"""Verify phase-profile scores using direct norms and original crop pixels."""
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(".cache/experiments/phase-fit-shrinkage-probe-v1").resolve()
report = read_json(root/"review/result.json")
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
by_case = {row["id"]: row for row in collection["synthetic"]}
scores = {(row["id"],row["method"]): row for row in report["metrics"]}
region = np.s_[...,128:384,128:384]
adopted = read_json(checked(plan["adopted_report"]))
old_scores = {(row["id"], row["method"]): row for row in adopted["metrics"]}
assert all(scores[key] == row for key, row in old_scores.items())
maximum = 0.
comparisons = 0


def norm_dn(value):
    return np.linalg.norm(value.ravel())*65535/np.sqrt(value.size)


for group in plan["groups"]:
    key = group["id"]
    with np.load(checked(group["arrays"])) as inputs:
        truth = inputs["target"].astype(np.float64)
        quiet, edge = inputs["quiet"], inputs["edge_band"]
    parent = np.load(checked(group["parent"])).astype(np.float64)
    methods = [row["method"] for row in report["metrics"] if row["id"] == key and row["method"].startswith("shrunken-")]
    predictions = {name: parent.copy() for name in methods}
    for row in by_case[key]["rows"]:
        with np.load(checked(row["prediction"])) as outputs:
            assert set(outputs.files) == set(methods)
            for method in outputs.files:
                predictions[method][row["role"]][region] = outputs[method]
    for method, value in predictions.items():
        error = value-truth
        expected = scores[key,method]
        actual = {
            "full_error_RMS_DN16": norm_dn(error),
            "query_full_RMS_DN16": norm_dn(error[region]),
            "query_quiet_RMS_DN16": norm_dn(error[region][...,quiet[region]]),
            "query_weak_absent_RMS_DN16": norm_dn(error[1][region]),
        }
        for name, mask in [("quiet",quiet),("edge",edge)]:
            part = error[...,mask]
            dc = part.sum(-1,keepdims=True)/part.shape[-1]
            actual[name+"_error_RMS_DN16"] = norm_dn(part)
            actual[name+"_DC_RMS_DN16"] = norm_dn(dc)
            actual[name+"_spatial_RMS_DN16"] = norm_dn(part-dc)
        for name, a, b in [("weak",1,2),("strong",0,1)]:
            observed = (value[b]-value[a]).ravel()
            target = (truth[b]-truth[a]).ravel()
            energy = target @ target
            gain = (observed @ target)/energy
            actual[name+"_gain"] = gain
            actual[name+"_increment_error_RMS_DN16"] = norm_dn(observed-target)
            actual[name+"_orthogonal_RMS_DN16"] = norm_dn(observed-gain*target)
            if name == "weak":
                actual["weak_absent_projection"] = (error[a].ravel() @ target)/energy
        assert set(actual) == set(expected)-{"source","placement","CFA","id","profile","method"}
        for metric, observed in actual.items():
            target = expected[metric]
            np.testing.assert_allclose(observed,target,rtol=1e-11,atol=1e-10)
            maximum = max(maximum,abs(observed-target))
            comparisons += 1

def cell(image, panels, index):
    x,y,w,h = panels[index]["png_xywh"]
    assert (w,h) == (160,160)
    return image[y:y+h,x:x+w]

for board in report["synthetic_boards"]:
    a,b = (np.asarray(Image.open(checked(board[k]["image"]))) for k in ["board","triplet"])
    for i,j in enumerate([0,3,4]):
        np.testing.assert_array_equal(cell(a,board["board"]["panels"],j),
                                      cell(b,board["triplet"]["panels"],i))
baseline_panels = 0
old_boards = {v["id"]: v for v in adopted["camera_boards"]}
for board in report["camera_boards"]:
    previous = old_boards[board["id"]]
    a,b = (np.asarray(Image.open(checked(x["image"]))) for x in [previous,board])
    for old in range(len(previous["panels"])):
        np.testing.assert_array_equal(cell(a,previous["panels"],old),
                                      cell(b,board["panels"],old+int(old>=5)))
        baseline_panels += 1
    source = board["source"]
    x,y,w,h = previous["original_board"]["ROI_xywh"]
    ox,oy = source["query_box"][:2]
    crop = np.s_[:,y-oy:y-oy+h,x-ox:x-ox+w]
    with np.load(checked(board["prediction"])) as result, np.load(checked(source["prediction"])) as original:
        for method, key in [("shrunken","shrunken-profile-t2")]:
            value = result[key][crop].astype(np.float64)
            parent = original["parent"][crop].astype(np.float64)
            np.testing.assert_allclose(norm_dn(value-parent),board[method+"_correction_RMS_DN16"],
                                       atol=1e-10,rtol=0.)
assert len(scores) == 1280 and len(old_scores) == 896 and comparisons == 6528 and len(report["camera_boards"]) == 8
write_json(root/"review/independent-audit.json", {
  "audit_driver": reference(__file__), "report": reference(root/"review/result.json"),
  "metric_rows": len(scores), "adopted_rows_bitexact": len(old_scores), "direct_comparisons": comparisons, "maximum_difference": maximum,
  "camera_baseline_panels_bitexact": baseline_panels, "synthetic_triplet_subsets": 4,
  "status": "passed",
})
print("Checked", comparisons, "numeric reductions and", baseline_panels, "old camera cells")
