"""Render two native diagnostic comparisons at the fixed ISO6400 threshold of zero."""
from pathlib import Path

import numpy as np

from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
receipt = root / "output/collection.json"
collection = read_json(receipt)
plan = read_json(checked(collection["plan"]))
matches = [
    group for group in plan["groups"]
    if group["profile"] == "iso6400" and group["source"] == 0 and group["CFA"] == "RGGB"
]
assert {v["placement"] for v in matches} == {"near", "far"}
rows = {row["id"]:row["rows"][2] for row in collection["synthetic"]}
query = np.s_[...,128:384,128:384]
boards = []
for group in matches:
    key = group["id"]
    row = rows[key]
    assert row["role"] == 2
    with np.load(checked(group["arrays"])) as arrays:
        target = arrays["target"][2][query].astype(np.float64)
        context = {k:arrays[k][2:3] for k in ("colors","wb","matrix")}
        context["packed"] = arrays["packed"][2:3,:,64:192,64:192]
    with np.load(checked(row["prediction"])) as result, np.load(checked(row["adopted_prediction"])) as prior:
        values = [
            noisy_malvar(context)[0],
            np.load(checked(group["parent"]))[2][query],
            prior["phase-profile-t0"],
            result["shrunken-profile-t0"],
            target,
        ]
    boards.append(native_board(
        root/"review", key, values, context, {"group":group, "role":2, "threshold":0},
        labels=("Noisy Malvar","V143 EMA","Phase bins","Shrunken phase fit","Exact GT"),
        triplet_indices=(0,3,4),
    ))
write_json(root/"review/high-noise.json",{
    "boards":boards,"driver":reference(__file__),"collection":reference(receipt),
    "scope":"Supplemental high-noise native viewing of the already scored fixed threshold-zero arms."})
print(*(v["id"] for v in boards))
