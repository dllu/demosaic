"""Preserve the discovery-shrinkage study and native comparisons."""
import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
source = repo/".cache/experiments/phase-fit-shrinkage-probe-v1"
analysis = source/"review"
report = read_json(analysis/"result.json")
audit = read_json(analysis/"independent-audit.json")
viewing = read_json(analysis/"actual-native-viewing.json")
summary = read_json(source/"diagnosis/summary.json")
assert audit["status"] == "passed" and audit["metric_rows"] == 1280
assert len(viewing["boards"]) == 14 and all(r["viewed"] for r in viewing["boards"])
out = repo/"docs/results/phase-fit-shrinkage-probe-v1"
images = repo/"docs/images/phase-fit-shrinkage-probe-v1"
out.mkdir()
images.mkdir()
records = []
synthetic = [*report["synthetic_boards"], *read_json(analysis/"high-noise.json")["boards"]]
boards = {"synthetic_boards":synthetic,"camera_boards":report["camera_boards"]}
for group, roles in [("synthetic_boards",["board","triplet"]),("camera_boards",["camera"])]:
    for item in boards[group]:
        for role in roles:
            record = item if role == "camera" else item[role]
            original = checked(record["image"])
            asset = images/original.name
            shutil.copyfile(original,asset)
            assert reference(asset)["sha256"] == record["image"]["sha256"]
            records.append({"id":item["id"],"role":role,"image":reference(asset),
                            "original":record["image"],"provenance":item})
plot = images/"quiet-tradeoff.png"
shutil.copyfile(checked(summary["plot"]),plot)
assert reference(plot)["sha256"] == summary["plot"]["sha256"]
write_json(images/"manifest.json", {"images":records,"plot":reference(plot),
    "viewing":reference(analysis/"actual-native-viewing.json"),
    "scope":"Unresized native comparisons: six synthetic, six exact triplet subsets, eight standing-camera."})
files = [p for p in source.rglob("*")
         if p.is_file() and p.suffix in (".py",".json",".log") and "__pycache__" not in p.parts]
files.append(repo/".cache/phase-fit-shrinkage-tests-v1.log")
archive = out/"evidence.tar.gz"
members = []
with archive.open("xb") as stream, gzip.GzipFile(fileobj=stream,mode="wb",mtime=0) as packed, tarfile.open(fileobj=packed,mode="w") as tar:
    for path in sorted(set(files)):
        label = str(path.relative_to(repo))
        members.append({"member":label,**reference(path)})
        tar.add(path,arcname=label,recursive=False)
with tarfile.open(archive) as tar:
    for row in members:
        assert hashlib.sha256(tar.extractfile(row["member"]).read()).hexdigest() == row["sha256"]
for src,dest in [(analysis/"independent-audit.json","independent-audit.json"),
                 (source/"diagnosis/summary.json","paired-summary.json"),
                 (analysis/"actual-native-viewing.json","actual-native-viewing.json")]:
    shutil.copyfile(src,out/dest)
write_json(out/"publication.json",{
    "archive":reference(archive),"members":members,"all_member_bytes_verified":True,
    "native_manifest":reference(images/"manifest.json"),"audited_metric_rows":1280,"adopted_metric_rows_bitexact":896,
    "native_boards_actually_viewed":14,
    "scope":"Complete discovery-fit shrinkage comparison. Original source/config/receipts"
             " and unresized PNGs retained. Actual output tensors stay locally bound by hash.",
})
print("Archived",len(members),"evidence files and",len(records),"native images")
