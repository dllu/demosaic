"""Evaluate channel delivery on signed captures, aligned controls and the real RAW crops."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers

from capture_signed import reversal

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-regional-phase-v1")
sys.path.insert(0, str(HERE.with_name(PRIOR.name)))
from replay_regional import FIXED, RAW, ROI, SENSOR_ROI, arrays, display, native_board, section
from review_pool import interval, source_bootstrap
from signed_delivery import ARMS, apply_delivery

METHODS = ARMS + ("parent", "v120")
LABELS = {
    "neutral": "Pooled color",
    "omit_color": "Green delivery",
    "signed": "Signed R/B",
    "conditional": "Conditional R/B",
}
CORE = np.s_[..., 64:192, 64:192]
REGION = np.s_[128:384, 128:384]


def rms(value):
    return float(np.sqrt(np.mean(value.astype("d") ** 2)) * 65535)


def scores(value, target, mask, parent):
    diff = (value - target)[CORE]
    weak = diff[0] - diff[1]
    z = {
        "full_RGB_DN16": rms(diff[0]),
        "full_green_DN16": rms(diff[0, 1]),
        "flat_RGB_DN16": rms(diff[2]),
        "edge_added_DN16": rms((value - parent)[CORE][3]),
        "uniform_added_DN16": rms((value - parent)[CORE][4]),
    }
    if np.count_nonzero(mask) >= 64:
        z.update(
            {
                "local_RGB_DN16": rms(diff[0][:, mask]),
                "local_RB_DN16": rms(diff[0][[0, 2]][:, mask]),
                "local_green_DN16": rms(diff[0, 1][mask]),
                "weak_increment_RGB_DN16": rms(weak[:, mask]),
                "weak_increment_RB_DN16": rms(weak[[0, 2]][:, mask]),
            }
        )
    return z


def checked_arms(rgb, scene, local, roi, colors, peaks, noise, wb, matrix, clearance):
    arms, info = apply_delivery(rgb, local, scene, roi, colors, peaks, noise, wb, matrix)
    x, y, w, h = local
    context = rgb[:, y - 16 : y + h + 16, x - 16 : x + w + 16]
    expect = refine_raw_mesh_carriers(
        rgb[:, y : y + h, x : x + w],
        scene,
        colors,
        roi,
        shot=noise["shot"],
        read=noise["read"],
        white_balance=wb,
        camera_to_srgb=matrix,
        method="pooled-color",
        parent_context=context,
        donor_clearance=clearance,
    )
    np.testing.assert_array_equal(expect, arms["neutral"])
    return arms, info


def photo_panel(cases, rows, own_plan, mode, outer=None):
    summary = []
    for case, row in zip(cases, rows, strict=True):
        assert case["id"] == row["id"]
        color_window = reversal(case)[1].numpy()[REGION]
        results = []
        for i, draw in enumerate(row["observations"]["warped"]):
            f = arrays(draw["input"])
            p = f["local50k"]
            donor = (
                draw["input"]
                if outer is None
                else outer[row["id"]]["observations"]["straight"][i]["input"]
            )
            scene = arrays(donor)["scene_packed"].copy()
            colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
            noise = own_plan["noise"]
            peaks = _spacing(scene, colors, *SENSOR_ROI[:2], clearance=48)
            outputs = {key: p.copy() for key in ARMS}
            details = []
            for index, sample in enumerate(f["packed"]):
                scene[RAW] = sample
                arms, info = checked_arms(
                    p[index], scene, ROI, SENSOR_ROI, colors, peaks, noise, wb, matrix, 48
                )
                for key in ARMS:
                    section(outputs[key][index], *ROI)[:] = arms[key]
                details.append(info)
            mask = (color_window & (f["support"] >= 0.35))[CORE]
            results.append(
                {
                    "draw": i,
                    "input": draw["input"],
                    "frequency_donor": donor,
                    "local_pixels": int(mask.sum()),
                    "fits": details,
                    "scores": {
                        k: scores(v, f["target"], mask, p)
                        for k, v in (outputs | {"parent": p, "v120": f["v120"]}).items()
                    },
                }
            )
            if mode == "signed" and i == 0 and case["index"] in own_plan["native_indices"]:
                attrs = {k: f[k][None] for k in ("colors", "wb", "matrix")}
                attrs["packed"] = f["packed"][:1]
                frames = [
                    noisy_malvar(attrs)[0],
                    f["v120"][0],
                    p[0],
                    *(outputs[k][0] for k in ARMS),
                    f["target"][0],
                ]
                results[-1]["native"] = native_board(
                    OUT / "exact",
                    f"color-{case['index']:02d}",
                    frames,
                    attrs,
                    {
                        "source": case,
                        "input": draw["input"],
                        "noise": noise,
                        "weights": own_plan["weights"],
                        "query": own_plan["query"],
                        "optical_sigma": own_plan["sigma"],
                    },
                    labels=["Noisy Malvar", "V120 EMA", "Local 50k", *LABELS.values(), "Exact GT"],
                    triplet_indices=(0, 6, 7),
                )
        summary.append(
            {
                "id": case["id"],
                "family": case["geometry"]["family"],
                "contrast": case["contrast_group"],
                "multiplier": case["color_multipliers"],
                "draws": results,
            }
        )
        if len(summary) % 8 == 0:
            print(mode, len(summary), flush=True)
    return summary


def mean_panel(rows):
    result = {}
    for metric in sorted({m for r in rows for d in r["draws"] for m in d["scores"]["neutral"]}):
        eligible = [r for r in rows if all(metric in d["scores"]["neutral"] for d in r["draws"])]
        rng = np.random.default_rng(202611200238)
        indices = source_bootstrap(eligible, rng)
        table = {}
        for arm in METHODS:
            values = (
                np.array(
                    [
                        [d["scores"][arm][metric], d["scores"]["neutral"][metric]]
                        for r in eligible
                        for d in r["draws"]
                    ]
                )
                .reshape(len(eligible), 2, 2)
                .mean(axis=1)
            )
            delta = values[:, 0] - values[:, 1]
            table[arm] = {
                "n": len(eligible),
                "mean": float(values[:, 0].mean()),
                "difference": interval(delta[indices].mean(axis=1)),
            }
        result[metric] = table
    return result


def standing():
    meta = reference(FIXED)
    review = read_json(checked(meta))
    rows = []
    for case in review["standing"]:
        f = arrays(case["input"])
        p = np.load(checked(case["predictions"]["local50k"]), allow_pickle=False)[0]
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(case["local_ROI"])
        peaks = _spacing(scene, colors, *roi[:2], clearance=16)
        arms, detail = checked_arms(
            p, scene, roi, roi, colors, peaks, case["noise"], wb, matrix, 16
        )
        changes = {k: rms(v - arms["neutral"]) for k, v in arms.items()}
        views = []
        for view in case["displays"]:
            before = view["board"]
            with Image.open(checked(before["image"])) as im:
                saved = np.asarray(im)
            cells = {}
            for pane in before["panels"]:
                x, y, w, h = pane["png_xywh"]
                cells[pane["name"]] = saved[y : y + h, x : x + w]
            exp = view["exposure"]
            cols = [(k, cells[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            cols += [
                (LABELS[m], display(arms[m], wb, matrix, exp))
                for m in ("neutral", "signed", "conditional")
            ]
            cols += [
                (k, cells[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in cells
            ]
            img = Image.new("RGB", (8 + 168 * len(cols), 192), "#eee")
            painter = ImageDraw.Draw(img)
            panels = []
            for i, (name, arr) in enumerate(cols):
                x = 8 + 168 * i
                img.paste(Image.fromarray(arr), (x, 24))
                painter.text((x, 5), name, fill="black")
                panels.append({"label": name, "xywh": (x, 24, 160, 160)})
            path = OUT / "standing" / f"{case['id']}-x{exp:g}.png"
            img.save(path)
            views.append(
                {"exposure": exp, "image": reference(path), "panels": panels, "prior": before}
            )
        rows.append(
            {
                "id": case["id"],
                "RAW": case["raw"],
                "roi": case["global_ROI"],
                "noise": case["noise"],
                "input": case["input"],
                "parent": case["predictions"]["local50k"],
                "windows": detail,
                "change_RGB_DN16": changes,
                "views": views,
            }
        )
        print(case["id"], changes, detail, flush=True)
    return {"rows": rows, "prior": meta, "weights": review["checkpoints"]}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    for sub in ("standing", "exact"):
        (OUT / sub).mkdir(exist_ok=True)
    capture = reference(OUT / "inputs.json")
    inp = read_json(checked(capture))
    plan = read_json(checked(inp["plan"]))
    neutral_bind = reference(PRIOR / "inputs.json")
    baseline = read_json(checked(neutral_bind))
    standing_result = standing()
    signed = photo_panel(plan["cases"], inp["rows"], plan, "signed")
    aligned = photo_panel(
        plan["cases"],
        baseline["rows"],
        plan,
        "aligned",
        outer={r["id"]: r for r in baseline["rows"]},
    )
    write_json(
        OUT / "review.json",
        {
            "driver": reference(__file__),
            "source": reference(HERE / "signed_delivery.py"),
            "signed_capture": capture,
            "aligned_capture": neutral_bind,
            "signed": {"rows": signed, "summary": mean_panel(signed)},
            "aligned": {"rows": aligned, "summary": mean_panel(aligned)},
            "standing": standing_result,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
