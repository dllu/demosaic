"""Repeat the preceding phase reversal control with signed channel delivery."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-regional-phase-v1")
sys.path.insert(0, str(HERE.with_name(PRIOR.name)))
import stress_regional as stress

from signed_delivery import apply_delivery, split_audit


def corrected(*args):
    reference_arms, info = BASE(*args)
    variants, _ = apply_delivery(*args)
    np.testing.assert_array_equal(reference_arms["regional_phase"], variants["neutral"])
    return reference_arms | variants, info


BASE = stress.apply_sharing


def main():
    before = reference(PRIOR / "Stress.json")
    old = read_json(checked(before))
    start = monotonic()
    stress.apply_sharing = corrected
    groups = {}
    for factor in stress.NOISES:
        key = f"{factor:g}x"
        rows = [stress.run_case(stress.SALT + i, factor) for i in range(stress.COUNT)]
        for old_case, new_case in zip(old["panels"][key]["rows"], rows, strict=True):
            for r in ("aligned", "medium"):
                expect = old_case["conditions"][r]["delivered"]["regional_phase"]
                value = new_case["conditions"][r]["delivered"]["neutral"]
                assert expect == value, (key, r, expect, value)
        rng = np.random.default_rng(stress.SALT)
        sel = rng.integers(0, stress.COUNT, (6000, stress.COUNT))
        views = {
            condition: [x["conditions"][condition]["delivered"] for x in rows]
            for condition in ("aligned", "medium")
        }
        arms = ("neutral", "omit_color", "signed", "conditional", "parent")
        groups[key] = {
            "summary": {
                role: {
                    metric: stress.stats([[item] for item in group], arms, metric, sel)
                    for metric in ("green_RMS_DN16", "rgb_RMS_DN16")
                }
                for role, group in views.items()
            },
            "per_fixture": views,
        }
        print(
            key,
            {
                r: {m: v["mean"] for m, v in s["rgb_RMS_DN16"].items()}
                for r, s in groups[key]["summary"].items()
            },
            flush=True,
        )
    write_json(
        OUT / "stress-conditional.json",
        {
            "driver": reference(__file__),
            "prior": before,
            "operation": reference(HERE / "signed_delivery.py"),
            "split_audit": split_audit(),
            "seconds": monotonic() - start,
            "results": groups,
        },
    )


if __name__ == "__main__":
    main()
