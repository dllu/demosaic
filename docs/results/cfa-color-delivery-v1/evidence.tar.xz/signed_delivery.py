"""Verify signed red and blue wire amplitudes on alternating same-color samples."""

import numpy as np

from demosaic._mesh_pooled import (
    _CENTERS,
    _CORE,
    _ABSOLUTE,
    _POOLED_FOOTPRINT,
    _SMOOTH,
    _STRIDE,
    _WINDOW,
    _Projection,
    _correction,
    _dominant,
    _inverse,
    _measure_nodes,
    _phase_template,
    _ramp,
    _rgb,
    _scores,
    _variance,
    _wave,
    _windows,
)
from demosaic.mesh_carrier_fit import _cosine_background

from regional_phase import fields, template

ARMS = ("neutral", "omit_color", "signed", "conditional")
_FIT_WIDTH = 48
_FIT_MARGIN = (_WINDOW - _FIT_WIDTH) // 2
_FIT = np.s_[_FIT_MARGIN:-_FIT_MARGIN, _FIT_MARGIN:-_FIT_MARGIN]
_FIT_BASIS = _cosine_background(_FIT_WIDTH)
_CENTER_BASIS = _cosine_background(_WINDOW // 2)
_CHECKER = {
    size: np.indices((size // 2, size // 2)).sum(axis=0).ravel() % 2 == 0
    for size in (_FIT_WIDTH, _WINDOW // 2)
}


def projection(basis, position, keep):
    r, c = position
    sample = basis[r::2, c::2].reshape(-1, basis.shape[-1])
    fitted = sample[keep]
    return _Projection(fitted, sample[~keep], _inverse(fitted))


def analyses(raw_patches, phase_patches, basis, position, shot, read, slope=None, nominal=None):
    """Fit on a checkerboard half and project it onto the unused half."""
    r, c = position
    sample = phase_patches[:, r::2, c::2].reshape(len(raw_patches), -1)
    observed = raw_patches.reshape(len(raw_patches), -1)
    mask = _CHECKER[basis.shape[0]]
    results = []
    for i, keep in enumerate((mask, ~mask)):
        projector = projection(basis, position, keep)
        u, v = observed[:, keep], observed[:, ~keep]
        train, held = projector.residual(u, v)
        f, h = projector.residual(sample[:, keep], sample[:, ~keep])
        if slope is None:
            value = np.einsum("np,np->n", f, train) / np.einsum("np,np->n", f, f).clip(min=1e-12)
        else:
            value = slope[i]
        variance = _variance(u, shot, read)
        score = _scores(held, h * value[:, None], variance)
        neutral = None if nominal is None else _scores(held, h * nominal[:, None], variance)
        results.append((value, score, neutral))
    return results


def channel_patches(plane, position, phase, competing, parent, active, shot, read, nominal):
    """Fit signed amplitudes in 48-pixel support and deliver to 32 pixels."""
    result = np.zeros((len(active), _WINDOW // 2, _WINDOW // 2))
    contradict = np.zeros(len(active), dtype=bool)
    if not active.any():
        return result, contradict
    margin = _FIT_MARGIN // 2
    center_margin = (_WINDOW // 4) // 2
    wave = _windows(phase, _WINDOW, _STRIDE)[active]
    raw = _windows(plane, _WINDOW // 2, _STRIDE // 2)[active]
    broad = np.concatenate((_FIT_BASIS, competing[_FIT]), axis=-1)
    narrow = np.concatenate((_CENTER_BASIS, competing[_CORE]), axis=-1)
    fits = analyses(
        raw[:, margin:-margin, margin:-margin],
        wave[:, _FIT[0], _FIT[1]],
        broad,
        position,
        shot,
        read,
        nominal=nominal,
    )
    coefficients, scores = (np.stack([pair[i] for pair in fits], axis=-1) for i in range(2))
    hold = analyses(
        raw[:, center_margin:-center_margin, center_margin:-center_margin],
        wave[:, _CORE[0], _CORE[1]],
        narrow,
        position,
        shot,
        read,
        slope=coefficients.T,
        nominal=nominal,
    )
    contradict[active] = (np.maximum(fits[0][2], fits[1][2]) < -_ABSOLUTE[0]) & (
        np.maximum(hold[0][2], hold[1][2]) < -_ABSOLUTE[1]
    )
    gain = _ramp(np.stack((scores.min(axis=1), np.minimum(hold[0][1], hold[1][1])), axis=-1))
    gain *= coefficients.prod(axis=1) > 0
    fitted = coefficients.mean(axis=1)
    flat = broad.reshape(_FIT_WIDTH**2, -1)
    tem = wave[:, _FIT[0], _FIT[1]].reshape(len(gain), -1)
    component = np.einsum("dp,np->nd", _inverse(flat), tem)
    residual = tem - np.einsum("pd,nd->np", flat, component)
    prior = parent[active, _FIT[0], _FIT[1]].reshape(len(gain), -1)
    existing = np.einsum("np,np->n", residual, prior) / np.einsum(
        "np,np->n", residual, residual
    ).clip(min=1e-12)
    delta = np.clip(gain * (fitted - existing), -abs(fitted), abs(fitted))
    result[active] = wave[:, _CORE[0], _CORE[1]] * delta[:, None, None]
    return result, contradict


def guides(wave, green, terms, direction):
    """The held red or blue observation is absent from this shape."""
    coefficients = np.stack([terms[p][0][:, direction] for p in green])
    precisions = np.stack([terms[p][1][:, direction] for p in green])
    precision = precisions.sum(axis=0)
    value = np.sum(coefficients * precisions[..., None], axis=0) / precision[:, None]
    return _phase_template(wave[..., direction, :], value, precision)


def green_amplitude(phase, competing, observed, positions, active):
    if not active.any():
        return np.empty(0)
    nuisance = np.concatenate((_FIT_BASIS, competing[_FIT]), axis=-1)
    wave = _windows(phase, _WINDOW, _STRIDE)[active, _FIT[0], _FIT[1]]
    margin = _FIT_MARGIN // 2
    values = []
    for (r, c), packed in zip(positions, observed, strict=True):
        design = nuisance[r::2, c::2].reshape(-1, nuisance.shape[-1])
        field = wave[:, r::2, c::2].reshape(len(wave), -1)
        coeff = np.einsum("dp,np->nd", _inverse(design), field)
        residual = field - np.einsum("pd,nd->np", design, coeff)
        raw = packed[active, margin:-margin, margin:-margin].reshape(len(wave), -1)
        values.append(
            np.einsum("np,np->n", residual, raw)
            / np.einsum("np,np->n", residual, residual).clip(min=1e-12)
        )
    return np.maximum(0, (values[0] + values[1]) / 2)


def apply_delivery(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    x, y, w, h = local
    crop = parent[:, y : y + h, x : x + w]
    if peaks is None:
        return {mode: crop for mode in ARMS}, {"rank": None, "enabled": None}
    rgb_context = parent[:, y - 16 : y + h + 16, x - 16 : x + w + 16]
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    shot, read = noise["shot"], noise["read"]
    green, chroma, planes = fields(scene, colors, roi[:2])
    global_wave = _wave(_POOLED_FOOTPRINT, peaks)
    terms = {p: _measure_nodes(plane, global_wave, p, shot, read) for p, plane in planes.items()}
    first, second = (_dominant(*terms[p]) for p in green)
    weak = 1 - first if first is not None and first == second else None
    waves = _wave(_WINDOW, peaks)
    basis = np.concatenate((_SMOOTH, waves.reshape(_WINDOW, _WINDOW, 4)), axis=-1)
    proj = _inverse(basis.reshape(_WINDOW**2, -1))[-4:]
    parent_windows = tuple(_windows(c, _WINDOW, _STRIDE) for c in rgb_context)
    prior = np.einsum("dp,np->nd", proj, parent_windows[1].reshape(len(_CENTERS), -1)).reshape(
        -1, 2, 2
    )
    observed = tuple(_windows(planes[p], _WINDOW // 2, _STRIDE // 2) for p in green)
    results = {name: [] for name in ("omit_color", "signed")}
    green_patches = []
    veto_delta = []
    selected = {}
    for d in range(2):
        enabled = weak is None or d == weak
        templates = None
        if enabled:
            local_guides = tuple(
                template(global_wave, terms, p, chroma, d, regional=True) for p in green
            )
            if any(count > 0 for _, v in local_guides for _, count in v):
                templates = tuple(f for f, _ in local_guides)
            else:
                templates = tuple(template(global_wave, terms, p, (), d)[0] for p in green)
        patches = _correction(
            waves,
            d,
            green,
            observed,
            templates,
            parent_windows[1].reshape(len(_CENTERS), -1),
            prior[:, d],
            shot,
            read,
        )
        green_patches.append(patches)
        veto_delta.append(np.zeros((3, *patches.shape)))
        if not enabled:
            results["omit_color"].append(None)
            results["signed"].append(None)
            continue
        active = np.any(patches, axis=(1, 2))
        phase = guides(global_wave, green, terms, d)
        amplitude = green_amplitude(phase, waves[..., 1 - d, :], observed, green, active)
        signed = []
        counts = []
        for c, p in zip((0, 2), chroma, strict=True):
            value, contradicted = channel_patches(
                planes[p],
                p,
                phase,
                waves[..., 1 - d, :],
                parent_windows[c],
                active,
                shot,
                read,
                neutral[c] * amplitude,
            )
            signed.append(value)
            veto_delta[-1][c, contradicted] = (
                value[contradicted] - neutral[c] * patches[contradicted]
            )
            counts.append(int(np.count_nonzero(contradicted)))
        results["omit_color"].append(
            np.stack((np.zeros_like(patches), patches, np.zeros_like(patches)))
        )
        results["signed"].append(np.stack((signed[0], patches, signed[1])))
        selected[str(d)] = {
            "signed_windows": [
                int(np.count_nonzero(np.any(f, axis=(1, 2))))
                for f in (signed[0], patches, signed[1])
            ],
            "veto_windows": counts,
        }

    def convert(planes):
        return np.stack([_rgb(a, np.ones(1), crop.dtype)[0] for a in planes])

    if weak is None:
        blended = green_patches[0] + green_patches[1]
        out = {name: crop + convert(parts[0] + parts[1]) for name, parts in results.items()}
        out["neutral"] = crop + _rgb(blended, neutral, crop.dtype)
    else:
        common = crop + _rgb(green_patches[1 - weak], neutral, crop.dtype)
        out = {name: common + convert(parts[weak]) for name, parts in results.items()}
        out["neutral"] = common + _rgb(green_patches[weak], neutral, crop.dtype)
    out["conditional"] = out["neutral"] + convert(veto_delta[0] + veto_delta[1])
    for name in ARMS[1:]:
        np.testing.assert_array_equal(out[name][1], out["neutral"][1])
    return out, {"rank": weak, "enabled": selected}


def split_audit():
    """Replacing an entire red/blue reserve leaves the corresponding fitted amplitude fixed."""
    rng = np.random.default_rng(24252)
    phase = _wave(_FIT_WIDTH, np.array(((0.10, 0.070), (0.105, -0.065))))
    waves = np.broadcast_to(phase[..., 0, 0], (len(_CENTERS), _FIT_WIDTH, _FIT_WIDTH))
    keep = _CHECKER[_FIT_WIDTH]
    out = []
    for pos in np.ndindex(2, 2):
        y, x = pos
        original = (
            0.06 + 0.003 * waves[:, y::2, x::2] + rng.normal(0, 0.01, (len(_CENTERS), 24, 24))
        )
        base = analyses(original, waves, _FIT_BASIS, pos, 0.00128, 6.5536e-6)
        for i, mask in enumerate((keep, ~keep)):
            changed = original.copy().reshape(len(_CENTERS), -1)
            changed[:, ~mask] = rng.uniform(0.04, 0.08, (len(_CENTERS), (~mask).sum()))
            replay = analyses(
                changed.reshape(original.shape), waves, _FIT_BASIS, pos, 0.00128, 6.5536e-6
            )
            np.testing.assert_array_equal(base[i][0], replay[i][0])
            assert np.any(replay[i][1] != base[i][1])
            out.append({"position": pos, "fold": i})
    return out
