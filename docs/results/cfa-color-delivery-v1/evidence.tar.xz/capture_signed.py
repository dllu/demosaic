"""Create optical signed-color observations from the locked 24-photo cohort."""

from pathlib import Path
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-regional-phase-v1")
SEED = 202611200233
sys.path.insert(0, str(HERE.with_name("local-carrier-envelope-v1")))
import capture_envelope as envelope

MODES = ((-1.0, -1.0), (-1.0, 0.0), (0.0, -1.0))
OLD_FIXTURES = envelope.fixtures


def reversal(g, n=512):
    y, x = torch.meshgrid(
        torch.arange(n) - (n - 1) / 2, torch.arange(n) - (n - 1) / 2, indexing="ij"
    )
    cx, cy, w, h = g["color_ellipse"]
    radius = ((x - cx) / w) ** 2 + ((y - cy) / h) ** 2
    return ((1.2 - radius) / 0.4).clamp(0, 1), radius <= 0.8


def fixtures(case, state):
    geo, (present, strong, *controls), mask, recipe = OLD_FIXTURES(case, state)
    inv = torch.tensor(recipe.camera_inverse, dtype=torch.float32)
    calibration = torch.tensor(recipe.wb, dtype=torch.float32)[:, None, None]
    weak = torch.einsum("ij,jhw->ihw", inv, present - strong) / calibration
    weight, _ = reversal(case)
    ratio = torch.tensor([case["color_multipliers"][0], 1.0, case["color_multipliers"][1]])
    weak *= 1 + (ratio[:, None, None] - 1) * weight
    changed = strong + torch.einsum("ij,jhw->ihw", torch.linalg.inv(inv), weak * calibration)
    assert float(changed.min()) > 0 and float(changed.max()) < 1
    new_green = torch.einsum("j,jhw->hw", inv[1], changed)
    old_green = torch.einsum("j,jhw->hw", inv[1], present)
    torch.testing.assert_close(new_green, old_green, rtol=0, atol=3e-7)
    return geo, (changed, strong, *controls), mask, recipe


def main():
    torch.set_num_threads(2)
    binding = reference(PRIOR / "plan.json")
    old = read_json(checked(binding))
    cases = []
    for case in old["cases"]:
        i = case["index"]
        mod = MODES[(i + i // 4) % len(MODES)]
        ellipse = (float((-1) ** i * (9 + i % 5)), float((i % 3 - 1) * 9), 37.0, 47.0)
        cases.append(case | {"color_multipliers": mod, "color_ellipse": ellipse})
    plan = old | {
        "cases": cases,
        "seed": SEED,
        "states": ["warped"],
        "source_plan": binding,
        "capture_driver": reference(envelope.__file__),
        "driver": reference(__file__),
        "native_indices": [3, 6],
        "primary": "Fresh sensor draws from the same photo sources, with independently signed weak contrasts in camera red and blue.",
    }
    path = OUT / "plan.json"
    write_json(path, plan)
    envelope.OUT, envelope.SALT, envelope.STATES, envelope.fixtures = (
        OUT,
        SEED,
        ("warped",),
        fixtures,
    )
    envelope.capture(plan, reference(path))


if __name__ == "__main__":
    main()
