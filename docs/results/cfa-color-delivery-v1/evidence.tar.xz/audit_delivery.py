"""Check whether conditional color gains come from fitting or suppressing chroma."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

from replay_delivery import CORE, OUT, PRIOR, RAW, REGION, ROI, SENSOR_ROI, rms
from capture_signed import reversal
from replay_delivery import arrays
import signed_delivery as delivery

HERE = Path(__file__).resolve().parent
ORIGINAL = delivery.channel_patches


def evaluate(row, case, observations, aligned, noise):
    by_draw = []
    mask0 = reversal(case)[1].numpy()[REGION]
    for i, d in enumerate(row["draws"]):
        source = d["input"]
        f = arrays(source)
        rgb = f["local50k"][0]
        bayer = arrays(d["frequency_donor"])["scene_packed"].copy()
        bayer[RAW] = f["packed"][0]
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        peaks = _spacing(bayer, colors, *SENSOR_ROI[:2], clearance=48)
        counts = []

        def instrumented(*args):
            values, veto = ORIGINAL(*args)
            counts.append((int(veto.sum()), int(np.sum(veto & np.any(values, axis=(1, 2))))))
            return values, veto

        try:
            delivery.channel_patches = instrumented
            common, _ = delivery.apply_delivery(
                rgb, ROI, bayer, SENSOR_ROI, colors, peaks, noise, wb, matrix
            )
            by_veto = np.asarray(counts, dtype=np.int64).reshape(-1, 2).sum(axis=0)
            if by_veto[1]:

                def suppression(*args):
                    values, veto = ORIGINAL(*args)
                    values[veto] = 0
                    return values, veto

                delivery.channel_patches = suppression
                controls, _ = delivery.apply_delivery(
                    rgb, ROI, bayer, SENSOR_ROI, colors, peaks, noise, wb, matrix
                )
                no_color = controls["conditional"]
            else:
                no_color = common["conditional"]
        finally:
            delivery.channel_patches = ORIGINAL
        x, y, w, h = ROI
        native = np.s_[:, y : y + h, x : x + w]
        a, b = f["target"][0][native], rgb[native]
        mask = mask0 & (f["support"] >= 0.35)
        mask = mask[y : y + h, x : x + w]
        inner = np.s_[..., 16:-16, 16:-16]
        patch = mask[inner]
        variants = common | {"veto_only": no_color}
        values = {name: rms(((val - a)[inner])[:, patch]) for name, val in variants.items()}
        np.testing.assert_allclose(
            values["conditional"], d["scores"]["conditional"]["local_RGB_DN16"], atol=1e-6, rtol=0
        )
        by_draw.append(
            {
                "input": source,
                "changed_windows": int(by_veto[0]),
                "with_signed_fit": int(by_veto[1]),
                "scores": values,
            }
        )
    return {"id": row["id"], "draws": by_draw}


def main():
    torch.set_num_threads(2)
    bind = reference(OUT / "review.json")
    review = read_json(checked(bind))
    capture = read_json(checked(review["signed_capture"]))
    plan = read_json(checked(capture["plan"]))
    results = {}
    for tag in ("signed", "aligned"):
        rows = [
            evaluate(row, case, review, tag == "aligned", plan["noise"])
            for row, case in zip(review[tag]["rows"], plan["cases"], strict=True)
        ]
        vals = [d for row in rows for d in row["draws"]]
        counts = {k: sum(d[k] for d in vals) for k in ("changed_windows", "with_signed_fit")}
        averages = {
            key: float(np.mean([d["scores"][key] for d in vals])) for key in vals[0]["scores"]
        }
        results[tag] = {"rows": rows, "counts": counts, "mean_local_RGB_DN16": averages}
        print(tag, counts, averages, flush=True)
    write_json(
        OUT / "audit.json",
        {
            "source": reference(__file__),
            "operation": reference(HERE / "signed_delivery.py"),
            "review": bind,
            "results": results,
        },
    )


if __name__ == "__main__":
    main()
