"""Estimate a within-window carrier deficit using disjoint green samples."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
NEAR = ROOT.with_name("bayer-near-donors-v1")
CROSS = ROOT.with_name("bayer-cross-evidence-v1")
sys.path.insert(0,str(NEAR))
from screen import phase,nominate
from evidence import old

spec=spec_from_file_location("frozen_carrier_decomposition",CROSS/"delivery_fair.py")
cross=module_from_spec(spec)
spec.loader.exec_module(cross)

WIDTH=phase.SIZE
INNER=32
STATIONS=tuple((y,x) for y in (0,16,32) for x in (0,16,32))
PULSE=np.sin(np.pi*(np.arange(INNER)+.5)/INNER)**2
BLEND=PULSE[:,None]*PULSE[None,:]
TILE_TAPER=phase.BLENDS[WIDTH]
# Use a fixed low-frequency basis on each sample set. The inner patch
# keeps a constant, two slopes and their second-order variations.
yy,xx=np.indices((WIDTH,WIDTH),dtype=np.float64)
xx=(xx-31.5)/32
yy=(yy-31.5)/32
TONE=np.stack((np.ones_like(xx),xx,yy,xx*xx,xx*yy,yy*yy),axis=-1)
LOW=0.75
HIGH=2.5
MAX_CUT=.75
MODES=("baseline","local","uniform","reversed")


def solve(raw,design,mask,offset,noise):
    keep=phase.clip_samples(mask,offset)
    A=phase.clip_samples(design,offset)[keep]
    y=phase.clip_samples(raw,offset)[keep].astype(np.float64)
    normal=A.T@A
    if np.linalg.cond(normal)>1e7:
        return None
    inverse=np.linalg.solve(normal,np.eye(normal.shape[0]))
    fitted=(inverse@(A.T@y))[-4:].reshape(2,2).T
    ids=np.arange(normal.shape[0]-4,normal.shape[0]).reshape(2,2).T
    cov=np.stack([inverse[np.ix_(idx,idx)] for idx in ids])*phase.variance(y,noise)
    return fitted,cov


def compare(ring,inside):
    first,second=ring
    half=inside
    deficit=second[0]-half[0]
    cov=second[1]+half[1]
    projection=np.sum(first[0]*deficit,axis=1)
    normal=np.einsum("fi,fij,fj->f",first[0],cov,first[0])
    z=projection/np.sqrt(np.maximum(1e-24,normal))
    coherence=np.sum(first[0]*second[0],axis=1)
    ratio=projection/np.maximum(1e-10,coherence)
    return z,ratio,coherence



def coherent_orthogonal(ring, inside):
    ref=ring[0][0]+ring[1][0]
    normal=np.maximum(1e-10,np.linalg.norm(ref,axis=-1,keepdims=True))
    v=np.column_stack((-ref[:,1],ref[:,0]))/normal
    a=np.sum(v*inside[0][0],axis=1)
    b=np.sum(v*inside[1][0],axis=1)
    ca=np.einsum("fi,fij,fj->f",v,inside[0][1],v)
    cb=np.einsum("fi,fij,fj->f",v,inside[1][1],v)
    inner=a*b
    ring=np.sum(ring[0][0]*ring[1][0],axis=1)
    return (inner>2*np.sqrt(np.maximum(1e-24,ca*cb))) & (inner>.25*ring)

def envelope(raw,carriers,layout,origin,noise):
    design=np.concatenate((TONE,carriers),axis=-1)
    colors=phase.planes(layout,(*origin,WIDTH))
    total=np.zeros((2,WIDTH,WIDTH),dtype=np.float64)
    mass=np.zeros((WIDTH,WIDTH),dtype=np.float64)
    diagnoses=[]
    for y,x in STATIONS:
        region=np.s_[y:y+INNER,x:x+INNER]
        core=np.zeros((WIDTH,WIDTH),dtype=bool)
        core[region]=True
        a,b=pair=[solve(raw,design,~core,plane,noise) for plane in colors]
        inner=[solve(raw,design,core,plane,noise) for plane in colors]
        z=np.zeros(2)
        cut=np.zeros(2)
        blocked=np.zeros(2,dtype=bool)
        if all(item is not None for item in (*pair,*inner)):
            forward=compare((a,b),inner[1])
            reverse=compare((b,a),inner[0])
            z=np.minimum(forward[0],reverse[0])
            fraction=np.clip(np.minimum(forward[1],reverse[1]),0,1)
            confidence=np.clip((z-LOW)/(HIGH-LOW),0,1)
            blocked=coherent_orthogonal(pair,inner)
            cut=MAX_CUT*fraction*confidence*(np.minimum(forward[2],reverse[2])>0)*~blocked
        total[:,region[0],region[1]]+=cut[:,None,None]*BLEND
        mass[region]+=BLEND
        diagnoses.append({"xy":[x,y],"deficit_z":z.tolist(),"cut":cut.tolist(),"phase_veto":blocked.tolist()})
    return 1-total/mass,diagnoses


def matched(gain,component):
    energy=np.square(component.astype(np.float64)*TILE_TAPER)
    room=energy.sum((-2,-1),keepdims=True)
    mass=np.maximum(room,1e-24)
    target=np.sum((1-gain)*energy,axis=(-2,-1),keepdims=True)/mass
    reversed_cut=(1-gain[:,::-1,::-1])
    reversed_mean=np.sum(reversed_cut*energy,axis=(-2,-1),keepdims=True)/mass
    reduced=reversed_cut*target/np.maximum(reversed_mean,1e-24)
    raised=reversed_cut+(MAX_CUT-reversed_cut)*(target-reversed_mean)/np.maximum(MAX_CUT-reversed_mean,1e-24)
    flipped=np.where(reversed_mean>=target,reduced,raised)
    np.testing.assert_allclose(np.sum(flipped*energy,axis=(-2,-1),keepdims=True)/mass,
                               target,atol=1e-12,rtol=0)
    return 1-target,1-flipped


def render(raw,parent,cfa,wb,matrix,noise,spacing,terms,roi=phase.ROI):
    x,y,w,h=roi
    assert (w,h)==(160,160)
    native=phase.unpack(raw)[y:y+h,x:x+w]
    prior=parent[1,y:y+h,x:x+w]
    weights=np.zeros((h,w),dtype=np.float64)
    sums=np.zeros((len(MODES),h,w),dtype=np.float64)
    receipt=[]
    for top in range(0,h-WIDTH+1,WIDTH//2):
        for left in range(0,w-WIDTH+1,WIDTH//2):
            sl=np.s_[top:top+WIDTH,left:left+WIDTH]
            nominal,indices=phase.coords(left,top,spacing)
            wave=phase.wave(nominal,indices,terms)
            p=(x+left,y+top)
            bands=cross.fit_bands(native[sl],prior[sl],cfa,(*p,WIDTH),wave,noise)
            sums[0][sl]+=bands[2]*TILE_TAPER
            # A zero parent lift is an exact no-op in every arm.
            if np.any(bands[2]):
                gain,test=envelope(native[sl],wave,cfa,p,noise)
                # The far/near gate already fixes both bands. Damping acts on
                # each estimated direction, and subtracts only its removed part.
                uniform,flipped=matched(gain,bands[:2])
                receipt.append({"tile":[left,top],"subwindows":test,
                                "uniform_strength":uniform[:,0,0].tolist()})
                for ix,control in enumerate((gain,uniform,flipped),start=1):
                    if np.all(control==1):
                        weighted=bands[2]*TILE_TAPER
                    else:
                        adjusted=bands[2]+((control-1)*bands[:2]).sum(0)
                        weighted=adjusted*TILE_TAPER
                    sums[ix][sl]+=weighted
            else:
                for ix in range(1,len(MODES)):
                    sums[ix][sl]+=bands[2]*TILE_TAPER
            weights[sl]+=TILE_TAPER
    edge=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    normal=(edge[:,None]*edge[None,:])/np.maximum(.02,weights)
    ratios=np.linalg.solve(matrix,np.ones(3))/wb
    rgb=np.zeros((len(MODES),*parent.shape),dtype=np.float32)
    rgb[:,:,y:y+h,x:x+w]=(ratios/ratios[1])[None,:,None,None]*(sums*normal)[:,None]
    return dict(zip(MODES,np.float32(old.DOSE)*rgb,strict=True)),receipt
