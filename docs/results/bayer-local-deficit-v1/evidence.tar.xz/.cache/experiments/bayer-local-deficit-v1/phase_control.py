"""Check whether a continuing carrier with shifted phase triggers false damping."""
import numpy as np

from local import ROOT, phase, envelope
from phase_veto import envelope as checked_envelope
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import reference,write_json


def main():
    freq=np.array(((.095,.050),(.11,-.081)))
    nominal,terms=phase.coords(32,32,freq)
    wave=phase.wave(nominal,terms,np.zeros((2,5)))
    strength=(.031,.022)
    scene=.10+strength[0]*wave[:,:,0]
    inner=np.s_[16:48,16:48]
    cases={"intact":scene+strength[1]*wave[:,:,1],"missing":scene+strength[1]*wave[:,:,1],
           "quarter-cycle":scene+strength[1]*wave[:,:,1]}
    cases["missing"][inner]=scene[inner]
    cases["quarter-cycle"][inner]=scene[inner]+strength[1]*wave[inner][...,3]
    noise={"shot":.00128,"read":6.5536e-6}
    rng=np.random.default_rng(3683657)
    outputs=[]
    for profile in ("noiseless","independent-gaussian"):
        for cfa in ("RGGB","GBRG","GRBG","BGGR"):
            layout=color_indices(cfa).numpy()
            for label,data in cases.items():
                for repeat in range(1 if profile=="noiseless" else 12):
                    mosaic = data if profile=="noiseless" else data+rng.normal(0,np.sqrt(data*noise["shot"]+noise["read"]))
                    row={"name":label,"profile":profile,"CFA":cfa,"repeat":repeat}
                    for k,fn in (("plain",envelope),("veto",checked_envelope)):
                        gain,test=fn(mosaic,wave,layout,(48,49),noise)
                        tile=next(t for t in test if t["xy"]==[16,16])
                        row[k]={"center_window_cut":tile["cut"],"mean_cut":(1-gain[:,16:48,16:48]).mean((1,2)).tolist()}
                    outputs.append(row)
    plain=lambda r:r["plain"]["center_window_cut"][1]
    veto=lambda r:r["veto"]["center_window_cut"][1]
    for entry in outputs:
        if entry["profile"]=="noiseless":
            if entry["name"]=="intact":
                assert plain(entry)==veto(entry)==0
            if entry["name"]=="missing":
                assert plain(entry)==veto(entry) and plain(entry)>.5
            if entry["name"]=="quarter-cycle":
                assert plain(entry)>.5 and veto(entry)==0
    write_json(ROOT/"phase-control.json",{"driver":reference(__file__),"noise":noise,"rows":outputs,"seed":3683657})


if __name__=="__main__":
    main()
