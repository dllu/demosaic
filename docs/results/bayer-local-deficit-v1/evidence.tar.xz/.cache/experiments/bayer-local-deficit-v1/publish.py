"""Build native boards and link all three localization rules to their receipts."""
from collections import defaultdict
from datetime import datetime
import hashlib
from pathlib import Path
from statistics import mean
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image,ImageDraw

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
DEST=Path("docs/images")/ROOT.name
RESULTS=Path("docs/results")/ROOT.name
NEAR=ROOT.with_name("bayer-near-donors-v1")
PREVIOUS=Path("docs/images/bayer-near-donors-v1/manifest.json")
TESTS=("replay","replay-weak","replay-phase")
VIEWS=("camera","camera-weak","camera-phase")
NAMES=("Local deficit check","Weak-only deficit check","Local check with phase veto")


def pieces(spec,src=None):
    if src is None:
        path=checked(spec["image"])
    else:
        path=src/spec["image"]["path"]
        assert reference(path)["sha256"]==spec["image"]["sha256"]
    with Image.open(path)as opened:
        view=np.asarray(opened.convert("RGB"))
    bins={}
    for rec in spec["panels"]:
        x,y,w,h=rec["png_xywh"]
        assert (w,h)==(160,160)
        cell=view[y:y+h,x:x+w]
        assert cell.shape==(160,160,3)
        bins[rec.get("name") or rec["label"]]=cell
    assert len(bins)==len(spec["panels"])
    return bins


def equality(first,second,keys):
    for name in keys:
        np.testing.assert_array_equal(first[name],second[name],err_msg=name)


def native(path,items):
    path.parent.mkdir(exist_ok=True)
    output=Image.new("RGB",(8+168*len(items),192),"#eeeeee")
    draw=ImageDraw.Draw(output)
    panels=[]
    for i,(label,pixels) in enumerate(items):
        assert pixels.dtype==np.uint8 and pixels.shape==(160,160,3)
        x=8+168*i
        draw.text((x,5),label,fill="black")
        output.paste(Image.fromarray(pixels),(x,24))
        panels.append({"label":label,"png_xywh":[x,24,160,160]})
    output.save(path)
    result={"image":reference(path),"panels":panels}
    saved=pieces(result)
    for label,original in items:
        np.testing.assert_array_equal(saved[label], original)
    result["image"]["path"]=path.relative_to(DEST).as_posix()
    return result


def exact_panels(data,previous):
    controls={r["id"]:r for r in previous["exact"]}
    runs=[]
    for test in data:
        boards=[board for row in test["groups"]["independent"]["records"] for board in row["native"]]
        assert len(boards)==2
        runs.append(boards)
    output=[]
    for base,weak,veto in zip(*runs,strict=True):
        srcs=(base,weak,veto)
        evidence=("id","source","input","parent","query","ROI_xywh","display_exposure","noise","CFA")
        assert all(row[k]==base[k] for row in srcs for k in evidence)
        prior=controls[base["id"]]
        for k in evidence:
            assert base[k]==prior[k]
        left,mid,right=[pieces(row["board"])for row in srcs]
        stable=("Noisy Malvar","Corpus 100k EMA","Near and far fallback","Exact GT")
        for also in (mid,right):
            equality(left,also,stable)
        earlier=pieces(prior["board"],PREVIOUS.parent)
        np.testing.assert_array_equal(left["Near and far fallback"],earlier["Near fallback, Bayer check"])
        changed=[(name,row[name]) for name,row in zip(NAMES,(left,mid,right),strict=True)]
        fields=[(name,left[name]) for name in stable[:3]]+changed+[
            ("Uniform attenuation",left["Same attenuation, uniform"]),
            ("Reversed attenuation",left["Same attenuation, reversed"]),
            ("Exact GT",left["Exact GT"])]
        endpoint=DEST/"exact"
        key=base["id"]
        result={"comparison":native(endpoint/f"{key}-comparison.png",fields),
                "triplet":native(endpoint/f"{key}-triplet.png",[fields[0],changed[-1],fields[-1]])}
        output.append({k:base[k] for k in evidence}|result)
    return output


def comparisons(data,previous):
    before={r["id"]:r for r in previous["standing"]["rows"]}
    manifest=[read_json(checked(r["manifest"])) for r in data]
    observations=[{obs["id"]:obs for obs in row["observations"]} for row in data]
    metadata=[]
    for base,weak,veto in zip(*(r["rows"]for r in manifest),strict=True):
        srcs=(base,weak,veto)
        evidence=("id","raw","input","parent","native_box","roi","noise","display_exposure")
        name=base["id"]
        assert all(row[k]==base[k]==before[name][k] for row in srcs for k in evidence)
        left,mid,right=[pieces(row["board"]) for row in srcs]
        initial=[k for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Prior joint crop check") if k in left]
        ending=[k for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in left]
        for also in (mid,right,pieces(before[name]["board"],PREVIOUS.parent)):
            equality(left,also,initial+ending)
        changed=[(key,row[key])for key,row in zip(NAMES,(left,mid,right),strict=True)]
        cells=[(key,left[key])for key in initial]+changed+[(key,left[key])for key in ending]
        board=native(DEST/"standing"/f"{name}.png",cells)
        report={key:obs[name]["changes"]["local"] for key,obs in zip(NAMES,observations,strict=True)}
        metadata.append({k:base[k]for k in evidence}|{"board":board,"change_vs_joint_fit":report})
    assert len(metadata)==8
    return metadata,manifest[0]["checkpoint"]


def phase_control(data):
    groups=defaultdict(list)
    for row in data["rows"]:
        groups[(row["profile"],row["name"])].append(row)
    scores={}
    for (noise,label),rows in groups.items():
        values={k:[float(row[k]["center_window_cut"][1]) for row in rows] for k in ("plain","veto")}
        assert len(rows)==(48 if noise=="independent-gaussian" else 4)
        scores[f"{noise}/{label}"]={k:{"mean_cut":mean(v),"active":sum(d>0 for d in v),"tested":len(v)}
                                     for k,v in values.items()}
    return scores


def main():
    DEST.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    source={k:reference(ROOT/f"{k}.json") for k in (*TESTS,*VIEWS,"phase-control")}
    bundle={k:read_json(checked(v)) for k,v in source.items()}
    previous=read_json(PREVIOUS)
    synthetic=[bundle[key] for key in TESTS]
    assert all(row["input"]==synthetic[0]["input"] and row["checkpoint"]==synthetic[0]["checkpoint"]
               for row in synthetic)
    exact=exact_panels(synthetic,previous)
    standing,composed=comparisons([bundle[key] for key in VIEWS],previous)
    scope={"checkpoint":synthetic[0]["checkpoint"],"standing_distal_gate":composed,
           "exact":exact,"standing":standing,"previous_manifest":reference(PREVIOUS),
           "actual_native_viewed":True,
           "native_observations":"The exact triplets keep their visible diagonals. All eight standing boards retain the same coarse crossings and incomplete fine cab intersections.",
           "reviewed_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()}
    view=DEST/"manifest.json"
    write_json(view,scope,replace=True)
    archive=RESULTS/"evidence.tar.xz"
    files=[checked(s)for s in source.values()]
    files += [checked(bundle[k]["manifest"])for k in VIEWS]
    files += [ROOT/f for f in ("local.py","local_weak.py","phase_veto.py","phase_control.py","replay.py",
        "replay_weak.py","replay_phase.py","standing.py","standing_weak.py","standing_phase.py","publish.py",
        "replay.log","replay-weak.log","replay_phase.log","phase_control.log","standing.log",
        "standing-weak.log","standing_phase.log")]
    files += [NEAR/file for file in ("delivery.json","recenter.json","screen.py","standing.py")]
    cross=NEAR.with_name("bayer-cross-evidence-v1")
    files += [cross/file for file in ("evidence.py","delivery_fair.py")]
    paths={str(f.resolve().relative_to(Path.cwd())):f for f in files}
    with tarfile.open(archive,"w:xz",preset=4)as stream:
        for tag,path in sorted(paths.items()):
            stream.add(path,arcname=tag,recursive=False)
    with tarfile.open(archive)as stream:
        for tag,path in paths.items():
            with stream.extractfile(tag) as file:
                assert hashlib.file_digest(file,"sha256").hexdigest()==reference(path)["sha256"]
    write_json(RESULTS/"publication.json",{"manifest":reference(view),"archive":reference(archive),
        "sources":source,"checkpoints":{"synthetic":synthetic[0]["checkpoint"],"standing_ema":composed},
        "phase_controls":phase_control(bundle["phase-control"]),
        "panels":{n:{k:v["summary"] for k,v in bundle[n]["groups"].items()}for n in TESTS},
        "scope":"Fixed near/far delivery replay with matched local attenuation controls and a separate ideal phase-control experiment."},replace=True)


if __name__=="__main__":
    main()
