"""Compare restorations with calibrated changes in weak response or flat error."""

from collections import Counter

import numpy as np
from scipy.optimize import brentq

from review_continuing import LABELS, LOCAL, PARENT, ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from fit_local import metric_for_wire
from upper import luma

MODELS = (LABELS["wire-aligned"], LABELS["strong-gap"])
KEYS = (
    "weak_response_pp",
    "exact_flat_RMS_DN16",
    "gap_weak_RMS_DN16",
    "gap_RMS_DN16",
    "intact_increment_RMS_DN16",
    "gap_strong_response_pp",
)


def measure(view, array):
    scorer, data = view["metric"], view["input"]
    value = scorer(array)
    if scorer.gap.any():
        basis = scorer.strong_basis
        expected = scorer.truth[0][scorer.gap] @ basis
        found = luma(array, data["wb"], data["matrix"])[0, 64:192, 64:192][scorer.gap] @ basis
        value["gap_strong_response_pp"] = float(100 * (found @ expected) / (expected @ expected))
    return {k: value.get(k) for k in KEYS}


def mix(view, pair, strength):
    a, b = (view["arrays"][name] for name in pair)
    return measure(view, a * (1 - strength) + b * strength)


def compare(held, pair, alpha, truth):
    rows = [
        dict(
            source=v["index"],
            candidate=measure(v, v["arrays"][truth]),
            comparison=mix(v, pair, alpha),
        )
        for v in held
    ]
    rng = np.random.default_rng(202611191401)
    out = {}
    for key in KEYS:
        nums = np.array(
            [
                [r["candidate"][key], r["comparison"][key]]
                for r in rows
                if r["candidate"][key] is not None
            ]
        )
        d = nums[:, 0] - nums[:, 1]
        boot = rng.integers(len(d), size=(8000, len(d)))
        out[key] = dict(
            samples=len(d),
            delta=float(d.mean()),
            interval=np.quantile(d[boot].mean(1), [0.025, 0.975]).tolist(),
            candidate=float(nums[:, 0].mean()),
            reference=float(nums[:, 1].mean()),
        )
    return dict(rows=rows, summary=out)


def main():
    proof = reference(ROOT / "review/result.json")
    native = read_json(checked(proof))
    cal, held = [], []
    for row in native["groups"]["wire"]["rows"]:
        with np.load(checked(row["input"]), allow_pickle=False) as doc:
            data = {k: doc[k] for k in doc.files}
        idx = row["source"]["index"]
        partition = cal if (idx // 4) % 2 == 0 else held
        arrays = {
            PARENT: np.load(checked(row["parent_output"]), allow_pickle=False),
            LOCAL: np.load(checked(row["endpoint_output"]), allow_pickle=False),
        }
        arrays.update(
            {LABELS[k]: np.load(checked(v), allow_pickle=False) for k, v in row["outputs"].items()}
        )
        view = dict(
            index=idx,
            input=data,
            metric=metric_for_wire(data, row["source"]["geometry"]),
            arrays=arrays,
        )
        partition.append(view)
    for p in (cal, held):
        assert len(p) == 12 and set(
            Counter(v["metric"].geometry["family"] for v in p).values()
        ) == {3}
    summaries = {}
    for label, target, pair, metric in (
        ("quiet_matched_to_repeat_parent", PARENT, MODELS, "exact_flat_RMS_DN16"),
        ("response_matched_to_continuing_model", MODELS[1], (PARENT, LOCAL), "weak_response_pp"),
    ):
        wanted = float(np.mean([measure(item, item["arrays"][target])[metric] for item in cal]))

        def delta(alpha):
            return np.mean([mix(item, pair, alpha)[metric] for item in cal]) - wanted

        lo, hi = delta(0.0), delta(1.0)
        result = dict(
            criterion=metric,
            blend=pair,
            calibration_target=target,
            reference_value=wanted,
            endpoint_differences=[float(lo), float(hi)],
            evaluated=bool(lo * hi <= 0),
        )
        if result["evaluated"]:
            alpha = float(brentq(delta, 0, 1, xtol=1e-5))
            result["fraction"] = alpha
            # First comparison treats the new-model blend as the candidate.
            result["held_out"] = compare(held, pair, alpha, target)
            print(
                label,
                alpha,
                {k: round(v["delta"], 4) for k, v in result["held_out"]["summary"].items()},
                flush=True,
            )
        summaries[label] = result
    write_json(
        ROOT / "review/matched-mixtures.json",
        dict(
            frozen_input=proof,
            driver=reference(__file__),
            calibration=[v["index"] for v in cal],
            held_out=[v["index"] for v in held],
            results=summaries,
            scope="Camera-RGB output interpolation. For quiet matching, reported deltas are repeat-parent minus blend. For response matching, they are continuing model minus the older-model blend.",
        ),
    )


if __name__ == "__main__":
    main()
