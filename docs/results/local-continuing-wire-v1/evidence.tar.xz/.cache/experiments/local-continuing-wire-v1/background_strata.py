"""Compare learned gap outcomes by the measured background ambiguity of the RAW fit."""

from review_continuing import ROOT, compare
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


if __name__ == "__main__":
    bound = reference(ROOT / "review/double-gap.json")
    phy = reference(ROOT / "raw-gap-evidence.json")
    result, raw = (read_json(checked(ref)) for ref in (bound, phy))
    assert result["inputs"] == raw["inputs"]
    biases = {r["source"]: r["draws"][0]["clean_affine_background_projection"] for r in raw["rows"]}
    cohorts = {"lower_background_projection": [], "higher_background_projection": []}
    for row in result["rows"]:
        identity = row["case"]["source"]["id"]
        bias = biases[identity]
        key = "higher_background_projection" if abs(bias) > 0.5 else "lower_background_projection"
        cohorts[key].append(dict(source=identity, background=bias, scores=row["scores"]))
    metrics = (
        "strong_response_pp",
        "continuing_error_DN16",
        "double_gap_strong_DN16",
        "double_gap_weak_DN16",
        "flat_RMS_DN16",
    )
    summary = {}
    for key, rows in cohorts.items():
        assert len(rows) == 8
        stats = compare([r["scores"] for r in rows], metrics)
        summary[key] = dict(rows=rows, summary=stats)
        for metric in metrics:
            print(
                key,
                metric,
                stats[metric]["values"],
                stats[metric]["differences"]["Continuing-wire loss vs Aligned control"],
                flush=True,
            )
    write_json(
        ROOT / "review/background-strata.json",
        dict(
            neural=bound,
            measurement=phy,
            cohorts=summary,
            scope="Two eight-source strata. A higher background projection means the clean residual after an affine CFA fit exceeds half the physical strong-wire coefficient in magnitude.",
        ),
    )
