"""Show source-paired continuing-wire outcomes from completed receipts."""

from pathlib import Path
from demosaic.experiments.artifacts import read_json

ROOT = Path(__file__).resolve().parent
STATS = {
    "fixed_photo": (
        "fine_response_pp",
        "fine_increment_RMS_DN16",
        "exact_flat_fine_RMS_DN16",
        "flat_chroma_RMS_DN16",
    ),
    "fixed_wire": (
        "weak_response_pp",
        "intact_increment_RMS_DN16",
        "exact_flat_RMS_DN16",
        "gap_RMS_DN16",
        "gap_weak_RMS_DN16",
    ),
    "gap-directions": (
        "strong_response_pp",
        "strong_error_DN16_squared",
        "aligned_error_DN16_squared",
    ),
    "double-gap": (
        "strong_response_pp",
        "continuing_bias_DN16",
        "continuing_error_DN16",
        "double_gap_signed_DN16",
        "double_gap_strong_DN16",
        "double_gap_weak_DN16",
        "flat_RMS_DN16",
    ),
    "wire-transfer": (
        "weak_response_pp",
        "intact_increment_RMS_DN16",
        "exact_flat_RMS_DN16",
        "gap_RMS_DN16",
        "gap_weak_RMS_DN16",
        "intact_draw_variance_DN16_squared",
        "shared_DN16_squared",
    ),
}


def show(scope, scores):
    print(scope)
    for key in STATS[scope]:
        base = scores[key]
        print(key, {model: round(value, 5) for model, value in base["values"].items()})
        for target in ("Aligned control", "Repeat parent", "Prior aligned wire"):
            label = f"Continuing-wire loss vs {target}"
            if label in base["differences"]:
                comp = base["differences"][label]
                print(" ", target, round(comp["delta"], 5), [round(n, 5) for n in comp["interval"]])


if __name__ == "__main__":
    native = ROOT / "review/result.json"
    if native.is_file():
        view = read_json(native)
        for name, v in view["groups"].items():
            show(f"fixed_{name}", v["summary"])
        for title in view["exact"]:
            print(
                title["id"],
                title["source"]["source"]["title"],
                title["source"]["source"]["author"],
                title["source"]["source"]["license"],
            )
        for case in view["standing"]:
            print(case["id"], case["rms_vs_parent_DN16"])
    for name in ("gap-directions", "double-gap", "wire-transfer"):
        path = ROOT / "review" / f"{name}.json"
        if path.is_file():
            show(name, read_json(path)["summary"])
