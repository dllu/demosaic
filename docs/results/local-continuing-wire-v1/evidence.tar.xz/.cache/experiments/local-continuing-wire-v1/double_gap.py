"""Measure true continuation and false lines under the same exterior geometry."""

import argparse
from collections import Counter, defaultdict
from dataclasses import replace
import json
import random
import time

import numpy as np
import torch

from review_continuing import LABELS, PARENT, PRIOR, PROFILE, ROOT, compare
from review_redraw_average import restore
from train_local_paired_continuation import (
    BOX,
    CORE,
    FORWARD_ARGS,
    clean_crop,
    gap_projection,
    wire_pair,
)
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe
from demosaic.scene_inference import load_scene_checkpoint
from demosaic.scene_training_data import scene_seed
from upper import luma

SEED = 202611191407
ROLES = ("continuing", "double-gap", "exact-flat")


def capture():
    base = ROOT.with_name("green-covariance-refit-v1")
    origin = reference(base / "plan.json")
    pool = read_json(checked(origin))["sources"]
    photos = [row for row in pool if row["kind"] == "natural"][:16]
    trial = reference(ROOT / "plan.json")
    study = read_json(checked(trial))
    source_ids = {row["source"]["id"] for row in photos}
    source_hashes = {row["source"]["cache_sha256"] for row in photos}
    assert len(source_ids) == len(source_hashes) == 16
    assert set(Counter(row["camera"]["pattern"] for row in photos).values()) == {4}
    assert all(row["source"]["split"] == "val" for row in photos)
    previous = read_json(PRIOR / "review/result.json")
    fixed = {
        row["source"]["source"]["id"]
        for group in previous["groups"].values()
        for row in group["rows"]
    }
    reused = read_json(PRIOR / "wire-redraw-inputs/panel.json")
    assert source_ids.isdisjoint(fixed | {r["source"]["source"]["id"] for r in reused["rows"]})
    manifests = {
        v["sha256"]: v for v in study["inputs"] if v["path"].endswith("manifest-train.jsonl")
    }
    assert manifests
    audit = []
    for proof in manifests.values():
        count = 0
        with checked(proof).open() as stream:
            for item in map(json.loads, stream):
                assert item["id"] not in source_ids and item["cache_sha256"] not in source_hashes
                count += 1
        audit.append(dict(manifest=proof, rows=count))
    panel = ROOT / "double-gap-inputs"
    panel.mkdir()
    rows = []
    for index, case in enumerate(photos):
        rng = random.Random(scene_seed(SEED, index, "background"))
        crop, native = clean_crop(case["source"], rng)
        geometry_state = rng.getstate()
        present, _, wire = wire_pair(crop, rng, strong_continues=True)
        rng.setstate(geometry_state)
        double, _, stopped = wire_pair(crop, rng, strong_continues=False)
        assert (wire | {"strong_continues": False}) == stopped
        flat = crop[:, 128:129, 128:129].expand_as(crop).contiguous()
        camera = replace(
            sample_scene_recipe(scene_seed(SEED, index, "camera")),
            pattern=case["camera"]["pattern"],
            black=0.03,
            shot=PROFILE["shot"],
            read=PROFILE["read"],
            exposure=PROFILE["exposure"],
        )
        views, same_clean = [], None
        for redraw in range(2):
            role_seeds = {role: scene_seed(SEED, index, f"noise:{redraw}:{role}") for role in ROLES}
            captures = [
                observe_scene(target, replace(camera, noise_seed=role_seeds[role])).crops([BOX])
                for target, role in zip((present, double, flat), ROLES, strict=True)
            ]
            batch = {
                k: torch.cat([o[k] for o in captures]).numpy() for k in (*FORWARD_ARGS, "target")
            }
            for k in ("colors", "wb", "matrix"):
                assert np.all(batch[k] == batch[k][0])
                batch[k] = batch[k][0]
            clean = fingerprint(batch["target"])
            assert same_clean is None or same_clean == clean
            same_clean = clean
            path = panel / f"{index:02d}-{redraw}.npz"
            with path.open("xb") as stream:
                np.savez_compressed(stream, **batch)
            views.append(
                dict(
                    arrays=reference(path),
                    role_seeds=role_seeds,
                    packed=fingerprint(batch["packed"]),
                )
            )
        assert views[0]["packed"] != views[1]["packed"]
        rows.append(
            dict(
                source=case["source"],
                index=index,
                crop=native,
                CFA=camera.pattern,
                geometry=wire,
                camera=vars(camera),
                draws=views,
                clean=same_clean,
            )
        )
        print("double-gap observations", len(rows), flush=True)
    seeds = [v for row in rows for draw in row["draws"] for v in draw["role_seeds"].values()]
    assert len(seeds) == len(set(seeds)) == 96
    write_json(
        panel / "panel.json",
        dict(
            origin=origin,
            study=trial,
            training_exclusions=audit,
            rows=rows,
            profile=PROFILE,
            driver=reference(__file__),
            training_driver=study["driver"],
            roles=ROLES,
            seed=SEED,
            scope="Sixteen source-disjoint held-out backgrounds. Exact continuation, absence of both directions and flat targets with two independent sensor draws.",
        ),
    )


def metrics(values, target, wire):
    p = gap_projection(wire, continuing=True).numpy().astype(float)
    weak = gap_projection(wire).numpy().astype(float)
    core = np.s_[..., CORE, CORE]
    actual = values[core].reshape(-1, 3, 96**2)
    clean = target[core].reshape(3, -1)
    residual = actual - clean
    truth = (clean[0] - clean[1]) @ p
    assert truth > 0
    paired = (actual[:, 0] - actual[:, 1]) @ p
    continuing, hallucinated = (residual @ p).T[:2]
    weak_double = residual[:, 1] @ weak
    smooth = residual[:, 2] - residual[:, 2].mean(axis=1, keepdims=True)
    return dict(
        strong_response_pp=float(100 * paired.mean() / truth),
        true_projected_DN16=float(truth * 65535),
        continuing_bias_DN16=float(continuing.mean() * 65535),
        continuing_error_DN16=float(np.sqrt(np.mean(continuing**2)) * 65535),
        double_gap_signed_DN16=float(hallucinated.mean() * 65535),
        double_gap_strong_DN16=float(np.sqrt(np.mean(hallucinated**2)) * 65535),
        double_gap_weak_DN16=float(np.sqrt(np.mean(np.sum(weak_double**2, axis=1))) * 65535),
        flat_RMS_DN16=float(np.sqrt(np.mean(smooth**2)) * 65535),
    )


@torch.inference_mode()
def score():
    torch.set_num_threads(2)
    binding = reference(ROOT / "double-gap-inputs/panel.json")
    panel = read_json(checked(binding))
    endpoint = reference(ROOT / "training/completed.json")
    run = read_json(checked(endpoint))
    assert panel["study"] == run["plan"]
    plans = {PARENT: run["parent"]} | {LABELS[key]: ref for key, ref in run["checkpoints"].items()}
    models = {}
    for name, ref in plans.items():
        model, state = load_scene_checkpoint(
            checked(ref), weights="ema", expected_sha256=ref["sha256"]
        )
        assert state["loaded_weights"] == "ema"
        models[name] = _stage_tiled_cuda(model.eval(), "cuda")
    start = time.monotonic()
    results = []
    for record in panel["rows"]:
        views = defaultdict(list)
        for capture in record["draws"]:
            with np.load(checked(capture["arrays"]), allow_pickle=False) as data:
                args = {k: data[k] for k in data.files}
            assert (
                fingerprint(args["target"]) == record["clean"]
                and fingerprint(args["packed"]) == capture["packed"]
            )
            for label, model in models.items():
                values, _ = restore(model, args, panel["profile"])
                views[label].append(luma(values, args["wb"], args["matrix"]))
        exact = luma(args["target"], args["wb"], args["matrix"])
        results.append(
            dict(
                case=record,
                scores={
                    k: metrics(np.stack(v), exact, record["geometry"]) for k, v in views.items()
                },
            )
        )
        print("double gaps scored", len(results), flush=True)
    keys = sorted(results[0]["scores"][PARENT])
    summary = compare([r["scores"] for r in results], keys)
    write_json(
        ROOT / "review/double-gap.json",
        dict(
            inputs=binding,
            endpoint=endpoint,
            models=plans,
            weights="EMA",
            precision="CUDA IEEE FP32",
            rows=results,
            summary=summary,
            seconds=time.monotonic() - start,
            driver=reference(__file__),
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("capture", "score"))
    args = parser.parse_args()
    if args.action == "capture":
        torch.set_num_threads(2)
        capture()
    else:
        score()
