"""Measure continuation evidence in Bayer samples with supplied exact wire geometry."""

from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic, unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from train_local_paired_continuation import CORE, gap_projection

ROOT = Path(__file__).resolve().parent


def observations(f, wire, profile):
    colors = torch.from_numpy(f["colors"])
    data = unpack(torch.from_numpy(f["packed"]))[:2, 0, CORE, CORE].numpy().astype(float)
    clean = (
        unpack(mosaic(torch.from_numpy(f["target"]), colors))[:2, 0, CORE, CORE]
        .numpy()
        .astype(float)
    )
    keep = gap_projection(wire, continuing=True).numpy().reshape(96, 96) != 0
    encoded = clean[:, keep]
    assert encoded.min() > 0 and encoded.max() < 0.98
    signal = encoded[0] - encoded[1]
    standard = np.sqrt(profile["shot"] * encoded.mean(0) + profile["read"])
    # Measured quantities use a common whitening scale for both hypotheses.
    truth = signal / standard
    raw = data[:, keep] / standard
    exact_background = encoded[1] / standard
    expected = truth @ truth
    coefficients_exact = (raw - exact_background) @ truth / expected
    rows, cols = np.indices(keep.shape)
    phase = (rows % 2) * 2 + cols % 2
    indicator = np.eye(4)[phase[keep]]
    trend = np.concatenate(
        [
            indicator,
            indicator * ((rows[keep, None] - 47.5) / 48),
            indicator * ((cols[keep, None] - 47.5) / 48),
        ],
        axis=1,
    )
    basis, _ = np.linalg.qr(trend / standard[:, None], mode="reduced")
    supported = truth - basis @ (basis.T @ truth)
    supported_power = supported @ supported
    assert supported_power > 0
    coefficients_plane = raw @ supported / supported_power
    return dict(
        exact_background_amplitudes=coefficients_exact.tolist(),
        affine_CFA_background_amplitudes=coefficients_plane.tolist(),
        expected_exact_SNR=float(np.sqrt(expected)),
        expected_affine_SNR=float(np.sqrt(supported_power)),
        clean_affine_background_projection=float(exact_background @ supported / supported_power),
        raw_pixels=int(keep.sum()),
    )


def main():
    torch.set_num_threads(2)
    binding = reference(ROOT / "double-gap-inputs/panel.json")
    panel = read_json(checked(binding))
    cases = []
    for case in panel["rows"]:
        results = []
        for draw in case["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                values = {k: f[k] for k in f.files}
            assert (
                fingerprint(values["target"]) == case["clean"]
                and fingerprint(values["packed"]) == draw["packed"]
            )
            results.append(observations(values, case["geometry"], panel["profile"]))
        cases.append(dict(source=case["source"]["id"], draws=results))
    summary = {}
    for name in ("exact", "affine_CFA"):
        values = np.asarray(
            [v[f"{name}_background_amplitudes"] for row in cases for v in row["draws"]]
        )
        assert len(values) == 32
        statistics = dict(
            positive_cases=int((values[:, 0] > 0.5).sum()),
            double_gap_false_alarms=int((values[:, 1] > 0.5).sum()),
            draws_per_condition=32,
            median_continuing_amplitude=float(np.median(values[:, 0])),
            median_double_gap_amplitude=float(np.median(values[:, 1])),
            response_across_sources_pp=float(100 * np.mean(values[:, 0] - values[:, 1])),
        )
        summary[name] = statistics
        print(name, statistics, flush=True)
    snr = np.asarray(
        [[r["draws"][0][k] for r in cases] for k in ("expected_exact_SNR", "expected_affine_SNR")]
    )
    q = np.quantile(snr, [0, 0.25, 0.5, 0.75, 1], axis=1).T.tolist()
    print("SNR quantiles in exact and affine variants", q, flush=True)
    write_json(
        ROOT / "raw-gap-evidence.json",
        dict(
            inputs=binding,
            driver=reference(__file__),
            amplitude_threshold=0.5,
            summary=summary,
            rows=cases,
            predicted_SNR_quantiles=q,
            scope="Fixed detection with a supplied exact waveform and gap mask. Exact background and Bayer phase-specific affine background diagnostics on the same draws.",
        ),
    )


if __name__ == "__main__":
    main()
