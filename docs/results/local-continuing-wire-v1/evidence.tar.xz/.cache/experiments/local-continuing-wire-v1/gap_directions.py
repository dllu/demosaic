"""Read the signed continuing-wire response from the fixed exact weak-wire gaps."""

import numpy as np

from review_continuing import EARLIER, LABELS, PARENT, ROOT, compare
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from fit_local import metric_for_wire
from upper import luma


def main():
    binding = reference(ROOT / "review/result.json")
    review = read_json(checked(binding))
    rows = []
    for case in review["groups"]["wire"]["rows"]:
        with np.load(checked(case["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        metric = metric_for_wire(data, case["source"]["geometry"])
        if not metric.gap.any():
            continue
        basis = metric.strong_basis
        exact = metric.truth[0][metric.gap] @ basis
        power = exact @ exact
        assert power > 0
        scale = 65535**2 / int(metric.gap.sum())
        scores = {}
        files = {PARENT: case["parent_output"], EARLIER: case["historical_output"]} | {
            LABELS[k]: v for k, v in case["outputs"].items()
        }
        for name, proof in files.items():
            values = np.load(checked(proof), allow_pickle=False)
            tone = luma(values, data["wb"], data["matrix"])[0, 64:192, 64:192][metric.gap]
            coeff = tone @ basis
            response = coeff @ exact / power
            diff = coeff - exact
            scores[name] = dict(
                strong_response_pp=float(100 * response),
                aligned_error_DN16_squared=float((response - 1) ** 2 * power * scale),
                strong_error_DN16_squared=float(diff @ diff * scale),
            )
        rows.append(
            dict(
                source=case["source"]["source"]["id"],
                scores=scores,
                files=files,
                input=case["input"],
            )
        )
    assert len(rows) == 12
    keys = sorted(rows[0]["scores"][PARENT])
    result = compare([r["scores"] for r in rows], keys)
    write_json(
        ROOT / "review/gap-directions.json",
        dict(review=binding, rows=rows, summary=result, driver=reference(__file__)),
    )
    for field in keys:
        print(
            field,
            result[field]["values"],
            result[field]["differences"]["Continuing-wire loss vs Aligned control"],
            flush=True,
        )


if __name__ == "__main__":
    main()
