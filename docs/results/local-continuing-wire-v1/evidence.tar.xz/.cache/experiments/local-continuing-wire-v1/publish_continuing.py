"""Bind the two completed endpoints and their measured and viewed comparisons."""

import argparse
from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS, IMAGES = (Path("docs") / kind / ROOT.name for kind in ("results", "images"))
ARMS = ("wire-aligned", "strong-gap")


def load_trace(binding):
    with checked(binding).open() as stream:
        return list(map(json.loads, stream))


def audit_training():
    phases = {
        phase: reference(ROOT / phase / "completed.json") for phase in ("training", "qualification")
    }
    completed, qual = (read_json(checked(phases[phase])) for phase in phases)
    assert not completed["qualification"] and qual["qualification"]
    assert completed["parent"] == qual["parent"] and completed["plan"] == qual["plan"]
    study = read_json(checked(completed["plan"]))
    prior = read_json(checked(study["comparison_completion"]))
    parent = read_json(checked(study["parent_completion"]))
    previous = read_json(checked(parent["plan"]))
    original = read_json(checked(previous["parent_completion"]))
    assert (
        parent["checkpoints"]["repeat"] == prior["parent"] == study["parent"] == completed["parent"]
    )
    assert all(p["DINO_unchanged"] for p in (completed, qual, prior, parent, original))
    assert set(study["mode_weights"]) == set(ARMS)
    checked(completed["parent"])
    forbidden = set()
    for earlier in (prior, parent, original):
        binding = read_json(checked(earlier["plan"]))
        for key in ("schedule", "qualification_schedule"):
            forbidden.update(r["source"]["id"] for r in read_json(checked(binding[key])))
    recipes = {}
    for stage, state, key, budget in (
        ("qualification", qual, "qualification_schedule", 8),
        ("training", completed, "schedule", 320),
    ):
        assert (
            state["native_observations_per_arm"] == 6 * budget
            and state["updates_per_arm"] == state["source_photos_per_arm"] == budget
        )
        for cp in state["checkpoints"].values():
            checked(cp)
        rows = read_json(checked(study[key]))
        trace = load_trace(state["observations"])
        scores = load_trace(state["log"])
        assert len(rows) == len(trace) == len(scores) == budget
        distribution = Counter()
        shapes = Counter()
        known = set()
        for row, witness, loss in zip(rows, trace, scores, strict=True):
            ident = row["source"]["id"]
            assert ident == witness["source_id"] and ident not in known and ident not in forbidden
            known.add(ident)
            assert (
                witness["cache_sha256"] == row["source"]["cache_sha256"]
                and len(set(witness["seeds"].values())) == 8
            )
            key = (row["kind"], row["iso"], row["pattern"], row["law"])
            assert key == (
                witness["kind"],
                witness["iso"],
                witness["camera"]["pattern"],
                witness["law"],
            )
            distribution[key] += 1
            wire = "wire" in witness["geometry"]
            if wire:
                continues = row["strong_continues"]
                assert witness["geometry"]["wire"]["strong_continues"] == continues
                shapes[continues] += 1
                distribution[key + (continues,)] += 1
            for arm in ARMS:
                assert np.isfinite(list(loss[arm].values())).all()
                assert ("aligned_loss" in loss[arm]) == ("strong_gap_loss" in loss[arm]) == wire
                assert loss[arm]["paired"] == loss[arm]["mean_loss"]
        forbidden.update(known)
        assert dict(shapes) == (
            {True: 2, False: 2} if stage == "qualification" else {True: 128, False: 32}
        )
        if stage == "training":
            assert sum(len(cell) == 4 for cell in distribution) == 32
            assert all(
                n == (10 if len(cell) == 4 else 8 if cell[4] else 2)
                for cell, n in distribution.items()
            )
        recipes[stage] = dict(
            continued=shapes[True],
            double_gap=shapes[False],
            paired_core_values_valid=state["valid_core_pairs"],
        )
    return completed | dict(
        qualified=phases["qualification"],
        receipt=phases["training"],
        recipes=recipes,
        comparison_completion=study["comparison_completion"],
        source_disjoint_from_previous_schedules=True,
        matched_observations_verified=True,
    )


def publish_board(board):
    source = checked(board["image"])
    destination = IMAGES / source.parent.name / source.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert reference(destination)["sha256"] == board["image"]["sha256"]
    board["image"]["path"] = str(destination.relative_to(IMAGES))
    with Image.open(destination) as f:
        pixels = np.asarray(f.convert("RGB"))
    crops = {}
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert w == h == 160
        crops[panel.get("name", panel.get("label"))] = pixels[y : y + h, x : x + w]
    return crops


def publish(training):
    native_ref = reference(ROOT / "review/result.json")
    native = read_json(checked(native_ref))
    double_ref = reference(ROOT / "review/double-gap.json")
    double = read_json(checked(double_ref))
    replay_ref = reference(ROOT / "review/wire-transfer.json")
    repeats = read_json(checked(replay_ref))
    directions_ref = reference(ROOT / "review/gap-directions.json")
    gaps = read_json(checked(directions_ref))
    assert native["endpoint"] == double["endpoint"] == repeats["endpoint"] == training["receipt"]
    assert len(double["rows"]) == len(repeats["rows"]) == 16 and len(gaps["rows"]) == 12
    assert gaps["review"] == native_ref
    assert read_json(checked(double["inputs"]))["study"] == training["plan"]
    scores = reference(ROOT / "viewing-notes.json")
    notes = read_json(checked(scores))
    for key in ("exact", "standing"):
        assert set(notes[key]) == {i["id"] for i in native[key]}
    for crop in native["exact"]:
        all_pixels = publish_board(crop["board"])
        triplet = publish_board(crop["triplet"])
        assert list(triplet) == ["Noisy Malvar", "Continuing-wire loss", "Exact GT"]
        assert all(np.array_equal(all_pixels[k], v) for k, v in triplet.items())
    for crop in native["standing"]:
        all_pixels = publish_board(crop["board"])
        assert {
            "Repeat parent",
            "Prior aligned wire",
            "Aligned control",
            "Continuing-wire loss",
            "ISO100 AHD reference",
        } <= set(all_pixels)
        if crop["id"].startswith("mesh-"):
            assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= set(all_pixels)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        dict(
            weights="EMA",
            precision=native["precision"],
            native=native_ref,
            models=training["checkpoints"],
            parent=training["parent"],
            ISO100_reference="Independent capture and demosaicing. Qualitative reference.",
            exact=native["exact"],
            standing=native["standing"],
            viewing_notes=scores,
            viewed_local=datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        ),
    )
    RESULTS.mkdir(parents=True, exist_ok=True)
    audit = RESULTS / "training.json"
    write_json(audit, training)
    plan = read_json(checked(training["plan"]))
    qualification = read_json(checked(training["qualified"]))
    raw_gap = reference(ROOT / "raw-gap-evidence.json")
    assert read_json(checked(raw_gap))["inputs"] == double["inputs"]
    raw_published = RESULTS / "raw-gap-evidence.json"
    shutil.copyfile(checked(raw_gap), raw_published)
    assert reference(raw_published)["sha256"] == raw_gap["sha256"]
    mixes = reference(ROOT / "review/matched-mixtures.json")
    assert read_json(checked(mixes))["frozen_input"] == native_ref
    mi = RESULTS / "matched-mixtures.json"
    shutil.copyfile(checked(mixes), mi)
    assert reference(mi)["sha256"] == mixes["sha256"]
    background = reference(ROOT / "review/background-strata.json")
    assert read_json(checked(background))["neural"] == double_ref
    archive = RESULTS / "evidence.tar.xz"
    inputs = [
        native_ref,
        double_ref,
        replay_ref,
        directions_ref,
        double["inputs"],
        raw_gap,
        mixes,
        background,
        scores,
        training["receipt"],
        training["plan"],
        plan["schedule"],
        plan["qualification_schedule"],
        plan["driver"],
        training["observations"],
        training["log"],
        training["qualified"],
        qualification["observations"],
        qualification["log"],
        *(reference(p) for p in sorted(ROOT.glob("*.py"))),
        *(
            reference(ROOT / p)
            for p in (
                "training.log",
                "qualification.log",
                "review_continuing.log",
                "double_gap.log",
                "wire_transfer.log",
            )
        ),
    ]
    external = checked(training["receipt"]).resolve().parent.parent
    with tarfile.open(archive, "x:xz", preset=4) as out:
        for binding in inputs + [reference(audit)]:
            p = checked(binding).resolve()
            name = (
                p.relative_to(Path.cwd())
                if p.is_relative_to(Path.cwd())
                else Path("external") / p.relative_to(external)
            )
            out.add(p, arcname=name, recursive=False)
    write_json(
        RESULTS / "publication.json",
        dict(
            training=reference(audit),
            archive=reference(archive),
            manifest=reference(manifest),
            models=training["checkpoints"],
            parent=training["parent"],
            training_seconds=training["training_seconds"],
            evaluation_seconds=dict(
                native=native["seconds"],
                double_gap=double["seconds"],
                wire_transfer=repeats["seconds"],
            ),
            reviews=dict(
                native_metrics_complete=True,
                wire_transfer_and_double_gap_complete=True,
                native_image_view_complete=True,
                fixed_427_complete=False,
            ),
            exact_results={k: g["summary"] for k, g in native["groups"].items()},
            double_gap=double["summary"],
            wire_transfer=repeats["summary"],
            gap_directions=gaps["summary"],
            raw_gap_evidence=reference(raw_published),
            matched_mixtures=reference(mi),
            background_strata=read_json(checked(background))["cohorts"],
            standing={r["id"]: r["rms_vs_parent_DN16"] for r in native["standing"]},
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()
    audited = audit_training()
    if args.audit_only:
        print(audited["recipes"], audited["training_seconds"], flush=True)
    else:
        publish(audited)
