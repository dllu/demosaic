"""Replay the previous independent wire panel with the new matched endpoints."""

from collections import defaultdict
import sys
import time

import numpy as np
import torch

from review_continuing import EARLIER, LABELS, PARENT, PRIOR, ROOT, compare, metrics
from review_redraw_average import restore
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

sys.path.insert(0, str(PRIOR))
from score_wire_redraws import decompose, metric_for_wire


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    baseline = reference(PRIOR / "review/wire-redraw.json")
    old = read_json(checked(baseline))
    panel = read_json(checked(old["inputs"]))
    endpoint = reference(ROOT / "training/completed.json")
    run = read_json(checked(endpoint))
    recipe = read_json(checked(run["plan"]))
    assert recipe["comparison_completion"] == old["endpoint"]
    old_parent = read_json(checked(old["parent_replay"]))
    assert old_parent["models"] == {PARENT: run["parent"]}
    training = {
        r["source"]["id"]
        for k in ("schedule", "qualification_schedule")
        for r in read_json(checked(recipe[k]))
    }
    assert training.isdisjoint(case["source"]["source"]["id"] for case in panel["rows"])
    assert len(panel["rows"]) == 16
    original = {r["case"]["source"]["index"]: r for r in old["rows"]}
    models = {}
    for key, ref in run["checkpoints"].items():
        model, state = load_scene_checkpoint(
            checked(ref), weights="ema", expected_sha256=ref["sha256"]
        )
        assert state["continued_from"] == run["parent"] and state["training_arm"] == key
        models[LABELS[key]] = _stage_tiled_cuda(model.eval(), "cuda")
    start = time.monotonic()
    rows = []
    for case in panel["rows"]:
        before = original[case["source"]["index"]]
        assert before["case"] == case
        renders = defaultdict(list)
        for draw in case["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as stream:
                data = {k: stream[k] for k in stream.files}
            assert {k: fingerprint(data[k]) for k in case["target_fingerprints"]} == case[
                "target_fingerprints"
            ]
            assert fingerprint(data["packed"]) == draw["packed"]
            for name, model in models.items():
                values, _ = restore(model, data, panel["profile"])
                renders[name].append(values)
        metric = metric_for_wire(data, case["source"]["geometry"])
        scores = {PARENT: before["scores"][PARENT], EARLIER: before["scores"]["Aligned wire"]}
        for name, values in renders.items():
            report = decompose(np.stack(values), data, metric)
            statistics = [metrics(case, array, data) for array in values]
            for field in (
                "exact_flat_RMS_DN16",
                "gap_RMS_DN16",
                "gap_weak_RMS_DN16",
                "flat_chroma_RMS_DN16",
            ):
                numeric = [r[field] for r in statistics if r.get(field) is not None]
                if numeric:
                    report[field] = float(np.mean(numeric))
            np.testing.assert_allclose(
                report["weak_response_pp"],
                np.mean([value["weak_response_pp"] for value in statistics]),
                rtol=1e-8,
            )
            scores[name] = report
        rows.append(dict(case=case, scores=scores))
        print("wire redraws scored", len(rows), flush=True)
    keys = sorted({k for row in rows for k in row["scores"][PARENT]})
    write_json(
        ROOT / "review/wire-transfer.json",
        dict(
            inputs=old["inputs"],
            endpoint=endpoint,
            reference=baseline,
            rows=rows,
            summary=compare([r["scores"] for r in rows], keys),
            seconds=time.monotonic() - start,
            weights="EMA",
            precision="CUDA IEEE FP32",
            driver=reference(__file__),
        ),
    )


if __name__ == "__main__":
    main()
