"""Compute exact-gap residuals after replacing only the measured continuing component."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def main():
    native = reference(ROOT / "review/result.json")
    bands = reference(ROOT / "review/gap-directions.json")
    data = read_json(checked(native))
    phases = read_json(checked(bands))
    assert phases["review"] == native
    by_source = {
        r["source"]["source"]["id"]: r for r in data["groups"]["wire"]["rows"] if r["gap_pixels"]
    }
    sources = []
    for row in phases["rows"]:
        local = by_source.pop(row["source"])
        assert local["input"] == row["input"]
        old, new = (row["scores"][m] for m in ("Aligned control", "Continuing-wire loss"))
        control, full, parent = (
            local["scores"][m]["gap_RMS_DN16"]
            for m in ("Aligned control", "Continuing-wire loss", "Repeat parent")
        )
        parts = dict(aligned_control=control, full_continuing=full, repeat_parent=parent)
        for key, field in (
            ("replace_strong_band", "strong_error_DN16_squared"),
            ("replace_only_aligned_strong", "aligned_error_DN16_squared"),
        ):
            parts[key] = float(np.sqrt(control * control - old[field] + new[field]))
        sources.append(dict(source=row["source"], gap_RMS_DN16=parts))
    assert not by_source and len(sources) == 12
    bootstrap = np.random.default_rng(202611191401).integers(12, size=(8000, 12))
    summary = {}
    all_values = {
        name: np.array([c["gap_RMS_DN16"][name] for c in sources])
        for name in sources[0]["gap_RMS_DN16"]
    }
    for name, values in all_values.items():
        change = values - all_values["aligned_control"]
        parent = values - all_values["repeat_parent"]
        summary[name] = dict(
            mean_RMS_DN16=float(values.mean()),
            delta_vs_control=float(change.mean()),
            interval_vs_control=np.quantile(change[bootstrap].mean(1), [0.025, 0.975]).tolist(),
            delta_vs_repeat_parent=float(parent.mean()),
            interval_vs_repeat_parent=np.quantile(
                parent[bootstrap].mean(1), [0.025, 0.975]
            ).tolist(),
        )
    dest = Path("docs/results/local-continuing-wire-v1/continuing-component-bound.json")
    write_json(
        dest,
        dict(
            native=native,
            frequency_scores=bands,
            source=reference(__file__),
            rows=sources,
            summary=summary,
            scope="Hypothetical replacement of the measured continuing component. Uses the clean target and exact gap shape. All other gap error terms keep their aligned-control values.",
        ),
    )
    print(summary, flush=True)


if __name__ == "__main__":
    main()
