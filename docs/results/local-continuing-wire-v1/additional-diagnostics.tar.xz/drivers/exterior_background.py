"""Test whether a disjoint RAW annulus improves estimated backgrounds inside wire gaps."""

from pathlib import Path
import math

import numpy as np
import torch

from demosaic.cfa import mosaic, unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def geometry(wire):
    y, x = np.indices((256, 256), dtype=float) - 127.5
    dx, dy = x - wire["gap_center"][0], y - wire["gap_center"][1]
    a, b = wire["gap_axes"]
    c, s = math.cos(wire["gap_angle"]), math.sin(wire["gap_angle"])
    r = np.hypot((c * dx + s * dy) / a, (-s * dx + c * dy) / b)
    carriers = []
    for theta, period, phase, width in zip(
        wire["angles"], wire["periods"], wire["phases"], wire["widths"], strict=True
    ):
        u = (math.cos(theta) * x + math.sin(theta) * y) / period + phase
        carriers.append(
            np.exp(-0.5 * ((u - np.rint(u)) / width) ** 2) - math.sqrt(math.tau) * width
        )
    carriers[1] *= np.clip((105 - np.maximum(np.abs(x), np.abs(y))) / 28, 0, 1)
    masks = r < 1, (r >= 1.42) & (r <= 2.25)
    parity = np.indices((256, 256))
    phase = 2 * (parity[0] % 2) + (parity[1] % 2)
    cfa = np.eye(4)[phase]
    quarter = ((parity[0] // 2) % 2) * 2 + (parity[1] // 2) % 2
    return dx / (2 * a), dy / (2 * b), cfa, carriers, masks, quarter


def design(x, y, cfa, channels, degree):
    components = [np.ones_like(x), x, y]
    if degree == 2:
        components.extend((x * x, x * y, y * y))
    baseline = np.concatenate([cfa * p[..., None] for p in components], axis=-1)
    nuisance = np.concatenate([cfa * p[..., None] for p in channels], axis=-1)
    return baseline, np.concatenate((baseline, nuisance), axis=-1)


def analyze(data, record, profile):
    x, y, cfa, carriers, (gap, fit), quarter = geometry(record["geometry"])
    raw = unpack(torch.from_numpy(data["packed"]))[:2, 0].numpy().astype(float)
    target = (
        unpack(mosaic(torch.from_numpy(data["target"]), torch.from_numpy(data["colors"])))[:2, 0]
        .numpy()
        .astype(float)
    )
    assert np.array_equal(target[0, fit], target[1, fit])
    sig = target[0, gap] - target[1, gap]
    var = profile["shot"] * target[:, gap].mean(0) + profile["read"]
    direction = sig / var
    norm = sig @ direction
    assert norm > 0
    output = {}
    noise_std = np.sqrt(profile["shot"] * np.maximum(raw, 0) + profile["read"])
    for label, form in (("affine", 1), ("quadratic", 2)):
        baseline, expectation = design(x, y, cfa, carriers, form)
        values = []
        checks = []
        for arr, scale in zip(raw, noise_std, strict=True):
            dev = fit & (quarter != 3)
            witness = fit & (quarter == 3)
            coef = np.linalg.lstsq(
                expectation[dev] / scale[dev, None], arr[dev] / scale[dev], rcond=None
            )[0]
            checks.append(
                float(np.mean(((arr[witness] - expectation[witness] @ coef) / scale[witness]) ** 2))
            )
            # Refit on the complete exterior after the disjoint model-order check.
            coef = np.linalg.lstsq(
                expectation[fit] / scale[fit, None], arr[fit] / scale[fit], rcond=None
            )[0]
            bg = baseline[gap] @ coef[: baseline.shape[-1]]
            values.append(float((arr[gap] - bg) @ direction / norm))
        output[label] = dict(inferred_amplitude=values, exterior_validation_MSE=checks)
    chosen = [
        min(output, key=lambda label: output[label]["exterior_validation_MSE"][i]) for i in range(2)
    ]
    output["selected"] = dict(
        inferred_amplitude=[
            output[label]["inferred_amplitude"][i] for i, label in enumerate(chosen)
        ],
        chosen=chosen,
    )
    output["outside_pixels"] = int(fit.sum())
    return output


def main():
    torch.set_num_threads(2)
    bound = reference(ROOT / "double-gap-inputs/panel.json")
    panel = read_json(checked(bound))
    rows = []
    for row in panel["rows"]:
        views = []
        for draw in row["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                vals = {k: f[k] for k in f.files}
            views.append(analyze(vals, row, panel["profile"]))
        rows.append(dict(source=row["source"]["id"], draws=views))
    summary = {}
    for name in ("affine", "quadratic", "selected"):
        found = np.array([v[name]["inferred_amplitude"] for row in rows for v in row["draws"]])
        summary[name] = dict(
            true_positive=int((found[:, 0] > 0.5).sum()),
            false_positive=int((found[:, 1] > 0.5).sum()),
            per_condition=len(found),
            median_continuing=float(np.median(found[:, 0])),
            median_interrupted=float(np.median(found[:, 1])),
        )
    print(summary, flush=True)
    write_json(
        ROOT / "exterior-background.json",
        dict(
            inputs=bound,
            driver=reference(__file__),
            summary=summary,
            rows=rows,
            threshold=0.5,
            scope="Diagnostic with exact wire waveform and support. Fit background and both known carriers on a disjoint Bayer annulus and score the still-independent interior samples. Select background order on held-out exterior samples. Common inner noise weighting uses simulated calibration.",
        ),
    )


if __name__ == "__main__":
    main()
