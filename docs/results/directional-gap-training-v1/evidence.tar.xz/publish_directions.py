"""Publish native image comparisons and byte-exact method and measurement receipts."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name


def read(name):
    return json.loads((ROOT/name).read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def reference(path):
    return {"path":str(path),"sha256":sha(path)}


def check(record, local=None):
    assert sha(Path(record["path"]) if local is None else local)==record["sha256"], record


def write(path, record):
    path.write_text(json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)+"\n")


def transfer(entry, directory):
    binding=entry["image"]
    original=Path(binding["path"])
    path=IMAGES/directory/original.name
    path.parent.mkdir(parents=True,exist_ok=True)
    check(binding)
    shutil.copyfile(original,path)
    check(binding,path)
    binding["path"]=path.relative_to(IMAGES).as_posix()
    with Image.open(path) as im:
        pieces={}
        for panel in entry["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160)
            assert 0<=x<=im.width-w and 0<=y<=im.height-h
            pieces[panel.get("label") or panel["name"]]=im.crop((x,y,x+w,y+h))
        assert len(pieces)==len(entry["panels"])
    return pieces


def review(training, pointer):
    manifests={}
    for directory,n in (("exact",3),("standing",8),("flat",2)):
        data=read(directory+"/manifest.json")
        assert data["checkpoint"]==training["checkpoint"] and data["parent"]==training["parent"] and len(data["rows"])==n
        assert data.get("training",data.get("weights"))==pointer
        check(data["driver"])
        for row in data["rows"]:
            frames=transfer(row["board"],directory)
            if directory=="standing":
                continue
            for trio in (row["triplet"],*row.get("other_triplets",{}).values()):
                pages=transfer(trio,directory)
                assert len(pages)==3
                for name,img in pages.items():
                    assert ImageChops.difference(img,frames[name]).getbbox() is None
        manifests[directory]=data
    manifests["native_image_review"]={
        "completed":True,"standing":8,"exact_comparisons":3,"exact_triplets":9,"flat_comparisons":2,"flat_triplets":2,
        "notes":"The sky and exact-flat cores look smooth. The coarse fence stays coherent. Fine building and foliage stay soft. The nominal right cab has stronger existing diagonals with directional training. The nominal left is faint and mottled, and the transferred profile resembles the previous conditional blend. Fine crossings remain incomplete."
    }
    output=IMAGES/"manifest.json"
    write(output,manifests)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":sha(output)}


def archive(name, files):
    path=OUT/name
    names=sorted(files)
    with tarfile.open(path,"w:xz",preset=5)as bundle:
        for key in names:
            bundle.add(files[key],arcname=key,recursive=False)
    with tarfile.open(path)as bundle:
        assert bundle.getnames()==names
        for key in names:
            with bundle.extractfile(key)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==sha(files[key])
    return {"path":name,"sha256":sha(path),"entries":len(files)}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    bound=ROOT/"training/completed.json"
    completed=read("training/completed.json")
    pointer=reference(bound)
    for name in ("driver","checkpoint","features","directions","frozen_phase_checkpoint","parent","prior_training"):
        check(completed[name])
    endpoint=completed["checkpoint"]
    upstream={}
    for label,files in {
        "phase-correction-mixture-v1": ("mixture.py","train_mixture.py","evaluate_mixture_matched.py","training/completed.json"),
        "phase-activity-v1":("activity.py",),
        "phase-edge-validation-v1":("phase_edge.py","edge_choices.py","audit_edge.py"),
        "quiet-parent-phase-v1":("quiet_heads.py","calibrate_components.py","review_quiet.py","native_quiet.py"),
        "local-phase-envelope-v1":("gap_projection.py",),
        "learned-spectral-gaps-v1":("plan.json","train_gap_head.py","evaluate_gap_head.py"),
    }.items():
        upstream |= {f"upstream/{label}/{name}":ROOT.parent/label/name for name in files}
    upstream["upstream/phase_witness.py"]=Path("src/demosaic/phase_witness.py")
    records=[
        "direction.py","train_directions.py","evaluate_directions.py","render_directions.py",
        "flat_directions.py","audit_directions.py","publish_directions.py",
        "directions.json","training/completed.json",f"training/{Path(endpoint['path']).name}",
        "exact/manifest.json","standing/manifest.json","flat/manifest.json","tests.log","audit.json"
    ]
    summaries={}
    for panel,size,tune in (("photo",256,16),("wire",48,24)):
        for scope,count in (("holdout",size),("calibration",tune)):
            name=f"{panel}-{scope}.json"
            receipt=read(name)
            assert len(receipt["rows"])==count and receipt["training"]==pointer
            assert receipt["checkpoint"]==endpoint and receipt["parent"]==completed["parent"]
            check(receipt["driver"])
            records.append(name)
            if scope=="holdout":
                summaries[panel]=receipt["reports"]["iso6400/independent"if panel=="photo"else "iso6400"]
    prepared=review(completed,pointer)
    result=archive("evidence.tar.xz",{p:ROOT/p for p in records}|upstream)
    write(OUT/"publication.json",{
        "experiment":ROOT.name,"parent":completed["parent"],"frozen_crop_component":completed["frozen_phase_checkpoint"],
        "checkpoint":{"member":f"training/{Path(endpoint['path']).name}","sha256":endpoint["sha256"]},
        "training":{k:completed[k]for k in ("seconds","photos","updates_per_head","visits_per_head",
                           "queries_per_head","epochs","seed","EMA","optimizer","arms","experts","gradient_match",
                           "calibration_seconds")},
        "weights":"EMA for all reported primary comparisons; raw weights and their numerical results are archived.",
        "training_complete":True,"scoped_numerical_evaluation_complete":True,"native_image_review_complete":True,
        "fixed_427_photo_and_camera_panels":"Outside this crop component study",
        "evidence":result,"presentation":prepared,"summary":summaries,
    })
    print("Verified model, matched numeric replays, archives and native pixels.")


if __name__=="__main__":
    main()
