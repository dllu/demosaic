"""Verify the projected loss and reproduce the old whole-gap control."""
import numpy as np
import torch

from direction import ROOT,FABRIC,COORD,WINDOW,COMPONENTS,FIELDS,axes,orth,projectors,map_basis
from head_corrected_broad import NATIVE_I,NATIVE_J,SYNTH
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    rng=np.random.default_rng(99071)
    y,x=np.indices(SYNTH.shape)
    mask=(((x-15)/10)**2+((y-16)/9)**2<1).ravel()
    a=np.array([[.113,.042],[.226,.084]])
    b=np.array([[.057,-.153],[.114,-.306],[.17,-.111],[.056,.195]])
    strong,weak=axes(a),axes(b)
    lead,faint=projectors(mask,strong,weak)
    both=np.column_stack((lead,faint))
    np.testing.assert_allclose(both.T@both,np.eye(both.shape[1]),atol=5e-14,rtol=0)
    maximum=float(abs(faint.T@(strong[mask]*WINDOW[mask,None])).max())
    assert maximum<2e-12
    records=[]
    for seed in range(8):
        form=(rng.normal(size=(len(NATIVE_I),2))*.01).astype(np.float32)
        complex_value=form[:,0]+1j*form[:,1]
        plane=np.zeros(SYNTH.shape,dtype=np.complex64)
        plane[NATIVE_I,NATIVE_J]=complex_value
        plane[-NATIVE_I,-NATIVE_J]=complex_value.conj()
        wave=2*np.fft.ifft2(plane,norm="ortho").real.ravel()
        for name,q in (("weak",faint),("strong",lead)):
            want=q.T@(wave[mask]*WINDOW[mask])
            actual=map_basis(q,mask,q.shape[1])@form.ravel()
            np.testing.assert_allclose(actual,want,atol=3e-8,rtol=0)
            reduced=map_basis(q,mask,q.shape[1]).astype(np.float16).astype(np.float32)@form.ravel()
            np.testing.assert_allclose(reduced,want,atol=4e-5,rtol=0)
            records.append(float(abs(reduced-want).max()))
    marker=reference(ROOT/"training/completed.json")
    trained=read_json(checked(marker))
    model=torch.load(checked(trained["checkpoint"]),weights_only=True,map_location="cpu")
    first=read_json(checked(trained["prior_training"]))
    old=torch.load(checked(first["checkpoint"]),weights_only=True,map_location="cpu")
    changes={}
    for version in ("raw","EMA"):
        newest=model[version]["whole-gap"]
        prior=old[version]["gap-supervised"]
        assert newest.keys()==prior.keys()
        delta=max(float((v-prior[k]).abs().max())for k,v in newest.items())
        changes[version]=delta
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"training":marker,"checkpoint":trained["checkpoint"],
        "projection_FP16_max_error":max(records),"weak_projection_of_strong_max_abs":maximum,
        "whole_gap_reproduction_max_abs_weights":changes,"diagnostic":"Quantized coefficient projector compared with direct weighted pixel-space dot products."})
    print(max(records),changes,flush=True)
if __name__=="__main__":
    main()
