"""Review direction-separated training on unchanged exact and real native crops."""
import sys

import numpy as np
import torch

from direction import ROOT, FABRIC
from mixture import PRIOR, inputs, combine
from evaluate_directions import load
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from native_quiet import native_board, native_png, raw_full, original_panels
from review_quiet import SCENE, LOCAL, photo_inputs, wire_inputs
import evaluate_gap_head as review

CAPTIONS = {
    "Bayer-gated": "Bayer-gated refit",
    "local_power": "Local power",
    "conditional": "Conditional blend",
    "whole-gap": "Whole-gap training",
    "weak-gap": "Weak-band gap loss",
    "directional": "Directional training",
}


def render_models(mosaic, pattern, wb, matrix, noise, box, exterior, parent, models, _unused=None):
    component,nets=models
    donors=review.exterior(exterior,pattern,noise,box)
    field,_,frozen,experts,desc=inputs(mosaic,pattern,noise,box,donors,parent,wb,matrix,component)
    rows=combine(nets,field,frozen,experts,desc)
    return {k:parent+rows[k]for k in CAPTIONS}


def json_binding(path):
    marker=reference(path)
    return marker,read_json(checked(marker))


def standing(model, receipt, policies):
    previous, previous_board = json_binding(PRIOR/"standing/manifest.json")
    _, book = json_binding(SCENE/"review-native-020000/work/render/result.json")
    source = read_json(checked(book["collections"]["none"]))
    _,cfg = json_binding("configs/gfx-green-mesh-20231231.json")
    plans = {r["id"]:r for r in read_json(checked(book["plan"]))["observations"]}
    entries = {r["id"]:r for r in source["records"]}
    old = {r["id"]:r for r in previous_board["rows"]}
    assert source["checkpoint"] == receipt["parent"] == previous_board["local_parent_checkpoint"]
    out=ROOT/"standing"
    out.mkdir()
    rows=[]
    for kind in ("main","mesh"):
        boards=[r for r in book["boards"] if r["id"].startswith(kind+"-")]
        raw_stamp=old[boards[0]["id"]]["raw"]
        full, cfa=raw_full(raw_stamp)
        for spec in boards:
            name=spec["id"]
            baseline=old[name]
            observation=plans[spec["observation"]]
            local=entries[spec["observation"]]
            assert baseline["raw"]==raw_stamp and baseline["input"]==observation["arrays"]
            assert baseline["noise"]==spec["noise"]==observation["noise"]
            if kind=="main":
                origin=observation["metadata"]["context_xywh"][:2]
            else:
                origin=cfg["raw_context_xywh"][:2]
            box=baseline["native_box"]
            ox,oy=box[0]-origin[0],box[1]-origin[1]
            roi=baseline["roi"]
            x,y=roi[:2]
            assert list(spec["case"]["ROI_xywh"]) == [ox+x,oy+y,160,160]
            with np.load(checked(observation["arrays"]),allow_pickle=False) as data:
                profile={key:data[key] for key in ("packed","colors","wb","matrix")}
            for key,value in profile.items():
                assert fingerprint(value)==local["input_fingerprints"][key]
            view=profile["packed"][0,:,oy//2:oy//2+128,ox//2:ox//2+128]
            np.testing.assert_array_equal(profile["colors"][0],cfa)
            bx,by=box[:2]
            np.testing.assert_array_equal(view,full[:,by//2:by//2+128,bx//2:bx//2+128])
            parent=np.load(checked(local["prediction"]),allow_pickle=False)[0,:,oy:oy+256,ox:ox+256]
            predictions=render_models(view,cfa,profile["wb"][0],profile["matrix"][0],spec["noise"],box,full,parent,model,policies)
            with np.load(checked(baseline["predictions"]),allow_pickle=False) as prior:
                np.testing.assert_array_equal(parent,prior["parent"][0])
                np.testing.assert_allclose(predictions["Bayer-gated"],prior["witness-gated"][0],atol=1e-7,rtol=0)
            panels=original_panels(spec)
            balance,conversion=(torch.from_numpy(profile[k]) for k in ("wb","matrix"))
            def shown(values):
                display=display_crop(torch.from_numpy(values[None]),balance,conversion,roi,exposure=spec["display_exposure"])
                return np.rint(display.clip(0,1)*255).astype(np.uint8)
            np.testing.assert_array_equal(shown(parent),panels["Local-only 20k EMA"])
            begin=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Local-only 20k EMA")
            end=("ISO100 AHD reference","ISO100 camera JPEG")
            images=[(k,panels[k]) for k in begin if k in panels]
            images += [(CAPTIONS[key],shown(pred)) for key,pred in predictions.items()]
            images += [(k,panels[k]) for k in end if k in panels]
            board=native_png(out/(name+".png"),images)
            region=np.s_[...,y:y+160,x:x+160]
            scored={k:float(np.sqrt(np.mean((v[region].astype(np.float64)-parent[region])**2))*65535)
                    for k,v in predictions.items()}
            rows.append({k:baseline[k] for k in ("id","raw","input","parent","display_exposure","roi","native_box","noise")}
                        | {"board":board,"camera_RGB_RMS_DN16":scored,"matched_display":spec["image"]})
            print(name,scored,flush=True)
        del full
    write_json(out/"manifest.json",receipt|{"rows":rows,"prior_native":previous})


def exact(model, receipt, policies):
    prior,manifest=json_binding(PRIOR/"exact-final/manifest.json")
    archive=read_json(checked(manifest["natural_observations"]))["records"]
    wire=read_json(checked(manifest["wire_predictions"]))
    plan=read_json(checked(wire["plan"]))
    plans=read_json(checked(wire["inputs"]))["rows"]
    saves={r["id"]:r for r in wire["rows"]}
    control=read_json(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")
    lookup={r["input"]["sha256"]:r for r in control["rows"]}
    out=ROOT/"exact"
    out.mkdir()
    rows=[]
    for row in manifest["rows"]:
        name=row["id"]
        if name.endswith("independent"):
            entry=next(p for p in archive if p["path"].endswith(name+".json"))
            request, data, predictions, ref=photo_inputs(entry)
            exterior=data["scene_packed"]
            assert row["input"]==request["input"] and row["local_parent"]==ref
        else:
            index=int(name.split("-")[0])
            entry=next(value for value in plans if (value["index"],value["noise"])==(index,"iso6400"))
            data,predictions,ref=wire_inputs(entry,saves,lookup)
            exterior=data["full"]
            assert row["input"]==entry["input"] and row["local_parent"]==ref and row["query"]==plan["query"]
        sample={key:data[key][:1] for key in ("packed","colors","wb","matrix")}
        known=predictions[LOCAL][0]
        noisy=noisy_malvar(sample)[0]
        gt=data["target"][0]
        variants=render_models(*(sample[key][0] for key in ("packed","colors","wb","matrix")),
               row["noise"],row["query"],exterior,known,model,policies)
        fixed=["Noisy Malvar","V120 EMA","Corpus 100k EMA","Local 20k EMA"]
        images=[noisy,predictions["V120"][0],predictions["100k"][0],known]
        labels=fixed+[CAPTIONS[k] for k in variants]+["Exact GT"]
        previous={p["label"]:p for p in row["board"]["panels"]}
        binding={k:row[k] for k in ("source","input","noise","query","CFA","local_parent")}
        for key in ("family","source_box"):
            if key in row:
                binding[key]=row[key]
        exposure=row["display_exposure"]
        contrast=row["display_contrast"]
        main=native_board(out,name,[*images,*variants.values(),gt],sample,binding,labels=labels,
                  exposure=exposure,contrast=contrast,triplet_indices=(0,labels.index(CAPTIONS["directional"]),len(labels)-1))
        from PIL import Image
        with Image.open(checked(row["board"]["image"])) as earlier, Image.open(checked(main["board"]["image"])) as later:
            for panel in main["board"]["panels"]:
                label=panel["label"]
                if label not in previous:
                    continue
                def extract(frame, record):
                    x,y,w,h=record["png_xywh"]
                    return np.asarray(frame.crop((x,y,x+w,y+h)))
                now, old=extract(later,panel),extract(earlier,previous[label])
                if label=="Bayer-gated refit":
                    assert np.max(abs(now.astype(int)-old))<=1
                else:
                    np.testing.assert_array_equal(now,old)
        smaller={}
        for key in ("whole-gap","weak-gap"):
            single=native_board(out,name+"-"+key,[noisy,variants[key],gt],sample,binding,
                 labels=("Noisy Malvar",CAPTIONS[key],"Exact GT"),exposure=exposure,contrast=contrast,triplet_indices=(0,1,2))
            smaller[key]=single["triplet"]
        rows.append(main|{"other_triplets":smaller})
        print(name,flush=True)
    write_json(out/"manifest.json",receipt|{"rows":rows,"prior_exact":prior})


if __name__=="__main__":
    torch.set_num_threads(1)
    models,fit,endpoint=load(raw_weights=False)
    receipt={"driver":reference(__file__),"training":fit,"parent":endpoint["parent"],
             "checkpoint":endpoint["checkpoint"],"frozen_phase":endpoint["frozen_phase_checkpoint"],
             "policies":list(CAPTIONS)}
    {"standing":standing,"exact":exact}[sys.argv[1]](models,receipt,None)
