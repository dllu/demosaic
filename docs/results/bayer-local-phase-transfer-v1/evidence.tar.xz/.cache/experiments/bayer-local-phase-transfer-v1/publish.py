"""Bind phase-transfer numbers, provenance and native output panels."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path("docs/results") / ROOT.name
IMAGES = Path("docs/images") / ROOT.name
PRIOR = Path("docs/images/bayer-local-deficit-v1")


def cells(path, spec):
    with Image.open(path) as image:
        pixels = np.asarray(image.convert("RGB"))
    panels = {}
    for panel in spec["panels"]:
        x, y, w, h = panel["png_xywh"]
        crop = pixels[y:y+h, x:x+w]
        assert crop.shape == (h, w, 3) == (160, 160, 3)
        panels[panel.get("label", panel.get("name"))] = crop
    return panels


def publish_board(spec, subfolder):
    source = checked(spec["image"])
    dest = IMAGES / subfolder / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    assert reference(dest)["sha256"] == spec["image"]["sha256"]
    spec["image"]["path"] = dest.relative_to(IMAGES).as_posix()
    return cells(dest, spec)


def main():
    refs = {key: reference(ROOT / f"{key}.json") for key in (
        "automatic-native", "iso6400-native", "controlled", "noisy-centers", "replay", "camera")}
    data = {key: read_json(checked(value)) for key, value in refs.items()}
    stand = read_json(checked(data["camera"]["manifest"]))
    earlier = reference(PRIOR / "manifest.json")
    previous = {row["id"]: row for row in read_json(checked(earlier))["standing"]}
    changed = {}
    camera = {row["id"]: row["changes"]["rotation_vs_veto"] for row in data["camera"]["observations"]}
    assert len(camera) == len(stand["rows"]) == 8
    for row in stand["rows"]:
        name = row["id"]
        old = previous[name]
        for key in ("raw", "input", "parent", "native_box", "roi", "noise", "display_exposure"):
            assert row[key] == old[key], (name, key)
        expected = PRIOR / old["board"]["image"]["path"]
        assert reference(expected)["sha256"] == old["board"]["image"]["sha256"]
        previous_cells = cells(expected, old["board"])
        new = publish_board(row["board"], "standing")
        shared = previous_cells.keys() & new.keys()
        assert all(np.array_equal(previous_cells[key], new[key]) for key in shared), name
        assert np.array_equal(previous_cells["Local check with phase veto"], new["Phase veto only"])
        delta = np.abs(new["Phase veto only"].astype(np.int16) - new["Measured local phase"])
        row["phase_transfer_vs_veto"] = {**camera[name], "max_srgb8": int(delta.max())}
        if camera[name]["RMS_DN16"]:
            changed[name] = row["phase_transfer_vs_veto"]
        else:
            assert not delta.any()
    assert set(changed) == {"main-chain-link-fence-main-chain-link-fence", "mesh-profile3879-fine-green-mesh-right"}

    checkpoint = data["controlled"]["checkpoint"]
    for name, folder in (("automatic-native", "automatic"), ("iso6400-native", "exact")):
        native = data[name]
        assert native["checkpoint"] == checkpoint
        assert len(native["boards"]) == 2
        for row in native["boards"]:
            full = publish_board(row["board"], folder)
            triplet = publish_board(row["triplet"], folder)
            assert all(np.array_equal(full[label], crop) for label, crop in triplet.items())

    manifest = IMAGES / "manifest.json"
    write_json(manifest, {
        "checkpoint": checkpoint, "standing": stand["rows"], "previous_standing": earlier,
        "automatic": data["automatic-native"]["boards"], "supplied": data["iso6400-native"]["boards"],
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "observations": "Both automatic and both supplied ISO6400 comparisons and all eight standing boards were viewed. Planted crossings stay softer than their exact targets. Fine cab crossings remain incomplete.",
    }, replace=True)

    RESULTS.mkdir(exist_ok=True)
    archive = RESULTS / "evidence.tar.xz"
    files = [checked(v) for v in refs.values()] + [checked(data["camera"]["manifest"])]
    files += sorted(ROOT.glob("*.py")) + sorted(ROOT.glob("*.log"))
    files += [ROOT.with_name("bayer-local-deficit-v1") / "phase_veto.py"]
    files += [ROOT.with_name("bayer-near-donors-v1") / "screen.py"]
    files += [ROOT.with_name("bayer-warped-spacing-v1") / "nominate.py"]
    by_member = {str(path.resolve().relative_to(Path.cwd())): path for path in files}
    with tarfile.open(archive, "w:xz", preset=4) as out:
        for member, path in sorted(by_member.items()):
            out.add(path, arcname=member, recursive=False)
    with tarfile.open(archive) as out:
        for member, path in by_member.items():
            with out.extractfile(member) as handle:
                assert hashlib.file_digest(handle, "sha256").hexdigest() == reference(path)["sha256"]

    write_json(RESULTS / "publication.json", {
        "checkpoint": checkpoint, "sources": refs, "manifest": reference(manifest), "archive": reference(archive),
        "standing_changes": changed,
        "supplied_256": data["controlled"]["summary"], "supplied_and_automatic_512": data["noisy-centers"]["summary"],
        "replay": {key: group["summary"] for key, group in data["replay"]["groups"].items()},
        "scope": "Same frozen checkpoint and composed standing components. No new training or fixed photo or measured-camera panel. Native crops inspected at unity scale.",
    }, replace=True)
    print("Verified all eight standing boards and four exact-target triplets.")


if __name__ == "__main__":
    main()
