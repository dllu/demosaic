"""Render the first two shifted captures changed by automatic donor geometry."""
from pathlib import Path

import numpy as np
import torch

from noisy_centers import ROOT,ROLES,KEYS,full_scene_generator,donor,metric,luma,render,PROFILES
from rotate import phase,old
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    size=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/size))
    comparison=reference(ROOT/"noisy-centers.json")
    report=read_json(checked(comparison))
    plan=read_json(checked(report["plan"]))
    checkpoint=report["checkpoint"]
    model,state=load_checkpoint(checkpoint["path"],"cuda",tiled_inference=True)
    assert state["loaded_sha256"]==checkpoint["sha256"] and "ema" in state
    model.eval()
    a,b=PROFILES["ISO6400"]
    noise={"shot":a,"read":b}
    model.set_noise(a,b)
    prepare=full_scene_generator()
    out=ROOT/"automatic-native"
    out.mkdir(exist_ok=True)
    selected=[r for r in report["rows"]["automatic"] if r["routes"][0]["phase_delivery"]][:2]
    assert len(selected)==2
    views=[]
    for example in selected:
        i=example["index"]
        scene=plan["sources"][i]
        full,masks,_,_,recipe=prepare(plan,scene,"ISO6400")
        matrices={k:(v[...,64:192,64:192] if k in ("packed","variance") else
                   v[...,128:384,128:384] if k=="target" else v)for k,v in full.items()}
        mask={k:m[128:384,128:384]for k,m in masks.items()}
        args=[torch.as_tensor(matrices[k],device="cuda")for k in KEYS[:5]]
        args[:2]=[x.contiguous(memory_format=torch.channels_last)for x in args[:2]]
        with ieee_fp32():
            base=model(*args).cpu().numpy()
        predictions={k:base.copy()for k in ("parent","baseline","local","uniform","reversed","rotation","opposite")}
        trace=[]
        for n,role in enumerate(ROLES):
            cfa,wb,matrix=(matrices[k][n] for k in ("colors","wb","matrix"))
            tile=matrices["packed"][n]
            tag,terms=donor(full["packed"][n],cfa,noise,tile)
            trace.append({"origin":tag,"terms":None if terms is None else [v.tolist()for v in terms],"role":role})
            if terms is not None:
                patches,_=render(tile,base[n],cfa,wb,matrix,noise,*terms)
                for k,v in patches.items():
                    predictions[k][n]+=v
            proof=example["routes"][n]
            assert (tag,role)==(proof["origin"],proof["role"])
            assert bool(np.any(predictions["rotation"][n]!=predictions["local"][n]))==proof["phase_delivery"]
        scores={k:metric(v,matrices,mask,luma(predictions["local"],matrices))for k,v in predictions.items()}
        assert scores==example["scores"]
        path=out/f"{i:03d}-iso6400-automatic.npz"
        with path.open("xb") as stream:
            np.savez_compressed(stream,**matrices,**{f"result_{k}":v for k,v in predictions.items()})
        frame={k:matrices[k][:1] for k in ("packed","wb","matrix","colors")}
        names=("parent","local","rotation","opposite")
        plates=[noisy_malvar(frame)[0],*(predictions[k][0]for k in names),matrices["target"][0]]
        labels=("Noisy Malvar","Corpus 100k EMA","Phase veto only","Measured local phase","Opposite phase shift","Exact GT")
        result=old.native_board(out,f"{i:03d}-iso6400-automatic",plates,frame,
             {"source":scene["source"],"full_source_box":scene["box"],"query_within_source_box":[128,128,256,256],
              "input":reference(path),"checkpoint":checkpoint,"noise":noise,"CFA":scene["camera"]["pattern"],
              "scene_recipe":recipe,"role":"shifted","routes":trace},
             labels=labels,exposure=2,contrast=1,triplet_indices=(0,3,5))
        views.append(result)
    write_json(ROOT/"automatic-native.json",{"driver":reference(__file__),"comparison":comparison,
                "checkpoint":checkpoint,"boards":views})


if __name__=="__main__":
    main()
