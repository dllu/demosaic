"""Repeat the first two active ISO6400 phase changes and render their native pixels."""
from pathlib import Path
import time

import torch

from rotate import ROOT
from controlled import evaluate
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint


@torch.inference_mode()
def main():
    source=reference(ROOT/"controlled.json")
    archived=read_json(checked(source))
    plan=read_json(checked(archived["plan"]))
    driver=checked(archived["driver"])
    text=driver.read_text()
    # Same observation and evaluation. Move the rendering predicate to ISO6400.
    rule='draw_boards and log[0]["changed"] and profile=="ISO400"'
    assert text.count(rule)==1
    namespace={"__name__":"high_noise_native_solver","__file__":str(driver)}
    exec(compile(text.replace(rule,rule.replace("ISO400","ISO6400")),str(driver),"exec"),namespace)
    infer=namespace["evaluate"]
    torch.set_num_threads(2)
    limit=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/limit))
    bound=archived["checkpoint"]
    model, weights=load_checkpoint(bound["path"],"cuda",tiled_inference=True)
    assert weights["loaded_sha256"]==bound["sha256"] and "ema" in weights
    model.eval()
    rows=[r for r in archived["rows"] if r["profile"]=="ISO6400" and r["changes"][0]["changed"]][:2]
    assert len(rows)==2
    output=ROOT/"iso6400-native"
    output.mkdir(exist_ok=True)
    copied=[]
    for r in rows:
        i=r["i"]
        view=infer(model,plan,plan["sources"][i],"ISO6400",bound,output,True)
        assert view["scores"]==r["scores"] and view["changes"]==r["changes"]
        assert view["board"]
        copied.append(view["board"])
    write_json(ROOT/"iso6400-native.json",{"driver":reference(__file__),"comparison":source,
                "checkpoint":bound,"boards":copied})


if __name__=="__main__":
    main()
