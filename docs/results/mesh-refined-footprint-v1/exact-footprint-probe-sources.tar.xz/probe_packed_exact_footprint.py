"""Separate footprint selection from wavelength evidence using synthetic truth."""

import math
import os
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from panel import CENTRE, Carrier, ribbon, window
from optimized_footprints import ReservedFit
from pooled_gap_audit_20261118 import SIGNED_OVERLAP, fitted_terms, read_score, sound_template

ROOT = Path(__file__).resolve().parent


def check_case(case, plan):
    path = checked(case["source"])
    row = read_json(path)
    role = row["proof"]["matching"]["roles"][1]
    result = {"id": case["id"], "source": case["source"], "profile": row["entry"]["profile"],
              "entered_shape_audit": "central_pair" in role}
    if "central_pair" not in role:
        return result
    with np.load(checked(row["arrays"]), allow_pickle=False) as values:
        raw = window(values["packed"][1], CENTRE, phase=2)
        cfa = values["colors"][1]
        native = window(1-values["support"], CENTRE)
        exact = np.stack([native[y::2,x::2] for y,x in ((0,0),(0,1),(1,0),(1,1))])
    assert exact.shape == raw.shape
    coords = native_sites(raw.shape[-2:], (-127.5, -127.5))
    np.testing.assert_array_equal(exact, native[(coords[1]+127.5).astype(int),(coords[0]+127.5).astype(int)])
    exact = exact.ravel()
    p, q = (ribbon(*coords,Carrier(**opts)) for opts in role["central_pair"])
    raw_noise = plan["noise"][row["entry"]["profile"]]
    data, reserve, groups, bg, rear, edge = fitted_terms(raw, cfa, p, q, raw_noise)
    design = np.column_stack((bg, rear))
    fitter = ReservedFit(data, design, rear, reserve)
    score, fraction = map(float, fitter.scores([SimpleNamespace(mask=lambda *unused: exact[reserve])])[0])
    delta, variance, _ = sound_template(data, design, rear, reserve, fraction * exact)
    known = read_score(data.raw, data.colors, design, delta, variance, ~reserve)
    result.update({
        "known_footprint": known,
        "nomination_fit": {"gain": score, "fraction": fraction},
        "passes_with_known_footprint": bool(role["evidence"]["global_keep"] and
            known["z"] > SIGNED_OVERLAP and known["half_displacement_gain"] > 0),
        "global_keep": role["evidence"]["global_keep"],
        "measured": {arm: {"accepted": value["accepted"], "audit_score": value["holdout"]["z"]}
                   for arm, value in role["evidence"]["policies"].items()},
    })
    return result


if __name__ == "__main__":
    os.sched_setaffinity(0, [14])
    os.nice(12)
    source = reference(ROOT / "summary.json")
    summary = read_json(checked(source))
    plan = read_json(checked(summary["plan"]))
    gaps = [check_case(case, plan) for case in summary["cases"] if case["entry"]["kind"]=="gaps"]
    assert len(gaps)==12
    for case in gaps:
        print(case["id"], round(case.get("known_footprint",{}).get("z", float("nan")), 3),
              case.get("passes_with_known_footprint"), flush=True)
    write_json(ROOT / "packed-exact-footprint-probe.json", {"source": reference(__file__), "summary": source,
        "scope": "Packs exact synthetic gap masks into Bayer phase order and fits only their strength on the nomination subset before the signed audit. Fitted foreground, measured rear carriers, noise weights and gate are fixed. This is a diagnostic and uses hidden ground truth.",
        "cases": gaps})
