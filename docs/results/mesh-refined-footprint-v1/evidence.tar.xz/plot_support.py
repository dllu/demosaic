"""Draw the exact and measured missing-wire masks from the archived angle miss."""

from pathlib import Path

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
scene = read_json(ROOT / "development.json")["scenes"][0]
assert scene["id"] == "iso6400-band-g223"
with np.load(checked(scene["assets"]), allow_pickle=False) as arrays:
    target = arrays["actual_support"]
    fields = [2*arrays[k] for k in ("coarse-mean", "refined-mean", "refined-top")]
labels = ["Exact missing region", "Coarse mean", "Refined mean", "Refined best"]
fig, axes = plt.subplots(1, 4, figsize=(9.3, 2.9), layout="constrained")
for i, (axis, label, field) in enumerate(zip(axes, labels, [target, *fields], strict=True)):
    bar = axis.imshow(field, vmin=0, vmax=1, cmap="viridis", interpolation="nearest")
    if i:
        axis.contour(target, levels=[.5], colors="white", linewidths=.65)
    axis.set_title(label, fontsize=9)
    axis.set_xticks([])
    axis.set_yticks([])
    for spine in axis.spines.values():
        spine.set_visible(False)
fig.suptitle("Refining a high-noise band angle on ISO6400 g223", fontsize=12)
fig.colorbar(bar, ax=list(axes), fraction=.04, shrink=.87, label="Cut fraction before delivery")
path = ROOT / "refined-footprint.png"
fig.savefig(path, dpi=155)
write_json(ROOT / "refined-figure.json", {"source": reference(__file__),
    "case": scene["source"], "replay": reference(ROOT/"development.json"),
    "image": reference(path), "ROI": [80, 80, 160, 160],
    "scope": "The white line marks the half-value of the exact missing-wire footprint."})
