"""Measure off-grid refinement against two already inspected high-noise gap geometries."""

import importlib.util
import math
import os
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"mesh-tapered-strength-v1"
sys.path.insert(1,str(OLD))
spec=importlib.util.spec_from_file_location("prior_tapered_delivery_source",OLD/"panel.py")
original=importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
from deliver import CENTRE,DISPLAY,Carrier,proposals,score,window
from mesh import ribbon
from optimized_footprints import audit


def direction(field):
    row,column=np.gradient(field)
    G=np.array([column.ravel(),row.ravel()])
    values,vectors=np.linalg.eigh(G@G.T)
    heading=vectors[:,-1]
    return (math.degrees(math.atan2(heading[1],heading[0]))%180,
            float(values[-1]/max(values.sum(),1e-12)))


def angle_error(a,b):
    return min(abs(a-b),180-abs(a-b))


def run():
    old=read_json(OLD/"measured-plan.json")
    outdated=("iso6400-band-g223","iso6400-compound-g224")
    output=ROOT/"development";output.mkdir()
    out=[]
    for key in outdated:
        path=OLD/"scored"/f"{key}.json"
        row=read_json(path)
        noise=old["noise"][row["entry"]["profile"]]
        role=next(r for r in row["proof"]["matching"]["roles"]if r["role"]==1)
        with np.load(checked(row["arrays"]),allow_pickle=False)as f:
            obs={k:f[k]for k in ("parent","packed","target","colors","variance","strong_phase","weak_phase","support",
                              "matching/broad","matching/central","matching/fixed")}
        parent,target=obs["parent"],obs["target"]
        packed,var,cfa=(obs[k][1]for k in ("packed","variance","colors"))
        scan=window(packed,CENTRE,phase=2)
        pos=native_sites(scan.shape[-2:],(-127.5,-127.5))
        carriers=tuple(Carrier(**spec)for spec in role["central_pair"])
        p,q=(ribbon(*pos,e)for e in carriers)
        fx,fy=carriers[0].frequency
        masks,proof=audit(scan,cfa,p,q,noise,CENTRE,DISPLAY,math.atan2(fy,fx))
        assembled,context,_,_,_=original.observe(row["entry"],noise)
        np.testing.assert_array_equal(assembled["packed"].numpy(),obs["packed"])
        exterior=context["matching"]
        _,trace=proposals(exterior,cfa,(256,256,256,256),noise,80)
        config,moved,_=original.base.prepare(lambda x,y,s:window(exterior,(x,y,s,s),phase=2),trace,cfa,noise,(383.5,383.5))
        wide,rear,_=original.base.reconstruct(parent[1],packed,var,cfa,CENTRE,DISPLAY,noise,
                   config,moved if role["carried"]else None)
        np.testing.assert_array_equal(wide,obs["matching/broad"][1])
        actual=window(1-obs["support"],DISPLAY)
        a,strength=direction(actual)
        cases={}
        data={}
        gt={k:obs[k]for k in ("strong_phase","weak_phase","support")}
        for name,mask in masks.items():
            field=obs["matching/central"].copy()
            field[1]=(field[1]-mask[None]*rear).astype(field.dtype)
            if name=="coarse-mean":
                np.testing.assert_array_equal(field[1],obs["matching/fixed"][1])
            location=None
            if mask.any():
                b,orientation=direction(mask)
                est=mask*2.
                intersection=np.minimum(actual,est).sum()
                location={"normal_deg_mod180":b,"directional_mass":orientation,
                    "angle_error_deg":angle_error(a,b),"soft_cut_IoU":float(intersection/np.maximum(actual,est).sum())}
            cases[name]=score(parent,field,target,gt)|{"geometry":location}
            data[name]=field
        file=output/f"{key}.npz"
        np.savez_compressed(file,actual_support=actual,**masks,**{"pred-"+k:v for k,v in data.items()})
        out.append({"id":key,"source":reference(path),"proof":proof,"scores":cases,"assets":reference(file),
                    "true_normal_deg_mod180":a,"true_directional_mass":strength})
        print(key,[(k,v["geometry"]and round(v["geometry"]["angle_error_deg"],2),v["gap_added_RMS_DN16"])for k,v in cases.items()],flush=True)
    write_json(ROOT/"development.json",{"driver":reference(__file__),"previous_plan":reference(OLD/"measured-plan.json"),"scenes":out})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12);torch.set_num_threads(1)
    run()
