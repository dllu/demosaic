"""Refine band, disk and ellipse footprints on the nomination samples alone."""

from dataclasses import dataclass
import math

import numpy as np

from demosaic.isolated_line import coordinates
from averaged_footprints import proposal_bank
from pooled_gap_audit_20261118 import SIGNED_OVERLAP, admitted, fitted_terms, forecasts, read_score, sound_template

MODES=("coarse-top","coarse-mean","refined-top","refined-mean")
STEPS=(1.,.5,.25)
LABELS=("band","disk","ellipse")


@dataclass(frozen=True)
class Shape:
    kind: str
    center: tuple[float,float]
    width: float
    angle: float

    def mask(self,x,y):
        dx,dy=x-self.center[0],y-self.center[1]
        if self.kind=="disk":
            radius=np.hypot(dx,dy)
        else:
            cn,sn=math.cos(self.angle),math.sin(self.angle)
            X=cn*dx+sn*dy
            radius=abs(X) if self.kind=="band"else np.hypot(X/.64,(-sn*dx+cn*dy)/1.35)
        ramp=np.clip((self.width+10-radius)/10,0,1)
        return ramp*ramp*(3-2*ramp)


def packed_parameters(s):
    x,y=s.center
    theta=s.angle
    if s.kind=="band":
        offset=x*math.cos(theta)+y*math.sin(theta)
        return np.array([offset,s.width,theta]),np.array([10.,8.,np.deg2rad(12)])
    if s.kind=="disk":
        return np.array([x,y,s.width]),np.array([10.,10.,9.])
    return np.array([x,y,s.width,theta]),np.array([10.,10.,9.,np.deg2rad(12)])


def unpack_parameters(s,vector):
    if s.kind=="band":
        offset,width,theta=map(float,vector)
        return Shape(s.kind,(offset*math.cos(theta),offset*math.sin(theta)),width,theta)
    x,y,width=map(float,vector[:3])
    return Shape(s.kind,(x,y),width,float(vector[3]) if s.kind=="ellipse" else 0.)


class ReservedFit:
    def __init__(self,data,design,rear,learn):
        self.position=tuple(a[learn]for a in data.positions)
        measured=data.raw[learn]
        colors=data.colors[learn]
        self.parts=[]
        for c in range(3):
            site=colors==c
            X=design[learn][site]
            Q,R=np.linalg.qr(X,mode="reduced")
            p=Q.T@measured[site]
            resid=measured[site]-Q@p
            co=np.linalg.solve(R,p)[-rear.shape[1]:]
            front=rear[learn][site]@co
            sigma=data.shot*max(1e-4,float(np.median(measured[site])))+data.read
            self.parts.append((site,Q,resid,front,sigma))

    def scores(self,shapes):
        output=[]
        for start in range(0,len(shapes),12):
            group=shapes[start:start+12]
            mask=np.column_stack([s.mask(*self.position)for s in group])
            dot,norm=np.zeros(len(group)),np.zeros(len(group))
            for site,Q,resid,profile,sigma in self.parts:
                assert mask.ndim==2 and profile.ndim==1 and len(profile)==int(site.sum())
                delta=-(mask[site]*profile[:,None])
                project=Q.T@delta
                norm+=((delta**2).sum(0)-(project**2).sum(0))/sigma
                dot+=(resid@delta)/sigma
            fraction=np.clip(dot/np.maximum(norm,1e-12),0,1)
            gain=2*dot*fraction-norm*fraction*fraction
            output.extend(zip(gain.tolist(),fraction.tolist(),strict=True))
        return np.asarray(output)


def refine(score,seed):
    initial,rate=packed_parameters(seed)
    lower=initial-rate*1.8
    upper=initial+rate*1.8
    width=1 if seed.kind=="band" else 2
    lower[width]=max(lower[width],14.)
    upper[width]=min(upper[width],73.)
    eye=np.eye(len(initial))
    directions=np.concatenate((eye,-eye),axis=0)
    current=initial
    before=score.scores([seed])[0]
    value=before
    for scale in STEPS:
        for _ in range(2):
            proposals=np.clip(current+scale*rate*directions,lower,upper)
            targets=[unpack_parameters(seed,a)for a in proposals]
            all_scores=score.scores(targets)
            winner=int(np.argmax(all_scores[:,0]))
            if all_scores[winner,0]<=value[0]+1e-8:
                break
            current=proposals[winner]
            value=all_scores[winner]
    final=unpack_parameters(seed,current)
    return final,value


def nominations(fit,bank):
    scores=fit.scores(bank)
    sizes={k:sum(s.kind==k for s in bank)for k in LABELS}
    initial={}
    other=[]
    for kind in LABELS:
        ranking=sorted([i for i,s in enumerate(bank)if s.kind==kind],key=lambda i:-scores[i,0])
        first=ranking[0]
        # Find another starting basin by testing footprint overlap on a fixed,
        # sparse subset of reserve coordinates rather than through audit scores.
        test=tuple(p[::89]for p in fit.position)
        first_mask=bank[first].mask(*test)
        for i in ranking[1:]:
            field=bank[i].mask(*test)
            likeness=(field@first_mask)/max(1e-9,np.linalg.norm(first_mask)*np.linalg.norm(field))
            if likeness<.83:
                second=i
                break
        else:
            second=ranking[1]
        initial[kind]=[first,second]
    changed=list(bank)
    updated=scores.copy()
    for indices in initial.values():
        for index in indices:
            new,value=refine(fit,bank[index])
            assert value[0]>=scores[index,0]-1e-8
            changed[index]=new
            updated[index]=value
            other.append({"family":new.kind,"original":vars(bank[index]),"refined":vars(new),
                           "gain":[float(scores[index,0]),float(value[0])],
                           "fraction":[float(scores[index,1]),float(value[1])]})
    return scores,tuple(changed),updated,sizes,other


def fields(shapes,ranking,sizes,sites,native):
    winner=int(np.argmax(ranking[:,0]))
    peak=shapes[winner]
    weights=np.exp((ranking[:,0]-ranking[winner,0])/3)/np.asarray([sizes[s.kind]for s in shapes])
    weights/=weights.sum()
    rate=weights*ranking[:,1]
    raw=np.zeros_like(sites[0])
    pixels=np.zeros_like(native[0])
    for coeff,shape in zip(rate,shapes,strict=True):
        if coeff>1e-7:
            raw+=coeff*shape.mask(*sites)
            pixels+=coeff*shape.mask(*native)
    top=ranking[winner,1]
    indexes=np.argsort(-weights)[:5]
    return {
        "top":(top*peak.mask(*sites),top*peak.mask(*native),
               {"shape":vars(peak),"gain":float(ranking[winner,0]),"strength":float(top)}),
        "mean":(raw,pixels,{"effective_shapes":float(1/np.dot(weights,weights)),
               "main_shapes":[{"shape":vars(shapes[i]),"weight":float(weights[i]),
                 "gain":float(ranking[i,0])}for i in indexes]}),
    }


def audit(raw,cfa,p,q,noise,query,roi,approx_angle):
    data,reserve,held,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    a,b,d=held
    keep="shape" not in edge or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    design=np.column_stack((bg,rear))
    theta=edge["shape"][0]if "shape"in edge else approx_angle
    bank=proposal_bank(theta)
    fit=ReservedFit(data,design,rear,reserve)
    coarse,new,updated,sizes,history=nominations(fit,bank)
    origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
    native=coordinates(roi[3],roi[2],origin=origin)
    out={}
    proof={}
    for name,shapes,ranks in (("coarse",bank,coarse),("refined",new,updated)):
        for method,(cut,fixed,witness)in fields(shapes,ranks,sizes,data.positions,native).items():
            delta,sigma,_=sound_template(data,design,rear,reserve,cut)
            result=read_score(data.raw,data.colors,design,delta,sigma,~reserve)
            accepted=bool(keep and result["z"]>SIGNED_OVERLAP and result["half_displacement_gain"]>0)
            key=f"{name}-{method}"
            out[key]=.5*fixed if accepted else np.zeros_like(fixed)
            proof[key]={"accepted":accepted,"holdout":result,"nomination":witness,
                        "max_cut":float(out[key].max())}
    return out,{"edge":edge,"global_keep":keep,"policies":proof,"refinement":history}
