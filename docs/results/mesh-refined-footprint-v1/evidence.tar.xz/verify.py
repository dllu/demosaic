"""Check coarse-bank parity and the sample boundary of refined nominations."""

import math
import os
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

ROOT = Path(__file__).resolve().parent
OLDER = ROOT.parent / "mesh-tapered-strength-v1"
sys.path[:0] = [str(ROOT.parent / name) for name in (
    "mesh-envelope-support-v1", "mesh-refined-edge-v1", "mesh-shrunk-footprint-v1",
    "mesh-pooled-gap-evidence-v1", "mesh-averaged-gap-v1")]
from panel import CENTRE, DISPLAY, Carrier, window
from averaged_footprints import proposal_bank, rank
from mesh import ribbon
from optimized_footprints import ReservedFit, audit, packed_parameters, unpack_parameters
from pooled_gap_audit_20261118 import fitted_terms


def check_case(name, plan):
    path = OLDER / "scored" / f"{name}.json"
    row = read_json(path)
    noise = plan["noise"][row["entry"]["profile"]]
    with np.load(checked(row["arrays"]), allow_pickle=False) as values:
        raw = window(values["packed"][1], CENTRE, phase=2)
        cfa = values["colors"][1]
    role = row["proof"]["matching"]["roles"][1]
    position = native_sites(raw.shape[-2:], (-127.5, -127.5))
    p, q = (ribbon(*position, Carrier(**value)) for value in role["central_pair"])
    fx, fy = role["central_pair"][0]["frequency"]
    angle = math.atan2(fy, fx)
    data, reserve, masks, bg, rear, edge = fitted_terms(raw, cfa, p, q, noise)
    design = np.column_stack((bg, rear))
    bank = proposal_bank(edge["shape"][0] if "shape" in edge else angle)
    expected = rank(data, design, rear, reserve, bank)
    actual = ReservedFit(data, design, rear, reserve).scores(bank)
    np.testing.assert_allclose(actual, expected, rtol=1e-11, atol=1e-10)
    largest_profile_difference = 0.
    for shape in bank:
        seed = packed_parameters(shape)[0]
        sample = tuple(axis[::211] for axis in data.positions)
        measured = shape.mask(*sample)
        restored = unpack_parameters(shape, seed).mask(*sample)
        np.testing.assert_allclose(restored, measured, rtol=0, atol=1e-12)
        largest_profile_difference = max(largest_profile_difference, float(abs(restored - measured).max()))
    _, witness = audit(raw, cfa, p, q, noise, CENTRE, DISPLAY, angle)
    altered = raw.copy()
    idx = masks[2].reshape(raw.shape)
    assert not np.any(masks[2] & reserve)
    altered[idx] += .008 * (p[idx] - .2*q[idx])
    _, second = audit(altered, cfa, p, q, noise, CENTRE, DISPLAY, angle)
    assert witness["refinement"] == second["refinement"]
    for key, arm in witness["policies"].items():
        assert arm["nomination"] == second["policies"][key]["nomination"]
    assert any(witness["policies"][key]["holdout"]["z"] != second["policies"][key]["holdout"]["z"]
               for key in witness["policies"])
    slopes = [change["gain"][1]-change["gain"][0] for change in witness["refinement"]]
    assert len(slopes) == 6 and min(slopes) >= -1e-8
    return {"case": reference(path), "grid_shapes": len(bank), "refinements": len(slopes),
            "maximum_score_difference": float(abs(actual - expected).max()),
            "maximum_mask_roundtrip_difference": largest_profile_difference,
            "reserve_gain_changes": slopes, "audit_mutation_preserves_all_nominations": True}


if __name__ == "__main__":
    os.sched_setaffinity(0, [14])
    os.nice(12)
    plan = read_json(OLDER / "measured-plan.json")
    checks = [check_case(name, plan) for name in (
        "iso400-compound-g224", "iso6400-band-g223", "iso6400-compound-g224")]
    write_json(ROOT / "verification.json", {"source": reference(__file__), "checks": checks})
    print([(v["grid_shapes"], v["maximum_score_difference"], v["maximum_mask_roundtrip_difference"])
           for v in checks], flush=True)
