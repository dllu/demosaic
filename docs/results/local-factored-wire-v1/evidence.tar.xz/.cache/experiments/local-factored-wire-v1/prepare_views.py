"""Assemble inspection boards from unchanged native crop pixels."""

import argparse
from pathlib import Path
import sys

from demosaic.experiments.artifacts import read_json

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name("local-continuing-wire-v1")))
from prepare_views import make

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--floor", action="store_true")
    args = parser.parse_args()
    root = args.root.absolute()
    review = read_json(root / "review/native.json")
    pair = (
        ("Band-limited correction", "0.25 gain floor")
        if args.floor
        else ("Direct correction", "Band-limited correction")
    )
    make(
        review["boards"],
        ("Noisy Malvar", "Aligned control", *pair, "Exact GT"),
        root / "view-exact.png",
    )
    for name in ("main", "mesh"):
        crops = [i for i in review["standing"] if i["id"].startswith(name)]
        make(
            crops,
            ("V120 EMA", "Aligned control", "Continuing-wire loss", *pair),
            root / ("view-" + name + ".png"),
        )
        references = (
            ("Noisy (Malvar)", "ISO6400 camera JPEG", "ISO100 AHD reference", "ISO100 camera JPEG")
            if name == "mesh"
            else ("Noisy (Malvar)", "ISO100 AHD reference")
        )
        make(crops, references, root / ("view-" + name + "-references.png"))
