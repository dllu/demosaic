"""Replay immutable exact, redraw, camera and standing GFX panels for two correction heads."""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.factored_detail import load_detail_checkpoint
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from demosaic.scene_inference import load_scene_checkpoint
from report_scene_wave_guides import native_board
from collect_scene_primary_compact import metric_rows_for, numbers, score

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("local-continuing-wire-v1")
sys.path.insert(0, str(PREVIOUS))
from review_continuing import PROFILE, ROI, KEYS, metrics, native_png, old_pixels
from double_gap import metrics as double_metrics
from upper import luma
from fit_local import metric_for_wire

sys.path.insert(0, str(ROOT.with_name("local-wire-response-v1")))
from score_wire_redraws import decompose

ARMS = {"direct": "Direct correction", "band-limited": "Band-limited correction"}
PARENT = "Aligned control"
TEACHER = "Continuing-wire loss"
OUTPUT = ROOT / "review"


def read_arrays(binding):
    with np.load(checked(binding), allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}


def load(binding):
    return np.load(checked(binding), allow_pickle=False)


def save(values, path):
    with path.open("xb") as stream:
        np.save(stream, values, allow_pickle=False)
    return reference(path)


def compare(rows, *, natural=False):
    rng = np.random.default_rng(202611191518)
    aggregate = {}
    for metric in sorted(rows[0][next(iter(ARMS.values()))]):
        cases = [row for row in rows if row[PARENT].get(metric) is not None]
        if not cases:
            continue
        n = len(cases)
        index = np.vstack((np.arange(n), rng.integers(n, size=(6500, n))))
        means = {}
        for name in set.intersection(*(set(row) for row in cases)):
            values = [row[name].get(metric) for row in cases]
            if any(value is None for value in values):
                continue
            values = np.asarray(values)[index]
            if (natural and metric.endswith("RMS_DN16")) or metric.endswith("_squared"):
                values = np.sqrt(np.mean(values**2, axis=1)) if natural else np.sqrt(values.mean(1))
            else:
                values = values.mean(1)
            means[name] = values
        pairs = [
            (name, prior)
            for name in ARMS.values()
            for prior in (PARENT, TEACHER, "V120")
            if prior in means
        ]
        control, candidate = ARMS.values()
        pairs.append((candidate, control))
        effects = {}
        for name, prior in pairs:
            change = means[name] - means[prior]
            effects[f"{name} vs {prior}"] = {
                "delta": float(change[0]),
                "interval": np.quantile(change[1:], [0.025, 0.975]).tolist(),
            }
        aggregate[metric.removesuffix("_squared")] = {
            "cases": n,
            "values": {name: float(val[0]) for name, val in means.items()},
            "differences": effects,
        }
    return aggregate


class Runner:
    def __init__(self, run, floor=None):
        parent = run["parent"]
        self.parent, _ = load_scene_checkpoint(
            checked(parent), weights="ema", expected_sha256=parent["sha256"]
        )
        _stage_tiled_cuda(self.parent, "cuda")
        self.heads = {}
        self.activations = {}
        specs = {key: (binding, run) for key, binding in run["checkpoints"].items()}
        if floor is not None:
            specs.pop("direct")
            specs["gain-floor"] = (floor["checkpoints"]["band-limited"], floor)
        for key, (binding, phase) in specs.items():
            detail, state = load_detail_checkpoint(
                checked(binding), weights="ema", expected_sha256=binding["sha256"]
            )
            assert state["parent"] == parent and state["plan"] == phase["plan"]
            assert state["band_limited"] == (key != "direct")
            assert detail.gain_floor == (0.25 if key == "gain-floor" else 0.0)
            assert state["step"] == phase["updates_per_arm"]
            self.heads[key] = _stage_tiled_cuda(detail, "cuda")

            def capture(module, inputs, output, *, label=key):
                self.activations[label] = output.detach()

            detail.output.register_forward_hook(capture)

    def telemetry(self, roi):
        x, y, w, h = roi
        result = {}
        for key, value in self.activations.items():
            native = torch.nn.functional.pixel_shuffle(value[:1], 2)
            detail, confidence = native[0, :, y : y + h, x : x + w].cpu().numpy()
            result[key] = {
                "confidence_logits_5_50_95": np.quantile(confidence, (0.05, 0.5, 0.95)).tolist(),
                "confidence_below_one_percent": float(np.mean(confidence < np.log(0.01 / 0.99))),
                "detail_tanh_saturated": float(np.mean(np.abs(detail) > np.arctanh(0.99))),
            }
        return result

    def forward(self, args, profile):
        count = len(args["packed"])
        self.parent.base.set_noise(profile["shot"], profile["read"])
        batch = {}
        for key in KEYS:
            array = torch.as_tensor(args[key])
            if key in ("packed", "variance"):
                array = array.cuda().contiguous(memory_format=torch.channels_last)
            elif array.ndim == (2 if key == "matrix" else 1):
                array = array.cuda()[None].expand(count, *array.shape)
            else:
                array = array.cuda()
            batch[key] = array
        p, v, c, w, m = (batch[key] for key in KEYS)
        with ieee_fp32():
            parent = self.parent(p, v, c, w, m)
            frames, scale, direction = next(iter(self.heads.values())).features(
                parent, p, v, c, w, m
            )
            deltas = {key: head.correction(frames, scale) for key, head in self.heads.items()}
            outputs = {key: parent + direction * delta for key, delta in deltas.items()}
        assert parent.dtype == torch.float32
        return parent, outputs, deltas

    def arrays(self, args, profile):
        parent, values, deltas = self.forward(args, profile)
        result = [
            parent.cpu().numpy(),
            {k: v.cpu().numpy() for k, v in values.items()},
            {k: v.cpu().numpy() for k, v in deltas.items()},
        ]
        assert all(np.isfinite(v).all() for v in result[1].values())
        return tuple(result)


def lift_stats(field):
    field = np.asarray(field, dtype=np.float64)
    h, w = field.shape[-2:]
    fy, fx = np.fft.fftfreq(h)[:, None], np.fft.fftfreq(w)[None, :]
    radius = np.hypot(fy, fx)
    hann = np.outer(np.hanning(h), np.hanning(w))
    windowed = field * (hann / np.sqrt(np.mean(hann**2)))
    energy = np.abs(np.fft.fft2(windowed, norm="ortho")) ** 2
    rms = lambda x: float(65535 * np.sqrt(np.mean(x)))
    return {
        "DC_DN16": float(field.mean() * 65535),
        "RMS_DN16": rms(field**2),
        "below_1_over_40_RMS_DN16": rms(energy * (radius < 1 / 40)),
        "above_1_over_40_RMS_DN16": rms(energy * (radius >= 1 / 40)),
    }


def exact(runner, prior):
    folder = OUTPUT / "exact"
    predictions = OUTPUT / "predictions"
    for path in (folder, predictions):
        path.mkdir()
    groups, boards = {}, []
    for kind, group in prior["groups"].items():
        rows = []
        for case in group["rows"]:
            source = case["source"]
            arrays = read_arrays(case["input"])
            p, outputs, deltas = runner.arrays(arrays, PROFILE)
            parent = load(case["outputs"]["wire-aligned"])
            np.testing.assert_array_equal(p, parent)
            outcomes = {
                name: case["scores"][name] for name in (PARENT, TEACHER, "V120", "Corpus 100k")
            }
            files = {}
            for key, output in outputs.items():
                outcomes[ARMS[key]] = metrics(case, output, arrays)
                files[key] = save(output, predictions / f"{source['index']:02d}-{key}.npy")
            projections = {}
            if kind == "wire":
                field = metric_for_wire(arrays, source["geometry"])
                if field.gap.any():
                    basis = field.strong_basis
                    truth = field.truth[0][field.gap] @ basis
                    power = truth @ truth
                    scale = 65535**2 / int(field.gap.sum())
                    references = {
                        "V120": read_arrays(case["model_outputs"])["v120"],
                        PARENT: parent,
                        TEACHER: load(case["outputs"]["strong-gap"]),
                    }
                    references.update({ARMS[key]: value for key, value in outputs.items()})
                    for name, value in references.items():
                        tone = luma(value, arrays["wb"], arrays["matrix"])[0, 64:192, 64:192][
                            field.gap
                        ]
                        coeff = tone @ basis
                        response = (coeff @ truth) / power
                        residual = coeff - truth
                        projections[name] = {
                            "strong_response_pp": float(100 * response),
                            "strong_error_DN16_squared": float(residual @ residual * scale),
                        }
            x, y, w, h = ROI
            rows.append(
                {
                    "source": source,
                    "input": case["input"],
                    "query": case["box"],
                    "outputs": files,
                    "scores": outcomes,
                    "strong_projections": projections,
                    "delivered": {
                        key: lift_stats(delta[0, 0, y : y + h, x : x + w])
                        for key, delta in deltas.items()
                    },
                    "gate": runner.telemetry(ROI),
                    "previous_outputs": case["outputs"],
                    "model_outputs": case["model_outputs"],
                }
            )
        summary = compare([row["scores"] for row in rows], natural=kind == "photo")
        if kind == "wire":
            projected = [row["strong_projections"] for row in rows if row["strong_projections"]]
            assert len(projected) == 12
            summary.update(compare(projected))
        groups[kind] = {"rows": rows, "summary": summary}
        field = "gap_RMS_DN16" if kind == "wire" else "fine_increment_RMS_DN16"
        candidate = list(ARMS.values())[-1]
        ordered = sorted(
            (row for row in rows if row["scores"][PARENT].get(field) is not None),
            key=lambda row: row["scores"][candidate][field] - row["scores"][PARENT][field],
        )
        for row in (ordered[0], ordered[-1]):
            arrays = read_arrays(row["input"])
            camera = {key: arrays[key][None] for key in ("colors", "wb", "matrix")}
            camera["packed"] = arrays["packed"][:1]
            images = (
                noisy_malvar(camera)[0],
                read_arrays(row["model_outputs"])["v120"][0],
                load(row["previous_outputs"]["wire-aligned"])[0],
                load(row["previous_outputs"]["strong-gap"])[0],
                *(load(row["outputs"][key])[0] for key in ARMS),
                arrays["target"][0],
            )
            ident = f"{row['source']['index']:02d}-{kind}-iso6400"
            boards.append(
                native_board(
                    folder,
                    ident,
                    images,
                    camera,
                    {
                        key: row[key]
                        for key in ("source", "input", "query", "outputs", "previous_outputs")
                    }
                    | {"iso_profile": PROFILE},
                    labels=("Noisy Malvar", "V120", PARENT, TEACHER, *ARMS.values(), "Exact GT"),
                    triplet_indices=(0, 5, 6),
                    roi=ROI,
                    exposure=2 if kind == "wire" else 1 / 0.33,
                    contrast=1 if kind == "wire" else 2,
                )
            )
    return groups, boards


def standing(runner, prior):
    folder = OUTPUT / "standing"
    folder.mkdir()
    cache, rows = {}, []
    for case in prior["standing"]:
        arrays = read_arrays(case["input"])
        args = {key: arrays[key] for key in KEYS}
        key = (case["input"]["sha256"], case["noise"]["shot"], case["noise"]["read"])
        if key not in cache:
            base, values, deltas = runner.arrays(args, case["noise"])
            np.testing.assert_array_equal(base, load(case["outputs"]["wire-aligned"]))
            proofs = {
                k: save(v, OUTPUT / "predictions" / f"{case['id']}-{k}.npy")
                for k, v in values.items()
            }
            cache[key] = (values, deltas, proofs, runner.activations.copy())
        values, deltas, proofs, activations = cache[key]
        runner.activations = activations.copy()
        pixels = old_pixels(case["board"])
        columns = [
            (label, pixels[label])
            for label in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", PARENT, TEACHER)
            if label in pixels
        ]
        for key, value in values.items():
            rgb = display_crop(
                torch.from_numpy(value),
                torch.from_numpy(args["wb"]),
                torch.from_numpy(args["matrix"]),
                case["roi"],
                exposure=case["exposure"],
            )
            columns.append((ARMS[key], np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)))
        columns.extend(
            (label, pixels[label])
            for label in ("ISO100 AHD reference", "ISO100 camera JPEG")
            if label in pixels
        )
        x, y, w, h = case["roi"]
        rows.append(
            case
            | {
                "previous_board": case["board"],
                "previous_outputs": case["outputs"],
                "outputs": proofs,
                "board": native_png(folder / f"{case['id']}.png", columns),
                "delivered": {
                    key: lift_stats(delta[0, 0, y : y + h, x : x + w])
                    for key, delta in deltas.items()
                },
                "gate": runner.telemetry(case["roi"]),
            }
        )
    assert len(rows) == 8
    return rows


def repeat_panel(runner, previous, training_ids, *, double):
    panel = read_json(checked(previous["inputs"]))
    records = []
    for original, case in zip(previous["rows"], panel["rows"], strict=True):
        assert original["case"] == case
        identity = case["source"]["id"] if double else case["source"]["source"]["id"]
        assert identity not in training_ids
        rendered = defaultdict(list)
        for draw in case["draws"]:
            data = read_arrays(draw["arrays"])
            assert fingerprint(data["packed"]) == draw["packed"]
            _, variants, _ = runner.arrays(data, panel["profile"])
            for key, values in variants.items():
                rendered[key].append(luma(values, data["wb"], data["matrix"]) if double else values)
        scores = {name: original["scores"][name] for name in (PARENT, TEACHER)}
        for key, outputs in rendered.items():
            if double:
                truth = luma(data["target"], data["wb"], data["matrix"])
                result = double_metrics(np.stack(outputs), truth, case["geometry"])
            else:
                metric = metric_for_wire(data, case["source"]["geometry"])
                result = decompose(np.stack(outputs), data, metric)
                rows = [metrics(case, array, data) for array in outputs]
                for name in (
                    "exact_flat_RMS_DN16",
                    "gap_RMS_DN16",
                    "gap_weak_RMS_DN16",
                    "flat_chroma_RMS_DN16",
                ):
                    valid = [row[name] for row in rows if row.get(name) is not None]
                    if valid:
                        result[name] = float(np.mean(valid))
            scores[ARMS[key]] = result
        records.append({"case": case, "scores": scores})
    return {
        "source": previous["inputs"],
        "rows": records,
        "summary": compare([row["scores"] for row in records]),
    }


def cameras(runner):
    plan_path = PREVIOUS / "primary/plan.json"
    plan_ref = reference(plan_path)
    plan = read_json(plan_path)
    canonical = read_json(checked(plan["canonical_inputs"]))
    assert canonical["all_input_witnesses_exact"]
    rows = defaultdict(list)
    for item in canonical["records"]:
        stage, number = item["stage"], item["batch"]
        if stage not in ("known", "unseen"):
            continue
        prior_ref = reference(PREVIOUS / f"primary/full/{stage}-{number:05d}.json")
        prior = read_json(checked(prior_ref))
        assert prior["plan"] == plan_ref and prior["arrays"] == item["arrays"]
        data = read_arrays(item["arrays"])
        assert all(fingerprint(data[key]) == item["fingerprints"][key] for key in KEYS)
        batch = {key: torch.from_numpy(arr).cuda() for key, arr in data.items()}
        base, outputs, _ = runner.forward(batch, item["context"]["noise"])
        assert fingerprint(base.cpu()) == prior["variants"]["wire-aligned"]["output_fingerprint"]
        specs = {"V120": "V120", PARENT: "wire-aligned", TEACHER: "strong-gap"}
        scores = {label: prior["variants"][arm]["rows"] for label, arm in specs.items()}
        scores.update(
            {
                ARMS[key]: metric_rows_for(item, ARMS[key], numbers(score(stage, value, batch)))
                for key, value in outputs.items()
            }
        )
        rows[stage].append(
            {"batch": number, "arrays": item["arrays"], "previous": prior_ref, "rows": scores}
        )
    assert {key: len(values) for key, values in rows.items()} == {"known": 24, "unseen": 30}
    summary = {}
    for stage, entries in rows.items():
        by_arm = defaultdict(list)
        for entry in entries:
            for arm, candidates in entry["rows"].items():
                by_arm[arm].extend(r["metrics"] for r in candidates)
        summary[stage] = {
            arm: {
                k: float(np.mean([r[k] for r in scores]))
                for k in scores[0]
                if k != "reference_samples"
            }
            for arm, scores in by_arm.items()
        }
        assert all(len(values) == (72 if stage == "known" else 90) for values in by_arm.values())
    return {
        "previous": plan_ref,
        "canonical": plan["canonical_inputs"],
        "rows": rows,
        "summary": summary,
    }


@torch.inference_mode()
def main():
    global ARMS, OUTPUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--floor", type=Path)
    args = parser.parse_args()
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    end = reference(ROOT / "training/completed.json")
    trained = read_json(checked(end))
    plan = read_json(checked(trained["plan"]))
    floor = None
    floor_ref = None
    if args.floor is not None:
        floor_ref = reference(args.floor)
        floor = read_json(checked(floor_ref))
        recipe = read_json(checked(floor["plan"]))
        assert recipe["sources_replayed_from"] == trained["plan"]
        assert floor["frozen_parent"] and not floor["qualification"]
        assert floor["parent"] == trained["parent"] and floor["updates_per_arm"] == 480
        for name in ("schedule", "qualification_schedule", "seed", "loss_weights", "optimizer"):
            assert recipe[name] == plan[name]
        ARMS = {"band-limited": "Band-limited correction", "gain-floor": "0.25 gain floor"}
        OUTPUT = args.floor.absolute().parent.parent / "review"
    assert (
        trained["frozen_parent"]
        and not trained["qualification"]
        and trained["updates_per_arm"] == 480
    )
    assert trained["parent"] == plan["parent"]
    prior_end = read_json(checked(plan["parent_completion"]))
    assert prior_end["checkpoints"]["wire-aligned"] == trained["parent"]
    ids = {
        row["source"]["id"]
        for name in ("schedule", "qualification_schedule")
        for row in read_json(checked(plan[name]))
    }
    assert len(ids) == 488
    source_dir = PREVIOUS / "review"
    sources = {
        name: reference(source_dir / (name + ".json"))
        for name in ("result", "double-gap", "wire-transfer")
    }
    prior = {name: read_json(checked(ref)) for name, ref in sources.items()}
    assert all(obj["endpoint"] == plan["parent_completion"] for obj in prior.values())
    for group in prior["result"]["groups"].values():
        assert ids.isdisjoint(row["source"]["source"]["id"] for row in group["rows"])
    runner = Runner(trained, floor)
    OUTPUT.mkdir()
    start = time.monotonic()
    exact_groups, boards = exact(runner, prior["result"])
    print("exact complete", time.monotonic() - start, flush=True)
    real = standing(runner, prior["result"])
    write_json(
        OUTPUT / "native.json",
        {
            "endpoint": end,
            "gain_floor_endpoint": floor_ref,
            "previous": sources["result"],
            "exact": exact_groups,
            "boards": boards,
            "standing": real,
            "driver": reference(__file__),
            "weights": "EMA correction and frozen EMA parent",
            "precision": "CUDA IEEE FP32",
            "seconds": time.monotonic() - start,
        },
    )
    print("standing complete", time.monotonic() - start, flush=True)
    for key in ("double-gap", "wire-transfer"):
        result = repeat_panel(runner, prior[key], ids, double=key == "double-gap")
        write_json(
            OUTPUT / f"{key}.json",
            result | {"previous": sources[key], "endpoint": end, "gain_floor_endpoint": floor_ref},
        )
        print(key, "complete", time.monotonic() - start, flush=True)
    write_json(
        OUTPUT / "cameras.json",
        cameras(runner)
        | {"endpoint": end, "gain_floor_endpoint": floor_ref, "driver": reference(__file__)},
    )
    print("cameras complete", time.monotonic() - start, flush=True)


if __name__ == "__main__":
    main()
