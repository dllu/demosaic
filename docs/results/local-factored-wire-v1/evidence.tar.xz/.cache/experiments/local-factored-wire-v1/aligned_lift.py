"""Attribute the learned lift with the exact projectable strong-wire direction."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_factored import ROOT, read_arrays, load, luma, metric_for_wire

FLOOR = ROOT.with_name("local-factored-wire-floor-v1")
review = reference(FLOOR / "review/native.json")
document = read_json(checked(review))
rows = []
for case in document["exact"]["wire"]["rows"]:
    args = read_arrays(case["input"])
    geometry = case["source"]["geometry"]
    metric = metric_for_wire(args, geometry)
    if not metric.gap.any():
        continue
    basis = metric.strong_basis
    np.testing.assert_allclose(basis.T @ basis, np.eye(basis.shape[1]), rtol=0, atol=1e-10)
    direction = basis @ (metric.truth[0][metric.gap] @ basis)
    direction /= np.linalg.norm(direction)

    def gap(rgb):
        return luma(rgb, args["wb"], args["matrix"])[0, 64:192, 64:192][metric.gap]

    control = gap(load(case["previous_outputs"]["wire-aligned"]))
    candidate = gap(load(case["outputs"]["gain-floor"]))
    exact = gap(args["target"])
    delta = candidate - control
    parallel = direction * (delta @ direction)
    rms = lambda x: float(65535 * np.sqrt(np.mean(x**2)))
    power = {
        "total_lift_sum_squares": float(delta @ delta),
        "aligned_lift_sum_squares": float(parallel @ parallel),
    }
    rows.append(
        {
            "source": case["source"],
            "input": case["input"],
            "gap_pixels": int(metric.gap.sum()),
            "control": case["previous_outputs"]["wire-aligned"],
            "candidate": case["outputs"]["gain-floor"],
            "power": power,
            "control_gap_RMS_DN16": rms(control - exact),
            "learned_gap_RMS_DN16": rms(candidate - exact),
            "only_aligning_the_learned_lift_gap_RMS_DN16": rms(control + parallel - exact),
            "lift_RMS_DN16": rms(delta),
            "aligned_lift_RMS_DN16": rms(parallel),
            "aligned_lift_percent_of_energy": 100
            * power["aligned_lift_sum_squares"]
            / power["total_lift_sum_squares"],
        }
    )
assert len(rows) == 12
summary = {
    name: float(np.mean([row[name] for row in rows]))
    for name in (
        "control_gap_RMS_DN16",
        "learned_gap_RMS_DN16",
        "only_aligning_the_learned_lift_gap_RMS_DN16",
        "lift_RMS_DN16",
        "aligned_lift_RMS_DN16",
        "aligned_lift_percent_of_energy",
    )
}
summary["pooled_aligned_lift_percent_of_energy"] = (
    100
    * sum(r["power"]["aligned_lift_sum_squares"] for r in rows)
    / sum(r["power"]["total_lift_sum_squares"] for r in rows)
)
write_json(
    ROOT / "aligned-lift.json",
    {
        "review": review,
        "driver": reference(__file__),
        "rows": rows,
        "summary": summary,
        "scope": "Exact target direction supplied for diagnosis only. Project the delivered lift with its "
        "actual learned signed coefficient. No inference selection or tuning.",
    },
)
print(summary)
