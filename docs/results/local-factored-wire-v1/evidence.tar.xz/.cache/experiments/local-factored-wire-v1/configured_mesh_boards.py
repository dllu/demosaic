"""Render the designated cab ROIs at the configuration's linear display exposure."""

from pathlib import Path

import numpy as np
import torch

from demosaic.color import linear_to_srgb, srgb_to_linear
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from review_factored import ROOT, KEYS, load, native_png, old_pixels, read_arrays

FLOOR = ROOT.with_name("local-factored-wire-floor-v1")
CONFIG = Path("configs/gfx-green-mesh-20231231.json")
BASELINE = ROOT.with_name("scene-context-native-review-v1") / "parent/collection-recovered.json"


def pixels(rgb):
    return np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    previous = reference(ROOT / "review/native.json")
    floor = reference(FLOOR / "review/native.json")
    config = read_json(CONFIG)
    baseline = read_json(BASELINE)
    assert (
        baseline["checkpoint"]["sha256"]
        == "a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb"
    )
    by_id = {r["id"]: r for r in baseline["records"]}
    first = {r["id"]: r for r in read_json(checked(previous))["standing"]}
    folder = ROOT / "configured-mesh"
    folder.mkdir()
    output = []
    for case in read_json(checked(floor))["standing"]:
        if not case["id"].startswith("mesh-"):
            continue
        old = first[case["id"]]
        assert case["input"] == old["input"] and case["noise"] == old["noise"]
        assert case["raw"] == config["sources"]["noisy"]
        assert case["native_sensor_box"] == config["raw_context_xywh"]
        region = next(r for r in config["regions"] if case["id"].endswith(r["name"]))
        assert case["roi"] == region["ROI_xywh"]
        identifier = case["id"].removesuffix("-" + region["name"])
        archive = read_arrays(case["input"])
        comparator = by_id[identifier]
        assert all(fingerprint(archive[k]) == comparator["input_fingerprints"][k] for k in KEYS)
        arrays = {
            "Noisy (Malvar)": archive["noisy_rgb"],
            "V120 EMA": load(comparator["prediction"]),
            "Aligned control": load(case["previous_outputs"]["wire-aligned"]),
            "Continuing-wire loss": load(case["previous_outputs"]["strong-gap"]),
            "Direct correction": load(old["outputs"]["direct"]),
            "Band-limited correction": load(case["outputs"]["band-limited"]),
            "0.25 gain floor": load(case["outputs"]["gain-floor"]),
            "ISO100 AHD reference": archive["reference_rgb"],
        }

        def render(exposure):
            fields = {
                key: pixels(
                    display_crop(
                        torch.from_numpy(value),
                        torch.from_numpy(archive["wb"]),
                        torch.from_numpy(archive["matrix"]),
                        case["roi"],
                        exposure=exposure,
                    )
                )
                for key, value in arrays.items()
            }
            for key, label in (
                ("noisy_camera_jpeg", "ISO6400 camera JPEG"),
                ("reference_camera_jpeg", "ISO100 camera JPEG"),
            ):
                rgb = load(region["camera_JPEGs"][key]["pixels"]).astype(np.float32) / 255
                fields[label] = pixels(
                    linear_to_srgb(np.clip(srgb_to_linear(rgb) * exposure, 0, 1))
                )
            return fields

        old_pixels_initial = old_pixels(old["board"])
        old_pixels_floor = old_pixels(case["board"])
        for label, field in render(case["exposure"]).items():
            expected = (old_pixels_floor if label in old_pixels_floor else old_pixels_initial)[
                label
            ]
            np.testing.assert_array_equal(field, expected)
        display_exposure = config["display_exposure"]
        display = render(display_exposure)
        ordered = ["ISO6400 camera JPEG", *arrays, "ISO100 camera JPEG"]
        board = native_png(
            folder / (case["id"] + "-configured.png"),
            [(label, display[label]) for label in ordered],
        )
        output.append(
            {
                "id": case["id"],
                "board": board,
                "input": case["input"],
                "noise": case["noise"],
                "capture": case["raw"],
                "region": region,
                "native_box": case["native_sensor_box"],
                "display_exposure": display_exposure,
                "aligned_parent": case["previous_outputs"]["wire-aligned"],
                "full_trunk": case["previous_outputs"]["strong-gap"],
                "V120": comparator["prediction"],
                "Direct": old["outputs"]["direct"],
                "Band_limited": case["outputs"]["band-limited"],
                "Gain_floor": case["outputs"]["gain-floor"],
            }
        )
    assert len(output) == 4
    write_json(
        folder / "result.json",
        {
            "initial_review": previous,
            "gain_floor_review": floor,
            "driver": reference(__file__),
            "V120_source": reference(BASELINE),
            "config": reference(CONFIG),
            "boards": output,
            "historical_exposure_reconstructed_pixel_exactly": True,
        },
    )


if __name__ == "__main__":
    main()
