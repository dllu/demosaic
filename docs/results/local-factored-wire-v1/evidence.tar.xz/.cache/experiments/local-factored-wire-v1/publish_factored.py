"""Publish immutable receipts, displayed native crops and complete scoped results."""

from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from train_factored_detail import ancestor_plans

ROOT = Path(__file__).resolve().parent
FLOOR = ROOT.with_name("local-factored-wire-floor-v1")
RESULTS = Path("docs/results") / ROOT.name
IMAGES = Path("docs/images") / ROOT.name


def training(root):
    train = reference(root / "training/completed.json")
    qual = reference(root / "qualification/completed.json")
    t, q = (read_json(checked(r)) for r in (train, qual))
    p = read_json(checked(t["plan"]))
    verify_plan(p)
    assert t["plan"] == q["plan"] and t["parent"] == q["parent"] == p["parent"]
    assert not t["qualification"] and q["qualification"] and p["id"] == root.name
    assert len(p["arms"]) == (1 if root == FLOOR else 2)
    records = [train, qual, t["plan"], p["driver"]]
    earlier = {
        r["source"]["id"]
        for _, plan in ancestor_plans(checked(p["parent_completion"]))
        for name in ("schedule", "qualification_schedule")
        for r in read_json(checked(plan[name]))
    }
    assert len(earlier) == p["excluding_distinct_prior_ids"]
    visits = {}
    for phase, name, steps in ((t, "schedule", 480), (q, "qualification_schedule", 8)):
        assert phase["frozen_parent"] and set(phase["checkpoints"]) == set(p["arms"])
        assert phase["updates_per_arm"] == phase["source_photos_per_arm"] == steps
        assert phase["native_observations_per_arm"] == steps * 6
        for binding in phase["checkpoints"].values():
            checked(binding)
        records.extend([p[name], phase["observations"], phase["log"]])
        cases = read_json(checked(p[name]))
        observed, losses = (
            list(map(json.loads, checked(phase[k]).read_text().splitlines()))
            for k in ("observations", "log")
        )
        assert len(cases) == len(observed) == len(losses) == steps
        strata, continuations = Counter(), Counter()
        for row, actual, loss in zip(cases, observed, losses, strict=True):
            ident = row["source"]["id"]
            assert ident == actual["source_id"] and ident not in earlier
            earlier.add(ident)
            assert row["source"]["split"] == "train"
            assert row["source"]["cache_sha256"] == actual["cache_sha256"]
            assert len(set(actual["seeds"].values())) == 8
            assert (row["iso"], row["law"], row["pattern"], row["kind"]) == (
                actual["iso"],
                actual["law"],
                actual["camera"]["pattern"],
                actual["kind"],
            )
            strata[row["iso"], row["law"], row["pattern"], row["kind"]] += 1
            if row["kind"] == "wire":
                continuing = row["strong_continues"]
                assert actual["geometry"]["wire"]["strong_continues"] == continuing
                continuations[continuing] += 1
            for arm in phase["checkpoints"]:
                assert np.isfinite(list(loss[arm].values())).all()
        if steps == 480:
            assert len(strata) == 32 and set(strata.values()) == {15}
            assert continuations == {True: 192, False: 48}
        visits[name] = {
            "valid_pair_cores": phase["valid_core_pairs"],
            "continuing_wires": continuations[True],
            "double_gaps": continuations[False],
        }
    records.extend(
        reference(Path(p["driver"]["path"]).parent.parent / name)
        for name in (
            "src/demosaic/factored_detail.py",
            "scripts/train_local_paired_continuation.py",
        )
    )
    return (
        t | {"completion": train, "qualification_receipt": qual, "recipe_detail": visits},
        records,
    )


def board(source, category):
    file = checked(source["image"])
    dst = IMAGES / category / file.parent.name / file.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(file, dst)
    assert reference(dst)["sha256"] == source["image"]["sha256"]
    with Image.open(dst) as image:
        for panel in source["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert w == h == 160
            assert 0 <= x < x + w <= image.width and 0 <= y < y + h <= image.height
    return source | {"image": source["image"] | {"path": str(dst.relative_to(IMAGES))}}


def publish(audit, records):
    initial, floor = audit["initial"], audit["gain_floor"]
    assert initial["parent"] == floor["parent"]
    q0 = read_json(checked(initial["qualification_receipt"]))
    q1 = read_json(checked(floor["qualification_receipt"]))
    for a, b in ((initial, floor), (q0, q1)):
        assert a["observations"]["sha256"] == b["observations"]["sha256"]
    notes = reference(ROOT / "viewing-notes.json")
    records.append(notes)
    viewed = read_json(checked(notes))
    manifest, summaries = {}, {}
    for category, root in (("initial", ROOT), ("gain_floor", FLOOR)):
        path = root / "review"
        refs = {
            k: reference(path / (k + ".json"))
            for k in (
                "native",
                "double-gap",
                "wire-transfer",
                "cameras",
            )
        }
        records.extend(refs.values())
        docs = {key: read_json(checked(ref)) for key, ref in refs.items()}
        native = docs["native"]
        floor_ref = floor["completion"] if category == "gain_floor" else None
        assert all(
            v["endpoint"] == initial["completion"] and v["gain_floor_endpoint"] == floor_ref
            for v in docs.values()
        )
        assert len(native["boards"]) == 4 and len(native["standing"]) == 8
        assert len(docs["double-gap"]["rows"]) == len(docs["wire-transfer"]["rows"]) == 16
        assert {k: len(v) for k, v in docs["cameras"]["rows"].items()} == {
            "known": 24,
            "unseen": 30,
        }
        exact, standing = [], []
        for crop in native["boards"]:
            exact.append(crop | {key: board(crop[key], category) for key in ("board", "triplet")})
        for crop in native["standing"]:
            standing.append(crop | {"board": board(crop["board"], category)})
        for kind, items in (("exact", exact), ("standing", standing)):
            assert set(viewed[category][kind]) == {item["id"] for item in items}
        manifest[category] = {
            "source": refs["native"],
            "exact": exact,
            "standing": standing,
            "viewed": viewed[category],
        }
        summaries[category] = {
            "receipts": refs,
            "exact": {k: v["summary"] for k, v in native["exact"].items()},
            "double_gap": docs["double-gap"]["summary"],
            "redraws": docs["wire-transfer"]["summary"],
            "cameras": docs["cameras"]["summary"],
            "standing": {c["id"]: {key: c[key] for key in ("delivered", "gate")} for c in standing},
        }

    RESULTS.mkdir(parents=True, exist_ok=True)
    configured = reference(ROOT / "configured-mesh/result.json")
    mesh = read_json(checked(configured))
    assert mesh["gain_floor_review"] == manifest["gain_floor"]["source"]
    assert mesh["initial_review"] == manifest["initial"]["source"]
    assert mesh["historical_exposure_reconstructed_pixel_exactly"]
    mesh_notes = reference(ROOT / "configured-mesh/viewing.json")
    seen_mesh = read_json(checked(mesh_notes))
    assert seen_mesh["review"] == configured
    assert set(seen_mesh["crops"]) == {c["id"] for c in mesh["boards"]}
    assert len(mesh["boards"]) == 4
    manifest["configured_mesh"] = {
        "source": configured,
        "viewing": mesh_notes,
        "boards": [c | {"board": board(c["board"], "configured")} for c in mesh["boards"]],
    }
    lift = reference(ROOT / "aligned-lift.json")
    attribution = read_json(checked(lift))
    assert attribution["review"] == manifest["gain_floor"]["source"]
    attribution_path = RESULTS / "aligned-lift.json"
    shutil.copyfile(checked(lift), attribution_path)
    assert reference(attribution_path)["sha256"] == lift["sha256"]
    training_ref = RESULTS / "training.json"
    write_json(training_ref, audit | {"ordered_observations_identical": True})
    crop_ref = IMAGES / "manifest.json"
    write_json(
        crop_ref,
        manifest
        | {
            "training": reference(training_ref),
            "viewing_notes": notes,
            "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "checkpoint_composition": "Correction EMA on the Aligned Control EMA. CUDA IEEE FP32.",
            "references": "The ISO100 AHD and JPEG are independently exposed qualitative references.",
        },
    )
    archive = RESULTS / "evidence.tar.xz"
    sources = [
        reference(__file__),
        reference(ROOT / "review_factored.py"),
        reference(training_ref),
        *(reference(root / "review.log") for root in (ROOT, FLOOR)),
        reference(ROOT / "prepare_views.py"),
        attribution["driver"],
        lift,
        configured,
        mesh["driver"],
        mesh_notes,
    ]
    with tarfile.open(archive, "x:xz", preset=4) as target:
        for proof in {r["path"]: r for r in [*records, *sources]}.values():
            p = checked(proof)
            target.add(p, arcname=str(p.relative_to(Path.cwd())), recursive=False)
    write_json(
        RESULTS / "publication.json",
        {
            "training": reference(training_ref),
            "native": reference(crop_ref),
            "archive": reference(archive),
            "aligned_lift": reference(attribution_path),
            "training_complete": True,
            "scoped_metrics_complete": True,
            "native_image_view_complete": True,
            "fixed_camera_panels_complete": True,
            "configured_cab_native_boards_viewed": True,
            "fixed_427_complete": False,
            "fixed_427_scope": "Scoped frozen-component study. No broad-photo replay performed.",
            "results": summaries,
        },
    )


if __name__ == "__main__":
    original, original_refs = training(ROOT)
    replay, replay_refs = training(FLOOR)
    publish({"initial": original, "gain_floor": replay}, original_refs + replay_refs)
