"""Wait for the owned retained-checkpoint review and independently verify its artifacts."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil
from demosaic.experiments.artifacts import read_json,reference,write_json

root=Path(__file__).resolve().parent
work=root/"work"
parent=read_json(root/"launch.json")
finished=root/"completed.json"
deadline=time.monotonic()+6000
while not finished.exists():
    process=psutil.Process(parent["pid"])
    assert process.create_time()==parent["create_time"] and process.status()!=psutil.STATUS_ZOMBIE
    if time.monotonic()>deadline:
        raise TimeoutError("Observation deadline; original training and review remain independent.")
    time.sleep(5)
assert read_json(finished)["control_predictions_bitexact"]==220
env={**os.environ, "CUDA_VISIBLE_DEVICES":"",
     "PYTHONPATH":f"{work}/scripts:{work}/src:scripts","OPENBLAS_NUM_THREADS":"2","OMP_NUM_THREADS":"2"}
cmd=[sys.executable,str(root/"independent-native-audit.py")]
with (root/"independent-native-audit.log").open("xb") as log:
    child=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
write_json(root/"independent-native-audit-return.json",{
    "returncode":child.returncode,"driver":reference(root/"independent-native-audit.py"),
    "completed_review":reference(finished),
})
assert child.returncode==0
