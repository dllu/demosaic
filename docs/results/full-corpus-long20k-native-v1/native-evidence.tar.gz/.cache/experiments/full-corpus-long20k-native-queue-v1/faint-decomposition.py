"""Split the retained faint-target error into channel mean and spatial terms."""

from pathlib import Path
from statistics import mean
import numpy as np

from analyze_retained_faint_detail import error_components
from demosaic.archive_metrics import display, linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root=Path(__file__).resolve().parent
plan=read_json(root/"plan.json")
collection=read_json(root/"collection/result.json")
records={read_json(checked(v))["id"]:read_json(checked(v)) for v in collection["records"]}
rows=[]
for case in plan["observations"]:
    if case["kind"]!="material" or "contrast0p025-adc" not in case["case_id"]:
        continue
    x,y,w,h=case["ROI_xywh"]
    roi=np.s_[...,y:y+h,x:x+w]
    with np.load(checked(case["arrays"])) as data:
        arrays={k:data[k] for k in ("wb","matrix")}
    with np.load(checked(case["target"])) as ref:
        target=ref["target"][roi].astype(np.float64)
    for v in records[case["id"]]["variants"]:
        prediction=np.load(checked(v["prediction"]))[roi].astype(np.float64)
        for space, convert in [
            ("camera_RGB",lambda n:n),
            ("linear_sRGB",lambda n:linear_rgb(n,arrays)),
            ("clipped_sRGB",lambda n:display(n,arrays)),
        ]:
            terms=error_components(convert(prediction),convert(target))
            np.testing.assert_allclose(terms["MSE"],terms["DC_MSE"]+terms["spatial_MSE"],rtol=1e-12,atol=1e-25)
            rows.append({"id":case["id"],"variant":v["label"],"space":space,**terms})
assert len(rows)==144
results={}
for space in ("camera_RGB","linear_sRGB","clipped_sRGB"):
    results[space]={}
    for method in ("V120","scale-control20k","scale-long20k"):
        values=[r for r in rows if r["space"]==space and r["variant"]==method]
        assert len(values)==16
        results[space][method]={k:mean(r[k] for r in values) for k in ("MSE","DC_MSE","spatial_MSE")}
write_json(root/"report/faint-decomposition.json",{
    "producer":reference(__file__),"collection":reference(root/"collection/result.json"),
    "rows":rows,"means":results,"scope":"All16 retained faint-ADC cases. Arithmetic16-case MSE of each space"
      " decomposed into channel-mean DC and centered spatial MSE. Aggregation differs from mean PSNR."
})
for k,v in results.items():print(k,v)
