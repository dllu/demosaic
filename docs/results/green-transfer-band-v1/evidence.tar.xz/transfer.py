"""Select the delivered change in bands predicted to gain or lose input power."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32

ROOT = Path(__file__).resolve().parent
CONTEXT = ROOT.parent / "context-strength-v1"
GREEN = ROOT.parent / "green-phase-innovation-v1"
sys.path[:0] = [str(CONTEXT), str(GREEN)]
from collect import ARGS, as_cuda, bind_models, channel_coefficients, contrast, inputs, moments
from edge_delivery import detail, quiet, paired_gates
from phase_innovation import lift

ROUTES = ("same-phase", "all-bands", "lower-transfer", "higher-transfer")


def split(signal):
    """Reflect-pad the candidate difference and split by analytic RAW transfer."""
    native = F.pad(signal, (16, 16, 16, 16), mode="reflect")
    dims = native.shape[-2:]
    k0 = (2 * torch.pi) * torch.fft.fftfreq(dims[0], device=signal.device)
    k1 = (2 * torch.pi) * torch.fft.rfftfreq(dims[1], device=signal.device)
    u, v = k0[:, None], k1[None, :]
    same = 0.5 + (1 + 2 * torch.cos(2 * u)) * (1 + 2 * torch.cos(2 * v)) / 18
    cross = (
        10 + 2 * torch.cos(2 * u) + 2 * torch.cos(2 * v) + 4 * torch.cos(u) * torch.cos(v)
    ) / 18
    radial = torch.sqrt(u**2 + v**2) / (2 * torch.pi)
    admit = ((radial - 0.08) / 0.05).clamp(0, 1) * ((0.38 - radial) / 0.06).clamp(0, 1)
    transform = torch.fft.rfft2(native)
    output = []
    for difference in (same - cross, cross - same):
        gate = ((difference - 0.02) / 0.08).clamp(0, 1) * admit
        filtered = torch.fft.irfft2(transform * gate, s=dims)
        output.append(filtered[..., 16:-16, 16:-16])
    return output


def predict(head, inputs, base, limits):
    wide, shared = paired_gates(*inputs[:3], *limits)
    calm, neutral = quiet(head, base, inputs, wide)
    anchor = base + calm
    old = detail(head, base, inputs, shared)
    all_bands = lift(head, base, inputs, shared)
    low, high = split(all_bands - old)
    color = neutral[:, :, None, None]
    return {
        "parent": base,
        "quiet": anchor,
        "same-phase": anchor + color * old,
        "all-bands": anchor + color * all_bands,
        "lower-transfer": anchor + color * (old + low),
        "higher-transfer": anchor + color * (old + high),
    }


def compare(plan, rows):
    result = {}
    rng = np.random.default_rng(24898)
    for profile in ("iso400", "iso6400"):
        selected = [r for r in rows if r["profile"] == profile]
        fit = [r for r in selected if r["index"] < 32 and r["draw"] == "coupled"]
        assert len(fit) == 32
        gains = {key: sum(r["scores"][key]["score"][1] for r in fit) for key in ROUTES}
        scales = (
            {key: min(gains.values()) / value for key, value in gains.items()}
            if min(gains.values()) > 0
            else {}
        )
        if scales:
            assert all(
                abs(contrast(fit, k, "same-phase", scales, rng)["response_pp"][0]) < 1e-10
                for k in ROUTES
            )
        result[profile] = {"gain_calibration": gains, "scales": scales, "draw": {}}
        for draw in ("coupled", "independent"):
            test = [r for r in selected if r["index"] >= 32 and r["draw"] == draw]
            assert len(test) == 32
            result[profile]["draw"][draw] = {
                key: {
                    "matched": contrast(test, key, "same-phase", scales, rng),
                    "nominal": contrast(test, key, "same-phase", {}, rng),
                }
                for key in (*ROUTES[1:], "parent", "quiet")
            }
    return result


@torch.inference_mode()
def run(smoke):
    torch.set_num_threads(2)
    stamp = reference(ROOT / "plan.json")
    plan = read_json(checked(stamp))
    assert plan["driver"] == reference(__file__)
    trial = read_json(checked(plan["physical_panel"]))
    parents = read_json(checked(trial["parents"]))
    panel = read_json(checked(trial["panel"]))
    head, limits = bind_models(read_json(checked(trial["frozen_composition"])))
    rows = []
    start = time.monotonic()
    with ieee_fp32():
        for record in parents["records"][: 4 if smoke else None]:
            case, native, parent = inputs(record)
            args = as_cuda(
                {
                    key: native[key]
                    if key in ("packed", "variance")
                    else np.broadcast_to(native[key], (3, *native[key].shape))
                    for key in ARGS
                }
            )
            base = torch.from_numpy(parent).cuda().contiguous(memory_format=torch.channels_last)
            fields = {
                key: np.broadcast_to(native[key], (3, *native[key].shape))
                for key in ("wb", "matrix")
            }
            predictions = {
                key: v.cpu().numpy() for key, v in predict(head, args, base, limits).items()
            }
            scores = {
                key: channel_coefficients(v, fields, panel["score_ROI_xywh"])[1]
                for key, v in (predictions | {"GT": native["target"]}).items()
            }
            rows.append(
                {
                    "id": case["id"],
                    "index": case["case"],
                    "profile": case["profile"]["name"],
                    "draw": case["draw"],
                    "scores": {
                        k: moments(scores["quiet"], scores[k], scores["GT"]) for k in predictions
                    },
                }
            )
            if len(rows) % 32 == 0 or smoke:
                print(len(rows), round(time.monotonic() - start, 2), flush=True)
    assert len(rows) == (4 if smoke else 256)
    write_json(
        ROOT / ("smoke.json" if smoke else "result.json"),
        {
            "plan": stamp,
            "rows": rows,
            "metrics": None if smoke else compare(plan, rows),
            "seconds": time.monotonic() - start,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "smoke", "run"))
    mode = parser.parse_args().mode
    if mode == "freeze":
        write_json(
            ROOT / "plan.json",
            {
                "driver": reference(__file__),
                "physical_panel": reference(CONTEXT / "plan.json"),
                "native_filter": reference(GREEN / "phase_innovation.py"),
                "basis_analysis": reference(GREEN / "orientation.json"),
                "scope": "Separate 64-photo panel from the weak-edge filter-development panel. Fixed Fourier taper of candidate differences with reflect padding. Compare at separate source-matched response. Unchanged quiet anchor and no new training.",
            },
        )
    else:
        run(mode == "smoke")
