"""Render the delivered narrowband comparison on exact and standing inputs."""

import numpy as np
import torch

from transfer import ROOT, ROUTES, ARGS, as_cuda, bind_models, inputs, predict
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board
from collect import value
import render_repeat

LABEL = {
    "parent": "Corpus 100k EMA",
    "quiet": "Quiet path",
    "same-phase": "Same-phase smoothing",
    "all-bands": "Native-green smoothing",
    "lower-transfer": "Lower-transfer bands",
    "higher-transfer": "Higher-transfer bands",
}


def render_exact(head, limits, archive, rows, panel, scales, destination):
    parent = {r["id"]: r for r in archive["records"]}
    chosen = [
        r
        for r in rows
        if r["index"] >= 32 and r["profile"] == "iso6400" and r["draw"] == "independent"
    ]
    assert len(chosen) == 32

    def diff(r, k):
        return (
            value(r["scores"]["lower-transfer"], scales["lower-transfer"])[k]
            - value(r["scores"]["same-phase"], scales["same-phase"])[k]
        )

    rank = sorted(chosen, key=lambda r: diff(r, "increment"))
    examples = [
        (rank[0], 0, "Largest fine-increment improvement on the separate test subset."),
        (rank[-1], 0, "Largest fine-increment regression on the separate test subset."),
        (
            max(chosen, key=lambda r: diff(r, "flat")),
            2,
            "Largest increase in exact-flat variation.",
        ),
    ]
    boards = []
    for row, role, selection in examples:
        case, raw, base = inputs(parent[row["id"]])
        args = as_cuda(
            {
                k: raw[k]
                if k in ("packed", "variance")
                else np.broadcast_to(raw[k], (3, *raw[k].shape))
                for k in ARGS
            }
        )
        outputs = restore(head, args, {"100k": base}, limits, scales)
        fields = {
            k: raw[k][role : role + 1] if k in ("packed", "variance") else raw[k][None]
            for k in ARGS
        }
        names = tuple(LABEL)
        images = [noisy_malvar(fields)[0], *[outputs[k][role] for k in names], raw["target"][role]]
        item = panel["rows"][case["case"]]
        boards.append(
            native_board(
                destination,
                f"{row['id']}-role{role}",
                images,
                fields,
                {
                    "selection": selection,
                    "source_photo": item["source"],
                    "query_xywh": case["box"],
                    "CFA": item["camera"]["pattern"],
                    "profile": case["profile"],
                    "role": role,
                    "observation": parent[row["id"]]["source"],
                },
                labels=("Noisy Malvar", *LABEL.values(), "Exact GT"),
                triplet_indices=(0, names.index("lower-transfer") + 1, len(images) - 1),
                exposure=1 / case["profile"]["exposure"],
                contrast=2,
                roi=tuple(panel["native_display_ROI_xywh"]),
            )
        )
    return boards


def restore(head, args, baseline, limits, scales):
    model = torch.from_numpy(baseline["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    pred = predict(head, args, model, limits)
    base = pred["quiet"]
    return baseline | {
        name: (base + scales[name] * (output - base) if name in scales else output).cpu().numpy()
        for name, output in pred.items()
    }


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    bound = reference(ROOT / "result.json")
    result = read_json(checked(bound))
    plan = read_json(checked(result["plan"]))
    ref = read_json(checked(plan["physical_panel"]))
    parents = read_json(checked(ref["parents"]))
    panel = read_json(checked(ref["panel"]))
    frozen = read_json(checked(ref["frozen_composition"]))
    head, limits = bind_models(frozen)
    scales = result["metrics"]["iso6400"]["scales"]
    destination = ROOT / "native"
    destination.mkdir()
    render_repeat.SHOW = ROUTES
    render_repeat.DISPLAY = LABEL
    render_repeat.predictions = lambda h, a, p, l: restore(h, a, p, l, scales)
    with ieee_fp32():
        a = render_exact(head, limits, parents, result["rows"], panel, scales, destination)
        b = render_repeat.show_camera(head, limits, destination)
    write_json(
        destination / "render.json",
        {
            "result": bound,
            "driver": reference(__file__),
            "photos": a,
            "standing": b,
            "parent": frozen["models"]["Corpus 100k"],
            "correction": frozen["initial_head"],
            "scales": scales,
            "actual_native_viewing_complete": False,
        },
    )


if __name__ == "__main__":
    run()
