"""Replay the completed local 50k EMA on the exact and standing 47.5k inputs."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
BEFORE=ROOT.with_name('local-band-mixture-v1')
sys.path.insert(0,str(BEFORE))
import collect_local
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

COMPLETE=Path('docs/results/scene-full-epoch-v1/local-050000-training.json')
STANDING=ROOT.with_name('green-covariance-refit-v1')/'transport-standing.json'


def restore(model,args,profile):
    model.base.set_noise(profile['shot'],profile['read'])
    query=[torch.from_numpy(args[key]).cuda().contiguous(memory_format=torch.channels_last)for key in ('packed','variance')]
    count=len(query[0])
    query.extend(torch.from_numpy(args[k]).cuda()[None].expand(count,*args[k].shape)for k in ('colors','wb','matrix'))
    start=time.monotonic()
    with ieee_fp32():
        result=model(*query).cpu().numpy()
    assert result.shape==(count,3,2*args['packed'].shape[-2],2*args['packed'].shape[-1])
    assert np.isfinite(result).all()
    return result,time.monotonic()-start


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    endpoint=reference(COMPLETE)
    finished=read_json(checked(endpoint))
    captured=reference(BEFORE/'confirmation.json')
    earlier=read_json(checked(captured))
    refs=reference(STANDING)
    previous=read_json(checked(refs))
    plan=read_json(checked(earlier['plan']))
    checkpoint=finished['checkpoint']
    document=dict(endpoint=endpoint,checkpoint=checkpoint,weights='ema',
                  previous=plan['checkpoints'],exact_capture=captured,standing=refs,
                  precision='CUDA IEEE FP32 EMA',fixed_inputs=True)
    locked=ROOT/'plan.json'
    write_json(locked,document)
    model,loaded=load_scene_checkpoint(checked(checkpoint),device='cuda',weights='ema',expected_sha256=checkpoint['sha256'])
    assert loaded['loaded_sha256']==checkpoint['sha256'] and loaded['step']==50000 and loaded['mode']=='none'
    model.eval().to(memory_format=torch.channels_last)
    out=ROOT/'predictions'
    out.mkdir(exist_ok=True)
    query_keys=('packed','variance','colors','wb','matrix')
    rows=[]
    started=time.monotonic()
    forward=0.
    for item in earlier['rows']:
        with np.load(checked(item['input']),allow_pickle=False)as src:
            data={key:src[key]for key in query_keys}
        rgb,duration=restore(model,data,plan['profile'])
        forward+=duration
        path=out/f"{item['source']['index']:02d}.npy"
        np.save(path,rgb,allow_pickle=False)
        rows.append(dict(index=item['source']['index'],input=item['input'],outputs=reference(path),forward_seconds=duration))
        if len(rows)%12==0:
            print(len(rows),round(time.monotonic()-started,2),flush=True)
    assert len(rows)==48
    wall=0.
    cache={}
    cameras=[]
    for item in previous['rows']:
        key=item['input']['sha256'],str(item['noise'])
        if key not in cache:
            with np.load(checked(item['input']),allow_pickle=False)as src:
                data={key:src[key] for key in query_keys}
            data.update({k:data[k][0]for k in ('colors','wb','matrix')})
            rgb,duration=restore(model,data,item['noise'])
            wall+=duration
            path=out/f"{item['id']}.npy"
            np.save(path,rgb,allow_pickle=False)
            cache[key]=reference(path)
        cameras.append(dict(id=item['id'],input=item['input'],raw=item['raw'],noise=item['noise'],
            roi=item['roi'],exposure=item['exposure'],box=item['native_sensor_box'],prediction=cache[key]))
    assert len(cameras)==8
    write_json(ROOT/'model-results.json',dict(driver=reference(__file__),plan=reference(locked),exact=rows,
            standing=cameras,exact_forward_seconds=forward,standing_forward_seconds=wall,wall_seconds=time.monotonic()-started))
    print('endpoint',forward,wall,flush=True)


if __name__=='__main__':
    main()
