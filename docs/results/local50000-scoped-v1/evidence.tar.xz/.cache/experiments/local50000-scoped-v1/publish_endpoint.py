"""Bind the scoped 50k local quality review to its exact training endpoint."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from replay import ROOT,BEFORE,COMPLETE
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

RESULTS=Path('docs/results')/ROOT.name
IMAGES=Path('docs/images')/ROOT.name


def save_view(board):
    file=checked(board['image'])
    name=Path(file.parent.name)/file.name
    out=IMAGES/name
    out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(file,out)
    assert reference(out)['sha256']==board['image']['sha256']
    image=np.asarray(Image.open(out).convert('RGB'))
    cells={}
    for row in board['panels']:
        x,y,w,h=row['png_xywh']
        assert (w,h)==(160,160)
        cells[row.get('label',row.get('name'))]=image[y:y+h,x:x+w]
    board['image']['path']=str(name)
    return cells


def main():
    RESULTS.mkdir(parents=True,exist_ok=True)
    sources={key:reference(ROOT/f'{key}.json')for key in ('plan','model-results','review')}
    recipe,model,native=(read_json(checked(sources[key]))for key in sources)
    ready_ref=reference(COMPLETE)
    ready=read_json(checked(ready_ref))
    assert ready_ref==recipe['endpoint'] and ready['checkpoint']==native['checkpoint']==recipe['checkpoint']
    assert recipe['weights']=='ema' and ready['training_complete']
    assert native['replay']==sources['model-results'] and model['plan']==sources['plan']
    assert len(native['standing'])==8 and len(native['exact'])==3
    assert len(native['wire'])==len(native['photo'])==24
    checked(ready['checkpoint'])
    archived=deepcopy(native)
    for item in archived['standing']:
        pixels=save_view(item['board'])
        assert 'Local 50k EMA'in pixels and 'ISO100 AHD reference'in pixels
        if item['id'].startswith('mesh-'):
            assert 'ISO100 camera JPEG'in pixels and 'ISO6400 camera JPEG'in pixels
    for item in archived['exact']:
        board=save_view(item['board'])
        triplet=save_view(item['triplet'])
        assert list(triplet)==['Noisy Malvar','Local 50k EMA','Exact GT']
        assert all(np.array_equal(im,board[name]) for name,im in triplet.items())
    view=IMAGES/'manifest.json'
    manifest={key:archived[key] for key in ('scoped','checkpoint','exact','standing') if key in archived}
    write_json(view,{**manifest,'review':sources['review'],'previous_checkpoints':recipe['previous'],
                    'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    archive=RESULTS/'evidence.tar.xz'
    candidates=[*ROOT.glob('*.py'),*ROOT.glob('*.log'),*(checked(binding)for binding in sources.values()),
        checked(ready_ref),checked(recipe['exact_capture']),checked(recipe['standing']),
        BEFORE/'review_local.py',BEFORE/'fit_local.py',BEFORE/'collect_local.py',Path('src/demosaic/scene_inference.py'),
        Path('scripts/report_scene_wave_guides.py'),Path('configs/gfx-qualitative-20231231.json'),
        Path('configs/gfx-green-mesh-20231231.json')]
    files={str(p.absolute().relative_to(Path.cwd())):p for p in candidates}
    with tarfile.open(archive,'x:xz',preset=4)as tar:
        for name,p in sorted(files.items()):
            tar.add(p,arcname=name,recursive=False)
    with tarfile.open(archive)as tar:
        for name,p in files.items():
            with tar.extractfile(name)as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==reference(p)['sha256']
    write_json(RESULTS/'publication.json',dict(sources=sources,endpoint=ready_ref,checkpoint=ready['checkpoint'],
               weights=recipe['weights'],previous_checkpoints=recipe['previous'],views=reference(view),
               scope=native['scope'],training_complete=True,scoped_numerical_complete=True,scoped_native_complete=True,
               fixed_photo_and_camera_complete=False,summary=native['summary'],
               exact_inference_seconds=model['exact_forward_seconds'],standing_inference_seconds=model['standing_forward_seconds'],
               archive=reference(archive)))
    print(len(files),len(list(IMAGES.rglob('*.png'))),flush=True)


if __name__=='__main__':
    main()
