"""Score the complete local-only endpoint on 48 exact captures and both GFX families."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import time

import numpy as np
import torch

from replay import ROOT,BEFORE
from local_band_review import photo,fine_region,flat_color
from fit_local import metric_for_wire
from upper import ROI
from native import old_pixels,native_png
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

PREVIOUS=Path('docs/images/local-band-mixture-v1/manifest.json')
END='Local 50k EMA'
LAST='Local-only 47.5k'
CORPUS='Corpus 100k'
V120='V120'


def comparisons(rows,photo_panel):
    rng=np.random.default_rng(202611191109)
    stats={}
    for comparator in (LAST,CORPUS,V120):
        metrics={}
        for key in sorted(set().union(*(row['scores'][END]for row in rows))):
            selected=[row['scores']for row in rows if row['scores'][END].get(key) is not None]
            if not selected:
                continue
            data=np.asarray([[row[name][key] for row in selected] for name in (END,comparator)])
            n=len(selected)
            indices=np.vstack((np.arange(n),rng.integers(n,size=(6500,n))))
            values=data[:,indices]
            means=np.sqrt(np.mean(values**2,axis=-1)) if photo_panel and key.endswith('RMS_DN16') else values.mean(-1)
            diff=means[0]-means[1]
            metrics[key]=dict(cases=n,candidate=float(means[0,0]),control=float(means[1,0]),
                              delta=float(diff[0]),interval=np.quantile(diff[1:],[.025,.975]).tolist())
        stats[comparator]=metrics
    return stats


def exact_views(wires,photos,profile):
    selected=[]
    known=[r for r in wires if r['gap_pixels']]
    def delta(row,key):
        return row['scores'][END][key]-row['scores'][LAST][key]
    selected.append(min(known,key=lambda x:delta(x,'gap_RMS_DN16')))
    selected.append(min(photos,key=lambda x:delta(x,'fine_increment_RMS_DN16')))
    selected.append(max(photos,key=lambda x:delta(x,'fine_increment_RMS_DN16')))
    root=ROOT/'exact'
    root.mkdir(exist_ok=True)
    rows=[]
    for case in selected:
        wire=case['source']['kind']=='wire'
        with (np.load(checked(case['input']),allow_pickle=False)as archive,
              np.load(checked(case['model_outputs']),allow_pickle=False)as prev):
            args={k:archive[k]for k in ('wb','matrix','colors','packed','target')}
            old={name:prev[key][0]for name,key in ((V120,'v120'),(CORPUS,'parent'),(LAST,'local'))}
        rgb=np.load(checked(case['endpoint_output']),allow_pickle=False)[0]
        camera={k:args[k][None]for k in ('wb','matrix','colors')}|{'packed':args['packed'][0:1]}
        results=[noisy_malvar(camera)[0],*old.values(),rgb,args['target'][0]]
        key=f"{case['source']['index']:02d}-{case['source']['kind']}-iso6400"
        rows.append(native_board(root,key,results,camera,dict(source=case['source'],query=case['box'],
                     prior_outputs=case['model_outputs'],local_50000=case['endpoint_output'],input=case['input'],profile=profile),
                     labels=('Noisy Malvar',*old,END,'Exact GT'),triplet_indices=(0,4,5),
                     exposure=2. if wire else 1/.33,contrast=1. if wire else 2.,roi=ROI))
    return rows


def camera_views(records,older,prior_proof,checkpoint):
    previous=reference(PREVIOUS)
    views=read_json(checked(previous))
    assert views['checkpoints']['local']==prior_proof['local']
    assert views['checkpoints']['parent']==prior_proof['parent']
    archive={r['id']:r for r in views['standing']['rows']}
    target=ROOT/'standing'
    target.mkdir(exist_ok=True)
    publish=[]
    for item,upstream in zip(records,older,strict=True):
        assert item['id']==upstream['id']
        before=archive[item['id']]
        assert item['input']==upstream['input']==before['input']
        assert item['raw']==upstream['raw']==before['source']
        assert item['noise']==upstream['noise']==before['noise']
        assert item['roi']==upstream['roi']==before['roi']
        assert item['exposure']==upstream['exposure']==before['exposure']
        with np.load(checked(item['input']),allow_pickle=False)as src:
            wb,matrix=(torch.from_numpy(src[k])for k in ('wb','matrix'))
        current=np.load(checked(item['prediction']),allow_pickle=False)
        with np.load(checked(upstream['predictions']),allow_pickle=False)as src:
            old=src['local']
        p=np.load(checked(upstream['parent_images']['parent100k']),allow_pickle=False)
        board=before['board']
        file=PREVIOUS.parent/board['image']['path']
        bind=reference(file)
        assert bind['sha256']==board['image']['sha256']
        pixels=old_pixels(board|{'image':bind})
        roi=item['roi']
        def display(v):
            out=display_crop(torch.from_numpy(v),wb,matrix,roi,exposure=item['exposure'])
            return np.rint(np.clip(out,0,1)*255).astype(np.uint8)
        np.testing.assert_array_equal(display(old),pixels['Local 47.5k'])
        np.testing.assert_array_equal(display(p),pixels['Parent 100k EMA'])
        labels=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Local 47.5k')
        panels=[(key,pixels[key])for key in labels if key in pixels]
        panels.append((END,display(current)))
        panels.extend((k,pixels[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in pixels)
        x,y,w,h=roi
        axis=np.s_[...,y:y+h,x:x+w]
        rms=lambda u,v:float(np.sqrt(np.mean((u[axis].astype(float)-v[axis])**2))*65535)
        output=native_png(target/f"{item['id']}.png",panels)
        publish.append(dict(item,board=output,baseline_board=bind,checkpoint=checkpoint,
                            difference=dict(vs_47500=rms(current,old),vs_corpus=rms(current,p))))
    assert len(publish)==8
    return publish


def main():
    torch.set_num_threads(2)
    start=time.monotonic()
    proof=reference(ROOT/'model-results.json')
    result=read_json(checked(proof))
    recipe=read_json(checked(result['plan']))
    checkpoint=recipe['checkpoint']
    original_ref=reference(BEFORE/'review.json')
    original=read_json(checked(original_ref))
    assert original['capture_receipt']==recipe['exact_capture']
    old_captures=read_json(checked(original['capture_receipt']))
    frozen=read_json(checked(old_captures['plan']))
    profile=frozen['profile']
    base={r['source']['index']:r for r in original['wire']+original['photo']}
    evals=[]
    for r in result['exact']:
        old=base[r['index']]
        assert old['input']==r['input']
        with np.load(checked(r['input']),allow_pickle=False)as raw:
            args={k:raw[k]for k in raw.files}
        output=np.load(checked(r['outputs']),allow_pickle=False)
        if old['source']['kind']=='wire':
            metric=metric_for_wire(args,old['source']['geometry'])
            properties=metric(output)|fine_region(output,args,2)|{'flat_chroma_RMS_DN16':flat_color(output,args,3,(64,64,128,128))}
        else:
            properties=photo(output,args)
        arms={k:old['scores'][k]for k in (LAST,CORPUS,V120)}
        arms[END]=properties
        evals.append(dict(old,scores=arms,endpoint_output=r['outputs']))
    wires=[row for row in evals if row['source']['kind']=='wire']
    photos=[row for row in evals if row['source']['kind']=='natural']
    assert len(wires)==len(photos)==24
    measures={'wire':comparisons(wires,False),'photo':comparisons(photos,True)}
    exact=exact_views(wires,photos,profile)
    older=read_json(checked(recipe['standing']))['rows']
    standing=camera_views(result['standing'],older,recipe['previous'],checkpoint)
    write_json(ROOT/'review.json',dict(driver=reference(__file__),replay=proof,previous_review=original_ref,
                   checkpoint=checkpoint,scope='Scoped exact-target and native review. Broad paired panels pending.',
                   wire=wires,photo=photos,summary=measures,exact=exact,standing=standing,
                   elapsed_seconds=time.monotonic()-start))
    print('reviewed',len(wires),len(photos),len(standing),flush=True)


if __name__=='__main__':
    main()
