"""Make a source-disjoint confirmation cohort for the Corpus/local mixture."""
from dataclasses import asdict
import hashlib
import math
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.with_name('green-covariance-refit-v1')
sys.path.insert(0,str(PREVIOUS))
import fresh_fields as generator
from transport import compare,load_models
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import sample_scene_recipe,scene_crop_boxes
from demosaic.scene_training_data import scene_seed

SEED=202611191057
MATCH=Path('docs/results/scene-full-epoch-v1/paired-prefix-047500.json')
PROFILE=generator.FIRST_PROFILE


def plan():
    specimen=reference(PREVIOUS/'fresh.json')
    earlier=read_json(checked(specimen))
    old_ref=earlier['plan']
    old=read_json(checked(old_ref))
    blocked_ids={row['source']['id']for row in old['sources']}
    blocked_hashes={row['source']['cache_sha256']for row in old['sources']}
    training=old['training_manifest']
    for row in generator.read_rows(checked(training)):
        blocked_ids.add(row['id'])
        blocked_hashes.add(row['cache_sha256'])
    full_panel=read_json(checked(old['rejected_full427']))
    for row in full_panel['source_metadata']:
        blocked_ids.add(row['id'])
        blocked_hashes.add(row['cache_sha256'])
    older_wire=read_json(checked(old['excluded_prior_wires']))
    for bench in older_wire['protocol'].values():
        prior=read_json(checked(bench['plan']))
        for row in prior['sources']:
            blocked_ids.add(row['source']['id'])
            blocked_hashes.add(row['source']['cache_sha256'])
    candidates=[]
    for row in generator.read_rows(checked(old['source_pool'])):
        if row['split']=='val' and row['bin_factor']==4 and min(row['shape'][:2])>=512 and math.prod(row['shape'][:2])<=2_200_000:
            if row['id'] not in blocked_ids and row['cache_sha256'] not in blocked_hashes:
                candidates.append(row)
    candidates.sort(key=lambda row:hashlib.sha256(f"{SEED}/{row['id']}".encode()).digest())
    rows=[]
    for photo in candidates:
        if photo['cache_sha256'] in blocked_hashes:
            continue
        i=len(rows)
        old_geometry=old['sources'][i]
        is_wire=old_geometry['kind']=='wire'
        h,w=(int(v)//2*2 for v in photo['shape'][:2])
        box,=scene_crop_boxes((h,w),patch_size=512 if is_wire else 256,count=1,seed=scene_seed(SEED,i,'source-box'))
        camera=asdict(sample_scene_recipe(scene_seed(SEED,i,'camera')))
        camera.update(pattern=tuple(PATTERNS)[(i+i//4)%4],black=.03)
        entry=dict(source=photo,index=i,box=box,camera=camera,kind=old_geometry['kind'])
        if is_wire:
            # Keep the closed balanced geometries and regenerate all backgrounds
            # and camera draws. The complete experimental design stays matched.
            entry['geometry']=old_geometry['geometry']
        blocked_hashes.add(photo['cache_sha256'])
        rows.append(entry)
        if len(rows)==48:
            break
    assert len(rows)==48
    picked_ids={row['source']['id']for row in rows}
    picked_hashes={row['source']['cache_sha256']for row in rows}
    assert len(picked_ids)==len(picked_hashes)==48
    audit=read_json(checked(old['parent_visit_audit']))
    count=0
    for trace in audit['source_traces']:
        for update in generator.read_rows(checked(trace)):
            for visit in update['sources']:
                if visit['kind']!='photographic':
                    continue
                count+=1
                assert visit['source_id'] not in picked_ids and visit['cache_sha256'] not in picked_hashes
    assert count==559808
    matched=reference(MATCH)
    compared=read_json(checked(matched))
    assert compared['matched_to_update']==47500
    result=dict(driver=reference(__file__),fixture_driver=reference(generator.__file__),
        exact_geometry=reference(generator.wire_math.__file__),sources=rows,profile=PROFILE,seed=SEED,
        checkpoints={'parent':old['checkpoints']['100k'],'local':compared['arms']['none']['checkpoint'],
                     'v120':old['checkpoints']['V120']},
        paired_checkpoint_receipt=matched,compatible_training_manifest=training,
        prior_cohort=old_ref,exclude_recent_test=specimen,excluded_photo_panel=old['rejected_full427'],
        source_pool=old['source_pool'],parent_visit_audit=old['parent_visit_audit'],visited_rows_checked=count)
    write_json(ROOT/'plan.json',result)
    return result


@torch.inference_mode()
def render(models,data,noise):
    inp=[torch.from_numpy(data[k]).cuda().contiguous(memory_format=torch.channels_last)for k in ('packed','variance')]
    n=len(inp[0])
    inp += [torch.from_numpy(data[k]).cuda()[None].expand(n,*data[k].shape)for k in ('colors','wb','matrix')]
    result={}
    with ieee_fp32():
        for label,model in models.items():
            base=model.base if label=='local' else model
            base.set_noise(noise['shot'],noise['read'])
            value=model(*inp)
            assert value.shape==(n,3,256,256) and torch.isfinite(value).all()
            result[label]=value.cpu().numpy()
    return result


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    generator.SEED=SEED
    record=plan()
    print('locked',len(record['sources']),flush=True)
    models=load_models({'none':record['checkpoints']['local']})
    models={'local':models['none']}
    for name in ('parent','v120'):
        bind=record['checkpoints'][name]
        model,state=load_checkpoint(checked(bind),'cuda',tiled_inference=True)
        assert state['loaded_sha256']==bind['sha256'] and 'ema'in state
        del state
        models[name]=model.eval().to(memory_format=torch.channels_last)
    path=ROOT/'confirmation'
    path.mkdir(exist_ok=True)
    rows=[]
    start=time.monotonic()
    model_seconds=0.
    for row in record['sources']:
        args,box=generator.capture(row,record['profile'])
        t0=time.monotonic()
        estimates=render(models,args,record['profile'])
        model_seconds+=time.monotonic()-t0
        a,b=(path/f"{row['index']:02d}-{label}.npz"for label in ('capture','estimate'))
        np.savez_compressed(a,**args)
        np.savez_compressed(b,**estimates)
        rows.append(dict(source=row,box=box,input=reference(a),model_outputs=reference(b)))
        if len(rows)%8==0: print(len(rows),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/'confirmation.json',dict(driver=reference(__file__),plan=reference(ROOT/'plan.json'),rows=rows,
        precision='CUDA IEEE FP32 EMA',inference_seconds=model_seconds,wall_seconds=time.monotonic()-start))


if __name__=='__main__':
    main()
