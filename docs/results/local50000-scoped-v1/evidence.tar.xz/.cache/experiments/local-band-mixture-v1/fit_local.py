"""Fit bounded local/Corpus mixtures on independent-noise increment and gap controls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import time

import numpy as np
from scipy.optimize import minimize

from collect_local import ROOT,PREVIOUS
from local_fields import KINDS,PLANES,fields,verify
from scoring import WireMetric,remove_basis
from upper import ROI,SCORE,tile_dct,luma,measure
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

KINDS_TO_LIMIT=('wire_flat','wire_chroma','gap_absolute','gap_weak','gap_exterior','gap_strong',
                'photo_flat','photo_chroma','photo_increment')


def metric_for_wire(args,geometry):
    if geometry['family']=='smooth-dip':
        assert np.min(args['support'][64:192,64:192])>0
        args={**args,'support':np.ones_like(args['support'])}
    return WireMetric(args,geometry)


def assemble(parent,local,args,profile):
    matrices={n:[]for n in KINDS}
    for i in range(len(parent)):
        camera={k:args[k]for k in ('wb','matrix','colors')}|{'packed':args['packed'][i]}
        for name,basis in fields(parent[i],local[i],camera,profile,ROI).items():
            matrices[name].append(basis)
    return {n:np.stack(values,axis=1)for n,values in matrices.items()}


def samples(local,basis,args,score):
    x,y,w,h=score
    ox,oy,_,_=ROI
    bed=local[...,y:y+h,x:x+w]
    detail=basis[...,y-oy:y-oy+h,x-ox:x-ox+w]
    estimated=np.concatenate((bed[None],detail),axis=0)
    l=luma(estimated,args['wb'],args['matrix'])
    color=np.einsum('ic,abcxy->abixy',args['matrix'],estimated*args['wb'][None,None,:,None,None])
    return l,color


def gram(x,weight):
    y=x.reshape(len(x),-1)*(65535/np.sqrt(weight))
    return y@y.T


def neutral_error(colors,args,role,score):
    x,y,w,h=score
    target=args['target'][role,:,y:y+h,x:x+w]
    reference=np.einsum('ic,cxy->ixy',args['matrix'],target*args['wb'][:,None,None])
    error=colors[:,role].copy()
    error[0]-=reference
    error-=error.mean(axis=1,keepdims=True)
    return gram(error,3*w*h)


def wire_case(local,basis,args,geometry):
    roi=(64,64,128,128)
    y,color=samples(local,basis,args,roi)
    metric=metric_for_wire(args,geometry)
    diff=remove_basis((y[:,0]-y[:,2])[:,metric.intact],metric.intact_nuisance)
    response=100*diff@metric.truth_weak/metric.strength
    diff[0]-=metric.truth_weak
    quiet=y[:,3]-y[:,3].mean(axis=(1,2),keepdims=True)
    values=dict(wire_increment=gram(diff,diff.shape[1]),wire_flat=gram(quiet,128**2),
                wire_chroma=neutral_error(color,args,3,roi))
    if metric.gap.any():
        gap=metric.gap
        absolute=y[:,0][:,gap].copy()
        absolute[0]-=metric.truth[0][gap]
        ext=(y[:,1]-y[:,2])[:,gap].copy()
        ext[0]-=(metric.truth[1]-metric.truth[2])[gap]
        n=absolute.shape[1]
        values.update(gap_absolute=gram(absolute,n),gap_weak=gram(absolute@metric.weak_basis,n),
                      gap_exterior=gram(ext@metric.weak_basis,n),gap_strong=gram(absolute@metric.strong_basis,n))
    return values,response


def natural_case(local,basis,args,geometry):
    fine=measure.BANDS['fine']
    restored,color=samples(local,basis,args,SCORE)
    s=tile_dct(restored)[...,fine]
    x,y,w,h=SCORE
    target=tile_dct(luma(args['target'][...,y:y+h,x:x+w],args['wb'],args['matrix']))[...,fine]
    residual=(s[:,0]-s[:,1]).reshape(len(restored),-1)
    texture=(target[0]-target[1]).ravel()
    norm=texture@texture
    response=100*residual@texture/norm if norm else None
    residual[0]-=texture
    flat=s[:,2].copy()
    flat[0]-=target[2]
    values=dict(photo_increment=gram(residual,96**2),photo_flat=gram(flat,96**2),
                photo_chroma=neutral_error(color,args,2,SCORE))
    return values,response


def case_terms(data,parent,local,kind,profile):
    func=wire_case if kind['kind']=='wire' else natural_case
    geometry=kind.get('geometry')
    precedent=np.zeros((1,len(parent),3,160,160),np.float32)
    corpus,corpus_response=func(parent,precedent,data,geometry)
    estimates=assemble(parent,local,data,profile)
    return {'parent_error':{key:float(q[0,0])for key,q in corpus.items()},
            'parent_response':None if corpus_response is None else float(corpus_response[0]),
            'modes':{key:func(local,value,data,geometry)for key,value in estimates.items()}}


def development():
    frozen=reference(PREVIOUS/'fresh.json')
    current=reference(PREVIOUS/'transport-fresh.json')
    older,after=(read_json(checked(ref))for ref in (frozen,current))
    assert len(older['rows'])==len(after['rows'])==48
    profile=read_json(checked(older['plan']))['profile']
    cases=[]
    for a,b in zip(older['rows'],after['rows'],strict=True):
        assert a['input']==b['input'] and a['source']['index']==b['index']
        with (np.load(checked(a['input']),allow_pickle=False) as src,
              np.load(checked(a['predictions']),allow_pickle=False)as before,
              np.load(checked(b['predictions']),allow_pickle=False)as after):
            data={k:src[k]for k in src.files}
            values=case_terms(data,before['parent'],after['local'],a['source'],profile)
        cases.append(dict(values,source=a['source']['source']['id'],kind=a['source']['kind'],capture=a['input']))
    return cases,[frozen,current]


def response_average(cases,kind,arm):
    return np.mean([case['modes'][arm][1] for case in cases
                    if case['kind']==kind and case['modes'][arm][1] is not None],axis=0)


def solve(cases,arm,budget):
    all_terms=[r['modes'][arm][0]for r in cases]
    expected={key:np.mean([q[key] for q in all_terms if key in q],axis=0)
              for key in sorted(set().union(*(list(q)for q in all_terms)))}
    forward={k:response_average(cases,k,arm)for k in ('wire','natural')}
    anchor={k:float(np.mean([r['parent_response']for r in cases
                          if r['kind']==k and r['parent_response'] is not None]))for k in forward}
    floors={k:min(anchor[k],v[0])for k,v in forward.items()}
    maxima={}
    for key in KINDS_TO_LIMIT:
        loss=expected[key][0,0]
        before=np.mean([q['parent_error'][key]for q in cases if key in q['parent_error']])
        maxima[key]=loss+budget*max(before-loss,0)
    def valid(w):
        s=np.r_[1.,w]
        quality=[(cap-s@expected[k]@s)/max(cap,1.)for k,cap in maxima.items()]
        details=[(v@s-floors[k])/max(1.,abs(floors[k]))for k,v in forward.items()]
        return np.asarray(quality+details)
    def value(w):
        s=np.r_[1.,w]
        return .75*(s@expected['wire_increment']@s)/expected['wire_increment'][0,0]+.25*(s@expected['photo_increment']@s)/expected['photo_increment'][0,0]
    start=np.zeros(len(PLANES[arm]))
    fit=minimize(value,start,bounds=((0,1),)*len(start),constraints=[dict(type='ineq',fun=valid)],
                 method='SLSQP',options={'maxiter':400,'ftol':1e-12})
    assert np.min(valid(fit.x))>=-1e-7,(arm,fit.message,valid(fit.x))
    w=fit.x if value(fit.x)<value(start)-1e-9 else start
    full=np.r_[1.,w]
    return dict(weights=w.tolist(),features=PLANES[arm],constraint_minimum=float(np.min(valid(w))),
                relative_objective=float(value(w)),success=bool(fit.success),solver_message=fit.message,
                budget_MSE={k:float(v)for k,v in maxima.items()},
                local_MSE={k:float(v[0,0])for k,v in expected.items()},
                fitted_MSE={k:float(full@v@full)for k,v in expected.items()},
                response={k:dict(floor=float(floors[k]),Corpus=anchor[k],local=float(v[0]),result=float(v@full))for k,v in forward.items()})


def serializable(cases):
    return [{**c,'modes':{n:[{k:q.tolist()for k,q in e.items()},
                           None if r is None else r.tolist()]for n,(e,r) in c['modes'].items()}}
            for c in cases]


def main():
    beginning=time.monotonic()
    frozen=reference(ROOT/'research-plan.json')
    plan=read_json(checked(frozen))
    checks=verify()
    cases,anchor=development()
    assert anchor==plan['development']
    fits={k:{n:solve(cases,n,v) for n in KINDS}for k,v in (('exact_local_budget',0.),('retain75',.25))}
    preferred=plan['candidate_for_native']
    assert preferred==['retain75','raw_gated']
    write_json(ROOT/'fit.json',dict(driver=reference(__file__),plan=frozen,development=anchor,
              results=fits,phase_test=checks,cases=serializable(cases),elapsed=time.monotonic()-beginning))
    for family,names in fits.items():
        for mode,value in names.items():
            print(family,mode,np.round(value['weights'],6),value['relative_objective'],value['response'],flush=True)


if __name__=='__main__':
    main()
