"""Evaluate the locked blends on new source-disjoint RAW captures."""
import time

import numpy as np

from collect_local import ROOT
from fit_local import metric_for_wire,assemble,neutral_error
from local_fields import apply
from upper import ROI,SCORE,tile_dct,luma,measure
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

RAW='Registered RAW blend'
LABELS={'uniform':'Uniform blend','subband':'Subband blend','raw_gated':RAW,'flipped':'Flipped RAW blend'}
LOCAL='Local-only 47.5k'
PARENT='Corpus 100k'
REF='V120'
PAIRS=((RAW,LOCAL),(RAW,PARENT),(RAW,'Uniform blend'),(RAW,'Subband blend'),(RAW,'Flipped RAW blend'),
       (RAW,REF),(LOCAL,PARENT),('Uniform blend',LOCAL),('Subband blend',LOCAL),('Flipped RAW blend',LOCAL))


def generate(args,estimate,profile,weights):
    p,q=estimate['parent'],estimate['local']
    basis=assemble(p,q,args,profile)
    return {PARENT:p,LOCAL:q,REF:estimate['v120']}|{LABELS[n]:apply(q,v,weights[n]['weights'],ROI)for n,v in basis.items()}


def fine_region(image,args,pair):
    x,y,w,h=SCORE
    cut=np.s_[...,y:y+h,x:x+w]
    a=tile_dct(luma(image[cut],args['wb'],args['matrix']))
    b=tile_dct(luma(args['target'][cut],args['wb'],args['matrix']))
    field=a[0]-a[pair]
    truth=b[0]-b[pair]
    result={}
    for label in ('fine','upper'):
        mask=measure.BANDS[label]
        residual=(field-truth)[...,mask]
        f,t=(v[...,mask].ravel()for v in (field,truth))
        support=t@t
        result[label+'_increment_RMS_DN16']=float(np.linalg.norm(residual)*65535/96.)
        result[label+'_response_pp']=float(100*(f@t)/support) if support else None
    return result


def flat_color(image,args,index,score):
    x,y,w,h=score
    native=image[None,...,y:y+h,x:x+w]*args['wb'][None,None,:,None,None]
    rgb=np.einsum('ic,abcxy->abixy',args['matrix'],native)
    return float(np.sqrt(neutral_error(rgb,args,index,score)[0,0]))


def photo(image,args):
    x,y,w,h=SCORE
    cut=np.s_[...,y:y+h,x:x+w]
    error=tile_dct(luma((image-args['target'])[cut],args['wb'],args['matrix']))
    return fine_region(image,args,1)|{'exact_flat_fine_RMS_DN16':float(np.linalg.norm(error[2,...,measure.BANDS['fine']])*65535/96),
             'exact_flat_upper_RMS_DN16':float(np.linalg.norm(error[2,...,measure.BANDS['upper']])*65535/96),
             'flat_chroma_RMS_DN16':flat_color(image,args,2,SCORE)}


def summaries(rows,pool):
    rng=np.random.default_rng(202611191101)
    output={}
    for candidate,control in PAIRS:
        comparisons={}
        keys=set().union(*(set(row['scores'][candidate])for row in rows))
        for key in sorted(keys):
            picked=[row['scores']for row in rows if row['scores'][candidate].get(key) is not None]
            if not picked:
                continue
            v=np.asarray([[entry[arm][key]for entry in picked] for arm in (candidate,control)])
            draws=np.vstack((np.arange(len(picked)),rng.integers(len(picked),size=(7000,len(picked)))))
            data=v[:,draws]
            score=np.sqrt(np.mean(data**2,axis=-1)) if pool and key.endswith('RMS_DN16') else data.mean(-1)
            change=score[0]-score[1]
            comparisons[key]=dict(count=len(picked),candidate=float(score[0,0]),control=float(score[1,0]),delta=float(change[0]),
                  interval=np.quantile(change[1:],[.025,.975]).tolist())
        output[f'{candidate} vs {control}']=comparisons
    return output


def main():
    started=time.monotonic()
    collected=reference(ROOT/'confirmation.json')
    checked_fit=reference(ROOT/'fit.json')
    survey=read_json(checked(collected))
    experiment=read_json(checked(checked_fit))
    plan=read_json(checked(survey['plan']))
    assert len({x['source']['source']['id']for x in survey['rows']})==48
    wanted={x['source']for x in experiment['cases']}
    assert wanted.isdisjoint(x['source']['id']for x in plan['sources'])
    selected=experiment['results']['retain75']
    assert all(not any(row['weights'])for row in experiment['results']['exact_local_budget'].values())
    data=[]
    for row in survey['rows']:
        with (np.load(checked(row['input']),allow_pickle=False)as raw,
              np.load(checked(row['model_outputs']),allow_pickle=False)as pred):
            args={k:raw[k]for k in raw.files}
            candidates=generate(args,pred,plan['profile'],selected)
        scores={}
        if row['source']['kind']=='wire':
            metric=metric_for_wire(args,row['source']['geometry'])
            for label,value in candidates.items():
                scores[label]=metric(value)|fine_region(value,args,2)|{'flat_chroma_RMS_DN16':flat_color(value,args,3,(64,64,128,128))}
            gap=int(metric.gap.sum())
        else:
            scores={k:photo(v,args)for k,v in candidates.items()}
            gap=0
        data.append(dict(row,scores=scores,gap_pixels=gap))
    wires=[r for r in data if r['source']['kind']=='wire']
    photos=[r for r in data if r['source']['kind']=='natural']
    assert len(wires)==len(photos)==24 and sum(r['gap_pixels']>0 for r in wires)==12
    summary={'wire':summaries(wires,False),'photo':summaries(photos,True)}
    write_json(ROOT/'review.json',dict(driver=reference(__file__),capture_receipt=collected,fit=checked_fit,
           applied_coefficients=selected,wire=wires,photo=photos,summary=summary,wall_seconds=time.monotonic()-started))
    print('Completed',len(wires),len(photos),round(time.monotonic()-started,2),flush=True)


if __name__=='__main__':
    main()
