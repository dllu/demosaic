"""Record actual native viewing and the full-photo context geometry separately."""
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path('.cache/experiments/scene-primary-camera-review-v1').resolve()
notes = {
    'known': [
        'Mostly quiet dark plate/background with a broad horizontal transition. All restored outputs stay smooth; no obvious new coherent grid or large fringe. The independent AHD reference retains visible noise.',
        'Fine diagonal/woven-looking light surface remains softened in all restored outputs. Small method differences do not establish recovered fine structure; the independent reference is noisy.',
        'Low-contrast brown stone/wall texture remains softened and patchy. No convincing extra fine structure or new large color fringe among continuations at this ROI.',
        'Broad pale curved grooves and a dark diagonal boundary remain smooth. Method changes are subtle; no convincing new small crossing or texture recovery despite this scene driving the positive panel mean.',
    ],
    'unseen': [
        'Dark lettering and broad diagonal edges are retained but softened similarly in all restored outputs. No obvious new fringe or detail gain.',
        'Quiet brown field remains smooth in all methods. Subtle broad color differences are visible; no obvious new fine grid. This source has the largest numerical regression against V120, not a large visible center-crop artifact.',
        'Faint warm tapestry-like shapes remain waxy and poorly defined in all methods. Spatial/pooled changes do not convincingly restore fine structure.',
        'Faint diagonal wood-like streaks are present but smoother than the noisy independent reference. Similar outputs; no convincing new fine recovery.',
        'Dark low-contrast texture remains softened. All methods look close at native scale; no obvious new coherent grid or large fringe in this fixed center.',
    ],
}
for stage, relative in [('known', 'native-v2'), ('unseen', 'native')]:
    folder = root / stage / relative
    native = read_json(folder / 'result.json')
    assert len(native['boards']) == len(notes[stage])
    write_json(folder / 'native-viewing.json', {
        'recorded_UTC': datetime.now(timezone.utc).isoformat(),
        'reviewer': 'Codex primary agent, all final boards actually opened through view_image in this turn',
        'boards': [{'image': b['image'], 'id': b['id'], 'opened': True, 'note': note}
                   for b, note in zip(native['boards'], notes[stage], strict=True)],
        'scope': 'Actual native160 viewing of every predeclared first-capture/first-crop scene board. These center ROIs do not cover all scored448 crop pixels or scene/capture variation. Independent AHD references are noisy/approximate and not exact RGB GT. All9 boards across both panels viewed; no neural/GPU/noise/RAW/optimizer work.',
    })
inventory_path = Path('.cache/canonical-fullscene-lineage-v1.json').resolve()
inventory = read_json(inventory_path)
sizes = np.array([r['phase_frame_native_hw'] for r in inventory['sources']], dtype=np.int64)
fraction = 256**2 / sizes.prod(1)
write_json(root / 'photo-context-geometry.json', {
    'producer': reference(__file__), 'inventory': reference(inventory_path),
    'sources': len(sizes), 'median_frame_height_width': np.median(sizes, axis=0).tolist(),
    'maximum_height_width': sizes.max(0).tolist(), 'short_side_below512_count': int((sizes.min(1) < 512).sum()),
    'median_local256_crop_area_fraction': float(np.median(fraction)),
    'maximum_local256_crop_area_fraction': float(fraction.max()),
    'scope': 'The primary photo benchmark uses complete binned source fields with original256 crops unchanged;427 sources,420 have a short side below512 and median local crop occupies43.3% of field area. This is correct full FOV at benchmark resolution, not a claim of100MP context/detail performance. Camera scenes and dedicated64-source development fields have different size/coverage. No new quality score/model/RAW/noise/GPU work.',
})
print('Recorded actual viewing of all9 camera boards and427 photo context geometry')
