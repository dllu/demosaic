"""Publish complete camera panels and append actual7k IO evidence without resealing old cutoffs."""
import gzip
import shutil
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/scene-primary-camera-review-v1'
destination = repo / 'docs/results/scene-primary-camera-review-v1'
destination.mkdir()
images = repo / 'docs/images/scene-primary-camera-review-v1'
images.mkdir()
assets, paths, sources, scores = [], [], [], {}
for stage, folder in [('known', 'native-v2'), ('unseen', 'native')]:
    result = read_json(root / stage / 'result.json')
    assert len(result['cases']) == (24 if stage == 'known' else 30)
    scores[stage] = {r['model']: r['metrics']['sensor_psnr']['mean'] for r in result['summary']['overall']}
    paths += [root / stage / 'result.json', root / stage / 'per-crop.csv']
    paths += [checked(binding) for binding in result['cases']]
    source = root / stage / folder
    viewing = read_json(source / 'native-viewing.json')
    assert all(b['opened'] for b in viewing['boards'])
    for path in source.rglob('*'):
        if not path.is_file() or path.suffix not in {'.png', '.json'}:
            continue
        target = images / stage / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert target.read_bytes() == path.read_bytes()
        assets.append({'original': reference(path), 'published': reference(target)})
paths += [root / 'photo-context-geometry.json']
paths += [repo / '.cache' / name for name in [
    'analyze-scene-primary-cameras-v1.py', 'scene-primary-camera-known-analysis-v1.log',
    'scene-primary-camera-known-analysis-v2.log', 'scene-primary-camera-unseen-analysis-v1.log',
    'render-scene-primary-cameras-v1.py', 'scene-primary-camera-known-render-v1.log',
    'scene-primary-camera-known-render-v2.log', 'scene-primary-camera-unseen-render-v1.log',
    'close-scene-primary-camera-viewing-v1.py', 'close-scene-primary-camera-viewing-v1.log',
    'publish-scene-primary-camera-review-v1.py']]
paths += [repo / 'scripts' / name for name in ['analyze_scene_primary_cameras.py', 'render_scene_primary_cameras.py']]
paths += list((root / 'work/scripts').glob('*.py'))
paths += [root / 'known/native/result.json']
archives = []
for i, source in enumerate(sorted(set(paths))):
    data = source.read_bytes()
    target = destination / f'{i:03d}-{source.name}.gz'
    with target.open('xb') as stream:
        stream.write(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    archives.append({'original': reference(source), 'published': reference(target)})
write_json(destination / 'summary.json', {
    'models': read_json(root / 'known/result.json')['models'], 'weights': 'EMA',
    'known_scenes': 4, 'unseen_scenes': 5, 'known_crops': 72, 'unseen_crops': 90,
    'known_measured_CFA_PSNR': scores['known'], 'unseen_measured_CFA_PSNR': scores['unseen'],
    'full427_photo_PSNR': None, 'primary_three_panel_completion': False,
    'scope': 'Complete matched-CPU camera results, not a completed full427/three-panel primary registry. Individual source/capture/crop metrics and native provenance are archived; full photo collection continues.',
})
write_json(destination / 'publication.json', {
    'publisher': reference(__file__), 'archives': archives, 'native_assets': assets,
    'summary': reference(destination / 'summary.json'),
    'prior_primary_admission': reference(repo / 'docs/results/whole-scene-context-primary-admission-v1/publication.json'),
    'same_endpoint_development_and_GFX_review': reference(repo / 'docs/results/whole-scene-context-native-review-v1/publication.json'),
    'scope': 'Complete54 camera batches/162 crops/4 EMA models,648 crop/model rows, original sensor scores independently reproduced exactly. All9 final native boards actually opened,9 matched real-reference triplets, plus separately linked same-endpoint exact-GT development triplets/GFX boards. Original observer rounding failure and immediate-loop renderer source preserved. No new neural/GPU/RAW/noise/optimizer work by these observers. Full427 photo and eligible complete three-panel history update remain pending.',
    'original_source_alias': {'original_failed_renderer_record': reference(root / 'known/native/result.json'),
                              'byte_exact_executed_source': reference(repo / '.cache/render-scene-primary-cameras-v1.py'),
                              'scope': 'The first renderer executed from the repository script before its immediate loop closure was bound explicitly for lint. Its exact old source is preserved here; final boards use the frozen corrected helper. Final/old known PNGs are compared independently; no learned call repeats.'},
    'not_embedded': 'Checkpoint/DINO binaries, canonical tensor arrays, full noisy scene feature fields and native predictions stay locally checksum-bound. Original primary source snapshots live in the previous admission publication. No claim every transitive historical local path is packed.',
})

# The old repair publication remains an immutable observation through6350.
# Append a new record for the actual later successful7000 checkpoint.
repair = repo / 'docs/results/full-corpus-checkpoint-recovery-v1'
post = repo / '.cache/experiments/full-corpus-scaling-v3/checkpoint-recovery-v6/post-repair-checkpoint-validation-v1/result.json'
receipt = read_json(post)
assert receipt['actual_training_step'] == 7000 and receipt['last_and_best_same_complete_inode']
items = []
for path in [post, repo / '.cache/verify-post-repair-checkpoint-step7000-v1.py',
             repo / '.cache/verify-post-repair-checkpoint-step7000-v1.log']:
    target = repair / ('post-repair7000-' + path.name + '.gz')
    with target.open('xb') as stream:
        stream.write(gzip.compress(path.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == path.read_bytes()
    items.append({'original': reference(path), 'published': reference(target)})
write_json(repair / 'post-repair-step7000-addendum.json', {
    'original_publication': reference(repair / 'publication.json'), 'actual_checkpoint_validation': receipt,
    'archives': items, 'publisher': reference(__file__),
    'scope': 'Later actual production checkpoint/IO validation, separate from original through6350 cutoff. Immutable complete7000 raw/EMA/Adam/RNG file retained, last/best shared its inode, and subsequent updates were observed. No new quality result or completed20k/100k horizon. No missing original failed-prefix receipt reconstructed.',
})
print('Published camera archives', len(archives), 'native assets', len(assets), 'plus actual7k addendum')
