"""Allocate smoothing and detail to regions with different measured RAW support."""
import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.paired_detail import fine_band
from demosaic.precision import ieee_fp32
from run_feedback import (ROOT,REPEAT,configure,cutoff,head,inputs,bind_upstream,
                          read_parent,paired_gates,channel_coefficients,as_cuda,packed_inputs,
                          BANDS,measure)
from feedback_heads import counterfactual
from directional_feedback import native as oriented
from review_projected import compare_at_strength
from strength_limits import curve,largest_allowed

STRENGTHS=(.05,.15)
ORIGINS=("box","oriented")


def quiet_direction(head,parent,args,wide):
    """Achromatic smoothing on pixels with no nearby green-phase support."""
    packed,_,_,wb,matrix=args
    support=F.max_pool2d(wide,17,stride=1,padding=8)
    marked=(packed>=.98).any(dim=1,keepdim=True).to(packed.dtype)
    protected=F.max_pool2d(marked,7,stride=1,padding=3)
    valid=1-F.interpolate(protected,scale_factor=2,mode="nearest")
    grey=torch.linalg.solve(matrix,torch.ones_like(wb).unsqueeze(-1)).squeeze(-1)/wb
    strength=(1-support).square()*valid
    correction=-fine_band(head.scene_luma(parent,wb,matrix))*strength
    return grey[:,:,None,None]*correction,grey


def outputs(model,image,args,limits):
    wide,shared=paired_gates(*args[:3],*limits)
    smooth,grey=quiet_direction(model,image,args,wide)
    box=counterfactual(model,image,image,*args,smooth_innovation=True)
    patterns={"box":(image+grey[:,:,None,None]*box*shared).cpu().numpy(),
              "oriented":oriented(model,image,args,shared)}
    delivered={}
    for amount in STRENGTHS:
        delta=(smooth*amount).cpu().numpy()
        delivered[f"quiet-{amount}"]=image.cpu().numpy()+delta
        for method in ORIGINS:
            delivered[f"{method}-quiet-{amount}"]=patterns[method]+delta
    return delivered


@torch.inference_mode()
def run():
    configure()
    default,conditions=cutoff()
    physical,cases=inputs()
    archive,_,baseline,_=bind_upstream()
    study=read_json(REPEAT/"evaluation-plan.json")
    roi=study["score_ROI_xywh"]
    model=head(torch.load(checked(default["initial_head"]),map_location="cpu",weights_only=True),"paired")
    records=[]
    with ieee_fp32():
        for i,case in enumerate(cases):
            observations=[]
            for repeat in (0,1):
                target=packed_inputs(case,repeat)
                args=as_cuda(target)
                parent=read_parent(baseline[case["id"]][repeat],classes=("100k",))["100k"]
                gpu=torch.from_numpy(parent).cuda().contiguous(memory_format=torch.channels_last)
                alternatives=outputs(model,gpu,args,conditions)|{"100k":parent}
                observations.append({label:channel_coefficients(array,target,roi)[1]
                                     for label,array in alternatives.items()})
            truth=channel_coefficients(target["target"],target,roi)[1]
            anchor=np.stack([r["100k"] for r in observations])
            models={label:np.stack([r[label] for r in observations]) for label in observations[0]}
            scored={label:measure(anchor,arr-anchor,truth,BANDS["fine"]) for label,arr in models.items()}
            records.append({"id":case["id"],"cohort":case["cohort"],"moments":scored})
            if (i+1)%16==0:
                print(i+1,flush=True)
    rng=np.random.default_rng(160278157)
    fit=[row for row in records if row["cohort"]=="original64"]
    holdout=[row for row in records if row["cohort"]=="fresh32"]
    assert (len(fit),len(holdout))==(64,32)
    result={}
    for model in (k for k in records[0]["moments"] if k!="100k"):
        intervals=[]
        for key in ("increment","flat"):
            f,init=curve(fit,model,key)
            intervals.append(largest_allowed(f,init))
        scale=min(intervals)
        result[model]={
            "nominal_fresh32":compare_at_strength(holdout,model,"100k",{model:1.,"100k":1.},rng),
            "limit_for_both_parent_budgets":scale,
            "fixed_joint_strength_fresh32":compare_at_strength(holdout,model,"100k",{model:scale,"100k":1.},rng),
        }
    write_json(ROOT/"flat-companion.json",{
        "driver":reference(__file__),"input":physical,"parent_archive":reference(archive),
        "strengths":STRENGTHS,"scope":"Two native queries per ISO6400 independent group. Predetermined smoothing strengths. Paired source bootstrap. Scales for both parent budgets determined on original64 and evaluated once on fresh32.",
        "metrics":result,"rows":records,
    })


if __name__=="__main__":
    run()
