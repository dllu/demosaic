"""Smooth the single-frame innovation along structures in the fixed parent guide."""
import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic
from demosaic.paired_detail import fine_band
from feedback_heads import pool

OFFSETS=((0,1),(1,0),(1,1),(1,-1))
TEMPERATURE=.04


def neighbors(field,axis):
    height,width=field.shape[-2:]
    dy,dx=axis
    rim=F.pad(field,(1,1,1,1),mode="replicate")
    backward=rim[...,1-dy:1-dy+height,1-dx:1-dx+width]
    forward=rim[...,1+dy:1+dy+height,1+dx:1+dx+width]
    return backward,forward


def steer(innovation,contrast):
    neighbor_means=[]
    costs=[]
    for direction in OFFSETS:
        prev,next=neighbors(innovation,direction)
        neighbor_means.append((prev+next)*.5)
        prev,next=neighbors(contrast,direction)
        costs.append(pool(((prev-contrast).square()+(next-contrast).square())*.5,3))
    orientation=torch.softmax(-torch.stack(costs,dim=0)/TEMPERATURE,dim=0)
    neighbors_avg=(orientation*torch.stack(neighbor_means,dim=0)).sum(dim=0)
    return (5*innovation+4*neighbors_avg)/9


def native(head,parent,args,guard):
    packed,variance,colors,wb,matrix=args
    sigma=variance.clamp_min(1e-10).sqrt()
    average=sigma.mean(dim=1,keepdim=True)
    guide=F.avg_pool2d(head.scene_luma(parent,wb,matrix),2)
    middle=pool(guide,17)
    contrast=((guide-middle)/average).clamp(-12,12)
    innovation=(packed-mosaic(parent,colors))/sigma
    selected=steer(innovation,contrast).clamp(-12,12)
    codes=.5*colors[:,:,None,None].to(packed.dtype).expand_as(packed)
    features=torch.cat((selected,sigma.log().clamp(-12,0)/8,codes,
                         (middle.clamp_min(0)+1e-4).log().clamp(-10,1)/4,contrast),dim=1)
    mixed=head.output(head.blocks(F.silu(head.stem(features))))
    detail,confidence=F.pixel_shuffle(mixed,2).split(1,dim=1)
    scale=.5*F.interpolate(average,scale_factor=2,mode="nearest")
    clip=(packed>=.98).any(dim=1,keepdim=True).to(packed.dtype)
    mask=1-F.max_pool2d(clip,7,stride=1,padding=3)
    correction=fine_band(detail.tanh()*confidence.sigmoid()*scale)*F.interpolate(mask,scale_factor=2,mode="nearest")
    gray=torch.linalg.solve(matrix,torch.ones_like(wb).unsqueeze(-1)).squeeze(-1)/wb
    return (parent+gray[:,:,None,None]*correction*guard).cpu().numpy()
