"""Render the quiet-region and detail combination in both standing GFX scenes."""
import os

import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board
from run_feedback import ROOT,REPEAT,ARGS,as_cuda,bind_upstream,cutoff,head,inputs,packed_inputs,read_parent,value
from flat_companion import outputs
import render_repeat

KEYS=("quiet-0.15","box-quiet-0.15","oriented-quiet-0.15")
MODEL_KEYS=("V120","100k",*KEYS)
LABELS={"V120":"V120 EMA","100k":"Parent 100k EMA",KEYS[0]:"Quiet smoothing",
        KEYS[1]:"Uniform + quiet",KEYS[2]:"Directional + quiet"}


def composed(state,args,parents,limits):
    raw=torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    rest=outputs(state,raw,args,limits)
    return parents|{key:rest[key] for key in KEYS}


def photos(out,data,head,limits):
    specification=read_json(REPEAT/"evaluation-plan.json")
    _,cases=inputs()
    by_id={r["id"]:r for r in cases}
    _,_,predictions,_=bind_upstream()
    group=[row for row in data["rows"] if row["cohort"]=="fresh32"]
    assert len(group)==32
    def effect(row,key):
        return value(row["moments"][KEYS[1]],1.)[key]-value(row["moments"]["100k"],1.)[key]
    ranked=sorted(group,key=lambda row:effect(row,"increment_DN16"))
    show=((ranked[0],0,"Largest fine-increment error reduction with uniform detail plus quiet smoothing"),
          (ranked[-1],0,"Largest fine-increment error increase with uniform detail plus quiet smoothing"),
          (min(group,key=lambda row:effect(row,"flat_DN16")),2,"Largest flat error reduction with the combined policy"))
    finished=[]
    for row,role,why in show:
        case=by_id[row["id"]]
        record=specification["rows"][case["index"]]
        fields=packed_inputs(case,0)
        pred=composed(head,as_cuda(fields),read_parent(predictions[case["id"]][0]),limits)
        calibration={k:fields[k][role:role+1] for k in ARGS}
        panels=[noisy_malvar(calibration)[0],*[pred[k][role] for k in MODEL_KEYS],fields["target"][role]]
        finished.append(native_board(
            out,f"{case['id']}-r0-role{role}",panels,calibration,{
                "source_photo":record["source"],"bbox_native":case["native_box"],"CFA":case["CFA"],
                "profile":case["profile"],"selection":why,"exact_input":case["draws"][0],
                "scope":"Full-strength combined policy; three methods use quiet damping at 15 percent.",
            },labels=("Noisy Malvar",*[LABELS[key] for key in MODEL_KEYS],"Exact GT"),
            triplet_indices=(0,1+MODEL_KEYS.index(KEYS[1]),len(panels)-1),
            exposure=1/case["profile"]["exposure"],contrast=2,roi=tuple(specification["native_display_ROI_xywh"]),
        ))
    return finished


@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[16,18])
    os.nice(12)
    torch.set_num_threads(2)
    exact,conditions=cutoff()
    file=ROOT/"flat-companion.json"
    data=read_json(file)
    model=head(torch.load(checked(exact["initial_head"]),map_location="cpu",weights_only=True),"paired")
    out=ROOT/"flat-companion-native"
    out.mkdir()
    render_repeat.SHOW=KEYS
    render_repeat.DISPLAY=LABELS
    render_repeat.predictions=composed
    with ieee_fp32():
        synthetic=photos(out,data,model,conditions)
        camera=render_repeat.show_camera(model,conditions,out)
    write_json(out/"render.json",{
        "driver":reference(__file__),"scoring":reference(file),"standing":camera,"synthetic":synthetic,
        "weights":exact["initial_head"],"parent":exact["models"]["Corpus 100k"],
        "actual_native_viewing_complete":False,
    })


if __name__=="__main__":
    run()
