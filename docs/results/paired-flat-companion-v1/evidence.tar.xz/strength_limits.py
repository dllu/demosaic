"""Find the positive correction strengths that preserve the frozen parent's two RMS budgets."""
import numpy as np
from scipy.optimize import brentq,minimize_scalar

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from run_feedback import ROOT,CANONICAL,SINGLE_FRAME
from donor_lift import LABEL
from score_directional import NAME
from review_projected import compare_at_strength


def curve(rows,policy,key):
    coefficients=np.asarray([r["moments"][policy][key] for r in rows], dtype=float)
    def error(scale):
        return float(np.sqrt(np.maximum(coefficients@np.array([1.,scale,scale**2]),0.)).mean())
    derivative=float((coefficients[...,1]/(2*np.sqrt(coefficients[...,0]))).mean())
    return error,derivative


def largest_allowed(error,slope):
    baseline=error(0.)
    if error(1.)<=baseline:
        return 1.
    if slope>=0:
        return 0.
    infimum=minimize_scalar(error,method="bounded",bounds=(0.,1.),options={"xatol":1e-13})
    if error(infimum.x)>=baseline:
        return 0.
    return float(brentq(lambda scale:error(scale)-baseline,infimum.x,1.,xtol=1e-13))


def run():
    nominal=reference(ROOT/"results.json")
    directional=reference(ROOT/"oriented.json")
    paired=reference(ROOT/"independent-capture-lift.json")
    replaced=read_json(checked(directional))
    lift=read_json(checked(paired))
    assert nominal==replaced["preceding_results"]==lift["source"]
    rows=read_json(checked(nominal))["rows"]
    expanded=[r|{"moments":r["moments"]|{NAME:replaced["moments"][r["id"]],LABEL:lift["moments"][r["id"]]}} for r in rows]
    fit=[r for r in expanded if r["cohort"]=="original64"]
    test=[r for r in expanded if r["cohort"]=="fresh32"]
    assert (len(fit),len(test))==(64,32)
    small=[]
    for key in (CANONICAL,*SINGLE_FRAME,NAME,LABEL):
        numbers={}
        for metric in ("increment","flat"):
            f,slope=curve(fit,key,metric)
            numbers[metric]={
                "initial_gradient_DN16_per_strength":slope,
                "parent_RMS_DN16":f(0.),"nominal_RMS_DN16":f(1.),
                "maximum_allowed_scale":largest_allowed(f,slope),
            }
        scale=min(v["maximum_allowed_scale"] for v in numbers.values())
        smallest=compare_at_strength(test,key,"100k",{key:scale,"100k":1.},np.random.default_rng(6353257))
        fine_only=numbers["increment"]["maximum_allowed_scale"]
        selected=compare_at_strength(test,key,"100k",{key:fine_only,"100k":1.},np.random.default_rng(1392803))
        small.append({"policy":key,"original64":numbers,"joint_scale":scale,"joint_fresh32":smallest,
                      "increment_only_budget_fresh32":selected})
    write_json(ROOT/"strength-limits.json",{
        "driver":reference(__file__),"inputs":[nominal,directional,paired],"results":small,
        "scope":"Convex error curves on original64 from exactly reconstructed coefficient polynomials. Largest scalar in [0,1] giving each parent RMS budget. Evaluate the fixed diagnostic scalar on fresh32.",
    })


if __name__=="__main__":
    run()
