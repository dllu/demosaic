"""Intervene on the guide and Bayer innovation of the frozen detail head."""
import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic
from demosaic.paired_detail import fine_band

CANONICAL="canonical"
SINGLE_FRAME=("smooth-guide","smooth-innovation","smooth-both")
DONOR=("donor-guide","donor-mosaic","donor-both")


def pool(field,size):
    return F.avg_pool2d(field,size,stride=1,padding=size//2,count_include_pad=False)


def counterfactual(head, guide_parent, mosaic_parent, packed, variance, colors, wb, matrix,
                   *, smooth_guide=False, smooth_innovation=False):
    sigma=variance.clamp_min(1e-10).sqrt()
    average=sigma.mean(dim=1,keepdim=True)
    guide=F.avg_pool2d(head.scene_luma(guide_parent,wb,matrix),2)
    middle=pool(guide,17)
    contrast=guide-middle
    if smooth_guide:
        contrast=pool(contrast,3)
    innovation=(packed-mosaic(mosaic_parent,colors))/sigma
    if smooth_innovation:
        innovation=torch.lerp(innovation,pool(innovation,3),.5)
    codes=.5*colors[:,:,None,None].to(packed.dtype).expand_as(packed)
    features=torch.cat((
       innovation.clamp(-12,12), sigma.log().clamp(-12,0)/8, codes,
       (middle.clamp_min(0)+1e-4).log().clamp(-10,1)/4,
       (contrast/average).clamp(-12,12),
    ),dim=1)
    prediction=head.output(head.blocks(F.silu(head.stem(features))))
    detail, confidence=F.pixel_shuffle(prediction,2).split(1,dim=1)
    scale=.5*F.interpolate(average,scale_factor=2,mode="nearest")
    clip=(packed>=.98).any(dim=1,keepdim=True).to(packed.dtype)
    quiet=1-F.max_pool2d(clip,7,stride=1,padding=3)
    return fine_band(detail.tanh()*confidence.sigmoid()*scale)*F.interpolate(quiet,scale_factor=2,mode="nearest")


def corrections(head, current, raw, guard, independent_parent=None):
    canonical=head.luminance_delta(current,*raw)
    control=counterfactual(head,current,current,*raw)
    torch.testing.assert_close(canonical,control,rtol=0,atol=0)
    changes={CANONICAL:canonical}
    changes |= {
        SINGLE_FRAME[0]:counterfactual(head,current,current,*raw,smooth_guide=True),
        SINGLE_FRAME[1]:counterfactual(head,current,current,*raw,smooth_innovation=True),
        SINGLE_FRAME[2]:counterfactual(head,current,current,*raw,smooth_guide=True,smooth_innovation=True),
    }
    if independent_parent is not None:
        changes |= {
            DONOR[0]:counterfactual(head,independent_parent,current,*raw),
            DONOR[1]:counterfactual(head,current,independent_parent,*raw),
            DONOR[2]:counterfactual(head,independent_parent,independent_parent,*raw),
        }
    wb,matrix=raw[-2:]
    neutral=torch.linalg.solve(matrix,torch.ones_like(wb).unsqueeze(-1)).squeeze(-1)/wb
    return {
        key:(current+neutral[:,:,None,None]*delta*guard).cpu().numpy()
        for key,delta in changes.items()
    }
