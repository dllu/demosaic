"""Plot the observed native response and error changes on the transfer photos."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from capture import OUT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

COLORS = {"local": "#036b63", "near": "#426baa", "whole": "#ab4b27", "permuted": "#74658a"}


def main():
    source = reference(OUT / "mild-transfer.json")
    vals = read_json(checked(source))["summary"]["vs"]
    f, axes = plt.subplots(1, 2, figsize=(9.25, 3.65), sharey=True, layout="constrained")
    for axis, m, title in zip(
        axes, ("flat", "increment"), ("Exact-flat fine RMS", "Fine-increment RMS"), strict=True
    ):
        axis.axhline(0, color="#a9abb1", lw=1)
        axis.axvline(0, color="#a9abb1", lw=1)
        for name, c in COLORS.items():
            x0, x1, x2 = vals[f"{name} vs baseline"][m]
            y0, y1, y2 = vals[f"{name} vs baseline"]["response_pp"]
            axis.errorbar(
                x0,
                y0,
                xerr=np.array([[x0 - x1], [x2 - x0]]),
                yerr=np.array([[y0 - y1], [y2 - y0]]),
                marker="o",
                lw=1.2,
                capsize=3,
                color=c,
                label=name.capitalize(),
            )
            xx = vals[f"{name} relaxed vs baseline"][m][0]
            yy = vals[f"{name} relaxed vs baseline"]["response_pp"][0]
            axis.plot([x0, xx], [y0, yy], ls=":", color=c, alpha=0.6)
            axis.plot(xx, yy, marker="o", markerfacecolor="white", color=c, ls="none", markersize=6)
        axis.set_title(title, loc="left")
        axis.set_xlabel("Change from the nominal model (DN16)")
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", alpha=0.15)
    axes[0].set_ylabel("Recovered fine contrast (percentage points)")
    axes[1].legend(frameon=False, loc="lower right", ncol=2)
    f.suptitle(
        "32 source-disjoint ISO6400 photos\nFilled markers use the strict calibration dose. Open markers use the relaxed dose."
    )
    figure = OUT / "detail-error.png"
    f.savefig(figure, dpi=155)
    write_json(
        OUT / "plot.json",
        {"driver": reference(Path(__file__)), "source": source, "figure": reference(figure)},
    )


if __name__ == "__main__":
    main()
