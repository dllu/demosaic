"""Audit native phase, disjoint exterior selection and Gaussian risk arithmetic."""

from pathlib import Path

import numpy as np

from capture import OUT
import context_gate as op
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def layout_checks():
    n = 128
    v, u = np.mgrid[:n, :n]
    wave = 0.16 + 0.02 * np.cos(2 * np.pi * (3 * u + 4 * v) / 32 + 0.23)
    raw = np.stack([wave[i // 2 :: 2, i % 2 :: 2] for i in range(4)])
    tests = {}
    for name, cfa in PATTERNS.items():
        cfa = np.asarray(cfa)
        roi = (32, 32, 64, 64)
        # Use a larger synthetic scene where some support lies outside the reserved halo.
        wide = np.tile(raw, (1, 3, 3))
        edited = np.tile(raw, (1, 3, 3))
        edited[:, 16:48, 16:48] = 0.6
        a = op.make_atlas(wide, cfa, 0.00128, 6.5536e-6, roi)
        b = op.make_atlas(edited, cfa, 0.00128, 6.5536e-6, roi)
        assert len(a[0]) > 50
        for i, j in zip(a, b, strict=True):
            np.testing.assert_array_equal(i, j)
        plain, _ = op.raw_features(
            op.tiles(np.full_like(raw, 0.16), [[32, 32]]), cfa, 0.00128, 6.5536e-6
        )
        actual, _ = op.raw_features(op.tiles(raw, [[32, 32]]), cfa, 0.00128, 6.5536e-6)
        assert abs(plain[0]) < 1e-20 and actual[0] > 10
        tests[name] = {
            "constant": float(plain[0]),
            "known_native_wave": float(actual[0]),
            "unseen_atlas": len(a[0]),
        }
    return tests


def gaussian():
    rng = np.random.default_rng(73185)
    n = 64
    shot_scale = 0.007
    bas, trial = 0.16, 0.38
    cfa = np.asarray(PATTERNS["RGGB"])
    estimate, observed, true_proxy = [], [], []
    for i in range(16):
        target = np.full((32, 4, n // 2, n // 2), 0.12, dtype=float)
        sensor = target + rng.normal(size=target.shape) * shot_scale
        observed_noise = sensor - target
        predicted = target + bas * observed_noise
        physical_shift = (trial - bas) * observed_noise
        probe = shot_scale * np.where(rng.random(target.shape) < 0.5, -1, 1)
        b = lambda x: op.bandpass(op.native_green(x, cfa))
        d = b(physical_shift)
        y = b(predicted - sensor)
        p, q = b(probe), b(probe * (trial - bas))
        naive = 2 * y * d + d * d
        exact = 2 * b(predicted - target) * d + d * d
        estimate.append(float((naive + 2 * p * q).mean()))
        observed.append(float(naive.mean()))
        true_proxy.append(float(exact.mean()))
    score = np.array([np.mean(x) for x in (observed, estimate, true_proxy)]) * 65535.0**2
    assert score[0] < 0 < score[1] and abs(score[1] - score[2]) < 0.02 * score[2]
    return dict(
        zip(
            ("observed_site_DN16_sq", "corrected_DN16_sq", "exact_DN16_sq"),
            score.tolist(),
            strict=True,
        )
    )


def identity():
    study = read_json(OUT / "plan.json")
    groups = study["groups"]

    def source(r):
        d = r["source"]
        return d if isinstance(d, str) else d["id"]

    rows = [{source(r) for r in groups[k]} for k in ("calibration", "transfer", "wires")]
    assert list(map(len, rows)) == [32, 32, 24]
    assert all(rows[i].isdisjoint(rows[j]) for i in range(3) for j in range(i))
    inputs = {r["input"]["sha256"] for g in groups.values() for r in g}
    assert len(inputs) >= 92
    checked(study["checkpoint"])
    return {
        "pairwise_source_disjoint": True,
        "sources": list(map(len, rows)),
        "input_hash_count": len(inputs),
    }


if __name__ == "__main__":
    result = {
        "driver": reference(Path(__file__)),
        "operator": reference(Path(op.__file__)),
        "plan": reference(OUT / "plan.json"),
        "CFA_checks": layout_checks(),
        "risk_identity": gaussian(),
        "source_audit": identity(),
    }
    print(result)
    write_json(OUT / "verification.json", result)
