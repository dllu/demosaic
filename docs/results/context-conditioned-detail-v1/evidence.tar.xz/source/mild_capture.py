"""Replay two closer conditioning strengths after the broad sweep."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from capture import KEYS, OUT, batch, run
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

FACTORS = {"crisp": 0.90, "smooth": 1.15}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    source = reference(OUT / "plan.json")
    study = read_json(checked(source))
    weight = study["checkpoint"]
    model, state = load_scene_checkpoint(
        checked(weight), expected_sha256=weight["sha256"], weights="ema"
    )
    assert state["mode"] == "none" and state["step"] == 50000
    model = (
        _stage_tiled_cuda(model, torch.device("cuda")).eval().to(memory_format=torch.channels_last)
    )
    with ieee_fp32():
        for group, cases in study["groups"].items():
            records = []
            start = monotonic()
            directory = OUT / f"mild-{group}"
            directory.mkdir(exist_ok=True)
            for i, item in enumerate(cases, 1):
                binding = item["input"]
                path = directory / f"{item['id']}.npz"
                if not path.exists():
                    with np.load(checked(binding), allow_pickle=False) as f:
                        d = batch({k: f[k] for k in KEYS})
                    results = {
                        k: run(model, d, d["packed"], d["variance"], item["profile"], v)
                        .cpu()
                        .numpy()
                        for k, v in FACTORS.items()
                    }
                    assert all(np.isfinite(v).all() for v in results.values())
                    temp = path.with_suffix(".partial")
                    with temp.open("wb") as f:
                        np.savez(f, **results)
                    temp.replace(path)
                records.append({"id": item["id"], "input": binding, "output": reference(path)})
                if i % 8 == 0:
                    print(group, i, "of", len(cases), flush=True)
            write_json(
                OUT / f"mild-capture-{group}.json",
                {
                    "driver": reference(Path(__file__)),
                    "plan": source,
                    "factors": FACTORS,
                    "seconds": monotonic() - start,
                    "rows": records,
                },
            )


if __name__ == "__main__":
    main()
