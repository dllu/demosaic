"""Measure wire transfer and render both standing families with full RAW context."""

from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from capture import OUT, HERE
import context_gate as gate
from mild_score import ingredients, synthesis, paired_items
from score import signatures
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

sys.path.append(str(HERE.parent / "local-junction-support-v1"))
from review_junction import image, board

EXACT = (48, 48, 160, 160)
NAMES = ("local", "near", "whole", "permuted")
LABELS = {
    "nominal": "Local 50k, nominal",
    "wide": "Local 50k, 0.65 variance",
    "local": "Local Bayer gate",
    "near": "Nearby Bayer gate",
    "whole": "Whole-photo Bayer gate",
    "permuted": "Permuted context",
}


def apply(out, data, maps, selections):
    fields, neutral = ingredients(out, data)
    anchor = out["nominal"]
    return {"nominal": anchor} | {
        k: synthesis(anchor, fields, neutral, maps, v) for k, v in selections.items()
    }


def wire(selections):
    sys.path.append(str(HERE.parent / "scene-mixture-wire-gaps-v1"))
    from scoring import WireMetric

    rows = []
    for item, data, out, bindings in paired_items("wires"):
        geometry = item["fixture"]["geometry"]
        scorer = WireMetric(
            data | {"support": np.ones_like(data["support"])}
            if geometry["family"] == "smooth-dip"
            else data,
            geometry,
        )
        maps = signatures(data, item)
        arms = apply(out, data, maps, selections)
        rows.append(
            {
                "id": item["id"],
                "input": item["input"],
                "predictions": bindings,
                "geometry": geometry["family"],
                "scores": {k: scorer(x) for k, x in arms.items()},
            }
        )
    rng = np.random.default_rng(202611200721)
    metrics = {m for r in rows for m in r["scores"]["nominal"]}
    output = {}
    for method in ("nominal", *NAMES):
        results = {}
        for k in sorted(metrics):
            selected = np.array(
                [
                    [r["scores"][m][k] for m in ("nominal", method)]
                    for r in rows
                    if k in r["scores"][method]
                ]
            )
            n = len(selected)
            diffs = selected[:, 1] - selected[:, 0]
            intervals = diffs[rng.integers(n, size=(10000, n))].mean(1)
            results[k] = {
                "mean": float(selected[:, 1].mean()),
                "delta": [float(diffs.mean()), *np.quantile(intervals, [0.025, 0.975]).tolist()],
                "sources": n,
            }
        output[method] = results
        print(method, {k: round(p["mean"], 5) for k, p in results.items()}, flush=True)
    return {
        "rows": rows,
        "summary": output,
        "scorer": reference(HERE.parent / "scene-mixture-wire-gaps-v1/scoring.py"),
    }


def crop(arr, roi):
    x, y, w, h = roi
    return arr[..., y : y + h, x : x + w]


def standing(selections, dest):
    rows = []
    camera = list(paired_items("camera"))
    for primary in ("main", "mesh"):
        matches = [r for r in camera if r[0]["id"].startswith(primary)]
        source = matches[0][0]["raw"]
        raw, metadata = read_raw(checked(source))
        h, w = (2 * (n // 2) for n in raw.shape)
        # Read once per capture, retaining the real sensor parity and native pixel coordinates.
        frame = np.stack([raw[i // 2 : h : 2, i % 2 : w : 2] for i in range(4)])
        del raw
        cfa = color_indices(metadata.pattern).numpy()
        for r, data, out, bindings in matches:
            assert r["raw"] == source
            data = {k: v[0] if k in ("colors", "wb", "matrix") else v for k, v in data.items()}
            x, y, rw, rh = r["sensor_box"]
            assert not any(v % 2 for v in (x, y, rw, rh))
            np.testing.assert_array_equal(data["colors"], cfa)
            np.testing.assert_array_equal(
                frame[..., y // 2 : (y + rh) // 2, x // 2 : (x + rw) // 2], data["packed"][0]
            )
            noise = r["noise"]
            atlas = gate.make_atlas(frame, cfa, noise["shot"], noise["read"], r["sensor_box"])
            maps = {
                k: v[None]
                for k, v in gate.guides(
                    data["packed"][0], cfa, noise["shot"], noise["read"], (x, y), atlas
                ).items()
            }
            predictions = apply(out, data, maps, selections)
            with np.load(checked(bindings["initial"]), allow_pickle=False) as saved:
                predictions["wide"] = saved["crisp"]
            native = []
            for previous in r["displays"]:
                with Image.open(checked(previous["board"]["image"])) as original:
                    old = np.asarray(original)
                tiles = {}
                for p in previous["board"]["panels"]:
                    a, b, c, d = p["png_xywh"]
                    tiles[p["name"]] = old[b : b + d, a : a + c]
                expo = previous["exposure"]
                roi = r["local_ROI"]
                here = lambda p: image(crop(p[0], roi), data["wb"], data["matrix"], expo)
                np.testing.assert_array_equal(here(predictions["nominal"]), tiles["Local 50k"])
                mats = [(k, tiles[k]) for k in ("Noisy (Malvar)", "V120 EMA")]
                mats.extend(
                    (LABELS[k], here(predictions[k]))
                    for k in ("nominal", "wide", "local", "near", "whole")
                )
                mats.extend(
                    (k, tiles[k])
                    for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                    if k in tiles
                )
                native.append(
                    board(mats, dest / f"{r['id']}-x{expo:g}.png")
                    | {"exposure": expo, "previous": previous["board"]}
                )
            base = predictions["nominal"].astype(float)
            rms = {
                k: float(np.sqrt(np.mean(crop(v - base, r["local_ROI"]) ** 2)) * 65535)
                for k, v in predictions.items()
            }
            rows.append(
                {
                    "id": r["id"],
                    "raw": source,
                    "input": r["input"],
                    "predictions": bindings,
                    "noise": noise,
                    "camera_roi": r["global_ROI"],
                    "local_roi": r["local_ROI"],
                    "atlas_count": len(atlas[0]),
                    "changes_DN16": rms,
                    "native": native,
                }
            )
            print(r["id"], rms, flush=True)
        del frame
    return {
        "rows": rows,
        "scope": "Entire native noisy RAW captures supply the exterior atlas. Only the existing 512-pixel context is forwarded.",
    }


def photo(selections, dest):
    frozen = reference(OUT / "mild-transfer.json")
    transfer = read_json(checked(frozen))
    tab = transfer["rows"]
    plan = selections["whole"]
    from mild_score import values

    prior = values(tab, "uniform", 0, 0, 0)
    new = values(tab, "whole", plan["index"], *plan["dose"])
    score = new["increment"] - prior["increment"]
    chosen = {
        tab[int(j)]["id"]: (float(score[j]), key)
        for j, key in (
            (np.argmin(score), "largest improvement"),
            (np.argmax(score), "largest regression"),
        )
    }
    rows = []
    for r, data, out, bindings in paired_items("transfer"):
        if r["id"] not in chosen:
            continue
        maps = signatures(data, r)
        predictions = apply(out, data, maps, selections)
        with np.load(checked(bindings["initial"]), allow_pickle=False) as saved:
            predictions["wide"] = saved["crisp"]
        tools = {
            k: np.broadcast_to(data[k], (len(data["packed"]), *data[k].shape))
            for k in ("wb", "matrix", "colors")
        }
        noise = r["profile"]
        wb, matrix = data["wb"], data["matrix"]
        noisy = noisy_malvar(tools | {"packed": data["packed"]})
        native = []
        for role, label in ((0, "present"), (2, "flat")):
            show = lambda arr: image(crop(arr[role], EXACT), wb, matrix, 1 / noise["exposure"])
            tested = (
                ("Noisy Malvar", show(noisy)),
                *(
                    (LABELS[key], show(predictions[key]))
                    for key in ("nominal", "wide", "local", "near", "whole")
                ),
                ("Exact GT", show(data["target"])),
            )
            paths = {"board": board(tested, dest / f"{r['id']}-{label}-comparison.png")}
            if role == 0:
                paths["triplet"] = board(
                    [tested[i] for i in (0, 5, 6)], dest / f"{r['id']}-triplet.png"
                )
            native.append(
                {
                    "role": role,
                    "noise": noise,
                    "exposure": 1 / noise["exposure"],
                    "ROI": EXACT,
                    **paths,
                }
            )
        rows.append(
            {
                "id": r["id"],
                "source": r["source"],
                "input": r["input"],
                "predictions": bindings,
                "query": r["box"],
                "selection": chosen[r["id"]][1],
                "increment_delta_DN16": chosen[r["id"]][0],
                "native": native,
            }
        )
        print(r["id"], chosen[r["id"]], flush=True)
    return {"source": frozen, "rows": rows}


if __name__ == "__main__":
    torch.set_num_threads(2)
    lock = reference(OUT / "mild-calibration.json")
    policy = read_json(checked(lock))["policy"]
    selections = {k: policy["specs"][k]["chosen"] for k in NAMES}
    kind = sys.argv[1]
    dest = OUT / "native" / kind
    dest.mkdir(exist_ok=True, parents=True)
    result = {"camera": standing, "exact": photo}.get(kind)
    record = wire(selections) if kind == "wires" else result(selections, dest)
    write_json(
        OUT / f"review-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "calibration": lock,
            "selected": selections,
            "report": record,
        },
    )
