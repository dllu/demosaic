"""Write the immutable context-conditioning analysis, crop manifest and archive."""

from copy import deepcopy
from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from capture import OUT, HERE
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

PROJECT = Path.cwd()
ASSETS = PROJECT / "docs/assets" / HERE.name
RESULTS = PROJECT / "docs/results" / HERE.name
BORROWED = (
    "scene-mixture-wire-gaps-v1/scoring.py",
    "local-junction-support-v1/review_junction.py",
)
NAMES = (
    "plan",
    "verification",
    "plot",
    "evaluation-calibration",
    "evaluation-transfer",
    "mild-calibration",
    "mild-transfer",
    "review-exact",
    "review-wires",
    "review-camera",
    *(
        f"{name}-{group}"
        for name in ("capture", "mild-capture")
        for group in ("calibration", "transfer", "wires", "camera")
    ),
)


def local(path):
    return reference(path) | {"path": str(path.relative_to(PROJECT))}


def png(row):
    relative_path = checked(row["image"])
    target = ASSETS / relative_path.name
    shutil.copyfile(relative_path, target)
    receipt = local(target)
    assert receipt["sha256"] == row["image"]["sha256"]
    with Image.open(target) as raster:
        for tile in row["panels"]:
            x, y, w, h = tile["png_xywh"]
            assert (
                (w, h) == (160, 160)
                and 0 <= x < x + w <= raster.width
                and 0 <= y < y + h <= raster.height
            )
    return row | {"image": receipt}


def main():
    refs = {name: reference(OUT / f"{name}.json") for name in NAMES}
    contents = {name: read_json(checked(binding)) for name, binding in refs.items()}
    for name, obj in contents.items():
        for key in ("driver", "operator", "renderer", "score"):
            if key in obj:
                checked(obj[key])
    plan = contents["plan"]
    verified = contents["verification"]
    assert verified["plan"] == refs["plan"] and verified["source_audit"]["pairwise_source_disjoint"]
    checked(plan["checkpoint"])
    for group, items in plan["groups"].items():
        a, b = (contents[f"{k}-{group}"] for k in ("capture", "mild-capture"))
        assert a["plan"] == b["plan"] == refs["plan"]
        for item, d, e in zip(items, a["rows"], b["rows"], strict=True):
            assert item["id"] == d["id"] == e["id"] and item["input"] == d["input"] == e["input"]
            checked(item["input"])
            checked(d["output"])
            checked(e["output"])
    assert contents["evaluation-transfer"]["locked"] == refs["evaluation-calibration"]
    assert contents["mild-transfer"]["frozen_calibration"] == refs["mild-calibration"]
    assert contents["plot"]["source"] == refs["mild-transfer"]
    for kind in ("exact", "wires", "camera"):
        assert contents[f"review-{kind}"]["calibration"] == refs["mild-calibration"]
    camera = deepcopy(contents["review-camera"]["report"]["rows"])
    exact = deepcopy(contents["review-exact"]["report"]["rows"])
    assert len(exact) == 2 and len(camera) == 8
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    for r in camera:
        r["native"] = [png(b) for b in r["native"]]
    for r in exact:
        for item in r["native"]:
            for k in ("board", "triplet"):
                if k in item:
                    item[k] = png(item[k])
    fig = ASSETS / "detail-error.png"
    shutil.copyfile(checked(contents["plot"]["figure"]), fig)
    assert local(fig)["sha256"] == contents["plot"]["figure"]["sha256"]
    index = ASSETS / "manifest.json"
    write_json(
        index,
        {
            "checkpoint": plan["checkpoint"],
            "weights": "EMA",
            "precision": plan["precision"],
            "camera": camera,
            "exact": exact,
            "tradeoff": local(fig),
            "locked_calibration": refs["mild-calibration"],
        },
    )
    files = {f"receipts/{k}.json": v for k, v in refs.items()}
    files.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    files.update({f"reused/{k}": reference(HERE.parent / k) for k in BORROWED})
    files.update({f"logs/{p.name}": reference(p) for p in OUT.glob("*.log")})
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as t:
        for name, file in files.items():
            t.add(checked(file), arcname=name, recursive=False)
    with tarfile.open(archive) as t:
        assert set(t.getnames()) == files.keys()
        for name, binding in files.items():
            with t.extractfile(name) as file:
                assert file_digest(file, "sha256").hexdigest() == binding["sha256"]
    summary = RESULTS / "summary.json"
    output = {
        group: {
            "broad": contents[f"evaluation-{group}"]["summary"],
            "risk": contents[f"evaluation-{group}"]["risk_proxy"],
            "bounded": contents[f"mild-{group}"]["summary"],
        }
        for group in ("calibration", "transfer")
    }
    output["wire"] = contents["review-wires"]["report"]["summary"]
    output["camera"] = {r["id"]: r["changes_DN16"] for r in camera}
    output["verification"] = verified
    output["locked"] = {
        k: v["chosen"] for k, v in contents["mild-calibration"]["policy"]["specs"].items()
    }
    output["endpoint"] = plan["checkpoint"]
    write_json(summary, output)
    write_json(
        RESULTS / "publication.json",
        {
            "archive": local(archive),
            "summary": local(summary),
            "manifest": local(index),
            "files": files,
            "inference_checkpoint": plan["checkpoint"],
            "training": "none",
            "scope": "Exact natural, wire and both qualitative GFX families. Fixed external model panels are out of scope.",
        },
    )
    print(local(archive))


if __name__ == "__main__":
    main()
