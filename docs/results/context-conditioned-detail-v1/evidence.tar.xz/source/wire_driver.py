"""Reuse the frozen wire metric without loading the old inference experiment."""

import ast
from pathlib import Path
import sys
from types import ModuleType

import numpy as np
from scipy.special import expit

from capture import OUT, HERE
from review import wire, NAMES
from score import luma
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def metric():
    source = HERE.parent / "scene-mixture-wire-gaps-v1/scoring.py"
    program = ast.parse(source.read_text(), filename=str(source))
    names = {"rms", "space", "remove_basis", "wire_bases", "WireMetric"}
    functions = [
        n
        for n in program.body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names
    ]
    assert {fn.name for fn in functions} == names
    env = ModuleType("scoring")
    env.__dict__.update(
        np=np,
        expit=expit,
        SCORED=np.s_[..., 64:192, 64:192],
        luma=lambda a, wb, m: luma(a, {"wb": wb, "matrix": m}),
    )
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), "exec"), env.__dict__)
    return env


if __name__ == "__main__":
    sys.modules["scoring"] = metric()
    lock = reference(OUT / "mild-calibration.json")
    policy = read_json(checked(lock))["policy"]
    selections = {k: policy["specs"][k]["chosen"] for k in NAMES}
    write_json(
        OUT / "review-wires.json",
        {
            "driver": reference(Path(__file__)),
            "renderer": reference(HERE / "review.py"),
            "calibration": lock,
            "selected": selections,
            "report": wire(selections),
        },
    )
