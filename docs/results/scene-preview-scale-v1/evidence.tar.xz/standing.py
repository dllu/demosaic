"""Re-encode the same complete GFX RAW at several preview levels."""
import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.cfa import pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_context import scene_preview
from probe_scene_context_extent import ARGUMENTS, encode, observation
from profile_raw_kernel_inference import model_hash

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "scene-local-contrast-2400-v1"
PLAN = ROOT / "standing-plan.json"
MODELS = ("plain-spatial", "localized-spatial")
POLICIES = ("1024","2048","3072","1024-to-2048")
BACKBONE_SHA = "691963f0f796aac860d818d59d9d14287a4675612829fbe9467c7f5df8ce5b14"
sys.path.insert(0,str(SOURCE))
from evaluate import setup_models

def freeze():
    earlier = SOURCE/"reviews/standing/collection.json"
    collection = read_json(earlier)
    training = checked(collection["training"])
    endpoints = read_json(training)["endpoints"]
    models = {k:endpoints[k]["checkpoint"]|{"type":"scene","mode":"spatial","step":2400} for k in MODELS}
    write_json(PLAN, {
        "driver":reference(__file__),
        "models":models,"prior":reference(earlier),"training":reference(training),
        "prior_render":reference(earlier.parent/"render/result.json"),
        "preview_implementation":reference(Path("src/demosaic/scene_context.py")),
        "rendered_grid_control":"1024-to-2048 bilinearly resamples the same rendered 1024 preview.",
        "policies":POLICIES,
        "scope":"All eight fixed standing GFX crop/profile views. All receive the identical native packed observations and noise parameters as prior registered reviews. Validated neutral and local-only points remain visible as earlier results.",
    })

def synchronize_time():
    torch.cuda.synchronize()
    return time.monotonic()

def fields(model, packed, args, exposure):
    levels = (1024,2048,3072)
    preview = {size:scene_preview(packed,*[args[k][0] for k in ("colors","wb","matrix")],
                                 long_side=size,exposure=exposure) for size in levels}
    _, finer = preview[2048]
    control = F.interpolate(preview[1024][0],size=finer.preview_hw,
                            mode="bilinear",align_corners=False)
    modes = {str(k):v for k,v in preview.items()}|{"1024-to-2048":(control,finer)}
    for name,(image,grid) in modes.items():
        torch.cuda.reset_peak_memory_stats()
        started = synchronize_time()
        encoded = encode(model,image,grid)
        seconds = synchronize_time()-started
        yield name, encoded, {
            "preview":fingerprint(image.cpu()), "preview_hw":grid.preview_hw,
            "native_hw":grid.native_hw, "encoder_seconds":seconds,
            "run_peak_cuda_allocation_GiB":torch.cuda.max_memory_allocated()/2**30,
        }

@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[17,18])
    os.nice(10)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    plan = read_json(PLAN)
    assert checked(plan["driver"])==Path(__file__) and tuple(plan["policies"])==POLICIES
    prior = read_json(checked(plan["prior"]))
    records = {k:read_json(checked(prior["epochs"][k])) for k in MODELS}
    base = records[MODELS[0]]
    spec = read_json(checked(base["plan"]))
    assert spec["preview_long_side"]==1024 and base["weights"]=="EMA"
    output = ROOT/"standing"
    output.mkdir()
    table = {k:{r["id"]:r for r in value["records"]} for k,value in records.items()}
    models = setup_models(plan)
    encoder = models[MODELS[0]]
    other = models[MODELS[1]]
    assert all(torch.equal(getattr(encoder.base.context,k),getattr(other.base.context,k))
               for k in ("mean","std"))
    assert model_hash(encoder.base.context.backbone)==BACKBONE_SHA
    for model in models.values():
        model.eval().to(memory_format=torch.channels_last)
    result = {}
    with ieee_fp32():
        for family, obs_kind in (("main","gfx"),("mesh","mesh")):
            source = checked(base["full_real_noisy_sources"][family])
            assert source.is_relative_to(Path.cwd()/".cache")
            assert records[MODELS[1]]["full_real_noisy_sources"][family]==base["full_real_noisy_sources"][family]
            raw, metadata = read_raw(source)
            assert metadata.pattern=="RGGB"
            cases = [row for row in spec["observations"] if row["kind"]==obs_kind]
            packed = pack(torch.from_numpy(raw)[None,None])[0].cuda()
            rows = {}
            for row in cases:
                key = row["id"]
                args,_ = observation(row["arrays"],False)
                old = table[MODELS[0]][key]
                assert all(table[k][key]["input_fingerprints"]==old["input_fingerprints"] for k in MODELS)
                assert {k:fingerprint(v)for k,v in args.items()}==old["input_fingerprints"]
                boxes = old["scene_box_xywh"]
                assert boxes == table[MODELS[1]][key]["scene_box_xywh"]
                for (x,y,w,h), crop in zip(boxes,args["packed"],strict=True):
                    assert torch.equal(packed[:,y//2:(y+h)//2,x//2:(x+w)//2].cpu(),crop)
                args={k:v.cuda()for k,v in args.items()}
                for k in ARGUMENTS[:2]:
                    args[k]=args[k].contiguous(memory_format=torch.channels_last)
                rows[key]=(row,args,boxes)
            calibration = next(iter(rows.values()))[1]
            assert all(torch.equal(calibration[k],args[k]) for _,args,_ in rows.values()
                       for k in ("colors","wb","matrix"))
            for name, scene, evidence in fields(encoder,packed,calibration,spec["preview_exposure"]):
                print(family,name,evidence["preview_hw"],round(evidence["encoder_seconds"],2),flush=True)
                for key,(row,args,boxes) in rows.items():
                    entry = result.setdefault(key,{"capture":family,"observation":row,"boxes":boxes,
                                                   "exact_input_fingerprints":table[MODELS[0]][key]["input_fingerprints"],
                                                   "predictions":{}})
                    prediction = {}
                    for tag,model in models.items():
                        model.base.set_noise(row["noise"]["shot"],row["noise"]["read"])
                        began = synchronize_time()
                        rgb = model(*args.values(),scene=scene,boxes_xywh=boxes).cpu().numpy()
                        elapsed = synchronize_time()-began
                        assert list(rgb.shape)==row["output_shape"] and np.isfinite(rgb).all()
                        dest = output/f"{key}-{tag}-{name}.npy"
                        with dest.open("xb") as stream:
                            np.save(stream,rgb,allow_pickle=False)
                        older = np.load(checked(table[tag][key]["prediction"]),allow_pickle=False)
                        prediction[tag] = {"file":reference(dest),"seconds":elapsed,
                            "prior_CPU_1024":table[tag][key]["prediction"],
                            "delta_rms_vs_prior_CPU_1024_DN16":float(65535*np.sqrt(np.mean((rgb.astype(float)-older)**2)))}
                    entry["predictions"][name]={"preview":evidence,"models":prediction}
                del scene
            del packed, raw
    assert len(result)==6 and all(tuple(row["predictions"])==POLICIES for row in result.values())
    write_json(ROOT/"standing-results.json",{"plan":reference(PLAN),"cases":result,
                "precision":"CUDA IEEE FP32, channels last, EMA","native_images_viewed":False})

if __name__=="__main__":
    parse = argparse.ArgumentParser(description=__doc__)
    parse.add_argument("--plan",action="store_true")
    freeze() if parse.parse_args().plan else run()
