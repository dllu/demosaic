"""Source-paired statistics for the preview and output-band interventions."""
import argparse
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import read_json,reference,write_json

HERE=Path(__file__).resolve().parent
ORIG=HERE.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(ORIG))
from analyze_matched import compare

MODELS=("plain-spatial","localized-spatial")
FAINT=ORIG/"matched-analysis-plan.json"
RESAMPLES=20000

def ordinary(rows):
    for profile in sorted({row["profile"]for row in rows}):
        for draw in ("coupled","independent"):
            group=[row for row in rows if (row["profile"],row["draw"])==(profile,draw)]
            assert len(group)==64
            yield profile,draw,group

def preview_pairs():
    for model,local in zip(MODELS,("plain-none","localized-none"),strict=True):
        fine=f"{model}/fine"
        yield model,{
            "fine_minus_coarse":{fine:1,f"{model}/coarse":-1},
            "fine_minus_resampled_coarse":{fine:1,f"{model}/resampled-coarse":-1},
            "resampled_coarse_minus_coarse":{f"{model}/resampled-coarse":1,f"{model}/coarse":-1},
            "fine_minus_native_cap":{fine:1,f"{model}/matching":-1},
            "fine_minus_matched_local":{fine:1,local:-1},
            "fine_minus_corpus100k":{fine:1,"100k":-1},
        }

def flatten_bands(rows):
    for row in rows:
        yield row|{"metrics":{f"{model}/{arm}":values
                       for model,arms in row["arms"].items()for arm,values in arms.items()}}

def band_pairs():
    for model in MODELS:
        s=lambda label:f"{model}/{label}"
        yield model,{
            "coarse_only_minus_full":{s("coarse-only"):1,s("matching"):-1},
            "coarse_only_minus_neutral":{s("coarse-only"):1,s("neutral"):-1},
            "fine_only_minus_neutral":{s("fine-only"):1,s("neutral"):-1},
            "full_minus_neutral":{s("matching"):1,s("neutral"):-1},
        }

def run(kind):
    input_path=HERE/("natural-results.json"if kind=="preview"else "context-band-sources.json")
    rows=read_json(input_path)
    record=rows["rows"]if kind=="preview"else list(flatten_bands(rows["frames"]))
    pairs=list(preview_pairs()if kind=="preview"else band_pairs())
    faint={r[2]for r in read_json(FAINT)["fainter_half_by_frozen_clean_increment"]}
    rng=np.random.default_rng(510225)
    results={}
    for profile,draw,group in ordinary(record):
        half=[r for r in group if r["source"]in faint]
        assert len(half)==32
        for cohort,selected in (("all",group),("fainter",half)):
            methods={}
            for model,comparisons in pairs:
                findings={}
                for name,weights in comparisons.items():
                    primary=compare(selected,weights,rng,True)
                    extra={}
                    samples=rng.integers(len(selected),size=(RESAMPLES,len(selected)))
                    for key,path in (
                        ("flat_RGB_bias_DN16",("uniform_core","quiet_RGB_mean_absolute_bias_DN16")),
                        ("flat_RGB_centered_RMS_DN16",("uniform_core","quiet_RGB_centered_RMS_DN16")),
                    ):
                        effects=np.array([sum(weight*r["metrics"][m][path[0]][path[1]]
                                          for m,weight in weights.items())for r in selected])
                        extra[key]={"estimate":float(effects.mean()),
                                    "percentile_interval_95":np.quantile(effects[samples].mean(1),[.025,.975]).tolist()}
                    findings[name]=primary|extra
                methods[model]=findings
            results.setdefault(profile,{}).setdefault(draw,{})[cohort]=methods
    write_json(HERE/f"{kind}-paired.json",{"analysis_driver":reference(__file__),"observations":reference(input_path),
        "fainter_selection":reference(FAINT),"estimates":results,
        "scope":"Paired resampling of complete held-out photos. Report each noise draw separately."})

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind",choices=("preview","band"))
    run(parser.parse_args().kind)
