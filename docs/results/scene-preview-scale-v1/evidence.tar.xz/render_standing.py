"""Render and measure all standing crops with the same native sensor coordinates."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop

ROOT = Path(__file__).resolve().parent
RAW = ROOT/"standing-results.json"
MODELS = ("plain-spatial","localized-spatial")
NAMES = {"1024":"Actual 1024","2048":"Actual 2048","3072":"Actual 3072",
         "1024-to-2048":"1024 resampled to 2048"}

def rms(value):
    return float(65535*np.sqrt(np.mean(np.asarray(value,dtype=np.float64)**2)))

def board(path, panels):
    result = Image.new("RGB",(8+168*len(panels),192),"#eeeeee")
    draw = ImageDraw.Draw(result)
    fields=[]
    for i,(name,pixels) in enumerate(panels):
        assert pixels.dtype==np.uint8 and pixels.shape==(160,160,3)
        x = 8+168*i
        draw.text((x,5),name,fill="black")
        result.paste(Image.fromarray(pixels),(x,24))
        fields.append({"label":name,"png_xywh":[x,24,160,160]})
    result.save(path)
    reread = np.asarray(Image.open(path))
    for field,(_,pixels) in zip(fields,panels,strict=True):
        x,y,w,h=field["png_xywh"]
        np.testing.assert_array_equal(reread[y:y+h,x:x+w],pixels)
    return {"image":reference(path),"panels":fields}

def run():
    torch.set_num_threads(1)
    source = read_json(RAW)
    past = read_json(checked(read_json(checked(source["plan"]))["prior_render"]))
    photos=ROOT/"standing-native"; photos.mkdir()
    output = []
    for item in past["boards"]:
        if item["observation"] not in source["cases"]:
            continue
        observation = source["cases"][item["observation"]]
        panel = np.asarray(Image.open(checked(item["image"])).convert("RGB"))
        panels = {r["label"]:panel[y:y+h,x:x+w].copy() for r in item["panels"]
                  for x,y,w,h in [r["png_xywh"]]}
        roi = item["case"]["ROI_xywh"]
        x,y,w,h=roi
        assert (w,h)==(160,160)
        with np.load(checked(item["input_arrays"]),allow_pickle=False)as loaded:
            wb,matrix=(torch.from_numpy(loaded[k])for k in ("wb","matrix"))
        measured={}
        for arm in MODELS:
            values={k:np.load(checked(v["models"][arm]["file"]),allow_pickle=False)
                    for k,v in observation["predictions"].items()}
            crops={k:v[0,:,y:y+h,x:x+w].astype(np.float64)for k,v in values.items()}
            absolute={}
            for k,v in crops.items():
                detail=v-gaussian_filter(v,(0,4,4),mode="reflect")
                absolute[k]={"RGB_RMS_from_1024_DN16":rms(v-crops["1024"]),
                             "mean_RGB_difference_from_1024_DN16":(65535*(v-crops["1024"]).mean((1,2))).tolist(),
                             "band_RMS_DN16":rms(detail)}
            displays={}
            for k,value in values.items():
                rgb=display_crop(torch.from_numpy(value),wb,matrix,roi,exposure=item["display_exposure"])
                displays[k]=np.rint(rgb.clip(0,1)*255).astype(np.uint8)
            inds=(["ISO6400 camera JPEG"]if "ISO6400 camera JPEG"in panels else [])
            inds.extend(["Noisy (Malvar)","V120 EMA","Parent 100k EMA"])
            showing=[(k,panels[k])for k in inds]
            showing.extend((NAMES[k],displays[k])for k in NAMES)
            showing.append(("ISO100 AHD reference",panels["ISO100 AHD reference"]))
            if "ISO100 camera JPEG"in panels:
                showing.append(("ISO100 camera JPEG",panels["ISO100 camera JPEG"]))
            measured[arm]={"measurements":absolute,
                "same_grid_added_preview_information_RMS_DN16":rms(crops["2048"]-crops["1024-to-2048"]),
                "native":board(photos/f"{item['id']}-{arm}.png",showing)}
        output.append({"id":item["id"],"ROI_xywh":roi,"native_full_query":observation["boxes"],
                       "expected_noise":item["noise"],"reference_role":item["reference_role"],
                       "display_exposure":item["display_exposure"],"results":measured,
                       "earlier_render":item["image"]})
    assert len(output)==8
    write_json(ROOT/"standing-native.json",{
        "driver":reference(__file__),"results":reference(RAW),"rows":output,
        "scope":"Fixed unresized 160x160 pixels. RMS calculations describe output differences; differently exposed ISO100/AHD and JPEG pixels are qualitative references.",
    })

if __name__=="__main__":
    run()
