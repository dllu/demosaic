"""Relate measured mesh proposals to the real preview sampling grids."""
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json

HERE = Path(__file__).resolve().parent
STANDING = HERE/"standing-results.json"
WIRES = HERE.parent/"mesh-background-transmission-v1/standing.json"

def main():
    sensor = read_json(STANDING)["cases"]
    rows = []
    for board in read_json(WIRES)["native_boards"]:
        if board["trace"] is None:
            continue
        matches = [v for k,v in sensor.items()if board["id"].startswith(k+"-")]
        case, = matches
        policies = {}
        carriers = [v["frequency"]for v in board["trace"]["carriers"]]
        for name,prediction in case["predictions"].items():
            field = prediction["preview"]
            ny,nx = [p/(2*n)for p,n in zip(field["preview_hw"],field["native_hw"],strict=True)]
            policies[name]={"Nyquist_cyc_per_native_xy":[nx,ny],
                "carrier_in_rectangular_band":[abs(fx)<nx and abs(fy)<ny for fx,fy in carriers],
                "grid_contains_new_samples":name!="1024-to-2048"}
        rows.append({"crop":board["id"],"carriers_cyc_per_native_xy":carriers,"preview_policies":policies})
    assert len(rows)==5
    write_json(HERE/"frequency-geometry.json",{
        "source":reference(__file__),"standing":reference(STANDING),"carrier_proposals":reference(WIRES),
        "scope":"Geometric sampling bound on previously supported proposals before any learned stage. This does not measure the actual amplitudes, phase reliability, classification or the encoder's transfer.",
        "rows":rows})

if __name__=="__main__":
    main()
