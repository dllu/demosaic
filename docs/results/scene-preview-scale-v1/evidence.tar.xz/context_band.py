"""Separate the measured effect of aligned context into slow and fine output components."""
from pathlib import Path
import sys
import time

import numpy as np
from scipy.ndimage import gaussian_filter

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(SOURCE))
from measure import parts

MODELS=("plain-spatial","localized-spatial")
SIGMA=3.

def run():
    previous=SOURCE/"evaluation"
    plan=read_json(previous/"plan.json")
    owner=read_json(SOURCE/"reviews/heldout/queue-launch.json")
    definition=read_json(checked(plan["panel"]))
    rows=[]
    start=time.monotonic()
    for index in plan["selected_indices"]:
        for profile in definition["profiles"]:
            for draw in definition["draws"]:
                location=previous/"predictions"/f"{index:03d}-{profile['name']}-{draw}.json"
                while not location.exists():
                    if not owner_live(owner):
                        raise RuntimeError(f"Missing source evaluation receipt {location}")
                    time.sleep(5)
                prior=read_json(location)
                case=read_json(checked(prior["case"]))
                with np.load(checked(case["input"]),allow_pickle=False)as source:
                    truth=source["target"]
                    fields={k:np.broadcast_to(source[k][None],(3,*source[k].shape)) for k in ("wb","matrix")}
                fields["exposure"]=profile["exposure"]
                arms={}
                with np.load(checked(prior["saved"]),allow_pickle=False)as values:
                    for model in MODELS:
                        neutral=values[f"{model}--neutral"]
                        matching=values[f"{model}--matching"]
                        raw=matching.astype(np.float64)-neutral
                        smooth=gaussian_filter(raw,(0,0,SIGMA,SIGMA),mode="reflect")
                        high=raw-smooth
                        np.testing.assert_allclose(neutral+smooth+high,matching,atol=1e-12,rtol=0.)
                        policies={"neutral":neutral,"matching":matching,
                                  "coarse-only":(neutral+smooth).astype(np.float32),
                                  "fine-only":(neutral+high).astype(np.float32)}
                        arms[model]={k:parts(fields,p,truth,definition)for k,p in policies.items()}
                rows.append({"case":reference(location),"source":case["source"],"profile":profile["name"],
                             "draw":draw,"arms":arms})
        print(index,len(rows),round(time.monotonic()-start,2),flush=True)
    assert len(rows)==256
    write_json(ROOT/"context-band-sources.json",{"driver":reference(__file__),
        "scope":"Frozen outputs, no new neural inference. Separate the aligned-preview minus masked-preview correction by linear camera RGB spatial scale, exact local inputs and checkpoints.",
        "blur_sigma_native":SIGMA,"frames":rows})

if __name__=="__main__":
    run()
