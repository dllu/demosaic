"""Measure preview sampling on the full ISO6400 exact-target context panel."""
import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_context import scene_preview
from probe_scene_context_extent import encode

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(SOURCE))
from evaluate import ARGS,load,setup_models
from measure import parts,reduce

PLAN = ROOT/"natural-plan.json"
MODELS = ("plain-spatial","localized-spatial")
DRAWS = ("coupled","independent")
POLICIES = ("coarse","fine","resampled-coarse")
PITCH = 11662./1024

def freeze():
    earlier_path = SOURCE/"evaluation/plan.json"
    earlier = read_json(earlier_path)
    assert len(earlier["selected_indices"])==64 and not earlier["pilot"]
    write_json(PLAN, {
        "driver":reference(__file__),"previous":reference(earlier_path),"sensor_panel":earlier["panel"],
        "models":{k:earlier["models"][k]for k in MODELS},
        "selected_indices":earlier["selected_indices"],"precision":"CUDA IEEE FP32, channels last, EMA",
        "target_profile":"iso6400","draws":DRAWS,
        "policies":POLICIES,"native_pitch_coarse":PITCH,"native_pitch_fine":PITCH/2,
        "baseline":"Previously evaluated native-cap matching scenes, V120, Corpus 100k and both matched local EMA arms.",
        "intervention":"Keep the complete field and exact native observations. Degrade the number of preview samples per native pixel to the standing GFX sensor's spacing under 1024 and 2048 preview caps. The resampled coarse arm is a grid-density control within each same physical field.",
        "roles":"Existing physically coupled and independently drawn present/absent fine increments and truly constant flat cores.",
    })

def fields(model, data, setting):
    x,y,w,h = [k//2 for k in setting["box"]]
    original = data["scene_packed"]
    global_long = 2*max(original.shape[-2:])
    a,b = round(global_long/PITCH),round(global_long/(PITCH/2))
    assert 32<a<b<=max(original.shape[-2:])
    meta = [data[key]for key in ("colors","wb","matrix")]
    modes = {k:[]for k in POLICIES}
    receipts = []
    for crop in data["packed"]:
        raw = original.clone()
        raw[:,y:y+h,x:x+w] = crop
        torch.testing.assert_close(raw[:,y:y+h,x:x+w],crop,atol=0,rtol=0)
        assert torch.equal(raw[:,:y],original[:,:y]) and torch.equal(raw[:,y+h:],original[:,y+h:])
        assert torch.equal(raw[:,y:y+h,:x],original[:,y:y+h,:x])
        assert torch.equal(raw[:,y:y+h,x+w:],original[:,y:y+h,x+w:])
        coarse, cg = scene_preview(raw,*meta,long_side=a)
        fine, fg = scene_preview(raw,*meta,long_side=b)
        resized = F.interpolate(coarse,size=fg.preview_hw,mode="bilinear",align_corners=False)
        new = {"coarse":(coarse,cg),"fine":(fine,fg),"resampled-coarse":(resized,fg)}
        receipts.append({key:{"input":fingerprint(rgb.cpu()),"preview_hw":grid.preview_hw,
                              "native_hw":grid.native_hw}for key,(rgb,grid) in new.items()})
        for key,(rgb,grid) in new.items():
            modes[key].append(encode(model,rgb,grid))
    return modes,receipts

@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[17,19])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,7*2**30/torch.cuda.get_device_properties(0).total_memory))
    plan=read_json(PLAN)
    assert checked(plan["driver"])==Path(__file__) and tuple(plan["policies"])==POLICIES
    models=setup_models(plan)
    encoder=models[MODELS[0]]
    assert all(torch.equal(getattr(encoder.base.context,k),getattr(models[MODELS[1]].base.context,k))
               for k in ("mean","std"))
    spec=read_json(checked(plan["sensor_panel"]))
    profile=next(p for p in spec["profiles"] if p["name"]==plan["target_profile"])
    previous=checked(plan["previous"])
    ou=ROOT/"natural"; ou.mkdir()
    rows=[]
    t0=time.monotonic()
    with ieee_fp32():
        for i in plan["selected_indices"]:
            for draw in DRAWS:
                binding,setting,arrays=load(i,(profile["name"],draw))
                witness=previous.parent/"predictions"/(setting["id"]+".json")
                while not witness.exists():
                    time.sleep(5)
                former=read_json(witness)
                assert former["plan"]==plan["previous"] and former["case"]==binding
                assert former["exact_query_inputs"]=={k:setting["fingerprints"][k]for k in ARGS}
                with np.load(checked(setting["input"]),allow_pickle=False)as file:
                    target=file["target"]
                data={k:torch.from_numpy(v).cuda()for k,v in arrays.items()}
                views,proof=fields(encoder,data,setting)
                query=[data[k] if k in ("packed","variance") else data[k][None].expand(3,*data[k].shape)
                       for k in ARGS]
                for j,k in enumerate(ARGS[:2]):
                    query[j]=query[j].contiguous(memory_format=torch.channels_last)
                    assert fingerprint(query[j].contiguous().cpu())==setting["fingerprints"][k]
                fields_np={k:np.broadcast_to(arrays[k],(3,*arrays[k].shape))for k in ("wb","matrix")}
                fields_np["exposure"]=profile["exposure"]
                prediction={}
                for key,model in models.items():
                    model.base.set_noise(profile["shot"],profile["read"])
                    for mode,context in views.items():
                        prediction[f"{key}/{mode}"]=model(*query,scene=context,
                                                boxes_xywh=[setting["box"]]*3).cpu().numpy()
                assert all(v.shape==target.shape and np.isfinite(v).all() for v in prediction.values())
                dest=ou/(setting["id"]+".npz")
                with dest.open("xb") as stream:
                    np.savez(stream,**{k.replace("/","--"):v for k,v in prediction.items()})
                prior_keys=["V120","100k","plain-none","localized-none",
                            *[f"{k}/matching"for k in MODELS]]
                with np.load(checked(former["saved"]),allow_pickle=False)as file:
                    prior={k:file[k.replace("/","--")]for k in prior_keys}
                metrics={k:parts(fields_np,v,target,spec)for k,v in (prior|prediction).items()}
                row={"source":setting["source"],"profile":profile["name"],"draw":draw,
                     "case":binding,"previous_prediction":reference(witness),"saved":reference(dest),
                     "measurements":proof,"metrics":metrics}
                write_json(dest.with_suffix(".json"),row)
                rows.append(row)
            print(i,len(rows),round(time.monotonic()-t0,2),flush=True)
    assert len(rows)==128
    write_json(ROOT/"natural-results.json",{"plan":reference(PLAN),"rows":rows,"pooled":reduce(rows),
                   "count":{"sources":64,"groups":len(rows),"observations":3*len(rows)},
                   "inference_and_scoring_seconds":time.monotonic()-t0})

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else run()
