"""Verify package defaults and the adjacent fallback against native archived inputs."""

import os
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import refine_local_raw_mesh
from demosaic.prediction_archive import fingerprint

from delivery import ROOT, load, window
from adjacent import BEFORE

old_frequency = load("demosaic._mesh_frequency_before_adjacent", ROOT / "before-_mesh_frequency.py")
old_mesh = load("demosaic.mesh_refinement_before_adjacent", ROOT / "before-mesh_refinement.py")
old_mesh.infer_prior = old_frequency.infer_prior
old_mesh.query_phases = old_frequency.query_phases


def difference(a, b):
    return float(np.sqrt(np.mean((a.astype(float) - b)**2)) * 65535)


def main():
    baseline = read_json(BEFORE / "camera.json")
    pilots = read_json(ROOT / "adjacent-ranked.json")
    archived = {row["id"]: row for row in pilots["views"]}
    out = ROOT / "port"
    out.mkdir()
    results = []
    for row in baseline["views"]:
        key = row["id"]
        box, roi, noise = row["query"], row["ROI"], row["noise"]
        with np.load(checked(row["input"]), allow_pickle=False) as archive:
            raw, variance, cfa = (archive[name][0] for name in ("packed", "variance", "colors"))
        parent = np.load(checked(row["parent"]), allow_pickle=False)[0]
        crop = window(parent, roi)
        run = (parent, raw, variance, cfa, box, roi)
        config = {k: noise[k] for k in ("shot", "read")}
        config["donor_span"] = 112 if key.startswith("mesh-") else 80
        prior = old_mesh.refine_local_raw_mesh(*run, **config)
        default = refine_local_raw_mesh(*run, **config)
        np.testing.assert_array_equal(prior, default)
        gap_prior = old_mesh.refine_local_raw_mesh(*run, suppress_gaps=True, **config)
        gap_default = refine_local_raw_mesh(*run, suppress_gaps=True, **config)
        np.testing.assert_array_equal(gap_prior, gap_default)
        matched = refine_local_raw_mesh(*run, adjacent_donors=True, **config)
        composite = refine_local_raw_mesh(*run, adjacent_donors=True, suppress_gaps=True, **config)
        with np.load(checked(archived[key]["iterations"]), allow_pickle=False) as d:
            trial = crop + d["fallback"]
        if "fine-green-mesh-right" in key:
            assert np.array_equal(default, crop)
            np.testing.assert_array_equal(matched, trial)
        else:
            np.testing.assert_array_equal(matched, default)
        cache = out / (key + ".npz")
        np.savez_compressed(cache, default=default, adjacent=matched, adjacent_gap=composite)
        metrics = {
            "id": key, "native_array": reference(cache), "input": row["input"], "noise": config,
            "crop": roi, "unchanged_default": True, "unchanged_default_gap": True,
            "fingerprints": {k: fingerprint(v) for k, v in
                             (("raw", raw), ("parent", parent), ("adjacent", matched))},
            "adjacent_RMS_DN16": difference(default, matched),
            "second_gap_check_RMS_DN16": difference(matched, composite),
            "relative_to_pilot_DN16": difference(matched, trial),
        }
        results.append(metrics)
        print(key, metrics["adjacent_RMS_DN16"], metrics["relative_to_pilot_DN16"],
              metrics["second_gap_check_RMS_DN16"], flush=True)
    assert len(results) == 8
    write_json(ROOT / "port.json", {
        "driver": reference(__file__), "checkpoints": [pilots["checkpoint"]],
        "inputs": reference(BEFORE / "camera.json"), "pilot": reference(ROOT / "adjacent-ranked.json"),
        "files": [reference(Path("src/demosaic") / p) for p in ("mesh_refinement.py", "_mesh_frequency.py")],
        "frozen_defaults": [reference(ROOT / p) for p in ("before-_mesh_frequency.py", "before-mesh_refinement.py")],
        "scope": "Both preexisting package options are bitwise preserved across eight camera observations. The opt-in fallback changes both right cab outputs and matches the exploratory right cab comparison exactly.",
        "cases": results,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    main()
