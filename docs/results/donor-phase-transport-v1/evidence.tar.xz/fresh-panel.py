"""Run the frozen transport and delivery policy on independent RAW observations."""

from itertools import product
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

from delivery import ROOT, load, prepare, reconstruct, window
from diagnose import PREVIOUS
from deliver import CENTRE, DISPLAY, proposals, score
from run import SHIFTS

sample = load("fresh_transport_observations", ROOT / "observations.py").observe


def evaluate(all_data, parent, entry, masks, surroundings, noise):
    raw, variance, cfa, target = (all_data[k].numpy() for k in ("packed", "variance", "colors", "target"))
    diagnostics = {}
    control = {"parent": score(parent, None, target, masks)}
    corrections = {}
    for outside, scene in surroundings.items():
        if outside == "unrelated" and entry["g"] not in (150, 153):
            continue
        _, trace = proposals(scene, cfa[0], (256, 256, 256, 256), noise, 80)

        def tile(x, y, span):
            return window(scene, (x, y, span, span), phase=2)

        config, moved, witness = prepare(tile, trace, cfa[0], noise, (383.5, 383.5))
        roles = []
        old, new = [], []
        for i, field in enumerate(parent):
            column = field, raw[i], variance[i], cfa[i], CENTRE, DISPLAY, noise, config
            baseline, before = reconstruct(*column, None)
            if moved:
                rotated, after = reconstruct(*column, moved)
            else:
                rotated, after = baseline, []
            retained = rotated if rotated.any() else baseline
            old.append(baseline)
            new.append(retained)
            roles.append({
                "baseline_active_shifts": sum(r["status"] == "supported" for r in before),
                "transport_active_shifts": sum(r["status"] == "supported" for r in after),
                "baseline_at_center": before[0] if before else None,
                "transport_at_center": after[0] if after else None,
                "transport_changes": bool(np.any(retained != baseline)),
            })
        for label, delta in (("previous", old), ("transported", new)):
            key = outside + "/" + label
            corrections[key] = np.stack(delta)
            control[key] = score(parent, corrections[key], target, masks)
        diagnostics[outside] = {"transport": witness, "donor_trace": trace, "roles": roles}
    return control, corrections, diagnostics


@torch.inference_mode()
def main():
    source = read_json(PREVIOUS / "fresh-plan.json")
    output = ROOT / "fresh"
    output.mkdir()
    entries = []
    for j, (profile, layout, g) in enumerate(product(
        ("iso6400", "iso400"), ("continuous", "gaps"), range(150, 156),
    )):
        if layout == "gaps":
            layout = "disk" if g % 2 == 0 else "band"
        entries.append({
            "id": f"{profile}-{layout}-g{g}", "profile": profile, "layout": layout, "g": g,
            "seed": 646240913 + 26003 * j + 457 * g,
        })
    spec = {
        "driver": reference(__file__),
        "sources": [reference(ROOT / p) for p in ("transport.py", "delivery.py", "fixed-delivery.py", "observations.py", "diagnose.py")],
        "cases": entries, "noise": source["noise"], "checkpoint": source["checkpoint"],
        "query": CENTRE, "native_ROI": DISPLAY, "translations": SHIFTS,
        "scope": "Fresh exact-target pairs with a fixed local input and equally rendered output under each donor intervention. The shipped model is unmodified. Matching and phase-shifted donors are evaluated on all cases, rotated donors on geometries 150 and 153.",
    }
    write_json(ROOT / "fresh-plan.json", spec)
    key = spec["checkpoint"]
    model, state = load_scene_checkpoint(checked(key), device="cuda", weights="ema", expected_sha256=key["sha256"])
    assert state["step"] == 2000
    model.mode = "none"
    del state
    begin = time.monotonic()
    rows = []
    with ieee_fp32():
        for entry in entries:
            noise = spec["noise"][entry["profile"]]
            all_data, surroundings, masks, sensor, geometry = sample(entry["g"], entry["layout"], noise, entry["seed"])
            model.base.set_noise(noise["shot"], noise["read"])
            parent = model(*(all_data[k].cuda() for k in ("packed", "variance", "colors", "wb", "matrix"))).cpu().numpy()
            metrics, corrections, details = evaluate(all_data, parent, entry, masks, surroundings, noise)
            outfile = output / (entry["id"] + ".npz")
            np.savez_compressed(outfile, **{k: v.numpy() for k, v in all_data.items()},
                               parent=parent, **masks, **corrections)
            row = {
                "id": entry["id"], "entry": entry, "metrics": metrics, "details": details,
                "array": reference(outfile), "sensor": sensor, "geometry": geometry,
                "inputs": {k: fingerprint(v) for k, v in all_data.items()},
            }
            path = output / (entry["id"] + ".json")
            write_json(path, row)
            rows.append(reference(path))
            print(entry["id"], [(k, round(v["response"][0] * 100, 3), v["changed"],
                                round(v["gap_added_RMS_DN16"] or 0, 2))
                               for k, v in metrics.items()], round(time.monotonic() - begin, 1), flush=True)
    assert len(rows) == 24
    write_json(ROOT / "fresh.json", {
        "plan": reference(ROOT / "fresh-plan.json"), "cases": rows,
        "seconds": time.monotonic() - begin,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [12, 13])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    main()
