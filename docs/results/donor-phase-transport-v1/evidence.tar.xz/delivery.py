"""Keep the existing reconstruction and change only the source of the rear phase."""

import importlib.util

import numpy as np

from diagnose import ROOT, infer_donors
from deliver import shift_prior
from run import SHIFTS, window
from stabilize import median_correction
from transport import ordered_like, translate


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


solver = load("frozen_transport_delivery", ROOT / "fixed-delivery.py")


def verify_translation(carrier):
    from mesh import ribbon

    x = np.arange(-128, 128, dtype=float) + 0.5
    xx, yy = np.meshgrid(x[::9], x[::13])
    for dx, dy in SHIFTS:
        changed = translate(carrier, dx, dy)
        np.testing.assert_allclose(
            ribbon(xx + dx, yy + dy, carrier), ribbon(xx, yy, changed), rtol=0, atol=1e-12,
        )


def reconstruct(field, packed, variance, colors, query, roi, noise, config, moved):
    info = []
    if config is None:
        return np.zeros_like(window(field, roi)), info
    for dx, dy in SHIFTS:
        freq, warp = shift_prior(*config, dx, dy)
        box = (query[0] + dx, query[1] + dy, *query[2:])
        if moved:
            candidates = tuple(translate(carrier, dx, dy) for carrier in moved)

            def swap(local):
                return local[0], ordered_like(candidates, local)[1]
        else:
            swap = None
        correction, state = solver.correction(
            field, packed, variance, colors, box, roi, freq, warp, noise,
            packed_offset=dx // 2, replace_pair=swap,
        )
        info.append((correction, state))
    return median_correction([frame[0] for frame in info]), [frame[1] for frame in info]


def prepare(read_tile, trace, colors, noise, donor_center):
    config, candidate, diagnostic = infer_donors(read_tile, trace, colors, noise, donor_center)
    if candidate is None:
        return config, None, diagnostic
    for carrier in candidate:
        verify_translation(carrier)
    # A fixed donor proposal must survive exterior agreement before local validation.
    if diagnostic["status"] != "accepted":
        return config, None, diagnostic
    return config, candidate, diagnostic
