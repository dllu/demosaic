"""Test existing localization options against the transported weak-wire fit."""

import os
import time
from dataclasses import asdict

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from delivery import ROOT, load, window
from diagnose import PREVIOUS
from deliver import CENTRE, DISPLAY, Carrier, geometry, score
from transport import ordered_like

previous_gap = load("frozen_gap_control", PREVIOUS / "rank.py")
short = load("frozen_short_control", ROOT.parent / "local-mesh-phase-evidence-v1" / "short-support.py")


def main():
    plan = read_json(ROOT / "fresh-plan.json")
    rows = []
    out = ROOT / "attenuate"
    out.mkdir()
    for entry in plan["cases"]:
        key = entry["id"]
        receipt = ROOT / "fresh" / (key + ".json")
        while not receipt.exists():
            time.sleep(2)
        data = read_json(receipt)
        noise = plan["noise"][entry["profile"]]
        kin = data["details"]["matching"]
        with np.load(checked(data["array"]), allow_pickle=False) as archived:
            correction = archived["matching/transported"]
            requested = {"column": correction.copy(), "distributed": correction.copy(), "short": correction.copy()}
            clean, parent, colors, packed = (archived[k] for k in ("target", "parent", "colors", "packed"))
            masks = {k: archived[k] for k in ("strong_phase", "weak_phase", "support")}
            witnesses = []
            trace = kin["donor_trace"]
            if correction.any():
                centers, adjusted, usable, _ = geometry.donor_arrays(trace, (383.5, 383.5))
                frequency, warp, _ = geometry.fit_geometry(centers, adjusted, usable)
            for i, d in enumerate(correction):
                if not d.any():
                    continue
                raw = window(packed[i], CENTRE, phase=2)
                pair, _ = geometry.reserve_candidates(raw, colors[i], frequency, warp, noise)
                if kin["roles"][i]["transport_changes"]:
                    carried = tuple(Carrier(**e["carrier"]) for e in kin["transport"]["carriers"])
                    pair = pair[0], ordered_like(carried, pair)[1]
                record = {"role": i, "pair": [asdict(c) for c in pair]}
                for mode, allocator in (("column", "columns-proxy"), ("distributed", "balanced-proxy")):
                    requested[mode][i], record[mode] = previous_gap.apply(
                        d, packed[i], colors[i], pair, noise, CENTRE, DISPLAY, allocator,
                    )
                requested["short"][i] = short.shorten(
                    d, raw, colors[i], [asdict(c) for c in pair], noise, CENTRE, DISPLAY, 0,
                )
                witnesses.append(record)
            values = {k: score(parent, d, clean, masks) for k, d in requested.items()}
        fn = out / (key + ".npz")
        np.savez_compressed(fn, **requested)
        rows.append({"id": key, "entry": entry, "case": reference(receipt), "arrays": reference(fn),
                     "modes": values, "fixed_pair_evidence": witnesses})
        print(key, [(k, round(v["response"][0] * 100, 2),
                     round(v["gap_added_RMS_DN16"] or 0, 2)) for k, v in values.items()], flush=True)
    write_json(ROOT / "attenuation.json", {
        "driver": reference(__file__), "plan": reference(ROOT / "fresh-plan.json"), "rows": rows,
        "sources": [reference(x.__file__) for x in (previous_gap, short)],
        "scope": "Exploratory reuse of frozen column/distributed gap audits and the fixed short mask. Applied once at the central query to the median output after looking at early positive-noise fresh cases. Shared local samples between admission and attenuation. No thresholds changed.",
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    main()
