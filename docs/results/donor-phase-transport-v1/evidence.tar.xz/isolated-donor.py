"""Exercise the shipped fallback on exact targets with one useful outside tile."""

import os

import numpy as np
import torch
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import refine_local_raw_mesh
from report_scene_wave_guides import native_board

from delivery import ROOT, load, window
from deliver import DISPLAY, score

sampler = load("single_donor_design", ROOT / "isolated-donor-observations.py")


def run():
    plan = read_json(ROOT / "fresh-plan.json")
    destination = ROOT / "isolated-donor"
    images = destination / "native"
    images.mkdir(parents=True)
    cases = []
    for entry in plan["cases"]:
        if entry["layout"] != "continuous" or entry["g"] not in (150, 153):
            continue
        key = entry["id"]
        saved = ROOT / "fresh" / (key + ".json")
        before = read_json(saved)
        noise = plan["noise"][entry["profile"]]
        data, exteriors, masks, _, shape = sampler.observe(entry["g"], entry["layout"], noise, entry["seed"])
        with np.load(checked(before["array"]), allow_pickle=False) as archive:
            arrays = dict(archive)
        for name in ("packed", "variance", "colors", "target"):
            np.testing.assert_array_equal(data[name], arrays[name])
        parent, exact = arrays["parent"], arrays["target"]
        x, y, w, h = DISPLAY
        roi = (x + 224, y + 224, w, h)
        box = (256, 256, 256, 256)
        outputs = {}
        for name, outside in exteriors.items():
            if name == "phase-shifted":
                continue
            trial = {"default": [], "adjacent": []}
            for role in range(len(parent)):
                raw = outside.copy()
                raw[:, 112:272, 112:272] = arrays["packed"][role]
                rgb = np.pad(parent[role], [(0, 0), (224, 224), (224, 224)], mode="edge")
                variance = noise["shot"] * raw + noise["read"]
                variance[:, 112:272, 112:272] = arrays["variance"][role]
                args = rgb, raw, variance, arrays["colors"][role], box, roi
                options = {"shot": noise["shot"], "read": noise["read"], "donor_span": 112}
                values = (
                    refine_local_raw_mesh(*args, **options),
                    refine_local_raw_mesh(*args, adjacent_donors=True, **options),
                )
                for k, v in zip(trial, values, strict=True):
                    trial[k].append(v - window(parent[role], DISPLAY))
            for k, rows in trial.items():
                outputs[name + "/" + k] = np.stack(rows)
        metrics = {k: score(parent, correction, exact, masks) for k, correction in outputs.items()}
        stored = destination / (key + ".npz")
        np.savez_compressed(stored, **outputs)
        details = {
            "id": key, "entry": entry, "archive": reference(saved), "arrays": reference(stored),
            "metrics": metrics, "noise": noise, "CFA": shape["CFA"], "ROI": DISPLAY,
        }
        if entry["profile"] == "iso400" and entry["g"] in (150, 153):
            def correct(fit):
                rgb = parent[1].copy()
                rgb[:, y:y + h, x:x + w] += outputs["matching/" + fit][1]
                return rgb
            panels = (noisy_malvar(arrays)[1], correct("default"), correct("adjacent"), exact[1])
            details["view"] = native_board(
                images, key, panels, {k: arrays[k][1:2] for k in ("wb", "matrix")},
                {"archive": reference(saved), "checkpoint": plan["checkpoint"],
                 "noise": noise, "CFA": shape["CFA"], "seed": entry["seed"]},
                labels=("Noisy Malvar", "Usual donor fit", "Adjacent donor fallback", "Exact GT"),
                triplet_indices=(0, 2, 3), exposure=1, roi=DISPLAY, contrast=8,
            )
        cases.append(details)
        print(key, [(k, round(v["response"][0] * 100, 3), round(v["increment_RMS_DN16"][0], 2), v["changed"])
                    for k, v in metrics.items()], flush=True)
    assert len(cases) == 4
    write_json(ROOT / "isolated-donor.json", {
        "driver": reference(__file__), "sampler": reference(ROOT / "isolated-donor-observations.py"),
        "local_input_plan": reference(ROOT / "fresh-plan.json"), "cases": cases,
        "scope": "Four exact-target continuous queries reuse bound fresh local predictions. The exterior pattern is wholly inside one ordinary donor grid cell by construction. This is a targeted replay after the broader exterior patch failed to expose a difference. Matching and rotated exteriors keep the query identical. This constructed ablation targets the fallback's intended scope.",
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    torch.set_num_threads(2)
    run()
