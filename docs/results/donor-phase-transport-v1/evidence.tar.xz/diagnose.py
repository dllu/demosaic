"""Check exterior-transported phase against unchanged and exact-geometry controls."""

import os
import sys
from pathlib import Path

import numpy as np
import torch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "local-mesh-gap-forecast-v1"
sys.path.insert(0, str(PREVIOUS))
from fresh import CENTRE, observe, window
from probe import Carrier, evidence, similarity
from deliver import geometry

from transport import donor_tiles, ordered_like, transport


def infer_donors(read_tile, trace, colors, noise, scene_center):
    if not trace.get("prior_frequencies"):
        return None, None, None
    positions, adjusted, use, _ = geometry.donor_arrays(trace, scene_center)
    frequencies, warp, _ = geometry.fit_geometry(positions, adjusted, use)
    tiles = donor_tiles(read_tile, trace, colors, noise, scene_center, warp)
    carriers, detail = transport(tiles, frequencies, warp)
    return (frequencies, warp), carriers, detail


def replay():
    fresh = read_json(PREVIOUS / "fresh.json")
    plan = read_json(checked(fresh["plan"]))
    rows = []
    for bound in fresh["cases"]:
        row = read_json(checked(bound))
        entry = row["entry"]
        if entry["profile"] != "iso6400" and entry["g"] not in (140, 141):
            continue
        layout, profile, g = (entry[k] for k in ("layout", "profile", "g"))
        noise = plan["noise"][profile]
        inputs, surrounds, _, _, _ = observe(g, layout, noise, entry["seed"], entry["read_stress"])
        with np.load(checked(row["source"]), allow_pickle=False) as archived:
            for key in ("packed", "variance", "colors", "target"):
                np.testing.assert_array_equal(archived[key], inputs[key])
        true = tuple(Carrier(**r) for r in row["shape"]["case_geometry"])
        donor_records = {}
        for context, scene in surrounds.items():
            trace = row["witnesses"][context]["source_geometry"]
            config, tested, detail = infer_donors(
                lambda x, y, s: window(scene, (x, y, s, s), phase=2),
                trace, inputs["colors"][0], noise, (383.5, 383.5),
            )
            if config is None:
                donor_records[context] = {"status": "no pair"}
                continue
            roles = []
            for role in range(3):
                raw = window(inputs["packed"][role].numpy(), CENTRE, phase=2)
                cfa = inputs["colors"][role]
                local, _ = geometry.reserve_candidates(raw, cfa, *config, noise)
                estimates = {"query-reserve": local, "exact": true}
                if tested is not None:
                    elsewhere = ordered_like(tested, local)
                    estimates["donor-pair"] = elsewhere
                    estimates["donor-rear"] = local[0], elsewhere[1]
                ledger = {}
                for method, pair in estimates.items():
                    metrics = evidence(raw, cfa, pair, noise)
                    ledger[method] = {"scores": metrics, "rear_cosine": similarity(pair, true, raw)}
                roles.append(ledger)
            donor_records[context] = detail | {"roles": roles}
        rows.append({"id": row["id"], "entry": entry, "case": bound, "contexts": donor_records})
        m = donor_records.get("matching", {})
        print(row["id"], m["status"], [
            (k, round(v["rear_cosine"], 3), v["scores"]["passes"])
            for k, v in m.get("roles", [{}, {}])[1].items()
        ], flush=True)
    write_json(ROOT / "diagnosis.json", {
        "program": reference(__file__),
        "method": reference(ROOT / "transport.py"),
        "source": reference(PREVIOUS / "fresh.json"),
        "scope": "Development replay. The tested phase is estimated from disjoint donor tiles. Local Bayer observations, RAW audit and ground truth are fixed. Exact carrier geometry identifies an input-assisted ceiling.",
        "cases": rows,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [12, 13])
    os.nice(12)
    torch.set_num_threads(2)
    replay()
