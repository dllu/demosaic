"""Verify exact score replay across every native prediction and collect summaries."""

from collections import defaultdict
from statistics import mean

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from delivery import ROOT
from deliver import score


def gather(binding):
    payload = read_json(ROOT / binding)
    return {row["id"]: row for row in (read_json(checked(r)) for r in payload["cases"])}


def main():
    main = gather("fresh.json")
    adjacent = gather("adjacent-panel.json")
    attenuation = {r["id"]: r for r in read_json(ROOT / "attenuation.json")["rows"]}
    assert set(main) == set(adjacent) == set(attenuation)
    rows = defaultdict(lambda: defaultdict(list))
    counts = defaultdict(lambda: defaultdict(int))
    paired = []
    for case, row in main.items():
        entry = row["entry"]
        profile = entry["profile"]
        cell = profile + ("/continuous" if entry["layout"] == "continuous" else "/gaps")
        with np.load(checked(row["array"]), allow_pickle=False) as f:
            arrays = dict(f)
        parent, target = arrays["parent"], arrays["target"]
        masks = {k: arrays[k] for k in ("strong_phase", "weak_phase", "support")}
        for path, listed in row["metrics"].items():
            estimate = None if path == "parent" else arrays[path]
            assert score(parent, estimate, target, masks) == listed
            rows[cell][path].append(listed)
            counts["replayed"]["transport"] += 1
            if path.endswith("transported"):
                reference_path = path.replace("transported", "previous")
                diff = estimate != arrays[reference_path]
                group = path.split("/")[0]
                if np.any(diff):
                    counts[group + "/transported"][profile] += 1
                for role, has_change in enumerate(np.any(diff, axis=(1, 2, 3))):
                    counts[group + "/transport-changed-roles"][str(role)] += int(has_change)
        a = adjacent[case]
        with np.load(checked(a["array"]), allow_pickle=False) as f:
            for path, measured in a["metrics"].items():
                assert score(parent, f[path], target, masks) == measured
                counts["replayed"]["adjacent"] += 1
                rows[cell][path + "/adjacent"].append(measured)
                diff = f[path] != arrays[path + "/previous"]
                for role, has_change in enumerate(np.any(diff, axis=(1, 2, 3))):
                    counts[path + "/adjacent-changed-roles"][str(role)] += int(has_change)
        b = attenuation[case]
        with np.load(checked(b["arrays"]), allow_pickle=False) as f:
            for key, measured in b["modes"].items():
                assert score(parent, f[key], target, masks) == measured
                counts["replayed"]["attenuation"] += 1
                rows[cell]["matching/" + key].append(measured)
        paired.append({
            "id": case, "entry": entry,
            "metrics": row["metrics"], "adjacent": a["metrics"], "attenuation": b["modes"],
        })
    aggregates = {}
    for cell, variants in rows.items():
        aggregates[cell] = {}
        for key, group in variants.items():
            agg = {
                "n": len(group),
                "weak_response_pct": 100 * mean(v["response"][0] for v in group),
                "weak_error_DN16": mean(v["increment_RMS_DN16"][0] for v in group),
                "changed": [sum(v["changed"][i] for v in group) for i in range(3)],
            }
            if group[0]["gap_added_RMS_DN16"] is not None:
                agg["added_gap_RMS_DN16"] = mean(v["gap_added_RMS_DN16"] for v in group)
                agg["total_gap_RMS_DN16"] = mean(v["gap_error_RMS_DN16"] for v in group)
            aggregates[cell][key] = agg
            if key in ("parent", "matching/previous", "matching/transported", "matching/adjacent",
                       "matching/column", "matching/distributed", "matching/short"):
                print(cell, key, {k: round(v, 3) if isinstance(v, float) else v for k, v in agg.items()})
    print({k: dict(v) for k, v in counts.items()})
    write_json(ROOT / "summary.json", {
        "driver": reference(__file__), "plan": reference(ROOT / "fresh-plan.json"),
        "full_cases": paired, "aggregates": aggregates, "replay_and_changes": counts,
        "scope": "All metrics are recomputed from frozen saved arrays. The counts distinguish changes relative to the common trunk from changes relative to the previous donor policy.",
    })


if __name__ == "__main__":
    main()
