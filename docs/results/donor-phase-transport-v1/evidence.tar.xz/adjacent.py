"""Test whether a disjoint donor next to the query supplies missing hypotheses."""

from dataclasses import asdict
from itertools import combinations
import math
import os

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from delivery import ROOT, reconstruct, window
from support import donor_peaks, separation

BEFORE = ROOT.parent / "local-mesh-phase-evidence-v1"


def nominate(packed, query, layout, noise, span=160, separation_px=32):
    x, y, w, h = query
    side_x, side_y = (x + (w - span) // 2), (y + (h - span) // 2)
    windows = (
        (x - separation_px - span, side_y), (x + w + separation_px, side_y),
        (side_x, y - separation_px - span), (side_x, y + h + separation_px),
    )
    height, width = np.array(packed.shape[-2:]) * 2
    best = None
    evidence = []
    for u, v in windows:
        if u < 0 or v < 0 or u + span > width or v + span > height:
            continue
        pixels = window(packed, (u, v, span, span), phase=2)
        peaks = donor_peaks(pixels, layout, noise)
        proposed = [
            (min(p.scores[1], q.scores[1]), p, q)
            for p, q in combinations(peaks, 2)
            if 0.5 < separation(p, q) and min(p.scores[1], q.scores[1]) >= 5
        ]
        region = {"box": [u, v, span, span], "peaks": [asdict(p) for p in peaks]}
        evidence.append(region)
        if not proposed:
            continue
        score, p, q = max(proposed, key=lambda a: a[0])
        region["approved_peaks"] = [asdict(p), asdict(q)]
        if best is None or score > best[0]:
            best = score, p, q, region["box"]
    if best is None:
        return None, {"status": "no adjacent pair", "windows": evidence}
    score, p, q, box = best
    return (np.asarray([p.frequency, q.frequency]), np.zeros(2)), {
        "status": "proposed", "box": box, "training_free": True, "windows": evidence,
        "score": score, "frequencies": [p.frequency, q.frequency],
    }


def main():
    source = read_json(BEFORE / "camera.json")
    wide = read_json(BEFORE / "wider-camera.json")
    binding = {r["id"]: r for r in wide["views"]}
    records = []
    for row in source["views"]:
        with np.load(checked(row["input"]), allow_pickle=False) as a:
            pixels, variance, cfa = (a[k][0]for k in ("packed", "variance", "colors"))
        field = np.load(checked(row["parent"]), allow_pickle=False)[0]
        query, roi, noise = row["query"], row["ROI"], row["noise"]
        proposals, note = nominate(pixels, query, cfa, noise)
        delta, checks = reconstruct(field, pixels, variance, cfa, query, roi, noise, proposals, None)
        native = np.sqrt(np.mean(delta.astype(float)**2)) * 65535
        old = binding[row["id"]]["corrections"][1]
        print(row["id"], note.get("box"), note.get("frequencies"), float(native), old,
              sum(x["status"] == "supported" for x in checks), flush=True)
        records.append({
            "id": row["id"], "query": query, "ROI": roi, "noise": noise,
            "nomination": note, "detail_DN16": float(native), "wider_DN16": old, "checks": checks,
        })
    write_json(ROOT / "adjacent.json", {
        "scope": "Exploratory adjacent donor probe on known scene crops. Any approval is diagnostic. The tested proposal uses disjoint exterior RAW and the unmodified local phase selection and delivery.",
        "source": reference(BEFORE / "camera.json"), "driver": reference(__file__), "cases": records,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [10, 11])
    os.nice(12)
    main()
