"""Evaluate the fixed adjacent fallback on the independent exact-target panel."""

import os
import time

import numpy as np
import torch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

from delivery import ROOT, load, reconstruct, window
from deliver import CENTRE, DISPLAY, score
from adjacent import nominate

rank = load("adjacent_ranking", ROOT / "adjacent-ranked.py").rank
sample = load("adjacent_fresh_inputs", ROOT / "observations.py").observe


def main():
    source = ROOT / "fresh-plan.json"
    plan = read_json(source)
    dest = ROOT / "adjacent-panel"
    dest.mkdir()
    measurements = []
    begin = time.monotonic()
    for entry in plan["cases"]:
        case = entry["id"]
        previous = ROOT / "fresh" / (case + ".json")
        while not previous.exists():
            time.sleep(2)
        old = read_json(previous)
        noise = plan["noise"][entry["profile"]]
        all_data, surrounds, masks, _, _ = sample(entry["g"], entry["layout"], noise, entry["seed"])
        assert {k: fingerprint(v) for k, v in all_data.items()} == old["inputs"]
        with np.load(checked(old["array"]), allow_pickle=False) as saved:
            raw = saved["packed"]
            variance, colors, parent, target = (saved[k] for k in ("variance", "colors", "parent", "target"))
            proposals = {}
            values = {}
            evaluated = {}
            for outside, scene in surrounds.items():
                match = outside + "/previous"
                if match not in saved:
                    continue
                initial = saved[match]
                result = initial.copy()
                _, registry = nominate(scene, (256, 256, 256, 256), colors[0], noise)
                tested = []
                for i, delta in enumerate(initial):
                    if delta.any():
                        tested.append({"already_supported": True})
                        continue
                    reserve = window(raw[i], CENTRE, phase=2)
                    config, candidates = rank(registry["windows"], reserve, colors[i], noise)
                    advanced, notes = reconstruct(parent[i], raw[i], variance[i], colors[i],
                                                   CENTRE, DISPLAY, noise, config, None)
                    result[i] = advanced
                    tested.append({
                        "already_supported": False, "rank": candidates,
                        "active": sum(note["status"] == "supported" for note in notes),
                        "chosen": notes[0] if notes else None,
                    })
                proposals[outside] = tested
                values[outside] = score(parent, result, target, masks)
                evaluated[outside] = result
            assert "matching" in values and "phase-shifted" in values
        output = dest / (case + ".npz")
        np.savez_compressed(output, **evaluated)
        report = dest / (case + ".json")
        write_json(report, {
            "id": case, "entry": entry, "prior": reference(previous), "array": reference(output),
            "metrics": values, "proposals": proposals,
        })
        measurements.append(reference(report))
        print(case, [(k, round(v["response"][0] * 100, 2), v["changed"],
                      round(v["gap_added_RMS_DN16"] or 0, 2)) for k, v in values.items()],
              round(time.monotonic() - begin, 1), flush=True)
    write_json(ROOT / "adjacent-panel.json", {
        "driver": reference(__file__), "plan": reference(source), "cases": measurements,
        "sources": [reference(ROOT / p) for p in ("adjacent.py", "adjacent-ranked.py", "fixed-delivery.py")],
        "scope": "Evaluates a preset adjacent fallback whose heuristic was motivated by development GFX observations. Exact target inputs from the independent transport panel with matching, phase-shifted and selected rotated exterior controls. Prior delivered corrections are preserved as they are.",
        "seconds": time.monotonic() - begin,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [10, 11])
    os.nice(12)
    torch.set_num_threads(2)
    main()
