"""Transport a projected Bayer carrier phase from separate exterior RAW windows."""

from dataclasses import asdict, replace
from itertools import product

import numpy as np
from demosaic._mesh_frequency import residual_sensor
from demosaic.isolated_line import native_sites

from probe import Carrier


def donor_tiles(read_tile, trace, colors, noise, center, warp):
    span = trace["donor_span"]
    window = np.outer(np.hanning(span // 2), np.hanning(span // 2))
    native_x, native_y = native_sites((span // 2, span // 2), (-(span - 1) / 2,) * 2)
    available = np.ones(window.shape, dtype=bool)
    result = []
    for x, y in sorted(trace["supporting_centers"], key=lambda row: (row[1], row[0])):
        left, top = int(x - span / 2), int(y - span / 2)
        raw = read_tile(left, top, span)
        if raw.shape != (4, span // 2, span // 2):
            raise ValueError("Donor tile must be a complete Bayer array")
        dx, dy = np.asarray((x - 0.5, y - 0.5)) - center
        greens = residual_sensor(raw, colors, noise, available, window)
        points = np.concatenate([np.column_stack((
            (native_x[k] + dx).ravel(), (native_y[k] + dy).ravel(),
        )) for k, _ in greens])
        points /= (1 + points @ warp)[:, None]
        values = np.concatenate([(s * window).ravel() for _, s in greens])
        values /= np.sqrt(len(greens) * np.sum(window**2) / 2)
        location = np.array((dx, dy))
        projected = location / (1 + location @ warp)
        result.append((points, values, projected))
    return result


def phasors(tiles, frequencies):
    values = []
    for xy, raw, _ in tiles:
        theta = (2 * np.pi * xy) @ frequencies.T
        values.append(raw @ np.cos(theta) + 1j * (raw @ np.sin(theta)))
    return np.asarray(values)


def select(tiles, frequencies, train):
    """Coarse coherent peak, followed by direct Bayer reevaluation near it."""
    p0 = phasors(tiles, frequencies)
    means = p0[train].mean(0)
    axis = frequencies[np.argmax(abs(means))]
    fine = axis + np.array(list(product(np.arange(-2, 3), repeat=2))) / 6144
    samples = phasors(tiles, fine)
    centers = samples[train].mean(0)
    best = int(np.argmax(abs(centers)))
    return fine[best], centers[best], samples[:, best]


def transport(tiles, frequencies, warp):
    """Require phase learned from either exterior half to predict the other."""
    if len(tiles) < 2:
        return None, {"status": "insufficient donor tiles"}
    splits = np.arange(len(tiles)) % 2 == 0
    delta = np.array(list(product(np.arange(-6, 7), repeat=2))) / 1536
    guesses = []
    for f in frequencies:
        search = f + delta
        agreements, choices = [], []
        for learn in (splits, ~splits):
            freq, signal, predicted = select(tiles, search, learn)
            witness = predicted[~learn]
            z = np.real(witness * np.exp(-1j * np.angle(signal)))
            score = float(z.sum() / np.sqrt(len(z)))
            coherence = float(z.sum() / max(abs(witness).sum(), 1e-12))
            agreements.append((score, coherence))
            choices.append((freq, signal))
        difference = float(np.angle(choices[0][1] * np.conj(choices[1][1])) / (2 * np.pi))
        frequency_gap = float(np.linalg.norm(choices[0][0] - choices[1][0]))
        pooled = np.ones(len(tiles), dtype=bool)
        chosen, strength, signed = select(tiles, search, pooled)
        guess = Carrier(tuple(chosen), float(np.angle(strength) / (2 * np.pi) % 1), 0.08, tuple(warp))
        note = {
            "carrier": asdict(guess),
            "crossed": agreements,
            "phase_difference_cycles": difference,
            "frequency_difference_per_pixel": frequency_gap,
            "donor_scores": abs(signed).tolist(),
        }
        ok = min(z for z, _ in agreements) > 3 and min(c for _, c in agreements) > 0.4
        ok &= abs(difference) < 0.2 and frequency_gap < 0.0025
        guesses.append((guess, bool(ok), note))
    success = all(item[1] for item in guesses)
    return tuple(item[0] for item in guesses), {
        "status": "accepted" if success else "withheld",
        "separate_carriers_admitted": [item[1] for item in guesses],
        "carriers": [item[2] for item in guesses],
        "donor_tiles": len(tiles),
    }


def ordered_like(carriers, local):
    direct = sum(abs(np.dot(a.frequency, b.frequency) /
                     (np.linalg.norm(a.frequency) * np.linalg.norm(b.frequency)))
                 for a, b in zip(carriers, local, strict=True))
    reverse = sum(abs(np.dot(a.frequency, b.frequency) /
                      (np.linalg.norm(a.frequency) * np.linalg.norm(b.frequency)))
                  for a, b in zip(carriers[::-1], local, strict=True))
    return carriers if direct >= reverse else carriers[::-1]


def translate(carrier, dx, dy):
    f, g = np.asarray(carrier.frequency), np.asarray(carrier.perspective)
    d = np.array([dx, dy])
    divisor = 1 + g @ d
    phase = (f @ d) / divisor
    return replace(carrier, frequency=tuple((f - phase * g) / divisor),
                   perspective=tuple(g / divisor), offset=(carrier.offset - phase) % 1)
