"""Verify prediction-score bindings and render matched native comparisons."""

import os

import numpy as np
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board

from delivery import ROOT
from deliver import DISPLAY, score


CHOICES = (
    "iso6400-continuous-g151", "iso6400-continuous-g153", "iso6400-continuous-g150",
    "iso6400-disk-g154", "iso6400-band-g155",
)


def main():
    spec = read_json(ROOT / "fresh-plan.json")
    images = ROOT / "native"
    images.mkdir(exist_ok=True)
    boards = []
    for case in CHOICES:
        receipt = ROOT / "fresh" / (case + ".json")
        row = read_json(receipt)
        native = ROOT / "attenuate" / (case + ".npz")
        with np.load(checked(row["array"]), allow_pickle=False) as saved:
            arrays = dict(saved)
        with np.load(native, allow_pickle=False) as archive:
            short, column = archive["short"], archive["column"]
        parent, target = arrays["parent"], arrays["target"]
        masks = {k: arrays[k] for k in ("strong_phase", "weak_phase", "support")}
        for name, recorded in row["metrics"].items():
            used = None if name == "parent" else arrays[name]
            assert score(parent, used, target, masks) == recorded, (case, name)
        role = 1
        x, y, w, h = DISPLAY

        def rendered(correction):
            image = parent[role].copy()
            image[:, y:y+h, x:x+w] += correction[role]
            return image

        labels = ("Noisy Malvar", "Local trunk", "Query phase", "Transported rear phase",
                  "Transport + column gap", "Transport + short support", "Exact GT")
        panels = (noisy_malvar(arrays)[role], parent[role], rendered(arrays["matching/previous"]),
                  rendered(arrays["matching/transported"]), rendered(column), rendered(short), target[role])
        details = {
            "case": reference(receipt), "arrays": row["array"],
            "checkpoint": spec["checkpoint"], "CFA": row["geometry"]["CFA"],
            "seed": row["entry"]["seed"], "noise": spec["noise"][row["entry"]["profile"]],
            "gap_replay": reference(native),
        }
        boards.append(native_board(
            images, case, panels,
            {k: arrays[k][role:role+1] for k in ("wb", "matrix")}, details,
            labels=labels, triplet_indices=(0, 3, 6), exposure=1, roi=DISPLAY, contrast=8,
        ))
    write_json(ROOT / "render.json", {
        "driver": reference(__file__), "plan": reference(ROOT / "fresh-plan.json"),
        "boards": boards, "scope": "Five native exact target comparisons show continuous recovery and failures. Triplets g151/g153 illustrate the continuous setting with lower wire error.",
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    main()
