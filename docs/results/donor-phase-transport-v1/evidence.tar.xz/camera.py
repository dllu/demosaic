"""Replay exterior phase transport on both fixed GFX scenes with cached RAW only."""

import os
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

from delivery import ROOT, load, prepare, reconstruct, window
from standing import legacy

SOURCE = ROOT.parent / "local-mesh-phase-evidence-v1"
wider = load("wide_frozen", SOURCE / "wider-camera.py")


def rms(delta):
    return float(np.sqrt(np.mean(delta.astype(float)**2)) * 65535)


def main():
    previous = read_json(SOURCE / "wider-camera.json")
    controls = read_json(SOURCE / "camera.json")
    originals = {r["id"]: r for r in controls["views"]}
    out = ROOT / "camera"
    out.mkdir()
    arrays, records = {}, []
    for row in previous["views"]:
        key = row["id"]
        control = originals[key]
        noise, roi = row["noise"], row["ROI"]
        query, trace = control["query"], control["donor_windows"]
        path = checked(row["RAW"])
        assert (Path.cwd() / ".cache").resolve() in path.resolve().parents
        if path not in arrays:
            arrays[path] = read_raw(path)[0]
        full = arrays[path]
        left, top, width, height = row["absolute_box"]
        with np.load(checked(row["input"]), allow_pickle=False) as data:
            packed, variance, colors = (data[k][0] for k in ("packed", "variance", "colors"))
            metadata = {k: data[k] for k in ("wb", "matrix")}
        np.testing.assert_array_equal(wider.packed(full[top:top + height, left:left + width]), packed)
        field = np.load(checked(control["parent"]), allow_pickle=False)[0]
        base = window(field, roi)
        with np.load(checked(row["deltas"]), allow_pickle=False) as old:
            old_wide = old["wider"]
        if trace.get("prior_frequencies"):
            trace, added = wider.augment(full, row["absolute_box"], query, trace, colors, noise)
            assert added == row["added_donors"]

        def read_tile(x, y, span):
            return wider.packed(full[y + top:y + top + span, x + left:x + left + span])

        config, pair, receipt = prepare(read_tile, trace, colors, noise, np.asarray(query[:2]) + 127.5)
        if pair is None:
            delta, checks = old_wide, []
        else:
            local, _ = reconstruct(field, packed, variance, colors, query, roi, noise, config, None)
            np.testing.assert_array_equal(local, old_wide)
            new, checks = reconstruct(field, packed, variance, colors, query, roi, noise, config, pair)
            delta = new if new.any() else old_wide
        baseline = {"image": row["image"], "panels": row["panels"]}
        w, h = roi[2:]
        image, positions = legacy.insert_camera_panels(
            out, key, baseline, "Wider donors",
            [("Transported rear phase", legacy.pixel(base + delta, metadata, (0, 0, w, h), row["exposure"]))],
        )
        stored = out / (key + ".npz")
        np.savez_compressed(stored, previous=old_wide, transported=delta)
        report = {k: row[k] for k in ("id", "input", "RAW", "ROI", "absolute_box", "noise", "exposure")}
        report.update({
            "query": query, "local_parent": control["parent"], "transport": receipt, "checks": checks,
            "source": row["image"], "image": image, "panels": positions, "differences": reference(stored),
            "previous_RMS_DN16": rms(old_wide), "candidate_RMS_DN16": rms(delta),
            "change_RMS_DN16": rms(delta - old_wide),
        })
        records.append(report)
        print(key, receipt and receipt["status"], report["previous_RMS_DN16"],
              report["candidate_RMS_DN16"], report["change_RMS_DN16"], flush=True)
    assert len(records) == 8
    write_json(ROOT / "camera.json", {
        "driver": reference(__file__), "before": reference(SOURCE / "wider-camera.json"),
        "checkpoint": controls["checkpoint"], "views": records,
        "scope": "Fixed RAW/camera parent and native display for eight standing crops. A transferred candidate replaces only the local estimate of the rear phase. Failed agreement or empty delivery preserves the wider-donor correction.",
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [10, 11])
    os.nice(12)
    main()
