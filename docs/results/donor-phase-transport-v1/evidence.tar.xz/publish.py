"""Publish the reviewed native crops and bind exact sources and score receipts."""

from datetime import UTC, datetime
import hashlib
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
repo = ROOT.parents[2]
images = repo / "docs/images/donor-phase-transport-v1"
results = repo / "docs/results/donor-phase-transport-v1"
images.mkdir()
results.mkdir()


def portable(p):
    return {"path": p.relative_to(repo).as_posix(), "sha256": reference(p)["sha256"]}


def image_copy(binding, panels):
    source = checked(binding)
    target = images / source.name
    shutil.copyfile(source, target)
    with Image.open(target) as board:
        assert all((w, h) == (160, 160) and x + w <= board.width and y + h <= board.height
                   for p in panels for x, y, w, h in (p["png_xywh"],))
    path = portable(target)
    assert path["sha256"] == binding["sha256"]
    return path


observations = {
    "main-overcast-sky-main-overcast-sky": "Both maintain uniform sky. Each matches the earlier local prediction.",
    "main-building-detail-main-building-detail": "Soft braces and suspension lines remain unchanged.",
    "main-foliage-main-foliage": "Matching soft edges and quiet dark regions.",
    "main-chain-link-fence-main-chain-link-fence": "Both preserve the prior visible coarse crossings and the blurry strip near the spot.",
    "mesh-nominal-fine-green-mesh-left": "Both preserve a faint lattice and the post. Finer crossings are weaker than in the independent reference.",
    "mesh-profile3879-fine-green-mesh-left": "Both preserve the earlier lattice and uneven dark background.",
    "mesh-nominal-fine-green-mesh-right": "Adjacent donors show previously faint crossings in both directions across much of the patch. The horizontal wire remains visible, and the resulting lattice is quite regular.",
    "mesh-profile3879-fine-green-mesh-right": "Additional crossings are visible but softer and uneven. The background and horizontal wire remain.",
    "iso6400-continuous-g151": "Very faint secondary modulation increases. The main diagonal retains its visible form.",
    "iso6400-continuous-g153": "The second diagonal crosses the strong horizontal wires. Its contrast is closer to the exact target.",
    "iso6400-continuous-g150": "Some very faint added modulation and a modest change in the existing diagonal pattern. Wire error is higher.",
    "iso6400-disk-g154": "Transport extends faint repeats into part of the known gap. The column audit removes much of the added texture there.",
    "iso6400-band-g155": "A second wire becomes clearer where present. The unguarded transport repeats in the gap, especially near the transition. The short mask leaves much weaker traces.",
}

camera = read_json(ROOT / "camera.json")
adjacent = read_json(ROOT / "adjacent-ranked.json")
port = read_json(ROOT / "port.json")
synth = read_json(ROOT / "render.json")
expected = {r["id"]: r for r in camera["views"]}
api = {r["id"]: r for r in port["cases"]}
camera_views = []
for row in adjacent["views"]:
    key = row["id"]
    baseline, verified = expected[key], api[key]
    assert baseline["change_RMS_DN16"] == 0
    assert verified["unchanged_default"] and verified["unchanged_default_gap"]
    assert verified["second_gap_check_RMS_DN16"] == 0
    assert verified["adjacent_RMS_DN16"] == row["fallback_change_DN16"]
    checked(row["RAW"])
    checked(row["input"])
    checked(baseline["image"])
    if row["fallback_change_DN16"]:
        assert "fine-green-mesh-right" in key
        with np.load(checked(verified["native_array"]), allow_pickle=False) as samples:
            np.testing.assert_array_equal(samples["adjacent"], samples["adjacent_gap"])
    native = {k: row[k] for k in ("id", "query", "ROI", "panels", "absolute_box", "noise",
                                  "exposure", "input", "RAW", "source", "fallback_change_DN16")}
    native["standalone_transport_board"] = baseline["image"]
    native["image"] = image_copy(row["image"], row["panels"])
    native["observation"] = observations[key]
    camera_views.append(native)
assert len(camera_views) == 8 and sum(bool(r["fallback_change_DN16"]) for r in camera_views) == 2

rendered = []
for row in synth["boards"]:
    view = {k: v for k, v in row.items() if k not in ("board", "triplet")}
    for k in ("case", "arrays", "checkpoint", "gap_replay"):
        checked(row[k])
    for k in ("board", "triplet"):
        if k == "triplet" and row["id"] not in ("iso6400-continuous-g151", "iso6400-continuous-g153"):
            continue
        panel = row[k]
        view[k] = {"image": image_copy(panel["image"], panel["panels"]), "panels": panel["panels"]}
    view["observation"] = observations[row["id"]]
    rendered.append(view)
assert len(rendered) == 5 and sum("triplet" in row for row in rendered) == 2
for reference_to_bound_file in port["files"]:
    checked(reference_to_bound_file)
viewing = results / "viewing.json"
write_json(viewing, {
    "recorded_utc": datetime.now(UTC).isoformat(), "actual_native_viewing": True,
    "scope": "Eight fixed transport boards and eight adjacent boards viewed, five exact synthetic comparisons and the two selected continuous triplets viewed. The eight adjacent camera boards and seven synthetic images are published.",
    "camera": camera_views, "camera_checkpoint": adjacent["checkpoint"], "synthetic": rendered,
})
for name in ("summary.json", "port.json", "one-donor.json", "isolated-donor.json"):
    shutil.copyfile(ROOT / name, results / name)
files = {
    p.name: p for p in ROOT.iterdir()
    if p.is_file() and p.suffix in (".py", ".json", ".log")
}
for directory in ("fresh", "adjacent-panel"):
    files.update({path.relative_to(ROOT).as_posix(): path for path in (ROOT / directory).glob("*.json")})
for name in ("_mesh_frequency.py", "mesh_refinement.py", "_mesh_profiles.py"):
    files["package/" + name] = repo / "src/demosaic" / name
files["package/test_mesh_refinement.py"] = repo / "tests/test_mesh_refinement.py"
bundle = results / "evidence.tar.xz"
with tarfile.open(bundle, "x:xz", preset=4) as packed:
    for name, path in files.items():
        packed.add(path, arcname=name)
contents = {name: reference(path) for name, path in files.items()}
with tarfile.open(bundle, "r:xz") as packed:
    assert set(packed.getnames()) == set(files)
    for name, bound in contents.items():
        assert hashlib.sha256(packed.extractfile(name).read()).hexdigest() == bound["sha256"]
prior = ("local-mesh-projective-v1", "local-mesh-gap-support-v1", "local-mesh-distributed-audit-v1")
write_json(results / "publication.json", {
    "scope": "Optional crop refinement without model training. Camera fit and package parity reviewed. Synthetic metrics use a fixed exact-target weak-wire suite. Signed display references are qualitative. No comparable primary scores added.",
    "actual_viewing": portable(viewing), "archive": portable(bundle), "archive_contents": contents,
    "exact_metrics": portable(results / "summary.json"), "package_parity": portable(results / "port.json"),
    "single_donor_replays": [portable(results / name) for name in ("one-donor.json", "isolated-donor.json")],
    "prior_source_archives": [portable(repo / "docs/results" / directory / "evidence.tar.xz")
                              for directory in prior],
})
