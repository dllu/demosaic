"""Nominate one nearby donor pair using only the query's phase reserve."""

import os
from itertools import combinations

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from delivery import ROOT, reconstruct, window
from deliver import geometry
from standing import legacy
from support import Peak, separation
from adjacent import BEFORE
def rms(delta):
    return float(np.sqrt(np.mean(delta.astype(float)**2)) * 65535)


def rank(windows, raw, cfa, noise):
    rows = []
    for donor in windows:
        for a, b in combinations(donor["peaks"], 2):
            pair = [Peak(**p) for p in (a, b)]
            if separation(*pair) <= 0.5:
                continue
            freq = np.asarray([a["frequency"], b["frequency"]])
            _, support = geometry.reserve_candidates(raw, cfa, freq, np.zeros(2), noise)
            rows.append({
                "box": donor["box"], "frequencies": freq.tolist(),
                "local_phase_reserve": support, "donor_support": [p.scores for p in pair],
            })
    rows.sort(key=lambda row: min(row["local_phase_reserve"]), reverse=True)
    if not rows or min(rows[0]["local_phase_reserve"]) < 4:
        return None, rows
    return (np.array(rows[0]["frequencies"]), np.zeros(2)), rows


def main():
    adjacent = read_json(ROOT / "adjacent.json")
    archive = read_json(BEFORE / "camera.json")
    wide = read_json(BEFORE / "wider-camera.json")
    previous = {r["id"]: r for r in wide["views"]}
    exterior = {r["id"]: r for r in adjacent["cases"]}
    out = ROOT / "adjacent-ranked"
    out.mkdir()
    results = []
    for row in archive["views"]:
        key = row["id"]
        baseline = previous[key]
        with np.load(checked(row["input"]), allow_pickle=False) as data:
            pixels, variance, cfa = (data[k][0] for k in ("packed", "variance", "colors"))
            renders = {k: data[k] for k in ("wb", "matrix")}
        field = np.load(checked(row["parent"]), allow_pickle=False)[0]
        with np.load(checked(baseline["deltas"]), allow_pickle=False) as d:
            correction = d["wider"]
        query, roi, noise = row["query"], row["ROI"], row["noise"]
        note = exterior[key]["nomination"]
        config, trials = rank(note["windows"], window(pixels, query, phase=2), cfa, noise)
        if config is not None:
            estimate, checks = reconstruct(field, pixels, variance, cfa, query, roi, noise, config, None)
        else:
            estimate, checks = np.zeros_like(correction), []
        accepted = correction if correction.any() else estimate
        existing = {"image": baseline["image"], "panels": baseline["panels"]}
        base = window(field, roi)
        image, places = legacy.insert_camera_panels(out, key, existing, "Wider donors", [
            ("Adjacent donor fallback", legacy.pixel(
                base + accepted, renders, (0, 0, *roi[2:]), row["exposure"],
            )),
        ])
        saved = out / (key + ".npz")
        np.savez_compressed(saved, baseline=correction, adjacent=estimate, fallback=accepted)
        print(key, trials[0] if trials else None, round(rms(estimate), 3),
              round(rms(accepted - correction), 3), flush=True)
        results.append({
            "id": key, "query": query, "ROI": roi, "observed_rank": trials, "evidence": checks,
            "source": baseline["image"], "image": image, "panels": places, "iterations": reference(saved),
            "fallback_change_DN16": rms(accepted - correction), "absolute_box": baseline["absolute_box"],
            "noise": noise, "exposure": row["exposure"], "input": row["input"], "RAW": baseline["RAW"],
        })
    assert len(results) == 8
    write_json(ROOT / "adjacent-ranked.json", {
        "scope": "Exploratory after seeing the separate standing-scene result. Local phase reserve alone chooses among fixed disjoint nearby donor candidates. Both folds and the final RAW audit remain withheld from nomination. Existing successful outputs take precedence.",
        "driver": reference(__file__), "source": reference(ROOT / "adjacent.json"), "views": results,
        "checkpoint": archive["checkpoint"],
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [10, 11])
    os.nice(12)
    main()
