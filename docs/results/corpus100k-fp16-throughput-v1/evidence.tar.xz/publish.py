"""Validate fixed evidence and package the FP16 throughput follow-up."""
import hashlib
from pathlib import Path
import shutil
from statistics import median
import tarfile

from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results')/ROOT.name
IMAGES = Path('docs/images')/ROOT.name


def publish_board(board):
    src=checked(board['image'])
    dst=IMAGES/src.name
    shutil.copyfile(src,dst)
    assert reference(dst)['sha256']==board['image']['sha256']
    cells={}
    with Image.open(dst) as image:
        for cell in board['panels']:
            x,y,w,h=cell['png_xywh']
            assert (w,h)==(160,160) and 0<=x<=image.width-w and 0<=y<=image.height-h
            key=cell.get('name',cell.get('label'))
            assert key not in cells
            cells[key]=image.crop((x,y,x+w,y+h))
    board['image']['path']=dst.name
    return cells


def main():
    OUT.mkdir(exist_ok=True)
    IMAGES.mkdir(exist_ok=True)
    screen, full, native, overlap, canonical, trt_tails, observations = (
        read_json(ROOT/name) for name in ('screen.json','full.json','quality.json','overlap.json','trt-canonical.json','trt-panel-outliers.json','visual-review.json')
    )
    checkpoint = screen['checkpoint']
    assert all(row['checkpoint']==checkpoint for row in (full,native,overlap,canonical,trt_tails))
    assert len(screen['results'])==32 and len(full['schedule'])==7 and len(native['exact'])==12
    assert canonical['batches']==3162 and len(overlap['rows'])==6
    assert len(native['main'])==len(native['cab'])==4
    assert all(checked(row['driver']).is_file() for row in (screen,full,native,overlap,canonical,trt_tails))
    assert checked(full['screen'])==ROOT/'screen.json' and checked(native['full'])==ROOT/'full.json'
    assert full['runs']['control'][0]['RGB16']['sha256']==read_json(
        ROOT.with_name('corpus100k-faster-inference-v1')/'cli-staging.json'
    )['runs']['pinned']['TIFF']['sha256']
    assert all(row['channels']==305987556 for group in full['output_differences'].values() for row in group)
    assert full['output_differences']['cached'][0]['fraction_exact']==1
    assert all(row['fraction_exact']==1 for row in full['output_differences']['control'])
    for runs in full['runs'].values():
        for run in runs:
            checked(run['RGB16'])
            checked(run['crops'])
            assert run['timing']['compute_precision']=='float16'
    assert canonical['summaries']['photo']['sources']==427
    assert canonical['summaries']['photo']['cases']==11956
    assert canonical['summaries']['known']['cases']==72 and canonical['summaries']['unseen']['cases']==90
    checked(canonical['progress'])
    for engine in canonical['engines'].values():
        checked(engine)
    assert observations['quality']==reference(ROOT/'quality.json')
    views={}
    for key in ('main','cab','outliers'):
        for row in native[key]:
            publish_board(row['board'])
        views[key]=native[key]
    for row in native['exact']:
        if row['board'] is not None:
            comparisons=publish_board(row['board']['board'])
            triplet=publish_board(row['board']['triplet'])
            assert len(triplet)==3 and {'Noisy Malvar','Exact GT'}<=triplet.keys()
            assert all(ImageChops.difference(img,comparisons[label]).getbbox() is None for label,img in triplet.items())
    views['exact']=native['exact'][:2]
    views['long_exact'] = []
    for row in overlap['rows']:
        if row['board'] is not None:
            comparisons=publish_board(row['board']['board'])
            triplet=publish_board(row['board']['triplet'])
            assert set(triplet)=={'Noisy Malvar','FP16 larger / less overlap','Exact GT'}
            assert all(ImageChops.difference(img,comparisons[label]).getbbox() is None for label,img in triplet.items())
            views['long_exact'].append(row)
    assert len(views['long_exact'])==2
    assert observations['overlap']==reference(ROOT/'overlap.json')
    views['TensorRT_panel_outliers'] = []
    assert checked(trt_tails['canonical'])==ROOT/'trt-canonical.json'
    assert observations['TensorRT_panel_outliers']==reference(ROOT/'trt-panel-outliers.json')
    for row in trt_tails['rows']:
        comparisons=publish_board(row['board']['board'])
        triplet=publish_board(row['board']['triplet'])
        assert set(triplet)=={'Noisy Malvar','TensorRT FP16','Exact GT'}
        assert all(ImageChops.difference(img,comparisons[label]).getbbox() is None for label,img in triplet.items())
        views['TensorRT_panel_outliers'].append(row)
    views['checkpoint']=checkpoint
    views['observations']=observations
    manifest = IMAGES/'manifest.json'
    write_json(manifest,views,replace=True)
    arm_timings = {}
    for name,runs in full['runs'].items():
        arm_timings[name]={'restoration_seconds':median(r['timing']['seconds'] for r in runs),
                           'export_seconds':median(r['writer_seconds'] for r in runs),
                           'peak_cuda_gb':max(r['timing']['peak_cuda_gb'] for r in runs),
                           'tiles':runs[0]['timing']['tiles']}
    files={name:ROOT/name for name in (
        'screen_throughput.py','full_throughput.py','review_throughput.py','review_overlap.py','trt_canonical.py','trt_panel_outlier.py','publish.py',
        'screen.log','full.log','review_throughput.log','review_training_trace_preflight.log',
        'review_overlap.log','trt_canonical.log','trt_panel_outlier.log','tests.log','screen.json','full.json','quality.json','overlap.json',
        'visual-review.json','trt-canonical.json','trt-canonical-progress.jsonl','trt-panel-outliers.json',
    )}
    paths = (
        (ROOT.with_name('corpus100k-faster-inference-v1'),('trt_hidden.py','trt-review.json','replay.py')),
        (ROOT.with_name('corpus100k-mixed-precision-v1'),('full_production.py','screen.py','canonical.py','canonical.json')),
        (ROOT.with_name('paired-luminance-detail-v1'),('render.py',)),
        (Path('src/demosaic'),('precision.py','inference.py')),
        (Path('scripts'),('report_scene_wave_guides.py',)),
    )
    for directory, names in paths:
        files.update({f'dependencies/{directory.name}/{name}':directory/name for name in names})
    archive=OUT/'evidence.tar.xz'
    with tarfile.open(archive,'w:xz',preset=5) as stream:
        for name,path in sorted(files.items()):
            stream.add(path,arcname=name)
    with tarfile.open(archive) as stream:
        for name,path in files.items():
            with stream.extractfile(name) as f:
                assert hashlib.file_digest(f,'sha256').hexdigest()==reference(path)['sha256']
    publication = {
        'archived':reference(archive),'native_manifest':reference(manifest),'checkpoint':checkpoint,
        'scope':'Inference only. Independent eager tile-geometry timing/fidelity and a source-bound broad check for the existing TensorRT FP16 engines.',
        'eager_full_frame':full,'eager_timing_summary':arm_timings,'native_images_viewed':True,
        'long_geometry_exact_targets':overlap,'TensorRT_FP16_canonical':canonical,
    }
    write_json(OUT/'publication.json',publication,replace=True)
    print('Archived',len(files),'files and reviewed',len(native['main'])+len(native['cab'])+6+len(native['outliers']),'native cases')


if __name__=='__main__':
    main()
