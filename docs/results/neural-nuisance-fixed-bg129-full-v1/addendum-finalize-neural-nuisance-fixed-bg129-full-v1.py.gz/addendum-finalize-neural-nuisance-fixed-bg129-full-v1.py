import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-review-v1"
destination = repo / "docs/results/neural-nuisance-fixed-bg129-full-v1"
batches = [read_json(path) for path in sorted(root.glob("viewing-batch-*.json"))]
assert all(b["actually_viewed"] for b in batches)
prepared = read_json(root / "publication-prepared.json")
manifest = read_json(root / "contact-sheets/manifest.json")
assert len(prepared["images"]) == manifest["source_images"] == 68
assert sorted(i for batch in batches for i in batch["sheets"]) == list(range(len(manifest["sheets"])))
archives = list(prepared["archives"])
for source in [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *sorted(root.glob("viewing-batch-*.json")), repo / ".cache/native-contact-sheets-v1.py", Path(__file__), repo / ".cache/prepare-fixed-bg129-full-publication-v1.py", repo / ".cache/fixed-bg129-full-publication-prep-result-v1.json"]:
    target = destination / ("addendum-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})
for item in archives:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in prepared["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
prepared.update(archives=archives,
    viewing={"actually_viewed": True, "figures": 68, "contact_sheets": 17,
             "manifest": reference(root / "contact-sheets/manifest.json"),
             "batches": [reference(p) for p in sorted(root.glob("viewing-batch-*.json"))]},
    status="complete full producer/audit/statistics/native review",
    quality_decision="Compared to256 NN,400/far weak2.299% to2.778%, strong37.032% to48.055%. All8 sources improve strong response/full RGB error,7 improve weak response, but mean quiet/increment error increase and only3 sources improve increment error vs256/1 vs parent. Real cab ripples/coarse-fence correction smaller, fine crossings still absent; analytic building bands persist. Useful stronger-detail/less-real-ripple alternative, no broad weak fidelity/general-model promotion.",
    summary=reference(root / "summary.json"), published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination / "publication.json", prepared)
print(len(archives), "exact archives;", len(prepared["per_case_receipts"]["members"]), "bundled case receipts;68 actually viewed source figures")
