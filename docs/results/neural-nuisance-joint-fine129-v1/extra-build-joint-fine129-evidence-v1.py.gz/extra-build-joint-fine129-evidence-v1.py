"""Freeze46-figure review helpers without reading pending inference outputs."""
from pathlib import Path

repo=Path.cwd()
old='neural-nuisance-fine-sinusoidal129-pilot-v1'
new='neural-nuisance-joint-fine129-pilot-v1'
created=[]
def build(source,target,replacements=()):
    s=(repo/'.cache'/source).read_text().replace(old,new)
    for a,b in replacements:
        assert a in s,(source,a)
        s=s.replace(a,b)
    p=repo/'.cache'/target;assert not p.exists();p.write_text(s);compile(s,str(p),'exec');created.append(p)
labels=[('Broad+fine H1 A t2','Joint fine A t2'),('Broad+fine H1 NN t2','Joint fine NN t2')]
build('extra-fine-sinusoidal129-stress-v1.py','extra-joint-fine129-stress-v1.py',labels)
build('analytic-fine-sinusoidal129-triplets-v1.py','analytic-joint-fine129-triplets-v1.py',labels[:1])
build('fine-sinusoidal129-1600-triplets-v1.py','joint-fine129-1600-triplets-v1.py',labels[:1])
build('fine-sinusoidal129-paired-boards-v1.py','joint-fine129-paired-boards-v1.py',[
    ('neural-nuisance-fine-phase129-pilot-v1',old),
    ('Fine phase A t2','Independent A t2'),('Fine H1 A t2','Joint colour A t2'),
    ('Common analytic nuisance and identical broad guided-phase correction/fine proposals. Fine phase versus local129/stride32 H1 full-fit carrier delivery, conditional full/null support, fixed global broad/background nuisance. Fine H1 has no phase/range/edge-side pooling; RGB coefficients independent. Not an isolated harmonic-only ablation.',
     'Identical broad/fine H1 proposals, coefficients and full/null predictors. Only fine support changes: separate per-colour scores versus pooled actual-CFA full/null gain and energy before normalization, one scalar RGB support. Independent RGB amplitudes/phases retained; not calibrated confidence.'),
])
build('fine-sinusoidal129-cab-before-after-v1.py','joint-fine129-cab-before-after-v1.py',[
    ('neural-nuisance-fine-phase129-pilot-v1',old),
    ("('Fine phase A t2',a,ap,'Broad+fine A t2'),('Fine H1 A t2',b,bp,'Broad+fine H1 A t2')",
     "('Independent A t2',a,ap,'Broad+fine H1 A t2'),('Joint colour A t2',b,bp,'Joint fine A t2')"),
    ('fine-phase/fine-sinusoidal','independent-colour/joint-colour'),
])
s=(repo/'.cache/publish-neural-nuisance-fine-sinusoidal129-v1.py').read_text().replace(old,new).replace('neural-nuisance-fine-sinusoidal129-v1','neural-nuisance-joint-fine129-v1')
for a,b in labels:s=s.replace(a,b)
s=s.replace("['iso400-index0008-role2','iso400-index0024-role2']", "['iso400-index0008-role2','iso400-index0024-role2','iso1600-index0008-role2','iso1600-index0024-role2']")
s=s.replace('assert len(figures)==44','assert len(figures)==46')
s=s.replace('Broad guided phase plus sinusoidal fine carriers','Joint colour support for measured fine carriers')
s=s.replace('Paired1600 boards compare fine phase versus fine sinusoidal full-fit carrier delivery, with the identical broad guided-phase correction and fine proposals. Fine H1 has local129/stride32 amplitudes/conditional support after global nuisance, no fine range/edge-side pooling. Separate RGB coefficients and identical RAW/parent map.',
    'Paired1600 boards compare independent-colour versus joint-colour fine support. Identical broad/fine geometry, full-fit RGB coefficients and RAW/parent maps. Joint score pools actual CFA full/null gains/energies before normalization and shares one support across independent RGB amplitudes/phases. It can admit noisy weak-colour coefficients; not calibrated confidence.')
a=s.index('extras = [');b=s.index('assert all(p.is_file()',a)
extras=['tests/test_joint_colour_evidence.py','tests/test_fine_carrier_proposals.py',
 '.cache/joint-fine-colour-tests-v1.log','.cache/joint-fine-colour-ruff-v1.log',
 '.cache/diagnose-fine-colour-evidence-v1.py','.cache/diagnose-fine-colour-evidence-v1.log','.cache/fine-colour-evidence-v1.json',
 '.cache/prepare-neural-nuisance-joint-fine129-v1.log','.cache/launch-neural-nuisance-joint-fine129-v1.py','.cache/launch-neural-nuisance-joint-fine129-v1.log',
 '.cache/build-joint-fine129-evidence-v1.py','.cache/build-joint-fine129-evidence-v1.log',
 '.cache/prepare-joint-fine129-publication-v1.py','.cache/publish-neural-nuisance-joint-fine129-v1.py',
 'scripts/audit_neural_nuisance_inputs.py']
for p in created:extras.extend([str(p.relative_to(repo)),str(p.with_suffix('.log').relative_to(repo))])
s=s[:a]+'extras = [R / name for name in '+repr(extras)+']\n'+s[b:]
p=repo/'.cache/publish-neural-nuisance-joint-fine129-v1.py';assert not p.exists();p.write_text(s);compile(s,str(p),'exec')
driver=(repo/'.cache/prepare-fine-sinusoidal129-publication-v1.py').read_text().replace(old,new)
p=repo/'.cache/prepare-joint-fine129-publication-v1.py';assert not p.exists();p.write_text(driver);compile(driver,str(p),'exec')
print('Prepared seven immutable evidence helpers/driver;46 figures, no pending output access')
