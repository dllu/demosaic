"""Exact native before/after cab cells, retaining independent reference/JPEG pixels."""
from pathlib import Path
import shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/neural-nuisance-joint-fine129-pilot-v1';old=root.parent/'neural-nuisance-fine-sinusoidal129-pilot-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
current=read_json(root/'native/report.json');before=read_json(old/'native/report.json')
out=root/'cab-before-after';out.mkdir();figures=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10)
for profile in ['mesh-nominal','mesh-profile3879']:
    for side in ['left','right']:
        name=profile+'-fine-green-mesh-'+side+'-comparison.png'
        a=next(f for f in before['figures']if Path(f['image']['path']).name==name)
        b=next(f for f in current['figures']if Path(f['image']['path']).name==name)
        for key in ['source','ROI_xywh','display_exposure','display_contrast']:assert a[key]==b[key]
        ap=np.asarray(Image.open(checked(a['image'])));bp=np.asarray(Image.open(checked(b['image'])))
        requests=[('Noisy Malvar',b,bp,'Noisy Malvar'),('Independent A t2',a,ap,'Broad+fine H1 A t2'),('Joint colour A t2',b,bp,'Joint fine A t2'),('ISO100 ref, not GT',b,bp,'ISO100 ref, not GT'),('SOOC ISO100 JPEG',b,bp,'SOOC ISO100 JPEG')]
        canvas=Image.new('RGB',(848,192),'#eeeeee');draw=ImageDraw.Draw(canvas);panels=[]
        for j,(label,figure,png,source_label)in enumerate(requests):
            panel=next(p for p in figure['panels']if p['label']==source_label)
            x,y,w,h=panel['xywh'];cell=png[y:y+h,x:x+w];assert cell.shape==(160,160,3)
            tx,ty=8+j*168,24;canvas.paste(Image.fromarray(cell),(tx,ty));draw.text((tx,5),label,font=font,fill='black')
            panels.append({'label':label,'xywh':[tx,ty,160,160],'source_image':figure['image'],'source_xywh':panel['xywh']})
        path=out/(profile+'-'+side+'-before-after.png');canvas.save(path);encoded=np.asarray(Image.open(path))
        for panel,(_,figure,png,source_label)in zip(panels,requests,strict=True):
            x,y,w,h=panel['xywh'];sx,sy,sw,sh=panel['source_xywh'];np.testing.assert_array_equal(encoded[y:y+h,x:x+w],png[sy:sy+sh,sx:sx+sw])
        figures.append({'image':reference(path),'panels':panels,'source':b['source'],'ROI_xywh':b['ROI_xywh'],'display_exposure':b['display_exposure'],'display_contrast':1,'no_resize':True,'baseline_model':reference(old/'analytic-model.json'),'current_model':reference(root/'analytic-model.json'),'scope':'Exact same native ROI/calibration/input/parent, independent ISO100/AHD reference and JPEG pixels copied unchanged. This is a qualitative capture comparison, not pixelwise scoring or exact GT.'})
write_json(out/'report.json',{'script':reference(__file__),'figures':figures,'new_neural_forwards':0,'RGB_crop_channels_exact':4*5*160*160*3,'scope':'Four primary analytic independent-colour/joint-colour comparisons at original left/right ROIs under both noise profiles. Every displayed cell reread exactly; no resize.'})
print('four cab boards, exact channels',4*5*160*160*3)
