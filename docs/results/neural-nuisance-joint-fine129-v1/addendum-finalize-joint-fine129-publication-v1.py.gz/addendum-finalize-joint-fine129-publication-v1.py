"""Seal46 actually viewed joint-support figures and exact historical evidence."""
import gzip
from datetime import datetime,timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/neural-nuisance-joint-fine129-pilot-v1'
dest=repo/'docs/results/neural-nuisance-joint-fine129-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
assert read_json(root/'evidence-result.json')['all_stages_succeeded']
p=read_json(root/'publication-prepared.json');manifest=read_json(root/'contact-sheets/manifest.json')
batches=sorted(root.glob('viewing-batch-*.json'));viewed=[]
for path in batches:
    b=read_json(path);assert b['actually_viewed']and b['notes']and b['manifest']==reference(root/'contact-sheets/manifest.json')
    viewed.extend(b['sheets'])
    for ref in b['sheet_images']:checked(ref)
assert sorted(viewed)==list(range(len(manifest['sheets'])))
assert len(p['images'])==manifest['source_images']==46 and len(manifest['sheets'])==14
decision=read_json(root/'quality-decision.json');assert decision['actually_viewed_figures']==46 and decision['limitations']
archives=list(p['archives']);already={a['original']['path']for a in archives}
sources=[f for f in sorted(root.rglob('*'))if f.is_file()and root/'work'not in f.parents and f.suffix in {'.json','.log','.py'}]
sources += [repo/n for n in [
 '.cache/finalize-joint-fine129-publication-v1.py',
 '.cache/prepare-joint-fine129-publication-v2.py','.cache/native-joint-fine129-contact-sheets-v1.py',
 '.cache/joint-fine129-evidence-queue-v1.log','.cache/joint-fine129-evidence-queue-v2.log',
 '.cache/compare-joint-fine129-v1.py','.cache/compare-joint-fine129-v1.log',
 '.cache/joint-fine129-H1-parity-v1.py','.cache/joint-fine129-H1-parity-v1.log',
 '.cache/joint-fine129-scene-maxima-v1.py','.cache/joint-fine129-scene-maxima-v1.log',
 '.cache/native-joint-fine129-contact-sheets-v1.log',
 '.cache/diagnose-joint-fine-colour-evidence-v1.py','.cache/diagnose-joint-fine-colour-evidence-v1.log',
 '.cache/joint-fine-colour-evidence-v1.json','.cache/joint-fine-colour-diagnostic-completion-v1.json',
 ]]
for source in sources:
    ref=reference(source)
    if ref['path']in already:continue
    name=str(source.relative_to(root)if root in source.parents else source.name).replace('/','--')
    path=dest/('addendum-'+name+'.gz')
    with path.open('xb')as stream:stream.write(gzip.compress(source.read_bytes(),mtime=0))
    archives.append({'original':ref,'published':reference(path),'decompressed_bytes_exact':True});already.add(ref['path'])
for item in archives:assert gzip.decompress(checked(item['published']).read_bytes())==checked(item['original']).read_bytes()
for item in p['images']:assert checked(item['published']).read_bytes()==checked(item['original']).read_bytes()
p.update(archives=archives,original_preparation=reference(root/'publication-prepared.json'),
         viewing={'actually_viewed':True,'figures':46,'contact_sheets':14,'manifests':{'base':reference(root/'contact-sheets/manifest.json')},'batches':[reference(f)for f in batches]},
         quality_decision=decision,comparison=reference(root/'closed-comparison.json'),
         H1_control_parity=reference(root/'all-H1-control-parity.json'),correction_maxima=reference(root/'scene-correction-maxima.json'),
         input_colour_diagnostics=[reference(repo/'.cache/fine-colour-evidence-v1.json'),reference(repo/'.cache/joint-fine-colour-evidence-v1.json')],
         status='complete; cleaner real cab colour with synthetic-response and artifact costs',
         scope_clarification='Same fine proposals, full-fit independent RGB amplitudes/phases, nuisance maps and predictors; only fine support aggregates actual CFA gains/energies jointly. Original broad support/H1 unchanged. Fixed two-source development cohort and0/2/4 sweeps, all48 corrections before scoring. Real ISO100/AHD/JPEG references independent/not GT. Can admit noisy colour coefficients; no calibrated confidence/generalization claim. No neural replay in this cohort. Separate fresh coloured-wire study has its own explicitly recorded144 neural calls.',
         comparison_baselines=[reference(repo/'docs/results'/n/'publication.json')for n in ['neural-nuisance-fine-sinusoidal129-v1','neural-nuisance-guided-phase129-v1']],
         published_UTC=datetime.now(timezone.utc).isoformat())
write_json(dest/'publication.json',p)
print(len(archives),'exact archives;',len(p['images']),'actually viewed native figures on14 sheets')
