"""Closed-only source/geometry/metric comparison, without inference or real GT."""
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-joint-fine129-pilot-v1'
old = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
assert read_json(root / 'controller-result.json')['all_stages_succeeded']
assert read_json(root / 'followup/result.json')['returncode'] == 0
new_rows, old_rows = [read_json(p / 'collection.json')['rows'] for p in [root, old]]
assert len(new_rows) == len(old_rows) == 48
tiles = coarse_arms = fine_arms = matched_fine_units = 0
for a, b in zip(new_rows, old_rows, strict=True):
    assert a['id'] == b['id']
    for key in ['parent_values', 'packed_values', 'colors_values']:
        assert a[key] == b[key]
    aa, bb = a['aux'], b['aux']
    assert aa['identity_zero_noise'] == bb['identity_zero_noise']
    if aa['identity_zero_noise']:
        continue
    assert len(aa['records']) == len(bb['records'])
    for x, y in zip(aa['records'], bb['records'], strict=True):
        assert x['xy'] == y['xy']
        assert x['fine_proposal_unavailable_folds'] == y['fine_proposal_unavailable_folds']
        assert x['arms'].keys() == y['arms'].keys()
        for name in ['H1-', 'neural']:
            assert x['arms'][name] == y['arms'][name]
            coarse_arms += 1
        for name in ['fine-H1-', 'fine-neural']:
            if name not in x['arms']:
                continue
            for key in ['frequencies', 'matched', 'heldout_full_standardized_MSE_by_color', 'wave_residual_energy_fraction_by_direction_color', 'wave_residual_Gram_eigenvalues_by_direction_color']:
                assert x['arms'][name][key] == y['arms'][name][key]
            fine_arms += 1
            if name == 'fine-H1-':
                matched_fine_units += len(x['arms'][name]['matched'])
        tiles += 1

keys = ['weak_gain', 'strong_gain', 'quiet_error_RMS_DN16', 'weak_increment_error_RMS_DN16']
rows = []
fields = 0
source_rows = []
names = ['neural-nuisance-guided-phase129-pilot-v1', old.name, root.name]
for name in names:
    folder = root.parent / name
    summary = read_json(folder / 'summary-review/summary.json')
    finite = read_json(folder / 'finite-scores.json')['rows']
    for row in summary['means']:
        if row['method'] not in ['V143', 'conditional-local-t2', 'local-t2']:
            continue
        subset = [r for r in finite if all(r[k] == row[k] for k in ['profile', 'placement', 'method'])]
        assert len(subset) == 2
        for key in keys:
            assert abs(np.mean([r[key] for r in subset]) - row[key]) < 1e-12
            fields += 1
        full = next(r['full_RMS_DN16'] for r in summary['absolute_role_means']
                    if all(r[k] == row[k] for k in ['profile', 'placement', 'method']) and r['role'] == 2)
        rows.append({'study': name, **{k: row[k] for k in ['profile', 'placement', 'method', *keys]},
                     'role2_full_RMS_DN16': full})
    for row in finite:
        if row['method'] in ['V143', 'conditional-local-t2', 'local-t2']:
            source_rows.append({'study': name, **{k: row[k] for k in ['profile', 'placement', 'source', 'method', *keys]}})
write_json(root / 'closed-comparison.json', {
    'script': reference(__file__), 'current': reference(root / 'collection.json'),
    'fine_phase': reference(old / 'collection.json'),
    'paired_input_parent_fingerprints_exact': 48, 'paired_tiles': tiles,
    'broad_diagnostic_arms_exact': coarse_arms, 'fine_geometry_arms_exact': fine_arms,
    'fine_matched_direction_units': matched_fine_units,
    'independent_mean_fields': fields, 'means': rows, 'sources': source_rows,
    'scope': 'All48 closed before analysis. Identical broad diagnostic arms and fine proposals/matching; '
        'fine waveform/fit/delivery/support differ. Fixed t2 primary, no new NN/RAW/noise. '
        'Two reused geometries; response is amplitude, not accuracy or camera generalization. '
        'No real reference scoring or inference replay.',
})
print('matched tiles', tiles, 'broad arms exact', coarse_arms, 'fine geometry arms exact', fine_arms)
for row in rows:
    if row['study'] == root.name and row['method'] == 'conditional-local-t2':
        print(row)
