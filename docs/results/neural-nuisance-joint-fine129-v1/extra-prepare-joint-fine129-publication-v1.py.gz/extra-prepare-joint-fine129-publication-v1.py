"""Wait for exact owners and all48 outputs before seven evidence stages."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-joint-fine129-pilot-v1'
os.sched_setaffinity(0, [16, 17])
for path in [root / 'launch.json', root / 'followup/launch.json']:
    identity = read_json(path)
    while True:
        try:
            process = psutil.Process(identity['pid'])
            if process.create_time() != identity['create_time'] or process.status() == psutil.STATUS_ZOMBIE:
                break
        except psutil.NoSuchProcess:
            break
        time.sleep(5)
assert read_json(root / 'controller-result.json')['all_stages_succeeded']
assert read_json(root / 'followup/result.json')['returncode'] == 0
assert len(read_json(root / 'collection.json')['rows']) == 48
queue = read_json(root / 'evidence-queue.json')
env = dict(os.environ, PYTHONPATH=str(repo / 'src') + ':' + str(repo / 'scripts'),
           CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2')
stages = []
for entry in queue['stages']:
    script = checked(entry['script'])
    began = time.monotonic()
    with (repo / '.cache' / (script.stem + '.log')).open('x') as log:
        child = subprocess.Popen([sys.executable, str(script), *entry['args']], stdout=log,
                                 stderr=subprocess.STDOUT, env=env)
        identity = {'pid': child.pid, 'create_time': psutil.Process(child.pid).create_time(),
                    'script': reference(script)}
        write_json(root / (script.stem + '-launch.json'), identity)
        code = child.wait()
    stages.append({'script': reference(script), 'returncode': code, 'seconds': time.monotonic() - began})
    if code:
        break
write_json(root / 'evidence-result.json', {'script': reference(__file__), 'stages': stages,
           'all_stages_succeeded': len(stages) == 7 and all(r['returncode'] == 0 for r in stages)})
print(stages, flush=True)
