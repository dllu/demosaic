"""RAW/A-only colour phasors and support; no parent, GT or reference access."""
import os
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.fine_carrier_proposals import fit_fine_candidate
from demosaic.local_validated_waves import LocalWaveConfig, conditional_scores, fit_local_candidate, match_directions, support_weight
from demosaic.neural_nuisance import WithheldBackground, fit_neural_candidate
from demosaic.spatial_carrier_amplitudes import SpatialCarrierOperator

os.sched_setaffinity(0, [16, 17])
repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
plan = read_json(root / 'plan.json')
assert read_json(root / 'controller-result.json')['all_stages_succeeded']
config = LocalWaveConfig(**plan['geometry_config'])
cache = {r['id']: r for r in read_json(root / 'backgrounds-collection.json')['rows']}
stored = {r['id']: r for r in read_json(root / 'collection.json')['rows']}
result = []
maximum_map_error = 0.
for row in plan['rows']:
    if row['kind'] != 'mesh':
        continue
    with np.load(checked(row['arrays']), allow_pickle=False) as z:
        packed, phases = z['packed'][row['sample']], z['colors'][row['sample']]
    shape = tuple(2 * n for n in packed.shape[-2:])
    raw = np.empty(shape, np.float64)
    for phase in range(4):
        raw[phase // 2::2, phase % 2::2] = packed[phase]
    colors = np.tile(phases.reshape(2, 2), (shape[0] // 2, shape[1] // 2))
    mask = np.load(checked(cache[row['id']]['mask_A']))
    fields = [np.load(checked(f)) for f in cache[row['id']]['fields']]
    for item in stored[row['id']]['aux']['records']:
        x, y = item['xy']
        region = np.s_[y:y + 512, x:x + 512]
        tile, layout = raw[region], colors[region]
        masks = [mask[region], ~mask[region]]
        coarse = [fit_local_candidate(tile, layout, m, shot=row['noise']['shot'], read=row['noise']['read'], config=config) for m in masks]
        fine = [fit_fine_candidate(tile, layout, r, shot=row['noise']['shot'], read=row['noise']['read'], config=config) for r in coarse]
        assert all(c is not None for c in fine)
        for arm in ['analytic', 'neural']:
            backgrounds = [None, None] if arm == 'analytic' else [WithheldBackground(f[:, region[0], region[1]], m) for f, m in zip(fields, masks, strict=True)]
            candidates = fine if arm == 'analytic' else [fit_neural_candidate(tile, layout, c, b, config=config, reselect_frequencies=False) for c, b in zip(fine, backgrounds, strict=True)]
            key = 'fine-H1-' if arm == 'analytic' else 'fine-neural'
            assert [np.asarray(c.frequencies_xy).tolist() for c in candidates] == item['arms'][key]['frequencies']
            operators = [SpatialCarrierOperator(c, layout, window=129, stride=32, background=b, nuisance_mode='global') for c, b in zip(candidates, backgrounds, strict=True)]
            scores = [conditional_scores(o.predict(tile), tile, layout, ~o.mask, window=129, stride=32) for o in operators]
            matched = match_directions(candidates[0].frequencies_xy, candidates[1].frequencies_xy, tile.shape, config.match_native_bins, matching='cardinality')
            for side, roi in [('left', [206,229,160,160]), ('right', [426,189,160,160])]:
                cx, cy = roi[0] + 79.5 - x, roi[1] + 79.5 - y
                if not (0 <= cx < 512 and 0 <= cy < 512):
                    continue
                phase_window = lambda z: float(np.sin(np.pi * (z + .5) / 512) ** 2)
                center_blend = phase_window(cx) * phase_window(cy)
                for first, second, distance in matched:
                    phasors = np.empty((2,3), complex)
                    scales = np.empty((2,3))
                    queries = []
                    for fold, (candidate, operator, unit) in enumerate(zip(candidates, operators, [first, second], strict=True)):
                        iy, ix = int(np.argmin(abs(operator.ay - cy))), int(np.argmin(abs(operator.ax - cx)))
                        qy, qx = int(operator.ay[iy]), int(operator.ax[ix])
                        queries.append([qx+x, qy+y])
                        for color, group in enumerate(operator.groups):
                            coefficient = operator.coefficients(tile, group)[0][iy,ix]
                            # Exact linear query map, including global nuisance subtraction.
                            selected = group['selected']
                            sy, sx = np.where(selected)
                            local = (abs(sx-qx) <= 64) & (abs(sy-qy) <= 64)
                            design = operator.design[selected.ravel()]
                            weights = group['weights'][selected][local]
                            direct = group['inverse'][iy,ix] @ (design[local].T * weights)
                            mapping = np.zeros((4, len(sx)))
                            mapping[:,local] = direct
                            mapping -= direct @ group['sensor_background'][local] @ group['global_operator'][:operator.nuisance_columns]
                            error = float(np.max(abs(mapping @ tile[selected] - coefficient)))
                            maximum_map_error = max(maximum_map_error, error)
                            assert error < 1e-11
                            covariance = (mapping * candidate.variance_cfa[selected]) @ mapping.T
                            start = 2 * unit
                            value = coefficient[start] - 1j*coefficient[start+1]
                            frequency = np.asarray(candidate.frequencies_xy[unit])
                            # Shift each fold's native sinusoid to the common ROI centre.
                            phasors[fold,color] = value * np.exp(2j*np.pi*np.dot(frequency,[cx,cy]))
                            scales[fold,color] = np.sqrt(np.trace(covariance[start:start+2,start:start+2]))
                    x0,y0 = max(0,roi[0]-x),max(0,roi[1]-y)
                    x1,y1 = min(512,roi[0]+160-x),min(512,roi[1]+160-y)
                    support = support_weight(np.minimum(scores[0][0][first],scores[1][0][second]),2.)[:,y0:y1,x0:x1]
                    for color in range(3):
                        result.append({'case':row['id'],'arm':arm,'side':side,'tile_xy':[x,y],
                            'center_blend':center_blend,'query_xy_by_fold':queries,
                            'frequency_by_fold':[candidates[0].frequencies_xy[first],candidates[1].frequencies_xy[second]],
                            'match_native_bins':distance,'color':'RGB'[color],
                            'phasor_DN16_by_fold':[[float(v.real*65535),float(v.imag*65535)] for v in phasors[:,color]],
                            'amplitude_DN16_by_fold':(abs(phasors[:,color])*65535).tolist(),
                            'fixed_design_noise_scale_DN16_by_fold':(scales[:,color]*65535).tolist(),
                            'fixed_design_amplitude_over_scale':(abs(phasors[:,color])/scales[:,color]).tolist(),
                            'fold_phase_difference_degrees':float(np.angle(phasors[0,color]*phasors[1,color].conjugate(),deg=True)),
                            'local_support_mean_t2':float(support[color].mean()),
                            'local_support_positive_fraction_t2':float(np.mean(support[color]>0))})
write_json(repo/'.cache/fine-colour-evidence-v1.json',{'script':reference(__file__),'plan':reference(root/'plan.json'),
    'rows':result,'maximum_direct_linear_map_error':maximum_map_error,'parent_GT_reference_arrays_loaded':0,
    'new_neural_forwards':0,'scope':'Actual RAW plus genuine cached A-only NN fields only. Native query129/32 full-fit fine coefficients and conditional support. Common ROI-centre phasors, nearest native query coefficients. Noise scale propagates the fixed complete local/global operator with the declared A-only variance proxy; frequency/weight selection is data-dependent, so these are NOT calibrated confidence/SNR or true-noise uncertainties. No low-noise reference, parent or GT loaded; real colour correctness remains unknown.'})
print('colour rows',len(result),'maximum exact-map error',maximum_map_error)
for r in result:
    if r['center_blend']>.6 and r['case']=='mesh-nominal':
        print({k:r[k]for k in ['arm','side','tile_xy','color','amplitude_DN16_by_fold','fixed_design_amplitude_over_scale','fold_phase_difference_degrees','local_support_mean_t2']})
