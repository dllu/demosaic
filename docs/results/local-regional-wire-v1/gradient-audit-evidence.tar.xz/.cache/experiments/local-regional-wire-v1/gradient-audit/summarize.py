"""Summarize signed first-order interactions and the available protected update."""

from itertools import product
import json
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path("/mnt/external/demosaic/local-regional-wire-v1/gradient-audit/result.json")
PAIRS = ("whole", "regional")
PROTECTED = ("weak_absence", "continuing")
SCORED = ("absolute", "paired", "repeat", "weak_absence", "continuing", "flat")


def cosine(gram, first, second):
    norm = np.sqrt(max(first @ gram @ first, 0) * max(second @ gram @ second, 0))
    return float(np.clip(first @ gram @ second / norm, -1, 1)) if norm else None


def tangent_fraction(correlations, i, controls):
    """Fraction of the original gradient norm orthogonal to the control span."""
    cross = correlations[i, controls]
    control = correlations[np.ix_(controls, controls)]
    projection = cross @ np.linalg.pinv(control, rcond=1e-10, hermitian=True) @ cross
    assert -1e-5 <= projection <= 1.00001
    return float(np.sqrt(np.clip(1 - projection, 0, 1)))


def details(row, field, labels):
    eye = dict(zip(labels, np.eye(len(labels)), strict=True))
    gram = np.asarray(row[field], dtype=np.float64)
    assert gram.shape == (len(labels), len(labels))
    assert np.isfinite(gram).all() and (gram.diagonal() >= 0).all()
    assert np.allclose(gram, gram.T, rtol=0, atol=1e-7)
    norms = np.sqrt(gram.diagonal())
    denominator = norms[:, None] * norms[None, :]
    correlations = np.divide(gram, denominator, out=np.zeros_like(gram), where=denominator > 0)
    assert np.linalg.eigvalsh(correlations)[0] > -1e-5
    elig = {name: norms[j] > 0 for j, name in enumerate(labels)}
    control = [labels.index(k) for k in PROTECTED if elig[k]]
    shared = sum(eye[k] for k in ("absolute", "paired", *PROTECTED))
    # Training activates the repeat term only on independent within-pair noise.
    if row["observation"]["law"] == "independent":
        shared += eye["repeat"]
    arms = {}
    for name in PAIRS:
        if not elig[name]:
            continue
        arm = eye[name]
        arms[name] = {
            "weighted_gradient_norm": float(norms[labels.index(name)]),
            "norm_over_absolute": float(norms[labels.index(name)] / norms[labels.index("absolute")]),
            "cosine_to": {k: cosine(gram, arm, eye[k]) for k in SCORED},
            "shared_to": {k: cosine(gram, shared, eye[k]) for k in SCORED},
            "total_to": {k: cosine(gram, shared + arm, eye[k]) for k in SCORED},
            "protected_fraction": tangent_fraction(correlations, labels.index(name), control),
            "protected_fraction_all_three": tangent_fraction(
                correlations, labels.index(name), [*control, labels.index("flat")],
            ),
        }
        if field == "prediction_gram":
            values = arms[name]["cosine_to"]
            assert values["flat"] == 0
            assert values["continuing"] is None or abs(values["continuing"]) < 1e-6
    return {
        "norms": dict(zip(labels, norms.tolist(), strict=True)),
        "whole_to_regional": cosine(gram, eye["whole"], eye["regional"]),
        "arms": arms,
        "shared_to_whole": cosine(gram, shared, eye["whole"]),
        "shared_to_regional": cosine(gram, shared, eye["regional"]),
        "whole_total_to_regional_total": cosine(gram, shared + eye["whole"], shared + eye["regional"]),
    }


def describe(values):
    if not values:
        return None
    percentiles = np.quantile(values, [0.1, 0.5, 0.9]).tolist()
    return {
        "n": len(values), "arithmetic_mean": float(np.mean(values)), "q10_median_q90": percentiles,
        "negative": int(np.sum(np.asarray(values) < -1e-5)),
        "positive": int(np.sum(np.asarray(values) > 1e-5)),
    }


def summarize(rows, field):
    values = [r[field] for r in rows]
    eligible = [d for d in values if len(d["arms"]) == 2]
    output = {"matched_valid": len(eligible), "all": len(values)}
    for key in ("whole_to_regional", "shared_to_whole", "shared_to_regional",
                "whole_total_to_regional_total"):
        output[key] = describe([d[key] for d in eligible])
    for name in PAIRS:
        arms = [d["arms"][name] for d in eligible]
        result = {k: describe([d[k] for d in arms]) for k in (
            "norm_over_absolute", "protected_fraction", "protected_fraction_all_three",
        )}
        for group in ("cosine_to", "shared_to", "total_to"):
            result[group] = {
                k: describe([d[group][k] for d in arms if d[group][k] is not None])
                for k in SCORED
            }
        output[name] = result
    output["regional_to_whole_norm"] = describe([
        d["arms"]["regional"]["weighted_gradient_norm"] / d["arms"]["whole"]["weighted_gradient_norm"]
        for d in eligible
    ])
    return output


def main():
    proof = reference(RESULT)
    result = read_json(checked(proof))
    plan = read_json(checked(result["audit"]))
    base = read_json(checked(plan["train_plan"]))
    training = Path("/mnt/external/demosaic/local-regional-wire-v1/train/observations.jsonl")
    labels = plan["labels"]
    rows = []
    with training.open() as stream:
        observed = {}
        for line in stream:
            if line.endswith("\n"):
                item = json.loads(line)
                observed[item["index"]] = item
    for source in result["samples"]:
        record = read_json(checked(source))
        assert record["audit"] == result["audit"]
        obs = record["observation"]
        live = observed.get(record["index"])
        assert live is None or live == obs
        plant = obs["geometry"]["wire"]
        rows.append({
            "index": record["index"], "source_id": obs["source_id"], "profile": obs["iso"],
            "law": obs["law"], "strong_continues": plant["strong_continues"],
            "live_training_input_matched": live is not None,
            **{key: details(record, field, labels) for key, field in (
                ("output", "prediction_gram"), ("parameters", "parameter_gram"),
            )},
        })
    assert [r["index"] for r in rows] == plan["indices"]
    assert result["weights"] == base["parent"]
    populations = {"all": rows}
    for iso, continuing in product(("ISO400", "ISO6400"), (False, True)):
        tag = f"{iso}-{'true_continuation' if continuing else 'double_gap'}"
        populations[tag] = [r for r in rows if r["profile"] == iso and r["strong_continues"] == continuing]
        assert len(populations[tag]) == 8, (tag, populations[tag])
    write_json(RESULT.with_name("summary.json"), {
        "driver": reference(__file__), "gradient_result": proof,
        "measurement": "A positive cosine predicts lower loss along the negative of the other gradient.",
        "rows": rows, "strata": {
            k: {space: summarize(samples, space) for space in ("output", "parameters")}
            for k, samples in populations.items()
        },
    })


if __name__ == "__main__":
    main()
