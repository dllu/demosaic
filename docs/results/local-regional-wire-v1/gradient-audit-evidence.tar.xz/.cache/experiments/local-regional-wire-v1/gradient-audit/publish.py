"""Publish the balanced training-gradient diagnostic and its source witnesses."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from plot import main as plot
from summarize import RESULT, ROOT


def main():
    git = ROOT.parents[3]
    receipts = {
        "result": reference(RESULT),
        "summary": reference(RESULT.with_name("summary.json")),
    }
    result, summary = (read_json(checked(v)) for v in receipts.values())
    assert summary["gradient_result"] == receipts["result"]
    assert len(result["samples"]) == len(summary["rows"]) == 32
    plan = read_json(checked(result["audit"]))
    assert plan["indices"] == [r["index"] for r in summary["rows"]]
    assert len({r["source_id"] for r in summary["rows"]}) == 32
    assert len({r["index"] for r in summary["rows"]}) == 32
    launch = reference(git / "docs/results/local-regional-wire-v1/launch.json")
    assert read_json(checked(launch))["plan"] == plan["train_plan"]
    entries = [
        *receipts.values(), *result["samples"], result["audit"], plan["driver"],
        plan["regional_objective"], summary["driver"], reference(__file__),
        reference(ROOT / "plot.py"), launch,
    ]
    folder = git / "docs/images/local-regional-wire-v1/gradient-audit"
    folder.mkdir(parents=True)
    graph = folder / "wire-loss-gradients.png"
    plot(checked(receipts["summary"]), graph)
    release = git / "docs/results/local-regional-wire-v1"
    archive = release / "gradient-audit-evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as bundle:
        for binding in entries:
            path = checked(binding)
            key = (path.relative_to(git) if path.is_relative_to(git)
                   else Path("external") / path.relative_to("/mnt/external/demosaic"))
            assert key.as_posix() not in members
            bundle.add(path, arcname=key.as_posix())
            members[key.as_posix()] = binding["sha256"]
    with tarfile.open(archive) as bundle:
        assert set(members) == set(bundle.getnames())
        for path, wanted in members.items():
            assert sha256(bundle.extractfile(path).read()).hexdigest() == wanted
    publication = {
        "scope": "Matched training-gradient diagnosis. No weights were changed and no inference quality was measured.",
        "recorded": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "result": receipts["result"], "summary": receipts["summary"],
        "launch": launch, "weights": result["weights"], "precision": result["precision"],
        "samples": len(result["samples"]),
        "samples_matching_run_trace": sum(r["live_training_input_matched"] for r in summary["rows"]),
        "strata": summary["strata"], "wall_seconds": result["wall_seconds"],
        "parameter_tensors": result["parameter_tensors"], "trainable_parameters": result["trainable_parameters"],
        "figure": reference(graph), "archive": reference(archive), "members": members,
    }
    write_json(release / "gradient-audit.json", publication)


if __name__ == "__main__":
    main()
