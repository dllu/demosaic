"""Plot how the wire update directions change from pixels to shared parameters."""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference


def main(source, output):
    rows = read_json(checked(reference(source)))["rows"]
    eligible = [r for r in rows if len(r["parameters"]["arms"]) == 2]
    fig, ax = plt.subplots(1, 2, figsize=(9.7, 3.8), layout="constrained")
    for has_strong, marker, color in ((True, "o", "#1d6668"), (False, "^", "#984b2b")):
        cases = [r for r in eligible if r["strong_continues"] == has_strong]
        ax[0].scatter(
            [r["output"]["whole_to_regional"] for r in cases],
            [r["parameters"]["whole_to_regional"] for r in cases],
            label="Continuing strong wire" if has_strong else "Both strands absent",
            marker=marker, c=color, s=24, alpha=.82,
        )
        k = ("flat", "weak_absence", "continuing")
        region = [[r["parameters"]["arms"]["regional"]["cosine_to"][key]
                   for r in cases if r["parameters"]["arms"]["regional"]["cosine_to"][key] is not None]
                  for key in k]
        for j, dots in enumerate(region):
            y = j + (.10 if has_strong else -.10)
            ax[1].scatter(dots, np.full(len(dots), y), marker=marker, c=color, s=22, alpha=.6)
            if dots:
                ax[1].plot(np.median(dots), y, "|", color="black", ms=9, mew=1.4)
    ax[0].set(
        title="Whole-core versus regional gradient",
        xlabel="Output pixel cosine", ylabel="Parameter cosine", xlim=(-1.05, 1.05), ylim=(-1.05, 1.05),
    )
    ax[0].plot([-1, 1], [-1, 1], ":", color=".6", linewidth=1)
    ax[0].legend(loc="lower right", fontsize=8, frameon=False)
    ax[1].set(
        title="Regional gradient versus control gradients",
        xlabel="Parameter cosine", xlim=(-1.05, 1.05), ylim=(2.5, -.5),
        yticks=(0, 1, 2), yticklabels=("Exact flat", "Weak direction absent", "Strong direction in gap"),
    )
    ax[1].axvline(0, color=".6", linewidth=1)
    for axis in ax:
        axis.grid(axis="x", alpha=.18)
        axis.set_axisbelow(True)
    fig.savefig(output, dpi=155, facecolor="white")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    opts = p.parse_args()
    main(opts.source, opts.output)
