"""Measure the interaction of directional and shared gradients on matched training inputs."""

import argparse
from collections import defaultdict
from dataclasses import replace
from itertools import product
from pathlib import Path
import random
import sys
import time

import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import RuntimePolicy, exclusive_run
from demosaic.inference import _stage_tiled_cuda
from demosaic.losses import reconstruction_loss
from demosaic.precision import amp_context, ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from train_regional import ARCHIVE, shared
import regional_objective as regional

LABELS = ("absolute", "paired", "repeat", "weak_absence", "continuing", "whole", "regional", "flat")
SAMPLE_SEED = 202611192244


def prepare():
    binding = reference(ROOT / "plan-v3.json")
    plan = read_json(checked(binding))
    verify_plan(plan)
    included = defaultdict(list)
    for idx, row in enumerate(read_json(checked(plan["schedule"]["train"])), 1):
        if row["kind"] != "wire":
            continue
        key = tuple(row[k] for k in ("iso", "pattern", "law", "strong_continues"))
        included[key].append(idx)
    assert set(included) == set(product(
        ("ISO400", "ISO6400"), ("RGGB", "BGGR", "GRBG", "GBRG"),
        ("coupled", "independent"), (False, True),
    ))
    rng = random.Random(SAMPLE_SEED)
    samples = [rng.choice(included[key]) for key in sorted(included)]
    rng.shuffle(samples)
    write_json(ROOT / "gradient-audit/plan.json", {
        "purpose": "Training-gradient diagnosis on the frozen source schedule at the shared Local 50k starting point.",
        "train_plan": binding,
        "driver": reference(__file__),
        "regional_objective": reference(ROOT / "regional_objective.py"),
        "sample_seed": SAMPLE_SEED,
        "indices": samples,
        "labels": LABELS,
    })


def pair_matrix(vectors):
    flat = torch.stack([v.float().reshape(-1) for v in vectors])
    gram = (flat @ flat.T).cpu()
    assert torch.isfinite(gram).all()
    return gram


def score(model, frozen, prior, bands, parameters, row, index):
    arrays, metadata = prior.observations(row, index, pair_draws=2, seed=frozen["seed"])
    batch = {k: value.cuda() for k, value in arrays.items()}
    for k in ("packed", "variance", "target", "sensor_target"):
        batch[k] = batch[k].contiguous(memory_format=torch.channels_last)
    camera = metadata["camera"]
    model.base.set_noise(camera["shot"], camera["read"])
    with amp_context("cuda", dtype="bfloat16"):
        prediction = model(*(batch[k] for k in prior.FORWARD_ARGS))
    assert prediction.dtype == torch.float32
    absolute, _ = reconstruction_loss(
        prediction, batch, auxiliary=mosaic(prediction, batch["colors"]),
        camera_supervision="sensor-valid-v1", reconstruction_charbonnier_epsilon=0.0003,
    )
    redraw, valid = bands.redraw_losses(prediction, batch, align=True)
    plant = metadata["geometry"]["wire"]
    bank = [(r, a.cuda() if a is not None else None, b.cuda() if b is not None else None)
            for r, a, b in regional.projections(plant)]
    localized, absence = regional.loss(prediction, batch, bank, bands.luminance)
    continuing = bands.continuing_wire_loss(
        prediction, batch, prior.gap_projection(plant, continuing=True).cuda(),
    )
    # Hold this metric out of the objective. It isolates the exact-flat observation.
    flat_delta = (prediction[4, :, 80:176, 80:176]
                  - batch["sensor_target"][4, :, 80:176, 80:176])
    flat = flat_delta.square().mean().add(1e-10).sqrt()
    weights = frozen["loss"]
    terms = {
        "absolute": absolute, "paired": redraw["mean"] * weights["paired"],
        "repeat": redraw["repeat"] * weights["repeat"],
        "weak_absence": absence * weights["weak_absence"],
        "continuing": continuing * weights["strong_gap"],
        "whole": redraw["aligned"] * weights["aligned"],
        "regional": localized * weights["regional_aligned"],
        "flat": flat,
    }
    assert tuple(terms) == LABELS
    gradients = []
    for j, loss in enumerate(terms.values()):
        g = torch.autograd.grad(loss, prediction, retain_graph=True)[0].detach()
        gradients.append(g)
    by_parameter = []
    for j, g in enumerate(gradients):
        # Reuse the actual forward for each VJP. The audit never updates weights.
        by_parameter.append(torch.autograd.grad(
            prediction, parameters, grad_outputs=g, retain_graph=j + 1 < len(gradients), allow_unused=True,
        ))
    gram = torch.zeros((len(LABELS), len(LABELS)), dtype=torch.float64)
    for parameter, derivatives in zip(parameters, zip(*by_parameter, strict=True), strict=True):
        if any(g is not None for g in derivatives):
            gram += pair_matrix([g if g is not None else torch.zeros_like(parameter) for g in derivatives])
    assert torch.isfinite(gram).all()
    return {
        "index": index, "observation": metadata, "valid_whole_core": bool(valid),
        "weighted_losses": {k: float(value.detach()) for k, value in terms.items()},
        "prediction_gram": pair_matrix(gradients).tolist(), "parameter_gram": gram.tolist(),
    }


def run(limit):
    audit_binding = reference(ROOT / "gradient-audit/plan.json")
    audit = read_json(checked(audit_binding))
    assert audit["driver"] == reference(__file__)
    assert audit["regional_objective"] == reference(regional.__file__)
    frozen = read_json(checked(audit["train_plan"]))
    schedule = read_json(checked(frozen["schedule"]["train"]))
    runtime = replace(RuntimePolicy(**frozen["runtime"]), cuda_quota_gib=16)
    runtime.resources(ARCHIVE)
    runtime.apply()
    prior = shared(frozen["shared_driver"])
    device = torch.device("cuda:0")
    checkpoint = frozen["parent"]
    model, state = load_scene_checkpoint(
        checked(checkpoint), weights="ema", device="cpu", expected_sha256=checkpoint["sha256"],
    )
    assert state["step"] == frozen["parent_update"] and state["mode"] == "none"
    assert state["DINO_sha256"] == frozen["DINO_sha256"]
    _stage_tiled_cuda(model, device)
    model.train()
    parameters = tuple(p for p in model.base.parameters() if p.requires_grad)
    bands = prior.PairedBands(device, frozen["loss"]["bands"])
    output = ARCHIVE / "gradient-audit"
    output.mkdir(exist_ok=True)
    indices = audit["indices"] if limit is None else audit["indices"][:limit]
    receipts = []
    started = time.monotonic()
    with exclusive_run(output), ieee_fp32():
        for index in indices:
            filename = output / f"wire-{index:04}.json"
            if filename.is_file():
                stored = read_json(filename)
                assert stored["audit"] == audit_binding and stored["index"] == index
            else:
                began = time.monotonic()
                scored = score(model, frozen, prior, bands, parameters, schedule[index - 1], index)
                write_json(filename, scored | {
                    "audit": audit_binding, "seconds": time.monotonic() - began,
                })
            receipts.append(reference(filename))
            print(f"Audited {len(receipts)}/{len(indices)} wire group {index}", flush=True)
        if limit is None:
            write_json(output / "result.json", {
                "audit": audit_binding, "samples": receipts, "weights": checkpoint,
                "precision": "training BF16 autocast with FP32 residuals and losses",
                "parameter_tensors": len(parameters),
                "trainable_parameters": sum(p.numel() for p in parameters),
                "wall_seconds": time.monotonic() - started,
            })


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("prepare", "run"))
    p.add_argument("--limit", type=int)
    options = p.parse_args()
    if options.action == "prepare":
        prepare()
    else:
        run(options.limit)
