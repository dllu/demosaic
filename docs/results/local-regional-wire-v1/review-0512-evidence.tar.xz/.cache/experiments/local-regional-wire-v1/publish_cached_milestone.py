"""Publish the verified intermediate EMA review with unchanged native pixels."""

import argparse
from collections import Counter
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, REPO, ROOT
from views_milestone import cells, GLOBAL, PARENT, REGIONAL
from review_milestone_cached import saved_local_outputs


def publish(step):
    tag = f"step-{step:04d}"
    run = ARCHIVE / f"review-{step:04d}"
    receipts = {k: reference(run / filename) for k, filename in (
        ("review", "result.json"), ("offgrid", "offgrid.json"), ("viewing", "views.json"),
        ("cab", "cab-peaks.json"),
    )}
    proof = reference(ROOT / f"checkpoint-{step:04d}-verified.json")
    identities = read_json(checked(proof))
    review, offgrid, viewing, cab = [read_json(checked(r)) for r in receipts.values()]
    assert cab["step"] == step and cab["review"] == receipts["review"]
    assert identities["matched_snapshot"] == review["checkpoint_pair"]
    assert offgrid["review"] == viewing["review"] == receipts["review"]
    assert viewing["offgrid"] == receipts["offgrid"] and step == review["step"]
    snapshots = read_json(checked(review["checkpoint_pair"]))
    plan = read_json(checked(snapshots["plan"]))
    assert review["review_inputs"] == plan["review_inputs"]
    assert review["checkpoints"] == snapshots["arms"] | {"local50k": plan["parent"]}
    previous = read_json(checked(review["reused_parent"]))
    assert previous["review_inputs"] == review["review_inputs"]
    assert previous["checkpoints"]["local50k"] == plan["parent"]
    assert saved_local_outputs(previous) == saved_local_outputs(review)
    assert review["parent_outputs_reused"] == len(saved_local_outputs(review))
    for source in viewing["view_sheets"].values():
        checked(source)

    schedule = read_json(checked(plan["schedule"]["train"]))
    assert len(schedule) == plan["steps"]
    launch_prefix = ROOT / f"verified-training-{step:04d}.jsonl"
    with (ARCHIVE / "train/observations.jsonl").open("rb") as live:
        prefix = [live.readline() for _ in range(step)]
    assert all(line.endswith(b"\n") for line in prefix)
    observed = [json.loads(line) for line in prefix]
    for i, (actual, case) in enumerate(zip(observed, schedule[:step], strict=True), 1):
        assert actual["index"] == i
        assert actual["source_id"] == case["source"]["id"]
        assert actual["cache_sha256"] == case["source"]["cache_sha256"]
    launch_prefix.write_bytes(b"".join(prefix))
    timing_prefix = ROOT / f"verified-training-{step:04d}-timing.log"
    timing_lines = []
    with (ROOT / "training.log").open("rb") as live:
        for line in live:
            timing_lines.append(line)
            if line.startswith(f"{step} ".encode()):
                break
    assert timing_lines[-1].startswith(f"{step} ".encode())
    training_wall_seconds = float(timing_lines[-1].split(maxsplit=2)[1])
    timing_prefix.write_bytes(b"".join(timing_lines))
    scores = review["exact"]
    assert len(scores["photo"]["rows"]) == len(scores["wire"]["rows"]) == 24
    assert len(offgrid["rows"]) == 32
    used = {a["source_id"] for a in observed}
    assert used.isdisjoint(r["case"]["source"]["source"]["id"]
                           for section in scores.values() for r in section["rows"])
    assert used.isdisjoint(r["case"]["source"]["id"] for r in offgrid["rows"])

    base = REPO / "docs/images" / ROOT.name / tag
    base.mkdir(parents=True)
    for name in ("exact", "standing"):
        (base / name).mkdir()

    def copy(source, kind=""):
        original = checked(source)
        target = base / kind / original.name
        shutil.copyfile(original, target)
        assert reference(target)["sha256"] == source["sha256"]
        return source | {"path": str(target.relative_to(base))}

    def board(original, kind):
        return original | {"image": copy(original["image"], kind)}

    native = []
    for item in review["standing"]:
        exposure = {v["exposure"] for v in item["displays"]}
        mesh = item["id"].startswith("mesh")
        assert exposure == ({4, 16} if mesh else {4})
        subset = []
        for view in item["displays"]:
            shown = cells(view["board"])
            labels = {"Noisy (Malvar)", "V120 EMA", "Corpus 100k", PARENT, GLOBAL, REGIONAL,
                      "ISO100 AHD reference"}
            if mesh:
                labels |= {"ISO6400 camera JPEG", "ISO100 camera JPEG"}
            assert set(shown) == labels
            subset.append(view | {"board": board(view["board"], "standing")})
        native.append(item | {"displays": subset})
    assert len(native) == 8 and sum(len(r["displays"]) for r in native) == 12
    examples = []
    for item in review["exact_boards"]:
        all_cells, selected = (cells(item[k]) for k in ("board", "triplet"))
        assert list(selected) == ["Noisy Malvar", REGIONAL, "Exact GT"]
        for name, image in selected.items():
            np.testing.assert_array_equal(np.asarray(image), np.asarray(all_cells[name]))
        examples.append(item | {k: board(item[k], "exact") for k in ("board", "triplet")})
    assert len(examples) == 4
    manifest = base / "manifest.json"
    write_json(manifest, {
        "step": step, "weights": "EMA", "precision": review["precision"],
        "checkpoints": review["checkpoints"], "exact": examples, "standing": native,
        "figure": copy(viewing["figure"]), "reviewed": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "viewing": receipts["viewing"], "review_scope": "Intermediate matched checkpoints.",
    })

    root = REPO / "docs/results" / ROOT.name
    archive = root / f"review-{step:04d}-evidence.tar.xz"
    evidence = [*receipts.values(), proof, review["checkpoint_pair"], review["review_inputs"],
                reference(launch_prefix), reference(timing_prefix), reference(manifest), reference(__file__),
                *[r["driver"] for r in (review, offgrid, viewing, cab, identities)],
                review["reused_parent"],
                reference(ROOT / "review_regional.py"), reference(ROOT / "score_offgrid.py")]
    ext = Path("/mnt/external/demosaic")
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for entry in {v["path"]: v for v in evidence}.values():
            path = checked(entry)
            name = (path.relative_to(REPO) if path.is_relative_to(REPO)
                    else Path("external") / path.relative_to(ext)).as_posix()
            tar.add(path, arcname=name)
            members[name] = entry["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(k).read()).hexdigest() == v for k, v in members.items())
    write_json(root / f"review-{step:04d}.json", {
        "scope": "Matched intermediate EMA review. The training endpoint is evaluated separately.",
        "step_per_arm": step, "training_case_counts": dict(Counter(i["kind"] for i in observed)),
        "checkpoints": review["checkpoints"], "weights": review["weights"], "precision": review["precision"],
        "native_observations_per_arm": step * len(plan["members"]),
        "training_wall_seconds_interleaved": training_wall_seconds,
        "fixed_exact": {k: v["scores"] for k, v in scores.items()},
        "offgrid": offgrid["subsets"], "standing_cab_peaks": cab["rows"],
        "receipts": receipts, "manifest": reference(manifest),
        "scope_review_wall_seconds": review["wall_seconds"],
        "parent_outputs_reused": review["parent_outputs_reused"],
        "archive": reference(archive), "members": members,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    publish(parser.parse_args().step)
