"""Publish the verified final EMA pair and its fixed scoped native review."""

import argparse
from collections import Counter
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, REPO, ROOT
from views_milestone import cells, GLOBAL, PARENT, REGIONAL
from review_milestone_cached import saved_local_outputs


def publish(step):
    completion_proof = reference(ROOT / "endpoint-training-verified.json")
    verified = read_json(checked(completion_proof))
    training = read_json(checked(verified["completion"]))
    assert training["completed_schedule"] and training["DINO_unchanged"]
    assert step == training["step"] == training["updates_per_arm"]
    tag = f"step-{step:04d}"
    run = ARCHIVE / f"review-{step:04d}"
    receipts = {k: reference(run / filename) for k, filename in (
        ("review", "result.json"), ("offgrid", "offgrid.json"), ("viewing", "views.json"),
        ("cab", "cab-peaks.json"), ("doses", "doses.json"),
    )}
    proof = reference(ROOT / f"checkpoint-{step:04d}-verified.json")
    assert proof == verified["verified_checkpoint_pair"]
    identities = read_json(checked(proof))
    review, offgrid, viewing, cab, doses = [read_json(checked(r)) for r in receipts.values()]
    assert cab["step"] == step and cab["review"] == receipts["review"]
    assert doses["step"] == step and doses["offgrid"] == receipts["offgrid"]
    dose_plot = reference(run / "wire-dose-curve.png")
    assert identities["matched_snapshot"] == review["checkpoint_pair"]
    assert offgrid["review"] == viewing["review"] == receipts["review"]
    assert viewing["offgrid"] == receipts["offgrid"] and step == review["step"]
    snapshots = read_json(checked(review["checkpoint_pair"]))
    plan = read_json(checked(snapshots["plan"]))
    assert step == plan["steps"] and snapshots["arms"] == training["checkpoints"]
    assert review["review_inputs"] == plan["review_inputs"]
    assert review["checkpoints"] == snapshots["arms"] | {"local50k": plan["parent"]}
    previous = read_json(checked(review["reused_parent"]))
    assert previous["review_inputs"] == review["review_inputs"]
    assert previous["checkpoints"]["local50k"] == plan["parent"]
    assert saved_local_outputs(previous) == saved_local_outputs(review)
    assert review["parent_outputs_reused"] == len(saved_local_outputs(review))
    for source in viewing["view_sheets"].values():
        checked(source)

    schedule = read_json(checked(plan["schedule"]["train"]))
    assert len(schedule) == plan["steps"]
    launch_prefix = ROOT / f"verified-training-{step:04d}.jsonl"
    with (ARCHIVE / "train/observations.jsonl").open("rb") as live:
        prefix = [live.readline() for _ in range(step)]
    assert all(line.endswith(b"\n") for line in prefix)
    observed = [json.loads(line) for line in prefix]
    for i, (actual, case) in enumerate(zip(observed, schedule[:step], strict=True), 1):
        assert actual["index"] == i
        assert actual["source_id"] == case["source"]["id"]
        assert actual["cache_sha256"] == case["source"]["cache_sha256"]
    launch_prefix.write_bytes(b"".join(prefix))
    timing_prefix = ROOT / f"verified-training-{step:04d}-timing.log"
    timing_lines = []
    with (ROOT / "training.log").open("rb") as live:
        for line in live:
            timing_lines.append(line)
            if line.startswith(f"{step} ".encode()):
                break
    assert timing_lines[-1].startswith(f"{step} ".encode())
    training_wall_seconds = training["training_wall_seconds_including_checkpoint"]
    timing_prefix.write_bytes(b"".join(timing_lines))
    scores = review["exact"]
    assert len(scores["photo"]["rows"]) == len(scores["wire"]["rows"]) == 24
    assert len(offgrid["rows"]) == 32
    used = {a["source_id"] for a in observed}
    assert used.isdisjoint(r["case"]["source"]["source"]["id"]
                           for section in scores.values() for r in section["rows"])
    assert used.isdisjoint(r["case"]["source"]["id"] for r in offgrid["rows"])

    base = REPO / "docs/images" / ROOT.name / tag
    base.mkdir(parents=True)
    for name in ("exact", "standing"):
        (base / name).mkdir()

    def copy(source, kind=""):
        original = checked(source)
        target = base / kind / original.name
        shutil.copyfile(original, target)
        assert reference(target)["sha256"] == source["sha256"]
        return source | {"path": str(target.relative_to(base))}

    def board(original, kind):
        return original | {"image": copy(original["image"], kind)}

    native = []
    for item in review["standing"]:
        exposure = {v["exposure"] for v in item["displays"]}
        mesh = item["id"].startswith("mesh")
        assert exposure == ({4, 16} if mesh else {4})
        subset = []
        for view in item["displays"]:
            shown = cells(view["board"])
            labels = {"Noisy (Malvar)", "V120 EMA", "Corpus 100k", PARENT, GLOBAL, REGIONAL,
                      "ISO100 AHD reference"}
            if mesh:
                labels |= {"ISO6400 camera JPEG", "ISO100 camera JPEG"}
            assert set(shown) == labels
            subset.append(view | {"board": board(view["board"], "standing")})
        native.append(item | {"displays": subset})
    assert len(native) == 8 and sum(len(r["displays"]) for r in native) == 12
    examples = []
    for item in review["exact_boards"]:
        all_cells, selected = (cells(item[k]) for k in ("board", "triplet"))
        assert list(selected) == ["Noisy Malvar", REGIONAL, "Exact GT"]
        for name, image in selected.items():
            np.testing.assert_array_equal(np.asarray(image), np.asarray(all_cells[name]))
        examples.append(item | {k: board(item[k], "exact") for k in ("board", "triplet")})
    assert len(examples) == 4
    manifest = base / "manifest.json"
    write_json(manifest, {
        "step": step, "weights": "EMA", "precision": review["precision"],
        "checkpoints": review["checkpoints"], "exact": examples, "standing": native,
        "figure": copy(viewing["figure"]), "dose_figure": copy(dose_plot),
        "reviewed": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "viewing": receipts["viewing"], "review_scope": "Completed matched EMA endpoints.",
    })

    root = REPO / "docs/results" / ROOT.name
    archive = root / f"review-{step:04d}-evidence.tar.xz"
    evidence = [*receipts.values(), proof, review["checkpoint_pair"], review["review_inputs"],
                reference(launch_prefix), reference(timing_prefix), reference(manifest), reference(__file__),
                *[r["driver"] for r in (review, offgrid, viewing, cab, doses, identities)],
                review["reused_parent"], completion_proof, verified["completion"],
                verified["driver"], training["log"], training["plan"],
                reference(ROOT / "plot_endpoint_doses.py"), training["trace"],
                reference(ROOT / "review_regional.py"), reference(ROOT / "score_offgrid.py")]
    ext = Path("/mnt/external/demosaic")
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for entry in {v["path"]: v for v in evidence}.values():
            path = checked(entry)
            name = (path.relative_to(REPO) if path.is_relative_to(REPO)
                    else Path("external") / path.relative_to(ext)).as_posix()
            tar.add(path, arcname=name)
            members[name] = entry["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(k).read()).hexdigest() == v for k, v in members.items())
    write_json(root / f"review-{step:04d}.json", {
        "scope": "Final matched EMA scoped review. Fixed photo and camera panels have independent receipts.",
        "step_per_arm": step, "training_case_counts": dict(Counter(i["kind"] for i in observed)),
        "checkpoints": review["checkpoints"], "weights": review["weights"], "precision": review["precision"],
        "native_observations_per_arm": step * len(plan["members"]),
        "training_wall_seconds_interleaved": training_wall_seconds,
        "training": verified["completion"], "training_audit": completion_proof,
        "fixed_exact": {k: v["scores"] for k, v in scores.items()},
        "offgrid": offgrid["subsets"], "standing_cab_peaks": cab["rows"],
        "calibrated_offgrid_doses": doses["calibrated_at_common_response"],
        "calibrated_offgrid_comparison": doses["confirmation_at_calibrated_doses"],
        "receipts": receipts, "manifest": reference(manifest),
        "scope_review_wall_seconds": review["wall_seconds"],
        "parent_outputs_reused": review["parent_outputs_reused"],
        "archive": reference(archive), "members": members,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    publish(parser.parse_args().step)
