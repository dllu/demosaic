"""Verify final training rows, checkpoint identities and frozen review exclusions."""

from collections import Counter
import json
import math

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, ROOT, lr_at


def rows(binding):
    with checked(binding).open() as stream:
        return [json.loads(line) for line in stream]


def source_ids(sources):
    return {row["id"] for row in sources}, {row["cache_sha256"] for row in sources}


def main():
    torch.set_num_threads(2)
    completion = reference(ARCHIVE / "train/completed.json")
    result = read_json(checked(completion))
    plan = read_json(checked(result["plan"]))
    count = plan["steps"]
    assert result["start"] == 0 and result["step"] == result["updates_per_arm"] == count == 1024
    assert result["completed_schedule"] and not result["qualification"] and result["DINO_unchanged"]
    assert result["parent"] == plan["parent"]
    assert result["native_observations_per_arm"] == count * len(plan["members"]) == 6144
    scheduled = read_json(checked(plan["schedule"]["train"]))
    observed, logged = (rows(result[k]) for k in ("trace", "log"))
    assert len(scheduled) == len(observed) == len(logged) == count
    seen = Counter()
    for index, (wanted, actual, log) in enumerate(zip(scheduled, observed, logged, strict=True), 1):
        assert actual["index"] == log["step"] == index
        assert (actual["source_id"], actual["cache_sha256"]) == (
            wanted["source"]["id"], wanted["source"]["cache_sha256"],
        )
        assert all(actual[k] == wanted[k] for k in ("kind", "iso", "law"))
        assert actual["camera"]["pattern"] == wanted["pattern"]
        assert log["lr"] == lr_at(index, plan)
        assert all(math.isfinite(value) for arm in ARMS for value in log[arm].values())
        kind = actual["kind"]
        seen[kind] += 1
        if kind == "wire":
            active = actual["geometry"]["wire"]["strong_continues"]
            assert active == wanted["strong_continues"]
            seen["strong_continues" if active else "double_gap"] += 1
    assert all(result["seen"][k] == v for k, v in seen.items())
    assert dict(seen) == {"natural": 512, "wire": 512, "strong_continues": 400, "double_gap": 112}
    assert len({row["source_id"] for row in observed}) == count
    assert len({row["cache_sha256"] for row in observed}) == count

    fixtures = read_json(checked(plan["review_inputs"]))
    transfer = read_json(checked(fixtures["transfer"]))
    held = [r["source"]["source"] for panel in fixtures["exact"].values() for r in panel]
    held += [r["source"] for r in transfer["rows"]]
    ids, hashes = source_ids(held)
    assert all(r["source_id"] not in ids and r["cache_sha256"] not in hashes for r in observed)
    audit = reference(ARCHIVE / "gradient-audit/result.json")
    probes = read_json(checked(audit))
    for item in probes["samples"]:
        audit_row = read_json(checked(item))
        assert observed[audit_row["index"] - 1] == audit_row["observation"]

    saved = reference(ROOT / "checkpoint-1024-verified.json")
    check = read_json(checked(saved))
    pair = read_json(checked(check["matched_snapshot"]))
    assert result["checkpoints"] == pair["arms"]
    assert check["step"] == pair["step"] == count
    for key, info in check["arms"].items():
        assert info["checkpoint"] == result["checkpoints"][key]
        path = checked(info["checkpoint"])
        model = torch.load(path, map_location="cpu", weights_only=True, mmap=True)
        tensors = tuple(model["model"].values()) + tuple(model["ema"].values())
        moments = [m[k] for m in model["optimizer"]["state"].values()
                   for k in ("exp_avg", "exp_avg_sq")]
        assert all(torch.isfinite(t).all() for t in (*tensors, *moments))

    write_json(ROOT / "endpoint-training-verified.json", {
        "driver": reference(__file__), "completion": completion, "verified_checkpoint_pair": saved,
        "gradient_audit": audit, "matched_gradient_observations": len(probes["samples"]),
        "scoped_review_overlap": 0, "finite_training_updates_per_arm": count,
        "matched_distinct_photo_count": count, "counts": dict(seen),
    })
    print("Verified all 1,024 observations, both final EMA/raw/Adam states and review disjointness", flush=True)


if __name__ == "__main__":
    main()
