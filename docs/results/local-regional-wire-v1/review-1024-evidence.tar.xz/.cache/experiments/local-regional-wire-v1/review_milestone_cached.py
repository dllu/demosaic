"""Review matched EMA checkpoints using the verified unchanged Local 50k outputs."""

import argparse
import time

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint
import review_regional as review


def saved_local_outputs(record):
    output = {}
    for category, rows in record["exact"].items():
        for row in rows["rows"]:
            output[f'{category}-{row["case"]["source"]["index"]:02}'] = row["predictions"]["local50k"]
    for row in record["standing"]:
        binding = row["predictions"]["local50k"]
        # Prediction is shared across ROIs only when the input hash and profile match.
        tag = binding["path"].split("/")[-1].removesuffix("-local50k.npy")
        assert tag == row["id"] or row["id"].startswith("mesh")
        assert tag not in output or output[tag] == binding
        output[tag] = binding
    for row in record["offgrid_predictions"]:
        output[f'offgrid-{row["case"]["id"]}'] = row["predictions"]["local50k"]
    assert len(output) >= 86
    for binding in output.values():
        checked(binding)
    return output


@torch.inference_mode()
def main(step, prior_step):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    device = torch.device("cuda:0")
    capacity = torch.cuda.get_device_properties(device).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, 11 * 2**30 / capacity), device)
    archive, arms = review.ARCHIVE, review.ARMS
    snapshot = reference(archive / "train" / f"step-{step:04d}" / "checkpoint.json")
    frozen = read_json(checked(snapshot))
    plan = read_json(checked(frozen["plan"]))
    assert prior_step < step <= plan["steps"] and frozen["step"] == step and tuple(frozen["arms"]) == arms
    fixtures = read_json(checked(plan["review_inputs"]))
    parent_review = reference(archive / f"review-{prior_step:04d}" / "result.json")
    before = read_json(checked(parent_review))
    assert before["review_inputs"] == plan["review_inputs"] and before["step"] == prior_step
    assert before["precision"] == "CUDA IEEE FP32" and before["weights"] == "EMA"
    assert before["checkpoints"]["local50k"] == plan["parent"]
    assert fixtures["training_source_schedule"] == plan["schedule"]
    old = saved_local_outputs(before)
    original = review.predict
    used = set()

    def predict(models, data, profile, dest, name):
        assert name in old and name not in used
        prediction, elapsed = original(models, data, profile, dest, name)
        used.add(name)
        return prediction | {"local50k": old[name]}, elapsed | {"local50k": 0.0}

    models = {}
    for label, binding in frozen["arms"].items():
        model, metadata = load_scene_checkpoint(
            checked(binding), expected_sha256=binding["sha256"], weights="ema",
        )
        assert metadata["mode"] == "none" and metadata["DINO_sha256"] == plan["DINO_sha256"]
        assert metadata["step"] == step and metadata["training_arm"] == label
        assert metadata["plan"] == frozen["plan"]
        models[label] = _stage_tiled_cuda(model, device)
        del metadata
    root = archive / f"review-{step:04d}"
    root.mkdir()
    dirs = {v: root / v for v in ("predictions", "exact", "standing")}
    for folder in dirs.values():
        folder.mkdir()
    started = time.monotonic()
    # Reuse the frozen metric and rendering functions with one verified predictor.
    review.predict = predict
    try:
        scores = review.exact(models, fixtures["exact"], dirs["predictions"])
        boxes = review.chosen_crops(scores, dirs["exact"])
        cameras = review.standing(models, fixtures["standing"], dirs["predictions"], dirs["standing"])
        transfer = review.capture_offgrid(models, fixtures["transfer"], dirs["predictions"])
    finally:
        review.predict = original
    assert used == set(old)
    write_json(root / "result.json", {
        "driver": reference(__file__), "checkpoint_pair": snapshot, "step": step,
        "review_inputs": plan["review_inputs"], "weights": "EMA", "precision": "CUDA IEEE FP32",
        "checkpoints": frozen["arms"] | {"local50k": plan["parent"]},
        "exact": scores, "exact_boards": boxes, "standing": cameras,
        "offgrid_predictions": transfer, "wall_seconds": time.monotonic() - started,
        "reused_parent": parent_review, "parent_outputs_reused": len(used),
    })
    print("Saved milestone native review", root, flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("step", type=int)
    p.add_argument("--prior-step", type=int, default=128)
    args = p.parse_args()
    main(args.step, args.prior_step)
