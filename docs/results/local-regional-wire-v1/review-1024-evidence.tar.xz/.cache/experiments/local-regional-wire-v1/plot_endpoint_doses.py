"""Plot the response and false-detail sweep on the reserved cases."""

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import read_json


def main(source):
    record = read_json(source)
    fields = (
        ("exact_flat_RMS_DN16", "Exact-flat error", "DN16 RMS"),
        ("fundamental_false_RMS_DN16", "False weak direction in gap", "DN16 RMS"),
    )
    response = "fundamental_response"
    curves = (("global-aligned", "Whole-core supervision", "#2b6092"),
              ("regional-aligned", "Regional supervision", "#a55b35"))
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 3.65), layout="constrained")
    fig.suptitle(f"Weak-wire recovery as endpoint strength varies at {record['step']:,} updates")
    for axis, (field, title, units) in zip(axes, fields, strict=True):
        for arm, name, color in curves:
            samples = record["confirmation_sweep"][arm]
            axis.plot([r[field] for r in samples], [r[response] for r in samples],
                      label=name, color=color, linewidth=1.7)
            end = samples[-1]
            axis.scatter(end[field], end[response], marker="s", color=color, s=28, zorder=3)
            fit = record["confirmation_at_calibrated_doses"]
            if fit is not None:
                axis.scatter(fit[field]["arms"][arm], fit[response]["arms"][arm],
                             marker="o", facecolor="white", edgecolor=color, linewidth=1.6, zorder=4)
        axis.set_title(title)
        axis.set_xlabel(units)
        axis.set_ylabel("Signed weak response (%)")
        axis.grid(alpha=.22)
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(source.with_name("wire-dose-curve.png"), dpi=155, facecolor="white")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("scores", type=Path)
    main(p.parse_args().scores)
