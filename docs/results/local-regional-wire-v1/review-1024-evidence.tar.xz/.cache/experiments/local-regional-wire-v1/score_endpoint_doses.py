"""Compare endpoint corrections at a common calibrated weak-wire response."""

import argparse
from hashlib import sha256

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_offgrid import ARCHIVE, ARMS, WireFundamental
from evaluate_wide import values

RESPONSE = "fundamental_response"
FLAT = "exact_flat_RMS_DN16"
FALSE = "fundamental_false_RMS_DN16"
STRONG = "gap_continuing_strong_RMS_DN16"
FIELDS = (RESPONSE, FLAT, FALSE, STRONG)
SEED = "regional-doses-20261119"


def measure(row):
    case = row["case"]
    with np.load(checked(case["input"]), allow_pickle=False) as target:
        operator = WireFundamental(
            {k: target[k] for k in ("wb", "matrix", "target", "support")},
            case["fixture"]["geometry"],
        )
    parents = row["predictions"]
    native = np.load(checked(parents["local50k"]), allow_pickle=False).astype(np.float64)
    original = operator(native)
    basis = {}
    for arm in ARMS:
        estimate = np.load(checked(parents[arm]), allow_pickle=False).astype(np.float64)
        delta = estimate - native
        plus, minus = operator(native + delta), operator(native - delta)
        fields = [k for k in FIELDS if k in original]
        basis[arm] = {
            k: (
                [original[k], (plus[k] - minus[k]) / 2]
                if k == RESPONSE
                else [
                    original[k] ** 2,
                    (plus[k] ** 2 - minus[k] ** 2) / 2,
                    (plus[k] ** 2 + minus[k] ** 2) / 2 - original[k] ** 2,
                ]
            ) for k in fields
        }
        dose = 0.37
        direct = operator(native + dose * delta)
        record = [{"terms": {arm: basis[arm]}}]
        for k in fields:
            np.testing.assert_allclose(values(record, arm, k, dose)[0], direct[k], atol=1e-9, rtol=1e-9)
            np.testing.assert_allclose(plus[k], row["scores"][arm][k], atol=.002, rtol=1e-6)
    return {"id": case["source"]["id"], "terms": basis, "true_gap": FALSE in original}


def score(rows, arm, field, dose):
    eligible = [r for r in rows if field in r["terms"][arm]]
    assert eligible
    return values(eligible, arm, field, dose)


def calibrated(calibration):
    full = [float(score(calibration, arm, RESPONSE, 1).mean()) for arm in ARMS]
    origin = float(score(calibration, ARMS[0], RESPONSE, 0).mean())
    low = max(min(origin, end) for end in full)
    high = min(max(origin, end) for end in full)
    limit = max((low, high), key=lambda v: abs(v - origin))
    target = (limit + origin) / 2
    if abs(target - origin) < 1e-6:
        return None
    gains = {arm: (target - origin) / (end - origin) for arm, end in zip(ARMS, full, strict=True)}
    assert all(0 < g <= 1 for g in gains.values())
    assert all(abs(float(score(calibration, arm, RESPONSE, gains[arm]).mean()) - target) < 1e-8
               for arm in gains)
    return {"target_percent": target, "doses": gains, "local_response": origin}


def comparisons(rows, doses):
    rng = np.random.default_rng(202611192313)
    output = {}
    for field in FIELDS:
        measured = [score(rows, arm, field, doses[arm]) for arm in ARMS]
        difference = measured[1] - measured[0]
        count = len(difference)
        samples = difference[rng.integers(0, count, (8000, count))].mean(axis=1)
        output[field] = {
            "n": count, "arms": {arm: float(data.mean()) for arm, data in zip(ARMS, measured, strict=True)},
            "regional_minus_whole": float(difference.mean()), "paired_95_percent": np.quantile(samples, (.025, .975)).tolist(),
        }
    return output


def main(step):
    directory = ARCHIVE / f"review-{step:04d}"
    source = reference(directory / "offgrid.json")
    rows = [measure(r) for r in read_json(checked(source))["rows"]]
    assert len(rows) == len({r["id"] for r in rows}) == 32
    calibration, confirmation = [], []
    for gap in (False, True):
        ranked = sorted((r for r in rows if r["true_gap"] == gap),
                        key=lambda r: sha256((SEED + r["id"]).encode()).hexdigest())
        assert len(ranked) == 16
        calibration += ranked[:8]
        confirmation += ranked[8:]
    fitted = calibrated(calibration)
    doses = np.linspace(0, 1, 21)
    sweep = {
        arm: [{"dose": float(t), **{f: float(score(confirmation, arm, f, t).mean()) for f in FIELDS}}
              for t in doses] for arm in ARMS
    }
    result = {
        "driver": reference(__file__), "offgrid": source, "step": step, "split_seed": SEED,
        "calibration": [r["id"] for r in calibration], "confirmation": [r["id"] for r in confirmation],
        "calibrated_at_common_response": fitted,
        "confirmation_at_calibrated_doses": comparisons(confirmation, fitted["doses"]) if fitted else None,
        "confirmation_at_full_dose": comparisons(confirmation, dict.fromkeys(ARMS, 1)),
        "confirmation_sweep": sweep, "per_photo": rows,
    }
    write_json(directory / "doses.json", result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    main(parser.parse_args().step)
