"""Arrange native crops without resizing and plot the checkpoint-pair differences."""

import argparse
import os

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_regional import ARCHIVE, ARMS, GLOBAL, PARENT, REGIONAL


def cells(board):
    with Image.open(checked(board["image"])) as source:
        rgb = source.convert("RGB")
    output = {}
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert (w, h) == (160, 160) and x + w <= rgb.width and y + h <= rgb.height
        name = panel.get("label", panel.get("name"))
        assert name not in output
        output[name] = rgb.crop((x, y, x + w, y + h))
    return output


def sheet(path, rows, labels):
    result = Image.new("RGB", (8 + 168 * len(labels), 28 + 184 * len(rows)), "#ebebeb")
    draw = ImageDraw.Draw(result)
    for col, label in enumerate(labels):
        draw.text((8 + 168 * col, 6), label, fill="#121212")
    for i, (tag, board) in enumerate(rows):
        item = cells(board)
        for j, label in enumerate(labels):
            tile = item[label]
            assert tile.size == (160, 160)
            result.paste(tile, (8 + 168 * j, 28 + 184 * i))
        draw.text((8, 190 + 184 * i), tag, fill="#111111")
    result.save(path)
    return reference(path)


def figure(path, results, offgrid):
    os.environ["MPLCONFIGDIR"] = str(path.parent / "matplotlib")
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    settings = (
        ("Weak-wire response", "Percentage points",
         "weak_response_pp", "fundamental_response"),
        ("Continuing-wire error", "DN16 RMS",
         "gap_continuing_strong_RMS_DN16", "gap_continuing_strong_RMS_DN16"),
        ("False weak-direction error", "DN16 RMS",
         "gap_weak_RMS_DN16", "fundamental_false_RMS_DN16"),
        ("Exact-flat error", "DN16 RMS",
         "exact_flat_RMS_DN16", "exact_flat_RMS_DN16"),
    )
    tests = results["exact"]["wire"]["scores"]
    fig, panels = plt.subplots(2, 2, figsize=(8.7, 4.5), layout="constrained")
    labels = ("Fixed wires", "Off-grid transfer")
    for axis, (title, units, fixed, transfer) in zip(panels.flat, settings, strict=True):
        fixed_delta = tests[fixed]["methods"][REGIONAL][GLOBAL]
        entry = offgrid["subsets"]["all"][transfer]["models"][ARMS[1]]["versus"][ARMS[0]]
        comparison = (fixed_delta, [entry["delta"], *entry["95_percent"]])
        middle, low, high = np.asarray(comparison).T
        axis.axvline(0, color="#666666", linewidth=.9)
        axis.errorbar(middle, (0, 1), xerr=(middle - low, high - middle),
                      fmt="o", color="#28646c", ms=4, capsize=3)
        axis.set_title(title)
        axis.set_xlabel(units)
        axis.set_yticks((0, 1), labels)
        axis.set_ylim(1.46, -.46)
        axis.grid(axis="x", alpha=.2)
    fig.suptitle(f"Regional minus whole-core supervision at {results['step']} updates")
    fig.savefig(path, dpi=155, facecolor="white")
    return reference(path)


def main(step):
    root = ARCHIVE / f"review-{step:04d}"
    source, transfer = (reference(root / p) for p in ("result.json", "offgrid.json"))
    results, offgrid = (read_json(checked(r)) for r in (source, transfer))
    assert offgrid["review"] == source and results["step"] == step
    output = root / "viewing"
    output.mkdir()
    views = {}
    for scope, exposure in (("main", 4), ("mesh", 4), ("mesh", 16)):
        rows = [(r["id"], d["board"]) for r in results["standing"] if r["id"].startswith(scope)
                for d in r["displays"] if d["exposure"] == exposure]
        assert len(rows) == 4
        labels = ("Noisy (Malvar)", PARENT, GLOBAL, REGIONAL, "ISO100 AHD reference")
        tag = f"{scope}-x{exposure}"
        views[tag] = sheet(output / f"{tag}.png", rows, labels)
        controls = ("V120 EMA", "Corpus 100k")
        if scope == "mesh":
            controls += ("ISO6400 camera JPEG", "ISO100 camera JPEG")
        views[tag+"-controls"] = sheet(output / f"{tag}-controls.png", rows, controls)
    views["exact"] = sheet(output / "exact.png", [(r["id"], r["board"]) for r in results["exact_boards"]],
                           ("Noisy Malvar", "V120", "Corpus 100k", PARENT, GLOBAL, REGIONAL, "Exact GT"))
    graph = figure(output / "wire-paired-effects.png", results, offgrid)
    write_json(root / "views.json", {
        "driver": reference(__file__), "review": source, "offgrid": transfer,
        "view_sheets": views, "figure": graph,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    main(parser.parse_args().step)
