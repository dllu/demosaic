"""Verify the first saved matched checkpoint can restore both optimizer states."""

import sys
from pathlib import Path

import torch

from train_regional import ARMS, ARCHIVE, ROOT, lr_at
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    step = int(sys.argv[1])
    plans = reference(ROOT / "plan-v3.json")
    plan = read_json(checked(plans))
    proof = reference(ARCHIVE / f"train/step-{step:04d}/checkpoint.json")
    result = read_json(checked(proof))
    assert result["step"] == step and result["plan"] == plans
    records = {}
    for arm in ARMS:
        ref = result["arms"][arm]
        source = checked(ref)
        state = torch.load(source, weights_only=True, map_location="cpu", mmap=True)
        assert state["step"] == step and state["plan"] == plans and state["training_arm"] == arm
        assert state["continued_from"] == plan["parent"] and state["mode"] == "none"
        assert state["DINO_sha256"] == plan["DINO_sha256"]
        assert set(state["ema"]) == set(state["model"]) and len(state["ema"]) > 0
        assert all(a.shape == state["ema"][k].shape for k, a in state["model"].items())
        optimizer = state["optimizer"]
        assert all(g["lr"] == lr_at(step, plan) for g in optimizer["param_groups"])
        steps = [int(s["step"]) for s in optimizer["state"].values()]
        assert steps and max(steps) == step
        records[arm] = {"checkpoint": ref, "file_bytes": Path(source).stat().st_size,
                        "optimizer_entries": len(steps), "maximum_adam_step": max(steps),
                        "restoration_tensors": len(state["ema"])}
    write_json(ROOT / f"checkpoint-{step:04d}-verified.json", {
        "driver": reference(__file__), "plan": plans, "matched_snapshot": proof,
        "arms": records, "step": step, "next_lr": lr_at(step + 1, plan),
    })
    print("Verified raw, EMA and optimizer state in both checkpoints", step)


if __name__ == "__main__":
    main()
