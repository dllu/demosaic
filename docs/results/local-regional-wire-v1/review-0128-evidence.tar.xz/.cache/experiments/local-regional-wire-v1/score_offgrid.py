"""Score the matched regional models on the independent off-grid transfer."""

import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, CACHE

sys.path.insert(0, str(CACHE / "scene-staggered-phase-v1"))
from score_staggered import WireFundamental


def main():
    binding = reference(ARCHIVE / "review/result.json")
    review = read_json(checked(binding))
    rows = []
    for r in review["offgrid_predictions"]:
        case = r["case"]
        with np.load(checked(case["input"]), allow_pickle=False) as src:
            measurement = WireFundamental(
                {k: src[k] for k in ("wb", "matrix", "target", "support")},
                case["fixture"]["geometry"],
            )
        with np.load(checked(case["rgb"]), allow_pickle=False) as original:
            scores = {"V120": measurement(original["v120"]), "Corpus 100k": measurement(original["parent"])}
        scores.update({key: measurement(np.load(checked(ref), allow_pickle=False))
                       for key, ref in r["predictions"].items()})
        rows.append(r | {"scores": scores})
    assert len(rows) == 32
    summary = {}
    rng = np.random.default_rng(202611192224)
    keys = tuple(rows[0]["scores"])
    for metric in sorted(set.union(*(set(row["scores"][ARMS[0]]) for row in rows))):
        eligible = [r for r in rows if metric in r["scores"][ARMS[0]]]
        n = len(eligible)
        sample = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
        means = {k: np.array([r["scores"][k][metric] for r in eligible])[sample].mean(1) for k in keys}
        outputs = {}
        for k, measured in means.items():
            outputs[k] = {"value": float(measured[0])}
            for control in (ARMS[0], "local50k", "Corpus 100k", "V120"):
                delta = measured - means[control]
                outputs[k][control] = [float(delta[0]), *np.quantile(delta[1:], (.025, .975)).tolist()]
        summary[metric] = {"count": n, "modes": outputs}
    write_json(ARCHIVE / "review/offgrid.json", {
        "review": binding, "driver": reference(__file__), "rows": rows, "summary": summary,
    })


if __name__ == "__main__":
    main()
