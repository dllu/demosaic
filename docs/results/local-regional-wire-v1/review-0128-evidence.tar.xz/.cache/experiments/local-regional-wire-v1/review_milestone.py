"""Run the frozen scoped review on a complete intermediate checkpoint pair."""

import argparse
import time

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint
from review_regional import ARCHIVE, ARMS, capture_offgrid, chosen_crops, exact, standing


@torch.inference_mode()
def main(step):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    device = torch.device("cuda:0")
    capacity = torch.cuda.get_device_properties(device).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, 12 * 2**30 / capacity), device)
    snapshot = reference(ARCHIVE / "train" / f"step-{step:04d}" / "checkpoint.json")
    frozen = read_json(checked(snapshot))
    plan = read_json(checked(frozen["plan"]))
    assert 0 < step < plan["steps"] and frozen["step"] == step and tuple(frozen["arms"]) == ARMS
    fixtures = read_json(checked(plan["review_inputs"]))
    assert fixtures["training_source_schedule"] == plan["schedule"]
    checkpoints = frozen["arms"] | {"local50k": plan["parent"]}
    models = {}
    for label, binding in checkpoints.items():
        model, metadata = load_scene_checkpoint(
            checked(binding), expected_sha256=binding["sha256"], weights="ema"
        )
        assert metadata["mode"] == "none" and metadata["DINO_sha256"] == plan["DINO_sha256"]
        expect = plan["parent_update"] if label == "local50k" else step
        assert metadata["step"] == expect
        if label != "local50k":
            assert metadata["training_arm"] == label and metadata["plan"] == frozen["plan"]
        models[label] = _stage_tiled_cuda(model, device)
        del metadata
    root = ARCHIVE / f"review-{step:04d}"
    root.mkdir()
    dirs = {v: root / v for v in ("predictions", "exact", "standing")}
    for folder in dirs.values():
        folder.mkdir()
    started = time.monotonic()
    scores = exact(models, fixtures["exact"], dirs["predictions"])
    boxes = chosen_crops(scores, dirs["exact"])
    cameras = standing(models, fixtures["standing"], dirs["predictions"], dirs["standing"])
    transfer = capture_offgrid(models, fixtures["transfer"], dirs["predictions"])
    write_json(root / "result.json", {
        "driver": reference(__file__), "checkpoint_pair": snapshot, "step": step,
        "review_inputs": plan["review_inputs"], "weights": "EMA", "precision": "CUDA IEEE FP32",
        "checkpoints": checkpoints, "exact": scores, "exact_boards": boxes, "standing": cameras,
        "offgrid_predictions": transfer, "wall_seconds": time.monotonic() - started,
    })
    print("Saved milestone native review", root, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    main(parser.parse_args().step)
