"""Compare the trained local arms on frozen exact, off-grid and GFX inputs."""

import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.reporting import display_crop
from demosaic.scene_inference import load_scene_checkpoint
from train_regional import ARCHIVE, ARMS, CACHE, ROOT

sys.path[:0] = [str(CACHE / "local-redraw-average-v1"), "scripts"]
from review_redraw_average import KEYS, metrics, native_board, native_png, old_pixels, predict

PARENT = "Local 50k"
GLOBAL = "Whole-core supervision"
REGIONAL = "Regional supervision"
LABELS = {ARMS[0]: GLOBAL, ARMS[1]: REGIONAL, "local50k": PARENT}
PROFILE = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": .33}


def compare(records):
    names = tuple(records[0]["metrics"])
    rng = np.random.default_rng(202611192224)
    table = {}
    for metric in sorted(set().union(*(r["metrics"][REGIONAL] for r in records))):
        sample = [r["metrics"] for r in records if r["metrics"][REGIONAL].get(metric) is not None]
        n = len(sample)
        index = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
        stats = {key: np.asarray([row[key][metric] for row in sample])[index].mean(1) for key in names}
        result = {}
        for key, value in stats.items():
            result[key] = {"mean": float(value[0])}
            for control in (GLOBAL, PARENT, "V120", "Corpus 100k"):
                if control in stats:
                    d = value - stats[control]
                    result[key][control] = [float(d[0]), *np.quantile(d[1:], (.025, .975)).tolist()]
        table[metric] = {"sources": n, "methods": result}
    return table


def arrays(ref):
    with np.load(checked(ref), allow_pickle=False) as values:
        return {k: values[k] for k in values.files}


def exact(models, fixtures, dest):
    reports = {}
    for section, cases in fixtures.items():
        rows = []
        for case in cases:
            native = arrays(case["input"])
            name = f'{section}-{case["source"]["index"]:02}'
            predictions, times = predict(models, native, PROFILE, dest, name)
            former = arrays(case["model_outputs"])
            scores = {LABELS[k]: metrics(case, np.load(checked(r), allow_pickle=False), native)
                      for k, r in predictions.items()}
            scores.update({name: metrics(case, former[k], native) for name, k in (
                ("V120", "v120"), ("Corpus 100k", "parent"),
            )})
            rows.append({"case": case, "predictions": predictions, "forward": times, "metrics": scores})
        reports[section] = {"rows": rows, "scores": compare(rows)}
        print("Exact panel", section, len(rows), flush=True)
    return reports


def chosen_crops(reviews, dest):
    output = []
    groups = [("wire", "gap_weak_RMS_DN16"), ("photo", "fine_increment_RMS_DN16")]
    for group, objective in groups:
        eligible = [r for r in reviews[group]["rows"] if r["metrics"][REGIONAL].get(objective) is not None]

        def effect(row):
            return row["metrics"][REGIONAL][objective] - row["metrics"][GLOBAL][objective]

        chosen = (min(eligible, key=effect), max(eligible, key=effect))
        for case in chosen:
            item = case["case"]
            native = arrays(item["input"])
            camera = {k: native[k][None] for k in ("wb", "matrix", "colors")}
            noisy = noisy_malvar(camera | {"packed": native["packed"][:1]})[0]
            base = arrays(item["model_outputs"])
            frames = [noisy, base["v120"][0], base["parent"][0]]
            frames.extend(np.load(checked(case["predictions"][key]), allow_pickle=False)[0]
                          for key in ("local50k", *ARMS))
            frames.append(native["target"][0])
            name = f'{group}-{item["source"]["index"]:02}'
            output.append(native_board(
                dest, name, frames, camera,
                {"case": item, "predictions": case["predictions"], "noise": PROFILE,
                 "selection_metric": objective, "difference": effect(case)},
                labels=("Noisy Malvar", "V120", "Corpus 100k", PARENT, GLOBAL, REGIONAL, "Exact GT"),
                triplet_indices=(0, 5, 6), exposure=2, roi=(48, 48, 160, 160),
            ))
    return output


def standing(models, rows, stored, dest):
    results, memo = [], {}
    compare_labels = ("Noisy (Malvar)", "V120 EMA", "Corpus 100k")
    references = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
    for r in rows:
        s = arrays(r["input"])
        arguments = {k: s[k] for k in KEYS}
        arguments.update({k: s[k][0] for k in ("colors", "wb", "matrix")})
        key = (r["input"]["sha256"], r["noise"]["shot"], r["noise"]["read"])
        if key not in memo:
            memo[key] = predict(models, arguments, r["noise"], stored, r["id"])
        files, times = memo[key]
        prediction = {LABELS[k]: np.load(checked(v), allow_pickle=False) for k, v in files.items()}
        roi = r["local_ROI"]
        wb, matrix = (torch.from_numpy(s[k]) for k in ("wb", "matrix"))
        views = []
        for look in r["displays"]:
            old = old_pixels(look["board"])
            exposure = look["exposure"]
            full = [(k, old[k]) for k in compare_labels]
            for label in (PARENT, GLOBAL, REGIONAL):
                pixels = display_crop(torch.from_numpy(prediction[label]), wb, matrix, roi,
                                      exposure=exposure)
                full.append((label, np.rint(np.clip(pixels, 0, 1) * 255).astype(np.uint8)))
            full.extend((k, old[k]) for k in references if k in old)
            view = native_png(dest / f'{r["id"]}-x{exposure:g}.png', full)
            views.append({"exposure": exposure, "board": view})
        x, y, w, h = roi
        cut = np.s_[..., y:y+h, x:x+w]
        difference = {k: float(np.sqrt(np.mean((a[cut].astype(float)-prediction[PARENT][cut])**2))*65535)
                      for k, a in prediction.items() if k != PARENT}
        results.append(r | {"predictions": files, "forward": times, "displays": views,
                            "RGB_RMS_vs_parent_DN16": difference})
    return results


def capture_offgrid(models, input_ref, dest):
    pred = read_json(checked(input_ref))
    output = []
    for case in pred["rows"]:
        data = arrays(case["input"])
        paths, duration = predict(models, data, case["profile"], dest, f'offgrid-{case["id"]}')
        output.append({"case": case, "predictions": paths, "forward": duration})
        if len(output) % 8 == 0:
            print("Off-grid predictions", len(output), flush=True)
    return output


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    record = reference(ARCHIVE / "train/completed.json")
    endpoint = read_json(checked(record))
    plan = read_json(checked(endpoint["plan"]))
    assert endpoint["completed_schedule"] and endpoint["step"] == plan["steps"]
    assert endpoint["DINO_unchanged"] and not endpoint["qualification"]
    fixtures = read_json(checked(plan["review_inputs"]))
    assert fixtures["training_source_schedule"] == plan["schedule"]
    refs = endpoint["checkpoints"] | {"local50k": endpoint["parent"]}
    models = {}
    for k, ref in refs.items():
        model, state = load_scene_checkpoint(checked(ref), expected_sha256=ref["sha256"], weights="ema")
        assert state["step"] == (plan["parent_update"] if k == "local50k" else endpoint["step"])
        assert state["DINO_sha256"] == plan["DINO_sha256"]
        models[k] = _stage_tiled_cuda(model, torch.device("cuda"))
    root = ARCHIVE / "review"
    root.mkdir()
    buffers = root / "predictions"
    buffers.mkdir()
    exact_dir, real_dir = (root / k for k in ("exact", "standing"))
    exact_dir.mkdir()
    real_dir.mkdir()
    start = time.monotonic()
    scores = exact(models, fixtures["exact"], buffers)
    boxes = chosen_crops(scores, exact_dir)
    cameras = standing(models, fixtures["standing"], buffers, real_dir)
    transfer = capture_offgrid(models, fixtures["transfer"], buffers)
    write_json(root / "result.json", {
        "driver": reference(__file__), "endpoint": record, "review_inputs": plan["review_inputs"],
        "checkpoints": refs, "weights": "EMA", "precision": "CUDA IEEE FP32",
        "exact": scores, "exact_boards": boxes, "standing": cameras, "offgrid_predictions": transfer,
        "wall_seconds": time.monotonic() - start,
    })


if __name__ == "__main__":
    main()
