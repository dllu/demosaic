"""Measure signed detail and false projection at a saved regional-training milestone."""

import argparse

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_offgrid import ARCHIVE, ARMS, WireFundamental


def summarize(rows, seed):
    rng = np.random.default_rng(seed)
    method_names = tuple(rows[0]["scores"])
    result = {}
    metrics = sorted(set().union(*(row["scores"][ARMS[0]].keys() for row in rows)))
    for name in metrics:
        eligible = [row for row in rows if name in row["scores"][ARMS[0]]]
        if not eligible:
            continue
        count = len(eligible)
        indices = np.vstack((np.arange(count), rng.integers(count, size=(8000, count))))
        means = {
            key: np.array([row["scores"][key][name] for row in eligible])[indices].mean(axis=1)
            for key in method_names
        }
        effects = {}
        for key, values in means.items():
            diffs = {}
            for comparator in (ARMS[0], "local50k", "Corpus 100k", "V120"):
                change = values - means[comparator]
                diffs[comparator] = {
                    "delta": float(change[0]),
                    "95_percent": np.quantile(change[1:], (0.025, 0.975)).tolist(),
                }
            effects[key] = {"value": float(values[0]), "versus": diffs}
        result[name] = {"photo_count": count, "models": effects}
    return result


def main(step):
    root = ARCHIVE / f"review-{step:04d}"
    native = reference(root / "result.json")
    previous = read_json(checked(native))
    assert previous["step"] == step and previous["weights"] == "EMA"
    frozen = read_json(checked(previous["review_inputs"]))
    parent = read_json(checked(frozen["transfer"]))
    rows = []
    paired = zip(previous["offgrid_predictions"], parent["rows"], strict=True)
    for row, case in paired:
        assert row["case"] == case
        with np.load(checked(case["input"]), allow_pickle=False) as raw:
            op = WireFundamental(
                {k: raw[k] for k in ("wb", "matrix", "target", "support")},
                case["fixture"]["geometry"],
            )
        with np.load(checked(case["rgb"]), allow_pickle=False) as former:
            scores = {"V120": op(former["v120"]), "Corpus 100k": op(former["parent"])}
        scores.update({
            name: op(np.load(checked(ref), allow_pickle=False)) for name, ref in row["predictions"].items()
        })
        rows.append(row | {"scores": scores})
    assert len(rows) == 32
    rank = sorted(rows, key=lambda row: row["case"]["fixture"]["geometry"]["strength"][1])
    subsets = {"all": rows, "lower_weak_amplitude_half": rank[:16], "upper_weak_amplitude_half": rank[16:]}
    write_json(root / "offgrid.json", {
        "review": native, "driver": reference(__file__), "capture": frozen["transfer"],
        "subsets": {k: summarize(items, 202611192225 + i) for i, (k, items) in enumerate(subsets.items())},
        "rows": rows,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    main(parser.parse_args().step)
