"""Measure both standing cab peaks against the same noisy Bayer input."""

import argparse
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, CACHE

sys.path.insert(0, str(CACHE / "scene-patch-width-v1"))
from render_wide import CAMERA_PEAKS, peak_fit


def main(step):
    root = ARCHIVE / f"review-{step:04d}"
    review = reference(root / "result.json")
    record = read_json(checked(review))
    assert record["step"] == step
    reports = []
    for case in record["standing"]:
        if not case["id"].startswith("mesh"):
            continue
        with np.load(checked(case["input"]), allow_pickle=False) as source:
            raw, colors = (source[k][0] for k in ("packed", "colors"))
        result = {
            label: np.load(checked(binding), allow_pickle=False)[0]
            for label, binding in case["predictions"].items()
        }
        parent = result.pop("local50k")
        assert set(result) == set(ARMS)
        score = peak_fit(raw, parent, result, colors, case["local_ROI"])
        reports.append({
            "case": case["id"], "raw": case["raw"], "input": case["input"], "noise": case["noise"],
            "roi": case["global_ROI"], "camera_peak_frequency_xy": CAMERA_PEAKS,
            "signed_projection_percent_of_noisy_RAW": {
                k: item["percent_of_observed"] for k, item in score.items()
            },
        })
    assert len(reports) == 4
    write_json(root / "cab-peaks.json", {
        "review": review, "driver": reference(__file__), "step": step, "rows": reports,
        "scope": "Input-domain projection against noisy RAW. No aligned ISO100 scoring target.",
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    main(parser.parse_args().step)
