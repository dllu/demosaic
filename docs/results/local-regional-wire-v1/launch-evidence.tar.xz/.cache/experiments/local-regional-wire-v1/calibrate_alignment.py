"""Match initial output-gradient doses on the reserved wire qualifications."""

import statistics

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import RuntimePolicy
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import amp_context, ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

from train_regional import ARCHIVE, ROOT, shared
import regional_objective as regional


def main():
    proof = reference(ARCHIVE / "qualification/completed.json")
    result = read_json(checked(proof))
    assert result["qualification"] and result["completed_schedule"] and result["step"] == 8
    plan_binding = result["plan"]
    plan = read_json(checked(plan_binding))
    runtime = RuntimePolicy(**plan["runtime"])
    runtime.resources(ARCHIVE)
    runtime.apply()
    prior = shared(plan["shared_driver"])
    parent, _ = load_scene_checkpoint(
        checked(plan["parent"]), weights="ema", device="cpu", expected_sha256=plan["parent"]["sha256"]
    )
    _stage_tiled_cuda(parent, torch.device("cuda"))
    parent.train()
    bands = prior.PairedBands("cuda", plan["loss"]["bands"])
    schedule = read_json(checked(plan["schedule"]["qualification"]))
    ratios = []
    rows = []
    with ieee_fp32():
        for index, example in enumerate(schedule, start=1):
            if example["kind"] != "wire":
                continue
            arrays, about = prior.observations(example, plan["steps"] + index, pair_draws=2, seed=plan["seed"])
            batch = {k: v.cuda() for k, v in arrays.items()}
            for k in ("packed", "variance", "target", "sensor_target"):
                batch[k] = batch[k].contiguous(memory_format=torch.channels_last)
            parent.base.set_noise(about["camera"]["shot"], about["camera"]["read"])
            with torch.no_grad(), amp_context("cuda", dtype="bfloat16"):
                estimate = parent(*(batch[k] for k in prior.FORWARD_ARGS))
            estimate.requires_grad_(True)
            global_loss, valid = bands.redraw_losses(estimate, batch, align=True)
            plant = about["geometry"]["wire"]
            bank = [(r, a.cuda() if a is not None else None, b.cuda() if b is not None else None)
                    for r, a, b in regional.projections(plant)]
            localized, _ = regional.loss(estimate, batch, bank, bands.luminance)
            whole_gradient = torch.autograd.grad(global_loss["aligned"], estimate, retain_graph=True)[0]
            local_gradient = torch.autograd.grad(localized, estimate)[0]
            whole, local = float(whole_gradient.norm()), float(local_gradient.norm())
            if valid and whole > 0 and local > 0:
                ratios.append(whole / local)
            rows.append({
                "id": example["source"]["id"], "ISO": example["iso"], "CFA": example["pattern"],
                "strong_continues": example["strong_continues"], "valid": bool(valid),
                "whole_output_gradient_L2": whole, "local_output_gradient_L2": local,
            })
    assert len(rows) == 4 and len(ratios) >= 3
    weight = plan["loss"]["aligned"] * statistics.median(ratios)
    write_json(ROOT / "alignment-dose.json", {
        "driver": reference(__file__), "qualification": proof,
        "plan": plan_binding, "parent": plan["parent"], "rows": rows,
        "whole_aligned_weight": plan["loss"]["aligned"], "regional_aligned_weight": weight,
        "method": "Median global-to-local loss gradient norm ratio at unchanged Local 50k EMA outputs.",
    })
    print("Regional alignment weight", weight, flush=True)


if __name__ == "__main__":
    main()
