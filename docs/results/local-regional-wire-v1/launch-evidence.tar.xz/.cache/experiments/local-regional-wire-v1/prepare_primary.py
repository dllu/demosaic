"""Bind both completed regional-training arms to the canonical panel collector."""

from pathlib import Path

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json
from train_regional import ARCHIVE, ARMS, REPO


def main():
    completed = reference(ARCHIVE / "train/completed.json")
    training = read_json(checked(completed))
    plan = read_json(checked(training["plan"]))
    assert training["completed_schedule"] and training["step"] == plan["steps"]
    assert not training["qualification"] and training["DINO_unchanged"]
    evaluation = read_json(checked(plan["review_inputs"]))
    original = evaluation["canonical_recipe"]
    template = read_json(checked(original))
    assert template["canonical_inputs"] == evaluation["canonical_inputs"]
    assert template["models"]["none"]["checkpoint"] == training["parent"]
    assert template["DINO_sha256"] == plan["DINO_sha256"]

    root = ARCHIVE / "canonical"
    root.mkdir()
    work, frozen = freeze_sources(REPO, root, ["collect_scene_primary_compact.py"])
    models = {name: template["models"][name] for name in ("V120", "parent100k")}
    models["local50k"] = template["models"]["none"]
    for name in ARMS:
        models[name] = {
            "kind": "scene", "checkpoint": training["checkpoints"][name], "step": training["step"]
        }
    inputs = [completed, training["plan"], plan["review_inputs"], original,
              *(m["checkpoint"] for m in models.values()),
              *(template[k] for k in ("canonical_inputs", "photo_inventory", "parent_CPU_probes")),
              *(m["manifest"] for m in template["stages"].values() if "manifest" in m)]
    keys = ("canonical_inputs", "photo_inventory", "parent_CPU_probes", "preview_long_side",
            "preview_exposure", "stages", "DINO_sha256", "policy")
    document = {k: template[k] for k in keys}
    document.update(root=str(root), inputs=inputs, probe_only=False, models=models, frozen_files=frozen,
                    driver=reference(work / "scripts/collect_scene_primary_compact.py"),
                    reference_replay={
                        "plan": original, "root": template["root"],
                        "models": {"V120": "V120", "parent100k": "parent100k", "local50k": "none"},
                    })
    write_json(root / "plan.json", document)
    print(root / "plan.json")


if __name__ == "__main__":
    main()
