"""Compare global and regional weak-wire supervision on the full Local 50k trunk."""

import argparse
from collections import Counter
from itertools import product
import json
import math
from pathlib import Path
import random
import sys
import time

import torch
from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import RuntimePolicy, exclusive_run
from demosaic.scene_inference import load_scene_checkpoint
from demosaic.inference import _stage_tiled_cuda
from demosaic.cfa import mosaic
from demosaic.losses import reconstruction_loss
from demosaic.precision import amp_context, ieee_fp32

import regional_objective as regional

ROOT = Path(__file__).resolve().parent
if ROOT.name == "scripts":
    ROOT = ROOT.parents[1]
REPO = ROOT.parents[2]
CACHE = ROOT.parent
SEED = 202611192213
STEPS = 1024
ARMS = ("global-aligned", "regional-aligned")
OLDER = CACHE / "local-continuing-wire-v1"
SOURCE = OLDER / "work/scripts/train_local_paired_continuation.py"
ARCHIVE = Path("/mnt/external/demosaic/local-regional-wire-v1")
PRIOR_TRIALS = (
    "local-paired-continuation-v1", "local-redraw-average-v1", "local-redraw-stability-v1",
    "local-wire-response-v1", "local-continuing-wire-v1", "local-factored-wire-v1",
    "local-phase-support-v1",
)
PROTECTED = ("gfx-qualitative-20231231.json", "gfx-green-mesh-20231231.json")


def shared(binding):
    path = checked(binding)
    sys.path.insert(0, str(path.parent))
    try:
        import train_local_paired_continuation as prior
    finally:
        sys.path.pop(0)
    assert Path(prior.__file__) == path
    return prior


def scene_rows(binding):
    with checked(binding).open() as data:
        for line in data:
            if line.strip():
                yield json.loads(line)


def prepare():
    project = reference(CACHE / "scene-full-epoch-v1/plan.json")
    top = read_json(checked(project))
    corpus = reference(CACHE / "expanded-scene-epoch-corpus-v1/audit.json")
    corpus_audit = read_json(checked(corpus))
    assert corpus_audit["train_manifest"] == top["train_manifest"]
    receipt = reference(CACHE / "scene-full-epoch-v1/matched-050000.json")
    trained = read_json(checked(receipt))
    assert trained["training_complete"] and trained["through_update"] == 50000
    assert trained["plan"] == project
    parent = trained["arms"]["none"]["checkpoint"]
    checked(parent)
    ancestor = read_json(OLDER / "plan.json")
    assert ancestor["driver"] == reference(SOURCE)
    prior = shared(ancestor["driver"])
    earlier = [
        reference(CACHE / name / item)
        for name in PRIOR_TRIALS
        for item in ("schedule.json", "qualification-schedule.json", "qualification_schedule.json")
        if (CACHE / name / item).is_file()
    ]
    blocked = {r["source"][key] for plan in earlier for r in read_json(checked(plan))
               for key in ("id", "cache_sha256")}
    blocked.update(
        r[key] for r in scene_rows(top["development_manifest"]) for key in ("id", "cache_sha256")
    )
    held = [
        reference(CACHE / f) for f in (
            "scene-coherent-fourier-v1/transfer.json",
            "scene-phase-neighbors-v1/natural.json",
            "scene-phase-neighbors-v1/natural-doses.json",
        )
    ]
    for file in held:
        blocked.update(r["case"]["source"][key] for r in read_json(checked(file))["rows"]
                       for key in ("id", "cache_sha256"))
    configs = [reference(REPO / "configs" / name) for name in PROTECTED]
    protected = set()
    for config in configs:
        capture = read_json(checked(config))
        sources = capture.get("sources", {})
        protected.update(v["sha256"] for v in sources.values())
        if sources:
            paths = [v["path"] for v in sources.values()]
        else:
            paths = [capture[key] for key in ("noisy", "reference")]
        protected.update(Path(p).stem.split("_")[-1] for p in paths)
    for folder in (REPO / ".cache/gfx-qualitative-20231231", REPO / ".cache/gfx-green-mesh-20231231"):
        protected.update(p.stem.split("_")[-1].split("-")[0] for p in folder.glob("*_DSCF*"))
    blocked |= protected
    rows = list(scene_rows(top["train_manifest"]))
    assert len(rows) == 90692 and all(r["split"] == "train" for r in rows)
    assert all(Path(r["cache"]).is_relative_to("/mnt/external/demosaic")
               and Path(r["cache"]).parts[4].startswith("commons-") for r in rows)
    assert protected.isdisjoint(r[k] for r in rows for k in ("id", "cache_sha256"))
    rng = random.Random(SEED)
    cells = list(product(("natural", "wire"), prior.PROFILES, prior.PATTERNS, ("coupled", "independent")))
    assert STEPS % len(cells) == 0
    variants = cells * (STEPS // len(cells))
    rng.shuffle(variants)
    qualification = [cells[i] for i in (0, 3, 8, 11, 16, 19, 24, 27)]
    rng.shuffle(rows)
    visits = Counter()
    selected = []
    for recipe, row in zip(variants + qualification, (
        row for row in rows if row["id"] not in blocked and row["cache_sha256"] not in blocked
    ), strict=False):
        kind, iso, pattern, law = recipe
        assert row["id"] not in blocked and row["cache_sha256"] not in blocked
        assert min(row["shape"][:2]) >= 256 and row["dtype"] == "uint16"
        blocked.update((row["id"], row["cache_sha256"]))
        entry = {"source": row, "kind": kind, "iso": iso, "pattern": pattern, "law": law}
        if kind == "wire":
            if len(selected) >= STEPS:
                entry["strong_continues"] = sum(r["kind"] == "wire" for r in selected[STEPS:]) % 2 == 1
            else:
                entry["strong_continues"] = visits[recipe] % 5 != 0
        visits[recipe] += 1
        selected.append(entry)
    assert len(selected) == STEPS + len(qualification)
    schedule = {"train": ROOT / "schedule.json", "qualification": ROOT / "qualification-schedule.json"}
    write_json(schedule["train"], selected[:STEPS])
    write_json(schedule["qualification"], selected[STEPS:])
    work, frozen = freeze_sources(REPO, ROOT)
    snapshot = work / "scripts"
    snapshot.mkdir()
    for path in (ROOT / "train_regional.py", ROOT / "regional_objective.py"):
        out = snapshot / path.name
        out.write_bytes(path.read_bytes())
        frozen[str(out)] = reference(out)["sha256"]
    policy = {
        "seed": SEED, "threads": 2, "cuda_quota_gib": 23,
        "minimum_ram_gib": 24, "minimum_disk_gib": 20,
    }
    bindings = {key: reference(path) for key, path in schedule.items()}
    plan = {
        "experiment": ROOT.name, "parent": parent, "parent_training": receipt,
        "parent_update": 50000, "adapter_width": top["adapter_width"],
        "DINO_sha256": top["DINO_sha256"], "seed": SEED,
        "shared_driver": ancestor["driver"], "driver": reference(snapshot / Path(__file__).name),
        "schedule": bindings, "frozen_files": frozen, "runtime": policy,
        "inputs": [project, corpus, receipt, parent, ancestor["driver"], top["train_manifest"],
                   corpus_audit["input"],
                   top["development_manifest"], *earlier, *held, *configs, *bindings.values()],
        "steps": STEPS, "report_every": 32, "save_steps": [128, 512, STEPS],
        "arms": list(ARMS), "ordinary_source_count": 512, "wire_source_count": 512,
        "members": ["present", "absent", "present-redraw", "absent-redraw", "flat", "ordinary"],
        "optimizer": {"peak_lr": 5e-6, "warmup": 64, "floor": 0.15, "ema": 0.995},
        "loss": {"paired": 0.8, "repeat": 0.5, "aligned": 1.6, "strong_gap": 1.6,
                 "weak_absence": 0.8, "bands": ancestor["pair_bands_cycles_per_pixel"]},
        "scope": "1,024 distinct approved sources per matched arm. Whole-core and regional "
                 "signed weak-wire targets share the absent-direction term, continuing-wire term, "
                 "the same reconstruction and repeat losses, and full local trunk training.",
    }
    write_json(ROOT / "plan.json", plan)
    print("frozen", len(selected), plan["parent"]["sha256"], flush=True)


def lr_at(step, plan):
    p = plan["optimizer"]
    fraction = max(0, step - p["warmup"]) / (plan["steps"] - p["warmup"])
    anneal = p["floor"] + (1 - p["floor"]) * (1 + math.cos(math.pi * fraction)) / 2
    return p["peak_lr"] * min(1, step / p["warmup"]) * anneal


def trainable(model):
    return [p for p in model.base.parameters() if p.requires_grad]


def save_state(output, plans, plan, completed, models, optimizer, averages):
    slot = output / f"step-{completed:04d}"
    slot.mkdir(exist_ok=True)
    paths = {}
    for arm in ARMS:
        path = slot / f"{arm}.pt"
        temporary = path.with_suffix(".partial")
        model, base_parent = models[arm]
        torch.save({
            "model": {key: value.detach().cpu() for key, value in model.restoration_state_dict().items()},
            "ema": {key: value.cpu() for key, value in averages[arm].items()},
            "optimizer": optimizer[arm].state_dict(), "base_parent": base_parent,
            "continued_from": plan["parent"], "mode": "none", "adapter_width": plan["adapter_width"],
            "DINO_sha256": plan["DINO_sha256"], "step": completed, "training_arm": arm,
            "plan": plans,
        }, temporary)
        temporary.replace(path)
        paths[arm] = reference(path)
    write_json(slot / "checkpoint.json", {"step": completed, "plan": plans, "arms": paths})
    return paths


def stage(plan_binding, output, name, stop, resume):
    plan = read_json(checked(plan_binding))
    verify_plan(plan)
    assert checked(plan["driver"]) == Path(__file__).resolve()
    prior = shared(plan["shared_driver"])
    schedule = read_json(checked(plan["schedule"][name]))
    stop = stop or len(schedule)
    previous = read_json(checked(resume)) if resume is not None else None
    start = previous["step"] if previous else 0
    assert 0 <= start < stop <= len(schedule)
    assert previous is None or previous["plan"] == plan_binding
    assert name == "train" or (start == 0 and stop == len(schedule))
    if name == "train":
        qualified = read_json(output.parent / "qualification/completed.json")
        assert qualified["plan"] == plan_binding and qualified["qualification"]
    output.mkdir(parents=True, exist_ok=False)
    runtime = RuntimePolicy(**plan["runtime"])
    runtime.resources(output)
    runtime.apply()
    device = torch.device("cuda")
    models, optim, ema = {}, {}, {}
    endp = previous["arms"] if previous else dict.fromkeys(ARMS, plan["parent"])
    for arm in ARMS:
        source = endp[arm]
        model, state = load_scene_checkpoint(
            checked(source), weights="model" if previous else "ema", device="cpu",
            expected_sha256=source["sha256"],
        )
        assert state["mode"] == "none" and state["step"] == (start if previous else plan["parent_update"])
        assert state["adapter_width"] == plan["adapter_width"]
        assert prior.model_hash(model.base.context.backbone) == plan["DINO_sha256"]
        _stage_tiled_cuda(model, device)
        model.train()
        models[arm] = model, state["base_parent"]
        optim[arm] = torch.optim.AdamW(trainable(model), lr=0, weight_decay=1e-4, fused=True)
        if previous:
            assert state["training_arm"] == arm and state["plan"] == plan_binding
            optim[arm].load_state_dict(state["optimizer"])
            ema[arm] = {k: t.to(device) for k, t in state["ema"].items()}
        else:
            ema[arm] = {k: t.detach().clone() for k, t in model.restoration_state_dict().items()}
        del state
    bands = prior.PairedBands(device, plan["loss"]["bands"])
    loss_weights = plan["loss"]
    checkpoint_s = 0.0
    data_s, live_s = 0.0, {arm: 0. for arm in ARMS}
    seen = Counter()
    started = time.monotonic()
    outputs = {}
    with (
        (output / "observations.jsonl").open("x", buffering=1) as trace,
        (output / "train.jsonl").open("x", buffering=1) as log,
        ieee_fp32(),
    ):
        for step in range(start + 1, stop + 1):
            mark = time.monotonic()
            index = step + (plan["steps"] if name == "qualification" else 0)
            arrays, about = prior.observations(schedule[step - 1], index, pair_draws=2, seed=plan["seed"])
            batch = {k: t.to(device) for k, t in arrays.items()}
            for k in ("packed", "variance", "target", "sensor_target"):
                batch[k] = batch[k].contiguous(memory_format=torch.channels_last)
            trace.write(json.dumps(about, sort_keys=True) + "\n")
            wire = about["geometry"].get("wire")
            banks, continuing = None, None
            if wire is not None:
                banks = [(r, p.to(device) if p is not None else None, q.to(device) if q is not None else None)
                         for r, p, q in regional.projections(wire)]
                continuing = prior.gap_projection(wire, continuing=True).to(device)
                seen["strong_continues" if wire["strong_continues"] else "double_gap"] += 1
            seen[about["kind"]] += 1
            data_s += time.monotonic() - mark
            lr = lr_at(step, plan)
            stats = {"step": step, "lr": lr}
            for arm in ARMS:
                mark = time.monotonic()
                model, _ = models[arm]
                model.base.set_noise(about["camera"]["shot"], about["camera"]["read"])
                optimizer = optim[arm]
                optimizer.param_groups[0]["lr"] = lr
                optimizer.zero_grad(set_to_none=True)
                with amp_context("cuda", dtype="bfloat16"):
                    prediction = model(*(batch[k] for k in prior.FORWARD_ARGS))
                assert prediction.dtype == torch.float32
                absolute, _ = reconstruction_loss(
                    prediction, batch, auxiliary=mosaic(prediction, batch["colors"]),
                    camera_supervision="sensor-valid-v1", reconstruction_charbonnier_epsilon=0.0003,
                )
                redraw, valid = bands.redraw_losses(prediction, batch, align=wire is not None)
                total = absolute + loss_weights["paired"] * redraw["mean"]
                if about["law"] == "independent":
                    total = total + loss_weights["repeat"] * redraw["repeat"]
                pieces = {"absolute": absolute, **redraw}
                if wire is not None:
                    local, false = regional.loss(prediction, batch, banks, bands.luminance)
                    strong = bands.continuing_wire_loss(prediction, batch, continuing)
                    alignment = redraw["aligned"] if arm == ARMS[0] else local
                    total = (total + loss_weights["aligned"] * alignment
                             + loss_weights["weak_absence"] * false
                             + loss_weights["strong_gap"] * strong)
                    pieces |= {"regional": local, "weak_absence": false, "continuing": strong}
                if step == 1:
                    if arm == ARMS[0]:
                        initial = prediction.detach().clone()
                    else:
                        torch.testing.assert_close(prediction.detach(), initial, atol=0, rtol=0)
                        del initial
                if not torch.isfinite(total):
                    raise FloatingPointError(f"Nonfinite loss for {arm} at update {step}")
                total.backward()
                norm = torch.nn.utils.clip_grad_norm_(trainable(model), 1.0, error_if_nonfinite=True)
                optimizer.step()
                with torch.no_grad():
                    for key, value in model.restoration_state_dict().items():
                        ema[arm][key].lerp_(value, 1 - plan["optimizer"]["ema"])
                stats[arm] = {k: float(v.detach()) for k, v in pieces.items()}
                stats[arm]["gradient_norm"] = float(norm)
                stats[arm]["total"] = float(total.detach())
                live_s[arm] += time.monotonic() - mark
            seen["valid_pairs"] += int(valid)
            log.write(json.dumps(stats, sort_keys=True) + "\n")
            if step % plan["report_every"] == 0 or step == stop or name == "qualification":
                print(step, round(time.monotonic() - started, 2), stats, flush=True)
                runtime.resources(output)
            if step == stop or step in plan["save_steps"]:
                mark = time.monotonic()
                outputs = save_state(output, plan_binding, plan, step, models, optim, ema)
                checkpoint_s += time.monotonic() - mark
    elapsed = time.monotonic() - started
    for model, _ in models.values():
        assert prior.model_hash(model.base.context.backbone) == plan["DINO_sha256"]
    write_json(output / "completed.json", {
        "plan": plan_binding, "parent": plan["parent"], "qualification": name == "qualification",
        "start": start, "step": stop, "completed_schedule": stop == len(schedule),
        "updates_per_arm": stop - start, "native_observations_per_arm": (stop - start) * len(plan["members"]),
        "seen": dict(seen), "checkpoints": outputs, "DINO_unchanged": True,
        "training_wall_seconds_including_checkpoint": elapsed, "arm_seconds": live_s,
        "data_seconds": data_s, "checkpoint_and_hash_seconds": checkpoint_s,
        "trace": reference(output / "observations.jsonl"), "log": reference(output / "train.jsonl"),
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "qualification", "train"))
    parser.add_argument("--stop", type=int)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "prepare":
        assert ROOT == Path(__file__).parent
        prepare()
        return
    config = reference(ROOT / "plan-v2.json")
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    target = args.output or ARCHIVE / args.action
    with exclusive_run(ARCHIVE):
        stage(config, target, args.action, args.stop, reference(args.resume) if args.resume else None)


if __name__ == "__main__":
    main()
