"""Archive the frozen training protocol and verified launch prefix."""

from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import tarfile
from zoneinfo import ZoneInfo

import math
from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import owner_live
from train_regional import ARCHIVE, ARMS, ROOT, REPO


def snapshot(source, target, count):
    with source.open("rb") as stream, target.open("xb") as output:
        lines = []
        for _ in range(count):
            value = stream.readline()
            assert value.endswith(b"\n")
            lines.append(json.loads(value))
            output.write(value)
    return lines


def main():
    binding = reference(ROOT / "plan-v3.json")
    plan = read_json(checked(binding))
    verify_plan(plan)
    q = read_json(checked(plan["qualification"]))
    assert q["qualification"] and q["completed_schedule"] and q["step"] == 8 and q["DINO_unchanged"]
    for checkpoint in q["checkpoints"].values():
        checked(checkpoint)
    schedule = read_json(checked(plan["schedule"]["train"]))
    geometry = reference(ROOT / "schedule-geometry-audit.json")
    audit = read_json(checked(geometry))
    assert audit["plan"] == binding and len(audit["rows"]) == 512
    owner = read_json(ARCHIVE / "owner.json")
    assert owner_live(owner)
    run = ARCHIVE / "train"
    stage = ROOT / "launch"
    stage.mkdir()
    count = 32
    trace = snapshot(run / "observations.jsonl", stage / "observations-through-0032.jsonl", count)
    losses = snapshot(run / "train.jsonl", stage / "train-through-0032.jsonl", count)
    for index, (source, actual, loss) in enumerate(zip(schedule[:count], trace, losses, strict=True), 1):
        assert index == loss["step"] == actual["index"]
        assert actual["source_id"] == source["source"]["id"]
        assert actual["cache_sha256"] == source["source"]["cache_sha256"]
        for arm in ARMS:
            assert all(math.isfinite(value) for value in loss[arm].values())
    assert losses[0][ARMS[0]]["absolute"] == losses[0][ARMS[1]]["absolute"]
    frozen_python = [p for p in (ROOT / "work/scripts").glob("*.py")]
    refs = [
        binding, plan["qualification"], plan["qualification_base"], plan["alignment_dose"],
        plan["review_inputs"], geometry, reference(ROOT / "cpu-audit.json"),
        *plan["schedule"].values(), q["log"], q["trace"], plan["shared_driver"],
        *[reference(p) for p in frozen_python],
        *[reference(ROOT / p) for p in (
            "audit_regional.py", "calibrate_alignment.py", "check_schedule.py", "freeze_review.py",
            "prepare_primary.py", "review_regional.py", "score_offgrid.py",
        )],
        *[reference(p) for p in stage.iterdir()], reference(__file__),
    ]
    result = REPO / "docs/results" / ROOT.name
    result.mkdir(parents=True)
    suffix = Path("/mnt/external/demosaic")
    archive = result / "launch-evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for ref in {v["path"]: v for v in refs}.values():
            file = checked(ref)
            name = (file.relative_to(REPO) if file.is_relative_to(REPO)
                    else Path("external") / file.relative_to(suffix)).as_posix()
            tar.add(file, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(name).read()).hexdigest() == v for name, v in members.items())
    write_json(result / "launch.json", {
        "experiment": ROOT.name,
        "plan": binding, "parent": plan["parent"], "parent_weights": "EMA",
        "scope": "Training launch and immutable qualification. No endpoint quality review.",
        "training_status_at_receipt": "running", "planned_updates_per_arm": plan["steps"],
        "planned_native_observations_per_arm": plan["steps"] * len(plan["members"]),
        "verified_running_prefix_updates_per_arm": count, "training_owner": owner,
        "recorded": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "optimizer": plan["optimizer"], "loss": plan["loss"],
        "qualification": plan["qualification"], "qualification_training_seconds": q["training_wall_seconds_including_checkpoint"],
        "alignment_dose": plan["alignment_dose"], "prepared_reviews": plan["review_inputs"],
        "archive": reference(archive), "members": members,
    })


if __name__ == "__main__":
    main()
