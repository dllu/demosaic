"""Check target isolation, phase normalization and finite loss gradients."""

from pathlib import Path

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ROOT, shared
from regional_objective import CORE, loss, projections, geometry_axes


def main():
    torch.set_num_threads(2)
    binding = reference(ROOT / "plan.json")
    plan = read_json(checked(binding))
    prior = shared(plan["shared_driver"])
    source = read_json(checked(plan["schedule"]["qualification"]))
    results = []
    luma = torch.tensor([.2126, .7152, .0722])
    for index, row in enumerate(source):
        if row["kind"] != "wire":
            continue
        arrays, about = prior.observations(
            row, plan["steps"] + index + 1, pair_draws=2, seed=plan["seed"]
        )
        truth = arrays["sensor_target"]
        wire = about["geometry"]["wire"]
        bank = projections(wire)
        assert sum(r is not None for _, r, _ in bank) >= 4
        assert sum(g is not None for _, _, g in bank) >= 1
        x, y, rho, (strong, weak) = geometry_axes(wire)
        for region, intact, absent in bank:
            for direction, role in ((intact, "intact"), (absent, "gap")):
                if direction is None:
                    continue
                if role == "gap":
                    assert (direction[rho[region].flatten() >= 1] == 0).all()
                nuisance = torch.stack((torch.ones_like(x), x / 32, y / 32, strong.cos(), strong.sin()), dim=0)
                cuts = nuisance[(slice(None), *region)].flatten(1)
                torch.testing.assert_close(
                    cuts @ direction.double(), torch.zeros((5, 2), dtype=torch.float64),
                    atol=1e-7, rtol=0,
                )
        zero = loss(truth, arrays, bank, luma)
        assert max(abs(float(v)) for v in zero) <= 1e-8

        coherent = truth.clone()
        coherent[:4, 1, CORE, CORE] += 0.008 * weak.cos().float()
        shared_error, false = loss(coherent, arrays, bank, luma)
        if float(false) > 0:
            assert float(shared_error) < 1e-7
        missing = truth.clone()
        missing[0:4:2] -= 0.5 * (truth[0] - truth[1])
        missing.requires_grad_(True)
        response, false_missing = loss(missing, arrays, bank, luma)
        response.backward()
        assert torch.isfinite(missing.grad).all()
        assert float(false_missing) < 1e-7
        results.append({
            "source": row["source"]["id"], "strong_continues": wire["strong_continues"],
            "valid_response_tiles": sum(r is not None for _, r, _ in bank),
            "valid_gap_tiles": sum(g is not None for _, _, g in bank),
            "perfect_target": [float(a) for a in zero],
            "common_error_paired_loss": float(shared_error), "common_error_false_loss": float(false),
            "attenuated_pair_regional_loss": float(response.detach()),
            "attenuated_pair_gradient_norm": float(missing.grad.norm()),
        })
    assert len(results) == 4 and {r["strong_continues"] for r in results} == {False, True}
    assert sum(r["attenuated_pair_gradient_norm"] > 0 for r in results) >= 2
    assert sum(r["common_error_false_loss"] > 0 for r in results) >= 2
    write_json(ROOT / "cpu-audit.json", {
        "driver": reference(__file__), "plan": binding,
        "objective": reference(ROOT / "regional_objective.py"), "rows": results,
    })
    print(f"Regional objective validated on {len(results)} exact qualification cases.", flush=True)


if __name__ == "__main__":
    main()
