"""Bind the evaluation inputs before a trained regional model can be scored."""

from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import CACHE, ROOT, REPO


def source_keys(records):
    return {r[key] for r in records for key in ("id", "cache_sha256")}


def main():
    training_plan = reference(ROOT / "plan-v2.json")
    plan = read_json(checked(training_plan))
    training = source_keys(r["source"] for ref in plan["schedule"].values()
                           for r in read_json(checked(ref)))
    before = reference(CACHE / "local-continuing-wire-v1/review/result.json")
    saved = read_json(checked(before))
    native = reference(CACHE / "scene-phase-neighbors-v1/native/standing/result.json")
    displays = {r["id"]: r for r in read_json(checked(native))["rows"]}
    fixed = {}
    for name, count in (("photo", 24), ("wire", 24)):
        rows = saved["groups"][name]["rows"]
        assert len(rows) == count
        assert training.isdisjoint(source_keys(r["source"]["source"] for r in rows))
        fixed[name] = [
            {"source": r["source"], "input": r["input"], "model_outputs": r["model_outputs"],
             "endpoint_output": r["endpoint_output"], "box": r["box"], "gap_pixels": r["gap_pixels"]}
            for r in rows
        ]
        for r in fixed[name]:
            checked(r["input"])

    transfer = reference("/mnt/external/demosaic/scene-coherent-fourier-v1/transfer/parents.json")
    confirmation = read_json(checked(transfer))
    assert len(confirmation["rows"]) == 32
    assert training.isdisjoint(source_keys(r["source"] for r in confirmation["rows"]))
    for r in confirmation["rows"]:
        checked(r["input"])

    standing = []
    for r in saved["standing"]:
        item = displays[r["id"]]
        x, y = r["native_sensor_box"][:2]
        a, b, w, h = r["roi"]
        assert [x + a, y + b, w, h] == item["global_roi"] and r["raw"] == item["raw"]
        assert {k: r["noise"][k] for k in ("shot", "read")} == {
            k: item["noise"][k] for k in ("shot", "read")
        }
        allowed = {4, 16} if r["id"].startswith("mesh") else {4}
        assert {board["exposure"] for board in item["displays"]} == allowed
        standing.append({
            "id": r["id"], "raw": r["raw"], "noise": r["noise"], "input": r["input"],
            "local_ROI": r["roi"], "sensor_box": r["native_sensor_box"],
            "global_ROI": item["global_roi"], "displays": item["displays"],
        })
    assert len(standing) == 8
    broad = reference(CACHE / "scene-compact-050000-v1/plan.json")
    canonical = read_json(checked(broad))
    assert canonical["models"]["none"]["checkpoint"] == plan["parent"]
    write_json(ROOT / "review-inputs.json", {
        "driver": reference(__file__), "training_source_schedule": plan["schedule"],
        "exact_fixture_reference": before, "exact": fixed,
        "transfer": transfer, "standing_reference": native, "standing": standing,
        "canonical_recipe": broad, "canonical_inputs": canonical["canonical_inputs"],
        "known_cameras": canonical["stages"]["known"]["manifest"],
        "unseen_cameras": canonical["stages"]["unseen"]["manifest"],
        "GFX_configs": [reference(REPO / "configs" / name) for name in (
            "gfx-qualitative-20231231.json", "gfx-green-mesh-20231231.json",
        )],
        "scope": "48 fixed exact conditions, 32 held-out off-grid source photos, both standing "
                 "GFX scenes and their usual exposures, and canonical fixed photo and camera inputs.",
        "source_overlap": {"fixed_exact": 0, "offgrid_transfer": 0},
    })
    print("Evaluation inputs frozen before matched training.", flush=True)


if __name__ == "__main__":
    main()
