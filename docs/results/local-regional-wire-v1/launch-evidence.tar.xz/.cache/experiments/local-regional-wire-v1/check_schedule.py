"""Audit every planned wire geometry and each standing display binding."""

from collections import Counter
import random

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_regional import ROOT, shared
from regional_objective import projections


def main():
    torch.set_num_threads(2)
    step_plan = reference(ROOT / "plan-v3.json")
    plan = read_json(checked(step_plan))
    schedule = read_json(checked(plan["schedule"]["train"]))
    previous = shared(plan["shared_driver"])
    scene = torch.full((3, 256, 256), .2)
    result = []
    for index, case in enumerate(schedule, 1):
        if case["kind"] != "wire":
            continue
        rng = random.Random(previous.scene_seed(plan["seed"], index, "content"))
        h, w = case["source"]["shape"][:2]
        rng.randrange(0, w-255, 2)
        rng.randrange(0, h-255, 2)
        rng.randrange(4)
        rng.randrange(2)
        _, _, wire = previous.wire_pair(scene, rng, strong_continues=case["strong_continues"])
        bank = projections(wire)
        outcome = [sum(r is not None for _, r, _ in bank), sum(g is not None for _, _, g in bank)]
        assert all(v > 0 for v in outcome)
        result.append({
            "step": index, "source": case["source"]["id"], "response_tiles": outcome[0],
            "absence_tiles": outcome[1], "period_native": wire["periods"],
        })
    assert len(result) == 512
    write_json(ROOT / "schedule-geometry-audit.json", {
        "plan": step_plan, "driver": reference(__file__), "rows": result,
        "counts": {"response": dict(Counter(r["response_tiles"] for r in result)),
                   "gap": dict(Counter(r["absence_tiles"] for r in result))},
    })
    print("Checked regional support in all 512 wire geometries.", flush=True)


if __name__ == "__main__":
    main()
