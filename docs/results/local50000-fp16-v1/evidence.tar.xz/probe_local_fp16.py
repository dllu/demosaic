"""Measure FP16 on local 50k at fixed RAW geometry, including faint targets."""
from collections import defaultdict
from pathlib import Path
import time

import numpy as np
import torch
from PIL import Image

from review_continuation import BASELINE, BEFORE, ROOT, KEYS, metrics
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import amp_context, ieee_fp32
from demosaic.reporting import display_crop
from demosaic.scene_inference import load_scene_checkpoint

MODES = ("float32", "float16")


def cuda(args):
    batch = [torch.from_numpy(args[k]).cuda() for k in KEYS]
    for i in (0, 1):
        batch[i] = batch[i].contiguous(memory_format=torch.channels_last)
    return batch


def run(model, inputs, profile, dtype):
    model.base.set_noise(profile["shot"], profile["read"])
    start = torch.cuda.Event(enable_timing=True)
    stop = torch.cuda.Event(enable_timing=True)
    with amp_context("cuda", dtype=dtype):
        start.record()
        result = model(*inputs)
        stop.record()
        stop.synchronize()
    assert result.dtype == torch.float32
    return result.cpu().numpy(), start.elapsed_time(stop)


def error(a, b):
    delta = np.subtract(a, b, dtype=np.float64) * 65535
    return dict(RMS_DN16=float(np.sqrt(np.mean(delta**2))), max_DN16=float(abs(delta).max()),
                code_p999_DN16=float(np.quantile(abs(delta), .999)))


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root = ROOT / "fp16-probe"
    root.mkdir()
    source = reference(BASELINE / "review.json")
    old = read_json(checked(source))
    prior = read_json(checked(old["replay"]))
    plan = read_json(checked(prior["plan"]))
    profile = read_json(checked(read_json(checked(plan["exact_capture"]))["plan"]))["profile"]
    checkpoint = old["checkpoint"]
    model, state = load_scene_checkpoint(checked(checkpoint), weights="ema", expected_sha256=checkpoint["sha256"])
    assert state["step"] == 50000 and state["mode"] == "none"
    model = _stage_tiled_cuda(model.eval(), "cuda")
    tagged = defaultdict(list)
    start = time.monotonic()
    with ieee_fp32():
        for kind in ("photo", "wire"):
            for row in old[kind]:
                with np.load(checked(row["input"]), allow_pickle=False) as archive:
                    args = {k: archive[k] for k in archive.files}
                query = {**args}
                query.update({key: np.broadcast_to(args[key], (len(args["packed"]), *args[key].shape)).copy()
                              for key in ("colors", "wb", "matrix")})
                inputs = cuda(query)
                half, elapsed = run(model, inputs, profile, "float16")
                full = np.load(checked(row["endpoint_output"]), allow_pickle=False)
                precise = row["scores"]["Local 50k EMA"]
                fast = metrics(row, half, args)
                tagged[kind].append(dict(input=row["input"], source=row["source"]["source"]["id"],
                    error=error(half,full), float16_forward_ms=elapsed,
                    float16=fast, float32=precise))
    scenes = []
    with ieee_fp32():
        durations = []
        # Use a native, even 512-pixel subwindow of the standing input.
        example = old["standing"][0]
        with np.load(checked(example["input"]), allow_pickle=False) as f:
            tile = {k:f[k] for k in KEYS}
        h, w = tile["packed"].shape[-2:]
        assert min(h,w) >= 256
        y0, x0 = (h - 256) // 2, (w - 256) // 2
        for k in ("packed", "variance"):
            tile[k] = np.broadcast_to(tile[k][:1, :, y0:y0+256, x0:x0+256], (4,4,256,256)).copy()
        for k in ("colors", "wb", "matrix"):
            tile[k] = np.repeat(tile[k][:1], 4, axis=0)
        query = cuda(tile)
        for precision in MODES:
            run(model, query, example["noise"], precision)
        for trial in range(12):
            row = {}
            for policy in (MODES if trial % 2 == 0 else MODES[::-1]):
                output, elapsed = run(model, query, example["noise"], policy)
                row[policy] = elapsed
            durations.append(row)
        running = {}
        for example in old["standing"]:
            ref = example["input"]["sha256"], str(example["noise"])
            if ref not in running:
                with np.load(checked(example["input"]), allow_pickle=False) as raw:
                    args = {key:raw[key] for key in KEYS}
                fast, dt = run(model,cuda(args),example["noise"],"float16")
                running[ref] = fast,dt,args
            half, dt, fields = running[ref]
            full = np.load(checked(example["prediction"]), allow_pickle=False)
            x,y,w,h=example["roi"]
            coordinate = np.s_[..., y:y+h, x:x+w]
            transforms = [torch.from_numpy(fields[k]) for k in ("wb","matrix")]

            def display(rgb):
                preview = display_crop(torch.from_numpy(rgb), *transforms, example["roi"],exposure=example["exposure"])
                return np.rint(np.clip(preview,0,1)*255).astype(np.uint8)

            previews = [display(output) for output in (full,half)]
            img = root/f'{example["id"]}.png'
            Image.fromarray(np.concatenate(previews,axis=1)).save(img)
            scenes.append(dict(id=example["id"],crop=example["roi"],noise=example["noise"],raw=example["raw"],
                array=example["input"], exposure=example["exposure"],board=reference(img),
                error=error(full[coordinate],half[coordinate]), forward_ms=dt))
    write_json(root/"result.json",{
        "checkpoint":checkpoint,"weights":"EMA","prior":source,"same_coordinates":True,
        "precision":"IEEE FP32 and eager FP16 AMP, FP32 physical input/output paths",
        "driver":reference(__file__),"panel":dict(tagged),"standing":scenes,"profile":profile,
        "timing_512_B4_ms":durations,"timing_context":old["standing"][0]["input"],
        "timing_packed_crop_xywh":[x0,y0,256,256],"seconds":time.monotonic()-start,
    })
    print("Completed FP16 probe",len(tagged["photo"]),len(tagged["wire"]),len(scenes),flush=True)


if __name__ == "__main__":
    main()
