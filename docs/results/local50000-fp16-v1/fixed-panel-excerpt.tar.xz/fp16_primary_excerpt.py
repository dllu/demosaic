"""Check local 50k FP16 on canonical shadow, highlight, ADC and camera inputs."""
from pathlib import Path
import numpy as np
import torch

from probe_local_fp16 import BASELINE, ROOT, KEYS, cuda, error, run
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from collect_scene_primary_compact import score
from collect_scene_primary import numbers
from report_scene_wave_guides import native_board

@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root = ROOT / "fp16-extra"
    root.mkdir()
    parent = read_json(BASELINE / "review.json")
    checkpoint = parent["checkpoint"]
    stage = ROOT.with_name("scene-compact-47500-qualification-v1")
    canonical = read_json(stage / "plan.json")
    probes = read_json(checked(canonical["parent_CPU_probes"]))
    index = {(a["stage"], a["batch"]) for a in probes["records"]} | {("photo",i) for i in (21,22,23)}
    model, loaded = load_scene_checkpoint(checked(checkpoint), weights="ema", expected_sha256=checkpoint["sha256"])
    assert loaded["loaded_sha256"] == checkpoint["sha256"]
    model = _stage_tiled_cuda(model, "cuda")
    rows = []
    for record in read_json(checked(canonical["canonical_inputs"]))["records"]:
        if (record["stage"], record["batch"]) not in index:
            continue
        with np.load(checked(record["arrays"]),allow_pickle=False)as f:
            arrays = {k:f[k] for k in f.files}
        assert all(fingerprint(arrays[k]) == record["fingerprints"][k] for k in KEYS)
        profile = record["context"]["condition" if record["stage"] == "photo" else "noise"]
        a = cuda(arrays)
        exact,_ = run(model,a,profile,"float32")
        reduced,_ = run(model,a,profile,"float16")
        batch = {k: torch.from_numpy(v).cuda() for k,v in arrays.items()}
        summaries = [numbers(score(record["stage"], torch.from_numpy(x).cuda(), batch)) for x in (exact,reduced)]
        rows.append(dict(stage=record["stage"],batch=record["batch"],context=record["context"],
                         arrays=record["arrays"],quality=summaries,error=error(exact,reduced)))
    assert len(rows) == len(index)
    old = read_json(ROOT / "review/result.json")
    exact = []
    for item in old["exact"][:2]:
        with np.load(checked(item["inputs"]),allow_pickle=False) as z:
            args = {k:z[k] for k in (*KEYS,"target")}
        camera = {k:args[k][None] for k in ("wb","matrix","colors")}
        camera["packed"] = args["packed"][:1]
        one = camera | {"variance": args["variance"][:1]}
        fp32, _ = run(model,cuda(one),item["iso_profile"],"float32")
        fp16, _ = run(model,cuda(one),item["iso_profile"],"float16")
        exact.append(native_board(
            root,item["id"],[noisy_malvar(camera)[0],fp32[0],fp16[0],args["target"][0]],camera,
            {k:item[k] for k in ("source","query","inputs","iso_profile")},
            labels=("Noisy Malvar","Local 50k IEEE FP32","Local 50k FP16","Exact GT"),
            triplet_indices=(0,2,3),exposure=item["display_exposure"],contrast=item["display_contrast"],
            roi=item["ROI_xywh"],
        ))
    write_json(root/"result.json",dict(driver=reference(__file__),checkpoint=checkpoint,weights="ema",
        canonical_inputs=canonical["canonical_inputs"],comparison="CUDA IEEE FP32 and standard FP16 autocast",
        rows=rows,exact=exact))
    print(len(rows),len(exact),flush=True)

if __name__=="__main__":
    main()
