from pathlib import Path
import os
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from report_checkpoint_pilot import pixels
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
root=Path(__file__).absolute().parent;plan=read_json(root/'plan.json');out=root/'stress';out.mkdir()
os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:])
sources={a:Path(checked(b)).parent for a,b in plan['comparison_sources'].items()}
collections={a:{r['id']:r for r in read_json(p/'collection.json')['rows']}for a,p in sources.items()}
rows=read_json(root/'individual/plan.json')['rows'];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10);figures=[]
def board(name,row,values,selections,cal):
 canvas=Image.new('RGB',(848,192*len(selections)),'#eeeeee');draw=ImageDraw.Draw(canvas);panels=[]
 for iy,selection in enumerate(selections):
  roi=selection['ROI_xywh']
  for ix,(label,value)in enumerate(values.items()):
   cell=pixels(value,cal,roi,row['display_exposure']);x,y=8+168*ix,24+192*iy
   draw.text((x,y-19),label,font=font,fill='black');canvas.paste(Image.fromarray(cell),(x,y));panels.append((x,y,cell,label))
 path=out/(name+'.png');canvas.save(path);saved=np.asarray(Image.open(path))
 for x,y,cell,label in panels:np.testing.assert_array_equal(saved[y:y+160,x:x+160],cell)
 figures.append({'image':reference(path),'case':row['id'],'source':row,'selections':selections,'panels':[{'label':label,'xywh':[x,y,160,160]}for x,y,cell,label in panels],'display_exposure':row['display_exposure'],'display_contrast':1,'calibration':{k:v.tolist()for k,v in cal.items()},'no_resize':True})
for row in rows:
 if row['kind'] not in ['gfx','mesh']:continue
 values={'V120':np.load(checked(row['parent']),allow_pickle=False)[row['sample']:row['sample']+1]}
 values.update({a:np.load(checked(collections[a][row['id']]['predictions']['local-t2']),allow_pickle=False)[None]for a in sources})
 with np.load(checked(row['arrays']),allow_pickle=False)as z:cal={k:z[k][row['sample']:row['sample']+1]for k in ['wb','matrix']}
 selections=[]
 for arm in ['individual','background']:
  delta=np.abs(values[arm]-values['H1']).max(axis=(0,1));py,px=np.unravel_index(np.argmax(delta),delta.shape);h,w=delta.shape
  roi=[int(np.clip(px-80,0,w-160)),int(np.clip(py-80,0,h-160)),160,160]
  selections.append({'selector':arm+' minus H1 max absolute camera-RGB change','ROI_xywh':roi,'maximum_change_DN16':float(delta.max()*65535)})
 board(row['id']+'-max-changes',row,values,selections,cal)
 if row['id']=='main-building-detail':board('building-prior-failure-ROI',row,values,[{'selector':'Fixed prior H3-group building failure crop, chosen in the previous study','ROI_xywh':[0,334,160,160]}],cal)
write_json(out/'manifest.json',{'script':reference(__file__),'figures':figures,'scope':'All native160 cells unchanged, matching coordinates/display across five methods in each row. Top row selects maximal individual-minus-H1 change, bottom selects maximal background-minus-H1; fixed previous building failure crop also retained. Post-inference correction-only selections, no reference/GT selection or reference claimed at extra coordinates. Not representative sampling or full-context assurance.'})
print([(f['case'],f['selections'])for f in figures])
