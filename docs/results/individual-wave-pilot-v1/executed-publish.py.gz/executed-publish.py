from pathlib import Path
import gzip,shutil,tarfile
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
repo=Path.cwd();root=Path(__file__).absolute().parent
dest=repo/'docs/results/individual-wave-pilot-v1';dest.mkdir(parents=True,exist_ok=False)
images=repo/'docs/images/individual-wave-pilot-v1';images.mkdir(parents=True,exist_ok=False)
archives=[]
def archive(p,name):
 data=p.read_bytes();target=dest/(name+'.gz')
 with target.open('xb')as f:f.write(gzip.compress(data,mtime=0))
 assert gzip.decompress(target.read_bytes())==data
 archives.append({'original':reference(p),'archive':reference(target),'encoding':'gzip; exact original bytes'})
for name in ['plan.json','launch.json','status.json','legacy-equivalence.json','both-arms-closed-before-GT.json','comparison/summary.json','stress/manifest.json','viewing.json','quality-review.json']:
 archive(root/name,name.replace('/','-'))
for arm in ['individual','background']:
 for name in ['plan.json','analytic-model.json','owner.json','collection.json','finite-scores.json','report/report.json','independent-audit.json']:
  archive(root/arm/name,arm+'-'+name.replace('/','-'))
for key,folder in [('study',root),('individual',root/'individual'),('background',root/'background')]:
 plan=read_json(folder/'plan.json');work=Path(plan['work']);target=dest/(key+'-executed-sources.tar.gz')
 with tarfile.open(target,'x:gz')as tar:
  for p,digest in plan['frozen_files'].items():
   source=checked({'path':p,'sha256':digest});tar.add(source,arcname=str(source.relative_to(work)))
 archives.append({'archive':reference(target),'encoding':'tar.gz; exact frozen Python files','plan':reference(folder/'plan.json')})
for path in ['src/demosaic/local_validated_waves.py','tests/test_local_validated_waves.py','scripts/prepare_individual_wave_pilot.py','scripts/study_local_wave_shapes.py','scripts/report_local_wave_shapes.py']:
 target=dest/Path(path).name;shutil.copyfile(repo/path,target);archives.append({'original':reference(repo/path),'archive':reference(target),'encoding':'identical source bytes'})
for name in ['stress.py','report_local_wave_shapes.py','publish.py']:archive(root/name,'executed-'+name)
archive(repo/'.cache/local-wave-unit-tests-v1.log','focused-tests-initial56.log')
archive(repo/'.cache/local-wave-unit-tests-v2.log','focused-tests68.log')
boards=[]
for name,folder in [('comparison',root/'comparison'),('individual',root/'individual/report'),('background',root/'background/report'),('stress',root/'stress')]:
 (images/name).mkdir()
 for source in sorted(folder.glob('*.png')):
  target=images/name/source.name;shutil.copyfile(source,target);assert source.read_bytes()==target.read_bytes()
  boards.append({'original':reference(source),'copy':reference(target),'native_pixels_unchanged':True})
write_json(images/'manifest.json',{'boards':boards,'comparison_summary':reference(dest/'comparison-summary.json.gz'),'arm_reports':{a:reference(dest/(a+'-report-report.json.gz'))for a in ['individual','background']},'stress_selections':reference(dest/'stress-manifest.json.gz'),'scope':'Unchanged native160 cells; identical ROI/display per row/method. Source/ROI/noise/WB/matrix/domain checkpoints/configurations in archived manifests. Main/cab ISO100 references differ in aperture/exposure/motion; not exact GT. Both camera JPEGs retained. Extra stress ROIs claim no GT/reference.'})
write_json(dest/'publication.json',{'status':'completed-per-harmonic-and-background-pilot-with-native-review','archives':archives,'native_manifest':reference(images/'manifest.json'),'scope':'Two completed24-input arms/196 tiles each, no neural/source/noise/RAW/optimizer work. Legacy group regression exact. All48 close before new scoring; 68 tests. More per-harmonic discrimination has restricted gains and persistent bands; background does not solve failure. No broad/default promotion. All original receipts/outputs preserved.'})
print(len(archives),'archives;',len(boards),'native boards')
