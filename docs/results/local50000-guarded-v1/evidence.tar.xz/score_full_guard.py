"""Compare the full-frame RGB16 exports in camera codes and native crops."""
from pathlib import Path
import math

import numpy as np
import tifffile
import torch
from PIL import Image, ImageDraw
from scipy.ndimage import maximum_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop

ROOT = Path(__file__).resolve().parent / "guarded-full-frame"
POLICIES = ("fp32","fp16","guarded")


def histograms(rgb, base, raw):
    total = np.zeros((4, 65536), np.int64)
    maximum = (0,0,0)
    largest = -1
    for y in range(0, len(rgb), 128):
        bottom = min(y+128, len(rgb))
        delta = np.abs(rgb[y:bottom].astype(np.int32)-base[y:bottom])
        coordinates = np.unravel_index(delta.argmax(), delta.shape)
        high = int(delta[coordinates])
        if high > largest:
            largest = high
            maximum = (int(y+coordinates[0]), int(coordinates[1]), int(coordinates[2]))
        y0, y1 = max(0,y-5), min(len(rgb),bottom+5)
        near = maximum_filter(raw[y0:y1] >= .98, size=11)[y-y0:bottom-y0]
        selections = (delta, delta[near], delta[~near], delta[raw[y:bottom] >= .98])
        for i, selected in enumerate(selections):
            total[i] += np.bincount(selected.ravel(),minlength=65536)
    return total, maximum


def stats(counts):
    n = int(counts.sum())
    if n == 0:
        return {}
    cdf = np.cumsum(counts)
    codes = np.arange(len(counts), dtype=float)
    return dict(count=n, RMS_DN16=math.sqrt(np.sum(codes*codes*counts)/n),
                within1=float(cdf[1]/n), p999_DN16=int(np.searchsorted(cdf,0.999*n)),
                maximum_DN16=int(np.flatnonzero(counts)[-1]))


def draw(folder, name, images, calibration, box, exposure):
    wb, matrix = [torch.as_tensor(v).unsqueeze(0) for v in calibration]
    x,y,w,h=box
    assert w==h==160
    sheet=Image.new("RGB",(3*168+8,188),"#eeeeee")
    labels=ImageDraw.Draw(sheet)
    for i, policy in enumerate(POLICIES):
        img=images[policy][y:y+h,x:x+w].astype(np.float32)/65535
        out=display_crop(torch.from_numpy(img).permute(2,0,1)[None],wb,matrix,[0,0,w,h],exposure=exposure)
        pixels=np.rint(np.clip(out,0,1)*255).astype(np.uint8)
        labels.text((8+i*168,4),policy,fill="black")
        sheet.paste(Image.fromarray(pixels),(8+i*168,22))
    path=folder/(name+".png")
    sheet.save(path)
    return dict(image=reference(path),box=box,display_exposure=exposure)


def main():
    torch.set_num_threads(2)
    refs={policy:reference(ROOT/policy/"result.json")for policy in POLICIES}
    values={name:read_json(checked(ref)) for name,ref in refs.items()}
    base=values["fp32"]
    common=("raw","config","checkpoint","pattern","noise","wb","matrix")
    assert all(all(d[k]==base[k] for k in common)for d in values.values())
    assert sum(sum(r)for r in values["guarded"]["routes"])==131
    images={name:tifffile.memmap(checked(d["output"]),mode="r")for name,d in values.items()}
    assert all(img.dtype==np.uint16 and img.shape==(8746,11662,3)for img in images.values())
    raw, _ = read_raw(checked(base["raw"]))
    comparisons={}
    timing={name:d["timing"] for name,d in values.items()}
    for policy in ("fp16","guarded"):
        h, worst=histograms(images[policy],images["fp32"],raw)
        comparisons[policy]=dict(**{label:stats(counts)for label,counts in
            zip(("overall","near_clip_r5","away_from_clip","at_clip"),h,strict=True)}, worst_yxc=worst)
    out=ROOT/"review"
    out.mkdir()
    cfg=read_json(checked(base["config"]))
    calibration=(base["wb"],base["matrix"])
    boards={}
    for roi in cfg["regions"]:
        box=[*roi["noisy_xy"],160,160]
        name=roi["name"]
        boards[name]=draw(out,name,images,calibration,box,cfg["display_exposure"])
    for tag, result in comparisons.items():
        y,x,_=result["worst_yxc"]
        pos=[int(np.clip(x-80,0,raw.shape[1]-160)),int(np.clip(y-80,0,raw.shape[0]-160)),160,160]
        name=tag+"-largest-change"
        boards[name]=draw(out,name,images,calibration,pos,1.)
    write_json(out/"result.json",dict(
        driver=reference(__file__),arms=refs,comparisons_vs_FP32=comparisons,boards=boards,
        timing=timing,checkpoint=base["checkpoint"],raw=base["raw"],noise=base["noise"]))
    print(comparisons,flush=True)

if __name__=="__main__":
    main()
