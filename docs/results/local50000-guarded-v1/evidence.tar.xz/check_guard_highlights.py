"""Replay four held-out highlight batches through the full-frame guard."""
from pathlib import Path
import numpy as np
import torch

from guarded_full_frame import Guarded
from probe_local_fp16 import ROOT, KEYS, cuda, run
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    path=ROOT/"fp16-extra/result.json"
    witness=reference(path)
    prepared=read_json(checked(witness))
    identity=prepared["checkpoint"]
    model,state=load_scene_checkpoint(checked(identity),weights="ema",expected_sha256=identity["sha256"])
    assert state["mode"]=="none" and state["step"]==50000
    base=_stage_tiled_cuda(model.base.eval(),"cuda")
    candidate=Guarded(base).eval()
    rows=[]
    with ieee_fp32():
        for r in prepared["rows"]:
            if r["stage"]!="photo" or r["context"]["condition"]["name"]!="highlights":
                continue
            with np.load(checked(r["arrays"]),allow_pickle=False)as axes:
                packed=cuda({key:axes[key]for key in KEYS})
            profile=r["context"]["condition"]
            base.set_noise(profile["shot"],profile["read"])
            with torch.autocast("cuda", enabled=False):
                precise=base(*packed)
            result=candidate(*packed)
            rows.append(dict(batch=r["batch"],pattern=r["context"]["pattern"],arrays=r["arrays"],
                             routing=candidate.routing[-1],source_ids=r["context"]["ids"],
                             all_outputs_bit_exact=bool(torch.equal(result,precise)),
                             reference=fingerprint(precise),guarded=fingerprint(result)))
    assert len(rows)==4 and all(all(r["routing"]) and r["all_outputs_bit_exact"] for r in rows)
    out=ROOT/"guarded-full-frame/highlight-replay.json"
    write_json(out,dict(checkpoint=identity,source=witness,rows=rows,
        driver=reference(__file__),data="Four canonical highlights batches. All routed to IEEE FP32."))
    print(len(rows),sum(len(r["routing"])for r in rows),flush=True)

if __name__=="__main__":
    main()
