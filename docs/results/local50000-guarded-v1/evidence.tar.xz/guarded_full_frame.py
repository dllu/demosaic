"""Measure an FP32 near-saturation fallback on the full cached 102 MP frame."""
import argparse
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn

from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda, restore_tiled
from demosaic.io import read_raw, write_rgb16
from demosaic.precision import amp_context, ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

BASE = Path(__file__).resolve().parent
CONFIG = Path("configs/gfx-qualitative-20231231.json")
CHECKPOINT = Path("docs/results/scene-full-epoch-v1/local-050000-training.json")
THRESHOLD = .98


class Guarded(nn.Module):
    """Give tiles with near-saturated Bayer samples an IEEE FP32 forward."""

    def __init__(self, base):
        super().__init__()
        self.model = base
        self.config = base.config
        self.routing = []

    def set_noise(self, shot, read):
        self.model.set_noise(shot, read)

    def forward(self, *args):
        packed = args[0]
        selection = (packed.amax(dim=(1,2,3)) >= THRESHOLD).cpu().tolist()
        self.routing.append(selection)
        if all(selection):
            with amp_context("cuda", dtype="float32"):
                return self.model(*args)
        if not any(selection):
            with amp_context("cuda", dtype="float16"):
                return self.model(*args)
        result = torch.empty((len(packed),3,2*packed.shape[-2],2*packed.shape[-1]),
                             dtype=torch.float32,device=packed.device,memory_format=torch.channels_last)
        for high in (False, True):
            index = torch.tensor([i for i,v in enumerate(selection) if high == v],device=packed.device)
            fields = [v.index_select(0,index) for v in args]
            fields[:2] = [v.contiguous(memory_format=torch.channels_last) for v in fields[:2]]
            with amp_context("cuda",dtype="float32" if high else "float16"):
                rgb = self.model(*fields)
            result.index_copy_(0,index,rgb)
        return result


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("policy",choices=("fp16","fp32","guarded"))
    args = parser.parse_args()
    torch.set_num_threads(3)
    torch.backends.cudnn.benchmark = False
    target = BASE / "guarded-full-frame"
    target.mkdir(exist_ok=True)
    folder = target / args.policy
    folder.mkdir()
    setup = time.monotonic()
    config = read_json(CONFIG)
    path = Path(config["noisy"])
    assert path.is_relative_to(".cache/gfx-qualitative-20231231")
    source = reference(path)
    raw, metadata = read_raw(path)
    decoder_seconds = time.monotonic() - setup
    checkpoint = read_json(CHECKPOINT)["checkpoint"]
    started = time.monotonic()
    wrapper, values = load_scene_checkpoint(checked(checkpoint), weights="ema", expected_sha256=checkpoint["sha256"])
    assert values["mode"] == "none" and values["step"] == 50000
    del values
    model = _stage_tiled_cuda(wrapper.base.eval(), "cuda")
    model_seconds = time.monotonic() - started
    shot,read = .00128,6.5536e-6
    wb,matrix = metadata.white_balance,metadata.camera_to_srgb
    colors = color_indices(metadata.pattern)
    if args.policy == "guarded":
        model = Guarded(model)
    policy = "float32" if args.policy=="fp32" else "float16"
    with ieee_fp32():
        rgb, stats = restore_tiled(
            model, raw, colors, shot=shot, read=read, tile=512, overlap=64, batch_size=4,
            precision=policy, amp=args.policy!="guarded", wb=wb, matrix=matrix)
    export = folder/"linear.tiff"
    started = time.monotonic()
    write_rgb16(export,rgb.permute(1, 2, 0).numpy(),flip=0)
    encode_seconds = time.monotonic()-started
    writes = reference(export)
    route = model.routing if args.policy=="guarded" else []
    assert stats["tiles"]==520
    write_json(folder/"result.json", dict(
        raw=source,config=reference(CONFIG),checkpoint=checkpoint,driver=reference(__file__),
        weights="ema",pattern=metadata.pattern,noise={"shot":shot,"read":read}, wb=wb,matrix=matrix,
        policy=args.policy, threshold=THRESHOLD if route else None, routes=route,
        timing=stats|{"raw_decode_seconds":decoder_seconds,"load_seconds":model_seconds,"rgb16_encode_seconds":encode_seconds},
        output=writes))
    print(args.policy, stats["seconds"], "seconds", sum(sum(b)for b in route), "FP32 tiles via guard", flush=True)


if __name__=="__main__":
    main()
