"""Absolute zero/one/two-direction errors, after the entire cohort closes."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
R=Path.cwd();p=R/'.cache/experiments/phase-aggregation-pilot-v1';review=R/'.cache/experiments/phase-aggregation-review-v1';assert(review/'completed.json').exists();plan=read_json(p/'plan.json');collection=read_json(p/'collection.json');assert len(collection['rows'])==48;records={r['id']:r for r in collection['rows']};result=[];maximum_identity_error=0.
for group in plan['finite_groups']:
 with np.load(checked(group['arrays']),allow_pickle=False)as z:target=z['target'].astype(np.float64);masks={'full':np.ones(target.shape[-2:],bool),'quiet':z['quiet'],'edge':z['edge_band']}
 parent=next(r['parent']for r in plan['rows']if r['id']==group['cases'][0]);methods=['V143',*records[group['cases'][0]]['predictions']]
 for method in methods:
  value=np.load(checked(parent)).astype(np.float64)if method=='V143'else np.stack([np.load(checked(records[case]['predictions'][method]))for case in group['cases']]).astype(np.float64)
  for role in range(3):
   row={'profile':group['profile'],'source':group['metadata']['recipe']['source'],'placement':group['metadata']['placement'],'method':method,'role':role}
   for name,mask in masks.items():
    e=(value[role]-target[role])[:,mask];dc=e.mean(-1,keepdims=True);mse=float(np.vdot(e,e)/e.size);bias=float(np.mean(dc**2));spatial=float(np.mean((e-dc)**2));maximum_identity_error=max(maximum_identity_error,abs(mse-bias-spatial));row[name+'_RMS_DN16']=float(np.sqrt(mse)*65535);row[name+'_DC_RMS_DN16']=float(np.sqrt(bias)*65535);row[name+'_spatial_RMS_DN16']=float(np.sqrt(spatial)*65535)
   result.append(row)
assert len(result)==468 and maximum_identity_error<1e-14
write_json(review/'absolute-role-errors.json',{'script':reference(__file__),'plan':reference(p/'plan.json'),'collection':reference(p/'collection.json'),'rows':result,'maximum_mse_bias_spatial_identity_error':maximum_identity_error,'scope':'Absolute target errors separately on zero/one/two-direction roles, including edge-only role0; no cancellation through role differences. Every fixed method/threshold/cell retained, no fit or selection. Descriptive reused2-geometry/one-CFA/repeat cohort. Zero neural/noise/RAW/optimizer calls.'});print('absolute role rows',len(result),flush=True)
