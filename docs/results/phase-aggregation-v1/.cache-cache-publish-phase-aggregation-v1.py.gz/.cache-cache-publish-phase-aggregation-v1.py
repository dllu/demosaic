"""Publish closed, audited aggregation evidence without resampling native pixels."""
import gzip,html,json,shutil,tarfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
R=Path.cwd();E=R/'.cache/experiments';producer=E/'phase-aggregation-pilot-v1';review=E/'phase-aggregation-review-v1';assert(review/'completed.json').exists();report=read_json(review/'native/report.json');base=read_json(producer/'report/report.json');out=R/'docs/images/phase-aggregation-v1';pub=R/'docs/results/phase-aggregation-v1';out.mkdir(exist_ok=False);pub.mkdir(exist_ok=False);figures=[]
for folder,items in [('original',base['figures']),('matched',report['figures']),('stress',report['stress_figures'])]:
 (out/folder).mkdir()
 for item in items:
  source=checked(item['image']);dest=out/folder/source.name;dest.write_bytes(source.read_bytes());assert dest.read_bytes()==source.read_bytes();figures.append(dict(item,image=reference(dest),original_image=item['image']))
write_json(out/'manifest.json',{'images':figures,'analytic_model':reference(producer/'analytic-model.json'),'base_report':reference(producer/'report/report.json'),'matched_report':reference(review/'native/report.json'),'independent_audit':reference(review/'independent-audit.json'),'no_resize':True,'viewing_status':'Awaiting actual native viewing; independent encoded-pixel audits are separate.'})
for metric,name,label in [('quiet_error_RMS_DN16','tradeoff-quiet','Quiet RMS, DN16'),('weak_increment_error_RMS_DN16','tradeoff-increment','Weak-increment RMS, DN16')]:
 fig,axes=plt.subplots(2,3,figsize=(11,6),layout='constrained')
 for j,profile in enumerate(['iso400','iso1600','iso6400']):
  for i,placement in enumerate(['near','far']):
   ax=axes[i,j];rows={r['method']:r for r in report['means']if r['profile']==profile and r['placement']==placement};parent=rows['V143'];ax.scatter(parent[metric],100*parent['weak_gain'],marker='x',s=55,color='black',label='V143')
   for method,color,style,labeltext in [('H1-local','#305c9b','-','H1 local'),('H1-global','#305c9b',':','H1 global'),('local','#b94428','-','Aggregation local'),('global','#b94428',':','Aggregation global')]:
    values=[rows[f'{method}-t{t}']for t in [0,2,4]];ax.plot([r[metric]for r in values],[100*r['weak_gain']for r in values],style,marker='o',markersize=4,color=color,label=labeltext)
    for t,r in zip([0,2,4],values):ax.annotate(str(t),(r[metric],100*r['weak_gain']),fontsize=7,xytext=(3,3),textcoords='offset points')
   ax.set_title(profile+' '+placement+'; two reused sources');ax.set_xlabel(label);ax.set_ylabel('Weak response, % exact GT');ax.grid(alpha=.2)
 axes[0,0].legend(fontsize=7);fig.savefig(out/(name+'.png'),dpi=150);plt.close(fig)
body=['<!doctype html><meta charset="utf-8"><title>Phase measurement aggregation</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:28px 0;overflow:auto}img{max-width:none}</style><h1>Phase-aligned measurement aggregation</h1><p>One native pixel per PNG pixel; browser zoom100%. Fixed three-prior/two-source development pilot. Matched boards compare noisy, parent,H1local,aggregationlocal,reference and both cab JPEGs. Real references are qualitative, not GT. Stress ROIs are selected after inference by largest correction RMS and have no reference at the extra coordinates.</p>']
for item in [r for r in figures if '/matched/'in r['image']['path']or'/stress/'in r['image']['path']]:
 rel=Path(item['image']['path']).relative_to(out);body.append('<figure><figcaption>'+html.escape(str(rel))+'</figcaption><a href="'+str(rel)+'"><img src="'+str(rel)+'"></a></figure>')
(out/'native-viewer.html').write_text('\n'.join(body)+'\n');archives=[]
def archive(source,dest):
 dest.write_bytes(gzip.compress(source.read_bytes(),mtime=0));assert gzip.decompress(dest.read_bytes())==source.read_bytes();archives.append({'original':reference(source),'published':reference(dest),'decompressed_bytes_exact':True})
for root,prefix,names in [(producer,'producer',['plan.json','analytic-model.json','launch.json','controller.py','controller.log','owner.json','predict-launch.json','progress.json','collection.json','finite-scores.json','report/report.json','predict.log','score.log','report.log','audit.log','failed.json']), (review,'review',['plan.json','launch.json','controller.py','controller.log','closure.json','audit-launch.json','compare-launch.json','independent-audit.json','audit.log','compare.log','native/report.json','completed.json']), (R,'.cache',['.cache/phase-aggregation-tests-v1.log','.cache/phase-aggregation-tests-v2.log','.cache/phase-aggregation-auditor-backward-v1.json','.cache/phase-aggregation-auditor-backward-v1.log','.cache/publish-phase-aggregation-v1.py'])]:
 for name in names:
  source=root/name
  if source.exists():archive(source,pub/(prefix+'-'+name.replace('/','-').lstrip('.')+'.gz'))
source_archives=[]
for root,name in [(producer,'producer'),(review,'review')]:
 dest=pub/(name+'-executed-sources.tar.gz')
 with tarfile.open(dest,'x:gz')as t:
  for p in sorted((root/'work').rglob('*.py')):t.add(p,arcname=str(p.relative_to(root/'work')))
 with tarfile.open(dest,'r:gz')as t:
  for member in t.getmembers():assert t.extractfile(member).read()==(root/'work'/member.name).read_bytes()
 source_archives.append(reference(dest))
write_json(pub/'publication.json',{'archives':archives,'executed_sources':source_archives,'manifest':reference(out/'manifest.json'),'new_neural_forwards':0,'new_source_noise_draws':0,'RAW_decodes':0,'optimizer_steps':0,'scope':'All copied native PNG bytes and decompressed machine receipts exact. Original frozen profile-join audit failure retained, corrected separate audit uses unchanged numerical definitions. Human viewing remains separate.'});print('published',len(figures),'boards',len(archives),'exact receipt payloads',flush=True)
