"""Exact-owner closure watcher and separately frozen multi-prior postprocessing."""
from pathlib import Path
import os,subprocess,sys,json,psutil,time,hashlib
root=Path(__file__).absolute().parent;p=json.loads((root/'plan.json').read_text());producer=Path(p['producer']);owner=p['expected_owner'];work=Path(p['work']);python=str(Path('.venv/bin/python').absolute());began=time.monotonic()
def save(name,value):
 with(root/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
def ref(path):return{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
while True:
 try:
  q=psutil.Process(owner['pid']);alive=q.create_time()==owner['created']and q.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:alive=False
 if not alive:break
 if time.monotonic()-began>p['maximum_wait_seconds']:
  save('observation-timeout.json',{'producer_confirmed_live':True,'pid':q.pid,'created':q.create_time(),'scope':'Own watcher observation expired; producer remains untouched. No terminal or restart inference.'});sys.exit(2)
 time.sleep(10)
collection=json.loads((producer/'collection.json').read_text());assert len(collection['rows'])==48 and collection['plan']==p['producer_plan'];assert(producer/'report/report.json').exists();failure=json.loads((producer/'failed.json').read_text())if(producer/'failed.json').exists()else None
if failure is not None:assert failure['stage']=='audit',failure
save('closure.json',{'producer_controller_terminal':True,'collection':ref(producer/'collection.json'),'finite_scores':ref(producer/'finite-scores.json'),'report':ref(producer/'report/report.json'),'original_failure':failure,'scope':'Original48 input-only outputs and report closed; original numerical source/receipts retained. Corrected auditor adds noise profile to score identity; no prediction changes.'})
env=dict(os.environ);env['PYTHONPATH']=str(work/'src')+':'+str(work/'scripts');env['CUDA_VISIBLE_DEVICES']='';env['OPENBLAS_NUM_THREADS']='2';env['OMP_NUM_THREADS']='2'
for stage,script,args in [('audit','audit_local_wave_pilot.py',[str(producer),'--output',str(root/'independent-audit.json')]),('compare','report_phase_aggregation.py',[str(producer),str(root/'native')])]:
 with(root/(stage+'.log')).open('xb')as log:
  child=subprocess.Popen([python,str(work/'scripts'/script),*args],stdout=log,stderr=subprocess.STDOUT,env=env);save(stage+'-launch.json',{'pid':child.pid,'created':psutil.Process(child.pid).create_time(),'script':ref(work/'scripts'/script)});code=child.wait()
 if code:save('failed.json',{'stage':stage,'exit_code':code});sys.exit(code)
save('completed.json',{'status':'full48-independent-audit-and-native-comparisons-awaiting-actual-viewing','independent_audit':ref(root/'independent-audit.json'),'report':ref(root/'native/report.json'),'new_neural_forwards':0})
