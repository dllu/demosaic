"""Input-only nuisance-projection check on the already exposed building failure."""
from pathlib import Path
import os,time
import numpy as np
from PIL import Image,ImageDraw
from demosaic.phase_aggregation import restore_phase_aggregation,PhaseAggregateConfig
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.archive_metrics import display,noisy_malvar
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());p=read_json(root/'plan.json');os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:]);row=p['row'];
with np.load(checked(row['arrays']),allow_pickle=False)as z:packed=z['packed'][row['sample']];colors=z['colors'][row['sample']]
parent=np.load(checked(row['parent']))[row['sample']];began=time.monotonic();values,aux=restore_phase_aggregation(parent,packed,colors,shot=row['noise']['shot'],read=row['noise']['read'],thresholds=(2.,),geometry_config=LocalWaveConfig(**p['geometry_config']),aggregation_config=PhaseAggregateConfig(**p['aggregation_config']));records={}
for(mode,t),value in values.items():
 path=root/(mode+'.npy');np.save(path,value,allow_pickle=False);records[mode]=reference(path)
old=np.load(checked(p['original_aggregation']));expected_h1=np.load(checked(p['original_H1']));assert np.array_equal(values['H1-local',2.],expected_h1);q=values['local',2.];error=np.mean((q.astype(np.float64)-parent)**2,axis=0);integral=np.pad(error.cumsum(0).cumsum(1),((1,0),(1,0)));energy=integral[160:,160:]-integral[:-160,160:]-integral[160:,:-160]+integral[:-160,:-160];y,x=np.unravel_index(np.argmax(energy),energy.shape);rois=[[176,176,160,160],[76,260,160,160],[int(x),int(y),160,160]];figures=[]
with np.load(checked(row['arrays']),allow_pickle=False)as z:data={k:z[k][row['sample']:row['sample']+1]for k in ['packed','colors','wb','matrix']}
for i,roi in enumerate(rois):
 x,y,w,h=roi;canvas=Image.new('RGB',(848,192),'#eee');draw=ImageDraw.Draw(canvas)
 for j,(label,v)in enumerate(zip(['Noisy Malvar','V120','H1 local2','Original aggregation','Projected aggregation'],[noisy_malvar(data),parent[None],expected_h1[None],old[None],q[None]],strict=True)):
  pixels=np.rint(display(v[...,y:y+h,x:x+w],data,exposure=4)[0].transpose(1,2,0)*255).astype(np.uint8);px=8+j*168;canvas.paste(Image.fromarray(pixels),(px,24));draw.text((px,5),label,fill='black')
 path=root/f'building-{i}.png';canvas.save(path);figures.append({'image':reference(path),'ROI_xywh':roi,'display_exposure':4,'no_resize':True,'reference':'No GT/ISO100/reference at these comparisons; existing failure ROI and new correction-max ROI explicitly selected after inference.'})
def rms(v,roi):
 x,y,w,h=roi;return float(np.sqrt(np.mean((v[:,y:y+h,x:x+w].astype(np.float64)-parent[:,y:y+h,x:x+w])**2))*65535)
write_json(root/'result.json',{'plan':reference(root/'plan.json'),'predictions':records,'figures':figures,'original_failure_ROI':rois[1],'old_correction_RMS_DN16':rms(old,rois[1]),'projected_correction_RMS_DN16':rms(q,rois[1]),'new_max_ROI':rois[2],'new_max_correction_RMS_DN16':rms(q,rois[2]),'H1_control_byte_exact':True,'seconds':time.monotonic()-began,'target_or_reference_arrays_loaded':0,'new_neural_forwards':0,'scope':'Development input-only check of consistent nuisance projection, fixed original raw-only geometry/support; no target fit. Not broad quality evidence.'});print('oldROI',rms(old,rois[1]),'newROI',rms(q,rois[1]),'newmax',rms(q,rois[2]),flush=True)
