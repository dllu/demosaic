"""Single-owner serial prediction/closed-cohort report/audit; never restart workers."""
from pathlib import Path
import os,subprocess,sys,time,json,psutil
root=Path(__file__).absolute().parent;plan=json.loads((root/'plan.json').read_text());python=str(Path('.venv/bin/python').absolute());work=Path(plan['work']);env=dict(os.environ);env['PYTHONPATH']=str(work/'src')+':'+str(work/'scripts');env['CUDA_VISIBLE_DEVICES']='';env['OPENBLAS_NUM_THREADS']='2';env['OMP_NUM_THREADS']='2'
def save(name,value):
 with(root/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
for stage,script,args in [('predict','pilot_phase_aggregation.py',['predict',str(root)]),('score','pilot_phase_aggregation.py',['score',str(root)]),('report','report_local_validated_waves.py',[str(root)]),('audit','audit_local_wave_pilot.py',[str(root)])]:
 with(root/(stage+'.log')).open('xb')as log:
  process=subprocess.Popen([python,str(work/'scripts'/script),*args],stdout=log,stderr=subprocess.STDOUT,env=env)
  save(stage+'-launch.json',{'pid':process.pid,'created':psutil.Process(process.pid).create_time(),'stage':stage,'command':[python,str(work/'scripts'/script),*args]});code=process.wait()
 if code:
  save('failed.json',{'stage':stage,'exit_code':code,'scope':'No worker restart or signals; original receipts retained.'});sys.exit(code)
save('completed.json',{'status':'all48-predicted-scored-rendered-independently-audited-awaiting-native-viewing','neural_forwards':0,'scope':plan['scope']})
