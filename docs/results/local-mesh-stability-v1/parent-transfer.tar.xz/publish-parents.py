"""Bind the parent-transfer extension without rewriting the original publication."""
import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
output = repo / "docs" / "results" / "local-mesh-stability-v1"
images = repo / "docs" / "images" / "local-mesh-stability-v1" / "parent-transfer"
images.mkdir()
source = read_json(root / "parents.json")
assert len(source["cases"]) == 8
notes = {
    "main-overcast-sky-main-overcast-sky": "Both corrected skies match their smooth parent.",
    "main-building-detail-main-building-detail": "Both retain the parent beams, hardware, and soft fine lines.",
    "main-foliage-main-foliage": "Both retain existing parent leaf-edge and shadow detail.",
    "main-chain-link-fence-main-chain-link-fence": "Both retain coarse crossings, with subtly different local changes.",
    "mesh-nominal-fine-green-mesh-left": "Both gains are visible as faint, slightly regular crossings, especially left of the post.",
    "mesh-nominal-fine-green-mesh-right": "Both preserve the soft parent outputs and their incomplete wire crossings.",
    "mesh-profile3879-fine-green-mesh-left": "Both show the fine repeating pattern around the horizontal wire. Independent references show substantially stronger crossings.",
    "mesh-profile3879-fine-green-mesh-right": "Both keep their parents, including weak diagonal modulation and patchiness.",
}
for row in source["cases"]:
    original = checked(row["image"])
    with Image.open(original) as im:
        for panel in row["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160) and x+w <= im.width and y+h <= im.height
    active = [v["RMS_DN16"] > 0 for v in row["results"].values()]
    assert all(active) or not any(active)
    if all(active):
        p = images / original.name
        shutil.copyfile(original, p)
        row["published"] = reference(p) | {"path": str(p.relative_to(repo))}
        assert row["image"]["sha256"] == row["published"]["sha256"]
    else:
        assert all(v["exact_parent"] for v in row["results"].values()), row["id"]
    row["actual_native_viewing"] = notes[row["id"]]
assert sum("published" in r for r in source["cases"]) == 3
files = [root / n for n in ("parents.py", "parents.json", "parents.log", "publish-parents.py")]
archive = output / "parent-transfer.tar.xz"
with tarfile.open(archive, "x:xz") as f:
    for path in files:
        f.add(path, arcname=path.name)
with tarfile.open(archive, "r:xz") as f:
    for path in files:
        assert hashlib.sha256(f.extractfile(path.name).read()).hexdigest() == reference(path)["sha256"]
write_json(output / "parent-transfer.json", source | {"published_utc": datetime.now(UTC).isoformat(),
    "source_bundle": reference(archive) | {"path": str(archive.relative_to(repo))},
    "archived_originals": [reference(p) for p in files], "all_eight_native_viewed": True,
    "scope": "Same two retained camera observations, three noise settings across the main and fine cab scenes and same native display. V120 and 100k fields come from their bound archives, compared with unchanged local-2k correction records. Three changed comparison boards published. All other delivered native crops exactly equal their respective neural parents. No training or primary-panel measurements."})
