"""Test matched V120/100k parent fields with exactly the delivered crop helper."""
import os
import time
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import refine_local_raw_mesh
from standing import legacy

root = Path(__file__).resolve().parent
os.sched_setaffinity(0, [12, 13])
os.nice(12)
matcher = root.parent / "expanded-scene-12000-native-v1"
plan = read_json(matcher / "plan.json")
collections = {"V120": plan["baseline_collection"], "100k": reference(matcher / "parent/collection.json")}
loaded = {k: read_json(checked(v)) for k, v in collections.items()}
fields = {k: {x["id"]: x for x in v["records"]} for k, v in loaded.items()}
checkpoints = {k: v["checkpoint"] for k, v in loaded.items()}
source = read_json(root / "camera.json")
output = root / "parents"
output.mkdir()
results = []
for row in source["rows"]:
    ob = next(o for o in plan["observations"] if row["id"].startswith(o["id"] + "-"))
    assert row["input"] == ob["arrays"]
    name = ob["id"]
    assert fields["V120"][name]["input_fingerprints"] == fields["100k"][name]["input_fingerprints"]
    with np.load(checked(row["input"]), allow_pickle=False) as inputs:
        arrays = {k: inputs[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
    raw, variance, colors = (arrays[k][0] for k in ("packed", "variance", "colors"))
    x, y, w, h = row["native_ROI"]
    new_panels = []
    details = {}
    with np.load(checked(row["corrections"]), allow_pickle=False) as arrays_old:
        v = arrays_old["combined"].astype(float).ravel()
    for method, prediction in fields.items():
        bound = prediction[name]["prediction"]
        field = np.load(checked(bound), allow_pickle=False)[0]
        base = field[:, y:y+h, x:x+w]
        start = time.monotonic()
        candidate = refine_local_raw_mesh(field, raw, variance, colors, row["native_query"], row["native_ROI"],
                               shot=row["noise"]["shot"], read=row["noise"]["read"], donor_span=112 if name.startswith("mesh-") else 80)
        correct = (candidate - base).astype(float).ravel()
        elapsed = time.monotonic() - start
        magnitude = float(np.linalg.norm(correct))
        agreement = float(v @ correct / np.linalg.norm(v) / magnitude) if magnitude and np.any(v) else None
        rms = magnitude / np.sqrt(correct.size) * 65535
        details[method] = {"prediction": bound, "RMS_DN16": rms, "cosine_to_local2k_correction": agreement,
                           "CPU_seconds": elapsed, "exact_parent": bool(np.array_equal(base, candidate))}
        if method == "100k":
            new_panels.append(("100k EMA", legacy.pixel(base, arrays, (0, 0, w, h), row["display_exposure"])))
        new_panels.append((method + " + anchored", legacy.pixel(candidate, arrays, (0, 0, w, h), row["display_exposure"])))
    old = {"image": row["image"], "panels": row["panels"]}
    old["panels"] = [p for p in old["panels"] if p["label"] not in ("Local-only2k", "Prior at original box", "Median, moving split", "Median, anchored split")]
    new, panels = legacy.insert_camera_panels(output, row["id"], old, "V120 EMA", new_panels)
    results.append({"id": row["id"], "source_arrays": row["input"], "ROI": row["native_ROI"], "noise": row["noise"],
                    "exposure": row["display_exposure"], "results": details, "image": new, "panels": panels})
    print(row["id"], [(m, round(v["RMS_DN16"], 3), v["cosine_to_local2k_correction"]) for m,v in details.items()], flush=True)
write_json(root / "parents.json", {"driver": reference(__file__), "plan": reference(matcher / "plan.json"), "collections": collections,
    "checkpoints": checkpoints, "mesh_camera": reference(root / "camera.json"), "cases": results})
