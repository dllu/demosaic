"""Compare localized donor support on the fixed standing GFX crops."""

import dataclasses
import importlib.util
import os
import sys
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from mesh import restore
from support import infer_prior, query_phases

ROOT=Path(__file__).resolve().parent
EARLIER=ROOT.parent/"multiline-raw-shoulders-v1"
sys.path.append(str(EARLIER))
spec=importlib.util.spec_from_file_location("native_reference_layout",EARLIER/"standing.py")
legacy=importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)


from guard import dual_support


