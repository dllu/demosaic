"""Replay a fixed donor prior with anchored reserve groups and overlap consensus."""

import numpy as np
from audit import heldout
from confirm import admit
from guard import dual_support


def window(a,box,phase=1):
    x,y,w,h=(v//phase for v in box)
    return a[...,y:y+h,x:x+w]


def correction(field,raw,var,c,box,roi,freq,noise,*,packed_offset=0):
    if freq is None:
        return np.zeros_like(window(field,roi)),{"status":"no exterior pair"}
    current=window(field,box)
    query=window(raw,box,phase=2)
    evidence=heldout(query,c,freq,noise,packed_offset=packed_offset)
    state={"extra":evidence,"status":"extra RAW check rejected"}
    if not admit(evidence):
        return np.zeros_like(window(field,roi)),state
    out,fit=dual_support(current,query,window(var,box,phase=2),c,freq,noise,
                         packed_offset=packed_offset)
    x,y,w,h=roi
    translated=x-box[0],y-box[1],w,h
    delta=window(out[-1]-current,translated)
    return delta, state|{"status":fit["status"],"guides":fit.get("guides")}


def median_correction(variants):
    """Use a strict majority of supported queries, then a signed median."""
    active=np.array([np.any(v) for v in variants])
    if active.sum()<=len(variants)//2:
        return np.zeros_like(variants[0])
    return np.median(np.stack(variants),axis=0).astype(variants[0].dtype)
