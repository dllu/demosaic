"""Pool measured amplitudes and keep them only in jointly supported neighborhoods."""

import dataclasses

import numpy as np

from demosaic.isolated_line import coordinates
from mesh import restore
from support import query_phases


def dual_support(p,raw,var,c,freq,noise,*,packed_offset=0):
    if not freq:
        return [p,p,p],{"status":"no exterior pair"}
    guides,reserve,q=query_phases(raw,c,freq,noise,refine=True,packed_offset=packed_offset)
    conditioning=noise["shot"],noise["read"]
    front,f=restore(p,raw,var,c,guides[::-1],conditioning,method="add",reserved=reserve)
    rear,r=restore(p,raw,var,c,guides,conditioning,method="adaptive",reserved=reserve)
    admission={"front":f,"rear":r,"guides":[dataclasses.asdict(a) for a in guides],
               "reserved_phase_scores":q}
    if max(q)<3 or any(i[0]["basis"] is None for i in (f,r)):
        return [p,p,p],admission|{"status":"global front/rear prediction rejected"}
    _,f_local=restore(p,raw,var,c,guides[::-1],conditioning,method="add",
                      local=True,reserved=reserve,dense=True)
    _,r_local=restore(p,raw,var,c,guides,conditioning,method="adaptive",
                      local=True,reserved=reserve,dense=True)
    h,w=p.shape[-2:]
    x,y=coordinates(h,w,origin=(-(w-1)/2,-(h-1)/2))
    mask=np.zeros_like(x)
    normalization=np.zeros_like(x)
    for a,b in zip(f_local,r_local,strict=True):
        assert a["center"]==b["center"]
        cx,cy=a["center"]
        taper=np.maximum(0,1-np.abs(x-cx)/64)*np.maximum(0,1-np.abs(y-cy)/64)
        normalization+=taper
        # Local fits only validate the footprint. They never replace the broad
        # amplitude estimate. An unsupported direction stops both corrections.
        mask+=taper*min(a["blend"],b["blend"])
    mask/=np.maximum(normalization,1e-8)
    add=front.astype(float)+rear.astype(float)-p
    guard=p+mask[None]*(add-p)
    return [rear,add.astype(p.dtype),guard.astype(p.dtype)],admission|{
       "status":"dual predictions supported","front_local":f_local,"rear_local":r_local,
       "mean_local_weight":float(mask.mean()),"nonzero_local_area":float(np.count_nonzero(mask)/mask.size)}
