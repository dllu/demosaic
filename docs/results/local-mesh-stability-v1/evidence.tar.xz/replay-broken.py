"""Reconstruct the one newly admitted broken-wire case from its recorded seed."""

import os
import sys
from pathlib import Path

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from report_scene_wave_guides import native_board
from run import DISPLAY, expansion, sample, score

root = Path(__file__).resolve().parent
repo = root.parents[2]
os.sched_setaffinity(0, [12, 13])
os.nice(12)
torch.set_num_threads(2)
plan = read_json(root / "plan.json")
key = "iso400-broken-g111-r0"
source = root / "cases" / (key + ".json")
case = read_json(source)
noise = plan["noise"][case["profile"]]
inputs, surrounds, masks, meta = sample(case["g"], case["layout"], noise, case["sensor_seed"])
assert {k: fingerprint(v) for k, v in inputs.items()} == case["input_fingerprints"]
arrays = {k: v.numpy() for k, v in inputs.items()}
bound = plan["checkpoint"]
torch.cuda.set_per_process_memory_fraction(min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
model, payload = load_scene_checkpoint(checked(bound), device="cuda", weights="ema", expected_sha256=bound["sha256"])
assert payload["step"] == 2000
model.mode = "none"
model.base.set_noise(noise["shot"], noise["read"])
with torch.inference_mode(), ieee_fp32():
    parent = model(*(inputs[k].cuda() for k in ("packed", "variance", "colors", "wb", "matrix"))).cpu().numpy()
x, y, w, h = DISPLAY
rows = []
for i in range(3):
    outputs, checks = expansion(arrays["packed"][i], arrays["variance"][i], parent[i], arrays["colors"][i],
                                case["frequency_priors"]["matching"], noise)
    rows.append(outputs)
versions = []
for method in ("original", "moving-median", "anchored-median"):
    delta = np.stack([row[method] for row in rows])
    actual = score(parent, delta, arrays["target"], masks)
    saved = case["measurements"]["matching-" + method]
    for metric in ("response", "increment_RMS_DN16", "gap_added_RMS_DN16", "gap_error_RMS_DN16"):
        np.testing.assert_allclose(actual[metric], saved[metric], rtol=0, atol=1e-12)
    field = parent.copy()
    field[..., y:y+h, x:x+w] += delta
    versions.append(field[1])
values = [noisy_malvar(arrays)[1], parent[1], *versions, arrays["target"][1]]
out = repo / "docs" / "images" / "local-mesh-stability-v1"
board = native_board(out, key, values, {k: arrays[k][1:2] for k in ("wb", "matrix")},
    {"case": reference(source), "checkpoint": bound, "CFA_planes": arrays["colors"][1].tolist(), "noise": noise},
    labels=("Noisy Malvar", "Local trunk", "Original box", "Moving median", "Anchored median", "Exact GT"),
    triplet_indices=(0, 4, 5), exposure=1, roi=DISPLAY, contrast=8)
write_json(root / "replay-broken.json", {"driver": reference(__file__), "board": board})
