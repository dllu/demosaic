"""Compare scene-anchored sampling and overlap consensus on the same native regions."""

import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from stabilize import correction,median_correction,window
from standing import legacy

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"local-mesh-origin-v1"
LATTICE=ROOT.parent/"local-donor-mesh-guard-v1"


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    torch.set_num_threads(2)
    prior=read_json(SOURCE/"result.json")
    old=read_json(checked(prior["previous_camera"]))
    source=read_json(legacy.SAVED)
    plan=read_json(checked(old["source_plan"]))
    obs={r["id"]:r for r in plan["observations"]}
    orig_boards={r["id"]:r for r in source["boards"]}
    out=ROOT/"camera"
    out.mkdir()
    rows=[]
    launch=time.monotonic()
    for entry in prior["cases"]:
        old=entry["old"]
        case=entry["id"]
        planned=obs[next(k for k in obs if case.startswith(k+"-"))]
        raw_ref=entry["source_arrays"]
        assert raw_ref==planned["arrays"]
        with np.load(checked(raw_ref),allow_pickle=False) as a:
            data={k:a[k] for k in ("packed","variance","colors","wb","matrix")}
        raw,var,colors=(data[k][0] for k in ("packed","variance","colors"))
        field=np.load(checked(entry["matched_parent"]),allow_pickle=False)[0]
        prior_freq=entry["shifted"]["frozen-donors"][0]["frequency_prior"]
        roi=entry["native_roi"]
        crop=window(field,roi)
        centre=old["query"]
        all_corrections,checks=[],[]
        for x,y in prior["translations_native_xy"]:
            box=centre[0]+x,centre[1]+y,256,256
            z,witness=correction(field,raw,var,colors,box,roi,prior_freq,old["noise"],packed_offset=x//2)
            all_corrections.append(z)
            checks.append({"shift":[x,y],"fit":witness})
        with np.load(checked(entry["correction_arrays"]),allow_pickle=False) as f:
            previous=f["frozen-donors"]
        np.testing.assert_array_equal(previous[0],all_corrections[0])
        anchored=np.asarray(all_corrections)
        zero=np.zeros_like(crop)
        combined=median_correction(anchored)
        unanchored=median_correction(previous)
        variant={"Prior at original box":previous[0],"Median, moving split":unanchored,
                 "Median, anchored split":combined}
        effects={}
        comparisons=[]
        for name,a in variant.items():
            effects[name]={"RMS_DN16":float(np.sqrt(np.mean(a.astype(float)**2))*65535),
                           "peak_DN16":float(np.max(np.abs(a.astype(float)))*65535)}
            comparisons.append((name,legacy.pixel(crop+a,data,(0,0,roi[2],roi[3]),old["display_exposure"])))
        board=orig_boards[case]
        kept={**board,"panels":[v for v in board["panels"] if v["label"] not in ("Pooled2k","Spatial2k")]}
        image,panels=legacy.insert_camera_panels(out,case,kept,"Local-only2k",comparisons)
        path=out/(case+"-comparison-arrays.npz")
        np.savez_compressed(path,anchored=anchored,unanchored=previous,combined=combined,
                            unanchored_median=unanchored)
        rows.append({"id":case,"image":image,"panels":panels,"input":raw_ref,"matched_parent":entry["matched_parent"],
            "noise":old["noise"],"display_exposure":old["display_exposure"],"native_ROI":roi,
            "native_query":centre,"effects":effects,"evidence":checks,"corrections":reference(path)})
        print(case,np.count_nonzero(anchored.reshape(len(anchored),-1).any(1)),
              [round(x["RMS_DN16"],3) for x in effects.values()],round(time.monotonic()-launch,2),flush=True)
    assert len(rows)==8
    write_json(ROOT/"camera.json",{"driver":reference(__file__),"method":reference(ROOT/"stabilize.py"),
         "source":reference(SOURCE/"result.json"),"rows":rows,"checkpoint":old["rows"][0]["checkpoint"],
         "scope":"One donor pair from the original local fitting region, independent of overlapping query shifts. The native Bayer phase discovery and the extra RAW verification use the same absolute sensor columns across translated queries. An empirical strict majority and signed median combine the aligned corrections."})


if __name__=="__main__":
    main()
