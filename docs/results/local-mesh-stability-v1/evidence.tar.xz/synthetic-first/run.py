"""Fresh translated-query studies with one fixed noisy parent per observed field."""

import dataclasses
import importlib.util
import math
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise,variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from mesh import ribbon
from stabilize import correction,median_correction,window
from support import infer_prior

ROOT=Path(__file__).resolve().parent
SHAPE_SOURCE=ROOT.parent/"joint-mesh-phase-v1/run.py"
spec=importlib.util.spec_from_file_location("mesh_shape_generation",SHAPE_SOURCE)
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
WIRE=ROOT.parent/"scene-wire-gap-v1"
SIZES=(320,768)
GEOMETRY=range(110,116)
LAYOUTS=("occluded","broken")
PRIORS=prior.PRIORS
SHIFTS=[(0,0)]+[(dx,dy) for s in (2,8,16) for dx,dy in ((s,0),(-s,0),(0,s),(0,-s))]
CENTRE=(32,32,256,256)
DISPLAY=(80,80,160,160)
EXTERIOR_QUERY=(256,256,256,256)


def sample(g,layout,noise,seed):
    geometry=prior.guides(g)
    x,y=coordinates(320,320,origin=(-159.5,-159.5))
    a,b=(ribbon(x,y,k) for k in geometry)
    base=np.array([.267,.298,.328])[:,None,None]+.015*x/320-.017*y/320
    base=base+.003*np.sin(.028*x+.023*y)
    p=base+.04*prior.STRONG*a
    extent=np.ones_like(x)
    if layout=="broken":
        along=x+.28*y-(g%3-1)*26
        t=np.clip((np.abs(along)-30)/16,0,1)
        extent=t*t*(3-2*t)
        edge=.5+.5*np.tanh((.44*x-y+23)/2.3)
        p=p+np.array([.018,.023,.012])[:,None,None]*edge
    r=p+(.0031 if g%2 else .0027)*prior.FAINT*b*(1-a)*extent
    p,r,flat=(torch.from_numpy(z.astype(np.float32)) for z in (p,r,base))
    raw,noise_metadata=paired_observation(p[None],r[None],noise,[tuple(PATTERNS)[g%4]],
                                         torch.ones(1,3),torch.eye(3)[None],seed)
    inputs={k:torch.from_numpy(raw[k]) for k in ("packed","variance","target","colors","wb","matrix")}
    colors=inputs["colors"][0]
    flat_raw=add_noise(mosaic(flat[None],colors),noise["shot"],noise["read"],black_level=.03,
                       generator=torch.Generator().manual_seed(seed+2393))
    for k,v in (("packed",flat_raw),("variance",variance_map(flat_raw,noise["shot"],noise["read"])),
                ("target",flat[None]),("colors",inputs["colors"][:1]),
                ("wb",inputs["wb"][:1]),("matrix",inputs["matrix"][:1])):
        inputs[k]=torch.cat((inputs[k],v))
    xx,yy=coordinates(768,768,origin=(-383.5,-383.5))
    core=np.array([.246,.285,.326])[:,None,None]+.025*xx/768-.013*yy/768
    presence=np.zeros_like(xx)
    for cx,cy in ((-220,50),(242,(g%3-1)*45),((g%3-1)*66,214)):
        s=np.clip((110-np.maximum(abs(xx-cx),abs(yy-cy)))/20,0,1)
        presence=np.maximum(presence,s*s*(3-2*s))
    angle=.35
    rotate=np.array([[math.cos(angle),-math.sin(angle)],[math.sin(angle),math.cos(angle)]])
    bad=tuple(dataclasses.replace(k,frequency=tuple(rotate@k.frequency)) for k in geometry)
    surrounds={}
    for name,proposal in (("matching",geometry),("unrelated",bad),("quiet",None)):
        field=core.copy()
        if proposal:
            f1,f2=(ribbon(xx,yy,f) for f in proposal)
            field+=presence*(.092*prior.STRONG*f1+.066*prior.FAINT*f2)
        sensor=mosaic(torch.from_numpy(field.astype(np.float32))[None],colors)
        surrounds[name]=add_noise(sensor,noise["shot"],noise["read"],black_level=.03,
            generator=torch.Generator().manual_seed(seed+794))[0].numpy()
    return inputs,surrounds,{"strong_phase":a,"weak_phase":b,"support":extent},noise_metadata


def score(parent,output,truth,masks):
    arguments=(window(parent,CENTRE),window(truth,CENTRE),
               {k:window(v,CENTRE) for k,v in masks.items()})
    parent_crop,clean,regions=arguments
    if output is None:
        return prior.metrics(parent_crop,parent_crop,clean,regions)
    restored=parent_crop.copy()
    restored[...,48:208,48:208]+=output
    return prior.metrics(restored,parent_crop,clean,regions)


def expansion(packed,var,field,colors,prior_freq,noise):
    original=[]
    anchored=[]
    states=[]
    for dx,dy in SHIFTS:
        actual=(CENTRE[0]+dx,CENTRE[1]+dy,256,256)
        shifted,witness=correction(field,packed,var,colors,actual,DISPLAY,prior_freq,noise,packed_offset=dx//2)
        anchored.append(shifted)
        states.append(witness)
        if not dx and not dy:
            original.append(shifted)
        else:
            value,_=correction(field,packed,var,colors,actual,DISPLAY,prior_freq,noise)
            original.append(value)
    return {"original":original[0],"moving-median":median_correction(original),
            "anchored-median":median_correction(anchored)},{
         "queries":states,"anchored_active":sum(a.any() for a in anchored),
         "moving_active":sum(a.any() for a in original)}


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    ckpt=read_json(WIRE/"plan.json")["checkpoint"]
    plan={
        "source":reference(__file__),"method":reference(ROOT/"stabilize.py"),"support":reference(ROOT/"support.py"),
        "target_geometry":reference(SHAPE_SOURCE),"checkpoint":ckpt,"query_field":SIZES[0],"exterior_field":SIZES[1],
        "query":CENTRE,"ROI":DISPLAY,"noise":PRIORS,"layouts":LAYOUTS,"shifts":SHIFTS,"geometries":list(GEOMETRY),
        "repeats":[0,1],"seed_basis":178998122709,
        "scope":"Fresh 48 pairs from six new geometries and fixed identical 320x320 local parent outputs. Three independent exterior patterns share one query observation, and each candidate sees the same donor frequency pair across query translations. Signed median only delivers if a strict majority of query placements support a correction.",
    }
    write_json(ROOT/"plan.json",plan)
    model,payload=load_scene_checkpoint(checked(ckpt),device="cuda",weights="ema",expected_sha256=ckpt["sha256"])
    assert payload["step"]==2000
    model.mode="none"
    folder=ROOT/"cases"
    folder.mkdir()
    began=time.monotonic()
    records=[]
    with ieee_fp32():
        for np_,(noise_id,noise) in enumerate(PRIORS.items()):
            model.base.set_noise(noise["shot"],noise["read"])
            for li,layout in enumerate(LAYOUTS):
                for g in GEOMETRY:
                    for k in (0,1):
                        name=f"{noise_id}-{layout}-g{g}-r{k}"
                        seed=178998122709+np_*90001+li*4003+g*121+k*19
                        inputs,surrounds,masks,meta=sample(g,layout,noise,seed)
                        order=("packed","variance","colors","wb","matrix")
                        parent=model(*(inputs[key].cuda() for key in order)).cpu().numpy()
                        packed,var,colors,truth=(inputs[key].numpy() for key in ("packed","variance","colors","target"))
                        measurements={"parent":score(parent,None,truth,masks)}
                        all_freq={}
                        checks={}
                        stored={}
                        for background,scene in surrounds.items():
                            frequencies,peaks=infer_prior(scene,colors[0],EXTERIOR_QUERY,noise,span=80)
                            all_freq[background]=frequencies
                            parts={}
                            local=[]
                            for i in (0,1,2):
                                found,record=expansion(packed[i],var[i],parent[i],colors[i],frequencies,noise)
                                for variant,value in found.items():
                                    parts.setdefault(variant,[]).append(value)
                                local.append(record)
                            for method,val in parts.items():
                                output=np.stack(val)
                                method=background+"-"+method
                                stored[method]=output
                                measurements[method]=score(parent,output,truth,masks)
                            checks[background]={"exterior":peaks,"query_checks":local}
                        retained=None
                        if k==0 and g in (110,112,115):
                            path=folder/(name+".npz")
                            np.savez_compressed(path,**{key:v.numpy() for key,v in inputs.items()},
                                                **masks,parent=parent,**stored)
                            retained=reference(path)
                        dst=folder/(name+".json")
                        write_json(dst,{"id":name,"profile":noise_id,"layout":layout,"g":g,"r":k,"sensor_seed":seed,
                            "measurements":measurements,"frequency_priors":all_freq,"checks":checks,"noise_metadata":meta,
                            "retained":retained,"input_fingerprints":{key:fingerprint(v) for key,v in inputs.items()}})
                        records.append(reference(dst))
                        print(name,[round(measurements[f"matching-{key}"]["response"][0],4) for key in
                                    ("original","moving-median","anchored-median")],round(time.monotonic()-began,2),flush=True)
    assert len(records)==48
    write_json(ROOT/"result.json",{"plan":reference(ROOT/"plan.json"),"cases":records,"seconds":time.monotonic()-began})

if __name__=="__main__":
    main()
