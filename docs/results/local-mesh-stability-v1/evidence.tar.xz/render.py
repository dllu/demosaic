"""Render native companion boards and verify their retained metric inputs."""

import os
import sys
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from run import DISPLAY, score

root = Path(__file__).resolve().parent
repo = root.parents[2]
sys.path.insert(0, str(repo / "scripts"))
from report_scene_wave_guides import native_board

os.sched_setaffinity(0, [12, 13])
os.nice(12)
output = repo / "docs" / "images" / "local-mesh-stability-v1"
output.mkdir(exist_ok=True)
plan = read_json(root / "plan.json")
rows = []
for key in ("iso400-occluded-g110-r0", "iso400-occluded-g115-r0", "iso400-broken-g115-r0", "iso6400-occluded-g115-r0"):
    receipt = root / "cases" / (key + ".json")
    case = read_json(receipt)
    with np.load(checked(case["retained"]), allow_pickle=False) as saved:
        arrays = dict(saved)
    noisy, base, truth = noisy_malvar(arrays), arrays["parent"], arrays["target"]
    masks = {k: arrays[k] for k in ("strong_phase", "weak_phase", "support")}
    x, y, w, h = DISPLAY
    versions = []
    for method in ("matching-original", "matching-moving-median", "matching-anchored-median"):
        delta = arrays[method]
        expected = case["measurements"][method]
        actual = score(base, delta, truth, masks)
        for metric in ("response", "increment_RMS_DN16", "negative_added_RMS_DN16"):
            np.testing.assert_allclose(expected[metric], actual[metric], rtol=0, atol=1e-12)
        version = base.copy()
        version[..., y:y+h, x:x+w] += delta
        versions.append(version[1])
    values = [noisy[1], base[1], *versions, truth[1]]
    rows.append(native_board(output, key, values, {p: arrays[p][1:2] for p in ("wb", "matrix")},
        {"input": case["retained"], "metrics": reference(receipt), "checkpoint": plan["checkpoint"],
         "CFA_planes": arrays["colors"][1].tolist(), "noise": plan["noise"][case["profile"]],
         "sensor_seed": case["sensor_seed"]},
        labels=("Noisy Malvar", "Local trunk", "Original box", "Moving median", "Anchored median", "Exact GT"),
        triplet_indices=(0, 4, 5), exposure=1, roi=DISPLAY, contrast=8))
write_json(root / "render.json", {"driver": reference(__file__), "crops": rows})
