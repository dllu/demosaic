"""Translate the query against identical stored full-scene Bayer and RGB fields."""

import os
import sys
import time
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
GUARD=ROOT.parent/"local-donor-mesh-guard-v1"
sys.path.insert(0,str(GUARD))
from audit import heldout
from confirm import admit
from guard import dual_support
from support import infer_prior
from standing import legacy

SHIFTS=[(0,0)]+[(dx,dy) for s in (2,8,16) for dx,dy in ((s,0),(-s,0),(0,s),(0,-s))]
MODES=("frozen-donors","refit-donors")


def make_check(p,raw,var,colors,freq,noise):
    if not freq:
        return p,{"status":"no exterior pair"}
    verified=heldout(raw,colors,freq,noise)
    passed=admit(verified)
    if not passed:
        return p,{"status":"extra RAW check rejected","extra":verified}
    out,details=dual_support(p,raw,var,colors,freq,noise)
    return out[-1],{"status":details["status"],"extra":verified,
                    "fitted_carriers":details.get("guides"),"local_weight":details.get("mean_local_weight")}


def numerics(candidate,reference):
    ch=candidate.ravel()
    r=reference.ravel()
    factor=65535
    return {
        "rms_DN16":float(factor*np.linalg.norm(ch)/np.sqrt(ch.size)),
        "difference_from_center_DN16":float(factor*np.linalg.norm(ch-r)/np.sqrt(ch.size)),
        "correlation_to_center":float(np.dot(ch,r)/(np.linalg.norm(ch)*np.linalg.norm(r))) if ch.any() and r.any() else None,
        "peak_DN16":float(factor*np.abs(ch).max()),
    }


def load_preserved():
    old_path=GUARD/"confirmed-standing/result.json"
    old=read_json(old_path)
    plan=read_json(checked(old["source_plan"]))
    observed={r["id"]:r for r in plan["observations"]}
    base_path=legacy.PREVIOUS/"none/collection.json"
    bases={r["id"]:r for r in read_json(base_path)["records"]}
    return old_path,old,observed,bases


def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    old_path,old,observed,bases=load_preserved()
    result=[]
    started=time.monotonic()
    stored=ROOT/"arrays"
    stored.mkdir()
    for scene_view in old["rows"]:
        id_=scene_view["id"]
        obs_id=next(name for name in observed if id_.startswith(name+"-"))
        obs=observed[obs_id]
        record=bases[obs_id]
        with np.load(checked(obs["arrays"]),allow_pickle=False) as source:
            arrays={k:source[k] for k in ("packed","variance","colors","wb","matrix")}
        assert {k:fingerprint(a) for k,a in arrays.items()}==record["input_fingerprints"]
        raw,var,colors=(arrays[k][0] for k in ("packed","variance","colors"))
        field=np.load(checked(record["prediction"]),allow_pickle=False)[0]
        x,y,w,h=scene_view["native_roi"]
        origin=scene_view["query"]
        span=112 if "mesh" in id_ else 80
        center_prior=scene_view["evidence"][str(span)].get("prior_frequencies")
        gathered={k:[] for k in MODES}
        output={k:[] for k in MODES}
        for dx,dy in SHIFTS:
            left,top=origin[0]+dx,origin[1]+dy
            box=(left,top,256,256)
            same_scene=(x-left,y-top,w,h)
            assert min(same_scene[:2])>=0 and max(same_scene[0]+w,same_scene[1]+h)<=256
            neural=legacy.window(field,box)
            input_raw,input_variance=[legacy.window(a,box,phase=2) for a in (raw,var)]
            new_prior,proposal=infer_prior(raw,colors,box,obs["noise"],span=span)
            for k,prior in zip(MODES,(center_prior,new_prior),strict=True):
                p,v=make_check(neural,input_raw,input_variance,colors,prior,obs["noise"])
                delta=legacy.window(p.astype(float)-neural,same_scene)
                output[k].append(delta)
                gathered[k].append({"shift":[dx,dy],"frequency_prior":prior,"fit":v,
                   **numerics(delta,output[k][0]),
                   "fitted_window_count":proposal["best_window_pair_count"] if k=="refit-donors" else None})
        for k in MODES:
            np.testing.assert_array_equal(output[MODES[0]][0],output[k][0])
            assert abs(gathered[k][0]["rms_DN16"]-scene_view["effects"]["Extra RAW check"]["RMS_DN16"])<1e-10
        dest=stored/(id_+".npz")
        np.savez_compressed(dest,**{k:np.asarray(q,dtype=np.float32) for k,q in output.items()})
        row={"id":id_,"old":scene_view,"source_arrays":obs["arrays"],"matched_parent":record["prediction"],
             "native_roi":scene_view["native_roi"],"shifted":gathered,"correction_arrays":reference(dest)}
        result.append(row)
        print(id_,[sum(p["rms_DN16"]>0 for p in gathered[k]) for k in MODES],
              [round(max(p["difference_from_center_DN16"] for p in gathered[k]),2) for k in MODES],
              round(time.monotonic()-started,2),flush=True)
    assert len(result)==8
    write_json(ROOT/"result.json",{"driver":reference(__file__),"previous_camera":reference(old_path),
          "mode_names":MODES,"translations_native_xy":SHIFTS,"cases":result,
          "scope":"The fixed carryover prior uses original localized donor boxes that remain disjoint from every translated 256px query (previous 32px margin exceeds the 16px extent). The second policy reruns donor inference. The same registered camera-linear parent and 160px native output region are read for each translation. No reference data enters fitting."})

if __name__=="__main__":
    main()
