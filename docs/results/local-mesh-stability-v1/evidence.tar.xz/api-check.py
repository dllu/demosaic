"""Verify the optional crop helper against the archived experiment implementation."""

import os
import time
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import refine_local_raw_mesh

root = Path(__file__).resolve().parent
os.sched_setaffinity(0, [12, 13])
os.nice(12)
camera = read_json(root / "camera.json")
changes = []
for row in camera["rows"]:
    with np.load(checked(row["input"]), allow_pickle=False) as inputs:
        raw, variance, colors = (inputs[k][0] for k in ("packed", "variance", "colors"))
    field = np.load(checked(row["matched_parent"]), allow_pickle=False)[0]
    box, roi = row["native_query"], row["native_ROI"]
    x, y, w, h = roi
    base = field[:, y:y+h, x:x+w]
    with np.load(checked(row["corrections"]), allow_pickle=False) as a:
        expected = base + a["combined"]
        differences = []
        for name in ("unanchored", "anchored"):
            flat = a[name].reshape(len(a[name]), -1).astype(np.float64)
            mask = np.any(flat, axis=1)
            ref = flat[0]
            corr = flat[mask] @ ref / np.linalg.norm(flat[mask], axis=1) / np.linalg.norm(ref) if mask[0] else []
            corr2 = float(corr[1]) if len(corr) == len(flat) else None
            differences.append({"method": name, "active": int(sum(mask)), "min_cosine": float(min(corr)) if len(corr) else None,
                                "right2_cosine": corr2, "max_RMS_from_center_DN16": float(np.max(np.sqrt(np.mean((flat-ref)**2,axis=1)))*65535)})
    begin = time.monotonic()
    output = refine_local_raw_mesh(field, raw, variance, colors, box, roi,
                                  shot=row["noise"]["shot"], read=row["noise"]["read"],
                                  donor_span=112 if row["id"].startswith("mesh-") else 80)
    error = float(np.max(np.abs(output-expected)))
    print(row["id"], error, differences, flush=True)
    np.testing.assert_allclose(output, expected, rtol=0, atol=6e-8)
    changes.append({"id": row["id"], "peak_error": error, "bitwise_equal": bool(np.array_equal(output, expected)),
                    "seconds": time.monotonic()-begin, "fit_stability": differences})
repo = root.parents[2]
write_json(root / "api-check.json", {"driver": reference(__file__), "camera": reference(root / "camera.json"),
    "api_sources": [reference(repo / "src" / "demosaic" / name) for name in
                    ("mesh_refinement.py", "_mesh_frequency.py", "_mesh_profiles.py")], "rows": changes})
