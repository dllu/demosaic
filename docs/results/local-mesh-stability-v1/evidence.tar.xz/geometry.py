"""Fresh mesh panels with known geometry and independently observed outer phase."""

import dataclasses
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic, PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates, native_sites
from demosaic.noise import add_noise, variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from mesh import Carrier, ribbon, phase, restore

ROOT=Path(__file__).resolve().parent
WIRE=ROOT.parent/"scene-wire-gap-v1"
SIDES=(256,768)
POLICIES={
    "additive-fixed":("add",False,"exact"),
    "occlusion-fixed":("occlusion",False,"exact"),
    "separate-fixed":("separate",False,"exact"),
    "adaptive-fixed":("adaptive",False,"exact"),
    "additive-exterior":("add",False,"exterior"),
    "adaptive-exterior":("adaptive",False,"exterior"),
    "adaptive-local":("adaptive",True,"exterior"),
    "adaptive-shifted":("adaptive",False,"shifted"),
}
PRIORS={"iso400":{"shot":8e-5,"read":2.56e-8,"exposure":1.0},"iso6400":{"shot":0.00128,"read":6.5536e-6,"exposure":1.0}}
LAYOUT=("additive","occluded","broken")
GEOMETRY=range(80,86)
EXPOSURE=1.0
CROP=(48,48,160,160)
STRONG=np.array([-.32,1.,-.18])[:,None,None]
FAINT=np.array([.58,.76,-.36])[:,None,None]


def guides(g):
    a=math.radians((g*17+9)%180)
    b=a+math.radians((56,71,83)[g%3])
    perspective=((g%3-1)*.00018,((g+1)%3-1)*.00012)
    return (
        Carrier((math.cos(a)/(14+(g%3)*3),math.sin(a)/(14+(g%3)*3)),(g*.271)%1,.087,perspective),
        Carrier((math.cos(b)/(16+((g+1)%3)*3),math.sin(b)/(16+((g+1)%3)*3)),(g*.387)%1,.070,perspective),
    )


def clean(g,layout,carriers):
    x,y=coordinates(256,256,origin=(-127.5,-127.5))
    p,q=(ribbon(x,y,v) for v in carriers)
    background=np.array([.25,.29,.32])[:,None,None] + .014*x/256 + .009*y/256
    strength=.0032 if g%2 else .0027
    absent=background+.043*STRONG*p
    complete=q if layout=="additive" else q*(1-p)
    if layout=="broken":
        travel=(x+.3*y)-(g%3-1)*27
        support=np.clip((np.abs(travel)-30)/12,0,1)
        support=support**2*(3-2*support)
        complete=complete*support
        step=.5+.5*np.tanh((.65*x-y+36)/1.7)
        absent=absent+(np.array([.019,.028,.011])[:,None,None])*step
    else:
        support=np.ones_like(p)
    clean_present=absent+strength*FAINT*complete
    return [torch.from_numpy(v.astype(np.float32)) for v in (absent,clean_present,background)], {
        "strong_phase":p,"weak_phase":q,"support":support,
    }


def shifted(guides, offset):
    return guides[0],dataclasses.replace(guides[1],offset=(guides[1].offset+offset)%1)


def estimate_offset(scene,colors,carrier,box=(256,256,256,256),*, polarity=1):
    h,w=scene.shape[-2:]
    x,y=native_sites((h,w), (-(2*w-1)/2,-(2*h-1)/2))
    left,top,height,width=box
    xp=x+(2*w-1)/2
    yp=y+(2*h-1)/2
    outside=(xp<left-32)|(xp>=left+width+32)|(yp<top-32)|(yp>=top+height+32)
    pure=np.broadcast_to(np.asarray(colors)[:,None,None]==1,scene.shape)&outside
    exposure=scene[pure].astype(float)
    u,v=x[pure],y[pure]
    angle=2*np.pi*phase(u,v,dataclasses.replace(carrier,offset=0.0))
    fit=np.column_stack([np.ones(len(u)),u/max(1,w),v/max(1,h),np.cos(angle),np.sin(angle)])
    a=np.linalg.solve(fit.T@fit,fit.T@exposure)
    offset=float(np.arctan2(polarity*a[4],polarity*a[3])/(2*np.pi)%1)
    return dataclasses.replace(carrier,offset=offset),float(np.hypot(a[3],a[4]))


def simulate(g,layout,prior,seed):
    geometry=guides(g)
    gt,masks=clean(g,layout,geometry)
    pattern=tuple(PATTERNS)[g%4]
    a,b,flat=gt
    raw,metadata=paired_observation(a[None],b[None],prior,[pattern],torch.ones(1,3),torch.eye(3)[None],seed)
    store={k:torch.from_numpy(raw[k]) for k in ("packed","variance","target","colors","wb","matrix")}
    c=store["colors"][0]
    flat_m=mosaic(flat[None],c)
    flat_raw=add_noise(flat_m,prior["shot"],prior["read"],black_level=.03,
                       generator=torch.Generator().manual_seed(seed+1293))
    for k,extra in (("packed",flat_raw),("variance",variance_map(flat_raw,prior["shot"],prior["read"])),
                    ("target",flat[None]),("colors",store["colors"][:1]),
                    ("wb",store["wb"][:1]),("matrix",store["matrix"][:1])):
        store[k]=torch.cat((store[k],extra))
    x,y=coordinates(768,768,origin=(-383.5,-383.5))
    p,q=(ribbon(x,y,v) for v in geometry)
    outside=np.array([.24,.29,.34])[:,None,None]+.016*x/768+.012*y/768
    outside=outside+.15*STRONG*p+.085*FAINT*q
    scene=mosaic(torch.from_numpy(outside.astype(np.float32))[None],c)
    observed=add_noise(scene,prior["shot"],prior["read"],black_level=.03,
                      generator=torch.Generator().manual_seed(seed+794))[0].numpy()
    offsets=[estimate_offset(observed,c.numpy(),v) for v in geometry]
    estimated=tuple(v[0] for v in offsets)
    proposal={"exact":geometry,"exterior":estimated,"shifted":shifted(estimated,.31)}
    return store,masks,proposal,list(map(lambda x:x[1],offsets)),metadata


def metrics(images,parent,truth,masks):
    x,y,w,h=CROP
    roi=np.s_[...,y:y+h,x:x+w]
    selected={k:m[roi] for k,m in masks.items()}
    output=images.astype(float)[roi]
    target=truth.astype(float)[roi]
    correction=output-parent.astype(float)[roi]
    error=output-target
    delta=target[1]-target[0]
    increment=output[1]-output[0]
    q,p,h=selected["weak_phase"],selected["strong_phase"],selected["support"]
    main=(q>.10)&(h>.9999)
    junction=main&(p>.45)
    wire=main&(p<.12)
    missing=(h<1e-8)&(q>.10)
    def rms(v):
        return float(65535*np.sqrt(np.mean(v**2)))
    def response(z):
        return float(np.sum(increment[:,z]*delta[:,z])/np.sum(delta[:,z]**2))
    return {
        "response":[response(i) for i in (main,junction,wire)],
        "increment_RMS_DN16":[rms((increment-delta)[:,i]) for i in (main,junction,wire)],
        "negative_RMS_DN16":[rms(error[i]) for i in (0,2)],
        "negative_added_RMS_DN16":[rms(correction[i]) for i in (0,2)],
        "gap_added_RMS_DN16":rms(correction[1][:,missing]) if missing.any() else None,
        "gap_error_RMS_DN16":rms(error[1][:,missing]) if missing.any() else None,
        "changed":[bool(v.any()) for v in correction],
    }


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    binding=read_json(WIRE/"plan.json")["checkpoint"]
    plan={
        "driver":reference(__file__),"method":reference(ROOT/"mesh.py"),"checkpoint":binding,
        "geometries":list(GEOMETRY),"layouts":LAYOUT,"priors":PRIORS,"repeats":[0,1],
        "policies":POLICIES,"seed_base":177912748975,"ROI":CROP,"native_size":SIDES,
        "gate":1.75,
        "scope":"Crossed weak ribbons, including full-overlap, front occlusion and a missing segment with a strong step. The outer phase arm supplies the true frequency and perspective field, estimating both offsets from an independently noisy exterior. No target or parent enters the local gate.",
    }
    write_json(ROOT/"plan.json",plan)
    model, payload=load_scene_checkpoint(checked(binding),device="cuda",weights="ema",expected_sha256=binding["sha256"])
    assert payload["step"]==2000
    model.mode="none"
    cases=ROOT/"cases"
    cases.mkdir()
    began=time.monotonic()
    linked=[]
    with ieee_fp32():
        for ni,(profile,noise) in enumerate(PRIORS.items()):
            model.base.set_noise(noise["shot"],noise["read"])
            for li,layout in enumerate(LAYOUT):
                for g in GEOMETRY:
                    for repeat in (0,1):
                        key=f"{profile}-{layout}-g{g}-r{repeat}"
                        seed=177912748975+70001*ni+4100*li+79*g+17*repeat
                        store,masks,proposal,offset_fit,physical=simulate(g,layout,noise,seed)
                        order=("packed","variance","colors","wb","matrix")
                        parent=model(*(store[k].cuda() for k in order)).cpu().numpy()
                        raw,var,colors,truth=(store[k].numpy() for k in ("packed","variance","colors","target"))
                        stats={"parent":metrics(parent,parent,truth,masks)}
                        pred={"parent":parent}
                        for method,(shape,local,role) in POLICIES.items():
                            r,control=[],[]
                            for i in (0,1,2):
                                restored,witness=restore(parent[i],raw[i],var[i],colors[i],proposal[role],
                                    (noise["shot"],noise["read"]),method=shape,local=local)
                                r.append(restored)
                                control.append(witness)
                            pred[method]=np.stack(r)
                            stats[method]=metrics(pred[method],parent,truth,masks)|{"fits":control}
                        retained=None
                        if repeat==0 and g in (80,83):
                            bundle=cases/(key+".npz")
                            np.savez_compressed(bundle,**{k:v.numpy() for k,v in store.items()},
                                               **{f"pred_{k}":v for k,v in pred.items()},**masks)
                            retained=reference(bundle)
                        row=cases/(key+".json")
                        write_json(row,{
                            "id":key,"profile":profile,"layout":layout,"geometry":g,"seed":seed,"repeat":repeat,
                            "measurements":stats,"guides":{k:[dataclasses.asdict(a) for a in v] for k,v in proposal.items()},
                            "exterior_amplitudes":offset_fit,"retained":retained,"physical":physical,
                            "fingerprints":{k:fingerprint(v) for k,v in store.items()},
                        })
                        linked.append(reference(row))
                        print(key,[np.round(stats[d]["response"],3).tolist() for d in
                              ("additive-exterior","adaptive-exterior","adaptive-local")],round(time.monotonic()-began,2),flush=True)
    assert len(linked)==72
    write_json(ROOT/"result.json",{"plan":reference(ROOT/"plan.json"),"records":linked,"seconds":time.monotonic()-began})

if __name__=="__main__":
    main()
