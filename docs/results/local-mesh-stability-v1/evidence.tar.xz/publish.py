"""Bind viewed boards, frozen experiment sources and closed mesh receipts."""

import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
images = repo / "docs" / "images" / "local-mesh-stability-v1"
output = repo / "docs" / "results" / "local-mesh-stability-v1"
output.mkdir()
origin = root.parent / "local-mesh-origin-v1"
geometry = root.parent / "joint-mesh-phase-v1" / "run.py"
source_camera = read_json(root / "camera.json")
source_synth = read_json(root / "result.json")
api = read_json(root / "api-check.json")
source_renders = read_json(root / "render.json")
source_replay = read_json(root / "replay-broken.json")
assert len(source_synth["cases"]) == 48
assert len(source_camera["rows"]) == len(api["rows"]) == 8
assert all(row["bitwise_equal"] for row in api["rows"])
for record in api["api_sources"]:
    checked(record)


def board(source, panels, *, copy):
    original = checked(source)
    new = images / original.name
    if copy:
        shutil.copyfile(original, new)
    binding = reference(new)
    assert binding["sha256"] == source["sha256"]
    with Image.open(new) as im:
        assert all((w, h) == (160, 160) and 0 <= x <= im.width - w and 0 <= y <= im.height - h
                   for panel in panels for x, y, w, h in [panel["png_xywh"]])
    return {"path": str(new.relative_to(repo)), "sha256": binding["sha256"]}


notes = {
    "main-overcast-sky-main-overcast-sky": "Smooth dark gray rendered sky. All corrected panels equal the local-only parent; the independent ISO100 AHD has more visible grain.",
    "main-building-detail-main-building-detail": "Parent beams and small cross-bracing remain soft. All corrected panels match the parent, with no added bands.",
    "main-foliage-main-foliage": "Existing light leaf edges and soft dark foliage are unchanged in both medians.",
    "main-chain-link-fence-main-chain-link-fence": "Regular coarse crossings and the existing bright speck remain visible. Both medians resemble the original correction.",
    "mesh-nominal-fine-green-mesh-left": "Faint lattice survives both medians. Some fine sections repeat too uniformly. Stronger crossings appear in both independent lower-noise references.",
    "mesh-nominal-fine-green-mesh-right": "Still soft with incomplete crossings. All corrected panels equal the local-only parent.",
    "mesh-profile3879-fine-green-mesh-left": "Faint crossings remain visible under the transferred prior. Soft horizontal wire remains visible. Independent references show finer, stronger detail.",
    "mesh-profile3879-fine-green-mesh-right": "Retains soft diagonal modulation but no new resolved intersections after correction.",
    "iso400-occluded-g110-r0": "Faint secondary lines become clearer. Some segments remain too weak compared with the exact field.",
    "iso400-occluded-g115-r0": "Clearer secondary diagonals join the stronger green wires. The exact field has sharper transitions at some crossings.",
    "iso400-broken-g111-r0": "The median reveals faint cross-lines above the edge. It slightly extends the fit into the exact missing interval.",
    "iso400-broken-g115-r0": "All mesh variants show the same parent. The weak lines and some step detail stay soft.",
    "iso6400-occluded-g115-r0": "All mesh variants show the same parent. The parent strong wire edges vary in apparent position and the exact weak direction remains indistinct.",
}
views = []
cameras = []
for row in source_camera["rows"]:
    published = board(row["image"], row["panels"], copy=True)
    for key in ("input", "matched_parent", "corrections"):
        checked(row[key])
    cameras.append({k: row[k] for k in ("id", "panels", "input", "matched_parent", "noise", "display_exposure", "native_ROI", "native_query", "corrections", "effects")} | {"published": published, "original": row["image"]})
    views.append({"id": row["id"], "published": published, "observation": notes[row["id"]]})

synthetic = []
keepers = ("iso400-occluded-g110-r0", "iso400-occluded-g115-r0")
for row in [*source_renders["crops"], source_replay["board"]]:
    published = board(row["board"]["image"], row["board"]["panels"], copy=False)
    item = {k: v for k, v in row.items() if k not in ("triplet", "board")}
    item["board"] = {"published": published, "panels": row["board"]["panels"]}
    if row["id"] in keepers:
        panel = row["triplet"]
        item["triplet"] = {"published": board(panel["image"], panel["panels"], copy=False), "panels": panel["panels"]}
    else:
        local_only = checked(row["triplet"]["image"])
        shutil.move(local_only, root / local_only.name)
    views.append({"id": row["id"], "published": published, "observation": notes[row["id"]]})
    synthetic.append(item)
assert len(views) == 13 and len(synthetic) == 5

record = output / "actual-viewing.json"
write_json(record, {"recorded_utc": datetime.now(UTC).isoformat(), "native_viewed": True,
                    "views": views, "synthetic_triplets_also_viewed": list(keepers),
                    "scope": "Actual viewing at native 160×160 crop pixels. Both DSCF3842 conditioning profiles share one RAW. The lower-noise AHD and all JPEG references are qualitative."})

files = {name: root / name for name in (
    "run.py", "run.log", "plan.json", "result.json", "summarize.py", "summary.json", "stabilize.py",
    "camera.py", "camera.log", "camera.json", "camera-first.py", "camera-first.log", "mesh.py", "support.py",
    "guard.py", "audit.py", "confirm.py", "standing.py", "api-check.py", "api-check.json", "api-check.log",
    "render.py", "render.json", "replay-broken.py", "replay-broken.json", "publish.py",
    "synthetic-first/run.py", "synthetic-first/run.log", "synthetic-first/plan.json",
)}
files.update({name: origin.parent / name for name in ("local-mesh-origin-v1/probe.py", "local-mesh-origin-v1/result.json", "local-mesh-origin-v1/run.log")})
files["geometry.py"] = geometry
files.update({f"cases/{p.name}": p for p in map(checked, source_synth["cases"])})
shutil.copyfile(root / "summary.json", output / "summary.json")
archive_path = output / "evidence.tar.xz"
with tarfile.open(archive_path, "x:xz") as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
with tarfile.open(archive_path, "r:xz") as archive:
    assert set(archive.getnames()) == set(files)
    for name, path in files.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == reference(path)["sha256"], name


def portable(path):
    binding = reference(path)
    return binding | {"path": str(path.relative_to(repo))}


write_json(output / "publication.json", {
    "study": "local-mesh-stability-v1", "evidence": portable(archive_path),
    "actual_viewing": portable(record), "summary": portable(output / "summary.json"),
    "archived_originals": {name: reference(path) for name, path in files.items()},
    "checkpoints": {"synthetic_parent": read_json(root / "plan.json")["checkpoint"], "camera_local_parent": source_camera["checkpoint"]},
    "api": api["api_sources"], "api_replay": api["rows"], "synthetic": synthetic, "camera": cameras,
    "training_performed": False, "scoped_numeric_complete": True, "native_viewed": True,
    "comparable_primary_scores": None,
    "scope": "Machine originals retain their bytes and path and SHA256 bindings. Large retained RAW and correction arrays remain in the local cache. Rendered board pixels have been checked and published without resizing. The crop helper reproduces the anchored result bitwise on all eight standing outputs.",
})
