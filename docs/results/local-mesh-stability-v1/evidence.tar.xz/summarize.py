"""Reduce the complete paired panel without combining its two noise regimes."""

from collections import Counter
from pathlib import Path
from statistics import mean

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
source = root / "result.json"
result = read_json(source)
cases = [read_json(checked(ref)) for ref in result["cases"]]
methods = tuple(cases[0]["measurements"])
assert len(cases) == 48 and len({row["id"] for row in cases}) == 48

def summarize(rows):
    metrics = {}
    for method in methods:
        vals = [row["measurements"][method] for row in rows]
        gap = [m for m in vals if m["gap_added_RMS_DN16"] is not None]
        metrics[method] = {
            "response": list(map(mean, zip(*(m["response"] for m in vals), strict=True))),
            "increment_RMS_DN16": list(map(mean, zip(*(m["increment_RMS_DN16"] for m in vals), strict=True))),
            "negative_added_RMS_DN16": list(map(mean, zip(*(m["negative_added_RMS_DN16"] for m in vals), strict=True))),
            "gap_added_RMS_DN16": mean(m["gap_added_RMS_DN16"] for m in gap) if gap else None,
            "gap_error_RMS_DN16": mean(m["gap_error_RMS_DN16"] for m in gap) if gap else None,
            "changed_roles": list(map(sum, zip(*(m["changed"] for m in vals), strict=True))),
            "changed_ids": [row["id"] for row, m in zip(rows, vals, strict=True) if any(m["changed"])],
        }
    return {"pairs": len(rows), "metrics": metrics}

assert Counter((r["profile"], r["layout"]) for r in cases) == {
    (profile, layout): 12 for profile in ("iso400", "iso6400") for layout in ("occluded", "broken")
}
splits = {f"{profile}/{layout}": summarize([r for r in cases if r["profile"] == profile and r["layout"] == layout])
          for profile in ("iso400", "iso6400") for layout in ("occluded", "broken")}
write_json(root / "summary.json", {"driver": reference(__file__), "source": reference(source), "splits": splits,
    "overall": summarize(cases), "has_donor_pair": {g: sum(bool(r["frequency_priors"][g]) for r in cases)
                    for g in ("matching", "unrelated", "quiet")}})
for label, summary in splits.items():
    print(label)
    for method in ("parent", "matching-original", "matching-moving-median", "matching-anchored-median",
                   "unrelated-anchored-median", "quiet-anchored-median"):
        m = summary["metrics"][method]
        print(method, round(m["response"][0]*100,2), round(m["increment_RMS_DN16"][0],2),
              None if m["gap_added_RMS_DN16"] is None else round(m["gap_added_RMS_DN16"],2),
              None if m["gap_error_RMS_DN16"] is None else round(m["gap_error_RMS_DN16"],2),
              m["changed_roles"], m["changed_ids"] if method.startswith("unrelated-") else "")
