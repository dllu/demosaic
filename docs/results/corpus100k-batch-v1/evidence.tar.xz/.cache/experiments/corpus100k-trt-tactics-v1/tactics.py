"""Compare FP16 TensorRT tactics for the unchanged Corpus 100k tile grid."""
from collections import Counter
from contextlib import nullcontext
import json
from pathlib import Path
from statistics import median
import sys
import time

import numpy as np
import torch
import tensorrt as trt

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name('corpus100k-faster-inference-v1')
sys.path.insert(0, str(PREVIOUS))
from trt_hidden import Engine, HiddenNetwork, LOGGER, selected
from full_production import gpu_jobs
from screen import load, policy, statistics, versions, SHOT, READ
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw


class StaticHiddenNetwork(HiddenNetwork):
    def __init__(self, trunk, tile, batch):
        self.batch = batch
        super().__init__(trunk, (tile, tile), {})

    def input(self, name, dtype, dims):
        from trt_hidden import FORMATS
        value = self.network.add_input(name, dtype, (self.batch, *dims))
        value.allowed_formats = 1 << int(FORMATS[dtype])
        return value

    def build_plan(self, path, level):
        config = self.builder.create_builder_config()
        config.clear_flag(trt.BuilderFlag.TF32)
        config.builder_optimization_level = level
        config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 2 << 30)
        config.avg_timing_iterations = 5
        config.max_aux_streams = 0
        started = time.perf_counter()
        blob = self.builder.build_serialized_network(self.network, config)
        elapsed = time.perf_counter() - started
        if blob is None:
            raise RuntimeError(f'TensorRT did not build {path}')
        path.write_bytes(bytes(blob))
        return elapsed


def prepare():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1., 12 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.conv.fp32_precision = 'ieee'
    torch.backends.cuda.matmul.fp32_precision = 'ieee'
    return load()


def path_for(level, tile, batch):
    return ROOT / f'static-l{level}-b{batch}-{tile}.plan'


@torch.inference_mode()
def build_one(level, tile, batch):
    model, checkpoint = prepare()
    trunk = model.pretrained_rgb.network
    path = path_for(level, tile, batch)
    print('build', path.name, flush=True)
    build_jobs = gpu_jobs()
    seconds = StaticHiddenNetwork(trunk, tile, batch).build_plan(path, level)
    engine = Engine(path)
    layers = path.with_suffix('.layers.json')
    write_json(layers, engine.inspection)
    receipt = {
        'driver': reference(__file__), 'base_builder': reference(PREVIOUS / 'trt_hidden.py'),
        'checkpoint': checkpoint, 'backend': {**versions(), 'TensorRT': trt.__version__},
        'jobs_before': build_jobs, 'jobs_after': gpu_jobs(), 'tile': tile, 'batch': batch,
        'level': level, 'timing_iterations': 5, 'workspace_bytes': 2 << 30, 'max_aux_streams': 0,
        'build_seconds': seconds, 'plan': reference(path), 'layers': reference(layers),
        'types': dict(Counter(row.get('LayerType', 'unknown') for row in engine.inspection['Layers'])),
    }
    write_json(path.with_suffix('.json'), receipt)
    print(path.name, seconds, receipt['types'], flush=True)


@torch.inference_mode()
def screen(levels):
    model, checkpoint = prepare()
    config = read_json('configs/gfx-qualitative-20231231.json')
    source = reference(config['noisy'])
    raw, meta = read_raw(source['path'])
    origins = [(r['noisy_xy'][0] - 176, r['noisy_xy'][1] - 176) for r in config['regions']]
    tiles = np.stack([raw[y:y + 512, x:x + 512] for x, y in origins])
    del raw
    sensor = pack(torch.from_numpy(tiles[:, None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors = torch.as_tensor(color_indices(meta.pattern), device='cuda')[None].expand(4, -1)
    wb = torch.as_tensor(meta.white_balance, dtype=torch.float32, device='cuda')[None].expand(4, -1)
    matrix = torch.as_tensor(meta.camera_to_srgb, dtype=torch.float32, device='cuda')[None].expand(4, -1, -1)
    args = sensor, sensor.clamp_min(0) * SHOT + READ, colors, wb, matrix
    model.set_noise(SHOT, READ)
    old = PREVIOUS / 'trt-fp16-pyramid-b4-512-opt2.plan'
    plans = {'eager-fp16': None, 'dynamic-2': old}
    plans.update({f'static-{level}': checked(read_json(path_for(level, 512, 4).with_suffix('.json'))['plan'])
                  for level in levels})
    engines = {name: Engine(path) if path else None for name, path in plans.items()}
    with policy(model, 'fp32'):
        baseline32 = model(*args).cpu().numpy()
    values, timings, checks = {}, {name: [] for name in plans}, {}
    for name, engine in engines.items():
        with selected(model, engine), policy(model, 'fp16'):
            for _ in range(3):
                output = model(*args)
        values[name] = output.cpu().numpy()
        assert np.isfinite(values[name]).all()
        checks[name] = {'vs_ieee_fp32': statistics(values[name], baseline32),
                        'vs_eager_fp16': statistics(values[name], values['eager-fp16'])}
    jobs = gpu_jobs()
    names = list(plans)
    for round_index in range(12):
        start = (round_index // 2) % len(names)
        order = names[start:] + names[:start]
        if round_index % 2:
            order.reverse()
        for name in order:
            with selected(model, engines[name]), policy(model, 'fp16'):
                torch.cuda.synchronize()
                before = time.perf_counter()
                output = model(*args)
                torch.cuda.synchronize()
                timings[name].append(time.perf_counter() - before)
            assert np.array_equal(output.cpu().numpy(), values[name]), name
        print(round_index, {name: round(v[-1], 4) for name, v in timings.items()}, flush=True)
    write_json(ROOT / 'screen.json', {
        'driver': reference(__file__), 'checkpoint': checkpoint, 'backend': {**versions(), 'TensorRT': trt.__version__},
        'RAW': source, 'origins': origins, 'noise': [SHOT, READ], 'jobs_before': jobs,
        'jobs_after': gpu_jobs(), 'engine_plans': {name: reference(p) if p else None for name, p in plans.items()},
        'timings': timings, 'medians': {name: median(v) for name, v in timings.items()}, 'quality': checks,
    })


if __name__ == '__main__':
    action, *args = sys.argv[1:]
    if action == 'build':
        build_one(*map(int, args))
    elif action == 'screen':
        screen(list(map(int, args)))
    else:
        raise ValueError(action)
