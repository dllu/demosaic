"""Time complete exports and compare fixed target and GFX native crops."""
from dataclasses import replace
from pathlib import Path
from statistics import median
import sys
import time

import numpy as np
import torch

from tactics import (Engine, PREVIOUS, ROOT, SHOT, READ, checked, gpu_jobs, path_for, read_json,
                     read_raw, reference, selected, trt, versions, write_json)
THROUGHPUT = ROOT.with_name('corpus100k-fp16-throughput-v1')
sys.path.extend([str(THROUGHPUT), str(Path('scripts').resolve())])

from demosaic.cfa import color_indices
from demosaic.inference import restore_tiled
from demosaic.io import write_rgb16
from full_throughput import exported_differences
from review_throughput import (board_panels, difference, display_sensor, native_board, native_png,
                               noisy_malvar, observe_scene, photometry, sample_scene_recipe, unpack)
from screen_throughput import bound_model

FIXTURE = Path('configs/gfx-qualitative-20231231.json')
CAB = Path('docs/images/full-corpus-long100k-native-v1/manifest.json')
EXACT = THROUGHPUT / 'overlap.json'
MAIN_PREVIEW = Path('docs/images/corpus100k-mixed-precision-v1')
BASE32 = ROOT.with_name('corpus100k-mixed-precision-v1')
SETTINGS = dict(tile=512, overlap=64, batch_size=4, device='cuda', precision='float16')
LABELS = {'ieee-fp32': 'IEEE FP32', 'eager': 'Eager FP16', 'dynamic': 'Previous TensorRT FP16',
          'static': 'Static TensorRT FP16'}


def build_refs(level):
    previous = read_json(PREVIOUS / 'trt-review.json')
    return {
        'dynamic': previous['engines']['trt-fp16']['engine'],
        'static': read_json(path_for(level, 512, 4).with_suffix('.json'))['plan'],
    }


def engine_set(refs):
    return {'ieee-fp32': None, 'eager': None,
            **{name: Engine(checked(src)) for name, src in refs.items()}}


def prepare():
    torch.set_num_threads(3)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.conv.fp32_precision = 'ieee'
    torch.backends.cuda.matmul.fp32_precision = 'ieee'
    torch.cuda.set_per_process_memory_fraction(min(1, 14 * 2**30 / torch.cuda.get_device_properties(0).total_memory))


def restore(model, engines, arm, raw, colors, *, shot, read, wb, matrix):
    settings = {**SETTINGS, 'precision': 'float32' if arm == 'ieee-fp32' else 'float16'}
    with selected(model, engines[arm]):
        result, stats = restore_tiled(model, raw, colors, shot=shot, read=read, wb=wb,
                                      matrix=matrix, **settings)
    assert torch.isfinite(result).all()
    return result, stats


@torch.inference_mode()
def full(level):
    prepare()
    fixture = read_json(FIXTURE)
    source = reference(fixture['noisy'])
    started = time.perf_counter()
    raw, meta = read_raw(source['path'])
    decoded = time.perf_counter()
    model, checkpoint = bound_model()
    loaded = time.perf_counter()
    refs = build_refs(level)
    engines = engine_set(refs)
    ready = time.perf_counter()
    colors = color_indices(meta.pattern)
    args = dict(shot=SHOT, read=READ, wb=meta.white_balance, matrix=meta.camera_to_srgb)
    arms = ('eager', 'dynamic', 'static', 'static', 'dynamic', 'eager')
    events, exports = [], {}
    jobs = gpu_jobs()
    stream = torch.cuda.Stream()
    with torch.cuda.stream(stream):
        for arm in ('eager', 'dynamic', 'static'):
            restore(model, engines, arm, raw[512:1024, 512:2304], colors, **args)
        for index, arm in enumerate(arms):
            rgb, stats = restore(model, engines, arm, raw, colors, **args)
            assert stats['tiles'] == 520
            output = ROOT / f'full-{index}-{arm}.tiff'
            writer_started = time.perf_counter()
            write_rgb16(output, rgb.permute(1, 2, 0).numpy(), metadata=meta, flip=meta.flip)
            writer = time.perf_counter() - writer_started
            crop = output.with_suffix('.npz')
            np.savez_compressed(crop, **{reg['name']: rgb[:, y:y+160, x:x+160].numpy()
                                        for reg in fixture['regions'] for x,y in [reg['noisy_xy']]})
            del rgb
            export = reference(output)
            if arm in exports:
                assert export['sha256'] == exports[arm]['sha256'], (arm, export, exports[arm])
                # The first byte-identical export remains the archived local sample.
                output.unlink()
            exports.setdefault(arm, export)
            events.append(dict(arm=arm, index=index, restore=stats, export_seconds=writer,
                               export=export, crops=reference(crop), jobs_after=gpu_jobs()))
            print(index, arm, stats['seconds'], writer, flush=True)
            write_json(ROOT / 'full-progress.json', events, replace=True)
    ground = read_json(BASE32 / 'first-fp32.json')
    assert ground['checkpoint'] == checkpoint and ground['source']['sha256'] == source['sha256']
    fp32 = checked(ground['RGB16'])
    old_fp16 = read_json(PREVIOUS / 'trt-review.json')['full_frame'][0]['RGB16']
    assert exports['eager']['sha256'] == old_fp16['sha256']
    paired = {f'{mode}_vs_{baseline}': exported_differences(checked(exports[baseline]) if baseline != 'ieee-fp32' else fp32,
                                                            checked(exports[mode]), SETTINGS)
              for mode,baseline in (('dynamic','eager'), ('static','eager'), ('static','dynamic'), ('static','ieee-fp32'))}
    write_json(ROOT / 'full.json', dict(driver=reference(__file__), source=source, fixture=reference(FIXTURE),
               checkpoint=checkpoint, level=level, plans=refs, FP32_anchor=reference(fp32),
               versions={**versions(), 'TensorRT': trt.__version__}, jobs_before=jobs, events=events,
               decode_seconds=decoded-started, checkpoint_setup_seconds=loaded-decoded, load_engines_seconds=ready-loaded,
               settings=dict(SETTINGS, shot=SHOT, read=READ), exports=exports, paired=paired,
               medians={arm:median(row['restore']['seconds'] for row in events if row['arm']==arm) for arm in exports}))
    print(paired, flush=True)


def publish_main(full_receipt, meta):
    assert full_receipt['fixture'] == reference(FIXTURE)
    archived = {r['id']:r for r in read_json(MAIN_PREVIEW/'manifest.json')['main_views']}
    fp32 = read_json(BASE32 / 'first-fp32.json')
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    rows = []
    for region in read_json(FIXTURE)['regions']:
        name = region['name']
        ref_spec = archived[name]['board']
        ref_path = MAIN_PREVIEW / Path(ref_spec['image']['path']).name
        assert reference(ref_path)['sha256'] == ref_spec['image']['sha256']
        refs = board_panels(ref_path, ref_spec['panels'])
        arrays = {'ieee-fp32': fp32['native_float_RGB']}
        arrays.update({row['arm']:row['crops'] for row in full_receipt['events'][:3]})
        output = {}
        for arm, binding in arrays.items():
            with np.load(checked(binding), allow_pickle=False) as src:
                output[arm] = src[name]
        exposure = 4
        panels = [(label,value) for label,value in refs.items() if 'Noisy' in label]
        panels += [(LABELS[arm], display_sensor(torch.from_numpy(value),wb,matrix,(0,0,160,160),exposure))
                   for arm,value in output.items()]
        panels += [(label,value) for label,value in refs.items() if 'ISO100' in label]
        board = native_png(ROOT / f'{name}.png', panels)
        rows.append({'id':name, 'board':board, 'coordinates':[*region['noisy_xy'],160,160],
                     'reference_board':reference(ref_path), 'exposure':exposure,
                     'delta_eager':difference(output['static'],output['eager']),
                     'delta_IEEE32':difference(output['static'],output['ieee-fp32'])})
    return rows


@torch.inference_mode()
def quality(level):
    prepare()
    model, checkpoint = bound_model()
    refs = build_refs(level)
    engines = engine_set(refs)
    arms = ('ieee-fp32','eager','dynamic','static')
    cab = []
    exact = []
    for item in read_json(CAB)['images']:
        name = item['id']
        if item['role'] != 'board' or not name.startswith('mesh-'):
            continue
        provenance = item['provenance']
        with np.load(checked(provenance['input_arrays']), allow_pickle=False) as inputs:
            raw = unpack(torch.from_numpy(inputs['packed']))[0,0]
            colors = inputs['colors'][0]
            wb, matrix = torch.from_numpy(inputs['wb']), torch.from_numpy(inputs['matrix'])
        shot, read = (provenance['noise'][key] for key in ('shot','read'))
        x,y,w,h = provenance['ROI_xywh']
        exposure = provenance['display_exposure']
        output = {arm:restore(model,engines,arm,raw,colors,shot=shot,read=read,wb=wb,matrix=matrix)[0][:,y:y+h,x:x+w].contiguous()
                  for arm in arms}
        refs_png = board_panels(checked(item['image']), provenance['panels'])
        panels = [('Noisy Malvar',refs_png['Noisy Malvar'])]
        panels += [(LABELS[arm],display_sensor(value,wb,matrix,(0,0,w,h),exposure)) for arm,value in output.items()]
        panels += [(label,refs_png[label]) for label in ('ISO100 ref, not GT','SOOC ISO6400 JPEG','SOOC ISO100 JPEG')]
        cab.append({'id':name, 'provenance':provenance, 'board':native_png(ROOT/f'{name}.png',panels),
                    'delta_eager':difference(output['static'].numpy(),output['eager'].numpy()),
                    'delta_IEEE32':difference(output['static'].numpy(),output['ieee-fp32'].numpy())})
        print(name, cab[-1]['delta_eager'], flush=True)

    for index, case in enumerate(read_json(EXACT)['rows']):
        provenance = case['provenance']
        x,y,w,h = provenance['cache_box_xywh']
        source = np.load(checked(provenance['source']), mmap_mode='r', allow_pickle=False)
        crop = torch.from_numpy(source[y:y+h,x:x+w].astype(np.float32)).permute(2,0,1)/65535
        recipe = replace(sample_scene_recipe(0), **provenance['recipe'])
        obs = observe_scene(crop, recipe)
        raw = unpack(obs.packed[None])[0,0]
        output = {arm:restore(model,engines,arm,raw,obs.colors,shot=recipe.shot,read=recipe.read,
                              wb=obs.wb,matrix=obs.matrix)[0][None].numpy() for arm in arms}
        sup = {key:getattr(obs,key)[None].numpy() for key in ('target','packed','colors','wb','matrix')}
        roi = (680,480,160,160) if w == 1536 else (480,680,160,160)
        info = {'provenance':provenance, 'roi':roi,
                'sRGB_PSNR':{arm:float(photometry(value,sup)['srgb_psnr'][0]) for arm,value in output.items()},
                'delta_eager':difference(output['static'][0],output['eager'][0]),
                'delta_IEEE32':difference(output['static'][0],output['ieee-fp32'][0])}
        if index < 2:
            name = ('pinakothek', 'highlight')[index]
            info['id'] = name
            info['board'] = native_board(ROOT,name,[noisy_malvar(sup)[0],*[v[0] for v in output.values()],sup['target'][0]],
                                        sup,{**provenance,'checkpoint':checkpoint,'native_roi':roi},
                                        labels=('Noisy Malvar',*[LABELS[arm] for arm in output],'Exact GT'),
                                        triplet_indices=(0,4,5),exposure=provenance['display_exposure'],roi=roi)
        exact.append(info)
        print(index,info['sRGB_PSNR'],flush=True)

    full_receipt = read_json(ROOT/'full.json')
    assert full_receipt['checkpoint']==checkpoint and full_receipt['plans']==refs
    _, meta = read_raw(checked(full_receipt['source']))
    main = publish_main(full_receipt,meta)
    write_json(ROOT/'quality.json',{'driver':reference(__file__), 'checkpoint':checkpoint,'plans':refs,
              'sources':{'cab':reference(CAB),'main':reference(FIXTURE),'exact':reference(EXACT)},
              'full_receipt':reference(ROOT/'full.json'),'cab':cab,'exact':exact,'main':main})


if __name__ == '__main__':
    action, level = sys.argv[1:]
    {'full':full,'quality':quality}[action](int(level))
