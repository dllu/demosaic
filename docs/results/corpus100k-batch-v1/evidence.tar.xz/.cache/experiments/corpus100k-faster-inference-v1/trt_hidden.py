"""Test strongly typed TensorRT engines for the DRUNet hidden path."""
from contextlib import contextmanager
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn
import tensorrt as trt

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name('corpus100k-mixed-precision-v1')))
from full_production import gpu_jobs
from screen import load, policy, versions, SHOT, READ
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.pretrained_rgb import ResidualBlock
from demosaic.scene_data import observe_scene, sample_scene_recipe
from replay import timed

HALF, FLOAT = trt.DataType.HALF, trt.DataType.FLOAT
FORMATS = {HALF: trt.TensorFormat.HWC8, FLOAT: trt.TensorFormat.HWC}
QUANT_GROUPS = ('m_down3', 'm_body', 'm_up3')
LOGGER = trt.Logger(trt.Logger.WARNING)
RUNTIME = trt.Runtime(LOGGER)


def calibrate(model):
    path = ROOT / 'calibration.json'
    if path.exists():
        prior = read_json(path)
        return prior
    plan = read_json(ROOT.with_name('scene-full-epoch-v1') / 'plan.json')
    manifest = checked(plan['train_manifest'])
    profiles = [(0., 0., 1.), (8e-5, 2.56e-8, 4.), (4e-5, 6.4e-9, .10),
                (1.28e-3, 6.5536e-6, .65), (2.56e-3, 2.62144e-5, .20), (2.56e-3, 2.62144e-5, 1.3)]
    eligible = [row for line in manifest.open() for row in (json.loads(line),) if min(row['shape'][:2]) >= 512]
    eligible.sort(key=lambda row: hashlib.sha256(f"2026111903/{row['id']}".encode()).digest())
    sources = eligible[:24]
    maxima, observations = {}, []
    trunk = model.pretrained_rgb.network
    handles = []
    for name, module in trunk.named_modules():
        if not isinstance(module, nn.Conv2d) or not name.startswith(QUANT_GROUPS) or '.res.' not in name:
            continue
        def observe(_module, args, key=name):
            value = args[0].half().abs().amax()
            maxima[key] = value if key not in maxima else torch.maximum(maxima[key], value)
        handles.append(module.register_forward_pre_hook(observe))
    try:
        for i, row in enumerate(sources):
            source = reference(manifest.parent / row['cache'])
            assert source['sha256'] == row['cache_sha256']
            photo = np.load(source['path'], mmap_mode='r', allow_pickle=False)
            y, x = [(n - 512)//4*2 for n in photo.shape[:2]]
            crop = torch.from_numpy(photo[y:y+512,x:x+512].astype('float32')).permute(2,0,1)/65535
            shot, read, exposure = profiles[i % len(profiles)]
            recipe = replace(sample_scene_recipe(2026111903+i), shot=shot, read=read, exposure=exposure)
            observation = observe_scene(crop, recipe)
            model.set_noise(shot, read)
            args = [
                getattr(observation, k)[None].cuda() for k in ('packed','variance','colors','wb','matrix')
            ]
            args[0] = args[0].contiguous(memory_format=torch.channels_last)
            with policy(model, 'fp16'):
                model(*args)
            observations.append({'id':row['id'], 'source':source, 'xywh':[x,y,512,512], 'recipe':vars(recipe)})
    finally:
        for handle in handles:
            handle.remove()
    receipt = {'train_manifest':plan['train_manifest'], 'observations':observations,
               'FP8_absmax':{name: float(value) for name,value in maxima.items()},
               'scope':'Observe max of FP16-cast convolution input. Weights use independent per-output max.'}
    assert len(maxima)==24
    write_json(path, receipt)
    return receipt


class HiddenNetwork:
    def __init__(self, trunk, hw, quantized):
        self.builder = trt.Builder(LOGGER)
        self.network = self.builder.create_network()
        self.keepalive = []
        self.weights = {key: value.detach().cpu().half().numpy().copy(order='C')
                        for key,value in trunk.named_parameters() if not key.startswith(('m_head','m_tail'))}
        self.calibration = quantized
        h,w = hw
        self.first = self.input('head',FLOAT,(64,h,w))
        self.offsets = (
            self.input('context_half', FLOAT, (128,h//2,w//2)),
            self.input('context_quarter', FLOAT, (256,h//4,w//4)),
            self.input('context_eighth', FLOAT, (512,h//8,w//8)),
        )
        self.result = self.build(trunk)
        self.result.name = 'hidden'
        self.result.allowed_formats = 1 << int(FORMATS[self.result.dtype])
        self.network.mark_output(self.result)

    def input(self, name, dtype, dims):
        value = self.network.add_input(name,dtype,(-1,*dims))
        value.allowed_formats = 1 << int(FORMATS[dtype])
        return value

    def cast(self, value, dtype):
        return value if value.dtype==dtype else self.network.add_cast(value,dtype).get_output(0)

    def add(self, a, b, dtype):
        return self.network.add_elementwise(self.cast(a,dtype),self.cast(b,dtype),trt.ElementWiseOperation.SUM).get_output(0)

    def constant(self, value):
        contiguous = np.ascontiguousarray(value)
        self.keepalive.append(contiguous)
        return self.network.add_constant(contiguous.shape, contiguous).get_output(0)

    def qdq(self, value, scale, axis):
        coefficients = self.constant(np.atleast_1d(np.asarray(scale,'float32')))
        q = self.network.add_quantize(value, coefficients, trt.DataType.FP8)
        d = self.network.add_dequantize(q.get_output(0), coefficients, HALF)
        q.axis = d.axis = axis
        return d.get_output(0)

    def conv(self, name, module, value):
        value = self.cast(value, HALF)
        weights = self.weights[name+'.weight']
        if isinstance(module,nn.ConvTranspose2d):
            layer = self.network.add_deconvolution_nd(value,module.out_channels,module.kernel_size,weights)
        elif name in self.calibration:
            weight_scales = np.maximum(np.max(np.abs(weights), axis=(1,2,3)).astype('float32')/448, 1e-12)
            kernel = self.qdq(self.constant(weights),weight_scales,0)
            value = self.qdq(value,max(self.calibration[name]/448,1e-12),-1)
            layer = self.network.add_convolution_nd(value,module.out_channels,module.kernel_size,trt.Weights())
            layer.set_input(1,kernel)
        else:
            layer = self.network.add_convolution_nd(value,module.out_channels,module.kernel_size,weights)
        layer.name = name
        layer.padding_nd = module.padding
        layer.stride_nd = module.stride
        return layer.get_output(0)

    def sequence(self, name, seq, value, residual_dtype):
        for index, layer in enumerate(seq):
            key = f'{name}.{index}'
            if isinstance(layer,ResidualBlock):
                residual = self.conv(key+'.res.0',layer.res[0],value)
                residual = self.network.add_activation(residual,trt.ActivationType.RELU).get_output(0)
                residual = self.conv(key+'.res.2',layer.res[2],residual)
                value = self.add(value,residual,residual_dtype)
            else:
                value = self.conv(key,layer,value)
        return value

    def build(self,trunk):
        d1 = self.sequence('m_down1',trunk.m_down1,self.first,FLOAT)
        d1 = self.add(d1,self.offsets[0],HALF)
        d2 = self.sequence('m_down2',trunk.m_down2,d1,HALF)
        d2 = self.add(d2,self.offsets[1],HALF)
        middle = self.sequence('m_down3',trunk.m_down3,d2,HALF)
        middle = self.add(middle,self.offsets[2],FLOAT)
        body = self.sequence('m_body',trunk.m_body,middle,FLOAT)
        u3 = self.sequence('m_up3',trunk.m_up3,self.add(body,middle,FLOAT),HALF)
        u2 = self.sequence('m_up2',trunk.m_up2,self.add(u3,d2,HALF),HALF)
        return self.sequence('m_up1',trunk.m_up1,self.add(u2,d1,HALF),HALF)

    def save(self,path, *, batch, optimization):
        config = self.builder.create_builder_config()
        config.clear_flag(trt.BuilderFlag.TF32)
        config.builder_optimization_level = optimization
        config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 2<<30)
        profile = self.builder.create_optimization_profile()
        for value in (self.first, *self.offsets):
            _, *dims = tuple(value.shape)
            profile.set_shape(value.name,(1,*dims),(batch,*dims),(batch,*dims))
        config.add_optimization_profile(profile)
        start = time.perf_counter()
        serialized = self.builder.build_serialized_network(self.network,config)
        if serialized is None:
            raise RuntimeError(f'TensorRT could not build {path}')
        path.write_bytes(bytes(serialized))
        return time.perf_counter()-start


class Engine:
    def __init__(self,path):
        self.engine = RUNTIME.deserialize_cuda_engine(path.read_bytes())
        assert self.engine is not None
        self.context = self.engine.create_execution_context()
        assert self.context is not None
        self.inspection = json.loads(self.engine.create_engine_inspector().get_engine_information(trt.LayerInformationFormat.JSON))
        self.output = None

    def __call__(self,first,offsets):
        stream = torch.cuda.current_stream().cuda_stream
        bindings = tuple(zip(('head','context_half','context_quarter','context_eighth'),(first,*offsets),strict=True))
        for name,value in bindings:
            assert self.context.set_input_shape(name, tuple(value.shape))
        copies = []
        for name,value in bindings:
            strides = tuple(self.context.get_tensor_strides(name))
            if value.stride() != strides:
                value = torch.empty_strided(value.shape,strides,device=value.device,dtype=value.dtype).copy_(value)
            assert self.context.set_tensor_address(name,value.data_ptr())
            copies.append(value)
        shape = tuple(self.context.get_tensor_shape('hidden'))
        strides = tuple(self.context.get_tensor_strides('hidden'))
        if self.output is None or tuple(self.output.shape)!=shape or self.output.stride()!=strides:
            self.output = torch.empty_strided(shape,strides,device=first.device,dtype=torch.float16)
        assert self.context.set_tensor_address('hidden',self.output.data_ptr())
        assert self.context.execute_async_v3(stream)
        return self.output


@contextmanager
def selected(model, engine):
    if engine is None:
        yield
        return
    trunk = model.pretrained_rgb.network
    original = trunk.forward

    def forward(rgb,noise,*,head_offset=None,middle_offset=None,encoder_offsets=None,return_features=False):
        if return_features or encoder_offsets is None or middle_offset is None:
            raise ValueError('This experiment expects the Corpus 100k middle-context trunk')
        from demosaic.precision import ieee_fp32
        with torch.autocast('cuda',enabled=False),ieee_fp32():
            first = trunk.m_head(torch.cat((rgb.float(),noise.float()),dim=1))
            if head_offset is not None:
                first = first+head_offset.float()
        assert first.dtype==middle_offset.dtype==torch.float32
        hidden = engine(first,(*encoder_offsets,middle_offset))
        with torch.autocast('cuda',enabled=False),ieee_fp32():
            return trunk.m_tail(hidden.float()+first)
    try:
        trunk.forward = forward
        yield
    finally:
        trunk.forward = original


@torch.inference_mode()
def main(optimization='2'):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    model, binding = load()
    trunk = model.pretrained_rgb.network
    calib = calibrate(model)
    engines, artifacts = {'eager': None}, {}
    for mode, maxima in (('trt-fp16',{}),('trt-selective-fp8',calib['FP8_absmax'])):
        path = ROOT / f'{mode}-pyramid-b4-512-opt{optimization}.plan'
        elapsed = None
        if not path.exists():
            print('building',mode,flush=True)
            elapsed = HiddenNetwork(trunk,(512,512),maxima).save(path,batch=4,optimization=int(optimization))
        print('loading',mode,elapsed,flush=True)
        engines[mode] = Engine(path)
        details = ROOT / f'{mode}-layers-opt{optimization}.json'
        write_json(details,engines[mode].inspection)
        artifacts[mode] = {'engine':reference(path),'inspector':reference(details),'build_seconds':elapsed}
    config = read_json('configs/gfx-qualitative-20231231.json')
    raw_ref = reference(config['noisy'])
    raw, meta = read_raw(raw_ref['path'])
    positions = [(r['noisy_xy'][0]-176,r['noisy_xy'][1]-176) for r in config['regions']]
    tiles = np.stack([raw[y:y+512,x:x+512] for x,y in positions])
    del raw
    sensor = pack(torch.from_numpy(tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors = torch.as_tensor(color_indices(meta.pattern),device='cuda')[None].expand(4,-1)
    wb = torch.as_tensor(meta.white_balance,device='cuda',dtype=torch.float32)[None].expand(4,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb,device='cuda',dtype=torch.float32)[None].expand(4,-1,-1)
    model.set_noise(SHOT,READ)
    from screen import statistics
    args = (sensor,sensor.clamp_min(0)*SHOT+READ,colors,wb,matrix)
    comparisons, times = {}, {name:[] for name in engines}
    with policy(model,'fp32'):
        reference32 = model(*args).cpu().numpy()
    for trial in range(6):
        for name in (list(engines) if trial%2==0 else list(engines)[::-1]):
            with selected(model,engines[name]),policy(model,'fp16'):
                model(*args)
                result, elapsed = timed(lambda: model(*args))
            result = result.cpu().numpy()
            assert np.isfinite(result).all()
            if trial==0:
                if name=='eager':
                    fp16=result
                comparisons[name]={'ieee_fp32':statistics(result,reference32),'eager_fp16':statistics(result,fp16)}
            times[name].append(elapsed)
        print(trial,{name:v[-1] for name,v in times.items()},flush=True)
    write_json(ROOT/f'trt-screen-opt{optimization}.json', {'driver':reference(__file__), 'checkpoint':binding,
        'calibration':reference(ROOT/'calibration.json'),'artifacts':artifacts,'backend':{**versions(),'TensorRT':trt.__version__},
        'timing':'6 interleaved B4 512px resident forward wall times with CUDA sync, warmed immediately before each arm',
        'full_forward_seconds':times,'differences':comparisons,'raw':raw_ref,'positions':positions,
        'noise':{'shot':SHOT,'read':READ},'jobs_after':gpu_jobs()})
    print('comparison',comparisons,flush=True)


if __name__=='__main__':
    main(*sys.argv[1:])
