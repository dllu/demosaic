"""Lay out comparison boards as unresampled 160-pixel cutouts for review."""

import sys
from pathlib import Path

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def sheet(name, boards, omit=()):
    cells = []
    for label, spec in boards:
        src = Image.open(checked(spec["image"])).convert("RGB")
        use = []
        for info in spec["panels"]:
            panel = info.get("label", info.get("name"))
            if panel in omit:
                continue
            x, y, w, h = info["png_xywh"]
            assert (w, h) == (160, 160)
            use.append((panel, src.crop((x, y, x + w, y + h))))
        cells.append((label, use))
    xpad = 7
    row_h = 199
    out = Image.new(
        "RGB", (xpad + 167 * max(len(row) for _, row in cells), row_h * len(cells) + 5), "#ededed"
    )
    pen = ImageDraw.Draw(out)
    for i, (label, row) in enumerate(cells):
        y = i * row_h + 5
        pen.text((xpad, y), label, fill="black")
        for j, (panel, cut) in enumerate(row):
            x = xpad + 167 * j
            pen.text((x, y + 17), panel, fill="black")
            out.paste(cut, (x, y + 34))
    dest = ROOT / f"view-{name}.png"
    out.save(dest)
    return reference(dest)


def main(source):
    if source == "camera":
        spec = reference(ROOT / "camera-exact.json")
        q = read_json(checked(spec))
        views = {
            "exact": sheet("exact", [(r["id"], r["boards"]["board"]) for r in q["exact"][:2]]),
        }
        for exposure in ("display4", "display16"):
            for label in ("mesh-nominal", "mesh-profile3879"):
                items = [r for r in q["cab"] if r["id"].startswith(label)]
                for group, omit in (
                    ("predictions", ("SOOC ISO6400 JPEG", "SOOC ISO100 JPEG")),
                    (
                        "reference",
                        ("Eager FP16 ×4", "Eager FP16 ×8", "TensorRT FP16 ×2", "IEEE FP32 ×4"),
                    ),
                ):
                    key = f"{label}-{exposure}-{group}"
                    views[key] = sheet(
                        key, [(r["id"], r["boards"][exposure]["board"]) for r in items], omit
                    )
    else:
        assert source == "full"
        spec = reference(ROOT / "full-audit.json")
        q = read_json(checked(spec))
        views = {
            "main": sheet("main", [(r["id"], r["board"]) for r in q["main"]]),
            "outliers": sheet("outliers", [(k, r["board"]) for k, r in q["full"].items()]),
        }
    write_json(
        ROOT / f"view-{source}.json", {"source": spec, "driver": reference(__file__), "vw": views}
    )


if __name__ == "__main__":
    main(sys.argv[1])
