"""Review changed batch sizes on exact targets and the fixed GFX crops."""

from dataclasses import replace

import numpy as np
import tifffile
import torch
from benchmark_batches import (
    ARMS,
    DINO,
    PROFILE,
    ROOT,
    SHAPE,
    TILE,
    build_refs,
    combined,
    engine_set,
    prior,
)
from review_geometry import CAB_FIXTURE, clip_strata, tile_intersection

from demosaic.cfa import pack
from demosaic.inference import positions, restore_tiled
from demosaic.precision import amp_context

OVERLAP = ROOT.with_name("corpus100k-overlap-v1")
LABELS = {
    "eager4": "Eager FP16 ×4",
    "eager8": "Eager FP16 ×8",
    "compiled4": "TensorRT FP16 ×4",
    "compiled2": "TensorRT FP16 ×2",
    "ieee": "IEEE FP32 ×4",
}
REFERENCE_LABELS = ("ISO100 ref, not GT", "SOOC ISO6400 JPEG", "SOOC ISO100 JPEG")


def sensor_pixels(outputs, wb, matrix, exposure):
    return [
        (
            LABELS[arm],
            prior.display_sensor(torch.as_tensor(arr), wb, matrix, (0, 0, 160, 160), exposure),
        )
        for arm, arr in outputs.items()
    ]


def native_deltas(outputs):
    return {
        k: prior.difference(np.asarray(outputs[k]), np.asarray(outputs[anchor]))
        for k, anchor in (("eager8", "eager4"), ("compiled2", "compiled4"), ("compiled4", "ieee"))
    }


def main_boards(result, meta):
    archived_quality = prior.read_json(OVERLAP / "full-review.json")
    saved = {row["id"]: row for row in archived_quality["main"]}
    assert result["checkpoint"] == archived_quality["checkpoint"]
    checkpoint_receipt = prior.read_json(prior.BASE32 / "first-fp32.json")
    assert checkpoint_receipt["checkpoint"] == result["checkpoint"]
    refs = {tag: data["crops"] for tag, data in result["outputs"].items()}
    refs["ieee"] = checkpoint_receipt["native_float_RGB"]
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    crops = {}
    for tag, ref in refs.items():
        with np.load(prior.checked(ref), allow_pickle=False) as src:
            crops[tag] = dict(src)
    rows = []
    for region in prior.read_json(prior.FIXTURE)["regions"]:
        name = region["name"]
        archived = saved[name]["board"]
        pixels = prior.board_panels(prior.checked(archived["image"]), archived["panels"])
        outputs = {tag: values[name] for tag, values in crops.items()}
        panels = [next(item for item in pixels.items() if "Noisy" in item[0])]
        panels += sensor_pixels(outputs, wb, matrix, 4)
        panels.append(next(item for item in pixels.items() if "ISO100" in item[0]))
        rows.append(
            {
                "id": name,
                "roi": [*region["noisy_xy"], 160, 160],
                "exposure": 4,
                "previous_board": archived["image"],
                "deltas": native_deltas(outputs),
                "board": prior.native_png(ROOT / f"{name}.png", panels),
            }
        )
    return rows


def replay_rois(model, engines, full_raw, meta, profile, rois, arm):
    raw = torch.from_numpy(full_raw)
    grid = [
        (y, x)
        for y in positions(raw.shape[0], TILE, TILE - 64)
        for x in positions(raw.shape[1], TILE, TILE - 64)
    ]
    backend, batch = ARMS.get(arm, ("ieee-fp32", 4))
    precision = "float32" if arm == "ieee" else "float16"
    colors = torch.tensor(prior.color_indices(meta.pattern), device="cuda")[None]
    wb = torch.tensor(meta.white_balance, dtype=torch.float32, device="cuda")[None]
    matrix = torch.tensor(meta.camera_to_srgb, dtype=torch.float32, device="cuda")[None]
    edge = torch.hann_window(TILE, periodic=False).clamp_min(0.02)
    weight = edge[:, None] * edge[None, :]
    output = [torch.zeros((3, h, w)) for _, _, w, h in rois]
    norm = [torch.zeros((h, w)) for _, _, w, h in rois]
    model.set_noise(**profile)
    used = []
    with combined(model, engines[backend]):
        for start in range(0, len(grid), batch):
            group = grid[start : start + batch]
            intersections = [[tile_intersection(x, y, r) for r in rois] for y, x in group]
            if not any(hit is not None for row in intersections for hit in row):
                continue
            used.append({"start": start, "origins_yx": group})
            tiles = torch.stack([raw[y : y + TILE, x : x + TILE] for y, x in group])[:, None].cuda()
            packed = pack(tiles).contiguous(memory_format=torch.channels_last)
            variance = packed.clamp_min(0) * profile["shot"] + profile["read"]
            n = len(group)
            with amp_context("cuda", dtype=precision):
                preds = (
                    model(
                        packed,
                        variance,
                        colors.expand(n, -1),
                        wb.expand(n, -1),
                        matrix.expand(n, -1, -1),
                    )
                    .float()
                    .cpu()
                )
            for pred, per_roi in zip(preds, intersections, strict=True):
                for total, weights, hit in zip(output, norm, per_roi, strict=True):
                    if hit is not None:
                        src, dst = hit
                        total[:, *dst].add_(pred[:, *src] * weight[src])
                        weights[dst].add_(weight[src])
    assert all(torch.all(weights > 0) for weights in norm)
    return [
        total.div_(weights.clamp_min_(1e-12)) for total, weights in zip(output, norm, strict=True)
    ], used


def cab_boards(model, engines):
    cfg = prior.read_json(CAB_FIXTURE)
    raw, meta = prior.read_raw(prior.checked(cfg["sources"]["noisy"]))
    bounds = [r["noisy_raw_xywh"] for r in cfg["regions"]]
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    previous = prior.read_json(OVERLAP / "quality.json")
    rows = []
    for observation in ("mesh-nominal", "mesh-profile3879"):
        anchors = [
            row for row in previous["cab"] if row["provenance"]["observation_id"] == observation
        ]
        assert [row["global_ROI_xywh"] for row in anchors] == bounds
        profile = {key: anchors[0]["provenance"]["noise"][key] for key in PROFILE}
        results = {
            arm: replay_rois(model, engines, raw, meta, profile, bounds, arm) for arm in LABELS
        }
        for i, row in enumerate(anchors):
            arrays = {arm: values[0][i] for arm, values in results.items()}
            boards = {}
            for key, name in (("board", "exposure"), ("configured_board", "configured_exposure")):
                ref = row[key]
                pixels = prior.board_panels(prior.checked(ref["image"]), ref["panels"])
                exposed = row[name]
                menus = [
                    ("Noisy Malvar", pixels["Noisy Malvar"]),
                    *sensor_pixels(arrays, wb, matrix, exposed),
                    *((label, pixels[label]) for label in REFERENCE_LABELS),
                ]
                image = ROOT / f"{row['id']}-display{int(exposed)}.png"
                boards[f"display{exposed:g}"] = {
                    "board": prior.native_png(image, menus),
                    "input_reference_board": ref["image"],
                }
            rows.append(
                {
                    "id": row["id"],
                    "roi": bounds[i],
                    "noise": profile,
                    "boards": boards,
                    "deltas": native_deltas(arrays),
                    "provenance": row["provenance"],
                    "batches": {arm: value[1] for arm, value in results.items()},
                }
            )
            print("cab", row["id"], rows[-1]["deltas"], flush=True)
    return rows


def exact_targets(model, engines, checkpoint):
    rows = []
    for index, case in enumerate(prior.read_json(prior.EXACT)["rows"]):
        p = case["provenance"]
        x, y, w, h = p["cache_box_xywh"]
        src = np.load(prior.checked(p["source"]), mmap_mode="r", allow_pickle=False)
        target = (
            torch.from_numpy(src[y : y + h, x : x + w].astype(np.float32)).permute(2, 0, 1) / 65535
        )
        recipe = replace(prior.sample_scene_recipe(0), **p["recipe"])
        obs = prior.observe_scene(target, recipe)
        raw = prior.unpack(obs.packed[None])[0, 0]
        inputs = {
            name: getattr(obs, name)[None].numpy()
            for name in ("target", "packed", "colors", "wb", "matrix")
        }
        roi = (680, 480, 160, 160) if w == 1536 else (480, 680, 160, 160)
        values = {}
        for arm in LABELS:
            backend, batch = ARMS.get(arm, ("ieee-fp32", 4))
            with combined(model, engines[backend]):
                values[arm] = restore_tiled(
                    model,
                    raw,
                    obs.colors,
                    shot=recipe.shot,
                    read=recipe.read,
                    wb=obs.wb,
                    matrix=obs.matrix,
                    device="cuda",
                    batch_size=batch,
                    precision="float32" if arm == "ieee" else "float16",
                    **SHAPE,
                )[0][None].numpy()
        scores = {
            arm: float(prior.photometry(value, inputs)["srgb_psnr"][0])
            for arm, value in values.items()
        }
        row = {
            "provenance": p,
            "roi": roi,
            "sRGB_PSNR": scores,
            "deltas": native_deltas({arm: value[0] for arm, value in values.items()}),
        }
        if index < 2:
            name = ("pinakothek", "highlight")[index]
            row["id"] = name
            row["boards"] = prior.native_board(
                ROOT,
                name,
                [
                    prior.noisy_malvar(inputs)[0],
                    *(value[0] for value in values.values()),
                    inputs["target"][0],
                ],
                inputs,
                {**p, "checkpoint": checkpoint, "native_roi": roi},
                labels=("Noisy Malvar", *LABELS.values(), "Exact GT"),
                triplet_indices=(0, 4, 6),
                exposure=p["display_exposure"],
                roi=roi,
            )
        rows.append(row)
        print("exact", index, scores, flush=True)
    return rows


def full_rgb16(result, raw, meta):
    previous = prior.read_json(DINO / "full.json")
    files = {tag: prior.checked(item["tiff"]) for tag, item in result["outputs"].items()}
    files["ieee"] = prior.checked(previous["FP32_anchor"])
    data = {tag: tifffile.memmap(path) for tag, path in files.items()}
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    h, w = raw.shape
    assert meta.flip == 0
    rows = {}
    for tag, anchor in (("eager8", "eager4"), ("compiled2", "compiled4"), ("compiled2", "ieee")):
        stats = prior.exported_differences(files[anchor], files[tag], SHAPE)
        peak, (x, y, ch) = stats["max_DN16_and_sensor_xy_channel"]
        left, top = min(max(x - 80, 0), w - 160), min(max(y - 80, 0), h - 160)
        assert abs(int(data[tag][y, x, ch]) - int(data[anchor][y, x, ch])) == peak
        cut = {
            arm: data[arm][top : top + 160, left : left + 160].astype(np.float32).transpose(2, 0, 1)
            / 65535
            for arm in LABELS
        }
        which = f"{tag}-vs-{anchor}"
        rows[which] = {
            **stats,
            "clip_strata": clip_strata(raw, data[tag], data[anchor]),
            "roi": [left, top, 160, 160],
            "exposure": 1,
            "board": prior.native_png(
                ROOT / f"{which}-outlier.png", sensor_pixels(cut, wb, matrix, 1)
            ),
        }
        print("full", which, stats, flush=True)
    return rows


@torch.inference_mode()
def main(action):
    prior.prepare()
    if action == "camera":
        model, checkpoint = prior.bound_model()
        plans = build_refs(3)
        engines = engine_set(plans)
        torch.cuda.synchronize()
        with torch.cuda.stream(torch.cuda.Stream()):
            cab = cab_boards(model, engines)
            exact = exact_targets(model, engines, checkpoint)
        prior.write_json(
            ROOT / "camera-exact.json",
            {
                "driver": prior.reference(__file__),
                "checkpoint": checkpoint,
                "plans": plans,
                "exact_cases": prior.reference(prior.EXACT),
                "cab_fixture": prior.reference(CAB_FIXTURE),
                "exact": exact,
                "cab": cab,
            },
        )
    else:
        assert action == "full"
        result = prior.read_json(ROOT / "benchmark.json")
        raw, meta = prior.read_raw(prior.checked(result["source"]))
        prior.write_json(
            ROOT / "full-audit.json",
            {
                "driver": prior.reference(__file__),
                "checkpoint": result["checkpoint"],
                "plans": result["plans"],
                "benchmark": prior.reference(ROOT / "benchmark.json"),
                "main": main_boards(result, meta),
                "full": full_rgb16(result, raw, meta),
            },
        )


if __name__ == "__main__":
    import sys

    main(sys.argv[1])
