"""Interleave fixed-geometry candidate batch sizes on cached photo tiles."""
import gc
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name("corpus100k-overlap-v1")))
from benchmark import TILE, batches, build_refs, combined, engine_set, prior
from demosaic.cfa import pack
from demosaic.precision import amp_context

ARMS = {"eager2": ("eager", 2), "eager4": ("eager", 4), "eager8": ("eager", 8),
        "compiled2": ("static", 2), "compiled4": ("static", 4)}
PROFILE = {"shot": prior.SHOT, "read": prior.READ}


def tensor_arguments(raw, meta, group):
    tiles = torch.stack([raw[y:y + TILE, x:x + TILE] for y, x in group])
    packed = pack(tiles[:, None].cuda()).contiguous(memory_format=torch.channels_last)
    variance = packed.clamp_min(0) * prior.SHOT + prior.READ
    n = len(group)
    colors = torch.as_tensor(prior.color_indices(meta.pattern), device="cuda")[None].expand(n, -1)
    wb = torch.as_tensor(meta.white_balance, dtype=torch.float32, device="cuda")[None].expand(n, -1)
    matrix = torch.as_tensor(meta.camera_to_srgb, dtype=torch.float32, device="cuda")[None].expand(n, -1, -1)
    return packed, variance, colors, wb, matrix


@torch.inference_mode()
def main():
    prior.prepare()
    fixture = prior.read_json(prior.FIXTURE)
    source = prior.reference(fixture["noisy"])
    raw_np, meta = prior.read_raw(prior.checked(source))
    raw = torch.from_numpy(raw_np)
    model, checkpoint = prior.bound_model()
    refs = build_refs(3)
    engines = engine_set(refs)
    model.set_noise(prior.SHOT, prior.READ)
    grid = [pair for batch in batches(raw.shape, 64) for pair in batch]
    groups = [grid[index:index + 8] for index in (0, 80, 160, 240, 320, 400, 512)]
    rows = []
    fidelity = []
    jobs_before = prior.gpu_jobs()
    rng = np.random.default_rng(20261119)
    torch.cuda.synchronize()
    stream = torch.cuda.Stream()
    with torch.cuda.stream(stream):
        for pass_id in range(2):
            for group_id, group in enumerate(groups):
                requested = {
                    tag: [tensor_arguments(raw, meta, group[i:i + batch]) for i in range(0, 8, batch)]
                    for tag, (_, batch) in ARMS.items()
                }
                outputs = {}
                order = list(rng.permutation(list(ARMS)))
                if group_id == 0 and pass_id == 0:
                    for tag in order:
                        backend, _ = ARMS[tag]
                        with combined(model, engines[backend]), amp_context("cuda", dtype="float16"):
                            for args in requested[tag]:
                                model(*args)
                    stream.synchronize()
                for tag in order:
                    backend, batch = ARMS[tag]
                    torch.cuda.reset_peak_memory_stats()
                    start = time.perf_counter()
                    gpu_start, gpu_end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                    gpu_start.record()
                    with combined(model, engines[backend]), amp_context("cuda", dtype="float16"):
                        preds = [model(*args) for args in requested[tag]]
                    gpu_end.record()
                    stream.synchronize()
                    duration = time.perf_counter() - start
                    peak = torch.cuda.max_memory_allocated()
                    outputs[tag] = torch.cat([out.float().cpu() for out in preds])
                    rows.append(dict(tag=tag, batch=batch, pass_id=pass_id, group_id=group_id,
                                     seconds=duration, gpu_seconds=gpu_start.elapsed_time(gpu_end) / 1000,
                                     peak_allocated_bytes=peak))
                    del preds
                for tag in outputs:
                    anchor = "compiled4" if tag.startswith("compiled") else "eager4"
                    diff = (outputs[tag] - outputs[anchor]) * 65535
                    fidelity.append(dict(tag=tag, anchor=anchor, pass_id=pass_id, group_id=group_id,
                                         RMS_DN16=float(diff.square().mean().sqrt()), max_DN16=float(diff.abs().max())))
                del outputs, requested
                gc.collect()
                print(pass_id, group_id, [(r["tag"], round(r["seconds"], 3)) for r in rows[-len(ARMS):]], flush=True)
    summary = {}
    for tag in ARMS:
        scores = [row for row in rows if row["tag"] == tag]
        summary[tag] = {metric: float(np.median([row[metric] for row in scores]))
                        for metric in ("seconds", "gpu_seconds", "peak_allocated_bytes")}
    print(summary, flush=True)
    prior.write_json(ROOT / "screen.json", dict(driver=prior.reference(__file__), source=source,
        fixture=prior.reference(prior.FIXTURE), checkpoint=checkpoint, plans=refs, profiles=PROFILE,
        settings=dict(tile=TILE, overlap=64), jobs_before=jobs_before, jobs_after=prior.gpu_jobs(),
        groups=groups, versions={**prior.versions(), "TensorRT": prior.trt.__version__},
        rows=rows, fidelity=fidelity, summary=summary))


if __name__ == "__main__":
    main()
