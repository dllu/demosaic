"""Interleave complete, identical 102 MP tile grids by eight-tile blocks."""

import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
EXTERNAL = Path("/mnt/external/demosaic/corpus100k-batch-v1")
sys.path.insert(0, str(ROOT.with_name("corpus100k-overlap-v1")))
from benchmark import DINO, TILE, batches, build_refs, combined, engine_set, prior

from demosaic.cfa import pack
from demosaic.precision import amp_context

ARMS = {
    "eager4": ("eager", 4),
    "eager8": ("eager", 8),
    "compiled4": ("static", 4),
    "compiled2": ("static", 2),
}
SHAPE = {"tile": TILE, "overlap": 64}
PROFILE = {"shot": prior.SHOT, "read": prior.READ}
BLOCK = 8


def run_batch(model, engine, raw, cfa, wb, matrix, group):
    tensor = torch.stack([raw[y : y + TILE, x : x + TILE] for y, x in group])[:, None]
    packed = pack(tensor.cuda()).contiguous(memory_format=torch.channels_last)
    var = packed.clamp_min(0) * prior.SHOT + prior.READ
    n = len(group)
    with combined(model, engine), amp_context("cuda", dtype="float16"):
        rgb = model(packed, var, cfa.expand(n, -1), wb.expand(n, -1), matrix.expand(n, -1, -1))
    return rgb.float().cpu()


def timings(rows):
    rng = np.random.default_rng(2026111907)
    ns = np.array([row["seconds"] for row in rows])
    # Correlated work and shared load span adjacent regions. Pair blocks of
    # five adjacent groups across all methods on every bootstrap draw.
    block_sum = np.asarray([ns[i : i + 5].sum(axis=0) for i in range(0, len(rows), 5)])
    samples = rng.integers(0, len(block_sum), (6000, len(block_sum)))
    totals = ns.sum(axis=0)
    resamples = block_sum[samples].sum(axis=1)
    changes = {}
    for anchor, candidate in (
        ("eager4", "eager8"),
        ("eager4", "compiled4"),
        ("compiled4", "compiled2"),
    ):
        a, b = [list(ARMS).index(tag) for tag in (anchor, candidate)]
        changes[f"{candidate}_vs_{anchor}"] = {
            "percentage": 100 * (totals[b] / totals[a] - 1),
            "CI95_percentage": (
                100 * np.quantile(resamples[:, b] / resamples[:, a] - 1, [0.025, 0.975])
            ).tolist(),
        }
    return {"seconds": dict(zip(ARMS, totals.tolist(), strict=True)), "relative": changes}


@torch.inference_mode()
def main():
    prior.prepare()
    previous = prior.read_json(DINO / "full.json")
    decode = time.perf_counter()
    raw_np, meta = prior.read_raw(prior.checked(previous["source"]))
    decode = time.perf_counter() - decode
    raw = torch.from_numpy(raw_np)
    setup = time.perf_counter()
    model, checkpoint = prior.bound_model()
    setup = time.perf_counter() - setup
    plans = build_refs(3)
    assert plans == previous["plans"] and checkpoint == previous["checkpoint"]
    ready = time.perf_counter()
    engines = engine_set(plans)
    ready = time.perf_counter() - ready
    fixture = prior.read_json(prior.FIXTURE)
    model.set_noise(prior.SHOT, prior.READ)
    cfa = torch.as_tensor(prior.color_indices(meta.pattern), device="cuda")[None]
    wb = torch.as_tensor(meta.white_balance, dtype=torch.float32, device="cuda")[None]
    matrix = torch.as_tensor(meta.camera_to_srgb, dtype=torch.float32, device="cuda")[None]
    grid = [xy for batch in batches(raw.shape, SHAPE["overlap"]) for xy in batch]
    assert raw.numel() == 101995852 and len(grid) == 520
    h, w = raw.shape
    edge = torch.hann_window(TILE, periodic=False).clamp_min(0.02)
    weight = edge[:, None] * edge[None, :]
    accum = {name: torch.zeros(3, h, w, dtype=torch.float32) for name in ARMS}
    norm = torch.zeros(h, w, dtype=torch.float32)
    for y, x in grid:
        norm[y : y + TILE, x : x + TILE].add_(weight)
    assert torch.all(norm > 0)
    torch.cuda.synchronize()
    rows = []
    jobs_before = prior.gpu_jobs()
    memory_peaks = {name: 0 for name in ARMS}
    rng = np.random.default_rng(2026111907)
    with torch.cuda.stream(torch.cuda.Stream()):
        for name, (backend, batch) in ARMS.items():
            run_batch(model, engines[backend], raw, cfa, wb, matrix, grid[:batch])
        for start in range(0, len(grid), BLOCK):
            group = grid[start : start + BLOCK]
            order = rng.permutation(list(ARMS)).tolist()
            arm_timing = {}
            stages = {}
            for tag in order:
                backend, size = ARMS[tag]
                torch.cuda.reset_peak_memory_stats()
                block_start = time.perf_counter()
                compute, blend = 0.0, 0.0
                for i in range(0, len(group), size):
                    chunk = group[i : i + size]
                    launch = time.perf_counter()
                    result = run_batch(model, engines[backend], raw, cfa, wb, matrix, chunk)
                    returned = time.perf_counter()
                    for rgb, (y, x) in zip(result, chunk, strict=True):
                        accum[tag][:, y : y + TILE, x : x + TILE].add_(rgb * weight)
                    compute += returned - launch
                    blend += time.perf_counter() - returned
                arm_timing[tag] = time.perf_counter() - block_start
                stages[tag] = {"pack_restore_return_seconds": compute, "blend_seconds": blend}
                memory_peaks[tag] = max(memory_peaks[tag], torch.cuda.max_memory_allocated())
            rows.append(
                {
                    "origins_yx": group,
                    "order": order,
                    "seconds": [arm_timing[tag] for tag in ARMS],
                    "stages": stages,
                }
            )
            if len(rows) % 8 == 0:
                print("blocks", len(rows), len(grid) // BLOCK, timings(rows)["seconds"], flush=True)
    outputs = {}
    for tag, (_, batch) in ARMS.items():
        start = time.perf_counter()
        rgb = accum.pop(tag).div_(norm)
        phase = time.perf_counter() - start
        name = EXTERNAL / f"{tag}.tiff"
        start = time.perf_counter()
        prior.write_rgb16(name, rgb.permute(1, 2, 0).numpy(), metadata=meta, flip=meta.flip)
        writer = time.perf_counter() - start
        crops = EXTERNAL / f"{tag}-native.npz"
        np.savez_compressed(
            crops,
            **{
                r["name"]: rgb[:, y : y + 160, x : x + 160].numpy()
                for r in fixture["regions"]
                for x, y in (r["noisy_xy"],)
            },
        )
        outputs[tag] = {
            "tiff": prior.reference(name),
            "crops": prior.reference(crops),
            "batch": batch,
            "normalize_seconds": phase,
            "tiff_seconds": writer,
            "peak_torch_bytes": memory_peaks[tag],
        }
        print("export", tag, phase, writer, flush=True)
    for tag, anchor in (("eager4", "eager"), ("compiled4", "static")):
        assert outputs[tag]["tiff"]["sha256"] == previous["exports"][anchor]["sha256"], tag
    summary = timings(rows)
    for tag, value in summary["seconds"].items():
        summary.setdefault("equivalent_restore_seconds", {})[tag] = (
            value + outputs[tag]["normalize_seconds"]
        )
    prior.write_json(
        ROOT / "benchmark.json",
        {
            "driver": prior.reference(__file__),
            "checkpoint": checkpoint,
            "plans": plans,
            "versions": {**prior.versions(), "TensorRT": prior.trt.__version__},
            "jobs_before": jobs_before,
            "jobs_after": prior.gpu_jobs(),
            "source": previous["source"],
            "profiles": PROFILE,
            "arms": ARMS,
            "settings": SHAPE,
            "decode_seconds": decode,
            "checkpoint_seconds": setup,
            "engines_seconds": ready,
            "timing_columns": list(ARMS),
            "summary": summary,
            "timings": rows,
            "outputs": outputs,
            "source_revision": os.environ["STUDY_REVISION"],
        },
    )
    print(summary, flush=True)


if __name__ == "__main__":
    main()
