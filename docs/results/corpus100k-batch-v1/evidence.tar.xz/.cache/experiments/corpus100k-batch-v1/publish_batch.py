"""Publish fixed-grid timings, source bindings and independently viewed crops."""

import shutil
import tarfile
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
IMAGES = REPO / "docs" / "images" / ROOT.name
RESULTS = REPO / "docs" / "results" / ROOT.name
NAMES = (
    "screen",
    "benchmark",
    "full-audit",
    "camera-exact",
    "wire-gap",
    "view-full",
    "view-camera",
    "visual",
)


def board(source, indices):
    src = checked(source["image"])
    dst = IMAGES / src.name
    assert not dst.exists()
    shutil.copyfile(src, dst)
    frozen = reference(dst)
    assert frozen["sha256"] == source["image"]["sha256"]
    pixels = np.asarray(Image.open(dst).convert("RGB"))
    for cell in source["panels"]:
        x, y, w, h = cell["png_xywh"]
        crop = pixels[y : y + h, x : x + w]
        assert (w, h) == (160, 160) and crop.shape == (h, w, 3)
        indices[cell.get("name", cell.get("label"))] = crop
    return {**source, "image": {**frozen, "path": dst.name}}


def compiled_batch_four_triplet(source, comparison):
    original = checked(source["image"])
    target = IMAGES / original.name
    assert not target.exists()
    image = Image.new("RGB", (512, 192), "#eeeeee")
    draw = ImageDraw.Draw(image)
    labels = ("Noisy Malvar", "TensorRT FP16 ×4", "Exact GT")
    panels = []
    for i, label in enumerate(labels):
        x = 8 + 168 * i
        draw.text((x, 5), label.replace(" ×", " batch "), fill="black")
        image.paste(Image.fromarray(comparison[label]), (x, 24))
        panels.append({"label": label, "png_xywh": [x, 24, 160, 160]})
    image.save(target)
    pixels = np.asarray(Image.open(target).convert("RGB"))
    for label, panel in zip(labels, panels, strict=True):
        x = panel["png_xywh"][0]
        np.testing.assert_array_equal(comparison[label], pixels[24:184, x : x + 160])
    return {
        "image": {**reference(target), "path": target.name},
        "panels": panels,
        "assembled_from_comparison": True,
        "source_batch_two_triplet": source["image"],
    }


def review_boards(full, quality):
    main = [{**row, "board": board(row["board"], {})} for row in full["main"]]
    cab = []
    for row in quality["cab"]:
        images = {
            tag: {**entry, "board": board(entry["board"], {})}
            for tag, entry in row["boards"].items()
        }
        assert set(images) == {"display4", "display16"}
        cab.append({**row, "boards": images})
    exact = []
    for row in quality["exact"]:
        if "boards" not in row:
            exact.append(row)
            continue
        compare = {}
        side = board(row["boards"]["board"], compare)
        triplet = compiled_batch_four_triplet(row["boards"]["triplet"], compare)
        exact.append({**row, "boards": {**row["boards"], "board": side, "triplet": triplet}})
    surprises = {k: {**row, "board": board(row["board"], {})} for k, row in full["full"].items()}
    return {"main": main, "cab": cab, "exact": exact, "full_frame_outliers": surprises}


def main():
    refs = {tag: reference(ROOT / f"{tag}.json") for tag in NAMES}
    rows = {tag: read_json(checked(r)) for tag, r in refs.items()}
    screen, timing, full, camera, wires, view_full, view_camera, visual = (
        rows[key] for key in NAMES
    )
    assert (
        timing["checkpoint"]
        == screen["checkpoint"]
        == full["checkpoint"]
        == camera["checkpoint"]
        == wires["checkpoint"]
    )
    assert timing["plans"] == screen["plans"] == full["plans"] == camera["plans"] == wires["plans"]
    assert len(timing["timings"]) == 65 and len(wires["rows"]) == 24
    assert len(full["main"]) == len(camera["cab"]) == 4
    assert len(camera["exact"]) == 6 and len(full["full"]) == 3
    assert (
        view_full["source"] == refs["full-audit"] and view_camera["source"] == refs["camera-exact"]
    )
    assert full["benchmark"] == refs["benchmark"]
    assert visual["full"] == refs["view-full"] and visual["camera"] == refs["view-camera"]
    for src in (
        timing["source"],
        timing["checkpoint"],
        *timing["plans"].values(),
        *view_full["vw"].values(),
        *view_camera["vw"].values(),
    ):
        checked(src)
    for row in timing["outputs"].values():
        checked(row["tiff"])
        checked(row["crops"])
    IMAGES.mkdir(parents=True)
    RESULTS.mkdir(parents=True)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "checkpoint": timing["checkpoint"],
            "settings": timing["settings"],
            "arms": timing["arms"],
            "main_profile": timing["profiles"],
            "views": review_boards(full, camera),
            "review": visual,
        },
    )
    deps = (
        (
            "corpus100k-overlap-v1",
            ("benchmark.py", "review_geometry.py", "full-review.json", "quality.json"),
        ),
        (
            "corpus100k-trt-dino-v1",
            ("dino_review.py", "dino_engine.py", "full.json", "dino-t512-l3.json"),
        ),
        ("corpus100k-trt-tactics-v1", ("full_quality.py", "tactics.py", "wires.py")),
        (
            "corpus100k-fp16-throughput-v1",
            ("full_throughput.py", "review_throughput.py", "screen_throughput.py"),
        ),
        ("corpus100k-faster-inference-v1", ("trt_hidden.py", "trt-review.json")),
        ("corpus100k-mixed-precision-v1", ("screen.py", "full_production.py", "first-fp32.json")),
    )
    files = [
        *refs.values(),
        *[r["driver"] for r in rows.values() if "driver" in r],
        reference(__file__),
        reference(manifest),
        wires["plan"],
        wires["captures"],
        camera["exact_cases"],
        camera["cab_fixture"],
        screen["fixture"],
    ]
    for directory, names in deps:
        files.extend(reference(ROOT.with_name(directory) / k) for k in names)
    evidence = RESULTS / "evidence.tar.xz"
    hashes = {}
    with tarfile.open(evidence, "x:xz", preset=4, dereference=True) as tar:
        for source in {v["path"]: v for v in files}.values():
            artifact = checked(source)
            name = artifact.relative_to(REPO).as_posix()
            tar.add(artifact, arcname=name)
            hashes[name] = source["sha256"]
    with tarfile.open(evidence) as tar:
        for name, digest in hashes.items():
            assert sha256(tar.extractfile(name).read()).hexdigest() == digest
    full_metrics = {
        k: {field: v for field, v in row.items() if field != "board"}
        for k, row in full["full"].items()
    }
    write_json(
        RESULTS / "publication.json",
        {
            "completion_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "source": timing["source"],
            "checkpoint": timing["checkpoint"],
            "plans": timing["plans"],
            "timing_source_revision": timing["source_revision"],
            "versions": timing["versions"],
            "fixed_geometry": timing["settings"],
            "noise": timing["profiles"],
            "arms": timing["arms"],
            "resident_screen": screen["summary"],
            "full_tile_loop": timing["summary"],
            "outputs": timing["outputs"],
            "one_time_seconds": {
                key: timing[key]
                for key in ("decode_seconds", "checkpoint_seconds", "engines_seconds")
            },
            "full_frame_RGB16": full_metrics,
            "exact_sRGB_PSNR": [
                {"source": r["provenance"]["photo"], "scores": r["sRGB_PSNR"]}
                for r in camera["exact"]
            ],
            "wire_gap": wires["summary"],
            "evaluation": {
                "checkpoint_type": "Existing Corpus 100k EMA",
                "completed": [
                    "paired full-frame timings and RGB16 audit",
                    "six exact photo contexts",
                    "24 controlled wire/gap fields",
                    "native review of both standing GFX100S scenes",
                ],
                "broad_panel": "Earlier precision study covers fixed photo and measured-camera panels. Batch study uses scoped targets.",
                "reference": "General recommended V120 remains separate from the same-checkpoint Corpus 100k precision comparison.",
            },
            "receipts": refs,
            "manifest": reference(manifest),
            "evidence": reference(evidence),
            "members": hashes,
        },
    )


if __name__ == "__main__":
    main()
