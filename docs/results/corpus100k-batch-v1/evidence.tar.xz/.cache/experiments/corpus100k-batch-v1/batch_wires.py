"""Measure batch-shape changes in isolated weak wires, true gaps and quiet color."""

from statistics import mean

import numpy as np
import torch
from benchmark_batches import ARMS, ROOT, build_refs, combined, engine_set, prior
from wires import KEYS, LUMA, SOURCE, evaluate

from demosaic.archive_metrics import linear_rgb
from demosaic.precision import amp_context


def measure(prediction, data, support, frequencies):
    axis = np.arange(128, dtype=float) - 63.5
    x, y = (a.ravel() for a in np.meshgrid(axis, axis))
    phase = 2 * np.pi * np.asarray(frequencies) @ np.stack((x, y))
    terms = np.column_stack(
        [
            np.ones_like(x),
            x,
            y,
            x * x,
            x * y,
            y * y,
            np.cos(phase[0]),
            np.sin(phase[0]),
            np.cos(phase[1]),
            np.sin(phase[1]),
        ]
    )
    intact = support >= 0.97
    gaps = support == 0
    fit = np.linalg.pinv(terms[intact.ravel()])[-4:]
    fit_gaps = np.linalg.pinv(terms[gaps.ravel()])[-2:]
    target = linear_rgb(data["target"], data)
    lum = np.einsum("c,bchw->bhw", LUMA, target)[:, 192:320, 192:320]
    np.testing.assert_array_equal(lum[0][gaps], lum[2][gaps])
    weak = (lum[0] - lum[2])[intact]
    strong = (lum[2] - lum[3])[intact]
    values = evaluate(
        prediction,
        data,
        fit,
        intact,
        weak,
        target[3, :, 200:312, 200:312],
        fit @ weak,
        fit @ strong,
    )
    output = np.einsum("c,bchw->bhw", LUMA, linear_rgb(prediction, data))[:, 192:320, 192:320]
    error = output[0][gaps] - lum[0][gaps]
    leaked = output[0][gaps] - output[2][gaps]
    return {
        **values,
        "gap_luma_RMS_DN16": float(np.sqrt(np.mean(error**2)) * 65535),
        "extra_weak_in_gap_DN16": float(np.linalg.norm(fit_gaps @ leaked) * 65535),
    }


@torch.inference_mode()
def main():
    prior.prepare()
    model, checkpoint = prior.bound_model()
    plans = build_refs(3)
    engines = engine_set(plans)
    plan, captures = (prior.read_json(SOURCE / f"{name}.json") for name in ("plan", "captures"))
    rows = []
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for label in ("iso400", "iso6400"):
            profile = plan["profiles"][label]
            model.set_noise(profile["shot"], profile["read"])
            cases = []
            for case in captures["rows"]:
                geom = plan["sources"][case["index"]]["geometry"]
                if case["noise"] == label and geom["family"] in ("ellipse", "strip"):
                    cases.append((case, geom))
            assert len(cases) == 12
            for start in range(0, len(cases), 2):
                pair = cases[start : start + 2]
                fields, masks = [], []
                for case, _ in pair:
                    with np.load(prior.checked(case["input"]), allow_pickle=False) as src:
                        fields.append({key: src[key] for key in (*KEYS, "target")})
                        masks.append(src["support"][64:192, 64:192])
                args = [
                    torch.from_numpy(np.concatenate([p[key] for p in fields])).cuda()
                    for key in KEYS
                ]
                assert args[0].shape == (8, 4, 256, 256)
                args[0] = args[0].contiguous(memory_format=torch.channels_last)
                predictions = {}
                for arm, (name, n) in ARMS.items():
                    with combined(model, engines[name]):
                        pieces = []
                        for i in range(0, 8, n):
                            with amp_context("cuda", dtype="float16"):
                                pieces.append(
                                    model(*(value[i : i + n] for value in args)).cpu().numpy()
                                )
                        predictions[arm] = np.concatenate(pieces, axis=0)
                for i, (case, geom) in enumerate(pair):
                    scores = {
                        arm: measure(
                            output[i * 4 : (i + 1) * 4], fields[i], masks[i], geom["frequency"]
                        )
                        for arm, output in predictions.items()
                    }
                    rows.append(
                        {
                            "profile": label,
                            "id": case["index"],
                            "input": case["input"],
                            "scores": scores,
                        }
                    )
                print(label, start + 2, len(cases), flush=True)
    summary = {}
    for noise in ("iso400", "iso6400"):
        summary[noise] = {}
        selected = [row["scores"] for row in rows if row["profile"] == noise]
        for arm, parent in (("eager8", "eager4"), ("compiled2", "compiled4")):
            values = {}
            for metric in selected[0][arm]:
                delta = [row[arm][metric] - row[parent][metric] for row in selected]
                values[metric] = {"mean_delta": mean(delta), "min": min(delta), "max": max(delta)}
            summary[noise][f"{arm}_vs_{parent}"] = values
    prior.write_json(
        ROOT / "wire-gap.json",
        {
            "driver": prior.reference(__file__),
            "plan": prior.reference(SOURCE / "plan.json"),
            "captures": prior.reference(SOURCE / "captures.json"),
            "checkpoint": checkpoint,
            "plans": plans,
            "rows": rows,
            "summary": summary,
        },
    )
    print(summary, flush=True)


if __name__ == "__main__":
    main()
