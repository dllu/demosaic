"""Run and time RAW decode, production tiled restoration and RGB16 export."""
from contextlib import nullcontext
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
import tifffile
import torch

from demosaic.cfa import color_indices
from demosaic.io import read_raw, write_rgb16
from demosaic.inference import restore_tiled
from demosaic.experiments.artifacts import read_json, reference, write_json
from screen import ROOT, READ, SHOT, load, policy, versions


def gpu_jobs():
    text=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True)
    return [(int(pid),memory.strip()) for line in text.splitlines() if line.strip() for pid,memory in (line.split(','),)]


@torch.inference_mode()
def restore(mode, run):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    fixture=read_json(Path('configs/gfx-qualitative-20231231.json'))
    binding=reference(fixture['noisy'])
    started=time.perf_counter()
    raw,metadata=read_raw(binding['path'])
    loaded_raw=time.perf_counter()
    model,checkpoint=load()
    torch.cuda.synchronize()
    loaded_model=time.perf_counter()
    original=gpu_jobs()
    with (nullcontext() if mode=="fp16" else policy(model,mode)):
        rgb,stats=restore_tiled(model,raw,color_indices(metadata.pattern),shot=SHOT,read=READ,
                        tile=512,overlap=64,batch_size=4,device='cuda',wb=metadata.white_balance,
                        matrix=metadata.camera_to_srgb,
                        precision='float32' if mode in ('fp32','tf32') else 'float16',amp=mode!='tf32')
    restored=time.perf_counter()
    output=ROOT/f'{run}-{mode}.tiff'
    write_rgb16(output,rgb.permute(1,2,0).numpy(),metadata=metadata,flip=metadata.flip)
    exported=time.perf_counter()
    source=reference(output)
    image=tifffile.memmap(source['path'])
    assert image.dtype==np.uint16 and image.shape[-1]==3 and image.shape[0]*image.shape[1]==raw.size
    np.savez_compressed(ROOT/f'{run}-{mode}-native.npz',
        **{r['name']:rgb[:,r['noisy_xy'][1]:r['noisy_xy'][1]+160,r['noisy_xy'][0]:r['noisy_xy'][0]+160].numpy() for r in fixture['regions']})
    row={'driver':reference(__file__),'policy':mode,'source':binding,'checkpoint':checkpoint,'backend':versions(),
          'noise':{'shot':SHOT,'read':READ},'reader_seconds':loaded_raw-started,'checkpoint_setup_seconds':loaded_model-loaded_raw,
          'restore_wall_seconds':restored-loaded_model,'writer_seconds':exported-restored,
          'raw_to_rgb16_seconds':exported-started,'timing':stats,'RGB16':source,
          'native_float_RGB':reference(ROOT/f'{run}-{mode}-native.npz'),
          'jobs_before':original,'jobs_after':gpu_jobs(),'flip':metadata.flip,'RGB16_shape':list(image.shape),
          'RGB16_dtype':str(image.dtype)}
    write_json(ROOT/f'{run}-{mode}.json',row)
    print(mode,'RAW→RGB16',row['raw_to_rgb16_seconds'],'restore',stats['seconds'], 'blend',stats['blend_seconds'],flush=True)


if __name__=='__main__':
    restore(*sys.argv[1:])
