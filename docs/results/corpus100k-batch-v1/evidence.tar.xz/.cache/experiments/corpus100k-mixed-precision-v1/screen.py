"""Compare Corpus 100k arithmetic with resident, pre-packed GFX batches."""
from contextlib import contextmanager
import importlib.metadata
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import amp_context
from demosaic.io import read_raw

ROOT=Path(__file__).resolve().parent
PRIMARY=Path('docs/results/full-corpus-long100k-primary-v1/primary.json')
MODEL='scale-long100k'
POLICIES=('fp32','fp16','fp16-hidden','tf32')
SHOT,READ=.00128,6.5536e-6


def load():
    binding=read_json(PRIMARY)['models'][MODEL]['checkpoint']
    model,state=load_checkpoint(binding['path'],'cuda')
    assert state['step']==100000 and state['loaded_sha256']==binding['sha256'] and 'ema' in state
    model.eval().to(memory_format=torch.channels_last)
    assert model.config.physical_fp32 and model.config.variance_stabilization and model.config.physical_anchors
    assert not model.pretrained_rgb.network.hidden_autocast
    return model,binding


@contextmanager
def policy(model, name):
    trunk=model.pretrained_rgb.network
    before=trunk.hidden_autocast
    conv,matmul=torch.backends.cudnn.conv.fp32_precision,torch.backends.cuda.matmul.fp32_precision
    trunk.hidden_autocast=name=='fp16-hidden'
    try:
        if name=='tf32':
            torch.backends.cudnn.conv.fp32_precision='tf32'
            torch.backends.cuda.matmul.fp32_precision='tf32'
            yield
        else:
            with amp_context('cuda',dtype='float32' if name=='fp32' else 'float16'):
                yield
    finally:
        trunk.hidden_autocast=before
        torch.backends.cudnn.conv.fp32_precision=conv
        torch.backends.cuda.matmul.fp32_precision=matmul


def versions():
    packages={}
    for name in ('torch','torch-tensorrt','tensorrt','nvidia-modelopt','torchao','rawpy'):
        try:
            packages[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name]=None
    return {'packages':packages,'cuda':torch.version.cuda,'cudnn':torch.backends.cudnn.version(),
            'hardware':torch.cuda.get_device_name(),'cudnn_benchmark':torch.backends.cudnn.benchmark,
            'cudnn_deterministic':torch.backends.cudnn.deterministic}


def statistics(out,base):
    delta=(out.astype(np.float64)-base)*65535
    absolute=np.abs(delta)
    start=176
    crops=delta[...,start:start+160,start:start+160]
    return {'rms_DN16':float(np.sqrt(np.mean(delta**2))),
            'mean_abs_DN16':float(absolute.mean()),
            'absolute_percentile_DN16':np.percentile(absolute,[95,99,99.9,100]).tolist(),
            'ROI_RMS_DN16':np.sqrt(np.mean(crops**2,axis=(1,2,3))).tolist(),
            'ROI_channel_mean_DN16':crops.mean((2,3)).tolist()}


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    config=read_json(Path('configs/gfx-qualitative-20231231.json'))
    raw_source=reference(config['noisy'])
    raw,meta=read_raw(raw_source['path'])
    calibrated=[(r['noisy_xy'][0]-176,r['noisy_xy'][1]-176) for r in config['regions']]
    tiles=np.stack([raw[y:y+512,x:x+512]for x,y in calibrated])
    sensor=pack(torch.from_numpy(tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors=torch.as_tensor(color_indices(meta.pattern),device='cuda')[None].expand(4,-1)
    wb=torch.as_tensor(meta.white_balance,device='cuda',dtype=torch.float32)[None].expand(4,-1)
    matrix=torch.as_tensor(meta.camera_to_srgb,device='cuda',dtype=torch.float32)[None].expand(4,-1,-1)
    args=(sensor,sensor.clamp_min(0)*SHOT+READ,colors,wb,matrix)
    model,binding=load()
    model.set_noise(SHOT,READ)
    bench={}
    images={}
    for mode in POLICIES:
        with policy(model,mode):
            for _ in range(2):
                image=model(*args)
        torch.cuda.synchronize()
        assert image.dtype==torch.float32 and image.shape==(4,3,512,512) and torch.isfinite(image).all()
        images[mode]=image.cpu().numpy()
        bench[mode]={'trials':[],'stage_sample':[]}
        print('warmed',mode,statistics(images[mode],images['fp32'])['rms_DN16'],flush=True)
    for turn in range(8):
        order=POLICIES if turn%2==0 else POLICIES[::-1]
        shift=turn//2
        order=order[shift:]+order[:shift]
        for mode in order:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            start=time.perf_counter()
            with policy(model,mode):
                image=model(*args)
            torch.cuda.synchronize()
            bench[mode]['trials'].append({'seconds':time.perf_counter()-start,
                                          'peak_cuda_bytes':torch.cuda.max_memory_allocated()})
    layers={'DINO':model.context.backbone,'restoration_trunk':model.pretrained_rgb.network,
            'native_head':model.pretrained_rgb.network.m_head,'first_encoder':model.pretrained_rgb.network.m_down1,
            'bottleneck':model.pretrained_rgb.network.m_body,'RGB_tail':model.pretrained_rgb.network.m_tail}
    for mode in POLICIES:
        stages={}
        handles=[]
        for name,layer in layers.items():
            def begin(_mod,ins,name=name):
                t=torch.cuda.Event(enable_timing=True)
                t.record()
                stages[name]=(t,str(ins[0].dtype) if ins else None)
            def end(_mod,_args,out,name=name):
                t=torch.cuda.Event(enable_timing=True)
                t.record()
                stages[name]=(*stages[name],t,str(out.dtype) if isinstance(out,torch.Tensor) else None)
            handles+= [layer.register_forward_pre_hook(begin),layer.register_forward_hook(end)]
        with policy(model,mode):
            for _ in range(3):
                stages.clear()
                model(*args)
                torch.cuda.synchronize()
                bench[mode]['stage_sample'].append({k:{'ms':a.elapsed_time(b),'input':i,'output':o} for k,(a,i,b,o) in stages.items()})
        for h in handles:
            h.remove()
        bench[mode]['difference']=statistics(images[mode],images['fp32'])
        bench[mode]['median_seconds']=float(np.median([r['seconds'] for r in bench[mode]['trials']]))
        print(mode,bench[mode]['median_seconds'],bench[mode]['difference'],flush=True)
    np.savez(ROOT/'screen-arrays.npz',**images)
    write_json(ROOT/'screen.json',{'driver':reference(__file__),'checkpoint':binding,'camera':raw_source,
             'crop_geometry':calibrated,'shot':SHOT,'read':READ,'backend':versions(),'results':bench,
             'arrays':reference(ROOT/'screen-arrays.npz'),'timing':'8 interleaved resident B4 forward calls per policy, no hooks, synchronized wall clock. Stage probes are separate. Shared system.'})


if __name__=='__main__':
    main()
