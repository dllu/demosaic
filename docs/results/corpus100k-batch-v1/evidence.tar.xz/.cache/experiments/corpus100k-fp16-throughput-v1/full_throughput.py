"""Benchmark selected eager policies through full-frame RAW to TIFF."""
from contextlib import nullcontext
from statistics import median
import sys
import time

import numpy as np
import tifffile
import torch

from screen_throughput import ROOT, SHOT, READ, amp_context, bound_model, color_indices, gpu_jobs
from screen_throughput import read_json, reference, settings, versions, write_json
from demosaic.inference import positions, restore_tiled
from demosaic.io import read_raw, write_rgb16


def restore(model, raw, colors, shot, read, wb, matrix, mode):
    settings(mode['tune'])
    context = amp_context('cuda', dtype='float16') if mode['keep_cache'] else nullcontext()
    t0 = time.perf_counter()
    try:
        with context:
            pred, timings = restore_tiled(
                model, raw, colors, shot=shot, read=read, wb=wb, matrix=matrix,
                device='cuda', precision='float16', tile=mode['tile'],
                overlap=mode['overlap'], batch_size=mode['batch'],
            )
    finally:
        settings(False)
    return pred, timings, time.perf_counter()-t0


def identify(value):
    return {k:value[k] for k in ('tile','batch','tune','keep_cache','overlap')}


def select(screen):
    control = {'tile':512,'overlap':64,'batch':4,'tune':False,'keep_cache':False}
    cache = dict(control, keep_cache=True)
    records = []
    for row in screen['results']:
        if row['tune'] or row['peak_cuda_gb'] > 8:
            continue
        for overlap, summary in row['overlaps'].items():
            records.append((summary['resident_estimate_seconds'],identify(dict(row,overlap=int(overlap)))))
    def choice(predicate):
        return min((item for item in records if predicate(item[1])),key=lambda item:item[0])[1]
    same = choice(lambda row: row['tile']==512 and row['overlap']==64 and row['batch']!=4)
    larger = choice(lambda row: row['tile']>512 and row['overlap']==64)
    reduced = choice(lambda row: (row['tile'],row['batch'],row['keep_cache'])==
                                 (larger['tile'],larger['batch'],larger['keep_cache']) and row['overlap']==32)
    return {'control':control,'cached':cache,'rebatch':same,'larger':larger,'reduced':reduced}


def blend_bands(length, mode):
    starts = positions(length, mode['tile'], mode['tile']-mode['overlap'])
    coord = np.arange(length)
    return np.min([abs(coord-(a+b+mode['tile'])/2) for a,b in zip(starts,starts[1:])],axis=0)<=8


def exported_differences(baseline, candidate, mode):
    before = tifffile.memmap(baseline)
    after = tifffile.memmap(candidate)
    assert before.shape==after.shape and before.dtype==after.dtype==np.uint16
    hist = np.zeros(65536, dtype=np.int64)
    high = (-1, None)
    y_band=blend_bands(before.shape[0], mode)
    x_band=blend_bands(before.shape[1], mode)
    seam_sumsq = rest_sumsq = seam_n = rest_n = 0
    for y in range(0, before.shape[0], 64):
        delta = np.abs(after[y:y+64].astype(np.int32)-before[y:y+64])
        hist += np.bincount(delta.ravel(),minlength=len(hist))
        if delta.max() > high[0]:
            v,u,c = np.unravel_index(delta.argmax(),delta.shape)
            high = (int(delta[v,u,c]), [int(u), int(y+v), int(c)])
        norms = (delta.astype(float)**2).sum(axis=-1)
        mask = y_band[y:y+len(delta),None] | x_band[None,:]
        seam_n += int(mask.sum())*3
        rest_n += int((~mask).sum())*3
        seam_sumsq += float(norms[mask].sum())
        rest_sumsq += float(norms[~mask].sum())
    cdf = hist.cumsum()
    values = np.arange(len(hist),dtype=float)
    return {'channels':int(cdf[-1]),'fraction_exact':float(cdf[0]/cdf[-1]),
            'fraction_within_one':float(cdf[1]/cdf[-1]),'RMS_DN16':float(np.sqrt(hist@(values**2)/cdf[-1])),
            'p95_99_999_DN16':np.searchsorted(cdf,cdf[-1]*np.array([.95,.99,.999])).tolist(),
            'max_DN16_and_sensor_xy_channel':high,'seam_RMS_DN16':float(np.sqrt(seam_sumsq/seam_n)),
            'interior_RMS_DN16':float(np.sqrt(rest_sumsq/rest_n))}


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    total = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1, 16*2**30/total))
    fixture = read_json('configs/gfx-qualitative-20231231.json')
    source = reference(fixture['noisy'])
    t0 = time.perf_counter()
    raw, meta = read_raw(source['path'])
    t1 = time.perf_counter()
    model, checkpoint = bound_model()
    t2 = time.perf_counter()
    assert meta.flip==0
    colors = color_indices(meta.pattern)
    args = colors, SHOT, READ, meta.white_balance, meta.camera_to_srgb
    screen = reference(ROOT/'screen.json')
    modes = select(read_json(screen['path']))
    print('selected', modes, flush=True)
    runs = {}
    schedule = ('control','cached','rebatch','control','larger','reduced','control')
    for i,name in enumerate(schedule):
        mode = modes[name]
        local_width = mode['tile'] + (mode['tile']-mode['overlap'])*(mode['batch']-1)
        _, _, warm = restore(model,raw[:mode['tile'],:local_width],*args,mode)
        prediction, timings, restore_wall = restore(model,raw,*args,mode)
        views = {}
        crops = ROOT/f'{i}-{name}-native.npz'
        for r in fixture['regions']:
            x,y=r['noisy_xy']
            views[r['name']]=prediction[:,y:y+160,x:x+160].numpy()
        np.savez_compressed(crops,**views)
        tiff = ROOT/f'{i}-{name}.tiff'
        w0 = time.perf_counter()
        write_rgb16(tiff,prediction.permute(1,2,0).numpy(),metadata=meta,flip=meta.flip)
        w1 = time.perf_counter()
        del prediction
        run = {'index':i,'timing':timings,'restore_wall_seconds':restore_wall,'writer_seconds':w1-w0,
               'warmup_seconds':warm,'RGB16':reference(tiff),'crops':reference(crops),'jobs':gpu_jobs()}
        runs.setdefault(name,[]).append(run)
        print(i,name,timings['seconds'],w1-w0,'peak',timings['peak_cuda_gb'],flush=True)
        write_json(ROOT/'full-progress.json',{'modes':modes,'runs':runs},replace=True)
    control = runs['control'][0]['RGB16']['path']
    differences = {}
    for name, group in runs.items():
        differences[name] = [exported_differences(control, row['RGB16']['path'], modes[name]) for row in group
                             if row['RGB16']['path'] != control]
        print(name,'RMS',[v['RMS_DN16'] for v in differences[name]],flush=True)
    write_json(ROOT/'full.json',{'driver':reference(__file__),'screen':screen,'schedule':schedule,'fixture':reference('configs/gfx-qualitative-20231231.json'),
      'source':source,'noise':{'shot':SHOT,'read':READ},'checkpoint':checkpoint,'modes':modes,
      'decode_seconds':t1-t0,'staging_seconds':t2-t1,'runs':runs,'output_differences':differences,
      'versions':versions()})


if __name__ == '__main__':
    main()
