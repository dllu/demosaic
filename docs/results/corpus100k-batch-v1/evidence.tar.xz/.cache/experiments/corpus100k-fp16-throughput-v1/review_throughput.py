"""Bind native comparisons and check geometry changes against exact targets."""
from dataclasses import asdict, replace
import hashlib
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import tifffile
import torch

from full_throughput import ROOT, blend_bands, restore, read_json, reference, write_json, bound_model
from screen_throughput import SHOT, READ
from demosaic.archive_metrics import display, noisy_malvar, photometry
from demosaic.cfa import unpack
from demosaic.experiments.artifacts import checked
from demosaic.io import read_raw
from demosaic.reporting import display_crop
from demosaic.scene_data import observe_scene, sample_scene_recipe

sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
sys.path.insert(0, str(Path('scripts').resolve()))
from render import native_png
import report_scene_wave_guides
native_board = report_scene_wave_guides.native_board

OLD = Path('docs/images/corpus100k-mixed-precision-v1')
CASES = Path('.cache/experiments/query-exterior-colour-v1/plan.json')
TRAINING_AUDIT = Path('docs/results/full-corpus-long100k-training-v1/source-audit.json')
LABELS = {'control':'FP16 512/64','cached':'FP16 cached','rebatch':'FP16 rebatch','larger':'FP16 larger tiles',
          'reduced':'FP16 larger / less overlap'}
RENDER = ('control','cached','larger','reduced')


def board_panels(path, panels):
    source = np.asarray(Image.open(path).convert('RGB'))
    return {cell.get('label',cell.get('name')):source[y:y+h,x:x+w] for cell in panels
            for x,y,w,h in (cell['png_xywh'],)}


def display_sensor(pred, wb, matrix, box, exposure):
    return np.rint(display_crop(pred[None],wb,matrix,box,exposure=exposure)*255).astype(np.uint8)


def difference(pred, base):
    d = (pred.astype(np.float64)-base)*65535
    return {'rms_DN16':float(np.sqrt(np.mean(d*d))), 'max_DN16':float(np.abs(d).max()),
            'channel_mean_DN16':d.mean((1,2)).tolist()}


def main_crops(receipt, meta):
    historical = {row['id']:row for row in read_json(OLD/'manifest.json')['main_views']}
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    rows = []
    for region in read_json(checked(receipt['fixture']))['regions']:
        name = region['name']
        bound = historical[name]['board']
        source = OLD/Path(bound['image']['path']).name
        assert reference(source)['sha256']==bound['image']['sha256']
        prior = board_panels(source,bound['panels'])
        outputs = {}
        for arm in RENDER:
            with np.load(checked(receipt['runs'][arm][0]['crops']),allow_pickle=False) as values:
                outputs[arm] = values[name]
        exposure = 4
        ordered = [(k,v) for k,v in prior.items() if 'Noisy' in k]
        ordered += [(LABELS[arm],display_sensor(torch.from_numpy(image),wb,matrix,(0,0,160,160),exposure))
                    for arm,image in outputs.items()]
        ordered += [(k,v) for k,v in prior.items() if 'ISO100' in k]
        board = native_png(ROOT/f'{name}.png',ordered)
        rows.append({'id':name, 'reference_board':reference(source), 'board':board,
                     'sensor_xywh':[*region['noisy_xy'],160,160],'display_exposure':exposure,
                     'delta':{arm:difference(img,outputs['control']) for arm,img in outputs.items() if arm!='control'}})
    return rows


def cab_crops(model, modes):
    manifest = Path('docs/images/full-corpus-long100k-native-v1/manifest.json')
    rows = []
    for item in read_json(manifest)['images']:
        name = item['id']
        if not name.startswith('mesh-') or item['role'] != 'board':
            continue
        source = item['provenance']
        with np.load(checked(source['input_arrays']),allow_pickle=False) as data:
            raw = unpack(torch.from_numpy(data['packed']))[0,0]
            colors = data['colors'][0]
            wb, matrix = torch.from_numpy(data['wb']),torch.from_numpy(data['matrix'])
        x,y,w,h = source['ROI_xywh']
        exposure = source['display_exposure']
        outputs = {}
        for arm in RENDER:
            pred,_,_=restore(model,raw,colors,source['noise']['shot'],source['noise']['read'],wb,matrix,modes[arm])
            outputs[arm]=pred[:,y:y+h,x:x+w].contiguous()
        prior = board_panels(checked(item['image']),source['panels'])
        ordered = [('Noisy Malvar',prior['Noisy Malvar'])]
        ordered += [(LABELS[arm],display_sensor(image,wb,matrix,(0,0,w,h),exposure))
                    for arm,image in outputs.items()]
        ordered += [(label,prior[label]) for label in ('ISO100 ref, not GT','SOOC ISO6400 JPEG','SOOC ISO100 JPEG')]
        rows.append({'id':name,'provenance':source,'board':native_png(ROOT/f'{name}.png',ordered),
                     'delta':{arm:difference(image.numpy(),outputs['control'].numpy()) for arm,image in outputs.items()
                              if arm!='control'}})
        print(name,rows[-1]['delta'],flush=True)
    assert len(rows)==4
    return rows


def exact_cohort():
    plan = read_json(CASES)
    used = {row['id'] for line in checked(plan['training_manifest']).open() for row in (read_line(line),)}
    holdout = [row for line in checked(plan['candidate_manifest']).open() for row in (read_line(line),)
               if min(row['shape'][:2])>=1152 and row['id'] not in used and row['split']!='train']
    holdout.sort(key=lambda row:hashlib.sha256(f"fp16-throughput-20261119/{row['id']}".encode()).digest())
    selected = [next(row for row in holdout if row['id']==key)
                for key in ('5b8ca4bc4835c5f41065d0a2aa3e165be166cd26','d99935a126097f7657157c948447094caa6288f0')]
    ids = {row['id'] for row in selected}
    selected += [row for row in holdout if row['id'] not in ids][:10]
    ids = {row['id'] for row in selected}
    hashes = {row['cache_sha256'] for row in selected}
    for trace in read_json(TRAINING_AUDIT)['source_traces']:
        with checked(trace).open() as stream:
            for line in stream:
                for draw in read_line(line)['sources']:
                    if draw['kind'] != 'photographic':
                        continue
                    assert draw['source_id'] not in ids and draw['cache_sha256'] not in hashes
    return selected


def read_line(line):
    import json
    return json.loads(line)


def exact_targets(model, modes):
    conditions = ((.00256,2.62144e-5,1.), (SHOT,READ,.4), (8e-5,2.56e-8,1.),
                  (8e-5,2.56e-8,4.), (SHOT,READ,1.), (0.,0.,1.))
    rows = []
    for index, source in enumerate(exact_cohort()):
        path = reference(source['cache'])
        assert path['sha256']==source['cache_sha256']
        pixels = np.load(path['path'], mmap_mode='r',allow_pickle=False)
        y,x = ((length-1152)//4*2 for length in pixels.shape[:2])
        rgb = torch.from_numpy(pixels[y:y+1152,x:x+1152].astype(np.float32)).permute(2,0,1)/65535
        shot, read, exposure = conditions[index%len(conditions)]
        recipe = replace(sample_scene_recipe(20261119090+index),shot=shot,read=read,exposure=exposure,black=.03)
        obs = observe_scene(rgb,recipe)
        raw = unpack(obs.packed[None])[0,0]
        supervision = {k:getattr(obs,k)[None].numpy() for k in ('target','packed','colors','wb','matrix')}
        outputs = {arm:restore(model,raw,obs.colors,shot,read,obs.wb,obs.matrix,mode)[0].numpy()[None]
                   for arm,mode in modes.items()}
        scores = {}
        truth = display(supervision['target'],supervision)
        for arm,pred in outputs.items():
            error = (display(pred,supervision)-truth)**2
            bands = blend_bands(1152,modes[arm])
            bmask = bands[:,None] | bands[None,:]
            scores[arm] = {'sRGB_PSNR':float(photometry(pred,supervision)['srgb_psnr'][0]),
                           'blend_band_sRGB_MSE_here':float(error[...,bmask].mean()),
                           'control_sRGB_MSE_in_same_bands':float(((display(outputs['control'],supervision)-truth)**2)[...,bmask].mean()),
                           'rms_delta_camera_DN16':difference(pred[0],outputs['control'][0])['rms_DN16']}
        provenance = {'photo':source,'source':path,'cache_box_xywh':[x,y,1152,1152], 'recipe':asdict(recipe),
                      'ADC_bits':16,'display_exposure':min(1.,1/exposure)}
        board = None
        if index<2:
            # Compare native detail where the 512-pixel control blends tiles.
            roi = (400,400,160,160)
            board = native_board(ROOT,('pinakothek','cardoon')[index],
                [noisy_malvar(supervision)[0],*[outputs[arm][0] for arm in RENDER],supervision['target'][0]],
                supervision,provenance, labels=('Noisy Malvar',*[LABELS[arm] for arm in RENDER],'Exact GT'),
                triplet_indices=(0,2,5), exposure=provenance['display_exposure'],roi=roi)
        rows.append({'provenance':provenance,'metrics':scores,'board':board})
        print(index,source['title'],{arm:round(score['sRGB_PSNR'],5) for arm,score in scores.items()},flush=True)
    return rows


def outliers(receipt, meta):
    arms = receipt['output_differences']
    control = tifffile.memmap(checked(receipt['runs']['control'][0]['RGB16']))
    wb,matrix = torch.tensor(meta.white_balance)[None],torch.tensor(meta.camera_to_srgb)[None]
    rows = []
    for arm in ('rebatch','larger','reduced'):
        peak,(x,y,c) = arms[arm][0]['max_DN16_and_sensor_xy_channel']
        if peak==0:
            continue
        after = tifffile.memmap(checked(receipt['runs'][arm][0]['RGB16']))
        assert abs(int(after[y,x,c])-int(control[y,x,c]))==peak
        start_x = min(max(0,x-80),after.shape[1]-160)
        start_y = min(max(0,y-80),after.shape[0]-160)
        cells = []
        for label,image in [('FP16 512/64',control),(LABELS[arm],after)]:
            patch=image[start_y:start_y+160,start_x:start_x+160].astype(np.float32)
            cells.append((label,display_sensor(torch.from_numpy(patch).permute(2,0,1)/65535,wb,matrix,(0,0,160,160),1)))
        rows.append({'arm':arm,'sensor_xyc':[x,y,c],'difference_DN16':peak,'display_exposure':1,
                     'sensor_xywh':[start_x,start_y,160,160], 'board':native_png(ROOT/f'{arm}-outlier.png',cells)})
    return rows


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    total = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1,16*2**30/total))
    input_ref = reference(ROOT/'full.json')
    receipt = read_json(checked(input_ref))
    _, meta = read_raw(checked(receipt['source']))
    model, checkpoint = bound_model()
    assert checkpoint==receipt['checkpoint']
    main = main_crops(receipt,meta)
    cab = cab_crops(model,receipt['modes'])
    exact = exact_targets(model,receipt['modes'])
    peak = outliers(receipt,meta)
    write_json(ROOT/'quality.json',{'driver':reference(__file__),'full':input_ref,'checkpoint':checkpoint,
      'exact_source_plan':reference(CASES),'training_exclusion_audit':reference(TRAINING_AUDIT),'main':main,'cab':cab,'exact':exact,'outliers':peak})


if __name__ == '__main__':
    main()
