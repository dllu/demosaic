"""Measure tile throughput without changing precision or trained weights."""
from itertools import cycle
from pathlib import Path
from statistics import median
import sys
import time

import numpy as np
import torch

from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.inference import load_checkpoint, positions
from demosaic.io import read_raw
from demosaic.precision import amp_context

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name('corpus100k-mixed-precision-v1')))
from full_production import gpu_jobs
from screen import PRIMARY, MODEL, SHOT, READ, versions

TUNABLE = ((512, 4), (512, 8), (768, 2), (1024, 1))
SHAPES = ((384, 4), (512, 2), (512, 4), (512, 6), (512, 8), (512, 12),
          (640, 2), (640, 4), (768, 2), (768, 4), (1024, 1), (1024, 2))


def bound_model():
    expected = read_json(PRIMARY)['models'][MODEL]['checkpoint']
    model, state = load_checkpoint(expected['path'], 'cuda', tiled_inference=True)
    assert state['step'] == 100000 and state['loaded_sha256'] == expected['sha256'] and 'ema' in state
    return model.eval(), expected


def settings(tune):
    torch.backends.cudnn.benchmark = tune
    torch.backends.cudnn.benchmark_limit = 5


def prepare(raw, meta, cfg, tile, batch):
    # Tile locations cover all four standing conditions and preserve Bayer phase.
    crops = [raw[y - tile//2 + 80:y + tile//2 + 80, x - tile//2 + 80:x + tile//2 + 80]
             for x,y in (entry['noisy_xy'] for entry in cfg['regions'])]
    raw_tiles = np.stack([crop for _, crop in zip(range(batch), cycle(crops))])
    tiles = pack(torch.from_numpy(raw_tiles[:, None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors = torch.as_tensor(color_indices(meta.pattern),device='cuda')[None].expand(batch,-1)
    wb = torch.as_tensor(meta.white_balance,dtype=torch.float32,device='cuda')[None].expand(batch,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb,dtype=torch.float32,device='cuda')[None].expand(batch,-1,-1)
    return tiles, tiles.clamp_min(0)*SHOT+READ, colors, wb, matrix


def invoke(model, args, tune, keep_cache, num):
    settings(tune)
    torch.cuda.synchronize()
    begin = time.perf_counter()
    with amp_context('cuda', keep_cache, dtype='float16'):
        for _ in range(num):
            with amp_context('cuda', dtype='float16'):
                output = model(*args)
    torch.cuda.synchronize()
    return (time.perf_counter()-begin)/num, output


def differences(x, y):
    dn = (x.double()-y)*65535
    return {'rms_DN16': float(dn.square().mean().sqrt()), 'max_DN16': float(dn.abs().max()),
            'identical': bool(torch.equal(x,y))}


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    total = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1, 16*2**30/total))
    fixture = read_json('configs/gfx-qualitative-20231231.json')
    source = reference(fixture['noisy'])
    raw, meta = read_raw(source['path'])
    model, checkpoint = bound_model()
    model.set_noise(SHOT,READ)
    args = {key:prepare(raw,meta,fixture,*key) for key in SHAPES}
    baseline = {}
    records = {}
    gpu_before = gpu_jobs()
    for key, value in args.items():
        settings(False)
        warm, output = invoke(model, value, False, False, 1)
        baseline[key] = output[:1].clone()
        records[(key,False,False)] = {'warm_seconds': warm, 'trials':[]}
        print('warm',key,warm,flush=True)
    for key in SHAPES:
        records[(key,False,True)] = {'trials':[]}
    for key in TUNABLE:
        for keep in (False,True):
            warm, output = invoke(model,args[key],True,keep,1)
            records[(key,True,keep)] = {'warm_seconds':warm,'trials':[]}
            print('tune',key,keep,warm,flush=True)
    items = list(records)
    for turn in range(4):
        order = items[turn*5:]+items[:turn*5]
        if turn % 2:
            order = order[::-1]
        for key,tune,keep in order:
            torch.cuda.reset_peak_memory_stats()
            seconds, output = invoke(model,args[key],tune,keep,3)
            row = records[(key,tune,keep)]
            row['trials'].append(seconds)
            row['peak_cuda_gb'] = torch.cuda.max_memory_allocated()/1e9
            if 'differences' not in row:
                row['differences'] = differences(output[:1],baseline[key])
    results = []
    for ((tile,batch),tune,keep),row in records.items():
        seconds = median(row['trials'])
        overlaps = {}
        for overlap in (32,64,96):
            stride = tile-overlap
            count = len(positions(raw.shape[0],tile,stride))*len(positions(raw.shape[1],tile,stride))
            overlaps[overlap] = {'tile_count':count,'resident_estimate_seconds':count/batch*seconds}
        row.update(tile=tile,batch=batch,tune=tune,keep_cache=keep,median_seconds=seconds,overlaps=overlaps)
        results.append(row)
        print(tile,batch,tune,keep,round(seconds,4),{o:round(v['resident_estimate_seconds'],2) for o,v in overlaps.items()},
              row['differences'],flush=True)
    settings(False)
    write_json(ROOT/'screen.json',{'driver':reference(__file__),'checkpoint':checkpoint,'source':source,
                                    'noise':{'shot':SHOT,'read':READ},'gpu_before':gpu_before,'gpu_after':gpu_jobs(),
                                    'versions':versions(),'results':results,'benchmark_limit':5})


if __name__ == '__main__':
    main()
