"""Measure complete DINO compilation on the same fixed grid and native panels."""
from contextlib import contextmanager
from pathlib import Path
from statistics import median
import sys
import time

import numpy as np
import torch

from dino_engine import DinoEngine, ROOT, selected_dino
import full_quality as quality
from full_quality import Engine, PREVIOUS, SHOT, READ, checked, gpu_jobs, read_json, reference, selected, trt, versions, write_json
from demosaic.precision import amp_context

PRIOR_TACTICS = quality.ROOT
EXECUTION = ROOT / 'dino-t512-l3.json'


def build_refs(level):
    assert level == 3
    previous = read_json(PREVIOUS / 'trt-review.json')
    return {'dynamic': previous['engines']['trt-fp16']['engine'], 'dino': read_json(EXECUTION)['plan']}


def engine_set(refs):
    trunk = Engine(checked(refs['dynamic']))
    dino = DinoEngine(checked(refs['dino']))
    return {'ieee-fp32': (None,None), 'eager': (None,None),
            'dynamic': (trunk,None), 'static': (trunk,dino)}


@contextmanager
def combined(model, engines):
    trunk, dino = engines
    with selected(model,trunk), selected_dino(model,dino):
        yield


def configure():
    quality.ROOT = ROOT
    quality.BASE32 = ROOT.with_name('corpus100k-mixed-precision-v1')
    quality.build_refs = build_refs
    quality.engine_set = engine_set
    quality.selected = combined
    quality.LABELS['dynamic'] = 'TensorRT FP16 trunk'
    quality.LABELS['static'] = 'TensorRT FP16 trunk and DINO'


@torch.inference_mode()
def screen():
    quality.prepare()
    model, checkpoint = quality.bound_model()
    refs = build_refs(3)
    engines = engine_set(refs)
    assert read_json(EXECUTION)['checkpoint'] == checkpoint
    fixture = read_json(quality.FIXTURE)
    source = reference(fixture['noisy'])
    raw, meta = quality.read_raw(source['path'])
    from demosaic.cfa import pack
    origins = [(r['noisy_xy'][0]-176,r['noisy_xy'][1]-176) for r in fixture['regions']]
    raw_tiles = np.stack([raw[y:y+512,x:x+512] for x,y in origins])
    del raw
    sensor = pack(torch.from_numpy(raw_tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    wb = torch.as_tensor(meta.white_balance,dtype=torch.float32,device='cuda')[None].expand(4,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb,dtype=torch.float32,device='cuda')[None].expand(4,-1,-1)
    colors = torch.as_tensor(quality.color_indices(meta.pattern),device='cuda')[None].expand(4,-1)
    args = sensor,sensor.clamp_min(0)*SHOT+READ,colors,wb,matrix
    model.set_noise(SHOT,READ)
    torch.cuda.synchronize()
    stream = torch.cuda.Stream()
    before = gpu_jobs()
    rows = []
    outputs = {}
    with torch.cuda.stream(stream):
        capture = []
        hook=model.context.backbone.register_forward_pre_hook(lambda _m,_a,k: capture.append(k['pixel_values']), with_kwargs=True)
        with amp_context('cuda',dtype='float16'):
            model(*args)
        stream.synchronize()
        hook.remove()
        assert len(capture)==1
        preview=capture[0]
        dino=engines['static'][1]
        with amp_context('cuda',dtype='float16'):
            stages=model.context.backbone(pixel_values=preview, output_hidden_states=True).hidden_states[1:]
        compiled = dino(preview)
        native = []
        for a,b in zip(stages,compiled,strict=True):
            delta = b-a
            native.append({'rms_feature_units':float(delta.square().mean().sqrt()),
                           'max_abs_feature_units':float(delta.abs().amax())})

        def run(arm):
            if arm=='dino-eager':
                return model.context.backbone(pixel_values=preview, output_hidden_states=True).hidden_states[1:]
            if arm=='dino-compiled':
                return dino(preview)
            with combined(model,engines[arm]):
                return model(*args)

        arms=('eager','dynamic','static','dino-eager','dino-compiled')
        with amp_context('cuda',dtype='float32'):
            outputs['ieee-fp32']=model(*args).cpu().numpy()
        for idx in range(-3,22):
            i=idx%len(arms)
            order=arms[i:]+arms[:i]
            if idx%2:
                order=order[::-1]
            measurements={}
            for arm in order:
                start, stop = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                stream.synchronize()
                t=time.perf_counter()
                start.record(stream)
                with amp_context('cuda',dtype='float16'):
                    result=run(arm)
                stop.record(stream)
                stop.synchronize()
                measurements[arm]={'wall_seconds':time.perf_counter()-t,'cuda_seconds':start.elapsed_time(stop)/1000}
                if idx==-1 and arm in engines:
                    outputs[arm]=result.cpu().numpy()
            if idx>=0:
                rows.append(measurements)
        for n in (1,2,3):
            with amp_context('cuda',dtype='float16'), combined(model,engines['static']):
                resized = model(*(x[:n] for x in args))
            assert resized.shape == (n,3,512,512) and torch.isfinite(resized).all()
    medians={arm:{key:median(row[arm][key] for row in rows) for key in ('wall_seconds','cuda_seconds')} for arm in arms}
    metrics={f'{arm}_vs_{control}': quality.difference(
                outputs[arm].transpose(1,0,2,3).reshape(3,-1,512),
                outputs[control].transpose(1,0,2,3).reshape(3,-1,512))
             for arm,control in (('eager','ieee-fp32'),('dynamic','ieee-fp32'),('static','ieee-fp32'),('static','dynamic'))}
    write_json(ROOT/'screen.json',dict(checkpoint=checkpoint,plans=refs,raw=source,origins=origins,rows=rows,
               driver=reference(__file__),build=reference(EXECUTION),profiles=[SHOT,READ],stages=native,
               versions={**versions(),'TensorRT':trt.__version__},job_pids_before=before,job_pids_after=gpu_jobs(),
               medians=medians,output_deltas=metrics))
    print(medians,metrics, flush=True)


if __name__ == '__main__':
    action=sys.argv[1]
    configure()
    if action=='screen':
        screen()
    elif action=='full':
        quality.full(3)
    elif action=='paired':
        import interleave
        interleave.main()
    elif action=='quality':
        quality.quality(3)
    elif action=='wires':
        import wires
        wires.main()
    else:
        raise ValueError(action)
