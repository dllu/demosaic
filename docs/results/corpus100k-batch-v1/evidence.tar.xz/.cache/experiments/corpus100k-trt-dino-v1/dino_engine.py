"""Compile all four frozen DINO stages while retaining eager precision boundaries."""
from collections import Counter
from contextlib import contextmanager
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name('corpus100k-trt-tactics-v1')))
from full_quality import prepare, bound_model, gpu_jobs, reference, trt, versions, write_json
from trt_hidden import FLOAT, HALF, LOGGER, RUNTIME

STAGES = ('stage_0', 'stage_1', 'stage_2', 'stage_3')


class DinoNetwork:
    def __init__(self, backbone, tile):
        assert backbone.config.hidden_act == 'gelu' and not backbone.training
        self.tile = tile
        self.builder = trt.Builder(LOGGER)
        self.network = self.builder.create_network()
        self.constants = []
        self.source = self.network.add_input('preview', FLOAT, (-1,3,tile,tile))
        self.source.allowed_formats = 1 << int(trt.TensorFormat.HWC)
        value = self.source
        for index, stage in enumerate(backbone.stages):
            for name, layer in enumerate(stage.downsample_layers):
                layer_name = f'{index}.downsample.{name}'
                if isinstance(layer, nn.Conv2d):
                    value = self.conv(value, layer, layer_name)
                else:
                    value = self.norm(value, layer, layer_name)
            for block_index, block in enumerate(stage.layers):
                value = self.block(value, block, f'{index}.block.{block_index}')
            value.name = STAGES[index]
            self.network.mark_output(value)
            value.allowed_formats = 1 << int(trt.TensorFormat.HWC)

    def cast(self, value, dtype):
        return value if value.dtype == dtype else self.network.add_cast(value, dtype).get_output(0)

    def array(self, param, dtype):
        value = param.detach().cpu().numpy().astype(dtype, copy=True, order='C')
        self.constants.append(value)
        return value

    def channel_constant(self, param):
        value = self.array(param, np.float32).reshape(1,-1,1,1)
        return self.network.add_constant(value.shape, value).get_output(0)

    def conv(self, value, module, name):
        weight = self.array(module.weight, np.float16)
        if isinstance(module, nn.Linear):
            weight = weight[:,:,None,None]
            channels, kernel, padding, stride, groups = module.out_features, (1,1), (0,0), (1,1), 1
        else:
            channels, kernel = module.out_channels, module.kernel_size
            padding, stride, groups = module.padding, module.stride, module.groups
        bias = self.array(module.bias, np.float16)
        layer = self.network.add_convolution_nd(self.cast(value, HALF), channels, kernel, weight, bias)
        layer.name = name
        layer.padding_nd, layer.stride_nd, layer.num_groups = padding, stride, groups
        return layer.get_output(0)

    def norm(self, value, module, name):
        scale = self.channel_constant(module.weight)
        bias = self.channel_constant(module.bias)
        layer = self.network.add_normalization(self.cast(value, FLOAT), scale, bias, 1 << 1)
        layer.name = name
        layer.epsilon = module.eps
        return layer.get_output(0)

    def block(self, value, module, name):
        assert not module.drop_path.training
        x = self.conv(value, module.depthwise_conv, name+'.depthwise')
        x = self.norm(x, module.layer_norm, name+'.norm')
        x = self.conv(x, module.pointwise_conv1, name+'.expand')
        gelu = self.network.add_activation(x, trt.ActivationType.GELU_ERF)
        gelu.name = name+'.gelu'
        x = self.conv(gelu.get_output(0), module.pointwise_conv2, name+'.reduce')
        gamma = self.channel_constant(module.gamma)
        x = self.network.add_elementwise(self.cast(x, FLOAT), gamma, trt.ElementWiseOperation.PROD).get_output(0)
        return self.network.add_elementwise(self.cast(value, FLOAT), x, trt.ElementWiseOperation.SUM).get_output(0)

    def save(self, path, level):
        config = self.builder.create_builder_config()
        config.clear_flag(trt.BuilderFlag.TF32)
        config.builder_optimization_level = level
        config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 2 << 30)
        config.avg_timing_iterations = 5
        config.max_aux_streams = 0
        profile = self.builder.create_optimization_profile()
        c, h, w = 3, self.tile, self.tile
        profile.set_shape('preview', (1,c,h,w), (4,c,h,w), (4,c,h,w))
        config.add_optimization_profile(profile)
        start = time.perf_counter()
        blob = self.builder.build_serialized_network(self.network, config)
        if blob is None:
            raise RuntimeError(f'Could not build {path}')
        path.write_bytes(bytes(blob))
        return time.perf_counter()-start


class DinoEngine:
    """Single-current-stream prototype, with eager fallback for other shapes."""
    def __init__(self, path, tile=512):
        self.tile = tile
        self.engine = RUNTIME.deserialize_cuda_engine(path.read_bytes())
        assert self.engine is not None
        self.context = self.engine.create_execution_context()
        assert self.context is not None
        self.outputs = None

    def __call__(self, preview):
        stream = torch.cuda.current_stream()
        context = self.context
        assert context.set_input_shape('preview', tuple(preview.shape))
        bound = preview.contiguous(memory_format=torch.channels_last)
        assert bound.stride() == tuple(context.get_tensor_strides('preview'))
        assert context.set_tensor_address('preview', bound.data_ptr())
        if self.outputs is None or self.outputs[0].shape[0] != len(preview):
            self.outputs = tuple(
                torch.empty_strided(tuple(context.get_tensor_shape(name)),
                    tuple(context.get_tensor_strides(name)), dtype=torch.float32, device=preview.device)
                for name in STAGES
            )
        for name, value in zip(STAGES, self.outputs, strict=True):
            assert context.set_tensor_address(name, value.data_ptr())
        assert context.execute_async_v3(stream.cuda_stream)
        return self.outputs


@contextmanager
def selected_dino(model, engine):
    if engine is None:
        yield
        return
    backbone = model.context.backbone
    forward = backbone.forward

    def features(pixel_values, *, output_hidden_states=None):
        if output_hidden_states and 1 <= len(pixel_values) <= 4 and pixel_values.shape[-2:] == (engine.tile,engine.tile):
            return SimpleNamespace(hidden_states=(pixel_values, *engine(pixel_values)))
        return forward(pixel_values, output_hidden_states=output_hidden_states)

    backbone.forward = features
    try:
        yield
    finally:
        backbone.forward = forward


@torch.inference_mode()
def build(tile, level):
    prepare()
    model, checkpoint = bound_model()
    path = ROOT / f'dino-t{tile}-l{level}.plan'
    jobs = gpu_jobs()
    print('building', path.name, flush=True)
    net = DinoNetwork(model.context.backbone, tile)
    seconds = net.save(path, level)
    engine = DinoEngine(path, tile)
    layers = path.with_suffix('.layers.json')
    inspection = json.loads(engine.engine.create_engine_inspector().get_engine_information(trt.LayerInformationFormat.JSON))
    write_json(layers, inspection)
    record = dict(driver=reference(__file__), checkpoint=checkpoint, dino_revision=model.config.dino_revision,
                  job_pids_before=jobs, job_pids_after=gpu_jobs(), build_seconds=seconds, tile=tile,
                  level=level, plan=reference(path), inspection=reference(layers),
                  layer_types=dict(Counter(l.get('LayerType','unknown') for l in inspection['Layers'])),
                  backend={**versions(),'TensorRT':trt.__version__})
    write_json(path.with_suffix('.json'), record)
    print(seconds, record['layer_types'], flush=True)


if __name__ == '__main__':
    build(*map(int, sys.argv[1:]))
