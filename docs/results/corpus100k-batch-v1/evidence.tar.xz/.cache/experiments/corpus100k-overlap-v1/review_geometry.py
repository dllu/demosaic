"""Audit shape, seams, and both standing camera families on identical native ROIs."""

from dataclasses import replace
from pathlib import Path

import numpy as np
import tifffile
import torch
from benchmark import (
    ARMS,
    BATCH,
    DINO,
    ROOT,
    TILE,
    batches,
    build_refs,
    combined,
    engine_set,
    prior,
)
from scipy.ndimage import maximum_filter

from demosaic.archive_metrics import linear_rgb
from demosaic.cfa import pack
from demosaic.inference import restore_tiled
from demosaic.precision import amp_context

LABELS = {
    "ieee": "IEEE FP32 / 64",
    "eager64": "Eager FP16 / 64",
    "compiled64": "TensorRT FP16 / 64",
    "compiled48": "TensorRT FP16 / 48",
    "compiled32": "TensorRT FP16 / 32",
}
PROFILE = {"shot": prior.SHOT, "read": prior.READ}
CAB_FIXTURE = Path("configs/gfx-green-mesh-20231231.json")


def native_delta(a, b):
    return prior.difference(np.asarray(a), np.asarray(b))


def restore(model, engines, profiles, raw, colors, wb, matrix, name):
    backend, overlap = ARMS[name] if name != "ieee" else ("eager", 64)
    with combined(model, engines[backend]):
        rgb, _ = restore_tiled(
            model,
            raw,
            colors,
            wb=wb,
            matrix=matrix,
            **profiles,
            tile=TILE,
            overlap=overlap,
            batch_size=BATCH,
            device="cuda",
            precision="float32" if name == "ieee" else "float16",
        )
    return rgb


def compare_main(result):
    prior_review = prior.read_json(DINO / "quality.json")
    controls = {row["id"]: row for row in prior_review["main"]}
    fixture = prior.read_json(prior.FIXTURE)
    raw, meta = prior.read_raw(prior.checked(result["source"]))
    wb = torch.tensor(meta.white_balance)[None]
    mat = torch.tensor(meta.camera_to_srgb)[None]
    panels_ref = {key: prior.checked(item["crops"]) for key, item in result["outputs"].items()}
    panels_ref["ieee"] = prior.checked(
        prior.read_json(prior.BASE32 / "first-fp32.json")["native_float_RGB"]
    )
    rows = []
    for region in fixture["regions"]:
        name = region["name"]
        exposure = 4
        previous = controls[name]["board"]
        pixels = prior.board_panels(prior.checked(previous["image"]), previous["panels"])
        outputs = {}
        for key, ref in panels_ref.items():
            with np.load(ref, allow_pickle=False) as file:
                outputs[key] = file[name]
        panels = [(k, v) for k, v in pixels.items() if "Noisy" in k]
        panels += [
            (
                LABELS[key],
                prior.display_sensor(
                    torch.from_numpy(outputs[key]), wb, mat, (0, 0, 160, 160), exposure
                ),
            )
            for key in LABELS
        ]
        panels += [(k, v) for k, v in pixels.items() if "ISO100" in k]
        rows.append(
            {
                "id": name,
                "roi": [*region["noisy_xy"], 160, 160],
                "exposure": exposure,
                "reference": previous["image"],
                "deltas": {key: native_delta(outputs[key], outputs["compiled64"]) for key in ARMS},
                "board": prior.native_png(ROOT / f"{name}.png", panels),
            }
        )

    files = {name: prior.checked(row["tiff"]) for name, row in result["outputs"].items()}
    files["ieee"] = prior.checked(prior.read_json(DINO / "full.json")["FP32_anchor"])
    images = {name: tifffile.memmap(path) for name, path in files.items()}
    assert meta.flip == 0
    full_deltas = {}
    for name, control in (
        ("compiled64", "ieee"),
        ("compiled48", "compiled64"),
        ("compiled32", "compiled64"),
    ):
        mode = {"tile": TILE, "overlap": ARMS[name][1]}
        stats = prior.exported_differences(files[control], files[name], mode)
        magnitude, (x, y, c) = stats["max_DN16_and_sensor_xy_channel"]
        assert abs(int(images[name][y, x, c]) - int(images[control][y, x, c])) == magnitude
        h, w, _ = images[name].shape
        x0, y0 = min(max(0, x - 80), w - 160), min(max(0, y - 80), h - 160)
        panels = []
        for key, label in LABELS.items():
            cut = images[key][y0 : y0 + 160, x0 : x0 + 160].astype(np.float32)
            rgb = torch.from_numpy(cut).permute(2, 0, 1) / 65535
            panels.append((label, prior.display_sensor(rgb, wb, mat, (0, 0, 160, 160), 1)))
        stats.update(
            roi=[x0, y0, 160, 160],
            display_exposure=1,
            near_observed_clipping=clip_strata(raw, images[name], images[control]),
            board=prior.native_png(ROOT / f"{name}-vs-{control}-outlier.png", panels),
        )
        full_deltas[f"{name}_vs_{control}"] = stats
    return rows, full_deltas


def clip_strata(raw, candidate, control):
    """Split exported RGB errors by distance to a near-white Bayer measurement."""
    stats = {
        k: {"pixel_count": 0, "channel_square_sum": 0.0, "max_DN16": 0}
        for k in ("within_6_px", "elsewhere")
    }
    h = raw.shape[0]
    for y in range(0, h, 64):
        stop = min(y + 64, h)
        start_with_margin = max(0, y - 6)
        mask = maximum_filter(raw[start_with_margin : min(stop + 6, h)] >= 0.9995, size=13)
        mask = mask[y - start_with_margin : stop - start_with_margin]
        delta = np.abs(candidate[y:stop].astype(np.int32) - control[y:stop])
        for name, select in (("within_6_px", mask), ("elsewhere", ~mask)):
            codes = delta[select]
            stats[name]["pixel_count"] += len(codes)
            stats[name]["channel_square_sum"] += np.square(codes.astype(np.float64)).sum()
            stats[name]["max_DN16"] = max(stats[name]["max_DN16"], int(codes.max(initial=0)))
    for row in stats.values():
        ss = row.pop("channel_square_sum")
        row["RMS_DN16"] = (
            float(np.sqrt(ss / (3 * row["pixel_count"]))) if row["pixel_count"] else None
        )
    return stats


def tile_intersection(x, y, roi):
    rx, ry, rw, rh = roi
    l, t, r, b = max(x, rx), max(y, ry), min(x + TILE, rx + rw), min(y + TILE, ry + rh)
    if l >= r or t >= b:
        return None
    return (np.s_[t - y : b - y, l - x : r - x], np.s_[t - ry : b - ry, l - rx : r - rx])


def sparse_restore(model, engines, profiles, raw, meta, rois, name):
    """Run original full-frame batches intersecting a requested native ROI."""
    assert all(n % 2 == 0 and n >= TILE for n in raw.shape)
    raw = torch.from_numpy(raw)
    backend, overlap = ARMS[name] if name != "ieee" else ("eager", 64)
    precision = "float32" if name == "ieee" else "float16"
    edge = torch.hann_window(TILE, periodic=False).clamp_min(0.02)
    weight = edge[:, None] * edge[None, :]
    accum = [torch.zeros(3, h, w, dtype=torch.float32) for _, _, w, h in rois]
    norm = [torch.zeros(h, w, dtype=torch.float32) for _, _, w, h in rois]
    model.set_noise(profiles["shot"], profiles["read"])
    colors = torch.as_tensor(prior.color_indices(meta.pattern), device="cuda")[None]
    wb = torch.as_tensor(meta.white_balance, dtype=torch.float32, device="cuda")[None]
    mat = torch.as_tensor(meta.camera_to_srgb, dtype=torch.float32, device="cuda")[None]
    used = []
    with combined(model, engines[backend]):
        for index, current in enumerate(batches(raw.shape, overlap)):
            intersections = [[tile_intersection(x, y, r) for r in rois] for y, x in current]
            if not any(hit is not None for tiles in intersections for hit in tiles):
                continue
            used.append({"batch": index, "origins_yx": current})
            tiles = pack(
                torch.stack([raw[y : y + TILE, x : x + TILE] for y, x in current])[:, None].cuda()
            )
            tiles = tiles.contiguous(memory_format=torch.channels_last)
            variance = tiles.clamp_min(0) * profiles["shot"] + profiles["read"]
            n = len(current)
            with amp_context("cuda", dtype=precision):
                outputs = model(
                    tiles, variance, colors.expand(n, -1), wb.expand(n, -1), mat.expand(n, -1, -1)
                )
            for output, hits in zip(outputs.float().cpu(), intersections, strict=True):
                for dst, nrm, hit in zip(accum, norm, hits, strict=True):
                    if hit is not None:
                        src, target = hit
                        dst[:, *target].add_(output[:, *src] * weight[src])
                        nrm[target].add_(weight[src])
    assert all(torch.all(n > 0) for n in norm)
    return [value.div_(n.clamp_min_(1e-12)) for value, n in zip(accum, norm, strict=True)], used


def verify_sparse(model, engines, result):
    fixtures = prior.read_json(prior.FIXTURE)
    raw, meta = prior.read_raw(prior.checked(result["source"]))
    rois = [(*region["noisy_xy"], 160, 160) for region in fixtures["regions"]]
    rows = {}
    for arm in ("compiled64", "compiled32"):
        a, used = sparse_restore(model, engines, PROFILE, raw, meta, rois, arm)
        ref = result["outputs"][arm]["crops"]
        with np.load(prior.checked(ref), allow_pickle=False) as data:
            for array, region in zip(a, fixtures["regions"], strict=True):
                np.testing.assert_array_equal(array.numpy(), data[region["name"]])
        rows[arm] = {"crops": ref, "batches": used, "all_float32_values_identical": True}
    print("sparse full-grid replay matches 8 saved main crops exactly", flush=True)
    return rows


def compare_cab(model, engines):
    cfg = prior.read_json(CAB_FIXTURE)
    source = cfg["sources"]["noisy"]
    raw, meta = prior.read_raw(prior.checked(source))
    cases = [
        item
        for item in prior.read_json(prior.CAB)["images"]
        if item["role"] == "board" and item["id"].startswith("mesh-")
    ]
    wb, mat = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    rx, ry, rw, rh = cfg["raw_context_xywh"]
    assert len(cases) == 4
    rows = []
    for ob in ("mesh-nominal", "mesh-profile3879"):
        pair = [case for case in cases if case["provenance"]["observation_id"] == ob]
        p = pair[0]["provenance"]
        with np.load(prior.checked(p["input_arrays"]), allow_pickle=False) as data:
            np.testing.assert_array_equal(
                raw[ry : ry + rh, rx : rx + rw],
                prior.unpack(torch.from_numpy(data["packed"]))[0, 0].numpy(),
            )
            np.testing.assert_array_equal(wb.numpy(), data["wb"])
            np.testing.assert_array_equal(mat.numpy(), data["matrix"])
            frozen_previews = {
                label: torch.from_numpy(data[key][0])
                for label, key in (
                    ("Noisy Malvar", "noisy_rgb"),
                    ("ISO100 ref, not GT", "reference_rgb"),
                )
            }
        rois = [case["provenance"]["case"]["noisy_raw_xywh"] for case in pair]
        assert rois == [region["noisy_raw_xywh"] for region in cfg["regions"]]
        profiles = {key: p["noise"][key] for key in PROFILE}
        outputs, used = {}, {}
        for key in LABELS:
            outputs[key], used[key] = sparse_restore(model, engines, profiles, raw, meta, rois, key)
        for i, item in enumerate(pair):
            name, p = item["id"], item["provenance"]
            _, _, w, h = rois[i]
            exposure = p["display_exposure"]
            pixels = prior.board_panels(prior.checked(item["image"]), p["panels"])
            panels = [("Noisy Malvar", pixels["Noisy Malvar"])]
            panels += [
                (LABELS[key], prior.display_sensor(values[i], wb, mat, (0, 0, w, h), exposure))
                for key, values in outputs.items()
            ]
            panels += [
                (label, pixels[label])
                for label in ("ISO100 ref, not GT", "SOOC ISO6400 JPEG", "SOOC ISO100 JPEG")
            ]
            configured_exposure = cfg["display_exposure"]
            configured = [
                (
                    label,
                    prior.display_sensor(
                        frozen_previews[label], wb, mat, p["ROI_xywh"], configured_exposure
                    ),
                )
                for label in ("Noisy Malvar",)
            ]
            configured += [
                (
                    LABELS[key],
                    prior.display_sensor(values[i], wb, mat, (0, 0, w, h), configured_exposure),
                )
                for key, values in outputs.items()
            ]
            label = "ISO100 ref, not GT"
            configured.append(
                (
                    label,
                    prior.display_sensor(
                        frozen_previews[label], wb, mat, p["ROI_xywh"], configured_exposure
                    ),
                )
            )
            configured.extend(
                (label, pixels[label]) for label in ("SOOC ISO6400 JPEG", "SOOC ISO100 JPEG")
            )
            rows.append(
                {
                    "id": name,
                    "provenance": p,
                    "exposure": exposure,
                    "global_ROI_xywh": rois[i],
                    "raw_source": source,
                    "contributing_batches": used,
                    "exposure_in_stops": float(np.log2(exposure)),
                    "configured_exposure": configured_exposure,
                    "deltas": {
                        key: native_delta(outputs[key][i], outputs["compiled64"][i])
                        for key in LABELS
                    },
                    "board": prior.native_png(ROOT / f"{name}.png", panels),
                    "configured_board": prior.native_png(ROOT / f"{name}-display4.png", configured),
                }
            )
            print("cab", name, rows[-1]["deltas"]["compiled32"], flush=True)
    return rows


def seam_mask(shape, overlap):
    from full_throughput import blend_bands

    h, w = shape
    mode = {"tile": TILE, "overlap": overlap}
    return blend_bands(h, mode)[:, None] | blend_bands(w, mode)[None, :]


def compare_exact(model, engines, checkpoint):
    rows = []
    for i, case in enumerate(prior.read_json(prior.EXACT)["rows"]):
        p = case["provenance"]
        x, y, w, h = p["cache_box_xywh"]
        src = np.load(prior.checked(p["source"]), mmap_mode="r", allow_pickle=False)
        crop = (
            torch.from_numpy(src[y : y + h, x : x + w].astype(np.float32)).permute(2, 0, 1) / 65535
        )
        recipe = replace(prior.sample_scene_recipe(0), **p["recipe"])
        obs = prior.observe_scene(crop, recipe)
        raw = prior.unpack(obs.packed[None])[0, 0]
        sup = {
            key: getattr(obs, key)[None].numpy()
            for key in ("target", "packed", "colors", "wb", "matrix")
        }
        profiles = {"shot": recipe.shot, "read": recipe.read}
        output = {
            key: restore(model, engines, profiles, raw, obs.colors, obs.wb, obs.matrix, key)[
                None
            ].numpy()
            for key in LABELS
        }
        mask = seam_mask((h, w), 32)
        score = {}
        render = np.clip(linear_rgb(sup["target"], sup), 0, 1)
        for key, v in output.items():
            error = (np.clip(linear_rgb(v, sup), 0, 1) - render) ** 2
            score[key] = {
                "srgb_psnr": float(prior.photometry(v, sup)["srgb_psnr"][0]),
                "linear_RGB_seam_RMSE_DN16": float(error[..., mask].mean() ** 0.5 * 65535),
                "linear_RGB_interior_RMSE_DN16": float(error[..., ~mask].mean() ** 0.5 * 65535),
                "delta_compiled64": native_delta(v[0], output["compiled64"][0]),
            }
        roi = (680, 480, 160, 160) if w == 1536 else (480, 680, 160, 160)
        row = {
            "provenance": p,
            "roi": roi,
            "scores": score,
            "tile_count": {
                key: sum(map(len, batches((h, w), overlap))) for key, (_, overlap) in ARMS.items()
            },
        }
        if i < 2:
            row["id"] = ("pinakothek", "highlight")[i]
            row["boards"] = prior.native_board(
                ROOT,
                row["id"],
                [prior.noisy_malvar(sup)[0], *(output[key][0] for key in LABELS), sup["target"][0]],
                sup,
                {**p, "checkpoint": checkpoint, "native_roi": roi},
                labels=("Noisy Malvar", *LABELS.values(), "Exact GT"),
                triplet_indices=(0, 5, 6),
                exposure=p["display_exposure"],
                roi=roi,
            )
        rows.append(row)
        print(
            "exact",
            i,
            {name: round(values["srgb_psnr"], 6) for name, values in score.items()},
            flush=True,
        )
    return rows


@torch.inference_mode()
def main():
    prior.prepare()
    result = prior.read_json(ROOT / "benchmark.json")
    main_rows, full = compare_main(result)
    prior.write_json(
        ROOT / "full-review.json",
        {
            "benchmark": prior.reference(ROOT / "benchmark.json"),
            "driver": prior.reference(__file__),
            "checkpoint": result["checkpoint"],
            "main": main_rows,
            "full": full,
        },
    )
    model, checkpoint = prior.bound_model()
    plans = build_refs(3)
    assert checkpoint == result["checkpoint"] and plans == result["plans"]
    engines = engine_set(plans)
    with torch.cuda.stream(torch.cuda.Stream()):
        calibration = verify_sparse(model, engines, result)
        cab = compare_cab(model, engines)
        exact = compare_exact(model, engines, checkpoint)
    prior.write_json(
        ROOT / "quality.json",
        {
            "driver": prior.reference(__file__),
            "checkpoint": checkpoint,
            "plans": plans,
            "sparse_replay_check": calibration,
            "inputs": {
                "main": prior.reference(prior.FIXTURE),
                "cab_config": prior.reference(CAB_FIXTURE),
                "cab": prior.reference(prior.CAB),
                "exact": prior.reference(prior.EXACT),
            },
            "cab": cab,
            "exact": exact,
        },
    )


if __name__ == "__main__":
    main()
