"""Time reduced overlap on the fixed 512-pixel Corpus 100k inference path."""
from fractions import Fraction
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
EXTERNAL = Path("/mnt/external/demosaic/corpus100k-overlap-v1")
DINO = ROOT.with_name("corpus100k-trt-dino-v1")
TACTICS = ROOT.with_name("corpus100k-trt-tactics-v1")
sys.path.extend([str(DINO), str(TACTICS)])

from dino_review import build_refs, combined, engine_set
import full_quality as prior
from demosaic.cfa import pack
from demosaic.inference import positions
from demosaic.precision import amp_context

ARMS = {"eager64": ("eager", 64), "compiled64": ("static", 64),
        "compiled48": ("static", 48), "compiled32": ("static", 32)}
TILE, BATCH = 512, 4


def batches(shape, overlap):
    y, x = (positions(n, TILE, TILE-overlap) for n in shape)
    grid = [(yy, xx) for yy in y for xx in x]
    return [grid[i:i+BATCH] for i in range(0, len(grid), BATCH)]


def execution_order(grids):
    # Match traversal of the frame and alternate ties across different engines.
    keyed = []
    for rank, (name, groups) in enumerate(grids.items()):
        for index in range(len(groups)):
            keyed.append((Fraction(index, len(groups)), rank if index % 2 else -rank, name, index))
    return [(name, index) for _, _, name, index in sorted(keyed)]


def capture_stats(rows):
    blocks = 26
    rng = np.random.default_rng(20261119)
    draws = rng.integers(0, blocks, (4000, blocks))
    totals = {}
    resamples = {}
    for metric in ("forward_transfer", "blend", "tile_loop"):
        totals[metric] = {}
        resamples[metric] = {}
        for name, records in rows.items():
            data = [row[metric] for row in records]
            totals[metric][name] = sum(data)
            block_sums = np.array([x.sum() for x in np.array_split(data, blocks)])
            resamples[metric][name] = block_sums[draws].sum(axis=1)
    total_time = totals["tile_loop"]
    changes = {}
    for name, candidates in resamples["tile_loop"].items():
        if name == "compiled64":
            continue
        control = "compiled64" if name != "eager64" else "eager64"
        arm = name if name != "eager64" else "compiled64"
        if name == "eager64":
            candidates = resamples["tile_loop"][arm]
        baseline = resamples["tile_loop"][control]
        changes[f"{arm}_vs_{control}"] = {
            "percent": 100 * (total_time[arm]/total_time[control]-1),
            "block_bootstrap_95": (100*np.quantile(candidates/baseline-1, [.025, .975])).tolist(),
        }
    return {"seconds": totals, "tile_loop_changes": changes}


@torch.inference_mode()
def main():
    prior.prepare()
    prior_full = prior.read_json(DINO / "full.json")
    before = time.perf_counter()
    raw, meta = prior.read_raw(prior.checked(prior_full["source"]))
    decode_seconds = time.perf_counter()-before
    raw = torch.from_numpy(raw)
    assert raw.numel() == 101995852 and all(length % 2 == 0 for length in raw.shape)
    before = time.perf_counter()
    model, checkpoint = prior.bound_model()
    checkpoint_seconds = time.perf_counter()-before
    plans = build_refs(3)
    assert checkpoint == prior_full["checkpoint"] and plans == prior_full["plans"]
    before = time.perf_counter()
    engines = engine_set(plans)
    engine_seconds = time.perf_counter()-before
    model.set_noise(prior.SHOT, prior.READ)
    grids = {name: batches(raw.shape, overlap) for name, (_, overlap) in ARMS.items()}
    assert sum(map(len, grids["compiled64"])) == 520
    print({name: sum(map(len, group)) for name, group in grids.items()}, flush=True)

    h,w = raw.shape
    edge = torch.hann_window(TILE, periodic=False).clamp_min(0.02)
    weight = edge[:, None] * edge[None, :]
    accum = {name: torch.zeros(3, h, w, dtype=torch.float32) for name in ARMS}
    norm = {name: torch.zeros(h, w, dtype=torch.float32) for name in ARMS}
    colors = torch.as_tensor(prior.color_indices(meta.pattern), device="cuda")[None]
    wb = torch.as_tensor(meta.white_balance, dtype=torch.float32, device="cuda")[None]
    matrix = torch.as_tensor(meta.camera_to_srgb, dtype=torch.float32, device="cuda")[None]
    torch.cuda.synchronize()

    def call(backend, current):
        tiles = pack(torch.stack([raw[y:y+TILE, x:x+TILE] for y,x in current])[:, None].cuda())
        tiles = tiles.contiguous(memory_format=torch.channels_last)
        variance = tiles.clamp_min(0)*prior.SHOT + prior.READ
        n = len(current)
        with combined(model, engines[backend]), amp_context("cuda", dtype="float16"):
            out = model(tiles, variance, colors.expand(n,-1), wb.expand(n,-1), matrix.expand(n,-1,-1))
        return out.float().cpu()

    rows = {name: [] for name in ARMS}
    schedule = execution_order(grids)
    jobs_before = prior.gpu_jobs()
    with torch.cuda.stream(torch.cuda.Stream()):
        for name in ARMS:
            backend, _ = ARMS[name]
            for group in (grids[name][0], grids[name][-1]):
                call(backend, group)
        for serial, (name, index) in enumerate(schedule):
            backend, _ = ARMS[name]
            current = grids[name][index]
            start = time.perf_counter()
            result = call(backend, current)
            copied = time.perf_counter()
            for tile_rgb, (y,x) in zip(result, current, strict=True):
                accum[name][:, y:y+TILE, x:x+TILE].add_(tile_rgb*weight)
                norm[name][y:y+TILE, x:x+TILE].add_(weight)
            complete = time.perf_counter()
            rows[name].append(dict(ordinal=serial, batch=index, xy=current, forward_transfer=copied-start,
                                   blend=complete-copied, tile_loop=complete-start))
            if serial % 80 == 79:
                print("timing", serial+1, "of", len(schedule), flush=True)

    fixture = prior.read_json(prior.FIXTURE)
    outputs = {}
    for name, (_, overlap) in ARMS.items():
        start = time.perf_counter()
        rgb = accum.pop(name).div_(norm.pop(name).clamp_min_(1e-12))
        normalize_seconds = time.perf_counter()-start
        tiff = EXTERNAL / f"{name}.tiff"
        start = time.perf_counter()
        prior.write_rgb16(tiff, rgb.permute(1,2,0).numpy(), metadata=meta, flip=meta.flip)
        export_seconds = time.perf_counter()-start
        crop_path = EXTERNAL / f"{name}-native.npz"
        np.savez_compressed(crop_path, **{
            r["name"]: rgb[:, y:y+160, x:x+160].numpy()
            for r in fixture["regions"] for x, y in (r["noisy_xy"],)
        })
        outputs[name] = dict(tiles=sum(map(len,grids[name])), overlap=overlap, normalize_seconds=normalize_seconds,
                             export_seconds=export_seconds, tiff=prior.reference(tiff), crops=prior.reference(crop_path))
    for new, anchor in (("eager64", "eager"), ("compiled64", "static")):
        assert outputs[new]["tiff"]["sha256"] == prior_full["exports"][anchor]["sha256"], (new, anchor)
    summary = capture_stats(rows)
    prior.write_json(ROOT / "benchmark.json", dict(driver=prior.reference(__file__), checkpoint=checkpoint,
        fixture=prior.reference(prior.FIXTURE), source=prior_full["source"], plans=plans, tile=TILE, batch=BATCH,
        profiles=dict(shot=prior.SHOT, read=prior.READ), decode_seconds=decode_seconds,
        checkpoint_seconds=checkpoint_seconds, engine_seconds=engine_seconds, jobs_before=jobs_before,
        jobs_after=prior.gpu_jobs(), versions={**prior.versions(), "TensorRT": prior.trt.__version__},
        rows=rows, outputs=outputs, summary=summary))
    print(summary, flush=True)


if __name__ == "__main__":
    main()
