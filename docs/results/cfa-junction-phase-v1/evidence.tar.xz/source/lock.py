"""Lock the gap/response comparison on the earlier calibration photos."""

from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay_color import ARM, OUT, scoring

if __name__ == "__main__":
    source = reference(OUT / "replay-calibration.json")
    rows = read_json(checked(source))["rows"]
    base = scoring.score(rows, ARM[0])["means"]
    chosen = None
    candidates = {}
    for name, dose in ARM[1:]:
        full = scoring.score(rows, (name, dose))
        full_gap = full["means"][scoring.GAP]
        matched = min(1.0, base[scoring.GAP] / full_gap) if full_gap > 0 else 1.0
        equal_gap = scoring.score(rows, (name, matched))
        candidates[name] = {"full": full, "gap_dose": matched, "equal_gap": equal_gap}
        if chosen is None or equal_gap["means"][scoring.RESPONSE] > candidates[chosen]["equal_gap"]["means"][scoring.RESPONSE]:
            chosen = name
    write_json(
        OUT / "locked.json",
        {"driver": reference(Path(__file__)), "calibration": source, "method": chosen,
         "gap_dose": candidates[chosen]["gap_dose"], "alternatives": candidates,
         "policy": "Select the four-plane rule with greatest response after scaling to the same mean gap addition as green-only in calibration. Compare both full and frozen doses on fresh sources."},
    )
    print(chosen,candidates[chosen]["gap_dose"])
