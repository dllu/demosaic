"""Render green-only and measured red/blue junction support on matched native crops."""

import sys
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers

import guide_color as model
from replay_color import scoring

from review_junction import board, image

OUT = model.OUT
KEYS = ("green", "locked", "bounded", "four")
LABELS = ("Green wire check", "Bounded R/B, locked", "Bounded R/B, full", "Four-plane pool")


def sample(out, dose):
    a, b = out["anchor"], out["bounded"]
    return out | {"locked": (a + dose * (b.astype(float) - a)).astype(a.dtype)}


def verify(out, parent, local, scene, colors, roi, noise, wb, matrix, clearance):
    x, y, w, h = local
    restored = refine_raw_mesh_carriers(
        model.crop(parent, local),
        scene,
        colors,
        roi,
        shot=noise["shot"],
        read=noise["read"],
        white_balance=wb,
        camera_to_srgb=matrix,
        method="weak-junction-phase",
        parent_context=model.crop(parent, (x - 48, y - 48, w + 96, h + 96)),
        donor_clearance=clearance,
    )
    np.testing.assert_array_equal(out["green"], restored)


def standing(lock, dest):
    source = reference(model.FIXED)
    data = read_json(checked(source))
    rows = []
    for r in data["standing"]:
        with np.load(checked(r["input"]), allow_pickle=False) as file:
            raw, colors, wb, matrix = [file[k][0] for k in ("packed", "colors", "wb", "matrix")]
        parent = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(r["local_ROI"])
        predictions, trace = model.apply(
            parent, roi, raw, colors, roi, r["noise"], wb, matrix, clearance=16
        )
        verify(predictions, parent, roi, raw, colors, roi, r["noise"], wb, matrix, 16)
        predictions = sample(predictions, lock["gap_dose"])
        views = []
        for former in r["displays"]:
            with Image.open(checked(former["board"]["image"])) as original:
                p = np.asarray(original)
            old_tiles = {}
            for tile in former["board"]["panels"]:
                x, y, w, h = tile["png_xywh"]
                old_tiles[tile["name"]] = p[y : y + h, x : x + w]
            exp = former["exposure"]
            np.testing.assert_array_equal(
                image(model.crop(parent, roi), wb, matrix, exp), old_tiles["Local 50k"]
            )
            tiles = [
                (name, old_tiles[name]) for name in ("Noisy (Malvar)", "V120 EMA", "Local 50k")
            ]
            tiles += [
                (name, image(predictions[k], wb, matrix, exp))
                for name, k in zip(LABELS, KEYS, strict=True)
            ]
            tiles += [
                (n, old_tiles[n])
                for n in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if n in old_tiles
            ]
            views.append(
                board(tiles, dest / f"{r['id']}-x{exp:g}.png")
                | {"exposure": exp, "previous": former["board"]}
            )
        difference = {
            k: float(
                np.sqrt(np.mean((predictions[k].astype(float) - predictions["green"]) ** 2)) * 65535
            )
            for k in KEYS[1:]
        }
        print(r["id"], difference, flush=True)
        rows.append(
            {
                "id": r["id"],
                "input": r["input"],
                "noise": r["noise"],
                "raw": r["raw"],
                "parent": r["predictions"]["local50k"],
                "ROI_xywh": r["global_ROI"],
                "local_ROI": roi,
                "trace": trace,
                "change_DN16": difference,
                "native": views,
            }
        )
    return {"source": source, "checkpoints": data["checkpoints"], "rows": rows}


def synthetic(source, lock, dest):
    run = read_json(checked(source))
    plan = read_json(checked(run["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    roi = (x + 48, y + 48, 160, 160)
    local = (48, 48, 160, 160)
    candidates = {}
    for row in run["rows"]:
        for draw in row["draws"]:
            value = scoring.values(draw, ("bounded", 1))
            baseline = scoring.values(draw, ("green", 1))
            category = (
                "red through green break"
                if row["fixture"]["color_case"].startswith("red") and scoring.GAP in value
                else "other"
            )
            change = (
                value[scoring.GAP] - baseline[scoring.GAP]
                if category == "red through green break"
                else baseline[scoring.JUNCTION] - value[scoring.JUNCTION]
            )
            if category not in candidates or change > candidates[category][0]:
                candidates[category] = (change, row, draw)
    records = []
    for category, (value, row, draw) in candidates.items():
        with np.load(checked(draw["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        colors, wb, matrix = [data[k] for k in ("colors", "wb", "matrix")]
        scene = data["scene_packed"].copy()
        scene[cut] = data["packed"][0]
        root = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)[0]
        v120 = np.load(checked(draw["outputs"]["v120"]), allow_pickle=False)[0]
        out, trace = model.apply(root, local, scene, colors, roi, plan["noise"], wb, matrix)
        verify(out, root, local, scene, colors, roi, plan["noise"], wb, matrix, 48)
        out = sample(out, lock["gap_dose"])
        samples = {k: data[k][None] for k in ("colors", "matrix", "wb")} | {
            "packed": data["packed"][:1]
        }
        exp = 2.0
        rgb = [
            ("Noisy Malvar", model.crop(noisy_malvar(samples)[0], local)),
            ("V120 EMA", model.crop(v120, local)),
            ("Local 50k", model.crop(root, local)),
        ]
        rgb.extend((label, out[key]) for label, key in zip(LABELS, KEYS, strict=True))
        rgb.append(("Exact GT", model.crop(data["target"][0], local)))
        tiles = [(name, image(p, wb, matrix, exp)) for name, p in rgb]
        triplet = board(
            [tiles[i] for i in (0, 4, len(tiles) - 1)], dest / f"{row['id']}-triplet.png"
        )
        comparison = board(tiles, dest / f"{row['id']}-comparison.png")
        print(row["id"], category, value, flush=True)
        records.append(
            {
                "id": row["id"],
                "draw": draw["draw"],
                "input": draw["input"],
                "fixture": row["fixture"],
                "noise": plan["noise"],
                "sigma": plan["sigma"],
                "weights": plan["checkpoints"],
                "ROI": local,
                "query": plan["query"],
                "exposure": exp,
                "selection": category,
                "criterion": value,
                "trace": trace,
                "triplet": triplet,
                "board": comparison,
            }
        )
    return {"source": source, "rows": records}


if __name__ == "__main__":
    torch.set_num_threads(2)
    name = sys.argv[1]
    dest = OUT / "boards" / name
    dest.mkdir(exist_ok=True, parents=True)
    lock = reference(OUT / "locked.json")
    study = read_json(checked(lock))
    assert study["method"] == "bounded"
    res = (
        standing(study, dest)
        if name == "camera"
        else synthetic(reference(OUT / "replay-held.json"), study, dest)
    )
    write_json(
        OUT / f"board-{name}.json", {"driver": reference(Path(__file__)), "lock": lock, "data": res}
    )
