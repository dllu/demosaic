"""Audit response at the green-only gap cost on independent photographs."""

from pathlib import Path


from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay_color import OUT, scoring

B, G = ("baseline", 1), ("green", 1)


def compare(rows, path):
    return {
        "stats": scoring.score(rows, path),
        "vs_green": scoring.paired(rows, path, G),
    }


def analyze(rows, locked):
    method = locked["method"]
    base = scoring.score(rows, B)
    green = scoring.score(rows, G)
    full = scoring.score(rows, (method, 1))
    ratio = green["means"][scoring.GAP] / max(1e-30, full["means"][scoring.GAP])
    base_r, green_r, full_r = [v["means"][scoring.RESPONSE] for v in (base, green, full)]
    equal_response = (green_r - base_r) / max(1e-30, full_r - base_r)
    ratio = float(ratio)
    paths = {
        "green": G,
        "full": (method, 1),
        "calibration_dose": (method, locked["gap_dose"]),
        "at_green_gap": (method, min(1, ratio)),
        "at_green_recovery": (method, min(1, equal_response)),
    }
    return {
        "base": base,
        "methods": paths,
        "results": {name: compare(rows, path) for name, path in paths.items()},
        "matching_ratios": {"gap": ratio, "response": equal_response},
        "eligible": [
            {
                "role": i,
                "green_admission": sum(d["trace"][i]["admitted"] for r in rows for d in r["draws"]),
                "partner_admission": {
                    str(c): sum(
                        any(
                            p["admitted"] and p["color"] == c
                            for p in d["trace"][i].get("color_support", ())
                        )
                        for r in rows
                        for d in r["draws"]
                    )
                    for c in (0, 2)
                },
            }
            for i in range(7)
        ],
    }


def breakdown(rows, locked):
    values = {}
    for mode in sorted({row["fixture"]["color_case"] for row in rows}):
        chosen = [row for row in rows if row["fixture"]["color_case"] == mode]
        path = locked["method"], 1
        metrics = compare(chosen, path)
        values[mode] = {"source_count": len(chosen), **metrics}
    return values


if __name__ == "__main__":
    lock_ref = reference(OUT / "locked.json")
    locked = read_json(checked(lock_ref))
    source = reference(OUT / "replay-held.json")
    held = read_json(checked(source))
    result = analyze(held["rows"], locked)
    for name, r in result["results"].items():
        s = r["stats"]["means"]
        print(
            name,
            *(
                round(s[key], 5)
                for key in (
                    scoring.RESPONSE,
                    scoring.JUNCTION,
                    scoring.GAP,
                    scoring.ADD,
                    scoring.CONTINUOUS_ADD,
                )
            ),
            flush=True,
        )
        for key in (scoring.RESPONSE, scoring.JUNCTION, scoring.GAP):
            print(" ", key, r["vs_green"][key]["interval"], flush=True)
    groups = breakdown(held["rows"], locked)
    print(
        [
            (
                k,
                v["source_count"],
                v["vs_green"][scoring.RESPONSE]["interval"],
                v["vs_green"][scoring.GAP]["interval"],
            )
            for k, v in groups.items()
        ],
        flush=True,
    )
    write_json(
        OUT / "summary.json",
        {
            "driver": reference(Path(__file__)),
            "lock": lock_ref,
            "holdout": source,
            "full": result,
            "color_groups": groups,
        },
    )
