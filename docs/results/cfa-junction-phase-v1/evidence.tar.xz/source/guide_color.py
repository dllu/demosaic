"""Use held red and blue wire measurements when both phases match the green guide."""

from pathlib import Path
import numpy as np

from demosaic import _mesh_junction as j
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
from audit_color import HERE, OUT, PARENT, FIXED, pack, per_site, projected

ARMS = ("anchor", "green", "four", "bounded", "four_leave_uncertain", "bounded_leave_uncertain")
LABELS = {
    "anchor": "Masked internal phase",
    "green": "Green wire support",
    "four": "Held four-plane support",
    "bounded": "Bounded CFA support",
    "four_leave_uncertain": "Four-plane + sideband check",
    "bounded_leave_uncertain": "Bounded + sideband check",
}
STATIONS = j._SIDE * j._SIDE


def crop(array, roi):
    x, y, w, h = roi
    return array[..., y:y+h, x:x+w]


def _station_terms(x, y, phase, variance, raw, fold, known):
    waves = j._quadratures(known)
    here = (abs(x) < j._ROI_SIZE / 2) & (abs(y) < j._ROI_SIZE / 2) & (fold >= 2)
    ids = ((y + j._ROI_SIZE / 2) // j._CELL).astype(int) * j._SIDE + (
        (x + j._ROI_SIZE / 2) // j._CELL
    ).astype(int)
    values = np.zeros((STATIONS, 2, 2))
    for station in range(STATIONS):
        mask = here & (ids == station)
        if mask.sum() < 11:
            continue
        a, b = x[mask], y[mask]
        u, v = (a - a.mean()) / j._CELL, (b - b.mean()) / j._CELL
        nuisance = np.c_[np.ones_like(u), u, v, u**2, u*v, v**2]
        weight = 1 / np.sqrt(variance[mask])
        local = waves[mask]
        for d in (0,1):
            controls = np.c_[nuisance, local[:, 1-d]] * weight[:, None]
            signal = local[:, d, 0] * weight
            residual = signal - controls @ np.linalg.lstsq(controls, signal, rcond=1e-8)[0]
            values[station, d] = (residual @ (raw[mask] * weight), residual @ residual)
    return values


def _maps(obs, phase, packed, greens, frequencies, noise, bands, diff_idx, sign):
    known = obs.angles + phase
    clean = [
        _station_terms(obs.x[m], obs.y[m], site, obs.variance[m], obs.raw[m], obs.fold[m], known[m])
        for site in greens if (m := obs.phase == site).any()
    ]
    green = np.stack(clean, axis=-2)
    votes, powers = np.moveaxis(green, -1, 0)
    totals = votes.sum(axis=-1)
    information = powers.sum(axis=-1)
    z = totals / np.sqrt(np.maximum(1e-10, information))
    green_limit = (votes / np.sqrt(np.maximum(1e-10, powers))).min(axis=-1) + 1.5
    w0 = j._folds() == 0
    step = j._step_from_discovery(packed, w0, greens.tolist())
    inputs = []
    records = []
    for site in np.setdiff1d(np.arange(4), greens):
        s = per_site(packed[site], site, frequencies, bands, noise, step)
        x, y = obs.x[:16384] + site % 2 - greens[0] % 2, obs.y[:16384] + site // 2 - greens[0] // 2
        comps = [
            [projected(s, d, phase[d])[1,1], projected(s, d, phase[d]+np.pi/2)[1,1]]
            for d in (0,1)
        ]
        double = projected(s, diff_idx+2, phase[0]-phase[1])[1,1] * sign
        admitted = all(a >= 2 and a >= abs(b) for a, b in comps)
        records.append({"site": int(site), "admitted": admitted, "fundamental_q1": comps,
                        "sideband_q1": double})
        if admitted:
            local = _station_terms(x, y, site, s[1], s[0], obs.fold[:16384], j._wave_angles(x, y, frequencies)+phase)
            inputs.append((local, double))

    def pooled(checked):
        selected = [local for local, q in inputs if not checked or q >= 1.0]
        if not selected:
            return z
        prior = sum(v[..., 0] for v in selected)
        confidence = sum(v[..., 1] for v in selected)
        return (totals + prior) / np.sqrt(np.maximum(1e-10, information + confidence))

    def bound(proposal):
        return z + np.minimum(np.maximum(z, 0), np.maximum(proposal - z, 0))

    basic, checked = pooled(False), pooled(True)
    variants = (z, basic, bound(basic), checked, bound(checked))
    result = {}
    for label, proposal in zip(ARMS[1:], variants, strict=True):
        support = np.clip(np.minimum(proposal, green_limit).min(axis=-1) / 1.5, 0, 1)
        own = support.reshape(j._SIDE, j._SIDE).repeat(j._CELL, axis=0).repeat(j._CELL, axis=1)
        result[label] = np.minimum(j._pixel_map(support), own)
    return result, records


def apply(parent, local, scene, colors, roi, noise, wb, matrix, *, clearance=48):
    x, y, w, h = local
    section = crop(parent, local)
    anchor = refine_raw_mesh_carriers(
        section, scene, colors, roi, shot=noise["shot"], read=noise["read"],
        white_balance=wb, camera_to_srgb=matrix, method="weak-internal-phase",
        parent_context=crop(parent, (x - 16, y - 16, 192, 192)), donor_clearance=clearance,
    )
    nominated = pack(scene, colors, roi, clearance)
    if nominated is None:
        return dict.fromkeys(ARMS, anchor), {"admitted": False, "state": "no frequencies"}
    packed, relative, frequencies = nominated
    greens = np.flatnonzero(relative == 1)
    bands = j._distinct_bands(frequencies)
    obs = j._Observation.make(packed, greens, frequencies, noise["shot"], noise["read"])
    guide = j._discovery(obs, bands)
    if guide is None:
        return dict.fromkeys(ARMS, anchor), {"admitted": False, "state": "difference unavailable"}
    phase, base, harmonics, index, sign, maximum = guide
    support, records = _maps(obs, phase, packed, greens, frequencies, noise, bands, index, sign)
    baseline = j._local_wire_support(obs, obs.angles + phase)
    np.testing.assert_array_equal(support["green"], baseline)
    rgb = crop(parent, (x-48, y-48, 256, 256))[1].copy()
    rgb[j._CORE] = anchor[1]
    inherited = rgb[(obs.y+j._CENTER).astype(int), (obs.x+j._CENTER).astype(int)]
    columns = np.c_[base, harmonics.reshape(len(base), -1)]
    amplitudes = j._amplitudes(obs, columns, base.shape[1]+2*index, sign, maximum, inherited)
    angle = j._wave_angles(j._GRID_X, j._GRID_Y, frequencies) + phase
    residual = amplitudes * (sign * np.cos(angle[..., 0] - angle[..., 1]))
    residual = residual * (j._FIELD_EDGE[:, None] * j._FIELD_EDGE)
    neutral = np.linalg.solve(np.asarray(matrix, dtype=float), np.ones(3)) / wb
    neutral /= neutral[1]
    update = (residual[None] * neutral[:, None, None]).astype(np.float32)[j._CORE].astype(float) * j._GAINS
    outputs = {"anchor":anchor} | {k: (anchor + v*update).astype(anchor.dtype) for k,v in support.items()}
    records = [{"color": int(relative[c["site"]]), **c} for c in records]
    return outputs, {"admitted": True, "state": "delivered" if update.any() else "no measured increment",
                     "color_support": records,
                     "map_means": {k: float(v.mean()) for k,v in support.items()}}
