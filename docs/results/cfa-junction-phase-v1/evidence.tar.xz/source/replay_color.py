"""Compare retained parent output with measured partner-wire support."""

from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import guide_color as model

sys.path.append(str(model.HERE.parent / "local-junction-support-v1"))
import replay_junction as scoring

HERE, OUT = model.HERE, model.OUT
ARM = (
    ("green", 1),
    *( (k, 1) for k in model.ARMS[2:] ),
)


def collect(path):
    rows = []
    parent = read_json(checked(path))
    inputs = read_json(checked(parent["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y//2:(y+h)//2, x//2:(x+w)//2]
    local = (48,48,160,160)
    roi = (x+48,y+48,160,160)
    methods = ("baseline", *model.ARMS[1:])

    class Adapter:
        ARMS = methods

        @staticmethod
        def apply(*args, **kwargs):
            out, record = apply(*args, **kwargs)
            out["baseline"] = out.pop("anchor")
            return out, record

    apply = model.apply
    scoring.model = Adapter
    for fixture, record in zip(plan["sources"], parent["records"], strict=True):
        draws = []
        for stream in record["streams"]:
            with np.load(checked(stream["data"])) as data:
                payload = {k: data[k] for k in data.files}
            pred = np.load(checked(stream["outputs"]["local50k"]))
            result = scoring.assess(
                fixture, plan["noise"], pred, payload, payload["scene_packed"].copy(), cut, local, roi
            )
            draws.append(result | {"draw": stream["draw"], "input": stream["data"], "outputs": stream["outputs"]})
        rows.append({"id": fixture["id"], "fixture": fixture, "family": fixture["geometry"]["family"], "draws": draws})
        if len(rows)%8 == 0:
            print("Replayed", len(rows), flush=True)
    return rows, inputs["plan"]


def summary(rows):
    stats = {k: scoring.score(rows, (k, d)) for k,d in ARM}
    deltas = {k: scoring.paired(rows, (k,d), ARM[0]) for k,d in ARM[1:]}
    return {"statistics": stats, "relative_to_green": deltas}


def camera():
    source = reference(model.FIXED)
    data = read_json(checked(source))
    records = []
    for r in data["standing"]:
        with np.load(checked(r["input"])) as f:
            raw, colors, wb, matrix = [f[k][0] for k in ("packed","colors","wb","matrix")]
        parent = np.load(checked(r["predictions"]["local50k"]))[0]
        roi = tuple(r["local_ROI"])
        predictions, trace = model.apply(parent, roi, raw, colors, roi, r["noise"], wb, matrix, clearance=16)
        green = predictions["green"]
        differences = {k: float(np.sqrt(np.mean((v.astype(float)-green)**2))*65535) for k,v in predictions.items()}
        print(r["id"], differences, trace.get("color_support"), flush=True)
        records.append({"id":r["id"], "input":r["input"], "roi":r["global_ROI"], "noise":r["noise"],
                        "parent":r["predictions"]["local50k"], "difference_DN16":differences, "trace":trace})
    return source, records


if __name__ == "__main__":
    group = sys.argv[1]
    if group == "camera":
        source, rows = camera()
        result = {"source": source, "rows": rows}
    else:
        root = model.PARENT if group == "calibration" else OUT
        source = reference(root / group / "parent/result.json")
        rows, plan = collect(source)
        result = {"source": source, "plan": plan, "rows": rows, "summary": summary(rows)}
        for name, row in result["summary"]["statistics"].items():
            print(name, {k: round(v,4) for k,v in row["means"].items()}, flush=True)
    write_json(OUT / f"replay-{group}.json", {"driver": reference(__file__), "model": reference(Path(model.__file__))} | result)
