"""Measure phase closure in each color using disjoint packed Bayer cells."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

from demosaic._mesh_junction import (
    _CENTER, _distinct_bands, _folds, _quadratures, _step_from_discovery, _wave_angles,
)
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _sites, _spacing

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PARENT = OUT.with_name("local-junction-support-v1")
FIXED = OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"
PAIR = (1, -1)
FOLDS = _folds().ravel()
LEVEL_MASK = _folds() == 0
DENSITY = gaussian_filter(LEVEL_MASK.astype(float), 3)
XY = np.indices(_folds().shape).reshape(2, -1) * 2 - _CENTER
COLORS = ("red", "green1", "green2", "blue")


def pack(scene, colors, roi, clearance):
    x, y = roi[:2]
    f = _spacing(scene, colors, x, y, clearance=clearance)
    if f is None or PAIR not in _distinct_bands(f):
        return None
    x, y = x - 48, y - 48
    raw = np.stack([_sites(scene, x, y, 256, r, c) for r, c in np.ndindex(2, 2)])
    colors = np.array([colors[2 * ((y + r) % 2) + (x + c) % 2] for r, c in np.ndindex(2, 2)])
    return raw, colors, f


def per_site(raw, site, freq, bands, noise, step):
    y, x = XY + np.array([[site // 2], [site % 2]])
    x0, y0 = x / 128, y / 128
    k = (abs(x) < 96) & (abs(y) < 96)
    radial = np.exp(-0.5 * (x*x+y*y) / 75**2)
    r = raw.ravel().astype(float)
    level = (gaussian_filter(np.where(LEVEL_MASK, raw, 0).astype(float), 3) / DENSITY).ravel()
    variance = np.maximum(2e-11, noise["shot"] * level.clip(min=0) + noise["read"])
    poly = np.c_[np.ones(len(x)), x0, y0, x0**2, y0**2, x0*y0]
    if step is not None:
        a, z = step
        edge = np.clip(0.5 + (x * np.cos(a) + y * np.sin(a) - z) / 5, 0, 1)
        poly = np.c_[poly, edge[:, None] * poly[:, :3]]
    angles = _wave_angles(x, y, freq)
    shapes = _quadratures(angles)
    harmonics = _quadratures(angles @ np.asarray(bands).T)
    columns = np.c_[poly, shapes.reshape(len(x), -1), harmonics.reshape(len(x), -1)]
    tr = k & (FOLDS == 0)
    train = solve(columns[tr], r[tr], (radial / variance)[tr])
    start = poly.shape[1]
    theta = train[start:start+4].reshape(2, 2)
    return r, variance, radial, k, columns, start, theta, train


def solve(a, z, w):
    weighted = a.T * w
    return np.linalg.solve(weighted @ a, weighted @ z)


def projected(sample, index, phase):
    r, variance, radial, inner, columns, start, _, _ = sample
    index = start + 2*index
    u = np.asarray((np.cos(phase), -np.sin(phase)))
    signal = columns[:, index:index+2] @ u
    control = np.c_[columns[:, :index], columns[:, index+2:]]
    votes = []
    for fold in (0, 1, 2, 3):
        chosen = inner & (FOLDS == fold)
        a, t, z = control[chosen], signal[chosen], r[chosen]
        w = (radial / variance)[chosen]
        residual = t - a @ solve(a, t, w)
        norm = float((w * residual) @ residual)
        numerator = float((w * residual) @ z)
        power = float((w * residual)**2 @ variance[chosen])
        votes.append([numerator / norm * 65535, numerator / np.sqrt(power), np.sqrt(power) / norm * 65535])
    return np.asarray(votes)


def inspect(data, noise):
    if data is None:
        return None
    raw, colors, f = data
    bands = _distinct_bands(f)
    idx = bands.index(PAIR) + 2
    green = np.flatnonzero(colors == 1)
    step = _step_from_discovery(raw, LEVEL_MASK, green)
    sites = np.argsort(colors, kind="stable")
    samples = [per_site(raw[i], i, f, bands, noise, step) for i in sites]
    green_theta = 0.5 * (samples[1][6] + samples[2][6])
    phase = np.arctan2(-green_theta[:, 1], green_theta[:, 0])
    start = samples[1][5]
    votes = []
    for name, site, sample in zip(COLORS, sites, samples, strict=True):
        theta = sample[6]
        native = np.arctan2(-theta[:, 1], theta[:, 0])
        angle = phase[0] - phase[1]
        own = native[0] - native[1]
        aligned = projected(sample, idx, angle)
        quarter = projected(sample, idx, angle + np.pi/2)
        eigen = sample[-1][start + 2*idx:start + 2*idx + 2]
        free = np.arctan2(-eigen[1], eigen[0])
        votes.append({
            "name": name, "site": int(site), "fundamental_DN16": (np.linalg.norm(theta, axis=1)*65535).tolist(),
            "fundamental_phase": native.tolist(),
            "locked": aligned.tolist(), "quarter": quarter.tolist(),
            "own_locked": projected(sample, idx, own).tolist(),
            "free": projected(sample, idx, free).tolist(),
            "free_angle": float(free), "own_angle": float(own),
            "fundamental": [projected(sample, d, phase[d]).tolist() for d in (0, 1)],
        })
    return {"frequencies": f.tolist(), "bands": bands, "phase": phase.tolist(), "colors": votes}


def camera():
    source = reference(FIXED)
    data = read_json(checked(source))
    rows = []
    for r in data["standing"]:
        with np.load(checked(r["input"]), allow_pickle=False) as file:
            raw, colors = (file[k][0] for k in ("packed", "colors"))
        info = inspect(pack(raw, colors, r["local_ROI"], 16), r["noise"])
        if info:
            for c in info["colors"]:
                print(r["id"], c["name"], "fundamental", np.round(np.array(c["fundamental"])[:, :, 1], 1).tolist(), "side", np.round(np.array(c["locked"])[:, 1], 1), "quarter", np.round(np.array(c["quarter"])[:, 1], 1), flush=True)
        rows.append({"id": r["id"], "profile": r["noise"], "input": r["input"], "roi": r["global_ROI"], "terms": info})
    return {"source": source, "rows": rows}


def prior(group):
    source = reference(PARENT / group / "inputs.json")
    data = read_json(checked(source))
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y//2:(y+h)//2, x//2:(x+w)//2]
    roi = (x+48, y+48, 160, 160)
    rows = []
    for r in data["observations"]:
        views = []
        for stream in r["streams"]:
            with np.load(checked(stream["data"])) as f:
                scene, colors, packed = (f[k] for k in ("scene_packed","colors","packed"))
            terms = []
            for raw in packed:
                scene[cut] = raw
                terms.append(inspect(pack(scene, colors, roi, 48), plan["noise"]))
            views.append({"input": stream["data"], "draw": stream["draw"], "terms": terms})
        rows.append({"id": r["id"], "views": views})
        if len(rows) % 8 == 0:
            print("Finished", group, len(rows), flush=True)
    return {"source": source, "plan": data["plan"], "roles": plan["roles"], "rows": rows}


if __name__ == "__main__":
    kind = sys.argv[1]
    info = camera() if kind == "camera" else prior(kind)
    write_json(OUT / f"audit-{kind}.json", {"driver": reference(__file__)} | info)
