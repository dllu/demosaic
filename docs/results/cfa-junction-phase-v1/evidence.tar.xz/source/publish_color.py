"""Publish the four-plane evidence, both native comparisons, and parity receipts."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
BORROWED = (
    "local-junction-support-v1/capture_junction.py",
    "local-junction-support-v1/replay_junction.py",
    "local-junction-support-v1/review_junction.py",
    "local-nested-support-v1/replay_nested_parents.py",
)
RECEIPTS = (
    "audit-camera.json",
    "audit-camera-initial.json",
    "replay-calibration.json",
    "locked.json",
    "held/plan.json",
    "held/inputs.json",
    "held/parent/result.json",
    "replay-held.json",
    "replay-camera.json",
    "summary.json",
    "board-camera.json",
    "board-exact.json",
    "check-fast.json",
    "check-natural.json",
)
LOGS = (
    "audit-camera.log",
    "replay-calibration.log",
    "capture-held.log",
    "replay-held.log",
    "replay-camera.log",
    "summary.log",
    "board-camera.log",
    "board-exact.log",
    "check-fast.log",
    "check-natural.log",
    "tests.log",
)


def rooted(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def image(board):
    file = checked(board["image"])
    output = ASSETS / file.name
    shutil.copyfile(file, output)
    result = rooted(output)
    assert result["sha256"] == board["image"]["sha256"]
    with Image.open(output) as png:
        for panel in board["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= png.width and 0 <= y < y + h <= png.height
    return board | {"image": result}


def main():
    refs = {name: reference(OUT / name) for name in RECEIPTS}
    data = {name: read_json(checked(ref)) for name, ref in refs.items()}
    for name, payload in data.items():
        if name == "audit-camera-initial.json":
            assert (
                payload["driver"]["sha256"] == reference(OUT / "audit_color-initial.py")["sha256"]
            )
            continue
        for key in ("driver", "model", "old_operator", "current_operator"):
            if key in payload:
                checked(payload[key])
    assert data["locked.json"]["calibration"] == refs["replay-calibration.json"]
    for artifact in ("summary.json", "board-camera.json", "board-exact.json"):
        assert data[artifact]["lock"] == refs["locked.json"]
    assert data["summary.json"]["holdout"] == refs["replay-held.json"]
    inputs, plan, parents = (
        data[k] for k in ("held/inputs.json", "held/plan.json", "held/parent/result.json")
    )
    assert data["replay-held.json"]["source"] == refs["held/parent/result.json"]
    assert data["replay-held.json"]["plan"] == inputs["plan"] == refs["held/plan.json"]
    assert parents["inputs"] == refs["held/inputs.json"]
    for binding in parents["weights"].values():
        checked(binding)
    sets = []
    for source in (
        data["replay-calibration.json"]["plan"],
        refs["held/plan.json"],
        reference(OUT.with_name("local-junction-support-v1") / "independent/plan.json"),
    ):
        batch = read_json(checked(source))["sources"]
        assert len(batch) == 24
        sets.append({r["source"][k] for r in batch for k in ("id", "cache_sha256")})
    assert all(sets[i].isdisjoint(sets[j]) for i in range(3) for j in range(i))
    for group, first, second in zip(
        plan["sources"], inputs["observations"], parents["records"], strict=True
    ):
        assert group["id"] == first["id"] == second["id"]
        checked({"path": group["source"]["cache"], "sha256": group["source"]["cache_sha256"]})
        for observed, output in zip(first["streams"], second["streams"], strict=True):
            assert observed["data"] == output["data"]
            checked(observed["data"])
            for file in output["outputs"].values():
                checked(file)
    fast = data["check-fast.json"]
    assert [r["total"] for r in fast["bindings"]] == [336, 336, 8]
    assert "97 passed" in (OUT / "tests.log").read_text()
    camera = data["board-camera.json"]["data"]
    exact = data["board-exact.json"]["data"]
    assert exact["source"] == refs["replay-held.json"]
    assert len(camera["rows"]) == 8 and len(exact["rows"]) == 2
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    manifest = {
        "camera": camera
        | {"rows": [r | {"native": [image(b) for b in r["native"]]} for r in camera["rows"]]},
        "exact": exact
        | {"rows": [r | {k: image(r[k]) for k in ("triplet", "board")} for r in exact["rows"]]},
        "lock": refs["locked.json"],
    }
    manifest_path = ASSETS / "manifest.json"
    write_json(manifest_path, manifest)
    binding = {f"receipts/{k}": ref for k, ref in refs.items()}
    binding.update({f"logs/{k}": reference(OUT / k) for k in LOGS})
    binding.update({f"source/{fp.name}": reference(fp) for fp in HERE.glob("*.py")})
    binding.update({f"reused/{rel}": reference(HERE.parent / rel) for rel in BORROWED})
    binding["source/audit_color-initial.py"] = reference(OUT / "audit_color-initial.py")
    binding["source/mesh_junction_frozen.py"] = fast["old_operator"]
    binding["source/mesh_junction_batched.py"] = fast["current_operator"]
    tarpath = RESULTS / "evidence.tar.xz"
    with tarfile.open(tarpath, "x:xz") as out:
        for k, ref in binding.items():
            out.add(checked(ref), arcname=k, recursive=False)
    with tarfile.open(tarpath) as source:
        assert set(source.getnames()) == binding.keys()
        for k, ref in binding.items():
            with source.extractfile(k) as f:
                assert file_digest(f, "sha256").hexdigest() == ref["sha256"]
    previous = rooted(ROOT / "docs/results/local-junction-support-v1/publication.json")
    summary = RESULTS / "summary.json"
    write_json(summary, data["summary.json"] | {"batched": fast["statistics"]})
    write_json(
        RESULTS / "publication.json",
        {
            "archive": rooted(tarpath),
            "summary": rooted(summary),
            "native": rooted(manifest_path),
            "archive_members": binding,
            "previous_study": previous,
            "parent_weights": parents["weights"],
            "protected_capture_configs": [
                rooted(ROOT / "configs/gfx-qualitative-20231231.json"),
                rooted(ROOT / "configs/gfx-green-mesh-20231231.json"),
            ],
        },
    )
    print(rooted(tarpath))


if __name__ == "__main__":
    main()
