"""Capture new signed junction pairs, with aligned and conflicting color continuity."""

from pathlib import Path
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

from audit_color import HERE, OUT, PARENT

sys.path.append(str(HERE.parent / "local-junction-support-v1"))
import capture_junction as previous

SEED = 202611200702
COUNT = 24
clean = previous.clean_scenes
FAMILIES = ("aligned", "red continues through green break", "blue rear reversal")
prior = previous.source.last.run
weights = previous.source.last.run.prior.parents


def plan_for(root):
    prior.OUT = root
    prior.SEED = SEED
    prior.COUNT = COUNT
    prior.prior.EXCLUSIONS += (
        previous.ORIGINAL,
        PARENT / "calibration/plan.json",
        PARENT / "independent/plan.json",
        *(OUT.with_name("local-replicated-phase-v1") / g / "plan.json"
          for g in ("fresh", "verification", "station-confirm")),
        OUT.with_name("local-unranked-phase-v1") / "fresh/plan.json",
        OUT.with_name("local-near-phase-v1") / "fresh/plan.json",
    )
    plan = prior.freeze()
    for j, group in enumerate(plan["sources"]):
        i = group["index"]
        g = group["geometry"]
        rng = np.random.default_rng(scene_seed(SEED, i, "junction"))
        g["interaction_ratio"] = float(rng.uniform(0.45, 0.95))
        g["relative_interaction_polarity"] = 1 if i % 4 in (0, 3) else -1
        g["strength"][1] = float(g["strength"][0] * rng.uniform(0.60, 1.2))
        group["id"] = f"cfa-junction-{i:02d}"
        group["color_case"] = FAMILIES[(j + j // 6) % len(FAMILIES)]
    return plan | {
        "driver": reference(__file__), "roles": previous.ROLES,
        "channel_families": FAMILIES, "seed": SEED,
        "scope": "Distinct held photo sources, including red continuity through a green break and a blue rear wire with phase reversal.",
    }


def color_scenes(case):
    scenes, support, attachment = clean(case)
    color = case["color_case"]
    if color == FAMILIES[0]:
        return scenes, support, attachment
    inverse = torch.tensor(case["camera"]["camera_inverse"], dtype=torch.float32)
    matrix = torch.linalg.inv(inverse)
    both, bare = scenes[1], scenes[3]
    # Work in camera primaries before optics, normalization and Bayer sampling.
    axis = torch.arange(512) - 255.5
    radius = torch.maximum(axis.abs()[:, None], axis.abs()[None, :])
    inner = ((128 - radius) / 24).clamp(0, 1)
    channel = 0 if color == FAMILIES[1] else 2
    partner = torch.zeros(3)
    partner[channel] = 1.0
    inverse_axis = matrix @ partner
    if color == FAMILIES[1]:
        # A red rear strand may continue across a break that is exact in green.
        signed = (inverse[channel] @ (scenes[2] - both).flatten(1)).reshape(512, 512)
    else:
        # A chromatic sign change in one strand is compatible with these two green phases.
        signed = -2 * (inverse[channel] @ (both - bare).flatten(1)).reshape(512, 512)
    offset = inverse_axis[:, None, None] * (signed * inner)
    # Modify the present and matched additive captures identically.
    scenes = tuple(scene + offset if i < 2 else scene for i, scene in enumerate(scenes))
    assert all(0 < float(frame.min()) and float(frame.max()) < 1 for frame in scenes)
    return scenes, support, attachment


def main():
    torch.set_num_threads(2)
    root = OUT / "held"
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    plan_fp = root / "plan.json"
    if not plan_fp.exists():
        write_json(plan_fp, plan_for(root))
    plan = read_json(plan_fp)
    assert reference(__file__) == plan["driver"]
    capture = root / "inputs.json"
    if not capture.exists():
        captured = []
        start = monotonic()
        with patch.object(previous, "clean_scenes", color_scenes):
            for c in plan["sources"]:
                captured.append({
                    "id": c["id"],
                    "streams": list(previous.save_case(c, SEED, plan["noise"], plan["sigma"], root / "inputs")),
                })
                if len(captured)%8 == 0:
                    print("Captured", len(captured), flush=True)
        write_json(capture, {"driver": reference(__file__), "plan": reference(plan_fp),
                            "observations": captured, "seconds": monotonic()-start})
    weights.OUT = root
    if not (root / "parent/result.json").exists():
        weights.main()


if __name__ == "__main__":
    main()
