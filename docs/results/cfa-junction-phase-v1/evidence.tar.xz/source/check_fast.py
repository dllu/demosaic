"""Measure parity and timing for batched green-only station projections."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from statistics import median
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch

from demosaic import _mesh_junction as junction
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
from audit_color import OUT, PARENT, FIXED
import guide_color

FROZEN = OUT / "mesh_junction_frozen.py"
name = "demosaic._mesh_junction_frozen"
spec = spec_from_file_location(name, FROZEN)
frozen = module_from_spec(spec)
sys.modules[name] = frozen
spec.loader.exec_module(frozen)
NEW = junction._local_wire_support
METHODS = ("frozen", "batched")
LOCAL = (48, 48, 160, 160)


def outputs(data, raw, layout, roi, noise, wb, matrix, seconds, ordering, clearance=48):
    x, y, w, h = roi
    region = guide_color.crop(data, (x - 48, y - 48, 256, 256))
    core = guide_color.crop(data, roi)

    def infer():
        return refine_raw_mesh_carriers(
            core,
            raw,
            layout,
            roi,
            shot=noise["shot"],
            read=noise["read"],
            white_balance=wb,
            camera_to_srgb=matrix,
            method="weak-junction-phase",
            donor_clearance=clearance,
            parent_context=region,
        )

    images, used = {}, {}
    for method in METHODS if ordering % 2 == 0 else METHODS[::-1]:

        def measuring(obs, known):
            label = frozen._local_wire_support if method == "frozen" else NEW
            begin = monotonic()
            out = label(obs, known)
            used[method] = monotonic() - begin
            return out

        with patch.object(junction, "_local_wire_support", measuring):
            start = monotonic()
            images[method] = infer()
            seconds.setdefault(method, []).append((monotonic() - start, used.get(method)))
    np.testing.assert_array_equal(images["frozen"], images["batched"])
    return "frozen" in used


def synthetic(source, timings):
    receipt = read_json(checked(source))
    inputs = read_json(checked(receipt["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    assert (x, y, w, h) == (128, 128, 256, 256)
    comparisons, support = 0, 0
    for row in receipt["records"]:
        for draw in row["streams"]:
            with np.load(checked(draw["data"])) as f:
                full, subset, cfa, wb, matrix = [
                    f[k] for k in ("scene_packed", "packed", "colors", "wb", "matrix")
                ]
            parent = np.load(checked(draw["outputs"]["local50k"]))
            roi = (48, 48, 160, 160)
            for raw, output in zip(subset, parent, strict=True):
                full[cut] = raw
                # The public method shares one origin for the full scene and its RGB context.
                # Pad only for geometry. The known parent lives inside the same 256 query.
                canvas = np.pad(output, ((0, 0), (y, y), (x, x)))
                support += outputs(
                    canvas,
                    full,
                    cfa,
                    (x + 48, y + 48, 160, 160),
                    plan["noise"],
                    wb,
                    matrix,
                    timings,
                    comparisons,
                )
                comparisons += 1
    return {"source": source, "total": comparisons, "with_local_fit": support}


def standing(source, timings):
    receipt = read_json(checked(source))
    support = 0
    for i, r in enumerate(receipt["standing"]):
        with np.load(checked(r["input"])) as stream:
            packed, colors, wb, matrix = [
                stream[name][0] for name in ("packed", "colors", "wb", "matrix")
            ]
        parent = np.load(checked(r["predictions"]["local50k"]))[0]
        support += outputs(
            parent, packed, colors, r["local_ROI"], r["noise"], wb, matrix, timings, i, 16
        )
    return {"source": source, "total": len(receipt["standing"]), "with_local_fit": support}


def natural():
    guide_color.j = frozen
    refs = {
        k: reference(OUT.with_name(d) / n)
        for k, d, n in (
            ("authentic", "local-weak-contrast-v1", "natural-controls.json"),
            ("mismatch", "local-near-phase-v1", "contexts-calibration.json"),
        )
    }
    natural, others = [read_json(checked(refs[k])) for k in ("authentic", "mismatch")]
    profile = read_json(checked(others["plan"]))["noise"]
    records = []
    cut = np.s_[..., 64:192, 64:192]
    for a, b in zip(natural["rows"], others["records"], strict=True):
        assert a["id"] == b["id"]
        with np.load(checked(a["input"])) as file:
            d = {k: file[k] for k in file.files}
        alt = b["streams"][0]["far_phase"]
        mismatch = np.load(checked(alt), allow_pickle=False)
        mismatch[cut] = d["scene_packed"][cut]
        changes = {}
        for key, raw in (("authentic", d["scene_packed"]), ("mismatch", mismatch)):
            result, trace = guide_color.apply(
                d["parent"],
                LOCAL,
                raw,
                d["colors"],
                (176, 176, 160, 160),
                profile,
                d["wb"],
                d["matrix"],
            )
            changes[key] = {
                h: float(np.sqrt(np.mean((v.astype(float) - result["green"]) ** 2)) * 65535)
                for h, v in result.items()
            }
        records.append({"id": a["id"], "input": a["input"], "mismatch": alt, "changes": changes})
    print(
        "Ordinary replay",
        sum(
            any(x > 0 for k, x in r["changes"][g].items() if k != "anchor")
            for g in ("authentic", "mismatch")
            for r in records
        ),
        flush=True,
    )
    return {"sources": refs, "rows": records}


def benches(timings):
    report = {}
    for label, values in timings.items():
        total = [s * 1e3 for s, _ in values]
        accepted = [s * 1e3 for s, a in values if a is not None]
        stations = [a * 1e3 for _, a in values if a is not None]
        report[label] = {
            k: {"median": median(v), "p95": float(np.quantile(v, 0.95)), "count": len(v)}
            for k, v in (("total_ms", total), ("accepted_ms", accepted), ("station_ms", stations))
        }
    return report


if __name__ == "__main__":
    torch.set_num_threads(2)
    kind = sys.argv[1]
    if kind == "natural":
        report = natural()
    else:
        timings = {}
        provenance = []
        for root, key in [(OUT, "held"), (PARENT, "independent")]:
            source = reference(root / key / "parent/result.json")
            provenance.append(synthetic(source, timings))
            print(key, provenance[-1], flush=True)
        provenance.append(standing(reference(FIXED), timings))
        report = {"bindings": provenance, "timings": timings, "statistics": benches(timings)}
        print(report["statistics"], flush=True)
    write_json(
        OUT / f"check-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "old_operator": reference(FROZEN),
            "current_operator": reference(Path(junction.__file__)),
        }
        | report,
    )
