"""Render the selected held-out ISO400 ellipse and strip without resampling."""
from pathlib import Path
import numpy as np

from render_envelope import ROOT, OLDER, CAPTIONS, render_models, prior_setup
from review_gate import PRIOR
from review_quiet import LOCAL, wire_inputs
from report_scene_wave_guides import native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


if __name__=="__main__":
    model,stamp=prior_setup()
    binding=reference(PRIOR/"wire-parent.json")
    inputs=read_json(checked(binding))
    plan=read_json(checked(inputs["plan"]))
    proofs={r["id"]:r for r in inputs["rows"]}
    control=read_json(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")
    lookup={r["input"]["sha256"]:r for r in control["rows"]}
    records=read_json(checked(inputs["inputs"]))["rows"]
    destination=ROOT/"low-iso"
    destination.mkdir()
    rows=[]
    for index in (5,12):
        case=next(r for r in records if r["index"]==index and r["noise"]=="iso400")
        raw,parents,proof=wire_inputs(case,proofs,lookup)
        source=plan["sources"][index]
        noise=plan["profiles"]["iso400"]
        sample={k:raw[k][:1]for k in ("packed","colors","wb","matrix")}
        restore=render_models(*(sample[k][0]for k in ("packed","colors","wb","matrix")),noise,plan["query"],
                              raw["full"],parents[LOCAL][0],(model[0],model[1]["scale64"]))
        fields=("distant","wide","checked","cell-all")
        measures=[noisy_malvar(sample)[0],parents["V120"][0],parents["100k"][0],
                  *[restore[k]for k in fields],raw["target"][0]]
        metadata={"input":case["input"],"local_parent":proof,"noise":noise,"source":source["source"],
                  "family":source["geometry"]["family"],"query":plan["query"],
                  "source_specification":source}
        labels=("Noisy Malvar","V120 EMA","Corpus 100k EMA",*[CAPTIONS[k]for k in fields],"Exact GT")
        rows.append(native_board(destination,f"{index:03d}-iso400",measures,sample,metadata,labels=labels,
                  exposure=2,contrast=1,triplet_indices=(0,5,7)))
    write_json(destination/"manifest.json",stamp|{"driver":reference(__file__),"rows":rows,"sources":binding})
