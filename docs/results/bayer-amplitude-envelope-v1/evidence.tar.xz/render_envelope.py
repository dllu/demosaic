"""View the registered amplitude rules with the exact parent and coordinates."""
from pathlib import Path
import sys

import numpy as np

from pooled import ROOT, OLDER, METHODS, correction
from envelope import ROI, compose, prior_setup, review, select
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import envelope_boards as boards

CAPTIONS={
    "Bayer-gated":"Bayer-gated refit",
    "ring8":"Eight-donor EMA",
    "distant":"Distant Bayer gate",
    "wide":"64-pixel carrier fit",
    "checked":"Green envelope",
    "cell-green":"Cell split, green",
    "cell-all":"All-color envelope",
    "cell-all-reversed":"All-color reversed",
    "cell-all-unchecked":"Unchecked envelope",
}


def render_models(raw,layout,wb,matrix,noise,box,exterior,parent,models,roi=None):
    frozen,dose=models
    roi=ROI if roi is None else tuple(roi)
    spacing,ok,_=select(exterior,layout,box,roi)
    donors=review.exterior(exterior,layout,noise,box)
    controls=compose(raw,layout,wb,matrix,noise,box,donors,parent,frozen,False)
    base=controls["distant"]
    routed,_=correction(raw,base,layout,wb,matrix,noise,spacing,roi,ok)
    images=controls|{key:base+np.float32(dose)*d.sum(axis=-1)for key,d in routed.items()}
    return {key:images[key]for key in CAPTIONS}


def main(mode):
    (models,doses),stamp=prior_setup()
    frozen=reference(ROOT/"pooled.json")
    joined=read_json(checked(frozen))
    assert joined["checkpoint"]==stamp["checkpoint"]
    # Reuse the frozen board routines with this experiment's output folder,
    # labels and exact rendering function.
    boards.ROOT=ROOT
    boards.CAPTIONS=CAPTIONS
    boards.render_models=render_models
    receipt=stamp|{"driver":reference(__file__),"envelope_receipt":frozen,"comparison_dose":doses["scale64"]}
    {"exact":boards.exact,"standing":boards.standing}[mode]((models,doses["scale64"]),receipt,None)


if __name__=="__main__":
    main(sys.argv[1])
