"""Estimate one spatial amplitude envelope from separate per-color carrier fits."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

from envelope import ROOT, OLDER, SIZE, MODES, BLENDS, TEMPLATES, ROI, unpack, wave, geometry
from envelope import patch as green_patch, compose, prior_setup, review
import screen
from review_gate import PRIOR
from review_quiet import numeric
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

METHODS=("wide","checked","cell-green","cell-all","cell-all-mean","cell-all-reversed","cell-all-unchecked")
MARGIN=3.
SHRINK=6.

generator=np.random.default_rng(144175)
masked=np.zeros((SIZE//2)**2,dtype=bool)
masked[generator.choice(len(masked),len(masked)//2,replace=False)]=True
FOLDS=(masked,~masked)


def in_plane(field,index):
    height, width = field.shape[:2]
    values=field[index//2:height:2,index%2:width:2]
    return values.reshape(((height//2)*(width//2),*field.shape[2:]))


def profiled(raw,base,carrier,index,fold,noise):
    values=in_plane(raw,index).astype(np.float64)
    design=in_plane(base,index)
    phases=in_plane(carrier,index)
    test=FOLDS[1-fold]
    fit=FOLDS[fold]
    A,B=design[fit],design[test]
    x,y=values[fit],values[test]
    sigma2=max(2e-11,float(noise["shot"])*max(0.,float(x.mean()))+float(noise["read"]))
    gram=A.T@A
    beta=np.linalg.solve(gram,A.T@x)
    strength=beta[-4:].reshape(2,2).T
    combined=np.stack((phases[:,:2],phases[:,2:]),axis=-1)
    # Each Bayer plane gets its own signed complex carrier and smooth tone.
    # Only the fractional spatial amplitude change is shared.
    amplitude=np.sum(combined*strength,axis=-1)
    basis=(amplitude[...,None]*in_plane(MODES,index)[:,None,:]).reshape(len(values),-1)
    removed=np.linalg.solve(gram,A.T@basis[fit])
    U=(basis[fit]-A@removed)/np.sqrt(sigma2)
    V=(basis[test]-B@removed)/np.sqrt(sigma2)
    return U,V,(x-A@beta)/np.sqrt(sigma2),(y-B@beta)/np.sqrt(sigma2)


def solve(stats):
    U,V,x,y=(np.concatenate([part[d]for part in stats],axis=0)for d in range(4))
    gram=U.T@U
    coef=np.linalg.solve(gram+np.diag(.45*np.diag(gram)+.05),U.T@x)
    k=MODES.shape[-1]
    proposal=(V*coef).reshape(len(y),2,k).sum(axis=-1)
    residual=y-proposal.sum(axis=1)
    gain=(((residual[:,None]+proposal)**2-residual[:,None]**2).sum(axis=0))
    envelope=np.clip(1+MODES@coef.reshape(2,k).T,0,1)
    return envelope,gain


def envelopes(raw,base,carrier,green,noise):
    banks = [tuple(profiled(raw,base,carrier,i,f,noise) for i in range(4))for f in (0,1)]
    views=([[bank[j]for j in green]for bank in banks],banks)
    output=[]
    for kind in views:
        first,second=(solve(arm)for arm in kind)
        weaker=np.maximum(0,np.minimum(first[1],second[1])-MARGIN)
        strength=weaker/(weaker+SHRINK)
        field=(first[0]+second[0])*.5
        output.append((1+(field-1)*strength,field,(strength>0).astype(int)))
    return output


def compose_patch(raw,parent,layout,xy,carrier,base,noise):
    reference, matched=green_patch(raw,parent,layout,xy,carrier,base,noise)
    prediction=reference["wide"]
    if not prediction.any():
        return {label:prediction for label in METHODS}, [matched,[0,0],[0,0]]
    x,y,_=xy
    pattern=layout.reshape(2,2)[(np.arange(2)+y)%2][:,(np.arange(2)+x)%2].ravel()
    ids=np.flatnonzero(pattern==1)
    green,all_planes=envelopes(raw,base,carrier,ids,noise)
    local,unchecked,active=all_planes
    average=np.sum(local*BLENDS[SIZE][...,None],axis=(0,1))/BLENDS[SIZE].sum()
    return {"wide":prediction,"checked":reference["checked"],"cell-green":prediction*green[0],
            "cell-all":prediction*local,"cell-all-mean":prediction*average,
            "cell-all-reversed":prediction*local[::-1,::-1],"cell-all-unchecked":prediction*unchecked},[matched,green[2].tolist(),active.tolist()]


def correction(raw,parent,layout,wb,matrix,noise,spacing,roi,ok):
    if not ok:
        return {k:np.zeros(parent.shape+(2,),dtype=np.float32)for k in METHODS}, [[0,0],[0,0],[0,0]]
    x,y,w,h=roi
    assert w==h==160
    carriers=wave(spacing,SIZE)
    base=np.concatenate((TEMPLATES[SIZE],carriers),axis=-1)
    mass=np.zeros((h,w),dtype=np.float64)
    accum={key:np.zeros((h,w,2),dtype=np.float64)for key in METHODS}
    green=parent[1,y:y+h,x:x+w]
    mosaic=unpack(raw)[y:y+h,x:x+w]
    counts=np.zeros((3,2),dtype=np.int64)
    blend=BLENDS[SIZE]
    for row in range(0,h-SIZE+1,SIZE//2):
        for col in range(0,w-SIZE+1,SIZE//2):
            sl=np.s_[row:row+SIZE,col:col+SIZE]
            fields,taken=compose_patch(mosaic[sl],green[sl],layout,(x+col,y+row,SIZE),carriers,base,noise)
            for key,value in fields.items():
                accum[key][sl]+=value*blend[...,None]
            mass[sl]+=blend
            counts+=taken
    edge=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    weights=edge[:,None]*edge[None,:]/np.maximum(.02,mass)
    neutral=np.linalg.solve(matrix,np.ones(3))/wb
    result={}
    for key,value in accum.items():
        out=np.zeros(parent.shape+(2,),dtype=np.float32)
        out[:,y:y+h,x:x+w]=(neutral/neutral[1])[:,None,None,None]*(value*weights[...,None])[None]
        result[key]=out
    return result,counts.tolist()


def proposals(raw,layout,wb,matrix,noise,box,donors,parent,network,spacing,roi,admitted):
    controls=compose(raw,layout,wb,matrix,noise,box,donors,parent,network,False)
    additions,counts=correction(raw,controls["distant"],layout,wb,matrix,noise,spacing,roi,admitted)
    return controls,additions,counts


def main():
    start=time.monotonic()
    (models,previous),binding=prior_setup()
    dose=previous["scale64"]
    prior=reference(ROOT/"wire.json")
    first=read_json(checked(prior))
    tables={}
    screen.ARMS=METHODS
    screen.proposals=proposals
    for name,n in (("wire-tune",24),("wire",48)):
        proof=read_json(checked(first["inputs"][name]))
        plan=read_json(checked(proof["plan"]))
        rows=read_json(checked(proof["inputs"]))["rows"]
        tables[name]=review.run(rows,partial(screen.measure,plan=plan,lookup={r["id"]:r for r in proof["rows"]},models=models))
        assert len(tables[name])==n
    assert {r["source_id"]for r in tables["wire-tune"]}.isdisjoint(r["source_id"]for r in tables["wire"])
    matching={}
    for m in METHODS[1:]:
        a,b=(np.mean([np.diag(r["gram"][k]["component_intact_present"][2])/
                       r["gram"][k]["component_intact_present"][3] for r in tables["wire-tune"]],axis=0)
             for k in (m,"wide"))
        matching[m]=(dose*np.sqrt(np.minimum(1.,a/np.maximum(1e-20,b)))).tolist()
    scored=[screen.evaluate(r,dose,matching)for r in tables["wire"]]
    old={row["id"]:row for row in first["rows"]}
    for row in scored:
        matched=old[row["id"]]
        assert (row["input"],row["parent_output"])==(matched["input"],matched["parent_output"])
        for key in ("wide","checked"):
            assert row["metrics"][key]==matched["metrics"][key]
    groups={p:[r for r in scored if r["profile"]==p]for p in ("iso400","iso6400")}
    comparisons=[(a,b)for a in METHODS[1:]for b in ("wide",a+"-uniform")]
    comparisons += [("cell-all",b)for b in ("checked","cell-green","cell-all-mean","cell-all-reversed","zero","ring8")]
    write_json(ROOT/"pooled.json",binding | {"driver":reference(__file__),"analysis_driver":reference(screen.__file__),
        "prior":prior,"dose":dose,"uniform_doses":matching,"rows":scored,"calibration":tables["wire-tune"],
        "reports":numeric(groups,comparisons,("intact_response",*screen.RMS_FIELDS)),"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
