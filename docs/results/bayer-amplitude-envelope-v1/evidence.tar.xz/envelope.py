"""Refine 64-pixel Bayer amplitudes with cross-checked smooth envelopes."""
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
OLDER = ROOT.parent / "bayer-carrier-scale-v1"
sys.path.insert(0, str(OLDER))

from carrier_scale import planes, wave
from restore import BLENDS, TEMPLATES, ROI, unpack, geometry, compose, review
from apply_scale import setup as prior_setup, select

ARMS = ("wide", "checked", "mean", "flipped", "unchecked")
SIZE = 64
RIDGE = .06
MARGIN = 3.
SHRINK = 6.

POS = (np.arange(SIZE, dtype=np.float64)+.5) / SIZE
ODD = np.cos(np.pi*POS)
EVEN = np.cos(2*np.pi*POS)
CONSTANT = np.ones(SIZE)
MODES = np.stack([np.outer(a,b)for a,b in ((ODD,CONSTANT),(CONSTANT,ODD),(ODD,ODD),
                   (EVEN,CONSTANT),(CONSTANT,EVEN),(EVEN,ODD),(ODD,EVEN))],axis=-1)


def sample(image, offsets):
    y,x = offsets
    values = image[y::2,x::2]
    return values.reshape((-1,*values.shape[2:]))


def fit_fold(base, carriers, raw, discovery, hold, noise):
    A,B = (sample(base,o) for o in (discovery,hold))
    x,y = (sample(raw,o).astype(np.float64) for o in (discovery,hold))
    sigma2 = max(2e-11, float(noise["shot"])*max(0,float(x.mean()))+float(noise["read"]))
    gram,moment = A.T@A,A.T@x
    coeff = np.linalg.solve(gram,moment)
    observed = coeff[-4:].reshape(2,2).T
    target = y-B@coeff
    variance = float(target@target)
    wave_support = []
    for side in range(2):
        columns = np.ones(A.shape[1],dtype=bool)
        columns[np.arange(side,4,2)+A.shape[1]-4] = False
        params = np.linalg.solve(gram[columns][:,columns],moment[columns])
        residual = y-B[:,columns]@params
        wave_support.append(float((residual@residual-variance)/sigma2))
    if not any(v>6 for v in wave_support):
        return observed, wave_support, np.ones((SIZE,SIZE,2)), np.zeros(2)
    period = np.stack((carriers[...,:2],carriers[...,2:]),axis=-1)
    power = np.linalg.norm(observed,axis=1).clip(min=1e-8)
    phase = np.sum(period*(observed/power[:,None]),axis=-1)
    bumps = (phase[...,None]*MODES[...,None,:]).reshape(SIZE,SIZE,-1)
    U,V = (sample(bumps,o) for o in (discovery,hold))
    # Remove the nuisance and both constant carriers using the same
    # projection on the reserve. This makes the comparison conditional.
    remove = np.linalg.solve(gram,A.T@U)
    U -= A@remove
    V -= B@remove
    grid = MODES.shape[-1]
    params = np.linalg.solve(U.T@U + RIDGE*len(x)*np.eye(U.shape[1]), U.T@(x-A@coeff))
    details = (V*params).reshape(len(y),2,grid).sum(axis=-1)
    extra = target-details.sum(axis=1)
    score = (((extra[:,None]+details)**2-extra[:,None]**2).sum(axis=0))/sigma2
    modulation = np.einsum("yxf,df->yxd",MODES,params.reshape(2,grid))/power
    return observed,wave_support, np.clip(1+modulation,0,1), score


def patch(raw, parent, pattern, corner, carriers, base, noise):
    a,b=planes(pattern,corner)
    first, second = [fit_fold(base,carriers,raw,j,k,noise) for j,k in ((a,b),(b,a))]
    reserve = np.maximum(0,np.minimum(first[1],second[1])-6)
    weight = reserve/(reserve+6)
    shape = (SIZE,SIZE,2)
    if not weight.any():
        return {a:np.zeros(shape,dtype=np.float64) for a in ARMS}, [0,0]
    coefficients = (first[0]+second[0])*.5
    mat = base.reshape(-1,base.shape[-1])
    recovered = np.linalg.solve(mat.T@mat,mat.T@parent.ravel())[-4:].reshape(2,2).T
    delta = (coefficients-recovered)*weight[:,None]
    extent = np.linalg.norm(coefficients,axis=1)
    delta *= np.minimum(1,extent/np.linalg.norm(delta,axis=1).clip(min=1e-10))[:,None]
    independent = np.maximum(0,np.minimum(first[3],second[3])-MARGIN)
    apply = independent/(independent+SHRINK)
    envelope = (first[2]+second[2])*.5
    gated = 1+(envelope-1)*apply
    avg = np.sum(gated*BLENDS[SIZE][...,None],axis=(0,1))/BLENDS[SIZE].sum()
    wavefront = np.stack((carriers[...,:2],carriers[...,2:]),axis=-1)
    prediction = np.sum(wavefront*delta,axis=-1)
    maps = {"wide":prediction,"checked":prediction*gated,"mean":prediction*avg,
            "flipped":prediction*gated[::-1,::-1],"unchecked":prediction*envelope}
    return maps,((apply>0)&(weight>0)).astype(int).tolist()


def correction(raw,parent,layout,wb,matrix,noise,spacing,roi,admitted):
    if not admitted:
        return {key:np.zeros(parent.shape+(2,),dtype=np.float32) for key in ARMS}, [0,0]
    x,y,w,h=roi
    assert w==h==160
    carriers=wave(spacing,SIZE)
    base=np.concatenate((TEMPLATES[SIZE],carriers),axis=-1)
    mass=np.zeros((h,w),dtype=np.float64)
    accum={key:np.zeros((h,w,2),dtype=np.float64) for key in ARMS}
    green=parent[1,y:y+h,x:x+w]
    mosaic=unpack(raw)[y:y+h,x:x+w]
    count=np.zeros(2,dtype=np.int64)
    taper=BLENDS[SIZE]
    for row in range(0,h-SIZE+1,SIZE//2):
        for col in range(0,w-SIZE+1,SIZE//2):
            bounds=np.s_[row:row+SIZE,col:col+SIZE]
            routed,supported=patch(mosaic[bounds],green[bounds],layout,(x+col,y+row,SIZE),carriers,base,noise)
            for key,delta in routed.items():
                accum[key][bounds]+=delta*taper[...,None]
            mass[bounds]+=taper
            count+=supported
    edge=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    weights=edge[:,None]*edge[None,:]/np.maximum(.02,mass)
    neutral=np.linalg.solve(matrix,np.ones(3))/wb
    results={}
    for name,result in accum.items():
        dst=np.zeros(parent.shape+(2,),dtype=np.float32)
        dst[:,y:y+h,x:x+w]=(neutral/neutral[1])[:,None,None,None]*(result*weights[...,None])[None]
        results[name]=dst
    return results,count.tolist()


def proposals(raw,layout,wb,matrix,noise,box,donors,parent,network,spacing,roi,admitted):
    controls=compose(raw,layout,wb,matrix,noise,box,donors,parent,network,False)
    deltas,counts=correction(raw,controls["distant"],layout,wb,matrix,noise,spacing,roi,admitted)
    return controls,deltas,counts
