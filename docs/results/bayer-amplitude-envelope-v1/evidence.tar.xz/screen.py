"""Score envelope localization at fixed and independently matched strength."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

from envelope import ARMS, ROI, ROOT, OLDER, geometry, proposals, prior_setup, review
from review_gate import PRIOR
from review_quiet import CORE, LOCAL, numeric, wire_inputs
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0,str(ROOT.parent/"local-phase-envelope-v1"))
from gap_projection import subspace

RMS_FIELDS=("intact_rms","flat_rms","flat_added","gap_exact","gap_added","gap_weak_error",
            "gap_weak_added","gap_strong_added","strong_only_weak_error")


def grams(y,x):
    y=np.asarray(y,dtype=np.float64).ravel()
    X=np.asarray(x,dtype=np.float64).reshape((len(y),2))
    a=X.T@y
    b=X.T@X
    return [float(y@y),a.tolist(),b.tolist(),len(y)]


def estimate(block, scale, length=None):
    yy,yx,xx,n=block
    n=n if length is None else length
    if not n:
        return None
    return float(65535*np.sqrt(max(0,yy+2*np.asarray(yx)@scale+scale@np.asarray(xx)@scale)/n))


def measure(case, plan, lookup, models):
    data, parents, proof=wire_inputs(case,lookup,None)
    profile=plan["profiles"][case["noise"]]
    box=plan["query"]
    scene=plan["sources"][case["index"]]
    donors=review.exterior(data["full"],data["colors"][0],profile,box)
    spacing,admitted,geom=geometry(data["full"],data["colors"][0],box,ROI)
    head=[proposals(a,b,c,d,profile,box,donors,e,models,spacing,ROI,admitted)
          for a,b,c,d,e in zip(data["packed"],data["colors"],data["wb"],data["matrix"],parents[LOCAL],strict=True)]
    def luma(value):
        return review.old.luma(value,data)[...,CORE[0],CORE[1]]
    clean=luma(data["target"])
    base=luma(np.stack([v[0]["distant"]for v in head]))
    net_delta={key:luma(np.stack([v[0][key]for v in head]))-base for key in ("ring8","exterior-only")}
    error=base-clean
    support=data["support"][CORE]
    intact,gap=support>=.97,support<=.01
    goal=(clean[0]-clean[1])[intact]
    shadow=np.s_[3,8:-8,8:-8]
    projected=subspace(scene["geometry"],gap)
    quiet=subspace(scene["geometry"],np.ones(support.shape,dtype=bool))[-1]
    reports={}
    for key in (*ARMS,"zero",*net_delta):
        if key in ARMS:
            extra=np.stack([h[1][key] for h in head])
            c=np.stack([luma(extra[...,i])for i in range(2)],axis=-1)
        else:
            y=net_delta.get(key,np.zeros_like(base))
            c=np.stack((y,np.zeros_like(y)),axis=-1)
        difference=(c[0]-c[1])[intact]
        reports[key]={"dot":[*review.aligned(goal,(base[0]-base[1])[intact]),
                            *np.asarray(goal,dtype=np.float64)@difference.astype(np.float64)],
            "component_intact_present":grams(np.zeros(intact.sum()),c[0][intact]),
            "intact_rms":grams((error[0]-error[1])[intact],difference),
            "flat_rms":grams(error[shadow],c[shadow]),
            "flat_added":grams(np.zeros_like(error[shadow]),c[shadow]),
            "gap_exact":grams(error[0][gap],c[0][gap]),
            "gap_added":grams(np.zeros(gap.sum()),c[0][gap]),
            "strong_only_weak_error":grams(quiet.T@error[2].ravel(),quiet.T@c[2].reshape(-1,2)),
        }
        if projected is not None:
            strong,weak=projected[1:]
            reports[key].update(
                gap_weak_error=grams(weak.T@error[0][gap],weak.T@c[0][gap]),
                gap_weak_added=grams(np.zeros(weak.shape[1]),weak.T@c[0][gap]),
                gap_strong_added=grams(np.zeros(strong.shape[1]),strong.T@c[0][gap]))
        else:
            reports[key].update({m:grams(np.empty(0),np.empty((0,2)))
                                  for m in ("gap_weak_error","gap_weak_added","gap_strong_added")})
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"profile":case["noise"],"source_id":scene["source"]["id"],
            "gap_pixels":int(gap.sum()),"core_pixels":int(support.size),"input":case["input"],"parent_output":proof,
            "geometry":geom,"counts":[x[2]for x in head],"gram":reports}


def uniform_controls(calibration,dose):
    control={}
    for name in ("checked","mean","flipped","unchecked"):
        a,b=(np.mean([np.diag(r["gram"][key]["component_intact_present"][2])/
                            r["gram"][key]["component_intact_present"][3]for r in calibration],axis=0)
             for key in (name,"wide"))
        control[name]=np.sqrt(np.minimum(1.,a/np.maximum(1e-20,b)))*dose
    return {k:v.tolist()for k,v in control.items()}


def evaluate(row,dose,matching):
    choices=[(name,name,(dose,dose))for name in ARMS]
    choices.extend((name+"-uniform","wide",d)for name,d in matching.items())
    choices.extend((name,name,(1.,0.))for name in ("zero","ring8","exterior-only"))
    scores={}
    for key,method,strength in choices:
        stats=row["gram"][method]
        amount=np.asarray(strength)
        dot,power,*increment=stats["dot"]
        metrics={"intact_dot":float(dot+amount@increment),"intact_power":power}
        for field in RMS_FIELDS:
            length=row["gap_pixels"] if field in ("gap_weak_error","gap_weak_added","gap_strong_added") else None
            if field=="strong_only_weak_error":
                length=row["core_pixels"]
            metrics[field]=estimate(stats[field],amount,length=length)
        scores[key]=metrics
    return row | {"metrics":scores|{"matched":scores["wide"]}}


def main():
    start=time.monotonic()
    (models,previous),binding=prior_setup()
    dose=previous["scale64"]
    prior=reference(OLDER/"wire.json")
    orig=read_json(checked(prior))
    tables={}
    for name,n in (("wire-tune",24),("wire",48)):
        proof=read_json(checked(orig["inputs"][name]))
        records=read_json(checked(proof["inputs"]))["rows"]
        plan=read_json(checked(proof["plan"]))
        table=review.run(records,partial(measure,plan=plan,lookup={r["id"]:r for r in proof["rows"]},models=models))
        assert len(table)==n
        tables[name]=table
    assert {a["source_id"]for a in tables["wire"]}.isdisjoint(b["source_id"]for b in tables["wire-tune"])
    matching=uniform_controls(tables["wire-tune"],dose)
    final=[evaluate(row,dose,matching)for row in tables["wire"]]
    from benchmark import evaluate as previously_evaluated
    before={r["id"]:previously_evaluated(r,orig["dose"])for r in orig["rows"]["wire"]}
    for row in final:
        b=before[row["id"]]
        assert row["input"]==b["input"] and row["parent_output"]==b["parent_output"]
        for key in ("intact_rms","gap_exact","flat_rms"):
            current=row["metrics"]["wide"][key]
            prior_value=b["metrics"]["scale64"][key]
            if current is not None:
                assert abs(current-prior_value)<.003,(row["id"],key,current,prior_value)
    cohorts={p:[r for r in final if r["profile"]==p]for p in ("iso400","iso6400")}
    pairs=[(a,b)for a in ARMS[1:]for b in ("wide",a+"-uniform")]
    pairs += [("checked",b)for b in ("mean","flipped","unchecked","zero","ring8")]
    write_json(ROOT/"wire.json",binding|{"driver":reference(__file__),"operator":reference(ROOT/"envelope.py"),
        "inputs":orig["inputs"],"prior":prior,"uniform_doses":matching,"dose":dose,
        "rows":final,"calibration":tables["wire-tune"],
        "reports":numeric(cohorts,pairs,("intact_response",*RMS_FIELDS)),"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
