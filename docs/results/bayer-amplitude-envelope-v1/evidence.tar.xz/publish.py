"""Bind the inference study, package replay and viewed native images."""
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
OUT=Path("docs/results")/ROOT.name
IMAGES=Path("docs/images")/ROOT.name


def copy_board(item,scope):
    held=checked(item["image"])
    destination=IMAGES/scope/held.name
    destination.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(held,destination)
    assert reference(destination)["sha256"]==item["image"]["sha256"]
    item["image"]["path"]=destination.relative_to(IMAGES).as_posix()
    pieces={}
    with Image.open(destination) as image:
        for panel in item["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and x+w<=image.width and y+h<=image.height
            pieces[panel.get("label") or panel["name"]]=image.crop((x,y,x+w,y+h))
    assert len(pieces)==len(item["panels"])
    return pieces


def images(checkpoint,calibration):
    result={}
    for scope,count in (("exact",3),("low-iso",2),("standing",8)):
        note=read_json(ROOT/scope/"manifest.json")
        assert len(note["rows"])==count and note["checkpoint"]==checkpoint and note["scale_calibration"]==calibration
        checked(note["driver"])
        for row in note["rows"]:
            panels=copy_board(row["board"],scope)
            if scope=="standing":
                base=np.asarray(panels["64-pixel carrier fit"],dtype=np.int16)
                row["changed_display_codes"]={k:int(np.count_nonzero(np.asarray(panels[k],dtype=np.int16)-base))
                    for k in ("Green envelope","All-color envelope","Unchecked envelope")}
            else:
                for held in (row["triplet"],*row.get("other_triplets",{}).values()):
                    slots=copy_board(held,scope)
                    assert len(slots)==3
                    assert all(ImageChops.difference(panels[label],crop).getbbox() is None for label,crop in slots.items())
        result[scope]=note
    result["actual_viewing"]={"exact":5,"standing":8,
       "notes":"The two checked envelopes look close to the existing fit. Both fine cab wire directions remain visible. Narrow crossings are incomplete, and some areas stay mottled or look overly regular. The unchecked version can noticeably reduce contrast. ISO400 gap changes are faint at native scale."}
    path=IMAGES/"manifest.json"
    write_json(path,result)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":reference(path)["sha256"]}


def main():
    OUT.mkdir(exist_ok=True)
    sources={name:reference(ROOT/(name+".json"))for name in ("wire","pooled","port")}
    checked_rows={k:read_json(checked(link))for k,link in sources.items()}
    wire,pooled,port=(checked_rows[k]for k in sources)
    for record in checked_rows.values():
        checked(record["driver"])
        assert record["checkpoint"]==wire["checkpoint"]
    checked(port["package"])
    variants=[cell for row in port["exact"]for cell in row["variants"]]
    real=[row["fit_matches"]for row in port["standing"]]
    assert len(variants)==192 and len(real)==8 and all(p["bit_identical"]for p in variants+real)
    for d in (wire,pooled):
        assert len(d["rows"])==48 and len(d["calibration"])==24
        for row in d["rows"]+d["calibration"]:
            checked(row["input"])
            checked(row["parent_output"])
    views=images(wire["checkpoint"],wire["scale_calibration"])
    rootfiles=("envelope.py","screen.py","pooled.py","render_envelope.py","envelope_boards.py","low_iso.py",
               "port_review.py","port_review_final.py","publish.py","wire.log","pooled.log","port.log",
               "port-final.log","tests.log","exact.log","standing.log","low-iso.log",
               "exact/manifest.json","standing/manifest.json","low-iso/manifest.json")
    files={k:ROOT/k for k in rootfiles}
    files|={f"{k}.json":checked(v)for k,v in sources.items()}
    files["package/mesh_carrier_fit.py"]=checked(port["package"])
    path=OUT/"evidence.tar.xz"
    with tarfile.open(path,"x:xz",preset=4)as archive:
        for label,source in sorted(files.items()):
            archive.add(source,arcname=label,recursive=False)
    with tarfile.open(path)as archive:
        assert archive.getnames()==sorted(files)
        for label,source in files.items():
            with archive.extractfile(label)as contents:
                assert contents.read()==source.read_bytes()
    shutil.copyfile(checked(sources["port"]),OUT/"package-parity.json")
    write_json(OUT/"publication.json",{
        "source_receipts":sources,"checkpoint":wire["checkpoint"],"base_parent":wire["parent"],
        "scale_calibration":wire["scale_calibration"],"native_review":views,"learned_weights":False,
        "archive":{"path":path.name,"sha256":reference(path)["sha256"],"entries":len(files)},
        "port":{"source":port["package"],"variants_bit_identical":len(variants),"standing_bit_identical":len(real),
                "report":"package-parity.json","sha256":reference(OUT/"package-parity.json")["sha256"]},
        "scope":"Scoped 64-pixel inference and localization study. The package implements the established unmodulated fit.",
        "green":{k:d["contrasts"]for k,d in wire["reports"].items()},
        "pooled":{k:d["contrasts"]for k,d in pooled["reports"].items()},
    })


if __name__=="__main__":
    main()
