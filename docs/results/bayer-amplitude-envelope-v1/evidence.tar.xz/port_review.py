"""Verify the package port on the actual frozen fit and on both GFX scenes."""
from functools import partial
import time

import numpy as np

from envelope import ROOT, OLDER, ROI, geometry, review, prior_setup
from apply_scale import render_models as reference_render
from restore import correction, compose
from benchmark import GATE
from review_quiet import LOCAL, SCENE, wire_inputs
from review_gate import PRIOR
from native_quiet import raw_full, original_panels
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def read(path):
    return read_json(checked(reference(path)))


def apply(parent,scene,layout,noise,box,roi,wb,matrix):
    x,y,w,h=roi
    selected=np.s_[..., y:y+h,x:x+w]
    coordinates=(box[0]+x,box[1]+y,w,h)
    return refine_raw_mesh_carriers(parent[selected],scene,layout,coordinates,
            shot=noise["shot"],read=noise["read"],white_balance=wb,camera_to_srgb=matrix)


def compares(candidate,control):
    assert candidate.dtype==control.dtype
    d=candidate.astype(np.float64)-control
    variation=float(abs(d).max())
    assert variation < 1e-7
    return {"max_linear_RGB_difference":variation,"bit_identical":bool(np.array_equal(candidate,control))}


def standing(models,dose):
    gates=read(ROOT.parent/"bayer-distant-phase-gate-v1"/"standing/manifest.json")
    original=read(OLDER/"standing/manifest.json")
    by_id={r["id"]:r for r in original["rows"]}
    book=read(SCENE/"review-native-020000/work/render/result.json")
    recorded=read_json(checked(book["collections"]["none"]))
    plan=read_json(checked(book["plan"]))
    observations={r["id"]:r for r in plan["observations"]}
    rows={r["id"]:r for r in recorded["records"]}
    views=[]
    for group in ("main","mesh"):
        chosen=[row for row in gates["rows"] if row["id"].startswith(group+"-")]
        scene,layout=raw_full(chosen[0]["raw"])
        for row in chosen:
            name=row["id"]
            spec=next(r for r in book["boards"]if r["id"]==name)
            rec=observations[spec["observation"]]
            local=rows[spec["observation"]]
            if group=="main":
                origin=rec["metadata"]["context_xywh"][:2]
            else:
                origin=read_json("configs/gfx-green-mesh-20231231.json")["raw_context_xywh"][:2]
            x,y,w,h=row["native_box"]
            i,j=x-origin[0],y-origin[1]
            with np.load(checked(rec["arrays"]),allow_pickle=False) as arr:
                wb,matrix=arr["wb"][0],arr["matrix"][0]
                noisy=arr["packed"][0,:,j//2:j//2+128,i//2:i//2+128]
            np.testing.assert_array_equal(noisy,scene[:,y//2:y//2+128,x//2:x//2+128])
            prior=np.load(checked(local["prediction"]),allow_pickle=False)[0,:,j:j+256,i:i+256]
            box=row["native_box"]
            roi=row["roi"]
            ref=reference_render(noisy,layout,wb,matrix,row["noise"],box,scene,prior,(models,dose),roi)
            estimate=apply(ref["distant"],scene,layout,row["noise"],box,roi,wb,matrix)
            rx,ry,rw,rh=roi
            expected=ref["scale64"][:,ry:ry+rh,rx:rx+rw]
            assert by_id[name]["input"]==row["input"]
            views.append({"id":name,"input":row["input"],"raw":row["raw"],"parent_output":local["prediction"],
                         "box":box,"roi":roi,"noise":row["noise"],"fit_matches":compares(estimate,expected)})
        del scene
    return views


def exact(case,plan,lookup,models,dose):
    inputs,parents,proof=wire_inputs(case,lookup,None)
    scene=inputs["full"]
    box=plan["query"]
    noise=plan["profiles"][case["noise"]]
    layout,wb,matrix=(inputs[k][0]for k in ("colors","wb","matrix"))
    surrounding=review.exterior(scene,layout,noise,box)
    spacing,ok,_=geometry(scene,layout,box,ROI)
    x,y,_,_=box
    rows=[]
    # Each role has a distinct query RAW realization. Preserve its exterior
    # bank and replace only the native 256-pixel query inside the public scene.
    for raw,parent in zip(inputs["packed"],parents[LOCAL],strict=True):
        frozen=compose(raw,layout,wb,matrix,noise,box,surrounding,parent,models,False)["distant"]
        old,_=correction(raw,frozen,layout,wb,matrix,noise,spacing,ROI,64,GATE,ok)
        prior=(frozen+np.float32(dose["scale64"])*old)[:,48:208,48:208]
        frame=scene.copy()
        frame[:,y//2:y//2+128,x//2:x//2+128]=raw
        result=apply(frozen,frame,layout,noise,box,ROI,wb,matrix)
        rows.append(compares(result,prior))
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"input":case["input"],"parent_output":proof,
            "variants":rows}


if __name__=="__main__":
    start=time.monotonic()
    (model,dose),stamp=prior_setup()
    wire=reference(PRIOR/"wire-parent.json")
    manifest=read_json(checked(wire))
    plan=read_json(checked(manifest["plan"]))
    rows=read_json(checked(manifest["inputs"]))["rows"]
    cases=review.run(rows,partial(exact,plan=plan,lookup={r["id"]:r for r in manifest["rows"]},models=model,dose=dose))
    media=standing(model,dose)
    assert len(cases)==48 and len(media)==8
    write_json(ROOT/"port.json",stamp | {"driver":reference(__file__),"package":reference("src/demosaic/mesh_carrier_fit.py"),
        "exact":cases,"wire_inputs":wire,"standing":media,"runtime_s":time.monotonic()-start})
