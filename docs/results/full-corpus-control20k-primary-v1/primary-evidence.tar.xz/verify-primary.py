"""Verify closure receipts and reproduce the source-balanced Corpus20k score."""

from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = Path.cwd()
WORK = ROOT.parent / "full-corpus-control20k-review-queue-v1/primary20k"
DEST = REPO / "docs/results/full-corpus-control20k-primary-v1"
CAMERA = REPO / "docs/results/full-corpus-control20k-camera-v1/summary.json"
METRICS = ("srgb_psnr", "linear_psnr")


def main():
    result_path = WORK / "collection/result.json"
    full = read_json(result_path)
    assert full["all_complete"] and full["kind"] == "full" and full["cases"] == 3162
    assert full["full_model_before"] == full["full_model_after"] and full["CPU_rng_unchanged"]
    assert full["counts"]["root"] == 6324
    assert full["counts"]["local_DINO_executions"] == full["counts"]["local_DINO_replays"] == 3162
    assert all(row["all_output_values_bitexact"] and row["all_metric_rows_bitexact"]
               for row in full["parent_reference_checks"])
    keys = ["V120", "scale-control20k"]
    plan_path = checked(full["plan"])
    plan = read_json(plan_path)
    native_path = checked(plan["canonical_inputs"])
    native = read_json(native_path)
    canonical = {(r["stage"], r["batch"]):r for r in native["records"]}
    assert native["all_input_witnesses_exact"] and len(canonical) == 3162
    assert plan["models"] == full["models"]
    cam = read_json(CAMERA)
    for arm in keys:
        assert full["models"][arm]["checkpoint"] == cam["models"][arm]["checkpoint"]
        assert full["models"][arm]["weights"] == "EMA"
        assert full["models"][arm]["step"] == 20000
    rows, observed, per_source = {}, Counter(), defaultdict(dict)
    for bound in full["case_records"]:
        case = read_json(checked(bound))
        stage, batch = case["stage"], case["batch"]
        entry = canonical[stage, batch]
        assert case["canonical_arrays"] == entry["arrays"]
        assert set(case["input_fingerprints"]) == {"packed", "variance", "colors", "wb", "matrix"}
        assert case["input_fingerprints"] == {k:entry["fingerprints"][k] for k in case["input_fingerprints"]}
        observed[stage] += 1
        assert set(v["arm"] for v in case["variants"]) == set(keys)
        for v in case["variants"]:
            arm = v["arm"]
            assert v["checkpoint"] == full["models"][arm]["checkpoint"] and v["weights"] == "EMA"
            if stage != "photo":
                continue
            for r in v["rows"]:
                if r["kind"] != "photo":
                    continue
                assert r["model"] == arm
                key = (r["id"], r["condition"], r["pattern"], arm)
                assert key not in rows
                rows[key] = r["metrics"]
                per_source[r["id"]][r["condition"], r["pattern"], arm] = r["metrics"]
    assert observed == {"photo": 3108, "known": 24, "unseen": 30}
    assert len(rows) == 2 * 427 * 28 and len(per_source) == 427
    recipes = {(case, pattern) for _, case, pattern, _ in rows}
    assert len(recipes) == 28 and len({nc for nc, _ in recipes}) == 7 and len({cfa for _, cfa in recipes}) == 4
    scores = {}
    for key, items in sorted(per_source.items()):
        assert set(items) == {(case, pattern, a) for case, pattern in recipes for a in keys}
        scores[key] = {
            arm:{m: mean(items[*recipe, arm][m] for recipe in recipes) for m in METRICS}
            for arm in keys
        }
    overall = {a:{m:mean(r[a][m] for r in scores.values()) for m in METRICS} for a in keys}
    for r in full["summaries"]["photo"]["overall"]:
        if r["kind"] == "photo":
            for metric in METRICS:
                assert r["metrics"][metric]["count"] == 427
                assert abs(r["metrics"][metric]["mean"] - overall[r["model"]][metric]) < 1e-11
    for stage, n in (("known",4),("unseen",5)):
        for r in full["summaries"][stage]["overall"]:
            assert r["metrics"]["sensor_psnr"]["count"] == n
            assert r["metrics"]["sensor_psnr"]["mean"] == cam["measured_CFA_PSNR"][stage][r["model"]]
    conditions = {}
    for name in sorted({nc for nc, _ in recipes}):
        values = {
            arm: mean(v["srgb_psnr"] for (_, c, _, a), v in rows.items() if (c, a) == (name, arm))
            for arm in keys
        }
        conditions[name] = values | {"gain": values[keys[1]] - values[keys[0]]}
    DEST.mkdir(exist_ok=True)
    archive = DEST / "primary-evidence.tar.xz"
    members = {"collector-result.json":result_path,"primary-plan.json":plan_path,
               "canonical-input-index.json":native_path,"verify-primary.py":Path(__file__)}
    with tarfile.open(archive,"x:xz") as bundle:
        for name, path in members.items():
            bundle.add(path, arcname=name)
    def rel(path):
        return reference(path) | {"path": str(path.relative_to(REPO))}
    write_json(DEST / "primary.json", {
        "all_complete": True, "photo_sources": len(scores), "noise_conditions": 7, "CFAs": 4,
        "case_receipts_verified": full["cases"], "batches": dict(observed), "observations_per_model": len(rows)//2,
        "models": full["models"], "source_result": reference(result_path), "canonical_inputs": reference(native_path),
        "archive": rel(archive), "archive_member_sha256": {k:reference(v)["sha256"] for k,v in members.items()},
        "source_balanced": overall,
        "collector_photo_overall": [r for r in full["summaries"]["photo"]["overall"] if r["kind"]=="photo"],
        "paired_photo_differences": full["summaries"]["photo"]["paired_comparisons"][:3],
        "per_condition_srgb_PSNR": conditions,
        "camera_summary": rel(CAMERA),
        "known_unseen_camera_PSNR": cam["measured_CFA_PSNR"],
        "source_averages": scores,
        "photographic_sources_improved": sum(v[keys[1]]["srgb_psnr"] > v[keys[0]]["srgb_psnr"] for v in scores.values()),
        "collection_seconds": full["seconds"],
        "scope": "Verified fixed CPU IEEE FP32 canonical closure, all case and checkpoint bindings, and independent recombination of retained photometric metric rows. Exact previously published camera aggregates. A separate NumPy pixel audit and weak-band analysis process reads the saved predictions.",
    })


if __name__ == "__main__":
    main()
