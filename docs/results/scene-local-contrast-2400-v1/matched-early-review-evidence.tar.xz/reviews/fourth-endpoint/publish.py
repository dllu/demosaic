"""Bind the selected native evidence after viewing, preserving original receipts."""
from pathlib import Path
import shutil

from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
RUN = HERE.parents[1]
REPO = RUN.parents[2]
RESULTS = REPO/"docs/results/scene-local-contrast-2400-v1"
IMAGES = REPO/"docs/images/scene-local-contrast-2400-matched"

def relative(path):
    return reference(path)|{"path":str(path.relative_to(REPO))}

def native(receipt):
    source = checked(receipt["image"])
    dest = IMAGES/source.name
    shutil.copyfile(source,dest)
    published = relative(dest)
    assert published["sha256"] == receipt["image"]["sha256"]
    with Image.open(dest) as png:
        for panel in receipt["panels"]:
            x,y,w,h = panel["png_xywh"]
            assert (w,h)==(160,160) and x+w<=png.width and y+h<=png.height
        png.verify()
    return {**receipt,"image":published}

def publish():
    IMAGES.mkdir(exist_ok=True)
    notes = read_json(HERE/"viewing-notes.json")
    training = read_json(RUN/"matched-training.json")["endpoints"]
    early_path = HERE/"early.json"
    early = read_json(early_path)
    assert early["retained_cases"]==32
    heldout_views = []
    for row in early["native"]:
        heldout_views.append({
            **row,"checkpoint":training["localized-none"]["checkpoint"],"weights":"EMA",
            "actual_native_viewing":notes["heldout"][row["id"]],
            "board":native(row["board"]),"triplet":native(row["triplet"]),
        })
    assert len(heldout_views)==3
    write_json(RESULTS/"matched-early-native-viewing.json",{
        "early":reference(early_path),"scope":"Three 100% native synthetic views from the initial eight-source matched replay.",
        "views":heldout_views})
    report = HERE.parent/"standing/render/result.json"
    standing = read_json(report)
    checkpoints = {k:read_json(checked(v))["checkpoint"] for k,v in standing["collections"].items()}
    for k,v in training.items():
        assert checkpoints[k]==v["checkpoint"]
    boards = [{**native(row),"actual_native_viewing":notes["GFX"][row["id"]]}
              for row in standing["boards"] if not row["observation"].startswith("development")]
    assert len(boards)==8
    write_json(RESULTS/"matched-standing-viewing.json",{
        "render":reference(report),"checkpoints":checkpoints,"native_boards_viewed":len(boards),
        "boards":boards,"captures":{"main":["DSCF3879","DSCF3880"],"cab":["DSCF3842","DSCF3835"]},
        "reference_scope":"Independent ISO100 AHD and camera JPEGs are qualitative references.",
    })
    shutil.copyfile(early_path,RESULTS/"matched-early-heldout.json")
    shutil.copyfile(HERE/"standing-deltas.json",RESULTS/"matched-standing-deltas.json")

if __name__=="__main__":
    publish()
