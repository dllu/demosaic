"""Reuse the first eight groups of the complete matched collector, without neural replay."""

from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from measure import CFA_ARGS, parts, reduce

FULL=ROOT/"evaluation"
NAMES={
    "V120":"V120 EMA", "100k":"Corpus 100k EMA", "plain-none":"Plain local EMA",
    "plain-spatial/matching":"Plain spatial EMA", "localized-spatial/matching":"Localized spatial EMA",
    "localized-none":"Localized local EMA",
}
REPLAY=("000-iso6400-coupled", "001-iso6400-coupled")


def collect():
    owner = read_json(HERE.parent/"heldout/queue-launch.json")
    folder = HERE/"native"
    folder.mkdir()
    preceding = read_json(HERE.parent/"third-endpoint/heldout-results.json")
    preceding_metrics = {(r["source"],r["profile"],r["draw"]):r for r in preceding["source_metrics"]}
    keys = sorted({str(Path(r["case"]["path"]).stem) for r in preceding["source_metrics"]})
    receipts = [FULL/"predictions"/(key+".json") for key in keys]
    assert len(receipts) == 32
    while missing := [p for p in receipts if not p.is_file()]:
        if not owner_live(owner):
            raise RuntimeError(f"Held-out collection exited with {len(missing)} missing initial receipts")
        time.sleep(5)
    run = reference(FULL/"plan.json")
    plan = read_json(checked(run))
    spec = read_json(checked(plan["panel"]))
    rows, views = [], []
    for path in receipts:
        binding = reference(path)
        record = read_json(checked(binding))
        case = read_json(checked(record["case"]))
        key = (case["source"],case["profile"]["name"],case["draw"])
        previous = preceding_metrics[key]
        previous_prediction = read_json(checked(previous["prediction_receipt"]))
        assert record["plan"]==run and record["case"]==previous["case"]
        assert record["exact_query_inputs"]==previous_prediction["exact_query_inputs"]
        assert record["views"]==previous_prediction["views"]
        with np.load(checked(case["input"]),allow_pickle=False) as archive:
            arrays={k:archive[k] for k in (*CFA_ARGS,"target")}
        with np.load(checked(record["saved"]),allow_pickle=False) as archive:
            predictions={k:archive[k.replace("/","--")] for k in record["inference_variants"]}
        fields={k:np.broadcast_to(arrays[k][None],(3,*arrays[k].shape)) for k in ("wb","matrix")}
        fields["exposure"]=case["profile"]["exposure"]
        metric={k:parts(fields,v,arrays["target"],spec) for k,v in predictions.items()}
        rows.append({"source":key[0],"profile":key[1],"draw":key[2],
                     "prediction_receipt":binding,"metrics":metric})
        if case["id"] in REPLAY:
            for role in ((0,2) if case["id"]==REPLAY[0] else (0,)):
                args={k:arrays[k][role:role+1] if k in ("packed","variance") else arrays[k][None]
                      for k in CFA_ARGS}
                source=spec["rows"][case["case"]]
                views.append(native_board(
                    folder,case["id"]+f"-role{role}",[noisy_malvar(args)[0],
                     *[predictions[k][role] for k in NAMES],arrays["target"][role]],args,
                    {"source":source["source"],"query_box":case["box"],"profile":case["profile"],
                     "CFA":source["camera"]["pattern"],"draw":case["draw"],"role":spec["roles"][role],
                     "plan":run,"prediction_receipt":binding},
                    labels=("Noisy Malvar",*NAMES.values(),"Exact GT"),
                    triplet_indices=(0,6,7),exposure=1/fields["exposure"],contrast=2,
                    roi=tuple(spec["native_display_ROI_xywh"])))
    assert len(views)==3
    write_json(HERE/"early.json",{"driver":reference(__file__),"plan":run,"retained_cases":len(rows),
               "metrics":reduce(rows),"source_metrics":rows,"native":views,
               "scope":"Eight fixed sources from the full matched collector. All profiles and both draws. Equal query and preview fingerprints verified against the original pilot."})

if __name__=="__main__":
    collect()
