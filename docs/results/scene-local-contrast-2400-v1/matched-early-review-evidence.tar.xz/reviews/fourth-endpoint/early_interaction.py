"""Read the paired spatial-by-recipe contrast on the first eight photos."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import read_json, reference, write_json

HERE = Path(__file__).resolve().parent
EARLY = HERE/"early.json"
ARM_PAIRS = (("localized-spatial/matching","localized-none"),("plain-spatial/matching","plain-none"))
FIELDS = ("increment_RMS_DN16","quiet_RMS_DN16")

def main():
    rows = read_json(EARLY)["source_metrics"]
    rng = np.random.default_rng(2400)
    measured = []
    for profile in ("iso400","iso6400"):
        for draw in ("coupled","independent"):
            group = [v for v in rows if (v["profile"],v["draw"]) == (profile,draw)]
            assert len({v["source"] for v in group}) == len(group) == 8
            sample = rng.integers(len(group),size=(10000,len(group)))
            def arm(label,field):
                return np.array([row["metrics"][label]["band"]["fine"][field] for row in group])
            for field in FIELDS:
                local,ordinary = (arm(left,field)-arm(right,field) for left,right in ARM_PAIRS)
                interaction = local-ordinary
                def summarize(values):
                    return {"mean":float(values.mean()),
                            "interval_95":np.quantile(values[sample].mean(1),[.025,.975]).tolist()}
                measured.append({"field":field,"profile":profile,"draw":draw,
                                 "localized_spatial_minus_local":summarize(local),
                                 "plain_spatial_minus_local":summarize(ordinary),
                                 "interaction":summarize(interaction)})
    write_json(HERE/"early-interaction.json",{"driver":reference(__file__),"data":reference(EARLY),
        "scope":"Exploratory source-paired contrast restricted to the first eight held-out sources.",
        "seed":2400,"resamples":10000,"contrasts":measured})

if __name__=="__main__":
    main()
