"""Bind the three completed arms and publish the ordinary-data spatial checkpoint."""

import json
from pathlib import Path
import shutil

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
RUN = HERE.parents[1]
REPO = RUN.parents[2]
DEST = REPO / "docs/results/scene-local-contrast-2400-v1"
IMAGES = REPO / "docs/images/scene-local-contrast-2400-third"
IMAGES.mkdir(exist_ok=True)
HELDOUT = HERE / "heldout-results.json"

def published(path):
    return reference(path) | {"path": str(path.relative_to(REPO))}

def copy(source, name):
    return shutil.copyfile(source, DEST / name)

def save_json(name, data):
    write_json(DEST / (name + ".json"), data)

def native_image(receipt):
    source = checked(receipt["image"])
    path = IMAGES / source.name
    shutil.copyfile(source, path)
    stored = published(path)
    assert stored["sha256"] == receipt["image"]["sha256"]
    with Image.open(path) as opened:
        for panel in receipt["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160) and x+w <= opened.width and y+h <= opened.height
        opened.verify()
    return {**receipt, "image": stored}

def input_comparison():
    left, right = (RUN / f"plain-{arm}-verified.json" for arm in ("none", "spatial"))
    local, spatial = (read_json(p) for p in (left, right))
    assert local["observations"]["sha256"] == spatial["observations"]["sha256"]
    traces = [checked(run["observations"]) for run in (local, spatial)]
    raw = traces[0].read_bytes()
    assert raw == traces[1].read_bytes()
    records = [json.loads(row) for row in raw.splitlines()]
    assert len({row["source_id"] for row in records}) == len(records) == 4800
    assert sum(len(row["boxes_xywh"]) for row in records) == 19200
    assert read_json(checked(local["completed"]))["plan"] == read_json(checked(spatial["completed"]))["plan"]
    save_json("plain-matched-inputs", {"plain_local":reference(left),"plain_spatial":reference(right),
        "whole_scene_and_crop_records_byte_identical":len(records),
        "distinct_source_count":len(records),"native_crop_count":19200,
        "shared_data_plan":read_json(checked(spatial["completed"]))["plan"]})

def paired():
    source_metrics = read_json(HELDOUT)["source_metrics"]
    rng = np.random.default_rng(2400)
    rows = []
    for prior in ("iso400", "iso6400"):
        for draw in ("coupled", "independent"):
            views = [v for v in source_metrics if (v["profile"],v["draw"]) == (prior,draw)]
            assert len(views) == len({v["source"] for v in views}) == 8
            samples = rng.integers(8, size=(10000, 8))
            for left,right in (
                ("plain-spatial2400/matching","plain-local2400"),
                ("plain-spatial2400/matching","plain-spatial2400/neutral"),
                ("plain-spatial2400/matching","plain-spatial2400/blur-distant"),
                ("plain-spatial2400/matching","plain-spatial2400/wrong-distant"),
                ("plain-spatial2400/matching","100k"),
                ("plain-spatial2400/matching","V120"),
            ):
                a,b = (np.asarray([[v["metrics"][key]["band"]["fine"][field] for field in (
                    "increment_RMS_DN16","quiet_RMS_DN16","aligned_increment_dot","exact_paired_increment_sq")]
                    for v in views]) for key in (left,right))
                np.testing.assert_array_equal(a[:,3], b[:,3])
                results = (a-b)[samples].mean(axis=1)
                mean = (a-b).mean(axis=0)
                resp = 100*results[:,2]/a[samples,3].mean(axis=1).clip(1e-20)
                ci = lambda values: np.quantile(values, [.025,.975]).tolist()
                rows.append({"prior":prior,"draw":draw,"pair":[left,right],
                    "increment_RMS_DN16":{"mean":mean[0],"interval_95":ci(results[:,0])},
                    "flat_RMS_DN16":{"mean":mean[1],"interval_95":ci(results[:,1])},
                    "signed_response_percentage_point":{"mean":100*mean[2]/a[:,3].mean(),"interval_95":ci(resp)}})
    save_json("third-endpoint-paired",{"heldout_results":reference(HELDOUT),"seed":2400,
                "resamples":10000,"unit":"whole photo","scope":"Exploratory eight-photo replay.", "pairs":rows})

heldout_notes = [
    "The stone edge and near-black surround stay intact. Inner stone grain remains softer than exact GT and looks close to plain local.",
    "Fine bright masonry and the separation around red/orange balcony edges are soft. Matching scene context has no clear visible advantage over plain local.",
    "The exact flat center still appears smooth with a soft skirt. None of the new models reconstructs obvious new texture in the center.",
]
standing_notes = {
    "main-overcast-sky": "All models keep the overcast center smooth at identical display exposure.",
    "main-building-detail": "Major cables and truss openings remain. The smaller brackets and cables stay soft without new conspicuous color fringes.",
    "main-foliage": "Main leaf clusters and dark gaps remain separated. Small leaf tips and edges stay soft.",
    "main-chain-link-fence": "Both coarse wire directions and repeated crossings remain visible. Fine interruptions along the lower boundary remain soft.",
    "mesh-nominal-fine-green-mesh-left": "Little coherent fine mesh beside the post. Residual broad blue-green variation persists.",
    "mesh-nominal-fine-green-mesh-right": "Most fine crossings remain unresolved against the gray green background. The diagonal bars and patches look close to plain local.",
    "mesh-profile3879-fine-green-mesh-left": "There are faint short crossing-like segments near the lower edge and post. The full lattice in the neighboring reference is still incomplete.",
    "mesh-profile3879-fine-green-mesh-right": "Both directions are more visible with the transferred prior. The crossings remain much softer and more broken than the qualitative reference.",
}

def views():
    raw = read_json(HERE/"heldout-native/views.json")
    assert [row["id"] for row in raw["views"]] == [
        "000-iso6400-coupled-role0","001-iso6400-coupled-role0","000-iso6400-coupled-role2"]
    report = [{**row,"actual_native_viewing":note,
        **{key:native_image(row[key]) for key in ("board","triplet")}}
        for row,note in zip(raw["views"],heldout_notes,strict=True)]
    save_json("third-endpoint-heldout-viewing",{**raw,"views":report,
              "native_boards_viewed":3,"native_triplets_viewed":3})
    result = read_json(HERE/"render/result.json")
    standing = []
    for row in result["boards"]:
        if row["observation"].startswith("development"):
            continue
        key = row["id"] if row["observation"].startswith("mesh") else row["observation"]
        standing.append({**native_image(row),"actual_native_viewing":standing_notes[key]})
    assert len(standing) == len(standing_notes)
    save_json("third-endpoint-standing-viewing",{"render":reference(HERE/"render/result.json"),
              "native_boards_viewed":len(standing),"records":standing,
              "collections":result["collections"],"checkpoints":{
                  k:read_json(checked(v))["checkpoint"] for k,v in result["collections"].items()},
              "reference":"Independent ISO100 AHD and camera JPEGs are qualitative references."})

def main():
    input_comparison()
    paired()
    views()
    copy(RUN/"plain-spatial-verified.json","plain-spatial-verified.json")
    copy(HERE/"heldout-plan.json","third-endpoint-heldout-plan.json")
    copy(HELDOUT,"third-endpoint-heldout.json")
    copy(HERE/"standing-deltas.json","third-endpoint-standing-deltas.json")
    copy(RUN/"reviews/standing/plain/spatial/collection.json","third-endpoint-standing-collection.json")

if __name__ == "__main__":
    main()
