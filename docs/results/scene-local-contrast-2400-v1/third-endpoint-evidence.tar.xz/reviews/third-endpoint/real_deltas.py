"""Measure same-input output changes on native standing crops."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RENDER = ROOT / "render/result.json"


def reduce():
    rendered = read_json(RENDER)
    table = {}
    for label, binding in rendered["collections"].items():
        collection = read_json(checked(binding))
        checkpoints = collection["checkpoint"]
        records = {row["id"]: row for row in collection["records"]}
        table[label] = {"checkpoint": checkpoints, "records": records}
    comparison = []
    for board in rendered["boards"]:
        name = board["observation"]
        if name.startswith("development-"):
            continue
        assert board["case"]["crop_index"] == 0
        x, y, width, height = board["case"]["ROI_xywh"]
        assert (width, height) == (160, 160)
        parents = {}
        for label, arm in table.items():
            row = arm["records"][name]
            prediction = np.load(checked(row["prediction"]),allow_pickle=False)
            parents[label] = prediction[0,:,y:y+height,x:x+width].astype(np.float64)
        newest = parents.pop("plain-spatial")
        def rms(values):
            return float(65535*np.sqrt(np.mean(values**2)))
        measurements = {}
        for label, prediction in parents.items():
            residual = newest - prediction
            measurements[label] = {
                "paired_model_output_RMS_DN16":rms(residual),
                "chroma_channel_mean_delta_DN16":(65535*residual.mean(axis=(1,2))).tolist(),
                "paired_model_output_centered_RMS_DN16":rms(residual-residual.mean(axis=(1,2),keepdims=True)),
            }
        comparison.append({"board":board["id"],"case":board["case"],"noise":board["noise"],
                           "display_exposure":board["display_exposure"], "changes":measurements})
    assert len(comparison) == 8
    write_json(ROOT/"standing-deltas.json",{
        "renderer":reference(RENDER),"driver":reference(__file__),
        "results":comparison,
        "scope":"Differences among exactly matched float32 predictions. ISO100 and camera JPEG references are qualitative comparators.",
    })


if __name__ == "__main__":
    reduce()
