"""Render the first endpoint once its checkpoint-bound native collection closes."""

from pathlib import Path
import subprocess
import sys
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

HERE = Path(__file__).resolve().parent


def main():
    declaration = read_json(HERE/"pending.json")
    standing = read_json(HERE.parent/"standing/localized-spatial-launch.json")
    product = Path(declaration["localized-spatial_reservation"])
    with exclusive_run(HERE):
        while not product.is_file():
            if not owner_live(standing) and not product.is_file():
                raise RuntimeError("Native collector exited without its bound completed receipt")
            time.sleep(5)
        trained, collected = (read_json(p) for p in (checked(declaration["training"]), product))
        assert trained["checkpoint"] == collected["checkpoint"] and len(collected["records"]) == 10
        write_json(HERE/"collection.json", {
            "training":declaration["training"], "V120":declaration["V120"], "parent":declaration["parent"],
            "epochs":{"earlier-spatial12k":declaration["earlier-spatial12k"],"localized-spatial":reference(product)},
        })
        subprocess.run([sys.executable,checked(declaration["driver"])],check=True)
        assert len(read_json(HERE/"render/result.json")["boards"])==16


if __name__=="__main__":
    main()
