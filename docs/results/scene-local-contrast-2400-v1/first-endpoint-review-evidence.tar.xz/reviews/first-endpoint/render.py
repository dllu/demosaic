"""Compare both expanded scene endpoints with V120 and their matched 100k parent."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

from demosaic.cfa import malvar
from demosaic.color import linear_to_srgb, srgb_to_linear
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop, save_triplet

torch.set_num_threads(2)
root=Path(__file__).resolve().parent
plan_path=root.parent/'standing/localized/plan.json';plan=read_json(plan_path)
closed=read_json(root/'collection.json')
training=read_json(checked(closed['training']))
assert training['steps']==2400 and training['distinct_scenes']==4800
collection_links={'V120':closed['V120'], 'parent100k':closed['parent'], **closed['epochs']}
collections={k:read_json(checked(v)) for k,v in collection_links.items()}
assert collections['localized-spatial']['plan']==reference(plan_path)
assert collections['localized-spatial']['checkpoint']==training['checkpoint']
rows={arm:{r['id']:r for r in collection['records']} for arm,collection in collections.items()}
labels={'V120':'V120 EMA','parent100k':'Parent 100k EMA','earlier-spatial12k':'Spatial 12k EMA','localized-spatial':'Localized spatial EMA'}
output=root/'render';output.mkdir()
boards,triplets=[],[]

def pixels(value):
    assert value.shape==(160,160,3) and np.isfinite(value).all()
    return np.rint(value.clip(0,1)*255).astype(np.uint8)

for observation in plan['observations']:
    identity=observation['id']
    assert all(rows[arm][identity]['input_fingerprints']==rows['V120'][identity]['input_fingerprints'] for arm in rows)
    predictions={arm:torch.from_numpy(np.load(checked(table[identity]['prediction']),allow_pickle=False))for arm,table in rows.items()}
    with np.load(checked(observation['arrays']),allow_pickle=False)as data:
        arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
    development=observation['kind']=='development';prefix='crop_'if development else''
    wb,matrix,packed,colors=[arrays[prefix+k]for k in ['wb','matrix','packed','colors']]
    noisy=malvar(packed,colors,wb);exposure=observation['display_exposure']
    if development:
        cases=[{'name':f'crop{i}','ROI_xywh':observation['ROI_xywh'],'crop_index':i}for i in [0,1]]
    elif observation['kind']=='gfx':cases=[{'name':identity,'ROI_xywh':observation['ROI_xywh'],'crop_index':0}]
    else:cases=[{**c,'crop_index':0}for c in observation['cases']]
    for case in cases:
        index=case['crop_index'];roi=case['ROI_xywh'];balance=wb[index:index+1];matrix1=matrix[index:index+1]
        def display(value,box=roi):return display_crop(value[index:index+1],balance,matrix1,box,exposure=exposure)
        noisy_display=display(noisy)
        rendered={arm:display(prediction)for arm,prediction in predictions.items()}
        if development:
            reference_display=display(arrays['crop_target']);reference_label='Exact GT'
        elif observation['kind']=='gfx':
            reference_rgb=torch.from_numpy(np.load(checked(observation['target']),allow_pickle=False))
            reference_display=display_crop(reference_rgb,balance,matrix1,[0,0,160,160],exposure=exposure);reference_label='ISO100 AHD reference'
        else:
            reference_display=display(arrays['reference_rgb']);reference_label='ISO100 AHD reference'
        panels=[('Noisy (Malvar)',noisy_display),*[(labels[arm],rendered[arm])for arm in collections],(reference_label,reference_display)]
        if observation['kind']=='mesh':
            def jpeg(role):
                data=np.load(checked(case['camera_JPEGs'][role]['pixels']),allow_pickle=False)
                return linear_to_srgb((srgb_to_linear(data.astype(np.float32)/255)*exposure).clip(0,1))
            panels.insert(0,('ISO6400 camera JPEG',jpeg('noisy_camera_jpeg')))
            panels.append(('ISO100 camera JPEG',jpeg('reference_camera_jpeg')))
        name=identity+'-'+case['name'];path=output/(name+'.png')
        canvas=Image.new('RGB',(8+168*len(panels),192),'#eeeeee');draw=ImageDraw.Draw(canvas);rectangles=[]
        for i,(label,value)in enumerate(panels):
            x=8+168*i;draw.text((x,5),label,fill='black');canvas.paste(Image.fromarray(pixels(value)),(x,24));rectangles.append({'label':label,'png_xywh':[x,24,160,160]})
        canvas.save(path);reread=np.asarray(Image.open(path))
        for rectangle,(_,value)in zip(rectangles,panels,strict=True):
            x,y,w,h=rectangle['png_xywh'];np.testing.assert_array_equal(reread[y:y+h,x:x+w],pixels(value))
        metadata={'observation':identity,'case':case,'noise':observation['noise'],'input_arrays':observation['arrays'],
                  'display_exposure':exposure,'reference_role':observation['reference_role']}
        boards.append({'id':name,'image':reference(path),'panels':rectangles,**metadata})
        for arm in (['localized-spatial'] if development else []):
            triplet=save_triplet(output/'triplets',arm+'-'+name,
                    [('Noisy (Malvar)',noisy_display),(labels[arm],rendered[arm]),(reference_label,reference_display)],
                    caption=name,metadata={**metadata,'checkpoint':collections[arm]['checkpoint'],'weights':'EMA','arm':arm})
            triplets.append({'arm':arm,'id':name,'image':reference(output/'triplets'/triplet['image']),
                             'metadata':reference((output/'triplets'/triplet['image']).with_suffix('.json'))})
means={}
for arm,collection in collections.items():
    for condition in ['shadows','iso12800-prior']:
        group=[r for r in collection['records']if r['id'].startswith('development-')and r['id'].endswith(condition)]
        means[arm+'-'+condition]={key:float(np.mean([v for row in group for v in row['metrics'][key]if v is not None]))
                                 for key in group[0]['metrics']if any(v is not None for row in group for v in row['metrics'][key])}
write_json(output/'result.json',{'plan':reference(plan_path),'renderer':reference(__file__),
           'collections':collection_links,'matched_training':closed['training'],
           'boards':boards,'triplets':triplets,'native_crop_size':[160,160],'development_condition_means':means,
           'actual_native_viewing':'pending','scope':'First localized spatial 2400 EMA, older spatial 12k EMA, 100k parent and V120 on fixed inputs. Four complete noisy development fields,16 scored crops;8 displayed fixed development crops,4 main GFX regions,4 cab ROI/profile combinations. Every PNG panel independently reread and checked without resizing. Narrow development scores are not full427/camera metrics. Independent real ISO100/AHD/JPEG references are not exact GT. No new neural, noise or RAW calls.'})
print('rendered',len(boards),'boards,',len(triplets),'triplets')
