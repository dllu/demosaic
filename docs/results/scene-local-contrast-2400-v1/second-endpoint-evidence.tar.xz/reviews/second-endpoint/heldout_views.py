"""Render the same three ISO6400 pilot queries with the first trained endpoint."""

from pathlib import Path
import sys

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from report_scene_wave_guides import native_board
from evaluate import ARGS


def render():
    result_ref=reference(HERE/"heldout-results.json")
    result=read_json(checked(result_ref))
    raw_plan=read_json(ROOT/"evaluation-plan.json")
    pil=read_json(checked(read_json(checked(result["plan"]))["former_eight_photo_plan"]))
    samples=HERE/"heldout-native"
    samples.mkdir()
    views=[]
    for selected, role in ((0,0),(1,0),(0,2)):
        original=raw_plan["rows"][selected]
        row=next(r for r in result["source_metrics"] if r["source"]==original["source"]["id"]
                 and r["profile"]=="iso6400" and r["draw"]=="coupled")
        data=read_json(checked(row["case"]))
        previous=read_json(checked(row["prediction_receipt"]))
        with np.load(checked(data["input"]),allow_pickle=False) as payload:
            args={k:payload[k][role:role+1] if k in ("packed","variance") else payload[k][None]
                  for k in ARGS}
            target=payload["target"][role]
        with np.load(checked(previous["saved"]),allow_pickle=False) as payload:
            old=[payload[k][role] for k in ("V120","100k","prior-spatial12k--matching")]
        with np.load(checked(row["localized_spatial_output"]),allow_pickle=False) as payload:
            spatial=payload["localized-spatial2400--matching"][role]
        with np.load(checked(row["saved"]),allow_pickle=False) as payload:
            latest=payload["plain-local2400"][role]
        method=["Noisy Malvar","V120","Corpus 100k","Spatial12k","Localized spatial",
                "Plain local EMA","Exact GT"]
        views.append(native_board(
            samples, f"{data['id']}-role{role}", [noisy_malvar(args)[0],*old,spatial,latest,target], args,
            {"source":original["source"],"role":raw_plan["roles"][role],"query_box":data["box"],
             "profile":data["profile"],"CFA":original["camera"]["pattern"],"draw":data["draw"],
             "trained_checkpoint":read_json(checked(result["plan"]))["models"]["plain-local2400"],
             "previous_checkpoints":pil["models"],"input_receipt":row["case"],"result":result_ref},
            labels=method,triplet_indices=(0,5,6), contrast=2,
            exposure=1/data["profile"]["exposure"], roi=tuple(raw_plan["native_display_ROI_xywh"]),
        ))
    write_json(samples/"views.json",{"results":result_ref,"driver":reference(__file__),"views":views})
if __name__=="__main__":
    render()
