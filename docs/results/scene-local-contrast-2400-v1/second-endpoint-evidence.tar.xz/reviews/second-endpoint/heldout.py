"""Verify inference and compare the first endpoint on the fixed eight-photo probe."""

import os
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from evaluate import ARGS, load, scene_fields, setup_models
from measure import parts, reduce

PLAN=HERE/"heldout-plan.json"


def prepare():
    training=reference(ROOT/"plain-none-verified.json")
    endpoint=read_json(checked(training))
    models={
        "plain-local2400":endpoint["checkpoint"]|{"type":"scene","step":2400,"mode":"none"},
    }
    write_json(PLAN,{
        "driver":reference(__file__),"training":training,
        "former_eight_photo_plan":reference(ROOT/"pilot/plan.json"),
        "former_eight_photo_results":reference(HERE.parent/"first-endpoint/heldout-results.json"),
        "collector_source":reference(ROOT/"evaluate.py"),"reducer_source":reference(ROOT/"measure.py"),
        "models":models,
        "comparison":"First two completed arms. Eight existing pilot sources and four existing prior/draw combinations per source. Previous V120, 100k and earlier spatial12k compared on identical held-out observations.",
    })


@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[17,18])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    plan=read_json(PLAN)
    assert checked(plan["driver"])==Path(__file__)
    for name in ("collector_source","reducer_source"):
        checked(plan[name])
    prior=read_json(checked(plan["former_eight_photo_plan"]))
    report=read_json(checked(plan["former_eight_photo_results"]))
    old=report["source_metrics"]
    assert read_json(checked(report["plan"]))["former_eight_photo_plan"]==plan["former_eight_photo_plan"] and len(old)==32
    spec=read_json(checked(prior["panel"]))
    key="plain-local2400"
    model=setup_models({"models":plan["models"]})[key]
    results=[]
    saved=HERE/"predictions"
    saved.mkdir()
    started=time.monotonic()
    with ieee_fp32():
        for index in prior["selected_indices"]:
            for prof in spec["profiles"]:
                profile=prof["name"]
                for draw in spec["draws"]:
                    bound,setting,arrays=load(index,(profile,draw))
                    old_case=next(row for row in old if (row["source"],row["profile"],row["draw"])==
                                  (setting["source"],profile,draw))
                    former=read_json(checked(old_case["prediction_receipt"]))
                    assert former["case"]==bound and former["exact_query_inputs"]=={
                        k:setting["fingerprints"][k] for k in ARGS
                    }
                    with np.load(checked(setting["input"]),allow_pickle=False) as store:
                        target=store["target"]
                    fields={k:np.broadcast_to(arrays[k][None],(3,*arrays[k].shape))
                            for k in ("wb","matrix")}
                    fields["exposure"]=prof["exposure"]
                    data={k:torch.from_numpy(v).cuda()for k,v in arrays.items()}
                    query=[data[k] if k in ("packed","variance") else data[k][None].expand(3,*data[k].shape)
                           for k in ARGS]
                    for i in range(2):
                        query[i]=query[i].contiguous(memory_format=torch.channels_last)
                    for i,k in enumerate(ARGS[:2]):
                        assert fingerprint(query[i].contiguous().cpu())==setting["fingerprints"][k]
                    model.base.set_noise(prof["shot"],prof["read"])
                    outputs={key:model(*query).cpu().numpy()}
                    assert all(v.shape==target.shape and np.isfinite(v).all() for v in outputs.values())
                    output=saved/(setting["id"]+".npz")
                    with output.open("xb") as stream:
                        np.savez(stream,**{name.replace("/","--"):v for name,v in outputs.items()})
                    metrics={name:parts(fields,v,target,spec) for name,v in outputs.items()}
                    results.append({**old_case,"case":bound,"localized_spatial_output":old_case["saved"],"saved":reference(output),
                                    "metrics":old_case["metrics"]|metrics})
            print(index,len(results),round(time.monotonic()-started,2),flush=True)
    assert len(results)==32
    write_json(HERE/"heldout-results.json",{
        "plan":reference(PLAN),"count":len(results),"observations":96,
        "seconds_including_metrics":time.monotonic()-started,
        "exact_former_local_queries_replayed":True,
        "source_metrics":results,"pooled":reduce(results),
    })


if __name__=="__main__":
    if sys.argv[1:]==["--plan"]:
        prepare()
    else:
        run()
