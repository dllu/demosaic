"""Execute the four frozen training arms and audit each endpoint on exit."""

import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import psutil

from demosaic.experiments.artifacts import checked,read_json,reference,verify_plan,write_json
from demosaic.experiments.runtime import exclusive_run,owner_identity

ROOT=Path(__file__).resolve().parent


def status(stage, **fields):
    write_json(ROOT/"status.json",{"stage":stage,"owner":owner_identity(),**fields},replace=True)


def resources(plan,name):
    while (psutil.virtual_memory().available<plan["minimum_start_RAM_GiB"]*2**30 or
           shutil.disk_usage(ROOT).free<plan["minimum_disk_GiB"]*2**30):
        status("resource-wait",pending=name)
        time.sleep(20)


def worker(name,plan,bind,operation,path,mode=None):
    resources(plan,name)
    work=Path(plan["work"])
    arguments=[operation,str(checked(bind)),str(path)]
    if mode is not None:
        arguments.extend(["--mode",mode])
    command=["taskset","-c","12,13",sys.executable,str(checked(plan["training_script"])),*arguments]
    env=os.environ.copy()
    env.pop("CUDA_VISIBLE_DEVICES",None)
    env.update(PYTHONPATH=f"{work}/src:{work}/scripts",OPENBLAS_NUM_THREADS="1",
               OMP_NUM_THREADS="2",MKL_NUM_THREADS="2",PYTHONUNBUFFERED="1")
    with (ROOT/f"{name}.log").open("xb") as output:
        process=subprocess.Popen(command,env=env,stdout=output,stderr=subprocess.STDOUT)
        child={"pid":process.pid,"created":psutil.Process(process.pid).create_time(),
               "command":command,"plan":bind}
        write_json(ROOT/f"{name}-launch.json",child)
        status(name,child=child)
        stop=process.wait()
    write_json(ROOT/f"{name}-exit.json",{"returncode":stop,"child":child},)
    if stop:
        raise RuntimeError(f"{name} exited with status {stop}")
    print("finished",name,flush=True)


def verified_prefix(plan,name,bind):
    data=ROOT/name/"preflight/result.json"
    reports=read_json(data)
    assert reports["plan"]==bind and reports["all_modes_passed"]
    a,b=reports["results"]
    assert [a["mode"],b["mode"]]==plan["modes"]==["none","spatial"]
    assert a["discarded_updates"]==b["discarded_updates"]==2
    assert a["training_observations"]==b["training_observations"]
    for arm in (a,b):
        checked(arm["roundtrip_checkpoint"])
    return reference(data)


def endpoint(name,mode,plan,bind,order):
    end=ROOT/name/mode/"completed.json"
    trained=read_json(end)
    assert trained["steps"]==plan["steps"] and trained["mode"]==mode
    assert trained["DINO_unchanged"] and trained["plan"]==bind
    trace=checked(trained["observations"])
    off=name=="plain"
    local=0
    with trace.open() as stream:
        for i,(line,target) in enumerate(zip(stream,order,strict=True)):
            record=json.loads(line)
            assert record["index"]==i and record["source_id"]==target["source_id"]
            assert ("local_contrast" in record)==(not off and target["localized"])
            local+=int("local_contrast" in record)
    run=ROOT/name/mode/"train.jsonl"
    with run.open() as stream:
        steps=[json.loads(line)for line in stream]
    assert [row["step"]for row in steps]==list(range(1,plan["steps"]+1))
    assert all(math.isfinite(t["gradient_norm"]) and all(math.isfinite(v) for v in t["terms"].values()) for t in steps)
    return {"completed":reference(end),"checkpoint":reference(checked(trained["checkpoints"][-1])),
            "raw_and_ema_weights":True,"review_policy":"EMA","training_trace":reference(run),
            "observations":trained["observations"],"wall_training_seconds":trained["seconds"],
            "steps":plan["steps"],"native_crops":len(order)*plan["crops_per_scene"],
            "distinct_scenes":len(order),"localized_scene_count":local}


def compare_traces(receipts):
    for candidate in ("plain","localized"):
        first,second=(receipts[f"{candidate}-{arm}"]["observations"]for arm in ("none","spatial"))
        assert first["sha256"]==second["sha256"]
    first,second=(checked(receipts[f"{data}-none"]["observations"]) for data in ("plain","localized"))
    same=0
    fields=("source_id","recipe","boxes_xywh","D4_quarter_turns","mirror_x","native_hw")
    with first.open() as a, second.open() as b:
        for x,y in zip(a,b,strict=True):
            plain,local=map(json.loads,(x,y))
            assert all(plain[k]==local[k]for k in fields)
            if "local_contrast" not in local:
                assert plain==local
                same+=1
    return same


def main():
    with exclusive_run(ROOT):
        top=reference(ROOT/"plan.json")
        master=read_json(checked(top))
        order=read_json(checked(master["source_order"]))["rows"]
        plans={name:read_json(checked(ref))for name,ref in master["plans"].items()}
        for plan in plans.values():
            verify_plan(plan)
        primary_bindings=master["plans"]
        audits={}
        for name in ("plain","localized"):
            bind=primary_bindings[name]
            worker(f"{name}-preflight",plans[name],bind,"preflight",ROOT/name/"preflight")
            audits[name]=verified_prefix(plans[name],name,bind)
        a,b=(read_json(checked(audits[name]))["results"][0]["training_observations"]for name in ("plain","localized"))
        for x,y in zip(a,b,strict=True):
            assert all(x[k]==y[k] for k in ("index","recipe","source_id","boxes_xywh"))
        write_json(ROOT/"physical-prefix.json",{"preflights":audits,"plan":top,
                   "same_coordinates_metadata_and_scenes":True,
                   "qualification_updates_per_arm":2,
                   "localized_draws_in_prefix":[v["index"]for v in b if "local_contrast"in v]})
        receipts={}
        for name,mode in master["sequence"]:
            key=f"{name}-{mode}"
            worker(key,plans[name],primary_bindings[name],"train",ROOT/name/mode,mode)
            receipts[key]=endpoint(name,mode,plans[name],primary_bindings[name],order)
            write_json(ROOT/f"{key}-verified.json",receipts[key])
        same=compare_traces(receipts)
        assert same==len(order)-master["localized_draws_per_augmented_arm"]
        write_json(ROOT/"matched-training.json",{"plan":top,"preflights":audits,"endpoints":receipts,
                   "same_full_input_trace_within_each_recipe":True,
                   "identical_draws_across_recipes":same,"trained":True,
                   "numerical_quality_review_complete":False,"actual_native_review_complete":False})
        status("trained")


if __name__=="__main__":
    try:
        main()
    except Exception as err:
        status("failed",reason=str(err))
        raise
