"""Freeze a matched two-by-two comparison on the complete-scene photo corpus."""

import json
from collections import Counter
from pathlib import Path
import random
import shutil
import subprocess

import numpy as np

from demosaic.experiments.artifacts import checked,freeze_sources,read_json,reference,write_json
from demosaic.scene_training_data import scene_seed
from prepare_scene_epoch_corpus import read_catalogue,write_order

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
OLD=ROOT.parent/"expanded-scene-12000-v2"
FRAC={"plain":0.0,"localized":0.5}
STEPS=2400
SCENES=2
SEED=202611180702


def main():
    legacy=reference(OLD/"plan.json")
    initial=read_json(checked(legacy))
    verified=reference(REPO/"docs/results/scene-local-contrast-preflight-v1/cuda-preflight.json")
    assert read_json(checked(verified))["all_modes_passed"]
    source_plan=initial["train_manifest"]
    rows=read_catalogue(checked(source_plan))
    assert len(rows)==90692 and all(r["split"]=="train" and Path(r["cache"]).is_absolute() for r in rows)
    canonical=reference(ROOT.parent/"full427-faint-adc-v1"/"cohort.json")
    excluded=set(read_json(checked(canonical))["source_ids"])
    development=read_catalogue(checked(initial["development_manifest"]))
    excluded.update(r["id"] for r in development)
    assert not ({r["id"] for r in rows}&excluded)
    order_dir=ROOT/"data"
    order_dir.mkdir()
    manifest=order_dir/"manifest-train.jsonl"
    shutil.copyfile(checked(source_plan),manifest)
    assert reference(manifest)["sha256"]==source_plan["sha256"]
    order=write_order(manifest,rows,seed=SEED,steps=STEPS,scenes_per_step=SCENES)
    order_ref=reference(order)
    header=read_json(checked(order_ref))
    file=order.parent/header["order"]["path"]
    assert reference(file)["sha256"]==header["order"]["sha256"]
    indices=np.load(file,allow_pickle=False)
    assert len(indices)==len(set(indices))==STEPS*SCENES
    sources=[]
    for index,row in enumerate(indices):
        source=rows[row]
        rng=random.Random(scene_seed(SEED,index,"local-contrast"))
        replaced=rng.random()<FRAC["localized"]
        sources.append({"draw":index,"source_id":source["id"],"localized":replaced})
    count=sum(r["localized"] for r in sources)
    write_json(ROOT/"planned-source-order.json",{"rows":sources,"source_count":len(sources),
               "localized_scenes":count,"source_manifest":reference(manifest),"indices":reference(file)})
    work,frozen=freeze_sources(REPO,ROOT,["train_scene_context.py"])
    driver=reference(work/"scripts/train_scene_context.py")
    plans={}
    for arm,fraction in FRAC.items():
        job=ROOT/arm
        job.mkdir()
        plan=initial|dict(root=str(job),work=str(work),frozen_files=frozen,training_script=driver,
           inputs=[initial["parent"],reference(manifest),order_ref,initial["development_manifest"],legacy,verified,canonical],
           train_manifest=reference(manifest),photo_epoch_order=order_ref,local_contrast_fraction=fraction,
           data_seed=SEED,model_seed=202611180701,steps=STEPS,scenes_per_step=SCENES,
           checkpoint_every=800,log_every=50,maximum_GPU_GiB=8,maximum_arm_seconds=7200,
           scope="Controlled 2400-update continuation, 4800 distinct binned whole photos, eight native crops per update.",
           scientific_primary="Interaction between localized contrast attenuation and aligned spatial context, with a matched local-only arm.",
           evaluation_limits="Use new source-disjoint photo inputs; earlier scene development set may appear in the common 100k parent. Standing GFX media are evaluation only.")
        path=job/"plan.json"
        write_json(path,plan)
        plans[arm]=reference(path)
    declared={"source":reference(__file__),"repo_commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
              "parent":initial["parent"],"training_script":driver,"plans":plans,
              "source_order":reference(ROOT/"planned-source-order.json"),"source_cohort":source_plan,
              "steps_per_arm":STEPS,"scenes_per_arm":STEPS*SCENES,"native_crops_per_arm":STEPS*SCENES*4,
              "localized_draws_per_augmented_arm":count,"factors":FRAC,
              "questions":["Does aligned spatial context restore more true faint structure within each training-data recipe?",
                "Does local augmentation change the benefit from the aligned scene relative to a matched local-only trunk?",
                "What happens to quiet, low-frequency and Bayer/chroma error under incorrect or neutral context?"],
              "sequence":[["localized","spatial"],["plain","none"],["plain","spatial"],["localized","none"]],
              "standing_camera_protocols":[reference(REPO/"configs"/name)for name in
                    ("gfx-qualitative-20231231.json","gfx-green-mesh-20231231.json")],
              "benchmark_contract":"Every completed full-model endpoint receives the fixed 427-photo and known/unseen camera panels and both native standing GFX families. Their results are separate from target-localized and context interventions.",
              "numeric_detail_contract":"Same held-out camera/CFA draws and targets. Hold the query RAW fixed across matched and altered scene previews. Summarize signed fine response, fine residual, quiet-region change, rendered metrics and current-V120 comparison."}
    write_json(ROOT/"plan.json",declared)
    print(STEPS,count,len(sources),flush=True)


if __name__=="__main__":
    main()
