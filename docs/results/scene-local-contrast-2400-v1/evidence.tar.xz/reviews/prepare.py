"""Freeze the heldout, standing GFX and canonical review queue."""

from pathlib import Path
import shutil

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json

REVIEW = Path(__file__).resolve().parent
ROOT = REVIEW.parent
REPO = ROOT.parents[2]
PREVIOUS = ROOT.parent / "expanded-scene-12000-native-v1"
CANONICAL = ROOT.parent / "expanded-scene-12000-primary-v3" / "full-plan.json"


def prepare():
    work, sources = freeze_sources(REPO, REVIEW, [
        "review_scene_context_native.py", "collect_scene_primary.py",
        "diagnose_local_material_detail.py", "report_scene_wave_guides.py",
        "profile_raw_kernel_inference.py", "probe_scene_context_extent.py",
    ])
    master_path = ROOT / "plan.json"
    master = read_json(master_path)
    template = read_json(PREVIOUS / "plan.json")
    old_collection = read_json(PREVIOUS / "collection.json")
    parent, baseline = (read_json(checked(old_collection[key])) for key in ("parent", "V120"))
    assert parent["checkpoint"]["sha256"] == master["parent"]["sha256"]
    v120 = read_json(REPO / "configs/current-model.json")["checkpoint"]
    assert baseline["checkpoint"]["sha256"] == v120["sha256"]
    for key in ("main_full_RAW", "mesh_full_RAW"):
        checked(template[key])
    assert len(template["observations"]) == 10
    for row in template["observations"]:
        checked(row["arrays"])
    for lane in ("standing", "canonical", "heldout"):
        (REVIEW / lane).mkdir()
    driver = reference(work / "scripts/review_scene_context_native.py")
    plans = {}
    for recipe in master["plans"]:
        out = REVIEW / "standing" / recipe
        out.mkdir()
        plan = {
            **template,
            "root": str(out), "CPU_affinity": [14, 19], "script": driver,
            "sources": sources, "training_plan": master["plans"][recipe],
            "training_output_root": str(ROOT / recipe),
            "template": reference(PREVIOUS / "plan.json"),
            "scope": "Frozen real Bayer queries and established display comparators for the matched localized-contrast EMA endpoints.",
        }
        path = out / "plan.json"
        write_json(path, plan)
        plans[recipe] = reference(path)
    renderer = REVIEW / "standing/render.py"
    old_renderer = (PREVIOUS / "render.py").read_text()
    replacements = {
        'plan_path=root/\'plan.json\'': 'plan_path=root/\'plain/plan.json\'',
        "training['native_examples_per_arm']==96000": "len(training['endpoints'])==4",
        "for arm in ('none','spatial'):\n    assert collections[arm]['plan']==reference(plan_path)\n    assert collections[arm]['checkpoint']==training['endpoints'][arm]['EMA']":
            "for arm in training['endpoints']:\n    recipe=arm.split('-')[0]\n    assert collections[arm]['plan']==reference(root/recipe/'plan.json')\n    assert collections[arm]['checkpoint']==training['endpoints'][arm]['checkpoint']",
        "labels={'V120':'V120 EMA','parent100k':'Parent 100k EMA','none':'Local-only 12k EMA','spatial':'Spatial 12k EMA'}":
            "labels={'V120':'V120 EMA','parent100k':'Parent 100k EMA','plain-none':'Plain local EMA','plain-spatial':'Plain spatial EMA','localized-none':'Localized local EMA','localized-spatial':'Localized spatial EMA'}",
        "(['spatial'] if development else [])": "(list(training['endpoints']) if development else [])",
        "Expanded local-only and spatial 12k EMA": "Four matched local-only and spatial 2400 EMA arms",
        "ISO100 AHD, not GT": "ISO100 AHD reference",
    }
    for before, after in replacements.items():
        assert before in old_renderer
        old_renderer = old_renderer.replace(before, after)
    renderer.write_text(old_renderer)
    work_canonical = reference(work / "scripts/collect_scene_primary.py")
    for key in ("collect_scene_primary.py", "review_scene_context_native.py"):
        assert (work / "scripts" / key).read_bytes() == (REPO / "scripts" / key).read_bytes()
    write_json(REVIEW / "plan.json", {
        "queue_driver": reference(REVIEW / "run.py"), "source_snapshot": sources,
        "training": reference(master_path), "training_launch": reference(ROOT / "launch.json"),
        "sequence": master["sequence"], "standing_plans": plans, "standing_driver": driver,
        "standing_renderer": reference(renderer), "V120_standing": old_collection["V120"],
        "100k_standing": old_collection["parent"], "heldout_driver": reference(ROOT / "evaluate.py"),
        "heldout_reducer": reference(ROOT / "measure.py"), "canonical_template": reference(CANONICAL),
        "canonical_driver": work_canonical,
    })


if __name__ == "__main__":
    prepare()
