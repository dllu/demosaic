"""Bind and run each evaluation when its audited EMA endpoint becomes available."""

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

REVIEW = Path(__file__).resolve().parent
ROOT = REVIEW.parent
WORK = REVIEW / "work"
ENV = {
    **os.environ,
    "PYTHONPATH": f"{WORK / 'src'}:{WORK / 'scripts'}",
    "OPENBLAS_NUM_THREADS": "1",
    "OMP_NUM_THREADS": "2",
}
TRAINING = ROOT / "matched-training.json"


def wait_for(file, owner, folder):
    write_json(folder / "status.json", {"stage": "waiting", "required": str(file)}, replace=True)
    while not file.is_file():
        if not owner_live(owner):
            if file.is_file():
                break
            raise RuntimeError(f"Bound training controller exited before creating {file}")
        time.sleep(15)
    return read_json(file)


def run(folder, name, arguments, gpu=False):
    child_env = ENV.copy()
    if not gpu:
        child_env["CUDA_VISIBLE_DEVICES"] = ""
    command = [sys.executable, *map(str, arguments)]
    with (folder / f"{name}.log").open("xb") as stream:
        child = subprocess.Popen(command, env=child_env, stdout=stream, stderr=subprocess.STDOUT)
        identity = {"pid": child.pid, "created": psutil.Process(child.pid).create_time()}
        write_json(folder / "status.json", {"stage": name, "child": identity}, replace=True)
        write_json(folder / f"{name}-launch.json", identity | {"command": command})
        code = child.wait()
    write_json(folder / f"{name}-exit.json", {"returncode": code})
    if code:
        raise RuntimeError(f"{name} exited with {code}")


def standing(folder, spec, owner):
    collector = checked(spec["standing_driver"])
    outputs = {}
    for recipe, mode in spec["sequence"]:
        label = f"{recipe}-{mode}"
        audit = wait_for(ROOT / f"{label}-verified.json", owner, folder)
        plan = checked(spec["standing_plans"][recipe])
        run(folder, label, [collector, plan, mode])
        receipt = folder / recipe / mode / "collection.json"
        collected = read_json(receipt)
        assert collected["weights"] == "EMA" and collected["DINO_unchanged"]
        assert collected["checkpoint"] == audit["checkpoint"]
        assert collected["plan"] == reference(plan) and len(collected["records"]) == 10
        outputs[label] = reference(receipt)
    complete = wait_for(TRAINING, owner, folder)
    assert complete["trained"]
    write_json(folder / "collection.json", {
        "training": reference(TRAINING), "V120": spec["V120_standing"],
        "parent": spec["100k_standing"], "epochs": outputs,
    })
    run(folder, "render", [checked(spec["standing_renderer"])])
    render = read_json(folder / "render" / "result.json")
    assert len(render["boards"]) == 16
    assert render["actual_native_viewing"] == "pending"
    return reference(folder / "render" / "result.json")


def heldout(folder, spec, owner):
    assert wait_for(TRAINING, owner, folder)["trained"]
    driver, reducer = (checked(spec[key]) for key in ("heldout_driver", "heldout_reducer"))
    run(folder, "bind", [driver, "--plan"], gpu=True)
    run(folder, "collect", [driver], gpu=True)
    run(folder, "reduce", [reducer])
    receipt = ROOT / "evaluation" / "results.json"
    value = read_json(receipt)
    assert value["counts"] == {"cases": 256, "observations": 768}
    return reference(receipt)


def canonical(folder, spec, owner):
    finished = wait_for(TRAINING, owner, folder)
    assert finished["trained"] and finished["plan"] == spec["training"]
    template_path = checked(spec["canonical_template"])
    template = read_json(template_path)
    driver = checked(spec["canonical_driver"])
    archive = read_json(checked(template["canonical_inputs"]))
    assert len(archive["records"]) == 3162
    models = {key: template["models"][key] for key in ("V120", "parent100k")}
    for label, record in finished["endpoints"].items():
        # The original collector uses the model keyed as spatial for the
        # shared, hash-identical DINO preview encoder.
        key = "spatial" if label == "plain-spatial" else label
        models[key] = {"kind": "scene", "checkpoint": record["checkpoint"], "step": 2400}
    assert len(models) == 6
    controls = [r for r in template["inputs"] if r != template["preflight"]]
    plan = {
        **template,
        "root": str(folder),
        "work": str(WORK),
        "driver": reference(driver),
        "frozen_files": spec["source_snapshot"],
        "CPU_affinity": [6, 7, 15, 16],
        "CPU_threads": 4,
        "models": models,
        "training_arm_aliases": {"spatial": "plain-spatial"},
        "inputs": [*controls, reference(template_path), reference(TRAINING),
                   *[value["checkpoint"] for value in models.values()]],
        "scope": "Four matched 2400 EMA endpoints and two bound parents on fixed photo, known and unseen inputs.",
    }
    del plan["preflight"]
    preflight_path = folder / "preflight-plan.json"
    write_json(preflight_path, plan)
    run(folder, "preflight-run", [driver, preflight_path, "preflight"])
    qualified = reference(folder / "preflight" / "result.json")
    assert read_json(checked(qualified))["cases"] == 3
    plan_path = folder / "full-plan.json"
    write_json(plan_path, plan | {"preflight": qualified, "inputs": [*plan["inputs"], qualified]})
    run(folder, "full-run", [driver, plan_path, "full"])
    receipt = folder / "full" / "result.json"
    value = read_json(receipt)
    assert value["all_complete"] and value["cases"] == 3162
    return reference(receipt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("lane", choices=["standing", "heldout", "canonical"])
    lane = parser.parse_args().lane
    declaration = read_json(REVIEW / "plan.json")
    assert checked(declaration["queue_driver"]) == Path(__file__)
    training_owner = read_json(checked(declaration["training_launch"]))
    current = REVIEW / lane
    with exclusive_run(current):
        try:
            result = {"standing": standing, "heldout": heldout, "canonical": canonical}[
                lane
            ](current, declaration, training_owner)
        except Exception as error:
            write_json(current / "failure.json", {"stage": lane, "error": repr(error)})
            raise
        write_json(current / "status.json", {"stage": "collected", "result": result}, replace=True)
