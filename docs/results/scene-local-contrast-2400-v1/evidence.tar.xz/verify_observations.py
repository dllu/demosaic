"""Independently verify the frozen evaluation input groups and their targets."""

from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
EVALUATION = ROOT / "evaluation-plan.json"


def verify():
    plan = read_json(EVALUATION)
    training = read_json(checked(plan["training_plan"]))
    trained_sources = {
        row["source_id"]
        for row in read_json(checked(training["source_order"]))["rows"]
    }
    panels = [ROOT / f"observation-shard-{index}.json" for index in (0, 1)]
    cases = [
        record for path in panels for record in read_json(path)["records"]
    ]
    ids, seeds = set(), set()
    reference_targets, packed_receipts = {}, defaultdict(set)
    raw_strength, zero_core = [], set()
    for binding in cases:
        spec = read_json(checked(binding))
        assert spec["plan"] == reference(EVALUATION)
        index = spec["case"]
        source = plan["rows"][index]["source"]
        identifier = spec["id"]
        assert identifier not in ids
        ids.add(identifier)
        assert spec["source"] == source["id"] and source["id"] not in trained_sources
        assert source["split"] == "val"
        case_seeds = set(spec["physical_seeds"].values())
        assert len(case_seeds) == 5 and not case_seeds & seeds
        seeds |= case_seeds

        with np.load(checked(spec["input"]), allow_pickle=False) as data:
            assert {key: fingerprint(data[key]) for key in data.files} == spec["fingerprints"]
            target, packed, scene = (data[key] for key in ("target", "packed", "scene_packed"))
            assert target.shape == (3, 3, 256, 256)
            assert packed.shape == (3, 4, 128, 128) and scene.shape[0] == 4
            assert all(np.isfinite(data[key]).all() for key in data.files)
            x, y, w, h = plan["score_ROI_xywh"]
            core = target[2, :, y : y + h, x : x + w]
            assert np.array_equal(core, np.broadcast_to(core[:, :1, :1], core.shape))
            if np.array_equal(target[0, :, y : y + h, x : x + w],
                              target[1, :, y : y + h, x : x + w]):
                zero_core.add(index)
            ref = spec["fingerprints"]["target"]["sha256"]
            assert ref == reference_targets.setdefault(index, ref)
            packed_receipts[index].add(spec["fingerprints"]["packed"]["sha256"])
            if spec["profile"]["name"] == "iso400" and spec["draw"] == "coupled":
                raw_strength.append(spec["clean_linear_increment_RMS_DN16"])

    expected = {
        f"{row['index']:03d}-{profile['name']}-{draw}"
        for row in plan["rows"] for profile in plan["profiles"] for draw in plan["draws"]
    }
    assert ids == expected and len(ids) == plan["expected_cases"] == 256
    assert len(reference_targets) == 64
    assert all(len(group) == 4 for group in packed_receipts.values())
    for row in plan["rows"]:
        source = row["source"]
        checked({"path": source["cache"], "sha256": source["cache_sha256"]})
    write_json(
        ROOT / "observation-verification.json",
        {
            "plan": reference(EVALUATION),
            "driver": reference(__file__),
            "shards": list(map(reference, panels)),
            "observation_groups": len(ids),
            "native_queries": len(ids) * 3,
            "unique_source_ids": len(reference_targets),
            "CFA_source_counts": dict(Counter(row["camera"]["pattern"] for row in plan["rows"])),
            "unique_physical_seeds": len(seeds),
            "all_clean_roles_identical_across_priors_and_draws": True,
            "all_flat_cores_exact": True,
            "all_absolute_record_digests_and_array_fingerprints_verified": True,
            "train_id_overlap": 0,
            "zero_increment_core_source_indices": sorted(zero_core),
            "nonzero_increment_core_sources": len(reference_targets) - len(zero_core),
            "recorded_linear_increment_RMS_DN16_percentiles_10_50_90": np.percentile(raw_strength, [10, 50, 90]).tolist(),
        },
    )


if __name__ == "__main__":
    verify()
