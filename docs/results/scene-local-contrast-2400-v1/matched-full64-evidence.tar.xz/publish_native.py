"""Bind published native comparisons to bit-identical rendered pixels."""
import argparse
from pathlib import Path
import shutil

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
SCALE="scene-preview-scale-v1"
MATCHED="scene-local-contrast-2400-v1"

def relative(path):
    return reference(path)|{"path":str(path.relative_to(REPO))}

def image(data,folder):
    source=checked(data["image"])
    dest=folder/source.name
    shutil.copyfile(source,dest)
    published=relative(dest)
    assert published["sha256"]==data["image"]["sha256"]
    with Image.open(dest) as png:
        for panel in data["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160) and x+w<=png.width and y+h<=png.height
        png.verify()
    return data|{"image":published}

def standing(notes,folder,out):
    source=ROOT/"standing-native.json"
    report=read_json(source)
    output=[]
    for row in report["rows"]:
        results={}
        for arm,fields in row["results"].items():
            results[arm]={**fields,"native":image(fields["native"],folder),
                          "actual_native_viewing":notes[row["id"]][arm]}
        output.append(row|{"results":results})
    assert len(output)==8 and all(len(v["results"])==2 for v in output)
    write_json(out,{
        **report,"rows":output,"native_boards_viewed":16,
        "checkpoints":read_json(ROOT/"standing-plan.json")["models"],
        "captures":{"main":["DSCF3879","DSCF3880"],"fine_cab":["DSCF3842","DSCF3835"]},
    })

def natural(kind,notes,folder,out):
    source=ROOT/f"{kind}-native/result.json"
    report=read_json(source)
    rows=[row|{"actual_native_viewing":notes[row["id"]],
              **{key:image(row[key],folder)for key in ("board","triplet")}}
          for row in report["views"]]
    assert len(rows)==3
    record={**report,"views":rows,"viewing":"All three comparison boards and triplets actually viewed at native scale"}
    write_json(out,record)

def main(kind):
    notes=read_json(ROOT/"viewing-notes.json")[kind]
    if kind=="original":
        folder=REPO/"docs/images/scene-local-contrast-2400-full64"
        parent=REPO/"docs/results"/MATCHED
        dest=parent/"matched-full64-viewing.json"
    else:
        folder=REPO/"docs/images"/SCALE/kind
        parent=REPO/"docs/results"/SCALE
        dest=parent/f"{kind}-viewing.json"
    folder.mkdir(parents=True,exist_ok=True)
    parent.mkdir(exist_ok=True)
    if kind=="standing":
        standing(notes,folder,dest)
    else:
        natural(kind,notes,folder,dest)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("kind",choices=("original","preview","standing"))
    main(p.parse_args().kind)
