"""Summarize whole-image and data-recipe effects using paired source draws."""

from pathlib import Path
import argparse

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ARM_COEFFICIENTS = {
    "plain_spatial_over_local": {"plain-spatial/matching": 1, "plain-none": -1},
    "localized_spatial_over_local": {"localized-spatial/matching": 1, "localized-none": -1},
    "augmentation_by_spatial_interaction": {
        "localized-spatial/matching": 1, "localized-none": -1,
        "plain-spatial/matching": -1, "plain-none": 1,
    },
    "localized_spatial_matching_over_blur": {
        "localized-spatial/matching": 1, "localized-spatial/blur-distant": -1,
    },
    "localized_spatial_matching_over_mirror": {
        "localized-spatial/matching": 1, "localized-spatial/wrong-distant": -1,
    },
    "localized_spatial_matching_over_neutral": {
        "localized-spatial/matching": 1, "localized-spatial/neutral": -1,
    },
}
PILOT_COEFFICIENTS = {
    "matching_over_blur": {"prior-spatial12k/matching": 1, "prior-spatial12k/blur-distant": -1},
    "matching_over_mirror": {"prior-spatial12k/matching": 1, "prior-spatial12k/wrong-distant": -1},
    "matching_over_neutral": {"prior-spatial12k/matching": 1, "prior-spatial12k/neutral": -1},
}
METRICS = {
    "pooled_signed_response_delta_percentage_points": "aligned_increment_dot",
    "mean_paired_increment_RMS_delta_DN16": "increment_RMS_DN16",
    "mean_flat_core_fine_RMS_delta_DN16": "quiet_RMS_DN16",
}
RESAMPLES = 20_000
SEED = 383501
PROFILE = ("iso6400", "iso400")
DRAWS = ("coupled", "independent")


def freeze():
    panel = read_json(ROOT / "evaluation-plan.json")
    strengths = []
    for row in panel["rows"]:
        group = ROOT / "observations" / f"{row['index']:03d}-iso400-coupled.json"
        case = read_json(group)
        strengths.append((case["clean_linear_increment_RMS_DN16"], row["index"], case["source"]))
    half = sorted(strengths)[:len(strengths) // 2]
    assert len(half) == 32
    write_json(ROOT / "matched-analysis-plan.json", {
        "analysis_driver": reference(__file__),
        "evaluation_panel": reference(ROOT / "evaluation-plan.json"),
        "observation_verification": reference(ROOT / "observation-verification.json"),
        "contrasts": ARM_COEFFICIENTS,
        "pilot_descriptive_contrasts": PILOT_COEFFICIENTS,
        "metrics": METRICS,
        "profiles": PROFILE,
        "draws": DRAWS,
        "primary_noise": "iso6400",
        "fainter_half_by_frozen_clean_increment": half,
        "interval": {"unit": "whole photo", "resamples": RESAMPLES, "seed": SEED, "percentiles": [2.5, 97.5]},
        "interpretation": "Report coupled and independent draws separately. A source-level paired bootstrap resamples the same photo indices across arms. The ISO6400 interaction in signed response is interpreted together with paired increment error and false energy in the exact flat core. The fainter half is fixed using clean inputs only. The interval describes the sampled photo cohort with no multiplicity adjustment.",
    })


def compare(rows, coefficients, rng, bootstrap):
    values = {}
    indices = rng.integers(0, len(rows), (RESAMPLES, len(rows))) if bootstrap else None
    for label, key in METRICS.items():
        shifts, energy = [], []
        for row in rows:
            individual = {m: row["metrics"][m]["band"]["fine"] for m in coefficients}
            powers = {v["exact_paired_increment_sq"] for v in individual.values()}
            assert len(powers) == 1
            energy.append(powers.pop())
            shifts.append(sum(coefficients[m] * v[key] for m, v in individual.items()))
            assert sum(coefficients.values()) == 0
        shifts, energy = np.asarray(shifts), np.asarray(energy)
        if key == "aligned_increment_dot":
            material = energy > 1e-12
            per_source = 100.0 * shifts[material] / energy[material]
            result = (100.0 * shifts.sum()) / energy.sum()
            if bootstrap:
                denominators = energy[indices].sum(1)
                assert (denominators > 0).all()
                distribution = 100.0 * shifts[indices].sum(1) / denominators
        else:
            per_source = shifts
            result = shifts.mean()
            if bootstrap:
                distribution = shifts[indices].mean(1)
        values[label] = {
            "estimate": float(result),
            "source_level_median": float(np.median(per_source)),
            "source_count": len(per_source),
            "positive_source_count": int((per_source > 0).sum()),
            "percentile_interval_95": np.percentile(distribution, [2.5, 97.5]).tolist() if bootstrap else None,
        }
    return values


def reduce(pilot):
    path = ROOT / "matched-analysis-plan.json"
    frozen = read_json(path)
    assert checked(frozen["analysis_driver"]) == Path(__file__)
    assert frozen["contrasts"] == ARM_COEFFICIENTS
    assert frozen["pilot_descriptive_contrasts"] == PILOT_COEFFICIENTS
    run = ROOT / ("pilot" if pilot else "evaluation")
    measure = run / "results.json"
    raw = read_json(measure)
    reported = raw["source_metrics"]
    detail = {}
    faint = {entry[2] for entry in frozen["fainter_half_by_frozen_clean_increment"]}
    rng = np.random.default_rng(SEED)
    for profile in PROFILE:
        detail[profile] = {}
        for draw in DRAWS:
            selected = [record for record in reported if (record["profile"], record["draw"]) == (profile, draw)]
            assert len(selected) == (8 if pilot else 64)
            detail[profile][draw] = {
                "all": {split: compare(selected, coeff, rng, not pilot)
                        for split, coeff in (PILOT_COEFFICIENTS if pilot else ARM_COEFFICIENTS).items()},
            }
            if not pilot:
                weaker = [record for record in selected if record["source"] in faint]
                assert len(weaker) == 32
                detail[profile][draw]["fainter_half"] = {
                    split: compare(weaker, coeff, rng, True) for split, coeff in ARM_COEFFICIENTS.items()
                }
    write_json(run / "matched-analysis.json", {
        "plan": reference(path), "results": reference(measure),
        "scope": "Eight photographs. Descriptive paired differences." if pilot else
                 "Paired whole-photo estimates. Positive fine response implies more target-aligned signal. Positive RMS implies more error.",
        "estimates": detail,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("freeze", "pilot", "endpoint"))
    action = parser.parse_args().action
    if action == "freeze":
        freeze()
    else:
        reduce(action == "pilot")
