"""Render fixed 100% crops for the original and preview-scale exact-target panels."""
import argparse
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT.parent/"scene-local-contrast-2400-v1"
KEYS=("packed","variance","colors","wb","matrix")

def selection(rows,left,right,faint):
    high=[r for r in rows if r["profile"]=="iso6400" and r["draw"]=="coupled"]
    assert len(high)==64 and len({r["source"] for r in high})==64
    by_source=[r for r in high if r["source"] in faint]
    assert len(by_source)==32
    def difference(row,metric):
        return (row["metrics"][left]["band"]["fine"][metric]
                - row["metrics"][right]["band"]["fine"][metric])
    order=sorted(by_source,key=lambda row:difference(row,"increment_RMS_DN16"))
    gap=max(by_source,key=lambda row:difference(row,"quiet_RMS_DN16"))
    return ((order[0],0,"Largest coupled fine-increment RMS improvement on the fainter half"),
            (order[-1],0,"Largest coupled fine-increment RMS regression on the fainter half"),
            (gap,2,"Largest coupled exact-flat fine-band RMS increase on the fainter half"))

def run(kind):
    scope=ORIGINAL/"matched-analysis-plan.json"
    faint={r[2] for r in read_json(scope)["fainter_half_by_frozen_clean_increment"]}
    original=kind=="original"
    results=ORIGINAL/"evaluation/results.json" if original else ROOT/"natural-results.json"
    data=read_json(results)
    plan=read_json(checked(data["plan"]))
    panel=read_json(checked(plan["panel"] if original else plan["sensor_panel"]))
    left,right=("localized-spatial/matching","localized-none") if original else (
        "localized-spatial/fine","localized-spatial/coarse")
    rows=data["source_metrics"] if original else data["rows"]
    result=ROOT/f"{kind}-native"; result.mkdir()
    views=[]
    for row, role, why in selection(rows,left,right,faint):
        witness=checked(row["prediction_receipt"] if original else row["previous_prediction"])
        prior=read_json(witness)
        settings=read_json(checked(prior["case"]))
        material=panel["rows"][settings["case"]]
        with np.load(checked(settings["input"]),allow_pickle=False) as p:
            args={k:p[k][role:role+1] if k in ("packed","variance") else p[k][None] for k in KEYS}
            target=p["target"][role]
        if original:
            arms={"V120 EMA":"V120","Corpus 100k EMA":"100k",
                  "Plain local EMA":"plain-none","Plain spatial EMA":"plain-spatial/matching",
                  "Localized local EMA":"localized-none","Localized spatial EMA":left}
        else:
            arms={"V120 EMA":"V120","Corpus 100k EMA":"100k","Localized local EMA":"localized-none",
                  "Native-cap spatial":"localized-spatial/matching"}
        with np.load(checked(prior["saved"]),allow_pickle=False) as p:
            decoded={label:p[key.replace("/","--")][role] for label,key in arms.items()}
        if not original:
            alternatives={"Coarse preview":right,"Coarse resampled":"localized-spatial/resampled-coarse",
                          "Fine preview":left}
            with np.load(checked(row["saved"]),allow_pickle=False) as p:
                decoded.update({label:p[key.replace("/","--")][role] for label,key in alternatives.items()})
        images=[noisy_malvar(args)[0],*decoded.values(),target]
        item=native_board(result,f"{settings['id']}-role{role}",images,args,{
            "selection":why,"role":panel["roles"][role],"source":material["source"],
            "query_box":settings["box"],"profile":settings["profile"],
            "CFA":material["camera"]["pattern"],"draw":settings["draw"],
            "results":reference(results),"previous_prediction":reference(witness),
            "selected_checkpoint":plan["models"]["localized-spatial"],
            "precision":"CUDA IEEE FP32 EMA",
        },labels=("Noisy Malvar",*decoded,"Exact GT"),
          triplet_indices=(0,len(images)-2,len(images)-1),
          exposure=1/settings["profile"]["exposure"],contrast=2,
          roi=tuple(panel["native_display_ROI_xywh"]))
        views.append(item)
    write_json(result/"result.json",{
        "driver":reference(__file__),"results":reference(results),"fainter_case_selection":reference(scope),
        "viewing":"Pending actual native inspection","views":views})

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind",choices=("original","preview"))
    run(parser.parse_args().kind)
