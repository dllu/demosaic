"""Run a source-bound whole-scene intervention with identical local native RAW."""

import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from profile_raw_kernel_inference import model_hash
from probe_scene_context_extent import encode,near_weight

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_context import scene_preview
from demosaic.scene_inference import load_scene_checkpoint,perturb_scene

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
ARGS=("packed","variance","colors","wb","matrix")
PILOT_SOURCES=8


def freeze(pilot):
    published=reference(ROOT/"evaluation-plan.json")
    of=read_json(checked(published))
    training=read_json(checked(of["training_plan"]))
    model_sources={
       "V120":read_json(REPO/"configs/current-model.json")["checkpoint"]|{"type":"base","step":20000},
       "100k":training["parent"]|{"type":"base","step":100000},
    }
    if pilot:
        scale=REPO/"docs/results/expanded-scene-12000-v2/matched-training.json"
        older=read_json(scale)["endpoints"]["spatial"]["EMA"]
        model_sources["prior-spatial12k"]=older|{"type":"scene","step":12000,"mode":"spatial"}
        ids=[v["index"]for v in of["rows"][:PILOT_SOURCES]]
        identity=ROOT/"pilot"
    else:
        current=read_json(ROOT/"matched-training.json")
        assert current["plan"]==of["training_plan"] and current["trained"]
        for k,r in current["endpoints"].items():
            model_sources[k]=r["checkpoint"]|{"type":"scene","step":r["steps"],"mode":k.split("-")[-1]}
        ids=[v["index"]for v in of["rows"]]
        identity=ROOT/"evaluation"
    expected=of["scene_preview_policies"]
    assert expected==["matching","blur-distant","neutral","wrong-distant"]
    identity.mkdir()
    result={"source":reference(__file__),"panel":published,"models":model_sources,
            "selected_indices":ids,"precision":"CUDA IEEE FP32","pilot":pilot}
    write_json(identity/"plan.json",result)


def load(case,conditions):
    original=ROOT/"observations"/f"{case:03d}-{conditions[0]}-{conditions[1]}.json"
    settings=read_json(original)
    with np.load(checked(settings["input"]),allow_pickle=False)as f:
        arrays={k:f[k]for k in (*ARGS,"scene_packed")}
    assert {k:fingerprint(v)for k,v in arrays.items()}=={k:settings["fingerprints"][k]for k in arrays}
    return reference(original),settings,arrays


def scene_fields(model,data,settings,spec):
    # Reproduce a physical complete scene for each native input, with the
    # exact same exterior packed sensor samples across all three roles.
    box=settings["box"]
    x,y,w,h=(q//2 for q in box)
    obs=data["scene_packed"]
    by_policy={k:[]for k in spec["scene_preview_policies"]}
    traces=[]
    calibrate=[data[m]for m in ("colors","wb","matrix")]
    for branch in data["packed"]:
        full=obs.clone()
        full[:,y:y+h,x:x+w]=branch
        assert torch.equal(full[:,y:y+h,x:x+w],branch)
        assert torch.equal(full[:,:y],obs[:,:y]) and torch.equal(full[:,y+h:],obs[:,y+h:])
        assert torch.equal(full[:,y:y+h,:x],obs[:,y:y+h,:x])
        assert torch.equal(full[:,y:y+h,x+w:],obs[:,y:y+h,x+w:])
        preview,grid=scene_preview(full,*calibrate,long_side=1024,exposure=1.0)
        weight=near_weight(grid,[box],spec["halo_preview_px"],spec["transition_preview_px"]).to(preview.device)
        near=weight==1
        far=weight==0
        assert near.any() and far.any()
        smooth=np.asarray(gaussian_filter(preview.cpu().numpy(),
             (0,0,spec["blur_sigma_preview_px"],spec["blur_sigma_preview_px"]),mode="reflect"))
        blur=torch.from_numpy(smooth).to(preview.device)
        wrong=preview.flip((-1,-2))
        altered={"blur-distant":torch.lerp(blur,preview,weight),
                 "wrong-distant":torch.lerp(wrong,preview,weight)}
        actual=encode(model,preview,grid)
        by_policy["matching"].append(actual)
        by_policy["neutral"].append(perturb_scene(actual,"masked"))
        checks={"scene_shape":list(full.shape),"preview_shape":list(preview.shape),
                "exact_near_preview_pixels":int(near.sum()),"far_preview_pixels":int(far.sum()),
                "preview_keys":{}}
        for name,value in altered.items():
            value[...,near]=preview[...,near]
            assert torch.equal(value[...,near],preview[...,near])
            checks["preview_keys"][name]={
                     "preview":fingerprint(value.cpu()),
                     "far_change_RMS":float((value[...,far]-preview[...,far]).square().mean().sqrt())}
            by_policy[name].append(encode(model,value,grid))
        checks["preview_keys"]["matching"]={"preview":fingerprint(preview.cpu())}
        traces.append(checks)
    return by_policy,traces


def setup_models(configuration):
    models={}
    backbones=set()
    for label,bindings in configuration["models"].items():
        source=checked(bindings)
        if bindings["type"]=="base":
            model,state=load_checkpoint(source,"cuda")
            assert "ema" in state
            context=model.context
        else:
            model,state=load_scene_checkpoint(source,device="cuda",weights="ema",expected_sha256=bindings["sha256"])
            assert state["mode"]==bindings["mode"]
            context=model.base.context
        assert state["step"]==bindings["step"] and state["loaded_sha256"]==bindings["sha256"]
        model.eval().to(memory_format=torch.channels_last)
        models[label]=model
        backbones.add(model_hash(context.backbone))
        del state
        print("loaded",label,flush=True)
    assert backbones=={"691963f0f796aac860d818d59d9d14287a4675612829fbe9467c7f5df8ce5b14"}
    return models


@torch.inference_mode()
def evaluate(pilot):
    os.sched_setaffinity(0,[18,19] if pilot else [12,13])
    torch.set_num_threads(2)
    os.nice(13)
    size=5*2**30 if pilot else 9*2**30
    torch.cuda.set_per_process_memory_fraction(min(1.,size/torch.cuda.get_device_properties(0).total_memory))
    identity=ROOT/("pilot" if pilot else "evaluation")
    declared=reference(identity/"plan.json")
    fixed=read_json(checked(declared))
    assert reference(__file__)==fixed["source"]
    models=setup_models(fixed)
    spec=read_json(checked(fixed["panel"]))
    spatial=[models[k]for k,b in fixed["models"].items() if b.get("mode")=="spatial"]
    assert spatial
    output=identity/"predictions"
    output.mkdir()
    sources=[]
    first=time.monotonic()
    with ieee_fp32():
        for index in fixed["selected_indices"]:
            for profile in spec["profiles"]:
                for draw in spec["draws"]:
                    bound,settings,arrays=load(index,(profile["name"],draw))
                    raw={k:torch.from_numpy(v).cuda()for k,v in arrays.items()}
                    appearances,proof=scene_fields(spatial[0],raw,settings,spec)
                    query=[raw[k] if k in ("packed","variance") else raw[k][None].expand(3,*raw[k].shape)
                           for k in ARGS]
                    for i in range(2):
                        query[i]=query[i].contiguous(memory_format=torch.channels_last)
                    values={}
                    for model,fields in fixed["models"].items():
                        chosen=models[model]
                        base=chosen if fields["type"]=="base" else chosen.base
                        base.set_noise(profile["shot"],profile["read"])
                        if fields.get("mode")=="spatial":
                            for role, encoded in appearances.items():
                                values[f"{model}/{role}"]=chosen(*query,scene=encoded,
                                                                 boxes_xywh=[settings["box"]]*3).cpu().numpy()
                        else:
                            values[model]=chosen(*query).cpu().numpy()
                    assert all(v.shape==(3,3,256,256) and np.isfinite(v).all() and v.dtype==np.float32
                               for v in values.values())
                    for i,k in enumerate(ARGS[:2]):
                        assert fingerprint(query[i].contiguous().cpu())==settings["fingerprints"][k]
                    dest=output/f"{settings['id']}.npz"
                    with dest.open("xb")as stream:
                        # Prefix-safe names preserve model and policy in the accompanying receipt.
                        np.savez(stream,**{k.replace("/","--"):v for k,v in values.items()})
                    witness=output/f"{settings['id']}.json"
                    write_json(witness,{"plan":declared,"case":bound,"saved":reference(dest),
                             "exact_query_inputs":{k:settings["fingerprints"][k]for k in ARGS},
                             "views":proof,"inference_variants":list(values)})
                    sources.append(reference(witness))
            print("evaluated",index,len(sources),round(time.monotonic()-first,1),flush=True)
    write_json(identity/"collected.json",{"plan":declared,"records":sources,
         "inference_wall_seconds":time.monotonic()-first,"peak_GiB":torch.cuda.max_memory_allocated()/2**30,
         "scene_feature_reuse":"Frozen bit-identical DINO state verified across models. Each role/context is encoded once and interpreted by its model's scene adapter."})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pilot",action="store_true")
    parser.add_argument("--plan",action="store_true")
    args=parser.parse_args()
    freeze(args.pilot) if args.plan else evaluate(args.pilot)
