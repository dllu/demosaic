"""Apply the frozen paired analysis once the full held-out collection closes."""

import os
from pathlib import Path
import subprocess
import sys
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "reviews" / "analysis"
HELDOUT = ROOT / "reviews" / "heldout"


def analyze():
    launch = read_json(HELDOUT / "queue-launch.json")
    source = read_json(ROOT / "matched-analysis-plan.json")
    driver = checked(source["analysis_driver"])
    expected = ROOT / "evaluation" / "results.json"
    write_json(HERE / "status.json", {"stage": "waiting", "until": str(expected)}, replace=True)
    while not expected.is_file():
        if not owner_live(launch) and not expected.is_file():
            raise RuntimeError("The bound held-out reviewer exited without results")
        time.sleep(15)
    subprocess.run([sys.executable, driver, "endpoint"], env=os.environ, check=True)
    result = ROOT / "evaluation" / "matched-analysis.json"
    assert read_json(result)["results"] == reference(expected)
    write_json(HERE / "status.json", {"stage": "analyzed", "artifact": reference(result)}, replace=True)


if __name__ == "__main__":
    with exclusive_run(HERE):
        analyze()
