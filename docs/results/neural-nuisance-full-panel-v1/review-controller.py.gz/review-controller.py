import os,sys,time,subprocess
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
root=Path(sys.argv[1]);plan=read_json(root/'plan.json');launch=read_json(checked(plan['producer_launch']))
while psutil.pid_exists(launch['pid']):
 try:
  p=psutil.Process(launch['pid'])
  if p.create_time()!=launch['create_time']or p.status()==psutil.STATUS_ZOMBIE:break
 except psutil.NoSuchProcess:break
 time.sleep(5)
result=read_json(Path(plan['producer'])/'controller-result.json')
if not result['producer_stages_succeeded']:
 write_json(root/'controller-result.json',{'status':'producer-failed','producer_result':result,'review_started':False});sys.exit(1)
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=plan['work']+'/src:'+plan['work']+'/scripts',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
with(root/'review.log').open('x')as log:
 p=subprocess.Popen([plan['python'],str(checked(plan['script'])),'run',str(root)],env=env,stdout=log,stderr=subprocess.STDOUT)
 write_json(root/'review-launch.json',{'pid':p.pid,'create_time':psutil.Process(p.pid).create_time(),'plan':reference(root/'plan.json')})
 code=p.wait()
write_json(root/'controller-result.json',{'returncode':code,'status':'review-complete-awaiting-actual-viewing'if code==0 else'review-failed','plan':reference(root/'plan.json')})
