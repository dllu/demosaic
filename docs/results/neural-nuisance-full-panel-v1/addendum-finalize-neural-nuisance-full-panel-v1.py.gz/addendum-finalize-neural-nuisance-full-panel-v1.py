import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-full-review-v1"
destination = repo / "docs/results/neural-nuisance-full-panel-v1"
batches = [
    ([0,1,2,3], "All sixteen6400 near/far views across8 sources inspected: mostly parent-like flat output, exact GT shows substantial missing wires/crossings."),
    ([4,5,6,7], "All sixteen1600 near/far views inspected. Source2 has stronger slanted modulation, but weak crossed detail mostly absent. Most sources remain near parent, no general weak-direction recovery."),
    ([8,9,10,11], "All sixteen400 near/far views inspected. Sources1/2 show strongest modulation; many weak directions remain absent and source7 retains large loss. NN is generally less modulated than analytic control, consistent with response/error tradeoff."),
    ([12,13,14,15], "Materials and all protected main/cab primary/stress views inspected, both cab profiles/ROIs/JPEGs. Sky quiet, bark/fur/foliage soft. Added building bands smaller with NN. Nominal cab parallel modulation stronger but fine crossings missing; profile retains incomplete mesh/false waves. Real ISO100 remains qualitative not GT."),
    ([16], "Additional analytic-max and historical-failure building boards plus source1/source7 native triplets inspected. NN reduces added analytic bands; most weak source7 structure remains missing. No real-reference score inferred."),
]
for i, (sheets, note) in enumerate(batches):
    write_json(root / f"viewing-batch-{i}.json", {"sheets": sheets, "actually_viewed": True,
        "method": "Exact unresized native contact sheets through tools.view_image", "notes": note})
prepared = read_json(root / "publication-prepared.json")
manifest = read_json(root / "contact-sheets/manifest.json")
assert len(prepared["images"]) == manifest["source_images"] == 68
assert sorted(i for sheets, _ in batches for i in sheets) == list(range(len(manifest["sheets"])))
archives = list(prepared["archives"])
for source in [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *sorted(root.glob("viewing-batch-*.json")), repo / ".cache/native-contact-sheets-v1.py", Path(__file__)]:
    target = destination / ("addendum-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})
for item in archives:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in prepared["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
prepared.update(archives=archives,
    viewing={"actually_viewed": True, "figures": 68, "contact_sheets": 17,
             "manifest": reference(root / "contact-sheets/manifest.json"),
             "batches": [reference(p) for p in sorted(root.glob("viewing-batch-*.json"))]},
    status="complete full producer/audit/statistics/native review",
    quality_decision="Useful quieter alternative to conditional analytic H1 across all6 noise/placement cells, with lower weak response at400/far. Parent weak-increment error still slightly lower; source1 drives most mean response gain. Fine real crossings remain unresolved; no general model promotion.",
    summary=reference(root / "summary.json"), published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination / "publication.json", prepared)
print(len(archives), "exact archives;4560 bundled case receipts;68 actually viewed source figures")
