"""Publish inspected native crops and bind the reserve-selection replays."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
partner = root.parent / "reserved-wire-partner-v1"
results = Path("docs/results") / root.name
images = Path("docs/images") / root.name
summary = root / "review/summary.json"
stages = read_json(summary)
synthetic = read_json(root / "review/synthetic.json")["rows"]
photos = read_json(root / "review/camera.json")["rows"]
assert len(synthetic) == 2 and len(photos) == 8
results.mkdir()
images.mkdir()


def copy(binding):
    source = checked(binding)
    destination = images / source.name
    shutil.copyfile(source, destination)
    assert reference(destination)["sha256"] == binding["sha256"]
    return destination.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Inspected two synthetic native triplets, their full comparisons, "
        "and eight GFX native crop boards with independently captured qualitative references.",
        "synthetic": [
            r | {k: r[k] | {"file": copy(r[k]["image"])} for k in ("board", "triplet")}
            for r in synthetic
        ],
        "camera": [r | {"file": copy(r["image"])} for r in photos],
    },
)
summary_path = results / "summary.json"
shutil.copyfile(summary, summary_path)
assert reference(summary_path)["sha256"] == reference(summary)["sha256"]

panel_names = list(stages["stages"])
files = ["plan.json", *(f"{p}.{suffix}" for p in panel_names for suffix in ("json", "log"))]
members = {
    root: files
    + [
        "review.py",
        "publish.py",
        "review/camera.json",
        "review/camera-before-partner.json",
        "review/synthetic.json",
        "review/summary.json",
        "tests.log",
        "work/src/demosaic/reserved_wire_footprint.py",
        "work/scripts/probe_reserved_wire_footprint.py",
        "work/scripts/probe_fresh_wire_envelopes.py",
    ],
    partner: files + ["work/scripts/probe_reserved_wire_footprint.py"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            source = folder / name
            meta = bundle.gettarinfo(str(source), arcname=f"{folder.name}/{name}")
            meta.mtime = meta.uid = meta.gid = 0
            meta.uname = meta.gname = ""
            with source.open("rb") as data:
                bundle.addfile(meta, data)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )

write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary_path),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
