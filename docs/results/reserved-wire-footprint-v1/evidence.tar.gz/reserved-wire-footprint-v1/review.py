"""Bind reserved footprint selection to crop, null and camera metrics."""

import argparse
from itertools import product
from pathlib import Path

import numpy as np
from probe_fresh_wire_envelopes import targets
from probe_reserved_wire_footprint import PANELS
from report_fold_support_pooling import insert_camera_panels
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PARTNER = ROOT.parent / "reserved-wire-partner-v1"


def reduce_metrics(rows):
    grouped = {}
    for key in rows[0]["metrics"]:
        metrics = [r["metrics"][key] for r in rows]
        scores = {}
        for metric in metrics[0]:
            v = np.asarray([m[metric] for m in metrics])
            if metric.endswith("RMS_DN16"):
                score = np.sqrt(np.mean(v**2))
            elif metric == "peak_DN16":
                score = v.max()
            elif metric == "changed_pixels":
                metric, score = "changed_cases", np.count_nonzero(v)
            elif metric == "absent_weak_projection":
                metric, score = "absolute_" + metric, np.abs(v).mean()
            else:
                score = v.mean()
            scores[metric] = float(score)
        grouped[key] = scores
    return grouped


def selection_stats(rows, paired):
    result = {}
    for arm in ("admitted", "confirmed"):
        chosen = [r["selection"][1] if paired else r["selection"] for r in rows]
        winners = [r["winner"] for r in chosen if r.get(arm, False)]
        item = {
            "cases": len(rows),
            "localized": len(winners),
            "directions": [sum(w["direction"] == index for w in winners) for index in (0, 1)],
        }
        if paired:
            errors = [r["center_error_px"] for r in chosen if r.get(arm, False)]
            item["median_error_px"] = float(np.median(errors)) if errors else None
            item["within_24_px"] = sum(e <= 24 for e in errors)
        result[arm] = item
    return result


def group_rows(rows, label):
    groups = {"all": rows}
    if label.startswith("null"):
        for key, styles in {
            "flat": {"flat"},
            "straight": {"step", "rail"},
            "complex": {"wedge", "bent-rail", "two-rails"},
        }.items():
            groups[key] = [r for r in rows if r["style"] in styles]
    else:
        groups["planar"] = [r for r in rows if not r["chirped_signed_color"]]
        groups["chirped"] = [r for r in rows if r["chirped_signed_color"]]
    return {
        key: {
            "n": len(g),
            "selection": selection_stats(g, not label.startswith("null")),
            "metrics": reduce_metrics(g),
        }
        for key, g in groups.items()
    }


def native_synthetic(out, plan):
    crops = []
    for label, idx in (("fresh400", 2), ("offset400", 4)):
        row = read_json(ROOT / f"{label}.json")["rows"][idx]
        assert row["case"] == idx
        peer = read_json(PARTNER / f"{label}.json")["rows"][idx]
        assert peer["case"] == row["case"] and peer["selection"] == row["selection"]
        with np.load(checked(row["prediction"])) as f, np.load(checked(peer["prediction"])) as g:
            ctx = {
                "packed": f["packed"][None],
                "colors": f["cfa"][None],
                "wb": np.ones((1, 3)),
                "matrix": np.eye(3)[None],
            }
            parent = f["parent"].astype(float)
            scale = plan["settings"]["iso400"]["scale"]
            modes = ("uniform", "centered", "screened", "confirmed")
            restored = [parent + scale * (f[k] - parent) for k in modes]
            np.testing.assert_array_equal(f["uniform"], g["uniform"])
            partner = parent + scale * (g["partner"] - parent)
            preview = [noisy_malvar(ctx)[0], parent, *restored, partner, f["target"]]
        roi = [48, 48, 160, 160]
        crops.append(
            native_board(
                out,
                f"{label}-case{idx}",
                preview,
                ctx,
                {
                    "ROI_xywh": roi,
                    "source": label,
                    "case": idx,
                    "CFA": row["CFA"],
                    "case_prediction": row["prediction"],
                    "partner_prediction": peer["prediction"],
                    "selection": row["selection"],
                    "checkpoint_sha256": None,
                    "parent": "Analytic rail-only target",
                    "noise": plan["profiles"]["iso400"],
                    "operating": plan["settings"]["iso400"],
                    "color_transform": "Fixed clipped sRGB, identity WB and camera matrix",
                },
                labels=(
                    "Noisy Malvar",
                    "Analytic rail",
                    "Uniform",
                    "Fixed center",
                    "Screened location",
                    "Confirmed location",
                    "Partner only",
                    "Exact GT",
                ),
                exposure=4,
                roi=roi,
                triplet_indices=(0, 6, 7),
            )
        )
    return crops


def real_camera(out, plan):
    old = read_json(checked(plan["camera_plan"]))
    baseline = read_json(checked(old["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"] for r in read_json(checked(old["camera_conditions"]))["camera"]
    }
    control_path = ROOT.parent / "wire-envelope-camera-v1/camera.json"
    previous = read_json(control_path)["comparison"]
    done = read_json(ROOT / "camera.json")["rows"]
    peers = read_json(PARTNER / "camera.json")["rows"]
    names = {
        f"{family}-{arm}": f"{family.title()} {label}"
        for family, (arm, label) in product(
            ("scene", "spectral"),
            (
                ("uniform", "uniform"),
                ("screened", "screened"),
                ("confirmed", "confirmed"),
                ("partner", "partner"),
            ),
        )
    }
    rows = []
    for recent, other, source, before in zip(done, peers, baseline, previous, strict=True):
        key, info = recent["id"], source["source"]
        assert key == other["id"] == before["id"] == source["id"]
        assert recent["flexible_edges"] == other["flexible_edges"]
        x, y, w, h = source["ROI_xywh"]
        qx, qy, *_ = info["query_box"]
        crop = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(info["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = source["display_exposure"]
        extra = []
        stats = {}
        with (
            np.load(checked(recent["predictions"])) as arrays,
            np.load(checked(before["predictions"])) as control,
            np.load(checked(other["predictions"])) as partner,
        ):
            parent = arrays["parent"][crop].astype(float)
            for arm, title in names.items():
                candidate = partner[arm] if arm.endswith("-partner") else arrays[arm]
                if arm.endswith("-uniform"):
                    target = arm.removesuffix("-uniform") + "-fundamental"
                    np.testing.assert_array_equal(candidate, control[target])
                    np.testing.assert_array_equal(candidate, partner[arm])
                    np.testing.assert_array_equal(
                        arrays[arm + "-strict"], control[target + "-strict"]
                    )
                pixels = display(candidate[None], ctx, exposure=exposure)[0][crop].transpose(
                    1, 2, 0
                )
                extra.append((title, np.rint(pixels * 255).astype(np.uint8)))
                stats[arm] = float(np.sqrt(np.mean((candidate[crop] - parent) ** 2)) * 65535)
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in source["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            out, key, source | {"panels": panels}, "V120 EMA", extra
        )
        ax, ay, *_ = info["absolute_query_xywh"]
        rows.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "noise": noise[key],
                "checkpoint": info["checkpoint"],
                "display_exposure": exposure,
                "ROI_xywh": [ax + x - qx, ay + y - qy, w, h],
                "CFA": "RGGB",
                "source_calibration": info["query_arrays"],
                "prediction": recent["predictions"],
                "partner_prediction": other["predictions"],
                "selection": recent["flexible_edges"],
                "reference": before["reference"],
                "RMS_from_V120_DN16": stats,
            }
        )
    return rows


def render_panels(mode):
    plan = read_json(ROOT / "plan.json")
    out = ROOT / "review"
    out.mkdir(exist_ok=True)
    if mode == "synthetic":
        write_json(out / "synthetic.json", {"rows": native_synthetic(out, plan)})
    else:
        write_json(out / "camera.json", {"rows": real_camera(out, plan)})


def compare_quiet(rows, label, plan):
    archived = label.startswith("fresh")
    seed = plan["fresh_seed"] if archived else plan["prospective_geometry"]["seed"]
    span = 35 if archived else plan["prospective_geometry"]["along_limit"]
    terms = {a: [] for a in rows[0]["metrics"] if not a.endswith("-strict")}
    for row in rows:
        _, strong, both, *_ = targets(row["case"], seed, along_limit=span)
        truth = np.mean(((both.astype(float) - strong) * 65535) ** 2)
        for arm, samples in terms.items():
            m = row["metrics"][arm]
            cross = 2 * m["weak_projection"] * truth
            power = m["increment_RMS_DN16"] ** 2 - truth + cross
            assert power >= -1e-8
            samples.append(
                [truth, cross, max(0, power), m["quiet_RMS_DN16"] ** 2, m["weak_projection"]]
            )
    terms = {k: np.mean(v, axis=0) for k, v in terms.items()}
    budget = terms["uniform"][3]
    result = {}
    for name, (t, c, p, q, response) in terms.items():
        factor = min(1.0, np.sqrt(budget / q)) if q else 1.0
        result[name] = {
            "fixed_scale_multiplier": float(factor),
            "quiet_RMS_DN16": float(factor * np.sqrt(q)),
            "weak_projection": float(response * factor),
            "increment_RMS_DN16": float(np.sqrt(t - factor * c + factor**2 * p)),
        }
    return result


def reduce_all():
    plan = read_json(ROOT / "plan.json")
    stages = {p: reference(ROOT / f"{p}.json") for p in PANELS}
    peers = {p: reference(PARTNER / f"{p}.json") for p in PANELS}
    data = {p: read_json(checked(stages[p]))["rows"] for p in PANELS}
    assert [len(data[p]) for p in PANELS] == [8, 8, 8, 8, 24, 24, 8]
    for panel, rows in data.items():
        if panel == "camera":
            continue
        other = read_json(checked(peers[panel]))["rows"]
        for row, peer in zip(rows, other, strict=True):
            assert row["selection"] == peer["selection"]
            for key in ("uniform", "uniform-strict"):
                assert row["metrics"][key] == peer["metrics"][key]
            row["metrics"].update(
                {k: m for k, m in peer["metrics"].items() if k.startswith("partner")}
            )
        if panel.startswith("null"):
            noise = "iso6400" if panel.endswith("6400") else "iso400"
            previous = ROOT.parent / f"wire-envelope-controls-v1/{noise}.json"
            for row, old in zip(rows, read_json(previous)["rows"], strict=True):
                for key in ("style", "profile", "trial"):
                    assert row[key] == old[key]
                for suffix in ("", "-strict"):
                    assert (
                        row["metrics"]["uniform" + suffix]
                        == old["metrics"]["uniform-fundamental" + suffix]
                    )
    full = {p: group_rows(data[p], p) for p in PANELS if p != "camera"}
    full["null-pooled"] = group_rows(data["null400"] + data["null6400"], "null")
    caps = {p: compare_quiet(data[p], p, plan) for p in PANELS if p.startswith(("offset", "fresh"))}
    photos = read_json(ROOT / "review/camera.json")["rows"]
    write_json(
        ROOT / "review" / "summary.json",
        {
            "plan": reference(ROOT / "plan.json"),
            "producer": reference(__file__),
            "stages": stages,
            "partner_stages": peers,
            "results": full,
            "quiet_caps": caps,
            "camera": [
                {k: r[k] for k in ("id", "RMS_from_V120_DN16", "noise", "checkpoint")}
                for r in photos
            ],
            "new_checkpoint": None,
        },
    )


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("mode", choices=("synthetic", "camera", "reduce"))
    opts = cli.parse_args()
    if opts.mode == "reduce":
        reduce_all()
    else:
        render_panels(opts.mode)
