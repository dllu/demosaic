"""Fit and test noise-conditioned delivery of the measured Bayer residual."""

import argparse
from collections import defaultdict
from itertools import product
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from report_checkpoint_pilot import band as material_band
from report_full_faint_photo_panel import band, band_sums, blocks, original_masks, source_balance
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import linear_rgb, noisy_malvar, photometry
from demosaic.cfa import bilinear, malvar, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prior import box_mean

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT.parent
DEV = ARTIFACTS / "full-corpus-long86k-faint-noise-v1"
GFX = ARTIFACTS / "full-corpus-long86k-native-v1"
LUMA = np.asarray([0.2126, 0.7152, 0.0722])
DN16 = 65535
WIDTHS = (0, 2, 4, 8, 16, 32, 64)
ROI = np.s_[..., 48:208, 48:208]
POLICIES = ("raw", "single", "split")


def inputs_and_variants(root, accept=lambda obs: True):
    plan_path, result_path = root / "plan.json", root / "collection/result.json"
    plan_binding = reference(plan_path)
    plan, collected = read_json(plan_path), read_json(result_path)
    assert collected["plan"] == plan_binding
    for obs, receipt in zip(plan["observations"], collected["records"], strict=True):
        if not accept(obs):
            continue
        saved = read_json(checked(receipt))
        assert saved["id"] == obs["id"] and saved["input_fingerprints"] == obs["input_fingerprints"]
        with np.load(checked(obs["arrays"])) as f:
            inputs = {k: f[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
        predictions = {}
        for p in saved["variants"]:
            label = p["label"]
            assert p["checkpoint"] == plan["models"][label]["checkpoint"]
            predictions[label] = np.load(checked(p["prediction"]))
        yield obs, inputs, predictions, plan["models"]


def residuals(prediction, arrays, shot, read):
    p = torch.from_numpy(prediction)
    y, c, wb = (torch.from_numpy(arrays[k]) for k in ("packed", "colors", "wb"))
    measured = mosaic(p, c)
    quantizer_step = 1 / (DN16 * 0.97)
    sigma = (shot * measured.clamp(0, 1) + read + quantizer_step**2 / 12).sqrt()
    lower_limit = -0.03 / 0.97
    valid = (y > lower_limit + 2 * sigma) & (y < 1 - 2 * sigma)
    innovation = torch.where(valid, y - measured, 0)
    mask = valid.to(y.dtype)
    low = box_mean(innovation, 7) / box_mean(mask, 7).clamp_min(1 / 49)
    low *= mask
    return c, wb, sigma * DN16, innovation, low


def delivery(parts, kind, width):
    colors, wb, sigma_dn16, innovation, low = parts
    weight = width / (width + sigma_dn16)
    if kind == "single":
        return malvar(weight * innovation, colors, wb).numpy()
    if kind == "fine":
        return malvar(weight * (innovation - low), colors, wb).numpy()
    if kind == "coarse":
        return bilinear(weight * low, colors).numpy()
    raise ValueError(kind)


def corrected(prediction, arrays, noise, fit):
    args = (noise["shot"], noise["read"])
    assert max(args) > 0 and min(args) >= 0
    parts = residuals(prediction, arrays, *args)
    return {
        "raw": prediction,
        "single": prediction + delivery(parts, "single", fit["single"]["width"]),
        "split": prediction
        + delivery(parts, "fine", fit["split"]["fine_width"])
        + delivery(parts, "coarse", fit["split"]["coarse_width"]),
    }


def select_blocks(target):
    coefficients, means = material_band(target)
    block_rms = np.linalg.norm(coefficients[0], axis=-1) / 16
    valid = ((target[0] >= 0) & (target[0] <= 1)).all(0)
    valid = valid.reshape(10, 16, 10, 16).transpose(0, 2, 1, 3).reshape(100, 256).all(1)
    valid &= (means[0] >= 0.02) & (means[0] <= 0.9)
    return valid & (block_rms >= 1e-5) & (block_rms < 0.02 * means[0])


def vector(image, mask):
    return image.ravel(), material_band(image)[0][0, mask].ravel()


def calibration_case(p, t, a, noise):
    parts = residuals(p, a, noise["shot"], noise["read"])
    target = linear_rgb(t[ROI], a)
    mask = select_blocks(target)
    error = vector(linear_rgb(p[ROI], a) - target, mask)
    tags = [(k, w) for k in ("single", "fine", "coarse") for w in WIDTHS]
    terms = list(zip(*(vector(linear_rgb(delivery(parts, k, w)[ROI], a), mask) for k, w in tags)))
    gram = np.zeros((1 + len(tags), 1 + len(tags)), dtype=np.float64)
    for e, entries in zip(error, terms, strict=True):
        matrix = np.row_stack((e, *entries))
        gram += (matrix @ matrix.T) / np.dot(e, e) / len(error)
    return tags, gram


@torch.inference_mode()
def calibrate():
    rows, grams = [], []
    for o, a, predictions, _ in inputs_and_variants(DEV):
        with np.load(checked(o["target"])) as data:
            t = data["target"]
        for model, p in predictions.items():
            tags, g = calibration_case(p, t, a, o["noise"])
            rows.append({"observation": o["id"], "model": model, "gram": g.tolist()})
            grams.append(g)
    assert len(grams) == 96
    g = np.mean(grams, axis=0)
    candidate = {}
    for key, search in {
        "single": [((1 + tags.index(("single", w)),), {"width": w}) for w in WIDTHS],
        "split": [
            ((1 + tags.index(("fine", f)), 1 + tags.index(("coarse", c))), {"fine_width": f, "coarse_width": c})
            for f, c in product(WIDTHS, repeat=2)
        ],
    }.items():
        trials = []
        for indices, fields in search:
            select = (0, *indices)
            trials.append(fields | {"calibration_normalized_error": float(g[np.ix_(select, select)].sum())})
        candidate[key] = min(trials, key=lambda row: row["calibration_normalized_error"]) | {"trials": trials}
    write_json(ROOT / "calibration.json", {
        "producer": reference(__file__), "terms": tags,
        "calibration_plan": reference(DEV / "plan.json"),
        "calibration_collection": reference(DEV / "collection/result.json"),
        "heldout_plan": reference(ROOT / "plan.json"),
        "objective": "Equal mean of baseline-normalized linear RGB squared error and weak-band luma "
        "squared error, first per observation and model, then balanced over 96 retained predictions.",
        "parameters": candidate, "rows": rows,
    })
    print({k: {a: b for a, b in v.items() if a != "trials"} for k, v in candidate.items()}, flush=True)


def score(o, arrays, predictions, fit):
    rendered = {model: corrected(p, arrays, o["noise"], fit) for model, p in predictions.items()}
    with np.load(checked(o["target"])) as data:
        target, original = (data[k] for k in ("target", "original_target"))
    masks = original_masks(original, arrays)
    target_band = band(np.einsum("c,bchw->bhw", LUMA, linear_rgb(target, arrays)))
    rows = []
    for model, policies in rendered.items():
        for name, p in policies.items():
            rgb = linear_rgb(p, arrays)
            estimate = band(np.einsum("c,bchw->bhw", LUMA, rgb))
            pp = photometry(p, arrays | {"target": target})
            reference_rgb = linear_rgb(target, arrays)
            error_blocks = blocks(rgb-reference_rgb)
            mottle = np.sqrt(np.mean(error_blocks.mean((-2, -1))**2, axis=(1, 2)))
            for i, fields in enumerate(band_sums(estimate, target_band, masks)):
                rows.append({
                    "source": o["source_ids"][i], "CFA": o["pattern"], "profile": o["noise"]["name"],
                    "model": model, "policy": name, "band_sums": fields,
                    "PSNR_sRGB": float(pp["srgb_psnr"][i]),
                    "block_mean_error_DN16": float(DN16*mottle[i]),
                })
    return rows, rendered, target


def photos(fit, boards):
    plan = read_json(ROOT / "plan.json")
    selected = sorted(s for group in plan["source_groups"] for s in group)[:2]
    all_rows = defaultdict(list)
    for shard in plan["heldout"]:
        root = checked(shard).parent
        for o, a, preds, models in inputs_and_variants(root):
            rows, rendered, target = score(o, a, preds, fit)
            all_rows[o["noise"]["name"]].extend(rows)
            if o["pattern"] != "RGGB" or o["noise"]["name"] not in ("small-positive", "iso6400-prior"):
                continue
            for i, s in enumerate(o["source_ids"]):
                if s not in selected:
                    continue
                local = {k: a[k][i:i+1] for k in ("packed", "colors", "wb", "matrix")}
                model = rendered["scale-long86k"]
                frame = native_board(
                    ROOT / "review", f"{s}-{o['noise']['name']}",
                    [noisy_malvar(local)[0], *(model[n][i] for n in POLICIES), target[i]], local,
                    {"source": s, "models": models, "observation": o, "conditioning": o["noise"], "CFA": o["pattern"]},
                    exposure=1, contrast=20 if o["noise"]["name"] == "small-positive" else 4,
                    labels=("Noisy Malvar", "86k raw EMA", "86k single", "86k split", "Exact GT"),
                    triplet_indices=(0, 2, 4),
                )
                boards.append(frame)
    summary = []
    for profile, rows in all_rows.items():
        assert len(rows) == 16 * 4 * len(POLICIES) * 2
        by_angle = source_balance(rows)
        for (model, policy) in product(("V120", "scale-long86k"), POLICIES):
            items = [r for r in by_angle if r["model"] == model and r["policy"] == policy]
            selected = [r for r in rows if r["model"] == model and r["policy"] == policy]
            target_fields = {fn: mean(r[fn] for r in selected) for fn in ("PSNR_sRGB", "block_mean_error_DN16")}
            for case in ("0", "quiet"):
                r = next((k for k in items if k["band"] == case), None)
                target_fields[f"band_{case}"] = r
            summary.append({"profile": profile, "model": model, "policy": policy} | target_fields)
    assert len(boards) == 4
    return dict(all_rows), summary


@torch.inference_mode()
def review():
    fit = read_json(ROOT / "calibration.json")["parameters"]
    (ROOT / "review").mkdir()
    boards = []
    grouped, summary = photos(fit, boards)
    write_json(ROOT / "review" / "photos.json", {
        "producer": reference(__file__), "calibration": reference(ROOT / "calibration.json"),
        "plan": reference(ROOT / "plan.json"), "boards": boards, "observations": grouped, "summary": summary,
    })
    for r in summary:
        print(r["profile"], r["model"], r["policy"], round(r["PSNR_sRGB"], 5),
              round(r["band_0"]["equal_source_RMS_DN16"], 5), round(r["block_mean_error_DN16"], 4), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("calibrate", "review"))
    args = parser.parse_args()
    torch.set_num_threads(2)
    (calibrate if args.stage == "calibrate" else review)()
