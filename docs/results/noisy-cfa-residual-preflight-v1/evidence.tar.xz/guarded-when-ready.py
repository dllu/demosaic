"""Wait for the same two collection handles and score the frozen low-noise guard."""

from importlib.machinery import SourceFileLoader
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent
runner = SourceFileLoader("study_review_queue", str(SCRIPT / "review-when-ready.py")).load_module()
runner.review("guarded-review", [SCRIPT / "heldout-0", SCRIPT / "heldout-1"],
              ("guarded.py", str(SCRIPT / "guarded-declaration.json")))
