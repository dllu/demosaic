"""Measure actual recorded noise-prior coverage through update 86,000."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "full-corpus-long86k-native-v1/source-audit.json"


def main():
    prefix = read_json(SOURCE)
    segments = (1000, 86000)
    grouped = defaultdict(list)
    receipts, expected = [], 1
    for stage, stop in zip(prefix["source_prefixes"], segments, strict=True):
        phase = Path(stage["path"]).parent
        for p in sorted(phase.glob("conditions-*.npz")):
            first, end = map(int, p.stem.split("-")[1:])
            if first > stop:
                continue
            assert first == expected and end <= stop
            binding = reference(p)
            with np.load(checked(binding)) as f:
                np.testing.assert_array_equal(f["steps"], np.arange(first, end+1))
                noise = f["values"][..., :2]
                domains = f["domains"]
                assert noise.shape == (end-first+1, 16, 2) and (noise >= 0).all()
            for domain in set(domains):
                grouped[str(domain)].append(noise[domains == domain].reshape(-1, 2))
            expected = end+1
            receipts.append(binding)
    assert expected == 86001 and len(receipts) == 344
    result = []
    for domain, values in sorted(grouped.items()):
        x = np.concatenate(values).astype(float)
        sigma = (x.sum(axis=1)**.5) * (65535 * .97)
        active = sigma > 0
        result.append({
            "domain": domain, "examples": len(x), "ADC_only": int((~active).sum()),
            "positive_at_most_8_codes": int((active & (sigma <= 8)).sum()),
            "positive_min_p01_median_full_signal_sigma_codes":
                np.quantile(sigma[active], [0, .01, .5]).tolist(),
        })
    assert sum(r["examples"] for r in result) == 1376000
    assert {r["domain"]: r["examples"]//16 for r in result} == prefix["domain_updates"]
    write_json(ROOT / "training-noise-audit.json", {
        "source": reference(__file__), "training_prefix": reference(SOURCE),
        "condition_records": receipts, "coverage": result,
        "scope": "Executed diagnostic prefix 86k; logged shot/read used as noise conditioning. "
        "These full-signal noise units are not observed image-noise statistics.",
    })
    print(result)


if __name__ == "__main__":
    main()
