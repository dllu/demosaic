"""Cross physical ADC observations with model conditioning at the smallest noise level."""

from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent


def main():
    torch.set_num_threads(1)
    source = ROOT / "nulls"
    plan = read_json(source / "plan.json")
    out = ROOT / "conditioning"
    out.mkdir()
    selected = [o for o in plan["observations"] if o["noise"]["name"] == "small-positive"
                and o["pattern"] in ("RGGB", "GBRG")]
    assert len(selected) == 2
    observations = []
    for original in selected:
        with np.load(checked(original["arrays"])) as data:
            observed = dict(data)
        with np.load(checked(original["target"])) as data:
            target = torch.from_numpy(data["target"])
        quantized = add_noise(mosaic(target, torch.from_numpy(observed["colors"])), 0, 0,
                              bit_depth=16, black_level=.03,
                              generator=torch.Generator().manual_seed(0))
        array_path = out / (original["pattern"] + "-adc-center.npz")
        args = observed | {"packed": quantized.numpy()}
        with array_path.open("xb") as f:
            np.savez(f, **args)
        clean = original | {"arrays": reference(array_path),
                            "input_fingerprints": {k: fingerprint(v) for k, v in args.items()}}
        for raw_name, source_obs in (("positive-observation", original), ("adc-observation", clean)):
            for policy in ("positive", "zero"):
                if raw_name == "positive-observation" and policy == "positive":
                    continue
                conditioning = dict(original["noise"])
                if policy == "zero":
                    conditioning.update({"name": "conditioning-zero", "shot": 0.0, "read": 0.0})
                observations.append(source_obs | {
                    "id": f"{original['pattern']}-{raw_name}-as-{policy}",
                    "noise": conditioning, "physical_noise_label": raw_name, "condition_policy": policy,
                    "origin": original["id"],
                })
    assert len(observations) == 6
    write_json(out / "plan.json", plan | {
        "root": str(out), "observations": observations,
        "inputs": [*plan["inputs"], reference(source / "plan.json"),
                   reference(source / "collection/result.json"), reference(__file__)],
        "CPU_affinity": [16,17], "maximum_seconds": 1200, "batch_histogram": {"4": 6},
        "planned_root_calls": 12, "planned_DINO_executions": 6,
        "scope": "Fixed diagnostic cross on the first and last Bayer layout. Exact ADC center compared to "
        "one tiny-noise observation. For each measurement, all five tensors remain identical across "
        "the two conditioning values; only transient model shot/read metadata varies. Variance tensor "
        "from the tiny-noise source retained across all four arms. No new camera or photographic data.",
    })


if __name__ == "__main__":
    main()
