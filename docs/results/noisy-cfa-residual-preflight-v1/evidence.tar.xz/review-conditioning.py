"""Assess the frozen model's sensitivity to matched shot/read conditioning."""

from itertools import product
from pathlib import Path

import numpy as np
from probe import DN16, ROOT, inputs_and_variants
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    out = ROOT / "conditioning-review"
    out.mkdir()
    null_root, new_root = (ROOT / k for k in ("nulls", "conditioning"))
    cases = {}
    for o, a, predictions, models in inputs_and_variants(
        null_root, lambda o: o["noise"]["name"] == "small-positive" and o["pattern"] in ("RGGB", "GBRG")
    ):
        cases[o["pattern"], "positive-observation", "positive"] = (o, a, predictions, models)
    for o, a, predictions, models in inputs_and_variants(new_root):
        assert o["origin"] == cases[o["pattern"], "positive-observation", "positive"][0]["id"]
        cases[o["pattern"], o["physical_noise_label"], o["condition_policy"]] = (o, a, predictions, models)
    assert len(cases) == 8
    rows, boards = [], []
    order = (
        ("positive-observation", "positive"), ("positive-observation", "zero"),
        ("adc-observation", "positive"), ("adc-observation", "zero"),
    )
    for cfa in ("RGGB", "GBRG"):
        selected = [cases[(cfa, *k)] for k in order]
        assert selected[0][0]["input_fingerprints"] == selected[1][0]["input_fingerprints"]
        assert selected[2][0]["input_fingerprints"] == selected[3][0]["input_fingerprints"]
        assert selected[0][0]["input_fingerprints"]["packed"] != selected[2][0]["input_fingerprints"]["packed"]
        for name in ("variance", "colors", "wb", "matrix"):
            assert len({o["input_fingerprints"][name]["sha256"] for o, *_ in selected}) == 1
        assert all(e[0]["target"] == selected[0][0]["target"] for e in selected)
        first, a, _, models = selected[0]
        with np.load(checked(first["target"])) as f:
            t = f["target"]
        for ((measurements, conditioning), (o, _, predictions, _)) in zip(order, selected, strict=True):
            for model, prediction in predictions.items():
                error = (prediction.astype(float) - t)[..., 48:208, 48:208] * DN16
                bias = np.abs(np.mean(error, axis=(-2,-1))).max(axis=1)
                rms = np.sqrt(np.mean(error**2, axis=(-3,-2,-1)))
                for i, material in enumerate(o["source_ids"]):
                    row = {"CFA": cfa, "observation": measurements, "conditioning": conditioning,
                           "model": model, "source": material,
                           "max_abs_channel_mean_DN16": float(bias[i]), "RMS_DN16": float(rms[i])}
                    rows.append(row)
                    if material == "bright-yellow":
                        print(row, flush=True)
        index = first["source_ids"].index("bright-yellow")
        local = {k: a[k][index:index+1] for k in ("packed","colors","wb","matrix")}
        boards.append(native_board(
            out, "yellow-" + cfa, [noisy_malvar(local)[0], *[entry[2]["scale-long86k"][index] for entry in selected], t[index]],
            local, {"source": "bright-yellow", "CFA": cfa, "cases": [r[0] for r in selected], "models": models},
            exposure=1,
            labels=("Noisy Malvar", "Tiny-noise input/cond.", "Tiny-noise input/zero cond.",
                    "ADC input/tiny-noise cond.", "ADC input/zero cond.", "Exact GT"),
            triplet_indices=(0,2,5),
        ))
    assert len(rows) == 64 and len(boards) == 2
    write_json(out / "result.json", {
        "source": reference(__file__), "base_plan": reference(null_root / "plan.json"),
        "collection": reference(new_root / "collection/result.json"), "base_collection": reference(null_root / "collection/result.json"),
        "plan": reference(new_root / "plan.json"), "rows": rows, "boards": boards,
    })


if __name__ == "__main__":
    main()
