"""Bind the zero-conditioned tiny-noise replay on the twelve unseen source IDs."""

from collections import Counter
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def main():
    study = read_json(ROOT / "plan.json")
    first = read_json(ROOT / "first-heldout-group/result.json")
    excluded = {row["source"] for rows in first["rows"].values() for row in rows}
    assert len(excluded) == 4
    chosen = []
    for p in study["heldout"]:
        plan = read_json(checked(p))
        for o in plan["observations"]:
            if o["noise"]["name"] == "small-positive" and not excluded.intersection(o["source_ids"]):
                chosen.append((o, p))
    assert len(chosen) == 12
    assert set(Counter(s for o, _ in chosen for s in o["source_ids"]).values()) == {4}
    base = read_json(checked(study["heldout"][0]))
    refs = []
    for i, cpus in enumerate(([6,7], [16,17])):
        sub = ROOT / f"photo-conditioning-{i}"
        sub.mkdir()
        selected = []
        for obs, parent in chosen[i::2]:
            selected.append(obs | {
                "id": obs["id"] + "-as-zero", "positive_input": obs["id"],
                "positive_plan": parent, "measurement_noise": obs["noise"],
                "noise": obs["noise"] | {"name": "conditioning-zero", "shot": 0.0, "read": 0.0},
            })
        path = sub / "plan.json"
        write_json(path, base | {
            "root": str(sub), "observations": selected, "CPU_affinity": cpus, "maximum_seconds": 1800,
            "planned_root_calls": 12, "planned_DINO_executions": 6, "batch_histogram": {"4": 6},
            "inputs": [*base["inputs"], reference(ROOT/"plan.json"), reference(ROOT/"guarded-declaration.json"), reference(__file__)],
            "scope": "Twelve photographic sources outside the four used to choose the low-noise guard. "
            "Same packed/variance/CFA/WB/matrix, one explicit zero-noise conditioning replay for both "
            "models. Used only for an experimental crossed-conditioning quality comparison.",
        })
        refs.append(reference(path))
    write_json(ROOT / "photo-conditioning-plan.json", {
        "source": reference(__file__), "shards": refs, "excluded_source_ids": sorted(excluded),
        "closed_adverse_control": reference(ROOT/"conditioning-review/result.json"),
    })


if __name__ == "__main__":
    main()
