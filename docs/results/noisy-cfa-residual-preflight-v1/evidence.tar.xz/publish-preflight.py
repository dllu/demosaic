"""Release the completed parts of the positive-noise study with viewed native pages."""

import os
import shutil
import tarfile
from pathlib import Path

import psutil
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
VERSION = "noisy-cfa-residual-preflight-v1"
OUT, IMAGES = Path("docs/results")/VERSION, Path("docs/images")/VERSION
RESULTS = {
    "photos": "first-heldout-group/result.json",
    "null": "nulls-review/result.json",
    "null-adverse": "null-adverse/result.json",
    "conditioning": "conditioning-review/result.json",
    "interval": "large-disagreement/result.json",
    "gfx": "camera-review/result.json",
}
TRAINING = ROOT/"training-noise-audit.json"
INPUT_AUDIT = ROOT/"inputs-audit.json"
VIEW_NOTES = {
    "photos": "Inspected comparisons and triplets for the selected ornate interior and red engraving. The smallest positive noise lift clarifies a few contour segments. Fine detail remains soft in both.",
    "null": "Viewed intermediate slanted edge and ISO100 yellow. No discrete new edge or periodic profile is visible. Yellow color changes are modest in clipped sRGB.",
    "null-adverse": "Viewed lowest and intermediate positive noise yellow. Both show a visible hue change, small on screen compared with the unclipped sensor-linear bias.",
    "conditioning": "Viewed RGGB and GBRG. Both positive-conditioned columns show a yellow cast, including the ADC image. The zero-conditioned renders lose the visible cast.",
    "interval": "Viewed lowest-positive RGGB yellow. The interval-excess correction is much closer in hue to the exact reference.",
    "gfx": "Viewed eight boards, both cab sides and profiles, both SOOC JPEGs. Small grain differences; smooth sky, same coarse fence crossings, soft foliage, soft small hardware, and no new fine cab crossings.",
}


def copy(group, b, *, role):
    p = checked(b)
    path = IMAGES/group/p.name
    path.parent.mkdir(exist_ok=True)
    shutil.copyfile(p,path)
    assert reference(path)["sha256"] == b["sha256"]
    return {"file": str(path.relative_to(IMAGES)), "role": role, "sha256": b["sha256"]}


def capture_live(name):
    folder = ROOT/name/"collection"
    owner, progress = (read_json(folder/key) for key in ("owner.json","progress.json"))
    assert progress["completed"] < progress["planned"]
    proc = psutil.Process(owner["pid"])
    assert proc.create_time() == owner["create_time"] and proc.status() != psutil.STATUS_ZOMBIE
    assert any((Path(proc.cwd())/arg).resolve() == ROOT/name/"plan.json" for arg in proc.cmdline())
    return {"collector": name, "owner": owner, "progress": progress, "observed_alive": True}


def main():
    OUT.mkdir()
    IMAGES.mkdir()
    assert "47 passed" in (ROOT/"tests.log").read_text()
    result = {k:read_json(ROOT/path) for k,path in RESULTS.items()}
    assert result["null-adverse"]["rows"] == result["null"]["rows"]
    training = read_json(TRAINING)
    assert sum(x["examples"] for x in training["coverage"]) == 1376000
    assert all(x["positive_at_most_8_codes"] == 0 for x in training["coverage"])
    assert read_json(INPUT_AUDIT)["exact_sensor_and_variance_replays"] == 80
    pending = [capture_live("heldout-0")]
    for k in ("photo-conditioning-0","photo-conditioning-1"):
        path = ROOT/k/"collection/result.json"
        pending.append({"collector": k, "result": reference(path)} if path.exists() else capture_live(k))

    cohort = read_json(checked(read_json(INPUT_AUDIT)["cohort"]))
    credits = {x["sha1"]:x for x in cohort["source_metadata"]}
    photos, count = {}, {"comparisons": 0, "triplets": 0}
    for group, data in result.items():
        panels = []
        for item in data["rows"] if group == "gfx" else data["boards"]:
            if group == "gfx":
                row = item | {"asset": copy(group, item["image"], role="comparison")}
            else:
                row = {k:v for k,v in item.items() if k not in ("board","triplet")}
                row["comparison"] = item["board"] | copy(group,item["board"]["image"],role="comparison")
                if group == "photos":
                    row["triplet"] = item["triplet"] | copy(group,item["triplet"]["image"],role="triplet")
                    row["credit"] = credits[row["source"]]
                    orig = row["comparison"]
                    triplet = row["triplet"]
                    with Image.open(IMAGES/orig["file"]) as img1, Image.open(IMAGES/triplet["file"]) as img2:
                        ordered = {a["label"]:a["png_xywh"] for a in orig["panels"]}
                        for a in triplet["panels"]:
                            b = ordered[a["label"]]
                            x,y,w,h = a["png_xywh"]
                            p,q,_,_ = b
                            assert (w,h) == (160,160)
                            assert img1.crop((p,q,p+w,q+h)).tobytes() == img2.crop((x,y,x+w,y+h)).tobytes()
                    count["triplets"] += 1
            assert row["ROI_xywh"][2:] == [160,160]
            count["comparisons"] += 1
            panels.append(row)
        photos[group] = {"view_notes": VIEW_NOTES[group], "boards": panels}
    assert count == {"comparisons":17,"triplets":2}
    manifest = IMAGES/"manifest.json"
    write_json(manifest, {"views": photos, "view_counts":count,
                          "scope":"Actually viewed, unresized native160 panels copied byte-for-byte."})
    shutil.copyfile(TRAINING,OUT/"training-noise-audit.json")
    shutil.copyfile(INPUT_AUDIT,OUT/"inputs-audit.json")
    write_json(OUT/"cutoff.json", {"running":pending,
        "finished_reference_shard":reference(ROOT/"heldout-1/collection/result.json"),
        "scope":"Checkpoint and artifact status at preflight publication. Remaining 12 source scores are pending."})
    members = {
        p.name:p for p in ROOT.glob("*.py")
    }
    members.update({k:ROOT/k for k in (
        "plan.json","calibration.json","tests.log","calibration.log","calibration-first.log","motivation.json",
        "development-review.json","inputs-audit.json","training-noise-audit.json","guarded-declaration.json",
        "photo-conditioning-plan.json","first-heldout-group.log","conditioning-review.log",
        "null-review-queued-result.json", *RESULTS.values()
    )})
    for scope in ("heldout-0","heldout-1","nulls","conditioning","photo-conditioning-0","photo-conditioning-1"):
        r = ROOT/scope
        members[f"{scope}/plan.json"] = r/"plan.json"
        if scope in ("heldout-1","nulls","conditioning"):
            a = r/"collection/result.json"
            members[f"{scope}/collection/result.json"] = a
            if scope != "heldout-1":
                for item in read_json(a)["records"]:
                    p = checked(item)
                    members[str(p.relative_to(ROOT))] = p
    for item in result["photos"]["collection_cases"]:
        p = checked(item)
        members[str(p.relative_to(ROOT))] = p
    renderer = Path("scripts/report_scene_wave_guides.py")
    members["source/renderer.py"] = renderer
    archive = OUT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=6) as out:
        for key,p in sorted(members.items()):
            info = out.gettarinfo(p, arcname=key)
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ""
            with p.open("rb") as f:
                out.addfile(info,f)
    with tarfile.open(archive) as src:
        for entry in src:
            assert src.extractfile(entry).read() == members[entry.name].read_bytes()
    write_json(OUT/"publication.json", {
        "native_manifest":reference(manifest), "archive":reference(archive),
        "training_noise_audit":reference(OUT/"training-noise-audit.json"),
        "inputs_audit":reference(OUT/"inputs-audit.json"),
        "cutoff":reference(OUT/"cutoff.json"), "counts":count, "archive_members":len(members),
        "checkpoint":result["photos"]["boards"][0]["models"]["scale-long86k"]["checkpoint"],
        "complete":"Four-source photographic preflight, all 64 null CFA observations, crossed flat "
        "conditioning, and actual native GFX review.",
        "pending":"Full 16-source scoring, unviewed 12-source guard and paired conditioning replay.",
    })
    print("Validated", len(members), "archive members and native panels", count)


if __name__ == "__main__":
    main()
