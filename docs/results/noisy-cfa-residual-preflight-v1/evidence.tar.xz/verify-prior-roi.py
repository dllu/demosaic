"""Audit the actual pixel rectangle in the previous two positive-noise plates."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.archive_metrics import linear_rgb, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

STUDY = Path(".cache/experiments/full-corpus-long86k-faint-noise-v1")
MANIFEST = Path("docs/images/full-corpus-long86k-adc-panels-v1/manifest.json")
DESTINATION = Path("docs/results/full-corpus-long86k-adc-panels-v1/native-roi-correction.json")
METHODS = ("Noisy Malvar", "V120 EMA", "86k EMA", "Exact GT")
NATIVE = [48, 48, 160, 160]


def main():
    plan, collection = (read_json(STUDY / filename) for filename in ("plan.json", "collection/result.json"))
    cases = {obs["id"]: (obs, receipt) for obs, receipt in zip(plan["observations"], collection["records"], strict=True)}
    manifest = read_json(MANIFEST)
    rec = []
    for row in manifest["boards"]["noise"]:
        obs, receipt = cases[row["id"]]
        case = read_json(checked(receipt))
        with np.load(checked(obs["arrays"])) as f:
            arrays = dict(f)
        with np.load(checked(obs["target"])) as f:
            target = f["target"]
        values = dict(zip(METHODS, (
            noisy_malvar(arrays), *[np.load(checked(v["prediction"])) for v in case["variants"]], target
        ), strict=True))
        exposure = row["display_exposure"]
        contrast = row["display_contrast"]
        rgb = {name: linear_rgb(value * exposure, arrays)[0, :, 48:208, 48:208] for name, value in values.items()}
        anchor = rgb["Exact GT"].mean((-2, -1), keepdims=True)
        count = defaultdict(int)
        assert row["ROI_xywh"] == [176, 176, 160, 160] and obs["ROI_xywh"] == NATIVE
        for kind in ("board", "triplet"):
            asset = row[kind]
            path = MANIFEST.parent / asset["file"]
            assert reference(path)["sha256"] == asset["image"]["sha256"]
            with Image.open(path) as image:
                for panel in asset["panels"]:
                    field = np.clip(anchor + contrast * (rgb[panel["label"]] - anchor), 0, 1)
                    srgb = np.where(field <= .0031308, 12.92 * field, 1.055 * field**(1/2.4) - .055)
                    field = np.rint(srgb.transpose(1, 2, 0) * 255).astype(np.uint8)
                    x, y, w, h = panel["png_xywh"]
                    np.testing.assert_array_equal(np.asarray(image.crop((x, y, x+w, y+h))), field)
                    count[kind] += 1
        rec.append({"id": row["id"], "old_metadata_ROI_xywh": row["ROI_xywh"], "actual_ROI_xywh": NATIVE,
                    "recomputed_exact_display_cells": dict(count), "observation": obs, "prediction_record": receipt})
    assert len(rec) == 2
    write_json(DESTINATION, {"kind": "native-crop provenance addendum", "archived_original_manifest": reference(MANIFEST),
                            "cause": "The original renderer wrote its 512-context default coordinates into the receipt while cropping its supplied 256-context default.",
                            "image_changes": 0, "model_forwards": 0, "producer": reference(__file__), "rows": rec})
    print("Independent display recomputation verified all 14 cells and the actual native ROI.")


if __name__ == "__main__":
    main()
