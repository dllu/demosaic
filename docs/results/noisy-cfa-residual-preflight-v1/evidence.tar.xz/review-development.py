"""Check implemented correction on the four development materials with legacy metrics."""

from collections import defaultdict
from statistics import mean

import numpy as np
import torch
from probe import DEV, ROOT, corrected, inputs_and_variants
from report_checkpoint_pilot import statistics

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    calibration = ROOT / "calibration.json"
    fit = read_json(calibration)["parameters"]
    rows, grouped = [], defaultdict(list)
    for o, a, predictions, _ in inputs_and_variants(DEV):
        with np.load(checked(o["target"])) as f:
            truth = f["target"]
        for model, raw in predictions.items():
            for policy, value in corrected(raw, a, o["noise"], fit).items():
                measured = statistics(value, truth, a)
                weak = next(r for r in measured["bands"] if r["bin"] == 0)
                row = {
                    "id": o["id"], "source": o["source_id"], "model": model,
                    "noise": o["noise"]["name"], "policy": policy,
                    "sRGB_PSNR": measured["sRGB_PSNR"], "fine_DN16": 65535*weak["band_error_RMS"],
                }
                rows.append(row)
                grouped[model, row["noise"], policy].append(row)
    original = read_json(DEV / "review/result.json")
    check = {(r["id"], r["model"]): (r["sRGB_PSNR"], r["fine_band_DN16"]) for r in original["rows"]}
    assert len(check) == 96
    assert all(check[r["id"], r["model"]] == (r["sRGB_PSNR"], r["fine_DN16"]) for r in rows if r["policy"] == "raw")
    summary = []
    for (model, noise, policy), group in sorted(grouped.items()):
        assert len(group) == 16
        row = {"model": model, "noise": noise, "policy": policy}
        row.update({k: mean(r[k] for r in group) for k in ("sRGB_PSNR", "fine_DN16")})
        print(row, flush=True)
        summary.append(row)
    write_json(ROOT / "development-review.json", {
        "producer": reference(__file__), "calibration": reference(calibration),
        "old_scores": reference(DEV / "review/result.json"),
        "exact_retained_raw_matches": len(check), "rows": rows, "summary": summary,
    })


if __name__ == "__main__":
    main()
