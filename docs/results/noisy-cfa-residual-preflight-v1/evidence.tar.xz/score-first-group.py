"""Verify the holdout scorer on the first complete group of the second frozen shard."""

from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from probe import ROOT, score
from report_full_faint_photo_panel import source_balance
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    origin = ROOT / "heldout-1"
    folder = ROOT / "first-heldout-group"
    folder.mkdir()
    plan = read_json(origin / "plan.json")
    selection = plan["observations"][:16]
    assert all(o["source_ids"] == selection[0]["source_ids"] for o in selection)
    assert len({(o["pattern"], o["noise"]["name"]) for o in selection}) == 16
    calibration = read_json(ROOT / "calibration.json")
    parameters = calibration["parameters"]
    assert calibration["heldout_plan"] == reference(ROOT / "plan.json")
    collected, accum, boards = [], defaultdict(list), []
    for index, o in enumerate(selection):
        record = reference(origin / "collection" / f"case-{index:03d}.json")
        case = read_json(checked(record))
        assert case["id"] == o["id"] and case["input_fingerprints"] == o["input_fingerprints"]
        with np.load(checked(o["arrays"])) as data:
            arrays = dict(data)
        predictions = {p["label"]: np.load(checked(p["prediction"])) for p in case["variants"]}
        rows, rendered, target = score(o, arrays, predictions, parameters)
        accum[o["noise"]["name"]].extend(rows)
        if o["noise"]["name"] == "small-positive" and o["pattern"] == "RGGB":
            for j, source in enumerate(o["source_ids"][:2]):
                camera = {k: arrays[k][j:j+1] for k in ("packed", "colors", "wb", "matrix")}
                variants = rendered["scale-long86k"]
                boards.append(native_board(
                    folder, source, [noisy_malvar(camera)[0], variants["raw"][j], variants["single"][j],
                                     variants["split"][j], target[j]], camera,
                    {"source": source, "observation": o, "variant_receipts": case["variants"],
                     "models": plan["models"]}, contrast=20, exposure=1,
                    labels=("Noisy Malvar", "86k raw EMA", "86k single", "86k split", "Exact GT"),
                    triplet_indices=(0, 2, 4),
                ))
        collected.append(record)
    assert len(boards) == 2
    summary = []
    for noise, rows in accum.items():
        assert len(rows) == 4 * 4 * 3 * 2
        for group in source_balance(rows):
            if group["band"] != "0":
                continue
            subset = [r for r in rows if r["model"] == group["model"] and r["policy"] == group["policy"]]
            row = group | {"profile": noise, "mean_PSNR": mean(r["PSNR_sRGB"] for r in subset),
                           "mean_coarse_DN16": mean(r["block_mean_error_DN16"] for r in subset)}
            summary.append(row)
            print(noise, row["model"], row["policy"], round(row["mean_PSNR"], 5),
                  round(row["equal_source_RMS_DN16"], 4), round(row["mean_coarse_DN16"], 4), flush=True)
    write_json(folder / "result.json", {
        "producer": reference(__file__), "calibration": reference(ROOT / "calibration.json"),
        "plan": reference(origin / "plan.json"), "collection_cases": collected,
        "rows": dict(accum), "summary": summary, "boards": boards,
        "scope": "Preflight of the fixed scoring operator on the four first held-out sources of shard 1. "
        "Parameters frozen from the four separate materials. This group is a subset of the continuing study.",
    })


if __name__ == "__main__":
    main()
