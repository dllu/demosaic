"""Run the fixed offline scorers when their owned CPU collections complete."""

import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def live(owner):
    try:
        proc = psutil.Process(owner["pid"])
        return proc.create_time() == owner["create_time"] and proc.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False


def await_collection(root):
    result, owner_file = (root / "collection" / x for x in ("result.json", "owner.json"))
    owner = read_json(owner_file)
    assert owner["plan"] == reference(root / "plan.json")
    while not result.is_file() and live(owner):
        time.sleep(8)
    if not result.is_file():
        raise RuntimeError(f"Collector {owner['pid']} exited before publishing {result}")
    identity = reference(result)
    c = read_json(checked(identity))
    assert c["plan"] == owner["plan"] and c["CPU_rng_unchanged"]
    assert c["full_model_before"] == c["full_model_after"]
    assert c["local_DINO"] == {"requests": 2*len(c["records"]), "executions": len(c["records"]), "replays": len(c["records"])}
    return identity


def review(name, roots, command):
    dependencies = [await_collection(root) for root in roots]
    cmd = [sys.executable, *[str(ROOT / command[0]), *command[1:]]]
    with (ROOT / (name + "-queued.log")).open("x") as log:
        done = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False)
    write_json(ROOT / (name + "-queued-result.json"), {
        "queue": reference(__file__), "dependencies": dependencies,
        "scorer": reference(ROOT / command[0]), "returncode": done.returncode,
    })
    if done.returncode:
        raise RuntimeError(f"{name} scorer exited with status {done.returncode}")


def main():
    os.nice(10)
    jobs = {
        "photo-review": ([ROOT / "heldout-0", ROOT / "heldout-1"], ("probe.py", "review")),
        "null-review": ([ROOT / "nulls"], ("review-nulls.py",)),
    }
    with ThreadPoolExecutor(max_workers=2) as pool:
        waits = [pool.submit(review, k, *v) for k, v in jobs.items()]
        for job in waits:
            job.result()


if __name__ == "__main__":
    main()
