"""Score false structure and bias on three flats and an exact slanted edge."""

from pathlib import Path

import numpy as np
import torch
from probe import DN16, POLICIES, ROOT, corrected, inputs_and_variants
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


@torch.inference_mode()
def report():
    torch.set_num_threads(2)
    out = ROOT / "nulls-review"
    out.mkdir()
    fit = read_json(ROOT / "calibration.json")["parameters"]
    rows, boards = [], []
    y, x = np.mgrid[48:208, 48:208]
    distance = np.abs(x - 121.7 - .21 * (y - 128))
    for o, a, predictions, models in inputs_and_variants(ROOT / "nulls"):
        variants = {model: corrected(p, a, o["noise"], fit) for model, p in predictions.items()}
        with np.load(checked(o["target"])) as ds:
            target = ds["target"]
        for model, policies in variants.items():
            for label, p in policies.items():
                err = DN16 * (p[..., 48:208, 48:208].astype(float) - target[..., 48:208, 48:208])
                for i, case in enumerate(o["source_ids"]):
                    cell = err[i]
                    centered = cell - cell.mean((-2, -1), keepdims=True)
                    is_edge = case == "slanted-edge"
                    rows.append({
                        "profile": o["noise"]["name"], "CFA": o["pattern"], "source": case,
                        "model": model, "policy": label,
                        "worst_channel_abs_bias_DN16": float(np.max(np.abs(cell.mean((-2,-1))))),
                        "spatial_centered_RMS_DN16": float(np.sqrt(np.mean(centered**2))),
                        "quiet_RMS_DN16": float(np.sqrt(np.mean(cell[:, distance >= 24]**2))) if is_edge else None,
                        "boundary_RMS_DN16": float(np.sqrt(np.mean(cell[:, distance <= 6]**2))) if is_edge else None,
                        "max_abs_error_DN16": float(np.max(np.abs(cell))),
                    })
        if o["pattern"] != "RGGB":
            continue
        selected = {"intermediate": "slanted-edge", "iso100-prior": "bright-yellow"}
        case = selected.get(o["noise"]["name"])
        if case is None:
            continue
        i = o["source_ids"].index(case)
        local = {k: a[k][i:i+1] for k in ("packed", "colors", "wb", "matrix")}
        model = variants["scale-long86k"]
        boards.append(native_board(
            out, f"{o['noise']['name']}-{case}",
            [noisy_malvar(local)[0], *(model[k][i] for k in POLICIES), target[i]], local,
            {"source": case, "observation": o, "models": models}, exposure=1,
            labels=("Noisy Malvar", "86k raw EMA", "86k single", "86k split", "Exact GT"),
            triplet_indices=(0, 2, 4),
        ))
    assert len(rows) == 16 * 4 * 2 * 3 and len(boards) == 2
    write_json(out / "result.json", {
        "producer": reference(__file__), "calibration": reference(ROOT / "calibration.json"),
        "plan": reference(ROOT / "nulls/plan.json"),
        "collection": reference(ROOT / "nulls/collection/result.json"),
        "rows": rows, "boards": boards,
    })


if __name__ == "__main__":
    report()
