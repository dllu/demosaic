"""Generate source-independent flats and a slanted-edge control at four noise priors."""

import hashlib
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import color_indices, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise, variance_map
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
PLAN = ROOT / "plan.json"
CASE_IDS = ("neutral-grey", "green", "bright-yellow", "slanted-edge")
PATTERNS = ("RGGB", "BGGR", "GRBG", "GBRG")


def main():
    out = ROOT / "nulls"
    out.mkdir()
    inputs = out / "inputs"
    inputs.mkdir()
    study = read_json(PLAN)
    parent = read_json(checked(study["heldout"][0]))
    y, x = torch.meshgrid(torch.arange(256), torch.arange(256), indexing="ij")
    targets = torch.tensor([[0.18, .18, .18], [.08, .43, .065], [.90, .90, .018],
                            [.10, .15, .17]], dtype=torch.float32)[:, :, None, None]
    targets = targets.expand(4, 3, 256, 256).clone()
    transition = ((x - 121.7 - .21 * (y - 128)) / 1.8).sigmoid()
    targets[-1] += torch.tensor([.57, .38, .14])[:, None, None] * transition
    target = inputs / "targets.npz"
    with target.open("xb") as f:
        np.savez(f, target=targets.numpy())
    observations = []
    for profile, (shot, read) in study["profiles"].items():
        for pattern in PATTERNS:
            rgb_indices = color_indices(pattern)[None].expand(4, -1).clone()
            measured = mosaic(targets, rgb_indices)
            name = f"{profile}-{pattern}"
            digest = hashlib.sha256(f"noisy-cfa-residual-nulls-v1:{name}".encode()).digest()
            seed = int.from_bytes(digest[:8], "little") % 2**63
            rng = torch.Generator().manual_seed(seed)
            raw = add_noise(measured, shot, read, bit_depth=16, black_level=0.03, generator=rng)
            arrays = {
                "packed": raw.numpy(), "variance": variance_map(raw, shot, read).numpy(),
                "colors": rgb_indices.numpy(), "wb": np.ones((4, 3), np.float32),
                "matrix": np.repeat(np.eye(3, dtype=np.float32)[None], 4, axis=0),
            }
            path = inputs / f"{name}.npz"
            with path.open("xb") as f:
                np.savez(f, **arrays)
            observations.append({
                "id": name, "kind": "null-control", "source_ids": list(CASE_IDS), "pattern": pattern,
                "target": reference(target), "arrays": reference(path), "seed": seed,
                "input_fingerprints": {k: fingerprint(v) for k, v in arrays.items()},
                "output_shape": [4, 3, 256, 256], "ROI_xywh": [48, 48, 160, 160],
                "noise": {"name": profile, "shot": shot, "read": read, "ADC_bits": 16,
                          "black_level": .03, "CPU_precision": "float32"},
            })
    assert len(observations) == 16
    write_json(out / "plan.json", parent | {
        "root": str(out), "observations": observations, "CPU_affinity": [16, 17],
        "inputs": [*parent["inputs"], reference(PLAN), reference(__file__), reference(target)],
        "batch_histogram": {"4": 16}, "planned_root_calls": 32, "planned_DINO_executions": 16,
        "scope": "Fresh holdout noise on three exact flats and one blurred slanted edge, with identity camera "
        "transforms. Four Bayer layouts and four profiles; used only for evaluation.",
    })


if __name__ == "__main__":
    torch.set_num_threads(1)
    main()
