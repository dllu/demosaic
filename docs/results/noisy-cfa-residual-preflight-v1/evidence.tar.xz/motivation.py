"""Measure the best fixed residual gains on the retained four source panel."""

from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from report_checkpoint_pilot import band
from torch.nn import functional as F

from demosaic.archive_metrics import linear_rgb
from demosaic.cfa import bilinear, malvar, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / "full-corpus-long86k-faint-noise-v1"
ROI = np.s_[..., 48:208, 48:208]


def energy(p, t, proposals, a):
    truth_rgb = linear_rgb(t[ROI], a)
    truth_coeff, mean = band(truth_rgb)
    valid = ((truth_rgb[0] >= 0) & (truth_rgb[0] <= 1)).all(0)
    valid = valid.reshape(10, 16, 10, 16).transpose(0, 2, 1, 3).reshape(100, 256).all(1)
    rms = np.linalg.norm(truth_coeff[0], axis=-1) / 16
    valid &= (mean[0] >= 0.02) & (mean[0] <= 0.9) & (rms >= 1e-5) & (rms < 0.02 * mean[0])
    assert valid.any()
    base = linear_rgb(p[ROI], a)
    te = [(base - truth_rgb).ravel(), (band(base)[0] - truth_coeff)[0, valid].ravel()]
    result = {}
    for name, field in proposals.items():
        change = linear_rgb(field[ROI], a)
        deltas = [change.ravel(), band(change)[0][0, valid].ravel()]
        result[name] = {
            metric: (
                float(np.mean(err**2)),
                float(np.mean(err * update)),
                float(np.mean(update**2)),
            )
            for metric, err, update in zip(("linear_RGB", "weak_fine"), te, deltas, strict=True)
        }
    return result


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    bindings = [reference(INPUT / filename) for filename in ("plan.json", "collection/result.json")]
    plan, collection = map(lambda r: read_json(checked(r)), bindings)
    assert collection["plan"] == bindings[0]
    rows, grouped = [], defaultdict(list)
    for obs, record in zip(plan["observations"], collection["records"], strict=True):
        case = read_json(checked(record))
        assert case["id"] == obs["id"] and case["input_fingerprints"] == obs["input_fingerprints"]
        with np.load(checked(obs["arrays"])) as data:
            a = dict(data)
        with np.load(checked(obs["target"])) as data:
            t = data["target"]
        raw, colors, wb = (torch.from_numpy(a[k]) for k in ("packed", "colors", "wb"))
        for variant in case["variants"]:
            model = variant["label"]
            assert variant["checkpoint"] == plan["models"][model]["checkpoint"]
            p = np.load(checked(variant["prediction"]))
            r = raw - mosaic(torch.from_numpy(p), colors)
            proposals = {}
            for w in (3, 7, 15):
                radius = w // 2
                smooth = F.avg_pool2d(F.pad(r, (radius,) * 4, mode="reflect"), w, stride=1)
                proposals[f"low{w}"] = bilinear(smooth, colors).numpy()
                proposals[f"high{w}"] = malvar(r - smooth, colors, wb).numpy()
            proposals["malvar"] = malvar(r, colors, wb).numpy()
            proposals["bilinear"] = bilinear(r, colors).numpy()
            terms = energy(p, t, proposals, a)
            rows.append({"model": model, "observation": obs["id"], "terms": terms})
            for variant, metrics in terms.items():
                for metric, terms in metrics.items():
                    grouped[model, obs["noise"]["name"], variant, metric].append(terms)
    summary = []
    for (model, noise, arm, metric), entries in sorted(grouped.items()):
        assert len(entries) == 16
        base, cross, update = np.mean(entries, axis=0)
        gain = max(0, min(1, -cross / update))
        rms = np.sqrt(base + 2 * gain * cross + gain**2 * update) * 65535
        row = {
            "model": model, "noise": noise, "basis": arm, "metric": metric,
            "matched_GTx_optimum_gain": gain,
            "baseline_DN16": np.sqrt(base) * 65535, "oracle_DN16": rms,
        }
        summary.append(row)
        if arm in ("malvar", "low7", "high7"):
            print(row, flush=True)
    write_json(ROOT / "motivation.json", {"source": reference(__file__), "inputs": bindings, "rows": rows, "summary": summary})


if __name__ == "__main__":
    main()
