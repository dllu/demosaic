"""Bind a new, source-disjoint positive-noise panel before scoring the operators."""

import hashlib
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise, variance_map
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "full427-faint-adc-v1/plan.json"
EARLIER = ROOT.parent / "full-corpus-long86k-adc-panels-v1/plan.json"
DEV = ROOT.parent / "full-corpus-long86k-faint-noise-v1/plan.json"
SALT = "noisy-cfa-residual-20261118-holdout-v1"
PROFILES = {
    "small-positive": (1e-8, 1e-10),
    "intermediate": (3.2e-7, 1e-10),
    "iso100-prior": (2e-5, 1.6e-9),
    "iso6400-prior": (0.00128, 6.5536e-6),
}


def hash_key(*values):
    return hashlib.sha256("|".join((SALT, *values)).encode()).digest()


def main():
    torch.set_num_threads(1)
    original, earlier, dev = (read_json(path) for path in (PARENT, EARLIER, DEV))
    pretested = {o["source_id"] for o in dev["observations"]}
    for binding in earlier["stages"]["faint"]["shards"]:
        for o in read_json(checked(binding))["observations"]:
            pretested.update(o["source_ids"])
    groups = defaultdict(list)
    for obs in original["observations"]:
        if len(obs["source_ids"]) == 4 and not pretested.intersection(obs["source_ids"]):
            groups[tuple(obs["source_ids"])].append(obs)
    selected = sorted(groups, key=lambda g: hash_key(*g))[:4]
    assert len({s for g in selected for s in g}) == 16
    bindings = []
    for i, cpus in enumerate(([2, 3], [6, 7])):
        root = ROOT / f"heldout-{i}"
        root.mkdir()
        local = root / "inputs"
        local.mkdir()
        observations = []
        for group in selected[i::2]:
            assert {o["pattern"] for o in groups[group]} == {"RGGB", "BGGR", "GRBG", "GBRG"}
            for obs in groups[group]:
                with np.load(checked(obs["arrays"])) as ds:
                    camera = {k: ds[k] for k in ("colors", "wb", "matrix")}
                with np.load(checked(obs["target"])) as ds:
                    target = torch.from_numpy(ds["target"])
                clean = mosaic(target, torch.from_numpy(camera["colors"]))
                for profile, (shot, read) in PROFILES.items():
                    seed = int.from_bytes(hash_key(obs["id"], profile)[:8], "little") % 2**63
                    generator = torch.Generator().manual_seed(seed)
                    packed = add_noise(clean, shot, read, bit_depth=16, black_level=0.03, generator=generator)
                    arrays = camera | {"packed": packed.numpy(), "variance": variance_map(packed, shot, read).numpy()}
                    name = f"{obs['id']}-{profile}"
                    path = local / f"{name}.npz"
                    with path.open("xb") as file:
                        np.savez(file, **arrays)
                    observations.append(
                        obs | {
                            "id": name, "ADC_parent": obs["id"], "seed": seed,
                            "arrays": reference(path), "input_fingerprints": {k: fingerprint(v) for k, v in arrays.items()},
                            "noise": {
                                "name": profile, "shot": shot, "read": read, "ADC_bits": 16,
                                "black_level": 0.03, "CPU_precision": "float32",
                            },
                        }
                    )
        assert len(observations) == 32
        path = root / "plan.json"
        write_json(path, original | {
            "root": str(root), "observations": observations,
            "inputs": [*original["inputs"], *map(reference, (PARENT, EARLIER, DEV, __file__)), dev["models"]["scale-long86k"]["checkpoint"]],
            "models": dev["models"], "CPU_affinity": cpus, "CPU_threads": 2,
            "maximum_seconds": 2700, "planned_root_calls": 64, "planned_DINO_executions": 32,
            "batch_histogram": {"4": 32},
            "scope": "Matched positive-noise held-out photo crops at 2.5% contrast. Four CFAs, four noise profiles. "
            "Input observations regenerated from disjoint original faint ADC targets, with fixed new noise draws.",
        })
        bindings.append(reference(path))
    write_json(ROOT / "plan.json", {
        "producer": reference(__file__), "heldout": bindings, "source_groups": selected,
        "excluded_prior_review_sources": sorted(pretested), "profiles": PROFILES, "selection_salt": SALT,
    })
    print("Bound 16 held-out sources, 256 noisy crop observations across 64 B4 inputs.")


if __name__ == "__main__":
    main()
