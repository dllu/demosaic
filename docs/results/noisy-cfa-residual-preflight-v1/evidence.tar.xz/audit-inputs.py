"""Verify reserved source IDs, exact targets, and regenerated physical observations."""

import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
ORIGIN = ROOT.parent / "full427-faint-adc-v1"


def audit():
    torch.set_num_threads(1)
    root_plan = read_json(ROOT / "plan.json")
    source = read_json(ORIGIN / "cohort.json")
    ids = {s for grp in root_plan["source_groups"] for s in grp}
    assert len(ids) == 16 and ids.issubset(source["source_ids"])
    assert not ids.intersection(root_plan["excluded_prior_review_sources"])
    with checked(source["training_manifest"]).open() as f:
        training = {r["id"] for line in f if (r := json.loads(line))["split"] == "train"}
    assert len(training) == 90778 and not ids.intersection(training)
    original = {o["id"]: o for o in read_json(ORIGIN / "plan.json")["observations"]}
    observations = []
    counts, seeds = Counter(), set()
    for binding in (*root_plan["heldout"], reference(ROOT / "nulls" / "plan.json")):
        for o in read_json(checked(binding))["observations"]:
            with np.load(checked(o["arrays"])) as f:
                a = dict(f)
            with np.load(checked(o["target"])) as f:
                target = f["target"]
            expected = original[o["ADC_parent"]] if "ADC_parent" in o else None
            if expected:
                assert all(expected[k] == o[k] for k in ("target", "source_ids", "pattern", "original_canonical"))
                with np.load(checked(expected["arrays"])) as f:
                    for k in ("colors", "wb", "matrix"):
                        np.testing.assert_array_equal(a[k], f[k])
                salt = root_plan["selection_salt"]
                message = "|".join((salt, o["ADC_parent"], o["noise"]["name"]))
            else:
                message = "noisy-cfa-residual-nulls-v1:" + o["id"]
            val = hashlib.sha256(message.encode()).digest()
            seed = int.from_bytes(val[:8], "little") % 2**63
            assert seed == o["seed"] and seed not in seeds
            seeds.add(seed)
            raw = np.stack([
                np.stack([y[c, p//2::2, p%2::2] for p, c in enumerate(cf)])
                for y, cf in zip(target, a["colors"], strict=True)
            ])
            shot, read = o["noise"]["shot"], o["noise"]["read"]
            generated = add_noise(torch.from_numpy(raw), shot, read, bit_depth=16, black_level=.03,
                                  generator=torch.Generator().manual_seed(seed)).numpy()
            np.testing.assert_array_equal(generated, a["packed"])
            expected_variance = np.maximum(a["packed"], np.float32(0)) * np.float32(shot) + np.float32(read)
            np.testing.assert_array_equal(expected_variance, a["variance"])
            assert {k: fingerprint(v) for k, v in a.items()} == o["input_fingerprints"]
            observations.append({"id": o["id"], "seed": seed, "input": o["arrays"], "target": o["target"]})
            for s in o["source_ids"]:
                counts[s, o["noise"]["name"], o["pattern"]] += 1
    assert len(observations) == 80 and len(counts) == 320 and max(counts.values()) == 1
    write_json(ROOT / "inputs-audit.json", {
        "source": reference(__file__), "cohort": reference(ORIGIN / "cohort.json"),
        "training_manifest": source["training_manifest"], "training_ids": len(training),
        "heldout_photo_ids": sorted(ids), "training_overlap": 0,
        "exact_sensor_and_variance_replays": len(observations), "observations": observations,
    })
    print("Audited 80 physical input replays, independent CFA indexing and FP32 variance. No source overlap.")


if __name__ == "__main__":
    audit()
