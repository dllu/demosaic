"""Compare both noisy-residual policies on the eight retained native GFX boards."""

from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from probe import GFX, ROOT, corrected, inputs_and_variants
from report_checkpoint_pilot import pixels

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

OLD = Path("docs/images/full-corpus-long86k-native-v1/manifest.json")


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    out = ROOT / "camera-review"
    out.mkdir()
    source = read_json(OLD)
    old = {r["id"]: r for r in source["images"] if r["role"] == "board"}
    fit = read_json(ROOT / "calibration.json")["parameters"]
    rows = []
    for obs, a, predictions, models in inputs_and_variants(GFX, lambda o: o["kind"] in ("gfx", "mesh")):
        methods = corrected(predictions["scale-long86k"], a, obs["noise"], fit)
        ids = (
            [obs["id"]] if obs["kind"] == "gfx"
            else [f"{obs['id']}-{case['name']}" for case in obs["cases"]]
        )
        for key in ids:
            entry = old[key]
            provenance = entry["provenance"]
            roi = provenance["ROI_xywh"]
            x, y, w, h = roi
            image = checked(entry["image"])
            with Image.open(image) as canvas:
                cells = []
                columns = provenance["panels"]
                changes = {}
                for i, col in enumerate(columns):
                    if col["label"] == "Long schedule 50k EMA":
                        continue
                    px, py, pw, ph = col["png_xywh"]
                    num = np.asarray(canvas.crop((px, py, px+pw, py+ph)))
                    cells.append((col["label"], num))
                    if col["label"] == "Long schedule 86k EMA":
                        old_rgb = pixels(methods["raw"], a, roi, obs["display_exposure"])
                        np.testing.assert_array_equal(num, old_rgb)
                        for name in ("single", "split"):
                            z = methods[name]
                            candidate = pixels(z, a, roi, obs["display_exposure"])
                            diff = z[..., y:y+h, x:x+w].astype(float) - methods["raw"][..., y:y+h, x:x+w]
                            changes[name] = {
                                "camera_RGB_rms_DN16": float(np.sqrt(np.mean(diff**2)) * 65535),
                                "camera_RGB_peak_DN16": float(np.max(np.abs(diff)) * 65535),
                                "changed_srgb_pixels": int(np.any(candidate != old_rgb, axis=-1).sum()),
                            }
                            cells.append((f"86k {name}", candidate))
            rendered = Image.new("RGB", (8+168*len(cells), 192), "#eeeeee")
            draw = ImageDraw.Draw(rendered)
            panels = []
            for i, (label, field) in enumerate(cells):
                xpos = 8+168*i
                assert field.shape == (160, 160, 3) and field.dtype == np.uint8
                rendered.paste(Image.fromarray(field), (xpos, 24))
                draw.text((xpos, 5), label, fill="black")
                panels.append({"label": label, "png_xywh": [xpos, 24, 160, 160]})
            path = out / f"{key}.png"
            rendered.save(path)
            with Image.open(path) as check:
                for col, (_, field) in zip(panels, cells, strict=True):
                    x, y, w, h = col["png_xywh"]
                    np.testing.assert_array_equal(np.asarray(check.crop((x,y,x+w,y+h))), field)
            rows.append({
                "id": key, "image": reference(path), "panels": panels, "original_board": entry["image"],
                "input": obs, "ROI_xywh": roi, "models": models, "changes": changes,
            })
            print(key, changes, flush=True)
    assert len(rows) == 8
    write_json(out / "result.json", {
        "producer": reference(__file__), "calibration": reference(ROOT / "calibration.json"),
        "prior_manifest": reference(OLD), "rows": rows, "model_forwards": 0,
        "scope": "Prior board references, noise conditioning and original pixels checked. All differences "
        "relative to 86k EMA; independent ISO100 and JPEG references stay qualitative.",
    })


if __name__ == "__main__":
    main()
