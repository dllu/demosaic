"""Bind the prospective and exploratory measurements and the crops actually viewed."""

from datetime import UTC,datetime
import hashlib
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
repo=ROOT.parents[2]
images=repo/"docs/images/mesh-step-continuity-v1"
results=repo/"docs/results/mesh-step-continuity-v1"
images.mkdir();results.mkdir()


def relative(file):
    return {"path":file.relative_to(repo).as_posix(),"sha256":reference(file)["sha256"]}


def export(src,panels,prefix=""):
    before=checked(src)
    image=images/(prefix+before.name)
    shutil.copyfile(before,image)
    with Image.open(image)as photo:
        for item in panels:
            x,y,w,h=item["png_xywh"]
            assert (w,h)==(160,160) and x+w<=photo.width and y+h<=photo.height
    binding=relative(image)
    assert binding["sha256"]==src["sha256"]
    return binding


camera=read_json(ROOT/"camera.json")
rescale=read_json(ROOT/"camera-rescale.json")
paired={r["id"]:r for r in rescale["views"]}
scenes=[]
details={
    "main-overcast-sky-main-overcast-sky":"Smooth gray sky, with exact identity for both alternatives.",
    "main-building-detail-main-building-detail":"The same soft supporting structure and lines.",
    "main-foliage-main-foliage":"Leaf edges and shadows retain the original pixels.",
    "main-chain-link-fence-main-chain-link-fence":"Small contrast changes. Both directions and the small bright spot remain visible.",
    "mesh-nominal-fine-green-mesh-left":"The faint lattice and the post remain identical under both new options.",
    "mesh-nominal-fine-green-mesh-right":"Both recovered directions and the horizontal wire remain; identity to the earlier adjacent-donor result.",
    "mesh-profile3879-fine-green-mesh-left":"The side-dependent mask preserves the faint lattice exactly while the background-only step fades it slightly.",
    "mesh-profile3879-fine-green-mesh-right":"Both new options keep the visible crossings and mottled background.",
}
for row in camera["views"]:
    name=row["id"]
    followup=paired[name]
    for key in ("source","parent","RAW","exposure","ROI","noise","query"):
        assert row[key]==followup[key]
    for key in ("source","parent","RAW","arrays"):
        checked(row[key])
    with np.load(checked(row["arrays"]),allow_pickle=False)as a:
        with np.load(checked(followup["arrays"]),allow_pickle=False)as b:
            for key in ("before","step"):
                np.testing.assert_array_equal(a[key],b[key])
            if "chain-link-fence"not in name:
                for f in (a,b):
                    np.testing.assert_array_equal(f["before"],f["sided"])
                    np.testing.assert_array_equal(f["before"],f["rear"])
    scope={k:row[k]for k in ("id","source","parent","RAW","ROI","noise","query","exposure","changes_DN16","panels")}
    scope["image"]=export(row["image"],row["panels"])
    scope["rescale_changes_DN16"]=followup["changes_DN16"]
    scope["rescale_view"]=followup["image"]
    checked(followup["image"])
    if "chain-link-fence"in name:
        scope["rescale_board"]=export(followup["image"],followup["panels"],"rescale-")
        scope["rescale_panels"]=followup["panels"]
    scope["observation"]=details[name]
    scenes.append(scope)
assert len(scenes)==8

render=read_json(ROOT/"summary.json")
native=[]
observations={
    "iso400-step-g173":"The continuing weak direction varies across the edge. The attenuated rear contribution reduces some dark-side overshoot.",
    "iso400-step-g175":"Visible weak crossings across the step. Direct attenuation reduces brighter-side contrast while preserving the dark-side continuation.",
    "iso400-step-g174":"The side-aware check attenuates this continuous case near the transition, though its shift from the wide result is smaller than the background step's.",
    "iso6400-disk-g174":"Both step masks retain some of the false weak repeat through the disk.",
}
for row in render["boards"]:
    key=row["id"]
    output={k:v for k,v in row.items()if k not in ("board","triplet")}
    for k in ("case","prediction_pack","checkpoint"):
        checked(row[k])
    for k in ("board","triplet"):
        if k=="triplet" and key not in render["triplets"]:
            continue
        base=row[k]
        output[k]={"panels":base["panels"],"image":export(base["image"],base["panels"])}
    output["observation"]=observations.get(key,"One of the ISO400 gaps with lower total error after the side-dependent cut. Some weak crossings outside the gap remain soft.")
    native.append(output)
assert len(native)==5 and sum("triplet"in v for v in native)==2
view=results/"viewing.json"
write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
                 "scope":"Both sets of eight camera boards, five synthetic comparisons and the two native synthetic triplets opened at native size.",
                 "camera_checkpoint":camera["checkpoint"],"camera":scenes,"synthetic":native})

extras=("summary.json","verification.json","edge-delivery.json","rescale-independent.json",
        "negative-oracle.json","admission-probe.json")
for k in extras:
    shutil.copyfile(ROOT/k,results/k)
files={r.name:r for r in ROOT.iterdir()if r.is_file()and r.suffix in (".json",".py",".log")}
files.update({r.relative_to(ROOT).as_posix():r for r in (ROOT/"fresh").glob("*.json")})
assert len(list((ROOT/"fresh").glob("*.json")))==28
packed=results/"evidence.tar.xz"
with tarfile.open(packed,"x:xz",preset=4)as bundle:
    for name,path in files.items():
        bundle.add(path,arcname=name)
contents={name:reference(path)for name,path in files.items()}
with tarfile.open(packed,"r:xz")as bundle:
    assert set(bundle.getnames())==set(files)
    for name,item in contents.items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==item["sha256"]
depends=("mesh-envelope-support-v1","donor-phase-transport-v1","local-mesh-distributed-audit-v1")
write_json(results/"publication.json",{"metrics":relative(results/"summary.json"),"actual_viewing":relative(view),
                                       "source_archive":relative(packed),"archive_contents":contents,
                                       "checks":[relative(results/p)for p in extras[1:]],
                                       "previous_sources":[relative(repo/"docs/results"/p/"evidence.tar.xz")for p in depends],
                                       "scope":"Prospective exact-target and retrospective RAW crop comparisons on unchanged EMA models. Both camera families reviewed. No new training or primary PSNR points."})
