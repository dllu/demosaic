"""Locate the remaining strong-only false positives with known nuisance controls."""

from pathlib import Path
import sys

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
sys.path.insert(1,str(ROOT.parent/"mesh-envelope-support-v1"))
from admission_probe import evaluate
from deliver import CENTRE,Carrier,window
from envelope_nuisance import observation,partition
from mesh import ribbon
from qualified_step import KNOTS,select_step


def run():
    plan=read_json(ROOT/"plan.json")
    records=[]
    for name in ("iso400-step-g174","iso400-step-g175","iso400-disk-g174","iso400-ellipse-g175"):
        path=ROOT/"fresh"/(name+".json")
        row=read_json(path)
        role=row["broad"]["matching"]["roles"][0]
        prior=plan["noise"][row["entry"]["profile"]]
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            packed=window(f["packed"][0],CENTRE,phase=2)
            cfa=f["colors"][0]
            clean=window(f["target"][0],CENTRE)
        sites=native_sites(packed.shape[-2:],(-127.5,-127.5))
        p,q=(ribbon(*sites,Carrier(**v))for v in role["central_pair"])
        exact=ribbon(*sites,Carrier(**row["traits"]["case_geometry"][0]))
        floor=np.stack([clean[c,i//2::2,i%2::2]for i,c in enumerate(cfa)])
        no_nuisance=packed-floor+np.median(floor,axis=(1,2))[:,None,None]
        variants={}
        for label,data,front in (("measured",packed,p),("exact-front",packed,exact),
                                  ("exact-clean",no_nuisance,exact)):
            measured=observation(data,cfa,front,q,prior,KNOTS,flexible=True)
            x,y=measured.positions
            slot=partition(data.shape,"distributed")
            step,shape=select_step((x,y,measured.colors,slot,measured.wave,
                                    measured.nuisance,measured.raw,prior))
            bg=step[5]
            if "shape"in shape:
                bg=np.column_stack((bg,front.ravel()*bg[:,-1]))
            design=np.column_stack((bg,measured.wave))
            a,b,d=(slot==i for i in (1,2,3))
            evidence=[evaluate(measured,bg,design,aa,bb)for aa,bb in ((a,b),(b,a),(a|b,d))]
            variants[label]={"checks":evidence,"passes_positive":min(s["gain"]for s in evidence)>0}
        records.append({"id":name,"source":reference(path),"variants":variants})
        print(name,{k:([round(s["z"],2)for s in v["checks"]],v["passes_positive"])for k,v in variants.items()})
    write_json(ROOT/"negative-oracle.json",{"source_plan":reference(ROOT/"plan.json"),"driver":reference(__file__),
                                           "records":records,
                                           "scope":"Exact-front and exact-clean controls use targets and produce no predictions. The scene has no weaker wire. Fixed measured rear candidate and the same distributed audit in all arms."})


if __name__=="__main__":
    import os
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
