"""Recompute stored metrics, measure both sides, and draw native exact-target crops."""

import os
from pathlib import Path
from statistics import mean

import numpy as np
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates
from report_scene_wave_guides import native_board

from deliver import DISPLAY,score

ROOT=Path(__file__).resolve().parent


def field_score(target,wide,delta,regions,identity):
    x,y,w,h=DISPLAY
    region=np.s_[...,y:y+h,x:x+w]
    exact=target[region].astype(float)
    rendered=wide[region].copy()
    if delta is not None:
        rendered+=delta
    rendered=rendered.astype(float)
    expected=exact[1]-exact[0]
    increment=rendered[1]-rendered[0]
    a,b=coordinates(target.shape[-2],target.shape[-1],origin=(-159.5,-159.5))
    from_edge=(np.cos(identity["edge_angle"])*a+np.sin(identity["edge_angle"])*b-identity["edge_offset"])[region]
    wire=(regions["weak_phase"][region]>.1)&(regions["support"][region]>.9999)
    out={}
    for level,part in (("dark",from_edge< -12),("bright",from_edge>12)):
        site=wire&part
        true=expected[:,site]
        difference=increment[:,site]
        out[level]={
            "sites":int(site.sum()),
            "response":float(np.sum(true*difference)/np.sum(true**2)),
            "increment_RMS_DN16":float(np.sqrt(np.mean((true-difference)**2))*65535),
            "present_RMS_DN16":float(np.sqrt(
                np.mean((rendered[1][:,site]-exact[1][:,site])**2))*65535),
        }
    return out


def run():
    source=read_json(ROOT/"fresh.json");plan=read_json(checked(source["plan"]))
    delivery = read_json(ROOT/"edge-delivery.json")
    independent = read_json(ROOT/"rescale-independent.json")
    rescale = {r["id"]:r for r in (*delivery["cases"], *independent["cases"])}
    camera=read_json(ROOT/"camera.json")
    output=ROOT/"native";output.mkdir(exist_ok=True)
    boards=[];rows=[]
    for key in source["measurements"]:
        row=read_json(checked(key)); entry=row["entry"];case=row["id"]
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            arrays=dict(f)
        parent,clean=arrays["parent"],arrays["target"]
        regions={k:arrays[k]for k in ("strong_phase","weak_phase","support")}
        actual={}
        method_outputs={k:arrays[k]for k in row["metrics"]if k!="parent"}
        prior=row["metrics"].copy()
        if case in rescale:
            with np.load(checked(rescale[case]["arrays"]),allow_pickle=False)as f:
                method_outputs.update({"matching/"+k:f[k]for k in f.files})
            prior.update({"matching/"+k:v for k,v in rescale[case]["metrics"].items()})
        for method,result in prior.items():
            correction=method_outputs.get(method)
            now=score(parent,correction,clean,regions)
            assert now==result,(case,method)
            c=method.split("/")[0] if method!="parent" else "matching"
            base=arrays[c+"/wide"]
            comparison=correction if correction is not None else np.zeros_like(base)
            now["edited_roles"]=[bool(np.any(a!=b))for a,b in zip(comparison,base,strict=True)]
            now["sides"]=field_score(clean,parent,correction,regions,row["traits"])
            actual[method]=now
        rows.append({"id":case,"entry":entry,"traits":row["traits"],"source":key,"metrics":actual})
    assert len(rows)==28
    groups={}
    for profile in ("iso400","iso6400"):
        for group in ("continuity","gaps"):
            chosen=[r for r in rows if r["entry"]["profile"]==profile and
                    r["entry"]["kind"]==group and not r["entry"]["independent"]]
            assert len(chosen)==6
            methods=sorted(set().union(*(r["metrics"].keys()for r in chosen)))
            values={}
            for method in methods:
                s=[r["metrics"][method]for r in chosen if method in r["metrics"]]
                average={"n":len(s),"response_pct":100*mean(v["response"][0]for v in s),
                         "wire_increment_RMS_DN16":mean(v["increment_RMS_DN16"][0]for v in s),
                         "gap_added_RMS_DN16":None if s[0]["gap_added_RMS_DN16"]is None else mean(v["gap_added_RMS_DN16"]for v in s),
                         "gap_total_RMS_DN16":None if s[0]["gap_error_RMS_DN16"]is None else mean(v["gap_error_RMS_DN16"]for v in s),
                         "brightness_sides":{side:{"response_pct":100*mean(v["sides"][side]["response"]for v in s),
                                                   "wire_error_RMS_DN16":mean(v["sides"][side]["increment_RMS_DN16"]for v in s),
                                                   "present_RMS_DN16":mean(v["sides"][side]["present_RMS_DN16"]for v in s)}
                                             for side in ("dark","bright")},
                         "modified_from_parent":[sum(v["changed"][i]for v in s)for i in range(3)],
                         "modified_from_wide":[sum(v["edited_roles"][i]for v in s)for i in range(3)]}
                values[method]=average
                if method.startswith("matching"):
                    print(profile,group,method,
                          [round(average[k],3)if average[k] is not None else None for k in
                           ("response_pct","wire_increment_RMS_DN16","gap_added_RMS_DN16","gap_total_RMS_DN16")],
                          [round(average["brightness_sides"][side]["wire_error_RMS_DN16"],2)for side in("dark","bright")],
                          average["modified_from_wide"],flush=True)
            groups[profile+"/"+group]=values

    # Retain examples of improved direct delivery, a successful gap cut,
    # and the largest high-noise leak after the step-aware fit.
    candidates=[r for r in rows if r["id"]in rescale and r["entry"]["profile"]=="iso400"and r["entry"]["kind"]=="continuity"]
    ordered=sorted(candidates,key=lambda r:r["metrics"]["matching/wide"]["increment_RMS_DN16"][0]-
                   r["metrics"]["matching/attenuate"]["increment_RMS_DN16"][0],reverse=True)
    two=[r["id"]for r in ordered[:2]]
    gap=[r for r in rows if r["entry"]["profile"]=="iso400" and r["entry"]["kind"]=="gaps"]
    benefit=max(gap,key=lambda r:r["metrics"]["matching/wide"]["gap_error_RMS_DN16"]-
                r["metrics"]["matching/sided"]["gap_error_RMS_DN16"])["id"]
    high=[r for r in rows if r["entry"]["profile"]=="iso6400"and r["entry"]["kind"]=="gaps"]
    missed=max(high,key=lambda r:r["metrics"]["matching/sided"]["gap_added_RMS_DN16"])["id"]
    chosen={k:"attenuate"for k in two}|{benefit:"sided",missed:"sided","iso400-step-g174":"sided"}
    for row in rows:
        key=row["id"]
        if key not in chosen:
            continue
        record=read_json(checked(row["source"]))
        with np.load(checked(record["saved"]),allow_pickle=False)as f:
            a=dict(f)
        if key in rescale:
            cache=checked(rescale[key]["arrays"])
            with np.load(cache,allow_pickle=False)as f:
                a.update({"matching/"+k:f[k]for k in f.files})
        else:
            cache=None
        local=a["parent"][1]
        target=a["target"][1]
        seq=["wide","step","sided"]+["attenuate","bounded"]*(cache is not None)
        text=["Wide support","Background step","Side-dependent step"]+["Rear attenuation","Bounded rear rescale"]*(cache is not None)
        values=[noisy_malvar(a)[1],local]
        x,y,w,h=DISPLAY
        for method in seq:
            merged=local.copy()
            merged[:,y:y+h,x:x+w]+=a["matching/"+method][1]
            values.append(merged)
        values.append(target)
        tags=("Noisy Malvar","Local trunk",*text,"Exact GT")
        idx=(0,2+seq.index(chosen[key]),len(tags)-1)
        binds={"case":row["source"],"prediction_pack":record["saved"],"checkpoint":plan["checkpoint"],
               "CFA":row["traits"]["CFA"],"noise":plan["noise"][row["entry"]["profile"]],
               "seed":row["entry"]["seed"],"triplet_policy":chosen[key]}
        if cache:
            binds["rear_rescale"]=reference(cache)
        boards.append(native_board(output,key,values,{k:a[k][1:2]for k in ("wb","matrix")},
                                   binds,labels=tags,triplet_indices=idx,roi=DISPLAY,exposure=1,contrast=8))
    write_json(ROOT/"summary.json",{"driver":reference(__file__),"source":reference(ROOT/"fresh.json"),
                                     "edge_replay":reference(ROOT/"edge-delivery.json"),
                                     "independent_replay":reference(ROOT/"rescale-independent.json"),"rows":rows,
                                     "camera":reference(ROOT/"camera.json"),"groups":groups,"triplets":two,
                                     "boards":boards,"examples":chosen,"image_scores_recomputed_exactly":True})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
