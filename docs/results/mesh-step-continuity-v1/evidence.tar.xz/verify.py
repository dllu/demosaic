"""Check held-out fit arithmetic against an independent least-squares construction."""

import os
from pathlib import Path
import sys
import time

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
OLDER=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(OLDER))
from deliver import CENTRE,Carrier,window
from envelope_nuisance import observation,partition,solve
from mesh import ribbon
from qualified_step import KNOTS,field_cut,select_step
from sided import forecast,prepare


def residual_energy(data,design,fit,hold):
    losses=[]
    for i in range(3):
        a,b=fit&(data.colors==i),hold&(data.colors==i)
        sensor=data.raw[a]
        inverse_variance=1/(data.shot*max(1e-4,float(np.median(sensor)))+data.read)
        coefficients=np.linalg.lstsq(design[a],sensor,rcond=None)[0]
        error=data.raw[b]-design[b]@coefficients
        losses.append(float(error@error)*inverse_variance)
    return sum(losses)


def run():
    plan=read_json(ROOT/"plan.json")
    records=[]
    for label in ("iso400-step-g171","iso400-step-g173","iso400-ellipse-g172"):
        path=ROOT/"fresh"/(label+".json")
        limit=time.monotonic()+360
        while not path.exists():
            if time.monotonic()>limit:
                raise TimeoutError(path)
            time.sleep(2)
        row=read_json(path)
        prior=plan["noise"][row["entry"]["profile"]]
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            sensors=window(f["packed"][1],CENTRE,phase=2)
            colors=f["colors"][1]
        evidence=row["broad"]["matching"]["roles"][1]
        pair=tuple(Carrier(**g)for g in evidence["central_pair"])
        positions=native_sites(sensors.shape[-2:],(-127.5,-127.5))
        front,rear=(ribbon(*positions,d)for d in pair)
        data=observation(sensors,colors,front,rear,prior,KNOTS,flexible=True)
        slots=partition(sensors.shape,"distributed")
        x,y=data.positions
        parsed,step=select_step((x,y,data.colors,slots,data.wave,data.nuisance,data.raw,prior))
        assert "shape"in step
        sides=parsed[5][:,-1]
        data.nuisance=np.column_stack((parsed[5],front.ravel()*sides))
        wave=np.column_stack((data.wave,data.wave*sides))
        a,b,d=(slots==i for i in (1,2,3))
        compare=[]
        for train,hold in ((a,b),(b,a),(a|b,d)):
            assert not np.any(train&hold) and not np.any((train|hold)&(slots==0))
            k,_=solve(prepare(data,wave,train,hold),1.2)
            # A fixed sampled grid suffices to check the arithmetic.
            cut=field_cut(data.spline,data.spline[::67],k,"firm")
            optimized=forecast(data,wave,train,hold,cut)["gain"]
            design0=np.column_stack((data.nuisance,wave))
            design1=np.column_stack((data.nuisance,wave*(1-cut[:,None])))
            expected=residual_energy(data,design0,train,hold)-residual_energy(data,design1,train,hold)
            err=abs(expected-optimized)
            assert err<2e-8,(label,err)
            k2,_=solve(prepare(data,wave*np.array([1.,-1.]),train,hold),1.2)
            np.testing.assert_allclose(k,k2,rtol=0,atol=2e-11)
            compare.append(err)
        records.append({"id":label,"maximum_score_difference":max(compare),"fixed_forecasts":len(compare),
                        "step_sign_invariance":True,"source":reference(path)})
        print(records[-1],flush=True)
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"plan":reference(ROOT/"plan.json"),
                                          "cases":records,"scope":"Nine forecasts and three relabelings of each found step. Independently computes the same whitened energies using rectangular least squares."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
