"""Test an audited side-dependent rear correction after the main fit."""

import importlib.util
import math
import os
from pathlib import Path
import sys
import time

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates,native_sites

ROOT=Path(__file__).resolve().parent
OLDER=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(OLDER))
sys.path.insert(2,str(ROOT.parent/"donor-phase-transport-v1"))
from deliver import CENTRE,DISPLAY,Carrier,geometry,score,window
from directional import reconstruct
from envelope_nuisance import observation,partition
from mesh import ribbon
from qualified_step import KNOTS,column,select_step


def rms(values):
    return float(np.sqrt(np.mean(values.astype(float)**2))*65535)


def compare(data,constant,variable,train,test):
    overlap=power=0.
    for color in range(3):
        a,b=train&(data.colors==color),test&(data.colors==color)
        y=data.raw[a]
        variance=data.shot*max(1e-4,float(np.median(y)))+data.read
        fixed,local=(design[b]@np.linalg.lstsq(design[a],y,rcond=None)[0]
                      for design in (constant,variable))
        difference=local-fixed
        overlap+=float((data.raw[b]-fixed)@difference)/variance
        power+=float(difference@difference)/variance
    return {"gain":2*overlap-power,"z":(overlap-.5*power)/math.sqrt(max(power,1e-12)),"power":power}


def correction(raw,parent,colors,front,rear,noise):
    data=observation(raw,colors,front,rear,noise,KNOTS,flexible=True)
    slots=partition(raw.shape,"distributed")
    x,y=data.positions
    answer,step=select_step((x,y,data.colors,slots,data.wave,data.nuisance,data.raw,noise))
    empty=np.ones((3,*DISPLAY[2:]))
    if "shape"not in step:
        return empty,{"step":step,"passed":False}
    sides=answer[5][:,-1]
    same=np.column_stack((answer[5],front.ravel()*sides,data.wave))
    vary=np.column_stack((same,data.wave*sides))
    a,b,d=[slots==i for i in(1,2,3)]
    evidence=[compare(data,same,vary,train,test)for train,test in((a,b),(b,a),(a|b,d))]
    passed=min(v["z"]for v in evidence[:2])>.75 and evidence[-1]["z"]>1.5
    if not passed:
        return empty,{"step":step,"passed":False,"forecasts":evidence}
    px,py=coordinates(256,256,origin=(-127.5,-127.5))
    left,top=DISPLAY[0]-CENTRE[0],DISPLAY[1]-CENTRE[1]
    region=np.s_[top:top+DISPLAY[3],left:left+DISPLAY[2]]
    field=column(px[region],py[region],*step["shape"])
    mosaic=np.stack([parent[int(c),i//2::2,i%2::2]for i,c in enumerate(colors)]).ravel()
    result=[]
    gains=[]
    for c in range(3):
        keep=(a|b)&(data.colors==c)
        residual=data.raw[keep]-mosaic[keep]
        baseline=np.linalg.lstsq(same[keep],residual,rcond=None)[0][-1]
        mid,slope=np.linalg.lstsq(vary[keep],residual,rcond=None)[0][-2:]
        variance=data.shot*max(1e-4,float(np.median(data.raw[keep])))+data.read
        design=same[keep]
        noisy=variance*np.linalg.inv(design.T@design)[-1,-1]
        score=baseline/(baseline**2+noisy)
        result.append(1+(mid+slope*field-baseline)*score)
        gains.append({"constant_residual":float(baseline),"side_residual":[float(mid),float(slope)],
                      "variance_proxy":float(noisy)})
    return np.stack(result),{"step":step,"passed":True,"forecasts":evidence,"color_coefficients":gains}


def run():
    plan=read_json(ROOT/"plan.json")
    dest=ROOT/"edge-delivery";dest.mkdir()
    choices=[e for e in plan["cases"] if not e["independent"] and
             ((e["kind"]=="continuity"and e["g"]in (171,173,175))or
              (e["kind"]=="gaps"and e["g"]in (172,175)))]
    records=[]
    begin=time.monotonic()
    for entry in choices:
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-begin>1800:
                raise TimeoutError(path)
            time.sleep(2)
        row=read_json(path)
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            p,c,var,colors,parent,wide=(f[k]for k in("packed","target","variance","colors","parent","matching/wide"))
            masks={n:f[n]for n in("strong_phase","weak_phase","support")}
        variants={"attenuate":wide.copy(),"bounded":wide.copy()}
        artifacts=[]
        noise=plan["noise"][entry["profile"]]
        coarse=row["broad"]["matching"]
        for i,r in enumerate(coarse["roles"]):
            if "central_pair"not in r:
                continue
            packed=window(p[i],CENTRE,phase=2)
            sites=native_sites(packed.shape[-2:],(-127.5,-127.5))
            pair=tuple(Carrier(**a)for a in r["central_pair"])
            front,rear=(ribbon(*sites,v)for v in pair)
            ratio,log=correction(packed,window(parent[i],CENTRE),colors[i],front,rear,noise)
            if log["passed"]:
                witness=coarse["geometry"]
                frequency,warp=geometry.fit_geometry(*geometry.donor_arrays(witness,(383.5,383.5))[:3])[:2]
                moved=None
                if r["carried"]:
                    moved=tuple(Carrier(**a["carrier"])for a in coarse["donors"]["carriers"])
                recomputed,weak,_=reconstruct(parent[i],p[i],var[i],colors[i],CENTRE,DISPLAY,noise,(frequency,warp),moved)
                np.testing.assert_array_equal(recomputed,wide[i])
                for k,d in (("attenuate",1),("bounded",1.25)):
                    factor=np.clip(ratio,0,d)
                    variants[k][i]=(wide[i]+(factor-1)*weak).astype(wide.dtype)
            artifacts.append({"role":i,"step_model":log,"rms_change":{k:rms(d[i]-wide[i])for k,d in variants.items()}})
        before=row["metrics"]["matching/wide"]
        metrics={k:score(parent,d,c,masks)for k,d in variants.items()}
        saved=dest/(entry["id"]+".npz");np.savez_compressed(saved,**variants)
        records.append({"id":entry["id"],"entry":entry,"case":reference(path),"arrays":reference(saved),
                        "wide":before,"metrics":metrics,"certificates":artifacts})
        print(entry["id"],[(k,round(v["response"][0]*100,2),round(v["increment_RMS_DN16"][0],2),
                            round(v["gap_added_RMS_DN16"]or 0,2))for k,v in (("wide",before),*metrics.items())],
              flush=True)
    assert len(records)==10
    write_json(ROOT/"edge-delivery.json",{"driver":reference(__file__),"plan":reference(ROOT/"plan.json"),
                                          "cases":records,"scope":"Exploratory prechosen two-side delivery replay, prepared after viewing early fresh cases. Both raw fits exclude the reserve. Delivery noise proxy shrinks the input-output difference. Side amplitude may be attenuated or bounded to 125% of the existing rear contribution."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
