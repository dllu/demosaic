"""Run a prospective test of fixed step-aware variants on new raw observations."""

import importlib.util
import os
from pathlib import Path
import sys
import time
from itertools import product

import numpy as np
import torch
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(SOURCE))
spec=importlib.util.spec_from_file_location("preregistered_base",SOURCE/"fresh-study.py")
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
from deliver import CENTRE,DISPLAY,Carrier,score,window
from mesh import ribbon
from qualified_step import audit_masks
from scenes import observe
from sided import audit

RULE=("distributed","firm",1.5,False)
CONTROLS=("query","wide","column","distributed","short","spline-distributed")


def assess(items,parent,targets,outside,noise,entry):
    _,arrays,details=base.apply(items,parent,targets,outside,noise,entry)
    raw,cfa,clean=(items[k].numpy()for k in ("packed","colors","target"))
    bound={}
    metrics={"parent":score(parent,None,clean,targets)}
    findings={}
    for context,scene in details.items():
        for k in CONTROLS:
            bound[f"{context}/{k}"]=arrays[f"{context}/{k}"]
        whole=arrays[f"{context}/wide"]
        for m in ("step","sided"):
            bound[f"{context}/{m}"]=whole.copy()
        history=[]
        for i,row in enumerate(scene["roles"]):
            if "central_pair"not in row:
                continue
            block=window(raw[i],CENTRE,phase=2)
            x,y=native_sites(block.shape[-2:],(-127.5,-127.5))
            p,q=(ribbon(x,y,Carrier(**item))for item in row["central_pair"])
            first,receipt=audit_masks(block,cfa[i],p,q,noise,CENTRE,DISPLAY,(RULE,))[RULE]
            second,choice=audit(block,cfa[i],p,q,noise,CENTRE,DISPLAY)
            for k,mask in (("step",first),("sided",second)):
                bound[f"{context}/{k}"][i]=(whole[i]*(1-mask[None])).astype(whole.dtype)
            history.append({"role":i,"step":receipt,"sided":choice})
        findings[context]=history
    for k,v in bound.items():
        metrics[k]=score(parent,v,clean,targets)
    return metrics,bound,details,findings


@torch.inference_mode()
def main():
    earlier=read_json(SOURCE/"fresh-plan.json")
    dest=ROOT/"fresh";dest.mkdir()
    rows=[]
    for i,(mode,kind,g) in enumerate(product(("iso400","iso6400"),("continuity","gaps"),range(170,176))):
        layouts=("band","disk","ellipse")
        layout=("continuous"if g==170 else"step")if kind=="continuity"else layouts[(g-170)%3]
        rows.append({"id":f"{mode}-{layout}-g{g}","profile":mode,"kind":kind,"layout":layout,"g":g,
                     "seed":1143460137+i*37189+g*883,"rotated":g in (171,174),"independent":False})
    # Two independently drawn marginal repeats for each prior. The local
    # scene is unchanged. These rows do not enter the six-scene group means.
    for i,(mode,kind,g) in enumerate(product(("iso400","iso6400"),("continuity",), (171,173))):
        rows.append({"id":f"{mode}-step-g{g}-independent","profile":mode,"kind":kind,"layout":"step","g":g,
                     "seed":1399248217+i*97391+g*883,"rotated":False,"independent":True})
    plan={"sources":[reference(ROOT/k)for k in ("run_panel.py","scenes.py","sided.py")],
          "prior_plan":reference(SOURCE/"fresh-plan.json"),"prior_step":reference(SOURCE/"qualified_step.py"),
          "cases":rows,"checkpoint":earlier["checkpoint"],"noise":earlier["noise"],"query":CENTRE,"ROI":DISPLAY,
          "masks":["prior distributed background-only step","new side-dependent foreground and rear model"],
          "scope":"24 fixed fresh exact target RAW pairs, plus four repeats of continuous steps with independently drawn marginals. Both methods are fixed before collecting outputs. All methods receive the same delivered two-wire correction."}
    write_json(ROOT/"plan.json",plan)
    ck=plan["checkpoint"]
    model,state=load_scene_checkpoint(checked(ck),device="cuda",weights="ema",expected_sha256=ck["sha256"])
    assert state["step"]==2000;model.mode="none";del state
    start=time.monotonic();receipts=[]
    with ieee_fp32():
        for row in rows:
            noise=plan["noise"][row["profile"]]
            items,ext,masks,sensor,traits=observe(row,noise)
            model.base.set_noise(noise["shot"],noise["read"])
            parent=model(*(items[k].cuda()for k in ("packed","variance","colors","wb","matrix"))).cpu().numpy()
            metrics,arrays,details,proof=assess(items,parent,masks,ext,noise,row)
            name=row["id"]
            out=dest/(name+".npz")
            np.savez_compressed(out,parent=parent,**{k:v.numpy()for k,v in items.items()},**masks,**arrays)
            loc=dest/(name+".json")
            write_json(loc,{"id":name,"entry":row,"metrics":metrics,"traits":traits,"sensor":sensor,"broad":details,
                            "proof":proof,"saved":reference(out),"input":{k:fingerprint(v)for k,v in items.items()}})
            receipts.append(reference(loc))
            print(name,[(k,round(v["response"][0]*100,3),round(v["gap_added_RMS_DN16"]or 0,2),v["changed"])
                        for k,v in metrics.items()if k.startswith("matching/")],round(time.monotonic()-start,1),flush=True)
    assert len(receipts)==28
    write_json(ROOT/"fresh.json",{"measurements":receipts,"plan":reference(ROOT/"plan.json"),"seconds":time.monotonic()-start})


if __name__=="__main__":
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
