"""Compare the fixed side-aware model in both standing camera scenes."""

import importlib.util
import os
from pathlib import Path
import sys

import numpy as np
from demosaic._mesh_frequency import ADJACENT_SEARCH,adjacent_prior,infer_prior
from demosaic._mesh_profiles import ribbon
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.mesh_refinement import _overlap_correction

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(SOURCE))
spec=importlib.util.spec_from_file_location("prior_camera_geometry",SOURCE/"camera_step.py")
camera=importlib.util.module_from_spec(spec);spec.loader.exec_module(camera)
from deliver import window
from standing import legacy
import edge_delivery as delivery

PRIOR=ROOT.parent/"donor-phase-transport-v1"


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2))*65535)


def run():
    old=read_json(SOURCE/"camera-step.json")
    old_by_id={r["id"]:r for r in old["views"]}
    precision={r["id"]:r for r in read_json(PRIOR/"port.json")["cases"]}
    frames=read_json(ROOT.parent/"local-mesh-phase-evidence-v1"/"camera.json")
    dest=ROOT/"camera-rescale";dest.mkdir()
    records=[]
    for row in frames["views"]:
        key=row["id"]; before=old_by_id[key]
        box,roi,noise=row["query"],row["ROI"],row["noise"]
        with np.load(checked(before["camera_delta"]),allow_pickle=False)as f:
            packaged,step=(f[k]for k in("before","distributed"))
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            raw,var,cfa=(f[k][0]for k in("packed","variance","colors"))
            render={k:f[k]for k in("wb","matrix")}
        parent=np.load(checked(row["parent"]),allow_pickle=False)[0]
        trunk=window(parent,roi)
        result=rear=packaged
        proof=None
        if np.any(packaged!=trunk):
            opts={}
            donors=infer_prior(raw,cfa,box,noise,span=precision[key]["noise"]["donor_span"])
            current,pair=_overlap_correction(parent,raw,var,cfa,box,roi,noise,donors)
            if current is None or not current.any():
                donors=adjacent_prior(raw,cfa,box,noise)
                opts={"search":ADJACENT_SEARCH}
                current,pair=_overlap_correction(parent,raw,var,cfa,box,roi,noise,donors,**opts)
            np.testing.assert_array_equal(trunk+current,packaged)
            whole,soft=camera.front_field(parent,raw,var,cfa,box,roi,noise,donors,**opts)
            np.testing.assert_array_equal(whole,current)
            sample=window(raw,box,phase=2)
            positions=native_sites(sample.shape[-2:],(-127.5,-127.5))
            p,q=(ribbon(*positions,w)for w in pair)
            delivery.CENTRE, delivery.DISPLAY = box, roi
            factor,proof=delivery.correction(sample,window(parent,box),cfa,p,q,noise)
            result=trunk+(current+soft*(np.clip(factor,0,1)-1)).astype(current.dtype)
            rear=trunk+(current+soft*(np.clip(factor,0,1.25)-1)).astype(current.dtype)
        w,h=roi[2:]
        panels=[(tag,legacy.pixel(field,render,(0,0,w,h),before["exposure"]))for tag,field in (
            ("Attenuate rear at step",result),("Bounded rear rescale",rear))]
        board={"image":before["image"],"panels":[p for p in before["panels"]
                                                if p["label"]not in("Smooth with step","Rear only with step")]}
        image,coords=legacy.insert_camera_panels(dest,key,board,"Distributed with step",panels)
        fn=dest/(key+".npz")
        np.savez_compressed(fn,before=packaged,step=step,sided=result,rear=rear)
        difference={"background_step":rms(step-packaged),"sided":rms(result-packaged),
                    "sided_rear":rms(rear-packaged),"sided_minus_step":rms(result-step)}
        records.append({k:before[k]for k in("id","source","RAW","parent","exposure","ROI","query","noise")}|
                       {"image":image,"panels":coords,"proof":proof,"changes_DN16":difference,"arrays":reference(fn)})
        print(key,difference,proof and [round(s["z"],2)for s in proof.get("forecasts",())],flush=True)
    assert len(records)==8
    write_json(ROOT/"camera-rescale.json",{"driver":reference(__file__),"prior":reference(SOURCE/"camera-step.json"),
                                   "checkpoint":old["checkpoint"],"views":records,
                                   "scope":"Both methods use identical known packaged corrections from the 2k EMA and adjacent donor option, fixed native crops and noise. Step geometry comes from reserved RAW. Retrospective rescaling after watching early fresh examples. The camera references are qualitative."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
