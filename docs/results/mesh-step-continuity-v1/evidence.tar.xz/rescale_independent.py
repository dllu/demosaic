"""Test an audited side-dependent rear correction after the main fit."""

import importlib.util
import math
import os
from pathlib import Path
import sys
import time

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates,native_sites

ROOT=Path(__file__).resolve().parent
OLDER=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(OLDER))
sys.path.insert(2,str(ROOT.parent/"donor-phase-transport-v1"))
from deliver import CENTRE,DISPLAY,Carrier,geometry,score,window
from directional import reconstruct
from envelope_nuisance import observation,partition
from mesh import ribbon
from edge_delivery import correction,rms


def run():
    plan=read_json(ROOT/"plan.json")
    dest=ROOT/"rescale-independent";dest.mkdir()
    choices=[e for e in plan["cases"] if e["independent"]]
    records=[]
    begin=time.monotonic()
    for entry in choices:
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-begin>1800:
                raise TimeoutError(path)
            time.sleep(2)
        row=read_json(path)
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            p,c,var,colors,parent,wide=(f[k]for k in("packed","target","variance","colors","parent","matching/wide"))
            masks={n:f[n]for n in("strong_phase","weak_phase","support")}
        variants={"attenuate":wide.copy(),"bounded":wide.copy()}
        artifacts=[]
        noise=plan["noise"][entry["profile"]]
        coarse=row["broad"]["matching"]
        for i,r in enumerate(coarse["roles"]):
            if "central_pair"not in r:
                continue
            packed=window(p[i],CENTRE,phase=2)
            sites=native_sites(packed.shape[-2:],(-127.5,-127.5))
            pair=tuple(Carrier(**a)for a in r["central_pair"])
            front,rear=(ribbon(*sites,v)for v in pair)
            ratio,log=correction(packed,window(parent[i],CENTRE),colors[i],front,rear,noise)
            if log["passed"]:
                witness=coarse["geometry"]
                frequency,warp=geometry.fit_geometry(*geometry.donor_arrays(witness,(383.5,383.5))[:3])[:2]
                moved=None
                if r["carried"]:
                    moved=tuple(Carrier(**a["carrier"])for a in coarse["donors"]["carriers"])
                recomputed,weak,_=reconstruct(parent[i],p[i],var[i],colors[i],CENTRE,DISPLAY,noise,(frequency,warp),moved)
                np.testing.assert_array_equal(recomputed,wide[i])
                for k,d in (("attenuate",1),("bounded",1.25)):
                    factor=np.clip(ratio,0,d)
                    variants[k][i]=(wide[i]+(factor-1)*weak).astype(wide.dtype)
            artifacts.append({"role":i,"step_model":log,"rms_change":{k:rms(d[i]-wide[i])for k,d in variants.items()}})
        before=row["metrics"]["matching/wide"]
        metrics={k:score(parent,d,c,masks)for k,d in variants.items()}
        saved=dest/(entry["id"]+".npz");np.savez_compressed(saved,**variants)
        records.append({"id":entry["id"],"entry":entry,"case":reference(path),"arrays":reference(saved),
                        "wide":before,"metrics":metrics,"certificates":artifacts})
        print(entry["id"],[(k,round(v["response"][0]*100,2),round(v["increment_RMS_DN16"][0],2),
                            round(v["gap_added_RMS_DN16"]or 0,2))for k,v in (("wide",before),*metrics.items())],
              flush=True)
    assert len(records)==4
    write_json(ROOT/"rescale-independent.json",{"driver":reference(__file__),"plan":reference(ROOT/"plan.json"),
                                          "cases":records,"scope":"Fixed replay on four independently redrawn marginal pairs, planned after inspecting early coupled observations and before independent outputs. Both raw fits exclude the reserve. Delivery noise proxy shrinks the input-output difference. Side amplitude may be attenuated or bounded to 125% of the existing rear contribution."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
