"""Inspect false rear-direction admission after controlling the foreground step."""

import os
from pathlib import Path
import sys
import time

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/"mesh-envelope-support-v1"
sys.path.insert(1,str(SOURCE))
sys.path.insert(2,str(ROOT.parent/"donor-phase-transport-v1"))
from deliver import CENTRE,Carrier,window
from envelope_nuisance import observation,partition
from mesh import ribbon
from qualified_step import KNOTS,select_step


def evaluate(data, base, alternative, train, test):
    overlap=power=0.
    for c in range(3):
        a,b=train&(data.colors==c),test&(data.colors==c)
        y=data.raw[a]
        variance=data.shot*max(1e-4,float(np.median(y)))+data.read
        before,after=(x[b]@np.linalg.lstsq(x[a],y,rcond=None)[0]for x in (base,alternative))
        d=after-before
        overlap+=float((data.raw[b]-before)@d)/variance
        power+=float(d@d)/variance
    return {"gain":2*overlap-power, "z":float(overlap/np.sqrt(max(power,1e-20))), "change_power":power}


def run():
    plans=read_json(ROOT/"plan.json")
    cases=[]
    launch=time.monotonic()
    for entry in plans["cases"]:
        if entry["independent"]:
            continue
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-launch>1800:
                raise TimeoutError(path)
            time.sleep(2)
        row=read_json(path)
        noise=plans["noise"][entry["profile"]]
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            packed,colors=(f[k]for k in ("packed","colors"))
        values=[]
        for r in row["broad"]["matching"]["roles"]:
            if "central_pair"not in r:
                continue
            i=r["role"]
            local=window(packed[i],CENTRE,phase=2)
            first,second=(ribbon(*native_sites(local.shape[-2:],(-127.5,-127.5)),Carrier(**c))
                          for c in r["central_pair"])
            data=observation(local,colors[i],first,second,noise,KNOTS,flexible=True)
            slot=partition(local.shape,"distributed")
            x,y=data.positions
            adjusted,step=select_step((x,y,data.colors,slot,data.wave,data.nuisance,data.raw,noise))
            original=data.nuisance
            background=adjusted[5]
            wave=data.wave[:,None]
            if "shape"in step:
                trace=background[:,-1]
                background=np.column_stack((background,first.ravel()*trace))
                wave=np.column_stack((wave,data.wave*trace))
            a,b,d=(slot==i for i in (1,2,3))
            checks={}
            for name,design,profile in (("smooth",original,data.wave),("step",background,data.wave),
                                        ("sided",background,wave)):
                extra=np.column_stack((design,profile))
                fore=[evaluate(data,design,extra,learn,hold)for learn,hold in ((a,b),(b,a),(a|b,d))]
                checks[name]={"scores":fore, "positive":min(z["gain"]for z in fore)>0.,
                              "strong":min(z["z"]for z in fore)>1.75 and min(z["gain"]for z in fore)>0}
            values.append({"role":i,"step":step,"checks":checks})
        cases.append({"id":row["id"],"case":reference(path),"roles":values})
        print(row["id"],[(v["role"],{k:(m["positive"],m["strong"])for k,m in v["checks"].items()})
                          for v in values],flush=True)
    assert len(cases)==24
    write_json(ROOT/"admission-probe.json",{"driver":reference(__file__),"plan":reference(ROOT/"plan.json"),
                                            "cases":cases,"scope":"Post hoc raw forecast on fixed candidates of already-active corrections only. Tests one weak direction against an edge-aware null. No additional decisions or RGB outputs."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
