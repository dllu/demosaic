"""Compare the gap mask against a continuing wire with different contrast on each side."""

import math
import numpy as np
from demosaic.isolated_line import coordinates
from envelope_nuisance import basis,observation,partition,solve
from qualified_step import KNOTS,field_cut,select_step


def prepare(data, wave, train, test):
    background=np.column_stack((data.nuisance,wave))
    records=[]
    for c in range(3):
        a,b=train&(data.colors==c),test&(data.colors==c)
        xa,xb=background[a],background[b]
        ya=data.raw[a]
        normal=xa.T@xa
        beta=np.linalg.solve(normal,xa.T@ya)
        # Scale spatial amplitude columns by the fitted continuous waveform
        # on each side of the step, separately for each sensor color.
        gains=beta[-wave.shape[1]:]
        varying=data.spline*(wave@gains)[:,None]
        va,vb=varying[a],varying[b]
        projected=np.linalg.solve(normal,xa.T@va)
        variance=data.shot*max(1e-4,float(np.median(ya)))+data.read
        records.append({
            "design":va-xa@projected,"residual":ya-xa@beta,
            "test_design":vb-xb@projected,"test_residual":data.raw[b]-xb@beta,
            "variance":variance,"linear_gain":float(gains[0]),
        })
    lhs=sum(r["design"].T@r["design"]/r["variance"]for r in records)
    rhs=sum(r["design"].T@r["residual"]/r["variance"]for r in records)
    return lhs,rhs,records


def forecast(data,wave,a,b,cut):
    whole=np.column_stack((data.nuisance,wave))
    supported=np.column_stack((data.nuisance,wave*(1-cut[:,None])))
    agreement=power=0.
    for c in range(3):
        train=a&(data.colors==c);test=b&(data.colors==c)
        observed=data.raw[train]
        variance=data.shot*max(1e-4,float(np.median(observed)))+data.read
        before,after=(x[test]@np.linalg.solve(x[train].T@x[train],x[train].T@observed)
                      for x in(whole,supported))
        d=after-before
        agreement+=float((data.raw[test]-before)@d)/variance
        power+=float(d@d)/variance
    gain=2*agreement-power
    return {"gain":gain,"power":power,"z":gain/(2*math.sqrt(max(power,1e-12)))}


def audit(raw,colors,front,rear,noise,query,roi):
    data=observation(raw,colors,front,rear,noise,KNOTS,flexible=True)
    x,y=data.positions
    slots=partition(raw.shape,"distributed")
    answer,step=select_step((x,y,data.colors,slots,data.wave,data.nuisance,data.raw,noise))
    data.nuisance=answer[5]
    wave=data.wave[:,None]
    if "shape"in step:
        sides=data.nuisance[:,-1]
        data.nuisance=np.column_stack((data.nuisance,front.ravel()*sides))
        wave=np.column_stack((wave,data.wave*sides))
    nx,ny=coordinates(256,256,origin=(-127.5,-127.5))
    left,top=roi[0]-query[0],roi[1]-query[1]
    w,h=roi[2:]
    page=np.s_[top:top+h,left:left+w]
    grid=basis(nx[page],ny[page],KNOTS)
    reference=basis(nx[::5,::5],ny[::5,::5],KNOTS)
    a,b,d=[slots==j for j in(1,2,3)]
    splits=((a,b),(b,a),(a|b,d))
    checks=[]
    for train,test in splits:
        coeff,quality=solve(prepare(data,wave,train,test),1.2)
        nomination=field_cut(data.spline,reference,coeff,"firm")
        checks.append({"forecast":forecast(data,wave,train,test,nomination),"spatial":quality})
    passed=min(v["forecast"]["z"]for v in checks[:2])>.75 and checks[-1]["forecast"]["z"]>1.5
    mask=field_cut(grid,reference,coeff,"firm").reshape(h,w)if passed else np.zeros((h,w))
    return mask,{"passed":bool(passed),"step":step,"tests":checks,
                 "mask_mean":float(mask.mean()),"mask_max":float(mask.max())}
