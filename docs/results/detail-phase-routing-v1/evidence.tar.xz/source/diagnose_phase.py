"""Check source isolation and the spatial witness against exact fixture support."""

import json
from pathlib import Path
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_routing import HERE, OUT, PRIOR_OUT, scoring
from phase_route import fields

import sys

sys.path.insert(0, str(HERE.with_name("direct-detail-response-v1")))
from audit_sources import CORPUS, LOCAL, matches
from collect_wire_gate import identities

CORE = np.s_[2:6, 2:6]
BAND_TOL = 0.0234375


def audit():
    selection = reference(OUT / "confirmation/plan.json")
    current = read_json(checked(selection))
    panel = identities(r["source"] for r in current["groups"]["held"])
    assert len(panel) == 112
    for key in ("previous_plan", "previous_confirmation"):
        old = read_json(checked(current[key]))
        for group in old["groups"].values():
            assert panel.isdisjoint(identities(r["source"] for r in group))
    assert panel.isdisjoint(identities(read_json(checked(current["fixed427"]))["source_metadata"]))
    with checked(current["training_manifest"]).open() as f:
        assert panel.isdisjoint(identities(map(json.loads, f)))
    core, end = reference(CORPUS), reference(LOCAL)
    history, terminal = read_json(checked(core)), read_json(checked(end))
    assert history["checkpoint"] == terminal["parent"] and terminal["checkpoint"] == current["parent"]
    visits = 0
    for segment in history["source_traces"]:
        with checked(segment).open() as f:
            for line in map(json.loads, f):
                for row in line["sources"]:
                    if row["kind"] == "photographic":
                        assert not matches(row, panel)
                        visits += 1
    tail = 0
    for segment in terminal["segments"]:
        with checked(segment["observations"]).open() as f:
            for row in map(json.loads, f):
                assert not matches(row, panel)
                tail += 1
    assert (visits, tail) == (559808, 5000)
    return {"selection": selection, "corpus": core, "local": end, "sources": 56,
            "corpus_visits": visits, "local_visits": tail}


def counts(active, use, match, category):
    return {
        "total": int(category.sum()),
        "exterior": int((category & active).sum()),
        "local": int((category & active & use).sum()),
        "weak_frequency": int((category & active & match).sum()),
        "weak_frequency_local": int((category & active & use & match).sum()),
    }


def diagnose(source):
    output = []
    for row, d, p, bind in scoring.loads(source):
        if row["kind"] != "wire":
            continue
        _, _, m = fields(d, p, row["profile"])
        active = m["active"][:, CORE[0], CORE[1]]
        witness = m["local"][:, CORE[0], CORE[1]] > 0
        f = m["phase"][:, CORE[0], CORE[1]]
        geometry = row["fixture"]["geometry"]
        weak = np.asarray(geometry["frequency"][1])[::-1]
        error = np.minimum(np.linalg.norm(f - weak, axis=-1), np.linalg.norm(f + weak, axis=-1))
        match = error <= BAND_TOL
        support = d["support"].reshape(8, 32, 8, 32)
        intact = ((support >= 0.97).mean(axis=(1, 3)) >= 0.85)[CORE]
        gap = ((support == 0).mean(axis=(1, 3)) >= 0.25)[CORE]
        if geometry["family"] not in ("ellipse", "strip"):
            gap = np.zeros_like(gap)
            intact = np.ones_like(intact)
        unit = np.ones_like(gap)
        cells = {}
        for label, region, role in (
            ("intact", intact, 0), ("gap", gap, 0), ("gap-exterior-role", gap, 1),
            ("strong-only", unit, 2), ("wire-flat", unit, 3),
        ):
            cells[label] = counts(active[role], witness[role], match[role], region)
        output.append({"id": row["id"], "proof": bind, "cells": cells})
    aggregate = {k: {m: sum(r["cells"][k][m] for r in output) for m in vals}
                 for k, vals in output[0]["cells"].items()}
    return {"rows": output, "summary": aggregate}


if __name__ == "__main__":
    start = monotonic()
    source = reference(OUT / "confirmation/held/completed.json")
    isolation = audit()
    measured = diagnose(source)
    print(isolation["sources"], measured["summary"], monotonic() - start, flush=True)
    write_json(OUT / "diagnostic.json", {
        "driver": reference(Path(__file__)), "collection": source, "audit": isolation,
        "operator": reference(HERE / "phase_route.py"), "diagnostic": measured,
        "frequency_tolerance_cycles": BAND_TOL,
        "scope": "Central station census, not independent samples. Frequencies compare with the planted fundamental.",
    })
