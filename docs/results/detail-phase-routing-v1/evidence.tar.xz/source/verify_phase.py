"""Check phase offsets, the withheld-center dependency and a null field."""

import numpy as np

from phase_route import inspect, observations

H = 128
BASE = 0.19
PIVOT = (48, 48)
COARSE = dict(shot=0.00128, read=6.5536e-6)
COLORS = (0, 1, 1, 2)
STRONG = np.array([0.046875, 0.0703125])
WEAK = np.array([0.0859375, -0.046875])


def compose(remove_center=False, uniform=False):
    y, x = np.mgrid[:H, :H] - 47.5
    major = 0.035 * np.cos(2 * np.pi * (STRONG[0] * y + STRONG[1] * x) + 0.2)
    minor = 0.023 * np.cos(2 * np.pi * (WEAK[0] * y + WEAK[1] * x) - 0.8)
    if remove_center:
        minor[(np.abs(y) < 16) & (np.abs(x) < 16)] = 0
    true = BASE + major + minor
    anchor = BASE + 0.8 * major
    if uniform:
        true = np.broadcast_to(BASE, true.shape)
        anchor = true
    raw = np.stack([true[i::2, j::2] for i, j in ((0, 0), (0, 1), (1, 0), (1, 1))])[None]
    return raw, anchor[None]


def measure(**changes):
    raw, anchor = compose(**changes)
    sensors = [observations(raw, anchor, COARSE, i) for i in (1, 2)]
    # Only station (1,1) is used for the causal intervention.
    i = np.ravel_multi_index((0, 1, 1), sensors[0]["shape"])
    return tuple(v[i] for v in inspect(sensors))


if __name__ == "__main__":
    a, b, flat = measure(), measure(remove_center=True), measure(uniform=True)
    f, angle, dose, gate, active, z = a
    print("present", a, "missing", b, "flat", flat)
    assert active and dose > 0 and z > 2 and gate > 0.5
    assert np.linalg.norm(f - WEAK) <= 1 / 128
    np.testing.assert_array_equal(a[0], b[0])
    np.testing.assert_array_equal(a[1], b[1])
    np.testing.assert_allclose(a[2], b[2], atol=1e-12, rtol=0)
    assert b[3] == 0 and flat[2] == flat[3] == 0
