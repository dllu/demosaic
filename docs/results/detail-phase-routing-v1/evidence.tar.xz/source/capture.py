"""Freeze an independent replay under the standing optical and photo protocols."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("detail-shared-oracle-v1")))

spec = spec_from_file_location("previous_confirmation", HERE.with_name("detail-shared-oracle-v1") / "confirm_capture.py")
previous = module_from_spec(spec)
spec.loader.exec_module(previous)

SEED = 202611201108
PRIOR = previous.OUT / "confirmation"


def select():
    old = reference(PRIOR / "plan.json")
    earlier = read_json(checked(old))
    identities = previous.c.identities
    seen = identities(r["source"] for r in earlier["groups"]["held"])
    with (
        patch.object(previous, "SEED", SEED),
        patch.object(previous.c, "identities", lambda sources: identities(sources) | seen),
    ):
        plan = previous.select()
    ids = previous.c.identities(r["source"] for r in plan["groups"]["held"])
    assert len(ids) == 112 and ids.isdisjoint(seen)
    return plan | {"followup_driver": reference(Path(__file__)), "previous_confirmation": old}


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    if not (plan := folder / "plan.json").exists():
        write_json(plan, select())
    with patch.object(previous.c, "OUT", folder), patch.object(previous.c, "SEED", SEED):
        previous.c.collect("held")
