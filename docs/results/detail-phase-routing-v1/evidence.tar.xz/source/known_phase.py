"""Diagnose frequency nomination separately from the held phase check."""

from pathlib import Path
from time import monotonic
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_routing import HERE, OUT, METHODS, scoring
import phase_route as operator

METRICS = (
    "weak_response_pp", "intact_increment_RMS_DN16", "gap_continuing_strong_RMS_DN16",
    "gap_weak_RMS_DN16", "gap_RMS_DN16", "exterior_only_weak_RMS_DN16",
    "exact_flat_RMS_DN16",
)


def reveal(geometry):
    ordered = np.asarray(geometry["frequency"])[:, ::-1].copy()
    for f in ordered:
        if f[0] < 0 or (f[0] == 0 and f[1] < 0):
            f *= -1

    def exact(sensors, residual, excluded):
        f = ordered[int(excluded.shape[1] > 0)]
        coeff = []
        for s, e in zip(sensors, residual, strict=True):
            w = s["exterior"]
            phase = np.exp(-2j * np.pi * (s["coord"] @ f))
            dev = np.sqrt(np.maximum(1e-10, (w**2).sum(-1) * s["noise"]))
            coeff.append(((w * e) @ phase) / dev)
        support = np.real(coeff[0] * coeff[1].conj())
        return np.broadcast_to(f, (len(support), 2)), support

    return exact


def evaluate():
    start = monotonic()
    proof = reference(OUT / "score-held.json")
    result = read_json(checked(proof))
    source = reference(OUT / "confirmation/held/completed.json")
    _, factory = scoring.wire_scorer()
    rows = []
    for case, d, p, bind in scoring.loads(source):
        if case["kind"] != "wire":
            continue
        geometry = case["fixture"]["geometry"]
        with patch.object(operator, "discover", reveal(geometry)):
            v, neutral, details = operator.fields(d, p, case["profile"])
        if geometry["family"] not in ("ellipse", "strip"):
            d = d | {"support": np.ones_like(d["support"])}
        scorer = factory(d, geometry)
        moves = {k: w[:, None] * neutral[None, :, None, None] for k, w in v.items()}
        c = np.s_[:, 2:6, 2:6]
        active = details["active"][c]
        accepted = details["local"][c] > 0
        terms = scoring.polynomial(scorer, p["nominal"], moves)
        rows.append({
            "id": case["id"], "proof": bind, "terms": terms,
            "active_by_role": active.sum((1, 2)).tolist(),
            "accepted_by_role": (active & accepted).sum((1, 2)).tolist(),
        })
    held = [r for r in result["rows"] if r["kind"] == "wire"]
    assert [r["id"] for r in rows] == [r["id"] for r in held]
    dosing = {k: v["locked"]["dose"] for k, v in result["policy"]["arms"].items()}
    rng = np.random.default_rng(202611201111)
    values = {}
    same = {}
    with patch.object(scoring, "METHODS", METHODS):
        response = "weak_response_pp"
        mean = lambda arm, dose: scoring.wire_values(held, arm, response, dose).mean()
        origin = mean("nominal", 0)
        target = mean("directional", 1) - origin
        exterior = target / (mean("exterior", 1) - origin)
        assert 0 <= exterior <= 1
        for m in METRICS:
            base = scoring.wire_values(held, "nominal", m, 0)
            values[m] = {
                k: {str(d): float((scoring.wire_values(rows, k, m, d) - base).mean())
                    for d in (dosing.get(k, dosing["directional"]), 1.0)}
                for k in ("exterior", "directional", "rolled directional")
            }
            effects = {
                "held_minus_rolled_at_lock": (
                    scoring.wire_values(held, "directional", m, dosing["directional"]),
                    scoring.wire_values(held, "rolled directional", m, dosing["directional"]),
                ),
                "held_minus_exterior_at_equal_response": (
                    scoring.wire_values(held, "directional", m, 1),
                    scoring.wire_values(held, "exterior", m, exterior),
                ),
            }
            same[m] = {}
            for key, (a, b) in effects.items():
                diff = a - b
                ix = rng.integers(len(diff), size=(12000, len(diff)))
                same[m][key] = [float(diff.mean()), *np.quantile(diff[ix].mean(1), (0.025, 0.975)).tolist()]
    summary = {k: np.sum([r[k] for r in rows], axis=0).tolist()
               for k in ("active_by_role", "accepted_by_role")}
    print(values, same, summary, flush=True)
    write_json(OUT / "known-phase.json", {
        "driver": reference(Path(__file__)), "collection": source, "score": proof,
        "operator": reference(HERE / "phase_route.py"), "rows": rows, "known_phase_changes": values,
        "discovered_phase_controls": same, "known_phase_station_counts": summary,
        "discovered_phase_matched_response": target, "discovered_phase_exterior_dose": exterior,
        "elapsed": monotonic() - start,
        "scope": "True planted frequencies inaccessible during inference. Candidate phase and amplitude still estimated from exterior RAW. Center witnesses unchanged.",
    })


if __name__ == "__main__":
    evaluate()
