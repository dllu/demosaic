"""Evaluate the locked central and nested gates on fresh exact and standing scenes."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from nested_gate import BASE_CLEARANCE, FRESH_CLEARANCE, METHODS, apply, nominal_peaks
from freeze_nested import OUT, POLICIES
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_ring import (
    ABS, ABSOLUTE, FALSE, FIXED, FLAT, GAP, LENGTH, ROI, WireFundamental,
    arrays, display, interval, native_board, source_bootstrap, support_for_scoring,
)
from optical_response_balance import calibration
from scoring import luma
from score_center_guard import section

LABELS = {
    "local50k": "Local 50k",
    "broad": "Broad check",
    "center3": "Center 3",
    "nested": "Combined check",
    "center1.5": "Center 1.5",
    "v120": "V120 EMA",
}
METRICS = (ABSOLUTE, LENGTH, ABS, GAP, FALSE, FLAT,
           "edge_target_RMS_DN16", "uniform_target_RMS_DN16", "edge_update_RMS_DN16", "uniform_update_RMS_DN16")
NULLS = {"short_only": 2, "flat": 3, "edge_only": 4, "uniform": 5}


def profile_with_color(f, noise):
    return noise | {k: f[k] for k in ("wb", "matrix")}


def mix(original, changed, gains):
    return {arm: original + (changed[arm] - original) * gain for arm, gain in gains.items()}


def null_measures(candidate, original, f):
    values = {}
    for index, name in ((4, "edge"), (5, "uniform")):
        attrs = f["wb"], f["matrix"]
        selected = np.s_[..., 64:192, 64:192]
        image = luma(candidate[index:index+1][selected], *attrs)
        truth = luma(f["target"][index:index+1][selected], *attrs)
        prior = luma(original[index:index+1][selected], *attrs)
        values[name+"_target_RMS_DN16"] = float(np.sqrt(np.mean((image - truth)**2)) * 65535)
        values[name+"_update_RMS_DN16"] = float(np.sqrt(np.mean((image - prior)**2)) * 65535)
    return values


def observe(fixture, row, match, plan, dest):
    f = arrays(row["data"])
    parent = np.load(checked(row["outputs"]["local50k"]), allow_pickle=False)
    v120 = np.load(checked(row["outputs"]["v120"]), allow_pickle=False)
    x, y, _, _ = plan["query"]
    roi = (x + ROI[0], y + ROI[1], *ROI[2:])
    cut = np.s_[..., y//2:(y+256)//2, x//2:(x+256)//2]
    scene = f["scene_packed"].copy()
    colors = f["colors"]
    peaks = nominal_peaks(scene, colors, roi, FRESH_CLEARANCE)
    profile = profile_with_color(f, plan["noise"])
    corrected = {k: parent.copy() for k in METHODS}
    counts = []
    for i, packed in enumerate(f["packed"]):
        scene[cut] = packed
        # The complete query is excluded from nomination in every role.
        np.testing.assert_array_equal(nominal_peaks(scene, colors, roi, FRESH_CLEARANCE), peaks)
        selected, active = apply(parent[i], ROI, scene, colors, roi, peaks, profile)
        for k, value in selected.items():
            section(corrected[k][i], *ROI)[:] = value
        counts.append(active)

    mask = support_for_scoring(f["support"])
    g = fixture["geometry"]
    a = WireFundamental(f | {"support": mask, "target": f["sharp_target"]}, g)
    b = WireFundamental(f | {"support": mask, "target": f["target"][:4]}, g)
    assert np.array_equal(a.intact, b.intact) and np.array_equal(a.gap, b.gap)

    def measure(pred):
        return b(pred[:4]) | {ABSOLUTE: a(pred[:4])[LENGTH]} | null_measures(pred, parent, f)

    levels = {
        name: {arm: measure(value) for arm, value in mix(parent, corrected, gains).items()}
        for name, gains in match.items()
    }
    identity = fixture["id"]
    all_predictions = {"local50k": parent} | corrected | {"v120": v120}
    if fixture["index"] in plan["native_indices"] and not row["draw"]:
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        camera["packed"] = f["packed"][:1]
        frames = [noisy_malvar(camera)[0], *(all_predictions[key][0] for key in LABELS), f["target"][0]]
        native = native_board(
            dest, identity, frames, camera,
            {"source": fixture, "query": plan["query"], "noise": plan["noise"], "input": row["data"],
             "optical_sigma": plan["sigma"], "draw": row["draw"], "weights": plan["checkpoints"]},
            labels=["Noisy Malvar", *LABELS.values(), "Exact GT"], triplet_indices=(0, 4, 7),
        )
    else:
        native = None
    return {
        "draw": row["draw"], "input": row["data"], "parents": row["outputs"],
        "peak_frequencies": None if peaks is None else peaks.tolist(), "activity": counts,
        "nominal": {k: measure(v) for k, v in all_predictions.items()},
        "matched": levels, "has_gap": bool(a.gap.any()),
        "strength_DN16": float(np.sqrt(a.clean_norm / a.intact.sum()) * 65535), "native": native,
    }


def effects(rows, arm, baseline, data_key, policy=None):
    rng = np.random.default_rng(202611200129)
    out = {}
    for key in METRICS:
        sample = []
        for r in rows:
            draws = [e[data_key] if policy is None else e[data_key][policy] for e in r["draws"]]
            if not all(key in d[arm] for d in draws):
                continue
            scores = [(d[arm][key], d[baseline][key]) for d in draws]
            sample.append({"family": r["family"], "score": np.mean(scores, axis=0)})
        indices = source_bootstrap(sample, rng)
        values = np.array([r["score"] for r in sample])[indices].mean(1)
        out[key] = {
            "source_count": len(sample), "arm_mean": interval(values[:, 0]),
            "baseline_mean": interval(values[:, 1]), "paired_difference": interval(values[:, 0] - values[:, 1]),
        }
    return out


def false_activity(rows):
    total = {}
    for label, i in NULLS.items():
        counts = {}
        for arm in METHODS:
            windows = [np.array(d["activity"][i][arm]) for r in rows for d in r["draws"]]
            matched = []
            for r in rows:
                present = [any(d["activity"][i][arm]) for d in r["draws"]]
                matched.append(present)
            counts[arm] = {
                "crop_activations": sum(bool(w.any()) for w in windows),
                "windows_by_direction": np.sum(windows, axis=0).tolist(),
                "same_source_both_draws": sum(all(x) for x in matched),
            }
        total[label] = {"all_crops": 2 * len(rows), "source_count": len(rows), "methods": counts}
    return total


def standing(weight, dest):
    original = reference(FIXED)
    dataset = read_json(checked(original))
    assert dataset["checkpoints"]["local50k"] == weight
    rows = []
    for r in dataset["standing"]:
        f = arrays(r["input"])
        p = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(r["local_ROI"])
        peaks = nominal_peaks(scene, colors, roi, BASE_CLEARANCE)
        near = nominal_peaks(scene, colors, roi, 0)
        distant = nominal_peaks(scene, colors, roi, FRESH_CLEARANCE)
        altered = scene.copy()
        x, y = roi[:2]
        # Mutate the covering packed rectangle. For odd origins this rounds
        # the rectangle outwards by up to one pixel in each direction.
        # Keep only the exact native CFA sites inside the held footprint.
        for phase in range(4):
            row, col = divmod(phase, 2)
            xx, yy = x - BASE_CLEARANCE, y - BASE_CLEARANCE
            span = roi[2] + 2 * BASE_CLEARANCE
            altered[phase, (yy-row+1)//2:(yy+span-row+1)//2,
                    (xx-col+1)//2:(xx+span-col+1)//2] = .111
        np.testing.assert_array_equal(nominal_peaks(altered, colors, roi, BASE_CLEARANCE), peaks)
        restored, counts = apply(p, roi, scene, colors, roi, peaks, r["noise"] | {"wb": wb, "matrix": matrix})
        prior = section(p, *roi)
        images = []
        for view in r["displays"]:
            exp = view["exposure"]
            existing = view["board"]
            with Image.open(checked(existing["image"])) as img:
                a = np.asarray(img)
                frames = {}
                for panel in existing["panels"]:
                    x, y, w, h = panel["png_xywh"]
                    frames[panel["name"]] = a[y:y+h, x:x+w]
            np.testing.assert_array_equal(display(prior, wb, matrix, exp), frames["Local 50k"])
            names = ("Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Local 50k")
            pairs = [(name, frames[name]) for name in names]
            pairs.extend((LABELS[k], display(restored[k], wb, matrix, exp)) for k in METHODS)
            pairs.extend((name, frames[name]) for name in (
                "ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG",
            ) if name in frames)
            board = Image.new("RGB", (8 + 168 * len(pairs), 192), "#eeeeee")
            draw = ImageDraw.Draw(board)
            columns = []
            for i, (name, pixels) in enumerate(pairs):
                x = 8 + 168*i
                assert pixels.shape == (160, 160, 3)
                board.paste(Image.fromarray(pixels), (x, 24))
                draw.text((x, 5), name, fill="black")
                columns.append({"label": name, "PNG_xywh": [x, 24, 160, 160]})
            path = dest / f'{r["id"]}-x{exp:g}.png'
            board.save(path)
            images.append({"image": reference(path), "exposure": exp, "columns": columns, "references": existing})
        rows.append({
            "id": r["id"], "noise": r["noise"], "native_ROI_xywh": r["global_ROI"],
            "input": r["input"], "parent": r["predictions"]["local50k"], "raw": r["raw"],
            "nomination": None if peaks is None else peaks.tolist(),
            "zero_clearance_nomination": None if near is None else near.tolist(),
            "distant_nomination": None if distant is None else distant.tolist(), "passes": counts,
            "RMS_DN16": {k: float(np.sqrt(np.mean((value.astype(float) - prior)**2))*65535)
                         for k, value in restored.items()},
            "native": images,
        })
    assert len(rows) == 8
    return {"archive": original, "clearance": BASE_CLEARANCE, "rows": rows}


def main():
    torch.set_num_threads(2)
    start = time.monotonic()
    refs = {n: reference(OUT / path) for n, path in (
        ("analysis", "analysis-plan.json"), ("input", "inputs.json"), ("parents", "parent/result.json"),
    )}
    fixed = read_json(checked(refs["analysis"]))
    bundle = read_json(checked(refs["input"]))
    parents = read_json(checked(refs["parents"]))
    data = read_json(checked(bundle["plan"]))
    assert parents["inputs"] == refs["input"] and fixed["policies"] == data["policies"] == POLICIES
    assert fixed["parent_checkpoint"] == parents["weights"]["local50k"] == data["checkpoints"]["local50k"]
    assert fixed["whole_query_clearance"] == FRESH_CLEARANCE
    match = {"locked_center": fixed["locked_center_comparison"]} | {
        arm: record["gains"] for arm, record in fixed["same_clearance_matches"].items()
    }
    alternate = calibration(fixed["calibration_rows"], ("center3", "nested"))
    assert alternate["calibrated"]
    match["nested_vs_center3"] = alternate["gains"]
    initial_binding = reference(OUT / "result.json")
    initial = read_json(checked(initial_binding))
    assert initial["bindings"] == refs
    out = OUT / "native-v2"
    out.mkdir(exist_ok=True)
    exact = out / "exact"
    real = out / "standing"
    exact.mkdir(exist_ok=True)
    real.mkdir(exist_ok=True)
    rows = []
    for p, f in zip(parents["records"], data["sources"], strict=True):
        assert p["id"] == f["id"]
        values = [observe(f, stream, match, data, exact) for stream in p["streams"]]
        assert len(values) == 2 and values[0]["strength_DN16"] == values[1]["strength_DN16"]
        rows.append({"id": p["id"], "fixture": f, "family": f["geometry"]["family"], "draws": values})
        if len(rows) % 8 == 0:
            print("Scored", len(rows), flush=True)
    results = {
        "nominal_vs_parent": {arm: effects(rows, arm, "local50k", "nominal")
                              for arm in (*METHODS, "v120")},
        "nominal_vs_broad": {arm: effects(rows, arm, "broad", "nominal")
                             for arm in ("center3", "center1.5", "nested")},
        "response_matched_comparisons": {policy: effects(
            rows,
            {"locked_center": "center3", "nested_vs_center3": "nested"}.get(policy, policy),
            "center3" if policy == "nested_vs_center3" else "broad", "matched", policy,
        ) for policy in match},
        "null_role_activity": false_activity(rows),
    }
    for r, before in zip(rows, initial["exact"], strict=True):
        for new, old in zip(r["draws"], before["draws"], strict=True):
            assert new["nominal"] == old["nominal"] and new["activity"] == old["activity"]
    series = standing(fixed["parent_checkpoint"], real)
    write_json(OUT / "result-v2.json", {
        "driver": reference(__file__), "bindings": refs, "plan": bundle["plan"], "weights": parents["weights"],
        "nominal_gain": .73, "source_clearance": FRESH_CLEARANCE,
        "initial_review": initial_binding, "matches": match, "results": results, "exact": rows, "standing": series, "seconds": time.monotonic()-start,
    })


if __name__ == "__main__":
    main()
