"""Lock the nested gate response match on the earlier 32 calibration photos."""

import sys
from pathlib import Path
import time

import numpy as np

from nested_gate import METHODS, FRESH_CLEARANCE, apply, nominal_peaks
from freeze_nested import CACHE, CUTOFF, OUT, PANEL, POLICIES
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_ring import ABSOLUTE, LENGTH, ROI, WireFundamental, arrays, coefficients, frozen_inputs, support_for_scoring
from optical_response_balance import calibration
from score_center_guard import section

sweep_ref = reference(CUTOFF)
previous = read_json(checked(sweep_ref))
CENTER = previous["matched_response"]["3.0"]["fit"]["gains"]


def calibrated_case(row, profile):
    fixture = frozen_inputs(row)
    f, parent, scene, roi, case = (
        fixture[k] for k in ("input", "parent", "scene", "phase_correction_roi", "case")
    )
    support = support_for_scoring(f["support"])
    geo = case["fixture"]["geometry"]
    sharp = arrays(case["inputs"]["0.0"])
    target = WireFundamental(sharp | {"support": support}, geo)
    metric = WireFundamental(f | {"support": support}, geo)
    outputs = {k: parent.copy() for k in METHODS}
    nomination = nominal_peaks(scene, f["colors"], roi, FRESH_CLEARANCE)
    for i, packed in enumerate(f["packed"]):
        scene[fixture["cut"]] = packed
        new = nominal_peaks(scene, f["colors"], roi, FRESH_CLEARANCE)
        np.testing.assert_array_equal(nomination, new)
        views, counts = apply(
            parent[i], ROI, scene, f["colors"], roi, nomination, profile | {"wb": f["wb"], "matrix": f["matrix"]},
        )
        for k, value in views.items():
            section(outputs[k][i], *ROI)[:] = value

    def measure(prediction):
        return metric(prediction) | {ABSOLUTE: target(prediction)[LENGTH]}

    return {"id": case["id"], "response_balance": coefficients(parent, outputs, measure)}


if __name__ == "__main__":
    start = time.monotonic()
    binding = reference(PANEL)
    parent = read_json(checked(binding))
    prior = parent["panels"]["previous"]
    rows = [calibrated_case(r, prior["profile"]) for r in prior["rows"]]
    assert len(rows) == 32
    fit = {arm: calibration(rows, ("broad", arm)) for arm in ("nested", "center3")}
    assert all(x["calibrated"] for x in fit.values())
    write_json(OUT / "analysis-plan.json", {
        "driver": reference(__file__), "operator": reference(Path(__file__).with_name("nested_gate.py")),
        "calibration_parent": binding, "earlier_center": sweep_ref,
        "locked_center_comparison": {"broad": CENTER["broad"], "center3": CENTER["3.0"]},
        "same_clearance_matches": fit, "policies": POLICIES, "whole_query_clearance": FRESH_CLEARANCE,
        "parent_checkpoint": parent["checkpoint"], "calibration_rows": rows, "seconds": time.monotonic()-start,
    })
    print(fit, flush=True)
