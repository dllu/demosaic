"""Publish the fresh null and weak-detail replay with its actual native crops."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from freeze_nested import HERE, OUT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


REPO = HERE.parents[2]


def main():
    review = reference(OUT / "result-v2.json")
    result = read_json(checked(review))
    a, inputs, parents = (result["bindings"][k] for k in ("analysis", "input", "parents"))
    plan = read_json(checked(result["plan"]))
    analysis = read_json(checked(a))
    capture = read_json(checked(inputs))
    prior = read_json(checked(parents))
    assert capture["plan"] == result["plan"] and prior["inputs"] == inputs
    previous = read_json(checked(result["initial_review"]))
    assert previous["weights"] == result["weights"] == prior["weights"]
    assert len(result["exact"]) == plan["source_count"] == 32
    assert sum(d["has_gap"] for r in result["exact"] for d in r["draws"]) == 32
    assert len({r["fixture"]["source"]["cache_sha256"] for r in result["exact"]}) == 32
    assert len(result["standing"]["rows"]) == 8
    native_exact = [d["native"] for r in result["exact"] for d in r["draws"] if d["native"] is not None]
    native_real = [v for r in result["standing"]["rows"] for v in r["native"]]
    assert len(native_exact) == 2 and len(native_real) == 12
    sources = [(v[k]["image"], count) for v in native_exact for k, count in (("triplet", 3), ("board", 8))]
    sources.extend((v["image"], len(v["columns"])) for v in native_real)
    assets = REPO / "docs/assets" / HERE.name
    dest = REPO / "docs/results" / HERE.name
    assets.mkdir()
    dest.mkdir()
    images = []
    for item, cols in sources:
        src = checked(item)
        with Image.open(src) as img:
            assert img.size == (8+168*cols, 192)
        fp = assets / src.name
        shutil.copyfile(src, fp)
        assert reference(fp)["sha256"] == item["sha256"]
        images.append({"path": str(fp.relative_to(REPO)), "sha256": item["sha256"]})
    archive = dest / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=3) as bundle:
        for name, binding in (
            ("plan", result["plan"]), ("analysis-plan", a), ("inputs", inputs), ("parents", parents),
            ("initial-review", result["initial_review"]), ("result", review),
        ):
            bundle.add(checked(binding), arcname=f"receipts/{name}.json", recursive=False)
        for binding in (result["driver"], plan["driver"], prior["driver"], analysis["driver"], analysis["operator"]):
            f = checked(binding)
            bundle.add(f, arcname="source/" + str(f.relative_to(REPO)), recursive=False)
        initial_code = HERE / "score_nested_clearance48.py"
        assert reference(initial_code)["sha256"] == previous["driver"]["sha256"]
        for f in (initial_code, Path(__file__), REPO / "src/demosaic/mesh_carrier_fit.py",
                  HERE.with_name("local-center-guard-v1") / "center_guard.py"):
            bundle.add(f, arcname="source/" + str(f.relative_to(REPO)), recursive=False)
    write_json(dest / "publication.json", {
        "scope": "Fresh inference-only restoration and null-activation panel. Existing Local 50k and V120 EMA weights.",
        "archive": {"path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "review": review, "weights": result["weights"], "matches": result["matches"],
        "fresh_sources": 32, "noise_draws_per_source": 2, "native_figures_reviewed": 16,
        "parent_inference_seconds": prior["seconds"], "postprocess_and_review_seconds": result["seconds"],
        "results": result["results"], "standing_deltas": {
            r["id"]: {"RMS_DN16": r["RMS_DN16"], "peaks": r["nomination"],
                      "full_query_margin_peaks": r["distant_nomination"]}
            for r in result["standing"]["rows"]
        }, "images": images,
    })


if __name__ == "__main__":
    main()
