"""Publish native same-side phase comparisons and their executed analysis."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
review = root / "review"
report = read_json(review / "result.json")
summary = read_json(review / "summary.json")
audit = read_json(review / "independent-audit.json")
seen = read_json(review / "actual-native-viewing.json")
assert len(report["metrics"]) == 384 and len(summary["groups"]) == 16
assert audit["status"] == "passed" and audit["native_reductions"] == 4800
assert len(seen["boards"]) == 12 and all(v["viewed"] for v in seen["boards"])
images = repo / "docs/images/phase-edge-side-v1"
results = repo / "docs/results/phase-edge-side-v1"
images.mkdir()
results.mkdir()
items = []
for kind, row in [(k, v) for v in report["boards"] for k in ("board", "triplet")] + [
    ("camera", v) for v in report["camera"]
]:
    info = row if kind == "camera" else row[kind]
    source = checked(info["image"])
    dest = images / source.name
    shutil.copyfile(source, dest)
    fingerprint = reference(dest)
    assert fingerprint["sha256"] == info["image"]["sha256"]
    items.append({"id": row["id"], "kind": kind, "published": fingerprint, "native": row})
assert len(items) == 16
for row in report["boards"]:
    if not row["id"].startswith("iso400"):
        continue
    info = row["board"]
    filename = images / (row["id"] + "-validation-triplet.png")
    board = Image.open(checked(info["image"]))
    combined = Image.new("RGB", (512, 192), "#eeeeee")
    labels = ImageDraw.Draw(combined)
    panels, cells = [], []
    for i, original in enumerate((0, 3, 5)):
        p = info["panels"][original]
        x, y, w, h = p["png_xywh"]
        assert (w, h) == (160, 160)
        cell = board.crop((x, y, x + w, y + h))
        dest = 8 + i * 168
        combined.paste(cell, (dest, 24))
        labels.text((dest, 5), p["label"], fill="black")
        panels.append({"label": p["label"], "png_xywh": [dest, 24, w, h]})
        cells.append(cell)
    combined.save(filename)
    new = Image.open(filename)
    for cell, p in zip(cells, panels, strict=True):
        x, y, w, h = p["png_xywh"]
        assert new.crop((x, y, x + w, y + h)).tobytes() == cell.tobytes()
    items.append(
        {
            "id": row["id"],
            "kind": "validation-triplet",
            "published": reference(filename),
            "native": {**row, "validation_triplet_panels": panels},
        }
    )
assert len(items) == 18
write_json(
    images / "manifest.json",
    {
        "images": items,
        "viewing": reference(review / "actual-native-viewing.json"),
        "scope": "Fresh synthetic inputs and both standing GFX families. All crops at native 160×160.",
    },
)
for name in ("summary.json", "independent-audit.json", "actual-native-viewing.json"):
    shutil.copyfile(review / name, results / name)
    assert reference(review / name)["sha256"] == reference(results / name)["sha256"]
bundle = results / "evidence.tar.gz"
members = []
with (
    bundle.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped,
    tarfile.open(fileobj=zipped, mode="w") as tar,
):
    for path in sorted(root.rglob("*")):
        if (
            path.is_file()
            and path.suffix in (".py", ".json", ".log")
            and "__pycache__" not in path.parts
        ):
            member = str(path.relative_to(repo))
            members.append({"member": member, **reference(path)})
            tar.add(path, arcname=member, recursive=False)
with tarfile.open(bundle) as tar:
    for x in members:
        assert hashlib.sha256(tar.extractfile(x["member"]).read()).hexdigest() == x["sha256"]
write_json(
    results / "publication.json",
    {
        "archive": reference(bundle),
        "members": members,
        "all_member_hashes_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "boards_opened": 12,
        "metric_rows": 384,
        "matched_fold_geometry_checks": 1248,
        "scope": "Side-specific validation and waveform fitting versus the original guarded fits on synthetic and GFX fields.",
    },
)
print(len(members), len(items), "publication verified")
