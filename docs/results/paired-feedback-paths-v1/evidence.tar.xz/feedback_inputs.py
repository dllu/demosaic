"""Bind 96 fixed queries with two independent same-target donor observations."""
import os
from dataclasses import replace
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
REPEAT=ROOT.parent/"paired-repeat-stability-v2"
SCENE=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(REPEAT))
from train_repeat import observe, ARGS
from prepare_eval import flat_patch,load_photo,patch
from evaluate_repeat import load_rows,packed_inputs
SEED=1282392462151


def run():
    os.sched_setaffinity(0,[14,15])
    os.nice(13)
    torch.set_num_threads(1)
    earlier=reference(REPEAT/"evaluation-plan.json")
    definition=read_json(checked(earlier))
    all_cases,source_records=load_rows()
    cases=[case for case in all_cases if (case["profile"]["name"],case["coupling"])==("iso6400","independent")]
    assert len(cases)==96
    input_dir=ROOT/"new-observations"
    input_dir.mkdir()
    began=time.monotonic()
    records=[]
    for case in cases:
        info=definition["rows"][case["index"]]
        assert info["source"]["id"]==case["source"]
        data=load_photo(info)
        present=patch(data,info["box"],.22)
        absent=patch(data,info["box"],0.)
        flat=flat_patch(absent)
        profile={k:case["profile"][k] for k in ("shot","read","exposure")}
        camera=replace(sample_scene_recipe(SEED),**(info["camera"]|profile))
        seeding=[scene_seed(SEED,case["index"],f"donor3:{role}") for role in ("pair","present","absent","flat")]
        assert len(set(seeding))==4
        assert set(seeding).isdisjoint(x for r in case["draws"] for x in r["scored_physical_seeds"])
        native={k:v.numpy() for k,v in observe((present,absent,flat),camera,profile,"independent",seeding).items()}
        receipt={k:fingerprint(v) for k,v in native.items()}
        for key in (*ARGS[2:],"target"):
            assert receipt[key]==case["draws"][0]["fingerprints"][key], (case["id"],key)
        assert all(receipt["packed"]!=r["fingerprints"]["packed"] for r in case["draws"])
        artifact=input_dir/(case["id"]+".npz")
        with artifact.open("xb") as file:
            np.savez(file,**native)
        draw={"repeat":3,"file":reference(artifact),"original":None,
              "scored_physical_seeds":seeding,"fingerprints":receipt}
        records.append(case|{"draws":[*case["draws"],draw]})
        if len(records)%16==0:
            print(len(records),round(time.monotonic()-began,1),flush=True)
    write_json(ROOT/"input-plan.json",{
        "driver":reference(__file__),"previous_plan":earlier,"previous_observations":source_records,
        "observations":records,"query_donor_indices":[[0,2],[1,3]],
        "scope":"Two independent query/donor groups per exact ISO6400 independent case. Each role in all four groups is independently drawn, and each group shares identical targets, calibration and native coordinates.",
        "seconds":time.monotonic()-began,
    })


if __name__=="__main__":
    run()
