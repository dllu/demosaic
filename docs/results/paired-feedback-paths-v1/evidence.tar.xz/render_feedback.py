"""Render deployment-compatible single-frame controls on the standing cameras and exact-target crops."""
import os

import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board
from run_feedback import ROOT,REPEAT,SINGLE_FRAME,CANONICAL,ARGS,as_cuda,bind_upstream,corrections,cutoff,head,inputs,packed_inputs,paired_gates,read_parent,value
import render_repeat

LABELS={
    "V120":"V120 EMA","100k":"Parent 100k EMA",CANONICAL:"Paired head",
    SINGLE_FRAME[0]:"Smoothed guide",SINGLE_FRAME[1]:"Smoothed innovation",
    SINGLE_FRAME[2]:"Both smoothed",
}


def single(state,args,parents,thresholds):
    current=torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    gate=paired_gates(*args[:3],*thresholds)[1]
    return parents|corrections(state,current,args,gate)


def photo(out,data,state,thresholds):
    raw=read_json(REPEAT/"evaluation-plan.json")
    _,rows=inputs()
    originals={r["id"]:r for r in rows}
    _,_,cache,_=bind_upstream()
    key=SINGLE_FRAME[1]
    group=[r for r in data["rows"] if r["cohort"]=="fresh32"]
    assert len(group)==32
    def delta(r,metric):
        return value(r["moments"][key],1.)[metric]-value(r["moments"][CANONICAL],1.)[metric]
    ordered=sorted(group,key=lambda r:delta(r,"increment_DN16"))
    show=((ordered[0],0,"Largest fine increment error reduction with the same-frame smoothed innovation"),
          (ordered[-1],0,"Largest fine increment error increase with the same-frame smoothed innovation"),
          (max(group,key=lambda r:delta(r,"flat_DN16")),2,"Largest flat RMS increase with the same-frame smoothed innovation"))
    emitted=[]
    models=("V120","100k",CANONICAL,*SINGLE_FRAME)
    for selected,role,reason in show:
        case=originals[selected["id"]]
        source=raw["rows"][case["index"]]
        physical=packed_inputs(case,0)
        predictions=single(state,as_cuda(physical),read_parent(cache[case["id"]][0]),thresholds)
        fields={k:physical[k][role:role+1] for k in ARGS}
        panes=[noisy_malvar(fields)[0],*[predictions[k][role] for k in models],physical["target"][role]]
        emitted.append(native_board(
            out,f"{case['id']}-r0-role{role}",panes,fields,{
                "source_photo":source["source"],"bbox_native":case["native_box"],"CFA":case["CFA"],
                "profile":case["profile"],"selection":reason,"exact_input":case["draws"][0],
                "composed_checkpoint_plan":data["plan"],
            },
            labels=("Noisy Malvar",*[LABELS[k] for k in models],"Exact GT"),
            triplet_indices=(0,1+models.index(key),len(panes)-1),
            exposure=1/case["profile"]["exposure"],contrast=2,roi=tuple(raw["native_display_ROI_xywh"]),
        ))
    return emitted


@torch.inference_mode()
def render():
    os.sched_setaffinity(0,[16,18])
    os.nice(12)
    torch.set_num_threads(2)
    data=read_json(ROOT/"results.json")
    plan=read_json(checked(data["plan"]))
    common,thresholds=cutoff()
    assert plan["checkpoint"]==common["initial_head"]
    state=head(torch.load(checked(plan["checkpoint"]),map_location="cpu",weights_only=True),"paired")
    directory=ROOT/"native"
    directory.mkdir()
    render_repeat.SHOW=(CANONICAL,*SINGLE_FRAME)
    render_repeat.DISPLAY=LABELS
    render_repeat.predictions=single
    with ieee_fp32():
        camera=render_repeat.show_camera(state,thresholds,directory)
        synthetic=photo(directory,data,state,thresholds)
    write_json(directory/"render.json",{
        "driver":reference(__file__),"standing_renderer":reference(render_repeat.__file__),
        "composed":data["plan"],"standing":camera,"synthetic":synthetic,
        "actual_native_viewing_complete":False,
    })


if __name__=="__main__":
    render()
