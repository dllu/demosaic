"""Compare same-frame directed and uniform Bayer innovation averaging."""
import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from run_feedback import (ROOT,REPEAT,CANONICAL,configure,cutoff,head,inputs,bind_upstream,
                          read_parent,paired_gates,channel_coefficients,as_cuda,packed_inputs,
                          BANDS,measure,value)
from directional_feedback import native,TEMPERATURE
from analyze_feedback import covariance
from review_projected import compare_at_strength
from flat_matched_transfer import match_on

NAME="oriented-innovation"
MATCH=("smooth-innovation","canonical","100k")


@torch.inference_mode()
def run():
    configure()
    same,guard=cutoff()
    prior=read_json(ROOT/"results.json")
    _,cases=inputs()
    _,_,predictions,_=bind_upstream()
    roi=read_json(REPEAT/"evaluation-plan.json")["score_ROI_xywh"]
    state=head(torch.load(checked(same["initial_head"]),map_location="cpu",weights_only=True),"paired")
    produced={}
    with ieee_fp32():
        for case in cases:
            original=[]
            adapted=[]
            for repeat in (0,1):
                data=packed_inputs(case,repeat)
                fields=as_cuda(data)
                parent=read_parent(predictions[case["id"]][repeat],classes=("100k",))["100k"]
                output=native(state,torch.from_numpy(parent).cuda().contiguous(memory_format=torch.channels_last),
                              fields,paired_gates(*fields[:3],*guard)[1])
                original.append(channel_coefficients(parent,data,roi)[1])
                adapted.append(channel_coefficients(output,data,roi)[1])
            target=channel_coefficients(data["target"],data,roi)[1]
            base,contender=np.stack(original),np.stack(adapted)
            produced[case["id"]]=measure(base,contender-base,target,BANDS["fine"])
    fitted=[r|{"moments":r["moments"]|{NAME:produced[r["id"]]}} for r in prior["rows"]]
    fit=[r for r in fitted if r["cohort"]=="original64"]
    verify=[r for r in fitted if r["cohort"]=="fresh32"]
    assert (len(fit),len(verify))==(64,32)
    controls={}
    rng=np.random.default_rng(611988851)
    for condition in MATCH:
        nominal=dict.fromkeys((NAME,condition),1.)
        control={"fresh32_nominal":compare_at_strength(verify,NAME,condition,nominal,rng)}
        gain={key:sum(row["moments"][key]["aligned"][1] for row in fit) for key in nominal}
        lesser=min(gain.values())
        if lesser>0.:
            strengths={k:lesser/v for k,v in gain.items()}
            control["response_match_fresh32"]=compare_at_strength(verify,NAME,condition,strengths,rng)
            control["response_scales"]=strengths
            control["response_match_covariance"]=covariance(verify,NAME,strengths[NAME],condition,strengths[condition],rng)
        budget,scales,_=match_on(fit,NAME,condition)
        if scales:
            control["flat_match"]={"budget_original64":budget,"scales":scales,
                                   "fresh32":compare_at_strength(verify,NAME,condition,scales,rng)}
        controls[condition]=control
    write_json(ROOT/"oriented.json",{
        "driver":reference(__file__),"directional_module":reference(ROOT/"directional_feedback.py"),
        "preceding_results":reference(ROOT/"results.json"),"orientation_temperature":TEMPERATURE,
        "metrics":controls,"moments":produced,"scope":"Single physical inputs. Direction weights use only the frozen parent guide. Calibration on 64, transfer on 32, no inference training.",
    })


if __name__=="__main__":
    run()
