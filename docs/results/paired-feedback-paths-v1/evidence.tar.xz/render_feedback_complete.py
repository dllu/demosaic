"""Add the directional single-frame result to the complete matched native boards."""
import os

import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from directional_feedback import native as oriented
from score_directional import NAME
from run_feedback import ROOT,head,cutoff,paired_gates
import render_feedback
import render_repeat

base_render=render_feedback.single


def single_frame(state,args,parents,thresholds):
    results=base_render(state,args,parents,thresholds)
    current=torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    guard=paired_gates(*args[:3],*thresholds)[1]
    return results|{NAME:oriented(state,current,args,guard)}


@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[16,18])
    os.nice(12)
    torch.set_num_threads(2)
    data=read_json(ROOT/"results.json")
    plan=read_json(checked(data["plan"]))
    required=read_json(ROOT/"oriented.json")
    assert required["preceding_results"]==reference(ROOT/"results.json")
    common,thresholds=cutoff()
    assert plan["checkpoint"]==common["initial_head"]
    state=head(torch.load(checked(plan["checkpoint"]),map_location="cpu",weights_only=True),"paired")
    directory=ROOT/"native-final"
    directory.mkdir()
    render_feedback.SINGLE_FRAME=(*render_feedback.SINGLE_FRAME,NAME)
    render_feedback.LABELS[NAME]="Oriented innovation"
    render_feedback.single=single_frame
    render_repeat.SHOW=(render_feedback.CANONICAL,*render_feedback.SINGLE_FRAME)
    render_repeat.DISPLAY=render_feedback.LABELS
    render_repeat.predictions=single_frame
    with ieee_fp32():
        real=render_repeat.show_camera(state,thresholds,directory)
        synthetic=render_feedback.photo(directory,data,state,thresholds)
    write_json(directory/"render.json",{
        "driver":reference(__file__),"front_end":reference(render_feedback.__file__),
        "raw_directions":reference(ROOT/"directional_feedback.py"),
        "standing_renderer":reference(render_repeat.__file__),"plan":data["plan"],
        "oriented_receipt":reference(ROOT/"oriented.json"),
        "standing":real,"synthetic":synthetic,"actual_native_viewing_complete":False,
    })


if __name__=="__main__":
    run()
