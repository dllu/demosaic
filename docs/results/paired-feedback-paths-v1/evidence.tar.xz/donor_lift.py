"""Check the covariance floor when the correction comes entirely from a separate capture."""
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from run_feedback import (ROOT,REPEAT,CANONICAL,configure,cutoff,head,inputs,bind_upstream,
                          read_parent,paired_gates,channel_coefficients,as_cuda,packed_inputs,
                          BANDS,measure)
from review_projected import compare_at_strength
from analyze_feedback import covariance

LABEL="independent-capture-lift"


@torch.inference_mode()
def run():
    configure()
    common,limits=cutoff()
    base_data=read_json(ROOT/"results.json")
    meta=read_json(checked(base_data["plan"]))
    _,cases=inputs()
    _,_,parents,_=bind_upstream()
    source_meta=read_json(REPEAT/"evaluation-plan.json")
    roi=source_meta["score_ROI_xywh"]
    obs=read_json(checked(meta["new_donor_parents"]))
    injected={row["id"]:row for row in obs["predictions"]}
    state=head(torch.load(checked(common["initial_head"]),map_location="cpu",weights_only=True),"paired")
    replay={}
    with ieee_fp32():
        for case in cases:
            parent_coeff=[]
            full_coeff=[]
            for idx,donor in ((0,2),(1,3)):
                q=read_parent(parents[case["id"]][idx],classes=("100k",))["100k"]
                # All restoration inputs and the support gate originate in the donor exposure.
                donor_data=packed_inputs(case,donor)
                fields=as_cuda(donor_data)
                if donor==2:
                    alternate=read_parent(parents[case["id"]][donor],classes=("100k",))["100k"]
                else:
                    alternate=np.load(checked(injected[case["id"]]["saved"]),allow_pickle=False)
                camera=torch.from_numpy(alternate).cuda().contiguous(memory_format=torch.channels_last)
                guard=paired_gates(*fields[:3],*limits)[1]
                delta=state.luminance_delta(camera,*fields)*guard
                wb,matrix=fields[-2:]
                line=torch.linalg.solve(matrix,torch.ones_like(wb).unsqueeze(-1)).squeeze(-1)/wb
                result=q+(delta*line[:,:,None,None]).cpu().numpy()
                parent_coeff.append(channel_coefficients(q,donor_data,roi)[1])
                full_coeff.append(channel_coefficients(result,donor_data,roi)[1])
            truth=channel_coefficients(donor_data["target"],donor_data,roi)[1]
            original,corrected=np.stack(parent_coeff),np.stack(full_coeff)
            replay[case["id"]]=measure(original,corrected-original,truth,BANDS["fine"])
    exact=[r|{"moments":r["moments"]|{LABEL:replay[r["id"]]}} for r in base_data["rows"]]
    fit=[r for r in exact if r["cohort"]=="original64"]
    verify=[r for r in exact if r["cohort"]=="fresh32"]
    random=np.random.default_rng(239936146)
    scoped={"nominal_fresh32_vs_parent":compare_at_strength(verify,LABEL,"100k", {LABEL:1.,"100k":1.},random),
            "nominal_covariance_fresh32":covariance(verify,LABEL,1.,"100k",1.,random)}
    gains={key:sum(r["moments"][key]["aligned"][1] for r in fit) for key in (LABEL,CANONICAL)}
    floor=min(gains.values())
    if floor>0:
        scales={k:floor/gain for k,gain in gains.items()}
        scoped|={"matched_scales":scales,"response_match_fresh32":compare_at_strength(verify,LABEL,CANONICAL,scales,random)}
    write_json(ROOT/"independent-capture-lift.json",{
        "driver":reference(__file__),"source":reference(ROOT/"results.json"),
        "moments":replay,"results":scoped,
        "scope":"Mechanism control requiring a second independent simulated exposure for every query. Both the correction itself and its guard use only the donor exposure. The output parent comes from the query.",
    })


if __name__=="__main__":
    run()
