"""Compare response, false texture and parent-error covariance at fixed strengths."""
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from run_feedback import ROOT,CANONICAL,DONOR,SINGLE_FRAME,value
from review_projected import compare_at_strength
from flat_matched_transfer import match_on
from variance_budget import split, LABELS


def covariance(rows,arm,scale,other,other_scale,rng):
    diff=split(rows,arm,scale)-split(rows,other,other_scale)
    intervals=np.quantile(diff[rng.integers(0,len(rows),(4000,len(rows)))].mean(axis=1),[.025,.975],axis=0)
    mean=diff.mean(axis=0)
    return {k:[float(mean[i]),float(intervals[0,i]),float(intervals[1,i])] for i,k in enumerate(LABELS)}


def run():
    bind=reference(ROOT/"results.json")
    results=read_json(checked(bind))
    spec=read_json(checked(results["plan"]))
    chosen=results["rows"]
    train=[r for r in chosen if r["cohort"]=="original64"]
    reserved=[r for r in chosen if r["cohort"]=="fresh32"]
    assert (len(train),len(reserved))==(64,32)
    main={}
    rng=np.random.default_rng(131505817233)
    for policy in [CANONICAL,*DONOR,*SINGLE_FRAME,"V120"]:
        ordinary=dict.fromkeys((policy,"100k"),1.)
        numbers={
            "nominal_fresh32_vs_parent":compare_at_strength(reserved,policy,"100k",ordinary,rng),
            "nominal_original64_vs_parent":compare_at_strength(train,policy,"100k",ordinary,rng),
            "nominal_fresh32_covariance_vs_parent":covariance(reserved,policy,1.,"100k",1.,rng),
        }
        if policy not in (CANONICAL,"V120"):
            nom=dict.fromkeys((policy,CANONICAL),1.)
            gains={label:sum(r["moments"][label]["aligned"][1] for r in train) for label in nom}
            floor=min(gains.values())
            numbers["nominal_fresh32_vs_canonical"]=compare_at_strength(reserved,policy,CANONICAL,nom,rng)
            if floor>0:
                scale={label:floor/gain for label,gain in gains.items()}
                fit=compare_at_strength(train,policy,CANONICAL,scale,rng)
                assert abs(fit["response_percentage_points"][0])<1e-11
                numbers["response_match"]={
                    "scales":scale,"on_calibration64":fit,
                    "on_independent_fresh32":compare_at_strength(reserved,policy,CANONICAL,scale,rng),
                    "variance_terms_vs_canonical":covariance(reserved,policy,scale[policy],CANONICAL,scale[CANONICAL],rng),
                }
            budget,scales,nominal=match_on(train,policy,CANONICAL)
            numbers["flat_match"]={"budget_DN16":budget,"scales":scales,"calibration_nominal_flat_DN16":nominal}
            if scales:
                numbers["flat_match"]["on_independent_fresh32"]=compare_at_strength(reserved,policy,CANONICAL,scales,rng)
        main[policy]=numbers
    write_json(ROOT/"summary.json",{
        "results":bind,"driver":reference(__file__),"composed":spec,"methods":main,
        "calibration":"Response and flat matches fit only on the 64 original photos. All differences are measured with fixed scales on the additional 32 photos.",
        "variance":"Between-independent-query/donor-pair variance estimated from 2 disjoint physical repeats. Error changes attributed to variance of the correction and twice its covariance with parent error.",
    })


if __name__=="__main__":
    run()
