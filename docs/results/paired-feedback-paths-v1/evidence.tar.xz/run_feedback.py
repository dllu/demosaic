"""Run the fixed query-parent route interventions and score two disjoint redraws."""
import argparse
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import psutil
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from feedback_inputs import ROOT,REPEAT
from feedback_heads import CANONICAL,DONOR,SINGLE_FRAME,corrections
from evaluate_repeat import (as_cuda,base_forward,bind_upstream,channel_coefficients,head,packed_inputs,read_parent)
from evaluate import setup_models
from local_guard import paired_gates
from measure import BANDS
from train_repeat import ARGS

SHAPE=ROOT.parent/"paired-shape-stability-v1"
sys.path.insert(0,str(SHAPE))
from strength_moments import measure,value


def cutoff():
    common=read_json(REPEAT/"plan.json")
    return common,(read_json(checked(common["guard"]))["threshold"],
                   read_json(checked(common["guard_long"]))["threshold_0_to_1"][0])


def inputs():
    receipt=reference(ROOT/"input-plan.json")
    ready=read_json(checked(receipt))
    assert ready["query_donor_indices"]==[[0,2],[1,3]]
    return receipt,ready["observations"]


def configure():
    os.sched_setaffinity(0,[16,18])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,8*2**30/torch.cuda.get_device_properties(0).total_memory))


@torch.inference_mode()
def prepare_parents():
    configure()
    plan=read_json(REPEAT/"plan.json")
    detail,records=inputs()
    out=ROOT/"new-parent"
    out.mkdir()
    write_json(out/"launch.json",{"pid":os.getpid(),"created":psutil.Process().create_time()})
    models=setup_models(plan)
    parent=models["Corpus 100k"]
    began=time.monotonic()
    saved=[]
    with ieee_fp32():
        for case in records:
            native=as_cuda(packed_inputs(case,3))
            restored=base_forward(parent,native,case["profile"]).cpu().numpy()
            path=out/(case["id"]+".npy")
            with path.open("xb") as f:
                np.save(f,restored,allow_pickle=False)
            saved.append({"id":case["id"],"physical":case["draws"][3]["file"],"saved":reference(path)})
            if len(saved)%16==0:
                print("donor parents",len(saved),round(time.monotonic()-began,1),flush=True)
    write_json(out/"complete.json",{
        "source":detail,"driver":reference(__file__),"parent":plan["models"]["Corpus 100k"],
        "predictions":saved,"precision":"CUDA IEEE FP32","seconds":time.monotonic()-began,
    })


def arrays_for(case, stored, latest, state, thresholds, roi):
    measurements=[]
    for query,donor in ((0,2),(1,3)):
        native=packed_inputs(case,query)
        args=as_cuda(native)
        query_outputs=read_parent(stored[case["id"]][query])
        if donor==2:
            independent=read_parent(stored[case["id"]][donor],classes=("100k",))["100k"]
        else:
            assert latest[case["id"]]["physical"]==case["draws"][3]["file"]
            independent=np.load(checked(latest[case["id"]]["saved"]),allow_pickle=False)
        def gpu(array):
            return torch.from_numpy(array).cuda().contiguous(memory_format=torch.channels_last)
        guard=paired_gates(*args[:3],*thresholds)[1]
        variants=corrections(state,gpu(query_outputs["100k"]),args,guard,gpu(independent))
        all_frames=query_outputs|variants
        measurements.append({tag:channel_coefficients(array,native,roi)[1] for tag,array in all_frames.items()})
    target=channel_coefficients(native["target"],native,roi)[1]
    return measurements,target


@torch.inference_mode()
def run():
    configure()
    common,thresholds=cutoff()
    observation_plan,cases=inputs()
    old_pack,old_plan,stored,base_cases=bind_upstream()
    assert {row["id"] for row in cases}.issubset(stored)
    old_case={row["id"]:row for row in base_cases}
    assert all(row["draws"][:3]==old_case[row["id"]]["draws"] for row in cases)
    new_ref=reference(ROOT/"new-parent/complete.json")
    ready=read_json(checked(new_ref))
    assert ready["source"]==observation_plan and ready["parent"]==old_plan["models"]["100k"]
    latest={r["id"]:r for r in ready["predictions"]}
    state=head(torch.load(checked(common["initial_head"]),map_location="cpu",weights_only=True),"paired")
    meta=ROOT/"plan.json"
    write_json(meta,{
        "driver":reference(__file__),"head_interventions":reference(ROOT/"feedback_heads.py"),
        "source":observation_plan,"prior_parent_predictions":reference(old_pack),"new_donor_parents":new_ref,
        "strength_math":reference(SHAPE/"strength_moments.py"),
        "checkpoint":common["initial_head"],"parent":old_plan["models"]["100k"],"V120":old_plan["models"]["V120"],
        "guard":common["guard"],"guard_long":common["guard_long"],
        "policies":[CANONICAL,*DONOR,*SINGLE_FRAME],"fixed_queries":[[0,2],[1,3]],
        "precision":"CUDA IEEE FP32. Exact native placements. Alignment and variance measured on two independent query/donor pairs.",
    })
    start=time.monotonic()
    rows=[]
    exact=read_json(REPEAT/"evaluation-plan.json")
    roi=exact["score_ROI_xywh"]
    with ieee_fp32():
        for case in cases:
            frames,target=arrays_for(case,stored,latest,state,thresholds,roi)
            camera=np.stack([view["100k"] for view in frames])
            moments={}
            for tag in frames[0]:
                variant=np.stack([view[tag] for view in frames])
                moments[tag]=measure(camera,variant-camera,target,BANDS["fine"])
            rows.append({"id":case["id"],"source":case["source"],"index":case["index"],"cohort":case["cohort"],
                         "CFA":case["CFA"],"moments":moments})
            if len(rows)%8==0:
                print("scored",len(rows),round(time.monotonic()-start,1),flush=True)
    assert len(rows)==96
    write_json(ROOT/"results.json",{
        "plan":reference(meta),"rows":rows,"scoring_seconds":time.monotonic()-start,
        "scope":"Two same-law ISO6400 independent draws for each of 96 held-out photos. Cross-draw interventions require an additional simulated exposure. Fixed single-frame smoothing uses only the query.",
    })


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("stage",choices=("parents","score"))
    prepare_parents() if cli.parse_args().stage=="parents" else run()
