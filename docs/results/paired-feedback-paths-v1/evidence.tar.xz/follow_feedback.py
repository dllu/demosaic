"""Summarize and render the fixed study after its producer reaches coverage."""
import argparse
import os
import subprocess
import sys

import psutil

from demosaic.experiments.artifacts import reference,write_json
from run_feedback import ROOT
from follow import wait_until

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid",type=int)
    target=parser.parse_args().pid
    contender={"pid":target,"created":psutil.Process(target).create_time()}
    write_json(ROOT/"follow-launch.json",{
         "driver":reference(__file__),"producer":contender,
         "pid":os.getpid(),"created":psutil.Process().create_time(),
    })
    observed=wait_until(ROOT/"results.json",contender)
    subprocess.run([sys.executable,str(ROOT/"analyze_feedback.py")],check=True)
    subprocess.run([sys.executable,str(ROOT/"render_feedback.py")],check=True)
    write_json(ROOT/"follow-complete.json",{
        "observed":observed,"summary":reference(ROOT/"summary.json"),
        "render":reference(ROOT/"native/render.json"),"actual_native_viewing_complete":False,
    })
