"""Compare response-calibrated full-sampling averages against the full-input parent."""
import sys
import time

import numpy as np
import torch

from fission import (ROOT, QUERY, applied, coefficients, fixture, ieee_fp32, measure, panel, pattern,
                     prepare, reference, read_json, checked, split, stats, views, write_json)

NAMES = ('parent','double_prior','pair','repeat','half_mix')
START = 1


def extra_prior(model, raw, colors, wb, matrix, law):
    n = len(raw)
    inputs = [torch.as_tensor(np.broadcast_to(v,(n,*v.shape)).copy(),device='cuda')
              for v in (colors,wb,matrix)]
    v = torch.as_tensor(raw,device='cuda').contiguous(memory_format=torch.channels_last)
    model.set_noise(2*law['shot'],2*law['read'])
    variance = v.clamp_min(0)*(2*law['shot'])+2*law['read']
    with ieee_fp32():
        rgb = model(v,variance,*inputs).float().cpu().numpy()
    assert np.isfinite(rgb).all()
    return rgb


def shape_images(model, case, data, parent):
    camera = [data[k] for k in ('colors','wb','matrix')]
    noise = case['profile']
    side, predicted, sigma, meta = views(model,data['packed'],*camera,noise,case['id'])
    original = extra_prior(model,data['packed'],*camera,noise)
    first = predicted[0].mean(0)
    repeat = predicted.mean((0,1))
    half = (repeat+parent)*.5
    return meta, {'parent':parent,'double_prior':original,'pair':first,'repeat':repeat,'half_mix':half}


def lift(base,wb,matrix,roi=QUERY):
    neutral = np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    neutral /= neutral[1]
    pieces = [applied(pattern(rgb[1],roi),rgb,neutral,roi)-rgb for rgb in base]
    return np.stack(pieces)


def replay(raw, iso):
    p, results, network = panel()
    settings = read_json(checked(network['panel']))
    model = prepare(network['models']['100k'])
    previous = read_json(checked(raw))
    assert previous['panel']==p and previous['checkpoint']==network['models']['100k']
    lookup = {row['source']:row for row in previous['rows']}
    storage = []
    start = time.monotonic()
    for item in results['source_metrics']:
        if (item['profile'],item['draw']) != (iso,'independent'):
            continue
        _, case, data, parent = fixture(item)
        trace, previews = shape_images(model,case,data,parent)
        assert trace == lookup[item['source']]['paired_forwards']
        assert lookup[item['source']]['input']==case['input']
        met = {key:np.broadcast_to(data[key][None],(len(parent),*data[key].shape)) for key in ('wb','matrix')}
        met['exposure']=case['profile']['exposure']
        roi = settings['score_ROI_xywh']
        truth = coefficients(data['target'],met,roi)
        measurements = {}
        for name, rgb in previews.items():
            before = coefficients(rgb,met,roi)
            delta = coefficients(lift(rgb,data['wb'],data['matrix']),met,roi)
            measurements[name]={band:stats(truth,before,delta,mask) for band,mask in measure.BANDS.items()}
        assert measurements['parent']['fine']['response'][0] == lookup[item['source']]['stats']['parent']['fine']['response'][0]
        storage.append({'source':item['source'],'profile':iso,'case':case['case'],'input':case['input'],
                        'prediction_receipt':item['prediction_receipt'],'stats':measurements})
        if len(storage)%8==0:
            print(iso,len(storage),round(time.monotonic()-start,1),flush=True)
    assert len(storage)==64
    receipt = {'driver':reference(__file__),'checkpoint':network['models']['100k'],'configuration':network['panel'],
               'paired_replay':raw,'seconds':time.monotonic()-start,'rows':storage}
    write_json(ROOT/f'compensated-{iso}.json',receipt)


def calibrated(rows,band,cohort):
    cal = [r['stats'] for r in rows if r['source'] in cohort]
    assert len(cal)==16
    ref = sum(r['parent'][band]['response'][0] for r in cal)
    return {k:float((ref-sum(r[k][band]['response'][0] for r in cal))/
                    sum(r[k][band]['response'][1] for r in cal)) for k in NAMES}


def values(rows,band,gains,ids):
    numbers={}
    for k in NAMES:
        chosen = [r['stats'][k][band] for r in rows]
        r = np.asarray([m['response'] for m in chosen])
        target = np.asarray([m['truth'] for m in chosen])
        s = gains[k]
        r = r[:,0]+s*r[:,1]
        estimates = {'response_pp':100*r[ids].sum(1)/target[ids].sum(1)}
        for field in ('increment','present','quiet'):
            m = np.asarray([m[field] for m in chosen])
            mse = np.maximum(0.,m[:,0]+2*s*m[:,1]+s*s*m[:,2])
            estimates[field+'_RMS_DN16'] = np.sqrt(mse[ids].mean(1))
        numbers[k]=estimates
    return numbers


def summarize():
    results = {}
    checkpoint = None
    draws = np.random.default_rng(2173038)
    receipts = {}
    optics = {}
    for iso in ('iso6400','iso400'):
        receipt = reference(ROOT/f'compensated-{iso}.json')
        pack = read_json(checked(receipt))
        assert checkpoint is None or checkpoint == pack['checkpoint']
        checkpoint = pack['checkpoint']
        receipts[iso]=receipt
        cohort = split(pack['rows'])
        gains = calibrated(pack['rows'],'fine',set(cohort['calibration']))
        assert gains['parent']==0. and all(0<=v<=2 for v in gains.values())
        for group,source in cohort.items():
            rows = [row for row in pack['rows'] if row['source'] in set(source)]
            assert len(rows)==len(source)
            n = len(rows)
            reps = np.vstack((np.arange(n),draws.integers(n,size=(10000,n))))
            fit = {}
            for band in measure.BANDS:
                numbers = values(rows,band,gains,reps)
                center = {k:{f:float(a[0]) for f,a in v.items()} for k,v in numbers.items()}
                gaps = {}
                for k,v in numbers.items():
                    delta = {f:a-numbers['parent'][f] for f,a in v.items()}
                    gaps[k]={f:dict(value=float(a[0]),interval=np.quantile(a[1:],(.025,.975)).tolist()) for f,a in delta.items()}
                fit[band] = {'mean':center,'change':gaps}
            results[f'{iso}/{group}']={'metrics':fit,'gains':gains}
        optics[iso]=cohort
        print(iso,gains,results[f'{iso}/test']['metrics']['fine']['mean'],flush=True)
    record={'driver':reference(__file__),'checkpoint':checkpoint,'receipts':receipts,
            'scope':'Each arm matches fine response of the full-input EMA on 16 calibration photos per ISO. No evaluation targets used at application.',
            'source_splits':optics,'results':results}
    write_json(ROOT/'compensated.json',record)


if __name__=='__main__':
    if sys.argv[1]=='summary':
        summarize()
    else:
        with torch.inference_mode():
            replay(reference(ROOT/f'{sys.argv[1]}.json'),sys.argv[1])
