"""Check full-lattice restoration proposals on complementary noisy views."""
from functools import lru_cache
import hashlib
from pathlib import Path
import sys
import time

import numpy as np
import torch
from scipy.ndimage import convolve

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
COVARIANCE = ROOT.with_name('scene-raw-covariance-v1')
SCRIPT_ROOT = Path('scripts').resolve()
sys.path.extend((str(COVARIANCE), str(SCRIPT_ROOT)))
from covariance import bank_basis, lookup, QUERY, SIZE, STRIDE
from evaluate import coefficients, fixture, measure, split, stats

MONITOR = ROOT.with_name('scene-full-epoch-v1') / 'review-full-040000/evaluation/results.json'
FILTER_1D = np.array([1, 4, 6, 4, 1], dtype=np.float32)
FILTER = FILTER_1D[:, None] * FILTER_1D[None]
FILTER[2,2] = 0
FILTER /= FILTER.sum()
THRESHOLD = 1.5
COUNT = 2
ARMS = ('parent','pair_average','pair_same','pair_opposite','repeat_average','same','opposite',
        'signed_opposite','opposite_first','dither_extrapolation')


def seed_for(key, draw):
    return int.from_bytes(hashlib.sha256(f'202611190901/{key}/{draw}'.encode()).digest()[:8], 'little')


def marginal(raw, noise):
    mid = convolve(raw, FILTER.reshape((1,)*(raw.ndim-2)+(5,5)), mode='reflect')
    return noise['shot'] * mid.clip(0,1) + noise['read']


def split_views(raw, variance, seed):
    gauss = np.random.default_rng(seed).standard_normal(raw.shape, dtype=np.float32)
    auxiliary = np.sqrt(variance) * gauss
    return raw + auxiliary, raw - auxiliary


@torch.inference_mode()
def prepare(binding):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(min(1., 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    model, checkpoint = load_checkpoint(checked(binding), 'cuda', tiled_inference=True)
    assert checkpoint['step'] == 100000 and checkpoint['loaded_sha256'] == binding['sha256'] and 'ema' in checkpoint
    return model.eval()


@torch.inference_mode()
def views(model, raw, colors, wb, matrix, noise, key):
    variance = marginal(raw, noise)
    model.set_noise(2*noise['shot'], 2*noise['read'])
    count = len(raw)
    camera = [torch.as_tensor(np.broadcast_to(v, (count, *v.shape)).copy(),device='cuda')
              for v in (colors,wb,matrix)]
    proof = []
    inputs = []
    guides = []
    for i in range(COUNT):
        seed = seed_for(key, i)
        pair = split_views(raw, variance, seed)
        outputs = []
        for side in pair:
            v = torch.as_tensor(side,device='cuda').contiguous(memory_format=torch.channels_last)
            uncertainty = (v.clamp_min(0) * (2*noise['shot']) + 2*noise['read'])
            with ieee_fp32():
                result = model(v, uncertainty, *camera).float().cpu().numpy()
            assert result.shape == (count,3,raw.shape[-2]*2,raw.shape[-1]*2) and np.isfinite(result).all()
            outputs.append(result)
        guides.append(outputs)
        inputs.append(pair)
        proof.append({'seed':seed,'noisy_inputs':[fingerprint(v) for v in pair],
                      'model_outputs':[fingerprint(v) for v in outputs]})
    return np.asarray(inputs), np.asarray(guides), variance, proof


@lru_cache(maxsize=4)
def projector(offsets):
    design, start, _ = bank_basis()
    samples = np.concatenate([design[y::2,x::2].reshape(-1,design.shape[-1]) for x,y in offsets])
    normal_inv = np.linalg.inv(samples.T @ samples)
    return samples @ normal_inv[:,start:], np.linalg.inv(normal_inv[start:,start:])


def green_wall(raw, cfa, roi):
    values, offsets = lookup(raw,cfa,roi)
    return np.concatenate(values,axis=1), tuple(offsets)


def pattern(green, roi):
    x,y,w,h = roi
    windows = np.lib.stride_tricks.sliding_window_view(green[y:y+h,x:x+w],(SIZE,SIZE))
    fields = windows[::STRIDE,::STRIDE].reshape(-1,SIZE**2).astype(float)
    design, start, _ = bank_basis()
    basis = design[...,start:].reshape(SIZE**2,-1)
    return (fields-fields.mean(1,keepdims=True)) @ basis / SIZE**2


def delivery(shape, baseline, observation, precision, variance, signed=False):
    direction = shape @ precision
    power = np.maximum(np.sum(shape*direction,axis=1),1e-20)
    observed_gain = np.sum((observation-baseline)*direction,axis=1)/power
    threshold = THRESHOLD*np.sqrt(variance/power)
    residual = np.sign(observed_gain)*np.maximum(0.,np.abs(observed_gain)-threshold)
    return shape*np.clip(residual,-.5 if signed else 0.,.75)[:,None]


@lru_cache(maxsize=1)
def blending():
    taper = np.minimum(1., np.minimum(np.arange(160)+.5,np.arange(160)[::-1]+.5)/12)
    taper = taper[:,None]*taper[None,:]
    line = np.hanning(SIZE).clip(min=.02)
    blend = line[:,None]*line[None,:]
    positions = [(j,i) for j in range(0,160-SIZE+1,STRIDE) for i in range(0,160-SIZE+1,STRIDE)]
    mass = np.zeros((160,160),dtype=float)
    for top,left in positions:
        mass[top:top+SIZE,left:left+SIZE] += blend
    return positions,taper,blend,mass


def applied(delta, base, neutral, roi):
    x,y,w,h = roi
    assert (w,h) == (160,160)
    design, start, _ = bank_basis()
    basis = design[...,start:].reshape(SIZE**2,-1)
    positions, taper, blend, mass = blending()
    fields = (delta @ basis.T).reshape(-1,SIZE,SIZE)
    value = np.zeros((h,w),dtype=float)
    for (top,left),window in zip(positions,fields,strict=True):
        value[top:top+SIZE,left:left+SIZE] += blend*window
    value /= mass
    value = (value-np.sum(value*taper)/np.sum(taper))*taper
    combined = base.copy()
    combined[:,y:y+h,x:x+w] += (neutral[:,None,None]*value).astype(np.float32)
    return combined


def compose(parent, synthetic, neural, amplitude, cfa, wb, matrix, roi):
    var, offsets = green_wall(amplitude,cfa,roi)
    fit, precision = projector(offsets)
    double_variance = np.maximum(1e-20,2.*var.mean(1))
    full_pattern = pattern(parent[1],roi)
    guides = [[pattern(frame[1],roi) for frame in pair] for pair in neural]
    tests = [[green_wall(frame,cfa,roi)[0] for frame in pair] for pair in synthetic]
    tests = [[(field-field.mean(1,keepdims=True)) @ fit for field in pair] for pair in tests]
    exact_halves = {
        'pair_same':[(a,i,i,False) for a in (0,) for i in (0,1)],
        'pair_opposite':[(a,i,1-i,False) for a in (0,) for i in (0,1)],
        'same':[(a,i,i,False) for a in range(COUNT) for i in (0,1)],
        'opposite':[(a,i,1-i,False) for a in range(COUNT) for i in (0,1)],
        'signed_opposite':[(a,i,1-i,True) for a in range(COUNT) for i in (0,1)],
        'opposite_first':[(0,i,1-i,False) for i in (0,1)],
    }
    first_average = neural[0].mean(0)
    average = neural.mean((0,1))
    neutral = np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    neutral /= neutral[1]
    output = {'parent':parent,'pair_average':first_average,'repeat_average':average}
    for arm, trials in exact_halves.items():
        pair_level = arm.startswith('pair_')
        deltas = []
        for a,i,j,signed in trials:
            shape = guides[a][i]
            baseline = shape if pair_level else full_pattern
            deltas.append(delivery(shape,baseline,tests[a][j],precision,double_variance,signed=signed))
        output[arm] = applied(np.mean(deltas,axis=0), first_average if pair_level else parent, neutral,roi)
    output['dither_extrapolation'] = applied(full_pattern-pattern(average[1],roi),parent,neutral,roi)
    return output


def panel():
    binding = reference(MONITOR)
    results = read_json(checked(binding))
    spec = read_json(checked(results['plan']))
    return binding,results,spec


def evaluate_case(model,item,settings):
    p, case, data, parent = fixture(item)
    key = case['id']
    shot = case['profile']
    colors, wb, matrix = (data[k] for k in ('colors','wb','matrix'))
    side, guide, variance, proof = views(model,data['packed'],colors,wb,matrix,shot,key)
    roi = QUERY
    frames = [compose(parent[i],side[:,:,i],guide[:,:,i],variance[i],colors,wb,matrix,roi)
              for i in range(len(parent))]
    output = {name:np.stack([a[name] for a in frames]) for name in ARMS}
    return case,data,parent,output,proof


def stats_for_case(item, data, parent, output, case, settings):
    supervised = {key:np.broadcast_to(data[key][None],(len(parent),*data[key].shape)) for key in ('wb','matrix')}
    supervised['exposure'] = case['profile']['exposure']
    assert measure.parts(supervised,parent,data['target'],settings) == item['metrics']['100k']
    roi = settings['score_ROI_xywh']
    truth = coefficients(data['target'],supervised,roi)
    before = coefficients(parent,supervised,roi)
    replay = {}
    for arm,actual in output.items():
        after = coefficients(actual-parent,supervised,roi)
        replay[arm] = {k:stats(truth,before,after,mask) for k,mask in measure.BANDS.items()}
    return replay


def run(iso):
    t0 = time.monotonic()
    panel_ref, results, spec = panel()
    model = prepare(spec['models']['100k'])
    settings = read_json(checked(spec['panel']))
    audit = []
    for item in results['source_metrics']:
        if (item['profile'],item['draw']) != (iso,'independent'):
            continue
        case,data,parent,output,proof = evaluate_case(model,item,settings)
        measurement = stats_for_case(item,data,parent,output,case,settings)
        audit.append({'case':case['case'],'source':item['source'],'profile':iso,
                      'prediction_receipt':item['prediction_receipt'],'input':case['input'],'stats':measurement,
                      'paired_forwards':proof})
        if len(audit) % 4 == 0:
            print(iso,len(audit),round(time.monotonic()-t0,2),flush=True)
    assert len(audit) == 64
    write_json(ROOT/f'{iso}.json',{'driver':reference(__file__),'checkpoint':spec['models']['100k'],
        'panel':panel_ref,'settings':spec['panel'],'rows':audit,'seconds':time.monotonic()-t0,
        'configuration':{'auxiliary_filter':FILTER.tolist(),'pairs':COUNT,'threshold':THRESHOLD,
                         'neural_shot_read_factor':2,'IEEE_FP32':True,
                         'paired_variant':'Antithetic auxiliary Gaussian with measured local packed variance.'}})


if __name__=='__main__':
    run(sys.argv[1])
