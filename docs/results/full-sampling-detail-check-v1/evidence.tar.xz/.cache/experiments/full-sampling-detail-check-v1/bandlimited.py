"""Reinsert guide detail over the measured band while keeping parent color and coarse structure."""
from functools import lru_cache
import sys
import time

import numpy as np
from scipy.fft import irfft2, rfft2
import torch

from compensate import (NAMES, calibrated, coefficients, fixture, measure, panel, prepare, read_json,
                        checked, reference, ROOT, shape_images, split, stats, values, write_json)
from fission import QUERY

MARGIN = 24


def raised(x,low,high):
    coordinate = np.clip((x-low)/(high-low),0,1)
    return .5-.5*np.cos(np.pi*coordinate)


@lru_cache(maxsize=6)
def transfer(height,width):
    y = np.fft.fftfreq(height)[:,None]
    x = np.fft.rfftfreq(width)[None,:]
    f = np.hypot(y,x)
    return (raised(f,.115,.151)*(1-raised(f,.299,.365))).astype(np.float32)


def chroma_neutral(wb,matrix):
    direction = np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    return (direction/direction[1]).astype(np.float32)


def local_band(green,roi):
    x,y,w,h = roi
    padded = np.pad(green, ((MARGIN,MARGIN),(MARGIN,MARGIN)),mode='reflect')
    in_box=padded[y:y+h+2*MARGIN,x:x+w+2*MARGIN]
    assert in_box.shape == (h+2*MARGIN,w+2*MARGIN)
    response=transfer(*in_box.shape)
    centered=irfft2(rfft2(in_box)*response,s=in_box.shape)[MARGIN:MARGIN+h,MARGIN:MARGIN+w]
    wy=np.minimum(1,np.minimum(np.arange(h)+.5,np.arange(h)[::-1]+.5)/12)
    wx=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    window = wy[:,None]*wx[None,:]
    centered=(centered-np.sum(centered*window)/np.sum(window))*window
    return centered.astype(np.float32)


def compose(parent, guide, wb, matrix, roi):
    x,y,w,h=roi
    neutral = chroma_neutral(wb,matrix)
    replace = local_band(guide[1]-parent[1],roi) * neutral[:,None,None]
    adjust = local_band(guide[1],roi) * neutral[:,None,None]
    prior = parent.copy()
    prior[:,y:y+h,x:x+w] += replace
    addition = np.zeros_like(prior)
    addition[:,y:y+h,x:x+w] = adjust
    return prior,addition


@torch.inference_mode()
def replay(iso):
    plan, results, network = panel()
    config = read_json(checked(network['panel']))
    model = prepare(network['models']['100k'])
    before = reference(ROOT/f'{iso}.json')
    prev = read_json(checked(before))
    prior = {r['source']:r for r in prev['rows']}
    start = time.monotonic()
    rows = []
    for item in results['source_metrics']:
        if (item['profile'],item['draw'])!=(iso,'independent'):
            continue
        _,case,data,parent = fixture(item)
        trace,guides = shape_images(model,case,data,parent)
        assert trace == prior[item['source']]['paired_forwards']
        met = {key:np.broadcast_to(data[key][None],(len(parent),*data[key].shape)) for key in ('wb','matrix')}
        met['exposure']=case['profile']['exposure']
        roi = config['score_ROI_xywh']
        truth = coefficients(data['target'],met,roi)
        measurements = {}
        for name, rgb in guides.items():
            view, boost = map(np.stack,zip(*(compose(p,g,data['wb'],data['matrix'],QUERY)
                              for p,g in zip(parent,rgb,strict=True)),strict=True))
            base = coefficients(view,met,roi)
            delta = coefficients(boost,met,roi)
            measurements[name] = {band:stats(truth,base,delta,mask) for band,mask in measure.BANDS.items()}
        assert measurements['parent']['fine']['response'][0] == prior[item['source']]['stats']['parent']['fine']['response'][0]
        rows.append({'case':case['case'],'profile':iso,'source':item['source'],'input':case['input'],
                      'prediction_receipt':item['prediction_receipt'],'stats':measurements})
        if len(rows)%8==0:
            print(iso,len(rows),round(time.monotonic()-start,1),flush=True)
    assert len(rows)==64
    write_json(ROOT/f'bandlimited-{iso}.json',{'driver':reference(__file__),'parent':network['models']['100k'],
        'previous':before,'panel':plan,'rows':rows,'seconds':time.monotonic()-start,
        'policy':{'transition_cycles_per_native_px':[[.115,.151],[.299,.365]],
                  'margin':MARGIN,'correction_roi':QUERY,'neutral_color_preserved':True}})


def summarize(iso):
    binding = reference(ROOT/f'bandlimited-{iso}.json')
    records = read_json(checked(binding))
    data = records['rows']
    cohort = split(data)
    gains = calibrated(data,'fine',set(cohort['calibration']))
    assert gains['parent']==0. and all(-1<=v<=2 for v in gains.values())
    boot = np.random.default_rng(4250324)
    summary={}
    examples={}
    for division, ids in cohort.items():
        rows = [row for row in data if row['source'] in set(ids)]
        n = len(rows)
        counts = np.vstack((np.arange(n),boot.integers(n,size=(10000,n))))
        output={}
        per = values(rows,'fine',gains,np.arange(n)[None].T)
        for k in NAMES[1:]:
            delta=per[k]['increment_RMS_DN16']-per['parent']['increment_RMS_DN16']
            examples[division,k] = [{'kind':kind,'source':rows[i]['source'],'case':rows[i]['case'],
                'increment_delta_DN16':float(delta[i])}
                for kind,i in (('best',delta.argmin()),('worst',delta.argmax()))]
        for band in measure.BANDS:
            candidates = values(rows,band,gains,counts)
            arm_values = {}
            for name, arm in candidates.items():
                arm_values[name]={'mean':{k:float(v[0]) for k,v in arm.items()}}
                changes = {k:v-candidates['parent'][k] for k,v in arm.items()}
                arm_values[name]['change'] = {k:{'point':float(v[0]),
                    'interval':np.quantile(v[1:],(.025,.975)).tolist()} for k,v in changes.items()}
            output[band]=arm_values
        summary[division]=output
    write_json(ROOT/f'bandlimited-{iso}-summary.json',
            dict(source=binding,driver=reference(__file__),checkpoint=records['parent'],gains=gains,
                data=summary,cohort=cohort,examples={d:{k:examples[d,k] for k in NAMES[1:]} for d in cohort}))
    print(gains,summary['test']['fine'],flush=True)


if __name__=='__main__':
    action,iso=sys.argv[1:]
    {'replay':replay,'summary':summarize}[action](iso)
