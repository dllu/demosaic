"""Check complement arithmetic, green sampling and the assumed noise law."""
import numpy as np
import torch

from fission import ROOT, QUERY, bank_basis, green_wall, marginal, pattern, projector, split_views
from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import reference, write_json
from demosaic.noise import add_noise

PROFILE = {'shot':.00128,'read':6.5536e-6}
PATTERNS = ((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0))


def moments(plus,minus,mu):
    x = (plus.astype(float)-mu)
    y = (minus.astype(float)-mu)
    x -= x.mean()
    y -= y.mean()
    xy = x*y
    return {'correlation':float(np.mean(xy)/(x.std()*y.std())),
            'scaled_mixed_third_moment':float(np.mean(x*xy)/(x.var()*y.std())),
            'first_std_DN16':float(x.std()*65535),
            'second_std_DN16':float(y.std()*65535)}


def validation():
    generator = np.random.default_rng(4120542)
    proof = {}
    mu = .1
    truth = np.full((2048,1,16,16),mu,np.float32)
    variance = np.full_like(truth,PROFILE['shot']*mu+PROFILE['read'])
    y = truth + np.sqrt(variance)*generator.standard_normal(truth.shape,dtype=np.float32)
    plus,minus = split_views(y,variance,51)
    err = float(np.max(np.abs((plus.astype(float)+minus)/2-y)))
    proof['normal_known_variance'] = {**moments(plus,minus,mu),'max_pair_average_error':err}
    assert err < 5e-8 and abs(proof['normal_known_variance']['correlation']) < .01
    rng = torch.Generator().manual_seed(621505)
    records = {}
    for j,mean in enumerate((.003,.015,.10,.50,.95,.998)):
        clean = torch.full(tuple(truth.shape),mean,dtype=torch.float32)
        measured = add_noise(clean,PROFILE['shot'],PROFILE['read'],black_level=.03,generator=rng).numpy()
        proxy = marginal(measured,PROFILE)
        plus,minus = split_views(measured,proxy,135560+j)
        coordinates = np.s_[...,3:13,3:13]
        msk = measured[coordinates]
        records[str(mean)] = {**moments(plus[coordinates],minus[coordinates],mean),
           'relative_variance_error':float(proxy[coordinates].mean()/msk.var()-1),
           'mean_sensor_bias_DN16':float((msk.mean()-mean)*65535)}
    proof['poisson_read_adc_with_noisy_variance_estimate'] = records
    des,start,_ = bank_basis()
    dy,dx,_,_=QUERY
    note = []
    for color in PATTERNS:
        for sx,sy in ((0,0),(0,1),(1,0),(1,1)):
            x,y=dx+sx,dy+sy
            box=(x,y,160,160)
            expected=des[...,start+3]*.025 + .3
            scene = np.full((256,256),.3,dtype=np.float32)
            scene[y:y+32,x:x+32] = expected
            tensor=torch.from_numpy(np.tile(scene,(1,3,1,1)))
            raw=mosaic(tensor,torch.tensor(color))[0].numpy()
            samples,offset=green_wall(raw,np.asarray(color),box)
            fit,_=projector(offset)
            coeffs=(samples-samples.mean(1,keepdims=True))@fit
            direct=pattern(scene,box)
            note.append(float(abs(coeffs[0]-direct[0]).max()))
    proof['first_window_dense_vs_bayer_fit_worst_abs'] = max(note)
    proof['CFA_and_ROI_parity_cases'] = len(note)
    assert max(note) < 2e-8
    write_json(ROOT/'validation.json',{'driver':reference(__file__), 'noise':PROFILE,'measurements':proof})
    print(proof,flush=True)


if __name__ == '__main__':
    validation()
