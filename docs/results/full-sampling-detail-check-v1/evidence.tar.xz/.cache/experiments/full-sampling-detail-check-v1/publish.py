"""Verify full-sampling evidence and preserve crops and measured receipts."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
IMAGES = Path('docs/images') / ROOT.name
RESULTS = Path('docs/results') / ROOT.name


def pixels(spec, path=None):
    image = np.asarray(Image.open(path or checked(spec['image'])).convert('RGB'))
    results = {cell.get('label',cell.get('name')):image[y:y+h,x:x+w]
               for cell in spec['panels'] for x,y,w,h in [cell['png_xywh']]}
    assert all(rgb.shape==(160,160,3) for rgb in results.values())
    return results


def retain(spec, kind):
    source = checked(spec['image'])
    target = IMAGES/kind/source.name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert reference(target)['sha256']==spec['image']['sha256']
    output = pixels(spec,target)
    spec['image']['path']=target.relative_to(IMAGES).as_posix()
    return output


def main():
    names = ('evaluation','compensated','bandlimited-iso6400-summary','validation','native')
    refs = {name:reference(ROOT/f'{name}.json') for name in names}
    run,fit,band,validation,images = [read_json(checked(src)) for src in refs.values()]
    assert {k:refs[k] for k in names[:3]} == images['source']
    assert images['checkpoint']==run['checkpoint']==fit['checkpoint']==band['checkpoint']
    assert run['cohort']==band['cohort'] and all(group==run['cohort'] for group in fit['source_splits'].values())
    assert len(run['cohort']['calibration'])==16 and len(run['cohort']['test'])==48
    assert set(run['cohort']['calibration']).isdisjoint(run['cohort']['test'])
    paired = {iso:read_json(checked(src)) for iso,src in run['per_photo'].items()}
    for iso,compensated in fit['receipts'].items():
        a = paired[iso]
        b = read_json(checked(compensated))
        assert b['paired_replay']==run['per_photo'][iso]
        assert len(a['rows'])==len(b['rows'])==64
        for left,right in zip(a['rows'],b['rows'],strict=True):
            assert all(left[key]==right[key] for key in ('case','profile','source','input','prediction_receipt'))
            assert len(left['paired_forwards'])==2
    band_record = read_json(checked(band['source']))
    assert band_record['previous']==run['per_photo']['iso6400'] and len(band_record['rows'])==64
    assert len(images['exact'])==2 and len(images['standing']['rows'])==8
    for row in images['exact']:
        view, triplet = (retain(row[k],'exact') for k in ('board','triplet'))
        assert list(triplet)==['Noisy Malvar','Fine-band replacement','Exact GT']
        assert all(np.array_equal(im,view[name]) for name,im in triplet.items())
        assert row['checkpoint']==images['checkpoint']
    for row in images['standing']['rows']:
        old = pixels(row['old_board'])
        view = retain(row['board'],'standing')
        assert row['checkpoint']==images['checkpoint']
        keys = set(view) & set(old)
        assert {'ISO100 AHD reference','Noisy (Malvar)','Parent 100k EMA'} <= keys
        if row['id'].startswith('mesh-'):
            assert {'ISO6400 camera JPEG','ISO100 camera JPEG'} <= keys
            assert row['native_shape']==[768,768]
        else:
            assert row['native_shape']==[512,512]
        assert all(np.array_equal(view[k],old[k]) for k in keys)
    manifest=IMAGES/'manifest.json'
    write_json(manifest, {**images,'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    RESULTS.mkdir(exist_ok=True)
    files = list(ROOT.glob('*.py'))+list(ROOT.glob('*.log'))
    files += [checked(src) for src in (*refs.values(),*run['per_photo'].values(),*fit['receipts'].values(),band['source'])]
    files += [ROOT.with_name('scene-raw-covariance-v1')/n for n in ('covariance.py','evaluate.py')]
    files += [ROOT.with_name('scene-local-contrast-2400-v1')/'measure.py',
              ROOT.with_name('paired-luminance-detail-v1')/'render.py',Path('scripts/report_scene_wave_guides.py')]
    archive=RESULTS/'evidence.tar.xz'
    members={p.resolve().relative_to(Path.cwd()).as_posix():p for p in files}
    with tarfile.open(archive,'w:xz',preset=4) as out:
        for name,p in sorted(members.items()):
            out.add(p,arcname=name,recursive=False)
    with tarfile.open(archive) as inp:
        for name,p in members.items():
            with inp.extractfile(name) as handle:
                assert hashlib.file_digest(handle,'sha256').hexdigest()==reference(p)['sha256']
    compact = {
        'opposite_view_test':{iso:{policy:v['fine'] for policy,v in run['scopes'][f'{iso}/test'].items()}
                           for iso in ('iso400','iso6400')},
        'windowed_gain_test':{iso:fit['results'][f'{iso}/test'] for iso in ('iso400','iso6400')},
        'band_limited_ISO6400_test':band['data']['test'],
    }
    write_json(RESULTS/'publication.json',dict(checkpoint=run['checkpoint'],archive=reference(archive), native=reference(manifest),
        sources=refs,validation=validation,compact=compact,calibration={'dose':run['doses'],
        'added_quiet_RMS_DN16':run['matched_added_quiet_budget_DN16'],'bandlimited_gain':band['gains']},
        scope='Fixed Corpus 100k EMA. 64-photo exact comparisons in two noise profiles, confined-band extension at ISO6400, and both standing camera families. No new training or broad photo/camera scoring.'))
    print('Verified',len(members),'archive files, 2 exact triplets and 8 standing GFX boards')


if __name__=='__main__':
    main()
