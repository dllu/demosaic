"""Freeze correction strength on development photos and summarize the held-out result."""
import numpy as np

from fission import ROOT, ARMS, measure, split
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LIFTS = ('same','opposite','signed_opposite','opposite_first','dither_extrapolation')
MATCHED = ('parent',*LIFTS)
PAIRS = (
    ('pair_opposite','pair_same'), ('pair_opposite','pair_average'),
    ('repeat_average','pair_average'), ('opposite','same'), ('opposite','opposite_first'),
    ('signed_opposite','opposite'),
)
QUIET_BUDGET = .25


def estimate(rows, band, arms, doses, samples):
    scores, indices = {}, {}
    for arm in arms:
        values = [row['stats'][arm][band] for row in rows]
        desired = np.array([s['truth'] for s in values])
        r = np.asarray([s['response'] for s in values])
        dose = doses.get(arm,1.)
        score = {'response_pp':100*(r[:,0]+dose*r[:,1])[samples].sum(1)/desired[samples].sum(1)}
        for name in ('increment','present','quiet'):
            m = np.asarray([s[name] for s in values])
            square = np.maximum(0.,m[:,0]+2*dose*m[:,1]+dose**2*m[:,2])
            score[name+'_RMS_DN16'] = np.sqrt(square[samples].mean(1))
            if name == 'increment':
                indices[arm] = np.sqrt(square) - np.sqrt(m[:,0])
        q = np.sqrt([m['quiet'][2] for m in values]) * dose
        score['added_quiet_RMS_DN16'] = q[samples].mean(1)
        scores[arm] = score
    mean = {arm:{label:float(v[0]) for label,v in data.items()} for arm,data in scores.items()}
    estimates = {}
    for a,b in [(arm,'parent') for arm in arms if arm != 'parent'] + list(PAIRS):
        if not {a,b} <= scores.keys():
            continue
        gap = {k:scores[a][k]-scores[b][k] for k in scores[a]}
        estimates[a + '_vs_' + b] = {label:{'point':float(v[0]),
                'interval':np.quantile(v[1:],(.025,.975)).tolist()} for label,v in gap.items()}
    return dict(means=mean,deltas=estimates), indices


def main():
    refs = {iso:reference(ROOT/f'{iso}.json') for iso in ('iso400','iso6400')}
    baseline_path = ROOT.with_name('split-bayer-neural-v1')/'score-lattice.json'
    previous = read_json(baseline_path)
    data = {iso:read_json(checked(src)) for iso,src in refs.items()}
    assert all(data['iso400'][k]==data['iso6400'][k] for k in ('checkpoint','panel','settings','configuration'))
    assert data['iso400']['checkpoint']==previous['checkpoint']
    rows = [r for d in data.values() for r in d['rows']]
    previous_rows = {(r['case'],r['profile']):r for r in previous['rows']}
    for row in rows:
        baseline = previous_rows[row['case'],row['profile']]
        assert all(baseline[k] == row[k] for k in ('source','prediction_receipt'))
        assert baseline['stats']['parent'] == row['stats']['parent']
    cohort = split(rows)
    assert cohort == previous['summary']['split']
    calibration = [r for r in data['iso6400']['rows'] if r['source'] in set(cohort['calibration'])]
    assert len(calibration) == 16
    unit = {arm:float(np.mean([np.sqrt(r['stats'][arm]['fine']['quiet'][2]) for r in calibration])) for arm in LIFTS}
    budget = min(QUIET_BUDGET,*unit.values())
    assert budget > 0
    doses = {k:budget/v for k,v in unit.items()}
    sets = {}
    examples = []
    rng = np.random.default_rng(20296154)
    for iso, table in data.items():
        for partition, ids in cohort.items():
            active = [r for r in table['rows'] if r['source'] in set(ids)]
            assert len(active) == len(ids)
            draws = np.vstack((np.arange(len(ids)),rng.integers(len(ids),size=(10000,len(ids)))))
            policy = {'unit':{},'matched':{}}
            for band in measure.BANDS:
                policy['unit'][band],_ = estimate(active,band,ARMS,{},draws)
                policy['matched'][band],idx = estimate(active,band,MATCHED,doses,draws)
                if (iso,partition,band)==('iso6400','test','fine'):
                    for arm in ('opposite','dither_extrapolation','signed_opposite'):
                        for direction, index in zip(('best','worst'),(idx[arm].argmin(),idx[arm].argmax()),strict=True):
                            examples.append({'arm':arm,'extreme':direction,'source':active[index]['source'],
                                'case':active[index]['case'],'increment_delta':float(idx[arm][index])})
            sets[f'{iso}/{partition}']=policy
    x = dict(driver=reference(__file__),checkpoint=data['iso6400']['checkpoint'],cohort=cohort,selections=examples,
             unit_calibration_noise=unit,matched_added_quiet_budget_DN16=budget,doses=doses,scopes=sets,
             per_photo=refs,previous_baseline=reference(baseline_path))
    write_json(ROOT/'evaluation.json',x)
    for key in ('iso6400/test','iso400/test'):
        print(key,sets[key]['matched']['fine']['means'],flush=True)


if __name__=='__main__':
    main()
