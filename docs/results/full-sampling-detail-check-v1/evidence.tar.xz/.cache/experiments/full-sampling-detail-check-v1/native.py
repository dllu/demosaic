"""Recompute both standing capture families and two exact photographs at native scale."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from fission import ROOT, QUERY, compose, fixture, panel, prepare, views
from compensate import extra_prior, lift
from bandlimited import compose as compose_band
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
from render import native_png

STANDING = ROOT.with_name('scene-full-epoch-v1')/'review-native-040000/work/render/result.json'
LABELS = {
    'repeat_average':'Four-guide average','opposite':'Opposite-view lift','signed_opposite':'Signed opposite lift',
    'double_prior':'Doubled prior with gain','pair':'One pair with gain','repeat':'Two pairs with gain',
    'half_mix':'Half parent with gain','band_repeat':'Fine-band replacement',
    'band_half_mix':'Half fine-band mix','band_double_prior':'Doubled prior in fine band',
}
ARMS=('repeat_average','opposite','signed_opposite','double_prior','pair','repeat','half_mix',
      'band_repeat','band_half_mix','band_double_prior')


def selected(model, data, parent, noise, key, roi, gains, doses, band_gains):
    cam = [data[k] for k in ('colors','wb','matrix')]
    raw = data['packed']
    perturbed, guides, variance, trace = views(model,raw,*cam,noise,key)
    doubled = extra_prior(model,raw,*cam,noise)
    scores = {name:[] for name in ARMS}
    for index,p in enumerate(parent):
        a = compose(p,perturbed[:,:,index],guides[:,:,index],variance[index],*cam,roi)
        for name in ('repeat_average','opposite','signed_opposite'):
            scores[name].append(p+np.float32(doses.get(name,1.))*(a[name]-p))
        originals={'double_prior':doubled[index],'pair':a['pair_average'],'repeat':a['repeat_average'],
                   'half_mix':.5*(p+a['repeat_average'])}
        for name,base in originals.items():
            change = lift(base[None],data['wb'],data['matrix'],roi)[0]
            scores[name].append(base+np.float32(gains[name])*change)
        for name in ('repeat','half_mix','double_prior'):
            prior,extra = compose_band(p,originals[name],data['wb'],data['matrix'],roi)
            scores['band_'+name].append(prior+np.float32(band_gains[name])*extra)
    return {name:np.stack(images) for name,images in scores.items()},trace


def exact(model, evidence, compensated, banded):
    _,results,spec = panel()
    settings = read_json(checked(spec['panel']))
    iso = 'iso6400'
    recipe = compensated['results'][f'{iso}/test']
    band_gains = banded['gains']
    candidates = {item['source']:item for item in results['source_metrics']
                  if (item['profile'],item['draw']) == (iso,'independent')}
    original = read_json(checked(evidence['per_photo'][iso]))
    replay = {row['source']:row for row in original['rows']}
    examples = [(item['increment_delta_DN16'],item['source']) for item in banded['examples']['test']['repeat']]
    out = ROOT/'exact'
    out.mkdir(exist_ok=True)
    pages = []
    for effect,source in examples:
        prediction, case, data, parent = fixture(candidates[source])
        output,trace = selected(model,data,parent,case['profile'],case['id'],QUERY,recipe['gains'],evidence['doses'],band_gains)
        assert trace == replay[source]['paired_forwards']
        refs = {k:data[k][None] for k in ('colors','wb','matrix')}
        refs['packed'] = data['packed'][:1]
        r = settings['rows'][case['case']]
        captions=('Noisy Malvar','Corpus 100k EMA',*(LABELS[n] for n in ARMS),'Exact GT')
        values=(noisy_malvar(refs)[0],parent[0],*(output[n][0] for n in ARMS), data['target'][0])
        meta={'photo':r['source'],'noise':case['profile'],'capture_black':r['camera']['black'],
              'CFA':r['camera']['pattern'],'query_xywh':case['box'],'ADC_bits':16,
              'native_ROI':QUERY,'fine_increment_change_DN16':effect,'input':case['input'],
              'checkpoint':evidence['checkpoint'],'paired_forwards':trace,
              'draw':'independent','gain':recipe['gains'],'band_gain':band_gains,'doses':evidence['doses']}
        pages.append(native_board(out,case['id']+'-full-sampling',values,refs,meta,labels=captions,
                     triplet_indices=(0,captions.index(LABELS['band_repeat']),len(captions)-1),roi=QUERY,
                     contrast=2,exposure=1/case['profile']['exposure']))
    return pages


def cells(spec):
    image=np.asarray(Image.open(checked(spec['image'])).convert('RGB'))
    return {cell['label']:image[y:y+h,x:x+w] for cell in spec['panels'] for x,y,w,h in [cell['png_xywh']]}


def standing(model, evidence, compensated, banded):
    bound = reference(STANDING)
    board = read_json(checked(bound))
    source = read_json(checked(board['collections']['parent100k']))
    assert source['checkpoint']['sha256']==evidence['checkpoint']['sha256']
    parents={x['id']:x for x in source['records']}
    out = ROOT/'standing'
    out.mkdir(exist_ok=True)
    seen = []
    gains = compensated['results']['iso6400/test']['gains']
    for row in board['boards']:
        name = row['id']
        if not name.startswith(('main-','mesh-')):
            continue
        original=parents[row['observation']]
        with np.load(checked(row['input_arrays']),allow_pickle=False) as src:
            data = {k:src[k] for k in ('packed','variance','colors','wb','matrix')}
        assert {k:fingerprint(value) for k,value in data.items()} == original['input_fingerprints']
        y = np.load(checked(original['prediction']),allow_pickle=False)
        assert y.shape[-1] == data['packed'].shape[-1]*2
        data.update({k:data[k][0] for k in ('colors','wb','matrix')})
        roi=row['case']['ROI_xywh']
        outputs,trace = selected(model,data,y,row['noise'],name,roi,gains,evidence['doses'],banded['gains'])
        wb, matrix = [torch.from_numpy(data[k][None]) for k in ('wb','matrix')]
        exposure=row['display_exposure']
        def display(z):
            shown = display_crop(torch.from_numpy(z),wb,matrix,roi,exposure=exposure)
            return np.rint(shown.clip(0,1)*255).astype(np.uint8)
        shown=cells(row)
        assert np.array_equal(display(y),shown['Parent 100k EMA'])
        arms = ('repeat_average','opposite','repeat','band_double_prior','band_repeat','band_half_mix')
        views = [(key,shown[key]) for key in ('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA') if key in shown]
        views += [(LABELS[k],display(outputs[k])) for k in arms]
        views += [(key,shown[key]) for key in ('ISO100 AHD reference','ISO100 camera JPEG') if key in shown]
        x,y0,w,h=roi
        crop=np.s_[...,y0:y0+h,x:x+w]
        differences={k:float(np.sqrt(np.mean((outputs[k][crop].astype(float)-y[crop])**2))*65535) for k in arms}
        png=native_png(out/f'{name}.png',views)
        seen.append(dict(id=name,checkpoint=evidence['checkpoint'],board=png,old_board=row,input=row['input_arrays'],
                         parent=original['prediction'],native_shape=y.shape[-2:],roi=roi,noise=row['noise'],
                         exposure=exposure,gains=gains,band_gains=banded['gains'],doses=evidence['doses'],paired_forwards=trace,RMS_DN16=differences))
        print(name,differences,flush=True)
    assert len(seen)==8
    return dict(source=bound,rows=seen)


@torch.inference_mode()
def main():
    protocols={name:reference(ROOT/f'{name}.json') for name in ('evaluation','compensated','bandlimited-iso6400-summary')}
    bare, calibrated, banded=(read_json(checked(src)) for src in protocols.values())
    assert bare['checkpoint']==calibrated['checkpoint']==banded['checkpoint']
    model=prepare(bare['checkpoint'])
    target=exact(model,bare,calibrated,banded)
    cameras=standing(model,bare,calibrated,banded)
    write_json(ROOT/'native.json',dict(driver=reference(__file__),source=protocols,checkpoint=bare['checkpoint'],
        exact=target,standing=cameras))


if __name__=='__main__':
    main()
