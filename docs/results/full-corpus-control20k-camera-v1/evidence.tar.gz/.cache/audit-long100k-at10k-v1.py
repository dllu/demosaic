"""Retain the original long schedule's10k state and compare its actual inputs."""
import os,json
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import numpy as np,psutil,torch
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2);os.nice(10)
b=Path('.cache/experiments/full-corpus-scaling-v3').resolve();run=b/'checkpoint-recovery-v7/work/artifacts/train/long100k';receipt=read_json(run/'step010000-receipt.json');p=checked(receipt['checkpoint']);plan=read_json(b/'production-handoff-plan-v7.json')
launch=read_json(b/'production-handoff-v7/01-scale-long100k-launch.json');owner=psutil.Process(launch['pid']);assert owner.create_time()==launch['create_time']
s=torch.load(p,map_location='cpu',weights_only=True);assert s['step']==10000 and s['config']['steps']==100000 and s['config']['batch_size']==16 and s['config']['seed']==70
assert len(s['model'])==len(s['ema'])==91 and len(s['optimizer']['state'])==89
assert all(v['step']==10000 for v in s['optimizer']['state'].values())and s['python_rng']and s['torch_rng'].numel()and s['cuda_rng']
assert all(torch.isfinite(v).all()for name in ['model','ema']for v in s[name].values())
assert all(torch.isfinite(v).all()for v in s['optimizer']['state'].values()for v in v.values()if isinstance(v,torch.Tensor))
out=b/'long100k-at10k-independent-v1';out.mkdir();os.link(p,out/'checkpoint.pt')
initial=Path(plan['adopted_states']['long100k']['path']).parent;resumed=run/'phase-001001-100000';events=[];source_snapshots=[]
for folder,low,high in [(initial,1,1000),(resumed,1001,10000)]:
 lines=[]
 with(folder/'source-crop-observations.jsonl').open()as stream:
  for line in stream:
   e=json.loads(line)
   if e['step']>high:break
   assert low<=e['step']<=high;events.append(e);lines.append(line)
 path=out/f'source-{low:06d}-{high:06d}.jsonl';path.open('x').write(''.join(lines));source_snapshots.append(reference(path))
assert len(events)==10000 and[e['step']for e in events]==list(range(1,10001))and[e['global_draw_start']for e in events]==list(range(0,160000,16))
control=read_json('docs/results/full-corpus-control20k-review-v1/completed-training-audit.json');other=[]
for ref in control['sources']:
 with checked(ref).open()as stream:other +=[e for line in stream if(e:=json.loads(line))['step']<=10000]
assert len(other)==10000 and[e['step']for e in other]==list(range(1,10001))
source_equal=[i+1 for i,(a,c)in enumerate(zip(events,other,strict=True))if a!=c]
condition_checks=[]
control_conditions={Path(v['path']).name:v for v in control['conditioning_chunks']if int(Path(v['path']).stem.rsplit('-',1)[1])<=10000}
for folder,low,high in [(initial,1,1000),(resumed,1001,10000)]:
 for path in sorted(folder.glob('conditions-*.npz')):
  first,last=map(int,path.stem.split('-')[1:])
  if first<low or last>high:continue
  with np.load(path)as a,np.load(checked(control_conditions[path.name]))as c:
   assert a.files==c.files and a['values'].shape==(250,16,14)and np.isfinite(a['values']).all()
   assert a['steps'].tolist()==list(range(first,last+1));assert a['domains'].tolist()==[events[i-1]['domain']for i in a['steps']]
   same={key:np.array_equal(a[key],c[key])for key in a.files}
   condition_checks.append({'long':reference(path),'control':control_conditions[path.name],'logical_arrays_bitexact':same})
assert len(condition_checks)==40
old=read_json('.cache/experiments/full-corpus-control10k-review-v1/plan.json');spec=next(v for v in old['models'].values()if v['step']==10000);cs=torch.load(checked(spec['checkpoint']),map_location='cpu',weights_only=True)
rng={'Python':s['python_rng']==cs['python_rng'],'CPU':torch.equal(s['torch_rng'],cs['torch_rng']),'CUDA':len(s['cuda_rng'])==len(cs['cuda_rng'])and all(torch.equal(a,c)for a,c in zip(s['cuda_rng'],cs['cuda_rng'],strict=True))}
photos=Counter(x['source_id']for e in events for x in e['sources']if x['kind']=='photographic')
write_json(out/'result.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'checkpoint':reference(out/'checkpoint.pt'),'original_receipt':reference(run/'step010000-receipt.json'),'original_checkpoint':receipt['checkpoint'],'training_plan':reference(b/'production-handoff-plan-v7.json'),'parent':plan['parent'],'step':10000,'horizon':100000,'target_slots':160000,'raw_tensors':91,'EMA_tensors':91,'finite_Adam_states_at10k':89,'RNG_present':True,'sources':source_snapshots,'source_steps_different_from_control10k':source_equal,'conditioning_comparisons':condition_checks,'RNG_equal_control10k':rng,'domain_batches':dict(Counter(e['domain']for e in events)),'photo_visits':sum(photos.values()),'distinct_photo_IDs':len(photos),'actual_owner':{'pid':owner.pid,'create_time':owner.create_time()},'scope':'Actual original100k trajectory at10k,not completed horizon/quality result. Initial1k+stateful resumed9k,no replay/reset. All160k source slots and40 actual conditioning chunks compared with separately annealed20k control at10k. Difference lists/flags are observations,not assumed equal. Per-phase full GPU batch witnesses remain in live worker memory until phase completion; no all-corruption bitexact claim is inferred from source/conditioning/RNG alone. No new neural/GPU/RAW/noise/optimizer calls.'})
print('Retained10k,source differences',len(source_equal),'condition equal',sum(all(v['logical_arrays_bitexact'].values())for v in condition_checks),'of40,RNG',rng)
