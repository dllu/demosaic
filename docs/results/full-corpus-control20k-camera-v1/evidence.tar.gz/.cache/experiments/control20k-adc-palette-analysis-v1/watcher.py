"""Wait on an owned palette collector,never restart; then physical-only analysis."""
import os,subprocess,sys,time
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
plan=read_json(sys.argv[1]);root=Path(plan['root']);launch=read_json(checked(plan['palette_launch']));future=Path(plan['future_collection']);start=time.monotonic()
for path,sha in plan['frozen_files'].items():checked({'path':path,'sha256':sha})
write_json(root/'status.json',{'status':'waiting-for-complete588','owner':launch},replace=True)
while not future.exists():
 owner=psutil.Process(launch['pid']);assert owner.create_time()==launch['create_time'],'Collector PID identity changed; no retry'
 if time.monotonic()-start>plan['maximum_wait_seconds']:raise TimeoutError('Palette wait deadline; no retry')
 time.sleep(15)
collection=read_json(future);assert collection['plan']==plan['palette_plan']and len(collection['records'])==588
analysis={k:v for k,v in plan.items()if k not in ['future_collection','palette_launch','maximum_wait_seconds']};analysis['palette_collection']=reference(future);write_json(root/'analysis-plan.json',analysis)
write_json(root/'status.json',{'status':'physical-analysis-running','collection':reference(future)},replace=True)
with(root/'analysis.log').open('xb')as log:rc=subprocess.call([sys.executable,str(checked(plan['worker'])),str(root/'analysis-plan.json')],stdout=log,stderr=subprocess.STDOUT)
write_json(root/'analysis-return.json',{'returncode':rc});assert rc==0
write_json(root/'completed.json',{'watcher':reference(__file__),'queue_plan':reference(sys.argv[1]),'result':reference(root/'result.json'),'returncode':rc,'scope':'All588 numerical policies complete; independent audit and actual native viewing remain pending.'})
write_json(root/'status.json',{'status':'numerical-complete-audit-viewing-pending','result':reference(root/'result.json')},replace=True);print('Complete588 physical policy analysis',flush=True)
