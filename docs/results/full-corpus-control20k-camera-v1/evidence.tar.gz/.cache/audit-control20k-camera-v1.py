"""Independent photometry and capture aggregation; native-pixel/source checks."""
import os,sys
from pathlib import Path
from collections import defaultdict
import numpy as np
import torch
from PIL import Image
from audit_quality_archive import _check
from demosaic.archive_metrics import photometry
from demosaic.cfa import malvar
from demosaic.reporting import display_crop
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2);assert os.environ['CUDA_VISIBLE_DEVICES']==''
r=Path('.cache/experiments/control20k-camera-review-v2').resolve();errors=defaultdict(lambda:defaultdict(float));count=0;parent_matches=0;boards=0;channels=0;triplets=0;cases=[];summaries={}
for stage,n in [('known',24),('unseen',30)]:
 result=read_json(r/stage/'result.json');plan=read_json(checked(result['plan']));canonical=read_json(checked(plan['canonical_inputs']));records={v['batch']:v for v in canonical['records']if v['stage']==stage};groups=defaultdict(list)
 previous=read_json(Path('.cache/experiments/scene-primary-camera-review-v1')/stage/'result.json');old={read_json(checked(v))['batch']:read_json(checked(v))for v in previous['cases']}
 assert len(records)==len(result['cases'])==n
 for binding in result['cases']:
  case=read_json(checked(binding));record=records[case['batch']];assert case['canonical_arrays']==record['arrays'];cases.append(binding)
  with np.load(checked(record['arrays']))as f:a=dict(f)
  for v in case['variants']:
   p=np.load(checked(v['prediction']));assert v['checkpoint']==plan['models'][v['arm']]['checkpoint'];m=photometry(p,a,border=32,camera=True)
   assert [row['id']for row in v['rows']]==record['context']['ids']
   for i,row in enumerate(v['rows']):
    _check({name:value[i]for name,value in m.items()},row['metrics'],errors[stage],stage);groups[v['arm'],row['scene'],row['pair']].append(row['metrics']['sensor_psnr']);count+=1
   if v['arm']=='V120':
    prior=next(vv for vv in old[case['batch']]['variants']if vv['arm']=='V120');assert prior['checkpoint']==v['checkpoint']and old[case['batch']]['canonical_arrays']==case['canonical_arrays'];np.testing.assert_array_equal(p,np.load(checked(prior['prediction'])));assert v['rows']==prior['rows'];parent_matches+=1
 byscene=defaultdict(list)
 for(m,s,p),values in groups.items():assert len(values)==9;byscene[m,s].append(float(np.mean(values)))
 scene_scores={k:float(np.mean(v))for k,v in byscene.items()};assert all(len(v)==2 for v in byscene.values())
 for v in result['per_scene']:assert scene_scores[v['arm'],v['scene']]==v['sensor_psnr']
 summaries[stage]={m:float(np.mean([v for(mm,_),v in scene_scores.items()if mm==m]))for m in plan['models']}
 for v in result['summary']['overall']:assert abs(summaries[stage][v['model']]-v['metrics']['sensor_psnr']['mean'])<1e-12
 native=read_json(r/'work/artifacts'/(stage+'-native-v3')/'result.json')
 with torch.inference_mode():
  for b in native['boards']:
   case=read_json(checked(b['case']));record=records[case['batch']];assert b['native_context_xywh']==record['context']['crop_xywh'][0];x,y,w,h=b['native_context_xywh'];assert b['absolute_native_ROI_xywh']==[x+176,y+176,160,160]
   with np.load(checked(b['canonical_arrays']))as f:a={k:torch.from_numpy(f[k].copy())for k in f.files}
   values=[malvar(a['packed'],a['colors'],a['wb'])]+[torch.from_numpy(np.load(checked(v['prediction'])))for v in case['variants']]+[a['reference_rgb']];img=np.asarray(Image.open(checked(b['image'])))
   assert len(values)==len(b['panels'])==4 and img.shape==(192,680,3)
   for v,p in zip(values,b['panels'],strict=True):
    pixel=np.rint(display_crop(v[:1],a['wb'][:1],a['matrix'][:1],b['ROI_xywh'],exposure=1).clip(0,1)*255).astype(np.uint8);x,y,w,h=p['png_xywh'];assert(w,h)==(160,160);np.testing.assert_array_equal(img[y:y+h,x:x+w],pixel);channels+=pixel.size
   t=next(t for t in native['triplets']if t['id']==b['id']);meta=read_json(checked(t['metadata']));ts=np.asarray(Image.open(checked(t['image'])));assert 'not exact RGB GT'in meta['reference']
   for pp,i in zip(meta['panels'],[0,2,3],strict=True):
    x,y,w,h=pp['png_xywh'];xx,yy,ww,hh=b['panels'][i]['png_xywh'];np.testing.assert_array_equal(ts[y:y+h,x:x+w],img[yy:yy+hh,xx:xx+ww])
   boards+=1;triplets+=1
assert count==324 and parent_matches==54 and boards==triplets==9 and not torch.cuda.is_initialized()
out=r/'independent-audit-v1';out.mkdir();write_json(out/'result.json',{'producer':reference(__file__),'NumPy_metric_source':reference('src/demosaic/archive_metrics.py'),'legacy_tolerance_helper':reference('scripts/audit_quality_archive.py'),'cases':cases,'maximum_discrepancies':dict(errors),'per_panel_measured_CFA_PSNR':summaries,'model_crop_rows':count,'V120_camera_batches_bitexact_to_closed_controls':parent_matches,'native_boards':boards,'native_channels':channels,'triplets_exact_subsets':triplets,'status':'passed','scope':'Independent NumPy64 fixed-border photometry/CFA masks under unchanged5e-4dB/2e-6 tolerances; capture9crops,2captures/scene,then equal-scene means. Source/crop alignment,original Torch display every native pixel and triplet subsets checked.54 fresh V120 batches and every metric row bitexact to closed scene-primary controls. No neural/GPU/RAW/noise/optimizer work. AHD RGB is auxiliary,not exact RGB GT. Full427 photo benchmark still running.'});print('Audited',count,'model/crop rows,54 exact parent batches,9 boards',dict(errors),summaries)
