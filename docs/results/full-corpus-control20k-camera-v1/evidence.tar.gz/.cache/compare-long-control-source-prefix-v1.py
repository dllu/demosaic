"""Distinguish declared order-header identity from source/crop selections."""
import copy,json
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
b=Path('.cache/experiments/full-corpus-scaling-v3').resolve();r=b/'long100k-at10k-independent-v1';a=read_json(r/'result.json');control=read_json('docs/results/full-corpus-control20k-review-v1/completed-training-audit.json');long=[]
for p in a['sources']:long +=[json.loads(l)for l in checked(p).read_text().splitlines()]
other=[]
for p in control['sources']:other +=[row for l in checked(p).read_text().splitlines()if(row:=json.loads(l))['step']<=10000]
headers=[b.parent/'full-corpus-scaling-v1'/name/'photo-epoch-order.json'for name in ['order100k','order20k']];hs=[read_json(p)for p in headers];hashes=[reference(p)['sha256']for p in headers]
assert hs[0]['ordered_train_ids_sha256']==hs[1]['ordered_train_ids_sha256']and hs[0]['source_manifest']==hs[1]['source_manifest']
arrays=[]
for header,path in zip(hs,headers,strict=True):
 p=path.parent/header['order']['path'];assert reference(p)['sha256']==header['order']['sha256'];arrays.append(np.load(p,mmap_mode='r'))
np.testing.assert_array_equal(arrays[0][:160000],arrays[1][:160000]);normalized=0;source_items=0
for x,y in zip(long,other,strict=True):
 x,y=copy.deepcopy(x),copy.deepcopy(y)
 for i,h in [(x,hashes[0]),(y,hashes[1])]:
  for item in i['sources']:assert item.pop('photo_epoch_order_sha256')==h
 assert x==y;normalized+=1;source_items+=len(x['sources'])
assert normalized==10000 and len(a['source_steps_different_from_control10k'])==5038 and all(all(v['logical_arrays_bitexact'].values())for v in a['conditioning_comparisons'])
write_json(r/'source-order-identity-addendum.json',{'producer':reference(__file__),'original_audit':reference(r/'result.json'),'order_headers':[reference(p)for p in headers],'raw_record_differences':5038,'difference_field_only':'sources[*].photo_epoch_order_sha256','source_items_compared':source_items,'all10000_step_source_crop_records_equal_except_declared_order_header':True,'all160000_order_prefix_entries_equal':True,'all40_actual_conditioning_chunks_equal':True,'all_CPU_CUDA_Python_RNG_states_equal_at10k':a['RNG_equal_control10k'],'scope':'The100k and20k orders have different immutable header hashes because their lengths differ. Original raw comparison truthfully records5038 Commons-row differences. Every remaining source/crop/data-seed field matches once that one declared identity field is checked against its own header. Full finite input payload prefixes match160k. This is input/source/conditioning evidence,not identical learned weights,completed100k,quality,all-native/paired source IDs or all physical-noise tensor hashes. No original receipt/source/worker mutation.'});print('All10k source/crop/data-seed records match except declared order-header hashes;40 condition chunks andall3 RNG states match.')
