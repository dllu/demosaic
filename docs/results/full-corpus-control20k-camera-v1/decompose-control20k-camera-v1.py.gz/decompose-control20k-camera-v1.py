"""Masked measured-CFA error: channel DC versus centered spatial error."""
import os,sys
from pathlib import Path
from collections import defaultdict
import numpy as np
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
assert 'torch'not in sys.modules;os.sched_setaffinity(0,[2,3]);os.nice(10)
r=Path('.cache/experiments/control20k-camera-review-v2');rows=[];maximum=0.;panels={}
for stage in ['known','unseen']:
 result=read_json(r/stage/'result.json');groups=defaultdict(list)
 for binding in result['cases']:
  case=read_json(checked(binding))
  with np.load(checked(case['canonical_arrays']))as data:t=data['sensor_reference'][...,32:-32,32:-32].astype(np.float64);mask=data['sensor_mask'][...,32:-32,32:-32]
  count=mask.sum((-2,-1));n=count.sum(1);assert np.all(count>0)
  for v in case['variants']:
   p=np.load(checked(v['prediction']))[...,32:-32,32:-32].astype(np.float64);e=p.clip(0,1)-t;mu=(e*mask).sum((-2,-1))/count
   mse=(e*e*mask).sum((1,2,3))/n;bias=(mu*mu*count).sum(1)/n;spatial=(((e-mu[...,None,None])**2)*mask).sum((1,2,3))/n
   np.testing.assert_allclose(bias+spatial,mse,rtol=2e-13,atol=1e-20)
   scores=-10*np.log10(np.maximum(mse,1e-12));d=max(abs(scores-np.array([v['metrics']['sensor_psnr']for v in v['rows']])));assert d<5e-4;maximum=max(maximum,float(d))
   for i,original in enumerate(v['rows']):
    assert n[i]==original['metrics']['reference_samples'];row={'stage':stage,'model':v['arm'],'scene':original['scene'],'pair':original['pair'],'id':original['id'],'MSE':float(mse[i]),'channel_DC_MSE':float(bias[i]),'centered_spatial_MSE':float(spatial[i]),'channel_mean_error_DN16':(mu[i]*65535).tolist(),'samples':int(n[i])};rows.append(row);groups[v['arm'],original['scene'],original['pair']].append(row)
 pairgroups=defaultdict(list)
 for(m,s,p),values in groups.items():
  assert len(values)==9;pairgroups[m,s].append({key:float(np.mean([v[key]for v in values]))for key in ['MSE','channel_DC_MSE','centered_spatial_MSE']})
 scenes={}
 for(m,s),values in pairgroups.items():
  assert len(values)==2;scenes[m,s]={k:float(np.mean([v[k]for v in values]))for k in ['MSE','channel_DC_MSE','centered_spatial_MSE']}
 panels[stage]={m:{k:float(np.mean([v[k]for(mm,s),v in scenes.items()if mm==m]))for k in ['MSE','channel_DC_MSE','centered_spatial_MSE']}for m in result['models']}
assert len(rows)==324
out=r/'masked-error-decomposition-v1';out.mkdir();write_json(out/'result.json',{'producer':reference(__file__),'camera_results':[reference(r/s/'result.json')for s in ['known','unseen']],'rows':rows,'source_balanced_panel_MSE':panels,'maximum_reconstructed_PSNR_difference_dB':maximum,'scope':'Independent FP64 masked camera-space sums,original32px border and primary prediction clamp. Weighted per-channel DC +centered spatial error reconstructs every measured-CFA MSE.9crops within capture,2captures within scene,then equal scenes; arithmetic MSE is distinct from meanPSNR. Centered spatial term is not a fine-band-only metric. AHD RGB is not involved; paired measured-CFA references are not exact fullRGB GT.0 neural/GPU/RAW/noise/optimizer calls.'});print(panels)
