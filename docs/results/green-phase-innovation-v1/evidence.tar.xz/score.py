"""Measure matched RAW phase filtering on the fixed weak-edge panel."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from phase_innovation import lift, standard

ROOT = Path(__file__).resolve().parent
WEAK = ROOT.parent / "weak-edge-distill-v1"
sys.path.insert(0, str(WEAK))
from edge_delivery import detail, quiet, paired_gates
from edge_data import edge_distance
from edge_parents import fields
from evaluate_repeat import as_cuda, channel_coefficients
from measure_detail_scale import compare, rms_spatial, spatial
from review_edge import load_models, BANDS
from strength_moments import measure


def freeze():
    write_json(
        ROOT / "plan.json",
        {
            "scope": "Compare same-phase 3x3 and nearest native-green lattice innovation filtering at identical white-noise kernel energy, with unchanged frozen correction and trunk. Compare at calibration-matched signed fine response.",
            "driver": reference(__file__),
            "new_filter": reference(ROOT / "phase_innovation.py"),
            "fixed": reference(WEAK / "fixed-review.json"),
            "calibration": list(range(24)),
            "test": list(range(24, 48)),
            "fit_condition": "Per-prior shared-step data. Reuse one fitted multiplier on held-out natural and shared-step conditions.",
        },
    )


def proposals(teacher, parent, args, limits, *, check=False):
    wide, shared = paired_gates(*args[:3], *limits)
    calm, grey = quiet(teacher, parent, args, wide)
    current = detail(teacher, parent, args, shared)
    measured = lift(teacher, parent, args, shared)
    if check:
        replay = lift(teacher, parent, args, shared, mixing=lambda v, _: standard(v))
        torch.testing.assert_close(current, replay, rtol=0, atol=0)
    return parent + calm, grey[:, :, None, None] * current, grey[:, :, None, None] * measured


def moments(variant, base, target, truth_rgb, coords, roi):
    x, y, w, h = roi
    centered = np.zeros((256, 256), dtype=bool)
    centered[y : y + h, x : x + w] = True
    near, far = (abs(coords.numpy()) <= 12) & centered, (abs(coords.numpy()) >= 24) & centered
    anchor, coeffs = base
    rgb, fine = variant
    current = spatial(anchor - truth_rgb[None])
    diff = spatial(rgb - anchor)
    offset = diff[:, 0] - diff[:, 1]
    residual = current[:, 0] - current[:, 1]
    original = measure(coeffs, fine - coeffs, target, BANDS["fine"])
    return original | {
        "local": {
            "near_increment_DN16": rms_spatial(residual, offset, near),
            "far_increment_DN16": rms_spatial(residual, offset, far),
            "near_absent_DN16": rms_spatial(current[:, 1], diff[:, 1], near),
        }
    }


def statistics(rows, plan):
    rng = np.random.default_rng(618204)
    output = {}
    for profile in ("iso1600", "iso6400"):
        selected = [r for r in rows if r["profile"] == profile]
        cal = [
            r for r in selected if r["index"] in plan["calibration"] and r["style"] == "same-edge"
        ]
        gain = {
            name: sum(r["moments"][name]["aligned"][1] for r in cal) for name in ("same", "bayer")
        }
        scale = (
            {n: min(gain.values()) / v for n, v in gain.items()} if min(gain.values()) > 0 else {}
        )
        if scale:
            assert abs(compare(cal, "bayer", "same", scale, rng)["response_pp"][0]) < 1e-10
        scores = {}
        for style in ("same-edge", "natural"):
            held = [r for r in selected if r["index"] in plan["test"] and r["style"] == style]
            assert len(held) == 24
            scores[style] = {
                "bayer_vs_same": compare(held, "bayer", "same", scale, rng),
                "bayer_vs_parent": compare(held, "bayer", "parent", scale, rng),
                "matched_same_vs_parent": compare(held, "same", "parent", scale, rng),
                "nominal_bayer_vs_same": compare(held, "bayer", "same", {}, rng),
            }
        output[profile] = {"calibration": gain, "scales": scale, "scores": scores}
    return output


@torch.inference_mode()
def run(smoke=False):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(
        min(1.0, 5 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    bound = reference(ROOT / "plan.json")
    plan = read_json(checked(bound))
    old = read_json(checked(plan["fixed"]))
    parents = read_json(checked(old["parents"]))
    physical = read_json(checked(parents["observations"]))
    config = read_json(checked(physical["plan"]))
    recipe = read_json(checked(old["recipe"]))
    teacher, _, _ = load_models("fixed", recipe)
    limits = (
        read_json(checked(recipe["guard"]))["threshold"],
        read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0],
    )
    upstream = {r["id"]: r for r in parents["rows"]}
    rows = []
    began = time.monotonic()
    with ieee_fp32():
        for case in physical["cases"][: 4 if smoke else None]:
            native = fields(case)
            entry = upstream[case["id"]]
            with np.load(checked(entry["saved"]), allow_pickle=False) as file:
                restored = file["100k"]
            assert entry["physical"] == case["input"]
            parent = (
                torch.from_numpy(restored.reshape(6, 3, 256, 256))
                .cuda()
                .contiguous(memory_format=torch.channels_last)
            )
            args = as_cuda(
                {key: value.reshape((-1, *value.shape[2:])) for key, value in native.items()}
            )
            anchor, baseline, new = proposals(teacher, parent, args, limits, check=len(rows) < 4)
            camera = [{k: native[k][r] for k in ("wb", "matrix")} for r in range(2)]
            roi = config["score_ROI_xywh"]

            def convert(value):
                both = [channel_coefficients(n, c, roi) for n, c in zip(value, camera, strict=True)]
                return tuple(np.stack([n[j] for n in both]) for j in range(2))

            exact, targ = convert(native["target"])
            np.testing.assert_array_equal(exact[0], exact[1])
            base = convert(anchor.view(2, 3, 3, 256, 256).cpu().numpy())
            geo = config["heldout_rows"][case["index"]]["geometry"]
            coords = edge_distance(geo)[1]
            options = {"parent": parent, "bayer": anchor + new, "same": anchor + baseline}
            index = case["index"]
            rows.append(
                {
                    "id": case["id"],
                    "index": index,
                    "profile": case["profile"]["name"],
                    "style": case["style"],
                    "moments": {
                        key: moments(
                            convert(value.reshape(restored.shape).cpu().numpy()),
                            base,
                            targ[0],
                            exact[0],
                            coords,
                            roi,
                        )
                        for key, value in options.items()
                    },
                }
            )
            if len(rows) % 24 == 0 or smoke:
                print(len(rows), round(time.monotonic() - began, 2), flush=True)
    assert len(rows) == (4 if smoke else 192)
    write_json(
        ROOT / ("smoke.json" if smoke else "result.json"),
        {
            "plan": bound,
            "metrics": None if smoke else statistics(rows, plan),
            "rows": rows,
            "seconds": time.monotonic() - began,
            "parent": parents["models"]["100k"],
            "correction": recipe["initial_head"],
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("freeze", "smoke", "score"))
    mode = parser.parse_args().mode
    freeze() if mode == "freeze" else run(mode == "smoke")
