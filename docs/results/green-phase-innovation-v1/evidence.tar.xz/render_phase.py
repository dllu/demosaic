"""Render green phase mixing above frozen Corpus 100k on fixed native inputs."""

from pathlib import Path

import numpy as np
import torch

from score import ROOT, WEAK, fields, proposals, as_cuda, load_models
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board
from measure_detail_scale import metric
import render_repeat
from edge_data import ARGS

LABELS = {
    "V120": "V120 EMA",
    "100k": "Corpus 100k EMA",
    "quiet": "Quiet path",
    "same": "Same-phase smoothing",
    "bayer": "Native-green smoothing",
}


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    scored = reference(ROOT / "result.json")
    numeric = read_json(checked(scored))
    plan = read_json(checked(numeric["plan"]))
    archive = read_json(checked(plan["fixed"]))
    parents = read_json(checked(archive["parents"]))
    inputs = read_json(checked(parents["observations"]))
    scene = read_json(checked(inputs["plan"]))
    recipe = read_json(checked(archive["recipe"]))
    head, _, _ = load_models("fixed", recipe)
    guard = (
        read_json(checked(recipe["guard"]))["threshold"],
        read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0],
    )
    scales = numeric["metrics"]["iso6400"]["scales"]
    source = {r["id"]: r for r in inputs["cases"]}
    cached = {r["id"]: r for r in parents["rows"]}
    chosen = [
        r
        for r in numeric["rows"]
        if r["profile"] == "iso6400" and r["style"] == "same-edge" and r["index"] in plan["test"]
    ]
    assert len(chosen) == 24

    def difference(row, field):
        old, new = (metric(row["moments"][k], scales[k])[field] for k in ("same", "bayer"))
        return new - old

    rows = sorted(chosen, key=lambda r: difference(r, "near_increment_DN16"))
    examples = [
        (rows[0], 0, "Largest near-step reduction."),
        (rows[-1], 0, "Largest near-step regression."),
        (
            max(chosen, key=lambda r: difference(r, "near_absent_DN16")),
            1,
            "Largest absent-detail near-step increase.",
        ),
    ]
    folder = ROOT / "native"
    folder.mkdir()

    def restore(model, args, priors, thresholds):
        parent = (
            torch.from_numpy(priors["100k"]).cuda().contiguous(memory_format=torch.channels_last)
        )
        anchor, control, phase = proposals(model, parent, args, thresholds)
        return priors | {
            "quiet": anchor.cpu().numpy(),
            "same": (anchor + scales["same"] * control).cpu().numpy(),
            "bayer": (anchor + scales["bayer"] * phase).cpu().numpy(),
        }

    shots = []
    render_repeat.predictions = restore
    render_repeat.SHOW = ("same", "bayer")
    render_repeat.DISPLAY = LABELS
    with ieee_fp32():
        for row, role, selection in examples:
            case = source[row["id"]]
            data = fields(case)
            upstream = cached[row["id"]]
            assert upstream["physical"] == case["input"]
            with np.load(checked(upstream["saved"]), allow_pickle=False) as f:
                prior = {label: f[label][0] for label in ("V120", "100k")}
            predicted = restore(head, as_cuda({key: data[key][0] for key in ARGS}), prior, guard)
            fields_for_display = {k: data[k][0, role : role + 1] for k in ARGS}
            one = [
                noisy_malvar(fields_for_display)[0],
                *[predicted[k][role] for k in LABELS],
                data["target"][0, role],
            ]
            source_photo = scene["heldout_rows"][row["index"]]
            shots.append(
                native_board(
                    folder,
                    f"{row['id']}-r0-role{role}",
                    one,
                    fields_for_display,
                    {
                        "photo": source_photo["source"],
                        "CFA": source_photo["camera"]["pattern"],
                        "query": source_photo["box"],
                        "profile": case["profile"],
                        "why": selection,
                        "role": role,
                        "input": case["input"],
                    },
                    labels=("Noisy Malvar", *LABELS.values(), "Exact GT"),
                    triplet_indices=(0, 5, 6),
                    exposure=1 / case["profile"]["exposure"],
                    contrast=2,
                    roi=tuple(scene["display_ROI_xywh"]),
                )
            )
        standing = render_repeat.show_camera(head, guard, folder)
    write_json(
        folder / "render.json",
        {
            "result": scored,
            "driver": reference(__file__),
            "photos": shots,
            "standing": standing,
            "scales": scales,
            "actual_native_viewing_complete": False,
        },
    )


if __name__ == "__main__":
    run()
