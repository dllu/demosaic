"""Denoise the paired detail head's innovation at actual Bayer-green offsets."""

import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic, pack, unpack
from demosaic.paired_detail import fine_band


def standard(innovation):
    neighbors = F.avg_pool2d(innovation, 3, stride=1, padding=1, count_include_pad=False)
    return torch.lerp(innovation, neighbors, 0.5)


def phase_average(innovation, colors):
    native = unpack(innovation)
    kernel = (
        innovation.new_tensor(
            [
                [0, 0, 1, 0, 0],
                [0, 1, 0, 1, 0],
                [1, 0, 10, 0, 1],
                [0, 1, 0, 1, 0],
                [0, 0, 1, 0, 0],
            ]
        )[None, None]
        / 18
    )
    aligned = pack(F.conv2d(F.pad(native, (2, 2, 2, 2), mode="reflect"), kernel))
    return torch.where(colors[:, :, None, None] == 1, aligned, standard(innovation))


def lift(head, parent, args, guard, *, mixing=phase_average):
    packed, variance, colors, wb, matrix = args
    sigma = variance.clamp_min(1e-10).sqrt()
    average = sigma.mean(dim=1, keepdim=True)
    guide = F.avg_pool2d(head.scene_luma(parent, wb, matrix), 2)
    middle = F.avg_pool2d(guide, 17, stride=1, padding=8, count_include_pad=False)
    contrast = guide - middle
    innovation = (packed - mosaic(parent, colors)) / sigma
    selected = mixing(innovation, colors).clamp(-12, 12)
    codes = 0.5 * colors[:, :, None, None].to(packed.dtype).expand_as(packed)
    features = torch.cat(
        (
            selected,
            sigma.log().clamp(-12, 0) / 8,
            codes,
            (middle.clamp_min(0) + 1e-4).log().clamp(-10, 1) / 4,
            (contrast / average).clamp(-12, 12),
        ),
        dim=1,
    )
    prediction = head.output(head.blocks(F.silu(head.stem(features))))
    detail, confidence = F.pixel_shuffle(prediction, 2).split(1, dim=1)
    scale = 0.5 * F.interpolate(average, scale_factor=2, mode="nearest")
    clip = (packed >= 0.98).any(dim=1, keepdim=True).to(packed.dtype)
    quiet = 1 - F.max_pool2d(clip, 7, stride=1, padding=3)
    return (
        fine_band(detail.tanh() * confidence.sigmoid() * scale)
        * F.interpolate(quiet, scale_factor=2, mode="nearest")
        * guard
    )
