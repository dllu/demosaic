"""Check native Bayer geometry, color isolation and matched interior noise."""
from pathlib import Path
import math
import torch
from demosaic.cfa import PATTERNS, pack
from demosaic.experiments.artifacts import reference, write_json
from phase_innovation import phase_average, standard

torch.set_num_threads(2)
rng=torch.Generator().manual_seed(245214)
idx=torch.tensor(list(PATTERNS.values()))
white=torch.randn(4,4,256,256,generator=rng)
field=phase_average(white,idx)
controls=standard(white)
rgb=(idx!=1)[:,:,None,None].expand_as(white)
assert torch.equal(field[rgb],controls[rgb])
mask=(idx==1)[:,:,None,None].expand_as(white[...,8:-8,8:-8])
typical=float(field[...,8:-8,8:-8][mask].var())
baseline=float(controls[...,8:-8,8:-8][mask].var())
assert abs(typical-1/3)<.004 and abs(baseline-1/3)<.004
x=torch.arange(512,dtype=torch.float32)
plane=torch.cos(2 * math.pi * .2 * x)
samples=pack(plane[None,None,None,:].expand(4,1,512,512))
before=samples[...,8:-8,8:-8][mask]
def gain(result):
    return float((result[...,8:-8,8:-8][mask]*before).sum()/before.square().sum())
expected_same=5/9+(2+6*math.cos(2*.4*math.pi))/18
# Four same-phase axial and four opposite-phase diagonal one-step neighbors.
expected_native=5/9+(2+2*math.cos(2*.4*math.pi)+4*math.cos(.4*math.pi))/18
observed=gain(phase_average(samples,idx))
control=gain(standard(samples))
assert abs(control-expected_same)<3e-4 and abs(observed-expected_native)<3e-4
root=Path(__file__).resolve().parent
write_json(root/"physical-checks.json",{
    "driver":reference(__file__),"all_Bayer_orders":list(PATTERNS),
    "green_corrected_variance":typical,"same_phase_variance":baseline,
    "cross_phase_0p2cpx_gain":observed,"same_phase_0p2cpx_gain":control,
    "R_B_values_bit_identical":True,
})
print(typical,baseline,observed,control)
