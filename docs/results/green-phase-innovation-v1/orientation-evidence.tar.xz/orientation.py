"""Check delivered responses in fine bins favored by the two raw filters."""

import numpy as np
import torch

from score import (
    ROOT,
    BANDS,
    as_cuda,
    channel_coefficients,
    fields,
    load_models,
    measure,
    proposals,
)
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from strength_moments import value


def masks():
    frequencies = np.pi * np.arange(16) / 16
    u, v = np.meshgrid(frequencies, frequencies)
    old = 0.5 + (1 + 2 * np.cos(2 * u)) * (1 + 2 * np.cos(2 * v)) / 18
    new = (10 + 2 * np.cos(2 * u) + 2 * np.cos(2 * v) + 4 * np.cos(u) * np.cos(v)) / 18
    favor = new - old
    base = BANDS["fine"]
    return {
        "higher-native-transfer": base & (favor > 0.02),
        "lower-native-transfer": base & (favor < -0.02),
        "compatible-transfer": base & (np.abs(favor) <= 0.02),
    }


def compare(rows, scales):
    rng = np.random.default_rng(971244)
    pairs = [[value(r[k], scales[k]) for k in ("bayer", "same")] for r in rows]
    index = rng.integers(len(rows), size=(5000, len(rows)))
    delta = np.array([a["aligned_dot"] - b["aligned_dot"] for a, b in pairs])
    power = np.array([a["target_power"] for a, b in pairs])
    result = {
        "response_pp": [
            float(100 * delta.sum() / power.sum()),
            *np.quantile(100 * delta[index].sum(1) / power[index].sum(1), [0.025, 0.975]).tolist(),
        ]
    }
    for key in ("increment_DN16", "flat_DN16", "variance_DN16_squared"):
        differences = np.array([a[key] - b[key] for a, b in pairs])
        result[key] = [
            float(differences.mean()),
            *np.quantile(differences[index].mean(1), [0.025, 0.975]).tolist(),
        ]
    return result


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    stamp = reference(ROOT / "result.json")
    numbers = read_json(checked(stamp))
    plan = read_json(checked(numbers["plan"]))
    baseline = read_json(checked(plan["fixed"]))
    parent = read_json(checked(baseline["parents"]))
    data = read_json(checked(parent["observations"]))
    cover = read_json(checked(data["plan"]))
    recipe = read_json(checked(baseline["recipe"]))
    head, _, _ = load_models("fixed", recipe)
    limits = (
        read_json(checked(recipe["guard"]))["threshold"],
        read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0],
    )
    predictions = {r["id"]: r["saved"] for r in parent["rows"]}
    bands = masks()
    rows = {f: {label: [] for label in bands} for f in ("natural", "same-edge")}
    with ieee_fp32():
        for case in data["cases"]:
            if case["profile"]["name"] != "iso6400" or case["index"] not in plan["test"]:
                continue
            inputs = fields(case)
            with np.load(checked(predictions[case["id"]]), allow_pickle=False) as archive:
                current = archive["100k"]
            args = as_cuda({k: v.reshape((-1, *v.shape[2:])) for k, v in inputs.items()})
            tensor = (
                torch.from_numpy(current.reshape(6, 3, 256, 256))
                .cuda()
                .contiguous(memory_format=torch.channels_last)
            )
            base, same, bayer = proposals(head, tensor, args, limits)

            def coeffs(field):
                if isinstance(field, torch.Tensor):
                    field = field.cpu().numpy().reshape(current.shape)
                return np.stack(
                    [
                        channel_coefficients(
                            field[r],
                            {k: inputs[k][r] for k in ("wb", "matrix")},
                            cover["score_ROI_xywh"],
                        )[1]
                        for r in range(2)
                    ]
                )

            q = coeffs(base)
            target = coeffs(inputs["target"])[0]
            alternate = {
                key: coeffs(base + step) - q for key, step in (("same", same), ("bayer", bayer))
            }
            for label, mask in bands.items():
                rows[case["style"]][label].append(
                    {key: measure(q, override, target, mask) for key, override in alternate.items()}
                )
    assert all(len(r) == 24 for group in rows.values() for r in group.values())
    summary = {
        style: {
            label: compare(items, numbers["metrics"]["iso6400"]["scales"])
            for label, items in groups.items()
        }
        for style, groups in rows.items()
    }
    write_json(
        ROOT / "orientation.json",
        {
            "base": stamp,
            "driver": reference(__file__),
            "band_counts": {k: int(v.sum()) for k, v in bands.items()},
            "metric": summary,
            "scope": "Use analytic half-plane transfer difference above or below 0.02 to stratify the native fine DCT band. One global matched-response operating point from the original experiment applies to each bin set. The split is based on filter coefficients with no use of image metrics.",
        },
    )


if __name__ == "__main__":
    run()
