"""Resample the matched contributing photos for all recorded contrast cells."""
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
MEASURES=("GT_projected_gain","band_error_RMS","orthogonal_band_RMS")
SEED=1325404733
DRAWS=20000

def review(path):
    rows=read_json(path)
    cells=defaultdict(dict)
    for row in rows:
        key=(row["condition"],row["bin"],row["method"])
        assert row["source_id"] not in cells[key]
        cells[key][row["source_id"]]=row
    rng=np.random.default_rng(SEED)
    table=[]
    for condition,bin_id,_ in sorted(k for k in cells if k[-1]=="first"):
        a,b=[cells[condition,bin_id,m]for m in ("first","second")]
        assert a.keys()==b.keys()
        ids=sorted(a)
        samples=rng.integers(len(ids),size=(DRAWS,len(ids)))
        effects=[]
        for label in MEASURES:
            rows_a=np.array([a[i][label]for i in ids])
            rows_b=np.array([b[i][label]for i in ids])
            scale=100 if label=="GT_projected_gain"else 65535
            delta=scale*(rows_b-rows_a)
            q=np.quantile(delta[samples].mean(1),[.025,.975])
            effects.append({"metric":label,"unit":"percentage points"if scale==100 else "DN16",
                            "first":float(rows_a.mean()*scale),"second":float(rows_b.mean()*scale),
                            "mean_difference":float(delta.mean()),"interval_95":q.tolist(),
                            "sources_second_smaller":int((delta<0).sum())})
        table.append({"condition":condition,"bin":bin_id,"sources":len(ids),"effects":effects})
    assert len(table)==15
    return table

def main():
    comparisons={}
    for comparator,folder in (("V120","detail-v120"),("20k","detail-20k")):
        source=ROOT/folder/"per-source-v1.json"
        comparisons[comparator]={"source":reference(source),"estimates":review(source)}
    write_json(ROOT/"source-intervals.json",{
        "driver":reference(__file__),"unit":"whole photo including all valid CFA/crop blocks",
        "resamples":DRAWS,"seed":SEED,"estimates":comparisons})

if __name__=="__main__":
    main()
