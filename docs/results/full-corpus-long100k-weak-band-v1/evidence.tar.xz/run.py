"""Run existing canonical pixel and weak-band diagnostics for Corpus 100k."""
import os
from pathlib import Path

import psutil

from audit_local_primary import audit
from diagnose_archive_local_detail import analyze
from export_local_primary_archive import export
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PRIMARY=Path("docs/results/full-corpus-long100k-primary-v1/primary.json").resolve()
OLDER=ROOT.parent/"full-corpus-control20k-analysis-queue-v1/native-photo-archive/records.jsonl"

def run():
    result=read_json(PRIMARY)
    assert result["all_complete"] and result["photo_sources"]==427
    bind=checked(result["source_result"])
    source={name:art["checkpoint"]["sha256"]for name,art in result["models"].items()}
    short="633053370bdfb455d738ce0e3af686cb61e8dcac7c501954eb3b2293738a3795"
    owner={"pid":os.getpid(),"created":psutil.Process().create_time()}
    write_json(ROOT/"launch.json",owner|{
        "driver":reference(__file__),"primary":reference(PRIMARY),"combined":result["source_result"],
        "short_native_manifest":reference(OLDER),"scope":"Existing exact canonical pixel/weak-band procedures; no new neural outputs.",
    })
    def status(name):
        print(name,flush=True)
        write_json(ROOT/"status.json",owner|{"stage":name},replace=True)
    status("independent pixel audit")
    audit(bind,ROOT/"audit")
    status("native archive")
    export(bind,ROOT/"native")
    path=ROOT/"native/records.jsonl"
    status("427-photo weak-band vs V120")
    analyze(path,source["V120"],path,source["scale-long100k"],ROOT/"detail-v120",maximum_seconds=1800)
    status("427-photo weak-band vs Corpus 20k")
    analyze(OLDER,short,path,source["scale-long100k"],ROOT/"detail-20k",maximum_seconds=1800)
    endpoints={key:reference(ROOT/key/"result-v1.json") for key in ("detail-v120","detail-20k")}
    for b in endpoints.values():
        result=read_json(checked(b))
        assert result["photographic_sources"]==427 and result["paired_source_noise_CFA_observations"]==5124
    write_json(ROOT/"result.json",{
        "launch":reference(ROOT/"launch.json"),"audit":reference(ROOT/"audit/result.json"),
        "native":reference(ROOT/"native/result.json"),"weak_band":endpoints
    })
    status("complete")

if __name__=="__main__":
    run()
