"""Resume the bound audits after the saved-output reader accepts declared horizons."""
import argparse
import os
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from diagnose_archive_local_detail import analyze

ROOT=Path(__file__).resolve().parent

def run(label):
    archive=read_json(ROOT/"native/result.json")
    assert archive["records"]==6216 and archive["all_records_verified_with_existing_reader"]
    current=checked(archive["manifest"])
    if label=="V120":
        first_manifest=current
        first_sha=archive["models"]["V120"]["checkpoint"]["sha256"]
        dest=ROOT/"detail-v120"
    else:
        first_manifest=checked(read_json(ROOT/"launch.json")["short_native_manifest"])
        first_sha="633053370bdfb455d738ce0e3af686cb61e8dcac7c501954eb3b2293738a3795"
        dest=ROOT/"detail-20k"
    args=(first_manifest,first_sha,current,archive["models"]["scale-long100k"]["checkpoint"]["sha256"])
    checker=Path("scripts/diagnose_archive_local_detail.py").resolve()
    write_json(ROOT/f"band-{label}-launch.json",{"pid":os.getpid(),"created":psutil.Process().create_time(),
         "driver":reference(__file__),"audit_implementation":reference(checker),
         "completed_native_archive":reference(ROOT/"native/result.json"),
         "original_attempt":reference(ROOT/"run.log"),"comparison":label,"steps":[20000,100000]})
    result=analyze(*args,dest,first_step=20000,second_step=100000,maximum_seconds=1800)
    assert result["photographic_sources"]==427 and result["paired_source_noise_CFA_observations"]==5124
    write_json(ROOT/f"band-{label}-complete.json",{
        "launch":reference(ROOT/f"band-{label}-launch.json"),
        "detail":reference(dest/"result-v1.json"),"audit":reference(ROOT/"audit/result.json")
    })
    print(label,result["photographic_sources"],result["paired_source_noise_CFA_observations"],result["seconds"],flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("which",choices=("V120","20k"))
    run(p.parse_args().which)
