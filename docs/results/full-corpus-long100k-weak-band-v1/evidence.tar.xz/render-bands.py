"""Show exact native crops selected from the fixed weakest-band results."""
import json
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from diagnose_local_material_detail import basis,blocks,luminance
from report_scene_wave_guides import native_board

HERE=Path(__file__).resolve().parent
DETAIL=HERE/"detail-v120"
PRIMARY=Path("docs/results/full-corpus-long100k-primary-v1/primary.json").resolve()
ARGS=("packed","variance","colors","wb","matrix")
CFA="RGGB"

def observations():
    rows=read_json(DETAIL/"per-source-v1.json")
    inputs=read_json(DETAIL/"selected-inputs-v1.json")
    for prior,increasing in (("iso100-prior",True),("iso12800-prior",False)):
        by={role:{r["source_id"]:r for r in rows if (r["condition"],r["bin"],r["method"])==(prior,0,role)}
            for role in ("first","second")}
        assert len(by["first"])==len(by["second"])==326 and by["first"].keys()==by["second"].keys()
        def gain(id_):
            return by["first"][id_]["band_error_RMS"]-by["second"][id_]["band_error_RMS"]
        mode=max if increasing else min
        selected=mode(by["first"],key=gain)
        pair,=[r for r in inputs if selected in r["context"]["ids"] and
               r["context"]["pattern"]==CFA and r["context"]["condition"]["name"]==prior]
        yield prior,selected,pair,gain(selected),increasing

def main():
    primary=read_json(PRIMARY)
    canonical=read_json(checked(primary["canonical_inputs"]))
    exporter=read_json(checked(canonical["plan"]))
    binding=next(b for b in exporter["inputs"]if b["path"].endswith("common-8192-44732-val-v1.jsonl"))
    images={r["id"]:r for line in checked(binding).read_text().splitlines()if line for r in [json.loads(line)]}
    strata=DETAIL/"GT-strata-v1.npz"
    with np.load(strata,allow_pickle=False) as f:
        gt={k:f[k]for k in ("source_ids","eligible","bins")}
    model=primary["models"]["scale-long100k"]["checkpoint"]
    initial=primary["models"]["V120"]["checkpoint"]
    dct=basis(16)
    radius=np.hypot(np.arange(16)[:,None]/32,np.arange(16)[None,:]/32)
    band=(radius>=1/8)&(radius<1/3)
    output=HERE/"native-weakest";output.mkdir()
    views=[]
    for prior,source,pair,gain,increasing in observations():
        index=pair["context"]["ids"].index(source)
        assert pair["first"]["supervision"]["sha256"]==pair["second"]["supervision"]["sha256"]
        with np.load(checked(pair["first"]["supervision"]),allow_pickle=False)as item:
            args={k:item[k][index:index+1]for k in ARGS}
            target=item["target"][index]
        predictions=[np.load(checked(pair[k]["prediction"]),allow_pickle=False)[index]
                     for k in ("first","second")]
        def coeffs(rgb):
            frame=blocks(luminance(rgb[None],args)[1])
            return (dct@frame@dct.T)[:,band]
        exact=coeffs(target)
        old,new=[65535*np.sqrt(np.mean((coeffs(p)-exact)**2,axis=1))for p in predictions]
        who,=np.flatnonzero(gt["source_ids"]==source)
        eligible=np.flatnonzero(gt["eligible"][who]&(gt["bins"][who]==0))
        sort=np.argmax if increasing else np.argmin
        block=int(eligible[sort((old-new)[eligible])])
        y,x=[8+16*v for v in divmod(block,15)]
        roi=(max(0,min(96,x+8-80)),max(0,min(96,y+8-80)),160,160)
        views.append(native_board(output,f"{source[:12]}-{prior}",
            [noisy_malvar(args)[0],*predictions,target],args,{
                "source_photo":images[source],"photo_manifest":binding,"noise":pair["context"]["condition"],"CFA":CFA,
                "chosen_weak_band_block_xywh":[x,y,16,16],"ROI_xywh":roi,
                "selection":"Largest weak-band source improvement"if increasing else "Largest weak-band source regression",
                "source_average_RMS_improvement_DN16":65535*gain,
                "block_band_error_RMS_DN16":[float(old[block]),float(new[block])],
                "predictions":pair,"checkpoint":model,"V120":initial,"weights":"EMA",
            },labels=("Noisy Malvar","V120 EMA","Corpus 100k EMA","Exact GT"),
              triplet_indices=(0,2,3),exposure=1,contrast=2,roi=roi))
    write_json(output/"result.json",{"driver":reference(__file__),"detail":reference(DETAIL/"result-v1.json"),"views":views})

if __name__=="__main__":
    main()
