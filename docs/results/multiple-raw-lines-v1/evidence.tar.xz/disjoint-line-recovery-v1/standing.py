"""Replay the fixed exterior-line proposal on the protected native boards."""

import os
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from recover import external_guide, supported_correction
from report_fold_support_pooling import insert_camera_panels

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "scene-context-native-review-v2"
SAVED = PREVIOUS / "render-all-v1/result.json"
OUT = ROOT / "standing"


def pixel(value, arrays, roi, display):
    rgb = display_crop(
        torch.from_numpy(value[None]),
        torch.from_numpy(arrays["wb"]),
        torch.from_numpy(arrays["matrix"]),
        roi,
        exposure=display,
    )
    return np.rint(rgb.clip(0, 1) * 255).astype(np.uint8)


def window(array, box, *, phase=1):
    x, y, w, h = (n // phase for n in box)
    return array[..., y : y + h, x : x + w]


@torch.inference_mode()
def main():
    os.sched_setaffinity(0, [12, 13])
    os.nice(12)
    torch.set_num_threads(2)
    original = read_json(SAVED)
    plan_path = checked(original["plan"])
    plan = read_json(plan_path)
    src = PREVIOUS / "none/collection.json"
    base = read_json(src)
    assert base["plan"] == original["plan"]
    snapshots = {row["id"]: row for row in base["records"]}
    kind = {row["id"]: row for row in plan["observations"]}
    OUT.mkdir()
    rows = []
    for row in original["boards"]:
        key = row["observation"]
        obs = kind[key]
        if obs["kind"] not in ("gfx", "mesh"):
            continue
        found = snapshots[key]
        with np.load(checked(obs["arrays"]), allow_pickle=False) as content:
            arrays = {k: content[k] for k in ("packed", "colors", "wb", "matrix", "variance")}
        assert {k: fingerprint(v) for k, v in arrays.items()} == found["input_fingerprints"]
        predicted = np.load(checked(found["prediction"]), allow_pickle=False)[0]
        x, y, w, h = row["case"]["ROI_xywh"]
        box = ((x - 48) // 2 * 2, (y - 48) // 2 * 2, 256, 256)
        assert box[0] >= 0 and box[1] >= 0
        assert box[0] + 256 <= predicted.shape[-1] and box[1] + 256 <= predicted.shape[-2]
        p = window(predicted, box)
        region = (x - box[0], y - box[1], w, h)
        guide = external_guide(arrays["packed"][0], arrays["variance"][0], arrays["colors"][0], box)
        fixes = {}
        changes = {}
        details = {}
        for name, segment in (("Whole guide fit", None), ("64px supported fit", 64)):
            prediction, evidence = supported_correction(
                p,
                window(arrays["packed"][0], box, phase=2),
                window(arrays["variance"][0], box, phase=2),
                arrays["colors"][0],
                box[:2],
                guide,
                segment=segment,
            )
            fixes[name] = pixel(prediction, arrays, region, row["display_exposure"])
            error = window(prediction.astype(float) - p, region) * 65535
            changes[name] = {
                "RMS_DN16": float(np.sqrt((error**2).mean())),
                "peak_DN16": float(np.abs(error).max()),
                "exact": bool(np.array_equal(prediction, p)),
            }
            details[name] = evidence
        control = pixel(p, arrays, region, row["display_exposure"])
        panel = next(a for a in row["panels"] if a["label"] == "Local-only2k")
        px, py, _, _ = panel["png_xywh"]
        with Image.open(checked(row["image"])) as old:
            np.testing.assert_array_equal(np.asarray(old.crop((px, py, px + w, py + h))), control)
        subset = {
            **row,
            "panels": [
                cell for cell in row["panels"] if cell["label"] not in ("Pooled2k", "Spatial2k")
            ],
        }
        image, panels = insert_camera_panels(
            OUT, row["id"], subset, "Local-only2k", list(fixes.items())
        )
        rows.append(
            {
                "id": row["id"],
                "source_board": row,
                "image": image,
                "panels": panels,
                "native_query": box,
                "native_ROI": row["case"]["ROI_xywh"],
                "display_exposure": row["display_exposure"],
                "noise": obs["noise"],
                "parent_checkpoint": base["checkpoint"],
                "parent": found["prediction"],
                "exterior_guide": asdict(guide) if guide is not None else None,
                "changes": changes,
                "evidence": details,
            }
        )
    assert len(rows) == 8
    write_json(
        OUT / "result.json",
        {
            "source": reference(__file__),
            "method": reference(ROOT / "recover.py"),
            "native_input_plan": reference(plan_path),
            "existing_boards": reference(SAVED),
            "results": rows,
            "native_viewing_complete": False,
            "scope": "Use original fixed 512px or 768px archived RAW context outside the 256px query. Composed on the archived local-only scene checkpoint. Reference crops and JPEGs retain their established qualitative roles.",
        },
    )
    print([(v["id"], v["exterior_guide"] is not None, v["changes"]) for v in rows])


if __name__ == "__main__":
    main()
