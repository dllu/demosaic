"""Bind the compact two-trial evidence and selected native panels."""

import json
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REPO = Path.cwd()
ROOT = Path(__file__).resolve().parent
FRESH = ROOT.parent / "multiline-raw-shoulders-v1"
REVIEW = ROOT / "report/result.json"
BUNDLES = {"initial": ROOT, "fresh": FRESH}
DEST = REPO / "docs/results/multiple-raw-lines-v1"
IMAGES = REPO / "docs/images/multiple-raw-lines-v1"
SELECTED = {
    "initial": ("iso400-parallel-g37-r0", "iso400-crossing-g43-r0",
                "iso400-edge-aligned-g37-r0", "iso6400-crossing-g43-r0"),
    "fresh": ("iso400-parallel-g51-r0", "iso400-crossing-g55-r0",
              "iso400-edge-aligned-g55-r0", "iso6400-crossing-g55-r0"),
}


def portable(path):
    r = reference(path)
    return r | {"path": str(path.relative_to(REPO))}


def install_image(link, dest):
    src = checked(link)
    output = dest / src.name
    shutil.copyfile(src, output)
    actual = portable(output)
    assert actual["sha256"] == link["sha256"]
    return actual


def main():
    report = read_json(REVIEW)
    dest = DEST
    dest.mkdir(exist_ok=True)
    files = [
        REVIEW, ROOT / "mask-check.json", ROOT / "report.py", Path(__file__),
        ROOT / "mask-check.py", ROOT.parent / "scene-wire-gap-v1/probe.py",
        ROOT.parent / "disjoint-line-recovery-v1/standing.py",
        REPO / "src/demosaic/isolated_line.py",
        REPO / "scripts/report_scene_wave_guides.py",
        REPO / "scripts/report_fold_support_pooling.py",
    ]
    published = {}
    for name, place in BUNDLES.items():
        stage = report["trials"][name]
        output = IMAGES / name
        output.mkdir(parents=True, exist_ok=True)
        cases = read_json(checked(stage["source"]))
        files.extend(checked(row) for row in cases["records"])
        files.extend(place / p for p in ("plan.json", "result.json", "proposals.py", "run.py",
                                         "standing.py", "run.log", "standing.log"))
        fixed = checked(report["standing"][name])
        files.append(fixed)
        images = []
        for row in stage["boards"]:
            if row["id"] in SELECTED[name]:
                images.append({
                    **row, "board": row["board"] | {"image": install_image(row["board"]["image"], output)},
                    "triplet": row["triplet"] | {"image": install_image(row["triplet"]["image"], output)},
                })
        assert len(images) == 4
        camera = []
        standing_path = output / "standing"
        standing_path.mkdir(exist_ok=True)
        for row in read_json(fixed)["results"]:
            pick = {k: row[k] for k in ("id", "panels", "native_query", "native_ROI", "display_exposure",
                                       "noise", "parent_checkpoint", "ROI_added_RMS_DN16",
                                       "ROI_peak_DN16", "identical_display_pixels")}
            camera.append(pick | {"guide_count": len(row["guides"]),
                                  "image": install_image(row["image"], standing_path)})
        assert len(camera) == 8
        published[name] = {"synthetic_panels": images, "standing_panels": camera,
                           "scores": stage["scores"], "synthetic_seconds": stage["seconds"]}
    files.append(FRESH / "shoulders.py")
    files = sorted(set(files))
    assert all(p.is_file() for p in files)
    archive = dest / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as handle:
        for path in files:
            handle.add(path, arcname=str(path.relative_to(REPO)).removeprefix(".cache/experiments/"))
    refs = {str(p.relative_to(REPO)).removeprefix(".cache/experiments/"): reference(p)["sha256"] for p in files}
    with tarfile.open(archive, "r:xz") as handle:
        import hashlib

        assert set(handle.getnames()) == set(refs)
        for member in handle.getmembers():
            with handle.extractfile(member) as reader:
                assert hashlib.file_digest(reader, "sha256").hexdigest() == refs[member.name]
    write_json(dest / "publication.json", {
        "study": "Disjoint Bayer surround proposals for multiple straight lines",
        "trials": published, "evidence": portable(archive), "archive_members_sha256": refs,
        "native_viewed": {
            name: {
                "synthetic_boards": list(SELECTED[name]),
                "standing_views": [r["id"] for r in published[name]["standing_panels"]],
            } for name in BUNDLES
        },
        "scope": "Fixed scoped component experiment on two disjoint exact-reference panels and two archived GFX captures. No model training or comparable primary panel.",
    })


if __name__ == "__main__":
    main()
