"""Check source bindings and render native exact-reference line comparisons."""

import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board

ROOT = Path(__file__).resolve().parent
RUNS = {"initial": ROOT, "fresh": ROOT.parent / "multiline-raw-shoulders-v1"}


def check_retained(r, arrays, method, arm):
    roi = np.s_[..., 48:208, 48:208]
    predicted = arrays[method].astype(np.float64)[roi]
    parent = arrays["parent"].astype(np.float64)[roi]
    detail = arrays["detail"].astype(np.float64)[roi]
    corr = predicted - parent
    diff = predicted[1] - predicted[0]
    masks = arrays["isolated"][roi] & arrays["clean"][roi]
    q = masks & (np.abs(detail).max(axis=1) > 1e-7)
    response = [np.dot(diff[:, x].ravel(), d[:, x].ravel()) / np.linalg.norm(d[:, x])**2
                for d, x in zip(detail, q, strict=True)]
    errors = [65535 * np.linalg.norm((diff-d)[:, x])/np.sqrt(diff[:, x].size)
              for d, x in zip(detail, q, strict=True)]
    record = r["measurements"][arm]
    np.testing.assert_allclose(response, record["response"], rtol=2e-6, atol=2e-8)
    np.testing.assert_allclose(errors, record["increment_error_DN16"], rtol=2e-6, atol=2e-8)
    assert record["changed"] == [bool((d != 0).any()) for d in corr]


def reduce_cases(cases, arm):
    rows = [r["measurements"][arm] for r in cases]
    response = [100 * mean(r["response"][i] for r in rows) for i in (0, 1)]
    error = [mean(r["increment_error_DN16"][i] for r in rows) for i in (0, 1)]
    geometry_hits = [sum(any(theta <= 1 and offset <= 2 for theta, offset in
                            row.get("geometry_error_angle_and_offset_px", [[], [], []])[i])
                         for row in rows) for i in (0, 1, 2)]
    error_names = ("absent_added_RMS_DN16", "true_gap_added_RMS_DN16", "third_guide_added_RMS_DN16")
    return {
        "cases": len(cases),
        "outer_proposals_mean": mean(len(r.get("guides", [])) for r in rows),
        "geometry_hits_within_1deg_2px": geometry_hits,
        "weak_response_percent": response,
        "increment_error_DN16": error,
        "changed_roles": [sum(row["changed"][i] for row in rows) for i in (0, 1)],
        "mean_error": {key: mean(r[key] for r in rows) for key in error_names},
        "worst_error": {key: max(r[key] for r in rows) for key in error_names},
        "both_lines_improve": sum(all(out < p for out, p in zip(
            data["increment_error_DN16"], case["measurements"]["parent"]["increment_error_DN16"], strict=True
        )) for data, case in zip(rows, cases, strict=True)),
    }


def main(names):
    selected = {name: RUNS[name] for name in names} if names else RUNS
    report = ROOT / "report"
    report.mkdir(exist_ok=True)
    batches = {}
    for name, root in selected.items():
        result_path = root / "result.json"
        result = read_json(result_path)
        plan = read_json(checked(result["plan"]))
        for key in ("runner", "detector", "geometry_source", "local_correction", "checkpoint"):
            checked(plan[key])
        cases = [read_json(checked(link)) for link in result["records"]]
        assert len(cases) == (96 if name == "initial" else 48) == len({r["id"] for r in cases})
        buckets = defaultdict(list)
        boards = []
        out = report / name
        out.mkdir(exist_ok=True)
        for r in cases:
            checks = [("parent", "parent"), ("multiple", "matched")]
            if name == "fresh":
                checks.append(("shoulders", "shoulders"))
            buckets[r["profile"], r["layout"]].append(r)
            if r["retained"] is None:
                continue
            with np.load(checked(r["retained"]), allow_pickle=False) as f:
                arrays = dict(f)
            assert r["fingerprints"] == {k: fingerprint(arrays[k]) for k in r["fingerprints"]}
            for method, arm in checks:
                check_retained(r, arrays, method, arm)
            local = {k: arrays[k][1:2] for k in ("packed", "colors", "wb", "matrix")}
            labels = ["Noisy Malvar", "Local-only trunk", "Multi-line Bayer fit"]
            if name == "fresh":
                labels.append("RAW shoulder check")
            labels.append("Exact GT")
            values = [noisy_malvar(local)[0], *[arrays[m][1] for m, _ in checks], arrays["target"][1]]
            boards.append(native_board(
                out, r["id"], values, local,
                {"case":r["id"], "sensor_seed":r["seed"], "noise":plan["profile"][r["profile"]],
                 "color_indices":arrays["colors"][0].tolist(), "checkpoint":plan["checkpoint"],
                 "source":r["retained"]},
                labels=labels, triplet_indices=(0, len(values)-2, len(values)-1), exposure=1, contrast=8,
            ))
        assert len(buckets) == 6 and len(boards) == 12
        batches[name] = {
            "source": reference(result_path), "boards":boards, "seconds":result["seconds"],
            "scores": [
                {"profile":profile, "layout":layout, "method":method, **reduce_cases(group, method)}
                for (profile, layout), group in sorted(buckets.items())
                for method in group[0]["measurements"]
            ],
        }
    standing = {}
    for name, p in selected.items():
        path = p / "standing/result.json"
        rows = read_json(path)["results"]
        assert len(rows) == 8
        for r in rows:
            checked(r["image"])
            checked(r["source_board"]["image"])
        standing[name] = reference(path)
    result_name = ("-".join(names) + ".json") if names else "result.json"
    write_json(report / result_name, {
        "driver": reference(__file__), "trials": batches, "standing": standing,
    })


if __name__ == "__main__":
    main(sys.argv[1:])
