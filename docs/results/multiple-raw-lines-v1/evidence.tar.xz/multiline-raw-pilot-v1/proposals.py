"""Two-sided line proposals from a masked Bayer surround."""

import math

import numpy as np
from scipy.ndimage import gaussian_filter, maximum_filter
from scipy.optimize import minimize

from demosaic.isolated_line import (
    Guide,
    coordinates,
    fit,
    gaussian_profile,
    keep_local_support,
    native_sites,
    supported_correction,
)

ANGLE_STEP = 0.75
BIN = 1.5
LIMIT = 148


def band_measurement(scene, variance, box):
    x, y = coordinates(*scene.shape[-2:], phase=True)
    left, top, width, height = box
    cx, cy = left + (width - 1) / 2, top + (height - 1) / 2
    x, y = x + 0.5 - cx, y + 0.5 - cy
    exterior = (np.abs(x) >= width / 2 + 31) | (np.abs(y) >= height / 2 + 31)
    outside = np.where(exterior, scene, 0)

    def smooth(radius):
        visible = gaussian_filter(exterior.astype(np.float32), radius)
        filtered = gaussian_filter(outside, (0, radius, radius))
        return filtered / np.maximum(visible, 1e-9)

    band = (smooth(0.82) - smooth(3.25)) / (0.32 * np.sqrt(np.maximum(variance, 1e-12)))
    return x, y, exterior, band, np.array([cx, cy])


def line_bank(x, y, signal, angles):
    counts = 2 * math.ceil(LIMIT / BIN) + 1
    middle = counts // 2
    scores = np.zeros((len(angles), counts, 3), dtype=np.float32)
    for i, angle in enumerate(angles):
        a, b = np.cos(angle), np.sin(angle)
        bins = np.rint((a * x + b * y) / BIN).astype(np.int32) + middle
        on_strip = (bins >= 0) & (bins < counts)
        track = np.where(-b * x[on_strip] + a * y[on_strip] >= 0, counts, 0)
        ids = bins[on_strip] + track
        population = np.bincount(ids, minlength=2 * counts).reshape(2, counts)
        scale = np.sqrt(np.maximum(12, population))
        for color in range(3):
            totals = np.bincount(ids, weights=signal[color, on_strip], minlength=2 * counts)
            low, high = totals.reshape(2, counts) / scale
            scores[i, :, color] = np.where(low * high > 0, np.minimum(np.abs(low), np.abs(high)), 0)
        scores[i, population.min(axis=0) < 24] = 0
    return scores


def refine_location(x, y, signal, angle, offset, color):
    a, b = np.cos(angle), np.sin(angle)
    near = np.abs(a * x + b * y - offset) < 7
    xx, yy, value = x[near], y[near], signal[color, near]
    side = -b * xx + a * yy >= 0

    def objective(z):
        a, b = np.cos(angle + z[0] / 260), np.sin(angle + z[0] / 260)
        profile = gaussian_profile(a * xx + b * yy - offset - z[1], 1.05)
        totals = np.bincount(side, weights=profile * value, minlength=2)
        size = np.sqrt(np.maximum(1, np.bincount(side, weights=profile**2, minlength=2)))
        score = totals / size
        return -float(min(abs(score))) if score[0] * score[1] > 0 else 0

    start = np.zeros(2)
    result = minimize(objective, start, bounds=[(-2, 2), (-1.6, 1.6)], method="Powell")
    delta = result.x if result.fun < objective(start) else start
    return angle + delta[0] / 260, offset + delta[1]


def color_estimate(scene, variance, colors, exterior, x, y, normal, offset):
    d = normal[0] * x + normal[1] * y - offset
    t = -normal[1] * x + normal[0] * y
    plane = np.asarray(colors)[:, None, None]
    coefficients, errors = [], []
    for sign in (-1, 1):
        values, std = [], []
        for c in range(3):
            keep = (plane == c) & exterior[None] & (np.abs(d) < 9) & (sign * t > 80)
            if keep.sum() < 36:
                return None
            design = np.column_stack([
                np.ones(keep.sum()), d[keep] / 9, t[keep] / 256, gaussian_profile(d[keep], 2.8),
            ])
            v, e = fit(design, scene[keep], variance[keep])
            values.append(v[-1])
            std.append(e[-1])
        coefficients.append(values)
        errors.append(std)
    values, errors = np.asarray(coefficients), np.asarray(errors)
    joined = np.sum(values / errors**2, axis=0) / np.sum(1 / errors**2, axis=0)
    norm = np.linalg.norm(joined)
    if not norm or np.any(values @ joined <= 0):
        return None
    strength = min((values / errors) @ (joined / norm))
    if strength < 6:
        return None
    return joined / norm, strength, int(np.count_nonzero(exterior[None] & (np.abs(d) < 3)))


def external_proposals(scene, variance, colors, box, *, min_z=8, limit=8):
    x, y, exterior, band, center = band_measurement(scene, variance, box)
    x, y = x[exterior].astype(np.float32), y[exterior].astype(np.float32)
    # Average the two measured greens in the exterior accumulator, then fit
    # RGB amplitudes at actual CFA coordinates for each selected section.
    signals = np.asarray([band[np.asarray(colors) == c].mean(0)[exterior].clip(-24, 24)
                          for c in range(3)])
    angles = np.deg2rad(np.arange(0, 180, ANGLE_STEP)).astype(np.float32)
    scores = line_bank(x, y, signals, angles)
    strength = scores.max(2)
    peaks = np.argwhere((strength >= min_z) & (strength == maximum_filter(strength, size=(5, 5))))
    xn, yn = native_sites(scene.shape[-2:], -center)
    guides = []
    for i, j in sorted(peaks, key=lambda ij: -strength[tuple(ij)]):
        if len(guides) >= limit:
            break
        color = int(np.argmax(scores[i, j]))
        angle, offset = refine_location(
            x, y, signals, angles[i], (j - strength.shape[1] // 2) * BIN, color
        )
        normal = np.array([np.cos(angle), np.sin(angle)])
        absolute_offset = offset + center @ normal
        duplicate = False
        for old in guides:
            alignment = np.dot(normal, old.normal)
            sign = np.sign(alignment)
            if abs(alignment) > np.cos(np.deg2rad(1.5)) and abs(
                offset - sign * (old.offset - center @ old.normal)
            ) < 5:
                duplicate = True
                break
        if duplicate:
            continue
        estimated = color_estimate(scene, variance, colors, exterior, xn, yn, normal, offset)
        if estimated is not None:
            color, support, samples = estimated
            guides.append(Guide(tuple(normal), float(absolute_offset), tuple(color), float(support), samples))
    return guides


def compose(parent, packed, variance, colors, origin, guides):
    """Test each exterior proposal against the same local RAW and parent."""
    result = parent.copy()
    records = []
    for guide in guides:
        p, evidence = supported_correction(parent, packed, variance, colors, origin, guide, segment=64)
        p, local = keep_local_support(parent, p, packed, variance, colors, origin, guide)
        result += p - parent
        records.append({
            "changed": bool((p != parent).any()),
            "maximum_DN16": float(np.abs(p - parent).max() * 65535),
            "long": evidence,
            "short": local,
        })
    return result, records
