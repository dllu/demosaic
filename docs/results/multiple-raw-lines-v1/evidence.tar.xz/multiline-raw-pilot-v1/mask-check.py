"""Change all excluded RAW samples while keeping exterior measurements fixed."""

import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import reference, write_json
from demosaic.noise import variance_map

ROOT = Path(__file__).resolve().parent
FRESH = ROOT.parent / "multiline-raw-shoulders-v1"
sys.path.insert(0, str(FRESH))
from proposals import band_measurement, external_proposals
from shoulders import estimate

sys.path.insert(0, str(ROOT))
from run import probe, sample

torch.set_num_threads(2)
profile = probe.PRIORS["iso400"]
query, context, *_ = sample(37, "parallel", profile, 176589044777)
raw = context["matched"]
variance = variance_map(torch.from_numpy(raw), profile["shot"], profile["read"]).numpy()
_, _, outside, _, _ = band_measurement(raw, variance, probe.BOX)
changed, changed_variance = raw.copy(), variance.copy()
generator = np.random.default_rng(442908)
changed[:, ~outside] = generator.uniform(-0.02, 0.95, changed[:, ~outside].shape)
changed_variance[:, ~outside] = generator.uniform(1e-8, 0.002, changed[:, ~outside].shape)
np.testing.assert_array_equal(raw[:, outside], changed[:, outside])
np.testing.assert_array_equal(variance[:, outside], changed_variance[:, outside])
assert np.count_nonzero(raw != changed) == 4 * np.count_nonzero(~outside)
assert np.count_nonzero(variance != changed_variance) == 4 * np.count_nonzero(~outside)
colors = query["colors"][0].numpy()
record = {}
for label, kwargs in (("plain", {}), ("with_shoulders", {"color_estimator": estimate})):
    a = external_proposals(raw, variance, colors, probe.BOX, **kwargs)
    b = external_proposals(changed, changed_variance, colors, probe.BOX, **kwargs)
    assert a and a == b
    record[label] = [asdict(v) for v in a]
write_json(ROOT / "mask-check.json", {
    "source": reference(__file__),
    "excluded_sites_changed": int(4 * np.count_nonzero(~outside)),
    "exact_guide_identity": True,
    "guides": record,
})
