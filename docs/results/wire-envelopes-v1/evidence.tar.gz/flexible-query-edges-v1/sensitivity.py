"""Test weak wires alongside the complex rail controls with a fixed analytic parent."""

from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from probe_flexible_query_edges import MODES, predict
from probe_local_phase_bounds import fresh_structure, structure_module

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig, restore_local_waves
from demosaic.search_donor_geometry import screening_mask

ROOT = Path(__file__).resolve().parent
SEED = 202611172058


def targets(row):
    """Provide finite measured wires at prescribed phases without fitting the estimator."""
    parent = fresh_structure(row["style"], row["angle_radians"], *row["width_shift_level_height"])
    phi = row["angle_radians"]
    tangent = np.array([-np.sin(phi), np.cos(phi)])
    normal = np.array([np.cos(phi), np.sin(phi)])
    shifts = row["width_shift_level_height"][1]
    rng = np.random.default_rng(
        np.random.SeedSequence([SEED, 0, row["trial"], row["style"] == "two-rails"])
    )
    center = normal * (shifts + 8) + tangent * float(rng.uniform(-24, 24))
    angle = phi + np.deg2rad([62, 12])
    lengths = rng.uniform([10, 12], [14, 18])
    frequency = np.column_stack((np.cos(angle), np.sin(angle))) / lengths[:, None]
    phases = rng.uniform(0, 1, 2)
    yy, xx = np.indices(parent.shape[1:]) - 127.5
    along = tangent[0] * (xx - center[0]) + tangent[1] * (yy - center[1])
    across = normal[0] * (xx - center[0]) + normal[1] * (yy - center[1])
    radius = np.hypot(along / 93, across / 57)
    field = np.where(radius < 1, np.cos(np.pi * np.minimum(radius, 1) / 2) ** 2, 0)
    increment = []
    for (u, v), phase, strength in zip(frequency, phases, (0.0032, 0.0008), strict=True):
        integrate = np.sinc(u) * np.sinc(v)  # Pixel-area integration of the sinusoid.
        wave = np.cos(2 * np.pi * (u * xx + v * yy + phase)) * field * strength * integrate
        increment.append((np.array([0.88, 1, 0.78])[:, None, None] * wave).astype(np.float32))
    first = parent + increment[0]
    both = first + increment[1]
    return parent, first, both, frequency, radius >= 1


def baseline(parent, samples, colors, guess, noise, query, cfg, t):
    v, _ = restore_local_waves(
        parent,
        samples,
        colors,
        shot=noise["shot"],
        read=noise["read"],
        config=cfg,
        thresholds=(t, t + 1),
        evidence_mask=~screening_mask(query),
        guide_frequencies_xy=guess["frequencies_xy"],
        phase_bins=8,
        shrink_phase_fit=True,
        compare_pooled_support=True,
        compare_pooled_refit=True,
        active_guide_directions=guess["active"],
    )
    return {("parallel", k): v["weighted-refit", t + k] for k in (0, 1)}


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    path = ROOT / "plan.json"
    plan = read_json(path)
    recipe = structure_module(plan["structure"])
    old = LocalWaveConfig(**plan["config"])
    configs = {arm: replace(old, background=kind) for arm, kind in MODES.items()}
    source = checked(plan["source"]["null-fresh.json"])
    retained = [r for r in read_json(source)["rows"] if r["style"] in ("bent-rail", "two-rails")]
    rows = []
    for case, row in enumerate(retained):
        profile = row["profile"]
        noise, op = plan["profiles"][profile], plan["settings"][profile]
        threshold, alpha = op["threshold"], op["scale"]
        colors = np.asarray(PATTERNS[row["CFA"]])
        parent, strong, both, guide, quiet = targets(row)
        choice = {"active": [True, True], "frequencies_xy": guide.tolist()}
        output = []
        for role, target in enumerate((strong, both)):
            rng = np.random.default_rng(np.random.SeedSequence([SEED, 1, case, role]))
            samples = recipe.corrupt(target, colors, rng, noise)
            fixed = baseline(parent, samples, colors, choice, noise, recipe.QUERY, old, threshold)
            v, _ = predict(parent, samples, colors, choice, noise, recipe.QUERY, configs, threshold)
            output.append(fixed | v)
        truth = (both.astype(float) - strong).ravel()
        magnitude = truth @ truth
        scores = {}
        for (arm, stop), model in output[1].items():
            weak = alpha * (model.astype(float) - output[0][arm, stop]).ravel()
            residue = alpha * (model[:, quiet].astype(float) - parent[:, quiet])
            scores[f"{arm}{'-strict' if stop else ''}"] = {
                "weak_projection": float(weak @ truth / magnitude),
                "increment_RMS_DN16": float(np.sqrt(np.mean((weak - truth) ** 2)) * 65535),
                "quiet_RMS_DN16": float(np.sqrt(np.mean(residue**2)) * 65535),
            }
        rows.append(
            {
                k: row[k]
                for k in (
                    "profile",
                    "style",
                    "trial",
                    "CFA",
                    "angle_radians",
                    "width_shift_level_height",
                )
            }
            | {"wire_frequency": guide.tolist(), "case": case, "metrics": scores}
        )
        print(profile, row["style"], row["trial"], flush=True)
    assert len(rows) == 16
    write_json(
        ROOT / "sensitivity.json",
        {
            "plan": reference(path),
            "producer": reference(__file__),
            "source": reference(source),
            "seed": SEED,
            "rows": rows,
            "scope": "Fixed true nuisance as the delivery parent and exact nominal wire guides. "
            "Each rail scene has clean strong-only/weak-plus-strong roles and independently "
            "corrupted observations. This estimates weak-wire sensitivity alongside rails "
            "without new neural prediction or training.",
        },
    )


if __name__ == "__main__":
    main()
