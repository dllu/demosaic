"""Stress end-to-end query delivery with known flat, step and rail truth."""

from collections import Counter
from itertools import product
from pathlib import Path

import numpy as np
import torch
from probe_matched_query_evidence import deliver
from probe_screened_scene_donors import crop

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
SEED = 202611172010
TRIALS = 6
SENSOR_BLACK = 0.03
QUERY = (512, 512, 256, 256)
MEASURE = np.s_[..., 48:208, 48:208]
DIRECTION = np.array([0.84, 1, 0.79])


def construct(style, angle, width, shift, level, height):
    yy, xx = np.ogrid[:256, :256]
    u, v = np.cos(angle), np.sin(angle)
    line = u * (xx - 127.5) + v * (yy - 127.5) - shift
    structure = np.zeros((256, 256))
    if style != "flat":
        for x, y in product(np.linspace(-0.4, 0.4, 5), repeat=2):
            p = line + u * x + v * y
            present = p > 0
            structure += (present if style == "step" else present & (p < width)) / 25
    return ((level + height * structure) * DIRECTION[:, None, None]).astype(np.float32)


def corrupt(truth, colors, rng, noise):
    yy, xx = np.indices(truth.shape[1:])
    sample = truth[colors.reshape(2, 2)[yy % 2, xx % 2], yy, xx]
    shot, read = noise["shot"], noise["read"]
    value = rng.poisson(sample / shot) * shot + rng.normal(0, np.sqrt(read), sample.shape)
    return crop(
        (np.rint(np.clip(value + SENSOR_BLACK, 0, 1) * 65535) / 65535 - SENSOR_BLACK).astype(
            np.float32
        ),
        (0, 0, 256, 256),
    )


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    self_ref = reference(__file__)
    plan_path = ROOT / "plan.json"
    plan = read_json(plan_path)
    cfg = LocalWaveConfig(**plan["config"])
    rows, count = [], Counter()
    for (iso_idx, (profile, noise)), (kind, style), trial in product(
        enumerate(plan["profiles"].items()), enumerate(("flat", "step", "rail")), range(TRIALS)
    ):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 0, kind, trial]))
        angle = float(rng.uniform(0.04, np.pi - 0.04))
        values = tuple(
            float(rng.uniform(a, b)) for a, b in ((4, 14), (-36, 25), (0.03, 0.08), (0.05, 0.17))
        )
        period = np.clip(2 * values[0], 8, 26)
        freqs = np.array([[np.cos(angle), np.sin(angle)], [-np.sin(angle), np.cos(angle)]]) / period
        cfa = tuple(PATTERNS)[trial % len(PATTERNS)]
        colors = np.array(PATTERNS[cfa])
        target = construct(style, angle, *values)
        noise_rng = np.random.default_rng(np.random.SeedSequence([SEED, 1, iso_idx, kind, trial]))
        raw = corrupt(target, colors, noise_rng, noise)
        threshold = plan["settings"][profile]["threshold"]
        result, _ = deliver(
            target,
            raw,
            colors,
            {"null": {"active": [True, True], "frequencies_xy": freqs.tolist()}},
            noise,
            QUERY,
            cfg,
            threshold,
            edges=False,
        )
        metrics = {}
        for mode, restored in result.items():
            if mode == "parent":
                continue
            delta = (restored[MEASURE].astype(float) - target[MEASURE]) * 65535
            metrics[mode] = {
                "RMS_DN16": float(np.sqrt(np.mean(delta**2))),
                "max_abs_DN16": float(np.max(np.abs(delta))),
                "changed_pixels": int(np.any(delta != 0, axis=0).sum()),
            }
            count[profile, style, mode] += metrics[mode]["changed_pixels"] > 0
        rows.append(
            {
                "profile": profile,
                "style": style,
                "trial": trial,
                "CFA": cfa,
                "angle_radians": angle,
                "width_shift_level_height": values,
                "guide_frequencies_xy": freqs.tolist(),
                "metrics": metrics,
            }
        )
        print(
            profile, style, trial, [round(a["RMS_DN16"], 4) for a in metrics.values()], flush=True
        )
    assert self_ref == reference(__file__)
    write_json(
        ROOT / "structure-null.json",
        {
            "source": self_ref,
            "plan": reference(plan_path),
            "seed": SEED,
            "trials": TRIALS,
            "query": QUERY,
            "measured_local_xywh": [48, 48, 160, 160],
            "rows": rows,
            "false_changes": {" / ".join(k): v for k, v in count.items()},
            "scope": "The exact continuous flat/step/rail target is used as a diagnostic delivery parent. "
            "All guides are declared active and their RAW evidence is unconditioned on that target. "
            "Each rotation includes a direction normal to the step/rail and a perpendicular control.",
        },
    )


if __name__ == "__main__":
    main()
