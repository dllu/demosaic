"""Check the uniform fundamental basis on both native GFX comparisons."""

import argparse
import shutil
from dataclasses import replace
from pathlib import Path

import numpy as np
from probe_flexible_query_edges import camera
from probe_surface_aggregation import field
from report_fold_support_pooling import insert_camera_panels

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import (
    checked,
    freeze_sources,
    read_json,
    reference,
    verify_plan,
    write_json,
)
from demosaic.local_validated_waves import LocalWaveConfig, restore_local_waves
from demosaic.search_donor_geometry import screening_mask

BASIS = {"screened": None, "fundamental": ((1,), (1,))}


def prepare(root, previous):
    source = reference(previous / "plan.json")
    plan = read_json(checked(source))
    old = reference(previous / "camera.json")
    work, frozen = freeze_sources(
        Path.cwd(),
        root,
        [
            "probe_flexible_query_edges.py",
            "report_fold_support_pooling.py",
        ],
    )
    driver = work / "scripts/camera.py"
    shutil.copyfile(__file__, driver)
    binding = reference(driver)
    frozen[binding["path"]] = binding["sha256"]
    write_json(
        root / "camera-plan.json",
        plan
        | {
            "root": str(root),
            "driver": binding,
            "work": str(work),
            "frozen_files": frozen,
            "inputs": [
                source,
                old,
                plan["previous"],
                plan["camera_baseline"],
                plan["camera_conditions"],
            ],
            "screened_camera": old,
        },
    )


def predict(parent, packed, colors, guide, noise, query, config, threshold, *, edge_side):
    images, receipts = {}, {}
    thresholds = (threshold, threshold + 1)
    for name, harmonics in BASIS.items():
        outputs = {}
        if any(guide["active"]):
            outputs, results = restore_local_waves(
                parent,
                packed,
                colors,
                shot=noise["shot"],
                read=noise["read"],
                config=config,
                thresholds=thresholds,
                evidence_mask=~screening_mask(query),
                guide_frequencies_xy=guide["frequencies_xy"],
                phase_bins=8,
                phase_harmonics=harmonics,
                shrink_phase_fit=True,
                compare_pooled_support=True,
                compare_pooled_refit=True,
                phase_edge_side="validation" if edge_side else None,
                active_guide_directions=guide["active"],
            )
            receipts[name] = results
        for offset, stop in enumerate(thresholds):
            images[name, offset] = outputs.get(("weighted-refit", stop), parent)
    return images, receipts


def run(path):
    plan = read_json(path)
    verify_plan(plan)
    assert plan["driver"] == reference(__file__)
    root = Path(plan["root"])
    old = read_json(checked(plan["screened_camera"]))["rows"]
    config = replace(LocalWaveConfig(**plan["config"]), background="screened_curved4_step")
    arrays = root / "arrays"
    arrays.mkdir()
    rows = camera(plan, old, arrays, config, predictor=predict)
    baseline = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    comparisons = root / "native"
    comparisons.mkdir()
    review = []
    for row, archived, source in zip(rows, old, baseline, strict=True):
        key = row["id"]
        assert key == archived["id"] == source["id"]
        info = source["source"]
        x, y, w, h = source["ROI_xywh"]
        qx, qy, *_ = info["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(info["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = source["display_exposure"]
        with (
            np.load(checked(row["predictions"])) as f,
            np.load(checked(archived["predictions"])) as target,
        ):
            changes, pixels = {}, []
            for family in ("scene", "spectral"):
                eight = field(family, "screened", 0)
                simple = field(family, "fundamental", 0)
                for offset in (0, 1):
                    label = field(family, "screened", offset)
                    np.testing.assert_array_equal(f[label], target[label])
                pixels.extend(
                    tuple(
                        (
                            label,
                            np.rint(
                                display(f[k][None], ctx, exposure=exposure)[0][region].transpose(
                                    1, 2, 0
                                )
                                * 255
                            ).astype(np.uint8),
                        )
                        for label, k in (
                            (family + " eight knots", eight),
                            (family + " fundamental", simple),
                        )
                    )
                )
                changes[family] = {
                    arm: float(
                        np.sqrt(np.mean((f[k][region].astype(float) - f["parent"][region]) ** 2))
                        * 65535
                    )
                    for arm, k in (("eight", eight), ("fundamental", simple))
                }
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in source["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            comparisons, key, source | {"panels": panels}, "V120 EMA", pixels
        )
        ax, ay, *_ = info["absolute_query_xywh"]
        review.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "noise": noise[key],
                "checkpoint": info["checkpoint"],
                "display_exposure": exposure,
                "ROI_xywh": [ax + x - qx, ay + y - qy, w, h],
                "CFA": "RGGB",
                "source_calibration": info["query_arrays"],
                "predictions": row["predictions"],
                "reference": "DSCF3880 ISO100 AHD"
                if key.startswith("main-")
                else "DSCF3835 ISO100 AHD and both camera JPEGs",
                "RMS_from_V120_DN16": changes,
            }
        )
    write_json(
        root / "camera.json",
        {
            "plan": reference(path),
            "producer": reference(__file__),
            "comparison": review,
        },
    )


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("root", type=Path)
    cli.add_argument("--previous", type=Path)
    args = cli.parse_args()
    root = args.root.resolve()
    if args.previous is not None:
        prepare(root, args.previous.resolve())
    else:
        run(root / "camera-plan.json")
