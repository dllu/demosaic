"""Review native crops and reduce case-bound finite-envelope results."""

import argparse
from itertools import product
from pathlib import Path

import numpy as np
from probe_wire_envelopes import ARMS
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SOURCES = {
    "archived": ROOT,
    "fresh": ROOT.parent / "fresh-wire-envelopes-v1",
    "null": ROOT.parent / "wire-envelope-controls-v1",
    "tolerance": ROOT.parent / "wire-envelope-tolerance-v1",
    "tolerance_null": ROOT.parent / "wire-envelope-tolerance-controls-v1",
}
CAMERA = ROOT.parent / "wire-envelope-camera-v1/camera.json"
PROFILES = ("iso400", "iso6400")
NAMES = (
    "Noisy Malvar",
    "Analytic rail",
    "Uniform eight knots",
    "Exact eight knots",
    "Exact fundamental",
    "Exact GT",
)
ROI = (48, 48, 160, 160)


def sources():
    return {
        name: {p: reference(root / f"{p}.json") for p in PROFILES} for name, root in SOURCES.items()
    }


def render(out):
    out.mkdir(exist_ok=True)
    rows = []
    for source, index in (("archived", 8), ("fresh", 4)):
        run = SOURCES[source]
        declaration = read_json(run / "plan.json")
        stage = read_json(run / "iso400.json")
        row = next(r for r in stage["rows"] if r["case"] == index)
        with np.load(checked(row["predictions"])) as saved:
            ctx = {
                "packed": saved["packed"][None],
                "colors": saved["cfa"][None],
                "wb": np.ones((1, 3)),
                "matrix": np.eye(3)[None],
            }
            parent = saved["parent"].astype(float)
            scale = declaration["settings"]["iso400"]["scale"]
            uniform = "uniform" if source == "archived" else "restored_uniform"
            harmonic = "exact-fundamental" if source == "archived" else "restored_exact-fundamental"
            delivery = [
                parent + scale * (saved[key] - parent)
                for key in (uniform, "restored_exact", harmonic)
            ]
            values = [noisy_malvar(ctx)[0], parent, *delivery, saved["target"]]
        metadata = {
            "ROI_xywh": list(ROI),
            "source": source,
            "case": index,
            "CFA": row["CFA"],
            "case_prediction": row["predictions"],
            "parent": "Exact analytic rail-only scene",
            "checkpoint_sha256": None,
            "noise": declaration["profiles"]["iso400"],
            "operating": declaration["settings"]["iso400"],
            "color_transform": "Identity camera RGB and WB, fixed clipped sRGB",
        }
        rows.append(
            native_board(
                out,
                f"{source}-iso400-case{index}",
                values,
                ctx,
                metadata,
                roi=ROI,
                labels=NAMES,
                triplet_indices=(0, 4, 5),
                exposure=4,
            )
        )
    write_json(out / "native.json", {"producer": reference(__file__), "crops": rows})


def mean_scores(rows):
    means = {}
    for arm in rows[0]["metrics"]:
        items = [r["metrics"][arm] for r in rows]
        columns = {k: np.asarray([x[k] for x in items]) for k in items[0]}
        means[arm] = {}
        for key, v in columns.items():
            if key == "peak_DN16":
                value = v.max()
            elif key == "changed_pixels":
                key, value = "activated_cases", np.count_nonzero(v)
            elif key.endswith("RMS_DN16"):
                value = np.sqrt(np.mean(v**2))
            elif key == "absent_weak_projection":
                key, value = "absolute_absent_weak_projection", np.abs(v).mean()
            else:
                value = v.mean()
            means[arm][key] = float(value)
    return {"n": len(rows), "means": means}


def reduce(out):
    bindings = sources()
    summaries = {}
    for (name, paths), noise in product(bindings.items(), PROFILES):
        receipt = read_json(checked(paths[noise]))
        rows = receipt["rows"]
        assert receipt["plan"] == reference(SOURCES[name] / "plan.json")
        is_null = name in ("null", "tolerance_null")
        assert len(rows) == (24 if is_null else 8)
        assert len(rows[0]["metrics"]) == (3 if name.startswith("tolerance") else len(ARMS)) * 3
        if name.startswith("tolerance"):
            control = "null" if is_null else "fresh"
            previous = read_json(checked(bindings[control][noise]))["rows"]
            for row, old in zip(rows, previous, strict=True):
                for suffix in ("", "-strict", "-positive"):
                    key = "exact-fundamental" + suffix
                    assert row["metrics"][key] == old["metrics"][key]
        summaries.setdefault(name, {})[noise] = {"all": mean_scores(rows)}
        labels = {}
        if name in ("fresh", "tolerance"):
            labels = {
                "planar": lambda r: not r["chirped_signed_color"],
                "chirped": lambda r: r["chirped_signed_color"],
            }
        if is_null:
            labels = {
                "flat": lambda r: r["style"] == "flat",
                "straight": lambda r: r["style"] in ("step", "rail"),
                "complex": lambda r: r["style"] in ("wedge", "bent-rail", "two-rails"),
            }
        for label, select in labels.items():
            summaries[name][noise][label] = mean_scores([r for r in rows if select(r)])
    pooled = {}
    for stage in ("null", "tolerance_null"):
        nulls = [r for p in bindings[stage].values() for r in read_json(checked(p))["rows"]]
        pooled[stage] = {}
        for label, styles in {
            "flat": {"flat"},
            "straight": {"step", "rail"},
            "complex": {"wedge", "bent-rail", "two-rails"},
        }.items():
            pooled[stage][label] = mean_scores([r for r in nulls if r["style"] in styles])
    camera = read_json(CAMERA)["comparison"]
    assert len(camera) == 8
    write_json(
        out / "summary.json",
        {
            "sources": bindings,
            "producer": reference(__file__),
            "by_noise": summaries,
            "pooled_nulls": pooled,
            "camera_source": reference(CAMERA),
            "camera": [
                {k: r[k] for k in ("id", "RMS_from_V120_DN16", "checkpoint", "noise")}
                for r in camera
            ],
            "new_checkpoint_sha256": None,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("render", "reduce"))
    args = parser.parse_args()
    (render if args.action == "render" else reduce)(ROOT / "review")
