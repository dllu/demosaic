"""Bind the executed finite-wire experiment and its inspected native evidence."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path("docs/results/wire-envelopes-v1")
IMAGES = Path("docs/images/wire-envelopes-v1")

summary = ROOT / "review/summary.json"
review = read_json(summary)
native = read_json(ROOT / "review/native.json")
camera = read_json(checked(review["camera_source"]))["comparison"]
assert len(native["crops"]) == 2 and len(camera) == 8
RESULT.mkdir()
IMAGES.mkdir()


def copy(binding):
    src = checked(binding)
    output = IMAGES / src.name
    shutil.copyfile(src, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return output.name


crop_path = IMAGES / "manifest.json"
write_json(
    crop_path,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Inspected two native synthetic triplets and both full comparisons. "
        "The primary analytic rail has no neural checkpoint. Eight GFX native boards compare uniform bases.",
        "camera": [r | {"file": copy(r["image"])} for r in camera],
        "crops": [
            r | {k: r[k] | {"file": copy(r[k]["image"])} for k in ("board", "triplet")}
            for r in native["crops"]
        ],
    },
)
summary_path = RESULT / "summary.json"
shutil.copyfile(summary, summary_path)
assert reference(summary_path)["sha256"] == reference(summary)["sha256"]
stage_dirs = {name: checked(paths["iso400"]).parent for name, paths in review["sources"].items()}
fresh = stage_dirs["fresh"]
null = stage_dirs["null"]
files = ["plan.json", "iso400.json", "iso6400.json", "iso400.log", "iso6400.log"]
members = {
    ROOT: files
    + [
        "review.py",
        "publish.py",
        "review/native.json",
        "review/summary.json",
        "tests.log",
        "tests-final.log",
        "work/scripts/probe_wire_envelopes.py",
        "work/src/demosaic/local_validated_waves.py",
    ],
    fresh: files + ["work/scripts/probe_fresh_wire_envelopes.py"],
    null: files + ["work/scripts/probe_fresh_wire_envelopes.py"],
    stage_dirs["tolerance"]: files
    + ["work/scripts/probe_fresh_wire_envelopes.py", "work/scripts/probe_wire_envelopes.py"],
    stage_dirs["tolerance_null"]: files,
    checked(review["camera_source"]).parent: [
        "camera-plan.json",
        "camera.json",
        "camera.log",
        "work/scripts/camera.py",
        "work/src/demosaic/local_validated_waves.py",
    ],
    ROOT.parent / "wire-envelopes-v1": ["plan.json", "iso400.log", "iso6400.log"],
    ROOT.parent / "flexible-query-edges-v1": ["sensitivity.py"],
    ROOT.parent / "matched-query-evidence-v1": ["structure_null.py"],
}
archive = RESULT / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for path, names in members.items():
        for name in names:
            file = path / name
            m = bundle.gettarinfo(str(file), arcname=f"{path.name}/{name}")
            m.mtime = m.uid = m.gid = 0
            m.uname = m.gname = ""
            with file.open("rb") as data:
                bundle.addfile(m, data)

with tarfile.open(archive) as bundle:
    for path, names in members.items():
        for name in names:
            assert bundle.extractfile(f"{path.name}/{name}").read() == (path / name).read_bytes()

write_json(
    RESULT / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary_path),
        "native_manifest": reference(crop_path),
        "verified_members": sum(map(len, members.values())),
        "comparisons_viewed": 10,
        "camera_comparisons_viewed": 8,
        "triplets_viewed": 2,
        "new_checkpoint_sha256": None,
    },
)
