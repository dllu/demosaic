"""Publish the camera diagnostics, source-disjoint replay and opt-in crop fit."""

from hashlib import file_digest
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import leave_out_phase as model

ROOT = Path.cwd()
OUT = model.OUT
ASSETS = ROOT / "docs/assets" / model.HERE.name
RESULTS = ROOT / "docs/results" / model.HERE.name
FILES = (
    "noisy-only.json",
    "reference-witness.json",
    "phase-closure.json",
    "calibration.json",
    "independent.json",
    "retained.json",
    "camera-review.json",
    "exact-review.json",
    "api-review.json",
    "isolation.json",
    "natural-replay.json",
    "summary.json",
    "independent/inputs.json",
    "independent/plan.json",
    "independent/parent/result.json",
)
REUSED = (
    "local-replicated-phase-v1/replay_replicated.py",
    "local-replicated-phase-v1/check_station_api.py",
    "local-replicated-phase-v1/replicated_phase.py",
    "local-replicated-phase-v1/capture_balanced.py",
    "local-unranked-phase-v1/unranked_phase.py",
    "local-bayer-presence-v1/review_presence.py",
    "local-nested-support-v1/freeze_nested.py",
    "local-nested-support-v1/replay_nested_parents.py",
    "local-weak-contrast-v1/capture_contrast.py",
    "local-weak-support-v1/replay_exterior_support.py",
    "scene-patch-width-v1/evaluate_wide.py",
    "green-covariance-refit-v1/wire_math.py",
)


def local(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def image(binding):
    source = checked(binding)
    dest = ASSETS / source.name
    shutil.copyfile(source, dest)
    output = local(dest)
    assert output["sha256"] == binding["sha256"]
    return output


def board(row):
    pic = image(row["image"])
    with Image.open(ROOT / pic["path"]) as raster:
        for p in row["panels"]:
            x, y, w, h = p["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= raster.width and 0 <= y < y + h <= raster.height
    return row | {"image": pic}


def main():
    refs = {name: reference(OUT / name) for name in FILES}
    data = {name: read_json(checked(binding)) for name, binding in refs.items()}
    for row in data.values():
        for key in ("driver", "operator", "balance_source"):
            if key in row:
                checked(row[key])
    assert data["reference-witness.json"]["noisy_witness"] == refs["noisy-only.json"]
    assert data["phase-closure.json"]["source"] == refs["noisy-only.json"]
    for r in data["reference-witness.json"]["rows"]:
        checked(r["ref_RAW"])
    for key in ("retained.json", "independent.json"):
        assert data[key]["calibration"] == refs["calibration.json"]
        assert data[key]["summary"]["fits_limits"]["primary"]
    for key in ("api-review.json", "camera-review.json", "exact-review.json"):
        assert data[key]["main_source"] == refs["independent.json"]
    proof = data["api-review.json"]["data"]
    assert proof["maximum_error_DN16"] == {"weak-internal-phase": 0.0, "weak-replicated-phase": 0.0}
    assert proof["counts"]["exact"] == 288 and proof["counts"]["camera"] == 8
    group_paths = {}
    for k in ("calibration", "independent", "retained"):
        row = data[f"{k}.json"]
        parent = read_json(checked(row["source"]))
        inputs = read_json(checked(parent["inputs"]))
        assert row["plan"] == inputs["plan"]
        grp = read_json(checked(row["plan"]))
        group_paths[k] = {
            str(s["source"][key]) for s in grp["sources"] for key in ("id", "cache_sha256")
        }
        for cp in parent["weights"].values():
            checked(cp)
        for a, b in zip(inputs["observations"], parent["records"], strict=True):
            assert a["id"] == b["id"]
            for x, y in zip(a["streams"], b["streams"], strict=True):
                assert y["data"] == x["data"]
                checked(x["data"])
                for item in y["outputs"].values():
                    checked(item)
    assert len(set.union(*group_paths.values())) == sum(len(s) for s in group_paths.values())
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    members = {f"receipts/{path}": binding for path, binding in refs.items()}
    for k in ("calibration", "retained"):
        meta = data[f"{k}.json"]
        parent = read_json(checked(meta["source"]))
        members |= {
            f"receipts/{k}/plan.json": meta["plan"],
            f"receipts/{k}/inputs.json": parent["inputs"],
            f"receipts/{k}/parent.json": meta["source"],
        }
    members.update({f"source/{p.name}": reference(p) for p in sorted(model.HERE.glob("*.py"))})
    members.update({f"reused/{key}": reference(model.HERE.parent / key) for key in REUSED})
    members.update(proof["production_files"])
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for name, binding in members.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == members.keys()
        for name, binding in members.items():
            with tar.extractfile(name) as f:
                assert file_digest(f, "sha256").hexdigest() == binding["sha256"]
    camera = [
        c | {"native": [board(b) for b in c["native"]]}
        for c in data["camera-review.json"]["data"]["rows"]
    ]
    exact = [
        c | {k: board(c[k]) for k in ("board", "triplet")}
        for c in data["exact-review.json"]["data"]["boards"]
    ]
    assert sum(len(c["native"]) for c in camera) == 12 and len(exact) == 2
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest, {"camera": camera, "exact": exact, "chart": image(data["summary.json"]["chart"])}
    )
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(refs["summary.json"]), summary)
    write_json(
        RESULTS / "publication.json",
        {
            "parent_revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip(),
            "manifest": local(manifest),
            "summary": local(summary),
            "archive": local(archive),
            "receipt_bindings": refs,
            "archive_members": members,
            "prior_publication": local(
                ROOT / "docs/results/local-replicated-phase-v1/publication.json"
            ),
            "new_weights": None,
            "packaged_mode": "weak-internal-phase",
            "standing_native_boards_viewed": 12,
            "native_triplets_viewed": 2,
        },
    )


if __name__ == "__main__":
    main()
