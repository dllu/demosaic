"""Fit mesh phase inside a crop with each delivery neighborhood left out."""

from itertools import product
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-replicated-phase-v1"))

from demosaic._mesh_near_phase import (
    _along_wire_neighbor,
    _observations,
    _pixel_map,
    _replicated_taper,
    _signed_evidence,
)
from demosaic._mesh_pooled import (
    _CENTERS,
    _SMOOTH,
    _STRIDE,
    _correction,
    _dominant,
    _footprint,
    _inverse,
    _measure_nodes,
    _rgb,
    _wave,
    _windows,
)
from demosaic._mesh_weak_phase import _GAIN, _SITES, _background, _carrier, _taper, _variance
from demosaic._mesh_weak_posterior import _refine, _weak_correction
from demosaic.mesh_carrier_fit import _POOLED_FOOTPRINT, _ROI_SIZE, _WINDOW, _positions, _sites
from replicated_phase import evidence, replay

DONORS = np.array(tuple(product(range(0, 160, 32), repeat=2)))
Y, X = np.indices((10, 10), dtype=np.float64)
CENTER = np.stack((X.ravel(), Y.ravel()), axis=1) * 16 + 7.5
RIM = np.array(
    [
        *((x, y) for y in (-32, 160) for x in range(0, 160, 32)),
        *((x, y) for x in (-32, 160) for y in range(0, 160, 32)),
    ]
)
SCALES = (("core", 50.0, 75.0), ("mixed", 50.0, 75.0))
KIND = ("center", "replicated")
DOSE = (1.5, 2.5)
OPTIONS = tuple(
    (name, kind, cut, f"{name}/{kind}/{cut:g}")
    for (name, _, _), kind, cut in product(SCALES, KIND, DOSE)
)
ARMS = ("near", *(item[-1] for item in OPTIONS))


def estimates(scene, origin, frequencies, shot, read):
    x, y = origin
    coefficients, precision = [], []
    for dx, dy in DONORS:
        template = _carrier(32, dx, dy, frequencies).reshape(32, 32, 4)
        basis = np.concatenate((_background(32), template), axis=-1)
        values, weights = [], []
        for r, c in _SITES:
            pixels = _sites(scene, x + dx, y + dy, 32, r, c).astype(np.float64).ravel()
            var = _variance(pixels.mean(), shot, read)
            inv = np.linalg.pinv(basis[r::2, c::2].reshape(pixels.size, -1), rcond=1e-8)[-4:]
            values.append((inv @ pixels).reshape(2, 2))
            weights.append(1 / (var * np.square(inv).sum(axis=1).reshape(2, 2).mean(axis=1)))
        coefficients.append(values)
        precision.append(weights)
    return np.asarray(coefficients), np.asarray(precision)


def weights(locations, frequency, across, along):
    distance = CENTER[:, None] - (locations + 15.5)[None]
    normal = frequency / np.linalg.norm(frequency)
    tangent = normal[::-1] * (-1, 1)
    gaussian = np.exp(
        -0.5 * ((distance @ normal / across) ** 2 + (distance @ tangent / along) ** 2)
    )
    # The central station and all eight bordering stations are excluded from the phase estimate.
    keep = (np.abs(distance) >= 39.5).any(axis=-1)
    return gaussian * keep


def pool(coefficients, precision, locations, frequency, greens, across, along):
    gaussian = weights(locations, frequency, across, along)
    votes = gaussian @ precision
    average = np.einsum("nd,dsi,ds->nsi", gaussian, coefficients, precision) / np.maximum(
        1e-12, votes[..., None]
    )
    information = votes**2 / np.maximum(1e-12, gaussian**2 @ precision)
    amplitude = np.linalg.norm(average, axis=-1)
    power = np.sum(coefficients**2, axis=-1)
    remaining = np.sqrt(np.maximum(0, power - 2 / precision))
    expected = (gaussian @ (remaining * precision)) / np.maximum(1e-12, votes)
    valid = (amplitude**2 * information >= 16) & (amplitude >= 0.55 * expected)
    unit = average / np.maximum(1e-15, amplitude[..., None])
    agree = (unit[:, greens[0]] * unit[:, greens[1]]).sum(axis=-1)
    return np.where(valid[..., None], average, 0), valid[:, greens].all(axis=-1) & (agree >= 0.5)


def caps(values):
    own = values.reshape(10, 10).repeat(16, axis=0).repeat(16, axis=1)
    return np.minimum(_pixel_map(values), own)


def qualify(parent, local, scene, colors, roi, frequencies, profile, wb, matrix, *, clearance=48):
    x, y = local[:2]
    anchor = parent[:, y : y + 160, x : x + 160]
    empty = dict.fromkeys(ARMS)
    if frequencies is None:
        return dict.fromkeys(ARMS, anchor), empty, {"state": "no frequency"}
    origin = roi[:2]
    shot, read = profile["shot"], profile["read"]
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    context = parent[:, y - 16 : y + 176, x - 16 : x + 176]
    positions = _positions(colors, *origin)
    green = tuple(2 * r + c for r, c in positions)
    prior = _refine(
        anchor,
        context,
        scene,
        colors,
        origin,
        frequencies,
        shot,
        read,
        neutral,
        guard_clearance=clearance,
        full_weak_strength=True,
        near_phase=True,
        replicated_phase=True,
    )
    views = tuple(_footprint(scene, origin, p) for p in positions)
    guide = _wave(_POOLED_FOOTPRINT, frequencies)
    ranks = [
        _dominant(*_measure_nodes(raw, guide, site, shot, read))
        for raw, site in zip(views, positions, strict=True)
    ]
    known = ranks[0] is not None and ranks[0] == ranks[1]
    if known:
        weak = 1 - ranks[0]
        if isinstance(
            _taper(scene, origin, positions, frequencies, weak, shot, read, clearance), np.ndarray
        ):
            return (
                dict.fromkeys(ARMS, prior),
                empty,
                {"state": "distant phase already reliable", "ranks": ranks},
            )
        directions = (weak,)
    else:
        directions = (0, 1)

    observed = tuple(_windows(g, _WINDOW // 2, _STRIDE // 2) for g in views)
    wave = _wave(_WINDOW, frequencies)
    design = np.concatenate((_SMOOTH, wave.reshape(_WINDOW, _WINDOW, 4)), axis=-1)
    projection = _inverse(design.reshape(_WINDOW**2, -1))[-4:]
    patches = _windows(context[1], _WINDOW, _STRIDE).reshape(len(_CENTERS), -1)
    inherited = np.einsum("dp,np->nd", projection, patches).reshape(-1, 2, 2)
    combined = [
        _correction(wave, j, positions, observed, None, patches, inherited[:, j], shot, read)
        for j in range(2)
    ]
    base = (
        anchor + _rgb(sum(combined), neutral, anchor.dtype)
        if any(a.any() for a in combined)
        else anchor
    )
    stations = estimates(scene, origin, frequencies, shot, read)
    query = [_sites(scene, *origin, 160, r, c) for r, c in _SITES]
    audit = []
    deltas = {arm: [None, None] for arm in ARMS[1:]}
    for j in directions:
        refined = _weak_correction(
            anchor, wave, j, positions, observed, shot, read, combined[j], full_strength=True
        )
        change = _rgb(refined - combined[j], neutral, np.float64)
        if not change.any():
            continue
        if known:
            # The prior and the conventional fit share their strong correction.
            change = (base.astype(np.float64) + _GAIN * change - prior).astype(np.float64)
        else:
            old = _replicated_taper(scene, origin, positions, frequencies, j, shot, read)
            change = (1 if old is None else 1 - 0.95 * old) * _GAIN * change
        inside = stations[0][..., j, :], stations[1][..., j], DONORS
        outside = _observations(scene, origin, frequencies, j, shot, read)
        if outside is None:
            continue
        mixed = (
            *(np.concatenate((u, v), axis=0) for u, v in zip(inside[:2], outside, strict=True)),
            np.concatenate((DONORS, RIM)),
        )
        by_kind = {}
        for data, (name, normal, tangent) in zip((inside, mixed), SCALES, strict=True):
            phase, eligible = pool(*data, frequencies[j], green, normal, tangent)
            center, lesser = evidence(query, phase, frequencies, j, green, shot, read)
            strict = np.minimum(center, 2 * lesser)
            supported = np.minimum(
                strict, _along_wire_neighbor(strict, eligible, frequencies[j]) + 0.5
            )
            by_kind[name] = (eligible, {"center": strict, "replicated": supported})
        for name, kind, cut, arm in OPTIONS:
            ok, values = by_kind[name]
            taper = np.where(ok, np.clip((values[kind] - cut) / 2, 0, 1), 0)
            strength = caps(taper)
            if strength.any():
                deltas[arm][j] = strength * change
        audit.append(
            {
                "direction": j,
                "eligible": {k: int(x[0].sum()) for k, x in by_kind.items()},
                "supported": {
                    k: {name: int((x[0] & (score > 1.5)).sum()) for name, score in x[1].items()}
                    for k, x in by_kind.items()
                },
                "peaks": {
                    k: {
                        name: float(score[x[0] & np.isfinite(score)].max())
                        if (x[0] & np.isfinite(score)).any()
                        else None
                        for name, score in x[1].items()
                    }
                    for k, x in by_kind.items()
                },
            }
        )

    def render(group):
        changes = [x for x in group if x is not None]
        return (prior.astype(np.float64) + sum(changes)).astype(prior.dtype) if changes else prior

    return (
        {"near": prior} | {key: render(a) for key, a in deltas.items()},
        {"near": None} | {key: a[1] for key, a in deltas.items()},
        {
            "state": "ranked phase fallback" if known else "ambiguous rank",
            "ranks": ranks,
            "audit": audit,
        },
    )
