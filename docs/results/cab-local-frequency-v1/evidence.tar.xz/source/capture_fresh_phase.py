"""Capture 24 additional validation backgrounds with the established noise/optics."""

from pathlib import Path
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-replicated-phase-v1"))
import capture_balanced as capture

PREVIOUS = OUT.with_name("local-replicated-phase-v1")
SEED = 202611200625
COUNT = 24


def make_plan(root):
    engine = capture.last.run
    engine.OUT = root
    engine.SEED = SEED
    engine.COUNT = COUNT
    blocked = (
        *(
            PREVIOUS / name / "plan.json"
            for name in ("calibration", "fresh", "verification", "station-confirm")
        ),
        capture.PREVIOUS / "fresh" / "plan.json",
        capture.last.PREVIOUS / "fresh" / "plan.json",
        capture.last.CALIBRATION,
    )
    engine.prior.EXCLUSIONS += blocked
    plan = engine.freeze()
    for row in plan["sources"]:
        # Half the panel retains the naturally asymmetric earlier amplitudes.
        # The alternating half matches both median RMS values before drawing noise.
        if row["index"] % 2:
            row["target_balance"] = capture.balance(row, plan["sigma"], SEED)
        row["id"] = f"internal-phase-{row['index']:02d}"
    return plan | {
        "driver": reference(__file__),
        "balance_source": reference(capture.__file__),
        "primary": "Compare a masked inner phase pool against nearby and station-limited phase.",
        "groups": "Half balanced post-optics and half with the earlier weaker second direction.",
    }


def main():
    torch.set_num_threads(2)
    root = OUT / "independent"
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    draft = root / "plan.json"
    if not draft.exists():
        write_json(draft, make_plan(root))
    plan = read_json(draft)
    assert plan["driver"] == reference(__file__)
    input_receipt = root / "inputs.json"
    if not input_receipt.exists():
        capture.last.run.prior.earlier.SEED = SEED
        rows = []
        for case in plan["sources"]:
            rows.append(
                capture.last.run.prior.earlier.capture(case, plan["noise"], root / "inputs")
            )
            if len(rows) % 8 == 0:
                print("Captured", len(rows), flush=True)
        write_json(
            input_receipt,
            {"driver": reference(__file__), "plan": reference(draft), "observations": rows},
        )
    capture.last.run.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        capture.last.run.prior.parents.main()


if __name__ == "__main__":
    main()
