"""Collect the RAW witness, crop checks and source-level paired measures."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replay_internal as replay

OUT = replay.OUT
RECEIPTS = (
    "noisy-only",
    "reference-witness",
    "phase-closure",
    "calibration",
    "independent",
    "retained",
    "camera-review",
    "exact-review",
    "api-review",
    "isolation",
    "natural-replay",
)


def make_chart(data):
    fig, (terms, scores) = plt.subplots(1, 2, figsize=(10.8, 4.15), layout="constrained")
    data_real = [r for r in data["noisy-only"]["rows"] if r["id"].startswith("mesh-nominal")]
    labels = ("Positive wire", "Negative wire", "Positive 2×", "Negative 2×", "Sum", "Difference")
    colors = ("#5c7197", "#008064")
    for i, (row, color) in enumerate(zip(data_real, colors, strict=True)):
        held = np.array(row["held_at_prior"]["held"])
        terms.bar(
            np.arange(len(labels)) + (i - 0.5) * 0.34,
            np.min(held, axis=0),
            width=0.33,
            label=("Left cab", "Right cab")[i],
            color=color,
        )
    terms.axhline(0, color="#333333", lw=0.8)
    terms.set_xticks(np.arange(len(labels)), labels, rotation=28, ha="right")
    terms.set_ylabel("Smaller held error reduction in the two folds")
    terms.set_title("ISO6400 Bayer support at deployed frequencies", fontsize=11)
    terms.legend(frameon=False, loc="upper right")
    terms.grid(axis="y", alpha=0.26)
    metric1 = replay.review.MISSING
    metric2 = replay.review.RESPONSE
    for name, tag, color in (
        ("independent", "24 independent photos", colors[1]),
        ("retained", "24 retained photos", colors[0]),
    ):
        res = data[name]["summary"]["metrics"]
        source = res["near"]["means"][metric2]
        result = res["primary"]["means"]
        scores.scatter(result[metric1], result[metric2] - source, s=51, color=color, label=tag)
        for variant in ("core_center", "core_replicated", "mixed_center", "mixed_replicated"):
            v = res[variant]["means"]
            scores.scatter(v[metric1], v[metric2] - source, s=24, facecolor="none", edgecolor=color)
        scores.plot([0, result[metric1]], [0, result[metric2] - source], color=color, alpha=0.65)
    scores.set_xlabel("Added missing-direction luma (DN16)")
    scores.set_ylabel("Added second-direction contrast (percentage points)")
    scores.set_title("Masked internal phase versus station-capped phase", fontsize=11)
    scores.legend(loc="upper left", frameon=False, fontsize=8)
    scores.grid(alpha=0.26)
    path = OUT / "internal-phase-and-raw-support.png"
    fig.savefig(path, dpi=155)
    plt.close(fig)
    return reference(path)


def main():
    files = {n: reference(OUT / f"{n}.json") for n in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in files.items()}
    ref = data["reference-witness"]["rows"]
    comparisons = []
    for r in ref:
        high = np.array(r["compare_ref_frequency"]["debiased_native_amplitude_DN16"])
        low = np.array(r["ref_coefficients"]["debiased_native_amplitude_DN16"])
        adjusted = high / low * r["raw_green_means"]["reference"] / r["raw_green_means"]["noisy"]
        comparisons.append(
            {
                "id": r["id"],
                "offset": r["offset_cycles_per_pixel"],
                "exposure_normalized_amplitude_ratio": adjusted.tolist(),
                "frequency_reference": r["refined_reference_frequency"],
                "held_high_at_ref_frequency": r["compare_ref_frequency"]["held"],
                "relative_phase": r["relative_global_phase_degree"],
            }
        )
    plan = read_json(checked(data["independent"]["plan"]))
    output = {
        "driver": reference(Path(__file__)),
        "receipts": files,
        "locked_choice": data["calibration"]["policy"]["primary"],
        "calibration": data["calibration"]["summary"],
        "independent": data["independent"]["summary"],
        "retained": data["retained"]["summary"],
        "photographic_training_visits_audited": plan["training_photo_visits_audited"],
        "native_RAW_reference_witness": comparisons,
        "natural": data["natural-replay"]["summary"],
        "exact": [
            {k: r[k] for k in ("id", "draw", "selection", "response_change")}
            for r in data["exact-review"]["data"]["boards"]
        ],
        "standing": {
            r["id"]: r["delta"]["ring_phase"] | {"trace": r["support"]}
            for r in data["camera-review"]["data"]["rows"]
        },
        "api": {
            k: data["api-review"]["data"][k]
            for k in ("counts", "maximum_error_DN16", "median_cpu_ms")
        },
        "chart": make_chart(data),
    }
    write_json(OUT / "summary.json", output)


if __name__ == "__main__":
    main()
