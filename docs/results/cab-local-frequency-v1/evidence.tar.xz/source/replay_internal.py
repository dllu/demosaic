"""Select an internal phase pool on exact targets and freeze it for new sources."""

import collections
import os
from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import leave_out_phase as model
import replay_replicated as review

OUT = model.OUT
CALIBRATION = OUT.with_name("local-replicated-phase-v1") / "calibration"
ORIGINAL_HOLD = OUT.with_name("local-replicated-phase-v1") / "station-confirm"
INDEPENDENT = OUT / "independent"
LIMITS = review.CONTROLS


def load(root):
    review.model = model
    review.OUT = root.parent
    return review.load(root.name)


def choose(rows):
    prior = review.arm_stats(rows, ("near", 1))
    attempts = {}
    for _, _, _, arm in model.OPTIONS:
        entries = []
        for dose in (0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.0):
            result = review.arm_stats(rows, (arm, dose))
            entries.append(
                {
                    "choice": (arm, dose),
                    "metrics": result,
                    "within": bool(review.within(result, prior)),
                }
            )
        attempts[arm] = entries
    available = [row for table in attempts.values() for row in table if row["within"]]
    best = lambda rows: (
        max(
            rows,
            key=lambda v: (
                v["metrics"]["means"][review.RESPONSE],
                -v["metrics"]["means"][review.MISSING],
            ),
        )
        if rows
        else {"choice": ("near", 1), "metrics": prior}
    )
    variants = {
        name: best([r for r in available if r["choice"][0].split("/")[0] == name])
        for name in ("core", "mixed")
    }
    strength = {
        kind: best([r for r in available if r["choice"][0].split("/")[1] == kind])
        for kind in ("center", "replicated")
    }
    return {
        "limits": LIMITS,
        "candidates": attempts,
        "by_pool": variants,
        "by_validation": strength,
        "primary": best(available),
        "prior": prior,
    }


def summary(rows, policy):
    choices = {
        "near": ("near", 1),
        "core_center": ("core/center/1.5", 1),
        "core_replicated": ("core/replicated/1.5", 1),
        "mixed_center": ("mixed/center/1.5", 1),
        "mixed_replicated": ("mixed/replicated/1.5", 1),
        "primary": policy["primary"]["choice"],
    } | {kind: stage["choice"] for kind, stage in policy["by_pool"].items()}
    results = {key: review.arm_stats(rows, choice) for key, choice in choices.items()}
    delta = {
        key: review.paired(rows, choice, choices["near"])
        for key, choice in choices.items()
        if key != "near"
    }
    split = {}
    for label in ("ambiguous rank", "ranked phase fallback", "distant phase already reliable"):
        kept = [
            row | {"draws": ds}
            for row in rows
            if (ds := [d for d in row["draws"] if d["evidence"][0]["state"] == label])
        ]
        if kept:
            split[label] = {
                "sources": len(kept),
                "draws": sum(len(row["draws"]) for row in kept),
                "paired": review.paired(kept, choices["primary"], choices["near"]),
            }
    base = results["near"]
    return {
        "choices": choices,
        "metrics": results,
        "vs_prior": delta,
        "subsets": split,
        "fits_limits": {k: bool(review.within(v, base)) for k, v in results.items()},
        "intact_states": dict(
            collections.Counter(d["evidence"][0]["state"] for r in rows for d in r["draws"])
        ),
    }


def main(kind):
    torch.set_num_threads(2)
    root = {"calibration": CALIBRATION, "retained": ORIGINAL_HOLD, "independent": INDEPENDENT}[kind]
    begin = monotonic()
    entries, source, plan = load(root)
    header = {
        "driver": reference(__file__),
        "operator": reference(model.__file__),
        "source": source,
        "plan": plan,
    }
    if kind == "calibration":
        policy = choose(entries)
        header["policy"] = policy
    else:
        frozen = reference(OUT / "calibration.json")
        receipt = read_json(checked(frozen))
        assert receipt["operator"] == header["operator"]
        policy = receipt["policy"]
        header["calibration"] = frozen
    result = summary(entries, policy)
    print("Choice", policy["primary"]["choice"], "States", result["intact_states"], flush=True)
    for key, row in result["metrics"].items():
        print(
            key,
            {
                m: round(row["means"][m], 6)
                for m in (review.RESPONSE, review.ABS, review.FALSE, review.MISSING)
            },
            "limits",
            result["fits_limits"][key],
            "quiet-max",
            max(row["quiet_added"].values()),
            flush=True,
        )
    write_json(
        OUT / f"{kind}.json",
        header | {"rows": entries, "summary": result, "seconds": monotonic() - begin},
    )


if __name__ == "__main__":
    main(sys.argv[1])
