"""Verify phase isolation over odd Bayer origins and reserve splits."""

from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import leave_out_phase as model
from cab_frequency import recenter

ORIGIN = (151, 149)
FREQUENCY = np.asarray(((0.1171875, 0.07421875), (0.08984375, -0.072265625)))
STATION = (3, 4)
GAIN = 65535
NOISE = (0.00128, 6.5536e-6)


def pack(raw):
    return np.stack([raw[y::2, x::2] for y, x in model._SITES]).astype(np.float32)


def evaluate(raw, layout):
    c, p = model.estimates(raw, ORIGIN, FREQUENCY, *NOISE)
    positions = model._positions(layout, *ORIGIN)
    green = tuple(2 * r + s for r, s in positions)
    return [
        model.pool(c[..., i, :], p[..., i], model.DONORS, frequency, green, 50, 75)
        for i, frequency in enumerate(FREQUENCY)
    ]


def main():
    y, x = np.indices((480, 480), dtype=np.float64)
    waves = [
        0.012 * np.cos(2 * np.pi * (f[0] * x + f[1] * y) + phase)
        for f, phase in zip(FREQUENCY, (0.7, -0.4), strict=True)
    ]
    original = 0.11 + sum(waves)
    x0, y0 = ORIGIN
    row, col = STATION
    start = (y0 + (row - 1) * 16, x0 + (col - 1) * 16)
    whole = np.s_[start[0] : start[0] + 48, start[1] : start[1] + 48]
    modified = original.copy()
    modified[whole] = np.random.default_rng(554).uniform(0.03, 0.21, (48, 48))
    center = row * 10 + col
    outcomes = []
    for pattern, layout in PATTERNS.items():
        m, n = map(pack, (original, modified))
        a, b = (evaluate(raw, layout) for raw in (m, n))
        for (phase, elig), (replacement, fixed) in zip(a, b, strict=True):
            assert elig[center]
            np.testing.assert_array_equal(phase[center], replacement[center])
            assert elig[center] == fixed[center]
        # Perturb only the alternate Bayer reserve pixels in the 160 native crop.
        moved = original.copy()
        yy, xx = np.indices((160, 160))
        alternate = (yy // 2 + xx // 2) % 2 == 1
        current = moved[y0 : y0 + 160, x0 : x0 + 160]
        current[alternate] = np.random.default_rng(904).uniform(0.03, 0.21, alternate.sum())
        _, old = recenter(m, layout, ORIGIN, FREQUENCY, *NOISE)
        _, update = recenter(pack(moved), layout, ORIGIN, FREQUENCY, *NOISE)
        for first, other in zip(old, update, strict=True):
            a, b = first["folds"][0], other["folds"][0]
            np.testing.assert_array_equal(a["candidate"], b["candidate"])
            assert a["candidate_held"] != b["candidate_held"]
        outcomes.append(
            {
                "pattern": pattern,
                "center_phase_bit_identical": True,
                "fixed_discovery_candidate": True,
                "changed_held_score": True,
            }
        )
    write_json(
        model.OUT / "isolation.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "origin": ORIGIN,
            "through_phase_station_row_column": STATION,
            "changed_station_square": [*start[::-1], 48, 48],
            "rows": outcomes,
        },
    )


if __name__ == "__main__":
    main()
