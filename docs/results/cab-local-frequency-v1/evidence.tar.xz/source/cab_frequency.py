"""Choose local narrow-band geometry on one set of Bayer cells and test the other."""

from pathlib import Path

import numpy as np
from scipy.optimize import minimize

from demosaic.mesh_carrier_fit import _positions, _sites

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
SIZE = 160
RADIUS = 0.0039
MAX_DISAGREEMENT = 0.00195
MIN_GAIN = 3.0
Y, X = np.indices((SIZE, SIZE), dtype=np.float64) - (SIZE - 1) / 2
COORDINATES = np.stack((X, Y), axis=-1)
WINDOW = np.outer(np.hanning(SIZE), np.hanning(SIZE))
LOCATIONS = np.indices((SIZE // 2, SIZE // 2))
FOLD = (LOCATIONS[0] + LOCATIONS[1]) % 2
CY, CX = (np.indices((SIZE, SIZE), dtype=np.float64) + 0.5) / SIZE
SMOOTH = np.stack(
    [
        np.cos(np.pi * i * CX) * np.cos(np.pi * j * CY)
        for i in range(7)
        for j in range(7)
        if i * i + j * j <= 36
    ],
    axis=-1,
)


def wave(coordinates, frequency):
    phase = 2 * np.pi * (coordinates @ frequency)
    return np.stack((np.cos(phase), np.sin(phase)), axis=-1)


def folds(scene, colors, origin, shot, read):
    result = [[], []]
    for y, x in _positions(colors, *origin):
        values = _sites(scene, *origin, SIZE, y, x).astype(np.float64)
        coords = COORDINATES[y::2, x::2]
        basis = SMOOTH[y::2, x::2]
        # Use a single variance estimated from the fitting half for both halves.
        var = [
            max(2e-11, shot * max(0.0, float(values[FOLD == i].mean())) + read) for i in range(2)
        ]
        for i in range(2):
            halves = []
            for subset in (i, 1 - i):
                selected = FOLD == subset
                weight = np.sqrt(WINDOW[y::2, x::2][selected] / var[i])
                # A column of known weights allows the fixed sinusoid to use the same taper.
                halves.append(
                    (
                        coords[selected],
                        basis[selected] * weight[:, None],
                        values[selected] * weight,
                        weight,
                    )
                )
            result[i].append(halves)
    return result


class Fit:
    """Weighted native design with all nuisance terms fit on one reserve fold."""

    def __init__(self, data, fixed):
        self.train, self.test = data
        coord, background, obs, root = self.train
        test_coord, test_background, hold, test_root = self.test
        self.a = np.c_[background, self.basis(coord, root, fixed)]
        self.b = np.c_[test_background, self.basis(test_coord, test_root, fixed)]
        inv = np.linalg.pinv(self.a, rcond=1e-8)
        coef = inv @ obs
        self.inv = inv
        self.train_residual = obs - self.a @ coef
        self.test_residual = hold - self.b @ coef

    @staticmethod
    def basis(coord, weight, frequencies):
        return np.concatenate([wave(coord, f) for f in frequencies], axis=-1) * weight[:, None]

    def train_design(self, f):
        raw = wave(self.train[0], f) * self.train[3][:, None]
        adjust = self.inv @ raw
        x = raw - self.a @ adjust
        g = x.T @ x
        beta = np.linalg.solve(g, x.T @ self.train_residual)
        return x, adjust, beta

    def training_gain(self, f):
        x, _, beta = self.train_design(f)
        v = x @ beta
        return float(v @ v)

    def evaluate(self, f):
        x, adjust, beta = self.train_design(f)
        pred = (wave(self.test[0], f) * self.test[3][:, None] - self.b @ adjust) @ beta
        return float((2 * self.test_residual - pred) @ pred), tuple(beta)


def recenter(scene, colors, origin, frequencies, shot, read, *, diagnostics=False):
    measured = folds(scene, colors, origin, shot, read)
    output = frequencies.copy()
    details = []
    for d, original in enumerate(frequencies):
        fixed = frequencies[1 - d : 2 - d]
        predictions = []
        for data in measured:
            fits = [Fit(g, fixed) for g in data]

            def objective(q):
                f = original + 0.001 * q
                return -sum(fit.training_gain(f) for fit in fits)

            result = minimize(
                objective,
                np.zeros(2),
                method="L-BFGS-B",
                bounds=[(-RADIUS / 0.001, RADIUS / 0.001)] * 2,
                options={"ftol": 1e-9, "gtol": 1e-4, "maxiter": 14},
            )
            candidate = original + 0.001 * result.x
            old = [fit.evaluate(original)[0] for fit in fits]
            est = [fit.evaluate(candidate)[0] for fit in fits]
            predictions.append(
                {
                    "candidate": candidate,
                    "old": old,
                    "candidate_held": est,
                    "gain": sum(est) - sum(old),
                    "nondegrading_lattices": sum(
                        bool(a >= b) for a, b in zip(est, old, strict=True)
                    ),
                }
            )
        first, second = (item["candidate"] for item in predictions)
        agreement = float(np.linalg.norm(first - second))
        use = agreement <= MAX_DISAGREEMENT and all(
            p["gain"] >= MIN_GAIN and min(p["candidate_held"]) > 0 for p in predictions
        )
        if use:
            output[d] = (first + second) / 2
        details.append(
            {
                "direction": d,
                "accepted": bool(use),
                "separation": agreement,
                "folds": [p | {"candidate": p["candidate"].tolist()} for p in predictions],
            }
        )
    return output, details


def witness(scene, colors, origin, frequencies, shot, read):
    result = {"base": [], "harmonics": []}
    all_candidates = np.concatenate(
        (2 * frequencies, frequencies[:1] + frequencies[1:], frequencies[:1] - frequencies[1:])
    )
    for fold in folds(scene, colors, origin, shot, read):
        result["base"].append(
            [
                [Fit(g, frequencies[1 - d : 2 - d]).evaluate(f) for g in fold]
                for d, f in enumerate(frequencies)
            ]
        )
        with_base = [Fit(g, frequencies) for g in fold]
        result["harmonics"].append([[p.evaluate(f) for p in with_base] for f in all_candidates])
    return result
