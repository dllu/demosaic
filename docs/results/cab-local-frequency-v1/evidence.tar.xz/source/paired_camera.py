"""Compare native held Bayer evidence and an independent ISO100 phase guide."""

from collections import defaultdict
import json
from pathlib import Path
from statistics import mean

import numpy as np
from scipy.optimize import minimize

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.mesh_carrier_fit import _spacing
from cab_frequency import Fit, OUT, folds, recenter, witness

FIXED = Path("/mnt/external/demosaic/local-optical-mixture-v1/fixed-review/result.json")
MAIN = Path("configs/gfx-qualitative-20231231.json")
CAB = Path("configs/gfx-green-mesh-20231231.json")
FAMILIES = (
    "positive fundamental",
    "negative fundamental",
    "positive second harmonic",
    "negative second harmonic",
    "sum interaction",
    "difference interaction",
)


def parameterized(base):
    return np.concatenate((base, 2 * base, base[:1] + base[1:], base[:1] - base[1:]))


def fixed_from_layout(scene, colors, origin, guide):
    """Fit narrow reference frequencies with their own native Bayer samples."""
    measurements = folds(scene, colors, origin, 0, 1)
    # The ISO100 capture is entirely external to high-ISO held measurements.
    bank = guide.copy()
    for d, f in enumerate(guide):
        fit = [Fit(channel, guide[1 - d : 2 - d]) for group in measurements for channel in group]

        def cost(offset):
            return -sum(model.training_gain(f + 0.001 * offset) for model in fit)

        result = minimize(
            cost,
            np.zeros(2),
            method="L-BFGS-B",
            bounds=[(-3.9, 3.9)] * 2,
            options={"ftol": 1e-13, "gtol": 1e-12, "maxiter": 18},
        )
        bank[d] = f + 0.001 * result.x
    return bank


def combine(w):
    return np.asarray(w["base"] + w["harmonics"], dtype=object)


def closure(terms):
    z = np.asarray(terms)
    p = [
        z[2] * np.conj(z[0]) ** 2,
        z[3] * np.conj(z[1]) ** 2,
        z[4] * np.conj(z[0]) * np.conj(z[1]),
        z[5] * np.conj(z[0]) * z[1],
    ]
    return np.degrees(np.angle(p))


def measure(scene, colors, roi, frequencies, noise):
    h = witness(scene, colors, roi, frequencies, noise["shot"], noise["read"])
    pairs = [a + b for a, b in zip(h["base"], h["harmonics"], strict=True)]
    score = np.array([[sum(item[0] for item in direction) for direction in part] for part in pairs])
    coefficients = np.asarray(
        [[[complex(s, -c) for _, (s, c) in direction] for direction in part] for part in pairs]
    )
    signal = (
        np.sqrt(np.maximum(0, np.real(np.mean(coefficients[0] * coefficients[1].conj(), axis=-1))))
        * 65535
    )
    simple = coefficients.mean(axis=(0, 2))
    return {
        "held": score.tolist(),
        "incoherent_amplitude_DN16": [
            (abs(row).mean(axis=1) * 65535).tolist() for row in coefficients
        ],
        "debiased_native_amplitude_DN16": signal.tolist(),
        "phase_degrees": np.degrees(np.angle(simple)).tolist(),
        "phase_closure_degrees": closure(simple).tolist(),
        "coefficients": [
            [[[z.real, z.imag] for z in channel] for channel in family] for family in coefficients
        ],
    }


def from_center(raw, x, y, n=160):
    crop = raw[y : y + n, x : x + n]
    assert crop.shape == (n, n)
    return np.stack([crop[row::2, col::2] for row, col in np.ndindex(2, 2)])


def local_colors(layout, x, y):
    return tuple(layout[2 * ((y + r) % 2) + (x + c) % 2] for r, c in np.ndindex(2, 2))


def freeze_noisy(plan):
    historical = read_json(checked(plan))
    audit = []
    for item in historical["standing"]:
        f = np.load(checked(item["input"]), allow_pickle=False)
        scene = f["packed"][0]
        colors = f["colors"][0]
        roi = tuple(item["local_ROI"][:2])
        profile = item["noise"]
        current = _spacing(scene, colors, *roi, clearance=16)
        if current is None:
            audit.append({"id": item["id"], "input": item["input"], "prior": None})
            continue
        alternative, terms = recenter(scene, colors, roi, current, profile["shot"], profile["read"])
        audit.append(
            {
                "id": item["id"],
                "input": item["input"],
                "prior": current.tolist(),
                "candidate": alternative.tolist(),
                "reserved_search": terms,
                "held_at_prior": measure(scene, colors, roi, current, profile),
                "held_at_candidate": measure(scene, colors, roi, alternative, profile),
            }
        )
    write_json(
        OUT / "noisy-only.json",
        {
            "driver": reference(__file__),
            "operator": reference(Path(__file__).with_name("cab_frequency.py")),
            "source": plan,
            "families": FAMILIES,
            "rows": audit,
        },
    )


def verify_reference():
    source = reference(OUT / "noisy-only.json")
    before = read_json(checked(source))
    configs = {k: reference(p) for k, p in (("main", MAIN), ("mesh", CAB))}
    m, c = (read_json(checked(configs[k])) for k in ("main", "mesh"))
    receipt = read_json(checked(before["source"]))
    out = []
    decoded = {}
    for frame, p in (("main", m["reference"]), ("mesh", c["sources"]["reference"]["path"])):
        r = reference(p)
        if frame == "mesh":
            assert r["sha256"] == c["sources"]["reference"]["sha256"]
        raw, metadata = read_raw(r["path"])
        assert metadata.iso == 100
        decoded[frame] = raw, tuple(PATTERNS[metadata.pattern]), r
    for old, r in zip(before["rows"], receipt["standing"], strict=True):
        assert old["id"] == r["id"] and old["input"] == r["input"]
        if old["prior"] is None:
            continue
        region = next(
            i
            for i in (m if r["id"].startswith("main") else c)["regions"]
            if r["id"].endswith(i["name"])
        )
        mesh = r["id"].startswith("mesh")
        xy = region["reference_raw_xywh"][:2] if mesh else region["reference_xy"]
        raw, colors, binding = decoded["mesh" if mesh else "main"]
        local = from_center(raw, *xy)
        color = local_colors(colors, *xy)
        guide = np.asarray(old["prior"])
        low = fixed_from_layout(local, color, (0, 0), guide)
        reference_scores = measure(local, color, (0, 0), low, {"shot": 0, "read": 1})
        with np.load(checked(r["input"]), allow_pickle=False) as loading:
            scene = loading["packed"][0]
            cfa = loading["colors"][0]
        profile = r["noise"]
        o = tuple(r["local_ROI"][:2])
        hi = measure(scene, cfa, o, low, profile)
        c1 = np.asarray(reference_scores["phase_degrees"])
        c2 = np.asarray(hi["phase_degrees"])
        error = (c2 - c1 + 180) % 360 - 180
        low_level = float(np.mean(local[[i for i, v in enumerate(color) if v == 1]]))
        high_level = float(
            np.mean(
                from_center(mosaic(scene), *o)[
                    [i for i, v in enumerate(local_colors(tuple(cfa), *o)) if v == 1]
                ]
            )
        )
        out.append(
            {
                "id": r["id"],
                "ref_RAW": binding,
                "ref_ROI_xywh": [*xy, 160, 160],
                "input_ROI": r["global_ROI"],
                "prior_frequency": guide.tolist(),
                "refined_reference_frequency": low.tolist(),
                "offset_cycles_per_pixel": np.linalg.norm(low - guide, axis=-1).tolist(),
                "compare_ref_frequency": hi,
                "ref_coefficients": reference_scores,
                "relative_global_phase_degree": error.tolist(),
                "raw_green_means": {"reference": low_level, "noisy": high_level},
                "noise": profile,
                "input": r["input"],
            }
        )
    write_json(
        OUT / "reference-witness.json",
        {
            "driver": reference(__file__),
            "noisy_witness": source,
            "configurations": configs,
            "families": FAMILIES,
            "rows": out,
            "scope": "ISO100 selects comparison frequencies only. No reference samples enter noisy-only proposals or their validation.",
        },
    )
    for x in out:
        print(
            x["id"],
            np.round(x["refined_reference_frequency"], 6),
            np.round(x["relative_global_phase_degree"], 1),
            "new high held",
            np.round(x["compare_ref_frequency"]["held"], 2),
            "amplitudes",
            np.round(x["compare_ref_frequency"]["debiased_native_amplitude_DN16"], 1),
            np.round(x["ref_coefficients"]["debiased_native_amplitude_DN16"], 1),
            x["raw_green_means"],
            flush=True,
        )


def mosaic(scene):
    _, h, w = scene.shape
    a = np.empty((2 * h, 2 * w), dtype=scene.dtype)
    for i, (r, c) in enumerate(np.ndindex(2, 2)):
        a[r::2, c::2] = scene[i]
    return a


if __name__ == "__main__":
    plan = reference(FIXED)
    freeze_noisy(plan)
    verify_reference()
