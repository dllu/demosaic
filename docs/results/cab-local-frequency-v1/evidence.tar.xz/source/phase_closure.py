"""Test a crossing sideband with phase tied to fundamentals on disjoint Bayer cells."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from cab_frequency import OUT, Fit, folds, wave
from paired_camera import FIXED, parameterized

LABELS = (
    "positive second harmonic",
    "negative second harmonic",
    "sum interaction",
    "difference interaction",
)


def projection(fit, f, unit):
    column = (wave(fit.train[0], f) @ unit) * fit.train[3]
    offset = fit.inv @ column
    filtered = column - fit.a @ offset
    amplitude = float(filtered @ fit.train_residual / max(1e-15, filtered @ filtered))
    prediction = ((wave(fit.test[0], f) @ unit) * fit.test[3] - fit.b @ offset) * amplitude
    gain = float((2 * fit.test_residual - prediction) @ prediction)
    return {"signed_amplitude_DN16": amplitude * 65535, "held_reduction": gain}


def test_value(scene, colors, origin, guide, shot, read):
    test_guides = parameterized(guide)[2:]
    rows = []
    for discovery in folds(scene, colors, origin, shot, read):
        bank = {
            "phase_locked": np.zeros((4, 2)),
            "quadrature": np.zeros((4, 2)),
            "free": np.zeros((4, 2)),
        }
        amplitude = np.zeros((4, 2))
        for lattice, g in enumerate(discovery):
            c = []
            for d, f in enumerate(guide):
                base = Fit(g, guide[1 - d : 2 - d])
                _, (a, b) = base.evaluate(f)
                z = complex(a, -b)
                c.append(z / max(1e-15, abs(z)))
            symmetry = (c[0] ** 2, c[1] ** 2, c[0] * c[1], c[0] * c[1].conjugate())
            model = Fit(g, guide)
            for d, (frequency, z) in enumerate(zip(test_guides, symmetry, strict=True)):
                lock = projection(model, frequency, np.array((z.real, -z.imag)))
                control = projection(model, frequency, np.array((z.imag, z.real)))
                bank["phase_locked"][d, lattice] = lock["held_reduction"]
                bank["quadrature"][d, lattice] = control["held_reduction"]
                bank["free"][d, lattice] = model.evaluate(frequency)[0]
                amplitude[d, lattice] = lock["signed_amplitude_DN16"]
        rows.append(
            {k: v.tolist() for k, v in bank.items()} | {"locked_fit_DN16": amplitude.tolist()}
        )
    return rows


def main():
    source = reference(OUT / "noisy-only.json")
    data = read_json(checked(source))
    fixed = read_json(checked(data["source"]))
    rows = []
    for item, receipt in zip(fixed["standing"], data["rows"], strict=True):
        if receipt["prior"] is None:
            continue
        assert item["id"] == receipt["id"]
        with np.load(checked(item["input"]), allow_pickle=False) as f:
            scene, colors = f["packed"][0], f["colors"][0]
        n = item["noise"]
        terms = test_value(
            scene,
            colors,
            tuple(item["local_ROI"][:2]),
            np.asarray(receipt["prior"]),
            n["shot"],
            n["read"],
        )
        print(
            item["id"],
            [
                (name, np.round(np.sum([a[name] for a in terms], axis=-1), 2).tolist())
                for name in ("phase_locked", "quadrature", "free")
            ],
            flush=True,
        )
        rows.append(
            {
                "id": item["id"],
                "noise": n,
                "input": item["input"],
                "frequency": receipt["prior"],
                "terms": terms,
            }
        )
    write_json(
        OUT / "phase-closure.json",
        {
            "driver": reference(__file__),
            "source": source,
            "labels": LABELS,
            "rows": rows,
            "scope": "Opposed sensor cell folds provide physical relative phase for a signed scalar sideband. Both guides and phase use only the high-ISO RAW.",
        },
    )


if __name__ == "__main__":
    main()
