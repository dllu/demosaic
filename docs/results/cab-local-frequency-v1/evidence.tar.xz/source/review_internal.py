"""Compare the new opt-in mode with the existing crop method on native data."""

from pathlib import Path
from statistics import median
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import leave_out_phase as model
import replay_internal as replay
from check_station_api import call, view

OLD = "weak-replicated-phase"
MODE = "weak-internal-phase"
ARM = "core/center/1.5"
LABELS = {
    "parent": "Local 50k",
    "nested": "Station-capped phase",
    "ring_phase": "Masked internal phase",
}
TRACKED = (
    "src/demosaic/_mesh_internal_phase.py",
    "src/demosaic/_mesh_weak_posterior.py",
    "src/demosaic/mesh_carrier_fit.py",
    "tests/test_mesh_carrier_fit.py",
    "src/demosaic/_mesh_near_phase.py",
)


def check(parent, local, raw, colors, roi, frequency, noise, wb, matrix, *, clearance):
    values, _, trace = model.qualify(
        parent, local, raw, colors, roi, frequency, noise, wb, matrix, clearance=clearance
    )
    output = {}
    seconds = {}
    for name in (OLD, MODE):
        start = monotonic()
        output[name] = call(
            parent, local, raw, colors, roi, noise, wb, matrix, clearance=clearance, method=name
        )
        seconds[name] = monotonic() - start
    errors = {
        name: float(np.max(abs(output[name].astype(np.float64) - values[key])) * 65535)
        for name, key in ((OLD, "near"), (MODE, ARM))
    }
    assert max(errors.values()) < 0.002, (errors, trace)
    changed = not np.array_equal(output[OLD], output[MODE])
    if trace["state"] in ("no frequency", "distant phase already reliable"):
        assert not changed
    return output, {"seconds": seconds, "error_DN16": errors, "changed": changed, "trace": trace}


def arms(parent, local, raw, colors, roi, frequency, noise, wb, matrix, unused):
    values, test = check(
        parent,
        local,
        raw,
        colors,
        roi,
        frequency,
        noise,
        wb,
        matrix,
        clearance=16 if roi == local else 48,
    )
    return {
        "parent": view.section(parent, *local),
        "nested": values[OLD],
        "ring_phase": values[MODE],
    }, test["trace"]


def exact(ref, dest):
    data = read_json(checked(ref))
    noise_rng = read_json(checked(data["plan"]))
    x, y, w, h = noise_rng["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    selected = {}
    for row in data["rows"]:
        for d in row["draws"]:
            if d["evidence"][0]["state"] not in ("ambiguous rank", "ranked phase fallback"):
                continue
            name = "exact gap" if replay.review.MISSING in d["nominal"][ARM] else "continuous"
            gain = (
                d["nominal"][ARM][replay.review.RESPONSE]
                - d["nominal"]["near"][replay.review.RESPONSE]
            )
            if name not in selected or gain > selected[name][0]:
                selected[name] = (gain, row, d)
    assert len(selected) == 2
    results = []
    for name, (gain, row, draw) in selected.items():
        f = model.replay.arrays(draw["input"])
        raw = f["scene_packed"].copy()
        raw[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2] = f["packed"][0]
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")} | {"packed": f["packed"][:1]}
        parent, v120 = (
            np.load(checked(draw["outputs"][k]), allow_pickle=False)[0]
            for k in ("local50k", "v120")
        )
        geo = np.asarray(draw["actual_frequency"])
        outputs, trace = arms(
            parent, local, raw, colors, roi, geo, noise_rng["noise"], wb, matrix, None
        )
        frames = [noisy_malvar(camera)[0], v120]
        for value in outputs.values():
            composed = parent.copy()
            view.section(composed, *local)[:] = value
            frames.append(composed)
        frames.append(f["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(LABELS[k] for k in outputs), "Exact GT"]
        results.append(
            view.native_board(
                dest,
                row["id"],
                frames,
                camera,
                {
                    "input": draw["input"],
                    "fixture": row["fixture"],
                    "noise": noise_rng["noise"],
                    "weights": noise_rng["checkpoints"],
                    "query": noise_rng["query"],
                    "draw": draw["draw"],
                    "optical_sigma": noise_rng["sigma"],
                    "rank": trace,
                    "selection": name,
                    "response_change": gain,
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS["ring_phase"]), len(labels) - 1),
            )
        )
    return {"source": ref, "boards": results}


def api(ref):
    d = read_json(checked(ref))
    plan = read_json(checked(d["plan"]))
    x, y, w, h = plan["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    rows = []
    for row in d["rows"]:
        for draw in row["draws"]:
            f = model.replay.arrays(draw["input"])
            raw = f["scene_packed"].copy()
            parent = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)
            results = []
            for image, packed in zip(parent, f["packed"], strict=True):
                raw[cut] = packed
                frequency = _spacing(raw, f["colors"], *roi[:2], clearance=48)
                _, result = check(
                    image,
                    local,
                    raw,
                    f["colors"],
                    roi,
                    frequency,
                    plan["noise"],
                    f["wb"],
                    f["matrix"],
                    clearance=48,
                )
                results.append(result)
            rows.append({"id": row["id"], "draw": draw["draw"], "results": results})
        if len(rows) % 16 == 0:
            print("Verified", len(rows), "draws", flush=True)
    standing = reference(view.FIXED)
    camera = []
    for item in read_json(checked(standing))["standing"]:
        f = view.arrays(item["input"])
        raw, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(item["local_ROI"])
        parent = np.load(checked(item["predictions"]["local50k"]), allow_pickle=False)[0]
        _, result = check(
            parent,
            roi,
            raw,
            colors,
            roi,
            _spacing(raw, colors, *roi[:2], clearance=16),
            item["noise"],
            wb,
            matrix,
            clearance=16,
        )
        camera.append({"id": item["id"], "results": [result]})
    synth = [v for r in rows for v in r["results"]]
    changed = [v for v in synth if v["changed"]]
    durations = {
        label: {name: 1000 * median(v["seconds"][name] for v in group) for name in (OLD, MODE)}
        for label, group in (("all", synth), ("changed", changed))
    }
    errors = {
        name: max(v["error_DN16"][name] for r in rows + camera for v in r["results"])
        for name in (OLD, MODE)
    }
    print(durations, errors, flush=True)
    return {
        "source": ref,
        "camera_source": standing,
        "camera": camera,
        "exact": rows,
        "maximum_error_DN16": errors,
        "median_cpu_ms": durations,
        "counts": {"exact": len(synth), "changed": len(changed), "camera": len(camera)},
        "production_files": {key: reference(key) for key in TRACKED},
    }


def main(kind):
    torch.set_num_threads(2)
    ref = reference(model.OUT / "independent.json")
    assert read_json(checked(read_json(checked(ref))["calibration"]))["policy"]["primary"][
        "choice"
    ] == [ARM, 1.0]
    dest = model.OUT / "boards" / kind
    dest.mkdir(exist_ok=True, parents=True)
    if kind == "camera":
        view.NAMES = LABELS
        view.arcs = arms
        data = view.standing(None, dest)
    elif kind == "api":
        data = api(ref)
    else:
        data = exact(ref, dest)
    write_json(
        model.OUT / f"{kind}-review.json",
        {"driver": reference(Path(__file__)), "main_source": ref, "data": data},
    )


if __name__ == "__main__":
    main(sys.argv[1])
