"""Measure localized weak evidence at matched recovery and on independent photos."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

import weak_exterior_support as model
from weak_support import OUT
from conditional import replay

PRIOR = OUT.with_name("local-conditional-posterior-v1")
EXTRA = "gap_added_DN16"
LIMIT = 0.75


def assess(case, profile, parent, inputs, scene, cut, roi, sharp, *, oracle=False):
    measured = _spacing(scene, inputs["colors"], *roi[:2], clearance=48)
    exact = np.asarray(case["geometry"]["frequency"])
    frequency = exact if oracle else measured
    color = tuple(inputs[k] for k in ("wb", "matrix"))
    outputs = {k: parent.copy() for k in model.ARMS}
    audit = []
    saved = scene[cut].copy()
    for j, packed in enumerate(inputs["packed"]):
        scene[cut] = packed
        if not j or j == len(inputs["packed"]) - 1:
            np.testing.assert_array_equal(measured, _spacing(scene, inputs["colors"], *roi[:2], clearance=48))
        values, tx = model.qualify(
            parent[j], replay.ROI, scene, inputs["colors"], roi, frequency, profile, *color,
        )
        for k, value in values.items():
            replay.section(outputs[k][j], *replay.ROI)[:] = value
        audit.append(tx)
    scene[cut] = saved

    geometry = case["geometry"]
    support = replay.support_for_scoring(inputs["support"])
    clean = replay.WireFundamental({"target": sharp, "support": support, "wb": color[0], "matrix": color[1]}, geometry)
    optics = replay.WireFundamental(inputs | {"target": inputs["target"][:4], "support": support}, geometry)
    unedited = parent.astype("d")
    combined = outputs["combined"].astype("d")
    region = np.s_[..., 64:192, 64:192]

    def measure(rgb):
        luma = replay.luma((rgb[3:4] - unedited[3:4])[region], *color)
        separate = replay.null_measures(rgb, unedited, inputs) if len(rgb) == 6 else {}
        if optics.gap.any():
            added = replay.luma((rgb[:1] - combined[:1])[region], *color)[0]
            separate[EXTRA] = float(np.sqrt(np.mean(added[optics.gap]**2)) * 65535)
        return {
            **optics(rgb[:4]), replay.ABSOLUTE: clean(rgb[:4])[replay.LENGTH],
            "flat_added_DN16": float(np.sqrt(np.mean(luma**2)) * 65535),
            **separate,
        }

    anchor = measure(combined)
    powers = {}
    for key, restored in outputs.items():
        change = restored - combined
        plus, minus = measure(combined + change), measure(combined - change)
        powers[key] = {
            m: (z, (plus[m] - minus[m]) / 2) if m in replay.LINEAR
            else (z*z, (plus[m]**2 - minus[m]**2) / 2, (plus[m]**2 + minus[m]**2)/2-z*z)
            for m,z in anchor.items()
        }
    return {
        "actual_frequency": None if frequency is None else frequency.tolist(),
        "powers": powers, "evidence": audit,
        "nominal": {k: replay.metrics_at(v, 1) for k,v in powers.items()},
    }


def select(rows):
    base = float(replay.curve(rows, "combined", replay.ABSOLUTE)[-1])
    winner = float(replay.curve(rows, "weak", replay.ABSOLUTE)[-1])
    desired = base + LIMIT * (winner-base)
    accepted = {name: [] for name in model.METHODS}

    def matched(key):
        response = float(replay.curve(rows, key, replay.ABSOLUTE)[-1])
        if response < desired:
            return None
        weight = (desired - base)/(response - base)
        result = [replay.metrics_at(d["powers"][key], weight) for r in rows for d in r["draws"]]
        return {
            "name": key, "weight": weight, "full_response": response,
            "gap_added_DN16": float(np.mean([d[EXTRA] for d in result if EXTRA in d])),
            "false_gap_DN16": float(np.mean([d[replay.FALSE] for d in result if replay.FALSE in d])),
            "flat_added_DN16": float(np.mean([d["flat_added_DN16"] for d in result])),
        }

    control = matched("weak")
    for method, _, _, arm in model.OPTIONS:
        result = matched(arm)
        if result is not None:
            accepted[method].append(result)
    # Select within each guard family by actual added gap RMS at matched recovery.
    return {
        "response_baseline": base, "response_unscaled": winner, "response_matched": desired,
        "control": control, "candidates": accepted,
        "selected": {
            method: min(x, key=lambda r: (r["gap_added_DN16"], r["false_gap_DN16"]))
            for method,x in accepted.items() if x
        },
    }


def main():
    torch.set_num_threads(2)
    start = monotonic()
    replay.comparisons = assess
    replay.OUT = OUT
    name = sys.argv[1] if len(sys.argv) > 1 else "calibration"
    binding = {"driver": reference(Path(__file__)), "operator": reference(model.__file__)}
    if name == "calibration":
        source, rows = replay.load_calibration()
        write_json(OUT / "exterior-calibration.json", binding | {
            "source": source, "rows": rows, "policy": select(rows), "seconds": monotonic()-start,
        })
        return
    registry = {
        "recent": PRIOR / "fresh", "new": OUT / "fresh",
        "retained": OUT.with_name("local-nested-support-v1"),
    }
    replay.PREVIOUS = registry[name]
    checkpoint, plan, rows = replay.load_confirmation()
    write_json(OUT / f"exterior-{name}.json", binding | {
        "source": checkpoint, "plan": plan, "rows": rows,
        "calibration": reference(OUT / "exterior-calibration.json"),
        "seconds": monotonic()-start,
    })


if __name__ == "__main__":
    main()
