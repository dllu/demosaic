"""Separate wider query support from direct coverage of longer planted periods."""

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import sys
import time

import numpy as np
from scipy.optimize import brentq

from demosaic import scene_patch_covariance as patch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
PARENTS = Path("/mnt/external/demosaic") / ROOT.name / "parents.json"
OLDER = ROOT.with_name("scene-patch-crossfit-v1")
sys.path[:0] = [
    str(p)
    for p in (
        ROOT.with_name("scene-mixture-wire-gaps-v1"),
        ROOT.with_name("scene-patch-covariance-v1"),
    )
]
from scoring import WireMetric, SCORED, luma, remove_basis, space
import replay

BANDS = {
    "legacy16": patch.DEFAULT_BAND,
    "mid16": patch.PatchBand(16, 0.08, 0.16),
    "mid32": patch.PatchBand(32, 0.08, 0.16),
    "low32": patch.PatchBand(32, 0.022, 0.08),
}
METHODS = (
    "legacy16",
    "mid16",
    "mid32",
    "low32",
    "low32_diagonal",
    "low32_donor",
    "mid32_plus_low",
    "legacy16_plus_low",
)
LENGTH = "fundamental_response"
FLAT = "exact_flat_RMS_DN16"
COMP = "fundamental_intact_RMS_DN16"
HOLE = "fundamental_false_RMS_DN16"
RESPONSE = (LENGTH, "weak_response_pp")
PROFILE = "iso6400"
QUIET = 0.10


def luminance_corrections(observed, parent, camera, box, profile, exteriors=None):
    shot, read = (profile[k] for k in ("shot", "read"))
    colors = camera["colors"]
    if exteriors is None:
        exteriors = {
            k: patch.build_exterior(camera["scene_packed"], colors, box, shot, read, band=band)
            for k, band in BANDS.items()
        }
    per_scale = {
        k: patch.corrections(
            observed, parent[1], colors, shot, read, box, atlas, validate_donors=True
        )
        for k, atlas in exteriors.items()
    }
    outputs = {k: v["donor_and_query"] for k, v in per_scale.items()}
    b = per_scale["low32"]
    outputs |= {
        "low32_diagonal": b["diagonal_and_query"],
        "low32_donor": b["donor_validated"],
        "mid32_plus_low": outputs["mid32"] + outputs["low32"],
        "legacy16_plus_low": outputs["legacy16"] + outputs["low32"],
    }
    return outputs


def fields_for_record(row, fields, parent):
    p = row["profile"]
    noise = p["shot"], p["read"]
    box = row["box"]
    exteriors = {
        k: patch.build_exterior(fields["scene_packed"], fields["colors"], box, *noise, band=v)
        for k, v in BANDS.items()
    }
    record = {k: [] for k in METHODS}
    for noisy, base in zip(fields["packed"], parent, strict=True):
        for k, pred in luminance_corrections(noisy, base, fields, box, p, exteriors).items():
            record[k].append(
                replay.apply_delta(np.zeros_like(base), pred, fields["wb"], fields["matrix"], 1)
            )
    return {k: np.stack(v) for k, v in record.items()}, {
        k: len(a.coords) if a is not None else 0 for k, a in exteriors.items()
    }


class WireFundamental(WireMetric):
    def __init__(self, data, geo):
        if geo["family"] == "smooth-dip":
            assert np.all(data["support"] > 0)
            data = data | {"support": np.ones_like(data["support"])}
        super().__init__(data, geo)
        y, x = np.meshgrid(np.arange(64, 192) - 127.5, np.arange(64, 192) - 127.5, indexing="ij")
        fx, fy = geo["frequency"][1]
        phase = 2 * np.pi * (fx * x + fy * y)
        trig = np.stack([np.cos(phase), np.sin(phase)])
        self.signed_basis = space(remove_basis(trig[:, self.intact], self.intact_nuisance))
        self.clean_coeff = (self.truth[0] - self.truth[2])[self.intact] @ self.signed_basis
        self.clean_norm = self.clean_coeff @ self.clean_coeff
        assert self.clean_norm > 0
        self.gap_basis = (
            space(remove_basis(trig[:, self.gap], self.gap_nuisance)) if self.gap.any() else None
        )

    def __call__(self, pred):
        metrics = super().__call__(pred)
        image = luma(pred, self.wb, self.matrix)[SCORED]
        out = (image[0] - image[2])[self.intact] @ self.signed_basis
        metrics[LENGTH] = float(100 * out @ self.clean_coeff / self.clean_norm)
        metrics[COMP] = float(
            65535 * np.linalg.norm(out - self.clean_coeff) / np.sqrt(self.intact.sum())
        )
        if self.gap_basis is not None:
            false = (image[0] - self.truth[0])[self.gap] @ self.gap_basis
            metrics[HOLE] = float(65535 * np.linalg.norm(false) / np.sqrt(self.gap.sum()))
        return metrics


def measure_wire(row):
    f, b, v120 = replay.read_inputs(row)
    assert fingerprint(f["packed"]) == row["packed"]
    corrections, windows = fields_for_record(row, f, b)
    with np.load(checked(row["input"]), allow_pickle=False) as r:
        f |= {k: r[k] for k in ("target", "support")}
    metric = WireFundamental(f, row["fixture"]["geometry"])
    parent = b.astype(np.float64)
    origin = metric(parent)
    terms = {}
    for name, delta in corrections.items():
        plus, minus = metric(parent + delta), metric(parent - delta)
        terms[name] = {}
        for k, s in origin.items():
            p, n = plus[k], minus[k]
            terms[name][k] = (
                [s, (p - n) / 2]
                if k in RESPONSE
                else [s**2, (p * p - n * n) / 2, (p * p + n * n) / 2 - s**2]
            )
    gap = int(metric.gap.sum())
    return {
        "case": row,
        "windows": windows,
        "origin": origin,
        "v120": metric(v120),
        "terms": terms,
        "gap_pixels": gap,
    }


def evaluate(rows, callback):
    res = []
    start = time.monotonic()
    with ThreadPoolExecutor(4) as workers:
        for v in workers.map(callback, rows):
            res.append(v)
            if len(res) % 8 == 0:
                print(len(res), round(time.monotonic() - start, 2), flush=True)
    return res, time.monotonic() - start


def values(rows, mode, field, scale):
    if mode in ("origin", "v120"):
        return np.array([r[mode][field] for r in rows])
    vv = np.array([r["terms"][mode][field] for r in rows])
    if field in RESPONSE:
        return vv[:, 0] + scale * vv[:, 1]
    return np.sqrt(np.maximum(vv[:, 0] + scale * (vv[:, 1] + scale * vv[:, 2]), 0))


def settings(rows):
    fitting = {}
    for mode in METHODS:

        def residual(gain):
            return float(np.mean(values(rows, mode, FLAT, gain) - values(rows, "origin", FLAT, 0)))

        quiet = brentq(lambda g: residual(g) - QUIET, 0, 0.8) if residual(0.8) > QUIET else 0.8
        slope = float(np.mean([r["terms"][mode][LENGTH][1] for r in rows]))
        response_gain = min(0.8, 1 / max(slope, 1e-12)) if slope > 0 else 0
        grid = np.unique(np.r_[0, np.linspace(0, quiet, 241)])
        fit = min(
            (g for g in grid if residual(g) <= QUIET),
            key=lambda g: values(rows, mode, COMP, g).mean(),
        )
        fitting[mode] = {
            "quiet": quiet,
            "response": response_gain,
            "fitted": float(fit),
            "flat_at_quiet": residual(quiet),
            "response_at_fixed": response_gain * slope,
        }
    return fitting


def summarize(rows, policy):
    result = {}
    rng = np.random.default_rng(202611191831)
    for op in ("quiet", "response", "fitted"):
        s = {name: policy[name][op] for name in METHODS} | {"origin": 0, "v120": 0}
        result[op] = {}
        for metric in sorted({k for r in rows for k in r["origin"]}):
            used = [r for r in rows if metric in r["origin"]]
            # Each independent background remains a unit of resampling.
            n = len(used)
            indices = np.vstack([np.arange(n), rng.integers(0, n, (8000, n))])
            samples = {
                name: values(used, name, metric, gain)[indices].mean(axis=1)
                for name, gain in s.items()
            }
            body = {}
            for k, v in samples.items():
                differences = {}
                for comparator in ("origin", "legacy16", "mid16", "mid32", "low32_diagonal"):
                    d = v - samples[comparator]
                    differences[comparator] = [
                        float(d[0]),
                        *np.quantile(d[1:], [0.025, 0.975]).tolist(),
                    ]
                body[k] = {"value": float(v[0]), "comparisons": differences, "n": n}
            result[op][metric] = body
    return result


def study():
    model = reference(patch.__file__)
    inputs = reference(PARENTS)
    plan = read_json(checked(inputs))
    assert len(plan["rows"]) == 48
    calibration, cal_time = evaluate(plan["rows"][:16], measure_wire)
    assert {r["case"]["partition"] for r in calibration} == {"calibration"}
    s = settings(calibration)
    lock = ROOT / "frozen-strengths.json"
    write_json(
        lock,
        {
            "driver": reference(__file__),
            "model": model,
            "parents": inputs,
            "settings": s,
            "calibration": calibration,
            "elapsed": cal_time,
            "primary_quiet_target_DN16": QUIET,
        },
    )
    test, duration = evaluate(plan["rows"][16:], measure_wire)
    assert {r["case"]["partition"] for r in test} == {"confirmation"}
    assert sum(r["gap_pixels"] > 0 for r in test) == 16
    for key in ("id", "cache_sha256"):
        ids = lambda group: {r["case"]["source"][key] for r in group}
        assert len(ids(test)) == 32 and not ids(test) & ids(calibration)
    write_json(
        ROOT / "wire-study.json",
        {
            "driver": reference(__file__),
            "calibration": reference(lock),
            "test": test,
            "seconds": duration,
            "summary": summarize(test, s),
            "fixture_metric": reference(sys.modules["scoring"].__file__),
        },
    )


def natural_row(row, settings):
    f, b, baseline = replay.read_inputs(row)
    corr, counts = fields_for_record(row, f, b)
    with np.load(checked(row["input"]), allow_pickle=False) as src:
        exact = replay.transform(src["target"], f)
    former = replay.transform(b, f)
    corrections = {k: replay.transform(v, f) for k, v in corr.items()}
    terms_ = {
        k: {band: replay.terms(f0, v[band], exact[band]) for band, f0 in former.items()}
        for k, v in corrections.items()
    }
    terms_["parent"] = {
        band: replay.terms(f0, np.zeros_like(f0), exact[band]) for band, f0 in former.items()
    }
    if baseline is not None:
        terms_["v120"] = {
            band: replay.terms(f0, np.zeros_like(f0), exact[band])
            for band, f0 in replay.transform(baseline, f).items()
        }
    return {"case": row, "terms": terms_, "windows": counts}


def natural():
    capture = reference("/mnt/external/demosaic/scene-patch-crossfit-v1/parents.json")
    choices = reference(ROOT / "frozen-strengths.json")
    proof = read_json(checked(choices))
    assert proof["driver"] == reference(__file__) and proof["model"] == reference(patch.__file__)
    rows, elapsed = evaluate(
        read_json(checked(capture))["rows"], lambda r: natural_row(r, proof["settings"])
    )
    rng = np.random.default_rng(202611191834)
    samples = np.vstack([np.arange(32), rng.integers(0, 32, (8000, 32))])
    modes = {k: p["quiet"] for k, p in proof["settings"].items()} | {"parent": 0, "v120": 0}
    result = {}
    for band in replay.BANDS:
        result[band] = {}
        for metric in ("present", "flat", "increment", "response"):
            group = {
                k: replay.estimate(replay.arrays(rows, k, band, metric), metric, g, samples)
                for k, g in modes.items()
            }
            result[band][metric] = {
                m: {
                    "value": float(x[0]),
                    "change": [
                        float((x - group["parent"])[0]),
                        *np.quantile((x - group["parent"])[1:], [0.025, 0.975]).tolist(),
                    ],
                }
                for m, x in group.items()
            }
    write_json(
        ROOT / "natural.json",
        {
            "driver": reference(__file__),
            "source": capture,
            "calibration": choices,
            "elapsed": elapsed,
            "rows": rows,
            "summary": result,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("wires", "natural"))
    cmd = parser.parse_args()
    study() if cmd.stage == "wires" else natural()
