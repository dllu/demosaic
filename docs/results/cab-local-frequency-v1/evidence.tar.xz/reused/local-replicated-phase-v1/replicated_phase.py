"""Validate a held center and a disjoint tangent neighbor with fixed Bayer phase."""

from itertools import product
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-unranked-phase-v1"))
import unranked_phase as rank
from unranked_phase import replay

from demosaic._mesh_near_phase import _observations, _pool_phases
from demosaic._mesh_pooled import (
    _CENTERS,
    _SMOOTH,
    _STRIDE,
    _correction,
    _dominant,
    _footprint,
    _inverse,
    _measure_nodes,
    _rgb,
    _wave,
    _windows,
)
from demosaic._mesh_weak_phase import (
    _CELL,
    _GAIN,
    _SIDE,
    _SITES,
    _background,
    _carrier,
    _cells,
    _variance,
)
from demosaic._mesh_weak_posterior import _refine, _weak_correction
from demosaic.mesh_carrier_fit import _POOLED_FOOTPRINT, _ROI_SIZE, _WINDOW, _positions, _sites

METHODS = ("center", "both_greens", "neighbor", "both_and_neighbor")
CUTS = (1.5, 2.0, 2.5, 3.0)
OPTIONS = tuple((method, cut, f"{method}/{cut:g}") for method, cut in product(METHODS, CUTS))
ARMS = ("near", "unchecked", *(key for _, _, key in OPTIONS))
OFFSETS = np.asarray([(-1, 0), (-1, -1), (0, -1), (1, -1)])


def evidence(sites, coefficients, frequencies, direction, greens, shot, read):
    """Return pooled and weaker-green signed scores at each 16-pixel center."""
    wave = _carrier(_ROI_SIZE, 0, 0, frequencies)
    moments, powers = [], []
    for samples, phase, (r, c) in zip(sites, coefficients.transpose(1, 0, 2), _SITES, strict=True):
        values = _cells(samples).astype(np.float64)
        variance = _variance(values.mean(axis=1), shot, read)
        rival = _cells(wave[r::2, c::2, 1 - direction])
        background = _background(_CELL)[r::2, c::2].reshape(1, values.shape[1], 6)
        nuisance = np.concatenate((np.broadcast_to(background, (*values.shape, 6)), rival), axis=-1)
        template = (_cells(wave[r::2, c::2, direction]) @ phase[..., None])[..., 0]
        adjustment = (np.linalg.pinv(nuisance, rcond=1e-8) @ template[..., None])[..., 0]
        template -= np.einsum("npi,ni->np", nuisance, adjustment)
        moments.append(np.einsum("np,np->n", template, values) / variance)
        powers.append(np.einsum("np,np->n", template, template) / variance)
    moment, power = np.asarray(moments), np.asarray(powers)
    individual = moment / np.sqrt(np.maximum(1e-10, power))
    pooled = moment.sum(axis=0) / np.sqrt(np.maximum(1e-10, power.sum(axis=0)))
    weak_green = individual[list(greens)].min(axis=0)
    return np.minimum(pooled, weak_green + 1.5), weak_green


def tangent_neighbor(values, eligible, frequency):
    """Pick a preassigned antipodal pair of native stations along the wire."""
    tangent = frequency * (-1, 1)
    alignment = abs(OFFSETS @ tangent) / np.linalg.norm(OFFSETS, axis=1)
    dy, dx = OFFSETS[np.argmax(alignment)]
    pad = np.pad(
        np.where(eligible, values, -np.inf).reshape(_SIDE, _SIDE), 1, constant_values=-np.inf
    )
    plus = np.s_[1 + dy : 1 + dy + _SIDE, 1 + dx : 1 + dx + _SIDE]
    minus = np.s_[1 - dy : 1 - dy + _SIDE, 1 - dx : 1 - dx + _SIDE]
    return np.maximum(pad[plus], pad[minus]).ravel()


def support(scene, origin, positions, frequency, direction, sites, shot, read):
    donors = _observations(scene, origin, frequency, direction, shot, read)
    if donors is None:
        return None
    greens = tuple(2 * r + c for r, c in positions)
    phases, eligible = _pool_phases(*donors, frequency[direction], greens)
    if not eligible.any():
        return None
    center, weak_green = evidence(sites, phases, frequency, direction, greens, shot, read)
    two_greens = np.minimum(center, 2 * weak_green)
    scores = {"center": center, "both_greens": two_greens}
    for key, initial in (("neighbor", center), ("both_and_neighbor", two_greens)):
        nearby = tangent_neighbor(initial, eligible, frequency[direction])
        scores[key] = np.minimum(initial, nearby + 0.5)
    return eligible, scores


def qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, clearance=48):
    x, y = local[:2]
    anchor = parent[:, y : y + _ROI_SIZE, x : x + _ROI_SIZE]
    empty = dict.fromkeys(ARMS)
    if frequency is None:
        return dict.fromkeys(ARMS, anchor), empty, {"state": "no frequency"}
    context = parent[:, y - 16 : y + 176, x - 16 : x + 176]
    origin = roi[:2]
    shot, read = noise["shot"], noise["read"]
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    positions = _positions(colors, *origin)
    greens = tuple(_footprint(scene, origin, position) for position in positions)
    guides = _wave(_POOLED_FOOTPRINT, frequency)
    power = [
        _dominant(*_measure_nodes(plane, guides, site, shot, read))
        for plane, site in zip(greens, positions, strict=True)
    ]
    prior = _refine(
        anchor,
        context,
        scene,
        colors,
        origin,
        frequency,
        shot,
        read,
        neutral,
        guard_clearance=clearance,
        full_weak_strength=True,
        near_phase=True,
    )
    if power[0] is not None and power[0] == power[1]:
        return dict.fromkeys(ARMS, prior), empty, {"state": "ranked", "rank": power}

    observed = tuple(_windows(g, _WINDOW // 2, _STRIDE // 2) for g in greens)
    wave = _wave(_WINDOW, frequency)
    design = np.concatenate((_SMOOTH, wave.reshape(_WINDOW, _WINDOW, 4)), axis=-1)
    projection = _inverse(design.reshape(_WINDOW**2, -1))[-4:]
    parent_patches = _windows(context[1], _WINDOW, _STRIDE).reshape(len(_CENTERS), -1)
    inherited = np.einsum("dp,np->nd", projection, parent_patches).reshape(-1, 2, 2)
    sites = [_sites(scene, *origin, _ROI_SIZE, r, c) for r, c in _SITES]
    details = []
    contributions = {key: [None, None] for key in ARMS[1:]}
    for direction in range(2):
        previous = _correction(
            wave,
            direction,
            positions,
            observed,
            None,
            parent_patches,
            inherited[:, direction],
            shot,
            read,
        )
        revised = _weak_correction(
            anchor, wave, direction, positions, observed, shot, read, previous, full_strength=True
        )
        difference = _GAIN * _rgb(revised - previous, neutral, np.float64)
        if not difference.any():
            details.append({"eligible": 0, "fields": {key: 0 for key in METHODS}})
            continue
        contributions["unchecked"][direction] = difference
        checks = support(scene, origin, positions, frequency, direction, sites, shot, read)
        if checks is None:
            details.append({"eligible": 0, "fields": {key: 0 for key in METHODS}})
            continue
        eligible, scores = checks
        details.append(
            {
                "eligible": int(eligible.sum()),
                "fields": {key: int((eligible & (s > 1.5)).sum()) for key, s in scores.items()},
            }
        )
        for name, cutoff, key in OPTIONS:
            dose = rank.field(np.where(eligible, np.clip((scores[name] - cutoff) / 2, 0, 1), 0))
            contributions[key][direction] = dose * difference if dose.any() else None

    def render(direction):
        valid = [item for item in direction if item is not None]
        return (prior.astype(np.float64) + sum(valid)).astype(prior.dtype) if valid else prior

    options = {"near": prior} | {key: render(weights) for key, weights in contributions.items()}
    rear = {"near": None} | {key: weights[1] for key, weights in contributions.items()}
    return options, rear, {"state": "ambiguous rank", "rank": power, "directions": details}
