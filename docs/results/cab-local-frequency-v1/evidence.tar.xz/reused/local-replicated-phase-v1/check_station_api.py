"""Compare the public clipped station option to the frozen research operator."""

from pathlib import Path
from statistics import median
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers
import replicated_phase as model
import confirm_station_clip as locked
from review_replicated import select, view

MODE = "weak-replicated-phase"
BASELINE = "weak-near-phase"
PRODUCTION = (
    "src/demosaic/_mesh_near_phase.py",
    "src/demosaic/_mesh_weak_posterior.py",
    "src/demosaic/mesh_carrier_fit.py",
    "tests/test_mesh_carrier_fit.py",
)


def call(parent, local, raw, colors, roi, noise, wb, matrix, *, clearance, method):
    x, y, w, h = local
    crop = parent[:, y : y + h, x : x + w]
    context = parent[:, y - 16 : y + h + 16, x - 16 : x + w + 16]
    return refine_raw_mesh_carriers(
        crop,
        raw,
        colors,
        roi,
        shot=noise["shot"],
        read=noise["read"],
        white_balance=wb,
        camera_to_srgb=matrix,
        method=method,
        parent_context=context,
        donor_clearance=clearance,
    )


def check(parent, local, raw, colors, roi, noise, wb, matrix, choice, *, clearance=48):
    args = (parent, local, raw, colors, roi, noise, wb, matrix)
    frequency = _spacing(raw, colors, *roi[:2], clearance=clearance)
    arm, dose = choice
    family, cut = arm.split("/")
    with (
        patch.object(model.rank, "field", locked.local_cap),
        patch.object(model, "OPTIONS", ((family, float(cut), arm),)),
        patch.object(model, "ARMS", ("near", "unchecked", arm)),
    ):
        values, _, trace = model.qualify(
            parent, local, raw, colors, roi, frequency, noise, wb, matrix, clearance=clearance
        )
    expected = select(values, choice)
    seconds = {}
    output = {}
    for method in (BASELINE, MODE):
        start = monotonic()
        output[method] = call(*args, clearance=clearance, method=method)
        seconds[method] = monotonic() - start
    max_new = float(np.max(abs(output[MODE].astype(np.float64) - expected)) * 65535)
    max_old = float(np.max(abs(output[BASELINE].astype(np.float64) - values["near"])) * 65535)
    assert max_new < 0.002 and max_old < 0.002, (max_new, max_old)
    changed = not np.array_equal(output[BASELINE], output[MODE])
    if trace["state"] != "ambiguous rank":
        assert not changed
    return {
        "maximum_new_DN16": max_new,
        "maximum_baseline_DN16": max_old,
        "state": trace["state"],
        "changed": changed,
        "seconds": seconds,
    }


def main():
    torch.set_num_threads(2)
    source = reference(model.OUT / "station-confirm.json")
    receipt = read_json(checked(source))
    choice = read_json(checked(receipt["preselected_policy"]))["candidate"]
    plan = read_json(checked(receipt["plan"]))
    x, y, w, h = plan["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    rows = []
    for row in receipt["rows"]:
        for draw in row["draws"]:
            data = model.replay.arrays(draw["input"])
            raw = data["scene_packed"].copy()
            result = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)
            records = []
            for parent, pack in zip(result, data["packed"], strict=True):
                raw[cut] = pack
                records.append(
                    check(
                        parent,
                        local,
                        raw,
                        data["colors"],
                        roi,
                        plan["noise"],
                        data["wb"],
                        data["matrix"],
                        choice,
                    )
                )
            rows.append({"id": row["id"], "draw": draw["draw"], "results": records})
        if len(rows) % 16 == 0:
            print("Checked", len(rows), "draws", flush=True)
    fixed = reference(view.FIXED)
    camera = []
    for row in read_json(checked(fixed))["standing"]:
        f = view.arrays(row["input"])
        roi = tuple(row["local_ROI"])
        colors, wb, matrix, raw = (f[k][0] for k in ("colors", "wb", "matrix", "packed"))
        result = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        camera.append(
            {
                "id": row["id"],
                "results": [
                    check(
                        result,
                        roi,
                        raw,
                        colors,
                        roi,
                        row["noise"],
                        wb,
                        matrix,
                        choice,
                        clearance=16,
                    )
                ],
            }
        )
    all_synthetic = [r for row in rows for r in row["results"]]
    changed = [r for r in all_synthetic if r["changed"]]
    selected = [r for r in all_synthetic if r["state"] == "ambiguous rank"]
    timing = {
        label: {
            method: 1000 * median(r["seconds"][method] for r in batch)
            for method in (BASELINE, MODE)
        }
        for label, batch in (
            ("all", all_synthetic),
            ("rank_ambiguous", selected),
            ("changed", changed),
        )
        if batch
    }
    stats = {
        k: max(r[k] for row in rows + camera for r in row["results"])
        for k in ("maximum_new_DN16", "maximum_baseline_DN16")
    }
    write_json(
        model.OUT / "api-proof.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "standing": fixed,
            "preselected_policy": receipt["preselected_policy"],
            "production_files": {p: reference(p) for p in PRODUCTION},
            "real": camera,
            "synthetic": rows,
            "counts": {
                "real": len(camera),
                "synthetic": len(all_synthetic),
                "rank_ambiguous": len(selected),
                "changed": len(changed),
            },
            "times_ms_median": timing,
            "parity": stats,
        },
    )
    print(stats, timing, flush=True)


if __name__ == "__main__":
    main()
