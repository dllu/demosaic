"""Lock a detector using only calibration sources, including active true gaps."""

from collections import Counter
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replicated_phase as model
from replicated_phase import OUT, replay
from reduce_support import ABS, ADDED, FALSE, GAP, QUIET, RESPONSE
from evaluate_ring import source_bootstrap, interval
import replay_exterior_support as scoring

MISSING = "absent_direction_added_DN16"
CONTROLS = {
    "mean_absent_DN16": 0.2,
    "peak_absent_DN16": 2.0,
    "mean_extra_false_projection_DN16": 0.025,
    "peak_added_quiet_DN16": 0.6,
}
METRICS = (RESPONSE, ABS, GAP, FALSE, ADDED, MISSING, *QUIET)


def evaluate(fixture, noise, pred, data, scene, cut, roi):
    directions = []

    class Adapter:
        ARMS = ("combined", *model.ARMS)

        @staticmethod
        def qualify(*args, **kwargs):
            results, contribution, trace = model.qualify(*args, **kwargs)
            directions.append(contribution)
            return {"combined": results["near"], **results}, trace

    scoring.model = Adapter
    result = scoring.assess(fixture, noise, pred, data, scene, cut, roi, data["sharp_target"])
    if ADDED not in result["nominal"]["near"]:
        return result
    support = replay.support_for_scoring(data["support"])
    optics = replay.WireFundamental(
        data | {"target": data["target"][:4], "support": support}, fixture["geometry"]
    )
    for arm, rgb in directions[0].items():
        component = 0.0
        if rgb is not None:
            field = replay.luma(rgb[None, :, 16:144, 16:144], data["wb"], data["matrix"])[0]
            component = float(np.sqrt(np.mean(field[optics.gap] ** 2)) * 65535)
        assert np.isfinite(component)
        result["nominal"][arm][MISSING] = component
        result["powers"][arm][MISSING] = (0, 0, component**2)
    result["nominal"]["combined"][MISSING] = 0.0
    result["powers"]["combined"][MISSING] = (0.0, 0.0, 0.0)
    return result


def load(kind):
    source = reference(OUT / kind / "parent" / "result.json")
    parent = read_json(checked(source))
    inputs = read_json(checked(parent["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    local = replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    rows = []
    for fixture, entity in zip(plan["sources"], parent["records"], strict=True):
        assert fixture["id"] == entity["id"]
        draws = []
        for stream in entity["streams"]:
            data = replay.arrays(stream["data"])
            pred = np.load(checked(stream["outputs"]["local50k"]), allow_pickle=False)
            result = evaluate(
                fixture, plan["noise"], pred, data, data["scene_packed"].copy(), cut, roi
            )
            draws.append(
                result
                | {"input": stream["data"], "outputs": stream["outputs"], "draw": stream["draw"]}
            )
        rows.append(
            {
                "id": fixture["id"],
                "fixture": fixture,
                "family": fixture["geometry"]["family"],
                "draws": draws,
            }
        )
        if len(rows) % 8 == 0:
            print("Replayed", kind, len(rows), flush=True)
    return rows, source, inputs["plan"]


def arm_stats(rows, choice):
    name, dose = choice
    power = [draw["powers"][name] for row in rows for draw in row["draws"]]
    values = [replay.metrics_at(v, dose) for v in power]
    average = {
        key: mean(v[key] for v in values if key in v)
        for key in METRICS
        if any(key in v for v in values)
    }
    peak = {key: max(v[key] for v in values if key in v) for key in (ADDED, MISSING, *QUIET)}
    quiet_added = {
        key: float(dose * np.sqrt(max(0.0, max(v[key][2] for v in power)))) for key in QUIET
    }
    return {"means": average, "peak": peak, "quiet_added": quiet_added}


def within(record, anchor):
    m, p, q = record["means"], record["peak"], record["quiet_added"]
    return (
        m[MISSING] <= CONTROLS["mean_absent_DN16"]
        and p[MISSING] <= CONTROLS["peak_absent_DN16"]
        and m[FALSE] - anchor["means"][FALSE] <= CONTROLS["mean_extra_false_projection_DN16"]
        and max(q.values()) <= CONTROLS["peak_added_quiet_DN16"]
    )


def lock(rows):
    near = arm_stats(rows, ("near", 1))
    options = {}
    for method, cut, key in model.OPTIONS:
        records = []
        for dose in np.linspace(0.05, 1, 20).tolist():
            path = (key, dose)
            stats = arm_stats(rows, path)
            records.append(
                {"choice": path, "statistics": stats, "within": bool(within(stats, near))}
            )
        options[key] = records

    def best(keys):
        verified = [p for key in keys for p in options[key] if p["within"]]
        if not verified:
            return {"choice": ("near", 1), "statistics": near, "within": True}
        return max(
            verified,
            key=lambda v: (v["statistics"]["means"][RESPONSE], -v["statistics"]["means"][MISSING]),
        )

    methods = {
        method: best(key for name, _, key in model.OPTIONS if method == name)
        for method in model.METHODS
    }
    alternatives = [methods[key] for key in model.METHODS if key != "center"]
    ordered = lambda v: (v["statistics"]["means"][RESPONSE], -v["statistics"]["means"][MISSING])
    return {
        "budgets": CONTROLS,
        "primary": max(alternatives, key=ordered),
        "per_family": methods,
        "options": options,
    }


def paired(rows, first, second):
    result = {}
    for key in METRICS:
        chosen, diffs = [], []
        for row in rows:
            draws = [d for d in row["draws"] if key in d["powers"][first[0]]]
            if draws:
                chosen.append(row)
                diffs.append(
                    mean(
                        replay.metrics_at(d["powers"][first[0]], first[1])[key]
                        - replay.metrics_at(d["powers"][second[0]], second[1])[key]
                        for d in draws
                    )
                )
        if diffs:
            draws = source_bootstrap(chosen, np.random.default_rng(202611200605))
            result[key] = {
                "sources": len(chosen),
                "paired_interval": interval(np.asarray(diffs)[draws].mean(axis=1)),
            }
    return result


def summary(rows, policy):
    choices = {
        "near": ("near", 1),
        "previous": ("center/1.5", 1),
        "unchecked": ("unchecked", 1),
        "primary": policy["primary"]["choice"],
    } | {key: row["choice"] for key, row in policy["per_family"].items()}
    scores = {key: arm_stats(rows, choice) for key, choice in choices.items()}
    reference_stats = scores["near"]
    effects = {
        key: paired(rows, choice, choices["near"])
        for key, choice in choices.items()
        if key != "near"
    }
    baseline_response = scores["near"]["means"][RESPONSE]
    matched = {}
    for key in ("previous", "center", "unchecked"):
        current = choices[key]
        denominator = arm_stats(rows, (current[0], 1))["means"][RESPONSE] - baseline_response
        numerator = scores["primary"]["means"][RESPONSE] - baseline_response
        if denominator > 0 and 0 <= numerator / denominator <= 1:
            path = (current[0], numerator / denominator)
            matched[key] = {
                "choice": path,
                "statistics": arm_stats(rows, path),
                "primary_vs_matched": paired(rows, choices["primary"], path),
            }
    counts = {
        str(i): dict(Counter(d["evidence"][i]["state"] for row in rows for d in row["draws"]))
        for i in range(6)
    }
    active_gap = sum(
        MISSING in d["nominal"]["near"] and d["evidence"][0]["state"] == "ambiguous rank"
        for r in rows
        for d in r["draws"]
    )
    return {
        "choices": choices,
        "scores": scores,
        "within_budgets": {k: bool(within(v, reference_stats)) for k, v in scores.items()},
        "vs_near": effects,
        "equal_response": matched,
        "states": counts,
        "ambiguous_intact_draws_with_exact_gaps": active_gap,
    }


def main(kind):
    torch.set_num_threads(2)
    start = monotonic()
    rows, source, plan = load(kind)
    binding = {"driver": reference(Path(__file__)), "operator": reference(model.__file__)}
    if kind == "calibration":
        policy = lock(rows)
        binding["policy"] = policy
    else:
        reference_lock = reference(OUT / "calibration.json")
        previous = read_json(checked(reference_lock))
        assert previous["operator"] == binding["operator"]
        policy = previous["policy"]
        binding["calibration"] = reference_lock
    report = summary(rows, policy)
    print(
        "choice",
        policy["primary"]["choice"],
        "states",
        report["states"]["0"],
        "ambiguous exact-gap draws",
        report["ambiguous_intact_draws_with_exact_gaps"],
        flush=True,
    )
    for key, stats in report["scores"].items():
        print(
            key,
            {m: round(stats["means"][m], 5) for m in (RESPONSE, ABS, FALSE, MISSING, ADDED)},
            "peak missing",
            round(stats["peak"][MISSING], 5),
            "peak quiet",
            stats["quiet_added"],
            "pass",
            report["within_budgets"][key],
            flush=True,
        )
    write_json(
        OUT / f"{kind}.json",
        binding
        | {
            "source": source,
            "plan": plan,
            "rows": rows,
            "summary": report,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
