"""Freeze novel photos, fixed gates and independent RAW draws for a local support test."""

from collections import Counter
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(CACHE / "local-optical-mixture-v1"))
from freeze_confirmation import FAMILIES, ROLE_NAMES, capture_wide, carrier, filtered_observation
from review_optical import bindings

SOURCE = CACHE / "local-optical-mixture-v1"
REGIONAL = CACHE / "local-regional-wire-v1"
PANEL = Path("/mnt/external/demosaic/local-exterior-phase-transfer-v1/parent/result.json")
CUTOFF = Path("docs/results/local-center-guard-v1/cutoffs.json")
COUNT = 32
GROUP_SIZE = COUNT // len(FAMILIES)
SEED = 202611200113
SIGMA = .85
ROLES = (*ROLE_NAMES, "edge-only", "uniform")
REPEATS = (0, 1)
NATIVE = (1, 9)
POLICIES = {
    "broad": {"outer_cutoff": 6.0},
    "center3": {"center_cutoff": 3.0},
    "nested": {"outer_cutoff": 6.0, "center_cutoff": 1.5},
    "center1.5": {"center_cutoff": 1.5},
}


def choose():
    train_ref = reference(SOURCE / "plan.json")
    train = read_json(checked(train_ref))
    prior_plan = reference(SOURCE / "confirmation-plan.json")
    prior = read_json(checked(prior_plan))
    related_source = reference(PANEL)
    legacy = read_json(checked(related_source))
    assert legacy["checkpoint"] == train["parent"]
    regional_ref = reference(REGIONAL / "plan-v3.json")
    regional = read_json(checked(regional_ref))
    reg_inputs = reference(REGIONAL / "review-inputs.json")
    refs = [*prior["excluded_sources"], prior_plan, reg_inputs, *regional["schedule"].values()] if isinstance(regional.get("schedule"), dict) and all(isinstance(v, dict) and "path" in v for v in regional["schedule"].values()) else [*prior["excluded_sources"], prior_plan, reg_inputs]
    refs += [*train["schedule"].values(), train["review_inputs"]]
    blocked = set()
    for ref in refs:
        local = checked(ref)
        if local.suffix == ".jsonl":
            for row in capture_wide.lines(ref):
                capture_wide.scan(row, blocked)
        else:
            capture_wide.scan(read_json(local), blocked)
    for group in legacy["panels"].values():
        capture_wide.scan([p["case"]["fixture"]["source"] for p in group["rows"]], blocked)
    # The regional schedule uses the same source groups as the mixed continuation.
    eligible = [
        r for r in capture_wide.lines(prior["source_pool"])
        if r["split"] == "val" and r["bin_factor"] == 4 and min(r["shape"][:2]) >= 512
        and {r["id"], r["cache_sha256"]}.isdisjoint(blocked)
    ]
    eligible.sort(key=lambda row: sha256(f"nested/{SEED}/{row['id']}".encode()).digest())
    chosen = []
    profile = prior["camera_profile"]
    capture_wide.SEED = SEED
    for row in eligible:
        markers = {row["id"], row["cache_sha256"]}
        if not markers.isdisjoint(blocked):
            continue
        blocked.update(markers)
        i = len(chosen)
        case_id = f"nested-{i:02d}"
        (box,) = scene_crop_boxes(row["shape"][:2], patch_size=512, count=1,
                                   seed=scene_seed(SEED, i, "crop"))
        camera = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        camera.update(pattern=tuple(PATTERNS)[i % 4], black=.03,
                      **{k: profile[k] for k in ("shot", "read", "exposure")})
        rng = np.random.default_rng(scene_seed(SEED, i, "carrier"))
        g = capture_wide.geometry(i)
        g.update(family=FAMILIES[i // GROUP_SIZE],
                 frequency=[carrier(rng, 1, (6.9, 9.4)), carrier(rng, -1, (6.9, 9.4))],
                 strength=rng.uniform([.009, .0027], [.016, .009]).tolist(),
                 gap_width=float(rng.uniform(22, 32)), gap_length=float(rng.uniform(34, 54)),
                 tint=rng.uniform(.045, .145, 3).tolist())
        chosen.append({"id": case_id, "source": row, "box": box, "camera": camera, "geometry": g, "index": i})
        if len(chosen) == COUNT:
            break
    assert len(chosen) == COUNT and len({r["source"]["cache_sha256"] for r in chosen}) == COUNT
    chosen_ids = {row["source"][k] for row in chosen for k in ("id", "cache_sha256")}
    prior_file = read_json(checked(prior["reference_wire_panel"]))
    panel = read_json(checked(prior_file["plan"]))
    visits = 0
    trace = read_json(checked(panel["parent_traces"]))
    for binding in trace["source_traces"]:
        for record in capture_wide.lines(binding):
            for source in record["sources"]:
                if source["kind"] == "photographic":
                    assert chosen_ids.isdisjoint((source["source_id"], source["cache_sha256"]))
                    visits += 1
    assert visits == prior["archive_photo_visits_checked"]
    _, comparisons = bindings(train)
    return {
        "driver": reference(__file__), "source_pool": prior["source_pool"], "seed": SEED,
        "earlier_photos_excluded": related_source, "excluded_manifests": refs,
        "training_plan": train_ref, "regional_plan": regional_ref,
        "parent_trace": panel["parent_traces"], "training_photo_visits_audited": visits,
        "source_count": COUNT, "family_counts": dict(Counter(r["geometry"]["family"] for r in chosen)),
        "sources": chosen, "roles": ROLES, "redraws": REPEATS, "noise": profile, "sigma": SIGMA,
        "native_indices": NATIVE, "query": capture_wide.QUERY, "checkpoints": comparisons,
        "known_center3_calibration": reference(CUTOFF), "policies": POLICIES, "sources_are_val": True,
        "primary": "Center3 vs broad at locked response weights, on mean continuance RMS over the two fresh draws",
        "hypothesis": "Adding broad support as a cap to center 1.5 should contain null activations at greater recovery than center3.",
    }


def capture(fixture, profile, path):
    photo = capture_wide.wire_math.decode(fixture["source"], fixture["box"])
    geo, i = fixture["geometry"], fixture["index"]
    targets, _, support, _ = capture_wide.wire_math.exact(photo, geo)
    edge = capture_wide.wire_math.exact(photo, geo | {"strength": [0., 0.]})[0][2]
    flat = torch.ones_like(edge) * edge[..., 176:336, 176:336].mean((-2, -1), keepdim=True)
    sources = (*targets, edge, flat)
    recipe = replace(sample_scene_recipe(SEED), **fixture["camera"])
    noisy = np.s_[..., 64:192, 64:192]
    rgb = np.s_[..., 128:384, 128:384]
    keys = ("colors", "wb", "matrix")
    clean = []
    # The exact sharp targets are required for normalization only.
    for j, source in enumerate(sources[:4]):
        obs = filtered_observation(source, recipe, 0.)
        clean.append(getattr(obs, "target").numpy()[rgb])
    shared_support = support.numpy()[rgb]
    streams = []
    for draw in REPEATS:
        seeds = [scene_seed(SEED, i*len(ROLES)+j, f"fresh-read-and-shot-{draw}") for j in range(len(ROLES))]
        assert len(set(seeds)) == len(ROLES)
        samples = [filtered_observation(v, replace(recipe, noise_seed=seed), SIGMA)
                   for v, seed in zip(sources, seeds, strict=True)]
        data = {key: getattr(samples[0], key).numpy() for key in keys}
        for sample in samples[1:]:
            assert all(np.array_equal(data[k], getattr(sample, k).numpy()) for k in keys)
        values = {"packed": noisy, "variance": noisy, "target": rgb}
        for key, box in values.items():
            data[key] = np.stack([getattr(obs, key).numpy()[box] for obs in samples])
        data["scene_packed"] = samples[1].packed.numpy()
        np.testing.assert_array_equal(data["packed"][1], data["scene_packed"][noisy])
        data["support"] = shared_support
        data["sharp_target"] = np.stack(clean)
        assert all(np.isfinite(v).all() for v in data.values())
        out = path / f"{fixture['id']}-draw{draw}.npz"
        if not out.exists():
            with out.open("xb") as f:
                np.savez(f, **data)
        else:
            with np.load(out, allow_pickle=False) as prior:
                for k, v in data.items():
                    np.testing.assert_array_equal(prior[k], v)
        streams.append({"data": reference(out), "draw": draw, "noise_seeds": seeds})
    assert len(set(streams[0]["noise_seeds"] + streams[1]["noise_seeds"])) == 2 * len(ROLES)
    return {"id": fixture["id"], "streams": streams}


if __name__ == "__main__":
    torch.set_num_threads(2)
    start = time.monotonic()
    master = OUT / "plan.json"
    if master.is_file():
        plan = read_json(master)
        assert plan["driver"] == reference(__file__)
    else:
        plan = choose()
        write_json(master, plan)
    destination = OUT / "inputs"
    destination.mkdir(exist_ok=True)
    generated = []
    for fixture in plan["sources"]:
        generated.append(capture(fixture, plan["noise"], destination))
        if len(generated) % 8 == 0:
            print("Captured", len(generated), flush=True)
    write_json(OUT / "inputs.json", {
        "plan": reference(master), "observations": generated, "seconds": time.monotonic()-start,
    })
