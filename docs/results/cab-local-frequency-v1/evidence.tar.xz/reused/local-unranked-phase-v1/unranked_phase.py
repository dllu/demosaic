"""Check each candidate on nearby held native Bayer samples without global rank."""

from itertools import product
from pathlib import Path
import sys

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.ndimage import map_coordinates

from demosaic._mesh_near_phase import _observations, _pool_phases, _signed_evidence
from demosaic._mesh_pooled import (
    _CENTERS, _CORE, _SMOOTH, _STRIDE, _correction, _dominant, _footprint,
    _inverse, _measure_nodes, _rgb, _wave, _windows,
)
from demosaic._mesh_weak_phase import _CELL, _GAIN, _PIXEL_COORDS, _SIDE, _SITES, _background, _carrier, _variance
from demosaic._mesh_weak_posterior import _refine, _weak_correction
from demosaic.mesh_carrier_fit import _POOLED_FOOTPRINT, _ROI_SIZE, _WINDOW, _positions, _sites

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-near-phase-v1"))
from near_phase import replay

METHODS = ("collar", "ring", "tangent", "bilateral")
CUTS = (1.5, 2.5, 3.5)
OPTIONS = tuple((name, cut, f"{name}/{cut:g}") for name, cut in product(METHODS, CUTS))
ARMS = ("combined", "near", "unverified", *(key for _, _, key in OPTIONS))
RING = 64
HALO = (RING - _CELL) // 2
CENTER_INDICES = np.indices((_SIDE, _SIDE)).reshape(2, -1).T * _CELL
DONOR_YX = np.moveaxis(np.indices((RING, RING), dtype=np.float64), 0, -1) - (RING - 1) / 2
DONOR_MASK = abs(DONOR_YX).max(axis=-1) >= 16


def center_bands(scene, origin, frequencies, direction):
    normal = frequencies[direction, ::-1]
    normal = normal / np.linalg.norm(normal)
    tangent = normal[::-1] * np.array((-1.0, 1.0))
    along = DONOR_YX @ tangent
    across = DONOR_YX @ normal
    weight = np.exp(-0.5 * ((along / 22) ** 2 + (across / 12) ** 2))
    ring = DONOR_MASK.astype(np.float64)
    masks = (ring, ring * weight, ring * weight * (along < 0), ring * weight * (along >= 0))
    design = np.concatenate((_background(RING), _carrier(RING, -HALO, -HALO, frequencies).reshape(RING, RING, 4)), axis=-1)
    rotation = 2 * np.pi * (CENTER_INDICES @ frequencies[direction, ::-1])
    # Convert relative wave coefficients to the ROI's absolute coordinate origin.
    rotor = np.exp(1j * rotation)
    donor_data = []
    for r, c in _SITES:
        raw = _sites(scene, origin[0] - HALO, origin[1] - HALO, _ROI_SIZE + 2 * HALO, r, c)
        if raw.shape != ((88 + 16), (88 + 16)) or not np.isfinite(raw).all():
            return None
        windows = sliding_window_view(raw, (RING//2, RING//2))[::_CELL//2, ::_CELL//2]
        keep = DONOR_MASK[r::2, c::2]
        values = windows.reshape(_SIDE**2, RING//2, RING//2)[:, keep].astype(np.float64)
        columns = design[r::2, c::2][keep]
        estimates = []
        for spatial in masks:
            root = np.sqrt(spatial[r::2, c::2][keep])
            inverse = np.linalg.pinv(root[:, None] * columns, rcond=1e-8)
            projection = inverse[6 + 2 * direction : 8 + 2 * direction] * root
            coefficients = values @ projection.T
            vector = (coefficients[:, 0] + 1j * coefficients[:, 1]) * rotor
            estimates.append((np.stack((vector.real, vector.imag), axis=-1),
                              np.square(projection).sum(axis=-1).mean()))
        donor_data.append((values.mean(axis=-1), estimates))
    return donor_data


def middle_phases(data, green, shot, read):
    variance = np.stack([_variance(mean, shot, read) for mean, _ in data], axis=1)
    coeff = np.array([[estimate[0] for estimate in estimates] for _, estimates in data]).transpose(1, 2, 0, 3)
    noise = np.array([[estimate[1] for estimate in estimates] for _, estimates in data]).T[:, None] * variance
    norm = np.linalg.norm(coeff, axis=-1)
    unit = coeff / np.maximum(1e-15, norm[..., None])
    agreement = (unit[:, :, green[0]] * unit[:, :, green[1]]).sum(axis=-1)
    power = norm**2 / noise
    reliable = power >= 16
    green_ok = reliable[:, :, green].all(axis=-1) & (agreement >= 0.5)
    sides_agree = (unit[2] * unit[3]).sum(axis=-1)
    both = (power[2:, :, green] >= 6.25).all(axis=(0, 2)) & (sides_agree[:, green] >= 0.5).all(axis=-1)
    phases = np.where(reliable[..., None], coeff, 0)
    return {"ring":(phases[0], green_ok[0]), "tangent":(phases[1], green_ok[1]),
            "bilateral":(phases[1], green_ok[1] & both)}


def field(stations):
    return map_coordinates(stations.reshape(_SIDE, _SIDE), _PIXEL_COORDS, order=1,
                           mode="nearest", prefilter=False)


def qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, clearance=48):
    x, y = local[:2]
    anchor = parent[:, y:y + _ROI_SIZE, x:x + _ROI_SIZE]
    if frequency is None:
        return dict.fromkeys(ARMS, anchor), {"state": "no frequency"}
    context = parent[:, y - 16:y + 176, x - 16:x + 176]
    origin = roi[:2]
    shot, read = noise["shot"], noise["read"]
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    positions = _positions(colors, *origin)
    greens = tuple(_footprint(scene, origin, position) for position in positions)
    guides = _wave(_POOLED_FOOTPRINT, frequency)
    rank = [_dominant(*_measure_nodes(plane, guides, site, shot, read))
            for plane, site in zip(greens, positions, strict=True)]
    prior = _refine(anchor, context, scene, colors, origin, frequency, shot, read, neutral,
                    guard_clearance=clearance, full_weak_strength=True, near_phase=True)
    if rank[0] is not None and rank[0] == rank[1]:
        return dict.fromkeys(ARMS, prior) | {"combined": prior}, {"state": "ranked", "rank": rank}

    observed = tuple(_windows(g, _WINDOW // 2, _STRIDE // 2) for g in greens)
    wave = _wave(_WINDOW, frequency)
    design = np.concatenate((_SMOOTH, wave.reshape(_WINDOW, _WINDOW, 4)), axis=-1)
    projection = _inverse(design.reshape(_WINDOW**2, -1))[-4:]
    parent_patches = _windows(context[1], _WINDOW, _STRIDE).reshape(len(_CENTERS), -1)
    inherited = np.einsum("dp,np->nd", projection, parent_patches).reshape(-1, 2, 2)
    additions = {key: np.zeros_like(prior, dtype=np.float64) for key in ARMS}
    trace = {"state": "ambiguous rank", "rank": rank, "directions": []}
    sites = [_sites(scene, *origin, _ROI_SIZE, r, c) for r, c in _SITES]
    green = tuple(2 * r + c for r, c in positions)
    for direction in range(2):
        base = _correction(wave, direction, positions, observed, None, parent_patches,
                           inherited[:, direction], shot, read)
        revised = _weak_correction(anchor, wave, direction, positions, observed, shot, read, base,
                                   full_strength=True)
        difference = _rgb(revised - base, neutral, np.float64)
        data = center_bands(scene, origin, frequency, direction)
        closure = _observations(scene, origin, frequency, direction, shot, read)
        if data is None or closure is None:
            continue
        donors = middle_phases(data, green, shot, read)
        donors["collar"] = _pool_phases(*closure, frequency[direction], green)
        support = {}
        for name, (phase, eligible) in donors.items():
            scores = _signed_evidence(sites, phase, frequency, direction, green, shot, read)
            support[name] = eligible, scores
        audit = {"posterior_RGB_RMS_DN16": float(np.sqrt(np.mean(difference**2))*65535),
                 "donors": {key: {"eligible": int(ok.sum()), "above_2_5": int((ok & (z > 2.5)).sum()),
                                  "peak": float(z[ok].max()) if ok.any() else None}
                            for key, (ok, z) in support.items()}}
        trace["directions"].append(audit)
        additions["unverified"] += _GAIN * difference
        for name, cut, key in OPTIONS:
            eligible, score = support[name]
            weight = field(np.where(eligible, np.clip((score - cut) / 2, 0, 1), 0))
            additions[key] += _GAIN * weight * difference
    return {key: (prior.astype(np.float64) + delta).astype(prior.dtype) for key, delta in additions.items()}, trace
