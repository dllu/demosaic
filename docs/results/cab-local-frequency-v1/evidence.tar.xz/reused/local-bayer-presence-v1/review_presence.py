"""Render selected Bayesian and conventional fits at identical native coordinates."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import presence_guarded as guarded
import replay_presence as replay
from evaluate_ring import FIXED, ROI, arrays, display, native_board
from score_nested_clearance48 import section

NAMES = {
    "parent": "Local 50k",
    "broad": "Broad check",
    "nested": "Combined check",
    "local": "Center posterior",
    "ring_power": "Ring power prior",
    "ring_phase": "Ring phase prior",
}
SELECTED = ("presence-01", "presence-09")


def arcs(parent, local, scene, colors, roi, peaks, profile, wb, matrix, policy):
    old = section(parent, *local)
    guide, conventional = replay.nested_apply(
        parent, local, scene, colors, roi, peaks, profile | {"wb": wb, "matrix": matrix}
    )
    _, candidates, diagnostics = guarded.fit(
        parent, local, scene, colors, roi, peaks, profile["shot"], profile["read"], wb, matrix,
    )
    measured = {
        k: old + np.float32(policy["choices"][v]["weight"]) * (candidates[v] - old)
        for k, v in policy["best"].items()
    }
    return {"parent": old, "broad": guide["broad"], "nested": guide["nested"]} | measured, {
        "baseline": conventional,
        "posterior": {k: diagnostics[v] for k, v in policy["best"].items() if v in diagnostics},
    }


def standing(policy, output):
    earlier = reference(FIXED)
    review = read_json(checked(earlier))
    rows = []
    for view in review["standing"]:
        sample = arrays(view["input"])
        scene, colors, wb, matrix = [sample[k][0] for k in ("packed", "colors", "wb", "matrix")]
        parent = np.load(checked(view["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(view["local_ROI"])
        # Keep the entire 192-pixel fit footprint separate from the donors.
        guide = _spacing(scene, colors, *roi[:2], clearance=16)
        restored, support = arcs(
            parent, roi, scene, colors, roi, guide, view["noise"], wb, matrix, policy,
        )
        native = []
        for old in view["displays"]:
            exp = old["exposure"]
            old = old["board"]
            panels = {}
            with Image.open(checked(old["image"])) as png:
                img = np.asarray(png)
                for desc in old["panels"]:
                    x, y, w, h = desc["png_xywh"]
                    panels[desc["name"]] = img[y:y + h, x:x + w]
            np.testing.assert_array_equal(display(restored["parent"], wb, matrix, exp), panels["Local 50k"])
            choices = [(k, panels[k]) for k in ("Noisy (Malvar)", "V120 EMA")]
            choices.extend((NAMES[k], display(v, wb, matrix, exp)) for k, v in restored.items())
            choices.extend((k, panels[k]) for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG") if k in panels)
            result = Image.new("RGB", (8 + len(choices) * 168, 192), "#eee")
            painter = ImageDraw.Draw(result)
            panel_manifest = []
            for j, (label, pixels) in enumerate(choices):
                x = 8 + j * 168
                assert pixels.shape == (160, 160, 3)
                result.paste(Image.fromarray(pixels), (x, 24))
                painter.text((x, 5), label, fill="black")
                panel_manifest.append({"label": label, "png_xywh": [x, 24, 160, 160]})
            path = output / f"{view['id']}-x{exp:g}.png"
            result.save(path)
            native.append({"image": reference(path), "panels": panel_manifest, "exposure": exp, "previous": old})
        delta = {
            k: {
                "from_parent_DN16": float(np.sqrt(np.mean((v.astype("d") - restored["parent"])**2)) * 65535),
                "from_nested_DN16": float(np.sqrt(np.mean((v.astype("d") - restored["nested"])**2)) * 65535),
            }
            for k, v in restored.items()
        }
        rows.append({
            "id": view["id"], "capture": view["raw"], "ROI_xywh": view["global_ROI"],
            "parent": view["predictions"]["local50k"], "noise": view["noise"], "input": view["input"],
            "frequency": None if guide is None else guide.tolist(),
            "support": support, "native": native, "delta": delta,
        })
        print(view["id"], delta["ring_phase"], flush=True)
    return {"retained": earlier, "checkpoints": review["checkpoints"], "rows": rows}


def exact(policy, output):
    source = reference(replay.OUT / "fresh-guarded.json")
    review = read_json(checked(source))
    plan = read_json(checked(review["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + ROI[0], y + ROI[1], *ROI[2:])
    native = []
    for case in review["cases"]:
        if case["id"] not in SELECTED:
            continue
        record = case["draws"][0]
        inputs = arrays(record["input"])
        p = np.load(checked(record["outputs"]["local50k"]), allow_pickle=False)[0]
        v120 = np.load(checked(record["outputs"]["v120"]), allow_pickle=False)[0]
        scene = inputs["scene_packed"].copy()
        scene[:, y//2:(y + h)//2, x//2:(x + w)//2] = inputs["packed"][0]
        guide = record["fixed_guide"]
        colors, wb, matrix = (inputs[k] for k in ("colors", "wb", "matrix"))
        values, support = arcs(p, ROI, scene, colors, roi, guide, plan["noise"], wb, matrix, policy)
        camera = {k: inputs[k][None] for k in ("colors", "wb", "matrix")}
        camera["packed"] = inputs["packed"][:1]
        all_rgb = [noisy_malvar(camera)[0], v120]
        for value in values.values():
            image = p.copy()
            section(image, *ROI)[:] = value
            all_rgb.append(image)
        all_rgb.append(inputs["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(NAMES[k] for k in values), "Exact GT"]
        native.append(native_board(
            output, case["id"], all_rgb, camera,
            {"input": record["input"], "fixture": case["fixture"], "draw": 0,
             "query": plan["query"], "profile": plan["noise"], "optical_sigma": plan["sigma"],
             "weights": plan["checkpoints"], "activity": support},
            labels=labels, triplet_indices=(0, labels.index("Ring phase prior"), len(labels)-1),
        ))
    assert len(native) == len(SELECTED)
    return {"source": source, "boards": native}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    lock = reference(replay.OUT / "guarded-calibration.json")
    policy = read_json(checked(lock))["weights"]
    is_camera = "--camera" in sys.argv
    output = replay.OUT / "native" / ("standing" if is_camera else "exact")
    output.mkdir(exist_ok=True, parents=True)
    rows = (standing if is_camera else exact)(policy, output)
    write_json(
        replay.OUT / ("native-standing.json" if is_camera else "native-exact.json"),
        {"driver": reference(Path(__file__)), "calibration": lock, "data": rows, "seconds": monotonic() - start},
    )


if __name__ == "__main__":
    main()
