"""Frozen target and cache decoding operators from the prior wire study."""
import math
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import reference

def exact(photo,geometry):
    axis=torch.arange(512)-255.5
    y,x=torch.meshgrid(axis,axis,indexing="ij")
    grid=torch.maximum(x.abs(),y.abs())
    outer=((grid-132)/27).clamp(0,1)
    exterior_only=((grid-108)/18).clamp(0,1)
    flat=((128-grid)/57).clamp(0,1)
    smooth=.085+.52*F.avg_pool2d(photo[None],11,stride=1,padding=5,count_include_pad=False)[0]
    z=x*math.cos(geometry["angle"])+y*math.sin(geometry["angle"])-geometry["edge"]
    step=torch.sigmoid(z/1.3)
    base=smooth+torch.tensor(geometry["tint"])[:,None,None]*step

    def phases(rotation):
        c,s=math.cos(rotation),math.sin(rotation)
        return [2*math.pi*((fx*c-fy*s)*x+(fx*s+fy*c)*y)+p
                for (fx,fy),p in zip(geometry["frequency"],geometry["phase"],strict=True)]

    def profile(phase,width,narrow):
        result=phase.cos()
        if narrow:
            for m in range(2,9):
                result=result+math.exp(-2*math.pi**2*width**2*(m*m-1))*(m*phase).cos()
        return result

    tag=geometry["family"]
    p,q=phases(0)
    a,b=(profile(p,geometry["width"][0],True),profile(q,geometry["width"][1],True))
    side,weak=geometry["strength"]
    front=base+side*a
    dx,dy=x-geometry["gap_center"][0],y-geometry["gap_center"][1]
    angle=geometry["gap_orientation"]
    u=dx*math.cos(angle)+dy*math.sin(angle)
    v=-dx*math.sin(angle)+dy*math.cos(angle)
    normal=u/geometry["gap_width"]
    tangent=v/geometry["gap_length"]
    radius=torch.hypot(normal,tangent)
    if tag=="ellipse":
        footprint=((radius-1)*3.2).clamp(0,1)
    elif tag=="strip":
        footprint=((normal.abs()-1)*3.2).clamp(0,1)
    elif tag=="smooth-dip":
        footprint=1-.57*torch.exp(-.5*radius*radius)
    else:
        footprint=torch.ones_like(x)
    amplitude=.53+.47*step if tag=="contrast-step" else .78+.22*step
    support=torch.maximum(footprint,exterior_only)
    addition=weak*b*amplitude*(1-.28*(.5+.5*p.cos()))+.19*weak*p.cos()*q.cos()
    signal=front+addition*support
    outside=front+addition*exterior_only
    flat_color=signal[:,198:314,198:314].mean((-2,-1),keepdim=True)
    quiet=torch.where(flat==1,flat_color,torch.lerp(signal,flat_color,flat))
    cp,cq=phases(.57)
    shell=base+.025*p.cos()+.025*q.cos()
    bad=base+.025*cp.cos()+.025*cq.cos()
    targets=tuple(torch.lerp(v,shell,outer)for v in (signal,outside,front,quiet))
    assert all(0<float(z.min()) and float(z.max())<1 for z in (*targets,bad))
    return targets,bad,support,addition


def decode(record, box):
    path = Path(record["cache"])
    assert path.is_relative_to("/mnt/external") and reference(path)["sha256"] == record["cache_sha256"]
    x,y,w,h = box
    source = np.load(path, mmap_mode="r", allow_pickle=False)
    assert list(source.shape) == record["shape"] and source.dtype == np.uint16
    crop = source[y:y+h,x:x+w].astype(np.float32)
    return torch.from_numpy(crop).permute(2,0,1).contiguous()/65535.
