"""Freeze 48 new photo backgrounds and replay both camera-linear parent paths."""

from pathlib import Path
import sys
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic')/HERE.name/'fresh'
sys.path.insert(0,str(HERE.with_name('local-phase-extent-v1')))
from capture_extent import prior

SEED = 202611200512
COUNT = 48


def freeze():
    root = OUT.parent.parent
    plans = (*prior.EXCLUSIONS, *(root/f'{name}/fresh/plan.json' for name in ('local-weak-support-v1',
            'local-phase-extent-v1','local-phase-transport-v2')))
    refs = [reference(p) for p in plans]
    earlier = prior.earlier
    capture = earlier.capture_wide
    blocked = set()
    for binding in refs:
        capture.scan(read_json(checked(binding)),blocked)
    original = capture.lines
    pool = read_json(checked(refs[0]))['source_pool']

    def eligible(binding):
        for row in original(binding):
            if binding != pool or {row['id'],row['cache_sha256']}.isdisjoint(blocked):
                yield row

    earlier.COUNT, earlier.GROUP_SIZE, earlier.SEED = COUNT, COUNT//4, SEED
    capture.lines = eligible
    try:
        plan = earlier.choose()
    finally:
        capture.lines = original
    for row in plan['sources']:
        row['id'] = row['id'].replace('nested-','weak-contrast-')
        assert {row['source']['id'],row['source']['cache_sha256']}.isdisjoint(blocked)
    return plan | {'driver':reference(__file__), 'capture_source':reference(earlier.__file__),
                   'extra_excluded_sources':refs, 'native_indices':[1,13],
                   'primary':'Compare calibrated amplitude-strength controls on 48 separate photo backgrounds.',
                   'hypothesis':'Increasing strength where the separate RAW phase supports it preserves gaps at a higher weak response.'}


def main():
    torch.set_num_threads(2)
    started = monotonic()
    OUT.mkdir(exist_ok=True)
    plan = OUT/'plan.json'
    if not plan.is_file():
        write_json(plan,freeze())
    data = read_json(plan)
    assert data['driver'] == reference(__file__)
    prior.earlier.SEED = SEED
    directory = OUT/'inputs'
    directory.mkdir(exist_ok=True)
    inputs = OUT/'inputs.json'
    if not inputs.is_file():
        records = []
        for case in data['sources']:
            records.append(prior.earlier.capture(case,data['noise'],directory))
            if len(records)%8 == 0:
                print('Captured',len(records),flush=True)
        write_json(inputs,{'driver':reference(__file__),'plan':reference(plan),
                           'observations':records,'seconds':monotonic()-started})
    prior.parents.OUT = OUT
    if not (OUT/'parent/result.json').is_file():
        prior.parents.main()


if __name__ == '__main__':
    main()
