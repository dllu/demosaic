import os
import subprocess
import sys
from pathlib import Path

from demosaic.experiments.artifacts import reference, write_json

recovery = Path(__file__).resolve().parent
root = recovery.parent
for step, driver, args in (
    ("report", recovery / "report_phase_guide_edge_guard.py", [str(root / "plan.json")]),
    ("audit", root / "audit.py", []),
    ("summary", root / "summarize.py", []),
):
    command = [sys.executable, str(driver), *args]
    with (recovery / f"{step}.log").open("xb") as log:
        result = subprocess.run(command, env=os.environ, stdout=log, stderr=subprocess.STDOUT, check=False)
    write_json(recovery / f"{step}-return.json", {"returncode": result.returncode, "command": command, "driver": reference(driver), "collection": reference(root / "output/collection.json")})
    result.check_returncode()
