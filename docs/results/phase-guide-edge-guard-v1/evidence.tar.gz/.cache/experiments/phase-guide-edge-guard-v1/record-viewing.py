"""Record native board viewing and compare the sky to the saved V120 parent."""

import datetime as dt
import json
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent / "review"
source = root / "result.json"
report = read_json(source)
observations = json.load(sys.stdin)
rows = []
for b in report["boards"] + report["camera"]:
    info = b.get("board", b)["image"]
    assert reference(checked(info)) == info
    rows.append(
        {
            "id": b["id"],
            "image": info,
            "viewed": True,
            "observation": observations[b["id"]],
        }
    )
assert len(rows) == len(observations) == 12
sky = next(b for b in report["camera"] if b["id"] == "main-overcast-sky")
x, y, w, h = sky["ROI_xywh"]
bx, by, *_ = sky["source"]["query_box"]
crop = np.s_[:, y - by : y - by + h, x - bx : x - bx + w]
v120 = np.load(checked(sky["source"]["parent_prediction"]), mmap_mode="r")[
    0, :, y : y + h, x : x + w
]
image = np.asarray(Image.open(checked(sky["image"])))
pixels = {}
for p in sky["panels"]:
    x, y, w, h = p["png_xywh"]
    pixels[p["label"]] = image[y : y + h, x : x + w]
with np.load(checked(sky["guarded_prediction"])) as prediction:
    for width in (8, 24):
        np.testing.assert_array_equal(prediction[f"guard{width}"][crop], v120)
        np.testing.assert_array_equal(pixels[f"Edge guard {width}px"], pixels["V120 EMA"])
write_json(
    root / "actual-native-viewing.json",
    {
        "observed_at": dt.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "report": reference(source),
        "boards": rows,
        "v120_sky_matches": {"native_camera_RGB_bitexact": True, "displayed_pixels_bitexact": True},
    },
)
