"""Audit guarded sample counts, exact inactive controls, and saved image metrics."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split

root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
closed = read_json(checked(report["collection"]))
previous_report = read_json(checked(plan["previous_report"]))
fresh_plan = read_json(checked(plan["fresh_plan"]))
previous = read_json(checked(plan["previous_collection"]))
assert closed["new_synthetic_calls"] == 576 and closed["new_camera_calls"] == 16
assert report["metrics"][:768] == previous_report["metrics"]
assert plan["config"]["background"] == "step" and plan["config"]["window"] == 256
assert [v["previous"] for v in (read_json(checked(r)) for r in closed["synthetic"])] == previous[
    "synthetic"
]
roi = np.s_[..., 128:384, 128:384]
yy, xx = np.indices((256, 256))
xy = np.stack(((xx - 127.5) / 128, (yy - 127.5) / 128), axis=-1)
discovery = stratified_split((256, 256), plan["config"]["split_seed"])
metrics = (
    "quiet_RMS_DN16",
    "weak_gain",
    "strong_gain",
    "query_RMS_DN16",
    "weak_increment_RMS_DN16",
    "weak_absent_projection",
)
by_case = defaultdict(list)
for r in report["metrics"][768:]:
    by_case[r["id"]].append(r)


def rms(v):
    return float(np.sqrt(np.mean(v * v)) * 65535)


def excluded_measured(packed, colors, edges, noise, width):
    raw = np.stack([packed[k] for k in (0, 1, 2, 3)]).reshape(2, 2, 128, 128)
    raw = raw.transpose(2, 0, 3, 1).reshape(256, 256)
    layout = (
        np.broadcast_to(colors.reshape(2, 2), (128, 128, 2, 2))
        .transpose(0, 2, 1, 3)
        .reshape(256, 256)
    )
    expected = []
    for fold, (angle, offset) in zip((discovery, ~discovery), edges, strict=True):
        region = (layout == 1) & fold
        x, y = xy[region].T
        signed = x * np.cos(angle) + y * np.sin(angle) - offset
        design = np.column_stack((np.ones(len(x)), x, y, signed > 0))
        gram = design.T @ design
        coefficient = np.linalg.pinv(gram, hermitian=True, rcond=1e-12) @ (design.T @ raw[region])
        peak = max(float(np.max(design @ coefficient)), 1e-6)
        limit = 2 * np.sqrt(noise["read"] + noise["shot"] * peak)
        cx, cy = np.cos(angle), np.sin(angle)
        distance = np.abs(signed) / np.hypot(2 * cx / 256, 2 * cy / 256)
        expected.append(int((distance < width).sum()) if abs(coefficient[3]) > limit else 0)
    return expected


records, masks, checks, largest, exact = [], 0, 0, 0.0, 0
for binding in closed["synthetic"]:
    case = read_json(checked(binding))
    old = read_json(checked(case["previous"]))
    source = read_json(checked(case["case"]))
    assert source["id"] == old["id"] == case["id"] and case["case"] == old["case"]
    with np.load(checked(source["sensor"])) as f:
        packed, color = f["packed"][..., 64:192, 64:192], f["colors"]
    noise = fresh_plan["profiles"][source["profile"]]
    expectations = {}
    for arm, runs in case["fits"].items():
        offset, choice = arm.split("-")
        width = int(choice.removeprefix("guard"))
        for i, (now, control) in enumerate(
            zip(runs, old["fits"][offset + "-recentered"], strict=True)
        ):
            current = now["records"][0]
            earlier = control["records"][0]
            assert current["edges"] == earlier["edges"]
            assert now["guide_frequencies_xy"] == control["guide_frequencies_xy"]
            assert now["phase_guide_edge_guard_px"] == width and now["recenter_phase_guides"]
            key = (width, i)
            if key not in expectations:
                expectations[key] = excluded_measured(
                    packed[i], color[i], current["edges"], noise, width
                )
            assert current["guide_search_excluded"] == expectations[key]
            masks += 2
    parent = np.load(checked(source["parent"])).astype(np.float64)
    with np.load(checked(source["target"])) as f:
        truth = f["target"].astype(np.float64)
        quiet = f["quiet"][roi]
    weak = (truth[2] - truth[1]).ravel()
    strong = (truth[1] - truth[0]).ravel()
    with np.load(checked(case["output"])) as values, np.load(checked(old["output"])) as control:
        for arm, runs in case["fits"].items():
            group = arm.split("-")[0]
            for i, row in enumerate(runs):
                if not any(row["records"][0]["guide_search_excluded"]):
                    for k in values.files:
                        if k.startswith(arm + "--"):
                            other = k.replace(arm, group + "-recentered", 1)
                            np.testing.assert_array_equal(values[k][i], control[other][i])
                    exact += 1
        for v in by_case[case["id"]]:
            key = f"{v['arm']}--{v['method']}-t{v['threshold']:g}"
            output = parent.copy()
            output[roi] = (1 - v["scale"]) * parent[roi] + v["scale"] * values[key].astype(
                np.float64
            )
            diff = output - truth
            w = (output[2] - output[1]).ravel()
            s = (output[1] - output[0]).ravel()
            computed = np.array(
                [
                    rms(diff[roi][..., quiet]),
                    w @ weak / (weak @ weak),
                    s @ strong / (strong @ strong),
                    rms(diff[roi]),
                    rms(w - weak),
                    diff[1].ravel() @ weak / (weak @ weak),
                ]
            )
            saved = np.array([v[k] for k in metrics])
            np.testing.assert_allclose(computed, saved, atol=4e-10, rtol=0)
            largest = max(largest, float(np.max(abs(computed - saved))))
            checks += len(metrics)
            if v["budget_DN16"] == 0.02 and v["method"] == "weighted-refit":
                records.append(
                    {
                        "id": case["id"],
                        "profile": v["profile"],
                        "placement": v["placement"],
                        "arm": v["arm"],
                        "no_wire_delivered_correction_RMS_DN16": rms(
                            output[0][roi] - parent[0][roi]
                        ),
                    }
                )


def cell(image, p):
    x, y, w, h = p["png_xywh"]
    assert (w, h) == (160, 160)
    return image[y : y + h, x : x + w]


copied = 0
for rendered, inputs, new in zip(report["camera"], plan["camera"], closed["camera"], strict=True):
    old = inputs["board"]
    case = old["source"]
    assert rendered["id"] == old["id"] == new["id"]
    a = np.asarray(Image.open(checked(rendered["image"])))
    b = np.asarray(Image.open(checked(old["image"])))
    kept = [p for p in rendered["panels"] if not p["label"].startswith("Edge guard")]
    for p, q in zip(kept, old["panels"], strict=True):
        assert p["label"] == q["label"]
        np.testing.assert_array_equal(cell(a, p), cell(b, q))
        copied += 1
    x, y, w, h = case["query_box"]
    with np.load(checked(case["query_arrays"])) as sensor:
        packed = sensor["packed"][0, :, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
        colors = sensor["colors"][0]
    for name, stats in new["fits"].items():
        width = int(name.removeprefix("guard"))
        r = stats["records"][0]
        expect = excluded_measured(packed, colors, r["edges"], inputs["noise"], width)
        assert expect == r["guide_search_excluded"] == rendered["excluded_green_sites"][name]
        masks += 2
for board in report["boards"]:
    a, b = [np.asarray(Image.open(checked(board[k]["image"]))) for k in ("board", "triplet")]
    for i, j in enumerate((0, 3, 5)):
        np.testing.assert_array_equal(
            cell(a, board["board"]["panels"][j]), cell(b, board["triplet"]["panels"][i])
        )
assert checks == 4608 and len(records) == 192 and masks == 1184 and copied == 104
assert exact == report["zero_exclusion_refits_bitexact"]
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "status": "passed",
        "native_reductions": checks,
        "maximum_absolute_difference": largest,
        "independent_fold_mask_counts": masks,
        "nominal_adopted_rows": 768,
        "zero_exclusion_refits_bitexact": exact,
        "retained_camera_cells_bitexact": copied,
        "exact_triplet_subsets": 4,
        "background_correction_rows": records,
    },
)
print(checks, masks, copied, exact, largest, flush=True)
