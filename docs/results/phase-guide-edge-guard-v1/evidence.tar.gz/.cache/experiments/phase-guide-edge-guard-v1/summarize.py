"""Summarize guarded guide choices, delivered response and quiet error."""

from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np
from matplotlib.lines import Line2D

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
source = root / "review/result.json"
report = read_json(source)
plan = read_json(checked(report["plan"]))
old_audit = read_json(Path(plan["previous_report"]["path"]).with_name("independent-audit.json"))
audit = read_json(root / "review/independent-audit.json")
labels = (
    "weak_gain",
    "strong_gain",
    "quiet_RMS_DN16",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "query_RMS_DN16",
    "abs_weak_absent_projection",
)


def measured(r):
    return np.array(
        [
            r["weak_gain"],
            r["strong_gain"],
            r["quiet_RMS_DN16"],
            r["delta_from_parent"]["quiet_RMS_DN16"],
            r["weak_increment_RMS_DN16"],
            r["query_RMS_DN16"],
            abs(r["weak_absent_projection"]),
        ]
    )


stored = defaultdict(dict)
for r in report["metrics"]:
    stored[(r["profile"], r["placement"], r["method"], r["budget_DN16"], r["arm"])][r["source"]] = (
        measured(r)
    )
assert len(stored) == 192 and all(len(v) == 8 for v in stored.values())
rng = np.random.default_rng(3448)
draws = rng.integers(0, 8, (12000, 8))
samples = {k: np.stack([v[i] for i in sorted(v)]) for k, v in stored.items()}
means = {key: item.mean(axis=0) for key, item in samples.items()}
table = []
for key, x in samples.items():
    profile, place, method, budget, arm = key
    entry = {
        "profile": profile,
        "placement": place,
        "method": method,
        "budget_DN16": budget,
        "arm": arm,
        "mean": means[key].tolist(),
    }
    offset, mode = arm.split("-")
    if mode.startswith("guard"):
        differences = x - samples[profile, place, method, budget, f"{offset}-recentered"]
        entry.update(
            {
                "paired_mean_vs_unguarded": differences.mean(0).tolist(),
                "paired_descriptive_interval_vs_unguarded": np.quantile(
                    differences[draws].mean(1), [0.025, 0.975], axis=0
                ).tolist(),
                "sources_with_higher_response": int((differences[:, 0] > 0).sum()),
                "sources_with_lower_increment_error": int((differences[:, 4] < 0).sum()),
            }
        )
    table.append(entry)
geom = defaultdict(list)
for k in ("unguarded_guide_choices", "guarded_guide_choices"):
    for r in report[k]:
        if r["role"] != 2:
            continue
        error = (
            r["frequency_errors_native_bins"]
            if k == "guarded_guide_choices"
            else r["guide_errors_after"]
        )
        geom[r["profile"], r["placement"], r["arm"]].append((error, r.get("excluded_sites", 0)))
geometry = []
for (profile, place, arm), row in geom.items():
    err = np.array([v[0] for v in row])
    amount = np.array([v[1] for v in row])
    assert len(row) == 16
    geometry.append(
        {
            "profile": profile,
            "placement": place,
            "arm": arm,
            "mean_frequency_errors_native_bins": err.mean(0).tolist(),
            "both_within_quarter_bin_folds": int((err.max(axis=1) <= 0.25).sum()),
            "folds_with_exclusions": int((amount > 0).sum()),
            "mean_excluded_green": float(amount.mean()),
        }
    )
background = defaultdict(list)
for r in [*audit["background_correction_rows"], *old_audit["background_correction_rows"]]:
    background[r["profile"], r["placement"], r["arm"]].append(
        r["no_wire_delivered_correction_RMS_DN16"]
    )
assert all(len(v) == 8 for v in background.values())
blank = [
    {
        "profile": p,
        "placement": w,
        "arm": k,
        "mean_DN16": float(np.mean(v)),
        "number_above_0p1_DN16": sum(x > 0.1 for x in v),
    }
    for (p, w, k), v in background.items()
]
colors = {"fixed": "#394f86", "recentered": "#8874ae", "guard8": "#17816f", "guard24": "#b34d28"}
descriptions = {
    "fixed": "Fixed",
    "recentered": "Unguarded",
    "guard8": "Guard 8 px",
    "guard24": "Guard 24 px",
}
shape = {
    "nominal": ("o", "Nominal"),
    "tangential": ("s", "Tangential 0.5 bin"),
    "radial": ("^", "Radial 1 bin"),
}
fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.8), layout="constrained")
for ax, profile in zip(axes, ("iso400", "iso6400"), strict=True):
    for offset, (mark, _) in shape.items():
        points = [means[profile, "near", "weighted-refit", 0.02, f"{offset}-{m}"] for m in colors]
        ax.plot(
            [v[3] for v in points], [100 * v[0] for v in points], linewidth=0.8, color="#a4a4a4"
        )
        for mode, p in zip(colors, points, strict=True):
            ax.scatter(p[3], 100 * p[0], marker=mark, color=colors[mode], s=48, zorder=4)
    ax.set_title(profile.upper(), loc="left", fontweight="bold")
    ax.set_xlabel("Quiet RMS change from V143 (DN16)")
    ax.set_ylabel("Weak response (%)")
    ax.grid(alpha=0.15)
    ax.spines[["top", "right"]].set_visible(False)
keys = [
    Line2D([], [], marker="o", linestyle="none", color=c, label=descriptions[k])
    for k, c in colors.items()
]
keys.extend(
    Line2D([], [], marker=m, linestyle="none", color="#555555", label=label)
    for m, label in shape.values()
)
fig.legend(handles=keys, loc="outside lower center", ncol=4, frameon=False, fontsize=8)
fig.suptitle("Edge exclusions at the frozen tight-budget setting", fontweight="bold")
plot = root / "review/edge-guard-tradeoff.png"
fig.savefig(plot, dpi=150)
write_json(
    root / "review/summary.json",
    {
        "source": reference(source),
        "driver": reference(__file__),
        "metrics": list(labels),
        "strata": table,
        "two_wire_frequency_choices": geometry,
        "background_only_delivery": blank,
        "plot": reference(plot),
        "scope": "Common held-out observations, fixed operating points, paired source summaries.",
    },
)
for r in table:
    if r["placement"] == "near" and r["method"] == "weighted-refit" and r["budget_DN16"] == 0.02:
        print(r["profile"], r["arm"], np.round(r["mean"], 7).tolist())
