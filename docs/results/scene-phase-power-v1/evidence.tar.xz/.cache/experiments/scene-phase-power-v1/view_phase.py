"""Lay out native viewing sheets and plot the fixed-cohort response curves."""

import os

import numpy as np
from PIL import Image, ImageDraw
from evaluate_phase import ROOT
from evaluate_wide import FLAT, HOLE, LENGTH, values
from atlas_probe import pixels

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def sheet(name, items, columns):
    canvas = Image.new("RGB", (8 + 168 * len(columns), 30 + 185 * len(items)), "#eeeeee")
    draw = ImageDraw.Draw(canvas)
    for i, label in enumerate(columns):
        draw.text((8 + i * 168, 5), label, fill="black")
    for j, (label, ref) in enumerate(items):
        image = pixels(ref)
        draw.text((8, 191 + j * 185), label, fill="black")
        for i, col in enumerate(columns):
            art = Image.fromarray(image[col])
            assert art.size == (160, 160)
            canvas.paste(art, (8 + i * 168, 30 + 185 * j))
    path = ROOT / f"view-{name}.png"
    canvas.save(path)
    return reference(path)


def plots(receipt, cal):
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    data = [r["width"]["4800"] for r in receipt["short"]]
    gaps = [r for r in data if r["gap_pixels"]]
    styles = {
        "dense": ("Dense cosine", "#1763a4", "o"),
        "separate": ("Separate sine/cosine axes", "#214f35", "^"),
        "phase_pair": ("Phase-paired gain", "#a83645", "s"),
        "transposed": ("Transposed prior", "#777777", "x"),
    }
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.0), layout="constrained", sharey=True)
    for key, (label, color, marker) in styles.items():
        strength = cal["strengths"]["4800"][key]["gain"]
        scales = np.linspace(0, 1.65 * strength, 21)
        y = [values(data, key, LENGTH, g).mean() for g in scales]
        for axis, metric, field in zip(axes, (HOLE, FLAT), (gaps, data), strict=True):
            x = [values(field, key, metric, g).mean() for g in scales]
            axis.plot(x, y, color=color, label=label)
            axis.scatter(
                values(field, key, metric, strength).mean(),
                values(data, key, LENGTH, strength).mean(),
                color=color,
                marker=marker,
                zorder=4,
                s=33,
            )
    for ax in axes:
        ax.grid(alpha=0.20)
    axes[0].set_xlabel("False projection in true gaps (DN16 RMS)")
    axes[1].set_xlabel("Exact flat error (DN16 RMS)")
    axes[0].set_ylabel("Recovered short-wire fundamental (%)")
    axes[0].legend(loc="lower right", fontsize=8.7)
    fig.suptitle("Short-wire transfer on 24 photo backgrounds")
    file = ROOT / "response-tradeoff.png"
    fig.savefig(file, dpi=140)
    plt.close(fig)
    return reference(file)


def main():
    refs = {key: reference(ROOT / f"native/{key}/result.json") for key in ("standing", "exact")}
    stand, exact = (read_json(checked(p))["rows"] for p in refs.values())
    views = {}
    compare = (
        "Noisy (Malvar)",
        "V120 EMA",
        "Corpus 100k",
        "Dense cosine prior",
        "Phase-paired prior",
        "ISO100 AHD reference",
    )
    for family, gain in (("main", 4), ("mesh", 4), ("mesh", 16)):
        rows = [
            (r["id"], d["board"])
            for r in stand
            if r["id"].startswith(family)
            for d in r["displays"]
            if d["exposure"] == gain
        ]
        tag = f"{family}-x{gain}"
        views[tag] = sheet(tag, rows, compare)
        secondary = ("Separate phase axes", "Transposed paired prior")
        if family == "mesh":
            secondary = (
                "ISO6400 camera JPEG",
                *secondary,
                "Phase-paired prior",
                "ISO100 camera JPEG",
            )
        views[tag + "-controls"] = sheet(tag + "-controls", rows, secondary)
    views["exact"] = sheet(
        "exact",
        [(r["id"], r["board"]) for r in exact],
        (
            "Noisy Malvar",
            "Corpus 100k",
            "Dense cosine prior",
            "Separate phase axes",
            "Phase-paired prior",
            "Exact GT",
        ),
    )
    numerical = reference(ROOT / "results.json")
    numeric = read_json(checked(numerical))
    graph = plots(numeric, read_json(checked(numeric["settings"])))
    write_json(
        ROOT / "views.json",
        {
            "driver": reference(__file__),
            "native": refs,
            "views": views,
            "numeric": numerical,
            "figure": graph,
        },
    )


if __name__ == "__main__":
    main()
