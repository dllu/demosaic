"""Replay phase-paired spectral power on both standing GFX scenes."""

import time

import numpy as np
import torch
from evaluate_phase import ATLAS, BAND, DENSE, ROOT, patch, replay
from phase_pairs import corrections, reencode
from atlas_probe import exact_query, load_standing, packed_scene

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

OUT = ROOT / "camera"


def run():
    torch.set_num_threads(2)
    older = reference(ATLAS / "camera-audit.json")
    dense = read_json(checked(older))
    _, preceding, lookup = load_standing()
    sources = {r["id"]: r for r in dense["rows"]}
    assert len(sources) == 8
    start = time.monotonic()
    records = []
    OUT.mkdir()
    for family in ("main", "mesh"):
        cohort = [r for r in preceding["rows"] if r["id"].startswith(family)]
        raw_ref, scene, colors = packed_scene(cohort)
        for r in cohort:
            old = sources[r["id"]]
            case, parent, roi, wb, matrix = exact_query(r, lookup, scene, colors)
            sx, sy, w, h = roi
            region = np.s_[..., sy : sy + h, sx : sx + w]
            shot, read = (r["noise"][k] for k in ("shot", "read"))
            bank = patch.build_exterior(
                scene, colors, r["query"], shot, read, band=BAND, dense_radius=DENSE
            )
            assert len(bank.coords) == old["patch_counts"]["dense"]["total"]
            fitted = reencode(scene, colors, bank, shot, read)
            ds = corrections(case, parent[1], colors, shot, read, r["query"], fitted)
            with np.load(checked(old["arrays"]), allow_pickle=False) as f:
                for name, arr in (
                    ("parent", parent),
                    ("raw", case),
                    ("wb", wb),
                    ("matrix", matrix),
                ):
                    np.testing.assert_array_equal(f[name], arr)
                baseline = f["dense"]
            ds["dense"] = baseline
            strength = old["strength"]
            unit = {
                k: replay.apply_delta(np.zeros_like(parent), delta, wb, matrix, 1)
                for k, delta in ds.items()
            }
            metric = {
                k: float(65535 * np.sqrt(np.mean(p[region].astype(np.float64) ** 2)))
                for k, p in unit.items()
            }
            path = OUT / f"{r['id']}.npz"
            with path.open("xb") as f:
                np.savez_compressed(
                    f, parent=parent, raw=case, wb=wb, matrix=matrix, colors=colors, **unit
                )
            records.append(
                {
                    "id": r["id"],
                    "raw": raw_ref,
                    "absolute_query": r["query"],
                    "roi": roi,
                    "global_roi": r["native_ROI"],
                    "noise": r["noise"],
                    "paths": reference(path),
                    "prior_strength": strength,
                    "unit_crop_DN16": metric,
                    "source_row": old["arrays"],
                    "native_reference": r["displays"],
                }
            )
            print(r["id"], {k: round(p * strength, 4) for k, p in metric.items()}, flush=True)
        del scene
    write_json(
        ROOT / "camera-fields.json",
        {
            "driver": reference(__file__),
            "operator": reference(ROOT / "phase_pairs.py"),
            "dense_receipt": older,
            "seconds": time.monotonic() - start,
            "rows": records,
        },
    )


if __name__ == "__main__":
    run()
