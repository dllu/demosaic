"""Measure phase invariance and the error tradeoff at equal short-wire response."""

import numpy as np
from evaluate_phase import BAND, ROOT
from evaluate_wide import COMP, FLAT, HOLE, LENGTH, values
from phase_pairs import MODES, limit_pair_amplitude, phase_basis, phase_fields

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def phase_checks():
    tests = []
    levels = ((0, 1, 1, 2), (1, 0, 2, 1), (2, 1, 1, 0), (1, 2, 0, 1))
    for colors in levels:
        basis, grid = phase_basis(colors, BAND)
        n = int(np.flatnonzero(np.all(grid == np.array([3, -2]) / 32, axis=1))[0])
        pair = slice(2 * n, 2 * n + 2)
        fixed = np.array([2.7, 1.2])
        j = np.arange(32)
        angles = (j + 0.37) * 2 * np.pi / len(j)
        rotated = np.stack((np.cos(angles), np.sin(angles)), axis=-1) * np.linalg.norm(fixed)
        coefficients = np.zeros((2, len(j), 2, len(basis.image)))
        coefficients[0, :, :, pair] = fixed[None, None, :]
        coefficients[1, :, :, pair] = rotated[:, None, :]
        query = np.zeros((2, 2, len(basis.image)))
        query[..., pair] = fixed[None, None, :]
        weights = np.broadcast_to(np.full(32, 1 / 32), (2, 32))
        corrected = phase_fields(
            coefficients, weights, query.mean(axis=1) * 0.6, query, np.array([0.1, 0.1]), basis
        )
        paired = corrected["phase_pair"]
        np.testing.assert_allclose(paired[0], paired[1], atol=1e-13, rtol=0)
        assert np.linalg.norm(paired[0]) > 0
        assert not np.allclose(corrected["separate"][0], corrected["separate"][1])
        assert np.max(np.abs(corrected["transposed"])) == 0
        silent = phase_fields(
            coefficients, weights, query.mean(axis=1) * 0, query * 0, np.array([0.1, 0.1]), basis
        )
        assert all(np.max(np.abs(silent[key])) == 0 for key in MODES)
        descent = basis.image[2 * n] * fixed[0] + basis.image[2 * n + 1] * fixed[1]
        shifted_background = np.array([-0.03, 0.02]) @ np.stack(
            (np.tile(np.linspace(-1, 1, 32), 32), np.repeat(np.linspace(-1, 1, 32), 32))
        )
        raw_img = descent + 0.2 + shifted_background.reshape(32, 32)
        raw = np.stack([raw_img[g // 2 :: 2, g % 2 :: 2].ravel() for g in basis.green])
        fit = np.einsum("gki,gi->gk", basis.projection, raw)
        np.testing.assert_allclose(fit, query[0], atol=1e-12, rtol=0)
        clipped = limit_pair_amplitude(coefficients * 100).reshape(2, len(j), 2, -1, 2)
        np.testing.assert_allclose(
            np.linalg.norm(clipped[..., n, :], axis=-1), 10 * np.sqrt(2), atol=1e-14
        )
        tests.append(
            {
                "cfa": colors,
                "exact_fit_max": float(np.max(np.abs(fit - query[0]))),
                "frequency_yx": grid[n].tolist(),
                "spectral_norms_phase_fixed_shifted": {
                    key: np.linalg.norm(corrected[key], axis=1).tolist() for key in MODES
                },
            }
        )
    return tests


def equal_response(rows, settings):
    result = {}
    rng = np.random.default_rng(202611191952)
    for key, setting in settings.items():
        cases = [r["width"][key] for r in rows]
        phased = setting["phase_pair"]["gain"]
        target = values(cases, "phase_pair", LENGTH, phased).mean()
        headroom = target - values(cases, "origin", LENGTH, 0).mean()
        gain = {
            k: float(headroom / np.mean([p["terms"][k][LENGTH][1] for p in cases]))
            for k in ("dense", "separate", "phase_pair")
        }
        assert 0 < min(gain.values()) and max(gain.values()) < 0.8
        for k, g in gain.items():
            np.testing.assert_allclose(values(cases, k, LENGTH, g).mean(), target, atol=1e-12)
        measures = {}
        for name in (
            COMP,
            HOLE,
            FLAT,
            "gap_continuing_strong_RMS_DN16",
            "intact_increment_RMS_DN16",
        ):
            chosen = [c for c in cases if name in c["origin"]]
            boot = rng.integers(0, len(chosen), (8000, len(chosen)))
            inds = np.vstack((np.arange(len(chosen)), boot))
            aggreg = {k: values(chosen, k, name, g)[inds].mean(axis=1) for k, g in gain.items()}
            changes = {}
            for k, series in aggreg.items():
                d = series - aggreg["dense"]
                changes[k] = {
                    "mean": float(series[0]),
                    "vs_dense": [float(d[0]), *np.quantile(d[1:], [0.025, 0.975])],
                }
            measures[name] = changes
        result[key] = {
            "strengths": gain,
            "same_fundamental_response_pct": float(target),
            "measures": measures,
        }
    return result


if __name__ == "__main__":
    r = reference(ROOT / "results.json")
    n = read_json(checked(r))
    config = read_json(checked(n["settings"]))
    cases = phase_checks()
    comparison = equal_response(n["short"], config["strengths"])
    write_json(
        ROOT / "diagnostics.json",
        {
            "driver": reference(__file__),
            "results": r,
            "analytic": cases,
            "equal_response": comparison,
        },
    )
    print(cases[0], comparison["4800"], flush=True)
