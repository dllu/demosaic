"""Render native GFX and short-wire comparisons from frozen predictions."""

import sys

import numpy as np
import torch
from evaluate_phase import ATLAS, ROOT, field_updates, replay
from evaluate_wide import COMP, HOLE, LENGTH, values
from atlas_probe import pixels, render
from render_wide import native_board, native_png, peak_fit

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LABELS = {
    "dense": "Dense cosine prior",
    "separate": "Separate phase axes",
    "phase_pair": "Phase-paired prior",
    "transposed": "Transposed paired prior",
}


def camera(settings, calibration):
    upstream = reference(ROOT / "camera-fields.json")
    a = read_json(checked(upstream))
    prior = reference(ATLAS / "native/standing/result.json")
    saved = {r["id"]: r for r in read_json(checked(prior))["rows"]}
    room = ROOT / "native/standing"
    room.mkdir(parents=True)
    gains = {k: c["gain"] for k, c in settings["4800"].items()}
    rows = []
    for r in a["rows"]:
        old = saved[r["id"]]
        with np.load(checked(r["paths"]), allow_pickle=False) as f:
            parent, wb, matrix, raw, colors = (
                f[k] for k in ("parent", "wb", "matrix", "raw", "colors")
            )
            field = {k: f[k] for k in gains}
        np.testing.assert_allclose(gains["dense"], r["prior_strength"], atol=1e-12, rtol=0)
        outputs = {k: parent + g * field[k] for k, g in gains.items()}
        results = {
            "std_gain": {k: r["prior_strength"] * w for k, w in r["unit_crop_DN16"].items()},
            "wire_flat_gain": gains,
            "wire_flat_DN16": {k: w * gains[k] for k, w in r["unit_crop_DN16"].items()},
        }
        if r["id"].startswith("mesh"):
            norms = r["unit_crop_DN16"]
            scale = {k: gains["dense"] * norms["dense"] / x for k, x in norms.items() if x > 0}
            matched = {k: parent + v * field[k] for k, v in scale.items()}
            lock = peak_fit(raw, parent, outputs, colors, r["roi"])
            equal_energy = peak_fit(raw, parent, matched, colors, r["roi"])
            fixed = peak_fit(
                raw,
                parent,
                {k: parent + r["prior_strength"] * v for k, v in field.items()},
                colors,
                r["roi"],
            )

            def delta(receipt):
                p = np.asarray(receipt["parent"]["percent_of_observed"])
                return {
                    k: (np.asarray(v["percent_of_observed"]) - p).tolist()
                    for k, v in receipt.items()
                    if k not in ("parent", "observed")
                }

            results.update(
                {
                    "same_RAW_projection": lock,
                    "gain_match_projection_pp": delta(lock),
                    "identical_gain_projection_pp": delta(fixed),
                    "equal_RGB_scale": scale,
                    "equal_RGB_projection_pp": delta(equal_energy),
                }
            )
            print(
                r["id"],
                results["wire_flat_DN16"],
                results["gain_match_projection_pp"],
                results["equal_RGB_projection_pp"],
                flush=True,
            )
        boards = []
        for d in old["displays"]:
            exp = d["exposure"]
            source = pixels(d["board"])
            np.testing.assert_array_equal(
                render(parent, wb, matrix, r["roi"], exp), source["Corpus 100k"]
            )
            np.testing.assert_array_equal(
                render(outputs["dense"], wb, matrix, r["roi"], exp), source["Dense atlas"]
            )
            panels = [
                (k, source[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Corpus 100k") if k in source
            ]
            panels.extend(
                (LABELS[k], render(outputs[k], wb, matrix, r["roi"], exp)) for k in LABELS
            )
            panels.extend(
                (k, source[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in source
            )
            boards.append(
                {"exposure": exp, "board": native_png(room / f"{r['id']}-x{exp:g}.png", panels)}
            )
        rows.append(r | results | {"displays": boards})
    write_json(
        room / "result.json",
        {
            "driver": reference(__file__),
            "inputs": upstream,
            "calibration": calibration,
            "prior": prior,
            "rows": rows,
        },
    )


def exact(q, settings, calibration, evaluated):
    room = ROOT / "native/exact"
    room.mkdir(parents=True)
    group = [row for row in q["short"] if row["width"]["4800"]["gap_pixels"]]
    scale = {k: v["gain"] for k, v in settings["4800"].items()}

    def change(row, key):
        c = row["width"]["4800"]
        return float(
            values([c], "phase_pair", key, scale["phase_pair"])[0]
            - values([c], "dense", key, scale["dense"])[0]
        )

    best = min(group, key=lambda r: change(r, HOLE))
    regressed = max((r for r in group if r is not best), key=lambda r: change(r, COMP))
    rows = []
    for row, note in (
        (best, "largest false projection reduction"),
        (regressed, "largest intact fundamental error increase among other gaps"),
    ):
        case = row["case"]
        f, b, v = replay.read_inputs(case)
        updates, _ = field_updates(case, f, b, 4800, include_dense=True)
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        with np.load(checked(case["input"]), allow_pickle=False) as file:
            gt = file["target"]
        for i, role in ((0, "present"), (3, "flat")):
            malvar = noisy_malvar(camera | {"packed": f["packed"][i : i + 1]})[0]
            labels = ("Noisy Malvar", "V120 EMA", "Corpus 100k", *LABELS.values(), "Exact GT")
            img = [malvar, v[i], b[i], *(b[i] + scale[k] * updates[k][i] for k in LABELS), gt[i]]
            rows.append(
                native_board(
                    room,
                    f"{case['id']}-{role}",
                    img,
                    camera,
                    {
                        "source": case,
                        "role": role,
                        "selection": note,
                        "scales": scale,
                        "diff_vs_dense": {key: change(row, key) for key in (COMP, HOLE, LENGTH)},
                    },
                    labels=labels,
                    triplet_indices=(0, labels.index(LABELS["phase_pair"]), len(labels) - 1),
                    exposure=2,
                    contrast=1,
                    roi=(48, 48, 160, 160),
                )
            )
    write_json(
        room / "result.json",
        {
            "driver": reference(__file__),
            "calibration": calibration,
            "results": evaluated,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    evaluated = reference(ROOT / "results.json")
    q = read_json(checked(evaluated))
    cal = q["settings"]
    s = read_json(checked(cal))["strengths"]
    if sys.argv[1] == "camera":
        camera(s, cal)
    else:
        assert sys.argv[1] == "exact"
        exact(q, s, cal, evaluated)
