"""Publish the measured phase-paired donor comparison and native views."""

import shutil
import tarfile
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
IMAGES = REPO / "docs" / "images" / ROOT.name
RESULTS = REPO / "docs" / "results" / ROOT.name
FILES = {
    "calibration": "calibration.json",
    "numerical": "results.json",
    "diagnostic": "diagnostics.json",
    "camera_fields": "camera-fields.json",
    "standing": "native/standing/result.json",
    "exact": "native/exact/result.json",
    "viewing": "views.json",
}


def copy(source, category=""):
    path = checked(source)
    dst = IMAGES / category / path.name
    assert not dst.exists()
    shutil.copyfile(path, dst)
    assert reference(dst)["sha256"] == source["sha256"]
    return source | {"path": str(dst.relative_to(IMAGES))}


def pixels(board):
    source = Image.open(checked(board["image"])).convert("RGB")
    result = {}
    for cell in board["panels"]:
        label = cell.get("label", cell.get("name"))
        x, y, w, h = cell["png_xywh"]
        assert (w, h) == (160, 160) and x + w <= source.width and y + h <= source.height
        result[label] = np.asarray(source.crop((x, y, x + w, y + h)))
    return result


def copy_board(board, category):
    pixels(board)
    return board | {"image": copy(board["image"], category)}


def main():
    refs = {k: reference(ROOT / p) for k, p in FILES.items()}
    receipts = {k: read_json(checked(v)) for k, v in refs.items()}
    c, numeric, diag, fields, standing, exact, viewed = receipts.values()
    assert c["prior_results"] == numeric["prior"]
    assert (
        numeric["settings"]
        == standing["calibration"]
        == exact["calibration"]
        == refs["calibration"]
    )
    assert refs["numerical"] == diag["results"] == exact["results"] == viewed["numeric"]
    assert refs["camera_fields"] == standing["inputs"]
    assert refs["standing"] == viewed["native"]["standing"]
    assert refs["exact"] == viewed["native"]["exact"]
    assert fields["operator"] == c["operator"]
    assert len(numeric["long"]) == len(numeric["natural"]) == 32 and len(numeric["short"]) == 24
    assert len(diag["analytic"]) == len(exact["rows"]) == 4
    assert len(standing["rows"]) == 8 and sum(len(r["displays"]) for r in standing["rows"]) == 12
    assert len(viewed["views"]) == 7
    for v in viewed["views"].values():
        checked(v)
    for r in fields["rows"]:
        checked(r["paths"])
    atlas = ROOT.with_name("scene-dense-atlas-v1")
    historical = read_json(checked(read_json(checked(c["older"]))["inputs"]["long"]))
    weights = historical["weights"]

    (IMAGES / "standing").mkdir(parents=True)
    (IMAGES / "exact").mkdir()
    RESULTS.mkdir(parents=True)
    stands = []
    for row in standing["rows"]:
        displays = []
        for d in row["displays"]:
            names = set(pixels(d["board"]))
            assert {
                "Noisy (Malvar)",
                "Corpus 100k",
                "V120 EMA",
                "Dense cosine prior",
                "Phase-paired prior",
                "ISO100 AHD reference",
            } <= names
            if row["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= names
            displays.append(d | {"board": copy_board(d["board"], "standing")})
        stands.append(row | {"displays": displays})
    triplets = []
    for row in exact["rows"]:
        source = pixels(row["board"])
        trio = pixels(row["triplet"])
        assert list(trio) == ["Noisy Malvar", "Phase-paired prior", "Exact GT"]
        for key, frame in trio.items():
            np.testing.assert_array_equal(source[key], frame)
        triplets.append(row | {key: copy_board(row[key], "exact") for key in ("board", "triplet")})
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "checkpoint": weights,
            "standing": stands,
            "exact": triplets,
            "figure": copy(viewed["figure"]),
            "photo_credits": {
                "retained-12": "Selbymay photograph, David d’Angers sculpture, CC BY-SA 3.0 for the photograph",
                "retained-20": "Moonik photograph, CC BY-SA 3.0",
            },
            "review": {
                "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                "standing_sheets": refs["viewing"],
                "standing_main": "Sky is smooth. Coarse fence remains connected. Fine building lines and leaf subdivisions stay soft.",
                "standing_cab": "Both profiles and exposures viewed with both camera JPEGs and independent AHD. Mottled nominal left, incomplete fine crossings. Transferred right has the clearest existing diagonals.",
                "exact": "Both selected wire cases retain softer weaker diagonals than the exact target. Flat controls remain visually smooth.",
            },
        },
    )
    evidence = RESULTS / "evidence.tar.xz"
    payload = [
        *refs.values(),
        *[r["driver"] for r in receipts.values()],
        c["operator"],
        reference(__file__),
        reference(manifest),
        numeric["prior"],
        c["older"],
        standing["prior"],
        fields["dense_receipt"],
        reference(atlas / "measure_atlas.py"),
        reference(atlas / "atlas_probe.py"),
        reference(ROOT.with_name("scene-patch-width-v1") / "evaluate_wide.py"),
        reference(ROOT.with_name("scene-patch-width-v1") / "render_wide.py"),
        reference(REPO / "src/demosaic/scene_patch_covariance.py"),
        reference(REPO / "configs/gfx-qualitative-20231231.json"),
        reference(REPO / "configs/gfx-green-mesh-20231231.json"),
    ]
    hashes = {}
    with tarfile.open(evidence, "x:xz", preset=4) as archive:
        for ref in {ref["path"]: ref for ref in payload}.values():
            p = checked(ref)
            key = p.relative_to(REPO).as_posix()
            archive.add(p, arcname=key)
            hashes[key] = ref["sha256"]
    with tarfile.open(evidence) as archive:
        for k, v in hashes.items():
            assert sha256(archive.extractfile(k).read()).hexdigest() == v
    write_json(
        RESULTS / "publication.json",
        {
            "scope": "Frozen Corpus 100k inference component, with retained synthetic and natural validation and both standing GFX native reviews.",
            "checkpoint": weights,
            "camera_and_exact_review_complete": True,
            "strengths": c["strengths"],
            "equal_response": diag["equal_response"],
            "cohorts": {k: len(numeric[k]) for k in ("long", "short", "natural")},
            "timing_seconds": {
                "calibration": c["elapsed_seconds"],
                **numeric["elapsed_seconds"],
                "camera_probe": fields["seconds"],
            },
            "summary": numeric["summary"],
            "receipts": refs,
            "native": reference(manifest),
            "archive": reference(evidence),
            "members": hashes,
        },
    )


if __name__ == "__main__":
    main()
