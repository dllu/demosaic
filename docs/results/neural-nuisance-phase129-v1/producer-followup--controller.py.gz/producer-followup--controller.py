import os,sys,time,subprocess
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json,write_json,checked,reference
f=Path(sys.argv[1]);p=read_json(f/'plan.json');root=Path(p['root']);identity=p['producer']
while psutil.pid_exists(identity['pid']):
 try:
  process=psutil.Process(identity['pid'])
  if process.create_time()!=identity['create_time'] or process.status()==psutil.STATUS_ZOMBIE:break
 except psutil.NoSuchProcess:break
 time.sleep(5)
result=read_json(root/'controller-result.json')
if not result['all_stages_succeeded']:
 write_json(f/'result.json',{'status':'original-controller-failed','result':result});sys.exit(1)
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=p['work']+'/src:'+p['work']+'/scripts',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
with(f/'review.log').open('x')as log:
 process=subprocess.Popen([sys.executable,str(checked(p['script'])),str(root),p['output']],env=env,stdout=log,stderr=subprocess.STDOUT)
 write_json(f/'review-launch.json',{'pid':process.pid,'create_time':psutil.Process(process.pid).create_time()})
 code=process.wait()
write_json(f/'result.json',{'status':'completed'if code==0 else'failed','returncode':code,'plan':reference(f/'plan.json')})
