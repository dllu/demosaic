"""Seal exact artifacts only after every native sheet has a viewing receipt."""
import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-phase129-pilot-v1'
destination = repo / 'docs/results/neural-nuisance-phase129-v1'
prepared = read_json(root / 'publication-prepared.json')
manifest = read_json(root / 'contact-sheets/manifest.json')
batches = sorted(root.glob('viewing-batch-*.json'))
viewed = []
for path in batches:
    batch = read_json(path)
    assert batch['actually_viewed'] and batch['notes']
    viewed.extend(batch['sheets'])
assert sorted(viewed) == list(range(len(manifest['sheets'])))
assert manifest['source_images'] == len(prepared['images']) == 38
archives = list(prepared['archives'])
for source in [root / 'publication-prepared.json', root / 'contact-sheets/manifest.json',
               *batches, repo / '.cache/native-contact-sheets-v1.py', Path(__file__),
               repo / '.cache/summarize-phase129-v1.py', repo / '.cache/phase129-numerical-summary-v1.json',
               repo / '.cache/close-phase-publication-prep-v1.py', repo / '.cache/phase-publication-prep-result-v1.json',
               repo / '.cache/background-phase-final-ruff-v1.log']:
    target = destination / ('addendum-' + source.name + '.gz')
    with target.open('xb') as stream:
        stream.write(gzip.compress(source.read_bytes(),mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({'original':reference(source),'published':reference(target),'decompressed_bytes_exact':True})
for item in archives:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
for item in prepared['images']:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
prepared.update(archives=archives,
    viewing={'actually_viewed':True,'figures':38,'contact_sheets':len(manifest['sheets']),
             'manifest':reference(root/'contact-sheets/manifest.json'),'batches':[reference(p)for p in batches]},
    status='complete; much higher constructed weak response with noise/error and real-artifact costs',
    quality_decision='Neural phase400/far weak response4.695% to27.390%, both sources gain response, but quiet+2.352% and weak-increment+0.434% versus parent. Analytic phase28.558% with increment-0.539%, but larger real bands. NN building maximum75.18 DN16 versus15.55 prior sinusoidal; analytic531.58 versus302.55. Fine cab crossings remain absent. Preserve as experimental capacity/error tradeoff; no preferred operating point or general model change.',
    comparison_baselines=[reference(repo/'docs/results'/name/'publication.json')for name in [
        'neural-nuisance-fixed-bg129-v1','neural-nuisance-hann512-v1','neural-nuisance-fixed-v1']],
    scope_clarification='Fixed global joint-fit background; global competing H1 subtraction; native129 phase average minus local mean. Identical fixed composite operator on RAW and parent innovation. Prior sinusoidal129 has local competing-direction fits, so this is a complete reconstruction comparison, not a waveform-only causal ablation. No neural replay or learned update.',
    published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination/'publication.json',prepared)
print(len(archives),'exact archives;',len(prepared['images']),'source figures actually viewed')
