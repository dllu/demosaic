"""Render matched optical and GFX crops for the connected support study."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_occlusion as model
from evaluate_occlusion import metric
from view_camera_references import panels
from view_adaptive import board, image

OUT = model.OUT
CROP = model.s.crop
REFIT_LABEL = "Connected amplitude refit"


def load_array(ref):
    return np.load(checked(ref), allow_pickle=False)


def render(views, modes):
    baseline = views["baseline"]
    displayed = []
    names = {
        "regional_refit": "Regional RAW refit",
        "local_curve": "Local curved phase",
        "ordinary_pool": "Locked whole-region pool",
        "region_pool": "Connected support",
        "region_refit": REFIT_LABEL,
        "true_support_curve": "Known support (diagnostic)",
    }
    for key, label in names.items():
        arm, dose = modes[key]
        value = views[arm]
        if dose != 1:
            value = (baseline + dose * (value.astype(float) - baseline)).astype(baseline.dtype)
        displayed.append((label, value))
    return displayed


def exact(data, folder, modes):
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + 48, y + 48, 160, 160)
    local = (48, 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    best = {}
    for row in data["rows"]:
        if row["fixture"]["geometry"]["stationary_junction"]:
            continue
        for draw in row["draws"]:
            parent = metric.values(draw, modes["ordinary_pool"])
            trial = metric.values(draw, modes["region_refit"])
            kind = "gapped" if metric.GAP in trial else "continuous"
            change = parent[metric.JUNCTION] - trial[metric.JUNCTION]
            if kind == "gapped":
                residue = parent[metric.GAP] - trial[metric.GAP]
                if residue < 0:
                    continue
            weight = change
            if kind not in best or weight > best[kind][0]:
                best[kind] = (weight, row, draw)
    views = []
    for kind, (gain, row, draw) in best.items():
        parent = load_array(draw["outputs"]["local50k"])[0]
        with load_array(draw["input"]) as data:
            inputs = {k: data[k] for k in data.files}
        scene = inputs["scene_packed"].copy()
        scene[cut] = inputs["packed"][0]
        wb, matrix, colors = [inputs[k] for k in ("wb", "matrix", "colors")]
        all_, trace = model.replay(
            parent,
            local,
            scene,
            colors,
            roi,
            plan["noise"],
            wb,
            matrix,
            geometry=inputs["support"][48:208, 48:208],
        )
        test = render(all_, modes)
        noisy = noisy_malvar(
            {
                "packed": inputs["packed"][:1],
                **{k: inputs[k][None] for k in ("colors", "wb", "matrix")},
            }
        )[0]
        tiles = [
            ("Noisy Malvar", CROP(noisy, local)),
            ("Local 50k", CROP(parent, local)),
            *test,
            ("Exact GT", CROP(inputs["target"][0], local)),
        ]
        frames = {name: image(a, wb, matrix, 2) for name, a in tiles}
        fname = row["id"]
        triplet = board(
            [(k, frames[k]) for k in ("Noisy Malvar", REFIT_LABEL, "Exact GT")],
            folder / f"{fname}-triplet.png",
        )
        mont = board(list(frames.items()), folder / f"{fname}-comparison.png")
        views.append(
            {
                "id": fname,
                "fixture": row["fixture"],
                "draw": draw["draw"],
                "kind": kind,
                "junction_gain_over_locked_pool": gain,
                "trace": trace,
                "ROI": local,
                "scene_ROI": roi,
                "input": draw["input"],
                "outputs": draw["outputs"],
                "noise": plan["noise"],
                "exposure": 2,
                "all": mont,
                "triplet": triplet,
            }
        )
        print(fname, kind, gain, flush=True)
    return {"rows": views}


def camera(folder, modes):
    ctx = reference(
        OUT.with_name("adaptive-junction-phase-v1") / "views-camera-all-references.json"
    )
    prior = read_json(checked(ctx))["report"]
    corpus_receipt = reference(OUT / "corpus/parents.json")
    corpus = read_json(checked(corpus_receipt))
    external = {d["id"]: d for d in corpus["camera_outputs"]}
    results = []
    labels = ("Whole-region affine", "Connected affine", "Refitted affine")
    root_modes = dict(modes)
    root_modes.pop("true_support_curve")
    names = (
        ("full affine", "affine-pool"),
        ("connected affine", "affine-connected"),
        ("refitted affine", "affine-refit"),
    )
    for row in prior["rows"]:
        args = external[row["id"]]
        assert args["input"] == row["input"]
        balanced = [row["compared"], args["output"]]
        roi = row["local_ROI"]
        with load_array(row["input"]) as f:
            raw, cfa, wb, matrix = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        rendered, diagnostics, diff = {}, {}, {}
        for key, binding in zip(("Local 50k", "Corpus 100k"), balanced, strict=True):
            parent = load_array(binding)[0]
            views, trace = model.replay(
                parent, roi, raw, cfa, roi, row["noise"], wb, matrix, clearance=16
            )
            selected = [x for x in render(views, modes) if x[0] != "Known support (diagnostic)"]
            if key == "Local 50k":
                selected.extend(
                    (label, views[arm]) for label, (_, arm) in zip(labels, names, strict=True)
                )
            else:
                selected = [("Corpus 100k", CROP(parent, roi))] + [
                    ("Corpus " + n, v)
                    for n, v in selected
                    if n in {"Regional RAW refit", "Connected support", REFIT_LABEL}
                ]
            diagnostics[key] = trace
            diff[key] = {
                k: float(np.sqrt(np.mean((v.astype(float) - views["baseline"]) ** 2)) * 65535)
                for k, v in selected
            }
            rendered[key] = selected
        displays = []
        for carried in row["native"]:
            old = dict(panels(carried))
            ex = carried["exposure"]
            trials = [(k, old[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            for key in rendered:
                trials.extend((k, image(u, wb, matrix, ex)) for k, u in rendered[key])
            trials.extend(
                (k, old[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in old
            )
            obj = board(trials, folder / f"{row['id']}-x{ex:g}.png")
            displays.append(obj | {"exposure": ex, "source": carried})
        print(
            row["id"],
            {k: {n: round(v, 5) for n, v in m.items()} for k, m in diff.items()},
            flush=True,
        )
        results.append(
            {
                "id": row["id"],
                "input": row["input"],
                "RAW": row["RAW"],
                "noise": row["noise"],
                "ROI": row["ROI"],
                "local_ROI": roi,
                "traces": diagnostics,
                "difference_DN16": diff,
                "local50k": balanced[0],
                "corpus100k": balanced[1],
                "native": displays,
            }
        )
    return {"prior": ctx, "corpus": corpus_receipt, "rows": results}


if __name__ == "__main__":
    kind = sys.argv[1]
    torch.set_num_threads(2)
    end = reference(OUT / "evaluated-independent.json")
    data = read_json(checked(end))
    state = data["summary"]["modes"]
    folder = OUT / "native" / kind
    folder.mkdir(exist_ok=True, parents=True)
    output = exact(data, folder, state) if kind == "exact" else camera(folder, state)
    write_json(
        OUT / f"viewed-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "numerical": end,
            "report": output,
        },
    )
