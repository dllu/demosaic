"""Quantify actual delivery support and graph the response–gap tradeoff."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_occlusion import OUT, metric, earlier


def audit(data):
    stats = {}
    for role in ("region_pool", "region_refit", "ordinary_pool"):
        arm, dose = data["summary"]["modes"][role]
        per_file = []
        for row in data["rows"]:
            for draw in row["draws"]:
                t = draw["trace"][0]["arms"].get(arm, {})
                per_file.append(
                    {
                        "family": row["family"],
                        "phase": row["fixture"]["geometry"]["phase_class"],
                        "id": row["id"],
                        "draw": draw["draw"],
                        "changed": t.get("change", False),
                        "kept": t.get("minimum_kept", 1),
                        "shape": t.get("support_fit", {}),
                        "gapped": draw["gap_pixels"] > 0,
                        "delivered_DN16": float(np.sqrt(draw["power"][arm][metric.ABS][2]) * dose),
                    }
                )
        stats[role] = {
            "variable": [r for r in per_file if r["phase"] != "stationary" and r["changed"]],
            "stationary": [r for r in per_file if r["phase"] == "stationary" and r["changed"]],
        }
    return stats


def figure(groups):
    result, axes = plt.subplots(1, 2, figsize=(10.2, 4.2), layout="constrained")
    comparisons = {
        "curved-pool": ("Whole-region curve", "#5070a3"),
        "curved-refit": ("Connected curve refit", "#b33f22"),
        "affine-pool": ("Whole-region affine", "#287e82"),
        "affine-connected": ("Connected affine", "#8060a1"),
    }
    for axis, (kind, data) in zip(axes, groups, strict=True):
        split = earlier.panel_rows(data["rows"])
        base = data["summary"]["panels"]["varying"]["regional_refit"]["means"][metric.RESPONSE]
        for key, (label, color) in comparisons.items():
            doses = np.linspace(0, 1, 21)
            xx, yy = zip(
                *[
                    (
                        metric.score(split["all"], (key, d))["means"][metric.GAP],
                        metric.score(split["varying"], (key, d))["means"][metric.RESPONSE] - base,
                    )
                    for d in doses
                ]
            )
            axis.plot(xx, yy, label=label, color=color)
            for role in ("region_pool", "region_refit", "ordinary_pool"):
                choice = data["summary"]["modes"][role]
                if choice[0] == key:
                    n = round(choice[1] * 20)
                    axis.scatter(xx[n], yy[n], color=color, s=25)
        exact = data["summary"]["panels"]["varying"]["true_support_curve"]["means"][metric.RESPONSE]
        axis.scatter(
            0, exact - base, marker="*", s=80, c="#665126", label="Curve with known support"
        )
        axis.axvline(0.15, color="#555", linewidth=1, linestyle=":")
        axis.set_title(kind)
        axis.set_xlabel("Mean added gap luma (DN16)")
        axis.grid(axis="y", alpha=0.2)
    axes[0].set_ylabel("Interaction contrast gained (percentage points)")
    axes[0].legend(frameon=False, fontsize=8, loc="lower right")
    dest = OUT / "gain-vs-gap.png"
    result.savefig(dest, dpi=160)
    return reference(dest)


if __name__ == "__main__":
    src = {
        k: reference(OUT / f"evaluated-{k}.json") for k in ("calibration", "independent", "corpus")
    }
    rows = {k: read_json(checked(v)) for k, v in src.items()}
    support = {k: audit(data) for k, data in rows.items()}
    plot = figure(
        (("Earlier calibration", rows["calibration"]), ("New displaced gaps", rows["independent"]))
    )
    write_json(
        OUT / "diagnostics.json",
        {
            "driver": reference(Path(__file__)),
            "sources": src,
            "support": support,
            "plot": plot,
        },
    )
    for k, g in support.items():
        for name, score in g.items():
            print(
                k,
                name,
                "variable",
                len(score["variable"]),
                "masked",
                sum(r["kept"] < 1 for r in score["variable"]),
                "stationary",
                len(score["stationary"]),
                "max_stationary_DN16",
                max((r["delivered_DN16"] for r in score["stationary"]), default=0),
                flush=True,
            )
