"""Lock connected support on earlier photos and measure transfer to displaced gaps."""

from pathlib import Path
from time import monotonic
from unittest.mock import patch
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_occlusion as model
import evaluate_adaptive as earlier

metric = earlier.metric
OUT = model.OUT
LIMITS = earlier.LIMITS
BASE = earlier.BASE
LOCK_GROUPS = {
    "ordinary_pool": ("curved-pool", "affine-pool"),
    "region_pool": ("curved-connected", "curved-repeated", "affine-connected"),
    "region_refit": ("curved-refit", "affine-refit"),
}
STRATEGIES = {
    "regional_refit": BASE,
    "local_curve": ("curved", 1),
    "full_curve_pool": ("curved-pool", 1),
    "true_support_curve": ("curved-truth", 1),
    "full_affine_pool": ("affine-pool", 1),
    "true_support_affine": ("affine-truth", 1),
}


def collect(src, key="local50k"):
    receipt = read_json(checked(src))
    inputs = read_json(checked(receipt["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    gathered = []
    start = monotonic()
    for fixture, upstream in zip(plan["sources"], receipt["records"], strict=True):
        assert fixture["id"] == upstream["id"]
        draws = []
        for args in upstream["streams"]:
            with np.load(checked(args["data"]), allow_pickle=False) as payload:
                content = {k: payload[k] for k in payload.files}
            restored = np.load(checked(args["outputs"][key]), allow_pickle=False)
            truth = content["support"][48:208, 48:208]
            assert truth.shape == (160, 160)
            role = -1

            class Adapter:
                ARMS = model.ARMS

                @staticmethod
                def apply(*a, **k):
                    nonlocal role
                    role += 1
                    support = truth if role in (0, 1) else None
                    return model.replay(*a, **k, geometry=support)

            with patch.object(metric, "model", Adapter):
                row = metric.assess(
                    fixture,
                    plan["noise"],
                    restored,
                    content,
                    content["scene_packed"].copy(),
                    cut,
                    local,
                    roi,
                )
            draws.append(
                row | {"input": args["data"], "outputs": args["outputs"], "draw": args["draw"]}
            )
        gathered.append(
            {
                "fixture": fixture,
                "family": fixture["geometry"]["family"],
                "draws": draws,
                "id": fixture["id"],
            }
        )
        if len(gathered) % 8 == 0:
            print("Replayed", len(gathered), flush=True)
    return gathered, inputs["plan"], monotonic() - start


def lock(rows):
    panels = earlier.panel_rows(rows)
    base_error = metric.score(panels["stationary"], BASE)["means"][metric.JUNCTION]
    rules = {}
    for name, arms in LOCK_GROUPS.items():
        trials = []
        for arm in arms:
            for dose in np.linspace(0, 1, 21):
                key = (arm, float(dose))
                all_, varying, stationary = [
                    metric.score(panels[panel], key) for panel in ("all", "varying", "stationary")
                ]
                trials.append(
                    {
                        "key": key,
                        "all": all_,
                        "varying": varying,
                        "stationary": stationary,
                        "allowed": earlier.spatial_eval.within(all_, stationary, base_error),
                    }
                )
        winner = max(
            (q for q in trials if q["allowed"]),
            key=lambda q: (
                q["varying"]["means"][metric.RESPONSE],
                -q["varying"]["means"][metric.JUNCTION],
            ),
        )
        rules[name] = {"locked": winner["key"], "trials": trials}
    return {"groups": rules, "limits": LIMITS}


def summarize(rows, policy):
    modes = STRATEGIES | {k: item["locked"] for k, item in policy["groups"].items()}
    panels = earlier.panel_rows(rows)
    all_stats = {label: metric.score(panels["all"], key) for label, key in modes.items()}
    summaries = {}
    for category, selection in panels.items():
        comparisons = {}
        for name, key in modes.items():
            stats = metric.score(selection, key)
            if key != BASE:
                stats["versus_parent"] = metric.paired(selection, key, BASE)
            comparisons[name] = stats
        summaries[category] = comparisons

    equal = {}
    for name in ("region_pool", "region_refit"):
        arm, scale = modes[name]
        comparison = arm.split("-")[0] + "-pool"
        tgt = all_stats[name]["means"][metric.GAP]
        raw = metric.score(panels["all"], (comparison, 1))["means"][metric.GAP]
        dose = min(1.0, tgt / raw) if raw else 0.0
        equal[name] = {
            "neutralized_pool_scale": dose,
            "original_mode": (arm, scale),
            "added_gap": [tgt, raw * dose],
            "versus_pool": metric.paired(panels["varying"], (arm, scale), (comparison, dose)),
        }
    for name in ("true_support_curve", "true_support_affine"):
        arm = modes[name]
        comparison = arm[0].split("-")[0] + "-pool"
        tgt = all_stats[name]["means"][metric.GAP]
        raw = metric.score(panels["all"], (comparison, 1))["means"][metric.GAP]
        dose = min(1.0, tgt / raw) if raw else 0.0
        equal[name] = {
            "oracle_assist": True,
            "neutralized_pool_scale": dose,
            "original_mode": arm,
            "added_gap": [tgt, raw * dose],
            "versus_pool": metric.paired(panels["varying"], arm, (comparison, dose)),
        }
    return {"modes": modes, "panels": summaries, "equal_gap": equal}


def main(kind):
    folder = OUT if kind == "independent" else model.phase.OUT
    source = reference(folder / "independent/parent/result.json")
    cal = None if kind == "calibration" else reference(OUT / "evaluated-calibration.json")
    rows, plan, elapsed = collect(source)
    policy = lock(rows) if cal is None else read_json(checked(cal))["policy"]
    summary = summarize(rows, policy)
    print(summary["modes"])
    for label, m in summary["panels"]["varying"].items():
        print(
            label,
            [round(m["means"][k], 6) for k in (metric.RESPONSE, metric.JUNCTION, metric.GAP)],
            round(summary["panels"]["all"][label]["means"][metric.GAP], 6),
            flush=True,
        )
    write_json(
        OUT / f"evaluated-{kind}.json",
        {
            "driver": reference(__file__),
            "operator": reference(model.__file__),
            "source": source,
            "plan": plan,
            "calibration": cal,
            "policy": policy,
            "summary": summary,
            "seconds": elapsed,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
