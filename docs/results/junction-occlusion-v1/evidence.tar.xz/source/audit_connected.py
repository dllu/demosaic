"""Verify nomination, independent replication and ordinary-photo behavior."""

from pathlib import Path
from unittest.mock import patch
import sys

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import junction_occlusion as model
from audit_spatial import F, GEOMETRY, ROI, observation, pack
import ordinary_phase


def audit():
    s, j = model.s, model.j
    rng = np.random.default_rng(92011)
    truth = model.Region("oval", (26, -25), (23, 30), 0.2)
    x0, y0 = ROI[0] - 48, ROI[1] - 48
    y, x = np.indices((544, 544))
    x, y = x - x0 - j._CENTER, y - y0 - j._CENTER
    phase = s.supplied_phase(GEOMETRY)
    a, b = phase(x.ravel(), y.ravel()).T.reshape(2, 544, 544)
    kept = 1 - truth.deficit(x, y)
    raw = 0.21 + 0.030 * np.cos(a) + kept * (0.027 * np.cos(b) - 0.009 * np.cos(a - b))
    raw += rng.normal(0, 0.005, raw.shape)
    data = {}
    for name, colors in PATTERNS.items():
        rgb = observation(pack(raw), colors)
        inner = np.maximum(abs(rgb.x), abs(rgb.y)) < 96
        taper = np.exp(-0.5 * (rgb.x**2 + rgb.y**2) / 75**2)
        center = s.stationary(rgb, inner, taper)
        bands = j._distinct_bands(F)
        model_fit = model.phase.discover(rgb, F, bands, inner, taper, center)[0]["curved"]
        expected = model.nominate(rgb, model_fit, inner)
        (found, depth), record = model.check_prediction(rgb, model_fit, inner, expected)
        assert found is not None and expected[0] == 1 and depth >= 0.7
        np.testing.assert_allclose(found.center, truth.center, atol=12)

        def replace_folds(from_):
            repl = raw.copy()
            mask = np.repeat(np.repeat(j._folds() >= from_, 2, axis=0), 2, axis=1)
            repl[y0 : y0 + 256, x0 : x0 + 256][mask] = rng.uniform(0.07, 0.37, mask.sum())
            return observation(pack(repl), colors)

        for first in (1, 2):
            modified = replace_folds(first)
            new = model.phase.discover(modified, F, bands, inner, taper, center)[0]["curved"]
            regenerated = model.nominate(modified, new, inner)
            assert expected == regenerated
            _, diagnosis = model.check_prediction(modified, new, inner, regenerated)
            if first == 2:
                assert diagnosis == record
            else:
                assert diagnosis["Q1_z"] != record["Q1_z"]

        # Check sufficient-statistic variance and z against an explicit weighted solve.
        direction, i = expected[:2]
        a = model_fit
        use = inner & (rgb.fold == 1)
        x, y = rgb.x[use], rgb.y[use]
        phase_wave = np.cos(a.angles[use])
        uv = np.stack((x, y), axis=1) / 96
        slopes = (phase_wave[:, :, None] * uv[:, None, :]).reshape(len(x), -1)
        nuisance = [a.nuisance[use], a.signal[use], slopes]
        if rgb.nuisance.shape[1] == 14:
            nuisance.append(phase_wave * rgb.nuisance[use, 8, None])
        base = np.column_stack(nuisance)
        u, v = (x + 96) // 8 * 8 - 92, (y + 96) // 8 * 8 - 92
        template = -phase_wave[:, direction] * found.deficit(u, v)
        weight = 1 / np.sqrt(rgb.variance[use])
        basis, target, observed = base * weight[:, None], template * weight, rgb.raw[use] * weight
        fit = np.linalg.lstsq(basis, target, rcond=1e-8)[0]
        residual = target - basis @ fit
        z = float(residual @ observed / np.linalg.norm(residual))
        assert abs(z - record["Q1_z"]) < 1e-8
        data[name] = record | {
            "direct_replicate_z": z,
            "Q2_Q3_isolation": True,
            "Q1_nomination_isolation": True,
        }
    return data


if __name__ == "__main__":
    if sys.argv[1] == "ordinary":
        with (
            patch.object(ordinary_phase, "model", model),
            patch.object(ordinary_phase, "OUT", model.OUT),
        ):
            ordinary_phase.main()
    else:
        record = audit()
        print(record, flush=True)
        write_json(
            model.OUT / "audit.json",
            {
                "driver": reference(Path(__file__)),
                "operator": reference(model.__file__),
                "odd_origin": ROI,
                "layouts": record,
            },
        )
