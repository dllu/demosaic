"""Predict connected losses in a wire's fundamental from separate Bayer observations."""

from dataclasses import dataclass
from functools import cache
from itertools import product
from pathlib import Path
from unittest.mock import patch
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("adaptive-junction-phase-v1")))
import adaptive_phase_field as phase

s = phase.spatial
j = s.j
ARMS = (
    "baseline",
    "curved",
    "affine",
    "curved-pool",
    "affine-pool",
    "curved-connected",
    "curved-repeated",
    "curved-refit",
    "affine-connected",
    "affine-refit",
    "curved-truth",
    "affine-truth",
)
SIDE = 192
STEP = 8
CELLS = SIDE // STEP
FAMILIES = ("affine", "curved")
Q0_MIN = 3.5
REPEATS = (1.25, 2.25)


@dataclass(frozen=True)
class Region:
    kind: str
    center: tuple[float, float]
    radii: tuple[float, float]
    angle: float

    def deficit(self, x, y):
        u, v = x - self.center[0], y - self.center[1]
        c, s = np.cos(self.angle), np.sin(self.angle)
        across = (c * u + s * v) / self.radii[0]
        if self.kind == "strip":
            rho = abs(across)
        else:
            along = (-s * u + c * v) / self.radii[1]
            rho = np.hypot(across, along)
        # Flat core with a smooth shoulder. No carrier phase or samples define the bank.
        bump = np.clip((1.38 - rho) / 0.65, 0, 1)
        return bump**2 * (3 - 2 * bump)


@cache
def bank():
    ellipse = [
        Region("oval", (u, v), (a, b), theta)
        for u, v in product(range(-72, 73, 24), repeat=2)
        for a, b, steps in ((13, 13, 1), (23, 23, 1), (35, 35, 1), (15, 33, 4), (25, 50, 4))
        for theta in np.arange(steps) * np.pi / steps
    ]
    strip = [
        Region("strip", (d * np.cos(a), d * np.sin(a)), (w, 1), a)
        for a in np.arange(8) * np.pi / 8
        for d in range(-60, 61, 20)
        for w in (17, 30)
    ]
    regions = tuple(ellipse + strip)
    y, x = np.meshgrid(np.arange(CELLS) * STEP - 92, np.arange(CELLS) * STEP - 92, indexing="ij")
    design = np.stack([k.deficit(x.ravel(), y.ravel()) for k in regions])
    return regions, design, design**2


@dataclass
class GridScore:
    moment: np.ndarray
    power: np.ndarray
    couplings: np.ndarray
    inverse: np.ndarray
    beta: np.ndarray
    index: int

    def templates(self, design, energy):
        proj = design @ self.couplings
        remnant = energy @ self.power - ((proj @ self.inverse) * proj).sum(axis=1)
        return design @ self.moment, np.maximum(remnant, 1e-18)

    def fit(self, design, energy):
        dot, power = self.templates(design[None], energy[None])
        amplitude = float((dot / power)[0])
        reconstruction = self.beta - (self.inverse @ (design @ self.couplings)) * amplitude
        wire = float(reconstruction[self.index])
        depth = float(np.clip(amplitude / max(1e-8, wire), 0, 1))
        return float((dot / np.sqrt(power))[0]), depth


def grid_scores(obs, a, inner, fold):
    active = inner & (obs.fold == fold)
    x, y = obs.x[active], obs.y[active]
    cell = (((y + SIDE / 2) // STEP) * CELLS + ((x + SIDE / 2) // STEP)).astype(int)
    levels = obs.raw[active]
    weight = 1.0 / obs.variance[active]
    wire = np.cos(a.angles[active])
    # Allow both fundamental amplitudes to vary gradually across the field.
    # The tested interaction and the stationary band stay in the nuisance.
    tilt = np.stack((x, y), axis=1) / 96
    slopes = (wire[:, :, None] * tilt[:, None, :]).reshape(len(wire), -1)
    cols = [a.nuisance[active], a.signal[active], slopes]
    if obs.nuisance.shape[1] == 14:
        cols.append(wire * obs.nuisance[active, 8, None])
    design = np.column_stack(cols)
    left = design.T * weight
    cov = np.linalg.pinv(left @ design, hermitian=True, rcond=1e-9)
    beta = cov @ (left @ levels)
    background_error = levels - design @ beta
    scores = []
    for d in range(2):
        r = -wire[:, d]
        weighted = r * weight
        bins = CELLS**2
        moments = np.bincount(cell, weights=weighted * background_error, minlength=bins)
        powers = np.bincount(cell, weights=weighted * r, minlength=bins)
        cross = np.zeros((bins, design.shape[1]))
        np.add.at(cross, cell, weighted[:, None] * design)
        scores.append(GridScore(moments, powers, cross, cov, beta, obs.nuisance.shape[1] + 2 * d))
    return scores


def nominate(obs, a, inner):
    regions, design, energy = bank()
    discover = grid_scores(obs, a, inner, 0)
    raw = [score.templates(design, energy) for score in discover]
    z = np.stack([m / np.sqrt(v) for m, v in raw])
    direction, chosen = np.unravel_index(z.argmax(), z.shape)
    q0, depth0 = discover[direction].fit(design[chosen], energy[chosen])
    return int(direction), int(chosen), q0, depth0


def check_prediction(obs, a, inner, forecast):
    direction, chosen, q0, depth0 = forecast
    if q0 < Q0_MIN:
        return (None, 0.0), {"Q0_z": q0, "Q0_depth": depth0}
    regions, design, energy = bank()
    replicate = grid_scores(obs, a, inner, 1)[direction]
    q1, depth1 = replicate.fit(design[chosen], energy[chosen])
    region = regions[chosen]
    # Subtract only the replicated fraction of the measured attenuation.
    depth = min(depth0, depth1) * np.clip((q1 - 0.5) / 2, 0.0, 1.0)
    note = {
        "Q0_z": q0,
        "Q0_depth": depth0,
        "Q1_z": q1,
        "Q1_depth": depth1,
        "delivered_depth": float(depth),
        "region": vars(region),
        "direction": direction,
        "index": chosen,
    }
    return (region, depth), note


def fields(obs, a, inner, xx, yy):
    prediction = nominate(obs, a, inner)
    (region, depth), record = check_prediction(obs, a, inner, prediction)
    q1 = record.get("Q1_z", 0)
    abstain = np.ones_like(xx)
    if region is None or q1 < REPEATS[0]:
        return (abstain, abstain), record
    shaped = 1 - depth * region.deficit(xx, yy)
    return (shaped, shaped if q1 >= REPEATS[1] else abstain), record


def render(anchor, context, obs, f, center, a, wb, matrix, inner, supplied):
    rgb = context[1].copy()
    rgb[s.CROP] = anchor[1]
    iy, ix = (obs.y + j._CENTER).astype(int), (obs.x + j._CENTER).astype(int)
    rgb = rgb[iy, ix]
    neutral = np.linalg.solve(matrix.astype(float), np.ones(3)) / wb
    neutral /= neutral[1]
    wire = j._local_wire_support(obs, a.angles)
    full = (s.FULL_X, s.FULL_Y)
    angles = s.phases(*full, a.coefficients, f, a.curved)
    stationary = s.stationary_side(*full, j._wave_angles(*full, f), center)
    sign, cap = np.sign(a.amplitude), abs(a.amplitude)
    harmonic = sign * (np.cos(angles[:, 0] - angles[:, 1]) - stationary @ a.station).reshape(
        256, 256
    )
    edge = j._FIELD_EDGE[:, None] * j._FIELD_EDGE
    common = j._GAINS * wire * (harmonic * edge)[s.CROP]
    columns = np.c_[a.nuisance, a.signal]
    index = a.nuisance.shape[1]
    local = j._amplitudes(obs, columns, index, sign, cap, rgb, sigma=35, radius=80)
    whole = phase.pool(obs, columns, index, sign, cap, rgb)
    field, restricted = np.ones((256, 256)), np.ones((256, 256))
    newer = whole
    reply = {}
    if whole > 0:
        (field, restricted), reply = fields(obs, a, inner, j._GRID_X, j._GRID_Y)
        if np.any(field < 1):
            refit = np.c_[a.nuisance, a.signal * field[iy, ix]]
            newer = phase.pool(obs, refit, index, sign, cap, rgb)
    know = supplied if supplied is not None else np.ones((160, 160))
    scales = {
        "local": local[s.CROP],
        "pool": whole,
        "connected": whole * field[s.CROP],
        "repeated": whole * restricted[s.CROP],
        "refit": newer * field[s.CROP],
        "truth": whole * know,
    }

    def deliver(amplitude):
        return (anchor + (common * amplitude) * neutral[:, None, None]).astype(anchor.dtype)

    return {k: deliver(scale) for k, scale in scales.items()}, {
        "support_fit": reply,
        "pooled_DN16": whole * 65535,
        "refitted_DN16": newer * 65535,
        "mean_kept": float(field[s.CROP].mean()),
        "minimum_kept": float(field[s.CROP].min()),
    }


def deliver(anchor, context, obs, f, bands, wb, matrix, *, geometry=None):
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    taper = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2)
    center = s.stationary(obs, inner, taper)
    templates, _ = phase.discover(obs, f, bands, inner, taper, center)
    output = dict.fromkeys(ARMS, anchor)
    trace = {}
    for name, a in templates.items():
        permitted, note = phase.validate(obs, a, inner)
        if permitted:
            values, readout = render(
                anchor, context, obs, f, center, a, wb, matrix, inner, geometry
            )
            note.update(readout)
            for k, img in values.items():
                key = name if k == "local" else f"{name}-{k}"
                if key in output:
                    output[key] = img
        record = note | {"admitted": permitted}
        for key, img in output.items():
            if key == name or key.startswith(f"{name}-"):
                trace[key] = record | {"change": not np.array_equal(img, anchor)}
    return output, {"status": "measured", "arms": trace}


def replay(*args, **kwargs):
    with patch.object(s, "ARMS", ARMS), patch.object(s, "deliver", deliver):
        return s.replay(*args, **kwargs)
