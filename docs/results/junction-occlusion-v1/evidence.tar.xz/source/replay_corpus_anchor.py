"""Bind the same observed mosaics to the measured Corpus 100k EMA."""

from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_occlusion import OUT
from junction_occlusion import HERE

from demosaic.inference import load_checkpoint

FIXED = OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"
ANCHOR = HERE.with_name("scene-full-epoch-v1") / "plan.json"


def restore_one(model, batch, noise):
    total = len(batch["packed"])
    values = []
    model.set_noise(noise["shot"], noise["read"])
    for first in range(0, total, 3):
        subset = batch | {k: batch[k][first : first + 3] for k in ("packed", "variance")}
        tensors = [
            torch.from_numpy(subset[k]).cuda().contiguous(memory_format=torch.channels_last)
            for k in ("packed", "variance")
        ]
        count = len(subset["packed"])
        for k in ("colors", "wb", "matrix"):
            value = torch.from_numpy(subset[k]).cuda()
            tensors.append(value[None].expand(count, *value.shape))
        values.append(model(*tensors).cpu().numpy())
    restored = np.concatenate(values, axis=0)
    height, width = batch["packed"].shape[-2:]
    assert restored.shape == (total, 3, 2 * height, 2 * width) and np.isfinite(restored).all()
    return restored


def save(bind, model, path, noise, *, repackage=False):
    if not path.exists():
        with np.load(checked(bind), allow_pickle=False) as payload_file:
            payload = {k: payload_file[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
        if repackage:
            for k in ("colors", "wb", "matrix"):
                payload[k] = payload[k][0]
        result = restore_one(model, payload, noise)
        temp = path.with_suffix(".partial")
        with temp.open("xb") as f:
            np.save(f, result, allow_pickle=False)
        temp.rename(path)
    return reference(path)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    root = OUT / "corpus"
    root.mkdir(exist_ok=True)
    source = reference(OUT / "independent/parent/result.json")
    data = read_json(checked(source))
    half = read_json(checked(read_json(checked(data["inputs"]))["plan"]))["noise"]
    anchor_binding = reference(ANCHOR)
    checkpoint = read_json(checked(anchor_binding))["parent"]
    camera_src = reference(FIXED)
    model, state = load_checkpoint(checked(checkpoint), "cuda", tiled_inference=True)
    assert "ema" in state and state["loaded_sha256"] == checkpoint["sha256"]
    model = model.eval().to(memory_format=torch.channels_last)
    s = monotonic()
    rows = []
    cameras = []
    with ieee_fp32():
        for row in data["records"]:
            pair = []
            for draw in row["streams"]:
                path = root / f"{row['id']}-{draw['draw']}.npy"
                output = save(draw["data"], model, path, half)
                pair.append(draw | {"outputs": draw["outputs"] | {"corpus100k": output}})
            rows.append(row | {"streams": pair})
            if len(rows) % 8 == 0:
                print("Replayed Corpus 100k", len(rows), flush=True)
        for row in read_json(checked(camera_src))["standing"]:
            path = root / f"{row['id']}.npy"
            output = save(row["input"], model, path, row["noise"], repackage=True)
            cameras.append({"id": row["id"], "input": row["input"], "output": output})
    write_json(
        root / "parents.json",
        {
            "driver": reference(__file__),
            "previous": source,
            "input_plan": anchor_binding,
            "inputs": data["inputs"],
            "weights": data["weights"] | {"corpus100k": checkpoint},
            "camera": camera_src,
            "camera_outputs": cameras,
            "records": rows,
            "seconds": monotonic() - s,
            "policy": "Corpus 100k EMA; IEEE FP32; 256 px fixtures and matched 512/768 px camera queries",
        },
    )


if __name__ == "__main__":
    main()
