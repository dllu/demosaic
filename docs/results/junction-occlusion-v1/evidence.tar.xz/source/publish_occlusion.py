"""Publish exact, camera and numeric evidence for connected Bayer support."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_occlusion import metric, earlier, BASE
from junction_occlusion import OUT, HERE

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
NAMES = (
    "evaluated-calibration",
    "evaluated-independent",
    "evaluated-corpus",
    "diagnostics",
    "audit",
    "ordinary",
    "viewed-exact",
    "viewed-camera",
    "corpus/parents",
    "independent/plan",
    "independent/inputs",
    "independent/parent/result",
)


def bind(p):
    return reference(p) | {"path": str(p.relative_to(ROOT))}


def copy_image(item):
    src = checked(item["image"])
    saved = ASSETS / src.name
    shutil.copyfile(src, saved)
    with Image.open(saved) as im:
        for t in item.get("panels", []):
            x, y, w, h = t["png_xywh"]
            assert w == h == 160 and x + w <= im.width and y + h <= im.height
    dest = bind(saved)
    assert dest["sha256"] == item["image"]["sha256"]
    return item | {"image": dest}


def population(plan_bind):
    rows = read_json(checked(plan_bind))["sources"]
    score = set()
    for r in rows:
        f = r["source"]
        assert f["split"] == "val"
        identifiers = {f["id"], f["cache_sha256"]}
        assert score.isdisjoint(identifiers)
        score.update(identifiers)
        checked({"path": f["cache"], "sha256": f["cache_sha256"]})
    return score


def bindings(receipt, source, added=None):
    origin = read_json(checked(source))
    inputs = read_json(checked(origin["inputs"]))
    assert source == receipt["source"] and receipt["plan"] == inputs["plan"]
    weights = origin["weights"]
    for ck in weights.values():
        checked(ck)
    for plan, saved, scored in zip(
        inputs["observations"], origin["records"], receipt["rows"], strict=True
    ):
        assert plan["id"] == scored["id"] == saved["id"]
        for x, y, z in zip(plan["streams"], saved["streams"], scored["draws"], strict=True):
            assert x["data"] == y["data"] == z["input"] and y["outputs"] == z["outputs"]
            checked(y["data"])
            for k in ("local50k", "v120") if added is None else ("local50k", "v120", added):
                checked(y["outputs"][k])
    return weights


def at_budget(payload, value):
    panels = earlier.panel_rows(payload["rows"])
    status = payload["summary"]["modes"]
    base = BASE
    modes = ("curved-pool", "affine-pool", status["region_refit"][0], status["region_pool"][0])
    out = {}
    for k in modes:
        raw = metric.score(panels["all"], (k, 1))["means"][metric.GAP]
        dose = min(1.0, value / raw)
        out[k] = {
            "dose": dose,
            "gap": raw * dose,
            "versus_parent": metric.paired(panels["varying"], (k, dose), base),
        }
    return out


def main():
    refs = {k: reference(OUT / f"{k}.json") for k in NAMES}
    payload = {k: read_json(checked(v)) for k, v in refs.items()}
    for doc in payload.values():
        for k in ("driver", "operator"):
            if k in doc:
                checked(doc[k])
    calib, held, transfer = [
        payload[f"evaluated-{k}"] for k in ("calibration", "independent", "corpus")
    ]
    assert held["calibration"] == transfer["calibration"] == refs["evaluated-calibration"]
    assert held["plan"] == transfer["plan"] == refs["independent/plan"]
    assert payload["corpus/parents"]["previous"] == refs["independent/parent/result"]
    fixed = payload["viewed-camera"]["report"]
    assert fixed["corpus"] == refs["corpus/parents"]
    for key in ("exact", "camera"):
        assert payload[f"viewed-{key}"]["numerical"] == refs["evaluated-independent"]
    fresh = population(held["plan"])
    assert len(fresh) == 64 and fresh.isdisjoint(population(calib["plan"]))
    plan = payload["independent/plan"]
    for v in plan["excluded_spatial_panels"]:
        assert fresh.isdisjoint(population(v))
    assert fresh.isdisjoint(population(plan["additional_exclusion"]))
    a = bindings(calib, calib["source"])
    assert a == bindings(held, refs["independent/parent/result"])
    weights = bindings(transfer, refs["corpus/parents"], added="corpus100k")
    assert a == {x: weights[x] for x in a}
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    camera = fixed["rows"]
    exact = payload["viewed-exact"]["report"]["rows"]
    assert len(exact) == 2 and len(camera) == 8
    for r in exact:
        for k in ("all", "triplet"):
            r[k] = copy_image(r[k])
    count = 0
    for row in camera:
        checked(row["local50k"])
        checked(row["corpus100k"])
        checked(row["input"])
        for item in row["native"]:
            labels = {k["label"] for k in item["panels"]}
            assert "ISO100 AHD reference" in labels
            if row["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"}.issubset(labels)
            count += 1
        row["native"] = [copy_image(item) for item in row["native"]]
    assert count == 12
    plot = copy_image({"image": payload["diagnostics"]["plot"]})["image"]
    manifest = ASSETS / "manifest.json"
    write_json(manifest, {"exact": exact, "camera": camera, "tradeoff": plot, "weights": weights})
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            **{
                k: v["summary"]
                for k, v in (("calibration", calib), ("holdout", held), ("corpus100k", transfer))
            },
            "shape_audit": payload["audit"]["layouts"],
            "detection": payload["diagnostics"]["support"],
            "ordinary": payload["ordinary"]["changes"],
            "at_measured_gap_budget": at_budget(held, 0.15),
            "camera_difference_DN16": {r["id"]: r["difference_DN16"] for r in camera},
        },
    )
    docs = {f"receipts/{k}.json": v for k, v in refs.items()}
    docs.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    for p in (
        "adaptive-junction-phase-v1/adaptive_phase_field.py",
        "adaptive-junction-phase-v1/capture_adaptive.py",
        "adaptive-junction-phase-v1/evaluate_adaptive.py",
        "adaptive-junction-phase-v1/view_adaptive.py",
        "adaptive-junction-phase-v1/view_camera_references.py",
        "spatial-junction-phase-v1/junction_phase_field.py",
        "spatial-junction-phase-v1/capture_warped.py",
        "spatial-junction-phase-v1/pool_probe.py",
        "spatial-junction-phase-v1/audit_spatial.py",
        "spatial-junction-phase-v1/ordinary_phase.py",
        "local-junction-support-v1/review_junction.py",
        "local-junction-support-v1/replay_junction.py",
    ):
        docs[f"reused/{p}"] = reference(HERE.parent / p)
    for f in (
        "src/demosaic/_mesh_junction.py",
        "src/demosaic/mesh_carrier_fit.py",
        "configs/gfx-qualitative-20231231.json",
        "configs/gfx-green-mesh-20231231.json",
    ):
        docs[f"repo/{f}"] = reference(ROOT / f)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as pack:
        for key, v in docs.items():
            pack.add(checked(v), arcname=key, recursive=False)
    with tarfile.open(archive) as pack:
        assert set(pack.getnames()) == docs.keys()
        for key, v in docs.items():
            with pack.extractfile(key) as src:
                assert file_digest(src, "sha256").hexdigest() == v["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "archive": bind(archive),
            "summary": bind(summary),
            "native": bind(manifest),
            "members": docs,
            "scope": "Connected support for weak junctions on frozen checkpoints",
        },
    )
    print(bind(archive), flush=True)


if __name__ == "__main__":
    main()
