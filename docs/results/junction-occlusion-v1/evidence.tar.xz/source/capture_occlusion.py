"""Capture disjoint junctions with gap placement displaced from the crop center."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("adaptive-junction-phase-v1")))
import capture_adaptive as adaptive

prior = adaptive.prior
seed = 202611200812
excluded = adaptive.OUT / "independent" / "plan.json"


def choose(kind, root):
    plan = adaptive.choose(kind, root)
    before = reference(excluded)
    protected = {
        key
        for r in read_json(checked(before))["sources"]
        for key in (r["source"]["id"], r["source"]["cache_sha256"])
    }
    for row in plan["sources"]:
        i = row["index"]
        row["id"] = f"occlusion-{i:02d}"
        g = row["geometry"]
        rng = np.random.default_rng(scene_seed(seed, i, "junction-displaced-support"))
        # Displace the support independent of capture phase, content and geometry type.
        g["gap_center"] = rng.uniform(20, 43, 2) * rng.choice([-1, 1], 2)
        g["gap_center"] = g["gap_center"].tolist()
        assert {row["source"]["id"], row["source"]["cache_sha256"]}.isdisjoint(protected)
    return plan | {
        "driver": reference(__file__),
        "additional_exclusion": before,
        "capture": reference(adaptive.__file__),
        "scope": "Disjoint optical holdout with displaced gaps and contrast dips",
    }


if __name__ == "__main__":
    engine = prior.ENGINE.prior
    with (
        patch.object(engine, "EXCLUSIONS", (*engine.EXCLUSIONS, excluded)),
        patch.object(prior, "__file__", __file__),
        patch.object(prior, "OUT", OUT),
        patch.object(prior, "choose", choose),
        patch.object(adaptive, "SEED", seed),
        patch.dict(prior.SEED, {"independent": seed}),
    ):
        prior.main("independent")
