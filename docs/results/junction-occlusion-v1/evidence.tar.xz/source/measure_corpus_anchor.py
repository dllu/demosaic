"""Evaluate the existing locked policy on identical mosaics with Corpus 100k."""

from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_occlusion import OUT, collect, summarize, metric
from junction_occlusion import __file__ as operator


if __name__ == "__main__":
    source = reference(OUT / "corpus/parents.json")
    calibration = reference(OUT / "evaluated-calibration.json")
    policy = read_json(checked(calibration))["policy"]
    rows, plan, seconds = collect(source, key="corpus100k")
    summary = summarize(rows, policy)
    for name, score in summary["panels"]["varying"].items():
        print(
            name,
            [score["means"][k] for k in (metric.RESPONSE, metric.JUNCTION)],
            summary["panels"]["all"][name]["means"][metric.GAP],
            flush=True,
        )
    for name, score in summary["equal_gap"].items():
        print(name, score["versus_pool"][metric.RESPONSE], flush=True)
    write_json(
        OUT / "evaluated-corpus.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(operator),
            "source": source,
            "calibration": calibration,
            "policy": policy,
            "summary": summary,
            "plan": plan,
            "seconds": seconds,
            "rows": rows,
        },
    )
