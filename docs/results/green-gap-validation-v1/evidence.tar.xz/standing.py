"""Replay the finite-support phase diagnostic on the frozen standing GFX crops."""
import argparse
import math
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from demosaic.precision import ieee_fp32
from demosaic.reporting import display_crop
from green_phase_spectrum import green_pair
from resolve import METHODS, assess, regressions

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent/"paired-luminance-detail-v1"
sys.path.insert(0,str(PRIOR))
from render import native_png

LABELS = {
    "wide":"Wide RAW fit","local":"Local RAW fit","exterior":"Exterior phase","rotated":"Rotated phase"
}


def frequency_proposals(arrays, x, y):
    """Find two principal-band directions supported in two external tiles each."""
    centers = ((x-128,y+64),(x+256,y+64),(x+64,y-128),(x+64,y+256))
    spectra = []
    for left,top in centers:
        assert left >= 0 and top >= 0 and left%2 == top%2 == 0
        patch = np.s_[... ,top//2:(top+128)//2,left//2:(left+128)//2]
        packed,variance = (arrays[k][patch][0]for k in ("packed","variance"))
        assert packed.shape == (4,64,64)
        spectra.append(green_pair(packed,variance,arrays["colors"][0]))
    fx,fy = (spectra[0][k]for k in ("native_fx","native_fy"))
    radius = np.hypot(fx,fy)
    eligible = (fx>0) & (radius>=.035) & (radius<=.22)
    cross = np.stack([s["noise_units_signed_cross"]for s in spectra])
    coherent = np.stack([s["signed_coherence"]for s in spectra]) >= .65
    panel_support = (cross >= 4) & coherent
    eligible &= panel_support.sum(0) >= 2
    supported_strength = np.sort(np.where(coherent,cross,0),axis=0)[-2]
    proposed = []
    for row,col in np.argwhere(eligible)[np.argsort(supported_strength[eligible],kind="stable")[::-1]]:
        direction = (float(fx[row,col]),float(fy[row,col]))
        if proposed:
            a,b = prior = proposed[0]["frequency_xy"]
            c,d = direction
            if abs(a*d-b*c)/(math.hypot(*prior)*math.hypot(*direction)) < .35:
                continue
        proposed.append({"frequency_xy":direction,"per_tile_cross_over_noise":cross[:,row,col].tolist(),
                         "per_tile_support":panel_support[:,row,col].tolist()})
        if len(proposed) == 2:
            break
    return {"exterior_tiles_xywh":[[a,b,128,128]for a,b in centers],"proposals":proposed}


def earlier_cab_frequencies(region, box, bound):
    evidence = read_json(checked(bound))
    side = region["case"]["name"].split("-")[-1]
    case = next(r for r in evidence["executed_result"]["cases"] if r["name"] == side)
    assert case["context_xywh"] == box
    peaks = [p for p in case["peaks"] if "absolute_cross" in p["selected_by"]][:2]
    assert len(peaks) == 2 and all(p["signed_coherence"] > .9 for p in peaks)
    return {"source":bound,"proposals":[{"frequency_xy":p["native_frequency_xy"],
             "signed_coherence":p["signed_coherence"]}for p in peaks]}


@torch.inference_mode()
def run(known_cab):
    torch.set_num_threads(2)
    stamp = reference(ROOT/"scores.json")
    scores = read_json(checked(stamp))
    inference = read_json(checked(scores["predictions"]))
    earlier = read_json(PRIOR/"endpoint/complete.json")
    recipe = read_json(checked(earlier["standing_results"]))
    board_source = read_json(checked(recipe["display_parent_boards"]))
    stored = {r["id"]:r for r in recipe["rows"]}
    bound = reference("docs/results/green-phase-cross-spectrum-v1.json") if known_cab else None
    target = ROOT/("standing-known-cab" if known_cab else "standing-exterior")
    target.mkdir(exist_ok=True)
    output = []
    for region in board_source["boards"]:
        obs = region["observation"]
        if obs not in stored or (known_cab and not obs.startswith("mesh-")):
            continue
        row = stored[obs]
        arr = row["raw"]["arrays"]
        assert arr == region["input_arrays"]
        with np.load(checked(arr),allow_pickle=False) as f:
            arrays = {k:f[k]for k in ("packed","variance","colors","wb","matrix")}
        assert row["inputs"] == {k:fingerprint(v)for k,v in arrays.items()}
        parent = np.load(checked(row["parent"]),allow_pickle=False)
        roi = region["case"]["ROI_xywh"]
        x,y,w,h = roi
        assert w == h == 160
        left,top = (x-48)//2*2,(y-48)//2*2
        box = [left,top,256,256]
        discovery = earlier_cab_frequencies(region,box,bound) if known_cab else frequency_proposals(arrays,left,top)
        view = np.s_[...,top:top+256,left:left+256]
        packed_view = np.s_[...,top//2:top//2+128,left//2:left//2+128]
        packed,variance = (torch.from_numpy(arrays[k][packed_view].copy())for k in ("packed","variance"))
        colors,wb,matrix = (torch.from_numpy(arrays[k])for k in ("colors","wb","matrix"))
        baseline = torch.from_numpy(parent[view].copy())
        crop = (x-left,y-top,w,h)
        proposals = discovery["proposals"]
        delta = {name:torch.zeros_like(baseline)for name in METHODS}
        if len(proposals) == 2:
            with ieee_fp32():
                for signal,nuisance in (proposals,proposals[::-1]):
                    weak,strong = signal["frequency_xy"],nuisance["frequency_xy"]
                    fits = regressions(packed,variance,colors,baseline,weak,strong)
                    added = assess(fits,weak,variance,wb,matrix)
                    for name in METHODS:
                        delta[name].add_(added[name],alpha=scores["calibration"]["scale"][name])
        fields = {"baseline":baseline,**{k:baseline+v for k,v in delta.items()}}
        arrays_path = target/(region["id"]+".npz")
        with arrays_path.open("wb") as f:
            np.savez(f,**{k:v.numpy()for k,v in fields.items()})
        with Image.open(checked(region["image"])) as f:
            inherited = np.array(f.convert("RGB"))
        existing = {p["label"]:inherited[b:b+d,a:a+c]for p in region["panels"]
                    for a,b,c,d in (p["png_xywh"],)}
        panels = [(k,existing[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")if k in existing]
        changes = {}
        cx,cy,cw,ch = crop
        core = np.s_[...,cy:cy+ch,cx:cx+cw]
        value = display_crop(baseline,wb,matrix,crop,exposure=region["display_exposure"])
        residual_u8 = np.rint(value.clip(0,1)*255).astype(np.uint8)
        np.testing.assert_array_equal(residual_u8,existing["Parent 100k EMA"])
        for name in METHODS:
            value = display_crop(fields[name],wb,matrix,crop,exposure=region["display_exposure"])
            pixels = np.rint(value.clip(0,1)*255).astype(np.uint8)
            panels.append((LABELS[name],pixels))
            change = (fields[name]-baseline)[core].numpy().astype(float)
            changes[name] = {"camera_RGB_RMS_DN16":float(np.sqrt(np.mean(change**2))*65535),
                             "display_RGB_values_changed":int(np.count_nonzero(pixels!=residual_u8))}
        panels += [(k,existing[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in existing]
        board = native_png(target/(region["id"]+".png"),panels)
        output.append(board | {"id":region["id"],"observation":obs,"input_arrays":arr,
                               "inherited_board":region["image"],"baseline":row["parent"],"case":region["case"],
                               "fit_box_xywh":box,
                               "fit_scope":"Two eligible directions required; otherwise returns the matched parent.",
                               "discovery":discovery,"prediction_arrays":reference(arrays_path),
                               "display_exposure":region["display_exposure"],"noise":region["noise"],
                               "reference_role":region["reference_role"],"change":changes})
        print(region["id"],[p["frequency_xy"] for p in proposals],changes["exterior"],flush=True)
    assert len(output) == (4 if known_cab else 8)
    write_json(target/"receipt.json",{"score":stamp,"driver":reference(__file__),"resolver":inference["driver"],
                                     "upstream":earlier["standing_results"],"checkpoint":inference["base"],
                                     "scales":scores["calibration"]["scale"],
                                      "frequency_scope": (
                                         "The two pre-existing high-coherence cab RAW peaks in the 256 native query; geometry selection reuses pixels in the fitted query."
                                         if known_cab else "Two nonparallel positive green cross-spectrum peaks from four disjoint 128 native tiles strictly outside the 256 native fit."
                                     ),
                                     "scope":"Both candidate directions are fitted jointly and each is tested for delivery with the other as nuisance. Qualitative references never enter frequency selection, fitting, or calculation of changes.",
                                     "rows":output})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--known-cab", action="store_true")
    run(parser.parse_args().known_cab)
