"""Freeze an exact finite-support alias panel on independent photographic sources."""
import hashlib
import math
from dataclasses import replace
from pathlib import Path
import random
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "weak-edge-distill-v1"))
from edge_data import ARGS, decode, pair_targets, row_for

SEED = 520813575407
ROLES = ["gap", "absent", "full", "flat"]
PROFILE = {"shot": .00128, "read": 6.5536e-6, "exposure": .33}
FIT = 12
COUNT = 32


def geometry(index):
    rng = random.Random(scene_seed(SEED, index, "carrier-and-support"))
    major, minor = rng.uniform(.174, .221), rng.uniform(.034, .095) * rng.choice((-1, 1))
    main, alias = (major, minor), (major - .5, minor)
    if index // 4 % 2:
        main, alias = main[::-1], alias[::-1]
    return {
        "strong_frequency_xy": main, "weak_frequency_xy": alias,
        "strong_phase": rng.uniform(-math.pi, math.pi),
        "weak_phase": rng.uniform(-math.pi, math.pi),
        "strong_amplitude": .012, "weak_amplitude": (.0035, .006)[index // 4 % 2],
        "gap_angle": rng.uniform(-math.pi, math.pi),
        "gap_shift": rng.uniform(-14, 14), "gap_radius": (12, 17, 22)[index % 3],
        "shape": ("stripe", "ellipse")[(index // 2) % 2],
        "background": ("natural", "same-edge")[((index // 4) ^ index) % 2],
    }


def fields(placement):
    y, x = torch.meshgrid(torch.arange(256, dtype=torch.float32), torch.arange(256, dtype=torch.float32), indexing="ij")
    taper = ((112 - (x-127.5).abs())/24).clamp(0, 1) * ((112 - (y-127.5).abs())/24).clamp(0, 1)
    theta = placement["gap_angle"]
    u = (x-127.5) * math.cos(theta) + (y-127.5) * math.sin(theta)
    v = -(x-127.5) * math.sin(theta) + (y-127.5) * math.cos(theta)
    distance = (u - placement["gap_shift"]).abs()
    radius = placement["gap_radius"]
    if placement["shape"] == "ellipse":
        distance = torch.hypot(distance, v * radius / 44)
    envelope = ((distance-radius)/6).clamp(0, 1)
    return x, y, taper, envelope


def freeze():
    origin = reference(ROOT.parent / "weak-edge-distill-v1/evaluation.json")
    old = read_json(checked(origin))
    replay = read_json(ROOT.parent / "paired-repeat-stability-v2/evaluation-plan.json")
    cohort = read_json(checked(old["cohort"]))
    assert cohort["training_overlap"] == []
    previous = {r["source"]["id"] for r in [*old["heldout_rows"], *replay["rows"]]}
    candidates = [
        s for s in cohort["source_metadata"] if s["split"] == "val" and s["bin_factor"] == 4
        and min(s["shape"][:2]) >= 512 and np.prod(s["shape"][:2]) <= 4_000_000
        and s["id"] not in previous
    ]
    ranked = sorted(candidates, key=lambda s: hashlib.sha256(f"{SEED}/{s['id']}".encode()).hexdigest())
    chosen = [row_for(s, i, SEED) | {"placement": geometry(i)} for i, s in enumerate(ranked[:COUNT])]
    assert len({r["source"]["id"] for r in chosen}) == COUNT
    green = read_json(ROOT.parent / "quincunx-green-v1/plan.json")
    strength = read_json(checked(green["parent_panel"]))
    composition = read_json(checked(strength["frozen_composition"]))
    write_json(ROOT / "plan.json", {
        "driver": reference(__file__), "source_cohort": old["cohort"], "exclusion": origin,
        "base": composition["models"]["Corpus 100k"], "sources": chosen, "roles": ROLES,
        "profile": PROFILE, "seed": SEED, "repeat_count": 2, "fit_indices": list(range(FIT)),
        "test_indices": list(range(FIT, COUNT)), "score_ROI_xywh": [64,64,128,128],
        "display_ROI_xywh": [48,48,160,160], "display_exposure": 2,
        "scope": "Independent physical sensor draws for weak-with-gap, strong-only, weak unbroken, and flat roles. All nonflat roles share the same strong aliased carrier and photograph. Exact carrier frequencies are supplied to the diagnostic resolver. Phase, amplitude, gap shape and positions are withheld from the resolver.",
    })


def prepare():
    torch.set_num_threads(2)
    frozen = reference(ROOT / "plan.json")
    plan = read_json(checked(frozen))
    checked(plan["driver"])
    folder = ROOT / "observations"
    folder.mkdir(exist_ok=True)
    records = []
    for row in plan["sources"]:
        placement = row["placement"]
        x, y, taper, envelope = fields(placement)
        _, base, flat = pair_targets(decode(row["source"], row["box"]), row["geometry"], placement["background"])

        def wave(role):
            fx, fy = placement[f"{role}_frequency_xy"]
            return (2*math.pi*(fx*x + fy*y) + placement[f"{role}_phase"]).cos() * placement[f"{role}_amplitude"] * taper

        carrier = wave("weak")
        shared = base + wave("strong")
        targets = (shared + carrier*envelope, shared, shared + carrier, flat)
        assert all(0 < clean.min() < clean.max() < 1 or 0 < clean.min() == clean.max() < 1 for clean in targets)
        captured = {name: [] for name in (*ARGS, "target")}
        seeds = [[scene_seed(SEED, row["index"], f"capture/{r}/{role}") for role in ROLES] for r in range(2)]
        assert len(set(sum(seeds, []))) == 8
        for redraw in seeds:
            camera = replace(sample_scene_recipe(SEED), **(row["camera"] | PROFILE))
            observations = [observe_scene(clean, replace(camera, noise_seed=s)) for clean,s in zip(targets, redraw, strict=True)]
            for name in captured:
                captured[name].append(torch.stack([getattr(obs, name) for obs in observations]))
        arrays = {name: torch.stack(draws).numpy() for name, draws in captured.items()}
        np.testing.assert_array_equal(arrays["target"][0], arrays["target"][1])
        arrays["region"] = envelope.numpy()
        outfile = folder / f'{row["index"]:03d}.npz'
        if not outfile.exists():
            with outfile.open("xb") as f:
                np.savez(f, **arrays)
        with np.load(outfile, allow_pickle=False) as f:
            expected = {name: fingerprint(v) for name, v in arrays.items()}
            assert expected == {name: fingerprint(f[name]) for name in arrays}
        records.append({"index": row["index"], "input": reference(outfile), "seeds": seeds, "fingerprints": expected})
        if len(records) % 4 == 0:
            print(f"Prepared {len(records)}/{COUNT}", flush=True)
    write_json(ROOT / "inputs.json", {"plan": frozen, "records": records})


if __name__ == "__main__":
    freeze()
    prepare()
