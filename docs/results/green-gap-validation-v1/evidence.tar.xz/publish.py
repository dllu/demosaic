"""Publish the source-bound outcomes and actually viewed native crops."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path("docs/results/green-gap-validation-v1")
IMAGES = Path("docs/images/green-gap-validation-v1")


def retain(binding, relative, panes):
    image = checked(binding)
    dst = IMAGES/relative/image.name
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(image,dst)
    assert reference(dst)["sha256"] == binding["sha256"]
    with Image.open(dst) as f:
        for x,y,w,h in panes:
            assert w == h == 160 and x + w <= f.width and y + h <= f.height
        f.verify()
    return {"path":str(dst),"sha256":binding["sha256"]}


def main():
    RESULTS.mkdir(exist_ok=True)
    IMAGES.mkdir(exist_ok=True)
    metrics = reference(ROOT/"scores.json")
    scores = read_json(checked(metrics))
    independently = reference(ROOT/"independent-score-audit.json")
    audit = read_json(checked(independently))
    assert audit["scores"] == metrics and audit["checks"] == 384
    observed = read_json(ROOT/"native/manifest.json")
    assert observed["scores"] == metrics
    keep = {"012-gap-comparison.png","012-gap-triplet.png","012-flat-comparison.png",
            "014-gap-comparison.png","014-gap-triplet.png","014-full-comparison.png"}
    notes = {
        "012-gap":"The strong diagonal persists. The restored weak carrier is subtler than the exact target in the upper-right.",
        "014-gap":"Weak ridges are partly recovered around the ellipse and are strongest beyond the soft gap. Background features and the pronounced shared step remain.",
        "012-flat":"The exact flat center looks smooth in all displayed cells. Its measured added variation differs.",
        "014-full":"The exterior fit adds a faint periodic family. The exact unbroken pattern is clearer.",
    }
    photo = []
    for row in observed["images"]:
        name = Path(row["path"]["path"]).name
        if name not in keep:
            continue
        panes = [[160*i,0,160,160] for i,_ in enumerate(row["columns"])]
        row["path"] = retain(row["path"],Path("exact"),panes)
        scene = name.split("-")
        photo.append(row | {"png_rectangles":panes,"viewing":notes["-".join(scene[:2])]})
    assert len(photo) == len(keep)
    standing = {}
    camera_notes = {
        "main-overcast-sky-main-overcast-sky":"The sky cells are identical to the 100k parent.",
        "main-building-detail-main-building-detail":"The building outline and thicker cables remain. Low-frequency diagonal candidates modify some tones and do not visibly restore the finest cables.",
        "main-foliage-main-foliage":"Larger foliage edges remain clear and fine foliage stays soft.",
        "main-chain-link-fence-main-chain-link-fence":"The two coarse crossing directions remain visible. The fitted versions stay close to the parent.",
    }
    for mode in ("standing-exterior","standing-known-cab"):
        stamp = reference(ROOT/mode/"receipt.json")
        camera = read_json(checked(stamp))
        assert camera["score"] == metrics and camera["checkpoint"] == observed["ema"]
        for row in camera["rows"]:
            image = retain(row["image"],Path(mode),[p["png_xywh"]for p in row["panels"]])
            row["image"] = image
            if mode == "standing-known-cab":
                note = ("Both directions form a more visible lattice. Spacing is very regular in some zones and crossings remain broken or soft."
                        if row["id"].endswith("right") else
                        "The interference pattern increases on both sides of the vertical post. It remains uneven and overly regular in places.")
            else:
                note = camera_notes.get(row["id"], "The cab remains close to the parent. Thin diagonals stay soft and the fine intersections remain incomplete.")
            row["viewing"] = note
        standing[mode] = camera | {"original_receipt":stamp}
    write_json(IMAGES/"manifest.json",{
        "checkpoint":observed["ema"],"transform":observed["transform"],"exact":photo,
        "standing":standing,"actual_native_viewing_complete":True})
    evidence = RESULTS/"evidence.tar.xz"
    with tarfile.open(evidence,"x:xz") as f:
        for file in (
            "prepare.py","resolve.py","score.py","audit.py","standing.py","standing-initial.py","publish.py",
            "plan.json","inputs.json","predictions.json","scores.json","independent-score-audit.json",
            "prepare.log","resolve.log","resolve-v2.log","resolve-v3.log","resolve-v4.log","score.log",
            "native/manifest.json","standing/receipt.json","standing-exterior/receipt.json",
            "standing-known-cab/receipt.json","standing-exterior.log","standing-known-cab.log",
        ):
            f.add(ROOT/file,arcname=file)
    write_json(RESULTS/"publication.json",{
        "experiment":"green-gap-validation-v1","training_performed":False,
        "fixed_parent_EMA":observed["ema"],"numerical_evaluation_complete":True,
        "actual_native_viewing_complete":True,"checks":audit,
        "calibration":scores["calibration"],"nominal":scores["test_summary_nominal"],
        "matched":scores["test_summary_matched"],"matched_by_shape":scores["by_shape"],
        "images":reference(IMAGES/"manifest.json"),"archive":reference(evidence),
        "canonical_panel_scope":"Planted aliases plus both standing GFX families. No fixed427 or camera PSNR collection for this scoped inference component."
    })


if __name__ == "__main__":
    main()
