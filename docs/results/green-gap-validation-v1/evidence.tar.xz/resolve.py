"""Resolve two green alias classes with local amplitude and optional exterior phase."""
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "scene-local-contrast-2400-v1"))
from evaluate import ARGS, setup_models

METHODS = ("wide", "local", "exterior", "rotated")
GRID = 16
SIZE = 256


def solve(design, value, variance, weights):
    """Use fixed spatial weighting and propagate local variance through the two phase fits."""
    d = design.shape[-1]
    products = (design[:, :, None] * design[:, None, :]).reshape(-1, d*d)
    gram = (weights @ products).reshape(-1, d, d)
    gram_inv = torch.linalg.inv(gram)
    rhs_values = (value.T[:, :, None] * design[:, None, :]).reshape(-1, value.shape[0]*d)
    rhs = (weights @ rhs_values).reshape(-1, value.shape[0], d)
    beta = torch.einsum("gij,gbj->bgi", gram_inv, rhs)
    phase_rows = gram_inv[:, -2:, :]
    second = (weights.square() @ products).reshape(-1, d, d)
    unit_cov = phase_rows @ second @ phase_rows.transpose(-1, -2)
    local_variance = (weights @ variance.T / weights.sum(-1, keepdim=True)).T
    covariance = local_variance[..., None, None] * unit_cov
    return beta[..., -2:], covariance


def unit(value):
    size = torch.linalg.vector_norm(value, dim=-1, keepdim=True)
    return value / size.clamp_min(1e-12), size.squeeze(-1)


def regressions(packed, variance, colors, parent, weak, strong):
    device = packed.device
    assert packed.shape[1:] == (4,128,128) and torch.equal(colors, colors[:1].expand_as(colors))
    green = torch.where(colors[0] == 1)[0]
    row, col = torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    yy = (2*row + (green[:,None,None]//2)).flatten()
    xx = (2*col + (green[:,None,None]%2)).flatten()
    parity = ((row+col)%2).expand(2,-1,-1).flatten()
    sign = torch.ones((2,128,128),device=device)
    sign[1].neg_()
    sign = sign.flatten()
    values = torch.cat((packed[:,green].flatten(1),parent[:,1,yy,xx]))
    nvars = variance[:,green].flatten(1)
    nvars = torch.cat((nvars,nvars))
    y, x = (yy-127.5)/128, (xx-127.5)/128
    step = SIZE // GRID
    cy,cx = torch.meshgrid(torch.arange(GRID,device=device)*step+(step-1)/2,
                           torch.arange(GRID,device=device)*step+(step-1)/2,indexing="ij")
    sqdist = (xx[None]-cx.clamp(32,223).reshape(-1,1)).square() + (yy[None]-cy.clamp(32,223).reshape(-1,1)).square()
    # Centers close to the query frame are allowed to use only the actual inner samples.
    active = (x.abs() <= .70) & (y.abs() <= .70)
    weights = {
        "wide": (-sqdist/(2*24**2)).exp()*active,
        "local": (-sqdist/(2*9**2)).exp()*active*(sqdist < 30**2),
        "exterior": (-sqdist/(2*42**2)).exp()*active*(sqdist >= 30**2),
    }

    def harmonics(frequency):
        wave = (xx*frequency[0]+yy*frequency[1])*(2*torch.pi)
        return wave.cos(), wave.sin()

    wc, ws = harmonics(weak)
    sc, ss = harmonics(strong)
    a = torch.stack((torch.ones_like(x), x, y, sign, sign*x, sign*y,
                     sc, ss, sc*x, sc*y, ss*x, ss*y, wc, ws),dim=-1)
    fits = {name: [solve(a[parity==f], values[:,parity==f], nvars[:,parity==f], w[:,parity==f])
                   for f in (0,1)] for name,w in weights.items()}
    return fits


def amplitude(method,fits, batch):
    base = "local" if method in ("exterior","rotated") else method
    (a, va),(b,vb) = fits[base]
    a, parent_a = a.split(batch)
    b, parent_b = b.split(batch)
    va, vb = va[:batch], vb[:batch]
    if method in ("exterior","rotated"):
        ext_a, ext_b = (v[0][:batch] for v in fits["exterior"])
        if method == "rotated":
            ext_a, ext_b = (torch.stack((-v[...,1],v[...,0]),dim=-1) for v in (ext_a,ext_b))
        da,_ = unit(ext_a)
        db,_ = unit(ext_b)
        direction,_ = unit(ext_a+ext_b)
        sa = (a*da).sum(-1)
        sb = (b*db).sum(-1)
        na = torch.einsum("bgi,bgij,bgj->bg",da,va,da)
        nb = torch.einsum("bgi,bgij,bgj->bg",db,vb,db)
        coherence = (da*db).sum(-1) > 0
        evidence = (sa.clamp_min(0)*sb.clamp_min(0))*coherence
        size = ((a+b)*.5*direction).sum(-1).clamp_min(0)
    else:
        direction,size = unit((a+b)*.5)
        evidence = (a*b).sum(-1)
        na = va.diagonal(dim1=-1,dim2=-2).sum(-1)
        nb = vb.diagonal(dim1=-1,dim2=-2).sum(-1)
    shrink = (1-(na*nb).sqrt()/evidence.clamp_min(1e-15)).clamp(0,1)
    parent_size = (((parent_a+parent_b)*.5*direction).sum(-1)).clamp_min(0)
    return (size*shrink-parent_size).clamp_min(0)[...,None]*direction


def lift(projection, frequency):
    device = projection.device
    steps = torch.arange(SIZE, device=device)
    phase = (steps[None,:]*frequency[0]+steps[:,None]*frequency[1])*(2*torch.pi)
    plane = projection.reshape(-1, GRID, GRID,2).permute(0,3,1,2)
    plane = F.interpolate(plane, (SIZE,SIZE), mode="bilinear", align_corners=False)
    # The outer taper avoids delivering unsupported detail at the frame boundary.
    edge = ((112 - (steps-127.5).abs())/24).clamp(0,1)
    return (plane[:,0]*phase.cos()+plane[:,1]*phase.sin()) * edge[None,:] * edge[:,None]


def assess(fits, frequency, variance, wb, matrix):
    batch = variance.shape[0]
    gains = torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
    gains = gains / gains[:,1:2]
    result = {}
    for name in METHODS:
        inc = lift(amplitude(name,fits,batch),frequency)
        result[name] = inc[:,None]*gains[:,:,None,None]
    return result


def preflight(device):
    from demosaic.cfa import mosaic, color_indices
    for index,pattern in enumerate(("RGGB","BGGR","GRBG","GBRG")):
        colors = color_indices(pattern,device=device)[None]
        m = torch.arange(256,device=device)
        f0, f1 = (.201,.063),(-.299,.063)
        if index % 2:
            f0,f1 = f0[::-1], f1[::-1]
        def wave(f, shift):
            arg = 2*torch.pi*(m[None,:]*f[0]+m[:,None]*f[1])+shift
            return torch.cos(arg)
        rgb = torch.full((1,3,256,256),.3,device=device)
        parent = rgb + .012*wave(f0, -.57)
        truth = .006*wave(f1, 1.17)
        value = mosaic(parent+truth,colors)
        fits = regressions(value,torch.full_like(value,1e-12),colors,parent,f1,f0)
        weak = torch.tensor([.006*np.cos(1.17),-.006*np.sin(1.17)],device=device,dtype=torch.float32)
        interior = slice(64,192)
        for name in METHODS:
            output = lift(amplitude(name,fits,1),f1)
            expected = torch.zeros_like(truth) if name == "rotated" else truth
            torch.testing.assert_close(output[0,interior,interior],expected[interior,interior],rtol=0,atol=2e-6)
        for name in ("local","wide","exterior"):
            for coefficients,_ in fits[name]:
                torch.testing.assert_close(coefficients[0],weak.expand_as(coefficients[0]),rtol=0,atol=2e-6)
                assert coefficients[1].abs().max() < 2e-6
    print("Preflight recovered exact aliased weak carrier for four CFA origins and both orientations",flush=True)


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1., 6*2**30/torch.cuda.get_device_properties(0).total_memory))
    device = torch.device("cuda")
    frozen = reference(ROOT/"inputs.json")
    inputs = read_json(checked(frozen))
    plan = read_json(checked(inputs["plan"]))
    model = None
    out = ROOT/"outputs"
    out.mkdir(exist_ok=True)
    recorded = []
    started = time.monotonic()
    with ieee_fp32():
        preflight(device)
        for case,row in zip(inputs["records"],plan["sources"],strict=True):
            index = case["index"]
            assert index == row["index"]
            output = out/f"{index:03d}.npz"
            if not output.exists():
                if model is None:
                    model = setup_models({"models":{"Corpus 100k":plan["base"]}})["Corpus 100k"]
                    model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
                with np.load(checked(case["input"]),allow_pickle=False) as archive:
                    arrays = {k: archive[k] for k in (*ARGS,"target","region")}
                assert {k:fingerprint(v)for k,v in arrays.items()} == case["fingerprints"]
                args = [torch.from_numpy(arrays[k].reshape((-1,*arrays[k].shape[2:]))).to(device) for k in ARGS]
                packed,variance,colors,wb,matrix = args
                args[:2] = [v.contiguous(memory_format=torch.channels_last)for v in args[:2]]
                baseline = model(*args)
                placement = row["placement"]
                weak,strong = (placement[f"{k}_frequency_xy"]for k in ("weak","strong"))
                fits = regressions(packed,variance,colors,baseline,weak,strong)
                delta = assess(fits,weak,variance,wb,matrix)
                values = {"baseline":baseline.cpu().numpy().reshape(2,4,3,256,256)}
                values.update({k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in delta.items()})
                tmp = output.with_suffix(".tmp")
                with tmp.open("wb") as f:
                    np.savez(f,**values)
                tmp.rename(output)
            recorded.append({"index":index,"predictions":reference(output)})
            print(f"{len(recorded)}/{len(inputs['records'])} {time.monotonic()-started:.2f}s",flush=True)
    write_json(ROOT/"predictions.json", {"input":frozen,"driver":reference(__file__),"base":plan["base"],
                                        "seconds":time.monotonic()-started,"cases":recorded})


if __name__ == "__main__":
    run()
