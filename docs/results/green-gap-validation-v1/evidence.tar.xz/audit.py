"""Independently verify delivered match points and held-out source identities."""
import json
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
SCENE = ROOT.parent/"scene-full-epoch-v1"


def main():
    scored = reference(ROOT/"scores.json")
    report = read_json(checked(scored))
    predicted = read_json(checked(report["predictions"]))
    captured = read_json(checked(predicted["input"]))
    plan = read_json(checked(captured["plan"]))
    scene = read_json(SCENE/"plan.json")
    train = {json.loads(line)["id"] for line in checked(scene["train_manifest"]).open()}
    holdout = {r["source"]["id"] for r in plan["sources"]}
    assert len(train) == 90692 and len(holdout) == 32 and not train.intersection(holdout)
    max_error = 0
    checks = 0
    weights = np.array([.2126,.7152,.0722])

    def verify(comp, ref):
        nonlocal max_error,checks
        error = abs(comp-ref)
        assert error < 2e-10
        max_error = max(max_error,error)
        checks += 1

    for sample,out in zip(captured["records"],predicted["cases"],strict=True):
        i = sample["index"]
        assert out["index"] == i
        cohort = report["calibration_rows"] if i < 12 else report["test_rows_matched"]
        retained = next(r["methods"] for r in cohort if r["index"] == i)
        with np.load(checked(sample["input"]),allow_pickle=False) as capture, np.load(checked(out["predictions"]),allow_pickle=False) as preds:
            matrix = capture["matrix"].astype(np.float64)
            coefficients = (weights @ matrix) * capture["wb"]
            masks = capture["region"][64:192,64:192]
            actual = (capture["target"].astype(np.float64)*coefficients[...,None,None]).sum(2)
            assert np.array_equal(actual[0,0,64:192,64:192][masks==0],actual[0,1,64:192,64:192][masks==0])
            truth = (actual[0,2]-actual[0,1])[64:192,64:192]
            keep = masks==1
            denominator = (truth[keep]**2).sum()
            parent = (preds["baseline"].astype(np.float64)*coefficients[...,None,None]).sum(2)
            for name in ("wide","local","exterior","rotated"):
                scale = 1 if i < 12 else report["calibration"]["scale"][name]
                correction = (preds[name].astype(np.float64)*coefficients[...,None,None]).sum(2)*scale
                both = parent+correction
                recovered = (both[:,0]-both[:,1])[:,64:192,64:192]
                verify(100*np.sum(recovered[:,keep]*truth[keep])/2/denominator,retained[name]["intact_response_percentage"])
                for role,roi,label in ((0,(slice(64,192),slice(64,192),masks==0),"gap"),(3,(slice(80,176),slice(80,176),slice(None)),"flat")):
                    image = correction[:,role,roi[0],roi[1]]
                    region = [p[roi[2]].ravel() for p in image]
                    value = np.mean([np.linalg.norm(v)/np.sqrt(v.size) for v in region])*65535
                    verify(value,retained[name][label+"_added_DN16"])
    write_json(ROOT/"independent-score-audit.json",{
        "driver":reference(__file__),"scores":scored,"training_manifest":scene["train_manifest"],
        "sources":len(holdout),"train_overlap":0,"checks":checks,"maximum_absolute_error":max_error,
        "scope":"Independent dot-product reductions of intact projection, gap RMS, and flat RMS for four candidates, on each frozen source. Includes exact zero gap assertions in the camera-transformed target."})
    print(checks,max_error,flush=True)


if __name__ == "__main__":
    main()
