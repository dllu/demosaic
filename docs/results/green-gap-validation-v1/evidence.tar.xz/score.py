"""Score exact gap leakage and retained weak detail at a common false-addition budget."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
METHODS = ("wide", "local", "exterior")
ALL = (*METHODS, "rotated")
LUMA = np.array((.2126,.7152,.0722))
CORE = np.s_[...,64:192,64:192]
FLAT = np.s_[...,80:176,80:176]
TRIM = np.s_[...,48:208,48:208]


def arrays(record, prediction):
    with np.load(checked(record["input"]),allow_pickle=False) as f:
        data = {k:f[k] for k in f.files}
    with np.load(checked(prediction["predictions"]),allow_pickle=False) as f:
        output = {k:f[k] for k in f.files}
    return data,output


def luma(value, capture):
    bands = (linear_rgb(q,{k:capture[k][i]for k in ("matrix","wb")})for i,q in enumerate(value))
    return np.einsum("c,dbchw->dbhw", LUMA, np.stack(tuple(bands)))


def amplitude(plane, template, roi):
    return np.mean(np.sum(plane[:,roi]*template[roi],axis=-1)/np.sum(template[roi]**2))


def rms(x):
    return np.sqrt(np.mean(x*x,axis=-1)).mean()*65535


def score(source, capture, base, alter):
    roi = capture["region"][CORE]
    intact = roi == 1
    gap = roi == 0
    reference = luma(capture["target"],capture)
    full = reference[0,2][CORE]-reference[0,1][CORE]
    np.testing.assert_array_equal(reference[0,3][FLAT],np.full((96,96),reference[0,3,100,100]))
    assert intact.sum() > 256 and gap.sum() > 256
    value = base+alter
    gapped = (value[:,0]-value[:,1])[CORE]
    full_delta = (value[:,2]-value[:,1])[CORE]
    gapped_gt = reference[0,0][CORE]-reference[0,1][CORE]
    absent = (value[:,1]-reference[:,1])[CORE]
    actual = (value[:,0]-reference[:,0])[CORE]
    return {
        "gap_added_DN16": float(rms(alter[:,0][CORE][:,gap])),
        "flat_added_DN16": float(rms(alter[:,3][FLAT].reshape(2,-1))),
        "intact_response_percentage": float(100*amplitude(gapped,full,intact)),
        "unbroken_response_percentage": float(100*amplitude(full_delta,full,np.ones_like(intact))),
        "gap_false_response_percentage": float(100*abs(amplitude(gapped,full,gap))),
        "absent_false_response_percentage": float(100*abs(amplitude(absent,full,np.ones_like(gap)))),
        "intact_increment_RMS_DN16":float(rms((gapped-gapped_gt)[:,intact])),
        "gap_increment_RMS_DN16":float(rms(gapped[:,gap])),
        "gap_absolute_RMS_DN16":float(rms(actual[:,gap])),
        "flat_absolute_RMS_DN16":float(rms((value[:,3]-reference[:,3])[FLAT].reshape(2,-1))),
    }


def calibrate(rows):
    budget = {k:float(np.mean([r["methods"][k]["gap_added_DN16"]for r in rows]))for k in METHODS}
    goal = min(budget.values())
    assert goal > 0
    scale = {k:goal/x for k,x in budget.items()}
    scale["rotated"] = scale["exterior"]
    return {"mean_added_gap_DN16":budget,"matched_target_DN16":goal,"scale":scale}


def reduce(rows):
    seed = np.random.default_rng(598104)
    columns = rows[0]["methods"]["baseline"].keys()
    names = ("baseline",*ALL)
    chosen = seed.integers(len(rows),size=(10000,len(rows)))
    means = {}
    compared = {}
    for metric in columns:
        values = {k:np.array([r["methods"][k][metric]for r in rows])for k in names}
        means[metric] = {k:float(v.mean())for k,v in values.items()}
        compared[metric] = {}
        for new,old in (("exterior","wide"),("exterior","local"),("exterior","rotated"),("local","wide"),("exterior","baseline")):
            delta = values[new]-values[old]
            lo,hi = np.quantile(delta[chosen].mean(-1),(.025,.975))
            compared[metric][f"{new}_vs_{old}"] = [float(delta.mean()),float(lo),float(hi)]
    return {"means":means,"paired_difference_and_95pc_bootstrap":compared}


def main():
    stamp = reference(ROOT/"predictions.json")
    report = read_json(checked(stamp))
    frozen = read_json(checked(report["input"]))
    plan = read_json(checked(frozen["plan"]))
    fit,test = [],[]
    cached = []
    for source, inp, pred in zip(plan["sources"],frozen["records"],report["cases"],strict=True):
        index = source["index"]
        assert index == inp["index"] == pred["index"]
        capture, result = arrays(inp,pred)
        base = luma(result["baseline"],capture)
        corrections = {name:luma(result[name],capture)for name in ALL}
        corrections["baseline"] = np.zeros_like(base)
        methods = {k:score(source,capture,base,v)for k,v in corrections.items()}
        row = {"index":index,"id":source["source"]["id"],"placement":source["placement"],"methods":methods}
        if index in plan["fit_indices"]:
            fit.append(row)
        else:
            assert index in plan["test_indices"]
            test.append(row)
            cached.append((row,capture,base,corrections))
    fit_result = calibrate(fit)
    matched = [
        row | {"methods":{k:score(row,capture,base,v*fit_result["scale"].get(k,1))
                           for k,v in corrections.items()}}
        for row,capture,base,corrections in cached
    ]
    output = ROOT/"scores.json"
    write_json(output, {
        "driver":reference(__file__), "predictions":stamp, "calibration":fit_result,
        "calibration_rows":fit,"test_rows_nominal":test,"test_rows_matched":matched,
        "test_summary_nominal":reduce(test),"test_summary_matched":reduce(matched),
        "by_shape":{shape:reduce([r for r in matched if r["placement"]["shape"]==shape])
                    for shape in ("stripe","ellipse")},
        "scope":"Select output strength using mean parent-relative luma RMS only in the calibration gap cores. The truth envelope defines regions of scoring only. Model inputs have independent physical noise across roles and redraws. Scores average redraws within each source and give each source equal weight.",
    })
    print(output,flush=True)


def native():
    torch.set_num_threads(2)
    stamp = reference(ROOT/"scores.json")
    scores = read_json(checked(stamp))
    report = read_json(checked(scores["predictions"]))
    frozen = read_json(checked(report["input"]))
    plan = read_json(checked(frozen["plan"]))
    folder = ROOT/"native"
    folder.mkdir(exist_ok=True)
    images = []
    # First held-out source of each gap family, fixed independently of observed metrics.
    for shape in ("stripe","ellipse"):
        n = next(i for i in plan["test_indices"]if plan["sources"][i]["placement"]["shape"]==shape)
        source = plan["sources"][n]
        record, prediction = frozen["records"][n], report["cases"][n]
        capture, output = arrays(record,prediction)
        meta = {k:capture[k][0] for k in ("matrix","wb")}
        noisy = malvar(torch.from_numpy(capture["packed"][0]),torch.from_numpy(capture["colors"][0])).numpy()
        parent = output["baseline"][0]
        test = {name:parent+scores["calibration"]["scale"][name]*output[name][0]for name in METHODS}
        representations = {"noisy":noisy,"baseline":parent,**test,"exact":capture["target"][0]}
        rendered = {
            k:np.rint(display(v,meta,exposure=plan["display_exposure"])[TRIM].clip(0,1).transpose(0,2,3,1)*255).astype("uint8")
            for k,v in representations.items()
        }
        for role in [0,1,2,3]:
            for label,modes in (("triplet",("noisy","exterior","exact")),
                                ("comparison",("baseline","wide","local","exterior","exact"))):
                image = np.concatenate([rendered[k][role]for k in modes],axis=1)
                path = folder/f"{n:03d}-{plan['roles'][role]}-{label}.png"
                Image.fromarray(image).save(path,optimize=True)
                images.append({"path":reference(path),"index":n,"shape":shape,"columns":modes,
                               "role":plan["roles"][role],"repeat":0,"native_ROI_xywh":plan["display_ROI_xywh"],
                               "exposure":plan["display_exposure"],"profile":plan["profile"],
                               "prep":record["input"],"prediction":prediction["predictions"],
                               "source":source["source"],"source_box_xywh":source["box"],
                               "cfa":source["camera"]["pattern"]})
    write_json(folder/"manifest.json", {"scores":stamp,"ema":plan["base"],"transform":"shared WB/matrix then fixed 2x exposure and clipped sRGB8; native cells","images":images})


if __name__ == "__main__":
    main()
    native()
