"""Inspect the relaxed context-delta composition on exact and protected captures."""
from pathlib import Path

import numpy as np
import torch

from fit_delta import ROOT, MATCH, metrics, bandpass, luma, apply_delta
from review_continuation import KEYS, native_png, old_pixels, native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.io import read_raw
from demosaic.precision import ieee_fp32
from demosaic.reporting import display_crop
from demosaic.scene_inference import load_scene_checkpoint

SCENES=ROOT.with_name("scene-full-epoch-v1")/"endpoint-native-cuda"
LABEL="Aligned half-strength"
LOCAL="Local-only 50k EMA"
SPATIAL="Spatial 50k EMA"
SYNTH_LOCAL="Local 50k"
PANEL=Path("docs/images/scene-050000-native-v1/manifest.json")


def selection(result):
    natural=result["rows"]["natural"]
    wire=result["rows"]["wire"]
    a=min(natural,key=lambda row:row["scores"]["aligned-relaxed"]["fine_increment_RMS_DN16"]-
        row["scores"][SYNTH_LOCAL]["fine_increment_RMS_DN16"])
    b=min(wire,key=lambda row:row["scores"]["aligned-relaxed"]["weak_response_pp"]-
        row["scores"][SYNTH_LOCAL]["weak_response_pp"])
    return a,b


def exact_views(result,profile,folder):
    folder.mkdir()
    boards=[]
    for case in selection(result):
        with np.load(checked(case["input"]),allow_pickle=False) as src:
            args={k:src[k]for k in src.files}
        with np.load(checked(case["models"]),allow_pickle=False) as src:
            local,spatial,reversed=(src[k]for k in (SYNTH_LOCAL,"Spatial 50k","Spatial 50k reversed"))
        field=bandpass(luma(spatial-reversed,args))
        estimate=apply_delta(local,field,args,.5)
        cam={k:args[k][None]for k in ("wb","matrix","colors")}
        cam["packed"]=args["packed"][:1]
        case_type=case["source"]["kind"]; wire=case_type=="wire"
        provenance={"case":case["source"],"input":case["input"],"predictions":case["models"],"profile":profile}
        measured=metrics(case,estimate,args)
        np.testing.assert_allclose(list(measured.values()),list(case["scores"]["aligned-relaxed"].values()),equal_nan=True)
        boards.append(native_board(folder,f'{case["source"]["index"]:02d}-{case_type}',
            [noisy_malvar(cam)[0],local[0],spatial[0],estimate[0],args["target"][0]],cam,provenance,
            labels=("Noisy Malvar",LOCAL,SPATIAL,LABEL,"Exact GT"),
            triplet_indices=(0,3,4),exposure=2 if wire else 1/.33,
            contrast=1 if wire else 2,roi=(48,48,160,160)))
    return boards


def stored():
    native=read_json(SCENES/"collection.json")
    outputs={key:read_json(checked(v))for key,v in native["epochs"].items()}
    return {k:{r["id"]:r for r in v["records"]}for k,v in outputs.items()}


def scene_source(plan,kind):
    data=read_json(checked(plan[kind+"_full_RAW"]))
    if kind=="main":
        path=Path(data["noisy"])
        assert path.is_relative_to(".cache/gfx-qualitative-20231231")
    else:
        path=checked(data["sources"]["noisy"])
        assert ".cache/" in str(path)
    raw,meta=read_raw(path)
    return pack(torch.from_numpy(raw)[None,None])[0],meta,reference(path)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    record=reference(ROOT/"results.json")
    result=read_json(checked(record))
    assert result["choices"]["aligned-relaxed"]==["aligned",.5]
    training=reference(MATCH)
    checkpoint=read_json(checked(training))["arms"]["spatial"]["checkpoint"]
    model,_=load_scene_checkpoint(checked(checkpoint),weights="ema",expected_sha256=checkpoint["sha256"])
    model=_stage_tiled_cuda(model,"cuda")
    plan=read_json(SCENES/"plan.json")
    saved=stored()
    out=ROOT/"review"
    out.mkdir()
    standing=out/"standing"
    standing.mkdir()
    manifest=read_json(PANEL)
    assert manifest["checkpoints"]["spatial"]==checkpoint
    images=[b for b in manifest["boards"]if b["observation"].startswith(("main","mesh"))]
    review=[]
    with ieee_fp32():
        for kind in ("main","mesh"):
            full,metadata,raw=scene_source(plan,kind)
            reversed=full.flip((-1,-2))
            for idx,observation in enumerate(plan["observations"]):
                handle=observation["id"]
                if not handle.startswith(kind):continue
                with np.load(checked(observation["arrays"]),allow_pickle=False) as src:
                    args={k:src[k]for k in KEYS}
                camera=tuple(torch.from_numpy(args[k][0])for k in ("colors","wb","matrix"))
                box=observation["metadata"]["context_xywh"] if kind=="main" else [600,6260,768,768]
                x,y,w,h=(p//2 for p in box)
                np.testing.assert_array_equal(full[:,y:y+h,x:x+w],args["packed"][0])
                np.testing.assert_array_equal(args["wb"][0],np.asarray(metadata.white_balance,dtype=np.float32))
                np.testing.assert_array_equal(args["matrix"][0],np.asarray(metadata.camera_to_srgb,dtype=np.float32))
                obscure=reversed.clone()
                obscure[:,y:y+h,x:x+w].copy_(torch.from_numpy(args["packed"][0]))
                features=model.encode_scene(obscure,*camera,long_side=1024,exposure=1.)
                del obscure
                inputs=[torch.from_numpy(args[k]).cuda()for k in KEYS]
                inputs[:2]=[f.contiguous(memory_format=torch.channels_last)for f in inputs[:2]]
                model.base.set_noise(observation["noise"]["shot"],observation["noise"]["read"])
                wrong=model(*inputs,scene=features,boxes_xywh=[box]).cpu().numpy()
                local=np.load(checked(saved["none"][handle]["prediction"]),allow_pickle=False)
                spatial=np.load(checked(saved["spatial"][handle]["prediction"]),allow_pickle=False)
                calibration={k:args[k][0]for k in ("wb","matrix")}
                delivered=apply_delta(local,bandpass(luma(spatial-wrong,calibration)),calibration,.5)
                for item in [r for r in images if r["observation"]==handle]:
                    image=reference(PANEL.parent/item["image"]["path"])
                    assert image["sha256"]==item["image"]["sha256"]
                    pixels=old_pixels(item|{"image":image})
                    roi=item["case"]["ROI_xywh"]
                    exposure=item["display_exposure"]
                    wb,matrix=[torch.from_numpy(args[k])for k in ("wb","matrix")]

                    def render(data):
                        y=display_crop(torch.from_numpy(data),wb,matrix,roi,exposure=exposure)
                        return np.rint(np.clip(y,0,1)*255).astype(np.uint8)

                    np.testing.assert_array_equal(render(local),pixels[LOCAL])
                    np.testing.assert_array_equal(render(spatial),pixels[SPATIAL])
                    names=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA",LOCAL,SPATIAL)
                    parts=[(label,pixels[label])for label in names if label in pixels]
                    parts.append((LABEL,render(delivered)))
                    parts.extend((label,pixels[label])for label in ("ISO100 AHD reference","ISO100 camera JPEG")if label in pixels)
                    px,py,pw,ph=roi
                    delta=delivered[...,py:py+ph,px:px+pw].astype(float)-local[...,py:py+ph,px:px+pw].astype(float)
                    board=native_png(standing/f'{item["id"]}.png',parts)
                    review.append(dict(id=item["id"],array=observation["arrays"],raw=raw,roi=roi,
                       exposure=exposure,noise=observation["noise"],board=board,source_board=image,
                       against_local_RMS_DN16=float(np.sqrt(np.mean(delta*delta))*65535)))
                print(handle,flush=True)
            del full,reversed
    assert len(review)==8
    profile=read_json(checked(result["test"]))["noise"]
    exact=exact_views(result,profile,out/"exact")
    write_json(out/"result.json",dict(plan=record,training=training,checkpoint=checkpoint,
        strength=.5,scope="Single exposure based context-delta composition",exact=exact,standing=review,driver=reference(__file__)))

if __name__=="__main__":
    main()
