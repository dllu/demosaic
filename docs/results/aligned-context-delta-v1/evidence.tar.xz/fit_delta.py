"""Test a band-limited context intervention above the unchanged local EMA."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import dctn, rfft2, irfft2, rfftfreq, fftfreq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.with_name("local-paired-continuation-v1")
sys.path.insert(0,str(PRIOR))
from review_continuation import metrics

CONTROL=Path("docs/results/scene-050000-controlled-v1/publication.json")
TRANSFER=Path("docs/results/scene-050000-native-v1/aligned-exact.json")
MATCH=Path("docs/results/scene-full-epoch-v1/paired-prefix-050000.json")
LUMA=np.array([.2126,.7152,.0722],dtype=np.float64)
CROP=np.s_[...,80:176,80:176]
ALPHA=(0.,.25,.5,1.,2.,4.)
RADIUS=np.hypot(np.arange(16)[:,None]/32,np.arange(16)[None,:]/32)
BANDS=((1/32<=RADIUS)&(RADIUS<1/8),(1/8<=RADIUS)&(RADIUS<1/3),RADIUS>=1/3)


def luma(camera,fields):
    weights=(LUMA@fields["matrix"])*fields["wb"]
    return np.einsum("c,...chw->...hw",weights,camera)


def bandpass(values):
    """Fixed smooth radial passband, reflected edges, and native zero DC."""
    margin=32
    padded=np.pad(values,((0,0),(margin,margin),(margin,margin)),mode="reflect")
    h,w=padded.shape[-2:]
    radius=np.hypot(fftfreq(h)[:,None],rfftfreq(w)[None,:])
    lo=np.clip((radius-1/64)/(1/32-1/64),0,1)
    hi=np.clip((3/8-radius)/(3/8-0.30),0,1)
    taper=(.5-.5*np.cos(np.pi*lo))*(.5-.5*np.cos(np.pi*hi))
    rec=irfft2(rfft2(padded)*taper,s=(h,w))[...,margin:-margin,margin:-margin]
    return rec-rec.mean(axis=(-2,-1),keepdims=True)


def coeffs(values):
    pixels=values[CROP]
    block=pixels.reshape(-1,6,16,6,16).swapaxes(-2,-3).reshape(-1,36,16,16)
    return dctn(block,axes=(-2,-1),norm="ortho")*(65535/96)


def record_stats(local,target,correction):
    """Quadratic moments for prediction, increment, and truly flat control."""
    b,t,d=map(coeffs,(local,target,correction))
    result=[]
    for band in BANDS:
        e=(b-t)[...,band].reshape(3,-1)
        k=d[...,band].reshape(3,-1)
        truth=(t[0]-t[1])[...,band].ravel()
        err,increment=e[0]-e[1],k[0]-k[1]
        fields=[(err,increment),(e[0],k[0]),(e[2],k[2])]
        quad=[[p@p,2*(p@q),q@q] for p,q in fields]
        response=((err+truth)@truth,increment@truth,truth@truth)
        result.append(dict(quad=quad,response=response))
    return result


def roots(rows):
    matrix=np.asarray([[b["quad"] for b in values] for values in rows])
    response=np.asarray([[b["response"] for b in values] for values in rows])
    ordered=np.argsort(response[:,1,2],kind="stable")[:22]
    return matrix,response,ordered


def score(moments,amplitude):
    matrix,response,faint=moments
    weight=np.array([1,amplitude,amplitude**2])
    rms=(np.maximum(matrix @ weight,0))**.5
    projection=response[faint,1]
    return dict(mean_rms=rms.mean(0).tolist(),faint_rms=rms[faint].mean(0).tolist(),
                faint_response_pp=float(100*(projection[:,0]+amplitude*projection[:,1]).sum()/projection[:,2].sum()),
                overall_response_pp=float(100*(response[:,1,0]+amplitude*response[:,1,1]).sum()/response[:,1,2].sum()))


def pick(curve,quiet_budget):
    baseline=np.array(curve[0]["mean_rms"])
    allowed=[]
    for item in curve:
        error=np.array(item["mean_rms"])-baseline
        # Retain absolute errors on the present role and incremental fine/lower quality.
        if (error[:,2]<=quiet_budget+1e-10).all() and (error[:2,:2]<=.05).all():
            allowed.append(item)
    return max(allowed,key=lambda item:(item["faint_response_pp"],-item["alpha"]))


def apply_delta(local,correction,fields,alpha):
    if not alpha:
        return local
    camera_neutral=np.linalg.solve(fields["matrix"],np.ones(3))/fields["wb"]
    return (local+alpha*correction[:,None]*camera_neutral[None,:,None,None]).astype(np.float32)


def fit():
    proof=reference(CONTROL)
    controlled=read_json(checked(proof))
    table=read_json(checked(controlled["endpoint_results"]))
    rows=[r for r in table["source_metrics"] if (r["profile"],r["draw"])==("iso6400","independent")]
    assert len(rows)==64
    moments=defaultdict(list)
    identities=[]
    for row in rows:
        prediction=read_json(checked(row["prediction_receipt"]))
        capture=read_json(checked(prediction["case"]))
        identities.append(capture["source"])
        with np.load(checked(capture["input"]),allow_pickle=False) as vals:
            fields={k:vals[k]for k in ("wb","matrix","target")}
        with np.load(checked(prediction["saved"]),allow_pickle=False) as vals:
            local,spatial,wrong=map(lambda name:luma(vals[name],fields),
                ("none","spatial--matching","spatial--wrong-distant"))
        target=luma(fields["target"],fields)
        aligned=bandpass(spatial-wrong)
        full=bandpass(spatial-local)
        for name,delta in {"aligned":aligned,"flipped":-aligned,"full_spatial":full}.items():
            moments[name].append(record_stats(local,target,delta))
    fit={}
    for name,rows in moments.items():
        moment=roots(rows)
        curve=[dict(alpha=a,**score(moment,a))for a in ALPHA]
        fit[name]=dict(curve=curve,strict=pick(curve,0.),relaxed=pick(curve,.10))
    return proof,identities,fit


def test(fit, source_ids):
    proof=reference(TRANSFER)
    upstream=read_json(checked(proof))
    numeric=read_json(checked(upstream["result"]))
    assert upstream["training"]==reference(MATCH)
    choices={
        f"{family}-{tag}":(family,result[tag]["alpha"])
        for family,result in fit.items() for tag in ("strict","relaxed")
    }
    choices |= {family+"-unit":(family,1.)for family in fit}
    grouped={}
    for kind,rows in numeric["metrics"].items():
        observed=[]
        for row in rows:
            identity=row["source"]["source"]["id"]
            assert identity not in source_ids
            with np.load(checked(row["input"]),allow_pickle=False)as vals:
                raw={k:vals[k]for k in vals.files}
            with np.load(checked(row["output"]),allow_pickle=False)as vals:
                local,spatial,reverse=(vals[k]for k in ("Local 50k","Spatial 50k","Spatial 50k reversed"))
            aligned=bandpass(luma(spatial-reverse,raw))
            total=bandpass(luma(spatial-local,raw))
            options={"aligned":aligned,"flipped":-aligned,"full_spatial":total}
            scores={"Local 50k":metrics(row,local,raw)}
            for name,(family,alpha) in choices.items():
                out=apply_delta(local,options[family],raw,alpha)
                scores[name]=metrics(row,out,raw)
            observed.append(dict(identity=identity,source=row["source"],input=row["input"],
                                 models=row["output"],scores=scores))
        grouped[kind]=observed
    return proof,choices,grouped


def summarize(groups):
    rng=np.random.default_rng(229911)
    output={}
    for kind,rows in groups.items():
        ids=np.vstack([np.arange(len(rows)),rng.integers(len(rows),size=(4500,len(rows)))])
        scores=[r["scores"] for r in rows]
        variants={}
        for name in scores[0]:
            if name=="Local 50k": continue
            variants[name]={}
            for key in sorted(set().union(*(x[name] for x in scores))):
                array=np.array([[r[name][key],r["Local 50k"][key]]for r in scores if r[name].get(key) is not None])
                subset=ids if len(array)==len(rows) else np.vstack(
                    [np.arange(len(array)),rng.integers(len(array),size=(4500,len(array)))]
                )
                estimate=array[subset].mean(1)
                change=estimate[:,0]-estimate[:,1]
                variants[name][key]=dict(left=float(estimate[0,0]),right=float(estimate[0,1]),
                            difference=float(change[0]),interval=np.quantile(change[1:],[.025,.975]).tolist())
        output[kind]=variants
    return output


def main():
    start=time.monotonic()
    calibration,ids,fit_results=fit()
    plan=ROOT/"locked-fit.json"
    write_json(plan,dict(source=calibration,driver=reference(__file__),training=reference(MATCH),
        calibration_sources=ids,band_transition_cycles=[[1/64,1/32],[.3,3/8]],
        amplitudes=ALPHA,mean_flat_budgets_DN16=[0.,.1],fit=fit_results,
        scope="64 previously reviewed natural calibration photos. Every transfer source is source-disjoint."))
    print("selected",{k:(r["strict"]["alpha"],r["relaxed"]["alpha"])for k,r in fit_results.items()},flush=True)
    transfer,choices,rows=test(fit_results,set(ids))
    write_json(ROOT/"results.json",dict(plan=reference(plan),test=transfer,choices=choices,
        summary=summarize(rows),rows=rows,seconds=time.monotonic()-start))
    print("tested",{k:len(r)for k,r in rows.items()}, flush=True)

if __name__=="__main__":
    main()
