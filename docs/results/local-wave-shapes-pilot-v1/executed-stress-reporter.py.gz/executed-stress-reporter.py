from pathlib import Path
import os
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from report_checkpoint_pilot import pixels
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

root=Path(__file__).absolute().parent
out=root/'stress';out.mkdir()
os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:])
plan=read_json(root/'harmonics/plan.json')
collections={a:{r['id']:r for r in read_json(root/a/'collection.json')['rows']}for a in ['matching','harmonics']}
figures=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10)
for row in plan['rows']:
 if row['kind'] not in ['gfx','mesh']:continue
 values={a:np.load(checked(collections[a][row['id']]['predictions']['local-t2']),allow_pickle=False)[None]for a in collections}
 parent=np.load(checked(row['parent']),allow_pickle=False)[row['sample']:row['sample']+1]
 delta=np.abs(values['harmonics']-values['matching']).max(axis=(0,1))
 py,px=np.unravel_index(np.argmax(delta),delta.shape);h,w=delta.shape
 x,y=int(np.clip(px-80,0,w-160)),int(np.clip(py-80,0,h-160));roi=[x,y,160,160]
 with np.load(checked(row['arrays']),allow_pickle=False)as z:cal={k:z[k][row['sample']:row['sample']+1]for k in ['wb','matrix']}
 cells=[(label,pixels(value,cal,roi,row['display_exposure']))for label,value in [('V120',parent),('H1 matched local t2',values['matching']),('H3 matched local t2',values['harmonics'])]]
 canvas=Image.new('RGB',(512,192),'#eeeeee');draw=ImageDraw.Draw(canvas)
 for i,(label,cell)in enumerate(cells):draw.text((8+168*i,5),label,font=font,fill='black');canvas.paste(Image.fromarray(cell),(8+168*i,24))
 path=out/(row['id']+'-max-new-change.png');canvas.save(path);saved=np.asarray(Image.open(path))
 for i,(_,cell)in enumerate(cells):np.testing.assert_array_equal(saved[24:184,8+168*i:168+168*i],cell)
 figures.append({'image':reference(path),'case':row['id'],'ROI_xywh':roi,'selected_pixel_xy':[int(px),int(py)],'maximum_new_camera_change_DN16':float(delta.max()*65535),'source':row,'calibration':{k:v.tolist()for k,v in cal.items()},'no_resize':True,'display_exposure':row['display_exposure'],'display_contrast':1})
write_json(out/'manifest.json',{'reporter':reference(__file__),'figures':figures,'scope':'Post-inference stress ROIs centered on the largest absolute camera-RGB H3-minus-H1 matched local-t2 change in each complete context. No GT/reference selection; no GT/reference claimed for extra coordinates. Zero-change sky uses the first pixel by deterministic argmax. Same native160 cells/display, not representative sampling or full-context quality assurance.'})
print([(f['case'],f['ROI_xywh'],round(f['maximum_new_camera_change_DN16'],3))for f in figures])
