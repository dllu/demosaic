from pathlib import Path
import gzip, shutil, tarfile
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo=Path.cwd()
root=Path(__file__).absolute().parent
dest=repo/'docs/results/local-wave-shapes-pilot-v1'
images=repo/'docs/images/local-wave-shapes-pilot-v1'
dest.mkdir(parents=True,exist_ok=False)
images.mkdir(parents=True,exist_ok=False)
archives=[]
def archive(path,name):
 data=path.read_bytes(); target=dest/(name+'.gz')
 with target.open('xb') as f:f.write(gzip.compress(data,mtime=0))
 assert gzip.decompress(target.read_bytes())==data
 archives.append({'original':reference(path),'archive':reference(target),'encoding':'gzip; exact original bytes'})
for name in ['plan.json','launch.json','status.json','legacy-equivalence.json','both-arms-closed-before-GT.json','comparison/summary.json','stress/manifest.json','viewing.json','quality-review.json','quality-review-v2.json','long-runs-observed.json']:
 archive(root/name,name.replace('/','-'))
archive(repo/'.cache/experiments/local-wave-matching-audit-v1/result.json','saved-frequency-matching-audit.json')
for arm in ['matching','harmonics']:
 for name in ['plan.json','analytic-model.json','owner.json','collection.json','finite-scores.json','report/report.json','independent-audit.json']:
  archive(root/arm/name,arm+'-'+name.replace('/','-'))
for key,path in [('study',root),('matching',root/'matching'),('harmonics',root/'harmonics')]:
 plan=read_json(path/'plan.json');work=Path(plan['work']);target=dest/(key+'-executed-sources.tar.gz')
 with tarfile.open(target,'x:gz') as tar:
  for source,digest in plan['frozen_files'].items():
   p=checked({'path':source,'sha256':digest});tar.add(p,arcname=str(p.relative_to(work)))
 archives.append({'archive':reference(target),'encoding':'tar.gz of exact frozen Python files','bound_by':reference(dest/(key+'-plan.json.gz') if key!='study' else dest/'plan.json.gz')})
for source in ['src/demosaic/local_validated_waves.py','tests/test_local_validated_waves.py','scripts/study_local_wave_shapes.py','scripts/report_local_wave_shapes.py','scripts/pilot_local_validated_waves.py']:
 target=dest/Path(source).name
 shutil.copyfile(repo/source,target)
 archives.append({'original':reference(repo/source),'archive':reference(target),'encoding':'identical source bytes'})
archive(root/'report_local_wave_shapes.py','executed-comparison-reporter.py')
archive(root/'stress.py','executed-stress-reporter.py')
archive(root/'publish.py','publisher.py')
copied=[]
for arm,folder in [('comparison',root/'comparison'),('matching',root/'matching/report'),('harmonics',root/'harmonics/report'),('stress',root/'stress')]:
 target_dir=images/arm;target_dir.mkdir()
 for source in sorted(folder.glob('*.png')):
  target=target_dir/source.name;shutil.copyfile(source,target)
  assert source.read_bytes()==target.read_bytes()
  copied.append({'original':reference(source),'copy':reference(target),'native_pixels_unchanged':True})
write_json(images/'manifest.json',{'boards':copied,'comparison':reference(dest/'comparison-summary.json.gz'),'arm_reports':{a:reference(dest/(a+'-report-report.json.gz')) for a in ['matching','harmonics']},'scope':'Native160 cells copied unchanged. Full source/ROI/noise/display/domain checkpoint/configuration metadata is byte-preserved in the archived report/summary receipts. Both real reference exposures and JPEGs are qualitative, not exact GT.'})
write_json(dest/'publication.json',{'status':'completed-controlled-waveform-pilot-and-native-review','archives':archives,'image_manifest':reference(images/'manifest.json'),'scope':'H1 legacy versus matching-only versus H3. Reused development pilot, not broad promotion. Both input-only arms close before new scoring; original full-panel/training continue unchanged. No original receipt/prediction overwritten.'})
print(len(archives),'archives;',len(copied),'native boards copied')
