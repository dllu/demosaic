"""Publish the fresh matched panels and future-proof their case lineage."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
report = read_json(root / "review/result.json")
done = read_json(checked(report["source"]))
plan = read_json(checked(done["plan"]))
images = Path("docs/images") / root.name
results = Path("docs/results") / root.name
images.mkdir()
results.mkdir()
boards = []
for record in report["boards"]:
    case = read_json(checked(record["case_receipt"]))
    outputs = []
    for label in ("board", "triplet"):
        group = record[label]
        img = checked(group["image"])
        dest = images / img.name
        shutil.copyfile(img, dest)
        assert reference(dest)["sha256"] == group["image"]["sha256"]
        outputs.append(group | {"file": dest.name})
    boards.append(
        {k: v for k, v in record.items() if k not in ("board", "triplet")}
        | {
            "appearance": case["appearance"],
            "CFA": case["CFA"],
            "noise": plan["profiles"][case["profile"]],
            "checkpoint": plan["parent_checkpoint"],
            "inference": "CUDA IEEE FP32 V143 EMA, CPU analytic delivery",
            "setting": plan["settings"][case["profile"]],
            "files": outputs,
        }
    )
manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "boards": boards,
        "scope": "The noisy, affinity-first and exact synthetic target cells of both triplets were inspected at native pixels.",
    },
)
shutil.copyfile(root / "review/result.json", results / "summary.json")
inputs = [
    (root, p)
    for p in (
        "plan.json",
        "collect.log",
        "output/collection.json",
        "review/result.json",
        "review.py",
        "publish.py",
        "execution-policy-overlap.json",
        "work/scripts/probe_affinity_first_fresh.py",
        "work/src/demosaic/search_donor_geometry.py",
    )
]
for v in done["cases"]:
    inputs.append((root, f"output/{checked(v).name}"))
for version in ("v1", "v2"):
    previous = root.parent / f"affinity-first-fresh-{version}"
    inputs.extend((previous, p) for p in ("plan.json", "collect.log"))
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as dest,
    gzip.GzipFile(filename="", fileobj=dest, mode="wb", mtime=0) as gz,
    tarfile.open(fileobj=gz, mode="w") as tf,
):
    for directory, p in inputs:
        original = directory / p
        info = tf.gettarinfo(str(original), arcname=f"{directory.name}/{p}")
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ""
        with original.open("rb") as file:
            tf.addfile(info, file)
with tarfile.open(archive) as tf:
    for d, p in inputs:
        assert tf.extractfile(f"{d.name}/{p}").read() == (d / p).read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "archive_members_verified": len(inputs),
        "manifest": reference(manifest),
        "summary": reference(results / "summary.json"),
        "partial_runs": {
            "v1": "CPU partial stopped after CUDA confirmation. Original completed cases preserved.",
            "v2": "Invalid CUDA device index in setup, before observations.",
        },
        "scope": "16 fresh case groups, two native triplets and comparison boards viewed. Same V143 EMA for all arms. No neural training.",
    },
)
