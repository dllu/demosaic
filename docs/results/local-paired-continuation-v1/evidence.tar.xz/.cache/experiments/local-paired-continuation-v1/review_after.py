"""Start the scoped reviews after the bound training receipt is available."""
from pathlib import Path
import subprocess
import sys
import time

from demosaic.experiments.artifacts import read_json
from demosaic.experiments.runtime import owner_live

root = Path(__file__).resolve().parent
training = root / "training"
owner = read_json(training / "owner.json")
while not (training / "completed.json").is_file():
    if not owner_live(owner):
        raise RuntimeError("Matched training stopped before writing the completion receipt")
    time.sleep(10)
subprocess.run([sys.executable,"-u",str(root / "review_continuation.py")],check=True)
