"""Bind the executed match and viewed detail boards to immutable artifacts."""
from copy import deepcopy
from datetime import datetime
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS, IMAGES = (Path("docs") / tag / ROOT.name for tag in ("results", "images"))
EMA_LABEL = "Paired continuation"


def copy_board(board):
    source = checked(board["image"])
    destination = IMAGES / source.parent.name / source.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert reference(destination)["sha256"] == board["image"]["sha256"]
    board["image"]["path"] = str(destination.relative_to(IMAGES))
    data = np.asarray(Image.open(destination).convert("RGB"))
    images = {}
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert w == h == 160
        images[panel.get("label", panel.get("name"))] = data[y:y+h, x:x+w]
    return images


def main():
    result = reference(ROOT / "review/result.json")
    native = read_json(checked(result))
    notes = reference(ROOT / "viewing-notes.json")
    notes_by_id = read_json(checked(notes))
    run = read_json(checked(native["endpoint"]))
    assert run["updates_per_arm"] == 512 and run["native_observations_per_arm"] == 2048
    assert run["DINO_unchanged"] and not run["qualification"]
    for checkpoint in run["checkpoints"].values():
        checked(checkpoint)
    redraw = reference(ROOT / "redraw/results.json")
    independent = read_json(checked(redraw))
    assert independent["summary"]["coupled"]["photos"] == independent["summary"]["independent"]["photos"] == 16
    assert read_json(checked(independent["plan"]))["endpoint"] == native["endpoint"]

    provenance = {"weights": "ema", "precision": native["precision"], "endpoints": run["checkpoints"],
                  "parent": run["parent"], "reference_models": native["previous_review"],
                  "review": result, "viewing_notes": notes,
                  "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()}
    exact = deepcopy(native["exact"])
    assert len(exact) == 3 and len(notes_by_id["exact"]) == 3
    for item in exact:
        board = copy_board(item["board"])
        triplet = copy_board(item["triplet"])
        assert list(triplet) == ["Noisy Malvar", EMA_LABEL, "Exact GT"]
        assert all(np.array_equal(board[k], triplet[k]) for k in triplet)
    standing = deepcopy(native["standing"])
    assert {item["id"] for item in standing} == set(notes_by_id["standing"])
    for item in standing:
        contents = copy_board(item["board"])
        assert EMA_LABEL in contents and "ISO100 AHD reference" in contents
        if item["id"].startswith("mesh-"):
            assert "ISO100 camera JPEG" in contents and "ISO6400 camera JPEG" in contents
    write_json(IMAGES / "manifest.json", provenance | {"exact": exact, "standing": standing})
    RESULTS.mkdir(parents=True)
    archive = RESULTS / "evidence.tar.xz"
    plan = read_json(checked(run["plan"]))
    pieces = [
        result, notes, native["endpoint"], run["plan"], plan["schedule"], plan["qualification_schedule"],
        run["observations"], run["log"], plan["driver"], redraw, independent["plan"],
        reference(ROOT / "qualification/completed.json"),
        reference(ROOT / "qualification/train.jsonl"),
        reference(ROOT / "qualification/observations.jsonl"),
        reference(ROOT / "training.log"),
        reference(ROOT / "review.log"),
        reference(ROOT / "redraw.log"),
        *(reference(path) for path in ROOT.glob("*.py")),
    ]
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for name, item in sorted({str(Path(p["path"]).relative_to(Path.cwd())): p for p in pieces}.items()):
            tar.add(checked(item), arcname=name, recursive=False)
    write_json(RESULTS / "publication.json", provenance | dict(
        training_complete=True, scoped_atomic_metrics_complete=True,
        independent_redraw_review_complete=True, actual_native_view_complete=True,
        fixed427_and_camera_complete=False,
        run=native["endpoint"], archive=reference(archive), models=run["checkpoints"],
        qualified_updates=8, training_seconds=run["training_seconds"],
        exact_forward_seconds={m: sum(r["forward_seconds"][m] for r in native["wire"] + native["photo"])
                               for m in run["checkpoints"]},
        standing_forward_seconds=native["standing_forward_seconds"],
        independent_forward_and_metrics_seconds=independent["seconds"],
        exact_summary=native["summary"], redraw_summary=independent["summary"],
        manifest=reference(IMAGES / "manifest.json"),
    ))
    print(len(exact), len(standing), RESULTS)


if __name__ == "__main__":
    main()
