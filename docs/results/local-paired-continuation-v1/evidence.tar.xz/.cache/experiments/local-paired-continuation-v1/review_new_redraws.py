"""Check the signed correction on reserved photos with physically independent redraws."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from review_continuation import ROOT, BASELINE, ARMS, LOCAL, restore
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint

REPEAT = ROOT.with_name("paired-repeat-stability-v2")
from continuation_redraw_math import channel_coefficients, contributions, BANDS as MASKS


def summarize(cases):
    rng = np.random.default_rng(202611191118)
    groups = {}
    for law, rows in cases.items():
        names = tuple(rows[0]["arms"])
        keys = ("mean_increment_RMS_DN16", "shared_error_product_DN16_squared",
                "swapped_draw_variance_DN16_squared", "mean_present_RMS_DN16", "mean_quiet_RMS_DN16")
        indexes = np.vstack([np.arange(len(rows)), rng.integers(len(rows), size=(7500, len(rows)))])
        samples = {}
        for name in names:
            entries = [row["arms"][name] for row in rows]
            values = {key: np.array([v[key] for v in entries])[indexes].mean(1) for key in keys}
            dots = np.array([v["aligned_dot"] for v in entries])[indexes].sum(1)
            power = np.array([v["clean_power"] for v in entries])[indexes].sum(1)
            samples[name] = values | {"pooled_response_pp": 100 * dots / power}
        paired = samples[ARMS["paired"]]
        groups[law] = {
            "photos": len(rows), "per_arm": {name: {k: float(v[0]) for k, v in vals.items()} for name, vals in samples.items()},
            "paired_differences": {
                comp: {key: {"delta": float(change[0]), "interval": np.quantile(change[1:], [.025, .975]).tolist()}
                       for key in paired if (change := paired[key] - samples[comp][key]).size}
                for comp in (ARMS["absolute"], LOCAL)
            },
        }
    return groups


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root = ROOT / "redraw"
    root.mkdir()
    run = reference(ROOT / "training/completed.json")
    endpoints = read_json(checked(run))
    before = read_json(BASELINE / "review.json")
    prior_sources = {row["source"]["source"]["id"] for kind in ("wire", "photo") for row in before[kind]}
    training_plan = read_json(checked(endpoints["plan"]))
    train_ids = {r["source"]["id"] for r in read_json(checked(training_plan["schedule"]))}
    bindings = [reference(REPEAT / f"observation-shard-{i}.json") for i in range(2)]
    rows = [
        row for proof in bindings for row in read_json(checked(proof))["rows"]
        if row["index"] >= 64 and row["profile"]["name"] == "iso6400"
    ]
    assert len(rows) == 64 and train_ids.isdisjoint(row["source"] for row in rows)
    sources = sorted({r["index"] for r in rows if r["source"] not in prior_sources})[:16]
    assert len(sources) == 16
    panel = reference(REPEAT / "evaluation-plan.json")
    roi = read_json(checked(panel))["score_ROI_xywh"]
    configs = {LOCAL: endpoints["parent"]} | {label: endpoints["checkpoints"][arm] for arm, label in ARMS.items()}
    plan = {"panel": panel, "sources": sources, "endpoint": run, "observations": bindings, "models": configs,
            "native_ROI": roi, "noise": "ISO6400, three draws of each target under each coupling law"}
    write_json(root / "plan.json", plan)
    models = {}
    for name, binding in configs.items():
        model, state = load_scene_checkpoint(
            checked(binding), weights="ema", expected_sha256=binding["sha256"])
        assert state["loaded_sha256"] == binding["sha256"]
        models[name] = _stage_tiled_cuda(model.eval(), "cuda")
    grouped = defaultdict(list)
    started = time.monotonic()
    for i, case in enumerate(sorted((r for r in rows if r["index"] in sources), key=lambda r:r["id"]), start=1):
        band_output = defaultdict(list)
        target = None
        for d in case["draws"]:
            assert d["original"] is None
            with np.load(checked(d["file"]), allow_pickle=False) as f:
                args = {k: f[k] for k in d["fingerprints"]}
            assert {k: fingerprint(v) for k, v in args.items()} == d["fingerprints"]
            desired = channel_coefficients(args["target"], args, roi)[1]
            if target is None:
                target = desired
            else:
                np.testing.assert_array_equal(target, desired)
            data = dict(args)
            data.update({k: args[k][0] for k in ("colors", "wb", "matrix")})
            for name, model in models.items():
                restored, _ = restore(model, data, case["profile"])
                band_output[name].append(channel_coefficients(restored, args, roi)[1])
        scores = {name: contributions(np.stack(terms), target, MASKS["fine"]) for name, terms in band_output.items()}
        grouped[case["coupling"]].append({"case": case, "arms": scores})
        if i % 4 == 0:
            print(i, round(time.monotonic() - started, 2), flush=True)
    assert set(grouped) == {"coupled", "independent"}
    assert all(len(items) == 16 for items in grouped.values())
    write_json(root / "results.json", dict(cases=grouped, summary=summarize(grouped),
        seconds=time.monotonic()-started, plan=reference(root/"plan.json"), driver=reference(__file__)))


if __name__ == "__main__":
    main()
