"""Validate source isolation and delivered mixer arithmetic."""

import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT, identities, base, REGIMES
from confirm_capture import OUT as CONFIRM
from confirm_router import assess, coefficient_data, networks, all_changes
from score_router import captures
from review_router import render
from audit_sources import CORPUS, LOCAL, matches
import mild_score as math
import score


def source_check(first, confirmation):
    a, b = (read_json(checked(item)) for item in (first, confirmation))
    groups = a["groups"] | b["groups"]
    test = [row for r in groups.values() for row in r]
    photos = identities(test)
    assert len(photos) == 2 * len(test)
    with checked(a["training_manifest"]).open() as stream:
        assert photos.isdisjoint(identities(map(json.loads, stream)))
    parents = read_json(checked(a["references"]["previous"]))
    assert photos.isdisjoint(identities(r for v in parents["cases"].values() for r in v))
    broad427 = read_json(checked(a["full427"]))["source_metadata"]
    assert len(broad427) == 427 and photos.isdisjoint(identities(broad427))
    direct_previous = read_json(checked(parents["previous_held"]))
    assert photos.isdisjoint(identities(direct_previous["samples"]))
    training = read_json(checked(parents["previous_dataset"]))
    earlier = read_json(checked(training["previous"]))
    assert photos.isdisjoint(identities(training["samples"] + earlier["samples"]))
    all_used = []
    for tag, wanted in (("redraw", 512), ("direct", 768)):
        r = read_json(checked(a["references"][tag]))
        seen = set()
        for ref in r["stats"]:
            chunk = read_json(checked(ref))
            for row in chunk["samples"]:
                src = row["source"]
                seen.add(src if isinstance(src, str) else src["id"])
                seen.add(row["cache_sha256"] if "cache_sha256" in row else row["cache"]["sha256"])
        assert len(seen) == 2 * wanted and seen.isdisjoint(photos)
        all_used.append(seen)
    assert all_used[0].isdisjoint(all_used[1])
    corpus = reference(CORPUS)
    model = reference(LOCAL)
    first100 = read_json(checked(corpus))
    local = read_json(checked(model))
    assert first100["checkpoint"] == local["parent"] and local["checkpoint"] == a["parent"]
    corpus_count = 0
    for row in first100["source_traces"]:
        with checked(row).open() as f:
            for line in map(json.loads, f):
                for item in line["sources"]:
                    if item["kind"] == "photographic":
                        assert not matches(item, photos)
                        corpus_count += 1
    local_count = 0
    for piece in local["segments"]:
        with checked(piece["observations"]).open() as f:
            for line in map(json.loads, f):
                assert not matches(line, photos)
                local_count += 1
    assert corpus_count == 559808 and local_count == 5000
    return {
        "groups": {k: len(v) for k, v in groups.items()},
        "training": [512, 768],
        "corpus": corpus,
        "photo_visits": corpus_count,
        "local": model,
        "terminal_observations": local_count,
        "full427_overlap": 0,
    }


def recalculate(source, parameters):
    findings = {}
    for r, samples in captures(source):
        for key, (d, p) in samples.items():
            options = {
                "split Bayer": ("split Bayer", (0.575, 0.575)),
                "routed": ("routed", (0.50, 0)),
            }
            outputs = render(d, p, r, parameters, options)
            offsets, _, weights = all_changes(d, p, r["profile"], parameters)
            a, t = (score.stats(x, d) for x in (p["nominal"], d["target"]))
            for mode, (_, strength) in options.items():
                z = np.asarray(weights[mode])
                np.testing.assert_allclose(z.sum(axis=1), 1, atol=2e-7, rtol=0)
                assert np.min(z) >= 0 and np.max(z) <= 1
                c = offsets[mode]
                terms = {mode: math.terms(t, a, *[math.coefficients(x) for x in c])}
                zero = {"nominal": math.terms(t, a, *[math.coefficients(np.zeros_like(c[0]))] * 2)}
                established = {"scores": terms | zero}
                observed = assess(
                    coefficient_data([established, established], mode),
                    coefficient_data([established, established], "nominal"),
                    strength,
                )["scores"]
                direct = score.parts(score.stats(outputs[mode], d), t, np.zeros_like(a))["fine"]
                rms = {k: float(np.sqrt(direct[k][0])) for k in score.LIMITS}
                signed = 100 * direct["response"][0] / direct["true"]
                drift = {
                    k: abs(observed[k] - val) for k, val in (rms | {"response_pp": signed}).items()
                }
                for k, x in drift.items():
                    assert x < 0.0015, (r["id"], mode, key, k, x)
                findings[f"{r['id']}/{key}/{mode}"] = drift
    return findings


def run():
    torch.set_num_threads(2)
    plan, follow = reference(OUT / "plan.json"), reference(CONFIRM / "plan.json")
    preflight = reference(OUT / "preflight/completed.json")
    fit, output = networks()
    coverage = source_check(plan, follow)
    reproduce = recalculate(preflight, output)
    print(coverage, max(max(a.values()) for a in reproduce.values()), flush=True)
    write_json(
        OUT / "audit.json",
        {
            "driver": reference(Path(__file__)),
            "plan": plan,
            "confirm_plan": follow,
            "preflight": preflight,
            "fit": fit,
            "coverage": coverage,
            "coefficient_vs_pixels": reproduce,
        },
    )


if __name__ == "__main__":
    run()
