"""Publish source-bound router training, transfer and native review evidence."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import HERE, OUT

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULT = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "plan",
    "preflight/completed",
    "calibration/completed",
    "held/completed",
    "fit-preflight/result",
    "fit-training/result",
    "score-calibration",
    "score-held",
    "confirmation/plan",
    "confirmation/confirm/completed",
    "fit-split/result",
    "robust-calibration",
    "score-confirm",
    "first-held-buffered",
    "matched",
    "audit",
    "review-camera",
    "review-natural",
    "review-wires",
)
FILES = {
    "detail-redraw-gate-v1": ("redraw_gate.py", "collect_redraw.py"),
    "direct-detail-response-v1": (
        "direct_detail.py",
        "train_direct.py",
        "collect_direct.py",
        "evaluate_direct.py",
        "audit_sources.py",
    ),
    "scene-detail-selector-v1": (
        "detail_selector.py",
        "collect_training.py",
        "evaluate_selector.py",
        "benchmark_shared_local_encoding.py",
        "review_selector.py",
        "train_selector.py",
    ),
    "scene-local-contrast-2400-v1": ("prepare_eval.py",),
    "context-conditioned-detail-v1": ("mild_score.py", "score.py", "context_gate.py", "capture.py"),
}


def bound(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def figure(confirm):
    methods = {
        "stable original": ("Earlier stability head", "#555555"),
        "fixed mix": ("Buffered fixed mixture", "#aa3377"),
        "routed": ("Buffered single router", "#4477aa"),
        "split static": ("Buffered branchwise fixed", "#ee7733"),
        "split Bayer": ("Buffered branchwise Bayer", "#228833"),
    }
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.25), layout="constrained")
    y0 = confirm["faint"]["scores"]["nominal"]["response_pp"]
    for ax, group, metric, limit, title in zip(
        axes,
        ("stronger", "faint"),
        ("increment", "flat"),
        (0.10, 0.05),
        ("Paired error on stronger textures", "Exact-flat error on faint fixtures"),
        strict=True,
    ):
        x0 = confirm[group]["scores"]["nominal"][metric]
        for name, (label, color) in methods.items():
            x = [r["scores"][metric] - x0 for r in confirm[group]["curves"][name]]
            y = [r["scores"]["response_pp"] - y0 for r in confirm["faint"]["curves"][name]]
            ax.plot(x, y, c=color, label=label)
            ax.scatter(x[-1], y[-1], color=color, s=25)
        ax.axvline(0, color="#878787", ls=":", lw=1)
        ax.axhline(0, color="#878787", ls=":", lw=1)
        ax.axvline(limit, color="#242424", ls="--", lw=1)
        ax.set_title(title)
        ax.set_xlabel("RMS difference from Local 50k (DN16)")
    axes[0].set_ylabel("Faint response gain (percentage points)")
    axes[1].legend(frameon=False, fontsize=7.4, loc="upper right")
    path = ASSETS / "response-versus-error.png"
    fig.savefig(path, dpi=155)
    return bound(path)


def tile(row):
    old = checked(row["image"])
    path = ASSETS / old.name
    shutil.copyfile(old, path)
    now = bound(path)
    assert now["sha256"] == row["image"]["sha256"]
    with Image.open(path) as bitmap:
        for item in row["panels"]:
            x, y, w, h = item["png_xywh"]
            assert w == h == 160 and x + w <= bitmap.width and y + h <= bitmap.height
    return row | {"image": now}


def verify(data, refs, book):
    first, conf = refs["plan"], refs["confirmation/plan"]
    assert data["confirmation/plan"]["prior_plan"] == first
    audit = data["audit"]
    assert audit["plan"] == first and audit["confirm_plan"] == conf
    a, b = refs["fit-training/result"], refs["fit-split/result"]
    assert all(
        data[k]["plan"] == first
        for k in ("fit-preflight/result", "fit-training/result", "fit-split/result")
    )
    fits = [a, b]
    assert data["audit"]["fit"] == fits
    for name in ("score-calibration", "score-held"):
        assert data[name]["fit"] == a
    assert data["score-held"]["calibration"] == refs["score-calibration"]
    original, later = refs["score-calibration"], refs["robust-calibration"]
    assert data["robust-calibration"]["first_policy"] == original
    assert data["robust-calibration"]["source"] == refs["calibration/completed"]
    assert data["score-confirm"]["robust_calibration"] == later
    assert data["first-held-buffered"]["buffer"] == later
    assert data["first-held-buffered"]["first"] == refs["score-held"]
    for mode in (
        "robust-calibration",
        "score-confirm",
        "review-natural",
        "review-camera",
        "review-wires",
    ):
        assert data[mode]["fit"] == fits
    for mode in ("review-natural", "review-camera", "review-wires"):
        assert data[mode]["calibration"] == later
    assert (
        data["matched"]["source"]
        == data["review-natural"]["report"]["evaluation"]
        == refs["score-confirm"]
    )
    assert data["score-confirm"]["policy"]["primary"] == data["review-natural"]["primary"]
    for prefix, scoring, plan in (
        ("preflight", None, first),
        ("calibration", "score-calibration", first),
        ("held", "score-held", first),
        ("confirmation/confirm", "score-confirm", conf),
    ):
        name = f"{prefix}/completed"
        c = data[name]
        assert c["plan"] == plan
        slots = read_json(checked(plan))["groups"][Path(prefix).name]
        rows = []
        for i, f in enumerate(c["chunks"]):
            d = read_json(checked(f))
            assert d["plan"] == plan
            rows.extend(d["rows"])
            book[f"chunks/{prefix}/{i:02}.json"] = f
        assert len(rows) == len(slots) == c["source_count"]
        for r, w in zip(rows, slots, strict=True):
            assert r["source"]["id"] == w["id"] and r["source"]["cache_sha256"] == w["cache_sha256"]
            assert len(set(r["seeds"])) == 6 and set(r["inputs"]) == {"faint", "stronger"}
            for f in r["inputs"].values():
                checked(f)
        if scoring:
            score = data[scoring]
            assert score["source"] == refs[name]
            assert all(
                r["id"] == u["id"] and r["inputs"] == u["inputs"]
                for r, u in zip(rows, score["rows"], strict=True)
            )
    for k in ("fit-preflight", "fit-training", "fit-split"):
        for arm, row in data[f"{k}/result"]["checkpoints"].items():
            book[f"checkpoints/{k}/{arm.replace(' ', '-')}.pt"] = row


def main():
    receipts = {k: reference(OUT / (k + ".json")) for k in RECEIPTS}
    data = {k: read_json(checked(row)) for k, row in receipts.items()}
    for r in data.values():
        for k in ("driver", "followup_driver", "operator"):
            if k in r:
                checked(r[k])
    book = {f"receipts/{k}.json": r for k, r in receipts.items()}
    verify(data, receipts, book)
    for name, value in data["plan"]["expert_checkpoints"].items():
        book[f"checkpoints/frozen/{name}.pt"] = value
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULT.mkdir(exist_ok=True, parents=True)
    planets = data["review-natural"]["report"]["rows"]
    cameras = data["review-camera"]["report"]["rows"]
    assert len(planets) == 2 and sum(len(r["views"]) for r in cameras) == 12
    for r in planets:
        r["views"] = {k: tile(v) for k, v in r["views"].items()}
    for r in cameras:
        for v in r["views"]:
            labels = {x["label"] for x in v["panels"]}
            assert "ISO100 AHD reference" in labels
            if r["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= labels
        r["views"] = [tile(v) for v in r["views"]]
    c = data["score-confirm"]
    plot = figure(c["results"])
    summary = RESULT / "summary.json"
    training = {
        k: {m: v for m, v in data[f"{k}/result"].items() if m not in ("logs", "stats")}
        for k in ("fit-training", "fit-split")
    }
    write_json(
        summary,
        {
            "training": training,
            "coverage": data["audit"]["coverage"],
            "primary": c["policy"]["primary"],
            "locks": {k: r["locked"] for k, r in c["policy"]["arms"].items()},
            "initial": {k: r["scores"] for k, r in data["score-held"]["summary"].items()},
            "initial_buffered_replay": data["first-held-buffered"]["scores"],
            "confirmation": {
                k: {n: v for n, v in a.items() if n != "curves"} for k, a in c["results"].items()
            },
            "matched": {m: v for m, v in data["matched"].items() if m not in ("driver", "source")},
            "wire": data["review-wires"]["report"]["summary"],
            "camera": {r["id"]: r["RGB_change_DN16"] for r in cameras},
        },
    )
    refs = ASSETS / "manifest.json"
    write_json(
        refs,
        {
            "training": training,
            "parent": data["plan"]["parent"],
            "v120": data["plan"]["v120"],
            "experts": data["plan"]["expert_checkpoints"],
            "strengths": data["review-natural"]["doses"],
            "photo": planets,
            "camera": cameras,
            "plot": plot,
        },
    )
    for p in sorted(HERE.glob("*.py")):
        book[f"source/{p.name}"] = reference(p)
    for folder, files in FILES.items():
        for file in files:
            book[f"source/previous/{folder}/{file}"] = reference(HERE.with_name(folder) / file)
    for name in ("configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json"):
        book[name] = reference(ROOT / name)
    target = RESULT / "evidence.tar.xz"
    with tarfile.open(target, "x:xz", preset=4) as tar:
        for k, r in book.items():
            tar.add(checked(r), arcname=k, recursive=False)
    with tarfile.open(target) as tar:
        assert set(tar.getnames()) == book.keys()
        for k, r in book.items():
            with tar.extractfile(k) as f:
                assert file_digest(f, "sha256").hexdigest() == r["sha256"]
    write_json(
        RESULT / "publication.json",
        {
            "archive": bound(target),
            "native": bound(refs),
            "summary": bound(summary),
            "members": book,
            "scope": "Mixed-regime gate training and two source-disjoint transfers",
        },
    )
    print(bound(target), flush=True)


if __name__ == "__main__":
    main()
