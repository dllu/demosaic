"""Diagnose strength reduction on the already observed first transfer."""

from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT
from score_router import meters
from evaluate_selector import values
import score

if __name__ == "__main__":
    before = reference(OUT / "score-held.json")
    fresh = reference(OUT / "robust-calibration.json")
    data = read_json(checked(before))
    buffer = read_json(checked(fresh))["policy"]
    trials = {}
    for k, p in meters(data["rows"]).items():
        trials[k] = {"nominal": score.evaluate(values(p, "nominal", (0, 0)))}
        for name in ("plain", "stable", "fixed mix", "routed"):
            strength = buffer["arms"][name]["locked"]["dose"]
            trials[k][name] = score.evaluate(values(p, name, strength))
    print(trials, flush=True)
    write_json(
        OUT / "first-held-buffered.json",
        {
            "driver": reference(Path(__file__)),
            "first": before,
            "buffer": fresh,
            "scores": trials,
            "scope": "Already observed transfer with later strengths. The new split heads are outside this diagnostic.",
        },
    )
