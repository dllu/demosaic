"""Compare gated families at a common faint response and test the spatial intervention."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT
from confirm_router import locked_points
from score_router import meters
from evaluate_selector import values
import score


def main():
    replay = reference(OUT / "score-confirm.json")
    result = read_json(checked(replay))
    earlier = read_json(checked(result["first_policy"]))["policy"]
    ranks = locked_points(result["policy"], earlier)
    panels = meters(result["rows"])
    n = len(result["rows"])
    rng = np.random.default_rng(202611201001)
    ids = np.vstack((np.arange(n), rng.integers(0, n, (12000, n))))

    def compare(panel, first, second):
        d = [values(panel, *p) for p in (first, second)]
        scores = [score.evaluate(v) for v in d]
        batch = [
            {k: np.sqrt(np.mean(x[k][ids] ** 2, axis=1)) for k in score.LIMITS}
            | {"response_pp": 100 * x["projection"][ids].sum(axis=1) / x["true"][ids].sum(axis=1)}
            for x in d
        ]
        differences = {k: a - batch[1][k] for k, a in batch[0].items()}
        return {
            "doses": (first, second),
            "scores": scores,
            "intervals": {
                k: [float(a[0]), *np.quantile(a[1:], (0.025, 0.975)).tolist()]
                for k, a in differences.items()
            },
        }

    comparisons = [
        ("split Bayer", "routed"),
        ("split Bayer", "split rolled"),
        ("routed", "rolled"),
        ("split Bayer", "fixed mix"),
    ]
    intervention = {
        f"{a} versus {b}": {k: compare(p, ranks[a], ranks[b]) for k, p in panels.items()}
        for a, b in comparisons
    }
    equal = {}
    faint = panels["faint"]
    base = score.evaluate(values(faint, *ranks["nominal"]))["response_pp"]
    for a, b in comparisons:
        gains = {k: score.evaluate(values(faint, *ranks[k]))["response_pp"] - base for k in (a, b)}
        if min(gains.values()) <= 0:
            continue
        common = min(gains.values())
        adjusted = {
            k: (key, tuple(np.asarray(dose) * common / gains[k]))
            for k, (key, dose) in ranks.items()
            if k in gains
        }
        equal[f"{a} versus {b}"] = {
            "faint_gain": common,
            "regimes": {k: compare(p, adjusted[a], adjusted[b]) for k, p in panels.items()},
        }
    print({k: v["regimes"]["faint"]["intervals"] for k, v in equal.items()}, flush=True)
    write_json(
        OUT / "matched.json",
        {
            "driver": reference(Path(__file__)),
            "source": replay,
            "fixed_strength": intervention,
            "equal_faint_response_diagnostic": equal,
        },
    )


if __name__ == "__main__":
    main()
