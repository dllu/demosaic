"""Publish the audited local-bound replay and native comparison images."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
review = read_json(root / "review/result.json")
collection = read_json(checked(review["collection"]))
plan = read_json(checked(collection["plan"]))
assert review["verified_arrays"] == 280
assert len(review["boards"]) == 2 and len(review["camera"]) == 8
assert [
    len(read_json(checked(review["nulls"][k]["source"]))["rows"]) for k in ("retained", "fresh")
] == [36, 32]
images.mkdir()
results.mkdir()


def adopt(binding):
    source = checked(binding)
    target = images / source.name
    shutil.copyfile(source, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return target.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Ten native comparisons, two standalone triplets and one 160-pixel rail residual board inspected. "
        "Camera references are independent ISO100 AHD and JPEG images.",
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in review["boards"]
        ],
        "camera": [
            {k: v for k, v in r.items() if k != "delta_RMS_DN16"}
            | {
                "file": adopt(r["image"]),
                "CFA": "RGGB",
                "reference": "DSCF3880 ISO100 AHD"
                if r["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and both DSCF3842/DSCF3835 camera JPEGs",
            }
            for r in review["camera"]
        ],
        "rail_peak": review["rail_peak"] | {"file": adopt(review["rail_peak"]["image"])},
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "collection": review["collection"],
        "plan": collection["plan"],
        "direct_score": review["direct_scorer"],
        "verified_arrays": review["verified_arrays"],
        "results": review["results"],
        "nulls": review["nulls"],
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "delta_RMS_DN16", "checkpoint", "noise")}
            for r in review["camera"]
        ],
    },
)
members = {
    root: [
        "plan.json",
        "output/collection.json",
        "review/result.json",
        "review.py",
        "adopt.log",
        "review.log",
        "null-retained.json",
        "retained.log",
        "null-fresh.json",
        "fresh.log",
        "tests.log",
        "publish.py",
        "work/src/demosaic/surface_phase_aggregation.py",
        "work/scripts/probe_local_phase_bounds.py",
        "work/scripts/probe_surface_aggregation.py",
    ],
    root.parent / "surface-phase-aggregation-v2": ["null-replay.json", "disjoint-panel.json"],
    root.parent / "query-rail-background-v1": ["structure-replay.json"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            path = folder / name
            entry = bundle.gettarinfo(str(path), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with path.open("rb") as f:
                bundle.addfile(entry, f)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "rail_residual_viewed": 1,
        "new_checkpoint": None,
    },
)
