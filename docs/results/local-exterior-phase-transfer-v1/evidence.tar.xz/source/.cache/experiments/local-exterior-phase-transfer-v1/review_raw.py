"""Measure conditional transfer of exterior phase on the standing GFX crops."""

from pathlib import Path
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
FIXED = OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"
sys.path.insert(0, str(HERE.with_name("bayer-carrier-scale-v1")))
from carrier_scale import far_geometry, nuisance, planes

STATIONS = tuple((x, y) for y in (48, 80, 112) for x in (48, 80, 112))
SIZES = (32, 64, 128)
MODES = ("free", "far", "near", "quarter_cycle")


def unpack(values):
    _, h, w = values.shape
    output = np.empty((2*h, 2*w), dtype=values.dtype)
    for phase, plane in enumerate(values):
        y, x = divmod(phase, 2)
        output[y::2, x::2] = plane
    return output


def box_wave(box, origin, frequencies):
    x, y, n = box
    gy, gx = np.indices((n, n), dtype=np.float64)
    gx += x - origin[0]
    gy += y - origin[1]
    f = np.asarray(frequencies)
    angle = 2 * np.pi * (gx[..., None] * f[:, 0] + gy[..., None] * f[:, 1])
    return np.stack((np.cos(angle), np.sin(angle)), axis=-1)


def crop(raw, box):
    x, y, n = box
    a = raw[y:y+n, x:x+n]
    if a.shape != (n, n):
        raise ValueError(f"Context does not cover {box} in {raw.shape}")
    return a


def donor_coefficients(raw, layout, box, origin, frequency):
    y = crop(raw, box)
    size = box[2]
    waves = box_wave(box, origin, frequency)
    joined = np.concatenate((nuisance(size, "cosine"), waves.reshape(size, size, 4)), axis=-1)
    estimates = []
    for a, b in planes(layout, box):
        x = joined[a::2, b::2].reshape(-1, joined.shape[-1])
        data = y[a::2, b::2].ravel()
        fit = np.linalg.lstsq(x, data, rcond=1e-8)[0][-4:].reshape(2, 2)
        estimates.append(fit[:, 0] + 1j * fit[:, 1])
    return np.mean(estimates, axis=0)


def angles_between(a, b):
    return np.degrees(np.angle(a * np.conj(b))).tolist()


def make_fits(raw, layout, roi):
    frequency, far, nominations = far_geometry(raw, layout, roi)
    x, y, size = roi
    origin = x + (size - 1) / 2, y + (size - 1) / 2
    n = 64
    middle = (size - n) // 2
    near = [(x-n, y+middle, n), (x+size, y+middle, n), (x+middle, y-n, n), (x+middle, y+size, n)]
    bank = {
        name: np.stack([donor_coefficients(raw, layout, b, origin, frequency) for b in boxes])
        for name, boxes in (("far", far), ("near", near))
    }
    pooled = {k: v.mean(axis=0) for k, v in bank.items()}
    receipt = {
        "frequency_xy": frequency, "origin_xy": origin, "far_nomination_boxes": far,
        "separate_nomination_frequencies": nominations, "near_phase_boxes": near,
        "donor_signed_phase_degrees": {k: np.degrees(np.angle(v)).tolist() for k, v in bank.items()},
        "donor_amplitude_DN16": {k: (abs(v) * 65535).tolist() for k, v in bank.items()},
        "opposite_pair_phase_difference_degrees": {k: angles_between(v[:2].mean(0), v[2:].mean(0)) for k, v in bank.items()},
        "near_minus_far_phase_degrees": angles_between(pooled["near"], pooled["far"]),
    }
    return frequency, origin, pooled, receipt


def least_squares(a, y):
    gram = a.T @ a
    return np.linalg.solve(gram, a.T @ y)


def trial(raw, layout, box, frequency, center, fixed):
    n = box[-1]
    image = crop(raw, box).astype(np.float64)
    waves = box_wave(box, center, frequency)
    basis = nuisance(n, "cosine")
    output = {name: [] for name in MODES}
    query_complex = []
    for train, hold in (planes(layout, box), planes(layout, box)[::-1]):
        select = lambda q, coords: q[coords[0]::2, coords[1]::2]
        a_rgb, b_rgb = (select(image, lattice).ravel() for lattice in (train, hold))
        fitted = []
        for d in range(2):
            rival = 1 - d
            matrix = np.concatenate((basis, waves[..., rival, :]), axis=-1)
            qa, qb = (select(matrix, lattice).reshape(-1, matrix.shape[-1]) for lattice in (train, hold))
            baseline = least_squares(qa, a_rgb)
            residual = b_rgb - qb @ baseline
            a, b = (select(waves[..., d, :], lattice).reshape(-1, 2) for lattice in (train, hold))
            adjusted = np.linalg.solve(qa.T @ qa, qa.T @ a)
            da, db = a - qa @ adjusted, b - qb @ adjusted
            coeff = least_squares(da, a_rgb - qa @ baseline)
            fitted.append(complex(*coeff))
            preds = {"free": db @ coeff}
            for name in ("far", "near", "quarter_cycle"):
                v = fixed["near" if name == "quarter_cycle" else name][d]
                angle = np.angle(v) + (np.pi / 2 if name == "quarter_cycle" else 0)
                unit = np.array([np.cos(angle), np.sin(angle)])
                w = da @ unit
                fit = max(0., float(w @ (a_rgb - qa @ baseline) / (w @ w)))
                preds[name] = fit * (db @ unit)
            for mode, estimate in preds.items():
                if d == 0:
                    output[mode].append([])
                amount = float(2 * residual @ estimate - estimate @ estimate)
                output[mode][-1].append(amount)
        query_complex.append(np.array(fitted))
    return {
        "box": box,
        "raw_error_reduction": output,
        "query_minus_near_phase_degrees": [angles_between(z, fixed["near"]) for z in query_complex],
        "query_minus_far_phase_degrees": [angles_between(z, fixed["far"]) for z in query_complex],
       "query_amplitude_DN16": [(abs(z) * 65535).tolist() for z in query_complex],
        "levels": [float(np.mean(select(image, coord))) for coord in planes(layout, box)],
    }


def build(record):
    groups = {}
    for row in record["standing"]:
        aperture = tuple(row["local_ROI"][:3])
        identity = str(tuple(row["global_ROI"]))
        same = groups.setdefault(identity, {"region": row["id"], "ROI_xywh": row["global_ROI"],
                                         "input_bindings": [], "profiles": {}})
        with np.load(checked(row["input"]), allow_pickle=False) as array:
            raw = unpack(array["packed"][0])
            colors = array["colors"][0]
        if "hash_addressed_input" not in same:
            same["hash_addressed_input"] = row["input"]
            same["raw_capture"] = row["raw"]
            same["sensor_box"] = row["sensor_box"]
            same["geometry"] = aperture
            same["raw"] = raw
            same["colors"] = colors
        else:
            np.testing.assert_array_equal(raw, same["raw"])
            np.testing.assert_array_equal(colors, same["colors"])
            assert row["sensor_box"] == same["sensor_box"]
        profile = "transferred" if row["id"].startswith("mesh-profile3879") else "nominal"
        same["profiles"][profile] = {k: row["noise"][k] for k in ("shot", "read")}
        same["input_bindings"].append(row["input"])
    assert len(groups) == 6
    return list(groups.values())


def check(group):
    raw, layout = group.pop("raw"), group.pop("colors")
    roi = group["geometry"]
    f, origin, fixed, terms = make_fits(raw, layout, roi)
    fields = {}
    for n in SIZES:
        stations = ((80, 80),) if n == 128 else STATIONS
        result = []
        for px, py in stations:
            box = roi[0] + px - n // 2, roi[1] + py - n // 2, n
            item = trial(raw, layout, box, f, origin, fixed)
            scores = np.stack([item["raw_error_reduction"][k] for k in MODES])
            weighted = {}
            for name, profile in group["profiles"].items():
                var = np.maximum(np.asarray(item["levels"]), 0.) * profile["shot"] + profile["read"]
                standardized = scores / var[None, :, None]
                assert np.isfinite(standardized).all()
                weighted[name] = dict(zip(MODES, standardized.tolist(), strict=True))
            result.append(item | {"profiles": weighted})
        fields[str(n)] = result
    return group | {"candidate_geometry": terms, "fields": fields}


def independence(fixture):
    raw, layout = fixture["raw"], fixture["colors"]
    x, y, w = fixture["geometry"]
    old = make_fits(raw, layout, (x, y, w))
    altered = raw.copy()
    altered[y:y+w, x:x+w] += .02
    new = make_fits(altered, layout, (x, y, w))
    assert old[0] == new[0] and old[1] == new[1] and old[3] == new[3]
    for k in old[2]:
        np.testing.assert_array_equal(new[2][k], old[2][k])


def main():
    reference_fit = reference(FIXED)
    original = read_json(checked(reference_fit))
    groups = build(original)
    started = time.monotonic()
    independence(next(r for r in groups if r["region"].startswith("mesh")))
    rows = [check(fixture) for fixture in groups]
    OUT.mkdir(exist_ok=True)
    write_json(OUT / "standing.json", {
        "driver": reference(__file__), "fixed_review": reference_fit,
        "nomination": reference(Path(sys.modules[far_geometry.__module__].__file__)),
        "scope": "Guide frequencies and phase from disjoint exterior Bayer; local phase-fit control and held-green validation; no rendered correction",
        "independence_check": "Perturbing all pixels of a cab query preserves both exterior banks and frequency nominations",
        "results": rows, "seconds": time.monotonic() - started,
    })
    for item in nice(rows):
        print(*item, flush=True)


def nice(rows):
    for m in rows:
        for p in m["profiles"]:
            summary = []
            for n, fields in m["fields"].items():
                named = []
                for k in MODES:
                    val = np.array([row["profiles"][p][k] for row in fields])
                    named.append((k, ((val > 6).all(1)).sum(0).tolist(),
                                  np.round(np.median(val.sum(1), 0), 1).tolist()))
                summary.append((n, named))
            yield m["region"], p, np.round(m["candidate_geometry"]["near_minus_far_phase_degrees"], 1), summary


if __name__ == "__main__":
    main()
