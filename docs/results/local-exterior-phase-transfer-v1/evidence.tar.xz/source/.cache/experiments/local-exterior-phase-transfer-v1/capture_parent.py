"""Cache the IEEE FP32 Local 50k predictions on the two locked optical panels."""

from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("local-optical-mixture-v1")))
from prepare_optical import ROOT as OPTICAL_WORK
from review_optical import arrays, bind_models, bindings, run_model

DOSE = "0.85"
MODEL = "local50k"


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    plan_ref = reference(OPTICAL_WORK / "plan.json")
    plan = read_json(checked(plan_ref))
    panel, checkpoints = bindings(plan)
    checkpoint = checkpoints[MODEL]
    model = bind_models({MODEL: checkpoint})[MODEL]
    location = OUT / "parent"
    location.mkdir(parents=True)
    began = time.monotonic()
    output = {}
    with ieee_fp32():
        for name, (owned, profile, fixtures) in panel.items():
            group = []
            for photo in fixtures:
                fixture = photo["inputs"][DOSE]
                key = photo["id"]
                values = run_model(model, MODEL, arrays(fixture), profile)
                assert values.shape == (4, 3, 256, 256) and np.isfinite(values).all()
                file = location / f"{key}.npy"
                with file.open("xb") as stream:
                    np.save(stream, values, allow_pickle=False)
                group.append({"case": photo, "input": fixture, "output": reference(file)})
                if len(group) % 8 == 0:
                    print("Bound Local 50k", name, len(group), flush=True)
            output[name] = {"source": owned, "profile": profile, "rows": group}
    assert {k: len(v["rows"]) for k, v in output.items()} == {"confirmation": 24, "previous": 32}
    write_json(location / "result.json", {
        "source_plan": plan_ref, "driver": reference(__file__), "checkpoint": checkpoint, "dose": DOSE,
        "precision": "CUDA IEEE FP32 EMA", "panels": output, "seconds": time.monotonic() - began,
    })


if __name__ == "__main__":
    main()
