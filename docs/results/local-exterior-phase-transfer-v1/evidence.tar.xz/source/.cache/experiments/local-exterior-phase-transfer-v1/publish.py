"""Bind the disjoint RAW measurements, restoration scores and viewed native assets."""

from pathlib import Path
import shutil
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_raw import HERE, OUT

REPO = HERE.parents[2]
DEST = REPO / "docs/results" / OUT.name
ASSETS = REPO / "docs/assets" / OUT.name


def main():
    raw_ref = reference(OUT / "standing.json")
    raw = read_json(checked(raw_ref))
    result_ref = reference(OUT / "ring/result.json")
    result = read_json(checked(result_ref))
    assert len(raw["results"]) == 6 and len(result["standing"]["rows"]) == 8
    assert raw["fixed_review"] == result["standing"]["fixed_review"]
    assert len(result["exact"]["previous"]["rows"]) == 32
    confirm = result["exact"]["confirmation"]
    assert len(confirm["rows"]) == 24
    selected = result["matched_recovery_ring_minus_local64"]
    assert selected["fit"]["calibrated"] and selected["dose_pixels"] == .85
    assert selected["confirmation_ids"] == [r["id"] for r in confirm["rows"]]
    for row in result["standing"]["rows"]:
        if row["id"].startswith(("main-overcast", "main-building", "main-foliage")):
            assert all(v == 0.0 for v in row["RGB_RMS_DN16"].values())
    native = [entry["image"] for r in result["standing"]["rows"] for entry in r["native"]]
    length = len(native)
    assert length == 12
    native.extend(r["native"][kind]["image"] for r in confirm["rows"] if "native" in r
                  for kind in ("triplet", "board"))
    assert len(native) == 16
    ASSETS.mkdir()
    DEST.mkdir()
    files = []
    for item in native:
        image = checked(item)
        target = ASSETS / image.name
        shutil.copyfile(image, target)
        assert reference(target)["sha256"] == item["sha256"]
        files.append({"repo_path": str(target.relative_to(REPO)), "sha256": item["sha256"]})
    archive = DEST / "evidence.tar.xz"
    parent = read_json(checked(result["parent_replay"]))
    with tarfile.open(archive, "x:xz") as tar:
        for key, item in (("standing.json", raw_ref), ("ring/result.json", result_ref),
                          ("parents.json", result["parent_replay"])):
            tar.add(checked(item), arcname=f"receipts/{key}", recursive=False)
        for item in (reference(__file__), raw["driver"], result["driver"], result["implementation"],
                     raw["nomination"], parent["driver"], reference(REPO / "src/demosaic/mesh_carrier_fit.py")):
            path = checked(item)
            tar.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
    write_json(DEST / "publication.json", {
        "scope": "Inference-only crop component on the frozen Local 50k EMA. Prior-bound 32-case calibration and 24-case confirmation.",
        "raw_standing": raw_ref, "correction": result_ref, "parent_checkpoint": result["parent_checkpoint"],
        "precision": parent["precision"], "parent_replay_wall_s": parent["seconds"],
        "correction_review_wall_s": result["seconds"], "archive": {
            "repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"],
        },
        "confirmation_scores": confirm["summary"],
        "matched_recovery": selected,
        "standing_native_images_inspected": length,
        "exact_triplets_inspected": 2,
        "images": files,
    })
    print("Published 56 optical sources, six RAW regions and 16 native figures.", flush=True)


if __name__ == "__main__":
    main()
