"""Score the original delivery scale, same-quiet comparisons and native crops."""

import importlib.util
from pathlib import Path

import numpy as np
from probe_matched_query_evidence import MODES, output_key
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
FORMER = ROOT.parent / "affinity-first-fresh-v3/review.py"
spec = importlib.util.spec_from_file_location("existing_direct_scorer", FORMER)
score = importlib.util.module_from_spec(spec)
spec.loader.exec_module(score)


def summarize(rows, plan, out):
    moments, verified, role0, boards = [], 0, [], []
    guides = plan["synthetic_guides"]
    all_arms = ["parent", *(output_key(g, m, t) for g in guides for m in MODES for t in (0, 1))]
    for row in rows:
        case = read_json(checked(row["case"]))
        parents, truth, quiet, pred = score.load(case | {"prediction": row["prediction"]})
        with np.load(checked(row["previous_prediction"])) as saved:
            for current, old in (
                ("parent", "parent"),
                ("fixed-weighted-refit", "parallel"),
                ("scene-weighted-refit", "window_scene"),
            ):
                np.testing.assert_array_equal(pred[current], saved[old])
                verified += 1
        moments.append(
            (case["profile"], {arm: measure(parents, truth, quiet, pred[arm]) for arm in all_arms})
        )
        background = row["roles"][0]["fits"]
        noise_only = {}
        for arm in all_arms[1:]:
            p = pred[arm][0]
            delta = (p.astype(float) - pred["parent"][0]) * 65535
            noise_only[arm] = {
                "changed_pixels_native160": int(
                    np.any(delta[:, 48:208, 48:208] != 0, axis=0).sum()
                ),
                "correction_RMS_quiet_DN16": float(np.sqrt(np.mean(delta[:, quiet] ** 2))),
            }
        role0.append(
            {
                "id": row["id"],
                "profile": case["profile"],
                "active_guides": {name: value["active"] for name, value in background.items()},
                "noise_only": noise_only,
            }
        )
        if case["profile"] != "iso400" or case["source"] not in (88, 89):
            continue
        with np.load(checked(case["sensor"])) as a:
            ctx = {name: a[name][2:3] for name in ("colors", "wb", "matrix")}
            ctx["packed"] = a["packed"][2:3, :, 64:192, 64:192]
        setting = plan["settings"][case["profile"]]
        alpha = setting["scale"]
        arms = [
            "fixed-weighted-refit",
            "fixed-orthogonal-refit",
            "scene-weighted-refit",
            "scene-matched-refit",
            "scene-orthogonal-refit",
            "exact-center-weighted-refit",
            "exact-center-orthogonal-refit",
        ]
        labels = [
            "Noisy Malvar",
            "V143 EMA",
            "Fixed predictive",
            "Fixed orthogonal",
            "Scene predictive",
            "Scene matched",
            "Scene orthogonal",
            "Exact center predictive",
            "Exact center orthogonal",
            "Exact GT",
        ]
        parent = parents[2][ROI]
        pixels = [
            noisy_malvar(ctx)[0],
            parent,
            *(parent + alpha * (pred[k][2] - parent) for k in arms),
            truth[2][ROI],
        ]
        boards.append(
            native_board(
                out,
                case["id"],
                pixels,
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": case["CFA"],
                    "noise": case["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": setting,
                },
                labels=labels,
                triplet_indices=(0, 6, 9),
                contrast=5,
            )
        )
    aggregate = []
    for profile, setting in plan["settings"].items():
        scale = setting["scale"]
        group = [m for p, m in moments if p == profile]
        means = {
            arm: {k: np.mean([r[arm][k] for r in group], axis=0) for k in group[0][arm]}
            for arm in all_arms
        }
        fixed = {arm: evaluated(v, scale) for arm, v in means.items()}
        for guide in guides:
            selected = ["parent", *(output_key(guide, m, t) for m in MODES for t in (0, 1))]
            # Match each score against the original deployment threshold's actual quiet error.
            # Keep all arms within the previously declared maximum scale.
            parent_rms = fixed["parent"]["quiet_RMS_DN16"]
            limit = max(parent_rms, fixed[output_key(guide, "weighted-refit", 0)]["quiet_RMS_DN16"])
            budget = limit - parent_rms
            matched = {}
            for arm in selected:
                alpha = min(scale, scale_at_budget(means[arm]["quiet_mse"], budget))
                matched[arm] = evaluated(means[arm], alpha) | {"scale": alpha}
                assert matched[arm]["quiet_RMS_DN16"] <= limit + 2e-9
            aggregate.append(
                {
                    "profile": profile,
                    "guide": guide,
                    "count": len(group),
                    "quiet_ceiling": limit,
                    "fixed": {arm: fixed[arm] for arm in selected},
                    "matched": matched,
                }
            )
    # Check each delivery independently of the polynomial reduction.
    direct = []
    for row in rows:
        case = read_json(checked(row["case"]))
        parent, truth, quiet, predictions = score.load(case | {"prediction": row["prediction"]})
        local = []
        for item in aggregate:
            if item["profile"] != case["profile"]:
                continue
            for arm, m in item["matched"].items():
                record = score.direct(parent, truth, quiet, predictions[arm], m["scale"])
                expected = evaluated(measure(parent, truth, quiet, predictions[arm]), m["scale"])
                for key, value in record.items():
                    if key == "background_quiet_mse":
                        continue
                    want = np.sqrt(value) if key.endswith("_mse") else value
                    np.testing.assert_allclose(
                        want, expected[key.replace("_mse", "_RMS_DN16")], atol=2e-9, rtol=2e-9
                    )
                local.append(arm)
        direct.append({"id": row["id"], "tested": local})
    return aggregate, role0, boards, verified, direct


def real(rows, plan, out):
    sources = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    titles = {
        "scene-weighted-refit": "Scene predictive",
        "scene-matched-refit": "Scene matched",
        "scene-orthogonal-refit": "Scene orthogonal",
        "scene-orthogonal-refit-strict": "Scene strict",
        "spectral-weighted-refit": "Spectra predictive",
        "spectral-orthogonal-refit": "Spectra orthogonal",
        "spectral-orthogonal-refit-strict": "Spectra strict",
    }
    answer = []
    for camera, row in zip(sources, rows, strict=True):
        key, source = camera["id"], camera["source"]
        assert key == row["id"]
        x, y, w, h = camera["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            variants = dict(f)
        with np.load(checked(row["previous_predictions"])) as f:
            for field, old in (
                ("parent", "parent"),
                ("scene-weighted-refit", "window_scene"),
                ("spectral-weighted-refit", "window_spectral"),
            ):
                np.testing.assert_array_equal(variants[field], f[old])
        with np.load(checked(source["query_arrays"])) as a:
            ctx = {key: a[key] for key in ("wb", "matrix")}
        exposure = camera["display_exposure"]
        added = []
        for k, label in titles.items():
            rendered = display(variants[k][None], ctx, exposure=exposure)[0][region]
            added.append((label, np.rint(rendered.transpose(1, 2, 0) * 255).astype(np.uint8)))
        remain = [
            p
            for p in camera["panels"]
            if p["label"] in {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"} or "JPEG" in p["label"]
        ]
        image, panels = insert_camera_panels(
            out, key, camera | {"panels": remain}, "V120 EMA", added
        )
        distances = {
            a: {
                "parent_RMS_DN16": float(
                    np.sqrt(
                        np.mean((values[region].astype(float) - variants["parent"][region]) ** 2)
                    )
                    * 65535
                ),
                "same_guide_predictive_RMS_DN16": float(
                    np.sqrt(
                        np.mean(
                            (
                                values[region].astype(float)
                                - variants[a.split("-")[0] + "-weighted-refit"][region]
                            )
                            ** 2
                        )
                    )
                    * 65535
                ),
            }
            for a, values in variants.items()
            if a != "parent"
        }
        ox, oy, *_ = source["absolute_query_xywh"]
        image_row = {
            "id": key,
            "image": image,
            "panels": panels,
            "noise": noise[key],
            "ROI_xywh": [x - qx + ox, y - qy + oy, w, h],
            "display_exposure": exposure,
            "checkpoint": source["checkpoint"],
            "calibration": source["query_arrays"],
            "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
        }
        answer.append(
            image_row
            | {"distance": distances, "fits": row["fits"], "predictions": row["predictions"]}
        )
    return answer


def main():
    collection = ROOT / "output/collection.json"
    done = read_json(collection)
    plan = read_json(checked(done["plan"]))
    out = ROOT / "review"
    out.mkdir()
    aggregates, quiet, boards, checked_arrays, direct = summarize(done["synthetic"], plan, out)
    camera = real(done["camera"], plan, out)
    write_json(
        out / "result.json",
        {
            "collection": reference(collection),
            "producer": reference(__file__),
            "direct_scorer": reference(FORMER),
            "aggregates": aggregates,
            "quiet_role0": quiet,
            "boards": boards,
            "camera": camera,
            "previous_arrays_bit_exact": checked_arrays + 3 * len(camera),
            "direct_reduction_checks": direct,
        },
    )


if __name__ == "__main__":
    main()
