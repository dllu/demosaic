"""Publish the inspected query comparisons and freeze the two replay stages."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
initial = root.parent / "matched-query-evidence-v1"
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
review = read_json(root / "review/result.json")
collection = read_json(checked(review["collection"]))
plan = read_json(checked(collection["plan"]))
early = read_json(initial / "review/result.json")
early_collection = read_json(checked(early["collection"]))
nulls = read_json(root / "structure-replay.json")
early_nulls = read_json(checked(nulls["original"]))
assert len(nulls["rows"]) == len(early_nulls["rows"]) == 36
assert len(review["boards"]) == 2 and len(review["camera"]) == 8
assert collection["restoration_calls"] == early_collection["restoration_calls"] == 0
assert early["previous_arrays_bit_exact"] == 72
assert review["retained_arrays_bit_exact"] == 408
images.mkdir()
results.mkdir()


def adopt(binding):
    source = checked(binding)
    target = images / source.name
    shutil.copyfile(source, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return target.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Ten native comparison boards and two additional triplets were inspected. "
        "Independent ISO100 AHD and camera JPEGs are qualitative references.",
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in review["boards"]
        ],
        "camera": [
            {k: v for k, v in r.items() if k != "distance_to_parent_DN16"}
            | {
                "file": adopt(r["image"]),
                "CFA": "RGGB",
                "reference": "DSCF3880 ISO100 AHD"
                if r["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and DSCF3842/DSCF3835 camera JPEGs",
            }
            for r in review["camera"]
        ],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "collection": review["collection"],
        "plan": collection["plan"],
        "CPU_wall_seconds": [early_collection["CPU_wall_seconds"], collection["CPU_wall_seconds"]],
        "direct_scorer": review["scoring_source"],
        "retained_arrays_bit_exact": review["retained_arrays_bit_exact"],
        "matched_score_stage_retained_arrays_bit_exact": early["previous_arrays_bit_exact"],
        "initial_score_changes": early["aggregates"],
        "background_comparison": review["aggregate"],
        "structure_null": {
            "source": reference(root / "structure-replay.json"),
            "seed": early_nulls["seed"],
            "scope": nulls["scope"],
            "original_count": len(early_nulls["rows"]),
            "false_changes": nulls["false_changes"],
            "paired_metrics": [
                {k: r[k] for k in ("profile", "style", "trial", "metrics", "parallel_edges")}
                for r in nulls["rows"]
            ],
        },
        "camera": [
            {k: v for k, v in r.items() if k not in ("image", "panels", "calibration")}
            for r in review["camera"]
        ],
    },
)
members = {
    root: [
        "plan.json",
        "collect.log",
        "output/collection.json",
        "review.py",
        "review/result.json",
        "structure_replay.py",
        "structure-replay.json",
        "structure-replay.log",
        "tests.log",
        "publish.py",
        "work/scripts/probe_query_background.py",
        "work/scripts/probe_matched_query_evidence.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/src/demosaic/matched_query_evidence.py",
        "work/src/demosaic/full_frame_edge.py",
        "work/src/demosaic/donor_phase_geometry.py",
    ],
    initial: [
        "plan.json",
        "collect.log",
        "output/collection.json",
        "review.py",
        "review/result.json",
        "structure_null.py",
        "structure-null.json",
        "structure-null.log",
        "tests.log",
        "work/scripts/probe_matched_query_evidence.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/src/demosaic/matched_query_evidence.py",
    ],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            path = folder / name
            entry = bundle.gettarinfo(str(path), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with path.open("rb") as blob:
                bundle.addfile(entry, blob)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
