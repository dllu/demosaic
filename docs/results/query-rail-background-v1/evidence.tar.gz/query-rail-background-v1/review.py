"""Verify retained arrays, score matched quiet levels and render native evidence."""

import importlib.util
from pathlib import Path

import numpy as np
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
INITIAL = ROOT.parent / "matched-query-evidence-v1"
SCORER = ROOT.parent / "affinity-first-fresh-v3/review.py"
spec = importlib.util.spec_from_file_location("closed_query_scorer", SCORER)
score = importlib.util.module_from_spec(spec)
spec.loader.exec_module(score)
ARMS = ("bounded", "refined", "parallel")
MODES = ("weighted-refit", "matched-refit", "orthogonal-refit")


def key(background, guide, mode, strict=False):
    return f"{'' if background == 'bounded' else background + '-'}{guide}-{mode}{'-strict' if strict else ''}"


def capped(moment, scale, cap):
    alpha = min(scale, scale_at_budget(moment["quiet_mse"], cap))
    return evaluated(moment, alpha) | {"scale": alpha}


def synthetic(rows, plan, out):
    aggregate, per_set, boards, additions, bit_exact = [], [], [], [], 0
    methods = [
        "parent",
        *(
            key(b, g, m, t)
            for b in ARMS
            for g in ("scene", "exact-center")
            for m in MODES
            for t in (False, True)
        ),
    ]
    for row in rows:
        c = read_json(checked(row["case"]))
        parents, truth, quiet, pred = score.load(c | {"prediction": row["prediction"]})
        with np.load(checked(row["old_prediction"])) as f:
            for name in f.files:
                np.testing.assert_array_equal(pred[name], f[name])
                bit_exact += 1
        values = {name: measure(parents, truth, quiet, pred[name]) for name in methods}
        per_set.append({"id": row["id"], "profile": c["profile"], "moments": values})
        background = {}
        for a in methods:
            delta = (pred[a][0].astype(float) - pred["parent"][0]) * 65535
            background[a] = {
                "correction_RMS_quiet_DN16": float(np.sqrt(np.mean(delta[:, quiet] ** 2))),
                "native_pixels_changed": int(np.any(delta[:, 48:208, 48:208] != 0, axis=0).sum()),
            }
        additions.append({"id": row["id"], "profile": c["profile"], "no_wire": background})
        if c["profile"] != "iso400" or c["source"] not in (88, 89):
            continue
        with np.load(checked(c["sensor"])) as f:
            ctx = {n: f[n][2:3] for n in ("colors", "wb", "matrix")}
            ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
        setting = plan["settings"][c["profile"]]
        alpha = setting["scale"]
        parent = parents[2][ROI]
        selections = {
            "scene-weighted-refit": "Bounded step",
            "scene-orthogonal-refit": "Bounded orthogonal",
            "refined-scene-weighted-refit": "Full step",
            "parallel-scene-weighted-refit": "Two boundaries",
            "parallel-scene-orthogonal-refit": "Two-boundary orthogonal",
            "exact-center-weighted-refit": "Exact guide bounded",
            "parallel-exact-center-weighted-refit": "Exact guide two boundaries",
        }
        pixels = [
            noisy_malvar(ctx)[0],
            parent,
            *(parent + alpha * (pred[k][2] - parent) for k in selections),
            truth[2][ROI],
        ]
        boards.append(
            native_board(
                out,
                c["id"],
                pixels,
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": c["CFA"],
                    "noise": c["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": setting,
                },
                labels=["Noisy Malvar", "V143 EMA", *selections.values(), "Exact GT"],
                triplet_indices=(0, 5, 9),
                contrast=5,
            )
        )
    for profile, setting in plan["settings"].items():
        s = [row["moments"] for row in per_set if row["profile"] == profile]
        means = {
            a: {component: np.mean([r[a][component] for r in s], axis=0) for component in s[0][a]}
            for a in s[0]
        }
        nominal = setting["scale"]
        fixed = {a: evaluated(mom, nominal) for a, mom in means.items()}
        for guide in ("scene", "exact-center"):
            shown = [
                "parent",
                *(key(b, guide, m, t) for b in ARMS for m in MODES for t in (False, True)),
            ]
            base_rms = fixed["parent"]["quiet_RMS_DN16"]
            ref_rms = fixed[key("refined", guide, "weighted-refit")]["quiet_RMS_DN16"]
            allowance = max(0, ref_rms - base_rms)
            matched = {n: capped(means[n], nominal, allowance) for n in shown}
            assert all(m["quiet_RMS_DN16"] <= base_rms + allowance + 1e-9 for m in matched.values())
            aggregate.append(
                {
                    "profile": profile,
                    "guide": guide,
                    "count": len(s),
                    "quiet_ceiling": base_rms + allowance,
                    "fixed": {a: fixed[a] for a in shown},
                    "matched": matched,
                }
            )
    return aggregate, boards, additions, bit_exact


def compare_camera(rows, plan, out):
    baseline = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    titles = {
        "scene-weighted-refit": "Bounded step",
        "scene-orthogonal-refit": "Bounded orthogonal",
        "refined-scene-weighted-refit": "Full step",
        "parallel-scene-weighted-refit": "Two boundaries",
        "parallel-scene-orthogonal-refit": "Two-boundary orthogonal",
        "spectral-weighted-refit": "Spectra bounded",
        "refined-spectral-weighted-refit": "Spectra full step",
        "parallel-spectral-weighted-refit": "Spectra two boundaries",
    }
    results, exact = [], 0
    for old, new in zip(baseline, rows, strict=True):
        uid, source = old["id"], old["source"]
        assert uid == new["id"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(new["predictions"])) as f:
            values = dict(f)
        with np.load(checked(new["old_prediction"])) as f:
            for name in f.files:
                np.testing.assert_array_equal(values[name], f[name])
                exact += 1
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {name: f[name] for name in ("wb", "matrix")}
        exposure = old["display_exposure"]
        added = [
            (
                label,
                np.rint(
                    display(values[name][None], ctx, exposure=exposure)[0][region].transpose(
                        1, 2, 0
                    )
                    * 255
                ).astype(np.uint8),
            )
            for name, label in titles.items()
        ]
        remain = [
            p
            for p in old["panels"]
            if p["label"] in {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"} or "JPEG" in p["label"]
        ]
        image, panels = insert_camera_panels(out, uid, old | {"panels": remain}, "V120 EMA", added)
        reference_parent = values["parent"][region]
        distances = {
            a: float(np.sqrt(np.mean((v[region].astype(float) - reference_parent) ** 2)) * 65535)
            for a, v in values.items()
        }
        ax, ay, *_ = source["absolute_query_xywh"]
        results.append(
            {
                "id": uid,
                "image": image,
                "panels": panels,
                "display_exposure": exposure,
                "noise": noise[uid],
                "checkpoint": source["checkpoint"],
                "ROI_xywh": [x - qx + ax, y - qy + ay, w, h],
                "calibration": source["query_arrays"],
                "prediction": new["predictions"],
                "camera_RAW": plan["photos"]["main" if uid.startswith("main-") else "mesh"],
                "distance_to_parent_DN16": distances,
                "parallel_nuisance_by_guide": {
                    g: [c["parallel_edges"] for c in data.get("records", [])]
                    for g, data in new["background_diagnostics"]["parallel"].items()
                },
            }
        )
    return results, exact


def main():
    source = ROOT / "output/collection.json"
    done = read_json(source)
    plan = read_json(checked(done["plan"]))
    out = ROOT / "review"
    out.mkdir()
    results, boards, quiet, synthetic_exact = synthetic(done["synthetic"], plan, out)
    camera, camera_exact = compare_camera(done["camera"], plan, out)
    write_json(
        out / "result.json",
        {
            "producer": reference(__file__),
            "scoring_source": reference(SCORER),
            "collection": reference(source),
            "aggregate": results,
            "boards": boards,
            "camera": camera,
            "quiet": quiet,
            "retained_arrays_bit_exact": synthetic_exact + camera_exact,
        },
    )


if __name__ == "__main__":
    main()
