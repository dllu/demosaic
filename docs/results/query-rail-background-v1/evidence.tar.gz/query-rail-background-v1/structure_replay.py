"""Repeat the exact no-wire structure controls with the two query backgrounds."""

import importlib.util
from collections import Counter
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from probe_query_background import predict

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
INITIAL = ROOT.parent / "matched-query-evidence-v1"
source_file = INITIAL / "structure_null.py"
spec = importlib.util.spec_from_file_location("recorded_structure_null", source_file)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    old_path = INITIAL / "structure-null.json"
    original = read_json(old_path)
    assert original["source"] == reference(source_file)
    plan = read_json(ROOT / "plan.json")
    cfg = LocalWaveConfig(**plan["config"])
    configs = {
        "refined": replace(cfg, edge_search="full-frame"),
        "parallel": replace(cfg, edge_search="full-frame", background="parallel_step"),
    }
    profile_index = {name: i for i, name in enumerate(plan["profiles"])}
    style_index = {name: i for i, name in enumerate(("flat", "step", "rail"))}
    rows, totals = [], Counter()
    for row in original["rows"]:
        profile, style, trial = row["profile"], row["style"], row["trial"]
        args = (profile_index[profile], style_index[style], trial)
        noise = plan["profiles"][profile]
        cfa = np.array(PATTERNS[row["CFA"]])
        truth = source.construct(style, row["angle_radians"], *row["width_shift_level_height"])
        rng = np.random.default_rng(np.random.SeedSequence([source.SEED, 1, *args]))
        raw = source.corrupt(truth, cfa, rng, noise)
        threshold = plan["settings"][profile]["threshold"]
        values, diagnostic = predict(
            truth,
            raw,
            cfa,
            {"null": {"active": [True, True], "frequencies_xy": row["guide_frequencies_xy"]}},
            noise,
            source.QUERY,
            configs,
            threshold,
        )
        metrics = dict(row["metrics"])
        for name, out in values.items():
            delta = (out[source.MEASURE].astype(float) - truth[source.MEASURE]) * 65535
            metrics[name] = {
                "RMS_DN16": float(np.sqrt(np.mean(delta**2))),
                "max_abs_DN16": float(np.max(np.abs(delta))),
                "changed_pixels": int(np.any(delta != 0, axis=0).sum()),
            }
        for name, numbers in metrics.items():
            totals[profile, style, name] += numbers["changed_pixels"] > 0
        fitted = diagnostic["parallel"]["null"]["records"][0]["parallel_edges"]
        rows.append(row | {"metrics": metrics, "parallel_edges": fitted})
        print(
            profile,
            style,
            trial,
            [
                round(metrics[name]["RMS_DN16"], 3)
                for name in (
                    "null-weighted-refit",
                    "refined-null-weighted-refit",
                    "parallel-null-weighted-refit",
                    "parallel-null-orthogonal-refit",
                )
            ],
            flush=True,
        )
    write_json(
        ROOT / "structure-replay.json",
        {
            "plan": reference(ROOT / "plan.json"),
            "producer": reference(__file__),
            "original": reference(old_path),
            "trials": original["trials"],
            "scope": original["scope"],
            "rows": rows,
            "false_changes": {" / ".join(key): val for key, val in totals.items()},
        },
    )


if __name__ == "__main__":
    main()
