"""Publish exact receipts/sources and native review without copying private RAW/weights."""
import gzip
import io
import tarfile
import shutil
from pathlib import Path
from datetime import datetime,timezone
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-control10k-review-v1'
report=read_json(root/'report/result.json');post=read_json(root/'fixed-adc-diagnostic-v1/report/result.json')
assert read_json(root/'independent-audit-v2/result.json')['status']=='passed'
assert read_json(root/'actual-native-viewing-v1.json')['actual_native_board_count']==32
out=repo/'docs/results/full-corpus-control10k-review-v1';out.mkdir()
images=repo/'docs/images/full-corpus-control10k-review-v1';images.mkdir()
manifest=[]
for row in report['boards']+report['triplets']+post['boards']:
    source=checked(row['image']);name=('fixedADC-'if row in post['boards']else'')+source.name
    dest=images/name;shutil.copyfile(source,dest);assert reference(dest)['sha256']==row['image']['sha256']
    info={**row,'image':reference(dest),'original_image':row['image']};manifest.append(info)
write_json(images/'manifest.json',{'producer':reference(__file__),'plan':reference(root/'plan.json'),
 'models':read_json(root/'plan.json')['models'],'images':manifest,'native_boards':32,'triplets':22,
 'actual_viewing':reference(root/'actual-native-viewing-v1.json'),'audit':reference(root/'independent-audit-v2/result.json'),
 'scope':'Exact original PNG bytes; no crop resizing.32 boards actually viewed,22 triplets are exact subsets. Full source/ROI/noise/display/checkpoint/reference roles retained per image. No private RAW/weights copied.'})
files=[root/'plan.json',root/'collection/result.json',root/'report/result.json',root/'report/metrics.csv',
       root/'faint-decomposition-v1/result.json',root/'fixed-adc-diagnostic-v1/result.json',root/'fixed-adc-diagnostic-v1/report/result.json',
       root/'training-prefix-v2/result.json',root/'training-prefix-v2/source-crop-resumed6001-10000.jsonl',
       root/'actual-native-viewing-v1.json',root/'independent-audit-v2/result.json']
files+=list((root/'collection').glob('case-*.json'))
files += [p for p in(root/'work').rglob('*')if p.is_file()and '__pycache__'not in p.parts]
files += [p for p in(root/'analysis-source-v1').rglob('*')if p.is_file()]
for name in ['analyze-control10k-faint-decomposition-v1','apply-control10k-fixed-adc-v1','report-control10k-fixed-adc-v1',
             'audit-control10k-training-prefix-v1','audit-control10k-training-prefix-v2','audit-control10k-review-v1','audit-control10k-review-v2',
             'seal-control10k-native-viewing-v1']:
    files += list((repo/'.cache').glob(name+'.*'))
files += [repo/'.cache/audit-control10k-review-v3.log',repo/'.cache/full-corpus-control10k-report-v1.log',
          repo/'scripts/audit_checkpoint_pilot.py',repo/'scripts/collect_full_corpus_checkpoint_review.py',repo/'scripts/report_full_corpus_checkpoint_review.py',Path(__file__).resolve()]
paths=sorted(set(p.resolve()for p in files));assert all(p.is_file()for p in paths)
archive=out/'evidence.tar.gz';index=[]
with archive.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
    for p in paths:
        data=p.read_bytes();name=str(p.relative_to(repo));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));index.append({'source':reference(p),'member':name})
with tarfile.open(archive,'r:gz')as tar:
    assert len(tar.getmembers())==len(index)
    for v in index:assert tar.extractfile(v['member']).read()==Path(v['source']['path']).read_bytes()
for src,name in [(root/'report/result.json','report.json'),(root/'faint-decomposition-v1/result.json','faint-decomposition.json'),
 (root/'fixed-adc-diagnostic-v1/report/result.json','fixed-adc-report.json'),(root/'training-prefix-v2/result.json','training-prefix.json'),
 (root/'independent-audit-v2/result.json','independent-audit.json'),(root/'actual-native-viewing-v1.json','actual-native-viewing.json')]:
    shutil.copyfile(src,out/name)
write_json(out/'publication.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),
 'archive':reference(archive),'all_archive_bytes_verified':True,'members':index,'native_manifest':reference(images/'manifest.json'),
 'training_complete':False,'10k_scoped_numerical_review_complete':True,'actual_native_viewing_complete':True,
 'scope':'Retained10k/20k midpoint EMA, not full horizon/full427/known-unseen benchmark point.110 actual observations/220 CPU root calls/110 DINO executions/110 replays. All32 native boards viewed; independent256 numeric rows+120 strata+32 native boards+22 subset triplets. Fixed ADC is an exploratory physical diagnostic, not default or training change. Training source/progress separately published; large outputs/weights/private media remain local with exact bindings. Original failures/receipts/source preserved.'})
print('Published',len(paths),'exact evidence files,54 native PNGs')
