"""Evaluate the fixed physical ADC diagnostic against both unmodified models."""
import os
from pathlib import Path

import numpy as np
from PIL import Image,ImageDraw
from report_checkpoint_pilot import statistics,pixels

from demosaic.archive_metrics import color,linear_rgb,noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

os.sched_setaffinity(0,[8,9])
root=Path('.cache/experiments/full-corpus-control10k-review-v1').resolve();plan=read_json(root/'plan.json')
collection=read_json(root/'collection/result.json');raw={read_json(checked(b))['id']:read_json(checked(b))for b in collection['records']}
diagnostic=read_json(root/'fixed-adc-diagnostic-v1/result.json');corrected={(r['id'],r['method']):r for r in diagnostic['rows']}
out=root/'fixed-adc-diagnostic-v1/report';out.mkdir();metrics=[];colors=[];boards=[];constraints=[]
for o in plan['observations']:
    if o['noise']['shot']!=0 or o['noise']['read']!=0:continue
    with np.load(checked(o['arrays']),allow_pickle=False)as data:arrays=dict(data)
    with np.load(checked(o['target']),allow_pickle=False)as data:target=data['target']
    values={v['label']:np.load(checked(v['prediction']),allow_pickle=False)for v in raw[o['id']]['variants']}
    for label in ['V120','scale-control10k']:
        name=label+'+fixedADC';values[name]=np.load(checked(corrected[o['id'],name]['prediction']),allow_pickle=False)
        maximum=0.
        for phase,channel in enumerate(arrays['colors'][0]):
            y,x=divmod(phase,2);packed=arrays['packed'][:,phase];valid=(packed>1/65535)&(packed<1-1/65535)
            error=values[name][:,channel,y::2,x::2]-packed
            maximum=max(maximum,float(np.abs(error[valid]).max(initial=0))*65535)
        constraints.append({'id':o['id'],'method':name,'maximum_valid_site_residual_DN16':maximum})
    for label,value in values.items():
        if o['kind']=='color-spot-check':
            c=color(value,arrays);colors.append({'id':o['id'],'method':label,'mean_error_max_DN16':65535*max(abs(v)for v in c['camera_RGB_mean_error']),
                                               'centered_RGB_RMS_DN16':65535*c['spatially_centered_camera_RGB_RMS']})
        else:metrics.append({'id':o['id'],'source_id':o['source_id'],'method':label,'pattern':o['pattern'],**statistics(value,target,arrays)})
    selected=o.get('pattern')=='RGGB'and o['kind']=='material'
    selected|=o['kind']=='color-spot-check'and o['pattern']==('BGGR'if o['case_id'].startswith('h030')else'RGGB')
    if not selected:continue
    roi=o['ROI_xywh'];x,y,w,h=roi
    order=[('Noisy Malvar',noisy_malvar(arrays)),('V120',values['V120']),('V120 +fixed ADC',values['V120+fixedADC']),
           ('Corpus10k',values['scale-control10k']),('10k +fixed ADC',values['scale-control10k+fixedADC']),
           ('Exact GT'if o['kind']=='color-spot-check'or o['original_case_id']in ['bark','raccoon-fur']else'Binned ref, not GT',target)]
    cells=[];clipping=[];faint=o['kind']=='material'
    anchor=linear_rgb(target,arrays)[...,y:y+h,x:x+w].mean((-2,-1),keepdims=True)if faint else None
    for label,value in order:
        if faint:
            v=(.18+20*(linear_rgb(value,arrays)-anchor))[0,:,y:y+h,x:x+w];clipping.append({'label':label,'fraction':float(np.mean((v<0)|(v>1)))})
            v=v.clip(0,1);v=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055);p=np.rint(v.transpose(1,2,0)*255).astype(np.uint8)
        else:p=pixels(value,arrays,roi,1)
        cells.append((label,p))
    image=Image.new('RGB',(8+168*len(cells),192),'#eeeeee');draw=ImageDraw.Draw(image);panels=[]
    for i,(label,p)in enumerate(cells):
        assert p.shape==(160,160,3);px=8+168*i;draw.text((px,5),label,fill='black');image.paste(Image.fromarray(p),(px,24));panels.append({'label':label,'png_xywh':[px,24,160,160]})
    path=out/(o['id']+'.png');image.save(path);reread=np.asarray(Image.open(path))
    for panel,(_,p)in zip(panels,cells,strict=True):
        px,py,pw,ph=panel['png_xywh'];np.testing.assert_array_equal(reread[py:py+ph,px:px+pw],p)
    boards.append({'id':o['id'],'image':reference(path),'panels':panels,'ROI_xywh':roi,'source':o,'models':plan['models'],
                   'display':'Common contrast20/target ROI channel anchor aroundlinear.18'if faint else'Original clipped sRGB,exposure1',
                   'clipping':clipping,'anchor':anchor.tolist()if faint else None,'reference_role':o['reference_role']})
means={m:float(np.mean([r['sRGB_PSNR']for r in metrics if r['method']==m]))for m in values}
assert len(metrics)==64 and len(colors)==32 and len(boards)==6 and len(constraints)==48
write_json(out/'result.json',{'producer':reference(__file__),'diagnostic':reference(root/'fixed-adc-diagnostic-v1/result.json'),
           'metrics':metrics,'faint_sRGB_means':means,'color_metrics':colors,'valid_site_constraints':constraints,'boards':boards,'actual_viewing':'pending',
           'scope':'All16 faint inputs and8 preselected flat colors,raw and unchanged fixed ADC correction for both parent/candidate.6 native diagnostic boards,shared display/ROI,no resizing; target used only for scores/display. This post-hoc physical check changes no training/default/checkpoint.0 new neural/GPU/RAW/noise/optimizer calls.'})
print('faint means',means)
for method in values:print('color spot',method,max(r['mean_error_max_DN16']for r in colors if r['method']==method),max(r['centered_RGB_RMS_DN16']for r in colors if r['method']==method))
print('largest corrected valid-site residual DN16',max(r['maximum_valid_site_residual_DN16']for r in constraints))
