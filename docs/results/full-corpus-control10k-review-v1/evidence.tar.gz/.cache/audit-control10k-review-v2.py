"""Independent FFT scores/strata, native cells and measured/missing-site diagnosis."""
import hashlib
import os
import sys
from pathlib import Path
import numpy as np
from PIL import Image
from audit_checkpoint_pilot import rgb,srgb,coefficients,crop
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
assert 'torch'not in sys.modules and os.environ['CUDA_VISIBLE_DEVICES']==''
os.sched_setaffinity(0,[8,9]);os.nice(10)
root=Path('.cache/experiments/full-corpus-control10k-review-v1').resolve();plan=read_json(root/'plan.json');report=read_json(root/'report/result.json')
post=read_json(root/'fixed-adc-diagnostic-v1/report/result.json');projection=read_json(root/'fixed-adc-diagnostic-v1/result.json')
collection=read_json(root/'collection/result.json');records={read_json(checked(v))['id']:read_json(checked(v))for v in collection['records']}
metrics={(r['id'],r['method']):r for r in report['metrics']};strata={(r['id'],r['method'],r['original_bin']):r for r in report['original_source_faint_strata']}
postmetrics={(r['id'],r['method']):r for r in post['metrics']};corrected={(r['id'],r['method']):r for r in projection['rows']}
boards={r['id']:r for r in report['boards']};postboards={r['id']:r for r in post['boards']}
maximum={'score_dB':0.,'band':0.,'stratum':0.};counts={'metric_rows':0,'strata':0,'native_boards':0,'native_channels':0,'flat_rows':0};missing=[]
def close(a,b,kind):
    d=float(abs(a-b));maximum[kind]=max(maximum[kind],d);np.testing.assert_allclose(a,b,rtol=1e-9,atol=1e-10)
def masks(t,means,truth):
    valid=np.array([np.all((truth[0,:,y:y+16,x:x+16]>=0)&(truth[0,:,y:y+16,x:x+16]<=1))for y in range(0,160,16)for x in range(0,160,16)])
    rms=np.linalg.norm(t,axis=1)/16;valid&=(means>=.02)&(means<=.9)&(rms>=1e-5)
    return valid,rms/np.maximum(means,1e-12)
def verify_scores(row,p,target,a,exposure=1):
    pp,tt=[v.astype(np.float64)*exposure for v in [p,target]]
    x,y=[v[...,48:208,48:208]for v in [pp,tt]]
    for name,v in [('camera_RGB_PSNR',np.mean((x.clip(0,1)-y.clip(0,1))**2)),('sRGB_PSNR',np.mean((srgb(rgb(x,a))-srgb(rgb(y,a)))**2))]:close(row[name],-10*np.log10(max(v,1e-12)),'score_dB')
    t,means,truth=coefficients(tt,a);q,_,_=coefficients(pp,a);valid,contrast=masks(t,means,truth)
    actual=[]
    for i,(lo,hi)in enumerate(zip([0,.02,.05,.1,.2],[.02,.05,.1,.2,np.inf],strict=True)):
        select=valid&(contrast>=lo)&(contrast<hi)
        if not select.any():continue
        z,b=q[select],t[select];gain=np.sum(z*b)/np.sum(b*b);n=int(select.sum())
        actual.append({'bin':i,'blocks':n,'gain':gain,'band_error_RMS':np.linalg.norm(z-b)/np.sqrt(n*256),'orthogonal_residual_RMS':np.linalg.norm(z-gain*b)/np.sqrt(n*256)})
    assert len(actual)==len(row['bands'])
    for x,y in zip(actual,row['bands'],strict=True):
        assert x['bin']==y['bin']and x['blocks']==y['blocks']
        for k in ['gain','band_error_RMS','orthogonal_residual_RMS']:close(x[k],y[k],'band')
    counts['metric_rows']+=1

def verify_board(board,cells):
    img=np.asarray(Image.open(checked(board['image'])))
    assert len(cells)==len(board['panels'])
    for p,cell in zip(board['panels'],cells,strict=True):
        x,y,w,h=p['png_xywh'];assert(w,h)==(160,160)
        np.testing.assert_array_equal(img[y:y+h,x:x+w],cell,err_msg=board['id']+' '+p['label']);counts['native_channels']+=cell.size
    counts['native_boards']+=1

def enhanced(value,a,target,roi,exposure):
    x,y,w,h=roi;anchor=rgb(target.astype(np.float64)*exposure,a)[...,y:y+h,x:x+w].mean((-2,-1),keepdims=True)
    mapped=.18+20*(rgb(value.astype(np.float64)*exposure,a)-anchor)
    return np.rint(srgb(mapped)[0,:,y:y+h,x:x+w].transpose(1,2,0)*255).astype(np.uint8)

for o in plan['observations']:
    with np.load(checked(o['arrays']),allow_pickle=False)as f:a=dict(f)
    values={r['label']:np.load(checked(r['prediction']),allow_pickle=False)for r in records[o['id']]['variants']}
    target=None
    if o['kind']in ['material','shadow-material','color-spot-check']:
        with np.load(checked(o['target']),allow_pickle=False)as f:target=f['target']
    if o['kind']in ['material','shadow-material']:
        for label,p in values.items():
            verify_scores(metrics[o['id'],label],p,target,a,o['display_exposure'])
            if 'contrast0p025-adc'in o['case_id']:
                with np.load(checked(o['case']['original_target']),allow_pickle=False)as f:original=f['target']
                t,mean,truth=coefficients(original,a);valid,contrast=masks(t,mean,truth)
                pc,_,_=coefficients(p,a);tc,_,_=coefficients(target,a)
                for i,(lo,hi)in enumerate(zip([0,.02,.05,.1,.2],[.02,.05,.1,.2,np.inf],strict=True)):
                    select=valid&(contrast>=lo)&(contrast<hi)
                    if not select.any():continue
                    r=strata[o['id'],label,i];assert r['blocks']==int(select.sum())and r['mask_sha256']==hashlib.sha256(select.tobytes()).hexdigest()
                    z,b=pc[select],tc[select];close(r['gain'],np.sum(z*b)/np.sum(b*b),'stratum');close(r['relative_band_error'],np.linalg.norm(z-b)/np.linalg.norm(b),'stratum');counts['strata']+=1
    if o['id']in boards:
        roi=o['ROI_xywh'];exposure=o['display_exposure']
        if o['kind']=='gfx':target=np.load(checked(o['target']),allow_pickle=False);reference_cell=crop(target,a,[0,0,160,160],exposure)
        else:reference_cell=crop(target,a,roi,exposure)
        cells=[crop(noisy_malvar(a),a,roi,exposure),*[crop(v,a,roi,exposure)for v in values.values()],reference_cell]
        verify_board(boards[o['id']],cells)
        if o['id']+'-contrast20'in boards:
            verify_board(boards[o['id']+'-contrast20'],[enhanced(v,a,target,roi,exposure)for v in [noisy_malvar(a),*values.values(),target]])
    if o['kind']=='mesh':
        for case in o['cases']:
            roi=case['ROI_xywh'];e=o['display_exposure'];key=o['id']+'-'+case['name']
            cells=[crop(a['noisy_rgb'],a,roi,e),*[crop(v,a,roi,e)for v in values.values()],crop(a['reference_rgb'],a,roi,e)]
            cells += [np.load(checked(case['camera_JPEGs'][k]['pixels']),allow_pickle=False)for k in ['noisy_camera_jpeg','reference_camera_jpeg']]
            verify_board(boards[key],cells)
    if o['noise']['shot']==o['noise']['read']==0:
        for label in ['V120','scale-control10k']:values[label+'+fixedADC']=np.load(checked(corrected[o['id'],label+'+fixedADC']['prediction']),allow_pickle=False)
        if o['kind']=='material':
            for label,p in values.items():
                verify_scores(postmetrics[o['id'],label],p,target,a)
                if label.endswith('+fixedADC'):
                    mask=np.zeros_like(p,dtype=bool)
                    for phase,c in enumerate(a['colors'][0]):
                        y,x=divmod(phase,2);packed=a['packed'][:,phase];valid=(packed>1/65535)&(packed<1-1/65535)
                        np.testing.assert_array_equal(p[:,c,y::2,x::2][valid],packed[valid]);mask[:,c,y::2,x::2]=valid
                    roi=(...,slice(48,208),slice(48,208));err=(p.astype(np.float64)-target.astype(np.float64))[roi]**2;m=mask[roi]
                    missing.append({'id':o['id'],'method':label,'measured_count':int(m.sum()),'missing_count':int((~m).sum()),'measured_MSE':float(err[m].mean()),'missing_MSE':float(err[~m].mean()),'full_MSE':float(err.mean())})
        if o['id']in postboards:
            roi=o['ROI_xywh'];order=[noisy_malvar(a),values['V120'],values['V120+fixedADC'],values['scale-control10k'],values['scale-control10k+fixedADC'],target]
            cells=[enhanced(v,a,target,roi,1)if o['kind']=='material'else crop(v,a,roi,1)for v in order]
            verify_board(postboards[o['id']],cells)
    if o['kind']=='color-spot-check':
        for label,p in values.items():
            e=(p-target).astype(np.float64)[...,48:208,48:208];mean=e.mean((0,2,3));rms=np.sqrt(np.mean((e-mean[None,:,None,None])**2))
            rows=post['color_metrics']if label.endswith('+fixedADC')else report['ADC_color_spot_checks']
            r=next(r for r in rows if r['id']==o['id']and r['method']==label)
            close(max(abs(mean))*65535,r.get('maximum_absolute_mean_error_DN16',r.get('mean_error_max_DN16')),'band');close(rms*65535,r.get('centered_RGB_RMS_DN16'),'band');counts['flat_rows']+=1
for r in report['triplets']:
    b=boards[r['id'].removesuffix('-triplet')];img=np.asarray(Image.open(checked(r['image'])));base=np.asarray(Image.open(checked(b['image'])))
    for panel,index in zip(r['panels'],[0,2,3],strict=True):
        x,y,w,h=panel['png_xywh'];bx,by,bw,bh=b['panels'][index]['png_xywh'];np.testing.assert_array_equal(img[y:y+h,x:x+w],base[by:by+bh,bx:bx+bw])
assert counts['metric_rows']==256 and counts['strata']==120 and counts['native_boards']==32 and counts['flat_rows']==32
summary={}
for label in ['V120+fixedADC','scale-control10k+fixedADC']:
    rows=[r for r in missing if r['method']==label];summary[label]={k:float(np.mean([r[k]for r in rows]))for k in ['measured_MSE','missing_MSE','full_MSE']}
assert summary['V120+fixedADC']['measured_MSE']==summary['scale-control10k+fixedADC']['measured_MSE']
out=root/'independent-audit-v2';out.mkdir()
write_json(out/'result.json',{'auditor':reference(__file__),'helper':reference('scripts/audit_checkpoint_pilot.py'),'report':reference(root/'report/result.json'),'counts':counts,'maximum_discrepancies':maximum,'all22_triplets_exact_board_subsets':True,'fixed_ADC_measured_missing_camera_RGB':missing,'fixed_ADC_summary':summary,'status':'passed','scope':'Independent channel sums/mirrored-FFT DCT and masks;192 raw+64 physical diagnostic metric rows,120 original strata,32 boards all native cells,22 triplet subsets,32 raw/projected flat rows. Exact ADC measured values and missing-site camera RGB error.0 neural/RAW/noise/optimizer work; no broad panel claim.'})
print(counts,maximum,summary)
