"""Record actual native viewing separately from numeric/render completion."""
from pathlib import Path
from datetime import datetime,timezone
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
r=Path('.cache/experiments/full-corpus-control10k-review-v1').resolve()
s=read_json(r/'report/result.json');p=read_json(r/'fixed-adc-diagnostic-v1/report/result.json')
boards=[]
for row in s['boards']:
    key=row['id']
    if key.startswith('main-'):note='Sky smooth; building and foliage remain soft; coarse chain-link geometry largely preserved. No convincing finer reconstruction versus V120.'
    elif key.startswith('mesh-'):note='Nominal largely erases fine mesh; nearby profile shows soft partial lattice with incomplete crossings. Both native ROIs/profiles and both camera JPEGs inspected; no convincing new crossings.'
    elif 'contrast20'in key:note='Shared contrast20 shows attenuated fine structures, especially fur strands; no convincing faithful recovery. Target anchor is display-only.'
    elif 'contrast0p025'in key:note='Standard display nearly uniform; weak detail requires shared enhanced display. No visible large false texture.'
    elif 'gain1over32'in key:note='Severely blurred/clumpy material detail in both models; small mean score change does not show convincing new faithful structure.'
    elif key.startswith('flat-'):note='Uniform at native 8-bit display; the small numerical centered-RMS increase is not visibly resolved here.'
    else:note='Ordinary bark/fur/grass/wood remain close to V120; fine GT/reference structures are still lost.'
    boards.append({'image':reference(checked(row['image'])),'id':key,'actual_native_viewed':True,'notes':note})
for row in p['boards']:
    boards.append({'image':reference(checked(row['image'])),'id':row['id'],'actual_native_viewed':True,
                  'notes':'Six-panel raw/fixed-ADC parent/candidate board viewed. Changes are subtle; fixed projection does not visibly recover missing fine structures. Flat boards uniform at 8-bit display.'})
assert len(boards)==32
write_json(r/'actual-native-viewing-v1.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),
 'raw_report':reference(r/'report/result.json'),'physical_diagnostic_report':reference(r/'fixed-adc-diagnostic-v1/report/result.json'),
 'boards':boards,'actual_native_board_count':32,'triplets':'22 triplets are independently verified exact subsets of these viewed boards; no separate viewing claim.',
 'scope':'All26 raw boards and6 fixed-ADC diagnostic boards actually opened at native size using view_image in this goal turn. Independent ISO100/JPEG/binned PIXLS references are not exact GT. No score or training-completion status inferred from viewing.'})
print('Sealed32 actual native reviews')
