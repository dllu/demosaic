"""Count actual10k source/crop/conditioning coverage from preserved sequential records."""
import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

base=Path('.cache/experiments/full-corpus-scaling-v3').resolve()
review=Path('.cache/experiments/full-corpus-control10k-review-v1').resolve();out=review/'training-prefix-v1';out.mkdir()
old=base/'checkpoint-stall-step6000-v1/failed-source-crop-observations.jsonl'
new=base/'checkpoint-recovery-v6/work/artifacts/train/control20k/phase-006001-020000/source-crop-observations.jsonl'
with new.open()as stream:prefix=''.join(itertools.islice(stream,4000))
snapshot=out/'source-crop-resumed6001-10000.jsonl';snapshot.open('x').write(prefix)
events=[json.loads(line)for line in old.read_text().splitlines()]+[json.loads(line)for line in prefix.splitlines()]
assert len(events)==10000 and [r['step']for r in events]==list(range(1,10001))
assert [r['global_draw_start']for r in events]==list(range(0,160000,16))
domains=Counter();photo_visits=Counter();ordinary=Counter();reviewed=Counter();kinds=Counter();crops=set()
for event in events:
    domains[event['domain']]+=1
    assert len(event['sources'])==16
    if event['domain']!='commons':continue
    for source in event['sources']:
        kinds[source['kind']]+=1
        if source['kind']!='photographic':continue
        identity=source['source_id'];photo_visits[identity]+=1
        (reviewed if source['reviewed_roi_xywh']is not None else ordinary)[identity]+=1
        crops.add((identity,tuple(source['cache_xywh'])))
assert len(ordinary)==sum(ordinary.values()),'Ordinary source repeated before first planned epoch'
conditions=[];steps=[]
for folder,low,high in [(base/'work/artifacts/train/control20k/phase-000001-020000',1,6000),
                        (new.parent,6001,10000)]:
    for path in sorted(folder.glob('conditions-*.npz')):
        with np.load(path,allow_pickle=False)as data:
            a=data['steps']
            if a[0]<low or a[-1]>high:continue
            assert data['values'].shape==(250,16,14)and np.isfinite(data['values']).all()
            steps.extend(a.tolist());conditions.append(reference(path))
assert steps==list(range(1,10001))and len(conditions)==40
train=[]
for path,step,count in [(base/'checkpoint-stall-step6000-v1/failed-03-scale-control20k.log',6000,6000),
                         (base/'production-handoff-v6/00-scale-control20k.log',10000,4000)]:
    rows=[json.loads(line)for line in path.read_text().splitlines()if line.startswith('{')]
    row=next(row for row in rows if row.get('event')=='train'and row.get('step')==step)
    train.append({'last_global_step':step,'phase_updates_in_reported_average':count,
                  'reported_seconds_per_step':row['seconds_per_step'],
                  'reported_loop_seconds':row['seconds_per_step']*count})
write_json(out/'result.json',{'producer':reference(__file__),'checkpoint':read_json(review/'plan.json')['models']['scale-control10k']['checkpoint'],
           'first6000_source_records':reference(old),'next4000_source_records':reference(snapshot),
           'source_steps':10000,'target_examples':160000,'domain_batches':dict(domains),'commons_target_kinds':dict(kinds),
           'photographic_draws':sum(photo_visits.values()),'distinct_photo_sources':len(photo_visits),
           'ordinary_photo_draws':sum(ordinary.values()),'distinct_ordinary_photo_sources':len(ordinary),
           'reviewed_photo_draws':sum(reviewed.values()),'distinct_reviewed_photo_sources':len(reviewed),
           'reviewed_fraction_of_photographic_draws':sum(reviewed.values())/sum(photo_visits.values()),
           'distinct_source_cache_crop_boxes':len(crops),'conditioning_chunks':conditions,'conditioning_steps_exact':[1,10000],
           'training_loop_observations':train,'sum_reported_loop_seconds':sum(r['reported_loop_seconds']for r in train),
           'failed_original_phase_wall_seconds_including_stall':read_json(base/'production-handoff-v2/03-scale-control20k-result.json')['seconds'],
           'timing_scope':'Trainer time.perf_counter average includes phase loop work through each last train event, before its final validation/save; no initialization/final-worker-duration receipt is invented. Original failed phase wall includes stall. Current20k horizon/worker remains active; resumed phase final duration pending. Inference timings are separate.',
           'scope':'Actual complete0→10000 prefix, old6k plus exact next4k source records, all160k global target indices consecutive, all40 physical-conditioning chunks finite/complete. Ordinary shuffled photo IDs are unique within this prefix. Broader coverage is not lifetime/backbone novelty or proof of quality. Source/cache bounding boxes precede geometry and are not independent native pixels. Full90778-source epoch and20k/100k endpoints still pending.'})
print('Actual10k coverage',dict(domains),'photo draws',sum(photo_visits.values()),'photo IDs',len(photo_visits),'ordinary IDs',len(ordinary),'reviewed fraction',sum(reviewed.values())/sum(photo_visits.values()))
