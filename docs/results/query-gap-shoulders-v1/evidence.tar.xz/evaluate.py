"""Evaluate the frozen shoulder and off-grid geometry policies with exact RGB."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "query-shared-gap-v1"))
from review import CORE, fields, luma, rms
from shoulders import METHODS, PRIOR, ROOT, scan
from check import apply
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ARMS = ('parent', 'directional', 'shared', *METHODS)


def case(row, profile, output):
    fixture, earlier, base = row
    data, known = fields(fixture)
    with np.load(checked(fixture['input']),allow_pickle=False) as f:
        altered = f['rotated_packed'][...,64:192,64:192]
    predictions = {k:known[k].copy() for k in ('parent','directional','shared')}
    predictions.update({k:known['directional'].copy() for k in METHODS})
    by_control = {}
    for condition, inputs in (('matching',data['packed']),('rotated',altered)):
        native = known['directional'] if condition=='matching' else known['rotated_base']
        states = []
        for role, old in enumerate(fixture['checks'][condition]):
            result = scan(inputs[role],data['colors'][role],profile[fixture['noise']],old)
            state={}
            for arm in METHODS:
                if result:
                    opt = result[arm]
                    new = apply(known['parent'][role],native[role],opt['application'],'shared')
                    state[arm] = {k:opt[k] for k in ('candidate','test','strength')}
                else:
                    new=native[role]
                if condition=='matching':
                    predictions[arm][role] = new
                if role>0 or condition=='rotated':
                    assert np.array_equal(new,native[role]), (fixture['index'],condition,role,arm)
            states.append(state)
        by_control[condition]=states
    target = luma(data['target'],data)
    rgb = {name:luma(value,data) for name,value in predictions.items()}
    support=data['support'][CORE]
    gap=support==0
    intact=support>=.97
    if not intact.any():
        intact=np.ones_like(gap)
    exact=(target[0]-target[1])[CORE]
    gt=exact[intact]
    idea={}
    for name in ARMS:
        inc=(rgb[name][0]-rgb[name][1])[CORE]
        y=rgb[name][0][CORE]
        correction=y-rgb['parent'][0][CORE]
        idea[name]={
            'intact_response':float(100*(inc[intact]@gt)/(gt@gt)),
            'intact_increment_error':rms((inc-exact)[intact]),
            'full_increment_error':rms(inc-exact),
            'intact_edit':rms((y-rgb['directional'][0][CORE])[intact]),
            'full_error':rms(y-target[0][CORE]),
        }
        if gap.any():
            idea[name]['added_gap']=rms(correction[gap])
            idea[name]['total_gap']=rms((y-target[0][CORE])[gap])
    archives={}
    if output:
        path=output/f'{fixture["index"]:03d}-{fixture["noise"]}.npz'
        np.savez(path,**predictions)
        archives['methods']=reference(path)
    return {'index':fixture['index'],'noise':fixture['noise'],'input':fixture['input'],'upstream':fixture['output'],
            'label':base['geometry']['family'],'gap':bool(gap.any()),'metrics':idea, 'checks':by_control,
            'shared_strength':fixture['checks']['matching'][0]['cut'].get('shared',0),'archive':archives}


def summaries(rows):
    rng=np.random.default_rng(628454)
    result={}
    for noise in sorted({r['noise'] for r in rows}):
        scan=[r for r in rows if r['noise']==noise]
        sets={'gap':[r for r in scan if r['gap']],'continuous':[r for r in scan if not r['gap']]}
        per={}
        for label, subset in sets.items():
            bootstrap=rng.integers(len(subset),size=(10000,len(subset)))
            per[label]={}
            for arm in ARMS:
                a={k:np.array([r['metrics'][arm][k] for r in subset])for k in subset[0]['metrics'][arm]}
                paired={}
                for k,v in a.items():
                    delta=v-np.array([r['metrics']['shared'][k] for r in subset])
                    paired[k]=[float(delta.mean()),*np.quantile(delta[bootstrap].mean(1),[.025,.975]).tolist()]
                counts=0
                if arm in METHODS:
                    counts=sum(r['checks']['matching'][0].get(arm,{}).get('strength',0)>0 for r in subset)
                elif arm=='shared':
                    counts=sum(r['shared_strength']>0 for r in subset)
                per[label][arm]={'mean':{k:float(v.mean()) for k,v in a.items()},'delta_vs_shared':paired,'cuts':counts}
        result[noise]=per
    return result


def run(study):
    folder=ROOT if study=='new' else PRIOR
    study_tag={'new':'fresh','fresh-replay':'fresh','shape-replay':'replay'}[study]
    reference_run=reference(folder/f'{study_tag}-gap.json')
    origin=read_json(checked(reference_run))
    sources=read_json(checked(origin['observations']))
    plan=read_json(checked(sources['source']))
    files=ROOT/(study+'-arrays') if study=='new' else None
    if files is not None:
        files.mkdir()
    frozen=reference(ROOT/'shoulders.py')
    started=time.monotonic()
    with ThreadPoolExecutor(3) as executor:
        task=partial(case,profile=plan['profiles'],output=files)
        jobs=((row,sources,plan['sources'][row['index']])for row in origin['rows'])
        cases=[]
        for reviewed in executor.map(task,jobs):
            cases.append(reviewed)
            print(reviewed['index'],reviewed['noise'],round(time.monotonic()-started,1),flush=True)
    write_json(ROOT/(study+'-summary.json'),{'study':study,'upstream':reference_run,'checkpoint':origin['checkpoint'],
               'driver':reference(__file__),'fixed_policy':frozen,'cases':cases,'summary':summaries(cases),
               'controls':'Every outcome for the strong-only, flat, outside-only and rotated controls equaled the directional donor output exactly.'})


if __name__=='__main__':
    for tag in sys.argv[1:]:
        run(tag)
