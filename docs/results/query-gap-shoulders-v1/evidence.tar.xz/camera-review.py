"""Render shoulder hypotheses and prior paths in both standing camera scenes."""
import sys

import numpy as np
from PIL import Image
import torch

from shoulders import METHODS, PRIOR, ROOT, scan
from check import apply
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    binding=reference(PRIOR/'standing/manifest.json')
    previous=read_json(checked(binding))
    out=ROOT/'standing'
    out.mkdir()
    rows=[]
    for row in previous['rows']:
        key=row['id']
        left,top,w,h=row['box']
        x,y,cw,ch=row['ROI']
        box=(x-left,y-top,cw,ch)
        native=np.s_[...,box[1]:box[1]+ch,box[0]:box[0]+cw]
        with np.load(checked(row['base_input']),allow_pickle=False) as f:
            raw=f['packed'][0,:,top//2:(top+h)//2,left//2:(left+w)//2]
            cfa,wb,matrix=(f[k][0] for k in ('colors','wb','matrix'))
        with np.load(checked(row['arrays']),allow_pickle=False) as f:
            parent,before,prior=(f[k] for k in ('parent','before','shared'))
        opted=scan(raw,cfa,row['noise'],row['fit'])
        outputs={k:apply(parent,before,opted[k]['application'],'shared') if opted else before for k in METHODS}
        with Image.open(checked(row['image'])) as image:
            raster=np.asarray(image.convert('RGB'))
        previous_panels={p['name']:raster[y:y+h,x:x+w]for p in row['panels']for x,y,w,h in (p['png_xywh'],)}
        common=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Per-direction gate','Shared-wave deficit')
        panels=[(k,previous_panels[k]) for k in common if k in previous_panels]
        for name,label in zip(METHODS,('Shoulders','Off-grid shoulders','Off-grid amplitude'),strict=True):
            restored=display_crop(torch.from_numpy(outputs[name][None]),torch.from_numpy(wb[None]),
                 torch.from_numpy(matrix[None]),box,exposure=row['display_exposure'])
            panels.append((label,np.rint(restored*255).astype(np.uint8)))
        panels.extend((k,previous_panels[k]) for k in ('ISO100 AHD reference','ISO100 camera JPEG') if k in previous_panels)
        art=native_png(out/(key+'.png'),panels)
        changes={k:float(np.sqrt(np.mean((v[native]-prior[native]).astype(np.float64)**2))*65535)for k,v in outputs.items()}
        rows.append({k:row[k] for k in ('id','box','ROI','noise','display_exposure','base_input')}|art|
                    {'upstream':row['arrays'],'predecessor':row['image'],'fit':opted,'RMS_camera_RGB_to_shared_DN16':changes})
        print(key,changes,flush=True)
    write_json(out/'manifest.json',{'driver':reference(__file__),'source':binding,'checkpoint':previous['checkpoint'],'rows':rows})


if __name__=='__main__':
    main()
