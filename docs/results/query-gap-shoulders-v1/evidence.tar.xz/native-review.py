"""Render the same native pixels for the measured gap and quiet controls."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'query-shared-gap-v1'))
import check
from shoulders import METHODS, ROOT

ARMS = ('parent', 'directional', 'shared', *METHODS)
from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROI = np.s_[...,48:208,48:208]


def main(indexes, method):
    torch.set_num_threads(2)
    path=reference(ROOT/'new-summary.json')
    result=read_json(checked(path))
    plan=read_json(ROOT/'plan.json')
    dest=ROOT/'native'
    dest.mkdir()
    rows=[]
    for index in indexes:
        row=result['cases'][index]
        source=plan['sources'][index]
        assert row['index']==source['index']==index
        with np.load(checked(row['input']),allow_pickle=False) as arrays:
            data={k:arrays[k] for k in ('packed','colors','target','wb','matrix')}
        sensor=torch.from_numpy(data['packed'][...,64:192,64:192].copy())
        noisy=malvar(sensor,torch.from_numpy(data['colors'])).numpy()
        targets=data['target'][...,128:384,128:384]
        with np.load(checked(row['archive']['methods']),allow_pickle=False) as f:
            raw={name:f[name] for name in ARMS}
        views={}
        calibration={key:data[key] for key in ('wb','matrix')}
        for key,arr in (raw|{'noisy':noisy,'GT':targets}).items():
            px=display(arr[ROI],calibration,exposure=2)
            views[key]=np.rint(px.transpose(0,2,3,1)*255).astype(np.uint8)
        boards=[]
        for role,draw,order in (('triplet',0,('noisy',method,'GT')),
                 ('comparison',0,('noisy',*ARMS,'GT')),('quiet',3,('noisy',*ARMS,'GT'))):
            file=dest/f'{index:03d}-{row["noise"]}-{role}.png'
            Image.fromarray(np.concatenate([views[k][draw] for k in order],axis=1)).save(file,optimize=True)
            boards.append({'image':reference(file),'role':role,'order':order})
        rows.append({'source':source['source'],'source_box':source['box'],'CFA':source['camera']['pattern'],
                     'profile':plan['profiles'][row['noise']],'black':source['camera']['black'],'ROI':[48,48,160,160],
                     'capture':row['input'],'prediction':row['archive']['methods'],'index':index,'family':row['label'],
                     'display_exposure':2,'boards':boards,'method':method})
    write_json(dest/'manifest.json',{'driver':reference(__file__),'study':path,'checkpoint':result['checkpoint'],'rows':rows})


if __name__=='__main__':
    main([int(x) for x in sys.argv[2:]],sys.argv[1])
