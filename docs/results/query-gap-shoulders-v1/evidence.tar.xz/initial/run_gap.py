"""Apply gap localization over already admitted directional Bayer corrections."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np

from shoulders import ROOT
from check import METHODS,SHAPE,analyze,apply
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ARMS=("parent","directional",*METHODS)
NATIVE=np.s_[...,64:192,64:192]


def edit(job):
    raw,cfa,parent,before,selection,noise=job
    if not selection["state"].startswith("donor-"):
        np.testing.assert_array_equal(parent,before)
        return [before for _ in METHODS],{"cut":{},"gate":"original route rejected"}
    assert selection["geometry"]
    science=analyze(raw,cfa,noise,selection["geometry"])
    return [apply(parent,before,science,name)for name in METHODS],science


def main(tag):
    previous=reference((SHAPE if tag=="replay"else ROOT)/"results.json")
    bound=read_json(checked(previous))
    parents=read_json(checked(bound["parent_receipts"]))
    physical=read_json(checked(parents["captures"]))
    plan=read_json(checked(physical["source"]))
    output=ROOT/f"gap-{tag}"
    output.mkdir()
    log=[]
    started=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        for row in bound["rows"]:
            fields={}
            with np.load(checked(row["input"]),allow_pickle=False)as f:
                cfa=f["colors"]
                fields["matching"]=f["packed"][NATIVE]
                fields["rotated"]=f["rotated_packed"][NATIVE]
            profile=plan["profiles"][row["noise"]]
            with np.load(checked(row["prediction"]),allow_pickle=False)as f:
                parent=f["parent"]
                base={"matching":f["directional"],"rotated":f["rotated_directional"]}
            keys=("matching","rotated")
            steps=[(fields[k][role],cfa[role],parent[role],base[k][role],row["decisions"][role][k],profile)
                   for k in keys for role in range(4)]
            recovered={}
            receipts={}
            results=list(pool.map(edit,steps))
            for k,matches in zip(keys,(results[:4],results[4:]),strict=True):
                recovered[k]={name:np.stack([r[0][j]for r in matches])for j,name in enumerate(METHODS)}
                receipts[k]=[r[1] for r in matches]
            result=output/Path(row["input"]["path"]).name
            np.savez(result,parent=parent,directional=base["matching"],rotated_base=base["rotated"],
                **recovered["matching"],**{"rotated_"+k:v for k,v in recovered["rotated"].items()})
            log.append({k:row[k]for k in ("index","noise","input","prediction")}|
                        {"output":reference(result),"source_geometry":row["decisions"],"checks":receipts})
            print(row["index"],row["noise"],round(time.monotonic()-started,1),receipts["matching"][0].get("cut"),
                  flush=True)
    write_json(ROOT/f"{tag}-gap.json",{"driver":reference(__file__),"implementation":reference(ROOT/"check.py"),
             "upstream":previous,"observations":parents["captures"],"checkpoint":bound["checkpoint"],"rows":log})


if __name__=="__main__":
    main(sys.argv[1])
