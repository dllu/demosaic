"""Compare shoulder nominations with uniformly weakened edits at equal leakage."""
import numpy as np

from evaluate import ARMS, METHODS, ROOT, CORE, fields, luma, rms
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def measurements(table, value):
    score=[]
    for row in table:
        output=value(row)[0][CORE]
        recover=output-row['reference'][1][CORE]
        target=(row['target'][0]-row['target'][1])[CORE][row['intact']]
        score.append({'added_gap':rms((output-row['parent'][0][CORE])[row['gap']]),
                      'total_gap':rms((output-row['target'][0][CORE])[row['gap']]),
                      'intact_response':float(100*recover[row['intact']]@target/(target@target)),
                      'intact_edit':rms((output-row['directional'][0][CORE])[row['intact']])})
    return {k:float(np.mean([r[k] for r in score])) for k in score[0]}


def main():
    record=reference(ROOT/'new-summary.json')
    experiment=read_json(checked(record))
    history=read_json(checked(experiment['upstream']))
    rows=[]
    for row,earlier in zip(experiment['cases'],history['rows'],strict=True):
        if not row['gap']:
            continue
        data,fields_=fields(earlier)
        with np.load(checked(row['archive']['methods']),allow_pickle=False)as f:
            values={k:luma(f[k],data) for k in ARMS}
        rgb=luma(data['target'],data)
        support=data['support'][CORE]
        rows.append({'gap':support==0,'intact':support>=.97,'target':rgb,'reference':values['directional'],**values})
    def interpolation(name, scale):
        return measurements(rows,lambda r:r['directional']+scale*(r[name]-r['directional']))
    directional=interpolation('shared',0.)['added_gap']
    comparison={}
    for variant in METHODS:
        # Weaken whichever edit added less texture in the actual gap.
        primary,secondary=sorted((variant,'shared'),key=lambda z:interpolation(z,1.)['added_gap'])
        full=interpolation(secondary,1.)
        target=full['added_gap']
        lo,hi=0.,1.
        if target>directional:
            comparison[variant]={'available':False,'added_gap_target':target,'directional':directional}
            continue
        for _ in range(27):
            mid=(lo+hi)/2
            if interpolation(primary,mid)['added_gap']>target:
                lo=mid
            else:
                hi=mid
        v=(lo+hi)/2
        matched=interpolation(primary,v)
        assert abs(matched['added_gap']-target)<1e-5
        comparison[variant]={'available':True,'weakened_arm':primary,'scale':v,
                             'scores':{primary:matched,secondary:full}}
    write_json(ROOT/'strength.json',{'study':record,'driver':reference(__file__),'matched_gap':comparison,
                'scope':'Exact labels set a diagnostic scale on this panel only. Rendered outputs use the original unscaled arms.'})


if __name__=='__main__':
    main()
