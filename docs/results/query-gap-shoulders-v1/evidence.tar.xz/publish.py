"""Publish the frozen gap localization study and the native boards reviewed."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path('docs/results/query-gap-shoulders-v1')
IMAGES = Path('docs/images/query-gap-shoulders-v1')


def board(row, category, note):
    source=checked(row['image'])
    target=IMAGES/category/source.name
    target.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(source,target)
    assert reference(target)['sha256']==row['image']['sha256']
    with Image.open(target) as picture:
        if 'panels' in row:
            for p in row['panels']:
                x,y,w,h=p['png_xywh']
                assert w==h==160 and x+w<=picture.width and y+h<=picture.height
        else:
            assert picture.size==(160*len(row['order']),160)
        picture.verify()
    return row|{'image':{'path':str(target),'sha256':row['image']['sha256']},'actual_viewing':note}


def main():
    exact=read_json(ROOT/'native/manifest.json')
    audit=read_json(ROOT/'audit.json')
    standing=read_json(checked(audit['camera']))
    assert exact['checkpoint']==standing['checkpoint']
    assert exact['study']==audit['study']
    notes={16:'Repeated bright diagonals above the colored edge remain slightly stronger than with the original shared edit, which cuts a little more around the interruption.',
           20:'The off-grid shoulders make the quiet area beside the pale vertical feature slightly smoother. The surrounding fine lattice remains softer than the exact target.'}
    native=[]
    for row in exact['rows']:
        display=[board(r,'exact',notes[row['index']]if r['role']!='quiet'else 'The quiet control visually matches the donor and Corpus 100k output with no new repeating texture.')
                 for r in row['boards']]
        native.append(row|{'boards':display})
    real=[]
    for row in standing['rows']:
        kind=row['id']
        if 'sky' in kind:
            note='The overcast sky is smooth and matches the previous shared fit exactly.'
        elif 'mesh' in kind:
            note='The nominal and transferred styles retain the same faint diagonals as the previous method. Fine crossings remain incomplete, with mottling.'
        elif 'fence' in kind:
            note='Both coarse diagonal families and the yellow-green point carry over exactly.'
        else:
            note='The previous foliage or building appearance carries over exactly. Fine details remain soft.'
        real.append(board(row,'standing',note))
    assert len(native)==2 and sum(len(r['boards']) for r in native)==6 and len(real)==8
    manifest=IMAGES/'manifest.json'
    write_json(manifest,{'exact':exact|{'rows':native},'standing':standing|{'rows':real},'actual_native_viewing_complete':True})
    RESULT.mkdir(exist_ok=True,parents=True)
    key_paths=('new-summary.json','fresh-replay-summary.json','shape-replay-summary.json','strength.json','audit.json','color-information.json','color-discovery.json')
    papers={Path(p).stem:reference(ROOT/p) for p in key_paths}
    training=read_json(checked(papers['audit']))
    bundle=RESULT/'evidence.tar.xz'
    frozen=(ROOT.parent/'query-shared-gap-v1/check.py',ROOT.parent/'query-shared-gap-v1/review.py',
            ROOT.parent/'query-shape-routing-v1/routing.py',ROOT.parent/'query-checked-junctions-v1/model_delivery.py')
    with tarfile.open(bundle,'x:xz')as archive:
        for expr in ('*.py','*.json','*.log','initial/*.py','initial/*.log','initial/*.json','native/manifest.json','standing/manifest.json'):
            for f in sorted(ROOT.glob(expr)):
                if f.name!='score-reuse.py':
                    archive.add(f,arcname=f.relative_to(ROOT))
        for f in frozen:
            archive.add(f,arcname=Path('preceding')/f.parent.name/f.name)
    write_json(RESULT/'publication.json',{'analysis':papers,'native_images':reference(manifest),'archive':reference(bundle),
               'frozen_sources':[reference(p) for p in frozen],
               'checkpoint':exact['checkpoint'],'training_performed':False,'actual_native_viewing_complete':True,
               'numeric_evaluation_complete':True,'new_photo_panel':read_json(checked(papers['new-summary']))['summary'],
               'same_photo_and_training_overlap':training['training_and_recent_source_overlap'],
               'standing':{r['id']:r['RMS_camera_RGB_to_shared_DN16']for r in real},
               'scope':'Scoped inference study on 24 additional photographs and 72 replays. Both standing GFX families are viewed. No absolute photo or camera PSNR score for this study.'})


if __name__=='__main__':
    main()
