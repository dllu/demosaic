"""Audit fixed-fold geometry, exact support overlap and disjoint sources."""
import json
import math

import numpy as np

from shoulders import METHODS, PRIOR, ROOT, area, held, interior, latent, nomination, scan
from check import analyze, apply
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from witness import anchored, local

REGION = np.s_[64:192,64:192]
COORD = np.arange(256) - 127.5
Y, X = np.meshgrid(COORD,COORD,indexing='ij')
BAYER = ((0,0),(0,1),(1,0),(1,1))


def footprint(shape):
    return area(X.ravel(),Y.ravel(),shape)[0][:,0].reshape(256,256)


def math_audit():
    pair=[[.106,.061,0.],[.084,-.079,0.]]
    colors=np.array([0,1,1,2])
    geometry=(0,19.,-10.,25.,42.,.16)
    mask=footprint(geometry)
    a=2*np.pi*(pair[0][0]*X+pair[0][1]*Y)-.28
    b=2*np.pi*(pair[1][0]*X+pair[1][1]*Y)+.71
    strong=.018*np.cos(a)
    weak=.009*(np.cos(b)+.46*np.cos(2*b))
    image=.31+.022*X/128+.009*Y/128+strong+weak*(1-mask)
    packed=np.stack([image[dy::2,dx::2]for dy,dx in BAYER])
    ns={'shot':0.,'read':1.5e-7}
    old=analyze(packed,colors,ns,pair)
    found=scan(packed,colors,ns,old)
    with anchored((0,0)):
        verify=local.partition()>=2
    changed=packed.copy()
    changed[:,verify]=np.random.default_rng(553944).uniform(.18,.43,(4,int(verify.sum())))
    previously=analyze(changed,colors,ns,pair)
    after=scan(changed,colors,ns,previously)
    assert all(found[k]['candidate']==after[k]['candidate'] for k in METHODS)
    assert all(found[k]['test']!=after[k]['test'] for k in METHODS)
    parent=np.full((3,256,256),.31)
    donor=parent+strong+weak
    receipt={}
    for k in METHODS:
        c=found[k]
        assert c['strength']>0
        prediction=apply(parent,donor,c['application'],'shared')
        selected=footprint(c['candidate']['shape'])
        np.testing.assert_array_equal(prediction[:,selected==0],donor[:,selected==0])
        receipt[k]={'fit':c['candidate'],'off_grid_overlap':overlap(selected>.5,mask>.5)}
    return {'held_changes_raw_votes_only':True,'outside_edit_footprints_bit_exact':True,'off_grid_known':geometry,
            'old':overlap(footprint(old['chosen']['shared']['shape'])>.5,mask>.5),'new':receipt}


def overlap(a,b):
    return float((a&b).sum()/max(1,(a|b).sum()))


def main():
    driver=reference(ROOT/'new-summary.json')
    raw=read_json(checked(driver))
    original=read_json(checked(raw['upstream']))
    plan=read_json(checked(read_json(checked(original['observations']))['source']))
    previous=read_json(PRIOR/'plan.json')
    other=read_json(ROOT.parent/'query-shape-routing-v1/plan.json')
    source_ids={r['source']['id']for r in plan['sources']}
    near={r['source']['id']for p in (previous,other) for r in p['sources']}
    with checked(plan['training_manifest']).open() as f:
        train={json.loads(z)['id']for z in f}
    assert len(source_ids)==24 and not (source_ids&(near|train))
    diag=[]
    for row,base in zip(raw['cases'],original['rows'],strict=True):
        if not row['gap']:
            continue
        basis=base['checks']['matching'][0]
        if 'geometry' not in basis:
            diag.append({'index':row['index'],'upstream_donor_rejected':True})
            continue
        with np.load(checked(row['input']),allow_pickle=False) as f:
            actual=f['support']==0
            packed=f['packed'][0,:,64:192,64:192]
            cfa=f['colors'][0]
        fixture=plan['sources'][row['index']]['geometry']
        x,y=fixture['gap_center']
        width,length,theta=(fixture[k]for k in ('gap_width','gap_length','gap_orientation'))
        shape=(1,x*math.cos(theta)+y*math.sin(theta),0.,width,1.,theta) if fixture['family']=='strip' else (0,x,y,width,length,theta)
        r,_,boundary=interior(packed,cfa,plan['profiles'][row['noise']])
        waveform=latent(r,boundary,basis['geometry'])
        known=held(r,waveform,'shared',{'shape':shape})
        proposals={'shared':basis['chosen']['shared']}|{k:v['candidate']for k,v in row['checks']['matching'][0].items()}
        diag.append({'index':row['index'],'held_oracle':known,'overlap':{
            k:overlap((footprint(c['shape'])>.5)[REGION],actual[REGION]) if c else None for k,c in proposals.items()
        }})
    field=reference(ROOT/'standing/manifest.json')
    real=read_json(checked(field))
    assert all(v==0 for row in real['rows']for v in row['RMS_camera_RGB_to_shared_DN16'].values())
    write_json(ROOT/'audit.json',{'driver':reference(__file__),'study':driver,'camera':field,
               'sources':len(source_ids),'training_and_recent_source_overlap':0,'repeat_panel_overlap':sum(r['in_prior_repeat_evaluation']for r in plan['sources']),
               'math':math_audit(),'geometry_diagnostic':diag})


if __name__=='__main__':
    main()
