"""Audit whether red and blue contain independent evidence for fixed green gap hypotheses."""
import math
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'query-shared-gap-v1'))
from check import area, held, interior, latent, phases, regress, residual, valid_terms
from shoulders import PRIOR, ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from witness import anchored, local


def sums(x,y,fold,z,variance,taper,domain,wave,bg,shape):
    output=[]
    for part in (2,3):
        k=domain & (fold==part)
        h,s=area(x[k],y[k],shape)
        basis=np.column_stack((bg[k],h,s))
        target=-(h*wave[k,None])
        q=residual(target,basis,variance[k],taper[k]).ravel()
        w=taper[k]/variance[k]
        output.append((float((w*q*z[k]).sum()),float(((w*q)**2*variance[k]).sum())))
    return np.array(output)


def stats(array):
    return {'per_fold':(array[:,0]/np.sqrt(array[:,1].clip(1e-20))).tolist(),
            'pooled':float(array[:,0].sum()/np.sqrt(max(1e-20,array[:,1].sum())))}


def witnesses(packed,cfa,noise,old,known):
    data,_,boundary=interior(packed,cfa,noise)
    mod=latent(data,boundary,old['geometry'])
    x,y,_,z,v,fold=data
    candidates={'automatic':old['chosen']['shared']}
    if known is not None:
        candidates['known-footprint']={'shape':known}
    components={}
    with anchored((0,0)):
        groups=local.partition().ravel()
    yy,xx=np.indices((128,128))
    ids=[(1,0),(0,1)]+[tuple(k)for _,k,_ in valid_terms(old['geometry'])]
    for index in np.flatnonzero(cfa!=1):
        yy_=(2*yy+index//2-127.5).ravel()
        xx_=(2*xx+index%2-127.5).ravel()
        d=packed[index].astype(float)
        m=groups.reshape(d.shape)==0
        local_mean=gaussian_filter(np.where(m,d,0.),3)/gaussian_filter(m.astype(float),3)
        var=(noise['shot']*np.maximum(local_mean,0.)+noise['read']).clip(2e-11).ravel()
        x1,y1=xx_/128,yy_/128
        domain=np.maximum(abs(xx_),abs(yy_))<=98
        taper=np.exp(-.5*(xx_**2+yy_**2)/83**2)
        angle=phases(xx_,yy_,old['geometry'])
        orders=[angle@key for key in ids]
        bank=np.column_stack([f(p)for p in orders for f in (np.cos,np.sin)])
        core=np.column_stack((np.ones_like(x1),x1,y1,x1*x1,y1*y1,x1*y1))
        base=np.column_stack((core,bank,x1[:,None]*bank,y1[:,None]*bank))
        if boundary is not None:
            a,distance,_=boundary
            side=np.clip(.5+(xx_*np.cos(a)+yy_*np.sin(a)-distance)/5,0,1)
            core=np.column_stack((core,side[:,None]*core[:,:3]))
            base=np.column_stack((base,core[:,6:],side[:,None]*bank))
        fit=np.column_stack((core,bank))
        coeff=[]
        diagonals=[]
        for part in (0,1):
            q=domain & (groups==part)
            b,cov=regress(fit[q],taper[q]/var[q],d.ravel()[q])
            coeff.append(b[len(core[0]):].reshape(-1,2))
            diagonals.append(np.diag(cov)[len(core[0]):].reshape(-1,2).mean(1))
        selected=np.zeros_like(coeff[0])
        stable=[]
        for key in map(tuple,mod['active_orders']):
            i=ids.index(key)
            cross=coeff[0][i]@coeff[1][i]
            floor=np.sqrt(diagonals[0][i]*diagonals[1][i])
            if cross>1.25*floor:
                selected[i]=.5*(coeff[0][i]+coeff[1][i])*(1-floor/cross)
                stable.append(key)
        if stable:
            components[str(cfa[index])]=(xx_,yy_,groups,d.ravel(),var,taper,domain,bank@selected.ravel(),base,stable)
    results={}
    for k,candidate in candidates.items():
        if candidate is None:
            continue
        shape=candidate['shape']
        green=sums(x,y,fold,z,v,mod['taper'],mod['domain'],mod['g_shared'],mod['nuisance'],shape)
        prior=held(data,mod,'shared',candidate)
        gt=stats(green)
        np.testing.assert_allclose([gt['pooled'],*gt['per_fold']],[prior['pooled'],*prior['scores']],rtol=1e-9,atol=1e-9)
        ledgers={c:(sums(*args[:-1],shape),args[-1]) for c,args in components.items()}
        colors=sum((positions for positions,key in ledgers.values()),start=np.zeros_like(green))
        extra=stats(colors)
        fusion=stats(green+colors)
        admitted=gt['pooled']>=3.25 and min(gt['per_fold'])>=.85
        rescued=(not admitted and gt['pooled']>=2.0 and min(gt['per_fold'])>=0.
                 and fusion['pooled']>=3.25 and min(fusion['per_fold'])>=.85
                 and extra['pooled']>=2.0 and min(extra['per_fold'])>=.5)
        results[k]={'green':gt,'additional':extra,'pooled_all':fusion,'green_passed':admitted,'color_rescue':rescued,
                    'planes':{c:{'orders':keys,'stats':stats(d)}for c,(d,keys) in ledgers.items()}}
    return results


def run(root,tag):
    proof=reference(root/'fresh-gap.json')
    source=read_json(checked(proof))
    capture=read_json(checked(source['observations']))
    plan=read_json(checked(capture['source']))
    evaluated=[]
    for item in source['rows']:
        old=item['checks']['matching'][0]
        row=plan['sources'][item['index']]
        geo=row['geometry']
        x,y=geo['gap_center']
        w,length,t=(geo[k]for k in ('gap_width','gap_length','gap_orientation'))
        true=(0,x,y,w,length,t) if geo['family']=='ellipse' else ((1,x*math.cos(t)+y*math.sin(t),0,w,1.,t) if geo['family']=='strip' else None)
        with np.load(checked(item['input']),allow_pickle=False)as f:
            packed=f['packed'][0,:,64:192,64:192]
            cfa=f['colors'][0]
        path=witnesses(packed,cfa,plan['profiles'][item['noise']],old,true) if 'geometry' in old else {}
        evaluated.append({'index':item['index'],'correct_geometry_diagnostic':true,'family':geo['family'],'scores':path})
    return {'scope':tag,'input':proof,'cases':evaluated}


if __name__=='__main__':
    result=[run(p,k)for p,k in ((ROOT,'additional'),(PRIOR,'earlier'))]
    write_json(ROOT/'color-information.json',{'driver':reference(__file__),'results':result,
        'scope':'Exploratory score-only color witness. No images use it. Both source groups have been reviewed under other policies.'})
