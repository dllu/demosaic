"""Locate interruptions from a shared local waveform and its two shoulders."""
from copy import deepcopy
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / 'query-shared-gap-v1'
sys.path.insert(0, str(PRIOR))
from check import DEFICIT_THRESHOLD, area, held, interior, latent, regress, shapes

METHODS = ('coarse-shoulders', 'subgrid-shoulders', 'subgrid-amplitude')


def locations(x, y, masks):
    kind, xc, yc, width, length, angle = masks.T
    c, s = np.cos(angle), np.sin(angle)
    x, y = x[:, None], y[:, None]
    u = ((x-xc)*c + (y-yc)*s)/width
    v = (-(x-xc)*s + (y-yc)*c)/length
    strip = (x*c+y*s-xc)/width
    normal = np.where(kind == 0, u, strip)
    distance = np.where(kind == 0, np.hypot(u, v), np.abs(strip))
    return normal, distance


def local_parameter_bank(start):
    """Bound a second fit around discovery centers without changing the family."""
    kind, x, y, w, length, angle = start
    major = (-6., 0., 6.)
    minor = major if kind == 0 else (0.,)
    angular = (-np.pi/18, 0., np.pi/18)
    return np.asarray([(kind,x+dx,y+dy,w+dw,length+dl,(angle+da)% (2*np.pi))
              for dx in major for dy in minor for dw in major for da in angular
              for dl in (major if kind == 0 else (0.,))], dtype=float)


def nomination(raw, model, previous, shoulders=True):
    x, y, _, observed, variance, fold = raw
    use = model['domain'] & (fold < 2)
    x, y, value, v = x[use], y[use], observed[use], variance[use]
    carrier = model['g_shared'][use]
    operations = model['nuisance'][use]
    weight = model['taper'][use]/v
    bread = regress(operations,weight,value)[1]
    project = operations @ bread
    measured = operations.T * weight
    variance_weight = weight**2*v
    residual = value - project @ (measured @ value)
    weighted_data = weight*residual

    def measure(program):
        response = program - project @ (measured @ program)
        signal = weighted_data @ response
        squares = np.square(response)
        return signal/np.sqrt((variance_weight @ squares).clip(1e-20)), signal, weight @ squares

    def search(bank, use_edges, restrict=None):
        ledger = []
        for start in range(0,len(bank),40):
            active = bank[start:start+40]
            hard, _ = area(x,y,active)
            whole, dot, power = measure(-hard*carrier[:,None])
            ok = ((hard>.92).sum(0)>=150) & ((hard<.05).sum(0)>=600) & (power>=3) & (whole>=2)
            if restrict is not None:
                ok &= whole >= restrict
            eligible = np.flatnonzero(ok)
            if eligible.size == 0:
                continue
            if use_edges:
                normal, radius = locations(x,y,active[eligible])
                signed = np.exp(-.5*((radius-1.45)/.21)**2) - np.exp(-.5*((radius-.82)/.23)**2)
                zones = np.concatenate((signed*(normal>=0), signed*(normal<0)),axis=1)
                two = measure(zones*carrier[:,None])[0].reshape(2,-1).T
                weaker = np.min(two, axis=1)
                stronger = np.max(two, axis=1)
                edge_vote = .55*weaker + .15*stronger
                goodness = whole[eligible] + edge_vote
            else:
                two = np.zeros((len(eligible),2))
                goodness = whole[eligible]
            for column,index in enumerate(eligible):
                ledger.append({'index':start+int(index),'shape':active[index].tolist(),
                               'z':float(whole[index]),'rank':float(goodness[column]),'shoulders':two[column].tolist(),
                               'fraction':float(dot[index]/power[index])})
        return max(ledger,key=lambda item:item['rank'],default=None)

    if previous is None:
        return dict.fromkeys(METHODS)
    amplitude = search(local_parameter_bank(previous['shape']),False) or previous
    if not shoulders:
        return {'subgrid-amplitude':amplitude}
    limit = max(2.,previous['z']-2.)
    coarse = search(shapes(),True,limit)
    angular = search(local_parameter_bank(coarse['shape']),True,limit) if coarse else None
    refined = max((c for c in (coarse,angular) if c is not None),key=lambda c:c['rank'],default=None)
    return dict(zip(METHODS,(coarse,refined,amplitude),strict=True))


def qualify(data, model, candidates, predecessor):
    result={}
    for arm, candidate in candidates.items():
        test=held(data,model,'shared',candidate)
        strength=0.
        if test and test['pooled']>=DEFICIT_THRESHOLD and min(test['scores'])>=.85:
            strength=float(np.clip(.85*min(test['fraction'],candidate['fraction']),0,.85))
        adjusted=deepcopy(predecessor)
        adjusted['chosen']['shared']=candidate
        adjusted['cut']['shared']=strength
        result[arm]={'candidate':candidate,'test':test,'strength':strength, 'application':adjusted}
    return result


def scan(raw, cfa, profile, old):
    if 'geometry' not in old:
        return {}
    data,_,boundary=interior(raw,cfa,profile)
    model=latent(data,boundary,old['geometry'])
    np.testing.assert_allclose(model['discovery_bands'],old['discovery_bands'],rtol=1e-7,atol=1e-10)
    return qualify(data,model,nomination(data,model,old['chosen']['shared']),old)
