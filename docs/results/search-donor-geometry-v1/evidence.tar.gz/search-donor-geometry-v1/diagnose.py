"""Render the selected camera donors and measure synthetic guide alignment."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULT = read_json(ROOT / "review/result.json")
DONE = read_json(checked(RESULT["collection"]))
PLAN = read_json(checked(RESULT["plan"]))


def selected_regions():
    selected = [row for row in RESULT["camera"] if any(row["drift_fit"]["active"])]
    sheet = Image.new("RGB", (418, len(selected) * 166), "#eeeeee")
    draw = ImageDraw.Draw(sheet)
    cells = []
    for i, row in enumerate(selected):
        scene = row["source"]
        x, y, w, h = scene["query_box"]
        ax, ay, *_ = scene["absolute_query_xywh"]
        ox, oy = ax - x, ay - y
        first, second = row["drift_fit"]["donor_boxes"]
        boxes = [first, [ax + w // 2 - 64, ay + h // 2 - 64, 128, 128], second]
        parent = np.load(checked(scene["parent_prediction"]), mmap_mode="r")
        with np.load(checked(scene["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        draw.text((6, 166 * i + 4), row["id"], fill="black")
        for j, (box, label) in enumerate(
            zip(boxes, ("First donor", "Query center", "Second donor"), strict=True)
        ):
            a, b, c, d = box
            rgb = display(
                parent[..., b - oy : b - oy + d, a - ox : a - ox + c],
                ctx,
                exposure=row["display_exposure"],
            )[0]
            pixels = np.rint(rgb.transpose(1, 2, 0) * 255).astype(np.uint8)
            assert pixels.shape == (128, 128, 3)
            left, top = 6 + 138 * j, 166 * i + 32
            draw.text((left, 166 * i + 17), label, fill="black")
            sheet.paste(Image.fromarray(pixels), (left, top))
            cells.append(
                {
                    "id": row["id"],
                    "kind": label,
                    "source_xywh": box,
                    "parent_checkpoint": scene["checkpoint"],
                    "parent_prediction": scene["parent_prediction"],
                    "display_exposure": row["display_exposure"],
                    "figure_xywh": [left, top, c, d],
                }
            )
    path = ROOT / "review/selected-neighborhoods.png"
    sheet.save(path)
    return reference(path), cells


def alignment():
    rows = {}
    for group in DONE["synthetic"]:
        key = group["guide_key"]
        if key in rows:
            continue
        case = read_json(checked(group["case"]))
        recipe = case["metadata"]["recipe"]
        angles = np.asarray(recipe["wire_angles"])
        nominal = (
            np.stack((np.cos(angles), np.sin(angles)), 1) / np.asarray(recipe["periods"])[:, None]
        )
        scale = min(PLAN["query_xywh"][2:])
        fit = DONE["donors"][key]["fit"]
        frequencies = np.asarray(fit.get("frequencies_xy", [[0, 0], [0, 0]]))[fit["active"]]
        alignments = []
        for index, aim in enumerate(nominal):
            distances = {}
            for harmonic in (1, 2, 3):
                signed = (
                    np.minimum(
                        np.linalg.norm(frequencies - aim * harmonic, axis=1),
                        np.linalg.norm(frequencies + aim * harmonic, axis=1),
                    )
                    * scale
                )
                distances[str(harmonic)] = float(min(signed)) if len(signed) else None
            alignments.append({"family": index, "center_distances_in_native_bins": distances})
        rows[key] = {"kind": case["kind"], "alignment": alignments}
    return rows


image, cells = selected_regions()
write_json(
    ROOT / "review/diagnostic.json",
    {
        "script": reference(__file__),
        "result": reference(ROOT / "review/result.json"),
        "image": image,
        "cells": cells,
        "synthetic": alignment(),
        "scope": "V120 display crops provide a visual check. Only RAW data from the two donors enters the guide fit. "
        "Synthetic distances are signed modulo reversal and use the known query-center gradients.",
    },
)
