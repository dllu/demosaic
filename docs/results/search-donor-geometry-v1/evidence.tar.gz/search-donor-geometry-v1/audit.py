"""Check native board pixels and independently recompute the retained metrics."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ROI = np.s_[..., 128:384, 128:384]
METRICS = (
    "quiet_RMS_DN16",
    "query_RMS_DN16",
    "weak_increment_RMS_DN16",
    "weak_gain",
    "strong_gain",
    "weak_absent_projection",
)


def direct(parent, truth, quiet, cropped, alpha):
    out = parent.copy()
    out[ROI] += (cropped.astype(np.float64) - parent[ROI]) * alpha
    error = out - truth
    weak, strong = truth[2] - truth[1], truth[1] - truth[0]
    return (
        np.mean((error[ROI][..., quiet] * 65535) ** 2),
        np.mean((error[ROI] * 65535) ** 2),
        np.mean(((error[2] - error[1]) * 65535) ** 2),
        np.vdot(out[2] - out[1], weak) / np.vdot(weak, weak),
        np.vdot(out[1] - out[0], strong) / np.vdot(strong, strong),
        np.vdot(error[1], weak) / np.vdot(weak, weak),
    )


def main():
    result_path = ROOT / "review/result.json"
    result = read_json(result_path)
    plan = read_json(checked(result["plan"]))
    done = read_json(checked(result["collection"]))
    previous = read_json(checked(plan["previous_collection"]))
    assert done["new_neural_calls"] == 0
    actual = defaultdict(list)
    baseline_count = 0
    fallback_count = 0
    synthetic = {}
    for record, control in zip(done["synthetic"], previous["synthetic"], strict=True):
        assert record["case"] == control["case"]
        case = read_json(checked(record["case"]))
        checked(case["sensor"])
        key = record["guide_key"]
        donor = done["donors"][key]
        old_donor = previous["donors"][key]
        fit = donor["fit"]
        assert donor["left"] == old_donor["left"]
        assert donor["right"] == old_donor["right"]
        identities = [
            set(item["identities"])
            for item in [
                case["metadata"],
                old_donor["left_declaration"],
                old_donor["right_declaration"],
                *(d["declaration"] for d in donor["decoys"]),
            ]
        ]
        assert len(set.union(*identities)) == sum(map(len, identities))
        for item in [donor["left"], donor["right"], *(d["sensor"] for d in donor["decoys"])]:
            checked(item)
        synthetic[key] = {
            "selected_boxes": fit.get("donor_boxes"),
            "active": fit["active"],
            "screened_frequencies_xy": fit.get("screened_frequencies_xy"),
            "curvature_delivered": np.any(
                fit.get("hessians_xy", np.zeros((2, 2, 2))), (1, 2)
            ).tolist(),
        }
        parent = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as f:
            truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
        with (
            np.load(checked(record["prediction"])) as f,
            np.load(checked(control["prediction"])) as orig,
        ):
            for name in f.files:
                if name.startswith(("guarded--", "planar--", "bracket--")):
                    np.testing.assert_array_equal(f[name], orig[name])
                    baseline_count += 1
                if name.startswith("screened-") and not any(fit["active"]):
                    np.testing.assert_array_equal(
                        f[name], orig[name.replace(name.split("--")[0], "guarded")]
                    )
                    fallback_count += 1
            for j, row in enumerate(result["aggregates"]):
                s = row["setting"]
                if (case["profile"], case["placement"]) != (s["profile"], s["placement"]):
                    continue
                if row["kind"] not in ("all", case["kind"]):
                    continue
                for arm in plan["arms"]:
                    pixels = f[f"{arm}--t{s['threshold']:g}"]
                    scales = (("fixed", s["scale"]), ("matched", row["matched"][arm]["scale"]))
                    for mode, scale in scales:
                        actual[j, arm, mode].append(direct(parent, truth, quiet, pixels, scale))
    for (j, arm, mode), rows in actual.items():
        mean = np.mean(rows, 0)
        mean[:3] **= 0.5
        expected = result["aggregates"][j][mode][arm]
        np.testing.assert_allclose(mean, [expected[m] for m in METRICS], rtol=1e-10, atol=1e-10)
    for row in result["boards"]:
        with (
            Image.open(checked(row["board"]["image"])) as a,
            Image.open(checked(row["triplet"]["image"])) as b,
        ):
            for label in ("Noisy Malvar", "Search curved", "Exact GT"):
                crops = []
                for image, group in ((a, "board"), (b, "triplet")):
                    (panel,) = [p for p in row[group]["panels"] if p["label"] == label]
                    x, y, w, h = panel["png_xywh"]
                    assert (w, h) == (160, 160)
                    crops.append(np.asarray(image.crop((x, y, x + w, y + h))))
                np.testing.assert_array_equal(*crops)
    camera = []
    for board, old in zip(result["camera"], previous["camera"], strict=True):
        assert board["id"] == old["id"]
        x, y, w, h = board["ROI_xywh"]
        qx, qy, _, _ = board["source"]["query_box"]
        crop = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with (
            np.load(checked(board["drift_prediction"])) as a,
            np.load(checked(board["crosscheck_prediction"])) as b,
            np.load(checked(old["prediction"])) as c,
        ):
            candidate = a["corrected"][crop].astype(np.float64)
            previous_shift = candidate - c["corrected"][crop]
            delta = (candidate - b["corrected"][crop]) * 65535
        restored_rms = float(np.sqrt(np.mean(delta**2)))
        np.testing.assert_allclose(restored_rms, board["change_DN16"], rtol=1e-13, atol=1e-13)
        fit = board["drift_fit"]
        assert not np.any(delta) if not any(fit["active"]) else True
        with (
            Image.open(checked(board["image"])) as new,
            Image.open(checked(board["comparison_source"])) as old_board,
        ):
            parent_panels = read_json(checked(plan["camera_baseline"]))["camera"]
            parent = next(old_row for old_row in parent_panels if old_row["id"] == board["id"])
            for panel in board["panels"]:
                if panel["label"] == plan["rendering"]["camera_label"]:
                    continue
                (before,) = [p for p in parent["panels"] if p["label"] == panel["label"]]
                old_box = before["png_xywh"]
                new_box = panel["png_xywh"]
                assert new_box[2:] == old_box[2:] == [w, h]

                def crop_box(box):
                    x, y, w, h = box
                    return x, y, x + w, y + h

                np.testing.assert_array_equal(
                    old_board.crop(crop_box(old_box)), new.crop(crop_box(new_box))
                )
        camera.append(
            {
                "id": board["id"],
                "rms_DN16": restored_rms,
                "rms_vs_fixed_bracket_DN16": float(np.sqrt(np.mean(previous_shift**2)) * 65535),
                "candidate_count": fit["candidate_count"],
                "with_peaks": fit["with_peaks"],
                "active": fit["active"],
                "fit_status": fit["status"],
                "period_pixels": [
                    float(1 / np.linalg.norm(f))
                    for f, active in zip(fit.get("frequencies_xy", []), fit["active"])
                    if active
                ],
                "curvature_delivered": np.any(
                    fit.get("hessians_xy", np.zeros((2, 2, 2))), (1, 2)
                ).tolist(),
            }
        )
    write_json(
        ROOT / "review/independent-audit.json",
        {
            "producer": reference(__file__),
            "report": reference(result_path),
            "original_prediction_arrays_replayed": baseline_count,
            "screened_fallback_arrays_identical": fallback_count,
            "recomputed_metrics": len(actual) * len(METRICS),
            "synthetic": synthetic,
            "camera": camera,
            "verified_triplet_cells": 6,
        },
    )


if __name__ == "__main__":
    main()
