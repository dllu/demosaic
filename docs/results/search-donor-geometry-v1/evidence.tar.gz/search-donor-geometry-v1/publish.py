"""Record the completed viewing pass and publish its bound comparison evidence."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
NAME = ROOT.name
REPO = Path.cwd()
IMAGES = REPO / "docs/images" / NAME
RESULTS = REPO / "docs/results" / NAME
IMAGES.mkdir()
RESULTS.mkdir()

result_path = ROOT / "review/result.json"
result = read_json(result_path)
plan = read_json(checked(result["plan"]))
collection = read_json(checked(result["collection"]))
assert len(result["boards"]) == 2 and len(result["camera"]) == 8
camera_noise = {
    r["board"]["id"]: r["noise"] for r in read_json(checked(plan["camera_conditions"]))["camera"]
}
camera_sources = {r["id"]: r for r in collection["camera"]}
inspection = read_json(ROOT / "native-view/items.json")


def copy(binding):
    source = checked(binding)
    destination = IMAGES / source.name
    shutil.copyfile(source, destination)
    assert reference(destination)["sha256"] == binding["sha256"]
    return source.name


def case_board(row):
    case = read_json(checked(row["case_receipt"]))
    return {
        **{
            k: row[k]
            for k in (
                "id",
                "ROI_xywh",
                "display_contrast",
                "display_exposure",
                "ADC_bits",
                "black_level",
                "case_receipt",
                "operating_point",
            )
        },
        "parent_checkpoint": plan["parent_checkpoint"],
        "metadata": {
            k: case["metadata"][k] for k in ("pattern", "noise", "recipe", "placement", "repeat")
        },
        "prediction_receipt": next(
            record["prediction"] for record in collection["synthetic"] if record["id"] == row["id"]
        ),
        "files": [
            group | {"file": copy(group["image"])} for group in (row["board"], row["triplet"])
        ],
    }


def camera_board(row):
    key = row["id"]
    source = row["source"]
    x, y, w, h = row["ROI_xywh"]
    qx, qy, *_ = source["query_box"]
    ax, ay, *_ = source["absolute_query_xywh"]
    roi = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
    pixels = np.load(checked(source["parent_prediction"]), mmap_mode="r")[
        0, :, y : y + h, x : x + w
    ].astype(np.float64)
    rms = {}
    for control, binding in (
        ("cross_checked_guide", row["crosscheck_prediction"]),
        ("search", row["drift_prediction"]),
    ):
        with np.load(checked(binding)) as f:
            rms[control] = float(np.sqrt(np.mean((f["corrected"][roi] - pixels) ** 2)) * 65535)
    return {
        **{
            k: row[k]
            for k in (
                "id",
                "display_exposure",
                "source",
                "image",
                "panels",
                "change_DN16",
                "crosscheck_prediction",
            )
        },
        "file": copy(row["image"]),
        "absolute_ROI_xywh": [x + ax - qx, y + ay - qy, w, h],
        "capture": "DSCF3879 ISO6400" if key.startswith("main-") else "DSCF3842 ISO6400",
        "reference_capture": "DSCF3880 ISO100" if key.startswith("main-") else "DSCF3835 ISO100",
        "noise": camera_noise[key],
        "fit": row["drift_fit"],
        "frame": camera_sources[key]["frame"],
        "prediction_receipt": row["drift_prediction"],
        "distance_from_V120_DN16": rms,
    }


diagnostic = read_json(ROOT / "review/diagnostic.json")
manifest = IMAGES / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "renderings_seen": {
            "comparison_boards": inspection,
            "exact_target_triplets": 2,
            "neighborhood_board": {"file": copy(diagnostic["image"]), "cells": diagnostic["cells"]},
        },
        "synthetic": [case_board(row) for row in result["boards"]],
        "camera": [camera_board(row) for row in result["camera"]],
        "notes": [
            "All panels were inspected with native crop pixels retained. The reported sizes describe source pixels before layout.",
            "Camera companions are separate exposures with independently computed AHD or camera JPEG rendering. They are qualitative references.",
            "The cab left panels show less guide-added banding, with fine crossings still absent. Coarse fence retains visible crossings. Building hardware and leaf texture remain soft. Sky is numerically unchanged.",
        ],
    },
)
for name in ("independent-audit.json", "diagnostic.json"):
    shutil.copyfile(ROOT / "review" / name, RESULTS / name)
receipt_paths = (
    "plan.json",
    "collect.log",
    "output/collection.json",
    "review/result.json",
    "review/independent-audit.json",
    "review/diagnostic.json",
    "native-view/items.json",
    "audit.py",
    "diagnose.py",
    "publish.py",
    "work/src/demosaic/search_donor_geometry.py",
    "work/src/demosaic/bracket_phase_geometry.py",
    "work/src/demosaic/donor_phase_geometry.py",
    "work/src/demosaic/local_validated_waves.py",
    "work/scripts/probe_search_donor_geometry.py",
    "work/scripts/probe_donor_phase_geometry.py",
    "work/scripts/report_phase_drift.py",
)
archive = RESULTS / "evidence.tar.gz"
with (
    archive.open("xb") as disk,
    gzip.GzipFile(filename="", fileobj=disk, mode="wb", mtime=0) as compressed,
    tarfile.open(fileobj=compressed, mode="w") as tf,
):
    for name in receipt_paths:
        path = ROOT / name
        entry = tf.gettarinfo(str(path), arcname=f"{NAME}/{name}")
        entry.mtime = entry.uid = entry.gid = 0
        entry.uname = entry.gname = ""
        with path.open("rb") as raw:
            tf.addfile(entry, raw)
with tarfile.open(archive) as tf:
    assert tf.getnames() == [f"{NAME}/{name}" for name in receipt_paths]
    for name in receipt_paths:
        assert tf.extractfile(f"{NAME}/{name}").read() == (ROOT / name).read_bytes()
write_json(
    RESULTS / "publication.json",
    {
        "archive": reference(archive),
        "archive_members_verified": len(receipt_paths),
        "native_manifest": reference(manifest),
        "native_comparison_boards_viewed": 10,
        "native_triplets_viewed": 2,
        "native_neighborhood_boards_viewed": 1,
        "independent_audit": reference(RESULTS / "independent-audit.json"),
        "diagnostic": reference(RESULTS / "diagnostic.json"),
        "scope": "Fixed query and camera replays. No neural model was trained and no broad PSNR evaluation was run for this component.",
    },
)
