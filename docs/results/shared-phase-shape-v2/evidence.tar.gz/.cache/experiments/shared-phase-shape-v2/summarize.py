"""Aggregate paired source differences and direction-specific color gains."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path(__file__).resolve().parent / "review"
path = root / "result.json"
all_rows = read_json(path)["metrics"]
columns = (
    "weak_gain",
    "strong_gain",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "abs_weak_absent_projection",
    "centered_chroma_increment_RMS_DN16",
    "R",
    "G",
    "B",
)
groups = defaultdict(dict)
for r in all_rows:
    groups[r["profile"], r["placement"], r["method"], r["budget_DN16"], r["model"]][r["source"]] = [
        r["weak_gain"],
        r["strong_gain"],
        r["quiet_delta_DN16"],
        r["weak_increment_RMS_DN16"],
        abs(r["weak_absent_projection"]),
        r["centered_chroma_increment_RMS_DN16"],
        *r["response_RGB"],
    ]
assert len(groups) == 32 and all(len(v) == 8 for v in groups.values())
rng = np.random.default_rng(74122)
draws = rng.integers(0, 8, (12000, 8))
summaries = []
for (profile, placement, method, limit, model), values in groups.items():
    if model == "shared":
        continue
    matched = groups[profile, placement, method, limit, "shared"]
    order = sorted(values)
    old, new = [np.asarray([arr[k] for k in order]) for arr in (values, matched)]
    diff = new - old
    summaries.append(
        {
            "profile": profile,
            "placement": placement,
            "method": method,
            "budget_DN16": limit,
            "independent": old.mean(axis=0).tolist(),
            "shared": new.mean(axis=0).tolist(),
            "paired_delta": diff.mean(axis=0).tolist(),
            "paired_descriptive_percentiles": np.quantile(
                diff[draws].mean(axis=1), [0.025, 0.975], axis=0
            ).tolist(),
            "sources_with_higher_weak_response": int(np.sum(diff[:, 0] > 0)),
            "sources_with_lower_increment_error": int(np.sum(diff[:, 3] < 0)),
        }
    )
    if limit == 0.02 and method == "weighted-refit":
        print(
            profile,
            placement,
            old.mean(axis=0).round(6).tolist(),
            new.mean(axis=0).round(6).tolist(),
            flush=True,
        )
audit_path = root / "independent-audit.json"
audit = read_json(audit_path)
assert audit["status"] == "passed"
write_json(
    root / "summary.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "audit": reference(audit_path),
        "columns": columns,
        "groups": summaries,
        "camera": audit["camera_checks"],
    },
)
