"""Independently reduce saved RGB predictions and check native comparison panels."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
path = root / "review/result.json"
report = read_json(path)
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
earlier = read_json(checked(plan["previous_report"]))
assert collection["synthetic_fits"] == 96 and collection["camera_fits"] == 8
assert len(report["metrics"]) == 256 and len(report["boards"]) == 4
groups = defaultdict(list)
for r in report["metrics"]:
    groups[r["id"]].append(r)
roi = np.s_[..., 128:384, 128:384]


def rms(v):
    return np.sqrt(np.mean(np.square(v))) * 65535


def projection(a, b, *, axes=None):
    return np.sum(a * b, axis=axes) / np.sum(b * b, axis=axes)


reductions, delta, fold_checks = 0, 0.0, 0
background = []
for binding in collection["synthetic"]:
    item = read_json(checked(binding))
    old = read_json(checked(item["control"]))
    source = read_json(checked(item["case"]))
    assert item["id"] == source["id"] == old["id"]
    for independent, shared in zip(old["fits"][plan["reference_arm"]], item["fits"], strict=True):
        assert shared["shared_phase_shape"] is True
        for a, b in zip(independent["records"], shared["records"], strict=True):
            for name in ("frequencies", "edges", "guide_search_excluded"):
                assert a[name] == b[name]
                fold_checks += len(a[name])
    parent = np.load(checked(source["parent"])).astype(np.float64)
    with np.load(checked(source["target"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][roi]
    weak, strong = np.diff(target, axis=0)[::-1]
    with (
        np.load(checked(item["predictions"])) as candidate,
        np.load(checked(old["output"])) as independent,
    ):
        for row in groups[item["id"]]:
            key = f"{row['method']}-t{row['threshold']:g}"
            saved = (
                candidate[key]
                if row["model"] == "shared"
                else independent[f"{plan['reference_arm']}--{key}"]
            )
            prediction = parent.copy()
            scale = row["scale"]
            prediction[roi] = (1 - scale) * parent[roi] + scale * saved.astype(np.float64)
            error = prediction - target
            inc_weak, inc_strong = np.diff(prediction, axis=0)[::-1]
            weak_error = inc_weak - weak
            chroma = weak_error[roi] - weak_error[roi].mean(axis=0, keepdims=True)
            actual = {
                "weak_gain": projection(inc_weak, weak),
                "strong_gain": projection(inc_strong, strong),
                "weak_absent_projection": projection(error[1], weak),
                "weak_increment_RMS_DN16": rms(weak_error),
                "quiet_RMS_DN16": rms(error[roi][..., quiet]),
                "query_RMS_DN16": rms(error[roi]),
                "quiet_delta_DN16": rms(error[roi][..., quiet])
                - rms((parent - target)[roi][..., quiet]),
                "response_RGB": projection(inc_weak[roi], weak[roi], axes=(1, 2)),
                "centered_chroma_increment_RMS_DN16": rms(chroma),
            }
            for name, value in actual.items():
                np.testing.assert_allclose(value, row[name], rtol=0, atol=4e-10)
                delta = max(delta, float(np.max(np.abs(value - row[name]))))
                reductions += np.size(value)
            if row["method"] == "weighted-refit" and row["budget_DN16"] == 0.02:
                background.append(
                    {
                        "id": row["id"],
                        "profile": row["profile"],
                        "placement": row["placement"],
                        "model": row["model"],
                        "delivered_correction_DN16": float(rms((prediction - parent)[0][roi])),
                    }
                )


def display_cell(path, panel):
    x, y, w, h = panel["png_xywh"]
    assert (w, h) == (160, 160)
    return np.asarray(Image.open(checked(path)))[y : y + h, x : x + w]


assert reductions == 2816 and fold_checks == 576 and len(background) == 64
camera_checks = []
retained = 0
for row, prev, new in zip(report["camera"], earlier["camera"], collection["camera"], strict=True):
    assert row["id"] == prev["id"] == new["id"]
    keep = [p for p in row["panels"] if p["label"] != "Shared waveform"]
    for a, b in zip(keep, prev["panels"], strict=True):
        assert a["label"] == b["label"]
        np.testing.assert_array_equal(display_cell(row["image"], a), display_cell(prev["image"], b))
        retained += 1
    scene = row["source"]
    x, y, w, h = row["ROI_xywh"]
    ox, oy, *_ = scene["query_box"]
    parent_crop = np.load(checked(scene["parent_prediction"]), mmap_mode="r")[
        0, :, y : y + h, x : x + w
    ]
    crop = np.s_[:, y - oy : y - oy + h, x - ox : x - ox + w]
    with (
        np.load(checked(row["shared_prediction"])) as current,
        np.load(checked(prev["guarded_prediction"])) as control,
    ):
        val = current["shared"][crop]
        assert (
            abs(
                rms(val.astype(np.float64) - control["guard8"][crop])
                - row["shared_minus_independent_RMS_DN16"]
            )
            < 1e-12
        )
        camera_checks.append(
            {
                "id": row["id"],
                "shared_minus_V120_RMS_DN16": float(rms(val.astype(np.float64) - parent_crop)),
                "shared_minus_independent_RMS_DN16": row["shared_minus_independent_RMS_DN16"],
            }
        )
for b in report["boards"]:
    f, t = b["board"], b["triplet"]
    for j, k in enumerate((0, 3, 5)):
        np.testing.assert_array_equal(
            display_cell(f["image"], f["panels"][k]), display_cell(t["image"], t["panels"][j])
        )
assert retained == 120
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "status": "passed",
        "native_reductions": int(reductions),
        "maximum_difference": delta,
        "fold_geometry_and_guard_where_matched": fold_checks,
        "camera_checks": camera_checks,
        "retained_camera_cells_bitexact": retained,
        "exact_triplet_subsets": 4,
        "no_wire_role": background,
    },
)
print(reductions, delta, retained, "independent audit passed", flush=True)
