"""Bind observations to the actual native boards and check the rendered sky."""

import datetime as dt
import json
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent / "review"
path = root / "result.json"
report = read_json(path)
audit = read_json(root / "independent-audit.json")
observations = json.load(sys.stdin)
rows = []
for row in report["boards"] + report["camera"]:
    board = row.get("board", row)
    image = board["image"]
    checked(image)
    rows.append(
        {"id": row["id"], "image": image, "viewed": True, "observation": observations[row["id"]]}
    )
assert len(rows) == len(observations) == 12
sky = next(c for c in report["camera"] if c["id"] == "main-overcast-sky")
check = next(c for c in audit["camera_checks"] if c["id"] == "main-overcast-sky")
assert check["shared_minus_V120_RMS_DN16"] == 0
image = np.asarray(Image.open(checked(sky["image"])))
cells = {}
for p in sky["panels"]:
    x, y, w, h = p["png_xywh"]
    cells[p["label"]] = image[y : y + h, x : x + w]
np.testing.assert_array_equal(cells["V120 EMA"], cells["Shared waveform"])
write_json(
    root / "actual-native-viewing.json",
    {
        "observed_at": dt.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "report": reference(path),
        "boards": rows,
        "v120_sky_matches": {"linear_camera_RGB_bitexact": True, "displayed_pixels_bitexact": True},
    },
)
