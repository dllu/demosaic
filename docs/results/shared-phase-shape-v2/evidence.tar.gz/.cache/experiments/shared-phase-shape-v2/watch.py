"""Wait on the recorded collector and run the frozen report and separate audit."""

import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path(__file__).resolve().parent
collection = root / "output/collection.json"
owner = read_json(root / "launch.json")
deadline = time.monotonic() + 900
while not collection.exists():
    p = psutil.Process(owner["pid"])
    assert p.create_time() == owner["create_time"] and p.status() != psutil.STATUS_ZOMBIE
    if time.monotonic() > deadline:
        raise TimeoutError("Collector observation deadline")
    time.sleep(3)
assert read_json(collection)["plan"] == owner["plan"]
os.sched_setaffinity(0, [6, 7])
for label, script, args in [
    ("report", root / "work/scripts/report_shared_phase_shape.py", [str(root / "plan.json")]),
    ("audit", root / "audit.py", []),
]:
    cmd = [sys.executable, str(script), *args]
    with (root / f"{label}.log").open("xb") as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False)
    write_json(
        root / f"{label}-return.json",
        {
            "returncode": result.returncode,
            "command": cmd,
            "driver": reference(script),
            "collection": reference(collection),
        },
    )
    result.check_returncode()
