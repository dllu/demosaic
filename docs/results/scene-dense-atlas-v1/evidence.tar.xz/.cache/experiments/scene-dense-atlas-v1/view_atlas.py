"""Lay out native crop pixels for comparison at the common display transforms."""

import argparse

from PIL import Image, ImageDraw

from atlas_probe import ROOT, pixels
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def sheet(rows, cols, key):
    image = Image.new("RGB", (8 + 168 * len(cols), 30 + 179 * len(rows)), "#eeeeee")
    labels = ImageDraw.Draw(image)
    for i, k in enumerate(cols):
        labels.text((8 + i * 168, 5), k, fill="black")
    for j, (name, record) in enumerate(rows):
        art = pixels(record)
        labels.text((8, 191 + j * 179), name, fill="black")
        for i, k in enumerate(cols):
            tile = Image.fromarray(art[k])
            assert tile.size == (160, 160)
            image.paste(tile, (8 + i * 168, 30 + j * 179))
    path = ROOT / f"inspect-{key}.png"
    image.save(path)
    return reference(path)


def camera(rows):
    options = {}
    for name, gain in (("main", 4), ("mesh", 4), ("mesh", 16)):
        panel = [
            (r["id"], d["board"])
            for r in rows
            if r["id"].startswith(name)
            for d in r["displays"]
            if d["exposure"] == gain
        ]
        key = f"{name}-x{gain}"
        options[key] = sheet(
            panel,
            (
                "Noisy (Malvar)",
                "V120 EMA",
                "Corpus 100k",
                "Uniform atlas",
                "Dense atlas",
                "ISO100 AHD reference",
            ),
            key,
        )
        if name == "mesh":
            options[key + "-more"] = sheet(
                panel,
                (
                    "ISO6400 camera JPEG",
                    "Uniform atlas, near ranks",
                    "Dense atlas, near ranks",
                    "Dense, donor check",
                    "ISO100 camera JPEG",
                ),
                key + "-more",
            )
    return options


def exact(rows):
    return {
        "exact": sheet(
            [(r["id"], r["board"]) for r in rows],
            ("Noisy Malvar", "V120 EMA", "Corpus 100k", "Uniform atlas", "Dense atlas", "Exact GT"),
            "exact",
        )
    }


if __name__ == "__main__":
    arg = argparse.ArgumentParser()
    arg.add_argument("model", choices=("camera", "exact"))
    key = arg.parse_args().model
    path = ROOT / "native" / ("standing" if key == "camera" else "exact") / "result.json"
    src = reference(path)
    rows = read_json(checked(src))["rows"]
    views = camera(rows) if key == "camera" else exact(rows)
    write_json(
        ROOT / f"{key}-sheets.json", {"driver": reference(__file__), "native": src, "views": views}
    )
