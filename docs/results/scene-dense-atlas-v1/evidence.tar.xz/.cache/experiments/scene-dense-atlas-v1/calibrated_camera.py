"""Separate the fixed-gain camera intervention from the wire-flat-matched dose."""

import numpy as np

from atlas_probe import POLICIES, ROOT, peak_fit, replay
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    fitted = reference(ROOT / "calibration.json")
    audited = reference(ROOT / "camera-audit.json")
    a = read_json(checked(audited))
    c = read_json(checked(fitted))
    assert a["model"] == c["model"]
    settings = {k: v["gain"] for k, v in c["strengths"]["4800"].items()}
    output = []
    for row in a["rows"]:
        with np.load(checked(row["input"]), allow_pickle=False) as inp:
            pattern = inp["colors"][0]
        with np.load(checked(row["arrays"]), allow_pickle=False) as f:
            parent, wb, matrix = (f[k] for k in ("parent", "wb", "matrix"))
            images = {
                k: replay.apply_delta(parent, f[k], wb, matrix, settings[k]) for k in POLICIES
            }
            projection = (
                peak_fit(f["raw"], parent, images, pattern, row["ROI"])
                if row["id"].startswith("mesh")
                else {}
            )
        x, y, w, h = row["ROI"]
        core = np.s_[..., y : y + h, x : x + w]
        change = {
            k: float(65535 * np.sqrt(np.mean((image[core].astype(float) - parent[core]) ** 2)))
            for k, image in images.items()
        }
        output.append(
            {"id": row["id"], "camera": row["raw"], "projection": projection, "rms_DN16": change}
        )
    write_json(
        ROOT / "camera-calibrated.json",
        {
            "driver": reference(__file__),
            "audit": audited,
            "calibration": fitted,
            "dose": settings,
            "rows": output,
        },
    )


if __name__ == "__main__":
    main()
