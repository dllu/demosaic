"""Archive the held-out scores, camera attribution, and native evidence."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import os
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from atlas_probe import OUT, ROOT, WIDTH, pixels
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REPO = ROOT.parents[2]
IMAGES = REPO / "docs/images" / ROOT.name
DEST = REPO / "docs/results" / ROOT.name


def keep(ref, folder):
    old = checked(ref)
    new = IMAGES / folder / old.name
    shutil.copyfile(old, new)
    assert reference(new)["sha256"] == ref["sha256"]
    return ref | {"path": str(new.relative_to(IMAGES))}


def board(obj, folder):
    assert all(x.shape == (160, 160, 3) for x in pixels(obj).values())
    return obj | {"image": keep(obj["image"], folder)}


def main():
    names = {
        "calibration": "calibration.json",
        "numeric": "results.json",
        "camera": "camera-audit.json",
        "attribution": "attribution.json",
        "camera_calibration": "camera-calibrated.json",
        "standing": "native/standing/result.json",
        "exact": "native/exact/result.json",
        "camera_viewing": "camera-sheets.json",
        "exact_viewing": "exact-sheets.json",
        "plot": "plot.json",
        "short_views": "short-views.json",
    }
    refs = {k: reference(ROOT / p) for k, p in names.items()}
    science = {k: read_json(checked(p)) for k, p in refs.items()}
    c, n, a, e, b, s, x, cv, xv, plot_, sv = (science[k] for k in names)
    assert n["lock"] == x["lock"] == b["calibration"] == refs["calibration"]
    assert s["audit"] == e["camera"] == b["audit"] == refs["camera"]
    assert plot_["results"] == x["results"] == refs["numeric"]
    assert cv["native"] == refs["standing"] and xv["native"] == refs["exact"]
    assert c["model"] == a["model"]
    assert len(n["long"]) == 32 and len(n["short"]) == 24 and len(n["natural"]) == 32
    assert sv["result"] == refs["numeric"] and len(sv["rows"]) == 2
    assert len(x["rows"]) == 4 and len(s["rows"]) == 8 and len(e["rows"]) == 4
    assert sum(len(k["displays"]) for k in s["rows"]) == 12
    for view in (*cv["views"].values(), *xv["views"].values()):
        checked(view)
    (IMAGES / "exact").mkdir(parents=True)
    (IMAGES / "standing").mkdir()
    exact = []
    for obj in x["rows"]:
        full = pixels(obj["board"])
        trio = pixels(obj["triplet"])
        assert list(trio) == ["Noisy Malvar", "Dense atlas", "Exact GT"]
        assert all(np.array_equal(p, full[k]) for k, p in trio.items())
        exact.append(obj | {k: board(obj[k], "exact") for k in ("board", "triplet")})
    (IMAGES / "short").mkdir()
    short = []
    for obj in sv["rows"]:
        full, trio = (pixels(obj[k]) for k in ("board", "triplet"))
        assert list(trio) == ["Noisy Malvar", "Uniform atlas, near ranks", "Exact GT"]
        assert all(np.array_equal(p, full[k]) for k, p in trio.items())
        short.append(obj | {k: board(obj[k], "short") for k in ("board", "triplet")})
    standing = []
    for r in s["rows"]:
        displays = []
        for d in r["displays"]:
            shown = pixels(d["board"]).keys()
            assert {
                "Noisy (Malvar)",
                "V120 EMA",
                "Corpus 100k",
                "Uniform atlas",
                "Dense atlas",
                "Dense, donor check",
                "ISO100 AHD reference",
            } <= shown
            if r["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= shown
            displays.append(d | {"board": board(d["board"], "standing")})
        standing.append(r | {"displays": displays})
    index = IMAGES / "manifest.json"
    parents = read_json(checked(c["inputs"]["long"]))
    write_json(
        index,
        {
            "weights": parents["weights"],
            "exact": exact,
            "short": short,
            "standing": standing,
            "figure": keep(plot_["image"], ""),
            "review": {
                "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                "standing": refs["camera_viewing"],
                "exact": refs["exact_viewing"],
                "main": "Sky stays smooth. Coarse fence retains connected crossings. Fine cables and leaves stay soft.",
                "cab": "Both left crops retain missing crossings. The transferred right is clearest under both atlases, with soft incomplete junctions.",
                "short_overview": "The stronger proximity result is slightly more coherent on both cases. The weak oblique crossings still have lower contrast than the exact target.",
                "exact_overview": "Native wire and exact flat cells viewed at the shared exposure. The visible weak direction remains softer than the exact target.",
            },
        },
    )
    prior = read_json(checked(n["legacy_exact_parity"]))
    old = reference(ROOT / "old-patch-code.py")
    original_kernel = read_json(checked(prior["calibration"]))["model"]
    assert old["sha256"] == original_kernel["sha256"]
    payload = [
        *refs.values(),
        *[r["driver"] for r in science.values()],
        *c["inputs"].values(),
        parents["plan"],
        c["model"],
        old,
        n["legacy_exact_parity"],
        n["natural_parent_rows"],
        a["prior"],
        reference(index),
        reference(__file__),
        reference(REPO / "tests/test_scene_patch_covariance.py"),
        reference(WIDTH / "evaluate_wide.py"),
        reference(WIDTH / "render_wide.py"),
    ]
    compressed = OUT / "publication-evidence.tar.xz"
    contents = {}
    with tarfile.open(compressed, "x:xz", preset=4) as out:
        for bound in {p["path"]: p for p in payload}.values():
            path = checked(bound)
            key = (
                path.relative_to(REPO)
                if path.is_relative_to(REPO)
                else Path("external") / path.relative_to(OUT.parent)
            ).as_posix()
            out.add(path, arcname=key)
            contents[key] = bound["sha256"]
    with tarfile.open(compressed, "r:xz") as arc:
        assert all(sha256(arc.extractfile(k).read()).hexdigest() == v for k, v in contents.items())
    DEST.mkdir()
    end = DEST / "evidence.tar.xz"
    pending = DEST / ".evidence.tar.xz"
    try:
        with compressed.open("rb") as source, pending.open("xb") as target:
            shutil.copyfileobj(source, target)
            target.flush()
            os.fsync(target.fileno())
        assert reference(pending)["sha256"] == reference(compressed)["sha256"]
        os.link(pending, end)
    finally:
        pending.unlink(missing_ok=True)
    write_json(
        DEST / "publication.json",
        {
            "scope": "Frozen EMA inference, retained wire and natural test panels, both GFX100S standing scenes. No training, full427 or measured-CFA PSNR.",
            "weights": parents["weights"],
            "native": reference(index),
            "archive": reference(end),
            "archive_members": contents,
            "receipts": refs,
            "summary": n["summary"],
            "calibration": c["strengths"],
            "camera_dose_controls": b["rows"],
            "camera_attribution": e["rows"],
            "seconds": n["seconds"]
            | {"calibration": c["seconds"], "camera": a["duration_seconds"]},
        },
    )


if __name__ == "__main__":
    main()
