"""Plot delivered response against false continuation on both retained wire sets."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from atlas_probe import ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_wide import HOLE, LENGTH, values
from measure_atlas import TIGHT
from render_atlas import LABELS


def main():
    ref = reference(ROOT / "results.json")
    doc = read_json(checked(ref))
    budget = str(TIGHT)
    fit = read_json(checked(doc["lock"]))["strengths"][budget]
    fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2), layout="constrained")
    styles = {
        "uniform": ("#2459a6", "o"),
        "dense": ("#087c61", "s"),
        "uniform_near": ("#a88d30", "v"),
        "near": ("#7373ad", "D"),
        "dense_donor": ("#b75265", "^"),
    }
    all_ = {}
    strengths = np.linspace(0, 2, 5)
    for key, ax, title in zip(
        ("long", "short"),
        axs,
        ("Long planted fundamental", "Short retained fundamental"),
        strict=True,
    ):
        rows = [a["width"][budget] for a in doc[key]]
        gaps = [a for a in rows if a["gap_pixels"]]
        all_[key] = {}
        for method, (color, mark) in styles.items():
            y = values(rows, "origin", LENGTH, 0).mean()
            x = values(gaps, "origin", HOLE, 0).mean()
            dose = fit[method]["gain"] * strengths
            response = [values(rows, method, LENGTH, g).mean() - y for g in dose]
            false = [values(gaps, method, HOLE, g).mean() - x for g in dose]
            all_[key][method] = {"delta_response_pp": response, "delta_false_DN16": false}
            ax.plot(false, response, label=LABELS[method], color=color, marker=mark)
        ax.axhline(0, color="#444444", linewidth=0.7)
        ax.axvline(0, color="#444444", linewidth=0.7)
        ax.grid(alpha=0.20)
        ax.set(title=title, xlabel="Change in false gap projection (DN16)")
    axs[0].set_ylabel("Change in signed response (percentage points)")
    axs[0].legend(loc="best", frameon=False, fontsize=8)
    fig.suptitle("Tight donor budget, relative to Corpus 100k")
    dest = ROOT / "response-curves.png"
    fig.savefig(dest, dpi=150, facecolor="white")
    plt.close(fig)
    write_json(
        ROOT / "plot.json",
        {
            "driver": reference(__file__),
            "results": ref,
            "budget": TIGHT,
            "strengths": strengths.tolist(),
            "curves": all_,
            "image": reference(dest),
        },
    )


if __name__ == "__main__":
    main()
