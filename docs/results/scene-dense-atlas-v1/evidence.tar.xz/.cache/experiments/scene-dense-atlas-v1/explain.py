"""Locate the selected donor patches and compare real peak delivery at equal correction."""

import numpy as np
from scipy.spatial.distance import cdist
import torch

from atlas_probe import (
    BAND,
    DENSE,
    POLICIES,
    ROOT,
    atlases,
    exact_query,
    load_standing,
    packed_scene,
    patch,
    peak_fit,
    replay,
)
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from render_wide import CAMERA_PEAKS


def selection(raw, colors, box, profile, bank, *, nearby):
    size = BAND.size
    yy, xx = np.meshgrid(
        np.arange(0, raw.shape[1] * 2 - size + 1, size // 2),
        np.arange(0, raw.shape[2] * 2 - size + 1, size // 2),
        indexing="ij",
    )
    coords = np.column_stack((yy.ravel(), xx.ravel()))
    basis = patch.patch_basis(tuple(colors), BAND)
    noise = tuple(profile[k] for k in ("shot", "read"))
    feat, _, _, _ = patch.encode(patch.sample_windows(raw, coords, size), basis, *noise)
    position = coords + np.asarray(box)[[1, 0]]
    d2 = cdist(position, bank.coords, "sqeuclidean")
    long = d2 / (4 * patch.SIZE) ** 2
    cost = cdist(feat, bank.features, "sqeuclidean")
    total = cost + (long if nearby else 0.25 * np.log1p(long))
    n = min(patch.NEIGHBORS, len(bank.coords))
    idx = np.argpartition(total, n - 1, axis=1)[:, :n]
    idx = np.take_along_axis(
        idx, np.argsort(np.take_along_axis(total, idx, axis=1), axis=1, kind="stable"), axis=1
    )
    # Match the default selection exactly before describing its geometry.
    d, w = patch.choose_exterior(feat, position, bank, nearby=nearby, ranked=True)
    np.testing.assert_array_equal(d, bank.normalized[idx])
    point = np.sqrt(np.take_along_axis(d2, idx, axis=1))
    hist = np.sum(w, axis=1)

    grid = 2 * np.pi * np.arange(size)
    tones = []
    for fx, fy in CAMERA_PEAKS:
        phase = fx * grid[None, :] + fy * grid[:, None]
        template = np.stack([np.cos(phase), np.sin(phase)])
        tones.append(np.linalg.qr(np.einsum("qyx,kyx->kq", template, basis.image))[0])
    output = {
        "mean_weighted_distance_px": float(np.sum(w * point) / w.sum()),
        "fraction_weight_at_96_px": float(np.sum(w * (point <= 96)) / w.sum()),
        "median_match_weight": float(np.median(hist)),
        "native_patch_count": len(coords),
    }
    power = []
    for subspace in tones:
        val = np.einsum("bngi,ik->bngk", d, subspace)
        raw_power = np.sum(val[:, :, 0] * val[:, :, 1], axis=-1)
        power.append(float(np.sum(w * raw_power) / w.sum()))
    return output | {"mean_selected_cross_power": power}


def main():
    torch.set_num_threads(2)
    digest = reference(ROOT / "camera-audit.json")
    numbers = read_json(checked(digest))
    base, saved, lookup = load_standing()
    assert numbers["prior"] == base and numbers["model"] == reference(patch.__file__)
    entries = [r for r in saved["rows"] if r["id"].startswith("mesh")]
    raw_ref, scene, colors = packed_scene(entries)
    out = []
    for row, notes in zip(entries, numbers["rows"][4:], strict=True):
        assert row["id"] == notes["id"] and row["raw"] == raw_ref
        raw, parent, roi, wb, matrix = exact_query(row, lookup, scene, colors)
        bank = atlases(scene, colors, row["query"], row["noise"])
        stats = {
            name: selection(raw, colors, row["query"], row["noise"], bank[key], nearby=near)
            for name, (key, near, k) in POLICIES.items()
            if k == "donor_and_query"
        }
        target = notes["rgb_change_DN16"]["uniform"]
        gains = {
            k: notes["strength"] * target / max(v, 1e-22)
            for k, v in notes["rgb_change_DN16"].items()
        }
        b = parent.astype(np.float64)
        with np.load(checked(notes["arrays"]), allow_pickle=False) as f:
            options = {k: replay.apply_delta(b, f[k], wb, matrix, q) for k, q in gains.items()}
        x, y, w, h = roi
        area = np.s_[..., y : y + h, x : x + w]
        for option in options.values():
            np.testing.assert_allclose(
                np.sqrt(np.mean((option[area] - b[area]) ** 2)) * 65535, target, atol=4e-5, rtol=0
            )
        matched = peak_fit(raw, b, options, colors, roi)
        parent_peak = matched["parent"]["percent_of_observed"]
        adjustment = {
            k: (np.asarray(v["percent_of_observed"]) - parent_peak).tolist()
            for k, v in matched.items()
            if k in POLICIES
        }
        out.append(
            {
                "id": row["id"],
                "selected_donors": stats,
                "match_RMS_DN16": target,
                "matched_peak_change_pp": adjustment,
                "gains": gains,
            }
        )
    write_json(
        ROOT / "attribution.json",
        {
            "driver": reference(__file__),
            "camera": digest,
            "scope": "Same-RAW peak projection with matched added RGB correction RMS. No independent reference is scored.",
            "rows": out,
        },
    )


if __name__ == "__main__":
    main()
