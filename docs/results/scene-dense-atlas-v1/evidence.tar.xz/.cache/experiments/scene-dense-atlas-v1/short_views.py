"""Show the stronger proximity policy on native crops from the short-wire transfer."""

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from measure_atlas import TIGHT, fields_for_observation
from render_atlas import LABELS, ROOT, native_board, noisy_malvar, replay
from evaluate_wide import COMP, HOLE, LENGTH, values


def main():
    torch.set_num_threads(2)
    proof = reference(ROOT / "results.json")
    data = read_json(checked(proof))
    names = ("uniform", "uniform_near")
    target = names[1]
    group = str(TIGHT)
    lock = read_json(checked(data["lock"]))
    s = {k: v["gain"] for k, v in lock["strengths"][group].items()}
    core = [r for r in data["short"] if r["width"][group]["gap_pixels"]]

    def change(r, metric):
        values_ = [values([r["width"][group]], k, metric, s[k])[0] for k in names]
        return float(values_[1] - values_[0])

    good = min(core, key=lambda r: change(r, COMP))
    adverse = max((r for r in core if r is not good), key=lambda r: change(r, HOLE))
    output = ROOT / "native/short"
    output.mkdir(parents=True)
    rows = []
    for case, note in (
        (good, "largest intact short-wave error reduction"),
        (adverse, "largest remaining extra false short projection"),
    ):
        row = case["case"]
        f, p, v = replay.read_inputs(row)
        gains, _ = fields_for_observation(row, f, p, TIGHT)
        camera = {k: f[k][None] for k in ("wb", "matrix", "colors")}
        malvar = noisy_malvar(camera | {"packed": f["packed"][:1]})[0]
        with np.load(checked(row["input"]), allow_pickle=False) as handle:
            gt = handle["target"][0]
        images = [malvar, v[0], p[0], *(p[0] + s[k] * gains[k][0] for k in names), gt]
        labels = (
            "Noisy Malvar",
            "V120 EMA",
            "Corpus 100k",
            *(LABELS[k] for k in names),
            "Exact GT",
        )
        rows.append(
            native_board(
                output,
                row["id"],
                images,
                camera,
                {
                    "source": row,
                    "strengths": s,
                    "role": "present",
                    "selection": note,
                    "change": {k: change(case, k) for k in (LENGTH, COMP, HOLE)},
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS[target]), 5),
                exposure=2,
                contrast=1,
                roi=(48, 48, 160, 160),
            )
        )
    write_json(
        ROOT / "short-views.json", {"driver": reference(__file__), "result": proof, "rows": rows}
    )


if __name__ == "__main__":
    main()
