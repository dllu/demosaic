"""Review dense exterior patches on the established GFX and exact-target crops."""

import argparse
from pathlib import Path
import sys

import numpy as np
import torch

from atlas_probe import POLICIES, ROOT, load_standing, pixels, render, replay
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_wide import HOLE, LENGTH, values
from measure_atlas import TIGHT, fields_for_observation
from render_wide import native_board, native_png

LABELS = {
    "uniform": "Uniform atlas",
    "dense": "Dense atlas",
    "uniform_near": "Uniform atlas, near ranks",
    "near": "Dense atlas, near ranks",
    "uniform_donor": "Uniform, donor check",
    "dense_donor": "Dense, donor check",
    "near_donor": "Dense near, donor check",
}


def cameras():
    lock = reference(ROOT / "camera-audit.json")
    a = read_json(checked(lock))
    base, camera, _ = load_standing()
    assert a["prior"] == base
    previous = {r["id"]: r for r in camera["rows"]}
    room = ROOT / "native/standing"
    room.mkdir(parents=True)
    proofs = []
    for r in a["rows"]:
        last = previous[r["id"]]
        with np.load(checked(r["arrays"]), allow_pickle=False) as f:
            p, wb, matrix = (f[k] for k in ("parent", "wb", "matrix"))
            outputs = {k: replay.apply_delta(p, f[k], wb, matrix, r["strength"]) for k in POLICIES}
        displays = []
        for frame in last["displays"]:
            exposure = frame["exposure"]
            views = pixels(frame["board"])
            np.testing.assert_array_equal(
                render(p, wb, matrix, r["ROI"], exposure), views["Corpus 100k"]
            )
            panels = [
                (k, views[k])
                for k in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Corpus 100k")
                if k in views
            ]
            panels.extend(
                (LABELS[k], render(x, wb, matrix, r["ROI"], exposure)) for k, x in outputs.items()
            )
            panels.extend(
                (k, views[k]) for k in ("ISO100 AHD reference", "ISO100 camera JPEG") if k in views
            )
            new = native_png(room / f"{r['id']}-x{exposure:g}.png", panels)
            displays.append({"exposure": exposure, "board": new})
        proofs.append(r | {"native_ROI": last["native_ROI"], "displays": displays})
    assert len(proofs) == 8 and sum(len(r["displays"]) for r in proofs) == 12
    write_json(room / "result.json", {"driver": reference(__file__), "audit": lock, "rows": proofs})


def exact_views():
    link = reference(ROOT / "results.json")
    d = read_json(checked(link))
    calibration = read_json(checked(d["lock"]))
    strength = {k: v["gain"] for k, v in calibration["strengths"][str(TIGHT)].items()}
    room = ROOT / "native/exact"
    room.mkdir(parents=True)
    grouped = [r for r in d["long"] if r["width"][str(TIGHT)]["gap_pixels"]]
    wide = "dense"
    origin = "uniform"

    def difference(r, metric):
        v = r["width"][str(TIGHT)]
        return float(
            values([v], wide, metric, strength[wide])[0]
            - values([v], origin, metric, strength[origin])[0]
        )

    best = max(grouped, key=lambda r: difference(r, LENGTH))
    cost = max((r for r in grouped if r is not best), key=lambda r: difference(r, HOLE))
    results = []
    for item, note in (
        (best, "largest long-wave response advantage"),
        (cost, "largest false long projection increase in the other gaps"),
    ):
        row = item["case"]
        fields, base, v120 = replay.read_inputs(row)
        updates, _ = fields_for_observation(row, fields, base, TIGHT)
        camera = {k: fields[k][None] for k in ("colors", "wb", "matrix")}
        with np.load(checked(row["input"]), allow_pickle=False) as f:
            exact = f["target"]
        methods = ("uniform", "dense", "near", "dense_donor")
        outputs = {k: base + strength[k] * updates[k] for k in methods}
        for role, name in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(camera | {"packed": fields["packed"][role : role + 1]})[0]
            labels = (
                "Noisy Malvar",
                "V120 EMA",
                "Corpus 100k",
                *(LABELS[k] for k in methods),
                "Exact GT",
            )
            imgs = [
                noisy,
                v120[role],
                base[role],
                *(outputs[k][role] for k in methods),
                exact[role],
            ]
            record = {
                "source": row,
                "role": name,
                "budget": TIGHT,
                "strengths": strength,
                "method": wide,
                "selection": note,
                "response_change": difference(item, LENGTH),
                "false_long_change_DN16": difference(item, HOLE),
            }
            b = native_board(
                room,
                f"{row['id']}-{name}",
                imgs,
                camera,
                record,
                labels=labels,
                triplet_indices=(0, labels.index(LABELS[wide]), len(labels) - 1),
                exposure=2,
                contrast=1,
                roi=(48, 48, 160, 160),
            )
            results.append(b)
    write_json(
        room / "result.json",
        {"driver": reference(__file__), "results": link, "lock": d["lock"], "rows": results},
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=("camera", "exact"))
    a = p.parse_args()
    cameras() if a.stage == "camera" else exact_views()
