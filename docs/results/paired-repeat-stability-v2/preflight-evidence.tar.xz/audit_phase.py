"""Audit joint ISO/CFA exposure and phase-stratify fixed earlier evaluation."""
from collections import Counter
import json
from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "paired-luminance-detail-v1"
SCENE = ROOT.parent / "scene-local-contrast-2400-v1"
PROFILES = ("iso400", "iso6400")
METHODS = ("absolute", "paired", "intersection-paired")
ERRORS = ("increment_RMS_DN16", "quiet_RMS_DN16", "present_RMS_DN16")


def audit():
    old = read_json(PRIOR / "training/complete.json")
    schedule = checked(old["observations"])
    distribution = Counter()
    with schedule.open() as stream:
        for line in stream:
            row = json.loads(line)
            for sample in row["samples"]:
                profile = min((8e-5, .00128), key=lambda center: abs(np.log(sample["profile"]["shot"]/center)))
                distribution["iso400" if profile < 1e-4 else "iso6400",
                             sample["pattern"], sample["coupling"]] += 1
    assert sum(distribution.values()) == old["distinct_photos"] == 2400
    counts = {
        iso: {cfa: {"coupled": distribution[iso, cfa, "shared counts and read draw"],
                    "independent": distribution[iso, cfa, "independent"]}
              for cfa in PATTERNS}
        for iso in PROFILES
    }
    planned = read_json(SCENE / "evaluation-plan.json")
    phases = {row["source"]["id"]: row["camera"]["pattern"] for row in planned["rows"]}
    results_path = PRIOR / "endpoint/short-guard/results.json"
    results = read_json(results_path)["rows"]
    assert len(results) == 256
    rng = np.random.default_rng(12240875325)
    metrics = {}
    for iso in PROFILES:
        for draw in ("coupled", "independent"):
            rows = [row for row in results if row["profile"] == iso and row["draw"] == draw]
            for method in METHODS:
                for cfa in (*PATTERNS, "seen-pair", "missing-pair"):
                    if cfa in PATTERNS:
                        selected = [row for row in rows if phases[row["source"]] == cfa]
                    else:
                        subset = {code for code, vals in counts[iso].items()
                                  if bool(sum(vals.values())) == (cfa == "seen-pair")}
                        selected = [row for row in rows if phases[row["source"]] in subset]
                    assert len(selected) == (16 if cfa in PATTERNS else 32)
                    seed = rng.integers(len(selected), size=(4000, len(selected)))
                    f = lambda r, key: r["metrics"][key]["band"]["fine"]
                    power = np.array([f(row, "100k")["exact_paired_increment_sq"] for row in selected])
                    effect = np.array([f(row, method)["aligned_increment_dot"] -
                                       f(row, "100k")["aligned_increment_dot"] for row in selected])
                    per_error = np.array([[f(row, method)[key] - f(row, "100k")[key] for key in ERRORS]
                                          for row in selected])
                    lower, upper = np.quantile(per_error[seed].mean(axis=1), [.025, .975], axis=0)
                    table = {
                        "n": len(selected),
                        "aligned_response_delta_pp": float(100 * effect.sum() / power.sum()),
                        "95pct_aligned_response_delta_pp": np.quantile(
                            100*effect[seed].sum(axis=1)/power[seed].sum(axis=1), [.025, .975]
                        ).tolist(),
                        "error_delta_DN16": dict(zip(ERRORS, per_error.mean(axis=0).tolist(), strict=True)),
                        "95pct_error_delta_DN16": dict(zip(ERRORS, np.stack((lower, upper), axis=1).tolist(), strict=True)),
                    }
                    metrics.setdefault(iso, {}).setdefault(draw, {}).setdefault(method, {})[cfa] = table
    write_json(ROOT/"prior-phase-audit.json", {
        "driver": reference(__file__), "complete_training": reference(PRIOR/"training/complete.json"),
        "training_observations": old["observations"],
        "prior_photo_metrics": reference(results_path), "panel": reference(SCENE/"evaluation-plan.json"),
        "training_joint_exposure_by_ISO_CFA": counts, "evaluation_effects": metrics,
        "scope": "Bayer layout is associated with photo identity in the fixed panel. Phase subgroup differences are descriptive and leave CFA, subject and clean target contrast unmatched between groups.",
    })
    for iso, section in metrics.items():
        for draw, methods in section.items():
            print(iso, draw)
            for key, v in methods["intersection-paired"].items():
                print(key, round(v["aligned_response_delta_pp"],4),
                      [round(x, 4) for x in v["95pct_aligned_response_delta_pp"]],
                      round(v["error_delta_DN16"][ERRORS[0]],4),
                      [round(x, 4) for x in v["95pct_error_delta_DN16"][ERRORS[0]]])


if __name__ == "__main__":
    audit()
