"""Measure single-frame predictions across three independent redraws of each target."""
import argparse
from collections import defaultdict
import os
from pathlib import Path
import time

import numpy as np
import psutil
import torch

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.paired_detail import PairedLuminanceDetail
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from train_repeat import ARGS, PRIOR, ROOT, SCENE, WEIGHTS
from prepare_repeat import previous_case
from evaluate import setup_models
from local_guard import paired_gates
from measure import BANDS, LUMA, coeffs

LABELS = ("V120", "100k", "paired-init", *WEIGHTS)
OUTPUT_KEYS = (*ARGS, "target")


def load_rows():
    plan_ref = reference(ROOT / "evaluation-plan.json")
    documents = [reference(ROOT / f"observation-shard-{shard}.json") for shard in range(2)]
    rows = []
    for document in documents:
        data = read_json(checked(document))
        assert data["plan"] == plan_ref
        rows += data["rows"]
    rows.sort(key=lambda row: row["id"])
    assert len(rows) == len({row["id"] for row in rows}) == 384
    return rows, documents


def packed_inputs(case, repeat):
    item = case["draws"][repeat]
    if item["original"] is None:
        with np.load(checked(item["file"]), allow_pickle=False) as saved:
            arrays = {key: saved[key] for key in OUTPUT_KEYS}
    else:
        arrays, origin, _ = previous_case(case["index"], case["profile"], case["coupling"])
        assert origin == item["original"]
    assert {k: fingerprint(a) for k, a in arrays.items()} == item["fingerprints"]
    return arrays


def as_cuda(arrays):
    fields = [torch.from_numpy(np.ascontiguousarray(arrays[k]).copy()).cuda() for k in ARGS]
    for index in range(2):
        fields[index] = fields[index].contiguous(memory_format=torch.channels_last)
    return fields


def base_forward(parent, args, profile):
    parent.set_noise(profile["shot"], profile["read"])
    return parent(*args)


@torch.inference_mode()
def cache_upstream():
    training = read_json(ROOT / "plan.json")
    oldeval = read_json(SCENE / "evaluation/plan.json")
    models = {k: oldeval["models"][k] for k in ("V120", "100k")}
    assert training["models"]["Corpus 100k"] == models["100k"]
    rows, archives = load_rows()
    product = ROOT / "parent-predictions"
    product.mkdir()
    plan = product / "plan.json"
    write_json(plan, {
        "driver": reference(__file__), "observations": archives,
        "models": models, "evaluation": reference(ROOT / "evaluation-plan.json"),
        "previous_draw0_receipt": reference(SCENE / "evaluation/plan.json"),
        "precision": "CUDA IEEE FP32 or identical archived replay",
    })
    began = time.monotonic()
    nets = setup_models({"models": models})
    ledger = []
    with ieee_fp32():
        for index, case in enumerate(rows):
            samples = []
            for repeat in range(len(case["draws"])):
                if case["draws"][repeat]["original"] is None:
                    fields = as_cuda(packed_inputs(case, repeat))
                    computed = {
                        k: base_forward(model, fields, case["profile"]).cpu().numpy()
                        for k, model in nets.items()
                    }
                    path = product / f"{case['id']}-r{repeat}.npz"
                    with path.open("xb") as stream:
                        np.savez(stream, **computed)
                    item = {"saved": reference(path), "reused": None}
                else:
                    receipt = reference(SCENE / "evaluation/predictions" / (case["id"] + ".json"))
                    legacy = read_json(checked(receipt))
                    assert legacy["case"] == case["draws"][repeat]["original"]
                    assert legacy["plan"] == reference(SCENE / "evaluation/plan.json")
                    assert legacy["exact_query_inputs"] == {k: case["draws"][repeat]["fingerprints"][k]
                                                           for k in ARGS}
                    item = {"saved": legacy["saved"], "reused": receipt}
                samples.append(item)
            ledger.append({"id": case["id"], "predictions": samples})
            if (index + 1) % 16 == 0:
                print("base", index + 1, round(time.monotonic() - began, 1), flush=True)
    write_json(product / "complete.json", {
        "plan": reference(plan), "rows": ledger, "seconds": time.monotonic() - began,
        "calculated": sum(x["reused"] is None for r in ledger for x in r["predictions"]),
        "reused": sum(x["reused"] is not None for r in ledger for x in r["predictions"]),
    })


def read_parent(receipt, classes=("V120", "100k")):
    with np.load(checked(receipt["saved"]), allow_pickle=False) as archive:
        return {key: archive[key] for key in classes}


def head(buffer, key):
    module = PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).eval()
    module.load_state_dict(buffer["weights"][key]["ema"], strict=True)
    return module


def prepare_heads(training, checkpoint):
    control = torch.load(checked(training["initial_head"]), map_location="cpu", weights_only=True)
    models = {"paired-init": head(control, "paired")}
    if checkpoint:
        state = torch.load(checked(checkpoint), map_location="cpu", weights_only=True)
        assert state["plan"] == reference(ROOT / "plan.json") and state["parent_frozen"]
        models.update({name: head(state, name) for name in WEIGHTS})
    return models


def inputs_with_calibration(args, parents):
    parent = torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    wb, matrix = args[-2:]
    neutral = torch.linalg.solve(matrix, torch.ones_like(wb).unsqueeze(-1)).squeeze(-1) / wb
    return parent, neutral


def predictions(models, args, parents, cutoff):
    parent, neutral = inputs_with_calibration(args, parents)
    _, weight = paired_gates(*args[:3], *cutoff)
    return parents | {
        name: (parent + neutral[:, :, None, None] * model.luminance_delta(parent, *args) * weight).cpu().numpy()
        for name, model in models.items()
    }


def contributions(coefficients, target, mask):
    truth = target[0][:, mask] - target[1][:, mask]
    actual = coefficients[:, 0][:, :, mask] - coefficients[:, 1][:, :, mask]
    errors = actual - truth[None]
    scale = 65535**2 / (36 * 16 * 16)
    actual_rms = np.sqrt(np.sum(errors**2, axis=(1, 2)) * scale)
    square = np.mean(actual_rms**2)
    variation = np.sum(errors.var(axis=0, ddof=1)) * scale
    products = [np.sum(errors[a] * errors[b]) for a, b in ((0, 1), (0, 2), (1, 2))]
    shared = np.mean(products) * scale
    np.testing.assert_allclose(square, shared + variation, rtol=1e-13, atol=1e-9)
    quiet = coefficients[:, 2][:, :, mask]
    assert np.max(abs(target[2][:, mask])) < 1e-14
    return {
        "aligned_dot": float(np.sum(actual.mean(axis=0) * truth)),
        "clean_power": float(np.sum(truth**2)),
        "mean_increment_RMS_DN16": float(actual_rms.mean()),
        "mean_quiet_RMS_DN16": float(np.sqrt(np.sum(quiet**2, axis=(1, 2)) * scale).mean()),
        "mean_present_RMS_DN16": float(np.sqrt(np.sum(
            (coefficients[:, 0][:, :, mask] - target[None, 0][:, :, mask])**2,
            axis=(1, 2)
        ) * scale).mean()),
        "increment_MSE_DN16_squared": float(square),
        "shared_error_product_DN16_squared": float(shared),
        "swapped_draw_variance_DN16_squared": float(variation),
        "repeat_increment_RMS_DN16": actual_rms.tolist(),
    }


def channel_coefficients(output, field, roi):
    image = linear_rgb(output, field)
    luma = np.einsum("c,bchw->bhw", LUMA, image)
    return image, coeffs(luma, roi)


def score_triplet_sets(sets, target, fields, roi):
    exact_rgb, exact_coeff = channel_coefficients(target, fields, roi)
    x, y, w, h = roi
    core = np.s_[..., y:y+h, x:x+w]
    result = {}
    for method in sets[0]:
        values = [channel_coefficients(predictions[method], fields, roi) for predictions in sets]
        rgb = np.stack([r[0][2][core] for r in values])
        coefficients = np.stack([r[1] for r in values])
        delta = rgb - exact_rgb[2][core]
        bias = delta.mean(axis=(-2, -1), keepdims=True)
        result[method] = {band: contributions(coefficients, exact_coeff, mask) for band, mask in BANDS.items()}
        result[method]["flat_color"] = {
            "mean_worst_channel_abs_bias_DN16": float(65535 * abs(bias).max(axis=(1, 2, 3)).mean()),
            "mean_centered_RGB_RMS_DN16": float(65535 * np.sqrt(
                np.mean((delta - bias)**2, axis=(1, 2, 3))
            ).mean()),
        }
    return result


def bind_upstream():
    rows, archives = load_rows()
    parent_path = ROOT / "parent-predictions/complete.json"
    parent = read_json(parent_path)
    parents = read_json(checked(parent["plan"]))
    assert parents["observations"] == archives and parents["evaluation"] == reference(ROOT / "evaluation-plan.json")
    upstream = {row["id"]: row["predictions"] for row in parent["rows"]}
    assert upstream.keys() == {case["id"] for case in rows}
    return parent_path, parents, upstream, rows


@torch.inference_mode()
def score(stage):
    folder = ROOT / stage
    folder.mkdir()
    parent_path, parents, upstream, rows = bind_upstream()
    scenario = read_json(ROOT / "evaluation-plan.json")
    training = read_json(ROOT / "plan.json")
    if stage == "starting":
        checkpoint = None
        num = 0
    elif stage == "midpoint":
        checkpoint = reference(ROOT / "training/step000300.pt")
        num = 300
    else:
        done = read_json(ROOT / "training/complete.json")
        checkpoint = done["head_checkpoint"]
        num = done["updates"]
        assert num == training["steps"]
    models = prepare_heads(training, checkpoint)
    cutoff = (read_json(checked(training["guard"]))["threshold"],
              read_json(checked(training["guard_long"]))["threshold_0_to_1"][0])
    plan = folder / "plan.json"
    write_json(plan, {
        "driver": reference(__file__), "stage": stage, "step": num,
        "initial_head": training["initial_head"], "endpoint": checkpoint,
        "parents": reference(parent_path), "parent_models": parents["models"],
        "guard": training["guard"], "training": reference(ROOT / "plan.json"),
    })
    began = time.monotonic()
    outs = []
    with ieee_fp32():
        for case in rows:
            if stage == "midpoint" and (case["profile"]["name"] != "iso6400" or case["index"] not in range(16)):
                continue
            images = []
            for repeat, base in enumerate(upstream[case["id"]]):
                arrays = packed_inputs(case, repeat)
                fields = as_cuda(arrays)
                images.append(predictions(models, fields, read_parent(base), cutoff))
            fields = {k: arrays[k] for k in ("matrix", "wb")}
            fields["exposure"] = case["profile"]["exposure"]
            metrics = score_triplet_sets(images, arrays["target"], fields, scenario["score_ROI_xywh"])
            outs.append({
                "id": case["id"], "source": case["source"], "index": case["index"],
                "cohort": case["cohort"], "profile": case["profile"]["name"],
                "coupling": case["coupling"], "metrics": metrics,
            })
            if len(outs) % 16 == 0:
                print(stage, len(outs), round(time.monotonic() - began, 1), flush=True)
    assert len(outs) == (32 if stage == "midpoint" else 384)
    write_json(folder / "results.json", {
        "plan": reference(plan), "rows": outs, "seconds": time.monotonic() - began,
        "scope": "3 independent complete observations for each fixed within-pair coupling law. Each predictor sees one observation at a time.",
    })


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("base", "starting", "midpoint", "endpoint"))
    action = p.parse_args().action
    os.sched_setaffinity(0, [14, 15])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1., 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    if action == "base":
        cache_upstream()
    else:
        score(action)


if __name__ == "__main__":
    main()
