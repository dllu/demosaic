"""Test if the early repeat effect exceeds an ordinary reduction in correction strength."""
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_repeat import (
    as_cuda, bind_upstream, channel_coefficients, contributions, packed_inputs, predictions,
    prepare_heads, read_parent,
)
from measure import BANDS
from strength_sweep import contrast_curve
from train_repeat import ROOT


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [16,18])
    os.nice(12)
    torch.set_num_threads(2)
    train = read_json(ROOT/"plan.json")
    plan = read_json(ROOT/"evaluation-plan.json")
    midpoint = read_json(ROOT/"mid16-iso6400.json")
    snapshot = midpoint["midpoint"]
    models = prepare_heads(train,snapshot)
    guard = (read_json(checked(train["guard"]))["threshold"],
             read_json(checked(train["guard_long"]))["threshold_0_to_1"][0])
    archive, _, parents, source_data = bind_upstream()
    selected = [case for case in source_data if case["index"]<16 and case["profile"]["name"]=="iso6400"]
    assert len(selected)==32
    started = time.monotonic()
    prepared = {}
    for row in selected:
        per_repeat = []
        with ieee_fp32():
            for repeat, bound in enumerate(parents[row["id"]]):
                view = packed_inputs(row,repeat)
                pred = predictions(models,as_cuda(view),read_parent(bound,classes=("100k",)),guard)
                per_repeat.append({k:channel_coefficients(v,view,plan["score_ROI_xywh"])[1] for k,v in pred.items()})
        target=channel_coefficients(view["target"],view,plan["score_ROI_xywh"])[1]
        values={key:np.stack([v[key] for v in per_repeat]) for key in pred}
        scores={key:contributions(value,target,BANDS["fine"]) for key,value in values.items()}
        prepared[row["id"]]=(row["coupling"],values,target,scores)
    report={}
    rng=np.random.default_rng(34247598)
    for draw in ("coupled","independent"):
        raw={k:(v[1],v[2],v[3]) for k,v in prepared.items() if v[0]==draw}
        for key in ("repeat025","repeat075"):
            gain=lambda arm: sum(s[arm]["aligned_dot"]-s["100k"]["aligned_dot"] for _,_,s in raw.values())
            alpha=gain(key)/gain("control")
            assert 0<=alpha<=1
            reduced={
                ident:contributions(v["100k"]+alpha*(v["control"]-v["100k"]),target,BANDS["fine"])
                for ident,(v,target,scores) in raw.items()
            }
            trained={ident:scores[key] for ident,(_,_,scores) in raw.items()}
            contrast=contrast_curve(trained,reduced,rng)
            assert abs(contrast["response_percentage_points"]["delta"])<1e-12
            report.setdefault(draw,{})[key]={
                "control_strength_meeting_same_aligned_response":alpha,
                "trained_minus_scaled_control":contrast,
            }
    write_json(ROOT/"mid16-strength.json",{
        "driver":reference(__file__),"pilot":reference(ROOT/"mid16-iso6400.json"),
        "parent_archive":reference(archive),"results":report,
        "scope":"Descriptive panel-wide scalar reduction of matched control, chosen using the exact targets on the same 16 scored sources. Resampling holds that scalar fixed. The trained production policy remains single-frame and does not use this scale.",
        "seconds":time.monotonic()-started,
    })


if __name__=="__main__":
    run()
