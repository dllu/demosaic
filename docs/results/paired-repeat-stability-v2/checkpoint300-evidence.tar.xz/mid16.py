"""Check the prespecified first 16 held-out ISO6400 sources at 300 updates."""
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_repeat import as_cuda, load_rows, packed_inputs, predictions, prepare_heads, read_parent
from evaluate_repeat import score_triplet_sets
from summarize import METHODS, summarize_group
from train_repeat import ROOT, SCENE


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [16, 18])
    os.nice(12)
    torch.set_num_threads(2)
    rows, shards = load_rows()
    eval_plan = read_json(ROOT / "evaluation-plan.json")
    common = read_json(ROOT / "plan.json")
    base_dir = ROOT / "parent-predictions"
    base_plan = read_json(base_dir / "plan.json")
    assert base_plan["observations"] == shards
    assert base_plan["models"]["100k"] == common["models"]["Corpus 100k"]
    milestone = reference(ROOT / "training/step000300.pt")
    models = prepare_heads(common, milestone)
    thresholds = (read_json(common["guard"]["path"])["threshold"],
                  read_json(common["guard_long"]["path"])["threshold_0_to_1"][0])
    start = time.monotonic()
    selected = [case for case in rows if case["index"] < 16 and case["profile"]["name"] == "iso6400"]
    assert len(selected) == 32
    scored = []
    observations = []
    with ieee_fp32():
        for case in selected:
            values = []
            files = []
            for repeat in range(3):
                arrays = packed_inputs(case, repeat)
                if repeat == 0:
                    origin = read_json(SCENE / "evaluation/predictions" / (case["id"] + ".json"))
                    assert origin["case"] == case["draws"][repeat]["original"]
                    base = origin["saved"]
                else:
                    base = reference(base_dir / f"{case['id']}-r{repeat}.npz")
                parents = read_parent({"saved": base})
                values.append(predictions(models, as_cuda(arrays), parents, thresholds))
                files.append(base)
            reference_inputs = {k: arrays[k] for k in ("matrix", "wb")}
            metrics = score_triplet_sets(values, arrays["target"], reference_inputs, eval_plan["score_ROI_xywh"])
            scored.append({"id": case["id"], "source": case["source"], "coupling": case["coupling"],
                           "metrics": metrics})
            observations.append({"id": case["id"], "base": files})
            if len(scored) % 16 == 0:
                print(len(scored), round(time.monotonic()-start, 2), flush=True)
    rng = np.random.default_rng(7403199722)
    tables = {
        law: summarize_group([v for v in scored if v["coupling"] == law], METHODS, rng)
        for law in ("coupled", "independent")
    }
    write_json(ROOT/"mid16-iso6400.json", {
        "driver": reference(__file__), "midpoint": milestone, "training_plan": reference(ROOT/"plan.json"),
        "evaluation_plan": reference(ROOT/"evaluation-plan.json"),
        "parent_plan": reference(base_dir/"plan.json"), "observation_shards": shards,
        "sources": scored, "tables": tables, "parent_arrays": observations,
        "scope": "Scheduled 300-update checkpoint, first 16 original ISO6400 sources. Three independent redraws per within-pair law. Pilot descriptive; endpoint evaluation remains active.",
        "seconds": time.monotonic()-start,
    })


if __name__ == "__main__":
    run()
