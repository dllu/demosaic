"""Compare the aligned-detail/noise frontier of the frozen repeat-training arms."""
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_repeat import (
    as_cuda, bind_upstream, channel_coefficients, contributions, packed_inputs, predictions,
    prepare_heads, read_parent,
)
from measure import BANDS
from train_repeat import ROOT

STRENGTHS = (0., .25, .5, .75, 1., 1.25)
METHODS = ("paired-init", "control", "repeat025", "repeat075")
KEYS = (
    "mean_increment_RMS_DN16", "mean_quiet_RMS_DN16",
    "shared_error_product_DN16_squared", "swapped_draw_variance_DN16_squared",
)


def contrast_curve(rows, controls, rng):
    assert controls.keys() == rows.keys()
    ids = sorted(controls)
    n = len(ids)
    bootstrap = rng.integers(n, size=(4000, n))
    power = np.array([controls[i]["clean_power"] for i in ids])
    dot = np.array([rows[i]["aligned_dot"] - controls[i]["aligned_dot"] for i in ids])
    values = np.array([[rows[i][k] - controls[i][k] for k in KEYS] for i in ids])
    boot = values[bootstrap].mean(axis=1)
    points = np.c_[100*dot[bootstrap].sum(axis=1)/power[bootstrap].sum(axis=1),boot]
    observed = np.r_[100*dot.sum()/power.sum(), values.mean(axis=0)]
    bounds = np.quantile(points, [.025,.975], axis=0).T
    return {
        k: {"delta": float(mid), "paired_95pct": ci.tolist()}
        for k,mid,ci in zip(("response_percentage_points",*KEYS),observed,bounds,strict=True)
    }


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    torch.set_num_threads(2)
    train = read_json(ROOT/"plan.json")
    data = read_json(ROOT/"evaluation-plan.json")
    endpoint = read_json(ROOT/"endpoint/plan.json")
    complete = read_json(ROOT/"training/complete.json")
    assert endpoint["endpoint"] == complete["head_checkpoint"]
    models = prepare_heads(train, endpoint["endpoint"])
    cutoffs = (read_json(checked(train["guard"]))["threshold"],
               read_json(checked(train["guard_long"]))["threshold_0_to_1"][0])
    parent_path, _, current, rows = bind_upstream()
    assert endpoint["parents"]==reference(parent_path)
    rng = np.random.default_rng(5947353)
    cube = {}
    selected = [row for row in rows if row["profile"]["name"]=="iso6400"]
    assert len(selected) == 192
    began = time.monotonic()
    roi = data["score_ROI_xywh"]
    fine = BANDS["fine"]
    with ieee_fp32():
        for index, row in enumerate(selected):
            samples = []
            for repeat, ref in enumerate(current[row["id"]]):
                native = packed_inputs(row,repeat)
                observed = predictions(models,as_cuda(native),read_parent(ref,classes=("100k",)),cutoffs)
                sample = {
                    key: channel_coefficients(value,native,roi)[1]
                    for key,value in observed.items()
                }
                samples.append(sample)
            truth = channel_coefficients(native["target"],native,roi)[1]
            base = np.stack([view["100k"] for view in samples])
            coeffs = {}
            for label in METHODS:
                correction = np.stack([view[label] for view in samples])-base
                coeffs[label] = {
                    str(level): contributions(base + level*correction,truth,fine)
                    for level in STRENGTHS
                }
            cube[row["id"]] = {"cohort": row["cohort"],"coupling": row["coupling"],"sweep": coeffs,
                               "base": contributions(base,truth,fine)}
            if (index+1)%24==0:
                print(index+1,round(time.monotonic()-began,1),flush=True)
    report = {}
    for draw in ("coupled","independent"):
        for cohort in ("all","original64","fresh32"):
            filt = {k:v for k,v in cube.items() if v["coupling"]==draw and
                    (cohort=="all" or cohort==v["cohort"])}
            base = {k:v["base"] for k,v in filt.items()}
            results = {}
            for method in METHODS:
                evaluation = {}
                for level in STRENGTHS:
                    candidates = {k:v["sweep"][method][str(level)] for k,v in filt.items()}
                    evaluation[str(level)] = contrast_curve(candidates,base,rng)
                results[method]=evaluation
            report.setdefault(draw,{})[cohort]=results
    write_json(ROOT/"endpoint/strength-sweep.json",{
        "driver": reference(__file__), "endpoint": reference(ROOT/"endpoint/plan.json"),
        "intended_scope": "Descriptive strength curves on common single-frame evaluation inputs, no evaluation-set choice of a production strength.",
        "seconds": time.monotonic()-began, "rows": cube,"scores": report,
    })


if __name__=="__main__":
    run()
