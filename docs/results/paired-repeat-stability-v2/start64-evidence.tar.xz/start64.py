"""Read the completed ISO6400 parent files for the original64 while fresh inputs collect."""
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_repeat import as_cuda, load_rows, packed_inputs, predictions, prepare_heads, read_parent
from evaluate_repeat import score_triplet_sets
from summarize import summarize_group
from train_repeat import ROOT, SCENE


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [16, 18])
    os.nice(12)
    torch.set_num_threads(2)
    rows, shards = load_rows()
    eval_plan = read_json(ROOT / "evaluation-plan.json")
    common = read_json(ROOT / "plan.json")
    base_dir = ROOT / "parent-predictions"
    base_plan = read_json(base_dir / "plan.json")
    assert base_plan["observations"] == shards
    assert base_plan["models"]["100k"] == common["models"]["Corpus 100k"]
    models = prepare_heads(common, None)
    thresholds = (read_json(common["guard"]["path"])["threshold"],
                  read_json(common["guard_long"]["path"])["threshold_0_to_1"][0])
    start = time.monotonic()
    selected = [case for case in rows if case["cohort"] == "original64" and case["profile"]["name"] == "iso6400"]
    assert len(selected) == 128
    scored = []
    observations = []
    with ieee_fp32():
        for case in selected:
            values = []
            files = []
            for repeat in range(3):
                arrays = packed_inputs(case, repeat)
                if repeat == 0:
                    origin = read_json(SCENE / "evaluation/predictions" / (case["id"] + ".json"))
                    assert origin["case"] == case["draws"][repeat]["original"]
                    base = origin["saved"]
                else:
                    base = reference(base_dir / f"{case['id']}-r{repeat}.npz")
                parents = read_parent({"saved": base})
                values.append(predictions(models, as_cuda(arrays), parents, thresholds))
                files.append(base)
            reference_inputs = {k: arrays[k] for k in ("matrix", "wb")}
            metrics = score_triplet_sets(values, arrays["target"], reference_inputs, eval_plan["score_ROI_xywh"])
            scored.append({"id": case["id"], "source": case["source"], "coupling": case["coupling"],
                           "metrics": metrics})
            observations.append({"id": case["id"], "base": files})
            if len(scored) % 16 == 0:
                print(len(scored), round(time.monotonic()-start, 2), flush=True)
    rng = np.random.default_rng(7403199722)
    tables = {
        law: summarize_group([v for v in scored if v["coupling"] == law], ("V120", "100k", "paired-init"), rng)
        for law in ("coupled", "independent")
    }
    write_json(ROOT/"starting64-iso6400.json", {
        "driver": reference(__file__), "training_plan": reference(ROOT/"plan.json"),
        "evaluation_plan": reference(ROOT/"evaluation-plan.json"),
        "parent_plan": reference(base_dir/"plan.json"), "observation_shards": shards,
        "sources": scored, "tables": tables, "parent_arrays": observations,
        "scope": "Existing paired head before continuation. 64 original exact-target photos at ISO6400 only. Decompose draw error separately for three independent complete redraws of each fixed within-pair law.",
        "seconds": time.monotonic()-start,
    })


if __name__ == "__main__":
    run()
