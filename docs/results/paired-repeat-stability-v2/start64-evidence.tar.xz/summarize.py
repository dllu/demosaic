"""Pool complete-draw weak-detail error and compare endpoints with source resampling."""
import argparse
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
METHODS = ("V120", "100k", "paired-init", "control", "repeat025", "repeat075")
BANDS = ("lower", "fine", "upper")
METRICS = (
    "mean_increment_RMS_DN16",
    "mean_quiet_RMS_DN16",
    "mean_present_RMS_DN16",
    "increment_MSE_DN16_squared",
    "shared_error_product_DN16_squared",
    "swapped_draw_variance_DN16_squared",
)
COLOR = ("mean_worst_channel_abs_bias_DN16", "mean_centered_RGB_RMS_DN16")


def wrap(values):
    return {"mean_delta": float(values[0]), "percentiles_95": np.quantile(values[1:], [.025, .975]).tolist()}


def summarize_group(rows, methods, rng):
    assert len(rows) >= 8
    repeats = rng.integers(len(rows), size=(4000, len(rows)))
    table = {band: {} for band in (*BANDS, "flat_color")}
    per_band = {}
    for band, metrics in *((name, METRICS) for name in BANDS), ("flat_color", COLOR):
        block = {
            method: np.array([[row["metrics"][method][band][key] for key in metrics] for row in rows])
            for method in methods
        }
        per_band[band] = block
        for method, values in block.items():
            observed = values.mean(axis=0)
            table[band][method] = {name: float(item) for name, item in zip(metrics, observed, strict=True)}
            if band != "flat_color":
                table[band][method]["quiet_RMS_source_p90_DN16"] = float(np.quantile(values[:, 1], .9))
                table[band][method]["increment_RMS_source_p90_DN16"] = float(np.quantile(values[:, 0], .9))
    comparisons = {}
    baseline = {}
    for band in BANDS:
        powers = np.array([row["metrics"]["100k"][band]["clean_power"] for row in rows])
        crosses = {
            name: np.array([row["metrics"][name][band]["aligned_dot"] for row in rows]) for name in methods
        }
        baseline[band] = powers, crosses
        for method, values in crosses.items():
            table[band][method]["target_aligned_response"] = float(values.sum() / powers.sum())
    for method in methods:
        contrasts = list(dict.fromkeys(("100k", "paired-init", "control" if "control" in methods else "100k")))
        for control in contrasts:
            if control == method:
                continue
            columns = {}
            for band, metrics in (*((name, METRICS) for name in BANDS), ("flat_color", COLOR)):
                block = per_band[band]
                deltas = block[method] - block[control]
                samples = np.concatenate((deltas.mean(axis=0)[None], deltas[repeats].mean(axis=1)), axis=0)
                cols = {name: wrap(samples[:, i]) for i, name in enumerate(metrics)}
                if band != "flat_color":
                    powers, crosses = baseline[band]
                    diff = crosses[method] - crosses[control]
                    rates = np.r_[diff.sum() / powers.sum(), diff[repeats].sum(axis=1) / powers[repeats].sum(axis=1)]
                    cols["aligned_response_fraction"] = wrap(rates)
                columns[band] = cols
            comparisons[f"{method}-vs-{control}"] = columns
    return {"sources": len(rows), "table": table, "contrasts": comparisons}


def summarize(stage):
    result = ROOT / stage / "results.json"
    doc = read_json(result)
    plan = read_json(checked(doc["plan"]))
    assert plan["stage"] == stage
    rows = doc["rows"]
    methods = METHODS if stage != "starting" else METHODS[:3]
    rng = np.random.default_rng(183977937)
    cells = {}
    profiles = sorted({r["profile"] for r in rows})
    for profile in profiles:
        for draw in ("coupled", "independent"):
            included = [r for r in rows if (r["profile"], r["coupling"]) == (profile, draw)]
            for cohort in ("all", "original64", "fresh32"):
                group = [r for r in included if cohort == "all" or cohort == r["cohort"]]
                if not group:
                    continue
                ranked = sorted(group, key=lambda r: (r["metrics"]["100k"]["fine"]["clean_power"], r["source"]))
                sections = {"all_strength": group, "fainter_half": ranked[:len(ranked)//2]}
                for name, data in sections.items():
                    cells.setdefault(profile, {}).setdefault(draw, {}).setdefault(cohort, {})[name] = (
                        summarize_group(data, methods, rng)
                    )
    write_json(ROOT / stage / "summary.json", {
        "results": reference(result), "driver": reference(__file__), "cells": cells,
        "intervals": "Resample complete sources and their three repeat predictions with 4,000 paired bootstrap draws.",
        "fainter_half": "Selected independently of predictions by fixed exact fine-increment energy within cohort.",
    })
    for profile, by_draw in cells.items():
        for draw, by_cohort in by_draw.items():
            print(profile, draw)
            for cohort, scopes in by_cohort.items():
                print(" ", cohort)
                for method, row in scopes["all_strength"]["table"]["fine"].items():
                    print(f"    {method:<12} {100*row['target_aligned_response']:.4f}% "
                          f"{row['mean_increment_RMS_DN16']:.4f} "
                          f"{row['mean_quiet_RMS_DN16']:.4f} "
                          f"{row['shared_error_product_DN16_squared']:.1f} "
                          f"{row['swapped_draw_variance_DN16_squared']:.1f}")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("stage", choices=("starting", "midpoint", "endpoint"))
    summarize(cli.parse_args().stage)
