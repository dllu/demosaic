"""Attribute increment variance to the correction and its covariance with the parent."""
import argparse
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_projected import ROOT

LABELS = ("twice_parent_correction_covariance","correction_variance","total_variance_above_parent")


def split(rows,label,scale):
    coefficients=[row["moments"][label]["repeat_variance"] for row in rows]
    cols=np.asarray(coefficients,dtype=np.float64)
    covariance=cols[:,1]*scale
    additive=cols[:,2]*scale**2
    assert (additive>=0).all()
    return np.stack([covariance,additive,covariance+additive],axis=1)


def measure(rows,label,scale,baseline,base_scale,indices):
    metric=split(rows,label,scale)
    if baseline is not None:
        metric=metric-split(rows,baseline,base_scale)
    avg=metric.mean(axis=0)
    bounds=np.quantile(metric[indices].mean(axis=1),[.025,.975],axis=0).T
    return {key:[float(estimate),*interval.tolist()]
            for key,estimate,interval in zip(LABELS,avg,bounds,strict=True)}


def report():
    source=reference(ROOT/"prior600-matched.json")
    data=read_json(checked(source))
    random=np.random.default_rng(66198791)
    out={}
    for law in ("coupled","independent"):
        for cohort in ("original64","fresh32"):
            rows=[r for r in data["rows"] if r["law"]==law and r["cohort"]==cohort]
            assert len(rows)==(64 if cohort=="original64" else 32)
            indices=random.integers(0,len(rows),size=(4000,len(rows)))
            moments={}
            for label in ("paired-init","control","repeat025","repeat075"):
                moments[label]={
                    "nominal_above_parent":measure(rows,label,1.,None,0.,indices),
                }
                if label.startswith("repeat"):
                    scales=data["results"][law][label].get("scales",{})
                    if scales:
                        evaluated=measure(rows,label,scales[label],"control",scales["control"],indices)
                        moments[label]["matched_above_control"]=evaluated
                        key="calibration_original64" if cohort=="original64" else "calibrated_fresh32"
                        expected=data["results"][law][label][key]["variance_DN16_squared"][0]
                        np.testing.assert_allclose(evaluated[LABELS[2]][0],expected,rtol=1e-12,atol=1e-10)
            out.setdefault(law,{})[cohort]=moments
    write_json(ROOT/"prior600-variance-budget.json",{
        "driver":reference(__file__),"source":source,"variance_terms":out,
        "units":"DN16 squared",
        "identity":"Var(parent error + correction) - Var(parent error) = 2*Cov(parent error, correction) + Var(correction), using three independent complete draws from each fixed law. Terms are paired by source.",
    })


if __name__=="__main__":
    report()
