"""Bind the completed repeat-training endpoint and its inspected native results."""
from collections import Counter
import json
import math
from pathlib import Path
import shutil
import tarfile

from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from train_repeat import ROOT

SHAPE=ROOT.parent/"paired-shape-stability-v1"
DEST=Path("docs/results/paired-repeat-stability-v2")
IMAGES=Path("docs/images/paired-repeat-stability-v2")

ARCHIVE=(
 "plan.json","schedule.json","evaluation-plan.json","training/launch.json","training/complete.json",
 "training/observations.jsonl","train_repeat.py","evaluate_repeat.py","summarize.py","render_repeat.py",
 "follow.py","follow-complete.json","prepare_repeat.py","strength_sweep.py","endpoint/strength-sweep.json",
 "endpoint/plan.json","endpoint/results.json","endpoint/summary.json","endpoint/native/render.json",
 "endpoint-training-audit.json","endpoint-viewing-notes.json","publish_repeat_final.py",
 "train.log","endpoint.log","render.log","strength-sweep.log",
)


def training_audit(ready):
    plan=read_json(checked(ready["plan"]))
    scheduled=read_json(checked(plan["schedule"]))["rows"]
    logged=[json.loads(line) for line in checked(ready["observations"]).read_text().splitlines()]
    assert [x["step"] for x in logged]==list(range(1,1201))
    sourced=[r for row in logged for r in row["samples"]]
    assert len(sourced)==len({r["id"] for r in sourced})==2400
    assert [x["id"] for x in sourced]==[x["id"] for x in scheduled]
    seeds=[group for sample in sourced for draw in sample["seeds"] for group in draw]
    assert len(seeds)==len(set(seeds))==19200
    buckets=Counter((('iso6400' if row["step"]%2 else 'iso400'),sample["pattern"],sample["coupling"])
                    for row in logged for sample in row["samples"])
    assert len(buckets)==16 and set(buckets.values())=={150}
    assert all(math.isfinite(value) for its in logged for series in its["losses"].values() for value in series)
    state=torch.load(checked(ready["head_checkpoint"]),weights_only=True,map_location="cpu")
    assert state["step"]==1200 and state["parent_frozen"] and state["plan"]==ready["plan"]
    assert len(state["weights"])==3
    for head in state["weights"].values():
        assert set(head)=={"raw","ema","optimizer"} and head["optimizer"]["state"]
        assert all(value.isfinite().all() for key in ("raw","ema") for value in head[key].values())
    path=ROOT/"endpoint-training-audit.json"
    write_json(path,{
        "training":reference(ROOT/"training/complete.json"),"checkpoint":ready["head_checkpoint"],
        "verified_sources":len(sourced),"unique_physical_seeds":len(seeds),"balanced_cells":len(buckets),
        "raw_EMA_optimizer_verified":True,"finite_training_scores":True,
    })
    return reference(path)


def publish():
    ready=read_json(ROOT/"training/complete.json")
    assert ready["updates"]==1200 and ready["examples_per_head"]==14400
    execution=training_audit(ready)
    final=checked(ready["head_checkpoint"])
    mirror=Path("/mnt/external/demosaic/models/paired-repeat-stability-v2-step001200.pt")
    if not mirror.exists():
        shutil.copyfile(final,mirror)
    assert reference(mirror)["sha256"]==ready["head_checkpoint"]["sha256"]
    exact=read_json(ROOT/"endpoint/summary.json")
    result=read_json(checked(exact["results"]))
    assert len(result["rows"])==384
    state=read_json(checked(result["plan"]))
    assert state["endpoint"]==ready["head_checkpoint"]
    matched=read_json(SHAPE/"repeat1200-matched.json")
    assert matched["EMA_checkpoint"]==ready["head_checkpoint"] and len(matched["rows"])==192
    native=read_json(ROOT/"endpoint/native/render.json")
    eyes=read_json(ROOT/"endpoint-viewing-notes.json")
    boards=[*native["standing"],*native["photos"]]
    assert set(eyes["rows"])=={r["id"] for r in boards} and len(boards)==11
    IMAGES.mkdir(exist_ok=True)
    def keep(row):
        src=checked(row["image"])
        path=IMAGES/src.name
        shutil.copyfile(src,path)
        assert reference(path)["sha256"]==row["image"]["sha256"]
        with Image.open(path) as image:
            for pane in row["panels"]:
                x,y,w,h=pane["png_xywh"]
                assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            image.verify()
        row["image"]["path"]=str(path)
    for r in native["standing"]:
        keep(r)
        r["native_review"]=eyes["rows"][r["id"]]
    for r in native["photos"]:
        keep(r["board"])
        keep(r["triplet"])
        r["native_review"]=eyes["rows"][r["id"]]
    native["actual_native_viewing_complete"]=True
    archive=DEST/"endpoint-evidence.tar.xz"
    with tarfile.open(archive,"x:xz") as output:
        for f in ARCHIVE:
            output.add(ROOT/f,arcname=f)
        for f in ("review_repeat1200.py","repeat1200-matched.json","repeat1200.log",
                  "strength_moments.py","review_projected.py","flat_matched_transfer.py"):
            output.add(SHAPE/f,arcname="separate-corpus-match/"+f)
    stat={}
    for profile,conditions in exact["cells"].items():
        stat[profile]={lab:{cohort:row["all_strength"]["table"] for cohort,row in groups.items()}
                       for lab,groups in conditions.items()}
    write_json(DEST/"endpoint-summary.json",{
        "training":ready,"training_execution_audit":execution,"checkpoint":reference(mirror),
        "evaluation_policy":state,"seconds_using_saved_parents":result["seconds"],
        "all_96_numerical_review_complete":True,"native":native,
        "endpoint_summary_by_panel":stat,"exact_6400_response_and_flat_matches_fresh32":matched["results"],
        "frozen_evidence":reference(archive),
        "chart_scope":"Completed luminance component review. Fixed full427 and measured-camera history evaluate parent models separately.",
    })


if __name__=="__main__":
    publish()
