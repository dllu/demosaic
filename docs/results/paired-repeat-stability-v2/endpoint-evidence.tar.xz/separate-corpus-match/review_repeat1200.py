"""Transfer final standard repeat response and exact-flat matches to separate holdouts."""
import os
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from train_projected import ROOT, STABILITY
from follow import wait_until
from review_projected import compare_at_strength
from flat_matched_transfer import match_on
from evaluate_repeat import (
    as_cuda,bind_upstream,channel_coefficients,packed_inputs,predictions,prepare_heads,read_parent,
)
from measure import BANDS
from strength_moments import measure


@torch.inference_mode()
def review(checkpoint):
    os.sched_setaffinity(0,[14,15])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    begun=time.monotonic()
    common=read_json(STABILITY/"plan.json")
    panel=read_json(STABILITY/"evaluation-plan.json")
    archive, base, cache, original_rows=bind_upstream()
    all_heads=prepare_heads(common,checkpoint)
    short_and_long=(read_json(checked(common["guard"]))["threshold"],
                    read_json(checked(common["guard_long"]))["threshold_0_to_1"][0])
    rows=[]
    with ieee_fp32():
        for case in original_rows:
            if case["profile"]["name"]!="iso6400":
                continue
            view=[]
            for index,prediction in enumerate(cache[case["id"]]):
                native=packed_inputs(case,index)
                raw=as_cuda(native)
                ready=predictions(all_heads,raw,read_parent(prediction,classes=("100k",)),short_and_long)
                view.append({k:channel_coefficients(val,native,panel["score_ROI_xywh"])[1] for k,val in ready.items()})
            target=channel_coefficients(native["target"],native,panel["score_ROI_xywh"])[1]
            accumulated={label:np.stack([draw[label] for draw in view]) for label in ready}
            no_head=accumulated["100k"]
            rows.append({
                "id":case["id"],"law":case["coupling"],"cohort":case["cohort"],
                "moments":{key:measure(no_head,value-no_head,target,BANDS["fine"]) for key,value in accumulated.items()},
            })
            if len(rows)%16==0:
                print(len(rows),round(time.monotonic()-begun,2),flush=True)
    rng=np.random.default_rng(182014518)
    totals={}
    for law in ("coupled","independent"):
        fit=[r for r in rows if r["law"]==law and r["cohort"]=="original64"]
        held=[r for r in rows if r["law"]==law and r["cohort"]=="fresh32"]
        assert (len(fit),len(held))==(64,32)
        result={}
        for candidate in ("repeat025","repeat075"):
            group=(candidate,"control")
            fitted_gains={arm:sum(r["moments"][arm]["aligned"][1] for r in fit) for arm in group}
            nominal=compare_at_strength(held,*group,dict.fromkeys(group,1.),rng)
            limits=min(fitted_gains.values())
            response_check={"nominal_fresh32":nominal,"gains_original64":fitted_gains}
            if limits>0.:
                coeff={arm:limits/strength for arm,strength in fitted_gains.items()}
                matched_old=compare_at_strength(fit,*group,coeff,rng)
                matched_new=compare_at_strength(held,*group,coeff,rng)
                assert abs(matched_old["response_percentage_points"][0])<1e-11
                response_check |= {"scales":coeff,"calibration_original64":matched_old,
                                   "calibrated_fresh32":matched_new}
            budget,flat_scalars,_=match_on(fit,*group)
            response_check["same_flat"]={"budget_DN16":budget,"scales":flat_scalars}
            if flat_scalars:
                response_check["same_flat"]["fresh32"]=compare_at_strength(held,*group,flat_scalars,rng)
            result[candidate]=response_check
        totals[law]=result
    write_json(ROOT/"repeat1200-matched.json",{
        "driver":reference(__file__),"projection_driver":reference(ROOT/"review_projected.py"),
        "strength_module":reference(ROOT/"strength_moments.py"),"EMA_checkpoint":checkpoint,
        "training_plan":reference(STABILITY/"plan.json"),"evaluation_panel":reference(STABILITY/"evaluation-plan.json"),
        "parent_predictions":reference(archive),"guards":common["guard"],"rows":rows,"results":totals,
        "seconds":time.monotonic()-begun,
        "scope":"Final 1,200-update EMA from the original repeat training. Fixed descriptive scalar fit on the 64 original sources, no scale fitting or training on the extra 32 sources.",
    })


if __name__=="__main__":
    job=read_json(STABILITY/"training/launch.json")
    receipt=read_json(checked(wait_until(STABILITY/"training/complete.json",job)))
    assert receipt["updates"]==1200
    review(receipt["head_checkpoint"])
