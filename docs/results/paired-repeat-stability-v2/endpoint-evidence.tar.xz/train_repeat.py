"""Continue the paired head with matched supervision and independent repeat penalties."""
import argparse
from collections import Counter
from dataclasses import replace
import json
import math
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import psutil
import torch
from torch.nn import functional as F

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.paired_detail import PairedLuminanceDetail, fine_band
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "paired-luminance-detail-v1"
SCENE = ROOT.parent / "scene-local-contrast-2400-v1"
sys.path[:0] = [str(PRIOR), str(SCENE)]
from train import clean_crop, ema_update, save_checkpoint
from evaluate import ARGS, setup_models
from local_guard import paired_gates
from profile_raw_kernel_inference import model_hash

SEED = 71682363074
STEPS = 1200
PER_UPDATE = 2
CORE = np.s_[..., 80:176, 80:176]
WEIGHTS = {"control": 0.0, "repeat025": 0.25, "repeat075": 0.75}
GUARD = PRIOR / "local-support-calibration.json"


def freeze():
    earlier = read_json(PRIOR / "plan.json")
    previous_schedule = read_json(checked(earlier["source_schedule"]))
    prior_ids = {row["id"] for row in previous_schedule["rows"]}
    manifest = checked(previous_schedule["source"])
    rows = [json.loads(line) for line in manifest.read_text().splitlines() if line.strip()]
    reserved = read_json(checked(earlier["reserved_natural_panel"]))["rows"]
    fixed = read_json(Path("docs/results/full-corpus-long100k-primary-v1/primary.json"))
    excluded = {x["source"]["id"] for x in reserved} | set(fixed["source_averages"]) | prior_ids
    assert len(rows) == 90692 and all(x["split"] == "train" for x in rows)
    assert {x["id"] for x in rows}.isdisjoint(excluded - prior_ids)
    available = [row for row in rows if row["id"] not in excluded]
    selected = random.Random(SEED).sample(available, STEPS * PER_UPDATE + 3 * PER_UPDATE)
    assert len({row["id"] for row in selected}) == len(selected)
    design = Counter(((index // PER_UPDATE) % 2, *balanced_camera(index))
                     for index in range(STEPS * PER_UPDATE))
    assert len(design) == 16 and set(design.values()) == {150}
    schedule = ROOT / "schedule.json"
    write_json(schedule, {
        "manifest": reference(manifest), "prior_training_sources": earlier["source_schedule"],
        "rows": selected[:STEPS * PER_UPDATE], "qualification": selected[STEPS * PER_UPDATE:],
    })
    previous_training = read_json(PRIOR / "training/complete.json")
    guard = read_json(GUARD)
    sources = [
        Path(__file__), PRIOR / "train.py", SCENE / "evaluate.py", SCENE / "prepare_eval.py",
        PRIOR / "raw_support.py", PRIOR / "local_guard.py",
        Path("src/demosaic/paired_detail.py"), Path("src/demosaic/experiments/data/paired.py"),
        Path("src/demosaic/experiments/data/noise.py"), Path("src/demosaic/scene_training_data.py"),
        Path("src/demosaic/scene_data.py"),
    ]
    write_json(ROOT / "plan.json", {
        "driver": reference(__file__), "sources": [reference(p) for p in sources],
        "models": earlier["models"], "initial_head": previous_training["head_checkpoint"],
        "initial_head_weights": "paired EMA", "schedule": reference(schedule),
        "guard": reference(GUARD), "guard_long": guard["existing"],
        "steps": STEPS, "photos_per_update": PER_UPDATE, "penalty": WEIGHTS, "seed": SEED,
        "loss": "Per-draw absolute fine residual + 0.25 exact-flat lift + 0.65 finite increment residual. Repeat arms add smooth L1 on the difference of delivered finite-increment errors between two independent complete draws, divided by sqrt(2) and shared noise scale.",
        "training": "Two redraws of the same clean triplet per photo. Both repeats of one photo are coupled within group. Both repeats of the other photo are independent within group. Every ISO × CFA × coupling cell has 150 photos.",
        "conditioning": "Fixed two-window green support guard in the delivered correction. Single noisy input per model evaluation. No repeat signal enters the head or gate.",
        "optimizer": "Fresh AdamW per head. 60 warmup updates, 1e-4 to 1e-5 cosine, gradient norm limit 1, EMA .995. CUDA IEEE FP32.",
    })


def observe(clean, camera, profile, coupling, seeds):
    """Observe a triplet, using one shared physical draw only within a coupled pair."""
    def read(patch, seed):
        obs = observe_scene(patch, replace(camera, noise_seed=seed))
        return {name: getattr(obs, name) for name in (*ARGS, "target")}

    if coupling == "coupled":
        batch, _ = paired_observation(
            clean[0][None], clean[1][None], profile, [camera.pattern],
            torch.tensor(camera.wb)[None], torch.tensor(camera.camera_inverse)[None], seeds[0],
        )
        pair = [{key: torch.from_numpy(batch[key][i]) for key in (*ARGS, "target")} for i in (0, 1)]
    else:
        pair = [read(patch, seed) for patch, seed in zip(clean[:2], seeds[1:3], strict=True)]
    pair.append(read(clean[2], seeds[3]))
    values = {k: torch.stack([role[k] for role in pair]) for k in (*ARGS, "target")}
    flat = values["target"][2]
    assert torch.equal(flat[CORE], flat[:, 80:81, 80:81].expand(3, 96, 96))
    return values


def seeds_for(index, repeat):
    return [scene_seed(SEED, index, f"repeat-{repeat}:{role}")
            for role in ("pair", "present", "absent", "flat")]


def balanced_camera(index):
    update, position = divmod(index, PER_UPDATE)
    pattern = tuple(PATTERNS)[position + 2 * ((update // 2) % 2)]
    coupling = "coupled" if position == ((update // 4) % 2) else "independent"
    return pattern, coupling


def training_observations(row, index, profile):
    clean, metadata = clean_crop(row, index + 57_279)
    pattern, coupling = balanced_camera(index)
    camera = replace(sample_scene_recipe(scene_seed(SEED, index, "camera")),
                     pattern=pattern, black=.03, **profile)
    seeds = [seeds_for(index, repeat) for repeat in range(2)]
    assert len(set(seeds[0] + seeds[1])) == 8
    repeat = [observe(clean, camera, profile, coupling, draw) for draw in seeds]
    assert torch.equal(repeat[0]["target"], repeat[1]["target"])
    assert not torch.equal(repeat[0]["packed"], repeat[1]["packed"])
    groups = {key: torch.cat([values[key] for values in repeat]) for key in (*ARGS, "target")}
    return groups, metadata | {
        "pattern": pattern, "coupling": coupling, "profile": profile, "camera": camera.__dict__,
        "seeds": seeds, "observations": {key: fingerprint(values.numpy()) for key, values in groups.items()},
    }


def lr(step):
    if step <= 60:
        return 1e-4 * step / 60
    fraction = (step - 60) / (STEPS - 60)
    return 1e-5 + 9e-5 * (0.5 + 0.5 * math.cos(math.pi * fraction))


def shaped(array):
    return array.unflatten(0, (-1, 2, 3))


def robust(array):
    return F.smooth_l1_loss(array, torch.zeros_like(array), beta=.06)


def run_training(qualification):
    path = ROOT / "plan.json"
    plan = read_json(path)
    assert checked(plan["driver"]) == Path(__file__) and plan["penalty"] == WEIGHTS
    for source in plan["sources"]:
        checked(source)
    schedule = read_json(checked(plan["schedule"]))
    photos = schedule["qualification" if qualification else "rows"]
    start = STEPS * PER_UPDATE if qualification else 0
    limits = (3 if qualification else STEPS)
    folder = ROOT / ("qualification" if qualification else "training")
    folder.mkdir()
    write_json(folder / "launch.json", {
        "pid": os.getpid(), "created": psutil.Process().create_time(), "plan": reference(path),
        "qualification_only": qualification,
    })
    os.sched_setaffinity(0, [10, 11, 17])
    os.nice(9)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1., 11 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    parent = setup_models(plan)["Corpus 100k"].requires_grad_(False)
    witness = model_hash(parent)
    short = read_json(checked(plan["guard"]))["threshold"]
    long = read_json(checked(plan["guard_long"]))["threshold_0_to_1"][0]
    initial = torch.load(checked(plan["initial_head"]), weights_only=True, map_location="cpu")
    heads = {tag: PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last) for tag in WEIGHTS}
    for net in heads.values():
        net.load_state_dict(initial["weights"]["paired"]["ema"])
    averages = {tag: {k: v.clone() for k, v in net.state_dict().items()} for tag, net in heads.items()}
    optimizers = {tag: torch.optim.AdamW(net.parameters(), lr=1e-4) for tag, net in heads.items()}
    checkpoints = []
    coupling_counts = Counter()
    cfa_coupling = Counter()
    started = time.monotonic()
    with (folder / "observations.jsonl").open("x") as receipt, ieee_fp32():
        for step in range(1, limits + 1):
            rng = random.Random(scene_seed(SEED, step, "profile"))
            shot, read = (.00128, 6.5536e-6) if step % 2 else (8e-5, 2.56e-8)
            jitter = 2**rng.uniform(-.45, .45)
            profile = {"shot": shot * jitter, "read": read * jitter**2,
                       "exposure": 2**rng.uniform(-2.3, -.25)}
            offset = (step - 1) * PER_UPDATE
            photos_and_draws = [
                training_observations(photos[offset + i], start + offset + i, profile)
                for i in range(PER_UPDATE)
            ]
            for _, row in photos_and_draws:
                coupling_counts[row["coupling"]] += 1
                cfa_coupling[f"{row['pattern']}:{row['coupling']}"] += 1
            data = {k: torch.cat([r[0][k] for r in photos_and_draws]).cuda() for k in (*ARGS, "target")}
            for key in ("packed", "variance", "target"):
                data[key] = data[key].contiguous(memory_format=torch.channels_last)
            parent.set_noise(profile["shot"], profile["read"])
            with torch.no_grad():
                restored = torch.cat([
                    parent(*(data[k][sl] for k in ARGS))
                    for sl in (slice(0, 6), slice(6, None))
                ]).detach()
                _, gate = paired_gates(data["packed"], data["variance"], data["colors"], short, long)
                desired = fine_band(heads["control"].scene_luma(
                    data["target"] - restored, data["wb"], data["matrix"]
                ))
                noise = data["variance"].mean((1, 2, 3)).sqrt().clamp_min(.001)
                noise = noise[:, None, None, None]
                pair_noise = shaped(noise)[:, :, :2].mean(dim=(1, 2))
            objective = {}
            step_zero = None
            for tag, model in heads.items():
                optimizer = optimizers[tag]
                optimizer.param_groups[0]["lr"] = lr(step)
                optimizer.zero_grad(set_to_none=True)
                delivered = model.luminance_delta(restored, *(data[key] for key in ARGS)) * gate
                if step == 1:
                    if step_zero is None:
                        step_zero = delivered.detach()
                    else:
                        assert torch.equal(step_zero, delivered.detach())
                residual = delivered - desired
                normalized = residual / noise
                absolute = .6 * robust(normalized[CORE]) + .4 * robust(normalized)
                quiet = shaped(delivered / noise)[:, :, 2][CORE].square().mean()
                by_draw = shaped(residual)
                pair = by_draw[:, :, 0] - by_draw[:, :, 1]
                pair_loss = robust((pair / pair_noise[:, None])[CORE])
                repeat_difference = ((pair[:, 0] - pair[:, 1]) / (math.sqrt(2) * pair_noise))[CORE]
                repeat_loss = robust(repeat_difference)
                total = absolute + .25 * quiet + .65 * pair_loss + WEIGHTS[tag] * repeat_loss
                total.backward()
                norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
                optimizer.step()
                ema_update(averages[tag], model)
                objective[tag] = [float(y.detach()) for y in (total, absolute, quiet, pair_loss, repeat_loss, norm)]
            receipt.write(json.dumps({"step": step, "samples": [r[1] for r in photos_and_draws],
                                      "losses": objective}) + "\n")
            receipt.flush()
            if step % 50 == 0 or step == limits:
                print(step, round(time.monotonic() - started, 2), objective, flush=True)
            if step in (300, 600, 900) or step == limits:
                checkpoints.append(save_checkpoint(folder, step, heads, averages, optimizers, reference(path)))
    assert model_hash(parent) == witness
    state = torch.load(checked(checkpoints[-1]), weights_only=True, map_location="cpu")
    assert state["step"] == limits
    assert all(torch.isfinite(t).all() for value in state["weights"].values() for t in value["ema"].values())
    write_json(folder / "complete.json", {
        "plan": reference(path), "head_checkpoint": checkpoints[-1], "milestones": checkpoints,
        "parent": plan["models"]["Corpus 100k"], "initial_head": plan["initial_head"],
        "parent_hash_unchanged": witness, "measured_train_seconds": time.monotonic() - started,
        "updates": limits, "distinct_photos": limits * PER_UPDATE,
        "examples_per_head": limits * PER_UPDATE * 6, "within_pair_coupling_by_source": dict(coupling_counts),
        "cfa_and_coupling_counts": dict(cfa_coupling), "observations": reference(folder / "observations.jsonl"),
        "qualification_only": qualification,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "qualify", "train"))
    action = parser.parse_args().action
    if action == "plan":
        freeze()
    else:
        run_training(action == "qualify")
