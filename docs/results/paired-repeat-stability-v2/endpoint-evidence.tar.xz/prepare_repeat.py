"""Prepare independent physical noise repetitions on fixed and fresh held-out photos."""
import argparse
from dataclasses import asdict, replace
import hashlib
import os
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed
from train_repeat import ARGS, ROOT, SCENE, observe
from prepare_eval import flat_patch, load_photo, patch

SEED = 65078125923
REPEATS = 3
NEW_PHOTOS = 32
DRAW_KINDS = ("coupled", "independent")


def freeze():
    original = reference(SCENE / "evaluation-plan.json")
    fixed = read_json(checked(original))
    cohort = read_json(checked(fixed["cohort"]))
    assert cohort["training_overlap"] == [] and len(fixed["rows"]) == 64
    frozen_training = read_json(ROOT / "plan.json")
    schedule = read_json(checked(frozen_training["schedule"]))
    selected_training = {x["id"] for x in schedule["rows"] + schedule["qualification"]}
    old = {x["source"]["id"] for x in fixed["rows"]}
    eligible = [
        row for row in cohort["source_metadata"] if row["split"] == "val" and row["bin_factor"] == 4
        and min(row["shape"][:2]) >= 512 and np.prod(row["shape"][:2]) <= 4_000_000
        and row["id"] not in old | selected_training
    ]
    ranked = sorted(eligible, key=lambda row: hashlib.sha256(
        f"paired-repeat-fixed-v2|{row['id']}".encode()
    ).hexdigest())
    extra = []
    for n, row in enumerate(ranked[:NEW_PHOTOS], 64):
        shape = [int(x) // 2 * 2 for x in row["shape"][:2]]
        (box,) = scene_crop_boxes(shape, patch_size=256, count=1, seed=scene_seed(SEED, n, "box"))
        camera = sample_scene_recipe(scene_seed(SEED, n, "camera"))
        extra.append({
            "source": row, "index": n, "box": box,
            "camera": asdict(camera) | {"pattern": tuple(PATTERNS)[n % 4], "black": .03},
        })
    assert len(extra) == NEW_PHOTOS
    assert len({row["source"]["id"] for row in [*fixed["rows"], *extra]}) == 64 + NEW_PHOTOS
    assert (old | {r["source"]["id"] for r in extra}).isdisjoint(selected_training)
    write_json(ROOT / "evaluation-plan.json", {
        "driver": reference(__file__), "observer": reference(ROOT / "train_repeat.py"),
        "training_plan": reference(ROOT / "plan.json"), "original_panel": original,
        "rows": [row | {"cohort": "original64"} for row in fixed["rows"]] +
                [row | {"cohort": "fresh32"} for row in extra],
        "profiles": fixed["profiles"], "coupling": DRAW_KINDS, "repeats": REPEATS,
        "score_ROI_xywh": fixed["score_ROI_xywh"],
        "native_display_ROI_xywh": fixed["native_display_ROI_xywh"],
        "analysis": "Each coupling law uses three noise draws on identical clean targets. Existing originals retain their first draw and add two fresh draws. Fresh photo sources add three draws.",
    })


def previous_case(index, profile, coupling):
    path = SCENE / "observations" / f"{index:03d}-{profile['name']}-{coupling}.json"
    receipt = reference(path)
    case = read_json(checked(receipt))
    with np.load(checked(case["input"]), allow_pickle=False) as saved:
        values = {key: saved[key] for key in (*ARGS, "target")}
    assert {key: fingerprint(arr) for key, arr in values.items()} == {
        key: case["fingerprints"][key] for key in values
    }
    for key in (*ARGS[2:],):
        arr = values[key]
        values[key] = np.broadcast_to(arr[None], (3, *arr.shape))
    return values, receipt, list(case["physical_seeds"].values())


def prepare(shard):
    os.sched_setaffinity(0, [14 + shard])
    os.nice(11)
    torch.set_num_threads(1)
    plan_ref = reference(ROOT / "evaluation-plan.json")
    plan = read_json(checked(plan_ref))
    assert plan["driver"] == reference(__file__)
    checked(plan["observer"])
    folder = ROOT / "observations"
    folder.mkdir(exist_ok=True)
    manifest = []
    began = time.monotonic()
    for row in plan["rows"][shard::2]:
        index = row["index"]
        image = load_photo(row)
        present = patch(image, row["box"], .22)
        absent = patch(image, row["box"], 0.)
        clean = (present, absent, flat_patch(absent))
        assert all(tile.shape == (3, 256, 256) for tile in clean)
        for condition in plan["profiles"]:
            profile = {key: condition[key] for key in ("shot", "read", "exposure")}
            camera = replace(sample_scene_recipe(SEED), **(row["camera"] | profile))
            for coupling in plan["coupling"]:
                tag = f"{index:03d}-{condition['name']}-{coupling}"
                sources = []
                seen = set()
                expected = None
                for repeat in range(REPEATS):
                    origin = None
                    if index < 64 and repeat == 0:
                        arrays, origin, seeds = previous_case(index, condition, coupling)
                    else:
                        seeds = [scene_seed(SEED, index, f"{tag}/{repeat}/{role}")
                                 for role in ("pair", "present", "absent", "flat")]
                        obs = observe(clean, camera, profile, coupling, seeds)
                        arrays = {key: value.numpy() for key, value in obs.items()}
                    assert seen.isdisjoint(seeds)
                    seen.update(seeds)
                    signature = {key: fingerprint(value) for key, value in arrays.items()}
                    invariants = {k: signature[k] for k in ("target", "colors", "wb", "matrix")}
                    if expected is None:
                        expected = invariants
                    assert invariants == expected, (tag, repeat, invariants, expected)
                    assert all(signature["packed"] != value["fingerprints"]["packed"] for value in sources)
                    packed_ref = None
                    if origin is None:
                        path = folder / f"{tag}-r{repeat}.npz"
                        with path.open("xb") as f:
                            np.savez(f, **arrays)
                        packed_ref = reference(path)
                    sources.append({
                        "repeat": repeat, "file": packed_ref, "original": origin,
                        "scored_physical_seeds": seeds, "fingerprints": signature,
                    })
                manifest.append({
                    "id": tag, "source": row["source"]["id"], "index": index, "cohort": row["cohort"],
                    "profile": condition, "coupling": coupling, "draws": sources, "native_box": row["box"],
                    "CFA": row["camera"]["pattern"],
                })
        if index % 8 == shard:
            print(index, len(manifest), round(time.monotonic() - began, 2), flush=True)
    assert len(manifest) == 192
    write_json(ROOT / f"observation-shard-{shard}.json", {
        "plan": plan_ref, "rows": manifest, "seconds": time.monotonic() - began,
    })


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("action", choices=("plan", "0", "1"))
    part = cli.parse_args().action
    freeze() if part == "plan" else prepare(int(part))
