"""Render exact-target triplets and both standing GFX scene families."""
import os
from pathlib import Path
import time

import numpy as np
import torch
from PIL import Image

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

from evaluate_repeat import (LABELS, as_cuda, bind_upstream, packed_inputs, predictions,
                             prepare_heads, read_parent)
from train_repeat import ARGS, PRIOR, ROOT, WEIGHTS
from render import native_png

DISPLAY = {
    "V120": "V120 EMA",
    "100k": "Parent 100k EMA",
    "paired-init": "Prior paired EMA",
    "control": "Matched control",
    "repeat025": "Repeat loss 0.25",
    "repeat075": "Repeat loss 0.75",
}
SHOW = ("paired-init", *WEIGHTS)


def loose_delta(row, metric):
    return row["metrics"]["repeat075"]["fine"][metric] - row["metrics"]["control"]["fine"][metric]


def show_photo(analysis, scenario, upstream, rows, models, thresholds, out):
    fresh = [row for row in analysis["rows"] if row["cohort"] == "fresh32" and
             (row["profile"], row["coupling"]) == ("iso6400", "independent")]
    assert len(fresh) == 32
    target = "mean_increment_RMS_DN16"
    ranked = sorted(fresh, key=lambda row: loose_delta(row, target))
    on_flat = max(fresh, key=lambda row: loose_delta(row, "mean_quiet_RMS_DN16"))
    chosen = (
        (ranked[0], 0, "Biggest reduction in repeated ISO6400 independent fine-increment RMS versus matched control"),
        (ranked[-1], 0, "Biggest increase in repeated ISO6400 independent fine-increment RMS versus matched control"),
        (on_flat, 2, "Largest change toward higher exact-flat fine RMS versus matched control"),
    )
    info = {row["id"]: row for row in rows}
    emitted = []
    for item, role, why in chosen:
        case = info[item["id"]]
        repeat = 0
        source_row = scenario["rows"][case["index"]]
        assert source_row["source"]["id"] == case["source"]
        arrays = packed_inputs(case, repeat)
        parents = read_parent(upstream[case["id"]][repeat])
        computed = predictions(models, as_cuda(arrays), parents, thresholds)
        fields = {key: arrays[key][role:role+1] for key in ARGS}
        frames = [noisy_malvar(fields)[0], *[computed[key][role] for key in LABELS], arrays["target"][role]]
        emitted.append(native_board(
            out, f"{case['id']}-r{repeat}-role{role}", frames, fields,
            {
                "selection": why, "source_photo": source_row["source"], "bbox_native": case["native_box"],
                "profile": case["profile"], "CFA": case["CFA"], "coupling": case["coupling"], "repeat": repeat,
                "scored_observation": case["draws"][repeat],
                "for_display": "One physical observation selected before evaluation. Aggregate source metrics use three.",
            },
            labels=("Noisy Malvar", *[DISPLAY[label] for label in LABELS], "Exact GT"),
            triplet_indices=(0, LABELS.index("repeat075") + 1, len(frames) - 1),
            exposure=1 / case["profile"]["exposure"], contrast=2,
            roi=tuple(scenario["native_display_ROI_xywh"]),
        ))
    return emitted


def show_camera(models, thresholds, out):
    review = read_json(PRIOR / "endpoint/complete.json")
    parent = read_json(checked(review["standing_results"]))
    source = read_json(checked(parent["display_parent_boards"]))
    by_id = {row["id"]: row for row in parent["rows"]}
    scratch = out / "real-arrays"
    scratch.mkdir()
    material = {}
    for pid, row in by_id.items():
        with np.load(checked(row["raw"]["arrays"]), allow_pickle=False) as inp:
            args = {k: inp[k] for k in ARGS}
        assert {k: fingerprint(value) for k, value in args.items()} == row["inputs"]
        original = np.load(checked(row["parent"]), allow_pickle=False)
        assert original.shape[0] == 1
        restored = predictions(models, as_cuda(args), {"100k": original}, thresholds)
        path = scratch / f"{pid}.npz"
        with path.open("xb") as stream:
            np.savez(stream, **restored)
        material[pid] = args, restored, reference(path)
    board = []
    for region in source["boards"]:
        obs = region["observation"]
        if obs not in material:
            continue
        assert by_id[obs]["raw"]["arrays"] == region["input_arrays"]
        args, results, bound = material[obs]
        with Image.open(checked(region["image"])) as read:
            old = np.array(read.convert("RGB"))
        existing = {panel["label"]: old[y:y+h, x:x+w] for panel in region["panels"]
                    for x,y,w,h in [panel["png_xywh"]]}
        roi = region["case"]["ROI_xywh"]
        x, y, w, h = roi
        baseline = results["100k"][..., y:y+h, x:x+w].astype(float)
        wb, matrix = (torch.from_numpy(args[key]) for key in ("wb", "matrix"))
        panels = [(name, existing[name]) for name in ("ISO6400 camera JPEG", "Noisy (Malvar)",
                  "V120 EMA", "Parent 100k EMA") if name in existing]
        differences = {}
        for key in SHOW:
            values = results[key]
            view = display_crop(torch.from_numpy(values), wb, matrix, roi, exposure=region["display_exposure"])
            panels.append((DISPLAY[key], np.rint(view.clip(0, 1)*255).astype(np.uint8)))
            delta = values[..., y:y+h, x:x+w] - baseline
            differences[key] = {
                "camera_RGB_RMS_DN16": float(65535 * np.sqrt(np.mean(delta**2))),
                "changed_native_RGB_values": int(np.count_nonzero(delta)),
            }
        panels += [(key, existing[key]) for key in ("ISO100 AHD reference", "ISO100 camera JPEG") if key in existing]
        board.append(native_png(out / (region["id"] + ".png"), panels) | {
            "id": region["id"], "output_arrays": bound, "prediction_input": region["input_arrays"],
            "parent_region": region["image"], "parent_linear_RGB": by_id[obs]["parent"],
            "ROI_xywh": roi, "noise": region["noise"], "display_exposure": region["display_exposure"],
            "reference_role": region["reference_role"], "camera_rgb_changes": differences,
        })
    assert len(board) == 8
    return board


@torch.inference_mode()
def render():
    os.sched_setaffinity(0, [14, 15])
    os.nice(10)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1., 5 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    folder = ROOT / "endpoint"
    analysis = read_json(folder / "results.json")
    plan = read_json(checked(analysis["plan"]))
    scenario = read_json(ROOT / "evaluation-plan.json")
    training = read_json(checked(plan["training"]))
    _, _, upstream, rows = bind_upstream()
    models = prepare_heads(training, plan["endpoint"])
    short = read_json(checked(training["guard"]))["threshold"]
    long = read_json(checked(training["guard_long"]))["threshold_0_to_1"][0]
    out = folder / "native"
    out.mkdir()
    before = time.monotonic()
    with ieee_fp32():
        cameras = show_camera(models, (short, long), out)
        photos = show_photo(analysis, scenario, upstream, rows, models, (short, long), out)
    write_json(out / "render.json", {
        "driver": reference(__file__), "bound_plan": analysis["plan"], "photos": photos,
        "standing": cameras, "render_seconds": time.monotonic() - before,
        "require_actual_viewing": True,
    })


if __name__ == "__main__":
    render()
