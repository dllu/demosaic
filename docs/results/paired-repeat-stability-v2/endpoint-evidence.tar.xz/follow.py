"""Advance checkpoint evaluation while verifying that each producing process remains alive."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent


def wait_until(path, owner):
    while not path.exists():
        if not owner_live(owner) and not path.exists():
            raise RuntimeError(f"Producer exited before writing {path}")
        time.sleep(10)
    return reference(path)


def command(program, *args, report):
    with (ROOT / report).open("x") as log:
        subprocess.run([sys.executable, str(ROOT / program), *args], stdout=log, stderr=subprocess.STDOUT,
                       check=True)


def run(base_pid):
    trainer = read_json(ROOT / "training/launch.json")
    parent_worker = {"pid": base_pid, "created": psutil.Process(base_pid).create_time()}
    initial = reference(ROOT / "evaluation-plan.json")
    write_json(ROOT / "follow-launch.json", {
        "pid": os.getpid(), "created": psutil.Process().create_time(),
        "training": trainer, "parent_worker": parent_worker, "evaluation": initial,
        "driver": reference(__file__),
    })
    upstream = wait_until(ROOT / "parent-predictions/complete.json", parent_worker)
    verified = read_json(checked(upstream))
    assert verified["calculated"] == 896 and verified["reused"] == 256
    print("parent archive", checked(upstream), flush=True)
    command("evaluate_repeat.py", "starting", report="starting.log")
    command("summarize.py", "starting", report="starting-summary.log")
    wait_until(ROOT / "training/step000300.pt", trainer)
    command("evaluate_repeat.py", "midpoint", report="midpoint.log")
    command("summarize.py", "midpoint", report="midpoint-summary.log")
    training = wait_until(ROOT / "training/complete.json", trainer)
    command("evaluate_repeat.py", "endpoint", report="endpoint.log")
    command("summarize.py", "endpoint", report="endpoint-summary.log")
    command("render_repeat.py", report="render.log")
    write_json(ROOT / "follow-complete.json", {
        "training": training,
        "endpoint": reference(ROOT / "endpoint/summary.json"),
        "native_render": reference(ROOT / "endpoint/native/render.json"),
        "actual_native_viewing_complete": False,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("parent_worker", type=int)
    run(parser.parse_args().parent_worker)
