"""Bind background, exterior phase, and local gap forecasts before restoration."""
from concurrent.futures import ThreadPoolExecutor
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from local_gap import EXTERIOR,REPLICA,ROOT,columns,inspect,masks,score
from witness import interior
from chirp_bank import predict
from specificity import evaluate
from forecasts import nominate

ROLES=("present","outside-only","strong-only","quiet-query")


def oracle(packed,colors,noise,forecast,layout):
    data,regions,boundary=interior(packed,colors,noise)
    x,y,p,raw,var,fold=data
    active=forecast["accepted"]["specificity"]
    param=np.asarray([*layout["aperture_center"],layout["aperture_width"],layout["aperture_length"],layout["aperture_theta"]])
    w=masks(x,y,param[None])[0].ravel()
    count={name:float(w[regions[name]].sum())for name in active}
    zone=max(count,key=count.get)
    if count[zone]<60:
        return {"nomination":None,"cut":{}}
    axis,mag,nu=columns(data,forecast)
    candidate={"region":zone,"parameters":param.tolist()}
    held=score(data,axis,nu,regions,candidate)
    return {"nomination":candidate,"held":held,"cut":{}}


def one(job):
    material,plan,previous=job
    if previous:
        assert previous["input"]==material["capture"]
    with np.load(checked(material["capture"]),allow_pickle=False)as src:
        raw={k:src[k]for k in ("packed","colors")}
    base=previous or nominate((material,None))
    ix=material["index"]
    layout=plan["sources"][ix]["layout"]
    box,noise=plan["query_box"],plan["profile"]
    x,y,w,h=box
    choices=[]
    for entry in base["trials"]:
        r=entry["repeat"]
        i=ROLES.index(entry["role"])
        orig=entry["previous"]if previous else entry
        choice=None
        recheck={}
        perfect=None
        if not orig["geometry"]:
            frame,colors=(raw[k][r,i]for k in ("packed","colors"))
            choice=entry["checked_exterior"]if previous else evaluate(frame,colors,box,noise,predict(frame,colors,box,noise))
            if choice.get("accepted",{}).get("specificity"):
                crop=frame[:,y//2:(y+h)//2,x//2:(x+w)//2]
                recheck=inspect(crop,colors,noise,choice)
                if not previous and i==0 and layout["support"]=="independent":
                    perfect=oracle(crop,colors,noise,choice,layout)
        choices.append({"repeat":r,"role":entry["role"],"previous":orig,"exterior":choice,
                        "held_gap":recheck,"exact_gap_diagnostic":perfect})
    return {"index":ix,"input":material["capture"],"trials":choices}


def main(mode):
    source=reference((REPLICA if mode=="fit" else ROOT)/"fields.json")
    assets=read_json(checked(source))
    specification=read_json(checked(assets["plan"]))
    frozen=reference(REPLICA/"nomination.json")if mode=="fit" else None
    known=read_json(checked(frozen))["rows"]if frozen else [None]*len(assets["rows"])
    packets=[(r,specification,tr)for r,tr in zip(assets["rows"],known,strict=True)]
    now=time.monotonic()
    selected=[]
    with ThreadPoolExecutor(3)as pool:
        for i,entry in enumerate(pool.map(one,packets),1):
            selected.append(entry)
            print(mode,i,round(time.monotonic()-now,1),flush=True)
    write_json(ROOT/f"nominations-{mode}.json",{"driver":reference(__file__),"inputs":source,
        "inherited":frozen,"local_method":reference(ROOT/"local_gap.py"),
        "phase_method":reference(EXTERIOR/"chirp_bank.py"),"phase_gate":reference(EXTERIOR/"specificity.py"),
        "rows":selected})


if __name__=="__main__":
    main(sys.argv[1])
