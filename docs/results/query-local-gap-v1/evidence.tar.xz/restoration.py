"""Apply held-out gap decisions to the existing exterior-only weak correction."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from local_gap import MODES,REPLICA,ROOT,attenuation
from deliver import transport
from half_gap import HALF_MODES,reduction
from aperture import APERTURE_MODES,compare
from witness import curvature
from run_restore import ARGS,observations,setup_models

ARMS=("baseline","wide","screened",*MODES,*HALF_MODES,*APERTURE_MODES)


@torch.inference_mode()
def run(mode):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    header=reference(ROOT/f"nominations-{mode}.json")
    ledger=read_json(checked(header))
    half_binding=reference(ROOT/f"half-{mode}.json")
    file=read_json(checked(half_binding))
    assert file["source"]==header
    sources=read_json(checked(ledger["inputs"]))
    plan=read_json(checked(sources["plan"]))
    prior=reference(REPLICA/"restoration.json")if mode=="fit"else None
    saved=read_json(checked(prior))["rows"]if prior else [None]*len(sources["rows"])
    output=ROOT/f"predictions-{mode}"
    output.mkdir()
    clock=time.monotonic()
    logs=[]
    with ieee_fp32():
        net=None
        if not prior:
            net=setup_models({"models":{"Corpus100k":plan["base"]}})["Corpus100k"]
            net.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for source,nominations,inherit,halved in zip(sources["rows"],ledger["rows"],saved,file["rows"],strict=True):
            ix=source["index"]
            assert ix==nominations["index"] and source["capture"]==nominations["input"]
            arrays=observations(source)
            native=[torch.from_numpy(arrays[k].reshape((-1,*arrays[k].shape[2:]))).cuda()for k in ARGS]
            native[:2]=[a.contiguous(memory_format=torch.channels_last)for a in native[:2]]
            if inherit:
                assert ix==inherit["index"]
                with np.load(checked(inherit["predictions"]),allow_pickle=False)as p:
                    tensors={k:torch.from_numpy(p[k].reshape(8,3,256,256)).cuda()for k in ("baseline","wide","screened")}
            else:
                parent=net(*native)
                tensors={"baseline":parent,"wide":torch.zeros_like(parent),"screened":torch.zeros_like(parent)}
                for j,result in enumerate(nominations["trials"]):
                    use=[a[j:j+1]for a in native]
                    base=parent[j:j+1]
                    previous=result["previous"]["geometry"]
                    if previous:
                        residual=curvature.deliver(use,base,previous)
                        tensors["wide"][j:j+1]=residual
                        tensors["screened"][j:j+1]=residual
                    else:
                        guide=result["exterior"]
                        tensors["screened"][j:j+1]=transport(use,base,guide,{"extension":"specificity"})["extension"]
            wide,screened=tensors["wide"],tensors["screened"]
            tiers={k:screened.clone()for k in (*MODES,*HALF_MODES,*APERTURE_MODES)}
            for j,decision in enumerate(nominations["trials"]):
                if not decision["held_gap"]:
                    continue
                extra=screened[j]-wide[j]
                for key in (*MODES,*HALF_MODES):
                    if key in MODES:
                        mask=attenuation(decision["held_gap"],decision["exterior"],key)
                    else:
                        mask=reduction(halved["half"][j],decision["exterior"],key)
                    if mask is not None:
                        tiers[key][j]-=extra*torch.from_numpy(mask).cuda()[None]
                t=[z[j:j+1]for z in native]
                local=compare(t,tensors["baseline"][j:j+1],decision["exterior"])
                for key,value in local.items():
                    tiers[key][j:j+1]=wide[j:j+1]+value
            native=tensors|tiers
            expected={k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in native.items()}
            path=output/f"{ix:03d}.npz"
            assert all(np.isfinite(r).all()for r in expected.values())
            with path.open("xb")as f:
                np.savez(f,**expected)
            logs.append({"index":ix,"result":reference(path)})
            print(mode,ix,round(time.monotonic()-clock,2),flush=True)
    write_json(ROOT/f"restoration-{mode}.json",{"driver":reference(__file__),"nominations":header,
               "half":half_binding,"aperture":reference(ROOT/"aperture.py"),
               "existing_exterior":prior,"checkpoint":plan["base"],"rows":logs,"seconds":time.monotonic()-clock})


if __name__=="__main__":
    run(sys.argv[1])
