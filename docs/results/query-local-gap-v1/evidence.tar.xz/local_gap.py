"""Test finite weak-pattern interruptions on disjoint Bayer quarters."""
from functools import lru_cache
import math
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parent
EXTERIOR=ROOT.parent/"query-exterior-witness-v1"
REPLICA=ROOT.parent/"query-exterior-witness-replication-v1"
sys.path.insert(0,str(EXTERIOR))
from witness import design_terms,interior,project

MODES=("gap","sharp")
MIN_NOMINATION=1.5
MIN_HELD=3.25


@lru_cache(maxsize=1)
def footprints():
    rows=[]
    for x in (-40.,-20.,0.,20.,40.):
        for y in (-40.,-20.,0.,20.,40.):
            for rad in (13.,21.):
                rows.append((x,y,rad,rad,0.))
                for length in (35.,55.):
                    for a in np.arange(4)*math.pi/4:
                        rows.append((x,y,rad,length,float(a)))
    return np.asarray(rows)


def masks(x,y,parameters):
    xc,yc,width,length,theta=parameters.T
    dx=x[...,None]-xc
    dy=y[...,None]-yc
    cs,sn=np.cos(theta),np.sin(theta)
    along=(cs*dx+sn*dy)/width
    across=(-sn*dx+cs*dy)/length
    r=np.hypot(along,across)
    gap=(1-(r-1)/.34).clip(0,1)
    dip=np.exp(-.5*r*r)
    return gap,dip


def columns(inputs,forecast):
    x,y,p,raw,var,fold=inputs
    background,carriers=design_terms(inputs,forecast["geometry"])
    wx=x/128
    wy=y/128
    strong=1-forecast["weaker"]
    weaker=forecast["weaker"]
    compete=carriers[:,2*strong:2*strong+2]
    phase=np.asarray(forecast["representation"][weaker],dtype=float)
    exterior=float(np.linalg.norm(phase))
    axis=carriers[:,2*weaker:2*weaker+2]@(phase/max(exterior,1e-20))
    nuisance=np.column_stack((background,compete,compete*wx[:,None],compete*wy[:,None],
                             axis,axis*wx,axis*wy))
    return axis,exterior,nuisance


def nominate(inputs,axis,nuisance,regions):
    x,y,p,raw,var,fold=inputs
    params=footprints()
    chosen=[]
    for region,area in regions.items():
        use=area&(fold==0)
        if use.sum()<250:
            continue
        tx,ty=x[use],y[use]
        values=raw[use]
        weight=1/var[use]
        b=nuisance[use]
        masks_all,_=masks(tx,ty,params)
        supported=((masks_all>.7).sum(0)>=40)&((masks_all<.1).sum(0)>=160)
        pool=np.flatnonzero(supported)
        if len(pool)==0:
            continue
        prediction=-axis[use,None]*masks_all[:,pool]
        residual=project(prediction,b,weight)
        norm=np.sum(weight[:,None]*residual**2,axis=0)
        dot=(values*weight)@residual
        z=dot/np.sqrt(norm).clip(min=1e-20)
        winner=int(np.argmax(z))
        j=int(pool[winner])
        if z[winner]<MIN_NOMINATION:
            continue
        coefficient=np.linalg.solve((b.T*weight)@b,(b.T*weight)@values)
        ref=coefficient[-3]+(coefficient[-2:]@params[j,:2])/128
        chosen.append((float(z[winner]),region,j,float(dot[winner]/norm[winner]),float(ref)))
    if not chosen:
        return None
    z,side,j,delta,level=max(chosen,key=lambda entry:entry[0])
    return {"region":side,"candidate_index":j,"zQ0":z,"deficit_Q0":delta,"continuing_amplitude_Q0":level,
            "parameters":params[j].tolist()}


def score(inputs,axis,nuisance,regions,target):
    x,y,p,raw,var,fold=inputs
    eligible=regions[target["region"]]&(fold>0)
    a=x[eligible]
    b=y[eligible]
    if len(a)<600:
        return {}
    selected=axis[eligible]
    weight=1/var[eligible]
    foot,dip=masks(a,b,np.array(target["parameters"])[None])
    choices=-selected[:,None]*np.column_stack((foot,dip))
    conditional=project(choices,nuisance[eligible],weight)
    sharp,low=conditional.T
    margin=np.sum(weight*sharp*low)/np.sum(weight*low**2).clip(min=1e-20)
    controls={"gap":sharp,"sharp":sharp-margin*low}
    held={}
    for key,prediction in controls.items():
        energy=float(np.sum(weight*prediction**2))
        signal=float(np.sum(weight*prediction*raw[eligible]))
        held[key]={"z":signal/max(1e-20,energy)**.5,"deficit":signal/max(1e-20,energy),
                   "template_norm":energy**.5}
    held["retained_template_norm"]=held["sharp"]["template_norm"]/max(1e-20,held["gap"]["template_norm"])
    return held


def inspect(packed,colors,noise,forecast):
    inputs,regions,boundary=interior(packed,colors,noise)
    expected=forecast["boundary"]
    assert boundary==(tuple(expected) if expected is not None else None)
    carrier,exterior,nuisance=columns(inputs,forecast)
    possible=nominate(inputs,carrier,nuisance,regions)
    ready=forecast.get("accepted",{}).get("specificity",[])
    if possible is None:
        return {"nomination":None,"cut":{}}
    held=score(inputs,carrier,nuisance,regions,possible)
    if not held or possible["region"] not in ready:
        return {"nomination":possible,"held":held,"cut":{}}
    reference=max(1e-8,exterior*.55,possible["continuing_amplitude_Q0"])
    passed={}
    for method in MODES:
        proposal=held[method]
        if proposal["z"]>=MIN_HELD:
            amplitude=min(possible["deficit_Q0"],proposal["deficit"])
            passed[method]=float(np.clip(.85*amplitude/reference,0,.85))
    return {"nomination":possible,"held":held,"cut":passed}


def attenuation(candidate,forecast,name):
    fraction=candidate.get("cut",{}).get(name,0.)
    if fraction==0:
        return None
    shape=np.array(candidate["nomination"]["parameters"])[None]
    axis=np.arange(256)-127.5
    y,x=np.meshgrid(axis,axis,indexing="ij")
    window=masks(x,y,shape)[0][...,0]
    region=candidate["nomination"]["region"]
    if region!="whole":
        angle,offset,_=forecast["boundary"]
        signed=x*math.cos(angle)+y*math.sin(angle)-offset
        window=window*np.where(signed>=0,1.,0.)if region=="plus"else window*np.where(signed<=0,1.,0.)
    return (window*fraction).astype(np.float32)
