"""Pool two quarters for gap location and confirm a fixed mixture on the other half."""
import math

import numpy as np

from local_gap import MODES,columns,footprints,interior,masks,project

HALF_MODES=("half-gap","half-sharp")
MIN_HELD=3.25


def propose(data,phase,nuisance,regions):
    x,y,_,raw,var,fold=data
    refs=footprints()
    fitted=[]
    for side,region in regions.items():
        choose=region&(fold<2)
        if np.count_nonzero(choose)<500:
            continue
        weight=1/var[choose]
        controls=nuisance[choose]
        target=raw[choose]
        v,_=masks(x[choose],y[choose],refs)
        feasible=np.flatnonzero(((v>.7).sum(0)>=80)&((v<.1).sum(0)>=320))
        if not len(feasible):
            continue
        u=project(-v[:,feasible]*phase[choose,None],controls,weight)
        norm=(u**2*weight[:,None]).sum(0)
        dot=(target*weight)@u
        z=dot/np.sqrt(norm).clip(min=1e-20)
        top=int(np.argmax(z))
        if z[top]<1.5:
            continue
        lead=int(feasible[top])
        candidates=np.linalg.norm(refs[feasible,:2]-refs[lead,:2],axis=1)<=24
        close=np.flatnonzero(candidates&(z>=z[top]-1.1))
        close=close[np.argsort(z[close],kind="stable")[::-1]][:12]
        ix=feasible[close]
        mix=np.exp(2*(z[close]-z[top]))
        mix/=mix.sum()
        verify=masks(x[choose],y[choose],refs[ix])[0]@mix
        template=project(-phase[choose]*verify,controls,weight).ravel()
        strength=float((target*template*weight).sum()/(template**2*weight).sum())
        dominant=mix@refs[ix,:2]
        background=np.linalg.solve((controls.T*weight)@controls,(controls.T*weight)@target)
        level=background[-3]+(background[-2:]@dominant)/128
        fitted.append({"region":side,"seed":lead,"zHalf":float(z[top]),"sources":ix.tolist(),
             "weights":mix.tolist(),"deficit":strength,"amplitude":float(level)})
    return max(fitted,key=lambda entry:entry["zHalf"])if fitted else None


def names(data,phase,nuisance,regions,plan):
    x,y,_,raw,var,fold=data
    include=regions[plan["region"]]&(fold>=2)
    if include.sum()<400:
        return {}
    params=footprints()[plan["sources"]]
    f,d=masks(x[include],y[include],params)
    coeff=np.asarray(plan["weights"])
    controls=nuisance[include]
    w=1/var[include]
    raw=raw[include]
    selected=-phase[include,None]*np.column_stack((f@coeff,d@coeff))
    test=project(selected,controls,w)
    a,b=test.T
    trend=(w*a*b).sum()/(w*b*b).sum().clip(min=1e-20)
    methods={"half-gap":a,"half-sharp":a-trend*b}
    result={}
    for key,u in methods.items():
        gram=float((u*u*w).sum())
        value=float((w*raw*u).sum())
        result[key]={"z":value/max(1e-20,gram)**.5,"deficit":value/max(1e-20,gram),
                     "support":max(1e-20,gram)**.5}
    return result


def evaluate(packed,colors,noise,forecast):
    data,regions,edge=interior(packed,colors,noise)
    expected=forecast["boundary"]
    assert edge==(tuple(expected)if expected is not None else None)
    weak,far,nuisance=columns(data,forecast)
    candidate=propose(data,weak,nuisance,regions)
    record={"nomination":candidate,"cut":{}}
    if candidate is None:
        return record
    verified=names(data,weak,nuisance,regions,candidate)
    record["held"]=verified
    active=forecast.get("accepted",{}).get("specificity",[])
    if candidate["region"] not in active:
        return record
    reference=max(1e-8,far*.55,candidate["amplitude"])
    for key,proof in verified.items():
        if proof["z"]>=MIN_HELD:
            amplitude=min(candidate["deficit"],proof["deficit"])
            record["cut"][key]=float(np.clip(.85*amplitude/reference,0,.85))
    return record


def reduction(candidate,forecast,method):
    accepted=candidate.get("cut",{}).get(method,0.)
    if accepted==0:
        return None
    guide=candidate["nomination"]
    coord=np.arange(256)-127.5
    y,x=np.meshgrid(coord,coord,indexing="ij")
    stop=masks(x,y,footprints()[guide["sources"]])[0]@np.array(guide["weights"])
    region=guide["region"]
    if region!="whole":
        theta,d,_=forecast["boundary"]
        gate=x*math.cos(theta)+y*math.sin(theta)-d
        stop*=gate>=0 if region=="plus"else gate<=0
    return (stop*accepted).astype(np.float32)
