"""Render the same fixed GFX parent, geometry and declined fallback side by side."""
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from local_gap import EXTERIOR,ROOT
from aperture import compare
from run_restore import ARGS

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    visual=reference(EXTERIOR/"standing/manifest.json")
    earlier=read_json(checked(visual))
    metadata=reference(EXTERIOR/"specificity-standing.json")
    expected={r["id"]:r for r in read_json(checked(metadata))["rows"]}
    numeric=reference(ROOT/"scores.json")
    scales=read_json(checked(numeric))["strength_calibration"]
    output=ROOT/"standing"
    output.mkdir()
    saved=[]
    for row in earlier["rows"]:
        key=row["id"]
        r=expected[key]
        assert row["input"]==r["previous"]["raw"] and row["query_box"]==r["previous"]["window"]
        x,y,w,h=row["query_box"]
        zone=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            a=[torch.from_numpy(f[k][zone].copy()if k in ARGS[:2]else f[k])for k in ARGS]
        with np.load(checked(row["inherited_arrays"]),allow_pickle=False)as f:
            parent=torch.from_numpy(f["parent"].copy())
            wide=torch.from_numpy(f["wide"].copy())
        x0,y0,d,e=row["ROI"]["ROI_xywh"]
        roi=(x0-x,y0-y,d,e)
        representative=r["guarded"]
        mask=compare(a,parent,representative)
        assert not representative.get("accepted",{}).get("specificity")
        assert not any(v.any().item()for v in mask.values())
        with Image.open(checked(row["image"]))as f:
            canvas=np.asarray(f.convert("RGB"))
        strips={p["name"]:canvas[b:b+d,a:a+c]
                for p in row["panels"]for a,b,c,d in (p["png_xywh"],)}
        ordered=["ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Neighbor-frequency check"]
        cells=[(key,strips[key])for key in ordered if key in strips]
        checkpoint_delta={}
        for mode,title in (("three-wide","Three-quarter wide aperture"),("three-close","Three-quarter compact aperture")):
            current=wide+scales[mode]*mask[mode]
            sample=np.rint(display_crop(current,*a[-2:],roi,exposure=row["display_exposure"])*255).astype(np.uint8)
            np.testing.assert_array_equal(sample,strips["Neighbor-frequency check"])
            cells.append((title,sample))
            checkpoint_delta[mode]=float(torch.sqrt((current-wide).square().mean())*65535)
        cells += [(k,strips[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in strips]
        result=native_png(output/(key+".png"),cells)
        saved.append(row|result|{"source_image":row["image"],"new_camera_RMS_to_checked_DN16":checkpoint_delta,
                                 "extra_gap_evidence_candidates":0})
        print(key,checkpoint_delta,flush=True)
    assert len(saved)==8
    write_json(output/"manifest.json",{"driver":reference(__file__),"prior_boards":visual,"prior_candidates":metadata,
              "score":numeric,"checkpoint":earlier["checkpoint"],"rows":saved})


if __name__=="__main__":
    run()
