"""Freeze a new mixture of shifted gaps and genuine changes in weak contrast."""
from collections import Counter
import hashlib
import importlib.util
import math
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
START=ROOT.parent/"query-exterior-witness-replication-v1"
PREV=ROOT.parent/"query-contour-support-v1"
spec=importlib.util.spec_from_file_location("contour_fixture",PREV/"prepare.py")
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
SEED=633178943993


def targets(photo,layout):
    before,gap,weak=base.targets(photo,layout)
    kind=layout["support"]
    if kind=="occluded" or kind=="contrast":
        return before,gap,weak
    axis=torch.arange(512,dtype=photo.dtype)-255.5
    y,x=torch.meshgrid(axis,axis,indexing="ij")
    cx,cy=layout["aperture_center"]
    a=layout["aperture_theta"]
    dx,dy=x-cx,y-cy
    u=dx*math.cos(a)+dy*math.sin(a)
    v=-dx*math.sin(a)+dy*math.cos(a)
    U=layout["aperture_width"]
    V=layout["aperture_length"]
    dist=(u.square()/U**2+v.square()/V**2).sqrt()
    frame=torch.maximum(x.abs(),y.abs())
    inside=(1-((frame-92)/27).clamp(0,1))
    if kind=="dip":
        factor=1-layout["dip_depth"]*torch.exp(-.5*dist.square())*inside
        adjusted=weak*factor
        return (before[2]+adjusted,*before[1:]),torch.ones_like(gap),adjusted
    envelope=1-(1-((dist-1)/.33).clamp(0,1))*inside
    return (before[2]+weak*envelope,*before[1:]),envelope,weak


def run():
    past=reference(START/"plan.json")
    excluded=[]
    identifiers=set()
    cursor=past
    while cursor:
        options=read_json(checked(cursor))
        excluded.append(cursor)
        identifiers.update(r["source"]["id"]for r in options.get("sources",options.get("heldout_rows",[])))
        cursor=next((options[k]for k in ("previous","curve_reference","preceding","comparison","prior","exclusion")
                     if k in options),None)
    peer=read_json(ROOT.parent/"paired-repeat-stability-v2"/"evaluation-plan.json")
    identifiers.update(r["source"]["id"]for r in peer["rows"])
    settings=read_json(checked(past))
    cohort=read_json(checked(settings["cohort"]))
    rows=[r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
          and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in identifiers]
    ordered=sorted(rows,key=lambda q:hashlib.sha256(f"{SEED}/{q['id']}".encode()).hexdigest())
    factory=base.before.geometry.fields
    factory.ROOT,factory.SEED,factory.clean_targets=ROOT,SEED,targets
    plans=[]
    for i,photo in enumerate(ordered[:30]):
        box,=scene_crop_boxes(photo["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"photo"))
        geometry=factory.draw(i)
        prng=np.random.default_rng(scene_seed(SEED,i,"mask"))
        kind=("independent","dip","independent","contrast","occluded")[i%5]
        k=0. if i%3==0 else (-1)**(i//2)*(.000026+.0000009*i)
        center=prng.uniform(-34,34,2).tolist()
        radius=float(prng.uniform(13,22))
        length=float(prng.uniform(22,36)if i%2==0 else prng.uniform(46,67))
        geometry.update({"support":kind,"shape":"ellipse","step":True,"contrast_step":kind=="contrast",
              "weak_tangential_curvature_cycles_per_px2":k,"strong_tangential_curvature_cycles_per_px2":-.65*k,
              "aperture_center":center,"aperture_width":radius,"aperture_length":length,
              "aperture_theta":float(prng.uniform(0,math.pi)),"dip_depth":float(prng.uniform(.43,.58))})
        plans.append(factory.row_for(photo,i,SEED)|{"box":box,"layout":geometry})
    assert Counter(x["layout"]["support"]for x in plans)=={"occluded":6,"independent":12,"dip":6,"contrast":6}
    write_json(ROOT/"plan.json",{
        **{k:settings[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "sources":plans,"previous":past,"exclude":excluded,"seed":SEED,"driver":reference(__file__),
        "fit_indices":[],"test_indices":list(range(len(plans))),
        "scope":"30 disjoint photos. Twelve shifted gaps with varying elongation, six smooth nonzero contrast dips, six sharp nonzero transitions and six edge occlusions. Identical four paired conditions at the ISO6400 prior."})
    factory.construct()


if __name__=="__main__":
    run()
