"""Spend an extra Bayer quarter on a smaller phase-locked amplitude aperture."""
import math

import numpy as np
import torch

from witness import anchored,curvature,local

APERTURE_MODES=("three-wide","three-close","two-close")
SPATIAL_GRID=16


def fits(packed,variance,colors,parent,geometry,competitor):
    device=packed.device
    green=torch.where(colors[0]==1)[0]
    yy,xx=torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    X=(xx*2+green[:,None,None]%2).flatten()
    Y=(yy*2+green[:,None,None]//2).flatten()
    partition=torch.from_numpy(local.partition()).to(device).expand(2,-1,-1).flatten()
    phase_sign=torch.stack((torch.ones_like(xx),-torch.ones_like(xx))).flatten()
    observed=torch.cat((packed[:,green].flatten(1),parent[:,1,Y,X])).double()
    var=variance[:,green].flatten(1).repeat(2,1).double()
    X,Y=X.double(),Y.double()
    x,y=(X-127.5)/128,(Y-127.5)/128
    center=(torch.arange(SPATIAL_GRID,device=device,dtype=torch.float64)*16+7.5).clamp(32,223)
    cy,cx=torch.meshgrid(center,center,indexing="ij")
    rr=(X[None]-cx.reshape(-1,1)).square()+(Y[None]-cy.reshape(-1,1)).square()
    inside=(x.abs()<=.70)&(y.abs()<=.70)
    c=curvature.torch_phase(X,Y,competitor)
    h=curvature.torch_phase(X,Y,geometry)
    co,si=c.cos(),c.sin()
    basis=torch.stack((torch.ones_like(x),x,y,phase_sign,phase_sign*x,phase_sign*y,
        co,si,co*x,co*y,si*x,si*y,h.cos(),h.sin()),dim=-1)
    chosen={}
    for name,sigma,radius in (("wide",9.,30.),("close",math.sqrt(54.),25.)):
        weight=(-rr/(2.*sigma**2)).exp()*inside*(rr<radius**2)
        chosen[name]=[]
        for tag in (1,2,3):
            keep=partition==tag
            chosen[name].append(local.solve(basis[keep],observed[:,keep],var[:,keep],weight[:,keep]))
    return chosen


def lift(fitted,forecast,direction,parent):
    values=[fit[0][0]@direction for fit in fitted]
    parents=[fit[0][1]@direction for fit in fitted]
    variances=[direction@fit[1][0]@direction for fit in fitted]
    a=torch.stack(values)
    v=torch.stack(variances)
    p=torch.stack(parents)
    information=v.clamp_min(1e-20).reciprocal()
    # Average all disjoint cross-products and match their corresponding variance.
    pairs=torch.triu_indices(len(fitted),len(fitted),offset=1,device=a.device)
    u,w=pairs
    power=(a[u].clamp_min(0)*a[w].clamp_min(0)).mean(0)
    floor=(v[u]*v[w]).sqrt().mean(0)
    shrink=(1-floor/power.clamp_min(1e-15)).clamp(0,1)
    n=information.sum(0)
    measured=(a*information).sum(0)/n
    already=(p*information).sum(0)/n
    c=(measured.clamp_min(0)*shrink-already.clamp_min(0)).clamp_min(0)
    direction_field=c[:,None]*direction
    target=forecast["geometry"][forecast["weaker"]]
    return curvature.lift(direction_field[None],target)


def gate_regions(wave,forecast):
    active=forecast["accepted"]["specificity"]
    if len(active)==2 or active==["whole"]:
        return wave
    a,d,_=forecast["boundary"]
    native=torch.arange(256,device=wave.device,dtype=wave.dtype)-127.5
    signed=native[None]*math.cos(a)+native[:,None]*math.sin(a)-d
    got=signed if active==["plus"]else -signed
    return wave*(got/12.).clamp(0,1)


def compare(args,parent,forecast):
    if not forecast.get("accepted",{}).get("specificity"):
        return {k:torch.zeros_like(parent)for k in APERTURE_MODES}
    packed,variance,colors,wb,matrix=args
    weak=forecast["weaker"]
    target,other=forecast["geometry"][weak],forecast["geometry"][1-weak]
    offset=(target[0]+target[1])*127.5*2.*math.pi
    c,s=math.cos(offset),math.sin(offset)
    a,b=forecast["representation"][weak]
    direction=parent.new_tensor((a*c-b*s,a*s+b*c),dtype=torch.float64)
    direction=direction/torch.linalg.vector_norm(direction).clamp_min(1e-16)
    with anchored((0,0)):
        measured=fits(packed,variance,colors,parent,target,other)
    gains=torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)
    gains=gains/wb
    gains=(gains/gains[:,1:2])[:,:,None,None]
    chosen={"three-wide":measured["wide"],"three-close":measured["close"],"two-close":measured["close"][1:]}
    return {k:gate_regions((lift(v,forecast,direction,parent)[:,None]*gains).to(parent.dtype),forecast)
            for k,v in chosen.items()}
