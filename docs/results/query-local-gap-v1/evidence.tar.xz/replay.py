"""Check the calibrated three-quarter apertures on the earlier 24-photo cohort."""
import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from local_gap import EXTERIOR,ROOT
from aperture import compare
from metrics import bundle,CORE,SCALE,quality,rms
from run_restore import ARGS,observations
from score_panel import luma


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    previous,restored,decisions,base,inputs,plan=bundle()
    stamp=reference(ROOT/"scores.json")
    replay=read_json(checked(stamp))
    frozen=replay["strength_calibration"]
    methods=("screened","three-wide","three-close")
    rows=[]
    for old,selected,archived in zip(base["rows"],decisions["rows"],restored["rows"],strict=True):
        i=old["index"]
        rec=inputs["rows"][i]
        camera=observations(rec)
        with np.load(checked(archived["output"]),allow_pickle=False)as f:
            existing={k:f[k]for k in ("baseline","wide","chirp-specific")}
        packed=[torch.from_numpy(camera[k].reshape((-1,*camera[k].shape[2:]))).cuda()for k in ARGS]
        baseline=torch.from_numpy(existing["baseline"].reshape(8,3,256,256)).cuda()
        new={k:existing["wide"].copy()for k in methods[1:]}
        for j,(a,b) in enumerate(zip(old["trials"],selected["trials"],strict=True)):
            if a["previous"]["geometry"] or not b["guarded"].get("accepted",{}).get("specificity"):
                continue
            values=compare([x[j:j+1]for x in packed],baseline[j:j+1],b["guarded"])
            repeat,role=divmod(j,4)
            for key,field in new.items():
                field[repeat,role]+=frozen[key]*values[key][0].cpu().numpy()
        new["screened"]=existing["chirp-specific"]
        base_y=luma(existing["baseline"],camera)
        archive=luma(existing["wide"],camera)
        gt=luma(camera["target"],camera)
        metrics={}
        for key,val in new.items():
            change=luma(val,camera)
            metrics[key]=quality(base_y+SCALE*change,base_y,gt,camera["weak_linear_nominal"][CORE],camera["region"])
            mask=camera["region"][CORE]==0
            if mask.any():
                metrics[key]["fallback_added_gap_RMS"]=rms((SCALE*(change-archive))[:,0][:,mask])
        rows.append({"index":i,"kind":plan["sources"][i]["layout"]["support"],"input":rec["capture"],
                     "baseline":archived["output"],"measures":metrics})
        print(i,flush=True)
    output={}
    rng=np.random.default_rng(231463)
    for key in ("occluded","contrast","independent"):
        group=[r for r in rows if r["kind"]==key]
        idx=rng.integers(len(group),size=(10000,len(group)))
        values={}
        for k in group[0]["measures"]["screened"]:
            space={arm:np.array([x["measures"][arm][k]for x in group])for arm in methods}
            diffs={n:v-space["screened"] for n,v in space.items()}
            values[k]={"means":{n:float(v.mean())for n,v in space.items()},
                       "paired_95pct":{n:[float(d.mean()),*np.quantile(d[idx].mean(1),(.025,.975)).tolist()]
                                       for n,d in diffs.items()}}
        output[key]=values
    write_json(ROOT/"replay.json",{"driver":reference(__file__),"score":stamp,
        "previous_outputs":previous,"paired_replay":output,"rows":rows,
        "scope":"The earlier 24 held-out exterior witness photos, disjoint from amplitude calibration and today's held-out panel. Fixed aperture variant and calibration scales."})


if __name__=="__main__":
    run()
