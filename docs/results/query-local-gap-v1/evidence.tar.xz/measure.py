"""Compare selective gap and amplitude methods at matched calibration strength."""
from collections import Counter

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from local_gap import EXTERIOR,ROOT
from restoration import ARMS
from aperture import APERTURE_MODES
from run_restore import observations
from score_panel import luma
from metrics import CORE,SCALE,quality,rms

POLICIES=(*ARMS,*(f"matched-{mode}"for mode in APERTURE_MODES))
CALIBRATION_POLICIES=tuple(k for k in ARMS if k not in ("baseline","wide"))


def gather(mode):
    restore=reference(ROOT/f"restoration-{mode}.json")
    loaded=read_json(checked(restore))
    nominations=read_json(checked(loaded["nominations"]))
    half=read_json(checked(loaded["half"]))
    captures=read_json(checked(nominations["inputs"]))
    plan=read_json(checked(captures["plan"]))
    table=[]
    for a,b,c,d in zip(loaded["rows"],captures["rows"],nominations["rows"],half["rows"],strict=True):
        i=a["index"]
        assert (i,b["index"],c["index"],d["index"])==(i,i,i,i)
        raw=observations(b)
        with np.load(checked(a["result"]),allow_pickle=False)as p:
            fields={k:luma(p[k],raw)for k in ARMS}
        table.append({"index":i,"fields":fields,"target":luma(raw["target"],raw),"type":plan["sources"][i]["layout"]["support"],
                      "source":plan["sources"][i],"region":raw["region"],"truth":raw["weak_linear_nominal"][CORE],
                      "capture":b,"restoration":a["result"],"nominated":c,"half":d})
    return restore,table


def delivered(fields,mode,factors):
    if mode=="baseline":
        return fields["baseline"]
    if mode.startswith("matched-"):
        tag=mode.removeprefix("matched-")
        lift=fields["wide"]+factors[tag]*(fields[tag]-fields["wide"])
    else:
        lift=fields[mode]
    return fields["baseline"]+SCALE*lift


def measurements(row,mode,factors):
    fields=row["fields"]
    prediction=delivered(fields,mode,factors)
    within=row["region"][CORE]==0
    metrics=quality(prediction,fields["baseline"],row["target"],row["truth"],row["region"])
    if within.any():
        wide=delivered(fields,"wide",factors)
        metrics["fallback_added_gap_RMS"]=rms((prediction-wide)[:,0][:,within])
    return metrics


def summary(rows):
    rng=np.random.default_rng(572634355)
    indices=rng.integers(len(rows),size=(10000,len(rows)))
    series={}
    comparisons=[(k,"screened")for k in POLICIES if k not in ("baseline","screened")]
    comparisons+=[("matched-three-close","matched-three-wide"),("three-close","two-close")]
    for metric in rows[0]["scores"]["wide"]:
        values={k:np.array([r["scores"][k][metric]for r in rows])for k in POLICIES}
        changes={}
        for l,r in comparisons:
            delta=values[l]-values[r]
            changes[l+"-vs-"+r]=[float(delta.mean()),*np.quantile(delta[indices].mean(1),(.025,.975)).tolist()]
        series[metric]={"mean":{k:float(z.mean())for k,z in values.items()},"paired_95pct":changes}
    return series


def gates(rows):
    out={}
    for row in rows:
        kind=row["type"]
        for a,b in zip(row["nominated"]["trials"],row["half"]["half"],strict=True):
            key=kind+"/"+a["role"]
            number=out.setdefault(key,Counter())
            number["draws"]+=1
            if a["held_gap"]:
                number["eligible"]+=1
                for t in (a["held_gap"],b):
                    for k,scale in t.get("cut",{}).items():
                        number[k]+=bool(scale)
            supplied=a["exact_gap_diagnostic"]
            if supplied:
                number["exact_geometry_tested"]+=bool(supplied["nomination"])
                for k,result in supplied.get("held",{}).items():
                    if isinstance(result,dict):
                        number["oracle-"+k]+=result["z"]>=3.25
    return {k:dict(v)for k,v in out.items()}


def main():
    cal,fit=gather("fit")
    measured,fresh=gather("fresh")
    amps={}
    for key in CALIBRATION_POLICIES:
        amplitude=[]
        for row in fit:
            truth=row["region"][CORE]==1
            y=row["fields"]
            amplitude.append(rms((y[key]-y["wide"])[:,0][:,truth]))
        amps[key]=float(np.mean(amplitude))
    scales={k:amps["screened"]/amps[k]for k in APERTURE_MODES}
    quality=[{"index":r["index"],"geometry":r["type"],"scores":{k:measurements(r,k,scales)for k in POLICIES}}
             for r in fresh]
    groups={k:summary([r for r in quality if r["geometry"]==k])for k in ("independent","occluded","dip","contrast")}
    write_json(ROOT/"scores.json",{"driver":reference(__file__),"calibration":cal,"fresh":measured,
        "calibration_intact_fallback_RMS":amps,"strength_calibration":scales,"methods":list(POLICIES),"unit_scale":SCALE,
        "groups":groups,"per_source":quality,"nominations":{k:gates(rows)for k,rows in (("fit",fit),("fresh",fresh))}})


def native(method):
    torch.set_num_threads(2)
    binding=reference(ROOT/"scores.json")
    params=read_json(checked(binding))
    proof,rows=gather("fresh")
    stamps=[]
    for shape in ("independent","dip"):
        for r in rows:
            if r["type"]!=shape:
                continue
            valid=[x["repeat"]for x in r["nominated"]["trials"]if x["role"]=="present"and x["held_gap"]]
            if valid:
                stamps.append((r,valid[0]))
                break
    assert len(stamps)==2
    target=ROOT/"native"
    target.mkdir()
    kept=[]
    for row,rep in stamps:
        record=row["source"]
        capture=observations(row["capture"])
        with np.load(checked(row["restoration"]),allow_pickle=False)as p:
            found={k:p[k][rep]for k in ARMS}
        named=("wide","screened","gap","half-gap","matched-three-close",method)
        if method in named[:-1]:
            named=named[:-1]
        arrays={k:delivered(found,k,params["strength_calibration"])for k in named}
        noisy=malvar(torch.from_numpy(capture["packed"][rep]),torch.from_numpy(capture["colors"][rep])).numpy()
        arrays|={"noisy":noisy,"target":capture["target"][rep]}
        camera={k:capture[k][rep]for k in ("wb","matrix")}
        rgb={k:np.rint(display(v,camera,exposure=2.)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
             for k,v in arrays.items()}
        for flag,role,order in (("triplet",0,("noisy",method,"target")),
                                ("comparison",0,(*named,"target")),
                                ("outside",1,(*named,"target")),
                                ("quiet",3,(*named,"target"))):
            path=target/f'{row["index"]:03d}-{flag}.png'
            Image.fromarray(np.concatenate([rgb[k][role]for k in order],axis=1)).save(path,optimize=True)
            kept.append({"image":reference(path),"index":row["index"],"role":flag,"condition":row["type"],
                         "order":order,"repeat":rep,"source":record["source"],"source_box":record["box"],
                         "ROI_in_query":[48,48,160,160],"CFA":record["camera"]["pattern"],
                         "profile":{"shot":.00128,"read":6.5536e-6,"exposure":.33},"display_exposure":2.,
                         "capture":row["capture"],"restoration":row["restoration"]})
    write_json(target/"manifest.json",{"driver":reference(__file__),"restoration":proof,"score":binding,
               "checkpoint":read_json(checked(proof))["checkpoint"],"rows":kept,
               "selection":"First two fields with the checked exterior fallback active on the present draw, one unrelated gap and one smooth nonzero contrast dip."})


if __name__=="__main__":
    main()
