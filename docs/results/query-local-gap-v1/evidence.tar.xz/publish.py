"""Bind the three-quarter review to the selected checkpoint, images and held-out results."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
RESULT=Path("docs/results/query-local-gap-v1")
IMAGES=Path("docs/images/query-local-gap-v1")


def main():
    scores=reference(ROOT/"scores.json")
    evidence=read_json(checked(scores))
    audit=read_json(ROOT/"audit.json")
    replay=reference(ROOT/"replay.json")
    exact=read_json(ROOT/"native/manifest.json")
    real=read_json(ROOT/"standing/manifest.json")
    assert exact["checkpoint"]==real["checkpoint"]
    assert exact["score"]==real["score"]==read_json(checked(replay))["score"]==scores
    assert audit["restoration"]==evidence["fresh"]
    records={"exact":exact,"standing":real}
    for family,manifest in records.items():
        for row in manifest["rows"]:
            binding=row["image"]
            source=checked(binding)
            path=IMAGES/family/source.name
            path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,path)
            assert reference(path)["sha256"]==binding["sha256"]
            row["image"]={"path":str(path),"sha256":binding["sha256"]}
            if family=="exact":
                boxes=[(160*j,0,160,160)for j in range(len(row["order"]))]
                if row["role"]=="quiet":
                    note="The exact-flat patch stays smooth across the compared paths."
                elif row["role"]=="outside":
                    note="Only the stronger intact direction and the underlying coarse edge remain prominent."
                elif row["condition"]=="independent":
                    note="The fine pattern is softer than the target. Difference between the two wide apertures is small around the gap."
                else:
                    note="The broad foreground edge remains sharp. Continuous weak crossings are still more visible in the exact crop."
            else:
                boxes=[x["png_xywh"]for x in row["panels"]]
                assert all(v==0 for v in row["new_camera_RMS_to_checked_DN16"].values())
                name=row["id"]
                if "overcast" in name:
                    note="All denoised sky crops are visibly smooth."
                elif "chain-link" in name:
                    note="Both directions of the coarse lattice and its crossings remain visible."
                elif name.endswith("mesh-right"):
                    note="Both prior choices leave the same faint right-cab lattice with soft, uneven crossings."
                elif name.endswith("mesh-left"):
                    note="The existing left-cab parent shows faint diagonals in parts; the reference has clearer fine crossings."
                else:
                    note="The existing coarse shapes stay clean. Fine leaf edges or wires remain soft."
            row["actual_viewing"]=note
            with Image.open(path)as f:
                assert all(w==h==160 and x+w<=f.width and y+h<=f.height for x,y,w,h in boxes)
                f.verify()
    assert len(exact["rows"])==len(real["rows"])==8
    manifest=IMAGES/"manifest.json"
    write_json(manifest,records|{"actual_native_viewing_complete":True})
    RESULT.mkdir(exist_ok=True)
    archive=RESULT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for rule in ("*.py","*.json","*.log","initial/*","native/manifest.json","standing/manifest.json"):
            for source in sorted(ROOT.glob(rule)):
                f.add(source,arcname=source.relative_to(ROOT))
    write_json(RESULT/"publication.json",{
        "study":"query-local-gap-v1","training_performed":False,"numeric_evaluation_complete":True,
        "actual_native_viewing_complete":True,"checkpoint":exact["checkpoint"],"audit":audit,
        "strength_calibration":evidence["strength_calibration"],"fresh_groups":evidence["groups"],
        "nominations":evidence["nominations"],"disjoint_replay":read_json(checked(replay))["paired_replay"],
        "replay_receipt":replay,"manifest":reference(manifest),"archive":reference(archive),
        "scope":"30 new exact-target photos, 36 calibration photos, 24 disjoint earlier exterior phase photos replayed, all eight standing GFX crops reviewed. No comparable full427 or measured-camera panel scores."})


if __name__=="__main__":
    main()
