"""Check CFA fits, sample separation, and calibrated operation on fresh photos."""
import json
import math

import numpy as np
import torch

from demosaic.cfa import color_indices,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from local_gap import ROOT,inspect
from half_gap import evaluate
from aperture import APERTURE_MODES,compare,fits
from run_restore import ARGS,observations
from witness import anchored,curvature,local


def preflight():
    errors={}
    n=torch.arange(256,dtype=torch.float64)
    weak=(.127,.071,2e-5)
    strong=(.054,-.092,-1e-5)
    wave=lambda p:curvature.torch_phase(n[None],n[:,None],p)-(p[0]+p[1])*127.5*2*math.pi
    extra=(.004*wave(weak).cos()).float()
    base=(torch.full((1,3,256,256),.21)+.008*wave(strong).cos().float())
    parameter={"geometry":[strong,weak],"representation":[[1,0],[1,0]],"weaker":1,
               "accepted":{"specificity":["whole"]}}
    for pattern in ("RGGB","GRBG","GBRG","BGGR"):
        colors=color_indices(pattern)[None]
        raw=mosaic(base+extra,colors)
        var=torch.full_like(raw,1e-12)
        args=[raw,var,colors,torch.ones(1,3),torch.eye(3)[None]]
        out=compare(args,base,parameter)
        region=np.s_[...,64:192,64:192]
        for p,result in out.items():
            err=float(abs(result[region]-extra[region]).max())
            assert err<1e-6,(p,err)
            errors[pattern+"-"+p]=err
    return errors


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    pre=preflight()
    receipt=reference(ROOT/"restoration-fresh.json")
    result=read_json(checked(receipt))
    geometry=read_json(checked(result["nominations"]))
    half=read_json(checked(result["half"]))
    fields=read_json(checked(geometry["inputs"]))
    plan=read_json(checked(fields["plan"]))
    prior=read_json(ROOT.parent/"scene-full-epoch-v1"/"plan.json")["train_manifest"]
    with checked(prior).open()as r:
        trained={json.loads(line)["id"]for line in r}
    ids={r["source"]["id"]for r in plan["sources"]}
    assert len(ids)==30 and len(trained)==90692 and not trained&ids
    for source in plan["exclude"]:
        earlier=read_json(checked(source))
        assert not ids&{r["source"]["id"]for r in earlier.get("sources",earlier.get("heldout_rows",[]))}
    with anchored((0,0)):
        tag=local.partition()
    rng=np.random.default_rng(3746525)
    checks=[]
    for row,a,b in zip(result["rows"],geometry["rows"],half["rows"],strict=True):
        i=row["index"]
        assert i==a["index"]==b["index"]
        probe=next((j for j,r in enumerate(a["trials"])if r["role"]=="present" and r["held_gap"]),None)
        if probe is None:
            continue
        checked_shape=a["trials"][probe]
        model=checked_shape["exterior"]
        r,k=divmod(probe,4)
        arrays=observations(fields["rows"][i])
        previous=[arrays[k0][r,k:k+1].copy()for k0 in ARGS]
        src=[torch.from_numpy(a)for a in previous]
        with np.load(checked(row["result"]),allow_pickle=False)as saved:
            parent=torch.from_numpy(saved["baseline"][r,k:k+1])
            variants=compare(src,parent,model)
            parity={}
            for key,value in variants.items():
                np.testing.assert_allclose(value.numpy(),saved[key][r,k:k+1],rtol=0,atol=2e-8)
                parity[key]=float(abs(value.numpy()-saved[key][r,k:k+1]).max())
        noise=plan["profile"]
        original,colors=previous[0][0],previous[2][0]
        altered=original.copy()
        alter=(tag!=0)
        altered[:,alter]=rng.uniform(0.,.8,(4,int(alter.sum())))
        result_q=inspect(altered,colors,noise,model)
        assert result_q["nomination"]==checked_shape["held_gap"]["nomination"]
        altered=original.copy()
        alter=tag>=2
        altered[:,alter]=rng.uniform(0.,.8,(4,int(alter.sum())))
        result_half=evaluate(altered,colors,noise,model)
        assert result_half["nomination"]==b["half"][probe]["nomination"]
        for v in previous[:2]:
            v[...,tag==0]=rng.uniform(0.,.8,(1,4,int((tag==0).sum())))
        after=compare([torch.from_numpy(x)for x in previous],parent,model)
        for key,f in variants.items():
            np.testing.assert_array_equal(after[key].numpy(),f.numpy())
        checks.append({"index":i,"repeat":r,"parent_fixed":True,"proposal_isolation":True,
                       "aperture_excludes_Q0":True,"CPU_GPU_max_abs":parity})
        if len(checks)==4:
            break
    assert len(checks)==4
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"restoration":receipt,"train_manifest":prior,
              "overlap":0,"trained_source_count":len(trained),"noise_free_CFA_fit_error":pre,
              "checks":checks,"scope":"Footprint tests hold the measured exterior waveform fixed. All four CFA noiseless phases are checked. The aperture reads Q1-Q3 and holds full-input parent fixed."})
    print(max(pre.values()),max(v for c in checks for v in c["CPU_GPU_max_abs"].values()),flush=True)


if __name__=="__main__":
    run()
