"""Reconsider the same measured wave geometries using a half-field gap search."""
from concurrent.futures import ThreadPoolExecutor
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from local_gap import ROOT
from half_gap import evaluate


def row(job):
    info,profile,box=job
    values=[]
    with np.load(checked(info["input"]),allow_pickle=False)as src:
        packed,colors=(src[k]for k in ("packed","colors"))
    x,y,w,h=box
    for i,trial in enumerate(info["trials"]):
        if not trial["held_gap"]:
            values.append({})
            continue
        r,j=divmod(i,4)
        crop=packed[r,j,:,y//2:(y+h)//2,x//2:(x+w)//2]
        values.append(evaluate(crop,colors[r,j],profile,trial["exterior"]))
    return {"index":info["index"],"input":info["input"],"half":values}


def run(mode):
    initial=reference(ROOT/f"nominations-{mode}.json")
    study=read_json(checked(initial))
    records=read_json(checked(study["inputs"]))
    plan=read_json(checked(records["plan"]))
    result=[]
    now=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        jobs=((r,plan["profile"],plan["query_box"])for r in study["rows"])
        for i,v in enumerate(pool.map(row,jobs),1):
            result.append(v)
            print(mode,i,round(time.monotonic()-now,1),flush=True)
    write_json(ROOT/f"half-{mode}.json",{"driver":reference(__file__),"source":initial,
        "algorithm":reference(ROOT/"half_gap.py"),"rows":result})


if __name__=="__main__":
    run(sys.argv[1])
