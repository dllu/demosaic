"""Queue bound native and complete-primary CPU reviews behind actual20k completion."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
import yaml
from demosaic.experiments.artifacts import checked,read_json,reference,write_json,verify_plan

repo=Path.cwd();qualified=repo/'.cache/experiments/local-primary-preflight-v1'
qualification=read_json(qualified/'collection/result.json')
assert qualification['all_complete']and qualification['cases']==3
assert all(v['all_output_values_bitexact']and v['all_metric_rows_bitexact']for v in qualification['parent_reference_checks'])
old=(qualified/'work/scripts/collect_local_primary.py').read_text();new=(repo/'scripts/collect_local_primary.py').read_text()
start=new.index('        qualified = read_json(checked(plan["preflight"]))')
end=new.index('    models, before, counters',start)
assert new[:start]+new[end:]==old,'More than the explicit full-result admission guard changed'
root=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1';root.mkdir();work=root/'watcher-work'
shutil.copytree(qualified/'work',work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
names=['collect_local_primary.py','collect_full_corpus_checkpoint_review.py','report_full_corpus_checkpoint_review.py','queue_full_corpus_control_review.py']
for name in names:shutil.copyfile(repo/'scripts'/name,work/'scripts'/name)
scale=repo/'.cache/experiments/full-corpus-scaling-v3';train_path=scale/'production-handoff-plan-v7.json';train=read_json(train_path)
config=yaml.safe_load(checked(train['configs']['control20k']).read_text());controller=read_json(scale/'production-handoff-v7-launch.json');worker=read_json(scale/'production-handoff-v7/00-scale-control20k-launch.json')
for owner in [controller,worker]:assert psutil.Process(owner['pid']).create_time()==owner['create_time']
plan={'root':str(root),'driver':reference(work/'scripts/queue_full_corpus_control_review.py'),'qualified_work':str(qualified/'work'),
 'primary_template':reference(qualified/'plan.json'),'primary_qualification':reference(qualified/'collection/result.json'),
 'native_template':reference(repo/'.cache/experiments/full-corpus-control10k-review-v1/plan.json'),
 'training_plan':reference(train_path),'training_run':config['run'],'training_stage_result':str(scale/'production-handoff-v7/00-scale-control20k-result.json'),
 'training_controller_owner':{k:controller[k]for k in ['pid','create_time']},'training_worker_owner':{k:worker[k]for k in ['pid','create_time']},
 'review_scripts':[reference(work/'scripts'/name)for name in names if name!='queue_full_corpus_control_review.py'],
 'frozen_files':{str(p):reference(p)['sha256']for p in work.rglob('*')if p.is_file()},
 'inputs':[reference(train_path),reference(qualified/'plan.json'),reference(qualified/'collection/result.json'),reference(repo/'.cache/experiments/full-corpus-control10k-review-v1/plan.json')],
 'scope':'Wait on exact already-running20k controller/worker and successful stage receipt; admit only complete20k raw/EMA/Adam/RNG with original horizon and immutable endpoint. Start110-input native review and own20k primary preflight, then full3162-case427/known/unseen CPU benchmark. No training action/retry/reset/quality promotion. Native viewing, independent audits, archive weak-band analysis and history publication remain explicit later work.'}
write_json(root/'plan.json',plan);verify_plan(plan)
env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
command=[sys.executable,str(checked(plan['driver'])),str(root/'plan.json')]
with(root/'watcher.log').open('x')as log:child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'launch.json',{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'plan':reference(root/'plan.json'),'command':command,'producer':reference(__file__)})
print('Queued20k reviews behind existing trainer',child.pid)
