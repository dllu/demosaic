"""Repair only NumPy helper resolution; preserve frozen live plans and all predictions."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1';native=root/'native20k'
failed_launch=read_json(root/'native20k-report-launch.json')
try:
 p=psutil.Process(failed_launch['pid']);assert p.create_time()!=failed_launch['create_time'],'Original reporter still alive'
except psutil.NoSuchProcess:pass
assert 'ModuleNotFoundError' in(root/'native20k-report.log').read_text()and not(native/'report').exists()
collection=read_json(native/'collection/result.json');assert len(collection['records'])==110
assert collection['local_DINO']=={'requests':220,'executions':110,'replays':110}
plan=read_json(root/'plan.json');template=read_json(checked(plan['native_template']))
out=native/'report-dependency-recovery-v2';out.mkdir();work=out/'work'
shutil.copytree(template['work'],work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
reporter=root/'review-work/scripts/report_full_corpus_checkpoint_review.py';assert reference(reporter)['sha256']==next(v for v in plan['review_scripts']if Path(v['path']).name==reporter.name)['sha256']==read_json(native/'plan.json')['frozen_files'][str(reporter)]
command=[sys.executable,str(reporter),str(native)]
env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
write_json(out/'admission.json',{'producer':reference(__file__),'unchanged_native_plan':reference(native/'plan.json'),
 'unchanged_collection':reference(native/'collection/result.json'),'reporter':reference(reporter),
 'original_failure':reference(root/'native20k-report.log'),'original_launch':reference(root/'native20k-report-launch.json'),
 'helper_files':{str(p):reference(p)['sha256']for p in work.rglob('*')if p.is_file()},
 'scope':'Missing NumPy helper import failed before report directory/rendering. Preserve failed source/log/launch. Same frozen reporter executes with exact already-sealed native-review helper package; no mutation of live primary/queue plans/source. No learned/RAW/noise/GPU/optimizer call or training restart; saved220 predictions reused.'})
with(out/'report.log').open('x')as log:child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(out/'launch.json',{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,'admission':reference(out/'admission.json')})
print('Launched NumPy-only report dependency recovery',child.pid)
