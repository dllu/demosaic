"""Seal actual native viewing and the observed stateful100k continuation."""
from pathlib import Path
from datetime import datetime,timezone
import json
import psutil
import torch
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1/native20k';report=read_json(root/'report/result.json')
assert read_json(root/'independent-audit-v1/result.json')['status']=='passed'
views=[]
for b in report['boards']:
 key=b['id']
 if key.startswith('mesh-'):note='Nominal still erases the fine grid; nearby profile contains soft incomplete lattice. Both ROIs/profiles and camera JPEGs viewed; no convincing new faithful crossings.'
 elif key.startswith('main-'):note='Sky smooth; building and foliage remain soft; coarse fence similar to V120. No convincing extra faithful fine reconstruction.'
 elif 'contrast20'in key:note='Much of10k attenuation is repaired, but fur strands/grass still soft. Bark/wood score gains do not show a convincing new general fine-detail gain. Shared target anchor is display-only.'
 elif 'contrast0p025'in key:note='Standard faint display nearly flat; enhanced companion viewed for actual weak structure.'
 elif key.startswith('flat-'):note='Uniform at native8-bit display; unquantized centered-RMS differences remain material numerically.'
 elif 'gain1over32'in key:note='Deep-shadow detail remains blurred/clumpy; small contrast/score changes do not restore missing material structure.'
 else:note='Ordinary detail close to V120; finer ground-truth/reference structure still missing.'
 views.append({'id':key,'image':b['image'],'actual_native_viewed':True,'notes':note})
assert len(views)==26
write_json(root/'actual-native-viewing-v1.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),
 'report':reference(root/'report/result.json'),'boards':views,'actual_native_boards':26,
 'triplets':'All22 triplets are independently checked exact subsets of the actually viewed boards; no separate viewing claim.',
 'scope':'Actual native160px viewing of all26 boards, including both standing GFX families/ROIs/profiles/JPEGs and four faint contrast20 companions. Exact constructed versus binned/independent references remain distinguished. Completed training/numerical/viewing scope is separate from pending full primary scores.'})
base=repo/'.cache/experiments/full-corpus-scaling-v3';plan=read_json(base/'production-handoff-plan-v7.json');launch_path=base/'production-handoff-v7/01-scale-long100k-launch.json';launch=read_json(launch_path)
p=psutil.Process(launch['pid']);assert p.create_time()==launch['create_time']
run=base/'checkpoint-recovery-v7/work/artifacts/train/long100k';phase=run/'phase-001001-100000'
with(phase/'source-crop-observations.jsonl').open()as stream:prefix=''.join(next(stream)for _ in range(250))
rows=[json.loads(line)for line in prefix.splitlines()]
assert [r['step']for r in rows]==list(range(1001,1251))and[r['global_draw_start']for r in rows]==list(range(16000,20000,16))
log=base/'production-handoff-v7/01-scale-long100k.log';text=log.read_text();events=[json.loads(l)for l in text.splitlines()if l.startswith('{"')]
start=next(e for e in events if e['event']=='start');last=max(e['step']for e in events if e['event']=='train')
assert start['start_step']==1000 and start['steps']==100000 and last>2000
out=base/'long100k-stateful-resume-observation-v1';out.mkdir();source=out/'first250-source-rows.jsonl';source.open('x').write(prefix)
log_snapshot=out/'log-snapshot.log';log_snapshot.open('x').write(text)
write_json(out/'result.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'launch':reference(launch_path),
 'actual_owner':{'pid':p.pid,'create_time':p.create_time()},'adopted_step1000_state':plan['adopted_states']['long100k'],
 'start':start,'last_observed_optimizer_step':last,'first250_source_rows':reference(source),'log_snapshot':reference(log_snapshot),
 'scope':'Actual100k trajectory resumed its exact immutable1k raw/EMA/Adam/RNG state, with first-forward91-tensor/DINO guard before new learning and100k horizon retained. New source indices1001–1250 continue after old1k; no prefix replay/reset. Optimizer logs and post-resume checkpoint completion observed, not merely PID liveness. Not completed100k or new quality evidence.'})
print('Sealed26 actual native views;100k trajectory observed through',last)
