"""Independent FFT scores/strata, native cells and measured/missing-site diagnosis."""
import hashlib
import os
import sys
from pathlib import Path
import numpy as np
from PIL import Image
from audit_checkpoint_pilot import rgb,srgb,coefficients,crop
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
assert 'torch'not in sys.modules and os.environ['CUDA_VISIBLE_DEVICES']==''
os.sched_setaffinity(0,[8,9]);os.nice(10)
root=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(root/'plan.json');report=read_json(root/'report/result.json')
collection=read_json(root/'collection/result.json');records={read_json(checked(v))['id']:read_json(checked(v))for v in collection['records']}
metrics={(r['id'],r['method']):r for r in report['metrics']};strata={(r['id'],r['method'],r['original_bin']):r for r in report['original_source_faint_strata']}
boards={r['id']:r for r in report['boards']}
maximum={'score_dB':0.,'band':0.,'stratum':0.};counts={'metric_rows':0,'strata':0,'native_boards':0,'native_channels':0,'flat_rows':0};missing=[]
def close(a,b,kind):
    d=float(abs(a-b));maximum[kind]=max(maximum[kind],d);np.testing.assert_allclose(a,b,rtol=1e-9,atol=1e-10)
def masks(t,means,truth):
    valid=np.array([np.all((truth[0,:,y:y+16,x:x+16]>=0)&(truth[0,:,y:y+16,x:x+16]<=1))for y in range(0,160,16)for x in range(0,160,16)])
    rms=np.linalg.norm(t,axis=1)/16;valid&=(means>=.02)&(means<=.9)&(rms>=1e-5)
    return valid,rms/np.maximum(means,1e-12)
def verify_scores(row,p,target,a,exposure=1):
    pp,tt=[v.astype(np.float64)*exposure for v in [p,target]]
    x,y=[v[...,48:208,48:208]for v in [pp,tt]]
    for name,v in [('camera_RGB_PSNR',np.mean((x.clip(0,1)-y.clip(0,1))**2)),('sRGB_PSNR',np.mean((srgb(rgb(x,a))-srgb(rgb(y,a)))**2))]:close(row[name],-10*np.log10(max(v,1e-12)),'score_dB')
    t,means,truth=coefficients(tt,a);q,_,_=coefficients(pp,a);valid,contrast=masks(t,means,truth)
    actual=[]
    for i,(lo,hi)in enumerate(zip([0,.02,.05,.1,.2],[.02,.05,.1,.2,np.inf],strict=True)):
        select=valid&(contrast>=lo)&(contrast<hi)
        if not select.any():continue
        z,b=q[select],t[select];gain=np.sum(z*b)/np.sum(b*b);n=int(select.sum())
        actual.append({'bin':i,'blocks':n,'gain':gain,'band_error_RMS':np.linalg.norm(z-b)/np.sqrt(n*256),'orthogonal_residual_RMS':np.linalg.norm(z-gain*b)/np.sqrt(n*256)})
    assert len(actual)==len(row['bands'])
    for x,y in zip(actual,row['bands'],strict=True):
        assert x['bin']==y['bin']and x['blocks']==y['blocks']
        for k in ['gain','band_error_RMS','orthogonal_residual_RMS']:close(x[k],y[k],'band')
    counts['metric_rows']+=1

def verify_board(board,cells):
    img=np.asarray(Image.open(checked(board['image'])))
    assert len(cells)==len(board['panels'])
    for p,cell in zip(board['panels'],cells,strict=True):
        x,y,w,h=p['png_xywh'];assert(w,h)==(160,160)
        np.testing.assert_array_equal(img[y:y+h,x:x+w],cell,err_msg=board['id']+' '+p['label']);counts['native_channels']+=cell.size
    counts['native_boards']+=1

def enhanced(value,a,target,roi,exposure):
    x,y,w,h=roi;anchor=rgb(target.astype(np.float64)*exposure,a)[...,y:y+h,x:x+w].mean((-2,-1),keepdims=True)
    mapped=.18+20*(rgb(value.astype(np.float64)*exposure,a)-anchor)
    return np.rint(srgb(mapped)[0,:,y:y+h,x:x+w].transpose(1,2,0)*255).astype(np.uint8)


operator_root=root/'adc-bin-core-review-v2'
scores=read_json(operator_root/'scores.json');native=read_json(operator_root/'native-report/result.json')
lookup={}
for name in ['fixed-adc-diagnostic-v1/result.json','adc-interval-probe-v1/result.json','adc-bin-core-review-v2/result.json']:
 for v in read_json(root/name)['rows']:lookup[v['id'],v['method']]=v
rows={(v['id'],v['method']):v for v in scores['metrics']};flatrows={(v['id'],v['method']):v for v in scores['color_metrics']}
nativeboards={v['id']:v for v in native['boards']};code_checks=0
for o in plan['observations']:
 if o['noise']['shot']or o['noise']['read']:continue
 with np.load(checked(o['arrays']))as f:a=dict(f)
 with np.load(checked(o['target']))as f:target=f['target']
 values={v['label']:np.load(checked(v['prediction']))for v in records[o['id']]['variants']}
 for model in ['V120','scale-control20k']:
  for suffix in ['fixedADC','exactSites','adcBins']:values[model+'+'+suffix]=np.load(checked(lookup[o['id'],model+'+'+suffix]['prediction']))
 for label,p in values.items():
  if o['kind']=='color-spot-check':
   e=p[...,48:208,48:208].astype(np.float64)-target[...,48:208,48:208].astype(np.float64);mean=e.mean((0,2,3));rms=np.sqrt(np.mean((e-mean[None,:,None,None])**2));row=flatrows[o['id'],label]
   close(max(abs(mean))*65535,row['mean_bias_DN16'],'band');close(rms*65535,row['centered_RMS_DN16'],'band');counts['flat_rows']+=1
  else:verify_scores(rows[o['id'],label],p,target,a)
  if label.endswith('+adcBins'):
   dtype=np.float32 if o['kind']=='color-spot-check'else np.float64;black=dtype(.03)
   def encode(v):return np.rint(np.clip(v.astype(dtype)*(dtype(1)-black)+black,0,1)*dtype(65535)).astype(np.int64)
   original=values[label.removesuffix('+adcBins')]
   for phase,c in enumerate(a['colors'][0]):
    y,x=divmod(phase,2);measured=p[:,c,y::2,x::2];gt=target[:,c,y::2,x::2];before=original[:,c,y::2,x::2];packed=a['packed'][:,phase]
    np.testing.assert_array_equal(encode(measured),encode(packed));np.testing.assert_array_equal(encode(gt),encode(packed))
    assert np.all((measured.astype(np.float64)-gt)**2<=(before.astype(np.float64)-gt)**2)
   code_checks+=1
 for model in ['V120','scale-control20k']:
  key=o['id']+'-'+model
  if key not in nativeboards:continue
  b=nativeboards[key];roi=b['ROI_xywh'];vs=[noisy_malvar(a),values[model],*[values[model+'+'+s]for s in ['fixedADC','exactSites','adcBins']],target]
  cells=[enhanced(v,a,target,roi,1)if b['contrast']==20 else crop(v,a,roi,1)for v in vs];verify_board(b,cells)
for t in native['triplets']:
 b=nativeboards[t['board']];img=np.asarray(Image.open(checked(t['image'])));base=np.asarray(Image.open(checked(b['image'])))
 for panel,i in zip(t['panels'],t['parent_panel_indices'],strict=True):
  x,y,w,h=panel['png_xywh'];xx,yy,ww,hh=b['panels'][i]['png_xywh'];np.testing.assert_array_equal(img[y:y+h,x:x+w],base[yy:yy+hh,xx:xx+ww])
assert counts['metric_rows']==128 and counts['flat_rows']==64 and counts['native_boards']==12 and code_checks==48
out=operator_root/'independent-audit-v1';out.mkdir()
write_json(out/'result.json',{'auditor':reference(__file__),'FFT_helper':reference('scripts/audit_checkpoint_pilot.py'),'scores':reference(operator_root/'scores.json'),'native_report':reference(operator_root/'native-report/result.json'),
'counts':counts,'all48_actual_bin_outputs_reencode_and_measured_error_nonincreasing':True,'all4_triplets_exact_native_subsets':True,'maximum_discrepancies':maximum,'status':'passed',
'scope':'Independent NumPy source-precision ADC encoding/measured-site squared errors,FP64 photometry/centered color sums,mirrored-FFT DCT band scores and every pixel of12 native boards. No neural/GPU/RAW/noise/optimizer work; broader palette still running.'})
print(counts,maximum,code_checks)
