"""Publish closed20k evidence; snapshot running work without modifying it."""
import gzip,io,tarfile,shutil,json
from pathlib import Path
from datetime import datetime,timezone
import psutil
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
repo=Path.cwd();queue=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1';root=queue/'native20k';train=repo/'.cache/experiments/full-corpus-scaling-v3';adc=root/'adc-bin-core-review-v2'
report=read_json(root/'report/result.json');physical=read_json(adc/'native-report/result.json');training=read_json(train/'completed-control20k-independent-v2/result.json')
assert read_json(root/'independent-audit-v1/result.json')['status']=='passed'and read_json(adc/'independent-audit-v1/result.json')['status']=='passed'
assert read_json(root/'actual-native-viewing-v1.json')['actual_native_boards']==26 and read_json(adc/'actual-native-viewing-v1.json')['actual_native_boards']==12
images=repo/'docs/images/full-corpus-control20k-review-v1';images.mkdir();manifest=[]
for kind,rows in [('raw',report['boards']+report['triplets']),('adc',physical['boards']+physical['triplets'])]:
 for row in rows:
  source=checked(row['image']);dest=images/(('adc-'if kind=='adc'else'')+source.name);shutil.copyfile(source,dest);assert reference(dest)['sha256']==row['image']['sha256']
  manifest.append({**row,'image':reference(dest),'original_image':row['image']})
write_json(images/'manifest.json',{'producer':reference(__file__),'models':read_json(root/'plan.json')['models'],'images':manifest,'actual_viewed_boards':38,'exact_subset_triplets':26,'scope':'26 raw20k boards plus12 complete physical-policy comparisons actually viewed. Original native160 PNG bytes;4 new ADC triplets and22 raw triplets are exact subsets. Source/ROI/noise/display/checkpoint/reference roles preserved. No private RAW or weights.'})
out=repo/'docs/results/full-corpus-control20k-review-v1';out.mkdir();observations=[]
for directory,launchname,progress in [(queue,'primary20k-launch.json','primary20k/collection/progress.json'),(repo/'.cache/experiments/scene-primary-cpu-v1','full-launch.json','full/progress.json'),(repo/'.cache/experiments/control20k-full-adc-palette-v1','launch.json','collection/progress.json'),(train/'production-handoff-v7','01-scale-long100k-launch.json',None)]:
 launch=read_json(directory/launchname);owner=psutil.Process(launch['pid']);assert owner.create_time()==launch['create_time']
 row={'launch':reference(directory/launchname),'actual_owner':{'pid':owner.pid,'create_time':owner.create_time()},'status':owner.status()}
 if progress:row['progress_snapshot']=read_json(directory/progress)
 else:
  es=[json.loads(l)for l in(directory/'01-scale-long100k.log').read_text().splitlines()if l.startswith('{"')];row['last_optimizer_step']=max(e['step']for e in es if e.get('event')=='train')
 observations.append(row)
write_json(out/'running-work-snapshot.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'observations':observations,'scope':'Identity plus actual source/collection progress snapshots. Ongoing jobs are not completed results; no training restart or signals.'})
files=[]
for directory in [root]:
 files += [p for p in directory.rglob('*')if p.is_file()and p.suffix in ['.json','.csv','.log']and 'work'not in p.parts and '__pycache__'not in p.parts]
for directory in [queue/'review-work',root/'report-dependency-recovery-v2/work']:
 files += [p for p in directory.rglob('*')if p.is_file()and p.suffix=='.py']
files += [train/'completed-control20k-independent-v2/result.json',train/'long100k-stateful-resume-observation-v1/result.json',train/'long100k-stateful-resume-observation-v1/first250-source-rows.jsonl',train/'long100k-stateful-resume-observation-v1/log-snapshot.log']
for key in ['training_plan','training_completion','phase_completion','order_header']:
 files.append(checked(training[key]))
files += [checked(v)for v in training['sources']+training['controller_phase_receipts']]
files += [checked(v['log'])for v in training['training_loop_windows']]
files += [queue/p for p in ['plan.json','endpoint-admission.json','native20k-launch.json','native20k-report-launch.json','native20k-report.log','primary20k-preflight-launch.json','primary20k-preflight/collection/result.json']]
for pattern in ['*control20k*.py','*control20k*.log','qualify-adc-bins-gpu-v*.py','qualify-adc-bins-gpu-v*.log','adc-bin-tests-v*.log']:
 files+=list((repo/'.cache').glob(pattern))
for directory in [repo/'.cache/experiments/adc-bin-gpu-qualification-v1',repo/'.cache/experiments/adc-bin-gpu-qualification-v2']:
 files += [p for p in directory.iterdir()if p.is_file()]
color=repo/'.cache/experiments/control20k-full-adc-palette-v1';files +=[color/'plan.json',color/'launch.json']
files += [repo/p for p in ['src/demosaic/adc_bins.py','tests/test_adc_bins.py','scripts/queue_full_corpus_control_review.py','scripts/audit_checkpoint_pilot.py']]+[out/'running-work-snapshot.json',Path(__file__).resolve()]
paths=sorted(set(p.resolve()for p in files));archive=out/'evidence.tar.gz';members=[]
with archive.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
 for p in paths:
  data=p.read_bytes();name=str(p.relative_to(repo));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'source':reference(p),'member':name})
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(members)
 for v in members:assert tar.extractfile(v['member']).read()==Path(v['source']['path']).read_bytes()
for source,name in [(root/'report/result.json','report.json'),(root/'independent-audit-v1/result.json','independent-native-audit.json'),(root/'actual-native-viewing-v1.json','actual-native-viewing.json'),(root/'faint-decomposition-v1/result.json','faint-decomposition.json'),(train/'completed-control20k-independent-v2/result.json','completed-training-audit.json'),(train/'long100k-stateful-resume-observation-v1/result.json','long100k-resume.json'),(adc/'result.json','adc-bin-result.json'),(adc/'scores.json','adc-bin-scores.json'),(adc/'native-report/result.json','adc-bin-native-report.json'),(adc/'independent-audit-v1/result.json','adc-bin-independent-audit.json'),(adc/'actual-native-viewing-v1.json','adc-bin-native-viewing.json'),(repo/'.cache/experiments/adc-bin-gpu-qualification-v2/result.json','adc-bin-GPU-qualification.json')]:shutil.copyfile(source,out/name)
write_json(out/'publication.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'archive':reference(archive),'all_archive_bytes_verified':True,'members':members,'native_manifest':reference(images/'manifest.json'),'training_complete':True,'scoped_numerical_complete':True,'actual_native_viewing_complete':True,'full_primary_complete':False,'scope':'Completed20k EMA633053... actual20k/320k slots,90778 distinct photos,first full epoch17039.110 native observations/220 CPU roots/110 actual DINO+110 replays.26 raw and12 physical boards actually viewed;26 exact-subset triplets. ADC-bin helper opt-in/calibrated zero-noise only,17 tests,independent numeric/codec/pixel audit and all-code CPU/CUDA qualification. All588 palette and both model primary jobs still running,not full scores/history points. Original failed log parsers/report dependency admissions/GPU codec qualification and executed sources preserved; recovered report has no observed OS return code. Weights/large prediction/conditioning arrays/private media remain local with exact hashes. No default changes.'})
print('Published',len(paths),'verified evidence files and',len(manifest),'PNG assets;archive MiB',archive.stat().st_size/2**20)
