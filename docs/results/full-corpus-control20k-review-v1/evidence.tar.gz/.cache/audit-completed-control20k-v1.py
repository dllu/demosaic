"""Independently close actual20k coverage/state/timing across explicit recoveries."""
import hashlib
import json
import os
import time
from collections import Counter
from pathlib import Path
import numpy as np
import psutil
import torch
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

torch.set_num_threads(2);os.nice(10);os.sched_setaffinity(0,[8,9])
base=Path('.cache/experiments/full-corpus-scaling-v3').resolve();stage_path=base/'production-handoff-v7/00-scale-control20k-result.json'
owner=read_json(base/'production-handoff-v7-launch.json')
while not stage_path.exists():
 p=psutil.Process(owner['pid']);assert p.create_time()==owner['create_time'];time.sleep(2)
stage=read_json(stage_path);assert stage['returncode']==0
plan_path=base/'production-handoff-plan-v7.json';plan=read_json(plan_path);assert stage['production_plan']==reference(plan_path)
run=base/'checkpoint-recovery-v7/work/artifacts/train/control20k';completion=read_json(run/'completed.json');phase=read_json(checked(completion['phase']))
assert completion['steps']==phase['to_step']==phase['LR_horizon']==20000 and phase['from_step']==13000
assert phase['production_plan']==reference(plan_path)and phase['training_updates']==7000 and phase['examples']==112000
assert phase['optimizer_EMA_RNG_preserved_on_resume']and phase['DINO_unchanged']
checkpoint=checked(completion['checkpoint']);assert phase['last']==completion['checkpoint']
state=torch.load(checkpoint,map_location='cpu',weights_only=True)
assert state['step']==20000 and len(state['model'])==len(state['ema'])==91 and len(state['optimizer']['state'])==89
assert all(v['step']==20000 for v in state['optimizer']['state'].values())
assert all(torch.isfinite(v).all()for name in ['model','ema']for v in state[name].values())
assert all(torch.isfinite(v).all()for item in state['optimizer']['state'].values()for v in item.values()if isinstance(v,torch.Tensor))
assert state['python_rng']and state['cuda_rng']and state['torch_rng'].numel()and state['config']['steps']==20000
assert state['config']['batch_size']==16 and state['config']['seed']==70
out=base/'completed-control20k-independent-v1';out.mkdir();os.link(checkpoint,out/'endpoint.pt')
header_path=Path('.cache/experiments/full-corpus-scaling-v1/order20k/photo-epoch-order.json').resolve();header=read_json(header_path)
manifest=checked(header['source_manifest']);rows=[v for line in manifest.read_text().splitlines()if(v:=json.loads(line))['split']=='train'];ids=[v['id']for v in rows]
assert len(ids)==len(set(ids))==90778 and hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest()==header['ordered_train_ids_sha256']
order_path=header_path.parent/header['order']['path'];assert reference(order_path)['sha256']==header['order']['sha256'];order=np.load(order_path,allow_pickle=False)
old_path=base/'checkpoint-stall-step6000-v1/failed-source-crop-observations.jsonl';middle_path=base/'checkpoint-stall-step14000-v1/failed-source-crop-observations.jsonl'
last_path=checked(phase['source_crop_observations'])
old=[json.loads(line)for line in old_path.read_text().splitlines()];middle=[json.loads(line)for line in middle_path.read_text().splitlines()];last=[json.loads(line)for line in last_path.read_text().splitlines()]
assert len(old)==6000 and len(middle)==8000 and len(last)==7000
abandoned=[v for v in middle if v['step']>13000];assert abandoned==last[:1000]
events=old+[v for v in middle if v['step']<=13000]+last
assert len(events)==20000 and [v['step']for v in events]==list(range(1,20001))
assert [v['global_draw_start']for v in events]==list(range(0,320000,16))
ordinary,reviewed,visits,kinds,domains=Counter(),Counter(),Counter(),Counter(),Counter();crops=set();first_complete=None
for event in events:
 domains[event['domain']]+=1;expected=order[event['global_draw_start']:event['global_draw_start']+16]
 if event['domain']!='commons':assert not event['sources']and np.all(expected==-1);continue
 assert len(event['sources'])==16
 for source,index in zip(event['sources'],expected,strict=True):
  kinds[source['kind']]+=1
  if source['kind']!='photographic':assert index==-1;continue
  identity=source['source_id'];visits[identity]+=1;crops.add((identity,tuple(source['cache_xywh'])))
  if source['reviewed_roi_xywh']is not None:reviewed[identity]+=1;assert index==-1
  else:
   assert index>=0 and ids[int(index)]==identity;ordinary[identity]+=1
   if first_complete is None and len(ordinary)==90778:first_complete=event['step']
assert set(ordinary)==set(visits)==set(ids)and first_complete==17039
assert sum(ordinary.values())==106823 and sum(reviewed.values())==5601 and sum(visits.values())==112424
assert dict(Counter(ordinary.values()))=={1:74733,2:16045}
assert dict(domains)=={'commons':10046,'native':4965,'paired':4989}
conditions=[];steps=[]
folders=[(base/'work/artifacts/train/control20k/phase-000001-020000',1,6000),
 (base/'checkpoint-recovery-v6/work/artifacts/train/control20k/phase-006001-020000',6001,13000),(last_path.parent,13001,20000)]
for folder,low,high in folders:
 for path in sorted(folder.glob('conditions-*.npz')):
  with np.load(path,allow_pickle=False)as data:
   a=data['steps']
   if a[0]<low or a[-1]>high:continue
   assert data['values'].shape==(250,16,14)and np.isfinite(data['values']).all()
   assert data['domains'].tolist()==[events[int(s)-1]['domain']for s in a]
   steps.extend(a.tolist());conditions.append(reference(path))
assert steps==list(range(1,20001))and len(conditions)==80
replay=[]
for start in [13001,13251,13501,13751]:
 name=f'conditions-{start:06d}-{start+249:06d}.npz';a=folders[1][0]/name;b=folders[2][0]/name
 with np.load(a,allow_pickle=False)as x,np.load(b,allow_pickle=False)as y:
  assert x.files==y.files
  for key in x.files:np.testing.assert_array_equal(x[key],y[key])
 replay.append({'abandoned':reference(a),'recomputed':reference(b)})
loop=[]
for path,end,count in [(base/'checkpoint-stall-step6000-v1/failed-03-scale-control20k.log',6000,6000),
 (base/'checkpoint-stall-step14000-v1/failed-00-scale-control20k.log',13000,7000),
 (base/'production-handoff-v7/00-scale-control20k.log',20000,7000)]:
 logs=[json.loads(line)for line in path.read_text().splitlines()if line.startswith('{')];event=next(v for v in logs if v.get('event')=='train'and v.get('step')==end)
 loop.append({'log':reference(path),'end_step':end,'counted_retained_updates':count,'reported_seconds_per_step':event['seconds_per_step'],'reported_loop_seconds':event['seconds_per_step']*count})
controllers=[reference(base/p)for p in ['production-handoff-v2/03-scale-control20k-result.json','production-handoff-v6/00-scale-control20k-result.json','production-handoff-v7/00-scale-control20k-result.json']]
wall=sum(read_json(checked(p))['seconds']for p in controllers)
write_json(out/'result.json',{'producer':reference(__file__),'checkpoint':reference(out/'endpoint.pt'),'original_phase_endpoint':completion['checkpoint'],'parent':plan['parent'],
 'training_plan':reference(plan_path),'training_completion':reference(run/'completed.json'),'phase_completion':completion['phase'],
 'raw_tensors':91,'EMA_tensors':91,'finite_Adam_states':89,'all_Adam_steps':20000,'RNG_present':True,'horizon':20000,
 'source_steps':20000,'target_examples':320000,'attempted_optimizer_updates_including_recomputed_segment':21000,
 'sources':[reference(old_path),reference(middle_path),reference(last_path)],'source_merge':'1..6000 +6001..13000 +13001..20000; old13001..14000 discarded before new replay counted.',
 'source_manifest':header['source_manifest'],'order_header':reference(header_path),'order_payload':reference(order_path),
 'every_ordinary_source_slot_matches_payload':True,'actual_photo_ID_set_equals_all90778_train_IDs':True,
 'domains':dict(domains),'Commons_kinds':dict(kinds),'ordinary_photo_draws':sum(ordinary.values()),'reviewed_photo_draws':sum(reviewed.values()),
 'photo_draws':sum(visits.values()),'distinct_photo_sources':len(visits),'reviewed_sources':len(reviewed),'ordinary_visit_histogram':dict(Counter(ordinary.values())),
 'unique_source_cache_crop_boxes':len(crops),'first_complete_ordinary_epoch_step':first_complete,'conditioning_chunks':conditions,
 'recomputed1000_source_rows_exact':True,'recomputed1000_conditioning_exact':replay,'training_loop_windows':loop,
 'sum_reported_retained_loop_seconds':sum(v['reported_loop_seconds']for v in loop),'successful_final7000_phase_worker_seconds':phase['seconds'],
 'controller_phase_receipts':controllers,'sum_attempted_control_phase_wall_seconds_including_stalls_and_replay':wall,
 'native_paired_actual_distinct_source_IDs':None,
 'scope':'Actual completed20k/320k-target-example trajectory, independent finite raw/EMA/Adam/RNG/source-order/80-conditioning-chunk audit. Whole90778-photo ordinary epoch verified; recomputed1000 source+conditioning records exact, counted once in valid trajectory. Attempted21k optimizer updates include lost1000. Reported loop windows exclude initialization and each last validation/save; total controller wall includes stalls/replay and concurrency, not exclusive GPU productivity. No full-quality/broad score/native viewing claim. Native/paired IDs absent; catalogue counts are not actual distinct visits.'})
print('Completed20k',reference(out/'endpoint.pt')['sha256'],'all90778 IDs verified','retained_loop_seconds',sum(v['reported_loop_seconds']for v in loop),'attempted_wall_seconds',wall)
