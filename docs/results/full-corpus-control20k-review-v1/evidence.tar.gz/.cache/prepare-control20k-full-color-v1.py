"""Bind the complete pre-existing ADC palette before any new forward."""
import os,subprocess,sys
from pathlib import Path
import numpy as np,psutil,torch
from demosaic.experiments.artifacts import read_json,checked,reference,write_json,freeze_sources
from demosaic.prediction_archive import fingerprint
repo=Path.cwd();root=repo/'.cache/experiments/control20k-full-adc-palette-v1';root.mkdir()
base=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1/native20k';old=read_json(base/'plan.json')
palette=Path('/mnt/external/demosaic/evaluation/prospective-color-grid-20261017-v1/plan.json');definition=read_json(palette)
assert definition['adc_bits']==16 and definition['adc_black']==.03
work,frozen=freeze_sources(repo,root,['collect_full_corpus_checkpoint_review.py'])
observations=[]
for c in definition['cases']:
 if c['condition']['name']!='adc-only':continue
 binding={'path':c['arrays'],'sha256':c['sha256']}
 with np.load(checked(binding))as f:
  fingerprints={k:fingerprint(torch.from_numpy(f[k].copy()))for k in ['packed','variance','colors','wb','matrix']}
  assert f['target'].shape==(1,3,256,256)
 observations.append({'id':c['id']+'-'+c['pattern'],'arrays':binding,'target':binding,'input_fingerprints':fingerprints,
 'noise':c['condition'],'output_shape':[1,3,256,256],'source_id':c['id'],'pattern':c['pattern'],'definition':c,'ROI_xywh':[48,48,160,160]})
assert len(observations)==588 and len({o['id']for o in observations})==588 and len({o['source_id']for o in observations})==147
plan={'root':str(root),'work':str(work),'inputs':[reference(palette),reference(base/'plan.json')]+[s['checkpoint']for s in old['models'].values()],
'frozen_files':frozen,'collector':reference(work/'scripts/collect_full_corpus_checkpoint_review.py'),'models':old['models'],'DINO_sha256':old['DINO_sha256'],
'CPU_affinity':[6,7],'CPU_threads':2,'maximum_seconds':14400,'observations':observations,'planned_root_calls':1176,'planned_DINO_executions':588,
'calibration':{'bits':16,'black':.03,'CPU_quantizer_precision':'float32'},
'scope':'Complete147-color/four-CFA pre-existing ADC-only palette. Fresh matched CPU EMA outputs, not standard full427 or camera benchmark. No new RAW/noise/GPU/training. Frozen before forwards; physical old/new policy analysis separate; no automated promotion.'}
write_json(root/'plan.json',plan)
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=str(work/'scripts')+':'+str(work/'src'))
log=root/'collection.log';stream=log.open('xb');command=[sys.executable,str(work/'scripts/collect_full_corpus_checkpoint_review.py'),str(root/'plan.json')]
child=subprocess.Popen(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'launch.json',{'producer':reference(__file__),'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,'plan':reference(root/'plan.json'),'log':str(log),'no_automatic_retry':True})
print('Launched complete588-input palette',child.pid)
