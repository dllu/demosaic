from pathlib import Path
from datetime import datetime,timezone
from demosaic.experiments.artifacts import read_json,reference,write_json
r=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k/adc-bin-core-review-v2');report=read_json(r/'native-report/result.json')
assert read_json(r/'independent-audit-v1/result.json')['status']=='passed'
notes=[]
for b in report['boards']:
 key=b['id']
 if key.startswith('flat-'):note='Uniform at8-bit native display; claimed improvements rely on unquantized color sums,not visible texture.'
 elif key.startswith('bark-'):note='Physical policies recover some fine bark contrast; ADC bins and exact MHC look close. Raw20k and V120 remain similar; no broad noisy-detail claim.'
 elif key.startswith('raccoon-'):note='Fur remains soft compared with exact constructed GT. Small physical-policy changes; no fully recovered fine strands.'
 elif key.startswith('pixls-5002-'):note='Grass/wires remain soft; physical changes are small and ADC-bin RGB PSNR regresses against raw V120 despite slightly lower band error.'
 else:note='Wood grain becomes modestly more distinct under physical corrections,with residual chroma difference; ADC-bin RGB PSNR regresses against raw V120. Binned reference is not exact GT.'
 notes.append({'id':key,'image':b['image'],'actual_native_viewed':True,'notes':note})
write_json(r/'actual-native-viewing-v1.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'report':reference(r/'native-report/result.json'),'actual_native_boards':12,'boards':notes,'triplets':'4 independently verified exact subsets of the12 actually viewed boards; no separate viewing claim.'})
