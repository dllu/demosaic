"""Bind independent primary/weak-band postprocessing to the already-owned review queue."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json,reference,write_json,checked
repo=Path.cwd();upstream=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1';launch=read_json(upstream/'launch.json')
assert psutil.Process(launch['pid']).create_time()==launch['create_time']
qualified=repo/'.cache/experiments/local-primary-preflight-v1'
assert read_json(qualified/'numpy-audit-qualification-v1/result.json')['status']=='passed'
assert read_json(qualified/'archive-qualification-v1/result.json')['all_records_verified_with_existing_reader']
# Preserve the exact earlier full427 DCT/statistics sources, without changing a gate.
old=repo/'.cache/experiments/v131-broad-local-detail-v1/work/scripts'
for name in ['diagnose_archive_local_detail.py','diagnose_local_material_detail.py']:
 assert (old/name).read_bytes()==(repo/'scripts'/name).read_bytes()
root=repo/'.cache/experiments/full-corpus-control20k-analysis-queue-v1';root.mkdir();work=root/'work'
shutil.copytree(qualified/'work',work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ['audit_local_primary.py','export_local_primary_archive.py','watch_local_primary_analysis.py','audit_quality_archive.py',
 'diagnose_archive_local_detail.py','diagnose_local_material_detail.py']:
 shutil.copyfile(repo/'scripts'/name,work/'scripts'/name)
plan={'root':str(root),'driver':reference(work/'scripts/watch_local_primary_analysis.py'),
 'upstream_queue_plan':reference(upstream/'plan.json'),'upstream_queue_owner':{k:launch[k]for k in ['pid','create_time']},
 'expected_primary_launch':str(upstream/'primary20k-launch.json'),'expected_primary_result':str(upstream/'primary20k/collection/result.json'),
 'endpoint_admission':str(upstream/'endpoint-admission.json'),
 'frozen_files':{str(p):reference(p)['sha256']for p in work.rglob('*')if p.is_file()},
 'inputs':[reference(upstream/'plan.json'),reference(qualified/'numpy-audit-qualification-v1/result.json'),reference(qualified/'archive-qualification-v1/result.json')],
 'scope':'Wait on exact owned20k review queue/primary worker; independently rescore every complete primary observation, archive unchanged native arrays, run original full427 weak-band analysis on5124 matched source/noise/CFA observations and96075 GT blocks. No training action/model replay/GT-fitting or quality promotion. Preflight qualification is not a broad result.'}
write_json(root/'plan.json',plan)
env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
command=[sys.executable,str(checked(plan['driver'])),str(root/'plan.json')]
with(root/'watcher.log').open('x')as log:child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'launch.json',{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'plan':reference(root/'plan.json'),'command':command,'producer':reference(__file__)})
print('Queued independent primary+full427 weak-band analysis',child.pid)
