"""Evaluate the calibrated exact-code-bin implementation on retained observations."""
import os
from pathlib import Path
import numpy as np
import torch
from demosaic.adc_bins import adc_bin_bounds,adc_bin_projection
from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

torch.set_num_threads(2);os.sched_setaffinity(0,[6,7])
root=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(root/'plan.json');collection=read_json(root/'collection/result.json')
cases={read_json(checked(v))['id']:read_json(checked(v))for v in collection['records']};out=root/'adc-bin-core-review-v2';out.mkdir();rows=[];bypass=[]
calibration=Path('/mnt/external/demosaic/evaluation/prospective-color-grid-20261017-v1/plan.json');cal=read_json(calibration);assert cal['adc_bits']==16 and cal['adc_black']==.03
with torch.inference_mode():
 for i,o in enumerate(plan['observations']):
  if o['noise']['shot']or o['noise']['read']:
   if o['kind']in ['gfx','mesh']:
    with np.load(checked(o['arrays']))as f:packed,colors,wb=[torch.from_numpy(f[k].copy())for k in ['packed','colors','wb']]
    for v in cases[o['id']]['variants']:
     original=torch.from_numpy(np.load(checked(v['prediction'])))
     result=adc_bin_projection(original,packed,colors,wb,bit_depth=16,black_level=.03,quantizer_precision='float64',shot=o['noise']['shot'],read=o['noise']['read'])
     assert result is original;bypass.append({'id':o['id'],'method':v['label'],'original_prediction':v['prediction'],'object_identity_bypass':True})
   continue
  precision='float32'if o['kind']=='color-spot-check'else'float64'
  with np.load(checked(o['arrays']))as f:packed,colors,wb=[torch.from_numpy(f[k].copy())for k in ['packed','colors','wb']]
  lower,upper=adc_bin_bounds(packed,bit_depth=16,black_level=.03,quantizer_precision=precision)
  for v in cases[o['id']]['variants']:
   original=torch.from_numpy(np.load(checked(v['prediction'])))
   result=adc_bin_projection(original,packed,colors,wb,bit_depth=16,black_level=.03,quantizer_precision=precision,shot=0.,read=0.)
   assert torch.isfinite(result).all()
   measured=mosaic(result,colors);assert torch.all((measured>=lower)&(measured<=upper))
   with np.load(checked(o['target']))as f:target=torch.from_numpy(f['target'].copy())
   gt=mosaic(target,colors);assert torch.all((gt>=lower)&(gt<=upper))
   assert torch.all((measured.double()-gt.double()).square()<=(mosaic(original,colors).double()-gt.double()).square())
   path=out/(v['label']+'-'+str(i)+'.npy')
   with path.open('xb')as stream:np.save(stream,result.numpy(),allow_pickle=False)
   rows.append({'id':o['id'],'method':v['label']+'+adcBins','prediction':reference(path),'raw_prediction':v['prediction'],
                'quantizer_precision':precision,'target_decoded_after_operator':True,'GT_in_exact_code_bins':True,'measured_camera_error_nonincreasing':True})
assert len(rows)==48 and len(bypass)==12 and not torch.cuda.is_initialized()
write_json(out/'result.json',{'producer':reference(__file__),'operator_source':reference('src/demosaic/adc_bins.py'),'CFA_source':reference('src/demosaic/cfa.py'),
 'parent_collection':reference(root/'collection/result.json'),'rows':rows,'actual_GFX_positive_noise_bypasses':bypass,
 'palette_calibration':reference(calibration),'tests':reference('.cache/adc-bin-tests-v2.log'),
 'scope':'Actual calibrated exact float32 preimage tables under source-specific FP64 faint/FP32 palette codecs. All48 physical outputs,GT-bin inclusion and measured-camera error monotonicity checked after input-only correction;12 actual positive-prior GFX object-identity bypasses. Existing prototype/controls preserved. No learned forward/training/RAW/noise/GPU calls, no default change. Missing-color/rendered/spatial errors are measured, not bounded by the site constraint.'})
print('48 exact-code-bin physical outputs verified;12 actual GFX positive-prior identity bypasses')
