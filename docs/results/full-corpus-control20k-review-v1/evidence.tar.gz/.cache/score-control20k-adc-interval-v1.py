"""Score all fixed physical controls equally; no new neural work."""
from pathlib import Path
import numpy as np
from report_checkpoint_pilot import statistics
from demosaic.archive_metrics import color
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
r=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(r/'plan.json');c=read_json(r/'collection/result.json')
raw={read_json(checked(v))['id']:read_json(checked(v))for v in c['records']};fixed=read_json(r/'fixed-adc-diagnostic-v1/result.json');new=read_json(r/'adc-interval-probe-v1/result.json')
lookup={(v['id'],v['method']):v for v in fixed['rows']+new['rows']};metrics=[];colors=[]
for o in plan['observations']:
 if o['noise']['shot']or o['noise']['read']:continue
 with np.load(checked(o['arrays']),allow_pickle=False)as f:a=dict(f)
 with np.load(checked(o['target']),allow_pickle=False)as f:target=f['target']
 values={v['label']:np.load(checked(v['prediction']))for v in raw[o['id']]['variants']}
 for method in ['V120','scale-control20k']:
  for suffix in ['fixedADC','exactSites','intervalMHC']:values[method+'+'+suffix]=np.load(checked(lookup[o['id'],method+'+'+suffix]['prediction']))
 for label,value in values.items():
  if o['kind']=='color-spot-check':
   s=color(value,a);colors.append({'id':o['id'],'method':label,'mean_bias_DN16':65535*max(abs(v)for v in s['camera_RGB_mean_error']),'centered_RMS_DN16':65535*s['spatially_centered_camera_RGB_RMS']})
  else:metrics.append({'id':o['id'],'source_id':o['source_id'],'method':label,'pattern':o['pattern'],**statistics(value,target,a)})
means={label:float(np.mean([v['sRGB_PSNR']for v in metrics if v['method']==label]))for label in values}
for label in means:print(label,'faint',means[label],'max_flat_bias',max(v['mean_bias_DN16']for v in colors if v['method']==label),'max_flat_centered_RMS',max(v['centered_RMS_DN16']for v in colors if v['method']==label))
assert len(metrics)==128 and len(colors)==64
write_json(r/'adc-interval-probe-v1/scores.json',{'producer':reference(__file__),'operator_result':reference(r/'adc-interval-probe-v1/result.json'),'metrics':metrics,'color_metrics':colors,'means':means,'scope':'All16 faint and8 preselected flat inputs, all8 raw/physical policies. No mode/gain tuning or new neural work. Exploratory correction; actual native viewing and broader evidence remain separate.'})
