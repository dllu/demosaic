"""All fixed physical policies with identical native ROI/display per source."""
import os
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from demosaic.archive_metrics import linear_rgb,noisy_malvar
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
os.sched_setaffinity(0,[6,7])
r=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(r/'plan.json');col=read_json(r/'collection/result.json')
raw={read_json(checked(v))['id']:read_json(checked(v))for v in col['records']}
lookup={}
for f in ['fixed-adc-diagnostic-v1/result.json','adc-interval-probe-v1/result.json','adc-bin-core-review-v2/result.json']:
 for v in read_json(r/f)['rows']:lookup[v['id'],v['method']]=v
out=r/'adc-bin-core-review-v2/native-report';out.mkdir();boards=[];triplets=[]
for o in plan['observations']:
 faint=o['kind']=='material'and 'contrast0p025-adc'in o.get('case_id','')
 flat=o['kind']=='color-spot-check'
 if not(faint or flat)or o['pattern']!='RGGB':continue
 with np.load(checked(o['arrays']))as f:a=dict(f)
 with np.load(checked(o['target']))as f:target=f['target']
 roi=o['ROI_xywh'];x,y,w,h=roi;assert(w,h)==(160,160)
 anchor=linear_rgb(target,a)[...,y:y+h,x:x+w].mean((-2,-1),keepdims=True)if faint else None
 for model in ['V120','scale-control20k']:
  values={model:np.load(checked(next(v for v in raw[o['id']]['variants']if v['label']==model)['prediction']))}
  for suffix in ['fixedADC','exactSites','adcBins']:values[model+'+'+suffix]=np.load(checked(lookup[o['id'],model+'+'+suffix]['prediction']))
  role='Exact constructed GT'if flat or o['original_case_id']in ['bark','raccoon-fur']else'Binned ref; not exact GT'
  order=[('Noisy Malvar',noisy_malvar(a)),*values.items(),(role,target)];cells=[];clipping=[]
  for label,value in order:
   linear=linear_rgb(value.astype(np.float64),a)[...,y:y+h,x:x+w]
   if faint:linear=.18+20*(linear-anchor)
   clipping.append({'label':label,'fraction':float(np.mean((linear<0)|(linear>1)))})
   v=linear.clip(0,1);v=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055);cells.append(np.rint(v[0].transpose(1,2,0)*255).astype(np.uint8))
  image=Image.new('RGB',(8+168*6,192),'#eeeeee');draw=ImageDraw.Draw(image);panels=[]
  names=['Noisy','Raw EMA','Exact MHC','Exact sites','ADC bins',role]
  for i,(name,cell)in enumerate(zip(names,cells,strict=True)):
   px=8+168*i;image.paste(Image.fromarray(cell),(px,24));draw.text((px,5),name,fill='black');panels.append({'label':name,'value':order[i][0],'png_xywh':[px,24,160,160]})
  dest=out/(o['id']+'-'+model+'.png');image.save(dest)
  row={'id':o['id']+'-'+model,'image':reference(dest),'panels':panels,'source':o,'model':plan['models'][model],'ROI_xywh':roi,'display_exposure':1,
       'contrast':20 if faint else 1,'linear_anchor':anchor.tolist()if faint else None,'clipping':clipping,'reference_role':role};boards.append(row)
  if faint and o['original_case_id']in ['bark','raccoon-fur']:
   t=Image.new('RGB',(512,192),'#eeeeee');d=ImageDraw.Draw(t);tp=[]
   for j,i in enumerate([0,4,5]):
    px=8+168*j;t.paste(Image.fromarray(cells[i]),(px,24));d.text((px,5),names[i],fill='black');tp.append({'label':names[i],'png_xywh':[px,24,160,160]})
   dest=out/(row['id']+'-triplet.png');t.save(dest);triplets.append({'id':row['id']+'-triplet','image':reference(dest),'board':row['id'],'panels':tp,'parent_panel_indices':[0,4,5]})
assert len(boards)==12 and len(triplets)==4
write_json(out/'result.json',{'producer':reference(__file__),'operator_result':reference(r/'adc-bin-core-review-v2/result.json'),'scores':reference(r/'adc-bin-core-review-v2/scores.json'),'boards':boards,'triplets':triplets,'actual_viewing':'pending',
'scope':'All4 faint materials and2 preselected flats,RGGB,both EMA parents,all4 unmodified/exact-MHC/exact-sites/ADC-bin policies. Native160 pixels,common source transform; faint contrast20 is display only with shared target-ROI channel anchor. No per-method normalization or resizing.12 boards,4 exact-subset triplets; actual viewing/audit separate.0 neural/GPU/RAW/noise/training calls.'})
print('12 native boards and4 triplets')
