"""Exploratory fixed quantization-bin MHC correction, no targets in the operator."""
import os
from pathlib import Path
import numpy as np
import torch
from demosaic.cfa import adc_cfa_projection,malvar,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32


def interval_projection(prediction,packed,colors,wb,*,bits,black):
    assert bits==16 and black==.03
    with torch.autocast('cpu',enabled=False),ieee_fp32():
        p,y=prediction.float(),packed.float();levels=2**bits-1
        codes=torch.round((y.double()*(1-black)+black)*levels).clamp(0,levels)
        # The retained source quantizer is FP64 code selection then FP32 output.
        # Packed FP32 dequantization rounding cannot change recovered codes.
        assert torch.max(torch.abs((y.double()*(1-black)+black)*levels-codes))<.01
        lo=((codes-.5)/levels-black)/(1-black);hi=((codes+.5)/levels-black)/(1-black)
        lo=torch.where(codes==0,-torch.inf,lo);hi=torch.where(codes==levels,torch.inf,hi)
        low,high=lo.float(),hi.float()
        low=torch.where(low.double()<lo,torch.nextafter(low,torch.full_like(low,torch.inf)),low)
        high=torch.where(high.double()>hi,torch.nextafter(high,torch.full_like(high,-torch.inf)),high)
        assert torch.all(low<=high)
        measured=mosaic(p,colors);nearest=torch.minimum(torch.maximum(measured,low),high)
        output=p+malvar(nearest-measured,colors,wb)
        for b in range(len(p)):
            for phase,channel in enumerate(colors[b]):
                dy,dx=divmod(phase,2);output[b,int(channel),dy::2,dx::2]=nearest[b,phase]
        return output,low,high,nearest

os.sched_setaffinity(0,[6,7]);torch.set_num_threads(2)
root=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(root/'plan.json');collection=read_json(root/'collection/result.json')
cases={read_json(checked(v))['id']:read_json(checked(v))for v in collection['records']}
calibration_path=Path('/mnt/external/demosaic/evaluation/prospective-color-grid-20261017-v1/plan.json');calibration=read_json(calibration_path)
assert calibration['adc_bits']==16 and calibration['adc_black']==.03
out=root/'adc-interval-probe-v1';out.mkdir();rows=[];bypass=[]
with torch.inference_mode():
 for i,o in enumerate(plan['observations']):
  if o['noise']['shot']!=0 or o['noise']['read']!=0:bypass.append(o['id']);continue
  if o['kind']!='color-spot-check':assert o['noise']['ADC_bits']==16 and o['noise']['black_level']==.03
  with np.load(checked(o['arrays']),allow_pickle=False)as f:packed,colors,wb=[torch.from_numpy(f[k].copy())for k in ['packed','colors','wb']]
  for v in cases[o['id']]['variants']:
   original=torch.from_numpy(np.load(checked(v['prediction']),allow_pickle=False))
   result,lo,hi,nearest=interval_projection(original,packed,colors,wb,bits=16,black=.03)
   assert torch.isfinite(result).all()and torch.equal(mosaic(result,colors),nearest)
   # Target decoding is deliberately after the input-only correction.
   with np.load(checked(o['target']),allow_pickle=False)as f:target=torch.from_numpy(f['target'].copy())
   gt=mosaic(target,colors);assert torch.all((gt>=lo)&(gt<=hi)),'Reference not in declared ADC bins; do not claim consistency'
   before=(mosaic(original,colors).double()-gt.double()).square();after=(nearest.double()-gt.double()).square()
   assert torch.all(after<=before),'Nearest feasible measured site increased error'
   for label,value in [('intervalMHC',result),('exactSites',adc_cfa_projection(original,packed,colors,wb,mode='sites'))]:
    path=out/(v['label']+'-'+label+'-'+str(i)+'.npy')
    with path.open('xb')as stream:np.save(stream,value.numpy(),allow_pickle=False)
    rows.append({'id':o['id'],'method':v['label']+'+'+label,'policy':label,'prediction':reference(path),'raw_prediction':v['prediction'],
                 'target_samples_in_ADC_bins':True,'measured_camera_MSE_nonincreasing_for_interval':True,
                 'interval_projection_is_input_only':True})
assert len(rows)==96 and len(bypass)==86 and not torch.cuda.is_initialized()
write_json(out/'result.json',{'producer':reference(__file__),'parent_collection':reference(root/'collection/result.json'),
 'CFA_operator_source':reference(Path(malvar.__code__.co_filename)),'palette_calibration':reference(calibration_path),'rows':rows,
 'positive_noise_identity_observation_ids':bypass,'scope':'Exploratory quantization-aware ADC correction after unchanged exact-MHC20k diagnostic worsened faint PSNR. Fixed16-bit/black.03 metadata; no parameter/kernel/gain/threshold search or target fitting. Nearest representable FP32 value in recovered ADC bin, then same WB-aware MHC residual lift, with measured sites restored exactly; clipped codes use one-sided bins. Existing exactSites is a named control, not a new method. All24 targets decoded only after correction and checked inside bins; measured-channel camera squared errors never increase for interval projection. Missing-color/spatial errors have no such guarantee.96 physical outputs,0 new learned/RAW/noise/GPU/optimizer calls; no default/inference export or positive-noise change.'})
print('Completed96 fixed physical corrections; all measured targets in bins and interval measured errors nonincreasing')
