"""Physical-only CPU/CUDA table/output qualification; no neural module calls."""
import os
import shutil
from pathlib import Path
import numpy as np
import torch
from demosaic.adc_bins import adc_bin_bounds,adc_bin_projection
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

torch.set_num_threads(2);os.sched_setaffinity(0,[6,7])
root=Path('.cache/experiments/adc-bin-gpu-qualification-v2').resolve();root.mkdir();source=root/'adc_bins.py';shutil.copyfile('src/demosaic/adc_bins.py',source)
torch.cuda.set_per_process_memory_fraction(2*2**30/torch.cuda.get_device_properties(0).total_memory)
forwards=[]
def forbidden(module,args):forwards.append(type(module).__name__);raise RuntimeError('No neural/module forward admitted')
hook=torch.nn.modules.module.register_module_forward_pre_hook(forbidden)
tables=[];comparisons=[]
with torch.inference_mode():
 for precision in ['float32','float64']:
  dtype=getattr(torch,precision);codes=torch.arange(65536,dtype=dtype);black=torch.tensor(.03,dtype=dtype);packed=((codes/65535-black)/(1-black)).float()
  a,b=adc_bin_bounds(packed,bit_depth=16,black_level=.03,quantizer_precision=precision)
  x,y=adc_bin_bounds(packed.cuda(),bit_depth=16,black_level=.03,quantizer_precision=precision)
  assert torch.equal(a,x.cpu())and torch.equal(b,y.cpu())
  tables.append({'precision':precision,'all65536_CPU_CUDA_bin_bounds_bitexact':True})
 native=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve();plan=read_json(native/'plan.json');col=read_json(native/'collection/result.json');records={read_json(checked(v))['id']:read_json(checked(v))for v in col['records']}
 actual=read_json(native/'adc-bin-core-review-v2/result.json');outputs={(r['id'],r['method']):r for r in actual['rows']}
 for identity in ['bark-contrast0p025-adc-RGGB','flat-gray-l0.18-RGGB']:
  o=next(o for o in plan['observations']if o['id']==identity);precision='float32'if o['kind']=='color-spot-check'else'float64'
  with np.load(checked(o['arrays']))as f:packed,colors,wb=[torch.from_numpy(f[k].copy()).cuda()for k in ['packed','colors','wb']]
  for v in records[identity]['variants']:
   prediction=torch.from_numpy(np.load(checked(v['prediction']))).cuda()
   result=adc_bin_projection(prediction,packed,colors,wb,bit_depth=16,black_level=.03,quantizer_precision=precision,shot=0.,read=0.).cpu().numpy()
   reference_value=np.load(checked(outputs[identity,v['label']+'+adcBins']['prediction']))
   delta=result.astype(np.float64)-reference_value.astype(np.float64);maximum=float(np.abs(delta).max())*65535;rms=float(np.sqrt(np.mean(delta**2)))*65535
   assert maximum<=.25 and rms<=.025
   comparisons.append({'id':identity,'method':v['label'],'bitexact':np.array_equal(result,reference_value),'max_DN16':maximum,'RMS_DN16':rms})
hook.remove();assert not forwards
write_json(root/'result.json',{'producer':reference(__file__),'operator_source':reference(source),'tables':tables,'actual_saved_output_comparisons':comparisons,
 'module_forwards':len(forwards),'peak_torch_CUDA_GiB':torch.cuda.max_memory_allocated()/2**30,
 'scope':'Physical-only CUDA qualification under existing training concurrency,2GiB per-process cap. Exact all65536-code CPU/CUDA tables under both source codecs,4 actual retained input/parent-policy outputs compared under existing quarter-DN/RMS numerical bounds.0 learned/module/RAW/noise/optimizer calls. No isolated timing or new quality sample claim.'})
print('GPU physical qualification complete',comparisons)
