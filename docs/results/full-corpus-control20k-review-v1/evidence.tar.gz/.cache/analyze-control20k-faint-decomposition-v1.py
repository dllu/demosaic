"""Split retained faint error into channel bias and spatial error, without models."""
import os
from pathlib import Path

import numpy as np
from analyze_retained_faint_detail import error_components

from demosaic.archive_metrics import display, linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

os.sched_setaffinity(0,[8,9])
root=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve()
plan=read_json(root/'plan.json');collection=read_json(root/'collection/result.json')
cases={read_json(checked(b))['id']:read_json(checked(b))for b in collection['records']}
rows=[]
for o in plan['observations']:
    if o['kind']!='material'or'contrast0p025-adc'not in o['case_id']:continue
    with np.load(checked(o['arrays']),allow_pickle=False)as data:arrays=dict(data)
    with np.load(checked(o['target']),allow_pickle=False)as data:target=data['target'].astype(np.float64)[...,48:208,48:208]
    for variant in cases[o['id']]['variants']:
        prediction=np.load(checked(variant['prediction']),allow_pickle=False).astype(np.float64)[...,48:208,48:208]
        for name,convert in [('camera_RGB',lambda a:a),('linear_sRGB',lambda a:linear_rgb(a,arrays)),('clipped_sRGB',lambda a:display(a,arrays))]:
            rows.append({'id':o['id'],'source_id':o['source_id'],'method':variant['label'],'space':name,**error_components(convert(prediction),convert(target))})
summaries=[]
for space in ['camera_RGB','linear_sRGB','clipped_sRGB']:
    a=[r for r in rows if r['method']=='V120'and r['space']==space];b=[r for r in rows if r['method']=='scale-control20k'and r['space']==space]
    assert len(a)==len(b)==16
    parent={k:float(np.mean([r[k]for r in a]))for k in ['MSE','DC_MSE','spatial_MSE']}
    candidate={k:float(np.mean([r[k]for r in b]))for k in parent}
    delta={k:candidate[k]-parent[k]for k in parent};np.testing.assert_allclose(delta['MSE'],delta['DC_MSE']+delta['spatial_MSE'],rtol=1e-12,atol=1e-25)
    summaries.append({'space':space,'parent':parent,'candidate':candidate,'candidate_minus_parent':delta,
                      'spatial_fraction_of_added_MSE':delta['spatial_MSE']/delta['MSE']})
out=root/'faint-decomposition-v1';out.mkdir()
write_json(out/'result.json',{'producer':reference(__file__),'helper':reference(root/'report-dependency-recovery-v2/work/scripts/analyze_retained_faint_detail.py'),
           'collection':reference(root/'collection/result.json'),'rows':rows,'summaries':summaries,
           'scope':'All16 retained faint-ADC inputs, native160 ROI, matched fresh CPU EMA outputs. MSE=per-channel DC MSE+spatially centered MSE in camera,unclipped linear-sRGB and clipped-sRGB domains. Arithmetic MSE decomposition is distinct from averaging PSNR. No new model/GPU/noise/RAW/optimizer work.'})
print(summaries)
