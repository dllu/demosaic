"""Exploratory unchanged ADC-only physical projection on saved outputs, no models/targets."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import adc_cfa_projection
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

os.sched_setaffinity(0,[10,11]);torch.set_num_threads(2)
root=Path('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k').resolve()
plan=read_json(root/'plan.json');collection=read_json(root/'collection/result.json')
cases={read_json(checked(b))['id']:read_json(checked(b))for b in collection['records']}
out=root/'fixed-adc-diagnostic-v1';out.mkdir();rows=[];bypassed=[]
with torch.inference_mode():
    for index,o in enumerate(plan['observations']):
        if o['noise']['shot']!=0 or o['noise']['read']!=0:
            bypassed.append(o['id']);continue
        with np.load(checked(o['arrays']),allow_pickle=False)as data:
            packed,colors,wb=[torch.from_numpy(data[k].copy())for k in ['packed','colors','wb']]
        for v in cases[o['id']]['variants']:
            original=torch.from_numpy(np.load(checked(v['prediction']),allow_pickle=False))
            corrected=adc_cfa_projection(original,packed,colors,wb,mode='malvar')
            assert torch.isfinite(corrected).all()and corrected.shape==original.shape
            path=out/(v['label']+'-'+str(index)+'.npy')
            with path.open('xb')as stream:np.save(stream,corrected.numpy(),allow_pickle=False)
            rows.append({'id':o['id'],'method':v['label']+'+fixedADC','raw_prediction':v['prediction'],'prediction':reference(path)})
assert len(rows)==48 and len(bypassed)==86 and not torch.cuda.is_initialized()
write_json(out/'result.json',{'producer':reference(__file__),'operator_source':reference(root/'report-dependency-recovery-v2/work/src/demosaic/cfa.py'),
           'collection':reference(root/'collection/result.json'),'rows':rows,'positive_noise_identity_observation_ids':bypassed,
           'scope':'Exploratory physical diagnostic added after raw20k faint regression, using the pre-existing unchanged WB-aware malvar ADC projection. All24 zero-shot/read observations under both parent/candidate; no threshold/mode search or target fitting. Targets never decoded. Positive-noise policies retain the exact original prediction bindings.48 static physical corrections,0 learned/encoder/GPU/RAW/noise/optimizer calls. Does not change training or the raw checkpoint/default inference policy.'})
print('Wrote48 fixed physical corrections,86 positive-noise observations bypassed,0 models/targets')
