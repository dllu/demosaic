"""Verify archive bytes and explicitly preserve the publisher log snapshot."""
from pathlib import Path
import hashlib,tarfile,gzip
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
r=Path('docs/results/full-corpus-control20k-review-v1');pub=read_json(r/'publication.json');changed=[]
with tarfile.open(checked(pub['archive']))as tar:
 assert len(tar.getmembers())==len(pub['members'])
 for v in pub['members']:
  data=tar.extractfile(v['member']).read();assert hashlib.sha256(data).hexdigest()==v['source']['sha256']
  if reference(v['source']['path'])['sha256']!=v['source']['sha256']:
   assert v['member']=='.cache/publish-control20k-review-v1.log'and data==b''
   dest=r/'publisher-log-at-archive.log';dest.open('xb').write(data);changed.append({'original_at_capture':v['source'],'immutable_capture':reference(dest),'current_completed_log':reference(v['source']['path'])})
assert len(changed)==1
for v in read_json(checked(pub['native_manifest']))['images']:assert checked(v['image']).read_bytes()==checked(v['original_image']).read_bytes()
v1=read_json('.cache/experiments/full-corpus-control20k-review-queue-v1/native20k/adc-bin-core-review-v1/source-preservation.json');assert v1['original_operator_reference']['sha256']==reference(checked(v1['preserved_operator_bytes']))['sha256']
for a,b in [('src/demosaic/adc_bins.py','.cache/experiments/adc-bin-gpu-qualification-v2/adc_bins.py')]:assert reference(a)['sha256']==reference(b)['sha256']
write_json(r/'verification-addendum.json',{'auditor':reference(__file__),'publication':reference(r/'publication.json'),'archive_members_verified':len(pub['members']),'all64_PNG_bytes_verified':True,'publisher_log_snapshot':changed,
'preserved_superseded_operator':v1,'scope':'Every archived member matches its recorded SHA. The publisher archived its still-empty output log before writing its completion line; preserve that exact empty capture under a new immutable name and identify the completed log separately. Original archive/receipts unchanged. Superseded v1 operator bytes preserved; corrected v2 CPU/GPU executed source matches current helper. No new numerical/neural/GPU/training work.'})
for name in ['.cache/verify-published-control20k-review-v1.py','.cache/publish-control20k-review-v1.log']:
 dest=r/(Path(name).name+'.gz');data=Path(name).read_bytes()
 with dest.open('xb')as f:f.write(gzip.compress(data,mtime=0))
 assert gzip.decompress(dest.read_bytes())==data
print('602 archive members/64 PNGs verified; publisher empty-log snapshot explicitly retained')
