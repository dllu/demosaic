"""Wait for exact original full owners, then prepare paired native evidence once."""
import os
import subprocess
import sys
import time
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json, reference, write_json

repo=Path.cwd()
producer=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-v1'
review=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-review-v1'
os.sched_setaffinity(0,[18,19])
for path in [producer/'launch.json',review/'launch.json']:
    identity=read_json(path)
    while True:
        try:
            process=psutil.Process(identity['pid'])
            if process.create_time()!=identity['create_time'] or process.status()==psutil.STATUS_ZOMBIE:
                break
        except psutil.NoSuchProcess:
            break
        time.sleep(5)
assert read_json(producer/'controller-result.json')['producer_stages_succeeded']
assert read_json(review/'controller-result.json')['returncode']==0
assert read_json(review/'completed.json')['cross_study_comparison']
env=dict(os.environ,PYTHONPATH=str(repo/'src')+':'+str(repo/'scripts'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
stages=[]
for name,script,args in [
    ('guided-phase129-full-prior-panels-v1',repo/'scripts/add_neural_nuisance_baseline_panels.py',[str(review),str(repo/'.cache/experiments/neural-nuisance-full-review-v1'),str(review/'prior-panels')]),
    ('extra-neural-guided-phase129-full-stress-v1',repo/'.cache/extra-neural-guided-phase129-full-stress-v1.py',[]),
    ('analytic-guided-phase129-full-triplets-v1',repo/'.cache/analytic-guided-phase129-full-triplets-v1.py',[]),
    ('publish-neural-nuisance-guided-phase129-full-v1',repo/'.cache/publish-neural-nuisance-guided-phase129-full-v1.py',[]),
    ('native-guided-phase129-full-contact-sheets-v1',repo/'.cache/native-contact-sheets-v1.py',[str(review)]),
]:
    began=time.monotonic()
    with(repo/'.cache'/(name+'.log')).open('x')as log:
        code=subprocess.call([sys.executable,str(script),*args],env=env,stdout=log,stderr=subprocess.STDOUT)
    stages.append({'name':name,'returncode':code,'seconds':time.monotonic()-began})
    if code:break
write_json(repo/'.cache/guided-phase129-full-publication-prep-result-v1.json',{'script':reference(__file__),'stages':stages,'all_stages_succeeded':len(stages)==5 and all(r['returncode']==0 for r in stages),'scope':'Preparation only after original full producer/reviewer close; all70 paired native figures, including two declared-primary analytic triplets still require actual inspection before final publication. No replay/restart of inference or old baseline.'})
print(stages,flush=True)
