import os
os.sched_setaffinity(0,[14,15])
import os,sys,time,subprocess
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json,write_json,reference,verify_plan
from demosaic.experiments.runtime import owner_identity
root=Path(sys.argv[1]);plan=read_json(root/'plan.json');verify_plan(plan);stages=[]
for name,gpu in [('backgrounds',True),('predict',False),('score',False)]:
 env=os.environ.copy();env.update(PYTHONPATH=plan['work']+'/src:'+plan['work']+'/scripts',CUDA_VISIBLE_DEVICES='0'if gpu else'',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
 args=[plan['python'],plan['script']['path'],name,str(root)];began=time.time()
 with(root/(name+'.log')).open('x')as log:
  p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  write_json(root/(name+'-launch.json'),{'pid':p.pid,'create_time':psutil.Process(p.pid).create_time(),'command':args,'controller':owner_identity(),'plan':reference(root/'plan.json')})
  code=p.wait()
 stages.append({'stage':name,'returncode':code,'seconds':time.time()-began});write_json(root/'controller-progress.json',{'owner':owner_identity(),'stages':stages},replace=True)
 if code:break
write_json(root/'controller-result.json',{'stages':stages,'producer_stages_succeeded':len(stages)==3 and all(r['returncode']==0 for r in stages),'plan':reference(root/'plan.json'),'script':reference(__file__),'scope':'Producer closure and full scoring only; independent full-cohort/native review separately queued. Inherited all6_H1_outputs control-label Boolean means all computed H1 outputs, two at the declared single threshold2 in this panel.'})
