"""Launch the full guided-phase comparison once, with its exact-owner review queue."""
import os
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, write_json, verify_plan

repo=Path.cwd()
root=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-v1'
review=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-review-v1'
plan=read_json(root/'plan.json');verify_plan(plan)
assert plan['full_panel'] and plan['phase_guide'] and plan['aggregation_config']
assert plan['maximum_new_neural_forwards']==0 and plan['background_field_count']==2320
assert plan['prediction_cache']==reference(repo/'.cache/experiments/neural-nuisance-guided-phase129-pilot-v1/collection.json')
assert len(read_json(checked(plan['background_cache']))['rows'])==1164
assert not(root/'launch.json').exists() and not review.exists()
controller=(repo/'.cache/experiments/neural-nuisance-fixed-bg129-full-v1/controller.py').read_text().replace('[16,17]','[14,15]')
(root/'controller.py').write_text(controller)
env=dict(os.environ,PYTHONPATH=str(repo/'src'),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
with(root/'controller.log').open('x')as log:
    process=subprocess.Popen([sys.executable,str(root/'controller.py'),str(root)],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
identity={'pid':process.pid,'create_time':psutil.Process(process.pid).create_time(),'plan':reference(root/'plan.json'),'controller':reference(root/'controller.py')}
write_json(root/'launch.json',identity)
with(root/'review-prepare.log').open('x')as log:
    subprocess.run([sys.executable,str(repo/'scripts/review_neural_nuisance_panel.py'),'prepare',str(review),'--producer',str(root),'--pilot-role-errors',str(repo/'.cache/experiments/neural-nuisance-guided-phase129-pilot-v1/summary-review/absolute-role-errors.json'),'--baseline-summary',str(repo/'.cache/experiments/neural-nuisance-full-review-v1/summary.json')],stdout=log,stderr=subprocess.STDOUT,check=True,env=env)
(review/'controller.py').write_text((repo/'.cache/experiments/neural-nuisance-fixed-bg129-full-review-v1/controller.py').read_text())
with(review/'controller.log').open('x')as log:
    reviewer=subprocess.Popen([sys.executable,str(review/'controller.py'),str(review)],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
write_json(review/'launch.json',{'pid':reviewer.pid,'create_time':psutil.Process(reviewer.pid).create_time(),'plan':reference(review/'plan.json'),'controller':reference(review/'controller.py')})
write_json(root/'study.json',{'plan':reference(root/'plan.json'),'review_plan':reference(review/'plan.json'),'launcher':reference(__file__),'pilot':reference(repo/'docs/results/neural-nuisance-guided-phase129-v1/publication.json'),'primary_quality_method':'conditional-local-t2','primary_external_baseline':'prior256-NN','renderer_primary_method':'local-t2','scope':'Full1152 finite roles from8 reused development sources/all4 CFAs/two repeats/three priors/near-far plus12 protected/material contexts. Primary scientific question: analytic nuisance plus A-only NN-guided phase vs completed256 NN, with parent and unguided pilot retained. Neural-nuisance primary pilot regression stays visible among all6 controls. All2320 fields adopted,48 exact pilot cases/288 threshold2 outputs eligible by complete-package/config/actual-input equality. Zero NN/DINO replay, no new sensor data/noise/RAW decoding/training admission or weight change. All1164 corrections close before GT/reference quality analysis. Exact8-source bootstrap descriptive, not population camera confidence. Both protected GFX families/profiles/ROIs/JPEGs qualitative, never exact GT; originals read-only.'})
print('producer',identity,flush=True)
print('reviewer',read_json(review/'launch.json'),flush=True)
