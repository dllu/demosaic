"""Publish measured FP16 tuning results and verify each native panel."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
from statistics import mean
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from full import ROOT

NAMES = ("heuristic-a", "tuned-a", "tuned-b", "heuristic-b")
IMAGES = Path("docs/images") / ROOT.name
RESULTS = Path("docs/results") / ROOT.name
DEP = ROOT.with_name("corpus100k-fp16-throughput-v1")
ORIG = ROOT.with_name("corpus100k-mixed-precision-v1")


def copy_board(spec):
    src = checked(spec["image"])
    dest = IMAGES / src.name
    shutil.copyfile(src, dest)
    assert reference(dest)["sha256"] == spec["image"]["sha256"]
    spec["image"]["path"] = dest.name
    with Image.open(dest) as image:
        frame = np.asarray(image.convert("RGB"))
    values = {}
    for pan in spec["panels"]:
        label = pan.get("label", pan.get("name"))
        x,y,w,h = pan["png_xywh"]
        crop = frame[y:y+h,x:x+w]
        assert crop.shape == (160,160,3) == (h,w,3)
        values[label] = crop
    return values


def main():
    IMAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    full_receipts = {name:reference(ROOT/f"{name}.json") for name in NAMES}
    full = {name:read_json(checked(value)) for name,value in full_receipts.items()}
    quality_receipt = reference(ROOT/"native.json")
    native = read_json(checked(quality_receipt))
    outlier_receipt = reference(ROOT/"outliers.json")
    extremes = read_json(checked(outlier_receipt))
    settings = full["heuristic-a"]["settings"]
    base_sha = full["heuristic-a"]["anchor"]["sha256"]
    for name, receipt in full.items():
        assert receipt["settings"]==settings and receipt["checkpoint"]==native["checkpoint"]
        assert receipt["source"]==full["heuristic-a"]["source"] and receipt["anchor"]["sha256"]==base_sha
        assert len(receipt["runs"])==2 and all(row["stats"]["tiles"]==520 for row in receipt["runs"])
        hashes = {row["RGB16"]["sha256"] for row in receipt["runs"]}
        assert len(hashes)==1
        for row in receipt["runs"]:
            checked(row["crops"])
            if name.startswith("heuristic"):
                assert row["RGB16"]["sha256"]==base_sha and row["difference"]["codes"]==305987556
            else:
                assert row["RGB16"]["sha256"]!=base_sha and row["difference"]["channels"]==305987556
                checked(row["RGB16"])
    tuned_hashes = {full[name]["runs"][0]["RGB16"]["sha256"] for name in ("tuned-a","tuned-b")}
    assert len(tuned_hashes)==2

    for row in native["main"]+native["cab"]+extremes["rows"]:
        copy_board(row["board"])
    boards = [row["board"] for row in native["exact"] if "board" in row]
    for board in boards:
        comparison = copy_board(board["board"])
        triplet = copy_board(board["triplet"])
        assert all(np.array_equal(comparison[label], crop) for label,crop in triplet.items())
    assert (len(native["main"]),len(native["cab"]),len(boards))==(4,4,2)
    manifest = IMAGES/"manifest.json"
    native["outliers"] = extremes["rows"]
    native["viewed_local"] = datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()
    native["visual_review"] = read_json(ROOT/"visual-review.json")
    write_json(manifest,native,replace=True)

    files = [checked(x) for x in full_receipts.values()]
    files += [checked(quality_receipt), checked(outlier_receipt)]
    files += [checked(x) for x in native["receipts"].values()]
    files += sorted(ROOT.glob("*.py")) + sorted(ROOT.glob("*.log"))
    files += [ROOT/"visual-review.json"]
    files += [DEP/name for name in ("full_throughput.py","review_throughput.py","screen_throughput.py","overlap.json")]
    files += [ORIG/name for name in ("full_production.py","screen.py")]
    files += [Path(path) for path in ("src/demosaic/inference.py","src/demosaic/pretrained_rgb.py",
              "src/demosaic/precision.py","scripts/report_scene_wave_guides.py",
              "configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json")]
    members = {str(p.resolve().relative_to(Path.cwd())):p for p in files}
    archive = RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"w:xz",preset=4) as out:
        for arc,path in sorted(members.items()):
            out.add(path,arcname=arc,recursive=False)
    with tarfile.open(archive) as out:
        for arc,path in members.items():
            with out.extractfile(arc) as entry:
                assert hashlib.file_digest(entry,"sha256").hexdigest()==reference(path)["sha256"]

    timing = {}
    for group in ("heuristic","tuned"):
        measures = [receipt for name,receipt in full.items() if name.startswith(group)]
        timing[group] = {
            "first_restore_mean":mean(r["runs"][0]["restore_wall_seconds"] for r in measures),
            "warm_restore_mean":mean(r["runs"][1]["restore_wall_seconds"] for r in measures),
        }
    write_json(RESULTS/"publication.json", {
        "scope":"FP16 algorithm selection on the same standing 102 MP frame, with two process repeats per policy and one complete warm repeat per process. Six exact-target long contexts and eight GFX crops. No new fixed photo or camera coverage.",
        "checkpoint":native["checkpoint"], "schedule":NAMES, "settings":settings,
        "source":full["heuristic-a"]["source"], "timing_summary":timing, "timing_receipts":full_receipts,
        "native_receipt":quality_receipt, "outlier_receipt":outlier_receipt, "manifest":reference(manifest),
        "archive":reference(archive), "warm_repeat_hashes":{name:receipt["runs"][1]["RGB16"]["sha256"] for name,receipt in full.items()},
        "cross_process_tuned_delta":extremes["between_processes"],
        "exact_contexts":[{k:r[k] for k in ("roi","scores","delta")} for r in native["exact"]],
    },replace=True)
    print("Verified eight full restores, twelve native figures, and the frozen evidence.",timing)


if __name__=="__main__":
    main()
