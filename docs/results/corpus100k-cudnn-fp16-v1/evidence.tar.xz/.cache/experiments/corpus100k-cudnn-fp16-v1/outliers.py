"""Inspect worst RGB16 differences and compare repeated engine selections."""
from pathlib import Path

import numpy as np
import tifffile
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from full import FIXTURE, ROOT, SETTINGS, exported_differences
from native_review import display_sensor, native_png


def main():
    source = {name:reference(ROOT/f"{name}.json") for name in ("tuned-a","tuned-b")}
    a,b = (read_json(checked(v)) for v in source.values())
    assert a["anchor"] == b["anchor"]
    assert a["checkpoint"] == b["checkpoint"]
    assert a["source"] == b["source"]
    _,meta = read_raw(read_json(FIXTURE)["noisy"])
    assert meta.flip == 0
    wb = torch.tensor(meta.white_balance)[None]
    matrix = torch.tensor(meta.camera_to_srgb)[None]
    paths = [checked(row) for row in (a["anchor"], a["runs"][0]["RGB16"], b["runs"][0]["RGB16"])]
    decoded = [tifffile.memmap(path) for path in paths]
    rows = []
    for index, receipt in enumerate((a,b), 1):
        magnitude, (x,y,c) = receipt["runs"][0]["difference"]["max_DN16_and_sensor_xy_channel"]
        assert abs(int(decoded[0][y,x,c]) - int(decoded[index][y,x,c])) == magnitude
        x0 = min(max(x-80,0),decoded[0].shape[1]-160)
        y0 = min(max(y-80,0),decoded[0].shape[0]-160)
        panels = []
        for name, arr in zip(("Eager FP16","cuDNN search A","cuDNN search B"),decoded,strict=True):
            rgb = torch.from_numpy(arr[y0:y0+160,x0:x0+160].astype(np.float32)).permute(2,0,1)/65535
            panels.append((name,display_sensor(rgb,wb,matrix,(0,0,160,160),1)))
        rows.append(dict(xywh=[x0,y0,160,160], coordinate=[x,y,c], difference=magnitude,
                         display_exposure=1, board=native_png(ROOT/f"outlier-{index}.png",panels)))
    write_json(ROOT/"outliers.json", {
        "runs":source, "rows":rows, "driver":reference(__file__),
        "between_processes":exported_differences(paths[1], paths[2], SETTINGS),
    }, replace=True)


if __name__ == "__main__":
    main()
