"""Run and compare native quality witnesses in fresh process caches."""
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
DEVICE = ROOT.with_name("corpus100k-device-tiles-v1")
THROUGHPUT = ROOT.with_name("corpus100k-fp16-throughput-v1")
sys.path.extend([str(THROUGHPUT), str(ROOT.with_name("corpus100k-mixed-precision-v1"))])

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import restore_tiled
from demosaic.io import read_raw
from full import FIXTURE, SETTINGS
from review_throughput import (board_panels, difference, display_sensor, native_board,
    native_png, noisy_malvar, observe_scene, photometry, sample_scene_recipe, unpack)
from screen_throughput import bound_model

CAB = Path("docs/images/full-corpus-long100k-native-v1/manifest.json")
EXACT = THROUGHPUT / "overlap.json"
LABELS = {"heuristic": "Eager FP16", "tuned": "cuDNN search FP16"}
MAIN_LABELS = {"heuristic-a": LABELS["heuristic"], "tuned-a": LABELS["tuned"],
               "tuned-b": "Second cuDNN search FP16"}


def cab_rows():
    return [r for r in read_json(CAB)["images"] if r["role"] == "board" and r["id"].startswith("mesh-")]


def exact_input(row):
    x, y, w, h = row["cache_box_xywh"]
    src = np.load(checked(row["source"]), mmap_mode="r", allow_pickle=False)
    crop = torch.from_numpy(src[y:y+h, x:x+w].astype(np.float32)).permute(2, 0, 1)/65535
    return observe_scene(crop, replace(sample_scene_recipe(0), **row["recipe"]))


@torch.inference_mode()
def run_arm(mode):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(
        min(1, 16 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    torch.backends.cudnn.benchmark_limit = 10
    torch.backends.cudnn.benchmark = mode == "tuned"
    model, binding = bound_model()
    rows = {}
    for item in cab_rows():
        prov = item["provenance"]
        x,y,w,h = prov["ROI_xywh"]
        with np.load(checked(prov["input_arrays"]), allow_pickle=False) as data:
            raw = unpack(torch.from_numpy(data["packed"]))[0,0]
            pred, stats = restore_tiled(model, raw, data["colors"][0], wb=data["wb"],
                                       matrix=data["matrix"], shot=prov["noise"]["shot"],
                                       read=prov["noise"]["read"], **SETTINGS)
        artifact = ROOT / f'{mode}-{item["id"]}.npz'
        np.savez_compressed(artifact, prediction=pred[:,y:y+h,x:x+w].numpy())
        rows[item["id"]] = {"output": reference(artifact), "stats":stats, "input":prov["input_arrays"]}
    for i, case in enumerate(read_json(EXACT)["rows"]):
        prov = case["provenance"]
        obs = exact_input(prov)
        raw = unpack(obs.packed[None])[0,0]
        params = prov["recipe"]
        pred, stats = restore_tiled(model, raw, obs.colors, shot=params["shot"],
                                    read=params["read"], wb=obs.wb, matrix=obs.matrix, **SETTINGS)
        scores = photometry(pred[None].numpy(), {k:getattr(obs,k)[None].numpy()
                             for k in ("target", "packed", "colors", "wb", "matrix")})
        artifact = ROOT / f"{mode}-exact-{i}.npz"
        roi = (680,480,160,160) if raw.shape[1] == 1536 else (480,680,160,160)
        x,y,w,h = roi
        np.savez_compressed(artifact, prediction=pred[:,y:y+h,x:x+w].numpy())
        rows[f"exact-{i}"] = {"output":reference(artifact), "stats":stats,
                             "scores":{key:float(value[0]) for key,value in scores.items()},
                             "roi":roi, "provenance":prov}
    write_json(ROOT/f"native-{mode}.json", {"checkpoint":binding, "rows": rows, "mode":mode,
              "driver":reference(__file__), "sources":{"exact":reference(EXACT),"cab":reference(CAB)}})


def read_output(binding, key="prediction"):
    with np.load(checked(binding), allow_pickle=False) as data:
        return data[key]


@torch.inference_mode()
def render():
    torch.set_num_threads(3)
    receipts = {name:reference(ROOT/f"native-{name}.json") for name in LABELS}
    quality = {name:read_json(checked(value)) for name,value in receipts.items()}
    checkpoint = quality["heuristic"]["checkpoint"]
    assert quality["tuned"]["checkpoint"] == checkpoint
    controls = quality["heuristic"]["rows"]
    tuned = quality["tuned"]["rows"]
    results = {"checkpoint":checkpoint, "cab":[], "main":[], "exact":[], "receipts":receipts}
    scene = read_json(FIXTURE)
    _,meta = read_raw(scene["noisy"])
    main_ref = Path("docs/images/corpus100k-mixed-precision-v1")
    main_by_name = {r["id"]:r for r in read_json(main_ref/"manifest.json")["main_views"]}
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    full = {name:read_json(ROOT/f"{name}.json") for name in MAIN_LABELS}
    assert all(row["checkpoint"] == checkpoint for row in full.values())
    for r in scene["regions"]:
        name = r["name"]
        spec = main_by_name[name]["board"]
        ref_source = main_ref / Path(spec["image"]["path"]).name
        assert reference(ref_source)["sha256"] == spec["image"]["sha256"]
        refs = board_panels(ref_source,spec["panels"])
        values = {arm:read_output(receipt["runs"][0]["crops"],name) for arm,receipt in full.items()}
        panels = [(k,v) for k,v in refs.items() if "Noisy" in k]
        panels.extend((MAIN_LABELS[k],display_sensor(torch.from_numpy(v),wb,matrix,(0,0,160,160),4))
                      for k,v in values.items())
        panels.extend((k,v) for k,v in refs.items() if "ISO100" in k)
        results["main"].append({"name":name, "provenance":{
            "fixture":reference(FIXTURE), "crop":[*r["noisy_xy"],160,160], "noise":full["heuristic-a"]["settings"],
            "source":full["heuristic-a"]["source"], "display_exposure":4, "reference_board":reference(ref_source)},
            "deltas":{k:difference(v,values["heuristic-a"]) for k,v in values.items() if k.startswith("tuned")},
            "board":native_png(ROOT/f"{name}.png",panels)})
    for item in cab_rows():
        name = item["id"]
        prov = item["provenance"]
        assert controls[name]["input"] == tuned[name]["input"] == prov["input_arrays"]
        refs = board_panels(checked(item["image"]),prov["panels"])
        with np.load(checked(prov["input_arrays"]), allow_pickle=False) as data:
            wb, matrix = torch.from_numpy(data["wb"]), torch.from_numpy(data["matrix"])
        values = {mode:read_output(qual[name]["output"]) for mode,qual in (("heuristic",controls),("tuned",tuned))}
        panels = [("Noisy Malvar",refs["Noisy Malvar"])]
        panels.extend((LABELS[k],display_sensor(torch.from_numpy(v),wb,matrix,(0,0,160,160),prov["display_exposure"]))
                      for k,v in values.items())
        panels.extend((k,refs[k]) for k in ("ISO100 ref, not GT","SOOC ISO6400 JPEG","SOOC ISO100 JPEG"))
        results["cab"].append({"name":name, "provenance":prov,
            "delta":difference(values["tuned"],values["heuristic"]),
            "board":native_png(ROOT/f"{name}.png",panels)})
    for index in range(6):
        key = f"exact-{index}"
        row = controls[key]
        prov = row["provenance"]
        assert prov == tuned[key]["provenance"]
        before, after = (read_output(items[key]["output"]) for items in (controls,tuned))
        scores = {mode:qual[key]["scores"] for mode,qual in (("heuristic",controls),("tuned",tuned))}
        info = {"source":prov,"roi":row["roi"],"scores":scores,"delta":difference(after,before)}
        if index < 2:
            obs = exact_input(prov)
            x,y,w,h = row["roi"]
            sup = {k:getattr(obs,k)[None].numpy() for k in ("target","packed","colors","wb","matrix")}
            noisy = noisy_malvar(sup)[0,:,y:y+h,x:x+w]
            target = sup["target"][0,:,y:y+h,x:x+w]
            info["board"] = native_board(ROOT, ("pinakothek","highlight")[index],
                    [noisy,before,after,target], sup, {**prov,"checkpoint":checkpoint,"native_roi":row["roi"]},
                    labels=("Noisy Malvar", LABELS["heuristic"],LABELS["tuned"],"Exact GT"),
                    triplet_indices=(0,2,3), exposure=prov["display_exposure"], roi=(0,0,w,h))
        results["exact"].append(info)
    write_json(ROOT/"native.json",results,replace=True)


if __name__ == "__main__":
    if sys.argv[1] == "render":
        render()
    else:
        assert sys.argv[1] in LABELS
        run_arm(sys.argv[1])
