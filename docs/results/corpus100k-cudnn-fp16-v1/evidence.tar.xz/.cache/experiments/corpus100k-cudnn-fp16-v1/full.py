"""Compare separately selected cuDNN FP16 engines on the same complete frame."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
for name in ("corpus100k-fp16-throughput-v1", "corpus100k-mixed-precision-v1"):
    sys.path.append(str(ROOT.with_name(name)))

from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import restore_tiled
from demosaic.io import read_raw, write_rgb16
from full_throughput import exported_differences
from screen_throughput import bound_model, gpu_jobs, versions, SHOT, READ

FIXTURE = Path("configs/gfx-qualitative-20231231.json")
ARCHIVE = ROOT.with_name("corpus100k-device-tiles-v1")
SETTINGS = dict(tile=512, overlap=64, batch_size=4, device="cuda", precision="float16")


@torch.inference_mode()
def run(label, limit, repeats):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(
        min(1, 16 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    started = time.perf_counter()
    fixture = read_json(FIXTURE)
    source = reference(fixture["noisy"])
    raw, meta = read_raw(source["path"])
    decoded = time.perf_counter()
    model, checkpoint = bound_model()
    loaded = time.perf_counter()
    torch.backends.cudnn.benchmark_limit = limit or 10
    torch.backends.cudnn.benchmark = bool(limit)
    archived = read_json(ARCHIVE / "full.json")
    anchor = archived["runs"][0]
    assert archived["source"]["sha256"] == source["sha256"]
    assert archived["checkpoint"]["sha256"] == checkpoint["sha256"]
    archive_tiff = checked(anchor["RGB16"])
    args = dict(SETTINGS, shot=SHOT, read=READ, wb=meta.white_balance, matrix=meta.camera_to_srgb)
    rows = []
    for index in range(repeats):
        process_start = time.time()
        t0 = time.perf_counter()
        prediction, stats = restore_tiled(model, raw, color_indices(meta.pattern), **args)
        t1 = time.perf_counter()
        output = ROOT / f"{label}-{index}.tiff"
        write_rgb16(output, prediction.permute(1, 2, 0).numpy(), metadata=meta, flip=meta.flip)
        t2 = time.perf_counter()
        print(label, limit, index, t1-t0, t2-t1, stats, flush=True)
        crops = ROOT / f"{label}-{index}-native.npz"
        np.savez_compressed(crops, **{
            reg["name"]: prediction[:, y:y+160, x:x+160].numpy()
            for reg in fixture["regions"] for x, y in [reg["noisy_xy"]]
        })
        del prediction
        row = dict(index=index, restore_wall_seconds=t1-t0, writer_seconds=t2-t1,
                   first_frame_seconds=t2-started if index == 0 else None,
                   process_utc_unix_seconds=process_start,
                   stats=stats, RGB16=reference(output), crops=reference(crops), gpu_jobs=gpu_jobs())
        if row["RGB16"]["sha256"] != anchor["RGB16"]["sha256"]:
            row["difference"] = exported_differences(archive_tiff, output, SETTINGS)
        else:
            row["difference"] = dict(codes=raw.size*3, RMS_DN16=0, max_DN16=0, exact=True)
        rows.append(row)
        print(label, index, row["difference"], flush=True)
        write_json(ROOT / f"{label}.json", dict(
            driver=reference(__file__), versions=versions(), source=source, checkpoint=checkpoint,
            fixture=reference(FIXTURE), settings={**SETTINGS, "shot":SHOT, "read":READ},
            algorithm_search_limit=limit, raw_decode_seconds=decoded-started,
            checkpoint_setup_seconds=loaded-decoded, anchor=anchor["RGB16"], runs=rows),
            replace=True)
        if row["RGB16"]["sha256"] == anchor["RGB16"]["sha256"]:
            output.unlink()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("label")
    parser.add_argument("limit", type=int)
    parser.add_argument("--repeats", type=int, default=2)
    args = parser.parse_args()
    run(args.label, args.limit, args.repeats)
