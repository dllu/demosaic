"""Audit local amplitude corrections on exact Bayer inputs and phase rotations."""

import numpy as np
from measure import BAND, ROOT
from query_consensus import MODES, green_agreement, phase_basis

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def sample(basis, image):
    green = np.stack([image[g // 2 :: 2, g % 2 :: 2].ravel() for g in basis.green])
    return np.einsum("gkf,gf->gk", basis.projection, green)


def known_signs():
    results = []
    for name, layout in PATTERNS.items():
        basis, axes = phase_basis(tuple(layout), BAND)
        frequency = int(np.flatnonzero(np.all(axes == [4 / 32, -2 / 32], axis=-1))[0])
        atom = basis.image[frequency * 2 : frequency * 2 + 2]
        fitted = np.array([0.042, 0.027])
        clean = (fitted[:, None, None] * atom).sum(axis=0)
        a = sample(basis, clean + 0.16)[None].reshape(1, 2, len(axes), 2)
        cov = basis.projection @ basis.projection.swapaxes(-1, -2)
        pair = np.arange(len(axes) * 2).reshape(len(axes), 2)
        cov = cov[:, pair[:, :, None], pair[:, None, :]]
        noise = np.array([0.001])
        weak = green_agreement(a, a * 0.5, noise, cov)
        for policy in MODES:
            np.testing.assert_allclose(weak[policy][0, frequency], fitted * 0.5, atol=1e-13)
        too_strong = green_agreement(a, 1.5 * a, noise, cov)
        np.testing.assert_allclose(
            too_strong["signed_cross_power"][0, frequency], -fitted * 0.5, atol=1e-13
        )
        assert all(
            np.max(np.abs(too_strong[key])) < 1e-13
            for key in ("cross_power", "radial", "reciprocal")
        )
        inconsistent = green_agreement(
            a * np.array([1, -1])[None, :, None, None], 0.25 * a, noise, cov
        )
        assert all(np.max(np.abs(x)) < 1e-13 for x in inconsistent.values())
        results.append(
            {
                "pattern": name,
                "frequency_yx": axes[frequency].tolist(),
                "response_small_parent": {k: v[0, frequency].tolist() for k, v in weak.items()},
                "response_parent_excess": {
                    k: v[0, frequency].tolist() for k, v in too_strong.items()
                },
                "opposite_phase_rejects_all": True,
            }
        )
    return results


def rotation_and_swap():
    rng = np.random.default_rng(51580604)
    x = rng.normal(size=(7, 2, 3, 2))
    y = rng.normal(size=x.shape)
    s = rng.uniform(0.1, 0.5, 7)
    f = rng.normal(size=(2, 3, 2, 2))
    cov = f @ f.swapaxes(-1, -2)
    phi = 0.77
    r = np.array([[np.cos(phi), -np.sin(phi)], [np.sin(phi), np.cos(phi)]])
    base = green_agreement(x, y, s, cov)
    shift = green_agreement(x @ r, y @ r, s, r.T @ cov @ r)
    flip = green_agreement(x[:, ::-1], y[:, ::-1], s, cov[::-1])
    for name in MODES:
        np.testing.assert_allclose(shift[name], base[name] @ r, atol=1e-14, rtol=0)
        np.testing.assert_allclose(flip[name], base[name], atol=1e-14, rtol=0)
    return {
        k: {
            "rotation_max": float(np.max(np.abs(shift[k] - base[k] @ r))),
            "green_swap_max": float(np.max(np.abs(flip[k] - base[k]))),
        }
        for k in MODES
    }


if __name__ == "__main__":
    data = reference(ROOT / "results.json")
    receipt = read_json(checked(data))
    assert (
        len(receipt["short"]) == 24 and len(receipt["long"]) == 32 and len(receipt["natural"]) == 32
    )
    write_json(
        ROOT / "algebra.json",
        {
            "driver": reference(__file__),
            "retained": data,
            "tests": known_signs(),
            "invariance": rotation_and_swap(),
        },
    )
