"""Compare green amplitude estimators on exact wire and natural-photo targets."""

from pathlib import Path

import numpy as np
from query_consensus import MODES, PREVIOUS, corrections, reencode
from evaluate_phase import BAND, BUDGETS, DENSE, patch, replay, run, summary, summarize_natural
from evaluate_wide import FLAT, RESPONSE, WireFundamental, values
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def field_updates(case, data, base, budget):
    shot, read = (case["profile"][k] for k in ("shot", "read"))
    scene, colors = (data[k] for k in ("scene_packed", "colors"))
    query = case["box"]
    maximum = budget
    if budget < 4800:
        uniform = patch.build_exterior(
            scene, colors, query, shot, read, band=BAND, max_windows=budget
        )
        if uniform is not None:
            maximum = max(1, len(uniform.coords))
    dense = patch.build_exterior(
        scene, colors, query, shot, read, band=BAND, max_windows=maximum, dense_radius=DENSE
    )
    phase = reencode(scene, colors, dense, shot, read) if dense is not None else None
    results = {k: [] for k in MODES}
    for raw, parent in zip(data["packed"], base, strict=True):
        for key, delta in corrections(raw, parent[1], colors, shot, read, query, phase).items():
            results[key].append(
                replay.apply_delta(np.zeros_like(parent), delta, data["wb"], data["matrix"], 1)
            )
    return {k: np.stack(items) for k, items in results.items()}, len(
        dense.coords
    ) if dense is not None else 0


def wires(original):
    case = original["case"]
    data, base, _ = replay.read_inputs(case)
    with np.load(checked(case["input"]), allow_pickle=False) as f:
        clean = {name: f[name] for name in ("target", "support")}
    metric = WireFundamental(data | clean, case["fixture"]["geometry"])
    predicted = base.astype(np.float64)
    origin = metric(predicted)
    scores = {}
    for budget in BUDGETS:
        control = original["width"][str(budget)]
        correction, count = field_updates(case, data, base, budget)
        assert count == control["windows"]["dense"]
        terms = {}
        for name, change in correction.items():
            plus, minus = metric(predicted + change), metric(predicted - change)
            terms[name] = {
                k: (
                    [v, (plus[k] - minus[k]) / 2]
                    if k in RESPONSE
                    else [
                        v**2,
                        (plus[k] ** 2 - minus[k] ** 2) / 2,
                        (plus[k] ** 2 + minus[k] ** 2) / 2 - v**2,
                    ]
                )
                for k, v in origin.items()
            }
        for key, rec in terms["phase_pair"].items():
            np.testing.assert_allclose(rec, control["terms"]["phase_pair"][key], atol=1e-10, rtol=0)
        scores[str(budget)] = {**control, "terms": control["terms"] | terms}
    return {"case": case, "width": scores}


def calibration(rows, old):
    control = read_json(checked(old))
    locked = {}
    for budget, prior in control["strengths"].items():
        group = [r["width"][budget] for r in rows]
        parent = values(group, "origin", FLAT, 0)
        locked[budget] = dict(prior)
        for method in MODES:

            def cost(gain):
                return float((values(group, method, FLAT, gain) - parent).mean())

            gain = brentq(lambda g: cost(g) - 0.1, 0, 0.8) if cost(0.8) > 0.1 else 0.8
            locked[budget][method] = {"gain": gain, "flat_DN16": cost(gain)}
        np.testing.assert_allclose(
            locked[budget]["phase_pair"]["gain"], prior["phase_pair"]["gain"], atol=1e-12, rtol=0
        )
    return locked


def natural(original):
    case = original["case"]
    data, base, _ = replay.read_inputs(case)
    change, count = field_updates(case, data, base, 4800)
    assert count == original["windows"]["dense"]
    with np.load(checked(case["input"]), allow_pickle=False) as z:
        exact = replay.transform(z["target"], data)
    parent = replay.transform(base, data)
    output = dict(original["terms"])
    for key, delta in change.items():
        seen = replay.transform(delta, data)
        output[key] = {k: replay.terms(v, seen[k], exact[k]) for k, v in parent.items()}
    for band in parent:
        for key, actual in output["phase_pair"][band].items():
            target = original["terms"]["phase_pair"][band][key]
            np.testing.assert_allclose(actual, target, atol=1e-10, rtol=0)
    return {**original, "terms": output}


def main():
    held = reference(PREVIOUS / "results.json")
    retained = read_json(checked(held))
    old = read_json(checked(retained["settings"]))
    trained, seconds = run(old["calibration"], wires)
    fit = calibration(trained, retained["settings"])
    proof = ROOT / "calibration.json"
    write_json(
        proof,
        {
            "operator": reference(ROOT / "query_consensus.py"),
            "driver": reference(__file__),
            "previous": retained["settings"],
            "seconds": seconds,
            "strengths": fit,
            "calibration": trained,
        },
    )
    print("calibration", fit, flush=True)
    long, lsecond = run(retained["long"], wires)
    short, ssecond = run(retained["short"], wires)
    photos, nsecond = run(retained["natural"], natural)
    write_json(
        ROOT / "results.json",
        {
            "driver": reference(__file__),
            "calibration": reference(proof),
            "prior": held,
            "long": long,
            "short": short,
            "natural": photos,
            "seconds": {"long": lsecond, "short": ssecond, "natural": nsecond},
            "scores": {
                "long": summary(long, fit),
                "short": summary(short, fit),
                "natural": summarize_natural(photos, fit["4800"]),
            },
        },
    )
    print("finished", lsecond, ssecond, nsecond, flush=True)


if __name__ == "__main__":
    main()
