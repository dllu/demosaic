"""Publish the locked off-grid evaluation, native views, and source evidence."""

import shutil
import tarfile
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
EXTERNAL = Path("/mnt/external/demosaic")
ART = REPO / ("docs/images/" + ROOT.name)
RES = REPO / ("docs/results/" + ROOT.name)
FILES = {
    "calibration": "calibration.json",
    "retained": "results.json",
    "fresh": "fresh-score.json",
    "algebra": "algebra.json",
    "coverage": "coverage.json",
    "camera_fields": "camera-fields.json",
    "standing": "native/standing-extended/result.json",
    "exact": "native/exact/result.json",
    "viewing": "views.json",
}


def pixels(board):
    artifact = Image.open(checked(board["image"])).convert("RGB")
    out = {}
    for cell in board["panels"]:
        x, y, w, h = cell["png_xywh"]
        assert (w, h) == (160, 160) and x + w <= artifact.width and y + h <= artifact.height
        out[cell.get("label", cell.get("name"))] = np.asarray(artifact.crop((x, y, x + w, y + h)))
    return out


def keep(ref, group=""):
    file = checked(ref)
    target = ART / group / file.name
    assert not target.exists()
    shutil.copyfile(file, target)
    assert reference(target)["sha256"] == ref["sha256"]
    return ref | {"path": str(target.relative_to(ART))}


def native(board, group):
    pixels(board)
    return board | {"image": keep(board["image"], group)}


def main():
    receipts = {k: reference(ROOT / v) for k, v in FILES.items()}
    d = {k: read_json(checked(v)) for k, v in receipts.items()}
    c, n, f, a, s, cf, g, x, view = d.values()
    assert (
        n["calibration"]
        == f["calibration"]
        == g["calibration"]
        == x["calibration"]
        == receipts["calibration"]
    )
    assert x["fresh"] == view["fresh"] == receipts["fresh"]
    assert view["native"] == {"standing-extended": receipts["standing"], "exact": receipts["exact"]}
    assert g["fields"] == receipts["camera_fields"]
    assert a["retained"] == s["retained"] == receipts["retained"]
    assert len(n["long"]) == len(n["natural"]) == 32 and len(n["short"]) == 24
    assert len(f["rows"]) == 24 and sum(r["gap_pixels"] > 0 for r in f["rows"]) == 16
    assert len(a["tests"]) == len(x["rows"]) == 4
    assert len(g["rows"]) == 8 and sum(len(r["displays"]) for r in g["rows"]) == 12
    assert len(view["views"]) == 7
    for ref in view["views"].values():
        checked(ref)
    parents = read_json(checked(f["parents"]))
    fresh_plan = read_json(checked(parents["plan"]))
    assert parents["plan"] == s["fresh_plan"] and fresh_plan["parent_visits_checked"] == 559808
    retained_ids = {
        r["case"]["source"]["id"] for key in ("long", "short", "natural") for r in n[key]
    }
    assert retained_ids.isdisjoint(p["source"]["id"] for p in fresh_plan["sources"])
    for row in parents["rows"]:
        checked(row["input"])
        checked(row["rgb"])
    for row in cf["rows"]:
        checked(row["paths"])

    (ART / "standing").mkdir(parents=True)
    (ART / "exact").mkdir()
    RES.mkdir(parents=True)
    standing = []
    exact = []
    for r in g["rows"]:
        scopes = []
        for display in r["displays"]:
            shown = set(pixels(display["board"]))
            assert {
                "Radial consensus",
                "Cross-power amplitude",
                "Original phase-paired",
                "V120 EMA",
                "Corpus 100k",
                "ISO100 AHD reference",
            } <= shown
            if r["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= shown
            scopes.append(display | {"board": native(display["board"], "standing")})
        standing.append(r | {"displays": scopes})
    for r in x["rows"]:
        before, after = (pixels(r[k]) for k in ("board", "triplet"))
        assert list(after) == ["Noisy Malvar", "Radial consensus", "Exact GT"]
        for k, v in after.items():
            np.testing.assert_array_equal(v, before[k])
        exact.append(r | {k: native(r[k], "exact") for k in ("board", "triplet")})
    m = ART / "manifest.json"
    write_json(
        m,
        {
            "weights": parents["weights"],
            "standing": standing,
            "exact": exact,
            "fresh_plan": parents["plan"],
            "figure": keep(view["figure"]),
            "review": {
                "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                "sheets": receipts["viewing"],
                "main": "Sky remains smooth. Coarse links are connected. Fine lines and foliage stay soft.",
                "mesh": "Both cab profiles and exposures viewed with both camera JPEGs and ISO100 AHD. The right remains clearest with incomplete fine crossings.",
                "exact": "Higher contrast and weaker axes stay separated. Visible gains over the prior Fourier filter are small, and the exact flat controls stay smooth.",
            },
        },
    )
    payload = [
        *receipts.values(),
        *[r["driver"] for r in d.values()],
        c["operator"],
        c["previous"],
        n["prior"],
        f["parents"],
        parents["plan"],
        fresh_plan["driver"],
        fresh_plan["freeze_driver"],
        fresh_plan["fixture"],
        g["baseline"],
        cf["previous"],
        reference(ROOT / "consensus_measure.py"),
        reference(m),
        reference(__file__),
        reference(ROOT.with_name("scene-phase-power-v1") / "phase_pairs.py"),
        reference(ROOT.with_name("scene-phase-power-v1") / "evaluate_phase.py"),
        reference(ROOT.with_name("scene-patch-crossfit-v1") / "capture.py"),
        reference(REPO / "src/demosaic/scene_patch_covariance.py"),
        reference(REPO / "configs/gfx-green-mesh-20231231.json"),
        reference(REPO / "configs/gfx-qualitative-20231231.json"),
    ]
    archive = RES / "evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for ref in {v["path"]: v for v in payload}.values():
            file = checked(ref)
            name = (
                file.relative_to(REPO)
                if file.is_relative_to(REPO)
                else Path("external") / file.relative_to(EXTERNAL)
            ).as_posix()
            tar.add(file, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(k).read()).hexdigest() == v for k, v in members.items())
    write_json(
        RES / "publication.json",
        {
            "scope": "Experimental corrections on frozen Corpus 100k; fresh 24-photo off-grid wire transfer and both standing GFX families.",
            "weights": parents["weights"],
            "strengths": c["strengths"],
            "fresh": f["summary"],
            "retained": n["scores"],
            "spectral_coverage": s["summary_median"],
            "seconds": {
                "calibration": c["seconds"],
                "retained": n["seconds"],
                "fresh_inference": parents["seconds"],
                "fresh_scoring": f["seconds"],
                "standing_fields": cf["seconds"],
            },
            "receipts": receipts,
            "native": reference(m),
            "archive": reference(archive),
            "members": members,
        },
    )


if __name__ == "__main__":
    main()
