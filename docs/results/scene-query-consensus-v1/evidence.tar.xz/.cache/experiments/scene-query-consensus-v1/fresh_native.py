"""Render the fixed GFX views and fresh exact-target query-consensus crops."""

import sys
import numpy as np
import torch
from consensus_measure import ROOT, replay
from query_consensus import PREVIOUS, MODES
from fresh_score import fields_with_dense
from atlas_probe import pixels, render
from evaluate_wide import COMP, HOLE, LENGTH
from render_wide import native_board, native_png, peak_fit

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LABELS = {
    "dense": "Dense cosine prior",
    "phase_pair": "Original phase-paired",
    "radial": "Radial consensus",
    "cross_power": "Cross-power amplitude",
    "signed_cross_power": "Signed cross-power",
}


def camera(config):
    binding = reference(ROOT / "camera-fields.json")
    existing = reference(PREVIOUS / "native/standing/result.json")
    original = {r["id"]: r for r in read_json(checked(existing))["rows"]}
    scales = {
        k: v["gain"]
        for k, v in read_json(checked(config))["strengths"]["4800"].items()
        if k in ("dense", *MODES)
    }
    room = ROOT / "native/standing-extended"
    room.mkdir(parents=True)
    rows = []
    for r in read_json(checked(binding))["rows"]:
        with np.load(checked(r["paths"]), allow_pickle=False) as src:
            parent, raw, wb, matrix, colors = (
                src[k] for k in ("parent", "raw", "wb", "matrix", "colors")
            )
            fields = {k: src[k] for k in scales}
        rgb = {k: parent + g * fields[k] for k, g in scales.items()}
        aux = r["unit_crop_DN16"]
        record = {k: g * aux[k] for k, g in scales.items()}
        projected = {}
        normalized = {}
        if r["id"].startswith("mesh"):
            q = peak_fit(raw, parent, rgb, colors, r["roi"])
            normalized_gain = {
                k: scales["phase_pair"] * aux["phase_pair"] / v for k, v in aux.items() if v > 0
            }
            normalized_prediction = {k: parent + g * fields[k] for k, g in normalized_gain.items()}
            matched = peak_fit(raw, parent, normalized_prediction, colors, r["roi"])
            base = np.asarray(q["parent"]["percent_of_observed"])

            def delta(result):
                return {
                    k: (np.asarray(p["percent_of_observed"]) - base).tolist()
                    for k, p in result.items()
                    if k not in ("parent", "observed")
                }

            projected = delta(q)
            normalized = delta(matched)
        views = []
        for d in original[r["id"]]["displays"]:
            images = pixels(d["board"])
            exposure = d["exposure"]
            np.testing.assert_array_equal(
                render(parent, wb, matrix, r["roi"], exposure), images["Corpus 100k"]
            )
            np.testing.assert_array_equal(
                render(rgb["phase_pair"], wb, matrix, r["roi"], exposure),
                images["Phase-paired prior"],
            )
            panels = [(k, images[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Corpus 100k")]
            panels.extend(
                (label, render(rgb[key], wb, matrix, r["roi"], exposure))
                for key, label in LABELS.items()
            )
            panels.extend(
                (k, images[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in images
            )
            tag = f"{r['id']}-x{exposure:g}.png"
            board = native_png(room / tag, panels)
            views.append({"exposure": exposure, "board": board})
        rows.append(
            r
            | {
                "rms": record,
                "same_raw_projection": projected,
                "equal_rgb_projection": normalized,
                "displays": views,
            }
        )
        print(r["id"], record, {k: projected.get(k) for k in LABELS}, flush=True)
    write_json(
        room / "result.json",
        {
            "driver": reference(__file__),
            "fields": binding,
            "baseline": existing,
            "calibration": config,
            "rows": rows,
        },
    )


def fresh(config):
    proof = reference(ROOT / "fresh-score.json")
    d = read_json(checked(proof))
    assert d["calibration"] == config
    pool = [row for row in d["rows"] if row["gap_pixels"]]

    def change(row, metric):
        scores = row["scores"]
        return scores["radial"][metric] - scores["phase_pair"][metric]

    best = min(pool, key=lambda p: change(p, "gap_continuing_strong_RMS_DN16"))
    adverse = max((r for r in pool if r is not best), key=lambda p: change(p, HOLE))
    dest = ROOT / "native/exact"
    dest.mkdir(parents=True)
    rows = []
    for row, note in (
        (best, "largest reduction in continuing-wire gap error"),
        (adverse, "largest increase in false weak projection among the other gaps"),
    ):
        case = row["case"]
        f, parent, v120 = replay.read_inputs(case)
        delta = fields_with_dense(case, f, parent)
        with np.load(checked(case["input"]), allow_pickle=False) as z:
            truth = z["target"]
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        for i, role in ((0, "present"), (3, "flat")):
            obs = noisy_malvar(camera | {"packed": f["packed"][i : i + 1]})[0]
            labels = ("Noisy Malvar", "V120 EMA", "Corpus 100k", *LABELS.values(), "Exact GT")
            prediction = [
                obs,
                v120[i],
                parent[i],
                *(parent[i] + d["gains"][k] * delta[k][i] for k in LABELS),
                truth[i],
            ]
            rows.append(
                native_board(
                    dest,
                    f"offgrid-{case['fixture']['index']:02}-{role}",
                    prediction,
                    camera,
                    {
                        "source": case,
                        "selection": note,
                        "role": role,
                        "gain": d["gains"],
                        "change_vs_phase_pair": {
                            k: change(row, k)
                            for k in (HOLE, COMP, LENGTH, "gap_continuing_strong_RMS_DN16")
                        },
                    },
                    labels=labels,
                    triplet_indices=(0, labels.index(LABELS["radial"]), len(labels) - 1),
                    exposure=2,
                    contrast=1,
                    roi=(48, 48, 160, 160),
                )
            )
    write_json(
        dest / "result.json",
        {"driver": reference(__file__), "calibration": config, "fresh": proof, "rows": rows},
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    config = reference(ROOT / "calibration.json")
    if sys.argv[1] == "camera":
        camera(config)
    else:
        assert sys.argv[1] == "fresh"
        fresh(config)
