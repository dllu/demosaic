"""Use agreement between measured green phases to bound a spectral correction."""

from pathlib import Path
import sys

import numpy as np

from demosaic import scene_patch_covariance as patch

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("scene-phase-power-v1")
sys.path.insert(0, str(PREVIOUS))
from phase_pairs import paired_query_support, phase_basis, powers, reencode

MODES = ("phase_pair", "radial", "cross_power", "signed_cross_power", "reciprocal")


def unit_direction(coefficients):
    amplitude = np.linalg.norm(coefficients, axis=-1, keepdims=True)
    return np.divide(coefficients, amplitude, out=np.zeros_like(coefficients), where=amplitude > 0)


def green_agreement(coefficients, parent, noise, cov):
    """Compute alternative updates on one fixed set of paired local measurements."""
    measured = coefficients.mean(axis=1)
    current = parent.mean(axis=1)
    innovation = (coefficients - parent).mean(axis=1)
    current_gate = paired_query_support(innovation, coefficients, noise, cov)
    original = innovation * current_gate[..., None]

    common = unit_direction(measured)
    gate = paired_query_support(common, coefficients, noise, cov)
    radial_gap = np.sum(innovation * common, axis=-1)
    radial = (gate * np.maximum(radial_gap, 0))[..., None] * common

    # Disagreement in phase or amplitude reduces the cross-power amplitude.
    cross = np.sqrt(np.maximum(np.sum(coefficients[:, 0] * coefficients[:, 1], axis=-1), 0))
    missing = cross - np.sum(current * common, axis=-1)
    cross_update = (gate * np.maximum(missing, 0))[..., None] * common
    signed_update = (gate * missing)[..., None] * common

    # A measured phase in one physical green proposes a direction. The
    # other green measures the amplitude along that fixed direction.
    direction = unit_direction(coefficients)
    held = np.sum(direction * coefficients[:, ::-1], axis=-1)
    fitted = np.sum(direction * parent[:, ::-1], axis=-1)
    variance = np.einsum("bgki,gkij,bgkj->bgk", direction, cov[::-1], direction)
    sigma = noise[:, None, None] * np.sqrt(np.maximum(variance, 1e-12))
    supported = np.clip((held / sigma - 0.5) / 2, 0, 1)
    reciprocal = (direction * (supported * np.maximum(held - fitted, 0))[..., None]).mean(axis=1)
    return {
        "phase_pair": original,
        "radial": radial,
        "cross_power": cross_update,
        "signed_cross_power": signed_update,
        "reciprocal": reciprocal,
    }


def coefficients_for_query(raw, parent, colors, shot, read, box, atlas):
    shape = parent.shape
    size = atlas.band.size
    basis, _ = phase_basis(tuple(colors), atlas.band)
    y, x = np.meshgrid(*(np.arange(0, n - size + 1, size // 2) for n in shape), indexing="ij")
    coords = np.column_stack((y.ravel(), x.ravel()))
    windows = patch.sample_windows(raw, coords, size)
    features, coefficients, noise, valid = patch.encode(windows, basis, shot, read)
    offsets = np.arange(size)
    ys = coords[:, 0, None, None] + offsets[:, None]
    xs = coords[:, 1, None, None] + offsets[None, :]
    current = parent[ys, xs]
    greens = np.stack([current[:, g // 2 :: 2, g % 2 :: 2] for g in basis.green], axis=1)
    projected = np.einsum("gkf,ngf->ngk", basis.projection, greens.reshape(len(coords), 2, -1))
    donor, weights = patch.choose_exterior(
        features, coords + np.asarray(box)[[1, 0]], atlas, ranked=True
    )
    return basis, offsets, ys, xs, coefficients, projected, noise, valid, donor, weights


def corrections(raw, parent, colors, shot, read, box, atlas):
    result = {name: np.zeros_like(parent) for name in MODES}
    if atlas is None or len(atlas.coords) < 8 or min(parent.shape) < atlas.band.size:
        return result
    basis, offsets, ys, xs, raw_coefs, fit, noise, valid, donors, weights = coefficients_for_query(
        raw, parent, colors, shot, read, box, atlas
    )
    count = raw_coefs.shape[-1] // 2
    gram = basis.projection @ basis.projection.swapaxes(-1, -2)
    pairs = np.arange(count * 2).reshape(count, 2)
    cov = gram[:, pairs[:, :, None], pairs[:, None, :]]
    products = (donors[:, :, 0] * donors[:, :, 1]).reshape(len(weights), -1, count, 2).mean(axis=-1)
    gain = powers(products, weights, np.sum(cov[0] * cov[1], axis=(-1, -2)) / 16)
    updates = green_agreement(
        raw_coefs.reshape(len(gain), 2, count, 2),
        fit.reshape(len(gain), 2, count, 2),
        noise,
        cov,
    )
    taper = np.sin((offsets + 0.5) * np.pi / len(offsets)) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(gain), *window.shape)))
    for key, update in updates.items():
        value = (update * (gain * valid[:, None])[..., None]).reshape(len(gain), -1)
        field = np.einsum("nk,kyx->nyx", value, basis.image)
        np.add.at(result[key], (ys, xs), field * window)
        result[key] /= np.maximum(1, norm)
    return result
