"""Run query consensus corrections on the fixed sensor native GFX windows."""

import time
from pathlib import Path

import numpy as np
import torch
from measure import BAND, DENSE, ROOT, patch, replay
from query_consensus import PREVIOUS, corrections, reencode
from atlas_probe import exact_query, load_standing, packed_scene

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

OUT = Path("/mnt/external/demosaic") / ROOT.name / "camera"


def main():
    torch.set_num_threads(2)
    old = reference(PREVIOUS / "camera-fields.json")
    old_fields = {r["id"]: r for r in read_json(checked(old))["rows"]}
    _, saved, lookup = load_standing()
    OUT.mkdir()
    rows = []
    start = time.monotonic()
    for family in ("main", "mesh"):
        group = [r for r in saved["rows"] if r["id"].startswith(family)]
        ref, raw, colors = packed_scene(group)
        for r in group:
            former = old_fields[r["id"]]
            assert ref == former["raw"] and r["query"] == former["absolute_query"]
            packed, parent, roi, wb, matrix = exact_query(r, lookup, raw, colors)
            shot, read = (r["noise"][k] for k in ("shot", "read"))
            dense = patch.build_exterior(
                raw, colors, r["query"], shot, read, band=BAND, dense_radius=DENSE
            )
            indexed = reencode(raw, colors, dense, shot, read)
            fixes = corrections(packed, parent[1], colors, shot, read, r["query"], indexed)
            units = {
                k: replay.apply_delta(np.zeros_like(parent), v, wb, matrix, 1)
                for k, v in fixes.items()
            }
            with np.load(checked(former["paths"]), allow_pickle=False) as source:
                for k, array in (
                    ("raw", packed),
                    ("parent", parent),
                    ("wb", wb),
                    ("matrix", matrix),
                    ("phase_pair", units["phase_pair"]),
                ):
                    np.testing.assert_array_equal(array, source[k])
                units["dense"] = source["dense"]
            answer = OUT / f"{r['id']}.npz"
            with answer.open("xb") as f:
                np.savez_compressed(
                    f, parent=parent, raw=packed, colors=colors, wb=wb, matrix=matrix, **units
                )
            x, y, w, h = roi
            region = np.s_[..., y : y + h, x : x + w]
            rms = {
                k: float(np.sqrt(np.mean(a[region].astype(float) ** 2)) * 65535)
                for k, a in units.items()
            }
            rows.append(
                {
                    **former,
                    "paths": reference(answer),
                    "phase_bank": former["paths"],
                    "unit_crop_DN16": rms,
                }
            )
            print(r["id"], rms, flush=True)
    write_json(
        ROOT / "camera-fields.json",
        {
            "driver": reference(__file__),
            "previous": old,
            "rows": rows,
            "seconds": time.monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
