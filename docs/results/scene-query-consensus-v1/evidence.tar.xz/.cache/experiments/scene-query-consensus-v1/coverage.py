"""Check fixed carrier representation on the native delivery grid."""

import numpy as np
from consensus_measure import BAND, ROOT, patch
from query_consensus import phase_basis
from fresh_fields import OUT
from render_wide import CAMERA_PEAKS

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def measure(frequencies, cfa):
    f_, _ = phase_basis(cfa, BAND)
    dct = patch.patch_basis(cfa, BAND)
    index = np.arange(BAND.size) - (BAND.size - 1) * 0.5
    yy, xx = np.meshgrid(index, index, indexing="ij")
    rows = []
    for frequency in frequencies:
        x, y = frequency
        phase = 2 * np.pi * (x * xx + y * yy)
        axes, _ = np.linalg.qr(np.column_stack((np.cos(phase).ravel(), np.sin(phase).ravel())))
        paired = ((f_.image.reshape(len(f_.image), -1) @ axes) ** 2).reshape(-1, 2, 2).sum(
            (1, 2)
        ) / 2
        cosine = ((dct.image.reshape(len(dct.image), -1) @ axes) ** 2).sum(axis=1) / 2
        assert paired.sum() <= 1.0000001 and cosine.sum() <= 1.0000001
        rows.append(
            {
                "frequency_xy": frequency,
                "pair_sum_fraction": float(paired.sum()),
                "max_pair_fraction": float(paired.max()),
                "three_pairs_fraction": float(np.sort(paired)[-3:].sum()),
                "cosine_sum_fraction": float(cosine.sum()),
                "nearest_bin_cycles_per_pixel": float(
                    np.linalg.norm(np.asarray(frequency) - np.rint(32 * np.asarray(frequency)) / 32)
                ),
            }
        )
    return rows


def main():
    prior = reference(ROOT / "results.json")
    existing = read_json(checked(prior))
    parent_plan = reference(OUT / "plan.json")
    new = read_json(checked(parent_plan))
    orig = [r["case"]["fixture"]["geometry"]["frequency"][1:] for r in existing["short"]]
    fresh = [x["geometry"]["frequency"][1:] for x in new["sources"]]
    rows = {
        "short_retained": [measure(f, (0, 1, 1, 2))[0] for f in orig],
        "short_offgrid": [measure(f, (0, 1, 1, 2))[0] for f in fresh],
        "cab_observed_peaks": measure(CAMERA_PEAKS, (0, 1, 1, 2)),
    }
    assert all(r["nearest_bin_cycles_per_pixel"] >= 0.008 for r in rows["short_offgrid"])
    keys = tuple(k for k in rows["short_offgrid"][0] if k != "frequency_xy")
    summary = {
        label: {k: float(np.median([r[k] for r in cells])) for k in keys}
        for label, cells in rows.items()
    }
    write_json(
        ROOT / "coverage.json",
        {
            "driver": reference(__file__),
            "retained": prior,
            "fresh_plan": parent_plan,
            "summary_median": summary,
            "rows": rows,
            "scope": "Pure continuous sinusoids on one native 32-pixel query window.",
        },
    )
    print(summary, flush=True)


if __name__ == "__main__":
    main()
