"""Freeze independent off-grid weak-mesh fields and replay the existing EMAs."""

from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / ROOT.name / "fresh"
SEED = 202611192006
COUNT = 24
FAMILIES = ("strip", "ellipse", "smooth-dip")

sys.path.insert(0, str(ROOT.with_name("scene-patch-width-v1")))
import capture_wide as old


def carrier(rng, angle_sign, bounds):
    for _ in range(400):
        f = 1 / rng.uniform(*bounds)
        angle = rng.uniform(0.54, 1.03)
        wave = f * np.array([np.cos(angle), angle_sign * np.sin(angle)])
        if np.linalg.norm(wave - np.rint(32 * wave) / 32) >= 0.008:
            return wave.tolist()
    raise RuntimeError("Could not draw an off-grid orientation")


def geometry(index):
    rng = np.random.default_rng(scene_seed(SEED, index, "off-grid"))
    shape = old.geometry(index)
    shape["family"] = FAMILIES[index // 8]
    shape["frequency"] = [carrier(rng, 1, (7.25, 8.90)), carrier(rng, -1, (7.20, 9.25))]
    shape["strength"] = rng.uniform([0.011, 0.0045], [0.016, 0.009]).tolist()
    return shape


def freeze():
    preceding = reference("/mnt/external/demosaic/scene-patch-width-v1/plan.json")
    prior = read_json(checked(preceding))
    exclude = [
        preceding,
        *prior["source_exclusions"],
        reference(ROOT.with_name("scene-phase-power-v1") / "results.json"),
    ]
    seen = set()
    for entry in exclude:
        old.scan(read_json(checked(entry)), seen)
    for row in old.lines(prior["training_manifest"]):
        old.scan(row, seen)
    candidates = []
    for row in old.lines(prior["source_pool"]):
        if (
            row["split"] == "val"
            and row["bin_factor"] == 4
            and min(row["shape"][:2]) >= 512
            and row["id"] not in seen
            and row["cache_sha256"] not in seen
        ):
            candidates.append(row)
    candidates.sort(key=lambda r: sha256(f"{SEED}/{r['id']}".encode()).digest())
    chosen = []
    for row in candidates:
        if row["id"] in seen or row["cache_sha256"] in seen:
            continue
        seen.update((row["id"], row["cache_sha256"]))
        index = len(chosen)
        (box,) = scene_crop_boxes(
            row["shape"][:2], patch_size=512, count=1, seed=scene_seed(SEED, index, "crop")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SEED, index, "off-grid-camera")))
        camera.update(
            pattern=tuple(PATTERNS)[index % 4],
            black=0.03,
            shot=old.PROFILE["shot"],
            read=old.PROFILE["read"],
            exposure=old.PROFILE["exposure"],
        )
        chosen.append(
            {
                "source": row,
                "box": box,
                "index": index,
                "geometry": geometry(index),
                "camera": camera,
                "partition": "fresh_confirmation",
            }
        )
        if len(chosen) == COUNT:
            break
    assert len(chosen) == COUNT
    ids = {item["source"]["id"] for item in chosen}
    hashes = {item["source"]["cache_sha256"] for item in chosen}
    count = 0
    for trace in read_json(checked(prior["parent_traces"]))["source_traces"]:
        for line in old.lines(trace):
            for visit in line["sources"]:
                if visit["kind"] == "photographic":
                    assert visit["source_id"] not in ids and visit["cache_sha256"] not in hashes
                    count += 1
    assert count == prior["parent_visits_checked"] == 559808
    binding = OUT / "plan.json"
    OUT.mkdir(parents=True, exist_ok=True)
    write_json(
        binding,
        {
            "driver": reference(old.__file__),
            "freeze_driver": reference(__file__),
            "fixture": prior["fixture"],
            "weights": prior["weights"],
            "query": prior["query"],
            "seed": SEED,
            "noise": old.PROFILE,
            "count": COUNT,
            "source_pool": prior["source_pool"],
            "source_exclusions": exclude,
            "training_manifest": prior["training_manifest"],
            "parent_visits_checked": count,
            "roles": ["weak-present", "weak-exterior-only", "strong-only", "flat"],
            "sources": chosen,
            "parent_traces": prior["parent_traces"],
        },
    )
    return binding


def main():
    proposed = freeze()
    old.SEED = SEED
    old.N = COUNT
    old.OUT = OUT
    old.ROLES = tuple(read_json(proposed)["roles"])
    torch.cuda.set_per_process_memory_fraction(
        min(1, 10 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    old.run(proposed)


if __name__ == "__main__":
    main()
