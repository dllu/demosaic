"""Lay out native views and the independent off-grid score differences."""

import os

import numpy as np
from PIL import Image, ImageDraw
from consensus_measure import ROOT
from atlas_probe import pixels

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def sheet(tag, rows, columns):
    canvas = Image.new("RGB", (8 + 168 * len(columns), 30 + 185 * len(rows)), "#eeeeee")
    text = ImageDraw.Draw(canvas)
    for index, col in enumerate(columns):
        text.text((8 + 168 * index, 6), col, fill="black")
    for i, (name, board) in enumerate(rows):
        choices = pixels(board)
        text.text((8, 191 + 185 * i), name, fill="black")
        for j, column in enumerate(columns):
            cut = Image.fromarray(choices[column])
            assert cut.size == (160, 160)
            canvas.paste(cut, (8 + 168 * j, 30 + 185 * i))
    dest = ROOT / f"view-{tag}.png"
    canvas.save(dest)
    return reference(dest)


def figure(r):
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    order = ("radial", "cross_power", "signed_cross_power", "reciprocal")
    labels = ("Radial consensus", "Cross-power amplitude", "Signed cross-power", "Reciprocal check")
    links = ("fundamental_response", "gap_continuing_strong_RMS_DN16", "fundamental_false_RMS_DN16")
    titles = ("Intact response", "Continuing-wire error", "False projection in true gaps")
    xlabels = ("Percentage points", "DN16 RMS", "DN16 RMS")
    fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.2), layout="constrained", sharey=True)
    for ax, metric, title, xlabel in zip(axes, links, titles, xlabels, strict=True):
        modes = r["summary"][metric]["values"]
        v = np.array([modes[k]["phase_pair"] for k in order])
        ax.axvline(0, color="#888888", lw=1)
        ax.errorbar(
            v[:, 0],
            np.arange(len(labels)),
            xerr=[v[:, 0] - v[:, 1], v[:, 2] - v[:, 0]],
            fmt="o",
            capsize=3.3,
            color="#126c79",
        )
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.grid(axis="x", alpha=0.22)
    axes[0].set_yticks(np.arange(len(labels)), labels)
    axes[0].invert_yaxis()
    fig.suptitle("Off-grid mesh fields vs the original phase-paired filter")
    dst = ROOT / "off-grid-effects.png"
    fig.savefig(dst, dpi=155)
    return reference(dst)


def main():
    refs = {k: reference(ROOT / f"native/{k}/result.json") for k in ("standing-extended", "exact")}
    stand, full = (read_json(checked(x))["rows"] for x in refs.values())
    views = {}
    methods = (
        "Noisy (Malvar)",
        "V120 EMA",
        "Corpus 100k",
        "Original phase-paired",
        "Radial consensus",
        "Cross-power amplitude",
        "ISO100 AHD reference",
    )
    for family, gain in (("main", 4), ("mesh", 4), ("mesh", 16)):
        rows = [
            (r["id"], d["board"])
            for r in stand
            if r["id"].startswith(family)
            for d in r["displays"]
            if d["exposure"] == gain
        ]
        tag = f"{family}-x{gain}"
        views[tag] = sheet(tag, rows, methods)
        second = ("Dense cosine prior", "Signed cross-power")
        if family == "mesh":
            second = ("ISO6400 camera JPEG", *second, "Radial consensus", "ISO100 camera JPEG")
        views[tag + "-controls"] = sheet(tag + "-controls", rows, second)
    views["exact"] = sheet(
        "exact",
        [(a["id"], a["board"]) for a in full],
        (
            "Noisy Malvar",
            "Corpus 100k",
            "Dense cosine prior",
            "Original phase-paired",
            "Radial consensus",
            "Cross-power amplitude",
            "Exact GT",
        ),
    )
    numerical = reference(ROOT / "fresh-score.json")
    graph = figure(read_json(checked(numerical)))
    write_json(
        ROOT / "views.json",
        {
            "driver": reference(__file__),
            "native": refs,
            "fresh": numerical,
            "views": views,
            "figure": graph,
        },
    )


if __name__ == "__main__":
    main()
