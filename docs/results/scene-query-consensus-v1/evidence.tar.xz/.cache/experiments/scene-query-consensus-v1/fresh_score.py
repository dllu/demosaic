"""Score locked inference policies on unseen off-grid wire backgrounds."""

import numpy as np
from consensus_measure import BAND, DENSE, MODES, ROOT, field_updates, patch, replay, run
from evaluate_wide import WireFundamental

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from fresh_fields import OUT


def fields_with_dense(case, f, parent):
    updates, _ = field_updates(case, f, parent, 4800)
    profile = case["profile"]
    shot, read = (profile[k] for k in ("shot", "read"))
    scene, colors = (f[k] for k in ("scene_packed", "colors"))
    box = case["box"]
    dense = patch.build_exterior(scene, colors, box, shot, read, band=BAND, dense_radius=DENSE)
    recovered = []
    for raw, p in zip(f["packed"], parent, strict=True):
        candidate = patch.corrections(
            raw, p[1], colors, shot, read, box, dense, validate_donors=True
        )["donor_and_query"]
        recovered.append(replay.apply_delta(np.zeros_like(p), candidate, f["wb"], f["matrix"], 1))
    updates["dense"] = np.stack(recovered)
    return updates


def analyze(row, gains):
    f, parent, v120 = replay.read_inputs(row)
    assert parent.shape == v120.shape == (4, 3, 256, 256)
    delta = fields_with_dense(row, f, parent)
    with np.load(checked(row["input"]), allow_pickle=False) as raw:
        known = {k: raw[k] for k in ("target", "support")}
    metric = WireFundamental(f | known, row["fixture"]["geometry"])
    anchor = parent.astype(np.float64)
    score = {"parent": metric(anchor), "v120": metric(v120)}
    for name, correction in delta.items():
        score[name] = metric(anchor + gains[name] * correction)
    return {"case": row, "scores": score, "gap_pixels": int(metric.gap.sum())}


def summarize(rows):
    rng = np.random.default_rng(202611192033)
    output = {}
    for name in sorted({k for r in rows for k in r["scores"]["parent"]}):
        eligible = [r["scores"] for r in rows if name in r["scores"]["parent"]]
        resampled = np.vstack(
            (np.arange(len(eligible)), rng.integers(0, len(eligible), size=(8000, len(eligible))))
        )
        values = {
            method: np.array([r[method][name] for r in eligible])[resampled].mean(axis=1)
            for method in eligible[0]
        }
        out = {}
        for k, points in values.items():
            current = {"value": float(points[0])}
            for ref in ("parent", "dense", "phase_pair"):
                d = points - values[ref]
                current[ref] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975])]
            out[k] = current
        output[name] = {"count": len(eligible), "values": out}
    return output


def main():
    captured = reference(OUT / "parents.json")
    source = read_json(checked(captured))
    choices = reference(ROOT / "calibration.json")
    config = read_json(checked(choices))
    scales = {k: config["strengths"]["4800"][k]["gain"] for k in (*MODES, "dense")}
    rows, elapsed = run(source["rows"], lambda r: analyze(r, scales))
    assert len(rows) == 24 and sum(r["gap_pixels"] > 0 for r in rows) == 16
    write_json(
        ROOT / "fresh-score.json",
        {
            "driver": reference(__file__),
            "parents": captured,
            "calibration": choices,
            "gains": scales,
            "summary": summarize(rows),
            "rows": rows,
            "seconds": elapsed,
            "lock": "No calibration adjustment on off-grid backgrounds.",
        },
    )


if __name__ == "__main__":
    main()
