"""Freeze and infer a source-disjoint independent-noise confirmation panel."""

from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
EXP = ROOT.parent
OUT = Path("/mnt/external/demosaic") / ROOT.name
N = 32
SEED = 202611191807
PROFILE = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": 0.33}
KEYS = ("packed", "variance", "colors", "wb", "matrix")
PARENT_SHA = "87b96f3c487b9edaf1c477742b6c38f2a82cc6b20a94716d51cc8cf46a17a760"
V120_SHA = "a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb"

sys.path.insert(0, str(EXP / "scene-local-contrast-2400-v1"))
import prepare_eval


def scan(value, blocked):
    if isinstance(value, dict):
        for k, item in value.items():
            if k in ("id", "source_id", "commons_id") and isinstance(item, str) and len(item) == 40:
                blocked.add(item)
            if k in ("cache_sha256", "image_sha256") and isinstance(item, str) and len(item) == 64:
                blocked.add(item)
            if isinstance(item, (dict, list)):
                scan(item, blocked)
    elif isinstance(value, list):
        for item in value:
            scan(item, blocked)


def lines(bound):
    with checked(bound).open() as stream:
        yield from map(json.loads, stream)


def freeze():
    older = reference(EXP / "green-covariance-refit-v1/plan.json")
    inherited = read_json(checked(older))
    exclusions = [
        older,
        inherited["rejected_full427"],
        inherited["excluded_prior_wires"],
        reference(EXP / "scene-local-contrast-2400-v1/evaluation-plan.json"),
        reference(EXP / "local-band-mixture-v1/plan.json"),
        reference(EXP / "local-continuing-wire-v1/double-gap-inputs/panel.json"),
        reference("/mnt/external/demosaic/wire-regional-amplitude-v1/fresh/plan.json"),
        reference("/mnt/external/demosaic/wire-segment-support-v1/fresh/plan.json"),
    ]
    blocked = set()
    for ref in exclusions:
        scan(read_json(checked(ref)), blocked)
    for row in lines(inherited["training_manifest"]):
        scan(row, blocked)

    candidates = []
    for row in lines(inherited["source_pool"]):
        h, w = row["shape"][:2]
        if (
            row["split"] == "val"
            and row["bin_factor"] == 4
            and min(h, w) >= 512
            and h * w <= 2_200_000
            and row["cache_sha256"] not in blocked
            and row["id"] not in blocked
        ):
            candidates.append(row)
    candidates.sort(key=lambda r: hashlib.sha256(f"{SEED}/{r['id']}".encode()).digest())
    sources = []
    for row in candidates:
        if row["cache_sha256"] in blocked or row["id"] in blocked:
            continue
        blocked.update((row["cache_sha256"], row["id"]))
        i = len(sources)
        h, w = (2 * (n // 2) for n in row["shape"][:2])
        (box,) = scene_crop_boxes(
            (h, w), patch_size=256, count=1, seed=scene_seed(SEED, i, "query")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        camera |= {"pattern": tuple(PATTERNS)[i % 4], "black": 0.03}
        sources.append({"source": row, "index": i, "box": box, "camera": camera})
        if len(sources) == N:
            break
    assert N == len(sources)

    visited = 0
    source_ids = {s["source"]["id"] for s in sources}
    hashes = {s["source"]["cache_sha256"] for s in sources}
    visits = read_json(checked(inherited["parent_visit_audit"]))
    for trace in visits["source_traces"]:
        for update in lines(trace):
            for event in update["sources"]:
                if event["kind"] == "photographic":
                    visited += 1
                    assert (
                        event["source_id"] not in source_ids and event["cache_sha256"] not in hashes
                    )
    assert visited == inherited["verified_parent_visits"] == 559808
    models = {k: inherited["checkpoints"][m] for k, m in (("parent", "100k"), ("v120", "V120"))}
    assert (models["parent"]["sha256"], models["v120"]["sha256"]) == (PARENT_SHA, V120_SHA)
    path = OUT / "plan.json"
    write_json(
        path,
        {
            "driver": reference(__file__),
            "fixture": reference(prepare_eval.__file__),
            "training_manifest": inherited["training_manifest"],
            "source_pool": inherited["source_pool"],
            "source_exclusions": exclusions,
            "parent_trace": inherited["parent_visit_audit"],
            "parent_photo_visits_checked": visited,
            "seed": SEED,
            "checkpoints": models,
            "noise": PROFILE,
            "sources": sources,
            "contrast_preserved": 0.22,
        },
    )
    return path


@torch.inference_mode()
def infer(plan):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    plan_ref = reference(plan)
    d = read_json(checked(plan_ref))
    assert d["driver"] == reference(__file__) and d["fixture"] == reference(prepare_eval.__file__)
    prepare_eval.SEED = SEED
    models = {}
    for key, entry in d["checkpoints"].items():
        model, state = load_checkpoint(checked(entry), "cuda", tiled_inference=True)
        assert state["loaded_sha256"] == entry["sha256"] and "ema" in state
        del state
        model.set_noise(PROFILE["shot"], PROFILE["read"])
        models[key] = model.eval().to(memory_format=torch.channels_last)
    obs = OUT / "observations"
    obs.mkdir()
    start = time.monotonic()
    rows = []
    with ieee_fp32():
        for name in d["sources"]:
            local = prepare_eval.load_photo(name)
            present = prepare_eval.patch(local, name["box"], 0.22)
            absent = prepare_eval.patch(local, name["box"], 0)
            values = {
                "present": present,
                "masked-fine": absent,
                "flat": prepare_eval.flat_patch(absent),
            }
            dpt = prepare_eval.observed_group(local, values, name, PROFILE, "independent")
            key = f"fresh-{name['index']:02}"
            i = obs / f"{key}-input.npz"
            with i.open("xb") as stream:
                np.savez(stream, **dpt)
            b = [
                torch.from_numpy(dpt[k]).cuda().contiguous(memory_format=torch.channels_last)
                for k in KEYS[:2]
            ]
            b.extend(
                torch.from_numpy(dpt[k]).cuda()[None].expand(3, *dpt[k].shape) for k in KEYS[2:]
            )
            parent = {k: model(*b).cpu().numpy() for k, model in models.items()}
            assert all(
                v.shape == (3, 3, 256, 256) and v.dtype == np.float32 and np.isfinite(v).all()
                for v in parent.values()
            )
            j = obs / f"{key}-predictions.npz"
            with j.open("xb") as stream:
                np.savez(stream, **parent)
            rows.append(
                {
                    "id": key,
                    "source": name["source"],
                    "box": name["box"],
                    "profile": PROFILE,
                    "input": reference(i),
                    "rgb": reference(j),
                    "rgb_key": "parent",
                    "draw": "independent",
                    "partition": "fresh",
                    "layout": name["camera"]["pattern"],
                    "seeds": {
                        k: prepare_eval.sensor(name, PROFILE, k, "independent").noise_seed
                        for k in ("exterior", "present", "masked-fine", "flat")
                    },
                    "packed": fingerprint(dpt["packed"]),
                }
            )
            if len(rows) % 8 == 0:
                print(len(rows), round(time.monotonic() - start, 2), flush=True)
    assert len({s for r in rows for s in r["seeds"].values()}) == 4 * N
    write_json(
        OUT / "parents.json",
        {
            "plan": plan_ref,
            "policy": "CUDA IEEE FP32 EMA",
            "checkpoints": d["checkpoints"],
            "seconds": time.monotonic() - start,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    infer(freeze())
