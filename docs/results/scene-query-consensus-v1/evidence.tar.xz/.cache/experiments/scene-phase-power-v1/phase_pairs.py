"""Compare phase-invariant exterior power with real-axis Bayer patch priors."""

from functools import lru_cache

import numpy as np

from demosaic import scene_patch_covariance as patch

MODES = ("separate", "phase_pair", "transposed", "phase_pair_donor")
AXIS = 2


def limit_pair_amplitude(values):
    pairs = values.reshape(*values.shape[:-1], -1, AXIS)
    length = np.linalg.norm(pairs, axis=-1, keepdims=True)
    return (pairs / np.maximum(1, length / (10 * np.sqrt(2)))).reshape(values.shape)


@lru_cache(maxsize=16)
def phase_basis(colors, band):
    """Least-squares sine and cosine fits on the two actual green grids."""
    size = band.size
    green = np.flatnonzero(np.asarray(colors) == 1)
    if len(colors) != 4 or len(green) != 2:
        raise ValueError("Expected two physical Bayer greens")
    axis = np.arange(size) - (size - 1) / 2
    yy, xx = np.meshgrid(axis / size, axis / size, indexing="ij")
    limit = int(size * 0.224)
    frequencies = [
        (y, x)
        for y in range(limit + 1)
        for x in range(-limit, limit + 1)
        if (y > 0 or x > 0) and np.hypot(y, x) <= 0.224 * size
    ]
    active = np.array(
        [band.low * size <= np.hypot(y, x) <= band.high * size for y, x in frequencies]
    )
    phase = 2 * np.pi * np.einsum("ki,iyx->kyx", frequencies, np.stack((yy, xx)))
    waves = np.stack((np.cos(phase), np.sin(phase)), axis=1) * (np.sqrt(2) / size)
    neutral = np.stack(
        [np.full_like(xx, 1 / size), xx / np.linalg.norm(xx), yy / np.linalg.norm(yy)]
    )
    nuisance = np.concatenate((neutral, waves[~active].reshape(-1, size, size)))
    image = waves[active].reshape(-1, size, size)
    design = np.concatenate((nuisance, image))
    sampled = np.stack([design[:, g // 2 :: 2, g % 2 :: 2] for g in green])
    sampled = sampled.reshape(2, len(design), -1).transpose(0, 2, 1)
    if not np.all(np.linalg.cond(sampled) < 128):
        raise ValueError("Ill-conditioned Fourier fit on the green grid")
    projection = np.linalg.pinv(sampled)[:, len(nuisance) :]
    chosen = np.asarray(frequencies)[active]
    lookup = {tuple(k): i for i, k in enumerate(chosen)}
    transposed = [lookup[(x, y) if x >= 0 else (-x, -y)] for y, x in chosen]
    return patch.PatchBasis(green, projection, image, np.asarray(transposed)), chosen / size


def reencode(raw, colors, donor, shot, read):
    basis, _ = phase_basis(tuple(colors), donor.band)
    # Validity, descriptor, coordinates and rankings are identical to DCT.
    windows = patch.sample_windows(raw, donor.coords, donor.band.size)
    features, coeffs, noise, valid = patch.encode(windows, basis, shot, read)
    np.testing.assert_array_equal(features, donor.features)
    assert valid.all()
    values = limit_pair_amplitude(coeffs / (np.sqrt(2) * noise[:, None, None]))
    return patch.ExteriorPatches(donor.coords, features, values, donor.band)


def paired_query_support(innovation, coeffs, noise, cov):
    # Support the measured innovation's actual phase along each sine/cosine pair.
    amplitude = np.linalg.norm(innovation, axis=-1, keepdims=True)
    direction = np.divide(innovation, amplitude, out=np.zeros_like(innovation), where=amplitude > 0)
    signed = np.einsum("bki,bgki->bgk", direction, coeffs)
    var = np.einsum("bki,gkij,bkj->bgk", direction, cov, direction)
    sigma = noise[:, None, None] * np.sqrt(np.maximum(var, 1e-12))
    return np.clip((np.min(signed / sigma, axis=1) - 0.5) / 2, 0, 1)


def powers(donors, weights, base_noise):
    result = np.zeros((weights.shape[0], donors.shape[-1]))
    strength = np.minimum(weights.sum(axis=1, keepdims=True), 1)
    for start in (0, 1):
        discovery, held = slice(start, None, 2), slice(1 - start, None, 2)
        p, _, count_ok = patch.folded_weights(weights[:, discovery])
        estimate = np.maximum(np.einsum("bn,bnk->bk", p, donors[:, discovery]), 0)
        validate = patch.confirmed_power(donors[:, held], weights[:, held], base_noise)
        signal = np.minimum(validate, estimate) * count_ok * strength
        result += 0.5 * signal / (1 + signal)
    return result


def phase_fields(donors, weights, innovation, coeffs, noise, basis):
    zeros = np.zeros_like(innovation)
    if donors.shape[1] < 8:
        return dict.fromkeys(MODES, zeros)
    gram = basis.projection @ basis.projection.swapaxes(-1, -2)
    num = innovation.shape[-1] // AXIS
    indices = np.arange(num * AXIS).reshape(num, AXIS)
    local_cov = gram[:, indices[:, :, None], indices[:, None, :]]
    var = gram.diagonal(axis1=-1, axis2=-2)
    term = donors[:, :, 0] * donors[:, :, 1]
    gain_axis = powers(term, weights, np.prod(var, axis=0) / 4)
    axis_support = patch.signed_support(coeffs, innovation, noise[:, None, None] * np.sqrt(var))
    separate = innovation * gain_axis * axis_support

    # The mean cross-product of the pair is invariant to a simultaneous
    # rotation of each observed pair. Its flat noise variance is the
    # Frobenius inner product of the two phase covariance blocks / 16.
    cross_pair = term.reshape(*term.shape[:2], num, AXIS).mean(axis=-1)
    floor = np.sum(local_cov[0] * local_cov[1], axis=(-1, -2)) / 16
    gain_pair = powers(cross_pair, weights, floor)
    update = innovation.reshape(len(innovation), num, AXIS)
    paired_obs = coeffs.reshape(len(coeffs), 2, num, AXIS)
    support = paired_query_support(update, paired_obs, noise, local_cov)
    confirmed = update * support[..., None]
    return {
        "separate": separate,
        "phase_pair": (confirmed * gain_pair[..., None]).reshape(innovation.shape),
        "transposed": (confirmed * gain_pair[:, basis.transpose, None]).reshape(innovation.shape),
        "phase_pair_donor": (update * gain_pair[..., None]).reshape(innovation.shape),
    }


def corrections(raw, parent, colors, shot, read, box, atlas):
    shape = parent.shape
    result = {label: np.zeros_like(parent) for label in MODES}
    if atlas is None or not len(atlas.coords) or min(shape) < atlas.band.size:
        return result
    size = atlas.band.size
    basis, _ = phase_basis(tuple(colors), atlas.band)
    y, x = np.meshgrid(*(np.arange(0, n - size + 1, size // 2) for n in shape), indexing="ij")
    coords = np.column_stack((y.ravel(), x.ravel()))
    windows = patch.sample_windows(raw, coords, size)
    features, coefficients, noise, valid = patch.encode(windows, basis, shot, read)
    offsets = np.arange(size)
    ys = coords[:, 0, None, None] + offsets[:, None]
    xs = coords[:, 1, None, None] + offsets[None, :]
    current = parent[ys, xs]
    greens = np.stack([current[:, g // 2 :: 2, g % 2 :: 2] for g in basis.green], axis=1)
    projected = np.einsum("gkf,ngf->ngk", basis.projection, greens.reshape(len(coords), 2, -1))
    innovation = (coefficients - projected).mean(axis=1) * valid[:, None]
    donor, weights = patch.choose_exterior(
        features, coords + np.asarray(box)[[1, 0]], atlas, ranked=True
    )
    values = phase_fields(donor, weights, innovation, coefficients, noise, basis)
    taper = np.sin((offsets + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, current.shape))
    for key, value in values.items():
        field = np.einsum("nk,kyx->nyx", value, basis.image)
        np.add.at(result[key], (ys, xs), field * window)
        result[key] /= np.maximum(1, norm)
    return result
