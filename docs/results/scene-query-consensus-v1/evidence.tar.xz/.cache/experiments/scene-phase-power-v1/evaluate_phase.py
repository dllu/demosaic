"""Evaluate phase-paired donor checks at equal flat error on retained fixtures."""

from pathlib import Path
import sys

import numpy as np
from scipy.optimize import brentq

from phase_pairs import MODES, corrections, reencode

ROOT = Path(__file__).resolve().parent
ATLAS = ROOT.with_name("scene-dense-atlas-v1")
sys.path.insert(0, str(ATLAS))
from measure_atlas import BAND, DENSE, TIGHT, patch, replay, run
from evaluate_wide import FLAT, RESPONSE, WireFundamental, values

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

MODES = ("dense", *MODES)
BUDGETS = (TIGHT, 4800)
QUIET = 0.10


def field_updates(case, data, base, budget, *, include_dense=False):
    profile = case["profile"]
    shot, read = profile["shot"], profile["read"]
    scene, colors, query = (data["scene_packed"], data["colors"], case["box"])
    limit = budget
    if budget == TIGHT:
        uniform = patch.build_exterior(
            scene, colors, query, shot, read, band=BAND, max_windows=budget
        )
        if uniform is not None:
            limit = max(1, len(uniform.coords))
    dense = patch.build_exterior(
        scene, colors, query, shot, read, band=BAND, max_windows=limit, dense_radius=DENSE
    )
    phase = reencode(scene, colors, dense, shot, read) if dense is not None else None
    output = {}
    for raw, parent in zip(data["packed"], base, strict=True):
        terms = corrections(raw, parent[1], colors, shot, read, query, phase)
        if include_dense:
            terms["dense"] = patch.corrections(
                raw, parent[1], colors, shot, read, query, dense, validate_donors=True
            )["donor_and_query"]
        for key, delta in terms.items():
            unit = replay.apply_delta(np.zeros_like(parent), delta, data["wb"], data["matrix"], 1)
            output.setdefault(key, []).append(unit)
    return {k: np.stack(ds) for k, ds in output.items()}, 0 if dense is None else len(dense.coords)


def wire(original):
    case = original["case"]
    data, base, _ = replay.read_inputs(case)
    with np.load(checked(case["input"]), allow_pickle=False) as f:
        exact = {name: f[name] for name in ("target", "support")}
    metric = WireFundamental(data | exact, case["fixture"]["geometry"])
    anchor = base.astype(np.float64)
    origin = metric(anchor)
    groups = {}
    for budget in BUDGETS:
        control = original["width"][str(budget)]
        ds, count = field_updates(case, data, base, budget)
        assert count == control["windows"]["dense"]
        for name, v in origin.items():
            np.testing.assert_allclose(v, control["origin"][name], atol=1e-10, rtol=0)
        moments = {"dense": control["terms"]["dense"]}
        for key, delta in ds.items():
            plus, minus = metric(anchor + delta), metric(anchor - delta)
            moments[key] = {}
            for name, target in origin.items():
                p, m = plus[name], minus[name]
                moments[key][name] = (
                    [target, (p - m) / 2]
                    if name in RESPONSE
                    else [target**2, (p**2 - m**2) / 2, (p**2 + m**2) / 2 - target**2]
                )
        groups[str(budget)] = {**control, "terms": moments}
    return {"case": case, "width": groups}


def calibrate(rows):
    strength = {}
    for budget in BUDGETS:
        key = str(budget)
        group = [r["width"][key] for r in rows]
        original = values(group, "origin", FLAT, 0)
        choices = {}
        for name in MODES:

            def excess(gain):
                return float(np.mean(values(group, name, FLAT, gain) - original))

            gain = brentq(lambda g: excess(g) - QUIET, 0, 0.8) if excess(0.8) > QUIET else 0.8
            choices[name] = {"gain": gain, "flat_DN16": excess(gain)}
        strength[key] = choices
    return strength


def summary(rows, strengths):
    rng = np.random.default_rng(202611191928)
    output = {}
    for key, configs in strengths.items():
        group = [r["width"][key] for r in rows]
        chosen = {"origin": 0, "v120": 0, **{k: d["gain"] for k, d in configs.items()}}
        scores = {}
        for metric in sorted({m for r in group for m in r["origin"]}):
            used = [r for r in group if metric in r["origin"]]
            n = len(used)
            idx = np.vstack((np.arange(n), rng.integers(0, n, size=(8000, n))))
            means = {
                mode: values(used, mode, metric, strength)[idx].mean(axis=1)
                for mode, strength in chosen.items()
            }
            scores[metric] = {}
            for mode, v in means.items():
                info = {"value": float(v[0])}
                for reference_ in ("origin", "dense", "separate", "phase_pair"):
                    d = v - means[reference_]
                    info[reference_] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
                scores[metric][mode] = info
        output[key] = scores
    return output


def natural(original):
    case = original["case"]
    data, base, _ = replay.read_inputs(case)
    ds, count = field_updates(case, data, base, 4800)
    assert count == original["windows"]["dense"]
    with np.load(checked(case["input"]), allow_pickle=False) as f:
        gt = replay.transform(f["target"], data)
    parent = replay.transform(base, data)
    terms = {k: original["terms"][k] for k in ("parent", "v120", "dense")}
    for key, delta in ds.items():
        change = replay.transform(delta, data)
        terms[key] = {mode: replay.terms(p, change[mode], gt[mode]) for mode, p in parent.items()}
    return {**original, "terms": terms}


def summarize_natural(rows, strengths):
    rnd = np.random.default_rng(202611191941)
    idx = np.vstack((np.arange(len(rows)), rnd.integers(0, len(rows), (8000, len(rows)))))
    choice = {"parent": 0, "v120": 0, **{k: v["gain"] for k, v in strengths.items()}}
    output = {}
    for band in ("fine", "lower"):
        output[band] = {}
        for metric in ("present", "increment", "flat", "response"):
            means = {
                k: replay.estimate(replay.arrays(rows, k, band, metric), metric, g, idx)
                for k, g in choice.items()
            }
            output[band][metric] = {}
            for k, points in means.items():
                info = {"value": float(points[0])}
                for ref in ("parent", "dense", "separate"):
                    d = points - means[ref]
                    info[ref] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
                output[band][metric][k] = info
    return output


def main():
    previous = reference(ATLAS / "results.json")
    older = read_json(checked(previous))
    locked = read_json(checked(older["lock"]))
    cal, elapsed = run(locked["calibration"], wire)
    strengths = calibrate(cal)
    for b in BUDGETS:
        np.testing.assert_allclose(
            strengths[str(b)]["dense"]["gain"],
            locked["strengths"][str(b)]["dense"]["gain"],
            rtol=0,
            atol=1e-10,
        )
    setting = ROOT / "calibration.json"
    write_json(
        setting,
        {
            "driver": reference(__file__),
            "operator": reference(ROOT / "phase_pairs.py"),
            "older": older["lock"],
            "prior_results": previous,
            "calibration": cal,
            "strengths": strengths,
            "elapsed_seconds": elapsed,
        },
    )
    print("locked", strengths, flush=True)
    long, l_elapsed = run(older["long"], wire)
    short, s_elapsed = run(older["short"], wire)
    photos, n_elapsed = run(older["natural"], natural)
    write_json(
        ROOT / "results.json",
        {
            "driver": reference(__file__),
            "settings": reference(setting),
            "prior": previous,
            "long": long,
            "short": short,
            "natural": photos,
            "summary": {
                "long": summary(long, strengths),
                "short": summary(short, strengths),
                "natural": summarize_natural(photos, strengths["4800"]),
            },
            "elapsed_seconds": {"long": l_elapsed, "short": s_elapsed, "natural": n_elapsed},
        },
    )
    print("finished", l_elapsed, s_elapsed, n_elapsed, flush=True)


if __name__ == "__main__":
    main()
