"""Render the measured response and false-detail frontier at native scale."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.cfa import malvar, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
from probe import CFAS, CHECK, POLICIES, ROOT, SIZE, THRESHOLDS, case

COLORS = {"pixel": "#943b39", "row-pairs": "#197288", "row-pairs-covariance": "#5f5195"}
LABELS = {
    "pixel": "Pixel split", "row-pairs": "Readout-row split",
    "row-pairs-covariance": "Row split + covariance",
}
DISPLAY = 16.


def frontier(summary):
    figure, axes = plt.subplots(2, 3, sharey="row", figsize=(10.8, 6.2), layout="constrained")
    for index, (name, values) in enumerate(summary["summary"].items()):
        for i, (role, description) in enumerate((
            ("row-parallel-pair", "Horizontal weak wave"),
            ("oblique-pair", "Oblique weak wave"),
        )):
            ax = axes[i, index]
            for method in POLICIES:
                line = [values[method][f"z>{n:g}"] for n in THRESHOLDS]
                false_detail = [r["flat"]["correction_RMS_DN16"]["mean"] for r in line]
                recovery = [r[role]["weak_projection"]["mean"]*100 for r in line]
                ax.plot(false_detail,recovery,color=COLORS[method], linewidth=1.5,
                        marker="o", markersize=3, label=LABELS[method])
                ix = THRESHOLDS.index(2)
                ax.scatter(false_detail[ix], recovery[ix], color=COLORS[method],s=34, zorder=3)
            ax.grid(alpha=.2)
            if i == 0:
                ax.set_title(f"{float(name):.0%} of read variance shared by row", fontsize=10)
            if index == 0:
                ax.set_ylabel(description + " response (%)")
            if i == 1:
                ax.set_xlabel("False fine detail on flat (DN16)")
    axes[0,0].legend(loc="best",fontsize=8,frameon=False)
    figure.suptitle("Weak-wave recovery versus false detail under shared readout noise")
    refs = []
    for name in ("frontier.png", "frontier.svg", "frontier.pdf"):
        path = ROOT / "native" / name
        figure.savefig(path,dpi=180)
        refs.append(reference(path))
    plt.close(figure)
    return refs


def display(pixels, *, pattern=None):
    value = torch.tensor(pixels, dtype=torch.float32)
    neutral = torch.ones((1,3))
    if pattern is not None:
        colors = torch.tensor(CFAS[pattern]).reshape(-1)
        value = malvar(value[None], colors, neutral)
    else:
        value = value[None]
    crop = display_crop(value, neutral, torch.eye(3)[None], [0,0,SIZE,SIZE], exposure=DISPLAY)
    assert crop.shape == (SIZE,SIZE,3)
    return np.rint(np.clip(crop,0,1)*255).astype(np.uint8)


def save_plot(selected, declaration, name):
    meta = selected
    f, pattern = meta["fraction"], meta["phase"]
    outputs, raw, pattern_table, target, arrays = case(declaration, meta["kind"], meta["repeat"], f)
    assert outputs["pixel"]["minimum_z"] == meta["policies"]["pixel"]["minimum_z"]
    pack = lambda src: np.stack([src[y::2,x::2] for y in range(2) for x in range(2)])
    values = [display(pack(raw),pattern=pattern)]
    for arm in POLICIES:
        pair = "pixel" if arm == "pixel" else "row-pairs"
        coarse, detail = arrays[pair]
        applied = outputs[arm]["minimum_z"] > 2
        values.append(display(pack(coarse + detail * applied),pattern=pattern))
    values.append(display(target))
    names = ["Noisy Malvar", "Pixel split fit", "Row split fit", "Row covariance fit", "Exact GT"]
    paths = {}
    panel_records = {}
    for tag, columns in (("comparison", range(5)), ("triplet", (0,3,4))):
        image = Image.new("RGB", (8 + 168*len(columns),192), "#eeeeee")
        draw=ImageDraw.Draw(image)
        records=[]
        for index, column in enumerate(columns):
            x=8 + 168*index
            draw.text((x,5),names[column],fill="black")
            image.paste(Image.fromarray(values[column]),(x,24))
            records.append({"label":names[column],"png_xywh":[x,24,SIZE,SIZE]})
        path = ROOT / "native" / f"{name}-{tag}.png"
        image.save(path)
        data=np.asarray(Image.open(path))
        for entry,k in zip(records,columns,strict=True):
            x,y,w,h=entry["png_xywh"]
            np.testing.assert_array_equal(data[y:y+h,x:x+w],values[k])
        paths[tag]=reference(path)
        panel_records[tag]=records
    return {
        "name":name, "source":declaration, "kind":meta["kind"], "repeat":meta["repeat"],
        "fraction":f, "noise":{"shot":.00128,"read":6.5536e-6,"ADC_bits":16,"black":.03},
        "ROI_xywh":[0,0,SIZE,SIZE],"display_exposure":DISPLAY,
        "policies":meta["policies"], "input":meta["raw"], "views":paths,"panels":panel_records,
    }


def render():
    torch.set_num_threads(1)
    source = ROOT / "summary.json"
    summary = read_json(source)
    plan = read_json(checked(summary["plan"]))
    raw = [row for item in summary["members"] for row in read_json(checked(item))["rows"]]
    rng = {row["source_seed"]:row for row in plan["seeds"]}
    (ROOT/"native").mkdir()
    pts = frontier(summary)
    candidates = [r for r in raw if r["cohort"]=="test" and r["fraction"]==1.]
    def accepted(r, label):
        return r["policies"][label]["minimum_z"]>2
    def quiet_reduction(r):
        score=lambda a: r["policies"][a]["delivered_candidate_RMS_DN16"]*accepted(r,a)
        return score("pixel")-score("row-pairs-covariance")
    flat = max((r for r in candidates if r["kind"]=="flat"),key=quiet_reduction)
    incorrect = max((r for r in candidates if r["kind"]=="offgrid-edge"),key=quiet_reduction)
    def weak_gain(r, label):
        return r["policies"][label]["weak_projection"]*accepted(r,label)
    helpful=max((r for r in candidates if r["kind"]=="oblique-pair"),
                key=lambda r: weak_gain(r,"row-pairs-covariance")-weak_gain(r,"pixel"))
    tradeoff=max((r for r in candidates if r["kind"]=="row-parallel-pair"),
                 key=lambda r:weak_gain(r,"pixel")-weak_gain(r,"row-pairs-covariance"))
    samples = [
        ("flat-largest-removed",flat),("edge-largest-removed",incorrect),
        ("oblique-largest-gain",helpful),("horizontal-largest-loss",tradeoff),
    ]
    views = [save_plot(row,rng[row["seed"]],name) for name,row in samples]
    write_json(ROOT/"native"/"rendered.json", {
        "collector":reference(source), "renderer":reference(__file__), "frontier":pts, "views":views,
        "selection":"At fraction 1 and threshold 2, show largest removed false correction on flat and edge, greatest oblique weak response gain, and greatest horizontal weak response loss. Display analytical fitted mosaic through Malvar, camera transform and sRGB. No resized crop cells.",
    })


if __name__ == "__main__":
    render()
