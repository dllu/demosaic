"""Verify the ADC and readout covariance independently of candidate fitting."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import read_json, reference, write_json
from probe import BLACK, CHECK, FRACTIONS, READ, ROOT, SHOT, SIZE, case, fields, sample


def measure_covariance():
    report = {}
    levels = 65535
    target = np.zeros((SIZE,SIZE))
    for fraction in FRACTIONS:
        products = []
        averages, mean_squared, censored, rounding_error = [], [], 0, 0.
        for seed in range(509121,509281):
            frame = sample(target,seed,fraction)
            recovered_codes = levels*(frame*(1-BLACK)+BLACK)
            rounding_error = max(rounding_error,float(np.max(abs(recovered_codes-np.rint(recovered_codes)))))
            averages.append(frame.mean())
            mean_squared.append(np.mean(frame**2))
            censored += int(np.count_nonzero((recovered_codes < .5) | (recovered_codes > levels-.5)))
            products.append([np.mean(frame[:,::2]*frame[:,1::2]),np.mean(frame[::2,:]*frame[1::2,:])])
        covariance = np.mean(products,axis=0)
        expected = np.array([READ*fraction,0.])
        np.testing.assert_allclose(covariance,expected,atol=.03*READ,rtol=0.)
        np.testing.assert_allclose(np.mean(mean_squared),READ,atol=.03*READ,rtol=0.)
        assert abs(np.mean(averages)) < 3e-5 and not censored and rounding_error < 1e-10
        report[str(fraction)] = {
            "variance_over_configured_read": float(np.mean(mean_squared)/READ),
            "covariance_over_configured_read_same_row":float(covariance[0]/READ),
            "covariance_over_configured_read_next_row":float(covariance[1]/READ),
            "mean":float(np.mean(averages)), "ADC_max_float_roundtrip_error_in_codes":rounding_error,
            "censored_count":censored,
        }
    return report


def check_axis():
    plan = read_json(CHECK)
    correlations = []
    for declaration in plan["seeds"]:
        for kind in ("oblique-pair","row-parallel-pair","row-parallel-pair-edge"):
            p,s,w,c=fields(kind,declaration["phase"],declaration["source_seed"])
            iy,ix=np.indices((SIZE,SIZE))
            s,w=(v[c,iy,ix] for v in (s,w))
            correlations.append(abs(np.sum(s*w)/np.linalg.norm(s)/np.linalg.norm(w)))
    assert max(correlations) < 1e-14
    return max(correlations)


if __name__ == "__main__":
    write_json(ROOT/"sensor-check.json", {"plan":reference(CHECK),"driver":reference(__file__),
                 "marginal_ADC_read_statistics":measure_covariance(),
                 "max_true_directions_absolute_cosine_on_CFA": check_axis(),
                 "scope":"160 independent exact-dark frames per fraction. Noise and ADC are checked separately from the fitted images."})
