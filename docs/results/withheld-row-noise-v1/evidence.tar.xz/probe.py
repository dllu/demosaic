"""Stress native CFA validation with shared readout-row noise."""

import argparse
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import fit_candidate, stratified_split, validate_candidate
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CHECK = ROOT / "plan.json"
SIZE = 160
SHOT, READ = 0.00128, 6.5536e-6
BLACK = 0.03
FRACTIONS = (0.0, 0.5, 1.0)
KINDS = ("flat", "offgrid-edge", "oblique-pair", "row-parallel-pair", "row-parallel-pair-edge")
POLICIES = ("pixel", "row-pairs", "row-pairs-covariance")
CFAS = {
    "RGGB": ((0, 1), (1, 2)),
    "BGGR": ((2, 1), (1, 0)),
    "GRBG": ((1, 0), (2, 1)),
    "GBRG": ((1, 2), (0, 1)),
}
Y, X = np.indices((SIZE, SIZE))
THRESHOLDS = (0, 1, 2, 3, 4, 6, 8)


def freeze():
    design = []
    for cohort, count, base in (("calibration", 24, 8054831254), ("test", 48, 8054931254)):
        for pattern_index, pattern in enumerate(CFAS):
            for index in range(count // len(CFAS)):
                source = base + pattern_index * 2300 + index * 11
                design.append({
                    "cohort": cohort, "phase": pattern, "source_seed": source,
                    "partition_seed": source + 59831,
                    "noise_seeds": [source * 47 + 9101, source * 47 + 17291],
                })
    write_json(CHECK, {
        "source": reference(__file__),
        "implementation": reference(REPO / "src/demosaic/experiments/evaluation/withheld.py"),
        "conditions": KINDS, "read_fractions": FRACTIONS, "policies": POLICIES,
        "seeds": design, "noise": {"shot": SHOT, "read": READ, "black": BLACK, "ADC_bits": 16},
        "thresholds": THRESHOLDS,
        "calibrated_policy": "For every read fraction and model, take the empirical higher 95th percentile on pooled calibration flat and off-grid edge roles. Apply strict greater-than on independent test scenes. Also report the shared fixed threshold 2.",
        "covariance_policy": "Public simulation row fraction determines scores in the covariance-weighted comparison. It is not fitted from either side of the test crop.",
        "scope": "Known-input sensor stress. Part of the fixed marginal read variance is shared by all pixels in a physical row. Unrelated readout rows have independent Gaussian offsets. Two independent noisy draws per exact source family, source-level registration across conditioning laws and policies. No RAW decode, NN, training or actual sensor-calibration claim.",
    })


def color_labels(pattern):
    return np.array(CFAS[pattern])[Y % 2, X % 2]


def fields(kind, pattern, seed):
    rng = np.random.default_rng(seed)
    colors = color_labels(pattern)
    tint = np.array([.80, 1., .68])
    base = np.full((3, SIZE, SIZE), rng.uniform(.016, .027)) * tint[:,None,None]
    base += rng.uniform(-.002, .002, (3,1,1)) * (X - 79.5) / 80
    base += rng.uniform(-.002, .002, (3,1,1)) * (Y - 79.5) / 80
    if "edge" in kind:
        theta = rng.choice(np.arange(1, 12)) * np.pi / 12 + .032
        u, v = np.cos(theta), np.sin(theta)
        offset = rng.choice(np.linspace(-.23, .23, 5)) + .019
        step = ((X - 79.5) * u + (Y - 79.5) * v) / 80 > offset
        base += rng.uniform(.024, .044) * tint[:,None,None] * step
    strong = np.zeros_like(base)
    weak = np.zeros_like(base)
    if "pair" in kind:
        phases = rng.uniform(0, 2*np.pi, size=2)
        strong += rng.uniform(.00115, .00165) * tint[:,None,None] * np.cos(
            2*np.pi * (7 * X + 4 * Y) / SIZE + phases[0]
        )
        frequency = -5 if kind == "oblique-pair" else 0
        weak += rng.uniform(.00056, .00085) * tint[:,None,None] * np.cos(
            2*np.pi * (frequency * X + 9 * Y) / SIZE + phases[1]
        )
    return base, strong, weak, colors


def sample(target, seed, fraction):
    poisson_rng, white_rng, row_rng = (
        np.random.default_rng(np.random.SeedSequence([seed, stream])) for stream in range(3)
    )
    poisson = poisson_rng.poisson(target / SHOT) * SHOT
    white = white_rng.normal(size=target.shape) * np.sqrt(READ * (1 - fraction))
    row = row_rng.normal(size=(SIZE, 1)) * np.sqrt(READ * fraction)
    levels = 65535
    pre = BLACK + (poisson + white + row) * (1 - BLACK)
    assert np.isfinite(pre).all()
    codes = np.rint(np.clip(pre, 0, 1) * levels)
    return (codes / levels - BLACK) / (1 - BLACK)


def split_rows(seed):
    rng = np.random.default_rng(seed)
    selected = rng.permutation(SIZE // 2)[:SIZE // 4]
    rows = np.zeros(SIZE // 2, dtype=bool)
    rows[selected] = True
    return np.repeat(rows, 2)[:, None] & np.ones((1, SIZE), dtype=bool)


def covariance_score(candidate, raw, held, fraction):
    old = validate_candidate(candidate, raw, held)
    effect = (candidate.prediction - candidate.background)[held]
    variance = candidate.noise_variance[held]
    weight = effect / variance
    numbered_rows = Y[held]
    row_sums = np.bincount(numbered_rows, weights=weight, minlength=SIZE)
    row_variance = READ * fraction
    result = 4 * (float(np.sum((variance - row_variance) * weight**2))
                  + row_variance * float(row_sums @ row_sums))
    norm = np.sqrt(result)
    return old | {
        "noise_sd_with_covariance": float(norm),
        "validation_z": old["weighted_SSE_improvement"] / norm if norm else 0.0,
    }


def fit(raw, colors, selected, kind, fraction=None, *, proof=False):
    steps = "edge" in kind
    models, scores = [], []
    for discover in (selected, ~selected):
        setting = {"shot": SHOT, "read": READ,
                   "nuisance": "step" if steps else "affine", "edge_refinements": 2 if steps else 0}
        candidate = fit_candidate(raw, colors, discover, **setting)
        if proof:
            hidden = raw.copy()
            hidden[~discover] = np.nan
            masked = fit_candidate(hidden, colors, discover, **setting)
            assert candidate.frequencies_xy == masked.frequencies_xy
            assert candidate.edge_geometry == masked.edge_geometry
            for name in ("prediction", "background", "noise_variance"):
                np.testing.assert_array_equal(getattr(candidate, name), getattr(masked, name))
        models.append(candidate)
        scores.append(validate_candidate(candidate, raw, ~discover))
    result = {"independent_z": [score["validation_z"] for score in scores]}
    if fraction is not None:
        covariance = [covariance_score(m, raw, ~m.discovery_mask, fraction) for m in models]
        result["covariance_z"] = [score["validation_z"] for score in covariance]
    result["freqs"] = [candidate.frequencies_xy for candidate in models]
    coarse = np.mean([m.background for m in models], axis=0)
    detail = np.mean([m.prediction - m.background for m in models], axis=0)
    return result, coarse, detail


def measure(detail, weak, strong):
    gain = lambda wave: float(np.sum(detail * wave) / np.sum(wave**2)) if np.any(wave) else None
    return {
        "weak_projection": gain(weak), "strong_projection": gain(strong),
        "delivered_candidate_RMS_DN16": float(65535 * np.sqrt(np.mean(detail**2))),
        "increment_RMS_if_delivered_DN16": float(65535 * np.sqrt(np.mean((detail - weak - strong)**2))),
        "increment_RMS_if_suppressed_DN16": float(65535 * np.sqrt(np.mean((weak + strong)**2))),
    }


def case(declaration, kind, repeat, fraction, proof=False):
    seed, pattern = declaration["source_seed"], declaration["phase"]
    base_rgb, strong_rgb, weak_rgb, colors = fields(kind, pattern, seed)
    base, strong, weak = (arr[colors, Y, X] for arr in (base_rgb, strong_rgb, weak_rgb))
    raw = sample(base + strong + weak, declaration["noise_seeds"][repeat], fraction)
    seed = declaration["partition_seed"]
    pixel, rows = stratified_split(raw.shape, seed), split_rows(seed)
    assert not np.any(np.any(rows, axis=1) & np.any(~rows, axis=1))
    for u in (pixel, rows):
        for y in range(2):
            for x in range(2):
                assert u[y::2,x::2].sum() == SIZE**2 // 8
    outputs, arrays = {}, {}
    for tag, mask in (("pixel", pixel), ("row-pairs",rows)):
        result, coarse, detail = fit(raw, colors, mask, kind,
                                     fraction if tag=="row-pairs" else None, proof=proof)
        metrics = measure(detail, weak, strong)
        outputs[tag] = {"minimum_z": min(result["independent_z"]), **result, **metrics}
        if tag == "row-pairs":
            outputs["row-pairs-covariance"] = {**result, "minimum_z": min(result["covariance_z"]), **metrics}
            if fraction == 0:
                np.testing.assert_allclose(result["independent_z"], result["covariance_z"], rtol=1e-14, atol=1e-14)
        arrays[tag] = coarse, detail
    return outputs, raw, colors, base_rgb + strong_rgb + weak_rgb, arrays


def verify():
    plan = read_json(CHECK)
    maximum = 0.0
    # Direct positive-definite covariance check with repeated and separated
    # readout rows, independent of the grouped implementation above.
    for pattern in CFAS:
        row = next(r for r in plan["seeds"] if r["phase"]==pattern)
        outputs, raw, colors, _, _ = case(row, "row-parallel-pair-edge", 0, .5, proof=True)
        mask = split_rows(row["partition_seed"])
        test = np.flatnonzero(~mask.ravel())[:295]
        use = np.zeros(raw.size, dtype=bool)
        use[test]=True
        use=use.reshape(raw.shape)
        cand = fit_candidate(raw, colors, mask, shot=SHOT, read=READ, nuisance="step", edge_refinements=2)
        variance = cand.noise_variance[use]
        vector = (cand.prediction - cand.background)[use]/variance
        group = Y[use]
        covariance = np.diag(variance - READ*.5) + READ*.5*(group[:,None] == group[None,:])
        exact = 2*np.sqrt(vector@covariance@vector)
        grouped = covariance_score(cand, raw, use, .5)["noise_sd_with_covariance"]
        np.testing.assert_allclose(exact,grouped,rtol=1e-13,atol=1e-13)
        maximum=max(maximum,abs(exact-grouped))
    write_json(ROOT/"verification.json",{"plan":reference(CHECK),"layout_checks":list(CFAS),
       "substituting_NaNs_on_held_sites_preserves_every_candidate":True,
       "max_dense_vs_grouped_covariance_sd_error":maximum, "equal_Bayer_phase_sample_counts":True,
       "complete_disjoint_native_readout_rows":True})


def collect(shard):
    plan = read_json(CHECK)
    assert checked(plan["source"]) == Path(__file__) and plan["conditions"] == list(KINDS)
    checked(plan["implementation"])
    rows = []
    for source, definition in enumerate(plan["seeds"][shard::2]):
        for kind in KINDS:
            for repeat in range(2):
                for fraction in FRACTIONS:
                    values, raw, _, _, _ = case(definition, kind, repeat, fraction)
                    rows.append({"seed":definition["source_seed"], "cohort":definition["cohort"],
                                 "phase":definition["phase"],"kind":kind,"repeat":repeat,"fraction":fraction,
                                 "raw":fingerprint(raw),"policies":values})
        if source % 4 == 0:
            print(shard, source, len(rows), flush=True)
    write_json(ROOT/f"shard-{shard}.json", {"plan":reference(CHECK), "rows":rows})


def aggregate():
    plan = read_json(CHECK)
    shards = [read_json(ROOT/f"shard-{i}.json") for i in range(2)]
    assert all(s["plan"]==reference(CHECK) for s in shards)
    all_rows = [row for shard in shards for row in shard["rows"]]
    assert len(all_rows)==72*len(KINDS)*len(FRACTIONS)*2
    assert len({(r["seed"],r["kind"],r["repeat"],r["fraction"]) for r in all_rows})==len(all_rows)
    rng = np.random.default_rng(1051)
    summary, thresholds = {}, {}
    for fraction in FRACTIONS:
        training = [r for r in all_rows if r["cohort"]=="calibration" and r["fraction"]==fraction and "pair" not in r["kind"]]
        test = [r for r in all_rows if r["cohort"]=="test" and r["fraction"]==fraction]
        assert len(training)==96 and len(test)==480
        threshold = {
            name: float(np.quantile([r["policies"][name]["minimum_z"] for r in training], .95, method="higher"))
            for name in POLICIES
        }
        thresholds[str(fraction)] = threshold
        per_fraction = {}
        for name in POLICIES:
            table = {}
            setting = [(f"z>{value:g}",value) for value in THRESHOLDS]
            setting.append(("calibration-95", threshold[name]))
            for label, cutoff in setting:
                out = {}
                for kind in KINDS:
                    sites = defaultdict(list)
                    for row in test:
                        if row["kind"] != kind:
                            continue
                        metrics = row["policies"][name]
                        accepted = metrics["minimum_z"] > cutoff
                        sites[row["seed"]].append([
                            float(accepted),
                            (metrics["weak_projection"] or 0.) * accepted,
                            metrics["delivered_candidate_RMS_DN16"] * accepted,
                            metrics["increment_RMS_if_delivered_DN16" if accepted else "increment_RMS_if_suppressed_DN16"],
                        ])
                    cases = np.asarray([np.mean(sites[seed],axis=0) for seed in sorted(sites)])
                    assert cases.shape == (48, 4)
                    draws = rng.integers(len(cases),size=(5000,len(cases)))
                    keys = ("acceptance_rate","weak_projection","correction_RMS_DN16","increment_RMS_DN16")
                    means = cases.mean(0)
                    intervals = np.quantile(cases[draws].mean(1),[.025,.975],axis=0).T
                    out[kind] = {key:{"mean":float(value),"interval_95":interval.tolist()}
                                 for key,value,interval in zip(keys,means,intervals,strict=True)}
                table[label]=out
            per_fraction[name]=table
        summary[str(fraction)]=per_fraction
    write_json(ROOT/"summary.json", {"plan":reference(CHECK), "observations":len(all_rows),
               "members":[reference(ROOT/f"shard-{i}.json") for i in range(2)],
               "verification":reference(ROOT/"verification.json"),
               "thresholds_at_empirical_calibration_95th_percentile":thresholds,"summary":summary,
               "interval_unit":"photo scene seed; both noise repeats resampled together"})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "verify", "collect", "summarize"))
    parser.add_argument("--shard", type=int, choices=(0,1))
    args = parser.parse_args()
    if args.action=="plan":
        freeze()
    elif args.action=="verify":
        verify()
    elif args.action=="collect":
        collect(args.shard)
    else:
        aggregate()
