"""Create native views of distant-row recovery and biased reference failures."""

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from reference_rows import ARMS, PANEL, ROOT, SIZE, X, Y, exterior_strips, fields, fit, physical_rows, sample, split_rows
from render_v2 import display

EXP = 16.
VIEWS = [
    ("smooth-horizontal", "smooth", "row-parallel-pair", "largest horizontal gain"),
    ("smooth-edge", "smooth", "row-parallel-pair-edge", "largest error reduction"),
    ("striped-null", "all-striped-strips", "flat", "largest median-only false correction"),
    ("striped-residual", "all-striped-strips", "flat", "largest protected false correction"),
]


def select(rows, exterior, kind, rule):
    def accepted(row,label):
        return row["arms"][label]["accepted"]
    def gain(item, role):
        details=item["arms"].get(role) or item["controls"][role]
        deliver=details["minimum_z"]>2
        return deliver*details["weak_projection"]
    def error(item, role):
        details=item["arms"].get(role) or item["controls"][role]
        name="increment_RMS_if_delivered_DN16" if details["minimum_z"]>2 else "increment_RMS_if_suppressed_DN16"
        return details[name]
    def false_rms(row,label):
        return row["arms"][label]["delivered_candidate_RMS_DN16"]*accepted(row,label)
    search={
        "largest horizontal gain":lambda row:gain(row,"protected-reference")-gain(row,"row-pairs"),
        "largest error reduction":lambda row:error(row,"row-pairs")-error(row,"protected-reference"),
        "largest median-only false correction":lambda row:false_rms(row,"median-reference") if not accepted(row,"protected-reference") else -np.inf,
        "largest protected false correction":lambda row:false_rms(row,"protected-reference"),
    }
    possible=[row for row in rows if (row["exterior"],row["kind"],row["fraction"])==(exterior,kind,1.)]
    selected=max(possible,key=search[rule])
    return selected,float(search[rule](selected))


def image(selected, definition, key):
    kind, fraction, pattern = (selected[k] for k in ("kind","fraction","pattern"))
    base, strong, weak, cfa=fields(kind,pattern,selected["source"])
    target=base+strong+weak
    noise_seed=definition["noise_seeds"][selected["repeat"]]
    raw=sample(target[cfa,Y,X],noise_seed,fraction)
    assert fingerprint(raw)==selected["observed_query"]
    latent=physical_rows(noise_seed,fraction)
    median, screened, trace=exterior_strips(definition,selected["repeat"],fraction,selected["exterior"],latent)
    assert trace==selected["diagnostics"]
    pack=lambda v: np.stack([v[y::2,x::2]for y in range(2)for x in range(2)])
    variants={
        "row-pairs":np.zeros_like(latent),
        "median-reference":median, "protected-reference":screened,
        "true-offset-oracle":latent,
    }
    stash = [display(pack(raw),pattern=pattern)]
    for arm, correction in variants.items():
        score, coarse, detail=fit(raw-correction[:,None],cfa,split_rows(definition["partition_seed"]),kind)
        expected=(selected["arms"]|selected["controls"])[arm]
        assert min(score["independent_z"])==expected["minimum_z"]
        stash.append(display(pack(coarse+detail*(expected["minimum_z"]>2)),pattern=pattern))
    stash.append(display(target))
    records={}
    titles=["Noisy Malvar","Raw row split","Median reference","Protected reference","Exact offset oracle","Exact GT"]
    for name,columns in (("comparison",tuple(range(len(stash)))),("triplet",(0,3,5))):
        board=Image.new("RGB",(8+168*len(columns),192),"#eeeeee")
        draw=ImageDraw.Draw(board)
        metadata=[]
        for index,col in enumerate(columns):
            origin=8+168*index
            board.paste(Image.fromarray(stash[col]),(origin,24))
            draw.text((origin,5),titles[col],fill="black")
            metadata.append({"label":titles[col],"png_xywh":[origin,24,SIZE,SIZE]})
        filename=ROOT/"native"/f"{key}-{name}.png"
        board.save(filename)
        pixels=np.asarray(Image.open(filename))
        for row,j in zip(metadata,columns,strict=True):
            x,y,w,h=row["png_xywh"]
            np.testing.assert_array_equal(pixels[y:y+h,x:x+w],stash[j])
        records[name]={"image":reference(filename),"panels":metadata}
    return records


def render():
    torch.set_num_threads(1)
    summary_path=ROOT/"summary.json"
    summary=read_json(summary_path)
    spec=read_json(checked(summary["plan"]))
    condition_rows=[row for record in summary["shards"] for row in read_json(checked(record))["rows"]]
    sources={s["source_seed"]:s for s in spec["test_sources"]}
    (ROOT/"native").mkdir()
    rows=[]
    for key,exterior,kind,rule in VIEWS:
        selected, score=select(condition_rows,exterior,kind,rule)
        source=sources[selected["source"]]
        rows.append({"key":key,"selection":rule,"selection_score":score,"row":selected,
                     "views":image(selected,source,key),"source":source,
                     "display_exposure":EXP, "native_ROI_xywh":[0,0,SIZE,SIZE]})
    write_json(ROOT/"native"/"result.json", {"driver":reference(__file__),"summary":reference(summary_path),
                  "plan":reference(PANEL),"views":rows})


if __name__=="__main__":
    render()
