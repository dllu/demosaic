"""Test whether independent distant RAW samples can remove shared row offsets."""

from pathlib import Path
import argparse
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
EARLIER = ROOT.parent / "withheld-row-noise-v1"
sys.path.insert(0, str(EARLIER))
from probe import BLACK, CFAS, READ, SHOT, SIZE, X, Y, color_labels, fields, fit, measure, sample, split_rows, stratified_split

PANEL = ROOT / "plan.json"
FRACTIONS = (0.5, 1.0)
EXTERIORS = ("smooth", "one-striped-strip", "all-striped-strips")
ARMS = ("median-reference", "protected-reference", "true-offset-oracle")
KINDS = ("flat", "offgrid-edge", "oblique-pair", "row-parallel-pair", "row-parallel-pair-edge")
WIDTH = 256
STRIPS = (320, 832, 1344)
SPECTRAL_CUTOFF = 8.5
AXIS_Y, AXIS_X = np.indices((SIZE, WIDTH))
AXIS = np.stack((np.ones_like(AXIS_X), (AXIS_X-127.5)/128, (AXIS_Y-79.5)/80),axis=-1)


def freeze():
    prior = read_json(EARLIER/"plan.json")
    write_json(PANEL, {
        "driver":reference(__file__), "prior_plan":reference(EARLIER/"plan.json"),
        "prior_collector":reference(EARLIER/"probe.py"), "prior_summary":reference(EARLIER/"summary.json"),
        "prior_rows":[reference(EARLIER/f"shard-{i}.json") for i in (0,1)],
        "test_sources":[r for r in prior["seeds"] if r["cohort"]=="test"],
        "conditions":EXTERIORS,"new_methods":ARMS,
        "strips_absolute_native_x":STRIPS,"strip_width":WIDTH,
        "noise_profiles":{"row_read_fractions":FRACTIONS,"shot":SHOT,"read":READ,"ADC_black":BLACK},
        "score_threshold":2, "exterior_periodogram_rejection_power_over_expected_row":SPECTRAL_CUTOFF,
        "scope":"Matched follow-up on the same query crops. Three synthetic independent distant Bayer fields share the simulated query row offsets. Measured strip pairs are separate from all query locations. Probe assumes candidate strip locations, row-correlated variance and readout sharing are supplied. Shot/read in the existing query candidate fit remain fixed. Oracle offsets and withheld strip information are used separately.",
    })


def physical_rows(seed, fraction):
    rng=np.random.default_rng(np.random.SeedSequence([seed,2]))
    return rng.normal(size=SIZE)*np.sqrt(READ*fraction)


def exterior_strips(definition, repeat, fraction, exterior, shared):
    pattern = definition["phase"]
    source_seed = definition["source_seed"]
    repeat_seed = definition["noise_seeds"][repeat]
    true_colors=np.array(CFAS[pattern])[AXIS_Y%2, AXIS_X%2]
    hue = np.array([.94,1.,.88])[true_colors]
    phase = np.random.default_rng(source_seed+618955).uniform(0,2*np.pi)
    stripe = 0.0025*np.sin(2*np.pi*9*np.arange(SIZE)/SIZE + phase)
    latents, pointwise = [], []
    for strip, start_x in enumerate(STRIPS):
        assert start_x>=SIZE and start_x % 2 == 0
        scene_rng=np.random.default_rng(np.random.SeedSequence([source_seed,17,start_x]))
        weights=np.column_stack((scene_rng.uniform(.012,.035,3),
                                 scene_rng.uniform(-.003,.003,(3,2))))
        target = np.sum(AXIS*weights[true_colors],axis=-1)
        if exterior=="all-striped-strips" or (exterior=="one-striped-strip" and strip==1):
            target=target+stripe[:,None]*hue
        photon_rng, read_rng=(np.random.default_rng(np.random.SeedSequence(
            [repeat_seed,STRIPS[strip],group+19])) for group in range(2))
        photo=photon_rng.poisson(target/SHOT)*SHOT
        independent=noise(np.sqrt(READ*(1-fraction)),read_rng)
        raw=adc(photo+independent+shared[:,None])
        residual = np.empty_like(raw)
        for color in range(3):
            take=true_colors==color
            coef=np.linalg.lstsq(AXIS[take],raw[take],rcond=None)[0]
            residual[take]=raw[take]-AXIS[take]@coef
        latents.append(residual.mean(axis=-1))
        pointwise.append(float((SHOT*raw.mean()+READ*(1-fraction))/WIDTH))
    typical=float(np.median(pointwise))
    # Three independent strip estimates, combined by a median. Use one strip's
    # variance for a conservative fixed shrinkage factor.
    shrink = READ*fraction/(READ*fraction+typical)
    median=shrink*np.median(latents,axis=0)
    spectrum=np.fft.rfft(median)
    normalized=abs(spectrum)**2/(SIZE*READ*fraction)
    protect=normalized>SPECTRAL_CUTOFF
    protect[0]=False
    spectrum[protect]=0
    protection=np.fft.irfft(spectrum,n=SIZE)
    return median,protection,{"median_shrink":shrink,"protected_bins":np.flatnonzero(protect).tolist(),
                              "noise_error_before":float(np.sqrt(np.mean(shared**2))),
                              "median_noise_error":float(np.sqrt(np.mean((median-shared)**2))),
                              "protected_noise_error":float(np.sqrt(np.mean((protection-shared)**2)))}


def noise(scale,rng):
    return rng.normal(size=(SIZE,WIDTH))*scale


def adc(data):
    return (np.rint(np.clip(BLACK+(1-BLACK)*data,0,1)*65535)/65535-BLACK)/(1-BLACK)


def evaluate(raw, definition, kind, estimates):
    pattern=definition["phase"]
    _, strong, weak, colors = fields(kind,pattern,definition["source_seed"])
    signal=(weak[colors,Y,X],strong[colors,Y,X])
    assert np.array_equal(colors,color_labels(pattern))
    result={}
    for arm,r in estimates.items():
        # Validation always uses complete independent groups of native rows.
        mask = split_rows(definition["partition_seed"])
        data = raw - r[:,None]
        scores, _, increment = fit(data, colors, mask, kind)
        measurement=measure(increment,*signal)
        allowed=min(scores["independent_z"])>2
        result[arm]={**measurement,"accepted":allowed,
                     "minimum_z":min(scores["independent_z"]),"frequencies":scores["freqs"]}
    return result


def run(part):
    plan=read_json(PANEL)
    assert checked(plan["driver"])==Path(__file__)
    checked(plan["prior_collector"])
    rows=[r for f in plan["prior_rows"] for r in read_json(checked(f))["rows"] if r["cohort"]=="test"]
    lookup={(r["seed"],r["kind"],r["repeat"],r["fraction"]):r for r in rows}
    records=[]
    for ordinal, definition in enumerate(plan["test_sources"][part::2]):
        seed, pattern=definition["source_seed"],definition["phase"]
        for repeat, noise_seed in enumerate(definition["noise_seeds"]):
            for fraction in FRACTIONS:
                row=physical_rows(noise_seed,fraction)
                exteriors={key:exterior_strips(definition,repeat,fraction,key,row) for key in EXTERIORS}
                for kind in KINDS:
                    base, strong, weak, colors=fields(kind,pattern,seed)
                    raw=sample((base+strong+weak)[colors,Y,X],noise_seed,fraction)
                    p=lookup[seed,kind,repeat,fraction]
                    assert fingerprint(raw)==p["raw"]
                    oracle=evaluate(raw,definition,kind,{"true-offset-oracle":row})
                    for exterior,(median,protected,trace) in exteriors.items():
                        result=evaluate(raw,definition,kind,{"median-reference":median,"protected-reference":protected})
                        records.append({"source":seed,"pattern":pattern,"repeat":repeat,"fraction":fraction,"kind":kind,
                                        "exterior":exterior,"diagnostics":trace,"controls":p["policies"],
                                        "observed_query":p["raw"],"arms":result|oracle})
        if ordinal%4==0:
            print(part,ordinal,len(records),flush=True)
    write_json(ROOT/f"shard-{part}.json",{"plan":reference(PANEL),"rows":records})


if __name__ == "__main__":
    command=argparse.ArgumentParser(description=__doc__)
    command.add_argument("action",choices=("plan","collect"))
    command.add_argument("--part",type=int,choices=(0,1))
    settings=command.parse_args()
    freeze() if settings.action=="plan" else run(settings.part)
