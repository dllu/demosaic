"""Summarize measured and exact distant row compensation on paired queries."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from reference_rows import ARMS, EXTERIORS, FRACTIONS, KINDS, PANEL, ROOT

POLICIES = ("pixel", "row-pairs", *ARMS)


def fields(metrics, policy):
    accepted=metrics.get("accepted", metrics["minimum_z"]>2)
    return [
        float(accepted),
        (metrics["weak_projection"] or 0.)*accepted,
        metrics["delivered_candidate_RMS_DN16"]*accepted,
        metrics["increment_RMS_if_delivered_DN16" if accepted else "increment_RMS_if_suppressed_DN16"],
    ]


def stats(values, indices):
    intervals=np.quantile(values[indices].mean(1), [.025,.975],axis=0).T
    return {k:{"mean":float(mean),"interval_95":interval.tolist()} for k, mean, interval in
            zip(("accepted","weak_projection","correction_RMS_DN16","increment_RMS_DN16"),
                values.mean(0),intervals,strict=True)}


def reduce():
    shards=[ROOT/f"shard-{j}.json" for j in (0,1)]
    sources=[read_json(p) for p in shards]
    assert all(s["plan"] == reference(PANEL) for s in sources)
    rows=[r for shard in sources for r in shard["rows"]]
    assert len(rows)==48*len(FRACTIONS)*len(KINDS)*2*len(EXTERIORS)
    assert len(rows)==len({(r["source"],r["repeat"],r["kind"],r["fraction"],r["exterior"]) for r in rows})
    calibration, policies = {}, {}
    rng=np.random.default_rng(59371)
    for fraction in FRACTIONS:
        calibration[str(fraction)]={}
        policies[str(fraction)]={}
        for exterior in EXTERIORS:
            matches=[r for r in rows if r["fraction"]==fraction and r["exterior"]==exterior]
            debug=[r["diagnostics"] for r in matches if r["kind"]=="flat"]
            assert len(debug)==96
            calibration[str(fraction)][exterior]={
                "removed_most_common_horizontal_wave_bin":sum(9 in row["protected_bins"] for row in debug),
                "runs_with_any_protected_bin":sum(bool(row["protected_bins"])for row in debug),
                "row_RMS_errors_DN16":{name:65535*float(np.mean([r[name] for r in debug]))
                    for name in ("noise_error_before","median_noise_error","protected_noise_error")},
            }
            by_kind={}
            for kind in KINDS:
                table=defaultdict(lambda:defaultdict(list))
                for obs in matches:
                    if obs["kind"]!=kind:
                        continue
                    for arm in POLICIES:
                        info=(obs["arms"]|obs["controls"])[arm]
                        table[arm][obs["source"]].append(fields(info,arm))
                arrays={arm:np.asarray([np.mean(value,axis=0) for _,value in sorted(record.items())])
                        for arm,record in table.items()}
                assert all(value.shape==(48,4) for value in arrays.values())
                indices = rng.integers(0, 48, (5000,48))
                baseline=arrays["row-pairs"]
                by_kind[kind]={arm:{"aggregate":stats(estimate,indices),
                                    "delta_from_raw_row_split":stats(estimate-baseline,indices)}
                               for arm,estimate in arrays.items()}
            policies[str(fraction)][exterior]=by_kind
    write_json(ROOT/"summary.json", {
        "plan":reference(PANEL),"driver":reference(__file__),"shards":list(map(reference,shards)),
        "source_count":48,"matched_query_condition_groups":len(rows),
        "row_reference_fit":calibration,"policies":policies,
        "native_viewing_status":"pending",
    })


if __name__ == "__main__":
    reduce()
