"""Reweight saved correction by shorter support with matched-strength control."""
import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live
from local_guard import paired_gates

ROOT=Path(__file__).resolve().parent
ORIG=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(ORIG))
from measure import parts,reduce

MASK_INPUTS=("packed","variance","colors")
LABELS=("intersection-paired","scaled-wide-paired")
CENTER=np.s_[...,80:176,80:176]

def qualify_wait(stage):
    artifact=ROOT/stage/"complete.json"
    if stage=="milestone":
        assert artifact.is_file()
    else:
        base=ROOT/stage/"launch.json"
        parent=read_json(ROOT/"training/launch.json")
        while not base.is_file():
            if not owner_live(parent) and not (ROOT/"training/complete.json").exists():
                raise RuntimeError("The source training ended without completion")
            time.sleep(5)
        owner=read_json(base)
        while not artifact.is_file():
            if not owner_live(owner) and not artifact.is_file():
                raise RuntimeError("The bound endpoint reviewer has ended without a complete collection")
            time.sleep(5)
    return read_json(artifact)

def reweight(args,parent,paired,archived_threshold,local_threshold):
    data=[torch.from_numpy(args[k])for k in MASK_INPUTS]
    if data[-1].ndim==1:
        data[-1]=data[-1][None].expand(len(parent),-1)
    a,b=paired_gates(*data,local_threshold,archived_threshold)
    coarse,local=[v.numpy() for v in (a,b)]
    correction=paired-parent
    proposed=correction*local
    wide=correction*coarse
    std=lambda u:np.sqrt(np.mean(u.astype(np.float64)**2,axis=(1,2,3),keepdims=True))
    fraction=np.divide(std(proposed),std(wide),where=std(wide)>0,out=np.zeros((len(parent),1,1,1)))
    assert np.all((0<=fraction)&(fraction<=1.0000001))
    normalized=wide*fraction
    np.testing.assert_allclose(std(proposed),std(normalized),rtol=1e-6,atol=1e-12)
    variants={LABELS[0]:(parent+proposed).astype(np.float32),LABELS[1]:(parent+normalized).astype(np.float32)}
    return variants,local,fraction.flatten().tolist()

def run(stage):
    torch.set_num_threads(1)
    start=time.monotonic()
    original=qualify_wait(stage)
    plan=read_json(checked(original["plan"]))
    archive=read_json(checked(original["photo_results"]))
    study=read_json(ORIG/"evaluation-plan.json")
    local_file=ROOT/"local-support-calibration.json"
    local=read_json(local_file)
    assert local["existing"]==plan["support"]
    cutoff=local["threshold"]
    wide=plan["threshold"]
    out=ROOT/stage/"short-guard"
    out.mkdir()
    measurements=[]
    for row in archive["rows"]:
        prior=read_json(checked(row["original"]))
        case=read_json(checked(prior["case"]))
        with np.load(checked(case["input"]),allow_pickle=False)as source:
            inputs={k:source[k]for k in (*MASK_INPUTS,"wb","matrix","target")}
        with np.load(checked(prior["saved"]),allow_pickle=False)as source:
            parent=source["100k"]
        with np.load(checked(row["saved"]),allow_pickle=False)as source:
            full=source["paired"]
        after,gate,scale=reweight(inputs,parent,full,wide,cutoff)
        target=inputs["target"]
        scoring={k:np.broadcast_to(inputs[k][None],(3,*inputs[k].shape))for k in ("wb","matrix")}
        scoring["exposure"]=case["profile"]["exposure"]
        stats={k:parts(scoring,v,target,study)for k,v in after.items()}
        add_to_flat={}
        for key,arr in after.items():
            change=(arr-parent)[CENTER]
            add_to_flat[key]=(65535*np.sqrt(np.mean(change.astype(float)**2,axis=(1,2,3)))).tolist()
        file=out/(case["id"]+".npz")
        with file.open("xb")as fd:
            np.savez(fd,**after,guard=gate)
        measurements.append({**row,"metrics":row["metrics"]|stats,"guarded_output":reference(file),
                             "scales":scale,"added_RMS_DN16_per_role":add_to_flat})
    assert len(measurements)==len(archive["rows"])
    write_json(out/"results.json",{
        "driver":reference(__file__),"original":original["photo_results"],"calibration":reference(local_file),
        "count":len(measurements),"pooled":reduce(measurements),"rows":measurements,
        "seconds":time.monotonic()-start,
        "matched_strength":"Scalar matches the new gate's RMS correction over the whole native query independently in every role. It uses two input-only corrections. The clean masks and targets do not enter scaling.",
    })
    if original["standing_results"] is not None:
        cases=read_json(checked(original["standing_results"]))
        standing=[]
        for row in cases["rows"]:
            parent=np.load(checked(row["parent"]),allow_pickle=False)
            with np.load(checked(row["raw"]["arrays"]),allow_pickle=False)as stored:
                inputs={k:stored[k]for k in MASK_INPUTS}
            with np.load(checked(row["saved"]),allow_pickle=False)as stored:
                full=stored["paired"]
            current,gate,scale=reweight(inputs,parent,full,wide,cutoff)
            file=out/(row["id"]+".npz")
            with file.open("xb")as fd:
                np.savez(fd,**current,guard=gate)
            standing.append({"id":row["id"],"file":reference(file),"scale":scale})
        write_json(out/"standing.json",{"source":original["standing_results"],"cases":standing})

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage",choices=("milestone","endpoint"))
    run(parser.parse_args().stage)
