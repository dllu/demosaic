"""Check a fixed green-phase gate on withheld exact targets and the standing crops."""
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from raw_support import support_score,weights

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"scene-local-contrast-2400-v1"
KEYS=("packed","variance","colors")
CORE=np.s_[...,80:176,80:176]

def check_inputs(row,declared):
    assert all(fingerprint(row[k])==declared[k]for k in KEYS)

def summarize(array):
    return {"mean":float(np.mean(array)),"min":float(np.min(array)),
            "interval_10_to_90":np.quantile(array,[.10,.90]).tolist(),
            "max":float(np.max(array))}

def run():
    torch.set_num_threads(2)
    source=PRIOR/"evaluation-plan.json"
    panel=read_json(source)
    calib=ROOT/"support-calibration.json"
    threshold=read_json(calib)["threshold_0_to_1"][0]
    natural=[]
    groups=defaultdict(list)
    for row in panel["rows"]:
        for profile in panel["profiles"]:
            for draw in panel["draws"]:
                case=PRIOR/"observations"/f"{row['index']:03d}-{profile['name']}-{draw}.json"
                receipt=read_json(case)
                assert receipt["source"]==row["source"]["id"]
                with np.load(checked(receipt["input"]),allow_pickle=False)as stored:
                    arrays={k:stored[k]for k in KEYS}
                check_inputs(arrays,receipt["fingerprints"])
                args=[torch.from_numpy(arrays[k])for k in KEYS]
                args[-1]=args[-1][None].expand(3,-1)
                measured=support_score(*args)[CORE]
                support=((measured-threshold)/threshold).clamp(0,1)
                active=(support>0).float().mean((1,2,3)).tolist()
                strong=support.mean((1,2,3)).tolist()
                natural.append({"case":reference(case),"source":receipt["source"],"profile":profile["name"],
                    "draw":draw,"active_per_role":active,"mean_weight_per_role":strong,
                    "max_band_cross_per_role":measured.amax((1,2,3)).tolist(),
                    "exact_increment_RMS_DN16":receipt["clean_linear_increment_RMS_DN16"]})
                for index,role in enumerate(panel["roles"]):
                    groups[profile["name"],draw,role].append((active[index],strong[index]))
    metrics={}
    for (profile,draw,role),data in groups.items():
        a,w=np.asarray(data).T
        metrics.setdefault(profile,{}).setdefault(draw,{})[role]={
            "active":summarize(a),"average_gate":summarize(w),"sources":len(a),
            "sources_with_active_gate":int((a>0).sum())}
    render=read_json(PRIOR/"reviews/standing/render/result.json")
    camera=[]
    for region in render["boards"]:
        if region["observation"].startswith("development"):
            continue
        with np.load(checked(region["input_arrays"]),allow_pickle=False)as file:
            packed,var,colors=[torch.from_numpy(file[k])for k in KEYS]
        x,y,w,h=region["case"]["ROI_xywh"]
        support=weights(packed,var,colors,threshold)[0,0,y:y+h,x:x+w]
        assert (w,h)==(160,160)
        camera.append({"id":region["id"],"input":region["input_arrays"],
            "native_ROI_xywh":[x,y,w,h],"noise":region["noise"],
            "active_fraction":float((support>0).float().mean()),"mean_weight":float(support.mean())})
    assert len(natural)==256 and len(camera)==8
    write_json(ROOT/"guard-audit.json",{"driver":reference(__file__),"calibration":reference(calib),
        "heldout_plan":reference(source),"natural":natural,"summary":metrics,"standing":camera,
        "scope":"Measuring regional support coverage only. A nonzero weight neither selects a wire direction nor proves the proposed residual."})

if __name__=="__main__":
    run()
