"""Use aligned green-phase correlation to attenuate a candidate in quiet areas."""
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.cfa import PATTERNS,color_indices
from demosaic.experiments.artifacts import reference,write_json
from demosaic.experiments.data.noise import coupled_sensor_noise

ROOT=Path(__file__).resolve().parent
CROP=np.s_[...,48:208,48:208]
SEED=7210674

def support_score(packed,variance,colors):
    count,_,height,width=packed.shape
    phase_ids = torch.argsort((colors != 1).to(torch.int64),dim=1,stable=True)[:,:2]
    pick=phase_ids[:,:,None,None].expand(count,2,height,width)
    navy=torch.gather(packed,1,pick).reshape(count*2,1,height,width)
    variances=torch.gather(variance,1,pick)
    yy,xx=torch.meshgrid(torch.arange(height,device=packed.device,dtype=packed.dtype),
                         torch.arange(width,device=packed.device,dtype=packed.dtype),indexing="ij")
    xx=(xx + .5)*(2/width)-1
    yy=(yy + .5)*(2/height)-1
    offsets=torch.stack(((.5-(phase_ids%2))/width,(.5-(phase_ids//2))/height),-1)
    grid=torch.stack((xx,yy),-1)[None] + offsets.reshape(-1,1,1,2)
    centered=F.grid_sample(navy,grid,padding_mode="border",align_corners=False).reshape(count,2,height,width)
    def pool(values,size):
        return F.avg_pool2d(values,size,stride=1,padding=size//2,count_include_pad=False)
    wave=(pool(centered,3)-pool(centered,9))/pool(variances,9).clamp_min(1e-10).sqrt()
    cross=pool(wave[:,0:1]*wave[:,1:2],21)
    return F.interpolate(cross,scale_factor=2,mode="bilinear",align_corners=False)

def weights(raw,var,colors,threshold):
    z=(support_score(raw,var,colors)-threshold)/threshold
    return z.clamp(0,1)

def calibrate():
    torch.set_num_threads(2)
    noise=(("iso400",8e-5,2.56e-8),("iso6400",.00128,6.5536e-6))
    noise_seed=torch.Generator().manual_seed(SEED)
    scores=[]
    panels={}
    for name,shot,read in noise:
        n=64
        picks=[tuple(PATTERNS)[i%4]for i in range(n)]
        colors=torch.stack([color_indices(v)for v in picks])
        levels=torch.logspace(-2.7,-.27,n)
        raw=levels[:,None,None,None].expand(n,4,128,128).contiguous()
        actual,_=coupled_sensor_noise(raw,raw,shot,read,black_level=.03,generator=noise_seed)
        var=shot*actual.clamp_min(0)+read
        cs=support_score(actual,var,colors)[CROP].flatten().numpy()
        scores.append(cs)
        panels[name]={"exact_flats":n,"quantiles":np.quantile(cs,[.5,.95,.99,.995,.999]).tolist()}
    combined=np.concatenate(scores)
    threshold=float(np.quantile(combined,.995))
    assert threshold>0
    write_json(ROOT/"support-calibration.json",{
        "source":reference(__file__),"seed":SEED,"flat_calibration":panels,
        "threshold_0_to_1":[threshold,2*threshold],
        "scope":"The guard attenuates the learned correction where the two green Bayer phases have little local band covariance. Calibrate on simulated exact constants only. This is a regional texture test with related score locations, not a validation of the direction or of the proposed amplitude.",
    })

if __name__=="__main__":
    calibrate()
