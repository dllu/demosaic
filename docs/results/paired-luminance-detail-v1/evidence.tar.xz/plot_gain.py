"""Plot the fixed-amplitude fine-error and exact-flat frontier."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/"endpoint/gain-curve.json"
SERIES={
    "paired":("No gate","#3165a5"),
    "guarded-paired":("42 px","#cf741d"),
    "intersection-paired":("18 and 42 px","#158772"),
    "scaled-wide-paired":("42 px, matched RMS","#815898"),
}

def draw():
    receipt=read_json(SOURCE)
    assert receipt["gain_levels"]==[0,.25,.5,.75,1.]
    panel=receipt["curve"]["iso6400"]
    fig,axes=plt.subplots(1,2,figsize=(9.3,3.7),layout="constrained")
    for ax,(label,name) in zip(axes,(("coupled","Coupled noise"),("independent","Independent noise")),strict=True):
        for key,(series,color) in SERIES.items():
            values=panel[label][key]
            x,y=(np.asarray(values[k])-values[k][0]for k in ("flat_RMS_DN16","increment_RMS_DN16"))
            ax.plot(x,y,"o-",color=color,label=series,linewidth=1.5,markersize=4)
        ax.grid(alpha=.2)
        ax.axvline(0,color="#777777",lw=.8)
        ax.axhline(0,color="#777777",lw=.8)
        ax.set_title(name)
        ax.set_xlabel("Change in exact-flat fine RMS (DN16)")
        ax.set_ylabel("Change in weak-increment RMS (DN16)")
    axes[0].legend(loc="best",frameon=False,fontsize=8)
    fig.suptitle("Paired luminance correction at ISO6400")
    dest=ROOT/"native/gain-frontier.png"
    fig.savefig(dest,dpi=135)
    write_json(ROOT/"gain-plot.json",{
        "driver":reference(__file__),"source":reference(SOURCE),"image":reference(dest),
        "scope":"0, .25, .5, .75 and 1 times the proposed correction on 64 fixed sources, relative to Corpus 100k.",
    })

if __name__=="__main__":
    draw()
