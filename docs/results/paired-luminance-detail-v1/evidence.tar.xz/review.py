"""Review the two luminance detail EMAs on exact natural and standing camera inputs."""
import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
import psutil
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live
from demosaic.paired_detail import PairedLuminanceDetail,fine_band
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from raw_support import weights as sensor_support

ROOT=Path(__file__).resolve().parent
ORIG=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(ORIG))
from evaluate import ARGS
from measure import parts,reduce

LABELS=("absolute","paired")
POLICIES=("absolute","paired","guarded-absolute","guarded-paired")

def confirm_file(path):
    launch=ROOT/"training/launch.json"
    while not launch.is_file():
        owner=read_json(ROOT/"qualification/launch.json")
        if not owner_live(owner) and not (ROOT/"qualification/complete.json").is_file():
            raise RuntimeError("Training qualification ended before binding a complete checkpoint")
        time.sleep(3)
    owner=read_json(launch)
    while not path.is_file():
        if not owner_live(owner) and not path.is_file():
            raise RuntimeError(f"Training ended before producing {path}")
        time.sleep(5)
    return reference(path)

def load_heads(binding):
    state=torch.load(checked(binding),weights_only=True,map_location="cpu")
    heads={}
    assert state["parent_frozen"] and state["plan"]==reference(ROOT/"plan.json")
    for key in LABELS:
        net=PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).eval()
        net.load_state_dict(state["weights"][key]["ema"],strict=True)
        heads[key]=net
    return state["step"],heads

def compose(heads,parent,fields,threshold):
    args=[fields[k]for k in ARGS]
    fields_used=torch.linalg.solve(fields["matrix"],torch.ones_like(fields["wb"]).unsqueeze(-1))
    neutral=fields_used.squeeze(-1)/fields["wb"]
    gate=sensor_support(fields["packed"],fields["variance"],fields["colors"],threshold)
    variants,corrections={},{}
    for name,head in heads.items():
        delta=head.luminance_delta(parent,*args)
        corrections[name]=delta
        corrections["guarded-"+name]=delta*gate
    for name,delta in corrections.items():
        result=parent+delta*neutral[:,:,None,None]
        assert torch.isfinite(result).all()
        variants[name]=result
    return variants,gate,corrections

def exact_photos(out,heads,primary,subset):
    reference_plan=read_json(ORIG/"evaluation/plan.json")
    spec=read_json(checked(reference_plan["panel"]))
    assert reference_plan["models"]["100k"]==primary["base"]
    records=ORIG/"evaluation/predictions"
    product=out/"photos"
    product.mkdir()
    rows=[]
    for i in subset:
        for profile in spec["profiles"]:
            for draw in spec["draws"]:
                location=records/f"{i:03d}-{profile['name']}-{draw}.json"
                prior=read_json(location)
                assert prior["plan"]==reference(ORIG/"evaluation/plan.json")
                case=read_json(checked(prior["case"]))
                with np.load(checked(case["input"]),allow_pickle=False)as values:
                    arrays={k:values[k]for k in (*ARGS,"target")}
                assert all(fingerprint(arrays[k])==prior["exact_query_inputs"][k]for k in ARGS)
                with np.load(checked(prior["saved"]),allow_pickle=False)as variants:
                    parents={k:variants[k]for k in ("100k","V120","plain-none","localized-none")}
                fields={k:torch.from_numpy(arrays[k]).cuda()for k in ARGS}
                for k in ARGS[2:]:
                    fields[k]=fields[k][None].expand(3,*fields[k].shape)
                for k in ARGS[:2]:
                    fields[k]=fields[k].contiguous(memory_format=torch.channels_last)
                parent=torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
                variants,gate,correction=compose(heads,parent,fields,primary["threshold"])
                view={k:v.cpu().numpy()for k,v in variants.items()}
                score_fields={k:np.broadcast_to(arrays[k][None],(3,*arrays[k].shape))
                              for k in ("wb","matrix")}
                score_fields["exposure"]=profile["exposure"]
                scored={k:parts(score_fields,v,arrays["target"],spec)for k,v in (parents|view).items()}
                actual_lift={}
                for method,array in correction.items():
                    area=array[...,80:176,80:176]
                    actual_lift[method]={
                        "correction_RMS_DN16_per_role":(65535*area.square().mean((1,2,3)).sqrt()).cpu().tolist(),
                        "fine_correction_RMS_DN16_per_role":(65535*fine_band(array)[...,80:176,80:176].square().mean((1,2,3)).sqrt()).cpu().tolist(),
                    }
                path=product/(case["id"]+".npz")
                with path.open("xb")as dest:
                    np.savez(dest,**view,gate=gate.cpu().numpy())
                rows.append({
                    "source":case["source"],"profile":profile["name"],"draw":draw,"original":reference(location),
                    "saved":reference(path),"metrics":scored,"actual_lift":actual_lift,
                    "guard_active_fraction_per_role":(gate[...,80:176,80:176]>0).float().mean((1,2,3)).cpu().tolist(),
                })
        print("photo",i,len(rows),flush=True)
    assert len(rows)==len(subset)*4
    write_json(out/"photo-results.json",{
        "plan":reference(out/"plan.json"),"count":len(rows),"rows":rows,"pooled":reduce(rows),
        "scope":"All retained local inputs replayed with the same FP32 full parent. New component is applied once per native query.",
    })

def standing(out,heads,primary):
    target=out/"standing"
    target.mkdir()
    before=ORIG/"reviews/standing/collection.json"
    stable=read_json(before)
    collection=read_json(checked(stable["parent"]))
    original=read_json(checked(collection["plan"]))
    assert collection["checkpoint"]==primary["base"]|{} or collection["checkpoint"]["sha256"]==primary["base"]["sha256"]
    prior_by_id={key["id"]:key for key in collection["records"]}
    rows=[]
    for record in original["observations"]:
        if record["kind"]=="development":
            continue
        prior=prior_by_id[record["id"]]
        with np.load(checked(record["arrays"]),allow_pickle=False)as source:
            arrays={k:source[k]for k in ARGS}
        assert {k:fingerprint(v)for k,v in arrays.items()}==prior["input_fingerprints"]
        parent=torch.from_numpy(np.load(checked(prior["prediction"]),allow_pickle=False)).cuda()
        fields={k:torch.from_numpy(v).cuda()for k,v in arrays.items()}
        variants,gate,correction=compose(heads,parent,fields,primary["threshold"])
        product=target/(record["id"]+".npz")
        with product.open("xb")as dest:
            np.savez(dest,**{k:v.cpu().numpy()for k,v in variants.items()},gate=gate.cpu().numpy())
        rows.append({"id":record["id"],"parent":prior["prediction"],"raw":record,
                     "inputs":prior["input_fingerprints"],"saved":reference(product),
                     "cam_proof":collection["full_real_noisy_sources"]})
        print("GFX",record["id"],flush=True)
    assert len(rows)==6
    write_json(out/"standing-results.json",{
        "plan":reference(out/"plan.json"),"parent_collection":stable["parent"],"rows":rows,
        "display_parent_boards":reference(ORIG/"reviews/standing/render/result.json"),
    })

@torch.inference_mode()
def run(stage):
    os.sched_setaffinity(0,[14,15])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    early=stage=="milestone"
    wait=ROOT/"training"/("step000300.pt" if early else "complete.json")
    witness=confirm_file(wait)
    checkpoint=witness if early else read_json(checked(witness))["head_checkpoint"]
    step,heads=load_heads(checkpoint)
    assert step==(300 if early else 1200)
    out=ROOT/stage
    out.mkdir()
    write_json(out/"launch.json",{"pid":os.getpid(),"created":psutil.Process().create_time()})
    support_file=ROOT/"support-calibration.json"
    support=read_json(support_file)
    base=read_json(ROOT/"plan.json")["models"]["Corpus 100k"]
    active={"checkpoint":checkpoint,"training":witness,"base":base,"precision":"CUDA IEEE FP32 EMA head",
            "stage":stage,"support":reference(support_file),"threshold":support["threshold_0_to_1"][0],
            "driver":reference(__file__),"label_variants":POLICIES}
    write_json(out/"plan.json",active)
    began=time.monotonic()
    with ieee_fp32():
        exact_photos(out,heads,active,range(8 if early else 64))
        if not early:
            standing(out,heads,active)
    write_json(out/"complete.json",{
        "plan":reference(out/"plan.json"),"sample_scope":"8 held-out photos" if early else "64 held-out photos and both standing GFX families",
        "seconds":time.monotonic()-began,"photo_results":reference(out/"photo-results.json"),
        "standing_results":None if early else reference(out/"standing-results.json"),
        "actual_image_viewing":False,
    })

if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("stage",choices=("milestone","endpoint"))
    run(cli.parse_args().stage)
