"""Separate observed fine-band error shared across draws from draw sensitivity."""
import argparse
from pathlib import Path
import sys

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(PRIOR))
from measure import BANDS,LUMA,coeffs

NAMES=("100k","absolute","paired","guarded-absolute","guarded-paired",
       "intersection-paired","scaled-wide-paired")
METRICS=("average_squared_error","cross_draw_error_product","half_squared_draw_difference")
SEED=4271099

def load(row,with_local):
    older=read_json(checked(row["original"]))
    case=read_json(checked(older["case"]))
    with np.load(checked(case["input"]),allow_pickle=False)as stored:
        labels={"target":stored["target"],"wb":stored["wb"],"matrix":stored["matrix"]}
    with np.load(checked(older["saved"]),allow_pickle=False)as stored:
        output={"100k":stored["100k"]}
    with np.load(checked(row["saved"]),allow_pickle=False)as stored:
        output.update({k:stored[k]for k in ("absolute","paired","guarded-absolute","guarded-paired")})
    if with_local:
        with np.load(checked(row["guarded_output"]),allow_pickle=False)as stored:
            output.update({k:stored[k]for k in ("intersection-paired","scaled-wide-paired")})
    return case,labels,output

def run(stage):
    directory=ROOT/stage
    local=directory/"short-guard/results.json"
    with_local=local.is_file() and stage != "middle"
    source=local if with_local else directory/"photo-results.json"
    full=read_json(source)
    data=read_json(PRIOR/"evaluation-plan.json")
    roi=data["score_ROI_xywh"]
    selected=read_json(PRIOR/"matched-analysis-plan.json")["fainter_half_by_frozen_clean_increment"]
    faint={r[2]for r in selected}
    case_by_spec={(row["source"],row["profile"],row["draw"]):row for row in full["rows"]}
    all_ids=sorted({row["source"]for row in full["rows"]})
    methods=NAMES if with_local else NAMES[:5]
    scores={}
    for profile in ("iso400","iso6400"):
        rows=[]
        for identity in all_ids:
            a,b=[load(case_by_spec[identity,profile,kind],with_local)
                 for kind in ("coupled","independent")]
            for key in ("target","wb","matrix"):
                np.testing.assert_array_equal(a[1][key],b[1][key])
            assert set(a[0]["physical_seeds"].values()).isdisjoint(b[0]["physical_seeds"].values())
            fields={k:np.broadcast_to(a[1][k][None],(3,*a[1][k].shape)) for k in ("wb","matrix")}
            def band(values):
                image=linear_rgb(values,fields)
                y=np.einsum("c,bchw->bhw",LUMA,image)
                return coeffs(y,roi)[...,BANDS["fine"]]*65535
            target=band(a[1]["target"])
            stats={}
            for k in methods:
                error=[band(record[2][k])-target for record in (a,b)]
                u,v=[np.stack((p[0]-p[1],p[0],p[1],p[2]),axis=0) for p in error]
                avg=(u**2+v**2)*.5
                cross=u*v
                noise=(u-v)**2*.5
                np.testing.assert_allclose(avg,cross+noise,atol=1e-8,rtol=1e-9)
                stats[k]=[knd.mean(axis=(1,2)).tolist() for knd in (avg,cross,noise)]
            rows.append({"source":identity,"measures":stats})
        scores[profile]=rows
    rng=np.random.default_rng(SEED)
    summary={}
    for profile,rows in scores.items():
        summary[profile]={}
        for cohort,group in (("all",rows),("fainter",[r for r in rows if r["source"]in faint])):
            choices=rng.integers(len(group),size=(10000,len(group)))
            baseline=np.asarray([row["measures"]["100k"]for row in group])
            out={}
            for k in methods:
                vals=np.asarray([row["measures"][k]for row in group])
                delta=vals-baseline
                out[k]={"mean":vals.mean(0).tolist(),"vs_parent":delta.mean(0).tolist(),
                        "vs_parent_interval_95":np.quantile(delta[choices].mean(1),[.025,.975],axis=0).tolist()}
            summary[profile][cohort]=out
    write_json(directory/"repeat-decomposition.json",{
        "driver":reference(__file__),"metrics_source":reference(source),"metrics":METRICS,
        "score_units":"DN16 squared, identical native scored core","roles":["increment","present","masked","flat"],
        "sources":len(all_ids),"profiles":scores,"summary":summary,
        "scope":"Two available observations provide an exact sample decomposition. Cross products estimate error shared across independently sampled complete draws; half the squared difference reflects their mean draw sensitivity. The average combines one coupled and one independent within-pair noise law. This is a descriptive separation, not a replacement for either paired score or additional repeat observations.",
    })

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage",choices=("middle","endpoint"))
    run(p.parse_args().stage)
