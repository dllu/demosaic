"""Shared frozen Corpus 100k forward for two matched residual objectives."""
import argparse
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import psutil
import torch
from torch.nn import functional as F

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.paired_detail import PairedLuminanceDetail, fine_band
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe
from demosaic.scene_training_data import scene_seed,_attenuate_local_contrast
from profile_raw_kernel_inference import model_hash

ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(ORIGINAL))
from evaluate import ARGS,setup_models
from prepare_eval import flat_patch

SEED=9345663129
STEPS=1200
PER_UPDATE=2
CENTER=np.s_[...,80:176,80:176]
WEIGHTS={"absolute":0.,"paired":0.65}

def freeze():
    earlier=read_json(ORIGINAL/"plain/plan.json")
    ready=read_json(ORIGINAL/"evaluation/plan.json")
    source=checked(earlier["train_manifest"])
    records=[json.loads(line)for line in source.read_text().splitlines()if line.strip()]
    assert len(records)==90692 and all(r["split"]=="train" for r in records)
    holdout=read_json(checked(ready["panel"]))["rows"]
    assert {r["id"]for r in records}.isdisjoint(r["source"]["id"]for r in holdout)
    known=read_json(Path("docs/results/full-corpus-long100k-primary-v1/primary.json"))
    assert {r["id"]for r in records}.isdisjoint(known["source_averages"])
    rng=random.Random(SEED)
    use=rng.sample(range(len(records)),STEPS*PER_UPDATE)
    schedule=[records[i]for i in use]
    assert len({r["id"]for r in schedule})==STEPS*PER_UPDATE
    write_json(ROOT/"schedule.json",{"source":reference(source),"seed":SEED,"rows":schedule})
    write_json(ROOT/"plan.json",{
        "driver":reference(__file__),"head_source":reference(Path("src/demosaic/paired_detail.py")),
        "reserved_natural_panel":ready["panel"],"source_schedule":reference(ROOT/"schedule.json"),
        "models":{"Corpus 100k":ready["models"]["100k"]},"native_patch":256,"roles":["present","absent","flat"],
        "steps":STEPS,"photos_per_update":PER_UPDATE,"weights":WEIGHTS,"seed":SEED,
        "optimizer":"AdamW 3e-4 to 3e-5 cosine, warmup 60, gradient limit 1, EMA .995, identical init",
        "loss":"Both heads learn the absolute fine-luminance residual and zero delivered lift in exact flat cores. Paired adds aligned present-minus-absent fine residual. Same physical inputs, learning rate, and optimizer.",
        "precision":"CUDA IEEE FP32 throughout; canonical 16 bit Poisson/read/ADC; parent frozen.",
    })

def clean_crop(record,index):
    rng=random.Random(scene_seed(SEED,index,"crop"))
    path=Path(record["cache"])
    assert path.is_relative_to("/mnt/external/demosaic")
    assert reference(path)["sha256"]==record["cache_sha256"]
    data=np.load(path,mmap_mode="r",allow_pickle=False)
    assert data.dtype==np.uint16 and list(data.shape)==record["shape"]
    h,w=data.shape[:2]
    x,y=rng.randrange(0,w-255,2),rng.randrange(0,h-255,2)
    quarter=rng.randrange(4)
    mirror=rng.randrange(2)
    clean=np.rot90(np.asarray(data[y:y+256,x:x+256]).astype(np.float32),quarter)
    if mirror:
        clean=clean[:,::-1]
    rgb=torch.from_numpy(clean.copy()).permute(2,0,1).contiguous()/65535
    contrast=2**rng.uniform(-3.5,-.5)
    present=_attenuate_local_contrast(rgb,(0,0,256,256),contrast)
    absent=_attenuate_local_contrast(rgb,(0,0,256,256),0.)
    return (present,absent,flat_patch(absent)), {
        "id":record["id"],"cache_sha256":record["cache_sha256"],"crop_xywh":[x,y,256,256],
        "D4":[quarter,mirror],"present_contrast":contrast,
    }

def physical(record,index,profile):
    patches,about=clean_crop(record,index)
    base=sample_scene_recipe(scene_seed(SEED,index,"camera"))
    pattern=tuple(PATTERNS)[index%4]
    common=replace(base,pattern=pattern,black=.03,**profile)
    chance=random.Random(scene_seed(SEED,index,"couple"))
    seeds=[scene_seed(SEED,index,role)for role in ("pair","present","absent","flat")]
    def independently(patch,seed):
        obs=observe_scene(patch,replace(common,noise_seed=seed))
        return {k:getattr(obs,k)for k in (*ARGS,"target")}
    if chance.random()<0.75:
        pair,_=paired_observation(*[patch[None]for patch in patches[:2]],profile,[pattern],
                                 torch.tensor(base.wb)[None],torch.tensor(base.camera_inverse)[None],seeds[0])
        roles=[{k:torch.from_numpy(pair[k][i])for k in (*ARGS,"target")}for i in (0,1)]
        coupling="shared counts and read draw"
    else:
        roles=[independently(p,s)for p,s in zip(patches[:2],seeds[1:3],strict=True)]
        coupling="independent"
    flat=independently(patches[2],seeds[3])
    assert torch.equal(flat["target"][CENTER],flat["target"][:,80:81,80:81].expand(3,96,96))
    roles.append(flat)
    values={k:torch.stack([r[k]for r in roles])for k in (*ARGS,"target")}
    return values,about|{
        "profile":profile,"pattern":pattern,"coupling":coupling,"simulator_seeds":seeds,
        "camera":common.__dict__,"values":{k:fingerprint(v.numpy())for k,v in values.items()},
    }

def ema_update(ema,module):
    with torch.no_grad():
        for name,value in module.state_dict().items():
            ema[name].lerp_(value,0.005)

def schedule_lr(step):
    if step<=60:
        return 3e-4*step/60
    frac=(step-60)/max(1,STEPS-60)
    return float(3e-5+(3e-4-3e-5)*(0.5+0.5*np.cos(np.pi*frac)))

def save_checkpoint(folder,step,heads,ema,optimizer,plan):
    path=folder/f"step{step:06d}.pt"
    state={"step":step,"plan":plan,"weights":{
        key:{"raw":net.state_dict(),"ema":ema[key],"optimizer":optimizer[key].state_dict()}
        for key,net in heads.items()},"parent_frozen":True}
    temporary=path.with_suffix(".partial")
    torch.save(state,temporary)
    temporary.replace(path)
    return reference(path)

def run(qualification=False):
    path=ROOT/"plan.json"
    plan=read_json(path)
    assert checked(plan["driver"])==Path(__file__) and plan["weights"]==WEIGHTS
    checked(plan["head_source"])
    photos=read_json(checked(plan["source_schedule"]))["rows"]
    start_index=2*STEPS if qualification else 0
    if qualification:
        # Qualification consumes three separate training sources outside the scheduled examples.
        choices=[json.loads(line)for line in checked(read_json(plan["source_schedule"]["path"])["source"]).read_text().splitlines()]
        reserved={r["id"]for r in photos}
        photos=[r for r in choices if r["id"]not in reserved][:PER_UPDATE*3]
    os.sched_setaffinity(0,[10,11,17])
    os.nice(9)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,10*2**30/torch.cuda.get_device_properties(0).total_memory))
    folder=ROOT/("qualification" if qualification else "training")
    folder.mkdir()
    write_json(folder/"launch.json",{"pid":os.getpid(),"created":psutil.Process().create_time(),
        "plan":reference(path),"qualification":qualification})
    parent=setup_models(plan)["Corpus 100k"]
    parent.requires_grad_(False)
    witness=model_hash(parent)
    torch.manual_seed(SEED)
    master=PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).state_dict()
    heads={k:PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last)for k in WEIGHTS}
    for net in heads.values():
        net.load_state_dict(master)
    ema={k:{n:v.clone()for n,v in net.state_dict().items()}for k,net in heads.items()}
    optimizer={k:torch.optim.AdamW(v.parameters(),lr=3e-4)for k,v in heads.items()}
    started=time.monotonic()
    end=3 if qualification else STEPS
    checkpoints=[]
    with (folder/"observations.jsonl").open("x")as stream, ieee_fp32():
        for step in range(1,end+1):
            factor=random.Random(scene_seed(SEED,step,"profile"))
            high=step%2
            shot,read=(.00128,6.5536e-6)if high else (8e-5,2.56e-8)
            jitter=2**factor.uniform(-.45,.45)
            profile={"shot":shot*jitter,"read":read*jitter**2,"exposure":2**factor.uniform(-2.3,-.25)}
            rank=(step-1)*PER_UPDATE
            records=[physical(photos[rank+j],start_index+rank+j,profile)for j in range(PER_UPDATE)]
            values={k:torch.cat([r[0][k]for r in records]).cuda()for k in (*ARGS,"target")}
            for k in ("packed","variance","target"):
                values[k]=values[k].contiguous(memory_format=torch.channels_last)
            parent.base.set_noise(profile["shot"],profile["read"]) if hasattr(parent,"base") else parent.set_noise(profile["shot"],profile["read"])
            with torch.no_grad():
                restored=parent(*(values[k]for k in ARGS)).detach()
            anchors=(values["wb"],values["matrix"])
            units=values["variance"].mean((1,2,3)).sqrt().clamp_min(.001)[:,None,None,None]
            score={}
            for tag,head in heads.items():
                optimizer[tag].param_groups[0]["lr"]=schedule_lr(step)
                optimizer[tag].zero_grad(set_to_none=True)
                desired=fine_band(head.scene_luma(values["target"]-restored,*anchors))
                delta=head.luminance_delta(restored,*(values[k]for k in ARGS))
                if step==1:
                    assert torch.equal(delta,torch.zeros_like(delta))
                difference=(delta-desired)/units
                absolute=(0.6*F.smooth_l1_loss(difference[CENTER],torch.zeros_like(difference[CENTER]),beta=.06)+
                          0.4*F.smooth_l1_loss(difference,torch.zeros_like(difference),beta=.06))
                flat=(delta[2::3][CENTER]/units[2::3]).square().mean()
                a,b=(delta-desired)[0::3],(delta-desired)[1::3]
                paired_error=((a-b)/units[0::3])[CENTER]
                pair=F.smooth_l1_loss(paired_error,torch.zeros_like(paired_error),beta=.06)
                loss=absolute+.25*flat+WEIGHTS[tag]*pair
                loss.backward()
                norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True)
                optimizer[tag].step()
                ema_update(ema[tag],head)
                score[tag]=[float(v.detach())for v in (loss,absolute,pair,flat,norm)]
            stream.write(json.dumps({"step":step,"samples":[r[1]for r in records],"scores":score})+"\n")
            stream.flush()
            if step%50==0 or step==end:
                print(step,round(time.monotonic()-started,2),score,flush=True)
            if step%300==0 or step==end:
                checkpoints.append(save_checkpoint(folder,step,heads,ema,optimizer,reference(path)))
    assert model_hash(parent)==witness
    state=torch.load(checked(checkpoints[-1]),weights_only=True,map_location="cpu")
    assert state["step"]==end and all(torch.isfinite(p).all()for v in state["weights"].values()for p in v["ema"].values())
    write_json(folder/"complete.json",{
        "plan":reference(path),"head_checkpoint":checkpoints[-1],"milestones":checkpoints,
        "parent":plan["models"]["Corpus 100k"],"parent_hash_unchanged":witness,
        "measured_train_seconds":time.monotonic()-started,"updates":end,"distinct_photos":end*PER_UPDATE,
        "examples_per_head":end*PER_UPDATE*3,"observations":reference(folder/"observations.jsonl"),
        "qualification_only":qualification,
    })

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("plan","qualify","train"))
    action=p.parse_args().action
    freeze() if action=="plan" else run(action=="qualify")
