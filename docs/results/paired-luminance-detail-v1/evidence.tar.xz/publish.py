"""Preserve the training closure and the actual native comparisons."""
from collections import Counter
import json
from pathlib import Path
import shutil

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
NAME="paired-luminance-detail-v1"
OUT=REPO/"docs/results"/NAME
IMAGES=REPO/"docs/images"/NAME

def relative(path):
    return reference(path)|{"path":str(path.relative_to(REPO))}

def view(data,description):
    source=checked(data["image"])
    destination=IMAGES/source.name
    shutil.copyfile(source,destination)
    copied=relative(destination)
    assert copied["sha256"]==data["image"]["sha256"]
    with Image.open(destination) as image:
        for panel in data["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
        image.verify()
    return data|{"image":copied,"actual_native_viewing":description}

def train_audit():
    run=HERE/"training/complete.json"
    receipt=read_json(run)
    plan=read_json(checked(receipt["plan"]))
    rows=[json.loads(row)for row in checked(receipt["observations"]).read_text().splitlines()]
    assert [item["step"]for item in rows]==list(range(1,1201))
    order=[sample for record in rows for sample in record["samples"]]
    actual=Counter(sample["coupling"]for sample in order)
    schedule=read_json(checked(plan["source_schedule"]))["rows"]
    assert [s["id"]for s in order]==[s["id"]for s in schedule]
    assert len({s["id"]for s in order})==2400 and len(order)*3==receipt["examples_per_head"]
    for observed,declared in zip(order,schedule,strict=True):
        assert observed["cache_sha256"]==declared["cache_sha256"]
    write_json(OUT/"training-execution.json",{
        "training":reference(run),"source_schedule_verified":True,
        "counts":dict(actual),"four_CFAs":dict(Counter(row["pattern"]for row in order)),
        "steps":receipt["updates"],"photos":len(order),"examples_per_head":receipt["examples_per_head"],
        "EMA_component":receipt["head_checkpoint"],"parent":receipt["parent"],
        "train_seconds":receipt["measured_train_seconds"],
    })
    shutil.copyfile(run,OUT/"training.json")

def main():
    OUT.mkdir(exist_ok=True)
    IMAGES.mkdir(exist_ok=True)
    train_audit()
    notes=read_json(HERE/"viewing-notes.json")
    final=HERE/"endpoint-analysis.json"
    review=read_json(final)
    run=read_json(HERE/"endpoint/complete.json")
    cameras=[view(r,notes["standing"][r["id"]])for r in review["standing"]]
    examples=[]
    for row in review["photos"]:
        description=notes["photos"][row["id"]]
        examples.append(row|{k:view(row[k],description)for k in ("board","triplet")})
    assert len(cameras)==8 and len(examples)==3
    write_json(OUT/"native-viewing.json",{
        "viewed_native_camera_crops":len(cameras),"viewed_photo_comparisons":len(examples),
        "viewed_exact_triplets":len(examples),"analysis":reference(final),"standing":cameras,
        "photos":examples,"checkpoints":read_json(checked(run["plan"])),
        "reference_scope":"The independent ISO100 AHD and both cab JPEGs are qualitative references.",
    })
    full=read_json(HERE/"endpoint/short-guard/results.json")
    write_json(OUT/"summary.json",{"scope":"64 exact-target photos, 256 groups, both priors and draws",
        "pooled":full["pooled"],"source_intervals":review["paired_results"],
        "active_gate_fraction_per_role":review["active_gate_fraction_per_role"],
        "measured_inference_scoring_seconds":run["seconds"],
    })
    for name,dest in (
        ("local-support-coverage.json","local-support-coverage.json"),
        ("endpoint/repeat-decomposition.json","repeat-decomposition.json"),
    ):
        shutil.copyfile(HERE/name,OUT/dest)

if __name__=="__main__":
    main()
