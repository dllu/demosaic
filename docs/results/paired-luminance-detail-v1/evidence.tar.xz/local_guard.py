"""Measure the contribution of shorter overlapping green-phase support."""
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.cfa import PATTERNS,color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.noise import coupled_sensor_noise
from raw_support import support_score,weights

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"scene-local-contrast-2400-v1"
CORE=np.s_[...,80:176,80:176]
INSET=np.s_[...,112:144,112:144]
NOISE=(("iso400",8e-5,2.56e-8),("iso6400",.00128,6.5536e-6))

def local_score(packed, variance, colors, pooling):
    count,_,height,width=packed.shape
    phase_ids=torch.argsort((colors!=1).to(torch.int64),dim=1,stable=True)[:,:2]
    gather=phase_ids[:,:,None,None].expand(count,2,height,width)
    greens=packed.gather(1,gather).reshape(count*2,1,height,width)
    variances=variance.gather(1,gather)
    yy,xx=torch.meshgrid(torch.arange(height,device=packed.device,dtype=packed.dtype),
                         torch.arange(width,device=packed.device,dtype=packed.dtype),indexing="ij")
    xx=(xx+.5)*2/width-1
    yy=(yy+.5)*2/height-1
    offset=torch.stack(((.5-phase_ids%2)/width,(.5-phase_ids//2)/height),dim=-1)
    grid=torch.stack((xx,yy),-1)[None]+offset.reshape(-1,1,1,2)
    aligned=F.grid_sample(greens,grid,padding_mode="border",align_corners=False)
    aligned=aligned.reshape(count,2,height,width)

    def pool(field,size):
        return F.avg_pool2d(field,size,stride=1,padding=size//2,count_include_pad=False)

    wave=(pool(aligned,3)-pool(aligned,9))/pool(variances,9).clamp_min(1e-10).sqrt()
    product=wave[:,0:1]*wave[:,1:2]
    return F.interpolate(pool(product,pooling),scale_factor=2,mode="bilinear",align_corners=False)

def calibrate():
    seed=15263276
    generator=torch.Generator().manual_seed(seed)
    held=[]
    for _,shot,read in NOISE:
        n=64
        levels=torch.logspace(-2.7,-.27,n)
        clean=levels[:,None,None,None].expand(n,4,128,128).contiguous()
        colors=torch.stack([color_indices(tuple(PATTERNS)[i%4])for i in range(n)])
        actual,_=coupled_sensor_noise(clean,clean,shot,read,black_level=.03,generator=generator)
        variance=shot*actual.clamp_min(0)+read
        torch.testing.assert_close(local_score(actual,variance,colors,21),
                                   support_score(actual,variance,colors),atol=5e-7,rtol=1e-4)
        held.append(local_score(actual,variance,colors,9)[...,48:208,48:208].flatten().numpy())
    return float(np.quantile(np.concatenate(held),.995)),seed

def paired_gates(packed,variance,colors,threshold,long_threshold):
    whole=weights(packed,variance,colors,long_threshold)
    short=((local_score(packed,variance,colors,9)-threshold)/threshold).clamp(0,1)
    shared=torch.minimum(short,whole)
    return whole,shared

def coverage():
    torch.set_num_threads(2)
    before=ROOT/"support-calibration.json"
    existing=read_json(before)["threshold_0_to_1"][0]
    threshold,seed=calibrate()
    write_json(ROOT/"local-support-calibration.json",{
        "source":reference(__file__),"existing":reference(before),"threshold":threshold,
        "seed":seed,"window_native":18,"primary_window_native":42,"exact_flat_fields":128,
        "scope":"Intersection takes the minimum of the existing 42-native-pixel and new 18-native-pixel pooling weights. Both windows follow the same CFA-specific alignment and bandpass. Short thresholds use independently simulated exact flats.",
    })
    emitted=ROOT/"local-support-coverage.json"
    records=[]
    groups=defaultdict(list)
    for file in sorted((PRIOR/"observations").glob("*.json")):
        row=read_json(file)
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            raw,var,colors=[torch.from_numpy(f[k])for k in ("packed","variance","colors")]
        wide,local=paired_gates(raw,var,colors[None].expand(3,-1),threshold,existing)
        metrics={}
        for label,gate in (("wide",wide),("intersection",local)):
            selected=gate[CORE]
            center=gate[INSET]
            work=[(selected>0).float().mean((1,2,3)).tolist(),
                  selected.mean((1,2,3)).tolist(),(center>0).float().mean((1,2,3)).tolist()]
            metrics[label]=work
            groups[row["profile"]["name"],row["draw"],label].append(work)
        records.append({"case":reference(file),"metrics":metrics})
    assert len(records)==256
    summary={}
    for (prior,draw,key),items in groups.items():
        summary.setdefault(prior,{}).setdefault(draw,{})[key]=np.mean(items,axis=0).tolist()
    write_json(emitted,{"driver":reference(__file__),"metrics":["active96","mean_weight96","active32"],
        "role_order":["present","masked","exact flat"],"summary":summary,"records":records})

if __name__=="__main__":
    coverage()
