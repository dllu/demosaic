"""Score fixed correction amplitudes with identical local support and raw inputs."""
from pathlib import Path
import sys

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(PRIOR))
from measure import BANDS,LUMA,coeffs

POLICIES=("paired","guarded-paired","intersection-paired","scaled-wide-paired")
LEVELS=np.array([0.,.25,.5,.75,1.])
RMS_SCALE=65535/np.sqrt(36*256)

def phase_coeffs(values,fields,roi):
    y=np.einsum("c,bchw->bhw",LUMA,linear_rgb(values,fields))
    return coeffs(y,roi)[...,BANDS["fine"]]

def run(stage):
    raw=ROOT/stage/"short-guard/results.json"
    report=read_json(raw)
    panel=read_json(PRIOR/"evaluation-plan.json")
    records=[]
    for row in report["rows"]:
        previous=read_json(checked(row["original"]))
        case=read_json(checked(previous["case"]))
        with np.load(checked(case["input"]),allow_pickle=False) as data:
            target=data["target"]
            fields={k:np.broadcast_to(data[k][None],(3,*data[k].shape))for k in ("wb","matrix")}
        with np.load(checked(previous["saved"]),allow_pickle=False)as stored:
            parent=stored["100k"]
        with np.load(checked(row["saved"]),allow_pickle=False) as stored:
            matrices={k:stored[k]for k in POLICIES[:2]}
        with np.load(checked(row["guarded_output"]),allow_pickle=False)as stored:
            matrices.update({k:stored[k]for k in POLICIES[2:]})
        roi=panel["score_ROI_xywh"]
        base=phase_coeffs(parent,fields,roi)
        truth=phase_coeffs(target,fields,roi)
        assert np.max(np.abs(truth[2]))<1e-14
        exact=truth[0]-truth[1]
        evaluations={}
        for method,value in matrices.items():
            proposed=phase_coeffs(value,fields,roi)
            correction=proposed-base
            vary=base[None]+LEVELS[:,None,None,None]*correction[None]
            incremental=vary[:,0]-vary[:,1]
            evaluations[method]={
                "increment_RMS_DN16":(RMS_SCALE*np.sqrt(np.sum((incremental-exact)**2,axis=(1,2)))).tolist(),
                "flat_RMS_DN16":(RMS_SCALE*np.sqrt(np.sum(vary[:,2]**2,axis=(1,2)))).tolist(),
                "aligned_dot":np.sum(incremental*exact,axis=(1,2)).tolist(),
                "GT_power":float(np.sum(exact**2)),
            }
        records.append({"source":row["source"],"profile":row["profile"],"draw":row["draw"],"metrics":evaluations})
    summary={}
    for profile in ("iso400","iso6400"):
        summary[profile]={}
        for draw in ("coupled","independent"):
            rows=[v for v in records if (v["profile"],v["draw"])==(profile,draw)]
            assert len(rows) in (8,64)
            table={}
            for key in POLICIES:
                source=[r["metrics"][key]for r in rows]
                table[key]={metric:np.mean([p[metric]for p in source],axis=0).tolist()
                             for metric in ("increment_RMS_DN16","flat_RMS_DN16")}
                table[key]["pooled_fine_response"]=(
                    np.sum([p["aligned_dot"]for p in source],axis=0)/sum(p["GT_power"]for p in source)
                ).tolist()
            summary[profile][draw]=table
    write_json(ROOT/stage/"gain-curve.json",{"driver":reference(__file__),"review":reference(raw),
        "scope":"Fixed scalar amplitudes. Linearity of rendered linear RGB and DCT is used before display clipping. No clean target enters the correction scaling.",
        "gain_levels":LEVELS.tolist(),"curve":summary,"source_metrics":records})

if __name__=="__main__":
    import argparse

    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage",choices=("milestone","endpoint"))
    run(parser.parse_args().stage)
