"""Exact-geometry FP16 prototype keeping RAW tiles and FP32 blending on CUDA."""
from contextlib import contextmanager
import time

import numpy as np
import torch

from demosaic.cfa import pack
from demosaic.inference import positions
from demosaic.precision import amp_context


def cuda_graph(forward, sample):
    device = sample.device
    stream = torch.cuda.Stream(device)
    static = sample.clone()
    stream.wait_stream(torch.cuda.current_stream(device))
    with torch.cuda.stream(stream):
        for _ in range(2):
            forward(static)
    torch.cuda.current_stream(device).wait_stream(stream)
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph, stream=stream):
        output = forward(static)

    def replay(value):
        static.copy_(value)
        graph.replay()
        return output

    return replay


@torch.inference_mode()
def restore_device(model, raw, colors, *, shot, read, wb, matrix, graph=False,
                   tile=512, overlap=64, batch_size=4, device="cuda", precision="float16"):
    began = time.perf_counter()
    torch.cuda.synchronize(device)
    torch.cuda.reset_peak_memory_stats(device)
    raw = torch.as_tensor(raw, dtype=torch.float32, device="cpu")
    if raw.ndim != 2 or min(raw.shape) < 2 or not np.isfinite(raw.numpy()).all():
        raise ValueError("Raw must be a finite H×W normalized mosaic")
    original_h, original_w = raw.shape
    h = max(tile, (original_h + 1) // 2 * 2)
    w = max(tile, (original_w + 1) // 2 * 2)
    if (h, w) != raw.shape:
        rows, cols = torch.arange(h), torch.arange(w)
        rows = torch.where(rows < original_h, rows, 2 * ((original_h - 2) // 2) + rows % 2)
        cols = torch.where(cols < original_w, cols, 2 * ((original_w - 2) // 2) + cols % 2)
        raw = raw.index_select(0, rows).index_select(1, cols)
    raw = raw.pin_memory().to(device, non_blocking=True)
    edge = torch.hann_window(tile, periodic=False).clamp_min(0.02)
    weight = (edge[:, None] * edge[None, :]).to(device)
    accum = torch.zeros(3, h, w, device=device)
    norm = torch.zeros(h, w, device=device)
    colors = torch.as_tensor(colors, device=device, dtype=torch.long).reshape(1, -1)
    wb = None if wb is None else torch.as_tensor(wb, device=device, dtype=torch.float32).reshape(1, 3)
    matrix = (None if matrix is None else torch.as_tensor(matrix, device=device,
              dtype=torch.float32).reshape(1, 3, 3))
    coords = [(y, x) for y in positions(h, tile, tile - overlap)
             for x in positions(w, tile, tile - overlap)]
    model.eval().to(memory_format=torch.channels_last)
    model.set_noise(shot, read)

    def forward(batch):
        packed = pack(batch[:, None]).contiguous(memory_format=torch.channels_last)
        variance = packed.clamp_min(0) * shot + read
        count = len(batch)
        with amp_context(device, dtype=precision):
            return model(packed, variance, colors.expand(count, -1),
                         None if wb is None else wb.expand(count, -1),
                         None if matrix is None else matrix.expand(count, -1, -1))

    torch.cuda.synchronize(device)
    setup_seconds = time.perf_counter() - began
    dispatchers = {}
    capture_seconds = 0.0
    for start in range(0, len(coords), batch_size):
        current = coords[start:start + batch_size]
        batch = torch.stack([raw[y:y+tile, x:x+tile] for y, x in current])
        if graph and len(current) not in dispatchers:
            t0 = time.perf_counter()
            dispatchers[len(current)] = cuda_graph(forward, batch)
            torch.cuda.synchronize(device)
            capture_seconds += time.perf_counter() - t0
        outputs = dispatchers.get(len(current), forward)(batch).float()
        for output, (y, x) in zip(outputs, current, strict=True):
            accum[:, y:y+tile, x:x+tile].add_(output * weight)
            norm[y:y+tile, x:x+tile].add_(weight)
    accum.div_(norm.clamp_min_(1e-12))
    torch.cuda.synchronize(device)
    t0 = time.perf_counter()
    result = accum[:, :original_h, :original_w].cpu()
    return result, {"seconds": time.perf_counter() - began,
                    "graph_capture_seconds": capture_seconds,
                    "setup_seconds": setup_seconds,
                    "final_download_seconds": time.perf_counter() - t0,
                    "peak_cuda_gb": torch.cuda.max_memory_allocated(device) / 1e9,
                    "tiles": len(coords)}

@contextmanager
def cached_cfa():
    from demosaic import pretrained_rgb
    from cfa_cached import bilinear, malvar

    old = pretrained_rgb.bilinear, pretrained_rgb.malvar
    pretrained_rgb.bilinear, pretrained_rgb.malvar = bilinear, malvar
    try:
        yield
    finally:
        pretrained_rgb.bilinear, pretrained_rgb.malvar = old
