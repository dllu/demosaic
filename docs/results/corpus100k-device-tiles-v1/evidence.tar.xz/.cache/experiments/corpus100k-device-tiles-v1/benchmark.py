"""Measure steady full-frame RAW restore and exact TIFF parity."""
from contextlib import nullcontext
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
for name in ("corpus100k-fp16-throughput-v1", "corpus100k-mixed-precision-v1"):
    sys.path.append(str(ROOT.with_name(name)))

from device_tiles import cached_cfa, restore_device
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.inference import load_checkpoint, restore_tiled
from demosaic.io import read_raw, write_rgb16
from full_production import gpu_jobs
from full_throughput import exported_differences
from screen import PRIMARY, MODEL, SHOT, READ, versions

F = "configs/gfx-qualitative-20231231.json"
POLICIES = ("control", "device", "cached", "graph")
SETTINGS = dict(tile=512, overlap=64, batch_size=4, device="cuda", precision="float16")


def restore(mode, model, raw, colors, **args):
    if mode == "control":
        return restore_tiled(model, raw, colors, **args)
    with cached_cfa() if mode in ("graph", "cached", "cached-control") else nullcontext():
        if mode == "cached-control":
            return restore_tiled(model, raw, colors, **args)
        return restore_device(model, raw, colors, graph=mode == "graph", **args)


@torch.inference_mode()
def main(stage):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(
        min(1, 16 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    binding = read_json(PRIMARY)["models"][MODEL]["checkpoint"]
    fixture = read_json(F)
    raw_input = reference(fixture["noisy"])
    t0 = time.perf_counter()
    raw, meta = read_raw(raw_input["path"])
    t1 = time.perf_counter()
    model, state = load_checkpoint(binding["path"], "cuda", tiled_inference=True)
    t2 = time.perf_counter()
    assert binding["sha256"] == state["loaded_sha256"] and state["step"] == 100000 and "ema" in state
    assert meta.flip == 0
    colors = color_indices(meta.pattern)
    args = dict(SETTINGS, shot=SHOT, read=READ, wb=meta.white_balance, matrix=meta.camera_to_srgb)
    if stage == "screen":
        visible = raw[1000:1953, 5000:8201]
        expected, _ = restore("control", model, visible, colors, **args)
        rows = []
        for n in range(3):
            for mode in POLICIES if n % 2 == 0 else POLICIES[::-1]:
                prediction, stats = restore(mode, model, visible, colors, **args)
                delta = (prediction - expected).double() * 65535
                seed = {"mode":mode, "stats":stats, "shape":list(visible.shape),
                        "RMS_DN16":float(delta.square().mean().sqrt()),
                        "max_DN16":float(delta.abs().max()),
                        "bit_exact":torch.equal(prediction, expected)}
                rows.append(seed)
                print(seed, flush=True)
        write_json(ROOT/"screen.json", {"rows":rows, "settings":SETTINGS, "checkpoint":binding,
                   "source":raw_input,"driver":reference(__file__), "implementation":reference(ROOT/"device_tiles.py")})
        return
    schedule = tuple(stage.split(","))
    runs = []
    for index, mode in enumerate(schedule):
        t0_run = time.perf_counter()
        prediction, stats = restore(mode, model, raw, colors, **args)
        t1_run = time.perf_counter()
        crops = ROOT / f"{index}-{mode}-native.npz"
        np.savez_compressed(crops, **{
            reg["name"]: prediction[:, y:y+160, x:x+160].numpy()
            for reg in fixture["regions"] for x, y in [reg["noisy_xy"]]
        })
        output = ROOT / f"{index}-{mode}.tiff"
        t0_writer = time.perf_counter()
        write_rgb16(output, prediction.permute(1,2,0).numpy(), metadata=meta, flip=meta.flip)
        t1_writer = time.perf_counter()
        del prediction
        row = {"mode":mode,"index":index,"stats":stats,"restore_wall_seconds":t1_run-t0_run,
               "writer_seconds":t1_writer-t0_writer,"RGB16":reference(output),
               "crops":reference(crops),"gpu_jobs":gpu_jobs()}
        runs.append(row)
        print(index,mode,stats,t1_writer-t0_writer,flush=True)
        write_json(ROOT/"full-progress.json", {"runs":runs}, replace=True)
    comparison_geometry = {"tile":SETTINGS["tile"], "overlap":SETTINGS["overlap"]}
    reference_run = runs[0]
    for entry in runs[1:]:
        entry["difference"] = exported_differences(reference_run["RGB16"]["path"],
                                                  entry["RGB16"]["path"], comparison_geometry)
        print(entry["index"],entry["mode"],entry["difference"],flush=True)
    write_json(ROOT/"full.json", {"fixture":reference(F),"checkpoint":binding,"source":raw_input,
              "driver":reference(__file__), "implementation":reference(ROOT/"device_tiles.py"),
              "decode_seconds":t1-t0, "checkpoint_setup_seconds":t2-t1,
              "versions":versions(),"settings":SETTINGS,"noise":{"shot":SHOT,"read":READ},"runs":runs})


if __name__ == "__main__":
    main(sys.argv[1])
