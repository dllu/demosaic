"""Compare FP16 cuDNN engine selection from fresh process caches."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT.with_name("corpus100k-fp16-throughput-v1")))

from screen_throughput import bound_model, prepare, gpu_jobs, versions, SHOT, READ
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.precision import amp_context


@torch.inference_mode()
def main(key, limit):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(
        min(1, 16 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    model, checkpoint = bound_model()
    model.set_noise(SHOT, READ)
    config = read_json("configs/gfx-qualitative-20231231.json")
    source = reference(config["noisy"])
    raw, meta = read_raw(source["path"])
    inputs = prepare(raw, meta, config, 512, 4)
    del raw
    torch.cuda.synchronize()
    torch.backends.cudnn.benchmark_limit = limit
    torch.backends.cudnn.benchmark = limit > 0

    rows = []
    reference_path = ROOT / "autotune-reference.npy"
    for i in range(11):
        start = time.perf_counter()
        with amp_context("cuda", dtype="float16"):
            output = model(*inputs)
        torch.cuda.synchronize()
        rows.append(time.perf_counter() - start)
        print(key, limit, i, rows[-1], flush=True)
    actual = output.cpu().numpy()
    if not reference_path.exists():
        np.save(reference_path, actual)
    delta = (actual.astype(np.float64) - np.load(reference_path)) * 65535
    write_json(ROOT / f"autotune-{key}.json",
               {"benchmark_limit":limit, "times":rows, "checkpoint":checkpoint,
                "source":source, "positions":[[x-176,y-176,512,512]
                 for x,y in (r["noisy_xy"] for r in config["regions"])],
                "profile":{"shot":SHOT,"read":READ}, "driver":reference(__file__),
                "versions":versions(), "other_cuda_clients":gpu_jobs(),
                "reference":reference(reference_path),
                "RMS_DN16":float(np.sqrt((delta**2).mean())), "max_DN16":float(abs(delta).max())})


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]))
