"""Re-render fixed native comparisons for the FP16 tile transport trials."""
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("corpus100k-fp16-throughput-v1")
sys.path.extend([str(PREVIOUS), str(ROOT.with_name("corpus100k-mixed-precision-v1"))])

from benchmark import SETTINGS, restore
from review_throughput import (OLD, board_panels, display_sensor, native_png, native_board,
    noisy_malvar, observe_scene, photometry, sample_scene_recipe, unpack)
from screen_throughput import bound_model
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

LABELS = {"control":"Eager FP16","device":"Device FP16","cached":"Device FP16 cached",
          "cached-control":"Eager FP16 cached","graph":"Graph FP16"}


def delta(out, anchor):
    assert np.isfinite(out).all()
    d = (out.astype(np.float64) - anchor) * 65535
    return {"RMS_DN16":float((d*d).mean()**.5),"max_DN16":float(np.abs(d).max()),
            "float32_equal":bool(np.array_equal(out,anchor))}


def choices(values, baseline="control"):
    return {mode:delta(image, values[baseline]) for mode,image in values.items() if mode!=baseline}


def qualities(results, model, arms):
    rows = []
    sources = reference(PREVIOUS/"overlap.json")
    for index, case in enumerate(read_json(checked(sources))["rows"]):
        provenance = case["provenance"]
        x,y,w,h = provenance["cache_box_xywh"]
        src = np.load(checked(provenance["source"]), mmap_mode="r", allow_pickle=False)
        clean = torch.from_numpy(src[y:y+h,x:x+w].astype(np.float32)).permute(2,0,1)/65535
        params = provenance["recipe"]
        recipe = replace(sample_scene_recipe(0), **params)
        obs = observe_scene(clean, recipe)
        raw = unpack(obs.packed[None])[0,0]
        sup = {k:getattr(obs,k)[None].numpy() for k in ("target","packed","colors","wb","matrix")}
        args = dict(SETTINGS, shot=recipe.shot, read=recipe.read, wb=obs.wb, matrix=obs.matrix)
        values = {arm:restore(arm, model, raw, obs.colors, **args)[0].numpy() for arm in arms}
        scores = {arm:float(photometry(rgb[None],sup)["srgb_psnr"][0]) for arm,rgb in values.items()}
        board = None
        if index < 2:
            roi = (680,480,160,160) if w == 1536 else (480,680,160,160)
            board = native_board(ROOT,("pinakothek","highlight")[index],
                [noisy_malvar(sup)[0],*values.values(),sup["target"][0]],sup,
                {**provenance,"checkpoint":results["checkpoint"]},
                labels=("Noisy Malvar",*(LABELS[a] for a in arms),"Exact GT"),
                triplet_indices=(0, len(arms), len(arms)+1),
                exposure=provenance["display_exposure"], roi=roi)
        row = {"provenance":provenance,"scores_dB":scores,"deltas":choices(values),"board":board}
        rows.append(row)
        print(provenance["photo"]["title"], scores, row["deltas"], flush=True)
    return {"source_plan":sources,"rows":rows}


def render_main(results, meta, arms):
    reference_boards = {r["id"]:r for r in read_json(OLD/"manifest.json")["main_views"]}
    wb, matrix = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    rows = []
    for region in read_json(checked(results["fixture"]))["regions"]:
        name = region["name"]
        ref = reference_boards[name]["board"]
        image = reference(OLD/Path(ref["image"]["path"]).name)
        assert image["sha256"]==ref["image"]["sha256"]
        observed = board_panels(checked(image),ref["panels"])
        values = {}
        for mode in arms:
            run = next(value for value in results["runs"] if value["mode"]==mode)
            with np.load(checked(run["crops"]),allow_pickle=False) as data:
                values[mode] = data[name]
        exposure = 4
        ordered = [(k,v) for k,v in observed.items() if "Noisy" in k]
        ordered.extend((LABELS[mode],display_sensor(torch.from_numpy(rgb),wb,matrix,(0,0,160,160),exposure))
                       for mode,rgb in values.items())
        ordered.extend((k,v) for k,v in observed.items() if "ISO100" in k)
        rows.append({"id":name,"board":native_png(ROOT/f"{name}.png",ordered),
                     "xywh":[*region["noisy_xy"],160,160],"display_exposure":exposure,
                     "comparison":choices(values), "reference_board":image})
    return rows


def render_cab(model, arms):
    source_manifest = Path("docs/images/full-corpus-long100k-native-v1/manifest.json")
    rows = []
    for item in read_json(source_manifest)["images"]:
        if not item["id"].startswith("mesh-") or item["role"]!="board":
            continue
        provenance = item["provenance"]
        with np.load(checked(provenance["input_arrays"]),allow_pickle=False) as data:
            raw = unpack(torch.from_numpy(data["packed"]))[0,0]
            colors = data["colors"][0]
            wb, matrix = torch.from_numpy(data["wb"]), torch.from_numpy(data["matrix"])
        x,y,w,h = provenance["ROI_xywh"]
        args = dict(SETTINGS, wb=wb, matrix=matrix,
                    shot=provenance["noise"]["shot"], read=provenance["noise"]["read"])
        views = {arm:restore(arm,model,raw,colors,**args)[0][:,y:y+h,x:x+w] for arm in arms}
        observed = board_panels(checked(item["image"]),provenance["panels"])
        ordered = [("Noisy Malvar",observed["Noisy Malvar"])]
        ordered.extend((LABELS[arm],display_sensor(img,wb,matrix,(0,0,w,h),provenance["display_exposure"]))
                       for arm,img in views.items())
        refs = ("ISO100 ref, not GT","SOOC ISO6400 JPEG","SOOC ISO100 JPEG")
        ordered.extend((k,observed[k]) for k in refs)
        rows.append({"id":item["id"],"board":native_png(ROOT/f'{item["id"]}.png',ordered),
                     "provenance":provenance,"comparison":choices({k:v.numpy() for k,v in views.items()})})
        print(item["id"], rows[-1]["comparison"], flush=True)
    assert len(rows)==4
    return rows


@torch.inference_mode()
def main(modes):
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1,16*2**30/torch.cuda.get_device_properties(0).total_memory))
    # The timing loop saves source-bound crop arrays before computing TIFF histograms.
    data = reference(ROOT/"full-progress.json")
    results = read_json(checked(data))
    results["fixture"] = reference("configs/gfx-qualitative-20231231.json")
    _,meta = read_raw(read_json(checked(results["fixture"]))["noisy"])
    model, results["checkpoint"] = bound_model()
    arms = tuple(modes.split(","))
    assert arms[0] == "control"
    main_views = render_main(results,meta,arms)
    cab = render_cab(model,arms)
    exact = qualities(results,model,arms)
    write_json(ROOT/"quality.json",{"driver":reference(__file__),"timing_progress":data,"arms":arms,
               "checkpoint":results["checkpoint"],"main":main_views,"cab":cab,"exact":exact})


if __name__ == "__main__":
    main(sys.argv[1])
