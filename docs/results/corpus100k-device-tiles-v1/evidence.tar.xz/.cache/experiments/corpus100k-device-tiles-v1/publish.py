"""Bind receipts and native pixels for the FP16 tile transport benchmark."""
import hashlib
import json
from pathlib import Path
import shutil
from statistics import median
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


ROOT = Path(__file__).resolve().parent
SLUG = ROOT.name
IMAGES = Path("docs/images") / SLUG
RESULTS = Path("docs/results") / SLUG
PREVIOUS = ROOT.with_name("corpus100k-fp16-throughput-v1")
DIRECT_DEPENDENCIES = (
    PREVIOUS / "full_throughput.py",
    PREVIOUS / "screen_throughput.py",
    PREVIOUS / "review_throughput.py",
    PREVIOUS / "review_overlap.py",
    PREVIOUS / "overlap.json",
    ROOT.with_name("corpus100k-mixed-precision-v1") / "screen.py",
    ROOT.with_name("corpus100k-mixed-precision-v1") / "full_production.py",
    ROOT.with_name("paired-luminance-detail-v1") / "render.py",
    Path("src/demosaic/inference.py"),
    Path("src/demosaic/cfa.py"),
    Path("src/demosaic/pretrained_rgb.py"),
    Path("scripts/report_scene_wave_guides.py"),
)


def copy_board(data):
    if "image" in data:
        copy_image(data)
    for field in ("board", "triplet"):
        if field in data:
            copy_image(data[field])


def copy_image(data):
    original = checked(data["image"])
    output = IMAGES / original.name
    shutil.copy2(original,output)
    assert reference(output)["sha256"] == data["image"]["sha256"]
    data["image"]["path"] = str(output)
    with Image.open(output) as opened:
        pixels = np.asarray(opened.convert("RGB"))
    panels = data["panels"]
    for panel in panels:
        x,y,w,h = panel["png_xywh"]
        assert pixels[y:y+h,x:x+w].shape == (160,160,3) == (h,w,3)


def run():
    IMAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    quality_receipt = reference(ROOT/"quality.json")
    quality = read_json(checked(quality_receipt))
    full_receipt = reference(ROOT/"full.json")
    full = read_json(checked(full_receipt))
    assert full["checkpoint"]==quality["checkpoint"]
    assert all(row["stats"]["tiles"]==520 for row in full["runs"])
    assert len({row["RGB16"]["sha256"] for row in full["runs"]}) == 1
    for row in full["runs"][1:]:
        assert row["difference"]["channels"] == 305987556
        assert row["difference"]["fraction_exact"] == 1
    for row in quality["main"]+quality["cab"]:
        assert all(out["float32_equal"] for out in row["comparison"].values())
    for row in quality["exact"]["rows"]:
        assert all(out["float32_equal"] for out in row["deltas"].values())

    assert checked(quality["timing_progress"])==ROOT/"full-progress.json"
    for row, trial in zip(full["runs"], read_json(checked(quality["timing_progress"]))["runs"], strict=True):
        assert row["crops"]==trial["crops"] and row["mode"]==trial["mode"]
        assert checked(row["crops"]).is_file()
    for row in quality["main"]+quality["cab"]:
        copy_board(row["board"])
    for row in quality["exact"]["rows"]:
        if row["board"]:
            copy_board(row["board"])
    manifest = IMAGES/"manifest.json"
    write_json(manifest, quality, replace=True)

    timings = {}
    for name in {row["mode"] for row in full["runs"]}:
        values = [r["restore_wall_seconds"] for r in full["runs"] if r["mode"]==name]
        timings[name] = {"seconds":values, "median_seconds":median(values)}
    tests = [reference(ROOT/f"autotune-{mode}.json") for mode in ("first","tune","final")]
    for test in tests:
        assert read_json(checked(test))["checkpoint"]==full["checkpoint"]
    archive = RESULTS/"evidence.tar.xz"
    sources = (
        ROOT/"device_tiles.py", ROOT/"cfa_cached.py", ROOT/"benchmark.py", ROOT/"native.py",
        ROOT/"autotune.py", ROOT/"publish.py", ROOT/"autotune.log", ROOT/"screen.log",
        ROOT/"graph-uncached.log", ROOT/"full.log", ROOT/"native.log", ROOT/"screen.json",
        ROOT/"full-progress.json", ROOT/"full.json", ROOT/"quality.json",
        ROOT/"autotune-first.json", ROOT/"autotune-tune.json", ROOT/"autotune-final.json", ROOT/"test-collection.log", ROOT/"tests.log",
        ROOT/"visual-review.json", ROOT/"tail_batches.py", ROOT/"tail-batches.json", ROOT/"tail-batches.log",
    )
    repo = Path.cwd()
    with tarfile.open(archive, "w:xz", preset=6) as out:
        for path in (*sources, *DIRECT_DEPENDENCIES):
            out.add(path, arcname=str(path.resolve().relative_to(repo)))
    with tarfile.open(archive, "r:xz") as out:
        for path in (*sources, *DIRECT_DEPENDENCIES):
            member = str(path.resolve().relative_to(repo))
            assert hashlib.file_digest(out.extractfile(member),"sha256").hexdigest()==reference(path)["sha256"]
    publication = {"scope":"Inference-only comparison of the same Corpus 100k EMA and FP16 geometry. "
                            "Fresh-process cuDNN algorithm search is a separate B4 screen.",
                   "checkpoint":full["checkpoint"], "archived":reference(archive),
                   "native_manifest":reference(manifest), "full":full, "full_receipt":full_receipt,
                   "timing_summary":timings,"native_receipt":quality_receipt,
                   "screen":reference(ROOT/"screen.json"), "fresh_autotune":tests,
                   "native_review":reference(ROOT/"visual-review.json"),
                   "tail_batches":reference(ROOT/"tail-batches.json"), "test_log":reference(ROOT/"tests.log"),
                   "frozen_dependencies":{str(path.resolve().relative_to(repo)):reference(path)["sha256"]
                                          for path in DIRECT_DEPENDENCIES}}
    write_json(RESULTS/"publication.json",publication,replace=True)


if __name__ == "__main__":
    run()
