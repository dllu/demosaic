"""Check partial final CUDA batches on odd-sized native observations."""
from pathlib import Path

import numpy as np
import torch

from benchmark import SETTINGS, restore
from screen_throughput import bound_model, SHOT, READ
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.inference import positions
from demosaic.io import read_raw


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    root = Path(__file__).resolve().parent
    source = reference(read_json("configs/gfx-qualitative-20231231.json")["noisy"])
    raw, meta = read_raw(source["path"])
    model, checkpoint = bound_model()
    colors = color_indices(meta.pattern)
    rows = []
    for height, width in ((511, 1901), (949, 1901), (511, 2801)):
        x,y=5000,1000
        observed = raw[y:y+height,x:x+width]
        args = dict(SETTINGS, shot=SHOT, read=READ, wb=meta.white_balance, matrix=meta.camera_to_srgb)
        maps = {mode:restore(mode,model,observed,colors,**args) for mode in ("control","device","graph")}
        control = maps["control"][0].numpy().view(np.uint32)
        rows.append({"xywh":[x,y,width,height], "stats":{key:v[1] for key,v in maps.items()},
                     "trailing_batch":maps["control"][1]["tiles"] % SETTINGS["batch_size"],
                     "bit_equal":{name:bool(np.array_equal(pair[0].numpy().view(np.uint32),control))
                                  for name,pair in maps.items() if name!="control"}})
        print(rows[-1]["trailing_batch"], rows[-1]["bit_equal"], flush=True)
    assert [row["trailing_batch"] for row in rows] == [1,2,3]
    assert all(all(row["bit_equal"].values()) for row in rows)
    write_json(root/"tail-batches.json", {"rows":rows,"checkpoint":checkpoint,"source":source,
                       "driver":reference(__file__), "noise":{"shot":SHOT,"read":READ}})


if __name__ == "__main__":
    main()
