"""Evaluate the shorter overlap where a long native canvas changes tile origins."""
from dataclasses import asdict, replace

import numpy as np
import torch

from full_throughput import ROOT, bound_model, restore, read_json, reference, write_json
from review_throughput import LABELS, blend_bands, difference, display, exact_cohort, native_board
from review_throughput import noisy_malvar, photometry, observe_scene, sample_scene_recipe, unpack
from screen_throughput import SHOT, READ
from demosaic.inference import positions


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    total=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1, 16*2**30/total))
    bound=reference(ROOT/'full.json')
    full=read_json(bound['path'])
    model, checkpoint=bound_model()
    assert checkpoint==full['checkpoint']
    modes = {k:full['modes'][k] for k in ('control','larger','reduced')}
    candidates = [row for row in exact_cohort() if max(row['shape'][:2])>=1536][:6]
    assert len(candidates)>=4
    conditions = ((.00256,2.62144e-5,1.),(.00008,2.56e-8,4.),(SHOT,READ,.4),
                  (.00008,2.56e-8,1.),(SHOT,READ,1.),(0.,0.,1.))
    rows=[]
    for i,source in enumerate(candidates):
        file=reference(source['cache'])
        assert file['sha256']==source['cache_sha256']
        pixels=np.load(file['path'],mmap_mode='r',allow_pickle=False)
        size=(1152,1536) if pixels.shape[1]>=1536 else (1536,1152)
        h,w=size
        y,x=((length-width)//4*2 for length,width in zip(pixels.shape[:2],size,strict=True))
        clean=torch.from_numpy(pixels[y:y+h,x:x+w].astype(np.float32)).permute(2,0,1)/65535
        shot,read,expo=conditions[i]
        recipe=replace(sample_scene_recipe(20261119092+i),shot=shot,read=read,exposure=expo,black=.03)
        obs=observe_scene(clean,recipe)
        raw=unpack(obs.packed[None])[0,0]
        sup={k:getattr(obs,k)[None].numpy() for k in ('target','packed','colors','wb','matrix')}
        truth=display(sup['target'],sup)
        values={}
        scores={}
        stride={arm:mode['tile']-mode['overlap'] for arm,mode in modes.items()}
        starts={arm:[positions(length,mode['tile'],stride[arm]) for length in size] for arm,mode in modes.items()}
        assert starts['larger']!=starts['reduced']
        seams = blend_bands(h,modes['reduced'])[:,None] | blend_bands(w,modes['reduced'])[None,:]
        for arm,mode in modes.items():
            out=restore(model,raw,obs.colors,shot,read,obs.wb,obs.matrix,mode)[0].numpy()
            values[arm]=out
            err=(display(out[None],sup)-truth)**2
            scores[arm]={'sRGB_PSNR':float(photometry(out[None],sup)['srgb_psnr'][0]),
                         'reduced_blend_band_MSE':float(err[...,seams].mean()),
                         'off_reduced_blend_band_MSE':float(err[...,~seams].mean()),
                         'control_delta':difference(out,values['control'])}
        provenance={'photo':source,'source':file,'cache_box_xywh':[x,y,w,h],'recipe':asdict(recipe),
                    'ADC_bits':16,'display_exposure':min(1.,1/expo),'first_tile_origins_y_x':starts}
        board=None
        if i<2:
            roi=(680,480,160,160) if w==1536 else (480,680,160,160)
            board=native_board(ROOT,('wide-pinakothek','wide-highlight')[i],
                    [noisy_malvar(sup)[0],*values.values(),sup['target'][0]],sup,provenance,
                    labels=('Noisy Malvar',*(LABELS[arm] for arm in modes),'Exact GT'),
                    triplet_indices=(0,3,4),exposure=provenance['display_exposure'],roi=roi)
        rows.append({'provenance':provenance,'scores':scores,'board':board})
        print(i,source['title'],{arm:round(value['sRGB_PSNR'],5) for arm,value in scores.items()},flush=True)
    write_json(ROOT/'overlap.json',{'driver':reference(__file__),'dependency':reference(ROOT/'review_throughput.py'),
      'full':bound,'checkpoint':checkpoint,'modes':modes,'rows':rows})


if __name__=='__main__':
    main()
