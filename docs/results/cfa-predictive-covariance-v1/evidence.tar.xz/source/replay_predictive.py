"""Run signed-color predictive validation on the frozen optical and GFX RAW panels."""

from pathlib import Path
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

import predictive
import replay_relative as previous

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
REPLAY = previous.replay


def standing():
    fixed = reference(REPLAY.FIXED)
    review = read_json(checked(fixed))
    report = []
    for row in review["standing"]:
        inputs = REPLAY.arrays(row["input"])
        scene, colors, wb, matrix = (inputs[k][0] for k in ("packed", "colors", "wb", "matrix"))
        parent = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(row["local_ROI"])
        peaks = _spacing(scene, colors, *roi[:2], clearance=16)
        restored, info = predictive.evaluate(parent, roi, scene, roi, colors, peaks, row["noise"], wb, matrix)
        comparisons = {}
        for k, x in restored.items():
            comparisons[k] = {
                "versus_conditional_DN16": REPLAY.rms(x - restored["conditional"]),
                "versus_color_field_DN16": REPLAY.rms(x - restored["field_sign"]),
            }
        figures = []
        for old in row["displays"]:
            exposure = old["exposure"]
            before = old["board"]
            with Image.open(checked(before["image"])) as png:
                pixels = np.asarray(png)
            panes = {}
            for p in before["panels"]:
                x, y, w, h = p["png_xywh"]
                panes[p["name"]] = pixels[y:y + h, x:x + w]
            images = [(k, panes[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            images += [
                (predictive.LABELS[k], REPLAY.display(restored[k], wb, matrix, exposure))
                for k in ("conditional", "affine", "field_sign", *predictive.ARMS[len(predictive.BASE_ARMS):])
            ]
            images += [
                (k, panes[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in panes
            ]
            image = Image.new("RGB", (8 + 168 * len(images), 192), "#eee")
            draw = ImageDraw.Draw(image)
            panels = []
            for i, (label, values) in enumerate(images):
                x = 8 + i * 168
                assert values.shape == (160, 160, 3)
                image.paste(Image.fromarray(values), (x, 24))
                draw.text((x, 6), label, fill="black")
                panels.append({"label": label, "png_xywh": [x, 24, 160, 160]})
            path = OUT / "standing" / f"{row['id']}-x{exposure:g}.png"
            image.save(path)
            figures.append({"image": reference(path), "panels": panels, "previous": before, "exposure": exposure})
        report.append({
            "id": row["id"], "roi": row["global_ROI"], "noise": row["noise"],
            "input": row["input"], "raw": row["raw"], "parent": row["predictions"]["local50k"],
            "comparisons": comparisons, "details": info, "views": figures,
        })
        print(row["id"], comparisons["predictive_affine_sign"], flush=True)
    return {"input_review": fixed, "rows": report, "weights": review["checkpoints"]}


def replay_panel(tag, source, old=None):
    REPLAY.ARMS = predictive.ARMS
    REPLAY.LABELS = predictive.LABELS
    REPLAY.OUT = OUT
    REPLAY.apply_directional = predictive.evaluate
    original = REPLAY.native_board

    def native(folder, case, images, *args, **kwargs):
        # Show the uncertainty-aware affine arm with the permissive center.
        kwargs["triplet_indices"] = (0, 3 + predictive.ARMS.index("predictive_affine_sign"), len(images) - 1)
        return original(folder, case, images, *args, **kwargs)

    REPLAY.native_board = native
    try:
        rows = REPLAY.photos(source, tag)
    finally:
        REPLAY.native_board = original
    if old is not None:
        for before, after in zip(old, rows, strict=True):
            assert before["id"] == after["id"]
            for a, b in zip(before["draws"], after["draws"], strict=True):
                assert all(a["scores"][k] == b["scores"][k] for k in a["scores"])
    return {"source": source, "rows": rows, "summary": REPLAY.summary(rows)}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    for name in ("exact", "standing"):
        (OUT / name).mkdir(exist_ok=True)
    original = reference(previous.OUT / "result.json")
    old = read_json(checked(original))
    proof = predictive.audit()
    real = standing()
    panels = {}
    for name, case in old["results"].items():
        panels[name] = replay_panel(name, case["source"], case["rows"])
        print(name, len(panels[name]["rows"]), monotonic() - start, flush=True)
    write_json(
        OUT / "result.json",
        {
            "driver": reference(__file__), "operator": reference(predictive.__file__),
            "prior": original, "method_audit": proof, "standing": real, "panels": panels,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
