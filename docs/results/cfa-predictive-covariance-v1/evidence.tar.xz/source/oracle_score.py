"""Measure predictive-score effects with fixed exact guide frequencies and known nulls."""

from pathlib import Path
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import reference, write_json
import predictive_matched as model

OUT = Path("/mnt/external/demosaic/cfa-predictive-covariance-v1")
BASE = model.BASE
DRAWS = 96
FREQUENCIES = {"wire": (0.11, 0.075), "near_lattice_alias": (0.46, 0.042)}
PROFILES = {"iso1600": (0.00032, 4.096e-7), "iso6400": (0.00128, 6.5536e-6)}


def field(rng, freq, ratio):
    y, x = np.indices((64, 64), dtype="d") + 0.5
    lighting = (1 - np.cos(np.pi * x / 64)) / 2
    bg = 0.19 * (ratio + (1 - ratio) * lighting)
    bg = bg[None] + 0.003 * np.cos(np.pi * y[None] / 64)
    beta = rng.uniform(0, 2 * np.pi, (DRAWS, 1, 1))
    angle = 2 * np.pi * (freq[0] * x + freq[1] * y) + beta
    carriers = np.stack((np.cos(angle), np.sin(angle)), axis=-1)
    waves = np.concatenate(
        (carriers, carriers * model.relative.AFFINE[..., 0, None], carriers * model.relative.AFFINE[..., 1, None]),
        axis=-1,
    )
    coefficient = np.asarray([0.0020, 0.0008, -0.0007, 0.0014, 0.0005, -0.0010])
    distinct = waves @ coefficient
    return np.broadcast_to(bg, distinct.shape), distinct, waves


def replay(observed, wave, target, cfa, profile, method):
    shot, read = profile
    center = BASE._CENTER_BASIS
    background = BASE._FIT_BASIS
    methods = {
        "common": model.SUBFIT,
        "diagonal": lambda *a, **k: model.subfit(*a, **k, covariance=False),
        "covariance": model.subfit,
    }
    calc = methods[method]
    fits, held = [], []
    for f in range(2):
        p, valid = calc(observed[:, 4:-4, 4:-4], wave[:, 8:-8, 8:-8], background, cfa, shot, read, f, affine=True)
        _, central = calc(observed[:, 8:-8, 8:-8], wave[:, 16:-16, 16:-16], center, cfa, shot, read, f, supplied=p)
        fits.append(np.einsum("nyxc,nc->nyx", wave[:, 16:-16, 16:-16], p))
        held.append(np.minimum(valid / 6, central / 1.5))
    coherent = np.sum(fits[0] * fits[1], axis=(1, 2)) > 0
    combined = (fits[0] + fits[1]) / 2
    return {
        "weak_fit_RMS_DN16": float(np.sqrt(np.mean((combined - target)**2)) * 65535),
        "passes": int(np.count_nonzero(coherent & (np.minimum(*held) > 1))),
        "weak_fit_bias_DN16": float(np.mean(combined - target) * 65535),
    }


def main():
    mark = monotonic()
    rng = np.random.default_rng(895427)
    result = []
    for freq_name, freq in FREQUENCIES.items():
        for ratio in (1.0, 0.06):
            bg, direction, waves = field(rng, freq, ratio)
            for profile_name, (shot, read) in PROFILES.items():
                for role in ("weak", "null"):
                    target = direction if role == "weak" else 0
                    truth = bg + target
                    noise = np.sqrt(shot * truth + read)
                    noisy = np.rint(np.clip(truth + noise * rng.normal(size=truth.shape), 0, 1) * 65535) / 65535
                    result.append({
                        "frequency": freq_name,
                        "dark_bright_ratio": ratio,
                        "profile": profile_name,
                        "role": role,
                        "draws_per_site": DRAWS,
                        "sites": [
                            {
                                "pos": [r,c],
                                "scores": {
                                    m: replay(
                                        noisy[:, r::2, c::2], waves,
                                        direction[:, 16:-16, 16:-16] if role == "weak" else 0,
                                        (r,c), (shot,read), m,
                                    )
                                    for m in ("common", "diagonal", "covariance")
                                },
                            }
                            for r, c in np.ndindex(2, 2)
                        ],
                    })
    write_json(
        OUT / "oracle-score.json",
        {
            "driver": reference(__file__), "operator": reference(model.__file__),
            "description": "Exact guide and smooth cosine background with Gaussian shot/read approximation and 16-bit quantization. Four same-color positions sample the same noise field for each layout.",
            "frequencies": FREQUENCIES, "profiles": PROFILES, "rows": result, "seconds": monotonic() - mark,
        },
    )


if __name__ == "__main__":
    main()
