"""Render native exact-target crops from two changed mixed-illumination examples."""

from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

import predictive_matched as matched
from replay_predictive import OUT, REPLAY

SELECTION = ("lightstep-10", "lightstep-11")
SHOW = (
    "conditional", "affine_sign", "field_sign",
    "weighted_affine_sign", "predictive_affine_sign",
)


def main():
    torch.set_num_threads(2)
    bindings = reference(OUT / "lightstep" / "result.json")
    record = read_json(checked(bindings))["panels"]["iso1600"]
    capture = read_json(checked(record["source"]))
    plan = read_json(checked(capture["plan"]))
    output = OUT / "native"
    output.mkdir(exist_ok=True)
    results = []
    for g, row in zip(plan["cases"], record["rows"], strict=True):
        if row["id"] not in SELECTION:
            continue
        d = row["draws"][0]
        f = REPLAY.arrays(d["input"])
        attrs = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        attrs["packed"] = f["packed"][:1]
        scene = f["scene_packed"].copy()
        scene[REPLAY.RAW] = f["packed"][0]
        parent = f["local50k"][0]
        colors, wb, matrix = f["colors"], f["wb"], f["matrix"]
        peaks = _spacing(scene, colors, *REPLAY.SENSOR_ROI[:2], clearance=48)
        outputs, evidence = matched.evaluate(
            parent, REPLAY.ROI, scene, REPLAY.SENSOR_ROI, colors, peaks, plan["noise"], wb, matrix
        )
        held = []
        for k in SHOW:
            image = parent.copy()
            REPLAY.section(image, *REPLAY.ROI)[:] = outputs[k]
            held.append(image)
        values = [
            REPLAY.noisy_malvar(attrs)[0], f["v120"][0], parent, *held,
            f["target"][0],
        ]
        descriptor = {
            "input": d["input"], "source": g, "noise": plan["noise"],
            "weights": plan["weights"], "optical_sigma": plan["sigma"],
            "query": plan["query"], "draw": 0,
            "predictive_minus_conditional_peak_DN16": float(
                np.max(abs(outputs["predictive_affine_sign"] - outputs["conditional"])) * 65535
            ),
            "scored_local_RGB_DN16": {k: d["scores"][k]["local_RGB_DN16"] for k in SHOW},
            "evidence": evidence,
        }
        results.append(REPLAY.native_board(
            output, row["id"], values, attrs, descriptor,
            labels=["Noisy Malvar", "V120 EMA", "Local 50k", *(matched.LABELS[k] for k in SHOW), "Exact GT"],
            triplet_indices=(0, len(values) - 2, len(values) - 1),
        ))
    assert len(results) == len(SELECTION)
    write_json(OUT / "selected-views.json", {
        "driver": reference(__file__), "inputs": bindings, "boards": results,
    })


if __name__ == "__main__":
    main()
