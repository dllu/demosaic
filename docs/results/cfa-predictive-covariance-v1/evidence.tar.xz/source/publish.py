"""Publish verified native boards and original Bayer-fit experiment receipts."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
NAME = "cfa-predictive-covariance-v1"
OUT = Path("/mnt/external/demosaic") / NAME
SOURCE = ROOT / ".cache" / "experiments" / NAME
IMAGES = ROOT / "docs/assets" / NAME
RESULTS = ROOT / "docs/results" / NAME

RECEIPTS = (
    "result.json",
    "matched/retained.json",
    "lightstep/result.json",
    "lightstep/sources.json",
    "lightstep/inputs.json",
    "lightstep/iso1600/inputs.json",
    "lightstep/iso1600/plan.json",
    "lightstep/iso6400/inputs.json",
    "lightstep/iso6400/plan.json",
    "oracle-score.json",
    "oracle-curve.json",
    "selected-views.json",
    "summary.json",
)


def put(data):
    old = checked(data["image"])
    path = IMAGES / old.name
    shutil.copyfile(old, path)
    current = reference(path)
    assert current["sha256"] == data["image"]["sha256"]
    with Image.open(path) as image:
        for panel in data["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= image.width and 0 <= y < y + h <= image.height
    return data | {"image": current | {"path": str(path.relative_to(ROOT))}}


def main():
    IMAGES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    receipts = {name: reference(OUT / name) for name in RECEIPTS}
    doc = {name: read_json(checked(binding)) for name, binding in receipts.items()}
    base = doc["matched/retained.json"]
    changed = doc["selected-views.json"]
    frozen = doc["lightstep/inputs.json"]
    assert base["earlier"] == receipts["result.json"]
    assert changed["inputs"] == receipts["lightstep/result.json"]
    assert frozen["source"] == receipts["lightstep/sources.json"]
    for profile, descriptor in frozen["panels"].items():
        prefix = f"lightstep/{profile}"
        assert descriptor == receipts[f"{prefix}/inputs.json"]
        captured = doc[f"{prefix}/inputs.json"]
        assert captured["plan"] == receipts[f"{prefix}/plan.json"]
        for case in captured["rows"]:
            for obs in case["observations"]["warped"]:
                checked(obs["input"])
    for receipt in doc.values():
        for field in ("driver", "operator"):
            if field in receipt:
                checked(receipt[field])
    old = reference(ROOT / "docs/results/cfa-relative-phase-v1/publication.json")
    scripts = [
        "predictive.py", "predictive_matched.py", "replay_predictive.py", "capture_lightstep.py",
        "replay_matched.py", "replay_lightstep.py", "oracle_score.py", "oracle_curve.py",
        "render_selected.py", "reduce_results.py", "publish.py",
    ]
    files = {f"source/{k}": reference(SOURCE / k) for k in scripts}
    files.update({f"receipts/{k}": v for k, v in receipts.items()})
    for before in ("relative_phase.py", "replay_relative.py", "capture_relative.py"):
        files[f"prior/{before}"] = reference(SOURCE.with_name("cfa-relative-phase-v1") / before)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for name, binding in files.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == files.keys()
        for k, value in files.items():
            with tar.extractfile(k) as item:
                assert hashlib.file_digest(item, "sha256").hexdigest() == value["sha256"], k

    synthetic = [
        item | {"board": put(item["board"]), "triplet": put(item["triplet"])}
        for item in changed["boards"]
    ]
    cameras = []
    for row in base["standing"]["rows"]:
        assert all(
            k["versus_conditional_DN16"] == 0
            for k in row["comparisons"].values()
        )
        cameras.append(row | {"views": [put(view) for view in row["views"]]})
    native = IMAGES / "manifest.json"
    write_json(
        native, {
            "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "synthetic": synthetic, "camera": cameras,
        }
    )
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(receipts["summary.json"]), summary)
    assert reference(summary)["sha256"] == receipts["summary.json"]["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "archive": reference(archive),
            "summary": reference(summary),
            "native_manifest": reference(native),
            "prior_publication": old,
            "source_receipts": receipts,
            "members": files,
            "native_GFX_boards_viewed": sum(len(c["views"]) for c in cameras),
            "native_comparison_boards_viewed": 2,
            "native_triplets_viewed": 2,
            "new_weights": None,
        }
    )


if __name__ == "__main__":
    main()
