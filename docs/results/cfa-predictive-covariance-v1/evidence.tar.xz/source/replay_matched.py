"""Compare equal cutoffs and test fresh mixed-illumination RAW observations."""

from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import predictive_matched as matched
import replay_predictive as driver


def check_close(previous, current):
    count = 0
    for a, b in zip(previous, current, strict=True):
        for observation, replay in zip(a["draws"], b["draws"], strict=True):
            for k, row in observation["scores"].items():
                for m, value in row.items():
                    np.testing.assert_allclose(value, replay["scores"][k][m], rtol=1e-12, atol=1e-10)
                    count += 1
    return count


def main():
    torch.set_num_threads(2)
    start = monotonic()
    root = driver.OUT
    driver.OUT = root / "matched"
    (driver.OUT / "exact").mkdir(parents=True, exist_ok=True)
    (driver.OUT / "standing").mkdir(exist_ok=True)
    driver.predictive = matched
    earlier = reference(root / "result.json")
    old = read_json(checked(earlier))
    panels = {}
    checks = {}
    for name, former in old["panels"].items():
        panels[name] = driver.replay_panel(name, former["source"])
        checks[name] = check_close(former["rows"], panels[name]["rows"])
    standing = driver.standing()
    write_json(
        driver.OUT / "retained.json",
        {
            "driver": reference(__file__), "operator": reference(matched.__file__),
            "earlier": earlier, "numeric_replay_checks": checks, "audit": matched.audit(),
            "panels": panels, "standing": standing, "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
