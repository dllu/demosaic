"""Replay all paired color estimators on the fresh illumination-step panel."""

from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import predictive_matched as matched
import replay_predictive as driver


def main():
    torch.set_num_threads(2)
    start = monotonic()
    root = driver.OUT
    driver.OUT = root / "lightstep"
    (driver.OUT / "exact").mkdir(exist_ok=True)
    driver.predictive = matched
    original = reference(driver.OUT / "inputs.json")
    captures = read_json(checked(original))
    panels = {}
    for key, source in captures["panels"].items():
        panels[key] = driver.replay_panel(key, source)
    write_json(
        driver.OUT / "result.json",
        {
            "driver": reference(__file__), "operator": reference(matched.__file__),
            "capture": original, "panels": panels, "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
