"""Capture fresh signed-color wires and nulls over mixed illumination."""

from collections import Counter
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
SALT = 202611200337
COUNT = 16
sys.path.insert(0, str(HERE.with_name("cfa-relative-phase-v1")))
import capture_relative as previous

ENVELOPE = previous.envelope
SOURCE = OUT.with_name("cfa-relative-phase-v1") / "master.json"


def select():
    binding = reference(SOURCE)
    last = read_json(checked(binding))
    lines, scan = ENVELOPE.capture_wide.lines, ENVELOPE.capture_wide.scan
    excluded = [binding, *last["excluded"]]
    blocked = set()
    for src in excluded:
        path = checked(src)
        if path.suffix == ".jsonl":
            for item in lines(src):
                scan(item, blocked)
        else:
            scan(read_json(path), blocked)
    pool = [
        p for p in lines(last["source_pool"])
        if p["split"] == "val" and p["bin_factor"] == 4 and min(p["shape"][:2]) >= 512
        and {p["id"], p["cache_sha256"]}.isdisjoint(blocked)
    ]
    pool.sort(key=lambda row: sha256(f"predictive-lightstep/{SALT}/{row['id']}".encode()).digest())
    ENVELOPE.capture_wide.SEED = SALT
    picked = []
    for photo in pool:
        keys = {photo["id"], photo["cache_sha256"]}
        if not keys.isdisjoint(blocked):
            continue
        idx = len(picked)
        box, = scene_crop_boxes(
            photo["shape"][:2], patch_size=512, count=1, seed=scene_seed(SALT, idx, "crop")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SALT, idx, "camera")))
        camera.update(pattern=tuple(PATTERNS)[(idx + idx // 4) % 4], exposure=0.33, black=0.03)
        rng = np.random.default_rng(scene_seed(SALT, idx, "phase"))
        warp = dict(
            zip(
                ("tilt_t", "tilt_n", "bend"),
                rng.choice((-1, 1), 3) * rng.uniform((1.8, 0.45, 1.35), (4.0, 1.2, 3.2)),
                strict=True,
            )
        )
        geometry = ENVELOPE.capture_wide.geometry(idx)
        geometry.update(
            family=ENVELOPE.FAMILIES[idx % 4],
            frequency=[
                ENVELOPE.carrier(rng, 1, (6.85, 9.4)),
                ENVELOPE.carrier(rng, -1, (6.9, 9.5)),
            ],
            strength=rng.uniform((0.010, 0.0045), (0.017, 0.0105)).tolist(),
            gap_width=float(rng.uniform(22, 33)),
            gap_length=float(rng.uniform(32, 57)),
            tint=rng.uniform(0.04, 0.13, 3).tolist(),
        )
        mod = previous.MULTIPLIERS[(idx // 4 + idx % 4) % 4]
        picked.append({
            "id": f"lightstep-{idx:02d}", "index": idx, "split": "confirmation",
            "source": photo, "box": box, "camera": camera, "geometry": geometry,
            "warp": {k: float(v) for k, v in warp.items()},
            "contrast_group": "aligned" if mod == (1.0, 1.0) else "signed",
            "color_multipliers": mod,
            "color_ellipse": (float((-1) ** idx * (9 + idx % 3)), float((idx % 3 - 1) * 6), 37.0, 47.0),
            "step_angle": float(rng.uniform(0, 2 * np.pi)),
            "step_offset": float(rng.uniform(-16, 16)),
            "dim_ratio": (0.22, 0.35, 0.28, 0.45)[(idx + idx // 4) % 4],
        })
        blocked.update(keys)
        if len(picked) == COUNT:
            break
    assert len(picked) == COUNT
    trace = read_json(checked(last["parent_trace"]))
    ids = {x["source"][k] for x in picked for k in ("id", "cache_sha256")}
    visits = 0
    for f in trace["source_traces"]:
        for row in lines(f):
            for visit in row["sources"]:
                if visit["kind"] == "photographic":
                    assert ids.isdisjoint((visit["source_id"], visit["cache_sha256"]))
                    visits += 1
    assert visits == last["trace_visits"]
    return {
        "driver": reference(__file__), "source_panel": binding,
        "excluded": excluded, "trace_visits": visits, "parent_trace": last["parent_trace"],
        "groups": dict(Counter(r["contrast_group"] for r in picked)),
        "source_pool": last["source_pool"], "sources": picked, "weights": last["weights"],
        "roles": last["roles"], "sigma": last["sigma"], "query": last["query"],
        "profiles": last["profiles"], "seed": SALT,
    }


def illuminated(case, state):
    geo, clean, support, recipe = previous.signed_fixtures(case, state)
    n = clean[0].shape[-1]
    axis = torch.arange(n, dtype=clean[0].dtype) - (n - 1) / 2
    angle = case["step_angle"]
    level = np.sin(angle) * axis[:, None] + np.cos(angle) * axis[None, :] - case["step_offset"]
    dim = case["dim_ratio"]
    light = dim + (1 - dim) * torch.sigmoid(level / 1.8)
    return geo, (*(x * light for x in clean[:-1]), clean[-1]), support, recipe


def main():
    torch.set_num_threads(2)
    out = OUT / "lightstep"
    out.mkdir(exist_ok=True)
    master = out / "sources.json"
    if not master.exists():
        write_json(master, select())
    binding = reference(master)
    plan = read_json(checked(binding))
    panels = {}
    for idx, (name, noise) in enumerate(plan["profiles"].items()):
        directory = out / name
        directory.mkdir(exist_ok=True)
        fixture = directory / "plan.json"
        if not fixture.exists():
            write_json(fixture, plan | {
                "cases": [x | {"camera": x["camera"] | noise} for x in plan["sources"]],
                "noise": noise | {"exposure": 0.33},
                "master": binding, "native_indices": [1, 9], "states": ["warped"],
            })
        ENVELOPE.OUT = directory
        ENVELOPE.SALT = SALT + 1000 * idx
        ENVELOPE.STATES = ("warped",)
        ENVELOPE.fixtures = illuminated
        target = directory / "inputs.json"
        if not target.exists():
            ENVELOPE.capture(read_json(fixture), reference(fixture))
        panels[name] = reference(target)
    write_json(out / "inputs.json", {"source": binding, "panels": panels})


if __name__ == "__main__":
    main()
