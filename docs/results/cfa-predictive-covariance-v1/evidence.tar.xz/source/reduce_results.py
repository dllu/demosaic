"""Compute matched source-level differences for the candidate color checks."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay_predictive import OUT, REPLAY

PAIR = {
    "per_pixel_vs_common_affine": ("weighted_affine_sign", "affine_sign"),
    "covariance_vs_per_pixel_affine": ("predictive_affine_sign", "weighted_affine_sign"),
    "full_vs_common_affine": ("predictive_affine_sign", "affine_sign"),
    "per_pixel_vs_common_field": ("weighted_field", "field_sign"),
    "covariance_vs_per_pixel_field": ("predictive_field", "weighted_field"),
    "full_vs_common_field": ("predictive_field", "field_sign"),
}
METRICS = (
    "signed_RB_response", "local_RGB_DN16", "weak_increment_RB_DN16",
    "gap_RB_RMS_DN16", "flat_RGB_DN16", "edge_added_DN16", "uniform_added_DN16",
)


def source_difference(rows, first, second, key):
    eligible = [
        r for r in rows if r["class"] == "signed"
        and all(key in d["scores"][first] and key in d["scores"][second] for d in r["draws"])
    ]
    value = [
        mean(d["scores"][first][key] - d["scores"][second][key] for d in row["draws"])
        for row in eligible
    ]
    if not value:
        return None
    index = REPLAY.source_bootstrap(eligible, np.random.default_rng(202611200337))
    return {
        "n_sources": len(value), "changed_sources": int(np.count_nonzero(value)),
        "mean_and_interval": REPLAY.interval(np.asarray(value)[index].mean(1)),
        "sample_mean": mean(value),
        "worst_delta": max(value), "best_delta": min(value),
    }


def main():
    retained = reference(OUT / "matched" / "retained.json")
    lightstep = reference(OUT / "lightstep" / "result.json")
    oracle = reference(OUT / "oracle-score.json")
    panels = {}
    for source, name in ((retained, "retained"), (lightstep, "fresh")):
        for key, panel in read_json(checked(source))["panels"].items():
            rows = panel["rows"]
            panels[f"{name}_{key}"] = {
                "source": panel["source"], "cases": len(rows),
                "signed": panel["summary"]["signed"],
                "contrasts": {
                    label: {m: source_difference(rows, *pair, m) for m in METRICS}
                    for label, pair in PAIR.items()
                },
            }
    controls = []
    for r in read_json(checked(oracle))["rows"]:
        active = {
            k: sum(x["scores"][k]["passes"] for x in r["sites"])
            for k in ("common", "diagonal", "covariance")
        }
        errors = {
            k: mean(x["scores"][k]["weak_fit_RMS_DN16"] for x in r["sites"])
            for k in ("common", "diagonal", "covariance")
        }
        controls.append(
            {k: v for k, v in r.items() if k != "sites"}
            | {"passing_of_384": active, "mean_site_fit_RMS_DN16": errors}
        )
    write_json(
        OUT / "summary.json",
        {
            "driver": reference(__file__), "retained": retained, "fresh": lightstep, "oracle": oracle,
            "panels": panels, "controlled": controls,
        },
    )


if __name__ == "__main__":
    main()
