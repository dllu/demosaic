"""Condition held Bayer comparisons on the fit-side nuisance uncertainty."""

from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("cfa-relative-phase-v1")))
import relative_phase as relative

BASE = relative.base
SUBFIT = relative.subfit
COMPOSE = relative.compose
BASE_ARMS = relative.ARMS
ARMS = BASE_ARMS + (
    "affine_sign", "weighted_affine", "weighted_affine_sign", "predictive_affine",
    "predictive_affine_sign", "weighted_field", "predictive_field",
)
LABELS = relative.LABELS | {
    "affine_sign": "Affine + sign",
    "weighted_affine": "Weighted affine",
    "weighted_affine_sign": "Weighted affine + sign",
    "predictive_affine": "Predictive affine",
    "predictive_affine_sign": "Predictive affine + sign",
    "weighted_field": "Weighted field",
    "predictive_field": "Predictive field",
}
WEIGHT_FLOOR = 0.25


def weights(observed, design, target, shot, read):
    """Estimate expected sensor noise at fit and held sites from fit RAW only."""
    beta = observed @ np.linalg.pinv(design, rcond=1e-8).T
    level = np.maximum(0, np.concatenate((beta @ design.T, beta @ target.T), axis=1))
    variance = shot * level + read
    common = relative._variance(observed, shot, read)
    floor = np.maximum(1e-12, WEIGHT_FLOOR * common)
    variance = np.maximum(floor[:, None], variance)
    return tuple(np.split(1 / variance, [design.shape[0]], axis=1))


def projection(design, precision):
    weighted = precision[..., None] * design
    gram = design.T @ weighted
    inv = np.linalg.solve(gram, weighted.swapaxes(1, 2))
    return gram, inv


def score(held, prediction, precision, target, gram, covariance):
    first = 2 * held - prediction
    diagonal = np.einsum("np,np,np->n", first, precision, prediction)
    if not covariance:
        return diagonal
    # Predictive covariance adds B (A' W_A A)⁻¹ B' to the held sensor variance.
    # Woodbury reduces the inverse to a solve over the nuisance basis.
    weighted = target * precision[..., None]
    combined = gram + target.T @ weighted
    aa = np.einsum("np,npd->nd", first, weighted)
    bb = np.einsum("np,npd->nd", prediction, weighted)
    bias = np.linalg.solve(combined, bb[..., None])[..., 0]
    return diagonal - np.einsum("nd,nd->n", aa, bias)


def subfit(raw, patches, background, site, shot, read, split, supplied=None, affine=False, *, covariance=True):
    r, c = site
    n = len(raw)
    raw = raw.reshape(n, -1)
    terms = patches[:, r::2, c::2].reshape(n, -1, patches.shape[-1])
    nuisance = background[r::2, c::2].reshape(-1, background.shape[-1])
    fit_side = BASE._CHECKER[background.shape[0]]
    if split:
        fit_side = ~fit_side
    design, target = nuisance[fit_side], nuisance[~fit_side]
    a, b = raw[:, fit_side], raw[:, ~fit_side]
    u, v = terms[:, fit_side], terms[:, ~fit_side]
    wa, wb = weights(a, design, target, shot, read)
    gram, inv = projection(design, wa)
    centered = a - (design @ (inv @ a[..., None]))[..., 0]
    held = b - (target @ (inv @ a[..., None]))[..., 0]
    beta = inv @ u
    x, y = u - design @ beta, v - target @ beta
    if supplied is None:
        weighted = wa[..., None] * x
        energy = x.swapaxes(1, 2) @ weighted
        moment = weighted.swapaxes(1, 2) @ centered[..., None]
        if affine:
            scale = np.maximum(energy[:, (0, 1), (0, 1)].mean(axis=1), 1e-12)
            diag = np.arange(energy.shape[-1])
            energy[:, diag, diag] += scale[:, None] * 1e-10
            energy[:, diag[2:], diag[2:]] += scale[:, None] * relative.RIDGE
            fitted = np.linalg.solve(energy, moment)[..., 0]
        else:
            fitted = (np.linalg.pinv(energy, hermitian=True) @ moment)[..., 0]
        if fitted.shape[-1] == 1:
            fitted = np.maximum(0, fitted)
    else:
        fitted = supplied
    prediction = (y @ fitted[..., None])[..., 0]
    return fitted, score(held, prediction, wb, target, gram, covariance)


def compose(covariance, *args, **options):
    def measured(*values, **kwargs):
        return subfit(*values, **kwargs, covariance=covariance)

    try:
        relative.subfit = measured
        return COMPOSE(*args, **options)
    finally:
        relative.subfit = SUBFIT


def evaluate(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    def append(*args, **options):
        original = COMPOSE(*args, **options)
        k = args[1][0].shape[-1]
        if k == 6:
            diagonal = compose(False, *args, **options)
            full = compose(True, *args, **options)
            additions = {
                "affine_sign": original(0),
                "weighted_affine": diagonal(1.5),
                "weighted_affine_sign": diagonal(0),
                "predictive_affine": full(1.5),
                "predictive_affine_sign": full(0),
            }
        elif k == 1:
            diagonal = compose(False, *args, **options)
            full = compose(True, *args, **options)
            additions = {"weighted_field": diagonal(0), "predictive_field": full(0)}
        else:
            additions = {}
        reporters.update(additions)
        return original

    def patched_callback(*args, **options):
        result = callback[0](*args, **options)
        report = result | reporters
        reporters.clear()
        return report

    def mix(*args, **options):
        previous = relative.previous.candidate_patches
        try:
            callback[0] = previous
            relative.previous.candidate_patches = patched_callback
            return original_directional(*args, **options)
        finally:
            relative.previous.candidate_patches = previous

    reporters, callback = {}, [None]
    original_directional = relative.previous.apply_directional
    try:
        relative.compose = append
        relative.previous.apply_directional = mix
        relative.previous.ARMS = ARMS
        return relative.apply_relative(parent, local, scene, roi, colors, peaks, noise, wb, matrix)
    finally:
        relative.compose = COMPOSE
        relative.previous.apply_directional = original_directional
        relative.previous.ARMS = BASE_ARMS


def audit():
    """Check the precision calculation against a dense matrix and change holdouts."""
    rng = np.random.default_rng(623534)
    a, b = rng.normal(size=(55, 6)), rng.normal(size=(53, 6))
    wa, wb = rng.uniform(0.1, 3, (1, len(a))), rng.uniform(0.1, 3, (1, len(b)))
    e, p = rng.normal(size=(2, len(b)))
    gram, _ = projection(a, wa)
    dense = np.diag(1 / wb[0]) + b @ np.linalg.solve(gram[0], b.T)
    expected = (2 * e - p) @ np.linalg.solve(dense, p)
    exact, = score(e[None], p[None], wb, b, gram, True)
    np.testing.assert_allclose(expected, exact, rtol=1e-12, atol=1e-12)
    proofs = []
    for r, c in np.ndindex(2, 2):
        basis = BASE._FIT_BASIS
        fake = rng.normal(0.07, 0.004, (3, 24, 24))
        pair = rng.normal(size=(3, 48, 48, 2))
        for fold, keep in enumerate((BASE._CHECKER[48], ~BASE._CHECKER[48])):
            x = fake.reshape(len(fake), -1).copy()
            x[:, ~keep] += rng.normal(0.01, 0.05, (len(fake), (~keep).sum()))
            first, s = subfit(fake, pair, basis, (r, c), 0.00128, 6.5536e-6, fold)
            other, t = subfit(x.reshape(fake.shape), pair, basis, (r, c), 0.00128, 6.5536e-6, fold)
            np.testing.assert_array_equal(first, other)
            assert np.any(s != t)
            proofs.append({"position": [r, c], "holdout": fold})
    return {"dense_quadratic_form_difference": float(exact - expected), "holdout_checks": proofs}
