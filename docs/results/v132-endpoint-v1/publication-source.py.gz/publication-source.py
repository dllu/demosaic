import gzip,io,tarfile,shutil,html
from pathlib import Path
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
R=Path.cwd();root=R/'.cache/experiments/v132-endpoint-publication-v1';review=R/'.cache/experiments/raw-spatial-endpoint-review-v3';run=review/'V132';train=R/'.cache/experiments/raw-spatial-continuation-v2';images=R/'docs/images/v132-endpoint-v1';docs=R/'docs/results/v132-endpoint-v1';images.mkdir(exist_ok=False);docs.mkdir(exist_ok=False)
report=read_json(run/'report-v1/report.json');audit=read_json(run/'independent-audit-v1.json');collection=read_json(run/'collection-v1.json');assert audit['PNG_images']==64 and collection['counts']=={'root':102,'encoder':102};assert collection['full_model_before']==collection['full_model_after'];assert collection['backbone_before']==collection['backbone_after']
figures=[]
for f in report['images']:
 dest=images/Path(f['image']['path']).name;shutil.copyfile(checked(f['image']),dest);assert reference(dest)['sha256']==f['image']['sha256'];figures.append({'original':f['image'],'published':reference(dest),'relative':dest.name,'metadata':f})
body='<!doctype html><meta charset="utf-8"><title>V132 completed20k native review</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:28px 0;overflow:auto}img{max-width:none}</style><h1>V13220k versus V13120k and V120</h1><p>Native160 cells unresized; use browser zoom100%. Exact synthetic material GT; independent real ISO100/AHD references are qualitative, never exact GT. Standing main train and cab mesh, both profiles/ROIs/JPEGs retained. Faint ADC displays share contrast20. Full20k input traces match exactly; single training seed, targeted development observations.</p>'
for f in figures:
 n=html.escape(f['relative']);body+='<figure><figcaption>'+n+'</figcaption><a href="'+n+'"><img src="'+n+'"></a></figure>\n'
(images/'native-viewer.html').write_text(body)
archives=[]
def archive(path,name):
 path=Path(path);data=path.read_bytes();dest=docs/(name+'.gz');dest.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(dest.read_bytes())==data;archives.append({'original':reference(path),'published':reference(dest),'decompressed_bytes_exact':True})
for path,name in [(train/'train-V132-result.json','training-result.json'),(train/'plan.json','training-plan.json'),(review/'queue-plan.json','queue-plan.json'),(review/'readiness-V132.json','readiness.json'),(R/'.cache/experiments/neural-nuisance-full-panel-v1/completed-training-input-comparison.json','completed-training-input-comparison.json'),(root/'checkpoint-copy.json','checkpoint-copy.json'),(Path(__file__),'publication-source.py')]:archive(path,name)
for path in sorted(run.rglob('*')):
 if path.is_file()and run/'work'not in path.parents and path.suffix in ['.json','.jsonl','.log']:archive(path,'review-'+str(path.relative_to(run)).replace('/','--'))
files=[p for p in(run/'work').rglob('*.py')];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as tar:
 for path in sorted(files):
  data=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(run/'work')));info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
source=docs/'executed-source.tar.gz';source.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
with tarfile.open(source,'r:gz')as tar:
 for member in tar.getmembers():assert tar.extractfile(member).read()==(run/'work'/member.name).read_bytes()
write_json(root/'publication-prepared.json',{'archives':archives,'source_snapshot':reference(source),'source_files_exact':len(files),'images':figures,'viewer':reference(images/'native-viewer.html'),'checkpoint':read_json(train/'train-V132-result.json')['checkpoint'],'collection':reference(run/'collection-v1.json'),'independent_audit':reference(run/'independent-audit-v1.json'),'new_neural_forwards_in_publication':0,'neural_forwards_in_evaluation':102,'viewing':'Pending actual native review.','scope':'Completed20k trained RAW spatial-attention endpoint, exact-copy native boards and compressed receipts. Package/scripts source snapshot verified; official DINO backbone identity separately verified at runtime, vendor source remains in repository. Historical training/report status strings retained byte for byte.'});print('prepared',len(figures),'native images and',len(archives),'exact archives')
