"""Close the already-viewed studies without rewriting any earlier receipt."""
import gzip
from datetime import datetime, timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REPO = Path.cwd()


def archive(source, destination):
    source = Path(source)
    with destination.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(destination.read_bytes()) == source.read_bytes()
    return {"original": reference(source), "published": reference(destination),
            "decompressed_bytes_exact": True}


for experiment, publication in [
    ("neural-nuisance-context512-pilot-v1", "neural-nuisance-context512-v1"),
    ("neural-nuisance-full-edge512-pilot-v1", "neural-nuisance-full-edge512-v1"),
]:
    root = REPO / ".cache/experiments" / experiment
    destination = REPO / "docs/results" / publication
    prepared = read_json(root / "publication-prepared.json")
    manifest = read_json(root / "contact-sheets/manifest.json")
    batches = sorted(root.glob("viewing-batch-*.json"))
    viewed = [sheet for batch in batches for sheet in read_json(batch)["sheets"]]
    assert all(read_json(batch)["actually_viewed"] for batch in batches)
    assert sorted(viewed) == list(range(len(manifest["sheets"])))
    assert manifest["source_images"] == len(prepared["images"]) == 34
    assert manifest["no_resize"]
    sources = [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *batches, REPO / ".cache/native-contact-sheets-v1.py", Path(__file__)]
    if "full-edge" in experiment:
        sources += [root / "edge-discovery-diagnostic.json",
                    REPO / ".cache/diagnose-context-edge-v1.py",
                    REPO / ".cache/diagnose-context-edge-v1.log"]
    archives = list(prepared["archives"])
    for source in sources:
        archives.append(archive(source, destination / ("addendum-" + source.name + ".gz")))
    for item in archives:
        assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
    for item in prepared["images"]:
        assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
    prepared.update({
        "archives": archives,
        "viewing": {"actually_viewed": True, "figures": 34, "contact_sheets": len(viewed),
                    "manifest": reference(root / "contact-sheets/manifest.json"),
                    "batches": [reference(batch) for batch in batches],
                    "method": "All source board pixels copied unresized into actually viewed contact sheets"},
        "status": "complete; no weak-detail quality promotion",
        "quality_decision": "Keep native256 fixed-proposal NN operating point; native512 results are near parent with missing weak detail",
        "plot_limitation": "Original increment-tradeoff PNG clips left labels/title; original bytes preserved; use report tables",
        "published_UTC": datetime.now(timezone.utc).isoformat(),
    })
    write_json(destination / "publication.json", prepared)
    print(publication, len(archives), "exact archives;34 actually viewed source figures")

destination = REPO / "docs/results/v132-endpoint-v1"
archives = [archive(REPO / source, destination / ("import-test-" + Path(source).name + ".gz"))
            for source in [".cache/v132-public-preset-import-test.log",
                           ".cache/v132-public-preset-import-test-v2.log",
                           "tests/test_experiment_consolidation.py", ".cache/finalize-context512-publications-v1.py"]]
write_json(destination / "import-test-addendum.json", {
    "publication": reference(destination / "publication.json"), "archives": archives,
    "initial_failure": "The no-Torch assertion ran after shared_edge imports Torch; registry itself remains lightweight",
    "correction": "Check catalogue before training modules; verify training-module imports do not initialize CUDA",
    "result": "1 passed in1.63s", "new_neural_forwards": 0,
    "published_UTC": datetime.now(timezone.utc).isoformat(),
})
