"""Publish completed Corpus 20k weak-band and independent photometry evidence."""

import hashlib
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = Path.cwd()
DEST = REPO / "docs/results/full-corpus-control20k-detail-v1"
PRIMARY = REPO / "docs/results/full-corpus-control20k-primary-v1/primary.json"


def main():
    completed = read_json(ROOT/"result.json")
    primary = read_json(PRIMARY)
    assert completed["primary_result"] == primary["source_result"]
    audit_path = checked(completed["independent_primary_audit"])
    detail_path = checked(completed["broad_detail"])
    adapted = checked(completed["archive"])
    audit, detail, export = map(read_json, (audit_path, detail_path, adapted))
    assert audit["status"] == "passed" and len(audit["rows"]) == 25132
    assert export["all_records_verified_with_existing_reader"] and export["records"] == 6216
    assert audit["source_result"] == export["source_result"] == completed["primary_result"]
    assert detail["first_manifest"] == detail["second_manifest"] == export["manifest"]
    assert (detail["photographic_sources"],detail["paired_source_noise_CFA_observations"],detail["unique_source_blocks"]) == (427,5124,96075)
    assert detail["first_checkpoint_sha256"] == primary["models"]["V120"]["checkpoint"]["sha256"]
    assert detail["second_checkpoint_sha256"] == primary["models"]["scale-control20k"]["checkpoint"]["sha256"]
    assert all(key in detail for key in ("per_source", "GT_strata","retained_inputs"))
    assert not any(detail[key] for key in ("new_neural_forwards","new_noise_observations","RAW_decodes"))
    all_files = {
        "closed-analysis.json":ROOT/"result.json",
        "analysis-plan.json":checked(completed["plan"]),
        "independent-photometry.json":audit_path,
        "exact-native-archive.json":adapted,
        "weak-band/result.json":detail_path,
        "weak-band/per-source.json":checked(detail["per_source"]),
        "weak-band/input-hashes.json":checked(detail["retained_inputs"]),
        "weak-band/GT-strata.npz":checked(detail["GT_strata"]),
        "src/audit_local_primary.py":checked(audit["producer"]),
        "src/audit_quality_archive.py":checked(audit["original_tolerance_helper"]),
        "src/diagnose_archive_local_detail.py":ROOT/"work/scripts/diagnose_archive_local_detail.py",
        "src/publish_detail.py":Path(__file__),
        "worker.log":ROOT/"watcher.log",
    }
    plan = read_json(all_files["analysis-plan.json"])
    frozen = plan["frozen_files"]
    for f in all_files.values():
        if str(f) in frozen:
            assert reference(f)["sha256"] == frozen[str(f)]
    DEST.mkdir(exist_ok=True)
    archive = DEST/"evidence.tar.xz"
    refs = {n:reference(p)["sha256"] for n,p in all_files.items()}
    with tarfile.open(archive,"x:xz",preset=3) as bundle:
        for name, p in all_files.items():
            bundle.add(p,arcname=name)
    with tarfile.open(archive) as bundle:
        for n,s in refs.items():
            assert hashlib.file_digest(bundle.extractfile(n),"sha256").hexdigest() == s
    def local(path):
        return reference(path) | {"path":str(path.relative_to(REPO))}
    write_json(DEST/"publication.json", {
        "primary":local(PRIMARY), "audit":completed["independent_primary_audit"],
        "audit_rows":len(audit["rows"]), "audit_maximum_discrepancies":audit["maximum_discrepancies"],
        "rows_per_stage_and_model":audit["stage_model_observation_counts"],
        "detail_result":completed["broad_detail"], "detail":detail, "evidence":local(archive),
        "archive_member_sha256":refs, "complete":True,
    })


if __name__=="__main__":
    main()
