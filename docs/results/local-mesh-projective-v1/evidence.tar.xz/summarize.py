"""Summarize held-out RAW evidence and native restoration by noise and layout."""

import argparse
from pathlib import Path
from statistics import mean

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
GROUPS=[(p,l)for p in ('iso400','iso6400')for l in ('occluded','broken')]
ROLES=('rear-present','front-only','flat')


def summarize(mode):
    sources={key:reference(ROOT/name) for key,name in [('phase','result.json'),('donor','geometry.json'),('color','color.json'),('delivery','delivery.json')]}
    if mode=='fresh':
        sources={'fresh':reference(ROOT/'fresh.json')}
    summary={}
    for kind,binding in sources.items():
        original=read_json(checked(binding))
        rows=original['cases'] if kind=='color' else [read_json(checked(ref))for ref in original['cases']]
        assert len(rows)==(24 if mode=='fresh' else 48)
        by_group={}
        for p,l in GROUPS:
            group=[r for r in rows if r['profile']==p and r['layout']==l]
            assert len(group)==(6 if mode=='fresh' else 12)
            trim={}
            if kind=='phase':
                for k in ('original','conditional-phase','conditional-search','oracle-planar','oracle-perspective'):
                    data=[[r['roles'][role][k] for r in group]for role in ROLES]
                    trim[k]={'raw_pass':[sum(x['evidence']['passes']for x in a)for a in data],
                        'wire_template_cosine':mean(x['rear_template_cosine'] for x in data[0]),
                        'rear_occluded_pass':[sum(min(x['evidence']['occluded'])>0 for x in a) for a in data],
                        'raw_audit_gain':mean(x['evidence']['rear'][-1] for x in data[0])}
            if kind=='color':
                for policy in ('exact','original'):
                    for arm in ('independent','donor','uniform'):
                        data=[[r['roles'][role][policy][arm] for r in group]for role in ROLES]
                        trim[policy+'-'+arm]={'raw_pass':[sum(x['pass']for x in a)for a in data],
                            'raw_audit_gain':mean(x['rear'][-1] for x in data[0])}
            if kind=='donor':
                for s in ('matching','unrelated'):
                    exterior=[r['exteriors'][s]for r in group]
                    trim[s]={'warp_accepted':sum(d['geometry']['status']=='accepted' for d in exterior),
                             'harmonic_repairs':sum(2 in d['subharmonic']for d in exterior)}
                    for key in ('fundamental','projective'):
                        data=[[r['raw_candidates'][role][key] for r in exterior]for role in ROLES]
                        trim[s][key]={'raw_pass':[sum(x['measurements']['passes'] for x in a) for a in data],
                            'wire_template_cosine':mean(x['cosine'] for x in data[0]),
                            'raw_audit_gain':mean(x['measurements']['rear'][-1]for x in data[0])}
            if kind in ('delivery','fresh'):
                for key in (list(group[0]['controls'])+list(group[0]['delivery']) if kind=='delivery' else group[0]['metrics']):
                    parts=[(r['metrics'][key] if kind=='fresh' else
                           r['delivery'][key]['metrics'] if key in r['delivery'] else r['controls'][key])for r in group]
                    trim[key]={'weak_response':mean(x['response'][0]for x in parts),'wire_error':mean(x['increment_RMS_DN16'][0]for x in parts),
                               'front_only_error':mean(x['negative_RMS_DN16'][0]for x in parts),
                               'flat_error':mean(x['negative_RMS_DN16'][1]for x in parts),
                               'active':[sum(x['changed'][i]for x in parts)for i in range(3)]}
                    for metric in ('gap_added_RMS_DN16','gap_error_RMS_DN16'):
                        available=[x[metric] for x in parts if x[metric] is not None]
                        if available:
                            trim[key][metric]=mean(available)
                            trim[key]['max_'+metric]=max(available)
            by_group[p+'-'+l]=trim
        summary[kind]=by_group
    write_json(ROOT/(mode+'-summary.json'),{'driver':reference(__file__),'source':sources,'summary':summary})
    for kind in ('delivery','fresh'):
        for label,items in summary.get(kind,{}).items():
            print(label)
            for a,s in items.items():
                if a=='parent' or a in ('matching-anchored','matching-anchored-median','matching-tight-planar','matching-projective','matching-short-support','unrelated-projective'):
                    print(a,round(s['weak_response']*100,3),round(s['wire_error'],3),s['active'],s.get('gap_added_RMS_DN16'))


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('mode',choices=('replay','fresh'))
    summarize(cli.parse_args().mode)
