"""Render matching RAW, restoration and exact target in unresized native pixels."""
import argparse
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from deliver import ROOT,OLDER,DISPLAY,score


def render(queue):
    plan=read_json(OLDER/'plan.json')
    out=ROOT/(queue+'-native');out.mkdir()
    if queue=='replay':
        selected=[(ROOT/'delivery-cases'/(s+'-r0.json'), 'matching-projective') for s in
                  ('iso400-broken-g110','iso400-broken-g111','iso400-occluded-g115')]
        names=('matching-tight-planar','matching-projective')
        labels=('Donor-centered planar','Donor projective')
    else:
        original=read_json(ROOT/'fresh.json')
        cases=[checked(r)for r in original['cases']]
        grouped={l:[]for l in ('occluded','broken')}
        for path in cases:
            case=read_json(path)
            if case['profile']!='iso400':
                continue
            base=case['metrics']['matching-anchored']['increment_RMS_DN16'][0]
            revised=case['metrics']['matching-short-support']['increment_RMS_DN16'][0]
            grouped[case['layout']].append((base-revised,path,case))
        selected=[]
        for label,items in grouped.items():
            winner=max(items,key=lambda v:v[0]); selected.append((winner[1],'matching-short-support'))
            if label=='broken':
                worst=max(items,key=lambda v:v[2]['metrics']['matching-projective']['gap_added_RMS_DN16'])
                if worst[1]!=winner[1]: selected.append((worst[1],'matching-projective'))
        names=('matching-anchored','matching-projective','matching-short-support')
        labels=('Prior anchored','Donor projective','Short support')
    published=[]
    for ref,primary in selected:
        r=read_json(ref);src=checked(r['retained'] if queue=='replay' else r['array'])
        with np.load(src,allow_pickle=False)as z:
            arrays=dict(z)
        local=arrays['parent'];truth=arrays['target']
        masks={k:arrays[k]for k in ('strong_phase','weak_phase','support')}
        x,y,w,h=DISPLAY
        outputs=[]
        for name in names:
            delta=arrays[name]
            current=score(local,delta,truth,masks)
            expected=r['delivery'][name]['metrics'] if queue=='replay' else r['metrics'][name]
            np.testing.assert_allclose(current['response'],expected['response'],rtol=0,atol=1e-12)
            if current['gap_added_RMS_DN16'] is not None:
                np.testing.assert_allclose(current['gap_added_RMS_DN16'],expected['gap_added_RMS_DN16'],rtol=0,atol=1e-12)
            composed=local.copy();composed[...,y:y+h,x:x+w]+=delta;outputs.append(composed[1])
        previews=[noisy_malvar(arrays)[1],local[1],*outputs,truth[1]]
        case=r.get('name',r.get('id'))
        published.append(native_board(out,case,previews,{k:arrays[k][1:2]for k in ('wb','matrix')},
            {'checkpoint':plan['checkpoint'],'array':reference(src),'metrics':reference(ref),'CFA':arrays['colors'][1].tolist(),'noise':plan['noise'][r['profile']]},
            labels=('Noisy Malvar','Local-only trunk',*labels,'Exact GT'),triplet_indices=(0,2+names.index(primary),len(previews)-1),
            roi=DISPLAY,exposure=1,contrast=8))
    write_json(ROOT/(queue+'-render.json'),{'source':reference(__file__),'boards':published})


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('queue',choices=('replay','fresh'))
    render(p.parse_args().queue)
