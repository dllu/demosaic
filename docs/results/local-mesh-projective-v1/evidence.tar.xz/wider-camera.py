"""Try extending the already selected donor pair into a wider cached camera region."""

import math
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from deliver import ROOT,OLDER,geometry,window,shift_prior
from fresh import short,refined
from standing import legacy
from stabilize import median_correction
from support import donor_peaks


def packed(a):
    return np.stack([a[dy::2,dx::2] for dy,dx in ((0,0),(0,1),(1,0),(1,1))])


def augment(full,origin,query,trace,colors,noise):
    span=trace['donor_span']; frequency=np.asarray(trace['prior_frequencies'])
    center=np.asarray(query[:2])+127.5
    raw_offset=np.asarray(origin[:2]); old_windows=trace['windows']
    grid=np.asarray(old_windows[0]['center'])-span/2
    starts=[]
    for i in range(-8,13):
        for j in range(-8,13):
            rel=grid+np.array([i,j])*span
            u,v=(rel+raw_offset).astype(int)
            if not (0<=u<=full.shape[1]-span and 0<=v<=full.shape[0]-span):continue
            if np.linalg.norm(rel+span/2-.5-center)>730:continue
            if np.all(rel>=0) and np.all(rel+span<=origin[2:]):continue
            starts.append((np.linalg.norm(rel+span/2-.5-center),rel,(u,v)))
    added=[]; checks=[]
    for radius,rel,(x,y) in sorted(starts,key=lambda v:v[0]):
        tile=packed(full[y:y+span,x:x+span]); peaks=donor_peaks(tile,colors,noise)
        if len(peaks)<2:continue
        pools=[]
        for f in frequency:
            pool=[]
            for p in peaks:
                k=np.asarray(p.frequency);k=np.copysign(1,f@k)*k
                d=np.linalg.norm(k-f)
                if d<=.008:pool.append((float(d),p))
            pools.append(pool)
        if any(not p for p in pools):continue
        a,b=(min(p,key=lambda v:v[0])for p in pools)
        if a[1] is b[1]:continue
        mark={'center':list(rel+span/2),'peaks':[vars(p) for p in peaks]}
        added.append(mark);checks.append({'center':mark['center'],'distances':[a[0],b[0]],'distance_to_query':float(radius)})
    enriched={**trace,'windows':old_windows+added,'supporting_centers':trace['supporting_centers']+[v['center']for v in added]}
    return enriched,checks


def main():
    source=read_json(ROOT/'camera.json')
    context=read_json(ROOT.parent/'expanded-scene-12000-native-v1/plan.json')
    controls={r['id']:r for r in context['observations']}
    shifts=read_json(ROOT.parent/'local-mesh-origin-v1/result.json')['translations_native_xy']
    output=ROOT/'wider-camera';output.mkdir()
    observations={};rows=[]
    for row in source['views']:
        case=row['id'];observation=controls[next(k for k in controls if case.startswith(k+'-'))]
        family='mesh' if case.startswith('mesh-') else 'main';trace=row['donor_windows']
        if family not in observations:
            config=read_json(checked(context[family+'_full_RAW']))
            local=checked(config['sources']['noisy']) if family=='mesh' else Path(config['noisy']).absolute()
            assert (Path.cwd()/'.cache').resolve() in local.resolve().parents,local
            raw,_=read_raw(local)
            observations[family]=(raw,reference(local))
        raw,receipt=observations[family]
        origin=[600,6260,768,768]if family=='mesh'else observation['metadata']['context_xywh']
        x,y,w,h=origin
        with np.load(checked(row['input']),allow_pickle=False)as z:
            local=z['packed'][0];colors=z['colors'][0];var=z['variance'][0]
            renders={k:z[k]for k in ('wb','matrix')}
        np.testing.assert_array_equal(packed(raw[y:y+h,x:x+w]),local)
        data=trace.get('prior_frequencies')
        original_status=trace.get('projective',{}).get('status')
        if data:
            new,added=augment(raw,origin,row['query'],trace,colors,row['noise'])
            pos,local_freq,mask,division=geometry.donor_arrays(new,np.asarray(row['query'][:2])+127.5)
            freq,projective,fit=geometry.fit_geometry(pos,local_freq,mask)
        else:
            new=trace;added=[];fit={'status':'no local pair'}
        field=np.load(checked(row['parent']),allow_pickle=False)[0];base=window(field,row['ROI'])
        with np.load(checked(row['deltas']),allow_pickle=False)as old:
            delivered=old['projective']
        moved=[];narrow=[]
        qx,qy,qw,qh=row['query']
        if data:
            for dx,dy in shifts:
                f,g=shift_prior(freq,projective,dx,dy); query=(qx+dx,qy+dy,qw,qh)
                dd,details=refined.correction(field,local,var,colors,query,row['ROI'],f,g,row['noise'],packed_offset=dx//2)
                tapered=short.shorten(dd,window(local,query,phase=2),colors,details.get('phase_candidates'),row['noise'],query,row['ROI'],dx//2)
                moved.append(dd);narrow.append(tapered)
            value=median_correction(moved);limit=median_correction(narrow)
        else:
            value=limit=np.zeros_like(base)
        old={'image':row['comparison'],'panels':[p for p in row['panels'] if p['label']!='Donor-centered planar']}
        w,h=row['ROI'][2:]
        chosen=[(k,legacy.pixel(base+v,renders,(0,0,w,h),row['exposure']))for k,v in (('Wider donors',value),('Short support',limit))]
        image,positions=legacy.insert_camera_panels(output,case,old,'Donor projective',chosen)
        dest=output/(case+'.npz');np.savez_compressed(dest,wider=value,narrow=limit)
        rms=lambda a: float(np.sqrt(np.mean(a.astype(float)**2))*65535)
        result={'id':case,'input':row['input'],'RAW':receipt,'ROI':row['ROI'],'absolute_box':origin,'noise':row['noise'],
                'exposure':row['exposure'],'original_status':original_status,'fit':fit,'added_donors':added,
                'corrections':[rms(a)for a in (delivered,value,limit)],'deltas':reference(dest),'image':image,'panels':positions}
        rows.append(result)
        print(case,len(added),fit['status'],[round(x,3)for x in result['corrections']],flush=True)
    write_json(ROOT/'wider-camera.json',{'driver':reference(__file__),'source':reference(ROOT/'camera.json'),'views':rows,
        'scope':'An additional fixed-radius standing-camera diagnostic. The original local pair is required before searching a wider area. The same 80/112-pixel donor grid extends up to 730 native pixels from the query center. Newly accepted tiles must contain both prior directions within 0.008 cycles per pixel. Standing ROIs, RAW inputs, display and neural parent remain fixed.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
