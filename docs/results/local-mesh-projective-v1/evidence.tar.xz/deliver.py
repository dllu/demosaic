"""Replay projected donor geometry through the existing two-direction delivery."""

import importlib.util
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from probe import ROOT,OLDER,CENTRE,evidence,sample,Carrier
from mesh import restore
from run import DISPLAY,score,window

spec=importlib.util.spec_from_file_location('donor_geometry',ROOT/'donor-geometry.py')
geometry=importlib.util.module_from_spec(spec);spec.loader.exec_module(geometry)


def shift_prior(freq,g,base_x,base_y):
    d=np.array([base_x,base_y],dtype=float)
    return geometry.projected_frequency(freq,g,d[None])[0],g/(1+d@g)


def proposals(scene,colors,box,noise,span):
    from support import infer_prior
    f,trace=infer_prior(scene,colors,box,noise,span=span)
    if f is None:
        return None,trace
    pos,local,usable,division=geometry.donor_arrays(trace,(box[0]+127.5,box[1]+127.5))
    planar=np.asarray([local[usable[:,i],i].mean(0) for i in range(2)])
    freq,warp,note=geometry.fit_geometry(pos,local,usable)
    trace['projective']=note
    trace['subharmonic']=division
    return {'tight-planar':(planar,np.zeros(2)),'projective':(freq,warp)},trace


def correction(field,packed,var,colors,query,roi,freq,g,noise,*,packed_offset=0):
    raw=window(packed,query,phase=2)
    old=window(field,query)
    shade=lambda a: window(a,(roi[0]-query[0],roi[1]-query[1],roi[2],roi[3]))
    pair,z=geometry.reserve_candidates(raw,colors,freq,g,noise,packed_offset=packed_offset)
    if max(z)<3:
        return np.zeros_like(shade(old)), {'status':'no reserve proposal'}
    scores=evidence(raw,colors,pair,noise,packed_offset)
    if not scores['passes']:
        return np.zeros_like(shade(old)), {'status':'RAW prediction rejected','checks':scores}
    reserve=(np.indices(raw.shape[-2:])[1]+packed_offset)%4==0
    shot,read=noise['shot'],noise['read']
    variance=window(var,query,phase=2)
    fits=[];supports=[]
    for lines,method in ((pair[::-1],'add'),(pair,'adaptive')):
        new,r=restore(old,raw,variance,colors,lines,(shot,read),method=method,reserved=reserve)
        if r[0]['basis'] is None:
            return np.zeros_like(shade(old)), {'status':'fit rejected','checks':scores}
        _,local=restore(old,raw,variance,colors,lines,(shot,read),method=method,local=True,reserved=reserve,dense=True)
        fits.append(new);supports.append(local)
    x,y=coordinates(*old.shape[-2:],origin=(-127.5,-127.5))
    mask=np.zeros_like(x);denom=np.zeros_like(x)
    for l,r in zip(*supports,strict=True):
        cx,cy=l['center']
        taper=np.maximum(0,1-abs(x-cx)/64)*np.maximum(0,1-abs(y-cy)/64)
        denom+=taper
        mask+=taper*min(l['blend'],r['blend'])
    addition=(fits[0].astype(float)-old)+(fits[1].astype(float)-old)
    value=(old+addition*mask[None]/np.maximum(denom,1e-8)).astype(old.dtype)
    return shade(value-old),{'status':'supported','checks':scores,'support_fraction':float(np.count_nonzero(mask)/mask.size)}


@torch.inference_mode()
def main():
    old=read_json(OLDER/'result.json'); plan=read_json(checked(old['plan']))
    dest=ROOT/'delivery-cases';dest.mkdir()
    out=[];started=time.monotonic()
    ckpt=plan['checkpoint']
    model,payload=load_scene_checkpoint(checked(ckpt),device='cuda',weights='ema',expected_sha256=ckpt['sha256'])
    model.mode='none';assert payload['step']==2000;del payload
    with ieee_fp32():
        for b in old['cases']:
            row=read_json(checked(b)); name=row['id']; noise=plan['noise'][row['profile']]
            model.base.set_noise(noise['shot'],noise['read'])
            inp,surrounds,masks,_=sample(row['g'],row['layout'],noise,row['sensor_seed'])
            assert {k:fingerprint(v) for k,v in inp.items()}==row['input_fingerprints']
            local=model(*(inp[k].cuda() for k in ('packed','variance','colors','wb','matrix'))).cpu().numpy()
            packed,var,colors,truth=(inp[k].numpy() for k in ('packed','variance','colors','target'))
            expected=row['measurements']['parent'];actual=score(local,None,truth,masks)
            np.testing.assert_allclose(actual['response'],expected['response'],atol=5e-9,rtol=0)
            keep={}; result={}
            for outside in ('matching','unrelated'):
                details=row['checks'][outside]['exterior']
                position,local_donor,used,division=geometry.donor_arrays(details,(383.5,383.5))
                f,g,note=geometry.fit_geometry(position,local_donor,used)
                mean=np.asarray([local_donor[used[:,i],i].mean(0) for i in range(2)])
                for which,freq,warp in (('tight-planar',mean,np.zeros(2)),('projective',f,g)):
                    key=outside+'-'+which
                    pairs=[]; audits=[]
                    for i in (0,1,2):
                        delta,c=correction(local[i],packed[i],var[i],colors[i],CENTRE,DISPLAY,freq,warp,noise)
                        pairs.append(delta);audits.append(c)
                    delta=np.stack(pairs,axis=0)
                    result[key]={'metrics':score(local,delta,truth,masks),'checks':audits}
                    keep[key]=delta
            retained=None
            if row['r']==0:
                output=dest/(name+'.npz')
                np.savez_compressed(output,**{k:v.numpy() for k,v in inp.items()},**masks,parent=local,**keep)
                retained=reference(output)
            values=[round(result[k]['metrics']['response'][0],4) for k in ('matching-tight-planar','matching-projective')]
            print(name,values,[round(result[k]['metrics']['gap_added_RMS_DN16'] or 0,2) for k in ('matching-tight-planar','matching-projective')],flush=True)
            dst=dest/(name+'.json');write_json(dst,{'name':name,'profile':row['profile'],'layout':row['layout'],'source':b,
                'controls':row['measurements'],'delivery':result,'retained':retained});out.append(reference(dst))
    assert len(out)==48
    write_json(ROOT/'delivery.json',{'driver':reference(__file__),'sample_source':reference(OLDER/'result.json'),'checkpoint':ckpt,
      'cases':out,'seconds':time.monotonic()-started,'scope':'Central diagnostic with paired clean targets. Both methods deliver only after the exact earlier checks using new geometries, same footprint and same parent. Old central and overlap-anchored scores are retained controls.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
