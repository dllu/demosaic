"""Check projected scene geometry and the same existing native GFX boards."""

import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from deliver import ROOT,OLDER,proposals,correction,shift_prior,window
from standing import legacy
from stabilize import median_correction


def main():
    source=read_json(OLDER/'camera.json')
    origin=read_json(checked(source['source']))
    sources={r['id']: r for r in origin['cases']}
    output=ROOT/'camera';output.mkdir()
    data=[]
    for row in source['rows']:
        case=row['id']; input_binding=row['input']
        with np.load(checked(input_binding),allow_pickle=False) as a:
            colors=a['colors'][0]; packed=a['packed'][0]; variance=a['variance'][0]
            render={k:a[k] for k in ('wb','matrix')}
        field=np.load(checked(row['matched_parent']),allow_pickle=False)[0]
        box=row['native_query']; roi=row['native_ROI']; base=window(field,roi)
        noise=row['noise']; exposure=row['display_exposure']
        span=112 if case.startswith('mesh-') else 80
        proposal,trace=proposals(packed,colors,box,noise,span)
        old=sources[case]['shifted']['frozen-donors'][0]['frequency_prior']
        current=trace.get('prior_frequencies')
        assert (old is None) == (current is None)
        if old is not None:
            np.testing.assert_allclose(old,current,rtol=0,atol=1e-14)
        outcomes={};panels=[];outputs={}
        for mode,label in (('tight-planar','Donor-centered planar'),('projective','Donor projective')):
            choices=[];checks=[]
            for dx,dy in origin['translations_native_xy']:
                if proposal:
                    f,g=shift_prior(*proposal[mode],dx,dy)
                    moved=(box[0]+dx,box[1]+dy,box[2],box[3]);
                    d,details=correction(field,packed,variance,colors,moved,roi,f,g,noise,packed_offset=dx//2)
                else:
                    d=np.zeros_like(base);details={'status':'no exterior pair'}
                choices.append(d);checks.append({'shift':[dx,dy],'details':details})
            final=median_correction(choices)
            outputs[mode]=final
            outcomes[mode]={'RMS_DN16':float(np.sqrt(np.mean(final.astype(float)**2))*65535),
                           'shifts_active':sum(bool(x.any()) for x in choices),'checks':checks}
            panels.append((label,legacy.pixel(base+final,render,(0,0,roi[2],roi[3]),exposure)))
        old={'image':row['image'],'panels':[x for x in row['panels'] if x['label'] not in ('Prior at original box','Median, moving split')]}
        signal,positions=legacy.insert_camera_panels(output,case,old,'Median, anchored split',panels)
        path=output/(case+'.npz');np.savez_compressed(path,**outputs)
        data.append({'id':case,'source_image':row['image'],'input':input_binding,'parent':row['matched_parent'],
            'noise':noise,'exposure':exposure,'ROI':roi,'query':box,'donor_windows':trace,'measured':outcomes,
            'comparison':signal,'panels':positions,'deltas':reference(path)})
        print(case,trace.get('projective',{}).get('status'),[(k,round(v['RMS_DN16'],3),v['shifts_active']) for k,v in outcomes.items()],flush=True)
    write_json(ROOT/'camera.json',{'driver':reference(__file__),'source':reference(OLDER/'camera.json'),
       'checkpoint':source['checkpoint'],'views':data,'scope':'Same eight crop fields and display with old anchored baseline, planar donor recentering and projective donor geometry. The fit is evaluated at the same 13 native query origins.'})

if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
