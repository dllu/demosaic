"""Estimate a shared projective phase field from shifts in disjoint donor spectra."""

import itertools
import os
import time
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
import torch
from scipy.optimize import least_squares

from demosaic._mesh_frequency import residual_sensor
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint
from probe import ROOT,OLDER,CENTRE,Carrier,evidence,prior,query_phases,sample,similarity


def relative_peak(f, candidates):
    choices = [np.copysign(1, f @ np.asarray(p['frequency'])) * np.asarray(p['frequency']) for p in candidates]
    return min(choices,key=lambda p: np.linalg.norm(f-p))


def donor_arrays(trace, reference_center):
    """Only the windows that supplied the pair can nominate a subharmonic."""
    freq = np.asarray(trace['prior_frequencies'])
    centers = set(map(tuple,trace['supporting_centers']))
    sites = [w for w in trace['windows'] if tuple(w['center']) in centers]
    position = np.asarray([w['center'] for w in sites])-0.5-np.asarray(reference_center)
    original = [[relative_peak(f,w['peaks']) for f in freq] for w in sites]
    original = np.asarray(original)
    frequencies = original.copy()
    use = np.ones(original.shape[:2],bool)
    divisions=[]
    for d in range(2):
        reference = original[:,d]/2
        half = np.asarray([relative_peak(f,w['peaks']) for f,w in zip(reference,sites,strict=True)])
        agree = np.linalg.norm(half-reference,axis=-1) < .00375
        if agree.sum() >= max(2,len(agree)*.55):
            frequencies[agree,d] = half[agree]
            use[:,d] = agree
            divisions.append(2)
        else:
            divisions.append(1)
    return position,frequencies,use,divisions


def projected_frequency(f, g, positions):
    denominator = 1+positions@g
    numer = positions@f.T
    return (f[None]*(denominator[:,None,None])-numer[...,None]*g[None,None])/denominator[:,None,None]**2


def fit_geometry(positions, observed, use):
    mean = np.asarray([observed[use[:,i],i].mean(0) for i in range(2)])
    guess = np.r_[mean.ravel()*128,0.,0.]
    lower=np.r_[guess[:4]-3,-.09,-.09]
    upper=np.r_[guess[:4]+3,.09,.09]
    if len(observed)<4 or min(use.sum(0))<3:
        return mean,np.zeros(2),{'status':'insufficient donor windows'}
    def estimate(take):
        weights=use & take[:,None]
        def errors(theta):
            f,g=theta[:4].reshape(2,2)/128,theta[-2:]/128
            return ((projected_frequency(f,g,positions)-observed)[weights]*128).ravel()
        answer=least_squares(errors,guess,bounds=(lower,upper),loss='soft_l1',f_scale=.25)
        return answer.x[:4].reshape(2,2)/128,answer.x[-2:]/128
    # Cross-fit over dispersed disjoint windows. A projective fit must
    # forecast new donor frequencies at least as well in both directions.
    order=np.lexsort((positions[:,0],positions[:,1]))
    keep=np.zeros(len(order),bool);keep[order[::2]]=True
    audits=[]
    fits=[]
    for train in (keep,~keep):
        if min((train[:,None]&use).sum(0))<2 or min((~train[:,None]&use).sum(0))<1:
            return mean,np.zeros(2),{'status':'insufficient fold coverage'}
        f,g=estimate(train)
        null=np.asarray([observed[train&use[:,i],i].mean(0) for i in range(2)])
        valid=use & ~train[:,None]
        ref=np.mean((observed-null)[valid]**2)
        pred=np.mean((observed-projected_frequency(f,g,positions))[valid]**2)
        audits.append([float(ref),float(pred)])
        fits.append(g)
    f,g=estimate(np.ones(len(order),bool))
    accepted=all(new<old for old,new in audits) and np.linalg.norm(fits[0]-fits[1])<.00048
    details={'status':'accepted' if accepted else 'rejected','holdout_losses':audits,
             'fold_perspectives':np.asarray(fits).tolist(),'estimated_perspective':g.tolist()}
    return (f,g,details) if accepted else (mean,np.zeros(2),details)


def reserve_candidates(raw,colors,frequencies,projective,noise,*,packed_offset=0):
    """Measure each phase on the original reserved Bayer sites."""
    h,w=raw.shape[-2:]
    take=(np.indices((h,w))[1]+packed_offset)%4==0
    win=np.outer(np.hanning(h),np.hanning(w))
    greens=residual_sensor(raw,colors,noise,take,win)
    x,y=native_sites((h,w), (-(2*w-1)/2,-(2*h-1)/2))
    phase=[];values=[]
    for plane,sensor in greens:
        xy=np.stack((x[plane][take],y[plane][take]),axis=-1)
        phase.append(xy/(1+xy@projective)[:,None])
        values.append(sensor[take]*win[take])
    points=np.concatenate(phase)
    values=np.concatenate(values)
    normalizer=np.sqrt(len(greens)*np.sum(win[take]**2)/2)
    answer=[]
    for freq in frequencies:
        best=np.asarray(freq)
        for step in (1/640,1/1920):
            bank=best+np.asarray(list(itertools.product((-1,0,1),repeat=2)))*step
            phi=2*np.pi*(points @ bank.T)
            powers=values@np.cos(phi)+1j*(values@np.sin(phi))
            index=int(np.argmax(abs(powers)));best=bank[index]
        modulus=float(abs(powers[index])/normalizer)
        candidate=Carrier(tuple(best),float(np.angle(powers[index])/(2*np.pi)%1),.08,tuple(projective))
        answer.append((modulus,candidate))
    answer.sort(key=lambda t:t[0],reverse=True)
    return tuple(c for _,c in answer), [s for s,_ in answer]


def replay():
    source=read_json(OLDER/'result.json')
    plan=read_json(checked(source['plan']))
    output=ROOT/'geometry-cases';output.mkdir()
    receipts=[];start=time.monotonic()
    for binding in source['cases']:
        case=read_json(checked(binding))
        noise=plan['noise'][case['profile']]
        inp,_,_,_=sample(case['g'],case['layout'],noise,case['sensor_seed'])
        assert {k:fingerprint(v) for k,v in inp.items()}==case['input_fingerprints']
        oracle=prior.guides(case['g'])
        row={'id':case['id'],'source':binding,'profile':case['profile'],'layout':case['layout'],'exteriors':{}}
        for outside in ('matching','unrelated'):
            trace=case['checks'][outside]['exterior']
            pos,local_masked,mask,divisions=donor_arrays(trace,(383.5,383.5))
            estimated,g,geo=fit_geometry(pos,local_masked,mask)
            harmonic_mean=np.asarray([local_masked[mask[:,i],i].mean(0) for i in range(2)])
            state={'subharmonic':divisions,'geometry':geo,'center_frequencies':estimated.tolist(),'raw_candidates':{}}
            tuple_groups=(('fundamental',harmonic_mean,np.zeros(2)),('projective',estimated,g))
            for role,label in enumerate(('front-only','rear-present','flat')):
                x,y,w,h=CENTRE
                raw=inp['packed'][role,:,y//2:(y+h)//2,x//2:(x+w)//2].numpy()
                color=inp['colors'][role].numpy()
                local={}
                for method,frequencies,warp in tuple_groups:
                    candidates,strength=reserve_candidates(raw,color,frequencies,warp,noise)
                    local[method]={'candidates':[asdict(v) for v in candidates],'reserve_scores':strength,
                                   'cosine':similarity(candidates,oracle,raw),'measurements':evidence(raw,color,candidates,noise)}
                state['raw_candidates'][label]=local
            row['exteriors'][outside]=state
        path=output/(case['id']+'.json');write_json(path,row);receipts.append(reference(path))
        s=row['exteriors']['matching']; print(case['id'],s['subharmonic'],s['geometry']['status'],
              [(m,round(v['cosine'],3),v['measurements']['passes']) for m,v in s['raw_candidates']['rear-present'].items()],flush=True)
    write_json(ROOT/'geometry.json',{'driver':reference(__file__),'input':reference(OLDER/'result.json'),'cases':receipts,
       'seconds':time.monotonic()-start,'scope':'Subharmonic nomination uses repeated donor support only. Common geometry is verified on spatially dispersed donor folds. Query phase then comes from the existing green reserve. Both original noise and color measurements remain bitwise fixed.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    replay()
