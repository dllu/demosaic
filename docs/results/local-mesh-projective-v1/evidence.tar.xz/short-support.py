"""Limit a broad projective waveform to local held-out support."""

import dataclasses
import numpy as np

from demosaic._mesh_profiles import split_scores, supported_profile
from demosaic.isolated_line import coordinates,native_sites
from deliver import correction
from mesh import fields


def support(raw, color, pair, noise, packed_offset, *, half_width=38):
    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
    u,v=coordinates(raw.shape[-2]*2,raw.shape[-1]*2,origin=(-127.5,-127.5))
    front,waves=fields(x,y,pair)
    null=np.stack((np.ones_like(x),x/128,y/128,front),axis=-1)
    cfa=np.broadcast_to(np.asarray(color)[:,None,None],raw.shape)
    packed_y,packed_x=np.indices(raw.shape[-2:])
    fit=np.broadcast_to((packed_x+packed_offset)%4!=0,raw.shape)
    fold=np.broadcast_to((packed_x+packed_y)%2,raw.shape)
    weight=np.zeros_like(u); denominator=np.zeros_like(u)
    for cx in range(-112,113,28):
        for cy in range(-112,113,28):
            keep=(abs(x-cx)<=half_width)&(abs(y-cy)<=half_width)&fit
            p=(waves['add'][keep],waves['occlusion'][keep])
            _,strength=supported_profile(split_scores(null[keep],p,raw[keep].astype(float),
                                                   cfa[keep],fold[keep],noise['shot'],noise['read']))
            taper=np.maximum(0,1-abs(u-cx)/28)*np.maximum(0,1-abs(v-cy)/28)
            weight+=taper*strength;denominator+=taper
    return weight/np.maximum(denominator,1e-8)


def shorten(delta,raw,colors,candidates,noise,query,roi,packed_offset):
    if not np.any(delta):
        return delta
    from deliver import Carrier
    pair=[Carrier(**entry) for entry in candidates]
    weight=support(raw,colors,pair,noise,packed_offset)
    x,y=roi[0]-query[0],roi[1]-query[1]
    return (delta*weight[None,y:y+roi[3],x:x+roi[2]]).astype(delta.dtype)
