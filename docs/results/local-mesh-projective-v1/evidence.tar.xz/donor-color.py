"""Compare independent color fits with a signed donor color in held-out RAW."""

import os
import time
from dataclasses import replace

import numpy as np
import torch

from probe import ROOT,OLDER,CENTRE,prior,evidence,sample,Carrier,query_phases,ribbon,projected_fit
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint


def nearest(freq, peaks):
    choices = [np.copysign(1,np.dot(freq,row['frequency']))*np.asarray(row['frequency']) for row in peaks]
    return min(choices,key=lambda f:np.linalg.norm(f-freq))


def chroma(scene,colors,trace):
    pairs=np.asarray(trace['prior_frequencies'])
    span=trace['donor_span']
    centers=set(map(tuple,trace['supporting_centers']))
    x,y=native_sites((span//2,span//2),(-(span-1)/2, -(span-1)/2))
    win=np.broadcast_to(np.outer(np.hanning(span//2),np.hanning(span//2)),x.shape)
    cfa=np.broadcast_to(np.asarray(colors)[:,None,None],x.shape)
    checkerboard=np.broadcast_to(np.indices(x.shape[-2:]).sum(0)%2==0,x.shape)
    tint=[]
    for row in trace['windows']:
        cx,cy=row['center']
        if (cx,cy) not in centers:
            continue
        left,top=int(cx-span/2)//2,int(cy-span/2)//2
        tile=scene[:,top:top+span//2,left:left+span//2]
        f1,f2=(nearest(f,row['peaks']) for f in pairs)
        p,q=(2*np.pi*(f[0]*x+f[1]*y) for f in (f1,f2))
        design=np.stack([np.ones_like(x),x/span,y/span,np.cos(p),np.sin(p),np.cos(q),np.sin(q)],axis=-1)
        directions=[]
        for subset in (checkerboard,~checkerboard):
            same_color=[]
            for channel in range(3):
                k=subset&(cfa==channel)
                w=np.sqrt(win[k]); x1=design[k]*w[:,None]; v=tile[k]*w
                a=np.linalg.lstsq(x1,v,rcond=None)[0]
                same_color.append([a[3]+1j*a[4],a[5]+1j*a[6]])
            a=np.asarray(same_color)
            angle=np.angle(a[1])
            amplitudes=np.real(a*np.exp(-1j*angle))
            directions.append(amplitudes/np.maximum(np.linalg.norm(amplitudes,axis=0),1e-12))
        tint.append(directions)
    colors=np.asarray(tint)
    estimates=np.median(colors,axis=(0,1))
    estimates=estimates/np.maximum(np.linalg.norm(estimates,axis=0),1e-12)
    return estimates.T,colors.tolist()


def crossfit(raw, layout, pair, profile, tint, *, occlude, include_audit=False):
    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
    slot=np.broadcast_to(np.indices(raw.shape[-2:])[1]%4,raw.shape)
    cfa=np.broadcast_to(np.asarray(layout)[:,None,None],raw.shape)
    front,wire=(ribbon(x,y,g) for g in pair)
    if occlude:
        wire=wire*(1-front)
    base=np.stack((np.ones_like(x),x/128,y/128,front),axis=-1)
    rows=[]
    for train,test in (((1,),2),((2,),1),((1,2),3)):
        terms=[]
        for k in range(3):
            a=(cfa==k)&np.isin(slot,train); b=(cfa==k)&(slot==test)
            var=profile['shot']*max(1e-4,float(np.median(raw[a])))+profile['read']
            low,d,g,col,prec=projected_fit(base[a],wire[a,None],raw[a],np.full(a.sum(),1/var))
            test_wire=wire[b]-(base[b]@d).ravel()
            test_raw=raw[b]-base[b]@low
            terms.append((float(prec[0,0]),float(g[0]),float(test_wire@test_raw/var),float(test_wire@test_wire/var)))
        p,a,r,q=np.asarray(terms).T
        if tint is not None:
            a=(tint@(p*a)/(p@(tint**2)))*tint
        rows.append(float(np.sum(a*(2*r-a*q))))
    return rows


def run():
    old=read_json(OLDER/'result.json'); plan=read_json(checked(old['plan']))
    started=time.monotonic();rows=[]
    for b in old['cases']:
        case=read_json(checked(b)); noise=plan['noise'][case['profile']]
        inputs,donors,_,_=sample(case['g'],case['layout'],noise,case['sensor_seed'])
        assert {k:fingerprint(v) for k,v in inputs.items()}==case['input_fingerprints']
        tint,tints=chroma(donors['matching'],inputs['colors'][0],case['checks']['matching']['exterior'])
        actual=prior.guides(case['g']); front, rear=actual
        f=np.asarray(case['frequency_priors']['matching']); agree=abs(f@np.asarray(rear.frequency))/np.linalg.norm(f,axis=1)
        raw_tint=tint[agree.argmax()]
        result={'id':case['id'],'profile':case['profile'],'layout':case['layout'],'source':b,'donor_color':raw_tint.tolist(),
                'donor_estimates':tints,'roles':{}}
        for i,k in enumerate(('front-only','rear-present','flat')):
            x,y,w,h=CENTRE; obs=inputs['packed'][i,:,y//2:(y+h)//2,x//2:(x+w)//2].numpy()
            color=inputs['colors'][i].numpy()
            found,_,_=query_phases(obs,color,case['frequency_priors']['matching'],noise)
            ledger={}
            for geo,pair in (('exact',actual),('original',tuple(Carrier(v.frequency,v.offset,v.width) for v in found))):
                chosen=tint[np.argmax(abs(f@np.asarray(pair[1].frequency))/np.linalg.norm(f,axis=1))]
                baseline=evidence(obs,color,pair,noise)
                xyz={}
                for method,t in (('independent',None),('donor',chosen),('uniform',np.ones(3))):
                    delta=crossfit(obs,color,pair,noise,t,occlude=True)
                    shifted=(pair[0],replace(pair[1],offset=(pair[1].offset+0.31)%1))
                    control=crossfit(obs,color,shifted,noise,t,occlude=True)
                    xyz[method]={'rear':delta,'shifted_rear':control,'pass':min(baseline['front']+delta)>0 and delta[-1]>control[-1]}
                ledger[geo]=xyz
            result['roles'][k]=ledger
        rows.append(result)
        print(case['id'],[x['pass'] for x in result['roles']['rear-present']['exact'].values()],flush=True)
    write_json(ROOT/'color.json',{'driver':reference(__file__),'source':reference(OLDER/'result.json'),'cases': rows,
                                 'seconds':time.monotonic()-started,
                                 'scope':'Donor color is a signed three-channel axis estimated in the matched exterior, with green fixing its common direction. Direct RAW forecasts use one scalar amplitude or three independent amplitudes with identical fit and check columns. Exact geometry is a diagnostic only.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    run()
