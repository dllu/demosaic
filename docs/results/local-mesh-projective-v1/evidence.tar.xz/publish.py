"""Archive executed mesh analyses and the actual native viewing record."""

import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

root=Path(__file__).resolve().parent
repo=root.parents[2]
older=root.parent/'local-mesh-stable-v1'
images=repo/'docs/images/local-mesh-projective-v1'
output=repo/'docs/results/local-mesh-projective-v1'
images.mkdir();output.mkdir()


def portable(path):
    return reference(path)|{'path':str(path.relative_to(repo))}


def board(binding,panels):
    old=checked(binding);new=images/old.name
    shutil.copyfile(old,new)
    fresh=portable(new)
    assert fresh['sha256']==binding['sha256']
    with Image.open(new)as im:
        for p in panels:
            x,y,w,h=p['png_xywh']
            assert (w,h)==(160,160) and 0<=x<=im.width-w and 0<=y<=im.height-h
    return fresh


notes={
 'main-overcast-sky-main-overcast-sky':'The sky remains the same smooth parent in all composed views.',
 'main-building-detail-main-building-detail':'Parent beam and railing detail remains soft. Both new outputs equal the parent.',
 'main-foliage-main-foliage':'Leaf edges and dark foliage retain the exact parent.',
 'main-chain-link-fence-main-chain-link-fence':'Crossings remain distinct. Projective and planar outputs look similar. The tiny bright speck is present in all neural versions.',
 'mesh-nominal-fine-green-mesh-left':'Wider region returns the local donor fit. Short support visibly fades weak crossings left of the post.',
 'mesh-nominal-fine-green-mesh-right':'Both new compositions keep the parent, with faint diagonal modulation and absent crossings.',
 'mesh-profile3879-fine-green-mesh-left':'The fine lattice is still weak in the wider fit. Short support softens several crossings around the horizontal wire.',
 'mesh-profile3879-fine-green-mesh-right':'Soft diagonal repeat and local mottling remain unchanged in the delivered output.',
 'iso400-broken-g110-r0':'Donor perspective adds faint wire-like variation through the interrupted region. The true gap is poorly resolved.',
 'iso400-broken-g111-r0':'The second direction becomes visible in parts of the upper field. Some of the same variation spills toward the gap.',
 'iso400-occluded-g115-r0':'Fine diagonals are clearer under the projective arm and still softer than the exact reference. The change in phase is subtle.',
 'iso400-broken-g120':'The short-support panel retains part of the diagonal weak structure above the step and has less visible texture inside the gap than the broader corrections.',
 'iso400-broken-g123':'The broad corrections add faint traces in the interrupted interval. Short support reduces those traces and softens the near-gap wire.',
 'iso400-occluded-g121':'Perspective reveals secondary crossings across much of the field. Some become less pronounced under short support.',
}
views=[]
cam=read_json(root/'wider-camera.json')
for r in cam['views']:
    for k in ('RAW','input','deltas'):
        checked(r[k])
    views.append({'id':r['id'],'original':r['image'],'published':board(r['image'],r['panels']),'panels':r['panels'],
      'noise':r['noise'],'display_exposure':r['exposure'],'ROI':r['ROI'],'observed':notes[r['id']]})
assert len(views)==8
triplet_ids={'iso400-broken-g110-r0','iso400-broken-g111-r0','iso400-broken-g120','iso400-occluded-g121'}
synth=[]
for label in ('replay','fresh'):
    v=read_json(root/(label+'-render.json'))
    for d in v['boards']:
        p={k:v for k,v in d.items()if k not in ('board','triplet')}
        p['board']={'image':board(d['board']['image'],d['board']['panels']),'panels':d['board']['panels']}
        if d['id'] in triplet_ids:
            p['triplet']={'image':board(d['triplet']['image'],d['triplet']['panels']),'panels':d['triplet']['panels']}
        p['observed']=notes[d['id']]
        synth.append(p)
assert len(synth)==6 and sum('triplet'in r for r in synth)==4

view=output/'actual-viewing.json'
write_json(view,{'recorded_utc':datetime.now(UTC).isoformat(),'native_camera_viewed':True,'native_synthetic_viewed':True,
                 'camera':views,'synthetic':synth,'scope':'All eight final standing views, both ISO100 AHD references and both cab JPEGs were inspected. Six exact-target synthetic native comparison boards and four triplets were viewed. Real reference captures are qualitative.'})

files={name:root/name for name in (
 'probe.py','run.log','result.json','donor-geometry.py','geometry.log','geometry.json','donor-color.py','color.log','color.json',
 'deliver.py','delivery.log','delivery.json','deliver-short.py','short-support.py','fresh.py','fresh-plan.json','fresh.log','fresh.json',
 'camera.py','camera.log','camera.json','camera-first.py','camera-first.log','wider-camera.py','wider-camera.log','wider-camera.json',
 'summarize.py','replay-summary.json','fresh-summary.json','render.py','replay-render.json','fresh-render.json','publish.py')}
for folder in ('cases','geometry-cases','delivery-cases','fresh-cases'):
    files.update({f'{folder}/{p.name}':p for p in (root/folder).glob('*.json')})
for name in ('run.py','mesh.py','support.py','guard.py','audit.py','confirm.py','stabilize.py','standing.py'):
    files[f'dependency/{name}']=older/name
files['dependency/joint-targets.py']=root.parent/'joint-mesh-phase-v1/run.py'
files['dependency/native-board.py']=repo/'scripts/report_scene_wave_guides.py'
for mode in ('replay','fresh'):
    shutil.copyfile(root/(mode+'-summary.json'),output/(mode+'-summary.json'))
archive=output/'evidence.tar.xz'
with tarfile.open(archive,'x:xz',preset=4)as t:
    for name,p in files.items(): t.add(p,arcname=name)
with tarfile.open(archive,'r:xz')as t:
    assert set(t.getnames())==set(files)
    for name,p in files.items():
        assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==reference(p)['sha256']
write_json(output/'publication.json',{
 'evidence':portable(archive),'actual_viewing':portable(view),
 'summaries':{mode:portable(output/(mode+'-summary.json'))for mode in ('replay','fresh')},
 'archived_originals':{name:reference(p)for name,p in files.items()},
 'camera':views,'synthetic':synth,'scoped_numeric_complete':True,'native_viewing_complete':True,
 'training_performed':False,'comparable_primary_scores':None,
 'scope':'One archived 48-case replay, one new 24-case paired panel, and both standing GFX families. Synthetic and real views use their declared respective local EMA checkpoints. Reviewed images remain native. Large retained input and correction arrays remain in the local cache. The first camera attempt compared list and tuple representation of the same frequency pairs; it is retained with the fixed replay.'})
