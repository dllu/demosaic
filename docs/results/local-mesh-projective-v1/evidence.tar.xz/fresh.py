"""Check donor geometry and short support on six fresh mesh geometries."""
import importlib.util
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from deliver import ROOT,OLDER,CENTRE,DISPLAY,shift_prior,proposals,window,score,sample
from run import SHIFTS
from stabilize import correction as original,median_correction


def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


refined=load('deliver-short')
short=load('short-support')
METHODS=('anchored','projective','short-support')


def estimate(field,packed,variance,colors,freq,proposal,noise):
    collected={k:[] for k in METHODS}
    x,y,w,h=CENTRE
    if proposal is None:
        return {k:np.zeros_like(window(field,DISPLAY)) for k in METHODS}
    frames=[]
    for dx,dy in SHIFTS:
        box=(x+dx,y+dy,w,h)
        d1,_=original(field,packed,variance,colors,box,DISPLAY,freq,noise,packed_offset=dx//2)
        f,g=shift_prior(*proposal['projective'],dx,dy)
        d2,detail=refined.correction(field,packed,variance,colors,box,DISPLAY,f,g,noise,packed_offset=dx//2)
        d3=short.shorten(d2,window(packed,box,phase=2),colors,detail.get('phase_candidates'),noise,box,DISPLAY,dx//2)
        for label,delta in zip(METHODS,(d1,d2,d3),strict=True):
            collected[label].append(delta)
    return {k:median_correction(v) for k,v in collected.items()}


@torch.inference_mode()
def main():
    plan=read_json(OLDER/'plan.json'); ckpt=plan['checkpoint']
    destination=ROOT/'fresh-cases';destination.mkdir()
    spec={'driver':reference(__file__),'checkpoint':ckpt,'parent_plan':reference(OLDER/'plan.json'),
          'sources':[reference(ROOT/f'{p}.py')for p in ('donor-geometry','deliver','deliver-short','short-support')],
          'geometries':list(range(120,126)),'layout':['occluded','broken'],'noise':plan['noise'],'shifts':SHIFTS,
          'roles':['front-only','rear-present','flat'],'variants':list(METHODS),'native_ROI':DISPLAY,
          'scope':'Fresh exact synthetic geometries and observations. Local base prediction is held fixed under all donor interventions. Both competing donor kinds use identical local RAW. Short support can only attenuate the delivered projective correction before the common 13-shift median.'}
    write_json(ROOT/'fresh-plan.json',spec)
    model,state=load_scene_checkpoint(checked(ckpt),device='cuda',weights='ema',expected_sha256=ckpt['sha256'])
    assert state['step']==2000;model.mode='none';del state
    launch=time.monotonic(); records=[]
    with ieee_fp32():
        for j,(profile,noise) in enumerate(plan['noise'].items()):
            model.base.set_noise(noise['shot'],noise['read'])
            for li,layout in enumerate(spec['layout']):
                for index in spec['geometries']:
                    label=f'{profile}-{layout}-g{index}'
                    seed=15788940594+j*97501+li*56967+index*157
                    inp,surrounds,masks,meta=sample(index,layout,noise,seed)
                    local=model(*(inp[k].cuda() for k in ('packed','variance','colors','wb','matrix'))).cpu().numpy()
                    packed,variance,colors,truth=(inp[k].numpy()for k in ('packed','variance','colors','target'))
                    metrics={'parent':score(local,None,truth,masks)}; arrays={}; exterior={}
                    for name,scene in surrounds.items():
                        estimates,trace=proposals(scene,colors[0],(256,256,256,256),noise,80)
                        exterior[name]=trace
                        corrections={k:[] for k in METHODS}
                        for role in range(3):
                            methods=estimate(local[role],packed[role],variance[role],colors[role],trace.get('prior_frequencies'),estimates,noise)
                            for kind,delta in methods.items(): corrections[kind].append(delta)
                        for kind,items in corrections.items():
                            key=name+'-'+kind; arrays[key]=np.stack(items)
                            metrics[key]=score(local,arrays[key],truth,masks)
                    path=destination/(label+'.npz')
                    np.savez_compressed(path,**{k:v.numpy() for k,v in inp.items()},**masks,parent=local,**arrays)
                    record={'id':label,'profile':profile,'layout':layout,'seed':seed,'metrics':metrics,'array':reference(path),
                            'priors':exterior,'sensor':meta,'input_fingerprints':{k:fingerprint(v)for k,v in inp.items()}}
                    result=destination/(label+'.json');write_json(result,record);records.append(reference(result))
                    print(label,[(k,round(v['response'][0],3),round(v['gap_added_RMS_DN16'] or 0,3),v['changed']) for k,v in metrics.items() if k=='parent' or k.startswith('matching-')],round(time.monotonic()-launch,1),flush=True)
    assert len(records)==24
    write_json(ROOT/'fresh.json',{'plan':reference(ROOT/'fresh-plan.json'),'cases':records,'seconds':time.monotonic()-launch})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
