"""Locate where the local mesh check loses a weak second direction."""

import itertools
import os
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
import torch

from demosaic._mesh_frequency import query_phases
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
OLDER = ROOT.parent / 'local-mesh-stable-v1'
sys.path.insert(0, str(OLDER))
from run import sample, prior, CENTRE
from mesh import Carrier, ribbon, phase, projected_fit, split_fit, fields


def evidence(raw, colors, pair, noise, column_offset=0):
    x, y = native_sites(raw.shape[-2:], (-127.5, -127.5))
    slot = np.broadcast_to((np.indices(raw.shape[-2:])[1] + column_offset) % 4, raw.shape)
    cfa = np.broadcast_to(np.asarray(colors)[:, None, None], raw.shape)
    affine = np.stack((np.ones_like(x), x/128, y/128), axis=-1)
    front, rear = (ribbon(x, y, c) for c in pair)
    shifted = ribbon(x, y, replace(pair[1], offset=(pair[1].offset + 0.31) % 1))
    rows = {}
    for name, other, test in (('front', rear, front), ('rear', front, rear),
                              ('shifted', front, shifted), ('occluded', front, rear * (1 - front))):
        background = np.concatenate((affine, other[..., None]), axis=-1)
        gains = []
        for a,b in (((1,),2), ((2,),1), ((1,2),3)):
            improvement = 0.0
            for color in range(3):
                train = (cfa==color) & np.isin(slot,a)
                check = (cfa==color) & (slot==b)
                var = noise['shot'] * max(1e-4, float(np.median(raw[train]))) + noise['read']
                base, projection, amplitude, _, _ = projected_fit(
                    background[train], test[train,None], raw[train], np.full(train.sum(),1/var))
                delta = (test[check,None] - background[check] @ projection) @ amplitude
                residual = raw[check] - background[check] @ base
                improvement += float(np.sum(delta*(2*residual-delta)) / var)
            gains.append(improvement)
        rows[name] = gains
    rows['passes'] = bool(min(rows['front']+rows['rear'])>0 and rows['rear'][-1]>rows['shifted'][-1])
    # The guarded delivery additionally needs both A/B global regression scores.
    keep = slot!=0
    fold = np.broadcast_to(np.indices(raw.shape[-2:]).sum(0)%2,raw.shape)
    for name, ordered, method in (('global_front', pair[::-1], 'add'), ('global_rear', pair, 'adaptive')):
        other,basis=fields(x,y,ordered)
        null=np.concatenate((affine,other[...,None]),axis=-1)
        rows[name]=split_fit(null[keep], {k:v[keep] for k,v in basis.items()},raw[keep].astype(float),cfa[keep],fold[keep],(noise['shot'],noise['read']),method)
    return rows


def fit_reserved(raw, colors, front, rear, noise, *, refine_frequency=False, offset=0):
    """Select only on the reserved sites. Fit signed per-color amplitudes."""
    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
    slot=np.broadcast_to((np.indices(raw.shape[-2:])[1]+offset)%4,raw.shape)
    cfa=np.broadcast_to(np.asarray(colors)[:,None,None],raw.shape)
    u,v=x[slot==0],y[slot==0]
    p=ribbon(u,v,front)
    backdrop=np.stack((np.ones_like(u),u/128,v/128,p),axis=-1)
    parts=[]
    for c in range(3):
        use=cfa[slot==0]==c
        basis,_=np.linalg.qr(backdrop[use],mode='reduced')
        sensor=raw[slot==0][use].astype(float)
        residual=sensor-basis@(basis.T@sensor)
        invvar=1/(noise['shot']*max(1e-4,float(np.median(sensor)))+noise['read'])
        parts.append((use,basis,residual,invvar))

    def select(frequencies, offsets):
        bank = [(f, q) for f in frequencies for q in offsets]
        best = None
        for k in range(0,len(bank),32):
            chunk=bank[k:k+32]
            f=np.asarray([x[0] for x in chunk])
            shift=np.asarray([x[1] for x in chunk])
            cycle=u[:,None]*f[:,0]+v[:,None]*f[:,1]-shift
            distance=(cycle-np.rint(cycle))/rear.width
            profiles=np.exp(-.5*distance**2)
            values=np.zeros(len(chunk))
            for use,basis,residual,invvar in parts:
                wire=profiles[use]
                decor=basis.T@wire
                power=np.sum(wire**2,axis=0)-np.sum(decor**2,axis=0)
                values+=invvar*(residual@wire)**2/np.maximum(power,1e-12)
            i=np.argmax(values)
            candidate=(float(values[i]),tuple(f[i]),float(shift[i]%1))
            if best is None or candidate[0]>best[0]:
                best=candidate
        return best

    f=np.asarray(rear.frequency)
    around=[f]
    if refine_frequency:
        around=[f+np.asarray(delta)/384 for delta in itertools.product((-1,0,1),repeat=2)]
    coarse=select(around,rear.offset+np.arange(12)/12)
    f=np.asarray(coarse[1])
    around=[f]
    if refine_frequency:
        around=[f+np.asarray(delta)/1152 for delta in itertools.product((-1,0,1),repeat=2)]
    fine=select(around,coarse[2]+np.arange(-2,3)/48)
    return replace(rear,frequency=fine[1],offset=fine[2]),fine[0]


def similarity(pair, truth, raw):
    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
    a,b=(ribbon(x,y,c).ravel() for c in (pair[1],truth[1]))
    a=a-a.mean();b=b-b.mean()
    return float(a@b/np.linalg.norm(a)/np.linalg.norm(b))


def synthetic():
    old=read_json(OLDER/'result.json')
    plan=read_json(checked(old['plan']))
    output=ROOT/'cases';output.mkdir()
    receipts=[]
    start=time.monotonic()
    for binding in old['cases']:
        case=read_json(checked(binding))
        noise=plan['noise'][case['profile']]
        inp,_,_,_=sample(case['g'],case['layout'],noise,case['sensor_seed'])
        assert {k:fingerprint(v) for k,v in inp.items()}==case['input_fingerprints']
        record={'source':binding,'id':case['id'],'profile':case['profile'],'layout':case['layout'],'roles':{}}
        f=case['frequency_priors']['matching']
        spatial=prior.guides(case['g'])
        oracle=tuple(spatial)
        oracle_planar=tuple(replace(g,perspective=(0,0)) for g in spatial)
        for role in (0,1,2):
            key=('front-only','rear-present','flat')[role]
            x,y,w,h=CENTRE
            raw=inp['packed'][role,:,y//2:(y+h)//2,x//2:(x+w)//2].numpy()
            colors=inp['colors'][role].numpy()
            found,_,reserve_score=query_phases(raw,colors,f,noise)
            base=tuple(Carrier(g.frequency,g.offset,g.width) for g in found)
            cond,cond_score=fit_reserved(raw,colors,*base,noise)
            tuned,tuned_score=fit_reserved(raw,colors,*base,noise,refine_frequency=True)
            row={}
            for name,pair in (('original',base),('conditional-phase',(base[0],cond)),('conditional-search',(base[0],tuned)),
                              ('oracle-planar',oracle_planar),('oracle-perspective',oracle)):
                row[name]={'candidates':[asdict(v) for v in pair], 'rear_template_cosine':similarity(pair,oracle,raw),
                           'evidence':evidence(raw,colors,pair,noise)}
            row['reserve_scores']=[reserve_score,cond_score,tuned_score]
            record['roles'][key]=row
        p=output/(case['id']+'.json');write_json(p,record);receipts.append(reference(p))
        print(case['id'],[(k,round(v['rear_template_cosine'],3),v['evidence']['passes']) for k,v in record['roles']['rear-present'].items() if isinstance(v,dict)],flush=True)
    write_json(ROOT/'result.json',{'driver':reference(__file__),'source':reference(OLDER/'result.json'),'cases':receipts,
        'seconds':time.monotonic()-start,'scope':'The same 48 earlier raw pairs with bitwise matching input fingerprints. Central crop only. The oracle branches use target geometry as a diagnostic. All measured search modes use only the existing phase-reserve quarter. Candidate predictive scores use disjoint remaining columns.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    torch.set_num_threads(2)
    synthetic()
