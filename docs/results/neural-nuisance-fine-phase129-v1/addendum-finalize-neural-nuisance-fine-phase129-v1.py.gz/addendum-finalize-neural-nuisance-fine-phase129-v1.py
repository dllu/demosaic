"""Seal the original38 figures and six later native comparisons together."""
import gzip
from datetime import datetime, timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-phase129-pilot-v1'
destination = repo / 'docs/results/neural-nuisance-fine-phase129-v1'
prepared = read_json(root / 'publication-prepared.json')
extra = read_json(root / 'publication-extra-prepared.json')
assert len(prepared['images']) == 38 and len(extra['images']) == 6
checked(extra['base_preparation'])

# These images were actually inspected through view_image, before this receipt.
# Keep the original preparation and original11-sheet manifest byte-exact.
notes = [
    ('base', [0, 1, 2, 3],
     'All12 finite comparisons, bark/fur, sky and primary building viewed. '
     '400/far modulation stays close to guided broad-only; high-noise weak '
     'directions mostly absent. Bark/fur remain soft, sky unchanged. Residual '
     'building dark/color bands persist.'),
    ('base', [4, 5, 6, 7],
     'Both cab profiles/ROIs/JPEGs, foliage, coarse fence, correction stress '
     'views and both NN400 triplets viewed. Fine cab lattice is more visible '
     'with conspicuous purple/green periodic chroma and excessive regularity; '
     'not faithful mesh recovery. Foliage remains soft. Building artifacts '
     'are modestly larger. ISO100/AHD/JPEG views are independent references, '
     'not exact GT.'),
    ('base', [8, 9, 10],
     'Both analytic400 exact-GT triplets, both paired analytic broad-only/fine '
     'boards and all fixed0/2/4 tradeoff curves viewed. Low-prior output '
     'retains the broad-only result. Quiet/increment tradeoffs and '
     'higher-noise limitations remain visible.'),
    ('extra', [0, 1],
     'All four direct analytic cab before/after boards and both1600/far '
     'analytic exact-GT triplets viewed. Both fine cab families are more '
     'visible in each profile/ROI, with false purple/green grid texture. '
     '1600 finite changes are very small; most weaker detail is still absent. '
     'Noisy/reference transforms and native160 crop pixels are unchanged.'),
]
manifests = {
    'base': root / 'contact-sheets/manifest.json',
    'extra': root / 'extra-viewing/contact-sheets/manifest.json',
}
receipts = []
for i, (group, sheets, note) in enumerate(notes):
    path = root / f'viewing-batch-{i}.json'
    assert not path.exists()
    manifest = read_json(manifests[group])
    write_json(path, {
        'group': group, 'sheets': sheets, 'actually_viewed': True,
        'method': 'Exact unresized contact sheets through tools.view_image',
        'manifest': reference(manifests[group]),
        'sheet_images': [manifest['sheets'][s]['image'] for s in sheets],
        'notes': note,
        'recorded_UTC': datetime.now(timezone.utc).isoformat(),
    })
    receipts.append(path)
for group, path in manifests.items():
    m = read_json(path)
    viewed = [s for g, indices, _ in notes if g == group for s in indices]
    assert sorted(viewed) == list(range(len(m['sheets'])))
    assert m['no_resize'] and m['source_images'] == (38 if group == 'base' else 6)
    for sheet in m['sheets']:
        checked(sheet['image'])

archives = list(prepared['archives'])
already = {item['original']['path'] for item in archives}
sources = [p for p in sorted(root.rglob('*')) if p.is_file()
           and root / 'work' not in p.parents and p.suffix in {'.json', '.log', '.py'}]
sources.extend(repo / name for name in [
    '.cache/native-contact-sheets-v1.py',
    '.cache/finalize-neural-nuisance-fine-phase129-v1.py',
    '.cache/summarize-fine-phase129-v1.py',
    '.cache/fine-phase129-numerical-summary-v1.json',
    '.cache/fine-band-final-tests-v1.log',
    '.cache/fine-band-final-ruff-v1.log',
    '.cache/fine-phase-H1-parity-v1.py',
    '.cache/fine-phase-H1-parity-v1.log',
    '.cache/fine-cab-before-after-v1.py',
    '.cache/fine-cab-before-after-v1.log',
    '.cache/fine-1600-triplets-v1.py',
    '.cache/fine-1600-triplets-v1.log',
    '.cache/fine-scene-maxima-v1.py',
    '.cache/fine-scene-maxima-v1.log',
    '.cache/close-fine-phase-publication-prep-v1.py',
    '.cache/close-fine-phase-publication-prep-v1.log',
    '.cache/fine-phase-publication-prep-result-v1.json',
])
for source in sources:
    assert source.is_file(), source
    ref = reference(source)
    if ref['path'] in already:
        continue
    name = str(source.relative_to(root) if root in source.parents else source.name).replace('/', '--')
    target = destination / ('addendum-' + name + '.gz')
    with target.open('xb') as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    archives.append({'original': ref, 'published': reference(target), 'decompressed_bytes_exact': True})
    already.add(ref['path'])
for item in archives:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
figures = prepared['images'] + extra['images']
assert len(figures) == len({f['relative'] for f in figures}) == 44
for item in figures:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
prepared.update(
    archives=archives, images=figures,
    original_preparation=reference(root / 'publication-prepared.json'),
    extra_preparation=reference(root / 'publication-extra-prepared.json'),
    original_viewer=prepared['viewer'],
    viewer=reference(repo / 'docs/images/neural-nuisance-fine-phase129-v1/native-viewer-with-extras.html'),
    viewing={'actually_viewed': True, 'figures': 44, 'contact_sheets': 13,
             'manifests': {k: reference(v) for k, v in manifests.items()},
             'batches': [reference(p) for p in receipts]},
    H1_control_parity=reference(root / 'all-H1-control-parity.json'),
    phase_array_comparison=reference(root / 'phase-array-comparison.json'),
    correction_maxima=reference(root / 'scene-correction-maxima.json'),
    numerical_summary=reference(repo / '.cache/fine-phase129-numerical-summary-v1.json'),
    status='complete; additional fine structure with false-colour and error costs',
    quality_decision='Analytic1600/far weak response0.98935% to2.03712%, same quiet error, '
        'weak-increment15.62105 to15.61633 DN16; source1 drives gain and increment '
        'remains0.49946% above parent.400/far unchanged. Cab crossing/lattice visibility '
        'improves but conspicuous purple/green periodic chroma prevents a faithful-recovery '
        'claim. Building/foliage/fence corrections rise. Neural1600 increment error '
        'worsens. Optional development implementation; V120 remains general baseline.',
    comparison_baselines=[reference(repo / 'docs/results' / name / 'publication.json')
        for name in ['neural-nuisance-guided-phase129-v1', 'neural-nuisance-phase129-v1']],
    scope_clarification='Adaptive48-case development cohort, not generalization. Broad '
        'phase correction retained; separate fine A/B proposals and conditional tests '
        'project the original broad H1 design, not jointly delivered phase profiles. '
        'Both nuisance arms use A-only own-color neural guides; no neural replay or '
        'weight update. Raw H1 all288 outputs exact. Real references independent and '
        'never scored as GT; correction magnitudes are not reference errors.',
    published_UTC=datetime.now(timezone.utc).isoformat(),
)
assert not (destination / 'publication.json').exists()
write_json(destination / 'publication.json', prepared)
print(len(archives), 'exact archives;', len(figures), 'figures actually viewed on13 sheets')
