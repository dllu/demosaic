"""Exact archive publication, after the complete neural-nuisance review."""
import gzip,html,shutil,sys,tarfile,io
from pathlib import Path
import numpy as np
from PIL import Image
from audit_checkpoint_pilot import crop
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.archive_metrics import noisy_malvar
R=Path.cwd();root=R/'.cache/experiments/neural-nuisance-fine-phase129-pilot-v1';docs=R/'docs/results/neural-nuisance-fine-phase129-v1';images=R/'docs/images/neural-nuisance-fine-phase129-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
assert read_json(root/'followup/result.json')['returncode']==0
plan=read_json(root/'plan.json');collection=read_json(root/'collection.json');records={r['id']:r for r in collection['rows']}
report=read_json(root/'native/report.json');base=read_json(root/'report/report.json');summary=read_json(root/'summary-review/summary.json')
extras = [R / name for name in ['tests/test_fine_carrier_proposals.py', '.cache/fine-band-tests-v1.log', '.cache/fine-band-tests-v2.log', '.cache/fine-band-regression-v1.log', '.cache/fine-band-ruff-v1.log', '.cache/launch-neural-nuisance-fine-phase129-v1.py', '.cache/launch-neural-nuisance-fine-phase129-v1.log', '.cache/prepare-neural-nuisance-fine-phase129-v1.log', '.cache/extra-neural-fine-phase129-stress-v1.py', '.cache/extra-neural-fine-phase129-stress-v1.log', '.cache/analytic-fine-phase-triplets-v1.py', '.cache/analytic-fine-phase-triplets-v1.log', '.cache/fine-phase-paired-boards-v1.py', '.cache/fine-phase-paired-boards-v1.log', '.cache/publish-neural-nuisance-fine-phase129-v1.py', 'scripts/audit_neural_nuisance_inputs.py', '.cache/diagnose-fine-band-proposals-v1.py', '.cache/diagnose-fine-band-proposals-v1.log', '.cache/diagnose-fine-band-proposals-v2.py', '.cache/diagnose-fine-band-proposals-v2.log', '.cache/fine-band-proposal-diagnostic-v1.json', '.cache/fine-band-proposal-diagnostic-v2.json']]
assert all(p.is_file() for p in extras), [str(p) for p in extras if not p.is_file()]
docs.mkdir(exist_ok=False);images.mkdir(exist_ok=False);archives=[];figures=[];channels=0
def archive(source,name):
 source=Path(source);dest=docs/(name+'.gz');data=source.read_bytes();encoded=gzip.compress(data,mtime=0)
 with dest.open('xb')as f:f.write(encoded)
 assert gzip.decompress(dest.read_bytes())==data
 archives.append({'original':reference(source),'published':reference(dest),'decompressed_bytes_exact':True})
def copy_image(source,relative,metadata):
 dest=images/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(checked(source),dest);assert reference(dest)['sha256']==source['sha256'];figures.append({'original':source,'published':reference(dest),'relative':relative,'metadata':metadata})
for figure in report['figures']+report['stress_figures']+read_json(root/'extra-stress/report.json')['figures']:
 row=figure['source'];sample=row['sample'];roi=figure['ROI_xywh'];exposure=figure['display_exposure'];png=np.asarray(Image.open(checked(figure['image'])))
 with np.load(checked(row['arrays']),allow_pickle=False)as z:
  data={k:z[k][sample:sample+1]for k in ['wb','matrix','packed','colors']};noisy=z['noisy_rgb']if row['kind']=='mesh'else noisy_malvar(data)
 parent=np.load(checked(row['parent']))[sample:sample+1]
 for panel in figure['panels']:
  label=panel['label'];x,y,w,h=panel['xywh']
  if label=='Broad+fine A t2':value=np.load(checked(records[row['id']]['predictions']['conditional-local-t2']))[None]
  elif label=='Broad+fine NN t2':value=np.load(checked(records[row['id']]['predictions']['local-t2']))[None]
  elif label=='Noisy Malvar':value=noisy
  elif label in ['V120','V143']:value=parent
  else:
   original=np.asarray(Image.open(checked(figure['original_aggregation_board'])));np.testing.assert_array_equal(png[y:y+h,x:x+w],original[y:y+h,x:x+w]);channels+=h*w*3;continue
  expected=crop(value,data,roi,exposure);np.testing.assert_array_equal(png[y:y+h,x:x+w],expected);channels+=expected.size
 copy_image(figure['image'],('stress/'if 'selection'in figure else'matched/')+Path(figure['image']['path']).name,figure)
for case in ['iso400-index0008-role2','iso400-index0024-role2']:
 f=next(f for f in base['figures']if Path(f['image']['path']).stem==case+'-triplet');copy_image(f['image'],'triplets/'+Path(f['image']['path']).name,f)
for figure in read_json(root/'analytic-triplets/report.json')['figures']:copy_image(figure['image'],'triplets/'+Path(figure['image']['path']).name,figure)
for figure in read_json(root/'waveform-paired/report.json')['figures']:copy_image(figure['image'],'paired/'+Path(figure['image']['path']).name,figure)
for figure in summary['plots']:copy_image(figure,'plots/'+Path(figure['path']).name,{'kind':'fixed-threshold-tradeoff-plot'})
assert len(figures)==38
text='<!doctype html><meta charset="utf-8"><title>Neural nuisance reconstruction</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:28px 0;overflow:auto}img{max-width:none}</style><h1>Phase-aligned measurements with a fixed global background</h1><p>Native crop pixels are unresized; use browser zoom100%. Matched analytic and neural phase localt2 controls. Fixed global background, global competing H1 subtraction, local129 own-color A-only neural-range-guided phase kernel. Paired boards compare analytic nuisance broad-only vs broad+fine, both with identical A-only neural guides at identical coordinates and display transforms. Two-source adaptive development pilot, three noise priors. ISO100/AHD real references are qualitative, never exact GT; both cab JPEGs retained. Stress ROIs selected after inference by largest correction RMS, without reference. Plot pixels are charts.</p>'
for f in figures:
 name=html.escape(f['relative']);text+='<figure><figcaption>'+name+'</figcaption><a href="'+name+'"><img src="'+name+'"></a></figure>\n'
(images/'native-viewer.html').write_text(text)
for file in sorted(root.rglob('*')):
 if not file.is_file()or root/'work'in file.parents or file.suffix not in ['.json','.log','.py']:continue
 archive(file,'producer-'+str(file.relative_to(root)).replace('/','--'))
for file in extras:archive(file,'extra-'+file.name)
files=[p for p in (root/'work').rglob('*.py')];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as tar:
 for p in sorted(files):
  data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(root/'work')));info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
compressed=gzip.compress(buffer.getvalue(),mtime=0);source_tar=docs/'executed-source.tar.gz';source_tar.write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz')as tar:
 for member in tar.getmembers():assert tar.extractfile(member).read()==(root/'work'/member.name).read_bytes()
write_json(root/'publication-prepared.json',{'archives':archives,'source_snapshot':reference(source_tar),'source_files_exact':len(files),'images':figures,'viewer':reference(images/'native-viewer.html'),'matched_stress_RGB_channels_exact':channels,'base_independent_audit':reference(root/'independent-audit.json'),'background_input_independent_audit':reference(root/'background-independent-audit.json'),'script':reference(__file__),'new_neural_forwards':0,'viewing':'pending; actual viewing receipt required before final publication','scope':'Exact source/receipt archive and native boards. Frozen generic reporter wording is inherited; current conditional/neural modes are phase-kernel reconstruction above fixed global analytic/neural backgrounds. Raw H1 uses its own original scores. Prior/current broad branches share geometry/background/phase/support; additional fine proposals have separate A/B matching and validation, with broad carriers included in fine nuisance; the original broad correction is retained.'})
print('prepared',len(figures),'images;',channels,'matched/stress exact channels; archives',len(archives),flush=True)
