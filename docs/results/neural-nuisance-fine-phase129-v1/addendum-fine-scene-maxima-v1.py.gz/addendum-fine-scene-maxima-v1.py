"""Scene correction maxima, without accessing independent real references."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

root=Path.cwd()/'.cache/experiments/neural-nuisance-fine-phase129-pilot-v1'
old=root.parent/'neural-nuisance-guided-phase129-pilot-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
plan=read_json(root/'plan.json');before={r['id']:r for r in read_json(old/'collection.json')['rows']};after={r['id']:r for r in read_json(root/'collection.json')['rows']};rows=[]
for case in ['main-building-detail','main-foliage','main-chain-link-fence','mesh-nominal','mesh-profile3879']:
    source=next(r for r in plan['rows']if r['id']==case)
    parent=np.load(checked(source['parent']))[source['sample']].astype('f8')
    for label,records in [('broad-only',before),('broad+fine',after)]:
        for method in ['conditional-local-t2','local-t2']:
            value=np.load(checked(records[case]['predictions'][method])).astype('f8')
            error=np.mean((value-parent)**2,axis=0)
            integral=np.pad(error.cumsum(0).cumsum(1),((1,0),(1,0)))
            sums=integral[160:,160:]-integral[:-160,160:]-integral[160:,:-160]+integral[:-160,:-160]
            y,x=np.unravel_index(np.argmax(sums),sums.shape)
            rows.append({'case':case,'variant':label,'method':method,'ROI_xywh':[int(x),int(y),160,160],'maximum_correction_RMS_DN16':float(np.sqrt(sums[y,x]/160**2)*65535)})
write_json(root/'scene-correction-maxima.json',{'script':reference(__file__),'current':reference(root/'collection.json'),'baseline':reference(old/'collection.json'),'rows':rows,'reference_arrays_loaded':0,'new_neural_forwards':0,'scope':'Maximum native160 camera-RGB change from fixed V120 parent, exhaustive integral-image scan. Magnitude only, not real-reference error or quality score; no ref-dependent ROI selection.'})
print(rows)
