"""Input-only coarse/fine discovery audit; no parent, GT, reference or neural arrays."""
import os
import time
from pathlib import Path
import numpy as np
from demosaic.carrier_spectrum import discovery_weights, weighted_spectrum
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.local_validated_waves import LocalWaveConfig, _wave_columns, fit_local_candidate, match_directions
from pilot_neural_nuisance import input_arrays, raw_frame

os.sched_setaffinity(0,[16,17]);os.nice(10)
root=Path('.cache/experiments/neural-nuisance-guided-phase129-pilot-v1').resolve()
plan=read_json(root/'plan.json');collection=read_json(root/'collection.json')
assert read_json(root/'controller-result.json')['all_stages_succeeded']
records={r['id']:r for r in collection['rows']}
config=LocalWaveConfig(**plan['geometry_config'])
cases=['mesh-nominal','mesh-profile3879','main-building-detail','main-foliage','main-chain-link-fence','iso400-index0008-role2','iso400-index0024-role2']
results=[];began=time.monotonic()
for case in cases:
    row=next(r for r in plan['rows']if r['id']==case)
    data=input_arrays(row);raw=raw_frame(data)
    colors=np.tile(data['colors'].reshape(2,2),(raw.shape[0]//2,raw.shape[1]//2))
    mask=stratified_split(raw.shape,config.split_seed)
    background=read_json(checked(records[case]['background_receipt']))
    np.testing.assert_array_equal(mask,np.load(checked(background['mask_A'])))
    n=config.window
    positions=[np.unique(np.r_[np.arange(0,length-n+1,config.stride),length-n])for length in raw.shape]
    for y in positions[0]:
        for x in positions[1]:
            region=np.s_[y:y+n,x:x+n];tile,layout=raw[region],colors[region]
            stored=next(r for r in records[case]['aux']['records']if r['xy']==[x,y])
            folds=[]
            for fold,split in enumerate([mask[region],~mask[region]]):
                candidate=fit_local_candidate(tile,layout,split,shot=row['noise']['shot'],read=row['noise']['read'],config=config)
                np.testing.assert_array_equal(candidate.frequencies_xy,stored['arms']['H1-']['frequencies'][fold])
                green=((layout==1)&split).ravel()
                nuisance=candidate.design
                weights=discovery_weights(tile,green,nuisance[:,:candidate.wave_slices[0][0]],shot=row['noise']['shot'],read=row['noise']['read'],hann=True)
                fy,fx=np.meshgrid(np.fft.fftfreq(n),np.fft.fftfreq(n),indexing='ij')
                radius=np.hypot(fx,fy)
                allowed=(radius>=1/16)&(radius<=.24)&((fy>0)|((fy==0)&(fx>0)))
                for frequency in candidate.frequencies_xy:
                    for h in range(1,int(.24/np.linalg.norm(frequency))+1):
                        harmonic=h*np.asarray(frequency)
                        distance=np.minimum(np.hypot(fx-harmonic[0],fy-harmonic[1]),np.hypot(fx+harmonic[0],fy+harmonic[1]))*n
                        allowed&=distance>config.match_native_bins
                proposed=[];benefits=[]
                xx,yy=np.meshgrid(np.arange(n),np.arange(n))
                for direction in (0,1):
                    power=weighted_spectrum(tile,green,nuisance,weights)
                    available=allowed.copy()
                    if proposed:
                        f=proposed[0]
                        alignment=np.abs((fx*f[0]+fy*f[1])/np.maximum(radius*np.linalg.norm(f),1e-30))
                        available&=alignment<=np.cos(np.deg2rad(config.family_degrees))
                    index=np.unravel_index(np.argmax(np.where(available,power,-np.inf)),tile.shape)
                    frequency=(float(fx[index]),float(fy[index]))
                    proposed.append(frequency);benefits.append(float(power[index]))
                    nuisance=np.column_stack((nuisance,_wave_columns(xx,yy,frequency)))
                folds.append({'fold':fold,'coarse':candidate.frequencies_xy,'fine_FFT_proposals':proposed,'weighted_benefits':benefits})
            matched=match_directions(folds[0]['fine_FFT_proposals'],folds[1]['fine_FFT_proposals'],tile.shape,config.match_native_bins,matching='cardinality')
            results.append({'case':case,'xy':[int(x),int(y)],'folds':folds,'matched':matched,'actual_coarse_geometry_exact':True})
    print('case complete',case,flush=True)
write_json(Path('.cache/fine-band-proposal-diagnostic-v1.json'),{'script':reference(__file__),'plan':reference(root/'plan.json'),'collection':reference(root/'collection.json'),'rows':results,'seconds':time.monotonic()-began,'frequency_band_native':[1/16,.24],'coarse_harmonic_exclusion_bins':config.match_native_bins,'new_neural_forwards':0,'parent_GT_reference_or_neural_arrays_loaded':0,'scope':'A-only weighted Hann residual spectrum after the unchanged global analytic/coarse-pair design. Fine band is additive, never removes the lower-frequency/27.7px proposal. Excludes1.5-native-bin neighborhoods of coarse integer harmonics before taking two angularly separated fine peaks. Input-only A/B geometry agreement, no restoration/quality claim or calibrated confidence; protected media remain cached/read-only/out of training.'})
print('closed',len(results),'tiles',time.monotonic()-began,flush=True)
