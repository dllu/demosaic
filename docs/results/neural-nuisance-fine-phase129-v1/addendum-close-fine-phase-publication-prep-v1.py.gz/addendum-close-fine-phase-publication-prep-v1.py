"""Wait for exact pilot owners, then prepare native evidence once, without replay."""
import os
import subprocess
import sys
import time
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-phase129-pilot-v1'
os.sched_setaffinity(0, [16,17])
for path in [root/'launch.json',root/'followup/launch.json']:
    identity=read_json(path)
    while True:
        try:
            process=psutil.Process(identity['pid'])
            if process.create_time()!=identity['create_time'] or process.status()==psutil.STATUS_ZOMBIE:
                break
        except psutil.NoSuchProcess:
            break
        time.sleep(5)
assert read_json(root/'controller-result.json')['all_stages_succeeded']
assert read_json(root/'followup/result.json')['returncode']==0
env=dict(os.environ,PYTHONPATH=str(repo/'src')+':'+str(repo/'scripts'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
stages=[]
for name,script,args in [
    ('extra-neural-fine-phase129-stress-v1','extra-neural-fine-phase129-stress-v1.py',[]),
    ('analytic-fine-phase-triplets-v1','analytic-fine-phase-triplets-v1.py',[]),
    ('fine-phase-paired-boards-v1','fine-phase-paired-boards-v1.py',[]),
    ('publish-neural-nuisance-fine-phase129-v1','publish-neural-nuisance-fine-phase129-v1.py',[]),
    ('native-fine-phase-contact-sheets-v1','native-contact-sheets-v1.py',[str(root)]),
]:
    began=time.monotonic()
    with (repo/'.cache'/(name+'.log')).open('x')as log:
        code=subprocess.call([sys.executable,str(repo/'.cache'/script),*args],stdout=log,stderr=subprocess.STDOUT,env=env)
    stages.append({'name':name,'returncode':code,'seconds':time.monotonic()-began})
    if code:
        break
write_json(repo/'.cache/fine-phase-publication-prep-result-v1.json',{'script':reference(__file__),'stages':stages,'all_stages_succeeded':len(stages)==5 and all(r['returncode']==0 for r in stages)})
print(stages,flush=True)
