"""Publish exactly the inspected native boards and freeze the experiment receipts."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
review = read_json(root / "review/result.json")
collection = read_json(checked(review["collection"]))
plan = read_json(checked(collection["plan"]))
controls = read_json(root / "null-search-final.json")
first_controls = read_json(root / "null-search.json")
assert first_controls["rows"] == controls["rows"]
assert len(review["camera"]) == 8 and len(review["boards"]) == 2
assert len(review["neighborhoods"]) == 4 and len(controls["rows"]) == 36
assert collection["restoration_calls"] == 0
images.mkdir()
results.mkdir()


def publish_image(binding):
    source = checked(binding)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return source.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "encoder_revision": plan["encoder_revision"],
        "encoder_source": [r for r in plan["inputs"] if r["path"].endswith("model.safetensors")],
        "scope": "Ten native comparison boards, two separate native triplets, and four "
        "native cab donor montages were inspected. ISO100 AHD and JPEGs are independent references.",
        "synthetic": [
            row
            | {
                key: row[key] | {"file": publish_image(row[key]["image"])}
                for key in ("board", "triplet")
            }
            for row in review["boards"]
        ],
        "camera": [
            {k: v for k, v in row.items() if k not in ("fits", "distance")}
            | {
                "CFA": "RGGB",
                "file": publish_image(row["image"]),
                "reference_capture": "DSCF3880 ISO100 AHD"
                if row["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and DSCF3842/DSCF3835 camera JPEGs",
            }
            for row in review["camera"]
        ],
        "cab_donors": [
            row | {"file": publish_image(row["image"])} for row in review["neighborhoods"]
        ],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "review": reference(root / "review/result.json"),
        "collection": review["collection"],
        "plan": collection["plan"],
        "CPU_wall_seconds": collection["seconds"],
        "restoration_calls": collection["restoration_calls"],
        "retained_arrays_bit_exact": review["retained_arrays_bit_exact"],
        "aggregates": review["aggregates"],
        "budget_constrained": review["budget_constrained"],
        "selection_counts": review["selection_counts"],
        "null_controls": {
            "source": reference(root / "null-search-final.json"),
            "candidate_count": controls["candidate_count"],
            "same_seed_rerun_identical": True,
            "counts": controls["false_acceptance"],
        },
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "noise", "checkpoint", "distance")}
            for r in review["camera"]
        ],
    },
)
members = {
    root: [
        "plan.json",
        "collect.log",
        "output/collection.json",
        "review.py",
        "review/result.json",
        "null-search.log",
        "null-search.json",
        "null_search_final.py",
        "null-search-final.log",
        "null-search-final.json",
        "publish.py",
        "work/src/demosaic/localized_donor_geometry.py",
        "work/src/demosaic/scene_window_donors.py",
        "work/src/demosaic/screened_scene_donors.py",
        "work/src/demosaic/search_donor_geometry.py",
        "work/src/demosaic/donor_phase_geometry.py",
        "work/src/demosaic/full_frame_edge.py",
        "work/scripts/probe_scene_window_donors.py",
    ],
    root.parent / "localized-donor-parallel-v1": ["review.py"],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as tar,
):
    for folder, names in members.items():
        for name in names:
            path = folder / name
            entry = tar.gettarinfo(str(path), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with path.open("rb") as raw:
                tar.addfile(entry, raw)
with tarfile.open(archive) as tar:
    for folder, names in members.items():
        for name in names:
            assert tar.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "donor_views": 4,
        "new_checkpoint": None,
    },
)
