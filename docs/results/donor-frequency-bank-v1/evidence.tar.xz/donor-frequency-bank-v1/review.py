"""Measure frequency coverage, fallback and rendered quality on the retained panels."""

import argparse
import importlib.util
from itertools import product
from pathlib import Path

import numpy as np
from probe_scene_wire_footprint import PANELS
from probe_surface_aggregation import field
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ADMISSION = ROOT.parent / "donor-frequency-admission-v1"
NULLS = ROOT.parent / "donor-frequency-bank-guards-v1"
PRIOR = ROOT.parent / "local-phase-bounds-v1/review.py"
spec = importlib.util.spec_from_file_location("retained_wire_reader", PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
MODES = ("screened", "donor", "positive", "bank")


def declared_frequency(case):
    recipe = case["metadata"]["recipe"]
    angles = recipe["wire_angles"]
    return (
        np.column_stack((np.cos(angles), np.sin(angles))) / np.asarray(recipe["periods"])[:, None]
    )


def active(guide):
    return [f for f, flag in zip(guide.get("frequencies_xy", ()), guide["active"]) if flag]


def distances(candidates, frequency, n):
    if not candidates:
        return None
    fs = np.asarray(candidates)
    return float(
        n
        * np.min(
            np.minimum(
                np.linalg.norm(fs - frequency, axis=1), np.linalg.norm(fs + frequency, axis=1)
            )
        )
    )


def coverage(case, roles, output, split, n):
    freq = declared_frequency(case)
    result = []
    for source, row, arms in zip(roles, output["bank_records"], output["admission"], strict=True):
        before = source["fits"]["scene"]
        bank = row["bank"]
        shortlisted = [r["frequency_xy"] for r in bank["shortlist"]]
        confirmed = [r["frequency_xy"] for r in bank["shortlist"] if r["donor_valid"]]
        choices = {
            "baseline": active(before),
            "geometry": bank["compatible_frequencies"],
            "shortlisted": shortlisted,
            "confirmed": confirmed,
            "confirmed_union": active(before) + confirmed,
            "donor": active(arms["donor"]),
            "positive": active(arms["positive"]),
            "bank": active(row["final_guide"]),
        }
        new = {
            arm: guide != before
            for arm, guide in (
                ("donor", arms["donor"]),
                ("positive", arms["positive"]),
                ("bank", row["final_guide"]),
            )
        }
        result.append(
            {
                "weak_gap_native_bins": {k: distances(v, freq[1], n) for k, v in choices.items()},
                "strong_gap_native_bins": {k: distances(v, freq[0], n) for k, v in choices.items()},
                "new_companion": new,
                "shortlisted": len(shortlisted),
                "confirmed": len(confirmed),
                "anchor_index": row["anchor_index"],
                "query_status": row["query_selection"]["status"],
                "source_panel": split,
            }
        )
    return result


def scored(cases, setting, modes=MODES):
    rows = {}
    for offset in (0, 1):
        fields = ("parent", *(field("scene", a, offset) for a in modes))
        moments = {
            a: {
                k: np.mean([r["moments"][a][k] for r in cases], axis=0)
                for k in cases[0]["moments"][a]
            }
            for a in fields
        }
        alpha = setting["scale"]
        fixed = {a: evaluated(m, alpha) for a, m in moments.items()}
        baseline_quiet = fixed["parent"]["quiet_RMS_DN16"]
        cap = fixed[field("scene", "screened", offset)]["quiet_RMS_DN16"]
        budget = max(0, cap - baseline_quiet)
        same_quiet = {}
        for arm, moment in moments.items():
            scale = min(alpha, scale_at_budget(moment["quiet_mse"], budget))
            same_quiet[arm] = evaluated(moment, scale) | {"scale": scale}
            assert same_quiet[arm]["quiet_RMS_DN16"] <= max(cap, baseline_quiet) + 2e-9
        rows[str(offset)] = {
            "threshold": setting["threshold"] + offset,
            "scale": alpha,
            "quiet_limit_DN16": cap,
            "fixed": fixed,
            "quiet_capped": same_quiet,
        }
    return rows


def native_wire(path, case, p, truth, variants, plan, row):
    with np.load(checked(case["sensor"])) as raw:
        ctx = {k: raw[k][2:3] for k in ("colors", "wb", "matrix")}
        ctx["packed"] = raw["packed"][2:3, :, 64:192, 64:192]
    setting = plan["settings"][case["profile"]]
    parent = p[2][ROI]
    values = [
        parent + setting["scale"] * (variants[field("scene", a, 0)][2] - parent) for a in MODES
    ]
    return native_board(
        path,
        case["id"],
        [noisy_malvar(ctx)[0], parent, *values, truth[2][ROI]],
        ctx,
        {
            "case_receipt": row["case"],
            "CFA": case["CFA"],
            "noise": case["metadata"]["noise"],
            "checkpoint": plan["parent_checkpoint"],
            "operating": setting,
            "frequency_coverage": row["coverage"],
        },
        labels=(
            "Noisy Malvar",
            "V143 EMA",
            "Original two guides",
            "Donor only",
            "Positive reserve",
            "Reserve margin 1",
            "Exact GT",
        ),
        triplet_indices=(0, 5, 6),
        contrast=5,
    )


def evaluate_wires(plan, out):
    camera_crops, panels, records = [], {}, {}
    arrays_verified = 0
    for stage in PANELS:
        split, profile = stage.split("-")
        original = "original_guides" if split == "synthetic" else "disjoint_guides"
        archived = {r["id"]: r for r in read_json(checked(plan["source"][original]))["synthetic"]}
        old = read_json(checked(plan["screened_source"][split]))["rows"]
        prior_arrays = {r["id"]: r["prediction"] for r in old}
        rows = read_json(ADMISSION / f"{stage}.json")["rows"]
        cases = []
        for row in rows:
            case, p, truth, quiet, v = prior.read_case(row, split)
            key = row["id"]
            with np.load(checked(prior_arrays[key])) as f:
                for name in ("parent", "scene-screened", "scene-screened-strict"):
                    np.testing.assert_array_equal(v[name], f[name])
                    arrays_verified += 1
            choices = coverage(
                case,
                archived[key]["roles" if split == "synthetic" else "rankings"],
                row,
                split,
                plan["query_xywh"][2],
            )
            moments = {
                a: measure(p, truth, quiet, v[a])
                for a in (
                    "parent",
                    *(field("scene", mode, t) for mode, t in product(MODES, (0, 1))),
                )
            }
            cases.append({"id": key, "moments": moments, "coverage": choices})
            if stage == "synthetic-iso400" and case["source"] in (91, 92):
                camera_crops.append(
                    native_wire(out, case, p, truth, v, plan, row | {"coverage": choices})
                )
        totals = []
        for role in range(3):
            reports = [r["coverage"][role] for r in cases]
            totals.append(
                {
                    "weak_within_one_bin": {
                        k: sum(
                            v["weak_gap_native_bins"][k] is not None
                            and v["weak_gap_native_bins"][k] <= 1
                            for v in reports
                        )
                        for k in reports[0]["weak_gap_native_bins"]
                    },
                    "changed_guides": {
                        k: sum(v["new_companion"][k] for v in reports)
                        for k in reports[0]["new_companion"]
                    },
                    "n": len(reports),
                }
            )
        panels[stage] = {"metrics": scored(cases, plan["settings"][profile]), "coverage": totals}
        records[stage] = [
            r
            | {
                "moments": {
                    k: {m: t.tolist() for m, t in v.items()} for k, v in r["moments"].items()
                }
            }
            for r in cases
        ]
    assert len(camera_crops) == 2 and arrays_verified == 96
    return {
        "panels": panels,
        "records": records,
        "boards": camera_crops,
        "array_controls_verified": arrays_verified,
    }


def evaluate_camera(plan, out):
    inputs = read_json(checked(plan["camera_baseline"]))["camera"]
    baseline = read_json(checked(plan["screened_source"]["camera"]))["rows"]
    current = read_json(ADMISSION / "camera.json")["rows"]
    profiles = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    records = []
    for declaration, row, archived in zip(inputs, current, baseline, strict=True):
        source = declaration["source"]
        key = declaration["id"]
        assert key == row["id"] == archived["id"]
        x, y, w, h = declaration["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        roi = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = declaration["display_exposure"]
        tabs, diffs = [], {}
        with (
            np.load(checked(row["predictions"])) as f,
            np.load(checked(archived["predictions"])) as prev,
        ):
            parent = f["parent"][roi].astype(float)
            for guide, (arm, label) in product(
                ("scene", "spectral"), zip(MODES, ("uniform", "donor", "positive", "margin 1"))
            ):
                name = field(guide, arm, 0)
                if arm == "screened":
                    np.testing.assert_array_equal(f[name], prev[name])
                raw = f[name][roi]
                image = display(raw[None], ctx, exposure=exposure)[0].transpose(1, 2, 0)
                tabs.append((f"{guide.title()} {label}", np.rint(image * 255).astype(np.uint8)))
                diffs[name] = float(np.sqrt(np.mean((raw - parent) ** 2)) * 65535)
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in declaration["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        picture, positions = insert_camera_panels(
            out, key, declaration | {"panels": panels}, "V120 EMA", tabs
        )
        ax, ay, *_ = source["absolute_query_xywh"]
        records.append(
            {
                "id": key,
                "image": picture,
                "panels": positions,
                "noise": profiles[key],
                "ROI_xywh": [ax + x - qx, ay + y - qy, w, h],
                "display_exposure": exposure,
                "checkpoint": source["checkpoint"],
                "CFA": "RGGB",
                "calibration": source["query_arrays"],
                "prediction": row["predictions"],
                "reference": "DSCF3880 ISO100 AHD"
                if key.startswith("main-")
                else "DSCF3835 ISO100 AHD and both camera JPEGs",
                "RMS_from_V120_DN16": diffs,
            }
        )
    return records


def evaluate_nulls():
    rows = []
    for p in ("null-iso400", "null-iso6400"):
        rows.extend(read_json(NULLS / f"{p}.json")["rows"])
    assert len(rows) == 48
    results = {}
    for kind, names in {
        "flat": {"flat"},
        "straight": {"step", "rail"},
        "complex": {"wedge", "bent-rail", "two-rails"},
    }.items():
        chosen = [r for r in rows if r["style"] in names]
        arms = {}
        for a in chosen[0]["metrics"]:
            values = [r["metrics"][a] for r in chosen]
            arms[a] = {
                "RMS_DN16": float(np.sqrt(np.mean([v["RMS_DN16"] ** 2 for v in values]))),
                "peak_DN16": max(v["max_abs_DN16"] for v in values),
                "changed": sum(v["changed_pixels"] > 0 for v in values),
            }
        results[kind] = {"n": len(chosen), "metrics": arms}
    return results


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("task", choices=("wires", "camera", "nulls"))
    task = cli.parse_args().task
    plan = read_json(ROOT / "plan.json")
    output = ROOT / "review"
    output.mkdir(exist_ok=True)
    if task == "wires":
        payload = evaluate_wires(plan, output)
    elif task == "camera":
        payload = {"rows": evaluate_camera(plan, output)}
    else:
        payload = evaluate_nulls()
    write_json(output / f"{task}.json", {"producer": reference(__file__), **payload})
