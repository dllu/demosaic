"""Measure how much recoverable signal remains in a donor-confirmed shortlist."""

from probe_scene_wire_footprint import PANELS
from probe_surface_aggregation import field
from report_fold_support_pooling import measure
from review import ROOT, prior, scored

from demosaic.experiments.artifacts import read_json, reference, write_json

oracle = ROOT.parent / "donor-frequency-oracle-v1"
plan = read_json(oracle / "plan.json")
baseline = read_json(ROOT / "review/wires.json")
result = {}
for label in PANELS:
    stage = oracle / f"{label}.json"
    rows = read_json(stage)["rows"]
    geometry, profile = label.split("-")
    cases = []
    for row, previous in zip(rows, baseline["records"][label], strict=True):
        assert row["id"] == previous["id"]
        _, p, truth, quiet, v = prior.read_case(row, geometry)
        moments = dict(previous["moments"])
        for offset in (0, 1):
            name = field("scene", "oracle", offset)
            moments[name] = measure(p, truth, quiet, v[name])
        cases.append({"id": row["id"], "moments": moments})
    result[label] = {
        "source": reference(stage),
        "changes_from_margin_one_by_role": [
            sum(
                row["admission"][role]["oracle"] != row["bank_records"][role]["final_guide"]
                for row in rows
            )
            for role in range(3)
        ],
        "metrics": scored(cases, plan["settings"][profile], ("screened", "oracle")),
    }
write_json(ROOT / "review/oracle.json", result)
