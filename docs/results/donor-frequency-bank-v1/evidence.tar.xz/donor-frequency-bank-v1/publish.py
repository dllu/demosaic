"""Publish reviewed donor coverage and native evidence."""

import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from probe_scene_wire_footprint import PANELS, STAGES

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
results = Path("docs/results") / root.name
images = Path("docs/images") / root.name
aux = root.parent
groups = {
    "bank": (root, STAGES),
    "alternates": (aux / "donor-frequency-admission-v1", STAGES),
    "known_frequency": (aux / "donor-frequency-oracle-v1", PANELS),
    "forced_controls": (aux / "donor-frequency-bank-guards-v1", ("null-iso400", "null-iso6400")),
}
review = root / "review"
wires = read_json(review / "wires.json")
camera = read_json(review / "camera.json")["rows"]
assert len(wires["boards"]) == 2 and len(camera) == 8
assert wires["array_controls_verified"] == 96
results.mkdir()
images.mkdir()


def adopt(binding):
    src = checked(binding)
    target = images / src.name
    shutil.copyfile(src, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return target.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Two native synthetic triplets, their comparison boards, and eight native GFX crops. "
        "The GFX references are independent qualitative captures.",
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in wires["boards"]
        ],
        "camera": [r | {"file": adopt(r["image"])} for r in camera],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "stages": {
            k: {p: reference(folder / f"{p}.json") for p in panels}
            for k, (folder, panels) in groups.items()
        },
        "panels": wires["panels"],
        "array_controls_verified": wires["array_controls_verified"],
        "records": wires["records"],
        "known_frequency": read_json(review / "oracle.json"),
        "forced_controls": read_json(review / "nulls.json"),
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "checkpoint", "noise", "RMS_from_V120_DN16")}
            for r in camera
        ],
        "new_checkpoint": None,
    },
)

members = {
    folder: ["plan.json", *(f"{p}.{ext}" for p in panels for ext in ("json", "log"))]
    for folder, panels in groups.values()
}
members[root] += [
    "review.py",
    "review_oracle.py",
    "publish.py",
    "tests-final.log",
    "review/camera.json",
    "review/wires.json",
    "review/nulls.json",
    "review/oracle.json",
    "work/src/demosaic/donor_frequency_bank.py",
    "work/src/demosaic/search_donor_geometry.py",
    "work/scripts/probe_donor_frequency_bank.py",
]
members[groups["known_frequency"][0]].append("work/scripts/probe_frequency_bank_admission.py")
members[groups["forced_controls"][0]].append("work/scripts/probe_donor_frequency_bank.py")
members[aux / "donor-frequency-bank-nulls-v1"] = [
    "plan.json",
    "null-iso400.log",
    "null-iso6400.log",
]
members[aux / "local-phase-bounds-v1"] = ["review.py"]
members[aux / "matched-query-evidence-v1"] = ["structure_null.py"]
archive = results / "evidence.tar.xz"
with tarfile.open(archive, "x:xz", preset=8) as bundle:
    for folder, files in members.items():
        for name in files:
            p = folder / name
            m = bundle.gettarinfo(str(p), arcname=f"{folder.name}/{name}")
            m.mtime = m.uid = m.gid = 0
            m.uname = m.gname = ""
            with p.open("rb") as f:
                bundle.addfile(m, f)
with tarfile.open(archive) as bundle:
    for folder, files in members.items():
        for name in files:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparisons_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
