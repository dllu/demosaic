"""Check whether existing donor curvature fitting recovers the missing weak carrier."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.search_donor_geometry import search_donor_geometry

root = Path(__file__).resolve().parent
collection_path = root / "output/collection.json"
done = read_json(collection_path)
plan = read_json(checked(done["plan"]))
earlier = read_json(checked(plan["previous_plan"]))
offset = plan["synthetic_appearance_stress"]["xy_offset"]


def shift(box):
    x, y, w, h = box
    return (x + offset[0], y + offset[1], w, h)


boxes = list(
    map(
        shift,
        (
            earlier["left_xywh"],
            earlier["right_xywh"],
            *plan["synthetic_appearance_stress"]["decoy_boxes"],
        ),
    )
)
query = shift(plan["query_xywh"])


def distances(fit, truth):
    f = np.asarray(fit.get("frequencies_xy", [[0, 0], [0, 0]]))[fit["active"]]
    if not len(f):
        return [None, None]
    pairwise = np.minimum(
        np.linalg.norm(f[:, None] - truth, axis=2), np.linalg.norm(f[:, None] + truth, axis=2)
    )
    return (pairwise.min(axis=0) * 256).tolist()


cases = []
for row in done["synthetic"]:
    case = read_json(checked(row["case"]))
    if case["kind"] != "curved":
        continue
    guide = row["rankings"][2]
    old = guide["fits"]["scene"]
    if set(map(tuple, old.get("donor_boxes", []))) != set(boxes[:2]):
        continue
    noise = plan["profiles"][case["profile"]]
    donors = []
    for d, box in zip(row["decoys"], boxes, strict=True):
        with np.load(checked(d["raw"])) as f:
            donors.append((f["packed"], f["colors"], box))
    fit = search_donor_geometry(
        donors,
        query,
        shot=noise["shot"],
        read=noise["read"],
        donor_affinity=guide["affinities"]["scene"],
        affinity_first=True,
        fit_curvature=True,
    )
    assert fit["donor_boxes"] == old["donor_boxes"]
    recipe = case["metadata"]["recipe"]
    angle = np.asarray(recipe["wire_angles"])
    truth = np.stack((np.cos(angle), np.sin(angle)), 1) / np.asarray(recipe["periods"])[:, None]
    cases.append(
        {
            "id": row["id"],
            "before_native_bins": distances(old, truth),
            "after_native_bins": distances(fit, truth),
            "fit": fit,
        }
    )
    print(row["id"], cases[-1]["after_native_bins"], flush=True)
assert len(cases) == 8
write_json(
    root / "review/curvature-diagnostic.json",
    {
        "source": reference(collection_path),
        "driver": reference(__file__),
        "records": cases,
        "scope": "Curved fields with the intended donors selected. Refits use reserved donor folds and never see the target. "
        "Exact center gradients are used afterward to score geometry. No restoration is produced.",
    },
)
