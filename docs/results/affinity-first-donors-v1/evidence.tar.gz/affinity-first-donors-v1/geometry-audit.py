"""Measure agreement with the known query carriers after pair selection."""

from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
record = read_json(root / "output/collection.json")
plan = read_json(checked(record["plan"]))
prior = read_json(checked(plan["previous_plan"]))
dx, dy = plan["synthetic_appearance_stress"]["xy_offset"]
truth_boxes = {(x + dx, y + dy, w, h) for x, y, w, h in (prior["left_xywh"], prior["right_xywh"])}
counts = Counter()
rows = []
for bundle in record["synthetic"]:
    case = read_json(checked(bundle["case"]))
    recipe = case["metadata"]["recipe"]
    angles = np.asarray(recipe["wire_angles"])
    truth = np.stack((np.cos(angles), np.sin(angles)), 1) / np.asarray(recipe["periods"])[:, None]
    aligned = {}
    for arm, fit in bundle["rankings"][2]["fits"].items():
        correct = {tuple(x) for x in fit.get("donor_boxes", [])} == truth_boxes
        f = np.asarray(fit.get("frequencies_xy", [[0, 0], [0, 0]]))[fit["active"]]
        distances = (
            np.minimum(
                np.linalg.norm(f[:, None] - truth, axis=2),
                np.linalg.norm(f[:, None] + truth, axis=2),
            )
            * 256
        )
        hits = distances.min(axis=0).tolist() if len(f) else [None, None]
        aligned[arm] = {
            "correct_pair": correct,
            "active_directions": len(f),
            "nearest_true_carrier_native_bins": hits,
        }
        if arm == "scene" and correct:
            for key in ("all", case["profile"], case["kind"]):
                counts[key, "correct"] += 1
                if hits[1] is not None and hits[1] <= 1:
                    counts[key, "weak_within_one_bin"] += 1
                if all(h is not None and h <= 1 for h in hits):
                    counts[key, "both_within_one_bin"] += 1
    rows.append({"id": bundle["id"], "results": aligned})
write_json(
    root / "review/geometry-audit.json",
    {
        "producer": reference(__file__),
        "collection": reference(root / "output/collection.json"),
        "counts": {" / ".join(k): v for k, v in counts.items()},
        "rows": rows,
        "scope": "Two-family query roles only. Exact procedural center gradients used for diagnosis after restoration.",
    },
)
