"""Check whether short, screening-only regions contain the missing curved family."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.search_donor_geometry import _native, _screen_peaks, screening_mask

root = Path(__file__).resolve().parent
done_path = root / "output/collection.json"
done = read_json(done_path)
plan = read_json(checked(done["plan"]))
previous = read_json(checked(plan["previous_plan"]))
ox, oy = plan["synthetic_appearance_stress"]["xy_offset"]
boxes = [(x + ox, y + oy, w, h) for x, y, w, h in (previous["left_xywh"], previous["right_xywh"])]
seen = set()
rows = []


def gradient(recipe, box):
    angle = recipe["wire_angles"][1]
    u = np.array([np.cos(angle), np.sin(angle)])
    v = np.array([-u[1], u[0]])
    p = recipe["periods"][1]
    q, t = recipe["phase_drifts"][1]
    hessian = (q * np.outer(u, u) + t * np.outer(v, v)) / 256**2
    x, y, w, h = box
    center = np.array([x - ox + w / 2 - 256, y - oy + h / 2 - 256])
    return u / p + hessian @ center


def peaks(raw, cfa, box, noise, recipe):
    values = _screen_peaks(raw, cfa, screening_mask(box), noise["shot"], noise["read"])
    f = gradient(recipe, box)
    return min([min(np.linalg.norm(v - f), np.linalg.norm(v + f)) for v, _ in values], default=None)


for row in done["synthetic"]:
    case = read_json(checked(row["case"]))
    if case["kind"] != "curved":
        continue
    previous = row["rankings"][2]["fits"]["scene"]
    if set(map(tuple, previous.get("donor_boxes", []))) != set(boxes):
        continue
    key = (case["source"], case["profile"])
    if key in seen:
        continue
    seen.add(key)
    measures = []
    for donor, box in zip(row["decoys"][:2], boxes, strict=True):
        with np.load(checked(donor["raw"])) as f:
            raw, cfa = _native(f["packed"], f["colors"], box)
        noise = plan["profiles"][case["profile"]]
        recipe = case["metadata"]["recipe"]
        whole = peaks(raw, cfa, box, noise, recipe)
        x, y, _, _ = box
        short = [
            peaks(
                raw[dy : dy + 128, dx : dx + 128],
                cfa[dy : dy + 128, dx : dx + 128],
                (x + dx, y + dy, 128, 128),
                noise,
                recipe,
            )
            for dy in (0, 64, 128)
            for dx in (0, 64, 128)
        ]
        measures.append(
            {
                "box": box,
                "whole_frequency_error": whole,
                "short_frequency_errors": short,
                "short_hits_at_point_zero_one": int(sum(v is not None and v <= 0.01 for v in short)),
            }
        )
    rows.append({"source": key[0], "profile": key[1], "donors": measures})
write_json(
    root / "review/segment-diagnostic.json",
    {
        "source": reference(done_path),
        "producer": reference(__file__),
        "records": rows,
        "scope": "Post-run screening diagnostic. Per-window spectra use only fixed A sites. "
        "Known weak-family gradients are applied afterward for distance measurement. "
        "This run neither selects guides from the truth nor emits pixels.",
    },
)
