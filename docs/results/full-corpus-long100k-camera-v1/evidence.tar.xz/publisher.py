"""Bind the new camera measurements, inspected native crops and frozen provenance."""

import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
REPORT=ROOT/"camera-report"
DEST=Path("docs/results/full-corpus-long100k-camera-v1")
IMAGES=Path("docs/images/full-corpus-long100k-camera-v1")


def main():
    result=read_json(REPORT/"closed.json")
    actual=read_json(REPORT/"actual-native-viewing.json")
    assert actual["numerical_report"]==reference(REPORT/"closed.json")
    assert len(actual["viewed_sources"])==9 and all(row["viewed"] for row in actual["viewed_sources"])
    DEST.mkdir()
    IMAGES.mkdir()
    phases={}
    evidence={}
    image_manifest={}
    for phase in ("known","unseen"):
        role=result["panels"][phase]
        analysis=read_json(checked(role["analysis"]))
        native=read_json(checked(role["native"]))
        assert len(native["boards"])==(4 if phase=="known" else 5)
        assert all(item["scores_bit_exact"] for item in analysis["metric_checks"])
        assert {b["image"]["sha256"] for b in native["boards"]}=={
            v["image"]["sha256"] for v in actual["viewed_sources"] if v["phase"]==phase
        }
        metrics={}
        for row in analysis["summary"]["overall"]:
            metrics[row["model"]]={k:row["metrics"][k]["mean"] for k in ("sensor_psnr","ahd_srgb_psnr","ahd_srgb_ssim")}
        phases[phase]={"overall":metrics, "scenes":analysis["per_scene"], "batches":len(analysis["cases"]),
                       "metric_rows":sum(c["native_predictions"] for c in analysis["metric_checks"])}
        image_manifest[phase]={}
        for group in ("boards","triplets"):
            image_manifest[phase][group]=[]
            for item in native[group]:
                p=checked(item["image"])
                dest=IMAGES/p.name if group=="boards" else IMAGES/"triplets"/p.name
                dest.parent.mkdir(exist_ok=True)
                shutil.copyfile(p,dest)
                copy=reference(dest)
                assert copy["sha256"]==item["image"]["sha256"]
                if group=="triplets":
                    evidence[f"{phase}/triplets/{p.stem}.json"]=checked(item["metadata"])
                image_manifest[phase][group].append(item | {"image":copy})
        for label,path in {
            "analysis.json":checked(role["analysis"]),
            "native.json":checked(role["native"]),
            "per-crop.csv":checked(analysis["per_crop"]),
        }.items():
            evidence[f"{phase}/{label}"]=path
    write_json(IMAGES/"manifest.json",{"panels":image_manifest,"actual_viewing":reference(REPORT/"actual-native-viewing.json")})
    evidence.update({key:path for key,path in (
        ("adopt-primary.py",ROOT/"adopt-primary.py"),("adopt-when-ready.py",ROOT/"adopt-when-ready.py"),
        ("camera-reporter.py",ROOT/"report-camera-when-ready.py"),("publisher.py",Path(__file__)),
        ("closed.json",REPORT/"closed.json"),("viewed.json",REPORT/"actual-native-viewing.json"),
        ("adopted-collection.json",checked(result["collection"])),
    )})
    package=DEST/"evidence.tar.xz"
    with tarfile.open(package,"x:xz",preset=6) as archive:
        for name,path in sorted(evidence.items()):
            info=archive.gettarinfo(path,arcname=name)
            info.mtime=info.uid=info.gid=0
            info.uname=info.gname=""
            with path.open("rb") as stream:
                archive.addfile(info,stream)
    with tarfile.open(package) as archive:
        assert all(archive.extractfile(name).read()==path.read_bytes() for name,path in evidence.items())
    write_json(DEST/"publication.json",{
        "results":phases,"archive":reference(package),"native_manifest":reference(IMAGES/"manifest.json"),
        "viewing_record":reference(REPORT/"actual-native-viewing.json"),
        "complete_camera_panels":True,"complete_full427":False,
    })
    print(phases)


if __name__=="__main__":
    main()
