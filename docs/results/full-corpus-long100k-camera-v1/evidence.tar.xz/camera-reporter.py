"""Recompute complete measured CFA rows and render the fixed camera scenes."""

import os
import time
from pathlib import Path

import torch

from analyze_local_primary_cameras import analyze
from render_local_primary_cameras import render_panel

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/"canonical-camera"
adopter=read_json(ROOT/"adopt-when-ready-launch.json")
closure=CANDIDATE/"collection/result.json"
while not closure.is_file():
    if not owner_live(adopter):
        raise RuntimeError("The V120 adoption observer stopped before both camera panels closed")
    time.sleep(12)
joined=read_json(closure)
assert joined["cases"]==54 and set(joined["completed_panels"])=={"known","unseen"}
results={}
for stage in ("known","unseen"):
    dst=ROOT/"camera-report"/stage
    analyze(CANDIDATE,stage,dst)
    os.sched_setaffinity(0,[6,7])
    torch.set_num_threads(2)
    render_panel(dst/"result.json",dst/"native")
    results[stage]={"analysis":reference(dst/"result.json"),"native":reference(dst/"native/result.json")}
write_json(ROOT/"camera-report/closed.json",{
    "source":reference(__file__),"collection":reference(closure),"panels":results,
    "native_viewing_complete":False,
})
