"""Compose the candidate's canonical CPU results with independently collected V120."""

import argparse
import ast
from collections import Counter, defaultdict
from pathlib import Path

from collect_local_primary import summarize_stages

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

PANEL_COUNTS = {"known": 24, "unseen": 30, "photo": 3108}
ARGUMENTS = ("packed", "variance", "colors", "wb", "matrix")
BASELINE = "V120"


def plan_matches(candidate, parent):
    for field in ("CPU_threads", "canonical_inputs", "DINO_sha256"):
        assert candidate[field] == parent[field]
    # The later collector additionally validates the already-closed preflight.
    # Require byte identity for the whole forward/scoring code.
    preflight_validation = (
        '        qualified = read_json(checked(plan["preflight"]))\n'
        '        assert qualified["all_complete"] and qualified["kind"] == "preflight"\n'
        '        assert qualified["cases"] == 3 and qualified["models"] == plan["models"]\n'
    )
    a, b = (checked(plan["driver"]).read_text() for plan in (candidate, parent))
    assert a == b.replace(preflight_validation, "") or a == b
    ast.parse(a)
    ast.parse(b)
    for relative in ("src/demosaic/model.py", "src/demosaic/pretrained_rgb.py",
                     "src/demosaic/precision.py", "src/demosaic/metrics.py"):
        left, right = (str(Path(p["work"]) / relative) for p in (candidate, parent))
        assert candidate["frozen_files"][left] == parent["frozen_files"][right]


def adopt(candidate_root, parent_root, output, stages, label):
    candidate_path = candidate_root / "plan.json"
    parent_path = parent_root / "plan.json"
    candidate, parent = map(read_json,(candidate_path,parent_path))
    plan_matches(candidate, parent)
    assert label != BASELINE and {label,BASELINE} <= (candidate["models"].keys() | parent["models"].keys())
    models = {BASELINE: parent["models"][BASELINE], label: candidate["models"][label]}
    assert all(spec["weights"] == "EMA" for spec in models.values())
    canonical = read_json(checked(candidate["canonical_inputs"]))
    assert canonical["all_input_witnesses_exact"]
    chosen = {(r["stage"], r["batch"]):r for r in canonical["records"] if r["stage"] in stages}
    assert Counter(s for s, _ in chosen) == {s: PANEL_COUNTS[s] for s in stages}
    is_complete = set(stages) == set(PANEL_COUNTS)
    active_case_sets = []
    if is_complete:
        for root, path in ((parent_root,parent_path),(candidate_root,candidate_path)):
            result = read_json(root/"collection/result.json")
            assert result["plan"] == reference(path) and result["all_complete"]
            assert result["cases"] == 3162 and result["CPU_rng_unchanged"]
            active_case_sets.append({item["path"]:item for item in result["case_records"]})
    output.mkdir()
    bank = output/"collection"
    bank.mkdir()
    combined = candidate | {
        "root": str(output), "models": models, "parent_label": BASELINE,
        "scope": "Combined exact canonical CPU IEEE FP32 evaluations; verified saved V120 with fresh 100k EMA.",
    }
    write_json(output/"plan.json",combined)
    rows, case_records, witnesses = defaultdict(list), [], []
    for (stage,i), canonical in chosen.items():
        key = f"{stage}-{i:05d}"
        variants, sources = [], []
        item = canonical["arrays"]
        expected = {k: canonical["fingerprints"][k] for k in ARGUMENTS}
        for index, (root, name) in enumerate(((parent_root,BASELINE),(candidate_root,label))):
            path = root/"collection"/key/"result.json"
            binding = reference(path)
            if is_complete:
                assert active_case_sets[index][str(path.absolute())] == binding
            case = read_json(checked(binding))
            assert case["canonical_arrays"] == item and case["input_fingerprints"] == expected
            assert (case["stage"],case["batch"]) == (stage,i)
            var = next(v for v in case["variants"] if v["arm"] == name)
            assert var["checkpoint"] == models[name]["checkpoint"] and var["weights"] == "EMA"
            assert [r["id"] for r in var["rows"]] == canonical["context"]["ids"]
            assert all(r["model"] == name and r["pattern"] == canonical["context"]["pattern"] for r in var["rows"])
            checked(var["prediction"])
            variants.append(var)
            rows[stage].extend(var["rows"])
            sources.append(binding)
        r = bank/key
        r.mkdir()
        path = r/"result.json"
        write_json(path, {
            "stage":stage, "batch":i, "canonical_arrays":item, "input_fingerprints":expected,
            "variants":variants, "source_cases":sources, "new_root_calls":0,
        })
        case_records.append(reference(path))
        witnesses.append({"case":key,"sources":sources})
    assert len(case_records) == len(chosen)
    write_json(bank/"result.json", {
        "source":reference(__file__), "plan":reference(output/"plan.json"), "models":models,
        "source_plans":[reference(parent_path),reference(candidate_path)],
        "cases":len(case_records),"case_records":case_records,
        "kind":"full" if is_complete else "closed-camera-panels",
        "all_complete":is_complete, "completed_panels":list(stages),
        "summaries":summarize_stages(rows), "new_root_calls":0,
        "source_witnesses":witnesses,
    })
    print("Bound",len(case_records),"cases with matching CPU policy and saved control")


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate",type=Path)
    parser.add_argument("parent",type=Path)
    parser.add_argument("destination",type=Path)
    parser.add_argument("--label",default="scale-long100k")
    parser.add_argument("--camera-only",action="store_true")
    args=parser.parse_args()
    adopt(args.candidate,args.parent,args.destination,
          ("known","unseen") if args.camera_only else tuple(PANEL_COUNTS), args.label)
