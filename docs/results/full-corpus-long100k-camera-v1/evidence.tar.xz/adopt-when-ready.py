"""Adopt matched V120 controls at the camera and full primary closures."""

import time
from importlib.machinery import SourceFileLoader
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/"primary"
PREVIOUS=ROOT.parent/"full-corpus-control20k-review-queue-v1/primary20k"
adopt=SourceFileLoader("adopt_primary",str(ROOT/"adopt-primary.py")).load_module()


def wait(paths, collection):
    manifest=read_json(collection/"owner.json")
    owner={"pid":manifest["pid"],"created":manifest["create_time"]}
    while not all(path.is_file() for path in paths):
        if not owner_live(owner):
            remaining=[str(path) for path in paths if not path.is_file()]
            raise RuntimeError(f"Primary collector exited with {len(remaining)} missing closures")
        time.sleep(20)


def main():
    manifest=read_json(CANDIDATE/"plan.json")
    canonical=read_json(manifest["canonical_inputs"]["path"])
    paths=[
        Path("collection")/f"{r['stage']}-{r['batch']:05d}"/"result.json"
        for r in canonical["records"] if r["stage"] in ("known","unseen")
    ]
    assert len(paths)==54
    wait([CANDIDATE/path for path in paths],CANDIDATE/"collection")
    wait([PREVIOUS/path for path in paths],PREVIOUS/"collection")
    camera=ROOT/"canonical-camera"
    adopt.adopt(CANDIDATE,PREVIOUS,camera,("known","unseen"),"scale-long100k")
    full_relative=Path("collection")/"result.json"
    wait([CANDIDATE/full_relative],CANDIDATE/"collection")
    wait([PREVIOUS/full_relative],PREVIOUS/"collection")
    full=ROOT/"canonical-combined"
    adopt.adopt(CANDIDATE,PREVIOUS,full,("known","unseen","photo"),"scale-long100k")
    write_json(ROOT/"primary-with-V120.json",{
        "camera":reference(camera/full_relative),"primary":reference(full/full_relative),
        "notes":"Fixed broad evaluation includes all three panels. Scoped native review is published separately.",
    })


if __name__=="__main__":
    main()
