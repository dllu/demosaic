"""Summarize paired query responses for the two revised donor geometries."""

from pathlib import Path
import matplotlib
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
rp=root/"review/result.json"
r=read_json(rp)
plan=read_json(checked(r["plan"]))
receipt=read_json(checked(plan["donor_assessment"]))
selected=[(p,int(i)) for key,row in receipt["synthetic"].items() if any(row["accepted"])
          for p,i in (key.split("-"),)]
assert len(selected)==2
methods=("pooled","subharmonic")
metrics=("weak_gain","strong_gain","quiet_RMS_DN16","weak_increment_RMS_DN16","query_RMS_DN16")
rows=[]
for profile, source in selected:
    for place in ("far","near"):
        for method in methods:
            for t in plan["thresholds"]:
                group=[v for v in r["fixed_threshold_metrics"] if
                       (v["profile"],v["source"],v["placement"],v["method"]) == (profile,source,place,f"{method}-t{t:g}")]
                assert len(group)==4
                rows.append({"profile":profile,"source":source,"placement":place,"method":method,"threshold":t,
                             **{k:float(np.mean([v[k] for v in group])) for k in metrics},
                             "mean_absolute_weak_absent_projection":float(np.mean([abs(v["weak_absent_projection"]) for v in group]))})
fig, axes=plt.subplots(1,2,figsize=(9,4),layout="constrained")
for ax,(profile,source) in zip(axes,sorted(selected),strict=True):
    for mode,tone,marker,title in [("pooled","#5058b5","o","Original guide"),("subharmonic","#087f65","^","Revised guide")]:
        points=[v for v in rows if v["profile"]==profile and v["placement"]=="far" and v["method"]==mode]
        x=[p["quiet_RMS_DN16"] for p in points]
        y=[100*p["weak_gain"] for p in points]
        ax.plot(x,y,marker=marker,color=tone,label=title,markersize=4)
        for n,p in enumerate(points):
            if p["threshold"] in (0,2):
                ax.annotate(f"t{p['threshold']:g}",(x[n],y[n]),xytext=(4,6 if mode=="subharmonic" else -8),
                            textcoords="offset points",color=tone,fontsize=8)
    ax.set_title(f"{profile.upper()} · source {source}",fontweight="bold")
    ax.set_xlabel("Query quiet RMS (DN16)")
    ax.set_ylabel("Weak response (%)")
    ax.grid(alpha=.15)
axes[0].legend(frameon=False)
fig.suptitle("Far-wire detail response on the two revised guides",fontweight="bold")
plot=root/"review/revised-guide-tradeoff.png"
fig.savefig(plot,dpi=150)
counts={m:sum(max(v[f"{m}_distances_bins"])<=1 for v in r["donor_coverage"])
        for m in ("existing","revised")}
assert counts=={"existing":14,"revised":16}
write_json(root/"review/summary.json",{
    "source":reference(rp),"producer":reference(__file__),"guide_coverage":counts,
    "changed_donor_rows":[v for v in r["donor_coverage"] if any(v["accepted"])],
    "fixed_threshold_changed_geometry_means":rows,"plot":reference(plot),
    "scope":"Shared original geometry and revised subharmonic directions. Means over four Bayer layouts per target.",
})
print(counts,len(rows))
