"""Check the binary longer-repeat decision on cached donor RAW only."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig, donor_half_period_scores

root = Path(".cache/experiments")
synthetic = root/"scene-wave-guide-probe-v2"
camera = root/"scene-wave-guide-real-v1"
cfg = LocalWaveConfig(**read_json(synthetic/"plan.json")["guide_config"])
cutoff = 3.0

def resolve(packed, colors, guide, noise):
    h,w = packed.shape[-2:]
    raw = packed.reshape(2,2,h,w).transpose(2,0,3,1).reshape(h*2,w*2)
    cfa = np.tile(colors.reshape(2,2),(h,w))
    result = donor_half_period_scores(raw,cfa,guide,shot=noise["shot"],read=noise["read"],config=cfg)
    assert result.shape == (2,2) and np.isfinite(result).all()
    accepted = np.min(result,axis=0)>=cutoff
    revised = np.asarray(guide)*np.where(accepted[:,None],0.5,1.)
    return {"existing":guide,"revised":revised.tolist(),"fold_by_direction_scores":result.tolist(),
            "accepted":accepted.tolist()}

plan = read_json(synthetic/"plan.json")
guides = read_json(synthetic/"output/guides.json")
syn = {}
for key, row in plan["donors"].items():
    with np.load(checked(row["arrays"])) as a:
        noise = row["simulation"]["noise"]
        syn[key] = {"donor":row["arrays"],"noise":noise,
                    **resolve(a["packed"],a["colors"],guides[key],noise)}
    print(key,np.round(syn[key]["fold_by_direction_scores"],2).tolist(),syn[key]["accepted"],flush=True)
real_source=read_json(camera/"collection.json")
real_plan=read_json(checked(real_source["plan"]))
native=read_json(checked(real_plan["native_plan"]))
noise_by_id={x["id"]:x["noise"] for x in native["observations"]}
real={}
for row in real_source["rows"]:
    key=row["id"]
    x,y,w,h=row["donor_box"]
    assert w==h==256 and x%2==y%2==0
    noise=noise_by_id[row["donor"]]
    with np.load(checked(row["donor_arrays"])) as a:
        real[key]={"donor":row["donor_arrays"],"donor_box":row["donor_box"],"noise":noise,
           **resolve(a["packed"][0,:,y//2:(y+h)//2,x//2:(x+w)//2],a["colors"][0],row["guide"],noise)}
    print(key,np.round(real[key]["fold_by_direction_scores"],2).tolist(),real[key]["accepted"],flush=True)
assert len(syn)==16 and len(real)==8
write_json(".cache/donor-half-period-inputs-v1.json",{
    "driver":reference(__file__),"spectrum_operator":reference("src/demosaic/local_validated_waves.py"),
    "synthetic_plan":reference(synthetic/"plan.json"),"original_guides":reference(synthetic/"output/guides.json"),
    "real_collection":reference(camera/"collection.json"),"donor_config":cfg.to_dict(),
    "direction_score_threshold_each_fold":cutoff,"synthetic":syn,"camera":real,
    "scope":"One candidate per original direction, exactly half its frequency. Existing two-frequency nuisance and"
            " donor edge geometry are fixed. Candidate amplitudes and sensor variance are fit separately per fold"
            " and color. Sum opposite-fold predictive benefit across measured CFA colors. The scores are empirical"
            " because the full donor supplied the initial geometry. No query, target or reference data is read.",
})
