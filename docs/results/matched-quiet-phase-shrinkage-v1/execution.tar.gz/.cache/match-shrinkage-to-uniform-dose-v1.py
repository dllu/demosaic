"""Separate phase-fit shrinkage from simple equal-quiet attenuation at ISO6400."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_fold_support_pooling import ROI, evaluated, measure

experiment = Path(".cache/experiments/phase-fit-shrinkage-probe-v1").resolve()
report_path = experiment / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
collected = read_json(checked(report["collection"]))
old_report_path = checked(plan["adopted_report"])
old_scores={(r["id"],r["method"]):r for r in read_json(old_report_path)["metrics"]}
shrink_scores={(r["id"],r["method"]):r for r in report["metrics"]}
groups = {group["id"]: group for group in plan["groups"] if group["profile"] == "iso6400"}
assert len(groups) == 64
moments = defaultdict(lambda: defaultdict(list))
checked_rows = 0
for item in collected["synthetic"]:
    if item["id"] not in groups:
        continue
    g = groups[item["id"]]
    parent = np.load(checked(g["parent"])).astype(np.float64)
    with np.load(checked(g["arrays"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][ROI]
    raw, shrunk = [], []
    for row in item["rows"]:
        with np.load(checked(row["adopted_prediction"])) as data:
            raw.append(data["phase-profile-t0"])
        with np.load(checked(row["prediction"])) as data:
            shrunk.append(data["shrunken-profile-t0"])
    for title, output, source in [
        ("raw",raw,old_scores[g["id"],"phase-profile-t0"]),
        ("shrunk",shrunk,shrink_scores[g["id"],"shrunken-profile-t0"]),
    ]:
        terms=measure(parent,target,quiet,np.stack(output))
        values=evaluated(terms,1)
        for key, wanted in [
            ("quiet_RMS_DN16","query_quiet_RMS_DN16"),("weak_gain","weak_gain"),
            ("weak_increment_RMS_DN16","weak_increment_error_RMS_DN16"),
            ("strong_gain","strong_gain"),("query_RMS_DN16","query_full_RMS_DN16"),
            ("weak_absent_projection","weak_absent_projection")]:
            np.testing.assert_allclose(values[key],source[wanted],atol=1e-10,rtol=1e-10)
        checked_rows += 1
        moments[g["placement"],g["source"]][title].append(terms)

results = []
for (placement, source), values in sorted(moments.items()):
    assert all(len(v)==4 for v in values.values())
    a,b = [{key:np.mean([v[key] for v in values[name]],axis=0)
            for key in values[name][0]} for name in ("raw","shrunk")]
    observed=evaluated(b,1)
    c=a["quiet_mse"].copy()
    c[0] -= observed["quiet_RMS_DN16"]**2
    roots=np.polynomial.polynomial.polyroots(c)
    valid=[float(root.real) for root in roots if abs(root.imag)<1e-12 and 0<=root.real<=1]
    matched = None
    if valid:
        scale = max(valid,key=lambda weight: evaluated(a,weight)["weak_gain"])
        matched = evaluated(a,scale)
        np.testing.assert_allclose(matched["quiet_RMS_DN16"],observed["quiet_RMS_DN16"],atol=1e-11,rtol=0)
        # Report each CFA's absolute projection separately before averaging.
        matched["mean_abs_weak_absent_projection"] = np.mean([
            abs(evaluated(t,scale)["weak_absent_projection"]) for t in values["raw"]]).item()
        observed["mean_abs_weak_absent_projection"] = np.mean([
            abs(evaluated(t,1)["weak_absent_projection"]) for t in values["shrunk"]]).item()
    results.append({"placement":placement,"source":source,"matching_scale":scale if matched else None,
                    "unshrunk":evaluated(a,1),"uniformly_attenuated":matched,"shrunk":observed,
                    "parent":evaluated(a,0)})
assert len(results)==16 and checked_rows==128
output = Path(".cache/matched-quiet-shrinkage-v1.json")
write_json(output,{
    "driver":reference(__file__),"operating_point_report":reference(report_path),"old_report":reference(old_report_path),
    "control_metric_rows_reproduced":checked_rows,"exact_metrics_checked":checked_rows*6,"results":results,
    "scope":"ISO6400 all 8 geometries and 4 CFAs at fixed threshold 0. Scale the unshrunk delivered correction by a"
            " single scalar across all pixels, colors, and roles. Choose scalar per geometry to exactly match the"
            " shrunken output RMS over the four CFAs. Uses the targets for matching, an oracle diagnostic.",
})
for place in ("near","far"):
    group=[r for r in results if r["placement"]==place and r["uniformly_attenuated"]]
    print(place,len(group))
    for name in ("parent","uniformly_attenuated","shrunk"):
        print(name, {k:np.mean([r[name][k] for r in group]).item()
             for k in group[0][name] if k!="weak_absent_projection"})
