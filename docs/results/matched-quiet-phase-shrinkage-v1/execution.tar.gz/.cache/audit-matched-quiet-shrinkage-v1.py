"""Verify the matched-quiet calculation using reconstructed arrays and direct norms."""
from collections import defaultdict
from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

path = Path(".cache/matched-quiet-shrinkage-v1.json").resolve()
report = read_json(path)
source = read_json(checked(report["operating_point_report"]))
plan = read_json(checked(source["plan"]))
collection = read_json(checked(source["collection"]))
results = {(row["placement"],row["source"]):row for row in report["results"]}
pairs = defaultdict(lambda:{"uniformly_attenuated":[],"shrunk":[]})
roi = np.s_[...,128:384,128:384]
for group,item in zip(plan["groups"],collection["synthetic"],strict=True):
    assert group["id"] == item["id"]
    if group["profile"] != "iso6400":
        continue
    key = group["placement"],group["source"]
    alpha = results[key]["matching_scale"]
    assert 0 < alpha < 1
    parent = np.load(checked(group["parent"])).astype(np.float64)
    with np.load(checked(group["arrays"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][roi]
    old, new = parent.copy(),parent.copy()
    for row in item["rows"]:
        role = row["role"]
        with np.load(checked(row["adopted_prediction"])) as outputs:
            old[role][roi] = (1-alpha)*old[role][roi]+alpha*outputs["phase-profile-t0"].astype(np.float64)
        with np.load(checked(row["prediction"])) as outputs:
            new[role][roi] = outputs["shrunken-profile-t0"]
    weak, strong = (target[2]-target[1]).ravel(),(target[1]-target[0]).ravel()
    weak_energy,strong_energy = weak@weak,strong@strong
    for name,value in [("uniformly_attenuated",old),("shrunk",new)]:
        error = value-target
        blank = error[roi][...,quiet]
        increment = (error[2]-error[1]).ravel()
        errors = [np.linalg.norm(v.ravel())*65535/np.sqrt(v.size) for v in (blank,error[roi],increment)]
        pairs[key][name].append([
            *(v**2 for v in errors),
            ((value[2]-value[1]).ravel()@weak)/weak_energy,
            ((value[1]-value[0]).ravel()@strong)/strong_energy,
            abs(error[1].ravel()@weak)/weak_energy,
        ])

metrics=("quiet_RMS_DN16","query_RMS_DN16","weak_increment_RMS_DN16",
         "weak_gain","strong_gain","mean_abs_weak_absent_projection")
count = 0
largest_diff = 0.0
for key,arms in pairs.items():
    for name, values in arms.items():
        assert len(values) == 4
        mean = np.mean(values, axis=0)
        mean[:3] = np.sqrt(mean[:3])
        wanted = np.array([results[key][name][k] for k in metrics])
        np.testing.assert_allclose(mean,wanted,atol=1e-10,rtol=1e-10)
        largest_diff = max(largest_diff,np.max(abs(mean-wanted)))
        count += len(wanted)
assert len(pairs)==16 and count==192
write_json(path.with_name("matched-quiet-shrinkage-audit-v1.json"),{
    "driver":reference(__file__),"report":reference(path),"source_cases":64,
    "geometry_pairs":16,"direct_image_reductions":count,
    "largest_error":float(largest_diff),"status":"passed",
})
print(count,largest_diff)
