import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-hann512-pilot-v1"
destination = repo / "docs/results/neural-nuisance-hann512-v1"
notes = [
    ([0, 1, 2, 3], "All twelve procedural comparisons and bark/fur/main sky/building viewed. Low-prior far strong modulation increases modestly; the weak direction remains heavily attenuated. Higher-noise cases largely resemble parent. Bark/fur remain soft, sky quiet; no clear broad added building bands at primary ROI."),
    ([4, 5, 6, 7], "Main foliage/coarse fence plus both cab profiles/left-right ROIs/JPEGs and all stress views inspected. Fine cab crossings remain missing; nominal cab nearly unchanged, profile modulation remains incomplete. Foliage stays soft. Analytic building maximum and retained historical-failure view have much less conspicuous banding than prior aggregation, without proving fidelity against a real GT. NN triplets inspected."),
    ([8, 9, 10], "Both additional analytic noisy/restored/exact-GT native160 triplets inspected. Most weak structure still absent, modest strong pattern remains. Both fixed0/2/4 charts inspected: labels/title now fit; threshold0 buys more low-prior response with larger quiet error. Other priors largely abstain. No retrospective threshold selection."),
]
for i, (sheets, note) in enumerate(notes):
    write_json(root / f"viewing-batch-{i}.json", {"sheets": sheets, "actually_viewed": True,
        "method": "Exact unresized contact sheets through tools.view_image", "notes": note})
prepared = read_json(root / "publication-prepared.json")
manifest = read_json(root / "contact-sheets/manifest.json")
assert manifest["source_images"] == len(prepared["images"]) == 36
assert sorted(s for group, _ in notes for s in group) == list(range(len(manifest["sheets"])))
archives = list(prepared["archives"])
for source in [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *sorted(root.glob("viewing-batch-*.json")), repo / ".cache/native-contact-sheets-v1.py", Path(__file__)]:
    target = destination / ("addendum-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})
for item in archives:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in prepared["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
prepared.update(archives=archives,
    viewing={"actually_viewed": True, "figures": 36, "contact_sheets": 11,
             "manifest": reference(root / "contact-sheets/manifest.json"),
             "batches": [reference(p) for p in sorted(root.glob("viewing-batch-*.json"))]},
    status="complete; useful low-prior weak-increment-error operating point, limited development evidence",
    quality_decision="Retain analytic Hann512 as an opt-in lower weak-increment error choice; keep256 fixed-NN alternative for stronger strong-family response/lower total RGB error. No broad photo/camera/default promotion.",
    comparison_baselines=[reference(repo / "docs/results" / name / "publication.json") for name in [
        "neural-nuisance-fixed-v1", "neural-nuisance-full-edge512-v1", "neural-nuisance-context512-v1"]],
    scope_clarification="Inherited plan window-ablation sentence says other fitting rules unchanged; declared geometry.frequency_weighting and study.json explicitly change analytic frequency grid/refinement to Hann inverse-variance conditional WLS. Amplitude/validation/parent delivery remain unchanged. Current producer adds this wording explicitly for future plans; executed source/plan bytes preserved.",
    published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination / "publication.json", prepared)
print(len(archives), "exact archives;36 source figures actually viewed")
