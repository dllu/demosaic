"""Seal diagnosed failure, exact resume admission and actual post6000 progress."""
import gzip
import io
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/full-corpus-scaling-v3'
failure = root / 'checkpoint-stall-step6000-v1'
recovery = root / 'checkpoint-recovery-v6'
plan_path = root / 'production-handoff-plan-v6.json'
plan = read_json(plan_path)
launch = read_json(root / 'production-handoff-v6/00-scale-control20k-launch.json')
process = psutil.Process(launch['pid'])
assert process.create_time() == launch['create_time']
run = Path(read_json(recovery / 'retention-qualification.json')['new_train']['path']).parents[2] / 'artifacts/train/control20k'
phase = run / 'phase-006001-020000'
old_rows = [json.loads(line) for line in (failure / 'failed-source-crop-observations.jsonl').read_text().splitlines()]
assert len(old_rows) == 6000 and old_rows[-1]['global_draw_start'] == 95984
with (phase / 'source-crop-observations.jsonl').open() as stream:
    prefix = ''.join(next(stream) for _ in range(100))
rows = [json.loads(line) for line in prefix.splitlines()]
assert [r['global_draw_start'] for r in rows] == list(range(96000, 97600, 16))
prefix_path = recovery / 'first100-resumed-source-observations.jsonl'
prefix_path.open('x').write(prefix)
log = root / 'production-handoff-v6/00-scale-control20k.log'
events = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
start = next(e for e in events if e['event'] == 'start')
trained = [e for e in events if e['event'] == 'train']
assert start['start_step'] == 6000 and start['steps'] == 20000 and start['train_sources'] == 90778
assert trained[0]['step'] == 6001 and trained[-1]['step'] >= 6100
snapshot = recovery / 'actual-progress-observation.json'
write_json(snapshot, {
    'recorded_UTC': datetime.now(timezone.utc).isoformat(), 'script': reference(__file__),
    'launch': reference(root / 'production-handoff-v6/00-scale-control20k-launch.json'),
    'actual_owner': {'pid': process.pid, 'create_time': process.create_time(), 'status': process.status()},
    'start': start, 'completed_train_events_observed': trained, 'first100_sources': reference(prefix_path),
    'previous_prefix_rows': 6000, 'previous_last_global_draw_start': 95984,
    'resumed_first_global_draw_start': 96000, 'batch_size': 16,
    'scope': 'Live observation with actual new optimizer-step logs and exact100 closed source rows, not mere process liveness or a terminal training report. Worker may progress beyond this cutoff. Original global source indices continue6000→6001; no prefix replay. First-new-forward guards verify91 raw tensors and frozen DINO before learning. Full resumed terminal summary/next completed checkpoint and quality remain pending.',
})

destination = repo / 'docs/results/full-corpus-checkpoint-recovery-v1'
destination.mkdir()
paths = [failure / p for p in ['diagnosis.json', 'operator-stop.json', 'failed-03-scale-control20k.log',
         'failed-metrics.jsonl', 'failed-source-loss.jsonl', 'failed-source-crop-observations.jsonl']]
paths += [root / p for p in ['production-handoff-plan-v2.json', 'production-handoff-v2-launch.json',
          'production-handoff-v2/03-scale-control20k-launch.json', 'production-handoff-v2/03-scale-control20k-result.json',
          'production-handoff-v2/production-result.json']]
for version in [4, 5]:
    directory = root / f'production-handoff-v{version}'
    paths += list(directory.glob('*'))
    paths += [root / f'production-handoff-plan-v{version}.json', root / f'production-handoff-v{version}-launch.json',
              root / f'production-handoff-v{version}-controller.log', root / f'checkpoint-recovery-v{version}/retention-qualification.json']
paths += [plan_path, root / 'production-handoff-v6-launch.json', root / 'production-handoff-v6/00-scale-control20k-launch.json',
          phase / 'owner.json', recovery / 'retention-qualification.json', snapshot, prefix_path]
paths += [checked(plan['configs'][arm]) for arm in ['control20k', 'long100k']]
paths += sorted((root / 'work/artifacts/train/control20k/phase-000001-020000').glob('conditions-*.npz'))
paths += [repo / p for p in ['src/demosaic/train.py', 'tests/test_checkpoint_retention.py',
          '.cache/checkpoint-retention-tests-v1.log', '.cache/full-corpus-control20k-step6000-stack-v1.log',
          '.cache/diagnose-control-checkpoint-stall-v1.py', '.cache/diagnose-control-checkpoint-stall-v1.log',
          '.cache/stop-diagnosed-control-checkpoint-stall-v1.py', '.cache/stop-diagnosed-control-checkpoint-stall-v1.log',
          '.cache/publish-full-corpus-checkpoint-recovery-v1.py']]
for version in [3, 4, 5, 6]:
    for suffix in ['py', 'log']:
        paths.append(repo / f'.cache/prepare-full-corpus-checkpoint-recovery-v{version}.{suffix}')
    if version >= 4:
        for suffix in ['py', 'log']:
            paths.append(repo / f'.cache/launch-full-corpus-checkpoint-recovery-v{version}.{suffix}')
        paths.append(repo / f'.cache/full-corpus-and-context-controller-v{version}.py')
archives = []
for i, path in enumerate(sorted(set(paths))):
    assert path.is_file(), path
    target = destination / f'{i:03d}-{path.name}.gz'
    data = path.read_bytes()
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    archives.append({'original': reference(path), 'published': reference(target)})
packages = []
for version in [4, 5, 6]:
    manifest = root / f'production-handoff-plan-v{version}.json'
    specification = read_json(manifest)
    target = destination / f'recovery-v{version}-sources.tar.gz'
    members = []
    with tarfile.open(target, 'w:gz') as tar:
        for path, digest in sorted(specification['frozen_files'].items()):
            source = checked({'path': path, 'sha256': digest})
            data = source.read_bytes()
            name = str(source.relative_to(specification['work']))
            info = tarfile.TarInfo(name)
            info.size, info.mode = len(data), 0o644
            tar.addfile(info, io.BytesIO(data))
            members.append({'member': name, 'original': reference(source)})
    packages.append({'manifest': reference(manifest), 'published': reference(target), 'members': members})
write_json(destination / 'publication.json', {
    'publisher': reference(__file__), 'archives': archives, 'source_snapshots': packages,
    'diagnosis': reference(failure / 'diagnosis.json'), 'operator_stop': reference(failure / 'operator-stop.json'),
    'new_progress': reference(snapshot), 'adopted_immutable_states': plan['adopted_states'],
    'scope': 'Diagnosed>1h redundant best-checkpoint serialization stall, complete6k state and explicit source-bound resumed14k/99k schedules.100 actual new source rows and optimizer logs confirm progress beyond6000. Original pretraining admission failures/partial bytes retained, no automatic retry/reset or replay. Core change only atomic best retention. Full20k/100k training/quality still incomplete; no PSNR-history point or new native-quality claim.',
    'not_embedded': 'Large raw/EMA/Adam/DINO checkpoint binaries and partial best.tmp remain local with exact hashes; old complete6k and long1k are immutable. Failed prefix terminal aggregate/full GPU-witness list was never written and is not reconstructed. Original v3 preparer stopped before a final plan; its executed script/log and created sources remain locally preserved; no claim every transitive historic artifact is packed.',
})
print('Published recovery archives', len(archives), 'source members', sum(len(s['members']) for s in packages),
      'actual latest observed optimizer step', trained[-1]['step'])
