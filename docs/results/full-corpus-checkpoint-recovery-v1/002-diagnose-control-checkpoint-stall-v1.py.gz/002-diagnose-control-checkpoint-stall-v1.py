"""Bind the nonadvancing checkpoint and last complete state before any recovery."""
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import psutil
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

torch.set_num_threads(2)
root = Path('.cache/experiments/full-corpus-scaling-v3').resolve()
out = root / 'checkpoint-stall-step6000-v1'
out.mkdir()
launch = read_json(root / 'production-handoff-v2/03-scale-control20k-launch.json')
process = psutil.Process(launch['pid'])
assert process.create_time() == launch['create_time'] == 1794910101.73
run = root / 'work/artifacts/train/control20k'
log = root / 'production-handoff-v2/03-scale-control20k.log'


def observation():
    return {'observed_unix': time.time(), 'owner': {'pid': process.pid, 'create_time': process.create_time()},
            'status': process.status(), 'cpu_times': process.cpu_times()._asdict(),
            'IO': process.io_counters()._asdict(),
            'files': {str(p): {'size': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns}
                      for p in [log, run / 'last.pt', run / 'best.pt', run / 'best.tmp', run / 'source-loss.jsonl', run / 'metrics.jsonl']}}


first = observation()
assert time.time() - log.stat().st_mtime > 3600
for source, name in [(run / 'last.pt', 'control-step006000.pt'), (run / 'best.pt', 'previous-best.pt')]:
    os.link(source, out / name)
state = torch.load(out / 'control-step006000.pt', map_location='cpu', weights_only=True)
assert state['step'] == 6000 and len(state['model']) == len(state['ema']) == 91
assert len(state['optimizer']['state']) == 89
assert all(v['step'] == 6000 for v in state['optimizer']['state'].values())
assert all(torch.isfinite(v).all() for name in ['model', 'ema'] for v in state[name].values())
assert all(torch.isfinite(t).all() for value in state['optimizer']['state'].values() for t in value.values() if isinstance(t, torch.Tensor))
assert state['config']['steps'] == 20000 and state['config']['batch_size'] == 16
assert state['python_rng'] and state['cuda_rng'] and state['torch_rng'].numel()
elapsed = time.time() - first['observed_unix']
if elapsed < 10:
    time.sleep(10 - elapsed)
second = observation()
assert first['files'] == second['files'], 'Training/checkpoint progressed during diagnosis; do not stop it'
assert second['cpu_times']['user'] > first['cpu_times']['user'] + 3
write_json(out / 'diagnosis.json', {
    'script': reference(__file__), 'recorded_UTC': datetime.now(timezone.utc).isoformat(),
    'launch': reference(root / 'production-handoff-v2/03-scale-control20k-launch.json'),
    'first': first, 'second': second, 'unchanged_seconds_since_log': time.time() - log.stat().st_mtime,
    'checkpoint': reference(out / 'control-step006000.pt'), 'previous_best': reference(out / 'previous-best.pt'),
    'state': {'step': 6000, 'raw_tensors': 91, 'EMA_tensors': 91, 'Adam_states': 89,
              'all_Adam_steps': 6000, 'horizon': 20000, 'batch_size': 16, 'Python_CPU_CUDA_RNG_present': True},
    'gdb_attempt': reference('.cache/full-corpus-control20k-step6000-stack-v1.log'),
    'scope': 'Verified more than1h of unchanged training log/source records/complete last/partial best checkpoint, with ongoing CPU spin. Complete6k raw/EMA/Adam/RNG checkpoint retained as immutable hardlink. This is a diagnosed checkpoint-write stall, not an observation-cell timeout or a nonfinite training result. OS denied debugger attachment; no exact C++/CUDA root cause claimed. No process has yet been stopped or restarted by this script; no training or neural calls.',
})
print('Checkpoint-write stall confirmed; valid immutable6000 state', reference(out / 'control-step006000.pt')['sha256'])
