"""Independently check failure/state/source/continuity evidence without training."""
import gzip
import json
import os
import re
import tarfile
from pathlib import Path

import numpy as np
import torch
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

os.sched_setaffinity(0, [6, 7])
torch.set_num_threads(2)
repo = Path.cwd()
root = repo / '.cache/experiments/full-corpus-scaling-v3'
directory = repo / 'docs/results/full-corpus-checkpoint-recovery-v1'
publication = read_json(directory / 'publication.json')
for item in publication['archives']:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
for package in publication['source_snapshots']:
    expected = {m['member']: m for m in package['members']}
    with tarfile.open(checked(package['published']), 'r:gz') as tar:
        assert set(tar.getnames()) == set(expected)
        for name, item in expected.items():
            assert tar.extractfile(name).read() == checked(item['original']).read_bytes()
diagnosis = read_json(checked(publication['diagnosis']))
stop = read_json(checked(publication['operator_stop']))
assert diagnosis['first']['files'] == diagnosis['second']['files']
assert diagnosis['unchanged_seconds_since_log'] > 3600
assert diagnosis['second']['cpu_times']['user'] > diagnosis['first']['cpu_times']['user'] + 3
assert any(b['target'].endswith('/best.tmp') and '131685248' in b['fdinfo'] for b in stop['fd_evidence_at_stop'])
assert read_json(root / 'production-handoff-v2/03-scale-control20k-result.json')['returncode'] == -15
for binding in stop['closed_evidence']:
    assert checked(binding['original']).read_bytes() == checked(binding['retained']).read_bytes()
states = []
for arm, expected in [('control20k', 6000), ('long100k', 1000)]:
    checkpoint = publication['adopted_immutable_states'][arm]
    state = torch.load(checked(checkpoint), map_location='cpu', weights_only=True)
    assert state['step'] == expected and len(state['model']) == len(state['ema']) == 91
    assert len(state['optimizer']['state']) == 89
    assert all(t['step'] == expected for t in state['optimizer']['state'].values())
    assert all(torch.isfinite(t).all() for key in ['model', 'ema'] for t in state[key].values())
    assert all(torch.isfinite(t).all() for v in state['optimizer']['state'].values() for t in v.values() if isinstance(t, torch.Tensor))
    assert state['torch_rng'].numel() and state['cuda_rng'] and state['python_rng']
    states.append({'arm': arm, 'step': expected, 'checkpoint': checkpoint, 'raw_EMA_tensors_each': 91, 'finite_Adam_states': 89})
    del state
plan = read_json(root / 'production-handoff-plan-v6.json')
prior = read_json(root / 'production-handoff-plan-v2.json')
for arm in ['control20k', 'long100k']:
    before = yaml.safe_load(checked(prior['configs'][arm]).read_text())
    after = yaml.safe_load(checked(plan['configs'][arm]).read_text())
    assert {k: v for k, v in before.items() if k != 'run'} == {k: v for k, v in after.items() if k != 'run'}
    assert Path(after['run']).is_relative_to(Path(plan['work']))
assert [s['updates'] for s in plan['compute_schedule']] == [14000, 99000]
train_path = Path(plan['work']) / 'src/demosaic/train.py'
assert train_path.read_bytes() == (repo / 'src/demosaic/train.py').read_bytes()
text = train_path.read_text()
text = text[:text.index('def retain_checkpoint(')] + text[text.index('def save_checkpoint('):]
text = text.replace('import os\n', '', 1).replace('retain_checkpoint(run / "last.pt", run / "best.pt")',
                                                            'save_checkpoint(run / "best.pt", model, optimizer, ema, step, config, best)')
assert text == (Path(prior['work']) / 'src/demosaic/train.py').read_text()
conditions = sorted((root / 'work/artifacts/train/control20k/phase-000001-020000').glob('conditions-*.npz'))
steps = []
for condition in conditions:
    with np.load(condition, allow_pickle=False) as data:
        assert data['values'].shape == (250, 16, 14) and np.isfinite(data['values']).all()
        steps.extend(data['steps'].tolist())
assert len(conditions) == 24 and steps == list(range(1, 6001))
progress = read_json(checked(publication['new_progress']))
assert progress['start']['start_step'] == 6000 and progress['start']['steps'] == 20000
assert progress['completed_train_events_observed'][0]['step'] == 6001
assert progress['completed_train_events_observed'][-1]['step'] == 6350
rows = [json.loads(line) for line in checked(progress['first100_sources']).read_text().splitlines()]
assert [r['global_draw_start'] for r in rows] == list(range(96000, 97600, 16))
links = 0
for filename in ['docs/full-corpus-checkpoint-recovery.md', 'docs/full-corpus-scaling.md', 'docs/experiments.md',
                 'diary/index.md', 'diary/2026-11-17-04-36-50-full-corpus-checkpoint-recovery.md']:
    path = repo / filename
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        if target.endswith('/independent-review.json'):
            continue
        assert (path.parent / target.split('#')[0].strip('<>')).exists(), (filename, target)
        links += 1
write_json(directory / 'independent-review.json', {
    'verifier': reference(__file__), 'publication': reference(directory / 'publication.json'), 'all_passed': True,
    'exact_archives': len(publication['archives']), 'exact_frozen_members': sum(len(p['members']) for p in publication['source_snapshots']),
    'states': states, 'only_training_source_change_is_best_retention': True,
    'configs_equal_except_permitted_output_root': True, 'complete_original_conditioning_steps': [1, 6000],
    'actual_resume_first_step': 6001, 'actual_completed_step_observed': 6350, 'first100_source_indices_contiguous': True,
    'current_local_links_checked': links, 'scope': 'Independent existing source/archive/checkpoint/optimizer/RNG/conditioning and actual new progress audit.0 new neural, GPU, noise, RAW or optimizer calls. No missing original terminal receipt reconstructed, no quality result or PSNR-history point. Live jobs can advance beyond these frozen observations.',
})
with (directory / 'verification-source.py.gz').open('xb') as stream:
    stream.write(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Independent recovery verification passed:', len(publication['archives']), 'archives,', len(conditions), 'conditioning chunks,', links, 'links')
