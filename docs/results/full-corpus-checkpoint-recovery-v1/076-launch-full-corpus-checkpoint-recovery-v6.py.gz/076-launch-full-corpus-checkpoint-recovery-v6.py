"""Launch only the explicitly admitted remaining schedules, after the old owner exits."""
import os
import subprocess
import sys
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

root = Path('.cache/experiments/full-corpus-scaling-v3').resolve()
for pid, created in [(1200382, 1794910101.73), (1148040, 1794907294.12), (1351146, 1794918745.47), (1351137, 1794918745.19), (1351370, 1794918888.33)]:
    try:
        old = psutil.Process(pid)
        assert old.create_time() != created, 'Old training/controller still active; do not launch'
    except psutil.NoSuchProcess:
        pass
plan_path = root / 'production-handoff-plan-v6.json'
plan = read_json(plan_path)
verify_plan(plan)
assert read_json(checked(plan['checkpoint_write_recovery']))['checkpoint']['sha256'] == plan['adopted_states']['control20k']['sha256']
assert not Path(plan['allocation_root']).exists()
os.nice(10)
env = dict(os.environ, PYTHONPATH=str(Path.cwd() / 'src') + ':' + str(Path.cwd() / 'scripts'),
           OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', PYTHONUNBUFFERED='1')
command = [sys.executable, str(checked(plan['controller_script'])), str(plan_path)]
log_path = root / 'production-handoff-v6-controller.log'
with log_path.open('x') as log:
    process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
write_json(root / 'production-handoff-v6-launch.json', {
    'pid': process.pid, 'create_time': psutil.Process(process.pid).create_time(), 'command': command,
    'plan': reference(plan_path), 'launcher': reference(__file__), 'log': str(log_path),
    'scope': 'Diagnosed checkpoint-write recovery only: continue control from complete6000, then long from complete1000. Original optimizer/EMA/RNG/source-order/horizons preserved. New frozen source only retains completed last as best, with no second CUDA serialization. No automatic retry or prefix replay.',
})
print('Launched recovery controller', process.pid, psutil.Process(process.pid).create_time())
