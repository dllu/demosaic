"""Bind the actual successful full CUDA-training checkpoint after the repair."""
import os
from pathlib import Path

import torch
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

torch.set_num_threads(2)
root = Path('.cache/experiments/full-corpus-scaling-v3').resolve()
plan_path = root / 'production-handoff-plan-v6.json'
plan = read_json(plan_path)
cfg = yaml.safe_load(checked(plan['configs']['control20k']).read_text())
run = Path(cfg['run'])
out = root / 'checkpoint-recovery-v6/post-repair-checkpoint-validation-v1'
out.mkdir()
before = {name: (run / name).stat() for name in ['last.pt', 'best.pt']}
assert before['last.pt'].st_ino == before['best.pt'].st_ino
assert before['last.pt'].st_dev == before['best.pt'].st_dev
snapshot = out / 'step007000.pt'
os.link(run / 'last.pt', snapshot)
assert snapshot.stat().st_ino == before['last.pt'].st_ino
state = torch.load(snapshot, map_location='cpu', weights_only=True)
assert state['step'] == 7000 and len(state['model']) == len(state['ema']) == 91
assert len(state['optimizer']['state']) == 89
assert all(v['step'] == 7000 for v in state['optimizer']['state'].values())
assert all(torch.isfinite(t).all() for key in ['model', 'ema'] for t in state[key].values())
assert all(torch.isfinite(t).all() for v in state['optimizer']['state'].values() for t in v.values() if isinstance(t, torch.Tensor))
assert state['python_rng'] and state['cuda_rng'] and state['torch_rng'].numel()
assert state['config']['steps'] == 20000 and state['config']['batch_size'] == 16
for name in ['last.pt', 'best.pt']:
    assert (run / name).stat().st_ino == before[name].st_ino
write_json(out / 'result.json', {
    'script': reference(__file__), 'plan': reference(plan_path), 'checkpoint': reference(snapshot),
    'actual_training_step': 7000, 'raw_EMA_tensors_each': 91, 'Adam_states': 89,
    'all_Adam_steps': 7000, 'all_finite': True, 'Python_CPU_CUDA_RNG_present': True,
    'last_and_best_same_complete_inode': True, 'inode': before['last.pt'].st_ino,
    'model_training_source': reference(Path(plan['work']) / 'src/demosaic/train.py'),
    'scope': 'Actual first successful production checkpoint after diagnosed6k best-write stall, not an IO fixture. Step7000 complete checkpoint and atomic best retention independently loaded/validated on CPU and immutably retained before later replacements. No new learned/GPU/noise/RAW/optimizer calls by this verifier. Remaining20k/100k horizons and quality still pending.',
})
print('Actual7000 checkpoint finite/complete, last/best share inode, retained SHA', reference(snapshot)['sha256'])
