"""Admit exact6k/1k resume with only redundant best serialization removed."""
import os
import shutil
from pathlib import Path

import torch
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.train import retain_checkpoint

torch.set_num_threads(2)
repo = Path.cwd()
root = repo / '.cache/experiments/full-corpus-scaling-v3'
prior = read_json(root / 'production-handoff-plan-v2.json')
failure = root / 'checkpoint-stall-step6000-v1'
stop = read_json(failure / 'operator-stop.json')
assert read_json(root / 'production-handoff-v2/03-scale-control20k-result.json')['returncode'] == -15
assert not read_json(root / 'production-handoff-v2/production-result.json')['all_stages_succeeded']
old_train = Path(prior['work']) / 'src/demosaic/train.py'
new_train = repo / 'src/demosaic/train.py'
old, new = old_train.read_text(), new_train.read_text()
helper_start, helper_end = new.index('def retain_checkpoint('), new.index('def save_checkpoint(')
normalized = new[:helper_start] + new[helper_end:]
normalized = normalized.replace('import os\n', '', 1).replace(
    'retain_checkpoint(run / "last.pt", run / "best.pt")',
    'save_checkpoint(run / "best.pt", model, optimizer, ema, step, config, best)')
assert normalized == old, 'Unrelated training source change; do not resume under this admission'
assert '2 passed' in (repo / '.cache/checkpoint-retention-tests-v1.log').read_text()

recovery = root / 'checkpoint-recovery-v5'
recovery.mkdir()
work = recovery / 'work'
for directory in ['src', 'scripts']:
    shutil.copytree(Path(prior['work']) / directory, work / directory,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
shutil.copyfile(new_train, work / 'src/demosaic/train.py')
worker = work / 'scripts/run_full_corpus_continuation_v5.py'
source = checked(prior['worker_script']).read_text()
source = source.replace('    plan = read_json(plan_path)\n', '    plan = read_json(plan_path)\n    verify_plan(plan)\n', 1)
worker.write_text(source)

controller = repo / '.cache/full-corpus-and-context-controller-v5.py'
source = checked(prior['controller_script']).read_text()
line = "plan_path=Path(sys.argv[1]);plan=read_json(plan_path);base_root=Path(plan['root']);root=Path(plan.get('allocation_root',plan['root']));root.mkdir(exist_ok=True)"
assert line in source
source = source.replace(line, line + "\nassert reference(__file__)==plan['controller_script']", 1)
line = "    if stage['kind']=='scale':\n"
assert source.count(line) == 1
source = source.replace(line, line + "        cfg=__import__('yaml').safe_load(checked(plan['configs'][stage['arm']]).read_text())\n        actual=reference(Path(cfg['run'])/'last.pt')\n        assert actual['sha256']==plan['adopted_states'][stage['arm']]['sha256']\n", 1)
controller.open('x').write(source)

adopted = {}
for arm, step in [('control20k', 6000), ('long100k', 1000)]:
    config = yaml.safe_load(checked(prior['configs'][arm]).read_text())
    checkpoint = Path(config['run']) / 'last.pt'
    state = torch.load(checkpoint, map_location='cpu', weights_only=True)
    assert state['step'] == step and len(state['model']) == len(state['ema']) == 91
    assert len(state['optimizer']['state']) == 89 and all(v['step'] == step for v in state['optimizer']['state'].values())
    assert state['config']['steps'] == config['steps']
    assert state['config']['batch_size'] == config['batch_size'] == 16
    if arm == 'control20k':
        assert reference(checkpoint)['sha256'] == stop['checkpoint']['sha256']
    else:
        assert reference(checkpoint)['sha256'] == read_json(checked(prior['adopted_first1000']))['last']['sha256']
    adopted[arm] = stop['checkpoint'] if arm == 'control20k' else read_json(checked(prior['adopted_first1000']))['last']
    del state

# Frozen safety confines writes to its own work root. Only output locations
# change; every training/source/noise/optimizer/horizon value stays identical.
new_configs = dict(prior['configs'])
for arm in ['control20k', 'long100k']:
    original = yaml.safe_load(checked(prior['configs'][arm]).read_text())
    config = dict(original)
    new_run = work / 'artifacts/train' / arm
    new_run.mkdir(parents=True)
    assert new_run.is_relative_to(work)
    os.link(checked(adopted[arm]), new_run / 'last.pt')
    shutil.copyfile(Path(original['run']) / 'initialization.json', new_run / 'initialization.json')
    config['run'] = str(new_run)
    assert {k: v for k, v in config.items() if k != 'run'} == {k: v for k, v in original.items() if k != 'run'}
    path = recovery / (arm + '-continuation.yaml')
    path.open('x').write(yaml.safe_dump(config, sort_keys=False))
    new_configs[arm] = reference(path)

# Exercise retention with the actual complete6k file. Replacing only the probe's
# last name must leave both retained best and authoritative source bytes intact.
probe = recovery / 'retention-qualification'
probe.mkdir()
last, best = probe / 'last.pt', probe / 'best.pt'
os.link(checked(stop['checkpoint']), last)
retain_checkpoint(last, best)
assert reference(best)['sha256'] == stop['checkpoint']['sha256']
replacement = probe / 'last.tmp'
torch.save({'step': 6001, 'qualification_only': True}, replacement)
replacement.replace(last)
assert reference(best)['sha256'] == reference(checked(stop['checkpoint']))['sha256']
assert torch.load(best, map_location='cpu', weights_only=True)['step'] == 6000
write_json(recovery / 'retention-qualification.json', {
    'producer': reference(__file__), 'actual_6k_checkpoint': stop['checkpoint'],
    'retained_best': reference(best), 'best_survives_probe_last_replacement': True,
    'only_training_source_change': 'Atomic hardlink retention of complete last checkpoint as best; no repeated CUDA serialization.',
    'old_train': reference(old_train), 'new_train': reference(work / 'src/demosaic/train.py'),
    'all_other_training_source_bytes_exact': True, 'tests': reference('.cache/checkpoint-retention-tests-v1.log'),
    'scope': 'Actual checkpoint file/state retention qualification. The small6001 dictionary is an IO fixture, not a learned update. No neural/GPU/noise/optimizer calls; no original checkpoint bytes modified.',
})
plan = {**prior, 'work': str(work), 'worker_script': reference(worker), 'configs': new_configs,
        'controller_script': reference(controller), 'allocation_root': str(root / 'production-handoff-v5'),
        'adopted_states': adopted,
        'frozen_files': {str(p): reference(p)['sha256'] for p in work.rglob('*.py')},
        'inputs': [reference(root / 'production-handoff-plan-v2.json'), reference(failure / 'operator-stop.json'),
                   reference(recovery / 'retention-qualification.json'), *new_configs.values(),
                   prior['profile_plan'], prior['parent'], *adopted.values()],
        'compute_schedule': [dict(kind='scale', arm='control20k', updates=14000, maximum_seconds=64800),
                             dict(kind='scale', arm='long100k', updates=99000, maximum_seconds=259200)],
        'checkpoint_write_recovery': reference(failure / 'operator-stop.json'),
        'previous_controller_result': reference(root / 'production-handoff-v2/production-result.json'),
        'scope': 'Explicit continuation after diagnosed redundant best-checkpoint write stall. Adopt complete6000 control and1000 long raw/EMA/Adam/RNG/global indices with original configs/source epochs/horizons. No prefix replay or learning/quality-based reset. Only neural-training source change avoids redundant best serialization by atomic retention of complete last. Original v2 failure/partial bytes/sources remain preserved. Remaining14k control then99k long; no automatic retry.'}
write_json(root / 'production-handoff-plan-v5.json', plan)
print('Admitted recovery: control6000→20000, then long1000→100000; all other training source bytes exact')
