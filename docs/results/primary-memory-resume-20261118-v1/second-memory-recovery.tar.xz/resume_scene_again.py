"""Adopt both validated CPU prefixes after their second RAM-floor exit."""
import argparse
import os
from pathlib import Path
import sys
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from resume import ROOT, Recovery, change, common, scene


class SceneRetry(Recovery):
    def __init__(self, key):
        super().__init__(key)
        self.previous = self.record
        self.record = ROOT / (key+"-retry2")
        self.progress = read_json(self.previous/"progress.json")
        self.count = self.progress["completed_cases"]
        assert self.scene and self.count < 3162

    def begin(self):
        assert not (self.output/"result.json").exists()
        launch = read_json(ROOT/f"{self.previous.name}-launch.json")
        assert not owner_live({"pid":launch["pid"],"created":launch["created"]})
        prior_log = ROOT/f"{self.previous.name}-resumed.log"
        assert "CPU primary runtime RAM floor reached" in prior_log.read_text()
        self.record.mkdir()
        write_json(self.record/"start.json",{
            "driver":reference(__file__),"frozen_collector":reference(self.source),
            "original_plan":reference(self.plan_path),"original_log":reference(prior_log),
            "original_owner":reference(ROOT/f"{self.previous.name}-launch.json"),
            "original_progress":reference(self.previous/"progress.json"),
            "prior_count":self.count,"pid":os.getpid(),"started_unix":time.time(),
            "archive_of_prior_resume":reference(self.previous/"verified-prefix.json"),
        })


def configured(name):
    job = SceneRetry(name)
    code = scene(common(job.source.read_text(),job))
    code = change(code,'"resumed-contexts-20261118-v1"','"resumed-contexts-20261118-v2"')
    compiled = compile(code,str(job.source),"exec")
    return job,compiled


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("name",choices=("scene2k","scene12k"))
    parser.add_argument("--verify",action="store_true")
    arg = parser.parse_args()
    job,source = configured(arg.name)
    if arg.verify:
        directory = job.output
        count = len(list(directory.glob("known-*/result.json")))+len(list(directory.glob("unseen-*/result.json")))+len(list(directory.glob("photo-*/result.json")))
        assert count in (job.count,job.count-3), (directory,count,job.count)
        print(job.plan_path,job.count, count,flush=True)
        return
    sys.path.insert(0,str(job.source.parent))
    namespace = {"__name__":"frozen_primary_resume_retry2","__file__":str(job.source),"RESUME":job}
    exec(source,namespace)
    namespace["collect"](job.plan_path,"full")


if __name__=="__main__":
    main()
