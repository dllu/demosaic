"""Restore the planned V120 adoption after the resumed 100k panel closes."""

from importlib.machinery import SourceFileLoader
from pathlib import Path
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
job = read_json(ROOT/"corpus100k-retry1-launch.json")
previous = ROOT.parent/"full-corpus-long100k-review-v1"
original = previous/"primary"
baseline = ROOT.parent/"full-corpus-control20k-review-queue-v1/primary20k"
rel = Path("collection/result.json")
destination = previous/"canonical-combined"

while not (original/rel).is_file():
    if not owner_live(job):
        raise RuntimeError("Resumed 100k collector exited without a completed panel")
    time.sleep(30)

native = read_json(original/rel)
assert native["all_complete"] and native["cases"] == 3162
checked(native["recovery"])
camera = previous/"canonical-camera"/rel
assert read_json(camera)["cases"] == 54
function = SourceFileLoader("adopt_primary", str(previous/"adopt-primary.py")).load_module()
function.adopt(original, baseline, destination, ("known", "unseen", "photo"), "scale-long100k")
write_json(previous/"primary-with-V120.json", {
    "camera": reference(camera), "primary": reference(destination/rel),
    "recovery": native["recovery"],
    "scope": "Fixed complete primary panels from checked saved V120 and exact matching 100k CPU predictions.",
})
