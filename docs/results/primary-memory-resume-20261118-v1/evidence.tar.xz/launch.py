"""Start the verified-prefix collectors in detached process groups."""

from pathlib import Path
import os
import subprocess
import sys

import psutil
from demosaic.experiments.artifacts import reference, write_json
from resume import Recovery, RUNS

ROOT = Path(__file__).resolve().parent

for name in RUNS:
    job = Recovery(name)
    assert not job.record.exists()
    work = job.source.parents[1]
    threads = str(job.plan["CPU_threads"])
    env = dict(os.environ, PYTHONPATH=f"{work}/src:{work}/scripts", CUDA_VISIBLE_DEVICES="",
               OMP_NUM_THREADS=threads, OPENBLAS_NUM_THREADS=threads if name == "corpus100k" else "1",
               PYTHONUNBUFFERED="1")
    command = [sys.executable, str(ROOT/"resume.py"), name]
    with (ROOT/f"{name}-resumed.log").open("xb") as log:
        proc = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, start_new_session=True)
        write_json(ROOT/f"{name}-launch.json", {"pid": proc.pid, "created": psutil.Process(proc.pid).create_time(),
                   "command": command, "resume_source": reference(ROOT/"resume.py"), "plan": reference(job.plan_path)})
        print(name, proc.pid, flush=True)
