"""Bind interrupted-prefix and first resumed batch evidence to the four plans."""

import hashlib
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from resume import Recovery, RUNS

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
RESULTS = REPO/"docs/results/primary-memory-resume-20261118-v1"


def predecessor(job, record):
    start = read_json(record/"start.json")
    old = read_json(checked(start["original_progress"]))
    assert old["completed_cases"] == job.count
    assert "runtime RAM floor reached" in checked(start["original_log"]).read_text()
    for name in ("driver", "frozen_collector", "original_owner", "original_plan"):
        checked(start[name])
    return start


def main():
    published = []
    included = {p.name:p for p in ROOT.glob("*.py")}
    for name in RUNS:
        job = Recovery(name)
        local = name in ("corpus100k","near-adc")
        suffix = "-retry1" if local else ""
        record = ROOT/(name+suffix)
        before = predecessor(job, record)
        closure = record/"verified-prefix.json"
        verification = read_json(closure)
        assert verification["predictions_SHA256_verified"] and verification["completed"] == job.count
        stage, batch = verification["first_missing"]
        first = job.output/f"{stage}-{batch:05d}"/"result.json"
        case = read_json(first)
        assert (case["stage"],case["batch"]) == (stage,batch)
        canonical = read_json(checked(job.plan["canonical_inputs"]))
        qualifying = next(r for r in canonical["records"] if r["stage"] == stage and r["batch"] == batch)
        assert case["canonical_arrays"] == qualifying["arrays"]
        for variant in case["variants"]:
            checked(variant["prediction"])
            assert variant["checkpoint"] == job.plan["models"][variant["arm"]]["checkpoint"]
        log = ROOT/f"{name}{suffix if local else '-resumed'}.log"
        assert f"{stage} {batch} {job.count+1} of 3162" in log.read_text()
        launch = ROOT/f"{name}{suffix}-launch.json"
        published.append({"run": name, "old_completed": job.count, "first_new": reference(first),
                          "canonical_case": [stage,batch], "startup": reference(record/"start.json"),
                          "verified_prefix": reference(closure), "launch": reference(launch),
                          "original_plan": before["original_plan"], "original_log": before["original_log"]})
        for path in (closure,record/"start.json",launch,checked(before["original_progress"]),
                     checked(before["original_log"])):
            included[f"{name}/{path.name}"] = path
        if local:
            failure = ROOT/f"{name}-resumed.log"
            assert "AssertionError" in failure.read_text()
            included[f"{name}/first-restart.log"] = failure
    watcher = ROOT/"adopt100k-launch.json"
    included[watcher.name] = watcher
    RESULTS.mkdir(exist_ok=True)
    archive = RESULTS/"evidence.tar.xz"
    contents = {name:reference(p) for name,p in included.items()}
    with tarfile.open(archive,"w:xz",preset=4) as tar:
        for name,path in sorted(included.items()):
            tar.add(path,arcname=name)
    with tarfile.open(archive,"r:xz") as tar:
        assert set(tar.getnames()) == set(contents)
        for key,ref in contents.items():
            assert hashlib.sha256(tar.extractfile(key).read()).hexdigest() == ref["sha256"]
    write_json(RESULTS/"publication.json", {"verified_prefixes_and_resumes": published,
               "100k_adoption_watcher": reference(watcher),
               "source_archive": {"path":archive.relative_to(REPO).as_posix(), "sha256":reference(archive)["sha256"]},
               "archive_contents": contents,
               "scope": "CPU benchmark recovery after an erroneous outer product in unrelated verification caused memory pressure. Prior evaluator ownership, logs, plans and completed cases were preserved. This receipt verifies restart, not complete panels."})


if __name__ == "__main__":
    main()
