"""Resume the four stopped fixed panels from their verified completed prefixes."""

import argparse
import os
from pathlib import Path
import sys
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RUNS = {
    "scene2k": ("scene-primary-cpu-v1/full-plan.json", "full", 2424),
    "corpus100k": ("full-corpus-long100k-review-v1/primary/plan.json", "collection", 1887),
    "near-adc": ("near-adc-bridge-training-v1/primary-verified/full/plan.json", "collection", 701),
    "scene12k": ("expanded-scene-12000-primary-v3/full-plan.json", "full", 261),
}


class Recovery:
    def __init__(self, key):
        rel, self.action, self.count = RUNS[key]
        self.record = ROOT / (key+"-retry1")
        self.plan_path = ROOT.parent / rel
        self.plan = read_json(self.plan_path)
        self.source = checked(self.plan["driver"])
        self.scene = self.action == "full"
        self.output = Path(self.plan["root"]) / self.action
        self.finished = None

    def begin(self):
        self.record.mkdir()
        assert not (self.output/"result.json").exists()
        source_log = self.output.parent/"full.log" if self.scene else (
            self.output.parent.parent / ("full.log" if "near-adc" in str(self.plan_path) else "primary.log"))
        source = source_log.read_text()
        assert "runtime RAM floor reached" in source
        self.progress = read_json(self.output/"progress.json")
        assert self.progress["completed_cases"] == self.count
        write_json(self.record/"start.json", {
            "driver": reference(__file__), "frozen_collector": reference(self.source),
            "original_plan": reference(self.plan_path), "original_log": reference(source_log),
            "original_owner": reference(self.output/"owner.json"),
            "original_progress": reference(self.output/"progress.json"),
            "prior_count": self.count, "pid": os.getpid(), "started_unix": time.time(),
        })

    def scan(self, selected, adopted=None):
        """Check exactly one completed prefix, including checkpoint and input identity."""
        adopted = adopted or {}
        previous = {}
        seen = set()
        contexts = {}
        adopted_contexts = {f["key"] for row in adopted.values() for f in row["fields"]}
        missing = []
        for entry in selected:
            key = entry["stage"], entry["batch"]
            folder = self.output/f"{key[0]}-{key[1]:05d}"
            path = folder/"result.json"
            if key in adopted:
                assert not folder.exists()
                seen.add(key)
                continue
            if not path.is_file():
                assert not folder.exists(), f"Incomplete output directory {folder}"
                missing.append(key)
                continue
            assert not missing, f"Saved cases are not a prefix: {key}"
            value = read_json(path)
            assert (value["stage"], value["batch"]) == key
            assert value["canonical_arrays"] == entry["arrays"]
            if not self.scene:
                assert value["input_fingerprints"] == {name: entry["fingerprints"][name]
                    for name in ("packed", "variance", "colors", "wb", "matrix")}
            assert {v["arm"] for v in value["variants"]} == set(self.plan["models"])
            for variant in value["variants"]:
                assert variant["checkpoint"] == self.plan["models"][variant["arm"]]["checkpoint"]
                assert [v["id"] for v in variant["rows"]] == entry["context"]["ids"]
                assert all(v["model"] == variant["arm"] for v in variant["rows"])
                checked(variant["prediction"])
            for field in value.get("fields", []):
                identity = field["key"]
                assert contexts.setdefault(identity, field) == field
                assert Path(field["arrays"]["path"]).is_file()
            assert value["local_frozen_DINO"]["executions"] == 1
            previous[key] = reference(path), value
            seen.add(key)
        assert len(seen) == self.count
        assert len(missing) + self.count == len(selected) == 3162
        assert all(key[0] == "photo" for key in missing)
        new_contexts = {key: value for key,value in contexts.items() if key not in adopted_contexts}
        if self.scene:
            assert len(new_contexts) == self.progress["scene_DINO_executions"]
        self.finished = (len(new_contexts), sum("surround_noise_seed" in v["metadata"] for v in new_contexts.values()),
                         sum(not k.startswith("photo-") for k in new_contexts))
        write_json(self.record/"verified-prefix.json", {
            "completed": self.count, "first_missing": missing[0], "remaining": len(missing),
            "predictions_SHA256_verified": True, "original_plan": reference(self.plan_path),
            "resumed_context_totals": self.finished,
        })
        print(f"Verified {self.count} fixed cases, resuming at {missing[0]}", flush=True)
        return previous

    def final(self):
        return {"recovery": reference(self.record/"verified-prefix.json"),
                "recovery_start": reference(self.record/"start.json")}


def change(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def common(source, recovery):
    before = '''    output.mkdir()
    write_json(
        output / "owner.json",
        {
            "pid": os.getpid(),
            "create_time": psutil.Process().create_time(),
            "plan": reference(plan_path),
        },
    )'''
    source = change(source, before, "    RESUME.begin()")
    source = change(source, 'output / "progress.json"', 'RESUME.record / "progress.json"')
    # Keep the original output path and plan for the final public receipt.
    assert 'output / "result.json"' in source
    return source


LOCAL_SAVED = '''            if key in previous:
                binding, result = previous[key]
                for variant in result["variants"]:
                    arm = variant["arm"]
                    rows = variant["rows"]
                    if arm == plan["parent_label"] and key in parent_checks:
                        comparison = parent_checks[key]
                        assert comparison["canonical_arrays"] == record["arrays"]
                        assert comparison["checkpoint"] == variant["checkpoint"]
                        np.testing.assert_array_equal(
                            np.load(checked(comparison["prediction"]), allow_pickle=False),
                            np.load(checked(variant["prediction"]), allow_pickle=False),
                        )
                        assert rows == comparison["rows"]
                        comparisons.append({"stage": key[0], "batch": key[1],
                                            "all_output_values_bitexact": True,
                                            "previous_prediction": comparison["prediction"],
                                            "all_metric_rows_bitexact": True})
                    metric_rows[key[0]].extend(rows)
                cases.append(binding)
                totals["root"] += result["new_root_calls"]
                for name in ("requests", "executions", "replays"):
                    totals["local_DINO_" + name] += result["local_frozen_DINO"][name]
                continue
'''

SCENE_SAVED = '''            if key in previous:
                binding, result = previous[key]
                for variant in result["variants"]:
                    metric_rows[key[0]].extend(variant["rows"])
                    totals["reused_parent_CPU_predictions"] += int(variant["reused_CPU_probe"])
                totals["new_roots"] += result["new_root_calls"]
                for name in ("requests", "executions", "replays"):
                    totals["local_DINO_" + name] += result["local_frozen_DINO"][name]
                case_records.append(binding)
                continue
'''


def local(source):
    source = change(source, '    models, before, counters = {}, {}, {}',
                    '    previous = RESUME.scan(selected)\n    models, before, counters = {}, {}, {}')
    source = change(source, '            with np.load(checked(record["arrays"]), allow_pickle=False) as values:',
                   LOCAL_SAVED + '            with np.load(checked(record["arrays"]), allow_pickle=False) as values:')
    source = change(source, 'c["root"] == len(selected)', 'c["root"] == len(selected) - len(previous)')
    source = change(source, '            "CPU_rng_unchanged": True,',
                    '            "CPU_rng_unchanged": True,\n            **RESUME.final(),')
    return source


def scene(source):
    source = change(source, 'output / "contexts"', 'output / "resumed-contexts-20261118-v1"')
    source = change(source, '    prior_cpu = read_json(checked(plan["parent_CPU_probes"]))',
                    '    previous = RESUME.scan(selected, inherited)\n'
                    '    old_scene, old_surrounds, old_decodes = RESUME.finished\n'
                    '    prior_cpu = read_json(checked(plan["parent_CPU_probes"]))')
    source = change(source, '            if key in inherited:\n                result = inherited[key]',
                    SCENE_SAVED + '            if key in inherited:\n                result = inherited[key]')
    source = change(source, '"scene_DINO_executions": fields.new_scene_executions,\n                },',
                    '"scene_DINO_executions": old_scene + fields.new_scene_executions,\n                },')
    for field, original in (("scene_DINO_executions", "fields.new_scene_executions"),
                            ("new_surround_draws", "fields.new_surround_draws"),
                            ("RAW_decodes", "fields.RAW_decodes")):
        previous = {"scene_DINO_executions":"old_scene", "new_surround_draws":"old_surrounds",
                    "RAW_decodes":"old_decodes"}[field]
        source = change(source, f'            "{field}": {original},\n            "', 
                        f'            "{field}": {previous} + {original},\n            "')
    source = change(source, '            "DINO_unchanged": True,',
                    '            "DINO_unchanged": True,\n            **RESUME.final(),')
    return source


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run", choices=RUNS)
    parser.add_argument("--validate-source", action="store_true")
    args = parser.parse_args()
    job = Recovery(args.run)
    source = common(job.source.read_text(), job)
    source = scene(source) if job.scene else local(source)
    runtime = compile(source, str(job.source), "exec")
    if args.validate_source:
        print(job.source, job.output, job.count)
        return
    sys.path.insert(0, str(job.source.parent))
    runtime_namespace = {"__name__": "frozen_primary_resume", "__file__": str(job.source), "RESUME": job}
    exec(runtime, runtime_namespace)
    collect = runtime_namespace["collect"]
    suffix = ("full",) if job.scene else ()
    collect(job.plan_path, *suffix)


if __name__ == "__main__":
    main()
