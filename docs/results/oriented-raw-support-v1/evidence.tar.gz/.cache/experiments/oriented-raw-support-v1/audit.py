"""Independently verify calibrated restorations using delivered native RGB values."""

from collections import defaultdict
from pathlib import Path
from math import sqrt

import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
rp = root / "review/result.json"
report = read_json(rp)
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
prior = read_json(checked(plan["adopted_report"]))
adopted = read_json(checked(plan["adopted_collection"]))
rows = defaultdict(list)
for row in report["leave_one_geometry_out"]:
    rows[row["profile"], row["placement"], row["source"]].append(row)

region = np.s_[..., 128:384, 128:384]
reproduced = defaultdict(list)
for group, observed, saved in zip(plan["groups"], collection["synthetic"], adopted["synthetic"], strict=True):
    assert group["id"] == observed["id"]
    tests = rows[group["profile"], group["placement"], group["source"]]
    assert len(tests) == 9
    with np.load(checked(group["arrays"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][region]
    weak = (target[2]-target[1]).ravel()
    strong = (target[1]-target[0]).ravel()
    weak_power, strong_power = weak @ weak, strong @ strong
    parent = np.load(checked(group["parent"])).astype(np.float64)
    variants = {f"{r['method']}-t{r['threshold']:g}" for r in tests}
    cached = defaultdict(list)
    for row, control in zip(observed["rows"], saved["rows"], strict=True):
        with np.load(checked(row["prediction"])) as current, np.load(checked(control["prediction"])) as old:
            for name in variants:
                if name.startswith("square-"):
                    t = name.rsplit("-t",1)[-1]
                    key = f"subharmonic-t{t}" if saved["changed"] else f"pooled-t{t}" if t != "0" else "minimum-t0"
                    cached[name].append(old[key].astype(np.float64))
                else:
                    cached[name].append(current[name].astype(np.float64))
    for ri, row in enumerate(tests):
        assert set(row["calibration_sources"]) == set(range(8)) - {group["source"]}
        assert 0 <= row["scale"] <= 1
        assert row["calibration_quiet_delta_DN16"] <= row["budget_DN16"] + 1e-10
        method = row["method"]
        value = parent.copy()
        value[region] *= 1 - row["scale"]
        value[region] += row["scale"] * np.stack(cached[f"{method}-t{row['threshold']:g}"])
        error = value - target
        blank = error[region][..., quiet]
        dweak = (error[2] - error[1]).ravel()
        direct = [
            65535**2*(np.linalg.norm(blank.ravel())**2 / blank.size),
            65535**2*(np.linalg.norm(error[region].ravel())**2 / error[region].size),
            65535**2*(np.linalg.norm(dweak)**2 / dweak.size),
            (value[2] - value[1]).ravel() @ weak / weak_power,
            (value[1] - value[0]).ravel() @ strong / strong_power,
            error[1].ravel() @ weak / weak_power,
        ]
        reproduced[group["profile"], group["placement"], group["source"], ri].append(direct)

checks = 0
largest_error = 0.0
for (profile, place, source, ri), items in reproduced.items():
    assert len(items) == 4
    result = np.mean(items, axis=0)
    result[:3] = np.sqrt(result[:3])
    original = rows[profile, place, source][ri]
    expected = np.array([original[key] for key in ("quiet_RMS_DN16", "query_RMS_DN16",
        "weak_increment_RMS_DN16", "weak_gain", "strong_gain", "weak_absent_projection")])
    np.testing.assert_allclose(result, expected, atol=1e-9, rtol=1e-9)
    largest_error = max(largest_error, np.max(np.abs(result-expected)))
    checks += len(expected)

def pixels(image, panel):
    x,y,w,h = panel["png_xywh"]
    assert (w,h) == (160,160)
    return image[y:y+h,x:x+w]

prior_by_id = {b["id"]:b for b in prior["camera_boards"]}
copied = 0
for now in report["camera_boards"]:
    old = prior_by_id[now["id"]]
    a, b = [np.asarray(Image.open(checked(v["image"]))) for v in (now, old)]
    kept = [p for p in now["panels"] if p["label"] not in {"Along wire","Across wire"}]
    for p,q in zip(kept,old["panels"],strict=True):
        assert p["label"] == q["label"]
        np.testing.assert_array_equal(pixels(a,p),pixels(b,q))
        copied += 1

triplet_subsets = 0
for item in report["synthetic_boards"]:
    full, short = item["board"], item["triplet"]
    a,b = [np.asarray(Image.open(checked(v["image"]))) for v in (full,short)]
    for i,j in enumerate((0,3,5)):
        np.testing.assert_array_equal(pixels(a,full["panels"][j]),pixels(b,short["panels"][i]))
    triplet_subsets += 1

assert len(reproduced) == 288 and checks == 1728 and copied == 80 and triplet_subsets == 4
write_json(root / "review/independent-audit.json", {
    "driver":reference(__file__), "report":reference(rp), "status":"passed",
    "held_out_rows":len(reproduced), "direct_image_reductions":checks,
    "maximum_difference":float(largest_error), "unchanged_native_crops_bitexact":copied,
    "exact_native_triplet_subsets":triplet_subsets, "each_calibration_excludes_its_test_geometry":True,
})
print(checks, copied, triplet_subsets, largest_error)
