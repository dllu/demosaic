"""Measure edge error in the ISO6400 wire-free role at the fixed report gate."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root=Path(__file__).resolve().parent
plan_path=root/"plan.json"
plan=read_json(plan_path)
out, records = [], []
for g in plan["groups"]:
    if (g["profile"],g["placement"])!=("iso6400","near"):
        continue
    record=root/"output"/f"{g['id']}.json"
    observed=read_json(record)
    assert g["id"]==observed["id"]
    records.append(reference(record))
    with np.load(checked(g["arrays"])) as a:
        truth=a["target"][0,:,128:384,128:384].astype(np.float64)
        edge=a["edge_band"][128:384,128:384]
        quiet=a["quiet"][128:384,128:384]
    assert edge.sum()>100 and quiet.sum()>100
    role=observed["rows"][0]
    assert role["role"]==0
    with np.load(checked(role["prediction"])) as a:
        for method in ("square","along","across"):
            error=a[f"{method}-t2"].astype(np.float64)-truth
            rgb=error[:,edge]
            rgb_centered=rgb-rgb.mean(axis=1,keepdims=True)
            chroma=rgb-rgb.mean(axis=0,keepdims=True)
            chroma_centered=chroma-chroma.mean(axis=1,keepdims=True)
            def rms(x):
                return float(np.sqrt(np.mean(x**2))*65535)
            out.append({"id":g["id"],"source":g["source"],"CFA":g["CFA"],"method":method,
                        "edge_count":int(edge.sum()),"quiet_count":int(quiet.sum()),
                        "edge_RGB_RMS_DN16":rms(rgb),"edge_centered_RGB_RMS_DN16":rms(rgb_centered),
                        "edge_centered_color_RMS_DN16":rms(chroma_centered),
                        "quiet_RGB_RMS_DN16":rms(error[:,quiet])})
assert len(out)==96
names=("edge_RGB_RMS_DN16","edge_centered_RGB_RMS_DN16","edge_centered_color_RMS_DN16","quiet_RGB_RMS_DN16")
means={}
for label in ("square","along","across"):
    data=[v for v in out if v["method"]==label]
    assert len(data)==32
    means[label]={name:float(np.mean([v[name] for v in data])) for name in names}
write_json(root/"edge-diagnostics.json",{
    "plan":reference(plan_path),"case_records":records,"producer":reference(__file__),"rows":out,"means":means,
    "scope":"Fixed t2 on 32 near-edge ISO6400 no-wire observations. Edge mask from exact scene geometry."
            " Spatial error centers each channel over the mask. Color removes the pixel RGB mean and per-channel"
            " spatial DC. All quantities use the synthetic camera-linear channels.",
})
print(means)
