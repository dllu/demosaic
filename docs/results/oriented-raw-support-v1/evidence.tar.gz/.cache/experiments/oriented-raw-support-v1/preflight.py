"""Check exact square controls and footprint properties on the live collection."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import oriented_validation_footprint

root=Path(__file__).resolve().parent
plan=read_json(root/"plan.json")
prior=read_json(checked(plan["adopted_collection"]))
arms=("along","across")
records=[]
changed=0
n=plan["config"]["validation_window"]
for group, unmodified in zip(plan["groups"][:8],prior["synthetic"][:8],strict=True):
    path=root/"output"/f"{group['id']}.json"
    view=read_json(path)
    assert view["id"] == unmodified["id"] == group["id"]
    for frequency in group["frequencies"]:
        masks=[oriented_validation_footprint(n,frequency,name) for name in arms]
        assert not np.array_equal(*masks)
        for name,mask in zip(arms,masks,strict=True):
            np.testing.assert_array_equal(mask,mask[::-1,::-1])
            np.testing.assert_array_equal(mask,oriented_validation_footprint(n,-np.array(frequency),name))
            assert abs(mask.sum()/n**2-1)<.005
    for row in view["rows"]:
        with np.load(checked(row["prediction"])) as a, np.load(checked(row["adopted_prediction"])) as b:
            assert a["square-t2"].shape==(3,256,256)
            np.testing.assert_array_equal(a["square-t2"],b["subharmonic-t2" if unmodified["changed"] else "pooled-t2"])
            changed += int(np.any(a["along-t0"]!=a["across-t0"]))
            assert all(np.isfinite(a[key]).all() for key in a.files)
    records.append(reference(path))
assert changed>0
write_json(root/"preflight.json",{
    "driver":reference(__file__),"plan":reference(root/"plan.json"),"cases":records,
    "square_t2_outputs_bitexact":24,"along_across_t0_different":changed,
    "footprint_sign_and_center_symmetry":True,"maximum_relative_site_count_error":.005,
})
print("24 exact square controls;",changed,"have differing along and across outputs at t0")
