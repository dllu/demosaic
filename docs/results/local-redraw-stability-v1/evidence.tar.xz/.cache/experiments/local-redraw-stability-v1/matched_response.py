"""Compare the new losses to earlier outputs at matched mean detail response."""


import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_stability import LABELS, PRIOR, ROOT, metrics

FIELDS = {
    "photo": ("fine_response_pp", "fine_increment_RMS_DN16", "exact_flat_fine_RMS_DN16"),
    "wire": (
        "weak_response_pp",
        "intact_increment_RMS_DN16",
        "gap_weak_RMS_DN16",
        "exact_flat_RMS_DN16",
    ),
}


def main():
    proof = reference(ROOT / "review/result.json")
    previous = reference(PRIOR / "review/result.json")
    current, old = (read_json(checked(link)) for link in (proof, previous))
    results = {}
    for kind, fields in FIELDS.items():
        prior = {row["source"]["index"]: row for row in old[kind]}
        rows = current["groups"][kind]["rows"]
        prior_rows = [prior[row["source"]["index"]] for row in rows]
        assert all(
            a["input"] == b["input"] and a["source"] == b["source"]
            for a, b in zip(rows, prior_rows, strict=True)
        )
        response = fields[0]
        individual, mean = [
            float(np.mean([r["scores"][label][response] for r in prior_rows]))
            for label in ("Individual redraw loss", "Mean redraw loss")
        ]
        results[kind] = dict(old_response_range=[individual, mean], arms={})
        foils = []
        for name in LABELS.values():
            value = current["groups"][kind]["summary"][response]["values"][name]
            dose = (value - individual) / (mean - individual)
            if 0 <= dose <= 1:
                foils.append((name, dose, value))
            else:
                results[kind]["arms"][name] = dict(response=value, inside_old_range=False)
        for name, dose, value in foils:
            per_source = []
            for case, baseline in zip(rows, prior_rows, strict=True):
                with np.load(checked(case["input"]), allow_pickle=False) as data:
                    args = {k: data[k] for k in data.files}
                individual_rgb, mean_rgb = (
                    np.load(checked(baseline["outputs"][arm]), allow_pickle=False)
                    for arm in ("individual", "mean")
                )
                measured = metrics(
                    case, (individual_rgb * (1 - dose) + mean_rgb * dose).astype(np.float32), args
                )
                per_source.append(
                    dict(
                        id=case["source"]["source"]["id"],
                        comparison={
                            k: [case["scores"][name].get(k), measured.get(k)] for k in fields
                        },
                    )
                )
            contrasts = {}
            rng = np.random.default_rng(202611191231)
            for key in fields:
                pair = np.asarray(
                    [
                        r["comparison"][key]
                        for r in per_source
                        if r["comparison"][key][0] is not None
                    ]
                )
                n = len(pair)
                bs = np.vstack([np.arange(n), rng.integers(n, size=(6500, n))])
                pooled = (
                    np.sqrt(np.mean(pair[bs] ** 2, axis=1))
                    if kind == "photo" and key.endswith("RMS_DN16")
                    else np.mean(pair[bs], axis=1)
                )
                diff = pooled[:, 0] - pooled[:, 1]
                contrasts[key] = dict(
                    arm=pooled[0, 0],
                    mixture=pooled[0, 1],
                    delta=diff[0],
                    interval=np.quantile(diff[1:], [0.025, 0.975]).tolist(),
                )
            assert abs(contrasts[response]["delta"]) < 0.02
            results[kind]["arms"][name] = dict(
                response=value,
                inside_old_range=True,
                share_mean=dose,
                contrasts=contrasts,
                rows=per_source,
            )
    write_json(
        ROOT / "matched-response.json",
        dict(
            review=proof,
            prior=previous,
            driver=reference(__file__),
            results=results,
            scope="Descriptive response matching on the scored data. One mixture coefficient per target kind and arm. No extrapolation or independently calibrated deployment policy.",
        ),
    )


if __name__ == "__main__":
    main()
