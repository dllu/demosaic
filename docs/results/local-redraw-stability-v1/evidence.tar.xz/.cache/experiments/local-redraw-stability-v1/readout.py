"""Read matched stability estimates from their completed receipts."""

from pathlib import Path

from demosaic.experiments.artifacts import read_json

ROOT = Path(__file__).resolve().parent
KEYS = {
    "photo": (
        "fine_response_pp",
        "fine_increment_RMS_DN16",
        "exact_flat_fine_RMS_DN16",
        "flat_fine_RMS_DN16",
        "flat_chroma_RMS_DN16",
    ),
    "wire": (
        "weak_response_pp",
        "intact_increment_RMS_DN16",
        "gap_RMS_DN16",
        "gap_weak_RMS_DN16",
        "exact_flat_RMS_DN16",
    ),
    "draws": (
        "pooled_response_pp",
        "mean_increment_RMS_DN16",
        "shared_error_product_DN16_squared",
        "swapped_draw_variance_DN16_squared",
        "mean_present_RMS_DN16",
        "mean_quiet_RMS_DN16",
    ),
}


def show(panel, kind):
    print(kind)
    for field in KEYS[kind]:
        if field not in panel:
            continue
        item = panel[field]
        values = " ".join(f"{name}={value:.4f}" for name, value in item["values"].items())
        print(field, item["cases"], values)
        for comp in (
            "Repeat loss vs Mean control",
            "Repeat + gap loss vs Repeat loss",
            "Repeat + gap loss vs Mean parent",
        ):
            diff = item["differences"][comp]
            print(
                " ",
                comp,
                f"{diff['delta']:.4f} [{diff['interval'][0]:.4f}, {diff['interval'][1]:.4f}]",
            )


if __name__ == "__main__":
    review = read_json(ROOT / "review/result.json")
    for kind, group in review["groups"].items():
        show(group["summary"], kind)
    print("Exact", [item["id"] for item in review["exact"]])
    for row in review["standing"]:
        print(row["id"], row["rms_vs_parent_DN16"])
    redraw = ROOT / "review/redraw.json"
    if redraw.exists():
        for law, group in read_json(redraw)["groups"].items():
            print(law)
            show(group["summary"], "draws")
