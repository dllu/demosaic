"""Run native review and canonical cameras, then start the exact full-photo replay."""

from pathlib import Path
import os
import subprocess
import sys
import time

import psutil

from demosaic.experiments.artifacts import checked, read_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent


def run(log_name, *args, env=None):
    with (ROOT / log_name).open("xb") as log:
        subprocess.run(
            [sys.executable, "-u", *map(str, args)],
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
            env=env,
        )


def main():
    end = ROOT / "training/completed.json"
    owner = read_json(ROOT / "training/owner.json")
    while not end.is_file():
        if not owner_live(owner) and not end.is_file():
            raise RuntimeError("Training stopped without a final checkpoint")
        time.sleep(8)
    completed = read_json(end)
    for proof in completed["checkpoints"].values():
        checked(proof)
    run("review.log", ROOT / "review_stability.py")
    fixed = ROOT.with_name("scene-compact-050000-v1")
    training = ROOT.with_name("scene-full-epoch-v1")
    dest = ROOT / "primary"
    run(
        "prepare-primary.log",
        "scripts/collect_scene_primary_compact.py",
        "prepare",
        dest,
        fixed / "plan.json",
        training / "matched-050000.json",
        "--continuation",
        end,
        "--only-continuation",
    )
    driver = dest / "work/scripts/collect_scene_primary_compact.py"
    env = os.environ | {"PYTHONPATH": str(dest / "work/src")}
    for stage in ("preflight", "cameras"):
        run(f"{stage}.log", driver, stage, dest / "plan.json", env=env)
    # Preserve headroom while the previous fixed-panel workers retain their model sets.
    while psutil.virtual_memory().available < 32 * 2**30:
        time.sleep(15)
    run("full-photo.log", driver, "full", dest / "plan.json", env=env)


if __name__ == "__main__":
    main()
