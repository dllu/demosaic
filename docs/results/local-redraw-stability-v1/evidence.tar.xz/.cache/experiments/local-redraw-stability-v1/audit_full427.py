"""Audit completed compact photo replays by exact canonical case identity."""

import argparse
import math
import tarfile
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def identities(record):
    return [
        (case, record["context"]["pattern"], record["context"]["condition"]["name"])
        for case in record["context"]["ids"]
    ]


def measure(plan_ref, record, batch, arms):
    assert batch["plan"] == plan_ref and batch["stage"] == record["stage"] == "photo"
    assert batch["batch"] == record["batch"] and batch["arrays"] == record["arrays"]
    assert set(batch["variants"]) == set(arms)
    keys = identities(record)
    scored = {}
    for arm, arm_batch in batch["variants"].items():
        output = arm_batch["output_fingerprint"]
        rows = arm_batch["rows"]
        assert output["dtype"].endswith("f4") and output["shape"][0] == len(keys) == len(rows)
        assert [(row["id"], row["pattern"], row["condition"]) for row in rows] == keys
        scored[arm] = {}
        for key, row in zip(keys, rows, strict=True):
            expected_kind = "synthetic" if key[0].startswith("synthetic-") else "photo"
            assert row["model"] == arm and row["kind"] == expected_kind
            value = row["metrics"]["srgb_psnr"]
            assert math.isfinite(value)
            if expected_kind == "photo":
                scored[arm][key] = value
    return scored


def close(root, out):
    plan_ref = reference(root / "plan.json")
    result_ref = reference(root / "full/result.json")
    plan, result = (read_json(checked(x)) for x in (plan_ref, result_ref))
    assert result["plan"] == plan_ref and result["scope"] == "full" and result["complete"]
    assert result["counts"] == {"photo": 3108, "known": 24, "unseen": 30}
    assert (
        result["models"] == plan["models"]
        and result["canonical_inputs"] == plan["canonical_inputs"]
    )
    bound = read_json(checked(plan["canonical_inputs"]))
    assert bound["all_input_witnesses_exact"]
    photo = {r["batch"]: r for r in bound["records"] if r["stage"] == "photo"}
    archived = {
        p.name: x for x in result["cases"] if (p := Path(x["path"])).name.startswith("photo-")
    }
    assert len(photo) == len(archived) == 3108
    modeled = {name: {} for name in plan["models"]}
    for number, record in sorted(photo.items()):
        binding = archived[f"photo-{number:05d}.json"]
        scores = measure(plan_ref, record, read_json(checked(binding)), modeled)
        for arm, cases in scores.items():
            assert modeled[arm].keys().isdisjoint(cases)
            modeled[arm].update(cases)
    conditioned = Counter(
        (pattern, condition) for _, pattern, condition in next(iter(modeled.values()))
    )
    assert len(conditioned) == 28 and set(conditioned.values()) == {427}
    assert len({condition for _, condition in conditioned}) == 7
    assert {pattern for pattern, _ in conditioned} == {"RGGB", "BGGR", "GRBG", "GBRG"}
    summaries = {}
    for arm, cases in modeled.items():
        per_source = defaultdict(list)
        for (case, _, _), psnr in cases.items():
            per_source[case].append(psnr)
        assert len(cases) == 427 * 28 and len(per_source) == 427
        assert all(len(values) == 28 for values in per_source.values())
        means = {k: float(np.mean(v)) for k, v in sorted(per_source.items())}
        score = float(np.mean(list(means.values())))
        archived_overall = next(
            row
            for row in result["summaries"]["photo"]["overall"]
            if row["model"] == arm and row["kind"] == "photo"
        )["metrics"]["srgb_psnr"]
        assert archived_overall["count"] == 427 and math.isclose(
            score, archived_overall["mean"], abs_tol=1e-10
        )
        summaries[arm] = dict(source_means=means, sRGB_PSNR=score)
    ids = tuple(summaries["V120"]["source_means"])
    assert all(tuple(a["source_means"]) == ids for a in summaries.values())
    random = np.random.default_rng(42)
    bootstrap = random.integers(len(ids), size=(6500, len(ids)))
    for arm, arm_stats in summaries.items():
        for label in ("V120", "prior-mean" if "prior-mean" in summaries else "none"):
            if label not in summaries or label == arm:
                continue
            diff = np.array(
                [arm_stats["source_means"][k] - summaries[label]["source_means"][k] for k in ids]
            )
            arm_stats[f"vs_{label}"] = dict(
                delta_dB=float(diff.mean()),
                above=int((diff > 0).sum()),
                below=int((diff < 0).sum()),
                interval_dB=np.quantile(diff[bootstrap].mean(1), [0.025, 0.975]).tolist(),
            )
    out.mkdir(parents=True)
    audit = out / "photo-analysis.json"
    write_json(
        audit,
        dict(
            plan=plan_ref,
            canonical_inputs=plan["canonical_inputs"],
            full_replay=result_ref,
            matching_canonical_arrays=True,
            models=plan["models"],
            sources=427,
            conditions=7,
            CFA=4,
            proper_photo_cases=11956,
            total_batches=3108,
            cases=archived,
            summary=summaries,
        ),
    )
    bundle = out / "photo-evidence.tar.xz"
    with tarfile.open(bundle, "x:xz", preset=4) as tar:
        for name, binding in [
            ("plan.json", plan_ref),
            ("result.json", result_ref),
            ("analysis.json", reference(audit)),
            ("audit.py", reference(__file__)),
            *sorted(archived.items()),
        ]:
            tar.add(checked(binding), arcname=name, recursive=False)
    write_json(
        out / "photo-publication.json",
        dict(
            plan=plan_ref,
            canonical_inputs=plan["canonical_inputs"],
            analysis=reference(audit),
            archive=reference(bundle),
            models=plan["models"],
            sRGB_PSNR={a: s["sRGB_PSNR"] for a, s in summaries.items()},
            sources=427,
            conditions=7,
            CFA=4,
            proper_photo_cases=11956,
            complete=True,
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    close(args.root, args.out)
