"""Summarize matched-budget evidence with paired source statistics."""
from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np

from report_fold_support_pooling import evaluated, scale_at_budget
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
rp = root / "review/result.json"
report = read_json(rp)
plan = read_json(checked(report["plan"]))
thresholds = plan["thresholds"]
budgets = plan["positive_quiet_RMS_budgets_DN16"]
arms = ("minimum", "pooled")
pairs = defaultdict(dict)
for row in report["leave_one_geometry_out"]:
    key = row["profile"], row["placement"], row["budget_DN16"], row["source"]
    pairs[key][row["method"]] = row
assert len(pairs) == 96 and all(set(v) == set(arms) for v in pairs.values())
metrics = ("weak_gain", "strong_gain", "quiet_RMS_DN16", "weak_increment_RMS_DN16",
           "query_RMS_DN16", "mean_absolute_weak_absent_projection")
def result_value(row, field):
    if field == metrics[-1]:
        return abs(row["weak_absent_projection"])
    return row[field]

by_axis = defaultdict(list)
for row in report["fixed_threshold_metrics"]:
    by_axis[row["profile"],row["placement"],row["method"],row["source"]].append(row["moments"])
source_moments = {}
for key, observations in by_axis.items():
    assert len(observations) == 4
    source_moments[key] = {m:np.mean([v[m] for v in observations],axis=0) for m in observations[0]}

result = []
curves = []
envelope = []
rng = np.random.default_rng(20261117)
bootstrap = rng.integers(0,8,(12000,8))
fig, axes = plt.subplots(2,2,figsize=(10,8),layout="constrained")
for pi, profile in enumerate(("iso400","iso6400")):
    for ei, place in enumerate(("far","near")):
        ax = axes[pi,ei]
        for name, color, marker in zip(arms,("#5058b5","#087f65"),("o","^"),strict=True):
            series = []
            for t in thresholds:
                method = f"{name if t else 'minimum'}-t{t:g}"
                moments = [source_moments[profile,place,method,source] for source in range(8)]
                matrix = np.array([[result_value(evaluated(v, 1), k) for k in metrics] for v in moments])
                baseline = np.array([[result_value(evaluated(v, 0), k) for k in metrics] for v in moments])
                delta = (matrix-baseline).mean(0)
                series.append((delta[2],100*delta[0]))
                curves.append({"profile":profile,"placement":place,"method":name,"threshold":t,
                               "means":matrix.mean(0).tolist(),"delta_from_parent":delta.tolist()})
            x,y=zip(*series,strict=True)
            ax.plot(x,y,label=name.capitalize(),color=color,marker=marker,linewidth=1.4,markersize=4)
            for i, t in enumerate(thresholds):
                if (name=="minimum" and t==0) or (t in (0.5,2) and abs(x[i])>0.02):
                    ax.annotate(f"{t:g}",(x[i],y[i]),xytext=(4,5 if name=="minimum" else -9),
                                textcoords="offset points",fontsize=7,color=color)
        ax.scatter([0],[0],color="black",marker="+",s=60,zorder=4,label="V143 parent")
        ax.set_title(f"{profile.upper()} · {'far from edge' if place=='far' else 'near edge'}",loc="left",
                     fontweight="bold")
        ax.set_xlabel("Quiet RMS change (DN16)")
        ax.set_ylabel("Weak response change (percentage points)")
        ax.grid(alpha=0.15)
        ax.spines[["top","right"]].set_visible(False)
        if not(pi or ei):
            ax.legend(frameon=False)

        for budget in budgets:
            pair = [pairs[profile,place,budget,i] for i in range(8)]
            a,b = [np.array([[result_value(v[m],k) for k in metrics] for v in pair]) for m in arms]
            delta = b-a
            interval = np.quantile(delta[bootstrap].mean(1),[.025,.975],axis=0)
            row = {"profile":profile,"placement":place,"budget_DN16":budget,
                   "means": {arms[0]:a.mean(0).tolist(),arms[1]:b.mean(0).tolist()},
                   "delta_pooled_minus_minimum":delta.mean(0).tolist(),
                   "source_deltas":delta.tolist(),"paired_descriptive_intervals":interval.tolist(),
                   "heldout_quiet_delta": {m:float(np.mean([v[m]["delta_from_parent"]["quiet_RMS_DN16"] for v in pair])) for m in arms},
                   "number_of_distinct_choices":sum((v[arms[0]]["threshold"],v[arms[0]]["scale"])
                        !=(v[arms[1]]["threshold"],v[arms[1]]["scale"]) for v in pair)}
            result.append(row)
            for i in range(8):
                best = {}
                for name in arms:
                    options = []
                    for t in thresholds:
                        k = f"{name if t else 'minimum'}-t{t:g}"
                        v = source_moments[profile,place,k,i]
                        alpha = scale_at_budget(v["quiet_mse"],budget) if v["weak_gain"][1]>0 else 0.0
                        baseline= evaluated(v,0)
                        measured= evaluated(v,alpha)
                        change=measured["quiet_RMS_DN16"]-baseline["quiet_RMS_DN16"]
                        assert change<=budget+1e-10
                        options.append((measured["weak_gain"],-t,alpha,measured))
                    _,neg_t,alpha,measured=max(options,key=lambda row:row[:3])
                    best[name]={"threshold":-neg_t,"scale":alpha,**measured}
                envelope.append({"profile":profile,"placement":place,"source":i,"budget_DN16":budget,"target_assisted":best})
fig.suptitle("Weak-wire response at fixed held-out support thresholds",fontsize=14,fontweight="bold")
figure = root / "review/quiet-tradeoff.png"
fig.savefig(figure,dpi=150)
assert len(result)==12 and len(envelope)==96
write_json(root/"review/summary.json",{
    "source":reference(rp),"producer":reference(__file__),"plot":reference(figure),
    "metrics":list(metrics),"calibrated":result,"fixed_threshold_curves":curves,
    "target_assisted_same_case_budget_envelope":envelope,
    "scope":"Means and paired descriptive intervals across eight source geometries. Cross-validated held-out costs"
            " may differ between arms. The separate target-assisted envelope matches each geometry's"
            " budget using its own exact targets, showing what each fixed sweep could deliver with oracle selection.",
})
print("Summarized",len(result),"calibrated comparisons and",len(envelope),"target-assisted pairs")
