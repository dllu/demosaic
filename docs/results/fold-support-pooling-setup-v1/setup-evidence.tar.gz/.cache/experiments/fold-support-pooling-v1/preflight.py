"""Qualify source exclusion, RMS scaling and the first published collection outputs."""

from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import psutil

from report_fold_support_pooling import evaluated, matched_quiet, measure, scale_at_budget
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
plan = read_json(root/"plan.json")
launch = read_json(root/"launch.json")
owner = psutil.Process(launch["pid"])
assert owner.create_time() == launch["create_time"] and owner.status() != psutil.STATUS_ZOMBIE
selected = plan["groups"][:4]
results = []
crop = np.s_[..., 128:384, 128:384]
for group in selected:
    path = root/"output"/f"{group['id']}.json"
    result = read_json(path)
    assert result["id"] == group["id"]
    parent = np.load(checked(group["parent"])).astype(np.float64)
    with np.load(checked(group["arrays"])) as data:
        truth = data["target"].astype(np.float64)
        quiet = data["quiet"][crop]
    values = []
    for sample in result["rows"]:
        with np.load(checked(sample["prediction"])) as actual, np.load(checked(sample["adopted_prediction"])) as expected:
            for threshold in (0,2,4):
                np.testing.assert_array_equal(actual[f"minimum-t{threshold}"],expected[f"shrunken-profile-t{threshold}"])
            values.append(actual["pooled-t2"])
    pooled = np.stack(values)
    moments = measure(parent,truth,quiet,pooled)
    for budget in plan["positive_quiet_RMS_budgets_DN16"]:
        alpha = scale_at_budget(moments["quiet_mse"], budget)
        value = parent.copy()
        value[crop] *= 1-alpha
        value[crop] += alpha*pooled.astype(np.float64)
        actual = (value-truth)[crop][..., quiet].reshape(-1)
        rms = np.linalg.norm(actual)/np.sqrt(actual.size)*65535
        np.testing.assert_allclose(rms,evaluated(moments,alpha)["quiet_RMS_DN16"],atol=1e-10)
        assert rms <= evaluated(moments,0)["quiet_RMS_DN16"] + budget + 1e-10
    results.append(reference(path))

rows = []
for t in (0,2):
    for mode in ["minimum"] if not t else ["minimum","pooled"]:
        for source in range(8):
            for cfa in ("RGGB","GBRG","GRBG","BGGR"):
                rows.append({"profile":"iso6400","placement":"far","source":source,"CFA":cfa,
                     "method":f"{mode}-t{t}", "moments":{
                         "quiet_mse":[144.,-2.,40. if t==0 else 10.],
                         "query_mse":[100.,-1.,2.],
                         "weak_increment_mse":[130.,-3.,10.],
                         "weak_gain":[0.02,(0.1 if t==0 else 0.06)+source*.001],
                         "strong_gain":[0.03,0.1],
                         "weak_absent_projection":[0.0,0.03]}})
def choices(values):
    return {v["method"]:(v["threshold"],v["scale"],v["weak_gain"])
         for v in matched_quiet(values,[0,2],[0.02]) if v["source"]==0}
a = choices(rows)
for row in rows:
    if row["source"]==0:
        row["moments"]["weak_gain"][1] *= 1e6
        row["moments"]["quiet_mse"] = [144.,200.,4000.]
b = choices(rows)
assert all(a[name][:2]==b[name][:2] and a[name][2]!=b[name][2] for name in a)
write_json(root/"preflight.json", {"driver":reference(__file__),
    "plan":reference(root/"plan.json"), "launch":reference(root/"launch.json"),
    "as_observed":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
    "source_records":results,"exact_prior_control_predictions":36,"direct_quiet_error_checks":12,
    "mutating_test_target_moments_preserved_calibration_choices":True,
    "scope":"Four completed case groups from the live collector. Calibration exclusion tested through both modes. Full numerical and native review pending.",
})
print("36 controls, 12 direct quiet-error checks, both out-of-fold choices isolated")
