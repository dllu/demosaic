"""Direct independent error reductions and absent-wire checks for the closed pilot."""
from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(".cache/experiments/scene-wave-guide-probe-v1").resolve()
plan = read_json(root / "plan.json")
result = read_json(root / "review/result.json")
collection = read_json(checked(result["collection"]))
groups = defaultdict(list)
for row in plan["cases"]:
    groups[row["profile"],row["placement"],row["source"]].append(row)
outputs = {row["id"]: row["outputs"] for row in collection["rows"]}
metrics = {(row["profile"],row["placement"],row["source"],row["method"]): row
           for row in result["measurements"]}
methods = ["V143", "query-only", "matching-guide", "unrelated-guide"]
audited = 0
maximum = 0.
absent_rows = []
for (profile, placement, source), rows in groups.items():
    with np.load(checked(rows[0]["arrays"])) as data:
        truth = data["target"].astype(np.float64)
        quiet = data["quiet"]
        edge = data["edge_band"]
    parent = np.load(checked(rows[0]["parent"])).astype(np.float64)
    candidate = {method: parent.copy() for method in methods[1:]}
    for row in rows:
        with np.load(checked(outputs[row["id"]])) as data:
            for method in methods[1:]:
                candidate[method][row["sample"], :, 128:384, 128:384] = data[method]
    for method, values in {"V143": parent, **candidate}.items():
        expected = metrics[profile, placement, source, method]
        error = values - truth
        rms = lambda x: float(np.linalg.norm(x.ravel()) / np.sqrt(x.size)) * 65535
        actual = {"full_error_RMS_DN16": rms(error),
                  "query_error_RMS_DN16": rms(error[..., 128:384, 128:384])}
        for name, mask in [("quiet", quiet), ("edge", edge)]:
            region = error[..., mask]
            mean = np.sum(region, axis=-1, keepdims=True) / region.shape[-1]
            actual[name + "_error_RMS_DN16"] = rms(region)
            actual[name + "_DC_RMS_DN16"] = rms(mean)
            actual[name + "_spatial_RMS_DN16"] = rms(region-mean)
        absent = {}
        for name, before, after in [("strong", 0, 1), ("weak", 1, 2)]:
            t, v = (truth[after] - truth[before]).ravel(), (values[after] - values[before]).ravel()
            gain = float(np.dot(t,v) / np.dot(t,t))
            actual[name + "_gain"] = gain
            actual[name + "_increment_error_RMS_DN16"] = rms(v-t)
            actual[name + "_orthogonal_RMS_DN16"] = rms(v-gain*t)
            # The counterfactual template is available only at scoring. Measure
            # how much of it appears in the output for the absent role.
            absent[name + "_absent_projection"] = float(np.dot(error[before].ravel(),t)/np.dot(t,t))
            absent[name + "_absent_context_RMS_DN16"] = rms(error[before,:,128:384,128:384])
        absent_rows.append({"profile": profile, "placement": placement, "geometry": source,
                            "method": method, **absent})
        for key,value in actual.items():
            maximum = max(maximum,abs(value-expected[key]))
            np.testing.assert_allclose(value,expected[key],rtol=1e-12,atol=1e-10)
        audited += len(actual)
for board in result["boards"]:
    image = np.asarray(Image.open(checked(board["board"]["image"])))
    triplet = np.asarray(Image.open(checked(board["triplet"]["image"])))
    for p,i in zip(board["triplet"]["panels"],[0,3,5],strict=True):
        x,y,w,h = p["png_xywh"]
        xx,yy,ww,hh = board["board"]["panels"][i]["png_xywh"]
        assert (w,h)==(ww,hh)==(160,160)
        np.testing.assert_array_equal(triplet[y:y+h,x:x+w],image[yy:yy+h,xx:xx+w])
assert len(absent_rows) == len(metrics) == 128
output = root / "review/independent-audit.json"
write_json(output, {
    "producer": reference(__file__), "result": reference(root / "review/result.json"),
    "metric_comparisons": audited, "rows": len(metrics), "triplet_subsets": len(result["boards"]),
    "maximum_numeric_difference": maximum, "absent_role_metrics": absent_rows, "status": "passed",
    "scope": "Recompute every original score from direct sums and vector norms. Absent-role"
             " projections and context RMS diagnose false detail at the query, including inside"
             " the expected wire footprint. Four exact native triplet subsets.",
})
print(audited, "direct reductions and four exact triplet subsets", maximum)
