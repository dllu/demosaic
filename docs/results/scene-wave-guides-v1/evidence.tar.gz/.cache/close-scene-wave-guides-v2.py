"""Wait for the owned collection, then score and audit its unchanged outputs."""
import os
import sys
import time
from pathlib import Path
import subprocess
import psutil
from demosaic.experiments.artifacts import read_json,reference,write_json
root=Path(".cache/experiments/scene-wave-guide-probe-v2").resolve()
collector=read_json(root/"launch.json")
path=root/"output/collection.json"
deadline=time.monotonic()+1800
while not path.exists():
    proc=psutil.Process(collector["pid"])
    assert proc.create_time()==collector["create_time"] and proc.status()!=psutil.STATUS_ZOMBIE
    if time.monotonic()>deadline:
        raise TimeoutError("Review observation window exceeded. No producer restart.")
    time.sleep(5)
work=root/"work"
env={**os.environ, "CUDA_VISIBLE_DEVICES":"", "PYTHONPATH":f"{work}/scripts:{work}/src", "OPENBLAS_NUM_THREADS":"2"}
steps=[("report",work/"scripts/report_scene_wave_guides.py",[str(root)]),
       ("audit",Path(".cache/audit-scene-wave-guides-v2.py"),[])]
for name,script,args in steps:
    command=[sys.executable,str(script),*args]
    with (root/(name+".log")).open("xb") as log:
        result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    write_json(root/(name+"-return.json"),{"returncode":result.returncode,"command":command,
                                         "collection":reference(path),"script":reference(script)})
    assert result.returncode==0
