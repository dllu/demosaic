"""Cross-check native GFX pixels against the existing matched review."""
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

base=Path(".cache/experiments/scene-wave-guide-real-v1")
result=read_json(base/"result.json")
collection=read_json(checked(result["collection"]))
previous_path=Path(".cache/experiments/full-corpus-control20k-review-queue-v1/native20k/report/result.json")
previous=read_json(previous_path)
original={v["id"]:v for v in previous["boards"]}
rows={v["id"]:v for v in collection["rows"]}
comparisons=[]
for board in result["boards"]:
    old_id=board["id"].replace("-left","-fine-green-mesh-left").replace("-right","-fine-green-mesh-right")
    a=original[old_id]
    image=np.asarray(Image.open(checked(board["image"])))
    old=np.asarray(Image.open(checked(a["image"])))
    def cell(im,record,k):
        x,y,w,h=record["panels"][k]["png_xywh"]
        assert (w,h)==(160,160)
        return im[y:y+h,x:x+w]
    pairs=[(0,0),(1,1),(4,3)] if len(board["panels"])==5 else [(0,0),(1,1),(4,3),(5,4),(6,5)]
    for i,j in pairs:
        np.testing.assert_array_equal(cell(image,board,i),cell(old,a,j))
    row=rows[board["id"]]
    bx,by,w,h=row["query_box"];x,y,rw,rh=board["ROI_xywh"]
    with np.load(checked(row["prediction"]))as data:
        value=data["donor-guide"].astype(np.float64)-data["parent"].astype(np.float64)
        roi=value[...,y-by:y-by+rh,x-bx:x-bx+rw]
        rms=np.linalg.norm(roi.ravel())/np.sqrt(roi.size)*65535
        np.testing.assert_allclose(rms,board["camera_RGB_correction_RMS_DN16"],rtol=0,atol=1e-10)
    comparisons.append({"id":board["id"],"prior_display_panels_bitexact":len(pairs),"ROI_RMS":float(rms)})
assert len(comparisons)==8
write_json(base/"independent-audit.json",{"producer":reference(__file__),"result":reference(base/"result.json"),
    "previous_display_reference":reference(previous_path),"comparisons":comparisons,"status":"passed",
    "scope":"All matched base/noisy/AHD/JPEG native panels exact to closed V120/Corpus20k review. New method pixel cells checked by original producer. Direct RMS on actual native correction pixels."})
print("Verified",sum(v["prior_display_panels_bitexact"]for v in comparisons),"original display panels")
