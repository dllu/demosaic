"""Check pre-change unguided execution on retained probe observations."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json,reference,checked,write_json
from demosaic.local_validated_waves import LocalWaveConfig,restore_local_waves
r=Path(".cache/experiments/scene-wave-guide-probe-v1").resolve()
p=read_json(r/"plan.json");c=read_json(r/"output/collection.json")
old={item["id"]: item["outputs"] for item in c["rows"]};rows=[]
for case in p["cases"]:
 if case["source"]!=0 or case["sample"]!=2:continue
 with np.load(checked(case["arrays"])) as z:
  packed=z["packed"][2,:,64:192,64:192];colors=z["colors"][2]
 parent=np.load(checked(case["parent"]))[2,:,128:384,128:384]
 noise=case["query_noise"]
 outputs,_=restore_local_waves(parent,packed,colors,shot=noise["shot"],read=noise["read"],
                               config=LocalWaveConfig(**p["config"]),thresholds=(p["threshold"],))
 with np.load(checked(old[case["id"]])) as stored:
  np.testing.assert_array_equal(outputs["local",p["threshold"]],stored["query-only"])
 rows.append({"case":case["id"],"saved_output":old[case["id"]],"bitexact":True})
assert len(rows)==4
write_json(r/"pre-change-query-parity.json",{"producer":reference(__file__),"rows":rows,
    "pre-change_source":reference(Path(restore_local_waves.__code__.co_filename)),
    "scope":"Fresh unguided replay with repo bytes frozen before the proposed guide API."})
print("All four pre-change unguided replays are bit-exact.")
