"""Bind completed fixed-camera metrics, source-compatible comparisons and native boards."""

from datetime import datetime, UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
DEST = REPO/"docs/results/near-adc-camera-audit-v1"
IMAGES = REPO/"docs/images/near-adc-camera-audit-v1"


def relative(p):
    return {"path":p.relative_to(REPO).as_posix(),"sha256":reference(p)["sha256"]}


def main():
    readout = read_json(ROOT/"closed.json")
    join = read_json(checked(readout["join"]))
    plan = read_json(checked(join["plan"]))
    assert len(join["cases"])==54
    viewed = {
        "known-7D-1": "Muted near-edge pattern and visible diagonal boundary. The differences between learned columns are subtle.",
        "known-D60-2": "Low-contrast surface marks and a dark corner look close across EMA predictions.",
        "known-2pilesofplates": "Smooth gray region with a muted lower-edge transition.",
        "known-MuseeL-CopteArch-C500D": "Soft beige texture across all EMA columns.",
        "unseen-LucieB_top_of_Expedit": "Dark brown field stays smooth.",
        "unseen-LucieB_stick_figurine": "Subtle surface variations remain low contrast.",
        "unseen-LucieB_3apples": "Letter edges and the rail keep similar definition.",
        "unseen-LucieB_bedroom_tapestry": "Broad warm and green variation survives; finer texture remains soft.",
        "unseen-LucieB_Coulicoco": "Dark warm shadow transition with similar visible texture.",
    }
    closed = ("closed.json","joined.json","collection.log","collect.py","publish.py")
    files = {name: ROOT/name for name in closed}
    panels, boards = {}, []
    DEST.mkdir()
    IMAGES.mkdir()
    for stage, count, scenes in (("known",24,4),("unseen",30,5)):
        entry = readout["panels"][stage]
        analysis = read_json(checked(entry["analysis"]))
        native = read_json(checked(entry["native"]))
        assert analysis["models"] == plan["models"]
        assert len(analysis["cases"]) == count and len(native["boards"]) == scenes
        checks = analysis["metric_checks"]
        assert all(c["scores_bit_exact"] for c in checks)
        assert sum(c["native_predictions"] for c in checks)==scenes*18*len(plan["models"])
        for field,ref in (("analysis.json",entry["analysis"]),("native.json",entry["native"]),
                          ("per-crop.csv",analysis["per_crop"])):
            files[f"{stage}/{field}"] = checked(ref)
        overall = {arm["model"]: {k: arm["metrics"][k]["mean"]
                   for k in ("sensor_psnr","ahd_srgb_psnr","ahd_srgb_ssim")}
                   for arm in analysis["summary"]["overall"]}
        panels[stage] = {"batches":count,"scenes":scenes,"crops_per_model":scenes*18,
                         "overall":overall,"per_scene":analysis["per_scene"],"analysis":entry["analysis"]}
        for item in native["boards"]:
            assert all(panel["png_xywh"][-2:] == [160,160] for panel in item["panels"])
            path = checked(item["image"])
            output = IMAGES/path.name
            shutil.copyfile(path,output)
            binding = relative(output)
            assert binding["sha256"]==item["image"]["sha256"]
            boards.append(item | {"image":binding,"viewing_note":viewed[item["id"]]})
    assert {r["id"] for r in boards} == set(viewed)
    manifest = IMAGES/"manifest.json"
    write_json(manifest, {"actual_native_viewing":True,"recorded_utc":datetime.now(UTC).isoformat(),
                          "panels":boards, "scope":"Viewed all nine fixed native boards; independent AHD is a qualitative reference."})
    archive = DEST/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=4) as bundle:
        for name,path in files.items():
            bundle.add(path,arcname=name)
    with tarfile.open(archive,"r:xz") as bundle:
        for name,path in files.items():
            assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==reference(path)["sha256"]
    write_json(DEST/"publication.json", {"archive":relative(archive), "native_manifest":relative(manifest),
                    "canonical_inputs":plan["canonical_inputs"],"models":plan["models"],"weights":"EMA",
                    "complete_camera_panels":True,"complete_full427":False,"panels":panels,
                    "original_near_ADC_plan":join["near_adc"],"parents_camera_result":join["baseline"],
                    "scope":"Four EMA endpoints on the exact fixed known and unseen observations. Recomputed every measured-CFA score. No full427 result in this registration."})


if __name__=="__main__":
    main()
