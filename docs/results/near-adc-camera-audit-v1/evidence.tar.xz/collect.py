"""Audit both fixed camera panels using saved near-ADC, parent and V120 predictions."""

import os
from pathlib import Path

from analyze_local_primary_cameras import analyze
from render_local_primary_cameras import render_panel

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent/"near-adc-bridge-training-v1/primary-verified/full"
COMPARISON = ROOT.parent/"full-corpus-long100k-review-v1/canonical-camera"
TARGET = ROOT/"joined"
STAGES = ("known", "unseen")
ARGUMENTS = ("packed","variance","colors","wb","matrix")


def join():
    near = read_json(SOURCE/"plan.json")
    primary = read_json(COMPARISON/"plan.json")
    histories = read_json(COMPARISON/"collection/result.json")
    assert histories["completed_panels"] == list(STAGES) and histories["cases"] == 54
    closure = {Path(x["path"]).parent.name: x for x in histories["case_records"]}
    for key in ("CPU_threads", "canonical_inputs", "DINO_sha256", "driver"):
        assert near[key] == primary[key]
    catalog = read_json(checked(near["canonical_inputs"]))
    assert catalog["all_input_witnesses_exact"]
    methods = {
        **near["models"],
        **primary["models"],
    }
    assert list(methods) == ["bridge-control","bridge-trained","V120","scale-long100k"]
    for arm, label in zip(methods,("Matched control","Near-ADC EMA","V120 EMA","Corpus 100k EMA"),strict=True):
        methods[arm] = methods[arm] | {"display_label":label}
    names = {"models": methods, "root":str(TARGET), "kind":"closed-camera-subset",
             "scope":"Same CPU policy and canonical input arrays. Near-ADC predictions plus archived measured V120 and 100k parent predictions."}
    sink = TARGET/"collection"
    sink.mkdir(parents=True)
    write_json(TARGET/"plan.json", near | names)
    check = []
    for row in catalog["records"]:
        stage = row["stage"]
        if stage not in STAGES:
            continue
        key=f"{stage}-{row['batch']:05d}"
        candidate = reference(SOURCE/"collection"/key/"result.json")
        baseline = closure[key]
        claims = [read_json(checked(path)) for path in (candidate,baseline)]
        expected = {arg:row["fingerprints"][arg] for arg in ARGUMENTS}
        for case in claims:
            assert case["canonical_arrays"] == row["arrays"] and case["input_fingerprints"] == expected
            assert (case["stage"],case["batch"]) == (stage,row["batch"])
        entries = [v for case in claims for v in case["variants"]]
        assert list(methods) == [v["arm"] for v in entries]
        for variant in entries:
            assert variant["checkpoint"] == methods[variant["arm"]]["checkpoint"]
            assert [v["id"] for v in variant["rows"]] == row["context"]["ids"]
            assert variant["weights"] == "EMA"
            checked(variant["prediction"])
        folder = sink/key
        folder.mkdir()
        output = folder/"result.json"
        write_json(output, {"stage":stage,"batch":row["batch"],"canonical_arrays":row["arrays"],
                            "input_fingerprints":expected,"variants":entries,"source_cases":[candidate,baseline]})
        check.append({"joined":reference(output),"sources":[candidate,baseline]})
    assert len(check)==54
    write_json(ROOT/"joined.json", {"driver":reference(__file__),"plan":reference(TARGET/"plan.json"),
                                   "baseline":reference(COMPARISON/"collection/result.json"),
                                   "near_adc":reference(SOURCE/"plan.json"),"cases":check})


def main():
    os.sched_setaffinity(0,[15])
    os.nice(12)
    join()
    original = os.sched_setaffinity
    os.sched_setaffinity = lambda pid, cpus: original(pid, [15])
    phase = {}
    for stage in STAGES:
        analysis = ROOT/stage
        native = ROOT/f"{stage}-native"
        analyze(TARGET, stage, analysis)
        render_panel(analysis/"result.json", native)
        phase[stage] = {"analysis":reference(analysis/"result.json"),"native":reference(native/"result.json")}
    write_json(ROOT/"closed.json", {"join":reference(ROOT/"joined.json"), "panels":phase})


if __name__=="__main__":
    main()
