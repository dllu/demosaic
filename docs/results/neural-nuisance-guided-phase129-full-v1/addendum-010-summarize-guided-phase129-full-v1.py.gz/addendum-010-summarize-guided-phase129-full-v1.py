"""Closed full-run source/CFA/placement costs and adverse tails for documentation."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-review-v1'
producer=repo/'.cache/experiments/neural-nuisance-guided-phase129-full-v1'
assert read_json(producer/'controller-result.json')['producer_stages_succeeded']
assert read_json(root/'controller-result.json')['returncode']==0
cross=read_json(root/'cross-study-comparison.json');summary=read_json(root/'summary.json')
keys=['weak_gain','strong_gain','quiet_error_RMS_DN16','weak_increment_error_RMS_DN16','full_error_RMS_DN16']
cells=[];sources=[]
for profile in ['iso400','iso1600','iso6400']:
    for placement in ['near','far']:
        lookup={r['method']:r for r in cross['means']if(r['profile'],r['placement'])==(profile,placement)}
        parent=next(r for r in summary['means']if(r['profile'],r['placement'],r['method'])==(profile,placement,'V143'))
        means={'V143':{k:parent[k]for k in keys},**{name:{k:r[k]for k in keys}for name,r in lookup.items()}}
        counts={};tails={}
        selected=[r for r in cross['rows']if(r['profile'],r['placement'])==(profile,placement)]
        views={(r['source'],r['pattern'],r['repeat']):{}for r in selected}
        for r in selected:views[r['source'],r['pattern'],r['repeat']][r['method']]=r
        assert len(views)==64
        for method in ['current-analytic','current-NN']:
            joint=sum(v[method]['weak_gain']>v['prior256-NN']['weak_gain']and v[method]['quiet_error_RMS_DN16']<=v['prior256-NN']['quiet_error_RMS_DN16']and v[method]['weak_increment_error_RMS_DN16']<=v['prior256-NN']['weak_increment_error_RMS_DN16']for v in views.values())
            counts[method]={'weak_up_quiet_and_increment_not_up':int(joint),'views':64}
            for key in keys:
                delta=[(v[method][key]-v['prior256-NN'][key],identity)for identity,v in views.items()]
                worst=max(delta)if 'error'in key else min(delta)
                tails[method+'::'+key]={'delta':float(worst[0]),'source_pattern_repeat':worst[1]}
            for source in range(8):
                a=[v[method]for ident,v in views.items()if ident[0]==source]
                b=[v['prior256-NN']for ident,v in views.items()if ident[0]==source]
                sources.append({'profile':profile,'placement':placement,'method':method,'source':source,
                                'current':{k:float(np.mean([r[k]for r in a]))for k in keys},
                                'prior':{k:float(np.mean([r[k]for r in b]))for k in keys}})
        cells.append({'profile':profile,'placement':placement,'means':means,'paired_view_counts':counts,'adverse_view_tails':tails})
contrasts=[{'profile':r['profile'],'placement':r['placement'],'method':r['second'],
            'fields':{k:r['fields'][k]for k in keys}}for r in cross['contrasts']]
write_json(repo/'.cache/guided-phase129-full-documentation-summary-v1.json',{'script':reference(__file__),
           'cross_study':reference(root/'cross-study-comparison.json'),'cells':cells,'sources':sources,'contrasts':contrasts,
           'scope':'All1164 closed/audited; exact8-source bootstrap already independently checked.64 actual paired CFA/repeat views per cell, source clusters reused development geometries. Counts/tails descriptive, no calibrated population claim. No neural replay/GT-based crop selection.'})
for r in cells:
    a=r['means']['current-analytic'];b=r['means']['prior256-NN'];p=r['means']['V143']
    print(r['profile'],r['placement'],'analytic weak/strong%',a['weak_gain']*100,a['strong_gain']*100,
          'quiet/inc vsprior%',*[100*(a[k]/b[k]-1)for k in keys[2:4]],
          'quiet/inc vsparent%',*[100*(a[k]/p[k]-1)for k in keys[2:4]],'joint views',r['paired_view_counts']['current-analytic'])
