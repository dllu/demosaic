"""Close cached-background48-case predictions; no target/reference scoring."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import owner_identity

root = Path(sys.argv[1])
os.sched_setaffinity(0, [int(v) for v in sys.argv[2].split(',')])
os.nice(10)
plan = read_json(root/'plan.json')
verify_plan(plan)
assert len(plan['rows']) == 48 and plan['fine_validation'] == 'neural-parent'
assert plan['prediction_cache'] is None
cache = read_json(checked(plan['background_cache']))
assert {r['id']for r in cache['rows']} == {r['id']for r in plan['rows']}
assert cache['all91_restoration_and_backbone_tensors_unchanged']
(root/'controller.claim').open('x').close()
work = Path(plan['work'])
py = plan['python']
stages = [
    ('backgrounds', [py, str(work/'scripts/pilot_neural_nuisance.py'), 'backgrounds', str(root)], True),
    ('background-audit', [py, str(root/'audit_neural_nuisance_inputs.py'), str(root), str(root/'background-independent-audit.json')], False),
    ('predict', [py, str(work/'scripts/pilot_neural_nuisance.py'), 'predict', str(root)], False),
]
records = []
for name, args, gpu in stages:
    env = dict(os.environ, PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),
               CUDA_VISIBLE_DEVICES='0' if gpu else '', OMP_NUM_THREADS='2',
               OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', PYTHONUNBUFFERED='1')
    began = time.time()
    with (root/(name+'.log')).open('x') as log:
        child = subprocess.Popen(args, env=env, stdout=log, stderr=subprocess.STDOUT)
        write_json(root/(name+'-launch.json'), {'pid': child.pid, 'create_time': psutil.Process(child.pid).create_time(),
                   'command': args, 'controller': owner_identity(), 'plan': reference(root/'plan.json')})
        code = child.wait()
    records.append({'stage': name, 'returncode': code, 'seconds': time.time()-began})
    write_json(root/'controller-progress.json', {'owner': owner_identity(), 'stages': records}, replace=True)
    if code:
        break
    if name == 'backgrounds':
        completed = read_json(root/'backgrounds-collection.json')
        assert completed['new_root_forwards'] == completed['new_encoder_forwards'] == 0
write_json(root/'controller-result.json', {'stages': records, 'all_stages_succeeded': len(records) == len(stages) and all(r['returncode'] == 0 for r in records),
           'plan': reference(root/'plan.json'), 'script': reference(__file__),
           'scope': 'Only cached-field verification, independent physical-input audit and all48 corrections. No new neural calls, targets/references/noise/training. No automatic restart; quality work must wait for explicit terminal success of both declared producers.'})
