"""Closed-only paired metrics, independent reductions and native colour review."""

import sys
from pathlib import Path

import numpy as np
from audit_checkpoint_pilot import crop
from PIL import Image, ImageDraw, ImageFont
from score_colored_fine_wires import colour_increments

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.edge_response import measure

repo = Path.cwd()
root = repo / ".cache/experiments/coloured-parent-innovation129-v1"
pilot = repo / ".cache/experiments/neural-nuisance-parent-innovation129-pilot-v1"
cohort = repo / ".cache/experiments/coloured-fine-wire-neural-v1"
assert "torch" not in sys.modules
for folder in [root, pilot]:
    assert read_json(folder / "controller-result.json")["all_stages_succeeded"]
plan = read_json(cohort / "plan.json")
old = cohort / "variants/joint-fine"
collections = {
    name: read_json(folder / "collection.json")
    for name, folder in [("prior-joint", old), ("innovation", root)]
}
records = {}
for name, collection in collections.items():
    assert len(collection["rows"]) == 48 and collection["new_neural_forwards"] == 0
    assert collection["target_or_reference_arrays_loaded"] == 0
    records[name] = {r["id"]: r for r in collection["rows"]}
matches = 0
for case, a in records["innovation"].items():
    b = records["prior-joint"][case]
    for key in ["parent_values", "packed_values", "colors_values"]:
        assert a[key] == b[key]
    for method in ["H1-global-t2", "H1-local-t2"]:
        np.testing.assert_array_equal(
            np.load(checked(a["predictions"][method])), np.load(checked(b["predictions"][method]))
        )
        matches += 1
parents = {g["group"]: g["parent"] for g in read_json(cohort / "parents-collection.json")["groups"]}
rows = []
maximum = 0.0
fields = channels = 0
figures = []
native = root / "native"
native.mkdir()
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
for group in plan["groups"]:
    with np.load(checked(group["arrays"]), allow_pickle=False) as z:
        arrays = {k: z[k] for k in ["target", "quiet", "edge_band"]}
        physical = {k: z[k][2:3] for k in ["packed", "colors", "wb", "matrix"]}
    values = {"V120": np.load(checked(parents[group["id"]]))}
    bindings = {}
    for name, cases in records.items():
        for method in cases[group["cases"][0]]["predictions"]:
            key = name + "::" + method
            values[key] = np.stack(
                [np.load(checked(cases[c]["predictions"][method])) for c in group["cases"]]
            )
            bindings[key] = cases[group["cases"][2]]["predictions"][method]
    for name, value in values.items():
        row = {
            "profile": group["profile"],
            "source": group["source"],
            "pattern": group["pattern"],
            "method": name,
            **measure(arrays, value),
            **colour_increments(arrays["target"], value),
        }
        rows.append(row)
        # Independent direct norm and cross-product reductions, not producer measure/colour functions.
        truth = arrays["target"].astype(np.float64)
        value = value.astype(np.float64)
        error = value - truth
        norm = lambda x: float(np.linalg.norm(x.ravel()) / np.sqrt(x.size) * 65535)
        expected = {"full_error_RMS_DN16": norm(error)}
        for label, mask in [("quiet", arrays["quiet"]), ("edge", arrays["edge_band"])]:
            selected = error[..., mask]
            dc = selected.mean(-1, keepdims=True)
            expected.update(
                {
                    label + "_error_RMS_DN16": norm(selected),
                    label + "_DC_RMS_DN16": norm(dc),
                    label + "_spatial_RMS_DN16": norm(selected - dc),
                }
            )
        for label, first, second in [("strong", 0, 1), ("weak", 1, 2)]:
            delta, predicted = truth[second] - truth[first], value[second] - value[first]
            gain = float(
                np.dot(delta.ravel(), predicted.ravel()) / np.dot(delta.ravel(), delta.ravel())
            )
            expected[label + "_gain"] = gain
            expected[label + "_increment_error_RMS_DN16"] = norm(predicted - delta)
            expected[label + "_orthogonal_RMS_DN16"] = norm(predicted - gain * delta)
            direction = delta.reshape(3, -1).sum(axis=1)
            direction /= np.linalg.norm(direction)
            expected[label + "_colour_orthogonal_RMS_DN16"] = norm(
                np.cross(predicted.transpose(1, 2, 0), direction)
            )
            for c, channel in enumerate("RGB"):
                expected[label + "_" + channel + "_gain"] = float(
                    np.dot(predicted[c].ravel(), delta[c].ravel())
                    / np.dot(delta[c].ravel(), delta[c].ravel())
                )
        for key, v in expected.items():
            maximum = max(maximum, abs(v - row[key]))
            fields += 1
    display = {k: v[2:3] for k, v in values.items()}
    display.update({"Noisy": noisy_malvar(physical), "Exact GT": arrays["target"][2:3]})
    for arm, method in [("analytic", "conditional-local-t2"), ("neural", "local-t2")]:
        layouts = [
            (
                "comparison",
                [
                    ("Noisy Malvar", "Noisy"),
                    ("V120", "V120"),
                    ("Prior joint", "prior-joint::" + method),
                    ("Parent innovation", "innovation::" + method),
                    ("Exact constructed GT", "Exact GT"),
                ],
            )
        ]
        if group["pattern"] == "RGGB":
            layouts.append(
                (
                    "triplet",
                    [
                        ("Noisy Malvar", "Noisy"),
                        ("Parent innovation", "innovation::" + method),
                        ("Exact constructed GT", "Exact GT"),
                    ],
                )
            )
        for kind, layout in layouts:
            canvas = Image.new("RGB", (8 + 168 * len(layout), 192), "#eeeeee")
            draw = ImageDraw.Draw(canvas)
            panels = []
            for i, (label, key) in enumerate(layout):
                expected = crop(display[key], physical, [176, 176, 160, 160], 16.0)
                x, y = 8 + 168 * i, 24
                canvas.paste(Image.fromarray(expected), (x, y))
                draw.text((x, 5), label, fill="black", font=font)
                panels.append(
                    {
                        "label": label,
                        "method": key,
                        "xywh": [x, y, 160, 160],
                        "prediction": bindings.get(key),
                    }
                )
            path = native / (group["id"] + "-" + arm + "-" + kind + ".png")
            canvas.save(path)
            encoded = np.asarray(Image.open(path))
            for panel in panels:
                x, y, w, h = panel["xywh"]
                np.testing.assert_array_equal(
                    encoded[y : y + h, x : x + w],
                    crop(display[panel["method"]], physical, [176, 176, 160, 160], 16.0),
                )
                channels += w * h * 3
            figures.append(
                {
                    "image": reference(path),
                    "panels": panels,
                    "group": group,
                    "ROI_xywh": [176, 176, 160, 160],
                    "display_exposure": 16.0,
                    "display_contrast": 1,
                    "wb": physical["wb"].tolist(),
                    "matrix": physical["matrix"].tolist(),
                    "parent": parents[group["id"]],
                    "parent_checkpoint": plan["checkpoint"],
                    "model_configuration": reference(root / "analytic-model.json"),
                    "no_resize": True,
                    "reference_role": "Exact constructed sensor RGB GT",
                }
            )
assert len(rows) == 208 and fields == 4368 and maximum < 1e-9
assert len(figures) == 40 and channels == 14131200
means = []
for profile in ["iso1600", "iso6400"]:
    for source in [None, 0, 1]:
        for method in values:
            selected = [
                r
                for r in rows
                if r["profile"] == profile
                and r["method"] == method
                and (source is None or r["source"] == source)
            ]
            means.append(
                {
                    "profile": profile,
                    "source": source,
                    "method": method,
                    **{
                        k: float(np.mean([r[k] for r in selected]))
                        for k in selected[0]
                        if k not in ["profile", "source", "pattern", "method"]
                    },
                }
            )
write_json(
    root / "scores-v1.json",
    {
        "rows": rows,
        "means": means,
        "script": reference(__file__),
        "H1_exact_pair_checks": matches,
        "paired_input_cases": 48,
        "scope": "All96 new corrections across both follow-ups closed before quality analysis. Adaptive validation-target follow-up; same prior joint RGB reconstruction/proposals and observations. Fixedt2 analytic primary, NN secondary, all6 controls. Two synthetic sources/all4CFAs, not camera-population evidence.",
    },
)
write_json(
    root / "native/report.json",
    {
        "figures": figures,
        "RGB_crop_channels_exact": channels,
        "script": reference(__file__),
        "scope": "Native160 fixedROI/exposure16/contrast1, allCFAs/priors/botharms;40 figures prepared, actual viewing still required.",
    },
)
write_json(
    root / "independent-audit-v1.json",
    {
        "script": reference(__file__),
        "fields_checked": fields,
        "maximum_absolute_error": maximum,
        "native_RGB_channels_exact": channels,
        "native_figures": 40,
        "Torch_imported": False,
        "new_neural_forwards": 0,
        "scope": "Independent direct norms/dot/cross-product metric reductions for all208 rows, separate from producer measure/colour functions within this review source. Native pixels use the existing audit display helper and exact PNG rereads, not a new independent display implementation. Actual viewing still pending.",
    },
)
print(
    "208 rows,4368 independent fields; max",
    maximum,
    ";40 native figures ready, actual viewing pending",
)
