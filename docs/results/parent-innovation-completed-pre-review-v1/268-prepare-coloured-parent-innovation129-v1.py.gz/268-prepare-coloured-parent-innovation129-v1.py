"""Admit one adaptive validation-target follow-up; original four variants unchanged."""
from copy import deepcopy
from pathlib import Path

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, verify_plan, write_json

repo = Path.cwd()
cohort = repo/'.cache/experiments/coloured-fine-wire-neural-v1'
root = repo/'.cache/experiments/coloured-parent-innovation129-v1'
assert not root.exists()
source = read_json(cohort/'plan.json')
assert read_json(cohort/'comparison-result.json')['all_corrections_closed']
assert read_json(cohort/'independent-audit-v1.json')['fields_checked'] == 8400
baseline_root = cohort/'variants/joint-fine'
base = read_json(baseline_root/'plan.json')
root.mkdir()
work, files = freeze_sources(repo, root, entries=(
    'pilot_neural_nuisance.py', 'audit_neural_nuisance_inputs.py',
    'score_colored_fine_wires.py', 'audit_colored_fine_wires.py',
    'report_checkpoint_pilot.py', 'audit_checkpoint_pilot.py',
    'report_local_validated_waves.py', 'pilot_phase_aggregation.py',
    'profile_raw_kernel_inference.py',
))
model = deepcopy(read_json(checked(base['model'])))
model.update(kind='Fine H1 innovation validation on genuine A-only V120 RGB',
             fine_validation='neural-parent',
             source=reference(work/'src/demosaic/neural_nuisance.py'),
             joint_source=reference(work/'src/demosaic/joint_colour_evidence.py'),
             fine_validation_source=reference(work/'src/demosaic/spatial_carrier_amplitudes.py'),
             scope='Only fine validation target changes: A-only V120 RGB plus both unshrunk full-fit sinusoidal RAW-minus-that-field innovations; each null removes one delivered direction. Same candidates/coefficients/final RAW-fullparent maps and joint actual-CFA scoring/matching/fixedt2. Broad guided phase unchanged. Does not validate broad+fine or full-input estimator risk. Adaptive follow-up after the original signed-colour failure, not untouched confirmation.')
write_json(root/'analytic-model.json', model)
plan = deepcopy(base)
plan.update(root=str(root), work=str(work), frozen_files=files,
            script=reference(work/'scripts/pilot_neural_nuisance.py'),
            model=reference(root/'analytic-model.json'), fine_validation='neural-parent',
            prediction_cache=None, maximum_new_neural_forwards=0,
            inputs=[reference(baseline_root/'plan.json'), reference(baseline_root/'collection.json'),
                    reference(cohort/'plan.json'), reference(cohort/'neural-completed.json'),
                    reference(cohort/'masked-backgrounds-collection.json'),
                    reference(root/'analytic-model.json'), source['checkpoint'],
                    *[g['arrays']for g in source['groups']], *[r['parent']for r in base['rows']]],
            scope=model['scope']+' All48 new corrections must close before new GT analysis. Reuse96 genuine masked fields and48 V120 parents, zero new root/DINO calls, noise or training updates. Retain original four variants/400 score rows/40 actual figures untouched; new fixedt2 analytic comparison to prior joint support, NN secondary, all6 controls retained.')
write_json(root/'plan.json', plan)
verify_plan(plan)
write_json(root/'study.json', {'plan': reference(root/'plan.json'), 'script': reference(__file__),
            'baseline': reference(baseline_root/'collection.json'), 'cohort': reference(cohort/'plan.json'),
            'primary': 'conditional-local-t2 versus original joint-fine conditional-local-t2; local-t2 secondary',
            'expected_cases': 48, 'expected_new_neural_forwards': 0,
            'scope': plan['scope']})
print('One48-case adaptive validation-target follow-up admitted, fixedt2 and96 cached fields')
