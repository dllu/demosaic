"""Launch two frozen validation-target follow-ups after passing regression tests."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

repo = Path.cwd()
assert '114 passed' in (repo/'.cache/parent-innovation-regression-tests-v1.log').read_text()
assert psutil.virtual_memory().available > 48*2**30 and shutil.disk_usage(repo).free > 96*2**30
specs = [('neural-nuisance-parent-innovation129-pilot-v1', '14,15'), ('coloured-parent-innovation129-v1', '16,17')]
identities = []
for name, cpus in specs:
    root = repo/'.cache/experiments'/name
    plan = read_json(root/'plan.json')
    verify_plan(plan)
    assert not (root/'launch.json').exists()
    assert plan['fine_validation'] == 'neural-parent' and plan['fine_support'] == 'joint'
    assert plan['fine_reconstruction'] == 'sinusoidal' and plan['phase_guide']
    shutil.copyfile(repo/'scripts/audit_neural_nuisance_inputs.py', root/'audit_neural_nuisance_inputs.py')
    shutil.copyfile(repo/'.cache/parent-innovation-controller-v1.py', root/'controller.py')
    env = dict(os.environ, PYTHONPATH=str(repo/'src'), OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2')
    with (root/'controller.log').open('x') as log:
        child = subprocess.Popen([sys.executable, str(root/'controller.py'), str(root), cpus],
                                 stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    identity = {'pid': child.pid, 'create_time': psutil.Process(child.pid).create_time(),
                'plan': reference(root/'plan.json'), 'controller': reference(root/'controller.py'),
                'background_audit_source': reference(root/'audit_neural_nuisance_inputs.py'),
                'launcher': reference(__file__), 'cpus': cpus, 'no_restart': True}
    write_json(root/'launch.json', identity)
    identities.append(identity)
pilot = repo/'.cache/experiments'/specs[0][0]
write_json(pilot/'study.json', {'plan': reference(pilot/'plan.json'),
            'baseline': reference(repo/'.cache/experiments/neural-nuisance-joint-fine129-pilot-v1/plan.json'),
            'secondary_new_coloured_plan': identities[1]['plan'], 'launcher': reference(__file__),
            'primary': 'conditional-local-t2 versus prior joint-fine conditional-local-t2; NN secondary; original0/2/4 andH1 controls retained',
            'scope': 'Adaptive48-case original development pilot with both standing GFX families/ROIs/profiles/JPEGs; procedural parentV143, real parent/A-only teacherV120. Teacher/parent mismatch disclosed; new coloured cohort instead usesV120 for both. Changes fine full/null validation target only, same geometry/RGB reconstruction/delivery operator. All96 corrections across both follow-ups must close before new GT/reference analysis.0 fresh NN/noise/training;88+96 cached fields. No calibrated risk/generalization claim.'})
write_json(repo/'.cache/parent-innovation-followups-launch-v1.json', {'producers': identities,
           'tests': reference(repo/'.cache/parent-innovation-regression-tests-v1.log'),
           'scope': 'Both frozen producers admitted before quality analysis. No worker restart. Each cache matches all48 actual case IDs, physical/mask/argument checks repeated before CPU corrections; zero root/DINO calls required.'})
print(identities)
