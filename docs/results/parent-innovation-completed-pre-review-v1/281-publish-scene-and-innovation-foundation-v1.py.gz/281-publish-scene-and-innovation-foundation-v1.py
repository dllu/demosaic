"""Preserve completed numerical controls and scene-context foundation evidence."""
import gzip
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
roots = [repo/'.cache/experiments'/n for n in ['neural-nuisance-parent-innovation129-pilot-v1', 'coloured-parent-innovation129-v1']]
assert read_json(roots[0]/'quality-review-result.json')['all_stages_succeeded']
for root in roots:
    assert read_json(root/'controller-result.json')['all_stages_succeeded']
    assert read_json(root/'backgrounds-collection.json')['new_root_forwards'] == 0
    assert read_json(root/'backgrounds-collection.json')['new_encoder_forwards'] == 0
assert '114 passed' in (repo/'.cache/parent-innovation-regression-tests-v1.log').read_text()
assert '8 passed' in (repo/'.cache/scene-context-tests-v2.log').read_text()

def archives(destination, sources):
    items = []
    seen = set()
    for i, source in enumerate(sources):
        source = source.resolve()
        if source in seen:
            continue
        seen.add(source)
        target = destination/f'{i:03d}-{source.name}.gz'
        with target.open('xb') as stream:
            stream.write(gzip.compress(source.read_bytes(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == source.read_bytes()
        items.append({'original': reference(source), 'published': reference(target), 'decompressed_bytes_exact': True})
    return items

dest = repo/'docs/results/parent-innovation-completed-pre-review-v1'
dest.mkdir()
sources = []
bundles = []
for index, root in enumerate(roots):
    plan = read_json(root/'plan.json')
    work = Path(plan['work'])
    target = dest/f'executed-source-{index}.tar.gz'
    members = []
    with tarfile.open(target, 'x:gz') as tar:
        for path, digest in sorted(plan['frozen_files'].items()):
            original = checked({'path': path, 'sha256': digest})
            member = str(original.relative_to(work))
            tar.add(original, arcname=member, recursive=False)
            members.append({'original': reference(original), 'member': member})
    with tarfile.open(target, 'r:gz') as tar:
        for item in members:
            assert tar.extractfile(item['member']).read() == checked(item['original']).read_bytes()
    bundles.append({'archive': reference(target), 'members': members, 'root': str(root)})
    sources += [p for p in sorted(root.rglob('*')) if p.is_file() and work not in p.parents and p.suffix in ['.json','.log','.py']]
sources += [repo/'.cache'/name for name in [
    'parent-innovation-followups-launch-v1.json', 'parent-innovation-controller-v1.py',
    'launch-parent-innovation-followups-v1.py', 'launch-parent-innovation-followups-v1.log',
    'prepare-parent-innovation129-pilot-v1.log', 'prepare-coloured-parent-innovation129-v1.py',
    'prepare-coloured-parent-innovation129-v1.log', 'review-parent-innovation-followups-v1.py',
    'review-parent-innovation-followups-v1.log', 'review-coloured-parent-innovation129-v1.py',
    'parent-innovation-lint-v1.log', 'parent-innovation-lint-v2.log', 'parent-innovation-format-v1.log',
    'parent-innovation-targeted-tests-v1.log', 'parent-innovation-regression-tests-v1.log',
    'parent-innovation-colour-review-lint-v1.log',
]]
sources += [repo/'tests'/n for n in ['test_parent_innovation_validation.py','test_fine_carrier_proposals.py']]
sources += [Path(__file__)]
items = archives(dest, sources)
write_json(dest/'publication.json', {'archives': items, 'source_snapshots': bundles,
           'plans': [reference(r/'plan.json')for r in roots], 'numerical_review': reference(roots[0]/'quality-review-result.json'),
           'status': 'Both96 corrections and numerical audits complete; actual native viewing and quality decision pending',
           'new_neural_forwards': 0, 'regression_tests_passed': 114,
           'scope': 'Frozen same-observation fine validation-target control, both standing GFX families retained as qualitative/not GT. Original0/2/4 pilot plus fixedt2 V120 coloured follow-up. No weights/noise/source-media changes.40 coloured native figures and original-pilot native reports prepared, no actual-viewing claim or quality promotion. Preserve exact completed pre-review state.'})
print('Innovation pre-review:', len(items),'exact archives;', [len(b['members'])for b in bundles], 'executed source files')

dest = repo/'docs/results/whole-scene-context-foundation-v1'
dest.mkdir()
sources = [repo/n for n in [
    'src/demosaic/scene_context.py', 'tests/test_scene_context.py', '.cache/audit-whole-scene-training-lineage-v1.py',
    '.cache/audit-whole-scene-training-lineage-v1.log', '.cache/whole-scene-training-lineage-v1.json',
    '.cache/scene-context-tests-v1.log', '.cache/scene-context-tests-v2.log',
    '.cache/scene-context-lint-v1.log', '.cache/scene-context-lint-v2.log',
    '.cache/scene-context-format-v1.log', '.cache/scene-context-format-v2.log',
    'docs/whole-scene-context-next-test.md',
]] + [Path(__file__)]
items = archives(dest, sources)
write_json(dest/'publication.json', {'archives': items, 'tests_passed': 8, 'new_neural_forwards': 0,
           'lineage_inventory': reference(repo/'.cache/whole-scene-training-lineage-v1.json'),
           'source': reference(repo/'src/demosaic/scene_context.py'),
           'status': 'Preview/coordinate primitives and source/header feasibility only; no trained scene branch',
           'scope': 'CFA-aware whole-noisy-observation preview and exact native tile coordinate queries in padded feature space.8 numerical geometry/withholding/low-precision-coordinate checks. Cleaned90781-source metadata and32 NPY headers, no original media, model forward or training. No restoration/semantic-quality or speed claim. Prior6-test log retained; final8-test suite covers FP16/BF16 maps with FP32 coordinates.'})
print('Scene context foundation:',len(items),'exact source/header/test archives;8 tests,0 model forwards')
