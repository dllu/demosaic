"""Review only after both frozen48-case producers terminate successfully."""
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.experiments.runtime import owner_identity

repo = Path.cwd()
root = repo/'.cache/experiments/neural-nuisance-parent-innovation129-pilot-v1'
colour = repo/'.cache/experiments/coloured-parent-innovation129-v1'
identities = read_json(repo/'.cache/parent-innovation-followups-launch-v1.json')['producers']
for folder, identity in zip([root, colour], identities, strict=True):
    assert read_json(folder/'controller-result.json')['all_stages_succeeded']
    assert read_json(folder/'controller-result.json')['plan'] == identity['plan']
    if psutil.pid_exists(identity['pid']):
        process = psutil.Process(identity['pid'])
        assert process.create_time() != identity['create_time'] or process.status() == psutil.STATUS_ZOMBIE
    assert len(read_json(folder/'collection.json')['rows']) == 48
os.sched_setaffinity(0, [14, 15])
os.nice(10)
(root/'quality-review.claim').open('x').close()
plan = read_json(root/'plan.json')
work = Path(plan['work'])
for name in ['review_neural_nuisance.py']:
    shutil.copyfile(repo/'scripts'/name, root/name)
shutil.copyfile(repo/'.cache/review-coloured-parent-innovation129-v1.py', colour/'review-v1.py')
py = sys.executable
stages = [
    ('score', [py,str(work/'scripts/pilot_neural_nuisance.py'),'score',str(root)]),
    ('report', [py,str(work/'scripts/report_local_validated_waves.py'),str(root)]),
    ('audit', [py,str(work/'scripts/audit_local_wave_pilot.py'),str(root)]),
    ('matched', [py,str(work/'scripts/report_phase_aggregation.py'),str(root),str(root/'native'),
                 '--method-label','Innovation fine NN t2','--control-method','conditional-local-t2',
                 '--control-label','Innovation fine A t2','--skip-old-h1-equivalence']),
    ('summary', [py,str(root/'review_neural_nuisance.py'),str(root),str(root/'summary-review')]),
    ('coloured-review', [py,str(colour/'review-v1.py')]),
]
records = []
for name,args in stages:
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONPATH=str(work/'src')+':'+str(work/'scripts')+':'+str(repo/'scripts'),
               OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', PYTHONUNBUFFERED='1')
    began = time.time()
    with (root/('quality-'+name+'.log')).open('x') as log:
        child = subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        write_json(root/('quality-'+name+'-launch.json'),{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),
                   'controller':owner_identity(),'command':args})
        code=child.wait()
    records.append({'stage':name,'returncode':code,'seconds':time.time()-began})
    write_json(root/'quality-review-progress.json',{'stages':records,'owner':owner_identity()},replace=True)
    if code:break
write_json(root/'quality-review-result.json',{'stages':records,'all_stages_succeeded':len(records)==len(stages)and all(r['returncode']==0 for r in records),
           'script':reference(__file__),'plans':[i['plan']for i in identities],
           'scope':'Both96 corrections closed before all quality stages.0 new NN/noise/training. Native actual viewing/publication remains separate.'})
print(records)
