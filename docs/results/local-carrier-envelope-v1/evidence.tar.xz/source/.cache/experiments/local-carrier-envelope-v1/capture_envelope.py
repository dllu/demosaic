"""Freeze new clean photo fixtures and both parental replays before scoring."""

from collections import Counter
from dataclasses import asdict, replace
import hashlib
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent
OUT = Path("/mnt/external/demosaic") / HERE.name
NESTED = OUT.with_name("local-nested-support-v1")
sys.path.insert(0, str(CACHE / NESTED.name))
from freeze_nested import FAMILIES, capture_wide, carrier, filtered_observation
from review_optical import bind_models, run_model
from warped_wire import phase_shift

SALT = 202611200136
CAL = 12
COUNT = 32
SIGMA = .85
STATES = ("straight", "warped")
ROLES = ("present", "strong_only", "flat_core", "edge_only", "uniform")
RAW = np.s_[...,64:192,64:192]
CLEAN = np.s_[...,128:384,128:384]
LIMITS = {"broad": 6., "center": 1.5, "broad_relative": 1.5, "center_relative": .25, "ridge": .35}
FRAMES = (13, 14)


def freeze():
    prior_ref = reference(NESTED / "plan.json")
    prior = read_json(checked(prior_ref))
    trained_ref = reference(OUT.with_name("local-bayer-gain-v1") / "plan.json")
    trained = read_json(checked(trained_ref))
    blocked = [prior_ref, *prior["excluded_manifests"], trained_ref]
    seen = set()
    for binding in blocked:
        path = checked(binding)
        if path.suffix == ".jsonl":
            for item in capture_wide.lines(binding):
                capture_wide.scan(item, seen)
        else:
            capture_wide.scan(read_json(path), seen)
    bound = read_json(checked(prior["earlier_photos_excluded"]))
    for group in bound["panels"].values():
        capture_wide.scan(group["rows"], seen)
    bank = [
        r for r in capture_wide.lines(prior["source_pool"])
        if r["split"] == "val" and r["bin_factor"] == 4 and min(r["shape"][:2]) >= 512
        and {r["id"], r["cache_sha256"]}.isdisjoint(seen)
    ]
    bank.sort(key=lambda r: hashlib.sha256(f"envelope/{SALT}/{r['id']}".encode()).digest())
    selected = []
    capture_wide.SEED = SALT
    for photo in bank:
        if not {photo["id"], photo["cache_sha256"]}.isdisjoint(seen):
            continue
        seen.update((photo["id"], photo["cache_sha256"]))
        i = len(selected)
        (box,) = scene_crop_boxes(photo["shape"][:2], patch_size=512, count=1, seed=scene_seed(SALT,i,"crop"))
        camera = asdict(sample_scene_recipe(scene_seed(SALT,i,"camera")))
        # Each family sees each CFA across successive blocks.
        camera.update(pattern=tuple(PATTERNS)[(i+i//4)%4], black=.03,
                      **{k: prior["noise"][k] for k in ("shot","read","exposure")})
        rng = np.random.default_rng(scene_seed(SALT,i,"phase"))
        s = rng.choice([-1,1],3)
        variant = dict(zip(("tilt_t","tilt_n","bend"),
                           (s*rng.uniform([1.8,.45,1.35],[4.0,1.2,3.2])).tolist(),strict=True))
        g = capture_wide.geometry(i)
        # Number the recurring four photos with hard gaps first for each group.
        g.update(family=FAMILIES[i%4], frequency=[carrier(rng,1,(6.85,9.4)),carrier(rng,-1,(6.9,9.5))],
                 strength=rng.uniform([.009,.0028],[.017,.0095]).tolist(),
                 gap_width=float(rng.uniform(22,33)), gap_length=float(rng.uniform(32,57)),
                 tint=rng.uniform(.04,.13,3).tolist())
        selected.append({"source":photo,"box":box,"index":i,"geometry":g,"warp":variant,
                         "id":f"envelope-{i:02d}","camera":camera,
                         "split":"calibration" if i<CAL else "confirmation"})
        if len(selected)==COUNT:
            break
    assert len(selected)==COUNT
    choices={r["source"][k] for r in selected for k in ("id","cache_sha256")}
    trace = read_json(checked(prior["parent_trace"]))
    visits=0
    for record in trace["source_traces"]:
        for rec in capture_wide.lines(record):
            for row in rec["sources"]:
                if row["kind"]=="photographic":
                    assert choices.isdisjoint((row["source_id"],row["cache_sha256"]))
                    visits+=1
    assert visits==prior["training_photo_visits_audited"]
    return {"driver":reference(__file__),"warp_source":reference(HERE/"warped_wire.py"),
            "generator_source":reference(capture_wide.wire_math.__file__),"evaluation_exclusions":blocked,
            "source_pool":prior["source_pool"],"train_trace":prior["parent_trace"],"photo_visits_checked":visits,
            "weights":{k:prior["checkpoints"][k] for k in ("local50k","v120")},"cases":selected,
            "sources":dict(Counter(row["split"] for row in selected)),"query":[128,128,256,256],
            "noise":prior["noise"],"roles":ROLES,"states":STATES,"sigma":SIGMA,"native_indices":FRAMES,
            "policy":LIMITS,"seed":SALT,"geometry":"Planar strong direction. Smooth weak phase offset inside the query; identical planar exterior.",
            "primary":"Warped exact-target weak response vs the fixed combined fit. Also compare continuing strand and false projections."}


def fixtures(fixture, state):
    photo = capture_wide.wire_math.decode(fixture["source"], fixture["box"])
    g = fixture["geometry"]
    if state=="warped":
        g = g | {"warp":fixture["warp"]}
    # Keep the earlier generator intact. Only its weak phase is extended.
    source = Path(capture_wide.wire_math.__file__).read_text()
    marker = "    p,q=phases(0)"
    assert source.count(marker)==1
    altered = source.replace(marker, marker+"\n    q=q+phase_shift(x,y,geometry)")
    scope={"phase_shift":phase_shift}
    exec(compile(altered, str(capture_wide.wire_math.__file__), "exec"),scope)
    truth, _, support, _ = scope["exact"](photo,g)
    base = scope["exact"](photo,g | {"strength":[0.,0.]})[0][2]
    flat = torch.ones_like(base)*base[...,176:336,176:336].mean((-2,-1),keepdim=True)
    recipe = replace(sample_scene_recipe(SALT),**fixture["camera"])
    return g, (truth[0],truth[2],truth[3],base,flat), support.numpy()[CLEAN], recipe


def observe(g, sources, m, recipe, identifier, draw):
    i = identifier["index"]*len(ROLES)
    seeds = [scene_seed(SALT,i+j,f"raw-{draw}") for j in range(len(ROLES))]
    # Pair states with the same random seeds for blocking. Each marginal is a
    # new physical observation; Poisson counts need not match between states.
    views = [filtered_observation(v,replace(recipe,noise_seed=seed),SIGMA)
             for v,seed in zip(sources,seeds,strict=True)]
    f = {k:getattr(views[0],k).numpy() for k in ("colors","wb","matrix")}
    f |= {k:np.stack([getattr(v,k).numpy()[cut] for v in views])
          for k,cut in (("packed",RAW),("variance",RAW),("target",CLEAN))}
    f["scene_packed"]=views[0].packed.numpy()
    f["support"]=m
    return f,seeds


@torch.inference_mode()
def capture(plan, binding):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark=False
    torch.cuda.set_per_process_memory_fraction(min(1,8*2**30/torch.cuda.get_device_properties(0).total_memory))
    models=bind_models(plan["weights"])
    store=OUT/"captures"
    store.mkdir(exist_ok=True)
    start=time.monotonic()
    rows=[]
    with ieee_fp32():
        for fixture in plan["cases"]:
            captures={}
            for state in STATES:
                g, clean, mask, recipe = fixtures(fixture,state)
                by_draw=[]
                for draw in (0,1):
                    mid=store/f'{fixture["id"]}-{state}-{draw}.npz'
                    data,seeds=observe(g,clean,mask,recipe,fixture,draw)
                    for arm, net in models.items():
                        if arm=="v120" and fixture["split"]=="calibration":
                            continue
                        parts=[run_model(net,arm,data|{k:data[k][lo:hi] for k in ("packed","variance")},plan["noise"])
                               for lo,hi in ((0,3),(3,5))]
                        data[arm]=np.concatenate(parts,axis=0)
                    with mid.open("xb") as fp:
                        np.savez(fp,**data)
                    by_draw.append({"draw":draw,"noise_seeds":seeds,"input":reference(mid)})
                captures[state]=by_draw
            rows.append({"id":fixture["id"],"observations":captures})
            if len(rows)%8==0:
                print("Captured and restored",len(rows),round(time.monotonic()-start,2),flush=True)
    write_json(OUT/"inputs.json",{"plan":binding,"rows":rows,"seconds":time.monotonic()-start,
                                  "precision":"CUDA IEEE FP32 EMA"})


if __name__=="__main__":
    torch.set_num_threads(2)
    plan=freeze()
    p=OUT/"plan.json"
    write_json(p,plan)
    capture(plan,reference(p))
