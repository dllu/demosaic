"""Apply a smooth weak-wire phase deformation inside the held-out query."""

import torch


def phase_shift(x, y, geometry):
    """Center frequency stays bounded and every donor uses the planar phase."""
    config = geometry.get("warp")
    if config is None:
        return torch.zeros_like(x)
    fx, fy = geometry["frequency"][1]
    radius = (fx*fx+fy*fy)**.5
    normal = (fx*x+fy*y)/radius
    tangent = (-fy*x+fx*y)/radius
    taper = ((125-torch.maximum(x.abs(),y.abs()))/32).clamp(0,1)
    taper = taper*taper*(3-2*taper)
    value = config["tilt_t"]*tangent/80 + config["tilt_n"]*normal/80
    value = value + config["bend"]*(tangent/80)**2
    return taper*value
