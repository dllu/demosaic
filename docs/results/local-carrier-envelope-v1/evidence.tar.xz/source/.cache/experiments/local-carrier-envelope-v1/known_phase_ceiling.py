"""Use only the known weak deformation to measure conditional phase headroom."""

import time

import numpy as np
import torch

from capture_envelope import OUT, RAW
from carrier_envelope import (CORE, EDGE, GAIN, GRID, OFFSET, OUTER, TAPER, WIDTH,
                               Split, nominal_peaks, sample, strength, unpack, variance)
from review_raw import box_wave, nuisance, planes
from warped_wire import phase_shift
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_envelope import Measure, PRIMARY, GAP, FALSE, INTACT, FLAT, ROI, arrays, source_bootstrap, interval


def proposals(tile, waves, cfa, photo, center, noise):
    # Score the same two directions, replacing only the weak waveform's
    # artificial inside-query deformation. The competitor is still planar.
    wave=waves.copy()
    y,x=np.meshgrid(np.arange(OUTER,dtype=np.float32)+center[1]-127.5,
                    np.arange(OUTER,dtype=np.float32)+center[0]-127.5,indexing="ij")
    psi=phase_shift(torch.from_numpy(x),torch.from_numpy(y),photo).numpy()
    ps, pc=np.sin(psi),np.cos(psi)
    wc,ws=waves[...,1,0],waves[...,1,1]
    wave[...,1,0]=wc*pc-ws*ps
    wave[...,1,1]=ws*pc+wc*ps
    smooth64=nuisance(OUTER,"cosine")
    smooth32=nuisance(WIDTH,"cosine")
    model64=np.concatenate((smooth64,waves[...,0,:]),axis=-1)
    model32=np.concatenate((smooth32,waves[CORE][...,0,:]),axis=-1)
    wide_score,inner_score,coefs=[],[],[]
    for a,b in (cfa,cfa[::-1]):
        broad=Split.build(model64,wave[...,1,:],a,b)
        focus=Split.build(model32,wave[CORE][...,1,:],a,b)
        ya,yb=(sample(tile,s).ravel() for s in (a,b))
        ta,tb=(sample(tile[CORE],s).ravel() for s in (a,b))
        a_residual,b_residual=broad.errors(ya,yb)
        _,b_center=focus.errors(ta,tb)
        coeff=np.linalg.lstsq(broad.train_wave,a_residual,rcond=1e-8)[0]
        coefs.append(coeff)
        power=broad.held_wave@coeff
        central=focus.held_wave@coeff
        wide_score.append((2*b_residual@power-power@power)/variance(ya,noise["shot"],noise["read"]))
        inner_score.append((2*b_center@central-central@central)/variance(ta,noise["shot"],noise["read"]))
    gain=min(strength(min(wide_score),6.),strength(min(inner_score),1.5))
    columns=np.concatenate((model64,wave[...,1,:]),axis=-1).reshape(OUTER**2,-1)
    return float(gain),np.mean(coefs,axis=0),wave[CORE][...,1,:],columns


def weak_component(parent, raw, freq, photo, noise, colors, wb, mat, correct_geometry):
    values=np.zeros((160,160))
    weight=np.zeros((160,160))
    cfa=planes(colors,(176,176,32))
    wave=box_wave((0,0,OUTER),((OUTER-1)/2,)*2,freq)
    on=0
    geometry=photo if correct_geometry else {k:v for k,v in photo.items() if k!="warp"}
    for dy,dx in GRID:
        sl=np.s_[dy:dy+WIDTH,dx:dx+WIDTH]
        ox,oy=176+dx-OFFSET,176+dy-OFFSET
        box=raw[oy:oy+64,ox:ox+64].astype(np.float64)
        g,meas,signal,cols=proposals(box,wave,cfa,geometry,(ox-128,oy-128),noise)
        weight[sl]+=TAPER
        if g<=0:
            continue
        x,y=48+dx-OFFSET,48+dy-OFFSET
        p=parent[1,y:y+64,x:x+64].ravel()
        before=np.linalg.lstsq(cols,p,rcond=1e-8)[0][-2:]
        delta=g*(meas-before)
        delta*=min(1.,np.linalg.norm(meas)/max(1e-12,np.linalg.norm(delta)))
        values[sl]+=TAPER*(signal@delta)
        on+=1
    neutral=np.linalg.solve(mat,np.ones(3))/wb
    neutral/=neutral[1]
    corrections=GAIN*values/np.maximum(.02,weight)*EDGE[:,None]*EDGE[None,:]
    return (neutral[:,None,None]*corrections).astype(parent.dtype),on


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    begin=time.monotonic()
    review_ref=reference(OUT/"review.json")
    publication=read_json(checked(review_ref))
    inputs=read_json(checked(publication["captures"]))
    plan=read_json(checked(inputs["plan"]))
    results=[]
    for x in publication["confirmation"]:
        geo=x["fixture"]["geometry"]|{"warp":x["fixture"]["warp"]}
        draws=[]
        for row in x["states"]["warped"]:
            data=arrays(row["input"])
            a=arrays(row["held_donors"])["scene_packed"]
            box=(176,176,160,160)
            nominated=nominal_peaks(a,data["colors"],box,48)
            parent=data["local50k"]
            actual,base=parent.copy(),parent.copy()
            counts=[]
            for idx in (0,1,2,3,4):
                a[RAW]=data["packed"][idx]
                if nominated is None:
                    continue
                raw=unpack(a)
                pack=[]
                for suited,target in ((False,base),(True,actual)):
                    delta,on=weak_component(parent[idx],raw,nominated,geo,plan["noise"],data["colors"],
                                             data["wb"],data["matrix"],suited)
                    target[idx,:,48:208,48:208]+=delta
                    pack.append(on)
                counts.append(pack)
            test=Measure(data,geo)
            draws.append({"input":row["input"],"draw":row["draw"],"pass_counts":counts,
                          "scores":{"constant":test(base,parent),"known_shift":test(actual,parent)}})
        results.append({"id":x["id"],"family":x["family"],"draws":draws})
        if len(results)%5==0:
            print("Oracle",len(results),flush=True)
    rng=np.random.default_rng(202611200143)
    summary={}
    for k in (PRIMARY,GAP,FALSE,INTACT,FLAT,"edge_added_RMS_DN16","uniform_added_RMS_DN16"):
        sample=[]
        for r in results:
            if k not in r["draws"][0]["scores"]["constant"]:
                continue
            diff=np.mean([d["scores"]["known_shift"][k]-d["scores"]["constant"][k] for d in r["draws"]])
            sample.append({"family":r["family"],"delta":diff})
        ix=source_bootstrap(sample,rng)
        summary[k]={"n":len(sample),"difference":interval(np.array([r["delta"] for r in sample])[ix].mean(1))}
    write_json(OUT/"oracle.json",{"driver":reference(__file__),"scope":"Known weak deformation only; only weak proposal is changed.",
                                   "review":review_ref,"summary":summary,"rows":results,"seconds":time.monotonic()-begin})
    print(summary,flush=True)


if __name__=="__main__":
    main()
