"""Bind all held-out results, original receipts and inspected native views."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from capture_envelope import HERE, OUT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REPO=HERE.parents[2]


def main():
    refs={name:reference(OUT/f"{name}.json") for name in ("review","oracle","gain-lock","inputs","plan")}
    run, oracle, lock, capture, plan=(read_json(checked(refs[k])) for k in refs)
    assert oracle["review"]==refs["review"]
    assert run["captures"]==lock["inputs"]==refs["inputs"] and capture["plan"]==refs["plan"]
    assert len(oracle["rows"])==len(run["confirmation"])==20 and len(lock["calibration"])==12
    assert len(capture["rows"])==len(plan["cases"])==32
    assert run["policy"]==plan["policy"] and run["weights"]==plan["weights"]
    assert len(run["standing"]["rows"])==8
    checks=[r for r in run["confirmation"] if r["fixture"]["geometry"]["family"] in ("strip","ellipse")]
    assert len(checks)==10
    native=[d["native"] for r in run["confirmation"] for d in r["states"]["warped"] if d["native"]]
    real=[v for r in run["standing"]["rows"] for v in r["native"]]
    assert len(native)==2 and len(real)==12
    nodes=[(m[k]["image"],n) for m in native for k,n in (("triplet",3),("board",8))]
    nodes.extend((m["image"],m["columns"]) for m in real)
    assets=REPO/"docs/assets"/HERE.name
    dest=REPO/"docs/results"/HERE.name
    assets.mkdir()
    dest.mkdir()
    images=[]
    for binding,n in nodes:
        src=checked(binding)
        with Image.open(src) as img:
            assert img.size==(8+n*168,192)
        filename=assets/src.name
        shutil.copyfile(src,filename)
        assert reference(filename)["sha256"]==binding["sha256"]
        images.append({"path":str(filename.relative_to(REPO)),"sha256":binding["sha256"]})
    archive=dest/"evidence.tar.xz"
    files=[checked(r["driver"]) for r in (run,oracle,plan)]
    files += [checked(plan[k]) for k in ("warp_source","generator_source")]
    files += [Path(__file__),HERE/"carrier_envelope.py",REPO/"src/demosaic/mesh_carrier_fit.py"]
    with tarfile.open(archive,"x:xz",preset=3) as t:
        for k,binding in refs.items():
            t.add(checked(binding),arcname=f"receipts/{k}.json",recursive=False)
        for path in files:
            t.add(path,arcname="source/"+str(path.relative_to(REPO)),recursive=False)
    write_json(dest/"publication.json",{
        "scope":"Inference-only spatially varying carrier with two held-green checks",
        "review":refs["review"],"oracle":refs["oracle"],"gain_lock":refs["gain-lock"],
        "archive":{"path":str(archive.relative_to(REPO)),"sha256":reference(archive)["sha256"]},
        "frozen_sources":plan["sources"],"photo_visits_checked":plan["photo_visits_checked"],
        "weights":run["weights"],"capture_and_parent_seconds":capture["seconds"],"review_seconds":run["seconds"],
        "policy":run["policy"],"scores":run["paired"],"activity":run["activity"],
        "oracle_detail":oracle["summary"],"image_count":len(images),"images":images,
        "standing_RMS":{r["id"]:r["rms_RGB_DN16"] for r in run["standing"]["rows"]},
        "standing_selections":{r["id"]:r["chosen"] for r in run["standing"]["rows"]},
    })


if __name__=="__main__":
    main()
