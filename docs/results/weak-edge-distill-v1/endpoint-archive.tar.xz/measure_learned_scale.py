"""Compare at matched detail strength while holding the full quiet path fixed."""
import os
import argparse
from pathlib import Path
import time

import numpy as np
from scipy.ndimage import uniform_filter
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from edge_data import ROOT,edge_distance
from edge_parents import fields
from edge_delivery import detail,quiet,paired_gates
from edge_guard import edge_weight,oracle_weight
from evaluate_repeat import as_cuda,channel_coefficients,head
from review_edge import BANDS,LUMA,measure,value,load_models
from strength_moments import triplet


def composition(teacher,learners,parent,args,cut,edge,style):
    wb,matrix=args[-2:]
    w,shared=paired_gates(*args[:3],*cut)
    base,grey=quiet(teacher,parent,args,w)
    sharp=detail(teacher,parent,args,shared)*grey[:,:,None,None]
    steered=edge_weight(teacher.scene_luma(parent,wb,matrix),args[1])
    b=parent+base
    if style=="same-edge":
        oracle=oracle_weight(edge.to(device=parent.device,dtype=parent.dtype))[None,None]
    else:
        oracle=1.
    methods={"quiet-only":b,"quiet-lift":b+sharp}
    if learners:
        methods.update({name:b+grey[:,:,None,None]*detail(net,parent,args,shared)
                        for name,net in learners.items()})
    else:
        methods|={"measured-step":b+sharp*steered,"oracle-step":b+sharp*oracle}
    return {k:arr.reshape(2,3,3,256,256).cpu().numpy() for k,arr in methods.items()},steered


def spatial(rgb):
    luminosity=np.einsum("c,trchw->trhw",LUMA,rgb)
    return luminosity-uniform_filter(luminosity,size=(1,1,5,5),mode="nearest")


def rms_spatial(orig,amount,axis):
    chosen=orig[...,axis]
    change=amount[...,axis]
    return (triplet(chosen,change,(-1,))*(96*96/int(axis.sum()))).tolist()


def ready(row,raw,parents,teacher,learners,cut,record,roi):
    args=as_cuda({k:v.reshape((-1,*v.shape[2:])) for k,v in raw.items()})
    parent=torch.from_numpy(parents.reshape(6,3,256,256)).cuda().contiguous(memory_format=torch.channels_last)
    coords=edge_distance(record["geometry"])[1]
    out,gate=composition(teacher,learners,parent,args,cut,coords,row["style"])
    frame={"100k":parents}|out
    truth_rgb,truth=channel_coefficients(raw["target"][0],{k:raw[k][0] for k in ("wb","matrix")},roi)
    x,y,w,h=roi
    area=np.zeros((256,256),bool)
    area[y:y+h,x:x+w]=True
    near=(abs(coords.numpy())<=12)&area
    far=(abs(coords.numpy())>=24)&area
    def converted(array):
        per_repeat=[channel_coefficients(array[r],{k:raw[k][r] for k in ("wb","matrix")},roi) for r in range(2)]
        return (np.stack([p[i] for p in per_repeat]) for i in (0,1))
    anchor,plain=converted(out["quiet-only"])
    initial=spatial(anchor-truth_rgb[None])
    residual=initial[:,0]-initial[:,1]
    all_measures={}
    for name,pred in frame.items():
        rgb,coef=converted(pred)
        main=measure(plain,coef-plain,truth,BANDS["fine"])
        delta=spatial(rgb-anchor)
        increment=delta[:,0]-delta[:,1]
        main["local"]={
            "near_increment_DN16":rms_spatial(residual,increment,near),
            "far_increment_DN16":rms_spatial(residual,increment,far),
            "near_absent_DN16":rms_spatial(initial[:,1],delta[:,1],near),
        }
        all_measures[name]=main
    spatial_gate=gate.flatten(-2)
    near_index=torch.as_tensor(near.ravel(),device=gate.device)
    far_index=torch.as_tensor(far.ravel(),device=gate.device)
    return all_measures,{
        "mean_gate_near":float(spatial_gate[...,near_index].mean()),
        "mean_gate_far":float(spatial_gate[...,far_index].mean()),
    }


def metric(raw,scale):
    rounded=value(raw,scale)
    powers=np.array([1,scale,scale*scale])
    for label,entry in raw["local"].items():
        rounded[label]=float(np.sqrt(np.maximum(np.asarray(entry)@powers,0)).mean())
    return rounded


def compare(rows,test,control,scales,rng):
    metrics=("increment_DN16","flat_DN16","present_DN16","near_increment_DN16","far_increment_DN16",
             "near_absent_DN16","variance_DN16_squared","shared_DN16_squared")
    computed=[[metric(r["moments"][name],scales.get(name,1.)) for name in (test,control)] for r in rows]
    matrix=np.array([[a[k]-b[k] for k in metrics] for a,b in computed])
    gains=np.array([a["aligned_dot"]-b["aligned_dot"] for a,b in computed])
    energy=np.array([b["target_power"] for _,b in computed])
    ix=rng.integers(len(rows),size=(4000,len(rows)))
    ci=np.quantile(matrix[ix].mean(axis=1),[.025,.975],axis=0).T
    out={k:[float(v),*cc.tolist()] for k,v,cc in zip(metrics,matrix.mean(axis=0),ci,strict=True)}
    return out|{"response_pp":[float(100*gains.sum()/energy.sum()),
                *np.quantile(100*gains[ix].sum(1)/energy[ix].sum(1),[.025,.975]).tolist()]}


def summarize(data,mode):
    random=np.random.default_rng(312987237569)
    scope={}
    for profile in ("iso1600","iso6400"):
        groups={}
        for style in ("natural","same-edge"):
            rows=[r for r in data if r["profile"]==profile and r["style"]==style]
            fit=[r for r in rows if r["index"]<24]
            held=[r for r in rows if r["index"]>=24]
            assert len(held)==len(fit)==24
            portable={}
            tests=(("measured-step","quiet-lift"),("oracle-step","quiet-lift")) if mode=="guard" else (
                ("cross-draw","same-draw"),("cross-draw","supervised"),("cross-draw","quiet-lift"),
                ("same-draw","supervised"),
            )
            for name,baseline in tests:
                def positive_response(arm):
                    return sum(r["moments"][arm]["aligned"][1] for r in fit)
                gains={x:positive_response(x) for x in (name,baseline)}
                wanted=min(gains.values())
                result={"all48_nominal_vs_fixed":compare(rows,name,baseline,{},random),
                        "heldout24_nominal_vs_100k":compare(held,name,"100k",{},random),
                        "mean_gate_near":float(np.mean([r["gate"]["mean_gate_near"] for r in rows])),
                        "mean_gate_far":float(np.mean([r["gate"]["mean_gate_far"] for r in rows]))}
                if wanted>0:
                    factors={x:wanted/g for x,g in gains.items()}
                    verify=compare(fit,name,baseline,factors,random)
                    assert abs(verify["response_pp"][0])<1e-11
                    result["response_match"]={"scales":factors,
                        "heldout24":compare(held,name,baseline,factors,random)}
                portable[f"{name}_vs_{baseline}"]=result
            groups[style]=portable
        scope[profile]=groups
    return scope


@torch.inference_mode()
def run(mode):
    os.sched_setaffinity(0,[16,18])
    os.nice(12)
    torch.set_num_threads(2)

    if mode=="learned":
        from follow import wait_until
        wait_until(ROOT/"training/complete.json",read_json(ROOT/"training/launch.json"))
    orig=read_json(ROOT/"fixed-review.json")
    base=read_json(checked(orig["parents"]))
    physical=read_json(checked(base["observations"]))
    plan=read_json(checked(physical["plan"]))
    config=read_json(checked(orig["recipe"]))
    teacher,learners,binding=load_models("endpoint" if mode=="learned" else "fixed",config)
    cut=(read_json(checked(config["guard"]))["threshold"],
         read_json(checked(config["guard_long"]))["threshold_0_to_1"][0])
    started=time.monotonic()
    cache={r["id"]:r["saved"] for r in base["rows"]}
    scores={r["id"]:r["metrics"] for r in orig["rows"]}
    saved=[]
    with ieee_fp32():
        for row in physical["cases"]:
            raw=fields(row)
            with np.load(checked(cache[row["id"]]),allow_pickle=False) as f:
                prior=f["100k"]
            native=plan["heldout_rows"][row["index"]]
            moments,gate=ready(row,raw,prior,teacher,learners,cut,native,plan["score_ROI_xywh"])
            transfer=metric(moments["quiet-lift"],1)
            for element in ("increment_DN16","near_increment_DN16","near_absent_DN16"):
                np.testing.assert_allclose(transfer[element],scores[row["id"]]["quiet-lift"][element],atol=4e-8,rtol=0)
            saved.append({"id":row["id"],"index":row["index"],"profile":row["profile"]["name"],"style":row["style"],
                          "moments":moments,"gate":gate})
            if len(saved)%24==0:
                print(len(saved),round(time.monotonic()-started,2),flush=True)
    assert len(saved)==192
    write_json(ROOT/f"{mode}-detail-strength.json",{
       "driver":reference(__file__),"input":reference(ROOT/"fixed-review.json"),"gate_module":reference(ROOT/"edge_guard.py"),
       "rows":saved,"metrics":summarize(saved,mode),"seconds":time.monotonic()-started,"checkpoint":binding,
       "scope":"Keep the full common 0.15 quiet path fixed. Scale only the corresponding detail lifts. Response matched on 24 photos and scored on the other 24.",
    })


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("mode",choices=("guard","learned"))
    run(p.parse_args().mode)
