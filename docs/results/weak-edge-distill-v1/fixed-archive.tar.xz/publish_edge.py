"""Publish reviewed comparison pixels, frozen evidence and trained endpoint bindings."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import shutil
import tarfile

from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from edge_data import ROOT

DEST=Path("docs/results/weak-edge-distill-v1")
IMAGES=Path("docs/images/weak-edge-distill-v1")
COMMON=("evaluation.json","observations.json","physical-audit.json","parent-complete.json",
        "training-plan.json","edge_data.py","edge_delivery.py","edge_parents.py","review_edge.py",
        "render_edge.py","parents.log","publish_edge.py")


def training_details():
    receipt=reference(ROOT/"training/complete.json")
    all=read_json(checked(receipt))
    assert (all["updates"],all["photos"],all["examples_per_head"])==(384,768,4608)
    plan=read_json(checked(all["plan"]))
    rows=read_json(checked(plan["source_schedule"]))["rows"]
    trace=[json.loads(s) for s in checked(all["observations"]).read_text().splitlines()]
    source=[r for record in trace for r in record["samples"]]
    assert [r["step"] for r in trace]==list(range(1,385))
    assert [r["source"] for r in source]==[r["source"]["id"] for r in rows]
    assert len({item["source"] for item in source})==768
    counts=Counter("/".join((r["profile"]["name"],r["style"],r["CFA"])) for r in source)
    assert all["cells"]==dict(counts) and set(counts.values())=={48} and len(counts)==16
    seeds=[i for r in source for i in r["seeds"]]
    assert len(seeds)==len(set(seeds))==6144
    assert all_values_finite(trace)
    final=checked(all["head_checkpoint"])
    state=torch.load(final,map_location="cpu",weights_only=True)
    assert state["step"]==384 and state["plan"]==all["plan"] and state["parent_frozen"]
    for branch in state["weights"].values():
        assert set(branch)=={"raw","ema","optimizer"} and branch["optimizer"]["state"]
        assert all_finite_parameters(branch)
    mirror=Path("/mnt/external/demosaic/models/weak-edge-distill-v1-step000384.pt")
    if not mirror.exists():
        shutil.copyfile(final,mirror)
    assert reference(mirror)["sha256"]==all["head_checkpoint"]["sha256"]
    return {"report":all,"receipt":receipt,"exported":reference(mirror),
            "audited_distinct_seeds":len(seeds),"finite_raw_EMA_and_optimizer_structure":True}


def all_finite_parameters(branch):
    return all(v.isfinite().all() for key in ("raw","ema") for v in branch[key].values())


def all_values_finite(rows):
    return all(value is None or math.isfinite(value)
               for row in rows for scores in row["scores"].values() for value in scores.values())


def publish(stage):
    bound=reference(ROOT/f"{stage}-review.json")
    review=read_json(checked(bound))
    assert len(review["rows"])==192
    native=read_json(ROOT/f"{stage}-native/render.json")
    assert native["review"]==bound
    proof=ROOT/f"{stage}-viewing.json"
    observations=read_json(proof)
    assert set(observations)=={row["id"] for row in native["photo"]+native["camera"]}
    assert len(native["photo"])==3 and len(native["camera"])==(0 if stage=="fixed" else 8)
    details=training_details() if stage=="endpoint" else None
    if details:
        assert review["endpoint"]==details["report"]["head_checkpoint"]
    destination=IMAGES/stage
    destination.mkdir(parents=True,exist_ok=True)
    def copy_board(row):
        path=checked(row["image"])
        target=destination/path.name
        shutil.copyfile(path,target)
        assert reference(target)["sha256"]==row["image"]["sha256"]
        with Image.open(target) as pic:
            for pane in row["panels"]:
                x,y,w,h=pane["png_xywh"]
                assert (w,h)==(160,160) and x+w<=pic.width and y+h<=pic.height
            pic.verify()
        row["image"]["path"]=str(target)
    for r in native["photo"]:
        copy_board(r["board"])
        copy_board(r["triplet"])
        r["native_observation"]=observations[r["id"]]
    for r in native["camera"]:
        copy_board(r)
        r["native_observation"]=observations[r["id"]]
    native["actual_native_viewing_complete"]=True
    artifact=DEST/f"{stage}-archive.tar.xz"
    items=(*COMMON,f"{stage}-review.log",f"{stage}-render.log",f"{stage}-review.json",
           f"{stage}-native/render.json",proof.name)
    if details:
        items+=("schedule.json","training/complete.json","training/observations.jsonl",
                "train_distill.py","train.log","follow-complete.json")
    with tarfile.open(artifact,"x:xz") as f:
        for item in items:
            f.add(ROOT/item,arcname=item)
    write_json(DEST/f"{stage}-publication.json",{
        "study":"Independent-exposure teacher with matched weak edges",
        "checkpoint":review["endpoint"],"parent_models":read_json(checked(review["parents"]))["models"],
        "training_execution":details,"evaluation_seconds_with_saved_parents":review["seconds"],
        "numeric":review["metrics"],"native":native,"frozen_archive":reference(artifact),
        "scope":"48 source photos with matched edge conditions at ISO1600 and ISO6400, two independent repeats. Component-scale panel. Full427 and measured-camera history refer to separately evaluated full models.",
    })


if __name__=="__main__":
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument("stage",choices=("fixed","endpoint"))
    publish(args.parse_args().stage)
