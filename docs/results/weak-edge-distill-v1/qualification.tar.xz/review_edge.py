"""Measure exact weak detail, false edge increments and flats on an unused photo panel."""
import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
from scipy.ndimage import uniform_filter
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from edge_data import ROOT,ARGS,edge_distance
from edge_parents import fields
from edge_delivery import compose,quiet,paired_gates
from evaluate_repeat import as_cuda,channel_coefficients,head
from measure import BANDS,LUMA
from train_distill import ARMS

SHAPE=ROOT.parent/"paired-shape-stability-v1"
sys.path.insert(0,str(SHAPE))
from strength_moments import measure,value

FIXED=("V120","100k","original-paired","quiet-only","quiet-lift")
RMS=("increment_DN16","flat_DN16","present_DN16","near_increment_DN16","far_increment_DN16",
     "near_absent_DN16","far_absent_DN16","near_absent_chroma_DN16","orthogonal_increment_DN16",
     "variance_DN16_squared","shared_DN16_squared","flat_worst_bias_DN16")


def load_models(stage,training):
    original=torch.load(checked(training["initial_head"]),map_location="cpu",weights_only=True)
    teacher=head(original,"paired")
    binding=None
    learners={}
    if stage=="first":
        binding=reference(ROOT/"training/step000096.pt")
    elif stage=="endpoint":
        final=read_json(ROOT/"training/complete.json")
        assert final["updates"]==training["steps"]
        binding=final["head_checkpoint"]
    if binding:
        proof=torch.load(checked(binding),map_location="cpu",weights_only=True)
        assert proof["plan"]==reference(ROOT/"training-plan.json") and proof["parent_frozen"]
        learners={arm:head(proof,arm) for arm in ARMS}
    return teacher,learners,binding


def restore(teacher,learners,parent,args,cut):
    g0,g1=paired_gates(*args[:3],*cut)
    calm,gray=quiet(teacher,parent,args,g0)
    fixed=teacher.luminance_delta(parent,*args)*g1
    outcomes={
        "quiet-only":parent+calm,
        "original-paired":parent+gray[:,:,None,None]*fixed,
        "quiet-lift":compose(teacher,parent,args,cut),
    }
    outcomes.update({key:compose(net,parent,args,cut) for key,net in learners.items()})
    return {k:field.reshape(2,3,*field.shape[1:]).cpu().numpy() for k,field in outcomes.items()}


def rms(array,selected):
    return float(np.mean(np.sqrt((array[...,selected]**2).mean(axis=-1)))*65535)


def scores(variants,data,roi,geometry):
    true_quad=[channel_coefficients(data["target"][r],{k:data[k][r] for k in ("wb","matrix")},roi)
               for r in range(2)]
    truth_rgb,truth_coeff=true_quad[0]
    np.testing.assert_array_equal(truth_rgb,true_quad[1][0])
    _,distance=edge_distance(geometry,dtype=torch.float64)
    core=np.zeros((256,256),bool)
    x,y,w,h=roi
    core[y:y+h,x:x+w]=True
    near,far=(abs(distance.numpy())<=12)&core,(abs(distance.numpy())>=24)&core
    truth_band=truth_coeff[...,BANDS["fine"]]
    true_weak=truth_band[0]-truth_band[1]
    target_energy=np.sum(true_weak**2)
    output={}
    for label,array in variants.items():
        converted=[channel_coefficients(array[r],{k:data[k][r] for k in ("wb","matrix")},roi) for r in range(2)]
        rgb,coef=(np.stack([r[i] for r in converted]) for i in (0,1))
        observed=value(measure(coef,np.zeros_like(coef),truth_coeff,BANDS["fine"]),0)
        err=rgb-truth_rgb[None]
        yerr=np.einsum("c,drchw->drhw",LUMA,err)
        high=yerr-uniform_filter(yerr,size=(1,1,5,5),mode="nearest")
        increment=high[:,0]-high[:,1]
        chroma=err[:,1]-yerr[:,1,None]
        observed.update({
            "near_increment_DN16":rms(increment,near),
            "far_increment_DN16":rms(increment,far),
            "near_absent_DN16":rms(high[:,1],near),
            "far_absent_DN16":rms(high[:,1],far),
            "near_absent_chroma_DN16":rms(chroma,near),
            "flat_worst_bias_DN16":float(np.mean(np.max(abs(err[:,2][...,core].mean(axis=-1)),axis=-1))*65535),
        })
        derived=coef[...,BANDS["fine"]]
        signal=derived[:,0]-derived[:,1]
        proj=(signal*true_weak).sum(axis=(-2,-1))/max(target_energy,1e-24)
        uncompensated=signal-proj[:,None,None]*true_weak
        observed["orthogonal_increment_DN16"]=float(np.mean(np.sqrt(np.sum(uncompensated**2,axis=(-2,-1))/(w*h)))*65535)
        output[label]=observed
    return output


def reduce(rows, compared, control, rng):
    n=len(rows)
    assert n>0
    indices=rng.integers(n,size=(4000,n))
    rel=np.array([[r["metrics"][compared][m]-r["metrics"][control][m] for m in RMS] for r in rows])
    avg=rel.mean(axis=0)
    bands=np.quantile(rel[indices].mean(axis=1),[.025,.975],axis=0).T
    dot=np.array([r["metrics"][compared]["aligned_dot"]-r["metrics"][control]["aligned_dot"] for r in rows])
    truth=np.array([r["metrics"][control]["target_power"] for r in rows])
    diff=100*(dot[indices].sum(axis=1)/truth[indices].sum(axis=1))
    return {"differences":{k:[float(m),*c.tolist()] for k,m,c in zip(RMS,avg,bands,strict=True)}|{
        "response_pp":[float(100*dot.sum()/truth.sum()),*np.quantile(diff,[.025,.975]).tolist()]},
        "sources":n}


def edge_interaction(rows, compared, control, rng):
    by_type={form:{r["index"]:r["metrics"] for r in rows if r["style"]==form}
             for form in ("natural","same-edge")}
    assert by_type["natural"].keys()==by_type["same-edge"].keys()
    ids=sorted(by_type["natural"])
    n=len(ids)
    ix=rng.integers(n,size=(4000,n))
    terms=[]
    align=[]
    for k in ("natural","same-edge"):
        obs=[by_type[k][number] for number in ids]
        terms.append(np.array([[r[compared][m]-r[control][m] for m in RMS] for r in obs]))
        align.append((np.array([r[compared]["aligned_dot"]-r[control]["aligned_dot"] for r in obs]),
                      np.array([r[control]["target_power"] for r in obs])))
    paired=terms[1]-terms[0]
    means=np.quantile(paired[ix].mean(axis=1),[.025,.975],axis=0).T
    out={k:[float(v),*span.tolist()] for k,v,span in zip(RMS,paired.mean(0),means,strict=True)}
    ratios=[100*dot[ix].sum(axis=1)/power[ix].sum(axis=1) for dot,power in align]
    point=[100*dot.sum()/power.sum() for dot,power in align]
    out["response_pp"]=[float(point[1]-point[0]),*np.quantile(ratios[1]-ratios[0],[.025,.975]).tolist()]
    return out


def summarize(rows,learners):
    rng=np.random.default_rng(74054137)
    comparisons=[(key,"100k") for key in (*FIXED,*learners) if key!="100k"]
    comparisons.extend((arm,"quiet-lift") for arm in learners)
    if learners:
        comparisons.extend([("cross-draw","supervised"),("cross-draw","same-draw"),("same-draw","supervised")])
    panels={}
    for name in sorted({r["profile"] for r in rows}):
        panel={}
        for style in ("natural","same-edge"):
            allowed=[r for r in rows if (r["profile"],r["style"])==(name,style)]
            panel[style]={f"{a}_vs_{b}":reduce(allowed,a,b,rng) for a,b in comparisons}
            faint=[r for r in allowed if r["weak_scale"]==.065]
            if faint:
                panel[style+"-fainter"]={f"{a}_vs_{b}":reduce(faint,a,b,rng) for a,b in comparisons}
        panel["edge_interaction"]={f"{a}_vs_{b}":edge_interaction([r for r in rows if r["profile"]==name],a,b,rng)
                                   for a,b in comparisons}
        panels[name]=panel
    return panels


@torch.inference_mode()
def run(stage):
    os.sched_setaffinity(0,[16,18])
    os.nice(10)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    record=reference(ROOT/"parent-complete.json")
    parents=read_json(checked(record))
    physical=read_json(checked(parents["observations"]))
    evaluation=read_json(checked(physical["plan"]))
    recipe=read_json(ROOT/"training-plan.json")
    teacher,learners,binding=load_models(stage,recipe)
    cut=(read_json(checked(recipe["guard"]))["threshold"],
         read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0])
    saved={r["id"]:r for r in parents["rows"]}
    out=[]
    begun=time.monotonic()
    with ieee_fp32():
        for case in physical["cases"]:
            idx=case["index"]
            if stage=="first" and idx>=16:
                continue
            source=evaluation["heldout_rows"][idx]
            data=fields(case)
            assert case["input"]==saved[case["id"]]["physical"]
            with np.load(checked(saved[case["id"]]["saved"]),allow_pickle=False) as old:
                baselines={key:old[key] for key in ("100k","V120")}
            parent=torch.from_numpy(baselines["100k"].reshape(6,3,256,256)).cuda().contiguous(memory_format=torch.channels_last)
            arrays={k:a.reshape((-1,*a.shape[2:])) for k,a in data.items()}
            altered=restore(teacher,learners,parent,as_cuda(arrays),cut)
            metrics=scores(baselines|altered,data,evaluation["score_ROI_xywh"],source["geometry"])
            out.append({"id":case["id"],"source":case["source"],"index":idx,
                        "style":case["style"],"profile":case["profile"]["name"],
                        "weak_scale":source["geometry"]["weak_scale"],"metrics":metrics})
            if len(out)%24==0:
                print(stage,len(out),round(time.monotonic()-begun,2),flush=True)
    assert len(out)==(64 if stage=="first" else 192)
    write_json(ROOT/f"{stage}-review.json",{
        "driver":reference(__file__),"parents":record,"endpoint":binding,"recipe":reference(ROOT/"training-plan.json"),
        "rows":out,"metrics":summarize(out,learners),"seconds":time.monotonic()-begun,
        "scope":"Two independent repeats. Native 96-pixel DCT band, exact flat, near/far edge residuals, off-target and color terms. Whole-source paired bootstrap.",
    })


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage",choices=("fixed","first","endpoint"))
    run(p.parse_args().stage)
