"""Build exact weak increments with and without the same high-contrast edge."""
import argparse
from collections import Counter
from dataclasses import asdict, replace
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
STABILITY = ROOT.parent / "paired-repeat-stability-v2"
SCENE = ROOT.parent / "scene-local-contrast-2400-v1"
sys.path.insert(0, str(STABILITY))
from train_repeat import ARGS, observe
from prepare_eval import flat_patch

TEST_SEED = 43004748811
EDGE_SCOPES = ("natural", "same-edge")
PROFILES = (
    {"name":"iso1600","shot":.00032,"read":4.096e-7,"exposure":.33},
    {"name":"iso6400","shot":.00128,"read":6.5536e-6,"exposure":.33},
)


def decode(record, box):
    path = Path(record["cache"])
    assert path.is_relative_to("/mnt/external") and reference(path)["sha256"] == record["cache_sha256"]
    x,y,w,h = box
    source = np.load(path, mmap_mode="r", allow_pickle=False)
    assert list(source.shape) == record["shape"] and source.dtype == np.uint16
    crop = source[y:y+h,x:x+w].astype(np.float32)
    return torch.from_numpy(crop).permute(2,0,1).contiguous()/65535.


def geometry(seed, index):
    rng = random.Random(scene_seed(seed,index,"sample-geometry"))
    return {
        "angle": rng.uniform(0,math.pi),
        "shift": rng.uniform(-13,13),
        "height_rgb": [rng.uniform(.14,.235) for _ in range(3)],
        "weak_scale": (.065,.115)[(index//4)%2],
    }


def edge_distance(config, dtype=torch.float32):
    grid = torch.arange(256,dtype=dtype)-127.5
    yy,xx = torch.meshgrid(grid,grid,indexing="ij")
    return config["angle"],xx*math.cos(config["angle"])+yy*math.sin(config["angle"])-config["shift"]


def pair_targets(image, config, style):
    """Keep one identical true photographic increment in the two edge conditions."""
    coarse = F.avg_pool2d(image[None],5,stride=1,padding=2,count_include_pad=False)[0]
    coord = torch.arange(256,dtype=image.dtype)
    taper = ((111-(coord-127.5).abs())/20).clamp(0,1)
    center = taper[:,None]*taper[None,:]
    base = .04+.66*coarse
    delta = .66*config["weak_scale"]*(image-coarse)*center
    if style == "same-edge":
        _,distance = edge_distance(config)
        step = torch.sigmoid(distance/.65)
        amplitude=torch.tensor(config["height_rgb"],dtype=image.dtype)[:,None,None]
        base=base+step*amplitude
    detail = base+delta
    assert 0 <= float(detail.min()) and float(detail.max()) <= 1
    return detail,base,flat_patch(base)


def sensor_triplets(row, style, profile, seed):
    crop=decode(row["source"],row["box"])
    targets=pair_targets(crop,row["geometry"],style)
    fields={k:profile[k] for k in ("shot","read","exposure")}
    camera=replace(sample_scene_recipe(seed),**(row["camera"]|fields))
    ids=[scene_seed(seed,row["index"],f"{profile['name']}/{style}/repeat{r}/{role}")
         for r in range(2) for role in ("reserved","present","absent","flat")]
    assert len(ids)==len(set(ids))
    measured=[observe(targets,camera,fields,"independent",ids[k:k+4]) for k in (0,4)]
    assert torch.equal(measured[0]["target"],measured[1]["target"])
    assert not torch.equal(measured[0]["packed"],measured[1]["packed"])
    prepared={key:torch.stack([x[key] for x in measured]) for key in (*ARGS,"target")}
    return prepared,ids


def row_for(source, index, seed):
    shape=[int(x)//2*2 for x in source["shape"][:2]]
    (box,)=scene_crop_boxes(shape,patch_size=256,count=1,seed=scene_seed(seed,index,"box"))
    camera=asdict(sample_scene_recipe(scene_seed(seed,index,"camera")))|{
        "pattern":tuple(PATTERNS)[index%4],"black":.03,
    }
    return {"source":source,"index":index,"box":box,"camera":camera,"geometry":geometry(seed,index)}


def freeze():
    prior=read_json(STABILITY/"evaluation-plan.json")
    original=read_json(checked(prior["original_panel"]))
    cohort=read_json(checked(original["cohort"]))
    assert cohort["training_overlap"]==[]
    used={row["source"]["id"] for row in prior["rows"]}
    candidate=[s for s in cohort["source_metadata"] if s["split"]=="val" and s["bin_factor"]==4
               and min(s["shape"][:2])>=512 and np.prod(s["shape"][:2])<=4_000_000 and s["id"] not in used]
    ranked=sorted(candidate,key=lambda r:hashlib.sha256(f"weak-edge-distill-v1/{r['id']}".encode()).hexdigest())
    assert len(ranked)>=48
    samples=[row_for(s,i,TEST_SEED) for i,s in enumerate(ranked[:48])]
    assert len({x["source"]["id"] for x in samples})==48
    assert set(Counter(x["camera"]["pattern"] for x in samples).values())=={12}
    write_json(ROOT/"evaluation.json",{
        "driver":reference(__file__),"parents_from":reference(STABILITY/"parent-predictions/plan.json"),
        "cohort":original["cohort"],"heldout_rows":samples,"profiles":PROFILES,"edge_conditions":EDGE_SCOPES,
        "repeats":2,"score_ROI_xywh":[80,80,96,96],"display_ROI_xywh":[48,48,160,160],
        "contrasts":(.065,.115),"seed":TEST_SEED,
        "scope":"48 unused validation photos. Each has a natural low-pass photographic base and the same base with a subpixel step. Both share the same pre-camera weak native photographic increment. Two fully independent repeats of present, absent and exact-flat roles.",
    })


def make():
    os.sched_setaffinity(0,[16,18])
    os.nice(10)
    torch.set_num_threads(1)
    field=reference(ROOT/"evaluation.json")
    plan=read_json(checked(field))
    assert plan["driver"]==reference(__file__)
    prepared=ROOT/"physical"
    prepared.mkdir()
    records=[]
    began=time.monotonic()
    for row in plan["heldout_rows"]:
        img=decode(row["source"],row["box"])
        plain=pair_targets(img,row["geometry"],"natural")
        step=pair_targets(img,row["geometry"],"same-edge")
        torch.testing.assert_close(plain[0]-plain[1],step[0]-step[1],rtol=0,atol=9e-8)
        edge_step=step[1]-plain[1]
        assert float(edge_step.max())>.13
        for condition in plan["profiles"]:
            for style in plan["edge_conditions"]:
                tensors,seeds=sensor_triplets(row,style,condition,TEST_SEED)
                arrays={k:t.numpy() for k,t in tensors.items()}
                tag=f"{row['index']:03d}-{style}-{condition['name']}"
                out=prepared/(tag+".npz")
                with out.open("xb") as into:
                    np.savez(into,**arrays)
                records.append({
                    "id":tag,"index":row["index"],"source":row["source"]["id"],"style":style,
                    "profile":condition,"input":reference(out),"seeds":seeds,
                    "array_fingerprints":{k:fingerprint(v) for k,v in arrays.items()},
                })
        if (row["index"]+1)%8==0:
            print(row["index"]+1,round(time.monotonic()-began,1),flush=True)
    assert len(records)==192
    assert len(set(z for row in records for z in row["seeds"]))==8*len(records)
    write_json(ROOT/"observations.json",{
        "plan":field,"cases":records,"duration_seconds":time.monotonic()-began,
    })


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("action",choices=("plan","physical"))
    freeze() if cli.parse_args().action=="plan" else make()
