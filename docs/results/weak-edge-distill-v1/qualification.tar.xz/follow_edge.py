"""Follow the verified parent and training workers through exact and native review."""
import argparse
import os
import subprocess
import sys
import time

import psutil

from demosaic.experiments.artifacts import read_json,reference,write_json
from edge_data import ROOT
from follow import wait_until


def run(script,stage,log):
    with (ROOT/log).open("x") as output:
        subprocess.run([sys.executable,str(ROOT/script),stage],stdout=output,stderr=subprocess.STDOUT,check=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("parent_pid",type=int)
    key=parser.parse_args().parent_pid
    parent=ROOT/"parent-complete.json"
    worker=None if parent.is_file() else {"pid":key,"created":psutil.Process(key).create_time()}
    train=read_json(ROOT/"training/launch.json")
    write_json(ROOT/"follow-launch.json",{
        "pid":os.getpid(),"created":psutil.Process().create_time(),"driver":reference(__file__),
        "training":train,"parent_worker":worker,
    })
    if not parent.is_file():
        wait_until(parent,worker)
    run("review_edge.py","fixed","fixed-review.log")
    run("render_edge.py","fixed","fixed-render.log")
    first=wait_until(ROOT/"training/step000096.pt",train)
    run("review_edge.py","first","first-review.log")
    trained=wait_until(ROOT/"training/complete.json",train)
    run("review_edge.py","endpoint","endpoint-review.log")
    run("render_edge.py","endpoint","endpoint-render.log")
    write_json(ROOT/"follow-complete.json",{
        "training":trained,"endpoint":reference(ROOT/"endpoint-review.json"),
        "native":reference(ROOT/"endpoint-native/render.json"),"actual_native_viewing_complete":False,
    })
