"""Render the favorable and adverse weak-edge cases at native scale."""
import argparse
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board
from edge_data import ROOT,ARGS
from edge_parents import fields
from edge_delivery import compose,quiet,paired_gates
from evaluate_repeat import as_cuda
from review_edge import load_models
from train_distill import ARMS
import render_repeat

LABELS={
    "100k":"Corpus 100k EMA","V120":"V120 EMA",
    "original-paired":"Prior paired head","quiet-only":"Quiet only","quiet-lift":"Fixed two routes",
    "supervised":"Supervised","same-draw":"Same-draw teacher","cross-draw":"Independent teacher",
}


def restore_single(state,args,parents,limits):
    teacher,branches=state
    parent=torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    wide,shared=paired_gates(*args[:3],*limits)
    calm,gray=quiet(teacher,parent,args,wide)
    learned=teacher.luminance_delta(parent,*args)*shared
    lookup={"quiet-only":(parent+calm).cpu().numpy(),
        "original-paired":(parent+gray[:,:,None,None]*learned).cpu().numpy(),
        "quiet-lift":compose(teacher,parent,args,limits).cpu().numpy(),
    }
    return parents|lookup|{tag:compose(model,parent,args,limits).cpu().numpy() for tag,model in branches.items()}


def synthetic(out,state,plan,stage,locations,stored,analysis,settings):
    wanted="quiet-lift" if stage=="fixed" else "cross-draw"
    comparison="100k" if stage=="fixed" else "same-draw"
    table=[r for r in analysis["rows"] if r["profile"]=="iso6400" and r["style"]=="same-edge"]
    assert len(table)==48
    def shift(row,key):
        return row["metrics"][wanted][key]-row["metrics"][comparison][key]
    ordered=sorted(table,key=lambda r:shift(r,"near_increment_DN16"))
    selected=(
        (ordered[0],0,"Largest reduction in weak-increment error within 12 pixels of the added edge."),
        (ordered[-1],0,"Largest increase in weak-increment error within 12 pixels of the added edge."),
        (max(table,key=lambda r:shift(r,"near_absent_DN16")),1,"Largest edge-only error increase near the added edge."),
    )
    views=[]
    group=("V120","100k","quiet-only","quiet-lift",*(ARMS if stage=="endpoint" else ()))
    for case,role,why in selected:
        tag=case["id"]
        bound=locations[tag]
        source=plan["heldout_rows"][case["index"]]
        inputs=fields(bound)
        with np.load(checked(stored[tag]["saved"]),allow_pickle=False) as arrays:
            base={k:arrays[k][0] for k in ("100k","V120")}
        view=restore_single(state,as_cuda({k:v[0] for k,v in inputs.items()}),base,settings)
        sampled={k:inputs[k][0][role:role+1] for k in ARGS}
        displays=[noisy_malvar(sampled)[0],*[view[k][role] for k in group],inputs["target"][0,role]]
        views.append(native_board(
            out,f"{tag}-r0-role{role}",displays,sampled,{
                "source_photo":source["source"],"bbox_native":source["box"],"CFA":source["camera"]["pattern"],
                "profile":bound["profile"],"selection":why,"condition":bound["style"],"edge":source["geometry"],
                "physical":bound["input"],"candidate":wanted,"comparator":comparison,"evaluated_checkpoint":analysis["endpoint"],
            }, labels=("Noisy Malvar",*[LABELS[k] for k in group],"Exact GT"),
            triplet_indices=(0,group.index(wanted)+1,len(displays)-1),
            exposure=1/bound["profile"]["exposure"],contrast=2,roi=tuple(plan["display_ROI_xywh"]),
        ))
    return views


@torch.inference_mode()
def run(stage):
    os.sched_setaffinity(0,[16,18])
    os.nice(11)
    torch.set_num_threads(2)
    analytic=reference(ROOT/f"{stage}-review.json")
    data=read_json(checked(analytic))
    parents=read_json(checked(data["parents"]))
    observations=read_json(checked(parents["observations"]))
    plan=read_json(checked(observations["plan"]))
    recipe=read_json(checked(data["recipe"]))
    teacher,learners,checkpoint=load_models(stage,recipe)
    assert checkpoint==data["endpoint"]
    cut=(read_json(checked(recipe["guard"]))["threshold"],
         read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0])
    location={r["id"]:r for r in observations["cases"]}
    saved={r["id"]:r for r in parents["rows"]}
    directory=ROOT/(stage+"-native")
    directory.mkdir()
    render_repeat.SHOW=("original-paired","quiet-lift",*learners)
    render_repeat.DISPLAY=LABELS
    render_repeat.predictions=restore_single
    with ieee_fp32():
        fresh=synthetic(directory,(teacher,learners),plan,stage,location,saved,data,cut)
        camera=render_repeat.show_camera((teacher,learners),cut,directory) if learners else []
    write_json(directory/"render.json",{
        "review":analytic,"driver":reference(__file__),"standing_driver":reference(render_repeat.__file__),
        "photo":fresh,"camera":camera,"actual_native_viewing_complete":False,
    })


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage",choices=("fixed","endpoint"))
    run(p.parse_args().stage)
