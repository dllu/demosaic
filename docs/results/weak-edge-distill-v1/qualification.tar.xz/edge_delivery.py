"""Compose the smoothed-innovation detail head with its fixed quiet-region path."""
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FEEDBACK=ROOT.parent/"paired-feedback-paths-v1"
sys.path.insert(0,str(FEEDBACK))

from feedback_heads import counterfactual
from flat_companion import quiet_direction
from directional_feedback import native as directional
from local_guard import paired_gates

QUIET=.15


def quiet(head,parent,args,wide):
    correction,grey=quiet_direction(head,parent,args,wide)
    return QUIET*correction,grey


def detail(head,parent,args,shared):
    return counterfactual(head,parent,parent,*args,smooth_innovation=True)*shared


def compose(head,parent,args,thresholds):
    wide,shared=paired_gates(*args[:3],*thresholds)
    smooth,grey=quiet(head,parent,args,wide)
    lift=detail(head,parent,args,shared)
    return parent+smooth+grey[:,:,None,None]*lift
