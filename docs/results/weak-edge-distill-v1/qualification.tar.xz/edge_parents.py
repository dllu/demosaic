"""Restore every frozen photo query with its two bound full-model baselines."""
import os
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from edge_data import ROOT,STABILITY,ARGS
from evaluate import setup_models
from evaluate_repeat import as_cuda,base_forward


def fields(row):
    with np.load(checked(row["input"]),allow_pickle=False) as data:
        out={key:data[key] for key in (*ARGS,"target")}
    assert {key:fingerprint(arr) for key,arr in out.items()}==row["array_fingerprints"]
    return out


@torch.inference_mode()
def collect():
    os.sched_setaffinity(0,[16,18])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,14*2**30/torch.cuda.get_device_properties(0).total_memory))
    observed=reference(ROOT/"observations.json")
    data=read_json(checked(observed))
    plan=read_json(checked(data["plan"]))
    bindings=read_json(checked(plan["parents_from"]))["models"]
    models=setup_models({"models":bindings})
    folder=ROOT/"parents"
    folder.mkdir()
    rows=[]
    started=time.monotonic()
    with ieee_fp32():
        for row in data["cases"]:
            case=fields(row)
            combined={k:v.reshape((-1,*v.shape[2:])) for k,v in case.items()}
            args=as_cuda(combined)
            completed={}
            for name,model in models.items():
                restoration=base_forward(model,args,row["profile"])
                result=restoration.reshape(2,3,*restoration.shape[1:]).cpu().numpy()
                assert np.isfinite(result).all()
                completed[name]=result
            state=folder/(row["id"]+".npz")
            with state.open("xb") as stream:
                np.savez(stream,**completed)
            rows.append({"id":row["id"],"physical":row["input"],"saved":reference(state)})
            if len(rows)%16==0:
                print(len(rows),round(time.monotonic()-started,1),flush=True)
    assert len(rows)==192
    write_json(ROOT/"parent-complete.json",{
        "driver":reference(__file__),"observations":observed,"models":bindings,"rows":rows,
        "precision":"CUDA IEEE FP32","seconds":time.monotonic()-started,
    })


if __name__=="__main__":
    collect()
