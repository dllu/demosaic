"""Train matched single-frame heads from supervised and independent-exposure targets."""
import argparse
from collections import Counter
import json
import math
import os
from pathlib import Path
import random
import time

import psutil
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.paired_detail import PairedLuminanceDetail, fine_band
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_training_data import scene_seed
from edge_data import ROOT,STABILITY,ARGS,row_for,sensor_triplets
from train_repeat import CORE,ema_update,robust,save_checkpoint,setup_models,shaped
from edge_delivery import FEEDBACK,detail,quiet,paired_gates
from profile_raw_kernel_inference import model_hash

TRAIN_SEED=629114875926
STEPS=384
ARMS=("supervised","same-draw","cross-draw")
DISTILL=.35
RUN_OFFSET=20000


def freeze():
    prior=read_json(STABILITY/"plan.json")
    schedule=read_json(checked(prior["schedule"]))
    shape=read_json(ROOT.parent/"paired-shape-stability-v1"/"plan.json")
    earlier=read_json(checked(shape["schedule"]))
    first=read_json(checked(schedule["prior_training_sources"]))
    source=checked(schedule["manifest"])
    records=[json.loads(line) for line in source.read_text().splitlines() if line.strip()]
    photos={r["id"] for x in (schedule,earlier,first) for r in x["rows"]+x.get("qualification",[])}
    evaluation=read_json(ROOT/"evaluation.json")
    testing={x["source"]["id"] for x in evaluation["heldout_rows"]}
    assert len(records)==90692 and all(r["split"]=="train" for r in records)
    assert {r["id"] for r in records}.isdisjoint(testing)
    eligible=[r for r in records if r["id"] not in photos | testing]
    picked=random.Random(TRAIN_SEED).sample(eligible,2*STEPS+8)
    allocation=[row_for(r,index+RUN_OFFSET,TRAIN_SEED) for index,r in enumerate(picked)]
    manifest=ROOT/"schedule.json"
    write_json(manifest,{
        "manifest_source":reference(source),"evaluation":reference(ROOT/"evaluation.json"),
        "excluded_prior_schedules":[prior["schedule"],shape["schedule"],schedule["prior_training_sources"]],
        "rows":allocation[:2*STEPS],"qualification":allocation[2*STEPS:],
    })
    sources=[Path(__file__),ROOT/"edge_data.py",ROOT/"edge_delivery.py",FEEDBACK/"feedback_heads.py",
             FEEDBACK/"flat_companion.py", STABILITY/"train_repeat.py",
             *[checked(f) for f in prior["sources"]]]
    write_json(ROOT/"training-plan.json",{
        "driver":reference(__file__),"dependency_sources":[reference(path) for path in dict.fromkeys(sources)],
        "models":prior["models"],"initial_head":prior["initial_head"],
        "guard":prior["guard"],"guard_long":prior["guard_long"],"steps":STEPS,"photos":2*STEPS,
        "arms":ARMS,"distill_weight":DISTILL,"source_schedule":reference(manifest),
        "loss":"All heads optimize the exact clean absolute, paired fine and flat lift losses after the same quiet correction. Both distillation arms add 0.35 matched noise-normalized loss on the frozen teacher lift only. Same-draw uses the query's teacher. Cross-draw uses the other independent repeat for that same role and target.",
        "conditioning":"Two repeats, three roles, crossed Bayer/ISO/natural-or-edge strata. Smoothed same-frame innovation at student input. At inference one RAW and its parent feed the fixed quiet and student detail routes.",
        "optimizer":"AdamW with 48 warmup updates from zero, then 1e-4 to 1e-5 cosine. EMA .995, CUDA IEEE FP32, shared physical inputs.",
    })


def batch_sample(record,step,position):
    n=step-1
    phase=position+2*((n//2)%2)
    edge=position==((n//4)%2)
    iso,shot,read=("iso6400",.00128,6.5536e-6) if n%2 else ("iso1600",.00032,4.096e-7)
    jitter=random.Random(scene_seed(TRAIN_SEED,step,"camera-profile"))
    j=2**jitter.uniform(-.3,.3)
    profile={"name":iso,"shot":shot*j,"read":read*j*j,"exposure":2**jitter.uniform(-2.3,-.7)}
    style="same-edge" if edge else "natural"
    pattern=tuple(PATTERNS)[phase]
    row=record|{"camera":record["camera"]|{"pattern":pattern}}
    tensors,seeds=sensor_triplets(row,style,profile,TRAIN_SEED)
    extra={"source":record["source"]["id"],"index":row["index"],"style":style,"profile":profile,"CFA":pattern,
           "seeds":seeds,"values":{k:fingerprint(val.numpy()) for k,val in tensors.items()}}
    return tensors,extra


def lr(step):
    if step<=48:
        return 1e-4*step/48
    f=(step-48)/(STEPS-48)
    return 1e-5+9e-5*(.5+.5*math.cos(math.pi*f))


def tune(qualification):
    spec=ROOT/"training-plan.json"
    plan=read_json(spec)
    assert checked(plan["driver"])==Path(__file__)
    for dep in plan["dependency_sources"]:
        checked(dep)
    source=read_json(checked(plan["source_schedule"]))
    rows=source["qualification" if qualification else "rows"]
    count=4 if qualification else STEPS
    out=ROOT/("qualification" if qualification else "training")
    out.mkdir()
    write_json(out/"launch.json",{"plan":reference(spec),"pid":os.getpid(),
               "created":psutil.Process().create_time(),"qualification":qualification})
    os.sched_setaffinity(0,[10,11,17])
    os.nice(9)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,14*2**30/torch.cuda.get_device_properties(0).total_memory))
    upstream=setup_models(plan)["Corpus 100k"].requires_grad_(False)
    parent_hash=model_hash(upstream)
    old=torch.load(checked(plan["initial_head"]),map_location="cpu",weights_only=True)["weights"]["paired"]["ema"]
    teacher=PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).requires_grad_(False).eval()
    models={key:PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last) for key in ARMS}
    for branch in (*models.values(),teacher):
        branch.load_state_dict(old)
    teacher_hash=model_hash(teacher)
    live={k:{n:t.clone() for n,t in p.state_dict().items()} for k,p in models.items()}
    opt={k:torch.optim.AdamW(model.parameters(),lr=1e-4) for k,model in models.items()}
    cut=(read_json(checked(plan["guard"]))["threshold"],read_json(checked(plan["guard_long"]))["threshold_0_to_1"][0])
    headers=[]
    counts=Counter()
    began=time.monotonic()
    with (out/"observations.jsonl").open("x") as receipt,ieee_fp32():
        for step in range(1,count+1):
            offset=2*(step-1)
            readouts=[batch_sample(rows[offset+i],step,i) for i in range(2)]
            for _,row in readouts:
                counts["/".join((row["profile"]["name"],row["style"],row["CFA"]))]+=1
            flat={k:torch.cat([r[0][k].flatten(0,1) for r in readouts]).cuda() for k in (*ARGS,"target")}
            for k in ("packed","variance","target"):
                flat[k]=flat[k].contiguous(memory_format=torch.channels_last)
            args=tuple(flat[k] for k in ARGS)
            profile=readouts[0][1]["profile"]
            assert profile==readouts[1][1]["profile"]
            upstream.set_noise(profile["shot"],profile["read"])
            with torch.no_grad():
                parent=torch.cat([upstream(*(arr[s] for arr in args)) for s in (slice(0,6),slice(6,12))])
                wide,shared=paired_gates(*args[:3],*cut)
                calm,_=quiet(teacher,parent,args,wide)
                calm_y=teacher.scene_luma(calm,*args[-2:])
                target=fine_band(teacher.scene_luma(flat["target"]-parent,*args[-2:]))
                frozen=teacher.luminance_delta(parent,*args)*shared
                separate=shaped(frozen).flip(1).flatten(0,2)
                noise=flat["variance"].mean((1,2,3)).sqrt().clamp_min(.001)[:,None,None,None]
                pair_noise=shaped(noise)[:,:,:2].mean(dim=(1,2))
                if step==1:
                    assert torch.equal(shaped(flat["target"])[:,0],shaped(flat["target"])[:,1])
                    assert not torch.equal(frozen,separate)
            tied={}
            first_prediction=None
            for key,model in models.items():
                optimizer=opt[key]
                optimizer.param_groups[0]["lr"]=lr(step)
                optimizer.zero_grad(set_to_none=True)
                delta=detail(model,parent,args,shared)
                if step==1:
                    if first_prediction is None:
                        first_prediction=delta.detach()
                    else:
                        assert torch.equal(first_prediction,delta.detach())
                residual=delta+calm_y-target
                abs_scaled=residual/noise
                absolute=.6*robust(abs_scaled[CORE])+.4*robust(abs_scaled)
                shaped_err=shaped(residual)
                pair=shaped_err[:,:,0]-shaped_err[:,:,1]
                signed=robust((pair/pair_noise[:,None])[CORE])
                flat_lift=shaped(delta/noise)[:,:,2][CORE].square().mean()
                objective=absolute+.65*signed+.25*flat_lift
                teaching=None
                if key!="supervised":
                    guide=frozen if key=="same-draw" else separate
                    teaching=robust(((delta-guide)/noise)[CORE])
                    objective=objective+DISTILL*teaching
                objective.backward()
                norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
                optimizer.step()
                ema_update(live[key],model)
                tied[key]={
                    "objective":float(objective.detach()),"absolute":float(absolute.detach()),
                    "pair":float(signed.detach()),"flat":float(flat_lift.detach()),"norm":float(norm.detach()),
                    "teacher":float(teaching.detach()) if teaching is not None else None,
                }
            receipt.write(json.dumps({"step":step,"samples":[r[1] for r in readouts],"scores":tied})+"\n")
            receipt.flush()
            if step%48==0 or step==count:
                print(step,round(time.monotonic()-began,2),tied,flush=True)
            if step in (96,192,288) or step==count:
                headers.append(save_checkpoint(out,step,models,live,opt,reference(spec)))
    assert model_hash(upstream)==parent_hash and model_hash(teacher)==teacher_hash
    if not qualification:
        assert len(counts)==16 and set(counts.values())=={48}
    state=torch.load(checked(headers[-1]),map_location="cpu",weights_only=True)
    assert state["step"]==count and all(v.isfinite().all() for m in state["weights"].values() for v in m["ema"].values())
    write_json(out/"complete.json",{
        "plan":reference(spec),"head_checkpoint":headers[-1],"interim_checkpoints":headers,
        "updates":count,"photos":2*count,"examples_per_head":12*count,"cells":dict(counts),
        "parent":plan["models"]["Corpus 100k"],"initial_head":plan["initial_head"],
        "parent_weights":parent_hash,"teacher_weights":teacher_hash,"qualification":qualification,
        "observations":reference(out/"observations.jsonl"),"seconds":time.monotonic()-began,
    })


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("action",choices=("plan","qualify","train"))
    action=cli.parse_args().action
    freeze() if action=="plan" else tune(action=="qualify")
