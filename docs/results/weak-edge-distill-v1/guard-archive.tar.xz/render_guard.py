"""Render the measured-edge gate with fixed quiet smoothing at native pixels."""
from pathlib import Path

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from edge_guard import edge_weight
from edge_delivery import detail
from measure_detail_scale import metric
from render_edge import (
    ROOT, ARGS, LABELS, as_cuda, fields, load_models,
    native_board, paired_gates, quiet, render_repeat,
)


def restore(state, args, parents, thresholds):
    teacher, _ = state
    parent = torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
    wide, shared = paired_gates(*args[:3], *thresholds)
    calm, grey = quiet(teacher, parent, args, wide)
    lift = detail(teacher, parent, args, shared) * grey[:, :, None, None]
    anchor = parent + calm
    weight = edge_weight(teacher.scene_luma(parent, *args[-2:]), args[1])
    return parents | {
        "quiet-only": anchor.cpu().numpy(),
        "quiet-lift": (anchor + lift).cpu().numpy(),
        "measured-step": (anchor + lift * weight).cpu().numpy(),
    }


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    result = reference(ROOT / "guard-detail-strength.json")
    data = read_json(checked(result))
    fixed = read_json(ROOT / "fixed-review.json")
    parents = read_json(checked(fixed["parents"]))
    observations = read_json(checked(parents["observations"]))
    plan = read_json(checked(observations["plan"]))
    recipe = read_json(checked(fixed["recipe"]))
    teacher, branches, endpoint = load_models("fixed", recipe)
    assert endpoint == data["checkpoint"]
    thresholds = (read_json(checked(recipe["guard"]))["threshold"],
                  read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0])
    cases = {record["id"]:record for record in observations["cases"]}
    old = {record["id"]:record for record in parents["rows"]}
    rows = [r for r in data["rows"] if r["profile"] == "iso6400" and r["style"] == "same-edge"]
    def delta(row,key):
        return metric(row["moments"]["measured-step"],1)[key] - metric(row["moments"]["quiet-lift"],1)[key]
    examples=(min(rows,key=lambda r:delta(r,"near_increment_DN16")),
              max(rows,key=lambda r:delta(r,"near_increment_DN16")),
              max(rows,key=lambda r:delta(r,"near_absent_DN16")))
    destination=ROOT/"guard-native"
    destination.mkdir()
    render_repeat.SHOW=("quiet-lift","measured-step")
    render_repeat.DISPLAY=LABELS | {"measured-step":"Measured-edge gate"}
    render_repeat.predictions=restore
    boards=[]
    with ieee_fp32():
        for row, role in zip(examples,(0,0,1),strict=True):
            tag=row["id"]
            source=plan["heldout_rows"][row["index"]]
            case=cases[tag]
            values=fields(case)
            with np.load(checked(old[tag]["saved"]),allow_pickle=False) as archive:
                base={name:archive[name][0] for name in ("100k","V120")}
            prediction=restore((teacher,branches),as_cuda({k:v[0] for k,v in values.items()}),base,thresholds)
            inputs={key:values[key][0][role:role+1] for key in ARGS}
            names=("V120","100k","quiet-lift","measured-step")
            pieces=[noisy_malvar(inputs)[0],*[prediction[k][role] for k in names],values["target"][0,role]]
            boards.append(native_board(
                destination,f"{tag}-r0-role{role}",pieces,inputs,
                {"source_photo":source["source"],"bbox_native":source["box"],"CFA":source["camera"]["pattern"],
                 "profile":case["profile"],"physical":case["input"],"checkpoint":endpoint},
                labels=("Noisy Malvar",*[render_repeat.DISPLAY[k] for k in names],"Exact GT"),
                triplet_indices=(0,4,5),exposure=1/case["profile"]["exposure"],contrast=2,
                roi=tuple(plan["display_ROI_xywh"])))
        camera=render_repeat.show_camera((teacher,branches),thresholds,destination)
    write_json(destination/"render.json",{"analytic":result,"driver":reference(__file__),"photo":boards,
                                          "camera":camera,"actual_native_viewing_complete":False})


if __name__ == "__main__":
    run()
