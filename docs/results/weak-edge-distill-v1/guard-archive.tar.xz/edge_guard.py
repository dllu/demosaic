"""Lower the detail lift around a strong coherent step in the parent luminance."""
import torch
from torch.nn import functional as F


def pool(signal,width):
    return F.avg_pool2d(signal,width,stride=1,padding=width//2,count_include_pad=False)


def edge_weight(luminance,variance):
    smooth=pool(luminance,3)
    rim=F.pad(smooth,(1,1,1,1),mode="replicate")
    dx=(rim[...,1:-1,2:]-rim[...,1:-1,:-2])*.5
    dy=(rim[...,2:,1:-1]-rim[...,:-2,1:-1])*.5
    gradients=torch.cat((dx,dy),1)
    signed=pool(gradients,17).norm(dim=1,keepdim=True)
    absolute=pool(gradients.norm(dim=1,keepdim=True),17)
    coherence=signed/absolute.clamp_min(1e-8)
    typical=variance.mean(dim=1,keepdim=True).clamp_min(1e-10).sqrt()
    sigma=F.interpolate(typical,scale_factor=2,mode="nearest")
    height_strength=((17*signed/sigma-1.6)/2.4).clamp(0,1)
    orientation_strength=((coherence-.60)/.30).clamp(0,1)
    suppression=F.max_pool2d(height_strength*orientation_strength,5,stride=1,padding=2)
    return 1-.85*suppression


def oracle_weight(distance):
    return 1-.85*torch.exp(-.5*(distance/10.)**2)
