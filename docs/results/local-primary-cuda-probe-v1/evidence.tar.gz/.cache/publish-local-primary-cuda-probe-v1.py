"""Preserve immutable probe evidence without copying prediction arrays."""
import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/local-primary-CUDA-probe-v1"
out = repo / "docs/results/local-primary-cuda-probe-v1"
out.mkdir()
files = [root / p for p in ["plan.json", "launch.json", "probe.log",
                           "output/result.json", "independent-audit.json"]]
files.extend(root.glob("output/*-*.json"))
files.extend(p for p in (root / "work").rglob("*.py") if "__pycache__" not in p.parts)
files.extend([repo / ".cache/audit-local-primary-cuda-probe-v1.py",
              repo / ".cache/audit-local-primary-cuda-probe-v1.log", Path(__file__).resolve()])
archive = out / "evidence.tar.gz"
members = []
with archive.open("xb") as stream, gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as gz, tarfile.open(fileobj=gz, mode="w") as tar:
    for path in sorted(set(files)):
        relative = str(path.relative_to(repo))
        members.append({"member": relative, **reference(path)})
        tar.add(path, arcname=relative, recursive=False)
with tarfile.open(archive) as tar:
    for binding in members:
        assert hashlib.sha256(tar.extractfile(binding["member"]).read()).hexdigest() == binding["sha256"]
audit = read_json(root / "independent-audit.json")
assert audit["status"] == "passed" and audit["audited_model_batches"] == 24
for source, target in [("output/result.json","result.json"),("independent-audit.json","independent-audit.json")]:
    shutil.copyfile(root / source, out / target)
write_json(out / "publication.json", {
    "archive": reference(archive), "members": members, "all_member_bytes_verified": True,
    "result": reference(out / "result.json"), "independent_audit": reference(out / "independent-audit.json"),
    "scope": "Closed 24 matched CPU/CUDA output pairs, IEEE FP32 channels-last CUDA, original"
             " .25/.025 DN16 limits. All per-output pixel and primary metric differences audited."
             " Original frozen source bytes, settings and logs preserved. Prediction arrays remain local.",
})
print("Archived", len(members), "probe evidence files")
