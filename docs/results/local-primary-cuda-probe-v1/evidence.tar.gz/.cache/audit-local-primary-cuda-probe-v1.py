"""Independently verify the saved CPU/CUDA primary outputs and original bounds."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


root = Path(".cache/experiments/local-primary-CUDA-probe-v1").resolve()
result = read_json(root / "output/result.json")
plan = read_json(checked(result["plan"]))
records = {(v["record"]["stage"], v["record"]["batch"]): v["record"] for v in plan["cases"]}
timings = defaultdict(lambda: {"CPU": 0., "CUDA": 0., "observations_per_model": 0})
max_pixel = max_rms = max_score = 0.
counts = defaultdict(int)
for row in result["rows"]:
    record = records[row["stage"], row["batch"]]
    with np.load(checked(record["arrays"])) as data:
        inputs = dict(data)
    cpu = np.load(checked(row["CPU_prediction"])).astype(np.float64)
    gpu = np.load(checked(row["CUDA_prediction"])).astype(np.float64)
    delta = gpu - cpu
    max_dn = float(np.max(np.abs(delta))) * 65535
    rms = float(np.linalg.norm(delta.ravel()) / np.sqrt(delta.size)) * 65535
    np.testing.assert_allclose([max_dn, rms], [row["max_DN16"], row["RMS_DN16"]], atol=1e-12)
    assert row["within_pixel_bounds"] == (max_dn <= .25 and rms <= .025)
    max_pixel, max_rms = max(max_pixel, max_dn), max(max_rms, rms)
    if row["stage"] == "photo":
        border = 8
        def render(values):
            values = values * inputs["wb"][..., None, None]
            linear = (inputs["matrix"] @ values.reshape(len(values), 3, -1)).reshape(values.shape)
            linear = np.clip(linear, 0, 1)
            return np.where(linear <= .0031308, 12.92 * linear, 1.055 * linear ** (1/2.4) - .055)
        truth = render(inputs["target"])
        def score(values):
            error = (render(values) - truth)[..., border:-border, border:-border]
            return -10 * np.log10(np.maximum(np.mean(error**2, axis=(1, 2, 3)), 1e-12))
    else:
        border = 32
        target = inputs["sensor_reference"][..., border:-border, border:-border]
        mask = inputs["sensor_mask"][..., border:-border, border:-border]
        def score(values):
            p = np.clip(values[..., border:-border, border:-border], 0, 1)
            error = (p - target)[mask]
            starts = np.r_[0, np.cumsum(mask.sum((1, 2, 3)))[:-1]]
            mse = np.add.reduceat(error**2, starts) / mask.sum((1, 2, 3))
            return -10 * np.log10(np.maximum(mse, 1e-12))
    difference = score(gpu) - score(cpu)
    np.testing.assert_allclose(difference, row["metric_differences"][row["primary_metric"]],
                               rtol=0., atol=2e-11)
    max_score = max(max_score, float(np.abs(difference).max()))
    timing = timings[row["stage"]]
    for device in ["CPU", "CUDA"]:
        timing[device] += row[device + "_inference_seconds"]
    if row["model"] == "V120":
        timing["observations_per_model"] += row["batch_size"]
    counts[row["model"]] += 1
assert len(result["rows"]) == 24 and set(counts.values()) == {12}
assert max_pixel <= .25 and max_rms <= .025
write_json(root / "independent-audit.json", {
    "recorded_UTC": datetime.now(timezone.utc).isoformat(),
    "producer": reference(__file__), "result": reference(root / "output/result.json"),
    "audited_model_batches": sum(counts.values()), "timings": dict(timings),
    "max_DN16": max_pixel, "max_RMS_DN16": max_rms, "max_primary_delta_dB": max_score,
    "status": "passed",
    "scope": "Independent NumPy64 per-pixel differences and primary deltas, with matrix product"
             " rendering for photo and indexed CFA masks for camera. Original CPU/GPU bounds;"
             " scoring all cases of the probe, not the full benchmark. No learned calls.",
})
print("Audited", sum(counts.values()), "model batches", dict(timings))
