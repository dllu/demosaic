"""Independently re-aggregate the verified 100k and V120 fixed-panel rows."""
from collections import Counter,defaultdict
from pathlib import Path
from statistics import mean
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=Path.cwd()
CAMERA=REPO/"docs/results/full-corpus-long100k-camera-v1/publication.json"
TRAINING=REPO/"docs/results/full-corpus-long100k-training-v1/publication.json"
SHORT=REPO/"docs/results/full-corpus-control20k-primary-v1/primary.json"
DEST=REPO/"docs/results/full-corpus-long100k-primary-v1"
ARMS=("V120","scale-long100k")
METRICS=("srgb_psnr","linear_psnr")

def relative(path):
    return reference(path)|{"path":str(path.relative_to(REPO))}

def main():
    adoption=ROOT/"primary-with-V120.json"
    adoption_doc=read_json(adoption)
    full_path=checked(adoption_doc["primary"])
    full=read_json(full_path)
    assert full["kind"]=="full" and full["all_complete"] and full["cases"]==3162
    assert full["new_root_calls"]==0
    assert set(full["completed_panels"])=={"photo","known","unseen"}
    checked(adoption_doc["recovery"])
    short=read_json(SHORT)
    camera=read_json(CAMERA)
    training=read_json(TRAINING)
    plan_path=checked(full["plan"])
    plan=read_json(plan_path)
    target=checked(plan["canonical_inputs"])
    assert plan["canonical_inputs"]==short["canonical_inputs"]
    specs=read_json(target)
    versions=full["models"]
    assert versions==plan["models"] and set(versions)==set(ARMS)
    assert versions["V120"]["checkpoint"]==short["models"]["V120"]["checkpoint"]
    assert versions["scale-long100k"]["checkpoint"]==training["model"]["checkpoint"]
    assert all(v["weights"]=="EMA" for v in versions.values())
    canonical={(row["stage"],row["batch"]):row for row in specs["records"]}
    assert specs["all_input_witnesses_exact"] and len(canonical)==3162

    seen=Counter()
    seen_cases=set()
    scores=defaultdict(dict)
    by_condition=defaultdict(list)
    for binder in full["case_records"]:
        case=read_json(checked(binder))
        stage,batch=case["stage"],case["batch"]
        identity=(stage,batch)
        entry=canonical[identity]
        assert identity not in seen_cases
        seen_cases.add(identity)
        seen[stage]+=1
        assert case["canonical_arrays"]==entry["arrays"]
        assert case["input_fingerprints"]=={k:entry["fingerprints"][k]
             for k in ("packed","variance","colors","wb","matrix")}
        assert set(v["arm"] for v in case["variants"])==set(ARMS)
        assert case["new_root_calls"]==0
        for variant in case["variants"]:
            arm=variant["arm"]
            assert variant["checkpoint"]==versions[arm]["checkpoint"] and variant["weights"]=="EMA"
            assert [r["id"] for r in variant["rows"]]==entry["context"]["ids"]
            for row in variant["rows"]:
                if stage!="photo" or row["kind"]!="photo":
                    continue
                assert stage=="photo" and row["model"]==arm
                by_source=scores[row["id"]]
                key=(arm,row["condition"],row["pattern"])
                assert key not in by_source
                by_source[key]=row["metrics"]
                by_condition[(arm,row["condition"])].append(row["metrics"]["srgb_psnr"])

    assert seen=={"known":24,"unseen":30,"photo":3108}
    assert seen_cases==set(canonical)
    assert set(scores)==set(short["source_averages"]) and len(scores)==427
    recipes={key[1:] for key in next(iter(scores.values()))}
    assert len(recipes)==28 and len({c for c,_ in recipes})==7 and len({p for _,p in recipes})==4
    merged={}
    required={(arm,c,p)for arm in ARMS for c,p in recipes}
    for photo,table in sorted(scores.items()):
        assert set(table)==required
        merged[photo]={arm:{stat:mean(table[arm,c,p][stat]for c,p in recipes)
                   for stat in METRICS}for arm in ARMS}
        for stat in METRICS:
            assert abs(merged[photo]["V120"][stat]-short["source_averages"][photo]["V120"][stat])<1e-11
    totals={arm:{m:mean(r[arm][m]for r in merged.values())for m in METRICS}for arm in ARMS}
    official=[r for r in full["summaries"]["photo"]["overall"]if r["kind"]=="photo"]
    for row in official:
        for stat in METRICS:
            metric=row["metrics"][stat]
            assert metric["count"]==427 and abs(metric["mean"]-totals[row["model"]][stat])<1e-11
    camera_scores={}
    for stage,count in (("known",4),("unseen",5)):
        camera_scores[stage]={}
        for row in full["summaries"][stage]["overall"]:
            metric=row["metrics"]["sensor_psnr"]
            arm=row["model"]
            assert metric["count"]==count
            assert metric["mean"]==camera["results"][stage]["overall"][arm]["sensor_psnr"]
            camera_scores[stage][arm]=metric["mean"]
    conditions={}
    for noise in sorted({key for key,_ in recipes}):
        assert all(len(by_condition[(arm,noise)])==427*4 for arm in ARMS)
        values={arm:mean(by_condition[(arm,noise)])for arm in ARMS}
        conditions[noise]=values|{"gain":values[ARMS[1]]-values[ARMS[0]]}

    DEST.mkdir()
    archive=DEST/"primary-evidence.tar.xz"
    members={
        "collector-result.json":full_path,"combined-plan.json":plan_path,
        "canonical-input-index.json":target,"verify-primary.py":Path(__file__),
        "matched-adoption.json":adoption,"original-recovery.json":checked(adoption_doc["recovery"]),
    }
    with tarfile.open(archive,"x:xz")as tar:
        for name,path in members.items():
            tar.add(path,arcname=name)
    differences=[r["scale-long100k"]["srgb_psnr"]-short["source_averages"][key]["scale-control20k"]["srgb_psnr"]
                 for key,r in merged.items()]
    write_json(DEST/"primary.json",{
        "all_complete":True,"photo_sources":427,"noise_conditions":7,"CFAs":4,
        "case_receipts_verified":len(seen_cases),"batches":dict(seen),"observations_per_model":11956,
        "models":versions,"source_result":reference(full_path),"canonical_inputs":reference(target),
        "archive":relative(archive),"archive_member_sha256":{key:reference(path)["sha256"] for key,path in members.items()},
        "source_balanced":totals,"collector_photo_overall":official,"source_averages":merged,
        "paired_photo_differences":full["summaries"]["photo"]["paired_comparisons"][:3],
        "per_condition_srgb_PSNR":conditions,
        "photographic_sources_improved":sum(r[ARMS[1]]["srgb_psnr"]>r[ARMS[0]]["srgb_psnr"] for r in merged.values()),
        "against_corpus20k":{"source":relative(SHORT),"mean_srgb_gain":mean(differences),
                             "sources_improved":sum(d>0 for d in differences)},
        "known_unseen_camera_PSNR":camera_scores,"camera_summary":relative(CAMERA),"training":relative(TRAINING),
        "scope":"Complete fixed CPU IEEE FP32 canonical panel. Exact model and observation binding with independently aggregated per-photo and per-condition means. Prior V120 outputs are used at identical input/precision, and its 427 means reproduce their existing report.",
    })

if __name__=="__main__":
    main()
