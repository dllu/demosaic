"""Render native examples from the verified Corpus 100k fixed photo panel."""
import json
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board

HERE=Path(__file__).resolve().parent
REPO=Path.cwd()
NEW="scale-long100k"
OLD="V120"
SHORT="scale-control20k"
KEYS=("packed","variance","colors","wb","matrix")
PRIMARY=REPO/"docs/results/full-corpus-long100k-primary-v1/primary.json"

def main():
    receipt=read_json(PRIMARY)
    canonical_book=read_json(checked(receipt["canonical_inputs"]))
    setup=read_json(checked(canonical_book["plan"]))
    manifest=next(ref for ref in setup["inputs"]if ref["path"].endswith("common-8192-44732-val-v1.jsonl"))
    photos={p["id"]:p for line in checked(manifest).read_text().splitlines() if line for p in [json.loads(line)]}
    full=read_json(checked(receipt["source_result"]))
    cases={int(Path(binding["path"]).parent.name.split("-")[1]):binding
           for binding in full["case_records"] if Path(binding["path"]).parent.name.startswith("photo-")}
    sources=receipt["source_averages"]
    def gain(source):
        return sources[source][NEW]["srgb_psnr"] - sources[source][OLD]["srgb_psnr"]
    ordered=sorted(sources,key=gain)
    query=[(ordered[len(ordered)//2],"median source gain","iso12800-prior"),
           (ordered[0],"lowest source-average change",None)]
    rows=[]
    dest=HERE/"primary-native";dest.mkdir()
    for identity,selection,preferred in query:
        alternatives=[]
        for r in canonical_book["records"]:
            if r["stage"]!="photo" or r["context"]["pattern"]!="RGGB" or identity not in r["context"]["ids"]:
                continue
            noise=r["context"]["condition"]
            batch=r["batch"]
            if preferred is not None and noise["name"]!=preferred:
                continue
            case=read_json(checked(cases[batch]))
            assert case["canonical_arrays"]==r["arrays"]
            by_arm={v["arm"]:v for v in case["variants"]}
            index=r["context"]["ids"].index(identity)
            metrics={k:v["rows"][index]["metrics"]["srgb_psnr"]for k,v in by_arm.items()}
            assert all(v["rows"][index]["id"]==identity for v in by_arm.values())
            score=metrics[NEW]-metrics[OLD]
            alternatives.append((score,r,case,by_arm,index,metrics))
        _,r,case,by_arm,index,metrics=min(alternatives,key=lambda v:v[0])
        short=read_json(checked(case["source_cases"][0]))
        assert short["canonical_arrays"]==r["arrays"] and short["input_fingerprints"]==case["input_fingerprints"]
        third=next(v for v in short["variants"]if v["arm"]==SHORT)
        by_arm[SHORT]=third
        metrics[SHORT]=third["rows"][index]["metrics"]["srgb_psnr"]
        with np.load(checked(r["arrays"]),allow_pickle=False)as values:
            args={k:values[k][index:index+1]for k in KEYS}
            target=values["target"][index]
        predicted={k:np.load(checked(v["prediction"]),allow_pickle=False)[index]for k,v in by_arm.items()}
        profile=r["context"]["condition"]
        row=native_board(dest,f"{identity[:12]}-{profile['name']}",
            [noisy_malvar(args)[0],predicted[OLD],predicted[SHORT],predicted[NEW],target],
            args,{"source":photos[identity],"source_manifest":manifest,"selection":selection,
                  "source_average_gain_dB":gain(identity),"fixed_query_scores":metrics,
                  "CFA":r["context"]["pattern"],"noise":profile,"target":r["context"]["clean_RGB"],
                  "fixed_native_input":r["arrays"],"checkpoint":by_arm[NEW]["checkpoint"],
                  "reference_checkpoints":{k:v["checkpoint"]for k,v in by_arm.items()},
                  "weights":"EMA","precision":"CPU IEEE FP32"},
            labels=("Noisy Malvar","V120 EMA","Corpus 20k EMA","Corpus 100k EMA","Exact GT"),
            triplet_indices=(0,3,4),exposure=1/profile["exposure"],contrast=1,
            roi=(48,48,160,160))
        rows.append(row)
    write_json(dest/"result.json",{"driver":reference(__file__),"primary":reference(PRIMARY),"boards":rows})

if __name__=="__main__":
    main()
