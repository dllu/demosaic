"""Compare context-dependent detail attenuation with frozen predictions."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from context_strength import gates, summarize

ROOT = Path(__file__).resolve().parent
SCENE = ROOT.parent / "scene-local-contrast-2400-v1"
DONOR = ROOT.parent / "natural-raw-donor-evidence-v1"
WEAK = ROOT.parent / "weak-edge-distill-v1"
PAIRED = ROOT.parent / "paired-repeat-stability-v2"
SHAPE = ROOT.parent / "paired-shape-stability-v1"
sys.path[:0] = [str(WEAK), str(PAIRED), str(SCENE), str(SHAPE)]
from edge_delivery import detail, quiet, paired_gates
from evaluate_repeat import as_cuda, channel_coefficients, head
from measure import BANDS
from strength_moments import triplet

ARGS = ("packed", "variance", "colors", "wb", "matrix")
METHODS = ("100k", "quiet", "uniform", "local", "matching", "mirrored")
METRICS = ("increment", "present", "absent", "flat")


def freeze():
    prerequisites = {
        "panel": reference(SCENE / "evaluation-plan.json"),
        "parents": reference(DONOR / "full-parent.json"),
        "frozen_composition": reference(WEAK / "training-plan.json"),
        "standing_composition": reference(WEAK / "guard-native/render.json"),
        "driver": reference(__file__),
        "context": reference(ROOT / "context_strength.py"),
    }
    write_json(
        ROOT / "plan.json",
        prerequisites
        | {
            "calibration": list(range(32)),
            "test": list(range(32, 64)),
            "profiles": ["iso400", "iso6400"],
            "primary": "ISO6400 fresh-source half, coupled and independent drawn cases. Fit a single non-amplifying scalar per method to the smallest available response in each profile on coupled calibration cases only.",
            "scope": "Green power debiased by the noise model, with a fixed analytical modulation. Same frozen quiet component and native detail signal in every attenuation arm. Both distant views exclude Bayer samples in the query plus a native 16-pixel halo, even after mirror.",
        },
    )


def inputs(record):
    case = read_json(checked(record["source"]))
    assert record["id"] == case["id"]
    with np.load(checked(case["input"]), allow_pickle=False) as f:
        arrays = {key: f[key] for key in (*ARGS, "target", "scene_packed")}
    assert {k: fingerprint(v) for k, v in arrays.items()} == case["fingerprints"]
    assert record["exact_query"] == {k: case["fingerprints"][k] for k in ARGS}
    cached = checked(record["rgb"])
    if record["npz_field"] is None:
        parent = np.load(cached, allow_pickle=False)
    else:
        with np.load(cached, allow_pickle=False) as f:
            parent = f[record["npz_field"]]
    assert parent.shape == arrays["target"].shape == (3, 3, 256, 256)
    return case, arrays, parent


def bind_models(recipe):
    old = torch.load(checked(recipe["initial_head"]), map_location="cpu", weights_only=True)
    frozen = head(old, "paired")
    limits = (
        read_json(checked(recipe["guard"]))["threshold"],
        read_json(checked(recipe["guard_long"]))["threshold_0_to_1"][0],
    )
    return frozen, limits


def local_paths(frozen, packed, parent, limits):
    outer, inner = paired_gates(*packed[:3], *limits)
    calm, grey = quiet(frozen, parent, packed, outer)
    return parent + calm, detail(frozen, parent, packed, inner) * grey[:, :, None, None]


def variants(frozen, limits, case, native, prior):
    expanded = {
        k: native[k]
        if k in ("packed", "variance")
        else np.broadcast_to(native[k], (3, *native[k].shape))
        for k in ARGS
    }
    args = as_cuda(expanded)
    parent = torch.from_numpy(prior).cuda().contiguous(memory_format=torch.channels_last)
    base, lift = local_paths(frozen, args, parent, limits)
    full = torch.from_numpy(native["scene_packed"]).cuda()
    fields = case["profile"]
    outer = summarize(full, args[2][0], fields["shot"], fields["read"])
    weight = gates(args[0], args[2][0], fields["shot"], fields["read"], case["box"], outer)
    predictions = {"100k": parent, "quiet": base, "uniform": base + lift}
    predictions.update({name: base + lift * value for name, value in weight.items()})
    return {k: v.cpu().numpy() for k, v in predictions.items()}, {
        k: [
            [float(x) for x in role]
            for role in zip(
                value.mean((-2, -1)).flatten(),
                value.amin((-2, -1)).flatten(),
                value.amax((-2, -1)).flatten(),
            )
        ]
        for k, value in weight.items()
    }


def moments(base, alternative, truth):
    both = np.asarray([base, alternative, truth])[..., BANDS["fine"]]
    q, output, target = both
    difference = output - q
    assert np.max(np.abs(target[2])) < 1e-14
    signal = target[0] - target[1]
    increment = q[0] - q[1]
    step = difference[0] - difference[1]
    return {
        "increment": triplet(increment - signal, step, (-2, -1)).tolist(),
        **{
            key: triplet(q[ix] - target[ix], difference[ix], (-2, -1)).tolist()
            for ix, key in enumerate(("present", "absent", "flat"))
        },
        "score": [float((increment * signal).sum()), float((step * signal).sum())],
        "target_power": float((signal * signal).sum()),
    }


def value(row, scale):
    q = np.array([1, scale, scale**2])
    return {key: float(np.sqrt(max(np.asarray(row[key]) @ q, 0))) for key in METRICS} | {
        "dot": row["score"][0] + scale * row["score"][1],
        "power": row["target_power"],
    }


def contrast(rows, key, control, scales, rng):
    measurements = [
        [value(row["scores"][k], scales.get(k, 1)) for k in (key, control)] for row in rows
    ]
    ix = rng.integers(len(rows), size=(4000, len(rows)))
    result = {}
    for name in METRICS:
        delta = np.array([a[name] - b[name] for a, b in measurements])
        result[name] = [
            float(delta.mean()),
            *np.quantile(delta[ix].mean(1), [0.025, 0.975]).tolist(),
        ]
    delta = np.array([a["dot"] - b["dot"] for a, b in measurements])
    power = np.array([a["power"] for a, b in measurements])
    result["response_pp"] = [
        float(100 * delta.sum() / power.sum()),
        *np.quantile(100 * delta[ix].sum(1) / power[ix].sum(1), [0.025, 0.975]).tolist(),
    ]
    return result


def compare(plan, rows):
    result = {}
    rng = np.random.default_rng(83248)
    for prior in plan["profiles"]:
        by_profile = [r for r in rows if r["profile"] == prior]
        routes = METHODS[2:]
        fit = [
            r for r in by_profile if r["index"] in plan["calibration"] and r["draw"] == "coupled"
        ]
        gains = {key: sum(r["scores"][key]["score"][1] for r in fit) for key in routes}
        assert len(fit) == 32
        # Every matched policy attenuates its own detail. The quiet anchor stays exact.
        scales = (
            {key: min(gains.values()) / val for key, val in gains.items()}
            if min(gains.values()) > 0
            else {}
        )
        if scales:
            for method in routes:
                np.testing.assert_allclose(
                    contrast(fit, method, "local", scales, rng)["response_pp"][0],
                    0,
                    rtol=0,
                    atol=1e-10,
                )
        result[prior] = {"calibration_response_dot": gains, "scales": scales, "draw": {}}
        for kind in ("coupled", "independent"):
            test = [r for r in by_profile if r["index"] in plan["test"] and r["draw"] == kind]
            faint = sorted(test, key=lambda r: r["scores"]["quiet"]["target_power"])[:16]
            assert len(test) == 32
            tests = (
                ("matching", "uniform"),
                ("matching", "local"),
                ("matching", "mirrored"),
                ("matching", "100k"),
                ("local", "uniform"),
                ("uniform", "100k"),
                ("quiet", "100k"),
            )
            result[prior]["draw"][kind] = {
                "nominal": {f"{a}_vs_{b}": contrast(test, a, b, {}, rng) for a, b in tests},
                "matched": {f"{a}_vs_{b}": contrast(test, a, b, scales, rng) for a, b in tests}
                if scales
                else None,
                "matched_fainter_half": {
                    f"{a}_vs_{b}": contrast(faint, a, b, scales, rng) for a, b in tests
                }
                if scales
                else None,
            }
    return result


@torch.inference_mode()
def run(smoke=False):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(
        min(1.0, 5 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    parent_set = read_json(checked(plan["parents"]))
    parent_plan = read_json(checked(parent_set["plan"]))
    recipe = read_json(checked(plan["frozen_composition"]))
    assert recipe["models"]["Corpus 100k"] == parent_plan["model"]
    sources = read_json(checked(plan["panel"]))
    model, thresholds = bind_models(recipe)
    rows = []
    started = time.monotonic()
    with ieee_fp32():
        for record in parent_set["records"][: 4 if smoke else None]:
            case, arrays, parent = inputs(record)
            predicted, spatial = variants(model, thresholds, case, arrays, parent)
            roi = sources["score_ROI_xywh"]
            camera = {
                name: np.broadcast_to(arrays[name], (3, *arrays[name].shape))
                for name in ("wb", "matrix")
            }
            coefficients = {
                k: channel_coefficients(v, camera, roi)[1]
                for k, v in (predicted | {"target": arrays["target"]}).items()
            }
            anchor = coefficients["quiet"]
            rows.append(
                {
                    "id": case["id"],
                    "index": case["case"],
                    "source": case["source"],
                    "profile": case["profile"]["name"],
                    "draw": case["draw"],
                    "gains_mean_min_max": spatial,
                    "scores": {
                        k: moments(anchor, coefficients[k], coefficients["target"]) for k in METHODS
                    },
                }
            )
            if smoke or len(rows) % 32 == 0:
                print(len(rows), round(time.monotonic() - started, 2), flush=True)
    if smoke:
        assert len(rows) == 4
    else:
        assert len(rows) == 256
    write_json(
        ROOT / ("smoke.json" if smoke else "result.json"),
        {
            "plan": plan_ref,
            "rows": rows,
            "metrics": None if smoke else compare(plan, rows),
            "seconds": time.monotonic() - started,
            "parent": parent_plan["model"],
            "correction": recipe["initial_head"],
        },
    )


if __name__ == "__main__":
    arg = argparse.ArgumentParser()
    arg.add_argument("action", choices=("freeze", "smoke", "run"))
    stage = arg.parse_args().action
    freeze() if stage == "freeze" else run(stage == "smoke")
