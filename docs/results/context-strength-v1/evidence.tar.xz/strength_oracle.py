"""Bound the headroom of scaling an existing fine correction in DCT blocks."""

import numpy as np
import torch

from collect import ROOT, bind_models, inputs, variants, channel_coefficients, BANDS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32


def dot(a, b):
    return np.sum(a * b, axis=-1)


def law(fields, band):
    base, step, target = (
        fields[key][..., band].swapaxes(-1, -2) for key in ("base", "step", "target")
    )
    error = base - target
    unit = float(65535**2 / (96 * 96))
    before = error[0] - error[1]
    change = step[0] - step[1]
    signal = target[0] - target[1]
    return {
        "increment": np.stack([dot(before, before), dot(before, change), dot(change, change)])
        * unit,
        "flat": np.stack([dot(error[2], error[2]), dot(error[2], step[2]), dot(step[2], step[2])])
        * unit,
        "absent": np.stack([dot(error[1], error[1]), dot(error[1], step[1]), dot(step[1], step[1])])
        * unit,
        "info": dot(signal, change) * unit,
        "target": dot(signal, signal) * unit,
    }


def energies(group, scale):
    return group[0] + 2 * group[1] * scale + group[2] * scale**2


def allocate(quad, flat, information, target, cap):
    """Solve a bounded diagonal quadratic at fixed response and flat energy."""

    def fit(flat_penalty):
        lin = quad[1] + flat_penalty * flat[1]
        cur = np.maximum(quad[2] + flat_penalty * flat[2], 1e-20)

        def gain(amplitude_multiplier):
            return (-(lin + amplitude_multiplier * information) / cur).clip(0, 1)

        lower, upper = -1.0, 1.0
        while np.sum(gain(lower) * information) < target:
            lower *= 2
        while np.sum(gain(upper) * information) > target:
            upper *= 2
        for _ in range(60):
            mid = (lower + upper) / 2
            if np.sum(gain(mid) * information) > target:
                lower = mid
            else:
                upper = mid
        return gain((lower + upper) / 2)

    optimum = fit(0)
    if energies(flat, optimum).sum() <= cap + 1e-10:
        return optimum, 0
    lower, upper = 0, 1.0
    while energies(flat, fit(upper)).sum() > cap + 1e-10:
        upper *= 2
        assert upper < 2**32
    for _ in range(46):
        mid = (lower + upper) / 2
        if energies(flat, fit(mid)).sum() > cap:
            lower = mid
        else:
            upper = mid
    return fit(upper), upper


def measure(rows, scale):
    metrics = {
        name: np.stack([r[name] for r in rows], axis=1) for name in ("increment", "flat", "absent")
    }
    info = np.stack([r["info"] for r in rows])
    power = np.stack([r["target"] for r in rows])
    fixed, candidates = np.full_like(info, scale), {"uniform": np.full_like(info, scale)}
    target = float((fixed * info).sum())
    cap = energies(metrics["flat"], fixed).sum()
    penalties = {}
    for name in ("image", "block"):
        if name == "image":
            weights, penalty = allocate(
                metrics["increment"].sum(-1), metrics["flat"].sum(-1), info.sum(-1), target, cap
            )
            candidates[name] = np.broadcast_to(weights[:, None], info.shape)
        else:
            candidates[name], penalty = allocate(
                metrics["increment"], metrics["flat"], info, target, cap
            )
        penalties[name] = penalty
        np.testing.assert_allclose(np.sum(candidates[name] * info), target, rtol=0, atol=1e-8)
        assert energies(metrics["flat"], candidates[name]).sum() <= cap + 1e-6
    result = {}
    for name, weight in candidates.items():
        spaces = {k: energies(v, weight).sum(-1) for k, v in metrics.items()}
        result[name] = {
            "aligned_delta_pp": float(100 * (weight * info).sum() / power.sum()),
            "active_score_bounds": [float(weight.min()), float(weight.max())],
            "flat_penalty": penalties.get(name),
            "loss": {},
        }
        for label, error in spaces.items():
            result[name]["loss"][label] = {
                "mean_per_source_RMS_DN16": float(np.sqrt(np.maximum(error, 0)).mean()),
                "global_RMS_DN16": float(np.sqrt(max(0, error.mean()))),
            }
    return result


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    numeric = reference(ROOT / "result.json")
    report = read_json(checked(numeric))
    plan = read_json(checked(report["plan"]))
    parent = read_json(checked(plan["parents"]))
    panel = read_json(checked(plan["panel"]))
    frozen, limits = bind_models(read_json(checked(plan["frozen_composition"])))
    groups = {"coupled": [], "independent": []}
    with ieee_fp32():
        for rec in parent["records"]:
            if not "-iso6400-" in rec["id"] or int(rec["id"][:3]) not in plan["test"]:
                continue
            case, arrays, anchor = inputs(rec)
            outs, _ = variants(frozen, limits, case, arrays, anchor)
            camera = {
                k: np.broadcast_to(arrays[k], (3, *arrays[k].shape)) for k in ("wb", "matrix")
            }
            fields = {
                k: channel_coefficients(v, camera, panel["score_ROI_xywh"])[1]
                for k, v in {
                    "base": outs["quiet"],
                    "step": outs["uniform"].astype("float64") - outs["quiet"],
                    "target": arrays["target"],
                }.items()
            }
            groups[case["draw"]].append(law(fields, BANDS["fine"]))
            if sum(map(len, groups.values())) % 16 == 0:
                print(sum(map(len, groups.values())), flush=True)
    assert all(len(v) == 32 for v in groups.values())
    output = {
        draw: measure(rows, report["metrics"]["iso6400"]["scales"]["uniform"])
        for draw, rows in groups.items()
    }
    write_json(
        ROOT / "oracle-headroom.json",
        {
            "driver": reference(__file__),
            "numeric": numeric,
            "metrics": output,
            "scope": "Exact target required. One gain per image or critically sampled 16x16 DCT block shared between all three query roles. Gains constrained to [0,1], fixed aligned response and at most the same pooled exact-flat fine-band error as uniform. This is a favorable diagnostic for the fixed lift within this blockwise representation.",
        },
    )


if __name__ == "__main__":
    run()
