"""Review context-scaled detail at native pixels on exact and standing cases."""

import argparse
from pathlib import Path

import numpy as np
import torch

from collect import (
    ARGS,
    ROOT,
    SCENE,
    bind_models,
    contrast,
    gates,
    inputs,
    local_paths,
    summarize,
    value,
    variants,
)
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board
import render_repeat

LABELS = {
    "100k": "Corpus 100k EMA",
    "quiet": "Quiet path",
    "uniform": "Uniform lift",
    "local": "Local strength",
    "matching": "Matched context",
    "mirrored": "Mirrored context",
}


def scaled(predictions, scales):
    base = predictions["quiet"]
    return {
        k: base + scales.get(k, 1) * (v - base) if k in scales else v
        for k, v in predictions.items()
    }


def exact(model, threshold, result, plan, scales, output):
    parent = read_json(checked(plan["parents"]))
    lookup = {r["id"]: r for r in parent["records"]}
    panel = read_json(checked(plan["panel"]))
    rows = [
        r
        for r in result["rows"]
        if r["profile"] == "iso6400" and r["draw"] == "independent" and r["index"] in plan["test"]
    ]
    assert len(rows) == 32

    def delta(r, metric):
        return (
            value(r["scores"]["matching"], scales.get("matching", 1))[metric]
            - value(r["scores"]["uniform"], scales.get("uniform", 1))[metric]
        )

    ordering = sorted(rows, key=lambda r: delta(r, "increment"))
    choices = [
        (ordering[0], 0, "Largest held-out improvement against uniform strength."),
        (ordering[-1], 0, "Largest held-out regression against uniform strength."),
        (
            max(rows, key=lambda r: delta(r, "flat")),
            2,
            "Largest held-out increase in exact-flat error.",
        ),
    ]
    items = []
    for row, role, selector in choices:
        item, arrays, cached = inputs(lookup[row["id"]])
        result, _ = variants(model, threshold, item, arrays, cached)
        corrected = scaled(result, scales)
        fields = {
            k: arrays[k][role : role + 1] if k in ("packed", "variance") else arrays[k][None]
            for k in ARGS
        }
        names = tuple(LABELS)
        values = [
            noisy_malvar(fields)[0],
            *[corrected[k][role] for k in names],
            arrays["target"][role],
        ]
        source = panel["rows"][item["case"]]
        items.append(
            native_board(
                output,
                f"{item['id']}-role{role}",
                values,
                fields,
                {
                    "case": lookup[row["id"]]["source"],
                    "source": source["source"],
                    "query_box": item["box"],
                    "pattern": source["camera"]["pattern"],
                    "noise": item["profile"],
                    "selected": selector,
                    "role": role,
                },
                labels=("Noisy Malvar", *LABELS.values(), "Exact GT"),
                triplet_indices=(0, names.index("matching") + 1, len(values) - 1),
                exposure=1 / item["profile"]["exposure"],
                contrast=2,
                roi=tuple(panel["native_display_ROI_xywh"]),
            )
        )
    return items


def camera(model, threshold, scales, output):
    template = ROOT.parent / "expanded-scene-12000-native-v1/plan.json"
    specs = read_json(template)
    main = read_json(checked(specs["main_full_RAW"]))
    mesh = read_json(checked(specs["mesh_full_RAW"]))
    assert main["noisy"].startswith(".cache/")
    raw_paths = {"gfx": Path(main["noisy"]).resolve(), "mesh": checked(mesh["sources"]["noisy"])}
    meshes = {}
    metadata = {}
    for family, path in raw_paths.items():
        assert "/.cache/" in str(path)
        raw, metadata[family] = read_raw(path)
        meshes[family] = torch.from_numpy(raw)
    grids = {}
    case_by_key = {}
    summaries = {}
    for sample in specs["observations"]:
        if sample["kind"] == "development":
            continue
        family = sample["kind"]
        raw = meshes[family]
        box = sample["metadata"]["context_xywh"] if family == "gfx" else mesh["raw_context_xywh"]
        noise = sample["noise"]
        with np.load(checked(sample["arrays"]), allow_pickle=False) as z:
            expected = {k: z[k] for k in ARGS}
        x, y, w, h = box
        view = pack(raw[None, None, y : y + h, x : x + w])
        assert fingerprint(view) == sample["input_fingerprints"]["packed"]
        assert np.array_equal(view.numpy(), expected["packed"])
        measured_colors = color_indices(metadata[family].pattern)
        assert torch.equal(measured_colors, torch.from_numpy(expected["colors"][0]))
        exact = (family, noise["shot"], noise["read"])
        if exact not in grids:
            complete = pack(raw[None, None])[0]
            compressed = summarize(complete, measured_colors, noise["shot"], noise["read"])
            grids[exact] = type(compressed)(compressed.appearance.cuda(), compressed.power.cuda())
        keys = tuple(sample["input_fingerprints"][k]["sha256"] for k in ("packed", "variance"))
        case_by_key[keys] = (box, noise, exact, sample["id"])
    del meshes

    def reconstruct(model, args, parents, thresholds):
        keys = tuple(fingerprint(a.cpu())["sha256"] for a in args[:2])
        box, noise, tag, name = case_by_key[keys]
        parent = (
            torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
        )
        base, lift = local_paths(model, args, parent, thresholds)
        gain = gates(args[0], args[2][0], noise["shot"], noise["read"], box, grids[tag])
        result = {"100k": parent, "quiet": base, "uniform": base + scales.get("uniform", 1) * lift}
        result.update({k: base + scales.get(k, 1) * weight * lift for k, weight in gain.items()})
        summaries[name] = {
            "absolute_query_xywh": box,
            "noise": noise,
            "field": tag[0],
            "mean_gate": {k: float(g.mean()) for k, g in gain.items()},
        }
        return {k: v.cpu().numpy() for k, v in result.items()}

    render_repeat.predictions = reconstruct
    render_repeat.SHOW = ("uniform", "local", "matching", "mirrored")
    render_repeat.DISPLAY = LABELS
    views = render_repeat.show_camera(model, threshold, output)
    return views, {key: reference(path) for key, path in raw_paths.items()}, summaries


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    numerical = reference(ROOT / "result.json")
    report = read_json(checked(numerical))
    plan = read_json(checked(report["plan"]))
    assert plan["driver"] == reference(ROOT / "collect.py")
    scales = report["metrics"]["iso6400"]["scales"]
    model, limits = bind_models(read_json(checked(plan["frozen_composition"])))
    out = ROOT / "native"
    out.mkdir()
    with ieee_fp32():
        photos = exact(model, limits, report, plan, scales, out)
        standing, raw_paths, local = camera(model, limits, scales, out)
    write_json(
        out / "render.json",
        {
            "numeric": numerical,
            "photos": photos,
            "standing": standing,
            "raw_source": raw_paths,
            "actual_native_viewing_complete": False,
            "coefficient": scales,
            "standing_query": local,
            "driver": reference(__file__),
        },
    )


if __name__ == "__main__":
    run()
