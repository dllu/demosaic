"""Verify the null energy, signal sensitivity, and context exclusion."""
from pathlib import Path
import torch
from context_strength import summarize, gates, _positions, _outside
from demosaic.experiments.artifacts import reference, write_json

torch.set_num_threads(2)
noise_variance = .00025
generator = torch.Generator().manual_seed(24935)
channels = torch.tensor([0,1,1,2])
white = torch.randn(32,4,128,128,generator=generator)*noise_variance**.5+.2
view = summarize(white, channels, 0, noise_variance)
mean = float(view.power.mean())
assert abs(mean) < .035
x = torch.arange(128)
pattern = ((x // 4 % 2)*2-1)*.025
wires = white+pattern[None,None,None,:]
texture = float(summarize(wires,channels,0,noise_variance).power.mean())
assert texture > 5
scene = torch.randn(4,320,352,generator=generator)*noise_variance**.5+.2
box = (128,160,256,256)
outer = summarize(scene,channels,0,noise_variance)
window = scene[None, :,80:208,64:192].clone()
base = gates(window,channels,0,noise_variance,box,outer)
# Assign extreme other values to the query and all its native 16-pixel halo.
later = scene.clone()
later[:,72:216,56:200] = .8
new = summarize(later,channels,0,noise_variance)
same = gates(window,channels,0,noise_variance,box,new)
assert all(torch.equal(base[key],same[key]) for key in base)
# Small boundary scene offers no external support and must fall back to local.
tiny = summarize(window[0],channels,0,noise_variance)
again = gates(window,channels,0,noise_variance,(0,0,256,256),tiny)
assert torch.equal(again["local"],again["matching"]) and torch.equal(again["local"],again["mirrored"])
path=Path(__file__).resolve()
write_json(path.parent/"physical-checks.json",{
    "test":reference(path),"constant_gaussian_null_mean":mean,"planted_pattern_mean":texture,
    "query_and_halo_excluded_from_both_views":True,"empty_exterior_matches_local_exactly":True,
    "null_cell_count":view.power.numel(),
})
print(mean,texture)
