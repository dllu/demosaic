"""Estimate a texture-strength prior from green RAW power outside the query."""

from dataclasses import dataclass
import math

import torch
from torch.nn import functional as F

CELL = 16


@dataclass(frozen=True)
class Grid:
    appearance: torch.Tensor
    power: torch.Tensor


def summarize(packed, colors, shot, read):
    """One 16-native-pixel cell records color and three debiased Haar energies."""
    if packed.shape[-3] != 4 or min(packed.shape[-2:]) < 8:
        raise ValueError("Require packed Bayer data spanning at least one native cell")
    means = F.avg_pool2d(packed, kernel_size=4, stride=4)
    h, w = (v // 2 * 2 for v in means.shape[-2:])
    means = means[..., :h, :w]
    pooled = F.avg_pool2d(means, 2)
    order = torch.argsort(colors, stable=True)
    red, green_a, green_b, blue = pooled[..., order, :, :].unbind(dim=-3)
    green = (green_a + green_b) * 0.5
    denominator = 0.03 + green.clamp_min(0)
    features = torch.stack(
        (
            (0.015 + green.clamp_min(0)).log(),
            ((red - green) / denominator).clamp(-3, 3),
            ((blue - green) / denominator).clamp(-3, 3),
        ),
        dim=-3,
    )
    across_green = means[..., order[1], :, :] + means[..., order[2], :, :]
    a, b = across_green[..., ::2, ::2], across_green[..., ::2, 1::2]
    c, d = across_green[..., 1::2, ::2], across_green[..., 1::2, 1::2]
    # The common-green average and an orthonormal 2x2 contrast each contribute .5.
    energy = ((a + b - c - d).square() + (a - b + c - d).square() + (a - b - c + d).square()) / 48
    # Two green sites averaged across sixteen packed cells per subblock.
    expected = (shot * green.clamp(0, 1) + read) / 32
    power = (energy / expected.clamp_min(1e-10) - 1).clamp(-1, 12)
    return Grid(features, power)


def _gain(score):
    excess = score.clamp_min(0)
    return 0.25 + 0.75 * excess / (excess + 2.0)


def _positions(height, width, device):
    y = torch.arange(height, device=device) * CELL + CELL / 2
    x = torch.arange(width, device=device) * CELL + CELL / 2
    return torch.stack(torch.meshgrid(y, x, indexing="ij"), dim=-1)


def _outside(positions, box):
    x, y, w, h = box
    yy, xx = positions.unbind(dim=-1)
    # Query halo is 16 pixels; scene cells themselves extend eight pixels.
    margin = CELL * 1.5
    return (xx <= x - margin) | (xx >= x + w + margin) | (yy <= y - margin) | (yy >= y + h + margin)


def _distant(local, surroundings, box):
    device = local.power.device
    h, w = surroundings.power.shape
    positions = _positions(h, w, device)
    outside = _outside(positions, box)
    eligible = outside & outside.flip((-2, -1))
    if not eligible.any():
        return torch.zeros_like(local.power).expand(2, *local.power.shape)
    step = max(1, math.ceil(math.sqrt(int(eligible.sum()) / 4096)))
    points = eligible.nonzero()[:: step * step]
    yy, xx = points.unbind(dim=-1)
    nearby = positions[yy, xx]
    query = _positions(*local.power.shape[-2:], device)
    query = query + query.new_tensor([box[1], box[0]])
    distance = torch.cdist(query.reshape(-1, 2), nearby)
    scale = min(512, max(144, 0.28 * CELL * min(h, w)))
    spatial = -0.5 * (distance / scale).square()
    color_scale = query.new_tensor([0.35, 0.25, 0.25])
    query_color = local.appearance.movedim(-3, -1).reshape(local.power.shape[0], -1, 3)
    result = []
    for mirrored in (False, True):
        src_y, src_x = (h - 1 - yy, w - 1 - xx) if mirrored else (yy, xx)
        color = surroundings.appearance[:, src_y, src_x].T
        cost = torch.cdist(query_color / color_scale, color / color_scale).square()
        weights = (spatial - 0.5 * cost).exp()
        coverage = weights.sum(dim=-1)
        estimate = (weights @ surroundings.power[src_y, src_x]) / coverage.clamp_min(1e-8)
        confidence = (coverage / (coverage + 12)).clamp(0, 1)
        result.append(((2 * _gain(estimate) - 1) * confidence).reshape_as(local.power))
    return torch.stack(result, dim=0)


def gates(raw, colors, shot, read, box, outer):
    local = summarize(raw, colors, shot, read)
    smooth = F.avg_pool2d(local.power[:, None], 3, stride=1, padding=1, count_include_pad=False)
    base = _gain(smooth)
    matched, mirrored = _distant(local, outer, box)
    all_gates = {
        "local": base,
        "matching": (base * (1 + 0.5 * matched[:, None])).clamp(max=1),
        "mirrored": (base * (1 + 0.5 * mirrored[:, None])).clamp(max=1),
    }
    size = tuple(n * 2 for n in raw.shape[-2:])
    return {
        key: F.interpolate(value, size=size, mode="bilinear", align_corners=False)
        for key, value in all_gates.items()
    }
