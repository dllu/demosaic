"""Intervene on held-out RAW and score-only target arrays."""

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from verifier import inspect, templates
from diagnose import ROOT

fresh = reference("/mnt/external/demosaic/wire-blind-spot-v1/fresh/panel.json")
panel = read_json(checked(fresh))
torch.set_num_threads(2)
checks = []
UNCHANGED = (
    "outside_amplitude",
    "outside_z",
    "blend",
    "learned",
    "scored_pixels",
    "prediction_fingerprint",
    "influence_fingerprint",
)
for case in panel["rows"][:4]:
    with np.load(checked(case["draws"][0]["arrays"]), allow_pickle=False) as data:
        values = {k: data[k] for k in data.files}
    exact = inspect(values, case, case["profile"])
    y, x = np.indices(values["packed"].shape[-2:])
    _, _, radius = templates(case["geometry"], tuple(2 * k for k in y.shape))
    target = values | {"target": values["target"] * 0.8 + 0.001}
    reference_change = inspect(target, case, case["profile"])
    for role_before, role_after in zip(exact["roles"], reference_change["roles"], strict=True):
        for a, b in zip(role_before, role_after, strict=True):
            assert all(a[k] == b[k] for k in UNCHANGED)
            assert all(
                v == b["amplitude"][k] for k, v in a["amplitude"].items() if k != "exact_background"
            )
    assert abs(reference_change["true_amplitude"] / exact["true_amplitude"] - 0.8) < 1e-5
    for fold in (0, 1):
        mask = ((radius < 1) & (((y + x) % 2)[..., None] == fold)).transpose(2, 0, 1)
        altered = values["packed"].copy()
        altered[:, mask] = 0.75 - 0.5 * altered[:, mask]
        response = inspect(values | {"packed": altered}, case, case["profile"])
        for earlier, changed in zip(exact["roles"], response["roles"], strict=True):
            a, b = earlier[fold], changed[fold]
            assert all(a[k] == b[k] for k in UNCHANGED)
            assert a["amplitude"] != b["amplitude"]
        checks.append(
            dict(source=case["source"]["id"], fold=fold, tampered_sensor_samples=int(mask.sum()))
        )
write_json(
    ROOT / "isolation.json",
    {
        "fresh": fresh,
        "driver": reference(__file__),
        "checked_prediction_fields": UNCHANGED,
        "withheld_RAW_modified": checks,
        "operational_evidence_invariant_to_target_changes": True,
        "scope": "Same-fold background, score contrasts, exterior scale and blend selection are byte-identical when the validation samples inside the hole are replaced. Scores themselves change. The bidirectional average reuses A/B data and is an empirical estimator.",
    },
)
print(len(checks), "fold interventions")
