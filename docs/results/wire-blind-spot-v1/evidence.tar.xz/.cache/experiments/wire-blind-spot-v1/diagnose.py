"""Predict withheld Bayer sites and score a physically residualized wire template."""

from pathlib import Path
import argparse
import math
import time

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
DEFAULT = ROOT.with_name("local-continuing-wire-v1") / "double-gap-inputs/panel.json"
OFFSETS = tuple((dy, dx) for dy in range(-2, 3) for dx in range(-2, 3) if (dy + dx) % 2)
RIDGES = (0.0, 1.0, 10.0, 100.0)
METHODS = ("inner-affine", "exterior-affine", "neighbor", "blind-spot", "exact-bg")


def as_cells(native):
    h, w = native.shape[-2:]
    return (
        native.reshape(*native.shape[:-2], h // 2, 2, w // 2, 2)
        .swapaxes(-3, -2)
        .reshape(*native.shape[:-2], h // 2, w // 2, 4)
    )


def templates(wire, shape):
    y, x = np.indices(shape, dtype=float)
    x -= (shape[1] - 1) / 2
    y -= (shape[0] - 1) / 2
    dx, dy = x - wire["gap_center"][0], y - wire["gap_center"][1]
    a, b = wire["gap_axes"]
    c, s = math.cos(wire["gap_angle"]), math.sin(wire["gap_angle"])
    r = np.hypot((c * dx + s * dy) / a, (-s * dx + c * dy) / b)
    gap = np.clip((r - 1) * 2.5, 0, 1)
    carriers = []
    for theta, period, phase, width in zip(
        wire["angles"], wire["periods"], wire["phases"], wire["widths"], strict=True
    ):
        u = (math.cos(theta) * x + math.sin(theta) * y) / period + phase
        carriers.append(
            np.exp(-0.5 * ((u - np.rint(u)) / width) ** 2) - math.sqrt(math.tau) * width
        )
    border = np.clip((105 - np.maximum(abs(x), abs(y))) / 28, 0, 1)
    trend = [np.ones_like(x), dx / (2 * a), dy / (2 * b)]
    background = as_cells(np.stack([*trend, carriers[0] * gap, carriers[1] * gap * border]))
    wave = as_cells(carriers[0] * (1 - gap))
    return background.transpose(1, 2, 3, 0), wave, as_cells(r)


def neighbors(field):
    return np.concatenate([np.roll(field, (-dy, -dx), axis=(0, 1)) for dy, dx in OFFSETS], axis=2)


def matched(innovation, direction, weight):
    k = direction * weight
    norm = float(np.sum(direction * k))
    return (float(np.sum(innovation * k) / norm), norm) if norm > 1e-12 else (0.0, norm)


def exterior_background(y, design, ring, noise):
    coefs = []
    for p in range(4):
        matrix = design[ring, p]
        # The shot/read proxy is a per-phase scalar fitted from exterior A.
        coef, _, _, _ = np.linalg.lstsq(matrix / noise[p], y[ring, p] / noise[p], rcond=None)
        coefs.append(coef)
    return np.einsum("xyfd,fd->xyf", design, np.asarray(coefs))


def solve_predictor(X, Y, training, validation):
    a, b = X[training], Y[training]
    condition = a.T @ a / len(a)
    cross = a.T @ b / len(a)
    ev, vec = np.linalg.eigh(condition)
    proj = vec.T @ cross
    W = [vec @ (proj / np.maximum(ev[:, None] + k, 1e-8)) for k in RIDGES]
    report = [float(np.mean((X[validation] @ w - Y[validation]) ** 2)) for w in W]
    selected = int(np.argmin(report))
    # Freeze the model and regularizer selected on exterior cells.
    return W[selected], dict(ridge=RIDGES[selected], exterior_validation_MSE=report)


def analyze(data, case, profile):
    raw = data["packed"].transpose(0, 2, 3, 1).astype(float)
    shape = (raw.shape[1] * 2, raw.shape[2] * 2)
    design, wave, radius = templates(case["geometry"], shape)
    # A neutral working-space lift, with no clean amplitude or target pixels.
    wb, matrix, colors = data["wb"], data["matrix"], data["colors"]
    neutral = (np.linalg.solve(matrix.astype(float), np.ones(3)) / wb)[colors]
    phi = wave * neutral
    row, col = np.indices(raw.shape[1:3])
    parity = (row + col) % 2
    safe = (row >= 3) & (row < raw.shape[1] - 3) & (col >= 3) & (col < raw.shape[2] - 3)
    full_ring = (radius.min(2) > 1.45) & (radius.max(2) < 3.1) & safe
    # Keep the prediction-training stencil outside the entire changed region.
    far = (radius.min(2) > 1.55) & (radius.max(2) < 3.2) & safe
    far &= neighbors((radius.min(2) > 1.4)[..., None]).all(2)
    local = (radius < 1) & safe[..., None]
    test_support = [(local & (parity[..., None] == fold)) for fold in (0, 1)]
    Xphi = neighbors(phi)
    naive = np.zeros((4 * len(OFFSETS), 4))
    for k, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            naive[4 * k : 4 * (k + 1)] = np.eye(4) / 4
    output = []
    # Oracle measurements only enter the scoring stage.
    clean = (
        mosaic(torch.from_numpy(data["target"]), torch.from_numpy(colors))
        .numpy()
        .transpose(0, 2, 3, 1)
        .astype(float)
    )
    scale = float(np.sum((clean[0] - clean[1]) * phi) / np.sum(phi**2))
    assert scale > 0 and np.max(abs(clean[0] - clean[1] - phi * scale)) < 5e-6
    for role, y in enumerate(raw):
        role_results = {}
        for fold in (0, 1):
            ring = full_ring & (parity != fold)
            noise = np.sqrt(
                profile["shot"] * np.median(y[ring], axis=0).clip(min=0) + profile["read"]
            )
            expected = exterior_background(y, design, ring, noise)
            residual = (y - expected) / noise
            standardized_wave = phi / noise
            predictor_X = neighbors(residual)
            witness = far & (parity == fold)
            selector = (row // 5 + 2 * (col // 5)) % 4 == 0
            train, validate = witness & ~selector, witness & selector
            assert min(train.sum(), validate.sum()) > 50
            weights, selection = solve_predictor(predictor_X, residual, train, validate)
            dmask = test_support[fold]
            results = {}

            def score(key, innovation, direction):
                a, e = matched(innovation[dmask], direction[dmask], np.ones(dmask.sum()))
                results[key] = {
                    "amplitude": a / scale,
                    "power": e,
                    "noise_only_signal_scale": math.sqrt(e) * scale,
                }

            score("exterior-affine", residual, standardized_wave)
            for key, W in (("neighbor", naive), ("blind-spot", weights)):
                null_innovation = residual - predictor_X @ W
                response = standardized_wave - neighbors(standardized_wave) @ W
                score(key, null_innovation, response)
            # For disjoint scoring compare with the affine nuisance span on the same scored sites.
            p = np.broadcast_to(np.arange(4), y.shape)[dmask]
            A = (design[..., :3][dmask][:, None, :] * np.eye(4)[p, :, None]).reshape(-1, 12)
            Q, _ = np.linalg.qr(A, mode="reduced")
            s = standardized_wave[dmask]
            proj = s - Q @ (Q.T @ s)
            a, e = matched(y[dmask] / noise[p], proj, np.ones(len(p)))
            results["inner-affine"] = {
                "amplitude": a / scale,
                "power": e,
                "noise_only_signal_scale": math.sqrt(e) * scale,
            }
            background = clean[1] if role < 2 else clean[2]
            score("exact-bg", (y - background) / noise, standardized_wave)
            role_results[str(fold)] = {
                "fit": selection,
                "results": results,
                "scored_pixels": int(dmask.sum()),
            }
        output.append(role_results)
    return output


def summarize(rows):
    data = np.array(
        [
            [
                [
                    [view[role][str(fold)]["results"][method]["amplitude"] for role in range(3)]
                    for fold in (0, 1)
                ]
                for view in r["views"]
            ]
            for method in METHODS
            for r in rows
        ]
    ).reshape(len(METHODS), len(rows), -1, 2, 3)
    outputs = {}
    for method, block in zip(METHODS, data, strict=True):
        values = block.mean(2).reshape(-1, 3)
        outputs[method] = {
            "scored_draws": len(values),
            "true_above_half": int((values[:, 0] > 0.5).sum()),
            "double_above_half": int((values[:, 1] > 0.5).sum()),
            "flat_above_half": int((values[:, 2] > 0.5).sum()),
            "amplitude_median": np.median(values, axis=0).tolist(),
            "null_amplitude_RMS": np.sqrt(np.mean(values[:, 1:] ** 2, axis=0)).tolist(),
        }
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--panel", type=Path, default=DEFAULT)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(2)
    panel_ref = reference(args.panel)
    panel = read_json(checked(panel_ref))
    rows = []
    started = time.monotonic()
    for r in panel["rows"]:
        views = []
        for draw in r["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                values = {k: f[k] for k in f.files}
            assert fingerprint(values["target"]) == r["clean"]
            assert fingerprint(values["packed"]) == draw["packed"]
            views.append(analyze(values, r, panel["profile"]))
        rows.append({"source": r["source"]["id"], "CFA": r["CFA"], "views": views})
        print(r["index"], round(time.monotonic() - started, 2), flush=True)
    summary = summarize(rows)
    print(summary, flush=True)
    write_json(
        args.output,
        {
            "panel": panel_ref,
            "driver": reference(__file__),
            "rows": rows,
            "summary": summary,
            "scope": "Given exact waveform and support, compare quotients using a blind exterior-fit "
            "neighbor predictor. Both packed checkerboard directions scored and averaged "
            "with fixed equal weights. Ground truth is used only for score normalization "
            "and the exact-background oracle. All fits and predictions for the held-out "
            "hole exclude its validation samples.",
        },
    )


if __name__ == "__main__":
    main()
