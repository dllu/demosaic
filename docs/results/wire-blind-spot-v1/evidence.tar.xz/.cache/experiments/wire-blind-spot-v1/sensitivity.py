"""Stress estimated shapes with fixed signed half-bin errors in the supplied frequencies."""

from pathlib import Path
import math
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from diagnose import ROOT
from estimated_phase import inspect
from verifier import measure

FRESH = Path("/mnt/external/demosaic/wire-blind-spot-v1/fresh/panel.json")
OFFSETS = ("radial", "perpendicular")


def perturb(geometry, method, sign):
    angles, periods = [], []
    for i, (ang, per) in enumerate(zip(geometry["angles"], geometry["periods"], strict=True)):
        n = np.array([math.cos(ang), math.sin(ang)])
        offset = n if method == "radial" else np.array([-n[1], n[0]])
        candidate = n / per + sign * ((-1) ** i) * (0.5 / 256) * offset
        angles.append(math.atan2(candidate[1], candidate[0]))
        periods.append(1 / np.linalg.norm(candidate))
    return geometry | {"angles": angles, "periods": periods}


def main():
    torch.set_num_threads(2)
    panel_ref = reference(FRESH)
    panel = read_json(checked(panel_ref))
    tables = {method: [] for method in OFFSETS}
    audit = []
    start = time.monotonic()
    for c in panel["rows"]:
        rows = {key: [] for key in OFFSETS}
        for n, d in enumerate(c["draws"]):
            with np.load(checked(d["arrays"]), allow_pickle=False) as f:
                data = {k: f[k] for k in f.files}
            assert fingerprint(data["packed"]) == d["packed"]
            for method in OFFSETS:
                changes = perturb(c["geometry"], method, 1 if c["index"] % 2 == 0 else -1)
                rows[method].append(inspect(data, c | {"geometry": changes}, c["profile"]))
            if n == 0 and c["index"] < 4:
                control = inspect(data, c, c["profile"])
                artificial = c["geometry"] | {
                    "phases": [0.2, 0.8],
                    "widths": [0.3, 0.5],
                    "strengths": [0.03, 0.04],
                }
                altered = inspect(data, c | {"geometry": artificial}, c["profile"])
                assert control["roles"] == altered["roles"]
                assert control["true_amplitude"] != altered["true_amplitude"]
                audit.append(c["source"]["id"])
        for k, values in rows.items():
            tables[k].append(
                {
                    "source": c["source"]["id"],
                    "ISO": c["profile"]["iso"],
                    "CFA": c["CFA"],
                    "draws": values,
                }
            )
        if (c["index"] + 1) % 8 == 0:
            print(c["index"] + 1, round(time.monotonic() - start, 2), flush=True)
    summary = {
        method: {
            iso: measure([r for r in rows if r["ISO"] == iso]) for iso in ("ISO400", "ISO6400")
        }
        for method, rows in tables.items()
    }
    write_json(
        ROOT / "frequency-stress.json",
        {
            "panel": panel_ref,
            "driver": reference(__file__),
            "method": reference(Path(__file__).with_name("estimated_phase.py")),
            "tested_perturbation_bins": 0.5,
            "results": summary,
            "rows": tables,
            "exact_nominal_profile_leakage_audit_sources": audit,
            "scope": "Replay phase/width fitting after signed radial or perpendicular frequency perturbations. "
            "Geometry, pixels and noise condition match across arms. Same sources as the nominal-frequency test.",
        },
    )


if __name__ == "__main__":
    main()
