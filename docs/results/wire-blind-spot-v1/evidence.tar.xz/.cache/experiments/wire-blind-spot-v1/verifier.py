"""Verify a supplied RAW wire using affine and local-innovation contrasts."""

from pathlib import Path
import argparse
import math
import time

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from diagnose import DEFAULT, OFFSETS, neighbors, solve_predictor, templates

METHODS = (
    "inner_affine",
    "exterior_affine",
    "neighbor",
    "exterior_learned",
    "fixed_midpoint",
    "placebo_shrinkage",
    "exact_background",
)
THRESHOLDS = (0.25, 0.5, 0.75, 1.0, 1.25)
OUTSIDE_Z_THRESHOLD = 3.0
SHIFTS = tuple((dy, dx) for dy in range(-48, 49, 16) for dx in range(-48, 49, 16) if (dx or dy))


def fitted_exterior(y, design, ring, noise, neutral):
    coefficients, numerator, power = [], 0.0, 0.0
    for phase in range(4):
        x = design[ring, phase]
        b = y[ring, phase]
        coefficient = np.linalg.lstsq(x, b, rcond=None)[0]
        coefficients.append(coefficient)
        null = x[:, [0, 1, 2, 4]]
        q, _ = np.linalg.qr(null, mode="reduced")
        carrier = x[:, 3] * neutral[phase] / noise[phase]
        condition = carrier - q @ (q.T @ carrier)
        numerator += float(condition @ (b / noise[phase]))
        power += float(condition @ condition)
    assert power > 0
    return (
        np.einsum("xyfd,fd->xyf", design, np.asarray(coefficients)),
        numerator / power,
        numerator / math.sqrt(power),
    )


def normalize(signal):
    power = float(signal @ signal)
    if power <= 1e-12:
        raise ValueError("No energy retained in the provided waveform")
    return signal / power, power


def affine_contrast(design, wave, indexed):
    channels = indexed[2]
    columns = (design[indexed][:, None, :3] * np.eye(4)[channels, :, None]).reshape(-1, 12)
    q, _ = np.linalg.qr(columns, mode="reduced")
    phi = wave[indexed]
    return normalize(phi - q @ (q.T @ phi))


def select_shrinkage(y, innovation, index, outside, safe, contrast, neighbor):
    a, b = [], []
    yy, xx, cc = index
    h, w = outside.shape
    for dy, dx in SHIFTS:
        yi, xi = yy + dy, xx + dx
        if yi.min() < 0 or xi.min() < 0 or yi.max() >= h or xi.max() >= w:
            continue
        if not (outside[yi, xi] & safe[yi, xi]).all():
            continue
        a.append(float(contrast @ y[yi, xi, cc]))
        b.append(float(neighbor @ innovation[yi, xi, cc]))
    if len(a) < 3:
        return dict(blend=0.5, exterior_placebos=len(a), min_null_energy=None)
    a, b = np.array(a), np.array(b)
    change = b - a
    energy = change @ change
    blend = float(np.clip(-(a @ change) / max(energy, 1e-24), 0, 1))
    return dict(
        blend=blend,
        exterior_placebos=len(a),
        min_null_energy=float(np.mean((a + blend * change) ** 2)),
    )


def inspect(data, case, profile):
    raw = data["packed"].transpose(0, 2, 3, 1).astype(float)
    design, wave, radius = templates(case["geometry"], (raw.shape[1] * 2, raw.shape[2] * 2))
    wb, matrix, colors = (data[k] for k in ("wb", "matrix", "colors"))
    neutral = (np.linalg.solve(matrix.astype(float), np.ones(3)) / wb)[colors]
    shape = wave * neutral
    ys, xs = np.indices(raw.shape[1:3])
    parity = (ys + xs) % 2
    safe = (ys >= 3) & (ys < raw.shape[1] - 3) & (xs >= 3) & (xs < raw.shape[2] - 3)
    outside = (radius.min(2) > 1.4) & safe
    safe_stencil = neighbors(outside[..., None]).all(2)
    inner = radius < 1
    ring = outside & (radius.min(2) > 1.45) & (radius.max(2) < 3.1)
    far = outside & safe_stencil & (radius.min(2) > 1.55) & (radius.max(2) < 3.2)
    selector = (ys // 5 + 2 * (xs // 5)) % 4 == 0
    naive = np.zeros((4 * len(OFFSETS), 4))
    for n, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            naive[4 * n : 4 * (n + 1)] = np.eye(4) / 4
    clean = (
        mosaic(torch.from_numpy(data["target"]), torch.from_numpy(colors))
        .numpy()
        .transpose(0, 2, 3, 1)
        .astype(float)
    )
    signal = clean[0] - clean[1]
    true_scale = float(np.sum(signal * shape) / np.sum(shape**2))
    assert true_scale > 0 and np.max(abs(signal - true_scale * shape)) < 5e-6
    results = []
    for role, y in enumerate(raw):
        folds = []
        for fold in (0, 1):
            outer = ring & (parity != fold)
            noise = np.sqrt(
                profile["shot"] * np.median(y[outer], axis=0).clip(min=0) + profile["read"]
            )
            predicted, outer_scale, z = fitted_exterior(y, design, outer, noise, neutral)
            standardized = y / noise
            carrier = shape / noise
            resid = (y - predicted) / noise
            X = neighbors(resid)
            Xphi = neighbors(carrier)
            site = np.nonzero(inner & (parity[..., None] == fold) & safe[..., None])
            c_affine, _ = affine_contrast(design, carrier, site)
            c_exterior, _ = normalize(carrier[site])
            curve = standardized[site] @ c_affine
            residual = resid - X @ naive
            c_neighbor, _ = normalize((carrier - Xphi @ naive)[site])
            nearest = residual[site] @ c_neighbor
            witness = far & (parity == fold)
            train, valid = witness & ~selector, witness & selector
            assert min(train.sum(), valid.sum()) >= 25
            trained, learning = solve_predictor(X, resid, train, valid)
            c_trained, _ = normalize((carrier - Xphi @ trained)[site])
            blend = select_shrinkage(
                standardized, residual, site, outside, safe_stencil, c_affine, c_neighbor
            )
            alpha = blend["blend"]
            value = {
                "inner_affine": curve,
                "exterior_affine": resid[site] @ c_exterior,
                "neighbor": nearest,
                "exterior_learned": (resid - X @ trained)[site] @ c_trained,
                "fixed_midpoint": 0.5 * curve + 0.5 * nearest,
                "placebo_shrinkage": (1 - alpha) * curve + alpha * nearest,
                "exact_background": ((y - clean[1 if role < 2 else 2]) / noise)[site] @ c_exterior,
            }
            folds.append(
                dict(
                    amplitude={name: float(v) for name, v in value.items()},
                    outside_amplitude=outer_scale,
                    outside_z=z,
                    blend=blend,
                    learned=learning,
                    scored_pixels=len(site[0]),
                    prediction_fingerprint=fingerprint(
                        np.r_[predicted[site], (X @ naive)[site], (X @ trained)[site], alpha]
                    ),
                    influence_fingerprint=fingerprint(
                        np.r_[c_affine, c_exterior, c_neighbor, c_trained]
                    ),
                )
            )
        results.append(folds)
    return {"true_amplitude": true_scale, "roles": results}


def measure(rows):
    methods = {}
    for name in METHODS:
        fitted = np.array(
            [
                [
                    [np.mean([fold["amplitude"][name] for fold in role]) for role in draw["roles"]]
                    for draw in row["draws"]
                ]
                for row in rows
            ]
        )
        outside = np.array(
            [
                [
                    [
                        np.mean([fold["outside_amplitude"] for fold in role])
                        for role in draw["roles"]
                    ]
                    for draw in row["draws"]
                ]
                for row in rows
            ]
        )
        gate = np.array(
            [
                [
                    [
                        min(fold["outside_z"] for fold in role) >= OUTSIDE_Z_THRESHOLD
                        for role in draw["roles"]
                    ]
                    for draw in row["draws"]
                ]
                for row in rows
            ]
        )
        truth = np.array([[d["true_amplitude"] for d in r["draws"]] for r in rows])[:, :, None]
        response = fitted / truth
        decisions = {
            str(t): (gate & (outside > 0) & (fitted > t * outside)).sum(axis=(0, 1)).tolist()
            for t in THRESHOLDS
        }
        rng = np.random.default_rng(202611191607)
        idx = rng.integers(len(rows), size=(6500, len(rows)))
        null = np.mean(response[:, :, 1] ** 2, axis=1)
        methods[name] = dict(
            counts_known_amplitude=(response > 0.5).sum(axis=(0, 1)).tolist(),
            counts_exterior=decisions,
            pass_exterior_gate=gate.sum(axis=(0, 1)).tolist(),
            draws_per_role=response.shape[0] * response.shape[1],
            amplitude_median=np.median(response, axis=(0, 1)).tolist(),
            null_RMS=np.sqrt(np.mean(response[:, :, 1:] ** 2, axis=(0, 1))).tolist(),
            paired_response_pp=float(100 * np.mean(response[:, :, 0] - response[:, :, 1])),
            coherence_within_background=float(
                np.corrcoef(response[:, 0, 1], response[:, 1, 1])[0, 1]
            ),
            double_RMS_bootstrap_95=np.sqrt(
                np.quantile(null[idx].mean(1), (0.025, 0.975))
            ).tolist(),
        )
    return methods


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--panel", type=Path, default=DEFAULT)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(2)
    source = reference(args.panel)
    panel = read_json(checked(source))
    rows = []
    started = time.monotonic()
    for row in panel["rows"]:
        views = []
        profile = row.get("profile", panel.get("profile"))
        for draw in row["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as z:
                args_data = {k: z[k] for k in z.files}
            assert fingerprint(args_data["target"]) == row["clean"]
            assert fingerprint(args_data["packed"]) == draw["packed"]
            views.append(inspect(args_data, row, profile))
        rows.append(
            dict(
                source=row["source"]["id"],
                ISO=profile.get("iso", "ISO6400"),
                CFA=row["CFA"],
                draws=views,
            )
        )
        if (row["index"] + 1) % 8 == 0:
            print(row["index"] + 1, round(time.monotonic() - started, 2), flush=True)
    summary = {
        iso: measure([x for x in rows if x["ISO"] == iso])
        for iso in sorted({x["ISO"] for x in rows})
    }
    print(summary, flush=True)
    write_json(
        args.output,
        dict(
            panel=source,
            driver=reference(__file__),
            exterior_z=OUTSIDE_Z_THRESHOLD,
            components=reference(Path(__file__).with_name("diagnose.py")),
            summary=summary,
            rows=rows,
            seconds=time.monotonic() - started,
            roles=panel["roles"],
            scope="Supplied geometry and waveform. Predictivity and all fit "
            "options use only the indicated measured RAW sites. Score each held-out fold inside the "
            "hole then average the two folds. Truth normalizes the diagnostic half-amplitude count. "
            "The target-free count uses the independently estimated exterior scale and a fixed z gate.",
        ),
    )


if __name__ == "__main__":
    main()
