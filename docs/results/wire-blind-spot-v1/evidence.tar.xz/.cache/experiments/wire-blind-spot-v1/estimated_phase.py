"""Verify a supplied RAW wire using affine and local-innovation contrasts."""

from pathlib import Path
import argparse
import math
import time

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from diagnose import DEFAULT, OFFSETS, as_cells, neighbors, solve_predictor, templates
from verifier import (
    METHODS,
    OUTSIDE_Z_THRESHOLD,
    affine_contrast,
    fitted_exterior,
    measure,
    normalize,
    select_shrinkage,
)


def exterior_design(shape, geometry):
    y, x = np.indices(shape, dtype=float)
    x -= (shape[1] - 1) / 2
    y -= (shape[0] - 1) / 2
    basis = []
    for angle, period in zip(geometry["angles"], geometry["periods"], strict=True):
        phase = math.tau * (math.cos(angle) * x + math.sin(angle) * y) / period
        for harmonic in (1, 2):
            basis.extend((np.cos(harmonic * phase), np.sin(harmonic * phase)))
    return as_cells(np.stack(basis)).transpose(1, 2, 3, 0)


def fit_profile(raw, sinusoidal, trend, ring, noise, neutral):
    columns, response = [], []
    for phase in range(4):
        a = trend[ring, phase]
        q, _ = np.linalg.qr(a, mode="reduced")
        design = sinusoidal[ring, phase] * neutral[phase] / noise[phase]
        sample = raw[ring, phase] / noise[phase]
        columns.append(design - q @ (q.T @ design))
        response.append(sample - q @ (q.T @ sample))
    fit = np.linalg.lstsq(np.concatenate(columns), np.concatenate(response), rcond=None)[0]
    phase, width = [], []
    for c1, s1, c2, s2 in fit.reshape(2, 4):
        theta = math.atan2(-s1, c1)
        fundamental = max(math.hypot(c1, s1), 1e-12)
        second = c2 * math.cos(2 * theta) - s2 * math.sin(2 * theta)
        ratio = float(
            np.clip(
                second / fundamental,
                math.exp(-6 * math.pi**2 * 0.18**2),
                math.exp(-6 * math.pi**2 * 0.055**2),
            )
        )
        phase.append((theta / math.tau) % 1)
        width.append(math.sqrt(-math.log(ratio) / (6 * math.pi**2)))
    return {"phases": phase, "widths": width}


def inspect(data, case, profile):
    raw = data["packed"].transpose(0, 2, 3, 1).astype(float)
    shape_hw = (raw.shape[1] * 2, raw.shape[2] * 2)
    parameters = {
        k: case["geometry"][k] for k in ("angles", "periods", "gap_center", "gap_axes", "gap_angle")
    }
    skeleton = parameters | {"phases": (0.0, 0.0), "widths": (0.1, 0.1)}
    trend, _, radius = templates(skeleton, shape_hw)
    sinusoidal = exterior_design(shape_hw, parameters)
    wb, matrix, colors = (data[k] for k in ("wb", "matrix", "colors"))
    neutral = (np.linalg.solve(matrix.astype(float), np.ones(3)) / wb)[colors]
    ys, xs = np.indices(raw.shape[1:3])
    parity = (ys + xs) % 2
    safe = (ys >= 3) & (ys < raw.shape[1] - 3) & (xs >= 3) & (xs < raw.shape[2] - 3)
    outside = (radius.min(2) > 1.4) & safe
    safe_stencil = neighbors(outside[..., None]).all(2)
    inner = radius < 1
    ring = outside & (radius.min(2) > 1.45) & (radius.max(2) < 3.1)
    far = outside & safe_stencil & (radius.min(2) > 1.55) & (radius.max(2) < 3.2)
    selector = (ys // 5 + 2 * (xs // 5)) % 4 == 0
    naive = np.zeros((4 * len(OFFSETS), 4))
    for n, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            naive[4 * n : 4 * (n + 1)] = np.eye(4) / 4
    clean = (
        mosaic(torch.from_numpy(data["target"]), torch.from_numpy(colors))
        .numpy()
        .transpose(0, 2, 3, 1)
        .astype(float)
    )
    true_scale = case["geometry"]["strengths"][0] * profile["exposure"]
    results = []
    for role, y in enumerate(raw):
        folds = []
        for fold in (0, 1):
            outer = ring & (parity != fold)
            noise = np.sqrt(
                profile["shot"] * np.median(y[outer], axis=0).clip(min=0) + profile["read"]
            )
            fitted = fit_profile(y, sinusoidal, trend[..., :3], outer, noise, neutral)
            design, wave, _ = templates(parameters | fitted, shape_hw)
            shape = wave * neutral
            predicted, outer_scale, z = fitted_exterior(y, design, outer, noise, neutral)
            standardized = y / noise
            carrier = shape / noise
            resid = (y - predicted) / noise
            X = neighbors(resid)
            Xphi = neighbors(carrier)
            site = np.nonzero(inner & (parity[..., None] == fold) & safe[..., None])
            c_affine, _ = affine_contrast(design, carrier, site)
            c_exterior, _ = normalize(carrier[site])
            curve = standardized[site] @ c_affine
            residual = resid - X @ naive
            c_neighbor, _ = normalize((carrier - Xphi @ naive)[site])
            nearest = residual[site] @ c_neighbor
            witness = far & (parity == fold)
            train, valid = witness & ~selector, witness & selector
            assert min(train.sum(), valid.sum()) >= 25
            trained, learning = solve_predictor(X, resid, train, valid)
            c_trained, _ = normalize((carrier - Xphi @ trained)[site])
            blend = select_shrinkage(
                standardized, residual, site, outside, safe_stencil, c_affine, c_neighbor
            )
            alpha = blend["blend"]
            value = {
                "inner_affine": curve,
                "exterior_affine": resid[site] @ c_exterior,
                "neighbor": nearest,
                "exterior_learned": (resid - X @ trained)[site] @ c_trained,
                "fixed_midpoint": 0.5 * curve + 0.5 * nearest,
                "placebo_shrinkage": (1 - alpha) * curve + alpha * nearest,
                "exact_background": ((y - clean[1 if role < 2 else 2]) / noise)[site] @ c_exterior,
            }
            folds.append(
                dict(
                    amplitude={name: float(v) for name, v in value.items()},
                    outside_amplitude=outer_scale,
                    outside_z=z,
                    blend=blend,
                    learned=learning,
                    waveform=fitted,
                    scored_pixels=len(site[0]),
                    prediction_fingerprint=fingerprint(
                        np.r_[predicted[site], (X @ naive)[site], (X @ trained)[site], alpha]
                    ),
                    influence_fingerprint=fingerprint(
                        np.r_[c_affine, c_exterior, c_neighbor, c_trained]
                    ),
                )
            )
        results.append(folds)
    return {"true_amplitude": true_scale, "roles": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--panel", type=Path, default=DEFAULT)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(2)
    source = reference(args.panel)
    panel = read_json(checked(source))
    rows = []
    started = time.monotonic()
    for row in panel["rows"]:
        views = []
        profile = row.get("profile", panel.get("profile"))
        for draw in row["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as z:
                args_data = {k: z[k] for k in z.files}
            assert fingerprint(args_data["target"]) == row["clean"]
            assert fingerprint(args_data["packed"]) == draw["packed"]
            views.append(inspect(args_data, row, profile))
        rows.append(
            dict(
                source=row["source"]["id"],
                ISO=profile.get("iso", "ISO6400"),
                CFA=row["CFA"],
                draws=views,
            )
        )
        if (row["index"] + 1) % 8 == 0:
            print(row["index"] + 1, round(time.monotonic() - started, 2), flush=True)
    summary = {
        iso: measure([x for x in rows if x["ISO"] == iso])
        for iso in sorted({x["ISO"] for x in rows})
    }
    print(summary, flush=True)
    write_json(
        args.output,
        dict(
            panel=source,
            driver=reference(__file__),
            exterior_z=OUTSIDE_Z_THRESHOLD,
            components=[
                reference(Path(__file__).with_name(n)) for n in ("diagnose.py", "verifier.py")
            ],
            summary=summary,
            rows=rows,
            seconds=time.monotonic() - started,
            roles=panel["roles"],
            scope="Supplied nominal frequencies and gap coordinates. Phase and width estimated on exterior A. All fit "
            "options use only the indicated measured RAW sites. Score each held-out fold inside the "
            "hole then average the two folds. Truth normalizes the diagnostic half-amplitude count. "
            "The target-free count uses the fitted exterior scale and a fixed z gate.",
        ),
    )


if __name__ == "__main__":
    main()
