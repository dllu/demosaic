"""Replay fixed prior RAW proposals on both standing GFX families."""

import math
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
from diagnose import ROOT, OFFSETS, as_cells, neighbors, templates
from estimated_phase import exterior_design, fit_profile
from verifier import fitted_exterior, affine_contrast, normalize, select_shrinkage
from deliver import compose, read_arrays

EXPERIMENTS = ROOT.parent
PROPOSALS = EXPERIMENTS / "query-bayer-reserve-v1/proposals-camera.json"
OLD_ROOT = EXPERIMENTS / "local-phase-support-v1"
CONFIG = Path("configs/gfx-green-mesh-20231231.json")

import sys

sys.path.insert(0, str(EXPERIMENTS / "scene-mixture-upper-band-v1"))
from native import native_png, old_pixels


def score_fixed(data, settings, profile):
    y = data["packed"][0].transpose(1, 2, 0).astype(float)
    dims = (2 * y.shape[0], 2 * y.shape[1])
    neutral = (np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"])[
        data["colors"]
    ]
    trend, _, radius = templates(settings | {"phases": (0.0, 0.0), "widths": (0.1, 0.1)}, dims)
    sinusoidal = exterior_design(dims, settings)
    yy, xx = np.indices(y.shape[:2])
    parity = (yy + xx) % 2
    safe = (yy >= 3) & (yy < y.shape[0] - 3) & (xx >= 3) & (xx < y.shape[1] - 3)
    outside = (radius.min(2) > 1.4) & safe
    safe_stencil = neighbors(outside[..., None]).all(2)
    ring = outside & (radius.min(2) > 1.45) & (radius.max(2) < 3.1)
    inner = (radius < 1) & safe[..., None]
    nearest = np.zeros((4 * len(OFFSETS), 4))
    for j, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            nearest[4 * j : 4 * (j + 1)] = np.eye(4) / 4
    folds = []
    for fold in (0, 1):
        fit = ring & (parity != fold)
        noise = np.sqrt(profile["shot"] * np.median(y[fit], axis=0).clip(min=0) + profile["read"])
        learned = fit_profile(y, sinusoidal, trend[..., :3], fit, noise, neutral)
        design, wave, _ = templates(settings | learned, dims)
        # In the real query the competing direction can also cross the aperture.
        ny, nx = np.indices(dims, dtype=float)
        nx -= (dims[1] - 1) / 2
        ny -= (dims[0] - 1) / 2
        u = (
            math.cos(settings["angles"][1]) * nx + math.sin(settings["angles"][1]) * ny
        ) / settings["periods"][1] + learned["phases"][1]
        width = learned["widths"][1]
        design[..., 4] = as_cells(
            np.exp(-0.5 * ((u - np.rint(u)) / width) ** 2) - math.sqrt(math.tau) * width
        )
        prediction, a_out, z_out = fitted_exterior(y, design, fit, noise, neutral)
        if (y[fit] >= 0.98).any():
            z_out = 0.0
        val = np.nonzero(inner & (parity[..., None] == fold))
        phi = wave * neutral / noise
        innovation = (y - prediction) / noise
        a, _ = affine_contrast(design, phi, val)
        d, _ = normalize((phi - neighbors(phi) @ nearest)[val])
        corrected = innovation - neighbors(innovation) @ nearest
        blend = select_shrinkage(innovation, corrected, val, outside, safe_stencil, a, d)
        t = blend["blend"]
        affine = innovation[val] @ a
        local = corrected[val] @ d
        folds.append(
            dict(
                waveform=learned,
                outside_amplitude=a_out,
                outside_z=z_out,
                blend=blend,
                amplitude={
                    "inner_affine": float(affine),
                    "neighbor": float(local),
                    "placebo_shrinkage": float((1 - t) * affine + t * local),
                },
            )
        )
    return {"roles": [folds]}


def native_display(rgb, data, roi, exposure):
    v = display_crop(
        torch.from_numpy(rgb),
        torch.from_numpy(data["wb"]),
        torch.from_numpy(data["matrix"]),
        roi,
        exposure=exposure,
    )
    return np.rint(np.clip(v, 0, 1) * 255).astype(np.uint8)


def main():
    torch.set_num_threads(2)
    proposal_ref = reference(PROPOSALS)
    proposed = read_json(checked(proposal_ref))
    native_ref = reference(OLD_ROOT / "review/native.json")
    config_ref = reference(OLD_ROOT / "configured/result.json")
    report = read_json(checked(native_ref))
    earlier = read_json(checked(report["previous"]))
    frozen_parent = read_json(checked(earlier["endpoint"]))["checkpoints"]["wire-aligned"]
    configured = {r["id"]: r for r in read_json(checked(config_ref))["boards"]}
    destination = ROOT / "camera-v2"
    destination.mkdir()
    records = []
    for row, p in zip(report["standing"], proposed["rows"], strict=True):
        ident = row["id"]
        assert ident == p["id"] and row["input"] == p["raw"]
        data = read_arrays(row["input"])
        parent = np.load(checked(row["previous_outputs"]["wire-aligned"]), allow_pickle=False)
        case_profile = row["noise"]
        x, y, w, h = p["fit_xywh"]
        assert (w, h) == (256, 256) and x % 2 == y % 2 == 0
        ps = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
        ws = np.s_[..., y : y + h, x : x + w]
        tile = {k: data[k][0] for k in ("colors", "wb", "matrix")} | {"packed": data["packed"][ps]}
        base_tile = parent[ws].copy()
        r = row["roi"]
        offset = r[0] + 80 - x - 128, r[1] + 80 - y - 128
        assert max(map(abs, offset)) <= 1
        # Preserve the existing nominations, including the explicit empty cases.
        peaks = p["methods"]["combined"]["peaks"]
        candidates = [pk["frequency_xy"] for pk in peaks]
        assert len(candidates) in (0, 2)
        sums = {
            label: np.zeros_like(base_tile) for label in ("Affine local lift", "Adapted local lift")
        }
        proposals = []
        for i, g in enumerate(candidates):
            paired = (g, candidates[1 - i])
            geometry = {
                "angles": [math.atan2(fy, fx) for fx, fy in paired],
                "periods": [1 / math.hypot(fx, fy) for fx, fy in paired],
                "gap_center": (0.0, 0.0),
                "gap_axes": (28.0, 28.0),
                "gap_angle": 0.0,
            }
            decision = score_fixed(tile, geometry, case_profile)
            result, amplitudes = compose(
                tile, base_tile, {"geometry": geometry, "profile": case_profile}, decision
            )
            for label, key in (
                ("Affine local lift", "inner_affine"),
                ("Adapted local lift", "placebo_shrinkage"),
            ):
                sums[label] += result[key] - base_tile
            proposals.append(
                {"frequency": g, "geometry": geometry, "scores": decision, "delivery": amplitudes}
            )
        predictions = {}
        for label, value in sums.items():
            view = parent.copy()
            view[ws] += value
            predictions[label] = view
        displays = []
        choices = [(row["exposure"], row["board"])]
        if ident in configured:
            c = configured[ident]
            choices.append((c["display_exposure"], c["board"]))
        for exposure, old in choices:
            fixed = old_pixels(old)
            np.testing.assert_array_equal(
                native_display(parent, data, r, exposure), fixed["Aligned control"]
            )
            columns = [
                (n, fixed[n])
                for n in (
                    "ISO6400 camera JPEG",
                    "Noisy (Malvar)",
                    "V120 EMA",
                    "Aligned control",
                    "Support only",
                )
                if n in fixed
            ]
            columns.extend(
                (label, native_display(image, data, r, exposure))
                for label, image in predictions.items()
            )
            columns.extend(
                (n, fixed[n]) for n in ("ISO100 AHD reference", "ISO100 camera JPEG") if n in fixed
            )
            path = destination / f"{ident}-x{exposure:g}.png"
            displays.append({"exposure": exposure, "board": native_png(path, columns)})
        ix, iy, iw, ih = r
        cut = np.s_[..., iy : iy + ih, ix : ix + iw]
        changes = {
            name: float(65535 * np.sqrt(np.mean((image[cut].astype(float) - parent[cut]) ** 2)))
            for name, image in predictions.items()
        }
        records.append(
            {
                "id": ident,
                "source": row["raw"],
                "input": row["input"],
                "noise": case_profile,
                "native_box": row["native_sensor_box"],
                "ROI_xywh": r,
                "fit_in_context": p["fit_xywh"],
                "ROI_center_minus_fit_center": offset,
                "predictions_parent": row["previous_outputs"]["wire-aligned"],
                "candidate_counts": len(candidates),
                "proposals": proposals,
                "rgb_RMS_DN16": changes,
                "displays": displays,
            }
        )
    assert len(records) == 8
    write_json(
        destination / "result.json",
        {
            "driver": reference(__file__),
            "proposal_source": proposal_ref,
            "prior_native": native_ref,
            "configured_refs": config_ref,
            "matched_parent": frozen_parent,
            "scope": "Fixed prior noisy-RAW nominations and a single predetermined circular aperture. "
            "Nominations used samples which can overlap both of the current folds. "
            "This is a camera stress replay, with independent low-ISO qualitative references.",
            "rows": records,
        },
    )
    for record in records:
        print(record["id"], record["candidate_counts"], record["rgb_RMS_DN16"])


if __name__ == "__main__":
    main()
