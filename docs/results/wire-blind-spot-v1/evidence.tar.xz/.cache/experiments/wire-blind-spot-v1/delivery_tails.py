"""Show the actual redraws responsible for adverse output tails."""

from collections import defaultdict

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board
from deliver import ROOT, LABELS, POLICIES, compose, read_arrays, scores


def main():
    torch.set_num_threads(2)
    delivery = reference(ROOT / "delivery/result.json")
    summary = read_json(checked(delivery))
    p = read_json(checked(summary["parent"]))
    detector = read_json(checked(summary["detection"]))
    panel = read_json(checked(summary["panel"]))
    selected = []
    for metric, role in (("continuing_gap_RMS_DN16", 0), ("false_strong_RMS_DN16", 1)):
        candidates = [r for r in summary["rows"] if r["ISO"] == "ISO6400"]
        row = max(
            candidates,
            key=lambda r: r["scores"]["placebo_shrinkage"][metric] - r["scores"]["aligned"][metric],
        )
        idx = row["index"]
        case = panel["rows"][idx]
        alternatives = []
        for n, ref in enumerate(case["draws"]):
            saved = p["cases"][idx]["draws"][n]
            assert saved["input"] == ref["arrays"]
            data = read_arrays(ref["arrays"])
            restored = read_arrays(saved["outputs"])
            decision = detector["rows"][idx]["draws"][n]
            rgb, _ = compose(data, restored["aligned"], case, decision)
            measures = {
                k: scores([v], data["target"], case, data) for k, v in (restored | rgb).items()
            }
            cost = measures["placebo_shrinkage"][metric] - measures["aligned"][metric]
            alternatives.append((cost, n, ref, data, restored, rgb, measures, decision))
        selected.append((role, metric, case, max(alternatives, key=lambda x: x[0])))
    out = ROOT / "delivery-tails"
    out.mkdir()
    paths = []
    for role, metric, case, (cost, n, ref, data, restored, rgb, measures, decision) in selected:
        index = case["index"]
        camera = {k: data[k][None] for k in ("wb", "matrix", "colors")} | {
            "packed": data["packed"][role : role + 1]
        }
        values = (
            noisy_malvar(camera)[0],
            *(restored[k][role] for k in ("v120", "aligned")),
            *(rgb[k][role] for k in POLICIES),
            data["target"][role],
        )
        rows = native_board(
            out,
            f"ISO6400-adverse-{index:02d}-draw{n}-role{role}",
            values,
            camera,
            dict(
                source=case["source"],
                query=case["crop"],
                camera=case["camera"],
                recipe=case["profile"],
                input=ref["arrays"],
                waveform=decision["roles"][role],
                role=panel["roles"][role],
                checkpoints=p["checkpoints"],
                metric=metric,
                change=cost,
                metrics=measures,
            ),
            labels=(
                "Noisy Malvar",
                LABELS["v120"],
                LABELS["aligned"],
                *(LABELS[k] for k in POLICIES),
                "Exact GT",
            ),
            triplet_indices=(0, 5, 6),
            exposure=2,
            roi=(48, 48, 160, 160),
        )
        paths.append(rows)
    write_json(
        out / "result.json", {"selection": delivery, "driver": reference(__file__), "boards": paths}
    )
    print([(p["id"], p["change"]) for p in paths])


if __name__ == "__main__":
    main()
