"""Publish the source-bound RAW verification and inference diagnostic."""

from datetime import datetime
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from diagnose import ROOT

OUT = Path("docs/results") / ROOT.name
IMAGE = Path("docs/images") / ROOT.name


def move_image(obj, folder):
    path = checked(obj["image"])
    dest = IMAGE / folder / path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, dest)
    assert reference(dest)["sha256"] == obj["image"]["sha256"]
    with Image.open(dest) as f:
        for p in obj["panels"]:
            x, y, w, h = p["png_xywh"]
            assert (
                (w, h) == (160, 160)
                and 0 <= x
                and 0 <= y
                and x + w <= f.width
                and y + h <= f.height
            )
    return obj | {"image": obj["image"] | {"path": str(dest.relative_to(IMAGE))}}


def main():
    refs = {
        key: reference(ROOT / name)
        for key, name in (
            ("development", "development-final.json"),
            ("development_phase", "estimated-development.json"),
            ("isolated", "isolation.json"),
            ("known_wave", "fresh-results.json"),
            ("detected", "estimated-fresh.json"),
            ("frequency_stress", "frequency-stress.json"),
            ("curves", "curves.json"),
            ("delivery", "delivery/result.json"),
            ("adverse", "delivery-tails/result.json"),
            ("real", "camera-v2/result.json"),
            ("viewing", "viewing.json"),
        )
    }
    documents = {name: read_json(checked(r)) for name, r in refs.items()}
    observed = documents["viewing"]
    assert all(observed[k] == refs[k] for k in ("delivery", "adverse"))
    assert observed["camera"] == refs["real"] and observed["curve_viewed"]
    fresh = documents["detected"]["panel"]
    assert all(
        documents[k]["panel"] == fresh for k in ("known_wave", "delivery", "frequency_stress")
    )
    assert documents["isolated"]["fresh"] == fresh
    parent = documents["delivery"]["parent"]
    completed = read_json(checked(parent))
    panel = read_json(checked(fresh))
    assert len(panel["rows"]) == len(completed["cases"]) == 64
    assert completed["panel"] == fresh and documents["delivery"]["detection"] == refs["detected"]
    assert completed["checkpoints"] == documents["delivery"]["checkpoints"]
    assert completed["checkpoints"]["aligned"] == documents["real"]["matched_parent"]
    assert documents["adverse"]["selection"] == refs["delivery"]
    scope = {
        "training_completed": False,
        "inference_replay_complete": True,
        "fixed_427_complete": False,
        "supplied_nominal_frequency_and_aperture": True,
        "native_exact_and_standing_view_complete": True,
        "real_reference": "Independent low-ISO AHD and camera JPEG reference captures.",
    }
    images = {}
    for key in ("delivery", "adverse"):
        products = [
            b | {slot: move_image(b[slot], "exact") for slot in ("board", "triplet")}
            for b in documents[key]["boards"]
        ]
        note = "exact_boards" if key == "delivery" else "adverse_draws"
        assert set(observed[note]) == {r["id"] for r in products}
        images[key] = products
    assert len(images["delivery"]) == 6 and len(images["adverse"]) == 2
    images["real"] = [
        r | {"displays": [d | {"board": move_image(d["board"], "standing")} for d in r["displays"]]}
        for r in documents["real"]["rows"]
    ]
    assert len(images["real"]) == 8 and sum(len(r["displays"]) for r in images["real"]) == 12
    assert {r["id"] for r in images["real"]} == set(observed["standing"])
    plots = []
    for p in documents["curves"]["plots"]:
        path = checked(p)
        dest = IMAGE / path.name
        shutil.copyfile(path, dest)
        assert reference(dest)["sha256"] == p["sha256"]
        plots.append(p | {"path": dest.name})
    images["plots"] = plots
    manifest = IMAGE / "manifest.json"
    write_json(
        manifest,
        images
        | {
            "scope": scope,
            "binding": refs,
            "parent": parent,
            "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        },
    )
    OUT.mkdir(parents=True, exist_ok=True)
    archive = OUT / "evidence.tar.xz"
    pending = [
        *refs.values(),
        fresh,
        panel["plan"],
        parent,
        reference(manifest),
        *(reference(p) for p in sorted(ROOT.glob("*.py"))),
        reference(Path("scripts/train_local_paired_continuation.py")),
        reference(Path("scripts/report_scene_wave_guides.py")),
        *(
            reference(ROOT / n)
            for n in (
                "development.json",
                "development-verified.json",
                "restore.log",
                "restore-review.log",
                "delivery.log",
                "stress.log",
            )
        ),
    ]
    external = Path("/mnt/external/demosaic/wire-blind-spot-v1")
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for binding in {p["path"]: p for p in pending}.values():
            path = checked(binding)
            name = (
                path.relative_to(Path.cwd())
                if path.is_relative_to(Path.cwd())
                else Path("external") / path.relative_to(external)
            )
            tar.add(path, arcname=str(name), recursive=False)
    write_json(
        OUT / "publication.json",
        {
            "archive": reference(archive),
            "manifest": reference(manifest),
            "receipts": refs,
            "data": fresh,
            "parent": parent,
            "scope": scope,
            "checkpoints": completed["checkpoints"],
            "phase_estimated": documents["detected"]["summary"],
            "exact_profile": documents["known_wave"]["summary"],
            "phase_stress": documents["frequency_stress"]["results"],
            "delivery": documents["delivery"]["summary"],
            "decision_differences": {
                p: {
                    iso: {k: v | {"curve_values_in_archive": True} for k, v in methods.items()}
                    for iso, methods in values.items()
                }
                for p, values in documents["curves"]["series"].items()
            },
            "standing_RMS": {p["id"]: p["rgb_RMS_DN16"] for p in images["real"]},
            "replay_seconds": {
                "parent_forward_stage": completed["seconds"],
                "verified_delivery_scoring": documents["delivery"]["seconds"],
            },
            "development_correction": "Corrected the exact-background oracle's target role in a new driver. "
            "The initial receipt is archived with the original driver. The other methods are unchanged.",
        },
    )


if __name__ == "__main__":
    main()
