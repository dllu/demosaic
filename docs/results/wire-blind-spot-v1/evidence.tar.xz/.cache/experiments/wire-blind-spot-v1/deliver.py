"""Compare bounded verified lifts through the frozen aligned-control restorer."""

from collections import defaultdict
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board
from diagnose import ROOT, OFFSETS, neighbors, templates
from verifier import OUTSIDE_Z_THRESHOLD, affine_contrast, normalize

PARENT = Path("/mnt/external/demosaic/wire-blind-spot-v1/parent-v2/completed.json")
POLICIES = ("inner_affine", "neighbor", "placebo_shrinkage")
LABELS = {
    "v120": "V120 EMA",
    "aligned": "Aligned control",
    "inner_affine": "Affine evidence",
    "neighbor": "Neighbor evidence",
    "placebo_shrinkage": "Adapted evidence",
}


def read_arrays(binding):
    with np.load(checked(binding), allow_pickle=False) as f:
        return {k: f[k] for k in f.files}


def compose(data, base, case, decision):
    def square(rgb):
        return (
            mosaic(torch.from_numpy(rgb), torch.from_numpy(data["colors"]))
            .numpy()
            .transpose(0, 2, 3, 1)
        )

    working_direction = np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"]
    neutral = working_direction[data["colors"]]
    raw = data["packed"].transpose(0, 2, 3, 1).astype(float)
    difference = raw - square(base).astype(float)
    shape_hw = base.shape[-2:]
    settings = {
        k: case["geometry"][k] for k in ("angles", "periods", "gap_center", "gap_axes", "gap_angle")
    }
    _, _, radius = templates(settings | {"phases": (0, 0), "widths": (0.1, 0.1)}, shape_hw)
    y, x = np.indices(raw.shape[1:3])
    parity = (y + x) % 2
    safe = (y >= 3) & (x >= 3) & (y < raw.shape[1] - 3) & (x < raw.shape[2] - 3)
    ring = (radius.min(2) > 1.45) & (radius.max(2) < 3.1) & safe
    inner = (radius < 1) & safe[..., None]
    nearest = np.zeros((4 * len(OFFSETS), 4))
    for i, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            nearest[4 * i : 4 * i + 4] = np.eye(4) / 4
    output = {method: base.copy() for method in POLICIES}
    receipt = {method: [] for method in POLICIES}
    for role, (observed, delta, folds) in enumerate(
        zip(raw, difference, decision["roles"], strict=True)
    ):
        outer = np.mean([fold["outside_amplitude"] for fold in folds])
        qualified = min(fold["outside_z"] for fold in folds) >= OUTSIDE_Z_THRESHOLD and outer > 0
        responses, fields = [], []
        for fold, record in enumerate(folds):
            geometry = settings | record["waveform"]
            design, wave, _ = templates(geometry, shape_hw)
            outside = ring & (parity != fold)
            p = case["profile"]
            noise = np.sqrt(
                p["shot"] * np.median(observed[outside], axis=0).clip(min=0) + p["read"]
            )
            direction = wave * neutral / noise
            support = np.nonzero(inner & (parity[..., None] == fold))
            c_affine, _ = affine_contrast(design, direction, support)
            c_neighbor, _ = normalize((direction - neighbors(direction) @ nearest)[support])
            delta_noise = delta / noise
            affine = delta_noise[support] @ c_affine
            n = (delta_noise - neighbors(delta_noise) @ nearest)[support] @ c_neighbor
            alpha = record["blend"]["blend"]
            responses.append(
                {
                    "inner_affine": affine,
                    "neighbor": n,
                    "placebo_shrinkage": (1 - alpha) * affine + alpha * n,
                }
            )
            fields.append(
                wave.reshape(shape_hw[0] // 2, shape_hw[1] // 2, 2, 2)
                .transpose(0, 2, 1, 3)
                .reshape(shape_hw)
            )
        waveform = np.mean(fields, axis=0)
        # Preserve clipped sites and exclude them from the local verification footprint.
        qualified &= not bool(((observed >= 0.98) & (radius < 1.8)).any())
        for method in POLICIES:
            amplitude = np.mean([fold["amplitude"][method] for fold in folds])
            admissible = bool(qualified and amplitude > 0.5 * outer)
            residual = float(np.mean([row[method] for row in responses]))
            amount = float(np.clip(residual, 0, 0.5 * outer)) if admissible else 0.0
            output[method][role] = (
                base[role] + amount * working_direction[:, None, None] * waveform
            ).astype(np.float32)
            receipt[method].append(
                {"gate": admissible, "amplitude": amount, "sensor_deficit": residual}
            )
    return output, receipt


def luma(value, camera):
    return np.einsum(
        "...chw,c->...hw",
        value.astype(float),
        (np.array([0.2126, 0.7152, 0.0722]) @ camera["matrix"]) * camera["wb"],
    )


def scores(actual, target, case, camera):
    x = luma(np.stack(actual), camera)
    y = luma(target, camera)
    _, _, packed = templates(case["geometry"], target.shape[-2:])
    h, w = target.shape[-2:]
    gap = packed.reshape(h // 2, w // 2, 2, 2).transpose(0, 2, 1, 3).reshape(h, w) < 1
    direction = (y[0] - y[1])[gap]
    norm = direction @ direction
    waveform = direction / np.sqrt(norm * gap.sum())
    error = x - y
    signal = (x[:, 0] - x[:, 1])[:, gap]
    scale = 65535
    return {
        "strong_response_pp": float(100 * np.mean(signal @ direction) / norm),
        "continuing_gap_RMS_DN16": float(scale * np.sqrt(np.mean(error[:, 0, gap] ** 2))),
        "false_strong_RMS_DN16": float(
            scale * np.sqrt(np.mean((error[:, 1, gap] @ waveform) ** 2))
        ),
        "double_gap_RMS_DN16": float(scale * np.sqrt(np.mean(error[:, 1, gap] ** 2))),
        "flat_exact_RMS_DN16": float(scale * np.sqrt(np.mean(error[:, 2, 80:176, 80:176] ** 2))),
    }


def summarize(rows):
    rng = np.random.default_rng(202611191626)
    names = tuple(rows[0]["scores"])
    keys = tuple(rows[0]["scores"]["aligned"])
    samples = np.array([[[r["scores"][name][k] for k in keys] for name in names] for r in rows])
    indices = np.vstack((np.arange(len(rows)), rng.integers(len(rows), size=(6500, len(rows)))))
    estimate = samples[indices].mean(1)
    raw = {
        name: dict(zip(keys, val.tolist(), strict=True))
        for name, val in zip(names, estimate[0], strict=True)
    }
    comparisons = {}
    for cmp in ("aligned", "v120", "inner_affine", "neighbor"):
        change = estimate[:, names.index("placebo_shrinkage")] - estimate[:, names.index(cmp)]
        comparisons[cmp] = {
            key: {"delta": float(f[0]), "interval": np.quantile(f[1:], (0.025, 0.975)).tolist()}
            for key, f in zip(keys, change.T, strict=True)
        }
    return {"values": raw, "adapted_vs": comparisons, "sources": len(rows)}


def render(panel, rows, predictions, methods, output):
    boards = []
    for iso in ("ISO400", "ISO6400"):
        group = [r for r in rows if r["ISO"] == iso]
        gap = "continuing_gap_RMS_DN16"
        candidates = sorted(
            group, key=lambda r: r["scores"]["placebo_shrinkage"][gap] - r["scores"]["aligned"][gap]
        )
        for rank, ranked in (("best", candidates[0]), ("worst", candidates[-1])):
            index = ranked["index"]
            case = panel["rows"][index]
            verified = methods["rows"][index]["draws"][0]
            ref = predictions["cases"][index]["draws"][0]
            data = read_arrays(case["draws"][0]["arrays"])
            parents = read_arrays(ref["outputs"])
            output_rgb, _ = compose(data, parents["aligned"], case, verified)
            camera = {k: data[k][None] for k in ("colors", "wb", "matrix")} | {
                "packed": data["packed"][:1]
            }
            for role in (0, 1) if rank == "worst" else (0,):
                camera_role = camera | {"packed": data["packed"][role : role + 1]}
                scene = case["source"]
                views = (
                    noisy_malvar(camera_role)[0],
                    *(parents[k][role] for k in ("v120", "aligned")),
                    *(output_rgb[k][role] for k in POLICIES),
                    data["target"][role],
                )
                image = native_board(
                    output,
                    f"{iso}-{rank}-{index:02d}-role{role}",
                    views,
                    camera_role,
                    dict(
                        source=scene,
                        query=case["crop"],
                        camera=case["camera"],
                        recipe=case["profile"],
                        input=case["draws"][0]["arrays"],
                        base_predictions=ref["outputs"],
                        waveform=verified["roles"][role],
                        checkpoints=predictions["checkpoints"],
                        role=panel["roles"][role],
                    ),
                    labels=(
                        "Noisy Malvar",
                        LABELS["v120"],
                        LABELS["aligned"],
                        *(LABELS[k] for k in POLICIES),
                        "Exact GT",
                    ),
                    triplet_indices=(0, 5, 6),
                    exposure=2,
                    roi=(48, 48, 160, 160),
                )
                boards.append(image)
    return boards


def main():
    torch.set_num_threads(2)
    parent = reference(PARENT)
    predictions = read_json(checked(parent))
    panel = read_json(checked(predictions["panel"]))
    detected = reference(ROOT / "estimated-fresh.json")
    methods = read_json(checked(detected))
    assert methods["panel"] == predictions["panel"]
    out = ROOT / "delivery"
    out.mkdir()
    started = time.monotonic()
    rows = []
    for case, measures, restored in zip(
        panel["rows"], methods["rows"], predictions["cases"], strict=True
    ):
        assert case["source"]["id"] == measures["source"] == restored["source"]
        views = defaultdict(list)
        doses = []
        for ref, draw, decision in zip(
            case["draws"], restored["draws"], measures["draws"], strict=True
        ):
            assert ref["arrays"] == draw["input"]
            data = read_arrays(ref["arrays"])
            parents = read_arrays(draw["outputs"])
            updates, receipt = compose(data, parents["aligned"], case, decision)
            for key, value in (parents | updates).items():
                views[key].append(value)
            doses.append(receipt)
        rows.append(
            {
                "source": case["source"]["id"],
                "index": case["index"],
                "ISO": measures["ISO"],
                "scores": {
                    key: scores(values, data["target"], case, data) for key, values in views.items()
                },
                "delivered": doses,
            }
        )
        if len(rows) % 8 == 0:
            print(len(rows), round(time.monotonic() - started, 2), flush=True)
    table = {iso: summarize([r for r in rows if r["ISO"] == iso]) for iso in ("ISO400", "ISO6400")}
    boards = render(panel, rows, predictions, methods, out)
    write_json(
        out / "result.json",
        {
            "parent": parent,
            "detection": detected,
            "panel": predictions["panel"],
            "driver": reference(__file__),
            "checkpoints": predictions["checkpoints"],
            "summary": table,
            "rows": rows,
            "boards": boards,
            "seconds": time.monotonic() - started,
            "scope": "Inference diagnostic with supplied gap geometry and nominal frequencies. Bounded "
            "neutral lift from RAW-parent deficit through the same measured contrast. The physical "
            "variant takes one input frame. Estimate phase, width, gain and acceptance from the RAW.",
        },
    )


if __name__ == "__main__":
    main()
