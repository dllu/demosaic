"""Plot accepted continuations against false wires on fresh backgrounds."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from diagnose import ROOT

METHODS = {
    "inner_affine": "Affine",
    "neighbor": "Nearest same color",
    "placebo_shrinkage": "Adaptive blend",
}
COLORS = ("#376289", "#946444", "#167562")


def ratio(rows, method, cutoff):
    field = []
    for r in rows:
        draws = []
        for view in r["draws"]:
            roles = []
            for role in view["roles"]:
                valid = min(fold["outside_z"] for fold in role) >= cutoff
                scale = np.mean([fold["outside_amplitude"] for fold in role])
                amplitude = np.mean([fold["amplitude"][method] for fold in role])
                roles.append(float(amplitude / scale) if valid and scale > 0 else -np.inf)
            draws.append(roles)
        field.append(draws)
    return np.array(field)


def main():
    shape = {
        "RAW-estimated profile": reference(ROOT / "estimated-fresh.json"),
        "Supplied exact waveform": reference(ROOT / "fresh-results.json"),
    }
    thresholds = np.linspace(0.15, 1.55, 71)
    fig, axes = plt.subplots(1, 2, figsize=(9.3, 4.1), sharey=True, constrained_layout=True)
    data = {}
    for variant, source in shape.items():
        record = read_json(checked(source))
        examples = {}
        for iso, axis in zip(("ISO400", "ISO6400"), axes, strict=True):
            group = [r for r in record["rows"] if r["ISO"] == iso]
            fits = {m: ratio(group, m, record["exterior_z"]) for m in METHODS}
            rng = np.random.default_rng(202611191614)
            samples = rng.integers(len(group), size=(6500, len(group)))
            axis.set_title(iso)
            axis.set_xlabel("False continuations out of 64")
            axis.set_xlim(-0.8, 29)
            axis.set_ylim(13, 65)
            axis.grid(color="#e6e6e6", linewidth=0.7)
            series = {}
            for (method, title), color in zip(METHODS.items(), COLORS, strict=True):
                vals = fits[method]
                quant = np.sum(vals[None] > thresholds[:, None, None, None], axis=(1, 2))
                origin = (vals > 0.5).sum(axis=(0, 1))
                if variant == "RAW-estimated profile":
                    axis.plot(quant[:, 1], quant[:, 0], lw=2, color=color, label=title)
                    axis.scatter(
                        origin[1],
                        origin[0],
                        s=32,
                        facecolor=color,
                        edgecolor="white",
                        linewidth=0.7,
                        zorder=5,
                    )
                change = ((vals > 0.5).astype(float) - (fits["inner_affine"] > 0.5)).mean(1)
                interval = np.quantile(100 * change[samples].mean(1), [0.025, 0.975], axis=0).T
                series[method] = {
                    "curve": quant.tolist(),
                    "at_half": origin.tolist(),
                    "delta_rate_vs_affine_pp": (100 * change.mean(0)).tolist(),
                    "source_bootstrap_95_pp": interval.tolist(),
                }
            examples[iso] = series
        data[variant] = examples
    axes[0].set_ylabel("Accepted true continuations out of 64")
    axes[1].legend(frameon=False, loc="lower right")
    fig.suptitle("Fixed RAW candidates on 64 fresh backgrounds", fontsize=13)
    png = ROOT / "raw-admission.png"
    svg = ROOT / "raw-admission.svg"
    fig.savefig(png, dpi=175, facecolor="white")
    fig.savefig(svg, facecolor="white")
    plt.close(fig)
    write_json(
        ROOT / "curves.json",
        {
            "source": shape,
            "driver": reference(__file__),
            "plots": [reference(png), reference(svg)],
            "thresholds": thresholds.tolist(),
            "series": data,
            "scope": "Parent-independent scores. Ratios use fitted exterior amplitude. Filled points mark half-amplitude. Intervals resample photos, keeping both draws from each source.",
        },
    )


if __name__ == "__main__":
    main()
