"""Check whether sub-bin evidence can selectively restrict a fixed analytic lift."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
import sys

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import ROOT, measured
import evaluate_gap_head as base
from head_corrected_broad import LUMA, direct_fft, synthesis

CORE = np.s_[64:192, 64:192]
ROUTES = ("shared-gap", "integer-check", "refined-check")


def luma(rgb, cal):
    return np.einsum("c,chw->hw", LUMA, linear_rgb(rgb[None], cal)[0])


def guarded(raw, layout, noise, wb, matrix, parent, lifted):
    delta = lifted - parent
    if not np.any(delta):
        return {"integer-check": lifted, "refined-check": lifted}
    gain = np.linalg.solve(matrix, np.ones(3)) / wb
    light = luma(delta, {"wb": wb[None], "matrix": matrix[None]})
    spectrum = direct_fft(light)
    arms = {}
    for label in ("integer-check", "refined-check"):
        check = measured(raw, layout, noise, refine=label == "refined-check")
        signed = np.sinh(check.features[..., 2:6]).mean(axis=-1)
        # Conditional on the disjoint green phase, the standardized central
        # tests carry no signed positive expectation in an independent blank.
        passed = ((signed - .15) / .9).clip(0, 1)
        retained = synthesis((passed - 1) * spectrum)
        arms[label] = lifted + (gain[:,None,None] * retained).astype(lifted.dtype)
    return arms


def row(task, plan, scales=None):
    record = plan["sources"][task["index"]]
    r, refs = base.wire_inputs(task, None)
    settings = plan["profiles"][task["noise"]]
    parent, guide = refs["100k"], refs["shared-gap"]
    guarded_arms = {key: [] for key in ROUTES[1:]}
    for obs, cfa, wb, matrix, p, predicted in zip(r["packed"], r["colors"], r["wb"],
                                                 r["matrix"], parent, guide, strict=True):
        out = guarded(obs, cfa, settings, wb, matrix, p, predicted)
        for label, img in out.items():
            guarded_arms[label].append(img)
    guarded_arms = {k: np.stack(value) for k, value in guarded_arms.items()}
    for name, factor in (scales or {}).items():
        guarded_arms["uniform-at-" + name] = parent + np.float32(factor) * (guide - parent)
    actual = base.old.luma(r["target"], r)[..., CORE[0], CORE[1]]
    baseline = base.old.luma(parent, r)[..., CORE[0], CORE[1]]
    support = r["support"][CORE]
    intact, gap = support >= .97, support <= .01
    dip = (support <= .65) & (support > .01) if record["geometry"]["family"] in (
        "smooth-dip", "contrast-step") else np.zeros_like(gap)
    true = actual[0] - actual[1]
    variants = {}
    for label, estimated in (refs | guarded_arms).items():
        x = base.old.luma(estimated, r)[..., CORE[0], CORE[1]]
        inc = x[0] - x[1]
        delta = x - baseline
        dot, power = base.aligned(true[intact], inc[intact])
        d_dot, d_pow = base.aligned(true[dip], inc[dip])
        variants[label] = {"intact_rms":base.rms((inc-true)[intact]),
            "gap_added":base.rms(delta[0][gap]) if np.any(gap) else None,
            "gap_exact":base.rms((x[0]-actual[0])[gap]) if np.any(gap) else None,
            "gap_pair":base.rms((inc-true)[gap]) if np.any(gap) else None,
            "present_rms":base.rms(x[0]-actual[0]), "flat_added":base.rms(delta[3,8:-8,8:-8]),
            "weak_free_added":base.rms(delta[2]), "intact_dot":dot,"intact_power":power,
            "dip_dot":d_dot,"dip_power":d_pow}
    variants["matched"] = variants["shared-gap"]
    return {"source":record["source"]["id"],"id":f'{task["index"]:03d}-{task["noise"]}',
            "profile":task["noise"], "family":record["geometry"]["family"],
            "input":task["input"],"baseline":task["output"],"metrics":variants}


def panel(directory, scales=None):
    source, plan = [reference(directory/name) for name in ("fresh-gap.json","plan.json")]
    inputs = read_json(checked(source))
    settings = read_json(checked(plan))
    with ThreadPoolExecutor(3) as pool:
        rows = list(pool.map(partial(row, plan=settings, scales=scales),inputs["rows"]))
    groups = {iso: base.score_group([r for r in rows if r["profile"]==iso])
              for iso in sorted({r["profile"] for r in rows})}
    return {"source":source,"plan":plan,"rows":rows,"summary":groups}


if __name__=="__main__":
    before = panel(base.WIRE_TUNE)
    level = before["summary"]["iso6400"]
    scales = {k:level[k]["gap_added"]["mean"]/level["shared-gap"]["gap_added"]["mean"] for k in ROUTES[1:]}
    after = panel(base.WIRE_TEST, scales)
    write_json(ROOT/"analytic-guard-scores.json",{
       "driver":reference(__file__),"phase":reference(ROOT/"phase.py"),"scales":scales,
       "calibration":before,"held_out":after,
       "policy":"Luminance band gate on fixed shared Bayer gap restoration. Uniform control titrated on separate backgrounds."})
