"""Measure per-query CPU feature cost with a saved Bayer observation."""
from time import perf_counter

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import ROOT, measured
from witness_features import measured as integer

if __name__ == "__main__":
    bank = ROOT.parent / "query-exterior-colour-v1"
    collection = reference(bank / "fresh-gap.json")
    plan = reference(bank / "plan.json")
    tables = read_json(checked(plan))
    item = next(x for x in read_json(checked(collection))["rows"]
                if x["index"] == 12 and x["noise"] == "iso6400")
    with np.load(checked(item["input"]), allow_pickle=False) as stream:
        fields = (stream["packed"][0, :, 64:192, 64:192].copy(), stream["colors"][0],
                  tables["profiles"][item["noise"]])
    comparators = (("integer", integer), ("refined", measured))
    values = {name: [] for name, _ in comparators}
    for shutter in range(24):
        for name, compute in comparators[::(-1 if shutter % 2 else 1)]:
            start = perf_counter()
            compute(*fields)
            wall = perf_counter() - start
            if shutter >= 4:
                values[name].append(wall)
    write_json(ROOT / "feature-timings.json", {
        "driver": reference(__file__), "plan": plan, "case": item["input"], "samples": values,
        "median_seconds": {k: float(np.median(v)) for k, v in values.items()},
        "scope": "Single native 256-pixel query. Only CPU witness feature extraction. Alternating methods after four warmups.",
    })
