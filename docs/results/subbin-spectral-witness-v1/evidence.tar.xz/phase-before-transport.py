"""Fit sub-bin exterior green phase before checking disjoint local Bayer sites."""
from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np
from scipy.fft import fft2

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "learned-spectral-gaps-v1"
sys.path.insert(0, str(PARENT))
from witness_features import FX, FY, SUPPORTED, SIDE, XI, YI, WINDOW, unit, squares

NATIVE = 32
PACKED = NATIVE // 2
PAD = 64
OVERSAMPLE = PAD // PACKED
STEP = 1 / (2 * PAD)
RADIUS = OVERSAMPLE // 2
OFFSETS = np.asarray([(0, 0)] + sorted(
    [(y, x) for y in range(-RADIUS, RADIUS + 1) for x in range(-RADIUS, RADIUS + 1)
     if x or y],
    key=lambda v: (v[0] ** 2 + v[1] ** 2, *v),
))
BASE = np.stack((FY[SUPPORTED], FX[SUPPORTED]), axis=-1)
BINS = np.rint(BASE / STEP).astype(np.int64)[:, None, :] + OFFSETS[None, :, :]
FREQ = BINS * STEP
WIDTHS = tuple(BINS[..., k] % PAD for k in (0, 1))
ALLOWED = (np.linalg.norm(FREQ, axis=-1) <= .251) & (abs(FREQ).max(axis=-1) < .25)
PHASE = np.exp(2j * np.pi * NATIVE * FREQ).astype(np.complex64)
BAYER_OFFSETS = np.stack((np.arange(4) // 2, np.arange(4) % 2), axis=-1)
SHIFTS = np.exp(-2j * np.pi * np.einsum("ck,fok->cfo", BAYER_OFFSETS, FREQ)).astype(np.complex64)
PENALTY = .18 * np.sum(OFFSETS**2, axis=-1)[None, None, :]


@dataclass(frozen=True)
class Measurements:
    features: np.ndarray
    frequency: np.ndarray
    phase: np.ndarray
    exterior_z: np.ndarray
    offsets: np.ndarray


def neighborhood(vector, variance, phase_grid):
    """Transport the four disjoint neighboring windows to the center origin."""
    shape = (SIDE, SIDE, *vector.shape[1:])
    grid = vector.reshape(shape)
    variance = variance.reshape(SIDE, SIDE)
    total = np.zeros_like(grid)
    var = np.zeros_like(variance)
    for axis in (0, 1):
        g = np.swapaxes(grid, 0, axis)
        v = np.swapaxes(variance, 0, axis)
        out = np.swapaxes(total, 0, axis)
        ns = np.swapaxes(var, 0, axis)
        transport = phase_grid[..., axis]
        out[2:] += g[:-2] * transport
        out[:-2] += g[2:] * transport.conj()
        ns[2:] += v[:-2]
        ns[:-2] += v[2:]
    return total.reshape(vector.shape), var.ravel()


def measured(raw, layout, noise, *, refine=True):
    options = slice(None) if refine else slice(1)
    pixels = squares(raw, YI, XI).astype(np.float32)
    weight = WINDOW.astype(np.float32)
    average = (pixels * weight).sum(axis=(-1, -2)) / weight.sum()
    weighted = (pixels - average[..., None, None]) * weight
    dense = fft2(weighted, s=(PAD, PAD), workers=1) / PACKED
    iy, ix = (coords[:, options] for coords in WIDTHS)
    coeff = dense[..., iy, ix] * SHIFTS[..., options]
    variance = (noise["shot"] * average.clip(min=0) + noise["read"]).clip(min=2e-11)
    variance *= (weight**2).mean()
    sigma = np.sqrt(variance)
    green = np.flatnonzero(layout == 1)
    red, blue = (np.flatnonzero(layout == color)[0] for color in (0, 2))
    direct = coeff[:, green].mean(1)
    fused_variance = variance[:, green].sum(1) * .25
    vector, external_variance = neighborhood(direct, fused_variance, PHASE[:, options])
    exterior_power = abs(vector)**2 / external_variance[:, None, None].clip(min=4e-10)
    # The center samples are absent from frequency and phase selection.
    score = np.where(ALLOWED[:, options], exterior_power - PENALTY[..., options], -np.inf)
    choose = score.argmax(axis=-1)
    external = np.take_along_axis(vector, choose[..., None], axis=-1)[..., 0]
    ext_unit = unit(external)
    direct_bin = unit(direct[..., 0])
    tapped = np.take_along_axis(coeff, choose[:, None, :, None], axis=-1)[..., 0]
    measured_unit = unit(tapped[:, green].mean(1))
    at_selected = tapped / sigma[..., None]
    at_base = coeff[..., 0] / sigma[..., None]
    local_color = (at_base[:, [red, blue]] * direct_bin[:, None].conj()).real
    exterior_color = (at_selected[:, [red, blue]] * ext_unit[:, None].conj()).real
    exterior_green = (at_selected[:, green] * ext_unit[:, None].conj()).real
    strength = abs(external) / np.sqrt(external_variance[:, None]).clip(min=2e-5)
    agreement = (measured_unit * ext_unit.conj()).real
    features = np.concatenate((
        np.arcsinh(local_color).transpose(0, 2, 1),
        np.arcsinh(exterior_color).transpose(0, 2, 1),
        np.arcsinh(exterior_green).transpose(0, 2, 1),
        np.log1p(strength)[..., None], agreement[..., None],
    ), axis=-1).clip(-6, 6).astype(np.float32)
    frequency = FREQ[np.arange(len(BASE))[None], choose]
    return Measurements(features, frequency, ext_unit, strength, choose)
