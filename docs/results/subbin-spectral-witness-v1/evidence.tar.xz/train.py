"""Learn sub-bin witness features and a transported spectral proposal."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import PARENT, ROOT, measured
from train_gap_head import INPUTS, SEED, EPOCHS, PHOTOS, EXACT_FLAT, NATIVE_I, NATIVE_J, SYNTH
from train_gap_head import batch, choose_tiles, focal_energy, objective
from witness_features import WitnessHead
from models import TransportHead

TREATMENTS = ("refined", "refined-gap", "transport")


def compose_one(entry):
    row, binding, bases = entry
    recorded = read_json(checked(binding))
    assert recorded["index"] == row["index"]
    with np.load(checked(recorded["input"]), allow_pickle=False) as data:
        images, layouts = (data[k] for k in ("packed", "colors"))
        fields = [measured(mosaic, layout, row["noise"])
                  for mosaic, layout in zip(images, layouts, strict=True)]
    variance_scale = np.maximum(np.mean([f.noise for f in fields[:2]], axis=0), .002)
    witness = np.stack([f.features for f in fields])
    original = bases[..., 0, 0] + 1j * bases[..., 0, 1]
    proposal = np.stack([f.proposal(b, variance_scale) for f, b in zip(fields, original, strict=True)])
    proposal = np.stack((proposal.real, proposal.imag), axis=-1)
    assert np.isfinite(witness).all() and np.isfinite(proposal).all()
    return witness, proposal


def collect():
    prior = reference(PARENT / "observations.json")
    plan = read_json(checked(prior))
    records = read_json(checked(plan["plan"]))["batches"]
    frozen = reference(PARENT / "feature-cache.json")
    basis_path = checked(read_json(checked(frozen))["inputs"]["basis"])
    basis = np.load(basis_path, mmap_mode="r", allow_pickle=False)
    start = time.monotonic()
    stored = {}
    with ThreadPoolExecutor(3) as workers:
        for i, values in enumerate(workers.map(compose_one, zip(records, plan["rows"], basis, strict=True))):
            for key, row in zip(("witness", "proposal"), values, strict=True):
                if key not in stored:
                    stored[key] = np.lib.format.open_memmap(ROOT / f"{key}.npy", mode="w+",
                                                        dtype=np.float16, shape=(len(records), *row.shape))
                stored[key][i] = row
            if (i + 1) % 50 == 0:
                print(i + 1, round(time.monotonic() - start, 2), flush=True)
    for array in stored.values():
        array.flush()
    write_json(ROOT / "witness-cache.json", {"driver": reference(__file__), "observations": prior,
               "phase": reference(ROOT / "phase.py"), "frozen_inputs": frozen,
               "tensors": {k: reference(ROOT / f"{k}.npy") for k in stored},
               "shapes": {k: list(v.shape) for k,v in stored.items()}, "elapsed": time.monotonic() - start})


def train():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    device = "cuda"
    limit = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, 5 * 2**30 / limit))
    matched = reference(PARENT / "training/completed.json")
    control = read_json(checked(matched))
    standard = read_json(checked(control["cache"]))
    independent = reference(ROOT / "witness-cache.json")
    extra = read_json(checked(independent))
    rows = standard["counts"]["photos"]
    data = {k: np.load(checked(standard["inputs"][k]), allow_pickle=False, mmap_mode="r") for k in INPUTS}
    for k, pointer in extra["tensors"].items():
        data[k] = np.load(checked(pointer), allow_pickle=False, mmap_mode="r")
    integer = reference(PARENT / "training-witness/completed.json")
    prototype = WitnessHead().to(device)
    torch.manual_seed(SEED)
    transport = TransportHead().to(device)
    models = {"refined": deepcopy(prototype), "refined-gap": deepcopy(prototype), "transport": transport}
    ema = {name: deepcopy(net).requires_grad_(False) for name, net in models.items()}
    optimizer = torch.optim.AdamW([p for m in models.values() for p in m.parameters()], lr=.001, weight_decay=.001)
    coords = tuple(torch.as_tensor(k, device=device) for k in (NATIVE_I, NATIVE_J))
    taper = torch.as_tensor(SYNTH**2, device=device, dtype=torch.float32)
    step = 0
    budget = rows // PHOTOS * EPOCHS
    rng = np.random.default_rng(SEED)
    output = ROOT / "training"
    output.mkdir()
    start = time.monotonic()
    progress = []
    for epoch in range(EPOCHS):
        order = rng.permutation(rows)
        for i in range(0, rows, PHOTOS):
            indices = order[i:i + PHOTOS]
            selected = choose_tiles(rng, data["void_weight"], indices)
            arrays = batch(data, indices, selected, device)
            flat = torch.as_tensor(EXACT_FLAT[selected], device=device)
            weights = arrays["void"] * taper
            input_features = torch.cat((arrays["features"], arrays["witness"]), dim=-1)
            step += 1
            rate = .001 * step / 24 if step <= 24 else .0001 + .0009 * (.5 + .5 * np.cos(np.pi * (step - 24) / (budget - 24)))
            optimizer.param_groups[0]["lr"] = float(rate)
            optimizer.zero_grad(set_to_none=True)
            metric = {}
            for name, model in models.items():
                basis_values = arrays["basis"]
                if name == "transport":
                    basis_values = torch.cat((basis_values, arrays["proposal"][..., None, :]), dim=-2)
                pred = model(input_features, arrays["context"], basis_values)
                if step == 1:
                    assert not torch.any(pred)
                baseline, error, projection = objective(pred, arrays["target"], arrays["basis"][..., 0, :], flat)
                if name == "refined-gap":
                    loss = baseline + 3 * focal_energy(error[:, 0] - error[:, 1], weights, coords)
                    loss = loss + 1.5 * focal_energy(error[:, 0], weights, coords)
                else:
                    loss = baseline
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(tuple(model.parameters()), 2.0)
                if not torch.isfinite(norm):
                    raise FloatingPointError(step)
                metric[name] = torch.stack((loss, baseline, projection)).detach()
            optimizer.step()
            for name, model in models.items():
                with torch.no_grad():
                    torch._foreach_lerp_(tuple(ema[name].parameters()), tuple(model.parameters()), 0.01)
            if step % 48 == 0 or step in (1, budget):
                note = {k: value.cpu().tolist() for k, value in metric.items()}
                progress.append({"step": step, "loss": note})
                print(step, round(time.monotonic() - start, 2), note, flush=True)
    torch.cuda.synchronize()
    seconds = time.monotonic() - start
    assert step == budget
    checkpoint = output / f"step{step:06}.pt"
    with checkpoint.open("xb") as dst:
        torch.save({"raw": {k: v.state_dict() for k, v in models.items()},
                    "EMA": {k: v.state_dict() for k, v in ema.items()},
                    "optimizer": optimizer.state_dict(), "seed": SEED, "steps": step}, dst)
    write_json(output / "completed.json", {"driver": reference(__file__), "experiment": "subbin-spectral-witness-v1",
               "parent": control["parent"], "matched_control": matched, "integer_witness_control": integer,
               "head_sources": [reference(ROOT / x) for x in ("phase.py", "models.py")],
               "checkpoint": reference(checkpoint), "seconds": seconds, "standard_cache": control["cache"],
               "witness_cache": independent,  "policies": {"refined": "matched with sub-bin witnesses", "refined-gap": "exact gap loss with sub-bin witnesses",
                            "transport": "matched with sub-bin witnesses and a fourth transported proposal"},
               "weights": "EMA .99 and raw", "optimizer": control["optimizer"],
               "updates_per_head": step, "photos": rows, "photo_visits_per_head": rows * EPOCHS,
               "native_queries_per_head": rows * EPOCHS * 3, "epochs": EPOCHS,
               "training_seed": SEED, "progress": progress})


if __name__ == "__main__":
    import sys
    {"features": collect, "train": train}[sys.argv[1]]()
