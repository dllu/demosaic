"""Check shifted native phases, reserved sample isolation, and exact test alignment."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np
from scipy.fft import fft2
from scipy.stats import rankdata

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import BASE, NATIVE, PACKED, PAD, ROOT, STEP, XI, YI, measured
from witness_features import measured as old
from head_corrected_broad import LUMA, SYNTH

NOISE = {"shot": .00128, "read": 6.5536e-6}
LAYOUTS = ([0, 1, 1, 2], [2, 1, 1, 0], [1, 0, 2, 1], [1, 2, 0, 1])
CENTER = 112
CROP = np.s_[64:192, 64:192]
MODAL_YX = np.stack((2 * YI, 2 * XI), axis=-1)


def phase_correlation(reference, measured):
    return (reference * measured.conj()).real / abs(reference).clip(min=1e-8)


def center_truth(image, tiled_frequencies):
    windows = np.lib.stride_tricks.sliding_window_view(image, (NATIVE, NATIVE))[2 * YI, 2 * XI]
    taper = SYNTH.astype(np.float32)
    means = (windows * taper).sum((-2, -1), keepdims=True) / taper.sum()
    values = fft2((windows - means) * taper, s=(2 * PAD, 2 * PAD), workers=1) / NATIVE
    coordinates = np.rint(tiled_frequencies / STEP).astype(np.int64) % (2 * PAD)
    return values[np.arange(len(YI)), coordinates[:, 0], coordinates[:, 1]]


def equal_integer_control():
    rng = np.random.default_rng(4263)
    raw = (.22 + .014 * rng.standard_normal((4, 128, 128))).astype(np.float32)
    err = []
    for layout in LAYOUTS:
        prior = old(raw, np.array(layout), NOISE)
        replay = measured(raw, np.array(layout), NOISE, refine=False).features
        diff = abs(replay - prior)
        err.append(float(diff.max()))
        assert diff.max() < .00015 and np.sqrt(np.mean(diff**2)) < 2e-6
    return err


def synthetic():
    rng = np.random.default_rng(75369)
    ys, xs = np.indices((256, 256))
    modes = []
    for j, (y, x) in enumerate(((.0742, .1211), (-.0742, .1211), (.0430, .1016), (.1016, .0117))):
        angle = rng.uniform(-2.5, 2.5)
        exact = .047 * np.cos(2 * np.pi * (x * xs + y * ys) + angle)
        raw = np.stack([.23 + exact[q//2::2, q%2::2] for q in range(4)]).astype(np.float32)
        source = np.array([y, x])
        closest = int(np.argmin(np.linalg.norm(BASE - source, axis=-1)))
        for layout in LAYOUTS:
            before = measured(raw, np.array(layout), NOISE, refine=False)
            after = measured(raw, np.array(layout), NOISE)
            # Editing every central CFA site leaves phase and frequency intact.
            occluded = raw.copy()
            occluded[:, 56:72, 56:72] = np.float32(.23)
            vacant = measured(occluded, np.array(layout), NOISE)
            assert np.array_equal(after.frequency[CENTER], vacant.frequency[CENTER])
            assert np.array_equal(after.phase[CENTER], vacant.phase[CENTER])
            assert np.max(abs(vacant.features[CENTER, :, 2:6])) < 1e-5
            assert np.all(after.features[CENTER, closest, 2:6] > .5)
            original_error = np.linalg.norm(before.frequency[CENTER, closest] - source)
            fit_error = np.linalg.norm(after.frequency[CENTER, closest] - source)
            assert fit_error < original_error and fit_error < .008
            old_alignment, new_alignment = (
                phase_correlation(center_truth(exact, block.frequency[:, closest]), block.phase[:, closest])[CENTER]
                for block in (before, after)
            )
            modes.append({"mode": j, "layout": layout, "true_yx": source.tolist(),
                          "base_error": float(original_error), "refined_error": float(fit_error),
                          "base_phase_agreement": float(old_alignment), "refined_phase_agreement": float(new_alignment)})
    return modes


def auc(values, positive, negative):
    active = positive | negative
    if not positive.any() or not negative.any():
        return None
    n = positive.sum()
    order = rankdata(values[active])[positive[active]]
    return float((order.sum() - n * (n + 1) / 2) / (n * negative.sum()))


def fixture(task, plan):
    row = plan["sources"][task["index"]]
    noise = plan["profiles"][task["noise"]]
    with np.load(checked(task["input"]), allow_pickle=False) as data:
        raw = data["packed"][0, :, 64:192, 64:192]
        cfa = data["colors"][0]
        cal = {k: data[k][:2] for k in ("wb", "matrix")}
        clean = linear_rgb(data["target"][:2, :, 128:384, 128:384], cal)
        diff = np.einsum("c,chw->hw", LUMA, clean[0] - clean[1])
        mask = data["support"]
    # Score only the known weak direction. The selection within its coarse
    # neighborhood uses the method's measured exterior sites.
    x, y = row["geometry"]["frequency"][1]
    if (x < 0) or (x == 0 and y < 0):
        x, y = -x, -y
    known = np.array((y, x))
    idx = int(np.argmin(np.linalg.norm(BASE - known, axis=-1)))
    windows = np.lib.stride_tricks.sliding_window_view(mask, (32, 32))[2*YI, 2*XI]
    support = (windows * SYNTH**2).sum((-1,-2)) / (SYNTH**2).sum()
    core = np.all((MODAL_YX >= 48) & (MODAL_YX < 176), axis=-1)
    inside = (support >= .97) & core
    outside = (support <= .01) & core
    weak_no_gap = np.where(inside)[0]
    if not len(weak_no_gap):
        weak_no_gap = np.flatnonzero(core & (support > .65))
    arms = {}
    for key in ("integer", "refined"):
        result = measured(raw, cfa, noise, refine=key == "refined")
        frequency = result.frequency[:, idx]
        phase = result.phase[:, idx]
        exact = center_truth(diff, frequency)
        aligned = phase_correlation(exact, phase)
        signed = np.sinh(result.features[:, idx, 2:6]).mean(-1)
        n = int(len(weak_no_gap))
        arms[key] = {
            "intact_frequency_error": float(np.mean(np.linalg.norm(frequency[weak_no_gap]-known,axis=-1))) if n else None,
            "intact_true_phase": float(aligned[weak_no_gap].mean()) if n else None,
            "intact_signed_Bayer": float(signed[weak_no_gap].mean()) if n else None,
            "true_gap_signed_Bayer": float(signed[outside].mean()) if np.any(outside) else None,
            "gap_intact_AUC": auc(signed, inside, outside),
        }
    return {"source":row["source"]["id"],"index":task["index"],"family":row["geometry"]["family"],
            "intact_windows": int(inside.sum()), "gap_windows": int(outside.sum()), "rows": arms}


def main():
    name = ROOT.parent / "query-gap-shoulders-v1"
    plan_ref, results = (reference(name / file) for file in ("plan.json", "fresh-gap.json"))
    plan = read_json(checked(plan_ref))
    source = read_json(checked(results))["rows"]
    with ThreadPoolExecutor(3) as pool:
        rows = list(pool.map(lambda row: fixture(row, plan), source))
    keys = rows[0]["rows"]["integer"].keys()
    summary = {}
    for method in ("integer", "refined"):
        summary[method] = {}
        for k in keys:
            vals = [r["rows"][method][k] for r in rows if r["rows"][method][k] is not None]
            summary[method][k] = {"sources": len(vals), "mean": float(np.mean(vals)) if vals else None}
    write_json(ROOT / "audit.json", {"driver":reference(__file__), "phase":reference("phase.py")
              if Path("phase.py").is_file() else reference(ROOT/"phase.py"), "calibration_plan":plan_ref,
              "calibration_inputs":results, "integer_control_max_feature_deviation":equal_integer_control(),
              "synthetic_sinusoid_cases":synthetic(), "score_summary":summary, "rows":rows,
              "scope":"Planted direction is used for diagnostic scoring only. No clean pixels enter frequency selection."})
    print(summary, flush=True)


if __name__ == "__main__":
    main()
