"""Render both standing GFX scenes and exact comparison triplets."""
import sys

from phase import ROOT
from review_subbin import CAPTIONS, load, predict
from native_gap_head import standing, exact

if sys.argv[1] == "standing":
    standing(provider=load, predictor=predict, captions=CAPTIONS,
             methods=("witness-matched", "refined", "refined-gap", "transport"),
             output_dir=ROOT / "standing")
else:
    exact(provider=load, predictor=predict, captions=CAPTIONS, main_arm="transport",
          extra_arms=("refined", "refined-gap"), output_dir=ROOT / "exact")
