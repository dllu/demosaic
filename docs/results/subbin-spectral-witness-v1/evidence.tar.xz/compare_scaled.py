"""Compare refined and integer witnesses at independent matched gap amplitudes."""
import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import ROOT
import evaluate_gap_head as base
from derive_contrasts import contrast
from review_subbin import load, predict

REFERENCES = {"refined": "witness-matched",
              "refined-gap": "witness-localized", "transport": "witness-matched"}
METRICS = ("intact_response", "intact_rms", "gap_added", "gap_exact",
           "gap_pair", "dip_response", "flat_added")


def main():
    torch.set_num_threads(1)
    models, proof, end = load()
    keep = {"matched", *REFERENCES, *REFERENCES.values()}
    models = {k: models[k] for k in keep}
    calibration = reference(ROOT / "wire-calibration.json")
    measured = read_json(checked(calibration))["summary"]["iso6400"]["gapped"]
    scales = {k: measured[k]["gap_added"]["mean"] / measured[v]["gap_added"]["mean"]
              for k, v in REFERENCES.items()}

    def with_comparators(native, exterior, parents, noise, box, options):
        outputs = predict(native, exterior, parents, noise, box, options)
        return outputs | {"integer-at-" + k: parents + np.float32(scales[k]) * (outputs[b] - parents)
                          for k, b in REFERENCES.items()}

    output = base.wire_panel(base.WIRE_TEST, models, {}, True, predictor=with_comparators)
    rng = np.random.default_rng(61208232)
    intervals = {}
    for profile in ("iso400", "iso6400"):
        held = [row for row in output["rows"] if row["profile"] == profile]
        intervals[profile] = {k: {
            metric: contrast(held, k, "integer-at-" + k, metric, rng) for metric in METRICS}
            for k in REFERENCES}
    write_json(ROOT / "matched-integer.json", {
        "driver": reference(__file__), "training": proof, "checkpoint": end["checkpoint"],
        "prior_driver": reference(ROOT.parent / "learned-spectral-gaps-v1" / "derive_contrasts.py"),
        "calibration": calibration, "factors": scales, "intervals": intervals,
        **output,
    })


if __name__ == "__main__":
    main()
