"""Compare learned sub-bin evidence and transported detail on retained fixtures."""
from dataclasses import replace
from functools import partial
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase import ROOT, PARENT, measured
from models import TransportHead, extend
from train import TREATMENTS
from witness_features import WitnessHead, measured as integer_features
import evaluate_gap_head as base
import review_witness as previous

CAPTIONS = {
    "prior": "Earlier spectral head",
    "witness-matched": "Integer-bin witnesses",
    "refined": "Sub-bin witnesses",
    "refined-gap": "Sub-bin witnesses + gap loss",
    "transport": "Transported phase",
}


def load(*, ablations=False):
    models, baseline, inherited = previous.load()
    models = {k: v for k, v in models.items() if not k.endswith("-raw")}
    training = reference(ROOT / "training/completed.json")
    end = read_json(checked(training))
    assert end["integer_witness_control"] == baseline and end["parent"] == inherited["parent"]
    state = torch.load(checked(end["checkpoint"]), weights_only=True, map_location="cpu")
    for policy in ("EMA", "raw"):
        for label in TREATMENTS:
            model = TransportHead() if label == "transport" else WitnessHead()
            model.load_state_dict(state[policy][label])
            name = label if policy == "EMA" else label + "-raw"
            models[name] = model.eval().requires_grad_(False)
    if ablations:
        for key in TREATMENTS:
            models[key + "-integer"] = models[key]
    return models, training, end


def predict(native, exterior_raw, parents, noise, box, models):
    cfa = native["colors"]
    donors = base.exterior(exterior_raw, cfa[0], noise, box)
    decisions = {name: [] for name in models}
    need_integer = any(name.endswith("-integer") for name in models)
    for raw, pred, layout, wb, matrix in zip(native["packed"], parents, cfa,
                                             native["wb"], native["matrix"], strict=True):
        standard = base.features(raw, layout, noise, box, donors, pred, wb, matrix)
        inherited = replace(standard, inputs=np.concatenate((
            standard.inputs, integer_features(raw, layout, noise)), axis=-1))
        prepared = {}
        for name in ("sub-bin", "integer") if need_integer else ("sub-bin",):
            evidence = measured(raw, layout, noise, refine=name == "sub-bin")
            ready = replace(standard, inputs=np.concatenate((standard.inputs, evidence.features), axis=-1))
            prepared[name] = ready, replace(ready, basis=extend(standard.basis, evidence))
        for name, model in models.items():
            if name.startswith(TREATMENTS):
                pair = prepared["integer" if name.endswith("-integer") else "sub-bin"]
                used = pair[int(isinstance(model, TransportHead))]
            elif isinstance(model, WitnessHead):
                used = inherited
            else:
                used = standard
            restored = base.apply(model, used, pred, "shape")
            assert np.isfinite(restored).all()
            decisions[name].append(restored)
    return {name: np.stack(rows) for name, rows in decisions.items()}


def main(panel):
    torch.set_num_threads(1)
    overlap = base.panel_membership()
    models, receipt, end = load(ablations=True)
    stamp = {"driver": reference(__file__), "training": receipt, "checkpoint": end["checkpoint"],
             "exact_evaluator": reference(base.__file__), "phase_implementation": reference(ROOT / "phase.py"),
             "previous_integer": end["integer_witness_control"], "matched_control": end["matched_control"]}
    if panel == "wire":
        controls = {k: v for k, v in models.items() if not k.endswith(("-raw", "-integer"))}
        tune = base.wire_panel(base.WIRE_TUNE, controls, {}, False, predictor=predict)
        groups = tune["summary"]["iso6400"]["gapped"]
        scales = {arm: groups[arm]["gap_added"]["mean"] / groups["matched"]["gap_added"]["mean"]
                  for arm in TREATMENTS}
        binding = ROOT / "wire-calibration.json"
        write_json(binding, stamp | tune | {"matched_scales": scales})
        test = base.wire_panel(base.WIRE_TEST, models, scales, True, predictor=predict)
        write_json(ROOT / "wire-scores.json", stamp | test | {"calibration": reference(binding)})
    elif panel == "natural":
        binding = reference(base.NATURAL / "evaluation/collected.json")
        begin = time.monotonic()
        # The replay keeps all earlier inputs and reports the independent
        # 48-photo subset alongside the overlap with wire calibration.
        rows = base.run(read_json(checked(binding))["records"],
                        partial(base.natural_row, models=models, predictor=predict))

        def summary(subset):
            return {p: {d: base.score_group([r for r in subset if r["profile"] == p and r["draw"] == d])
                        for d in ("coupled", "independent")} for p in ("iso400", "iso6400")}

        isolated = [r for r in rows if r["source_id"] not in overlap]
        assert len(isolated) == 192 and len(rows) == 256
        write_json(ROOT / "natural-scores.json", stamp | {"inputs": binding, "rows": rows,
                   "summary": summary(isolated), "full_replay": summary(rows),
                   "natural_only": len(isolated) // 4, "calibration_overlap": sorted(overlap),
                   "seconds": time.monotonic() - begin})
    else:
        raise ValueError(panel)


if __name__ == "__main__":
    main(sys.argv[1])
