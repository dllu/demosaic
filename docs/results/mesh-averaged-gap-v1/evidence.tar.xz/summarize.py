"""Audit fresh RGB output, compare attenuation at equal energy and render native crops."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from deliver import DISPLAY,score

ROOT=Path(__file__).resolve().parent
POLICIES=("top-quarter","mean-quarter","top-half","mean-half")
METHODS=("broad","central",*POLICIES)
LABELS=("Wide delivery","Central check","Best quarter","Mean quarter","Best half","Mean half")


def rms(x):
    return float(np.sqrt(np.mean(x.astype(float)**2))*65535)


def check_record(ref):
    row=read_json(checked(ref))
    with np.load(checked(row["arrays"]),allow_pickle=False) as stored:
        arrays=dict(stored)
    parent,target=arrays["parent"],arrays["target"]
    masks={k:arrays[k]for k in ("strong_phase","weak_phase","support")}
    x,y,w,h=DISPLAY
    roi=np.s_[...,y:y+h,x:x+w]
    projected=masks["weak_phase"][roi]>.1
    intact=(masks["support"][roi]>.9999)&projected
    broad=arrays["matching/broad"]
    anchor=arrays["matching/central"]
    methods={}
    for name,original in row["metrics"].items():
        seq=None if name=="parent" else arrays[name]
        rebuilt=score(parent,seq,target,masks)
        assert rebuilt==original,(row["entry"]["id"],name)
        image=parent[roi] if seq is None else parent[roi]+seq
        diff=image-target[roi]
        delivery=np.zeros_like(broad) if seq is None else seq
        context=name.split("/")[0] if "/" in name else "matching"
        methods[name]=rebuilt | {"present_RMS_DN16":rms(diff[1]),
                                 "intact_RMS_DN16":rms(diff[1][:,intact]),
                                 "edits_from_wide":[bool(np.any(a))for a in delivery-arrays[context+"/broad"]],
                                 "edits_from_central":[bool(np.any(a))for a in delivery-arrays[context+"/central"]]}
    match={}
    for fraction in ("quarter","half"):
        old,new=(arrays["matching/"+arm+"-"+fraction]for arm in ("top","mean"))
        diffs=(old-anchor,new-anchor)
        energies=[np.linalg.norm(a[1].astype(float))for a in diffs]
        if not all(energies):
            continue
        multiplier=energies[1]/energies[0]
        role=next(v for v in row["proof"]["matching"]["roles"]if v["role"]==1)
        max_single=role["evidence"]["policies"]["top-"+fraction]["max_cut"]
        if multiplier*max_single>1:
            match[fraction]={"matched_score":False,"matched_scale":float(multiplier),
                             "reason":"equal RMS requires >100% local attenuation"}
            continue
        corrected=new.copy()
        corrected[1]=(anchor[1]+multiplier*diffs[0][1].astype(float)).astype(anchor.dtype)
        measured=rms(corrected[1]-anchor[1])
        np.testing.assert_allclose(measured,rms(new[1]-anchor[1]),rtol=1e-5,atol=1e-7)
        match[fraction]={"matched_score":True,"matched_scale":float(multiplier),"matched_RMS_DN16":measured,
                         "scaled_max_cut":float(multiplier*max_single),
                         "single":score(parent,corrected,target,masks),"mean":methods["matching/mean-"+fraction]}
    return {"id":row["entry"]["id"],"source":ref,"entry":row["entry"],"CFA":row["traits"]["CFA"],
            "methods":methods,"matched":match,"roles":row["proof"]["matching"]["roles"]}


def averages(items):
    methods={}
    for arm in ("parent",*("matching/"+k for k in METHODS)):
        rows=[r["methods"][arm]for r in items]
        m={"n":len(rows),
           "weak_response_pct":100*mean(r["response"][0]for r in rows),
           "increment_RMS_DN16":mean(r["increment_RMS_DN16"][0]for r in rows),
           "edits_from_central":[sum(r["edits_from_central"][i]for r in rows)for i in range(3)]}
        for k in ("gap_error_RMS_DN16","gap_added_RMS_DN16","present_RMS_DN16","intact_RMS_DN16"):
            c=[r[k]for r in rows if r[k] is not None]
            m[k]=mean(c) if c else None
        methods[arm]=m
    return methods


def matched_results(rows):
    means={}
    for noise in ("iso400","iso6400"):
        means[noise]={}
        for fraction in ("quarter","half"):
            pairs=[item["matched"][fraction]for item in rows
                   if item["entry"]["profile"]==noise and item["entry"]["kind"]=="gaps" and
                   item["matched"].get(fraction,{}).get("matched_score",False)]
            bucket={}
            for method in ("single","mean"):
                bucket[method]={"n":len(pairs)}
                if pairs:
                    bucket[method].update(**{k:mean(a[method][k]for a in pairs)
                             for k in ("gap_added_RMS_DN16","gap_error_RMS_DN16")},
                        inc_RMS_DN16=mean(a[method]["increment_RMS_DN16"][0]for a in pairs))
            means[noise][fraction]=bucket
    return means


def repeated_means():
    sources=[reference(ROOT/f"repeats-{i}.json")for i in (0,1)]
    plan=reference(ROOT/"repeats-verified-plan.json")
    runs=[read_json(checked(src))for src in sources]
    assert all(r["plan"]==plan for r in runs)
    samples=[v for s in runs for v in s["rows"]]
    ids=sorted({row["case"]["id"]for row in samples})
    assert len(samples)==32 and len(ids)==4
    measurements={}
    for scene in ("all",*ids):
        selected=[r for r in samples if scene=="all" or r["case"]["id"]==scene]
        assert len(selected)==(32 if scene=="all" else 8)
        measurements[scene]={}
        for seq in POLICIES:
            part={}
            for kind in ("gap","continuing"):
                count=sum(r["scores"][kind]["proof"]["policies"][seq]["accepted"]for r in selected)
                part[kind]={"detected":count,"n":len(selected)}
                for col in ("exact_rear_support_RMS_DN16","outside_gap_RMS_DN16"):
                    part[kind][col]=mean(r["scores"][kind]["diagnostic_loss"][seq][col]for r in selected)
            measurements[scene][seq]=part
    return {"sources":sources,"plan":plan,"means":measurements}


def view(out,record,plan,policy):
    row=read_json(checked(record["source"]))
    with np.load(checked(row["arrays"]),allow_pickle=False)as f:
        data=dict(f)
    x,y,w,h=DISPLAY
    r=np.s_[...,y:y+h,x:x+w]
    role=1
    trunk=data["parent"][role]
    stack=[noisy_malvar(data)[role],trunk]
    for name in METHODS:
        merged=trunk.copy()
        merged[r]+=data["matching/"+name][role]
        stack.append(merged)
    stack.append(data["target"][role])
    labels=("Noisy Malvar","Local trunk",*LABELS,"Exact GT")
    return native_board(out,record["id"],stack,{k:data[k][role:role+1]for k in ("wb","matrix")},
        {"CFA":row["traits"]["CFA"],"source":record["source"],"arrays":row["arrays"],
         "checkpoint":plan["checkpoint"],"noise":plan["noise"][row["entry"]["profile"]],
         "seed":row["entry"]["seed"],"triplet_policy":policy},
         labels=labels,triplet_indices=(0,2+METHODS.index(policy),len(labels)-1),roi=DISPLAY,
         exposure=1,contrast=8)


def main():
    plan_ref=reference(ROOT/"measured-plan.json")
    plan=read_json(checked(plan_ref))
    parts=[reference(ROOT/f"part-{i}.json")for i in (0,1)]
    order={row["id"]:i for i,row in enumerate(plan["cases"])}
    all_rows=[]
    for part in parts:
        closure=read_json(checked(part))
        assert closure["plan"]==plan_ref
        all_rows.extend(check_record(ref)for ref in closure["measurements"])
    all_rows.sort(key=lambda x:order[x["id"]])
    assert len(all_rows)==len({item["id"]for item in all_rows})==24
    assert sum(len(x["methods"])for x in all_rows)==216
    groups={}
    for p in ("iso400","iso6400"):
        for layout in ("continuity","gaps"):
            part=[r for r in all_rows if (r["entry"]["profile"],r["entry"]["kind"])==(p,layout)]
            assert len(part)==6
            groups[p+"/"+layout]=averages(part)
    ranked=[]
    for profile in ("iso400","iso6400"):
        group=[r for r in all_rows if r["entry"]["profile"]==profile and r["entry"]["kind"]=="gaps"]
        def value(row):
            scores=row["methods"]
            gain=scores["matching/top-quarter"]["gap_error_RMS_DN16"]-scores["matching/mean-quarter"]["gap_error_RMS_DN16"]
            return gain
        ranked.append(max(group,key=value))
    largest_miss=max([r for r in all_rows if r["entry"]["profile"]=="iso6400" and r["entry"]["kind"]=="gaps"],
                     key=lambda r:r["methods"]["matching/mean-quarter"]["gap_added_RMS_DN16"])
    continued=max([r for r in all_rows if r["entry"]["profile"]=="iso400" and r["entry"]["kind"]=="continuity"],
                  key=lambda r:r["methods"]["matching/top-quarter"]["response"][0]-
                               r["methods"]["matching/mean-quarter"]["response"][0])
    renders={r["id"]:r for r in (*ranked,largest_miss,continued)}
    dest=ROOT/"native";dest.mkdir()
    boards=[view(dest,r,plan,"mean-quarter")for r in renders.values()]
    write_json(ROOT/"summary.json",{"script":reference(__file__),"plan":plan_ref,"parts":parts,"cases":all_rows,
       "verified_policy_scores":216,"groups":groups,"matched":matched_results(all_rows),"repeats":repeated_means(),
       "boards":boards,"triplets":[r["id"]for r in ranked]})

if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    main()
