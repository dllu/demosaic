"""Render the bounded delivery fit on the same native synthetic and GFX ROIs."""

import os
from pathlib import Path
import sys

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
sys.path.insert(1,str(ROOT.parent/"mesh-envelope-support-v1"))
REFERENCE=ROOT.parent/"local-mesh-phase-evidence-v1"
from standing import legacy
from deliver import DISPLAY


def view():
    model=read_json(ROOT/"summary.json")
    refit=read_json(ROOT/"refit.json")
    camera=read_json(ROOT/"camera.json")
    matches={v["id"]:v for v in refit["rows"]}
    fixtures={v["id"]:v for v in model["cases"]}
    dest=ROOT/"refit-native";dest.mkdir()
    stages=("iso400-ellipse-g215","iso6400-band-g213","iso6400-compound-g214","iso400-step-g214")
    one=[]
    for case in stages:
        row=read_json(checked(fixtures[case]["source"]))
        with np.load(checked(row["arrays"]),allow_pickle=False)as f:
            data=dict(f)
        with np.load(checked(matches[case]["refitted_arrays"]),allow_pickle=False)as f:
            replacement=f["mean-quarter"]
        x,y,w,h=DISPLAY
        where=np.s_[...,y:y+h,x:x+w]
        start=data["parent"][1]
        options=[noisy_malvar(data)[1],start]
        for result in (data["matching/broad"],data["matching/top-quarter"],data["matching/mean-quarter"],replacement):
            changed=start.copy();changed[where]+=result[1];options.append(changed)
        options.append(data["target"][1])
        recorded=next(v for v in model["boards"] if v["id"]==case) if any(v["id"]==case for v in model["boards"]) else None
        plan=read_json(checked(model["plan"]))
        binds={"source":fixtures[case]["source"],"checkpoint":plan["checkpoint"],"CFA":row["traits"]["CFA"],
               "noise":plan["noise"][row["entry"]["profile"]],"original_arrays":row["arrays"],
               "refit_arrays":matches[case]["refitted_arrays"]}
        out=native_board(dest,case,options,{a:data[a][1:2]for a in ("wb","matrix")},binds,
                 roi=DISPLAY,exposure=1,contrast=8,
                 labels=("Noisy Malvar","Local trunk","Wide delivery","Best quarter","Mean quarter","Mean quarter refit","Exact GT"),
                 triplet_indices=(0,5,6))
        one.append(out)
    inputs={v["id"]:v for v in read_json(REFERENCE/"camera.json")["views"]}
    corrected={v["id"]:v for v in refit["camera"]}
    two=[]
    for record in camera["views"]:
        identity=record["id"]
        with np.load(checked(corrected[identity]["arrays"]),allow_pickle=False)as f:
            data=f["mean-quarter"]
        with np.load(checked(inputs[identity]["input"]),allow_pickle=False)as f:
            color={k:f[k]for k in ("wb","matrix")}
        w,h=record["ROI"][2:]
        panel=legacy.pixel(data,color,(0,0,w,h),record["exposure"])
        omit=("Best half","Mean half")
        before={"image":record["image"],"panels":[v for v in record["panels"]if v["label"]not in omit]}
        image,coords=legacy.insert_camera_panels(dest,identity,before,"Mean quarter",[("Mean quarter refit",panel)])
        two.append(record|{"image":image,"panels":coords,"refit":corrected[identity]})
    assert len(two)==8 and len(one)==4
    write_json(ROOT/"refit-view.json",{"driver":reference(__file__),"refit":reference(ROOT/"refit.json"),
                    "synthetic":one,"camera":two})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    view()
