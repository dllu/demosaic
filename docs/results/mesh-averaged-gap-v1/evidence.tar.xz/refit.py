"""Replay a bounded delivery-strength fit after the original footprint audit."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from deliver import DISPLAY,score

ROOT=Path(__file__).resolve().parent
MODES=("top-quarter","mean-quarter","top-half","mean-half")
ANCHOR=.5
PRIOR_INFORMATION=16.
MINIMUM=.25
MAXIMUM=.85


def coefficient(p):
    if not p["accepted"]:
        return ANCHOR
    check=p["holdout"]
    power=check["projected_energy"]
    likelihood=check["z"]*np.sqrt(power)
    result=(likelihood+ANCHOR*PRIOR_INFORMATION)/(power+PRIOR_INFORMATION)
    return float(np.clip(result,MINIMUM,MAXIMUM))


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2))*65535)


def fresh(summary):
    folder=ROOT/"refit";folder.mkdir()
    out=[]
    for v in summary["cases"]:
        row=read_json(checked(v["source"]))
        with np.load(checked(row["arrays"]),allow_pickle=False)as f:
            arrays={k:f[k]for k in ("parent","target","strong_phase","weak_phase","support",
                                       "matching/central",*("matching/"+m for m in MODES))}
        parent,target=(arrays[k]for k in ("parent","target"))
        criteria={k:arrays[k]for k in ("strong_phase","weak_phase","support")}
        trunk=arrays["matching/central"]
        methods={}
        images={}
        for mode in MODES:
            base=arrays["matching/"+mode]
            amplitudes=[coefficient(r["evidence"]["policies"][mode])if "evidence"in r else ANCHOR
                        for r in row["proof"]["matching"]["roles"]]
            ratios=np.asarray(amplitudes)[:,None,None,None]/ANCHOR
            final=(trunk+ratios*(base-trunk).astype(float)).astype(base.dtype)
            x,y,w,h=DISPLAY
            roi=np.s_[...,y:y+h,x:x+w]
            verdict=score(parent,final,target,criteria)
            verdict["direct_RMS_DN16"]=rms((parent[roi]+final-target[roi])[1])
            methods[mode]={"chosen":amplitudes,"old":v["methods"]["matching/"+mode],"new":verdict}
            images[mode]=final
        path=folder/f"{v['id']}.npz"
        np.savez_compressed(path,**images)
        out.append({"id":v["id"],"type":[v["entry"]["profile"],v["entry"]["kind"]],"case":v["source"],
                    "metrics":methods,"refitted_arrays":reference(path)})
    info={}
    keys=("gap_error_RMS_DN16","gap_added_RMS_DN16")
    for prior in ("iso400","iso6400"):
        for group in ("continuity","gaps"):
            subset=[r for r in out if r["type"]==[prior,group]]
            assert len(subset)==6
            findings={}
            for arm in MODES:
                bunch=[r["metrics"][arm]for r in subset]
                findings[arm]={"n_edited":sum(r["chosen"][1]!=.5 for r in bunch)}
                for label in ("old","new"):
                    vals=[r[label]for r in bunch]
                    fields={k:mean(v[k]for v in vals)for k in keys if vals[0][k]is not None}
                    fields.update(increment_RMS_DN16=mean(v["increment_RMS_DN16"][0]for v in vals))
                    findings[arm][label]=fields
            info[prior+"/"+group]=findings
    return out,info


def native():
    prior=read_json(ROOT/"camera.json")
    out=[]
    for v in prior["views"]:
        proof=v["proof"]
        with np.load(checked(v["arrays"]),allow_pickle=False)as f:
            packaged=f["packaged"]
            opts={mode:f[mode]for mode in MODES}
        groups={}
        fields={}
        for k,original in opts.items():
            choice=coefficient(proof["policies"][k])if proof else .5
            final=(packaged+choice/.5*(original-packaged).astype(float)).astype(packaged.dtype)
            groups[k]={"gain_scale":choice,"new_vs_original_DN16":rms(final-original),
                       "new_vs_packaged_DN16":rms(final-packaged)}
            fields[k]=final
        target=ROOT/"refit"/("camera-"+v["id"]+".npz")
        np.savez_compressed(target,**fields)
        out.append({"id":v["id"],"metrics":groups,"arrays":reference(target)})
    return out


def run():
    write_json(ROOT/"refit-plan.json",{"driver":reference(__file__),"starting_delivery":ANCHOR,
         "noise_information_prior":PRIOR_INFORMATION,"bounded_amplitude":[MINIMUM,MAXIMUM],
         "scope":"Retrospective delivery-strength replay. The fixed footprints and admissions stay exactly as measured. Uses held-out scores to refit output strength."})
    items,groups=fresh(read_json(ROOT/"summary.json"))
    camera=native()
    write_json(ROOT/"refit.json",{"driver":reference(__file__),"plan":reference(ROOT/"refit-plan.json"),
                                    "rows":items,"groups":groups,"camera":camera})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    run()
