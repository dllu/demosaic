"""Verify bank equivalence, convex attenuation and reservation boundaries."""

import math
import os
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates,native_sites

ROOT=Path(__file__).resolve().parent
POOLED=ROOT.parent/"mesh-pooled-gap-evidence-v1"
FOOT=ROOT.parent/"mesh-shrunk-footprint-v1"
sys.path[:0]=[str(ROOT.parent/"mesh-envelope-support-v1"),str(ROOT.parent/"mesh-refined-edge-v1"),str(FOOT),str(POOLED)]
from deliver import CENTRE,DISPLAY,Carrier,window
from mesh import ribbon
from averaged_footprints import footprints,mask_audit,proposal_bank,rank
from extended_scope import wide_search
from pooled_gap_audit_20261118 import fitted_terms


def run():
    paths=(
        FOOT/"fresh/iso6400-ellipse-g194.json",POOLED/"scored/iso6400-disk-g205.json",
        POOLED/"scored/iso400-step-g203.json",
    )
    source=read_json(POOLED/"measured-plan.json")
    results=[]
    for path in paths:
        row=read_json(path)
        noise=source["noise"][row["entry"]["profile"]]
        role=next(x for x in row["proof"]["matching"]["roles"]if x["role"]==1)
        with np.load(checked(row["arrays"]),allow_pickle=False)as f:
            raw=window(f["packed"][1],CENTRE,phase=2)
            cfa=f["colors"][1]
        nx,ny=native_sites(raw.shape[-2:],(-127.5,-127.5))
        p,q=(ribbon(nx,ny,Carrier(**g))for g in role["central_pair"])
        assert raw.shape==p.shape==q.shape and raw.ndim==3
        fx,fy=role["central_pair"][0]["frequency"]
        theta=math.atan2(fy,fx)
        baseline,record=mask_audit(raw,cfa,p,q,noise,CENTRE,DISPLAY,theta)
        data,reserve,other,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
        design=np.column_stack((bg,rear))
        bank_theta=edge["shape"][0]if "shape"in edge else theta
        native=coordinates(160,160,origin=(-79.5,-79.5))
        bank=proposal_bank(bank_theta)
        assert len(bank)==336
        check={}
        for name,learn in (("quarter",reserve),("half",reserve|other[0])):
            gain,shape,fraction=wide_search(data,design,rear,learn,bank_theta)
            top=record["policies"]["top-"+name]["proposal"]
            assert top["shape"]==vars(shape)
            np.testing.assert_allclose((gain,fraction),(top["gain"],top["fraction"]),rtol=1e-11,atol=1e-10)
            options=footprints(data,design,rear,learn,bank,native)
            chosen=rank(data,design,rear,learn,bank)
            modal={kind:sum(s.kind==kind for s in bank)for kind in ("band","disk","ellipse")}
            log=np.asarray([chosen[i,0]/3-math.log(modal[s.kind]) for i,s in enumerate(bank)])
            w=np.exp(log-log.max())
            w/=w.sum()
            assert np.all(w>=0)
            x,y=(col[::809] for col in data.positions)
            stack=np.column_stack([s.mask(x,y)for s in bank])
            output=options["mean"][0][::809]
            np.testing.assert_allclose(output,stack@np.where(w*chosen[:,1]>1e-7,w*chosen[:,1],0),atol=1e-10,rtol=1e-10)
            assert np.all(output>=0) and np.all(output<=1+1e-10)
            check[name]={"shape":vars(shape),"sampled_sites":len(output),"matched_single":True,
                         "weighted_convex_mean":True}
        changed=raw.copy()
        held=other[2].reshape(raw.shape)
        changed[held]+=.007*(p[held]-.35*q[held])
        alters,test=mask_audit(changed,cfa,p,q,noise,CENTRE,DISPLAY,theta)
        assert record["edge"]==test["edge"]
        for k,row_ in record["policies"].items():
            counterpart=test["policies"][k]
            assert row_["proposal"]==counterpart["proposal"]
            assert abs(row_["holdout"]["z"]-counterpart["holdout"]["z"])>1e-5
        results.append({"case":reference(path),"checks":check,"holdout_perturbation_kept_all_nominations":True})
        print(row["entry"]["id"],tuple(check),flush=True)
    write_json(ROOT/"verification.json",{"source":reference(__file__),"cases":results})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    run()
