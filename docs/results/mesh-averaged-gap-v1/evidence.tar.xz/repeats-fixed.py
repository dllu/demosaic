"""Independent noisy repeats with measured carriers fixed from earlier observations."""

import argparse
import importlib.util
import math
import os
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.noise import add_noise
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
POOLED=ROOT.parent/"mesh-pooled-gap-evidence-v1"
FOOT=ROOT.parent/"mesh-shrunk-footprint-v1"
SUPPORT=ROOT.parent/"mesh-envelope-support-v1"
sys.path[:0]=[str(SUPPORT),str(ROOT.parent/"mesh-refined-edge-v1"),str(FOOT),str(POOLED)]
from deliver import CENTRE, DISPLAY, Carrier, window
from mesh import ribbon
from averaged_footprints import mask_audit, POLICIES


def get_generator(file,complete=False):
    tag="fixed_continuing_scene" if complete else "fixed_gap_scene"
    if complete:
        source=file.read_text()
        full=source.replace("q*(1-p)*footprint","q*(1-p)")
        assert source!=full
        env={"__name__":tag}
        exec(compile(full,str(file),"exec"),env)
        return env["observe"]
    spec=importlib.util.spec_from_file_location(tag,file)
    scene=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scene)
    return scene.observe


def make_plan():
    cases=[
        ("iso6400-ellipse-g194",FOOT/"fresh"),
        ("iso6400-ellipse-g201",POOLED/"scored"),
        ("iso6400-ellipse-g204",POOLED/"scored"),
        ("iso6400-disk-g205",POOLED/"scored"),
    ]
    first=read_json(FOOT/"fixed-plan.json")["noise"]["iso6400"]
    second=read_json(POOLED/"measured-plan.json")["noise"]["iso6400"]
    assert first == second
    rows=[]
    for i,(key,prior) in enumerate(cases):
        source=prior/f"{key}.json"
        binding=reference(source)
        scene=reference(prior.parent/"scenes.py")
        for draw in range(8):
            rows.append({"id":key,"source":binding,"scene":scene,"draw":draw,
                         "seed":1637741137+(8*i+draw)*51797})
    write_json(ROOT/"repeats-verified-plan.json",{"sources":[reference(__file__),reference(ROOT/"averaged_footprints.py")],
         "cases":rows,"noise":first,
         "scope":"32 new independent gap/continuing pairs. Carrier frequency, phase and width are fixed from previous independently noisy observations. No new broad delivery. Exact-support geometry enters diagnostic scores only."})


def patches(spec,noise):
    case=read_json(checked(spec["source"]))
    actual=case["entry"]
    scene=checked(spec["scene"])
    role=next(r for r in case["proof"]["matching"]["roles"] if r["role"]==1)
    known=get_generator(scene)(actual,noise)[0]
    full=get_generator(scene,True)(actual,noise)[0]
    with np.load(checked(case["arrays"]),allow_pickle=False) as arrays:
        np.testing.assert_array_equal(arrays["target"],known["target"].numpy())
        np.testing.assert_array_equal(arrays["packed"],known["packed"].numpy())
        target=arrays["target"][1]
        active=arrays["support"]
    colors=known["colors"][1]
    complete=full["target"][1].numpy()
    rear=complete-known["target"][0].numpy()
    fields={}
    scores={}
    for k,(tag,rgb)in enumerate((("continuing",complete),("gap",target))):
        sample=add_noise(mosaic(torch.from_numpy(window(rgb,CENTRE))[None],colors),noise["shot"],noise["read"],
                         black_level=.03,generator=torch.Generator().manual_seed(spec["seed"]+k*12427))
        raw=sample[0].numpy()
        a,b=native_sites(raw.shape[-2:],(-127.5,-127.5))
        carriers=[Carrier(**e)for e in role["central_pair"]]
        p,q=(ribbon(a,b,c)for c in carriers)
        fx,fy=carriers[0].frequency
        masks,witness=mask_audit(raw,colors.numpy(),p,q,noise,CENTRE,DISPLAY,math.atan2(fy,fx))
        exact_cut=window(1-active,DISPLAY) if tag=="gap" else np.zeros((160,160))
        ref=window(rear,DISPLAY)
        full_target_rms=65535*np.sqrt(np.mean((ref*exact_cut[None])**2))
        scores[tag]={"proof":witness,"measurement":fingerprint(sample),
                     "uncorrected_exact_rear_RMS_DN16":float(full_target_rms)}
        loss={}
        for method in POLICIES:
            u=masks[method]
            residual=65535*np.sqrt(np.mean((ref*(exact_cut-u)[None])**2))
            wrong_area=exact_cut==0
            false_rms=65535*np.sqrt(np.mean((ref[:,wrong_area]*u[wrong_area][None])**2))
            loss[method]={"exact_rear_support_RMS_DN16":float(residual),"outside_gap_RMS_DN16":float(false_rms)}
        scores[tag]["diagnostic_loss"]=loss
    return scores


def run(part):
    os.sched_setaffinity(0,[14+part]);os.nice(12);torch.set_num_threads(1)
    begin=ROOT/"repeats-verified-plan.json"
    plan=read_json(begin);out=[]
    for row in plan["cases"][part::2]:
        scores=patches(row,plan["noise"])
        out.append({"case":row,"scores":scores})
        print(row["id"],row["draw"],{k:{m:e["accepted"] for m,e in v["proof"]["policies"].items()}for k,v in scores.items()},
              flush=True)
    write_json(ROOT/f"repeats-{part}.json",{"plan":reference(begin),"rows":out})


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--plan",action="store_true")
    parser.add_argument("--part",type=int,choices=(0,1))
    args=parser.parse_args()
    make_plan() if args.plan else run(args.part)
