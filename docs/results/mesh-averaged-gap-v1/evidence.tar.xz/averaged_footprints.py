"""Average plausible gap footprints before a fixed disjoint Bayer confirmation."""

from itertools import product
import math

import numpy as np

from demosaic.isolated_line import coordinates
from extended_scope import Ellipse
from gate import library
from pooled_gap_audit_20261118 import (
    SIGNED_OVERLAP, admitted, fitted_terms, forecasts, read_score, sound_template,
)

POLICIES = ("top-quarter", "mean-quarter", "top-half", "mean-half")


def proposal_bank(theta):
    return library()+tuple(Ellipse("ellipse",(x,y),width,theta+rotation)
        for x,y,width,rotation in product(range(-48,49,24),range(-48,49,24),(28,43,56),
                                        (0.,math.pi/4,-math.pi/4)))


def rank(data,design,rear,learn,candidates):
    """Return reserve error improvement and bounded rear attenuation for each shape."""
    position=tuple(z[learn]for z in data.positions)
    colors=data.colors[learn]
    raw=data.raw[learn]
    records=[]
    for c in range(3):
        site=colors==c
        design_here=design[learn][site]
        Q,R=np.linalg.qr(design_here,mode="reduced")
        proj=Q.T@raw[site]
        residual=raw[site]-Q@proj
        co=np.linalg.solve(R,proj)[-rear.shape[1]:]
        wire=rear[learn][site]@co
        noise=data.shot*max(1e-4,float(np.median(raw[site])))+data.read
        records.append((site,Q,residual,wire,noise))

    all_scores=[]
    for start in range(0,len(candidates),12):
        sub=candidates[start:start+12]
        field=np.column_stack([shape.mask(*position)for shape in sub])
        dot,power=np.zeros(len(sub)),np.zeros(len(sub))
        for site,Q,residual,wire,noise in records:
            assert wire.ndim==1 and field.ndim==2
            delta=-(wire[:,None]*field[site])
            projection=Q.T@delta
            dot+=(residual@delta)/noise
            power+=((delta*delta).sum(0)-(projection*projection).sum(0))/noise
        amplitude=np.clip(dot/np.maximum(power,1e-12),0,1)
        score=2*amplitude*dot-amplitude**2*power
        all_scores.extend(zip(score.tolist(),amplitude.tolist(),strict=True))
    return np.asarray(all_scores)


def footprints(data,design,rear,learn,bank,native):
    ranking=rank(data,design,rear,learn,bank)
    peak=int(np.argmax(ranking[:,0]))
    # A three-way prior gives each family equal total mass before the RAW fit.
    # Temper the fit score because overlapping grid entries are correlated.
    population={shape.kind:sum(s.kind==shape.kind for s in bank)for shape in bank}
    exponent=np.exp((ranking[:,0]-ranking[peak,0])/3)
    weights=exponent/np.asarray([population[s.kind]for s in bank])
    weights/=weights.sum()
    scaled=weights*ranking[:,1]
    nomination=np.zeros(len(data.raw))
    emitted=np.zeros_like(native[0])
    for shape,strength in zip(bank,scaled,strict=True):
        if strength>1e-7:
            nomination+=strength*shape.mask(*data.positions)
            emitted+=strength*shape.mask(*native)
    highest=bank[peak]
    strength=ranking[peak,1]
    winners=np.argsort(-weights)[:8]
    assert nomination.shape==data.raw.shape and float(nomination.max())<=1+1e-10
    chosen={
        "top":(strength*highest.mask(*data.positions),strength*highest.mask(*native),
            {"shape":vars(highest),"fraction":float(strength),"gain":float(ranking[peak,0])}),
        "mean":(nomination,emitted,
            {"effective_shapes":float(1/np.dot(weights,weights)),
             "family_mass":{kind:float(sum(w for w,s in zip(weights,bank,strict=True)if s.kind==kind))for kind in population},
             "largest_weights":[{"shape":vars(bank[i]),"weight":float(weights[i]),"gain":float(ranking[i,0]),
                                  "fraction":float(ranking[i,1])}for i in winners]}),
    }
    return chosen


def mask_audit(raw,cfa,p,q,noise,query,roi,approx_angle):
    data,reserve,other,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    a,b,d=other
    global_ok="shape" not in edge or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    design=np.column_stack((bg,rear))
    angle=edge["shape"][0]if "shape" in edge else approx_angle
    bank=proposal_bank(angle)
    origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
    native=coordinates(roi[3],roi[2],origin=origin)
    fields={}
    proof={}
    for label,learn in (("quarter",reserve),("half",reserve|a)):
        by_mode=footprints(data,design,rear,learn,bank,native)
        for operation,(cut,warped,note) in by_mode.items():
            delta,sigma,_=sound_template(data,design,rear,learn,cut)
            hold=read_score(data.raw,data.colors,design,delta,sigma,~learn)
            eligible=bool(global_ok and hold["z"]>SIGNED_OVERLAP and hold["half_displacement_gain"]>0)
            mode=f"{operation}-{label}"
            fields[mode]=.5*warped if eligible else np.zeros_like(warped)
            proof[mode]={"reservation_count":int(learn.sum()),"holdout":hold,"accepted":eligible,
                         "proposal":note,"max_cut":float(fields[mode].max())}
    return fields,{"edge":edge,"global_keep":global_ok,"policies":proof}
