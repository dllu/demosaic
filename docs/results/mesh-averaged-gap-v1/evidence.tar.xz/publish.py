"""Bind the completed fresh, repeated, and native studies to their source files."""

from datetime import datetime,UTC
import hashlib
from pathlib import Path
import shutil
from statistics import mean
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
IMAGES=REPO/"docs/images/mesh-averaged-gap-v1"
RESULTS=REPO/"docs/results/mesh-averaged-gap-v1"
ARM=("top-quarter","mean-quarter","top-half","mean-half")


def relative(path):
    return {"path":path.relative_to(REPO).as_posix(),"sha256":reference(path)["sha256"]}


def publish_image(item,panels,prefix=""):
    origin=checked(item)
    path=IMAGES/(prefix+origin.name)
    shutil.copyfile(origin,path)
    with Image.open(path) as image:
        for value in panels:
            x,y,w,h=value["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
    binding=relative(path)
    assert binding["sha256"]==item["sha256"]
    return binding


def refit_repeats():
    plan=reference(ROOT/"refit-repeats-plan.json")
    records=[reference(ROOT/f"refit-repeats-{i}.json") for i in (0,1)]
    parts=[read_json(checked(x))for x in records]
    assert all(part["plan"]==plan for part in parts)
    rows=[w for part in parts for w in part["rows"]]
    assert len(rows)==16 and len({item["case"]["seed"]for item in rows})==16
    values={}
    for mode in ARM:
        values[mode]={}
        for label in ("gap","continuing"):
            checks=[v["scores"][label]for v in rows]
            values[mode][label]={"n":len(checks),"admitted":sum(q["proof"]["policies"][mode]["accepted"]for q in checks)}
            for method in ("fixed","refit"):
                scores=[v["diagnostic_loss"][mode+"/"+method]for v in checks]
                values[mode][label][method]={k:mean(q[k]for q in scores)
                    for k in ("exact_rear_support_RMS_DN16","outside_gap_RMS_DN16","amplitude")}
    return {"plan":plan,"parts":records,"means":values}


def main():
    summary=read_json(ROOT/"summary.json")
    assert summary["verified_policy_scores"]==216 and len(summary["cases"])==24
    assert len(read_json(ROOT/"verification.json")["cases"])==3
    assert len(summary["triplets"])==2
    assert summary["repeats"]["means"]["all"]["mean-quarter"]["gap"]["detected"]==27
    assert all(not x["changed"][2] for v in summary["cases"] for k,x in v["methods"].items()
               if k.startswith("matching/"))
    rotations=[v for v in summary["cases"] if v["entry"]["rotated"]]
    assert len(rotations)==8 and all(not any(r["changed"]) for x in rotations
                      for k,r in x["methods"].items() if k.startswith("unrelated/"))
    source=read_json(ROOT/"camera.json")
    refits=read_json(ROOT/"refit-view.json")
    IMAGES.mkdir()
    RESULTS.mkdir()
    native=[]
    replay=[]
    native_notes={
        "iso400-ellipse-g215":"Averaging weakens some residual rear texture inside the ellipse. Thin vertical artifacts persist near the step.",
        "iso6400-band-g213":"Faint rear texture remains but the foreground wire stays coherent.",
        "iso6400-compound-g214":"The compound gap retains visible false texture in both methods.",
        "iso400-step-g210":"The continuous wire stays visible with the same cropped output.",
        "iso400-step-g214":"Refitting the strength reduces a weak continuous direction near the strong edge.",
    }
    for selected,dest,prefix in ((summary["boards"],native,""),(refits["synthetic"],replay,"refit-")):
        for v in selected:
            for key in ("source","checkpoint"):
                checked(v[key])
            settings={k:a for k,a in v.items()if k not in ("board","triplet")}
            modes=("board","triplet") if not prefix and v["id"] in summary["triplets"] else ("board",)
            for take in modes:
                item=v[take]
                settings[take]=item|{"image":publish_image(item["image"],item["panels"],prefix)}
            dest.append(settings|{"observation":native_notes[v["id"]]})
    assert len(native)==len(replay)==4 and sum("triplet"in r for r in native)==2
    cameras={}
    observations={
        "main-overcast-sky-main-overcast-sky":"Smooth gray sky and no visible added pattern.",
        "main-building-detail-main-building-detail":"The fine support and cable stay soft.",
        "main-foliage-main-foliage":"Same soft leaf edges and shadow contrast.",
        "main-chain-link-fence-main-chain-link-fence":"Coarse crossings remain visible with a more noticeable contrast cut in the strength replay.",
        "mesh-nominal-fine-green-mesh-left":"Faint modulation beside the post has slightly lower contrast after refitting the mean strength.",
        "mesh-nominal-fine-green-mesh-right":"Both recovered directions and the same dark background structure remain visible.",
        "mesh-profile3879-fine-green-mesh-left":"Weak strands remain soft, with a little more attenuation under the strength replay.",
        "mesh-profile3879-fine-green-mesh-right":"The mean limits fading along both directions. Background mottle is still visible.",
    }
    for label,boards,prefix in (("full_audit",source["views"],""),("strength_replay",refits["camera"],"refit-")):
        collection=[]
        for v in boards:
            for k in ("source","RAW","parent","arrays"):
                checked(v[k])
            collection.append(v|{"image":publish_image(v["image"],v["panels"],prefix),
                                 "observation":observations[v["id"]]})
        assert len(collection)==8
        cameras[label]=collection
    receipts=RESULTS/"viewing.json"
    write_json(receipts,{"actual_native_viewing":True,"recorded_utc":datetime.now(UTC).isoformat(),
                 "camera_checkpoint":source["checkpoint"],"cameras":cameras,
                 "synthetic":native,"strength_replay_synthetic":replay,
                 "scope":"Viewed eight fixed and eight refit standing GFX boards, eight synthetic comparisons and two exact-target triplets."})
    repeated=ROOT/"refit-repeats-summary.json"
    write_json(repeated,refit_repeats())
    exported=("summary.json","refit.json","refit-repeats-summary.json","verification.json")
    for name in exported:
        shutil.copyfile(ROOT/name,RESULTS/name)
    archived=sorted([p for p in ROOT.iterdir()if p.is_file() and p.suffix in (".py",".json",".log")]
                    +list((ROOT/"scored").glob("*.json")))
    archive=RESULTS/"evidence.tar.xz"
    inventory={str(t.relative_to(ROOT)):t for t in archived}
    with tarfile.open(archive,"x:xz",preset=4)as stream:
        for name,path in inventory.items():
            stream.add(path,arcname=name)
    with tarfile.open(archive,"r:xz")as stream:
        assert set(stream.getnames())==set(inventory)
        for name,path in inventory.items():
            assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==reference(path)["sha256"]
    history=("mesh-pooled-gap-evidence-v1","mesh-shrunk-footprint-v1","mesh-refined-edge-v1",
             "mesh-envelope-support-v1")
    write_json(RESULTS/"publication.json",{
        "scope":"Existing EMA crop models with the fixed 24-scene panel, 32+16 independent conditional pairs, and both native GFX families.",
        "receipt_files":[relative(RESULTS/name)for name in (*exported,"viewing.json")],
        "archive":relative(archive),"archive_contents":{k:reference(p)for k,p in inventory.items()},
        "earlier":[relative(REPO/"docs/results"/name/"evidence.tar.xz")for name in history],
    })


if __name__=="__main__":
    main()
