"""Exact full-panel receipts, sources and unresized preselected native boards."""
import gzip
import html
import io
import shutil
import tarfile
from pathlib import Path
import numpy as np
from PIL import Image
from audit_checkpoint_pilot import crop
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
producer = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-v1"
root = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-review-v1"
subset = root / "native-subset"
destination = repo / "docs/results/neural-nuisance-fixed-bg129-full-v1"
images = repo / "docs/images/neural-nuisance-fixed-bg129-full-v1"
assert read_json(producer / "controller-result.json")["producer_stages_succeeded"]
assert read_json(root / "controller-result.json")["returncode"] == 0
plan = read_json(producer / "plan.json")
collection = read_json(producer / "collection.json")
records = {r["id"]: r for r in collection["rows"]}
report = read_json(root / "prior-panels/report.json")
baseline_collection = read_json(checked(read_json(repo / ".cache/experiments/neural-nuisance-full-review-v1/completed.json")["producer_collection"]))
baseline_records = {r["id"]: r for r in baseline_collection["rows"]}
base = read_json(subset / "report/report.json")
destination.mkdir(exist_ok=False)
images.mkdir(exist_ok=False)
figures, archives = [], []
channels = 0

def copy_image(binding, relative, metadata):
    target = images / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(checked(binding), target)
    assert reference(target)["sha256"] == binding["sha256"]
    figures.append({"original": binding, "published": reference(target), "relative": relative, "metadata": metadata})

for figure in [*report["figures"], *read_json(root / "extra-stress/report.json")["figures"]]:
    row = figure["source"]
    sample = row["sample"]
    with np.load(checked(row["arrays"]), allow_pickle=False) as data:
        calibration = {k: data[k][sample:sample+1] for k in ["wb", "matrix", "packed", "colors"]}
        noisy = data["noisy_rgb"] if row["kind"] == "mesh" else noisy_malvar(calibration)
    parent = np.load(checked(row["parent"]))[sample:sample+1]
    encoded = np.asarray(Image.open(checked(figure["image"])))
    for panel in figure["panels"]:
        label = panel["label"]
        x, y, w, h = panel["xywh"]
        if label == "Conditional H1 t2":
            value = np.load(checked(records[row["id"]]["predictions"]["conditional-local-t2"]))[None]
        elif label == "Fixed proposal NN":
            value = np.load(checked(records[row["id"]]["predictions"]["local-t2"]))[None]
        elif label == "Prior256 NN t2":
            binding = baseline_records[row["id"]]["predictions"]["local-t2"]
            assert binding == figure["baseline_prediction"]
            value = np.load(checked(binding))[None]
        elif label == "Noisy Malvar":
            value = noisy
        elif label in ["V120", "V143"]:
            value = parent
        else:
            original = np.asarray(Image.open(checked(figure["original_aggregation_board"])))
            np.testing.assert_array_equal(encoded[y:y+h, x:x+w], original[y:y+h, x:x+w])
            channels += h*w*3
            continue
        expected = crop(value, calibration, figure["ROI_xywh"], figure["display_exposure"])
        np.testing.assert_array_equal(encoded[y:y+h, x:x+w], expected)
        channels += expected.size
    copy_image(figure["image"], ("stress/" if "selection" in figure else "matched/") + Path(figure["image"]["path"]).name, figure)

native_plan = read_json(subset / "plan.json")
for source in [1, 7]:
    group = next(g for g in native_plan["finite_groups"] if g["profile"] == "iso400" and g["metadata"]["placement"] == "far" and g["metadata"]["recipe"]["source"] == source)
    case = group["cases"][2]
    figure = next(f for f in base["figures"] if Path(f["image"]["path"]).stem == case + "-triplet")
    copy_image(figure["image"], "triplets/" + Path(figure["image"]["path"]).name, figure)
assert len(figures) == 68
body = '<!doctype html><meta charset="utf-8"><title>Full fixed-proposal neural nuisance review</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:28px 0;overflow:auto}img{max-width:none}</style><h1>Eight-source global-background/local129 neural nuisance with saved256 baseline</h1><p>All native160 cells unresized; appended Prior256 NN t2 panels use the identical source/ROI/calibration/noise/exposure without replay. Current labels Fixed proposal NN and Conditional H1 t2 are inherited renderer names for the fixed-global-background local129 controls; use browser zoom100%. All8 development sources/3 priors/near-far RGGB repeat0, protected main/cab families at both profiles/ROIs/JPEGs, additional input-only maximum-correction stress views. Independent ISO100/AHD references are qualitative, never exact GT. Eight-source statistics include all4 CFAs/two repeats; no camera-population claim.</p>'
for figure in figures:
    name = html.escape(figure["relative"])
    body += f'<figure><figcaption>{name}</figcaption><a href="{name}"><img src="{name}"></a></figure>\n'
(images / "native-viewer.html").write_text(body)

def archive(source, name):
    source = Path(source)
    target = destination / (name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})

for prefix, directory in [("producer", producer), ("review", root)]:
    for source in sorted(directory.rglob("*")):
        if not source.is_file() or directory / "work" in source.parents or source.suffix not in [".json", ".log", ".py"]:
            continue
        if prefix == "producer" and (producer / "backgrounds" in source.parents or producer / "predictions" in source.parents):
            continue
        archive(source, prefix + "-" + str(source.relative_to(directory)).replace("/", "--"))
for source in [Path(__file__), repo / ".cache/extra-neural-fixed-bg129-full-stress-v1.py", repo / ".cache/extra-neural-fixed-bg129-full-stress-v1.log", repo / "scripts/add_neural_nuisance_baseline_panels.py", repo / ".cache/fixed-bg129-full-prior-panels-v1.log"]:
    archive(source, "extra-" + source.name)

def exact_tar(files, base_directory, name):
    buffer = io.BytesIO()
    members = []
    with tarfile.open(fileobj=buffer, mode="w") as tar:
        for source in sorted(files):
            info = tarfile.TarInfo(str(source.relative_to(base_directory)))
            data = source.read_bytes()
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
            members.append({"original": reference(source), "member": info.name})
    target = destination / name
    with target.open("xb") as stream:
        stream.write(gzip.compress(buffer.getvalue(), mtime=0))
    with tarfile.open(target, "r:gz") as tar:
        for member in members:
            assert tar.extractfile(member["member"]).read() == checked(member["original"]).read_bytes()
    return {"archive": reference(target), "members": members, "all_member_bytes_exact": True}

receipts = [f for name in ["backgrounds", "predictions"] for f in (producer / name).glob("*.json")]
bundled = exact_tar(receipts, producer, "per-case-receipts.tar.gz")
sources = [exact_tar(list((directory / "work").rglob("*.py")), directory / "work", prefix + "-executed-source.tar.gz") for prefix, directory in [("producer", producer), ("review", root)]]
write_json(root / "publication-prepared.json", {"archives": archives, "source_snapshots": sources,
    "per_case_receipts": bundled, "images": figures, "viewer": reference(images / "native-viewer.html"),
    "matched_stress_RGB_channels_exact": channels, "full_independent_audit": reference(root / "independent-audit.json"),
    "background_input_audit": reference(root / "background-independent-audit.json"),
    "native_independent_audit": reference(subset / "independent-audit.json"),
    "cross_study_comparison": reference(root / "cross-study-comparison.json"),
    "saved_baseline_panels": reference(root / "prior-panels/report.json"),
    "producer_neural_forwards": read_json(producer / "backgrounds-collection.json")["new_root_forwards"],
    "new_neural_forwards_in_review_publication": 0, "viewing": "pending actual native inspection",
    "scope": "Complete1164-case producer and independent8-source/CFA/repeat/noise review. Exact compressed receipts, bundled per-case JSONs and both executed Python source snapshots; actual native viewing remains required before final publication. Original raw media/captures untouched; references remain qualitative, not exact GT."})
print(len(figures), "exact figures;", len(archives), "compressed receipts;", len(receipts), "bundled case receipts")
