"""Start the full fixed-background cohort and its separately frozen reviewer."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, write_json, verify_plan

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-v1"
review = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-review-v1"
plan = read_json(root / "plan.json")
verify_plan(plan)
assert not (root / "launch.json").exists()
assert plan["maximum_new_neural_forwards"] == 0 and len(plan["rows"]) == 1164
assert plan["prediction_cache"] == reference(repo / ".cache/experiments/neural-nuisance-fixed-bg129-pilot-v1/collection.json")
cache = read_json(checked(plan["background_cache"]))
assert cache["complete_background_fields"] == 2320
assert {r["id"] for r in cache["rows"]} == {r["id"] for r in plan["rows"]}
if review.exists():
    assert not (review / "plan.json").exists() and not (review / "launch.json").exists()
    backup = repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-review-prepare-failed-v1"
    assert not backup.exists()
    files = [{"original": reference(p), "preserved": str(backup / p.relative_to(review))}
             for p in review.rglob("*") if p.is_file()]
    review.rename(backup)
    assert all(reference(p["preserved"])["sha256"] == p["original"]["sha256"] for p in files)
    write_json(root / "review-preparation-failure-v1.json", {"files": files,
        "log": reference(repo / ".cache/prepare-fixed-bg129-full-review-v1.log"),
        "reason": "Reviewer prepare requires the producer launch receipt; first attempt preceded launch and stopped before any review worker. Preserve partial frozen source; corrected prepare now checks prerequisites before creating directories."})
template = repo / ".cache/experiments/neural-nuisance-full-panel-v1/controller.py"
(root / "controller.py").write_text("import os\nos.sched_setaffinity(0,[16,17])\n" + template.read_text())
env = dict(os.environ, PYTHONPATH=str(repo / "src") + ":" + str(repo / "scripts"),
           OPENBLAS_NUM_THREADS="2", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2")
with (root / "controller.log").open("x") as log:
    process = subprocess.Popen([sys.executable, str(root / "controller.py"), str(root)],
        env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
launch = {"pid": process.pid, "create_time": psutil.Process(process.pid).create_time(),
          "plan": reference(root / "plan.json"), "controller": reference(root / "controller.py")}
write_json(root / "launch.json", launch)
with (root / "review-prepare-v2.log").open("x") as log:
    subprocess.run([sys.executable, str(repo / "scripts/review_neural_nuisance_panel.py"),
        "prepare", str(review), "--producer", str(root), "--pilot-role-errors",
        str(repo / ".cache/experiments/neural-nuisance-fixed-bg129-pilot-v1/summary-review/absolute-role-errors.json"),
        "--baseline-summary", str(repo / ".cache/experiments/neural-nuisance-full-review-v1/summary.json")],
        env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
review_template = repo / ".cache/experiments/neural-nuisance-full-review-v1/controller.py"
(review / "controller.py").write_text("import os\nos.sched_setaffinity(0,[18,19])\n" + review_template.read_text())
with (review / "controller.log").open("x") as log:
    observer = subprocess.Popen([sys.executable, str(review / "controller.py"), str(review)],
        env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
write_json(review / "launch.json", {"pid": observer.pid,
    "create_time": psutil.Process(observer.pid).create_time(), "plan": reference(review / "plan.json"),
    "controller": reference(review / "controller.py")})
write_json(root / "study.json", {"plan": reference(root / "plan.json"), "review_plan": reference(review / "plan.json"),
    "launcher": reference(__file__), "baseline_summary": reference(repo / ".cache/experiments/neural-nuisance-full-review-v1/summary.json"),
    "rehearsal": reference(repo / ".cache/fixed-bg-cross-study-rehearsal-v1.json"),
    "cohort": "1152 finite roles/all8 sources/all4 CFAs/two repeats/all3 priors plus12 materials/protected contexts",
    "adoption": "All2320 closed masked fields;48 pilot cases/288 threshold2 outputs only after exact package/geometry/physical input/parent checks",
    "primary_comparison": "Current fixed-global-background local129 NN versus completed256 NN on identical input/parent/target archives; paired8-source summaries; internal six-control comparisons retained",
    "native_comparison": "All48 predeclared RGGB/repeat0 role2 views plus protected contexts/stress; add saved prior256 NN panels at identical ROIs/transforms when publishing, no neural replay",
    "maximum_new_neural_forwards": 0, "deadline_seconds_per_producer_stage": 21600,
    "scope": "Frozen new reconstruction package; all fields/corrections close before new full quality scoring. Queued reviewer waits on exact producer PID/creation time. No automatic restart, no old job alteration, no training/noise/RAW decode. Independent real references qualitative/notGT."})
print("producer", launch)
print("reviewer", read_json(review / "launch.json"))
