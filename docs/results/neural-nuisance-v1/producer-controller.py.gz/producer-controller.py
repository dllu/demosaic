import os, subprocess, sys, time
from pathlib import Path
from demosaic.experiments.artifacts import read_json, write_json, reference, verify_plan
from demosaic.experiments.runtime import owner_identity
root=Path(sys.argv[1]); plan=read_json(root/'plan.json'); verify_plan(plan)
work=Path(plan['work']); py=plan['python']; records=[]
stages=[('backgrounds',[py,str(work/'scripts/pilot_neural_nuisance.py'),'backgrounds',str(root)],True),('predict',[py,str(work/'scripts/pilot_neural_nuisance.py'),'predict',str(root)],False),('score',[py,str(work/'scripts/pilot_neural_nuisance.py'),'score',str(root)],False),('report',[py,str(work/'scripts/report_local_validated_waves.py'),str(root)],False),('audit',[py,str(work/'scripts/audit_local_wave_pilot.py'),str(root)],False),('matched',[py,str(work/'scripts/report_phase_aggregation.py'),str(root),str(root/'native'),'--method-label','Neural nuisance t2','--control-method','conditional-local-t2','--control-label','Conditional H1 t2','--skip-old-h1-equivalence'],False)]
for name,args,gpu in stages:
 env=os.environ.copy(); env.update(PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES='0' if gpu else '',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
 began=time.time()
 with (root/(name+'.log')).open('x') as log:
  child=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  import psutil
  write_json(root/(name+'-launch.json'),{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':args,'controller':owner_identity(),'plan':reference(root/'plan.json')})
  code=child.wait()
 records.append({'stage':name,'returncode':code,'seconds':time.time()-began})
 write_json(root/'controller-progress.json',{'owner':owner_identity(),'stages':records},replace=True)
 if code: break
write_json(root/'controller-result.json',{'stages':records,'all_stages_succeeded':len(records)==len(stages) and all(r['returncode']==0 for r in records),'plan':reference(root/'plan.json'),'script':reference(__file__)})
