"""Compare directional error and score-only removal of the different gap components."""
from functools import partial
import time

import numpy as np
import torch

from envelope import ROOT, PRIOR, MIXTURE
from gap_projection import subspace
from evaluate_mixture import load, predict
from review_quiet import LOCAL, CORE, wire_inputs
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import evaluate_gap_head as review


def record(task, plan, lookup, model):
    native,parents,frozen=wire_inputs(task,lookup,None)
    geometry=plan["sources"][task["index"]]["geometry"]
    mask=(native["support"][CORE]<=.01)
    basis=subspace(geometry,mask)
    assert basis is not None
    noise=plan["profiles"][task["noise"]]
    role={k:native[k][:1]for k in ("packed","wb","matrix","colors")}
    local={LOCAL:parents[LOCAL][:1]}
    restored=predict(role,native["full"],noise,plan["query"],local,model)["conditional"]
    def y(o):
        return review.old.luma(o,role)[0][CORE][mask]
    parent=y(local[LOCAL])
    delta=y(restored)-parent
    error=parent-y(native["target"][:1])
    edges,strong,weak=(space@(space.T@delta)for space in basis)
    other=delta-edges-strong-weak
    candidates={"parent":error,"conditional":error+delta,"strong-only":error+strong,
                "conditional-without-strong":error+delta-strong,
                "conditional-without-weak":error+delta-weak}
    rms={k:review.rms(v)for k,v in candidates.items()}
    error_by_family={}
    for endpoint,residual in candidates.items():
        small={name:review.rms(q@(q.T@residual))for name,q in zip(("tone","strong","weak"),basis,strict=True)}
        joined=np.column_stack(basis)
        small["remaining"]=review.rms(residual-joined@(joined.T@residual))
        error_by_family[endpoint]=small
    return {"source":plan["sources"][task["index"]]["source"]["id"],"noise":task["noise"],
            "id":f'{task["index"]:03d}-{task["noise"]}',"input":task["input"],"parent":frozen,
            "gap_pixels":int(mask.sum()),"absolute_RMS_DN16":rms,"absolute_error_by_family":error_by_family,
            "added_energy_DN16_squared":{name:review.rms(vec)**2 for name,vec in
                                    (("tone",edges),("strong",strong),("weak",weak),("remaining",other))}}


def result(rows):
    names=list(rows[0]["absolute_RMS_DN16"])
    means={i:float(np.mean([r["absolute_RMS_DN16"][i]for r in rows]))for i in names}
    error={k:{band:float(np.mean([r["absolute_error_by_family"][k][band]for r in rows]))
                for band in ("tone","strong","weak","remaining")}for k in names}
    totals={}
    for part in ("tone","strong","weak","remaining"):
        totals[part]=sum(row["added_energy_DN16_squared"][part]*row["gap_pixels"] for row in rows)
    overall=sum(totals.values())
    return {"absolute_RMS":means,"error_by_family":error,"pooled_added_energy_share":{k:v/overall for k,v in totals.items()}}


def main():
    torch.set_num_threads(1)
    (phase,nets),training,endpoint=load(raw_weights=False)
    binding=reference(PRIOR/"wire-parent.json")
    scenarios=read_json(checked(binding))
    plan=read_json(checked(scenarios["plan"]))
    inputs=read_json(checked(scenarios["inputs"]))["rows"]
    entries=[row for row in inputs if plan["sources"][row["index"]]["geometry"]["family"] in ("ellipse","strip")]
    assert len(entries)==24
    captions={r["id"]:r for r in scenarios["rows"]}
    t=time.monotonic()
    records=review.run(entries,partial(record,plan=plan,lookup=captions,model=(phase,{"conditional":nets["conditional"]})))
    prior=reference(ROOT/"wire-holdout.json")
    observed={row["id"]:row for row in read_json(checked(prior))["rows"]}
    for row in records:
        old=observed[row["id"]]
        assert old["input"]==row["input"] and old["gap_pixels"]==row["gap_pixels"]
        assert abs(row["absolute_RMS_DN16"]["conditional"]-old["metrics"]["conditional"]["gap_exact"])<.001
    output={iso:result([row for row in records if row["noise"]==iso])for iso in ("iso400","iso6400")}
    write_json(ROOT/"gap-attribution.json",{"driver":reference(__file__),"projection":reference(ROOT/"gap_projection.py"),
        "training":training,"checkpoint":endpoint["checkpoint"],"parent":endpoint["parent"],
        "wire":binding,"prior":prior,"rows":records,"summary":output,"seconds":time.monotonic()-t,
        "scope":"Score-only projections in annotated exact gaps. Frequencies, edge and footprint are construction metadata. The output restorations used for numeric and native comparisons never use these masks or geometry."})
    print(output["iso6400"],flush=True)


if __name__=="__main__":
    main()
