"""Fit fixed exterior phase on overlapping subregions of the native window."""
from pathlib import Path
import sys

import numpy as np
from scipy.fft import ifft2
from scipy.special import expit
import torch

ROOT=Path(__file__).resolve().parent
MIXTURE=ROOT.parent/"phase-correction-mixture-v1"
sys.path.insert(0,str(MIXTURE))

from mixture_features import inputs, PRIOR, rgb_residual, complex_parts
from phase_edge import (FOLDS, BAYER_OFFSETS, NORMALS, POSITIONS, EDGES,
                        HALF, NATIVE, PAD, UNIQUE, XI, YI, INDEX, PHASES, fft_columns)
from demosaic.phase_witness import measure_witnesses
from activity import reliability
from head_corrected_broad import SYNTH, NATIVE_I, NATIVE_J

WINDOW=32
SUBWINDOW=20
REGIONS=tuple((y,x)for y in (0,WINDOW-SUBWINDOW) for x in (0,WINDOW-SUBWINDOW))
REGION_MIN_ENERGY=5.
MODES=("conditional","local","flipped","tile-average","local-positive")


def basis(fold,plane,region):
    coords=NATIVE[FOLDS[fold]]+BAYER_OFFSETS[plane]
    origin=np.array(region)
    valid=((coords>=origin)&(coords<origin+SUBWINDOW)).all(axis=1)
    centered=coords[valid]-15.5
    trend=np.column_stack((np.ones(len(centered)),centered/16.))
    affine=np.linalg.qr(trend)[0].T.astype(np.float32)
    edge=expit(((centered@NORMALS.T)[:,:,None]-POSITIONS)/.75).reshape(len(centered),EDGES).T
    edge-=(edge@affine.T)@affine
    norms=np.linalg.norm(edge,axis=1,keepdims=True)
    edge/=norms.clip(min=1e-7)
    qa=np.zeros((3,HALF),dtype=np.float32)
    qe=np.zeros((EDGES,HALF),dtype=np.float32)
    qa[:,valid]=affine
    qe[:,valid]=edge
    doubled=np.exp(-4j*np.pi/PAD * coords[valid] @ (UNIQUE.T/2))
    return valid,qa,qe,fft_columns(qa,fold,plane),fft_columns(qe,fold,plane),doubled.sum(0).astype(np.complex64)


CACHE=[[[basis(f,p,r) for p in range(4)]for f in range(2)]for r in REGIONS]


def projected(values,cache,fold,plane,edge,selected,phase,sigma):
    mask,qa,qe,fa,fe,double=cache
    assert len(mask)==values.shape[1]
    raw=np.take_along_axis(fft_columns(values*mask,fold,plane),selected,axis=1)
    amplitude=(raw*phase).real
    q=(fa[:,selected]*phase[None]).real
    e=(fe[edge.clip(min=0)[:,None],selected]*phase).real*(edge>=0)[:,None]
    beta=values@qa.T
    gamma=np.sum(values*qe[edge.clip(min=0)],axis=-1)[:,None]
    dot=amplitude-np.einsum("wq,qwf->wf",beta,q)-e*gamma
    energy=.5*(mask.sum()+np.real(double[selected]*phase**2))-np.sum(q*q,axis=0)-e*e
    return np.where(energy>=REGION_MIN_ENERGY,dot/(sigma*np.sqrt(energy.clip(min=1e-7))),0.)


def evidence(raw,layout,noise,phase,edges):
    work=np.lib.stride_tricks.sliding_window_view(raw,(16,16),axis=(-2,-1))
    windows=work[:,YI,XI].reshape(4,len(XI),-1)
    greens=np.flatnonzero(layout==1)
    splits=[[np.ascontiguousarray(windows[p][:,FOLDS[j]])for p in greens]for j in range(2)]
    bins=INDEX[PHASES,phase.offsets]
    conjugate=phase.phase.conj()
    values=[]
    for k in range(len(REGIONS)):
        folds=[]
        for nominate in range(2):
            reserve=1-nominate
            scores=[]
            for i,p in enumerate(greens):
                observed=splits[reserve][i]
                sigma=np.sqrt((noise["shot"]*splits[nominate][i].mean(axis=1).clip(min=0)+noise["read"]).clip(min=2e-11))[:,None]
                scores.append(projected(observed,CACHE[k][reserve][p],reserve,p,edges[nominate],bins,conjugate,sigma))
            folds.append((scores[0]+scores[1])*np.float32(2**-.5))
        values.append(np.minimum(folds[0],folds[1]))
    return np.asarray(values,dtype=np.float32)


def partition():
    a=((np.arange(WINDOW,dtype=np.float32)+.5-(WINDOW-SUBWINDOW))/(2*SUBWINDOW-WINDOW)).clip(0,1)
    a=a*a*(3-2*a)
    weights=np.stack((1-a,a))
    return (weights[:,None,:,None]*weights[None,:,None,:]).reshape(4,WINDOW,WINDOW)


PARTITION=partition()
COORD=tuple(zip(YI*2,XI*2,strict=True))


def synthesize(coeff, field):
    dense=np.zeros((len(REGIONS),len(XI),WINDOW,WINDOW),dtype=np.complex64)
    dense[...,NATIVE_I,NATIVE_J]=coeff
    dense[...,-NATIVE_I,-NATIVE_J]=coeff.conj()
    frames=(2*ifft2(dense,norm="ortho").real*PARTITION[:,None]).sum(0)
    result=np.zeros((256,256),dtype=np.float64)
    weight=np.zeros_like(result)
    for (y,x),sample in zip(COORD,frames,strict=True):
        box=np.s_[y:y+WINDOW,x:x+WINDOW]
        result[box]+=sample*SYNTH
        weight[box]+=SYNTH**2
    index=np.arange(256)+.5
    side=np.minimum(index,index[::-1])
    bound=((side-8)/24).clip(0,1)
    rgb=result/np.maximum(weight,.05)*bound[:,None]*bound[None,:]
    return ((field.neutral/field.neutral[1])[:,None,None]*rgb[None]).astype(np.float32)


@torch.inference_mode()
def residuals(raw,pattern,noise,box,donors,parent,wb,matrix,model, *, output=MODES):
    component,router=model
    rows=inputs(raw,pattern,noise,box,donors,parent,wb,matrix,component,keep_evidence=True)
    field,_,frozen,experts,desc,phase,edges=rows
    value=router(torch.from_numpy(desc),torch.from_numpy(complex_parts(frozen)),torch.from_numpy(experts)).numpy()
    wave=value[...,0]+1j*value[...,1]
    confidence=reliability(evidence(raw,pattern,noise,phase,edges),0,.75)
    average=confidence.mean(0,keepdims=True)
    variants={}
    for policy in output:
        if policy=="conditional":
            correction=rgb_residual(wave,field)
        elif policy=="local-positive":
            correction=synthesize(wave[None]*confidence,field)
        elif policy=="tile-average":
            correction=rgb_residual(wave*average[0],field)
        else:
            shape=confidence if policy=="local" else confidence[::-1]
            correction=synthesize(wave[None]*(1.+.95*(shape-average)),field)
        variants[policy]=correction
    return variants,confidence
