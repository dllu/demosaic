"""Measure regional phase delivery at matched correction strength."""
from functools import partial
import sys
import time

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt

from envelope import ROOT, MIXTURE, PRIOR, MODES, residuals
from evaluate_mixture import load
from demosaic.experiments.artifacts import checked, reference, read_json, write_json
from review_quiet import LOCAL, photo_inputs, wire_inputs, CORE, numeric
from demosaic.archive_metrics import photometry
import evaluate_gap_head as review


def attach_models():
    torch.set_num_threads(1)
    fitted,trained,endpoint=load(raw_weights=False)
    return (fitted[0],fitted[1]["conditional"]),trained,endpoint


def all_corrections(native, surround, noise, box, parents, model):
    donors=review.exterior(surround,native["colors"][0],noise,box)
    stores={}
    confidence=[]
    for raw,pattern,wb,matrix,stored in zip(native["packed"],native["colors"],native["wb"],
                                             native["matrix"],parents[LOCAL],strict=True):
        change,trust=residuals(raw,pattern,noise,box,donors,stored,wb,matrix,model)
        for mode,delta in change.items():
            stores.setdefault(mode,[]).append(delta)
        confidence.append(trust)
    return {k:np.stack(v)for k,v in stores.items()},np.stack(confidence)


def add_controls(parents, correction, scales):
    local=parents[LOCAL]
    return parents | {k:local+v for k,v in correction.items()} | {
        name:local+np.float32(scale)*correction["conditional"]for name,scale in scales.items()}


def photo(pointer, model, scales):
    row,data,parents,verified=photo_inputs(pointer)
    correction,conf=all_corrections(data,data["scene_packed"],row["profile"],row["box"],parents,model)
    options=add_controls(parents,correction,scales)
    bands=partial(review.old.target_coeff,calibration=data,roi=review.old.ROI)
    exact=bands(data["target"])
    frozen=bands(parents[LOCAL])
    increment=exact[0]-exact[1]
    expo=row["profile"]["exposure"]
    metrics={}
    for name,result in options.items():
        band=bands(result)
        change=band[0]-band[1]
        dot,power=review.aligned(increment.ravel(),change.ravel())
        metrics[name]={"intact_dot":dot,"intact_power":power,
                "increment_rms":review.old.source_rms(change-increment,96**2),
                "flat_rms":review.old.source_rms(band[2]-exact[2],96**2),
                "flat_added":review.old.source_rms(band[2]-frozen[2],96**2),
                "present_rms":review.old.source_rms(band[0]-exact[0],96**2),
                "srgb_present_psnr":float(photometry(result/expo,data|{"target":data["target"]/expo})["srgb_psnr"][0])}
    return {"id":row["id"],"source_id":row["source"],"profile":row["profile"]["name"],"draw":row["draw"],
            "input":row["input"],"local_outputs":verified,"mean_regional_support":conf.mean(axis=(1,2,3)).tolist(),
            "metrics":metrics|{"matched":metrics[LOCAL]}}


def projection(error, template):
    den=float(np.sum(template**2))
    if den<1e-10:
        return None,None,None
    gain=float(np.sum(error*template))/den
    coherent=template*gain
    return gain,review.rms(coherent),review.rms(error-coherent)


def wire(task, plan, lookup, v120, model, scales):
    native,parents,verified=wire_inputs(task,lookup,v120)
    iso=task["noise"]
    shot=plan["profiles"][iso]
    scene=plan["sources"][task["index"]]
    delta,conf=all_corrections(native,native["full"],shot,plan["query"],parents,model)
    original=parents[LOCAL]
    outputs=add_controls(parents,delta,scales)
    support=native["support"][CORE]
    gap=support<=.01
    intact=support>=.97
    mask=native["support"]<=.01
    # Score-only, ideal rejection mask for the exact missing center.
    oracle=np.where(mask,0.,delta["conditional"])
    outputs["known-gap-zero"]=original+oracle
    def luma(rgb):
        return review.old.luma(rgb,native)[...,CORE[0],CORE[1]]
    target=luma(native["target"])
    baseline=luma(original)
    true_increment=target[0]-target[1]
    with np.load(checked(task["input"]),allow_pickle=False)as bank:
        saved=bank["weak_linear"]
        linear=np.einsum("c,chw->hw",np.asarray([.2126,.7152,.0722]),saved) if saved.ndim==3 else saved
        template=linear[CORE]*shot["exposure"]
    np.testing.assert_allclose(true_increment[intact],(template*support)[intact],atol=6e-6,rtol=0.001)
    inner=gap&(distance_transform_edt(gap)>=8) if gap.any() else np.zeros_like(gap)
    rim=gap&~inner
    scores={}
    for name,rgb in outputs.items():
        y=luma(rgb)
        inc=y[0]-y[1]
        change=y-baseline
        dot,power=review.aligned(true_increment[intact],inc[intact])
        gain,coherent,residual=projection(change[0][gap],template[gap])
        total_sign,_,_=projection((y[0]-target[0])[gap],template[gap])
        scores[name]={"intact_dot":dot,"intact_power":power,"intact_rms":review.rms((inc-true_increment)[intact]),
             "present_rms":review.rms(y[0]-target[0]),"gap_exact":review.rms((y[0]-target[0])[gap]) if gap.any() else None,
             "gap_added":review.rms(change[0][gap]) if gap.any() else None,
             "gap_pair":review.rms((inc-true_increment)[gap]) if gap.any() else None,
             "gap_coherent_added":coherent,"gap_unaligned_added":residual,
             "gap_signed_fraction":gain,"gap_total_signed_fraction":total_sign,
             "gap_rim_added":review.rms(change[0][rim]) if rim.any()else None,
             "gap_center_added":review.rms(change[0][inner]) if inner.any()else None,
             "flat_added":review.rms(change[3,8:-8,8:-8])}
    return {"id":f'{task["index"]:03d}-{iso}',"source_id":scene["source"]["id"],"profile":iso,
            "family":scene["geometry"]["family"],"input":task["input"],"local_output":verified,
            "gap_pixels":int(gap.sum()),"gap_center_pixels":int(inner.sum()),"gap_rim_pixels":int(rim.sum()),
            "metrics":scores|{"matched":scores[LOCAL]}}


def calibration_scales(rows,key):
    metrics=review.score_group(rows)
    cap=metrics["conditional"][key]["mean"]
    return {f"scaled-to-{name}":metrics[name][key]["mean"]/max(cap,1e-12)for name in MODES[1:]}


def main(kind):
    model,training,endpoint=attach_models()
    previous=reference(MIXTURE/(kind+"-holdout.json"))
    controls=read_json(checked(previous))
    earlier={row["id"]:row for row in controls["rows"]}
    stamp={"driver":reference(__file__),"method":reference(ROOT/"envelope.py"),
           "checkpoint":endpoint["checkpoint"],"training":training,"parent":endpoint["parent"],
           "prior_metrics":previous,"features":reference(ROOT/"mixture_features.py")}
    start=time.monotonic()
    if kind=="photo":
        old=read_json(PRIOR/"natural-results.json")
        examples=read_json(checked(old["inputs"]))["records"]
        reserve=review.panel_membership()
        pool={False:[],True:[]}
        for proof in examples:
            descriptor=read_json(checked(read_json(checked(proof))["case"]))
            if descriptor["draw"]=="independent" and descriptor["profile"]["name"]=="iso6400":
                pool[descriptor["source"]in reserve].append(proof)
        assert len(pool[True])==16 and len(pool[False])==48
        tune=review.run(pool[True],partial(photo,model=model,scales={}))
        scales=calibration_scales(tune,"flat_added")
        rows=review.run(pool[False],partial(photo,model=model,scales=scales))
        cohorts={"iso6400/independent":rows}
        metrics=("intact_response","increment_rms","flat_rms","flat_added")
    else:
        reference_wire=read_json(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")
        v120={row["input"]["sha256"]:row for row in reference_wire["rows"]}
        def from_archive(name,scales,references):
            note=read_json(PRIOR/f"{name}-parent.json")
            catalog={r["id"]:r for r in note["rows"]}
            inputs=read_json(checked(note["inputs"]))["rows"]
            plan=read_json(checked(note["plan"]))
            return review.run(inputs,partial(wire,model=model,plan=plan,lookup=catalog,v120=references,scales=scales))
        tune=from_archive("wire-tune",{},None)
        selected=[row for row in tune if row["gap_pixels"]]
        assert len(selected)==12
        scales=calibration_scales(selected,"gap_added")
        rows=from_archive("wire",scales,v120)
        cohorts={iso:[r for r in rows if r["profile"]==iso]for iso in ("iso400","iso6400")}
        metrics=("intact_response","intact_rms","gap_exact","gap_added","gap_pair",
                 "gap_coherent_added","gap_unaligned_added","gap_rim_added","gap_center_added","flat_added")
    pairs=[(arm,ctrl)for arm in MODES[1:] for ctrl in ("conditional",f"scaled-to-{arm}",LOCAL)]
    pairs.extend([("local","flipped"),("local-positive","tile-average"),("local-positive","local")])
    for row in rows:
        old=earlier[row["id"]]
        assert row["input"]==old["input"] and row["source_id"]==old["source_id"]
        field="local_outputs" if kind=="photo" else "local_output"
        previous_output="local20k_outputs" if kind=="photo" else "local20k_output"
        assert row[field]==old[previous_output]
        expected=old["metrics"]["conditional"]
        check_keys=("flat_rms","increment_rms")if kind=="photo"else ("gap_exact","intact_rms","flat_added")
        for key in check_keys:
            real=row["metrics"]["conditional"][key]
            if real is not None:
                assert abs(real-expected[key])<.005,(row["id"],key,real,expected[key])
    write_json(ROOT/f"{kind}-calibration.json",stamp|{"rows":tune,"scales":scales})
    write_json(ROOT/f"{kind}-holdout.json",stamp|{"rows":rows,"scales":scales,
        "calibration":reference(ROOT/f"{kind}-calibration.json"),"reports":numeric(cohorts,pairs,metrics),
        "seconds":time.monotonic()-start})


if __name__=="__main__":
    main(sys.argv[1])
