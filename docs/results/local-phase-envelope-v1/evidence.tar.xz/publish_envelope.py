"""Publish native image comparisons and byte-exact method and measurement receipts."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name


def read(name):
    return json.loads((ROOT/name).read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def reference(path):
    return {"path":str(path),"sha256":sha(path)}


def check(record, local=None):
    assert sha(Path(record["path"]) if local is None else local)==record["sha256"], record


def write(path, record):
    path.write_text(json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)+"\n")


def transfer(entry, directory):
    binding=entry["image"]
    original=Path(binding["path"])
    path=IMAGES/directory/original.name
    path.parent.mkdir(parents=True,exist_ok=True)
    check(binding)
    shutil.copyfile(original,path)
    check(binding,path)
    binding["path"]=path.relative_to(IMAGES).as_posix()
    with Image.open(path) as im:
        pieces={}
        for panel in entry["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160)
            assert 0<=x<=im.width-w and 0<=y<=im.height-h
            pieces[panel.get("label") or panel["name"]]=im.crop((x,y,x+w,y+h))
        assert len(pieces)==len(entry["panels"])
    return pieces


def review(training, pointer):
    manifests={}
    for directory,n in (("exact",3),("standing",8)):
        data=read(directory+"/manifest.json")
        assert data["checkpoint"]==training["checkpoint"] and data["parent"]==training["parent"] and len(data["rows"])==n
        assert data.get("training",data.get("weights"))==pointer
        check(data["driver"])
        for row in data["rows"]:
            frames=transfer(row["board"],directory)
            if directory=="standing":
                continue
            for trio in (row["triplet"],*row.get("other_triplets",{}).values()):
                pages=transfer(trio,directory)
                assert len(pages)==3
                for name,img in pages.items():
                    assert ImageChops.difference(img,frames[name]).getbbox() is None
        manifests[directory]=data
    manifests["native_image_review"]={
        "completed":True,"standing":8,"exact_comparisons":3,"exact_triplets":9,
        "notes":"All variants keep the sky smooth. The coarse lattice retains crossed wires, while building wires and fine foliage stay soft. The left cab remains mottled in places. The right retains some existing diagonals under both profiles, with incomplete fine junctions and no convincing new crossings over the conditional blend."
    }
    output=IMAGES/"manifest.json"
    write(output,manifests)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":sha(output)}


def archive(name, files):
    path=OUT/name
    names=sorted(files)
    with tarfile.open(path,"w:xz",preset=5)as bundle:
        for key in names:
            bundle.add(files[key],arcname=key,recursive=False)
    with tarfile.open(path)as bundle:
        assert bundle.getnames()==names
        for key in names:
            with bundle.extractfile(key)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==sha(files[key])
    return {"path":name,"sha256":sha(path),"entries":len(files)}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    photo=read("photo-holdout.json")
    wire=read("wire-holdout.json")
    trained=photo["training"]
    check(trained)
    completed=json.loads(Path(trained["path"]).read_text())
    for key in ("checkpoint","parent","frozen_phase_checkpoint"):
        check(completed[key])
    for panel,num,calibrated in (("photo",48,16),("wire",48,24)):
        for stage,count in (("holdout",num),("calibration",calibrated)):
            data=read(f"{panel}-{stage}.json")
            assert len(data["rows"])==count and data["training"]==trained
            assert data["checkpoint"]==completed["checkpoint"] and data["parent"]==completed["parent"]
            for key in ("driver","method","prior_metrics","features"):
                check(data[key])
    for key in ("audit.json","gap-attribution.json"):
        data=read(key)
        check(data["driver"])
    assert len(read("gap-attribution.json")["rows"])==24
    fresh=review(completed,trained)
    records=[
        "envelope.py","mixture_features.py","gap_projection.py","evaluate_envelope.py",
        "audit_envelope.py","attribute_gap.py","render_envelope.py","publish_envelope.py",
        "photo-holdout.json","wire-holdout.json","photo-calibration.json","wire-calibration.json",
        "audit.json","gap-attribution.json","exact/manifest.json","standing/manifest.json","tests.log",
    ]
    prior=ROOT.parent/"phase-correction-mixture-v1"
    verify_paths={f"upstream/{k}":prior/k for k in ("mixture.py","evaluate_mixture.py","training/completed.json")}
    verify_paths["upstream/phase_edge.py"]=ROOT.parent/"phase-edge-validation-v1/phase_edge.py"
    output=archive("evidence.tar.xz",{path:ROOT/path for path in records}|verify_paths)
    early_paths={p.relative_to(ROOT).as_posix():p for p in (ROOT/"initial-localization").iterdir()}
    early_paths|={key:ROOT/key for key in (
        "attribute-first.py","gap-attribution-initial.json","attribution-initial.log","initial-evaluation.py",
        "initial-wire.log","initial-render.py","initial-standing.log","render-second.py","standing-second.log",
        "initial-exact/manifest.json","exact-second/manifest.json")}
    early=archive("earlier-audits.tar.xz",early_paths)
    write(OUT/"publication.json",{
        "experiment":ROOT.name,"local_parent":completed["parent"],
        "frozen_phase_component":completed["frozen_phase_checkpoint"],"frozen_mixture":completed["checkpoint"],
        "weight_policy":"Conditional mixture EMA. Regional delivery and geometric score diagnostics add no trained weights.",
        "scoped_evaluation_complete":True,"native_image_review_complete":True,
        "fixed_427_photo_and_camera_panels":"Outside the crop method diagnostic",
        "evidence":output,"earlier_audits":early,"presentation":fresh,
        "directional_attribution":read("gap-attribution.json")["summary"],
        "photo_summary":photo["reports"]["iso6400/independent"],"wire_summary":wire["reports"]["iso6400"]
    })
    print("Verified frozen sources, matched measurements and native comparison pixels.")


if __name__=="__main__":
    main()
