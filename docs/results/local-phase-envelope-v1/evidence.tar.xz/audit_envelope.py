"""Check regional projection, synthesis and missing-template attribution."""
import time
from types import SimpleNamespace

import numpy as np
from scipy.special import expit

from envelope import ROOT, CACHE, PARTITION, REGIONS, HALF, FOLDS, NATIVE, BAYER_OFFSETS, UNIQUE, XI, YI
from envelope import synthesize, projected, rgb_residual
from demosaic.phase_witness import STEP, BASE
from demosaic.experiments.artifacts import reference, write_json
from gap_projection import subspace, summarize, X, Y


def test_contract():
    rng=np.random.default_rng(64917)
    high=0.
    for region in range(len(REGIONS)):
        fold,plane,nuisance=region%2,(region+1)%4,43+region
        mask,aff,edges,*_=CACHE[region][fold][plane]
        measured=rng.uniform(.1,.3,(1,HALF)).astype(np.float32)
        selected=np.arange(0,len(UNIQUE),19)[None]
        phase=np.exp(-1j*rng.uniform(-np.pi,np.pi,selected.shape)).astype(np.complex64)
        got=projected(measured,CACHE[region][fold][plane],fold,plane,np.array([nuisance]),selected,phase,np.ones((1,1)))[0]
        xy=NATIVE[FOLDS[fold]]+BAYER_OFFSETS[plane]
        expo=np.exp(-2j*np.pi*xy@(STEP*UNIQUE[selected[0]].T))
        waves=(expo*phase).real*mask[:,None]
        required=np.vstack((aff,edges[nuisance:nuisance+1])).astype(np.float64)
        waves-=required.T@(required@waves)
        den=np.sum(waves*waves,axis=0)
        want=np.where(den>=5.,(measured@waves)[0]/np.sqrt(den.clip(min=1e-7)),0.)
        np.testing.assert_allclose(got,want,atol=3e-5,rtol=0)
        high=max(high,float(abs(got-want).max()))
    np.testing.assert_array_equal(PARTITION.sum(0),1.)
    wave=(rng.normal(size=(len(XI),len(BASE)))+1j*rng.normal(size=(len(XI),len(BASE)))).astype(np.complex64)*.006
    scene=SimpleNamespace(neutral=np.array([.8,1.,.6]))
    expected=rgb_residual(wave,scene)
    partitioned=synthesize(np.broadcast_to(wave,(4,*wave.shape)),scene)
    np.testing.assert_allclose(partitioned,expected,atol=2e-8,rtol=0)
    return {"projected_score_max_abs":high,"unchanged_spectrum_max_abs_RGB":float(abs(partitioned-expected).max()),
            "partition_of_unity_error":float(abs(PARTITION.sum(0)-1.).max())}


def main():
    start=time.monotonic()
    result=test_contract()
    mask=(X**2+Y**2)<42**2
    geometry={"frequency":[[.1,.07],[.13,-.10]],"angle":.18,"edge":2.}
    span=subspace(geometry,mask)
    bank=np.column_stack(span)
    np.testing.assert_allclose(bank.T@bank,np.eye(bank.shape[1]),rtol=0,atol=1e-12)
    fair=np.zeros_like(X)
    a,b=geometry["frequency"][1]
    fair[mask]=np.sin(2*np.pi*(a*X[mask]+b*Y[mask])+.8)
    score=summarize(fair,fair,mask,span)
    np.testing.assert_allclose(score["gap_other_added"],0.,atol=.02,rtol=0)
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"envelope":reference(ROOT/"envelope.py"),
        "gap_projection":reference(ROOT/"gap_projection.py"),"seconds":time.monotonic()-start,
        "controls":result,"span_dimension":bank.shape[1],"pure_weak_frequency_unexplained_DN16":score["gap_other_added"]})
    print(result,flush=True)
if __name__=="__main__":
    main()
