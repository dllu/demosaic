"""Verify source and fifth-visit coverage through the 80k update prefix."""

from collections import Counter, defaultdict
import hashlib
from itertools import combinations
import json
from pathlib import Path

import numpy as np
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
old_path = Path("docs/results/full-corpus-long50k-prefix-v1/source-and-crop-audit.json")
old = read_json(old_path)
earlier_path = Path("docs/results/full-corpus-long72k-prefix-v1/source-audit.json")
earlier = read_json(earlier_path)
checked(old["training_plan"])
header_path = checked(old["photo_order"])
header = read_json(header_path)
order = np.load(
    checked(header["order"] | {"path": str(header_path.parent / header["order"]["path"])})
)
with checked(header["source_manifest"]).open() as f:
    photos = [r for line in f if (r := json.loads(line))["split"] == "train"]
assert len(photos) == len({r["id"] for r in photos}) == old["ordinary_distinct"]
ids = [row["id"] for row in photos]
areas = {row["id"]: np.prod(row["shape"][:2]).item() for row in photos}
cfg = yaml.safe_load(checked(old["training_config"]).read_bytes())
cfg = cfg.get("train", cfg)
assert cfg["steps"] == 100_000 and cfg["batch_size"] == 16
boxes = defaultdict(list)
visits = Counter()
epochs = {}
domains = Counter()
prefixes = []
for binding, stop in zip(old["source_log_prefixes"], (1000, 80000), strict=True):
    p = Path(binding["path"])
    digest = hashlib.sha256()
    with p.open("rb") as stream:
        for step in range(binding["start_step"], stop + 1):
            line = next(stream)
            digest.update(line)
            if step == binding["stop_step"]:
                assert stream.tell() == binding["prefix_bytes"]
                assert digest.hexdigest() == binding["prefix_sha256"]
            if step == 72000:
                prior = earlier["source_prefixes"][-1]
                assert stream.tell() == prior["prefix_bytes"]
                assert digest.hexdigest() == prior["prefix_sha256"]
            row = json.loads(line)
            pos = (step - 1) * 16
            assert (row["step"], row["global_draw_start"]) == (step, pos)
            seed = hashlib.sha256(f"data:{cfg['seed']}:{step}".encode()).digest()
            assert row["data_RNG_seed"] == int.from_bytes(seed[:8], "little") % 2**63
            domain = row["domain"]
            domains[domain] += 1
            idx = order[pos : pos + 16]
            if domain != "commons":
                assert not row["sources"] and np.all(idx == -1)
                continue
            for item, expected in zip(row["sources"], idx, strict=True):
                if expected == -1:
                    assert item["kind"] != "photographic" or item["reviewed_roi_xywh"] is not None
                    continue
                sid = ids[expected]
                assert item["kind"] == "photographic" and item["reviewed_roi_xywh"] is None
                assert (
                    item["source_id"] == sid
                    and item["draw_seed"] == cfg["seed"] + item["draw_index"]
                )
                assert item["photo_epoch_order_sha256"] == old["photo_order"]["sha256"]
                boxes[sid].append(tuple(item["cache_xywh"]))
                count = len(boxes[sid])
                visits[count] += 1
                if visits[count] == len(ids):
                    epochs[count] = step
        prefixes.append(
            {
                "path": str(p),
                "step": stop,
                "prefix_bytes": stream.tell(),
                "prefix_sha256": digest.hexdigest(),
            }
        )
assert list(epochs.values()) == [17039, 33985, 51009, 68269]
assert sum(domains.values()) == 80000 and max(map(len, boxes.values())) == 5
extra_conditions = []
for step in range(72001, 80001, 250):
    path = Path(prefixes[-1]["path"]).parent / f"conditions-{step:06d}-{step + 249:06d}.npz"
    with np.load(path) as f:
        np.testing.assert_array_equal(f["steps"], np.arange(step, step + 250))
        assert f["values"].shape == (250, 16, 14) and np.isfinite(f["values"]).all()
    extra_conditions.append(reference(path))


def intersection(rectangles):
    return max(
        0, min(x + w for x, y, w, h in rectangles) - max(x for x, y, w, h in rectangles)
    ) * max(0, min(y + h for x, y, w, h in rectangles) - max(y for x, y, w, h in rectangles))


def union(rectangles):
    return sum(
        (-1) ** (count + 1) * sum(intersection(g) for g in combinations(rectangles, count))
        for count in range(1, len(rectangles) + 1)
    )


def q(values):
    return np.quantile(values, [0.1, 0.5, 0.9]).tolist()


fifth = {sid: v for sid, v in boxes.items() if len(v) == 5}
added = {sid: union(v) - union(v[:4]) for sid, v in fifth.items()}
result = {
    "producer": reference(__file__),
    "old_prefix": reference(old_path),
    "prefix_72k": reference(earlier_path),
    "training_plan": old["training_plan"],
    "order": old["photo_order"],
    "source_prefixes": prefixes,
    "additional_conditioning_chunks": extra_conditions,
    "epochs_completed_at_update": epochs,
    "completed_prefix_updates": 80000,
    "target_slots": 80000 * 16,
    "domain_updates": domains,
    "ordinary_distinct": len(boxes),
    "ordinary_draws": sum(map(len, boxes.values())),
    "ordinary_visit_histogram": Counter(map(len, boxes.values())),
    "fifth_visit_added_area_ratio_10_50_90": q(
        [extra / areas[sid] for sid, extra in added.items()]
    ),
    "fifth_visit_no_new_cache_pixels": sum(v == 0 for v in added.values()),
    "fifth_visit_cumulative_area_ratio_10_50_90": q(
        [union(v) / areas[sid] for sid, v in fifth.items()]
    ),
    "scope": "Executed source repetition and cache rectangles before augmentation. The latest evaluated checkpoint is 50k. The source and conditioning audit is independent of restoration quality.",
}
write_json(root / "result.json", result)
print(
    {
        k: result[k]
        for k in (
            "epochs_completed_at_update",
            "ordinary_draws",
            "ordinary_visit_histogram",
            "fifth_visit_added_area_ratio_10_50_90",
            "fifth_visit_no_new_cache_pixels",
            "fifth_visit_cumulative_area_ratio_10_50_90",
        )
    }
)
