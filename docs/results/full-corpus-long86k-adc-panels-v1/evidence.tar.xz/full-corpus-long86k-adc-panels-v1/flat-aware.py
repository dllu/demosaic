"""Replay the optional flat-code switch on immutable prediction tensors."""

from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from numpy.lib.stride_tricks import sliding_window_view
from report_full_faint_photo_panel import ADC, score, source_balance

from analyze import ROOT, encode32, paired_data
from demosaic.adc_bins import adc_bin_projection
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

MODE = "flat-aware"
POLICY = f"ADC-bins-{MODE}"


def observed(obs):
    with np.load(checked(obs["arrays"])) as f:
        return tuple(torch.from_numpy(f[key]) for key in ("packed", "colors", "wb"))


def photos():
    pairs, models, proof = paired_data("faint")
    archived = ROOT / "review-faint-v2/result.json"
    old_rows = {
        (r["model"], r["policy"], r["source"], r["CFA"]): r
        for r in read_json(archived)["rows"]
    }
    rows, support, changed = [], [], defaultdict(int)
    for obs, case in pairs:
        results, inputs, predictions = score(obs, case, models, lift_modes=(MODE,))
        raw = inputs["packed"]
        # NumPy windows independently reproduce the per-phase constancy decision.
        windows = sliding_window_view(
            np.pad(raw, ((0, 0), (0, 0), (1, 1), (1, 1)), mode="edge"), (3, 3), axis=(-2, -1)
        )
        flat = (windows.max((-2, -1)) == windows.min((-2, -1))).all(1)
        pixels = flat.repeat(2, axis=1).repeat(2, axis=2)
        for model, output in predictions.items():
            same = (output[POLICY] == output["ADC-bins-Malvar"]).all(1)
            assert same[~pixels].all()
            changed[model] += int((~same).sum())
        support.append({"id": obs["id"], "count": int(flat.sum()), "total": flat.size})
        for r in results:
            if r["policy"] == POLICY:
                rows.append(r)
            else:
                assert r == old_rows[r["model"], r["policy"], r["source"], r["CFA"]]
    bands = source_balance(rows)
    summary = []
    for model in models:
        b = next(r for r in bands if (r["model"], r["band"]) == (model, "0"))
        selected = [r["photometry"]["srgb_psnr"] for r in rows if r["model"] == model]
        assert len(selected) == 256
        summary.append(
            {
                "model": model,
                "mean_sRGB_PSNR": mean(selected),
                "weakest_band_DN16": b["equal_source_RMS_DN16"],
                "signed_response": b["equal_source_gain"],
                "changed_native_pixels": changed[model],
            }
        )
    return {
        "dependencies": [reference(archived), *proof],
        "support": support,
        "flat_packed_locations": sum(r["count"] for r in support),
        "packed_locations": sum(r["total"] for r in support),
        "summary": summary,
        "rows": rows,
        "bands": bands,
    }


def palette():
    pairs, _, proof = paired_data("palette")
    rows = []
    calibration = ADC | {"quantizer_precision": "float32"}
    for obs, case in pairs:
        packed, colors, wb = observed(obs)
        codes = encode32(packed.numpy())
        assert (codes == codes[..., :1, :1]).all()
        for variant in case["variants"]:
            p = torch.from_numpy(np.load(checked(variant["prediction"])))
            actual = adc_bin_projection(p, packed, colors, wb, **calibration, mode=MODE)
            expected = adc_bin_projection(p, packed, colors, wb, **calibration, mode="bilinear")
            assert torch.equal(actual, expected)
            rows.append({"id": obs["id"], "model": variant["label"], "prediction": variant["prediction"]})
    assert len(rows) == 1176
    return {
        "dependencies": proof,
        "constant_by_phase_input_count": len(pairs),
        "outputs_equal_to_bilinear": len(rows),
        "records": rows,
    }


def positive_noise(path, select):
    plan, collection = path / "plan.json", path / "collection/result.json"
    plan_binding, collection_binding = reference(plan), reference(collection)
    coll = read_json(checked(collection_binding))
    assert coll["plan"] == plan_binding
    rows = []
    for obs, r in zip(read_json(checked(plan_binding))["observations"], coll["records"], strict=True):
        if not select(obs):
            continue
        case = read_json(checked(r))
        assert obs["id"] == case["id"]
        packed, colors, wb = observed(obs)
        params = ADC | {k: obs["noise"][k] for k in ("shot", "read")}
        assert params["shot"] > 0 or params["read"] > 0
        for variant in case["variants"]:
            p = torch.from_numpy(np.load(checked(variant["prediction"])))
            assert adc_bin_projection(p, packed, colors, wb, **params, mode=MODE) is p
            rows.append({"id": obs["id"], "model": variant["label"], "prediction": variant["prediction"]})
    return {"dependencies": [plan_binding, collection_binding], "identity_checks": len(rows), "records": rows}


@torch.inference_mode()
def run():
    torch.set_num_threads(3)
    out = ROOT / "flat-aware-result.json"
    assert not out.exists()
    selected = photos()
    print(selected["summary"], selected["flat_packed_locations"], selected["packed_locations"], flush=True)
    colors = palette()
    print("palette", colors["outputs_equal_to_bilinear"], flush=True)
    noise = positive_noise(ROOT.parent / "full-corpus-long86k-faint-noise-v1", lambda obs: True)
    gfx = positive_noise(
        ROOT.parent / "full-corpus-long86k-native-v1", lambda obs: obs["kind"] in ("gfx", "mesh")
    )
    assert noise["identity_checks"] == 96 and gfx["identity_checks"] == 18
    write_json(
        out,
        {
            "producer": reference(Path(__file__)),
            "implementation": reference("src/demosaic/adc_bins.py"),
            "photos": selected,
            "palette": colors,
            "positive_noise": noise,
            "GFX": gfx,
            "new_neural_calls": 0,
        },
    )


if __name__ == "__main__":
    run()
