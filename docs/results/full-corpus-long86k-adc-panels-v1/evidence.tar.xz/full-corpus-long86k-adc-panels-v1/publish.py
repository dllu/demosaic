"""Publish the audited photo and calibration panels with their inspected native crops."""

import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SPOT = ROOT.parent / "full-corpus-long86k-adc-lift-spot-v1"
NOISE = ROOT.parent / "full-corpus-long86k-faint-noise-v1"
RESULTS = {
    "faint": ROOT / "review-faint-v2/result.json",
    "palette": ROOT / "review-palette/result.json",
    "spot": SPOT / "result.json",
    "noise": NOISE / "review/result.json",
}
AUDIT = ROOT / "independent-audit.json"
FLAT = ROOT / "flat-aware-result.json"
audit = read_json(AUDIT)
flat = read_json(FLAT)
assert audit["status"] == "passed"
assert "101 passed" in (ROOT / "tests-flat-aware.log").read_text()
assert flat["implementation"] == reference("src/demosaic/adc_bins.py")
assert flat["photos"]["packed_locations"] == 4194304
assert flat["palette"]["outputs_equal_to_bilinear"] == 1176

images = Path("docs/images") / ROOT.name
out = Path("docs/results") / ROOT.name
images.mkdir()
out.mkdir()
reports = {k: read_json(v) for k, v in RESULTS.items()}


def adopt(scope, binding):
    path = checked(binding)
    result = images / scope / path.name
    result.parent.mkdir(exist_ok=True)
    shutil.copyfile(path, result)
    assert reference(result)["sha256"] == binding["sha256"]
    return result.relative_to(images).as_posix()


manifest = images / "manifest.json"
boards = {
    group: [
        {k: v for k, v in row.items() if k not in ("board", "triplet")}
        | {
            kind: row[kind] | {"file": adopt(group, row[kind]["image"])}
            for kind in ("board", "triplet")
            if kind == "board" or group in ("faint", "noise")
        }
        for row in r["boards"]
    ]
    for group, r in reports.items()
}
write_json(
    manifest,
    {
        "scope": "Viewed native comparisons. The first two fixed photo IDs and two constructed noisy "
        "materials include the viewed triplet subsets. GFX positive-noise identity comparisons link "
        "to the previously inspected 86k plates.",
        "boards": boards,
        "GFX_reference": reference("docs/images/full-corpus-long86k-native-v1/manifest.json"),
    },
)

summary = out / "summary.json"
write_json(
    summary,
    {
        "results": {k: reference(v) for k, v in RESULTS.items()},
        "faint": [
            {"source_count": 64} | {k: v for k, v in r.items() if k != "sources"}
            for r in reports["faint"]["summary"]
        ],
        "faint_paired_deltas": reports["faint"]["paired"],
        "palette": reports["palette"]["summary"],
        "positive_noise": reports["noise"]["summary"],
        "native_spot": reports["spot"]["summary"],
        "flat_aware": {
            "result": reference(FLAT),
            "faint": flat["photos"]["summary"],
            "flat_packed_locations": flat["photos"]["flat_packed_locations"],
            "packed_locations": flat["photos"]["packed_locations"],
            "palette_outputs_equal_to_bilinear": flat["palette"]["outputs_equal_to_bilinear"],
            "positive_noise_checks": flat["positive_noise"]["identity_checks"],
            "real_GFX_checks": flat["GFX"]["identity_checks"],
        },
        "audit": reference(AUDIT),
    },
)
shutil.copyfile(AUDIT, out / "independent-audit.json")

members = {}
for folder, assets in (
    (
        ROOT,
        (
            "plan.json",
            "prepare.py",
            "analyze-first.py",
            "analyze.py",
            "audit.py",
            "flat-aware.py",
            "flat-aware.log",
            "flat-aware-result.json",
            "publish.py",
            "review-faint.log",
            "review-faint-v2.log",
            "review-palette.log",
            "tests.log",
            "tests-expanded.log",
            "tests-flat-aware.log",
            "independent-audit.json",
            "review-faint-v2/result.json",
            "review-palette/result.json",
        ),
    ),
    (SPOT, ("review.py", "failed-render.py", "run.log", "run-v2.log", "result.json")),
    (
        NOISE,
        (
            "prepare.py",
            "prepare-first.py",
            "prepare.log",
            "analyze.py",
            "plan.json",
            "collection.log",
            "review.log",
            "review/result.json",
            "collection/result.json",
        ),
    ),
):
    members.update({f"{folder.name}/{f}": folder / f for f in assets})
for name in ("faint-0", "faint-1", "palette-0", "palette-1"):
    folder = ROOT / name
    local = read_json(folder / "collection/result.json")
    prefixes = (folder / "plan.json", folder / "collection.log", folder / "collection/result.json")
    all_inputs = (*prefixes, *(checked(r) for r in local["records"]))
    members.update({f"{ROOT.name}/{p.relative_to(ROOT)}": p for p in all_inputs})
for p in read_json(NOISE / "collection/result.json")["records"]:
    path = checked(p)
    members[f"{NOISE.name}/{path.relative_to(NOISE)}"] = path
for p in (
    "src/demosaic/adc_bins.py",
    "scripts/report_full_faint_photo_panel.py",
    "tests/test_adc_bins.py",
):
    members[f"source/{p}"] = Path(p)
archive = out / "evidence.tar.xz"
with tarfile.open(archive, "x:xz", preset=6) as tar:
    for name, p in sorted(members.items()):
        info = tar.gettarinfo(str(p), arcname=name)
        info.mtime = info.uid = info.gid = 0
        info.uname = info.gname = ""
        with p.open("rb") as stream:
            tar.addfile(info, stream)
with tarfile.open(archive) as tar:
    for member in tar:
        assert tar.extractfile(member).read() == members[member.name].read_bytes()
write_json(
    out / "publication.json",
    {
        "native_manifest": reference(manifest),
        "summary": reference(summary),
        "archive": reference(archive),
        "independent_audit": reference(out / "independent-audit.json"),
        "viewed_comparisons": sum(len(x) for x in boards.values()),
        "viewed_triplets": 4,
        "checked_archive_members": len(members),
        "observations": {
            "photo_ADC": 256,
            "palette_ADC": 588,
            "positive_noise": 48,
            "retained_native_spots": 24,
        },
        "checkpoint": reports["faint"]["models"]["scale-long86k"]["checkpoint"],
    },
)
print(f"Verified {len(members)} archived results and source files.")
