"""Independently verify the retained controls and the predeclared source selection."""

import hashlib
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
plan_path = ROOT / "plan.json"
stages = read_json(plan_path)
faint = ROOT / "review-faint-v2/result.json"
palette = ROOT / "review-palette/result.json"
spot = BASE / "full-corpus-long86k-adc-lift-spot-v1/result.json"
noise = BASE / "full-corpus-long86k-faint-noise-v1/review/result.json"
old_faint = BASE / "full427-faint-adc-analysis-v1/report/result.json"
old_palette = Path("docs/results/full-corpus-control20k-color-v1/report.json").resolve()
old_spot = BASE / "full-corpus-long86k-adc-spot-v1/result.json"

source = read_json(checked(stages["stages"]["faint"]["source_plan"]))
groups = {tuple(r["source_ids"]) for r in source["observations"] if len(r["source_ids"]) == 4}
salt = stages["faint_selection_salt"]
ordered = sorted(groups, key=lambda g: hashlib.sha256((salt + "|" + "|".join(g)).encode()).digest())
expected = {i for g in ordered[:16] for i in g}
observed = read_json(faint)
assert len(expected) == 64 == observed["coverage"]
assert {r["source"] for r in observed["rows"]} == expected


def compare_exact(previous, now, key, expected):
    lookup = {key(r): r for r in previous}
    matched = [r for r in now if key(r) in lookup]
    assert len(matched) == expected
    for r in matched:
        assert r == lookup[key(r)], key(r)
    return len(matched)


faint_controls = compare_exact(
    read_json(old_faint)["rows"],
    observed["rows"],
    lambda v: (v["source"], v["CFA"], v["model"], v["policy"]),
    1024,
)
spot_controls = compare_exact(
    read_json(old_spot)["rows"],
    read_json(spot)["rows"],
    lambda v: (v["id"], v["model"], v["mode"]),
    288,
)
canonical = read_json(old_palette)["metrics"]
name = {
    "raw": "raw",
    "existing-exact-Malvar": "exact-Malvar",
    "existing-exact-sites": "exact-sites",
    "ADC-bins-Malvar": "ADC-bins",
}
expected_rows = {(v["id"], v["model"], v["policy"]): v for v in canonical}
v120_checks = set()
groups = defaultdict(set)
p = read_json(palette)
for r in p["rows"]:
    groups[r["source"], r["model"], r["policy"]].add(r["pattern"])
    if r["model"] != "V120" or r["policy"] not in name:
        continue
    key = (r["id"], r["model"], name[r["policy"]])
    old = expected_rows[key]
    for field in (
        "camera_RGB_mean_error",
        "camera_RGB_MSE",
        "camera_RGB_mean_component_fraction",
        "spatially_centered_camera_RGB_RMS",
        "predicted_minus_GT_CFA_phase_mean",
        "observed_minus_GT_CFA_phase_mean",
    ):
        assert r[field] == old[field], (key, field)
    np.testing.assert_allclose(
        r["centered_RMS_DN16"], old["centered_RMS_DN16"], rtol=1e-9, atol=1e-7
    )
    np.testing.assert_equal(r["bias_DN16"], old["mean_bias_DN16"])
    v120_checks.add(key)
assert len(v120_checks) == 2352
assert len(groups) == 147 * 2 * 6 and all(
    s == {"RGGB", "BGGR", "GRBG", "GBRG"} for s in groups.values()
)
n = read_json(noise)
assert n["bin_bypass_checks"] == 288 and len(n["rows"]) == 96
v = read_json(spot)
assert all(r["bypassed"] for r in v["camera_bypass"])
assert len(v["camera_bypass"]) == 6
write_json(
    ROOT / "independent-audit.json",
    {
        "producer": reference(__file__),
        "checked_results": [reference(f) for f in (faint, palette, spot, noise)],
        "archived_scores": [reference(f) for f in (old_faint, old_palette, old_spot)],
        "photo_sources": len(expected),
        "palette_colors": 147,
        "exact_previous_faint_metrics": faint_controls,
        "exact_previous_spot_metrics": spot_controls,
        "exact_previous_palette_V120_metrics": len(v120_checks),
        "noise_mode_identity_checks": n["bin_bypass_checks"],
        "real_mode_identity_checks": 6 * 3 * 3,
        "status": "passed",
    },
)
print(
    "1024 faint + 288 spot + 2352 palette control rows verified; 288 synthetic + 54 real mode bypasses."
)
