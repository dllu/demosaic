"""Score 86k on the original native ADC photo subset and the complete flat palette."""

import argparse
import time
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from report_full_faint_photo_panel import ADC, DN16, physical_outputs, score, source_balance
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import color, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PLAN = read_json(ROOT / "plan.json")
V120, MODEL = "V120", "scale-long86k"
LIFTS = ("bilinear", "sites")
POLICIES = (
    "raw",
    "existing-exact-Malvar",
    "existing-exact-sites",
    "ADC-bins-Malvar",
    "ADC-bins-bilinear",
    "ADC-bins-sites",
)


def paired_data(kind):
    stage = PLAN["stages"][kind]
    original = read_json(checked(stage["source_plan"]))
    sealed = read_json(checked(stage["source_collection"]))
    baseline = {}
    for o, b in zip(original["observations"], sealed["records"], strict=True):
        baseline[o["id"]] = (o, b)
    models = {V120: original["models"][V120]}
    pairs, proofs = [], []
    for shard in stage["shards"]:
        p = read_json(checked(shard))
        b = reference(Path(p["root"]) / "collection/result.json")
        r = read_json(checked(b))
        assert r["plan"] == shard and r["models"] == p["models"]
        assert r["root_calls"] == {MODEL: {"root": len(p["observations"])}}
        assert r["CPU_rng_unchanged"] and r["full_model_before"] == r["full_model_after"]
        assert r["local_DINO"] == {
            "requests": len(p["observations"]),
            "executions": len(p["observations"]),
            "replays": 0,
        }
        proofs.append(b)
        models.update(p["models"])
        for o, case in zip(p["observations"], r["records"], strict=True):
            assert o == baseline[o["id"]][0]
            prev = read_json(checked(baseline[o["id"]][1]))
            selected = next(v for v in prev["variants"] if v["label"] == V120)
            current = read_json(checked(case))
            for rec in (prev, current):
                assert rec["id"] == o["id"] and rec["input_fingerprints"] == o["input_fingerprints"]
            assert current["variants"][0]["label"] == MODEL
            pairs.append((o, current | {"variants": [selected, *current["variants"]]}))
    assert len(pairs) == len({o["id"] for o, _ in pairs}) == (64 if kind == "faint" else 588)
    return pairs, models, proofs


def view(out, key, arrays, values, metadata, *, crop=0, contrast=1):
    a = {k: arrays[k][crop : crop + 1] for k in ("packed", "colors", "wb", "matrix")}
    layers = [
        (V120, "raw", "V120 EMA"),
        (V120, "ADC-bins-Malvar", "V120 bin Malvar"),
        (MODEL, "raw", "86k EMA"),
        (MODEL, "ADC-bins-Malvar", "86k bin Malvar"),
        (MODEL, "ADC-bins-bilinear", "86k bin bilinear"),
        (MODEL, "ADC-bins-sites", "86k bin sites"),
    ]
    frames = [values[m][policy][crop] for m, policy, _ in layers]
    return native_board(
        out,
        key,
        [noisy_malvar(a)[0], *frames, arrays["target"][crop]],
        a,
        metadata,
        exposure=1,
        contrast=contrast,
        triplet_indices=(0, 4, 7),
        labels=("Noisy Malvar", *(label for _, _, label in layers), "Exact GT"),
    )


def contrasts(table):
    indexed = {}
    for t in table:
        indexed[t["model"], t["policy"]] = t["sources"]
    pairs = (
        (MODEL, "raw", V120, "raw"),
        (MODEL, "ADC-bins-Malvar", V120, "ADC-bins-Malvar"),
        (MODEL, "ADC-bins-Malvar", MODEL, "raw"),
    )
    out = []
    for a, ap, b, bp in pairs:
        for key in ("sRGB_PSNR", "weakest_band_DN16"):
            da, db = indexed[a, ap], indexed[b, bp]
            identities = sorted(set(da) & set(db))
            d = np.asarray([da[x].get(key, np.nan) - db[x].get(key, np.nan) for x in identities])
            d = d[np.isfinite(d)]
            assert len(d)
            rng = np.random.default_rng(20261118)
            bootstrap = rng.choice(d, (4000, len(d)), replace=True).mean(1)
            out.append(
                {
                    "model": a,
                    "policy": ap,
                    "reference_model": b,
                    "reference_policy": bp,
                    "metric": key,
                    "count": len(d),
                    "mean_difference": float(d.mean()),
                    "positive_count": int(np.count_nonzero(d > 0)),
                    "paired_source_bootstrap95": np.quantile(bootstrap, [0.025, 0.975]).tolist(),
                }
            )
    return out


def faint(out):
    pairs, models, proofs = paired_data("faint")
    rows, boards = [], []
    identities = sorted({s for o, _ in pairs for s in o["source_ids"]})
    assert len(identities) == 64
    selection = set(identities[:2])
    for o, case in pairs:
        scores, arrays, values = score(o, case, models, lift_modes=LIFTS)
        rows.extend(scores)
        if o["pattern"] == "RGGB":
            for i, source in enumerate(o["source_ids"]):
                if source in selection:
                    boards.append(
                        view(
                            out,
                            source,
                            arrays,
                            values,
                            {
                                "source": source,
                                "ROI_xywh": [48, 48, 160, 160],
                                "CFA": "RGGB",
                                "source_observation": o,
                                "models": models,
                                "observations": case["variants"],
                                "ADC": ADC,
                                "target_role": "Exact contrast-reduced rendered target",
                            },
                            crop=i,
                            contrast=20,
                        )
                    )
    assert len(rows) == 64 * 4 * len(POLICIES) * len(models) and len(boards) == 2
    band = source_balance(rows)
    photo = defaultdict(list)
    for r in rows:
        photo[r["model"], r["policy"], r["source"]].append(r["photometry"]["srgb_psnr"])
    weakest = {
        (b["model"], b["policy"]): {r["source"]: r["error_RMS_DN16"] for r in b["source_rows"]}
        for b in band
        if b["band"] == "0"
    }
    stats = []
    for model in models:
        for policy in POLICIES:
            assert all(len(photo[model, policy, source]) == 4 for source in identities)
            metrics = {
                source: {"sRGB_PSNR": mean(photo[model, policy, source])} for source in identities
            }
            for source, value in weakest[model, policy].items():
                metrics[source]["weakest_band_DN16"] = value
            b = next(
                r for r in band if (r["model"], r["policy"], r["band"]) == (model, policy, "0")
            )
            stats.append(
                {
                    "model": model,
                    "policy": policy,
                    "sources": metrics,
                    "mean_sRGB_PSNR": mean(r["sRGB_PSNR"] for r in metrics.values()),
                    "weakest_band_DN16": b["equal_source_RMS_DN16"],
                    "weakest_band_source_count": b["source_count"],
                    "weakest_band_blocks": b["unique_blocks"],
                    "weakest_band_signed_response": b["equal_source_gain"],
                }
            )
    return {
        "coverage": 64,
        "collection_shards": proofs,
        "models": models,
        "boards": boards,
        "rows": rows,
        "bands": band,
        "summary": stats,
        "paired": contrasts(stats),
    }


def encode32(x):
    black = np.float32(0.03)
    return np.rint(np.clip(x * (np.float32(1) - black) + black, 0, 1) * np.float32(DN16))


def measured_native(rgb, pattern):
    return np.stack([rgb[:, c, p // 2 :: 2, p % 2 :: 2] for p, c in enumerate(pattern)], axis=1)


def palette_values(o, case):
    with np.load(checked(o["arrays"])) as data:
        arrays = dict(data)
    calibration = ADC | {"quantizer_precision": "float32"}
    values = {
        v["label"]: physical_outputs(
            np.load(checked(v["prediction"])), arrays, calibration=calibration, lift_modes=LIFTS
        )
        for v in case["variants"]
    }
    with np.load(checked(o["target"])) as data:
        arrays["target"] = data["target"]
    observed = encode32(arrays["packed"])
    colors = arrays["colors"][0]
    truth = measured_native(arrays["target"], colors)
    np.testing.assert_array_equal(encode32(truth), observed)
    for v in values.values():
        orig = measured_native(v["raw"], colors).astype(float)
        for p in ("ADC-bins-Malvar", "ADC-bins-bilinear", "ADC-bins-sites"):
            output = measured_native(v[p], colors)
            np.testing.assert_array_equal(encode32(output), observed)
            assert np.all((output.astype(float) - truth) ** 2 <= (orig - truth) ** 2)
    return arrays, values


def palette(out):
    pairs, models, proofs = paired_data("palette")
    grouped = defaultdict(list)
    rows, boards = [], []
    for count, (o, case) in enumerate(pairs, 1):
        arrays, values = palette_values(o, case)
        roi = np.s_[0, :, 48:208, 48:208]
        truth = arrays["target"][roi].astype(float)
        for model, policies in values.items():
            for policy, pred in policies.items():
                results = color(pred, arrays)
                error = pred[roi].astype(float) - truth
                dc = error.reshape(3, -1).mean(1)
                total = np.mean(error**2)
                spatial = np.sqrt(max(0, total - np.mean(dc**2)))
                assert np.allclose(
                    spatial, results["spatially_centered_camera_RGB_RMS"], atol=1e-12
                )
                row = {
                    "id": o["id"],
                    "source": o["source_id"],
                    "pattern": o["pattern"],
                    "model": model,
                    "policy": policy,
                    "bias_DN16": DN16 * max(abs(dc)),
                    "centered_RMS_DN16": DN16 * spatial,
                    **results,
                }
                rows.append(row)
                grouped[model, policy].append(row)
        if count % 64 == 0:
            print("palette", count, flush=True)
    assert len(rows) == 588 * len(POLICIES) * len(models)
    stats = []
    for (model, policy), rr in grouped.items():
        bias = max(rr, key=lambda r: r["bias_DN16"])
        spatial = max(rr, key=lambda r: r["centered_RMS_DN16"])
        stats.append(
            {
                "model": model,
                "policy": policy,
                "maximum_bias_DN16": bias["bias_DN16"],
                "maximum_bias_case": bias["id"],
                "maximum_centered_RMS_DN16": spatial["centered_RMS_DN16"],
                "maximum_centered_RMS_case": spatial["id"],
                "mean_MSE": mean(r["camera_RGB_MSE"] for r in rr),
            }
        )
    adverse = {m: max(grouped[m, "raw"], key=lambda r: r["bias_DN16"])["id"] for m in models}
    for o, case in pairs:
        if o["id"] not in adverse.values():
            continue
        a, v = palette_values(o, case)
        boards.append(
            view(
                out,
                o["id"],
                a,
                v,
                {
                    "source": o["source_id"],
                    "ROI_xywh": [48, 48, 160, 160],
                    "CFA": o["pattern"],
                    "raw_adverse_for": [m for m, k in adverse.items() if k == o["id"]],
                    "source_observation": o,
                    "models": models,
                    "observations": case["variants"],
                    "ADC": ADC | {"quantizer_precision": "float32"},
                    "target_role": "Exact constructed constant",
                },
            )
        )
    return {
        "coverage": 588,
        "colors": 147,
        "collection_shards": proofs,
        "models": models,
        "boards": boards,
        "rows": rows,
        "summary": stats,
        "raw_adverse_cases": adverse,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task", choices=("faint", "palette"))
    args = parser.parse_args()
    torch.set_num_threads(2)
    assert not torch.cuda.is_initialized()
    began = time.monotonic()
    out = ROOT / ("review-faint-v2" if args.task == "faint" else "review-palette")
    out.mkdir()
    with torch.inference_mode():
        result = {"faint": faint, "palette": palette}[args.task](out)
    write_json(
        out / "result.json",
        result
        | {
            "producer": reference(__file__),
            "plan": reference(ROOT / "plan.json"),
            "analysis_seconds": time.monotonic() - began,
        },
    )
