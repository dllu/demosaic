"""Bind matched CPU prediction shards for a fixed 64-photo recheck and the full palette."""

import hashlib
from collections import defaultdict
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ORIGINS = {"faint": "full427-faint-adc-v1", "palette": "control20k-full-adc-palette-v1"}
TRACKS = {
    "faint": ([2, 3], [6, 7]),
    "palette": ([12, 14], [13, 18]),
}
CFA = {"RGGB", "BGGR", "GRBG", "GBRG"}
SALT = "long86k-faint-recheck-2026-11-18"
STATE = read_json(ROOT.parent / "full-corpus-long86k-native-v1/plan.json")["models"][
    "scale-long86k"
]
assert STATE["step"] == 86000 and STATE["weights"] == "EMA"
checked(STATE["checkpoint"])
stages = {}


def pick_faint(observations):
    groups = defaultdict(list)
    for row in observations:
        groups[tuple(row["source_ids"])].append(row)
    assert len(groups) == 107
    eligible = sorted(
        (g for g in groups if len(g) == 4),
        key=lambda ids: hashlib.sha256((SALT + "|" + "|".join(ids)).encode()).hexdigest(),
    )[:16]
    assert all(len(groups[g]) == 4 and {r["pattern"] for r in groups[g]} == CFA for g in eligible)
    return [[r for key in eligible[i::2] for r in groups[key]] for i in range(2)]


def pick_palette(observations):
    groups = defaultdict(list)
    for row in observations:
        groups[row["source_id"]].append(row)
    assert len(groups) == 147
    assert all(len(v) == 4 and {r["pattern"] for r in v} == CFA for v in groups.values())
    return [[r for group in list(groups.values())[i::2] for r in group] for i in range(2)]


for kind, origin in ORIGINS.items():
    base = ROOT.parent / origin
    original = reference(base / "plan.json")
    control = reference(base / "collection/result.json")
    old = read_json(checked(original))
    collected = read_json(checked(control))
    assert collected["plan"] == original
    scope = (
        "Predeclared 64-source subset of the original 427 faint ADC panel, "
        "selected as complete original B4 groups by SHA256 and scored across all four CFAs."
        if kind == "faint"
        else "All 588 native ADC-only palette observations, 147 colors and four original CFAs."
    )
    assignments = (pick_faint if kind == "faint" else pick_palette)(old["observations"])
    shards = []
    for i, (obs, cpus) in enumerate(zip(assignments, TRACKS[kind], strict=True)):
        patch = ROOT / f"{kind}-{i}"
        patch.mkdir()
        local = old | {
            "root": str(patch),
            "models": {"scale-long86k": STATE},
            "CPU_affinity": cpus,
            "CPU_threads": 2,
            "planned_root_calls": len(obs),
            "planned_DINO_executions": len(obs),
            "inputs": [original, control, STATE["checkpoint"], *old["inputs"]],
            "observations": obs,
            "maximum_seconds": 5400,
            "scope": scope
            + " Same tensor bytes and batch shapes as the archived baseline; one new model.",
        }
        write_json(patch / "plan.json", local)
        shards.append(reference(patch / "plan.json"))
    stages[kind] = {
        "source_plan": original,
        "source_collection": control,
        "shards": shards,
        "scope": scope,
    }
write_json(
    ROOT / "plan.json",
    {"producer": reference(__file__), "stages": stages, "faint_selection_salt": SALT},
)
