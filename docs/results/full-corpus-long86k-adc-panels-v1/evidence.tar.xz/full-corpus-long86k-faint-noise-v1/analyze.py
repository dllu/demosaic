"""Reduce matched V120 and 86k results on the retained faint materials across noise."""

from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from report_checkpoint_pilot import statistics
from report_scene_wave_guides import native_board

from demosaic.adc_bins import adc_bin_projection
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PLAN = read_json(ROOT / "plan.json")
MODELS = ("V120", "scale-long86k")
LIFTS = ("malvar", "bilinear", "sites")
CROPS = {"bark-contrast0p025-iso100-prior-RGGB", "raccoon-fur-contrast0p025-iso100-prior-RGGB"}


def summarize(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["profile"], row["model"]].append(row)
    assert all(len(g) == 16 for g in groups.values())
    results = []
    for (profile, model), group in sorted(groups.items()):
        materials = sorted({r["source"] for r in group})
        assert len(materials) == 4
        by_material = []
        for source in materials:
            items = [r for r in group if r["source"] == source]
            assert {r["CFA"] for r in items} == {"RGGB", "BGGR", "GRBG", "GBRG"}
            by_material.append(
                {
                    "source": source,
                    "fine_band_DN16": mean(r["fine_band_DN16"] for r in items),
                    "sRGB_PSNR": mean(r["sRGB_PSNR"] for r in items),
                }
            )
        results.append(
            {
                "profile": profile,
                "model": model,
                "source_rows": by_material,
                "mean_fine_band_DN16": mean(r["fine_band_DN16"] for r in by_material),
                "mean_sRGB_PSNR": mean(r["sRGB_PSNR"] for r in by_material),
            }
        )
    return results


@torch.inference_mode()
def analyze():
    torch.set_num_threads(2)
    plan_path = ROOT / "plan.json"
    collection = read_json(ROOT / "collection/result.json")
    assert collection["plan"] == reference(plan_path)
    assert collection["models"] == PLAN["models"]
    assert collection["local_DINO"] == {"requests": 96, "executions": 48, "replays": 48}
    root = ROOT / "review"
    root.mkdir()
    rows, boards = [], []
    for obs, record in zip(PLAN["observations"], collection["records"], strict=True):
        record = read_json(checked(record))
        assert (
            obs["id"] == record["id"] and obs["input_fingerprints"] == record["input_fingerprints"]
        )
        with np.load(checked(obs["arrays"])) as f:
            arrays = dict(f)
        variants = {x["label"]: x for x in record["variants"]}
        with np.load(checked(obs["target"])) as f:
            target = f["target"]
        images = []
        for model in MODELS:
            b = variants[model]
            assert b["checkpoint"] == PLAN["models"][model]["checkpoint"]
            pixels = np.load(checked(b["prediction"]))
            p = torch.from_numpy(pixels)
            for mode in LIFTS:
                assert (
                    adc_bin_projection(
                        p,
                        torch.from_numpy(arrays["packed"]),
                        torch.from_numpy(arrays["colors"]),
                        bit_depth=16,
                        black_level=0.03,
                        quantizer_precision="float32",
                        shot=obs["noise"]["shot"],
                        read=obs["noise"]["read"],
                        mode=mode,
                    )
                    is p
                )
            result = statistics(pixels, target, arrays)
            band = next(r for r in result["bands"] if r["bin"] == 0)
            rows.append(
                {
                    "id": obs["id"],
                    "source": obs["source_id"],
                    "CFA": obs["pattern"],
                    "model": model,
                    "profile": obs["noise"]["name"],
                    "sRGB_PSNR": result["sRGB_PSNR"],
                    "camera_RGB_PSNR": result["camera_RGB_PSNR"],
                    "fine_band_DN16": 65535 * band["band_error_RMS"],
                    "prediction": b["prediction"],
                }
            )
            images.append(pixels[0])
        if obs["id"] in CROPS:
            boards.append(
                native_board(
                    root,
                    obs["id"],
                    [noisy_malvar(arrays)[0], *images, target[0]],
                    arrays,
                    {
                        "source": obs["source_id"],
                        "CFA": obs["pattern"],
                        "noise": obs["noise"],
                        "observation": obs,
                        "models": PLAN["models"],
                        "reference_role": "Exact target of the constructed corruption",
                    },
                    labels=("Noisy Malvar", "V120 EMA", "86k EMA", "Exact GT"),
                    triplet_indices=(0, 2, 3),
                    exposure=1,
                    contrast=20,
                )
            )
    assert len(rows) == 96 and len(boards) == 2
    table = summarize(rows)
    write_json(
        root / "result.json",
        {
            "producer": reference(__file__),
            "plan": reference(plan_path),
            "collection": reference(ROOT / "collection/result.json"),
            "rows": rows,
            "summary": table,
            "boards": boards,
            "bin_bypass_checks": len(rows) * len(LIFTS),
        },
    )
    for row in table:
        print(row, flush=True)


if __name__ == "__main__":
    analyze()
