"""Generate fixed positive-noise draws for the four retained 2.5%-contrast fields."""

import hashlib
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise, variance_map
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "full-corpus-long86k-native-v1/plan.json"
PROFILES = {
    "small-positive": (1e-8, 1e-10),
    "iso100-prior": (2e-5, 1.6e-9),
    "iso6400-prior": (0.00128, 6.5536e-6),
}
SEED = 202611180102


def main():
    torch.set_num_threads(1)
    old = read_json(PARENT)
    materials = [
        o
        for o in old["observations"]
        if o["kind"] == "material" and o["noise"]["name"] == "adc-only"
    ]
    assert len(materials) == 16 and len({o["source_id"] for o in materials}) == 4
    inputs = ROOT / "inputs"
    inputs.mkdir()
    observations = []
    for profile, (shot, read) in PROFILES.items():
        for o in materials:
            with np.load(checked(o["arrays"])) as f:
                arrays = {k: f[k] for k in ("colors", "wb", "matrix")}
            with np.load(checked(o["target"])) as f:
                tgt = torch.from_numpy(f["target"])
            clean = mosaic(tgt, torch.from_numpy(arrays["colors"]))
            draw = hashlib.sha256(f"{SEED}:{profile}:{o['id']}".encode()).digest()
            seed = int.from_bytes(draw[:8], "little") % 2**63
            rng = torch.Generator().manual_seed(seed)
            packed = add_noise(clean, shot, read, bit_depth=16, black_level=0.03, generator=rng)
            arrays.update(packed=packed.numpy(), variance=variance_map(packed, shot, read).numpy())
            identity = o["id"].replace("-adc-", f"-{profile}-")
            path = inputs / f"{identity}.npz"
            with path.open("xb") as f:
                np.savez(f, **arrays)
            observations.append(
                o
                | {
                    "id": identity,
                    "original_input_id": o["id"],
                    "seed": seed,
                    "arrays": reference(path),
                    "input_fingerprints": {k: fingerprint(v) for k, v in arrays.items()},
                    "noise": {
                        "name": profile,
                        "shot": shot,
                        "read": read,
                        "ADC_bits": 16,
                        "black_level": 0.03,
                        "ADC_precision": "float32",
                        "exposure": 1.0,
                    },
                }
            )
    assert len(observations) == 48
    write_json(
        ROOT / "plan.json",
        old
        | {
            "root": str(ROOT),
            "models": {k: old["models"][k] for k in ("V120", "scale-long86k")},
            "observations": observations,
            "CPU_affinity": [6, 7],
            "CPU_threads": 2,
            "inputs": [
                *old["inputs"],
                reference(PARENT),
                reference(__file__),
                reference("src/demosaic/noise.py"),
            ],
            "planned_root_calls": 48,
            "planned_DINO_executions": 48,
            "scope": "Matched V120 and 86k on 48 constructed positive-noise draws from the pre-existing "
            "four 2.5%-contrast material targets. Independent draws per source/profile/CFA, same tensors "
            "for both models; positive noise retains the unprojected model outputs.",
        },
    )


if __name__ == "__main__":
    main()
