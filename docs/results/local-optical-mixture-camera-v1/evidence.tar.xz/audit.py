"""Verify the mixed-optics fixed camera replay and bind it to the PSNR registry."""

from collections import defaultdict
from pathlib import Path
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM

ROOT = ARCHIVE / "canonical"
DEST = Path("docs/results/local-optical-mixture-camera-v1")
STAGES = {"known": (24, 4), "unseen": (30, 5)}


def main():
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    train_ref = reference(ARCHIVE / "train/completed.json")
    train = read_json(checked(train_ref))
    assert train["completed_schedule"] and train["step"] == 1024
    assert plan["models"][ARM]["checkpoint"] == train["checkpoints"][ARM]
    assert plan["models"]["local50k"]["checkpoint"] == train["parent"]
    camera_prior_ref = reference("docs/results/local-regional-wire-camera-v1/publication.json")
    prior = read_json(checked(camera_prior_ref))
    assert prior["canonical_inputs"] == plan["canonical_inputs"]
    references = plan["reference_replay"]
    assert references["plan"] == prior["plan"]
    assert ARM not in references["models"]
    for title, key in references["models"].items():
        assert plan["models"][title] == prior["models"][key]
    preflight = reference(ROOT / "preflight/result.json")
    probe = read_json(checked(preflight))
    assert probe["complete"] and probe["plan"] == plan_ref and probe["scope"] == "preflight"
    assert len(probe["V120_CPU_comparisons"]) == 8
    assert max(abs(d) for r in probe["V120_CPU_comparisons"] for d in r["delta_dB"]) < 1e-4

    witness = read_json(checked(plan["canonical_inputs"]))
    assert witness["all_input_witnesses_exact"]
    done_ref = reference(ROOT / "full/camera-result.json")
    done = read_json(checked(done_ref))
    assert done["complete"] and done["scope"] == "cameras" and done["plan"] == plan_ref
    assert done["counts"] == {s: count for s, (count, _) in STAGES.items()}
    assert done["models"] == plan["models"] and done["canonical_inputs"] == plan["canonical_inputs"]
    previous = {part: {ref["path"]: ref for ref in prior["panels"][part]["cases"]} for part in STAGES}
    indices = {(r["stage"], r["batch"]): r for r in witness["records"] if r["stage"] in STAGES}
    scores = {s: defaultdict(lambda: defaultdict(lambda: defaultdict(list))) for s in STAGES}
    files = {s: [] for s in STAGES}
    for link in done["cases"]:
        row = read_json(checked(link))
        part, index = row["stage"], row["batch"]
        record = indices.pop((part, index))
        assert row["plan"] == plan_ref and row["arrays"] == record["arrays"]
        checked(row["arrays"])
        assert set(row["variants"]) == set(plan["models"])
        prior_binding = row["reference_replay_batch"]
        assert prior_binding == previous[part][prior_binding["path"]]
        old = read_json(checked(prior_binding))
        assert old["plan"] == prior["plan"] and old["arrays"] == row["arrays"]
        for title, key in references["models"].items():
            value = row["variants"][title]
            historical = old["variants"][key]
            assert value["reused_from"] == {"batch": prior_binding, "model": key}
            assert value["output_fingerprint"] == historical["output_fingerprint"]
            assert value["rows"] == [r | {"model": title} for r in historical["rows"]]

        scene = record["context"]["scene"]
        pair = record["context"]["raw_source"]["sha256"]
        identity = None
        for arm, entry in row["variants"].items():
            r = entry["rows"]
            assert entry["output_fingerprint"]["dtype"].endswith("f4")
            assert [sample["id"] for sample in r] == record["context"]["ids"]
            assert all((q["model"], q["scene"], q["pair"]) == (arm, scene, pair) for q in r)
            witnesses = [(q["id"], q["pattern"], q["metrics"]["reference_samples"]) for q in r]
            assert all(v[2] >= 1024 for v in witnesses)
            assert identity is None or identity == witnesses
            identity = witnesses
            scores[part][arm][scene][pair].extend(q["metrics"]["sensor_psnr"] for q in r)
        files[part].append(link)

    assert not indices
    book = {}
    refs = {}
    DEST.mkdir()
    for stage, (batches, scenes) in STAGES.items():
        means = {}
        assert len(files[stage]) == batches
        for arm, groups in scores[stage].items():
            assert len(groups) == scenes and all(len(pairs) == 2 for pairs in groups.values())
            assert all(len(v) == 9 and np.isfinite(v).all() for pairs in groups.values() for v in pairs.values())
            balanced = {scene: float(np.mean([np.mean(v) for v in pairs.values()]))
                        for scene, pairs in sorted(groups.items())}
            means[arm] = {"per_scene": balanced, "sensor_psnr": float(np.mean(list(balanced.values())))}
            if arm in references["models"]:
                old = prior["panels"][stage]["overall"][references["models"][arm]]
                assert np.isclose(means[arm]["sensor_psnr"], old["sensor_psnr"], rtol=0, atol=1e-10)
        book[stage] = {
            "batches": batches, "scenes": scenes, "crops_per_model": scenes * 18, "overall": means,
            "matching_canonical_arrays": True, "cases": sorted(files[stage], key=lambda r: r["path"]),
        }
        path = DEST / (stage + ".json")
        write_json(path, book[stage])
        refs[stage] = reference(path)

    archive = DEST / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as out:
        for name, ref in (("plan.json", plan_ref), ("preflight.json", preflight), ("replay.json", done_ref),
                          ("audit.py", reference(__file__)), ("training-audit.json", train_ref)):
            out.add(checked(ref), arcname=name)
        for stage in STAGES:
            out.add(checked(refs[stage]), arcname=f"{stage}/analysis.json")
            for i, ref in enumerate(book[stage]["cases"]):
                out.add(checked(ref), arcname=f"{stage}/cases/{i:05d}.json")
    write_json(DEST / "publication.json", {
        "plan": plan_ref, "preflight": preflight, "models": plan["models"], "canonical_inputs": plan["canonical_inputs"],
        "weights": "EMA", "replay": done_ref, "prior_camera_study": camera_prior_ref, "training": train_ref,
        "precision": "CUDA IEEE FP32, channels-last, measured-CFA reference",
        "complete_camera_panels": True, "photo_panel_complete": False,
        "V120_minus_archived_dB": {s: prior["V120_minus_archived_dB"][s] for s in STAGES},
        "panels": book, "archive": reference(archive) | {"path": str(archive)}, "analysis": refs,
    })
    for stage, data in book.items():
        print(stage, {k: round(v["sensor_psnr"], 5) for k, v in data["overall"].items()}, flush=True)


if __name__ == "__main__":
    main()
