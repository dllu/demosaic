"""Check whether copying already formatted CPU weights speeds a cold CUDA load."""
from pathlib import Path
import sys
import time

import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.with_name('corpus100k-mixed-precision-v1')))
from screen import MODEL, PRIMARY, versions, SHOT, READ, policy
from demosaic.experiments.artifacts import read_json, checked, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.cfa import color_indices, pack
from demosaic.io import read_raw

@torch.inference_mode()
def main(order):
    torch.set_num_threads(3)
    t0=time.perf_counter()
    raw_path=read_json('configs/gfx-qualitative-20231231.json')['noisy']
    raw,metadata=read_raw(raw_path)
    pre=time.perf_counter()
    binding=read_json(PRIMARY)['models'][MODEL]['checkpoint']
    model,envelope=load_checkpoint(checked(binding),'cpu')
    assert envelope['loaded_sha256']==binding['sha256'] and 'ema' in envelope
    cpu=time.perf_counter()
    model.eval()
    if order!='gpu-layout':
        model.to(memory_format=torch.channels_last)
    before=time.perf_counter()
    host = []
    def transfer(value):
        if value.device.type=='cuda':
            return value
        pinned=value.pin_memory()
        host.append(pinned)
        return pinned.to('cuda',non_blocking=True)
    model._apply(transfer)
    torch.cuda.synchronize()
    moved=time.perf_counter()
    if order=='gpu-layout':
        model.to(memory_format=torch.channels_last)
        torch.cuda.synchronize()
    layout=time.perf_counter()
    print('decode',pre-t0,'CPU',cpu-pre,'CPU format',before-cpu,'upload',moved-before,'GPU format',layout-moved,flush=True)
    assert all(weight.is_contiguous(memory_format=torch.channels_last) for weight in model.parameters() if weight.ndim==4)
    x,y=4096,4096
    sensor=pack(torch.from_numpy(raw[y:y+512,x:x+512].copy())[None,None].cuda()).contiguous(memory_format=torch.channels_last)
    colors=torch.as_tensor(color_indices(metadata.pattern),device='cuda')[None]
    wb=torch.as_tensor(metadata.white_balance,device='cuda',dtype=torch.float32)[None]
    matrix=torch.as_tensor(metadata.camera_to_srgb,device='cuda',dtype=torch.float32)[None]
    model.set_noise(SHOT,READ)
    with policy(model,'fp16'):
        result=model(sensor,sensor.clamp_min(0)*SHOT+READ,colors,wb,matrix)
    assert result.dtype==torch.float32 and torch.isfinite(result).all()
    import numpy as np
    out=ROOT/f'startup-{order}-output.npy'
    np.save(out,result.cpu().numpy())
    write_json(ROOT/f'startup-{order}.json',{'driver':reference(__file__),'checkpoint':binding,
          'backend':versions(),'source':reference(raw_path),'ROI_xywh':[x,y,512,512],'noise':{'shot':SHOT,'read':READ},
          'order':order,'output':reference(out),'seconds':{'decode':pre-t0,'checkpoint_cpu':cpu-pre,'layout_cpu':before-cpu,
             'move_to_cuda':moved-before,'layout_cuda':layout-moved,'total_until_model_ready':layout-t0}})
if __name__=='__main__':
    main(*sys.argv[1:])
