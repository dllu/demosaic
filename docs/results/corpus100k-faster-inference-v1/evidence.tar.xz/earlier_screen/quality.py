"""Check production FP16 with native GFX photographs and exact faint targets."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, linear_rgb, noisy_malvar, photometry
from demosaic.cfa import unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import restore_tiled
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board
from screen import ROOT, load, policy, versions

SOURCES=Path('.cache/experiments')
FRESH=SOURCES/'query-exterior-colour-v1/plan.json'
FIXED=SOURCES/'full-corpus-long100k-review-v1/primary-native/result.json'
ARCHIVE=Path('docs/images/full-corpus-long100k-native-v1/manifest.json')
KEYS=('packed','variance','colors','wb','matrix')
LUMA=np.array([.2126,.7152,.0722])
CUT=np.s_[...,48:208,48:208]


def infer(model, arrays, noise, dtype):
    model.set_noise(noise['shot'],noise['read'])
    observed=[torch.from_numpy(arrays[k].copy()).to('cuda') for k in KEYS]
    observed[:2]=[v.contiguous(memory_format=torch.channels_last) for v in observed[:2]]
    with policy(model,dtype):
        estimate=model(*observed)
    assert estimate.dtype==torch.float32 and torch.isfinite(estimate).all()
    return estimate.cpu().numpy()


def error(a,b):
    d=(a.astype(float)-b)*65535
    return {'camera_RGB_RMS_DN16':float(np.sqrt(np.mean(d*d))),
            'max_camera_RGB_DN16':float(abs(d).max()),
            'mean_by_channel_DN16':d.mean(axis=(-2,-1)).tolist()}


def mesh(model, out):
    bound=reference(ARCHIVE)
    baseline=read_json(checked(bound))
    rows=[]
    for item in baseline['images']:
        if not item['id'].startswith('mesh-') or item['role']!='board':
            continue
        key=item['id']
        old=item['provenance']
        with np.load(checked(old['input_arrays']),allow_pickle=False) as f:
            arrays={k:f[k] for k in KEYS}
        shot,read=old["noise"]['shot'],old["noise"]['read']
        raw=unpack(torch.from_numpy(arrays['packed']))[0,0]
        predictions={}
        for mode in ('fp32','fp16'):
            restored,_=restore_tiled(model,raw,arrays['colors'][0],shot=shot,read=read,
                    tile=512,overlap=64,batch_size=4,device='cuda',wb=arrays['wb'][0],matrix=arrays['matrix'][0],
                    precision='float32' if mode=='fp32' else 'float16')
            predictions[mode]=restored
        x,y,w,h=old['ROI_xywh']
        box=(x,y,w,h)
        selected=np.s_[...,y:y+h,x:x+w]
        exposure=old['display_exposure']
        views={name:np.rint(display_crop(img[None],torch.from_numpy(arrays['wb']),
                   torch.from_numpy(arrays['matrix']),box,exposure=exposure)*255).astype(np.uint8) for name,img in predictions.items()}
        device_raster=np.asarray(Image.open(checked(item['image'])).convert('RGB'))
        prior={p['label']:device_raster[v:v+z,u:u+w] for p in old['panels'] for u,v,w,z in (p['png_xywh'],)}
        ordered=[('Noisy Malvar',prior['Noisy Malvar']),('Corpus 100k FP32',views['fp32']),('Corpus 100k FP16',views['fp16'])]
        ordered.extend((label,prior[label]) for label in ('ISO100 ref, not GT','SOOC ISO6400 JPEG','SOOC ISO100 JPEG'))
        from render import native_png
        board=native_png(out/(key+'.png'),ordered)
        rows.append({'id':key,'precisions':list(views),'source':old,'board':board,
                     'difference':error(predictions['fp16'][selected].numpy(),predictions['fp32'][selected].numpy()),
                     'changed_8bit_pixels':int(np.any(views['fp16']!=views['fp32'],axis=2).sum())})
        print(key,rows[-1]['difference'],flush=True)
    assert len(rows)==4
    return rows


def target_panel(model, out):
    old=read_json(checked(reference(FIXED)))
    source=read_json(checked(reference(Path('docs/results/full-corpus-long100k-primary-v1/primary.json'))))
    canonical=read_json(checked(source['canonical_inputs']))
    rows=[]
    for i, photo in enumerate(old['boards']):
        binding=photo['fixed_native_input']
        context=next(r['context'] for r in canonical['records'] if r['arrays']==binding)
        idx=context['ids'].index(photo['source']['id'])
        with np.load(checked(binding),allow_pickle=False) as f:
            arrays={k:f[k][idx:idx+1] for k in (*KEYS,'target')}
        before= infer(model,arrays,photo['noise'],'fp32')
        after= infer(model,arrays,photo['noise'],'fp16')
        board=native_board(out,'dahlia' if i else 'railway',[noisy_malvar(arrays)[0],before[0],after[0],arrays['target'][0]],arrays,
              {k:photo[k] for k in ('source','checkpoint','CFA','noise','fixed_native_input','ADC_bits','black_level')},
              labels=('Noisy Malvar','Corpus 100k FP32','Corpus 100k FP16','Exact GT'),triplet_indices=(0,2,3),
              exposure=photo['display_exposure'],roi=photo['ROI_xywh'])
        scores={k:float(photometry(img,arrays)['srgb_psnr'][0]) for k,img in (('fp32',before),('fp16',after))}
        rows.append({'board':board,'fixed_crop_scores':scores,'difference':error(after[CUT],before[CUT])})
        print('original panel',i,scores,flush=True)
    return rows


def wires(model):
    cohort=read_json(checked(reference(FRESH)))
    captures=read_json(checked(reference(FRESH.parent/'captures.json')))
    rows=[]
    for case in captures['rows']:
        profile=cohort['profiles'][case['noise']]
        setup=cohort['sources'][case['index']]['geometry']
        with np.load(checked(case['input']),allow_pickle=False) as f:
            arrays={k:f[k][...,64:192,64:192] if k in ('packed','variance') else f[k] for k in KEYS}
            arrays['target']=f['target'][...,128:384,128:384]
            support=f['support'][64:192,64:192]>=.97
        y,x=np.indices((128,128),dtype=float)-63.5
        xy=[x.ravel(),y.ravel()]
        carriers=np.asarray(setup['frequency'])
        z=2*np.pi*(carriers@np.array(xy))
        terms=np.column_stack([np.ones(128*128),x.ravel(),y.ravel(),(x*x).ravel(),(x*y).ravel(),(y*y).ravel(),
              np.cos(z[0]),np.sin(z[0]),np.cos(z[1]),np.sin(z[1])])[support.ravel()]
        fit=np.linalg.pinv(terms)[-4:]
        truth=linear_rgb(arrays['target'],arrays)
        truth_y=np.einsum('c,bchw->bhw',LUMA,truth)
        severe=np.s_[...,64:192,64:192]
        true_step=(truth_y[0]-truth_y[2])[severe][support]
        band=fit@true_step
        predicted={}
        outputs={}
        for mode in ('fp32','fp16'):
            rgb=infer(model,arrays,profile,mode)
            outputs[mode]=rgb
            value=linear_rgb(rgb,arrays)
            v=np.einsum('c,bchw->bhw',LUMA,value)
            step=(v[0]-v[2])[severe][support]
            weak=fit@step
            full=fit@(v[0][severe][support])
            raw_flat=value[3,:,72:184,72:184]
            vflat=v[3,72:184,72:184]
            cflat=raw_flat-vflat[None]
            predicted[mode]={'weak_aligned_response_pct':float(100*weak[-2:]@band[-2:]/(band[-2:]@band[-2:])),
                             'fine_increment_error_DN16':float(np.sqrt(np.mean((step-true_step)**2))*65535),
                             'strong_band_norm_DN16':float(np.linalg.norm(full[:2])*65535),
                             'flat_luma_RMS_DN16':float(np.std(vflat)*65535),
                             'flat_chroma_RMS_DN16':float(np.sqrt(np.mean((cflat-cflat.mean((1,2),keepdims=True))**2))*65535),
                             'flat_colour_bias_DN16':((raw_flat-truth[3,:,72:184,72:184]).mean((1,2))*65535).tolist()}
        rows.append({'index':case['index'],'noise':case['noise'],'arrays':case['input'],'scores':predicted,
                     'full_difference':error(outputs['fp16'],outputs['fp32'])})
    return rows


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    model,binding=load()
    out=ROOT/'native'
    out.mkdir(exist_ok=True)
    import sys
    sys.path.insert(0,str(SOURCES/'paired-luminance-detail-v1'))
    write_json(ROOT/'target-quality.json',{'driver':reference(__file__),'model':binding,'backend':versions(),
                  'fixed_cases':target_panel(model,out),'wire_cases':wires(model),'cab':mesh(model,out),
                  'scope':'Same GPU and checkpoint, target and native crop visual evidence. No new training.'})


if __name__=='__main__':
    main()
