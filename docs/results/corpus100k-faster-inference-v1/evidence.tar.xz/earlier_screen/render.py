"""Show native candidates and actual changes on the reserved photos and camera crops."""
from collections import defaultdict
from pathlib import Path
import sys

import numpy as np
import torch
from PIL import Image,ImageDraw

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
ORIG=ROOT.parent/"scene-local-contrast-2400-v1"
sys.path.insert(0,str(ORIG))
from analyze_matched import compare

ARGS=("packed","variance","colors","wb","matrix")
PARENT="100k"
CORE_METHODS=("absolute","paired","guarded-absolute","guarded-paired")
LOCAL_METHODS=("intersection-paired","scaled-wide-paired")
METHODS=CORE_METHODS+LOCAL_METHODS
COLORS=("V120 EMA","Parent 100k EMA")
LABELS=("Absolute EMA","Paired EMA","Absolute + guard","Paired + guard","Paired + both windows","Wide at matched RMS")

def full_results(endpoint):
    plot=read_json(ROOT/"endpoint/short-guard/results.json")
    assert plot["original"]==endpoint["photo_results"]
    study=read_json(checked(read_json(checked(endpoint["plan"]))["support"]))
    assert study["threshold_0_to_1"][0]>0 and len(plot["rows"])==256
    panel=read_json(ORIG/"matched-analysis-plan.json")
    faint={row[2] for row in panel["fainter_half_by_frozen_clean_increment"]}
    all_pairs=defaultdict(dict)
    cells=defaultdict(dict)
    rng=np.random.default_rng(85247002)
    for profile in ("iso400","iso6400"):
        for draw in ("coupled","independent"):
            group=[r for r in plot["rows"]if (r["profile"],r["draw"])==(profile,draw)]
            assert len(group)==64
            weaker=[v for v in group if v["source"]in faint]
            assert len(weaker)==32
            result={}
            for cohort,selected in (("all",group),("fainter",weaker)):
                result[cohort]={}
                for method in METHODS:
                    if method=="intersection-paired":
                        control="scaled-wide-paired"
                    elif method=="scaled-wide-paired":
                        control="guarded-paired"
                    elif method.startswith("guarded-"):
                        control=method.removeprefix("guarded-")
                    elif method=="paired":
                        control="absolute"
                    else:
                        control=PARENT
                    result[cohort][method]={
                        "against_parent":compare(selected,{method:1,PARENT:-1},rng,True),
                        "against_matched_policy":compare(selected,{method:1,control:-1},rng,True),
                        "mean_correction_DN16_per_role":np.mean(
                          [r["actual_lift"][method]["correction_RMS_DN16_per_role"] if method in CORE_METHODS
                           else r["added_RMS_DN16_per_role"][method] for r in selected],axis=0).tolist(),
                        "correction_domain":"linear luminance" if method in CORE_METHODS else "camera RGB",
                    }
            all_pairs[profile][draw]=result
            cells[profile][draw]=np.mean([v["guard_active_fraction_per_role"]for v in group],axis=0).tolist()
    return plot,dict(all_pairs),dict(cells),faint

def synthetic(folder,study,plan,plot,faint):
    pool=[r for r in plot["rows"]if r["profile"]=="iso6400" and r["draw"]=="coupled" and r["source"]in faint]
    assert len(pool)==32
    metric=lambda r:r["metrics"]["intersection-paired"]["band"]["fine"]["increment_RMS_DN16"]-r["metrics"][PARENT]["band"]["fine"]["increment_RMS_DN16"]
    ordered=sorted(pool,key=metric)
    flat=max(pool,key=lambda r:r["actual_lift"]["paired"]["fine_correction_RMS_DN16_per_role"][2])
    samples=((ordered[0],0,"Largest reduction in paired fine increment error with both windows on fainter half"),
             (ordered[-1],0,"Largest increase in paired fine increment error with both windows on fainter half"),
             (flat,2,"Largest fine correction on an exact flat from the unguarded paired head"))
    output=[]
    for row,role,reason in samples:
        prior=read_json(checked(row["original"]))
        case=read_json(checked(prior["case"]))
        source=study["rows"][case["case"]]
        assert source["source"]["id"]==case["source"]==row["source"]
        with np.load(checked(case["input"]),allow_pickle=False)as stored:
            args={k:stored[k][role:role+1]if k in ("packed","variance")else stored[k][None]for k in ARGS}
            ground_truth=stored["target"][role]
        with np.load(checked(prior["saved"]),allow_pickle=False)as previous:
            parents=[previous[k][role]for k in ("V120",PARENT)]
        with np.load(checked(row["saved"]),allow_pickle=False)as variants:
            compared=[variants[k][role]for k in CORE_METHODS]
        with np.load(checked(row["guarded_output"]),allow_pickle=False)as variants:
            compared.extend(variants[k][role]for k in LOCAL_METHODS)
        frames=[noisy_malvar(args)[0],*parents,*compared,ground_truth]
        output.append(native_board(folder,f"{case['id']}-role{role}",frames,args,{
            "selection":reason,"source_photo":source["source"],"bbox_native":case["box"],
            "profile":case["profile"],"CFA":source["camera"]["pattern"],"draw":case["draw"],
            "role":study["roles"][role],"original_case":prior["case"],"checkpoint":plan["checkpoint"],
            "parent_checkpoint":plan["base"],
        },labels=("Noisy Malvar",*COLORS,*LABELS,"Exact GT"),
          triplet_indices=(0,3+METHODS.index("intersection-paired"),len(frames)-1),exposure=1/case["profile"]["exposure"],contrast=2,
          roi=tuple(study["native_display_ROI_xywh"])))
    return output

def native_png(path,panels):
    canvas=Image.new("RGB",(8+168*len(panels),192),"#eeeeee")
    painter=ImageDraw.Draw(canvas)
    values=[]
    for i,(name,pixels) in enumerate(panels):
        assert pixels.shape==(160,160,3) and pixels.dtype==np.uint8
        x=8+i*168
        painter.text((x,5),name,fill="#111111")
        canvas.paste(Image.fromarray(pixels),(x,24))
        values.append({"name":name,"png_xywh":[x,24,160,160]})
    canvas.save(path)
    reread=np.asarray(Image.open(path).convert("RGB"))
    for field,(_,image) in zip(values,panels,strict=True):
        x,y,w,h=field["png_xywh"]
        np.testing.assert_array_equal(reread[y:y+h,x:x+w],image)
    return {"image":reference(path),"panels":values}

def camera(directory,endpoint,plan):
    receipt=read_json(checked(endpoint["standing_results"]))
    rows={r["id"]:r for r in receipt["rows"]}
    companion=read_json(ROOT/"endpoint/short-guard/standing.json")
    assert companion["source"]==endpoint["standing_results"]
    short={row["id"]:row["file"]for row in companion["cases"]}
    before=read_json(checked(receipt["display_parent_boards"]))
    rendered=[]
    for region in before["boards"]:
        if region["observation"] not in rows:
            continue
        current=rows[region["observation"]]
        assert current["raw"]["arrays"]==region["input_arrays"]
        old=np.asarray(Image.open(checked(region["image"])).convert("RGB"))
        existing={panel["label"]:old[y:y+h,x:x+w].copy()for panel in region["panels"]
                  for x,y,w,h in [panel["png_xywh"]]}
        roi=region["case"]["ROI_xywh"]
        x,y,w,h=roi
        with np.load(checked(region["input_arrays"]),allow_pickle=False)as source:
            wb,matrix=[torch.from_numpy(source[k])for k in ("wb","matrix")]
        baseline=np.load(checked(current["parent"]),allow_pickle=False)[...,y:y+h,x:x+w].astype(float)
        metadata={}
        direct={}
        with np.load(checked(current["saved"]),allow_pickle=False)as long, np.load(checked(short[region["observation"]]),allow_pickle=False)as local:
            arrays={k:long[k]for k in CORE_METHODS}|{k:local[k]for k in LOCAL_METHODS}
            for key,label in zip(METHODS,LABELS,strict=True):
                correction=arrays[key][...,y:y+h,x:x+w].astype(float)-baseline
                metadata[key]={"camera_RGB_RMS_DN16":float(65535*np.sqrt(np.mean(correction**2))),
                               "changed_native_RGB_values":int(np.count_nonzero(correction))}
                p=display_crop(torch.from_numpy(arrays[key]),wb,matrix,roi,
                               exposure=region["display_exposure"])
                direct[label]=np.rint(p.clip(0,1)*255).astype(np.uint8)
            weight=local["guard"][...,y:y+h,x:x+w]
        showing=[(k,existing[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)",*COLORS)if k in existing]
        showing.extend(direct.items())
        showing.extend((k,existing[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in existing)
        image=native_png(directory/(region["id"]+".png"),showing)
        rendered.append({**image,"id":region["id"],"checkpoints":plan["checkpoint"],
                         "parent_checkpoint":plan["base"],"input":region["input_arrays"],
                         "ROI_xywh":roi,"noise":region["noise"],"display_exposure":region["display_exposure"],
                         "guard_mean_weight":float(weight.mean()),"RMS_and_changes":metadata,
                         "reference_role":region["reference_role"],"old_board":region["image"]})
    assert len(rendered)==8
    return rendered

def run():
    torch.set_num_threads(1)
    finish=ROOT/"endpoint/complete.json"
    endpoint=read_json(finish)
    plan=read_json(checked(endpoint["plan"]))
    study=read_json(ORIG/"evaluation-plan.json")
    plot,results,gates,faint=full_results(endpoint)
    folder=ROOT/"native";folder.mkdir()
    photos=synthetic(folder,study,plan,plot,faint)
    cameras=camera(folder,endpoint,plan)
    write_json(ROOT/"endpoint-analysis.json",{
        "driver":reference(__file__),"review":reference(finish),"paired_results":results,
        "active_gate_fraction_per_role":gates,"photos":photos,"standing":cameras,
        "scope":"Source-resampled natural metrics. Real native regions use independent qualitative references.",
        "actual_native_viewing":False,
    })

if __name__=="__main__":
    run()
