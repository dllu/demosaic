"""Run cold CLI inference with the two checkpoint-transfer policies."""
import json
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
import tifffile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent


def main():
    if len(sys.argv)==2 and sys.argv[1]=='legacy':
        from demosaic import cli, inference
        current=inference.load_checkpoint
        def old(path,device,*,refinement_precision,tiled_inference):
            assert tiled_inference
            return current(path,device,refinement_precision=refinement_precision)
        inference.load_checkpoint=old
        sys.argv=sys.argv[:1]+json.loads((ROOT/'cli-baseline-arguments.json').read_text())
        cli.main()
        return

    checkpoint=read_json('docs/results/full-corpus-long100k-primary-v1/primary.json')['models']['scale-long100k']['checkpoint']
    fixture=read_json('configs/gfx-qualitative-20231231.json')
    source=reference(fixture['noisy'])
    rows={}
    for arm in ('pinned','legacy'):
        out=ROOT/f'cli-{arm}.tiff'
        args=['infer',str(checked(checkpoint)),str(checked(source)),str(out),'--device','cuda',
              '--tile','512','--overlap','64','--batch-size','4','--precision','float16',
              '--shot','0.00128','--read','0.0000065536']
        if arm=='legacy':
            write_json(ROOT/'cli-baseline-arguments.json',args)
        cli_args=([sys.executable,'-c','from demosaic.cli import main;main()',*args] if arm=='pinned'
                  else [sys.executable,__file__,'legacy'])
        started=time.perf_counter()
        with (ROOT/f'cli-{arm}.log').open('w') as log:
            out_from_process=subprocess.run(cli_args,stdout=log,stderr=subprocess.STDOUT,check=True)
        elapsed=time.perf_counter()-started
        sidecar=reference(out.with_suffix('.json'))
        stats=read_json(checked(sidecar))
        assert stats['checkpoint_sha256']==checkpoint['sha256'] and stats['compute_precision']=='float16'
        rows[arm]={'sidecar':sidecar,'TIFF':reference(out),'elapsed_seconds':elapsed,'stats':stats}
        print(arm,elapsed,stats['checkpoint_setup_seconds'],stats['seconds'],flush=True)
    a=tifffile.memmap(checked(rows['pinned']['TIFF']))
    b=tifffile.memmap(checked(rows['legacy']['TIFF']))
    assert a.shape==b.shape and a.dtype==b.dtype==np.uint16
    count=sum(int(np.count_nonzero(a[y:y+128]!=b[y:y+128])) for y in range(0,a.shape[0],128))
    write_json(ROOT/'cli-staging.json',{'driver':reference(__file__),'source':source,'checkpoint':checkpoint,
               'runs':rows,'rgb16_shape':list(a.shape),'mismatched_RGB16_codes':count,'RGB16_codes':a.size})
    assert count==0,count


if __name__=='__main__':
    main()
