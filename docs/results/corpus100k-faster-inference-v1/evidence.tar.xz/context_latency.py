"""Locate the cold CUDA cost before the first checkpoint parameter transfer."""
import ctypes
from pathlib import Path
import time

START = time.perf_counter()
import torch
from demosaic.experiments.artifacts import reference, write_json

ROOT=Path(__file__).resolve().parent
stages={'torch_import_seconds':time.perf_counter()-START}


def stage(name, fn):
    start=time.perf_counter()
    ans=fn()
    stages[name+'_seconds']=time.perf_counter()-start
    print(name,stages[name+'_seconds'],flush=True)
    return ans


def main():
    driver=stage('dlopen_cuda_driver',lambda:ctypes.CDLL('libcuda.so.1'))
    status=stage('cuInit',lambda:driver.cuInit(0))
    assert status==0,status
    stage('torch_cuda_init',torch.cuda.init)
    cpu=torch.rand(1024)
    gpu=stage('first_allocation',lambda:torch.empty_like(cpu,device='cuda'))
    stage('first_upload',lambda:gpu.copy_(cpu))
    stage('synchronize',torch.cuda.synchronize)
    def second_transfer():
        torch.empty_like(cpu,device='cuda').copy_(cpu)
        torch.cuda.synchronize()
    stage('repeat_allocation_and_upload',second_transfer)
    write_json(ROOT/'context-latency.json',{'driver':reference(__file__),'torch':torch.__version__,
               'device':torch.cuda.get_device_name(),'stages':stages,'total_seconds':time.perf_counter()-START})


if __name__=='__main__':
    main()
