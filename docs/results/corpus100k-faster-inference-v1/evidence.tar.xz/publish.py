"""Check and archive the inference comparisons and native crops."""
import hashlib
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
OUT=Path('docs/results')/ROOT.name
IMAGES=Path('docs/images')/ROOT.name


def publish_board(board):
    src=checked(board['image'])
    dest=IMAGES/src.name
    shutil.copyfile(src,dest)
    assert reference(dest)['sha256']==board['image']['sha256']
    with Image.open(dest) as image:
        pixels={}
        for cell in board['panels']:
            x,y,w,h=cell['png_xywh']
            assert (w,h)==(160,160)
            assert 0<=x<=image.width-w and 0<=y<=image.height-h
            label=cell.get('name',cell.get('label'))
            assert label not in pixels
            pixels[label]=image.crop((x,y,x+w,y+h))
    board['image']['path']=dest.name
    return pixels


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    IMAGES.mkdir(parents=True,exist_ok=True)
    checkpoint=read_json('docs/results/full-corpus-long100k-primary-v1/primary.json')['models']['scale-long100k']['checkpoint']
    checked(checkpoint)
    cli=read_json(ROOT/'cli-staging.json')
    review=read_json(ROOT/'trt-review.json')
    benchmark=read_json(ROOT/'trt-screen-opt2.json')
    assert all(value['checkpoint']==checkpoint for value in (cli,review,benchmark))
    assert cli['mismatched_RGB16_codes']==0 and cli['RGB16_codes']==305987556
    for run in cli['runs'].values():
        checked(run['sidecar'])
        checked(run['TIFF'])
    for run in review['full_frame']:
        checked(run['RGB16'])
        assert run['restore']['tiles']==520 and run['restore']['compute_precision']=='float16'
    for group in ('engines','small_engines'):
        for arm, details in review[group].items():
            checked(details['engine'])
            inspector=read_json(checked(details['inspector']))
            actual=[layer for layer in inspector['Layers']
                    if layer['LayerType']=='correlation' and any(x['Datatype']=='FP8' for x in layer['Inputs'])]
            assert len(actual)==(24 if arm=='trt-selective-fp8' else 0)
    views={}
    for group, count in (('GFX',4),('cab',4),('exact',2)):
        assert len(review[group])==count
        for row in review[group]:
            original=row['board']['board'] if group=='exact' else row['board']
            parts=publish_board(original)
            if group=='exact':
                triplet=publish_board(row['board']['triplet'])
                assert set(triplet)=={'Noisy Malvar','trt-fp16','Exact GT'}
                assert all(ImageChops.difference(im,parts[name]).getbbox() is None for name,im in triplet.items())
        views[group]=review[group]
    outliers=read_json(ROOT/'outliers.json')
    for row in outliers['rows']:
        publish_board(row['image'])
    views['worst_exported_code']=outliers['rows']
    views['observations']={
        'completed':True,
        'main':'Sky remains smooth, coarse lattice crossings and fine building wires have the same apparent continuity. Foliage remains soft in every arm.',
        'cab':'All four views preserve the existing faint diagonals and incomplete crossings, with no apparent false color added at the fixed display exposure.',
        'target':'All three half-precision paths look similar on the railway and dahlia. The yellow petals remain too bright.',
        'outliers':'The largest FP16 engine delta sits on saturated magenta signage and the FP8 delta on orange LED characters. The printed lettering shapes remain visually similar.'}
    views['checkpoint']=checkpoint
    views['noise']=review['noise']
    views['main_source']=review['source']
    manifest = IMAGES/'manifest.json'
    if manifest.exists():
        assert read_json(manifest)==views
    else:
        write_json(manifest,views)
    records = [
       'publish.py','cli-staging.json','cli-baseline-arguments.json','cli-pinned.json','cli-legacy.json',
       'cli-paired.log','paired_cli.py','install.log','tests.log',
       'context-latency.json','context_latency.py','startup_layout.py','startup_slab.py','startup_pinned_individual.py',
       'trt_hidden.py','trt_review.py','trt-screen-opt2.json','trt-review.json','trt-hidden-pyramid.log',
       'trt-review-fixed.log','calibration.json','replay.py','replay.json','replay.log','trunk_graph.py',
       'trunk-graph.json','trunk-graph.log','inspect_outliers.py','outliers.json']
    records += [path.name for path in ROOT.glob('*-layers*.json')]
    records += [path.name for path in ROOT.glob('startup-*.json')]
    records += [path.name for path in sorted(ROOT.glob('dino*py'))+sorted(ROOT.glob('dino*log'))+sorted(ROOT.glob('dino*nvfp4*json'))]
    records = sorted(set(records))
    archive=OUT/'evidence.tar.xz'
    files={name:ROOT/name for name in records}
    files.update({f'earlier_screen/{name}':ROOT.with_name('corpus100k-mixed-precision-v1')/name
                  for name in ('screen.py','full_production.py','quality.py')})
    files['earlier_screen/render.py']=ROOT.with_name('paired-luminance-detail-v1')/'render.py'
    production=('src/demosaic/inference.py','src/demosaic/cli.py','tests/test_inference_alignment.py')
    files.update({f'production/{name}':Path(name) for name in production})
    with tarfile.open(archive,'w:xz',preset=5) as stream:
        for name,path in sorted(files.items()):
            stream.add(path,arcname=name)
    with tarfile.open(archive) as stream:
        for name,path in files.items():
            with stream.extractfile(name) as f:
                assert hashlib.file_digest(f,'sha256').hexdigest()==reference(path)['sha256']
    wstats={}
    for profile in ('iso400','iso6400'):
        rows=[r['scores'] for r in review['wires'] if r['noise']==profile]
        assert len(rows)==24
        wstats[profile]={}
        for arm in ('trt-fp16','trt-selective-fp8'):
            wstats[profile][arm]={}
            for key in rows[0][arm]:
                diffs=np.array([np.array(row[arm][key])-row['eager-fp16'][key] for row in rows])
                wstats[profile][arm][key]={'mean_delta':float(diffs.mean()),'max_abs_delta':float(abs(diffs).max())}
    nvfp4={}
    for name in ('dino-nvfp4.json','dino-nvfp4-fp32-dequantizer.json'):
        if (ROOT/name).exists():
            record=read_json(ROOT/name)
            nvfp4[name]={'attempts':record['attempts'],'kernel_seconds':record['isolated_projection_seconds']}
    summary={
        'workload':ROOT.name,'checkpoint':checkpoint,'archived':reference(archive),
        'native_manifest':reference(IMAGES/'manifest.json'),'native_images_viewed':True,
        'production_source':[reference(name) for name in production],
        'production_CLI':cli,'TensorRT':{'full_frame':review['full_frame'],'export_fidelity':review['TIFF_differences'],
            'trunk_screen':benchmark,'wire_differences':wstats,'exact_scores':{r['id']:r['PSNR_dB'] for r in review['exact']},
            'DINO_NVFP4':nvfp4},
        'scope':'Compiled runtime comparisons cover fixed crops, a 48-case wire panel and full 102 MP for Corpus 100k. No new fixed427 or complete camera panel for TensorRT.'}
    write_json(OUT/'publication.json',summary,replace=True)
    print('Archived',len(files),'files and reviewed',sum(len(views[k]) for k in ('GFX','cab','exact')),'native cases')

if __name__=='__main__':
    main()
