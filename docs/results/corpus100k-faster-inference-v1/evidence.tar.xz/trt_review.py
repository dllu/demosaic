"""Measure full RGB16 export and inspect candidate arithmetic on fixed native inputs."""
from contextlib import ExitStack
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image
import tifffile
import torch

from trt_hidden import Engine, HiddenNetwork, ROOT, calibrate, selected
from screen import policy, load, versions, SHOT, READ
from full_production import gpu_jobs
from quality import ARCHIVE, FIXED, FRESH, KEYS, error
from demosaic.cfa import color_indices, unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.archive_metrics import noisy_malvar, photometry
from demosaic.inference import restore_tiled
from demosaic.io import read_raw, write_rgb16
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
from render import native_png

MODES = ('eager-fp16','trt-fp16','trt-selective-fp8')


def engine_set(model, size):
    result, records = {MODES[0]: None}, {}
    maxima = read_json(ROOT/'calibration.json')['FP8_absmax']
    for arm, scales in ((MODES[1],{}),(MODES[2],maxima)):
        path = ROOT / f'{arm}-pyramid-b4-{size}-opt2.plan'
        began = None
        if not path.exists():
            print('building shape',arm,size,flush=True)
            began = HiddenNetwork(model.pretrained_rgb.network,(size,size),scales).save(path,batch=4,optimization=2)
        result[arm] = Engine(path)
        inspector = ROOT/f'{arm}-layers-{size}-review.json'
        write_json(inspector,result[arm].inspection)
        records[arm] = {'engine': reference(path),'inspector':reference(inspector),'build_seconds':began}
    return result, records


def restore(model, engines, name, raw, colors, shot, read, wb, matrix):
    with selected(model,engines[name]):
        return restore_tiled(model,raw,colors,shot=shot,read=read,tile=512,overlap=64,batch_size=4,
                             device='cuda',wb=wb,matrix=matrix,precision='float16')


def compare_codes(tiffs, flip, main_rois):
    before = tifffile.memmap(checked(tiffs[MODES[0]]))
    assert flip == 0
    results = {}
    for arm in MODES[1:]:
        after = tifffile.memmap(checked(tiffs[arm]))
        assert after.shape == before.shape and before.dtype == after.dtype == np.uint16
        hist = np.zeros(65536,dtype=np.int64)
        max_pixel = (-1,None)
        seam_count = interior_count = seam_sumsq = interior_sumsq = 0
        from demosaic.inference import positions
        def bands(length):
            starts=positions(length,512,448)
            return np.min([abs(np.arange(length) - (a+b+512)/2) for a,b in zip(starts,starts[1:])],axis=0)<=8
        y_band=bands(before.shape[0])
        x_band=bands(before.shape[1])
        for y in range(0,before.shape[0],96):
            delta = np.abs(after[y:y+96].astype(np.int32)-before[y:y+96])
            hist += np.bincount(delta.ravel(),minlength=len(hist))
            if delta.max() > max_pixel[0]:
                v,u,c = np.unravel_index(delta.argmax(),delta.shape)
                max_pixel = (int(delta[v,u,c]),[int(u),int(y+v),int(c)])
            norms = (delta.astype(float)**2).sum(axis=-1)
            mask = y_band[y:y+len(delta),None] | x_band[None,:]
            seam_count += int(mask.sum())*3
            interior_count += int((~mask).sum())*3
            seam_sumsq += float(norms[mask].sum())
            interior_sumsq += float(norms[~mask].sum())
        codes = np.arange(len(hist),dtype=float)
        cdf = hist.cumsum()
        results[arm] = {'channels':int(cdf[-1]),'fraction_exact':float(cdf[0]/cdf[-1]),
                        'fraction_at_most_one':float(cdf[1]/cdf[-1]),
                        'rms_DN16':float(np.sqrt(hist@(codes**2)/cdf[-1])),
                        'max_DN16_and_sensor_xy_channel':max_pixel,
                        'p95_99_999_DN16':np.searchsorted(cdf,cdf[-1]*np.array([.95,.99,.999])).tolist(),
                        'seam_RMS_DN16':float(np.sqrt(seam_sumsq/seam_count)),
                        'interior_RMS_DN16':float(np.sqrt(interior_sumsq/interior_count))}
    return results


def main_boards(predictions, fixture, meta):
    prior_manifest = read_json('docs/images/corpus100k-mixed-precision-v1/manifest.json')
    bound = {row['id']:row for row in prior_manifest['main_views']}
    rows = []
    for region in fixture['regions']:
        name=region['name']
        ref=bound[name]
        prior=np.asarray(Image.open(Path('docs/images/corpus100k-mixed-precision-v1')/Path(ref['board']['image']['path']).name).convert('RGB'))
        panels={part.get('name',part.get('label')):prior[y:y+h,x:x+w] for part in ref['board']['panels']
                for x,y,w,h in (part['png_xywh'],)}
        wb=torch.tensor(meta.white_balance)[None]
        matrix=torch.tensor(meta.camera_to_srgb)[None]
        views={arm:np.rint(display_crop(torch.from_numpy(tiles[name])[None],wb,matrix,
                       (0,0,160,160),exposure=4)*255).astype(np.uint8) for arm,tiles in predictions.items()}
        ordered=[(key,value) for key,value in panels.items() if 'Noisy' in key]
        ordered+=list(views.items())
        ordered += [(key,value) for key,value in panels.items() if 'ISO100' in key]
        board=native_png(ROOT/f'{name}.png',ordered)
        rows.append({'id':name,'board':board,'ROI_xywh':[*region['noisy_xy'],160,160],
                     'exposure':4,'differences':{name:error(tiles[region['name']],predictions[MODES[0]][region['name']])
                        for name,tiles in predictions.items() if name!=MODES[0]},'reference_board':ref})
    return rows


def cab_boards(model, engines):
    edges = []
    for item in read_json(ARCHIVE)['images']:
        name = item['id']
        if not name.startswith('mesh-') or item['role']!='board':
            continue
        previous = item['provenance']
        with np.load(checked(previous['input_arrays']),allow_pickle=False) as source:
            inputs = {k:source[k] for k in KEYS}
        raw = unpack(torch.from_numpy(inputs['packed']))[0,0]
        wb, matrix = inputs['wb'][0], inputs['matrix'][0]
        box = tuple(previous['ROI_xywh'])
        x,y,w,h=box
        crops={}
        views={}
        for arm in MODES:
            prediction,_=restore(model,engines,arm,raw,inputs['colors'][0],previous['noise']['shot'],
                                 previous['noise']['read'],wb,matrix)
            crops[arm]=prediction[:,y:y+h,x:x+w].numpy()
            views[arm]=np.rint(display_crop(prediction[None],torch.from_numpy(inputs['wb']),
                    torch.from_numpy(inputs['matrix']),box,exposure=previous['display_exposure'])*255).astype(np.uint8)
        before=np.asarray(Image.open(checked(item['image'])).convert('RGB'))
        old={part['label']:before[py:py+ph,px:px+pw] for part in previous['panels']
                for px,py,pw,ph in (part['png_xywh'],)}
        ordered=[('Noisy Malvar',old['Noisy Malvar']),*views.items()]
        ordered.extend((label,old[label]) for label in ('ISO100 ref, not GT','SOOC ISO6400 JPEG','SOOC ISO100 JPEG'))
        board=native_png(ROOT/f'{name}.png',ordered)
        edges.append({'id':name,'board':board,'provenance':previous,
                      'differences':{arm:error(crops[arm],crops[MODES[0]]) for arm in MODES[1:]}})
    return edges


def infer(model, engines, arrays, noise, arm):
    model.set_noise(noise['shot'],noise['read'])
    args=[torch.from_numpy(arrays[k].copy()).cuda() for k in KEYS]
    args[0]=args[0].contiguous(memory_format=torch.channels_last)
    with selected(model,engines.get(arm)),policy(model,'fp32' if arm=='ieee-fp32' else 'fp16'):
        result=model(*args)
    assert result.dtype==torch.float32 and torch.isfinite(result).all()
    return result.cpu().numpy()


def quality_targets(model, engines):
    fixed=read_json(FIXED)
    old=read_json('docs/results/full-corpus-long100k-primary-v1/primary.json')
    canonical=read_json(checked(old['canonical_inputs']))
    rows=[]
    for name,photo in zip(('railway','dahlia'),fixed['boards'],strict=True):
        bound=photo['fixed_native_input']
        context=next(r['context'] for r in canonical['records'] if r['arrays']==bound)
        index=context['ids'].index(photo['source']['id'])
        with np.load(checked(bound),allow_pickle=False) as source:
            inputs={k:source[k][index:index+1] for k in (*KEYS,'target')}
        outputs={arm:infer(model,engines,inputs,photo['noise'],arm) for arm in ('ieee-fp32',*MODES)}
        board=native_board(ROOT,name,[noisy_malvar(inputs)[0],*[v[0] for v in outputs.values()],inputs['target'][0]],inputs,
              {k:photo[k] for k in ('source','checkpoint','CFA','noise','fixed_native_input','ADC_bits','black_level')},
              labels=('Noisy Malvar',*outputs,'Exact GT'),triplet_indices=(0,3,5),
              exposure=photo['display_exposure'],roi=photo['ROI_xywh'])
        rows.append({'id':name,'board':board,'PSNR_dB':{arm:float(photometry(rgb,inputs)['srgb_psnr'][0]) for arm,rgb in outputs.items()},
                    'differences':{arm:error(outputs[arm],outputs['ieee-fp32']) for arm in MODES}})
    return rows


def wire_review(model, engines):
    from demosaic.archive_metrics import linear_rgb
    parameters=read_json(FRESH)
    captures=read_json(FRESH.parent/'captures.json')
    rows=[]
    luma=np.array([.2126,.7152,.0722])
    y,x=np.indices((128,128),dtype=float)-63.5
    for case in captures['rows']:
        profile=parameters['profiles'][case['noise']]
        setup=parameters['sources'][case['index']]['geometry']
        with np.load(checked(case['input']),allow_pickle=False) as source:
            arrays={k:source[k][...,64:192,64:192] if k in ('packed','variance') else source[k] for k in KEYS}
            arrays['target']=source['target'][...,128:384,128:384]
            support=source['support'][64:192,64:192]>=.97
        carriers=np.asarray(setup['frequency'])
        z=2*np.pi*(carriers@np.stack([x.ravel(),y.ravel()]))
        terms=np.column_stack([np.ones(x.size),x.ravel(),y.ravel(),(x*x).ravel(),(x*y).ravel(),(y*y).ravel(),
                  np.cos(z[0]),np.sin(z[0]),np.cos(z[1]),np.sin(z[1])])[support.ravel()]
        fit=np.linalg.pinv(terms)[-4:]
        truth=linear_rgb(arrays['target'],arrays)
        truth_y=np.einsum('c,bchw->bhw',luma,truth)
        mid=np.s_[...,64:192,64:192]
        true_step=(truth_y[0]-truth_y[2])[mid][support]
        wire=fit@true_step
        scores={}
        for arm in MODES:
            rgb=infer(model,engines,arrays,profile,arm)
            value=linear_rgb(rgb,arrays)
            ly=np.einsum('c,bchw->bhw',luma,value)
            step=(ly[0]-ly[2])[mid][support]
            weak=fit@step
            flat=value[3,:,72:184,72:184]
            lflat=ly[3,72:184,72:184]
            chroma=flat-lflat[None]
            scores[arm]={'weak_response_pct':float(100*weak[-2:]@wire[-2:]/(wire[-2:]@wire[-2:])),
                         'increment_RMS_DN16':float(np.sqrt(np.mean((step-true_step)**2))*65535),
                         'flat_luma_RMS_DN16':float(np.std(lflat)*65535),
                         'flat_chroma_RMS_DN16':float(np.sqrt(np.mean((chroma-chroma.mean((1,2),keepdims=True))**2))*65535),
                         'flat_channel_bias_DN16':((flat-truth[3,:,72:184,72:184]).mean((1,2))*65535).tolist()}
        rows.append({'index':case['index'],'noise':case['noise'],'input':case['input'],'scores':scores})
    return rows


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    fixture=read_json('configs/gfx-qualitative-20231231.json')
    source=reference(fixture['noisy'])
    start=time.perf_counter()
    raw,meta=read_raw(source['path'])
    decoded=time.perf_counter()
    model,checkpoint=load()
    torch.cuda.synchronize()
    staged=time.perf_counter()
    engines, records=engine_set(model,512)
    ready=time.perf_counter()
    stream=torch.cuda.Stream()
    start_jobs=gpu_jobs()
    tiffs, images, times={},{},[]
    with torch.cuda.stream(stream):
        for i, arm in enumerate((*MODES, MODES[0])):
            # Warm once on exactly four tiles. The full frame divides evenly by batch four.
            restore(model,engines,arm,raw[512:1024,512:2304],color_indices(meta.pattern),SHOT,READ,
                    meta.white_balance,meta.camera_to_srgb)
            prediction,timing=restore(model,engines,arm,raw,color_indices(meta.pattern),SHOT,READ,
                    meta.white_balance,meta.camera_to_srgb)
            writer_start=time.perf_counter()
            output=ROOT/f'review-{arm}-{i}.tiff'
            write_rgb16(output,prediction.permute(1,2,0).numpy(),metadata=meta,flip=meta.flip)
            writer_seconds=time.perf_counter()-writer_start
            tiff=reference(output)
            times.append({'arm':arm,'restore':timing,'export_seconds':writer_seconds,'RGB16':tiff,'jobs_after':gpu_jobs()})
            if arm not in tiffs:
                tiffs[arm]=tiff
                images[arm]={r['name']:prediction[:,r['noisy_xy'][1]:r['noisy_xy'][1]+160,
                              r['noisy_xy'][0]:r['noisy_xy'][0]+160].clone().numpy() for r in fixture['regions']}
            del prediction
            print(i,arm,timing['seconds'],writer_seconds,flush=True)
        cab=cab_boards(model,engines)
    torch.cuda.synchronize()
    del raw
    small, small_records = engine_set(model,256)
    with torch.cuda.stream(stream):
        exact=quality_targets(model,small)
        wire=wire_review(model,small)
    torch.cuda.synchronize()
    receipt={'driver':reference(__file__),'checkpoint':checkpoint,'source':source,'noise':{'shot':SHOT,'read':READ},
             'versions':versions(),'calibration':reference(ROOT/'calibration.json'),'engines':records,'small_engines':small_records,
             'decode_seconds':decoded-start, 'checkpoint_setup_seconds':staged-decoded,'load_engines_seconds':ready-staged,
             'full_frame':times,'TIFF_differences':compare_codes(tiffs,meta.flip,fixture['regions']),
             'GFX':main_boards(images,fixture,meta),'cab':cab,'exact':exact,'wires':wire,'jobs_before':start_jobs,
             'scope':'Shared GB10, one process with all engines warm, identical tile grid and camera arithmetic. Eager bracketed.'}
    write_json(ROOT/'trt-review.json',receipt)


if __name__=='__main__':
    main()
