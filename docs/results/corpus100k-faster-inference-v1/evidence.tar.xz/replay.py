"""Benchmark persistent autocast and fixed-shape CUDA graph replay."""
from contextlib import contextmanager, nullcontext
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name('corpus100k-mixed-precision-v1')))
from screen import load, policy, statistics, versions, SHOT, READ
from full_production import gpu_jobs
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.io import read_raw


def timed(fn):
    torch.cuda.synchronize()
    start = time.perf_counter()
    out = fn()
    torch.cuda.synchronize()
    return out, time.perf_counter() - start


class GraphReplay:
    def __init__(self, model, example):
        self.static = tuple(tensor.clone(memory_format=torch.preserve_format) for tensor in example)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side), torch.autocast('cuda', dtype=torch.float16, cache_enabled=False):
            for _ in range(3):
                model(*self.static)
        torch.cuda.current_stream().wait_stream(side)
        self.graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.graph, stream=side), torch.autocast(
            'cuda', dtype=torch.float16, cache_enabled=False
        ):
            self.output = model(*self.static)

    def __call__(self, *args):
        for static, dynamic in zip(self.static, args, strict=True):
            static.copy_(dynamic)
        self.graph.replay()
        return self.output


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1., 12*2**30/torch.cuda.get_device_properties(0).total_memory))
    initialized = time.perf_counter()
    config = read_json('configs/gfx-qualitative-20231231.json')
    source = reference(config['noisy'])
    raw, meta = read_raw(source['path'])
    model, checkpoint = load()
    model.set_noise(SHOT, READ)
    positions = [(r['noisy_xy'][0]-176, r['noisy_xy'][1]-176) for r in config['regions']]
    tiles = np.stack([raw[y:y+512, x:x+512] for x,y in positions])
    sensor = pack(torch.from_numpy(tiles[:, None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors = torch.as_tensor(color_indices(meta.pattern), device='cuda')[None].expand(4,-1)
    wb = torch.as_tensor(meta.white_balance, device='cuda', dtype=torch.float32)[None].expand(4,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb, device='cuda', dtype=torch.float32)[None].expand(4,-1,-1)
    inputs = [(s, s.clamp_min(0)*SHOT+READ, colors, wb, matrix) for s in (sensor, sensor.flip(0))]
    print('ready',time.perf_counter()-initialized, flush=True)
    timings = {}
    differences = {}
    errors = {}
    reference_outputs = []
    for args in inputs:
        with policy(model, 'fp16'):
            reference_outputs.append(model(*args).cpu().numpy())
    make = None
    try:
        replay, make = timed(lambda: GraphReplay(model, inputs[0]))
    except RuntimeError as error:
        errors['graph'] = str(error)
        replay = None
        print(str(error), flush=True)

    def eager(args):
        with policy(model, 'fp16'):
            return model(*args)

    arms = {'eager': eager, 'persistent': lambda args: eager(args)}
    if replay is not None:
        arms['graph'] = lambda args: replay(*args)
    loops = 4
    for trial in range(6):
        order = list(arms) if trial%2==0 else list(arms)[::-1]
        for mode in order:
            context = torch.autocast('cuda', dtype=torch.float16) if mode=='persistent' else nullcontext()
            with context:
                # Cache populated before the warmed timing.
                result = arms[mode](inputs[0])
                for index in range(2):
                    delta = statistics(arms[mode](inputs[index]).cpu().numpy(), reference_outputs[index])
                    differences.setdefault(mode, []).append(delta)
                _, elapsed = timed(lambda: [arms[mode](inputs[i%2]) for i in range(loops)])
            timings.setdefault(mode, []).append(elapsed/loops)
        print(trial, {k: v[-1] for k,v in timings.items()}, flush=True)
    write_json(ROOT/'replay.json', {
        'driver': reference(__file__), 'checkpoint': checkpoint, 'source': source,
        'backend': versions(), 'positions': positions, 'shot': SHOT, 'read': READ,
        'batch': 4, 'tile': 512, 'jobs_after': gpu_jobs(), 'graph_create_seconds': make,
        'errors': errors, 'seconds_per_forward': timings, 'FP16_differences': differences})
    print({k: float(np.median(v)) for k,v in timings.items()}, flush=True)


if __name__ == '__main__':
    main()
