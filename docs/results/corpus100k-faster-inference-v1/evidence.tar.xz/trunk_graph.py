"""Capture the restoration trunk alone, so CFA and camera constants stay eager."""
from contextlib import contextmanager
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.with_name('corpus100k-mixed-precision-v1')))
from screen import load, statistics, versions, SHOT, READ
from full_production import gpu_jobs
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.io import read_raw
from replay import GraphReplay, timed


@contextmanager
def captured(network):
    original = network.forward
    capture_seconds = []
    replay = None
    def fn(rgb,noise,head,middle,half,quarter):
        return original(rgb,noise,head_offset=head,middle_offset=middle,encoder_offsets=(half,quarter))
    def forward(rgb,noise,*,head_offset=None,middle_offset=None,encoder_offsets=None,return_features=False):
        nonlocal replay
        if return_features or encoder_offsets is None or head_offset is None or middle_offset is None:
            raise ValueError('Expected the anchored DRUNet and pyramid offsets')
        args = (rgb, noise, head_offset, middle_offset, *encoder_offsets)
        if replay is None:
            start=time.perf_counter()
            replay = GraphReplay(fn,args)
            capture_seconds.append(time.perf_counter()-start)
        return replay(*args)
    network.forward = forward
    try:
        yield capture_seconds
    finally:
        network.forward = original


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    config = read_json('configs/gfx-qualitative-20231231.json')
    source = reference(config['noisy'])
    raw,meta = read_raw(source['path'])
    model,checkpoint = load()
    model.set_noise(SHOT,READ)
    positions = [(r['noisy_xy'][0]-176,r['noisy_xy'][1]-176) for r in config['regions']]
    tiles = np.stack([raw[y:y+512,x:x+512] for x,y in positions])
    del raw
    sensor = pack(torch.from_numpy(tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    colors = torch.as_tensor(color_indices(meta.pattern),device='cuda')[None].expand(4,-1)
    wb = torch.as_tensor(meta.white_balance,device='cuda',dtype=torch.float32)[None].expand(4,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb,device='cuda',dtype=torch.float32)[None].expand(4,-1,-1)
    inputs = [(s,s.clamp_min(0)*SHOT+READ,colors,wb,matrix) for s in (sensor,sensor.flip(0))]
    def eager(args):
        with torch.autocast('cuda',dtype=torch.float16):
            return model(*args)
    key = model.pretrained_rgb.network
    reference_outputs = [eager(args).cpu().numpy() for args in inputs]
    eager_forward = key.forward
    with captured(key) as build:
        graph_forward = key.forward
        images = [eager(args).cpu().numpy() for args in inputs]
        differences = [statistics(image,base) for image,base in zip(images,reference_outputs,strict=True)]
        timing = {'eager':[], 'graph':[]}
        for i in range(8):
            for mode in (('eager','graph') if i%2==0 else ('graph','eager')):
                key.forward = graph_forward if mode=='graph' else eager_forward
                eager(inputs[0])
                _,elapsed = timed(lambda: [eager(inputs[j%2]) for j in range(4)])
                timing[mode].append(elapsed/4)
            print(i,{k:v[-1] for k,v in timing.items()},flush=True)
    row = {'driver':reference(__file__), 'checkpoint':checkpoint,'source':source,'positions':positions,
           'noise':{'shot':SHOT,'read':READ},'backend':versions(),'other_jobs':gpu_jobs(),
           'capture_seconds':build,'differences':differences,'seconds_per_forward':timing,
           'median':{k:float(np.median(v)) for k,v in timing.items()}}
    write_json(ROOT/'trunk-graph.json',row)
    print(row['median'],differences,flush=True)


if __name__=='__main__':
    main()
