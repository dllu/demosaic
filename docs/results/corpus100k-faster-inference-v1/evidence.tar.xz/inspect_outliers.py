"""Render native neighborhoods around the two worst exported code differences."""
from pathlib import Path
import sys

import numpy as np
import tifffile
import torch

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
from render import native_png
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop


def main():
    proof=read_json(ROOT/'trt-review.json')
    fixture=read_json('configs/gfx-qualitative-20231231.json')
    _, metadata=read_raw(checked(proof['source']))
    assert metadata.flip==0
    wb = torch.as_tensor(metadata.white_balance,dtype=torch.float32)[None]
    matrix = torch.as_tensor(metadata.camera_to_srgb,dtype=torch.float32)[None]
    tiffs={row['arm']:tifffile.memmap(checked(row['RGB16'])) for row in proof['full_frame'][:3]}
    rows=[]
    for arm, row in proof['TIFF_differences'].items():
        maximum, (x,y,c)=row['max_DN16_and_sensor_xy_channel']
        x0 = min(max(x-80,0),tiffs[arm].shape[1]-160)
        y0 = min(max(y-80,0),tiffs[arm].shape[0]-160)
        sector=[]
        for mode in ('eager-fp16',arm):
            arr=tiffs[mode][y0:y0+160,x0:x0+160]
            image=torch.from_numpy(arr.astype(np.float32)).permute(2,0,1)[None]/65535.
            display=display_crop(image,wb,matrix,(0,0,160,160),exposure=1)
            sector.append((mode,np.rint(display*255).astype(np.uint8)))
        coordinates = [x0,y0,160,160]
        assert abs(int(tiffs[arm][y,x,c])-int(tiffs['eager-fp16'][y,x,c]))==maximum
        rows.append({'arm':arm,'roi_xywh':coordinates,'pixel_xyc':[x,y,c],'difference_DN16':maximum,
                     'image':native_png(ROOT/f'{arm}-outlier.png',sector),'display_exposure':1,'timing_receipt':reference(ROOT/'trt-review.json')})
    write_json(ROOT/'outliers.json',{'driver':reference(__file__),'config':reference('configs/gfx-qualitative-20231231.json'),'rows':rows})

if __name__=='__main__':
    main()
