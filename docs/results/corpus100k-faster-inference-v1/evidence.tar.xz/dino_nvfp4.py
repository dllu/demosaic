"""Screen two native NVFP4 pointwise projections in one DINO ConvNeXt block."""
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
import tensorrt as trt

from trt_hidden import LOGGER, RUNTIME, ROOT
from replay import timed
from screen import load, policy, statistics, versions, SHOT, READ
from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.scene_data import observe_scene, SceneRecipe

HALF, FLOAT = trt.DataType.HALF, trt.DataType.FLOAT
FP4, FP8 = trt.DataType.FP4, trt.DataType.FP8


class PointwiseEngine:
    def __init__(self, layer, shape, activation_max, use_nvfp4, path):
        b = trt.Builder(LOGGER)
        n = b.create_network()
        constants=[]
        def constant(value):
            array = np.ascontiguousarray(value)
            constants.append(array)
            return n.add_constant(array.shape,array).get_output(0)
        def nvfp4(value, scale):
            common = constant(np.asarray([max(scale/(448*6),1e-12)],dtype='float32'))
            q = n.add_dynamic_quantize(value,1,16,FP4,FP8)
            q.set_input(1,common)
            block = n.add_dequantize(q.get_output(1),common,FLOAT).get_output(0)
            restore = n.add_dequantize(q.get_output(0),block,HALF)
            restore.axis = 1
            return restore.get_output(0)
        tokens = int(np.prod(shape[:-1]))
        ch = shape[-1]
        x = n.add_input('activations',HALF,(tokens,ch))
        weights = layer.weight.detach().cpu().half().numpy().copy(order='C')
        w = constant(weights)
        if use_nvfp4:
            x = nvfp4(x,activation_max)
            w = nvfp4(w,float(abs(weights).max()))
        projected = n.add_matrix_multiply(x,trt.MatrixOperation.NONE,w,trt.MatrixOperation.TRANSPOSE)
        projected.name='DINO pointwise'
        result = n.add_elementwise(projected.get_output(0),
                                   constant(layer.bias.detach().cpu().half().numpy()[None]),
                                   trt.ElementWiseOperation.SUM).get_output(0)
        result.name='projected'
        n.mark_output(result)
        config = b.create_builder_config()
        config.clear_flag(trt.BuilderFlag.TF32)
        config.builder_optimization_level=2
        config.profiling_verbosity=trt.ProfilingVerbosity.DETAILED
        start=time.perf_counter()
        plan=b.build_serialized_network(n,config)
        if plan is None:
            raise RuntimeError(f'TensorRT did not build {path.name}')
        path.write_bytes(bytes(plan))
        self.build_seconds = time.perf_counter()-start
        self.engine = RUNTIME.deserialize_cuda_engine(bytes(plan))
        self.context = self.engine.create_execution_context()
        self.inspection = self.engine.create_engine_inspector().get_engine_information(trt.LayerInformationFormat.JSON)
        self.result=torch.empty((*shape[:-1],layer.out_features),device='cuda',dtype=torch.float16)
        self.shape=shape

    def __call__(self, value):
        assert value.shape == self.shape
        x = value.to(torch.float16).contiguous()
        assert self.context.set_tensor_address('activations',x.data_ptr())
        assert self.context.set_tensor_address('projected',self.result.data_ptr())
        assert self.context.execute_async_v3(torch.cuda.current_stream().cuda_stream)
        return self.result


@torch.inference_mode()
def main():
    import json
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,8*2**30/torch.cuda.get_device_properties(0).total_memory))
    model,binding=load()
    # The first block of the third ConvNeXt stage has an 8x larger internal
    # width than the stem output across the two pointwise projections.
    names, layers = zip(*[(k,m) for k,m in model.context.backbone.named_modules()
                     if isinstance(m,nn.Linear) and 'stages.2.layers.0.' in k])
    assert len(layers)==2
    captured = {}
    hooks=[]
    maxima={}
    def hook(index):
        def record(m,args):
            value=args[0].half()
            captured[index]=value.contiguous()
            maximum=value.abs().amax()
            maxima[index]=maximum if index not in maxima else torch.maximum(maxima[index],maximum)
        return record
    for i,m in enumerate(layers):
        hooks.append(m.register_forward_pre_hook(hook(i)))
    calibrate=read_json(ROOT/'calibration.json')
    samples=calibrate['observations'][::3]
    for row in samples:
        data=np.load(checked(row['source']),mmap_mode='r',allow_pickle=False)
        x,y,w,h=row['xywh']
        rgb=torch.from_numpy(data[y:y+h,x:x+w].astype('float32')).permute(2,0,1)/65535
        recipe=SceneRecipe(**row['recipe'])
        sample=observe_scene(rgb,recipe)
        args=[getattr(sample,k)[None].cuda() for k in ('packed','variance','colors','wb','matrix')]
        model.set_noise(recipe.shot,recipe.read)
        with policy(model,'fp16'):
            model(*args)
    peak = {index:float(value) for index,value in maxima.items()}
    fixture=read_json('configs/gfx-qualitative-20231231.json')
    raw_bound=reference(fixture['noisy'])
    raw,meta=read_raw(raw_bound['path'])
    xy=[(r['noisy_xy'][0]-176,r['noisy_xy'][1]-176) for r in fixture['regions']]
    mosaics=np.stack([raw[y:y+512,x:x+512] for x,y in xy])
    del raw
    inp=pack(torch.from_numpy(mosaics[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    args=(inp,inp.clamp_min(0)*SHOT+READ,torch.as_tensor(color_indices(meta.pattern),device='cuda')[None].expand(4,-1),
          torch.as_tensor(meta.white_balance,device='cuda')[None].expand(4,-1),
          torch.as_tensor(meta.camera_to_srgb,device='cuda')[None].expand(4,-1,-1))
    model.set_noise(SHOT,READ)
    with policy(model,'fp16'):
        base=model(*args).cpu().numpy()
    for h in hooks:
        h.remove()
    scope=torch.cuda.Stream()
    rows=[]
    timing={}
    differences={}
    attempts={}
    for mode in ('trt-fp16','trt-nvfp4'):
        built=[]
        details=[]
        for i,layer in enumerate(layers):
            path=ROOT/f'dino-{mode}-{i}.plan'
            try:
                engine=PointwiseEngine(layer,captured[i].shape,peak[i],mode=='trt-nvfp4',path)
            except RuntimeError as error:
                attempts[mode]={'error':str(error)}
                print(error,flush=True)
                break
            inspect=ROOT/f'dino-{mode}-{i}-layers.json'
            write_json(inspect,json.loads(engine.inspection))
            built.append(engine)
            details.append({'name':names[i],'shape':list(captured[i].shape),'build_seconds':engine.build_seconds,
                            'engine':reference(path),'inspector':reference(inspect),'activation_absmax':peak[i]})
        if len(built)==len(layers):
            rows.append((mode,built))
            attempts[mode]={'layers':details}
    original=[layer.forward for layer in layers]
    with torch.cuda.stream(scope):
        for j in range(8):
            order=[('eager',original),*rows]
            for mode,pair in (order if j%2==0 else order[::-1]):
                for layer,forward in zip(layers,pair,strict=True):
                    layer.forward=forward
                with policy(model,'fp16'):
                    estimate=model(*args)
                    _,elapsed=timed(lambda:model(*args))
                timing.setdefault(mode,[]).append(elapsed)
                if j==0:
                    differences[mode]=statistics(estimate.cpu().numpy(),base)
            print(j,{k:x[-1] for k,x in timing.items()},flush=True)
        micro={name:[] for name,_ in rows}
        for name, engines in rows:
            for i,engine in enumerate(engines):
                _,elapsed=timed(lambda:[engine(captured[i]) for _ in range(40)])
                micro[name].append(elapsed/40)
    write_json(ROOT/'dino-nvfp4.json',{'driver':reference(__file__),'checkpoint':binding,'backend':versions(),
                'case':raw_bound,'tiles':xy,'calibration':reference(ROOT/'calibration.json'),
                'calibration_ids':[row['id'] for row in samples],'attempts':attempts,'forward_seconds':timing,
                'isolated_projection_seconds':micro,'camera_RGB_difference_vs_eager_FP16':differences})
if __name__=='__main__':
    main()
