"""Time the added evidence on saved 256-pixel Bayer queries without inference or IO."""
import os
import time
import platform

import numpy as np

from phase_edge import ROOT,scores
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import measure_witnesses

def main():
    binding=reference(ROOT/"standing/manifest.json")
    prior=read_json(checked(binding))
    rows=[]
    for record in prior["rows"]:
        path=checked(record["input"])
        # Each stored array is larger than the native 256-pixel query.
        # Reuse the matching archived full model coordinates.
        shape=record["native_box"]
        old=read_json(checked(prior["prior_native"]))
        mode=next(x for x in old["rows"]if x["id"]==record["id"])
        scenes=read_json(checked(old["earlier_standing"]))
        spec=next(x for x in scenes["boards"]if x["id"]==record["id"])
        x,y,_,_=spec["case"]["ROI_xywh"]
        roi=mode["roi"]
        xx,yy=x-roi[0],y-roi[1]
        with np.load(path,allow_pickle=False) as store:
            mosaic=np.ascontiguousarray(store["packed"][0,:,yy//2:yy//2+128,xx//2:xx//2+128])
            cfa=store["colors"][0]
        assert mosaic.shape==(4,128,128) and shape[2:]==[256,256]
        noise=record["noise"]
        phase=measure_witnesses(mosaic,cfa,noise)
        def old_path():
            return measure_witnesses(mosaic,cfa,noise)
        def new_stage():
            return scores(mosaic,cfa,noise,phase)
        call={"phase_nomination":old_path,"additional_validation":new_stage}
        readings={k:[] for k in call}
        for name, fn in call.items():
            fn()
        for i in range(11):
            schedule=list(call)
            if i%2:
                schedule.reverse()
            for name in schedule:
                start=time.perf_counter_ns()
                call[name]()
                readings[name].append((time.perf_counter_ns()-start)/1e6)
        rows.append({"id":record["id"],"input":record["input"],"measurements_ms":readings,
                     "median_ms":{k:float(np.median(v))for k,v in readings.items()}})
    write_json(ROOT/"timing.json",{"driver":reference(__file__),"operator":reference(ROOT/"phase_edge.py"),
        "input":binding,"system":platform.uname()._asdict(),"openblas_threads":os.environ.get("OPENBLAS_NUM_THREADS"),
        "scope":"CPU resident RAW, phase determined once beforehand for the validation runtime. 11 warmed interleaved calls per arm on each of eight fixed queries. Excludes RAW decoding, model inference, blending and export.",
        "rows":rows})
    print([row["median_ms"] for row in rows],flush=True)
if __name__=="__main__":
    main()
