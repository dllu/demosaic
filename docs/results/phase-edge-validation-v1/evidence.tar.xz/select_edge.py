"""Set gains on disjoint calibration observations before scoring holdouts."""
import numpy as np

from edge_choices import ROOT, GATES, PHASE_NAMES
from select_activity import table
from demosaic.experiments.artifacts import checked, reference, read_json, write_json

CANDIDATES=PHASE_NAMES+("replace-predictive-affine","replace-predictive-edge")
GRID=np.column_stack((np.linspace(0,1.5,151),np.zeros(151)))


def one(rows, group, caps):
    permitted = [gate for gate,*_ in GATES if gate==group or gate.rsplit("-",1)[0]==group]
    values=[]
    for gate in permitted:
        metrics=table(rows,gate,GRID)
        keep=np.ones(len(GRID),dtype=bool)
        for key,cap in caps.items():
            keep&=metrics[key] <= cap
        if keep.any():
            index=int(np.argmax(np.where(keep,metrics["response"],-np.inf)))
            values.append({"gate":gate,"gain":float(GRID[index,0]),"quiet":0.,
                            "metrics":{k:float(v[index])for k,v in metrics.items()}})
    return max(values,key=lambda x:x["metrics"]["response"]) if values else None


def main():
    selections,detail={},{}
    for kind in ("photo","wire"):
        path=reference(ROOT/f"calibration-{kind}.json")
        receipt=read_json(checked(path))
        assert receipt["gate_parameters"]==[list(gate)for gate in GATES]
        cohort=[row for row in receipt["rows"]if row["iso"]=="iso6400"]
        assert len(cohort)==(16 if kind=="photo" else 24)
        anchor=table(cohort,"activity",[(1.,0.)])
        metrics=("flat",) if kind=="photo" else ("flat_added","gap_added")
        caps={key:float(anchor[key][0])for key in metrics}
        results={g:one(cohort,g,caps)for g in ("uniform",*CANDIDATES)}
        detail[kind]={"source":path,"limits":caps,"groups":results}
        selections|={f"{kind}-{key}":{k:r[k] for k in ("gate","gain","quiet")}
                      for key,r in results.items()if r is not None}
        print(kind,"limits",caps)
        for key,res in results.items():
            print(key,res)
    selections|={"local20k":{"gate":"uniform","gain":0.,"quiet":0.},
                 "Bayer-gated":{"gate":"uniform","gain":1.,"quiet":0.},
                 "activity":{"gate":"activity","gain":1.,"quiet":0.}}
    write_json(ROOT/"selection.json",{"driver":reference(__file__),"calibration":detail,
        "policies":selections,"gain_grid":[0.,1.5,.01],
        "selection_rule":"Choose the highest signed response within the moderate activity arm's exact-flat RMS on calibration photos. On calibration wires require both its flat-addition and gap-addition RMS ceilings. No parameter depends on the holdout."})


if __name__=="__main__":
    main()
