"""Score frozen local phase gates on calibration and independently held-out cases."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
import sys
import time

import numpy as np
import torch

from edge_choices import ACTIVITY, ROOT, GATES, choices
from activity import PRIOR
from score_activity import gram, pair_measure
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_quiet import LOCAL, CORE, load, photo_inputs, wire_inputs
from head_corrected_broad import EXACT_FLAT
import evaluate_gap_head as review


def collect(data, noise, box, exterior, local, model, transform):
    donors = review.exterior(exterior, data["colors"][0], noise, box)
    mapped, stats = [], []
    for role, (mosaic, pattern, wb, matrix) in enumerate(zip(data["packed"],data["colors"],data["wb"],data["matrix"],strict=True)):
        value, activity = choices(mosaic, pattern, noise, box, donors, local[role], wb, matrix, model)
        rgb=np.stack(tuple(value.values()))
        metric=transform(rgb,role)
        mapped.append(np.stack((metric,np.zeros_like(metric)),axis=1))
        scores,edges=activity
        stats.append({"score_quantiles":np.percentile(scores[:,EXACT_FLAT], [10,50,90],axis=(1,2)).tolist(),
                      "edge_fraction":[float(np.mean(e>=0))for e in edges]})
    return np.stack(mapped, axis=1), stats


def photo(pointer, model):
    test, data, parents, proof = photo_inputs(pointer)
    bands = partial(review.old.target_coeff, roi=review.old.ROI)
    measurements = np.stack([bands(array, data) for array in (data["target"], parents[LOCAL],parents["100k"])])
    def score_residual(rgb, role):
        calibration = {key: data[key][role:role+1] for key in ("wb", "matrix")}
        return bands(rgb, calibration)
    delta,stats = collect(data,test["profile"],test["box"],data["scene_packed"],parents[LOCAL],model,score_residual)
    divisor = 96**2
    truth, local, older = measurements
    increment = truth[0]-truth[1]
    restored = local[0]-local[1]
    results = {}
    for gate,(present,attenuated,flat) in zip(GATES,delta,strict=True):
        response, error = pair_measure(restored,present-attenuated,increment,divisor)
        results[gate[0]]={"response":response,"increment":error,"flat":gram(local[2]-truth[2],flat,divisor),
                          "present":gram(local[0]-truth[0],present,divisor)}
    ctrl,ctrl_error = pair_measure(older[0]-older[1],np.zeros((2,*increment.shape)),increment,divisor)
    results["100k"] = {"response":ctrl,"increment":ctrl_error,
                       "flat":gram(older[2]-truth[2],np.zeros((2,*truth[2].shape)),divisor),
                       "present":gram(older[0]-truth[0],np.zeros((2,*truth[0].shape)),divisor)}
    return {"id":test["id"],"source":test["source"],"draw":test["draw"],"iso":test["profile"]["name"],
            "input":test["input"],"local":proof,"activity_quantiles":stats,"results":results}


def wire(task, model, plan, lookup, v120):
    data, parents, proof = wire_inputs(task,lookup,v120)
    local=parents[LOCAL]
    noise=plan["profiles"][task["noise"]]
    def luma(a, calibration):
        return review.old.luma(a,calibration)[...,CORE[0],CORE[1]]
    delta,stats=collect(data,noise,plan["query"],data["full"],local,model,lambda a,k:luma(a,{key:data[key][k:k+1] for key in ("wb","matrix")}))
    truth=luma(data["target"],data)
    parent=luma(local,data)
    support=data["support"][CORE]
    intact,gap = support>=.97,support<=.01
    dip=(support>.01)&(support<=.65)
    inc=truth[0]-truth[1]
    restored=parent[0]-parent[1]
    cases={}
    for gate,(present,attenuated,weak_free,flat) in zip(GATES,delta,strict=True):
        projected,intact_error=pair_measure(restored[intact],(present-attenuated)[:,intact],inc[intact])
        cases[gate[0]]={"response":projected,"increment":intact_error,
                       "flat":gram(parent[3,8:-8,8:-8]-truth[3,8:-8,8:-8],flat[:,8:-8,8:-8]),
                       "flat_added":gram(np.zeros_like(flat[0,8:-8,8:-8]),flat[:,8:-8,8:-8]),
                       "present":gram(parent[0]-truth[0],present),
                       "gap":gram(parent[0][gap]-truth[0][gap],present[:,gap]) if gap.any() else None,
                       "gap_added":gram(np.zeros_like(present[0,gap]),present[:,gap]) if gap.any() else None,
                       "gap_pair":gram(restored[gap]-inc[gap],(present-attenuated)[:,gap]) if gap.any() else None,
                       "dip":pair_measure(restored[dip],(present-attenuated)[:,dip],inc[dip])[0] if dip.any() else None}
    source=plan["sources"][task["index"]]
    return {"id":f'{task["index"]:03d}-{task["noise"]}',"source":source["source"]["id"],
            "iso":task["noise"],"input":task["input"],"local":proof,"family":source["geometry"]["family"],
            "activity_quantiles":stats,"results":cases}


def check_scores(receipt, prior, kind, maximum=.008):
    saved={r["id"]:r for r in read_json(checked(prior))["rows"]}
    for record in receipt["rows"]:
        r=record["results"]["uniform"]
        prev=saved[record["id"]]["metrics"]
        for scale, values in ((0,prev[LOCAL]),(1,prev["witness-gated"])):
            keys= [("increment","increment_rms"),("flat","flat_rms"),("present","present_rms")] if kind=="photo" else [
                ("increment","intact_rms"),("present","present_rms"),("gap","gap_exact"),("gap_pair","gap_pair"),
                ("gap_added","gap_added"),("flat_added","flat_added")]
            for source,target in keys:
                if r[source] is not None:
                    actual=float(np.sqrt(np.asarray(r[source])@[1,scale,scale**2,0,0,0]))
                    assert abs(actual-values[target])<maximum, (record["id"],scale,target,actual,values[target])


def main(stage):
    torch.set_num_threads(1)
    models, training, endpoint=load(raw_weights=False)
    model=models["witness-gated"]
    prior=reference(PRIOR/"natural-results.json")
    source=read_json(checked(prior))["inputs"]
    cases=read_json(checked(source))["records"]
    intersection=review.panel_membership()
    selected=[]
    for ptr in cases:
        metadata=read_json(checked(read_json(checked(ptr))["case"]))
        candidate=metadata["source"] in intersection
        if stage=="calibration" and candidate and metadata["profile"]["name"]=="iso6400" and metadata["draw"]=="independent":
            selected.append(ptr)
        if stage=="holdout" and not candidate:
            selected.append(ptr)
    assert len(selected)==(16 if stage=="calibration" else 192)
    prior_wire=reference(PRIOR/("wire-calibration.json" if stage=="calibration" else "wire-results.json"))
    bind=reference(PRIOR/("wire-tune-parent.json" if stage=="calibration" else "wire-parent.json"))
    bank=read_json(checked(bind))
    assignments=read_json(checked(bank["inputs"]))["rows"]
    wire_plan=read_json(checked(bank["plan"]))
    assert len(assignments)==(24 if stage=="calibration" else 48)
    # Calibration comparisons are gain sweeps of the frozen phase component.
    v120=None
    if stage=="holdout":
        comp=read_json(checked(reference(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")))
        assert comp["source"]==bank["inputs"]
        v120={r["input"]["sha256"]:r for r in comp["rows"]}
    base_binding={"driver":reference(__file__),"activity":reference(ROOT/"phase_edge.py"),"choices":reference(ROOT/"edge_choices.py"),
                  "training":training,"component":endpoint["checkpoint"],"parent":endpoint["parent"],
                  "gate_parameters":GATES}
    for label, items, task, binding, baseline in (
        ("photo",selected,partial(photo, model=model),source,prior),
        ("wire",assignments,partial(wire,model=model,plan=wire_plan,lookup={r["id"]:r for r in bank["rows"]},
                                    v120=v120),bind,prior_wire)
    ):
        t=time.monotonic()
        with ThreadPoolExecutor(3) as pool:
            rows=[]
            for row in pool.map(task,items):
                rows.append(row)
                if len(rows)%8==0:
                    print(stage,label,len(rows),round(time.monotonic()-t,1),flush=True)
        receipt=base_binding | {"inputs":binding,"replayed":baseline,"seconds":time.monotonic()-t,"rows":rows}
        check_scores(receipt,baseline,label)
        write_json(ROOT/f"{stage}-{label}.json",receipt)


if __name__=="__main__":
    main(sys.argv[1])
