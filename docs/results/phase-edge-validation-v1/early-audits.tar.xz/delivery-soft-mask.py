"""Measure added waveform in an exact-parent control with a strong edge and true gap."""
from concurrent.futures import ThreadPoolExecutor
import time

import numpy as np
from scipy.special import expit
import torch

from phase_edge import ROOT
from render_edge import render_models
from audit_edge import pack, PROFILES
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_quiet import load

BOX=[128,128,256,256]
CORE=np.s_[96:160,96:160]
PLANS=("flat-edge","outside-only","continuous")
COLUMNS=("Bayer-gated","activity","photo-affine","photo-edge","wire-affine","wire-edge")
SOURCES=24
Y,X=np.indices((512,512),dtype=np.float64)
LAYOUTS=list(PATTERNS.values())
PHI=((0,.125),(.09375,.125),(.15625,-.0625))
SECOND=((-0.125,0),(-.125,.09375),(.0625,.15625))


def field(i, label, model, policies):
    if label not in PROFILES:
        raise ValueError(label)
    rng=np.random.default_rng(810797+8*i)
    angle=(i%6)*np.pi/12 + [0.,.09][(i//6)%2]
    coord=(X-255.5)*np.cos(angle)+(Y-255.5)*np.sin(angle)
    bend=(i//12)*((Y-255.5)*np.cos(angle)-(X-255.5)*np.sin(angle))**2/920
    # Some scenes have a direct step. The others include an angled or curved rail.
    mean=.16+.00010*(X-255.5)-.00008*(Y-255.5)
    smooth=expit((coord-3.-bend)/.75)
    if i%3==2:
        smooth-=expit((coord-12.+bend)/.75)
    edge=mean+.073*smooth
    a,b = PHI[i%3]
    c,d = SECOND[i%3]
    pattern=.011*np.cos(2*np.pi*(a*Y+b*X)+rng.uniform(0,2*np.pi))
    pattern+=.0045*np.cos(2*np.pi*(c*Y+d*X)+rng.uniform(0,2*np.pi))
    mask=expit((np.maximum(abs(Y-255.5),abs(X-255.5))-42)/3.5)
    region=np.s_[128:384,128:384]
    prior=np.ascontiguousarray(np.broadcast_to(edge[region],(3,256,256)),dtype=np.float32)
    exact=pattern[region][CORE]
    noise=PROFILES[label]
    colors=np.asarray(LAYOUTS[i%4])
    wb=np.ones(3,dtype=np.float32)
    matrix=np.eye(3,dtype=np.float32)
    results={}
    for j,key in enumerate(PLANS):
        draw=np.random.default_rng(126481+1000*i+100*j+int(label[3:]))
        truth=edge if key=="flat-edge" else edge+pattern*mask if key=="outside-only" else edge+pattern
        clean=pack(truth)
        sensor_noise=np.sqrt(noise["shot"]*clean+noise["read"])
        raw=(np.rint((clean+sensor_noise*draw.standard_normal(clean.shape))*65535)/65535).astype(np.float32)
        center=np.ascontiguousarray(raw[:,64:192,64:192])
        outputs=render_models(center,colors,wb,matrix,noise,BOX,raw,prior,model,policies)
        expected=(truth-edge)[region][CORE]
        group={}
        for route,rgb in outputs.items():
            delta=rgb[1][CORE].astype(np.float64)-prior[1][CORE]
            group[route]={"absolute_error_DN16":float(np.sqrt(np.mean((delta-expected)**2))*65535),
                          "added_RMS_DN16":float(np.sqrt(np.mean(delta**2))*65535),
                          "weak_template_dot":float(np.sum(delta*exact)),
                          "weak_template_power":float(np.sum(exact**2)),
                          "within_one_DN16":float(np.mean(abs(delta)*65535<=1.))}
        results[key]=group
    return {"source":i,"noise":label,"layout":colors.tolist(),"family":"rail" if i%3==2 else "step",
            "results":results}


def main():
    torch.set_num_threads(1)
    choice=reference(ROOT/"selection.json")
    mounted=read_json(checked(choice))["policies"]
    policies={k:mounted[k]for k in COLUMNS}
    models, component, endpoint=load(raw_weights=False)
    start=time.monotonic()
    with ThreadPoolExecutor(3) as pool:
        futures=[pool.submit(field,i,label,models["witness-gated"],policies)
                 for label in PROFILES for i in range(SOURCES)]
        rows=[job.result()for job in futures]
    write_json(ROOT/"controlled-delivery.json",{
        "driver":reference(__file__),"selection":choice,"phase_component":endpoint["checkpoint"],
        "component_training":component,"cases_per_profile":SOURCES,"query":BOX,"core_in_query":[96,96,64,64],
        "noise":PROFILES,"seconds":time.monotonic()-start,"rows":rows,
        "scope":"Synthetic edge-only exact RGB delivery parent. 24 geometric fields at each prior, no-wave, outside-only and continuous observations with independent draws. The exact missing increment is for scoring only; the frozen correction sees Bayer and the parent."})
    print(len(rows),round(time.monotonic()-start,2),flush=True)
if __name__=="__main__":
    main()
