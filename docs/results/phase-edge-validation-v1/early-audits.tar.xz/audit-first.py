"""Check disjoint dependencies and measure sensitivity near competing edges."""
import time
from types import SimpleNamespace

import numpy as np
from scipy.special import expit
from scipy.stats import rankdata

from phase_edge import ROOT, CACHE, FOLDS, NATIVE, BAYER_OFFSETS, PHASES, N, HALF
from phase_edge import discovery, projected, scores
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
from demosaic.phase_witness import FREQ, SIDE, XI, YI, STEP, UNIQUE, measure_witnesses

CENTER=(SIDE//2)*SIDE+SIDE//2
POS=np.arange(16)
X0,Y0=2*XI[CENTER],2*YI[CENTER]
GREEN=np.array([0,1,1,2])
FREQ_INDEX=np.argmin(np.linalg.norm(FREQ[:,0]-[0,.125],axis=1))
FREQUENCY=FREQ[FREQ_INDEX,0]
PROFILES={"iso400":{"shot":8e-5,"read":2.56e-8},"iso6400":{"shot":.00128,"read":6.5536e-6}}


def pack(s):
    return np.stack([s[p//2::2,p%2::2] for p in range(4)],axis=0)


def area(a,b):
    ranks=rankdata(np.r_[a,b])
    return float((ranks[len(a):].sum()-len(b)*(len(b)+1)/2)/(len(a)*len(b)))


def fixture(phi):
    proof=SimpleNamespace(offsets=np.zeros((len(XI),PHASES.size),dtype=np.int64),
                          phase=np.ones((len(XI),PHASES.size),dtype=np.complex64))
    proof.phase[CENTER,FREQ_INDEX]=np.exp(1j*phi)
    return proof


def independent_check():
    rng=np.random.default_rng(12345)
    geometry=rng.normal(.15,.014,(4,128,128)).astype(np.float32)
    noise=PROFILES["iso6400"]
    free=measure_witnesses(geometry,GREEN,noise)
    _,original=scores(geometry,GREEN,noise,free,geometry=True)
    changed=geometry.copy()
    for plane in range(4):
        y,x=FOLDS[1]//16+Y0//2,FOLDS[1]%16+X0//2
        changed[plane,y,x]+=rng.normal(0,.035,len(x)).astype(np.float32)
    after=measure_witnesses(changed,GREEN,noise)
    np.testing.assert_array_equal(free.offsets[CENTER],after.offsets[CENTER])
    np.testing.assert_array_equal(free.phase[CENTER],after.phase[CENTER])
    _,updated=scores(changed,GREEN,noise,after,geometry=True)
    assert original[0,CENTER]==updated[0,CENTER]

    sample=rng.normal(.15,.2,(1,HALF)).astype(np.float32)
    p,fold,k=2,1,13
    bins=np.arange(0,len(UNIQUE),11)[None]
    phase=np.exp(1j*rng.uniform(0,5,bins.shape)).astype(np.complex64)
    a,b=projected(discovery(sample,p,fold,noise),fold,p,np.array([k]),bins,phase)
    theta=-2*np.pi*(NATIVE[FOLDS[fold]]+BAYER_OFFSETS[p]) @ (UNIQUE[bins[0]].T*STEP)
    wave=(np.exp(1j*theta)*phase).real
    kernels=CACHE[fold][p]
    for j,q in enumerate((kernels["affine"],np.vstack((kernels["affine"],kernels["edge"][k])))):
        residue=wave-q.T@(q@wave)
        np.testing.assert_allclose(a[j,0],sample@residue,rtol=0,atol=2e-5)
        np.testing.assert_allclose(b[j,0],(residue**2).sum(axis=0),rtol=0,atol=2e-5)
    return {"direct_projection_bins":int(bins.size),"withheld_raw_perturbation_preserves_center_nomination":True}


def main():
    seed=481452
    rng=np.random.default_rng(seed)
    start=time.monotonic()
    y,x=np.indices((256,256))
    local_phase=2*np.pi*((y-Y0)*FREQUENCY[0]+(x-X0)*FREQUENCY[1])
    outputs={}
    masks={}
    models=("affine","edge","predictive-affine","predictive-edge")
    tests=("flat","edge-only","edge+wave-.002","edge+wave-.006","edge+wave-.012")
    for iso,noise in PROFILES.items():
        statistics={k:[] for k in tests}
        coverage={k:[] for k in tests}
        actual={k:[] for k in ("flat","edge-only")}
        for i in range(64):
            cfa=np.asarray(list(PATTERNS.values())[i%4])
            # Some boundaries are exactly represented. Others fall between the
            # candidate angles or offsets, as in a photographed edge.
            angle=[0,np.pi/12, .14,.40][i%4]
            offset=[1, -3,2.1,-2.6][(i//4)%4]
            step=expit((np.cos(angle)*(x-127.5)+np.sin(angle)*(y-127.5)-offset)/.75)
            edge=.083*step
            center=np.s_[Y0:Y0+32,X0:X0+32]
            # A deliberately adverse guide takes the phase leaked by the
            # clean step. Actual exterior nomination is tested separately.
            phase=np.angle(np.sum(step[center]*np.exp(-1j*local_phase[center])))
            wave=np.cos(local_phase+phase)
            true=fixture(phase)
            tone=.14 + .00019*(x-127.5) - .00017*(y-127.5)
            for role in tests:
                plane=pack(tone if role=="flat" else tone+edge)
                if "+" in role:
                    plane+=float(role.split("-")[-1])*pack(wave)
                sigma=np.sqrt(plane*noise["shot"]+noise["read"])
                raw=(np.rint((plane+sigma*rng.standard_normal(plane.shape))*65535)/65535).astype(np.float32)
                z, geom=scores(raw,cfa,noise,true,geometry=True)
                statistics[role].append(z[:,CENTER,FREQ_INDEX])
                coverage[role].append((geom[:,CENTER]>=0).tolist())
                if role in actual:
                    discovered=measure_witnesses(raw,cfa,noise)
                    status=scores(raw,cfa,noise,discovered)[:,CENTER]
                    actual[role].append(status.max(axis=-1))
        outputs[iso]={}
        for n,mode in enumerate(models):
            base=np.asarray(statistics["edge-only"])[:,n]
            outputs[iso][mode]={role:{
                "median":float(np.median(np.asarray(val)[:,n])),
                "versus_edge_only_AUC":area(base,np.asarray(val)[:,n]),
                "fraction_above_quarter":float((np.asarray(val)[:,n]>.25).mean())
                }for role,val in statistics.items()}
            outputs[iso][mode]["automatic_center_any"]={
                role:{str(t):float((np.asarray(v)[:,n]>t).mean())for t in (.25,.55,1.)}
                for role,v in actual.items()}
        masks[iso]={k:float(np.mean(np.all(v,axis=1)))for k,v in coverage.items()}
        print(iso,masks[iso],flush=True)
    check=independent_check()
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"operator":reference(ROOT/"phase_edge.py"),
        "seed":seed,"draws_per_role":64,"seconds":time.monotonic()-start,
        "scope":"Four layouts, both independent Gaussian shot/read coefficients, 16-bit ADC. One native centered tile per scene. Supplied phase deliberately matches single-edge leakage. Actual exterior nomination tests any center-tile activation across all candidate bins.",
        "fold_checks":check,"detected_both_folds":masks,"results":outputs})


if __name__=="__main__":
    main()
