"""Use a wider Bayer context to nominate frequencies with a reserved local witness."""

from functools import cache
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
from scipy.fft import fft2
from scipy.ndimage import distance_transform_edt, gaussian_filter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("detail-phase-routing-v1")))
import phase_route as local

SIZE = 256
PACKED = SIZE // 2
FFT_SIZE = 256
ROBUST = (1, 2, 3, 4)


@cache
def geometry():
    native = np.arange(PACKED) * 2
    y, x = np.meshgrid(native, native, indexing="ij")
    quadrant = (y >= SIZE // 2) * 2 + (x >= SIZE // 2)
    donor = np.stack([quadrant != i for i in range(4)])
    fringe = distance_transform_edt(np.pad(donor[0], 1))[1:-1, 1:-1]
    # Distances must be measured from both the held quadrant and the crop boundary.
    width = [fringe, *(distance_transform_edt(np.pad(d, 1))[1:-1, 1:-1] for d in donor[1:])]
    spectral = np.minimum(np.asarray(width) / 10.0, 1.0) ** 2
    k = np.fft.fftfreq(FFT_SIZE) / 2
    fy, fx = np.meshgrid(k, k, indexing="ij")
    f = np.stack((fy, fx), axis=-1)
    r = np.hypot(fy, fx)
    band = (r >= local.MIN_FREQUENCY) & (r <= local.MAX_FREQUENCY)
    band &= (fy > 0) | ((fy == 0) & (fx > 0))
    return donor, spectral, np.stack((y, x), axis=-1), f, band


def signals(d, profile):
    donor, taper, _, _, _ = geometry()
    phases = np.flatnonzero(d["colors"] == 1)
    raw = d["packed"][:, phases].astype(np.float64)
    assert raw.shape[-2:] == (PACKED, PACKED) and len(phases) == 2
    mask = donor[None, :, None] & ((raw > 0.001) & (raw < 0.995))[:, None]
    weight = taper[None, :, None] * mask
    raw = np.broadcast_to(raw[:, None], weight.shape)
    scale = (0, 0, 0, 5, 5)
    # Every numerator and denominator excludes all samples inside the recipient.
    # Restraining the fit to low frequencies limits contamination from slow shading.
    observed = np.where(mask, raw, 0)
    smooth = gaussian_filter(observed, scale) / np.maximum(gaussian_filter(mask.astype(float), scale), 1e-10)
    base = np.where(mask, raw - smooth, 0)
    mean = (weight * observed).sum((-1, -2)) / np.maximum(weight.sum((-1, -2)), 1)
    noise = np.maximum(2e-10, profile["shot"] * mean + profile["read"])
    return base, weight, noise, np.asarray([divmod(int(p), 2) for p in phases])


def spectrum(base, weight, noise, offsets):
    _, _, _, f, _ = geometry()
    z = fft2(base * weight, s=(FFT_SIZE, FFT_SIZE), axes=(-2, -1))
    adjust = np.exp(-2j * np.pi * np.einsum("xyc,pc->pxy", f, offsets))
    norm = np.sqrt(np.maximum(1e-10, (weight**2).sum((-1, -2)) * noise))
    z = z * adjust / norm[..., None, None]
    return (z[:, :, 0] * z[:, :, 1].conj()).real


def peak(power, allowed, *, prominence=False):
    _, _, _, f, _ = geometry()
    score = np.maximum(power, 0)
    if prominence:
        floor = gaussian_filter(score, (0, 0, 4, 4), mode="wrap")
        score = score / np.sqrt(1 + floor)
    idx = np.argmax(np.where(allowed, score, -np.inf).reshape(*power.shape[:2], -1), axis=-1)
    return f.reshape(-1, 2)[idx], np.take_along_axis(power.reshape(*power.shape[:2], -1),
                                                  idx[..., None], axis=-1)[..., 0]


def remove(base, weight, frequency, harmonics):
    _, _, coords, _, _ = geometry()
    # A per-green sin/cos fit spans the same subspace at its translated phase.
    phase = 2 * np.pi * np.einsum("...c,xyc->...xy", frequency, coords)
    phase = phase[..., None] * np.asarray(harmonics)
    shape = (*phase.shape[:-1], 2 * len(harmonics))
    harmonic = np.stack((np.cos(phase), np.sin(phase)), axis=-1).reshape(shape)
    X = harmonic.reshape(*base.shape[:2], 1, PACKED**2, -1)
    w = weight.reshape(*base.shape[:3], PACKED**2)
    transpose = np.swapaxes(X * w[..., None], -1, -2)
    g = transpose @ X + np.eye(X.shape[-1]) * 1e-6
    sol = np.linalg.solve(g, transpose @ base.reshape(*w.shape, 1))
    return base - (X @ sol).reshape(base.shape)


def separation(strong, robust=False):
    _, _, _, f, band = geometry()
    t = strong[..., None, None, :]
    d = np.minimum(np.linalg.norm(f - t, axis=-1), np.linalg.norm(f + t, axis=-1))
    keep = band & (d >= local.FREQUENCY_SEPARATION)
    if robust:
        # The second crossing must be angularly distinct from the first.
        cos = np.abs(np.sum(t * f, axis=-1)) / np.maximum(
            1e-10, np.linalg.norm(t, axis=-1) * np.linalg.norm(f, axis=-1)
        )
        keep &= cos <= np.cos(np.deg2rad(24))
    return keep


def nominate(d, profile):
    base, weight, noise, offsets = signals(d, profile)
    _, _, _, _, band = geometry()
    p = spectrum(base, weight, noise, offsets)
    strong, first = peak(p, band)
    clean = remove(base, weight, strong, (1,))
    weak, second = peak(spectrum(clean, weight, noise, offsets), separation(strong))
    peak_strong, peak_first = peak(p, band, prominence=True)
    clean = remove(base, weight, peak_strong, ROBUST)
    peak_weak, peak_second = peak(spectrum(clean, weight, noise, offsets),
                                 separation(peak_strong, robust=True), prominence=True)
    return {
        "wide": ((strong, first), (weak, second)),
        "harmonic": ((peak_strong, peak_first), (peak_weak, peak_second)),
    }


def inject(nomination):
    def discover(sensors, residual, excluded):
        n, ny, nx = sensors[0]["shape"]
        iy, ix = np.meshgrid(np.arange(ny), np.arange(nx), indexing="ij")
        q = (iy >= ny // 2) * 2 + (ix >= nx // 2)
        v, s = nomination[int(excluded.shape[1] > 0)]
        assert len(v) == n
        return v[:, q].reshape(-1, 2), s[:, q].reshape(-1)
    return discover


def fields(d, pred, profile):
    candidates = nominate(d, profile)
    output, details = {}, {}
    for name, nomination in candidates.items():
        # Keep the prior local phase fitting, the separate central witness,
        # the deficit cap and delivery unchanged.
        with patch.object(local, "discover", inject(nomination)):
            moves, neutral, info = local.fields(d, pred, profile)
        output[name] = moves["directional"]
        if name == "harmonic":
            output["rolled directional"] = moves["rolled directional"]
            output["wide exterior"] = moves["exterior"]
        details[name] = info
    return output, neutral, details
