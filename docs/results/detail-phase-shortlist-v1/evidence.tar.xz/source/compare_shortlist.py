"""Compare the gap check against the exact same shortlisted frequencies at matched recovery."""

from pathlib import Path
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_shortlist import OUT, METHODS, scoring

METRICS = (
    "weak_response_pp", "intact_increment_RMS_DN16", "gap_continuing_strong_RMS_DN16",
    "gap_weak_RMS_DN16", "gap_RMS_DN16", "exterior_only_weak_RMS_DN16", "exact_flat_RMS_DN16",
)
GROUPS = ("calibration", "prior-held", "held")


def evaluate(data):
    rows = [r for r in data["rows"] if r["kind"] == "wire"]
    lock = {k: v["locked"]["dose"] for k, v in data["policy"]["arms"].items()}
    value = lambda k,m,d: scoring.wire_values(rows, k, m, d)
    gain = lambda k,d: float((value(k,METRICS[0],d) - value("nominal",METRICS[0],0)).mean())
    a,b = METHODS
    full = {k: gain(k,1) for k in METHODS}
    target = min(full.values())
    level = {k: target / v for k,v in full.items()} if target > 0 else {}
    control = gain("rank one",0)
    rng = np.random.default_rng(202611201143)
    effects = {}
    for met in METRICS:
        this = value(b,met,lock[b])
        cmp = {
            "checked minus unchecked at locks": (this, value(a,met,lock[a])),
            "checked minus shifted check": (this, value("rolled directional",met,lock[b])),
            "checked minus rank one at locks": (this,value("rank one",met,0)),
        }
        if level:
            cmp["checked minus unchecked at equal response"] = (value(b,met,level[b]),value(a,met,level[a]))
        if 0 < control < full[b]:
            cmp["checked minus rank one at equal response"] = (
                value(b,met,control/full[b]), value("rank one",met,0)
            )
        effects[met] = {}
        for k,(u,v) in cmp.items():
            diff = u-v
            sample = rng.integers(len(diff), size=(12000,len(diff)))
            effects[met][k] = [float(diff.mean()), *np.quantile(diff[sample].mean(1), [0.025,0.975]).tolist()]
    return {
        "full_gains": full, "common_gain": target, "common_doses": level,
        "locked_gains": {k: gain(k,lock[k]) for k in METHODS} | {"rank one": control},
        "effects": effects,
    }


if __name__ == "__main__":
    proofs = {k: reference(OUT / f"score-{k}.json") for k in GROUPS}
    with patch.object(scoring, "METHODS", METHODS):
        results = {k:evaluate(read_json(checked(f))) for k,f in proofs.items()}
    print(results["held"], flush=True)
    write_json(OUT / "comparisons.json", {
        "driver": reference(Path(__file__)), "inputs": proofs, "results": results,
        "scope": "Calibration-fixed strengths and a retrospective equal-response comparison.",
    })
