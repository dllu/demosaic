"""Estimate one missing carrier from exterior Bayer phase with a separate local witness."""

from functools import cache

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.fft import fft2
from scipy.ndimage import gaussian_filter

NATIVE = 64
PACKED = NATIVE // 2
STRIDE = 16
PAD = 8
FFT_SIZE = 64
HALF_WIDTH = 16
MIN_FREQUENCY = 0.040
MAX_FREQUENCY = 0.210
FREQUENCY_SEPARATION = 0.032
CAP = 32 / 65535


@cache
def grid(oy, ox):
    pos = np.arange(PACKED) * 2 - (NATIVE - 1) / 2
    y, x = np.meshgrid(pos + oy, pos + ox, indexing="ij")
    coord = np.stack((y.ravel(), x.ravel()), axis=-1)
    cy, cx = (coord / 32).T
    smooth = np.stack((np.ones_like(cx), cx, cy, cx * cy, cx**2, cy**2), axis=-1)
    inner = np.maximum(np.abs(y), np.abs(x)) < HALF_WIDTH
    outer = np.square(np.cos(np.pi * x / NATIVE) * np.cos(np.pi * y / NATIVE)) * ~inner
    central = np.square(np.cos(np.pi * x / (2 * HALF_WIDTH)) *
                        np.cos(np.pi * y / (2 * HALF_WIDTH))) * inner
    return coord, smooth, outer.ravel(), central.ravel()


@cache
def spectrum_grid():
    k = np.fft.fftfreq(FFT_SIZE) / 2
    y, x = np.meshgrid(k, k, indexing="ij")
    r = np.hypot(y, x)
    mask = (r >= MIN_FREQUENCY) & (r <= MAX_FREQUENCY)
    mask &= (y > 0) | ((y == 0) & (x > 0))
    coords = np.stack((y.ravel(), x.ravel()), axis=-1)
    return coords, mask.ravel()


def windows(data):
    padded = np.pad(data, ((0, 0), (PAD, PAD), (PAD, PAD)))
    return sliding_window_view(padded, (PACKED, PACKED), axis=(-2, -1))[:, ::STRIDE, ::STRIDE]


def observations(raw, anchor, profile, phase):
    y, x = divmod(int(phase), 2)
    samples = windows(raw[:, phase])
    shape = samples.shape[:3]
    observed = samples.reshape(-1, PACKED**2).astype(np.float64)
    base = windows(anchor[:, y::2, x::2]).reshape(observed.shape)
    places, nuisance, outside, center = grid(y, x)
    valid = (observed > 0.001) & (observed < 0.995)
    exterior = valid * outside
    receiver = valid * center
    noise = profile["shot"] * np.clip((exterior * observed).sum(-1) /
                                     np.maximum(exterior.sum(-1), 1e-10), 0, 1) + profile["read"]
    return {
        "observed": observed, "base": base, "coord": places, "nuisance": nuisance,
        "exterior": exterior, "central": receiver, "noise": np.maximum(noise, 2e-10),
        "shape": shape, "offset": (y, x),
    }


def design(sensor, frequencies):
    raw = sensor["observed"]
    p = np.broadcast_to(sensor["nuisance"], (*raw.shape, 6))
    if frequencies.shape[1] == 0:
        return p
    phase = 2 * np.pi * np.einsum("sfc,pc->spf", frequencies, sensor["coord"])
    wave = np.stack((np.cos(phase), np.sin(phase)), axis=-1).reshape(*raw.shape, -1)
    return np.concatenate((p, wave), axis=-1)


def regress(sensor, frequencies, area, *, inspect=False):
    a = design(sensor, frequencies)
    w = sensor[area]
    weighted = a * w[..., None]
    transposed = np.swapaxes(weighted, -2, -1)
    G = transposed @ a + np.eye(a.shape[-1]) * 1e-5
    data = sensor["observed"]
    if inspect:
        stacked = np.stack((data, sensor["base"]), axis=-1)
        fit = np.linalg.solve(G, transposed @ stacked)
        # Variance of a tapered least-squares estimate with per-phase noise.
        inverse = np.linalg.solve(G, np.broadcast_to(np.eye(G.shape[-1]), G.shape))
        basis = weighted @ inverse[..., -2:]
        covariance = np.swapaxes(basis, -2, -1) @ basis
        covariance *= sensor["noise"][:, None, None]
        return fit, covariance
    fit = np.linalg.solve(G, transposed @ data[..., None])[..., 0]
    residual = data - (a @ fit[..., None])[..., 0]
    return fit, residual


def discover(sensors, residual, excluded):
    coeff = []
    freq, band = spectrum_grid()
    for sensor, r in zip(sensors, residual, strict=True):
        w = sensor["exterior"]
        field = (r * w).reshape(-1, PACKED, PACKED)
        spectrum = fft2(field, s=(FFT_SIZE, FFT_SIZE)).reshape(len(field), -1)
        offset = np.asarray(sensor["offset"])
        phase = np.exp(-2j * np.pi * (freq @ offset))
        floor = np.sqrt(np.maximum(1e-10, (w**2).sum(-1) * sensor["noise"]))
        coeff.append(spectrum * phase / floor[:, None])
    cross = (coeff[0] * coeff[1].conj()).real
    scope = np.broadcast_to(band, cross.shape)
    if excluded.shape[1]:
        first = excluded[:, :1, :]
        separation = np.minimum(
            np.linalg.norm(freq[None] - first, axis=-1),
            np.linalg.norm(freq[None] + first, axis=-1),
        )
        scope = scope & (separation >= FREQUENCY_SEPARATION)
    choice = np.argmax(np.where(scope, cross, -np.inf), axis=-1)
    return freq[choice], cross[np.arange(len(choice)), choice]


def inspect(sensors):
    zeros = np.zeros((len(sensors[0]["observed"]), 0, 2))
    plain = [regress(s, zeros, "exterior")[1] for s in sensors]
    strong, support_strong = discover(sensors, plain, zeros)
    residual = [regress(s, strong[:, None], "exterior")[1] for s in sensors]
    weak, support_weak = discover(sensors, residual, strong[:, None])
    both = np.stack((strong, weak), axis=1)
    outer = np.stack([regress(s, both, "exterior")[0][..., -2:] for s in sensors])
    common = outer.mean(axis=0)
    amplitude = np.hypot(*common.T)
    direction = common / np.maximum(amplitude[:, None], 1e-10)
    outer_aligned = (outer * direction).sum(-1)
    outer_ok = (support_strong >= 4.0) & (support_weak >= 3.5) & (outer_aligned.min(axis=0) > 0)
    fitted = [regress(s, both, "central", inspect=True) for s in sensors]
    center = np.stack([(b[..., -2:, 0] * direction).sum(-1) for b, _ in fitted])
    uncertainty = np.stack([
        np.sqrt(np.maximum(1e-12, np.einsum("si,sij,sj->s", direction, v, direction)))
        for _, v in fitted
    ])
    nominal = np.stack([(b[..., -2:, 1] * direction).sum(-1) for b, _ in fitted]).mean(axis=0)
    z = (center / uncertainty).min(axis=0)
    strength = np.maximum(z - 0.35, 0.0)
    agreement = strength / (strength + 1.0)
    # The transported amplitude proposes the missing amount. The independently
    # observed center values are used only as the bounded phase witness.
    return weak, direction, np.maximum(amplitude - nominal, 0) * outer_ok, agreement, outer_ok, z


@cache
def delivery():
    pos = np.arange(NATIVE) - (NATIVE - 1) / 2
    y, x = np.meshgrid(pos, pos, indexing="ij")
    window = np.outer(np.maximum(1 - np.abs(pos) / 24, 0),
                      np.maximum(1 - np.abs(pos) / 24, 0))
    return y, x, window


def fields(d, p, profile):
    raw = d["packed"]
    green = p["nominal"][:, 1]
    sensors = [observations(raw, green, profile, phase) for phase in np.flatnonzero(d["colors"] == 1)]
    assert len(sensors) == 2
    f, direction, strength, local, active, witness = inspect(sensors)
    neutral = np.linalg.solve(d["matrix"].astype(float), np.ones(3)) / d["wb"]
    scale = max(abs(float(neutral[1])), 1e-10)
    strength = np.minimum(strength / scale, CAP)
    n, ny, nx = sensors[0]["shape"]
    y, x, w = delivery()
    phase = 2 * np.pi * (f[:, 0, None, None] * y + f[:, 1, None, None] * x)
    projected = (direction[:, 0, None, None] * np.cos(phase) +
                 direction[:, 1, None, None] * np.sin(phase))
    projected *= strength[:, None, None]
    projected = projected.reshape(n, ny, nx, NATIVE, NATIVE)
    accepted = local.reshape(n, ny, nx)
    weight = np.zeros((2 * raw.shape[-2] + 2 * STRIDE, 2 * raw.shape[-1] + 2 * STRIDE))
    frame = np.zeros((3, n, *weight.shape))
    moved = np.roll(accepted, (2, 2), axis=(-2, -1))
    blend = np.stack((np.ones_like(accepted), accepted, moved))
    for i in range(ny):
        for j in range(nx):
            a = np.s_[i * 2 * STRIDE:i * 2 * STRIDE + NATIVE,
                      j * 2 * STRIDE:j * 2 * STRIDE + NATIVE]
            weight[a] += w
            frame[..., a[0], a[1]] += (blend[:, :, i, j, None, None] * projected[:, i, j] * w)
    area = np.s_[..., STRIDE:-STRIDE, STRIDE:-STRIDE]
    result = (frame / np.maximum(weight, 1e-10))[area]
    valid = np.all((raw > 0.001) & (raw < 0.995), axis=1)
    safe = gaussian_filter(valid.repeat(2, -2).repeat(2, -1).astype(float), (0, 2, 2))
    names = ("exterior", "directional", "rolled directional")
    additions = dict(zip(names, result * safe[None], strict=True))
    return additions, neutral, {"active": active.reshape(n, ny, nx), "phase": f.reshape(n, ny, nx, 2),
                                "witness": witness.reshape(n, ny, nx), "local": accepted}
