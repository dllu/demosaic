"""Render the completed learned gates and both standing RAW families at native scale."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT
from score_wire_gate import DISPLAY, METHODS, OLD_DIR, load_models, loads, prepare, wire_values
from evaluate_direct import Cases
from evaluate_selector import values
from review_selector import board, crop, image, named_pixels

ROI = (48, 48, 160, 160)
ORDER = ("nominal", "router", "parent phase", *METHODS)
REF = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")


def render(row, raw, p, net, dose):
    known, change = prepare(row, raw, p, net)
    body = known["nominal"]
    return known | {
        k: (body + float(dose.get(k, 0)) * v).astype(body.dtype) for k, v in change.items()
    }


def standing(net, dose, root):
    previous = reference(OLD_DIR / "review-camera.json")
    history = {r["id"]: r for r in read_json(checked(previous))["report"]["rows"]}
    output = []
    for row, d, p, origin in Cases("camera"):
        old = history[row["id"]]
        assert row["input"] == old["input"] and row["global_ROI"] == old["roi"]
        r = render(row, d, p, net, dose)
        xy = row["local_ROI"]
        native = []
        for draw in old["views"]:
            k = draw["exposure"]
            data = named_pixels(draw)

            def view(a):
                return image(crop(a[0], xy), d["wb"], d["matrix"], k)

            np.testing.assert_array_equal(view(r["nominal"]), data[DISPLAY["nominal"]])
            np.testing.assert_array_equal(view(r["router"]), data[DISPLAY["router"]])
            np.testing.assert_array_equal(view(r["parent phase"]), data[DISPLAY["parent phase"]])
            forms = [
                (a, data[a]) for a in ("Noisy (Malvar)", "V120 EMA", "Earlier whole-photo gate")
            ]
            forms += [(DISPLAY[a], view(r[a])) for a in ORDER]
            forms += [(a, data[a]) for a in REF if a in data]
            path = root / f"{row['id']}-x{k:g}.png"
            native.append(board(forms, path) | {"exposure": k, "historical_reference": draw})
        differences = {}
        for k in ORDER:
            differences[k] = {}
            for ref_ in ("nominal", "router"):
                difference = crop(r[k], xy).astype(float) - crop(r[ref_], xy)
                differences[k][ref_] = float(np.sqrt(np.mean(difference**2)) * 65535)
        output.append(
            {
                "id": row["id"],
                "RAW": row["raw"],
                "source": origin,
                "input": row["input"],
                "ROI": row["global_ROI"],
                "noise": row["noise"],
                "views": native,
                "RGB_RMS_DN16": differences,
            }
        )
    assert len(output) == 8 and sum(len(r["views"]) for r in output) == 12
    return {"reference": previous, "rows": output}


def choose(rows, dose):
    primary = "directional"
    m = "intact_increment_RMS_DN16"
    wires = [r for r in rows if r["kind"] == "wire"]
    change = wire_values(wires, primary, m, dose[primary]) - wire_values(wires, "nominal", m, 0)
    indices = (
        (0, len(wires) - 1)
        if np.ptp(change) < 1e-8
        else (int(change.argmin()), int(change.argmax()))
    )
    chosen = {
        wires[k]["id"]: (role, float(change[k]))
        for k, role in zip(
            indices,
            ("lowest intact paired error change", "highest intact paired error change"),
            strict=True,
        )
    }
    earlier = [r for r in rows if r["kind"] == "faint"]
    old = values(earlier, "nominal", (0, 0))["increment"]
    new = values(earlier, primary, (dose[primary], 0))["increment"]
    i = int((new - old).argmin())
    return chosen | {
        earlier[i]["id"]: (
            "lowest fine paired error change on faint photos",
            float(new[i] - old[i]),
        )
    }


def exact(nets, dose, root):
    result = reference(OUT / "score-held.json")
    proof = read_json(checked(result))
    selected = choose(proof["rows"], dose)
    referred = []
    for row, d, p, link in loads(proof["source"]):
        if row["id"] not in selected:
            continue
        model = render(row, d, p, nets, dose)
        shot = row["profile"]
        exp = 2.0 if row["kind"] == "wire" else 1 / shot["exposure"]
        obs = {"packed": d["packed"]} | {
            n: np.broadcast_to(d[n], (4, *d[n].shape)).copy() for n in ("colors", "wb", "matrix")
        }
        full = model | {"noisy": noisy_malvar(obs), "target": d["target"]}
        roles = {"present": 0, "flat": 3, "absent": 2}
        v = {}
        for k, i in roles.items():

            def thumb(a):
                return image(crop(a[i], ROI), d["wb"], d["matrix"], exp)

            labels = DISPLAY | {"noisy": "Noisy Malvar", "target": "Exact synthetic GT"}
            samples = {a: thumb(full[a]) for a in ("noisy", "v120", *ORDER, "target")}
            v[k] = board(
                [(labels[a], b) for a, b in samples.items()], root / f"{row['id']}-{k}.png"
            )
            if i == 0:
                exact_points = ("noisy", "directional", "target")
                v["triplet"] = board(
                    [(labels[a], samples[a]) for a in exact_points],
                    root / f"{row['id']}-triplet.png",
                )
        referred.append(
            {
                "id": row["id"],
                "fixture": row["fixture"],
                "noise": shot,
                "kind": row["kind"],
                "query_offset": row["offset"],
                "provenance": link,
                "ROI": ROI,
                "display_exposure": exp,
                "selection": selected[row["id"]],
                "views": v,
            }
        )
        print(row["id"], selected[row["id"]], flush=True)
    assert len(referred) == 3
    return {"reference": result, "rows": referred}


def run():
    torch.set_num_threads(2)
    fit, p = load_models()
    locked = reference(OUT / "score-calibration.json")
    cfg = read_json(checked(locked))
    dose = {k: v["locked"]["dose"] for k, v in cfg["policy"]["arms"].items()}
    assert cfg["weights"] == fit
    start = monotonic()
    for k, use in (("camera", standing), ("exact", exact)):
        folder = OUT / "native" / k
        folder.mkdir(exist_ok=True, parents=True)
        frame = use(p, dose, folder)
        write_json(
            OUT / f"review-{k}.json",
            {
                "driver": reference(Path(__file__)),
                "fit": fit,
                "lock": locked,
                "doses": dose,
                "ancestor": p["router"],
                "deficit": p["parent_phase"],
                "report": frame,
                "elapsed": monotonic() - start,
            },
        )


if __name__ == "__main__":
    run()
