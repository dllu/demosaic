"""Score complementary donor folds with the earlier phase variants as fixed controls."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import crossfit_phase as operator
import evaluate_wide as previous
import score_wire_gate as scoring
import review_wire_gate as review

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
OLDER = previous.OUT
METHODS = ("split", "directional", "donor only")
LABELS = previous.LABELS | {
    "split": "Unchecked donor folds",
    "directional": "Validated donor folds",
    "donor only": "Validated without local check",
    "old wide": "Earlier plain wide",
    "old harmonic": "Earlier harmonic wide",
}
ORDER = ("nominal", "router", "parent phase", "old wide", "old harmonic", *METHODS)


def models():
    _, nets = previous.models()
    bound = reference(OLDER / "score-calibration.json")
    config = read_json(checked(bound))
    nets["wide_doses"] = {k: v["locked"]["dose"] for k, v in config["policy"]["arms"].items()}
    return reference(OUT / "plan.json"), nets


def prepare(row, d, p, nets):
    known, old = previous.prepare(row, d, p, nets)
    nominal = known["nominal"]
    for k, label in (("wide", "old wide"), ("directional", "old harmonic")):
        known[label] = (nominal + nets["wide_doses"][k] * old[k]).astype(nominal.dtype)
    moves, neutral, _ = operator.fields(d, p, row["profile"])
    return known, {k: v[:, None] * neutral[None, :, None, None] for k, v in moves.items()}


def stage():
    limits = scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": previous.previous.prior.CONTINUING_LIMIT}
    official = {
        "calibration": OLDER / "calibration",
        "prior-held": OLDER / "held",
        "held": OUT / "confirmation/held",
    }
    for name, dataset in official.items():
        alias = OUT / name
        if not alias.exists() and not alias.is_symlink():
            alias.symlink_to(dataset, target_is_directory=True)
        assert alias.resolve() == dataset.resolve()
    marker = OUT / "plan.json"
    if not marker.exists():
        write_json(marker, {
            "driver": reference(Path(__file__)), "operator": reference(Path(operator.__file__)),
            "previous_operator": reference(Path(operator.wide.__file__)),
            "local_operator": reference(Path(operator.local.__file__)),
            "capture_selection": reference(OUT / "confirmation/plan.json"),
            "previous_plan": reference(OLDER / "plan.json"),
            "previous_calibration": reference(OLDER / "score-calibration.json"),
            "calibration": reference(official["calibration"] / "completed.json"),
            "replay": reference(official["prior-held"] / "completed.json"),
            "inherited_scorer": reference(Path(scoring.__file__)),
            "inherited_reviewer": reference(Path(review.__file__)),
            "fold_seed": operator.FOLD_SEED, "threshold_sd": operator.WITNESS,
            "methods": METHODS, "limits": limits,
            "scope": "Same calibration of strengths. Each broad donor hypothesis is validated using complementary Bayer blocks. The 56-source held panel is fixed before scoring.",
        })
    return limits


def run(mode):
    limits = stage()
    with ExitStack() as stack:
        for obj, name, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepare),
            (scoring, "WIRE_LIMITS", limits),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepare),
            (review, "ORDER", ORDER),
            (review, "DISPLAY", review.DISPLAY | LABELS),
        ):
            stack.enter_context(patch.object(obj, name, value))
        if mode == "review":
            review.run()
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
