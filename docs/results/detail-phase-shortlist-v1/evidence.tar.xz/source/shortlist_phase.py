"""Validate multiple wide frequencies and constrain delivery by local continuation."""

from functools import cache
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("detail-crossfit-phase-v1")))
import crossfit_phase as old

wide = old.wide
local = old.local
SIZE = old.SIZE
PACKED = old.PACKED
COUNT = 3
MIN_DISTANCE = 0.016
MIN_WITNESS = 1.55


def ranked(split):
    base, weight, noise, offsets, _, _ = split
    _, _, _, coordinate, band = wide.geometry()
    source = wide.spectrum(base, weight, noise, offsets)
    main, primary = wide.peak(source, band, prominence=True)
    rest = wide.remove(base, weight, main, wide.ROBUST)
    power = wide.spectrum(rest, weight, noise, offsets)
    support = wide.separation(main, robust=True)
    peaks, votes = [], []
    for _ in range(COUNT):
        f, s = wide.peak(power, support, prominence=True)
        rotate = f[..., None, None, :]
        spacing = np.minimum(np.linalg.norm(coordinate - rotate, axis=-1),
                             np.linalg.norm(coordinate + rotate, axis=-1))
        support &= spacing >= MIN_DISTANCE
        peaks.append(f)
        votes.append(s)
    return main, primary, np.stack(peaks, -2), np.stack(votes, -1)


def wave_design(main, weak):
    _, _, xy, _, _ = wide.geometry()
    f = np.concatenate((main[..., None, :] * np.asarray(wide.ROBUST)[:, None], weak), axis=-2)
    theta = 2 * np.pi * np.einsum("nqfc,yxc->nqyxf", f, xy)
    full = np.stack((np.cos(theta), np.sin(theta)), axis=-1)
    return full.reshape(*full.shape[:2], 1, PACKED**2, 2 * f.shape[-2])


def coefficients(x, split):
    data, weight, *_ = split
    w = weight.reshape(*weight.shape[:-2], PACKED**2)
    weighted = x * w[..., None]
    transpose = np.swapaxes(weighted, -1, -2)
    gram = transpose @ x + np.eye(x.shape[-1]) * 1e-5
    fit = np.linalg.solve(gram, transpose @ data.reshape(*w.shape, 1))[..., 0]
    return fit, gram, weighted


def verify(training, withheld, main, weak):
    x = wave_design(main, weak)
    angles = 2 * np.pi * np.einsum("nqkc,pc->nqpk", weak, training[3])
    a, b = np.cos(angles), np.sin(angles)
    rotation = np.stack((a, b, -b, a), axis=-1).reshape(*angles.shape, 2, 2)
    f, _, _ = coefficients(x, training)
    q = f[..., -2 * COUNT:].reshape(*angles.shape, 2)
    alignment = (q[..., None, :] @ rotation)[..., 0, :].mean(axis=2)
    alignment /= np.maximum(np.linalg.norm(alignment, axis=-1, keepdims=True), 1e-12)
    axis = (rotation @ alignment[:, :, None, :, :, None])[..., 0]
    g, gram, weighted = coefficients(x, withheld)
    signed = np.sum(g[..., -2 * COUNT:].reshape(*angles.shape, 2) * axis, -1)
    dimension = gram.shape[-1]
    vectors = np.zeros((*gram.shape[:-2], dimension, COUNT))
    for i in range(COUNT):
        pos = dimension - 2 * COUNT + 2 * i
        vectors[..., pos:pos + 2, i] = axis[..., i, :]
    influence = (weighted @ np.linalg.solve(gram, vectors)).reshape(
        *angles.shape[:-1], PACKED, PACKED, COUNT
    )
    _, _, variance, _, mask, normal = withheld
    adjoint = mask[..., None] * gaussian_filter(influence / normal[..., None], (*old.SIGMA, 0))
    se = np.sqrt(np.maximum(1e-12, variance[..., None] * ((influence - adjoint)**2).sum((-3, -2))))
    witness = (signed / se).min(axis=2)
    excess = np.maximum(witness - MIN_WITNESS, 0)
    return excess / (1 + excess), witness


def station(sensors, selected, broad):
    """Use the inherited local fit and measure support for the exterior amplitude."""
    primary, secondary = selected
    strong, available = wide.inject((primary, secondary))(sensors, None, np.empty((0, 0)))
    weak, vote = wide.inject((primary, secondary))(sensors, None, np.empty((0, 1)))
    all_f = np.stack((strong, weak), axis=1)
    outer = np.stack([local.regress(s, all_f, "exterior")[0][..., -2:] for s in sensors])
    common = outer.mean(axis=0)
    amplitude = np.linalg.norm(common, axis=-1)
    direction = common / np.maximum(amplitude[:, None], 1e-10)
    active = (available >= 4) & (vote >= 3.5) & ((outer * direction).sum(-1).min(axis=0) > 0)
    fitted = [local.regress(s, all_f, "central", inspect=True) for s in sensors]
    center = np.stack([(r[..., -2:, 0] * direction).sum(-1) for r, _ in fitted])
    nominal = np.stack([(r[..., -2:, 1] * direction).sum(-1) for r, _ in fitted]).mean(0)
    noise = np.stack([np.sqrt(np.maximum(1e-12, np.einsum("si,sij,sj->s", direction, v, direction)))
                      for _, v in fitted])
    signal = center / noise
    positive = np.maximum(signal.min(axis=0) - .35, 0)
    check = positive / (1.0 + positive)
    # Compare evidence for absence and for an attenuated continuation through
    # the center. Limit the reference amplitude in SD units for robustness.
    expected = np.minimum(.75 * amplitude[None] / noise, 6)
    odds = (expected * (signal - .5 * expected)).sum(axis=0)
    continuation = np.clip(.5 + .25 * odds, 0, 1)
    amount = np.maximum(amplitude - nominal, 0) * active * broad
    return weak, direction, amount, check, continuation, active & (broad > 0)


@cache
def offset_window(di, dj):
    _, _, taper = local.delivery()
    height, width = taper.shape
    dy, dx = 2 * local.STRIDE * di, 2 * local.STRIDE * dj
    y0, x0 = max(dy, 0), max(dx, 0)
    y1, x1 = min(height + dy, height), min(width + dx, width)
    window = np.zeros_like(taper)
    window[y0:y1, x0:x1] = taper[y0-dy:y1-dy, x0-dx:x1-dx]
    return window


def receiving_gate(frequency, available, guards, i, j):
    # Interpolate only matching frequencies at receiving stations. A gap
    # station can constrain overlap even if its own center would deliver zero.
    weighted = np.zeros((len(guards), *frequency.shape[:2], local.NATIVE, local.NATIVE))
    coverage = np.zeros_like(weighted[0])
    current = frequency[:, :, i, j]
    default = guards[:, :, :, i, j, None, None]
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            iy, ix = i + di, j + dj
            if not (0 <= iy < frequency.shape[2] and 0 <= ix < frequency.shape[3]):
                continue
            other = frequency[:, :, iy, ix]
            distances = np.minimum(
                np.linalg.norm(current[:, None] - other[None], axis=-1),
                np.linalg.norm(current[:, None] + other[None], axis=-1),
            )
            distances = np.where(available[None, :, :, iy, ix], distances, np.inf)
            nearest = distances.argmin(axis=1)
            supported = distances.min(axis=1) <= MIN_DISTANCE
            value = guards[:, :, :, iy, ix][:, nearest, np.arange(frequency.shape[1])]
            tap = supported[..., None, None] * offset_window(di, dj)
            weighted += tap[None] * value[..., None, None]
            coverage += tap
    mapped = np.where(coverage[None] > 1e-10, weighted / np.maximum(coverage, 1e-10), default)
    return np.minimum(default, mapped)


def deliver(fields, raw, neutral, shape):
    n, h, w = shape
    y, x, taper = local.delivery()
    s = max(abs(float(neutral[1])), 1e-10)
    amount = np.stack([np.minimum(pack[2] / s, local.CAP) * pack[3] for pack in fields])
    amount *= local.CAP / np.maximum(local.CAP, amount.sum(axis=0))
    phases = np.stack([pack[0] for pack in fields])
    direction = np.stack([pack[1] for pack in fields])
    arg = 2 * np.pi * (phases[..., 0, None, None] * y + phases[..., 1, None, None] * x)
    carrier = direction[..., 0, None, None] * np.cos(arg) + direction[..., 1, None, None] * np.sin(arg)
    field = carrier * amount[..., None, None]
    guard = np.stack([pack[4] for pack in fields]).reshape(COUNT, n, h, w)
    guards = np.stack((guard, np.roll(guard, (2, 2), axis=(-2, -1))))
    availability = np.stack([pack[5] for pack in fields]).reshape(COUNT, n, h, w)
    frequencies = phases.reshape(COUNT, n, h, w, 2)
    native = local.NATIVE
    pieces = field.reshape(COUNT, n, h, w, native, native)
    pad = local.STRIDE
    dims = 2 * raw.shape[-2] + 2 * pad, 2 * raw.shape[-1] + 2 * pad
    weight = np.zeros(dims)
    out = np.zeros((3, n, *dims))
    for i in range(h):
        for j in range(w):
            a = np.s_[i * 2 * pad:i * 2 * pad + native, j * 2 * pad:j * 2 * pad + native]
            weight[a] += taper
            piece = pieces[:, :, i, j]
            gates = receiving_gate(frequencies, availability, guards, i, j)
            out[0, ..., a[0], a[1]] += piece.sum(axis=0) * taper
            out[1:, ..., a[0], a[1]] += (gates * piece).sum(axis=1) * taper
    valid = np.all((raw > 0.001) & (raw < 0.995), axis=1).repeat(2, -2).repeat(2, -1)
    safe = gaussian_filter(valid.astype(float), (0, 2, 2))
    return (out / np.maximum(1e-10, weight))[..., pad:-pad, pad:-pad] * safe


def fields(d, p, profile):
    raw = d["packed"]
    sensors = [local.observations(raw, p["nominal"][:, 1], profile, phase)
               for phase in np.flatnonzero(d["colors"] == 1)]
    shape = sensors[0]["shape"]
    neutral = np.linalg.solve(d["matrix"].astype(float), np.ones(3)) / d["wb"]
    folds = [old.data_in_fold(d, profile, j) for j in (0, 1)]
    answer, detail = 0.0, []
    for i, fold in enumerate(folds):
        main, prior, weak, power = ranked(fold)
        score, z = verify(fold, folds[1-i], main, weak)
        fits = [station(sensors, ((main, prior), (weak[..., k, :], power[..., k])),
                        old.expand(score[..., k], shape)) for k in range(COUNT)]
        answer = answer + .5 * deliver(fits, raw, neutral, shape)
        detail.append({
            "frequency": np.stack([p_[0].reshape(*shape, 2) for p_ in fits]),
            "center": np.stack([p_[3].reshape(shape) for p_ in fits]),
            "guard": np.stack([p_[4].reshape(shape) for p_ in fits]),
            "active": np.stack([(p_[2] > 0).reshape(shape) for p_ in fits]),
            "votes": z,
        })
    names = ("shortlist", "directional", "rolled directional")
    return dict(zip(names, answer, strict=True)), neutral, detail
