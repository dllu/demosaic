"""Check wider carrier recovery and exact separation of donor and recipient pixels."""

import numpy as np

from wide_phase import SIZE, nominate

STRENGTHS = (0.015, 0.008)
FREQUENCIES = np.array(((0.045, 0.072), (0.085, -0.047)))
PROFILE = {"shot": 0.00128, "read": 6.5536e-6}


def field():
    y, x = np.meshgrid(np.arange(SIZE), np.arange(SIZE), indexing="ij")
    a = (0.12 + 0.03 * y / SIZE) + STRENGTHS[0] * (np.cos(2 * np.pi * (
        FREQUENCIES[0, 0] * y + FREQUENCIES[0, 1] * x
    )) + 0.6 * np.cos(4 * np.pi * (FREQUENCIES[0, 0] * y + FREQUENCIES[0, 1] * x)))
    a += STRENGTHS[1] * np.cos(2 * np.pi * (FREQUENCIES[1, 0] * y + FREQUENCIES[1, 1] * x))
    rng = np.random.default_rng(202611201517)
    a += rng.normal(0, np.sqrt(PROFILE["shot"] * a + PROFILE["read"]))
    raw = np.stack([a[i::2, j::2] for i, j in ((0, 0), (0, 1), (1, 0), (1, 1))])[None]
    return {"packed": raw, "colors": np.array([0, 1, 1, 2])}


if __name__ == "__main__":
    data = field()
    nominations = nominate(data, PROFILE)
    for quadrant in range(4):
        oy, ox = divmod(quadrant, 2)
        changed = data["packed"].copy()
        changed[..., oy * 64:(oy+1) * 64, ox * 64:(ox+1) * 64] = 0.81 - changed[
            ..., oy * 64:(oy+1) * 64, ox * 64:(ox+1) * 64
        ]
        control = nominate(data | {"packed": changed}, PROFILE)
        for k, found in nominations.items():
            for (a, vote), (b, altered_vote) in zip(found, control[k], strict=True):
                np.testing.assert_array_equal(a[:, quadrant], b[:, quadrant])
                np.testing.assert_array_equal(vote[:, quadrant], altered_vote[:, quadrant])
    plain = nominations["wide"][1][0]
    robust = nominations["harmonic"][1][0]
    print("plain", plain, "harmonic", robust)
    assert np.max(np.linalg.norm(robust - FREQUENCIES[1], axis=-1)) <= 0.01
