"""Measure real cab coverage of the shortlisted hypotheses against one nomination."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_shortlist import OUT, operator, review

PAIR = {
    "left": np.array([(0.1152, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
    "right": np.array([(0.1172, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
}
TOL = 0.009


def match(v, direction):
    return np.minimum(np.linalg.norm(v-direction, axis=-1), np.linalg.norm(v+direction, axis=-1)) <= TOL


def measure(raw, parent, profile, directions, box):
    _, _, new = operator.fields(raw, parent, profile)
    _, _, old = operator.old.fields(raw, parent, profile)
    result = []
    for direction in directions:
        u, v = [], []
        for checked_fold, rank_one in zip(new, old, strict=True):
            before = match(rank_one["phase"], direction) & rank_one["nominated"] & rank_one["checked"] & rank_one["center"]
            c = match(checked_fold["frequency"], direction) & checked_fold["active"] & (checked_fold["center"] > 0)
            u.append(before & box)
            v.append(np.stack((c.any(axis=0), (c & (checked_fold["guard"] > .25)).any(axis=0))) & box)
        result.append([int(np.logical_or(*u).sum()), *np.logical_or(*v).sum(axis=(1,2,3)).tolist()])
    return result


if __name__ == "__main__":
    adapter = reference(OUT / "native-adapter.json")
    review_plan = read_json(checked(adapter))
    fields = {}
    for row,d,p,_ in review.Cases("camera"):
        label = row["id"]
        if not label.startswith("mesh-"):
            continue
        q = review_plan["rows"][label]
        assert q["input"] == row["input"]
        ox,oy,w,h=q["operator_roi"]
        x,y,cw,ch=q["display_roi"]
        plane = np.s_[...,oy//2:(oy+h)//2,ox//2:(ox+w)//2]
        area = np.s_[...,oy:oy+h,ox:ox+w]
        pos=np.arange(16,256,32)
        box=((pos+oy>=y)&(pos+oy<y+ch))[:,None] & ((pos+ox>=x)&(pos+ox<x+cw))[None,:]
        pair=PAIR[label.rsplit("-",1)[-1]]
        counts = measure(d | {"packed":d["packed"][plane]},p | {"nominal":p["nominal"][area]},
                         row["profile"],pair,box)
        fields[label]={"input":row["input"],"stations":int(box.sum()),"pair_fy_fx":pair.tolist(),"counts":counts}
    write_json(OUT / "camera-frequency.json", {
        "driver":reference(Path(__file__)), "review":adapter,
        "source":reference(Path.cwd()/"docs/bayer-carrier-scale.md"),
        "columns":["rank one passes both witnesses","shortlist passes with positive deficit",
                   "shortlist passes with positive deficit and continuation > .25"],
        "tolerance_cycles_per_pixel":TOL,"rows":fields,
    })
