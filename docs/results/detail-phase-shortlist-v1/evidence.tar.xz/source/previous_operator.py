"""Validate frequency and signed phase on a disjoint part of the wider Bayer context."""

from functools import cache
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
from scipy.ndimage import gaussian_filter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("detail-wide-phase-v1")))
import wide_phase as wide

local = wide.local
SIZE = wide.SIZE
PACKED = wide.PACKED
SIGMA = (0, 0, 0, 5, 5)
WITNESS = 1.15
FOLD_SEED = 202611201127


@cache
def split_layout():
    """Each native 8×8 cell puts half its Bayer blocks in each fold."""
    rng = np.random.default_rng(FOLD_SEED)
    cells = PACKED // 4
    code = rng.random((cells, cells, 16)).argsort(axis=-1) < 8
    first = code.reshape(cells, cells, 4, 4).transpose(0, 2, 1, 3).reshape(PACKED, PACKED)
    assert first.sum() == PACKED**2 // 2
    return np.stack((first, ~first))


def data_in_fold(d, profile, fold):
    donors, taper, _, _, _ = wide.geometry()
    phases = np.flatnonzero(d["colors"] == 1)
    raw = d["packed"][:, phases].astype(np.float64)
    assert raw.shape[-2:] == (PACKED, PACKED) and len(phases) == 2
    present = (raw > 0.001) & (raw < 0.995)
    mask = (donors & split_layout()[fold])[None, :, None] & present[:, None]
    weight = taper[None, :, None] * mask
    measured = np.where(mask, raw[:, None], 0)
    normalizer = np.maximum(gaussian_filter(mask.astype(float), SIGMA), 1e-10)
    smooth = gaussian_filter(measured, SIGMA) / normalizer
    base = np.where(mask, measured - smooth, 0)
    mean = (weight * measured).sum((-2, -1)) / np.maximum(weight.sum((-2, -1)), 1)
    noise = np.maximum(2e-10, profile["shot"] * mean + profile["read"])
    offsets = np.asarray([divmod(int(p), 2) for p in phases])
    return base, weight, noise, offsets, mask, normalizer


def nominate(split):
    base, weight, noise, offsets, _, _ = split
    _, _, _, _, band = wide.geometry()
    wave = wide.spectrum(base, weight, noise, offsets)
    strong, first = wide.peak(wave, band, prominence=True)
    rest = wide.remove(base, weight, strong, wide.ROBUST)
    weak, second = wide.peak(wide.spectrum(rest, weight, noise, offsets),
                            wide.separation(strong, robust=True), prominence=True)
    return (strong, first), (weak, second)


def basis(selected):
    (main, _), (weak, _) = selected
    _, _, coords, _, _ = wide.geometry()
    f = np.concatenate((main[..., None, :] * np.asarray(wide.ROBUST)[:, None],
                        weak[..., None, :]), axis=-2)
    theta = 2 * np.pi * np.einsum("nqdc,yxc->nqyxd", f, coords)
    span = np.stack((np.cos(theta), np.sin(theta)), axis=-1)
    return span.reshape(*span.shape[:2], 1, PACKED**2, 2 * f.shape[-2])


def coefficients(split, X, offsets, weak):
    base, weight, noise, _, mask, normal = split
    w = weight.reshape(*base.shape[:3], PACKED**2)
    weighted = X * w[..., None]
    transposed = np.swapaxes(weighted, -1, -2)
    G = transposed @ X + np.eye(X.shape[-1]) * 1e-5
    inverse = np.linalg.solve(G, np.broadcast_to(np.eye(G.shape[-1]), G.shape))
    fit = (inverse @ (transposed @ base.reshape(*w.shape, 1)))[..., -2:, 0]
    influence = (weighted @ inverse[..., -2:]).reshape(*base.shape, 2)
    # The per-green fits use the same packed-block origin. Align phase on
    # the native coordinates before comparing the two physical lattices.
    shift = 2 * np.pi * np.einsum("nqc,pc->nqp", weak, offsets)
    c, s = np.cos(shift), np.sin(shift)
    rotation = np.stack((c, s, -s, c), axis=-1).reshape(*c.shape, 2, 2)
    aligned = (fit[..., None, :] @ rotation)[..., 0, :]
    return aligned, influence, rotation, noise, mask, normal


def confidence(train, held, selected):
    X = basis(selected)
    weak = selected[1][0]
    fit, *_ = coefficients(train, X, train[3], weak)
    center, impact, rotation, noise, mask, normal = coefficients(held, X, held[3], weak)
    phase = fit.mean(axis=-2)
    phase /= np.maximum(np.linalg.norm(phase, axis=-1, keepdims=True), 1e-10)
    perpendicular = np.stack((-phase[..., 1], phase[..., 0]), axis=-1)
    # A fixed signed phase and its quarter-cycle counterpart are tested once
    # each. The variance uses the exact adjoint of masked Gaussian subtraction.
    def verify(direction):
        aligned = (center * direction[..., None, :]).sum(-1)
        native_axis = (rotation @ direction[..., None, :, None])[..., 0]
        weights = np.einsum("nqpyxc,nqpc->nqpyx", impact, native_axis)
        effective = weights - mask * gaussian_filter(weights / normal, SIGMA)
        se = np.sqrt(np.maximum(1e-12, noise * np.sum(effective**2, axis=(-2, -1))))
        evidence = (aligned / se).min(axis=-1)
        excess = np.maximum(evidence - WITNESS, 0)
        return excess / (1.0 + excess), evidence

    return verify(phase), verify(perpendicular)


def expand(gain, shape):
    n, ny, nx = shape
    iy, ix = np.meshgrid(np.arange(ny), np.arange(nx), indexing="ij")
    quadrant = (iy >= ny // 2) * 2 + (ix >= nx // 2)
    assert len(gain) == n
    return gain[:, quadrant].reshape(-1)


def fold_render(d, p, profile, nomination, matched, rotated):
    raw, base = d["packed"], p["nominal"][:, 1]
    sensors = [local.observations(raw, base, profile, b) for b in np.flatnonzero(d["colors"] == 1)]
    with patch.object(local, "discover", wide.inject(nomination)):
        f, phase, strength, check, active, z = local.inspect(sensors)
    shape = sensors[0]["shape"]
    matched, rotated = (expand(k, shape) for k in (matched, rotated))
    variants = []
    for gate in (np.ones_like(matched), matched, rotated):
        def replace_inspection(_):
            return f, phase, strength * gate, check, active & (gate > 0), z

        with patch.object(local, "inspect", replace_inspection):
            moves, neutral, _ = local.fields(d, p, profile)
        variants.append(moves)
    result = {
        "split": variants[0]["directional"],
        "directional": variants[1]["directional"],
        "donor only": variants[1]["exterior"],
        "rolled directional": variants[2]["directional"],
    }
    return result, neutral, {
        "phase": f.reshape(shape + (2,)), "nominated": active.reshape(shape),
        "center": (check > 0).reshape(shape), "checked": (matched > 0).reshape(shape),
        "rotated": (rotated > 0).reshape(shape),
    }


def fields(d, p, profile):
    folds = [data_in_fold(d, profile, i) for i in (0, 1)]
    keys = ("split", "directional", "donor only", "rolled directional")
    output = dict.fromkeys(keys, 0.0)
    evidence = []
    for i, data in enumerate(folds):
        nominated = nominate(data)
        (agree, z), (rotated, wrong) = confidence(data, folds[1 - i], nominated)
        result, neutral, detail = fold_render(d, p, profile, nominated, agree, rotated)
        output = {name: output[name] + 0.5 * value for name, value in result.items()}
        evidence.append(detail | {"signed_z": z, "rotated_z": wrong})
    return output, neutral, evidence
