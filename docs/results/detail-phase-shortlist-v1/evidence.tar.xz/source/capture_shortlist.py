"""Capture a new panel while preserving all earlier source exclusions."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PROTECTED = ("detail-wide-phase-v1", "detail-crossfit-phase-v1")
SEED = 202611201138
spec = spec_from_file_location("wide_capture_design", HERE.with_name(PROTECTED[0]) / "capture_wide.py")
design = module_from_spec(spec)
spec.loader.exec_module(design)


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    marker = folder / "plan.json"
    if not marker.exists():
        with patch.object(design, "SEED", SEED), patch.object(
            design, "PROTECTED", (*design.PROTECTED, *PROTECTED)
        ):
            plan = design.select()
        write_json(marker, plan | {"followup_driver": reference(Path(__file__)),
                                   "selection_operator": reference(Path(design.__file__))})
    with patch.object(design.prior.c, "OUT", folder), patch.object(design.prior.c, "SEED", SEED):
        design.prior.c.collect("held")
