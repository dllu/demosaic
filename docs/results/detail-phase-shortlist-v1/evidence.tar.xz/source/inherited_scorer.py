"""Calibrate fixed-strength learned gains and score new sources with the same controls."""

import json
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT, ROI, Gate, base, wire_scorer, ingredients, normalized, remove
from fit_wire_gate import METHODS, Constant
from measure_proposal import binding as frozen_router, off_grid, FWD
from review_router import render as render_router
from deficit import fields as deficit_fields
from evaluate_selector import deltas, values
from confirm_router import assess, coefficient_data, Z
import mild_score as math
import score

GRID = tuple(float(x) for x in np.linspace(0, 1, 51))
WIRE_LIMITS = {
    "intact_increment_RMS_DN16": 0.10,
    "gap_weak_RMS_DN16": 0.05,
    "exterior_only_weak_RMS_DN16": 0.05,
    "exact_flat_RMS_DN16": 0.10,
}
OLD_DIR = OUT.with_name("detail-directional-proposal-v1")
CONTROLS = ("nominal", "router", "parent phase", "v120")
DISPLAY = {
    "nominal": "Local 50k EMA",
    "router": "Earlier Bayer blend",
    "parent phase": "Parent-phase deficit",
    "v120": "V120 EMA",
    "constant": "Fixed learned gains",
    "conditioning": "Learned conditioning",
    "directional": "Learned directional",
}


def load_models(phase="training"):
    trained = reference(OUT / ("fit-" + phase) / "result.json")
    info = read_json(checked(trained))
    networks = {}
    normal = None
    for k in METHODS:
        r = torch.load(checked(info["checkpoints"][k]), weights_only=True, map_location="cpu")
        net = Constant() if k == "constant" else Gate(k == "directional")
        net.load_state_dict(r["ema"])
        networks[k] = net.requires_grad_(False).eval()
        if normal:
            for m, v in normal.items():
                torch.testing.assert_close(v, r["normal"][m], rtol=0, atol=0)
        normal = r["normal"]
    ancestor, params = frozen_router()
    parent_phase = reference(OLD_DIR / "deficit/calibration.json")
    bound = read_json(checked(parent_phase))
    strength = bound["policy"]["arms"]["parent phase"]["locked"]["dose"]
    assert bound["router"] == json.loads(json.dumps(ancestor))
    return trained, network_dictionary(networks, normal, ancestor, params, parent_phase, strength)


def network_dictionary(networks, normal, ancestor, params, parent_phase, strength):
    return {
        "net": networks,
        "normal": normal,
        "router": ancestor,
        "router_params": params,
        "parent_phase": parent_phase,
        "deficit_dose": strength,
    }


def loads(ref):
    collection = read_json(checked(ref))
    for step in collection["chunks"]:
        rows = read_json(checked(step))
        assert rows["plan"] == collection["plan"]
        for r in rows["rows"]:
            with np.load(checked(r["file"]), allow_pickle=False) as f:
                pred = {k: f[k] for k in ("nominal", "crisp", "smooth", "v120")}
                obs = {k: f[k] for k in f.files if k not in pred}
            yield r, obs, pred, {"input": r["file"]}


@torch.no_grad()
def prepare(row, d, p, network):
    raw, cap, modes, neutral = ingredients(d, p, row["profile"])
    x = normalized(torch.from_numpy(raw), network["normal"])
    c = torch.from_numpy(cap)
    additions = {k: deltas(modes, head(x, c)).sum(1) for k, head in network["net"].items()}
    moved = x.roll((4, 4), dims=(-3, -2))
    additions["rolled directional"] = deltas(modes, network["net"]["directional"](moved, c)).sum(1)
    old = network["router"]
    key = old["name"]
    blend = render_router(d, p, row, network["router_params"], {key: old["dose"]})[key]
    fields, _ = deficit_fields(d, p, row["profile"])
    v = (
        blend
        + network["deficit_dose"] * fields["parent phase"][:, None] * neutral[None, :, None, None]
    ).astype(blend.dtype)
    known = {"nominal": p["nominal"], "router": blend, "parent phase": v}
    if "v120" in p:
        known["v120"] = p["v120"]
    return known, {k: v[:, None] * neutral[None, :, None, None] for k, v in additions.items()}


def polynomial(metric, anchor, moves):
    t = {}
    original = metric(anchor)
    for key, v in moves.items():
        plus = metric(anchor + v)
        minus = metric(anchor - v)
        q = {}
        for m, b in original.items():
            if m == "weak_response_pp":
                q[m] = [b, (plus[m] - minus[m]) / 2, 0.0]
            else:
                a, c = minus[m] ** 2, plus[m] ** 2
                q[m] = [b * b, (c - a) / 2, (c + a) / 2 - b * b]
        t[key] = q
    return t


def record(x, network, factory):
    case, d, p, bind = x
    known, moves = prepare(case, d, p, network)
    label = case["kind"]
    info = {
        "id": case["id"],
        "source": case["source"]["id"],
        "cache": case["source"]["cache_sha256"],
        "kind": label,
        "proof": bind,
        "fixture": case["fixture"],
    }
    if label == "wire":
        geometry = case["fixture"]["geometry"]
        if geometry["family"] in ("smooth-dip", "contrast-step"):
            d = d | {"support": np.ones_like(d["support"])}
        metric = factory(d, geometry)

        def parts(delta):
            y = base.old.luma(delta, d)[ROI]
            q = remove(y[[0, 2]][:, metric.intact], metric.intact_nuisance)
            return (np.array([1, -1]) * 100 * (q @ metric.truth_weak) / metric.strength).tolist()

        return info | {
            "controls": {k: metric(x) for k, x in known.items()},
            "terms": polynomial(metric, p["nominal"], moves),
            "role_projection": {
                k: parts(v)
                for k, v in (
                    {k: v.astype(np.float64) - p["nominal"] for k, v in known.items()} | moves
                ).items()
            },
        }
    selected = [0, 2, 3]
    target = score.stats(d["target"][selected], d)
    q = score.stats(p["nominal"][selected], d)
    zero = np.zeros_like(q)
    terms = {k: math.terms(target, q, score.stats(x[selected], d), zero) for k, x in moves.items()}
    terms.update(
        {k: math.terms(target, score.stats(x[selected], d), zero, zero) for k, x in known.items()}
    )
    return info | {"scores": terms}


def wire_values(rows, arm, name, dose):
    if arm in METHODS or arm == "rolled directional":
        packed = np.asarray([r["terms"][arm][name] for r in rows if name in r["terms"][arm]])
        axis = packed @ np.array([1, dose, dose * dose])
        return axis if name == "weak_response_pp" else np.sqrt(np.maximum(0.0, axis))
    return np.asarray([r["controls"][arm][name] for r in rows if name in r["controls"][arm]])


def separated(rows):
    wires = [r for r in rows if r["kind"] == "wire"]
    natural = {g: [r for r in rows if r["kind"] == g] for g in ("faint", "stronger")}
    return wires, natural


def locks(rows):
    wires, photo = separated(rows)
    nominal = {m: wire_values(wires, "nominal", m, 0) for m in WIRE_LIMITS}
    natural = {k: coefficient_data(v, "nominal") for k, v in photo.items() if v}
    result = {}
    for arm in METHODS:
        measures = {k: coefficient_data(photo[k], arm) for k in natural}
        bounds = []
        for x in GRID:
            actual = {m: wire_values(wires, arm, m, x) for m in WIRE_LIMITS}
            effect = {k: v - nominal[k] for k, v in actual.items()}
            raw = {k: float(v.mean()) for k, v in effect.items()}
            upper = {
                k: float(v.mean() + Z * np.std(v, ddof=1) / np.sqrt(len(v)))
                for k, v in effect.items()
            }
            photo_ = {k: assess(v, natural[k], (x, 0)) for k, v in measures.items()}
            reserve = all(v <= WIRE_LIMITS[k] for k, v in upper.items())
            bounds.append(
                {
                    "dose": x,
                    "response": float(wire_values(wires, arm, "weak_response_pp", x).mean()),
                    "wire_delta": raw,
                    "wire_upper_delta": upper,
                    "photo": photo_,
                    "joint": reserve
                    and all(
                        v <= score.LIMITS[k]
                        for r in photo_.values()
                        for k, v in r["upper_delta"].items()
                    ),
                    "wire_only": reserve,
                }
            )
        key = lambda d: d["response"]
        result[arm] = {
            "locked": max((x for x in bounds if x["joint"]), key=key),
            "wire-only": max((x for x in bounds if x["wire_only"]), key=key),
            "trials": bounds,
        }
    return {"wire_limits": WIRE_LIMITS, "natural_limits": score.LIMITS, "arms": result, "z": Z}


def summarize(rows, policy):
    ww, pp = separated(rows)
    rng = np.random.default_rng(202611201037)
    samples = lambda n: np.vstack((np.arange(n), rng.integers(0, n, (12000, n))))
    doses = {k: r["locked"]["dose"] for k, r in policy["arms"].items()}
    doses |= {k + " full": 1.0 for k in METHODS} | {"rolled directional": doses["directional"]}
    wire_metrics = {}
    tags = list(ww[0]["controls"]) + list(doses)
    measured = sorted({k for r in ww for k in r["controls"]["nominal"]})
    alias = lambda k: k.removesuffix(" full")
    for item in measured:
        data = {k: wire_values(ww, alias(k), item, doses.get(k, 0)) for k in tags}
        idx = samples(len(data["nominal"]))
        boosts = {k: v[idx].mean(1) for k, v in data.items()}
        wire_metrics[item] = {
            k: {
                "mean": float(v[0]),
                "intervals": {
                    p: [float((v - b)[0]), *np.quantile(v - b, (0.025, 0.975)).tolist()]
                    for p, b in boosts.items()
                    if p
                    in (
                        "nominal",
                        "router",
                        "parent phase",
                        "constant",
                        "conditioning",
                        "rolled directional",
                    )
                },
            }
            for k, v in boosts.items()
        }
    photo = {}
    for k, rows_ in pp.items():
        if not rows_:
            continue
        n = len(rows_)
        idx = samples(n)
        available = list(rows_[0]["scores"])
        data = {
            arm: values(rows_, alias(arm), (doses.get(arm, 0), 0))
            for arm in list(doses) + [key for key in available if key not in doses]
        }
        ensemble = {
            a: {m: np.sqrt((v[m][idx] ** 2).mean(1)) for m in score.LIMITS}
            | {"response_pp": 100 * v["projection"][idx].sum(1) / v["true"][idx].sum(1)}
            for a, v in data.items()
        }
        weaker = np.argsort(data["nominal"]["true"])[: n // 2]
        photo[k] = {
            "scores": {a: score.evaluate(d) for a, d in data.items()},
            "weakest_half": {
                a: score.evaluate({m: v[weaker] for m, v in d.items()}) for a, d in data.items()
            },
            "intervals": {
                a: {
                    p: {
                        k: [
                            float((v[k] - base[k])[0]),
                            *np.quantile(v[k] - base[k], (0.025, 0.975)).tolist(),
                        ]
                        for k in v
                    }
                    for p, base in ensemble.items()
                    if p in ("nominal", "router", "parent phase", "conditioning")
                }
                for a, v in ensemble.items()
            },
        }
    parts = {
        k: (
            np.mean([r["role_projection"][alias(k)] for r in ww], axis=0) * doses.get(k, 1.0)
        ).tolist()
        for k in tags
    }
    return {"wire": wire_metrics, "photo": photo, "response_role_contributions_from_nominal": parts}


def run(group):
    torch.set_num_threads(2)
    weights, nets = load_models()
    scorer, factory = wire_scorer()
    if group == "off-grid":
        source = reference(FWD)
        fixtures = ((r | {"kind": "wire"}, d, p, s) for r, d, p, s in off_grid(source))
    else:
        source = reference(OUT / group / "completed.json")
        fixtures = loads(source)
    start = monotonic()
    items = []
    for row in fixtures:
        items.append(record(row, nets, factory))
        if len(items) % 8 == 0:
            print(group, len(items), round(monotonic() - start, 2), flush=True)
    earlier = None if group == "calibration" else reference(OUT / "score-calibration.json")
    policy = read_json(checked(earlier))["policy"] if earlier else locks(items)
    q = summarize(items, policy)
    for k, r in policy["arms"].items():
        print(k, r["locked"]["dose"], r["wire-only"]["dose"], flush=True)
    for metric, r in q["wire"].items():
        print(metric, {k: x["mean"] for k, x in r.items()}, flush=True)
    write_json(
        OUT / f"score-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "weights": weights,
            "source": source,
            "scorer": scorer,
            "ancestor": nets["router"],
            "deficit": nets["parent_phase"],
            "calibration": earlier,
            "policy": policy,
            "rows": items,
            "summary": q,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
