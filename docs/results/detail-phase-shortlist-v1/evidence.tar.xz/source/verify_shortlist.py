"""Check frequency independence, capped delivery and the local gap check."""

from pathlib import Path
import sys

import numpy as np

from shortlist_phase import HERE, fields, ranked, old, local

sys.path.insert(0, str(HERE.with_name("detail-wide-phase-v1")))
from verify_wide import PROFILE, FREQUENCIES


def image(gap=False):
    y, x = np.meshgrid(np.arange(256), np.arange(256), indexing="ij")
    phi = 2 * np.pi * (FREQUENCIES[0, 0] * y + FREQUENCIES[0, 1] * x)
    psi = 2 * np.pi * (FREQUENCIES[1, 0] * y + FREQUENCIES[1, 1] * x)
    base = .12 + .02 * y / 256 + .012 * np.cos(phi) + .006 * np.cos(2 * phi)
    add = .009 * np.cos(psi)
    if gap:
        add = np.where((np.abs(y - 79.5) <= 22) & (np.abs(x - 79.5) <= 22), 0, add)
    clean = base + add
    rng = np.random.default_rng(202611201140)
    noisy = clean + rng.normal(0, np.sqrt(PROFILE["shot"] * clean + PROFILE["read"]))
    packed = np.stack([noisy[i::2, j::2] for i, j in ((0, 0), (0, 1), (1, 0), (1, 1))])[None]
    return {
        "packed": packed, "colors": np.asarray((0, 1, 1, 2)),
        "matrix": np.eye(3), "wb": np.ones(3),
    }, {"nominal": np.repeat(base[None, None], 3, axis=1)}


if __name__ == "__main__":
    data, parent = image()
    for k in (0, 1):
        proof = ranked(old.data_in_fold(data, PROFILE, k))
        actual = proof[2]
        assert np.max(np.min(np.linalg.norm(actual - FREQUENCIES[1], axis=-1), axis=-1)) <= 0.007
        changed = data["packed"].copy()
        changed[..., old.split_layout()[1-k]] = 0.84 - changed[..., old.split_layout()[1-k]]
        test = ranked(old.data_in_fold(data | {"packed": changed}, PROFILE, k))
        for a, b in zip(proof, test, strict=True):
            np.testing.assert_array_equal(a, b)
    yes, _, _ = fields(data, parent, PROFILE)
    d, p = image(gap=True)
    skip, _, notes = fields(d, p, PROFILE)
    for c in (yes, skip):
        assert all(np.max(np.abs(x)) <= local.CAP + 1e-10 for x in c.values())
    roi = np.s_[:, 71:89, 71:89]
    rms = lambda x: np.sqrt(np.mean(x[roi]**2)) * 65535
    assert rms(yes["directional"]) > 4
    print("test gap RMS", rms(skip["directional"]), rms(skip["shortlist"]))
    assert rms(skip["directional"]) < rms(skip["shortlist"]) * 0.8
    print("Intact checked", rms(yes["directional"]),
          "gap unchecked", rms(skip["shortlist"]), "gap checked", rms(skip["directional"]))
