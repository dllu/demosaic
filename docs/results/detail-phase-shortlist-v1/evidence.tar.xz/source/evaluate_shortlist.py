"""Compare wider frequency coverage and local continuation against validated rank one."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import shortlist_phase as operator
import evaluate_crossfit as previous
import score_wire_gate as scoring
import review_wire_gate as review

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
OLDER = previous.OUT
METHODS = ("shortlist", "directional")
LABELS = {
    "rank one": "Validated single nomination",
    "shortlist": "Validated shortlist",
    "directional": "Shortlist with gap check",
}
ORDER = ("nominal", "rank one", *METHODS)


def models():
    _, nets = previous.models()
    control = reference(OLDER / "score-calibration.json")
    nets["rank_one_strength"] = read_json(checked(control))["policy"]["arms"]["directional"]["locked"]["dose"]
    return reference(OUT / "plan.json"), nets


def prepare(row, d, p, nets):
    nominal = p["nominal"]
    known = {"nominal": nominal}
    if "v120" in p:
        known["v120"] = p["v120"]
    if "local_ROI" in row:
        routed, _ = previous.previous.previous.prepare(row, d, p, nets)
        known.update({k: routed[k] for k in ("router", "parent phase")})
    before, neutral, _ = operator.old.fields(d, p, row["profile"])
    known["rank one"] = (nominal + nets["rank_one_strength"] * before["directional"][:, None] *
                         neutral[None, :, None, None]).astype(nominal.dtype)
    after, direction, _ = operator.fields(d, p, row["profile"])
    return known, {k: v[:, None] * direction[None, :, None, None] for k, v in after.items()}


def stage():
    limits = scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": previous.previous.previous.prior.CONTINUING_LIMIT}
    paths = {
        "calibration": OLDER / "calibration",
        "prior-held": OLDER / "held",
        "held": OUT / "confirmation/held",
    }
    for key, parent in paths.items():
        target = OUT / key
        if not target.exists() and not target.is_symlink():
            target.symlink_to(parent, target_is_directory=True)
        assert target.resolve() == parent.resolve()
    output = OUT / "plan.json"
    if not output.exists():
        write_json(output, {
            "driver": reference(Path(__file__)), "operator": reference(Path(operator.__file__)),
            "previous_operator": reference(Path(operator.old.__file__)),
            "wide_operator": reference(Path(operator.wide.__file__)),
            "local_operator": reference(Path(operator.local.__file__)),
            "capture_selection": reference(OUT / "confirmation/plan.json"),
            "previous_plan": reference(OLDER / "plan.json"),
            "previous_calibration": reference(OLDER / "score-calibration.json"),
            "calibration": reference(paths["calibration"] / "completed.json"),
            "replay": reference(paths["prior-held"] / "completed.json"),
            "inherited_scorer": reference(Path(scoring.__file__)),
            "inherited_reviewer": reference(Path(review.__file__)),
            "candidates": operator.COUNT, "minimum_score": operator.MIN_WITNESS,
            "methods": METHODS, "limits": limits,
            "scope": "Matched calibration, new source-disjoint confirmation, and separate prior development replay.",
        })
    return limits


def run(mode):
    limits = stage()
    with ExitStack() as stack:
        for mod, name, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepare),
            (scoring, "WIRE_LIMITS", limits),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepare),
            (review, "ORDER", ORDER),
            (review, "DISPLAY", review.DISPLAY | LABELS),
        ):
            stack.enter_context(patch.object(mod, name, value))
        if mode == "review":
            review.run()
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
