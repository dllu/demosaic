"""Check the small active-set solver against an independent primal solve."""

from pathlib import Path

import numpy as np
from scipy.optimize import minimize

from demosaic.experiments.artifacts import reference, write_json
from projection import protected_projection

SEED = 71


def main():
    rng = np.random.default_rng(SEED)
    errors, residuals = [], []
    for dimension in (2, 6):
        for count in (1, 2, 3):
            for index in range(40):
                controls = rng.normal(size=(count, dimension))
                controls /= np.linalg.norm(controls, axis=1)[:, None]
                if index == 0 and count >= 2:
                    controls[1] = -controls[0]
                if index == 1 and count >= 2:
                    controls[1] = controls[0]
                proposed = rng.normal(size=dimension)
                proposed /= np.linalg.norm(proposed)
                coefficients = protected_projection(controls @ controls.T, controls @ proposed)
                projected = proposed - controls.T @ coefficients
                solution = minimize(
                    lambda x: np.linalg.norm(x - proposed) ** 2,
                    np.zeros(dimension), jac=lambda x: 2 * (x - proposed),
                    constraints={"type": "ineq", "fun": lambda x: -controls @ x,
                                 "jac": lambda x: -controls},
                    method="SLSQP", options={"ftol": 1e-12},
                )
                residual = float(max(controls @ projected))
                error = float(np.linalg.norm(projected - solution.x))
                assert solution.success and residual < 1.1e-10 and error < 2e-6
                errors.append(error)
                residuals.append(residual)
    root = Path(__file__).resolve().parent
    output = root / "solver-qualification.json"
    write_json(output, {
        "driver": reference(__file__), "projection": reference(root / "projection.py"),
        "seed": SEED, "cases": len(errors),
        "maximum_primal_difference": max(errors), "maximum_constraint_residual": max(residuals),
    })
    print("Verified independent primal solution for",len(errors),"constraints")


if __name__ == "__main__":
    main()
