"""Freeze the finite AdamW method and its first verified replays."""

from hashlib import sha256
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

RECIPE = Path(__file__).resolve().parent
REPO = RECIPE.parents[2]
RUN = Path("/mnt/external/demosaic") / RECIPE.name
COUNT = 8


def main():
    plan_ref = reference(RUN / "plan.json")
    plan = read_json(checked(plan_ref))
    owner = read_json(RUN / "owner.json")
    assert owner_live(owner)
    rows = [reference(RUN / f"pair-{index:02d}.json") for index in range(1, COUNT + 1)]
    samples = [read_json(checked(row)) for row in rows]
    qualification = reference(RECIPE / "solver-qualification.json")
    solver = read_json(checked(qualification))
    assert solver["cases"] == 240 and solver["projection"] == plan["projection_driver"]
    assert len(plan["paired_groups"]) == 32
    assert len({r[k]["case"]["source"]["id"] for r in plan["paired_groups"] for k in ("update","reserve")}) == 64
    assert all(r["plan"] == plan_ref and r["pair"] == i for i,r in enumerate(samples, 1))
    assert samples[0]["real_fused_adam_verified"]
    distances = [r["geometry"] for r in samples]
    strength = max(abs(v["projected_increment_L2"] - v["scaled_increment_L2"]) /
                   v["full_increment_L2"] for v in distances)
    assert strength < .006
    data = [
        plan_ref, *rows, qualification, solver["driver"], plan["completion"],
        *(plan[k] for k in ("driver", "probe_driver", "projection_driver")), reference(__file__),
    ]
    output = REPO / "docs/results" / RECIPE.name
    output.mkdir()
    path = output / "launch-evidence.tar.xz"
    members = {}
    with tarfile.open(path, "x:xz", preset=4) as bundle:
        for ref in data:
            source = checked(ref)
            member = (source.relative_to(REPO) if source.is_relative_to(REPO)
                      else Path("external") / source.relative_to("/mnt/external/demosaic")).as_posix()
            assert member not in members
            members[member] = ref["sha256"]
            bundle.add(source, arcname=member)
    with tarfile.open(path) as bundle:
        assert all(sha256(bundle.extractfile(name).read()).hexdigest()==value
                   for name,value in members.items())
    write_json(output / "launch.json", {
        "scope": "Method qualification and verified live prefix. Full reserve analysis is collected separately.",
        "regional_checkpoint": plan["regional_checkpoint"], "optimizer_clock": 1024, "weights": "raw",
        "run_plan": plan_ref, "planned_pairs": len(plan["paired_groups"]),
        "verified_prefix_pairs": len(samples), "owner": owner,
        "independent_solver": solver, "optimizer_exact_parity": samples[0]["real_fused_adam_verified"],
        "maximum_norm_mismatch_relative_to_full_increment": strength,
        "prefix": rows, "archive": reference(path), "members": members,
    })


if __name__ == "__main__":
    main()
