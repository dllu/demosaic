"""Replay finite shadow AdamW updates with and without directional protection."""

import argparse
from dataclasses import replace
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn.utils import clip_grad_norm_, get_total_norm
from torch.optim.adamw import adamw

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import RuntimePolicy, exclusive_run
from demosaic.inference import _stage_tiled_cuda
from demosaic.losses import reconstruction_loss
from demosaic.precision import amp_context, ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint
from prepare import DEST, ROOT
from projection import protected_projection
from train_regional import shared, trainable
import regional_objective as regional

CONTROLS = ("flat", "weak_absence", "continuing")
CORE = slice(80, 176)


def prepare_case(recipe, seed, prior):
    arrays, metadata = prior.observations(recipe["case"], recipe["index"], pair_draws=2, seed=seed)
    batch = {k: t.cuda() for k, t in arrays.items()}
    for k in ("packed", "variance", "target", "sensor_target"):
        batch[k] = batch[k].contiguous(memory_format=torch.channels_last)
    plant = metadata["geometry"]["wire"]
    bank = [
        (region, a.cuda() if a is not None else None, b.cuda() if b is not None else None)
        for region, a, b in regional.projections(plant)
    ]
    continuing = prior.gap_projection(plant, continuing=True).cuda()
    return batch, metadata, bank, continuing


def restore(model, case, prior):
    batch, metadata, _, _ = case
    camera = metadata["camera"]
    model.base.set_noise(camera["shot"], camera["read"])
    return model(*(batch[k] for k in prior.FORWARD_ARGS))


def directional_terms(prediction, case, bands):
    batch, _, bank, strong_basis = case
    weak, absence = regional.loss(prediction, batch, bank, bands.luminance)
    continuing = bands.continuing_wire_loss(prediction, batch, strong_basis)
    flat = prediction[4, :, CORE, CORE] - batch["sensor_target"][4, :, CORE, CORE]
    return weak, {"flat": flat.square().mean().add(1e-10).sqrt(),
                  "weak_absence": absence, "continuing": continuing}


def grad_parts(model, case, prior, bands, parameters, weights):
    batch, metadata, _, _ = case
    model.train()
    with amp_context("cuda", dtype="bfloat16"):
        prediction = restore(model, case, prior)
    assert prediction.dtype == torch.float32
    absolute, _ = reconstruction_loss(
        prediction, batch, auxiliary=mosaic(prediction, batch["colors"]),
        camera_supervision="sensor-valid-v1", reconstruction_charbonnier_epsilon=0.0003,
    )
    redraw, _ = bands.redraw_losses(prediction, batch)
    weak, terms = directional_terms(prediction, case, bands)
    shared_loss = absolute + weights["paired"] * redraw["mean"]
    if metadata["law"] == "independent":
        shared_loss = shared_loss + weights["repeat"] * redraw["repeat"]
    shared_loss = (shared_loss + weights["weak_absence"] * terms["weak_absence"]
                   + weights["strong_gap"] * terms["continuing"])
    full_loss = shared_loss + weights["regional_aligned"] * weak
    functions = (shared_loss, full_loss, *(terms[name] for name in CONTROLS))
    gradients = [
        torch.autograd.grad(value, parameters, retain_graph=i < len(functions) - 1)
        for i, value in enumerate(functions)
    ]
    return gradients[0], gradients[1], dict(zip(CONTROLS, gradients[2:], strict=True))


class AdamSnapshot:
    def __init__(self, saved):
        group, = saved["param_groups"]
        self.saved = saved
        self.group = group
        self.state = [saved["state"][i] for i in group["params"]]
        self.m = [s["exp_avg"].cuda() for s in self.state]
        self.v = [s["exp_avg_sq"].cuda() for s in self.state]
        self.step = [s["step"].cuda() for s in self.state]
        assert all(int(s["step"]) == 1024 for s in self.state)
        assert group["fused"] and not group["amsgrad"] and not group["maximize"]

    @torch.no_grad()
    def update(self, weights, grads, verify=False):
        assert len(weights) == len(grads) == len(self.state)
        norm = get_total_norm(grads, error_if_nonfinite=True)
        clipped = torch._foreach_mul(grads, (1.0 / (norm + 1e-6)).clamp(max=1.0))
        params = [p.detach().clone() for p in weights]
        first, second = [v.clone() for v in self.m], [v.clone() for v in self.v]
        step = [s.clone() for s in self.step]
        g = self.group
        adamw(params, clipped, first, second, [], step, fused=True, capturable=g["capturable"],
              differentiable=g["differentiable"], amsgrad=g["amsgrad"], beta1=g["betas"][0],
              beta2=g["betas"][1], lr=g["lr"], weight_decay=g["weight_decay"], eps=g["eps"],
              maximize=g["maximize"])
        if verify:
            shadow = [torch.nn.Parameter(p.detach().clone()) for p in weights]
            optimizer = torch.optim.AdamW(shadow, lr=g["lr"], fused=True)
            optimizer.load_state_dict(self.saved)
            for p, gradient in zip(shadow, grads, strict=True):
                p.grad = gradient.clone()
            clip_grad_norm_(shadow, 1.0, error_if_nonfinite=True)
            optimizer.step()
            for observed, expected in zip(params, shadow, strict=True):
                torch.testing.assert_close(observed, expected, rtol=0, atol=0)
            for i, item in enumerate(shadow):
                s = optimizer.state[item]
                for actual, k in ((first[i], "exp_avg"), (second[i], "exp_avg_sq"), (step[i], "step")):
                    torch.testing.assert_close(actual, s[k], rtol=0, atol=0)
        return params, float(norm)


def distance(first, second):
    return float(get_total_norm(torch._foreach_sub(first, second), error_if_nonfinite=True))


def dot(a, b):
    terms = [torch.dot(x.flatten(), y.flatten()) for x, y in zip(a, b, strict=True)]
    return float(torch.stack(terms).double().sum())


@torch.no_grad()
def limit_delta(common, full, protected):
    increment = torch._foreach_sub(full, common)
    length = float(get_total_norm(increment, error_if_nonfinite=True))
    labels = []
    unit_controls = []
    for name, gradient in protected.items():
        size = float(get_total_norm(gradient, error_if_nonfinite=True))
        if size > 0:
            labels.append(name)
            unit_controls.append(torch._foreach_mul(gradient, 1 / size))
    assert length > 0 and unit_controls
    direction = torch._foreach_mul(increment, 1 / length)
    gram = np.array([[dot(a, b) for b in unit_controls] for a in unit_controls])
    original = np.array([dot(g, direction) for g in unit_controls])
    coeff = protected_projection(gram, original)
    projected = list(direction)
    for value, control in zip(coeff, unit_controls, strict=True):
        if value > 0:
            torch._foreach_add_(projected, control, alpha=-float(value))
    assert max(dot(g, projected) for g in unit_controls) < 5e-7
    candidate = torch._foreach_add(common, projected, alpha=length)
    adjusted_length = distance(candidate, common)
    scale = min(1.0, adjusted_length / length)
    strength_control = torch._foreach_add(common, increment, alpha=scale)
    if abs(distance(strength_control, common) - adjusted_length) > .002 * length:
        lo, hi = 0., 1.
        for _ in range(12):
            scale = (lo + hi) / 2
            strength_control = torch._foreach_add(common, increment, alpha=scale)
            if distance(strength_control, common) < adjusted_length:
                lo = scale
            else:
                hi = scale
    effective = torch._foreach_mul(torch._foreach_sub(candidate, common), 1 / length)
    return candidate, strength_control, {
        "full_increment_L2": length,
        "projected_increment_L2": adjusted_length,
        "scaled_increment_L2": distance(strength_control, common),
        "scaled_control_fraction": scale,
        "original_normalized_slopes": dict(zip(labels, original.tolist(), strict=True)),
        "projected_normalized_slopes_after_FP32_rounding": {
            k: dot(g, effective) for k, g in zip(labels, unit_controls, strict=True)
        },
        "active_control_coefficients": dict(zip(labels, coeff.tolist(), strict=True)),
    }


def signed_weak_response(prediction, case, bands):
    batch, _, bank, _ = case
    clean = batch["sensor_target"][:4, :, CORE, CORE]
    value = prediction[:4, :, CORE, CORE]
    weights = (bands.luminance @ batch["matrix"][0]) * batch["wb"][0]
    luma = lambda x: (x * weights[None, :, None, None]).sum(1)
    source, expected = luma(value).double(), luma(clean).double()
    valid = ((clean >= 0) & (clean < .98)).all(dim=(0, 1))
    cross = energy = 0.
    for region, basis, _ in bank:
        if basis is None:
            continue
        inside = basis.abs().sum(1) > 0
        if not bool((valid[region].flatten() | ~inside).all()):
            continue
        axes = basis.double()

        def coefficient(tensor):
            v = tensor[(slice(None), *region)].flatten(1)
            return (v[0:4:2] - v[1:4:2]).mean(0) @ axes

        target = coefficient(expected)
        cross += float(coefficient(source) @ target)
        energy += float(target @ target)
    return 100 * cross / energy if energy > 1e-12 else None


@torch.no_grad()
def evaluate(model, states, params, cases, prior, bands):
    model.eval()
    book = {}
    for name, state in states.items():
        for p, value in zip(params, state, strict=True):
            p.copy_(value)
        rows = {}
        for label, case in cases.items():
            prediction = restore(model, case, prior)
            assert torch.isfinite(prediction).all()
            _, controls = directional_terms(prediction, case, bands)
            rows[label] = {
                "weak_response_pp": signed_weak_response(prediction, case, bands),
                **{f"{key}_DN16": float(value) * 65535 for key, value in controls.items()},
            }
        book[name] = rows
    return book


def audit(limit):
    manifest = reference(DEST / "plan.json")
    plan = read_json(checked(manifest))
    assert plan["probe_driver"] == reference(__file__)
    assert plan["projection_driver"] == reference(ROOT / "projection.py")
    frozen = read_json(checked(plan["original_plan"]))
    runtime = replace(RuntimePolicy(**frozen["runtime"]), cuda_quota_gib=17)
    runtime.resources(DEST)
    runtime.apply()
    checkpoint = plan["regional_checkpoint"]
    model, snapshot = load_scene_checkpoint(
        checked(checkpoint), weights="model", expected_sha256=checkpoint["sha256"],
    )
    _stage_tiled_cuda(model, torch.device("cuda:0"))
    params = tuple(trainable(model))
    adam = AdamSnapshot(snapshot["optimizer"])
    assert len(params) == 89
    original = [p.detach().clone() for p in params]
    prior = shared(frozen["shared_driver"])
    bands = prior.PairedBands("cuda", frozen["loss"]["bands"])
    rows = plan["paired_groups"] if limit is None else plan["paired_groups"][:limit]
    receipts = []
    started = time.monotonic()
    with exclusive_run(DEST), ieee_fp32():
        for row in rows:
            i = row["pair"]
            path = DEST / f"pair-{i:02d}.json"
            if path.is_file():
                before = read_json(path)
                assert before["plan"] == manifest and before["pair"] == i
            else:
                began = time.monotonic()
                cases = {key: prepare_case(row[key], plan["seed"], prior) for key in ("update", "reserve")}
                common_grad, full_grad, controls = grad_parts(
                    model, cases["update"], prior, bands, params, frozen["loss"],
                )
                common, common_norm = adam.update(params, common_grad, verify=i == 1)
                full, full_norm = adam.update(params, full_grad, verify=i == 1)
                projected, scaled, geometry = limit_delta(common, full, controls)
                del common_grad, full_grad, controls
                try:
                    metrics = evaluate(
                        model, {"original": original, "shared": common, "full": full,
                                "protected": projected, "dose_control": scaled},
                        params, cases, prior, bands,
                    )
                finally:
                    with torch.no_grad():
                        for p, value in zip(params, original, strict=True):
                            p.copy_(value)
                write_json(path, {
                    "plan": manifest, "pair": i,
                    "observations": {name: value[1] for name, value in cases.items()},
                    "common_gradient_norm": common_norm, "full_gradient_norm": full_norm,
                    "real_fused_adam_verified": i == 1,
                    "geometry": geometry, "metrics": metrics, "seconds": time.monotonic() - began,
                })
            receipts.append(reference(path))
            print(f"Measured AdamW shadow updates for {len(receipts)}/{len(rows)} source pairs", flush=True)
        if limit is None:
            write_json(DEST / "result.json", {
                "plan": manifest, "scope": "Independent one-step replays of the same raw/AdamW state.",
                "checkpoint": checkpoint, "weights": "raw model", "optimizer_lr": adam.group["lr"],
                "parameter_tensors": len(params), "pairs": receipts,
                "wall_seconds": time.monotonic() - started,
            })


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--limit", type=int)
    flags = p.parse_args()
    audit(flags.limit)
