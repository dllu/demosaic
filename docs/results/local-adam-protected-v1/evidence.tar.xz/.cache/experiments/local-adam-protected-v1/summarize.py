"""Compare finite protected, unprotected and norm-matched shadow updates."""

from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path("/mnt/external/demosaic/local-adam-protected-v1")
MODES = (("full", "shared"), ("protected", "full"), ("protected", "dose_control"))
FIELDS = ("weak_response_pp", "flat_DN16", "weak_absence_DN16", "continuing_DN16")
CONTROLS = ("flat", "weak_absence", "continuing")


def summarize(values, seed):
    vector = np.asarray(values, dtype=np.float64)
    assert len(vector) > 0 and np.isfinite(vector).all()
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(vector), (8000, len(vector)))
    without_each = (vector.sum() - vector) / (len(vector) - 1) if len(vector) > 1 else vector
    return {
        "n": len(vector), "mean": float(vector.mean()),
        "q10_median_q90": np.quantile(vector, (.1,.5,.9)).tolist(),
        "95_percent": np.quantile(vector[draws].mean(1), (.025,.975)).tolist(),
        "positive": int((vector > 0).sum()), "negative": int((vector < 0).sum()),
        "leave_one_out_mean_range": [float(without_each.min()), float(without_each.max())],
    }


def paired(rows, field, split, first, second):
    data = []
    for row in rows:
        results = row["metrics"]
        a, b = (results[key][split][field] for key in (first, second))
        if a is not None and b is not None:
            data.append(a - b)
    return data


def main():
    binding = reference(ROOT / "result.json")
    result = read_json(checked(binding))
    plan = read_json(checked(result["plan"]))
    rows = [read_json(checked(r)) for r in result["pairs"]]
    assert len(rows) == len(plan["paired_groups"]) == 32
    assert len({r["observations"][role]["source_id"] for r in rows for role in ("update","reserve")}) == 64
    assert set(result["checkpoint"]) >= {"path","sha256"}
    checked(result["checkpoint"])
    assert sum(r["real_fused_adam_verified"] for r in rows) == 1
    for row, expected in zip(rows, plan["paired_groups"], strict=True):
        assert row["plan"] == result["plan"] and row["pair"] == expected["pair"]
        for label in ("update", "reserve"):
            example = row["observations"][label]
            wanted = expected[label]["case"]
            assert example["index"] == expected[label]["index"]
            assert example["source_id"] == wanted["source"]["id"]
            assert example["cache_sha256"] == wanted["source"]["cache_sha256"]
            assert example["iso"] == wanted["iso"] and example["law"] == wanted["law"]
            assert example["camera"]["pattern"] == wanted["pattern"]
            assert example["geometry"]["wire"]["strong_continues"] == wanted["strong_continues"]

    populations = {"all": rows}
    for iso in ("ISO400", "ISO6400"):
        group = [r for r in rows if r["observations"]["update"]["iso"] == iso]
        populations[iso] = group
        assert len(group) == 16
        for continues in (True, False):
            key = f"{iso}-{'continuing' if continues else 'double-gap'}"
            populations[key] = [
                r for r in group if r["observations"]["update"]["geometry"]["wire"]["strong_continues"] == continues
            ]
            assert len(populations[key]) == 8
    for law in ("coupled", "independent"):
        group = [r for r in rows if r["observations"]["update"]["law"] == law]
        assert len(group) == 16
        populations[law] = group
    by_weak_strength = sorted(
        rows, key=lambda r: r["observations"]["reserve"]["geometry"]["wire"]["strengths"][1],
    )
    populations["lower_reserve_weak_amplitude"] = by_weak_strength[:16]
    populations["upper_reserve_weak_amplitude"] = by_weak_strength[16:]

    results = {}
    for group, cases in populations.items():
        results[group] = {}
        for split in ("update", "reserve"):
            results[group][split] = {}
            for first, last in MODES:
                results[group][split][f"{first}-minus-{last}"] = sections = {}
                for i, measure in enumerate(FIELDS):
                    differences = paired(cases, measure, split, first, last)
                    sections[measure] = summarize(differences, 202611192319 + i)

    geometry = [r["geometry"] for r in rows]
    original_slopes = [x["original_normalized_slopes"] for x in geometry]
    projected_slopes = [x["projected_normalized_slopes_after_FP32_rounding"] for x in geometry]
    adjusted = [x["projected_increment_L2"] / x["full_increment_L2"] for x in geometry]
    dose_errors = [
        (x["scaled_increment_L2"] - x["projected_increment_L2"]) / x["full_increment_L2"]
        for x in geometry
    ]
    assert max(abs(x) for x in dose_errors) < .006
    write_json(ROOT / "summary.json", {
        "driver": reference(__file__), "result": binding, "strata": results,
        "geometry": {
            "active_projection_cases": sum(any(v > 1e-8 for v in item.values()) for item in original_slopes),
            "full_step_norms": summarize([x["full_increment_L2"] for x in geometry], 202611192320),
            "remaining_norm_fraction": summarize(adjusted, 202611192320),
            "norm_control_difference_per_full_norm_maximum_absolute": max(abs(x) for x in dose_errors),
            "slopes": {place: {
                k: summarize([z[k] for z in cases if k in z], 202611192320) for k in CONTROLS
            } for place, cases in (("full", original_slopes), ("projected", projected_slopes))},
            "projected_positive_larger_than_0_005": {
                k: sum(case.get(k, 0) > .005 for case in projected_slopes) for k in CONTROLS
            },
        },
    })


if __name__ == "__main__":
    main()
