"""Closest feasible correction when only a few directional constraints are active."""

from itertools import combinations
import numpy as np


def protected_projection(gram, slopes):
    """Solve the correction coefficients for inequalities slopes - Gram @ coeff <= 0."""
    gram = np.asarray(gram, dtype=np.float64)
    slopes = np.asarray(slopes, dtype=np.float64)
    count = len(slopes)
    if gram.shape != (count, count) or not np.isfinite(gram).all() or not np.isfinite(slopes).all():
        raise ValueError("Expected a finite square control Gram matrix and matching slopes")
    if not count or max(slopes) <= 0:
        return np.zeros(count)
    # Inputs are normalized by the control norms and proposed step norm.
    # There are at most three inequalities, so we can test every active set.
    tolerance = 1e-10
    best = None
    cost = np.inf
    for size in range(1, count + 1):
        for subset in combinations(range(count), size):
            indices = list(subset)
            local = gram[np.ix_(indices, indices)]
            solve = np.linalg.lstsq(local, slopes[indices], rcond=1e-11)[0]
            if (solve < -tolerance).any():
                continue
            coeff = np.zeros(count)
            coeff[indices] = solve.clip(min=0)
            residual = slopes - gram @ coeff
            if (residual > tolerance).any() or (np.abs(residual[indices]) > tolerance).any():
                continue
            distance = float(coeff @ gram @ coeff)
            if distance < cost:
                cost, best = distance, coeff
    if best is None:
        raise ValueError("No verified active-set solution")
    return best
