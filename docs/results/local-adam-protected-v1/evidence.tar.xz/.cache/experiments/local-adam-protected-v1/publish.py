"""Archive each verified fresh source pair and the finite AdamW diagnostic."""

from hashlib import sha256
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from plot import save_figure
from summarize import ROOT as DATA

RECIPE = Path(__file__).resolve().parent
REPO = RECIPE.parents[2]


def main():
    result_ref, summary_ref = (reference(DATA / name) for name in ("result.json", "summary.json"))
    result, summary = [read_json(checked(ref)) for ref in (result_ref, summary_ref)]
    assert summary["result"] == result_ref
    assert len(result["pairs"]) == 32
    plan = read_json(checked(result["plan"]))
    prior = reference(REPO / "docs/results/local-regional-wire-v1/review-1024.json")
    trained = read_json(checked(prior))
    assert plan["completion"] == trained["training"]
    assert trained["checkpoints"]["regional-aligned"] == result["checkpoint"] == plan["regional_checkpoint"]
    image_dir = REPO / "docs/images" / RECIPE.name
    image_dir.mkdir(parents=True)
    graph = image_dir / "finite-step-effects.png"
    save_figure(summary, graph)
    output = REPO / "docs/results" / RECIPE.name
    output.mkdir(parents=True, exist_ok=True)
    launch_ref = reference(output / "launch.json")
    launch = read_json(checked(launch_ref))
    assert launch["run_plan"] == result["plan"]
    assert result["pairs"][:launch["verified_prefix_pairs"]] == launch["prefix"]
    archive = output / "evidence.tar.xz"
    items = [result_ref, summary_ref, result["plan"], launch_ref, *result["pairs"], summary["driver"],
             *(plan[k] for k in ("driver", "probe_driver", "projection_driver")),
             reference(RECIPE / "plot.py"), reference(__file__)]
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as bundle:
        for item in items:
            path = checked(item)
            key = (path.relative_to(REPO) if path.is_relative_to(REPO)
                   else Path("external") / path.relative_to("/mnt/external/demosaic")).as_posix()
            assert key not in members
            bundle.add(path, arcname=key)
            members[key] = item["sha256"]
    with tarfile.open(archive) as bundle:
        assert set(bundle.getnames()) == set(members)
        for name, wanted in members.items():
            assert sha256(bundle.extractfile(name).read()).hexdigest() == wanted
    write_json(output / "publication.json", {
        "scope": "Matched finite shadow steps from one fixed raw AdamW checkpoint.",
        "regional_parent": prior, "launch": launch_ref,
        "result": result_ref, "summary": summary_ref, "checkpoint": result["checkpoint"],
        "weights": result["weights"], "optimizer_lr": result["optimizer_lr"], "source_pairs": len(result["pairs"]),
        "strata": summary["strata"], "geometry": summary["geometry"], "wall_seconds": result["wall_seconds"],
        "plot": reference(graph), "archive": reference(archive), "members": members,
    })


if __name__ == "__main__":
    main()
