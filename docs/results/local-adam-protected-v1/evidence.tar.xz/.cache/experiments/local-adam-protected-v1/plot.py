"""Plot finite output effects at the same realized parameter-update strength."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def save_figure(summary, output):
    fields = (
        ("weak_response_pp", "Signed weak response", "Percentage points"),
        ("flat_DN16", "Exact-flat error", "DN16 RGB RMS"),
        ("weak_absence_DN16", "Absent weak direction", "DN16 robust error"),
        ("continuing_DN16", "Strong direction in the gap", "DN16 robust error"),
    )
    section = summary["strata"]["all"]
    fig, axes = plt.subplots(2, 2, figsize=(8.8, 4.6), layout="constrained")
    fig.suptitle("Protected AdamW update minus its norm-matched control")
    for axis, (key, title, units) in zip(axes.flat, fields, strict=True):
        data = [section[label]["protected-minus-dose_control"][key] for label in ("update", "reserve")]
        values = np.asarray([d["mean"] for d in data])
        bottom, top = np.asarray([d["95_percent"] for d in data]).T
        axis.axvline(0, color=".6", linewidth=1)
        axis.errorbar(values, (0, 1), xerr=(values - bottom, top - values),
                      fmt="o", color="#2c6c72", markersize=4, capsize=3)
        axis.set_yticks((0, 1), ("Update photo", "Separate photo"))
        axis.set_ylim(1.45, -.45)
        axis.set_title(title)
        axis.set_xlabel(units)
        axis.grid(axis="x", alpha=.20)
    fig.savefig(Path(output), dpi=155, facecolor="white")
