"""Bind distinct approved photos for an AdamW counterfactual probe."""

from itertools import product
from pathlib import Path
import random
import sys

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name("local-regional-wire-v1")))
from train_regional import ARCHIVE as TRAIN, CACHE, PROTECTED, REPO, PRIOR_TRIALS, scene_rows

DEST = TRAIN.parent / ROOT.name
SEED = 202611192316


def main():
    completion = reference(TRAIN / "train/completed.json")
    training = read_json(checked(completion))
    assert training["completed_schedule"] and training["step"] == 1024 and training["DINO_unchanged"]
    plan = read_json(checked(training["plan"]))
    review = read_json(checked(plan["review_inputs"]))
    parent_plan = reference(CACHE / "scene-full-epoch-v1/plan.json")
    corpus = read_json(checked(parent_plan))
    transfer = read_json(checked(review["transfer"]))
    excluded = [r["source"] for r in transfer["rows"]]
    excluded += [r["source"]["source"] for rows in review["exact"].values() for r in rows]
    excluded += list(scene_rows(corpus["development_manifest"]))
    schedules = [*plan["schedule"].values(), *[
        reference(CACHE / name / filename)
        for name in PRIOR_TRIALS
        for filename in ("schedule.json", "qualification-schedule.json", "qualification_schedule.json")
        if (CACHE / name / filename).is_file()
    ]]
    for source in schedules:
        excluded += [r["source"] for r in read_json(checked(source))]
    blocked = {r[k] for r in excluded for k in ("id", "cache_sha256")}
    configs = [reference(REPO / "configs" / filename) for filename in PROTECTED]
    for folder in (REPO / ".cache/gfx-qualitative-20231231", REPO / ".cache/gfx-green-mesh-20231231"):
        blocked.update(p.stem.split("_")[-1].split("-")[0] for p in folder.glob("*_DSCF*"))
    approved = list(scene_rows(corpus["train_manifest"]))
    assert len(approved) == 90692 and all(r["split"] == "train" for r in approved)
    rng = random.Random(SEED)
    rng.shuffle(approved)
    rows = []
    cells = list(product(("ISO400", "ISO6400"), ("RGGB", "BGGR", "GRBG", "GBRG"),
                         ("coupled", "independent"), (True, False)))
    rng.shuffle(cells)
    source_iter = iter(approved)
    for i, (iso, pattern, law, continues) in enumerate(cells, 1):
        matched = {"kind": "wire", "iso": iso, "pattern": pattern,
                   "law": law, "strong_continues": continues}
        group = {"pair": i}
        for j, name in enumerate(("update", "reserve")):
            photo = next(row for row in source_iter if (
                row["id"] not in blocked and row["cache_sha256"] not in blocked
                and row["dtype"] == "uint16" and min(row["shape"][:2]) >= 256
            ))
            assert Path(photo["cache"]).is_relative_to("/mnt/external/demosaic")
            assert Path(photo["cache"]).parts[4].startswith("commons-")
            blocked.update((photo["id"], photo["cache_sha256"]))
            group[name] = {"index": 2 * i + j, "case": matched | {"source": photo}}
        rows.append(group)
    assert len(rows) == 32
    DEST.mkdir(exist_ok=False)
    write_json(DEST / "plan.json", {
        "driver": reference(__file__), "probe_driver": reference(ROOT / "audit.py"),
        "projection_driver": reference(ROOT / "projection.py"),
        "completion": completion, "regional_checkpoint": training["checkpoints"]["regional-aligned"],
        "original_plan": training["plan"], "corpus_plan": parent_plan,
        "approved_manifest": corpus["train_manifest"], "exclusions": schedules + configs,
        "seed": SEED, "paired_groups": rows,
    })


if __name__ == "__main__":
    main()
