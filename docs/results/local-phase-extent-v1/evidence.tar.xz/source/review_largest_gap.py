"""Render the largest new source-level reduction in true-gap texture."""

from pathlib import Path
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_extent import OUT
from review_extent import exact


def main():
    torch.set_num_threads(2)
    selection = reference(OUT / 'calibration.json')
    dest = OUT / 'boards/largest-gap'
    dest.mkdir(exist_ok=True)
    board = exact(read_json(checked(selection))['policy'], dest, ('phase-extent-14',), 'fresh')
    write_json(OUT / 'board-largest-gap.json', {'driver': reference(Path(__file__)), 'calibration': selection, 'data': board})


if __name__ == '__main__':
    main()
