"""Lock wider supporting phase on calibration and replay two fixed held panels."""

from pathlib import Path
import sys
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import phase_extent as model
from phase_extent import OUT
import replay_exterior_support as template
from conditional import replay


def main(name):
    torch.set_num_threads(2)
    start = monotonic()
    template.model = model
    replay.comparisons = template.assess
    replay.OUT = OUT
    evidence = {'driver': reference(Path(__file__)), 'operator': reference(model.__file__)}
    if name == 'calibration':
        source, rows = replay.load_calibration()
        policy = template.select(rows)
        write_json(OUT / 'calibration.json', evidence | {'source': source, 'rows': rows, 'policy': policy, 'seconds': monotonic()-start})
        return
    sources = {'previous': 'local-conditional-posterior-v1/fresh', 'held': 'local-weak-support-v1/fresh',
               'fresh': 'local-phase-extent-v1/fresh'}
    replay.PREVIOUS = OUT.parent / sources[name]
    calibration = reference(OUT / 'calibration.json')
    assert read_json(checked(calibration))['operator'] == evidence['operator']
    source, plan, rows = replay.load_confirmation()
    write_json(OUT / f'{name}.json', evidence | {'source': source, 'plan': plan, 'rows': rows, 'calibration': calibration, 'seconds': monotonic()-start})


if __name__ == '__main__':
    main(sys.argv[1])
