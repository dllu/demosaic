"""Check support footprint, color-affinity effect and frozen donor measurements."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from phase_extent import OUT, donor_phase, field, measurements

PREVIOUS = OUT.parent / 'local-weak-support-v1/fresh'
ROI = (176, 176, 160, 160)
HALO = 48


def main():
    catalog = reference(PREVIOUS / 'inputs.json')
    rows = read_json(checked(catalog))['observations'][:4]
    plan = read_json(checked(read_json(checked(catalog))['plan']))
    noise = {k: plan['noise'][k] for k in ('shot', 'read')}
    entries = {}
    for row, fixture in zip(rows, plan['sources'], strict=False):
        source = row['streams'][0]['data']
        with np.load(checked(source), allow_pickle=False) as file:
            scene, colors = file['scene_packed'].copy(), file['colors']
            scene[:, 64:192, 64:192] = file['packed'][0]
        x, y, width, h = ROI
        whole = np.s_[..., (y-HALO)//2:(y+h+HALO)//2, (x-HALO)//2:(x+width+HALO)//2]
        change = scene.copy()
        change[whole] += .02
        frequency = _spacing(scene, colors, x, y, clearance=HALO)
        assert frequency is not None
        np.testing.assert_array_equal(frequency, _spacing(change, colors, x, y, clearance=HALO))
        measurements_before = donor_phase(scene, colors, ROI, frequency, 1, **noise, clearance=HALO)
        measurements_after = donor_phase(change, colors, ROI, frequency, 1, **noise, clearance=HALO)
        for a, b in zip(measurements_before, measurements_after, strict=True):
            np.testing.assert_array_equal(a, b)
        phase = measurements_before[0]
        assert phase is not None
        altered = scene.copy()
        rec = np.s_[..., y//2-12:y//2, x//2:(x+width)//2]
        generator = np.random.default_rng(6460)
        altered[rec] += generator.normal(0, .025, altered[rec].shape)
        before = measurements(scene, ROI, frequency, 1, **noise, phases=phase, halo=HALO)
        after = measurements(altered, ROI, frequency, 1, **noise, phases=phase, halo=HALO)
        np.testing.assert_array_equal(field(*before, HALO, 'local'), field(*after, HALO, 'local'))
        np.testing.assert_array_equal(field(*before, HALO, 'near'), field(*after, HALO, 'near'))
        difference = np.max(np.abs(field(*before, HALO, 'wide') - field(*after, HALO, 'wide')))
        mom, energy, guide, side = before
        precise_guide = guide.copy()
        precise_guide[::side] *= 2.
        affinity = np.max(np.abs(field(mom, energy, guide, side, HALO, 'guided') -
                                 field(mom, energy, precise_guide, side, HALO, 'guided')))
        assert difference > 0 and affinity > 0
        entries[fixture['camera']['pattern']] = {
            'input': source, 'extent_samples_altered': int(scene[whole].size),
            'max_wide_score_change_from_halo_only': float(difference),
            'max_guided_score_change_from_guide_only': float(affinity),
        }
    assert len(entries) == 4
    write_json(OUT / 'audit.json', {'driver': reference(Path(__file__)), 'source': catalog, 'layouts': entries})


if __name__ == '__main__':
    main()
