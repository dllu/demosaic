"""Measure a fixed exterior phase on a wider RAW support field."""

from functools import lru_cache
from itertools import product
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import map_coordinates

from demosaic.mesh_carrier_fit import _DONOR, _ROI_SIZE, _sites

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic') / HERE.name
PREVIOUS = HERE.with_name('local-weak-support-v1')
sys.path.insert(0, str(PREVIOUS))
import weak_exterior_support as previous

NAMES = ('local', 'near', 'wide', 'guided', 'opposite')
METHODS = NAMES
CUTOFFS = (-.5, .5, 1.5, 2.5)
OPTIONS = tuple((name, 'score', cutoff, f'{name}_{cutoff:+g}') for name, cutoff in product(NAMES, CUTOFFS))
ARMS = ('combined', 'weak', *(key for _, _, _, key in OPTIONS))
SITES = tuple(np.ndindex(2, 2))
CELL = 16


@lru_cache(maxsize=8)
def smooth(size):
    y, x = (np.indices((size, size), dtype='d') - (size - 1) / 2) / size
    return np.stack((np.ones_like(x), x, y, x*x, x*y, y*y), axis=-1)


def carrier(size, dx, dy, frequencies):
    y, x = np.indices((size, size), dtype='d')
    phase = 2 * np.pi * ((x + dx)[..., None] * frequencies[:, 0] + (y + dy)[..., None] * frequencies[:, 1])
    return np.stack((np.cos(phase), np.sin(phase)), axis=-1).reshape(size, size, 4)


def sites_at(scene, x, y, size, site):
    values = _sites(scene, x, y, size, *site)
    if values.shape != (size // 2, size // 2) or not np.isfinite(values).all():
        raise ValueError('The exterior and support field require complete finite Bayer sites')
    return values


def donor_boxes(roi, clearance):
    x, y, w, _ = roi
    return ((x - _DONOR - clearance, y + CELL), (x + w + clearance, y + CELL),
            (x + CELL, y - _DONOR - clearance), (x + CELL, y + w + clearance))


def donor_phase(scene, colors, roi, freq, weak, shot, read, clearance):
    """Fix the phase in each CFA channel using disjoint exterior patches."""
    x, y = roi[:2]
    vectors, inv_var = [], []
    for px, py in donor_boxes(roi, clearance):
        wave = carrier(_DONOR, px - x, py - y, freq)
        coeff, precision = [], []
        for r, c in SITES:
            samples = sites_at(scene, px, py, _DONOR, (r, c)).ravel()
            design = np.concatenate((smooth(_DONOR), wave), axis=-1)[r::2, c::2].reshape(samples.size, -1)
            transfer = np.linalg.pinv(design, rcond=1e-8)[6+weak*2:8+weak*2]
            coeff.append(transfer @ samples)
            var = max(2e-11, shot * max(0, samples.mean()) + read)
            precision.append(1 / (var * np.square(transfer).sum(axis=1).mean()))
        vectors.append(coeff)
        inv_var.append(precision)
    estimates, weights = np.asarray(vectors), np.asarray(inv_var)
    location = np.einsum('dci,dc->ci', estimates, weights) / weights.sum(axis=0)[:, None]
    norm = np.linalg.norm(location, axis=-1)
    radii = np.linalg.norm(estimates, axis=-1)
    coherence = norm / np.maximum(1e-12, (radii * weights).sum(axis=0) / weights.sum(axis=0))
    strength = norm**2 * weights.sum(axis=0)
    good = (coherence >= .65) & (strength >= 16)
    green = [colors[2*((y+r)%2)+(x+c)%2] == 1 for r,c in SITES]
    if not good[np.asarray(green)].all():
        return None, coherence, strength
    location *= good[:, None]
    return location, coherence, strength


def blocks(image, side):
    step = CELL // 2
    return image.reshape(side, step, side, step, *image.shape[2:]).swapaxes(1, 2).reshape(side*side, step*step, *image.shape[2:])


def measurements(scene, roi, freq, weak, shot, read, phases, halo, *, quadrature=False):
    """Local linear evidence for a fixed waveform after removing smooth/strong terms."""
    x, y, w, h = roi
    assert w == h == _ROI_SIZE
    size = w + 2 * halo
    side = size // CELL
    wave = carrier(size, -halo, -halo, freq).reshape(size, size, 2, 2)
    moment, energy, means = [], [], []
    for (r, c), phase in zip(SITES, phases, strict=True):
        values = blocks(sites_at(scene, x-halo, y-halo, size, (r,c)), side).astype('d')
        mean = values.mean(axis=1)
        means.append(mean)
        b = np.broadcast_to(smooth(CELL)[r::2, c::2].reshape(1, values.shape[1], 6), (*values.shape, 6))
        strong = blocks(wave[r::2, c::2, 1-weak], side)
        nuisance = np.concatenate((b, strong), axis=-1)
        shape = blocks(wave[r::2, c::2, weak], side)
        if quadrature:
            phase = np.asarray((-phase[1], phase[0]))
        template = shape @ phase
        removed = np.einsum('npi,ni->np', nuisance, (np.linalg.pinv(nuisance, rcond=1e-8) @ template[..., None])[..., 0])
        template -= removed
        var = np.maximum(2e-11, shot * np.maximum(0, mean) + read)
        moment.append(np.einsum('np,np->n', template, values) / var)
        energy.append(np.einsum('np,np->n', template, template) / var)
    return np.sum(moment, axis=0), np.sum(energy, axis=0), np.stack(means, axis=-1), side


@lru_cache(maxsize=4)
def positions(side, halo):
    grid = (np.indices((side, side)).reshape(2, -1).T + .5) * CELL - halo
    center = (grid >= 0).all(axis=1) & (grid < _ROI_SIZE).all(axis=1)
    dr2 = np.square((grid[center, None] - grid[None,:]) / CELL).sum(axis=2)
    pixel = (np.indices((_ROI_SIZE, _ROI_SIZE), dtype='d') + .5) / CELL - .5
    return center, dr2, pixel


def field(moment, precision, guide, side, halo, method):
    center, dr2, pixel = positions(side, halo)
    if method in ('local', 'opposite'):
        value = moment[center] / np.sqrt(np.maximum(1e-10, precision[center]))
    else:
        radius = .8 if method == 'near' else 1.55
        weight = np.exp(-.5 * dr2 / radius**2)
        if method == 'near':
            weight[:, ~center] = 0
        if method == 'guided':
            color = np.log(np.clip(guide, .005, None))
            dc = np.square(color[center, None] - color[None,:]).mean(axis=-1)
            weight *= np.exp(-.5 * dc / .075**2)
        value = weight @ moment / np.sqrt(np.maximum(1e-10, weight**2 @ precision))
    scale = _ROI_SIZE // CELL
    return map_coordinates(value.reshape(scale, scale), pixel, order=1, mode='nearest', prefilter=False)


def qualify(parent, local, scene, colors, roi, freq, profile, wb, matrix, *, clearance=48):
    original, flags = previous.qualify(parent, local, scene, colors, roi, freq, profile, wb, matrix, clearance=clearance)
    combined, weak = original['combined'], original['weak']
    arms = dict.fromkeys(ARMS, weak) | {'combined': combined}
    if not flags.get('selected'):
        return arms, {'weak': flags['weak'], 'selected': []}
    direction = flags['weak']
    shot, read = profile['shot'], profile['read']
    consensus, coherence, support = donor_phase(scene, colors, roi, freq, direction, shot, read, clearance)
    audit = {'weak': direction, 'selected': flags['selected'], 'coherence': coherence.tolist(),
             'exterior_SNR_squared': support.tolist(), 'phase_eligible': consensus is not None}
    if consensus is None:
        return arms, audit
    # Keep all scored stations outside the donor windows. The standing RAW crop has a 16px halo.
    halo = min(48, clearance)
    mom, power, guide, side = measurements(scene, roi, freq, direction, shot, read, consensus, halo)
    other, other_power, _, _ = measurements(scene, roi, freq, direction, shot, read, consensus, halo, quadrature=True)
    fields = {k: field(mom, power, guide, side, halo, k) for k in NAMES if k != 'opposite'}
    fields['opposite'] = field(other, other_power, guide, side, halo, 'opposite')
    change = weak.astype('d') - combined
    for method, _, cut, name in OPTIONS:
        scale = np.clip(1 + (fields[method] - cut) / 2, 0, 1)
        arms[name] = (combined + scale * change).astype(weak.dtype)
    audit['field_statistics'] = {name: np.quantile(z, (0, .25, .5, .75, 1)).tolist() for name,z in fields.items()}
    return arms, audit
