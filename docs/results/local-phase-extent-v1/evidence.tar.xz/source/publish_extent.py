"""Publish the verified crop API, held comparisons and native evidence."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_extent import HERE, OUT

ROOT = Path.cwd()
ASSETS = ROOT / 'docs/assets' / HERE.name
RESULTS = ROOT / 'docs/results' / HERE.name
BOARDS = ('camera', 'exact', 'outlier', 'largest-gap')
RECEIPTS = (
    'calibration.json', 'previous.json', 'held.json', 'fresh.json',
    'fresh/plan.json', 'fresh/inputs.json', 'fresh/parent/result.json',
    'audit.json', 'api-proof.json', 'summary.json', 'gap-diagnostic.json',
    *(f'board-{group}.json' for group in BOARDS),
)


def published(path):
    return reference(path) | {'path': str(path.relative_to(ROOT))}


def publish_image(binding):
    src = checked(binding)
    target = ASSETS / src.name
    shutil.copyfile(src, target)
    link = published(target)
    assert link['sha256'] == binding['sha256']
    return link


def publish_board(board):
    link = publish_image(board['image'])
    with Image.open(ROOT / link['path']) as img:
        for p in board['panels']:
            x, y, w, h = p['png_xywh']
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= img.width and 0 <= y < y + h <= img.height
    return board | {'image': link}


def main():
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    refs = {key: reference(OUT / key) for key in RECEIPTS}
    data = {key: read_json(checked(value)) for key, value in refs.items()}
    for item in data.values():
        for key in ('driver', 'operator'):
            if key in item:
                checked(item[key])
    for group in BOARDS:
        assert data[f'board-{group}.json']['calibration'] == refs['calibration.json']
    for group, source in (('exact', 'fresh'), ('outlier', 'previous'), ('largest-gap', 'fresh')):
        assert data[f'board-{group}.json']['data']['receipt'] == refs[f'{source}.json']
    assert data['fresh.json']['plan'] == refs['fresh/plan.json']
    assert data['fresh.json']['source'] == refs['fresh/parent/result.json']
    assert data['fresh/parent/result.json']['inputs'] == refs['fresh/inputs.json']
    assert data['fresh/inputs.json']['plan'] == refs['fresh/plan.json']
    assert data['gap-diagnostic.json']['source'] == refs['summary.json']
    api = data['api-proof.json']
    assert api['source'] == refs['fresh.json'] and api['maximum_guard_difference_DN16'] < .002
    assert len(api['synthetic']) == 64 and len(api['camera']) == 8
    for r in data['fresh/parent/result.json']['records']:
        for stream in r['streams']:
            checked(stream['data'])
            for output in stream['outputs'].values():
                checked(output)
    evidence = {f'receipts/{name}': binding for name, binding in refs.items()}
    evidence.update({f'source/{p.name}': reference(p) for p in sorted(HERE.glob('*.py'))})
    evidence.update(api['implementation'])
    evidence['tests/test_mesh_carrier_fit.py'] = reference(ROOT / 'tests/test_mesh_carrier_fit.py')
    archive = RESULTS / 'evidence.tar.xz'
    with tarfile.open(archive, 'x:xz') as tar:
        for name, binding in evidence.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == evidence.keys()
        for name, binding in evidence.items():
            with tar.extractfile(name) as source:
                assert hashlib.file_digest(source, 'sha256').hexdigest() == binding['sha256']
    native = ASSETS / 'manifest.json'
    camera = [r | {'native': [publish_board(b) for b in r['native']]}
              for r in data['board-camera.json']['data']['rows']]
    exact = {group: [r | {'board': publish_board(r['board']), 'triplet': publish_board(r['triplet'])}
                     for r in data[f'board-{group}.json']['data']['boards']] for group in BOARDS[1:]}
    write_json(native, {'camera': camera, 'synthetic': exact,
                        'plot': publish_image(data['gap-diagnostic.json']['image'])})
    summary = RESULTS / 'summary.json'
    shutil.copyfile(checked(refs['summary.json']), summary)
    prior = ROOT / 'docs/results/local-weak-support-v1/publication.json'
    write_json(RESULTS / 'publication.json', {
        'parent_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'summary': published(summary), 'native_manifest': published(native), 'archive': published(archive),
        'prior_publication': published(prior), 'original_receipts': refs, 'archive_members': evidence,
        'standing_native_boards_viewed': sum(len(r['native']) for r in camera),
        'native_triplets_viewed': sum(map(len, exact.values())), 'new_weights': None,
    })


if __name__ == '__main__':
    main()
