"""Compare the public crop API to the locked research arm."""

from pathlib import Path
from statistics import median
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers, _spacing
from phase_extent import OUT
from conditional import replay
from review_extent import arms
from review_presence import FIXED, section


def verify(parent, local, scene, colors, roi, noise, wb, matrix, policy):
    x, y, w, h = local
    p = section(parent, *local)
    ctx = parent[:, y-16:y+h+16, x-16:x+w+16]
    clearance = 16 if local == roi else 48
    frequency = _spacing(scene, colors, *roi[:2], clearance=clearance)
    study, _ = arms(parent, local, scene, colors, roi, frequency, noise, wb, matrix, policy)
    args = dict(shot=noise['shot'], read=noise['read'], white_balance=wb, camera_to_srgb=matrix,
                parent_context=ctx, donor_clearance=clearance)
    start = monotonic()
    actual = refine_raw_mesh_carriers(p, scene, colors, roi, method='weak-phase-guard', **args)
    guarded = monotonic() - start
    start = monotonic()
    unguarded = refine_raw_mesh_carriers(p, scene, colors, roi, method='weak-posterior', **args)
    base = monotonic() - start
    delta = abs(actual.astype('d') - study['local']) * 65535
    unguarded_delta = abs(unguarded.astype('d') - study['weak']) * 65535
    assert delta.max() < .01 and unguarded_delta.max() < .01, (float(delta.max()), float(unguarded_delta.max()))
    return {'maximum_guard_difference_DN16': float(delta.max()),
            'maximum_base_difference_DN16': float(unguarded_delta.max()),
            'guard_seconds': guarded, 'base_seconds': base}


def main():
    torch.set_num_threads(2)
    source = reference(OUT / 'fresh.json')
    data = read_json(checked(source))
    plan = read_json(checked(data['plan']))
    policy = read_json(checked(data['calibration']))['policy']
    x, y, width, height = plan['query']
    roi = (x + replay.ROI[0], y + replay.ROI[1], *replay.ROI[2:])
    exact = []
    for row in data['rows']:
        for draw in row['draws']:
            sample = replay.arrays(draw['input'])
            parents = np.load(checked(draw['outputs']['local50k']), allow_pickle=False)
            scene = sample['scene_packed'].copy()
            obs = []
            for p, raw in zip(parents, sample['packed'], strict=True):
                scene[:, y//2:(y+height)//2, x//2:(x+width)//2] = raw
                item = verify(p, replay.ROI, scene, sample['colors'], roi, plan['noise'], sample['wb'], sample['matrix'], policy)
                obs.append(item)
            exact.append({'source_id': row['id'], 'draw': draw['draw'], 'observations': obs})
        if len(exact) % 16 == 0:
            print('Compared paired draws', len(exact), flush=True)
    camera = []
    for row in read_json(FIXED)['standing']:
        data = replay.arrays(row['input'])
        roi = tuple(row['local_ROI'])
        parent = np.load(checked(row['predictions']['local50k']), allow_pickle=False)[0]
        item = verify(parent, roi, data['packed'][0], data['colors'][0], roi, row['noise'], data['wb'][0], data['matrix'][0], policy)
        camera.append({'source_id': row['id'], 'observation': item})
    values = [v for item in exact for v in item['observations']]
    both = [*values, *(v['observation'] for v in camera)]
    write_json(OUT / 'api-proof.json', {
        'driver': reference(Path(__file__)), 'source': source, 'standing': reference(FIXED),
        'implementation': {p: reference(p) for p in ('src/demosaic/mesh_carrier_fit.py', 'src/demosaic/_mesh_weak_phase.py', 'src/demosaic/_mesh_weak_posterior.py')},
        'synthetic': exact, 'camera': camera, 'maximum_guard_difference_DN16': max(v['maximum_guard_difference_DN16'] for v in both),
        'median_native_crop_ms': {k: 1000 * median(v[f'{k}_seconds'] for v in values) for k in ('guard', 'base')},
    })


if __name__ == '__main__':
    main()
