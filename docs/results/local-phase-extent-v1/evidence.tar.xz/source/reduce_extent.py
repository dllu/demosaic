"""Compute paired fixed-dose and equal-response comparisons."""

from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_extent import OUT
from reduce_support import ADDED, FALSE, RESPONSE, compare, means, review_panel


def domain(rows):
    selected = [info for r in rows for d in r['draws'] for info in d['evidence'] if info.get('selected')]
    eligible = [i for i in selected if i['phase_eligible']]
    return {'role_crops_with_weak_selection': len(selected), 'crops_with_donor_phase': len(eligible),
            'selected_windows': sum(len(i['selected']) for i in selected),
            'eligible_windows': sum(len(i['selected']) for i in eligible)}


def verify(previous, new):
    maxima = dict.fromkeys(('combined', 'weak'), 0.)
    for one, two in zip(previous, new, strict=True):
        assert one['id'] == two['id']
        for x, y in zip(one['draws'], two['draws'], strict=True):
            if 'input' in x:
                assert x['input'] == y['input'] and x['outputs'] == y['outputs']
            for key in maxima:
                for metric, value in x['nominal'][key].items():
                    maxima[key] = max(maxima[key], abs(value - y['nominal'][key][metric]))
    np.testing.assert_equal(list(maxima.values()), [0., 0.])
    return maxima


def main(names):
    cal = reference(OUT / 'calibration.json')
    choices = {'combined': ('combined', 1), 'weak': ('weak', 1), 'uniform': ('weak', .75)}
    policy = read_json(checked(cal))['policy']
    choices.update({k: (v['name'], v['weight']) for k,v in policy['selected'].items()})
    old = OUT.with_name('local-weak-support-v1')
    sources = {'calibration': 'exterior-calibration.json', 'previous': 'exterior-recent.json', 'held': 'exterior-new.json'}
    panels = {}
    for name in names:
        receipt = reference(OUT / f'{name}.json')
        rows = read_json(checked(receipt))['rows']
        panel = review_panel('fresh' if name == 'fresh' else name, receipt, rows, choices)
        panel['availability'] = domain(rows)
        if name in sources:
            binding = reference(old / sources[name])
            same = verify(read_json(checked(binding))['rows'], rows)
            panel['prior_parity'] = {'source': binding, 'maximum_baseline_absolute_error_by_method': same}
        elif name == 'fresh':
            assert len(rows) == 32
        panels[name] = panel
        values = panel['means']
        print(name, panel['availability'])
        for key in choices:
            result = values[key]
            entry = panel['equal_response_diagnostic'].get(key)
            diff = None if entry is None else entry['versus_equal_response_uniform'][ADDED]['difference_interval']
            print(key, *(round(result[k], 6) for k in (RESPONSE, ADDED, FALSE)), diff)
        k = 'weak' if name == 'fresh' else 'guided'
        print('vs uniform', k, panel['vs_fixed_uniform'][k][RESPONSE], panel['vs_fixed_uniform'][k][ADDED])
    if 'fresh' in names:
        write_json(OUT / 'summary.json', {'driver': reference(Path(__file__)), 'calibration': cal, 'choices': choices, 'panels': panels})


if __name__ == '__main__':
    main(sys.argv[1:])
