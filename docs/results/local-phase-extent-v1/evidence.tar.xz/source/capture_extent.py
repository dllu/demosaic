"""Freeze a source-disjoint optical confirmation panel for the wider envelope."""

from pathlib import Path
import sys
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic') / HERE.name / 'fresh'
sys.path.insert(0, str(HERE.with_name('local-weak-support-v1')))
import capture_new as prior


def choose():
    latest = reference(OUT.parent.parent / 'local-weak-support-v1/fresh/plan.json')
    if Path(latest['path']) not in prior.EXCLUSIONS:
        prior.EXCLUSIONS = (*prior.EXCLUSIONS, Path(latest['path']))
    # Reuse the same selection and trace audit with a separate seed and balanced larger panel.
    earlier = prior.earlier
    refs = [reference(p) for p in prior.EXCLUSIONS]
    blocked = set()
    capture = earlier.capture_wide
    for binding in refs:
        capture.scan(read_json(checked(binding)), blocked)
    original = capture.lines
    source_pool = read_json(checked(refs[0]))['source_pool']

    def filtered(binding):
        for item in original(binding):
            if binding != source_pool or {item['id'], item['cache_sha256']}.isdisjoint(blocked):
                yield item

    earlier.COUNT, earlier.GROUP_SIZE, earlier.SEED = 32, 8, 202611200437
    capture.lines = filtered
    try:
        plan = earlier.choose()
    finally:
        capture.lines = original
    assert not any({r['source']['id'], r['source']['cache_sha256']} & blocked for r in plan['sources'])
    plan.update(driver=reference(__file__), capture_source=reference(earlier.__file__),
                extra_excluded_sources=refs, native_indices=[1, 9],
                primary='After locking on the older 32 calibration sources, compare actual added gap luma RMS at similar weak response.',
                hypothesis='A fixed exterior phase and wider sensor support can identify weak-strand endpoints without changing fine phase delivery.')
    for r in plan['sources']:
        r['id'] = r['id'].replace('nested-', 'phase-extent-')
    return plan


def main():
    torch.set_num_threads(2)
    started = monotonic()
    OUT.mkdir(exist_ok=True)
    plan_ref = OUT / 'plan.json'
    if not plan_ref.is_file():
        write_json(plan_ref, choose())
    plan = read_json(plan_ref)
    assert plan['driver'] == reference(__file__)
    prior.earlier.SEED = plan['seed']
    inputs = OUT / 'inputs'
    inputs.mkdir(exist_ok=True)
    input_index = OUT / 'inputs.json'
    if not input_index.is_file():
        records = []
        for case in plan['sources']:
            records.append(prior.earlier.capture(case, plan['noise'], inputs))
            if len(records) % 8 == 0:
                print('Captured', len(records), flush=True)
        write_json(input_index, {'driver': reference(__file__), 'plan': reference(plan_ref),
                                 'observations': records, 'seconds': monotonic() - started})
    prior.parents.OUT = OUT
    if not (OUT / 'parent/result.json').is_file():
        prior.parents.main()


if __name__ == '__main__':
    main()
