"""Render original-pixel boards for the extent comparison."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_extent import OUT, qualify
from conditional import replay
import review_presence as view

DISPLAY = {
    'parent': 'Local 50k', 'nested': 'Combined check', 'weak': 'Weak posterior',
    'uniform': 'Uniform 75%', 'local': 'Donor phase, local', 'near': 'Near pooling',
    'wide': 'Wide pooling', 'ring_phase': 'Color-guided pooling',
}


def arms(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    out, trace = qualify(parent, local, scene, colors, roi, peaks, noise, wb, matrix,
                         clearance=16 if local == roi else 48)
    parent_crop = view.section(parent, *local)
    combined = out['combined']
    result = {'parent': parent_crop, 'nested': combined, 'weak': out['weak']}
    chosen = {'uniform': policy['control']} | policy['selected']
    for label in ('uniform', 'local', 'near', 'wide', 'guided'):
        row = chosen[label]
        change = out[row['name']].astype('d') - combined
        key = 'ring_phase' if label == 'guided' else label
        result[key] = (combined + row['weight'] * change).astype(combined.dtype)
    return result, trace


def exact(policy, destination, case_ids, panel):
    binding = reference(OUT / f'{panel}.json')
    receipt = read_json(checked(binding))
    plan = read_json(checked(receipt['plan']))
    x, y, w, h = plan['query']
    px, py, *_ = replay.ROI
    roi = (x + px, y + py, *replay.ROI[2:])
    boards = []
    for row in receipt['rows']:
        if row['id'] not in case_ids:
            continue
        draw = row['draws'][0]
        data = replay.arrays(draw['input'])
        scene = data['scene_packed'].copy()
        scene[:, y//2:(y+h)//2, x//2:(x+w)//2] = data['packed'][0]
        colors, wb, matrix = [data[key] for key in ('colors', 'wb', 'matrix')]
        inputs = dict(colors=colors[None], wb=wb[None], matrix=matrix[None], packed=data['packed'][:1])
        restorations = [np.load(checked(draw['outputs'][label]), allow_pickle=False)[0] for label in ('local50k', 'v120')]
        parent, v120 = restorations
        guide = draw['actual_frequency']
        peaks = None if guide is None else np.asarray(guide)
        options, traces = arms(parent, replay.ROI, scene, colors, roi, peaks, plan['noise'], wb, matrix, policy)
        frames = [noisy_malvar(inputs)[0], v120]
        for part in options.values():
            image = parent.copy()
            view.section(image, *replay.ROI)[:] = part
            frames.append(image)
        frames.append(data['target'][0])
        labels = ['Noisy Malvar', 'V120 EMA', *(DISPLAY[k] for k in options), 'Exact GT']
        boards.append(view.native_board(destination, row['id'], frames, inputs, {'input': draw['input'],
            'fixture': row['fixture'], 'query': plan['query'], 'noise': plan['noise'], 'weights': plan['checkpoints'],
            'optical_sigma': plan['sigma'], 'draw': 0, 'trace': traces}, labels=labels,
            triplet_indices=(0, labels.index(DISPLAY['local']), len(labels)-1)))
    assert len(boards) == len(case_ids)
    return {'receipt': binding, 'boards': boards}


def main(kind):
    torch.set_num_threads(2)
    start = monotonic()
    binding = reference(OUT / 'calibration.json')
    policy = read_json(checked(binding))['policy']
    destination = OUT / 'boards' / kind
    destination.mkdir(parents=True, exist_ok=True)
    if kind == 'camera':
        view.arcs = arms
        view.NAMES = DISPLAY
        data = view.standing(policy, destination)
    elif kind == 'exact':
        data = exact(policy, destination, ('phase-extent-01', 'phase-extent-09'), 'fresh')
    else:
        data = exact(policy, destination, ('weak-side-07',), 'previous')
    write_json(OUT / f'board-{kind}.json', {'driver': reference(Path(__file__)), 'calibration': binding,
                                          'data': data, 'seconds': monotonic()-start})


if __name__ == '__main__':
    main(sys.argv[1])
