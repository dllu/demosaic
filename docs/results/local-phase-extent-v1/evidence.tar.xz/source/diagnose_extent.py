"""Show equal-response gap changes and identify large paired source effects."""

from pathlib import Path
from statistics import mean

import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_extent import OUT
from reduce_support import ADDED, FALSE, evaluate

PANELS = {'previous': 'Earlier 24 photos', 'held': 'Second 24 photos', 'fresh': '32 new photos'}
ARMS = {'local': 'Local donor phase', 'near': 'Near pooling', 'wide': 'Wide pooling',
        'guided': 'Color-guided pooling', 'opposite': '90° phase control'}


def gap_sources(panel, choice):
    data = read_json(checked(panel['receipt']))
    dose = panel['equal_response_diagnostic']['local']['uniform_weight']
    rows = []
    for r in data['rows']:
        draws = []
        for d in r['draws']:
            arm, base = evaluate(d, choice), evaluate(d, ('weak', dose))
            if ADDED in arm:
                draws.append({'draw': d['draw'], 'guard_gap_luma_DN16': arm[ADDED], 'uniform_gap_luma_DN16': base[ADDED],
                              'guard_false_direction_DN16': arm[FALSE], 'uniform_false_direction_DN16': base[FALSE]})
        if draws:
            rows.append({'id': r['id'], 'draws': draws, 'mean_improvement_DN16': mean(
                d['uniform_gap_luma_DN16'] - d['guard_gap_luma_DN16'] for d in draws)})
    total = sum(r['mean_improvement_DN16'] for r in rows)
    largest = max(rows, key=lambda r: r['mean_improvement_DN16'])
    return {'largest_source': largest['id'], 'fraction_of_mean_from_largest': largest['mean_improvement_DN16'] / total,
            'without_largest_mean_improvement_DN16': mean(r['mean_improvement_DN16'] for r in rows if r is not largest),
            'sources': rows}


def main():
    binding = reference(OUT / 'summary.json')
    summary = read_json(checked(binding))
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.0), sharex=True, sharey=True, layout='constrained')
    gaps = {}
    for ax, (name, title) in zip(axes, PANELS.items(), strict=True):
        panel = summary['panels'][name]
        gaps[name] = gap_sources(panel, summary['choices']['local'])
        values = panel['equal_response_diagnostic']
        ax.axvline(0, color='#949a9d', linewidth=1)
        for i, key in enumerate(ARMS):
            center, low, high = values[key]['versus_equal_response_uniform'][ADDED]['difference_interval']
            ax.errorbar(center, i, xerr=[[max(0., center - low)], [max(0., high - center)]],
                        color='#176b67' if key == 'local' else '#606d75', fmt='o', markersize=4.5, capsize=2.7)
        ax.set_title(title, fontweight='bold', loc='left')
        ax.set_xticks(np.arange(-.6, .11, .15))
        ax.set_xlim(-.63, .115)
        ax.grid(axis='x', alpha=.15)
        ax.spines[['top', 'right', 'left']].set_visible(False)
    axes[0].set_yticks(range(len(ARMS)), ARMS.values())
    axes[0].invert_yaxis()
    fig.supxlabel('Difference in added gap luma RMS versus uniform scaling (DN16)', fontsize=10)
    output = OUT / 'equal-response-gap.png'
    fig.savefig(output, dpi=160, facecolor='white')
    write_json(OUT / 'gap-diagnostic.json', {'driver': reference(Path(__file__)), 'source': binding,
                                            'image': reference(output), 'breakdown': gaps})


if __name__ == '__main__':
    main()
