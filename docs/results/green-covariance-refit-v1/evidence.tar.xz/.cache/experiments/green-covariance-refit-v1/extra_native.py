"""Render the largest local-only fine-increment gain on the fresh photo cohort."""
import numpy as np

from fresh_fields import ROOT,FIRST_PROFILE
from review_recovery import PARENT,NEW_LOCAL,NEW_SPATIAL
from upper import ROI
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board


def main():
    proof=reference(ROOT/'review.json')
    q=read_json(checked(proof))
    key='fine_increment_RMS_DN16'
    witness=min(q['photo'],key=lambda r:r['scores'][NEW_LOCAL][key]-r['scores'][PARENT][key])
    with np.load(checked(witness['input']),allow_pickle=False)as f:
        data={k:f[k]for k in ('colors','wb','matrix','target','packed')}
    with np.load(checked(witness['prediction']),allow_pickle=False)as f:
        p=f['parent'][0]
    with np.load(checked(witness['transport']),allow_pickle=False)as f:
        local,spatial=(f[k][0] for k in ('local','aligned'))
    camera={key:data[key][None]for key in ('colors','wb','matrix')}|{'packed':data['packed'][0:1]}
    source=witness['source']
    labels=('Noisy Malvar',PARENT,NEW_LOCAL,NEW_SPATIAL,'Exact GT')
    view=native_board(ROOT/'exact',f"{source['index']:02d}-local-iso6400",
            [noisy_malvar(camera)[0],p,local,spatial,data['target'][0]],camera,
            {'source':source,'input':witness['input'],'parent_prediction':witness['prediction'],
             'matched_transport':witness['transport'],'profile':FIRST_PROFILE,'query_xywh':source['box']},
            labels=labels,triplet_indices=(0,2,4),exposure=1/.33,contrast=2,roi=ROI)
    write_json(ROOT/'extra-native.json',dict(driver=reference(__file__),scored=proof,view=view,
                    difference_DN16=witness['scores'][NEW_LOCAL][key]-witness['scores'][PARENT][key]))
    print(view['id'],source['source']['title'],source['box'],source['camera']['pattern'],flush=True)


if __name__=='__main__':
    main()
