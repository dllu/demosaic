"""Fit a direct, observable green-innovation basis and isolate the binding gap budgets."""
import time

import numpy as np
from scipy.optimize import minimize

from fresh_fields import ROOT,PREVIOUS,BOX
from refit import DAMPED,FORMS,wire_terms,photo_terms,WireMetric,load_data,load,metadata,proposed,serializable,score_constraints,fit_family
from green_innovation import innovation_fields,interpolation_check
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def compose_terms(parent,base,damp,args,profile,term):
    options={key:[]for key in FORMS}
    for i in range(len(parent)):
        raw={k:args[k]for k in ('colors','wb','matrix')}|{'packed':args['packed'][i]}
        for name,field in innovation_fields(base[i],damp[i],raw,profile).items():
            options[name].append(field)
    zero=np.zeros_like(damp)
    p,_=term(args,parent,zero,zero)
    return dict(parent_errors={key:float(q[0,0])for key,q in p.items()},
                terms={key:term(args,base,damp,np.stack(value))for key,value in options.items()})


def development(frozen,prev):
    wire=[]
    for row in prev['rows']:
        if row['panel']!='development' or row['case']['noise']!='iso6400':
            continue
        args=load_data(row['case'])
        with np.load(checked(row['prediction']),allow_pickle=False)as item:
            p,q=item['Corpus 100k'],item['aligned']
        base,damp,_,_=proposed(p,q,args,BOX,row['profile'],frozen['fits']['limited_guard'])
        metric=WireMetric(args,row['source']['geometry'])
        result=compose_terms(p,base,damp,args,row['profile'],lambda a,b,d,u:wire_terms(a,b,d,u,metric))
        wire.append(dict(result,source=row['source']['source']['id'],input=row['prediction']))
    _,review,_,_=metadata()
    photos=[]
    for row in review['source_metrics']:
        if row['source'] not in frozen['split']['calibration'] or row['profile']!='iso6400' or row['draw']!='independent':
            continue
        settings,args,predicted=load(row)
        p,q=predicted['100k'],predicted['spatial--matching']
        base,damp,_,_=proposed(p,q,args,settings['box'],settings['profile'],frozen['fits']['limited_guard'])
        result=compose_terms(p,base,damp,args,settings['profile'],photo_terms)
        photos.append(dict(result,source=row['source'],input=row['prediction_receipt']))
    assert len(wire)==24 and len(photos)==16
    return wire,photos


def optimize(mode,wire,photos,slack):
    terms=[r['terms'][mode][0]for r in (*wire,*photos)]
    errors={key:np.mean([item[key]for item in terms if key in item],axis=0)
            for key in sorted(set().union(*(item.keys()for item in terms)))}
    response={}
    for key,rows in (('wire',wire),('photo',photos)):
        response[key]=np.mean([r['terms'][mode][1]for r in rows if r['terms'][mode][1] is not None],axis=0)
    budgets={key:score_constraints(m,DAMPED)for key,m in errors.items()}
    if slack:
        for key in budgets:
            expected=np.mean([r['parent_errors'][key]for r in (*wire,*photos) if key in r['parent_errors']])
            budgets[key]+=.5*max(0.,expected-budgets[key])
    anchor={key:float(r@np.r_[1.,DAMPED])for key,r in response.items()}
    needed={key:float(max(.025,r[0]-anchor[key]))for key,r in response.items()}
    def residual(w):
        a=np.r_[1.,w[:2]]
        metrics=[(budgets[k]-a@q@a)/max(budgets[k],1.)for k,q in errors.items()]
        metrics.extend((float(r@a)-anchor[key])/needed[key]-w[2]for key,r in response.items())
        return np.asarray(metrics)
    solved=minimize(lambda w:-w[2],np.r_[DAMPED,0.],method='SLSQP',bounds=((-2,0),(0,2),(0,4)),
                    constraints=[{'type':'ineq','fun':residual}],options={'maxiter':300,'ftol':1e-10})
    assert np.min(residual(solved.x))>=-1e-7
    answer=solved.x if solved.x[2]>1e-7 else np.r_[DAMPED,0.]
    w=answer[:2]
    return dict(weights=w.tolist(),balanced_fraction_recovered=float(answer[2]),success=bool(solved.success),
                message=solved.message,ceilings=budgets,chosen_mse={key:score_constraints(q,w)for key,q in errors.items()},
                response={key:dict(prior=anchor[key],fitted=float(r@np.r_[1.,w]),band_limited=float(r[0]))
                          for key,r in response.items()})


def remove_budget_report(fit):
    """Closed development-only ablation on the frozen neural-difference fit."""
    variants={}
    for choice in ('no_gap','except_strong','except_weak','except_exterior','except_absolute'):
        key=f'gap_{choice.split("_",1)[-1]}'
        def filter_rows(rows):
            return [{'terms':{mode:({k:np.asarray(v)for k,v in e.items()
                                  if not (k==key or (choice=='no_gap' and k.startswith('gap_')))},
                                  None if r is None else np.asarray(r))
                              for mode,(e,r) in row['terms'].items()}}for row in rows]
        wire,photos=(filter_rows(fit[k])for k in ('wire','photos'))
        variants[choice]={mode:fit_family(mode,wire,photos,reserve=.5)for mode in FORMS}
    return variants


def main():
    started=time.monotonic()
    protocol=reference(ROOT/'innovation-plan.json')
    declaration=read_json(checked(protocol))
    previous=read_json(checked(declaration['neural_delta_fit']))
    stored=read_json(checked(previous['development']))
    frozen=read_json(checked(stored['fit']))
    error=interpolation_check()
    wire,photos=development(frozen,stored)
    strict={mode:optimize(mode,wire,photos,False)for mode in FORMS}
    reserved={mode:optimize(mode,wire,photos,True)for mode in FORMS}
    # Only the development outcomes control the candidate path used for native inspection.
    key='strict' if strict['covariance']['balanced_fraction_recovered']>0 else 'half_corpus_budget'
    write_json(ROOT/'innovation-fit.json',dict(driver=reference(__file__),protocol=protocol,
        interpolation_max_error=error,source=previous['development'],wire=serializable(wire),
        photos=serializable(photos),strict=strict,half_corpus_budget=reserved,selected_native=key,
        original_gap_ablation=remove_budget_report(previous),wall_seconds=time.monotonic()-started))
    for name,modes in (('strict',strict),('half Corpus budget',reserved)):
        for mode,row in modes.items():
            print(name,mode,row['weights'],row['balanced_fraction_recovered'],row['response'],flush=True)


if __name__=='__main__':
    main()
