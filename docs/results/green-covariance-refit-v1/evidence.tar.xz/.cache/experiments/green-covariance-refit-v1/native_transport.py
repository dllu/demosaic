"""Render the fresh exact-target crops and both standing 47.5k comparisons."""
from pathlib import Path

import numpy as np
import torch

from fresh_fields import ROOT,PREVIOUS
from review_recovery import modes,BASE,DAMP,RELEASE,NEW_TRANSPORT,NEW_LOCAL,NEW_SPATIAL,PARENT
from transport import STANDING
from support import candidate_fields,restore
from audit_delivery import compose_guarded
from upper import ROI
from native import old_pixels,native_png
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board


def exact(review,prior,profile):
    output=ROOT/'exact'
    output.mkdir(exist_ok=True)
    order=(PARENT,BASE,DAMP,RELEASE,NEW_LOCAL,NEW_SPATIAL,NEW_TRANSPORT)
    labels=('Noisy Malvar','Corpus 100k','40k blend','40k Bayer damping',
            '40k less damping','Local 47.5k','Spatial 47.5k','47.5k blend','Exact GT')
    wires=[r for r in review['wire'] if r['gap_pixels']>0]
    subset=[min(wires,key=lambda r:r['scores'][NEW_TRANSPORT]['gap_RMS_DN16']-r['scores'][BASE]['gap_RMS_DN16']),
            max(review['photo'],key=lambda r:r['scores'][NEW_TRANSPORT]['fine_increment_RMS_DN16']-r['scores'][BASE]['fine_increment_RMS_DN16'])]
    renders=[]
    for row in subset:
        source=row['source']
        layout=source['kind']
        origin=(128,128,256,256) if layout=='wire' else source['box']
        with (np.load(checked(row['input']),allow_pickle=False)as data,
              np.load(checked(row['prediction']),allow_pickle=False)as earlier,
              np.load(checked(row['transport']),allow_pickle=False)as after):
            args={k:data[k]for k in data.files}
            pictures,_=modes(args,earlier,after,prior,origin,profile,review['release'],review['matched_positive_recovery'])
        camera={key:args[key][None]for key in ('wb','matrix','colors')}|{'packed':args['packed'][0:1]}
        exposure=2. if layout=='wire' else 1/.33
        contrast=1. if layout=='wire' else 2.
        images=[noisy_malvar(camera)[0],*[pictures[k][0]for k in order],args['target'][0]]
        tag=f"{source['index']:02d}-{layout}-iso6400"
        renders.append(native_board(output,tag,images,camera,
              dict(source=source,input=row['input'],parent_predictions=row['prediction'],transport_predictions=row['transport'],
                   profile=profile,query_xywh=origin),labels=labels,triplet_indices=(0,7,8),
              exposure=exposure,contrast=contrast,roi=ROI))
    return renders


def standing(transport,fit,release):
    output=ROOT/'standing'
    output.mkdir(exist_ok=True)
    older=read_json(checked(reference(STANDING)))
    references={r['id']:r for r in older['standing']['records']}
    prior_board=Path('docs/images/scene-mixture-wire-gaps-v1/manifest.json')
    older_damping={row['id']:row for row in read_json(checked(reference(prior_board)))['standing']['rows']}
    finished=[]
    torch.set_num_threads(2)
    for family in ('main','mesh'):
        rows=[r for r in transport['rows'] if r['id'].startswith(family+'-')]
        source=rows[0]['raw']
        mosaic,_=read_raw(checked(source))
        h,w=mosaic.shape
        scene=np.stack([mosaic[y:h//2*2:2,x:w//2*2:2]for y in range(2)for x in range(2)])
        del mosaic
        for row in rows:
            name=row['id']
            old=references[name]
            old_damped=older_damping[name]
            assert row['raw']==old['raw']==old_damped['raw'] and row['input']==old['input']==old_damped['input']
            assert row['noise']==old_damped['shot_read'] and row['exposure']==old_damped['exposure']
            with np.load(checked(old['input']),allow_pickle=False)as f:
                raw={k:f[k][0]for k in ('packed','colors','wb','matrix')}
            p,q=(np.load(checked(row['parent_images'][label]),allow_pickle=False)[0]for label in ('parent100k','spatial'))
            with np.load(checked(row['predictions']),allow_pickle=False)as f:
                newest={k:f[k][0]for k in ('local','aligned')}
            profile,roi,box=row['noise'],row['roi'],row['native_sensor_box']
            base,changes,_=candidate_fields(p,q,raw,profile,roi,scene,box,fit)
            damp=restore(base,changes['supported'],-.5,roi)
            released=restore(base,changes['supported'],release,roi)
            updated=compose_guarded(p,newest['aligned'],raw,profile,roi,scene,box,fit)
            wb,cam=(torch.from_numpy(raw[k][None])for k in ('wb','matrix'))
            def display(array):
                value=display_crop(torch.from_numpy(array[None]),wb,cam,roi,exposure=row['exposure'])
                return np.rint(value.clip(0,1)*255).astype(np.uint8)
            previous=old_pixels(row['reference_board'])
            board=old_damped['output']
            # Verify the already-reviewed damped control on this input and display binding.
            expected=board['image'].copy()
            filename=prior_board.parent/expected['path']
            assert reference(filename)['sha256']==expected['sha256']
            old_pixels_board=board|{'image':reference(filename)}
            np.testing.assert_array_equal(display(damp),old_pixels(old_pixels_board)['Bayer-gated damping'])
            panels=[(k,previous[k])for k in ('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA') if k in previous]
            panels.extend((k,display(value))for k,value in (('40k blend',base),('40k Bayer damping',damp),
                ('40k less damping',released),('Local 47.5k',newest['local']),('Spatial 47.5k',newest['aligned']),
                ('47.5k blend',updated)))
            panels.extend((k,previous[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in previous)
            x,y,w,h=roi
            region=np.s_[:,y:y+h,x:x+w]
            def rms(a,b):
                return float(np.linalg.norm((a.astype(float)-b)[region])*65535/np.sqrt(3*w*h))
            finished.append(dict(row,board=native_png(output/f'{name}.png',panels),
                                difference=dict(new_blend_vs_old=rms(updated,base),less_damping_vs_damped=rms(released,damp),
                                                spatial_vs_local=rms(newest['aligned'],newest['local']))))
        del scene
    assert len(finished)==8
    return finished


def main():
    scores=reference(ROOT/'review.json')
    comparison=read_json(checked(scores))
    review_plan=read_json(checked(comparison['plan']))
    fresh=read_json(checked(review_plan['fresh']))
    spec=read_json(checked(fresh['plan']))
    frozen=read_json(checked(spec['previous_fit']))
    component=frozen['fits']['limited_guard']
    standing_proof=reference(ROOT/'transport-standing.json')
    raw=read_json(checked(standing_proof))
    checkpoint=read_json(checked(raw['plan']))['checkpoints']
    views=exact(comparison,component,spec['profile'])
    photos=standing(raw,component,comparison['release'])
    write_json(ROOT/'native.json',dict(driver=reference(__file__),scored=scores,standing_proof=standing_proof,
              checkpoints=spec['checkpoints']|{'transport':checkpoint},views=views,standing=photos))
    print('Completed',len(views),len(photos),flush=True)


if __name__=='__main__':
    main()
