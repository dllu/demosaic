"""Project measured-minus-restored green onto observable native frequency bands."""
import numpy as np
from scipy.fft import fft2,ifft2
from scipy.ndimage import gaussian_filter

from green_phase_power import ROI,RAW_PAD,cap_band,taper,filters,raw_support,FORMS
from refit import DAMPED


def native_oversample(frequency):
    """Interpolate a band-limited packed field to twice its sample density."""
    h,w=frequency.shape[-2:]
    native=np.zeros((*frequency.shape[:-2],2*h,2*w),np.complex128)
    native[...,h//2:h//2+h,w//2:w//2+w]=np.fft.fftshift(frequency,axes=(-2,-1))
    pixels=ifft2(np.fft.ifftshift(native,axes=(-2,-1)),workers=1)*4
    assert float(np.max(np.abs(pixels.imag)))<1e-9
    pad=2*RAW_PAD
    return pixels.real[...,pad:-pad,pad:-pad]


def innovation_fields(base,damping,raw,profile):
    x,y,w,h=ROI
    camera_green=base[1].astype(np.float64).copy()
    camera_green[y:y+h,x:x+w]+=DAMPED[0]*damping[1]
    residual=[]
    for phase in np.flatnonzero(raw['colors']==1):
        dy,dx=divmod(phase,2)
        residual.append(raw['packed'][phase]-camera_green[dy::2,dx::2])
    padded=np.pad(residual,((0,0),(RAW_PAD,RAW_PAD),(RAW_PAD,RAW_PAD)),mode='reflect')
    fy,fx,directions=filters(padded.shape[-2:],2,True)
    spectra=[]
    for phase,observed in zip(np.flatnonzero(raw['colors']==1),padded,strict=True):
        dy,dx=divmod(phase,2)
        offset=np.exp(-2j*np.pi*(fy*dy+fx*dx))
        spectra.append(fft2(observed,workers=1)*offset/2)
    cut=np.s_[...,y:y+h,x:x+w]
    signed= native_oversample(directions*sum(spectra))[cut]
    agreement,auto=raw_support(raw,profile,ROI)
    neutral=np.linalg.solve(raw['matrix'].astype(float),np.ones(3))/raw['wb']
    # A smooth highlight veto uses observed green levels and covers saturated
    # Bayer sites plus their immediate neighborhood.
    greens=raw['packed'][np.asarray(raw['colors'])==1].mean(0)
    display=np.repeat(np.repeat(gaussian_filter(greens,1.,mode='reflect'),2,axis=0),2,axis=1)[cut]
    guard=np.clip((.985-display)/.05,0,1)
    def render(weights):
        wave=cap_band((weights*signed).sum(0)*guard)*taper()
        # One unit of neutral change is expressed on the actual green scale.
        return (neutral[:,None,None]*(.1/neutral[1])*wave).astype(np.float32)
    result={'covariance':render(agreement),'auto_power':render(auto),
            'rotated':render(np.roll(agreement,2,axis=0)),'uniform':render(1.)}
    assert tuple(result)==FORMS
    return result


def interpolation_check():
    y,x=np.mgrid[:64,:64]
    wave=np.sin(2*np.pi*(7*x-3*y)/64.)
    f=fft2(wave,workers=1)
    got=native_oversample(f)
    z,v=np.mgrid[32:96,32:96]
    want=np.sin(2*np.pi*(7*v-3*z)/128.)
    error=float(np.max(np.abs(got-want)))
    assert error<1e-12
    return error
