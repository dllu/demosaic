"""Test the same frozen blend with the new matched 47,500-update checkpoints."""
import time

import numpy as np
import torch

from fresh_fields import ROOT,PREVIOUS,scene_preview,encode
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

MATCH=ROOT.with_name('scene-full-epoch-v1')/'matched-047500.json'
STANDING=ROOT.with_name('scene-gated-mixture-v1')/'native.json'


def load_models(checkpoints):
    models={}
    for arm,binding in checkpoints.items():
        model,state=load_scene_checkpoint(checked(binding),device='cuda',weights='ema',expected_sha256=binding['sha256'])
        assert state['step']==47500 and state['mode']==arm and state['loaded_sha256']==binding['sha256']
        models[arm]=model.eval().to(memory_format=torch.channels_last)
    return models


@torch.inference_mode()
def compare(models,data,box,profile,reverse):
    for model in models.values():
        model.base.set_noise(profile['shot'],profile['read'])
    camera=[torch.from_numpy(data[k]).cuda()for k in ('colors','wb','matrix')]
    raw=torch.from_numpy(data['packed']).cuda()
    variance=torch.from_numpy(data['variance']).cuda()
    scene=torch.from_numpy(data['scene_packed']).cuda()
    n=len(raw)
    args=[v.contiguous(memory_format=torch.channels_last)for v in (raw,variance)]+[v[None].expand(n,*v.shape)for v in camera]
    x,y,w,h=(v//2 for v in box)
    exteriors={'aligned':scene}
    if reverse:
        exteriors['reversed']=scene.flip((-2,-1))
    trace={}
    with ieee_fp32():
        result={'local':models['none'](*args).cpu().numpy()}
        for name,environment in exteriors.items():
            cache=[]
            trace[name]=[]
            for pixels in raw:
                painted=environment.clone()
                painted[:,y:y+h,x:x+w].copy_(pixels)
                assert torch.equal(painted[:,y:y+h,x:x+w],pixels)
                preview,grid=scene_preview(painted,*camera,long_side=1024,exposure=1.)
                cache.append(encode(models['spatial'],preview,grid))
                trace[name].append(fingerprint(preview.cpu()))
            result[name]=models['spatial'](*args,scene=cache,boxes_xywh=[box]*n).cpu().numpy()
    assert all(z.shape==(n,3,box[3],box[2])for z in result.values())
    return result,trace


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    fresh=reference(ROOT/'fresh.json')
    fixed=read_json(checked(fresh))
    matched=reference(MATCH)
    ends=read_json(checked(matched))
    assert ends['matched_input_traces'] and ends['through_update']==47500
    weights={key:val['checkpoint']for key,val in ends['arms'].items()}
    models=load_models(weights)
    protocol=dict(match=matched,checkpoints=weights,inputs=fresh,standing=reference(STANDING),
                  precision='CUDA IEEE FP32 EMA',geometry='Use identical normalized CFA arrays and source coordinates.')
    prereg=ROOT/'transport-plan.json'
    write_json(prereg,protocol)
    out=ROOT/'transport'
    out.mkdir(exist_ok=True)
    start=time.monotonic()
    receipts=[]
    for row in fixed['rows']:
        with np.load(checked(row['input']),allow_pickle=False)as f:
            data={k:f[k]for k in ('packed','variance','colors','wb','matrix','scene_packed')}
        # Whole-scene rotation changes only the exterior. The prior attenuation recipe is held fixed.
        predictions,dino=compare(models,data,row['box'],read_json(checked(fixed['plan']))['profile'],True)
        target=out/f"{row['source']['index']:02d}.npz"
        np.savez_compressed(target,**predictions)
        receipts.append(dict(index=row['source']['index'],input=row['input'],predictions=reference(target),previews=dino))
        if len(receipts)%8==0:
            print(len(receipts),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/'transport-fresh.json',dict(driver=reference(__file__),plan=reference(prereg),rows=receipts,
                                              scoped_inference_wall_seconds=time.monotonic()-start))

    archived=read_json(checked(protocol['standing']))
    captured=[]
    for family in ('main','mesh'):
        rows=[row for row in archived['standing']['records'] if row['id'].startswith(family+'-')]
        raw=checked(rows[0]['raw'])
        mosaic,_=read_raw(raw)
        h,w=mosaic.shape
        scene=np.stack([mosaic[y:h//2*2:2,x:w//2*2:2] for y in range(2) for x in range(2)])
        del mosaic
        existing={}
        for row in rows:
            key=row['input']['sha256'],str(row['conditioning'])
            if key not in existing:
                with np.load(checked(row['input']),allow_pickle=False)as f:
                    args={k:f[k]for k in ('packed','variance','colors','wb','matrix')}
                for k in ('colors','wb','matrix'):
                    args[k]=args[k][0]
                args['scene_packed']=scene
                x,y,w,h=row['native_sensor_box']
                np.testing.assert_array_equal(args['packed'][0],scene[:,y//2:(y+h)//2,x//2:(x+w)//2])
                predictions,dino=compare(models,args,row['native_sensor_box'],row['conditioning'],False)
                save=out/f"{row['id']}.npz"
                np.savez_compressed(save,**predictions)
                existing[key]=(reference(save),dino)
            stored,dino=existing[key]
            captured.append(dict(id=row['id'],predictions=stored,dino=dino,raw=row['raw'],input=row['input'],
                                 parent_images=row['parent_images'],roi=row['roi'],native_sensor_box=row['native_sensor_box'],
                                 noise=row['conditioning'],exposure=row['display_exposure'],reference_board=row['board']))
            print(row['id'],flush=True)
        del scene
    write_json(ROOT/'transport-standing.json',dict(driver=reference(__file__),plan=reference(prereg),rows=captured,
                                                  elapsed_seconds=time.monotonic()-start))


if __name__=='__main__':
    main()
