"""Use phase-aligned RAW covariance to route a fixed neutral model difference."""
from functools import lru_cache

import numpy as np
from scipy.fft import fft2,ifft2
from scipy.ndimage import gaussian_filter,map_coordinates

from upper import ROI,cap_band,luma,shape_delta,taper
from support import candidate_fields as previous_fields

N_DIRECTIONS=4
RAW_PAD=16
POOL_SIGMA=4.0
FORMS=('covariance','auto_power','rotated','uniform')
ANGLES=np.arange(N_DIRECTIONS)*np.pi/N_DIRECTIONS


def raised(low,high,coordinates):
    phase=np.clip((coordinates-low)/(high-low),0,1)
    return .5-.5*np.cos(np.pi*phase)


@lru_cache(maxsize=8)
def filters(shape,pixel_step,raw_band):
    fy,fx=np.meshgrid(np.fft.fftfreq(shape[0],d=pixel_step),np.fft.fftfreq(shape[1],d=pixel_step),indexing='ij')
    r=np.hypot(fy,fx)
    norm=np.maximum(r,1e-15)
    projection=np.stack([((fx*np.cos(a)+fy*np.sin(a))/norm)**8 for a in ANGLES])
    direction=projection/np.maximum(projection.sum(0),1e-12)
    direction[:,0,0]=1/N_DIRECTIONS
    if raw_band:
        response=raised(.055,.082,r)*(1-raised(.195,.239,r))
        direction*=response
    return fy,fx,direction


def raw_support(raw,profile,roi):
    """Fixed-band green-phase estimates. The cross product uses separate measured grids."""
    x,y,w,h=roi
    g=np.flatnonzero(raw['colors']==1)
    assert len(g)==2
    green=np.asarray(raw['packed'][g],dtype=np.float64)
    sources=np.pad(green,((0,0),(RAW_PAD,RAW_PAD),(RAW_PAD,RAW_PAD)),mode='reflect')
    fy,fx,directions=filters(sources.shape[-2:],2,True)
    projected=[]
    for phase,plane in zip(g,sources,strict=True):
        dy,dx=divmod(phase,2)
        phase_alignment=np.exp(-2j*np.pi*(fy*dy+fx*dx))
        value=ifft2(directions*(phase_alignment*fft2(plane,workers=1)),workers=1)
        assert np.max(np.abs(value.imag))<1e-10
        projected.append(value.real[:,RAW_PAD:-RAW_PAD,RAW_PAD:-RAW_PAD])
    a,b=projected
    average=lambda v:gaussian_filter(v,sigma=(0,POOL_SIGMA,POOL_SIGMA),mode='reflect')
    covariance=average(a*b)
    dose=np.maximum(0,gaussian_filter(green.mean(0),sigma=POOL_SIGMA,mode='reflect'))
    noise=np.maximum(1e-12,profile['shot']*dose+profile['read'])
    noise_energy=np.mean(directions**2,axis=(1,2))[:,None,None]*noise
    same_plane=average((a*a+b*b)/2)-noise_energy
    def map_to_native(value):
        signal=np.maximum(0,value)
        score=signal/(signal+.30*noise_energy+1e-15)
        yy,xx=np.meshgrid(np.arange(y,y+h)/2,np.arange(x,x+w)/2,indexing='ij')
        return np.stack([map_coordinates(gate,[yy,xx],order=1,mode='nearest',prefilter=False)for gate in score])
    return map_to_native(covariance),map_to_native(same_plane)


def split_directions(field):
    pad=24
    extended=np.pad(field,pad,mode='reflect')
    _,_,directions=filters(extended.shape,1,False)
    bands=ifft2(directions*fft2(extended,workers=1),workers=1).real
    values=bands[:,pad:-pad,pad:-pad]
    assert np.max(np.abs(values.sum(0)-field))<1e-12
    return values


def bases(parent,spatial,raw,profile,scene,box,frozen):
    registered,auto=raw_support(raw,profile,ROI)
    present,changes,_=previous_fields(parent,spatial,raw,profile,ROI,scene,box,frozen)
    _,_,detail=shape_delta(parent,spatial,ROI)
    wb,matrix=raw['wb'],raw['matrix']
    neutral=np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    shape=cap_band(-luma(detail,wb,matrix)/taper())
    bands=split_directions(shape)
    def render(weights):
        field=cap_band(np.sum(weights*bands,axis=0))*taper()
        return (neutral[:,None,None]*field).astype(np.float32)
    proposed={'covariance':render(registered),'auto_power':render(auto),
              'rotated':render(np.roll(registered,2,axis=0)),'uniform':render(1.)}
    return present,changes['supported'],proposed,dict(covariance_mean=float(registered.mean()),auto_power_mean=float(auto.mean()))


def synthesize(base,old_field,new_field,weights):
    x,y,w,h=ROI
    output=base.copy()
    output[...,y:y+h,x:x+w]+=(old_field*weights[0]+new_field*weights[1]).astype(np.float32)
    return output


def algebra():
    """Check the sign of subpixel alignment without fitting an analytic carrier."""
    dims=(128,128)
    yy,xx=np.mgrid[:dims[0],:dims[1]]
    yy,xx=2*yy,2*xx
    from demosaic.cfa import PATTERNS

    signal=lambda x,y:.25+.02*np.sin(2*np.pi*(.11*x+.035*y))
    packed=np.stack([signal(xx+dx,yy+dy)for dy in range(2)for dx in range(2)])
    noise={'shot':8e-5,'read':2.56e-8}
    crop=np.s_[32:-32,32:-32]
    results={}
    for name in PATTERNS:
        colors=np.asarray(PATTERNS[name])
        pattern={'packed':packed,'colors':colors}
        opposing=packed.copy()
        phase=np.flatnonzero(colors==1)[1]
        opposing[phase]=.50-opposing[phase]
        hit,_=raw_support(pattern,noise,ROI)
        null,_=raw_support({'packed':opposing,'colors':colors},noise,ROI)
        flat,_=raw_support({'packed':np.broadcast_to(.25,packed.shape),'colors':colors},noise,ROI)
        assert np.mean(hit[0][crop])>.92 and np.max(null[0][crop])<1e-10
        assert np.mean(hit[2][crop])<.01 and flat.max()<1e-16
        results[name]=dict(mean_correctly_aligned=float(hit[0][crop].mean()),
                 max_opposed_phase=float(null[0][crop].max()),max_constant_field=float(flat.max()),
                 perpendicular_average=float(hit[2][crop].mean()))
    return results
