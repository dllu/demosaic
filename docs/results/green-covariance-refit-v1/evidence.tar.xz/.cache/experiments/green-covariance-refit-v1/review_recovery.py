"""Measure fresh exact targets for the closed recovery and checkpoint-transport studies."""
import time

import numpy as np

from fresh_fields import ROOT
from refit import DAMPED,WireMetric,photo_metrics,FINE,summarize,proposed
from green_phase_power import ROI,synthesize
from green_innovation import innovation_fields
from upper import luma
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

PARENT='Corpus 100k'
BASE='Band-limited blend, 40k'
DAMP='Bayer damping, 40k'
RELEASE='Less Bayer damping, 40k'
NEW_LOCAL='Local-only 47.5k'
NEW_SPATIAL='Spatial 47.5k'
WRONG_SCENE='Spatial 47.5k, reversed exterior'
NEW_TRANSPORT='Band-limited blend, 47.5k'
NUDGE='Measured green, covariance'
LABELS=(PARENT,'V120',BASE,DAMP,RELEASE,NUDGE,NEW_LOCAL,NEW_SPATIAL,WRONG_SCENE,NEW_TRANSPORT)
COMPARISONS=((DAMP,BASE),(RELEASE,DAMP),(NUDGE,DAMP),('Measured green, rotated',NUDGE),
             ('Measured green, uniform',NUDGE),(NEW_LOCAL,PARENT),(NEW_SPATIAL,NEW_LOCAL),
             (NEW_SPATIAL,WRONG_SCENE),(NEW_TRANSPORT,BASE),(NEW_TRANSPORT,DAMP),(NEW_TRANSPORT,'V120'))


def recovery_doses(innovation):
    chosen=innovation[innovation['selected_native']]['covariance']['weights']
    assert abs(chosen[1])<1e-10
    mode='covariance'
    old_weight,new_weight=DAMPED[0],chosen[0]
    photo_q=[r['terms'][mode][0]['photo_flat']for r in innovation['photos']]
    power=float(np.mean([q[1][1]for q in photo_q]))*(new_weight-old_weight)**2
    dose={}
    for form in ('covariance','rotated','uniform'):
        q=[r['terms'][form][0]['photo_flat']for r in innovation['photos']]
        dose[form]=float(np.sqrt(power/np.mean([entry[2][2]for entry in q])))
    return float(new_weight),dose,float(power**.5)


def modes(args,former,after,fit,box,noise,release,doses):
    p,q=former['parent'],former['spatial']
    base,field,candidates,gates=proposed(p,q,args,box,noise,fit)
    zero=np.zeros_like(field)
    result={PARENT:p,'V120':former['v120'],'Spatial 40k':q,BASE:base,
            DAMP:synthesize(base,field,zero,DAMPED),RELEASE:synthesize(base,field,zero,(release,0))}
    adjustments={k:[]for k in doses}
    for i in range(len(p)):
        raw={k:args[k]for k in ('colors','wb','matrix')}|{'packed':args['packed'][i]}
        directions=innovation_fields(base[i],field[i],raw,noise)
        for key in doses:
            adjustments[key].append(directions[key])
    for key,multiplier in doses.items():
        name=f'Measured green, {key}'
        result[name]=synthesize(base,field,np.stack(adjustments[key]),(DAMPED[0],multiplier))
    result.update({NEW_LOCAL:after['local'],NEW_SPATIAL:after['aligned'],WRONG_SCENE:after['reversed']})
    fixed,_,_,_=proposed(p,after['aligned'],args,box,noise,fit)
    result[NEW_TRANSPORT]=fixed
    return result,gates


def photo_summary(rows,pairs):
    factor=np.sqrt(FINE.sum()/FINE.size)
    rng=np.random.default_rng(202611191048)
    result={}
    for arm,basis in pairs:
        metrics={}
        for key in rows[0]['scores'][arm]:
            valid=[row['scores']for row in rows if row['scores'][arm][key] is not None]
            values=np.asarray([[r[k][key]for r in valid] for k in (arm,basis)])
            draw=np.vstack((np.arange(len(valid)),rng.integers(len(valid),size=(7000,len(valid)))))
            mean=factor*np.sqrt(np.mean(values[:,draw]**2,axis=-1)) if key.endswith('RMS_DN16') else values[:,draw].mean(-1)
            difference=mean[0]-mean[1]
            metrics[key]=dict(count=len(valid),candidate=float(mean[0,0]),control=float(mean[1,0]),
                              delta=float(difference[0]),interval=np.quantile(difference[1:],[.025,.975]).tolist())
        result[f'{arm} vs {basis}']=metrics
    return result


def main():
    plan=reference(ROOT/'review-plan.json')
    policy=read_json(checked(plan))
    mask_policy=reference(ROOT/'continuous-dip-definition.json')
    assert read_json(checked(mask_policy))['original_plan']==plan
    fresh=read_json(checked(policy['fresh']))
    transport=read_json(checked(policy['transport']))
    dev=read_json(checked(policy['innovation_fit']))
    frozen=read_json(checked(read_json(checked(fresh['plan']))['previous_fit']))
    noise=read_json(checked(fresh['plan']))['profile']
    keys={row['source']for row in dev['wire']+dev['photos']}
    assert len(keys)==40 and keys.isdisjoint(row['source']['source']['id']for row in fresh['rows'])
    release,doses,budget=recovery_doses(dev)
    print('release',release,'matched doses',doses,'flat RMS target',budget,flush=True)
    cases=[]
    start=time.monotonic()
    for row,moved in zip(fresh['rows'],transport['rows'],strict=True):
        assert row['source']['index']==moved['index'] and row['input']==moved['input']
        with np.load(checked(row['input']),allow_pickle=False)as f:
            args={k:f[k]for k in f.files}
        with (np.load(checked(row['predictions']),allow_pickle=False)as earlier,
              np.load(checked(moved['predictions']),allow_pickle=False)as current):
            rendered,gates=modes(args,earlier,current,frozen['fits']['limited_guard'],row['box'],noise,release,doses)
        wire=row['source']['kind']=='wire'
        if wire:
            geometry=row['source']['geometry']
            scored_args=args
            if geometry['family']=='smooth-dip':
                # Its continuous contrast can stay below the gap shoulder
                # threshold throughout the scoring core.
                assert np.all(args['support']>0)
                scored_args={**args,'support':np.ones_like(args['support'])}
            metric=WireMetric(scored_args,geometry)
            scores={k:metric(v)for k,v in rendered.items()}
            gap=int(metric.gap.sum())
        else:
            scores={k:photo_metrics(args,v)for k,v in rendered.items()}
            gap=0
        cases.append(dict(source=row['source'],input=row['input'],prediction=row['predictions'],
                          transport=moved['predictions'],scores=scores,gates=gates,gap_pixels=gap))
    wires=[r for r in cases if r['source']['kind']=='wire']
    photos=[r for r in cases if r['source']['kind']=='natural']
    assert len(wires)==len(photos)==24 and sum(r['gap_pixels']>0 for r in wires)==12
    by_wire={f'{a} vs {b}':summarize(wires,a,b)for a,b in COMPARISONS}
    by_photo=photo_summary(photos,COMPARISONS)
    write_json(ROOT/'review.json',dict(driver=reference(__file__),plan=plan,mask_policy=mask_policy,wire=wires,photo=photos,
                 release=release,matched_positive_recovery=doses,matched_development_flat_DN16=budget,
                 wire_summary=by_wire,photo_summary=by_photo,elapsed_seconds=time.monotonic()-start))
    print('review complete',len(cases),round(time.monotonic()-start,2),flush=True)


if __name__=='__main__':
    main()
