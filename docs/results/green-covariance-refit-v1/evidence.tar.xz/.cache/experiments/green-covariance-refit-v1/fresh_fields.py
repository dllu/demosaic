"""Bind new wire and natural confirmation photos, then collect frozen model outputs."""
from dataclasses import asdict,replace
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.with_name('scene-mixture-wire-gaps-v1')
sys.path.insert(0,str(PREVIOUS))
from collect import BOX,PRIOR,scene_preview,encode
from fresh import networks,prepare_eval
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe,scene_crop_boxes
from demosaic.scene_training_data import scene_seed

import wire_math

SEED=202611191034
KEYS=('packed','variance','colors','wb','matrix','target')
WIRE_PATH=ROOT.with_name('query-gap-shoulders-v1')/'prepare.py'
CANDIDATE_SOURCE=ROOT.with_name('query-exterior-colour-v1')/'plan.json'
FIRST_PROFILE={'name':'iso6400','shot':.00128,'read':6.5536e-6,'exposure':.33}
TRAIN_AUDIT=Path('docs/results/full-corpus-long100k-training-v1/source-audit.json')
ROLES=('present','outside-only','strong-only','quiet')


def read_rows(path):
    with path.open()as source:
        yield from map(json.loads,source)


def make_plan():
    origin=reference(CANDIDATE_SOURCE)
    eligible_plan=read_json(checked(origin))
    locked=reference(PREVIOUS/'predictions.json')
    older=read_json(checked(locked))
    blocked_ids=set()
    blocked_content=set()
    for ref in (eligible_plan['training_manifest'],):
        for row in read_rows(checked(ref)):
            blocked_ids.add(row['id'])
            blocked_content.add(row['cache_sha256'])
    for ref in (eligible_plan['cohort'],):
        for row in read_json(checked(ref))['source_metadata']:
            blocked_ids.add(row['id'])
            blocked_content.add(row['cache_sha256'])
    for panel in older['protocol'].values():
        for row in read_json(checked(panel['plan']))['sources']:
            blocked_ids.add(row['source']['id'])
            blocked_content.add(row['source']['cache_sha256'])
    visits=read_json(checked(reference(TRAIN_AUDIT)))
    assert visits['checkpoint']['sha256']==older['checkpoints']['100k']['sha256']
    bins=[]
    for row in read_rows(checked(eligible_plan['candidate_manifest'])):
        if row['split']=='val' and row['bin_factor']==4 and min(row['shape'][:2])>=512 and math.prod(row['shape'][:2])<=2_200_000:
            if row['id'] not in blocked_ids and row['cache_sha256'] not in blocked_content:
                bins.append(row)
    bins.sort(key=lambda row:hashlib.sha256(f"{SEED}/{row['id']}".encode()).digest())
    unique=[]
    for row in bins:
        cache_hash=row['cache_sha256']
        if cache_hash in blocked_content:
            continue
        unique.append(row)
        blocked_content.add(cache_hash)
        if len(unique)==48:
            break
    assert len(unique)==48
    shortlist={r['id'] for r in unique}
    short_hashes={r['cache_sha256'] for r in unique}
    photo_visits=0
    for trace in visits['source_traces']:
        for update in read_rows(checked(trace)):
            for source in update['sources']:
                if source['kind']!='photographic':
                    continue
                photo_visits+=1
                assert source['source_id'] not in shortlist and source['cache_sha256'] not in short_hashes
    assert photo_visits==559808
    selected=[]
    for i,source in enumerate(unique):
        mode='wire' if i<24 else 'natural'
        h,w=(int(n)//2*2 for n in source['shape'][:2])
        box,=scene_crop_boxes((h,w),patch_size=512 if mode=='wire'else 256,count=1,seed=scene_seed(SEED,i,'source-box'))
        camera=asdict(sample_scene_recipe(scene_seed(SEED,i,'camera')))
        camera.update(pattern=tuple(PATTERNS)[(i+i//4)%4],black=.03)
        record=dict(source=source,index=i,box=box,camera=camera,kind=mode)
        if mode=='wire':
            rng=np.random.default_rng(scene_seed(SEED,i,'geometry'))
            incl=rng.uniform(.42,.85,2)
            f=rng.uniform(.082,.128,2)
            record['geometry']=dict(family=('ellipse','strip','smooth-dip','contrast-step')[i%4],
                frequency=[[f[0]*np.cos(incl[0]),f[0]*np.sin(incl[0])],
                           [f[1]*np.cos(incl[1]),-f[1]*np.sin(incl[1])]],
                phase=rng.uniform(-np.pi,np.pi,2).tolist(),
                strength=list(rng.uniform((.009,.007),(.015,.0115))),
                width=rng.uniform(.088,.132,2).tolist(),edge=float(rng.uniform(-25,25)),
                gap_center=rng.uniform(-24,24,2).tolist(),gap_width=float(rng.uniform(20,36)),
                gap_length=float(rng.uniform(36,58)),gap_orientation=float(rng.uniform(0,np.pi)),
                angle=float(rng.uniform(-1.6,1.6)),tint=rng.uniform(.07,.16,3).tolist())
        selected.append(record)
    plan=dict(driver=reference(__file__),source=origin,source_pool=eligible_plan['candidate_manifest'],
              rejected_full427=eligible_plan['cohort'],excluded_prior_wires=locked,
              training_manifest=eligible_plan['training_manifest'],parent_visit_audit=reference(TRAIN_AUDIT),
              verified_parent_visits=photo_visits,checkpoints=older['checkpoints'],old_coefficients=older['coefficients'],
              previous_fit=older['fit'],wire_fixture_code=reference(WIRE_PATH), extracted_wire_functions=reference(wire_math.__file__),
              natural_fixture_code=reference(prepare_eval.__file__),seed=SEED,profile=FIRST_PROFILE,sources=selected,
              scope='48 new exact-target sources outside full427, prior wire calibration and all recorded Corpus 100k visits.')
    write_json(ROOT/'plan.json',plan)
    return plan


def capture(photo,profile):
    if photo['kind']=='wire':
        targets,_,support,weak=wire_math.exact(wire_math.decode(photo['source'],photo['box']),photo['geometry'])
        seeds=[scene_seed(SEED,photo['index'],role)for role in ROLES]
        camera={**photo['camera'],**{k:profile[k]for k in ('shot','read','exposure')}}
        observations=[observe_scene(scene,replace(sample_scene_recipe(SEED),**(camera|{'noise_seed':seed})))
                      for scene,seed in zip(targets,seeds,strict=True)]
        values={key:np.stack([getattr(x,key).numpy()for x in observations])for key in KEYS}
        assert values['packed'].shape==(4,4,256,256)
        data={key:values[key][0]for key in ('colors','wb','matrix')}
        assert all(np.all(values[k]==values[k][0])for k in data)
        data.update({key:values[key][...,64:192,64:192]for key in ('packed','variance')})
        data.update(target=values['target'][...,128:384,128:384],scene_packed=values['packed'][1],
                    support=support.numpy()[128:384,128:384],weak_linear=weak.numpy()[...,128:384,128:384])
        return data,BOX
    prepare_eval.SEED=SEED
    image=prepare_eval.load_photo(photo)
    present=prepare_eval.patch(image,photo['box'],.22)
    absent=prepare_eval.patch(image,photo['box'],0)
    roles={'present':present,'masked-fine':absent,'flat':prepare_eval.flat_patch(absent)}
    data=prepare_eval.observed_group(image,roles,photo,profile,'independent')
    return data,photo['box']


@torch.inference_mode()
def run_models(models,data,box,profile):
    parent,spatial,v120=models
    for m in (parent,spatial.base,v120):
        m.set_noise(profile['shot'],profile['read'])
    camera=[torch.from_numpy(data[k]).cuda()for k in ('colors','wb','matrix')]
    raw=torch.from_numpy(data['packed']).cuda()
    variance=torch.from_numpy(data['variance']).cuda()
    scene=torch.from_numpy(data['scene_packed']).cuda()
    n=len(raw)
    query=[v.contiguous(memory_format=torch.channels_last)for v in (raw,variance)]+[v[None].expand(n,*v.shape)for v in camera]
    x,y,w,h=(v//2 for v in box)
    cache,views=[],[]
    with ieee_fp32():
        for pixels in raw:
            painted=scene.clone()
            painted[:,y:y+h,x:x+w].copy_(pixels)
            assert torch.equal(painted[:,y:y+h,x:x+w],pixels)
            preview,grid=scene_preview(painted,*camera,long_side=1024,exposure=1.)
            cache.append(encode(spatial,preview,grid))
            views.append(fingerprint(preview.cpu()))
        output={'parent':parent(*query).cpu().numpy(),'spatial':spatial(*query,scene=cache,boxes_xywh=[box]*n).cpu().numpy(),
                 'v120':v120(*query).cpu().numpy()}
    assert all(v.shape==(n,3,256,256) and np.isfinite(v).all()for v in output.values())
    return output,views


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    plan=make_plan()
    print('frozen',len(plan['sources']),flush=True)
    parent,spatial=networks(plan['checkpoints'])
    anchor=plan['checkpoints']['V120']
    v120,state=load_checkpoint(checked(anchor),'cuda',tiled_inference=True)
    assert state['loaded_sha256']==anchor['sha256'] and 'ema' in state
    del state
    v120.eval().to(memory_format=torch.channels_last)
    out=ROOT/'fresh'
    out.mkdir(exist_ok=True)
    rows=[]
    start=time.monotonic()
    seconds=0.
    for source in plan['sources']:
        data,box=capture(source,plan['profile'])
        before=time.monotonic()
        estimates,views=run_models((parent,spatial,v120),data,box,plan['profile'])
        seconds+=time.monotonic()-before
        a=out/f"{source['index']:02d}-input.npz"
        b=out/f"{source['index']:02d}-prediction.npz"
        np.savez_compressed(a,**data)
        np.savez_compressed(b,**estimates)
        rows.append(dict(source=source,box=box,input=reference(a),predictions=reference(b),preview_fingerprints=views))
        if len(rows)%8==0:
            print(len(rows),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/'fresh.json',dict(driver=reference(__file__),plan=reference(ROOT/'plan.json'),
                   rows=rows,precision='CUDA IEEE FP32 EMA',inference_seconds=seconds,
                   wall_seconds=time.monotonic()-start))


if __name__=='__main__':
    main()
