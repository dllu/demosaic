"""Fit response and damping gains against frozen per-control error budgets."""
import time

import numpy as np
from scipy.optimize import minimize

from fresh_fields import ROOT,PREVIOUS,BOX
from green_phase_power import FORMS,ROI,algebra,bases,synthesize
from scoring import WireMetric,photo_metrics,summarize,remove_basis,FINE
from collect import load_data
from upper import SCORE,tile_dct,luma,load,metadata
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

DAMPED=np.array([-.5,0.])
RAW_ARMS=('Corpus 100k','V120','Spatial 40k','Band-limited blend','Bayer-gated damping')
COMPONENTS=('damping','recovery')


def proposed(parent,spatial,args,box,profile,fit):
    clean,prior,delta,gates=[],[],{k:[]for k in FORMS},[]
    for i in range(len(parent)):
        raw={k:args[k]for k in ('colors','wb','matrix')}|{'packed':args['packed'][i]}
        old,damp,candidates,field_info=bases(parent[i],spatial[i],raw,profile,args['scene_packed'],box,fit)
        clean.append(old)
        prior.append(damp)
        gates.append(field_info)
        for key,field in candidates.items():
            delta[key].append(field)
    return np.stack(clean),np.stack(prior),{k:np.stack(v)for k,v in delta.items()},gates


def covariance_vectors(base,damp,field,args,score_view):
    x,y,w,h=score_view
    ox,oy,_,_=ROI
    view=np.s_[...,y:y+h,x:x+w]
    delta_view=np.s_[...,y-oy:y-oy+h,x-ox:x-ox+w]
    arrays=np.stack((base[view],damp[delta_view],field[delta_view]))
    return luma(arrays,args['wb'],args['matrix'])


def gram(rows,dose):
    data=np.asarray(rows).reshape(3,-1)*65535/np.sqrt(dose)
    return data@data.T


def wire_terms(args,base,damp,field,metric):
    observe=covariance_vectors(base,damp,field,args,(64,64,128,128))
    intact=remove_basis((observe[:,0]-observe[:,2])[:,metric.intact],metric.intact_nuisance)
    response=100*(intact@metric.truth_weak)/metric.strength
    intact[0]-=metric.truth_weak
    quiet=observe[:,3]-observe[:,3].mean(axis=(1,2),keepdims=True)
    q={'wire_increment':gram(intact,intact.shape[-1]),'wire_flat':gram(quiet,128*128)}
    if metric.gap.any():
        absolute=observe[:,0][:,metric.gap].copy()
        absolute[0]-=metric.truth[0][metric.gap]
        leakage=(observe[:,1]-observe[:,2])[:,metric.gap].copy()
        leakage[0]-=(metric.truth[1]-metric.truth[2])[metric.gap]
        samples=absolute.shape[1]
        q.update(gap_absolute=gram(absolute,samples),
                 gap_weak=gram(absolute@metric.weak_basis,samples),
                 gap_exterior=gram(leakage@metric.weak_basis,samples),
                 gap_strong=gram(absolute@metric.strong_basis,samples))
    return q,response


def photo_terms(args,base,damp,field):
    x,y,w,h=SCORE
    target=tile_dct(luma(args['target'][...,y:y+h,x:x+w],args['wb'],args['matrix']))[...,FINE]
    outputs=tile_dct(covariance_vectors(base,damp,field,args,SCORE))[...,FINE]
    prediction=(outputs[:,0]-outputs[:,1]).reshape(3,-1)
    increment=(target[0]-target[1]).ravel()
    support=increment@increment
    response=(100*prediction@increment/support) if support else None
    prediction[0]-=increment
    quiet=outputs[:,2].copy()
    quiet[0]-=target[2]
    return {'photo_flat':gram(quiet,96**2),'photo_increment':gram(prediction,96**2)},response


def development(fit):
    anchor=reference(PREVIOUS/'predictions.json')
    prior=read_json(checked(anchor))
    wire=[]
    for case in prior['rows']:
        if case['panel']!='development' or case['case']['noise']!='iso6400':
            continue
        args=load_data(case['case'])
        with np.load(checked(case['prediction']),allow_pickle=False)as z:
            base,damp,options,gates=proposed(z['Corpus 100k'],z['aligned'],args,BOX,case['profile'],fit)
        metric=WireMetric(args,case['source']['geometry'])
        wire.append(dict(source=case['source']['source']['id'],input=case['prediction'],gates=gates,
                    terms={k:wire_terms(args,base,damp,field,metric)for k,field in options.items()}))
    assert len(wire)==24
    older=read_json(checked(prior['fit']))
    _,review,_,_=metadata()
    photos=[]
    calibration=set(older['split']['calibration'])
    for case in review['source_metrics']:
        if case['source'] not in calibration or case['profile']!='iso6400' or case['draw']!='independent':
            continue
        setup,data,rgb=load(case)
        base,damp,options,gates=proposed(rgb['100k'],rgb['spatial--matching'],data,setup['box'],setup['profile'],fit)
        photos.append(dict(source=case['source'],input=case['prediction_receipt'],gates=gates,
                           terms={k:photo_terms(data,base,damp,field)for k,field in options.items()}))
    assert len(photos)==16
    return wire,photos,anchor


def score_constraints(q,w):
    full=np.r_[1.,w]
    return float(full@q@full)


def fit_family(mode,wire,photos,reserve=0.):
    wire_terms_all=[r['terms'][mode]for r in wire]
    photo_terms_all=[r['terms'][mode]for r in photos]
    errors={key:np.mean([v[key]for v,_ in wire_terms_all+photo_terms_all if key in v],axis=0)
            for key in sorted(set().union(*(v.keys()for v,_ in wire_terms_all+photo_terms_all)))}
    responses={key:np.mean([a for _,a in rows if a is not None],axis=0)
               for key,rows in (('wire',wire_terms_all),('photo',photo_terms_all))}
    prior=np.r_[1.,DAMPED]
    budgets={key:score_constraints(q,DAMPED) for key,q in errors.items()}
    for key in budgets:
        if not key.startswith('gap_'):
            budgets[key]+=reserve*max(0.,float(errors[key][0,0])-budgets[key])
    prior_response={key:float(v@prior)for key,v in responses.items()}
    desired={key:float(max(.025,v[0]-prior_response[key]))for key,v in responses.items()}
    def feasible(z):
        weights=np.r_[1.,z[:2]]
        largest_loss=[]
        for key,q in errors.items():
            largest_loss.append((budgets[key]-weights@q@weights)/max(budgets[key],1.))
        for key,v in responses.items():
            largest_loss.append((float(v@weights)-prior_response[key])/desired[key]-z[2])
        return np.array(largest_loss)
    result=minimize(lambda x:-x[2],np.r_[DAMPED,0.],method='SLSQP',bounds=((-2.,0.),(0.,2.),(0.,4.)),
                    constraints=[{'type':'ineq','fun':feasible}],
                    options={'ftol':1e-11,'maxiter':250})
    assert np.min(feasible(result.x))>=-1e-7,(mode,result.message,feasible(result.x))
    # An optimum with no gain above the previous damping deliberately keeps
    # its known weights. This also defines the no-recovery control.
    values=result.x if result.x[2]>1e-7 else np.r_[DAMPED,0.]
    chosen,retention=values[:2],values[2]
    return dict(weights=chosen.tolist(),balanced_fraction_recovered=float(retention),solver_success=bool(result.success),
                optimizer_message=result.message,constraint_minimum=float(np.min(feasible(values))),budget_mse=budgets,
                chosen_mse={key:score_constraints(q,chosen)for key,q in errors.items()},
                response={key:dict(previous=prior_response[key],band_limited=float(v[0]),
                            fitted=float(v@np.r_[1.,chosen]))for key,v in responses.items()})


def serializable(rows):
    return [{**r,'terms':{k:[{name:q.tolist()for name,q in error.items()},
                             None if response is None else response.tolist()]
                          for k,(error,response) in r['terms'].items()}}for r in rows]


def main():
    start=time.monotonic()
    protocol=reference(ROOT/'refit-plan.json')
    declared=read_json(checked(protocol))
    extra=reference(ROOT/'budget-plan.json')
    assert read_json(checked(extra))['base_plan']==protocol
    assert declared['development']==reference(PREVIOUS/'predictions.json')
    locked=reference(PREVIOUS/'scores.json')
    prior_receipt=read_json(checked(locked))
    assert prior_receipt['gains']['supported']==DAMPED[0]
    fixed=read_json(checked(read_json(checked(declared['development']))['fit']))
    model=fixed['fits']['limited_guard']
    check=algebra()
    wire,photos,anchor=development(model)
    answers={k:fit_family(k,wire,photos)for k in FORMS}
    reserve={k:fit_family(k,wire,photos,reserve=.5)for k in FORMS}
    write_json(ROOT/'fit.json',dict(driver=reference(__file__),protocol=protocol,development=anchor,
               base_composition=locked,budget_plan=extra,checks=check,weights=answers,half_saved_budget=reserve,wire=serializable(wire),photos=serializable(photos),
               wall_seconds=time.monotonic()-start))
    for name,modes in (('strict',answers),('half saved budget',reserve)):
        for k,v in modes.items():
            print(name,k,v['weights'],v['balanced_fraction_recovered'],v['response'],flush=True)


if __name__=='__main__':
    main()
