"""Bind the closed constraints, fresh data, endpoint transfer and native comparison evidence."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from fresh_fields import ROOT,PREVIOUS,PRIOR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

IMAGES=Path('docs/images')/ROOT.name
RESULTS=Path('docs/results')/ROOT.name
MATCH=Path('docs/results/scene-full-epoch-v1/paired-prefix-047500.json')


def keep(panel):
    file=checked(panel['image'])
    name=Path(file.parent.name)/file.name
    output=IMAGES/name
    output.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(file,output)
    assert reference(output)['sha256']==panel['image']['sha256']
    pixels=np.asarray(Image.open(output).convert('RGB'))
    images={}
    for record in panel['panels']:
        x,y,w,h=record['png_xywh']
        assert (w,h)==(160,160)
        images[record.get('label',record.get('name'))]=pixels[y:y+h,x:x+w]
    panel['image']['path']=str(name)
    return images


def main():
    RESULTS.mkdir(parents=True,exist_ok=True)
    labels=('plan','fresh','refit-plan','budget-plan','fit','innovation-plan','innovation-fit',
            'transport-plan','transport-fresh','transport-standing','review-plan','continuous-dip-definition','review','native','extra-native')
    receipts={key:reference(ROOT/f'{key}.json')for key in labels}
    values={k:read_json(checked(ref))for k,ref in receipts.items()}
    fit=values['fit']
    innovation=values['innovation-fit']
    fresh=values['fresh']
    transferred=values['transport-fresh']
    review=values['review']
    native=deepcopy(values['native'])
    train=reference(MATCH)
    match=read_json(checked(train))
    assert match['matched_to_update']==47500 and match['matched_marker']==values['transport-plan']['match']
    for mode,checkpoint in values['transport-plan']['checkpoints'].items():
        assert checkpoint==match['arms'][mode]['checkpoint']
        checked(checkpoint)
    assert receipts['plan']==fresh['plan']
    assert receipts['transport-plan']==transferred['plan']==values['transport-standing']['plan']
    assert receipts['review']==native['scored'] and receipts['transport-standing']==native['standing_proof']
    assert receipts['continuous-dip-definition']==review['mask_policy']
    assert receipts['review-plan']==review['plan']
    assert all(row['weights']==[-.5,0.] for row in fit['weights'].values())
    assert all(row['weights']==[-.5,0.] for row in innovation['strict'].values())
    assert all(abs(row['weights'][1])<1e-10 for row in innovation['half_corpus_budget'].values())
    assert len(review['wire'])==len(review['photo'])==24
    assert len({r['source']['source']['id']for r in review['wire']+review['photo']})==48
    assert all(a['input']==b['input'] for a,b in zip(fresh['rows'],transferred['rows'],strict=True))
    assert len(native['views'])==2 and len(native['standing'])==8
    for row in native['views']:
        panels=keep(row['board'])
        triplet=keep(row['triplet'])
        assert list(triplet)==['Noisy Malvar','47.5k blend','Exact GT']
        assert all(np.array_equal(pixels,panels[key])for key,pixels in triplet.items())
    extra=deepcopy(values['extra-native'])
    assert receipts['review']==extra['scored']
    panels=keep(extra['view']['board'])
    triplet=keep(extra['view']['triplet'])
    assert list(triplet)==['Noisy Malvar','Local-only 47.5k','Exact GT']
    assert all(np.array_equal(pixels,panels[key])for key,pixels in triplet.items())
    for row in native['standing']:
        panels=keep(row['board'])
        assert '47.5k blend'in panels and 'ISO100 AHD reference'in panels
        if row['id'].startswith('mesh-'):
            assert all(key in panels for key in ('ISO6400 camera JPEG','ISO100 camera JPEG'))
    manifest=IMAGES/'manifest.json'
    write_json(manifest,{**native,'local_example':extra,'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    archive=RESULTS/'evidence.tar.xz'
    files=[*ROOT.glob('*.py'),*ROOT.glob('*.log'),*(checked(ref)for ref in receipts.values()),checked(train),
           PREVIOUS/'collect.py',PREVIOUS/'scoring.py',PREVIOUS/'support.py',PRIOR/'upper.py',
           PRIOR/'fresh.py',PRIOR/'native.py',PRIOR/'audit_delivery.py',Path('scripts/report_scene_wave_guides.py'),
           Path('configs/gfx-qualitative-20231231.json'),Path('configs/gfx-green-mesh-20231231.json'),
           checked(values['plan']['extracted_wire_functions']),checked(values['plan']['wire_fixture_code']),
           checked(values['plan']['natural_fixture_code']),checked(values['plan']['old_coefficients'])]
    archive_files={str(f.absolute().relative_to(Path.cwd())):f for f in files}
    with tarfile.open(archive,'x:xz',preset=4)as out:
        for name,file in sorted(archive_files.items()):
            out.add(file,arcname=name,recursive=False)
    with tarfile.open(archive)as source:
        for name,file in archive_files.items():
            with source.extractfile(name)as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==reference(file)['sha256']
    result=dict(receipts=receipts,checkpoints=values['plan']['checkpoints'],transport_checkpoints=values['transport-plan']['checkpoints'],
               paired_training=train,archive=reference(archive),views=reference(manifest),phase_checks=fit['checks'],
               interpolation_error=innovation['interpolation_max_error'],positive_geometry_fit=fit['weights'],
               positive_measurement_fit=innovation['strict'],innovation_half_corpus_budget=innovation['half_corpus_budget'],
               development_gap_ablation=innovation['original_gap_ablation'],
               released_damping_coefficient=review['release'],fitted_diagnostic_doses=review['matched_positive_recovery'],
               matched_development_flat_RMS_DN16=review['matched_development_flat_DN16'],
               ISO6400_wires=review['wire_summary'],ISO6400_photos=review['photo_summary'],
               scoped_inference_seconds={'prior_models':fresh['inference_seconds'],
                                          'transport_queries_wall':transferred['scoped_inference_wall_seconds']})
    write_json(RESULTS/'publication.json',result)
    print(len(archive_files),'verified archive members,',len(list(IMAGES.rglob('*.png'))),'native images',flush=True)


if __name__=='__main__':
    main()
