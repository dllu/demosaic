"""Replay measured donor covariance on the natural ISO400 and ISO6400 panel."""
import argparse
import hashlib
from pathlib import Path
import sys
import time

import numpy as np

from covariance import ARMS, ROOT, bind_donors, correction
from demosaic.archive_metrics import linear_rgb, noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board

MONITOR=ROOT.with_name("scene-full-epoch-v1")/"review-full-040000/evaluation/results.json"
sys.path.insert(0,str(ROOT.with_name("scene-local-contrast-2400-v1")))
import measure

ARMS=("parent",*ARMS)
LABELS={"parent":"Corpus 100k EMA","full":"Exterior covariance","diagonal":"Exterior diagonal power",
        "isotropic":"Equal power by direction","transpose":"Transposed covariance",
        "distant":"Distant texture covariance",
        "coherent_full":"Scene-weighted parent pattern","coherent_isotropic":"Parent pattern",
        "coherent_transpose":"Transposed-weighted pattern"}
SEED="whole-scene-donor-covariance-20261119-v1"
QUIET_BUDGET=.25
SCALE=65535.**2/(36*16*16)


def split(rows):
    keys=list({r["source"] for r in rows})
    keys.sort(key=lambda key:hashlib.sha256((SEED+"/"+key).encode()).hexdigest())
    return {"calibration":keys[:16],"test":keys[16:]}


def fixture(item):
    pred=read_json(checked(item["prediction_receipt"]))
    case=read_json(checked(pred["case"]))
    with np.load(checked(case["input"]),allow_pickle=False) as file:
        data={k:file[k] for k in ("packed","variance","colors","wb","matrix","target","scene_packed")}
    assert all(fingerprint(v)==case["fingerprints"][k] for k,v in data.items())
    with np.load(checked(pred["saved"]),allow_pickle=False) as file:
        base=file["100k"]
    return pred,case,data,base


def fire(item,plan_panel):
    pred,case,data,base=fixture(item)
    x,y,w,h=case["box"]
    local=data["packed"]
    cfa,wb,matrix=(data[k] for k in ("colors","wb","matrix"))
    assert local.shape==(3,4,128,128) and (w,h)==(256,256)
    context=bind_donors(data["scene_packed"],cfa,case["box"])
    noise=case["profile"]
    outputs={k:np.zeros_like(base) for k in ARMS}
    traced={k:[] for k in ARMS[1:]}
    for i,tile in enumerate(local):
        fields,counts=correction(tile,base[i],cfa,wb,matrix,noise,context)
        for name in ARMS[1:]:
            outputs[name][i]=fields[name]
            traced[name].append(counts[name])
    return case,data,base,outputs,context,traced


def coefficients(rgb,supervision,roi):
    luma=np.einsum("bchw,c->bhw",linear_rgb(rgb,supervision),measure.LUMA)
    return measure.coeffs(luma,roi)


def stats(target,base,change,site_filter):
    expected=target[0,:,site_filter]-target[1,:,site_filter]
    made=base[0,:,site_filter]-base[1,:,site_filter]
    delta=change[0,:,site_filter]-change[1,:,site_filter]
    fit=target[0,:,site_filter]
    p=base[0,:,site_filter]
    u=change[0,:,site_filter]
    q=base[2,:,site_filter]-target[2,:,site_filter]
    v=change[2,:,site_filter]
    def quadrature(residual,movement):
        return [float(np.sum(z)*SCALE) for z in (residual**2,residual*movement,movement**2)]
    return {"truth":float(np.square(expected).sum()),"response":[float(np.sum(r*expected)) for r in (made,delta)],
            "increment":quadrature(made-expected,delta),"present":quadrature(p-fit,u),"quiet":quadrature(q,v)}


def summarize(rows,settings):
    divisions=split(rows)
    calibration=set(divisions["calibration"])
    holdout=set(divisions["test"])
    ref=[r for r in rows if r["source"] in calibration and r["profile"]=="iso6400"]
    assert len(ref)==16
    noise={arm:float(np.mean([np.sqrt(r["metrics"][arm]["fine"]["quiet"][2])for r in ref])) for arm in ARMS[1:]}
    budget=min(QUIET_BUDGET,*noise.values())
    assert budget>0
    doses={"parent":0.}|{arm:budget/value for arm,value in noise.items()}
    rng=np.random.default_rng(197611190818)
    metrics={}
    example=[]
    for subset,selected in (("calibration",calibration),("test",holdout)):
        for iso in ("iso400","iso6400"):
            keys=sorted([r for r in rows if r["profile"]==iso and r["source"] in selected],key=lambda r:r["source"])
            assert len(keys)==len(selected)
            draws=np.vstack((np.arange(len(keys)),rng.integers(len(keys),size=(10000,len(keys)))))
            # keep both the raw unit response and the equal-quiet comparison
            table={}
            for policy in ("unit dose","matched quiet"):
                results={}
                row_out={}
                for arm in ARMS:
                    dose=doses[arm] if policy=="matched quiet" else 1.
                    per_band={}
                    for band in measure.BANDS:
                        fields=[r["metrics"][arm][band] for r in keys]
                        mat=np.asarray([v["response"] for v in fields])
                        desired=np.asarray([v["truth"] for v in fields])
                        projected=mat[:,0]+dose*mat[:,1]
                        value={"response_pp":100*projected[draws].sum(1)/desired[draws].sum(1)}
                        for m in ("increment","present","quiet"):
                            y=np.asarray([v[m] for v in fields])
                            error2=y[:,0]+2*dose*y[:,1]+dose**2*y[:,2]
                            value[m+"_RMS_DN16"]=np.sqrt(np.maximum(0,error2[draws].mean(1)))
                        value["quiet_added_RMS_DN16"]=np.sqrt(np.asarray([v["quiet"][2]for v in fields]))[draws].mean(1)*dose
                        per_band[band]=value
                        if policy=="matched quiet" and band=="fine":
                            row_out[arm]={"increment_RMS_DN16":
                                np.sqrt(np.maximum(0,np.asarray([v["increment"][0]+2*dose*v["increment"][1]+dose*dose*v["increment"][2]for v in fields]))).tolist()}
                    results[arm]=per_band
                named={}
                for band in measure.BANDS:
                    means={name:{k:float(v[0]) for k,v in val[band].items()} for name,val in results.items()}
                    test={}
                    for a,b in [(k,"parent") for k in ARMS[1:]]+[("full","isotropic"),("full","diagonal"),("full","transpose"),("full","distant"),
                            ("coherent_full","coherent_isotropic"),("coherent_full","coherent_transpose")]:
                        values={key:results[a][band][key]-results[b][band][key] for key in results[a][band]}
                        test[f"{a}_vs_{b}"]={key:{"point":float(v[0]),"interval":np.quantile(v[1:],(.025,.975)).tolist()}for key,v in values.items()}
                    named[band]={"means":means,"delta":test}
                table[policy]=named
                if subset=="test" and iso=="iso6400" and policy=="matched quiet":
                    for arm in ("full","coherent_full","coherent_isotropic"):
                        delta=np.asarray(row_out[arm]["increment_RMS_DN16"])-row_out["parent"]["increment_RMS_DN16"]
                        order=np.argsort(delta)
                        for j in (order[0],order[-1]):
                            example.append({"arm":arm,"source":keys[int(j)]["source"],"increment_change":float(delta[j]),"case_index":keys[int(j)]["index"]})
            metrics[f"{subset}/{iso}"]=table
    return {"split":divisions,"dose":doses,"calibration_quiet_unit":noise,"quiet_budget":budget,"metrics":metrics,"example":example}


def main(stage):
    started=time.monotonic()
    monitor=reference(MONITOR)
    readout=read_json(checked(monitor))
    plan=read_json(checked(readout["plan"]))
    settings=read_json(checked(plan["panel"]))
    items=[item for item in readout["source_metrics"] if item["draw"]=="independent"]
    if stage=="screen":
        items=items[:24]
    records=[]
    for item in items:
        case,data,base,outputs,context,counts=fire(item,settings)
        sample={key:np.broadcast_to(data[key][None],(3,*data[key].shape)) for key in ("wb","matrix")}
        sample["exposure"]=case["profile"]["exposure"]
        reproduced=measure.parts(sample,base,data["target"],settings)
        assert reproduced==item["metrics"]["100k"]
        roi=settings["score_ROI_xywh"]
        target=coefficients(data["target"],sample,roi)
        anchor=coefficients(base,sample,roi)
        value={}
        for name,result in outputs.items():
            shift=coefficients(result,sample,roi)
            value[name]={label:stats(target,anchor,shift,mask) for label,mask in measure.BANDS.items()}
        records.append({"source":item["source"],"index":case["case"],"profile":item["profile"],"draw":item["draw"],
                 "prediction_receipt":item["prediction_receipt"],"metrics":value,"active":counts,
                 "donors":context["cov_count"] if context else 0,
                 "donor_origins_xy":context["donor_origins_xy"] if context else []})
        print(case["case"],item["profile"],[np.sum(r) for r in counts.values()],flush=True)
    receipt={"driver":reference(__file__),"operator":reference(ROOT/"covariance.py"),"stage":stage,
             "photo_panel":monitor,"settings":plan["panel"],"checkpoint":plan["models"]["100k"],
             "rows":records,"wall_seconds":time.monotonic()-started}
    if stage=="full":
        assert len(records)==128 and len({r["source"]for r in records})==64
        receipt["evaluation"]=summarize(records,settings)
    write_json(ROOT/f"{stage}.json",receipt,replace=True)


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("stage",choices=("screen","full"))
    main(p.parse_args().stage)
