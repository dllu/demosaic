"""Render the same covariance policies on exact targets and both standing scenes."""
from pathlib import Path
import sys

import numpy as np
import torch
from PIL import Image

from covariance import ROOT, bind_donors, correction
from evaluate import fire, LABELS, MONITOR
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

STUDY=ROOT.with_name("scene-full-epoch-v1")/"review-native-040000"
sys.path.insert(0,str(ROOT.with_name("paired-luminance-detail-v1")))
from render import native_png


def native_exact(full):
    data=read_json(checked(full))
    cases=read_json(checked(data["photo_panel"]))
    setup=read_json(checked(data["settings"]))
    estimates = data["evaluation"]["dose"]
    roster=[r for r in data["evaluation"]["example"] if r["arm"]=="coherent_full"]
    assert len(roster)==2 and len({r["source"] for r in roster})==2
    images=[]
    output=ROOT/"exact"
    output.mkdir(exist_ok=True)
    for selection in roster:
        target=selection["source"]
        item=next(r for r in cases["source_metrics"] if r["source"]==target and (r["profile"],r["draw"])==("iso6400","independent"))
        case,arrays,parent,updates,ctx,_=fire(item,setup)
        clear=arrays["target"][0]
        src=setup["rows"][case["case"]]
        assert src["source"]["id"]==target
        r={k:arrays[k][None] for k in ("colors","matrix","wb")}
        r["packed"]=arrays["packed"][:1]
        names=("full","coherent_full","coherent_isotropic","coherent_transpose")
        outputs=[noisy_malvar(r)[0], parent[0]]
        outputs+=[parent[0]+np.float32(estimates[arm])*updates[arm][0] for arm in names]
        # Full standard dose directly shows texture leakage in the permissive rule.
        outputs+=[parent[0]+updates["full"][0],clear]
        titles=("Noisy Malvar",LABELS["parent"],*(LABELS[k]for k in names),"Unscaled covariance","Exact GT")
        record=native_board(output,f'{case["case"]:03d}-iso6400-covariance',outputs,r,
            {"source":src["source"],"native_box":case["box"],"CFA":src["camera"]["pattern"],
             "checkpoint":data["checkpoint"],"profile":case["profile"],"role":"present",
             "input":case["input"],"evaluation":full,"dose":estimates,"choice":selection,
             "observation":item["prediction_receipt"],"ADC_bits":16,"black":.03},
             labels=titles,triplet_indices=(0,titles.index(LABELS["coherent_full"]),len(titles)-1),
             exposure=1/case["profile"]["exposure"],contrast=2,roi=tuple(setup["native_display_ROI_xywh"]))
        images.append(record)
    return images


def raw_full(binding):
    raw,meta=read_raw(checked(binding))
    rows,cols=raw.shape
    packed=np.stack([raw[dy:rows//2*2:2,dx:cols//2*2:2] for dy in range(2) for dx in range(2)])
    return packed,np.asarray(color_indices(meta.pattern))


def panel_cells(spec):
    with Image.open(checked(spec["image"])) as image:
        return {r["label"]:np.asarray(image.crop((x,y,x+w,y+h)).convert("RGB"))
                for r in spec["panels"] for x,y,w,h in (r["png_xywh"],)}


def native_standing(full):
    receipt=read_json(checked(full))
    doses=receipt["evaluation"]["dose"]
    report=reference(STUDY/"work/render/result.json")
    before=read_json(checked(report))
    origin=read_json(STUDY/"plan.json")
    cases={r["id"]:r for r in origin["observations"]}
    baseline=read_json(checked(before["collections"]["parent100k"]))
    assert baseline["checkpoint"]["sha256"]==receipt["checkpoint"]["sha256"]
    prior={r["id"]:r for r in baseline["records"]}
    manifest=read_json(Path("docs/images/bayer-single-direction-v1/manifest.json"))
    witnesses={r["id"]:r for r in manifest["standing"]}
    folder=ROOT/"standing"
    folder.mkdir(exist_ok=True)
    out=[]
    for kind in ("main","mesh"):
        selected=[r for r in before["boards"] if r["id"].startswith(kind+"-")]
        binding=witnesses[selected[0]["id"]]["raw"]
        exterior,cfa=raw_full(binding)
        for spec in selected:
            key=spec["id"]
            case=cases[spec["observation"]]
            parent=prior[spec["observation"]]
            witness=witnesses[key]
            assert case["arrays"]==spec["input_arrays"]==witness["input"]
            assert binding==witness["raw"] and spec["noise"]==witness["noise"]
            x,y,w,h=spec["case"]["ROI_xywh"]
            crop_left,crop_top=(2*((v-48)//2) for v in (x,y))
            box=witness["native_box"]
            assert box[2:]==[256,256]
            bx,by=box[:2]
            assert bx%2==by%2==0
            in_box=[x-crop_left,y-crop_top,w,h]
            assert in_box==witness["roi"]
            with np.load(checked(spec["input_arrays"]),allow_pickle=False) as f:
                arrays={k:f[k] for k in ("packed","colors","wb","matrix")}
            for name,array in arrays.items():
                assert fingerprint(array)==parent["input_fingerprints"][name]
            tile=arrays["packed"][0,:,crop_top//2:crop_top//2+128,crop_left//2:crop_left//2+128]
            np.testing.assert_array_equal(arrays["colors"][0],cfa)
            np.testing.assert_array_equal(tile,exterior[:,by//2:by//2+128,bx//2:bx//2+128])
            stock=np.load(checked(parent["prediction"]),allow_pickle=False)[0,:,crop_top:crop_top+256,crop_left:crop_left+256]
            context=bind_donors(exterior,cfa,box)
            balance,conversion=arrays["wb"],arrays["matrix"]
            updates,counts=correction(tile,stock,cfa,balance[0],conversion[0],spec["noise"],context,in_box)
            original=panel_cells(spec)
            turn=(torch.from_numpy(balance),torch.from_numpy(conversion))
            exposure=spec["display_exposure"]

            def view(obs):
                img=display_crop(torch.from_numpy(obs[None]),*turn,in_box,exposure=exposure)
                return np.rint(img.clip(0,1)*255).astype(np.uint8)

            np.testing.assert_array_equal(view(stock),original["Parent 100k EMA"])
            first=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Local-only 40k EMA","Spatial 40k EMA")
            ordered=[(k,original[k])for k in first if k in original]
            renders={"full":stock+np.float32(doses["full"])*updates["full"],
                     "coherent_full":stock+np.float32(doses["coherent_full"])*updates["coherent_full"],
                     "coherent_isotropic":stock+np.float32(doses["coherent_isotropic"])*updates["coherent_isotropic"],
                     "unit":stock+updates["full"]}
            ordered.extend((LABELS.get(k,"Unscaled covariance"),view(v))for k,v in renders.items())
            ordered.extend((k,original[k]) for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in original)
            diff={k:float(np.sqrt(np.mean((v.astype(float)-stock)**2))*65535*256/160) for k,v in renders.items()}
            out.append({"id":key,"raw":binding,"input":spec["input_arrays"],"checkpoint":baseline["checkpoint"],
                        "parent":parent["prediction"],"roi":in_box,"native_box":box,
                        "noise":spec["noise"],"display_exposure":exposure,
                        "board":native_png(folder/f"{key}.png",ordered),
                        "donor_boxes":context["donor_origins_xy"][:context["cov_count"]],"counts":counts,
                        "rgb_crop_RMS_DN16":diff,"previous":spec})
            print(key,diff,flush=True)
        del exterior
    assert len(out)==8
    return {"parent_collection":before["collections"]["parent100k"],"previous_render":report,"rows":out}


def main():
    data=reference(ROOT/"full.json")
    write_json(ROOT/"native.json",{"evaluation":data,"driver":reference(__file__),
        "exact":native_exact(data),"standing":native_standing(data)},replace=True)


if __name__=="__main__":
    main()
