"""Separate correlated parent error from amplitude error using an independent redraw."""
from pathlib import Path
import time

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import MONITOR, ROOT, coefficients, fire, measure, stats

ARMS=("full","isotropic","coherent_full","coherent_isotropic")


def numeric(rows):
    r=np.random.default_rng(8260445)
    draws=np.vstack((np.arange(len(rows)),r.integers(len(rows),size=(10000,len(rows)))))
    by_name={}
    for name in ARMS:
        modes={}
        for mode in ("same","cross"):
            raw=np.asarray([group["arms"][name][mode]for group in rows])
            metrics=raw[draws].mean(1)
            base,pair,error_cov,change_var=metrics.T
            modes[mode]={"increment_change_DN16":np.sqrt(base+2*error_cov+change_var)-np.sqrt(base),
                         "target_aligned_increment_DN16":pair,
                         "twice_error_covariance_DN16_squared":2*error_cov,
                         "correction_increment_energy_DN16_squared":change_var}
        assert np.max(np.abs(modes["same"]["correction_increment_energy_DN16_squared"]-modes["cross"]["correction_increment_energy_DN16_squared"]))<1e-9
        modes["cross_minus_same"]={key:modes["cross"][key]-modes["same"][key] for key in modes["same"]}
        by_name[name]={mode:{key:{"point":float(v[0]),"interval":np.quantile(v[1:],(.025,.975)).tolist()}
                        for key,v in values.items()}for mode,values in modes.items()}
    return by_name


def main():
    start=time.monotonic()
    experiment=reference(ROOT/"full.json")
    result=read_json(checked(experiment))
    monitor=read_json(checked(result["photo_panel"]))
    settings=read_json(checked(result["settings"]))
    sources=set(result["evaluation"]["split"]["test"])
    items={(r["source"],r["draw"]):r for r in monitor["source_metrics"]if r["profile"]=="iso6400" and r["source"]in sources}
    assert len(items)==96
    rows=[]
    for name in sorted(sources):
        roles=("coupled","independent")
        params=[fire(items[name,kind],settings)for kind in roles]
        case,data=zip(*[(row[0],row[1]) for row in params],strict=True)
        assert case[0]["box"]==case[1]["box"] and case[0]["profile"]==case[1]["profile"]
        for k in ("target","colors","wb","matrix"):
            np.testing.assert_array_equal(data[0][k],data[1][k])
        for k in ("packed",):
            assert not np.array_equal(data[0][k],data[1][k])
        assert case[0]["physical_seeds"]!=case[1]["physical_seeds"]
        supervised={k:np.broadcast_to(data[0][k][None],(3,*data[0][k].shape)) for k in ("wb","matrix")}
        r=settings["score_ROI_xywh"]
        actual=coefficients(data[0]["target"],supervised,r)
        prev=[coefficients(row[2],supervised,r) for row in params]
        results={}
        for arm in ARMS:
            additions=[coefficients(row[3][arm],supervised,r) for row in params]
            same=[]
            cross=[]
            for i in (0,1):
                for j,bucket in ((i,same),(1-i,cross)):
                    out=stats(actual,prev[i],additions[j],measure.BANDS["fine"])
                    inc=out["increment"]
                    bucket.append((inc[0],out["response"][1],inc[1],inc[2]))
            results[arm]={"same":np.mean(same,0).tolist(),"cross":np.mean(cross,0).tolist()}
        rows.append({"source":name,"case_index":case[0]["case"],"arms":results,
                     "input":[v["input"] for v in case],
                     "prediction_receipts":[items[name,kind]["prediction_receipt"]for kind in roles],
                     "shared_full_scene":bool(np.array_equal(data[0]["scene_packed"],data[1]["scene_packed"]))})
        print(case[0]["case"],results["full"],flush=True)
    write_json(ROOT/"repeat.json",{"driver":reference(__file__),"experiment":experiment,
        "rows":rows,"summary":numeric(rows),"seconds":time.monotonic()-start,
        "scope":"Fixed 48-source test split, identical optical targets with separately generated coupled and independent groups. Symmetric swap retains exactly the same two delivered corrections and total increment energy. Diagnostic with two groups, not a single-shot deliverable."},replace=True)


if __name__=="__main__":
    main()
