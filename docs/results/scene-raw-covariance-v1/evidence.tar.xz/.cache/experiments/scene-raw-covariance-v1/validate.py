"""Check sensor coordinates, exterior isolation and float32 replay reductions."""
import numpy as np

from covariance import SIZE, ROOT, bank_basis, bind_donors, correction, lookup, sensor_geometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate import fire, measure


def run():
    rng=np.random.default_rng(142155)
    ny,nx=np.indices((512,512))
    tiles=np.stack([np.sin((xx+yy)*.67) for xx,yy in ((nx,ny),)])[0]
    packed=np.stack([tiles[dy::2,dx::2] for dy in range(2) for dx in range(2)]).astype(np.float32)
    signal=rng.normal(.2,.01,packed.shape).astype(np.float32)+.01*packed
    cfa=np.asarray((0,1,1,2))
    outer=(128,128,256,256)
    context=bind_donors(signal,cfa,outer)
    changed=signal.copy()
    changed[:,64:192,64:192]+=rng.normal(.1,.2,changed[:,64:192,64:192].shape).astype(np.float32)
    other=bind_donors(changed,cfa,outer)
    for key in ("near","far"):
        np.testing.assert_array_equal(context[key],other[key])
    assert context["donor_origins_xy"]==other["donor_origins_xy"]
    for x,y in context["donor_origins_xy"]:
        assert x+SIZE<=128 or x>=384 or y+SIZE<=128 or y>=384
    assert set(map(tuple,context["donor_origins_xy"][:context["cov_count"]])).isdisjoint(
        map(tuple,context["donor_origins_xy"][-context["cov_count"]:]))
    design,index,_=bank_basis()
    expected=rng.normal(0,.001,design.shape[-1])
    native=np.full((256,256),.18)
    for left,top in ((48,48),(49,49),(49,48),(48,49)):
        native[top:top+32,left:left+32]=.18+design@expected
        tile=np.stack([native[dy::2,dx::2]for dy in range(2)for dx in range(2)])
        for layout in ((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0)):
            fields,planes=lookup(tile,np.asarray(layout),(left,top,160,160))
            for sample,plane in zip(fields,planes,strict=True):
                first=sample[0]
                L,_=sensor_geometry(plane)
                np.testing.assert_allclose((first-first.mean())@L,expected[index:],atol=1e-12,rtol=0)
    # A flat input and flat parent remain exactly equal even with nonzero
    # texture covariance from the donor patch bank.
    expected_flat=np.full((3,256,256),.18,dtype=np.float32)
    flat_tile=np.full((4,128,128),.18,dtype=np.float32)
    outputs,counts=correction(flat_tile,expected_flat,cfa,np.ones(3),np.eye(3),
                              {"shot":.00128,"read":6.5536e-6},context,(49,49,160,160))
    assert all(v==0 for v in counts.values()) and all(not v.any()for v in outputs.values())
    path=reference(ROOT/"full.json")
    proof=read_json(checked(path))
    monitor=read_json(checked(proof["photo_panel"]))
    camera=read_json(checked(proof["settings"]))
    selected=proof["evaluation"]["example"]
    verified=[]
    for case in selected:
        match=next(r for r in monitor["source_metrics"]if r["source"]==case["source"] and (r["profile"],r["draw"])==("iso6400","independent"))
        recipe,arrays,parent,delta,_,_=fire(match,camera)
        supervised={key:np.broadcast_to(arrays[key][None],(3,*arrays[key].shape))for key in ("wb","matrix")}
        supervised["exposure"]=recipe["profile"]["exposure"]
        dose=proof["evaluation"]["dose"][case["arm"]]
        corrected=parent+np.float32(dose)*delta[case["arm"]]
        score=measure.parts(supervised,corrected,arrays["target"],camera)["band"]["fine"]["increment_RMS_DN16"]
        error=score-match["metrics"]["100k"]["band"]["fine"]["increment_RMS_DN16"]
        assert abs(error-case["increment_change"])<.001
        verified.append({"case":case["case_index"],"arm":case["arm"],"predicted":case["increment_change"],"observed":error})
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"experiment":path,
        "donor_isolation_verified":True,"bayer_layout_and_offset_checks":16,"flat_input_noop":True,
        "composition":verified},replace=True)
    print("Verified disjoint donor banks, Bayer registration, flat no-op, and all six float32 composition checks.")


if __name__=="__main__":
    run()
