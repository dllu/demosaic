"""Bind the natural exact observations, repeat diagnostic and camera crops."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
IMAGES=Path("docs/images")/ROOT.name
RESULT=Path("docs/results")/ROOT.name


def panels(path,spec):
    with Image.open(path) as image:
        pixels=np.asarray(image.convert("RGB"))
    values={}
    for panel in spec["panels"]:
        x,y,w,h=panel["png_xywh"]
        image=pixels[y:y+h,x:x+w]
        assert image.shape==(h,w,3)==(160,160,3)
        values[panel.get("label",panel.get("name"))]=image
    return values


def retain(spec,subdir):
    src=checked(spec["image"])
    dest=IMAGES/subdir/src.name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dest)
    assert reference(dest)["sha256"]==spec["image"]["sha256"]
    spec["image"]["path"]=dest.relative_to(IMAGES).as_posix()
    return panels(dest,spec)


def main():
    refs={k:reference(ROOT/f"{k}.json") for k in ("full","coefficients-only","repeat","native","verification")}
    sources={k:read_json(checked(b)) for k,b in refs.items()}
    full,earlier,repeat,views,verification=(sources[k] for k in refs)
    assert views["evaluation"]==repeat["experiment"]==verification["experiment"]==refs["full"]
    assert len(full["rows"])==len(earlier["rows"])==128 and len(repeat["rows"])==48
    assert set(full["evaluation"]["split"]["test"])=={r["source"] for r in repeat["rows"]}
    assert len(verification["composition"])==6
    for row,before in zip(full["rows"],earlier["rows"],strict=True):
        for key in ("source","profile","prediction_receipt","donors","donor_origins_xy"):
            assert row[key]==before[key]
        for key,value in before["metrics"].items():
            assert row["metrics"][key]==value
    notes={}
    for board in views["exact"]:
        a=retain(board["board"],"exact")
        b=retain(board["triplet"],"exact")
        assert len(b)==3 and all(np.array_equal(a[key],value) for key,value in b.items())
        notes[board["id"]]="Viewed with the parent and transposed control. Both arms retain softer fine grain than the exact target."
    assert len(notes)==2
    standing=views["standing"]["rows"]
    assert len(standing)==8 and {row["checkpoint"]["sha256"] for row in standing}=={full["checkpoint"]["sha256"]}
    for row in standing:
        previous=row["previous"]
        assert row["input"]==previous["input_arrays"] and row["noise"]==previous["noise"]
        expected=panels(checked(previous["image"]),previous)
        current=retain(row["board"],"standing")
        assert all(np.array_equal(current[key],value) for key,value in expected.items())
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"checkpoint":full["checkpoint"],"evaluation":refs["full"],"native":views,
        "viewed_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),"exact_observations":notes,
        "camera_observation":"Viewed main sky, foliage, building and fence, and both fine cab crops under both profiles with JPEGs and AHD. Sky stays smooth. Fine cab intersections stay incomplete."},replace=True)
    RESULT.mkdir(exist_ok=True)
    archive=RESULT/"evidence.tar.xz"
    files=[checked(b) for b in refs.values()]+sorted(ROOT.glob("*.py"))+sorted(ROOT.glob("*.log"))
    files += [ROOT.with_name("scene-local-contrast-2400-v1")/"measure.py",
              Path("scripts/report_scene_wave_guides.py")]
    members={str(p.resolve().relative_to(Path.cwd())):p for p in files}
    with tarfile.open(archive,"w:xz",preset=4) as out:
        for name,source in sorted(members.items()):
            out.add(source,arcname=name,recursive=False)
    with tarfile.open(archive) as inp:
        for name,source in members.items():
            with inp.extractfile(name) as item:
                assert hashlib.file_digest(item,"sha256").hexdigest()==reference(source)["sha256"]
    compact={name:{method:stats["fine"]for method,stats in values.items()}
             for name,values in full["evaluation"]["metrics"].items()}
    write_json(RESULT/"publication.json",{"sources":refs,"checkpoint":full["checkpoint"],
        "archive":reference(archive),"native_manifest":reference(manifest),
        "doses":full["evaluation"]["dose"],"calibration_added_quiet_budget_DN16":full["evaluation"]["quiet_budget"],
        "fine":compact,"repeat":repeat["summary"],
        "camera_changes":{row["id"]:row["rgb_crop_RMS_DN16"] for row in standing},
        "scope":"Inference component only. Two exact noise profiles, 16 calibration and 48 evaluation backgrounds, symmetric two-capture test and eight native standing boards. Existing EMA with no new fixed photo or measured-camera panels."},replace=True)
    print("Verified 128 existing grouped captures, 48 paired redraws, two native triplets and all eight standing boards.")


if __name__=="__main__":
    main()
