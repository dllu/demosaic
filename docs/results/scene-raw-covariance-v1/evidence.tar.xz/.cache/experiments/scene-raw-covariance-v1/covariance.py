"""Estimate texture covariance outside a query and gate locally measured detail."""
from functools import lru_cache
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
SIZE=32
STRIDE=16
QUERY=(48,48,160,160)
BANK=96
THRESHOLD=2.
ARMS=("full","diagonal","isotropic","transpose","distant",
      "coherent_full","coherent_isotropic","coherent_transpose")


@lru_cache(maxsize=1)
def bank_basis():
    span=np.arange(SIZE,dtype=np.float64)+.5
    axis=np.cos(np.arange(10)[:,None]*np.pi/SIZE*span)*np.sqrt(2.)
    axis[0]=1.
    modes=sorted(((y,x) for y in range(10) for x in range(10) if x*x+y*y<=81),
                 key=lambda coord:(sum(v*v for v in coord),coord))
    design=np.stack([axis[y,:,None]*axis[x,None,:] for y,x in modes],axis=-1)
    first=next(i for i,(y,x) in enumerate(modes) if x*x+y*y>=16)
    retained=modes[first:]
    transpose=np.array([retained.index((x,y)) for y,x in retained])
    return design, first, transpose


@lru_cache(maxsize=4)
def sensor_geometry(offset):
    design,start,_=bank_basis()
    dx,dy=offset
    pixels=design[dy::2,dx::2].reshape(-1,design.shape[-1])
    inverse=np.linalg.inv(pixels.T@pixels)
    assert np.linalg.cond(inverse)<100
    normalize=(pixels@inverse[:,start:])
    return normalize,inverse[start:,start:]


def bind_donors(full, colors, exclusions):
    """Read 32-pixel nonoverlapping donors outside the complete query box."""
    if full.shape[0]!=4 or len(colors)!=4:
        raise ValueError("Expected packed Bayer data")
    x,y,w,h=exclusions
    if x%2 or y%2:
        raise ValueError("Query offsets must preserve absolute CFA phase")
    height,width=np.array(full.shape[1:])*2
    stride=SIZE//2
    patches=np.lib.stride_tricks.sliding_window_view(full,(stride,stride),axis=(-2,-1))
    yy,xx=np.meshgrid(np.arange(0,height-SIZE+1,SIZE),np.arange(0,width-SIZE+1,SIZE),indexing="ij")
    outside=(xx+SIZE<=x)|(xx>=x+w)|(yy+SIZE<=y)|(yy>=y+h)
    blank=xx[outside],yy[outside]
    if len(blank[0])<24:
        return None
    order=np.argsort(np.square(blank[0]+SIZE/2-(x+w/2))+np.square(blank[1]+SIZE/2-(y+h/2)),kind="stable")
    xx,yy=(v[order] for v in blank)
    patterns=[]
    for phase in np.flatnonzero(colors==1):
        z=patches[phase,yy//2,xx//2].reshape(-1,stride**2).astype(np.float64)
        z-=z.mean(1,keepdims=True)
        L,_=sensor_geometry((phase%2,phase//2))
        patterns.append(z@L)
    a,b=patterns

    def covariance(s):
        product=a[s].T@b[s]/len(a[s])
        return (product+product.T)*.5

    count=min(len(xx)//2,BANK)
    return {"near":covariance(slice(0,count)), "far":covariance(slice(-count,None)),
            "donor_origins_xy":np.column_stack((xx,yy)).tolist(),
            "cov_count":count}


def lookup(packed, colors, roi):
    x,y,w,h=roi
    if w!=160 or h!=160 or x<0 or y<0 or x+w>packed.shape[2]*2 or y+h>packed.shape[1]*2:
        raise ValueError("The native ROI must be a registered 160-square")
    # Read true native CFA phases. Odd ROI offsets shift slice origin, not layout.
    box=np.array([x,y])
    window=SIZE//2
    stride=STRIDE//2
    fields=[]
    offsets=[]
    for phase in np.flatnonzero(colors==1):
        physical=np.array([phase%2,phase//2])
        local=(physical-box)%2
        bx,by=(box+local-physical)//2
        raw=packed[phase,by:by+h//2,bx:bx+w//2]
        all_patches=np.lib.stride_tricks.sliding_window_view(raw,(window,window))
        z=all_patches[::stride,::stride].reshape(-1,window**2).astype(np.float64)
        fields.append(z)
        offsets.append(tuple(local))
    return fields,offsets


def bases(cov):
    _,_,swap=bank_basis()
    e,V=np.linalg.eigh(cov["near"])
    signal=np.maximum(0.,e)
    true_total=signal.sum()
    ident=np.eye(len(e))
    far_values,far_vectors=np.linalg.eigh(cov["far"])
    far_positive=np.maximum(0.,far_values)
    unmatched=far_positive*true_total/max(1e-15,far_positive.sum())
    diagonal=np.maximum(0.,np.diag(cov["near"]))
    diagonal=diagonal*true_total/max(1e-15,diagonal.sum())
    return {"full":(V,signal),"diagonal":(ident,diagonal),"isotropic":(ident,np.full(len(e),true_total/len(e))),
            "transpose":(V[swap],signal),"distant":(far_vectors,unmatched)}


def correction(packed, parent, colors, wb, matrix, noise, context, roi=QUERY):
    if context is None:
        return {key:np.zeros_like(parent) for key in ARMS},{key:0 for key in ARMS}
    # Guard and restore in camera green; the final output direction is neutral
    # after the existing white balance and camera-matrix conversion.
    x,y,w,h=roi
    design,start,_=bank_basis()
    fine=design[...,start:].reshape(SIZE**2,-1)
    work,offsets=lookup(packed,colors,roi)
    prior=np.lib.stride_tricks.sliding_window_view(parent[1,y:y+h,x:x+w],(SIZE,SIZE))
    prior=prior[::STRIDE,::STRIDE].reshape(-1,SIZE**2).astype(np.float64)
    prior-=prior.mean(1,keepdims=True)
    prior=prior@fine/SIZE**2
    estimates=[]
    covs=[]
    variances=[]
    for z,p in zip(work,offsets,strict=True):
        mean=z.mean(1,keepdims=True)
        variance=noise["shot"]*np.maximum(0.,mean)+noise["read"]
        L,C=sensor_geometry(p)
        estimates.append((z-mean)@L)
        covs.append(C)
        variances.append(np.maximum(1e-15,variance))

    blend=np.hanning(SIZE).clip(min=.02)
    blend=blend[None,:]*blend[:,None]
    mass=np.zeros((h,w),dtype=np.float64)
    stations=[(j,i) for j in range(0,h-SIZE+1,STRIDE) for i in range(0,w-SIZE+1,STRIDE)]
    for top,left in stations:
        mass[top:top+SIZE,left:left+SIZE]+=blend
    axis=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    taper=axis[:,None]*axis[None,:]
    neutral=np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    neutral/=neutral[1]
    outputs={}
    counts={}
    factors=bases(context)
    for key in ("full","isotropic","transpose"):
        factors["coherent_"+key]=factors[key]
    for name,(vectors,eigenvalue) in factors.items():
        a,b=(c@vectors for c in estimates)
        pa=prior@vectors
        av,bv=(scale*np.sum((cov@vectors)*vectors,axis=0) for scale,cov in zip(variances,covs,strict=True))
        product=a*b/np.maximum(1e-20,np.sqrt(av*bv))
        supported=np.maximum(0.,1.-THRESHOLD**2/np.maximum(1.e-20,product))
        observed=(a/av+b/bv)/(1/av+1/bv)
        noise_fused=1/(1/av+1/bv)
        wiener=eigenvalue/(eigenvalue+noise_fused)
        # A lift can only move toward the common, observed sign. Limit it
        # to the magnitude of the observation even if the parent is opposed.
        sign=np.sign(observed)
        excess=np.minimum(np.abs(observed),np.maximum(0.,(observed-pa)*sign))
        if name.startswith("coherent_"):
            # Keep the local parent oscillation and adjust its amplitude.
            # Test the whole fixed direction separately on both green planes.
            direction=pa*wiener
            whitened=[]
            gains=[]
            for raw,cov,scale in zip((a,b),covs,variances,strict=True):
                precision=vectors.T@np.linalg.inv(cov)@vectors
                direction_score=direction@precision
                energy=np.maximum(np.sum(direction*direction_score,axis=1),1e-20)
                dot=np.sum((raw-pa)*direction_score,axis=1)
                sd=np.sqrt(scale[:,0]/energy)
                whitened.append(dot/energy/sd)
                gains.append(dot/energy)
            least=np.minimum(*whitened)
            estimate=np.clip(np.mean(gains,axis=0),0.,.75)
            weight=np.clip(1.-1.5/np.maximum(1.e-20,least),0.,1.)
            changes=direction*(estimate*weight)[:,None]
        else:
            changes=sign*excess*wiener*supported
        count=int(np.count_nonzero(changes))
        signal=((changes@vectors.T)@fine.T).reshape(len(stations),SIZE,SIZE)
        surface=np.zeros((h,w),dtype=np.float64)
        for (top,left),patch in zip(stations,signal,strict=True):
            surface[top:top+SIZE,left:left+SIZE]+=patch*blend
        surface/=mass
        surface=(surface-np.sum(surface*taper)/np.sum(taper))*taper
        complete=np.zeros_like(parent,dtype=np.float32)
        complete[:,y:y+h,x:x+w]=(neutral[:,None,None]*surface).astype(np.float32)
        counts[name]=count
        outputs[name]=complete
    return outputs,counts
