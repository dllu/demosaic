"""Measure true faint increments and false detail in the exact flat cores."""

import argparse
from collections import defaultdict
from pathlib import Path
from statistics import mean,median
import time

import numpy as np
from diagnose_local_material_detail import basis,fft_dct
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import linear_rgb,noisy_malvar,photometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
LUMA=np.array([.2126,.7152,.0722])
FREQ=np.arange(16)/32
RADIAL=np.hypot(FREQ[:,None],FREQ[None,:])
BANDS={"lower":(RADIAL>=1/32)&(RADIAL<1/8),"fine":(RADIAL>=1/8)&(RADIAL<1/3),"upper":RADIAL>=1/3}
DCT=basis(16)
CFA_ARGS=("packed","variance","colors","wb","matrix")


def coeffs(luma,roi):
    x,y,w,h=roi
    assert w==h==96
    sample=luma[...,y:y+h,x:x+w]
    blocks=sample.reshape(*sample.shape[:-2],6,16,6,16).swapaxes(-2,-3).reshape(*sample.shape[:-2],36,16,16)
    result=DCT@blocks@DCT.T
    other=fft_dct(fft_dct(blocks,-1),-2)
    np.testing.assert_allclose(result,other,rtol=0,atol=1e-14)
    return result


def parts(inputs,outputs,target,spec):
    roi=spec["score_ROI_xywh"]
    truth=linear_rgb(target,inputs)
    actual=linear_rgb(outputs,inputs)
    y=lambda rgb:np.einsum("c,bchw->bhw",LUMA,rgb)
    T,P=(coeffs(y(v),roi)for v in (truth,actual))
    rows={}
    for label,mask in BANDS.items():
        ref=T[0,:,mask]-T[1,:,mask]
        diff=P[0,:,mask]-P[1,:,mask]
        power=float(np.sum(ref**2))
        cross=float(np.sum(ref*diff))
        correct=float(np.sum(diff**2))
        quiet=T[2,:,mask]
        assert np.max(abs(quiet))<1e-14
        scale=65535**2/(36*16*16)
        rows[label]={"exact_paired_increment_sq":power,
             "predicted_increment_sq":correct,"aligned_increment_dot":cross,
             "signed_response":cross/power if power>1e-12 else None,
             "increment_RMS_DN16":float(np.sqrt(np.sum((diff-ref)**2)*scale)),
             "present_RMS_DN16":float(np.sqrt(np.sum((P[0,:,mask]-T[0,:,mask])**2)*scale)),
             "quiet_RMS_DN16":float(np.sqrt(np.sum(P[2,:,mask]**2)*scale))}
    x0,y0,w,h=roi
    right=actual[2,:,y0:y0+h,x0:x0+w]-truth[2,:,y0:y0+h,x0:x0+w]
    bias=right.mean((-2,-1),keepdims=True)
    quiet_metrics={"quiet_RGB_mean_absolute_bias_DN16":float(abs(bias).max()*65535),
                   "quiet_RGB_centered_RMS_DN16":float(np.sqrt(np.mean((right-bias)**2))*65535)}
    extra=photometry(outputs/inputs["exposure"],inputs|{"target":target/inputs["exposure"]})
    return {"band":rows,"uniform_core":quiet_metrics,
            "srgb_PSNR_per_role":[float(x)for x in extra["srgb_psnr"]]}


def reduce(rows):
    groups=defaultdict(list)
    for record in rows:
        for label, row in record["metrics"].items():
            groups[record["profile"],record["draw"],label].append(row)
    merged={}
    for (prior,draw,label),cases in groups.items():
        assert len(cases) in (8,64)
        table={"cases":len(cases),"PSNR":np.asarray([v["srgb_PSNR_per_role"]for v in cases]).mean(0).tolist(),
            "uniform_core":{k:mean(v["uniform_core"][k]for v in cases)for k in cases[0]["uniform_core"]},"bands":{}}
        for name in BANDS:
            rows=[v["band"][name]for v in cases]
            sign=[v["signed_response"]for v in rows if v["signed_response"] is not None]
            table["bands"][name]={"weak_RMS_DN16":mean(v["increment_RMS_DN16"]for v in rows),
                   "quiet_RMS_DN16":mean(v["quiet_RMS_DN16"]for v in rows),
                   "present_RMS_DN16":mean(v["present_RMS_DN16"]for v in rows),
                   "pooled_signed_response":sum(v["aligned_increment_dot"]for v in rows)/
                                            max(1e-20,sum(v["exact_paired_increment_sq"]for v in rows)),
                   "median_case_signed_response":median(sign) if sign else None}
        merged.setdefault(prior,{}).setdefault(draw,{})[label]=table
    return merged


def add_view(folder,record,settings,values,predictions,plan,spec,role):
    args={k:values[k][role:role+1]if k in ("packed","variance") else values[k][None]
          for k in CFA_ARGS}
    methods=["V120","100k","prior-spatial12k/matching","prior-spatial12k/blur-distant",
             "prior-spatial12k/neutral","prior-spatial12k/wrong-distant"]
    names=("V120","100k","Spatial12k match","Blur-distant","Neutral","Wrong-distant")
    pieces=[noisy_malvar(args)[0],*[predictions[k][role]for k in methods],values["target"][role]]
    case=spec["rows"][settings["case"]]
    return native_board(folder,f"{settings['id']}-role{role}",pieces,args,
                        {"role":spec["roles"][role],"source":case["source"],"query_box":settings["box"],
                         "profile":settings["profile"],"CFA":case["camera"]["pattern"],"draw":settings["draw"],
                         "prediction_receipt":record,"models":plan["models"]},
                        labels=("Noisy Malvar",*names,"Exact GT"),triplet_indices=(0,3,len(pieces)-1),
                        exposure=1/settings["profile"]["exposure"],contrast=2,
                        roi=tuple(spec["native_display_ROI_xywh"]))


def measure(pilot):
    folder=ROOT/("pilot" if pilot else "evaluation")
    frozen=reference(folder/"plan.json")
    plan=read_json(checked(frozen))
    assert plan["pilot"]==pilot
    spec=read_json(checked(plan["panel"]))
    receipt=reference(folder/"collected.json")
    recording=read_json(checked(receipt))
    assert recording["plan"]==frozen
    started=time.monotonic()
    out=folder/"native"
    out.mkdir()
    rows,boards=[],[]
    for item in recording["records"]:
        record=read_json(checked(item))
        settings=read_json(checked(record["case"]))
        assert record["plan"]==frozen
        assert record["exact_query_inputs"]=={k:settings["fingerprints"][k]for k in CFA_ARGS}
        with np.load(checked(settings["input"]),allow_pickle=False)as f:
            values={k:f[k]for k in (*CFA_ARGS,"target")}
        assert {k:fingerprint(v)for k,v in values.items()}=={k:settings["fingerprints"][k]for k in values}
        with np.load(checked(record["saved"]),allow_pickle=False)as f:
            predictions={name:f[name.replace("/","--")]for name in record["inference_variants"]}
        fields={k:np.broadcast_to(values[k][None],(3,*values[k].shape))for k in ("wb","matrix")}
        fields["exposure"]=settings["profile"]["exposure"]
        summary={k:parts(fields,z,values["target"],spec)for k,z in predictions.items()}
        if pilot and settings["case"]<2 and settings["draw"]=="coupled":
            boards.append(add_view(out,item,settings,values,predictions,plan,spec,0))
            if settings["case"]==0 and settings["profile"]["name"]=="iso6400":
                boards.append(add_view(out,item,settings,values,predictions,plan,spec,2))
        rows.append({"source":settings["source"],"profile":settings["profile"]["name"],"draw":settings["draw"],
                     "prediction_receipt":item,"metrics":summary})
    assert len(rows)==(32 if pilot else spec["expected_cases"])
    write_json(folder/"results.json",{"plan":frozen,"collection":receipt,"driver":reference(__file__),
               "counts":{"cases":len(rows),"observations":len(rows)*3},
               "source_metrics":rows,"pooled":reduce(rows),"native":boards,
               "metric_seconds":time.monotonic()-started,
               "scope":"Two real photographic panel priors with exact paired weak component and flat core."
                       " Per-scene signed RMS and independent-coupled comparisons. Noise extent affects variance"
                       " of independent increment estimates. This early pilot preflights the panel on old checkpoints." if pilot else
                       "Full frozen natural-photo context panel and fixed local inputs."})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pilot",action="store_true")
    measure(parser.parse_args().pilot)
