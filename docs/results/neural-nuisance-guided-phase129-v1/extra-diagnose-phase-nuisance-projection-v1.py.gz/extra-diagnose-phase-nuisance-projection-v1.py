"""A-only weighted residual-operator norms, without GT/reference arrays."""
import os
import sys
import time
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig, fit_local_candidate
from demosaic.neural_nuisance import WithheldBackground, fit_neural_candidate
from pilot_neural_nuisance import input_arrays, raw_frame

os.sched_setaffinity(0, [14, 15])
os.nice(10)
root = Path('.cache/experiments/neural-nuisance-phase129-pilot-v1').resolve()
plan = read_json(root / 'plan.json')
assert read_json(root / 'controller-result.json')['all_stages_succeeded']
collection = read_json(root / 'collection.json')
records = {r['id']: r for r in collection['rows']}
backgrounds = {r['id']: r for r in read_json(root / 'backgrounds-collection.json')['rows']}
config = LocalWaveConfig(**plan['geometry_config'])
case_ids = ['iso400-index0008-role2', 'iso400-index0024-role2', 'main-building-detail', 'mesh-nominal']
results = []
began = time.monotonic()
for case in case_ids:
    row = next(r for r in plan['rows'] if r['id'] == case)
    data = input_arrays(row)
    raw = raw_frame(data)
    colors = np.tile(data['colors'].reshape(2, 2), (raw.shape[0] // 2, raw.shape[1] // 2))
    mask = np.load(checked(backgrounds[case]['mask_A']))
    fields = [np.load(checked(p)) for p in backgrounds[case]['fields']]
    parent = np.load(checked(row['parent']))[row['sample']]
    n = config.window
    positions = [np.unique(np.r_[np.arange(0, length - n + 1, config.stride), length - n]) for length in raw.shape]
    for y in positions[0]:
        for x in positions[1]:
            region = np.s_[y:y+n, x:x+n]
            tile, layout = raw[region], colors[region]
            stored = next(r for r in records[case]['aux']['records'] if r['xy'] == [x, y])
            for fold, split in enumerate([mask[region], ~mask[region]]):
                analytic = fit_local_candidate(tile, layout, split, shot=row['noise']['shot'], read=row['noise']['read'], config=config)
                neural = fit_neural_candidate(tile, layout, analytic, WithheldBackground(fields[fold][:, region[0], region[1]], split), config=config, reselect_frequencies=False)
                for arm, candidate in [('H1-', analytic), ('neural', neural)]:
                    np.testing.assert_array_equal(candidate.frequencies_xy, stored['arms'][arm]['frequencies'][fold])
                    nuisance_columns = candidate.wave_slices[0][0]
                    for color in range(3):
                        selected = candidate.selected_indices[color]
                        precision = 1 / np.sqrt(candidate.variance_cfa.ravel()[selected])
                        design = candidate.design[selected]
                        z = design * precision[:, None]
                        q = np.linalg.qr(z, mode='reduced')[0]
                        zn = z[:, :nuisance_columns]
                        oblique = (q.T @ zn) @ ((candidate.operators[color][:nuisance_columns] / precision[None]) @ q)
                        innovation = (tile.ravel()[selected] - parent[color, region[0], region[1]].ravel()[selected]) * precision
                        nuisance_prediction = zn @ (candidate.operators[color][:nuisance_columns] @ (innovation / precision))
                        for direction in (0, 1):
                            a, b = candidate.wave_slices[1-direction]
                            other = z[:, a:b]
                            u, s, _ = np.linalg.svd(other, full_matrices=False)
                            qo = u[:, s > s[0]*1e-10]
                            small_qo = q.T @ qo
                            residual_operator = (np.eye(q.shape[1]) - small_qo @ small_qo.T) @ (np.eye(q.shape[1]) - oblique)
                            small_gain = np.linalg.svd(residual_operator, compute_uv=False)[0]
                            residual = innovation - nuisance_prediction
                            residual -= qo @ (qo.T @ residual)
                            keep = np.ones(z.shape[1], bool)
                            start, stop = candidate.wave_slices[direction]
                            keep[start:stop] = False
                            un, sn, _ = np.linalg.svd(z[:, keep], full_matrices=False)
                            qn = un[:, sn > sn[0]*1e-10]
                            orthogonal = innovation - qn @ (qn.T @ innovation)
                            # Independent direct action on all full-design span vectors.
                            raw_q = q / precision[:, None]
                            action = q - zn @ (candidate.operators[color][:nuisance_columns] @ raw_q)
                            action -= qo @ (qo.T @ action)
                            np.testing.assert_allclose(action, q @ residual_operator, atol=1e-10, rtol=1e-9)
                            norm = np.linalg.norm(innovation)
                            results.append({'case':case,'xy':[int(x),int(y)],'fold':fold,'arm':arm,'color':color,'direction':direction,
                                'weighted_oblique_residual_spectral_norm':float(max(1.0,small_gain)),
                                'weighted_orthogonal_residual_spectral_norm':1.0,
                                'actual_parent_innovation_weighted_norm_ratio_oblique':float(np.linalg.norm(residual)/norm),
                                'actual_parent_innovation_weighted_norm_ratio_orthogonal':float(np.linalg.norm(orthogonal)/norm),
                                'frequencies_exact_against_closed_prediction':True})
    print('closed case',case,flush=True)
summary = []
for case in case_ids:
    for arm in ['H1-', 'neural']:
        selected = [r for r in results if r['case']==case and r['arm']==arm]
        summary.append({'case':case,'arm':arm,'rows':len(selected),
            **{key:[float(np.min([r[key] for r in selected])),float(np.median([r[key] for r in selected])),float(np.max([r[key] for r in selected]))] for key in ['weighted_oblique_residual_spectral_norm','actual_parent_innovation_weighted_norm_ratio_oblique','actual_parent_innovation_weighted_norm_ratio_orthogonal']}})
write_json(Path('.cache/phase-nuisance-projection-diagnostic-v1.json'),{'script':reference(__file__),'plan':reference(root/'plan.json'),'collection':reference(root/'collection.json'),'rows':results,'summary':summary,'seconds':time.monotonic()-began,'new_neural_forwards':0,'GT_reference_arrays_loaded':0,'Torch_imported':'torch' in sys.modules,'scope':'Frozen actual input-only candidate geometry/weights and joint-fit operators. Exact noise-weighted residual spectral norms on the full design span plus identity complement; direct-action parity checked. Parent used only in final RHS norm diagnostic. Orthogonal-null residual is a counterfactual operator diagnostic, not a scored quality result or proof of artifact cause. All original receipts and predictions unchanged.'})
print(summary,flush=True)
