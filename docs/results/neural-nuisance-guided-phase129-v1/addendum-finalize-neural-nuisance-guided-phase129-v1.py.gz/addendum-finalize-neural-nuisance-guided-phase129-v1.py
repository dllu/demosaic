"""Seal exact artifacts only after every native sheet has a viewing receipt."""
import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-guided-phase129-pilot-v1'
destination = repo / 'docs/results/neural-nuisance-guided-phase129-v1'
prepared = read_json(root / 'publication-prepared.json')
manifest = read_json(root / 'contact-sheets/manifest.json')
batches = sorted(root.glob('viewing-batch-*.json'))
viewed = []
for path in batches:
    batch = read_json(path)
    assert batch['actually_viewed'] and batch['notes']
    viewed.extend(batch['sheets'])
assert sorted(viewed) == list(range(len(manifest['sheets'])))
assert manifest['source_images'] == len(prepared['images']) == 38
archives = list(prepared['archives'])
for source in [root / 'publication-prepared.json', root / 'contact-sheets/manifest.json',
               *batches, repo / '.cache/native-contact-sheets-v1.py', Path(__file__),
               repo / '.cache/summarize-guided-phase129-v1.py', repo / '.cache/guided-phase129-numerical-summary-v1.json',
               repo / '.cache/close-guided-phase-publication-prep-v1.py', repo / '.cache/guided-phase-publication-prep-result-v1.json',
               repo / '.cache/guided-phase-ruff-v1.log', root / 'all-H1-control-parity.json', repo / '.cache/guided-phase-H1-parity-v1.py', repo / '.cache/guided-phase-H1-parity-v1.log']:
    target = destination / ('addendum-' + source.name + '.gz')
    with target.open('xb') as stream:
        stream.write(gzip.compress(source.read_bytes(),mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({'original':reference(source),'published':reference(target),'decompressed_bytes_exact':True})
for item in archives:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
for item in prepared['images']:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
prepared.update(archives=archives,
    viewing={'actually_viewed':True,'figures':38,'contact_sheets':len(manifest['sheets']),
             'manifest':reference(root/'contact-sheets/manifest.json'),'batches':[reference(p)for p in batches]},
    status='complete; much higher constructed weak response with noise/error and real-artifact costs',
    quality_decision='Analytic nuisance plus A-only neural-guided phase:400/far weak28.702%, quiet+0.541% and increment-0.946% vs parent, both sources improve increment error. Versus unguided analytic, quiet/increment lower with retained response and building maximum531.58 to130.59 DN16. Guided NN nuisance primary has quiet+1.744%, increment+3.006%, both sources worse increment; not preferred. Neural building75.18 to55.20. Fine cab crossings remain absent; higher-noise errors remain. Useful measured analytic phase option, no broad/general-model promotion.',
    comparison_baselines=[reference(repo/'docs/results'/name/'publication.json')for name in [
        'neural-nuisance-phase129-v1','neural-nuisance-fixed-bg129-v1','neural-nuisance-fixed-v1']],
    scope_clarification='Both phase arms use matching own-color A-only neural range guides; separate CFA amplitudes, same global background/competing fit/phase geometry/support and identical RAW-parent operator. Raw H1 controls remain byte-exact on all288 outputs. Analytic label refers to nuisance basis, not neural-free inference. Physical square-root coordinate has an approximate delta-method noise-unit interpretation, not calibrated neural uncertainty. Oblique-projection diagnostic rejects large global amplification on checked inputs. No neural replay or learned update.',
    published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination/'publication.json',prepared)
print(len(archives),'exact archives;',len(prepared['images']),'source figures actually viewed')
