"""Small closed-study table for documentation; no new inference."""
import json
from pathlib import Path
from demosaic.experiments.artifacts import read_json

base=Path('.cache/experiments')
root=base/'neural-nuisance-guided-phase129-pilot-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
assert read_json(root/'followup/result.json')['returncode']==0
keys=['weak_gain','strong_gain','quiet_error_RMS_DN16','weak_increment_error_RMS_DN16']
tables=[]
for name in ['neural-nuisance-fixed-proposals-pilot-v1','neural-nuisance-hann512-pilot-v1','neural-nuisance-fixed-bg129-pilot-v1','neural-nuisance-phase129-pilot-v1','neural-nuisance-guided-phase129-pilot-v1']:
    folder=base/name
    if not folder.exists():
        continue
    d=read_json(folder/'summary-review/summary.json')
    for method in ['V143','local-t2','conditional-local-t2']:
        row=next(r for r in d['means']if(r['profile'],r['placement'],r['method'])==('iso400','far',method))
        role=next(r for r in d['absolute_role_means']if(r['profile'],r['placement'],r['method'],r['role'])==('iso400','far',method,2))
        tables.append({'study':name,'method':method,**{k:row[k]for k in keys},'role2_full_RMS_DN16':role['full_RMS_DN16']})
d=read_json(root/'summary-review/summary.json')
cells=[{k:r[k]for k in ['profile','placement','method',*keys]}for r in d['means']if r['method']in['V143','local-t2','conditional-local-t2']]
sources=[{k:r[k]for k in ['source','method',*keys]}for r in read_json(root/'finite-scores.json')['rows']if(r['profile'],r['placement'],r['method'])==('iso400','far','local-t2')or(r['profile'],r['placement'],r['method'])==('iso400','far','V143')]
stress=read_json(root/'native/report.json')['stress_figures']
print(json.dumps({'tables':tables,'cells':cells,'sources':sources,'stress':[{k:r.get(k)for k in ['ROI_xywh','correction_ROI_RMS_DN16']}|{'id':r['source']['id']}for r in stress],'stages':read_json(root/'controller-result.json')['stages']},indent=2))
