"""Resolve a diagnostic-only process-global override by replaying serially."""
from unittest.mock import patch

from geometry import ROOT, PRIOR
import curve_delivery as central
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    original=reference(PRIOR/"delivery.json")
    prior=read_json(checked(original))
    checked(prior["driver"])
    out=ROOT/"central-replay"
    out.mkdir(exist_ok=True)
    saved={name:read_json(checked(value))for name,value in prior["dependencies"].items()}
    cases=saved["fields.json"]
    plan=read_json(checked(cases["plan"]))
    archived=saved["predictions-fresh.json"]
    diagnostic=saved["diagnostic.json"]["exact_geometry"]
    tangential=saved["tangent.json"]["exact"]
    chosen=[i for i,row in enumerate(diagnostic)if row["geometry"]=="bent"][:2]
    (out/"bent-native").mkdir(exist_ok=True)
    with patch.object(central,"ROOT",out):
        rows=[central.observe(row,plan,archived["rows"],diagnostic,tangential,chosen)for row in cases["rows"]]
    assert len(rows)==len(prior["rows"])==20
    out_data=prior|{"rows":rows,"executor":"serial","executor_source":reference(__file__),
        "summary":{key:central.summary([row for row in rows if row["geometry"]==key])for key in ("bent","straight")}}
    new_path=out/"delivery.json"
    write_json(new_path,out_data)
    new=reference(new_path)
    current=read_json(checked(new))
    assert current["checkpoint"]==prior["checkpoint"] and current["dependencies"]==prior["dependencies"]
    changed=[]
    for old,row in zip(prior["rows"],current["rows"],strict=True):
        assert all(old[k]==row[k]for k in ("index","id","geometry","case","parent"))
        assert row["scores"]["parent"]==old["scores"]["parent"]
        assert row["scores"]["fixed"]==old["scores"]["fixed"]
        changes={}
        for arm,scores in row["scores"].items():
            delta={k:v-old["scores"][arm][k]for k,v in scores.items()}
            if any(delta.values()):
                changes[arm]=delta
        if changes:
            changed.append({"i":row["index"],"id":row["id"],"geometry":row["geometry"],"new_minus_old":changes})
    pictures=[{"i":x["index"],"matches_display":all(x["board"][k]["image"]["sha256"]==y["board"][k]["image"]["sha256"]
                       for k in ("board","triplet"))}for x,y in zip(prior["rows"],current["rows"],strict=True)if x["board"]]
    write_json(ROOT/"serial-audit.json",{"driver":reference(__file__),"prior_result":original,"serial_result":new,
                 "prior_driver":prior["driver"],"checkpoint":current["checkpoint"],"changed":changed,"native_parity":pictures,
                 "old_summary":prior["summary"],"serial_summary":current["summary"],
                 "scope":"Serial replay of the published synthetic delivery diagnostic. Standing crops, RAW-only geometry and separate planted wire delivery results use no mutable diagnostic override."})
    print([(row["i"],tuple(row["new_minus_old"]))for row in changed],pictures)


if __name__=="__main__":
    main()
