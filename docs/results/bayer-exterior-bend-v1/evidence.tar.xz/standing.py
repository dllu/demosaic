"""Render the geometry variants on both cached GFX100S scene families."""
from unittest.mock import patch

import numpy as np

from geometry import ROOT, phase
from delivery import check_query, correction
import render_phase as prior
from demosaic.experiments.artifacts import checked, read_json, reference

CAPTIONS={
    "Bayer-gated":"Bayer-gated refit","ring8":"Eight-donor EMA","distant":"Distant Bayer gate",
    "fixed":"64-pixel carrier fit","exterior-curved":"Exterior bend",
    "spatial-curved":"Checked donor locations","query-checked":"Checked in crop",
    "fixed-center":"Bend at fixed center","fixed-center-spatial":"Bend with held donors",
    "fixed-center-query-checked":"Fixed center, check crop",
}


def render(raw,layout,wb,matrix,noise,box,exterior,parent,model,roi=None):
    networks,dose,camera,shifts,anchored=model
    roi=phase.ROI if roi is None else tuple(roi)
    x,y,w,_=roi
    position=(box[0]+x,box[1]+y,w)
    record=camera[position]
    spacing,admitted,_=phase.select(exterior,layout,box,roi)
    np.testing.assert_allclose(spacing,record["frequencies_xy"],rtol=0,atol=1e-12)
    assert admitted==record["original_admission"]==shifts[position]["original_admission"]==anchored[position]["original_admission"]
    expected={"nominal":(.00128,6.5536e-6),"transferred":(.0014635775921166604,1.0715704128646712e-6)}
    noise_pair=(noise["shot"],noise["read"])
    profiles=[key for key,pair in expected.items()if np.allclose(pair,noise_pair,rtol=2e-14,atol=0)]
    assert len(profiles)==1,(position,noise_pair)
    profile=profiles[0]
    args = shifts[position]["profiles"][profile]["parameters"]|anchored[position]["profiles"][profile]["parameters"]
    arms = {k:np.asarray(args[k])for k in CAPTIONS if k in args}
    arms["fixed"]=np.zeros((2,5))
    for key,checked_name in (("exterior-curved","query-checked"),("fixed-center","fixed-center-query-checked")):
        arms[checked_name]=check_query(raw,layout,spacing,roi,arms[key],noise)[0] if admitted else arms["fixed"]
    donors=phase.review.exterior(exterior,layout,noise,box)
    earlier=phase.compose(raw,layout,wb,matrix,noise,box,donors,parent,networks,False)
    addition=correction(raw,earlier["distant"],layout,wb,matrix,noise,spacing,roi,dose,admitted,arms)
    combined=earlier|{k:earlier["distant"]+v for k,v in addition.items()}
    return {k:combined[k]for k in CAPTIONS}


def main():
    model,receipt=prior.setup()
    assert len(model)==2
    refs={name:reference(ROOT/f"{name}.json")for name in ("geometry","anchored","delivery")}
    sets={name:read_json(checked(link))for name,link in refs.items()}
    assert sets["delivery"]["geometry"]==refs["geometry"]==sets["anchored"]["variation_of"]
    base=read_json(checked(sets["geometry"]["source"]))
    dims=lambda rows:{tuple(item["box"]):item for item in rows}
    prepared=(*model,dims(base["camera"]),dims(sets["geometry"]["camera"]),dims(sets["anchored"]["camera"]))
    with patch.object(prior,"ROOT",ROOT),patch.object(prior,"CAPTIONS",CAPTIONS),patch.object(prior,"render_models",render):
        prior.standing(prepared,receipt|{"driver":reference(__file__),"exterior_runs":refs},None)


if __name__=="__main__":
    main()
