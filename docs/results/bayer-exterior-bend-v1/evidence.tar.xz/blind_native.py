"""Native triplets on the first two sources with admitted bent-wire estimates."""
import numpy as np

from geometry import ROOT, phase
from delivery import DOSE, correction, native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    result=reference(ROOT/"blind.json")
    audit=read_json(checked(result))
    earlier=read_json(checked(audit["prior"]))
    runs=read_json(checked(earlier["geometry"]))
    plan=read_json(checked(runs["plan"]))
    out=ROOT/"blind-exact"
    out.mkdir(exist_ok=True)
    images=[]
    for case in audit["rows"]:
        if case["geometry"]!="bent":
            continue
        supported=next((r for r in case["rows"]if r["role"]=="present" and r["nomination"]["admitted"]),None)
        if supported is None:
            continue
        i,a=case["i"],supported["draw"]
        shot=plan["sources"][i]
        assert shot["source"]["id"]==case["id"]
        with np.load(checked(case["input"]),allow_pickle=False)as f:
            full={k:f[k]for k in ("packed","colors","wb","matrix","target")}
        with np.load(checked(case["parent"]),allow_pickle=False)as f:
            parent=f["baseline"][a,0]
        x,y,w,h=plan["query_box"]
        packed=full["packed"][a,0:1,:,y//2:(y+h)//2,x//2:(x+w)//2]
        frame={k:full[k][a,0:1]for k in ("colors","wb","matrix")}|{"packed":packed}
        exact=full["target"][a,0,:,y:y+h,x:x+w]
        imposed={k:np.array(v)for k,v in supported["accepted_terms"].items()}
        shift=correction(packed[0],parent,*(frame[k][0]for k in ("colors","wb","matrix")),plan["profile"],
                         np.array(supported["nomination"]["frequencies_xy"]),phase.ROI,DOSE,True,imposed)
        names=("Noisy Malvar","Corpus 100k EMA","Fixed noisy center","Bend at noisy center","Joint exterior fit","Joint fit, check crop","Exact GT")
        pictures=(noisy_malvar(frame)[0],parent,*(parent+shift[k] for k in ("fixed","anchored","joint","joint-checked")),exact)
        metadata={"CFA":shot["camera"]["pattern"],"noise":plan["profile"],"repeat":a,
                  "source":shot["source"],"source_box":shot["box"],"query":plan["query_box"],"capture":case["input"],
                  "checkpoint":audit["checkpoint"],"prediction":case["parent"],"conditioning":supported}
        board=native_board(out,f'case-{i:03d}',pictures,frame,metadata,labels=names,exposure=2,
                           triplet_indices=(0,4,6))
        images.append(board)
        if len(images)==2:
            break
    assert len(images)==2
    write_json(out/"manifest.json",{"driver":reference(__file__),"blind":result,"rows":images,
         "selection":"First two bent source ids by predetermined panel order with an admitted present draw. Use earliest admitted draw."})


if __name__=="__main__":
    main()
