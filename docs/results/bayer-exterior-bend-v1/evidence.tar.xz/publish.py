"""Bind geometry, arithmetic replay and the inspected native comparisons."""
from pathlib import Path
import hashlib
import shutil
import tarfile

import numpy as np
from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.with_name("bayer-shared-phase-v1")
IMAGES=Path("docs/images")/ROOT.name
OUT=Path("docs/results")/ROOT.name


def pixels(image,panels):
    result={}
    for cell in panels:
        x,y,w,h=cell["png_xywh"]
        assert w==h==160 and 0<=x<=image.width-w and 0<=y<=image.height-h
        result[cell.get("label") or cell["name"]]=image.crop((x,y,x+w,y+h))
    assert len(result)==len(panels)
    return result


def board(entry,scope):
    src=checked(entry["image"])
    dst=IMAGES/scope/src.name
    dst.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(src,dst)
    assert reference(dst)["sha256"]==entry["image"]["sha256"]
    entry["image"]["path"]=dst.relative_to(IMAGES).as_posix()
    with Image.open(dst)as raw:
        return pixels(raw,entry["panels"])


def triple(row,scope):
    all_cells=board(row["board"],scope)
    views=board(row["triplet"],scope)
    assert len(views)==3 and {"Noisy Malvar","Exact GT"}<=views.keys()
    assert all(ImageChops.difference(all_cells[k],v).getbbox() is None for k,v in views.items())


def main():
    OUT.mkdir(exist_ok=True)
    stamps={k:reference(ROOT/f"{k}.json")for k in ("geometry","anchored","delivery","blind","serial-audit")}
    records={k:read_json(checked(v))for k,v in stamps.items()}
    geom,anchored,delivery,blind,serial=(records[k]for k in stamps)
    for data in records.values():
        checked(data["driver"])
    assert delivery["geometry"]==anchored["variation_of"]==stamps["geometry"]
    assert blind["prior"]==stamps["delivery"] and delivery["serial_audit"]==stamps["serial-audit"]
    assert blind["checkpoint"]==delivery["checkpoint"]==serial["checkpoint"]
    assert len(blind["rows"])==len(delivery["records"])==len(anchored["simulated"])==20
    assert all(row["query_perturbation_bit_exact"]for row in anchored["simulated"])
    assert len(serial["changed"])==1 and serial["changed"][0]["i"]==17
    assert all(row["matches_display"]for row in serial["native_parity"])
    for row in blind["rows"]:
        checked(row["input"])
        checked(row["parent"])

    native={}
    standing_path=ROOT/"with-blind/standing/manifest.json"
    standing=read_json(standing_path)
    assert standing["exterior_runs"]=={k:stamps[k]for k in ("geometry","anchored","delivery","blind")}
    checked(standing["driver"])
    checked(standing["parent"])
    older_path=Path("docs/images/bayer-shared-phase-v1/manifest.json")
    older={row["id"]:row for row in read_json(older_path)["standing"]["rows"]}
    assert len(standing["rows"])==len(older)==8
    for row in standing["rows"]:
        saved=older[row["id"]]
        assert all(row[k]==saved[k]for k in ("raw","noise","input","parent","roi","native_box","display_exposure"))
        published=board(row["board"],"standing")
        base=published["64-pixel carrier fit"]
        original=older_path.parent/saved["board"]["image"]["path"]
        assert reference(original)["sha256"]==saved["board"]["image"]["sha256"]
        with Image.open(original)as image:
            before=pixels(image,saved["board"]["panels"])
            for label in set(before)&set(published):
                assert ImageChops.difference(before[label],published[label]).getbbox() is None
        row["changed_display_channel_codes"]={
            name:int(np.count_nonzero(np.asarray(view)!=np.asarray(base)))for name,view in published.items()
            if name in ("Exterior bend","Checked donor locations","Checked in crop","Bend at fixed center","Bend with held donors",
                        "Fixed center, check crop","Joint exterior fit","Joint fit, check crop")}
        if "main-chain-link-fence" not in row["id"]:
            assert not any(row["changed_display_channel_codes"].values())
    native["standing"]=standing
    conditional=[r["board"]for r in delivery["records"]if r["board"]]
    assert len(conditional)==2
    for row in conditional:
        triple(row,"exact-center")
    native["exact_center"]=conditional
    examples=read_json(ROOT/"blind-exact/manifest.json")
    assert examples["blind"]==stamps["blind"] and len(examples["rows"])==2
    checked(examples["driver"])
    for row in examples["rows"]:
        triple(row,"noisy-center")
    native["noisy_center"]=examples
    native["viewed"]={"standing":8,"exact":4,"observations":
      "Both standing camera families were reviewed at 160 native pixels per cell. Both cab priors retain their original incomplete and sometimes regular crossings, with some mottle. Main coarse crossing contrast changes subtly. No added sky structure. The noisy-center synthetic pairs show small contrast improvements in a few weave intersections and still miss much of the exact weak texture."}
    manifest=IMAGES/"manifest.json"
    write_json(manifest,native,replace=True)
    accepted={key:sum(d["nomination"]["admitted"]for row in blind["rows"]if row["geometry"]==key
                      for d in row["rows"]if d["role"]=="present") for key in ("bent","straight")}
    files={label:ROOT/label for label in (
        "geometry.py","anchored.py","delivery.py","blind.py","replay_central.py","standing.py","standing_blind.py","blind_native.py",
        "geometry.log","anchored.log","delivery.log","delivery-preflight.log","blind.log","replay-central.log",
        "replay-central-preflight.log","standing-blind-preflight.log","standing-blind.log","standing.log","standing-preflight.log",
        "blind-native.log","publish.py","blind-exact/manifest.json","with-blind/standing/manifest.json","standing/manifest.json",
        "central-replay/delivery.json",
    )}
    files.update({f"{k}.json":checked(v)for k,v in stamps.items()})
    for name in ("shared_phase.py","tangent.py","curve_delivery.py","diagnose.py","render_phase.py"):
        files["prior/"+name]=PRIOR/name
    path=OUT/"evidence.tar.xz"
    with tarfile.open(path,"w:xz",preset=4)as stream:
        for k,v in sorted(files.items()):
            stream.add(v,arcname=k,recursive=False)
    with tarfile.open(path)as raw:
        assert raw.getnames()==sorted(files)
        for k,v in files.items():
            with raw.extractfile(k)as member:
                assert hashlib.file_digest(member,"sha256").hexdigest()==reference(v)["sha256"]
    shutil.copyfile(checked(stamps["serial-audit"]),OUT/"serial-replay.json")
    write_json(OUT/"publication.json",{
        "archive":{"path":path.name,"sha256":reference(path)["sha256"],"entries":len(files)},
        "manifest":{"path":f"../../images/{ROOT.name}/manifest.json","sha256":reference(manifest)["sha256"]},
        "source_receipts":stamps,"serial_correction":{"path":"serial-replay.json","sha256":reference(OUT/"serial-replay.json")["sha256"]},
        "checkpoint":blind["checkpoint"],"standing_parent":standing["parent"],"standing_gate":standing["checkpoint"],
        "admitted_noisy_present_of_20":accepted,"exact_center_summary":delivery["summary"],"noisy_center_summary":blind["summary"],
        "geometry_seconds":geom["seconds"],"render_seconds":delivery["seconds"],"noisy_center_seconds":blind["seconds"],
        "scope":"Scoped inference comparison on previously archived experimental crops. Numerical results use 20 sources and standing qualitative review uses eight crops. No model training or full-panel score."},replace=True)
    print("Archived",len(files),"sources and receipts. Inspected twelve native comparisons.")


if __name__=="__main__":
    main()
