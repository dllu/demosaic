"""Add the noisy-only joint fit to the fixed native standing comparisons."""
from importlib.util import module_from_spec, spec_from_file_location
from unittest.mock import patch

import numpy as np

from geometry import ROOT, phase
from delivery import check_query, correction
import render_phase as prior
from demosaic.experiments.artifacts import checked, read_json, reference

module=spec_from_file_location("exterior_bend_standing",ROOT/"standing.py")
fixed=module_from_spec(module)
module.loader.exec_module(fixed)
CAPTIONS=fixed.CAPTIONS|{"joint":"Joint exterior fit","joint-checked":"Joint fit, check crop"}


def render(raw,layout,wb,matrix,noise,box,exterior,parent,model,roi=None):
    previous,registered=model
    out=fixed.render(raw,layout,wb,matrix,noise,box,exterior,parent,previous,roi)
    roi=phase.ROI if roi is None else tuple(roi)
    x,y,w,_=roi
    _,dose,*_=previous
    position=(box[0]+x,box[1]+y,w)
    row=registered[position]
    spacing,admitted,_=phase.select(exterior,layout,box,roi)
    assert admitted==row["original_admission"]
    profile="nominal" if np.isclose(noise["shot"],.00128,rtol=1e-13,atol=0) else "transferred"
    values=np.array(row["profiles"][profile]["parameters"])
    confirmed=check_query(raw,layout,spacing,roi,values,noise)[0] if admitted else values
    updates=correction(raw,out["distant"],layout,wb,matrix,noise,spacing,roi,dose,admitted,
                      {"joint":values,"joint-checked":confirmed})
    return out|{key:out["distant"]+delta for key,delta in updates.items()}


def main():
    model,receipt=prior.setup()
    refs={k:reference(ROOT/f"{k}.json")for k in ("geometry","anchored","delivery","blind")}
    sets={k:read_json(checked(ref))for k,ref in refs.items()}
    assert sets["delivery"]["geometry"]==refs["geometry"]==sets["anchored"]["variation_of"]
    assert sets["blind"]["prior"]==refs["delivery"]
    diagnostic=read_json(checked(sets["geometry"]["source"]))
    ranks=lambda rows:{tuple(x["box"]):x for x in rows}
    prepared=(*model,ranks(diagnostic["camera"]),ranks(sets["geometry"]["camera"]),ranks(sets["anchored"]["camera"]))
    out=ROOT/"with-blind"
    out.mkdir(exist_ok=True)
    with patch.object(prior,"ROOT",out),patch.object(prior,"CAPTIONS",CAPTIONS),patch.object(prior,"render_models",render):
        prior.standing((prepared,ranks(sets["blind"]["camera"])),
             receipt|{"driver":reference(__file__),"exterior_runs":refs},None)


if __name__=="__main__":
    main()
