"""Exact pilot publication and full-run setup integrity, without inference."""
import gzip
import re
import subprocess
import tarfile
from pathlib import Path
from urllib.parse import unquote
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
file = repo / "docs/results/neural-nuisance-fixed-bg129-v1/publication.json"
publication = read_json(file)
assert publication["viewing"]["actually_viewed"] and len(publication["images"]) == 36
for item in publication["archives"]:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in publication["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
root = repo / ".cache/experiments/neural-nuisance-fixed-bg129-pilot-v1"
with tarfile.open(checked(publication["source_snapshot"]), "r:gz") as tar:
    members = tar.getmembers()
    assert len(members) == publication["source_files_exact"]
    for member in members:
        assert tar.extractfile(member).read() == (root / "work" / member.name).read_bytes()
for source in (root / "work/src").rglob("*.py"):
    assert source.read_bytes() == (repo / "src" / source.relative_to(root / "work/src")).read_bytes()

setup_path = repo / "docs/results/fixed-bg129-full-setup-v1/publication.json"
setup = read_json(setup_path)
for item in setup["archives"]:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
source_files = 0
for source in setup["sources"]:
    with tarfile.open(checked(source["archive"]), "r:gz") as tar:
        members = tar.getmembers()
        assert len(members) == source["files_exact"]
        for member in members:
            assert tar.extractfile(member).read() == (Path(source["work"]) / member.name).read_bytes()
            source_files += 1
for item in read_json(repo / ".cache/experiments/neural-nuisance-fixed-bg129-full-v1/review-preparation-failure-v1.json")["files"]:
    assert reference(item["preserved"])["sha256"] == item["original"]["sha256"]
addendum = read_json(repo / "docs/results/fixed-bg129-full-setup-v1/rehearsal-addendum.json")
assert gzip.decompress(checked(addendum["published"]).read_bytes()) == checked(addendum["original"]).read_bytes()

names = subprocess.check_output(["git", "diff", "--name-only"], text=True).splitlines()
documents = {repo / name for name in names if name.endswith(".md")}
documents.update(repo / name for name in ["docs/global-background-local-carriers.md",
    "docs/global-background-full-panel.md", "diary/2026-11-16-18-14-03-global-background-local-carriers.md"])
links = 0
for path in sorted(documents):
    for target in re.findall(r"\]\(([^\n)]+)\)", path.read_text()):
        if target.startswith(("http:", "https:", "mailto:", "#")):
            continue
        assert (path.parent / unquote(target.split("#", 1)[0]).strip("<>")).exists(), (str(path), target)
        links += 1
output = repo / "docs/results/fixed-bg-publication-verification-v1.json"
archive = output.with_suffix(".py.gz")
with archive.open("xb") as stream:
    stream.write(gzip.compress(Path(__file__).read_bytes(), mtime=0))
assert gzip.decompress(archive.read_bytes()) == Path(__file__).read_bytes()
write_json(output, {"status": "passed", "pilot_publication": reference(file),
    "native_figures_exact_and_actually_viewed": 36, "receipt_archives_exact": len(publication["archives"]),
    "current_package_matches_executed_pilot": True, "full_setup": reference(setup_path),
    "full_setup_frozen_source_files_exact": source_files, "cross_study_rehearsal_addendum": reference(repo / "docs/results/fixed-bg129-full-setup-v1/rehearsal-addendum.json"),
    "local_document_links_checked": links, "documents_checked": [reference(p) for p in sorted(documents)],
    "script": reference(__file__), "script_archive": reference(archive), "new_neural_forwards": 0,
    "scope": "Pilot quality evidence complete; full-panel quality remains pending.167 numerical tests and36 standalone analytic predictions pass; no model inference or GT scoring in publication verification."})
print("36 viewed source figures/165 receipt archives/current numerical package exact;", source_files, "full setup source files;", links, "local links")
