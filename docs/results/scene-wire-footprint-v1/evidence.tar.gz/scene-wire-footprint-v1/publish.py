"""Publish the scene-guide, waveform and companion-gate comparison."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
eight = root.parent / "scene-wire-footprint-eight-v1"
camera = root.parent / "scene-wire-footprint-camera-v1"
control = root.parent / "scene-wire-footprint-eight-controls-v1"
gate = root.parent / "partner-taper-gate-v1"
review = root / "review"
results = Path("docs/results") / root.name
images = Path("docs/images") / root.name
wires = read_json(review / "wires.json")
photos = read_json(review / "camera.json")["rows"]
assert len(wires["boards"]) == 2 and len(photos) == 8
results.mkdir()
images.mkdir()


def adopt(binding):
    source = checked(binding)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return output.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Two synthetic comparison boards and triplets and eight native GFX boards. "
        "AHD and camera JPEGs are qualitative references.",
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in wires["boards"]
        ],
        "camera": [r | {"file": adopt(r["image"])} for r in photos],
    },
)

panels = ("synthetic-iso400", "synthetic-iso6400", "disjoint-iso400", "disjoint-iso6400")
structural = ("fresh400", "fresh6400", "null400", "null6400")
stages = {
    "fundamental": {p: reference(root / f"{p}.json") for p in panels}
    | {"camera": reference(camera / "camera.json")},
    "eight": {p: reference(eight / f"{p}.json") for p in (*panels, "camera")},
    "controls": {p: reference(control / f"{p}.json") for p in structural},
    "companion_gate": {p: reference(gate / f"{p}.json") for p in (*panels, *structural, "camera")},
}
summary = results / "summary.json"
write_json(
    summary,
    {
        "stages": stages,
        "array_controls_verified": {
            kind: sum(read_json(checked(p))["unchanged_arrays"] for p in binding.values())
            for kind, binding in stages.items()
            if kind in ("fundamental", "eight")
        },
        "matched_selection_records": wires["matched_selection_records"],
        "ordinary_wire": wires["groups"],
        "controls": read_json(review / "controls.json"),
        "companion_gate": read_json(review / "gates.json"),
        "camera": [
            {k: r[k] for k in ("id", "RMS_from_V120_DN16", "noise", "checkpoint")} for r in photos
        ],
        "new_checkpoint": None,
    },
)


def stage_files(names):
    return [f"{p}.{ext}" for p in names for ext in ("json", "log")]


members = {
    root: [
        "plan.json",
        "camera.log",
        *stage_files(panels),
        "tests-final.log",
        "review.py",
        "review_gate.py",
        "publish.py",
        "review/wires.json",
        "review/camera.json",
        "review/controls.json",
        "review/gates.json",
        "work/scripts/probe_scene_wire_footprint.py",
    ],
    eight: [
        "plan.json",
        *stage_files((*panels, "camera")),
        "work/scripts/probe_scene_wire_footprint.py",
        "work/scripts/probe_reserved_wire_footprint.py",
    ],
    camera: ["plan.json", *stage_files(("camera",))],
    control: ["plan.json", *stage_files(structural)],
    gate: [
        "plan.json",
        *stage_files((*panels, *structural, "camera")),
        "work/scripts/probe_partner_taper_gate.py",
        "work/src/demosaic/reserved_wire_footprint.py",
    ],
    root.parent / "local-phase-bounds-v1": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            source = folder / name
            m = bundle.gettarinfo(str(source), arcname=f"{folder.name}/{name}")
            m.mtime = m.uid = m.gid = 0
            m.uname = m.gname = ""
            with source.open("rb") as f:
                bundle.addfile(m, f)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparisons_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
