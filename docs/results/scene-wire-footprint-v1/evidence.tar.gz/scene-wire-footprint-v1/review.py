"""Review scene-prior footprint transfer at the same quiet-error limit."""

import argparse
import importlib.util
from itertools import product
from pathlib import Path

import numpy as np
from probe_scene_wire_footprint import PANELS
from probe_surface_aggregation import field
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, write_json

ROOT = Path(__file__).resolve().parent
EIGHT = ROOT.parent / "scene-wire-footprint-eight-v1"
CONTROLS = ROOT.parent / "scene-wire-footprint-eight-controls-v1"
FUNDAMENTAL_CAMERA = ROOT.parent / "scene-wire-footprint-camera-v1"
PRIOR = ROOT.parent / "local-phase-bounds-v1/review.py"
spec = importlib.util.spec_from_file_location("archived_wire_reader", PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)

MODES = ("screened", "uniform", "partner", "partner8")


def guide_diagnostics(case, chosen, trace, width):
    geom = case["metadata"]["recipe"]
    angles = geom["wire_angles"]
    truth = np.column_stack((np.cos(angles), np.sin(angles))) / np.asarray(geom["periods"])[:, None]
    candidates = np.asarray(chosen["frequencies_xy"])
    active = chosen["active"]
    weak_native_bins = None
    both_close = False
    if any(active):
        freqs = candidates[np.asarray(active)]
        distance = width * np.minimum(
            np.linalg.norm(freqs[:, None] - truth[None], axis=2),
            np.linalg.norm(freqs[:, None] + truth[None], axis=2),
        )
        weak_native_bins = float(distance[:, 1].min())
        both_close = len(freqs) == 2 and (
            max(distance[0, 0], distance[1, 1]) <= 1 or max(distance[0, 1], distance[1, 0]) <= 1
        )
    return {
        "active": list(active),
        "closest_to_weak_native_bins": weak_native_bins,
        "both_distinct_within_one": bool(both_close),
        "taper_used": all(active) and trace.get("confirmed", False),
        "selector": trace,
    }


def summary(cases, plan, profile, guides, modes=MODES):
    result = {}
    settings = plan["settings"][profile]
    alpha = settings["scale"]
    for guide, t in product(guides, (0, 1)):
        names = ["parent", *(field(guide, arm, t) for arm in modes)]
        means = {
            arm: {
                k: np.mean([row["moments"][arm][k] for row in cases], axis=0)
                for k in cases[0]["moments"][arm]
            }
            for arm in names
        }
        fixed = {k: evaluated(v, alpha) for k, v in means.items()}
        quiet = fixed[field(guide, "screened", t)]["quiet_RMS_DN16"]
        budget = max(0, quiet - fixed["parent"]["quiet_RMS_DN16"])
        capped = {}
        for k, moment in means.items():
            scale = min(alpha, scale_at_budget(moment["quiet_mse"], budget))
            capped[k] = evaluated(moment, scale) | {"scale": scale}
            assert (
                capped[k]["quiet_RMS_DN16"] <= max(quiet, fixed["parent"]["quiet_RMS_DN16"]) + 2e-9
            )
        result[field(guide, "comparison", t)] = {
            "n": len(cases),
            "threshold": settings["threshold"] + t,
            "fixed_scale": alpha,
            "quiet_limit_DN16": quiet,
            "fixed": fixed,
            "capped": capped,
        }
    return result


def render_wire(out, case, row, p, gt, images, plan):
    with np.load(checked(case["sensor"])) as raw:
        ctx = {k: raw[k][2:3] for k in ("colors", "wb", "matrix")}
        ctx["packed"] = raw["packed"][2:3, :, 64:192, 64:192]
    settings = plan["settings"][case["profile"]]
    parent = p[2][ROI]
    values = [
        parent + settings["scale"] * (images[field("scene", a, 0)][2] - parent) for a in MODES
    ]
    return native_board(
        out,
        case["id"],
        [noisy_malvar(ctx)[0], parent, *values, gt[2][ROI]],
        ctx,
        {
            "case_receipt": row["case"],
            "CFA": case["CFA"],
            "noise": case["metadata"]["noise"],
            "checkpoint": plan["parent_checkpoint"],
            "operating": settings,
            "scene_guide_roles": row["guide_diagnostics"],
        },
        labels=(
            "Noisy Malvar",
            "V143 EMA",
            "Eight-knot uniform",
            "Fundamental uniform",
            "Fundamental taper",
            "Eight-knot taper",
            "Exact GT",
        ),
        triplet_indices=(0, 5, 6),
        contrast=5,
    )


def score_panels(out, plan, panels):
    reviewed, crops, matches = {}, [], 0
    output_receipts = {}
    for panel in panels:
        split, noise = panel.split("-")
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        data = read_json(ROOT / f"{panel}.json")["rows"]
        eight = read_json(EIGHT / f"{panel}.json")["rows"]
        origin = "original_guides" if split == "synthetic" else "disjoint_guides"
        archived = read_json(checked(plan["source"][origin]))["synthetic"]
        poses = {r["id"]: r["roles" if split == "synthetic" else "rankings"] for r in archived}
        cases = []
        for row, full in zip(data, eight, strict=True):
            assert (
                row["id"] == full["id"] and row["witnesses_flexible"] == full["witnesses_flexible"]
            )
            matches += len(row["witnesses_flexible"])
            case, p, gt, quiet, arrays = prior.read_case(row, split)
            with np.load(checked(full["prediction"])) as f:
                for g, t in product(guides, (0, 1)):
                    arrays[field(g, "partner8", t)] = f[field(g, "partner", t)]
            names = ["parent", *(field(g, a, t) for g, a, t in product(guides, MODES, (0, 1)))]
            measurements = {a: measure(p, gt, quiet, arrays[a]) for a in names}
            diagnostics = {
                g: [
                    guide_diagnostics(case, source["fits"][g], trace[g], plan["query_xywh"][2])
                    for source, trace in zip(
                        poses[row["id"]], row["witnesses_flexible"], strict=True
                    )
                ]
                for g in guides
            }
            record = {"id": row["id"], "moments": measurements, "guide_diagnostics": diagnostics}
            cases.append(record)
            if panel == "synthetic-iso400" and case["source"] in (90, 91):
                crops.append(render_wire(out, case, row | record, p, gt, arrays, plan))
        reviewed[panel] = summary(cases, plan, noise, guides)
        output_receipts[panel] = [
            row
            | {
                "moments": {
                    a: {k: v.tolist() for k, v in m.items()} for a, m in row["moments"].items()
                }
            }
            for row in cases
        ]
    return reviewed, crops, output_receipts, matches


def render_camera(out, plan):
    base = read_json(checked(plan["camera_baseline"]))["camera"]
    matched = read_json(FUNDAMENTAL_CAMERA / "camera.json")["rows"]
    eight = read_json(EIGHT / "camera.json")["rows"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    rows = []
    for main, full, old in zip(matched, eight, base, strict=True):
        key, source = old["id"], old["source"]
        assert key == main["id"] == full["id"]
        assert main["flexible_edges"] == full["flexible_edges"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        crop = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = old["display_exposure"]
        variants = {}
        with np.load(checked(full["predictions"])) as a, np.load(checked(main["predictions"])) as b:
            parent = a["parent"][crop].astype(float)
            for g in ("scene", "spectral"):
                for label, data, mode in (
                    ("eight uniform", a, "uniform"),
                    ("eight taper", a, "partner"),
                    ("fund. taper", b, "partner"),
                ):
                    variants[f"{g.title()} {label}"] = data[field(g, mode, 0)][crop]
        pixels = [
            (
                label,
                np.rint(
                    display(value[None], ctx, exposure=exposure)[0].transpose(1, 2, 0) * 255
                ).astype(np.uint8),
            )
            for label, value in variants.items()
        ]
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            out, key, old | {"panels": panels}, "V120 EMA", pixels
        )
        ax, ay, *_ = source["absolute_query_xywh"]
        rows.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "noise": noise[key],
                "checkpoint": source["checkpoint"],
                "display_exposure": exposure,
                "ROI_xywh": [ax + x - qx, ay + y - qy, w, h],
                "CFA": "RGGB",
                "calibration": source["query_arrays"],
                "prediction": full["predictions"],
                "selection": full["flexible_edges"],
                "reference": "DSCF3880 ISO100 AHD"
                if key.startswith("main-")
                else "DSCF3835 ISO100 AHD and both camera JPEGs",
                "RMS_from_V120_DN16": {
                    k: float(np.sqrt(np.mean((v - parent) ** 2)) * 65535)
                    for k, v in variants.items()
                },
            }
        )
    return rows


def reduce_controls():
    result = {"sinusoids": {}, "null": {}}
    retained = ROOT.parent / "reserved-wire-partner-v1"
    for label in ("fresh400", "fresh6400", "null400", "null6400"):
        rows = read_json(CONTROLS / f"{label}.json")["rows"]
        old = read_json(retained / f"{label}.json")["rows"]
        for r, p in zip(rows, old, strict=True):
            assert r["selection"] == p["selection"]
            if label.startswith("null"):
                for k in ("profile", "trial", "style", "CFA"):
                    assert r[k] == p[k]
                for k, v in p["metrics"].items():
                    r["metrics"]["fund-" + k] = v
            else:
                assert r["case"] == p["case"]
                for k, v in p["metrics"].items():
                    r["metrics"]["fund-" + k] = v
        if label.startswith("fresh"):
            result["sinusoids"][label] = aggregate_controls(rows)
        else:
            for r in rows:
                g = (
                    "flat"
                    if r["style"] == "flat"
                    else "straight"
                    if r["style"] in ("step", "rail")
                    else "complex"
                )
                result["null"].setdefault(g, []).append(r)
    result["null"] = {k: aggregate_controls(v) for k, v in result["null"].items()}
    return result


def aggregate_controls(rows):
    metrics = {}
    for arm in rows[0]["metrics"]:
        measures = [r["metrics"][arm] for r in rows]
        for key in measures[0]:
            v = np.asarray([m[key] for m in measures])
            if key.endswith("RMS_DN16"):
                n = np.sqrt(np.mean(v**2))
            elif key == "peak_DN16":
                n = v.max()
            elif key == "changed_pixels":
                key, n = "changed_cases", np.count_nonzero(v)
            else:
                n = v.mean()
            metrics.setdefault(arm, {})[key] = float(n)
    return {"n": len(rows), "metrics": metrics}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task", choices=("wires", "camera", "controls"))
    args = parser.parse_args()
    plan = read_json(ROOT / "plan.json")
    out = ROOT / "review"
    out.mkdir(exist_ok=True)
    if args.task == "camera":
        write_json(out / "camera.json", {"rows": render_camera(out, plan)})
    elif args.task == "wires":
        cells, photos, receipts, verified = score_panels(out, plan, PANELS)
        write_json(
            out / "wires.json",
            {
                "groups": cells,
                "boards": photos,
                "cases": receipts,
                "matched_selection_records": verified,
            },
        )
    else:
        write_json(out / "controls.json", reduce_controls())
