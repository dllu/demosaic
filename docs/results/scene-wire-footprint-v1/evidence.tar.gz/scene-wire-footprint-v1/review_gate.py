"""Measure the optional companion veto using its retained composite predictions."""

from itertools import product

import numpy as np
from probe_scene_wire_footprint import PANELS
from probe_surface_aggregation import field
from report_fold_support_pooling import measure
from review import CONTROLS, EIGHT, ROOT, aggregate_controls, prior, summary

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

GATE = ROOT.parent / "partner-taper-gate-v1"


def wires(plan, panel):
    trace = read_json(GATE / f"{panel}.json")["rows"]
    arrays = read_json(ROOT / f"{panel}.json")["rows"]
    base = read_json(ROOT / "review/wires.json")["cases"][panel]
    split, profile = panel.split("-")
    guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
    moments = []
    for audit, row, previous in zip(trace, arrays, base, strict=True):
        assert audit["id"] == row["id"] == previous["id"]
        _, p, truth, quiet, normal = prior.read_case(row, split)
        extra = {}
        with np.load(checked(audit["prediction"])) as x:
            for g, t in product(guides, (0, 1)):
                extra[field(g, "veto-fund", t)] = measure(p, truth, quiet, x[field(g, "fund", t)])
                extra[field(g, "veto-eight", t)] = measure(p, truth, quiet, x[field(g, "eight", t)])
                for role, gate in enumerate(audit["gates"][g]):
                    if not gate["accepted"]:
                        np.testing.assert_array_equal(
                            x[field(g, "fund", t)][role], normal[field(g, "uniform", t)][role]
                        )
                        np.testing.assert_array_equal(
                            x[field(g, "eight", t)][role], normal[field(g, "screened", t)][role]
                        )
        moments.append({"moments": previous["moments"] | extra})
    choice = {
        g: [sum(row["gates"][g][i]["accepted"] for row in trace) for i in range(3)] for g in guides
    }
    return {
        "selected_per_role": choice,
        "metrics": summary(
            moments,
            plan,
            profile,
            guides,
            ("screened", "uniform", "partner", "partner8", "veto-fund", "veto-eight"),
        ),
    }


def controls():
    stats = {}
    for p in ("fresh400", "fresh6400", "null400", "null6400"):
        rows = read_json(GATE / f"{p}.json")["rows"]
        if p.startswith("null"):
            assert all(not r["gate"]["accepted"] for r in rows)
            old = read_json(CONTROLS / f"{p}.json")["rows"]
            for r, original in zip(rows, old, strict=True):
                assert r["style"] == original["style"] and r["trial"] == original["trial"]
                for suffix in ("", "-strict"):
                    assert r["metrics"]["eight" + suffix] == original["metrics"]["uniform" + suffix]
        else:
            stats[p] = aggregate_controls(rows) | {
                "selected_per_role": [
                    sum(r["gates"][i]["accepted"] for r in rows) for i in range(2)
                ]
            }
    return stats


def cameras():
    rows = read_json(GATE / "camera.json")["rows"]
    full = read_json(EIGHT / "camera.json")["rows"]
    previews = read_json(ROOT / "review/camera.json")["rows"]
    result = []
    for row, source, view in zip(rows, full, previews, strict=True):
        assert row["id"] == source["id"] == view["id"]
        labels = [
            f"{g.title()} eight {'taper' if gate['accepted'] else 'uniform'}"
            for g, gate in row["gates"].items()
        ]
        assert set(labels).issubset({p["label"] for p in view["panels"]})
        result.append(row | {"viewed_panels": labels})
    return result


if __name__ == "__main__":
    result = {
        "plan": reference(GATE / "plan.json"),
        "scenes": {p: wires(read_json(ROOT / "plan.json"), p) for p in PANELS},
        "sinusoids": controls(),
        "camera": cameras(),
    }
    write_json(ROOT / "review/gates.json", result)
