"""Check the completed full publication against its exact original evidence."""
import gzip
import re
import tarfile
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo=Path.cwd()
binding=repo/'docs/results/neural-nuisance-fixed-bg129-full-v1/publication.json'
p=read_json(binding)
assert p['viewing']['actually_viewed'] and p['viewing']['figures']==68
for item in p['archives']:
    assert gzip.decompress(checked(item['published']).read_bytes())==checked(item['original']).read_bytes()
for item in p['images']:
    assert checked(item['published']).read_bytes()==checked(item['original']).read_bytes()
bundles=[p['per_case_receipts'],*p['source_snapshots']]
member_counts=[]
for bundle in bundles:
    with tarfile.open(checked(bundle['archive']),'r:gz')as t:
        assert len(t.getmembers())==len(bundle['members'])
        for item in bundle['members']:
            assert t.extractfile(item['member']).read()==checked(item['original']).read_bytes()
    member_counts.append(len(bundle['members']))
assert member_counts==[2328,164,168]
cross=read_json(checked(p['cross_study_comparison']))
assert cross['paired_input_cases_exact']==1164 and cross['maximum_parent_metric_error']<1e-10
assert cross['independent_source_summary_check']['fields_checked']==1950
native=read_json(checked(p['saved_baseline_panels']))
assert len(native['figures'])==64 and native['new_neural_forwards']==0
names=['README.md','docs/current-model.md','docs/index.md','docs/research.md',
       'docs/weak-detail-literature-2026-11.md','docs/global-background-full-panel.md',
       'docs/global-background-local-carriers.md','docs/neural-guided-phase-full-panel.md',
       'diary/2026-11-16-20-05-08-global-background-full-review.md']
links=0
for name in names:
    path=repo/name
    for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
        target=target.split('#')[0]
        if not target or '://'in target:continue
        assert(path.parent/target).exists(),(name,target)
        links+=1
result={'publication':reference(binding),'script':reference(__file__),'archives_exact':len(p['archives']),
    'images_exact':len(p['images']),'case_receipt_members_exact':member_counts[0],
    'executed_source_members_exact':sum(member_counts[1:]),'saved_baseline_boards':64,
    'paired_input_cases_exact':1164,'independent_cross_summary_fields':1950,
    'local_MD_links_checked':links,'new_neural_forwards':0,
    'scope':'Original frozen full execution and all68 actual native views checked. Later guided development is separate; no full-source rewrite or NN replay. Stronger response/full RGB and reduced real ripple have explicit quiet/increment and weak-crossing limitations.'}
write_json(repo/'docs/results/fixed-bg129-full-publication-verification-v1.json',result)
print(result)
