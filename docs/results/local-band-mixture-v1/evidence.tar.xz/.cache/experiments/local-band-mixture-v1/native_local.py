"""Render unchanged native crop coordinates for the fitted Corpus/local experiment."""
from pathlib import Path

import numpy as np
import torch

from collect_local import ROOT,PREVIOUS
from local_fields import fields,apply
from local_band_review import RAW,PARENT,LOCAL,REF,LABELS,generate
from upper import ROI
from native import old_pixels,native_png
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

PREVIEW=Path('docs/images/green-covariance-refit-v1/manifest.json')


def exact(review,profile):
    target=ROOT/'exact'
    target.mkdir(exist_ok=True)
    known=[r for r in review['wire']if r['gap_pixels']]
    choices=[min(known,key=lambda r:r['scores'][RAW]['intact_increment_RMS_DN16']-r['scores'][LOCAL]['intact_increment_RMS_DN16']),
             max(review['photo'],key=lambda r:r['scores'][RAW]['fine_increment_RMS_DN16']-r['scores'][LOCAL]['fine_increment_RMS_DN16'])]
    views=[]
    for row in choices:
        with (np.load(checked(row['input']),allow_pickle=False)as src,
              np.load(checked(row['model_outputs']),allow_pickle=False)as models):
            args={k:src[k]for k in src.files}
            rendered=generate(args,models,profile,review['applied_coefficients'])
        camera={k:args[k][None]for k in ('wb','matrix','colors')}|{'packed':args['packed'][0:1]}
        labels=(REF,PARENT,LOCAL,'Uniform blend','Subband blend','Flipped RAW blend',RAW)
        layers=[noisy_malvar(camera)[0],*[rendered[k][0]for k in labels],args['target'][0]]
        source=row['source']
        typ=source['kind']
        key=f"{source['index']:02d}-{typ}-iso6400"
        exposure=2. if typ=='wire' else 1/.33
        contrast=1. if typ=='wire' else 2.
        inputs=dict(source=source,query=row['box'],noise=profile,input=row['input'],models=row['model_outputs'])
        views.append(native_board(target,key,layers,camera,inputs,labels=('Noisy Malvar',*labels,'Exact GT'),
                   triplet_indices=(0,7,8),exposure=exposure,contrast=contrast,roi=ROI))
    return views


def standing(review,record):
    parent_ref=reference(PREVIEW)
    known=read_json(checked(parent_ref))
    assert known['checkpoints']['100k']==record['checkpoints']['parent']
    assert known['checkpoints']['transport']['none']==record['checkpoints']['local']
    root=ROOT/'standing'
    root.mkdir(exist_ok=True)
    compiled=[]
    torch.set_num_threads(2)
    for row in known['standing']:
        roi,profile,box=row['roi'],row['noise'],row['native_sensor_box']
        with np.load(checked(row['input']),allow_pickle=False)as z:
            c={k:z[k][0]for k in ('packed','wb','matrix','colors')}
        p=np.load(checked(row['parent_images']['parent100k']),allow_pickle=False)[0]
        with np.load(checked(row['predictions']),allow_pickle=False)as z:
            q=z['local'][0]
        basis=fields(p,q,c,profile,roi)
        choices={LABELS[k]:apply(q,v,review['applied_coefficients'][k]['weights'],roi)for k,v in basis.items()}
        original=row['board']
        file=PREVIEW.parent/original['image']['path']
        assert reference(file)['sha256']==original['image']['sha256']
        earlier=old_pixels(original|{'image':reference(file)})
        wb,matrix=(torch.from_numpy(c[key][None])for key in ('wb','matrix'))
        def show(value):
            pixels=display_crop(torch.from_numpy(value[None]),wb,matrix,roi,exposure=row['exposure'])
            return np.rint(np.clip(pixels,0,1)*255).astype(np.uint8)
        np.testing.assert_array_equal(show(q),earlier['Local 47.5k'])
        np.testing.assert_array_equal(show(p),earlier['Parent 100k EMA'])
        fixed=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Local 47.5k')
        panels=[(k,earlier[k])for k in fixed if k in earlier]
        panels.extend((key,show(a))for key,a in choices.items())
        panels.extend((k,earlier[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in earlier)
        x,y,w,h=roi
        coords=np.s_[:,y:y+h,x:x+w]
        change={}
        for label,a in choices.items():
            diff=(a[coords].astype(float)-q[coords])*65535
            change[label]=dict(RMS_DN16=float(np.sqrt(np.mean(diff**2))),max_DN16=float(np.max(np.abs(diff))))
        composed=choices[RAW][coords].astype(float)-q[coords]
        rhs=choices['Flipped RAW blend'][coords].astype(float)-q[coords]
        result=native_png(root/f"{row['id']}.png",panels)
        compiled.append(dict(id=row['id'],board=result,previous=row['board'],source=row['raw'],input=row['input'],
                      model_arrays={'parent':row['parent_images']['parent100k'],'local':row['predictions']},
                      noise=profile,exposure=row['exposure'],roi=roi,box=box,comparison=change,
                      compared_RMS_DN16=float(np.sqrt(np.mean((composed-rhs)**2))*65535)))
    assert len(compiled)==8
    return {'older':parent_ref,'rows':compiled}


def main():
    bind=reference(ROOT/'review.json')
    review=read_json(checked(bind))
    plan=read_json(checked(read_json(checked(review['capture_receipt']))['plan']))
    exact_views=exact(review,plan['profile'])
    views=standing(review,plan)
    write_json(ROOT/'native.json',dict(driver=reference(__file__),review=bind,checkpoints=plan['checkpoints'],
                  exact=exact_views,standing=views))
    print('native',len(exact_views),len(views['rows']),flush=True)


if __name__=='__main__':
    main()
