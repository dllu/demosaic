"""Subband interpolation between a quiet local restoration and its Corpus parent."""
from functools import lru_cache

import numpy as np
from scipy.fft import irfft2,rfft2

from green_phase_power import raw_support,raised
from upper import taper,luma

KINDS=('uniform','subband','raw_gated','flipped')
PLANES={'uniform':('full',),'subband':('low','fine'),
        'raw_gated':('low quiet','low one direction','low crossed','fine quiet','fine one direction','fine crossed'),
        'flipped':('low quiet','low one direction','low crossed','fine quiet','fine one direction','fine crossed')}
PADDING=24


@lru_cache(maxsize=4)
def transfers(h,w):
    fx=np.fft.rfftfreq(w)
    fy=np.fft.fftfreq(h)
    radial=np.hypot(fx[None],fy[:,None])
    middle=raised(.105,.132,radial)
    top=raised(.295,.342,radial)
    return np.stack((1-middle,middle*(1-top)))


def spectral(value,index=None):
    edge=((0,0),)*(value.ndim-2)+((PADDING,PADDING),(PADDING,PADDING))
    mirrored=np.pad(value,edge,mode='reflect')
    h,w=mirrored.shape[-2:]
    weights=transfers(h,w)
    if index is not None:
        weights=weights[index]
    powers=rfft2(mirrored,workers=1)*weights
    band=irfft2(powers,s=(h,w),workers=1)
    return band[...,PADDING:-PADDING,PADDING:-PADDING]


def partition(raw,profile,roi):
    weights,_=raw_support(raw,profile,roi)
    strongest=weights.max(0)
    crossed=np.maximum(np.minimum(weights[0],weights[2]),np.minimum(weights[1],weights[3]))
    result=np.stack((1-strongest,strongest-crossed,crossed))
    assert np.all(result>=0) and np.max(np.abs(result.sum(0)-1))<2e-15
    return result


def fields(parent,local,camera,profile,roi):
    x,y,w,h=roi
    patch=np.s_[:,y:y+h,x:x+w]
    diff=parent[patch].astype(np.float64)-local[patch]
    direction=np.linalg.solve(camera['matrix'].astype(float),np.ones(3))/camera['wb']
    # Coarse transport retains the actual endpoint color differences. Fine
    # transport is neutral rendered luma. Q delivers the highest frequencies.
    low=spectral(diff,0)
    fine=spectral(luma(diff,camera['wb'],camera['matrix']),1)
    taper_weight=taper()
    blend=np.stack((spectral(low,0),direction[:,None,None]*spectral(fine,1)))*taper_weight
    weights=partition(camera,profile,roi)
    def regional(guides):
        low_components=spectral(low[None]*guides[:,None],0)
        fine_components=spectral(fine[None]*guides,1)
        return np.concatenate((low_components,fine_components[:,None]*direction[None,:,None,None]))*taper_weight
    values=dict(uniform=(diff*taper_weight)[None],subband=blend,
                raw_gated=regional(weights),flipped=regional(weights[:,::-1,::-1]))
    return {name:v.astype(np.float32)for name,v in values.items()}


def apply(local,basis,coefficients,roi):
    x,y,w,h=roi
    out=local.copy()
    correction=np.tensordot(np.asarray(coefficients,dtype=np.float64),basis.astype(np.float64),axes=(0,0))
    out[...,y:y+h,x:x+w]+=correction.astype(np.float32)
    return out


def verify():
    x=np.arange(160)
    phase=lambda f:np.broadcast_to(np.cos(2*np.pi*f*x)[None],(160,160))
    crop=np.s_[42:-42,42:-42]
    rows={}
    for frequency in (1/32,3/16,7/16):
        a=phase(frequency)
        v=spectral(a)
        ratios=[float(np.linalg.norm(f[crop])/np.linalg.norm(a[crop])) for f in v]
        rows[str(frequency)]=ratios
    assert rows['0.03125'][0]>.99 and rows['0.03125'][1]<.02
    assert rows['0.1875'][0]<.02 and rows['0.1875'][1]>.98
    assert max(rows['0.4375'])<.02
    return rows
