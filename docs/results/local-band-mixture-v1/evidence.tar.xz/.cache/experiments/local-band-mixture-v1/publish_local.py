"""Publish bounded-blend evidence after actual native review."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from collect_local import ROOT,PREVIOUS
from local_fields import fields
from upper import ROI
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

RESULTS=Path('docs/results')/ROOT.name
IMAGES=Path('docs/images')/ROOT.name


def keep(board):
    source=checked(board['image'])
    target=IMAGES/source.parent.name/source.name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert reference(target)['sha256']==board['image']['sha256']
    im=np.asarray(Image.open(target).convert('RGB'))
    values={}
    for cell in board['panels']:
        x,y,w,h=cell['png_xywh']
        assert w==h==160
        values[cell.get('label',cell.get('name'))]=im[y:y+h,x:x+w]
    board['image']['path']=str(target.relative_to(IMAGES))
    return values


def closure(receipt,detail):
    one=receipt['rows'][0]
    with (np.load(checked(one['input']),allow_pickle=False)as z,
          np.load(checked(one['model_outputs']),allow_pickle=False)as model):
        cam={k:z[k]for k in ('colors','wb','matrix')}|{'packed':z['packed'][0]}
        terms=fields(model['parent'][0],model['local'][0],cam,detail['profile'],ROI)
    errors={}
    for mode in ('raw_gated','flipped'):
        reunited=terms[mode].astype(float).reshape(2,3,*terms[mode].shape[1:]).sum(1)
        gap=float(np.max(np.abs(reunited-terms['subband'])))
        assert gap<1e-8
        errors[mode]=gap
    return errors


def main():
    RESULTS.mkdir(parents=True,exist_ok=True)
    labels=('plan','confirmation','research-plan','fit','review','native','registration')
    receipts={key:reference(ROOT/f'{key}.json') for key in labels}
    result={key:read_json(checked(bind))for key,bind in receipts.items()}
    plan,confirm,fit,review,registration=(result[key]for key in ('plan','confirmation','fit','review','registration'))
    native=deepcopy(result['native'])
    assert confirm['plan']==receipts['plan'] and fit['plan']==receipts['research-plan']
    assert review['capture_receipt']==receipts['confirmation'] and review['fit']==receipts['fit']
    assert native['review']==registration['source']==receipts['review'] and native['checkpoints']==plan['checkpoints']
    assert len(native['standing']['rows'])==8 and len(native['exact'])==2
    assert len(review['wire'])==len(review['photo'])==24 and len(registration['rows'])==24
    for endpoint in plan['checkpoints'].values():
        checked(endpoint)
    for item in native['standing']['rows']:
        board=keep(item['board'])
        assert 'Registered RAW blend'in board and 'ISO100 AHD reference'in board
        if item['id'].startswith('mesh'):
            assert 'ISO6400 camera JPEG'in board and 'ISO100 camera JPEG'in board
    for view in native['exact']:
        board=keep(view['board'])
        pins=keep(view['triplet'])
        assert list(pins)==['Noisy Malvar','Registered RAW blend','Exact GT']
        assert all(np.array_equal(pin,board[k])for k,pin in pins.items())
    source=IMAGES/'manifest.json'
    write_json(source,{**native,'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    test=closure(confirm,plan)
    archive=RESULTS/'evidence.tar.xz'
    files=[*ROOT.glob('*.py'),*ROOT.glob('*.log'),*(checked(b) for b in receipts.values()),
           PREVIOUS/'green_phase_power.py',PREVIOUS/'fresh_fields.py',PREVIOUS/'wire_math.py',
           PREVIOUS/'transport.py',checked(plan['paired_checkpoint_receipt']),Path('scripts/report_scene_wave_guides.py'),
           Path('configs/gfx-qualitative-20231231.json'),Path('configs/gfx-green-mesh-20231231.json')]
    members={str(p.absolute().relative_to(Path.cwd())):p for p in files}
    with tarfile.open(archive,'x:xz',dereference=True,preset=4)as tar:
        for name,p in sorted(members.items()):
            tar.add(p,arcname=name,recursive=False)
    with tarfile.open(archive)as tar:
        for name,p in members.items():
            with tar.extractfile(name)as data:
                assert hashlib.file_digest(data,'sha256').hexdigest()==reference(p)['sha256']
    write_json(RESULTS/'publication.json',dict(receipts=receipts,weights=fit['results'],
                verified_sum_of_regional_bands=test,filter_test=fit['phase_test'],checkpoints=plan['checkpoints'],
                calibration=fit['development'],wire_photo_results=review['summary'],
                registration=registration['summary'],registration_dose=registration['pooled_added_luma_RMS_DN16'],
                inference_seconds=confirm['inference_seconds'],native=reference(source),archive=reference(archive)))
    print(len(members),len(list(IMAGES.rglob('*.png'))),test,flush=True)


if __name__=='__main__':
    main()
