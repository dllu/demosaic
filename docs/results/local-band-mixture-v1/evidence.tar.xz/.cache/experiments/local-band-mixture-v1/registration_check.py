"""Isolate alignment with the same gated weights in both wire paths."""
import time

import numpy as np

from collect_local import ROOT
from fit_local import assemble,metric_for_wire
from local_fields import apply
from upper import ROI,luma
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

TREATMENT='registered'
CONTROL='same coefficients, flipped RAW'


def main():
    start=time.monotonic()
    compared=reference(ROOT/'review.json')
    results=read_json(checked(compared))
    record=read_json(checked(read_json(checked(results['capture_receipt']))['plan']))
    weights=results['applied_coefficients']['raw_gated']['weights']
    rows=[]
    for row in results['wire']:
        with (np.load(checked(row['input']),allow_pickle=False)as f,
              np.load(checked(row['model_outputs']),allow_pickle=False)as source):
            args={k:f[k]for k in f.files}
            q=source['local']
            options=assemble(source['parent'],q,args,record['profile'])
        metric=metric_for_wire(args,row['source']['geometry'])
        modes={TREATMENT:apply(q,options['raw_gated'],weights,ROI),
               CONTROL:apply(q,options['flipped'],weights,ROI)}
        values={k:metric(v)for k,v in modes.items()}
        assert all(abs(values[TREATMENT][key]-row['scores']['Registered RAW blend'][key])<1e-7
                   for key in values[TREATMENT])
        band=np.s_[...,64:192,64:192]
        energies={key:float(np.mean(luma((v-q)[band],args['wb'],args['matrix'])**2)*65535**2)
                  for key,v in modes.items()}
        rows.append(dict(source=row['source']['source']['id'],input=row['input'],
                         scores=values,actual_added_luma_MSE=energies,gap_pixels=row['gap_pixels']))
    rng=np.random.default_rng(202611191104)
    summary={}
    for key in rows[0]['scores'][TREATMENT]:
        actual=[x['scores']for x in rows if key in x['scores'][TREATMENT]]
        delta=np.asarray([x[TREATMENT][key]-x[CONTROL][key]for x in actual])
        n=len(delta)
        resample=rng.integers(n,size=(6500,n))
        summary[key]=dict(delta=float(delta.mean()),interval=np.quantile(delta[resample].mean(1),(.025,.975)).tolist(),n=n)
    energy={key:float(np.sqrt(np.mean([r['actual_added_luma_MSE'][key]for r in rows])))for key in (TREATMENT,CONTROL)}
    write_json(ROOT/'registration.json',dict(driver=reference(__file__),source=compared,
                 scope='Post-fit diagnostic. Both arms use the same development-fit coefficients.',
                 weights=weights,pooled_added_luma_RMS_DN16=energy,summary=summary,rows=rows,
                 elapsed_seconds=time.monotonic()-start))
    print(energy,summary,flush=True)


if __name__=='__main__':
    main()
