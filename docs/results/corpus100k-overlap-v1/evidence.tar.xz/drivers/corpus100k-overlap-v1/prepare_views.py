"""Lay out the saved native cells for manual review without resizing."""

from pathlib import Path

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json

ROOT = Path(__file__).resolve().parent


def sheet(name, rows, labels):
    row_w = 160 * len(labels)
    row_h = 192
    canvas = Image.new("RGB", (row_w, row_h * len(rows)), "#191c21")
    draw = ImageDraw.Draw(canvas)
    for i, row in enumerate(rows):
        title = row.get("id", str(i + 1))
        y = i * row_h
        draw.text((3, y + 2), title, fill="#eeeeee")
        data = row["board"]
        with Image.open(checked(data["image"])) as png:
            for j, label in enumerate(labels):
                cell = next(p for p in data["panels"] if p.get("label", p.get("name")) == label)
                x0, y0, w, h = cell["png_xywh"]
                assert (w, h) == (160, 160)
                tile = png.crop((x0, y0, x0 + w, y0 + h))
                canvas.paste(tile, (j * 160, y + 30))
                draw.text((j * 160 + 1, y + 15), label, fill="#d0d3d8")
    canvas.save(ROOT / f"view-{name}.png")


def main():
    full = read_json(ROOT / "full-review.json")
    quality = read_json(ROOT / "quality.json")
    keys = ["IEEE FP32 / 64", "TensorRT FP16 / 64", "TensorRT FP16 / 48", "TensorRT FP16 / 32"]
    main = full["main"]
    cab = quality["cab"]
    sheet("main", main, keys)
    sheet(
        "main-references",
        main,
        ["Noisy Malvar", "IEEE FP32 / 64", "TensorRT FP16 / 32", "ISO100 AHD reference"],
    )
    sheet("cab", cab, keys)
    sheet(
        "cab-references",
        cab,
        ["Noisy Malvar", "ISO100 ref, not GT", "SOOC ISO6400 JPEG", "SOOC ISO100 JPEG"],
    )
    sheet(
        "cab-display4",
        [row | {"board": row["configured_board"]} for row in cab],
        ["Noisy Malvar", "TensorRT FP16 / 64", "TensorRT FP16 / 32", "ISO100 ref, not GT"],
    )
    sheet(
        "exact",
        [{"id": r["id"], "board": r["boards"]["board"]} for r in quality["exact"] if "boards" in r],
        [
            "Noisy Malvar",
            "TensorRT FP16 / 64",
            "TensorRT FP16 / 48",
            "TensorRT FP16 / 32",
            "Exact GT",
        ],
    )
    sheet("tails", [{"id": k, "board": v["board"]} for k, v in full["full"].items()], keys)


if __name__ == "__main__":
    main()
