"""Measure true weak signals and exact weak gaps crossing a changed tile seam."""

from statistics import mean

import numpy as np
import torch
from review_geometry import ROOT, build_refs, engine_set, prior, restore
from wires import KEYS, LUMA, SOURCE, evaluate

from demosaic.archive_metrics import linear_rgb

# Symmetric extension in whole Bayer cells places the middle of the
# frozen observation at x=480 on a 512×1440 canvas.
PAD_LEFT, PAD_RIGHT = 112, 352
OBS_START = 2 * PAD_LEFT
OBS_WIDTH = 512


def coefficients(terms):
    return np.linalg.pinv(terms)[-4:]


@torch.inference_mode()
def main():
    prior.prepare()
    result = prior.read_json(ROOT / "benchmark.json")
    model, checkpoint = prior.bound_model()
    refs = build_refs(3)
    assert refs == result["plans"] and checkpoint == result["checkpoint"]
    engines = engine_set(refs)
    plan, captures = (prior.read_json(SOURCE / f"{name}.json") for name in ("plan", "captures"))
    assert plan["roles"][:4] == ["present", "outside-only", "strong-only", "quiet"]
    x, y = np.meshgrid(np.arange(128, dtype=float) - 63.5, np.arange(128, dtype=float) - 63.5)
    x, y = x.ravel(), y.ravel()
    rows = []
    modes = ("compiled64", "compiled48", "compiled32")
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for case in captures["rows"]:
            geometry = plan["sources"][case["index"]]["geometry"]
            if geometry["family"] not in ("ellipse", "strip"):
                continue
            profile = {k: plan["profiles"][case["noise"]][k] for k in ("shot", "read")}
            with np.load(prior.checked(case["input"]), allow_pickle=False) as src:
                data = {key: src[key] for key in (*KEYS, "target")}
                coverage = src["support"][64:192, 64:192]
            support, gap = coverage >= 0.97, coverage == 0
            z = 2 * np.pi * (np.asarray(geometry["frequency"]) @ np.stack([x, y]))
            terms = np.column_stack(
                [
                    np.ones_like(x),
                    x,
                    y,
                    x * x,
                    x * y,
                    y * y,
                    np.cos(z[0]),
                    np.sin(z[0]),
                    np.cos(z[1]),
                    np.sin(z[1]),
                ]
            )
            fit = coefficients(terms[support.ravel()])
            fit_gap = coefficients(terms[gap.ravel()])[-2:]
            target = linear_rgb(data["target"], data)
            lum = np.einsum("c,bchw->bhw", LUMA, target)[:, 192:320, 192:320]
            np.testing.assert_array_equal(lum[0][gap], lum[2][gap])
            weak = (lum[0] - lum[2])[support]
            strong = (lum[2] - lum[3])[support]
            packed = np.pad(
                data["packed"], ((0, 0), (0, 0), (0, 0), (PAD_LEFT, PAD_RIGHT)), mode="symmetric"
            )
            raw = prior.unpack(torch.from_numpy(packed))[:, 0]
            assert raw.shape == (4, 512, 1440)
            arrays = [torch.from_numpy(data[key]) for key in ("colors", "wb", "matrix")]
            values = {}
            for mode in modes:
                out = torch.stack(
                    [
                        restore(model, engines, profile, raw[i], *(a[i] for a in arrays), mode)[
                            ..., OBS_START : OBS_START + OBS_WIDTH
                        ]
                        for i in range(4)
                    ]
                ).numpy()
                values[mode] = evaluate(
                    out,
                    data,
                    fit,
                    support,
                    weak,
                    target[3, :, 200:312, 200:312],
                    fit @ weak,
                    fit @ strong,
                )
                image = np.einsum("c,bchw->bhw", LUMA, linear_rgb(out, data))[:, 192:320, 192:320]
                err = image[0][gap] - lum[0][gap]
                paired = image[0][gap] - image[2][gap]
                values[mode].update(
                    gap_luma_RMS_DN16=float(np.sqrt(np.mean(err**2)) * 65535),
                    weak_gap_error_DN16=float(np.linalg.norm(fit_gap @ err) * 65535),
                    paired_leaked_weak_DN16=float(np.linalg.norm(fit_gap @ paired) * 65535),
                )
            rows.append(
                {
                    "input": case["input"],
                    "index": case["index"],
                    "profile": case["noise"],
                    "support": int(support.sum()),
                    "gap": int(gap.sum()),
                    "scores": values,
                }
            )
            if len(rows) % 4 == 0:
                print(len(rows), flush=True)
    assert len(rows) == 24
    summary = {}
    for profile in ("iso400", "iso6400"):
        cases = [row["scores"] for row in rows if row["profile"] == profile]
        assert len(cases) == 12
        summary[profile] = {}
        for candidate in modes[1:]:
            metrics = {}
            for key in cases[0][candidate]:
                values = [row[candidate][key] for row in cases]
                base = [row["compiled64"][key] for row in cases]
                d = [a - b for a, b in zip(values, base, strict=True)]
                metrics[key] = {
                    "value": mean(values),
                    "base": mean(base),
                    "mean_delta": mean(d),
                    "lo": min(d),
                    "hi": max(d),
                }
            summary[profile][candidate] = metrics
    prior.write_json(
        ROOT / "seams.json",
        {
            "driver": prior.reference(__file__),
            "checkpoint": checkpoint,
            "plans": refs,
            "canvas_HW": [512, 1440],
            "pad_whole_Bayer_cells": [PAD_LEFT, PAD_RIGHT],
            "scored_xywh": [OBS_START + 192, 192, 128, 128],
            "source_plan": prior.reference(SOURCE / "plan.json"),
            "captures": prior.reference(SOURCE / "captures.json"),
            "rows": rows,
            "summary": summary,
        },
    )
    for profile, candidates in summary.items():
        print(
            profile,
            {
                k: {m: round(d["mean_delta"], 5) for m, d in row.items()}
                for k, row in candidates.items()
            },
            flush=True,
        )


if __name__ == "__main__":
    main()
