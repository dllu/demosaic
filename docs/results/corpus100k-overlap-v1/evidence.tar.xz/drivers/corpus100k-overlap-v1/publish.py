"""Archive timing and quality receipts and retain only unresized native evidence."""

import shutil
import tarfile
from copy import deepcopy
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
IMAGES = REPO / "docs" / "images" / ROOT.name
RESULTS = REPO / "docs" / "results" / ROOT.name
SECTIONS = ("benchmark", "full-review", "quality", "seams", "visual-review")


def copy_board(board):
    src = checked(board["image"])
    dst = IMAGES / src.name
    shutil.copyfile(src, dst)
    assert reference(dst)["sha256"] == board["image"]["sha256"]
    pixels = np.asarray(Image.open(dst).convert("RGB"))
    board["image"]["path"] = dst.name
    crops = {}
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert (w, h) == (160, 160)
        crops[panel.get("label", panel.get("name"))] = pixels[y : y + h, x : x + w]
        assert crops[panel.get("label", panel.get("name"))].shape == (160, 160, 3)
    return crops


def main():
    receipts = {name: reference(ROOT / f"{name}.json") for name in SECTIONS}
    result = {name: read_json(checked(ref)) for name, ref in receipts.items()}
    bench, full, quality, seams, review = (result[k] for k in SECTIONS)
    assert len({r["checkpoint"]["sha256"] for r in (bench, full, quality, seams)}) == 1
    assert bench["plans"] == quality["plans"] == seams["plans"]
    assert full["benchmark"] == receipts["benchmark"]
    assert review["full"] == receipts["full-review"] and review["quality"] == receipts["quality"]
    assert len(full["main"]) == len(quality["cab"]) == 4 and len(quality["exact"]) == 6
    assert len(seams["rows"]) == 24
    assert len(review["views"]) == 13
    for binding in (bench["source"], bench["checkpoint"], *bench["plans"].values()):
        checked(binding)
    for output in bench["outputs"].values():
        checked(output["tiff"])
        checked(output["crops"])
    for receipt in (bench, full, quality, seams):
        checked(receipt["driver"])

    IMAGES.mkdir(parents=True)
    RESULTS.mkdir(parents=True)
    views = deepcopy(
        {
            "main": full["main"],
            "cab": quality["cab"],
            "exact": quality["exact"],
            "full_delta_outliers": full["full"],
        }
    )
    for row in views["main"] + views["cab"] + list(views["full_delta_outliers"].values()):
        copy_board(row["board"])
    for row in views["cab"]:
        copy_board(row["configured_board"])
    for row in views["exact"]:
        if "boards" not in row:
            continue
        a = copy_board(row["boards"]["board"])
        b = copy_board(row["boards"]["triplet"])
        assert list(b) == ["Noisy Malvar", "TensorRT FP16 / 32", "Exact GT"]
        assert all(np.array_equal(a[label], b[label]) for label in b)

    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "checkpoint": bench["checkpoint"],
            "tile": bench["tile"],
            "batch": bench["batch"],
            "main_noise": bench["profiles"],
            "comparison": views,
            "visual_review": review,
        },
    )
    evidence = RESULTS / "evidence.tar.xz"
    script_names = (
        "benchmark.py",
        "review_geometry.py",
        "seams.py",
        "prepare_views.py",
        "record_visual.py",
        "publish.py",
    )
    prior = ROOT.with_name("corpus100k-trt-dino-v1")
    dependencies = [prior / name for name in ("review.py", "dino_review.py", "dino_engine.py")]
    dependencies.extend(
        ROOT.with_name("corpus100k-trt-tactics-v1") / name
        for name in ("full_quality.py", "wires.py", "tactics.py")
    )
    dependencies.append(REPO / "src" / "demosaic" / "inference.py")
    sources = [ROOT / name for name in script_names] + dependencies
    with tarfile.open(evidence, "x:xz", preset=6) as tar:
        for ref in receipts.values():
            tar.add(checked(ref), arcname=f"receipts/{Path(ref['path']).name}")
        for path in sources:
            arc = f"drivers/{path.parent.name}/{path.name}"
            tar.add(path, arcname=arc)
        for binding in (seams["source_plan"], seams["captures"], *quality["inputs"].values()):
            path = checked(binding)
            tar.add(path, arcname=f"inputs/{path.parent.name}/{path.name}")

    timing = {
        key: {f: v[f] for f in ("tiles", "overlap", "normalize_seconds", "export_seconds")}
        for key, v in bench["outputs"].items()
    }
    write_json(
        RESULTS / "publication.json",
        {
            "id": ROOT.name,
            "checkpoint": bench["checkpoint"],
            "plans": bench["plans"],
            "tile": bench["tile"],
            "batch": bench["batch"],
            "completed": {
                "training": "Existing EMA",
                "full_frame": True,
                "numerical_review": True,
                "native_review": True,
                "fixed_photo_camera": "Prior fixed-context precision panels available. Changed full-image origins evaluated separately.",
            },
            "source": bench["source"],
            "versions": bench["versions"],
            "startup_seconds": {
                k: bench[k] for k in ("decode_seconds", "checkpoint_seconds", "engine_seconds")
            },
            "timings": timing,
            "summary": bench["summary"],
            "full": {
                k: {field: v for field, v in row.items() if field != "board"}
                for k, row in full["full"].items()
            },
            "exact": [
                {"scores": r["scores"], "title": r["provenance"]["photo"]["title"]}
                for r in quality["exact"]
            ],
            "seams": seams["summary"],
            "receipts": receipts,
            "sources": [reference(p) for p in sources],
            "manifest": reference(manifest),
            "evidence": reference(evidence),
        },
    )


if __name__ == "__main__":
    main()
