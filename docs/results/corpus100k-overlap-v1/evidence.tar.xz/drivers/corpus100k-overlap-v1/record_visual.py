"""Record the native inspection notes against the specific source boards."""

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
NOTES = {
    "overcast-sky": "Smooth under all five policies. No new visible texture or seam.",
    "building-detail": "The narrow cables and small braces stay soft across policies. The main beam stays continuous.",
    "foliage": "Leaf silhouettes persist across the grid changes. Fine subdivisions stay soft.",
    "chain-link-fence": "The visible diamonds and crossings persist. The tiny green point below the fence is still present.",
    "mesh-nominal-fine-green-mesh-left": "The nominal left stays mottled. The vertical bar remains visible and most lattice crossings are unresolved at both exposures.",
    "mesh-nominal-fine-green-mesh-right": "Some right diagonals persist across policies. The thin diagonal traces around the cable stay incomplete.",
    "mesh-profile3879-fine-green-mesh-left": "Transferred conditioning reveals weak lower-left traces. Changing overlap does not create coherent intersections beside the bar.",
    "mesh-profile3879-fine-green-mesh-right": "Transferred right diagonals are the clearest. The 32-pixel output is a little darker and the gaps in crossings persist at both exposures.",
    "pinakothek": "Window bars hold across the policies. Very fine horizontal cables and masonry stay softer than the exact target.",
    "highlight": "The saturated yellow background and the shoulder or sleeve tones differ from the exact target across the five policies. The two shorter overlaps show similar contours.",
    "compiled64_vs_ieee": "The saturated magenta sign keeps its shape and color at display x1.",
    "compiled48_vs_compiled64": "The warm halo of the distant pinpoint lamp has different strength and extent.",
    "compiled32_vs_compiled64": "The bright display keeps its red outline. The small adjacent glyphs vary in brightness and color.",
}


def main():
    full = reference(ROOT / "full-review.json")
    quality = reference(ROOT / "quality.json")
    frame, local = read_json(full["path"]), read_json(quality["path"])
    records = {r["id"]: [r["board"]] for r in frame["main"]}
    records.update({r["id"]: [r["board"], r["configured_board"]] for r in local["cab"]})
    records.update(
        {
            r["id"]: [r["boards"][key] for key in ("board", "triplet")]
            for r in local["exact"]
            if "boards" in r
        }
    )
    records.update({name: [item["board"]] for name, item in frame["full"].items()})
    assert set(records) == set(NOTES)
    views = []
    for name, boards in records.items():
        images = [board["image"] for board in boards]
        for image in images:
            checked(image)
        views.append(
            {
                "id": name,
                "images": images,
                "native_160_by_160_pixels": True,
                "observation": NOTES[name],
            }
        )
    write_json(
        ROOT / "visual-review.json",
        {
            "full": full,
            "quality": quality,
            "views": views,
            "cab_camera_JPEGs_and_AHD_viewed": True,
            "reviewed_at_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(
                timespec="seconds"
            ),
        },
    )


if __name__ == "__main__":
    main()
