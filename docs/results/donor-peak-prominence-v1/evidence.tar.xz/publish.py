"""Preserve the measured weak-detail search study and viewed native boards."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path("docs/results/donor-peak-prominence-v1")
IMAGES = Path("docs/images/donor-peak-prominence-v1")


def image_record(binding,subfolder,boxes):
    source = checked(binding)
    destination = IMAGES/subfolder/source.name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)
    assert reference(destination)["sha256"]==binding["sha256"]
    with Image.open(destination)as image:
        for x,y,w,h in boxes:
            assert w==h==160 and x+w<=image.width and y+h<=image.height
        image.verify()
    return {"path":str(destination),"sha256":binding["sha256"]}


def publish():
    RESULTS.mkdir(exist_ok=True)
    metrics = reference(ROOT/"scores.json")
    gap = reference(ROOT/"gap-budget.json")
    check = reference(ROOT/"verification.json")
    scores = read_json(checked(metrics))
    sensitivity = read_json(checked(gap))
    verification = read_json(checked(check))
    exact = read_json(ROOT/"native/manifest.json")
    photos = read_json(ROOT/"standing/manifest.json")
    assert exact["score"]==metrics==photos["scores"]==sensitivity["original"]
    assert exact["checkpoint"]==photos["checkpoint"]
    assert verification["standing"]==photos["proposals"]
    notes = {
        "012-present":"The broad shared edge remains, with mostly the stronger direction visible. The fine secondary lines are subdued.",
        "014-present":"A faint crossing pattern appears over the dark half. The exact pattern remains clearer, with different visibility across the step.",
        "012-outside-only":"The strong direction remains; no comparably clear second direction in the center.",
        "014-outside-only":"A single darker diagonal direction persists, as in the independent exact center.",
        "012-quiet-query":"The exact flat core appears smooth in all outputs.",
        "014-quiet-query":"The exact flat core appears smooth, with slight tonal variation in the restored panels.",
    }
    for row in exact["rows"]:
        src = Path(row["image"]["path"]).name
        row["image"] = image_record(row["image"],"exact",[(160*i,0,160,160)for i,_ in enumerate(row["mode_order"])])
        row["viewing"] = notes[src.rsplit("-",1)[0]]
    camera_notes = {
        "main-overcast-sky-main-overcast-sky":"All variants match Corpus 100k exactly and the sky is smooth.",
        "main-building-detail-main-building-detail":"Reduced change on the building, with long edges and thicker wires intact and no clearly recovered thin wire.",
        "main-foliage-main-foliage":"Large leaf shapes and highlights stay visible, with soft fine boundaries.",
        "main-chain-link-fence-main-chain-link-fence":"The two coarse fence directions remain clear. There is no clear new fine crossing.",
    }
    for row in photos["rows"]:
        row["image"] = image_record(row["image"],"standing",[p["png_xywh"]for p in row["panels"]])
        row["viewing"] = camera_notes.get(row["id"],"The fine cab stays close to the parent. The transferred prior shows faint diagonals and incomplete intersections.")
    assert len(exact["rows"])==len(photos["rows"])==8
    write_json(IMAGES/"manifest.json",{
        "exact":exact,"standing":photos,"actual_native_viewing_complete":True})
    archive = RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for item in (
            "prepare_fields.py","discover.py","probe.py","verify.py","run_restore.py","score_panel.py",
            "gap_budget.py","render_cameras.py","publish.py","plan.json","fields.json","physical-proposals.json",
            "standing-proposals.json","verification.json","restorations.json","scores.json","gap-budget.json",
            "native/manifest.json","standing/manifest.json","prepare.log","physical-proposals.log",
            "standing-proposals.log","verify.log","verify-v2.log","restore.log","score.log","render-standing.log",
        ):
            f.add(ROOT/item,arcname=item)
    write_json(RESULTS/"publication.json",{
        "experiment":"donor-peak-prominence-v1","training_performed":False,
        "numeric_evaluation_complete":True,"actual_native_viewing_complete":True,
        "parent":exact["checkpoint"],"scored_images":reference(IMAGES/"manifest.json"),"archive":reference(archive),
        "selection":scores["test_nominations"],"matched":scores["matched"],"nominal":scores["nominal"],
        "quiet_only_calibration":{"target":scores["calibration_target_DN16"],"scales":scores["scale"]},
        "two_budget_sensitivity":{"limits":sensitivity["limits"],"scales":sensitivity["scales"],"test":sensitivity["test"]},
        "query_exclusions_checked":verification["query_exclusion"],"standing_cab_nearby_bands":verification["cab_prominence"],
        "scope":"32 independent held-out source panels and both standing GFX100S crop families. No whole-model or full427 and known/unseen camera PSNR evaluation for this localized inference diagnostic.",
    })


if __name__=="__main__":
    publish()
