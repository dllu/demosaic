"""Nominate exterior green frequencies by narrow radial peak prominence."""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import map_coordinates,maximum_filter,uniform_filter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/"green-gap-validation-v1"))
from standing import frequency_proposals as previous_discovery

TILE = 96
PERIOD = 256
MODES = ("previous","tiled","prominence")


def boxes(x,y):
    return [(left,top,TILE,TILE) for offset in (0,80,160) for left,top in (
        (x-TILE,y+offset),(x+256,y+offset),(x+offset,y-TILE),(x+offset,y+256))]


@lru_cache(maxsize=1)
def grids():
    axis = np.fft.fftfreq(PERIOD)/2
    fy,fx = np.meshgrid(axis,axis,indexing="ij")
    radius = np.hypot(fx,fy)
    eligible = ((fx>0)|((fx==0)&(fy>0))) & (radius>=.035) & (radius<=.22)
    direction = np.stack((fy,fx))/np.maximum(radius,1e-12)
    offsets = []
    for delta in (-.033,.033):
        frequency = np.stack((fy,fx)) + delta*direction
        offsets.append((frequency*2*PERIOD)%PERIOD)
    xy = np.linspace(-1,1,TILE//2)
    dy,dx = np.meshgrid(xy,xy,indexing="ij")
    design = np.stack((np.ones_like(dx),dx,dy),axis=-1)
    hann = np.hanning(TILE//2)
    taper = hann[:,None]*hann[None]
    weights = design*taper[...,None]
    covariance = np.einsum("ijk,ijl->kl",weights,weights)
    return fy,fx,eligible,offsets,design,taper,np.linalg.inv(covariance)


def tile_scores(arrays,box):
    ygrid,xgrid,valid,sidebands,basis,taper,inverse = grids()
    x,y,w,h = box
    assert x>=0 and y>=0 and x%2==y%2==0
    section = np.s_[0,:,y//2:(y+h)//2,x//2:(x+w)//2]
    raw,variance = (arrays[k][section]for k in ("packed","variance"))
    assert raw.shape==(4,TILE//2,TILE//2)
    fourier = []
    for index in np.flatnonzero(arrays["colors"][0]==1):
        plane = inverse @ np.einsum("hwi,hw,hw->i",basis,taper**2,raw[index])
        residual = raw[index]-basis@plane
        noise_scale = np.sqrt(np.sum(variance[index]*taper**2)).clip(min=1e-9)
        phase = np.exp(-2j*np.pi*((index%2)*xgrid+(index//2)*ygrid))
        fft = np.fft.fft2(residual*taper,s=(PERIOD,PERIOD))
        fourier.append(fft*phase/noise_scale)
    average = lambda a:uniform_filter(a,size=3,mode="wrap")
    z = average((fourier[0]*fourier[1].conj()).real)
    energy = [average(np.abs(v)**2).clip(min=1e-12) for v in fourier]
    agreement = z/np.sqrt(energy[0]*energy[1])
    accepted = valid & (z>=5) & (agreement>=.70)
    shoulders = [map_coordinates(z,c,order=1,mode="grid-wrap",prefilter=False)for c in sidebands]
    floor = np.maximum(1,np.maximum(*shoulders))
    prominence = (z-floor)/(2+floor)
    return np.where(accepted,z,0),np.where(accepted,prominence.clip(min=0),0)


def intersects(left,right):
    a,b,w,h = left
    c,d,u,v = right
    return a < c+u and c < a+w and b < d+v and d < b+h


def candidates(weights, tiles, limit):
    fy,fx,valid,*_ = grids()
    local_max = [maximum_filter(a,size=5,mode="wrap")for a in weights]
    pooled = np.zeros_like(weights[0])
    pairs = [(i,j)for i,j in combinations(range(len(tiles)),2) if not intersects(tiles[i],tiles[j])]
    for i,j in pairs:
        # One tile locates the center. The other may differ by two oversampled bins.
        both = np.maximum(np.minimum(weights[i],local_max[j]),np.minimum(local_max[i],weights[j]))
        pooled = np.maximum(pooled,both)
    proposed = []
    unique = np.argwhere(valid & (pooled>=limit))
    scores = pooled[valid & (pooled>=limit)]
    for row,col in unique[np.argsort(scores,kind="stable")[::-1]]:
        direction = np.array([fx[row,col],fy[row,col]])
        if proposed:
            first = np.array(proposed[0]["frequency_xy"])
            separation = abs(first[0]*direction[1]-first[1]*direction[0])
            if separation < .35*np.linalg.norm(first)*np.linalg.norm(direction):
                continue
        proposed.append({"frequency_xy":direction.tolist(),"score":float(pooled[row,col]),
                         "nearby_tile_scores":[float(s[row,col])for s in local_max]})
        if len(proposed)==2:
            break
    return proposed


def propose(arrays,x,y):
    old = previous_discovery(arrays,x,y)
    tiles = boxes(x,y)
    values = [tile_scores(arrays,b)for b in tiles]
    strength,prominence = zip(*values,strict=True)
    return {"previous":old,
            "tiled":{"exterior_tiles_xywh":tiles,"proposals":candidates(strength,tiles,5)},
            "prominence":{"exterior_tiles_xywh":tiles,"proposals":candidates(prominence,tiles,1.35)}}
