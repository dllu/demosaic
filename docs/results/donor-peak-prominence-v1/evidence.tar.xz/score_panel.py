"""Measure exact weak recovery and false texture after exterior nomination."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display,linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from run_restore import ARGS,METHODS,observations

ROOT = Path(__file__).resolve().parent
CORE = np.s_[...,64:192,64:192]
TRIM = np.s_[...,48:208,48:208]
LUMA = np.array([.2126,.7152,.0722])
METRICS = ("weak_response","increment_DN16","gap_change_DN16","false_gap_response",
           "outside_false_response","strong_only_false_response","quiet_added_DN16","quiet_error_DN16")


def read_prediction(row):
    with np.load(checked(row["output"]),allow_pickle=False)as f:
        return {k:f[k]for k in f.files}


def luma(arr,capture):
    return np.stack([np.einsum("c,bchw->bhw",LUMA,linear_rgb(v,{k:capture[k][i]for k in ("wb","matrix")}))
                     for i,v in enumerate(arr)])[CORE]


def add_rms(v):
    return float(np.sqrt(np.mean(v.reshape(v.shape[0],-1)**2,axis=-1)).mean()*65535)


def project(im,truth):
    return 100*np.sum(im*truth,axis=-1)/np.sum(truth**2)


def analyze(record,pred):
    data = observations(record)
    output = read_prediction(pred)
    target = luma(data["target"],data)
    baseline = luma(output["baseline"],data)
    corrections = {k:luma(output[k],data)for k in METHODS}
    gap_mask = data["region"][CORE]==0
    keep = data["region"][CORE]==1
    assert keep.sum()>300 and gap_mask.sum()>256
    np.testing.assert_array_equal(target[0,0][gap_mask],target[0,1][gap_mask])
    np.testing.assert_array_equal(target[0,1],target[0,2])
    np.testing.assert_array_equal(target[0,3],np.full((128,128),target[0,3,0,0]))
    reference = target[0,0]-target[0,1]
    nominal = data["weak_linear_nominal"][CORE]
    gain = np.dot(reference[keep],nominal[keep])/np.dot(nominal[keep],nominal[keep])
    assert .2 < gain < .5
    support = nominal*gain
    return baseline,corrections,target,gap_mask,keep,reference,support


def values(saved,name,scale):
    baseline,lifts,target,gap,keep,extra,support = saved
    change = np.zeros_like(baseline) if name=="baseline" else scale*lifts[name]
    output = baseline+change
    delta = output[:,0]-output[:,1]
    return dict(zip(METRICS,(
        float(project(delta[:,keep],extra[keep]).mean()),
        add_rms((delta-extra)[:,keep]),
        add_rms(change[:,0][:,gap]),
        float(np.abs(project(delta[:,gap],support[gap])).mean()),
        float(np.abs(project((output[:,1]-target[:,1]).reshape(2,-1),support.ravel())).mean()),
        float(np.abs(project((output[:,2]-target[:,2]).reshape(2,-1),support.ravel())).mean()),
        add_rms(change[:,3]),
        add_rms(output[:,3]-target[:,3]),
    ),strict=True))


def reduce(rows):
    rng = np.random.default_rng(802192)
    draws = rng.integers(len(rows),size=(10000,len(rows)))
    result = {}
    comparisons = (("tiled","previous"),("prominence","previous"),("prominence","tiled"),
                   ("prominence","baseline"),("exact","prominence"))
    for metric in METRICS:
        data = {k:np.array([r["results"][k][metric]for r in rows])for k in ("baseline",*METHODS)}
        intervals = {}
        for new,old in comparisons:
            pair = data[new]-data[old]
            low,high = np.quantile(pair[draws].mean(-1),[.025,.975])
            intervals[f"{new}_vs_{old}"] = [float(pair.mean()),float(low),float(high)]
        result[metric] = {"means":{k:float(x.mean())for k,x in data.items()},"paired_diff_95pct":intervals}
    return result


def nominations(ordered):
    output = {}
    for role in ("present","outside-only","strong-only","quiet-query"):
        output[role] = {}
        for mode in METHODS[:-1]:
            rows = [d["methods"][mode]for r in ordered for d in r["draws"]if d["role"]==role]
            counts = {}
            for tolerance in (1.,2.,3.):
                def hit(x,k):
                    return x is not None and x <= tolerance
                boolean = [(hit(r["distance_in_query_bins"]["strong"],"strong"),
                            hit(r["distance_in_query_bins"]["weak"],"weak"))for r in rows]
                counts[str(tolerance)] = {"strong":sum(s for s,w in boolean),"weak":sum(w for s,w in boolean),
                                          "both":sum(s and w for s,w in boolean)}
            output[role][mode] = {"draws":len(rows),"accepted_pair":sum(a["pair"]for a in rows),
                                  "hits_by_tolerance_query_DFT_bins":counts}
    return output


def main():
    source = reference(ROOT/"restorations.json")
    recipes = read_json(checked(source))
    proposals = read_json(checked(recipes["source"]))
    captures = read_json(checked(proposals["fields"]))
    plan = read_json(checked(captures["plan"]))
    evaluated = []
    for case,pred,layout in zip(captures["rows"],recipes["cases"],plan["sources"],strict=True):
        assert case["index"]==pred["index"]==layout["index"]
        evaluated.append((layout,analyze(case,pred)))
    fit = [s for r,s in evaluated if r["index"] in plan["fit_indices"]]
    quiet = {k:float(np.mean([values(s,k,1)["quiet_added_DN16"]for s in fit]))for k in METHODS}
    budget = min(quiet.values())
    assert budget > 0
    scale = {k:budget/x for k,x in quiet.items()}

    def score(items,scale):
        return [{"index":r["index"],"source":r["source"]["id"],"shape":r["layout"]["shape"],
                  "results":{k:values(s,k,scale.get(k,1))for k in ("baseline",*METHODS)}}for r,s in items]

    test = [(r,s)for r,s in evaluated if r["index"] in plan["test_indices"]]
    fitted = score([pair for pair in evaluated if pair[0]["index"] in plan["fit_indices"]],{})
    nominal = score(test,{})
    matched = score(test,scale)
    write_json(ROOT/"scores.json",{
        "restoration":source,"driver":reference(__file__),
        "scope":"Preset strength per path on the independent calibration fields at mean equal added RMS in exact-flat query, where both carriers continue strictly outside. A synthetic exact-frequency arm bounds the phase fit at the same quiet budget. The quiet arm is exact in the central 128 native pixels. Present and outside-only have matched exterior content and independent sensor noise. All metrics use the same linear luma transform.",
        "scale":scale,"calibration_quiet_added_DN16_nominal":quiet,"calibration_target_DN16":budget,
        "test_nominations":nominations([r for r in proposals["outputs"]if r["index"] in plan["test_indices"]]),
        "calibration_rows":fitted,"nominal_rows":nominal,"matched_rows":matched,
        "nominal":reduce(nominal),"matched":reduce(matched)})
    print("scored",flush=True)


def render():
    torch.set_num_threads(2)
    stem = reference(ROOT/"scores.json")
    score = read_json(checked(stem))
    recipes = read_json(checked(score["restoration"]))
    proposals = read_json(checked(recipes["source"]))
    captures = read_json(checked(proposals["fields"]))
    plan = read_json(checked(captures["plan"]))
    folder = ROOT/"native"
    folder.mkdir(exist_ok=True)
    rows = []
    for shape in ("stripe","ellipse"):
        source = next(r for r in plan["sources"]if r["index"] in plan["test_indices"]and r["layout"]["shape"]==shape)
        idx = source["index"]
        record,pred = captures["rows"][idx],recipes["cases"][idx]
        data = observations(record)
        out = read_prediction(pred)
        camera = {k:data[k][0]for k in ("wb","matrix")}
        base = out["baseline"][0]
        noisy = malvar(torch.from_numpy(data["packed"][0]),torch.from_numpy(data["colors"][0])).numpy()
        restored = {"noisy":noisy,"baseline":base,"GT":data["target"][0],
                    **{k:base+score["scale"][k]*out[k][0]for k in METHODS}}
        converted = {k:np.rint(display(v,camera,exposure=2)[TRIM].transpose(0,2,3,1)*255).astype(np.uint8)
                     for k,v in restored.items()}
        for role_no,role in ((0,"present"),(1,"outside-only"),(3,"quiet-query")):
            selections = [("comparison",("baseline","previous","tiled","prominence","exact","GT"))]
            if role_no==0:
                selections += [("triplet",("noisy","prominence","GT"))]
            for kind,modes in selections:
                image = np.concatenate([converted[k][role_no]for k in modes],axis=1)
                dest = folder/f"{idx:03d}-{role}-{kind}.png"
                Image.fromarray(image).save(dest,optimize=True)
                rows.append({"image":reference(dest),"case":idx,"role":role,"mode_order":modes,
                    "width":image.shape[1],"height":image.shape[0],"roi_in_query_xywh":[48,48,160,160],
                    "outer_photo_box_xywh":source["box"],"query_box_xywh":plan["query_box"],
                    "camera_profile":plan["profile"],"display_exposure":2,"repeat":0,"capture":record,
                    "inference":pred,"CFA":source["camera"]["pattern"],"source":source["source"]})
    write_json(folder/"manifest.json",{"driver":reference(__file__),"score":stem,"rows":rows,
                                 "display":"fixed common WB and matrix then ×2 exposure and clipped sRGB8",
                                 "checkpoint":plan["base"]})


if __name__=="__main__":
    main()
    render()
