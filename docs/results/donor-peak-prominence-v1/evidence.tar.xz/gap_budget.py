"""Recheck the search at the previous method's calibration gap and flat budgets."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from score_panel import METHODS,analyze,reduce,values

ROOT = Path(__file__).resolve().parent


def main():
    original = reference(ROOT/"scores.json")
    summary = read_json(checked(original))
    settings = read_json(checked(summary["restoration"]))
    proposals = read_json(checked(settings["source"]))
    captures = read_json(checked(proposals["fields"]))
    plan = read_json(checked(captures["plan"]))
    controls = summary["calibration_rows"]
    limits = {key:{k:float(np.mean([r["results"][k][key]for r in controls]))for k in METHODS}
              for key in ("gap_change_DN16","quiet_added_DN16")}
    budgets = {k:summary["scale"]["previous"]*v["previous"] for k,v in limits.items()}
    scale = {k:min(1,*(budgets[key]/v[k] for key,v in limits.items()))for k in METHODS}
    assert abs(scale["previous"]-summary["scale"]["previous"]) < 1e-12
    rows = []
    for sample,pred,source in zip(captures["rows"],settings["cases"],plan["sources"],strict=True):
        i = sample["index"]
        assert pred["index"]==i==source["index"]
        if i not in plan["test_indices"]:
            continue
        cached = analyze(sample,pred)
        values_by_method = {k:values(cached,k,scale.get(k,1))for k in ("baseline",*METHODS)}
        rows.append({"index":i,"results":values_by_method})
    write_json(ROOT/"gap-budget.json",{"driver":reference(__file__),"original":original,
        "calibration_nominal":limits,"limits":budgets,"scales":scale,"test_rows":rows,"test":reduce(rows),
        "scope":"Post-hoc sensitivity using the original 12 calibration fields only to scale each complete delivered correction. Every path must remain under both calibration budgets achieved by the published previous-search arm. Gap RMS is total added luma including still-present strong detail. Held-out capture and output arrays are unmodified."})


if __name__=="__main__":
    main()
