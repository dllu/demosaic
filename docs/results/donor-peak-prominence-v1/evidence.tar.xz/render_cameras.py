"""Review the blind frequency nominations on both unmodified standing GFX families."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from probe import PRIOR
from run_restore import ARGS,MODES,correction

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(PRIOR))
from render import native_png

LABEL = {"previous":"Previous RAW search","tiled":"Oversampled tiles","prominence":"Radial prominence"}


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    stamp = reference(ROOT/"standing-proposals.json")
    evidence = read_json(checked(stamp))
    known = {r["id"]:r for r in evidence["rows"]}
    scores = reference(ROOT/"scores.json")
    calibration = read_json(checked(scores))["scale"]
    raw = read_json(checked(evidence["upstream"]))
    rows = {c["id"]:c for c in raw["rows"]}
    before = read_json(checked(raw["display_parent_boards"]))
    output = ROOT/"standing"
    output.mkdir(exist_ok=True)
    viewed = []
    with ieee_fp32():
        for region in before["boards"]:
            if region["id"] not in known:
                continue
            found = known[region["id"]]
            row = rows[region["observation"]]
            inp = row["raw"]["arrays"]
            assert region["input_arrays"]==found["input"]==inp
            with np.load(checked(inp),allow_pickle=False)as f:
                data = {k:f[k]for k in ARGS}
            assert {k:fingerprint(v)for k,v in data.items()}==row["inputs"]
            x,y,w,h = region["case"]["ROI_xywh"]
            left,top,_,_ = found["box"]
            native_box = (x-left,y-top,w,h)
            pad = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            stored = np.load(checked(row["parent"]),allow_pickle=False)
            parent = torch.from_numpy(stored[...,top:top+256,left:left+256].copy())
            args = [torch.from_numpy(data[k][pad].copy() if k in ("packed","variance") else data[k])
                    for k in ARGS]
            wb,matrix = args[-2:]
            with Image.open(checked(region["image"]))as f:
                original = np.array(f.convert("RGB"))
            existing = {p["label"]:original[b:b+d,a:a+c] for p in region["panels"] for a,b,c,d in (p["png_xywh"],)}
            panels = [(name,existing[name])for name in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")
                      if name in existing]
            anchor = display_crop(parent,wb,matrix,native_box,exposure=region["display_exposure"])
            np.testing.assert_array_equal(np.rint(anchor*255).astype(np.uint8),existing["Parent 100k EMA"])
            changes = {}
            linear = {}
            for method in MODES:
                peaks = [p["frequency_xy"]for p in found["methods"][method]["proposals"]]
                restore = parent + calibration[method]*correction(args,parent,peaks)
                view = display_crop(restore,wb,matrix,native_box,exposure=region["display_exposure"])
                pixels = np.rint(view*255).astype(np.uint8)
                ax,ay,aw,ah = native_box
                physical = (restore-parent)[...,ay:ay+ah,ax:ax+aw].numpy()
                changes[method] = {"camera_RGB_RMS_DN16":float(65535*np.sqrt(np.mean(physical.astype(float)**2))),
                                   "changed_display_RGB":int(np.count_nonzero(pixels!=existing["Parent 100k EMA"]))}
                linear[method] = restore.numpy()
                panels.append((LABEL[method],pixels))
            panels += [(name,existing[name])for name in ("ISO100 AHD reference","ISO100 camera JPEG")if name in existing]
            dst = output/(region["id"]+".npz")
            with dst.open("wb")as f:
                np.savez(f,parent=parent.numpy(),**linear)
            render = native_png(output/(region["id"]+".png"),panels)
            print(region["id"],{k:round(v["camera_RGB_RMS_DN16"],3)for k,v in changes.items()},flush=True)
            viewed.append(render|{
                "id":region["id"],"case":region["case"],"fit_xywh":found["box"],"raw":inp,
                "prior":row["parent"],"display_parent":region["image"],"outputs":reference(dst),
                "noise":region["noise"],"exposure":region["display_exposure"],
                "reference_role":region["reference_role"],"camera_RGB_changes":changes})
    assert len(viewed)==8
    read = read_json(checked(read_json(checked(scores))["restoration"]))
    write_json(output/"manifest.json",{
        "driver":reference(__file__),"scores":scores,"proposals":stamp,"checkpoint":read["checkpoint"],
        "rows":viewed})


if __name__=="__main__":
    run()
