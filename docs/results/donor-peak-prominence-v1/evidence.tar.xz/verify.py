"""Check query exclusion and whether the earlier cab bands reach the new detector."""
import json
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.ndimage import maximum_filter

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from discover import boxes,grids,intersects,propose,tile_scores
from probe import score_distance

ROOT = Path(__file__).resolve().parent


def exclusion(physical):
    capture = read_json(checked(physical["fields"]))
    plan = read_json(checked(capture["plan"]))
    ids = set(r["source"]["id"]for r in plan["sources"])
    repo = ROOT.parent/"scene-full-epoch-v1"
    train = read_json(repo/"plan.json")
    with checked(train["train_manifest"]).open() as f:
        known = {json.loads(line)["id"]for line in f}
    assert len(ids)==32 and len(known)==90692 and not known.intersection(ids)
    rng = np.random.default_rng(96278)
    tests = []
    for j,i in enumerate((1,6,12,18,21,30)):
        row = capture["rows"][i]
        repeat,role = j//4,j%4
        with np.load(checked(row["capture"]),allow_pickle=False)as f:
            arrays = {k:f[k][repeat,role:role+1].copy()for k in ("packed","variance","colors")}
        old = physical["outputs"][i]["draws"][j]["methods"]
        for k in ("packed","variance"):
            arrays[k][...,64:192,64:192] = rng.uniform(.001,.9,size=(1,4,128,128)).astype(np.float32)
        tested = propose(arrays,128,128)
        for method in tested:
            for key in ("proposals","exterior_tiles_xywh"):
                assert json.loads(json.dumps(tested[method][key]))==old[method][key],(i,method,key)
        tests.append({"index":i,"draw":j,"query_bayer_samples_replaced":65536,
                      "query_variance_values_replaced":65536,"all_nominations_equal":True})
    return {"checks":tests,"train_manifest":train["train_manifest"],"train_overlap":0}


def cab(standing):
    known = reference("docs/results/green-phase-cross-spectrum-v1.json")
    older = read_json(checked(known))["executed_result"]["cases"]
    produced = []
    for region in standing["rows"]:
        if not region["id"].startswith("mesh-"):
            continue
        side = region["id"].split("-")[-1]
        earlier = next(v for v in older if v["name"]==side)
        x,y,_,_ = region["box"]
        assert earlier["context_xywh"]==region["box"]
        measured = [p["native_frequency_xy"]for p in earlier["peaks"] if "absolute_cross" in p["selected_by"]][:2]
        with np.load(checked(region["input"]),allow_pickle=False)as f:
            data = {k:f[k]for k in ("packed","variance","colors")}
        tiles = boxes(x,y)
        powers = [tile_scores(data,t)[1]for t in tiles]
        neighborhood = [maximum_filter(p,size=5,mode="wrap")for p in powers]
        pairs = [(i,j)for i,j in combinations(range(len(tiles)),2)if not intersects(tiles[i],tiles[j])]
        fy,fx,eligible,*_ = grids()
        pooled = np.maximum.reduce([np.maximum(np.minimum(powers[i],neighborhood[j]),
                                    np.minimum(powers[j],neighborhood[i]))for i,j in pairs])
        reports = []
        guesses = region["methods"]["prominence"]["proposals"]
        for f in measured:
            pos = np.hypot(fx-f[0],fy-f[1])
            neg = np.hypot(fx+f[0],fy+f[1])
            close = (np.minimum(pos,neg) <= 3/256) & eligible
            power,sites = float(pooled[close].max()),int((pooled[close]>=1.35).sum())
            reports.append({"prior_RAW_frequency_xy":f,"best_pooled_prominence":power,
                          "exterior_coordinates_above_threshold_within_three_query_bins":sites,
                          "nomination_distance_query_bins":min((score_distance(g["frequency_xy"],f)for g in guesses),default=None)})
        produced.append({"id":region["id"],"nearby_prior_directions":reports})
    return {"earlier_RAW_spectrum":known,"rows":produced}


def main():
    p = reference(ROOT/"physical-proposals.json")
    s = reference(ROOT/"standing-proposals.json")
    audit = {"driver":reference(__file__),"physical":p,"standing":s,
          "query_exclusion":exclusion(read_json(checked(p))),"cab_prominence":cab(read_json(checked(s)))}
    write_json(ROOT/"verification.json",audit)
    print(audit["cab_prominence"],flush=True)


if __name__=="__main__":
    main()
