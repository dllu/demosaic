"""Record blind exterior candidate selection from all archived fields and standing crops."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from discover import MODES,propose
from prepare_fields import ROLES

ROOT = Path(__file__).resolve().parent
FIELDS = ("packed","variance","colors")
PRIOR = ROOT.parent/"paired-luminance-detail-v1"
REGION = 256


def score_distance(estimate,true):
    estimate,true = np.asarray(estimate),np.asarray(true)
    return float(REGION*min(np.linalg.norm(estimate-true),np.linalg.norm(estimate+true)))


def exact_scoring(guess,layout):
    seen = [r["frequency_xy"]for r in guess["proposals"]]
    distances = {k:min((score_distance(f,layout[k+"_frequency_xy"])for f in seen),default=None)
                 for k in ("strong","weak")}
    return {"distance_in_query_bins":distances,"pair":len(seen)==2}


def case_do(job):
    record,source = job
    with np.load(checked(record["capture"]),allow_pickle=False) as f:
        array = {k:f[k]for k in FIELDS}
    assert {k:fingerprint(v)for k,v in array.items()} == {k:record["fingerprints"][k]for k in array}
    draws = []
    for repeat in range(2):
        for j,role in enumerate(ROLES):
            case = {k:v[repeat,j:j+1]for k,v in array.items()}
            estimates = propose(case,128,128)
            draws.append({"repeat":repeat,"role":role,
                          "methods":{k:a|exact_scoring(a,source["layout"])for k,a in estimates.items()}})
    return {"index":source["index"],"input":record["capture"],"draws":draws}


def physical():
    frozen = reference(ROOT/"fields.json")
    field = read_json(checked(frozen))
    plan = read_json(checked(field["plan"]))
    outputs = []
    with ThreadPoolExecutor(3)as pool:
        for current,start in enumerate(pool.map(case_do,zip(field["rows"],plan["sources"],strict=True)),1):
            outputs.append(start)
            print(f"{current}/{len(field['rows'])}",flush=True)
    write_json(ROOT/"physical-proposals.json",{
        "driver":reference(__file__),"detector":reference(ROOT/"discover.py"),
        "fields":frozen,"outputs":outputs})


def standing():
    launch = read_json(PRIOR/"endpoint/complete.json")
    saved = read_json(checked(launch["standing_results"]))
    boards = read_json(checked(saved["display_parent_boards"]))
    mapping = {r["id"]:r for r in saved["rows"]}
    rows = []
    for region in boards["boards"]:
        obs = region["observation"]
        if obs not in mapping:
            continue
        used = mapping[obs]["raw"]["arrays"]
        assert region["input_arrays"]==used
        with np.load(checked(used),allow_pickle=False) as f:
            native = {k:f[k]for k in FIELDS}
        for key in FIELDS:
            assert fingerprint(native[key])==mapping[obs]["inputs"][key]
        x,y,_,_ = region["case"]["ROI_xywh"]
        box_x,box_y = (x-48)//2*2,(y-48)//2*2
        guesses = propose(native,box_x,box_y)
        rows.append({"id":region["id"],"box":[box_x,box_y,256,256],"input":used,"methods":guesses})
        print(region["id"],{k:[r["frequency_xy"]for r in v["proposals"]]for k,v in guesses.items()},flush=True)
    assert len(rows)==8
    write_json(ROOT/"standing-proposals.json",{
        "driver":reference(__file__),"detector":reference(ROOT/"discover.py"),
        "upstream":launch["standing_results"],"rows":rows})


if __name__=="__main__":
    {"physical":physical,"standing":standing}[sys.argv[1]]()
