"""Hold the localized phase fit fixed and change only the nominated frequencies."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from discover import MODES
from prepare_fields import ARGS,OLD,ROLES

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(OLD))
from resolve import assess,regressions,setup_models

METHODS = (*MODES,"exact")


def correction(args,parent,peaks):
    if len(peaks)<2:
        return torch.zeros_like(parent)
    packed,variance,colors,wb,matrix = args
    answer = torch.zeros_like(parent)
    for first,second in (peaks,peaks[::-1]):
        fits = regressions(packed,variance,colors,parent,first,second)
        answer += assess(fits,first,variance,wb,matrix)["exterior"]
    return answer


def group_restore(args,parent,frequencies):
    output = torch.zeros_like(parent)
    groups = {}
    for n,peaks in enumerate(frequencies):
        key = tuple(tuple(p) for p in peaks)
        if len(key)==2:
            groups.setdefault(key,[]).append(n)
    for peaks,locations in groups.items():
        output[locations] = correction([a[locations]for a in args],parent[locations],peaks)
    return output


def observations(record):
    with np.load(checked(record["capture"]),allow_pickle=False)as f:
        data = {k:f[k]for k in (*ARGS,"target","region","weak_linear_nominal")}
    assert {k:fingerprint(v)for k,v in data.items()}==record["fingerprints"]
    packed = np.s_[...,64:192,64:192]
    query = np.s_[...,128:384,128:384]
    array = data|{k:data[k][packed].copy()for k in ("packed","variance")}
    array["target"] = data["target"][query].copy()
    return array


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    dev = torch.device("cuda")
    source = reference(ROOT/"physical-proposals.json")
    proposals = read_json(checked(source))
    checked(proposals["detector"])
    fields = read_json(checked(proposals["fields"]))
    plan = read_json(checked(fields["plan"]))
    resolver = reference(OLD/"resolve.py")
    previous = read_json(OLD/"predictions.json")
    assert previous["driver"]==resolver and previous["base"]==plan["base"]
    archive = ROOT/"reconstructions"
    archive.mkdir(exist_ok=True)
    before = time.monotonic()
    recorded = []
    with ieee_fp32():
        model = setup_models({"models":{"Corpus 100k":plan["base"]}})["Corpus 100k"]
        model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for row,case,config in zip(proposals["outputs"],fields["rows"],plan["sources"],strict=True):
            no = row["index"]
            assert no==case["index"]==config["index"] and row["input"]==case["capture"]
            outfile = archive/f"{no:03d}.npz"
            if not outfile.exists():
                array = observations(case)
                args = [torch.from_numpy(array[k].reshape(-1,*array[k].shape[2:])).to(dev)for k in ARGS]
                args[:2] = [v.contiguous(memory_format=torch.channels_last)for v in args[:2]]
                baseline = model(*args)
                data = {"baseline":baseline.cpu().numpy().reshape(2,4,3,256,256)}
                exact = [config["layout"][k+"_frequency_xy"]for k in ("strong","weak")]
                for mode in METHODS:
                    bank = []
                    for j,d in enumerate(row["draws"]):
                        assert (d["repeat"],d["role"])==(j//4,ROLES[j%4])
                        bank.append(exact if mode=="exact" else
                                    [p["frequency_xy"]for p in d["methods"][mode]["proposals"]])
                    lift = group_restore(args,baseline,bank)
                    data[mode] = lift.cpu().numpy().reshape(2,4,3,256,256)
                temp = outfile.with_suffix(".tmp")
                with temp.open("wb")as f:
                    np.savez(f,**data)
                temp.rename(outfile)
            recorded.append({"index":no,"output":reference(outfile)})
            print(f"{len(recorded)}/{len(fields['rows'])}: {time.monotonic()-before:.1f}s",flush=True)
    write_json(ROOT/"restorations.json",{"source":source,"driver":reference(__file__),"resolver":resolver,
                                        "checkpoint":plan["base"],"cases":recorded,"seconds":time.monotonic()-before})


if __name__=="__main__":
    run()
