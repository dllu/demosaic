"""Fit native proposal gains with intact-wire, true-gap, and optical flat losses."""

from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("detail-directional-proposal-v1")))

import proposal
from proposal import base
from proposal_ceiling import ROI, windows, remove
from review_selector import wire_scorer

ARMS = ("conditioning", "directional")
D = 3 * 36
Q = 2 * D
FEATURES = 26
SCALE = 65535
WIRE_RESPONSE_WEIGHT = 0.9


def ingredients(meta, pred, profile):
    restore, conditioning, neutral = base.old.ingredients(pred, meta)
    local, cap = base.old.local_features(
        meta["packed"], restore, conditioning, meta["colors"], profile
    )
    detail, t = proposal.fields(meta, pred, profile)
    np.testing.assert_array_equal(neutral, t)
    fields = np.concatenate((conditioning, detail["directional"][:, None]), axis=1)
    signed = base.signed_raw(meta, pred, fields, neutral, profile).astype(np.float32)
    energy = np.log1p(base.old.rms_field(fields) * SCALE).transpose(0, 2, 3, 1)
    feat = np.concatenate((local, signed, energy), axis=-1)
    assert feat.shape[-1] == FEATURES
    support = np.stack((cap, np.ones_like(cap), np.ones_like(cap)), axis=-1)
    return feat.astype(np.float32), support.astype(np.float32), fields, neutral


def terms(D, r):
    return D @ D.T, D @ r, r @ r


def gap_terms(field, error, metric):
    if not metric.gap.any():
        return np.zeros((D, D)), np.zeros(D), 0.0, np.zeros((Q, Q)), np.zeros(Q), 0.0
    b = metric.weak_basis
    factor = SCALE / np.sqrt(np.count_nonzero(metric.gap))
    source = field[0][:, metric.gap] @ b * factor
    initial = error[0, metric.gap] @ b * factor
    outsider = np.concatenate((field[1], -field[2]), axis=0)[:, metric.gap] @ b * factor
    false = (error[1] - error[2])[metric.gap] @ b * factor
    return (*terms(source, initial), *terms(outsider, false))


def statistics(meta, pred, profile, geometry, metric_factory=None):
    f, cap, modes, _ = ingredients(meta, pred, profile)
    truth = base.old.luma(meta["target"], meta)[ROI]
    initial = base.old.luma(pred["nominal"], meta)[ROI]
    error = initial - truth
    # Coefficient ordering and gain flattening match the interpolated delivered pixels.
    cols = (modes[ROI][:, :, None] * windows()).reshape(4, D, 128, 128)
    projected = base.fine(cols) * (SCALE / 128)
    resid = base.fine(error) * (SCALE / 128)
    absolute = [terms(d, r) for d, r in zip(projected, resid, strict=True)]
    if geometry is None:
        pair = np.concatenate((projected[0], -projected[2]), axis=0)
        truth_pair = base.fine(truth[0] - truth[2]) * (SCALE / 128)
        residual = resid[0] - resid[2]
        gap = np.zeros((D, D)), np.zeros(D), 0.0, np.zeros((Q, Q)), np.zeros(Q), 0.0
    else:
        if geometry["family"] in ("smooth-dip", "contrast-step"):
            meta = meta | {"support": np.ones_like(meta["support"])}
        wire = metric_factory(meta, geometry)
        footprint = wire.intact
        luma = np.concatenate((cols[0], -cols[2]), axis=0)[:, footprint]
        dn = SCALE / np.sqrt(np.count_nonzero(footprint))
        pair = remove(luma, wire.intact_nuisance) * dn
        residual = remove((error[0] - error[2])[footprint], wire.intact_nuisance) * dn
        truth_pair = wire.truth_weak * dn
        gap = gap_terms(cols, error, wire)
    gram, linear, energy = terms(pair, residual)
    gapG, gapB, gapE, extG, extB, extE = gap
    return {
        "features": f,
        "support": cap,
        "roleG": np.asarray([x[0] for x in absolute], dtype=np.float32),
        "roleB": np.asarray([x[1] for x in absolute], dtype=np.float32),
        "roleE": np.asarray([x[2] for x in absolute], dtype=np.float32),
        "pairG": np.asarray(gram, dtype=np.float32),
        "pairB": np.asarray(linear, dtype=np.float32),
        "pairE": np.float32(energy),
        "signal": np.asarray(pair @ truth_pair, dtype=np.float32),
        "gapG": np.asarray(gapG, dtype=np.float32),
        "gapB": np.asarray(gapB, dtype=np.float32),
        "gapE": np.float32(gapE),
        "extG": np.asarray(extG, dtype=np.float32),
        "extB": np.asarray(extB, dtype=np.float32),
        "extE": np.float32(extE),
    }


class Gate(nn.Module):
    def __init__(self, directional):
        super().__init__()
        self.directional = directional
        self.layers = nn.Sequential(
            nn.Conv2d(FEATURES, 32, 1),
            nn.SiLU(),
            nn.Conv2d(32, 24, 3, padding=1, padding_mode="replicate"),
            nn.SiLU(),
            nn.Conv2d(24, 3, 1),
        )
        nn.init.zeros_(self.layers[-1].weight)
        with torch.no_grad():
            self.layers[-1].bias.copy_(torch.tensor([-3.5, -2.3, -3.5]))

    def forward(self, f, cap):
        shape = f.shape
        x = f.reshape(-1, *shape[-3:]).permute(0, 3, 1, 2)
        k = self.layers(x).permute(0, 2, 3, 1).reshape(*shape[:-1], 3).sigmoid()
        if not self.directional:
            k = k * k.new_tensor([1.0, 1.0, 0.0])
        return k * cap


def normalized(features, normal):
    return ((features - normal["mean"]) / normal["sd"]).clamp(-6, 6)


def prior_delta(weight, G, b):
    return 2 * (weight * b).sum(-1) + (weight.unsqueeze(-2) @ G @ weight.unsqueeze(-1)).squeeze(
        -1
    ).squeeze(-1)


def objective(g, data, weak):
    q = g[..., 1:7, 1:7, :].transpose(-1, -3).transpose(-1, -2).reshape(len(g), 4, D)
    pairs = torch.cat((q[:, 0], q[:, 2]), dim=-1)
    alt = torch.cat((q[:, 1], q[:, 2]), dim=-1)
    a = prior_delta(q, data["roleG"], data["roleB"]) / (data["roleE"] + 36**2)
    d = prior_delta(pairs, data["pairG"], data["pairB"])
    speech = 2 * (pairs * data["signal"]).sum(-1)
    power = data["pairE"] + 48**2
    pair = (d - weak * speech) / power
    flat = a[:, 3]
    gap = prior_delta(q[:, 0], data["gapG"], data["gapB"]) / (data["gapE"] + 24**2)
    ext = prior_delta(alt, data["extG"], data["extB"]) / (data["extE"] + 24**2)
    loss = 0.6 * a[:, 0] + 0.20 * a[:, 1] + 0.30 * a[:, 2] + 1.4 * flat + 1.7 * flat.relu()
    return (loss + pair + 0.7 * (gap + ext) + 3.0 * (gap.relu() + ext.relu())).mean()


@torch.no_grad()
def correction(d, p, profile, networks, normal):
    f, cap, field, neutral = ingredients(d, p, profile)
    x = normalized(torch.from_numpy(f), normal)
    c = torch.from_numpy(cap)
    from evaluate_selector import deltas

    return {name: deltas(field, net(x, c)).sum(1) for name, net in networks.items()}, neutral
