"""Freeze a larger set of paired wire and natural scenes and collect delivery coefficients."""

from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import sys
from time import monotonic

import numpy as np
from scipy.ndimage import maximum_filter, minimum_filter
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import sample_scene_recipe, observe_scene, scene_crop_boxes
from demosaic.scene_training_data import scene_seed
from demosaic.prediction_archive import fingerprint

from wire_gate import HERE, OUT, statistics, wire_scorer
from collect_router import (
    OUT as ROUTER,
    ISO,
    VAL,
    batch,
    forward,
    identities,
    load_model,
    renderer,
    save,
)

sys.path.insert(0, str(HERE.with_name("green-covariance-refit-v1")))
import wire_math

SEED = 202611201024
SIZES = {"preflight": (4, 4), "training": (384, 96), "calibration": (24, 20), "held": (40, 32)}
FAMILIES = ("strip", "ellipse", "smooth-dip", "contrast-step")
CHUNK = 16
PROFILES = ((0.00032, 4.096e-7), (0.00128, 6.5536e-6), (0.00256, 2.62144e-5))


def freeze():
    router = reference(ROUTER / "plan.json")
    spec = read_json(checked(router))
    old = read_json(checked(spec["references"]["previous"]))
    training = read_json(checked(old["previous_dataset"]))
    scene = read_json(checked(training["previous"]))
    evaluation = read_json(checked(scene["observations_for_evaluation"]))
    confirm = reference(ROUTER / "confirmation/plan.json")
    off_grid = reference(
        "/mnt/external/demosaic/detail-directional-proposal-v1/off-grid/completed.json"
    )
    held_old = read_json(checked(old["previous_held"]))["samples"]
    refs = [
        *training["samples"],
        *scene["samples"],
        *held_old,
        *[r for g in old["cases"].values() for r in g],
        *[r for g in spec["groups"].values() for r in g],
        *read_json(checked(confirm))["groups"]["confirm"],
        *read_json(checked(spec["full427"]))["source_metadata"],
        *[r["fixture"]["source"] for r in read_json(checked(off_grid))["rows"]],
        *[
            r["source"] if isinstance(r["source"], dict) else r["fixture"]["source"]
            for g in ("calibration", "transfer", "wires")
            for r in evaluation["groups"][g]
        ],
    ]
    blocked = identities(refs)
    with checked(spec["training_manifest"]).open() as f:
        full_train = list(map(json.loads, f))
    with checked(old["validation_manifest"]).open() as f:
        full_valid = list(map(json.loads, f))
    base_set = {"train": full_train, "val": full_valid}
    alltrain = identities(full_train)
    selected = {}
    for stage, (nwire, nphoto) in SIZES.items():
        split = "train" if stage in ("preflight", "training") else "val"
        possible = [
            v
            for v in base_set[split]
            if v["split"] == split
            and v["bin_factor"] == 4
            and min(v["shape"][:2]) >= 512
            and max(v["shape"][:2]) <= 1850
        ]
        possible.sort(key=lambda r: sha256(f"{SEED}/{stage}/{r['id']}".encode()).digest())
        rows = []
        for v in possible:
            key = {v["id"], v["cache_sha256"]}
            if key & blocked or (split == "val" and key & alltrain):
                continue
            i = len(rows)
            kind = "wire" if i < nwire else ("faint" if (i - nwire) % 2 == 0 else "stronger")
            rows.append({"source": v, "kind": kind, "index": i})
            blocked |= key
            if len(rows) == nwire + nphoto:
                break
        assert len(rows) == nwire + nphoto
        selected[stage] = rows
    return {
        "driver": reference(__file__),
        "operator": reference(HERE / "wire_gate.py"),
        "parent": spec["parent"],
        "v120": spec["v120"],
        "training_manifest": spec["training_manifest"],
        "validation_manifest": old["validation_manifest"],
        "fixed427": spec["full427"],
        "prior_router": router,
        "prior_confirmation": confirm,
        "prior_off_grid": off_grid,
        "wire_renderer": reference(wire_math.__file__),
        "natural_renderer": reference(renderer.__file__),
        "seed": SEED,
        "groups": selected,
        "family": FAMILIES,
        "sizes": SIZES,
        "precision": "IEEE FP32 EMA and identical per-query DINO reuse at three physical conditioning scales",
    }


def geometry(rng, index, train):
    angle = rng.uniform([0.47, 0.46], [1.09, 1.05])
    periods = (
        rng.uniform(7.0, 11.8),
        rng.uniform(13.0, 29.0) if train and index % 7 == 0 else rng.uniform(7.2, 12.4),
    )
    frequency = (
        np.asarray([np.cos(angle), np.sin(angle) * [1, -1]]).T / np.asarray(periods)[:, None]
    )
    return {
        "family": FAMILIES[index % 4],
        "frequency": frequency.tolist(),
        "phase": rng.uniform(-np.pi, np.pi, 2).tolist(),
        "strength": rng.uniform([0.011, 0.0037], [0.016, 0.0086]).tolist(),
        "width": rng.uniform(0.10, 0.16, 2).tolist(),
        "edge": float(rng.uniform(-27, 27)),
        "tint": rng.uniform(0.05, 0.11, 3).tolist(),
        "gap_center": rng.uniform(-14, 14, 2).tolist(),
        "gap_width": float(rng.uniform(23, 36)),
        "gap_length": float(rng.uniform(35, 54)),
        "gap_orientation": float(rng.uniform(0, np.pi)),
        "angle": float(rng.uniform(-1.6, 1.6)),
    }


def optical(v, sigma):
    radius = int(np.ceil(2.8 * sigma))
    coords = torch.arange(-radius, radius + 1, dtype=v.dtype)
    kernel = torch.exp(-coords.square() / (2 * sigma * sigma))
    kernel = kernel / kernel.sum()
    x = torch.nn.functional.pad(v[None], (radius, radius, radius, radius), mode="reflect")
    horiz = kernel.reshape(1, 1, 1, -1).expand(3, -1, -1, -1)
    vert = kernel.reshape(1, 1, -1, 1).expand(3, -1, -1, -1)
    return torch.nn.functional.conv2d(
        torch.nn.functional.conv2d(x, horiz, groups=3), vert, groups=3
    )[0]


def render(case, split):
    idx = case["index"]
    src = case["source"]
    path = Path(src["cache"])
    src = src | {"cache": str(path if path.is_absolute() else VAL.parent / path)}
    train = split in ("preflight", "training")
    rng = np.random.default_rng(scene_seed(SEED, idx, split + "/recipe"))
    wire = case["kind"] == "wire"
    extent = 512 if wire else 256
    (box,) = scene_crop_boxes(
        src["shape"][:2], patch_size=extent, count=1, seed=scene_seed(SEED, idx, split + "/box")
    )
    box = tuple(map(int, box))
    image = wire_math.decode(src, box)
    desc = None
    offset = 0
    support = np.ones((256, 256), dtype=np.float32)
    if wire:
        desc = geometry(rng, idx, train)
        targets, _, raw_support, _ = wire_math.exact(image, desc)
        sigma = (0.55 if (idx // 16) % 2 == 0 else 0.85) if train else 0.85
        radius = int(np.ceil(2.8 * sigma))
        targets = tuple(optical(v, sigma) for v in targets)
        mask = raw_support.numpy()
        intact = minimum_filter(mask, 2 * radius + 1) >= 0.97
        gap = maximum_filter(mask, 2 * radius + 1) == 0
        support = np.where(intact, 1.0, np.where(gap, 0.0, 0.5)).astype(np.float32)[
            128:384, 128:384
        ]
        offset = 128
    else:
        sigma = None
        a, b = (0.22, 0) if case["kind"] == "faint" else (0.78, 0.06)
        frame = (0, 0, 256, 256)
        present, absent = renderer.patch(image, frame, a), renderer.patch(image, frame, b)
        targets = (present, absent, absent, renderer.flat_patch(absent))
    sensor = sample_scene_recipe(scene_seed(SEED, idx, split + "/camera"))
    if train:
        shot, read = PROFILES[int(rng.choice(3, p=(0.17, 0.67, 0.16)))]
        exposure = float(2 ** rng.uniform(-2.2, -0.55))
    else:
        shot, read, exposure = (ISO[k] for k in ("shot", "read", "exposure"))
    sensor = replace(
        sensor,
        pattern=tuple(PATTERNS)[(idx // 4 + idx % 4) % 4],
        black=0.03,
        shot=shot,
        read=read,
        exposure=exposure,
    )
    after = []
    seeds = []
    for j, v in enumerate(targets):
        seed = scene_seed(SEED, idx, f"{split}/role/{j}")
        seeds.append(seed)
        after.append(
            observe_scene(v, replace(sensor, noise_seed=seed)).crops([(offset, offset, 256, 256)])
        )
    d = {k: torch.cat([v[k] for v in after]).numpy() for k in ("packed", "variance", "target")}
    d |= {k: after[0][k][0].numpy() for k in ("colors", "wb", "matrix")}
    d["support"] = support
    if wire and desc["family"] in ("strip", "ellipse"):
        gap = support == 0
        np.testing.assert_array_equal(d["target"][0, :, gap], d["target"][2, :, gap])
    stamp = {
        "id": f"{split}-{idx:03}",
        "kind": case["kind"],
        "source": src,
        "box": box,
        "fixture": {
            "source": src,
            "box": box,
            "camera": asdict(sensor),
            "geometry": desc,
            "sigma": sigma,
        },
        "profile": {"shot": shot, "read": read, "exposure": exposure},
        "offset": offset,
        "noise_seeds": seeds,
        "packed": fingerprint(torch.from_numpy(d["packed"])),
        "target": fingerprint(torch.from_numpy(d["target"])),
    }
    return d, stamp, desc


@torch.inference_mode()
def collect(which):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    path = OUT / "plan.json"
    if not path.exists():
        write_json(path, freeze())
    bound = reference(path)
    spec = read_json(checked(bound))
    assert spec["driver"] == reference(__file__) and spec["operator"] == reference(
        HERE / "wire_gate.py"
    )
    root = OUT / which
    root.mkdir(exist_ok=True)
    net = load_model(spec["parent"])
    prepare = which in ("training", "preflight")
    v120 = None
    if not prepare:
        v120, w = load_checkpoint(checked(spec["v120"]), "cuda", tiled_inference=True)
        assert w["loaded_sha256"] == spec["v120"]["sha256"] and "ema" in w
        del w
        v120 = v120.eval().to(memory_format=torch.channels_last)
        v120.set_noise(ISO["shot"], ISO["read"])
    ruler, factory = wire_scorer()
    book = []
    started = monotonic()
    roster = spec["groups"][which]
    with ieee_fp32():
        for start in range(0, len(roster), CHUNK):
            stop = min(start + CHUNK, len(roster))
            chunk = root / f"chunk-{start:03}-{stop:03}.json"
            if chunk.exists():
                book.append(reference(chunk))
                continue
            records = []
            pieces = []
            for case in roster[start:stop]:
                d, r, g = render(case, which)
                x = batch(d)
                maps = forward(net, x, r["profile"], reuse=True)
                if v120 is not None:
                    maps["v120"] = v120(
                        x["packed"].contiguous(memory_format=torch.channels_last),
                        x["variance"].contiguous(memory_format=torch.channels_last),
                        x["colors"],
                        x["wb"],
                        x["matrix"],
                    )
                p = {k: v.cpu().numpy() for k, v in maps.items()}
                if prepare:
                    values = statistics(d, p, r["profile"], g, factory)
                    assert all(np.isfinite(y).all() for y in values.values())
                    pieces.append(values)
                if which != "training":
                    r["file"] = save(root / (r["id"] + ".npz"), d | p)
                records.append(r)
            receipt = {"plan": bound, "rows": records}
            if pieces:
                receipt["stats"] = save(
                    chunk.with_suffix(".npz"),
                    {k: np.stack([p[k] for p in pieces]) for k in pieces[0]},
                )
            write_json(chunk, receipt)
            book.append(reference(chunk))
            print(which, stop, round(monotonic() - started, 2), flush=True)
    write_json(
        root / "completed.json",
        {
            "driver": reference(__file__),
            "plan": bound,
            "scorer": ruler,
            "chunks": book,
            "count": len(roster),
            "seconds": monotonic() - started,
        },
    )


if __name__ == "__main__":
    collect(sys.argv[1])
