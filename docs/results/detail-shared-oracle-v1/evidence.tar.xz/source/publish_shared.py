"""Bind the two trained heads, prospective evaluation and native crops."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile
from unittest.mock import patch

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import HERE, OUT
from fit_shared import METHODS
from score_wire_gate import wire_values
import score_wire_gate as scoring

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
GROUPS = ("calibration", "prior-held", "held")
RECEIPTS = (
    "audit", "diagnostic", "oracle/result", "training/completed", "fit-training/result",
    "confirmation/plan", "confirmation/held/completed", "evaluation-plan",
    "analysis", "review-camera", "review-exact", "review-full",
    *(f"score-{group}" for group in GROUPS),
)
UPSTREAM = (
    "wire_gate.py", "collect_wire_gate.py", "score_wire_gate.py", "review_wire_gate.py",
)
CONFIGS = ("configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json")


def bound(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def same_source(a, b):
    assert a["sha256"] == b["sha256"] and checked(a).resolve() == checked(b).resolve()


def frame(view, folder):
    src = checked(view["image"])
    dst = folder / src.name
    shutil.copyfile(src, dst)
    with Image.open(dst) as im:
        for panel in view["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert w == h == 160 and x + w <= im.width and y + h <= im.height
    ref = bound(dst)
    assert ref["sha256"] == view["image"]["sha256"]
    return view | {"image": ref}


def chart(data):
    wires = [row for row in data["rows"] if row["kind"] == "wire"]
    response = "weak_response_pp"
    styles = {
        "continuation": ("Direct continuation", "#0072b2", "-"),
        "directional": ("Shared-target student", "#d55e00", "-"),
        "rolled directional": ("Shared target, rolled features", "#7651a3", "--"),
    }
    columns = (
        ("intact_increment_RMS_DN16", "Intact paired error"),
        ("gap_continuing_strong_RMS_DN16", "Continuing-strand error in true gaps"),
    )
    figure, axes = plt.subplots(1, 2, figsize=(10.6, 4.3), layout="constrained")
    base_response = wire_values(wires, "nominal", response, 0).mean()
    for axis, (metric, title) in zip(axes, columns, strict=True):
        base_error = wire_values(wires, "nominal", metric, 0).mean()
        def point(method, dose):
            return (
                wire_values(wires, method, metric, dose).mean() - base_error,
                wire_values(wires, method, response, dose).mean() - base_response,
            )
        axis.axvline(0, color="#777777", lw=0.8)
        axis.axhline(0, color="#777777", lw=0.8)
        for method, (name, color, style) in styles.items():
            x, y = zip(*(point(method, dose) for dose in np.linspace(0, 1, 41)), strict=True)
            axis.plot(x, y, style, color=color, label=name)
            if method in METHODS:
                lock = data["policy"]["arms"][method]["locked"]["dose"]
                axis.scatter(*point(method, lock), color=color, edgecolor="white", s=62, zorder=4)
        axis.scatter(*point("previous directional", 0), marker="x", color="#454545",
                     label="Previous response head, full strength")
        axis.set_title(title)
        axis.set_xlabel("Change in RMS vs. Local 50k (DN16)")
        axis.set_ylabel("Weak contrast change (percentage points)")
        axis.grid(alpha=0.2)
    axes[0].legend(loc="best", fontsize=8)
    figure.suptitle("New optical fixtures · dots mark strengths fixed on calibration")
    target = ASSETS / "confirmation-response.png"
    figure.savefig(target, dpi=150, facecolor="white")
    plt.close(figure)
    return bound(target)


def run():
    refs = {name: reference(OUT / f"{name}.json") for name in RECEIPTS}
    data = {name: read_json(checked(ref)) for name, ref in refs.items()}
    for item in data.values():
        if "driver" in item:
            checked(item["driver"])
    book = {f"receipts/{name}.json": ref for name, ref in refs.items()}
    plan = data["evaluation-plan"]
    fit = data["fit-training/result"]
    calibration = refs["score-calibration"]
    training = data["training/completed"]
    oracle = data["oracle/result"]
    assert fit["continued"] == refs["training/completed"] == oracle["continuation_coefficients"]
    assert fit["teacher"] == refs["oracle/result"] == data["audit"]["teacher"]
    assert refs["confirmation/plan"] == data["audit"]["new_capture_plan"] == plan["selection"]
    assert fit["updates"] == 1600 and fit["examples"] == 1920 and training["wire_count"] == 384
    assert set(fit["checkpoints"]) == set(METHODS)
    assert fit["collection"] == training["source"]
    book["receipts/previous-training.json"] = fit["collection"]
    book["receipts/previous-fit.json"] = fit["previous_fit"]
    book["receipts/previous-calibration.json"] = plan["prior_calibration_receipt"]
    book["receipts/previous-held.json"] = plan["reused_held_receipt"]
    book["oracle/gain-labels.npz"] = oracle["labels"]
    book["checkpoints/previous-directional.pt"] = fit["init"]
    for name, ref in fit["checkpoints"].items():
        book[f"checkpoints/{name}.pt"] = ref
    for i, ref in enumerate(training["chunks"]):
        checked(read_json(checked(ref))["data"])
        book[f"chunks/continued/{i:02}.json"] = ref
    for group, src in zip(GROUPS, (
        plan["prior_calibration_receipt"], plan["reused_held_receipt"],
        refs["confirmation/held/completed"],
    ), strict=True):
        receipt = data[f"score-{group}"]
        same_source(receipt["source"], src)
        assert receipt["weights"] == refs["fit-training/result"]
        assert receipt["calibration"] == (None if group == "calibration" else calibration)
    for group, ref in data["analysis"]["source"].items():
        assert ref == refs[f"score-{group}"]
    captured = data["confirmation/held/completed"]
    assert captured["plan"] == refs["confirmation/plan"]
    rows = []
    for i, ref in enumerate(captured["chunks"]):
        block = read_json(checked(ref))
        assert block["plan"] == captured["plan"]
        rows.extend(block["rows"])
        book[f"chunks/confirmation/{i:02}.json"] = ref
    assert len(rows) == captured["count"] == 56
    for a, b in zip(rows, data["score-held"]["rows"], strict=True):
        assert a["id"] == b["id"]
        same_source(a["file"], b["proof"]["input"])
    for key in ("review-camera", "review-exact"):
        assert data[key]["fit"] == refs["fit-training/result"]
        assert data[key]["lock"] == calibration
    assert data["review-exact"]["report"]["reference"] == refs["score-held"]
    doses = data["review-camera"]["doses"]
    assert data["review-exact"]["doses"] == doses
    assert doses == {key: value["locked"]["dose"]
                     for key, value in data["score-calibration"]["policy"]["arms"].items()}

    full = data["review-full"]
    assert full["fit"] == refs["fit-training/result"] and full["lock"] == calibration
    assert full["held"] == full["views"]["exact"]["reference"] == refs["score-held"]
    assert full["dose"] == dict.fromkeys(METHODS, 1.0)

    for dir_ in (ASSETS, ASSETS / "full", RESULTS):
        dir_.mkdir(exist_ok=True, parents=True)
    exact = data["review-exact"]["report"]["rows"]
    camera = data["review-camera"]["report"]["rows"]
    full_exact = full["views"]["exact"]["rows"]
    full_camera = full["views"]["camera"]["rows"]
    for photo_rows, camera_rows, folder in (
        (exact, camera, ASSETS), (full_exact, full_camera, ASSETS / "full"),
    ):
        assert len(photo_rows) == 3 and sum(len(row["views"]) for row in camera_rows) == 12
        for row in photo_rows:
            row["views"] = {k: frame(view, folder) for k, view in row["views"].items()}
        for row in camera_rows:
            row["views"] = [frame(view, folder) for view in row["views"]]
            for view in row["views"]:
                labels = {panel["label"] for panel in view["panels"]}
                assert "ISO100 AHD reference" in labels
                if row["id"].startswith("mesh-"):
                    assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= labels
    with patch.object(scoring, "METHODS", METHODS):
        figure = chart(data["score-held"])
    selection = data["confirmation/plan"]
    manifest = ASSETS / "manifest.json"
    write_json(manifest, {
        "parent": selection["parent"], "v120": selection["v120"], "weights": fit["checkpoints"],
        "doses": doses, "synthetic": exact, "camera": camera, "figure": figure,
        "full_strength": {"doses": full["dose"], "synthetic": full_exact, "camera": full_camera},
    })
    summary = RESULTS / "summary.json"
    write_json(summary, {
        "training": {k: v for k, v in fit.items() if k != "logs"},
        "collection_seconds": training["seconds"],
        "oracle_seconds": oracle["seconds"],
        "headroom": data["diagnostic"]["summary"],
        "source_audit": data["audit"]["summary"],
        "scores": {group: data[f"score-{group}"]["summary"] for group in GROUPS},
        "locked_doses": doses,
        "analysis": data["analysis"]["results"],
        "camera": {row["id"]: row["RGB_RMS_DN16"] for row in camera},
        "camera_full_strength": {row["id"]: row["RGB_RMS_DN16"] for row in full_camera},
    })
    for f in sorted(HERE.glob("*.py")):
        book[f"source/{f.name}"] = reference(f)
    for f in UPSTREAM:
        book[f"source/previous/{f}"] = reference(HERE.with_name("detail-wire-gate-v1") / f)
    for f in CONFIGS:
        book[f] = reference(ROOT / f)
    target = RESULTS / "evidence.tar.xz"
    with tarfile.open(target, "x:xz", preset=4) as archive:
        for key, ref in book.items():
            archive.add(checked(ref), arcname=key, recursive=False)
    with tarfile.open(target) as archive:
        assert set(archive.getnames()) == book.keys()
        for key, ref in book.items():
            with archive.extractfile(key) as f:
                assert file_digest(f, "sha256").hexdigest() == ref["sha256"], key
    write_json(RESULTS / "publication.json", {
        "archive": bound(target), "summary": bound(summary), "manifest": bound(manifest),
        "members": book, "checkpoints": fit["checkpoints"],
        "previous_evidence": bound(ROOT / "docs/results/detail-wire-gate-v1/evidence.tar.xz"),
    })
    print(bound(target), flush=True)


if __name__ == "__main__":
    run()
