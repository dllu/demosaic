"""Train matched continuation-protected heads with and without shared oracle targets."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT, PRIOR
from oracle_labels import extras
from fit_wire_gate import load_stats
from wire_gate import Gate, D, normalized, objective, prior_delta

METHODS = ("continuation", "directional")
UPDATES = 1600
BATCH = (24, 12)
LR = 0.0004
EMA = 0.993
SEED = 202611201054
STRONG = 1.4
STRONG_HINGE = 3.0
TARGET_WEIGHT = 4.0
GAIN_WEIGHT = 0.08


def flat(g):
    return g[..., 1:7, 1:7, :].permute(0, 1, 4, 2, 3).reshape(len(g), 4, D)


def strong_loss(g, s):
    h = flat(g)[:, :3]
    x = prior_delta(h, s["strongG"], s["strongB"]) / (s["strongE"] + 36**2)
    return (STRONG * x + STRONG_HINGE * x.relu()).mean()


def teacher_loss(g, s):
    h = flat(g)
    u = flat(s["support"])
    e = h - u * s["teacher"][:, None]
    a = e[:, :3]
    gram = s["roleG"][:, :3]
    actual = prior_delta(a, gram, torch.zeros_like(a)) / (s["roleE"][:, :3] + 36**2)
    pair = torch.cat((e[:, 0], e[:, 2]), dim=1)
    pair_risk = prior_delta(pair, s["pairG"], torch.zeros_like(pair)) / (s["pairE"] + 48**2)
    return TARGET_WEIGHT * (actual.mean() + pair_risk.mean()) + GAIN_WEIGHT * (a * a).mean()


def sample(data, index):
    return {k: v[index] for k, v in data.items()}


def fit():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    device = "cuda"
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.cuda.set_per_process_memory_fraction(
        min(1.0, 3 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    training = reference(PRIOR / "training/completed.json")
    more = reference(OUT / "training/completed.json")
    labels = reference(OUT / "oracle/result.json")
    parts = read_json(checked(labels))
    assert parts["source"] == training and parts["continuation_coefficients"] == more
    with np.load(checked(parts["labels"]), allow_pickle=False) as a:
        teach = dict(zip(a["ids"], a["gain"], strict=True))
    supplement = extras(more)
    old = reference(PRIOR / "response-priority/fit-training/result.json")
    start = read_json(checked(old))["checkpoints"]["directional"]
    parent = torch.load(checked(start), weights_only=True, map_location="cpu")
    normal = {k: v.to(device) for k, v in parent["normal"].items()}
    roster, data = load_stats(training, device)
    data["features"] = normalized(data["features"], normal)
    wire = [i for i, r in enumerate(roster) if r["kind"] == "wire"]
    plain = [i for i, r in enumerate(roster) if r["kind"] != "wire"]
    ids = [roster[i]["id"] for i in wire]
    assert len(ids) == len(teach) == len(supplement) == 384
    dense = sample(data, torch.tensor(wire, device=device))
    clean = sample(data, torch.tensor(plain, device=device))
    del data
    for k in ("strongG", "strongB", "strongE"):
        dense[k] = torch.from_numpy(np.stack([supplement[i][k] for i in ids])).to(device)
    dense["teacher"] = torch.from_numpy(np.stack([teach[i] for i in ids])).to(device)
    arms = {k: Gate(True).to(device) for k in METHODS}
    ema = {k: Gate(True).to(device).requires_grad_(False) for k in METHODS}
    for n in (*arms.values(), *ema.values()):
        n.load_state_dict(parent["ema"])
    opt = {k: torch.optim.AdamW(n.parameters(), lr=LR, weight_decay=1e-4) for k, n in arms.items()}
    rng = torch.Generator().manual_seed(SEED)
    trace = {}
    clock = monotonic()
    for j in range(1, UPDATES + 1):
        w, p = (
            sample(mat, torch.randint(len(mat["features"]), (count,), generator=rng).to(device))
            for mat, count in zip((dense, clean), BATCH, strict=True)
        )
        info = {}
        for name, m in arms.items():
            opt[name].zero_grad(set_to_none=True)
            wg = m(w["features"], w["support"])
            pg = m(p["features"], p["support"])
            normal_ = objective(wg, w, 5.4) + 0.7 * objective(pg, p, 0.35)
            strong = strong_loss(wg, w)
            matching = teacher_loss(wg, w)
            loss = normal_ + strong
            if name == "directional":
                loss = loss + matching
            assert torch.isfinite(loss)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 1.0)
            opt[name].step()
            with torch.no_grad():
                torch._foreach_lerp_(list(ema[name].parameters()), list(m.parameters()), 1 - EMA)
            if j in (1, UPDATES) or j % 100 == 0:
                info[name] = {
                    "direct": normal_.item(),
                    "strong": strong.item(),
                    "teacher": matching.item(),
                }
        if info:
            trace[j] = info
            print(j, round(monotonic() - clock, 2), info, flush=True)
    root = OUT / "fit-training"
    root.mkdir(exist_ok=True)
    published = {}
    for k, m in arms.items():
        path = root / f"{k}.pt"
        tmp = path.with_suffix(".partial")
        record = {
            "raw": {k: v.cpu() for k, v in m.state_dict().items()},
            "ema": {k: v.cpu() for k, v in ema[k].state_dict().items()},
            "normal": parent["normal"],
            "optimizer": opt[k].state_dict(),
            "collection": training,
            "teacher": labels,
            "init": start,
            "update": UPDATES,
            "role": k,
            "rng": rng.get_state(),
        }
        torch.save(record, tmp)
        tmp.replace(path)
        published[k] = reference(path)
        restored = torch.load(checked(published[k]), weights_only=True, map_location="cpu")
        assert restored["update"] == UPDATES
        for key, t in restored["ema"].items():
            assert torch.equal(t, record["ema"][key])
    write_json(
        root / "result.json",
        {
            "driver": reference(Path(__file__)),
            "collection": training,
            "continued": more,
            "teacher": labels,
            "init": start,
            "previous_fit": old,
            "checkpoints": published,
            "logs": trace,
            "updates": UPDATES,
            "lr": LR,
            "ema_decay": EMA,
            "batch": BATCH,
            "source_count": len(roster),
            "examples": len(roster) * 4,
            "role_visits_per_arm": 4 * sum(BATCH) * UPDATES,
            "teacher_weights": [TARGET_WEIGHT, GAIN_WEIGHT],
            "continuing_weights": [STRONG, STRONG_HINGE],
            "seconds": monotonic() - clock,
        },
    )


if __name__ == "__main__":
    fit()
