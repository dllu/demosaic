"""Capture a new source-disjoint wire and natural panel after the previous fit."""

import json
from hashlib import sha256
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT, PRIOR
import collect_wire_gate as c

SEED = 202611201053


def select():
    old = reference(PRIOR / "plan.json")
    p = read_json(checked(old))
    earlier = read_json(checked(p["prior_router"]))
    prior_plan = read_json(checked(earlier["references"]["previous"]))
    old_experiment = read_json(checked(prior_plan["previous_dataset"]))
    old_scene = read_json(checked(old_experiment["previous"]))
    retained = read_json(checked(old_scene["observations_for_evaluation"]))
    sources = [r["source"] for rows in p["groups"].values() for r in rows]
    sources += [r for g in prior_plan["cases"].values() for r in g]
    sources += [r for g in earlier["groups"].values() for r in g]
    sources += read_json(checked(p["prior_confirmation"]))["groups"]["confirm"]
    sources += [r["fixture"]["source"] for r in read_json(checked(p["prior_off_grid"]))["rows"]]
    sources += read_json(checked(p["fixed427"]))["source_metadata"]
    sources += read_json(checked(prior_plan["previous_held"]))["samples"]
    sources += [
        r["source"] if isinstance(r["source"], dict) else r["fixture"]["source"]
        for g in ("calibration", "transfer", "wires")
        for r in retained["groups"][g]
    ]
    blocked = c.identities(sources)
    with checked(p["training_manifest"]).open() as stream:
        blocked |= c.identities(map(json.loads, stream))
    with checked(p["validation_manifest"]).open() as stream:
        photos = [
            r
            for r in map(json.loads, stream)
            if r["split"] == "val"
            and r["bin_factor"] == 4
            and min(r["shape"][:2]) >= 512
            and max(r["shape"][:2]) <= 1850
        ]
    photos.sort(key=lambda v: sha256(f"{SEED}/{v['id']}".encode()).digest())
    selected = []
    for r in photos:
        code = {r["id"], r["cache_sha256"]}
        if code & blocked:
            continue
        i = len(selected)
        selected.append(
            {
                "index": i,
                "source": r,
                "kind": "wire" if i < 32 else ("faint" if i % 2 == 0 else "stronger"),
            }
        )
        blocked |= code
        if len(selected) == 56:
            break
    assert len(selected) == 56
    return p | {
        "previous_plan": old,
        "followup_driver": reference(Path(__file__)),
        "groups": {"held": selected},
        "sizes": {"held": [32, 24]},
        "seed": SEED,
    }


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    plan = folder / "plan.json"
    if not plan.exists():
        write_json(plan, select())
    with patch.object(c, "OUT", folder), patch.object(c, "SEED", SEED):
        c.collect("held")
