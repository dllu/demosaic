"""Compute shared-role gain targets while accounting for the circulating stronger wire."""

from pathlib import Path
from time import monotonic

import numpy as np
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT, PRIOR
from collect_wire_gate import save
from wire_gate import D

TARGET_PP = 2.0
STRONG = 1.4
WEAK = 2.2
ABSOLUTE = 0.08
STEPS = 520


def load_blocks(source, extra):
    for chunk in read_json(checked(source))["chunks"]:
        spec = read_json(checked(chunk))
        with np.load(checked(spec["stats"]), allow_pickle=False) as array:
            source_data = {k: array[k] for k in array.files}
        indices = [i for i, r in enumerate(spec["rows"]) if r["kind"] == "wire"]
        if not indices:
            continue
        rows = [spec["rows"][i] for i in indices]
        yield (
            rows,
            {k: v[indices] for k, v in source_data.items()},
            {
                k: np.stack([extra[r["id"]][k] for r in rows])
                for k in ("truthE", "strongG", "strongB", "strongE", "gap_present")
            },
        )


def marginal(d, ids, scale, G, B):
    rows = np.concatenate([d[i] for i in ids])
    gram = (G * rows[:, None] * rows[None, :]).reshape(len(ids), D, len(ids), D).sum(axis=(0, 2))
    linear = (B * rows).reshape(len(ids), D).sum(axis=0)
    return gram / scale, linear / scale


def prepare(d, s):
    cap = d["support"][:, 1:7, 1:7, :].transpose(0, 3, 1, 2).reshape(4, D).astype(np.float64)
    C, P = marginal(cap, (0, 2), float(d["pairE"]) + 48**2, d["pairG"], d["pairB"])
    for i in range(3):
        G, B = marginal(cap, (i,), float(d["roleE"][i]) + 36**2, d["roleG"][i], d["roleB"][i])
        C += ABSOLUTE * G
        P += ABSOLUTE * B
        G, B = marginal(cap, (i,), float(s["strongE"][i]) + 36**2, s["strongG"][i], s["strongB"][i])
        C += (STRONG / 3) * G
        P += (STRONG / 3) * B
    for ids, k in (((0,), "gap"), ((1, 2), "ext")):
        G, B = marginal(cap, ids, float(d[k + "E"]) + 24**2, d[k + "G"], d[k + "B"])
        C += WEAK * G
        P += WEAK * B
    C += np.eye(D) * 0.00004
    coeff = 100 * (d["signal"].reshape(2, D) * cap[[0, 2]]).sum(axis=0) / s["truthE"]
    return C, P, coeff, cap


def solve(C, b, a):
    gain = float(np.maximum(a, 0.0).sum(dtype=np.float64))
    required = max(0.0, min(TARGET_PP, 0.90 * gain))
    bound = max(float(np.linalg.eigvalsh(C)[-1]), 1e-12)
    norm = np.linalg.norm(a)
    ux = a / max(norm, 1e-14)

    def project(y):
        still = np.clip(y, 0, 1)
        if a @ still >= required or norm < 1e-14:
            return still
        margin = lambda t: float(a @ np.clip(y + t * ux, 0, 1) - required)
        hi = 1.0
        while margin(hi) < 0:
            hi *= 2
        root = brentq(margin, 0, hi, xtol=1e-11)
        return np.clip(y + root * ux, 0, 1)

    x = np.zeros(D, dtype=np.float64)
    y = x.copy()
    pace = 1.0
    for _ in range(STEPS):
        z = project(y - (C @ y + b) / bound)
        q = (1 + np.sqrt(1 + 4 * pace * pace)) / 2
        y = z + (pace - 1) / q * (z - x)
        pace = q
        x = z
    fact = float(a @ x)
    assert fact >= required - 1e-7
    # Supporting hyperplane and a feasible multiplier for the target constraint.
    grad = 2 * (C @ x + b)
    endpoint = (grad < 0).astype(np.float64)
    deficit = required - a @ endpoint
    mu = 0.0
    if deficit > 0:
        ix = np.flatnonzero(((a > 0) & (endpoint == 0)) | ((a < 0) & (endpoint == 1)))
        pr = np.abs(grad[ix] / a[ix])
        for i in np.argsort(pr):
            mu = pr[i]
            deficit -= abs(a[ix[i]])
            if deficit <= 1e-10:
                break
        assert deficit < 1e-8
    support = mu * required + np.minimum(grad - mu * a, 0.0).sum(dtype=np.float64)
    gap = max(0.0, grad @ x - support)
    return x, {
        "max_response_pp": gain,
        "target_pp": required,
        "achieved_pp": fact,
        "duality_gap": float(gap),
    }


def predict(case, extra):
    C, b, a, cap = prepare(case, extra)
    x, receipt = solve(C, b, a)
    vals = cap * x
    report = {}
    for i in range(3):
        u = vals[i]
        r = extra["strongE"][i]
        energy = u @ extra["strongG"][i] @ u + 2 * u @ extra["strongB"][i] + r
        report[str(i)] = float(np.sqrt(max(float(energy), 0.0)) - np.sqrt(r))
    receipt["strong_RMS_change_DN16"] = report
    receipt["gap_present"] = bool(extra["gap_present"])
    receipt["averaged_gain"] = float(x.mean())
    return x.astype(np.float32), receipt


def extras(binding):
    src = read_json(checked(binding))
    seen = {}
    for chunk in src["chunks"]:
        with np.load(checked(read_json(checked(chunk))["data"]), allow_pickle=False) as a:
            fields = {k: a[k] for k in a.files if k != "ids"}
            for i, key in enumerate(a["ids"]):
                assert key not in seen
                seen[key] = {k: v[i] for k, v in fields.items()}
    assert len(seen) == src["wire_count"]
    return seen


def main():
    data = reference(PRIOR / "training/completed.json")
    add = reference(OUT / "training/completed.json")
    labels = []
    identity = []
    records = []
    roots = OUT / "oracle"
    roots.mkdir(exist_ok=True)
    before = monotonic()
    for rows, q, s in load_blocks(data, extras(add)):
        for i, r in enumerate(rows):
            gain, summary = predict(
                {k: v[i] for k, v in q.items()}, {k: v[i] for k, v in s.items()}
            )
            identity.append(r["id"])
            labels.append(gain)
            records.append({"id": r["id"], **summary})
        if len(labels) % 64 == 0:
            print(len(labels), round(monotonic() - before, 1), flush=True)
    assert len(labels) == 384
    result = save(
        roots / "gain-labels.npz", {"ids": np.asarray(identity), "gain": np.stack(labels)}
    )
    write_json(
        roots / "result.json",
        {
            "driver": reference(Path(__file__)),
            "source": data,
            "continuation_coefficients": add,
            "labels": result,
            "target_response_pp": TARGET_PP,
            "strength_penalty": STRONG,
            "weak_gap_penalty": WEAK,
            "absolute_penalty": ABSOLUTE,
            "numbers": records,
            "seconds": monotonic() - before,
            "scope": "Common normalized station gain in present, exterior-only and strong-only roles. Individual data-dependent proposal caps still apply.",
        },
    )


if __name__ == "__main__":
    main()
