"""Add exact continuing-wire statistics to the frozen four-role training captures."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("detail-wire-gate-v1")))

from collect_wire_gate import OUT as PRIOR, render, batch, forward, save, load_model
from wire_gate import ROI, D, SCALE, base, ingredients, windows, wire_scorer


def continuing(d, p, row, g, factory):
    if g["family"] in ("smooth-dip", "contrast-step"):
        d = d | {"support": np.ones_like(d["support"])}
    target = factory(d, g)
    intact = target.truth_weak
    power = float(np.mean(intact**2) * SCALE**2)
    if not target.gap.any():
        return (
            power,
            np.zeros((3, D, D), np.float32),
            np.zeros((3, D), np.float32),
            np.zeros(3, np.float32),
        )
    error = base.old.luma(p["nominal"], d)[ROI] - target.truth
    _, _, fields, _ = ingredients(d, p, row["profile"])
    selected = (fields[ROI][:3, :, None] * windows()).reshape(3, D, 128, 128)
    basis = target.strong_basis
    factor = SCALE / np.sqrt(np.count_nonzero(target.gap))
    design = selected[..., target.gap] @ basis * factor
    residual = error[:3, target.gap] @ basis * factor
    G = np.einsum("bik,bjk->bij", design, design)
    B = np.einsum("bik,bk->bi", design, residual)
    E = np.sum(residual**2, axis=-1)
    return power, G.astype(np.float32), B.astype(np.float32), E.astype(np.float32)


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1.0, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    source = reference(PRIOR / "training/completed.json")
    earlier = read_json(checked(source))
    plan = read_json(checked(earlier["plan"]))
    net = load_model(plan["parent"])
    scorer, factory = wire_scorer()
    folder = OUT / "training"
    folder.mkdir(exist_ok=True)
    old_rows = {}
    for f in earlier["chunks"]:
        for r in read_json(checked(f))["rows"]:
            old_rows[r["id"]] = r
    start = monotonic()
    targets = [r for r in plan["groups"]["training"] if r["kind"] == "wire"]
    chunks = []
    forwards = 0
    with ieee_fp32():
        for first in range(0, len(targets), 16):
            last = min(first + 16, len(targets))
            record = folder / f"part-{first:03}-{last:03}.json"
            if record.exists():
                chunks.append(reference(record))
                continue
            stamps = []
            for item in targets[first:last]:
                d, desc, g = render(item, "training")
                r = old_rows[desc["id"]]
                for key in ("packed", "target", "noise_seeds"):
                    assert r[key] == desc[key], (r["id"], key)
                g = desc["fixture"]["geometry"]
                phase = factory(
                    d | {"support": np.ones_like(d["support"])}
                    if g["family"] in ("smooth-dip", "contrast-step")
                    else d,
                    g,
                )
                if phase.gap.any():
                    preds = forward(net, batch(d), r["profile"], reuse=True)
                    p = {k: v.cpu().numpy() for k, v in preds.items()}
                    v, gram, linear, energy = continuing(d, p, r, g, factory)
                    forwards += 1
                else:
                    v = float(np.mean(phase.truth_weak**2) * SCALE**2)
                    gram = np.zeros((3, D, D), np.float32)
                    linear = np.zeros((3, D), np.float32)
                    energy = np.zeros(3, np.float32)
                stamps.append((r["id"], v, gram, linear, energy, bool(phase.gap.any())))
            values = {
                "ids": np.asarray([r[0] for r in stamps]),
                "truthE": np.asarray([r[1] for r in stamps], dtype=np.float32),
                "strongG": np.stack([r[2] for r in stamps]),
                "strongB": np.stack([r[3] for r in stamps]),
                "strongE": np.stack([r[4] for r in stamps]),
                "gap_present": np.asarray([r[5] for r in stamps], dtype=np.bool_),
            }
            bound = save(record.with_suffix(".npz"), values)
            write_json(record, {"source": source, "data": bound, "first": first, "last": last})
            chunks.append(reference(record))
            print(last, forwards, round(monotonic() - start, 2), flush=True)
    write_json(
        folder / "completed.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "scorer": scorer,
            "parent": plan["parent"],
            "chunks": chunks,
            "wire_count": len(targets),
            "strong_gap_count": 192,
            "forwards_this_pass": forwards,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    run()
