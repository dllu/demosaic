"""Verify retained labels and new confirmation independence."""

import json
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT, PRIOR
from collect_wire_gate import identities

sys.path.insert(0, str(Path(__file__).resolve().parent.with_name("direct-detail-response-v1")))
from audit_sources import CORPUS, LOCAL, matches


def audit():
    current = reference(OUT / "confirmation/plan.json")
    d = read_json(checked(current))
    prev = read_json(checked(d["previous_plan"]))
    panel = identities(r["source"] for r in d["groups"]["held"])
    assert len(panel) == 112
    assert all(
        panel.isdisjoint(identities(r["source"] for r in group))
        for group in prev["groups"].values()
    )
    with checked(prev["training_manifest"]).open() as f:
        assert panel.isdisjoint(identities(map(json.loads, f)))
    old427 = read_json(checked(prev["fixed427"]))["source_metadata"]
    assert len(old427) == 427 and panel.isdisjoint(identities(old427))
    corpus, local = reference(CORPUS), reference(LOCAL)
    data = read_json(checked(corpus))
    latest = read_json(checked(local))
    assert data["checkpoint"] == latest["parent"] and latest["checkpoint"] == prev["parent"]
    prior = 0
    for segment in data["source_traces"]:
        with checked(segment).open() as f:
            for line in map(json.loads, f):
                for row in line["sources"]:
                    if row["kind"] == "photographic":
                        assert not matches(row, panel)
                        prior += 1
    seen = 0
    for segment in latest["segments"]:
        with checked(segment["observations"]).open() as f:
            for line in map(json.loads, f):
                assert not matches(line, panel)
                seen += 1
    assert prior == 559808 and seen == 5000
    more = reference(OUT / "training/completed.json")
    targets = reference(OUT / "oracle/result.json")
    captions = read_json(checked(targets))
    assert captions["continuation_coefficients"] == more
    plan = prev["groups"]["training"]
    wire = [f"training-{r['index']:03}" for r in plan if r["kind"] == "wire"]
    with np.load(checked(captions["labels"]), allow_pickle=False) as d:
        assert d["ids"].tolist() == wire
        assert np.all(d["gain"] >= 0) and np.all(d["gain"] <= 1)
    ids = []
    for f in read_json(checked(more))["chunks"]:
        with np.load(checked(read_json(checked(f))["data"]), allow_pickle=False) as a:
            ids.extend(zip(a["ids"], a["gap_present"], strict=True))
    assert [k for k, v in ids] == wire and sum(v for k, v in ids) == 192
    summary = {
        "wire_labels": len(wire),
        "continuing_gap_labels": 192,
        "confirmation_sources": 56,
        "corpus_visits_checked": prior,
        "local_terminal_observations": seen,
        "teacher_diagnostic_max_gap": max(r["duality_gap"] for r in captions["numbers"]),
        "labels_at_target": sum(r["target_pp"] >= 2 for r in captions["numbers"]),
    }
    print(summary, flush=True)
    write_json(
        OUT / "audit.json",
        {
            "driver": reference(Path(__file__)),
            "new_capture_plan": current,
            "teacher": targets,
            "continuation": more,
            "corpus": corpus,
            "local": local,
            "summary": summary,
        },
    )


if __name__ == "__main__":
    audit()
