"""Measure attainable gains when the three wire views share one normalized gate."""

from pathlib import Path
from statistics import mean
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT, PRIOR, continuing
from oracle_labels import predict
from wire_gate import D, ingredients, statistics, wire_scorer
from score_wire_gate import loads
from evaluate_selector import deltas


def run():
    torch.set_num_threads(2)
    held = reference(PRIOR / "held/completed.json")
    prev = reference(PRIOR / "new-headroom.json")
    known = read_json(checked(prev))
    assert known["source"] == held
    by_id = {r["id"]: r for r in known["rows"]}
    score, make = wire_scorer()
    rows = []
    start = monotonic()
    for r, d, p, ref in loads(held):
        if r["kind"] != "wire":
            continue
        g = r["fixture"]["geometry"]
        source = (
            d | {"support": np.ones_like(d["support"])}
            if g["family"] in ("smooth-dip", "contrast-step")
            else d
        )
        metric = make(source, g)
        stat = statistics(d, p, r["profile"], g, make)
        power, G, B, E = continuing(d, p, r, g, make)
        extra = {
            "truthE": power,
            "strongG": G,
            "strongB": B,
            "strongE": E,
            "gap_present": metric.gap.any(),
        }
        result, info = predict(stat, extra)
        raw, cap, wave, neutral = ingredients(d, p, r["profile"])
        a = cap.copy() * 0
        a[:3, 1:7, 1:7] = result.reshape(3, 6, 6).transpose(1, 2, 0)[None] * cap[:3, 1:7, 1:7]
        restored = (
            p["nominal"]
            + deltas(wave, torch.from_numpy(a)).sum(1)[:, None] * neutral[None, :, None, None]
        )
        parent, oracle = (metric(v) for v in (p["nominal"], restored))
        change = {k: oracle[k] - parent[k] for k in parent}
        assert abs(change["weak_response_pp"] - info["achieved_pp"]) < 2e-5, (r["id"], change, info)
        if metric.gap.any():
            assert (
                abs(change["gap_continuing_strong_RMS_DN16"] - info["strong_RMS_change_DN16"]["0"])
                < 1e-4
            )
        separate = (
            by_id[r["id"]]["report"]["directional"]["oracle"]["maximum_signed_response_pp"]
            - parent["weak_response_pp"]
        )
        assert separate >= info["max_response_pp"] - 1e-5
        rows.append(
            {
                "id": r["id"],
                "source": ref,
                "teacher": info,
                "changes": change,
                "separate_maximum_gain": separate,
            }
        )
        if len(rows) % 8 == 0:
            print(len(rows), round(monotonic() - start, 2), flush=True)
    metrics = sorted({k for r in rows for k in r["changes"]})
    summary = {
        "wire_sources": len(rows),
        "n_exact_gap": sum(r["teacher"]["gap_present"] for r in rows),
        "shared_mean_maximum": mean(r["teacher"]["max_response_pp"] for r in rows),
        "separate_mean_maximum": mean(r["separate_maximum_gain"] for r in rows),
        "shared_two_points_feasible": sum(r["teacher"]["max_response_pp"] >= 2.0 for r in rows),
        "mean_changes": {
            k: mean(r["changes"][k] for r in rows if k in r["changes"]) for k in metrics
        },
        "strong_worse_sources": sum(
            r["changes"].get("gap_continuing_strong_RMS_DN16", 0) > 0 for r in rows
        ),
    }
    print(summary, flush=True)
    write_json(
        OUT / "diagnostic.json",
        {
            "driver": reference(Path(__file__)),
            "source": held,
            "separate_reference": prev,
            "scorer": score,
            "rows": rows,
            "summary": summary,
            "seconds": monotonic() - start,
            "scope": "Previously reviewed optical sources. True data set gains for numerical diagnosis.",
        },
    )


if __name__ == "__main__":
    run()
