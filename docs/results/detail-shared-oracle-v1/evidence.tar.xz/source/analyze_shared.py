"""Compare direct and distilled gains at the same signed response."""

from pathlib import Path
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from continue_stats import OUT
from fit_shared import METHODS
import score_wire_gate as s

METRICS = (
    "weak_response_pp",
    "intact_increment_RMS_DN16",
    "gap_weak_RMS_DN16",
    "gap_continuing_strong_RMS_DN16",
    "exterior_only_weak_RMS_DN16",
    "exact_flat_RMS_DN16",
)


def run(data):
    rows = [r for r in data["rows"] if r["kind"] == "wire"]
    policy = data["policy"]
    value = lambda k, m, x: s.wire_values(rows, k, m, x)
    base = value("nominal", METRICS[0], 0).mean()
    scores = {k: float(value(k, METRICS[0], 1.0).mean() - base) for k in METHODS}
    target = min(scores.values())
    rng = np.random.default_rng(202611201059)
    same = {}
    if target > 0:
        a, b = (target / scores[k] for k in METHODS)
        for m in METRICS:
            u, v = value(METHODS[1], m, b), value(METHODS[0], m, a)
            indices = np.vstack((np.arange(len(u)), rng.integers(len(u), size=(12000, len(u)))))
            diff = (u - v)[indices].mean(axis=1)
            same[m] = [float(diff[0]), *np.quantile(diff[1:], (0.025, 0.975)).tolist()]
    rolled = {}
    for d in (policy["arms"]["directional"]["locked"]["dose"], 1.0):
        comparison = {}
        for m in METRICS:
            a, b = value("directional", m, d), value("rolled directional", m, d)
            x = a - b
            ix = np.vstack((np.arange(len(x)), rng.integers(len(x), size=(12000, len(x)))))
            y = x[ix].mean(axis=1)
            comparison[m] = [float(y[0]), *np.quantile(y[1:], (0.025, 0.975)).tolist()]
        rolled[str(d)] = comparison
    return {
        "common_positive_response": target if target > 0 else None,
        "full_response_gain": scores,
        "matched_distilled_minus_direct": same,
        "aligned_minus_rolled": rolled,
    }


if __name__ == "__main__":
    refs = {k: reference(OUT / f"score-{k}.json") for k in ("prior-held", "held")}
    with patch.object(s, "METHODS", METHODS):
        pieces = {k: run(read_json(checked(ref))) for k, ref in refs.items()}
    print(pieces, flush=True)
    write_json(
        OUT / "analysis.json",
        {
            "driver": reference(Path(__file__)),
            "source": refs,
            "results": pieces,
            "scope": "Retrospective matched response and separately frozen rolled-feature intervention.",
        },
    )
