"""Replay the continuation-protected fits with the preceding measurements and fixed controls."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import torch

from continue_stats import OUT, PRIOR
from fit_shared import METHODS
from wire_gate import Gate, correction
import score_wire_gate as scoring
import review_wire_gate as review

ORIGINAL_LOAD = scoring.load_models
ORIGINAL_PREPARE = scoring.prepare
CONTINUING_LIMIT = 0.10
NAMES = {
    "continuation": "Direct continuation",
    "directional": "Shared-target student",
    "previous directional": "Previous response head",
}


def models():
    with (
        patch.object(scoring, "OUT", PRIOR),
        patch.object(scoring, "METHODS", ("constant", "conditioning", "directional")),
    ):
        _, previous = ORIGINAL_LOAD("training")
    old = reference(PRIOR / "response-priority/fit-training/result.json")
    previous_weights = read_json(checked(old))["checkpoints"]["directional"]
    saved = torch.load(checked(previous_weights), weights_only=True, map_location="cpu")
    model = Gate(True)
    model.load_state_dict(saved["ema"])
    earlier = model.requires_grad_(False).eval()
    trained = reference(OUT / "fit-training/result.json")
    stamp = read_json(checked(trained))
    marks = {}
    for k, f in stamp["checkpoints"].items():
        state = torch.load(checked(f), weights_only=True, map_location="cpu")
        head = Gate(True)
        head.load_state_dict(state["ema"])
        head = head.requires_grad_(False).eval()
        assert state["init"] == previous_weights and state["collection"] == stamp["collection"]
        marks[k] = head
    previous.update(
        {"net": marks, "old": earlier, "normal": saved["normal"], "previous": previous_weights}
    )
    return trained, previous


def prepared(r, d, p, models):
    known, field = ORIGINAL_PREPARE(r, d, p, models)
    add, neutral = correction(d, p, r["profile"], {"previous": models["old"]}, models["normal"])
    nominal = known["nominal"]
    known["previous directional"] = (
        nominal + add["previous"][:, None] * neutral[None, :, None, None]
    ).astype(nominal.dtype)
    return known, field


def stage():
    for k, path in (
        ("calibration", PRIOR / "calibration"),
        ("prior-held", PRIOR / "held"),
        ("held", OUT / "confirmation/held"),
    ):
        root = OUT / k
        if not root.exists():
            root.symlink_to(path, target_is_directory=True)
        assert root.resolve() == path.resolve()
    product = OUT / "evaluation-plan.json"
    if not product.exists():
        write_json(
            product,
            {
                "driver": reference(Path(__file__)),
                "original_scorer": reference(Path(scoring.__file__)),
                "original_reviewer": reference(Path(review.__file__)),
                "prior_calibration_receipt": reference(PRIOR / "calibration/completed.json"),
                "reused_held_receipt": reference(PRIOR / "held/completed.json"),
                "selection": reference(OUT / "confirmation/plan.json"),
                "methods": METHODS,
                "wire_allowed": scoring.WIRE_LIMITS
                | {"gap_continuing_strong_RMS_DN16": CONTINUING_LIMIT},
                "scope": "Same buffered calibration as the previous study, plus an explicit continuing-strand limit. The reused held panel is development evidence. The new confirmation panel is untouched.",
            },
        )


def run(mode):
    stage()
    with ExitStack() as stack:
        for obj, name, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepared),
            (
                scoring,
                "WIRE_LIMITS",
                scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": CONTINUING_LIMIT},
            ),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepared),
            (
                review,
                "ORDER",
                ("nominal", "router", "parent phase", "previous directional", *METHODS),
            ),
            (review, "DISPLAY", review.DISPLAY | NAMES),
        ):
            stack.enter_context(patch.object(obj, name, value))
        if mode == "review":
            review.run()
        elif mode == "full":
            torch.set_num_threads(2)
            fit, net = models()
            lock = reference(OUT / "score-calibration.json")
            dose = {k: 1.0 for k in METHODS}
            board = {}
            for key, make in (("camera", review.standing), ("exact", review.exact)):
                folder = OUT / "native-full" / key
                folder.mkdir(parents=True, exist_ok=True)
                board[key] = make(net, dose, folder)
            write_json(
                OUT / "review-full.json",
                {
                    "driver": reference(Path(__file__)),
                    "fit": fit,
                    "lock": lock,
                    "dose": dose,
                    "held": reference(OUT / "score-held.json"),
                    "views": board,
                    "scope": "Full-strength visual diagnostic. Fixed calibration is recorded separately.",
                },
            )
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
