"""Allow both phase quadratures to be estimated from the fitting colour samples."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from directional_chroma import _CORE, _STRIDE, _WINDOW, _inverse, _windows, base
from directional_chroma import _wave
import directional_chroma as directional
import replay_chroma as replay

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ARMS = ("own_phase", "own_phase_sign")
BASE_CANDIDATES = directional.candidate_patches


def verify(raw, wave, nuisance, pos, shot, read, slopes=None):
    sample = wave[pos[0] :: 2, pos[1] :: 2].reshape(-1, 2).T
    observed = raw.reshape(len(raw), -1)
    keep = base._CHECKER[nuisance.shape[0]]
    found = []
    for i, mask in enumerate((keep, ~keep)):
        proj = base.projection(nuisance, pos, mask)
        fit, held = proj.residual(observed[:, mask], observed[:, ~mask])
        train_wave, test_wave = proj.residual(sample[:, mask], sample[:, ~mask])
        coeff = fit @ _inverse(train_wave.T).T if slopes is None else slopes[i]
        score = directional.base._scores(
            held, coeff @ test_wave, directional._variance(observed[:, mask], shot, read)
        )
        found.append((coeff, score))
    return found


def own_candidates(plane, pos, phase, rival, parent, use, shot, read, frequency, global_rival):
    trial = BASE_CANDIDATES(
        plane, pos, phase, rival, parent, use, shot, read, frequency, global_rival
    )
    wave = _wave(_WINDOW, np.array([frequency]))[..., 0, :]
    raw = _windows(plane, _WINDOW // 2, _STRIDE // 2)[use]
    broad = np.concatenate((base._FIT_BASIS, rival[base._FIT]), axis=-1)
    center = np.concatenate((base._CENTER_BASIS, rival[_CORE]), axis=-1)
    columns = wave[base._FIT]
    output = wave[_CORE]
    first = verify(raw[:, 4:-4, 4:-4], columns, broad, pos, shot, read)
    second = verify(raw[:, 8:-8, 8:-8], output, center, pos, shot, read, [a for a, _ in first])
    first_min = np.minimum(first[0][1], first[1][1])
    second_min = np.minimum(second[0][1], second[1][1])
    coherent = np.einsum("ni,ni->n", first[0][0], first[1][0]) > 0
    measured = (first[0][0] + first[1][0]) / 2
    big = np.concatenate((broad, columns), axis=-1).reshape(base._FIT_WIDTH**2, -1)
    prior = (
        _inverse(big)[-2:] @ parent[use, base._FIT[0], base._FIT[1]].reshape(len(measured), -1).T
    )
    for name, threshold in zip(ARMS, (1.5, 0.0), strict=True):
        excess = np.maximum(0, np.stack((first_min - 6, second_min - threshold), axis=-1))
        gain = np.min(excess / (excess + (6.0, 1.5)), axis=-1) * coherent
        delta = (measured - prior.T) * gain[:, None]
        delta *= np.minimum(
            1, np.linalg.norm(measured, axis=1) / np.linalg.norm(delta, axis=1).clip(min=1e-12)
        )[:, None]
        trial[name] = np.einsum("ijd,nd->nij", output, delta)
    return trial


def main():
    torch.set_num_threads(2)
    start = monotonic()
    bind = reference(OUT / "review.json")
    state = read_json(checked(bind))
    destination = OUT / "own-phase"
    for folder in ("exact", "standing"):
        (destination / folder).mkdir(parents=True, exist_ok=True)
    directional.candidate_patches = own_candidates
    directional.ARMS += ARMS
    replay.ARMS = directional.ARMS
    replay.LABELS |= {"own_phase": "Own R/B phase", "own_phase_sign": "Own phase + sign"}
    replay.OUT = destination
    board = replay.native_board

    def native(folder, case, frames, *args, **kwargs):
        kwargs["triplet_indices"] = (0, len(frames) - 2, len(frames) - 1)
        return board(folder, case, frames, *args, **kwargs)

    replay.native_board = native
    real = replay.standing()
    results = {}
    for name, panel in state["panels"].items():
        rows = replay.photos(panel["source"], name)
        for a, b in zip(panel["rows"], rows, strict=True):
            for r, s in zip(a["draws"], b["draws"], strict=True):
                for k, old in r["scores"].items():
                    assert old == s["scores"][k]
        results[name] = {"source": panel["source"], "rows": rows, "summary": replay.summary(rows)}
    write_json(
        destination / "review.json",
        {
            "driver": reference(__file__),
            "prior": bind,
            "standing": real,
            "panels": results,
            "elapsed": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
