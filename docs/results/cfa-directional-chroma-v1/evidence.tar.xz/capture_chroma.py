"""Freeze a separate set of signed-colour photos at two sensor noise levels."""

from collections import Counter
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-color-delivery-v1")
SALT = 202611200248
COUNT = 16
PROFILES = {
    "iso1600": {"shot": 0.00032, "read": 4.096e-7},
    "iso6400": {"shot": 0.00128, "read": 6.5536e-6},
}
MULTIPLIERS = ((-1.0, -1.0), (-1.0, 0.0), (0.0, -1.0), (1.0, 1.0))
sys.path.insert(0, str(HERE.with_name(PRIOR.name)))
from capture_signed import fixtures as signed_fixtures
import capture_envelope as envelope


def select():
    prior = reference(PRIOR / "plan.json")
    earlier = read_json(checked(prior))
    envelope_plan = read_json(checked(earlier["source_plan"]))
    exclusions = [prior, earlier["source_plan"], *envelope_plan["exclusion_manifests"]]
    blocked = set()
    lines, scan = envelope.capture_wide.lines, envelope.capture_wide.scan
    for f in exclusions:
        if checked(f).suffix == ".jsonl":
            for row in lines(f):
                scan(row, blocked)
        else:
            scan(read_json(checked(f)), blocked)
    photos = [
        r
        for r in lines(earlier["source_pool"])
        if r["split"] == "val"
        and r["bin_factor"] == 4
        and min(r["shape"][:2]) >= 512
        and {r["id"], r["cache_sha256"]}.isdisjoint(blocked)
    ]
    photos.sort(key=lambda row: sha256(f"directional-chroma/{SALT}/{row['id']}".encode()).digest())
    selected = []
    envelope.capture_wide.SEED = SALT
    for r in photos:
        keys = {r["id"], r["cache_sha256"]}
        if not keys.isdisjoint(blocked):
            continue
        i = len(selected)
        (crop,) = scene_crop_boxes(
            r["shape"][:2], patch_size=512, count=1, seed=scene_seed(SALT, i, "crop")
        )
        profile = asdict(sample_scene_recipe(scene_seed(SALT, i, "camera")))
        profile.update(pattern=tuple(PATTERNS)[(i + i // 4) % 4], exposure=0.33, black=0.03)
        rng = np.random.default_rng(scene_seed(SALT, i, "phase"))
        warp = dict(
            zip(
                ("tilt_t", "tilt_n", "bend"),
                (rng.choice((-1, 1), 3) * rng.uniform((1.8, 0.45, 1.35), (4.0, 1.2, 3.2))).tolist(),
                strict=True,
            )
        )
        geometry = envelope.capture_wide.geometry(i)
        geometry.update(
            family=envelope.FAMILIES[i % 4],
            frequency=[
                envelope.carrier(rng, 1, (6.85, 9.4)),
                envelope.carrier(rng, -1, (6.9, 9.5)),
            ],
            strength=rng.uniform((0.010, 0.0045), (0.017, 0.0105)).tolist(),
            gap_width=float(rng.uniform(22, 33)),
            gap_length=float(rng.uniform(32, 57)),
            tint=rng.uniform(0.04, 0.13, 3).tolist(),
        )
        mod = MULTIPLIERS[(i // 4 + i % 4) % 4]
        ellipse = (float((-1) ** i * (9 + i % 3)), float((i % 3 - 1) * 6), 37.0, 47.0)
        selected.append(
            {
                "source": r,
                "box": crop,
                "geometry": geometry,
                "camera": profile,
                "index": i,
                "id": f"directional-color-{i:02d}",
                "split": "confirmation",
                "warp": warp,
                "contrast_group": "aligned" if mod == (1.0, 1.0) else "signed",
                "color_multipliers": mod,
                "color_ellipse": ellipse,
            }
        )
        blocked.update(keys)
        if len(selected) == COUNT:
            break
    assert len(selected) == COUNT
    picks = {x["source"][k] for x in selected for k in ("id", "cache_sha256")}
    trace = read_json(checked(earlier["train_trace"]))
    visited = 0
    for f in trace["source_traces"]:
        for row in lines(f):
            for src in row["sources"]:
                if src["kind"] == "photographic":
                    assert picks.isdisjoint((src["source_id"], src["cache_sha256"]))
                    visited += 1
    assert visited == earlier["photo_visits_checked"]
    return {
        "driver": reference(__file__),
        "capture_driver": reference(envelope.__file__),
        "signed_generator": reference(sys.modules["capture_signed"].__file__),
        "sources": selected,
        "source_pool": earlier["source_pool"],
        "seed": SALT,
        "weights": earlier["weights"],
        "excluded": exclusions,
        "parent_trace": earlier["train_trace"],
        "trace_visits": visited,
        "groups": dict(Counter(x["contrast_group"] for x in selected)),
        "states": ("warped",),
        "query": earlier["query"],
        "sigma": earlier["sigma"],
        "roles": earlier["roles"],
        "widths": {"along": [28.0, 10.0], "isotropic": [float(np.sqrt(280))] * 2},
        "central_held_thresholds": (1.5, 0.0),
        "profiles": PROFILES,
    }


def main():
    torch.set_num_threads(2)
    base = OUT / "master.json"
    if not base.exists():
        write_json(base, select())
    master = reference(base)
    plan = read_json(checked(master))
    assert plan["driver"] == reference(__file__)
    profiles = {}
    for i, (key, noise) in enumerate(plan["profiles"].items()):
        output = OUT / key
        output.mkdir(exist_ok=True)
        fixture = output / "plan.json"
        cases = [x | {"camera": x["camera"] | noise} for x in plan["sources"]]
        recipe = plan | {
            "cases": cases,
            "noise": noise | {"exposure": 0.33},
            "master": master,
            "native_indices": [0, 5],
        }
        if not fixture.exists():
            write_json(fixture, recipe)
        envelope.OUT, envelope.SALT, envelope.STATES, envelope.fixtures = (
            output,
            SALT + 1000 * i,
            ("warped",),
            signed_fixtures,
        )
        done = output / "inputs.json"
        if not done.exists():
            envelope.capture(read_json(fixture), reference(fixture))
        profiles[key] = reference(done)
    write_json(OUT / "inputs.json", {"master": master, "panels": profiles})


if __name__ == "__main__":
    main()
