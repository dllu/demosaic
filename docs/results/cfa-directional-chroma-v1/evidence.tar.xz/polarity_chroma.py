"""Keep only negative-polarity support nominated on the fitting checkerboard."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from directional_chroma import (
    _CORE,
    _STRIDE,
    _WINDOW,
    _inverse,
    _windows,
    base,
    node_terms,
    pool_weights,
    verify_pool,
)
import directional_chroma as directional
import replay_chroma as replay

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
NEW = ("polarity", "polarity_sign")
BASE_CANDIDATES = directional.candidate_patches


def negative_pool(terms, spatial):
    amplitudes, scores = [], []
    for row in terms:
        weight = np.clip(-(row[0] / np.sqrt(row[1].clip(min=1e-12))) / 2, 0, 1)
        fit, held = verify_pool([row], spatial * weight)
        amplitudes.append(fit[:, 0])
        scores.append(held[:, 0])
    return np.stack(amplitudes, axis=-1), np.stack(scores, axis=-1)


def candidates(plane, pos, phase, competing, parent, use, shot, read, frequency, rival):
    result = BASE_CANDIDATES(
        plane, pos, phase, competing, parent, use, shot, read, frequency, rival
    )
    terms = node_terms(plane, pos, phase, rival, shot, read)
    fit, scores = negative_pool(terms, pool_weights(frequency, "along")[use])
    window = _windows(phase, _WINDOW, _STRIDE)[use]
    phase_core = window[:, _CORE[0], _CORE[1]]
    raw_center = _windows(plane, _WINDOW // 2, _STRIDE // 2)[use, 8:-8, 8:-8]
    core = np.concatenate((base._CENTER_BASIS, competing[_CORE]), axis=-1)
    center = base.analyses(raw_center, phase_core, core, pos, shot, read, slope=fit.T)
    center_scores = np.minimum(center[0][1], center[1][1])
    broad = np.concatenate((base._FIT_BASIS, competing[base._FIT]), axis=-1)
    field = window[:, base._FIT[0], base._FIT[1]].reshape(len(fit), -1)
    nuisance = broad.reshape(field.shape[1], -1)
    projected = np.einsum("dp,np->nd", _inverse(nuisance), field)
    shape = field - np.einsum("pd,nd->np", nuisance, projected)
    prev = parent[use, base._FIT[0], base._FIT[1]].reshape(len(fit), -1)
    prior = np.einsum("np,np->n", shape, prev) / np.einsum("np,np->n", shape, shape).clip(min=1e-12)
    for k, threshold in zip(NEW, (1.5, 0.0), strict=True):
        excess = np.maximum(
            0, np.stack((scores.min(axis=1) - 6, center_scores - threshold), axis=-1)
        )
        gain = np.min(excess / (excess + (6.0, 1.5)), axis=-1) * np.all(fit < 0, axis=1)
        amp = fit.mean(axis=1)
        delta = np.clip(gain * (amp - prior), -abs(amp), abs(amp))
        result[k] = phase_core * delta[:, None, None]
    return result


def main():
    torch.set_num_threads(2)
    start = monotonic()
    reference_replay = reference(OUT / "review.json")
    prior = read_json(checked(reference_replay))
    destination = OUT / "polarity"
    for folder in ("exact", "standing"):
        (destination / folder).mkdir(exist_ok=True, parents=True)
    directional.candidate_patches = candidates
    directional.ARMS += NEW
    replay.ARMS = directional.ARMS
    replay.LABELS |= {"polarity": "Negative phase pool", "polarity_sign": "Negative phase + sign"}
    replay.OUT = destination
    old_board = replay.native_board

    def native(folder, case, frames, *args, **kwargs):
        kwargs["triplet_indices"] = (0, len(frames) - 2, len(frames) - 1)
        return old_board(folder, case, frames, *args, **kwargs)

    replay.native_board = native
    raw_review = read_json(checked(prior["prior"]))
    result = {}
    real = replay.standing()
    for name, panel in prior["panels"].items():
        expected = (
            {r["id"]: r for r in raw_review["signed"]["rows"]} if name == "retained" else None
        )
        rows = replay.photos(panel["source"], name, expected)
        for before, after in zip(panel["rows"], rows, strict=True):
            for a, b in zip(before["draws"], after["draws"], strict=True):
                for key, scores in a["scores"].items():
                    assert scores == b["scores"][key]
        result[name] = {"source": panel["source"], "rows": rows, "summary": replay.summary(rows)}
    write_json(
        destination / "review.json",
        {
            "driver": reference(__file__),
            "previous": reference_replay,
            "panels": result,
            "standing": real,
            "elapsed": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
