"""Pool disjoint colour observations around each green-approved strand window."""

from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_pooled import (
    _CENTERS,
    _CORE,
    _NODE,
    _NODE_BACKGROUND,
    _SIDE,
    _STRIDE,
    _WINDOW,
    _inverse,
    _nodes,
    _rgb,
    _variance,
    _wave,
    _windows,
)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("cfa-color-delivery-v1")))
from replay_delivery import apply_delivery as local_delivery
import signed_delivery as base

ARMS = ("conditional", "square_sign", "isotropic", "along", "along_sign")
WIDTHS = {"isotropic": (np.sqrt(280), np.sqrt(280)), "along": (28.0, 10.0)}
NODE_CENTERS = np.indices((_SIDE, _SIDE)).reshape(2, -1).T * _NODE + (_NODE - 1) / 2
WINDOW_CENTERS = np.asarray(_CENTERS) + (_WINDOW - 1) / 2
OFFSETS = NODE_CENTERS[None] - WINDOW_CENTERS[:, None]
NODE_PARITY = np.indices((_NODE // 2, _NODE // 2)).sum(axis=0).ravel() % 2 == 0
BASE_PATCHES = base.channel_patches


def pool_weights(frequency, kind):
    normal = np.asarray(frequency)[::-1]
    normal = normal / np.linalg.norm(normal)
    tangent = np.array([normal[1], -normal[0]])
    a, b = WIDTHS[kind]
    return np.exp(-0.5 * ((OFFSETS @ tangent / a) ** 2 + (OFFSETS @ normal / b) ** 2))


def node_terms(plane, position, shape, rival, shot, read):
    """Fit a separate low-frequency/RGB nuisance on each training subset."""
    r, c = position
    wave = _nodes(shape[r::2, c::2])
    smooth = _NODE_BACKGROUND[r::2, c::2].reshape(1, (_NODE // 2) ** 2, -1)
    rival = _nodes(rival[r::2, c::2])
    background = np.concatenate(
        (np.broadcast_to(smooth, (*rival.shape[:2], smooth.shape[-1])), rival), axis=-1
    )
    obs = _nodes(plane)
    result = []
    for k in (NODE_PARITY, ~NODE_PARITY):
        A, B = background[:, k], background[:, ~k]
        gram = np.einsum("ndi,ndj->nij", A, A)
        inv = np.linalg.pinv(gram, rcond=1e-9, hermitian=True) @ A.swapaxes(1, 2)
        transfer = B @ inv
        wf, wh = wave[:, k], wave[:, ~k]
        of, oh = obs[:, k], obs[:, ~k]
        qf = wf - np.einsum("nip,np->ni", A, np.einsum("nip,np->ni", inv, wf))
        qh = wh - np.einsum("nip,np->ni", transfer, wf)
        yh = oh - np.einsum("nip,np->ni", transfer, of)
        variance = _variance(of, shot, read)
        dot = lambda a, b: np.einsum("ni,ni->n", a, b) / variance
        extra = np.einsum("nip,ni->np", transfer, qh)
        result.append(
            (dot(qf, of), dot(qf, qf), dot(qh, yh), dot(qh, qh), dot(qh, qh) + dot(extra, extra))
        )
    return result


def verify_pool(terms, weights):
    fits = []
    scores = []
    for fit, fit_energy, held, held_energy, noise in terms:
        amplitude = (weights @ fit) / (weights @ fit_energy).clip(min=1e-12)
        power = weights @ held_energy
        denom = (weights**2 @ noise).clip(min=1e-12)
        scores.append((2 * amplitude * (weights @ held) - amplitude**2 * power) * power / denom)
        fits.append(amplitude)
    return np.stack(fits, axis=-1), np.stack(scores, axis=-1)


def candidate_patches(plane, position, phase, competing, parent, use, shot, read, frequency, rival):
    window = _windows(phase, _WINDOW, _STRIDE)[use]
    samples = _windows(plane, _WINDOW // 2, _STRIDE // 2)[use]
    broad = np.concatenate((base._FIT_BASIS, competing[base._FIT]), axis=-1)
    core = np.concatenate((base._CENTER_BASIS, competing[_CORE]), axis=-1)
    phase_fit = window[:, base._FIT[0], base._FIT[1]]
    phase_core = window[:, _CORE[0], _CORE[1]]
    sample_fit = samples[:, 4:-4, 4:-4]
    sample_core = samples[:, 8:-8, 8:-8]
    direct = base.analyses(sample_fit, phase_fit, broad, position, shot, read)
    local_fits = np.stack([a[0] for a in direct], axis=-1)
    local_scores = np.stack([a[1] for a in direct], axis=-1)

    terms = node_terms(plane, position, phase, rival, shot, read)
    by_shape = {name: verify_pool(terms, pool_weights(frequency, name)[use]) for name in WIDTHS}
    band = phase_fit.reshape(len(window), -1)
    nuisance = broad.reshape(len(band[0]), -1)
    ref = np.einsum("dp,np->nd", _inverse(nuisance), band)
    innovation = band - np.einsum("pd,nd->np", nuisance, ref)
    parent_values = parent[use, base._FIT[0], base._FIT[1]].reshape(len(window), -1)
    existing = np.einsum("np,np->n", innovation, parent_values) / np.einsum(
        "np,np->n", innovation, innovation
    ).clip(min=1e-12)
    result = {}
    for label, (fit, scores), threshold in (
        ("square_sign", (local_fits, local_scores), 0.0),
        ("isotropic", by_shape["isotropic"], 1.5),
        ("along", by_shape["along"], 1.5),
        ("along_sign", by_shape["along"], 0.0),
    ):
        held = base.analyses(sample_core, phase_core, core, position, shot, read, slope=fit.T)
        excess = np.maximum(
            0,
            np.stack(
                (scores.min(axis=1) - 6.0, np.minimum(held[0][1], held[1][1]) - threshold), axis=-1
            ),
        )
        gain = np.min(excess / (excess + (6.0, 1.5)), axis=-1) * (fit.prod(axis=1) > 0)
        amp = fit.mean(axis=1)
        delta = np.clip(gain * (amp - existing), -abs(amp), abs(amp))
        result[label] = phase_core * delta[:, None, None]
    return result


def apply_directional(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    if peaks is None:
        crop, _ = local_delivery(parent, local, scene, roi, colors, peaks, noise, wb, matrix)
        return {k: crop["conditional"] for k in ARMS}, {"old": None, "recovered": {}}
    local_wave = _wave(_WINDOW, peaks)
    footprint = _wave(_SIDE * _NODE, peaks)
    additions = {k: np.zeros((3, len(_CENTERS), _WINDOW // 2, _WINDOW // 2)) for k in ARMS[1:]}
    recovered = {k: np.zeros(3, dtype=int) for k in ARMS[1:]}
    tests = []
    xx, yy = roi[:2]

    def rescue(plane, position, phase, competing, prior, active, shot, read, nominal):
        original, veto = BASE_PATCHES(
            plane, position, phase, competing, prior, active, shot, read, nominal
        )
        use = veto & ~np.any(original, axis=(1, 2))
        if not use.any():
            return original, veto
        d = int(np.array_equal(competing, local_wave[..., 0, :]))
        rival = footprint[..., 1 - d, :]
        assert np.array_equal(competing, local_wave[..., 1 - d, :])
        choices = candidate_patches(
            plane, position, phase, competing, prior, use, shot, read, peaks[d], rival
        )
        r, c = position
        channel = colors[2 * ((yy + r) % 2) + ((xx + c) % 2)]
        assert channel in (0, 2)
        for arm, patches in choices.items():
            additions[arm][channel, use] += patches
            recovered[arm][channel] += int(np.count_nonzero(np.any(patches, axis=(1, 2))))
        tests.append({"direction": d, "channel": int(channel), "windows": int(use.sum())})
        return original, veto

    try:
        base.channel_patches = rescue
        local_variants, evidence = local_delivery(
            parent, local, scene, roi, colors, peaks, noise, wb, matrix
        )
    finally:
        base.channel_patches = BASE_PATCHES
    current = local_variants["conditional"]
    outputs = {"conditional": current}
    for name, patches in additions.items():
        outputs[name] = current + np.stack([_rgb(a, np.ones(1), current.dtype)[0] for a in patches])
        np.testing.assert_array_equal(current[1], outputs[name][1])
    return outputs, {
        "old": evidence,
        "proposals": tests,
        "recovered": {k: v.tolist() for k, v in recovered.items()},
    }


def held_audit():
    """The pooled fit has no dependence on the held checkerboard."""
    rng = np.random.default_rng(5003)
    freq = np.array(((0.101, 0.079), (0.091, -0.067)))
    wave = _wave(_SIDE * _NODE, freq)
    result = []
    for pos in np.ndindex(2, 2):
        shape = wave[..., 0, 0]
        r, c = pos
        data = 0.07 + 0.004 * shape[r::2, c::2] + rng.normal(0, 0.012, (96, 96))
        a = node_terms(data, pos, shape, wave[..., 1, :], 0.00128, 6.5536e-6)
        for fold, mask in enumerate((NODE_PARITY, ~NODE_PARITY)):
            keep = (np.indices(data.shape).sum(axis=0) % 2) == fold
            assert np.array_equal(_nodes(keep)[0], mask)
            new = data.copy()
            new[~keep] = rng.uniform(0.04, 0.10, (~keep).sum())
            b = node_terms(new, pos, shape, wave[..., 1, :], 0.00128, 6.5536e-6)
            for i in (0, 1):
                np.testing.assert_array_equal(a[fold][i], b[fold][i])
            assert np.any(a[fold][2] != b[fold][2])
            result.append({"phase": pos, "fold": fold})
    return result
