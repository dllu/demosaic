"""Bind the native examples where the fresh R/B phase trial delivers a correction."""

from pathlib import Path

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import directional_chroma as directional
from own_chroma_phase import ARMS, own_candidates
from replay_chroma import arrays, OUT, ROI, RAW, SENSOR_ROI, native_board


def main():
    torch.set_num_threads(2)
    binding = reference(OUT / "own-phase" / "review.json")
    review = read_json(checked(binding))
    panel = review["panels"]["iso1600"]
    captures = read_json(checked(panel["source"]))
    plan = read_json(checked(captures["plan"]))
    source = {r["id"]: r for r in plan["cases"]}
    directional.candidate_patches = own_candidates
    directional.ARMS += ARMS
    out = OUT / "recovered"
    out.mkdir(exist_ok=True)
    records = []
    for row in panel["rows"]:
        for r in row["draws"]:
            if not r["fits"][0]["recovered"].get("own_phase_sign", [0])[0]:
                continue
            f = arrays(r["input"])
            p = f["local50k"][0]
            colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
            scene = f["scene_packed"].copy()
            scene[RAW] = f["packed"][0]
            peaks = _spacing(scene, colors, *SENSOR_ROI[:2], clearance=48)
            arms, evidence = directional.apply_directional(
                p, ROI, scene, SENSOR_ROI, colors, peaks, plan["noise"], wb, matrix
            )
            assert evidence == r["fits"][0]
            attrs = {k: f[k][None] for k in ("colors", "wb", "matrix")}
            attrs["packed"] = f["packed"][:1]

            # native_board crops its inputs to the shared 160-pixel ROI.
            def full(v):
                img = p.copy()
                img[:, 48:208, 48:208] = v
                return img

            frames = [
                noisy_malvar(attrs)[0],
                p,
                full(arms["conditional"]),
                full(arms["own_phase_sign"]),
                f["target"][0],
            ]
            case = source[row["id"]]
            saved = native_board(
                out,
                row["id"],
                frames,
                attrs,
                {
                    "input": r["input"],
                    "source": case,
                    "weights": plan["weights"],
                    "noise": plan["noise"],
                    "query": plan["query"],
                    "optical_sigma": plan["sigma"],
                },
                labels=[
                    "Noisy Malvar",
                    "Local 50k",
                    "Local conditional",
                    "Own phase + sign",
                    "Exact GT",
                ],
                triplet_indices=(0, 3, 4),
            )
            changed = arms["own_phase_sign"].astype("d") - arms["conditional"]
            yy, xx = np.where(abs(changed[0]) > 0)
            assert len(xx) > 0
            region = [
                int(xx.min()),
                int(yy.min()),
                int(xx.max() + 1 - xx.min()),
                int(yy.max() + 1 - yy.min()),
            ]
            row = {
                "id": row["id"],
                "info": saved,
                "changed_roi_in_native_crop": region,
                "draw": r["draw"],
                "peak_change_DN16": 65535 * float(np.max(abs(changed))),
            }
            records.append(row)
            print(row["id"], region, row["peak_change_DN16"], flush=True)
    assert len(records) == 2
    write_json(
        OUT / "recovered.json",
        {"driver": reference(__file__), "bench": binding, "records": records},
    )


if __name__ == "__main__":
    main()
