"""Test held scores with a supplied exact signed contrast on suppressed windows."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from directional_chroma import node_terms, pool_weights, base, BASE_PATCHES
from demosaic._mesh_pooled import _CORE, _SIDE, _NODE, _STRIDE, _WINDOW, _wave, _windows
from replay_chroma import arrays, RAW, ROI, SENSOR_ROI, OUT, PRIOR

HERE = Path(__file__).resolve().parent


def exact_scores(terms, weights, amplitude):
    scores = []
    for _, _, m, energy, noise in terms:
        power = weights @ energy
        scores.append(
            (2 * amplitude * (weights @ m) - amplitude**2 * power)
            * power
            / (weights**2 @ noise).clip(min=1e-12)
        )
    return np.stack(scores, axis=-1)


def audit_sample(f, noise):
    packed = f["scene_packed"].copy()
    packed[RAW] = f["packed"][0]
    rgb = f["local50k"][0]
    colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
    peaks = _spacing(packed, colors, *SENSOR_ROI[:2], clearance=48)
    if peaks is None:
        return []
    live = []
    target = (f["target"][0] - f["target"][1])[:, 32:224, 32:224].astype("d")
    local_wave = _wave(_WINDOW, peaks)
    footprint = _wave(_SIDE * _NODE, peaks)
    xx, yy = SENSOR_ROI[:2]

    def observe(plane, site, phase, competing, prior, active, shot, read, nominal):
        original, veto = BASE_PATCHES(
            plane, site, phase, competing, prior, active, shot, read, nominal
        )
        use = veto & ~np.any(original, axis=(1, 2))
        if not use.any() or not np.array_equal(competing, local_wave[..., 0, :]):
            return original, veto
        r, c = site
        color = colors[2 * ((yy + r) % 2) + ((xx + c) % 2)]
        truth = target[color]
        center = _windows(truth, _WINDOW, _STRIDE)[use, _CORE[0], _CORE[1]]
        samples = _windows(plane, _WINDOW // 2, _STRIDE // 2)[use, 8:-8, 8:-8]
        strength = np.sqrt(np.mean(center**2, axis=(1, 2))) * 65535
        terms = node_terms(plane, site, truth, footprint[..., 0, :], shot, read)
        weights = pool_weights(peaks[1], "along")[use]
        source = [(weights @ fit) / (weights @ energy).clip(min=1e-12) for fit, energy, *_ in terms]
        unit = np.ones(len(strength))
        background = np.concatenate((base._CENTER_BASIS, competing[_CORE]), axis=-1)
        for name, dose in (("exact_amplitude", (unit, unit)), ("estimated_amplitude", source)):
            broad = (
                exact_scores(terms, weights, unit)
                if name == "exact_amplitude"
                else np.column_stack(
                    [exact_scores([t], weights, a)[:, 0] for t, a in zip(terms, dose, strict=True)]
                )
            )
            held = base.analyses(samples, center, background, site, shot, read, slope=dose)
            good = (
                (broad.min(axis=1) > 6)
                & (np.minimum(held[0][1], held[1][1]) > 1.5)
                & (np.minimum(*dose) > 0)
            )
            live.append(
                {
                    "color": int(color),
                    "mode": name,
                    "n": int(use.sum()),
                    "nontrivial": int(np.count_nonzero(strength >= 8)),
                    "signed_checks": int(np.count_nonzero(good & (strength >= 8))),
                    "DN16": strength.tolist(),
                    "pass": good.tolist(),
                }
            )
        return original, veto

    try:
        base.channel_patches = observe
        base.apply_delivery(rgb, ROI, packed, SENSOR_ROI, colors, peaks, noise, wb, matrix)
    finally:
        base.channel_patches = BASE_PATCHES
    return live


def main():
    torch.set_num_threads(2)
    start = monotonic()
    before = reference(PRIOR / "inputs.json")
    pair = reference(OUT / "inputs.json")
    links = {"retained": before, **read_json(checked(pair))["panels"]}
    data = {}
    for name, link in links.items():
        captures = read_json(checked(link))
        plan = read_json(checked(captures["plan"]))
        result = []
        for case in captures["rows"]:
            for d in case["observations"]["warped"]:
                witnesses = audit_sample(arrays(d["input"]), plan["noise"])
                result.append({"input": d["input"], "witnesses": witnesses})
        total = {}
        for label in ("exact_amplitude", "estimated_amplitude"):
            rows = [q for g in result for q in g["witnesses"] if q["mode"] == label]
            total[label] = {
                k: sum(q[k] for q in rows) for k in ("n", "nontrivial", "signed_checks")
            }
        data[name] = {"input": link, "findings": total, "samples": result}
        print(name, total, flush=True)
    write_json(
        OUT / "known-color.json",
        {
            "driver": reference(__file__),
            "inputs": pair,
            "procedure": reference(HERE / "directional_chroma.py"),
            "elapsed": monotonic() - start,
            "results": data,
        },
    )


if __name__ == "__main__":
    main()
