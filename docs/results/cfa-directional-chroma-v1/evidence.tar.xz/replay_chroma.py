"""Score directional chroma pooling on frozen RAW, fresh photos and standing crops."""

from pathlib import Path
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

from directional_chroma import ARMS, apply_directional, held_audit
from replay_delivery import (
    FIXED,
    RAW,
    ROI,
    SENSOR_ROI,
    CORE,
    REGION,
    arrays,
    display,
    native_board,
    section,
    rms,
)
from replay_delivery import scores as prior_scores
from capture_signed import reversal
from review_pool import interval, source_bootstrap

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-color-delivery-v1")
LABELS = {
    "conditional": "Local conditional",
    "square_sign": "Square + sign",
    "isotropic": "Isotropic pool",
    "along": "Along-strand pool",
    "along_sign": "Along + sign",
}


def exact_scores(v, t, mask, support, p):
    base = prior_scores(v, t, mask, p)
    z = v[0:2][CORE]
    truth = t[0:2][CORE]
    expected = (truth[0] - truth[1])[[0, 2]]
    fitted = (z[0] - z[1])[[0, 2]]
    gap = (support[CORE] <= 1e-8) & (np.max(abs(expected), axis=0) < 1e-6)
    if np.count_nonzero(gap) >= 64:
        base["gap_RB_RMS_DN16"] = rms(fitted[:, gap] - expected[:, gap])
    if np.count_nonzero(mask) >= 64:
        a, b = expected[:, mask], fitted[:, mask]
        norm = float(np.sum(a.astype("d") ** 2))
        if norm > 1e-9:
            base["signed_RB_response"] = 100 * float(np.sum(a.astype("d") * b)) / norm
    return base


def photos(links, tag, golden=None):
    input_rows = read_json(checked(links))
    plan = read_json(checked(input_rows["plan"]))
    out = []
    for case, row in zip(plan["cases"], input_rows["rows"], strict=True):
        assert case["id"] == row["id"]
        controls = []
        ellipse = reversal(case)[1].numpy()[REGION]
        for d, record in enumerate(row["observations"]["warped"]):
            f = arrays(record["input"])
            scene = f["scene_packed"].copy()
            parent = f["local50k"]
            colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
            peaks = _spacing(scene, colors, *SENSOR_ROI[:2], clearance=48)
            predictions = {m: parent.copy() for m in ARMS}
            fits = []
            for j, mosaic in enumerate(f["packed"]):
                scene[RAW] = mosaic
                modes, info = apply_directional(
                    parent[j], ROI, scene, SENSOR_ROI, colors, peaks, plan["noise"], wb, matrix
                )
                for mode in ARMS:
                    section(predictions[mode][j], *ROI)[:] = modes[mode]
                fits.append(info)
            mask = (ellipse & (f["support"] >= 0.35))[CORE]
            scores = {
                k: exact_scores(v, f["target"], mask, f["support"], parent)
                for k, v in (predictions | {"parent": parent, "v120": f["v120"]}).items()
            }
            if golden is not None:
                expected = golden[row["id"]]["draws"][d]["scores"]["conditional"]
                assert all(expected[k] == scores["conditional"][k] for k in expected)
            view = None
            if tag == "iso1600" and d == 0 and case["index"] in plan["native_indices"]:
                attrs = {k: f[k][None] for k in ("colors", "wb", "matrix")}
                attrs["packed"] = f["packed"][:1]
                images = [
                    noisy_malvar(attrs)[0],
                    f["v120"][0],
                    parent[0],
                    *(predictions[k][0] for k in ARMS),
                    f["target"][0],
                ]
                view = native_board(
                    OUT / "exact",
                    case["id"],
                    images,
                    attrs,
                    {
                        "input": record["input"],
                        "source": case,
                        "noise": plan["noise"],
                        "weights": plan["weights"],
                        "optical_sigma": plan["sigma"],
                        "query": plan["query"],
                    },
                    labels=["Noisy Malvar", "V120 EMA", "Local 50k", *LABELS.values(), "Exact GT"],
                    triplet_indices=(0, 7, 8),
                )
            controls.append(
                {
                    "draw": d,
                    "input": record["input"],
                    "scores": scores,
                    "local_samples": int(mask.sum()),
                    "fits": fits,
                    "view": view,
                }
            )
        out.append(
            {
                "id": case["id"],
                "family": case["geometry"]["family"],
                "multipliers": case["color_multipliers"],
                "class": "aligned" if case["color_multipliers"] == [1.0, 1.0] else "signed",
                "draws": controls,
            }
        )
        if len(out) % 8 == 0:
            print(tag, len(out), flush=True)
    return out


def summary(data):
    result = {}
    for name, rows in (
        ("all", data),
        ("signed", [r for r in data if r["class"] == "signed"]),
        ("aligned", [r for r in data if r["class"] == "aligned"]),
    ):
        if not rows:
            continue
        metrics = sorted({m for r in rows for d in r["draws"] for m in d["scores"]["conditional"]})
        table = {}
        for metric in metrics:
            subset = [
                r for r in rows if all(metric in d["scores"]["conditional"] for d in r["draws"])
            ]
            rg = np.random.default_rng(202611200249)
            indices = source_bootstrap(subset, rg)
            arms = {}
            for mode in (*ARMS, "parent", "v120"):
                a = np.array(
                    [[d["scores"][mode][metric] for d in r["draws"]] for r in subset]
                ).mean(axis=1)
                b = np.array(
                    [[d["scores"]["conditional"][metric] for d in r["draws"]] for r in subset]
                ).mean(axis=1)
                arms[mode] = {
                    "n": len(a),
                    "mean": float(a.mean()),
                    "delta": interval((a - b)[indices].mean(1)),
                }
            table[metric] = arms
        recovered = {}
        for arm in ARMS[1:]:
            for j, role in enumerate(("present", "strong_only", "flat", "edge", "uniform")):
                vals = [
                    np.asarray(d["fits"][j]["recovered"].get(arm, (0, 0, 0)))
                    for r in rows
                    for d in r["draws"]
                ]
                recovered.setdefault(role, {})[arm] = np.sum(vals, axis=0).tolist()
        result[name] = {"metrics": table, "windows": recovered}
    return result


def standing():
    source = reference(FIXED)
    saved = read_json(checked(source))
    rows = []
    for row in saved["standing"]:
        f = arrays(row["input"])
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(row["local_ROI"])
        peaks = _spacing(scene, colors, *roi[:2], clearance=16)
        out, details = apply_directional(
            p, roi, scene, roi, colors, peaks, row["noise"], wb, matrix
        )
        differences = {k: rms(out[k] - out["conditional"]) for k in ARMS}
        results = []
        for board in row["displays"]:
            prior = board["board"]
            exposure = board["exposure"]
            with Image.open(checked(prior["image"])) as image:
                saved_image = np.asarray(image)
            panes = {}
            for item in prior["panels"]:
                x, y, w, h = item["png_xywh"]
                panes[item["name"]] = saved_image[y : y + h, x : x + w]
            cells = [(k, panes[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            cells += [
                (LABELS[k], display(out[k], wb, matrix, exposure))
                for k in ("conditional", "isotropic", "along", "along_sign")
            ]
            cells += [
                (k, panes[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in panes
            ]
            img = Image.new("RGB", (168 * len(cells) + 8, 192), "#eee")
            draw = ImageDraw.Draw(img)
            labels = []
            for i, (name, arr) in enumerate(cells):
                x = 8 + 168 * i
                img.paste(Image.fromarray(arr), (x, 24))
                draw.text((x, 5), name, fill="black")
                labels.append({"label": name, "xywh": [x, 24, 160, 160]})
            path = OUT / "standing" / f"{row['id']}-x{exposure:g}.png"
            img.save(path)
            results.append(
                {"image": reference(path), "prior": prior, "labels": labels, "exposure": exposure}
            )
        rows.append(
            {
                "id": row["id"],
                "input": row["input"],
                "noise": row["noise"],
                "ROI": row["global_ROI"],
                "parent": row["predictions"]["local50k"],
                "raw": row["raw"],
                "change_RGB_DN16": differences,
                "details": details,
                "views": results,
            }
        )
        print(row["id"], differences, flush=True)
    return {"fixed": source, "rows": rows, "weights": saved["checkpoints"]}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    for folder in ("exact", "standing"):
        (OUT / folder).mkdir(exist_ok=True)
    pair = reference(OUT / "inputs.json")
    capture = read_json(checked(pair))
    before = reference(PRIOR / "review.json")
    past = read_json(checked(before))
    sources = {"retained": past["signed_capture"], **capture["panels"]}
    real = standing()
    groups = {}
    for name, source in sources.items():
        result = photos(
            source,
            name,
            {r["id"]: r for r in past["signed"]["rows"]} if name == "retained" else None,
        )
        groups[name] = {"source": source, "rows": result, "summary": summary(result)}
    write_json(
        OUT / "review.json",
        {
            "driver": reference(__file__),
            "operation": reference(HERE / "directional_chroma.py"),
            "prior": before,
            "capture": pair,
            "held_audit": held_audit(),
            "standing": real,
            "panels": groups,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
