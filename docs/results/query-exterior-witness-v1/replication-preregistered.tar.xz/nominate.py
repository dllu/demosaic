"""Run the frozen exterior and prior-wide searches on preregistered replica inputs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"query-exterior-witness-v1"
sys.path.insert(0,str(PREV))
from chirp_bank import predict
from specificity import evaluate
from forecasts import nominate

ROLES=("present","outside-only","strong-only","quiet-query")


def run():
    complete=reference(ROOT/"fields.json")
    inputs=read_json(checked(complete))
    design=read_json(checked(inputs["plan"]))
    for name,entry in design["fixed_algorithm"].items():
        assert checked(entry)==PREV/name
    box,noise=design["query_box"],design["profile"]
    def row(source):
        prior=nominate((source,None))
        with np.load(checked(source["capture"]),allow_pickle=False)as f:
            arrays={key:f[key]for key in ("packed","colors")}
        measurements=[]
        for t in prior["trials"]:
            rep=t["repeat"]
            role=ROLES.index(t["role"])
            if t["geometry"]:
                guarded=None
            else:
                args=tuple(arrays[key][rep,role]for key in ("packed","colors"))
                shaped=predict(*args,box,noise)
                guarded=evaluate(*args,box,noise,shaped)
            measurements.append({"repeat":rep,"role":t["role"],"previous":t,"checked_exterior":guarded})
        return {"index":source["index"],"input":source["capture"],"trials":measurements}
    began=time.monotonic()
    output=[]
    with ThreadPoolExecutor(3)as pool:
        for i,r in enumerate(pool.map(row,inputs["rows"]),1):
            output.append(r)
            print("replication",i,round(time.monotonic()-began,2),flush=True)
    write_json(ROOT/"nomination.json",{"driver":reference(__file__),"inputs":complete,"rows":output,
              "algorithm":design["fixed_algorithm"],"protocol":inputs["plan"]})


if __name__=="__main__":
    run()
