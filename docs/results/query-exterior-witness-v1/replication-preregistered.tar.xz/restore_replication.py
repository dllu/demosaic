"""Measure the prespecified fallback over the same Corpus 100k parent."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/"query-exterior-witness-v1"))
from deliver import transport
from witness import curvature
from metrics import CORE,SCALE,quality
from run_restore import ARGS,observations,setup_models
from score_panel import luma


def summary(results):
    random=np.random.default_rng(594332)
    groups={}
    for kind in ("occluded","contrast","independent"):
        chosen=[r for r in results if r["kind"]==kind]
        pairs=random.integers(len(chosen),size=(10000,len(chosen)))
        saved={}
        for field in chosen[0]["scores"]["wide"]:
            paired={key:np.array([r["scores"][key][field]for r in chosen])
                    for key in ("baseline","wide","screened")}
            delta=paired["screened"]-paired["wide"]
            saved[field]={"means":{k:float(v.mean())for k,v in paired.items()},
                          "screened_vs_wide_95pct":[float(delta.mean()),*np.quantile(delta[pairs].mean(1),(.025,.975)).tolist()]}
        groups[kind]=saved
    return groups


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    stamp=reference(ROOT/"nomination.json")
    adjudicated=read_json(checked(stamp))
    captures=read_json(checked(adjudicated["inputs"]))
    study=read_json(checked(captures["plan"]))
    assert study["scale_reference"]["sha256"] and study["sideband_ratio"]==1.2
    folder=ROOT/"restored"
    folder.mkdir()
    report=[]
    started=time.monotonic()
    with ieee_fp32():
        net=setup_models({"models":{"Corpus100k":study["base"]}})["Corpus100k"]
        net.set_noise(study["profile"]["shot"],study["profile"]["read"])
        for planned,nominations in zip(captures["rows"],adjudicated["rows"],strict=True):
            i=planned["index"]
            assert i==nominations["index"] and planned["capture"]==nominations["input"]
            material=observations(planned)
            native=[torch.from_numpy(material[k].reshape((-1,*material[k].shape[2:]))).cuda()for k in ARGS]
            native[:2]=[arr.contiguous(memory_format=torch.channels_last)for arr in native[:2]]
            parent=net(*native)
            wide=torch.zeros_like(parent)
            screened=torch.zeros_like(parent)
            for j,t in enumerate(nominations["trials"]):
                args=[r[j:j+1]for r in native]
                base=parent[j:j+1]
                geometry=t["previous"]["geometry"]
                if geometry:
                    wide[j:j+1]=curvature.deliver(args,base,geometry)
                    screened[j:j+1]=wide[j:j+1]
                else:
                    screened[j:j+1]=transport(args,base,t["checked_exterior"],{"screened":"specificity"})["screened"]
            saved={name:value.cpu().numpy().reshape(2,4,3,256,256)
                   for name,value in (("baseline",parent),("wide",wide),("screened",screened))}
            output=folder/f"{i:03d}.npz"
            with output.open("xb")as stream:
                np.savez(stream,**saved)
            base=luma(saved["baseline"],material)
            refreshed={name:base+SCALE*luma(saved[name],material)for name in ("wide","screened")}
            refreshed["baseline"]=base
            exact=luma(material["target"],material)
            scores={name:quality(rgb,base,exact,material["weak_linear_nominal"][CORE],material["region"])
                    for name,rgb in refreshed.items()}
            report.append({"index":i,"kind":study["sources"][i]["layout"]["support"],
                "predictions":reference(output),"scores":scores})
            print(i,round(time.monotonic()-started,1),flush=True)
    write_json(ROOT/"restoration.json",{"driver":reference(__file__),"selection":stamp,
              "checkpoint":study["base"],"numeric":summary(report),"rows":report,
              "scope":"Prespecified 36-photo validation. Exact metrics and native image viewing tracked separately."})


if __name__=="__main__":
    run()
