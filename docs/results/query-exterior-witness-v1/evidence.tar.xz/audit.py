"""Independently verify archive exclusions, held-site projections and restoration arithmetic."""
import json

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import ROOT,anchored,interior,local,project
from chirp_bank import from_outer
from deliver import transport
from metrics import bundle
from run_restore import ARGS,observations


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    restoration,solved,gated,selection,captures,plan=bundle()
    manifest=read_json(ROOT.parent/"scene-full-epoch-v1"/"plan.json")["train_manifest"]
    with checked(manifest).open()as source:
        training={json.loads(line)["id"]for line in source}
    holdout={r["source"]["id"]for r in plan["sources"]}
    assert len(training)==90692 and len(holdout)==24 and not holdout&training
    for f in plan["excluded_plans"]:
        earlier=read_json(checked(f))
        assert not holdout&{r["source"]["id"]for r in earlier.get("sources",earlier.get("heldout_rows",[]))}
    gen=np.random.default_rng(110837)
    box,noise=plan["query_box"],plan["profile"]
    x,y,w,h=box
    s=np.s_[y//2:(y+h)//2,x//2:(x+w)//2]
    with anchored((0,0)):
        unreserved=local.partition()!=0
    results=[]
    for a,b,c in zip(selection["rows"],gated["rows"],solved["rows"],strict=True):
        i=a["index"]
        assert (i,b["index"],c["index"])==(i,i,i)
        for first,selected in zip(a["trials"],b["trials"],strict=True):
            r,k=first["repeat"],0
            observed=selected["guarded"]
            if first["role"]!="present" or first["previous"]["geometry"] or not observed.get("accepted",{}).get("specificity"):
                continue
            record=captures["rows"][i]
            with np.load(checked(record["capture"]),allow_pickle=False)as f:
                raw=f["packed"][r,k].copy()
                colors=f["colors"][r,k].copy()
            section=raw[:,s[0],s[1]]
            data,regions,edge=interior(section,colors,noise)
            assert (edge is None and observed["boundary"] is None) or list(edge)==observed["boundary"]
            altered=raw.copy()
            altered[:,s[0],s[1]]=gen.uniform(.0,.71,section.shape)
            same=from_outer(altered,colors,box,noise,edge)
            assert same["geometry"]==observed["geometry"] and same["representation"]==observed["representation"]
            replaced=section.copy()
            replaced[:,unreserved]=gen.uniform(0.,.71,(4,int(unreserved.sum())))
            another,mask,bound=interior(replaced,colors,noise)
            assert edge==bound
            for side in regions:
                np.testing.assert_array_equal(regions[side],mask[side])
            np.testing.assert_array_equal(data[4],another[4])
            camera=observations(record)
            raw_args=[torch.from_numpy(camera[n][r,k:k+1])for n in ARGS]
            with np.load(checked(c["output"]),allow_pickle=False)as archive:
                p=torch.from_numpy(archive["baseline"][r,k:k+1].copy())
                correction=transport(raw_args,p,observed,{"arm":"specificity"})["arm"].numpy()
                expected=archive["chirp-specific"][r,k:k+1]-archive["wide"][r,k:k+1]
                np.testing.assert_allclose(correction,expected,rtol=0,atol=2e-8)
                assert np.any(expected)
                peak=float(abs(expected-correction).max())
            C=gen.normal(size=(2048,8))
            X=gen.normal(size=(2048,2))
            W=np.exp(gen.normal(size=2048))
            pred=project(X,C,W)
            E=X*np.sqrt(W[:,None])
            V=C*np.sqrt(W[:,None])
            fitted=np.linalg.lstsq(V,E,rcond=None)[0]
            np.testing.assert_allclose(pred,(E-V@fitted)/np.sqrt(W[:,None]),rtol=1e-10,atol=1e-10)
            np.testing.assert_allclose((C.T*W)@pred,0,rtol=0,atol=3e-10)
            results.append({"index":i,"repeat":r,"whole_query_redraw_leaves_exterior_geometry_identical":True,
                            "non_Q0_redraw_leaves_nuisance_guide_and_variance_identical":True,"CPU_GPU_max_abs":peak})
            break
        if len(results)==4:
            break
    assert len(results)==4
    metric=reference(ROOT/"scores.json")
    report=read_json(checked(metric))
    assert report["restoration"]==restoration
    assert all(row["quality"]["chirp-specific"]["flat_added_RMS"]==0 for row in report["quality"])
    assert report["discovery"]["fresh"]["counts"]["occluded/present"]["chirp-specificity-new_correct_geometry"]==11
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"training_manifest":manifest,
              "training_count":len(training),"overlap":0,"restoration":restoration,"score":metric,
              "checks":results,"weighted_projection_against_independent_lstsq":True,
              "scope":"Exterior fit audit holds the Q0-derived edge fixed. Q1-to-Q3 replacement preserves Q0 raw noise weighting. CPU/CUDA delivery is judged at fixed parent and choices."})
    print(len(results),max(r["CPU_GPU_max_abs"]for r in results),flush=True)


if __name__=="__main__":
    run()
