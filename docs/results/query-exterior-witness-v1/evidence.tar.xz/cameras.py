"""Review both GFX families using the verified saved wide output and native coordinates."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.reporting import display_crop
from deliver import transport
from metrics import SCALE,ROOT
from run_restore import ARGS

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

LABELS={"wide":"Wide curved backup","bank-pooled":"Exterior tile bank","chirp-pooled":"Bent phase, pooled",
        "chirp-specific":"Neighbor-frequency check"}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    last=reference(ROOT.parent/"query-contour-support-v1"/"standing/manifest.json")
    before=read_json(checked(last))
    after=reference(ROOT/"specificity-standing.json")
    guard=read_json(checked(after))
    bank_stamp=reference(ROOT/"bank-standing.json")
    narrowed=read_json(checked(bank_stamp))
    deep={r["id"]:r for r in guard["rows"]}
    bank={r["id"]:r for r in narrowed["rows"]}
    directory=ROOT/"standing"
    directory.mkdir()
    saved=[]
    with ieee_fp32():
        for row in before["rows"]:
            key=row["id"]
            state=deep[key]
            binding=state["previous"]
            assert binding["raw"]==row["input"] and binding["window"]==row["query_box"]
            x,y,w,h=binding["window"]
            window=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
            with np.load(checked(binding["raw"]),allow_pickle=False)as f:
                data=[torch.from_numpy(f[k][window].copy()if k in ARGS[:2]else f[k])for k in ARGS]
            with np.load(checked(row["output"]),allow_pickle=False)as f:
                parent=torch.from_numpy(f["parent"].copy())
                baseline=torch.from_numpy(f["wide"].copy())
            views={"wide":baseline}
            for method,r,rule in (("bank-pooled",bank[key]["banked"],"exterior-pooled"),
                                  ("chirp-pooled",state["guarded"],"exterior-pooled"),
                                  ("chirp-specific",state["guarded"],"specificity")):
                correction=torch.zeros_like(parent)if binding["geometry"]else transport(data,parent,r,{method:rule})[method]
                views[method]=baseline+SCALE*correction
            a,b,rw,rh=row["ROI"]["ROI_xywh"]
            roi=(a-x,b-y,rw,rh)
            default=["ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA"]
            with Image.open(checked(row["image"]))as f:
                prior=np.asarray(f.convert("RGB"))
            panes={p["name"]:prior[my:my+mh,mx:mx+mw]for p in row["panels"]for mx,my,mw,mh in (p["png_xywh"],)}
            items=[(name,panes[name])for name in default if name in panes]
            camera_map={}
            rx,ry,rw,rh=roi
            sl=np.s_[...,ry:ry+rh,rx:rx+rw]
            for name,rgb in views.items():
                linear=rgb[sl].numpy().astype(float)
                original=baseline[sl].numpy().astype(float)
                v=np.rint(display_crop(rgb,*data[-2:],roi,exposure=row["display_exposure"])*255).astype(np.uint8)
                if name=="wide":
                    np.testing.assert_array_equal(v,panes["Wide curved backup"])
                items.append((LABELS[name],v))
                diff=linear-original
                camera_map[name]={"RGB_RMS_to_wide_DN16":float(65535*np.sqrt(np.mean(diff**2))),
                                  "changed_components_in_RGB8":int((v!=panes["Wide curved backup"]).sum())}
            items.extend((k,panes[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in panes)
            card=native_png(directory/(key+".png"),items)
            saved.append(row|card|{"camera_metrics":camera_map,"score_proposal":state["guarded"],
                                  "inherited_arrays":row["output"]})
            print(key,{k:round(v["RGB_RMS_to_wide_DN16"],3)for k,v in camera_map.items()},flush=True)
    assert len(saved)==8
    write_json(directory/"manifest.json",{"driver":reference(__file__),"source":last,
              "phase_screen":after,"tile_bank_screen":bank_stamp,"delivery_scale":SCALE,
              "checkpoint":before["checkpoint"],"rows":saved})


if __name__=="__main__":
    main()
