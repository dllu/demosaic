"""Replay exterior-only phase transport before reading exact target pixels."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import MODES,PREVIOUS,ROOT,THRESHOLD,candidate,exact_model
from forecasts import nominate
from support import ROOT as PRIOR_SUPPORT

ROLES=("present","outside-only","strong-only","quiet-query")


def rows(job):
    row,layout,plan,base=job
    with np.load(checked(row["capture"]),allow_pickle=False)as f:
        captures={k:f[k]for k in ("packed","colors")}
    box,noise=plan["query_box"],plan["profile"]
    stock=base or nominate((row,None))
    geometry,phase=exact_model(layout)
    trials=[]
    for rep in range(2):
        for r,role in enumerate(ROLES):
            prior=stock["trials"][rep*4+r]
            assert (prior["repeat"],prior["role"])==(rep,role)
            args=(captures["packed"][rep,r],captures["colors"][rep,r],box,noise)
            observed=candidate(*args)
            oracle=candidate(*args,shape=geometry,phase=phase)
            trials.append({"repeat":rep,"role":role,"exterior":observed,"exact_phase_geometry":oracle,"previous":prior})
    return {"index":row["index"],"capture":row["capture"],"trials":trials}


def run(mode):
    folder=PREVIOUS if mode=="calibration" else ROOT
    observations=reference(folder/"fields.json")
    stage=read_json(checked(observations))
    plan=read_json(checked(stage["plan"]))
    prior=reference(PREVIOUS/"forecasts.json")if mode=="calibration" else None
    forecast=read_json(checked(prior))if prior else None
    by_index={r["index"]:r for r in forecast["rows"]}if prior else {}
    outputs=[]
    start=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        tasks=((r,plan["sources"][r["index"]]["layout"],plan,by_index.get(r["index"]))for r in stage["rows"])
        for i,one in enumerate(pool.map(rows,tasks),1):
            outputs.append(one)
            print(mode,i,round(time.monotonic()-start,1),flush=True)
    write_json(ROOT/f"selection-{mode}.json",{"driver":reference(__file__),"algorithm":reference(ROOT/"witness.py"),
        "captures":observations,"prior_forecasts":prior,"witness_cutoff":THRESHOLD,"rows":outputs})


def real():
    record=reference(PRIOR_SUPPORT/"forecasts-standing.json")
    data=read_json(checked(record))
    old=read_json(PREVIOUS/"standing/manifest.json")
    cameras={r["id"]:r for r in old["rows"]}
    rows=[]
    for here in data["rows"]:
        seen=cameras[here["id"]]
        assert seen["input"]==here["raw"]
        with np.load(checked(here["raw"]),allow_pickle=False)as f:
            args=(f["packed"][0],f["colors"][0])
        result=candidate(*args,here["window"],seen["shot_read"])
        rows.append({"id":here["id"],"exterior":result,"previous":here})
        accepted=result.get("accepted")
        print(here["id"],accepted,flush=True)
    write_json(ROOT/"selection-standing.json",{"driver":reference(__file__),"algorithm":reference(ROOT/"witness.py"),
        "prior_forecasts":record,"witness_cutoff":THRESHOLD,"rows":rows})


if __name__=="__main__":
    job=sys.argv[1]
    real() if job=="standing" else run(job)
