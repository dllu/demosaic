"""Run the same frozen Corpus 100k parent for the fresh holdout photos."""
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from witness import ROOT
from deliver import VARIANTS,restore
from run_restore import ARGS,observations,setup_models


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    bank=reference(ROOT/"bank-fresh.json")
    alternative=read_json(checked(bank))
    chosen=read_json(checked(alternative["source"]))
    captures=read_json(checked(chosen["captures"]))
    plan=read_json(checked(captures["plan"]))
    path=ROOT/"restored"
    path.mkdir()
    checkpoint=plan["base"]
    saved=[]
    start=time.monotonic()
    with ieee_fp32():
        net=setup_models({"models":{"Corpus100k":checkpoint}})["Corpus100k"]
        net.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for row,predict in zip(chosen["rows"],alternative["rows"],strict=True):
            i=row["index"]
            assert predict["capture"]==row["capture"]==captures["rows"][i]["capture"]
            obs=observations(captures["rows"][i])
            args=[torch.from_numpy(obs[k].reshape((-1,*obs[k].shape[2:]))).cuda()for k in ARGS]
            args[:2]=[t.contiguous(memory_format=torch.channels_last)for t in args[:2]]
            base=net(*args)
            values={k:torch.zeros_like(base)for k in ("wide",*VARIANTS)}
            for j,(older,now) in enumerate(zip(row["trials"],predict["trials"],strict=True)):
                assert (older["repeat"],older["role"])==(now["repeat"],now["role"])
                pair=older["previous"]["geometry"]
                arr=restore([a[j:j+1]for a in args],base[j:j+1],pair,older["exterior"],now["banked"])
                for k,v in arr.items():
                    values[k][j:j+1]=v
            output=path/f"{i:03d}.npz"
            with output.open("xb")as stream:
                np.savez(stream,**{k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in (values|{"baseline":base}).items()})
            saved.append({"index":i,"output":reference(output)})
            print(i,round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/"restoration.json",{"source":bank,"driver":reference(__file__),"delivery":reference(ROOT/"deliver.py"),
               "checkpoint":checkpoint,"rows":saved,"seconds":time.monotonic()-start})


if __name__=="__main__":
    run()
