"""Measure weak reconstruction and false-detail effects at the fixed display scale."""
from collections import Counter
import importlib.util

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import MODES,ROOT
from run_restore import observations
from score_panel import luma

METHODS=("baseline","wide","top-pooled","bank-quarter","bank-pooled","chirp-quarter","chirp-pooled",
         "chirp-spatial","chirp-specific")
CORE=np.s_[64:192,64:192]
SCALE=.6318481533720487


def bundle():
    restore=reference(ROOT/"restoration-specificity.json")
    saved=read_json(checked(restore))
    edge=read_json(checked(saved["spatial"]))
    chirp=read_json(checked(saved["source"]))
    chosen=read_json(checked(chirp["source"]))
    capture=read_json(checked(chosen["captures"]))
    plan=read_json(checked(capture["plan"]))
    return restore,saved,edge,chosen,capture,plan


def rms(value):
    return float(np.sqrt(np.mean(value.reshape(len(value),-1)**2,axis=-1)).mean()*65535)


def projection(value,truth):
    return value@truth/(truth@truth)*100


def quality(pred,baseline,gold,template,region):
    intact,gap=(region[CORE]==1),(region[CORE]==0)
    signal=gold[0,0]-gold[0,1]
    estimation=pred[:,0]-pred[:,1]
    now=(pred-baseline)
    found={"intact_weak_response":float(projection(estimation[:,intact],signal[intact]).mean()),
           "intact_increment_RMS_DN16":rms((estimation-signal)[:,intact]),
           "strong_only_added_RMS":rms(now[:,2]),
           "strong_only_absolute_RMS":rms((pred-gold)[:,2]),
           "flat_added_RMS":rms(now[:,3]),
           "outside_only_added_RMS":rms(now[:,1])}
    if gap.any():
        assert np.all(signal[gap]==0)
        found.update({"spurious_gap_response":float(abs(projection(estimation[:,gap],template[gap])).mean()),
                      "gap_absolute_RMS":rms((pred-gold)[:,0][:,gap]),
                      "gap_added_RMS":rms(now[:,0][:,gap])})
    return found


def summarize(rows):
    comps=(("chirp-specific","wide"),("chirp-specific","chirp-pooled"),("chirp-pooled","wide"),
           ("chirp-quarter","wide"),("chirp-spatial","wide"),("chirp-pooled","chirp-quarter"))
    ix=np.random.default_rng(829113).integers(len(rows),size=(10000,len(rows)))
    table={}
    for metric in rows[0]["quality"]["wide"]:
        by={k:np.array([r["quality"][k][metric]for r in rows])for k in METHODS}
        means={k:float(a.mean())for k,a in by.items()}
        changes={}
        for a,b in comps:
            delta=by[a]-by[b]
            changes[a+"-vs-"+b]=[float(delta.mean()),*np.quantile(delta[ix].mean(1),(.025,.975)).tolist()]
        table[metric]={"means":means,"paired_95pct":changes}
    return table


def match(geometry,layout):
    targets=np.array([layout[k+"_frequency_xy"]for k in ("strong","weak")])
    points=np.array(geometry)[:,:2]
    distance=np.minimum(np.linalg.norm(points[:,None]-targets,axis=-1),np.linalg.norm(points[:,None]+targets,axis=-1))
    options=[(distance[0,0]+distance[1,1],max(distance[0,0],distance[1,1]),1),
             (distance[0,1]+distance[1,0],max(distance[0,1],distance[1,0]),0)]
    return min(options)[-1]if min(options)[1] <=3/256 else None


def detection(stage):
    sources={k:reference(ROOT/f"{k}-{stage}.json")for k in ("selection","bank","chirp","specificity")}
    initial,band,curvy,guard=[read_json(checked(sources[k]))for k in sources]
    fields=read_json(checked(initial["captures"]))
    plan=read_json(checked(fields["plan"]))
    counts={}
    for old,b,c,g in zip(initial["rows"],band["rows"],curvy["rows"],guard["rows"],strict=True):
        index=old["index"]
        true=plan["sources"][index]["layout"]
        name=true["support"]
        for t,a,o,n in zip(old["trials"],b["trials"],c["trials"],g["trials"],strict=True):
            key=name+"/"+t["role"]
            acc=counts.setdefault(key,Counter())
            existing=t["previous"]["geometry"]
            acc["draws"]+=1
            acc["previous_pair"]+=bool(existing)
            if existing:
                acc["previous_correct_pair"]+=match(existing,true)is not None
            for label,pred in (("top",t["exterior"]),("bank",a["banked"]),("chirp",n["guarded"]),
                               ("exact",t["exact_phase_geometry"]),("known_geometry",o["exact_geometry_measured_phase"])):
                if not pred["proposed"]:
                    continue
                acc[label+"-proposed"]+=1
                exact=match(pred["geometry"],true)
                acc[label+"-correct_pair"]+=exact is not None
                for k,areas in pred["accepted"].items():
                    if areas:
                        acc[label+"-"+k]+=1
                        if not existing:
                            acc[label+"-"+k+"-new"]+=1
                            acc[label+"-"+k+"-new_correct_geometry"]+=exact==pred["weaker"]
    return {"sources":sources,"counts":{k:dict(v)for k,v in counts.items()}}


def main():
    restore,saved,edge,chosen,capture,plan=bundle()
    rows=[]
    for item,material in zip(saved["rows"],capture["rows"],strict=True):
        i=item["index"]
        assert i==material["index"]
        camera=observations(material)
        with np.load(checked(item["output"]),allow_pickle=False)as f:
            base=luma(f["baseline"],camera)
            styles={k:base+SCALE*luma(f[k],camera)for k in METHODS if k!="baseline"}
        styles["baseline"]=base
        exact=luma(camera["target"],camera)
        measurements={key:quality(value,base,exact,camera["weak_linear_nominal"][CORE],camera["region"])
                      for key,value in styles.items()}
        rows.append({"index":i,"kind":plan["sources"][i]["layout"]["support"],"quality":measurements})
    groups={}
    for name in ("occluded","contrast","independent"):
        groups[name]=summarize([r for r in rows if r["kind"]==name])
    scale_from=reference(ROOT.parent/"query-phase-support-v1"/"scores.json")
    assert read_json(checked(scale_from))["scale"]==SCALE
    write_json(ROOT/"scores.json",{"driver":reference(__file__),"restoration":restore,"scale":SCALE,
              "scale_from":scale_from,"groups":groups,"quality":rows,
              "discovery":{name:detection(name)for name in ("calibration","fresh")}})


def native():
    torch.set_num_threads(2)
    evidence=reference(ROOT/"scores.json")
    restore,saved,edge,old,capture,plan=bundle()
    cases=[]
    for prior,record in zip(old["rows"],edge["rows"],strict=True):
        index=record["index"]
        layout=plan["sources"][index]["layout"]
        if layout["support"]!="occluded":
            continue
        for a,b in zip(prior["trials"],record["trials"],strict=True):
            if a["role"]=="present" and not a["previous"]["geometry"] and b["guarded"].get("accepted",{}).get("specificity"):
                cases.append((index,a["repeat"]))
                break
        if len(cases)==2:
            break
    assert len(cases)==2
    folder=ROOT/"native"
    folder.mkdir(exist_ok=True)
    output=[]
    for i,rep in cases:
        obs=capture["rows"][i]
        row=plan["sources"][i]
        arrays=observations(obs)
        with np.load(checked(saved["rows"][i]["output"]),allow_pickle=False)as f:
            parent=f["baseline"][rep]
            rgb={k:parent+SCALE*f[k][rep]for k in ("wide","chirp-quarter","chirp-pooled","chirp-specific")}
        rgb.update({"noisy":malvar(torch.from_numpy(arrays["packed"][rep]),torch.from_numpy(arrays["colors"][rep])).numpy(),
                    "target":arrays["target"][rep]})
        wb={k:arrays[k][rep]for k in ("wb","matrix")}
        views={k:np.rint(display(v,wb,exposure=2.)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
               for k,v in rgb.items()}
        for card,r,names in (
                ("triplet",0,("noisy","chirp-specific","target")),
                ("contrast",0,("wide","chirp-quarter","chirp-pooled","chirp-specific","target")),
                ("outside",1,("wide","chirp-quarter","chirp-pooled","chirp-specific","target")),
                ("flat",3,("wide","chirp-quarter","chirp-pooled","chirp-specific","target"))):
            dest=folder/f"{i:03d}-{card}.png"
            Image.fromarray(np.concatenate([views[k][r]for k in names],axis=1)).save(dest,optimize=True)
            output.append({"image":reference(dest),"source":row["source"],"native_xywh":[48,48,160,160],
                "query_xywh":plan["query_box"],"source_box":row["box"],"index":i,"repeat":rep,"role":card,
                "panes":names,"profile":plan["profile"],"display_exposure":2.,"CFA":row["camera"]["pattern"],
                "capture":obs,"restoration":saved["rows"][i]["output"]})
    write_json(folder/"manifest.json",{"driver":reference(__file__),"scores":evidence,"restoration":restore,
              "checkpoint":saved["checkpoint"],"selection":"The first two different occluded fields with a present draw accepted by the specificity check and missed by the original search.",
              "rows":output})


if __name__=="__main__":
    main()
    native()
