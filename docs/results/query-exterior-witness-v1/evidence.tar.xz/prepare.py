"""Create disjoint images for exterior phase and pooled Bayer validation."""
from collections import Counter
import hashlib
import importlib.util
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"query-contour-support-v1"
spec=importlib.util.spec_from_file_location("contour_fixture",OLD/"prepare.py")
old=importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
SEED=746362109512


def run():
    prior=reference(OLD/"plan.json")
    bindings=[]
    lookup=prior
    forbidden=set()
    while lookup:
        record=read_json(checked(lookup))
        bindings.append(lookup)
        forbidden.update(row["source"]["id"]for row in record.get("sources",record.get("heldout_rows",[])))
        lookup=next((record[k]for k in ("previous","curve_reference","preceding","comparison","prior","exclusion")
                     if k in record),None)
    repeat=read_json(ROOT.parent/"paired-repeat-stability-v2"/"evaluation-plan.json")
    forbidden.update(r["source"]["id"]for r in repeat["rows"])
    template=read_json(checked(prior))
    cohort=read_json(checked(template["cohort"]))
    ids=[r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
         and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in forbidden]
    ordered=sorted(ids,key=lambda s:hashlib.sha256(f"{SEED}:{s['id']}".encode()).hexdigest())
    builder=old.before.geometry.fields
    builder.ROOT,builder.SEED,builder.clean_targets=ROOT,SEED,old.targets
    fields=[]
    for i,s in enumerate(ordered[:24]):
        box,=scene_crop_boxes(s["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"scene"))
        recipe=builder.draw(i)
        kind=("occluded","contrast","occluded","independent")[i%4]
        k=(-1)**(i//4)*(.000023+i*.0000011) if (i//4)%3 else 0.
        recipe.update({"support":kind,"step":True,"shape":"ellipse","contrast_step":kind=="contrast",
                       "weak_tangential_curvature_cycles_per_px2":k,
                       "strong_tangential_curvature_cycles_per_px2":-.65*k})
        fields.append(builder.row_for(s,i,SEED)|{"box":box,"layout":recipe})
    assert Counter(r["layout"]["support"]for r in fields)=={"occluded":12,"contrast":6,"independent":6}
    write_json(ROOT/"plan.json",{
        **{k:template[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "previous":prior,"excluded_plans":bindings,"driver":reference(__file__),"seed":SEED,
        "fit_indices":[],"test_indices":list(range(24)),"sources":fields,
        "scope":"24 held-out ISO6400 photos. Twelve partial occlusions at visible steps. Six continuous controls and six unrelated elliptical gaps. Two redraws and all four controls."})
    builder.construct()


if __name__=="__main__":
    run()
