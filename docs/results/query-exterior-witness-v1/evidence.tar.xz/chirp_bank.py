"""Compensate bend when nominating weak frequencies in the exterior RAW ring."""
from functools import lru_cache
from itertools import combinations
import math

import numpy as np
from scipy.ndimage import gaussian_filter,maximum_filter,uniform_filter

from witness import MODES,THRESHOLD,curvature,evidence,interior,outer_samples
from banked import BANDS

CURVATURE=np.array([0.,2.5e-5,-2.5e-5,5e-5,-5e-5,7.5e-5,-7.5e-5])


@lru_cache(maxsize=3)
def spectral_grid(n):
    frequency=np.fft.fftfreq(n,d=2.)
    fy,fx=np.meshgrid(frequency,frequency,indexing="ij")
    radius=np.hypot(fx,fy)
    angle=np.arctan2(fy,fx)%np.pi
    sector=np.rint(angle*12/np.pi).astype(int)%12
    half=(fx>0)|((fx==0)&(fy>=0))
    return fy,fx,radius,sector,half


def spectrum(raw,colors,box,noise,boundary):
    yy,xx=np.indices(raw.shape[-2:])
    cx,cy=box[0]+127.5,box[1]+127.5
    x,y=2*xx+.5-cx,2*yy+.5-cy
    radius=np.maximum(abs(x),abs(y))
    use=(radius>=140)&(radius<=241)
    taper=np.sin(np.pi*((radius-140)/101).clip(0,1))**.85
    if boundary:
        angle,shift,_=boundary
        side=x*np.cos(angle)+y*np.sin(angle)-shift
        use &= np.abs(side)>15
    coarse=raw[np.flatnonzero(colors==1)].astype(float).mean(0)
    low=gaussian_filter(np.where(use,coarse,0.),2.8)
    support=gaussian_filter(use.astype(float),2.8).clip(min=1e-9)
    mean=low/support
    variance=(noise["shot"]*mean.clip(min=0)+noise["read"]).clip(min=2e-11)*.5
    weight=use*taper/np.sqrt(variance)
    scene=(coarse-mean)*weight
    fft_size=256
    if min(scene.shape)<fft_size:
        # Truncated camera contexts still use the frozen grid, with zero padding.
        pass
    if max(scene.shape)>fft_size:
        left=max(0,(int(cx)//2-128))
        top=max(0,(int(cy)//2-128))
        sl=np.s_[top:top+fft_size,left:left+fft_size]
        scene,x,y,radius,taper=scene[sl],x[sl],y[sl],radius[sl],taper[sl]
    if np.count_nonzero(scene)<3500:
        return []
    fy,fx,radial,sector,half=spectral_grid(fft_size)
    pooled=np.zeros_like(fy)
    winner=np.zeros_like(fy)
    noise_band=np.sum(taper[np.abs(scene)>0]**2)
    for direction in range(12):
        theta=direction*np.pi/12
        tangent=(-x*np.sin(theta)+y*np.cos(theta))
        unbending=-1j*np.pi*tangent*tangent
        valid=(sector==direction)&half
        for bend in CURVATURE:
            demodulated=scene*np.exp(bend*unbending)
            fft=np.fft.fft2(demodulated,s=(fft_size,fft_size),axes=(-2,-1))
            value=np.abs(fft)**2/max(noise_band,1e-12)
            # The broad local spectral floor reduces response to leaking structure.
            floor=uniform_filter(value,size=15,mode="wrap").clip(min=1)
            prominence=value/np.sqrt(floor)
            select=valid&(prominence>pooled)
            pooled[select]=prominence[select]
            winner[select]=bend
    peaks=[]
    local_max=pooled==maximum_filter(pooled,5,mode="wrap")
    for low,high in zip(BANDS[:-1],BANDS[1:],strict=True):
        valid=local_max&(radial>=low)&(radial<high)&(pooled>=8.)
        points=np.argwhere(valid)[np.argsort(pooled[valid],kind="stable")[::-1]][:3]
        peaks.extend((float(fx[a,b]),float(fy[a,b]),float(winner[a,b]),float(pooled[a,b]))for a,b in points)
    return peaks


def from_outer(raw,colors,box,noise,boundary):
    peaks=spectrum(raw,colors,box,noise,boundary)
    if len(peaks)<2:
        return None
    fit,held,_=outer_samples(raw,colors,box,noise)
    if boundary:
        a,d,_=boundary
        def trim(data):
            valid=np.abs(data[0]*math.cos(a)+data[1]*math.sin(a)-d)>13
            return tuple(x[valid]for x in data)
        fit,held=map(trim,(fit,held))
    x,y,w,signal=fit
    shapes=np.array(peaks)[:,:3]
    terms=curvature.wave_columns(x,y,shapes)
    products=(terms.T*w)@terms
    direction=(terms.T*w)@signal
    proposals=[]
    for i,j in combinations(range(len(shapes)),2):
        a,b=shapes[[i,j],:2]
        separate=abs(a[0]*b[1]-a[1]*b[0])>.35*np.linalg.norm(a)*np.linalg.norm(b)
        if not separate:
            continue
        ix=[2*i,2*i+1,2*j,2*j+1]
        normal=products[np.ix_(ix,ix)]
        vec=direction[ix]
        projected=np.linalg.solve(normal,vec)
        proposals.append((float(projected@vec),i,j))
    options=[]
    for _,i,j in sorted(proposals,reverse=True)[:5]:
        estimate=curvature.refine(fit,shapes[[i,j]],(0,1),True)
        scores=curvature.directional_support(fit,held,estimate)
        if min(scores)>=3.25:
            options.append((sum(scores),estimate,scores))
    if not options:
        return None
    _,shape,scores=max(options,key=lambda v:v[0])
    beta,_,_=curvature.fit(fit,shape)
    beta=beta.reshape(2,2)
    return {"geometry":shape.tolist(),"representation":beta.tolist(),"weaker":int(np.argmin((beta**2).sum(1))),
            "exterior_conditional_scores":scores,"seed_bank":peaks}


def predict(packed,colors,box,noise):
    x,y,w,h=box
    local=packed[:,y//2:(y+h)//2,x//2:(x+w)//2]
    data,regions,boundary=interior(local,colors,noise)
    chosen=from_outer(packed,colors,box,noise,boundary)
    if chosen is None:
        return {"proposed":False,"boundary":boundary}
    match=evidence(data,regions,chosen["geometry"],chosen["representation"])
    accepted={k:[name for name,r in match.items()if min(r["scores"][k])>=THRESHOLD]for k in MODES}
    return chosen|{"proposed":True,"boundary":boundary,"support":match,"accepted":accepted}
