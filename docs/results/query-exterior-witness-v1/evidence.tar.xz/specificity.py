"""Compare the proposed weak phase with phase-free neighboring frequencies."""
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import ROOT,curvature,design_terms,interior,project

OFFSET=.016
MIN_EXCESS=1.
MIN_RATIO=1.20


def evaluate(packed,colors,box,noise,choice):
    if not choice.get("accepted",{}).get("exterior-pooled"):
        return choice|{"specificity": {}}
    x,y,w,h=box
    inputs,regions,bound=interior(packed[:,y//2:(y+h)//2,x//2:(x+w)//2],colors,noise)
    assert (bound is None and choice["boundary"] is None) or tuple(choice["boundary"])==bound
    geometry=choice["geometry"]
    background,model=design_terms(inputs,geometry)
    x,y,_,raw,var,fold=inputs
    weak=choice["weaker"]
    direction=np.asarray(geometry[weak][:2]); direction/=np.linalg.norm(direction)
    shifted=[]
    for d in (-OFFSET,OFFSET):
        new=np.r_[np.array(geometry[weak][:2])+d*direction,geometry[weak][2]]
        shifted.append(curvature.wave_columns(x,y,[new]))
    strong=1-weak
    nuisance=np.column_stack((background,model[:,2*strong:2*strong+2]))
    screened=[]; diagnostics={}
    for k in choice["accepted"]["exterior-pooled"]:
        chosen=regions[k]&(fold>0)
        wi=1/var[chosen]
        N=nuisance[chosen]
        active=choice["support"][k]["scores"]["exterior-pooled"][weak]
        others=[]
        for trial in shifted:
            directions=project(trial[chosen],N,wi)
            gram=(directions.T*wi)@directions
            innovation=(directions.T*wi)@raw[chosen]
            both=np.linalg.solve(gram,innovation)
            others.append(float(np.sqrt(max(0,both@innovation))))
        neighbor=max(others)
        if active>=neighbor+MIN_EXCESS and active>=neighbor*MIN_RATIO:
            screened.append(k)
        diagnostics[k]={"active":active,"sidebands":others}
    return choice|{"specificity":diagnostics,"accepted":choice["accepted"]|{"specificity":screened}}


def run(mode):
    source=reference(ROOT/f"spatial-{mode}.json")
    candidates=read_json(checked(source))
    outputs=[]
    if mode=="standing":
        prior=read_json(ROOT.parent/"query-contour-support-v1"/"standing/manifest.json")
        lookup={case["id"]:case for case in prior["rows"]}
        for row in candidates["rows"]:
            saved=row["previous"]
            with np.load(checked(saved["raw"]),allow_pickle=False)as f:
                test=evaluate(f["packed"][0],f["colors"][0],saved["window"],lookup[row["id"]]["shot_read"],row["guarded"])
            outputs.append({"id":row["id"],"previous":saved,"guarded":test})
            print(row["id"],test.get("accepted",{}).get("specificity"),test["specificity"],flush=True)
    else:
        upstream=read_json(checked(candidates["source"]))
        start=read_json(checked(upstream["source"]))
        prepared=read_json(checked(start["captures"]))
        plan=read_json(checked(prepared["plan"]))
        for row in candidates["rows"]:
            cases=[]
            with np.load(checked(row["capture"]),allow_pickle=False)as f:
                inputs={k:f[k]for k in ("packed","colors")}
            for j,t in enumerate(row["trials"]):
                r,i=divmod(j,4)
                result=evaluate(inputs["packed"][r,i],inputs["colors"][r,i],plan["query_box"],plan["profile"],t["guarded"])
                cases.append({"repeat":r,"role":t["role"],"guarded":result})
            outputs.append({"index":row["index"],"capture":row["capture"],"trials":cases})
            print(mode,row["index"],flush=True)
    write_json(ROOT/f"specificity-{mode}.json",{"driver":reference(__file__),"source":source,
            "offset_cycles_per_pixel":OFFSET,"absolute_excess":MIN_EXCESS,"minimum_ratio":MIN_RATIO,"rows":outputs})


if __name__=="__main__":
    run(sys.argv[1])
