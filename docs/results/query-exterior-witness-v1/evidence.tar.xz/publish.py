"""Publish measured reconstruction, approved geometry and native crop provenance."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
OUTPUT=Path("docs/results/query-exterior-witness-v1")
IMAGES=Path("docs/images/query-exterior-witness-v1")


def run():
    score=reference(ROOT/"scores.json")
    data=read_json(checked(score))
    check=read_json(ROOT/"audit.json")
    assert check["score"]==score
    exact=read_json(ROOT/"native/manifest.json")
    camera=read_json(ROOT/"standing/manifest.json")
    assert exact["scores"]==score and exact["checkpoint"]==camera["checkpoint"]
    sets={"exact":exact,"standing":camera}
    for name,group in sets.items():
        for row in group["rows"]:
            original=checked(row["image"])
            dest=IMAGES/name/original.name
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(original,dest)
            sha=row["image"]["sha256"]
            assert sha==reference(dest)["sha256"]
            row["image"]={"path":str(dest),"sha256":sha}
            if name=="exact":
                boxes=[(160*i,0,160,160)for i in range(len(row["panes"]))]
                if row["role"]=="flat":
                    note="Every output stays smooth in the exact-flat query."
                elif row["role"]=="outside":
                    note="The foreground boundary and stronger stripe remain; the neighbor-frequency check matches the wide path."
                elif row["index"]==0:
                    note="Faint extra crossings appear in the darker foliage on the supported side, with finer texture in the exact target."
                else:
                    note="The dominant wall pattern and diagonal cut survive. The weak crossing family is more visible on the retained side and clearer in the target."
            else:
                boxes=[pane["png_xywh"]for pane in row["panels"]]
                if "building" in row["id"]:
                    note="The unconstrained pooled candidate adds faint horizontal modulation. The neighboring-frequency rule restores the wide pixels."
                elif "overcast" in row["id"]:
                    note="The sky stays smooth in all views."
                elif "foliage" in row["id"]:
                    note="The wide foliage is retained, with soft fine boundaries."
                elif "chain-link" in row["id"]:
                    note="Both coarse directions and their knots remain visible."
                elif row["id"].endswith("mesh-right"):
                    note="The standing right cab retains both weak directions with soft, incomplete crossings under the two profiles."
                else:
                    note="The left-cab restoration remains at the parent, and fine crossings in the independent references remain faint."
            row["actual_viewing"]=note
            if name=="standing":
                assert row["camera_metrics"]["chirp-specific"]["RGB_RMS_to_wide_DN16"]==0
            with Image.open(dest)as f:
                assert all(w==h==160 and x+w<=f.width and y+h<=f.height for x,y,w,h in boxes)
                f.verify()
    assert all(len(group["rows"])==8 for group in sets.values())
    binding=IMAGES/"manifest.json"
    write_json(binding,sets|{"actual_native_viewing_complete":True})
    OUTPUT.mkdir(exist_ok=True)
    archive=OUTPUT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as dest:
        for pattern in ("*.py","*.json","*.log","native/manifest.json","standing/manifest.json"):
            for source in sorted(ROOT.glob(pattern)):
                dest.add(source,arcname=source.relative_to(ROOT))
    write_json(OUTPUT/"publication.json",{
        "experiment":"query-exterior-witness-v1","training_performed":False,"numerical_evaluation_complete":True,
        "actual_native_viewing_complete":True,"parent":exact["checkpoint"],"gain_scale":data["scale"],
        "groups":data["groups"],"phase_discovery":data["discovery"],"verification":check,
        "camera_differences":{r["id"]:r["camera_metrics"]for r in camera["rows"]},
        "manifest":reference(binding),"archive":reference(archive),
        "scope":"24 new photo sources with phase-controlled noise and both GFX families. The last safety screens are retrospective variants on the same panel. No comparable full427 or measured-camera panel scores.",
    })


if __name__=="__main__":
    run()
