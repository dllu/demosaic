"""Rank band-stratified exterior candidates after excluding the visible step."""
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.ndimage import maximum_filter

from witness import MODES,THRESHOLD,curvature,evidence,interior,outer_samples
from discover import boxes,grids,intersects,tile_scores

BANDS=(.042,.074,.107,.142,.178,.216)


def bank(values,tiles):
    fy,fx,valid,*_=grids()
    widened=[maximum_filter(v,5,mode="wrap")for v in values]
    pooled=np.zeros_like(values[0])
    for i,j in combinations(range(len(values)),2):
        if intersects(tiles[i],tiles[j]):
            continue
        support=np.maximum(np.minimum(values[i],widened[j]),np.minimum(widened[i],values[j]))
        pooled=np.maximum(pooled,support)
    peaks=[]
    radius=np.hypot(fx,fy)
    maxima=pooled==maximum_filter(pooled,5,mode="wrap")
    for low,high in zip(BANDS[:-1],BANDS[1:],strict=True):
        allowed=valid&maxima&(radius>=low)&(radius<high)&(pooled>=.90)
        ranked=np.argwhere(allowed)[np.argsort(pooled[allowed],kind="stable")[::-1]][:3]
        peaks.extend({"frequency_xy":[float(fx[a,b]),float(fy[a,b])],"exterior_salience":float(pooled[a,b])}
                     for a,b in ranked)
    return peaks


def from_outer(packed,colors,box,noise,boundary):
    x0,y0,w,h=box
    height,width=(2*x for x in packed.shape[-2:])
    tiles=[t for t in boxes(x0,y0)if t[0]>=0 and t[1]>=0 and t[0]+t[2]<=width and t[1]+t[3]<=height]
    if boundary is not None:
        a,d,_=boundary
        f=np.array([np.cos(a),np.sin(a)])
        center=np.array([x0+127.5,y0+127.5])
        squeezed=[]
        for x,y,w,h in tiles:
            corners=np.array([(x,y),(x+w,y),(x,y+h),(x+w,y+h)])
            signed=(corners-center)@f-d
            if signed.max() < -8. or signed.min() > 8.:
                squeezed.append((x,y,w,h))
        tiles=squeezed
    if len(tiles)<2:
        return None
    variance=noise["shot"]*np.maximum(packed,0.)+noise["read"]
    record={"packed":packed[None],"variance":variance[None],"colors":colors[None]}
    candidates=bank([tile_scores(record,t)[1]for t in tiles],tiles)
    if len(candidates)<2:
        return None
    training,testing,_=outer_samples(packed,colors,box,noise)
    if boundary is not None:
        def trim(data):
            keep=np.abs(data[0]*f[0]+data[1]*f[1]-d)>13
            return tuple(p[keep]for p in data)
        training,testing=map(trim,(training,testing))
    x,y,w,raw=training
    starting=np.array([[*r["frequency_xy"],0.]for r in candidates])
    design=curvature.wave_columns(x,y,starting)
    gram=(design.T*w)@design
    known=(design.T*w)@raw
    ranked=[]
    for i,j in combinations(range(len(starting)),2):
        first,second=starting[[i,j],:2]
        if abs(first[0]*second[1]-first[1]*second[0])<.35*np.linalg.norm(first)*np.linalg.norm(second):
            continue
        ix=[2*i,2*i+1,2*j,2*j+1]
        view=gram[np.ix_(ix,ix)]
        observed=known[ix]
        beta=np.linalg.solve(view,observed)
        ranked.append((float(beta@observed),i,j))
    arms=[]
    for _,i,j in sorted(ranked,reverse=True)[:5]:
        grid=starting[[i,j]]
        planar=curvature.refine(training,grid,(0,1),False)
        bent=curvature.refine(training,planar,(0,1),True)
        for shape in (planar,bent):
            support=curvature.directional_support(training,testing,shape)
            if min(support)<3.25:
                continue
            if shape is bent:
                control=curvature.prediction(training,testing,planar)
                prediction=curvature.prediction(training,testing,bent)
                if curvature.standardized(testing,control,prediction)<2:
                    continue
            key=sum(support)
            arms.append((key,shape,support))
    if not arms:
        return None
    _,shape,raw_scores=max(arms,key=lambda r:r[0])
    beta,_,_=curvature.fit(training,shape)
    beta=beta.reshape(2,2)
    return {"geometry":shape.tolist(),"representation":beta.tolist(),"weaker":int(np.argmin(np.sum(beta**2,axis=1))),
            "exterior_conditional_scores":raw_scores,"seed_bank":candidates,"exterior_tiles":tiles}


def predict(packed,colors,box,noise):
    x,y,w,h=box
    r=packed[:,y//2:(y+h)//2,x//2:(x+w)//2]
    data,regions,boundary=interior(r,colors,noise)
    outer=from_outer(packed,colors,box,noise,boundary)
    if outer is None:
        return {"proposed":False,"boundary":boundary}
    scored=evidence(data,regions,outer["geometry"],outer["representation"])
    return outer|{"proposed":True,"boundary":boundary,"support":scored,
                  "accepted":{k:[h for h,r in scored.items()if min(r["scores"][k])>=THRESHOLD]for k in MODES}}
