"""Drive a local signed amplitude with exterior phase after the witness passes."""
import math

import torch

from witness import anchored,curvature,local

VARIANTS=("top-pooled","bank-quarter","bank-pooled")


def transport(args,parent,forecast,modes):
    result={k:torch.zeros_like(parent)for k in modes}
    active={name:forecast.get("accepted",{}).get(mode,[])for name,mode in modes.items()}
    if not any(active.values()):
        return result
    assert parent.shape[0]==1
    geometry=forecast["geometry"]
    weaker=forecast["weaker"]
    target,other=geometry[weaker],geometry[1-weaker]
    packed,variance,colors,wb,matrix=args
    with anchored((0,0)):
        layers=curvature.local_fits(packed,variance,colors,parent,target,other)
    (a,a_cov),(b,b_cov)=layers["local"]
    offset=(target[0]+target[1])*127.5*2*math.pi
    c,s=math.cos(offset),math.sin(offset)
    cosine,sine=forecast["representation"][weaker]
    unit=torch.tensor([cosine*c-sine*s,cosine*s+sine*c],device=parent.device,dtype=a.dtype)
    unit=unit/torch.linalg.vector_norm(unit).clamp_min(1e-12)
    xa,xb=(a[0]@unit),(b[0]@unit)
    sa,sb=(unit@a_cov[0]@unit),(unit@b_cov[0]@unit)
    coherent=xa.clamp_min(0)*xb.clamp_min(0)
    shrink=(1-(sa*sb).sqrt()/coherent.clamp_min(1e-15)).clamp(0,1)
    raw=(xa+xb)*.5
    already=((a[1]+b[1])*.5@unit).clamp_min(0)
    correction=((raw.clamp_min(0)*shrink-already).clamp_min(0)[:,None]*unit)[None]
    lift=curvature.lift(correction,target)
    gains=torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
    gains=gains/gains[:,1:2]
    wave=(lift[:,None]*gains[:,:,None,None]).to(parent.dtype)
    coord=torch.arange(256,dtype=wave.dtype,device=wave.device)-127.5
    for label,regions in active.items():
        if len(regions)==2 or regions==["whole"]:
            result[label]=wave
        elif regions:
            angle,d,_=forecast["boundary"]
            signed=(coord[None]*math.cos(angle)+coord[:,None]*math.sin(angle)-d)
            sided=signed if regions[0]=="plus" else -signed
            # Begin at the measured edge and reach full weight inside the witnessed side.
            window=(sided/12).clamp(0,1)
            result[label]=wave*window
    return result


def restore(args,parent,previous,top,bank):
    original=curvature.deliver(args,parent,previous)if previous else torch.zeros_like(parent)
    if previous:
        updates={key:torch.zeros_like(parent)for key in VARIANTS}
    else:
        updates=transport(args,parent,top,{"top-pooled":"exterior-pooled"})
        updates.update(transport(args,parent,bank,{"bank-quarter":"exterior-quarter","bank-pooled":"exterior-pooled"}))
    return {"wide":original,**{k:original+v for k,v in updates.items()}}
