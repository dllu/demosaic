"""Add the bent-spectrum fallback over the same saved parent and baseline pixels."""
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import ROOT
from deliver import transport,VARIANTS
from run_restore import ARGS,observations

ADDED=("chirp-quarter","chirp-pooled","chirp-spatial")


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    parent=reference(ROOT/"restoration.json")
    base=read_json(checked(parent))
    chirp=reference(ROOT/"chirp-fresh.json")
    guarded=reference(ROOT/"spatial-fresh.json")
    spatial=read_json(checked(guarded))
    assert spatial["source"]==chirp
    now=read_json(checked(chirp))
    cases=read_json(checked(now["source"]))
    captures=read_json(checked(cases["captures"]))
    before=read_json(checked(base["source"]))
    assert before["source"]==now["source"]
    path=ROOT/"restored-chirp"
    path.mkdir()
    results=[]
    start=time.monotonic()
    for previous,record,solved,screened in zip(cases["rows"],now["rows"],base["rows"],spatial["rows"],strict=True):
        i=previous["index"]
        assert i==record["index"]==solved["index"] and previous["capture"]==record["capture"]
        observed=observations(captures["rows"][i])
        args=[torch.from_numpy(observed[n].reshape((-1,*observed[n].shape[2:]))).cuda()for n in ARGS]
        with np.load(checked(solved["output"]),allow_pickle=False)as f:
            inherited={k:f[k]for k in ("baseline","wide",*VARIANTS)}
        parent_rgb=torch.from_numpy(inherited["baseline"].reshape(8,3,256,256)).cuda()
        old_wide=torch.from_numpy(inherited["wide"].reshape(8,3,256,256)).cuda()
        ret={name:old_wide.clone()for name in ADDED}
        for j,(earlier,candidate) in enumerate(zip(previous["trials"],screened["trials"],strict=True)):
            if earlier["previous"]["geometry"]:
                continue
            assert (earlier["repeat"],earlier["role"])==(candidate["repeat"],candidate["role"])
            update=transport([p[j:j+1]for p in args],parent_rgb[j:j+1],candidate["guarded"],
                             dict(zip(ADDED,("exterior-quarter","exterior-pooled","spatial"),strict=True)))
            for k,v in update.items():
                ret[k][j:j+1]+=v
        out=path/f"{i:03d}.npz"
        with out.open("xb")as f:
            np.savez(f,**inherited,**{k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in ret.items()})
        results.append({"index":i,"output":reference(out)})
        print(i,round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/"restoration-chirp.json",{"driver":reference(__file__),"source":chirp,"reused_parent":parent,"spatial":guarded,
               "checkpoint":base["checkpoint"],"rows":results,"seconds":time.monotonic()-start})


if __name__=="__main__":
    run()
