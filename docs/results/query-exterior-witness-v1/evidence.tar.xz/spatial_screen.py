"""Require confirming weak phase across three exterior public quadrants."""
from functools import partial
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import ROOT,curvature,outer_samples,project

SCORE=2.5
MIN_QUADRANTS=3


def spatial(packed,colors,box,noise,proposal):
    if not proposal["proposed"]:
        return proposal|{"quadrant_scores":[],"coherent_quadrants":0}
    _,testing,_=outer_samples(packed,colors,box,noise)
    x,y,w,raw=testing
    fit_edge=proposal["boundary"]
    if fit_edge:
        a,d,_=fit_edge
        valid=np.abs(x*np.cos(a)+y*np.sin(a)-d)>13
    else:
        valid=np.ones(len(x),dtype=bool)
    weak=proposal["weaker"]
    strong=1-weak
    basis=curvature.wave_columns(x,y,proposal["geometry"])
    carrier=basis[:,2*weak:2*weak+2]@np.array(proposal["representation"][weak])
    nuisance=np.column_stack((np.ones_like(x),x/128,y/128,basis[:,2*strong:2*strong+2]))
    scores=[]
    for xsign,ysign in ((1,1),(1,-1),(-1,1),(-1,-1)):
        selected=valid&(x*xsign>0)&(y*ysign>0)
        if np.count_nonzero(selected)<1000:
            scores.append(None)
            continue
        residual=project(carrier[selected],nuisance[selected],w[selected]).ravel()
        z=np.sum(w[selected]*residual*raw[selected])/np.sqrt(np.sum(w[selected]*residual**2)).clip(min=1e-20)
        scores.append(float(z))
    matched=sum(v is not None and v>=SCORE for v in scores)
    held=proposal["accepted"]["exterior-pooled"] if matched>=MIN_QUADRANTS else []
    return proposal|{"quadrant_scores":scores,"coherent_quadrants":matched,
                     "accepted":proposal["accepted"]|{"spatial":held}}


def run(mode):
    stamp=reference(ROOT/f"chirp-{mode}.json")
    previous=read_json(checked(stamp))
    rows=[]
    if mode=="standing":
        files=read_json(ROOT.parent/"query-contour-support-v1"/"standing/manifest.json")
        maps={r["id"]:r for r in files["rows"]}
        for row in previous["rows"]:
            before=row["previous"]
            camera=maps[row["id"]]
            with np.load(checked(before["raw"]),allow_pickle=False)as f:
                result=spatial(f["packed"][0],f["colors"][0],before["window"],camera["shot_read"],row["banked"])
            rows.append({"id":row["id"],"guarded":result,"previous":before})
            print(row["id"],result.get("accepted",{}).get("spatial"),result["coherent_quadrants"],flush=True)
    else:
        overview=read_json(checked(previous["source"]))
        prepared=read_json(checked(overview["captures"]))
        plan=read_json(checked(prepared["plan"]))
        for row in previous["rows"]:
            with np.load(checked(row["capture"]),allow_pickle=False)as f:
                inputs={k:f[k]for k in ("packed","colors")}
            tr=[]
            for j,case in enumerate(row["trials"]):
                rep,role=divmod(j,4)
                args=(inputs["packed"][rep,role],inputs["colors"][rep,role],plan["query_box"],plan["profile"])
                result=spatial(*args,case["banked"])
                tr.append({"repeat":rep,"role":case["role"],"guarded":result})
            rows.append({"index":row["index"],"capture":row["capture"],"trials":tr})
            print(mode,row["index"],flush=True)
    write_json(ROOT/f"spatial-{mode}.json",{"driver":reference(__file__),"source":stamp,
              "per_quadrant_cutoff":SCORE,"required_quadrants":MIN_QUADRANTS,"rows":rows})


if __name__=="__main__":
    run(sys.argv[1])
