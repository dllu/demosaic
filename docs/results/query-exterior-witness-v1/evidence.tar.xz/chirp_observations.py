"""Evaluate the edge-aware exterior bank on calibration, new photos and cameras."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import MODES,ROOT,THRESHOLD,candidate,curvature,outer_samples
from chirp_bank import predict


def row(job):
    previous,source,plan=job
    with np.load(checked(previous["capture"]),allow_pickle=False)as f:
        captures={k:f[k]for k in ("packed","colors")}
    box,profile=plan["query_box"],plan["profile"]
    rows=[]
    for j,t in enumerate(previous["trials"]):
        rep,role=divmod(j,4)
        raw,colors=(captures[k][rep,role]for k in ("packed","colors"))
        result=predict(raw,colors,box,profile)
        geometry=t["exact_phase_geometry"]["geometry"]
        outer,_,_=outer_samples(raw,colors,box,profile)
        beta,_,_=curvature.fit(outer,geometry)
        estimated=candidate(raw,colors,box,profile,geometry,beta.reshape(2,2).tolist())
        rows.append({"repeat":rep,"role":t["role"],"banked":result,"exact_geometry_measured_phase":estimated})
    return {"index":previous["index"],"capture":previous["capture"],"trials":rows}


def first(mode):
    start=time.monotonic()
    stamp=reference(ROOT/f"selection-{mode}.json")
    data=read_json(checked(stamp))
    material=read_json(checked(data["captures"]))
    plan=read_json(checked(material["plan"]))
    result=[]
    with ThreadPoolExecutor(3)as pool:
        jobs=((x,plan["sources"][x["index"]],plan)for x in data["rows"])
        for i,val in enumerate(pool.map(row,jobs),1):
            result.append(val)
            print(mode,i,round(time.monotonic()-start,1),flush=True)
    write_json(ROOT/f"chirp-{mode}.json",{"driver":reference(__file__),"model":reference(ROOT/"chirp_bank.py"),
        "source":stamp,"witness_cutoff":THRESHOLD,"rows":result})


def real():
    old=reference(ROOT/"selection-standing.json")
    phase=read_json(checked(old))
    before=read_json(ROOT.parent/"query-contour-support-v1"/"standing/manifest.json")
    maps={row["id"]:row for row in before["rows"]}
    rows=[]
    for r in phase["rows"]:
        data=r["previous"]
        profile=maps[r["id"]]["shot_read"]
        with np.load(checked(data["raw"]),allow_pickle=False)as f:
            result=predict(f["packed"][0],f["colors"][0],data["window"],profile)
        rows.append({"id":r["id"],"previous":data,"banked":result})
        print(r["id"],result.get("accepted"),flush=True)
    write_json(ROOT/"chirp-standing.json",{"driver":reference(__file__),"model":reference(ROOT/"chirp_bank.py"),
               "source":old,"witness_cutoff":THRESHOLD,"rows":rows})


if __name__=="__main__":
    run=sys.argv[1]
    real() if run=="standing" else first(run)
