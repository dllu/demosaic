"""Transport an exterior phase and measure its signed increment on held Bayer sites."""
from pathlib import Path
import importlib.util
import math
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/"query-contour-support-v1"
sys.path.insert(0,str(PREVIOUS))
from contour import PREV,anchored,curvature,local
from discover import boxes,candidates,tile_scores
from consensus import bank_exterior

spec=importlib.util.spec_from_file_location("side_selector",ROOT.parent/"query-edge-side-selection-v1"/"select.py")
side=importlib.util.module_from_spec(spec)
spec.loader.exec_module(side)
THRESHOLD=3.25
MODES=("local-quarter","exterior-quarter","exterior-pooled","rotated-pooled")


def get_outer(raw,colors,box,noise):
    """Use only exterior tiles for candidates, then fit an exterior ring."""
    x0,y0,w,h=box
    height,width=(2*v for v in raw.shape[-2:])
    tiles=[b for b in boxes(x0,y0)if b[0]>=0 and b[1]>=0 and b[0]+b[2]<=width and b[1]+b[3]<=height]
    if len(tiles)<2:
        return None
    simulated=raw[None]
    noise_map=(noise["shot"]*np.maximum(simulated,0.)+noise["read"]).clip(min=2e-11)
    measures={"packed":simulated,"variance":noise_map,"colors":colors[None]}
    frames=[tile_scores(measures,b)[1]for b in tiles]
    peaks=candidates(frames,tiles,1.35)
    if len(peaks)!=2:
        return None
    initial=np.array([[*p["frequency_xy"],0.]for p in peaks])
    fit,checks,mask=outer_samples(raw,colors,box,noise)
    refined=curvature.refine(fit,initial,(0,1),False)
    curved=curvature.refine(fit,refined,(0,1),True)
    plane=curvature.prediction(fit,checks,refined)
    bent=curvature.prediction(fit,checks,curved)
    def strength(g):
        return curvature.directional_support(fit,checks,g)
    use_curved=curvature.standardized(checks,plane,bent)>=2 and min(strength(curved))>=3.25
    shape=curved if use_curved else refined
    support=strength(shape)
    if min(support)<3.25:
        return None
    weight,_,_=curvature.fit(fit,shape)
    weaker=int(np.argmin(np.sum(weight.reshape(2,2)**2,axis=1)))
    return {"geometry":shape.tolist(),"representation":weight.reshape(2,2).tolist(),"weaker":weaker,
            "exterior_conditional_scores":support,"seed_bank":peaks,"fit_native_cells":int(mask.sum()),
            "exterior_tiles":tiles,"curvature_admitted":bool(use_curved)}


def outer_samples(packed,colors,box,noise):
    x0,y0,w,h=box
    yy,xx=np.indices(packed.shape[-2:])
    bx=2*xx+0.5-x0-(w-1)*.5
    by=2*yy+0.5-y0-(h-1)*.5
    radius=np.maximum(np.abs(bx),np.abs(by))
    outside=(radius>=140)&(radius<=242)
    rng=np.random.default_rng(27284)
    fit_fold=rng.integers(2,size=outside.shape,dtype=np.int8)==0
    density=gaussian_filter((outside&fit_fold).astype(float),3.0)
    bands=[[],[]]
    for channel in np.flatnonzero(colors==1):
        values=packed[channel].astype(float)
        guide=gaussian_filter(np.where(outside&fit_fold,values,0),3.0)/density.clip(min=1e-10)
        weight=np.exp(-.5*(bx*bx+by*by)/205**2)/(noise["shot"]*guide.clip(min=0.)+noise["read"]).clip(min=2e-11)
        for j,region in enumerate((fit_fold,~fit_fold)):
            chosen=region&outside&(density>.08)
            bands[j].append((bx[chosen]+channel%2-.5,by[chosen]+channel//2-.5,weight[chosen],(values-guide)[chosen]))
    return (*[tuple(np.concatenate(t)for t in zip(*band,strict=True))for band in bands],outside)


def interior(cropped,colors,noise):
    with anchored((0,0)):
        labels=local.partition()
        approach=side.boundary(cropped,colors)
    safe=(labels==0)
    density=gaussian_filter(safe.astype(float),3)
    coords=np.indices(labels.shape)
    records=[]
    for channel in np.flatnonzero(colors==1):
        y,x=2*coords[0]+channel//2-127.5,2*coords[1]+channel%2-127.5
        value=cropped[channel].astype(float)
        guide=gaussian_filter(np.where(safe,value,0.),3)/density
        variance=(noise["shot"]*guide.clip(min=0.)+noise["read"]).clip(min=2e-11)
        records.append((x,y,np.full_like(x,channel),value,variance,labels))
    x,y,p,raw,var,fold=[np.concatenate([r[k].ravel()for r in records])for k in range(6)]
    valid=np.maximum(abs(x),abs(y))<=90
    if approach is None:
        regions={"whole":valid}
    else:
        a,d,_=approach
        z=x*math.cos(a)+y*math.sin(a)-d
        regions={"minus":valid&(z<=-7),"plus":valid&(z>=7)}
    return (x,y,p,raw,var,fold),regions,approach


def design_terms(inputs,geometry):
    x,y,p,raw,var,fold=inputs
    xnorm,ynorm=x/128,y/128
    p=np.where(p==p[0],1.,-1.)
    background=np.column_stack([np.ones_like(x),xnorm,ynorm,p,p*xnorm,p*ynorm])
    target=curvature.wave_columns(x,y,geometry)
    return background,target


def project(target,controls,weight):
    if target.ndim==1:
        target=target[:,None]
    gram=(controls.T*weight)@controls
    beta=np.linalg.solve(gram,(controls.T*weight)@target)
    return target-controls@beta


def evidence(inputs,regions,geometry,coefficients):
    background,target=design_terms(inputs,geometry)
    x,y,p,raw,v,fold=inputs
    segments={}
    for name,area in regions.items():
        metrics={k:[]for k in MODES}
        fits=[]
        chosen=area&(fold==0)
        A=np.column_stack((background[chosen],target[chosen]))
        w=1/v[chosen]
        if np.count_nonzero(chosen)<80:
            continue
        qa=np.linalg.solve((A.T*w)@A,(A.T*w)@raw[chosen])[-4:].reshape(2,2)
        for direction in (0,1):
            signal=slice(direction*2,direction*2+2)
            other=slice(2-direction*2,4-direction*2)
            designs=target[:,signal]
            nuisance=np.column_stack((background,target[:,other]))
            for k in MODES:
                phase=np.array(qa[direction]if k.startswith("local") else coefficients[direction])
                if k.startswith("rotated"):
                    phase=np.array([-phase[1],phase[0]])
                selected=area&((fold==1)if k.endswith("quarter") else (fold>0))
                w=1/v[selected]
                main=designs[selected]@phase
                residual=project(main,nuisance[selected],w).ravel()
                L=float(np.sqrt(np.sum(w*residual*residual)))
                z=float(np.sum(w*residual*raw[selected])/max(L,1e-20))
                metrics[k].append(z)
        segments[name]={"scores":metrics,"measured_Q0_phase":qa.tolist(),
                        "green_sites":int(area.sum())}
    return segments


def candidate(packed,colors,box,noise,shape=None,phase=None):
    x,y,w,h=box
    section=packed[:,y//2:(y+h)//2,x//2:(x+w)//2]
    outer=get_outer(packed,colors,box,noise)if shape is None else {
        "geometry":shape,"representation":phase,"weaker":1,"supplied_shape":True}
    observations,regions,fit_boundary=interior(section,colors,noise)
    if outer is None:
        return {"proposed":False,"boundary":fit_boundary}
    support=evidence(observations,regions,outer["geometry"],outer["representation"])
    chosen={k:[name for name,rec in support.items()if min(rec["scores"][k])>=THRESHOLD]for k in MODES}
    return outer|{"proposed":True,"boundary":fit_boundary,"support":support,"accepted":chosen}


def exact_model(layout):
    rows,amplitude=[],[]
    for tag in ("strong","weak"):
        rows.append([*layout[f"{tag}_frequency_xy"],layout[f"{tag}_tangential_curvature_cycles_per_px2"]])
        phi=layout[f"{tag}_phase"]
        amplitude.append([math.cos(phi),-math.sin(phi)])
    return rows,amplitude
