"""Render native replica examples and audit held-out geometry admissions."""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"query-exterior-witness-v1"
sys.path.insert(0,str(PREV))
from metrics import SCALE,match
from run_restore import observations


def run():
    torch.set_num_threads(2)
    receipt=reference(ROOT/"restoration.json")
    restored=read_json(checked(receipt))
    selection=read_json(checked(restored["selection"]))
    captured=read_json(checked(selection["inputs"]))
    plan=read_json(checked(captured["plan"]))
    catalog=read_json(ROOT.parent/"scene-full-epoch-v1"/"plan.json")["train_manifest"]
    with checked(catalog).open()as f:
        train={json.loads(row)["id"]for row in f}
    sources={p["source"]["id"]for p in plan["sources"]}
    assert len(sources)==36 and len(train)==90692 and not sources&train
    for earlier in plan["excluded_plans"]:
        history=read_json(checked(earlier))
        assert not sources&{p["source"]["id"]for p in history.get("sources",history.get("heldout_rows",[]))}
    for file in plan["fixed_algorithm"].values():
        checked(file)
    counts={}
    examples=[]
    for source,rows,pred in zip(plan["sources"],selection["rows"],restored["rows"],strict=True):
        i=source["index"]
        layout=source["layout"]
        group=layout["support"]
        assert i==rows["index"]==pred["index"]
        for run in rows["trials"]:
            role=run["role"]
            key=group+"/"+role
            counter=counts.setdefault(key,Counter())
            counter["trials"]+=1
            if run["previous"]["geometry"]:
                counter["existing"]+=1
                counter["existing_true"]+=match(run["previous"]["geometry"],layout) is not None
                continue
            candidate=run["checked_exterior"]
            if candidate.get("accepted",{}).get("specificity"):
                counter["new"]+=1
                exact=match(candidate["geometry"],layout)==candidate["weaker"]
                counter["new_correct_geometry"]+=exact
                if group=="occluded"and role=="present"and all(i!=j for j,r in examples):
                    examples.append((i,run["repeat"]))
    assert len(examples)>=2
    target=ROOT/"native"
    target.mkdir()
    native=[]
    for i,r in examples[:2]:
        raw=captured["rows"][i]
        source=plan["sources"][i]
        material=observations(raw)
        solved=restored["rows"][i]["predictions"]
        with np.load(checked(solved),allow_pickle=False)as f:
            base=f["baseline"][r]
            panels={k:base+SCALE*f[k][r]for k in ("wide","screened")}
        panels.update({"noisy":malvar(torch.from_numpy(material["packed"][r]),torch.from_numpy(material["colors"][r])).numpy(),
                       "target":material["target"][r]})
        transform={k:material[k][r]for k in ("wb","matrix")}
        rendered={name:np.rint(display(rgb,transform,exposure=2.)[...,48:208,48:208].transpose(0,2,3,1)*255)
                    .astype(np.uint8)for name,rgb in panels.items()}
        for title,role,names in (("triplet",0,("noisy","screened","target")),
                                  ("comparison",0,("wide","screened","target")),
                                  ("outside",1,("wide","screened","target")),
                                  ("quiet",3,("wide","screened","target"))):
            output=target/f"{i:03d}-{title}.png"
            Image.fromarray(np.concatenate([rendered[v][role]for v in names],axis=1)).save(output,optimize=True)
            native.append({"image":reference(output),"index":i,"repeat":r,"kind":title,"order":names,
              "ROI":[48,48,160,160],"source":source["source"],"source_box":source["box"],
              "observations":raw,"predictions":solved,"CFA":source["camera"]["pattern"],
              "profile":plan["profile"],"display_exposure":2})
    write_json(ROOT/"review.json",{"driver":reference(__file__),"restoration":receipt,
              "training_manifest":catalog,"training_photo_overlap":0,"counts":{k:dict(v)for k,v in counts.items()},
              "checkpoint":restored["checkpoint"],"criteria":"First two distinct occluded photos with a present draw admitted by the prespecified fallback and missed by the previous route.",
              "native":native})


if __name__=="__main__":
    run()
