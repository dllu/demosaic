"""Bind replica numbers, native views and the earlier standing-camera identity."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
RESULT=Path("docs/results/query-exterior-witness-v1")
IMAGES=Path("docs/images/query-exterior-witness-v1/replication")


def run():
    plan=reference(RESULT/"replication-preregistered.json")
    frozen=read_json(checked(plan))
    evidence=reference(ROOT/"review.json")
    viewed=read_json(checked(evidence))
    metrics=read_json(checked(viewed["restoration"]))
    selection=read_json(checked(metrics["selection"]))
    assert selection["protocol"]==frozen["plan"] and selection["algorithm"]==frozen["algorithm"]
    assert viewed["checkpoint"]==frozen["checkpoint"]
    camera=reference(Path("docs/images/query-exterior-witness-v1/manifest.json"))
    prior=read_json(checked(camera))
    assert prior["standing"]["checkpoint"]==viewed["checkpoint"] and prior["actual_native_viewing_complete"]
    notes=read_json(ROOT/"viewing.json")
    IMAGES.mkdir()
    for row in viewed["native"]:
        source=checked(row["image"])
        d=IMAGES/source.name
        shutil.copyfile(source,d)
        with Image.open(d)as f:
            assert row["ROI"][-2:]==[160,160] and f.height==160 and f.width==160*len(row["order"])
            f.verify()
        assert reference(d)["sha256"]==row["image"]["sha256"]
        row["image"]={"path":str(d),"sha256":row["image"]["sha256"]}
        row["native_viewing"]=notes[d.name]
    assert len(viewed["native"])==8
    archive=RESULT/"replication-evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as dest:
        for name in ("plan.json","fields.json","nomination.json","restoration.json","review.json","viewing.json",
                    "review.py","publish.py","nominate.py","restore_replication.py","prepare.log","nominate.log","restore.log","review.log"):
            dest.add(ROOT/name,arcname=name)
    write_json(RESULT/"replication-publication.json",{
        "method":"Frozen exterior bent phase, pooled query witness and adjacent-frequency check",
        "numerical_evaluation_complete":True,"actual_native_viewing_complete":True,
        "training_performed":False,"protocol":plan,"scoped_numeric":metrics["numeric"],"review":viewed,
        "standing_review_same_parent_and_algorithm":camera,"archive":reference(archive),
        "scope":"36 disjoint exact-target photo fields. The standing GFX media and evaluated model path are identical to the prior review. No comparable full427 or measured-camera benchmark score.",
    })


if __name__=="__main__":
    run()
