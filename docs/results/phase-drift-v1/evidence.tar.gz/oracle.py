"""Measure exact center-frequency and drift headroom under unchanged RAW support."""

import time
from collections import defaultdict
from pathlib import Path
from unittest.mock import patch

import numpy as np
from probe_phase_drift import restore
from report_fold_support_pooling import ROI, evaluated, measure, scale_at_budget

import demosaic.local_validated_waves as local
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SOURCES = (80, 81, 83, 84)


def audit():
    plan_path = ROOT / "plan.json"
    plan = read_json(plan_path)
    cfg = local.LocalWaveConfig(**plan["config"])
    groups = defaultdict(lambda: defaultdict(list))
    checked_cases = []
    deadline = time.monotonic() + 2700
    for group in plan["groups"]:
        if group["source"] not in SOURCES:
            continue
        path = ROOT / "output" / (group["id"] + ".json")
        while not path.is_file():
            if time.monotonic() > deadline:
                raise TimeoutError(f"Missing scheduled query {path.name}")
            time.sleep(5)
        case = read_json(path)
        parent = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as f:
            truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
        with np.load(checked(case["sensor"])) as f:
            packed, colors = f["packed"][..., 64:192, 64:192], f["colors"]
        recipe = case["metadata"]["recipe"]
        exact = tuple(
            (np.cos(a) / p, np.sin(a) / p)
            for a, p in zip(recipe["wire_angles"], recipe["periods"], strict=True)
        )
        geometry = tuple(tuple(v) for v in group["drifts"])
        setting = next(
            s
            for s in plan["settings"]
            if (s["profile"], s["placement"], s["budget_DN16"])
            == (group["profile"], group["placement"], 0.02)
        )
        t = setting["threshold"]
        results = {}
        with (
            patch.object(local, "_recenter_phase_guides", return_value=exact),
            patch.object(local, "_search_phase_drifts", return_value=(geometry, ())),
        ):
            for arm, selected in (("exact-center-planar", False), ("exact-center-drift", True)):
                images = []
                for role in range(3):
                    result, _ = restore(
                        parent[role][ROI].astype(np.float32),
                        packed[role],
                        colors[role],
                        exact,
                        plan["profiles"][group["profile"]],
                        cfg,
                        (t,),
                        group["placement"] == "near",
                        selected,
                    )
                    images.append(result[t])
                results[arm] = measure(parent, truth, quiet, np.stack(images))
        with np.load(checked(case["prediction"])) as actual:
            results.update(
                {
                    arm: measure(parent, truth, quiet, actual[f"{arm}--t{t:g}"])
                    for arm in plan["arms"]
                }
            )
        for arm, moment in results.items():
            groups[group["profile"], group["placement"]][arm].append(moment)
        checked_cases.append(reference(path))
        print(case["id"], flush=True)
    out = []
    for (profile, placement), variants in groups.items():
        moments = {
            arm: {k: np.mean([row[k] for row in rows], 0) for k in rows[0]}
            for arm, rows in variants.items()
        }
        parent = evaluated(moments["planar"], 0)
        scores = {}
        for arm, moment in moments.items():
            scale = scale_at_budget(moment["quiet_mse"], 0.02)
            scores[arm] = evaluated(moment, scale) | {"scale": scale}
        out.append({"profile": profile, "placement": placement, "parent": parent, "scores": scores})
    assert len(checked_cases) == 16 and len(out) == 4
    write_json(
        ROOT / "oracle.json",
        {
            "script": reference(__file__),
            "plan": reference(plan_path),
            "cases": checked_cases,
            "results": out,
            "scope": "Exact phase geometry assigned to both folds and all roles. Query RAW fits the waveform; existing local evidence still controls delivery, at the observed quiet budget. Exact geometry uses synthetic truth and serves as a diagnostic.",
        },
    )


if __name__ == "__main__":
    audit()
