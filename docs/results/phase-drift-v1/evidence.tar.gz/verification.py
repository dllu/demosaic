"""Independently recompute fixed and matched native error from saved pixels."""

from collections import Counter, defaultdict
from itertools import permutations
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ROI = np.s_[..., 128:384, 128:384]


def phase_assignment(frequencies, recipe):
    a = np.asarray(recipe["wire_angles"])
    expected = np.stack((np.cos(a), np.sin(a)), 1) / np.asarray(recipe["periods"])[:, None]
    observed = np.asarray(frequencies)
    distances = 256 * np.minimum(
        np.linalg.norm(observed[:, None] - expected, axis=2),
        np.linalg.norm(observed[:, None] + expected, axis=2),
    )
    indices = min(permutations((0, 1)), key=lambda p: sum(distances[i, j] for i, j in enumerate(p)))
    return [(j, np.sign(observed[i] @ expected[j]), distances[i, j]) for i, j in enumerate(indices)]


def direct_scores(parent, target, quiet, corrected, scale):
    image = parent.copy()
    image[ROI] += (corrected.astype(np.float64) - parent[ROI]) * scale
    error = image - target
    weak, strong = target[2] - target[1], target[1] - target[0]
    return (
        np.mean((error[ROI][..., quiet] * 65535) ** 2),
        np.mean((error[ROI] * 65535) ** 2),
        np.mean(((error[2] - error[1]) * 65535) ** 2),
        np.vdot(image[2] - image[1], weak) / np.vdot(weak, weak),
        np.vdot(image[1] - image[0], strong) / np.vdot(strong, strong),
        np.vdot(error[1], weak) / np.vdot(weak, weak),
    )


def vector(row):
    return [
        row["quiet_RMS_DN16"],
        row["query_RMS_DN16"],
        row["weak_increment_RMS_DN16"],
        row["weak_gain"],
        row["strong_gain"],
        row["weak_absent_projection"],
    ]


def audit():
    rpath = ROOT / "review/result.json"
    review = read_json(rpath)
    plan = read_json(checked(review["plan"]))
    collection = read_json(checked(review["collection"]))
    reduced = defaultdict(list)
    inferred = defaultdict(Counter)
    donor_residuals = [
        [d for _, _, d in phase_assignment(item["frequencies"], item["metadata"]["recipe"])]
        for item in collection["donors"].values()
    ]
    cases = 0
    for ref, group in zip(collection["synthetic"], plan["groups"], strict=True):
        case = read_json(checked(ref))
        assert all(case[k] == v for k, v in group.items())
        assert len(set(case["metadata"]["identities"])) == 3
        assert "phase_drifts" not in collection["donors"][case["guide_key"]]["metadata"]["recipe"]
        recipe = case["metadata"]["recipe"]
        for role, (old, new) in enumerate(
            zip(case["fits"]["planar"], case["fits"]["drift"], strict=True)
        ):
            assert old["parent_used_for_discovery_or_validation"] is False
            assert new["parent_used_for_discovery_or_validation"] is False
            b, a = old["records"][0], new["records"][0]
            for key in ("frequencies", "edges", "guide_crosschecks", "guide_search_excluded"):
                assert a[key] == b[key]
            for f, drift in zip(a["frequencies"], a["phase_drifts"], strict=True):
                for actual, (j, sign, distance) in zip(
                    drift, phase_assignment(f, recipe), strict=True
                ):
                    observed = any(actual)
                    expected = np.asarray(case["drifts"][j]) * sign
                    v = inferred[
                        case["profile"], case["kind"], "strong" if j == 0 else "weak", role > j
                    ]
                    v["trials"] += 1
                    v["nonzero"] += observed
                    v["exact_nonzero"] += (
                        observed and distance <= 1.5 and np.array_equal(actual, expected)
                    )
            v = inferred[case["profile"], case["kind"], "matched", role]
            v["planar"] += len(b["matched"])
            v["drift"] += len(a["matched"])
        parent = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as f:
            target, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
        with np.load(checked(case["prediction"])) as outputs:
            for i, agg in enumerate(review["aggregates"]):
                s = agg["setting"]
                if (s["profile"], s["placement"]) != (case["profile"], case["placement"]) or agg[
                    "kind"
                ] not in ("all", case["kind"]):
                    continue
                for arm in plan["arms"]:
                    prediction = outputs[f"{arm}--t{s['threshold']:g}"]
                    for method, scale in (
                        ("matched", agg["matched"][arm]["scale"]),
                        ("fixed", s["scale"]),
                    ):
                        reduced[i, arm, method].append(
                            direct_scores(parent, target, quiet, prediction, scale)
                        )
        cases += 1
    for (i, arm, method), scores in reduced.items():
        observed = np.mean(scores, axis=0)
        observed[:3] **= 0.5
        np.testing.assert_allclose(
            observed, vector(review["aggregates"][i][method][arm]), rtol=1e-10, atol=1e-10
        )
    for row in review["boards"]:
        with (
            Image.open(checked(row["board"]["image"])) as full,
            Image.open(checked(row["triplet"]["image"])) as small,
        ):
            for a, b in zip((0, 3, 4), (0, 1, 2), strict=True):
                box_a = (8 + 168 * a, 24, 168 + 168 * a, 184)
                box_b = (8 + 168 * b, 24, 168 + 168 * b, 184)
                np.testing.assert_array_equal(
                    np.asarray(full.crop(box_a)), np.asarray(small.crop(box_b))
                )
    cameras = {}
    for row in review["camera"]:
        x, y, w, h = row["ROI_xywh"]
        qx, qy, _, _ = row["source"]["query_box"]
        roi = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with (
            np.load(checked(row["drift_prediction"])) as f,
            np.load(checked(row["crosscheck_prediction"])) as g,
        ):
            delta = f["corrected"][roi].astype(np.float64) - g["corrected"][roi]
        observed = float(np.sqrt(np.mean(delta**2)) * 65535)
        assert np.isclose(observed, row["change_DN16"], rtol=0, atol=1e-13)
        cameras[row["id"]] = {"change_DN16": observed, "bit_exact": not np.any(delta)}
    write_json(
        ROOT / "review/independent-audit.json",
        {
            "script": reference(__file__),
            "review": reference(rpath),
            "cases": cases,
            "recomputed_groups": len(reduced),
            "recomputed_metrics": len(reduced) * 6,
            "donor_max_error_native_bins": float(np.max(donor_residuals)),
            "donor_median_error_native_bins": float(np.median(donor_residuals)),
            "drift_counts": [
                {"profile": k[0], "kind": k[1], "measurement": k[2], "present_or_role": k[3], **v}
                for k, v in inferred.items()
            ],
            "camera_roi": cameras,
            "native_triplet_cells_verified": 6,
        },
    )


if __name__ == "__main__":
    audit()
