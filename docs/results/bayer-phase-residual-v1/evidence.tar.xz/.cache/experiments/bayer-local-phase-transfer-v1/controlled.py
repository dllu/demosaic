"""Score phase delivery on independently captured local shifts with known geometry."""
from dataclasses import replace
import hashlib
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn import functional as F

from rotate import ROOT,CROSS,MODES,phase,old,guard,render
from demosaic.archive_metrics import linear_rgb,noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import observe_scene,sample_scene_recipe
from demosaic.scene_training_data import scene_seed

KEYS=("packed","variance","colors","wb","matrix","target")
ROLES=("shifted","same-phase","gap","flat")
PROFILES={"ISO400":(8e-5,2.56e-8),"ISO6400":(.00128,6.5536e-6)}
SEED=511703606211
LUMA=np.array((.2126,.7152,.0722))
TITLES={"parent":"Corpus 100k EMA","baseline":"Constant-phase fit","local":"Phase veto only",
        "rotation":"Measured local phase","opposite":"Opposite phase shift"}


def geometry(recipe,i):
    f=np.array([recipe["strong_frequency_xy"],recipe["weak_frequency_xy"]])
    k=np.array([recipe["strong_tangential_curvature_cycles_per_px2"],
                recipe["weak_tangential_curvature_cycles_per_px2"]])
    u=np.column_stack((-f[:,1],f[:,0]))/np.linalg.norm(f,axis=1,keepdims=True)
    shape=np.zeros((2,5))
    shape[:,2:]=k[:,None]*64**2*np.column_stack((u[:,0]**2,u.prod(1),u[:,1]**2))
    y,x=np.indices((256,256),dtype=float)-127.5
    native_phase=np.stack((x,y),axis=-1)@f.T+.5*np.square(np.stack((x,y),axis=-1)@u.T)*k
    rotation=((np.pi/4,np.pi/2,np.pi/2)[i%3])*(-1 if i%2 else 1)
    dx=((-6,-2,4,8)[i%4])
    dy=((5,-5,9,-3)[(i//4)%4])
    r=np.maximum(abs(x-dx),abs(y-dy))
    mask=np.clip((23-r)/7,0,1)
    mask=.5*(1-np.cos(np.pi*mask))
    return f,shape,native_phase,rotation,mask


def make(plan,row,profile):
    binding=reference(row["source"]["cache"])
    assert binding["sha256"]==row["source"]["cache_sha256"]
    photo=np.load(checked(binding),mmap_mode="r",allow_pickle=False)
    x,y,w,h=row["box"]
    assert (w,h)==(512,512)
    patch=torch.from_numpy(photo[y+128:y+384,x+128:x+384].astype(np.float32)).permute(2,0,1)/65535
    base=.060+.40*F.avg_pool2d(patch[None],13,stride=1,padding=6,count_include_pad=False)[0]
    i=row["index"]
    recipe=row["layout"]
    f,terms,nom,rotation,mask=geometry(recipe,i)
    strong=.021*np.cos(2*np.pi*nom[...,0]+recipe["strong_phase"])
    amp=(.008,.012,.018)[(i//3)%3]
    phase=2*np.pi*nom[...,1]+recipe["weak_phase"]
    weak=amp*np.cos(phase)
    def plane(values):
        return torch.from_numpy(values.astype(np.float32))[None]
    shared=base+plane(strong)
    clear=[shared+plane(amp*np.cos(phase+rotation*mask)),shared+plane(weak),
           shared+plane(weak*(1-mask)),torch.full_like(base,.18)]
    region={"inner":mask==1,"outside":mask==0,"transition":(mask>0)&(mask<1)}
    assert all(im.min()>0 and im.max()<1 for im in clear)
    a,b=PROFILES[profile]
    conditioning=dict(row["camera"])|{"shot":a,"read":b,"exposure":.33}
    cfg=replace(sample_scene_recipe(SEED),**conditioning)
    seeds=[scene_seed(SEED,i,f"{profile}/{role}")for role in ROLES]
    assert len(set(seeds))==4
    results=[observe_scene(arr,replace(cfg,noise_seed=seed)) for arr,seed in zip(clear,seeds,strict=True)]
    captured={k:torch.stack([getattr(r,k)for r in results]).numpy()for k in KEYS}
    return captured,region,f,terms,{"source":binding,"plant_phase_radians":rotation,"weak_amplitude":amp,
                                  "recipe":conditioning,"seeds":seeds}


def luma(image,captured):
    return np.einsum("bchw,c->bhw",linear_rgb(image,{k:captured[k]for k in ("wb","matrix")}),LUMA)


def metric(image,captured,region,reference_image):
    pred=luma(image,captured)
    truth=luma(captured["target"],captured)
    a=region["inner"]
    template=(truth[0]-truth[2])[a]
    assert np.linalg.norm(template)>0
    made=(pred[0]-pred[2])[a]
    def dn(x):
        return float(np.sqrt(np.mean(np.square(x)))*65535)
    return {"weak_response_pp":float((made@template)/(template@template)*100),
            "weak_increment_RMS_DN16":dn(made-template),
            "shifted_inner_RMS_DN16":dn((pred[0]-truth[0])[a]),
            "shifted_outside_RMS_DN16":dn((pred[0]-truth[0])[region["outside"]]),
            "same_phase_inner_RMS_DN16":dn((pred[1]-truth[1])[a]),
            "gap_inner_RMS_DN16":dn((pred[2]-truth[2])[a]),
            "flat_added_RMS_DN16":dn((pred[3]-reference_image[3])[a])}


def evaluate(model,plan,row,profile,metadata,folder,draw_boards):
    a,b=PROFILES[profile]
    data,region,freq,terms,recipe=make(plan,row,profile)
    noise={"shot":a,"read":b}
    model.set_noise(a,b)
    args=[torch.as_tensor(data[k],device="cuda")for k in KEYS[:5]]
    args[:2]=[x.contiguous(memory_format=torch.channels_last)for x in args[:2]]
    with ieee_fp32():
        base=model(*args).cpu().numpy()
    predictions={k:base.copy()for k in ("parent",*MODES)}
    log=[]
    for k,role in enumerate(ROLES):
        args=[data[key][k] for key in KEYS[:1]+KEYS[2:5]]
        outputs,tests=render(args[0],base[k],*args[1:],noise,freq,terms)
        verifier,_=guard.render(args[0],base[k],*args[1:],noise,freq,terms)
        for n,r in verifier.items():
            np.testing.assert_array_equal(r,outputs[n])
        for name,v in outputs.items():
            predictions[name][k]+=v
        rotation=predictions["rotation"][k]-predictions["local"][k]
        log.append({"role":role,"changed":bool(np.any(rotation)),
                    "RMS_DN16":float(np.sqrt(np.mean(rotation.astype(float)**2))*65535),
                    "peak_DN16":float(np.max(np.abs(rotation))*65535)})
    scores={key:metric(pred,data,region,luma(predictions["local"],data))for key,pred in predictions.items()}
    board=None
    if draw_boards and log[0]["changed"] and profile=="ISO400":
        case=f'{row["index"]:03d}-{profile.lower()}'
        path=folder/f"{case}.npz"
        with path.open("xb") as out:
            np.savez_compressed(out,**data,**{f"output_{k}":v for k,v in predictions.items()})
        frame={k:data[k][:1] for k in ("packed","wb","matrix","colors")}
        labels=("Noisy Malvar",*TITLES.values(),"Exact GT")
        photos=[noisy_malvar(frame)[0],*(predictions[k][0]for k in TITLES),data["target"][0]]
        board=old.native_board(folder,case,photos,frame,
            {"source":row["source"],"full_source_box":row["box"],"query_within_source_box":[128,128,256,256],
             "input":reference(path),"checkpoint":metadata,"noise":noise,"CFA":row["camera"]["pattern"],
             "scene_recipe":recipe,"role":"shifted"},
            labels=labels,exposure=2,contrast=1,
            triplet_indices=(0,labels.index(TITLES["rotation"]),len(labels)-1))
    return {"i":row["index"],"profile":profile,"source":row["source"]["id"],"recipe":recipe,
            "scores":scores,"changes":log,"board":board}


def summary(rows):
    rng=np.random.default_rng(4999054)
    values=rng.integers(len(rows),size=(10000,len(rows)))
    result={}
    for label in rows[0]["scores"]["local"]:
        metrics={name:np.asarray([r["scores"][name][label]for r in rows]) for name in ("parent",*MODES)}
        table={}
        for a,b in (("rotation","local"),("rotation","opposite"),("local","parent"),("rotation","parent")):
            diff=metrics[a]-metrics[b]
            table[f"{a}_vs_{b}"]={"point":float(diff.mean()),"interval":np.quantile(diff[values].mean(1),(.025,.975)).tolist()}
        result[label]={"mean":{k:float(v.mean())for k,v in metrics.items()},"delta":table}
    return result


@torch.inference_mode()
def main():
    start=time.monotonic()
    torch.set_num_threads(2)
    memory=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1,5*2**30/memory))
    source=reference(CROSS/"plan.json")
    plan=read_json(checked(source))
    checkpoint=plan["base"]
    model,record=load_checkpoint(checkpoint["path"],"cuda",tiled_inference=True)
    assert record["loaded_sha256"]==checkpoint["sha256"] and record["step"]==100000 and "ema" in record
    model.eval()
    folder=ROOT/"controlled-native"
    folder.mkdir(exist_ok=True)
    records=[]
    rendered=0
    for profile in PROFILES:
        for row in plan["sources"]:
            item=evaluate(model,plan,row,profile,checkpoint,folder,rendered<2)
            records.append(item)
            rendered+=bool(item["board"])
            print(profile,row["index"],[s["role"]for s in item["changes"]if s["changed"]],flush=True)
    write_json(ROOT/"controlled.json",{"driver":reference(__file__),"plan":source,"checkpoint":checkpoint,
               "operator":reference(ROOT/"rotate.py"),"profiles":PROFILES,"seed":SEED,
               "rows":records,"seconds":time.monotonic()-start,
               "summary":{profile:summary([r for r in records if r["profile"]==profile])for profile in PROFILES},
               "scope":"Exact-frequency isolated delivery diagnostic. Fresh local phase perturbations and Poisson-Gaussian scenes on the 24 archived held-out backgrounds."})


if __name__=="__main__":
    main()
