"""Preserve native-image parity, parameter bindings and source-level effects."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("bayer-local-phase-transfer-v1")
RESULTS = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name
PRIOR = Path("docs/images")/PREVIOUS.name


def panels(image, specification):
    with Image.open(image) as source:
        pixels = np.asarray(source.convert("RGB"))
    result = {}
    for panel in specification["panels"]:
        x,y,w,h = panel["png_xywh"]
        area = pixels[y:y+h,x:x+w]
        assert area.shape == (160,160,3) == (h,w,3)
        result[panel.get("label",panel.get("name"))] = area
    return result


def copy_board(spec, folder):
    src = checked(spec["image"])
    dest = IMAGES/folder/src.name
    dest.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(src,dest)
    assert reference(dest)["sha256"] == spec["image"]["sha256"]
    spec["image"]["path"] = dest.relative_to(IMAGES).as_posix()
    return panels(dest,spec)


def verify_reference(before,cells,aliases):
    old = PRIOR/before["image"]["path"]
    assert reference(old)["sha256"] == before["image"]["sha256"]
    expected = panels(old,before)
    for label in expected.keys() & cells.keys():
        assert np.array_equal(cells[label],expected[label])
    for here,earlier in aliases.items():
        assert np.array_equal(cells[here],expected[earlier])


def main():
    refs = {name:reference(ROOT/f"{name}.json") for name in ("screen","camera","replay","single-direction","donor-transfer")}
    data = {key:read_json(checked(ref)) for key,ref in refs.items()}
    stand = read_json(checked(data["camera"]["manifest"]))
    previous = reference(PRIOR/"manifest.json")
    last = read_json(checked(previous))
    prior = {r["id"]:r for r in last["standing"]}
    metrics = {r["id"]:r["changes"] for r in data["camera"]["observations"]}
    changed = {}
    for row in stand["rows"]:
        name = row["id"]
        known = prior[name]
        for key in ("raw","input","parent","native_box","roi","noise","display_exposure"):
            assert row[key]==known[key]
        cells = copy_board(row["board"],"standing")
        verify_reference(known["board"],cells,{})
        delta = abs(cells["Rotate toward missing signal"].astype(np.int16)-cells["Measured local phase"])
        row["vs_previous_rotation"] = metrics[name]["residual_vs_rotation"]|{"max_srgb8":int(delta.max())}
        if row["vs_previous_rotation"]["RMS_DN16"]:
            changed[name]=row["vs_previous_rotation"]
        else:
            assert not delta.any()
    assert len(stand["rows"])==8
    assert set(changed)=={"main-chain-link-fence-main-chain-link-fence","mesh-profile3879-fine-green-mesh-right"}
    checkpoint = data["screen"]["checkpoint"]
    assert checkpoint==data["replay"]["checkpoint"]
    native = []
    for line in data["screen"]["rows"]:
        if "board" not in line:
            continue
        spec = line["board"]
        cells = copy_board(spec["board"],"exact")
        triplet = copy_board(spec["triplet"],"exact")
        assert all(np.array_equal(pixels,cells[label]) for label,pixels in triplet.items())
        orig = next(r for r in last["automatic"] if r["id"].startswith(f'{line["index"]:03d}-'))
        verify_reference(orig["board"],cells,{"Rotate old correction":"Measured local phase"})
        native.append(spec)
    assert len(native)==2 and len(data["screen"]["rows"])==24
    assert [len(g["records"]) for g in data["replay"]["groups"].values()]==[20,16,24]
    manifest = IMAGES/"manifest.json"
    write_json(manifest,{"checkpoint":checkpoint,"previous_standing":previous,"standing":stand["rows"],"exact":native,
        "viewed_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "observations":"Both exact-target boards and all eight GFX boards were viewed at native scale. Real changes are small and add no visible intersections."},replace=True)
    RESULTS.mkdir(exist_ok=True)
    archive = RESULTS/"evidence.tar.xz"
    named = [checked(v) for v in refs.values()]+[checked(data["camera"]["manifest"])]
    named += sorted(ROOT.glob("*.py"))+sorted(ROOT.glob("*.log"))
    named += [PREVIOUS/n for n in ("rotate.py","controlled.py","noisy_centers.py","standing.py","replay.py")]
    files = {str(p.resolve().relative_to(Path.cwd())):p for p in named}
    with tarfile.open(archive,"w:xz",preset=4) as out:
        for member,p in sorted(files.items()):
            out.add(p,arcname=member,recursive=False)
    with tarfile.open(archive) as out:
        for member,p in files.items():
            with out.extractfile(member) as reader:
                assert hashlib.file_digest(reader,"sha256").hexdigest()==reference(p)["sha256"]
    write_json(RESULTS/"publication.json",{
        "checkpoint":checkpoint,"sources":refs,"manifest":reference(manifest),"archive":reference(archive),
        "shifted":data["screen"]["summary"],
        "smooth":{key:g["summary"] for key,g in data["replay"]["groups"].items()},
        "standing_changes":changed,"single_direction_summary":data["single-direction"]["reports"],
        "single_direction_spatial_sweep":data["donor-transfer"]["sweep"],
        "scope":"Inference-only, same parent and existing confidence. 24 shifted photo backgrounds, 60 photo replays, two exact and eight standing native boards. One-direction audit measures eligibility and compares geometry to planted frequencies. No new broad model scores.",
    },replace=True)
    print("Verified native controls, both triplets and all eight standing boards.")


if __name__=="__main__":
    main()
