"""Add missing-signal direction variants to the fixed standing crops."""
from importlib.util import module_from_spec,spec_from_file_location

import numpy as np

from residual import ROOT,PREVIOUS,render
from demosaic.experiments.artifacts import read_json,reference,write_json

source = PREVIOUS/"standing.py"
text = source.read_text()
changes = {
    "from rotate import ROOT,NEAR,phase,render":
        "from rotate import NEAR,phase\nfrom residual import ROOT,render",
    '"opposite":"Opposite phase shift"})':
        '"residual":"Rotate toward missing signal","residual_half":"Half shift toward missing signal"})',
    '("local","uniform","reversed","rotation","opposite")}':
        '("local","uniform","reversed","rotation","opposite","residual","residual_half")}',
    'observations.append({"id"':
        'for name in ("residual","residual_half"):\n'
        '        for before_name in ("local","rotation"):\n'
        '            diff=(updates[name][bounds].astype(float)-updates[before_name][bounds])*65535\n'
        '            metrics[name+"_vs_"+before_name]={"RMS_DN16":float(np.sqrt((diff**2).mean())),\n'
        '                                            "peak_DN16":float(np.abs(diff).max())}\n'
        '    observations.append({"id"',
}
for old,new in changes.items():
    assert text.count(old)==1
    text = text.replace(old,new)
module={
    "__name__":"camera_residual_direction","__file__":__file__}
exec(compile(text,str(source),"exec"),module)
module["main"]()
fresh=read_json(ROOT/"camera.json")
prior=reference(PREVIOUS/"camera.json")
for row,old_row in zip(fresh["observations"],read_json(prior["path"])["observations"],strict=True):
    assert all(row[k]==old_row[k] for k in ("id","noise","crop"))
    assert all(row["changes"][k]==v for k,v in old_row["changes"].items())
fresh["previous"]=prior
fresh["operator"]=reference(ROOT/"residual.py")
fresh["upstream_driver"]=reference(source)
write_json(ROOT/"camera.json",fresh,replace=True)
