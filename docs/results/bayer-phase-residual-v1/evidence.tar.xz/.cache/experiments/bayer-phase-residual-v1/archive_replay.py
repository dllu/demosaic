"""Add the residual-directed arms on the frozen 60-photo smooth-carrier replays."""
from pathlib import Path

from residual import ROOT, PREVIOUS, render
from demosaic.experiments.artifacts import read_json,reference,write_json

source = PREVIOUS/"replay.py"
text = source.read_text()
changes = {
    'reference(ROOT/"rotate.py")':'reference(ROOT/"residual.py")',
    "from rotate import ROOT,NEAR,CROSS,phase,nominate,old,MODES,render":
        "from rotate import NEAR,CROSS,phase,nominate,old\nfrom residual import ROOT,MODES,render",
    '"opposite":"Opposite phase shift"}':
        '"opposite":"Opposite phase shift","residual":"Rotate toward missing signal",\n'
        '        "residual_half":"Half shift toward missing signal"}',
    '("rotation","opposite")):':
        '("rotation","opposite"),("residual","local"),("residual","rotation"),\n'
        '                    ("residual_half","local"),("residual_half","rotation")):',
}
for old,new in changes.items():
    assert text.count(old)==1
    text=text.replace(old,new)
module={"__name__":"replay_with_residual_angles","__file__":str(source)}
exec(compile(text,str(source),"exec"),module)
module["main"]()
fresh=read_json(ROOT/"replay.json")
prior=reference(PREVIOUS/"replay.json")
for key,group in read_json(prior["path"])["groups"].items():
    for record,old_row in zip(fresh["groups"][key]["records"],group["records"],strict=True):
        assert record["input"]==old_row["input"] and record["parent"]==old_row["parent"]
        assert all(record["scores"][k]==v for k,v in old_row["scores"].items())
fresh["driver"]=reference(__file__)
fresh["operator"]=reference(ROOT/"residual.py")
fresh["previous"]=prior
fresh["upstream_driver"]=reference(source)
write_json(ROOT/"replay.json",fresh,replace=True)
