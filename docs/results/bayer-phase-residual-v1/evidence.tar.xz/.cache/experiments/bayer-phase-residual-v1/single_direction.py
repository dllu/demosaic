"""Audit single-carrier candidates discarded by the current two-carrier fallback."""
import numpy as np

from residual import ROOT, PREVIOUS
from rotate import NEAR, CROSS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

MATCH_RADIUS = .009
OLD_FLOOR = 4.734528924409914
TRUE_PRESENT = {"present":("strong","weak"),"outside-only":("strong",),"strong-only":("strong",),"quiet-query":()}


def source_plan(key, replay):
    if key == "prospective":
        return read_json(checked(replay["plan"]))
    evidence=read_json(checked(replay["detection"]))
    source="nomination" if key=="initial" else "replication"
    return read_json(checked(read_json(checked(evidence["sources"][source]))["plan"]))


def main():
    files = {name:reference(NEAR/f"{name}.json") for name in ("screen","prospective-screen")}
    existing = reference(PREVIOUS/"replay.json")
    screen,extra = (read_json(checked(v)) for v in files.values())
    arrays = screen["groups"]|{"prospective":extra["rows"]}
    baseline = read_json(checked(existing))["groups"]
    candidates = {}
    for group, current in arrays.items():
        plan = source_plan(group,extra if group=="prospective" else screen)
        selected = []
        for row,before in zip(current,baseline[group]["records"],strict=True):
            assert row["i"]==before["i"] and row["source"]==before["source"]
            pair = {(x["draw"], x["role"]) for x in before["local_traces"]}
            layout = plan["sources"][row["i"]]["layout"]
            truth = {k:np.array(layout[k+"_frequency_xy"]) for k in ("strong","weak")}
            for role in row["rows"]:
                key = role["draw"],role["role"]
                if key in pair:
                    continue
                assert not role["previous"]
                near=role["near"]["local-warped"]
                sectors = np.flatnonzero(near["families_pass"])
                if len(sectors)!=1:
                    continue
                k=int(sectors[0])
                v=np.array(near["seed"][k][:2])
                distances={name:float(np.linalg.norm(v-f)) for name,f in truth.items()}
                nearest=min(distances, key=distances.get)
                identity=nearest if distances[nearest] < MATCH_RADIUS else "other"
                correct=identity in TRUE_PRESENT[role["role"]]
                selected.append({"source":row["source"],"draw":key[0],"role":key[1],"shape":row["shape"],
                                 "score":near["query"]["by_family"][k],"identity":identity,"correct":correct,
                                 "nearest_distance":distances[nearest],"seed":near["seed"]})
        candidates[group]=selected
    threshold=max(OLD_FLOOR,max((v["score"] for v in candidates["initial"] if not v["correct"])))
    reports={}
    for name, rows in candidates.items():
        choose=[r for r in rows if r["score"]>threshold]
        reports[name]={"opportunities":len(rows),"passes":len(choose),"role_accepts":
            {role:{identity:sum(r["role"]==role and r["identity"]==identity for r in choose)
                   for identity in ("strong","weak","other")} for role in TRUE_PRESENT},
            "wrong":sum(not r["correct"] for r in choose)}
    real = []
    for row in screen["real"]:
        near=row["near"]["local-warped"]
        sectors=np.flatnonzero(near["families_pass"])
        real.append({"id":row["id"],"families_pass":near["families_pass"],
                     "by_family":near["query"]["by_family"],"signals_above_threshold":
                     [int(k) for k in sectors if near["query"]["by_family"][k]>threshold]})
    write_json(ROOT/"single-direction.json",{"driver":reference(__file__),"sources":files,"pair_routes":existing,
           "cutoff":threshold,"match_radius_cycles_per_pixel":MATCH_RADIUS,
           "candidates":candidates,"reports":reports,"real":real,
           "scope":"Eligibility only. Scan near-only single-direction proposals below the old paired route, with truth used to set the development cutoff and then label control errors. No delivered image and no new validation across a second sensing fold."},replace=True)
    print(threshold,reports,real)


if __name__=="__main__":
    main()
