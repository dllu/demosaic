"""Distinguish phase of the measured signal from the phase of the missing signal."""
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("bayer-local-phase-transfer-v1")
sys.path.insert(0, str(PREVIOUS))
from rotate import angle, cross, guard, local_fields, old, perpendicular, phase
from rotate import BLEND, INNER, MAX_ANGLE, STATIONS, TILE_TAPER, TONE, WIDTH

MODES = ("baseline", "local", "uniform", "reversed", "rotation", "opposite", "residual", "residual_half")


def coefficients(design, values):
    mat = design.reshape(-1, design.shape[-1])
    normal = mat.T @ mat
    if np.linalg.cond(normal) > 1e7:
        return None
    return np.linalg.solve(normal, mat.T @ values.ravel())[-4:].reshape(2, 2).T


def band_coefficients(wave, bands):
    result = []
    for index, band in enumerate(bands):
        design = wave[..., [index, index + 2]].reshape(-1, 2)
        result.append(np.linalg.solve(design.T @ design, design.T @ band.ravel()))
    return np.stack(result)


def residual_angles(raw, parent, wave, cfa, origin, noise, bands, diagnoses):
    """Geometric support is fixed by the previous RAW-only phase gate."""
    design = np.concatenate((TONE, wave), axis=-1)
    raw_coefficients = [
        coefficients(phase.clip_samples(design, plane), phase.clip_samples(raw, plane))
        for plane in phase.planes(cfa, (*origin, WIDTH))
    ]
    result = np.zeros((2, WIDTH, WIDTH), dtype=float)
    mass = np.zeros((WIDTH, WIDTH), dtype=float)
    if any(v is None for v in raw_coefficients):
        return result
    pooled = np.mean(raw_coefficients, axis=0)
    original = band_coefficients(wave, bands)
    for (y,x), test in zip(STATIONS, diagnoses, strict=True):
        sl = np.s_[y:y+INNER,x:x+INNER]
        shift = np.asarray(test["phase_shift"])
        mass[sl] += BLEND
        if not shift.any():
            continue
        p = coefficients(design[sl], parent[sl])
        if p is None:
            continue
        target = pooled*np.cos(shift)[:,None]
        target += np.column_stack((-pooled[:,1], pooled[:,0]))*np.sin(shift)[:,None]
        residual = target - p
        eligible = (shift != 0) & (np.linalg.norm(original, axis=1) > 1e-9)
        eligible &= np.linalg.norm(residual, axis=1) > 1e-9
        effect = np.where(eligible, np.clip(angle(original,residual),-MAX_ANGLE,MAX_ANGLE), 0)
        result[:,sl[0],sl[1]] += effect[:,None,None]*BLEND
        test["residual_angle"] = effect.tolist()
    return result/mass


def render(raw,parent,cfa,wb,matrix,noise,spacing,terms,roi=phase.ROI):
    x,y,w,h = roi
    assert (w,h) == (160,160)
    native = phase.unpack(raw)[y:y+h,x:x+w]
    prior = parent[1,y:y+h,x:x+w]
    weights = np.zeros((h,w),dtype=np.float64)
    sums = np.zeros((len(MODES),h,w),dtype=np.float64)
    receipt = []
    for top in range(0,h-WIDTH+1,WIDTH//2):
        for left in range(0,w-WIDTH+1,WIDTH//2):
            sl = np.s_[top:top+WIDTH,left:left+WIDTH]
            nominal,indices = phase.coords(left,top,spacing)
            wave = phase.wave(nominal,indices,terms)
            origin = (x+left,y+top)
            bands = cross.fit_bands(native[sl],prior[sl],cfa,(*origin,WIDTH),wave,noise)
            old_tile = bands[2]*TILE_TAPER
            sums[0][sl] += old_tile
            weights[sl] += TILE_TAPER
            if not bands[2].any():
                sums[1:,sl[0],sl[1]] += old_tile
                continue
            gain,rotation,tests = local_fields(native[sl],wave,cfa,origin,noise)
            uniform,flipped = guard.matched(gain,bands[:2])
            receipt.append({"tile":[left,top],"subwindows":tests})
            for ix,control in enumerate((gain,uniform,flipped),start=1):
                weighted = old_tile if np.all(control==1) else (
                    bands[2]+((control-1)*bands[:2]).sum(0))*TILE_TAPER
                sums[ix][sl] += weighted
                if ix == 1:
                    checked_tile = weighted
            if not rotation.any():
                sums[4:,sl[0],sl[1]] += checked_tile
                continue
            quadrature = perpendicular(wave,bands[:2])
            common = (np.cos(rotation)-1)*bands[:2]
            signed = np.sin(rotation)*quadrature
            for ix,sign in enumerate((1,-1),start=4):
                extra = (gain*(common+sign*signed)).sum(0)*TILE_TAPER
                sums[ix][sl] += checked_tile+extra
            directed = residual_angles(native[sl],prior[sl],wave,cfa,origin,noise,bands[:2],tests)
            for ix, strength in enumerate((1., .5), start=6):
                change = directed*strength
                extra = (gain*((np.cos(change)-1)*bands[:2] +
                               np.sin(change)*quadrature)).sum(0)*TILE_TAPER
                sums[ix][sl] += checked_tile+extra
    edge = np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    normal = (edge[:,None]*edge[None,:])/np.maximum(.02,weights)
    ratios = np.linalg.solve(matrix,np.ones(3))/wb
    rgb = np.zeros((len(MODES),*parent.shape),dtype=np.float32)
    rgb[:,:,y:y+h,x:x+w] = (ratios/ratios[1])[None,:,None,None]*(sums*normal)[:,None]
    return dict(zip(MODES,np.float32(old.DOSE)*rgb,strict=True)),receipt
