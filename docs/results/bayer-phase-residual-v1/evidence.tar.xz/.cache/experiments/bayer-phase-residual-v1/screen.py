"""Replay the full 512-pixel, noisy-only phase study with matched correction amplitudes."""
from pathlib import Path
import time

import numpy as np
import torch

from residual import ROOT, PREVIOUS, MODES, render
from noisy_centers import donor, full_scene_generator
from rotate import CROSS, render as previous_render
from controlled import luma, metric, KEYS, ROLES, PROFILES
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from rotate import old

LABELS = {"parent":"Corpus 100k EMA","local":"Phase veto only",
          "rotation":"Rotate old correction","residual":"Rotate toward missing signal",
          "residual_half":"Half shift toward missing signal"}


def summarize(rows, key):
    sample = np.random.default_rng(4999054).integers(len(rows), size=(10000,len(rows)))
    table = {}
    for name in rows[0]["scores"][key]["local"]:
        by_method = {m:np.asarray([r["scores"][key][m][name] for r in rows])
                     for m in ("parent",*MODES)}
        pairs = {}
        for a,b in (("rotation","local"),("residual","local"),("residual","rotation"),
                    ("residual_half","local"),("residual_half","rotation")):
            d = by_method[a]-by_method[b]
            pairs[f"{a}_vs_{b}"] = {
                "mean":float(d.mean()),"interval":np.quantile(d[sample].mean(1),(.025,.975)).tolist()}
        table[name] = {"mean":{k:float(v.mean()) for k,v in by_method.items()},"delta":pairs}
    return table


@torch.inference_mode()
def main():
    t0 = time.monotonic()
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    tests = reference(CROSS/"plan.json")
    plan = read_json(checked(tests))
    binding = plan["base"]
    prior = reference(PREVIOUS/"noisy-centers.json")
    historical = read_json(checked(prior))
    model,w = load_checkpoint(binding["path"],"cuda",tiled_inference=True)
    assert w["loaded_sha256"] == binding["sha256"] and "ema" in w and historical["checkpoint"] == binding
    model.eval()
    a,b = PROFILES["ISO6400"]
    noise = {"shot":a,"read":b}
    model.set_noise(a,b)
    prepare = full_scene_generator()
    rows = []
    native = ROOT/"native"
    native.mkdir(exist_ok=True)
    for row in plan["sources"]:
        i = row["index"]
        full,r,freq,terms,recipe = prepare(plan,row,"ISO6400")
        data = {k:(value[...,64:192,64:192] if k in ("packed","variance") else
                value[...,128:384,128:384] if k=="target" else value) for k,value in full.items()}
        region = {k:value[128:384,128:384] for k,value in r.items()}
        args = [torch.as_tensor(data[k],device="cuda") for k in KEYS[:5]]
        args[:2] = [x.contiguous(memory_format=torch.channels_last) for x in args[:2]]
        with ieee_fp32():
            base = model(*args).cpu().numpy()
        result = {"index":i,"source":row["source"]["id"],"recipe":recipe,"scores":{},"routes":{}}
        for route in ("known","automatic"):
            predictions = {k:base.copy() for k in ("parent",*MODES)}
            traces = []
            for n,role in enumerate(ROLES):
                camera = [data[k][n] for k in ("colors","wb","matrix")]
                tile = data["packed"][n]
                tag,parameters = ("known",(freq,terms)) if route=="known" else donor(full["packed"][n],camera[0],noise,tile)
                if parameters is not None:
                    images,_ = render(tile,base[n],*camera,noise,*parameters)
                    frozen,_ = previous_render(tile,base[n],*camera,noise,*parameters)
                    assert all(np.array_equal(images[key],x) for key,x in frozen.items())
                    for key,value in images.items():
                        predictions[key][n] += value
                traces.append({"role":role,"origin":tag,**{k:bool(np.any(predictions[k][n]!=predictions["local"][n]))
                              for k in ("rotation","residual","residual_half")}})
            scores = {k:metric(v,data,region,luma(predictions["local"],data)) for k,v in predictions.items()}
            expected = historical["rows"][route][i]
            assert expected["recipe"] == recipe and expected["source"] == result["source"]
            assert all(v==scores[k] for k,v in expected["scores"].items()),(route,i)
            result["scores"][route] = scores
            result["routes"][route] = traces
            if route == "automatic" and i in (0,4):
                art = native/f"{i:03d}.npz"
                np.savez_compressed(art,**data,**{"output_"+k:v for k,v in predictions.items()})
                frame = {k:data[k][:1] for k in ("packed","wb","matrix","colors")}
                images = [noisy_malvar(frame)[0],*(predictions[k][0] for k in LABELS), data["target"][0]]
                titles = ("Noisy Malvar",*LABELS.values(),"Exact GT")
                result["board"] = old.native_board(native,f"{i:03d}-iso6400",images,frame,
                    {"source":row["source"],"full_source_box":row["box"],"query_within_source_box":[128,128,256,256],
                     "input":reference(art),"checkpoint":binding,"noise":noise,"CFA":row["camera"]["pattern"],"scene_recipe":recipe,
                     "role":"shifted"},
                    labels=titles,exposure=2,contrast=1,
                    triplet_indices=(0,titles.index(LABELS["residual"]),len(titles)-1))
        print(i,[(r["origin"],r["residual"]) for r in result["routes"]["automatic"]],flush=True)
        rows.append(result)
    write_json(ROOT/"screen.json",{"driver":reference(__file__),"operator":reference(ROOT/"residual.py"),
        "comparison":prior,"plan":tests,"checkpoint":binding,"rows":rows,
        "summary":{key:summarize(rows,key) for key in ("known","automatic")},"seconds":time.monotonic()-t0},replace=True)


if __name__ == "__main__":
    main()
