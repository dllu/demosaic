"""Play the refined edge veto on cached GFX observations and render native crops."""

import importlib.util
import os
from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_frequency import ADJACENT_SEARCH, adjacent_prior, infer_prior
from demosaic._mesh_profiles import ribbon
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.mesh_refinement import _overlap_correction

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "mesh-envelope-support-v1"
sys.path.insert(1, str(SOURCE))
spec = importlib.util.spec_from_file_location("earlier_camera", SOURCE / "camera_step.py")
earlier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)
from deliver import window
sys.path.insert(2, str(ROOT.parent / "mesh-refined-edge-v1"))
sys.path.insert(3, str(ROOT.parent / "mesh-shrunk-footprint-v1"))
from extended_scope import audit
from standing import legacy


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2)) * 65535)


def run():
    rendered = read_json(ROOT / "camera.json")
    by_id = {r["id"]: r for r in rendered["views"]}
    precise = {r["id"]: r for r in read_json(ROOT.parent / "donor-phase-transport-v1" / "port.json")["cases"]}
    frames = read_json(ROOT.parent / "local-mesh-phase-evidence-v1" / "camera.json")
    dest = ROOT / "camera-expanded"
    dest.mkdir()
    rows = []
    for frame in frames["views"]:
        key = frame["id"]
        rec = by_id[key]
        query, roi, noise = (frame[k] for k in ("query", "ROI", "noise"))
        with np.load(checked(rec["arrays"]), allow_pickle=False) as f:
            packaged, prior_gap = (f[k] for k in ("packaged", "pool"))
        with np.load(checked(frame["input"]), allow_pickle=False) as f:
            raw, var, cfa = (f[k][0] for k in ("packed", "variance", "colors"))
            color = {k: f[k] for k in ("wb", "matrix")}
        parent = np.load(checked(frame["parent"]), allow_pickle=False)[0]
        trunk = window(parent, roi)
        ellipses = half = packaged
        proof = None
        if np.any(packaged != trunk):
            donors = infer_prior(raw, cfa, query, noise, span=precise[key]["noise"]["donor_span"])
            opts = {}
            delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors)
            if delta is None or not delta.any():
                donors = adjacent_prior(raw, cfa, query, noise)
                opts = {"search": ADJACENT_SEARCH}
                delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(trunk + delta, packaged)
            all_delta, rear = earlier.front_field(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(all_delta, delta)
            sample = window(raw, query, phase=2)
            positions = native_sites(sample.shape[-2:], (-127.5, -127.5))
            p, q = (ribbon(*positions, v) for v in pair)
            fx,fy = pair[0].frequency
            cuts, proof = audit(sample,cfa,p,q,noise,query,roi,float(np.arctan2(fy,fx)))
            def corrected(cut):
                if not proof["global_keep"]:
                    return trunk + (delta - rear).astype(delta.dtype)
                return trunk + (delta - rear*cut[None]).astype(delta.dtype)
            ellipses = corrected(cuts["ellipse-quarter"])
            half = corrected(cuts["ellipse-half"])
        w,h = roi[2:]
        panels = [(label,legacy.pixel(value,color,(0,0,w,h),rec["exposure"]))
                  for label,value in (("Ellipse reserve",ellipses),("Ellipse half-split",half))]
        before = {"image":rec["image"],"panels":[p for p in rec["panels"] if p["label"]!="Pooled without floor"]}
        image, coords = legacy.insert_camera_panels(dest,key,before,"Pooled audit",panels)
        fn = dest / f"{key}.npz"
        np.savez_compressed(fn,packaged=packaged,pool=prior_gap,ellipses=ellipses,half=half,parent=trunk)
        difference={"ellipses_vs_packaged":rms(ellipses-packaged),"half_vs_packaged":rms(half-packaged),
                    "half_vs_pool":rms(half-prior_gap)}
        rows.append({k:rec[k] for k in ("id","source","RAW","parent","exposure","ROI","query","noise")} |
                    {"image":image,"panels":coords,"proof":proof,"changes_DN16":difference,
                     "arrays":reference(fn)})
        print(key,difference,proof and tuple((k,v["accepted"],v["holdout"]["z"])for k,v in proof["options"].items()),flush=True)
    assert len(rows) == 8
    write_json(ROOT / "camera-expanded.json", {"sources": [reference(__file__), reference(ROOT / "extended_scope.py")],
                                     "prior": reference(ROOT / "camera.json"),
                                     "checkpoint": rendered["checkpoint"], "views": rows,
                                     "scope": "Native 100 percent qualitative playback. Same saved parent and same reproduced packaged deltas."})


if __name__ == "__main__":
    os.sched_setaffinity(0, [14])
    os.nice(12)
    run()
