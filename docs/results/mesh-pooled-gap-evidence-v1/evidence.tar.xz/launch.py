from pathlib import Path
import os
import subprocess
import sys

import psutil
from demosaic.experiments.artifacts import reference, write_json

root = Path(__file__).resolve().parent
for label,file,args in [("fixed-part-0","panel-fixed.py",["--part","0"]),
                        ("fixed-part-1","panel-fixed.py",["--part","1"]),
                        ("oracle-verified","oracle-verified.py",[]),("camera-fixed","camera-fixed.py",[])]:
    command = [sys.executable,str(root/file),*args]
    with (root/f"{label}.log").open("xb") as log:
        process = subprocess.Popen(command,env=os.environ,start_new_session=True,
                                   stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
        write_json(root/f"{label}-launch.json",{"pid":process.pid,"created":psutil.Process(process.pid).create_time(),
                   "command":command,"driver":reference(root/file)})
        print(process.pid)
