"""Nominate candidate gaps with elliptical geometry and a larger reserved sample."""

from dataclasses import dataclass
from itertools import product
import math
from types import FunctionType

import numpy as np

from demosaic.isolated_line import coordinates
from gate import choose, library
from pooled_gap_audit_20261118 import (
    SIGNED_OVERLAP, admitted, fitted_terms, forecasts, read_score, sound_template,
)


@dataclass(frozen=True)
class Ellipse:
    kind: str
    center: tuple[float,float]
    width: float
    angle: float

    def mask(self,x,y):
        a,b = x-self.center[0], y-self.center[1]
        cn,sn = math.cos(self.angle), math.sin(self.angle)
        radius = np.hypot((cn*a+sn*b)/.64,(-sn*a+cn*b)/1.35)
        ramp = np.clip((self.width+10-radius)/10,0,1)
        return ramp*ramp*(3-2*ramp)


def wide_search(data,design,rear,learn,angle):
    ellipses = tuple(Ellipse("ellipse",(x,y),width,angle+rotation)
                     for x,y,width,rotation in product(range(-48,49,24),range(-48,49,24),(28,43,56),
                                                      (0.,math.pi/4,-math.pi/4)))
    lookup = dict(choose.__globals__, library=lambda: library()+ellipses)
    chooser = FunctionType(choose.__code__,lookup,choose.__name__)
    return chooser(data,design,rear,learn)


def audit(raw,cfa,p,q,noise,query,roi,approx_angle):
    data,reserve,other,bg,rear,edge = fitted_terms(raw,cfa,p,q,noise)
    a,b,d = other
    global_keep = "shape" not in edge or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    design = np.column_stack((bg,rear))
    shape = edge.get("shape")
    theta = shape[0] if shape else approx_angle
    output, evidence = {}, {}
    for label,learn,circle_only in (("circles-quarter",reserve,True),
                      ("ellipse-quarter",reserve,False),("ellipse-half",reserve|a,False)):
        if circle_only:
            gain,footprint,strength = choose(data,design,rear,learn)
        else:
            gain,footprint,strength = wide_search(data,design,rear,learn,theta)
        delta,variance,_ = sound_template(data,design,rear,learn,footprint.mask(*data.positions))
        hold = read_score(data.raw,data.colors,design,delta,variance,~learn)
        accept = bool(global_keep and hold["z"]>SIGNED_OVERLAP and hold["half_displacement_gain"]>0)
        point = (roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
        x,y=coordinates(roi[3],roi[2],origin=point)
        cut = .5*strength*footprint.mask(x,y)
        output[label] = cut if accept else np.zeros_like(cut)
        evidence[label] = {"reserve_gain":gain,"nomination":vars(footprint),"fraction":strength,
                           "holdout":hold,"accepted":accept}
    return output,{"edge":edge,"global_keep":global_keep,"options":evidence}
