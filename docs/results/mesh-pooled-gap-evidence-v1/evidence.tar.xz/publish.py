"""Archive the complete measured and oracle panels with the reviewed native pixels."""

from datetime import datetime,UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
IMAGES=REPO/"docs/images/mesh-pooled-gap-evidence-v1"
RESULTS=REPO/"docs/results/mesh-pooled-gap-evidence-v1"


def relative(path):
    return {"path":path.relative_to(REPO).as_posix(),"sha256":reference(path)["sha256"]}


def picture(source,panels=(),prefix=""):
    path=checked(source)
    target=IMAGES/(prefix+path.name)
    shutil.copyfile(path,target)
    digest=relative(target)
    assert digest["sha256"]==source["sha256"]
    with Image.open(target) as source_image:
        for panel in panels:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and x+w<=source_image.width and y+h<=source_image.height
    return digest


def run():
    summary=read_json(ROOT/"report-summary.json")
    assert summary["independently_rescored_metrics"]==184
    assert len(summary["measurements"])==24
    for label,record in (("development",ROOT/"nomination.json"),("fresh_extension",ROOT/"fresh-nomination.json")):
        assert checked(summary[label])==record
        assert len(read_json(record)["results"])==12
    assert len(read_json(ROOT/"verify.json")["trials"])==3
    rotations=[v for v in summary["measurements"] if v["entry"]["rotated"]]
    assert len(rotations)==8 and all(not any(scores["changed"]) for row in rotations
                   for key,scores in row["metrics"].items() if key.startswith("unrelated/"))
    assert all(not scores["changed"][2] for row in summary["measurements"] for key,scores in row["metrics"].items()
               if key.startswith("matching/"))
    IMAGES.mkdir()
    RESULTS.mkdir()
    seen={
        "development-iso6400-ellipse-g194":"The rear repeat weakens in parts of the gap. Some lines remain visible inside the gap relative to GT.",
        "iso6400-disk-g205":"A small contrast reduction within the right part of the selected footprint. The foreground lines remain coherent.",
        "iso400-step-g203":"The pooled outputs reduce rear contrast on part of a continuous wire. The stronger diagonal lines remain visible.",
        "iso6400-ellipse-g204":"Strong over-continuation remains in the true ellipse. The half split misses the cut.",
    }
    camera_note={
        "main-overcast-sky-main-overcast-sky":"The gray sky stays smooth.",
        "main-building-detail-main-building-detail":"The same soft fine metal structure and rail lines.",
        "main-foliage-main-foliage":"Soft foliage edges with similar dark shadows.",
        "main-chain-link-fence-main-chain-link-fence":"Small contrast change with clear coarse crossings.",
        "mesh-nominal-fine-green-mesh-left":"Part of the already faint lattice softens with both forms of gap screening.",
        "mesh-nominal-fine-green-mesh-right":"The edited variants slightly soften weak periodic content. The strong rail and both directions remain.",
        "mesh-profile3879-fine-green-mesh-left":"The faint lattice and background variations remain visible.",
        "mesh-profile3879-fine-green-mesh-right":"The lattice crosses above and below the rail. The masked outputs still have dark background mottle.",
    }
    native=[]
    for row in summary["native"]:
        for k in ("source","arrays","checkpoint"):
            checked(row[k])
        out={k:v for k,v in row.items() if k not in ("board","triplet")}
        modes=("board","triplet") if row["id"] in ("development-iso6400-ellipse-g194","iso6400-disk-g205") else ("board",)
        for mode in modes:
            comparison=row[mode]
            out[mode]=comparison|{"image":picture(comparison["image"],comparison["panels"])}
        native.append(out|{"observation":seen[row["id"]]})
    assert len(native)==4 and sum("triplet" in row for row in native)==2
    camera={}
    for filename,prefix in (("camera.json",""),("camera-expanded.json","ellipse-")):
        by_walk=read_json(ROOT/filename)
        bound=[]
        for item in by_walk["views"]:
            for k in ("source","parent","RAW","arrays"):
                checked(item[k])
            bound.append(item|{"image":picture(item["image"],item["panels"],prefix=prefix),
                               "observation":camera_note[item["id"]]})
        assert len(bound)==8
        camera[filename]={"checkpoint":by_walk["checkpoint"],"sources":by_walk["sources"],"views":bound}
    figure=read_json(ROOT/"gap-oracle-figure.json")
    figure["image"]=picture(figure["image"])
    view=RESULTS/"viewing.json"
    write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
                     "camera_boards":camera,"native_synthetic":native,"oracle_plot":figure,
                     "scope":"Eight native GFX boards viewed in each of two comparisons, four exact-target boards and two native triplets."})
    outputs=("oracle.json","verify.json","nomination.json","fresh-nomination.json","report-summary.json")
    for name in outputs:
        shutil.copyfile(ROOT/name,RESULTS/name)
    chosen=sorted([p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py",".json",".log")]
                  + list((ROOT/"scored").glob("*.json")))
    bundle={str(p.relative_to(ROOT)):p for p in chosen}
    archive=RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=4) as tar:
        for name,p in bundle.items():
            tar.add(p,arcname=name)
    with tarfile.open(archive,"r:xz")as tar:
        for name,p in bundle.items():
            assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==reference(p)["sha256"]
    previous=("mesh-shrunk-footprint-v1","mesh-refined-edge-v1","mesh-step-continuity-v1","mesh-envelope-support-v1")
    write_json(RESULTS/"publication.json",{"scope":"Pooled Bayer gap audits on existing EMA crop predictions. Fixed fully known detector, new exact scenes and both standing GFX families. Crop scope.",
        "published":[relative(RESULTS/name) for name in (*outputs,"viewing.json")],
        "archive":relative(archive),"archive_contents":{name:reference(p)for name,p in bundle.items()},
        "earlier_archives":[relative(REPO/"docs/results"/name/"evidence.tar.xz")for name in previous]})


if __name__=="__main__":
    run()
