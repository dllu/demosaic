"""Check orthogonal invariance and holdout isolation on three archived native crops."""

import os
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import lstsq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent/"mesh-shrunk-footprint-v1"
sys.path[:0] = [str(ROOT.parent/"mesh-envelope-support-v1"),str(ROOT.parent/"mesh-refined-edge-v1"),str(PRIOR)]
from deliver import CENTRE, DISPLAY, Carrier, window
from mesh import ribbon
from gate import Footprint
from pooled_gap_audit_20261118 import fitted_terms, gap_audit, read_score, sound_template


def independent(raw,colors,null,delta,variance,sites):
    total = energy = 0.
    for color in range(3):
        index = sites & (colors==color)
        X = null[index]
        q = delta[index]
        sv = lstsq(X,q,lapack_driver="gelsy")[0]
        residual = q-X@sv
        total += (raw[index]*residual).sum()/variance[color]
        energy += (residual**2).sum()/variance[color]
    return float(total/np.sqrt(energy)), float(energy)


def verify():
    plan = read_json(PRIOR/"fixed-plan.json")
    paths = [PRIOR/"fresh"/f"{key}.json" for key in
             ("iso400-ellipse-g191","iso6400-band-g193","iso6400-ellipse-g194")]
    results = []
    for path in paths:
        case = read_json(path)
        role = next(v for v in case["proof"]["matching"]["roles"] if v["role"]==1)
        noise = plan["noise"][case["entry"]["profile"]]
        with np.load(checked(case["arrays"]),allow_pickle=False) as data:
            raw=window(data["packed"][1],CENTRE,phase=2)
            colors=data["colors"][1]
        sites=native_sites(raw.shape[-2:],(-127.5,-127.5))
        p,q=(ribbon(*sites,Carrier(**r))for r in role["central_pair"])
        _,receipt=gap_audit(raw,colors,p,q,noise,CENTRE,DISPLAY)
        samples,reserve,slots,bg,rear,_=fitted_terms(raw,colors,p,q,noise)
        initial=Footprint(**receipt["nomination"]).mask(*samples.positions)
        design=np.column_stack((bg,rear))
        shift,sigma,coeff=sound_template(samples,design,rear,reserve,initial)
        assert samples.raw.ndim==shift.ndim==1
        actual=read_score(samples.raw,samples.colors,design,shift,sigma,~reserve)
        independent_z,power=independent(samples.raw,samples.colors,design,shift,sigma,~reserve)
        np.testing.assert_allclose((actual["z"],actual["projected_energy"]),(independent_z,power),
                                   atol=2e-9,rtol=2e-10)
        model=design@np.linspace(-.016,.011,design.shape[1])
        moved=read_score(samples.raw+model,samples.colors,design,shift,sigma,~reserve)
        np.testing.assert_allclose(moved["z"],actual["z"],atol=2e-9,rtol=2e-10)
        changed=raw.copy()
        changed[slots[2].reshape(raw.shape)] += .008
        _,perturbed=gap_audit(changed,colors,p,q,noise,CENTRE,DISPLAY)
        for k in ("edge","reserve_gain","nomination","fraction","reserve_amplitude"):
            assert receipt[k]==perturbed[k]
        # A constant perturbation lies in the null; add a phased one to check that the held signal is seen.
        phased=raw.copy()
        phased[slots[2].reshape(raw.shape)] += np.asarray(-.28*shift[slots[2]],dtype=raw.dtype)
        _,changed_result=gap_audit(phased,colors,p,q,noise,CENTRE,DISPLAY)
        assert receipt["nomination"]==changed_result["nomination"]
        assert abs(receipt["pooled"]["z"]-changed_result["pooled"]["z"])>1e-4
        print(case["entry"]["id"],float(actual["z"]),float(moved["z"]),flush=True)
        results.append({"source":reference(path),"id":case["entry"]["id"],"QR_score":actual,
                        "rectangular_LS_score":[independent_z,power],"nuisance_shift_score":moved,
                        "reserve_unchanged_after_audit_perturbation":True})
    write_json(ROOT/"verify.json",{"source":reference(__file__),"trials":results})


if __name__=="__main__":
    os.sched_setaffinity(0,[15])
    os.nice(12)
    verify()
