"""Generate native test scenes with genuine contrast changes and true breaks."""

import dataclasses
import math

import numpy as np
import torch

from demosaic.cfa import PATTERNS,mosaic
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise,variance_map
from mesh import ribbon
from run import prior


def smooth(t):
    s=np.clip(t,0,1)
    return s*s*(3-2*s)


def pack(rgb,pattern,key,noise):
    raw=add_noise(mosaic(rgb[None],pattern),noise["shot"],noise["read"],black_level=.03,
                  generator=torch.Generator().manual_seed(key))
    return raw,variance_map(raw,noise["shot"],noise["read"])


def observe(entry,noise):
    g,seed=entry["g"],entry["seed"]
    i=g-200
    cfa=tuple(PATTERNS)[g%4]
    guides=prior.guides(g)
    x,y=coordinates(320,320,origin=(-159.5,-159.5))
    p,q=(ribbon(x,y,c)for c in guides)
    background=np.array([.235,.283,.338])[:,None,None]+.018*x/320-.016*y/320
    background=background+.0049*np.sin(.025*x-.027*y)+.0042*np.cos(.027*x+.021*y)
    angle=(np.arctan2(guides[1].frequency[1],guides[1].frequency[0])+
           np.deg2rad((14,29,49,62,87,9)[i]))%np.pi
    u,v=np.cos(angle),np.sin(angle)
    offset=(-9,14,-27,18,-7,23)[i]
    curvature=(0,14,7,-10,0,-14)[i]
    across=u*x+v*y-offset-curvature*((-v*x+u*y)/128)**2
    step=.5+.5*np.tanh(across/(2.5+1.2*(i%3)))
    has_edge=entry["layout"]!="continuous"
    if has_edge:
        background=background+np.array([.027,.020,.013])[:,None,None]*step
    shade=(.64,.48,.52,.31,.32,.58)[i]
    shade_rgb=np.array([shade*.94,shade,shade*1.1])[:,None,None]
    weak_shading=shade_rgb+(1-shade_rgb)*step if has_edge else 1.
    strong_shading=.76+.24*step if has_edge else 1.
    strength=(.0066,.0087,.0110,.0133,.0138,.0108)[i]
    footprint=np.ones_like(p)
    mode=entry["layout"]
    if mode=="band":
        a=angle+(-.53 if i%2 else .49)
        gap_dir=np.cos(a)*x+np.sin(a)*y-(6 if i%2 else -17)
        footprint=smooth((abs(gap_dir)-(16,25,33,38,31,23)[i])/11)
    elif mode in ("ellipse","disk"):
        dx,dy=(19,-21,31,-26,24,-33)[i],(11,31,-12,25,-19,8)[i]
        a=x-dx;b=y-dy
        if mode=="ellipse":
            radial=np.hypot((u*a+v*b)/.64,(-v*a+u*b)/1.35)
        else:
            radial=np.hypot(a,b)
        footprint=smooth((radial-(24,37,34,47,42,50)[i])/11)
    first=background+(.039*prior.STRONG*p*strong_shading)
    present=first+strength*prior.FAINT*weak_shading*q*(1-p)*footprint
    absent,truth,edge=(torch.from_numpy(v.astype(np.float32))for v in(first,present,background))
    packed,details=paired_observation(absent[None],truth[None],noise,[cfa],torch.ones(1,3),torch.eye(3)[None],seed)
    items={k:torch.from_numpy(packed[k])for k in("target","packed","variance","colors","wb","matrix")}
    pattern=items["colors"][0]
    if entry["independent"]:
        values,variance=zip(*(pack(t,pattern,seed+71+i*601,noise)for i,t in enumerate((absent,truth))),strict=True)
        items["packed"]=torch.cat(values)
        items["variance"]=torch.cat(variance)
    edge_raw,edge_var=pack(edge,pattern,seed+2357,noise)
    tails={"target":edge[None],"packed":edge_raw,"variance":edge_var,
           **{k:items[k][:1]for k in ("colors","wb","matrix")}}
    items={k:torch.cat((v,tails[k]))for k,v in items.items()}
    xx,yy=coordinates(768,768,origin=(-383.5,-383.5))
    donors={}
    extent=np.zeros_like(xx)
    for cx,cy in ((-238,-33),(227,40),(-25,234)):
        extent=np.maximum(extent,smooth((111-np.maximum(abs(xx-cx),abs(yy-cy)))/20))
    rotate=np.array([[np.cos(.49),-np.sin(.49)],[np.sin(.49),np.cos(.49)]])
    for name,geometry in (("matching",guides),("unrelated",tuple(dataclasses.replace(c,frequency=tuple(rotate@c.frequency))for c in guides))):
        if name=="unrelated"and not entry["rotated"]:
            continue
        p1,q1=(ribbon(xx,yy,c)for c in geometry)
        bg=np.array([.23,.281,.34])[:,None,None]+.023*xx/768-.013*yy/768
        image=bg+extent*(.097*prior.STRONG*p1+.069*prior.FAINT*q1)
        exterior=pack(torch.from_numpy(image.astype(np.float32)),pattern,seed+7409,noise)[0]
        donors[name]=exterior[0].numpy()
    return items,donors,{"strong_phase":p,"weak_phase":q,"support":footprint},details,{
        "case_geometry":[vars(c)for c in guides],"CFA":cfa,"weak_amplitude":strength,
        "edge_angle":float(angle),"edge_offset":offset,"curvature":curvature,"weak_side_fraction":shade,
        "continuous_across_step":bool(has_edge and mode=="step"),"independent_noise":entry["independent"],
    }
