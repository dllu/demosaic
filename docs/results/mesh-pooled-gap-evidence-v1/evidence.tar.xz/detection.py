"""Bayer gap scores with one reserved nomination and an orthogonal pooled audit."""

from dataclasses import dataclass
import math

import numpy as np

from demosaic.isolated_line import coordinates
from edge import fit_edge, forecasts, nuisance, step_profile
from envelope_nuisance import observation, partition
from gate import Footprint, admitted, choose, validate_support
from qualified_step import KNOTS


RESERVE_MINIMUM = 9.
SIGNED_OVERLAP = 3.25
PUBLIC_POLICIES = ("old", "pool", "pool-no-floor")


def masks(raw):
    slot = partition(raw.shape,"distributed")
    i,j,k = (slot==g for g in (1,2,3))
    return slot==0,(i,j,k)


def fitted_terms(raw,cfa,p,q,noise):
    data = observation(raw,cfa,p,q,noise,KNOTS,flexible=True)
    reserve,splits = masks(raw)
    edge,diagnostic = fit_edge(data,reserve)
    bg = nuisance(data,p,edge,"refined")
    rear = data.wave[:,None]
    if edge is not None:
        step = step_profile(*data.positions,edge)[0]
        rear = np.column_stack((rear,data.wave*step))
    return data,reserve,splits,bg,rear,diagnostic


def project(samples,design):
    """Rectangular projection by a reduced orthogonal basis."""
    assert samples.ndim==1 and design.ndim==2 and len(samples)==len(design)
    Q = np.linalg.qr(design,mode="reduced")[0]
    return samples-Q@(Q.T@samples)


def sound_template(data,design,rear,reserve,cut):
    """Learn the rear amplitude and channel signs on the reserve alone."""
    assert cut.ndim == 1 and design.ndim == rear.ndim == 2
    coefficient, variance = [], []
    for color in range(3):
        learn = reserve&(data.colors==color)
        values = data.raw[learn]
        params = np.linalg.lstsq(design[learn],values,rcond=None)[0]
        coefficient.append(params[-rear.shape[1]:])
        variance.append(data.shot*max(1e-4,float(np.median(values)))+data.read)
    model = np.asarray(coefficient)
    field = np.einsum("ij,ij->i",rear,model[data.colors],optimize=False)
    return -field*cut,np.asarray(variance),model


def read_score(raw,colors,null,delta,variance,sites):
    """Remove the continuing-wave nuisance from a signed test direction."""
    assert raw.ndim==colors.ndim==delta.ndim==sites.ndim==1 and null.ndim==2
    a = mass = nominal = 0.
    records = []
    for c in range(3):
        keep = sites&(colors==c)
        direction = project(delta[keep],null[keep])
        a += float(raw[keep]@direction)/variance[c]
        mass += float(direction@direction)/variance[c]
        nominal += float(delta[keep]@delta[keep])/variance[c]
        records.append(int(keep.sum()))
    return {"z":a/math.sqrt(max(mass,1e-20)),"projected_energy":mass,"template_energy":nominal,
            "samples_per_color":records,"half_displacement_gain":a-.25*mass}


def gap_audit(raw,cfa,p,q,noise,query,roi,*,known_cut=None):
    data,reserve,splits,bg,rear,edge = fitted_terms(raw,cfa,p,q,noise)
    a,b,d = splits
    groups = ((a,b),(b,a),(a|b,d))
    global_forecast = forecasts(data,bg,rear,groups)
    global_keep = "shape" not in edge or admitted(global_forecast,.5,(1.75,)*3)
    design = np.column_stack((bg,rear))
    reserve_gain,footprint,fraction = choose(data,design,rear,reserve)
    shape = footprint.mask(*data.positions)
    nominated = fraction*shape
    delta,variance,coefficient = sound_template(data,design,rear,reserve,shape)
    pooled = read_score(data.raw,data.colors,design,delta,variance,~reserve)
    old = validate_support(data,bg,rear,groups,nominated) if reserve_gain>=RESERVE_MINIMUM and global_keep else None
    pass_old = old is not None and admitted(old,.5,(1.25,1.25,1.65))
    pass_nominal = global_keep and pooled["z"]>SIGNED_OVERLAP and pooled["half_displacement_gain"]>0
    accepted = {"old":pass_old,"pool":pass_nominal and reserve_gain>=RESERVE_MINIMUM,
                "pool-no-floor":pass_nominal}
    origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
    x,y=coordinates(roi[3],roi[2],origin=origin)
    proposal = .5*fraction*footprint.mask(x,y)
    cuts = {k:proposal if enabled else np.zeros_like(proposal) for k,enabled in accepted.items()}
    record = {"edge":edge,"original_global_check":global_forecast,"global_keep":global_keep,
              "reserve_gain":reserve_gain,"nomination":vars(footprint),"fraction":fraction,"pooled":pooled,
              "earlier":old,"accepted":accepted,"reserve_amplitude":coefficient.tolist()}
    if known_cut is not None:
        assert known_cut.shape == raw.shape
        delta,variance,_ = sound_template(data,design,rear,reserve,known_cut.ravel())
        record["known_footprint"]=read_score(data.raw,data.colors,design,delta,variance,~reserve)
    return cuts,record
