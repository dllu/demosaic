"""Separate sensor evidence from nuisance fitting on fresh exact gap observations."""

import importlib.util
import math
import os
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.cfa import mosaic
from demosaic.isolated_line import native_sites
from demosaic.noise import add_noise

ROOT = Path(__file__).resolve().parent
RETAINED = ROOT.parent/"mesh-shrunk-footprint-v1"
OLD = ROOT.parent/"mesh-refined-edge-v1"
SUPPORT = ROOT.parent/"mesh-envelope-support-v1"
sys.path[:0] = [str(SUPPORT),str(OLD),str(RETAINED)]
from detection import gap_audit, masks
from deliver import CENTRE, DISPLAY, Carrier, window
from mesh import ribbon

SCENE_FILE = RETAINED/"scenes.py"
spec = importlib.util.spec_from_file_location("known_scene",SCENE_FILE)
scenes = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scenes)
CONTINUING = SCENE_FILE.read_text().replace("q*(1-p)*footprint", "q*(1-p)")
assert CONTINUING != SCENE_FILE.read_text()
full = {}
exec(compile(CONTINUING,str(SCENE_FILE),"exec"),full)
DRAWS = 64
LIMITS = (1.65,3.25)


def observations(rgb,cfa,noise,key):
    template = torch.from_numpy(rgb).unsqueeze(0)
    source = mosaic(template,cfa)
    raw = add_noise(source.expand(DRAWS,-1,-1,-1).contiguous(),noise["shot"],noise["read"],black_level=.03,
        generator=torch.Generator().manual_seed(key))
    return raw.numpy(),source[0].numpy().astype(np.float64)


def signed_score(observed,base,delta,variance,keep):
    assert observed.ndim==2 and base.ndim==delta.ndim==variance.ndim==keep.ndim==1
    norm = float(np.sum(delta[keep]**2/variance[keep]))
    stat = (observed[:,keep]-base[keep]) @ (delta[keep]/variance[keep])/math.sqrt(norm)
    return stat,norm


def cases():
    src = read_json(RETAINED/"fixed-plan.json")
    plan = ROOT/"oracle-plan.json"
    entries = [item for item in src["cases"] if item["kind"] == "gaps"]
    write_json(plan,{"driver":reference(__file__),"scenario_source":reference(SCENE_FILE),
                     "earlier_panel":reference(RETAINED/"fixed-plan.json"),"cases":entries,
                     "draws_per_class":DRAWS,"cuts":LIMITS,
                     "seed":"1979186217 + 63599 * case list index + hypothesis index * 379",
                     "scope":"Fully known simple hypotheses and independent marginal draws at each geometry. This is an optimistic physical diagnostic."})
    rows = []
    for idx,entry in enumerate(entries):
        name=entry["id"]
        record=RETAINED/"fresh"/f"{name}.json"
        tracked=read_json(record)
        noise=src["noise"][entry["profile"]]
        exact,_,shapes,_,meta=scenes.observe(entry,noise)
        continuous=full["observe"](entry,noise)[0]["target"][1].numpy()
        with np.load(checked(tracked["arrays"]),allow_pickle=False) as f:
            for k in ("target","packed"):
                np.testing.assert_array_equal(f[k],exact[k].numpy())
            positive = f["target"][1].copy()
            support=f["support"].copy()
            raw=window(f["packed"][1],CENTRE,phase=2)
            cfa=f["colors"][1]
        y0,F0=observations(window(continuous,CENTRE),cfa,noise,1979186217+63599*idx)
        y1,F1=observations(window(positive,CENTRE),cfa,noise,1979186217+63599*idx+379)
        variance = noise["shot"]*F0+noise["read"]+(1/(65535*(1-.03)))**2/12
        diff=(F1-F0).ravel()
        reserve,(a,b,d)=masks(raw)
        physical={}
        for policy, keep in (
            ("all",np.ones(reserve.shape,bool)),("one_fold",d),("pooled_after_reserve",~reserve),
        ):
            x,power=signed_score(y0.reshape(DRAWS,-1),F0.ravel(),diff,variance.ravel(),keep)
            y,_=signed_score(y1.reshape(DRAWS,-1),F0.ravel(),diff,variance.ravel(),keep)
            obs,_=signed_score(raw.reshape(1,-1),F0.ravel(),diff,variance.ravel(),keep)
            physical[policy]={"delta_snr":math.sqrt(power),"actual_observation_score":float(obs[0]),
                              "continuous":x.tolist(),"gap":y.tolist(),
                              "at_cut":[{"threshold":z,"false_cuts":int((x>z).sum()),
                                         "gap_detected":int((y>z).sum())} for z in LIMITS]}
        x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
        cut=np.stack([(1-window(support,CENTRE))[i//2::2,i%2::2]for i in range(4)])
        exact_pair=[Carrier(**v)for v in meta["case_geometry"]]
        exact_a,exact_b=(ribbon(x,y,v)for v in exact_pair)
        _, known=gap_audit(raw,cfa,exact_a,exact_b,noise,CENTRE,DISPLAY,known_cut=cut)
        row=next(v for v in tracked["proof"]["matching"]["roles"] if v["role"]==1)
        current=None
        if "central_pair" in row:
            measured_a,measured_b=(ribbon(x,y,Carrier(**v))for v in row["central_pair"])
            _, current=gap_audit(raw,cfa,measured_a,measured_b,noise,CENTRE,DISPLAY,known_cut=cut)
        rows.append({"id":name,"source_case":reference(record),"physical":physical,"with_known_geometry":known,
                     "with_measured_geometry":current,"weak_amplitude":meta["weak_amplitude"]})
        print(name,round(physical["all"]["delta_snr"],2),
                     round(physical["pooled_after_reserve"]["actual_observation_score"],2),
                     round(known["known_footprint"]["z"],2),
                     None if current is None else (round(current["pooled"]["z"],2),round(current["known_footprint"]["z"],2)),
                     flush=True)
    write_json(ROOT/"oracle.json",{"plan":reference(plan),"rows":rows})


if __name__=="__main__":
    os.sched_setaffinity(0,[14])
    os.nice(12)
    torch.set_num_threads(1)
    cases()
