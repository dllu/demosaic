"""Recompute saved RGB metrics and render fixed native scene interventions."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from deliver import DISPLAY,score

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"mesh-shrunk-footprint-v1"
METHODS=("broad","central","old","pool","pool-no-floor")
TAGS=("Wide delivery","Central check","Finite support","Pooled audit","Pooled no floor")


def rms(x):
    return float(np.sqrt(np.mean(x.astype(float)**2))*65535)


def audit_case(path,plan,attached=None):
    row=read_json(checked(path))
    if attached:
        full=checked(attached["scores"]["arrays"])
    with np.load(checked(row["arrays"]),allow_pickle=False)as f:
        arrays=dict(f)
    expected=row["metrics"]
    if attached:
        with np.load(full,allow_pickle=False)as result:
            for key in result.files:
                arrays["matching/"+key]=result[key]
        expected=expected | {"matching/"+k:v for k,v in attached["scores"].items() if k!="arrays"}
    base,clean=(arrays[n]for n in ("parent","target"))
    reg=np.s_[...,80:240,80:240]
    truth_shape={k:arrays[k]for k in ("weak_phase","strong_phase","support")}
    real={}
    for policy,record in expected.items():
        correction=None if policy=="parent" else arrays[policy]
        verified=score(base,correction,clean,truth_shape)
        assert verified==record,(row["entry"]["id"],policy)
        adapt=base[reg] if correction is None else base[reg]+correction
        error=adapt-clean[reg]
        scope=policy.split("/")[0] if "/" in policy else "matching"
        wide=arrays[scope+"/broad"]
        difference=wide if correction is None else correction-wide
        real[policy]=record | {"direct_present_RMS_DN16":rms(error[1]),
                               "edits_from_wide":[bool(np.any(j))for j in difference]}
    return real,arrays,row


def board(out,path,plan,k,methods,tags,*,role=1,policy,extended=None):
    _,a,row=audit_case(path,plan,extended)
    x,y,w,h=DISPLAY
    roi=np.s_[...,y:y+h,x:x+w]
    old,truth=a["parent"][role],a["target"][role]
    values=[noisy_malvar(a)[role],old]
    for method in methods:
        current=old.copy()
        current[roi]+=a["matching/"+method][role]
        values.append(current)
    values.append(truth)
    labels=("Noisy Malvar","Local trunk",*tags,"Exact GT")
    return native_board(out,k,values,{v:a[v][role:role+1]for v in("wb","matrix")},
        {"source":path,"arrays":row["arrays"],"checkpoint":plan["checkpoint"],"role":role,
         "date_set":row["entry"]["id"],"seed":row["entry"]["seed"],"CFA":row["traits"]["CFA"],
         "noise":plan["noise"][row["entry"]["profile"]],"shown_triplet":policy},
         labels=labels,triplet_indices=(0,2+methods.index(policy),len(labels)-1),roi=DISPLAY,exposure=1,contrast=8)


def average_group(group):
    means={}
    policies=sorted(set(policy for row in group for policy in row["metrics"] if policy.startswith("matching/"))|{"parent"})
    for p in policies:
        observed=[r["metrics"][p]for r in group if p in r["metrics"]]
        means[p]={"n":len(observed),
                  "weak_response_pct":100*mean(v["response"][0]for v in observed),
                  "increment_RMS_DN16":mean(v["increment_RMS_DN16"][0]for v in observed),
                  "present_RMS_DN16":mean(v["direct_present_RMS_DN16"]for v in observed),
                  "roles_edited":[sum(v["edits_from_wide"][i]for v in observed)for i in range(3)]}
        for k in ("gap_added_RMS_DN16","gap_error_RMS_DN16"):
            samples=[v[k]for v in observed if v[k] is not None]
            means[p][k]=mean(samples) if samples else None
    return means


def apply():
    plan_path=ROOT/"measured-plan.json"
    plan=read_json(plan_path)
    order={entry["id"]:i for i,entry in enumerate(plan["cases"])}
    refs=[reference(ROOT/f"part-{j}.json")for j in(0,1)]
    loaded=[read_json(checked(ref))for ref in refs]
    assert all(a["plan"]==reference(plan_path)for a in loaded)
    extended=read_json(ROOT/"fresh-nomination.json")
    development=read_json(ROOT/"nomination.json")
    by_id={row["id"]:row for row in extended["results"] if row["measured"]}
    cases={}
    checks=0
    for part in loaded:
        for item in part["measurements"]:
            raw=read_json(checked(item))
            name=raw["entry"]["id"]
            extra=by_id.get(name)
            rec,_,row=audit_case(item,plan,extra if extra and extra["scores"] else None)
            checks+=len(row["metrics"])
            # Rejected extra footprints reproduce the central policy in a measured case.
            if raw["entry"]["profile"]=="iso6400":
                for mode in ("circles-quarter","ellipse-quarter","ellipse-half"):
                    rec.setdefault("matching/"+mode,rec["matching/central"])
            roles=row["proof"]["matching"]["roles"]
            cases[name]={"id":name,"entry":row["entry"],"metrics":rec,"source":item,"roles":roles,"CFA":row["traits"]["CFA"]}
    assert checks==184 and len(cases)==24
    rows=sorted(cases.values(),key=lambda r:order[r["id"]])
    groups={}
    for prof in ("iso400","iso6400"):
        for kind in ("continuity","gaps"):
            focus=[r for r in rows if (r["entry"]["profile"],r["entry"]["kind"])==(prof,kind)]
            assert len(focus)==6
            groups[f"{prof}/{kind}"]=average_group(focus)
    dest=ROOT/"native";dest.mkdir(exist_ok=True)
    selected_dev=next(r for r in development["results"] if r["id"]=="iso6400-ellipse-g194")
    assert selected_dev["proof"]["options"]["ellipse-half"]["accepted"]
    previous=read_json(OLD/"fixed-plan.json")
    samples=[board(dest,selected_dev["previous"],previous,"development-iso6400-ellipse-g194",
                    ("broad","footprint","circles-quarter","ellipse-half"),
                    ("Wide delivery","Finite support","Circles","Ellipse half-split"),
                    policy="ellipse-half",extended=selected_dev)]
    def reduction(r, policy, control):
        return r["metrics"]["matching/"+control]["gap_error_RMS_DN16"]-r["metrics"]["matching/"+policy]["gap_error_RMS_DN16"]
    high = [r for r in rows if r["entry"]["profile"]=="iso6400" and r["entry"]["kind"]=="gaps"]
    good=max(high,key=lambda r:reduction(r,"ellipse-half","central"))
    if reduction(good,"ellipse-half","central")>0:
        variants=(*METHODS,"ellipse-quarter","ellipse-half")
        names=(*TAGS,"Ellipse reserve","Ellipse half-split")
        proof=by_id[good["id"]]
        samples.append(board(dest,good["source"],plan,good["id"],variants,names,
                        policy="ellipse-half",extended=proof))
    else:
        improved = [r for r in rows if r["entry"]["profile"]=="iso400" and r["entry"]["kind"]=="gaps"]
        best=max(improved,key=lambda r:reduction(r,"pool","broad"))
        samples.append(board(dest,best["source"],plan,best["id"],METHODS,TAGS,policy="pool"))
    weakest=max([r for r in rows if r["entry"]["profile"]=="iso400" and r["entry"]["kind"]=="continuity"],
               key=lambda r:r["metrics"]["matching/pool"]["increment_RMS_DN16"][0]-
                            r["metrics"]["matching/old"]["increment_RMS_DN16"][0])
    samples.append(board(dest,weakest["source"],plan,weakest["id"],METHODS,TAGS,policy="pool"))
    residual=max(high,key=lambda r:r["metrics"]["matching/ellipse-half"]["gap_added_RMS_DN16"])
    options=by_id.get(residual["id"])
    if residual["id"]!=good["id"] or len(samples)<3:
        if options and options["scores"]:
            samples.append(board(dest,residual["source"],plan,residual["id"],(*METHODS,"ellipse-half"),
                       (*TAGS,"Ellipse half-split"),policy="ellipse-half",extended=options))
        else:
            samples.append(board(dest,residual["source"],plan,residual["id"],METHODS,TAGS,policy="pool"))
    write_json(ROOT/"summary.json",{"script":reference(__file__),"plan":reference(plan_path),
        "measurements":rows,"groups":groups,"native":samples,"independently_rescored_metrics":checks,
        "fresh_extension":reference(ROOT/"fresh-nomination.json"),"development":reference(ROOT/"nomination.json")})


if __name__=="__main__":
    os.sched_setaffinity(0,[14])
    os.nice(12)
    apply()
