"""Plot the oracle score and detection counts alongside measured nomination."""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
oracle=read_json(ROOT/"oracle.json")
nomination=read_json(ROOT/"nomination.json")
archived={r["id"]:r for r in nomination["results"] if r["measured"]}
rows=[r for r in oracle["rows"] if r["id"].startswith("iso6400")]
assert len(rows)==6
fig,(scores,rates)=plt.subplots(2,1,figsize=(7.8,5.2),sharex=True,layout="constrained")
places=np.arange(len(rows))
styles=[
    ("Known background and gap, 75% audit", "#264f82","o",
     lambda r:r["physical"]["pooled_after_reserve"]["actual_observation_score"]),
    ("Measured wire and known gap, 75% audit", "#239085","s",
     lambda r:None if not r["with_measured_geometry"] else r["with_measured_geometry"]["known_footprint"]["z"]),
    ("Measured wire and nominated gap, 75% audit", "#d45f25","^",
     lambda r:None if not r["with_measured_geometry"] else r["with_measured_geometry"]["pooled"]["z"]),
    ("Expanded nomination, 50% audit", "#882f68","x",
     lambda r:None if r["id"] not in archived else archived[r["id"]]["proof"]["options"]["ellipse-half"]["holdout"]["z"]),
]
for (label,color,mark,fun),offset in zip(styles,(-.18,-.06,.06,.18),strict=True):
    coordinates=[(loc+offset,fun(row))for loc,row in zip(places,rows,strict=True)if fun(row)is not None]
    x,y=zip(*coordinates,strict=True)
    scores.scatter(x,y,s=30,label=label,color=color,marker=mark,zorder=4)
scores.axhline(3.25,color="#525d63",linestyle="--",linewidth=1)
scores.axhline(0,color="#b1bbc0",linewidth=.7)
scores.set_ylabel("Signed overlap score")
scores.set_title("ISO6400 gap evidence with known and measured footprints",loc="left",fontsize=13)
scores.legend(fontsize=8,loc="upper center",bbox_to_anchor=(.5,-.03),ncol=2,frameon=False)
for group,label,color,offset in (
    ("one_fold","25% of Bayer sites","#96b3d0",-.17),
    ("pooled_after_reserve","75% of Bayer sites","#2a669e",.17)):
    detected=[r["physical"][group]["at_cut"][-1]["gap_detected"] for r in rows]
    rates.bar(places+offset,detected,label=label,color=color,width=.31)
rates.set_ylim(0,68)
rates.set_ylabel("Known gaps detected\nof 64 fresh draws")
rates.set_xticks(places,[r["id"].split("-",1)[1] for r in rows],fontsize=9)
rates.legend(fontsize=8,loc="upper center",bbox_to_anchor=(.5,-.12),ncol=2,frameon=False)
for axes in (scores,rates):
    axes.spines[["top","right"]].set_visible(False)
    axes.grid(axis="y",alpha=.15)
image=ROOT/"gap-oracle.png"
fig.savefig(image,dpi=166)
write_json(ROOT/"gap-oracle-figure.json",{"script":reference(__file__),"oracle":reference(ROOT/"oracle.json"),
    "nomination":reference(ROOT/"nomination.json"),"image":reference(image),
    "scope":"Fixed prior synthetic cases. Crosses use a different split. Bottom uses known background and gap in held-out samples with cutoff 3.25."})
