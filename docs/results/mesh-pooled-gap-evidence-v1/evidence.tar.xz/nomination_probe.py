"""Development replay of the larger nomination set on the earlier fixed high-noise cases."""

from pathlib import Path
import importlib.util
import os
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint
import torch

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/"mesh-shrunk-footprint-v1"
sys.path.insert(1,str(OLD))
spec = importlib.util.spec_from_file_location("earlier_driver",OLD/"panel-fixed.py")
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
from deliver import CENTRE, DISPLAY, Carrier, proposals, score, window
from extended_scope import audit
from mesh import ribbon


def run():
    old = read_json(OLD/"fixed-plan.json")
    cases = [e for e in old["cases"] if e["profile"]=="iso6400"]
    assert len(cases)==12
    path = ROOT/"nomination-plan.json"
    write_json(path,{"earlier":reference(OLD/"fixed-plan.json"),"source":reference(__file__),
                     "methods":reference(ROOT/"extended_scope.py"),"cases":cases,
                     "scope":"Development-only larger nomination bank on previously scored high-noise RAW."})
    results=[]
    for entry in cases:
        name=entry["id"]
        source=OLD/"fresh"/f"{name}.json"
        row=read_json(source)
        role=next(v for v in row["proof"]["matching"]["roles"] if v["role"]==1)
        if "central_pair" not in role:
            results.append({"id":name,"measured":False,"previous":reference(source)})
            continue
        noise=old["noise"][entry["profile"]]
        with np.load(checked(row["arrays"]),allow_pickle=False) as f:
            values={k:f[k] for k in ("colors","packed","variance","parent","target",
                        "strong_phase","weak_phase","support","matching/broad","matching/footprint","matching/half")}
        packed,variance,colors=(values[k][1] for k in ("packed","variance","colors"))
        local=window(packed,CENTRE,phase=2)
        carriers=tuple(Carrier(**r) for r in role["central_pair"])
        sites=native_sites(local.shape[-2:],(-127.5,-127.5))
        p,q=(ribbon(*sites,c) for c in carriers)
        fx,fy=carriers[0].frequency
        cuts,proof=audit(local,colors,p,q,noise,CENTRE,DISPLAY,float(np.arctan2(fy,fx)))
        admitted=any(x["accepted"]for x in proof["options"].values())
        scores=None
        if admitted:
            observation,contexts,_,_,_=original.observe(entry,noise)
            np.testing.assert_array_equal(observation["packed"].numpy(),values["packed"])
            exterior=contexts["matching"]
            _,trace=proposals(exterior,colors,(256,256,256,256),noise,80)
            config,moved,_=original.base.prepare(lambda x,y,s: window(exterior,(x,y,s,s),phase=2),
                                                trace,colors,noise,(383.5,383.5))
            parent,target=values["parent"],values["target"]
            stable,rear,_=original.base.reconstruct(parent[1],packed,variance,colors,CENTRE,DISPLAY,noise,
                                                    config,moved if role["carried"] else None)
            np.testing.assert_array_equal(stable,values["matching/broad"][1])
            out={}
            for label,cut in cuts.items():
                field=values["matching/half"].copy()
                field[1]=(field[1]-rear*cut[None]).astype(field.dtype)
                out[label]=field
            support={k:values[k]for k in ("strong_phase","weak_phase","support")}
            scores={k:score(parent,v,target,support)for k,v in out.items()}
            dest=ROOT/"extended"
            dest.mkdir(exist_ok=True)
            fname=dest/f"{name}.npz"
            np.savez_compressed(fname,**out)
            scores["arrays"]=reference(fname)
        results.append({"id":name,"measured":True,"previous":reference(source),"proof":proof,"scores":scores})
        print(name,[(k,v["accepted"],round(v["holdout"]["z"],2),v["nomination"]["kind"])for k,v in proof["options"].items()],
              None if scores is None else {k:s["gap_added_RMS_DN16"]for k,s in scores.items()if k!="arrays"},flush=True)
    write_json(ROOT/"nomination.json",{"plan":reference(path),"results":results})


if __name__=="__main__":
    os.sched_setaffinity(0,[14])
    os.nice(12)
    torch.set_num_threads(1)
    run()
