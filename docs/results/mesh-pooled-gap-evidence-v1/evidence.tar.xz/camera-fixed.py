"""Play the refined edge veto on cached GFX observations and render native crops."""

import importlib.util
import os
from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_frequency import ADJACENT_SEARCH, adjacent_prior, infer_prior
from demosaic._mesh_profiles import ribbon
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.mesh_refinement import _overlap_correction

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "mesh-envelope-support-v1"
sys.path.insert(1, str(SOURCE))
spec = importlib.util.spec_from_file_location("earlier_camera", SOURCE / "camera_step.py")
earlier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)
from deliver import window
sys.path.insert(2, str(ROOT.parent / "mesh-refined-edge-v1"))
sys.path.insert(3, str(ROOT.parent / "mesh-shrunk-footprint-v1"))
from pooled_gap_audit_20261118 import gap_audit
from standing import legacy


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2)) * 65535)


def run():
    rendered = read_json(ROOT.parent / "mesh-shrunk-footprint-v1" / "camera.json")
    by_id = {r["id"]: r for r in rendered["views"]}
    precise = {r["id"]: r for r in read_json(ROOT.parent / "donor-phase-transport-v1" / "port.json")["cases"]}
    frames = read_json(ROOT.parent / "local-mesh-phase-evidence-v1" / "camera.json")
    dest = ROOT / "camera-verified"
    dest.mkdir()
    rows = []
    for frame in frames["views"]:
        key = frame["id"]
        rec = by_id[key]
        query, roi, noise = (frame[k] for k in ("query", "ROI", "noise"))
        with np.load(checked(rec["arrays"]), allow_pickle=False) as f:
            packaged, prior_gap = (f[k] for k in ("packaged", "footprint"))
        with np.load(checked(frame["input"]), allow_pickle=False) as f:
            raw, var, cfa = (f[k][0] for k in ("packed", "variance", "colors"))
            color = {k: f[k] for k in ("wb", "matrix")}
        parent = np.load(checked(frame["parent"]), allow_pickle=False)[0]
        trunk = window(parent, roi)
        pool = no_floor = packaged
        proof = None
        if np.any(packaged != trunk):
            donors = infer_prior(raw, cfa, query, noise, span=precise[key]["noise"]["donor_span"])
            opts = {}
            delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors)
            if delta is None or not delta.any():
                donors = adjacent_prior(raw, cfa, query, noise)
                opts = {"search": ADJACENT_SEARCH}
                delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(trunk + delta, packaged)
            all_delta, rear = earlier.front_field(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(all_delta, delta)
            sample = window(raw, query, phase=2)
            positions = native_sites(sample.shape[-2:], (-127.5, -127.5))
            p, q = (ribbon(*positions, v) for v in pair)
            cuts, proof = gap_audit(sample,cfa,p,q,noise,query,roi)
            def corrected(cut):
                if not proof["global_keep"]:
                    return trunk + (delta - rear).astype(delta.dtype)
                return trunk + (delta - rear*cut[None]).astype(delta.dtype)
            np.testing.assert_array_equal(corrected(cuts["old"]), prior_gap)
            pool = corrected(cuts["pool"])
            no_floor = corrected(cuts["pool-no-floor"])
        w,h = roi[2:]
        panels = [(label,legacy.pixel(value,color,(0,0,w,h),rec["exposure"]))
                  for label,value in (("Pooled audit",pool),("Pooled without floor",no_floor))]
        before = {"image":rec["image"],"panels":[p for p in rec["panels"] if p["label"]!="Half forecast"]}
        image, coords = legacy.insert_camera_panels(dest,key,before,"Finite support",panels)
        fn = dest / f"{key}.npz"
        np.savez_compressed(fn,packaged=packaged,old=prior_gap,pool=pool,no_floor=no_floor,parent=trunk)
        difference={"pool_vs_packaged":rms(pool-packaged),"no_floor_vs_packaged":rms(no_floor-packaged),
                    "old_vs_packaged":rms(prior_gap-packaged),"pool_vs_old":rms(pool-prior_gap),
                    "no_floor_vs_pool":rms(no_floor-pool)}
        rows.append({k:rec[k] for k in ("id","source","RAW","parent","exposure","ROI","query","noise")} |
                    {"image":image,"panels":coords,"proof":proof,"changes_DN16":difference,
                     "arrays":reference(fn)})
        print(key,difference,proof and (proof["pooled"],proof["accepted"]),flush=True)
    assert len(rows) == 8
    write_json(ROOT / "camera.json", {"sources": [reference(__file__), reference(ROOT / "pooled_gap_audit_20261118.py")],
                                     "prior": reference(ROOT.parent / "mesh-shrunk-footprint-v1" / "camera.json"),
                                     "checkpoint": rendered["checkpoint"], "views": rows,
                                     "scope": "Native 100 percent qualitative playback. Same saved parent and same reproduced packaged deltas."})


if __name__ == "__main__":
    os.sched_setaffinity(0, [15])
    os.nice(12)
    run()
