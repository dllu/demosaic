"""Bind the saved 8,500 trace and verify the failed attempt's replay."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
OUT=Path("docs/results/scene-full-epoch-v1")


def main():
    latest=reference(OUT/"paired-prefix-008000.json")
    original=read_json(checked(latest))
    plan=read_json(checked(original["training"]))
    first=read_json(checked(original["last_7500_proof"]))
    previous=[e["observations"]for e in first["arms"]["none"]["phases"]]
    previous.append(original["segments"]["8000"]["none"]["observations"])
    with checked(plan["train_manifest"]).open() as stream:
        train={json.loads(line)["id"]for line in stream}
    assert len(train)==90692
    assert original["trace_equal_through"]==8000
    segments,recordings=[],[]
    for mode in ("none","spatial"):
        folder=ROOT/f"{mode}-010000"/"segments/through-008500"
        pointer=reference(folder/"verified.json")
        verified=read_json(checked(pointer))
        receipt=read_json(checked(verified["receipt"]))
        expected=original["segments"]["8000"][mode]["checkpoint"]
        assert receipt["resume"]==expected and receipt["plan"]==original["training"]
        assert receipt["DINO_unchanged"] and receipt["schedule_steps"]==50000
        assert receipt["steps"]==8500 and receipt["start_step_exclusive"]==8000
        assert receipt["checkpoints"][-1]==verified["checkpoint"]
        checked(verified["checkpoint"])
        recordings.extend(((pointer,f"{mode}/verified.json"),(verified["receipt"],f"{mode}/completed.json")))
        segments.append(verified)
    local,spatial=segments
    assert local["observations"]["sha256"]==spatial["observations"]["sha256"]
    prior_trace=previous+[local["observations"]]
    photos=set()
    seeds=set()
    total=0
    for bind in prior_trace:
        with checked(bind).open() as stream:
            for d in map(json.loads,stream):
                key,noise=d["source_id"],d["recipe"]["noise_seed"]
                assert d["index"]==len(photos) and key in train and key not in photos and noise not in seeds
                photos.add(key)
                seeds.add(noise)
                total+=len(d["boxes_xywh"])
    assert len(photos)==len(seeds)==17000 and total==68000
    old=read_json(OUT/"spatial-retry-008500.json")
    failure=checked(old["failure"]["work/observations.jsonl"]).read_bytes()
    assert checked(spatial["observations"]).read_bytes().startswith(failure)
    replay_length=len(failure.splitlines())
    owner=reference(ROOT/"owner.json")
    assert owner_live(read_json(checked(owner)))
    running=read_json(ROOT/"status.json")
    later=ROOT/"spatial-010000/segments/through-009000"
    for attempt in sorted(later.glob("attempt-*")):
        exit_file=attempt/"exit.json"
        if exit_file.exists():
            for name in ("launch.json","exit.json","worker.log","work/train.jsonl","work/observations.jsonl"):
                pointer=reference(attempt/name)
                recordings.append((pointer,f"later-9000/{attempt.name}/{name}"))
    bundle=OUT/"paired-prefix-008500.tar.xz"
    with tarfile.open(bundle,"x:xz") as archive:
        for ref,member in recordings:
            archive.add(checked(ref),arcname=member)
        archive.add(Path(__file__),arcname=Path(__file__).name)
    write_json(OUT/"paired-prefix-008500.json",{"training":original["training"],"previous":latest,"matched_update":8500,
        "unique_photos_per_arm":len(photos),"unique_noise_seeds_per_arm":len(seeds),"native_queries_per_arm":total,
        "local":local,"spatial":spatial,"bit_identical_replayed_scene_records":replay_length,"quality_complete_through":7500,
        "live_controller":owner,"controller_state":running,"archived_files":dict((path,ref)for ref,path in recordings),
        "archive":reference(bundle)})
    print(len(photos),total,replay_length,flush=True)


if __name__=="__main__":
    main()
