"""Verify the complete local-only schedule and leave quality states distinct."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.photo_epoch_order import PhotoEpochOrder

ROOT=Path(__file__).resolve().parent
RESULTS=Path('docs/results/scene-full-epoch-v1')
START=47500
END=50000
FIRST=45346


def load(ref):
    return read_json(checked(ref))


def main():
    milestone=reference(RESULTS/f'paired-prefix-{START:06d}.json')
    same=load(milestone)
    initial=load(same['prior'])
    plan=load(same['plan'])
    raw_manifest=checked(plan['train_manifest'])
    with raw_manifest.open()as f:
        train=list(map(json.loads,f))
    order_header=checked(plan['photo_epoch_order'])
    order=PhotoEpochOrder(order_header,raw_manifest,train,read_json(order_header)['reader_policy'],
                          expected_sha256=plan['photo_epoch_order']['sha256'])
    assert len(train)==2*FIRST and plan['steps']==END
    final_proof=reference(ROOT/f'none-{END:06d}/verified.json')
    local=load(final_proof)
    complete=load(local['receipt'])
    assert complete['mode']=='none' and complete['steps']==END and complete['schedule_steps']==END
    assert complete['start_step_exclusive']==START and complete['resume']==same['arms']['none']['checkpoint']
    assert complete['plan']==same['plan'] and complete['DINO_unchanged']
    seeds=set()
    for trace in initial['traces']:
        with checked(trace).open()as stream:
            seeds.update(row['recipe']['noise_seed'] for row in map(json.loads,stream))
    assert len(seeds)==2*FIRST
    index=2*FIRST
    new_epoch=set()
    def ordered(rows):
        nonlocal index
        for line in rows:
            entry=json.loads(line)
            assert entry['index']==index and entry['photo_epoch_order_sha256']==plan['photo_epoch_order']['sha256']
            name=entry['source_id']
            seed=entry['recipe']['noise_seed']
            assert order.ordinary(index)['id']==name and name not in new_epoch and seed not in seeds
            assert len(entry['boxes_xywh'])==4
            new_epoch.add(name)
            seeds.add(seed)
            index+=1
            yield entry
    with checked(same['arms']['none']['observations']).open()as trace:
        visited=sum(1 for _ in ordered(trace))
    assert visited==2*(START-FIRST) and index==2*START
    previous=same['arms']['none']['checkpoint']
    last=START
    digest=hashlib.sha256()
    segments=[]
    directions=Counter()
    for binding in complete['segments']:
        receipt=load(binding)
        assert receipt['resume']==previous and receipt['start_step_exclusive']==last
        assert receipt['plan']==same['plan'] and receipt['DINO_unchanged'] and receipt['schedule_steps']==END
        previous=receipt['checkpoints'][-1]
        checked(previous)
        last=receipt['steps']
        def bind_trace(stream):
            for line in stream:
                digest.update(line)
                yield line
        with checked(receipt['observations']).open('rb')as trace:
            for entry in ordered(bind_trace(trace)):
                contrast=entry.get('local_contrast')
                scene_type='plain' if contrast is None else ('flat' if contrast.get('exact_flat_core',False) else 'weak')
                directions[scene_type]+=1
        segments.append(dict(update=last,checkpoint=previous,receipt=binding,observations=receipt['observations']))
    assert index==2*END==len(seeds) and len(new_epoch)==2*(END-FIRST)
    assert directions==local['scene_types'] and previous==local['checkpoint'] and last==END
    checked(local['observations'])
    assert digest.hexdigest()==local['observations']['sha256']
    archive=RESULTS/f'local-{END:06d}-training.tar.xz'
    with tarfile.open(archive,'x:xz')as tar:
        tar.add(Path(__file__),arcname=Path(__file__).name)
        tar.add(checked(final_proof),arcname='local-verified.json')
        tar.add(checked(local['receipt']),arcname='local-completed.json')
        for segment in segments:
            tar.add(checked(segment['receipt']),arcname=f"local-{segment['update']:06d}.json")
    retained=same['retained_training_seconds']['none']+complete['seconds']
    write_json(archive.with_suffix('').with_suffix('.json'),dict(arm='local-only',paired_through=milestone,
         completion=final_proof,checkpoint=local['checkpoint'],segments=segments,training_complete=True,
         numerical_review_complete=False,native_review_complete=False,last_quality_scope='paired scoped 47,500 review',
         plan=same['plan'],parent=plan['parent'],schedule_updates=END,photos_per_complete_epoch=len(train),
         observed_photo_visits=index,second_pass_distinct_visits=len(new_epoch),native_queries=4*index,
         distinct_noise_seeds=len(seeds),retained_training_seconds=retained,archive=reference(archive)))
    print(index,len(new_epoch),retained,flush=True)


if __name__=='__main__':
    main()
