"""Verify matched 10,500 coverage against the durable 10k prefix."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
DOC=Path("docs/results/scene-full-epoch-v1")


def main():
    old=reference(DOC/"matched-010000-training.json")
    matched=read_json(checked(old))
    frozen=read_json(checked(matched["training"]))
    plan=frozen["plan"]
    assert frozen["through_update"]==10000 and frozen["matched_input_traces"]
    local=reference(DOC/"local-012000-prefix.json")
    local_plan=read_json(checked(local))
    assert local_plan["run"]==plan
    cfg=read_json(checked(plan))
    with checked(cfg["train_manifest"]).open()as f:
        available={json.loads(line)["id"] for line in f}
    progress=[]
    receipt={}
    sources={}
    for arm in ("none","spatial"):
        folder=ROOT/f"{arm}-012000/segments/through-010500"
        bind=reference(folder/"verified.json")
        found=read_json(checked(bind))
        worker=read_json(checked(found["receipt"]))
        assert worker["plan"]==plan and worker["DINO_unchanged"]
        assert (worker["schedule_steps"],worker["start_step_exclusive"],worker["steps"])==(50000,10000,10500)
        assert worker["checkpoints"][-1]==found["checkpoint"]
        assert worker["resume"]==frozen["arms"][arm]["checkpoint"]
        checked(found["checkpoint"])
        trace=checked(found["observations"])
        sources[arm]=reference(trace)
        progress.extend(((found["receipt"],f"{arm}/completed.json"),(bind,f"{arm}/verified.json")))
        receipt[arm]=found|{"verified":bind}
    assert sources["none"]["sha256"]==sources["spatial"]["sha256"]
    trace=[r["observations"] for r in matched["arms"]["none"]["phases"]]+[sources["none"]]
    images=set()
    seeds=set()
    crops=0
    for t in trace:
        with checked(t).open()as f:
            for row in map(json.loads,f):
                key,noise=row["source_id"],row["recipe"]["noise_seed"]
                assert row["index"]==len(images) and key in available and key not in images and noise not in seeds
                images.add(key)
                seeds.add(noise)
                crops+=len(row["boxes_xywh"])
    assert len(images)==len(seeds)==21000 and crops==84000
    owner=reference(ROOT/"owner.json")
    assert owner_live(read_json(checked(owner)))
    archive=DOC/"paired-prefix-010500.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for item,relative in progress:
            f.add(checked(item),arcname=relative)
        f.add(Path(__file__),arcname=Path(__file__).name)
    write_json(DOC/"paired-prefix-010500.json",{
        "previous_matched":old,"training_plan":plan,"latest_local_only":local,
        "through_update":10500,"photos_per_arm":len(images),"noise_seeds_per_arm":len(seeds),
        "native_queries_per_arm":crops,"numeric_and_native_review_complete_through":10000,
        "arms":receipt,"controller":owner,"archive":reference(archive)})
    print(len(images),crops,receipt["spatial"]["checkpoint"]["sha256"])


if __name__=="__main__":
    main()
