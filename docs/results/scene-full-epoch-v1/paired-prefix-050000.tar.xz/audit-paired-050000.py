"""Close the matched 50k data, checkpoint and timing ledger."""
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path("docs/results/scene-full-epoch-v1")
MODES = ("none", "spatial")
START, END = 47500, 50000


def bound(binding):
    return read_json(checked(binding))


def main():
    previous = reference(RESULTS / f"paired-prefix-{START:06d}.json")
    prior = bound(previous)
    local_ref = reference(RESULTS / f"local-{END:06d}-training.json")
    local = bound(local_ref)
    marker = reference(ROOT / f"matched-{END:06d}.json")
    match = bound(marker)
    assert (match["first_step_exclusive"], match["through_update"]) == (START, END)
    assert match["matched_input_traces"] and match["training_complete"]
    assert match["plan"] == prior["plan"] == local["plan"]
    plan = bound(match["plan"])
    assert local["paired_through"] == previous and local["schedule_updates"] == END
    assert local["training_complete"] and local["distinct_noise_seeds"] == local["observed_photo_visits"]
    assert local["checkpoint"] == match["arms"]["none"]["checkpoint"]

    traces, segments, runtime = {}, {}, {}
    for mode in MODES:
        arm = match["arms"][mode]
        assert bound(reference(ROOT / f"{mode}-{END:06d}/verified.json")) == arm
        phase = bound(arm["receipt"])
        assert phase["plan"] == match["plan"] and phase["DINO_unchanged"]
        assert phase["resume"] == prior["arms"][mode]["checkpoint"]
        assert (phase["start_step_exclusive"], phase["steps"], phase["schedule_steps"]) == (START, END, END)
        assert phase["observations"] == arm["observations"]
        checked(arm["observations"])
        traces[mode] = arm["observations"]["sha256"]
        runtime[mode] = phase["seconds"]
        chain = []
        last, start = phase["resume"], START
        for proof in phase["segments"]:
            segment = bound(proof)
            assert segment["resume"] == last and segment["start_step_exclusive"] == start
            assert segment["plan"] == match["plan"] and segment["DINO_unchanged"]
            last = segment["checkpoints"][-1]
            start = segment["steps"]
            checked(last)
            checked(segment["observations"])
            chain.append(dict(receipt=proof, update=start, observations=segment["observations"], checkpoint=last))
        assert start == END and last == arm["checkpoint"]
        segments[mode] = chain
    assert traces["none"] == traces["spatial"]
    for a, b in zip(segments["none"], segments["spatial"], strict=True):
        assert a["update"] == b["update"] and a["observations"]["sha256"] == b["observations"]["sha256"]
    assert len(segments["none"]) == 5
    retained = {mode: prior["retained_training_seconds"][mode] + runtime[mode] for mode in MODES}
    assert retained["none"] == local["retained_training_seconds"]

    result = RESULTS / f"paired-prefix-{END:06d}.json"
    archive = result.with_suffix(".tar.xz")
    with tarfile.open(archive, "x:xz") as tar:
        tar.add(__file__, arcname=Path(__file__).name)
        tar.add(checked(marker), arcname="matched.json")
        for mode, rows in segments.items():
            tar.add(checked(match["arms"][mode]["receipt"]), arcname=f"{mode}/combined.json")
            for row in rows:
                tar.add(checked(row["receipt"]), arcname=f'{mode}/{row["update"]:06d}.json')
    write_json(result, dict(
        prior=previous, local_source_order_proof=local_ref, matched_marker=marker,
        matched_to_update=END, plan=match["plan"], parent=plan["parent"], arms=match["arms"],
        matched_segments=segments, observations_per_arm=local["observed_photo_visits"],
        queries_per_arm=local["native_queries"], distinct_noise_seeds_per_arm=local["distinct_noise_seeds"],
        distinct_eligible_photos=local["photos_per_complete_epoch"],
        second_pass_distinct_visits=local["second_pass_distinct_visits"],
        retained_training_seconds=retained, retained_47500_to_50000_seconds=runtime,
        training_schedule_updates=END, archive=reference(archive), training_complete=True,
        canonical_quality_complete_at_publication=False, paired_native_quality_complete_at_publication=False,
        prior_paired_quality_update=START, local_scoped_quality=reference("docs/results/local50000-scoped-v1/publication.json"),
    ))
    print(match["arms"]["spatial"]["checkpoint"], retained, flush=True)


if __name__ == "__main__":
    main()
