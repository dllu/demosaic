#!/usr/bin/env bash
set -euo pipefail
root=/home/dllu/proj/demosaic/.cache/experiments/scene-full-epoch-v1
store=$(mktemp -d /mnt/external/demosaic/scene-full-epoch-storage.XXXXXXXX)
printf 'SSD directory %s\n' "$store"
df -h "$root" "$store"
for name in review-020000 review-full-025000 review-full-030000 review-full-035000 review-full-040000 \
            none-030000 spatial-030000 none-032500 spatial-032500 none-035000 spatial-035000; do
    source="$root/$name"
    target="$store/$name"
    test -d "$source" && test ! -L "$source"
    mkdir "$target"
    rsync -aH -- "$source/" "$target/"
    delta=$(rsync -aH --checksum --dry-run --delete --itemize-changes -- "$source/" "$target/")
    test -z "$delta"
    retained="$root/.$name-copy-verified"
    mv -- "$source" "$retained"
    ln -s -- "$target" "$source"
    rm -r -- "$retained"
    printf 'Verified checksum-matched relocation %s\n' "$name"
done
for name in none-045000 spatial-045000 none-045346 spatial-045346 none-047500 spatial-047500 none-050000 spatial-050000; do
    source="$root/$name"
    target="$store/$name"
    mkdir "$target"
    if test -d "$source"; then
        rsync -aH -- "$source/" "$target/"
        delta=$(rsync -aH --checksum --dry-run --delete --itemize-changes -- "$source/" "$target/")
        test -z "$delta"
        retained="$root/.$name-copy-verified"
        mv -- "$source" "$retained"
        ln -s -- "$target" "$source"
        rm -r -- "$retained"
    else
        ln -s -- "$target" "$source"
    fi
    printf 'SSD output path %s\n' "$name"
done
df -h "$root" "$store"
