"""Compare both standing scene milestones without changing any crop pixels."""
from pathlib import Path
import sys
import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


def main():
    cases=[]
    names={}
    for step in (25000,30000):
        item=reference(ROOT/f"review-native-{step:06d}/work/render/result.json")
        data=read_json(checked(item))
        cases.append(item)
        names[step]={row["id"]:row for row in data["boards"]if row["id"].startswith(("main-","mesh-"))}
    assert set(names[25000])==set(names[30000])
    output=ROOT/"review-native-030000/paired-with-025000"
    output.mkdir()
    rows=[]
    for name,old in names[25000].items():
        current=names[30000][name]
        assert old["input_arrays"]==current["input_arrays"]
        assert old["case"]["ROI_xywh"]==current["case"]["ROI_xywh"]
        assert old["noise"]==current["noise"] and old["display_exposure"]==current["display_exposure"]
        parts=[]
        for step,row in ((25000,old),(30000,current)):
            required=(f"Local-only {step//1000}k EMA",f"Spatial {step//1000}k EMA")
            with Image.open(checked(row["image"]))as image:
                for panel in row["panels"]:
                    label=panel["label"]
                    if label in required:
                        x,y,w,h=panel["png_xywh"]
                        assert (w,h)==(160,160)
                        parts.append((label,np.asarray(image.crop((x,y,x+w,y+h)).convert("RGB"))))
        assert len(parts)==4
        rows.append({"id":name,"image":native_png(output/(name+".png"),parts),
                     "input_arrays":old["input_arrays"],"display_exposure":old["display_exposure"],
                     "roi":old["case"]["ROI_xywh"],"noise":old["noise"]})
    write_json(output/"manifest.json",{"driver":reference(__file__),"source_result_bindings":cases,"rows":rows})


if __name__=="__main__":
    main()
