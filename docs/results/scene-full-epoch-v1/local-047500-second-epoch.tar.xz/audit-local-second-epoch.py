"""Verify the first 4,308 second-epoch local observations and continuation chain."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.photo_epoch_order import PhotoEpochOrder

ROOT=Path(__file__).resolve().parent
RESULTS=Path('docs/results/scene-full-epoch-v1')
FIRST,END=45346,47500


def bound(ref):
    return read_json(checked(ref))


def main():
    prior=reference(RESULTS/f'paired-prefix-{FIRST:06d}.json')
    first=bound(prior)
    plan=bound(first['plan'])
    manifest=checked(plan['train_manifest'])
    with manifest.open()as stream:
        photos=list(map(json.loads,stream))
    header=checked(plan['photo_epoch_order'])
    policy=read_json(header)['reader_policy']
    permutation=PhotoEpochOrder(header,manifest,photos,policy,expected_sha256=plan['photo_epoch_order']['sha256'])
    expected=len(photos)
    assert expected==2*FIRST and len(set(permutation.values[:expected]))==expected
    verified=reference(ROOT/f'none-{END:06d}/verified.json')
    local=bound(verified)
    finished=bound(local['receipt'])
    assert (finished['mode'],finished['start_step_exclusive'],finished['steps'],finished['schedule_steps'])==('none',FIRST,END,50000)
    checkpoint=first['arms']['none']['checkpoint']
    assert finished['plan']==first['plan'] and finished['resume']==checkpoint and finished['DINO_unchanged']
    prefix_seeds=set()
    for ref in first['traces']:
        with checked(ref).open() as stream:
            prefix_seeds.update(row['recipe']['noise_seed'] for row in map(json.loads,stream))
    assert len(prefix_seeds)==expected
    counter=Counter()
    visited=set()
    index=expected
    query_count=0
    first_step=FIRST
    checkpoints=[]
    digest=hashlib.sha256()
    for segment in finished['segments']:
        proof=bound(segment)
        assert proof['resume']==checkpoint and proof['plan']==first['plan'] and proof['DINO_unchanged']
        assert proof['start_step_exclusive']==first_step and proof['schedule_steps']==50000
        checkpoint=proof['checkpoints'][-1]
        checked(checkpoint)
        checkpoints.append(checkpoint)
        first_step=proof['steps']
        with checked(proof['observations']).open('rb') as stream:
            for line in stream:
                digest.update(line)
                row=json.loads(line)
                key=row['source_id']
                seed=row['recipe']['noise_seed']
                assert row['index']==index and key==permutation.ordinary(index)['id']
                assert key not in visited and seed not in prefix_seeds and len(row['boxes_xywh'])==4
                visited.add(key)
                prefix_seeds.add(seed)
                query_count+=len(row['boxes_xywh'])
                index+=1
                contrast=row.get('local_contrast')
                category='plain' if contrast is None else ('flat' if contrast.get('exact_flat_core',False) else 'weak')
                counter[category]+=1
    assert index==2*END and len(visited)==index-expected
    assert len(prefix_seeds)==index and query_count==len(visited)*4
    assert counter==local['scene_types']
    assert checkpoint==local['checkpoint'] and checkpoints==finished['checkpoints']
    checked(local['observations'])
    assert digest.hexdigest()==local['observations']['sha256']==finished['observations']['sha256']
    archive=RESULTS/f'local-{END:06d}-second-epoch.tar.xz'
    with tarfile.open(archive,'x:xz')as tar:
        tar.add(Path(__file__),arcname=Path(__file__).name)
        tar.add(checked(verified),arcname='local-verified.json')
        tar.add(checked(local['receipt']),arcname='local-combined-completed.json')
        for ref in finished['segments']:
            receipt=bound(ref)
            tar.add(checked(ref),arcname=f"local-{receipt['steps']:06d}-completed.json")
    write_json(archive.with_name(f'local-{END:06d}-second-epoch.json'),
               dict(first_epoch=prior,arm='local-only',checkpoint=checkpoint,verified=verified,archive=reference(archive),
                    verified_to_update=END,schedule_updates=50000,last_matched_update=FIRST,
                    visits_second_epoch=len(visited),distinct_sources_second_epoch=len(visited),
                    queries_second_epoch=query_count,total_queries=index*4,total_observations=index,
                    eligible_training_photos=expected,retained_additional_seconds=finished['seconds'],
                    latest_completed_paired_quality_update=40000,scope='Intermediate endpoint and source trace audit.'))
    print(END,len(visited),query_count,finished['seconds'],flush=True)


if __name__=='__main__':
    main()
