"""Verify resumed 9,000-update coverage and its durable phase endpoints."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
OUT=Path("docs/results/scene-full-epoch-v1")


def publish():
    bound=reference(OUT/"paired-prefix-008500.json")
    facts=read_json(checked(bound))
    earlier=read_json(checked(facts["previous"]))
    original=read_json(checked(earlier["last_7500_proof"]))
    order=[p["observations"]for p in original["arms"]["none"]["phases"]]
    order.extend((earlier["segments"]["8000"]["none"]["observations"],facts["local"]["observations"]))
    assert facts["matched_update"]==8500
    retained={}
    media=[]
    archive=OUT/"paired-prefix-009000.tar.xz"
    for arm,record in (("none","local"),("spatial","spatial")):
        phase=ROOT/f"{arm}-010000/segments/through-009000"
        verified=reference(phase/"verified.json")
        info=read_json(checked(verified))
        outcome=read_json(checked(info["receipt"]))
        assert outcome["resume"]==facts[record]["checkpoint"]
        assert outcome["DINO_unchanged"] and outcome["plan"]==facts["training"]
        assert outcome["schedule_steps"]==50000 and (outcome["start_step_exclusive"],outcome["steps"])==(8500,9000)
        assert outcome["checkpoints"][-1]==info["checkpoint"]
        checked(info["checkpoint"])
        attempts={}
        trace=checked(info["observations"]).read_bytes()
        for failed in sorted(phase.glob("attempt-*/exit.json")):
            if not read_json(failed)["returncode"]:
                continue
            captured=reference(failed.parent/"work/observations.jsonl")
            prefix=checked(captured).read_bytes()
            assert trace.startswith(prefix)
            attempts[failed.parent.name]=len(prefix.splitlines())
        retained[arm]=info|{"verified":verified,"identical_replayed_prefix_rows":attempts}
        media.append((verified,f"{arm}/verified.json"))
        media.append((info["receipt"],f"{arm}/completed.json"))
    l,r=(retained[k]["observations"]for k in ("none","spatial"))
    assert l["sha256"]==r["sha256"]
    order.append(l)
    identifiers,seeds=set(),set()
    count=0
    plan=read_json(checked(facts["training"]))
    with checked(plan["train_manifest"]).open()as stream:
        allowed={json.loads(line)["id"]for line in stream}
    for trace in order:
        with checked(trace).open()as stream:
            for row in map(json.loads,stream):
                ref,seed=row["source_id"],row["recipe"]["noise_seed"]
                assert row["index"]==len(identifiers) and ref in allowed and ref not in identifiers and seed not in seeds
                identifiers.add(ref)
                seeds.add(seed)
                count+=len(row["boxes_xywh"])
    owner=reference(ROOT/"owner.json")
    assert owner_live(read_json(checked(owner)))
    assert len(identifiers)==len(seeds)==18000 and count==72000
    with tarfile.open(archive,"x:xz")as f:
        for item,relative in media:
            f.add(checked(item),arcname=relative)
        f.add(Path(__file__),arcname=Path(__file__).name)
    write_json(OUT/"paired-prefix-009000.json",{
        "previous":bound,"training":facts["training"],"matched_update":9000,
        "unique_photos_per_arm":len(identifiers),"native_queries_per_arm":count,"unique_noise_seeds_per_arm":len(seeds),
        "quality_complete_through":7500,"live_controller":owner,"segments":retained,"archive":reference(archive)})
    print(len(identifiers),count,retained["spatial"]["identical_replayed_prefix_rows"],flush=True)


if __name__=="__main__":
    publish()
