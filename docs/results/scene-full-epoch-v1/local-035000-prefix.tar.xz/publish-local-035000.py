"""Verify the local-only continuation beyond the 30,000 matched prefix."""
import json
from pathlib import Path
import tarfile
import sys

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results/scene-full-epoch-v1')
endpoint=int(sys.argv[1])
assert 33000 <= endpoint <= 35000 and endpoint % 500 == 0
matched = reference(OUT/'paired-prefix-012500.json')
start = read_json(checked(matched))
prior = read_json(checked(start['last_paired']))
plan = read_json(checked(start['plan']))
with checked(plan['train_manifest']).open() as file:
    eligible = {json.loads(row)['id'] for row in file}
trace = [r['observations'] for r in prior['arms']['none']['phases']]+[start['arms']['none']['observations']]
later = {}
final = start['arms']['none']['checkpoint']
for step in range(13000,endpoint+1,500):
    segment_root = ('none-015000' if step <= 15000 else
                    'none-017500' if step <= 17500 else
                    'none-020000' if step <= 20000 else
                    "none-022500" if step <= 22500 else
                    "none-025000" if step <= 25000 else
                    "none-027500" if step <= 27500 else
                    "none-030000" if step <= 30000 else
                    "none-032500" if step <= 32500 else "none-035000")
    note = reference(ROOT/f'{segment_root}/segments/through-{step:06d}/verified.json')
    saved = read_json(checked(note))
    raw = read_json(checked(saved['receipt']))
    assert raw['plan']==start['plan'] and raw['DINO_unchanged']
    assert raw['resume']==final and (raw['start_step_exclusive'],raw['steps'])==(step-500,step)
    assert raw['schedule_steps']==50000
    final = saved['checkpoint']
    assert raw['checkpoints'][-1]==final
    checked(final)
    trace.append(saved['observations'])
    later[step] = saved|{'accepted':note}
visits, seeds = set(), set()
queries = 0
for binding in trace:
    with checked(binding).open() as stream:
        for r in map(json.loads,stream):
            photo, noise = r['source_id'],r['recipe']['noise_seed']
            assert r['index']==len(visits) and photo in eligible and photo not in visits and noise not in seeds
            visits.add(photo)
            seeds.add(noise)
            queries+=len(r['boxes_xywh'])
assert len(visits)==len(seeds)==2*endpoint and queries==8*endpoint
controller = reference(ROOT/'owner.json')
assert owner_live(read_json(checked(controller)))
archive = OUT/f'local-{endpoint:06d}-prefix.tar.xz'
with tarfile.open(archive,'x:xz') as pack:
    for step, row in later.items():
        pack.add(checked(row['accepted']),arcname=f'{step}/verification.json')
        pack.add(checked(row['receipt']),arcname=f'{step}/completed.json')
    pack.add(Path(__file__),arcname=Path(__file__).name)
write_json(OUT/f'local-{endpoint:06d}-prefix.json',{'scope':'Checkpoint verification only. The latest completed matched exact-photo and native reviews are at update 30000.',
           'paired_15000':reference(OUT/'paired-prefix-015000.json'),'prefix_link':matched,'plan':start['plan'],'controller':controller,'archive':reference(archive),'segments':later,
           'checkpoint':final,'verified_update':endpoint,'distinct_photos':len(visits),'native_queries':queries,
           'distinct_noise_seeds':len(seeds),'retained_training_seconds':start['arms']['none']['total_retained_training_seconds']+
                 sum(q['training_seconds'] for q in later.values())})
print(len(visits),queries,final['sha256'],flush=True)
