"""Run the 64-photo and both standing GFX reviews once the 20k pair is verified."""
from pathlib import Path
import sys
import subprocess
import time

from demosaic.experiments.artifacts import checked, read_json, reference
from demosaic.experiments.runtime import owner_live
from review_queue_native_fixed import wait

ROOT = Path(__file__).resolve().parent
STEP = 20000


def run(action):
    stage = ROOT / f"queue-{action}-{STEP:06d}.log"
    with stage.open("x") as log:
        cmd = (sys.executable, "-u", str(Path(__file__)), action)
        return subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=False).returncode


if len(sys.argv) == 1:
    owner = read_json(ROOT / "owner.json")
    marker = ROOT / f"matched-{STEP:06d}.json"
    print("Awaiting matched checkpoint", STEP, owner, flush=True)
    while not marker.exists():
        if not owner_live(owner):
            raise RuntimeError("Training owner stopped before the matched 20k checkpoint")
        time.sleep(20)
    scores, native = run("monitor"), run("native")
    print("Numerical and native worker exit codes", scores, native, flush=True)
    raise SystemExit(bool(scores or native))

proof, matched = wait(STEP)
assert matched["plan"] == reference(ROOT / "plan.json")
assert read_json(checked(proof))["through_update"] == STEP
if sys.argv[1] == "monitor":
    import monitor_full_020000 as monitor
    monitor.run(STEP)
else:
    from milestone_native_fixed import native
    native(ROOT / f"review-native-{STEP:06d}", proof, matched)
