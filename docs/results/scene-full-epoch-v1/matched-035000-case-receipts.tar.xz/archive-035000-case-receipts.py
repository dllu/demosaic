"""Preserve the complete set of 35k per-observation receipts without prediction arrays."""
import hashlib
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results/scene-full-epoch-v1")
stage = ROOT / "review-full-035000/evaluation"
measurement = reference(OUT / "matched-035000-monitor.json")
collection = read_json(checked(measurement))["collection"]
records = read_json(checked(collection))["records"]
assert len(records) == 256
paths = {f"cases/{Path(record['path']).name}": checked(record) for record in records}
assert len(paths) == 256
paths["collection.json"] = checked(collection)
paths[Path(__file__).name] = Path(__file__)
location = OUT / "matched-035000-case-receipts.tar.xz"
with tarfile.open(location, "x:xz", preset=4) as output:
    for label, path in sorted(paths.items()):
        output.add(path, arcname=label, recursive=False)
with tarfile.open(location) as archive:
    assert archive.getnames() == sorted(paths)
    for label, path in paths.items():
        with archive.extractfile(label) as f:
            assert hashlib.file_digest(f, "sha256").hexdigest() == reference(path)["sha256"]
write_json(OUT / "matched-035000-case-receipts.json",
           {"archive": reference(location), "exact_photo_panel": measurement, "collection": collection,
            "entries": len(paths), "observation_receipts": len(records)})
