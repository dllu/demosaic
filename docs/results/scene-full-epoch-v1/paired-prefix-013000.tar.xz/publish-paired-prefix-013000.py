"""Check both 13k segment receipts against the matching larger source schedule."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
OUT=Path('docs/results/scene-full-epoch-v1')
matched=reference(OUT/'paired-prefix-012500.json')
previous=read_json(checked(matched))
reviewed=read_json(checked(previous['last_paired']))
plan=read_json(checked(previous['plan']))
local=read_json(OUT/'local-015000-prefix.json')
views={}
for arm in ('none','spatial'):
    path=reference(ROOT/f'{arm}-015000/segments/through-013000/verified.json')
    note=read_json(checked(path))
    worker=read_json(checked(note['receipt']))
    assert worker['plan']==previous['plan'] and worker['DINO_unchanged']
    assert worker['resume']==previous['arms'][arm]['checkpoint']
    assert (worker['start_step_exclusive'],worker['steps'],worker['schedule_steps'])==(12500,13000,50000)
    assert worker['checkpoints'][-1]==note['checkpoint']
    checked(note['checkpoint'])
    views[arm]=note|{'verification':path}
assert views['none']['checkpoint']==local['segments']['13000']['checkpoint']
assert views['none']['observations']['sha256']==views['spatial']['observations']['sha256']
checked(views['spatial']['observations'])
paths=[r['observations']for r in reviewed['arms']['none']['phases']]+[previous['arms']['none']['observations'],views['none']['observations']]
with checked(plan['train_manifest']).open()as f:
    allowable={json.loads(line)['id']for line in f}
photos,seeds=set(),set()
slots=0
for binding in paths:
    with checked(binding).open()as f:
        for row in map(json.loads,f):
            item=row['source_id']
            seed=row['recipe']['noise_seed']
            assert row['index']==len(photos) and item not in photos and seed not in seeds and item in allowable
            photos.add(item)
            seeds.add(seed)
            slots+=len(row['boxes_xywh'])
assert len(photos)==len(seeds)==26000 and slots==104000
owner=reference(ROOT/'owner.json')
assert owner_live(read_json(checked(owner)))
archive=OUT/'paired-prefix-013000.tar.xz'
with tarfile.open(archive,'x:xz')as tar:
    for arm,note in views.items():
        tar.add(checked(note['verification']),arcname=arm+'/verified.json')
        tar.add(checked(note['receipt']),arcname=arm+'/completed.json')
    tar.add(Path(__file__),arcname=Path(__file__).name)
write_json(OUT/'paired-prefix-013000.json',{'plan':previous['plan'],'prior':matched,'arms':views,
           'photos_per_arm':len(photos),'native_queries_per_arm':slots,'noise_seeds_per_arm':len(seeds),
           'verified_match_through_update':13000,'quality_complete_through':12000,
           'controller':owner,'archive':reference(archive)})
