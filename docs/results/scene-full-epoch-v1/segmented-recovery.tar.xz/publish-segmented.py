"""Bind the untouched plan and the first durable worker segment."""
from pathlib import Path
import hashlib
import json
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
OUTPUT = Path("docs/results/scene-full-epoch-v1")


def main():
    first = ROOT/"none-005000/segments/through-003000"
    verification = reference(first/"verified.json")
    supported = read_json(checked(verification))
    completed = read_json(checked(supported["receipt"]))
    active = read_json(ROOT/"status.json")
    launch = read_json(ROOT/"controller-segmented-launch.json")
    old = ROOT/"none-005000/attempt-02"
    old_source = ROOT/"controller-segmented-original.py"
    assert reference(old_source)["sha256"]==launch["controller_source"]["sha256"]
    assert active["controller"]==launch["controller"] and owner_live(active["controller"])
    assert active["attempt"].endswith("through-003500/attempt-01")
    assert owner_live(active["child"])
    active_receipt = reference(Path(active["attempt"])/"launch.json")
    assert (completed["start_step_exclusive"],completed["steps"],completed["schedule_steps"])==(2500,3000,50000)
    joined = checked(supported["observations"]).read_bytes()
    assert joined.count(b"\n")==1000
    for attempt in ("attempt-01","attempt-02"):
        failed = ROOT/"none-005000"/attempt/"work/observations.jsonl"
        with failed.open("rb")as f:
            assert f.read(len(joined))==joined
    last = json.loads((old/"work/train.jsonl").read_text().splitlines()[-1])
    assert last["step"]==4491
    planned = read_json(ROOT/"plan.json")
    assert planned["training_script"]==completed["script"]
    checked(planned["training_script"])
    checked(supported["checkpoint"])

    evidence = OUTPUT/"segmented-recovery.tar.xz"
    with tarfile.open(evidence,"x:xz")as f:
        for name in ("controller-segmented-launch.json","controller-segmented-original.py","segmentation.json","publish-segmented.py"):
            f.add(ROOT/name,arcname=name)
        for name in ("launch.json","exit.json","worker.log","work/progress.json"):
            f.add(old/name,arcname="second-failure/"+name)
        f.add(first/"verified.json",arcname="first-segment/verified.json")
        f.add(checked(supported["receipt"]),arcname="first-segment/completed.json")
        f.add(checked(active_receipt),arcname="next-segment/launch.json")
    write_json(OUTPUT/"segmented-recovery.json",{
        "plan":completed["plan"],"original_frozen_training_script":planned["training_script"],
        "segmentation_policy":reference(ROOT/"segmentation.json"),"initial_controller_launch":reference(ROOT/"controller-segmented-launch.json"),
        "controller_source_initial_archived":reference(old_source),"controller_source_in_repo":reference("scripts/resume_scene_full_epoch.py"),
        "first_segment":verification,"active_second_segment":active_receipt,"checkpoint3000":supported["checkpoint"],
        "prefix_equivalence":{"observations":1000,"matches_both_interrupted_attempts":True,
                              "sha256":hashlib.sha256(joined).hexdigest()},
        "second_failure_last_completed_optimizer_update":last["step"],
        "last_verified_matched_update":2500,"last_independently_reviewed_update":2000,
        "evidence":reference(evidence),
    })
    print(supported["checkpoint"],flush=True)


if __name__=="__main__":
    main()
