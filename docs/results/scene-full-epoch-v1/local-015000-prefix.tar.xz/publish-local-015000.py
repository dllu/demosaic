"""Verify local-only progress beyond the 12,500 matched prefix."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results/scene-full-epoch-v1')
matched = reference(OUT/'paired-prefix-012500.json')
start = read_json(checked(matched))
prior = read_json(checked(start['last_paired']))
plan = read_json(checked(start['plan']))
with checked(plan['train_manifest']).open() as file:
    eligible = {json.loads(row)['id'] for row in file}
trace = [r['observations'] for r in prior['arms']['none']['phases']]+[start['arms']['none']['observations']]
later = {}
final = start['arms']['none']['checkpoint']
for step in (13000,13500,14000,14500,15000):
    note = reference(ROOT/f'none-015000/segments/through-{step:06d}/verified.json')
    saved = read_json(checked(note))
    raw = read_json(checked(saved['receipt']))
    assert raw['plan']==start['plan'] and raw['DINO_unchanged']
    assert raw['resume']==final and (raw['start_step_exclusive'],raw['steps'])==(step-500,step)
    assert raw['schedule_steps']==50000
    final = saved['checkpoint']
    assert raw['checkpoints'][-1]==final
    checked(final)
    trace.append(saved['observations'])
    later[step] = saved|{'accepted':note}
visits, seeds = set(), set()
queries = 0
for binding in trace:
    with checked(binding).open() as stream:
        for r in map(json.loads,stream):
            photo, noise = r['source_id'],r['recipe']['noise_seed']
            assert r['index']==len(visits) and photo in eligible and photo not in visits and noise not in seeds
            visits.add(photo)
            seeds.add(noise)
            queries+=len(r['boxes_xywh'])
assert len(visits)==len(seeds)==30000 and queries==120000
controller = reference(ROOT/'owner.json')
assert owner_live(read_json(checked(controller)))
archive = OUT/'local-015000-prefix.tar.xz'
with tarfile.open(archive,'x:xz') as pack:
    for step, row in later.items():
        pack.add(checked(row['accepted']),arcname=f'{step}/verification.json')
        pack.add(checked(row['receipt']),arcname=f'{step}/completed.json')
    pack.add(Path(__file__),arcname=Path(__file__).name)
write_json(OUT/'local-015000-prefix.json',{'scope':'Checkpoint verification only. Both quality reviews are complete through update 12000.',
           'last_paired':matched,'plan':start['plan'],'controller':controller,'archive':reference(archive),'segments':later,
           'checkpoint':final,'verified_update':15000,'distinct_photos':len(visits),'native_queries':queries,
           'distinct_noise_seeds':len(seeds),'retained_training_seconds':start['arms']['none']['total_retained_training_seconds']+
                 sum(q['training_seconds'] for q in later.values())})
print(len(visits),queries,final['sha256'],flush=True)
