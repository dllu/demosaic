"""Preserve the local source audit after the recovered segment."""
from pathlib import Path
import runpy
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

root = Path(__file__).resolve().parent
out = Path('docs/results/scene-full-epoch-v1')
auditor = root/'audit-storage-recovery.py'
previous = reference(out/'storage-recovery-044000.json')
record = runpy.run_path(str(auditor))['source_prefix'](44500)
frozen = read_json(checked(previous))
assert record['segments'][:-1]==frozen['retained_prefix']['segments']
part = record['segments'][-1]
owner = read_json(root/'owner.json')
assert owner_live(owner)
archive = out/'local-044500-prefix.tar.xz'
with tarfile.open(archive,'x:xz') as pack:
    pack.add(Path(__file__),arcname='publish-044500.py')
    pack.add(auditor,arcname='audit-storage-recovery.py')
    pack.add(checked(part['part']),arcname='verified.json')
    pack.add(checked(part['receipt']),arcname='completed.json')
    pack.add(checked(part['receipt']).parent.parent/'worker.log',arcname='worker.log')
write_json(out/'local-044500-prefix.json',record|{'recovery':previous,'archive':reference(archive),
    'quality_review_matched_through':40000,'controller_at_publication':owner})
print({k:v for k,v in record.items() if k not in ('previous','segments','plan')},flush=True)
