"""Independently bind the verified local 12,000-update prefix."""
from collections import Counter
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
OUTPUT=Path("docs/results/scene-full-epoch-v1")

def run():
    plan=reference(ROOT/"plan.json")
    config=read_json(checked(plan))
    previous=reference(ROOT/"matched-010000.json")
    matched=read_json(checked(previous))
    assert matched["plan"]==plan and matched["through_update"]==10000
    with checked(config["train_manifest"]).open()as f:
        catalog={json.loads(row)["id"]for row in f}
    assert len(catalog)==90692
    input_ids,seeds=set(),set()
    provenance,new_segments=[],[]
    total_queries=0
    scene_types=Counter()
    timings=Counter()
    for step in (8,2000,2500,5000,7500,10000,12000):
        valid=reference(ROOT/f"none-{step:06d}"/"verified.json")
        bound=read_json(checked(valid))
        receipt=read_json(checked(bound["receipt"]))
        assert receipt["plan"]==plan and receipt["DINO_unchanged"] and receipt["steps"]==step
        assert receipt["schedule_steps"]==50000
        assert receipt["checkpoints"][-1]==bound["checkpoint"]
        checked(bound["checkpoint"])
        if step==10000:
            assert bound==matched["arms"]["none"]
        if step==12000:
            assert receipt["start_step_exclusive"]==10000
            for end,part in zip(range(10500,12001,500),receipt["segments"],strict=True):
                original=read_json(checked(part))
                assert original["plan"]==plan and original["DINO_unchanged"]
                assert (original["start_step_exclusive"],original["steps"])==(end-500,end)
                checked(original["checkpoints"][-1])
                new_segments.append((end,part))
        scene_types.update(bound["scene_types"])
        for k in ("training_seconds","reader_and_cpu_fingerprints_seconds","checkpoint_seconds"):
            timings[k]+=bound[k]
        with checked(bound["observations"]).open()as f:
            for row in map(json.loads,f):
                assert row["index"]==len(input_ids)
                key,seed=row["source_id"],row["recipe"]["noise_seed"]
                assert key in catalog and key not in input_ids and seed not in seeds
                input_ids.add(key)
                seeds.add(seed)
                total_queries+=len(row["boxes_xywh"])
        assert len(input_ids)==len(seeds)==2*step and total_queries==8*step
        provenance.append(bound|{"verified":valid})
    state=read_json(ROOT/"status.json")
    assert owner_live(state["controller"]) and owner_live(state["child"])
    assert "spatial-012000/segments" in state["attempt"]
    recovery=reference(Path(state["attempt"])/"launch.json")
    archive=OUTPUT/"local-012000-evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for end,receipt in new_segments:
            f.add(checked(receipt),arcname=f"segments/{end:06d}.json")
        f.add(checked(recovery),arcname="spatial/launch.json")
        f.add(checked(provenance[-1]["verified"]),arcname="local/verification.json")
        f.add(checked(provenance[-1]["receipt"]),arcname="local/completed.json")
        f.add(Path(__file__),arcname=Path(__file__).name)
    write_json(OUTPUT/"local-012000-prefix.json",{
        "run":plan,"parent":config["parent"],"train_manifest":config["train_manifest"],
        "local_through_update":12000,"local_unique_photos":len(input_ids),"local_unique_noise_seeds":len(seeds),
        "local_native_queries":total_queries,"scene_types":dict(scene_types),"retained_local_times_seconds":dict(timings),
        "local_checkpoint":provenance[-1]["checkpoint"],"local_phases":provenance,
        "last_matched_pair_at_publication":previous,"new_spatial_launch":recovery,
        "end_to_end_training_complete":False,"last_numerically_and_natively_reviewed_update":10000,
        "archive":reference(archive)})
    print(len(input_ids),total_queries,dict(timings),provenance[-1]["checkpoint"]["sha256"],flush=True)

if __name__=="__main__":
    run()
