"""Summarize matched 20k context interventions and the common 15k photo IDs."""
from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BANDS = ("lower", "fine", "upper", "uniform")
MODELS = ("V120", "100k", "none", "spatial/matching", "spatial/neutral",
          "spatial/blur-distant", "spatial/wrong-distant")
UNIFORM = ("quiet_RGB_mean_absolute_bias_DN16", "quiet_RGB_centered_RMS_DN16")
SEED = 281021


def data(rows, policy, band):
    if band == "uniform":
        return {k: np.array([r["metrics"][policy]["uniform_core"][k] for r in rows])
                for k in UNIFORM}
    fields = [r["metrics"][policy]["band"][band] for r in rows]
    return {k: np.array([r[k] for r in fields]) for k in
            ("increment_RMS_DN16", "quiet_RMS_DN16", "aligned_increment_dot", "exact_paired_increment_sq")}


def evaluate(rows, policy, band, draws):
    values = data(rows, policy, band)
    if band == "uniform":
        return {k: v[draws].mean(axis=1) for k, v in values.items()}
    dot = values.pop("aligned_increment_dot")
    power = values.pop("exact_paired_increment_sq")
    return {"aligned_response_pct":100*dot[draws].sum(1)/power[draws].sum(1)} | {
        k:v[draws].mean(1) for k,v in values.items()}


def compare(rows, matched_15k, noise, draw, rng):
    n=len(rows)
    draws=np.vstack((np.arange(n),rng.integers(n,size=(10000,n))))
    panels={}
    for band in BANDS:
        stats={policy:evaluate(rows,policy,band,draws)for policy in MODELS}
        anchor=stats["spatial/matching"]
        options={k:v for k,v in stats.items() if k!="spatial/matching"}
        if matched_15k:
            options["local-15k"]=evaluate(matched_15k,"none",band,draws)
            options["spatial-15k"]=evaluate(matched_15k,"spatial/matching",band,draws)
        intervals={}
        for profile,other in options.items():
            intervals[profile]={}
            for key in anchor:
                change=anchor[key]-other[key]
                intervals[profile][key]={"point":float(change[0]),
                    "interval_95":np.quantile(change[1:],[.025,.975]).tolist()}
        panels[band]={"means":{k:{n:float(x[0])for n,x in v.items()}for k,v in stats.items()},
                      "spatial_matching_minus":intervals}
        if matched_15k:
            panels[band]["means"] |= {name:{k:float(q[0])for k,q in options[name].items()}
                                      for name in ("local-15k","spatial-15k")}
    return panels


def main():
    current, prior=(reference(ROOT/p)for p in (
        "review-020000/evaluation/results.json", "review-015000/pilot/results.json"))
    full=read_json(checked(current))
    memo=read_json(checked(prior))
    configs=[read_json(checked(i["plan"]))for i in (full,memo)]
    assert configs[0]["panel"]==configs[1]["panel"]
    assert configs[0]["precision"]==configs[1]["precision"]=="CUDA IEEE FP32"
    assert len(full["source_metrics"])==256 and len(memo["source_metrics"])==32
    group={}
    common={}
    rng=np.random.default_rng(SEED)
    for noise in ("iso400","iso6400"):
        for draw in ("coupled","independent"):
            select=lambda r:r["profile"]==noise and r["draw"]==draw
            base=sorted([a for a in full["source_metrics"]if select(a)],key=lambda a:a["source"])
            old=sorted([a for a in memo["source_metrics"]if select(a)],key=lambda a:a["source"])
            keys={a["source"]for a in old}
            fixed=[a for a in base if a["source"]in keys]
            assert len(base)==64 and len(fixed)==len(old)==8
            assert all(a["source"]==b["source"] for a,b in zip(fixed,old,strict=True))
            for a,b in zip(fixed,old,strict=True):
                for k in ("V120","100k"):
                    assert a["metrics"][k]==b["metrics"][k]
            label=f"{noise}/{draw}"
            group[label]=compare(base,None,noise,draw,rng)
            common[label]=compare(fixed,old,noise,draw,rng)
    write_json(ROOT/"review-020000/evaluation/context-intervals.json",{
        "driver":reference(__file__),"evaluated":current,"earlier":prior,"all_64":group,"fixed_8_with_15k":common,
        "scope":"Source-paired resampling within each noise law. Distinct 64-photo and common-size progress comparisons."})


if __name__=="__main__":
    main()
