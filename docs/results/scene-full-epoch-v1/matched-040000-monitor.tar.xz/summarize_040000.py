"""Bind the matched 40k photo data and compare it with the same 35k observations."""
from pathlib import Path
import sys
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from summarize_020000 import BANDS, MODELS, SEED, evaluate

ROOT=Path(__file__).resolve().parent


def inspect():
    sources=[reference(ROOT/x)for x in ("review-full-035000/evaluation/results.json",
                                        "review-full-040000/evaluation/results.json")]
    old,new=[read_json(checked(s))for s in sources]
    config=[read_json(checked(obj["plan"])) for obj in (old,new)]
    assert config[0]["panel"]==config[1]["panel"]
    assert config[0]["precision"]==config[1]["precision"]=="CUDA IEEE FP32"
    assert config[0]["models"]["100k"]==config[1]["models"]["100k"]
    assert config[0]["models"]["V120"]==config[1]["models"]["V120"]
    assert all(len(x["source_metrics"])==256 for x in (old,new))
    for step,settings in ((35000,config[0]),(40000,config[1])):
        pair=read_json(checked(settings["training_snapshot"]))
        assert pair["through_update"]==step and pair["matched_input_traces"]
        for key in ("none","spatial"):
            assert settings["models"][key]==pair["arms"][key]["checkpoint"]|{
                "type":"scene","step":step,"mode":key}
    measures={}
    rng=np.random.default_rng(SEED)
    for iso in ("iso400","iso6400"):
        for draw in ("coupled","independent"):
            def cohort(bank):
                return sorted([r for r in bank["source_metrics"]if (r["profile"],r["draw"])==(iso,draw)],
                              key=lambda x:x["source"])
            base,candidate=cohort(old),cohort(new)
            assert len(base)==len(candidate)==64
            for a,b in zip(base,candidate,strict=True):
                assert a["source"]==b["source"]
                previous=read_json(checked(a["prediction_receipt"]))
                current=read_json(checked(b["prediction_receipt"]))
                assert previous["exact_query_inputs"]==current["exact_query_inputs"]
                for baseline in ("V120","100k"):
                    assert a["metrics"][baseline]==b["metrics"][baseline],(a["source"],baseline)
            bootstrap=np.vstack((np.arange(64),rng.integers(64,size=(10000,64))))
            selected={}
            for band in BANDS:
                current={key:evaluate(candidate,key,band,bootstrap)for key in MODELS}
                controls={key:evaluate(base,key,band,bootstrap)for key in ("none","spatial/matching")}
                comparisons={}
                for label,a,b in [
                    ("new_local_minus_35k",current["none"],controls["none"]),
                    ("new_spatial_minus_35k",current["spatial/matching"],controls["spatial/matching"]),
                    ("new_spatial_minus_local",current["spatial/matching"],current["none"]),
                    ("new_spatial_minus_100k",current["spatial/matching"],current["100k"]),
                    ("new_spatial_minus_V120",current["spatial/matching"],current["V120"]),
                    ("new_local_minus_100k",current["none"],current["100k"]),
                    ("new_local_minus_V120",current["none"],current["V120"]),
                    ("new_spatial_minus_wrong_distant",current["spatial/matching"],current["spatial/wrong-distant"]),
                    ("new_spatial_minus_masked",current["spatial/matching"],current["spatial/neutral"]),
                ]:
                    comparisons[label]={}
                    for key in a:
                        difference=a[key]-b[key]
                        comparisons[label][key]={"point":float(difference[0]),"interval95":np.quantile(difference[1:],[.025,.975]).tolist()}
                selected[band]={"means":{k:{measure:float(v[0])for measure,v in values.items()}
                                           for k,values in current.items()},
                                "means_35k":{k:{measure:float(v[0])for measure,v in values.items()}
                                            for k,values in controls.items()}, "contrasts":comparisons}
            measures[iso+"/"+draw]=selected
    write_json(ROOT/"review-full-040000/evaluation/context-intervals.json",{
        "driver":reference(__file__),"35k_numeric":sources[0],"40k_numeric":sources[1],
        "scope":"All 64 exactly matching held-out photo backgrounds, paired bootstrap across photos separately in each draw and noise profile.",
        "all_64":measures})


if __name__=="__main__":
    inspect()
