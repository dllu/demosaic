"""Preserve the matched update-40000 standing camera review."""

from pathlib import Path
import hashlib
import shutil
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
NATIVE = ROOT / "review-native-040000"


def run():
    recorded = reference(NATIVE / "work/render/result.json")
    rendered = read_json(checked(recorded))
    train = read_json(checked(rendered["matched_training"]))
    assert train["through_update"] == 40000 and train["matched_input_traces"]
    row_maps = {}
    for model, binding in rendered["collections"].items():
        proof = read_json(checked(binding))
        row_maps[model] = {r["id"]: r for r in proof["records"]}
        if model in train["arms"]:
            assert proof["checkpoint"] == train["arms"][model]["checkpoint"]
    output = Path("docs/images/scene-full-epoch-v1/standing-040000")
    output.mkdir()
    notes = read_json(NATIVE / "standing-viewing.json")
    prior = read_json(ROOT / "review-native-035000/work/render/result.json")
    prior_rows = {
        model: {row["id"]: row for row in read_json(checked(binding))["records"]}
        for model, binding in prior["collections"].items()
    }
    direct = read_json(NATIVE / "paired-with-035000/manifest.json")
    direct_boards = {}
    kept = []
    for case in rendered["boards"]:
        if case["id"] not in notes:
            continue
        id = case["observation"]
        roles = {arm: rows[id] for arm, rows in row_maps.items()}
        assert all(
            r["input_fingerprints"] == roles["V120"]["input_fingerprints"] for r in roles.values()
        )
        x, y, w, h = case["case"]["ROI_xywh"]
        assert w == h == 160
        values = {}
        for arm, row in roles.items():
            pixels = np.load(checked(row["prediction"]), allow_pickle=False)
            values[arm] = pixels[0, :, y : y + h, x : x + w].astype(np.float64)

        def change(a, b):
            diff = (values[a] - values[b]) * 65535
            return {
                "camera_RGB_RMS_DN16": float(np.sqrt(np.mean(diff**2))),
                "max_camera_RGB_DN16": float(abs(diff).max()),
            }

        for arm in ("none", "spatial"):
            old = prior_rows[arm][id]
            assert old["input_fingerprints"] == roles[arm]["input_fingerprints"]
            field = np.load(checked(old["prediction"]), allow_pickle=False)
            values[arm+"35k"] = field[0,:,y:y+h,x:x+w].astype(np.float64)
        paired = next(row for row in direct["rows"] if row["id"] == case["id"])
        paired_source = checked(paired["image"]["image"])
        paired_dest = output / f"35k-vs-40k-{paired_source.name}"
        shutil.copyfile(paired_source, paired_dest)
        assert reference(paired_dest)["sha256"] == paired["image"]["image"]["sha256"]
        direct_boards[case["id"]] = paired["image"] | {"image":reference(paired_dest)}

        bound = case["image"]
        source = checked(bound)
        dest = output / source.name
        shutil.copyfile(source, dest)
        assert reference(dest)["sha256"] == bound["sha256"]
        with Image.open(dest) as picture:
            assert all(
                w == h == 160 and x + w <= picture.width and y + h <= picture.height
                for pane in case["panels"]
                for x, y, w, h in (pane["png_xywh"],)
            )
            picture.verify()
        kept.append(
            case
            | {
                "image": reference(dest),
                "actual_native_viewing": notes[case["id"]],
                "model_differences": {
                    "spatial40_vs_spatial35": change("spatial","spatial35k"),
                    "local40_vs_local35": change("none","none35k"),
                    "spatial_vs_local": change("spatial", "none"),
                    "spatial_vs_Corpus_100k": change("spatial", "parent100k"),
                    "local_vs_Corpus_100k": change("none", "parent100k"),
                },
            }
        )
    assert set(notes) == {case["id"] for case in kept}
    assert sum(a["id"].startswith("main-") for a in kept) == 4
    assert sum(a["id"].startswith("mesh-") for a in kept) == 4
    archive = Path("docs/results/scene-full-epoch-v1/matched-040000-standing.tar.xz")
    with tarfile.open(archive, "x:xz") as stream:
        for path in (
            "plan.json",
            "collection.json",
            "none/collection.json",
            "spatial/collection.json",
            "work/render/result.json",
            "standing-viewing.json",
            "paired-with-035000/manifest.json",
            "render.py",
            "render.log",
            "none.log",
            "spatial.log",
        ):
            stream.add(NATIVE / path, arcname=path)
        stream.add(ROOT / "compare_35k_40k_standing.py", arcname="compare_35k_40k_standing.py")
        stream.add(Path(__file__), arcname=Path(__file__).name)
        stream.add(NATIVE / "work/scripts/review_scene_context_native.py", arcname="collector.py")
    with tarfile.open(archive) as stream:
        names = stream.getnames()
        assert len(names) == len(set(names))
        for name in names:
            if name == "collector.py":
                source = NATIVE / "work/scripts/review_scene_context_native.py"
            elif name == "compare_35k_40k_standing.py":
                source = ROOT / name
            elif name == Path(__file__).name:
                source = Path(__file__)
            else:
                source = NATIVE / name
            with stream.extractfile(name) as payload:
                assert hashlib.file_digest(payload, "sha256").hexdigest() == reference(source)["sha256"]
    write_json(
        archive.with_suffix("").with_suffix(".json"),
        {
            "recorded": recorded,
            "archive": reference(archive),
            "training": rendered["matched_training"],
            "collections": rendered["collections"],
            "boards": kept,
            "direct_35k_vs_40k": direct_boards,
            "scoped_viewing_complete": True,
            "torch_policy": "CPU IEEE FP32. Reused control RGB strictly matched to source conditions.",
            "scope": "Both fixed GFX families at intermediate 40k scene checkpoints. RGB differences compare models. References are qualitatively different captures. Canonical scores reserved for full endpoints.",
        },
    )


if __name__ == "__main__":
    run()
