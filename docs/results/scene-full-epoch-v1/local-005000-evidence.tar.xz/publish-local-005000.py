"""Audit the local 5,000 milestone and the spatial worker's continuation."""
from collections import Counter
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
RESULT = Path("docs/results/scene-full-epoch-v1")


def main():
    independent = ROOT/"none-005000/verified.json"
    final = read_json(independent)
    finished = read_json(checked(final["receipt"]))
    assert (finished["start_step_exclusive"],finished["steps"],finished["schedule_steps"])==(2500,5000,50000)
    assert len(finished["segments"])==5 and finished["DINO_unchanged"]
    for n,segment in zip(range(3000,5001,500),finished["segments"],strict=True):
        record = read_json(checked(segment))
        assert (record["start_step_exclusive"],record["steps"])==(n-500,n)
        assert record["plan"]==finished["plan"]
        checked(record["checkpoints"][-1])
    seen_ids,seen_seeds = set(),set()
    total_rois = 0
    counts = Counter()
    history = []
    index = 0
    for step in (8,2000,2500,5000):
        audit = reference(ROOT/f"none-{step:06d}/verified.json")
        arm = read_json(checked(audit))
        complete = read_json(checked(arm["receipt"]))
        assert complete["plan"]==finished["plan"]
        counts.update(arm["scene_types"])
        trace = checked(arm["observations"])
        with trace.open()as file:
            for line in file:
                row = json.loads(line)
                assert row["index"]==index
                assert row["source_id"] not in seen_ids and row["recipe"]["noise_seed"] not in seen_seeds
                seen_ids.add(row["source_id"])
                seen_seeds.add(row["recipe"]["noise_seed"])
                total_rois += len(row["boxes_xywh"])
                index += 1
        assert index==2*step
        history.append(arm|{"audit":audit})
    assert (len(seen_ids),len(seen_seeds),total_rois)==(10000,10000,40000)
    state = read_json(ROOT/"status.json")
    assert owner_live(state["controller"]) and owner_live(state["child"])
    assert state["attempt"].endswith("spatial-005000/segments/through-003000/attempt-01")
    next_launch = reference(Path(state["attempt"])/"launch.json")
    path = RESULT/"local-005000-evidence.tar.xz"
    with tarfile.open(path,"x:xz")as f:
        for item in finished["segments"]:
            file=checked(item)
            step=read_json(file)["steps"]
            f.add(file,arcname=f"local-{step:06d}/completed.json")
        f.add(checked(final["receipt"]),arcname="local-005000/combined.json")
        f.add(independent,arcname="local-005000/verified.json")
        f.add(checked(next_launch),arcname="spatial-003000/launch.json")
        f.add(Path(__file__),arcname=Path(__file__).name)
    report = {
        "plan":finished["plan"],"local_checkpoint":final["checkpoint"],"local_updates":5000,
        "local_distinct_photos":len(seen_ids),"local_distinct_noise_seeds":len(seen_seeds),
        "local_native_queries":total_rois,"scene_counts":dict(counts),"phase_audits":history,
        "local_measured_training_seconds":sum(a["training_seconds"]for a in history),
        "local_measured_data_seconds":sum(a["reader_and_cpu_fingerprints_seconds"]for a in history),
        "last_verified_matched_update":2500,"last_numerically_and_natively_reviewed_update":2000,
        "spatial_next_segment":next_launch,"archive":reference(path),
        "scope":"Verified local prefix only. Original full-epoch quality comparisons and the 5000 matched state remain pending.",
    }
    write_json(RESULT/"local-005000-prefix.json",report)
    print(report["local_checkpoint"],round(report["local_measured_training_seconds"],2),flush=True)


if __name__=="__main__":
    main()
