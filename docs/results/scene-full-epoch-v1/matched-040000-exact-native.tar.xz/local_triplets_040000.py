"""Extract local-only triplets from the exact monitor boards without resampling."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "paired-luminance-detail-v1"))
from render import native_png

if __name__ == "__main__":
    review = ROOT / "review-full-040000/evaluation"
    record = reference(review / "results.json")
    notes = []
    for row in read_json(checked(record))["native"]:
        if not row["id"].endswith("role0"):
            continue
        preserved = row["board"]
        with Image.open(checked(preserved["image"])) as img:
            panels = {p["label"]: np.asarray(img.crop((x, y, x + w, y + h)).convert("RGB"))
                      for p in preserved["panels"] for x, y, w, h in (p["png_xywh"],)}
        result = native_png(review / "native" / (row["id"] + "-local-triplet.png"),
                            [(label, panels[label]) for label in ("Noisy Malvar", "Local only", "Exact GT")])
        notes.append({"id":row["id"],"full_board":preserved,"triplet":result})
    assert len(notes)==2
    write_json(review/"local-triplets.json",{"driver":reference(__file__),"results":record,"rows":notes})
