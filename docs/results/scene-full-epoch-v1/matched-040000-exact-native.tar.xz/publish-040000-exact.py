"""Preserve the viewed exact crop images with frozen numerical bindings."""
from pathlib import Path
import shutil
import tarfile
from PIL import Image,ImageChops
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
STAGE=ROOT/"review-full-040000/evaluation"
OUT=Path("docs/results/scene-full-epoch-v1")
IMAGES=Path("docs/images/scene-full-epoch-v1/evaluation-040000")


def placement(binding):
    src=checked(binding["image"])
    dst=IMAGES/src.name
    shutil.copyfile(src,dst)
    digest=reference(dst)["sha256"]
    assert digest==binding["image"]["sha256"]
    binding["image"]={"path":str(dst),"sha256":digest}
    with Image.open(dst)as image:
        regions={}
        for pane in binding["panels"]:
            x,y,w,h=pane["png_xywh"]
            assert (w,h)==(160,160) and 0<=x<=image.width-w and 0<=y<=image.height-h
            regions[pane.get("label") or pane["name"]]=image.crop((x,y,x+w,y+h))
    return regions


def main():
    measurement=reference(STAGE/"results.json")
    result=read_json(checked(measurement))
    numerical=reference(OUT/"matched-040000-monitor.json")
    assert read_json(checked(numerical))["source"]==measurement
    local_binding=reference(STAGE/"local-triplets.json")
    local=read_json(checked(local_binding))
    assert local["results"]==measurement
    images={r["id"]:r["triplet"]for r in local["rows"]}
    IMAGES.mkdir(exist_ok=True)
    notes={
        "000-iso6400-independent-role0":"Rock relief remains visible and grain is softer than exact GT. The two 40k arms and wrong-distant view appear close.",
        "000-iso6400-independent-role2":"The exact-flat center stays smooth. The dark bottom boundary is still softer than exact GT.",
        "001-iso6400-independent-role0":"Both arms retain the arches and warm trim. The exact target carries finer surface texture. Matching and wrong distant previews appear close.",
        "001-iso6400-independent-role2":"The brown fill stays smooth. Some adjacent lighter trim is soft in the restored panels.",
    }
    assert {row["id"]for row in result["native"]}==notes.keys()
    for row in result["native"]:
        original=placement(row["board"])
        row["viewed_at_native_scale"]=notes[row["id"]]
        if row["id"] in images:
            row["local_triplet"]=images[row["id"]]
        for key in ("triplet","local_triplet"):
            if key not in row:
                continue
            parts=placement(row[key])
            assert len(parts)==3 and all(ImageChops.difference(original[name],piece).getbbox() is None
                                         for name,piece in parts.items())
    bundle=OUT/"matched-040000-exact-native.tar.xz"
    with tarfile.open(bundle,"x:xz")as archive:
        for file in (STAGE/"local-triplets.json",ROOT/"local_triplets_040000.py",Path(__file__)):
            archive.add(file,arcname=file.name)
    write_json(OUT/"matched-040000-exact-native.json",{
        "checkpoint_bound_numeric":numerical,"driver_archive":reference(bundle),
        "actual_exact_image_viewing_complete":True,"standing_viewing_complete":False,"rows":result["native"],
    })
if __name__=="__main__":
    main()
