"""Preserve the viewed exact crop images with frozen numerical bindings."""
from pathlib import Path
import shutil
import tarfile
from PIL import Image,ImageChops
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
STAGE=ROOT/"review-full-035000/evaluation"
OUT=Path("docs/results/scene-full-epoch-v1")
IMAGES=Path("docs/images/scene-full-epoch-v1/evaluation-035000")


def placement(binding):
    src=checked(binding["image"])
    dst=IMAGES/src.name
    shutil.copyfile(src,dst)
    digest=reference(dst)["sha256"]
    assert digest==binding["image"]["sha256"]
    binding["image"]={"path":str(dst),"sha256":digest}
    with Image.open(dst)as image:
        regions={}
        for pane in binding["panels"]:
            x,y,w,h=pane["png_xywh"]
            assert (w,h)==(160,160) and 0<=x<=image.width-w and 0<=y<=image.height-h
            regions[pane.get("label") or pane["name"]]=image.crop((x,y,x+w,y+h))
    return regions


def main():
    measurement=reference(STAGE/"results.json")
    result=read_json(checked(measurement))
    numerical=reference(OUT/"matched-035000-monitor.json")
    assert read_json(checked(numerical))["source"]==measurement
    local_binding=reference(STAGE/"local-triplets.json")
    local=read_json(checked(local_binding))
    assert local["results"]==measurement
    images={r["id"]:r["triplet"]for r in local["rows"]}
    IMAGES.mkdir(exist_ok=True)
    notes={
        "000-iso6400-independent-role0":"Both 35k arms retain the mottled rock relief with less visible fine grain than the exact target.",
        "000-iso6400-independent-role2":"The false-flat center looks smooth. Dark lower edges keep the faint boundary softness of the 30k review.",
        "001-iso6400-independent-role0":"Both arms retain the outlines of the arches and warm trim. Fine brick detail remains smooth. Correct and wrong distant context are visually similar.",
        "001-iso6400-independent-role2":"The central brown stays smooth, with slight softness along the borders. No new ripple is visible.",
    }
    assert {row["id"]for row in result["native"]}==notes.keys()
    for row in result["native"]:
        original=placement(row["board"])
        row["viewed_at_native_scale"]=notes[row["id"]]
        if row["id"] in images:
            row["local_triplet"]=images[row["id"]]
        for key in ("triplet","local_triplet"):
            if key not in row:
                continue
            parts=placement(row[key])
            assert len(parts)==3 and all(ImageChops.difference(original[name],piece).getbbox() is None
                                         for name,piece in parts.items())
    bundle=OUT/"matched-035000-exact-native.tar.xz"
    with tarfile.open(bundle,"x:xz")as archive:
        for file in (STAGE/"local-triplets.json",ROOT/"local_triplets_035000.py",Path(__file__)):
            archive.add(file,arcname=file.name)
    write_json(OUT/"matched-035000-exact-native.json",{
        "checkpoint_bound_numeric":numerical,"driver_archive":reference(bundle),
        "actual_exact_image_viewing_complete":True,"standing_viewing_complete":False,"rows":result["native"],
    })
if __name__=="__main__":
    main()
