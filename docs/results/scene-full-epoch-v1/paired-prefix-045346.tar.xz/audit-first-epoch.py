"""Check the first complete matched corpus pass against the frozen source order."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.photo_epoch_order import PhotoEpochOrder

ROOT = Path(__file__).resolve().parent
RESULTS = Path('docs/results/scene-full-epoch-v1')
START, END = 45000, 45346
MODES = ('none', 'spatial')
LAST_QUALITY = 40000


def load_bound(binding):
    return read_json(checked(binding))


def main():
    prior = reference(RESULTS/f'paired-prefix-{START:06d}.json')
    previous = load_bound(prior)
    plan_ref = previous['plan']
    plan = load_bound(plan_ref)
    manifest = checked(plan['train_manifest'])
    with manifest.open() as source:
        eligible = list(map(json.loads,source))
    order_path = checked(plan['photo_epoch_order'])
    order_receipt = read_json(order_path)
    order = PhotoEpochOrder(order_path, manifest, eligible, order_receipt['reader_policy'],
                            expected_sha256=plan['photo_epoch_order']['sha256'])
    assert len(eligible) == 90692 == 2 * END
    assert plan['steps'] == order_receipt['horizon_steps'] == 50000
    assert plan['scenes_per_step'] == 2 and plan['crops_per_scene'] == 4
    marker_ref = reference(ROOT/f'matched-{END:06d}.json')
    marker = load_bound(marker_ref)
    assert marker['matched_input_traces'] and marker['plan'] == plan_ref
    assert (marker['first_step_exclusive'],marker['through_update']) == (START,END)
    assert not any(marker[k] for k in ('training_complete','numerical_review_complete','native_review_complete'))
    segments = {}
    for mode in MODES:
        arm_root = ROOT/f'{mode}-{END:06d}'
        verification = reference(arm_root/f'segments/through-{END:06d}/verified.json')
        note = load_bound(verification)
        receipt = load_bound(note['receipt'])
        aggregate = marker['arms'][mode]
        assert aggregate == read_json(arm_root/'verified.json')
        assert receipt['plan'] == plan_ref and receipt['DINO_unchanged']
        assert (receipt['start_step_exclusive'],receipt['steps'],receipt['schedule_steps']) == (START,END,plan['steps'])
        assert receipt['resume'] == previous['arms'][mode]['checkpoint']
        assert receipt['checkpoints'][-1] == note['checkpoint'] == aggregate['checkpoint']
        assert note['observations']['sha256'] == aggregate['observations']['sha256']
        checked(note['checkpoint'])
        checked(note['observations'])
        checked(aggregate['observations'])
        assert load_bound(aggregate['receipt'])['checkpoints'][-1] == note['checkpoint']
        segments[mode] = note | {'verification':verification,'aggregate':aggregate,
                                 'retained_training_seconds':receipt['seconds']}
    traces = [segments['none']['observations']]
    assert traces[0]['sha256'] == segments['spatial']['observations']['sha256']
    seconds = {mode:segments[mode]['retained_training_seconds'] for mode in MODES}
    history = previous
    while 'phases' not in history['arms']['none']:
        arms = history['arms']
        assert arms['none']['observations']['sha256'] == arms['spatial']['observations']['sha256']
        traces.append(arms['none']['observations'])
        for mode in MODES:
            seconds[mode] += load_bound(arms[mode]['receipt'])['seconds']
        history = load_bound(history.get('prior',history.get('last_paired')))
    phases = {mode:history['arms'][mode]['phases'] for mode in MODES}
    for a,b in zip(phases['none'],phases['spatial'],strict=True):
        assert a['observations']['sha256'] == b['observations']['sha256']
    for mode in MODES:
        seconds[mode] += sum(load_bound(phase['receipt'])['seconds'] for phase in phases[mode])
    traces = [phase['observations'] for phase in phases['none']] + list(reversed(traces))
    ids, seeds = set(), set()
    queries = 0
    for trace in traces:
        with checked(trace).open() as stream:
            for row in map(json.loads,stream):
                index, name, seed = row['index'],row['source_id'],row['recipe']['noise_seed']
                assert index == len(ids) and name == order.ordinary(index)['id']
                assert name not in ids and seed not in seeds and len(row['boxes_xywh']) == 4
                ids.add(name)
                seeds.add(seed)
                queries += len(row['boxes_xywh'])
    assert ids == {row['id'] for row in eligible} and len(seeds) == 90692 and queries == 362768
    stem = RESULTS/f'paired-prefix-{END:06d}'
    archive = stem.with_suffix('.tar.xz')
    with tarfile.open(archive,'x:xz') as tar:
        tar.add(Path(__file__),arcname=Path(__file__).name)
        tar.add(checked(marker_ref),arcname='matched-first-epoch.json')
        tar.add(order_path,arcname='order/photo-epoch-order.json')
        payload = order_path.parent / order_receipt['order']['path']
        tar.add(payload,arcname=f'order/{payload.name}')
        for mode, note in segments.items():
            for key in ('verification','receipt'):
                tar.add(checked(note[key]),arcname=f'{mode}/{key}.json')
            log = checked(note['receipt']).parent.parent/'worker.log'
            tar.add(log,arcname=f'{mode}/worker.log')
    write_json(stem.with_suffix('.json'),dict(prior=prior,plan=plan_ref,verified_match_through_update=END,
               first_epoch_complete=True,allocated_updates=plan['steps'],photos_per_arm=len(ids),
               eligible_training_photos=len(eligible),noise_seeds_per_arm=len(seeds),native_queries_per_arm=queries,
               retained_training_seconds=seconds,quality_complete_through=LAST_QUALITY,arms=segments,
               matched_marker=marker_ref,order=plan['photo_epoch_order'],training_manifest=plan['train_manifest'],
               epoch_order_payload_sha256=order_receipt['order']['sha256'],traces=traces,archive=reference(archive)))
    print(END,len(ids),queries,seconds)


if __name__ == '__main__':
    main()
