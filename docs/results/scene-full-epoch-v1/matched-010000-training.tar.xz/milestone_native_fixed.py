"""Collect fixed standing GFX comparisons on a matched intermediate checkpoint."""

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import (
    checked,
    freeze_sources,
    read_json,
    reference,
    write_json,
)

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
OLDER = ROOT.parent / "expanded-scene-12000-native-v1"


def invoke(directory, work, driver, plan, action):
    env = os.environ | {
        "CUDA_VISIBLE_DEVICES": "",
        "PYTHONPATH": f"{work}/src:{work}/scripts",
        "OMP_NUM_THREADS": "2",
        "OPENBLAS_NUM_THREADS": "1",
    }
    command = [sys.executable, "-u", str(driver), str(checked(plan)), action]
    while psutil.virtual_memory().available < 48 * 2**30:
        time.sleep(30)
    with (directory / f"{action}.log").open("xb") as stream:
        child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=env)
        write_json(
            directory / f"{action}-launch.json",
            {
                "command": command,
                "pid": child.pid,
                "created": psutil.Process(child.pid).create_time(),
            },
        )
        code = child.wait()
    write_json(directory / f"{action}-exit.json", {"returncode": code})
    if code:
        raise subprocess.CalledProcessError(code, command)


def native(directory, proof, matched):
    historical = reference(OLDER / "plan.json")
    template = read_json(checked(historical))
    assert len(template["observations"]) == 10
    previous = read_json(OLDER / "collection.json")
    parent = reference(checked(previous["parent"]))
    train = matched["plan"]
    assert read_json(checked(train))["parent"] == template["parent"]
    directory.mkdir()
    training_paths = directory / "training"
    training_paths.mkdir()
    for mode, summary in matched["arms"].items():
        (training_paths / mode).symlink_to(
            checked(summary["receipt"]).parent, target_is_directory=True
        )
    work, sources = freeze_sources(REPOSITORY, directory, ["review_scene_context_native.py"])
    driver = work / "scripts/review_scene_context_native.py"
    new_sources = (historical, train, proof, parent, reference(__file__))
    step = matched["through_update"]
    reader = driver.read_text()
    assert reader.count('training["steps"]') == 2
    driver.write_text(reader.replace('training["steps"]', 'plan["evaluation_step"]'))
    sources[str(driver)] = reference(driver)["sha256"]
    updated = template | {
        "root": str(directory),
        "evaluation_step": step,
        "CPU_affinity": [13, 14],
        "training_plan": train,
        "training_output_root": str(training_paths),
        "sources": sources | {row["path"]: row["sha256"] for row in new_sources},
        "script": reference(driver),
    }
    plan_path = directory / "plan.json"
    write_json(plan_path, updated)
    plan = reference(plan_path)
    variants = {}
    for mode, summary in matched["arms"].items():
        invoke(directory, work, driver, plan, mode)
        result = reference(directory / mode / "collection.json")
        assert read_json(checked(result))["checkpoint"] == summary["checkpoint"]
        variants[mode] = result
    write_json(
        directory / "collection.json",
        {
            "plan": plan,
            "training": proof,
            "V120": template["baseline_collection"],
            "parent": parent,
            "epochs": variants,
            "actual_native_viewed": False,
        },
    )
    renderer = (OLDER / "render.py").read_text()
    edits = {
        "assert training['trained'] and training['native_examples_per_arm']==96000": f"assert training['matched_input_traces'] and training['through_update']=={step}",
        "training['endpoints'][arm]['EMA']": "training['arms'][arm]['checkpoint']",
        "Local-only 12k EMA": f"Local-only {step/1000:g}k EMA",
        "Spatial 12k EMA": f"Spatial {step/1000:g}k EMA",
        "spatial 12k EMA": f"spatial {step/1000:g}k EMA",
    }
    for old, new in edits.items():
        assert old in renderer
        renderer = renderer.replace(old, new)
    prior = "output=root/'render';output.mkdir()"
    assert renderer.count(prior) == 1
    renderer = renderer.replace(prior, "output=root/'work'/'render';output.mkdir()")
    renderer = renderer.replace("ISO100 AHD, not GT", "ISO100 AHD reference")
    render = directory / "render.py"
    render.write_text(renderer)
    env = os.environ | {"PYTHONPATH": f"{work}/src:{work}/scripts"}
    with (directory / "render.log").open("xb") as log:
        subprocess.run(
            [sys.executable, str(render)], env=env, stdout=log, stderr=subprocess.STDOUT, check=True
        )
    result = read_json(directory / "work/render/result.json")
    assert len(result["boards"]) == 16 and len(result["triplets"]) == 8


def run(step):
    receipt = reference(ROOT / f"matched-{step:06d}.json")
    matched = read_json(checked(receipt))
    assert matched["matched_input_traces"] and matched["through_update"] == step
    native(ROOT / f"review-native-{step:06d}", receipt, matched)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int)
    run(parser.parse_args().step)
