"""Bind and independently audit the matched 10k intermediate training prefix."""
from collections import Counter
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
OUTPUT = Path("docs/results/scene-full-epoch-v1")


def arm(mode,match,config,allowed):
    accumulator = Counter()
    durations = Counter()
    photos,seeds = set(),set()
    queries = 0
    records = []
    archived = []
    for step in (8,2000,2500,5000,7500,10000):
        verified = reference(ROOT/f"{mode}-{step:06d}/verified.json")
        info = read_json(checked(verified))
        receipt = read_json(checked(info["receipt"]))
        assert receipt["plan"]==match["plan"]
        assert receipt["steps"]==step and receipt["schedule_steps"]==50000
        assert receipt["DINO_unchanged"]
        if step==10000:
            assert info==match["arms"][mode]
            assert len(receipt["segments"])==5
            for stop,part in zip(range(8000,10001,500),receipt["segments"],strict=True):
                entry = read_json(checked(part))
                assert entry["plan"]==match["plan"] and entry["DINO_unchanged"]
                assert (entry["start_step_exclusive"],entry["steps"])==(stop-500,stop)
                checked(entry["checkpoints"][-1])
                archived.append((checked(part),f"{mode}/{stop:06d}/segment.json"))
        checkpoint = info["checkpoint"]
        checked(checkpoint)
        archived.extend(((checked(verified),f"{mode}/{step:06d}/verification.json"),
                         (checked(info["receipt"]),f"{mode}/{step:06d}/completed.json")))
        for k in ("training_seconds","reader_and_cpu_fingerprints_seconds","checkpoint_seconds"):
            durations[k]+=info[k]
        accumulator.update(info["scene_types"])
        with checked(info["observations"]).open()as stream:
            for row in map(json.loads,stream):
                key,noise = row["source_id"],row["recipe"]["noise_seed"]
                assert row["index"]==len(photos) and key in allowed
                assert key not in photos and noise not in seeds
                photos.add(key)
                seeds.add(noise)
                queries+=len(row["boxes_xywh"])
        assert len(photos)==len(seeds)==step*config["scenes_per_step"]
        assert queries==len(photos)*config["crops_per_scene"]
        records.append(info|{"audit":verified})
    return dict(durations)|{"checkpoint":checkpoint,"photos":len(photos),"distinct_noise_seeds":len(seeds),
                            "native_queries":queries,"scene_counts":dict(accumulator),"phases":records},archived


def main():
    marker = reference(ROOT/"matched-010000.json")
    value = read_json(checked(marker))
    assert value["through_update"]==10000 and value["matched_input_traces"]
    assert not value["training_complete"]
    config = read_json(checked(value["plan"]))
    with checked(config["train_manifest"]).open()as stream:
        allowed = {json.loads(line)["id"]for line in stream}
    assert len(allowed)==90692
    arms = {}
    archive = OUTPUT/"matched-010000-training.tar.xz"
    monitor = reference(ROOT/"queue-monitor-010000-launch.json")
    cameras = reference(ROOT/"queue-native-010000-launch.json")
    with tarfile.open(archive,"x:xz")as tf:
        for file,name in ((checked(marker),"matched.json"),(checked(monitor),"monitor-launch.json"),
                          (checked(cameras),"standing-launch.json"),(Path(__file__),Path(__file__).name),
                          (ROOT/"milestone_native_fixed.py","milestone_native_fixed.py")):
            tf.add(file,arcname=name)
        for mode in ("none","spatial"):
            arms[mode],archived = arm(mode,value,config,allowed)
            for file,name in archived:
                tf.add(file,arcname=name)
    for a,b in zip(arms["none"]["phases"],arms["spatial"]["phases"],strict=True):
        assert a["observations"]["sha256"]==b["observations"]["sha256"]
    output = {"experiment":"scene-full-epoch-v1","training":marker,"parent":config["parent"],
              "training_manifest":config["train_manifest"],"eligible_photos":len(allowed),
              "update":10000,"inference_weights":"EMA","checkpoint_contents":"raw, EMA, Adam and RNG",
              "identical_input_traces_through_update":10000,"matched_intermediate_training_complete":True,
              "end_to_end_training_complete":False,"arms":arms,"numerical_collection_launch":monitor,
              "native_collection_launch":cameras,"last_quality_review_at_publication":7500,
              "archive":reference(archive)}
    write_json(OUTPUT/"matched-010000-training.json",output)
    print({m:{k:a[k]for k in ("photos","native_queries","scene_counts","training_seconds")}
           for m,a in arms.items()},flush=True)


if __name__=="__main__":
    main()
