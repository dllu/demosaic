"""Bind the disk-full resume to the frozen checkpoint and retest the local source prefix."""
from itertools import islice
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results/scene-full-epoch-v1')
PHASE = ROOT/'none-045000/segments'


def live_run():
    bound = reference(ROOT/'recovery-044000-launch.json')
    recovery = read_json(checked(bound))
    plan = read_json(checked(recovery['plan']))
    old = read_json(checked(recovery['resume_verification']))
    assert recovery['resume_checkpoint'] == old['checkpoint']
    checked(old['checkpoint'])
    assert read_json(checked(recovery['failed_attempt']['exit']))['returncode']==1
    failure = checked(recovery['failed_attempt']['log'])
    assert 'No space left on device' in failure.read_text()
    retries = PHASE/'through-044000'
    trained = retries/'attempt-02'
    started = reference(trained/'launch.json')
    launch = read_json(checked(started))
    assert launch['controller']==recovery['child'] and owner_live(launch['controller'])
    assert launch['command'][-3:]==['44000','--resume-receipt',str(checked(old['receipt']))]
    before = retries/'attempt-01/work/observations.jsonl'
    after = trained/'work/observations.jsonl'
    with before.open() as a, after.open() as b:
        n = 100
        prefix = list(islice(a,n))
        assert len(prefix) == n and list(islice(b,n)) == prefix
    assert all((ROOT/f'{mode}-{stop:06d}').is_symlink()
               and (ROOT/f'{mode}-{stop:06d}').resolve().is_relative_to('/mnt/external')
               for stop in plan['phase_stops'] if stop >= 45000 for mode in plan['modes'])
    for proof in recovery['migration'].values():
        checked(proof)
    return recovery, bound, old, started, prefix


def source_prefix(endpoint):
    previous = reference(OUT/'local-042500-prefix.json')
    scope = read_json(checked(previous))
    plan = read_json(checked(scope['plan']))
    ready = read_json(checked(scope['prefix_link']))
    historical = read_json(checked(ready['last_paired']))
    lineage = [r['observations'] for r in historical['arms']['none']['phases']]
    lineage.append(ready['arms']['none']['observations'])
    kept = scope['segments']
    lineage.extend(kept[str(step)]['observations'] for step in range(13000,42501,500))
    last = scope['checkpoint']
    total = scope['retained_training_seconds']
    pieces = []
    for step in range(43000,endpoint+1,500):
        ref = reference(PHASE/f'through-{step:06d}/verified.json')
        state = read_json(checked(ref))
        worker = read_json(checked(state['receipt']))
        assert worker['resume']==last and worker['plan']==scope['plan']
        assert worker['DINO_unchanged'] and worker['steps']==step and worker['start_step_exclusive']==step-500
        last = state['checkpoint']
        assert last == worker['checkpoints'][-1]
        checked(last)
        lineage.append(state['observations'])
        total += worker['seconds']
        pieces.append({'step':step,'part':ref,'receipt':state['receipt']})
    with checked(plan['train_manifest']).open() as f:
        allowed = {json.loads(line)['id'] for line in f}
    photos, seeds = set(), set()
    queries = 0
    for trace in lineage:
        with checked(trace).open() as stream:
            for line in stream:
                row = json.loads(line)
                name, seed = row['source_id'],row['recipe']['noise_seed']
                assert row['index']==len(photos) and name in allowed and name not in photos and seed not in seeds
                photos.add(name)
                seeds.add(seed)
                queries += len(row['boxes_xywh'])
    assert len(photos)==len(seeds)==2*endpoint and queries==8*endpoint
    return {'previous':previous,'checkpoint':last,'plan':scope['plan'],'local_verified_through':endpoint,
            'photos':len(photos),'eligible_photos':len(allowed),'queries':queries,'noise_seeds':len(seeds),
            'retained_training_seconds':total,'segments':pieces}


def main():
    recovery,bound,start,launch,prefix = live_run()
    endpoint = max(step for step in range(43000,45001,500) if (PHASE/f'through-{step:06d}/verified.json').is_file())
    audit = source_prefix(endpoint)
    archive = OUT/'storage-recovery-044000.tar.xz'
    with tarfile.open(archive,'x:xz') as pack:
        pack.add(Path(__file__),arcname='audit-storage-recovery.py')
        for label,src in [('launch-controller.json',bound),('launch-worker.json',launch),('verified-restart.json',recovery['resume_verification']),
                          ('migration.sh',recovery['migration']['script']),('migration.log',recovery['migration']['log']),
                          ('original-exit.json',recovery['failed_attempt']['exit']),('original-worker.log',recovery['failed_attempt']['log'])]:
            pack.add(checked(src),arcname=label)
        for part in audit['segments']:
            for label in ('part','receipt'):
                pack.add(checked(part[label]),arcname=f'{part["step"]}/{label}.json')
    write_json(OUT/'storage-recovery-044000.json',{
        'resume':bound,'resumed_worker':launch,'restart_checkpoint':start['checkpoint'],
        'prefix_equality':{'observations':len(prefix),'metadata_rows_byte_identical':True,
            'first_source_index':json.loads(prefix[0])['index'],'last_source_index':json.loads(prefix[-1])['index']},
        'retained_prefix':audit,'archive':reference(archive),
        'quality_review_matched_through':40000,'latest_paired_update_published':42500})
    print(audit,flush=True)


if __name__=='__main__':
    main()
