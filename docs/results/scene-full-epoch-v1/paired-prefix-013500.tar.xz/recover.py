"""Recover the observed pre-training stall without changing the frozen run."""
import os
from pathlib import Path
import subprocess
import time

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
ATTEMPT=ROOT/'spatial-015000/segments/through-013500/attempt-01'
PROOF=ROOT/'startup-recovery-013500.json'
LOG=ROOT/'controller-startup-recovery-013500.log'


def snapshot(path, child):
    p=psutil.Process(child['pid'])
    assert p.create_time()==child['created']
    return {'age_seconds':time.time()-p.create_time(),'process_cpu_s':p.cpu_times().user+p.cpu_times().system,
            'cpu_percent':p.cpu_percent(),'rss':p.memory_info().rss,'io':p.io_counters()._asdict(),
            'worker_log_size':(path/'worker.log').stat().st_size,
            'work_contents':sorted(q.name for q in (path/'work').iterdir())}


def main():
    first_binding=reference(ATTEMPT/'launch.json')
    first=read_json(checked(first_binding))
    assert owner_live(first['controller']) and owner_live(first['child'])
    assert psutil.Process(first['child']['pid']).ppid()==first['controller']['pid']
    marker=reference(ROOT/'spatial-015000/segments/through-013000/verified.json')
    verified=read_json(checked(marker))
    checked(verified['checkpoint'])
    confirmed=read_json(checked(verified['receipt']))
    assert confirmed['steps']==13000 and confirmed['DINO_unchanged']
    assert first['command'][-1]==verified['receipt']['path']
    initial=snapshot(ATTEMPT,first['child'])
    time.sleep(12)
    later=snapshot(ATTEMPT,first['child'])
    assert initial['work_contents']==later['work_contents']==['owner.json']
    assert initial['worker_log_size']==later['worker_log_size']==0
    assert initial['io']==later['io'] and later['age_seconds']>480 and later['process_cpu_s']>initial['process_cpu_s']
    assert read_json(ROOT/'status.json')==first
    write_json(PROOF,{'launch':first_binding,'retained_state':marker,'first':initial,'last':later,
                       'reason':'Worker spun before opening the training trace with no I/O/log progress. Retry from verified 13000.'})
    p=psutil.Process(first['child']['pid'])
    p.terminate()
    for _ in range(30):
        if not owner_live(first['controller']) and not owner_live(first['child']):
            break
        time.sleep(1)
    assert not owner_live(first['controller']) and not owner_live(first['child'])
    assert read_json(ATTEMPT/'exit.json')['returncode']==-15
    command=[str(Path.cwd()/'.venv/bin/python'),'-u',str(Path.cwd()/'scripts/resume_scene_full_epoch.py'),str(ROOT),'--segment-updates','500']
    env=dict(os.environ,PYTHONPATH='src:scripts',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1')
    with LOG.open('x')as f:
        process=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,env=env)
    resumed={'pid':process.pid,'created':psutil.Process(process.pid).create_time()}
    write_json(ROOT/'startup-recovery-013500-launch.json',{'previous_attempt':first_binding,'observation':reference(PROOF),
         'original_exit':reference(ATTEMPT/'exit.json'),'owner':resumed,'driver':reference(__file__),'command':command,'log':str(LOG)})
    print(resumed,flush=True)


if __name__=='__main__':
    main()
