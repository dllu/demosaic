"""Verify matching 13,500 updates and preserve the restart evidence."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
OUT=Path('docs/results/scene-full-epoch-v1')
prior=reference(OUT/'paired-prefix-013000.json')
last=read_json(checked(prior))
before=read_json(checked(last['prior']))
review=read_json(checked(before['last_paired']))
local15=read_json(OUT/'local-015000-prefix.json')
plan=read_json(checked(last['plan']))
views={}
for arm in ('none','spatial'):
    old=last['arms'][arm]['checkpoint']
    path=reference(ROOT/f'{arm}-015000/segments/through-013500/verified.json')
    note=read_json(checked(path))
    retained=read_json(checked(note['receipt']))
    assert retained['plan']==last['plan'] and retained['DINO_unchanged']
    assert (retained['start_step_exclusive'],retained['steps'],retained['schedule_steps'])==(13000,13500,50000)
    assert retained['resume']==old and retained['checkpoints'][-1]==note['checkpoint']
    checked(note['checkpoint'])
    views[arm]=note|{'verification':path}
assert views['none']['checkpoint']==local15['segments']['13500']['checkpoint']
assert views['none']['observations']['sha256']==views['spatial']['observations']['sha256']
checked(views['spatial']['observations'])
trace=[r['observations']for r in review['arms']['none']['phases']]+[v['arms']['none']['observations']for v in (before,last,{'arms':views})]
with checked(plan['train_manifest']).open()as f:
    legal={json.loads(line)['id']for line in f}
photos,seeds=set(),set()
queries=0
for raw in trace:
    with checked(raw).open()as f:
        for line in map(json.loads,f):
            name, seed=line['source_id'],line['recipe']['noise_seed']
            assert line['index']==len(photos) and name not in photos and name in legal and seed not in seeds
            photos.add(name)
            seeds.add(seed)
            queries+=len(line['boxes_xywh'])
assert len(photos)==len(seeds)==27000 and queries==108000
recovery=reference(ROOT/'startup-recovery-013500-launch.json')
new=read_json(checked(recovery))
why=read_json(checked(new['observation']))
assert why['last']['worker_log_size']==0 and why['last']['io']==why['first']['io']
assert read_json(checked(new['original_exit']))['returncode']==-15
assert owner_live(new['owner'])
segment=ROOT/'spatial-015000/segments/through-013500'
ended=read_json(segment/'attempt-02/launch.json')
assert ended['controller']==new['owner']
assert ended['command'][-1]==last['arms']['spatial']['receipt']['path']
archive=OUT/'paired-prefix-013500.tar.xz'
with tarfile.open(archive,'x:xz')as tar:
    for arm,note in views.items():
        tar.add(checked(note['verification']),arcname=arm+'/verified.json')
        tar.add(checked(note['receipt']),arcname=arm+'/completed.json')
    for label,binding in (('recovery-launch.json',recovery),('stall-observation.json',new['observation']),
                           ('stalled-worker/launch.json',new['previous_attempt']),('stalled-worker/exit.json',new['original_exit'])):
        tar.add(checked(binding),arcname=label)
    files=((Path(__file__),Path(__file__).name),(ROOT/'recover-spatial-013500.py','recover.py'),
           (segment/'attempt-01/startup-backtrace.log','stalled-worker/attach.log'),
           (segment/'attempt-02/launch.json','resumed-worker/launch.json'),
           (segment/'attempt-02/worker.log','resumed-worker/worker.log'))
    for file,name in files:
        tar.add(file,arcname=name)
write_json(OUT/'paired-prefix-013500.json',{'prior':prior,'plan':last['plan'],'recovery':recovery,
          'verified_match_through_update':13500,'photos_per_arm':len(photos),'native_queries_per_arm':queries,
          'noise_seeds_per_arm':len(seeds),'quality_complete_through':12000,'arms':views,'archive':reference(archive)})
