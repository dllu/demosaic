"""Recover the matched 5k renderer without recollecting source predictions."""
import os
from pathlib import Path
import subprocess
import sys
import time

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

directory = Path(__file__).resolve().parent
root = directory / "review-native-005000"
owner = read_json(directory / "queue-native-005000-launch.json")["owner"]
while owner_live(owner):
    time.sleep(15)
working = root / "work"
receipt = read_json(root / "collection.json")
for entry in receipt["epochs"].values():
    checked(entry)
original = root / "render.py"
failure = root / "render.log"
assert "ValueError: Output must be inside" in failure.read_text()
assert str(root / "render/triplets") in failure.read_text()
program = original.read_text()
prior = "output=root/'render';output.mkdir()"
assert program.count(prior) == 1
program = program.replace(prior, "output=root/'work'/'render';output.mkdir()")
program = program.replace("ISO100 AHD, not GT", "ISO100 AHD reference")
recovery = root / "render-v2.py"
with recovery.open("x") as stream:
    stream.write(program)
env = os.environ | {"PYTHONPATH": f"{working}/src:{working}/scripts"}
with (root / "render-v2.log").open("xb") as stream:
    subprocess.run([sys.executable, str(recovery)], env=env, check=True, stdout=stream, stderr=subprocess.STDOUT)
result = working / "render/result.json"
evidence = read_json(result)
assert len(evidence["boards"]) == 16 and len(evidence["triplets"]) == 8
write_json(root / "render-v2-recovery.json", {
    "collection": reference(root / "collection.json"), "owner": owner,
    "original_driver": reference(original), "original_failure": reference(failure),
    "driver": reference(recovery), "log": reference(root / "render-v2.log"),
    "result": reference(result), "native_viewing_complete": False,
})
