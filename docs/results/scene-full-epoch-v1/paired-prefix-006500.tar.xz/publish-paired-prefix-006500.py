"""Verify checkpoint bindings and identical inputs across the paired 6,500 prefix."""
from collections import Counter
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
RESULT=Path("docs/results/scene-full-epoch-v1")

def progress():
    source=reference(RESULT/"matched-005000-training.json")
    known=read_json(checked(source))
    plans=known["training"]
    mark=read_json(checked(plans))
    assert mark["matched_input_traces"] and mark["through_update"]==5000
    formal=read_json(checked(mark["plan"]))
    with checked(formal["train_manifest"]).open()as f:
        manifest={json.loads(p)["id"]for p in f}
    assert len(manifest)==90692
    handled=set();seeds=set()
    total=0
    for row in known["arms"]["none"]["phases"]:
        with checked(row["observations"]).open()as stream:
            for line in stream:
                example=json.loads(line)
                assert example["index"]==len(handled)
                handled.add(example["source_id"])
                seeds.add(example["recipe"]["noise_seed"])
                total+=len(example["boxes_xywh"])
    assert len(handled)==len(seeds)==10000 and total==40000
    stats={}
    sources=[]
    for step in (5500,6000,6500):
        by_mode={}
        for mode in ("none","spatial"):
            work=ROOT/f"{mode}-007500"/"segments"/f"through-{step:06d}"
            candidates=sorted(work.glob("attempt-*/work/completed.json"))
            assert len(candidates)==1
            record=reference(candidates[0])
            proof=read_json(checked(record))
            assert proof["mode"]==mode and proof["plan"]==mark["plan"] and proof["DINO_unchanged"]
            assert (proof["start_step_exclusive"],proof["steps"],proof["schedule_steps"])==(step-500,step,50000)
            checked(proof["checkpoints"][-1])
            checked(proof["observations"])
            by_mode[mode]=(record,proof)
            sources.append((checked(record),f"{mode}/{step:06d}/completed.json"))
        local,spatial=(by_mode[mode][1]for mode in ("none","spatial"))
        assert local["observations"]["sha256"]==spatial["observations"]["sha256"]
        with checked(local["observations"]).open()as stream:
            for item in map(json.loads,stream):
                key,noise=item["source_id"],item["recipe"]["noise_seed"]
                assert item["index"]==len(handled) and key not in handled and noise not in seeds and key in manifest
                handled.add(key)
                seeds.add(noise)
                total+=len(item["boxes_xywh"])
        assert len(handled)==len(seeds)==2*step and total==8*step
        stats[str(step)]={m:{"receipt":pointer,"checkpoint":result["checkpoints"][-1],
                             "observations":result["observations"],"seconds":result["seconds"],
                             "data_seconds":result["data_seconds"]}for m,(pointer,result)in by_mode.items()}
    status=read_json(ROOT/"status.json")
    assert owner_live(status["controller"]) and owner_live(status["child"])
    assert "spatial-007500/segments" in status["attempt"]
    archive=RESULT/"paired-prefix-006500.tar.xz"
    with tarfile.open(archive,"x:xz")as dest:
        for path,name in sources:
            dest.add(path,arcname=name)
        dest.add(Path(__file__),arcname=Path(__file__).name)
    write_json(RESULT/"paired-prefix-006500.json",{"training":mark["plan"],"last_5000_proof":source,
        "matched_update":6500,"distinct_sources_per_arm":len(handled),"distinct_noise_seeds_per_arm":len(seeds),
        "native_queries_per_arm":total,"latest_quality_review":5000,"trace_equal_through":6500,
        "segments":stats,"active":status,"archive":reference(archive)})
    print(len(handled),total,stats["6500"]["spatial"]["checkpoint"]["sha256"],flush=True)

if __name__=="__main__":
    progress()
