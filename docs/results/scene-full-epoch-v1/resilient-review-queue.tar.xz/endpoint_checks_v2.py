"""Collect the fixed benchmark and native standing comparisons after training."""

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import (
    checked,
    freeze_sources,
    read_json,
    reference,
    verify_plan,
    write_json,
)
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]
OLDER = ROOT.parent / "expanded-scene-12000-native-v1"
CANONICAL = ROOT.parent / "scene-local-contrast-2400-v1/reviews/canonical"


def invoke(directory, work, driver, plan, action):
    env = os.environ | {
        "CUDA_VISIBLE_DEVICES": "",
        "PYTHONPATH": f"{work}/src:{work}/scripts",
        "OMP_NUM_THREADS": "2",
        "OPENBLAS_NUM_THREADS": "1",
    }
    command = [sys.executable, "-u", str(driver), str(checked(plan)), action]
    while psutil.virtual_memory().available < 48 * 2**30:
        time.sleep(30)
    with (directory / f"{action}.log").open("xb") as stream:
        child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=env)
        write_json(
            directory / f"{action}-launch.json",
            {
                "command": command,
                "pid": child.pid,
                "created": psutil.Process(child.pid).create_time(),
            },
        )
        code = child.wait()
    write_json(directory / f"{action}-exit.json", {"returncode": code})
    if code:
        raise subprocess.CalledProcessError(code, command)


def wait_for_match():
    worker = read_json(ROOT / "launch.json")["owner"]
    marker = ROOT / "matched-050000.json"
    while not marker.is_file():
        if not owner_live(worker):
            raise RuntimeError("Training stopped before the final matched receipt")
        time.sleep(30)
    record = read_json(marker)
    assert (
        record["training_complete"]
        and record["matched_input_traces"]
        and record["through_update"] == 50_000
    )
    return reference(marker), record


def native(directory, proof, matched):
    historical = reference(OLDER / "plan.json")
    template = read_json(checked(historical))
    assert len(template["observations"]) == 10
    previous = read_json(OLDER / "collection.json")
    parent = reference(checked(previous["parent"]))
    train = matched["plan"]
    assert read_json(checked(train))["parent"] == template["parent"]
    directory.mkdir()
    training_paths = directory / "training"
    training_paths.mkdir()
    for mode, summary in matched["arms"].items():
        (training_paths / mode).symlink_to(
            checked(summary["receipt"]).parent, target_is_directory=True
        )
    work, sources = freeze_sources(REPOSITORY, directory, ["review_scene_context_native.py"])
    driver = work / "scripts/review_scene_context_native.py"
    new_sources = (historical, train, proof, parent, reference(__file__))
    updated = template | {
        "root": str(directory),
        "training_plan": train,
        "training_output_root": str(training_paths),
        "sources": sources | {row["path"]: row["sha256"] for row in new_sources},
        "script": reference(driver),
    }
    plan_path = directory / "plan.json"
    write_json(plan_path, updated)
    plan = reference(plan_path)
    variants = {}
    for mode, summary in matched["arms"].items():
        invoke(directory, work, driver, plan, mode)
        result = reference(directory / mode / "collection.json")
        assert read_json(checked(result))["checkpoint"] == summary["checkpoint"]
        variants[mode] = result
    write_json(
        directory / "collection.json",
        {
            "plan": plan,
            "training": proof,
            "V120": template["baseline_collection"],
            "parent": parent,
            "epochs": variants,
            "actual_native_viewed": False,
        },
    )
    renderer = (OLDER / "render.py").read_text()
    edits = {
        "assert training['trained'] and training['native_examples_per_arm']==96000": "assert training['training_complete'] and training['through_update']==50000",
        "training['endpoints'][arm]['EMA']": "training['arms'][arm]['checkpoint']",
        "Local-only 12k EMA": "Local-only 50k EMA",
        "Spatial 12k EMA": "Spatial 50k EMA",
        "spatial 12k EMA": "spatial 50k EMA",
        "output=root/'render';output.mkdir()": "output=root/'work'/'render';output.mkdir()",
        "ISO100 AHD, not GT": "ISO100 AHD reference",
    }
    for old, new in edits.items():
        assert old in renderer
        renderer = renderer.replace(old, new)
    render = directory / "render.py"
    render.write_text(renderer)
    env = os.environ | {"PYTHONPATH": f"{work}/src:{work}/scripts"}
    with (directory / "render.log").open("xb") as log:
        subprocess.run(
            [sys.executable, str(render)], env=env, stdout=log, stderr=subprocess.STDOUT, check=True
        )
    result = read_json(directory / "work/render/result.json")
    assert len(result["boards"]) == 16 and len(result["triplets"]) == 8


def canonical(directory, proof, matched):
    historical = reference(CANONICAL / "full-plan.json")
    template = read_json(checked(historical))
    for name in ("canonical_inputs", "photo_inventory", "parent_CPU_probes"):
        checked(template[name])
    directory.mkdir()
    work, files = freeze_sources(REPOSITORY, directory, ["collect_scene_primary.py"])
    driver = work / "scripts/collect_scene_primary.py"
    endpoints = {name: template["models"][name] for name in ("V120", "parent100k")}
    for mode, summary in matched["arms"].items():
        endpoints[mode] = {"kind": "scene", "checkpoint": summary["checkpoint"], "step": 50_000}
    assert endpoints["parent100k"]["checkpoint"] == read_json(checked(matched["plan"]))["parent"]
    bindings = [
        historical,
        proof,
        reference(__file__),
        *[template[name] for name in ("canonical_inputs", "photo_inventory", "parent_CPU_probes")],
        *[row["checkpoint"] for row in endpoints.values()],
        *[config["manifest"] for config in template["stages"].values() if "manifest" in config],
    ]
    base = template | {
        "root": str(directory),
        "work": str(work),
        "frozen_files": files,
        "inputs": bindings,
        "driver": reference(driver),
        "models": endpoints,
        "training_arm_aliases": {},
        "CPU_affinity": [6, 7, 15, 16],
        "CPU_threads": 4,
    }
    base.pop("preflight")
    verify_plan(base)
    preflight_path = directory / "preflight-plan.json"
    write_json(preflight_path, base)
    invoke(directory, work, driver, reference(preflight_path), "preflight")
    preflight = reference(directory / "preflight/result.json")
    assert read_json(checked(preflight))["cases"] == 3
    full_path = directory / "full-plan.json"
    write_json(full_path, base | {"preflight": preflight, "inputs": [*bindings, preflight]})
    invoke(directory, work, driver, reference(full_path), "full")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("panel", choices=("canonical", "native"))
    action = parser.parse_args().panel
    receipt, result = wait_for_match()
    {"canonical": canonical, "native": native}[action](ROOT / f"endpoint-{action}", receipt, result)
