"""Verify the paired prefix from the completed 12k review to 12,500 updates."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results/scene-full-epoch-v1')
last = reference(OUT/'matched-012000-training.json')
previous = read_json(checked(last))
match = reference(ROOT/'matched-012500.json')
data = read_json(checked(match))
assert data['through_update'] == 12500 and data['matched_input_traces']
assert not data['training_complete']
plan = read_json(checked(data['plan']))
assert previous['eligible_photos'] == 90692
with checked(plan['train_manifest']).open() as file:
    eligible = {json.loads(line)['id'] for line in file}
assert len(eligible)==previous['eligible_photos']
observations = [r['observations'] for r in previous['arms']['none']['phases']]
views = {}
original = []
for arm, actual in data['arms'].items():
    earlier = previous['arms'][arm]
    receipt = read_json(checked(actual['receipt']))
    assert receipt['plan'] == data['plan'] and receipt['DINO_unchanged']
    assert receipt['steps']==12500 and receipt['schedule_steps']==50000
    assert len(receipt['segments']) == 1
    segment = receipt['segments'][0]
    current = read_json(checked(segment))
    assert current['resume'] == earlier['checkpoint']
    assert current['start_step_exclusive'] == 12000
    assert current['checkpoints'][-1] == actual['checkpoint']
    checked(actual['checkpoint'])
    original.extend(((actual['receipt'], f'{arm}-combined.json'), (segment, f'{arm}-segment.json')))
    views[arm] = actual | {'total_retained_training_seconds':earlier['training_seconds']+actual['training_seconds']}
assert views['none']['observations']['sha256']==views['spatial']['observations']['sha256']
observations.append(views['none']['observations'])
sources, seeds = set(), set()
queries = 0
for binding in observations:
    with checked(binding).open() as f:
        for row in map(json.loads,f):
            photo,seed = row['source_id'],row['recipe']['noise_seed']
            assert row['index']==len(sources) and photo in eligible
            assert photo not in sources and seed not in seeds
            sources.add(photo)
            seeds.add(seed)
            queries += len(row['boxes_xywh'])
assert len(sources)==len(seeds)==25000 and queries==100000
controller = reference(ROOT/'owner.json')
assert owner_live(read_json(checked(controller)))
archive = OUT/'paired-prefix-012500.tar.xz'
retry = ROOT/'none-012500/segments/through-012500/attempt-01'
assert 'Training RAM reserve unavailable' in (retry/'worker.log').read_text()
with tarfile.open(archive,'x:xz') as tar:
    for binding, name in ((match,'matched.json'),*original):
        tar.add(checked(binding),arcname=name)
    tar.add(Path(__file__),arcname=Path(__file__).name)
    for path in ('launch.json','worker.log','exit.json','work/observations.jsonl','work/train.jsonl'):
        tar.add(retry/path,arcname='discarded-local/'+path)
write_json(OUT/'paired-prefix-012500.json',{'last_paired':last,'matched':match,'plan':data['plan'],'controller':controller,
          'verified_match_through_update':12500,'photos_per_arm':len(sources),'native_queries_per_arm':queries,
          'noise_seeds_per_arm':len(seeds),'quality_complete_through':12000,'arms':views,'archive':reference(archive)})
print(len(sources),queries,*(v['total_retained_training_seconds'] for v in views.values()),flush=True)
