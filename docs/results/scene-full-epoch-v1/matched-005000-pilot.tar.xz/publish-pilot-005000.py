"""Publish exact-target native crops and fixed monitor results from matched 5k."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
PILOT = ROOT/"review-005000/pilot"
OUTPUT = Path("docs/results/scene-full-epoch-v1")
IMAGES = Path("docs/images/scene-full-epoch-v1/pilot-005000")


def main():
    result = reference(PILOT/"results.json")
    numerical = read_json(checked(result))
    plan = read_json(checked(numerical["plan"]))
    run = read_json(checked(plan["training_snapshot"]))
    prior = read_json(ROOT/"review-002000/pilot/results.json")
    prior_plan = read_json(checked(prior["plan"]))
    assert plan["panel"]==prior_plan["panel"] and plan["selected_indices"]==prior_plan["selected_indices"]
    assert run["through_update"]==5000 and run["matched_input_traces"]
    for model,record in run["arms"].items():
        assert {k:plan["models"][model][k]for k in ("path","sha256")}==record["checkpoint"]
        checked(record["checkpoint"])
    assert len(numerical["source_metrics"])==32 and len(numerical["native"])==4
    for previous,now in zip(prior["source_metrics"],numerical["source_metrics"],strict=True):
        keys = ("source","profile","draw")
        assert all(previous[k]==now[k]for k in keys)
        assert all(previous["metrics"][k]==now["metrics"][k]for k in ("V120","100k"))
    notes = read_json(PILOT/"viewing.json")
    IMAGES.mkdir()
    for row in numerical["native"]:
        row["actual_native_viewing"] = notes[row["id"]]
        for role in ("board","triplet"):
            artifact = row[role]
            source = checked(artifact["image"])
            dest = IMAGES/source.name
            shutil.copyfile(source,dest)
            with Image.open(dest)as png:
                for pane in artifact["panels"]:
                    x,y,w,h = pane["png_xywh"]
                    assert w==h==160 and x+w<=png.width and y+h<=png.height
                png.verify()
            assert artifact["image"]["sha256"]==reference(dest)["sha256"]
            artifact["image"] = {"path":str(dest),"sha256":artifact["image"]["sha256"]}
    archive = OUTPUT/"matched-005000-pilot.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for path in ("plan.json","collected.json","results.json","viewing.json"):
            f.add(PILOT/path,arcname=path)
        for path in ("queue-monitor-005000.log","queue-monitor-005000-launch.json","monitor_bound.py"):
            f.add(ROOT/path,arcname=path)
        f.add(Path(__file__),arcname=Path(__file__).name)
        for prediction in (PILOT/"predictions").glob("*.json"):
            f.add(prediction,arcname=f"predictions/{prediction.name}")
    write_json(OUTPUT/"matched-005000-pilot.json",{
        "source":result,"archive":reference(archive),"training":plan["training_snapshot"],
        "aligned_intervention_paired_monitor_complete":True,"actual_native_monitor_views_complete":True,
        "results":numerical|{"actual_native_review_complete":True},
        "scope":"Same eight fixed photo fields as 2k. Both standing GFX and comparable broad panels are separate.",
    })


if __name__=="__main__":
    main()
