"""Time the scene's CPU sensor work and verify a zero-noise fast path."""
from collections import Counter
from contextlib import ExitStack
import json
from pathlib import Path
import statistics
import time
from unittest.mock import patch

import torch

from demosaic import scene_data
from demosaic.experiments.artifacts import read_json, reference, write_json
from scripts.train_scene_context import training_dataset

ROOT = Path(__file__).resolve().parent
BASE = scene_data.add_noise


def specialized(clean, shot, read, *, bit_depth=16, black_level=0.0, generator=None):
    if shot or read:
        return BASE(clean, shot, read, bit_depth=bit_depth, black_level=black_level, generator=generator)
    black = torch.as_tensor(black_level, device=clean.device, dtype=torch.float32)
    levels = (1 << bit_depth) - 1
    adc = (clean * (1 - black) + black).clamp(0, 1)
    return ((adc * levels).round() / levels - black) / (1 - black)


def timed_trial(dataset, trace, noise_function, instrument):
    times = Counter()
    words = []
    hooks = ((scene_data, 'add_noise', noise_function), (scene_data, 'camera_pair', scene_data.camera_pair),
             (scene_data, 'mosaic', scene_data.mosaic), (torch, 'poisson', torch.poisson),
             (torch, 'randn', torch.randn))

    def wrapper(name, fn):
        def measure(*args, **kwargs):
            start = time.perf_counter()
            result = fn(*args, **kwargs)
            times[name] += time.perf_counter() - start
            return result
        return measure

    with ExitStack() as stack:
        for module, name, fn in hooks:
            if instrument or name == 'add_noise':
                stack.enter_context(patch.object(module, name, wrapper(name, fn) if instrument else fn))
        start = time.perf_counter()
        for expected in trace:
            sample = dataset[expected['index']]
            words.append(sample.metadata)
            del sample
        times['elapsed'] = time.perf_counter() - start
    assert json.dumps(words, sort_keys=True) == json.dumps(trace, sort_keys=True)
    return dict(times)


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    plan = reference(ROOT / 'plan.json')
    dataset = training_dataset(read_json(plan['path']))
    marker = read_json(ROOT / 'none-010000/verified.json')
    binding = reference(marker['observations']['path'])
    assert binding == marker['observations']
    pools = {'clean': [], 'noisy': []}
    with Path(binding['path']).open() as f:
        for row in map(json.loads, f):
            if row['index'] % 7 or row['index'] < 18100:
                continue
            group = 'clean' if row['recipe']['shot'] == row['recipe']['read'] == 0 else 'noisy'
            if len(pools[group]) < 24:
                pools[group].append(row)
    assert all(len(rows) == 24 for rows in pools.values())
    traces = {}
    for kind, rows in pools.items():
        timed_trial(dataset, rows, BASE, instrument=False)
        timings = {'base': [], 'specialized': []}
        for trial in (('base','specialized'), ('specialized','base'), ('specialized','base'), ('base','specialized')):
            for variant in trial:
                timings[variant].append(timed_trial(dataset, rows, BASE if variant == 'base' else specialized, instrument=True))
        medians = {label: {key: statistics.median(record.get(key, 0.0) for record in records)
                           for key in ('elapsed','camera_pair','mosaic','add_noise','poisson','randn')}
                   for label, records in timings.items()}
        traces[kind] = {'indices': [row['index'] for row in rows], 'timings': timings, 'median_seconds': medians}
    output = {'driver': reference(__file__), 'sensor': reference(scene_data.__file__), 'plan': plan, 'observations': binding,
              'exact_retained_metadata_every_pass': True, 'groups': traces,
              'scope': '24 clean and 24 noisy retained training scene observations selected by index. Both variants use a warm filesystem and previously validated source hashes. Nested timers overlap. No GPU or training timing.'}
    write_json(ROOT / 'profile-sensor-stages.json', output)
    print(json.dumps({k: v['median_seconds'] for k, v in traces.items()}, indent=2), flush=True)


if __name__ == '__main__':
    main()
