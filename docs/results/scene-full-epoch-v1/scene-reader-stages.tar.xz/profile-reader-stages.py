"""Profile the unchanged whole-scene data reader over verified training inputs."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import time
from unittest.mock import patch

import numpy as np
import torch

from demosaic import scene_training_data as data
from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.prediction_archive import _array
from scripts.train_scene_context import training_dataset

ROOT = Path(__file__).resolve().parent


def buffered_fingerprint(value):
    array = _array(value)
    return {'shape': list(array.shape), 'dtype': array.dtype.str,
            'sha256': hashlib.sha256(memoryview(array)).hexdigest()}


def profile(dataset, indices, implementation):
    timer = Counter()
    original = {'source_sha256': data.reference, 'npy_open': np.load,
                'raw_simulation_and_pack': data.observe_scene, 'tensor_fingerprints': implementation}

    def measured(name):
        def call(*args, **kwargs):
            start = time.perf_counter()
            result = original[name](*args, **kwargs)
            timer[name] += time.perf_counter() - start
            return result
        return call

    rows = []
    start = time.perf_counter()
    with (patch.object(data, 'reference', measured('source_sha256')),
          patch.object(data.np, 'load', measured('npy_open')),
          patch.object(data, 'observe_scene', measured('raw_simulation_and_pack')),
          patch.object(data, 'fingerprint', measured('tensor_fingerprints'))):
        for index in indices:
            sample = dataset[index]
            rows.append(sample.metadata)
            del sample
    timer['total'] = time.perf_counter() - start
    timer['other'] = timer['total'] - sum(v for k, v in timer.items() if k != 'total')
    return dict(timer), rows


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    plan = reference(ROOT / 'plan.json')
    dataset = training_dataset(read_json(plan['path']))
    marker = read_json(ROOT / 'none-010000/verified.json')
    receipts = reference(marker['observations']['path'])
    assert receipts == marker['observations']
    indices = sorted({19032 + 37 * k for k in range(24)})
    words = set(indices)
    with Path(receipts['path']).open() as trace:
        expected = [row for row in map(json.loads, trace) if row['index'] in words]
    assert len(expected) == len(indices)
    existing = data.fingerprint
    for probe in (np.zeros((0, 3)), np.asarray(3), np.arange(100, dtype='>f4')[1::3],
                  np.arange(64, dtype=np.uint16).reshape(8, 8).T, torch.arange(16)[::3]):
        assert buffered_fingerprint(probe) == existing(probe)
    data_times = {'bytes': [], 'buffer': []}
    for first in ('bytes', 'buffer', 'buffer', 'bytes'):
        for label in (first, 'buffer' if first == 'bytes' else 'bytes'):
            dataset.checked_files.clear()
            implementation = existing if label == 'bytes' else buffered_fingerprint
            timing, observed = profile(dataset, indices, implementation)
            digest = lambda values: json.dumps(values, sort_keys=True, separators=(',', ':'))
            assert digest(observed) == digest(expected)
            data_times[label].append(timing)
    medians = {label: {k: statistics.median(row[k] for row in rows) for k in rows[0]}
               for label, rows in data_times.items()}
    result = {'plan': plan, 'observations': receipts, 'driver': reference(__file__),
              'dataset_driver': reference(Path(data.__file__)), 'reference_fingerprint': reference(Path(_array.__code__.co_filename)),
              'indices': indices, 'source_count': len(expected), 'canonical_metadata_matches_retained_trace_every_pass': True,
              'seconds_per_pass': data_times, 'median_seconds_per_pass': medians,
              'scope': 'CPU two-thread profile, four passes per variant at fixed retained photos and seeds. Each pass rechecks source SHA. Filesystem cache unmanaged. No model or training-step timing.'}
    write_json(ROOT / 'profile-reader-stages.json', result)
    print(json.dumps(medians, indent=2), flush=True)


if __name__ == '__main__':
    main()
