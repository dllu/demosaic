"""Publish the 25k photo evidence with native standing quality still separate."""
import hashlib
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
STAGE=ROOT/"review-full-025000/evaluation"
OUT=Path("docs/results/scene-full-epoch-v1")


def main():
    interval=reference(STAGE/"context-intervals.json")
    summary=read_json(checked(interval))
    result=read_json(checked(summary["25k_numeric"]))
    plan=read_json(checked(result["plan"]))
    training=read_json(checked(plan["training_snapshot"]))
    old=read_json(checked(summary["20k_numeric"]))
    data=read_json(checked(result["collection"]))
    assert plan["training_snapshot"]==reference(ROOT/"matched-025000.json")
    assert training["through_update"]==25000 and training["matched_input_traces"]
    assert len(data["records"])==len(result["source_metrics"])==len(old["source_metrics"])==256
    assert len(result["native"])==4
    parts={name:STAGE/name for name in (
        "results.json","plan.json","collected.json","context-intervals.json")}
    parts|={name:ROOT/name for name in (
        "monitor_full_025000.py","summarize_025000.py","summarize_020000.py",
        "publish-025000-numerical.py","queue-full-photo-025000.log")}
    parts["source-panel.json"]=checked(plan["panel"])
    bundle=OUT/"matched-025000-monitor.tar.xz"
    with tarfile.open(bundle,"x:xz",preset=4)as handle:
        for name,file in sorted(parts.items()):
            handle.add(file,arcname=name,recursive=False)
    with tarfile.open(bundle)as handle:
        for name,file in parts.items():
            with handle.extractfile(name)as source_file:
                assert hashlib.file_digest(source_file,"sha256").hexdigest()==reference(file)["sha256"]
    write_json(OUT/"matched-025000-monitor.json",{
        "source":summary["25k_numeric"],"comparison_source":summary["20k_numeric"],
        "driver":reference(__file__),"intervals":interval,"plan":result["plan"],
        "training_snapshot":plan["training_snapshot"],"collection":result["collection"],
        "complete_photo_groups":256,"distinct_photos":64,"exact_crop_boards":4,
        "state":"Complete numerical photo readout. Standing GFX and complete native review still separate.",
        "archive":reference(bundle),"all_64":summary["all_64"],
    })
    print("Published full 25k photo numbers with training and per-source bindings.")


if __name__=="__main__":
    main()
