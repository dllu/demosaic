"""Accumulate matched source coverage across checked 500-update checkpoints."""
import json
from pathlib import Path
import sys
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path('docs/results/scene-full-epoch-v1')
MINIMUM = 25000
MODES = ('none','spatial')


def main(endpoint):
    prior = reference(RESULTS/f'paired-prefix-{endpoint-500:06d}.json')
    previous = read_json(checked(prior))
    plan = read_json(checked(previous['plan']))
    segments = {}
    for mode in MODES:
        proof = reference(ROOT/f'{mode}-027500/segments/through-{endpoint:06d}/verified.json')
        note = read_json(checked(proof))
        retained = read_json(checked(note['receipt']))
        assert retained['plan'] == previous['plan'] and retained['DINO_unchanged']
        assert (retained['start_step_exclusive'],retained['steps'],retained['schedule_steps']) == (endpoint-500,endpoint,50000)
        assert retained['resume'] == previous['arms'][mode]['checkpoint']
        assert retained['checkpoints'][-1] == note['checkpoint']
        checked(note['checkpoint'])
        checked(note['observations'])
        segments[mode] = note | {'verification':proof,'retained_training_seconds':retained['seconds']}
    local20 = read_json(RESULTS/'local-027500-prefix.json')
    assert segments['none']['checkpoint'] == local20['segments'][str(endpoint)]['checkpoint']
    assert segments['none']['observations']['sha256'] == segments['spatial']['observations']['sha256']
    traces = [segments['none']['observations']]
    seconds = {k:segments[k]['retained_training_seconds'] for k in MODES}
    prior_segment = previous
    while 'phases' not in prior_segment['arms']['none']:
        arms = prior_segment['arms']
        traces.append(arms['none']['observations'])
        for k in MODES:
            seconds[k] += read_json(checked(arms[k]['receipt']))['seconds']
        prior_segment = read_json(checked(prior_segment.get('prior', prior_segment.get('last_paired'))))
    for mode in MODES:
        seconds[mode] += sum(read_json(checked(phase['receipt']))['seconds'] for phase in prior_segment['arms'][mode]['phases'])
    traces = [r['observations'] for r in prior_segment['arms']['none']['phases']] + list(reversed(traces))
    with checked(plan['train_manifest']).open() as f:
        legal = {json.loads(line)['id'] for line in f}
    photos, seeds = set(), set()
    queries = 0
    for trace in traces:
        with checked(trace).open() as stream:
            for row in map(json.loads,stream):
                name, seed = row['source_id'],row['recipe']['noise_seed']
                assert row['index'] == len(photos) and name in legal and name not in photos and seed not in seeds
                photos.add(name)
                seeds.add(seed)
                queries += len(row['boxes_xywh'])
    assert len(photos) == len(seeds) == 2 * endpoint and queries == 8 * endpoint
    stem = RESULTS/f'paired-prefix-{endpoint:06d}'
    archive = stem.with_suffix('.tar.xz')
    with tarfile.open(archive,'x:xz') as tar:
        tar.add(Path(__file__),arcname=Path(__file__).name)
        for mode,note in segments.items():
            tar.add(checked(note['verification']),arcname=f'{mode}/verified.json')
            tar.add(checked(note['receipt']),arcname=f'{mode}/completed.json')
            logfile = checked(note['receipt']).parent.parent/'worker.log'
            if logfile.exists():
                tar.add(logfile,arcname=f'{mode}/worker.log')
    write_json(stem.with_suffix('.json'),{'prior':prior,'plan':previous['plan'],
               'verified_match_through_update':endpoint,'photos_per_arm':len(photos),
               'eligible_training_photos':len(legal),'noise_seeds_per_arm':len(seeds),
               'native_queries_per_arm':queries,'retained_training_seconds':seconds,
               'quality_complete_through':MINIMUM,'arms':segments,'archive':reference(archive)})
    print(endpoint,len(photos),queries,seconds)


if __name__=='__main__':
    main(int(sys.argv[1]))
