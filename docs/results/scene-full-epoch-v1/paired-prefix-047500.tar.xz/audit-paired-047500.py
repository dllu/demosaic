"""Verify the local and spatial traces agree after 4,308 second-pass photos."""
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
RESULTS=Path('docs/results/scene-full-epoch-v1')
END=47500
START=45346
MODES=('none','spatial')


def bound(item):
    return read_json(checked(item))


def main():
    initial=reference(RESULTS/f'paired-prefix-{START:06d}.json')
    prior=bound(initial)
    local_ref=reference(RESULTS/f'local-{END:06d}-second-epoch.json')
    local=bound(local_ref)
    mark=reference(ROOT/f'matched-{END:06d}.json')
    match=bound(mark)
    assert (match['first_step_exclusive'],match['through_update'])==(START,END)
    assert match['matched_input_traces'] and match['plan']==prior['plan']
    assert local['first_epoch']==initial and local['verified_to_update']==END
    traces={}
    segments={}
    seconds={}
    for mode in MODES:
        arm=match['arms'][mode]
        verified=reference(ROOT/f'{mode}-{END:06d}/verified.json')
        assert bound(verified)==arm
        source=bound(arm['receipt'])
        assert source['resume']==prior['arms'][mode]['checkpoint'] and source['DINO_unchanged']
        assert source['steps']==END and source['start_step_exclusive']==START
        assert source['schedule_steps']==50000 and source['plan']==prior['plan']
        checked(arm['observations'])
        assert source['observations']==arm['observations']
        seconds[mode]=source['seconds']
        previous=source['resume']
        start=START
        result=[]
        for receipt in source['segments']:
            segment=bound(receipt)
            assert segment['resume']==previous and segment['start_step_exclusive']==start
            assert segment['DINO_unchanged'] and segment['plan']==prior['plan']
            previous=segment['checkpoints'][-1]
            start=segment['steps']
            checked(segment['observations'])
            checked(previous)
            result.append(dict(receipt=receipt,update=start,observations=segment['observations'],checkpoint=previous))
        assert start==END and previous==arm['checkpoint']
        traces[mode]=arm['observations']['sha256']
        segments[mode]=result
    assert local['checkpoint']==match['arms']['none']['checkpoint']
    assert traces['none']==traces['spatial']
    for a,b in zip(segments['none'],segments['spatial'],strict=True):
        assert a['update']==b['update'] and a['observations']['sha256']==b['observations']['sha256']
    archive=RESULTS/f'paired-prefix-{END:06d}.tar.xz'
    with tarfile.open(archive,'x:xz')as tar:
        tar.add(__file__,arcname=Path(__file__).name)
        tar.add(checked(mark),arcname='matched.json')
        for mode,rows in segments.items():
            tar.add(checked(match['arms'][mode]['receipt']),arcname=f'{mode}/combined.json')
            for row in rows:
                tar.add(checked(row['receipt']),arcname=f"{mode}/{row['update']:06d}.json")
    out=archive.with_name(f'paired-prefix-{END:06d}.json')
    write_json(out,dict(prior=initial,local_source_order_proof=local_ref,matched_marker=mark,
        matched_to_update=END,plan=match['plan'],arms=match['arms'],matched_segments=segments,
        observations_per_arm=local['total_observations'],queries_per_arm=local['total_queries'],
        distinct_eligible_photos=local['eligible_training_photos'],second_pass_distinct_visits=local['visits_second_epoch'],
        retained_training_seconds={k:prior['retained_training_seconds'][k]+seconds[k]for k in MODES},
        retained_since_first_epoch_seconds=seconds,archive=reference(archive),
        training_schedule_updates=50000,completed_scope='Intermediate paired training coverage.'))
    print(END,local['total_observations'],local['total_queries'],seconds,flush=True)


if __name__=='__main__':
    main()
