"""Wait for frozen matched receipts across changes of training controller."""
import argparse
import importlib
from pathlib import Path
import time

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT = Path(__file__).resolve().parent


def wait(step):
    marker = ROOT/f"matched-{step:06d}.json"
    last = None
    while not marker.is_file():
        file = ROOT/"owner.json"
        identity = read_json(file)if file.exists()else None
        state = (identity, bool(identity and owner_live(identity)))
        if state != last:
            print("waiting",step,*state,flush=True)
            last = state
        time.sleep(20)
    link = reference(marker)
    configuration = read_json(checked(link))
    assert configuration["plan"]==reference(ROOT/"plan.json")
    assert configuration["matched_input_traces"] and configuration["through_update"]==step
    assert configuration["training_complete"]==(step==50000)
    assert set(configuration["arms"])=={"none","spatial"}
    for part in configuration["arms"].values():
        receipt = read_json(checked(part["receipt"]))
        assert receipt["steps"]==step and receipt["checkpoints"][-1]==part["checkpoint"]
        checked(part["checkpoint"])
    print("ready",step,link,flush=True)
    return link,configuration


def run(action,step):
    proof,matched = wait(step)
    if action=="monitor":
        module = importlib.import_module("monitor_bound")
        module.wait_for_match = lambda requested: proof if requested==step else wait(requested)[0]
        module.run(step)
    elif action=="native":
        module = importlib.import_module("milestone_native_fixed")
        module.native(ROOT/f"review-native-{step:06d}",proof,matched)
    else:
        assert step==50000
        module = importlib.import_module("endpoint_checks_v2")
        target = ROOT/f"endpoint-{action.split('-')[-1]}"
        if action=="endpoint-canonical":
            module.canonical(target,proof,matched)
        else:
            module.native(target,proof,matched)


if __name__=="__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("monitor","native","endpoint-canonical","endpoint-native"))
    parser.add_argument("step",type=int)
    args = parser.parse_args()
    run(args.action,args.step)
