"""Check matched full-epoch snapshots on the fixed scene intervention panel."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from report_scene_wave_guides import native_board

ROOT = Path(__file__).resolve().parent
HISTORICAL = ROOT.parent / "scene-local-contrast-2400-v1"
sys.path.insert(0, str(HISTORICAL))
import evaluate_035000 as evaluate
import measure


def wait_for_match(step):
    controller = read_json(ROOT / "launch.json")["owner"]
    path = ROOT / f"matched-{step:06d}.json"
    while not path.exists():
        if not owner_live(controller):
            raise RuntimeError("Training controller exited before the requested matched checkpoint")
        time.sleep(20)
    return reference(path)


def run(step):
    snapshot = wait_for_match(step)
    matched = read_json(checked(snapshot))
    panel = reference(HISTORICAL / "evaluation-plan.json")
    spec = read_json(checked(panel))
    plan = read_json(checked(matched["plan"]))
    assert matched["matched_input_traces"]
    configs = {
        "V120": read_json(ROOT / "monitor-baselines.json")["V120"]
        | {"type": "base", "step": 20000},
        "100k": plan["parent"] | {"type": "base", "step": 100000},
    }
    for mode, record in matched["arms"].items():
        configs[mode] = record["checkpoint"] | {"type": "scene", "step": step, "mode": mode}
    stage = ROOT / f"review-full-{step:06d}"
    stage.mkdir()
    (stage / "observations").symlink_to(HISTORICAL / "observations", target_is_directory=True)
    evaluate.ROOT = stage
    assert step == 35_000
    pilot = False
    identity = stage / ("pilot" if pilot else "evaluation")
    identity.mkdir()
    indices = [row["index"] for row in spec["rows"]]
    if pilot:
        indices = indices[:8]
    binding = {
        "source": reference(evaluate.__file__),
        "metrics_driver": reference(measure.__file__),
        "monitor": reference(__file__),
        "panel": panel,
        "models": configs,
        "training_snapshot": snapshot,
        "selected_indices": indices,
        "precision": "CUDA IEEE FP32",
        "reuse_30000_collection": reference(ROOT / "review-full-030000/evaluation/collected.json"),
    }
    write_json(identity / "plan.json", binding)
    evaluate.evaluate(pilot)
    collection = reference(identity / "collected.json")
    records = read_json(checked(collection))["records"]
    assert len(records) == len(indices) * len(spec["profiles"]) * len(spec["draws"])
    output = identity / "native"
    output.mkdir()
    rows = []
    boards = []
    for pointer in records:
        record = read_json(checked(pointer))
        case = read_json(checked(record["case"]))
        with np.load(checked(case["input"]), allow_pickle=False) as stream:
            inputs = {name: stream[name] for name in (*measure.CFA_ARGS, "target")}
        names = record["inference_variants"]
        with np.load(checked(record["saved"]), allow_pickle=False) as stream:
            predictions = {name: stream[name.replace("/", "--")] for name in names}
        fields = {
            key: np.broadcast_to(inputs[key][None], (3, *inputs[key].shape))
            for key in ("wb", "matrix")
        }
        fields["exposure"] = case["profile"]["exposure"]
        scores = {
            name: measure.parts(fields, prediction, inputs["target"], spec)
            for name, prediction in predictions.items()
        }
        rows.append(
            {
                "source": case["source"],
                "profile": case["profile"]["name"],
                "draw": case["draw"],
                "prediction_receipt": pointer,
                "metrics": scores,
            }
        )
        if (
            case["case"] in indices[:2]
            and case["profile"]["name"] == "iso6400"
            and case["draw"] == "independent"
        ):
            for role in (0, 2):
                args = {
                    key: inputs[key][role : role + 1]
                    if key in ("packed", "variance")
                    else inputs[key][None]
                    for key in measure.CFA_ARGS
                }
                pieces = [
                    noisy_malvar(args)[0],
                    predictions["V120"][role],
                    predictions["100k"][role],
                    predictions["none"][role],
                    predictions["spatial/matching"][role],
                    predictions["spatial/wrong-distant"][role],
                    inputs["target"][role],
                ]
                boards.append(
                    native_board(
                        output,
                        f"{case['id']}-role{role}",
                        pieces,
                        args,
                        {
                            "case": record["case"],
                            "source": case["source"],
                            "prediction": pointer,
                            "models": configs,
                            "profile": case["profile"],
                            "query_box": case["box"],
                            "draw": case["draw"],
                            "role": role,
                        },
                        labels=(
                            "Noisy Malvar",
                            "V120",
                            "Corpus 100k",
                            "Local only",
                            "Spatial matched",
                            "Wrong distant view",
                            "Exact GT",
                        ),
                        triplet_indices=(0, 4, 6),
                        exposure=1 / fields["exposure"],
                        contrast=2,
                        roi=tuple(spec["native_display_ROI_xywh"]),
                    )
                )
    write_json(
        identity / "results.json",
        {
            "plan": reference(identity / "plan.json"),
            "collection": collection,
            "source_metrics": rows,
            "pooled": measure.reduce(rows),
            "native": boards,
            "actual_native_review_complete": False,
            "scope": "Repeated exact weak increments and flat-core RGB errors for matching versus altered distant view. Canonical panels and standing GFX are separate.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", type=int, choices=(35000,))
    run(parser.parse_args().step)
