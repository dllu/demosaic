"""Preserve the full64 exact-target review and viewed 20k crop comparisons."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
MONITOR = ROOT / "review-020000/evaluation"
RESULTS = Path("docs/results/scene-full-epoch-v1")
IMAGES = Path("docs/images/scene-full-epoch-v1/evaluation-020000")


def placement(binding):
    source = checked(binding["image"])
    dest = IMAGES / source.name
    shutil.copyfile(source, dest)
    assert reference(dest)["sha256"] == binding["image"]["sha256"]
    binding["image"] = {"path": str(dest), "sha256": binding["image"]["sha256"]}
    items = {}
    with Image.open(dest) as im:
        for pane in binding["panels"]:
            x, y, w, h = pane["png_xywh"]
            assert w == h == 160 and 0 <= x <= im.width - 160 and 0 <= y <= im.height - 160
            items[pane.get("label") or pane["name"]] = im.crop((x, y, x + w, y + h))
    return items


def main():
    recorded = reference(MONITOR / "results.json")
    scores = read_json(checked(recorded))
    plan_path = scores["plan"]
    plan = read_json(checked(plan_path))
    training = read_json(checked(plan["training_snapshot"]))
    assert training["through_update"] == 20000 and training["matched_input_traces"]
    for mode, row in training["arms"].items():
        assert {k: plan["models"][mode][k] for k in ("path", "sha256")} == row["checkpoint"]
        checked(row["checkpoint"])
    assert len(plan["selected_indices"]) == 64
    assert len(scores["source_metrics"]) == 256 and len(scores["native"]) == 4
    context = reference(MONITOR / "context-intervals.json")
    assert read_json(checked(context))["evaluated"] == recorded
    local = read_json(MONITOR / "local-triplets.json")
    assert local["results"] == recorded
    local = {row["id"]:row["triplet"]for row in local["rows"]}
    viewing = read_json(MONITOR / "viewing.json")
    assert set(viewing) == {r["id"]for r in scores["native"]}
    IMAGES.mkdir(exist_ok=True)
    for row in scores["native"]:
        row["actual_native_viewing"] = viewing[row["id"]]
        options = placement(row["board"])
        triplets = [row["triplet"]]
        if row["id"] in local:
            row["local_triplet"] = local[row["id"]]
            triplets.append(row["local_triplet"])
        for attached in triplets:
            for label, tile in placement(attached).items():
                assert ImageChops.difference(options[label],tile).getbbox() is None
    archive = RESULTS / "matched-020000-monitor.tar.xz"
    with tarfile.open(archive, "x:xz") as pack:
        for name in ("plan.json", "collected.json", "results.json", "context-intervals.json",
                     "local-triplets.json", "viewing.json"):
            pack.add(MONITOR/name, arcname=name)
        for name in ("queue-monitor-020000.log", "queue-review-020000-launch.json",
                     "monitor_full_020000.py", "summarize_020000.py", "local_triplets_020000.py"):
            pack.add(ROOT/name, arcname=name)
        pack.add(Path(__file__), arcname=Path(__file__).name)
        for pointer in (MONITOR/"predictions").glob("*.json"):
            pack.add(pointer, arcname=f"predictions/{pointer.name}")
    data = read_json(checked(context))
    write_json(RESULTS/"matched-020000-monitor.json",{
        "results": recorded, "checkpoint_binding":plan["training_snapshot"],
        "archive": reference(archive), "exact_target_numerical_complete": True,
        "actual_native_monitor_viewing_complete": True, "native":scores["native"],
        "panels":{k: data[k]for k in ("all_64","fixed_8_with_15k")},
        "scope":"64 held-out photos across both noise levels and both noise laws. Native figures and paired scores. Broad photo and camera panels belong to the final checkpoint."})


if __name__ == "__main__":
    main()
