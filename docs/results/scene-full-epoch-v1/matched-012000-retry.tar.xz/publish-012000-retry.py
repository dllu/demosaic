"""Bind the discarded spatial attempt and the verified restart."""
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path('docs/results/scene-full-epoch-v1')
segment = ROOT / 'spatial-012000/segments/through-012000'
older = segment / 'attempt-01'
kept = segment / 'attempt-02'
failed_log = reference(older / 'worker.log')
failed_exit = reference(older / 'exit.json')
prior = reference(ROOT / 'spatial-012000/segments/through-011500/attempt-01/work/completed.json')
completed = reference(kept / 'work/completed.json')
matched = reference(ROOT / 'matched-012000.json')
assert 'RuntimeError: Training RAM reserve unavailable' in checked(failed_log).read_text()
assert read_json(checked(failed_exit))['returncode'] == 1
assert read_json(checked(prior))['steps'] == 11500
resumed = read_json(checked(completed))
assert resumed['start_step_exclusive'] == 11500 and resumed['steps'] == 12000
assert read_json(checked(matched))['matched_input_traces']
resumed_launch = reference(kept / 'launch.json')
assert prior['path'] in read_json(checked(resumed_launch))['command']
archive = OUT / 'matched-012000-retry.tar.xz'
with tarfile.open(archive, 'x:xz') as stream:
    for prefix, root, names in (
        ('discarded', older, ('launch.json', 'worker.log', 'exit.json', 'work/progress.json', 'work/train.jsonl', 'work/observations.jsonl')),
        ('completed', kept, ('launch.json', 'worker.log', 'work/completed.json')),
    ):
        for name in names:
            stream.add(root / name, arcname=f'{prefix}/{name}')
    stream.add(checked(prior), arcname='verified-previous.json')
    stream.add(Path(__file__), arcname=Path(__file__).name)
write_json(OUT / 'matched-012000-retry.json', {
    'archive': reference(archive), 'failed_log': failed_log, 'failed_exit': failed_exit,
    'verified_restart_input': prior, 'completed_launch': resumed_launch,
    'completed_segment': completed, 'matched': matched,
    'outcome': 'Controller stopped at the declared runtime RAM reserve and resumed from 11500 with the unchanged plan. The retained trace matches local-only through update 12000.'
})
