"""Run the full matched 25k photo and standing GFX evaluations."""
from pathlib import Path
import subprocess
import sys

import psutil

from demosaic.experiments.artifacts import reference, write_json
from review_queue_native_fixed import wait

ROOT=Path(__file__).resolve().parent
STEP=25000


def main():
    print("Waiting for the verified 25k pair",flush=True)
    if len(sys.argv)==1:
        exits={}
        for action in ("photo","native"):
            command=[sys.executable,"-u",str(Path(__file__)),action]
            logpath=ROOT/f"queue-full-{action}-{STEP:06d}.log"
            with logpath.open("xb") as log:
                child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                write_json(ROOT/f"queue-full-{action}-{STEP:06d}-launch.json",{
                    "command":command,"owner":{"pid":child.pid,"created":psutil.Process(child.pid).create_time()},
                    "driver":reference(__file__),
                })
                code=child.wait()
            exits[action]=code
        write_json(ROOT/f"queue-full-{STEP:06d}-exit.json",{"exit_codes":exits})
        raise SystemExit(int(any(exits.values())))
    binding,decision=wait(STEP)
    if sys.argv[1]=="photo":
        import monitor_full_025000 as monitor
        # The wrapper verifies the live controller and the final pair.
        monitor.wait_for_match=lambda step: binding if step==STEP else wait(step)[0]
        monitor.run(STEP)
    else:
        from milestone_native_fixed import native
        native(ROOT/f"review-native-{STEP:06d}",binding,decision)


if __name__=="__main__":
    main()
