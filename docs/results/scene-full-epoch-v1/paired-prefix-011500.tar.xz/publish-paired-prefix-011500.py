"""Verify identical source and tensor input traces through 11,500 updates."""
import json
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
DOC=Path("docs/results/scene-full-epoch-v1")


def main():
    earlier=reference(DOC/"paired-prefix-010500.json")
    prev=read_json(checked(earlier))
    base=read_json(checked(prev["previous_matched"]))
    prefix=[r["observations"]for r in base["arms"]["none"]["phases"]]+[prev["arms"]["none"]["observations"]]
    assert prev["through_update"]==10500
    run=prev["training_plan"]
    recipe=read_json(checked(run))
    with checked(recipe["train_manifest"]).open()as f:
        legal={json.loads(k)["id"]for k in f}
    checkpoint={k:r["checkpoint"]for k,r in prev["arms"].items()}
    summary={}
    archive=[]
    for step in (11000,11500):
        new={}
        for arm in ("none","spatial"):
            original=reference(ROOT/f"{arm}-012000/segments/through-{step:06d}/verified.json")
            trace=read_json(checked(original))
            receipt=read_json(checked(trace["receipt"]))
            assert receipt["plan"]==run and receipt["DINO_unchanged"]
            assert (receipt["schedule_steps"],receipt["start_step_exclusive"],receipt["steps"])==(50000,step-500,step)
            assert receipt["resume"]==checkpoint[arm] and receipt["checkpoints"][-1]==trace["checkpoint"]
            checkpoint[arm]=trace["checkpoint"]
            checked(checkpoint[arm])
            new[arm]=trace|{"verified":original}
            archive.extend(((original,f"{arm}/{step:06d}/verified.json"),(trace["receipt"],f"{arm}/{step:06d}/completed.json")))
        assert new["none"]["observations"]["sha256"]==new["spatial"]["observations"]["sha256"]
        prefix.append(new["none"]["observations"])
        summary[str(step)]=new
    source=set()
    seeds=set()
    native=0
    for file in prefix:
        with checked(file).open()as f:
            for line in map(json.loads,f):
                key,seed=line["source_id"],line["recipe"]["noise_seed"]
                assert line["index"]==len(source) and key in legal and key not in source and seed not in seeds
                source.add(key)
                seeds.add(seed)
                native+=len(line["boxes_xywh"])
    assert len(source)==len(seeds)==23000 and native==92000
    owner=reference(ROOT/"owner.json")
    assert owner_live(read_json(checked(owner)))
    source=DOC/"paired-prefix-011500.tar.xz"
    with tarfile.open(source,"x:xz")as pack:
        for term,name in archive:
            pack.add(checked(term),arcname=name)
        pack.add(Path(__file__),arcname=Path(__file__).name)
    write_json(DOC/"paired-prefix-011500.json",{"last_paired":earlier,"plan":run,"verified_match_through_update":11500,
                "photos_per_arm":len(seeds),"native_queries_per_arm":native,"noise_seeds_per_arm":len(seeds),
                "quality_complete_through":10000,"controller":owner,"segments":summary,"archive":reference(source)})
    print(len(seeds),native,checkpoint["spatial"]["sha256"],flush=True)


if __name__=="__main__":
    main()
