"""Cross-fit pooled signed Bayer evidence after fixed exterior geometry."""

from dataclasses import dataclass

import numpy as np

from demosaic.isolated_line import coordinates, gaussian_profile, native_sites


@dataclass
class Line:
    normal: tuple[float, float]
    offset: float
    color: tuple[float, float, float]


def smoothstep(value):
    x = np.clip(value, 0, 1)
    return x * x * (3 - 2 * x)


def candidate_envelopes(t, method):
    if method == "full":
        return np.ones((t.size, 1)), ["continuous"]
    yield_gaps = [(c, h) for c in (-64, -32, 0, 32, 64) for h in (12, 24, 36)]
    return (
        np.column_stack([np.ones(t.size),
                         *[smoothstep((np.abs(t - c) - h) / 8) for c, h in yield_gaps]]),
        ["continuous", *[f"gap-{c}-{h}" for c, h in yield_gaps]],
    )


def background(d, t, c, edge):
    # Four independent affine backgrounds along the line. The pooled
    # amplitude is shared across them.
    cells = np.digitize(t, [-64, 0, 64])
    index = 3 * cells + c
    bases = np.eye(12)[index]
    delta = (t - np.take([-96, -32, 32, 96], cells)) / 64
    cols = [bases, bases * (d / 9)[:, None], bases * delta[:, None]]
    if edge:
        # The signed line candidate and this color-wise step compete in the
        # same fit. Step position and three allowed smooth scales are fixed.
        one = np.eye(3)[c]
        cols.extend(one * np.tanh((d - shift) / 1.7)[:, None] for shift in (-3, 0, 3))
    return np.concatenate(cols, axis=1)


def subset_fit(x, u, y, weights):
    """Fit the null and residualize candidate columns using only given rows."""
    keep = np.count_nonzero(x, axis=0) > 0
    design = x[:, keep]
    def solve(columns, w):
        root = np.sqrt(w)
        return np.linalg.lstsq(root[:, None] * design, root[:, None] * columns, rcond=1e-7)[0]
    beta = solve(y[:, None], weights)[:, 0]
    for _ in range(2):
        residual = y - design @ beta
        robust = weights * np.minimum(1, 3 / np.maximum(1e-9, np.abs(residual) * np.sqrt(weights)))
        beta = solve(y[:, None], robust)[:, 0]
    gamma = solve(u, robust)
    residualized = u - design @ gamma
    info = (robust[:, None] * residualized**2).sum(0)
    score = residualized.T @ (robust * (y - design @ beta))
    return keep, beta, gamma, score, info, robust, residualized


def noise_weights(raw, colors, shot, read):
    # Estimate the variance scale from this side's values only. This controls
    # the other side's scoring weights too when testing this side's prediction.
    centres = np.array([np.median(raw[colors == i]) for i in range(3)])
    return 1 / (np.maximum(centres, 1e-4) * shot + max(read, 1e-10))


def crosscheck(x, u, y, colors, fold, noise, penalty, level):
    all_rows = []
    for a in (0, 1):
        train = fold == a
        test = ~train
        w = noise_weights(y[train], colors[train], *noise)[colors]
        keep, beta, gamma, score, info, *_ = subset_fit(x[train], u[train], y[train], w[train])
        z = score / np.sqrt(np.maximum(info, 1e-20))
        # The no-gap shape carries no search penalty. All gap options are
        # specified before seeing either subset.
        k = int(np.argmax(np.maximum(z, 0)**2 - penalty))
        amplitude = max(0.0, score[k] / max(info[k], 1e-20))
        xb = x[test][:, keep]
        wb = w[test]
        increment = u[test, k] - xb @ gamma[:, k]
        residual = y[test] - xb @ beta
        statistic = (wb * increment) @ residual
        precision = (wb * increment) @ increment
        test_z = statistic / np.sqrt(max(precision, 1e-20))
        risk_gain = 2 * amplitude * statistic - amplitude**2 * precision
        passed = bool(z[k] > level and test_z > level and risk_gain > 0)
        all_rows.append({
            "choice":k, "fitted_amplitude":float(amplitude), "training_Z":float(z[k]),
            "withheld_Z":float(test_z), "withheld_loss_reduction":float(risk_gain), "passed":passed,
        })
    return all_rows


def line_arrays(parent, packed, variance, colors, origin, guide, edge):
    xn, yn = native_sites(packed.shape[-2:], origin)
    width, height = parent.shape[-1], parent.shape[-2]
    xx, yy = coordinates(height, width, origin=origin)
    a, b = guide.normal
    cx, cy = origin[0] + (width - 1) / 2, origin[1] + (height - 1) / 2
    c = np.broadcast_to(np.asarray(colors)[:, None, None], packed.shape)
    d = a * xn + b * yn - guide.offset
    t = -b * (xn - cx) + a * (yn - cy)
    d_rgb = a * xx + b * yy - guide.offset
    t_rgb = -b * (xx - cx) + a * (yy - cy)
    fold = ((xn // 2 + yn // 2) % 2).astype(np.int8)
    # Geometry alone defines both fitting sets. Signed saturation stays
    # bounded by the acquisition model used to generate this panel.
    valid = np.abs(d) < 9
    c = c[valid]
    seen = (c, (yn[valid] - origin[1]).astype(int), (xn[valid] - origin[0]).astype(int))
    tint = np.asarray(guide.color)
    model = gaussian_profile(d[valid], 1.12) * tint[c]
    template = gaussian_profile(d_rgb, 1.12)[None] * tint[:, None, None]
    return (background(d[valid], t[valid], c, edge), model, t[valid], c, fold[valid],
            seen, packed[valid].astype(float), variance[valid].astype(float), template, t_rgb)


def restore(parent, packed, variance, colors, origin, guide, noise, *, method, exact=None, level=2.25):
    edge = method == "gap-edge"
    x, main, t, c, fold, sites, raw, v, rgb, t_rgb = line_arrays(
        parent, packed, variance, colors, origin, guide, edge
    )
    if min(np.count_nonzero(fold == a) for a in (0, 1)) < 100:
        return parent, {"folds": [], "accepted": False}
    if exact is None:
        basis, names = candidate_envelopes(t, "full" if method == "full" else "gap")
        profiles, _ = candidate_envelopes(t_rgb.ravel(), "full" if method == "full" else "gap")
        bank = main[:, None] * basis
    else:
        bank = exact[sites].astype(float)[:, None]
        names = ["target-informed-support"]
    if method == "oracle-open":
        witnesses = []
        combined = bank[:, 0]
        support = exact
        blend = 1.0
    else:
        witnesses = crosscheck(x, bank, raw, c, fold, noise, np.r_[0, np.full(len(names)-1, 3)], level)
        status = (all(r["passed"] for r in witnesses))
        if not status:
            return parent, {"folds": witnesses, "accepted": False, "choices": [names[r["choice"]] for r in witnesses]}
        if exact is None:
            a, b = (r["choice"] for r in witnesses)
            combined = main * np.minimum(basis[:, a], basis[:, b])
            field = np.minimum(profiles[:, a], profiles[:, b]).reshape(t_rgb.shape)
            support = rgb * field[None]
        else:
            combined = bank[:, 0]
            support = exact
        minimum = min(min(r["training_Z"], r["withheld_Z"]) for r in witnesses)
        blend = np.clip((minimum - level) / 1.4, 0, 1)
    # The parent is read here after delivery support has been fixed.
    weights = 1 / np.maximum(v, 1e-10)
    _, _, _, score, info, robust, field = subset_fit(x, combined[:, None], raw, weights)
    fit_amplitude = max(0, float(score[0] / max(info[0], 1e-20)))
    parent_amplitude = float((field[:, 0] * robust) @ parent[sites] / max(info[0], 1e-20))
    corrected = parent + blend * (fit_amplitude - parent_amplitude) * support
    return corrected.astype(parent.dtype), {
        "folds": witnesses, "accepted": True, "choices": [names[r["choice"]] for r in witnesses],
        "blend":float(blend), "physical_amplitude":fit_amplitude, "parent_amplitude":parent_amplitude,
    }
