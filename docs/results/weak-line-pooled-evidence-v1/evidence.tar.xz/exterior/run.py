"""Fresh paired tests of known line geometry and cross-fit support selection."""

import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import Guide
from demosaic.noise import variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from pool import Line, restore

ROOT = Path(__file__).resolve().parent
OLDER = ROOT.parent / "multiline-raw-shoulders-v1"
sys.path.append(str(OLDER))
from proposals import compose, external_proposals
from shoulders import estimate

import importlib.util
spec = importlib.util.spec_from_file_location("paired_multi_cfg", OLDER / "run.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
probe, sample, metrics, LAYOUTS = module.probe, module.sample, module.metrics, module.LAYOUTS
GEOMETRY = range(64, 70)
TINT = np.asarray([[-.45, 1., -.32], [.75, .58, -.31], [-.18, 1., .35]])
SOURCE = ROOT.parent / "weak-line-pooled-evidence-v1"
POLICY = {
    "wide-exterior": ("full", "exterior"),
    "gap-exterior": ("gap", "exterior"),
}


def known_guides(ideal, shifted=False):
    centre = (probe.SIDE - 1) / 2
    result = []
    for (angle, offset), color, shift in zip(ideal, TINT, (11.5, -11.5, -16), strict=True):
        vector = (-np.sin(angle), np.cos(angle))
        distance = offset + centre * sum(vector) + (shift if shifted else 0)
        result.append(Guide(vector, float(distance), tuple(color / np.linalg.norm(color)), 0., 0))
    return result


def apply_policy(base, packed, variance, colors, parent_origin, guides, prior, method, templates=None):
    if method == "previous":
        return compose(base, packed, variance, colors, parent_origin, guides)
    noise = prior["shot"], prior["read"]
    result = base.copy()
    rows = []
    for index, guide in enumerate(guides):
        exact = None if templates is None else templates[index]
        p, record = restore(base, packed, variance, colors, parent_origin, guide, noise,
                            method=method, exact=exact)
        result += p - base
        rows.append(record)
    return result, rows


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [6, 7])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    checkpoint = read_json(OLDER / "plan.json")["checkpoint"]
    prior_result = read_json(SOURCE / "result.json")
    old_cases = {Path(b["path"]).stem: b for b in prior_result["records"]}
    sources = {k:reference(v) for k,v in {
        "runner":__file__, "pool":ROOT / "pool.py", "paired_source":OLDER/"run.py",
        "proposal":OLDER/"proposals.py", "shoulder_check":OLDER/"shoulders.py",
        "original":SOURCE / "result.json", "previous_local":Path.cwd()/"src/demosaic/isolated_line.py",
    }.items()}
    write_json(ROOT/"plan.json", {
        "sources":sources, "checkpoint":checkpoint, "profiles":probe.PRIORS, "geometries":list(GEOMETRY),
        "layouts":LAYOUTS, "policies":POLICY, "query_box":probe.BOX, "ROI":probe.ROI,
        "seed_base":177220460903, "repeats":[0,1], "heldout_min_score":2.25, "gap_search_penalty":3,
        "scope":"Paired ablation on the frozen initial panel. Only noisy exterior guide geometry enters the wide and gap fits. Recreate and verify the old parent metrics, Bayer tensors and guide records on all cases.",
    })
    model, payload = load_scene_checkpoint(checked(checkpoint), device="cuda", weights="ema",
                                           expected_sha256=checkpoint["sha256"])
    assert model.mode == "spatial" and payload["step"] == 2000
    model.mode = "none"
    del payload
    cases = ROOT/"cases"
    cases.mkdir()
    output = []
    started = time.monotonic()
    with ieee_fp32():
        for n, (name, prior) in enumerate(probe.PRIORS.items()):
            model.base.set_noise(prior["shot"], prior["read"])
            for li, layout in enumerate(LAYOUTS):
                for g in GEOMETRY:
                    for repeat in (0,1):
                        seed = 177220460903 + 53000*n + 4000*li + 81*g + 9*repeat
                        key = f"{name}-{layout}-g{g}-r{repeat}"
                        local, context, masks, ideal, physics = sample(g, layout, prior, seed)
                        p = model(*(local[k].cuda() for k in ("packed", "variance", "colors", "wb", "matrix"))).cpu().numpy()
                        old = read_json(checked(old_cases[key]))
                        assert old["calibration"] == {k:fingerprint(t) for k,t in local.items()}
                        raw, v, c = (local[k].numpy() for k in ("packed","variance","colors"))
                        measurements = {"parent": metrics(local,masks,p,p)}
                        assert old["measurements"]["parent"] == measurements["parent"]
                        truth_templates = masks["detail"] / np.abs(masks["detail"]).max(axis=(1,2,3),keepdims=True)
                        scene = context["matched"]
                        scene_var = variance_map(torch.from_numpy(scene),prior["shot"], prior["read"]).numpy()
                        exact = known_guides(ideal)
                        exterior = external_proposals(scene,scene_var,c[0],probe.BOX,color_estimator=estimate)
                        guides = {"known":exact,"exterior":exterior,"shifted":known_guides(ideal,shifted=True),"shape":exact[:2]}
                        import json
                        assert json.loads(json.dumps([asdict(v) for v in exterior])) == old["guides"]["exterior"]
                        predictions = {"parent":p}
                        for arm,(policy,geometry) in POLICY.items():
                            result, fits = [], []
                            for i in (0,1):
                                y, record = apply_policy(p[i],raw[i],v[i],c[i],probe.BOX[:2],guides[geometry],prior,
                                    policy,truth_templates if geometry=="shape" else None)
                                result.append(y)
                                fits.append(record)
                            predictions[arm] = np.stack(result)
                            measurements[arm] = metrics(local,masks,p,predictions[arm])|{"fits":fits}
                        retained = None
                        if g in (64,67) and repeat==0:
                            arr = cases/(key+".npz")
                            np.savez_compressed(arr,**{k:t.numpy() for k,t in local.items()},**{f"pred_{k}": v for k,v in predictions.items()},**masks)
                            retained = reference(arr)
                        row = cases/(key+".json")
                        write_json(row, {
                            "id":key,"profile":name,"layout":layout,"geometry":g,"repeat":repeat,"seed":seed,
                            "measurements":measurements,"guides":{k:[asdict(e) for e in a] for k,a in guides.items()},
                            "guide_distances":module.comparisons(ideal,exterior),"retained":retained,"sensor":physics,
                            "calibration":{k:fingerprint(t) for k,t in local.items()},
                        })
                        output.append(reference(row))
                        print(key, len(exterior), [np.round(measurements[a]["response"],3).tolist()
                              for a in tuple(POLICY)],
                              round(time.monotonic()-started,2), flush=True)
    assert len(output)==72
    write_json(ROOT/"result.json", {"plan":reference(ROOT/"plan.json"),"records":output,
                                   "seconds":time.monotonic()-started})


if __name__=="__main__":
    run()
