"""Fresh exact paired controls for multi-line exterior Bayer proposals."""

import math
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import external_guide
from demosaic.noise import add_noise, variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from proposals import compose, external_proposals
from shoulders import estimate

ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT.parent / "scene-wire-gap-v1"))
import probe

LAYOUTS = ("parallel", "crossing", "edge-aligned")
GEOMETRIES = range(51, 59)


def target(geometry, layout):
    axis = torch.arange(probe.SIDE, dtype=torch.float32) - (probe.SIDE - 1) / 2
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    angle = (geometry * 19 + 24) * math.pi / 180
    advance = {"parallel": 0, "crossing": 55, "edge-aligned": 31}[layout]
    angles = [angle, angle + math.radians(advance), angle + math.radians(107)]
    main_offset = (geometry % 4 - 1.5) * 7
    offsets = [main_offset, main_offset + 17 if layout == "parallel" else -17, 38.5]
    d = [-math.sin(a) * x + math.cos(a) * y - k for a, k in zip(angles, offsets, strict=True)]
    t = [math.cos(a) * x + math.sin(a) * y for a in angles]
    radius = torch.maximum(x.abs(), y.abs())
    inside = probe.smoothstep((123 - radius) / 24)
    outside = probe.smoothstep((radius - 165) / 32) * probe.smoothstep((364 - radius) / 16)
    tint = torch.tensor([[-.45, 1., -.32], [.75, .58, -.31], [-.18, 1., .35]])[:, :, None, None]
    base = torch.tensor([.26, .29, .32])[:, None, None] + 0.014 * y / 768 + .009 * x / 768
    base = base + tint[0] * (0.035 * inside * probe.ribbon(t[0] - 8.1, 1.55))
    if layout == "edge-aligned":
        step = 0.5 + 0.5 * torch.erf((d[2] - 1.25) / 1.7)
        base = base + tint[2] * (.030 * inside * step)
    gap_center = (-19, 3, 21)[geometry % 3]
    half_gap = (13, 19, 27)[geometry % 3]
    full = torch.stack([tint[i] * ((.0055, .0048)[i] * inside * probe.ribbon(d[i], 1.12))
                        for i in (0, 1)])
    gap = (t[1] - gap_center).abs() <= half_gap
    detail = torch.stack([full[0], full[1] * probe.smoothstep(
        ((t[1] - gap_center).abs() - half_gap) / 8
    )])
    extent = torch.stack([tint[i] * ((.12, .10, .11)[i] * outside * probe.ribbon(d[i], 2.8))
                          for i in (0, 1, 2)]).sum(0)
    moved = torch.stack([tint[i] * ((.12, .10, .11)[i] * outside * probe.ribbon(d[i] - shift, 2.8))
                         for i, shift in enumerate((11.5, -11.5, -16))]).sum(0)
    isolated = [(d[1].abs() > 7) & (d[2].abs() > 8), (d[0].abs() > 7) & (d[2].abs() > 8)]
    clean = (t[0] - 8.1).abs() > 8
    ideal = [(a, k) for a, k in zip(angles, offsets, strict=True)]
    return base, base + detail.sum(0), extent, moved, full, detail, gap, isolated, clean, d[2], ideal


def sample(geometry, layout, profile, seed):
    a, b, extent, moved, full, detail, gap, isolated, clean, d3, ideal = target(geometry, layout)
    arrays, feedback = paired_observation(
        a[None], b[None], profile, [tuple(probe.PATTERNS)[geometry % 4]],
        torch.ones(1, 3), torch.eye(3)[None], seed,
    )
    local = {k: torch.from_numpy(arrays[k]) for k in ("packed", "variance", "target", "colors", "wb", "matrix")}
    for k in ("packed", "variance", "target"):
        local[k] = probe.query(local[k], packed=k != "target")
    contexts = {}
    for key, image in (("matched", a + extent), ("shifted", a + moved), ("flat", a)):
        raw = mosaic(image[None], local["colors"][0])
        contexts[key] = add_noise(raw, profile["shot"], profile["read"], black_level=.03,
                                  generator=torch.Generator().manual_seed(seed + 23))[0].numpy()
    masks = {"full": full, "detail": detail, "gap": gap, "isolated": torch.stack(isolated),
             "clean": clean, "third": d3.abs() <= 5}
    return local, contexts, {k: probe.query(x, packed=False).numpy() for k, x in masks.items()}, ideal, feedback


def metrics(local, masks, parent, prediction):
    x, y, w, h = probe.ROI
    roi = np.s_[..., y:y+h, x:x+w]
    truth = local["target"].numpy().astype(float)[roi]
    p = prediction.astype(float)[roi]
    already = parent.astype(float)[roi]
    correction = p - already
    increment = p[1] - p[0]
    masks = {k: v[roi] for k, v in masks.items()}

    def rms(value):
        return float(65535 * np.sqrt(np.mean(value**2)))

    detail = masks["detail"]
    clean = masks["clean"]
    real = (np.abs(detail).max(axis=1) > 1e-7) & masks["isolated"] & clean
    result = {
        "visible_pixels": [int(p.sum()) for p in real],
        "response": [float((increment[:, s] * d[:, s]).sum() / (d[:, s]**2).sum())
                     for s, d in zip(real, detail, strict=True)],
        "increment_error_DN16": [rms(increment[:, s] - d[:, s])
                                  for s, d in zip(real, detail, strict=True)],
        "absent_RMS_DN16": rms((p[0] - truth[0])[:, clean]),
        "absent_added_RMS_DN16": rms(correction[0][:, clean]),
        "changed": [bool((q != 0).any()) for q in correction],
    }
    missing = (np.abs(masks["full"][1]).max(0) > 1e-7) & masks["gap"] & clean & masks["isolated"][1]
    third = clean & masks["third"] & (np.abs(masks["full"]).max(axis=(0, 1)) < 1e-7)
    result["true_gap_added_RMS_DN16"] = rms(correction[1][:, missing])
    result["true_gap_error_RMS_DN16"] = rms((p[1] - truth[1])[:, missing])
    result["third_guide_added_RMS_DN16"] = rms(correction[0][:, third])
    return result


def comparisons(ideal, guides):
    center = (probe.SIDE - 1) / 2
    distances = []
    for angle, offset in ideal:
        normal = np.array([-math.sin(angle), math.cos(angle)])
        by_guide = []
        for guide in guides:
            align = np.dot(normal, guide.normal)
            native = guide.offset - center * sum(guide.normal)
            by_guide.append([math.degrees(math.acos(min(1, abs(align)))),
                             abs(offset - np.sign(align) * native)])
        distances.append(by_guide)
    return distances


@torch.inference_mode()
def main():
    os.sched_setaffinity(0, [12, 13])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    binding = read_json(ROOT.parent / "scene-wire-gap-v1/plan.json")["checkpoint"]
    plan = {
        "runner": reference(__file__), "detector": reference(ROOT / "proposals.py"),
        "geometry_source": reference(Path(probe.__file__)),
        "local_correction": reference("src/demosaic/isolated_line.py"),
        "shoulder_estimator": reference(ROOT / "shoulders.py"),
        "checkpoint": binding, "profile": probe.PRIORS, "layouts": LAYOUTS,
        "geometries": list(GEOMETRIES), "repeat": [0], "ROI_xywh": probe.ROI,
        "query": probe.BOX, "black_level": .03, "baseline": "scene context disabled",
        "scope": "Fresh synthetic exact-reference paired weak lines. An exterior-only bank uses both sides of a 32px moat. Search shifted and flat surrounds on identical query Bayer and variance.",
    }
    write_json(ROOT / "plan.json", plan)
    model, payload = load_scene_checkpoint(
        checked(binding), device="cuda", weights="ema", expected_sha256=binding["sha256"]
    )
    assert model.mode == "spatial" and payload["step"] == 2000
    del payload
    model.mode = "none"
    cases = ROOT / "cases"
    cases.mkdir(exist_ok=True)
    receipts = []
    began = time.monotonic()
    with ieee_fp32():
        for noise_index, (noise, profile) in enumerate(probe.PRIORS.items()):
            model.base.set_noise(profile["shot"], profile["read"])
            for i, layout in enumerate(LAYOUTS):
                for geometry in GEOMETRIES:
                    for r in (0,):
                        key = f"{noise}-{layout}-g{geometry}-r{r}"
                        seed = 176589801700 + 53000 * noise_index + 5000 * i + 81 * geometry + 9 * r
                        local, outer, masks, ideal, physics = sample(geometry, layout, profile, seed)
                        parent = model(*(local[k].cuda() for k in ("packed","variance","colors","wb","matrix"))).cpu().numpy()
                        result = {"parent": metrics(local, masks, parent, parent)}
                        predictions = {"parent": parent}
                        color = local["colors"][0].numpy()
                        for mode, source in (("matched", "matched"), ("shifted", "shifted"),
                                             ("flat", "flat"), ("shoulders", "matched"),
                                             ("shoulders-shifted", "shifted"),
                                             ("shoulders-flat", "flat")):
                            scene = outer[source]
                            var = variance_map(torch.from_numpy(scene), profile["shot"], profile["read"]).numpy()
                            kwargs = {"color_estimator": estimate} if mode.startswith("shoulders") else {}
                            guides = external_proposals(scene, var, color, probe.BOX, **kwargs)
                            if mode == "matched":
                                prior = external_guide(scene, var, color, probe.BOX)
                                isolated = np.stack([compose(parent[j], local["packed"][j].numpy(),
                                    local["variance"][j].numpy(), color, probe.BOX[:2], [prior] if prior else [])[0]
                                    for j in (0, 1)])
                                result["isolated"] = metrics(local, masks, parent, isolated) | {
                                    "guides": [asdict(prior)] if prior else [],
                                }
                            scored, evidence = [], []
                            for j in (0, 1):
                                p, fits = compose(parent[j], local["packed"][j].numpy(), local["variance"][j].numpy(), color,
                                                  probe.BOX[:2], guides)
                                scored.append(p)
                                evidence.append(fits)
                            prediction = np.stack(scored)
                            result[mode] = metrics(local, masks, parent, prediction) | {
                                "guides": [asdict(g) for g in guides], "geometry_error_angle_and_offset_px": comparisons(ideal, guides),
                                "evidence": evidence,
                            }
                            if mode == "matched":
                                predictions["multiple"] = prediction
                            elif mode == "shoulders":
                                predictions["shoulders"] = prediction
                        retained = None
                        if geometry in (51, 55) and r == 0:
                            dst = cases / (key + ".npz")
                            np.savez_compressed(dst, **{k: t.numpy() for k,t in local.items()}, **predictions, **masks)
                            retained = reference(dst)
                        record = cases / (key + ".json")
                        write_json(record, {
                            "id": key, "profile": noise, "layout": layout, "geometry": geometry, "repeat":r,
                            "seed":seed, "noise_physics": physics, "retained": retained, "measurements": result,
                            "fingerprints":{k: fingerprint(t) for k,t in local.items()},
                        })
                        receipts.append(reference(record))
                        print(key, len(result["matched"]["guides"]), len(result["shifted"]["guides"]),
                              len(result["shoulders"]["guides"]), result["shoulders"]["response"], round(time.monotonic()-began, 2), flush=True)
    assert len(receipts) == 48
    write_json(ROOT / "result.json", {"plan":reference(ROOT/"plan.json"),"records":receipts, "seconds":time.monotonic()-began})


if __name__ == "__main__":
    main()
