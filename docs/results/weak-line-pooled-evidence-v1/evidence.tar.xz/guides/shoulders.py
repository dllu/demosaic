"""Require like-signed exterior ridge prominence against both RAW shoulders."""

import numpy as np

from demosaic.isolated_line import fit, gaussian_profile


def estimate(scene, variance, colors, exterior, x, y, normal, offset):
    d = normal[0] * x + normal[1] * y - offset
    t = -normal[1] * x + normal[0] * y
    plane = np.asarray(colors)[:, None, None]
    ridge = gaussian_profile(d, 2.8)
    rows, errors = [], []
    for end in (-1, 1):
        for shoulder in (-1, 1):
            support = exterior[None] & (end * t > 80) & (shoulder * d > -1.5) & (shoulder * d < 11)
            values, std = [], []
            for c in range(3):
                keep = (plane == c) & support
                if keep.sum() < 36:
                    return None
                design = np.column_stack((np.ones(keep.sum()), d[keep] / 11, t[keep] / 256, ridge[keep]))
                a, e = fit(design, scene[keep], variance[keep])
                values.append(a[-1])
                std.append(e[-1])
            rows.append(values)
            errors.append(std)
    values, errors = np.asarray(rows), np.asarray(errors)
    joined = np.sum(values / errors**2, axis=0) / np.sum(1 / errors**2, axis=0)
    norm = np.linalg.norm(joined)
    if not norm or np.any(values @ joined <= 0):
        return None
    color = joined / norm
    strength = min((values / errors) @ color)
    if strength < 6:
        return None
    return color, strength, int(np.count_nonzero(exterior[None] & (np.abs(d) < 3)))
