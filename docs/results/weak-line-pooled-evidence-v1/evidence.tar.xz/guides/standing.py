"""Replay the two-sided guide bank on the fixed protected native views."""

import importlib.util
import os
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from proposals import compose, external_proposals
from shoulders import estimate

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "disjoint-line-recovery-v1/standing.py"
sys.path.append(str(OLD.parent))
spec = importlib.util.spec_from_file_location("line_standing_source", OLD)
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)
PREVIOUS, SAVED = renderer.PREVIOUS, renderer.SAVED
insert_camera_panels, pixel, window = renderer.insert_camera_panels, renderer.pixel, renderer.window


@torch.inference_mode()
def main():
    os.sched_setaffinity(0, [12, 13])
    os.nice(12)
    torch.set_num_threads(2)
    original = read_json(SAVED)
    plan_path = checked(original["plan"])
    plan = read_json(plan_path)
    base_path = PREVIOUS / "none/collection.json"
    base = read_json(base_path)
    assert base["plan"] == original["plan"]
    snapshots = {row["id"]: row for row in base["records"]}
    kind = {row["id"]: row for row in plan["observations"]}
    output = ROOT / "standing"
    output.mkdir(exist_ok=True)
    rows = []
    for row in original["boards"]:
        key = row["observation"]
        obs = kind[key]
        if obs["kind"] not in ("gfx", "mesh"):
            continue
        found = snapshots[key]
        with np.load(checked(obs["arrays"]), allow_pickle=False) as content:
            arrays = {k: content[k] for k in ("packed", "colors", "wb", "matrix", "variance")}
        assert {k: fingerprint(v) for k, v in arrays.items()} == found["input_fingerprints"]
        predicted = np.load(checked(found["prediction"]), allow_pickle=False)[0]
        x, y, w, h = row["case"]["ROI_xywh"]
        box = ((x - 48) // 2 * 2, (y - 48) // 2 * 2, 256, 256)
        assert 0 <= box[0] <= predicted.shape[-1] - 256
        assert 0 <= box[1] <= predicted.shape[-2] - 256
        p = window(predicted, box)
        roi = (x - box[0], y - box[1], w, h)
        color = arrays["colors"][0]
        scene, variance = arrays["packed"][0], arrays["variance"][0]
        guides = external_proposals(scene, variance, color, box, color_estimator=estimate)
        prediction, fits = compose(p, window(scene, box, phase=2), window(variance, box, phase=2),
                                   color, box[:2], guides)
        correction = window(prediction.astype(float) - p, roi) * 65535
        new = pixel(prediction, arrays, roi, row["display_exposure"])
        control = pixel(p, arrays, roi, row["display_exposure"])
        panel = next(c for c in row["panels"] if c["label"] == "Local-only2k")
        px, py, _, _ = panel["png_xywh"]
        with Image.open(checked(row["image"])) as old:
            np.testing.assert_array_equal(np.asarray(old.crop((px, py, px + w, py + h))), control)
        subset = {**row, "panels": [c for c in row["panels"] if c["label"] not in ("Pooled2k", "Spatial2k")]}
        image, panels = insert_camera_panels(output, row["id"], subset, "Local-only2k", [("With shoulder check", new)])
        result = {
            "id": row["id"], "source_board": row, "image": image, "panels": panels,
            "native_query": box, "native_ROI": row["case"]["ROI_xywh"],
            "display_exposure": row["display_exposure"], "noise": obs["noise"],
            "parent_checkpoint": base["checkpoint"], "parent": found["prediction"],
            "guides": [asdict(g) for g in guides], "fits": fits,
            "ROI_added_RMS_DN16": float(np.sqrt(np.mean(correction**2))),
            "ROI_peak_DN16": float(np.abs(correction).max()),
            "identical_display_pixels": int((new == control).all(2).sum()),
        }
        rows.append(result)
        print(row["id"], len(guides), len([f for f in fits if f["changed"]]),
              result["ROI_added_RMS_DN16"], result["ROI_peak_DN16"], flush=True)
    assert len(rows) == 8
    write_json(output / "result.json", {
        "driver": reference(__file__), "method": reference(ROOT / "proposals.py"),
        "native_input_plan": reference(plan_path), "existing_boards": reference(SAVED),
        "parent_collection": reference(base_path), "results": rows,
    })


if __name__ == "__main__":
    main()
