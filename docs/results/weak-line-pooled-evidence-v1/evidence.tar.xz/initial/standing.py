"""Use cached real RAW surrounds and preserve the established native controls."""

import importlib.util
import os
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from run import ROOT, OLDER, apply_policy, estimate, external_proposals

spec = importlib.util.spec_from_file_location("current_standing", OLDER / "standing.py")
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    torch.set_num_threads(2)
    camera = read_json(previous.SAVED)
    declaration = read_json(checked(camera["plan"]))
    prior_path = OLDER/"standing/result.json"
    prior = read_json(prior_path)
    prior_reviews = {r["id"]:r for r in prior["results"]}
    base_path = previous.PREVIOUS/"none/collection.json"
    base = read_json(base_path)
    assert base["plan"] == camera["plan"]
    snapshots = {v["id"]:v for v in base["records"]}
    kinds = {r["id"]:r for r in declaration["observations"]}
    out = ROOT/"standing"
    out.mkdir()
    started = time.monotonic()
    rows = []
    for row in camera["boards"]:
        obs = kinds[row["observation"]]
        if obs["kind"] not in ("gfx", "mesh"):
            continue
        old = prior_reviews[row["id"]]
        model_case = snapshots[row["observation"]]
        with np.load(checked(obs["arrays"]),allow_pickle=False) as data:
            arrays = {k:data[k] for k in ("packed","variance","colors","wb","matrix")}
        assert model_case["input_fingerprints"] == {k:fingerprint(v) for k,v in arrays.items()}
        parent = np.load(checked(model_case["prediction"]),allow_pickle=False)[0]
        box = old["native_query"]
        x, y, w, h = old["native_ROI"]
        roi = x-box[0], y-box[1],w,h
        p = previous.window(parent,box)
        scene,var,c = (arrays[k][0] for k in ("packed","variance","colors"))
        guides = external_proposals(scene,var,c,box,color_estimator=estimate)
        expected = [v | {"normal":tuple(v["normal"]),"color":tuple(v["color"])} for v in old["guides"]]
        assert [asdict(g) for g in guides] == expected
        cameras = {
            "pooled continuous":"full",
            "pooled gap and edge":"gap-edge",
        }
        added, effects = [], {}
        for label, method in cameras.items():
            restored,witness = apply_policy(p,previous.window(scene,box,phase=2),
                previous.window(var,box,phase=2),c,box[:2],guides,obs["noise"],method)
            crop = previous.window(restored.astype(float)-p,roi)*65535
            added.append((label,previous.pixel(restored,arrays,roi,row["display_exposure"])))
            effects[label] = {"rms_DN16":float(np.sqrt(np.mean(crop**2))),
                              "peak_DN16":float(np.abs(crop).max()),"fits":witness}
        compact = {**row,"panels":[v for v in row["panels"] if v["label"] not in ("Pooled2k","Spatial2k")]}
        image, panels = previous.insert_camera_panels(out,row["id"],compact,"Local-only2k",added)
        rows.append({"id":row["id"],"image":image,"panels":panels,"native_query":box,
                     "native_ROI":old["native_ROI"],"noise":obs["noise"],
                     "display_exposure":row["display_exposure"],"parent_checkpoint":base["checkpoint"],
                     "parent":model_case["prediction"],"guides":expected,"effects":effects})
        print(row["id"],[round(v["rms_DN16"],5) for v in effects.values()],flush=True)
    assert len(rows)==8
    write_json(out/"result.json",{
        "source":reference(__file__),"detector_standing":reference(prior_path),"prediction_source":reference(base_path),
        "local_method":reference(ROOT/"pool.py"),"results":rows,"seconds":time.monotonic()-started,
    })


if __name__=="__main__":
    main()
