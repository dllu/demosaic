"""Verify paired native material, sumarize held-out fits and render comparisons."""

import hashlib
import shutil
import tarfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from pool import Line, candidate_envelopes, crosscheck, line_arrays
from report_scene_wave_guides import native_board

ROOT = Path(__file__).resolve().parent
EXTERIOR = ROOT.parent / "weak-line-pooled-exterior-v1"
REPO = Path.cwd()
OUT = REPO / "docs/images/weak-line-pooled-evidence-v1"
DEST = REPO / "docs/results/weak-line-pooled-evidence-v1"
SELECTED = {
    "iso400-crossing-g64-r0": "gap-exterior",
    "iso400-edge-aligned-g67-r0": "gap-exterior",
    "iso6400-parallel-g67-r0": "wide-exterior",
    "iso6400-edge-aligned-g67-r0": "wide-exterior",
}
LOSSES = ("absent_RMS_DN16", "absent_added_RMS_DN16", "true_gap_added_RMS_DN16",
          "true_gap_error_RMS_DN16", "third_guide_added_RMS_DN16")


def read_cases(location):
    collection = read_json(location/"result.json")
    plan = read_json(checked(collection["plan"]))
    rows = [read_json(checked(r)) for r in collection["records"]]
    assert len(rows) == len({r["id"] for r in rows}) == 72
    for name, src in plan["sources"].items():
        if name != "checkpoint":
            checked(src)
    return collection, plan, {r["id"]: r for r in rows}


def summary(group, arm):
    cells = [p["measurements"][arm] for p in group]
    control = [p["measurements"]["parent"] for p in group]
    return {
        "count": len(cells),
        "response_percent": [100*mean(r["response"][i] for r in cells) for i in (0,1)],
        "increment_error_DN16": [mean(r["increment_error_DN16"][i] for r in cells) for i in (0,1)],
        "patch_role_modified": [sum(r["changed"][i] for r in cells) for i in (0,1)],
        "lower_increment_error": [sum(a["increment_error_DN16"][i]<b["increment_error_DN16"][i]
                                      for a,b in zip(cells,control,strict=True)) for i in (0,1)],
        "mean_costs": {k: mean(r[k] for r in cells) for k in LOSSES},
        "peak_costs": {k: max(r[k] for r in cells) for k in LOSSES},
        "worst_added_absent_error": max(a["absent_RMS_DN16"]-b["absent_RMS_DN16"]
                                         for a,b in zip(cells,control,strict=True)),
    }


def check_metric(images, row, method, data):
    roi = np.s_[...,48:208,48:208]
    a = images.astype(float)[roi]
    d = data["detail"].astype(float)[roi]
    q = (np.abs(d).max(1)>1e-7) & data["isolated"][roi] & data["clean"][roi]
    delta = a[1]-a[0]
    scores = [float(np.sum(z[:,m]*delta[:,m])/np.sum(z[:,m]**2)) for z,m in zip(d,q,strict=True)]
    np.testing.assert_allclose(scores,row["measurements"][method]["response"],atol=2e-7,rtol=2e-6)


def local_ref(value):
    p = checked(value)
    return value | {"path":str(p.relative_to(REPO))}


def independence(arrays, row, plan):
    g = row["guides"]["known"][0]
    guide = Line(g["normal"],g["offset"],g["color"])
    base = arrays["pred_parent"][1]
    box = plan["query_box"]
    x, main, t, c, fold, _, raw, _, _, _ = line_arrays(
        base, arrays["packed"][1], arrays["variance"][1], arrays["colors"][1], box[:2], guide, True
    )
    basis,_ = candidate_envelopes(t,"gap")
    u = main[:,None] * basis
    w = plan["profiles"][row["profile"]]
    noise = (w["shot"],w["read"])
    penalty = np.r_[0,np.full(u.shape[1]-1,3)]
    q = crosscheck(x,u,raw,c,fold,noise,penalty,2.25)
    rng = np.random.default_rng(13720)
    for a in (0,1):
        b = fold != a
        perturbed = raw.copy()
        perturbed[b] += rng.normal(0,.015,b.sum())
        changed = crosscheck(x,u,perturbed,c,fold,noise,penalty,2.25)
        for k in ("choice","fitted_amplitude","training_Z"):
            assert changed[a][k] == q[a][k]
        assert changed[a]["withheld_Z"] != q[a]["withheld_Z"]
    return {"id":row["id"],"training_choices_unchanged_with_disjoint_perturbations":True,
            "site_counts":[int(np.count_nonzero(fold==i)) for i in (0,1)]}


def main():
    first, plan, records = read_cases(ROOT)
    second, ext_plan, ext = read_cases(EXTERIOR)
    assert plan["checkpoint"] == ext_plan["checkpoint"] and records.keys()==ext.keys()
    OUT.mkdir(parents=True,exist_ok=True)
    DEST.mkdir(parents=True,exist_ok=True)
    groups = defaultdict(list)
    boards = []
    checked_cases = 0
    for key,row in records.items():
        other = ext[key]
        assert row["calibration"] == other["calibration"] and row["guides"] == other["guides"]
        assert row["measurements"]["parent"] == other["measurements"]["parent"]
        combined = row | {"measurements":row["measurements"]|other["measurements"]}
        groups[row["profile"],row["layout"]].append(combined)
        if row["retained"] is None:
            continue
        with (np.load(checked(row["retained"]),allow_pickle=False) as a,
              np.load(checked(other["retained"]),allow_pickle=False) as b):
            data, replay = dict(a), dict(b)
        assert row["calibration"] == {k:fingerprint(data[k]) for k in row["calibration"]}
        for name in row["calibration"]:
            np.testing.assert_array_equal(data[name], replay[name])
        np.testing.assert_array_equal(data["pred_parent"],replay["pred_parent"])
        arrays = data | replay
        for method in combined["measurements"]:
            check_metric(arrays["pred_"+method],combined,method,data)
        checked_cases+=1
        if key not in SELECTED:
            continue
        if key == "iso400-crossing-g64-r0":
            fold_check = independence(data,row,plan)
        view = SELECTED[key]
        local = {k: data[k][1:2] for k in ("packed","colors","wb","matrix")}
        labels = ["Noisy Malvar","Local trunk","Short exterior fit",
                  "Pooled exterior fit","Exact-template fit","Exact GT"]
        p = [noisy_malvar(local)[0],
             data["pred_parent"][1],data["pred_local-exterior"][1],replay["pred_"+view][1],
             data["pred_shape-informed-open"][1],data["target"][1]]
        board = native_board(OUT,key,p,local,{"endpoint":plan["checkpoint"],"noise":plan["profiles"][row["profile"]],
                    "sensor_seed":row["seed"],"method":view,"case":key,
                    "colors":data["colors"][1].tolist()},
                    labels=labels,triplet_indices=(0,3,5),exposure=1,contrast=8)
        for k in ("board","triplet"):
            board[k]["image"] = local_ref(board[k]["image"])
        boards.append(board)
    assert len(groups)==6 and len(boards)==4 and checked_cases==12
    views = OUT/"standing"
    views.mkdir(exist_ok=True)
    photos = read_json(EXTERIOR/"standing/result.json")
    stills = []
    for row in photos["results"]:
        linked = checked(row["image"])
        dst = views/linked.name
        shutil.copyfile(linked,dst)
        assert reference(dst)["sha256"] == row["image"]["sha256"]
        stills.append(row | {"image":local_ref(reference(dst))})
    assert len(stills)==8
    bundle_files = {n:ROOT/n for n in (
        "pool.py","run.py","run-first.py","run-first.log","plan-first.json","plan.json","result.json","run.log","report.py")}
    for name, location in (("initial",ROOT),("exterior",EXTERIOR)):
        raw = read_json(location/"result.json")
        for binding in raw["records"]:
            p=checked(binding)
            bundle_files[f"{name}/cases/{p.name}"] = p
        for fp in ("pool.py","plan.json","result.json","standing.py","standing/result.json","run.py","run.log","standing.log"):
            bundle_files[f"{name}/{fp}"] = location/fp
    previous = ROOT.parent / "multiline-raw-shoulders-v1"
    for src in ("proposals.py","shoulders.py","run.py","standing.py"):
        bundle_files[f"guides/{src}"] = previous/src
    bundle_files["isolated_line.py"] = REPO/"src/demosaic/isolated_line.py"
    compressed = DEST/"evidence.tar.xz"
    refs = {k:reference(p)["sha256"] for k,p in bundle_files.items()}
    with tarfile.open(compressed,"x:xz",preset=4) as w:
        for k,p in bundle_files.items():
            w.add(p,arcname=k)
    with tarfile.open(compressed,"r:xz") as handle:
        for member in handle.getmembers():
            assert hashlib.file_digest(handle.extractfile(member),"sha256").hexdigest() == refs[member.name]
    cols = list(next(iter(groups.values()))[0]["measurements"])
    summary_rows = [{"profile":n,"layout":l,"method":a,**summary(v,a)}
            for (n,l),v in sorted(groups.items()) for a in cols]
    write_json(DEST/"publication.json",{
        "closed_synthetic_cases":72,"synthetic_summary":summary_rows,"checked_native_arrays":checked_cases,
        "holdout_invariance_check":fold_check,"synthetic_boards":boards,
        "standing_replays":stills,"archive":local_ref(reference(compressed)),
        "archive_member_sha256":refs,"prior_trials":[reference(ROOT/"result.json"),reference(EXTERIOR/"result.json")],
        "scope":"Scoped component study using the same synthetic trunk as previous line tests. Exact support arms are diagnostic. Exterior-only arms have no target-dependent fitting or orientation. Camera/SNR comparisons are qualitative, no trained endpoint or comparable PSNR panels.",
    })


if __name__ == "__main__":
    main()
