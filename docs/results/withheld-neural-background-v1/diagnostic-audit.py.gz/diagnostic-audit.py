"""CPU-only archived-input and sensor-error checks; no model/source/GT reads."""
from pathlib import Path
import sys,numpy as np
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.local_validated_waves import LocalWaveConfig,fit_local_candidate
from demosaic.prediction_archive import fingerprint
root=Path(__file__).absolute().parent;collection=read_json(root/'collection.json');result=read_json(root/'result.json');rows={(r['case'],r['fold'],r['color'],r['method']):r for r in result['rows']};maximum=0.;fields=0
for item in collection['rows']:
 with np.load(checked(item['inputs']),allow_pickle=False)as z:d={k:z[k]for k in z.files}
 prediction=np.load(checked(item['prediction']));assert prediction.shape==(1,3,256,256)and prediction.dtype==np.float32 and np.isfinite(prediction).all();colors,mask,raw=d['colors'],d['discovery'],d['raw'];actual={'packed':d['packed'][None],'variance':d['variance'][None],'colors':colors[:2,:2].ravel()[None],'wb':d['wb'],'matrix':d['matrix']};assert{k:fingerprint(v)for k,v in actual.items()}==item['argument_fingerprints'];case=item['case'];candidate=fit_local_candidate(raw,colors,mask,shot=case['row']['noise']['shot'],read=case['row']['noise']['read'],config=LocalWaveConfig());damaged=raw.copy();damaged[~mask]=np.nan;second=fit_local_candidate(damaged,colors,mask,shot=case['row']['noise']['shot'],read=case['row']['noise']['read'],config=LocalWaveConfig());np.testing.assert_array_equal(candidate.full_cfa,second.full_cfa);yy,xx=np.indices(raw.shape);neural=prediction[0,colors,yy,xx]
 for color in range(3):
  selected=(~mask)&(colors==color)
  for method,value in [('H1',candidate.full_cfa),('masked_V120',neural)]:
   e=np.minimum(value[selected].astype(np.float64),1)-raw[selected].astype(np.float64);r=rows[(case['id'],item['fold'],color,method)];metrics={'RAW_prediction_RMS_DN16':float(np.linalg.norm(e)/np.sqrt(e.size)*65535),'mean_A_proxy_standardized_squared_error':float(np.vdot(e/np.sqrt(candidate.variance_cfa[selected]),e/np.sqrt(candidate.variance_cfa[selected]))/e.size)}
   for k,v in metrics.items():maximum=max(maximum,abs(v-r[k]));fields+=1
assert fields==48 and maximum<1e-10 and 'torch'not in sys.modules
write_json(root/'independent-audit.json',{'script':reference(__file__),'collection':reference(root/'collection.json'),'metric_fields':fields,'maximum_absolute_discrepancy':maximum,'all4_neural_inputs_match_archived_argument_fingerprints':True,'all4_H1_predictors_invariant_to_actual_withheld_NaNs':True,'all4_neural_outputs_native_finite_FP32':True,'Torch_imported':False,'new_neural_forwards':0,'target_or_reference_arrays_loaded':0,'scope':'L2/dot-product reductions vs original mean-square reductions. Same frozen H1 fitter/proxy is reconstructed, not a second independent geometry implementation. Actual noisy heldout sensor values, not GT; no new inference.'});print('passed48 independent fields',maximum,flush=True)
