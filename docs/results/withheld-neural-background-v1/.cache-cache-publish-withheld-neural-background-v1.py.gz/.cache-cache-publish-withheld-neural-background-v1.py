"""Publish four-forward withheld-sensor nuisance diagnostic with no GT claim."""
from pathlib import Path
import gzip,tarfile
import numpy as np
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
R=Path.cwd();E=R/'.cache/experiments';root=E/'withheld-neural-background-v2';out=R/'docs/images/withheld-neural-background-v1';pub=R/'docs/results/withheld-neural-background-v1';out.mkdir(exist_ok=False);pub.mkdir(exist_ok=False);plan=read_json(root/'plan.json');result=read_json(root/'result.json');audit=read_json(root/'independent-audit.json');figures=[]
for figure in result['figures']:
 source=checked(figure['image']);dest=out/source.name;dest.write_bytes(source.read_bytes());assert dest.read_bytes()==source.read_bytes();case=next(c for c in plan['cases']if c['tile_xy']==figure['tile_xy']);roi=figure['ROI_xywh_in_tile'];x,y=case['tile_xy'];figures.append(dict(figure,image=reference(dest),original_image=figure['image'],source=case['row'],ROI_xywh_in_retained_context=[x+roi[0],y+roi[1],roi[2],roi[3]],viewed=True))
write_json(out/'manifest.json',{'images':figures,'scope':'Noisy full RAW Malvar, A-only analytic H1, A-only masked V120. All2 native160 boards actually viewed. No GT/reference shown or scored; both are development heldout-sensor diagnostics, not new denoising benchmark results.','new_neural_forwards':4,'new_encoder_forwards':4,'target_or_reference_arrays_loaded':0,'no_resize':True});summary=[]
for case in plan['cases']:
 for method in ['H1','masked_V120']:
  rows=[r for r in result['rows']if r['case']==case['id']and r['method']==method];weights=np.array([r['validation_samples']for r in rows]);v=np.array([r['RAW_prediction_RMS_DN16']for r in rows]);a=np.array([r['mean_A_proxy_standardized_squared_error']for r in rows]);summary.append({'case':case['id'],'method':method,'validation_samples':int(weights.sum()),'heldout_sensor_RMS_DN16':float(np.sqrt(np.average(v*v,weights=weights))),'A_proxy_standardized_squared_error':float(np.average(a,weights=weights))})
write_json(root/'summary.json',{'result':reference(root/'result.json'),'independent_audit':reference(root/'independent-audit.json'),'rows':summary,'scope':'Pool squared errors over disjoint folds and colors by validation sample count. Reused2 cases, no generalization interval; noisy same-capture sensor values are validation observations, not exact GT. Better background prediction does not establish improved weak-detail restoration.'});archives=[]
for folder,prefix,names in[(root,'diagnostic',['run.py','plan.json','launch.json','output.log','collection.json','result.json','summary.json','audit.py','audit.log','independent-audit.json']), (E/'withheld-neural-background-v1','failed-v1',['run.py','plan.json','launch.json','output.log']), (R,'.cache',['.cache/publish-withheld-neural-background-v1.py','.cache/phase-aggregation-public-model-import-v1.log'])]:
 for name in names:
  source=folder/name;dest=pub/(prefix+'-'+name.replace('/','-').lstrip('.')+'.gz');dest.write_bytes(gzip.compress(source.read_bytes(),mtime=0));assert gzip.decompress(dest.read_bytes())==source.read_bytes();archives.append({'original':reference(source),'published':reference(dest),'decompressed_bytes_exact':True})
source_archive=pub/'executed-sources.tar.gz'
with tarfile.open(source_archive,'x:gz')as t:
 for file in sorted((root/'work').rglob('*.py')):t.add(file,arcname=str(file.relative_to(root/'work')))
with tarfile.open(source_archive,'r:gz')as t:
 for member in t.getmembers():assert t.extractfile(member).read()==(root/'work'/member.name).read_bytes()
write_json(pub/'publication.json',{'archives':archives,'executed_sources':reference(source_archive),'manifest':reference(out/'manifest.json'),'root_forwards':4,'DINO_forwards':4,'all91_restoration_tensors_and_backbone_unchanged':True,'independent_metric_fields':48,'target_or_reference_arrays_loaded':0,'RAW_decodes':0,'optimizer_steps':0,'scope':'Original import failure before inference retained. Lazy public load_model export repaired and tested without Torch; working diagnostic uses exact frozen package. Two actual native views, no GT/ISO100 scoring or new corruption.'});print('published NN nuisance',summary,flush=True)
