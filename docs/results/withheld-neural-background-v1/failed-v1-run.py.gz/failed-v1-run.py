"""A-only masked V120 nuisance viability: four forwards, two real contexts, no GT."""
from pathlib import Path
import os,time,sys,hashlib
import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from PIL import Image,ImageDraw
from demosaic.models import load_model
from demosaic.local_validated_waves import LocalWaveConfig,fit_local_candidate
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.prediction_archive import fingerprint
from demosaic.archive_metrics import display,noisy_malvar
from profile_raw_kernel_inference import model_hash
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());p=read_json(root/'plan.json');(root/'run.claim').open('x').close();os.nice(10);torch.set_num_threads(2);torch.backends.cudnn.benchmark=True;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.set_float32_matmul_precision('highest');torch.cuda.set_per_process_memory_fraction(min(1,24*2**30/torch.cuda.get_device_properties(0).total_memory));began=time.monotonic();model,state=load_model('v120',device='cuda');model.eval().to(memory_format=torch.channels_last);assert len(model.restoration_state_dict())==91
selected=state['ema']if'ema'in state else state['model'];assert set(selected)==set(model.restoration_state_dict())
for k,v in model.restoration_state_dict().items():assert torch.equal(v.detach().cpu(),selected[k].cpu())
backbone_before=model_hash(model.context.backbone);assert backbone_before=='691963f0f796aac860d818d59d9d14287a4675612829fbe9467c7f5df8ce5b14';calls=[0,0];handles=[model.register_forward_pre_hook(lambda *_:calls.__setitem__(0,calls[0]+1)),model.context.backbone.register_forward_pre_hook(lambda *_:calls.__setitem__(1,calls[1]+1))];records=[]
def fill(raw,mask):
 packed=[]
 for y in range(2):
  for x in range(2):
   values=raw[y::2,x::2];observed=mask[y::2,x::2];numerator=gaussian_filter(np.where(observed,values,0).astype(np.float64),1.,mode='constant',cval=0.,truncate=3.);denominator=gaussian_filter(observed.astype(np.float64),1.,mode='constant',cval=0.,truncate=3.);interpolated=np.divide(numerator,denominator,out=np.full(values.shape,float(values[observed].mean())),where=denominator>0);packed.append(np.where(observed,values,interpolated).astype(np.float32))
 return np.stack(packed)
with torch.inference_mode():
 for case in p['cases']:
  with np.load(checked(case['row']['arrays']),allow_pickle=False)as z:original=z['packed'][case['row']['sample']];layout=z['colors'][case['row']['sample']];cal={k:z[k][case['row']['sample']:case['row']['sample']+1]for k in ['wb','matrix']}
  h,w=original.shape[-2]*2,original.shape[-1]*2;raw=np.empty((h,w),np.float32)
  for phase in range(4):raw[phase//2::2,phase%2::2]=original[phase]
  cfa=np.tile(layout.reshape(2,2),(h//2,w//2));x,y=case['tile_xy'];raw=raw[y:y+256,x:x+256];colors=cfa[y:y+256,x:x+256];local_layout=colors[:2,:2].ravel();mask=stratified_split(raw.shape,p['split_seed']+y*w+x)
  for fold,discovery in enumerate([mask,~mask]):
   packed=fill(raw,discovery);damaged=raw.copy();damaged[~discovery]=np.nan;np.testing.assert_array_equal(packed,fill(damaged,discovery));shot,read=case['row']['noise']['shot'],case['row']['noise']['read'];variance=packed.clip(0)*shot+read;args=[torch.from_numpy(a.copy()).cuda()for a in [packed[None],variance[None],local_layout[None],cal['wb'],cal['matrix']]];model.set_noise(shot,read);prediction=model(*args).cpu().numpy();path=root/f"{case['id']}-fold{fold}.npy";np.save(path,prediction,allow_pickle=False);input_path=root/f"{case['id']}-fold{fold}-inputs.npz";np.savez(input_path,raw=raw,discovery=discovery,colors=colors,wb=cal['wb'],matrix=cal['matrix'],packed=packed,variance=variance);records.append({'case':case,'fold':fold,'prediction':reference(path),'inputs':reference(input_path),'argument_fingerprints':{k:fingerprint(v)for k,v in zip(['packed','variance','colors','wb','matrix'],args,strict=True)},'heldout_destroyed_input_invariance':True})
assert calls==[4,4];assert backbone_before==model_hash(model.context.backbone)
for k,v in model.restoration_state_dict().items():assert torch.equal(v.detach().cpu(),selected[k].cpu())
write_json(root/'collection.json',{'plan':reference(root/'plan.json'),'rows':records,'root_forwards':calls[0],'encoder_forwards':calls[1],'all91_restoration_and_backbone_tensors_unchanged':True,'target_or_reference_arrays_loaded':0,'seconds':time.monotonic()-began});metrics=[];figures=[]
for item in records:
 with np.load(checked(item['inputs']),allow_pickle=False)as z:data={k:z[k]for k in z.files}
 case=item['case'];raw,colors,mask=data['raw'],data['colors'],data['discovery'];shot,read=case['row']['noise']['shot'],case['row']['noise']['read'];candidate=fit_local_candidate(raw,colors,mask,shot=shot,read=read,config=LocalWaveConfig());prediction=np.load(checked(item['prediction']));yy,xx=np.indices(raw.shape);neural=prediction[0,colors,yy,xx];analytic=candidate.full_cfa
 for color in range(3):
  chosen=(~mask)&(colors==color);values={'H1':np.minimum(analytic[chosen],1),'masked_V120':np.minimum(neural[chosen],1)}
  for method,value in values.items():
   error=value.astype(np.float64)-raw[chosen].astype(np.float64);metrics.append({'case':case['id'],'fold':item['fold'],'color':color,'method':method,'validation_samples':int(chosen.sum()),'RAW_prediction_RMS_DN16':float(np.sqrt(np.mean(error**2))*65535),'mean_A_proxy_standardized_squared_error':float(np.mean(error**2/candidate.variance_cfa[chosen]))})
 if item['fold']==0:
  calib={k:data[k]for k in ['wb','matrix']};full_packed=np.stack([raw[y::2,x::2]for y in range(2)for x in range(2)])[None];phys=dict(calib,packed=full_packed,colors=colors[:2,:2].ravel()[None]);analytic_rgb=np.stack([(candidate.design@c).reshape(raw.shape)for c in candidate.coefficients])[None];canvas=Image.new('RGB',(512,192),'#eee');draw=ImageDraw.Draw(canvas)
  for j,(label,value)in enumerate(zip(['Noisy full RAW','A-only analytic H1','A-only masked V120'],[noisy_malvar(phys),analytic_rgb,prediction],strict=True)):
   cell=np.rint(display(value[...,48:208,48:208],calib,exposure=case['row']['display_exposure'])[0].transpose(1,2,0)*255).astype(np.uint8);px=8+j*168;canvas.paste(Image.fromarray(cell),(px,24));draw.text((px,5),label,fill='black')
  path=root/(case['id']+'-comparison.png');canvas.save(path);figures.append({'image':reference(path),'tile_xy':case['tile_xy'],'ROI_xywh_in_tile':[48,48,160,160],'display_exposure':case['row']['display_exposure'],'no_resize':True,'reference':'No GT/ISO100/reference is shown or scored. Source camera RAW heldout prediction diagnostic only.'})
write_json(root/'result.json',{'collection':reference(root/'collection.json'),'rows':metrics,'figures':figures,'scope':'Development viability on two adaptively reused real contexts,32,768 heldout sensor sites per fold. Noisy RAW is a validation observation, not exact GT. A-only H1 full prediction vs frozen masked-input V120; variance proxy fitted on A only, prediction upper-clipped at sensor white. Missing samples are imputed from A using same-phase normalizedGaussian sigma1packed/truncate3, retained A samples exact. Filled inputs have correlated/changed noise law; no claim of calibrated confidence or broad quality. Four fresh neural/DINO forwards; no targets, original RAW decoding, new noise, optimizer work or full-input-parent leakage.'});print('completed four-forward A-only background diagnostic',flush=True)
