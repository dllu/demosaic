"""Independent channelwise display verification for two no-GT diagnostic boards."""
from pathlib import Path
import sys,numpy as np
from PIL import Image
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.local_validated_waves import LocalWaveConfig,fit_local_candidate
from demosaic.archive_metrics import noisy_malvar
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());sys.path.insert(0,str(repo/'scripts'));from audit_checkpoint_pilot import crop
collection=read_json(root/'collection.json');result=read_json(root/'result.json');channels=0
for item in collection['rows']:
 if item['fold']!=0:continue
 with np.load(checked(item['inputs']),allow_pickle=False)as z:data={k:z[k]for k in z.files}
 raw,colors,mask=data['raw'],data['colors'],data['discovery'];case=item['case'];cal={k:data[k]for k in ['wb','matrix']};c=fit_local_candidate(raw,colors,mask,shot=case['row']['noise']['shot'],read=case['row']['noise']['read'],config=LocalWaveConfig());analytic=np.stack([(c.design@coefficient).reshape(raw.shape)for coefficient in c.coefficients])[None];packed=np.stack([raw[y::2,x::2]for y in range(2)for x in range(2)])[None];physical=dict(cal,packed=packed,colors=colors[:2,:2].ravel()[None]);values=[noisy_malvar(physical),analytic,np.load(checked(item['prediction']))];figure=next(f for f in result['figures']if f['tile_xy']==case['tile_xy']);png=np.array(Image.open(checked(figure['image'])))
 for i,value in enumerate(values):
  pixels=crop(value,cal,[48,48,160,160],case['row']['display_exposure']);x=8+i*168;np.testing.assert_array_equal(png[24:184,x:x+160],pixels);channels+=pixels.size
assert channels==460800 and 'torch'not in sys.modules
write_json(root/'native-independent-audit.json',{'script':reference(__file__),'display_helper':reference(repo/'scripts/audit_checkpoint_pilot.py'),'source_collection':reference(root/'collection.json'),'boards':2,'native_RGB_channels_exact':channels,'Torch_imported':False,'new_neural_forwards':0,'scope':'Independent per-channel float64 WB/matrix/sRGB rendering against encoded PNGs; shared existing noisy Malvar and frozen H1 fitter, no second geometry implementation. No GT/reference.'});print('passed460800 nativeRGB channels',flush=True)
