"""Render the continuous crop where hard tint changed the actual output."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from summarize import POLICIES, one_board

ROOT=Path(__file__).resolve().parent
summary=read_json(ROOT/"summary.json")
differences=[]
for crop in summary["cases"]:
    row=read_json(checked(crop["source"]))
    with np.load(checked(row["arrays"]),allow_pickle=False) as data:
        np.testing.assert_array_equal(data["matching/soft-tint"],data["matching/local"])
        if crop["entry"]["mistint"]:
            np.testing.assert_array_equal(data["wrong-tint/soft-tint"],data["wrong-tint/local"])
        if not np.array_equal(data["matching/shared-tint"],data["matching/local"]):
            differences.append(crop)
assert len(differences)==1 and differences[0]["id"]=="iso400-continuous-g255"
plan=read_json(checked(summary["plan"]))
board=one_board(ROOT/"native",differences[0],plan)
write_json(ROOT/"continuity-witness.json",{"driver":reference(__file__),"images":board,
           "soft_tint_matching_identical":24,"soft_tint_wrong_color_identical":8,
           "shared_tint_matching_differences":[row["id"] for row in differences]})
