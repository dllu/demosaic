"""Verify the whole fixed RGB panel, match strength and render its native witnesses."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from panel import DISPLAY,score

ROOT=Path(__file__).resolve().parent
POLICIES=("standard","local","shared-tint","soft-tint")
METHODS=("broad","central",*POLICIES)
LABELS=("Wide delivery","Central check","Straight + step","Local audit","Shared tint","Soft tint")


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2))*65535)


def read_case(witness):
    row=read_json(checked(witness))
    with np.load(checked(row["arrays"]),allow_pickle=False)as f:
        vals=dict(f)
    parent,gt=vals["parent"],vals["target"]
    x,y,w,h=DISPLAY
    roi=np.s_[...,y:y+h,x:x+w]
    physical={k:vals[k]for k in ("strong_phase","weak_phase","support")}
    valid=physical["support"][roi]>.9999
    wire=valid&(physical["weak_phase"][roi]>.10)
    settings={}
    for name,result in row["metrics"].items():
        difference=None if name=="parent" else vals[name]
        dtype=score(parent,difference,gt,physical)
        assert dtype==result
        context=name.split("/")[0]if "/" in name else "matching"
        anchor=vals[context+"/central"]
        corrected=parent[roi] if difference is None else parent[roi]+difference
        removed=-anchor if difference is None else difference-anchor
        error=corrected[1]-gt[1][roi]
        settings[name]=result|{
            "natively_rendered_RMS_DN16":rms(error),
            "intact_wire_RMS_DN16":rms(error[:,wire]),
            "outside_attenuation_DN16":rms(removed[1][:,valid]),
            "edits_from_central":[bool(np.any(v))for v in removed]}
    if row["entry"]["mistint"]:
        for method in ("broad","central","standard","local"):
            np.testing.assert_array_equal(vals["matching/"+method],vals["wrong-tint/"+method])
        assert row["proof"]["matching"]["donors"]==row["proof"]["wrong-tint"]["donors"]
    matching={}
    return row,vals,settings,matching


def combine(parts,params):
    rows=[]
    examined=0
    for name in parts:
        results=read_json(checked(name))
        assert results["plan"]==params
        for witness in results["measurements"]:
            case,_,scores,matched=read_case(witness)
            examined+=len(scores)
            rows.append({"id":case["entry"]["id"],"entry":case["entry"],"source":witness,
                         "CFA":case["traits"]["CFA"],"numerical":scores,"matched":matched,
                         "roles":{c:t["roles"] for c,t in case["proof"].items()},
                         "target_tint":case["traits"]["signed_RGB_tint"]})
    assert examined==264 and len(rows)==len({r["id"]for r in rows})==24
    order={x["id"]:i for i,x in enumerate(read_json(checked(params))["cases"])}
    rows.sort(key=lambda row:order[row["id"]])
    return rows,examined


def means(rows):
    modes=("parent",*("matching/"+m for m in METHODS))
    out={}
    for prior in ("iso400","iso6400"):
        for time in ("continuity","gaps"):
            related=[q for q in rows if(q["entry"]["profile"],q["entry"]["kind"])==(prior,time)]
            assert len(related)==6
            values={}
            for method in modes:
                scores=[r["numerical"][method]for r in related]
                stat={x:mean(s[x]for s in scores if s[x]is not None)if scores[0][x]is not None else None
                    for x in ("gap_error_RMS_DN16","gap_added_RMS_DN16","outside_attenuation_DN16",
                              "natively_rendered_RMS_DN16","intact_wire_RMS_DN16")}
                stat["response_pct"]=100*mean(s["response"][0]for s in scores)
                stat["increment_RMS_DN16"]=mean(s["increment_RMS_DN16"][0]for s in scores)
                stat["altered_roles"]=[sum(s["edits_from_central"][i]for s in scores)for i in range(3)]
                values[method]=stat
            out[f"{prior}/{time}"]=values
    return out


def tint_summary(rows):
    groups={}
    for noise in ("iso400","iso6400"):
        for context in ("matching","wrong-tint","unrelated"):
            for role_type in ("continuity","gaps"):
                found=[r for r in rows if r["entry"]["profile"]==noise and r["entry"]["kind"]==role_type
                       and context in r["roles"]]
                options=[(r["target_tint"],r["roles"][context][1]) for r in found]
                entered=[(known,q) for known,q in options if "evidence" in q]
                ready=[(known,q) for known,q in entered if q["exterior_tint"]["status"]=="available"]
                def cosine(target, q):
                    norm=np.asarray(target)/np.linalg.norm(target)
                    return float(norm@q["exterior_tint"]["tint"])
                summary={"n":len(found),"reached_audit":len(entered),"tint_available":len(ready),
                         "accepted":{m:sum(q["evidence"]["policies"][m]["accepted"] for _,q in entered)
                                     for m in POLICIES},
                         "mean_tint_cosine":None,"mean_soft_weight":None,"mean_signed_z":{}}
                if ready:
                    summary["mean_tint_cosine"]=mean(cosine(t,q) for t,q in ready)
                    summary["mean_soft_weight"]=mean(q["evidence"]["tint"]["weight"] for _,q in ready)
                    summary["mean_signed_z"]={m:mean(q["evidence"]["policies"][m]["holdout"]["z"] for _,q in ready)
                                              for m in POLICIES}
                groups["/".join((noise,context,role_type))]=summary
    return groups


def repeat_scores():
    opts=[reference(ROOT/f"repeat-{i}.json")for i in (0,1)]
    plan=reference(ROOT/"repeat-plan.json")
    jobs=[read_json(checked(i))for i in opts]
    assert all(item["plan"]==plan for item in jobs)
    pairs=[r for pack in jobs for r in pack["rows"]]
    assert len(pairs)==len({r["case"]["seed"]for r in pairs})==24
    names=sorted(set(r["case"]["id"]for r in pairs))
    display={}
    for name in ("all",*names):
        rows=[r for r in pairs if name=="all" or r["case"]["id"]==name]
        assert len(rows)==(24 if name=="all" else 6)
        stats={}
        for role in ("gap","continuing"):
            samples=[r["scores"][role]for r in rows]
            stats[role]={"accepted":{arm:sum(r["proof"]["policies"][arm]["accepted"]for r in samples)for arm in POLICIES},
                         "mean_z":{arm:mean(r["proof"]["policies"][arm]["holdout"]["z"]for r in samples)for arm in POLICIES},
                         "mean":{arm:{k:mean(x["diagnostic_loss"][arm][k]for x in samples)
                                 for k in ("exact_rear_support_RMS_DN16","outside_gap_RMS_DN16")}for arm in POLICIES}}
        display[name]=stats
    return {"plan":plan,"sources":opts,"groups":display}


def one_board(out,declared,plan):
    row,data,_,_=read_case(declared["source"])
    x,y,w,h=DISPLAY
    where=np.s_[...,y:y+h,x:x+w]
    source=data["parent"][1]
    values=[noisy_malvar(data)[1],source]
    for mode in METHODS:
        f=source.copy()
        f[where]+=data["matching/"+mode][1]
        values.append(f)
    values.append(data["target"][1])
    inputs={"source_case":declared["source"],"arrays":row["arrays"],"checkpoint":plan["checkpoint"],
            "CFA":row["traits"]["CFA"],"seed":row["entry"]["seed"],"profile":plan["noise"][row["entry"]["profile"]]}
    labels=("Noisy Malvar","Local trunk",*LABELS,"Exact GT")
    return native_board(out,declared["id"],values,{k:data[k][1:2]for k in ("wb","matrix")},inputs,
              labels=labels,triplet_indices=(0,2+METHODS.index("soft-tint"),len(labels)-1),roi=DISPLAY,
              exposure=1,contrast=8)


def main():
    plan=reference(ROOT/"measured-plan.json")
    parts=[reference(ROOT/f"part-{i}.json")for i in (0,1)]
    rows,count=combine(parts,plan)
    chosen=[]
    for prior in ("iso400","iso6400"):
        gaps=[r for r in rows if r["entry"]["profile"]==prior and r["entry"]["kind"]=="gaps"]
        def difference(r,method):
            reference=r["numerical"]["matching/local"]["gap_error_RMS_DN16"]
            current=r["numerical"]["matching/"+method]["gap_error_RMS_DN16"]
            return abs(reference-current)
        largest=max(gaps,key=lambda r:(difference(r,"soft-tint"),
                                   difference(r,"shared-tint"),r["numerical"]["matching/local"]["gap_added_RMS_DN16"]))
        chosen.append(largest)
    continuous=max([r for r in rows if r["entry"]["kind"]=="continuity"],
                key=lambda r:r["numerical"]["matching/standard"]["outside_attenuation_DN16"])
    hard=max([r for r in rows if r["entry"]["profile"]=="iso6400" and r["entry"]["kind"]=="gaps"],
             key=lambda r:r["numerical"]["matching/soft-tint"]["gap_added_RMS_DN16"])
    directory=ROOT/"native";directory.mkdir()
    cases={v["id"]:v for v in (*chosen,continuous,hard)}
    boards=[one_board(directory,r,read_json(checked(plan)))for r in cases.values()]
    write_json(ROOT/"summary.json",{"plan":plan,"parts":parts,"source":reference(__file__),
               "cases":rows,"scores_recomputed":count,"groups":means(rows),"tints":tint_summary(rows),
               "repeat":repeat_scores(),"boards":boards,"triplets":[v["id"]for v in chosen]})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    main()
