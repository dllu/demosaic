"""Prospective fixed-footprint comparison of exterior signed Bayer color."""

import argparse
import importlib.util
from itertools import product
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "mesh-envelope-support-v1"
sys.path.insert(1, str(SOURCE))
spec = importlib.util.spec_from_file_location("broad_delivery", SOURCE / "fresh-study.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
from deliver import CENTRE, DISPLAY, Carrier, geometry, proposals, score, window
sys.path.insert(2, str(ROOT.parent / "mesh-refined-edge-v1"))
sys.path.insert(3, str(ROOT.parent / "mesh-shrunk-footprint-v1"))
sys.path.insert(4, str(ROOT.parent / "mesh-pooled-gap-evidence-v1"))
sys.path.insert(5, str(ROOT.parent / "mesh-averaged-gap-v1"))
sys.path.insert(6, str(ROOT.parent / "mesh-refined-footprint-v1"))
sys.path.insert(7, str(ROOT.parent / "mesh-gap-information-v1"))
from tint_audit import audit, MODES as DELIVERIES
from donor_tint import exterior_tint
from mesh import ribbon
scene_spec = importlib.util.spec_from_file_location("shrunk_footprint_fresh_scenes", ROOT / "scenes.py")
scene_generator = importlib.util.module_from_spec(scene_spec)
scene_spec.loader.exec_module(scene_generator)
observe = scene_generator.observe


def assess(scene, parent, masks, contexts, noise):
    raw, var, colors, clean = (scene[key].numpy() for key in ("packed", "variance", "colors", "target"))
    metrics = {"parent": score(parent, None, clean, masks)}
    arrays = {}
    proof = {}
    for key, context in contexts.items():
        _, trace = proposals(context, colors[0], (256, 256, 256, 256), noise, 80)
        config, moved, donors = base.prepare(
            lambda x, y, s: window(context, (x, y, s, s), phase=2),
            trace, colors[0], noise, (383.5, 383.5),
        )
        choices = {mode: [] for mode in ("broad", "central", *DELIVERIES)}
        roles = []
        for i, cfa in enumerate(colors):
            args = parent[i], raw[i], var[i], cfa, CENTRE, DISPLAY, noise, config
            broad, rear, placements = base.reconstruct(*args, None)
            phase = None
            if moved is not None:
                carried, carry_rear, carry_spans = base.reconstruct(*args, moved)
                if carried.any():
                    broad, rear, placements, phase = carried, carry_rear, carry_spans, moved
            note = {"role": i, "carried": phase is not None,
                    "wide_placements": sum(r["status"] == "supported" for r in placements)}
            for choice in choices.values():
                choice.append(broad)
            if broad.any():
                local = window(raw[i], CENTRE, phase=2)
                p, q = geometry.reserve_candidates(local, cfa, *config, noise)[0]
                if phase is not None:
                    q = base.ordered_like(phase, (p, q))[1]
                x, y = native_sites(local.shape[-2:], (-127.5, -127.5))
                f0,f1 = p.frequency
                span=trace["donor_span"]
                boxes=[(int(cx-span/2),int(cy-span/2),span) for cx,cy in trace["supporting_centers"]]
                tint,tint_note=exterior_tint(context,cfa,(p,q),noise,(256,256,256,256),boxes)
                cuts, tests = audit(local, cfa, ribbon(x,y,p), ribbon(x,y,q), noise, CENTRE, DISPLAY,
                                         float(np.arctan2(f1,f0)),tint,tint_note.get("confidence",0.))
                note["exterior_tint"]=tint_note
                for mode in ("central", *DELIVERIES):
                    if not tests["global_keep"]:
                        choices[mode][-1] = (broad-rear).astype(broad.dtype)
                    elif mode in cuts:
                        choices[mode][-1] = (broad-rear*cuts[mode][None]).astype(broad.dtype)
                note.update(central_pair=[vars(Carrier(**vars(c))) for c in (p, q)], evidence=tests)
            roles.append(note)
        for method, values in choices.items():
            name = f"{key}/{method}"
            delta = arrays[name] = np.stack(values)
            metrics[name] = score(parent, delta, clean, masks)
        proof[key] = {"donors": donors, "roles": roles}
    return metrics, arrays, proof


def plan():
    prior = read_json(SOURCE / "fresh-plan.json")
    rows = []
    for index, (profile, kind, g) in enumerate(product(("iso400", "iso6400"), ("continuity", "gaps"), range(250, 256))):
        layout = ("continuous" if g == 255 else "step") if kind == "continuity" else ("band", "ellipse", "disk", "band", "compound", "ellipse")[g-250]
        rows.append({"id": f"{profile}-{layout}-g{g}", "profile": profile, "kind": kind, "layout": layout,
                     "g": g, "seed": 1381834303 + index*49957 + g*881, "rotated": g in (251, 254),
                     "mistint": g in (250,253), "independent": g % 2 == 0})
    result = {
        "sources": [reference(ROOT / n) for n in ("panel.py", "scenes.py", "donor_tint.py", "tint_audit.py")],
        "earlier_refined_edge": reference(ROOT.parent / "mesh-refined-edge-v1" / "edge.py"),
        "previous": reference(ROOT.parent / "mesh-gap-information-v1" / "measured-plan.json"),
        "checkpoint": prior["checkpoint"], "noise": prior["noise"], "query": CENTRE, "ROI": DISPLAY,
        "cases": rows,
        "gate": "All methods share the same reserved-quarter gap footprint and whole-wire gate. Compare straight local, curved-affine local audit, hard donor tint and soft shrinkage toward independent donor tint. All score the same threshold and use identical delivery strength. Donor tint uses crossed checkerboard Bayer fits in independent exterior RAW.",
        "previous_audit": reference(ROOT.parent / "mesh-gap-information-v1" / "conditioned.py"),
        "earlier_refined_shape": reference(ROOT.parent / "mesh-refined-footprint-v1" / "optimized_footprints.py"),
        "earlier_average": reference(ROOT.parent / "mesh-averaged-gap-v1" / "averaged_footprints.py"),
        "earlier_pool": reference(ROOT.parent / "mesh-pooled-gap-evidence-v1" / "pooled_gap_audit_20261118.py"),
        "earlier_footprint": reference(ROOT.parent / "mesh-shrunk-footprint-v1" / "gate.py"),
        "scope": "24 new exact scenes, eight rotated donor controls, and eight wrong-tint controls with the same local and exterior-green samples. The six geometries vary signed RGB wire contrast. Fresh ADC draws in every scene, independent strong-only and real-crossing noise in half the cases.",
    }
    write_json(ROOT / "measured-plan.json", result)


@torch.inference_mode()
def run(part, pins):
    os.sched_setaffinity(0, pins)
    os.nice(12)
    torch.set_num_threads(len(pins))
    torch.cuda.set_per_process_memory_fraction(min(1, 6*2**30 / torch.cuda.get_device_properties(0).total_memory))
    spec = read_json(ROOT / "measured-plan.json")
    checked(spec["earlier_refined_edge"])
    checked(spec["earlier_footprint"])
    checked(spec["earlier_pool"])
    checked(spec["earlier_average"])
    checked(spec["earlier_refined_shape"])
    checked(spec["previous_audit"])
    for ref in spec["sources"]:
        checked(ref)
    start = time.monotonic()
    dest = ROOT / "scored"
    dest.mkdir(exist_ok=True)
    ck = spec["checkpoint"]
    model, state = load_scene_checkpoint(checked(ck), device="cuda", weights="ema", expected_sha256=ck["sha256"])
    assert state["step"] == 2000
    model.mode = "none"
    del state
    rows = []
    with ieee_fp32():
        for case in spec["cases"][part::2]:
            noise = spec["noise"][case["profile"]]
            items, contexts, masks, sensor, traits = observe(case, noise)
            model.base.set_noise(noise["shot"], noise["read"])
            parent = model(*(items[key].cuda() for key in ("packed", "variance", "colors", "wb", "matrix"))).cpu().numpy()
            results, arrays, proof = assess(items, parent, masks, contexts, noise)
            row = dest / (case["id"] + ".json")
            native = dest / (case["id"] + ".npz")
            np.savez_compressed(native, parent=parent, **{k: v.numpy() for k, v in items.items()}, **masks, **arrays)
            write_json(row, {"entry": case, "metrics": results, "proof": proof, "sensor": sensor, "traits": traits,
                             "arrays": reference(native), "input": {k: fingerprint(v) for k, v in items.items()}})
            rows.append(reference(row))
            print(case["id"], [(name, round(v["response"][0]*100, 3), round(v["gap_added_RMS_DN16"] or 0, 2))
                               for name, v in results.items() if name.startswith("matching/")], round(time.monotonic()-start, 1),
                  flush=True)
    write_json(ROOT / f"part-{part}.json", {"measurements": rows, "plan": reference(ROOT / "measured-plan.json"),
                                           "seconds": time.monotonic()-start})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--part", type=int, choices=(0, 1))
    args = parser.parse_args()
    if args.plan:
        plan()
    else:
        run(args.part, [12] if args.part == 0 else [13])
