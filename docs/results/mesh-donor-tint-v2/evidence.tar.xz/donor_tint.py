"""Estimate signed RAW color along a candidate direction on disjoint donor pixels."""

import math

import numpy as np

from demosaic.isolated_line import native_sites


def wave(x,y,carrier):
    geom=getattr(carrier,"perspective",(0.,0.))
    cycles=(carrier.frequency[0]*x+carrier.frequency[1]*y)/(1+geom[0]*x+geom[1]*y)
    return np.cos(2*np.pi*cycles),np.sin(2*np.pi*cycles)


def fit_tile(raw,cfa,pair,noise,offset):
    x,y=native_sites(raw.shape[-2:], (-(2*raw.shape[-1]-1)/2,)*2)
    p,q=(wave(x+offset[0],y+offset[1],carrier) for carrier in pair)
    span=2*raw.shape[-1]
    design=np.column_stack((np.ones(raw.size),x.ravel()/span,y.ravel()/span,
                           (x*y).ravel()/span**2,*[v.ravel() for v in (*p,*q)]))
    samples=raw.ravel().astype(float)
    site_color=np.broadcast_to(np.asarray(cfa)[:,None,None],raw.shape).ravel()
    fold=(np.indices(raw.shape[-2:]).sum(0)%2)
    fold=np.broadcast_to(fold,raw.shape).ravel()
    values=[]
    support=[]
    covariance=[]
    for half in (0,1):
        coefficients,signal=[],[]
        cov=[]
        for color in range(3):
            take=(fold==half)&(site_color==color)
            if int(take.sum())<64:
                raise ValueError("Incomplete exterior Bayer donor")
            X,Y=design[take],samples[take]
            variance=noise["shot"]*max(float(np.median(Y)),1e-4)+noise["read"]
            B=np.linalg.qr(X[:,:-2],mode="reduced")[0]
            W=X[:,-2:]-B@(B.T@X[:,-2:])
            H=W.T@W
            g=W.T@Y
            b=np.linalg.solve(H,g)
            coefficients.append(b)
            signal.append(float(np.sqrt(max(0.,(b@g)/variance))))
            cov.append(np.linalg.inv(H)*variance)
        values.append(np.asarray(coefficients))
        support.append(signal)
        covariance.append(np.asarray(cov))
    u,v=(w[1] for w in values)
    denom=float(np.linalg.norm(u)*np.linalg.norm(v))
    green=float(u@v/max(denom,1e-20))
    dir0,dir1=(g/max(float(np.linalg.norm(g)),1e-20) for g in (u,v))
    a,b=(M@d for M,d in zip(values,(dir1,dir0),strict=True))
    norm_tints=float(np.linalg.norm(a)*np.linalg.norm(b))
    agreement=float(a@b/max(norm_tints,1e-20))
    tint=a+b
    tint/=max(float(np.linalg.norm(tint)),1e-20)
    green_z=min(row[1] for row in support)
    accepted=bool(green_z>=3.5 and green>=.75 and agreement>=.80 and tint[1]>=.18)
    return {"accepted":accepted,"tint":tint.tolist(),"green_cos":green,"tint_cos":agreement,
            "split_green_z":[float(q[1]) for q in support],"split_color_projection":[a.tolist(),b.tolist()],
            "quadrature_standard_errors":[np.sqrt(np.diagonal(c,axis1=1,axis2=2)).tolist() for c in covariance]}


def exterior_tint(packed,cfa,pair,noise,query,boxes):
    x,y,w,h=query
    origin=(x+(w-1)/2,y+(h-1)/2)
    rows=[]
    for bx,by,span in sorted(set(boxes)):
        valid=(bx+span<=x-16 or bx>=x+w+16 or by+span<=y-16 or by>=y+h+16)
        if not valid or bx<0 or by<0 or by+span>2*packed.shape[1] or bx+span>2*packed.shape[2]:
            continue
        assert bx%2==by%2==span%2==0
        sample=packed[:,by//2:(by+span)//2,bx//2:(bx+span)//2]
        center=(bx+(span-1)/2,by+(span-1)/2)
        fit=fit_tile(sample,cfa,pair,noise,tuple(v-r for v,r in zip(center,origin,strict=True)))
        rows.append({"box":[bx,by,span],**fit})
    used=[row for row in rows if row["accepted"]]
    if not used:
        return None,{"status":"no split-checked tint","tiles":rows}
    directions=np.asarray([r["tint"] for r in used])
    agreement=float(np.min(directions@directions.T))
    if agreement < .85:
        return None,{"status":"exterior tints disagree","color_agreement":agreement,"tiles":rows}
    weights=np.asarray([min(22.,min(r["split_green_z"])) for r in used])
    result=weights@directions
    result/=np.linalg.norm(result)
    confidence=float(np.clip((np.linalg.norm(weights)-3.5)/5,0,1))*agreement
    return result,{"status":"available","tint":result.tolist(),"confidence":confidence,
                   "color_agreement":agreement,"tiles":rows}


def adjacent_boxes(packed,cfa,query,noise,pair):
    """Choose disjoint tiles by measured spectral direction without looking at query audit sites."""
    from demosaic._mesh_frequency import contained_tiles,donor_peaks,signed_alignment

    x,y,w,h=query
    span=160
    ax,ay=x+(w-span)//2,y+(h-span)//2
    candidates=set(contained_tiles(packed,query,span))
    candidates.update(((x-192,ay),(x+w+32,ay),(ax,y-192),(ax,y+h+32)))
    matches=[]
    for bx,by in candidates:
        if bx<0 or by<0 or bx+span>2*packed.shape[2] or by+span>2*packed.shape[1]:
            continue
        peaks=donor_peaks(packed[:,by//2:(by+span)//2,bx//2:(bx+span)//2],cfa,noise)
        mismatch=[min((signed_alignment(c.frequency, p.frequency)[1] for p in peaks), default=1.)
                  for c in pair]
        if max(mismatch)<=.012:
            matches.append((bx,by,span))
    return matches
