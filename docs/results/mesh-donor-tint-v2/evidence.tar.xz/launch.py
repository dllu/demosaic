"""Start two frozen panel shards and the local camera playback independently."""

from pathlib import Path
import os
import subprocess
import sys

from demosaic.experiments.artifacts import reference, write_json

ROOT=Path(__file__).resolve().parent
jobs={name:("panel.py","--part",str(i)) for i,name in enumerate(("part-0","part-1"))}
jobs["camera"]=("camera.py",)
jobs.update({f"repeat-{i}":("repeat.py","--part",str(i)) for i in range(2)})
names=sys.argv[1:] or list(jobs)
for name in names:
    driver,*args=jobs[name]
    destination=ROOT/f"{name}.log"
    with destination.open("x") as f:
        environment=os.environ|{"OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"}
        proc=subprocess.Popen([sys.executable,str(ROOT/driver),*args],stdout=f,stderr=subprocess.STDOUT,
                              env=environment,start_new_session=True)
    write_json(ROOT/f"{name}-launch.json",{"pid":proc.pid,"driver":reference(ROOT/driver),
          "frozen_panel":reference(ROOT/"measured-plan.json"),"args":args})
    print(name,proc.pid,flush=True)
