"""Archive verified crop scores, model sources and reviewed native comparisons."""

from datetime import datetime,UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
IMAGES=REPO/"docs/images/mesh-donor-tint-v2"
RESULTS=REPO/"docs/results/mesh-donor-tint-v2"


def relative(p):
    return {"path":p.relative_to(REPO).as_posix(),"sha256":reference(p)["sha256"]}


def export(image,panels=()):
    source=checked(image)
    target=IMAGES/source.name
    shutil.copyfile(source,target)
    with Image.open(target)as f:
        for panel in panels:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and x+w<=f.width and y+h<=f.height
    result=relative(target)
    assert result["sha256"]==image["sha256"]
    return result


def main():
    summary=read_json(ROOT/"summary.json")
    assert summary["scores_recomputed"]==264 and len(summary["cases"])==24
    verification=read_json(ROOT/"verification.json")
    assert len(verification["synthetic_donors"])==4 and len(verification["audits"])==2 and verification["overlapping_donor_rejected"]
    repeat=summary["repeat"]["groups"]["all"]
    assert repeat["gap"]["accepted"]=={"standard":9,"local":7,"shared-tint":8,"soft-tint":9}
    assert repeat["continuing"]["accepted"]=={"standard":0,"local":0,"shared-tint":0,"soft-tint":0}
    controls=[v for v in summary["cases"] if v["entry"]["rotated"]]
    assert len(controls)==8
    diagnostics={"rotated_donor_roles_with_changes":{
        arm:sum(any(v["numerical"]["unrelated/"+arm]["changed"]) for v in controls)
        for arm in ("broad","central","standard","local","shared-tint","soft-tint")},
        "edge_only_crops_with_changes":{
        arm:sum(v["numerical"]["matching/"+arm]["changed"][2] for v in summary["cases"])
        for arm in ("broad","central","standard","local","shared-tint","soft-tint")}}
    IMAGES.mkdir()
    RESULTS.mkdir()
    view_notes=read_json(ROOT/"native-notes.json")
    extra=read_json(ROOT/"continuity-witness.json")
    assert extra["soft_tint_matching_identical"]==24 and extra["soft_tint_wrong_color_identical"]==8
    all_boards=[*summary["boards"],extra["images"]]
    assert {b["id"] for b in all_boards}==set(view_notes)
    native=[]
    for item in all_boards:
        for k in ("source_case","arrays","checkpoint"):
            checked(item[k])
        used={k:v for k,v in item.items()if k not in ("board","triplet")}
        for k in ("board","triplet")if item["id"]in summary["triplets"] else ("board",):
            cell=item[k]
            used[k]=cell|{"image":export(cell["image"],cell["panels"])}
        native.append(used|{"observation":view_notes[item["id"]]})
    assert len(native)==4 and sum("triplet" in s for s in native)==2
    camera_notes={
        "main-overcast-sky-main-overcast-sky":"Smooth gray sky with identical pixels to the local audit.",
        "main-building-detail-main-building-detail":"Fine rails and hardware remain soft and the tint policies reproduce local-audit pixels.",
        "main-foliage-main-foliage":"Leaf edges and dark contrast match the local audit.",
        "main-chain-link-fence-main-chain-link-fence":"The finer coarse-fence crossings retained by the local audit remain visible. Donor tint yields exact parity.",
        "mesh-nominal-fine-green-mesh-left":"Fine rear modulation remains weak near the post and the tint variants reproduce the local-audit crop.",
        "mesh-nominal-fine-green-mesh-right":"Both directions remain visible, with identical fine-grid visibility to the local audit.",
        "mesh-profile3879-fine-green-mesh-left":"The diagonal weave remains faint among uneven shadow patches.",
        "mesh-profile3879-fine-green-mesh-right":"Both visible directions match the local audit. The low-contrast crossings remain softer than the references.",
    }
    prior=read_json(ROOT/"camera.json")
    viewed=[]
    for view in prior["views"]:
        for k in ("source","parent","RAW","arrays"):
            checked(view[k])
        with np.load(checked(view["arrays"]),allow_pickle=False) as arrays:
            for mode in ("shared-tint","soft-tint"):
                np.testing.assert_array_equal(arrays[mode],arrays["local"])
        viewed.append(view|{"image":export(view["image"],view["panels"]),"observation":camera_notes[view["id"]]})
    assert len(viewed)==8
    view=RESULTS/"viewing.json"
    write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
        "scope":"Viewed all eight standing GFX boards and every published synthetic comparison and triplet.",
        "camera_checkpoint":prior["checkpoint"],"camera":viewed,"synthetic":native})
    extras=("summary.json","verification.json","continuity-witness.json")
    for name in extras:shutil.copyfile(ROOT/name,RESULTS/name)
    archive=RESULTS/"evidence.tar.xz"
    paths=sorted([f for f in ROOT.iterdir() if f.is_file() and f.suffix in (".py",".json",".log")]
                 +list((ROOT/"scored").glob("*.json")))
    files={str(p.relative_to(ROOT)):p for p in paths}
    abandoned=ROOT.parent/"mesh-donor-tint-v1"
    for name in ("panel.py","scenes.py","verify.py","measured-plan.json","part-0.log","part-1.log",
                 "part-0-launch.json","part-1-launch.json","verify.log"):
        files["original-control/"+name]=abandoned/name
    with tarfile.open(archive,"x:xz",preset=4)as f:
        for key,p in files.items():f.add(p,arcname=key)
    with tarfile.open(archive,"r:xz")as f:
        assert set(f.getnames())==set(files)
        for key,p in files.items():
            assert hashlib.sha256(f.extractfile(key).read()).hexdigest()==reference(p)["sha256"]
    previous=("mesh-gap-information-v1","mesh-refined-footprint-v1","mesh-tapered-strength-v1","mesh-averaged-gap-v1","mesh-pooled-gap-evidence-v1","mesh-shrunk-footprint-v1","mesh-refined-edge-v1")
    write_json(RESULTS/"publication.json",{"scope":"Same EMA crop models. Twenty-four fresh exact scenes, two sets of eight exterior interventions, twenty-four independent conditional support pairs, both standing camera scenes.",
        "archive":relative(archive),"verified_receipts":[relative(RESULTS/f)for f in (*extras,"viewing.json")],
        "archive_contents":{key:reference(p)for key,p in files.items()},"negative_controls":diagnostics,
        "earlier_sources":[relative(REPO/"docs/results"/n/"evidence.tar.xz")for n in previous]})


if __name__=="__main__":
    main()
