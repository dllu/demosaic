"""Verify signed color recovery and preservation of the withheld Bayer split."""

from dataclasses import replace
import math
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS,color_indices,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates,native_sites
from demosaic.noise import add_noise

ROOT=Path(__file__).resolve().parent
from panel import CENTRE,DISPLAY,Carrier,ribbon,window
from conditioned import audit as baseline
from donor_tint import exterior_tint,fit_tile
from pooled_gap_audit_20261118 import masks
from tint_audit import audit


def donor_checks():
    size=96
    x,y=coordinates(size,size,origin=(-(size-1)/2,)*2)
    f=Carrier((.051,-.033),.2,.10,(0.,0.))
    q=Carrier((.031,.073),.31,.10,(0.,0.))
    p,w=(ribbon(x,y,c) for c in (f,q))
    tint=np.array([.55,.7,-.45])
    tint/=np.linalg.norm(tint)
    occlusion=1-p
    photo=.28+.009*x/size+.10*p+.055*tint[:,None,None]*w*occlusion
    noise={"shot":8e-5,"read":2.56e-8}
    recovered=[]
    for i,pattern in enumerate(PATTERNS):
        cfa=color_indices(pattern)
        chip=add_noise(mosaic(torch.from_numpy(photo.astype(np.float32))[None],cfa),
                noise["shot"],noise["read"],black_level=.03,generator=torch.Generator().manual_seed(74129+i))[0]
        fresh=fit_tile(chip.numpy(),cfa.numpy(),(f,q),noise,(0.,0.))
        assert fresh["accepted"] and np.dot(fresh["tint"],tint)>.99
        recovered.append({"pattern":pattern,"recovered":fresh["tint"],"cosine":float(np.dot(fresh["tint"],tint))})
    full=np.full((4,160,160),.28)
    # An excellent tint wholly inside the query must never be inspected.
    full[:,40:88,40:88]=chip.numpy()
    suspect,note=exterior_tint(full,cfa.numpy(),(f,q),noise,(64,64,144,144),
                               [(80,80,96),(16,16,96),(-2,0,96)])
    assert suspect is None and len(note["tiles"])==0
    return recovered


def check_audit(key):
    prev=ROOT.parent/"mesh-gap-information-v1"
    source=reference(prev/"scored"/f"{key}.json")
    row=read_json(checked(source))
    profile=read_json(prev/"measured-plan.json")["noise"][row["entry"]["profile"]]
    role=row["proof"]["matching"]["roles"][1]
    with np.load(checked(row["arrays"]),allow_pickle=False) as pack:
        data=window(pack["packed"][1],CENTRE,phase=2)
        cfa=pack["colors"][1]
    x,y=native_sites(data.shape[-2:],(-127.5,-127.5))
    p,q=(ribbon(x,y,Carrier(**g)) for g in role["central_pair"])
    fx,fy=role["central_pair"][0]["frequency"]
    angle=math.atan2(fy,fx)
    color=np.array([.52,.71,-.33]);color/=np.linalg.norm(color)
    args=(cfa,p,q,profile,CENTRE,DISPLAY,angle)
    out,before=audit(data,*args,color,.9)
    original,proof=baseline(data,*args)
    np.testing.assert_array_equal(out["local"],original["joint-audit-only"])
    np.testing.assert_array_equal(out["standard"],original["standard"])
    assert before["policies"]["local"]["holdout"]==proof["policies"]["joint-audit-only"]["holdout"]
    saved=np.array(data,copy=True)
    reserve,groups=masks(saved)
    checked_sites=groups[-1].reshape(saved.shape)
    assert not np.any(reserve&checked_sites.ravel())
    saved[checked_sites]+=.012*(p[checked_sites]-.27*q[checked_sites])
    _,score=audit(saved,*args,color,.9)
    assert before["tint"]==score["tint"] and before["curved_edge"]==score["curved_edge"]
    for name,note in before["policies"].items():
        assert score["policies"][name]["nomination"]==note["nomination"]
        assert score["policies"][name]["holdout"]["z"]!=note["holdout"]["z"]
    _,no_tint=audit(data,*args)
    assert no_tint["policies"]["local"]==no_tint["policies"]["shared-tint"]==no_tint["policies"]["soft-tint"]
    return {"case":source,"same_shape_and_fit_after_validation_mutation":True,"same_local_and_straight_as_archived":True}


if __name__=="__main__":
    os.sched_setaffinity(0,[19]);os.nice(12);torch.set_num_threads(1)
    checks=donor_checks()
    for w in checks:
        print(w,flush=True)
    verified=[check_audit(key) for key in ("iso400-step-g241","iso6400-ellipse-g245")]
    write_json(ROOT/"verification.json",{"source":reference(__file__),"synthetic_donors":checks,
         "audits":verified,"overlapping_donor_rejected":True})
