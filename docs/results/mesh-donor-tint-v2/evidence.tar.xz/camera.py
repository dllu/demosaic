"""Play the independent donor tint score on both standing GFX scenes."""

import importlib.util
import os
from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_frequency import ADJACENT_SEARCH, adjacent_prior, infer_prior
from demosaic._mesh_profiles import ribbon
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.mesh_refinement import _overlap_correction
from panel import window

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "mesh-envelope-support-v1"
sys.path.insert(1, str(SOURCE))
spec = importlib.util.spec_from_file_location("earlier_camera", SOURCE / "camera_step.py")
earlier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)
sys.path.insert(2, str(ROOT.parent / "mesh-refined-edge-v1"))
sys.path.insert(3, str(ROOT.parent / "mesh-shrunk-footprint-v1"))
sys.path.insert(4,str(ROOT.parent/"mesh-pooled-gap-evidence-v1"))
sys.path.insert(5,str(ROOT.parent/"mesh-averaged-gap-v1"))
sys.path.insert(6, str(ROOT.parent / "mesh-refined-footprint-v1"))
from tint_audit import audit, MODES as DELIVERIES
from donor_tint import adjacent_boxes, exterior_tint
from standing import legacy


def rms(a):
    return float(np.sqrt(np.mean(a.astype(float)**2)) * 65535)


def run():
    rendered = read_json(ROOT.parent / "mesh-gap-information-v1" / "camera.json")
    by_id = {r["id"]: r for r in rendered["views"]}
    precise = {r["id"]: r for r in read_json(ROOT.parent / "donor-phase-transport-v1" / "port.json")["cases"]}
    frames = read_json(ROOT.parent / "local-mesh-phase-evidence-v1" / "camera.json")
    dest = ROOT / "camera"
    dest.mkdir()
    rows = []
    for frame in frames["views"]:
        key = frame["id"]
        rec = by_id[key]
        query, roi, noise = (frame[k] for k in ("query", "ROI", "noise"))
        with np.load(checked(rec["arrays"]), allow_pickle=False) as f:
            packaged, prior_gap, prior_local = (f[k] for k in ("packaged", "standard", "joint-audit-only"))
        with np.load(checked(frame["input"]), allow_pickle=False) as f:
            raw, var, cfa = (f[k][0] for k in ("packed", "variance", "colors"))
            color = {k: f[k] for k in ("wb", "matrix")}
        parent = np.load(checked(frame["parent"]), allow_pickle=False)[0]
        trunk = window(parent, roi)
        fields = {k:packaged for k in DELIVERIES}
        proof = None
        if np.any(packaged != trunk):
            donors = infer_prior(raw, cfa, query, noise, span=precise[key]["noise"]["donor_span"])
            opts = {}
            delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors)
            if delta is None or not delta.any():
                donors = adjacent_prior(raw, cfa, query, noise)
                opts = {"search": ADJACENT_SEARCH}
                delta, pair = _overlap_correction(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(trunk + delta, packaged)
            all_delta, rear = earlier.front_field(parent, raw, var, cfa, query, roi, noise, donors, **opts)
            np.testing.assert_array_equal(all_delta, delta)
            sample = window(raw, query, phase=2)
            positions = native_sites(sample.shape[-2:], (-127.5, -127.5))
            p, q = (ribbon(*positions, v) for v in pair)
            fx,fy = pair[0].frequency
            boxes=adjacent_boxes(raw,cfa,query,noise,pair)
            tint,tint_note=exterior_tint(raw,cfa,pair,noise,query,boxes)
            cuts, proof = audit(sample,cfa,p,q,noise,query,roi,float(np.arctan2(fy,fx)),
                                tint,tint_note.get("confidence",0.))
            proof["exterior_tint"]=tint_note
            def corrected(cut):
                if not proof["global_keep"]:
                    return trunk + (delta - rear).astype(delta.dtype)
                return trunk + (delta - rear*cut[None]).astype(delta.dtype)
            fields = {k:corrected(cut) for k,cut in cuts.items()}
        np.testing.assert_array_equal(fields["standard"],prior_gap)
        np.testing.assert_array_equal(fields["local"],prior_local)
        w,h=roi[2:]
        shown=tuple(DELIVERIES)
        names=("Straight + step","Local audit","Shared tint","Soft tint")
        panels=[(label,legacy.pixel(fields[method],color,(0,0,w,h),rec["exposure"]))
                for method,label in zip(shown,names,strict=True)]
        omit=("Straight + step","Affine rear","Curved edge","Curved + affine")
        before={"image":rec["image"],"panels":[p for p in rec["panels"]if p["label"]not in omit]}
        image,coords=legacy.insert_camera_panels(dest,key,before,"Crop helper + adjacent",panels)
        fn = dest / f"{key}.npz"
        np.savez_compressed(fn,packaged=packaged,previous=prior_gap,parent=trunk,**fields)
        differences={k:rms(value-packaged) for k,value in fields.items()}
        extra={k:rms(value-fields["standard"])for k,value in fields.items()}
        rows.append({k:rec[k] for k in ("id","source","RAW","parent","exposure","ROI","query","noise")} |
                    {"image":image,"panels":coords,"proof":proof,"changes_from_packaged_DN16":differences,
                     "changes_from_standard_DN16":extra,"arrays":reference(fn)})
        print(key,differences,proof and [(k,v["accepted"],round(v["holdout"]["z"],2))for k,v in proof["policies"].items()],flush=True)
    assert len(rows) == 8
    write_json(ROOT / "camera.json", {"sources": [reference(__file__), reference(ROOT / "tint_audit.py"), reference(ROOT / "donor_tint.py")],
                                     "prior": reference(ROOT.parent / "mesh-gap-information-v1" / "camera.json"),
                                     "checkpoint": rendered["checkpoint"], "views": rows,
                                     "scope": "Native 100 percent qualitative playback. Same saved parent and same reproduced packaged deltas."})


if __name__ == "__main__":
    os.sched_setaffinity(0, [14])
    os.nice(12)
    run()
