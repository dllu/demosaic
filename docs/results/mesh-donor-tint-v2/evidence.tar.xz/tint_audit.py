"""Use independent donor tint to regularize the measured signed Bayer template."""

import numpy as np

from demosaic.isolated_line import coordinates
from conditioned import affine_basis, curved_position, nomination, refine_edge
from edge import forecasts
from pooled_gap_audit_20261118 import SIGNED_OVERLAP, admitted, fitted_terms, read_score, sound_template

MODES=("standard","local","shared-tint","soft-tint")


def color_coefficients(data,bg,rear,reserve,tint,confidence):
    grams=[]
    rhs=[]
    sigmas=[]
    for color in range(3):
        take=reserve&(data.colors==color)
        B=np.linalg.qr(bg[take],mode="reduced")[0]
        Y=data.raw[take]
        W=rear[take]-B@(B.T@rear[take])
        variance=data.shot*max(1e-4,float(np.median(Y)))+data.read
        grams.append((W.T@W)/variance)
        rhs.append((W.T@Y)/variance)
        sigmas.append(variance)
    H=np.asarray(grams)
    g=np.asarray(rhs)
    independent=np.linalg.solve(H,g[:,:,None])[:,:,0]
    if tint is None:
        return independent,independent,independent,np.asarray(sigmas),{"weight":0.0}
    main=np.linalg.solve(np.einsum("c,cij->ij",tint*tint,H),tint@g)
    shared=tint[:,None]*main[None,:]
    diff=independent-shared
    error=float(np.einsum("ci,cij,cj->",diff,H,diff))
    # Independent colors have three times as many coefficients. Discount
    # the corresponding expected fit gain before treating it as mismatch.
    excess=max(0.,error-2*rear.shape[1])
    fraction=.75*confidence*np.exp(-excess/8.)
    blend=(1-fraction)*independent+fraction*shared
    return independent,shared,blend,np.asarray(sigmas),{"weight":float(fraction),
        "compatibility_loss":error,"local_coefficients":independent.tolist(),
        "shared_coefficients":shared.tolist()}


def audit(raw,cfa,p,q,noise,query,roi,guess,tint=None,confidence=0.):
    data,reserve,splits,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    a,b,d=splits
    seed=edge.get("shape")
    keep=seed is None or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    theta=guess if seed is None else seed[0]
    native=coordinates(roi[3],roi[2],origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5))
    X=np.column_stack((bg,rear))
    raw_cut,canvas,trace=nomination(data,X,rear,reserve,theta,native)
    delta,variance,_=sound_template(data,X,rear,reserve,raw_cut)
    standard=read_score(data.raw,data.colors,X,delta,variance,~reserve)
    contour,gain=None,None
    if seed is None:
        model=affine_basis(data)
    else:
        contour,gain=refine_edge(data,reserve,p,seed)
        step,tangent=curved_position(*data.positions,contour)
        bg=np.column_stack((data.nuisance,step,p.ravel()*step))
        model=affine_basis(data,step,tangent)
    design=np.column_stack((bg,model))
    delta,variance,_=sound_template(data,design,model,reserve,raw_cut)
    scores={"standard":standard,"local":read_score(data.raw,data.colors,design,delta,variance,~reserve)}
    witness={"weight":0.0}
    if tint is not None:
        independent,hard,soft,sigma,witness=color_coefficients(data,bg,model,reserve,tint,confidence)
        for name,coef in (("shared-tint",hard),("soft-tint",soft)):
            trial=-np.einsum("ij,ij->i",model,coef[data.colors],optimize=False)*raw_cut
            scores[name]=read_score(data.raw,data.colors,design,trial,sigma,~reserve)
    else:
        scores.update({name:scores["local"] for name in ("shared-tint","soft-tint")})
    policies={}
    cuts={}
    for name,score in scores.items():
        accepted=bool(keep and score["z"]>SIGNED_OVERLAP and score["half_displacement_gain"]>0)
        out=.5*canvas if accepted else np.zeros_like(canvas)
        policies[name]={"accepted":accepted,"holdout":score,"nomination":trace,"max_cut":float(out.max())}
        cuts[name]=out
    return cuts,{"edge":edge,"curved_edge":contour,"curved_fit_gain":gain,
                 "global_keep":keep,"policies":policies,"tint":witness}
