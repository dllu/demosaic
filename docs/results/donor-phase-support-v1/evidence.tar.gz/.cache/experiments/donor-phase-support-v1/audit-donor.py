"""Recompute each donor score via residualized harmonic design columns."""

from pathlib import Path

import numpy as np

from demosaic.donor_phase_support import ALL_HARMONICS, PHASE_BINS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.local_validated_waves import LocalWaveConfig, fit_local_candidate


root = Path(__file__).resolve().parent
evidence = root / "donor-harmonic-assessment.json"
scores = read_json(evidence)
plan = read_json(checked(scores["plan"]))
original = read_json(checked(scores["source"]))
config = LocalWaveConfig(**plan["config"])
cases = {row["id"]: row for row in plan["camera_cases"]}
groups = {g["guide_key"]: g for g in plan["groups"]}
order_counts = {"synthetic": [0, 0, 0], "camera": [0, 0, 0]}
shifts_checked, largest = 0, 0.0
for domain in ("synthetic", "camera"):
    for key, row in scores[domain].items():
        prev = original[domain][key]
        assert row["donor"] == prev["donor"] and row["noise"] == prev["noise"]
        assert row["frequencies"] == prev["revised"]
        with np.load(checked(row["donor"])) as data:
            if domain == "camera":
                case = cases[key]
                assert row["frequencies"] == case["guide"]
                assert row["donor"] == case["donor_arrays"]
                assert row["donor_box"] == prev["donor_box"] == case["donor_box"]
                qx, qy, qw, qh = case["absolute_query_xywh"]
                dx, dy, dw, dh = case["absolute_donor_xywh"]
                assert min(qx + qw, dx + dw) <= max(qx, dx) or min(qy + qh, dy + dh) <= max(qy, dy)
                x, y, w, h = row["donor_box"]
                samples = data["packed"][0, :, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
                colors = data["colors"][0]
            else:
                case = groups[key]
                assert row["donor"] != case["arrays"] and row["frequencies"] == case["frequencies"]
                samples, colors = data["packed"], data["colors"]
        height, width = samples.shape[-2:]
        raw = (
            samples.reshape(2, 2, height, width)
            .transpose(2, 0, 3, 1)
            .reshape(2 * height, 2 * width)
        )
        cfa = np.tile(colors.reshape(2, 2), (height, width))
        split = stratified_split(raw.shape, config.split_seed)
        recovered = np.zeros((2, 2, 3))
        for fi, mask in enumerate((split, ~split)):
            fit = fit_local_candidate(
                raw,
                cfa,
                mask,
                shot=row["noise"]["shot"],
                read=row["noise"]["read"],
                config=config,
                guide_frequencies_xy=row["frequencies"],
                phase_bins=PHASE_BINS,
                phase_harmonics=ALL_HARMONICS,
            )
            delta_rss, delta_energy = np.zeros((2, 3)), np.zeros((2, 3))
            for color in range(3):
                selection = cfa == color
                a = (selection & mask).ravel()
                b = (selection & ~mask).ravel()
                sigma = np.sqrt(fit.variance_cfa.ravel())
                A = fit.design[a] / sigma[a, None]
                B = fit.design[b] / sigma[b, None]
                oracle, *_ = np.linalg.lstsq(A, raw.ravel()[a] / sigma[a], rcond=1e-10)
                residual = raw.ravel()[b] / sigma[b] - B @ oracle
                for di, (start, end) in enumerate(fit.wave_slices):
                    units = np.arange(start, end)
                    for hi, remove in enumerate((units[2:4], units[4:6], units[6:])):
                        other = np.setdiff1d(np.arange(A.shape[1]), remove)
                        reg, *_ = np.linalg.lstsq(A[:, other], A[:, remove], rcond=1e-10)
                        change = (B[:, remove] - B[:, other] @ reg) @ oracle[remove]
                        delta_rss[di, hi] += np.sum((residual + change) ** 2 - residual**2) / 2
                        delta_energy[di, hi] += np.sum(change**2)
            recovered[fi] = np.divide(
                delta_rss,
                np.sqrt(delta_energy),
                out=np.zeros_like(delta_rss),
                where=delta_energy > 0,
            )
        expected = np.asarray(row["fold_by_direction_by_higher_harmonic"])
        np.testing.assert_allclose(recovered, expected, rtol=0, atol=2e-9)
        accepted = (recovered >= scores["minimum_in_each_fold"]).all(axis=0)
        for decision, orders in zip(accepted, row["orders"], strict=True):
            assert orders == [1, *(k for k, keep in enumerate(decision, start=2) if keep)]
        order_counts[domain] = (np.array(order_counts[domain]) + accepted.sum(axis=0)).tolist()
        largest = max(largest, float(np.max(np.abs(recovered - expected))))
        shifts_checked += recovered.size

assert shifts_checked == 288
write_json(
    root / "donor-audit.json",
    {
        "driver": reference(__file__),
        "assessment": reference(evidence),
        "scores_recomputed": shifts_checked,
        "max_absolute_difference": largest,
        "higher_orders": scores["higher_harmonics"],
        "direction_acceptance_counts": order_counts,
        "disjoint_camera_boxes_verified": True,
    },
)
print(shifts_checked, largest, order_counts)
