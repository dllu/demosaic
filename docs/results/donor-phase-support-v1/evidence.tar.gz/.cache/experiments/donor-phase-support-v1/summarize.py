"""Summarize color support and the held-out tradeoff."""

from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np
from report_fold_support_pooling import evaluated

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
rp = root / "review/result.json"
r = read_json(rp)
plan = read_json(checked(r["plan"]))
thresholds = plan["thresholds"]
labels = {
    "square": "Full phase fit",
    "fundamental": "Fundamental only",
    "donor-basis": "Donor harmonics",
}
methods = tuple(labels)
metrics = (
    "weak_gain",
    "strong_gain",
    "quiet_RMS_DN16",
    "weak_increment_RMS_DN16",
    "query_RMS_DN16",
    "mean_abs_weak_absent_projection",
)


def vector(row):
    return [row[k] for k in metrics[:-1]] + [abs(row["weak_absent_projection"])]


data = defaultdict(list)
for row in r["fixed_threshold_metrics"]:
    data[row["profile"], row["placement"], row["method"], row["source"]].append(row["moments"])
geom = {}
for key, rows in data.items():
    assert len(rows) == 4
    geom[key] = {k: np.mean([row[k] for row in rows], axis=0) for k in rows[0]}
calibrated = defaultdict(dict)
for row in r["leave_one_geometry_out"]:
    calibrated[row["profile"], row["placement"], row["budget_DN16"], row["source"]][
        row["method"]
    ] = row
assert len(calibrated) == 96 and all(len(p) == 3 for p in calibrated.values())
rng = np.random.default_rng(20261117)
resampling = rng.integers(0, 8, (12000, 8))

fig, axes = plt.subplots(2, 2, figsize=(10, 8), layout="constrained")
curves, budget_results = [], []
for i, profile in enumerate(("iso400", "iso6400")):
    for j, place in enumerate(("far", "near")):
        ax = axes[i, j]
        for mode, color, marker in zip(
            methods, ("#5058b5", "#087f65", "#ae5128"), ("o", "^", "s"), strict=True
        ):
            xs, ys = [], []
            for t in thresholds:
                ms = [geom[profile, place, f"{mode}-t{t:g}", s] for s in range(8)]
                values = np.array([vector(evaluated(m, 1.0)) for m in ms])
                baseline = np.array([vector(evaluated(m, 0.0)) for m in ms])
                diff = np.mean(values - baseline, axis=0)
                xs.append(diff[2])
                ys.append(diff[0] * 100)
                curves.append(
                    {
                        "profile": profile,
                        "placement": place,
                        "method": mode,
                        "threshold": t,
                        "mean": values.mean(0).tolist(),
                        "delta_V143": diff.tolist(),
                    }
                )
            ax.plot(
                xs, ys, color=color, marker=marker, markersize=4, linewidth=1.3, label=labels[mode]
            )
            ax.annotate(
                "t0",
                (xs[0], ys[0]),
                xytext=(-13, 5),
                textcoords="offset points",
                fontsize=8,
                color=color,
            )
        for budget in plan["positive_quiet_RMS_budgets_DN16"]:
            p = [calibrated[profile, place, budget, s] for s in range(8)]
            a = {arm: np.array([vector(v[arm]) for v in p]) for arm in methods}
            means = {arm: mat.mean(0).tolist() for arm, mat in a.items()}
            delta = {}
            for mode in methods[1:]:
                diff = a[mode] - a["square"]
                delta[mode] = {
                    "mean_delta": diff.mean(0).tolist(),
                    "paired_delta": diff.tolist(),
                    "paired_descriptive_interval": np.quantile(
                        diff[resampling].mean(1), [0.025, 0.975], axis=0
                    ).tolist(),
                }
            budget_results.append(
                {
                    "profile": profile,
                    "placement": place,
                    "budget_DN16": budget,
                    "means": means,
                    "delta_from_square": delta,
                }
            )
        ax.scatter([0], [0], color="#222222", marker="+", s=45, label="V143 parent")
        ax.set_title(
            f"{profile.upper()} · {'far from edge' if place == 'far' else 'near edge'}",
            loc="left",
            fontweight="bold",
        )
        ax.set_xlabel("Quiet RMS change (DN16)")
        ax.set_ylabel("Weak response change (percentage points)")
        ax.grid(alpha=0.15)
        ax.spines[["top", "right"]].set_visible(False)
        if i == j == 0:
            ax.legend(frameon=False)
fig.suptitle("Weak-wire response for three waveform bases", fontweight="bold")
plot = root / "review/quiet-tradeoff.png"
fig.savefig(plot, dpi=150)
summary = {
    "source": reference(rp),
    "producer": reference(__file__),
    "plot": reference(plot),
    "metrics": list(metrics),
    "fixed_threshold_curves": curves,
    "held_out_comparisons": budget_results,
    "scope": "Equal source/CFA weighting with actual Bayer evidence and source-level paired summaries.",
}
write_json(root / "review/summary.json", summary)
print(len(curves), len(budget_results))
