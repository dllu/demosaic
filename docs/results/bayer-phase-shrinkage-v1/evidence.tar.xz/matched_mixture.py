"""Compare adaptive synthesis with a uniform convex mixture at matched change."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from shrinkage import ROOT
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from review_quiet import numeric
from mixture import PRIOR
import evaluate_gap_head as review
import evaluate_shrinkage as native

ARMS=("shared-gate","separate-gates")


def fit(rows, scalar, metric):
    # For an identical linear luminance/spectral measurement,
    # ||near + a*(wide-near) - local||² is a quadratic in a.
    norms=np.asarray([[row["metrics"][method][metric]for method in ("directional","constant","ring8")]
                      for row in rows])
    intercept=norms[:,0]**2
    end=norms[:,2]**2-intercept
    middle=norms[:,1]**2-intercept
    curvature=(scalar*end-middle)/(scalar*(1-scalar))
    slope=end-curvature
    assert np.min(curvature)>-1e-2
    grid=np.linspace(0,1,20001)
    dose=np.sqrt((intercept[:,None]+slope[:,None]*grid+curvature[:,None]*grid**2).clip(min=0)).mean(0)
    alphas={}
    for name in ARMS:
        requested=float(np.mean([row["metrics"][name][metric]for row in rows]))
        minimum=int(dose.argmin())
        candidates=[]
        for side in (np.arange(minimum+1),np.arange(minimum,len(grid))):
            if dose[side].min()<=requested<=dose[side].max():
                candidates.append(int(side[np.argmin(abs(dose[side]-requested))]))
        if not candidates:
            candidates.append(int(np.argmin(abs(dose-requested))))
        primary=max(candidates)
        alphas[name]={"wide_weight":float(grid[primary]),"target_RMS":requested,
                      "achieved_calibration_RMS":float(dose[primary])}
        if min(candidates)!=primary:
            extra=min(candidates)
            alphas[name]["smaller_matching_weight"]=float(grid[extra])
            alphas[name]["smaller_calibration_RMS"]=float(dose[extra])
    return alphas


def main(panel):
    torch.set_num_threads(1)
    models,checkpoint,training=native.load(raw_weights=False)
    old=reference(ROOT/f"{panel}-holdout.json")
    earlier=read_json(checked(old))
    assert earlier["training"]==checkpoint
    calibr=read_json(checked(earlier["calibration"]))["rows"]
    if panel=="wire":
        calibr=[r for r in calibr if r["gap_pixels"]]
        assert len(calibr)==12
    metric="gap_added" if panel=="wire" else "flat_added"
    choices=fit(calibr,training["constant_Ema_gate"],metric)
    original=native.predict
    archive_rows={r["id"]:r for r in earlier["rows"]}

    def variants(*args,**kwargs):
        outputs=original(*args,**kwargs)
        left,right=(outputs[name]for name in ("directional","ring8"))
        for arm,opt in choices.items():
            key="fixed-mix-matched-to-"+arm
            outputs[key]=left+np.float32(opt["wide_weight"])*(right-left)
            if "smaller_matching_weight" in opt:
                outputs["small-root-matched-to-"+arm]=left+np.float32(opt["smaller_matching_weight"])*(right-left)
        assert np.max(abs(left+np.float32(training["constant_Ema_gate"])*(right-left)-outputs["constant"]))<2e-7
        return outputs

    native.predict=variants
    start=time.monotonic()
    if panel=="wire":
        incoming=read_json(checked(reference(PRIOR/"wire-parent.json")))
        lookup={row["id"]:row for row in incoming["rows"]}
        sources=read_json(checked(incoming["inputs"]))["rows"]
        plan=read_json(checked(incoming["plan"]))
        rows=review.run(sources,partial(native.wire_row,models=models,
                         plan=plan,scales={},lookup=lookup,v120=None))
        cohorts={iso:[r for r in rows if r["profile"]==iso]for iso in ("iso6400","iso400")}
        metrics=("intact_response","intact_weak_band_error","gap_added","gap_exact","gap_other_error",
                 "gap_weak_band_error","dip_response","flat_added")
    else:
        plan=read_json(checked(reference(PRIOR/"natural-results.json")))
        entries=read_json(checked(plan["inputs"]))["records"]
        membership=review.panel_membership()
        sources=[]
        for item in entries:
            meta=read_json(checked(read_json(checked(item))["case"]))
            if meta["source"] not in membership and meta["draw"]=="independent" and meta["profile"]["name"]=="iso6400":
                sources.append(item)
        assert len(sources)==48
        rows=review.run(sources,partial(native.photo_row,models=models,scales={}))
        cohorts={"iso6400/independent":rows}
        metrics=("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")
    for row in rows:
        remembered=archive_rows[row["id"]]
        assert row["input"]==remembered["input"] and row["source_id"]==remembered["source_id"]
        for name in ("directional","ring8","constant",*ARMS):
            actual=row["metrics"][name][metric]
            expected=remembered["metrics"][name][metric]
            if actual is not None:
                assert abs(actual-expected)<1e-5
        row["metrics"]={k:v for k,v in row["metrics"].items()if k in (*ARMS,"constant","directional","ring8","matched")
                        or k.startswith(("fixed-mix-matched-to-","small-root-matched-to-"))}
    pairs=[(name,"fixed-mix-matched-to-"+name)for name in ARMS]
    pairs.extend((name,"small-root-matched-to-"+name)for name,opt in choices.items()
                 if "smaller_matching_weight" in opt)
    write_json(ROOT/f"{panel}-matched-mixture.json",{"driver":reference(__file__),"training":checkpoint,
               "previous":old,"calibration":earlier["calibration"],"weights":choices,"results":numeric(cohorts,pairs,metrics),
               "seconds":time.monotonic()-start,"rows":rows,
               "scope":"A scalar in [0,1] mixes the identical frozen near and wide fields. The largest scalar that matches the mean added RMS on independent calibration sources is the primary control. A second feasible root is reported separately."})


if __name__=="__main__":
    main(sys.argv[1])
