"""Condition a bounded wide-neighborhood correction on split donor agreement."""
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

ROOT=Path(__file__).resolve().parent
WIDE=ROOT.parent/"wide-bayer-neighborhood-v1"
sys.path.insert(0,str(WIDE))
from wide_witness import NEAR,CORNERS,contributions,measure
from wide_mixture import PRIOR,Mixture,DIRECTIONAL
from phase_edge import scores
from edge_choices import correction_parts
from activity import fields,reliability,rgb_residual
from models import extend
from head_corrected_broad import features
from demosaic.phase_witness import _transform,_gather,_unit,INDEX

NEW=("nearest_reserved","wide_reserved","nearest_predictive","wide_predictive",
     "cardinal_strength","diagonal_strength","cardinal_diagonal_cosine","diagonal_signed_strength",
     "near_to_wide_cosine","frequency_shift","nearest_correction_strength",
     "wide_correction_strength","change_strength","change_parallel_fraction","local_self_power",
     "reserved_edge_fraction")
ARMS=("constant","shared-gate","separate-gates")


class Gate(nn.Module):
    def __init__(self, mode):
        super().__init__()
        self.mode=mode
        if mode=="constant":
            self.logit=nn.Parameter(torch.zeros(1))
        else:
            self.route=nn.Sequential(nn.Linear(len(NEW),24),nn.SiLU(),nn.Linear(24,16),
                                     nn.SiLU(),nn.Linear(16,2 if mode=="separate-gates"else 1))
            nn.init.zeros_(self.route[-1].weight)
            nn.init.zeros_(self.route[-1].bias)

    def weights(self, evidence):
        return torch.sigmoid(self.logit if self.mode=="constant" else self.route(evidence))

    def forward(self, evidence, nearest, components):
        weights=self.weights(evidence)
        change=(components*weights[...,None]).sum(dim=-2)
        return nearest+change


def parts(nearest, target):
    """Resolve changes parallel and orthogonal to the near correction's phase."""
    change=target-nearest
    axis=_unit(np.where(abs(nearest)>=1e-10,nearest,target))
    parallel=axis*(change*axis.conj()).real
    return parallel,change-parallel


def complex_parts(a):
    return np.stack((a.real,a.imag),axis=-1).astype(np.float32)


def fixed_coeff(network,descriptor,frozen,experts):
    with torch.inference_mode():
        result=network(torch.from_numpy(descriptor),torch.from_numpy(complex_parts(frozen)),
                       torch.from_numpy(experts)).numpy()
    return result[...,0]+1j*result[...,1]


def witnesses(raw,cfa,noise,box,donors,parent,wb,matrix,models,target=None):
    fixed,near,wide=models
    field=features(raw,cfa,noise,box,donors,parent,wb,matrix,target)
    local=fields(raw,cfa,noise)
    evaluated={}
    for label,net in (("nearest",near),("ring8",wide)):
        phase=measure(raw,cfa,noise,mode=label)
        e,edge=scores(raw,cfa,noise,phase,geometry=True)
        actual=replace(field,inputs=np.concatenate((field.inputs,phase.features),axis=-1),basis=extend(field.basis,phase))
        frozen=correction_parts(fixed,actual)[0]
        experts=np.stack((np.zeros_like(e[0]),
                          np.broadcast_to(1.5*reliability(local[0],0.,.30)[:,None],e[0].shape),
                          1.31*reliability(e[1],.55,.75),1.5*reliability(e[3],0.,.75)),axis=-1)
        descriptors=(*[np.arcsinh(s)[:,None]for s in local[:3]],np.mean(edge>=0,axis=0)[:,None],
                     np.arcsinh(e[0]),np.arcsinh(e[1]),np.arcsinh(e[3]),np.log1p(phase.exterior_z),
                     np.log1p(abs(frozen)/phase.noise.clip(min=.002)),
                     phase.features[...,4:6].mean(-1),phase.features[...,2:4].mean(-1))
        descriptor=np.stack(np.broadcast_arrays(*descriptors),axis=-1).clip(-6,6).astype(np.float32)
        evaluated[label]=(actual,phase,e,edge,frozen,experts,descriptor,fixed_coeff(net,descriptor,frozen,experts))
    line,near_phase,ns,edges,*_,left=evaluated["nearest"]
    _,wide_phase,ws,_,*_,right=evaluated["ring8"]
    transform,variance=_transform(raw,float(noise["shot"]),float(noise["read"]))
    greens=np.flatnonzero(cfa==1)
    g0,g1=(_gather(transform,int(p))for p in greens)
    direct=(g0+g1)*.5
    vg=variance[:,greens].sum(1)*.25
    x,vx=contributions(direct,vg,NEAR)
    y,vy=contributions(direct,vg,CORNERS)
    slots=INDEX[np.arange(INDEX.shape[0])[None],wide_phase.offsets]
    cardinal,diagonal=(np.take_along_axis(a,slots,axis=1)for a in (x,y))
    cvar,dvar=(np.sqrt(np.take_along_axis(a,slots,axis=1)).clip(min=2e-5)for a in (vx,vy))
    noise_scale=near_phase.noise.clip(min=.002)
    delta=np.linalg.norm(near_phase.frequency-wide_phase.frequency,axis=-1)
    components=parts(left,right)
    change=right-left
    values=(np.arcsinh(ns[1]),np.arcsinh(ws[1]),np.arcsinh(ns[3]),np.arcsinh(ws[3]),
          np.log1p(abs(cardinal)/cvar),np.log1p(abs(diagonal)/dvar),
          (_unit(cardinal)*_unit(diagonal).conj()).real,
          np.arcsinh((diagonal*_unit(cardinal).conj()).real/dvar),
          (near_phase.carrier*wide_phase.carrier.conj()).real,delta/.03125,
          np.log1p(abs(left)/noise_scale),np.log1p(abs(right)/noise_scale),np.log1p(abs(change)/noise_scale),
          abs(components[0])/abs(change).clip(min=1e-10),np.arcsinh(local[0])[:,None],np.mean(edges>=0,axis=0)[:,None])
    evidence=np.stack(np.broadcast_arrays(*values),axis=-1).clip(-6,6).astype(np.float32)
    return line,near_phase.noise,left,right,components,evidence,evaluated["nearest"]
