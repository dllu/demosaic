"""Fit matched bounded gates over the frozen near and wide corrections."""
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
import sys
import time

import numpy as np
import torch

from shrinkage import ROOT,WIDE,DIRECTIONAL,ARMS,NEW,Gate,complex_parts,witnesses
from direction import FABRIC
from evaluate_wide import load as load_wide
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from head_corrected_broad import EXACT_FLAT,NATIVE_I,NATIVE_J,SYNTH,exterior
from train_directions import losses,samples
from train_gap_head import SEED,EPOCHS,PHOTOS,choose_tiles,objective


def frozen():
    (fixed,prior,arms),proof,recipe=load_wide(raw_weights=False)
    return (fixed,prior["directional"],arms["EMA"]["ring8"]),proof,recipe


def encode(case,row,models,old):
    metadata=read_json(checked(row["measurement"]))
    assert case["index"]==row["index"]==metadata["index"]
    parents=np.load(checked(row["parent"]),allow_pickle=False)
    with np.load(checked(metadata["input"]),allow_pickle=False) as f:
        inputs={k:f[k]for k in ("packed","scene_packed","colors","wb","matrix","target")}
    surround=exterior(inputs["scene_packed"],inputs["colors"][0],case["noise"],case["box"])
    values=[witnesses(a,b,case["noise"],case["box"],surround,c,d,e,models,f)
            for a,b,c,d,e,f in zip(inputs["packed"],inputs["colors"],parents,inputs["wb"],inputs["matrix"],inputs["target"],strict=True)]
    norm=np.maximum(np.mean([item[1]for item in values[:2]],axis=0),.002)
    for observed,ref in zip(values,old,strict=True):
        field,_,_,_,_,_,near=observed
        np.testing.assert_array_equal(complex_parts(field.desired/norm).astype(np.float16),ref)
    return {"nearest":np.stack([complex_parts(item[2]/norm)for item in values]),
            "components":np.stack([complex_parts(np.stack(item[4],axis=-1)/norm[...,None])for item in values]),
            "evidence":np.stack([item[5]for item in values])}


def prepare():
    torch.set_num_threads(1)
    known,proof,checkpoint=frozen()
    frame=reference(FABRIC/"features.json")
    record=read_json(checked(frame))
    parents=read_json(checked(record["prior_training_parents"]))
    plan=read_json(checked(parents["plan"]))
    exact=np.load(checked(record["tensors"]["target"]),allow_pickle=False,mmap_mode="r")
    folder=ROOT/"features"
    folder.mkdir()
    cache={}
    start=time.monotonic()
    def run(pair):
        case,meta=pair
        return encode(case,meta,known,exact[case["index"]])
    with ThreadPoolExecutor(3)as workers:
        for i,result in enumerate(workers.map(run,zip(plan["batches"],parents["rows"],strict=True))):
            for name,data in result.items():
                assert np.isfinite(data).all()
                if name not in cache:
                    cache[name]=np.lib.format.open_memmap(folder/(name+".npy"),mode="w+",dtype=np.float16,
                                                            shape=(len(parents["rows"]),*data.shape))
                cache[name][i]=data
            if (i+1)%28==0:
                print(i+1,round(time.monotonic()-start,2),flush=True)
    for array in cache.values():
        array.flush()
    write_json(ROOT/"features.json",{"driver":reference(__file__),"operator":reference(ROOT/"shrinkage.py"),
       "sources":len(parents["rows"]),"original_features":frame,"wide_training":proof,
       "wide_checkpoint":checkpoint["checkpoint"],"parent":checkpoint["parent"],"exact_targets_reproduced":True,
       "seconds":time.monotonic()-start,"descriptors":NEW,
       "tensors":{k:reference(folder/(k+".npy"))for k in cache}})


def train():
    torch.set_num_threads(1)
    torch.manual_seed(SEED)
    device="cuda"
    total=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/total))
    artifact=reference(ROOT/"features.json")
    source=read_json(checked(artifact))
    old=reference(DIRECTIONAL/"training/completed.json")
    direction=read_json(checked(old))
    original=read_json(checked(direction["features"]))
    assert direction["features"]==source["original_features"]
    wide=read_json(checked(source["wide_training"]))
    weight=direction["gradient_match"]["weights"]["directional"]
    arrays={k:np.load(checked(v),allow_pickle=False,mmap_mode="r")for k,v in original["tensors"].items()
            if k in ("target","baseline","void","void_weight")}
    projection=read_json(checked(direction["directions"]))
    projected={k:np.load(checked(v),allow_pickle=False,mmap_mode="r")for k,v in projection["tensors"].items()}
    evidence={k:np.load(checked(v),allow_pickle=False,mmap_mode="r")for k,v in source["tensors"].items()}
    common=Gate("shared-gate").to(device)
    nets={"constant":Gate("constant").to(device),"shared-gate":common,"separate-gates":Gate("separate-gates").to(device)}
    for layer in range(len(common.route)-1):
        nets["separate-gates"].route[layer].load_state_dict(common.route[layer].state_dict())
    ema={k:deepcopy(v).requires_grad_(False)for k,v in nets.items()}
    optimizer=torch.optim.AdamW([p for net in nets.values()for p in net.parameters()],lr=.001,weight_decay=.001)
    taper=torch.tensor(SYNTH**2,dtype=torch.float32,device=device)
    coordinates=tuple(torch.tensor(v,device=device)for v in (NATIVE_I,NATIVE_J))
    count=source["sources"]
    updates=count//PHOTOS*EPOCHS
    rng=np.random.default_rng(SEED)
    history=[]
    step=0
    start=time.monotonic()
    for epoch in range(EPOCHS):
        reading=rng.permutation(count)
        for offset in range(0,count,PHOTOS):
            ids=reading[offset:offset+PHOTOS]
            tile=choose_tiles(rng,arrays["void_weight"],ids)
            data=samples(arrays,projected,ids,tile,device)
            inputs={k:torch.from_numpy(np.asarray([v[i][:,q]for i,q in zip(ids,tile,strict=True)],dtype=np.float32)).to(device)
                    for k,v in evidence.items()}
            flat=torch.as_tensor(EXACT_FLAT[tile],device=device)
            step+=1
            optimizer.param_groups[0]["lr"]=float(.001*step/24 if step<=24 else
                 .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(updates-24))))
            optimizer.zero_grad(set_to_none=True)
            results={}
            for name,net in nets.items():
                pred=net(inputs["evidence"],inputs["nearest"],inputs["components"])
                base,error,pair=objective(pred,data["target"],data["baseline"],flat)
                extra=losses(error,data,taper,coordinates)[2]
                value=base+float(weight)*extra
                value.backward()
                norm=torch.nn.utils.clip_grad_norm_(tuple(net.parameters()),2.)
                assert torch.isfinite(norm)
                results[name]=torch.stack((value,base,extra,pair,norm)).detach()
            optimizer.step()
            with torch.no_grad():
                for name in ARMS:
                    torch._foreach_lerp_(tuple(ema[name].parameters()),tuple(nets[name].parameters()),.01)
            if step==1 or step%48==0 or step==updates:
                metrics={k:v.cpu().tolist()for k,v in results.items()}
                history.append({"step":step,"metrics":metrics})
                print(step,round(time.monotonic()-start,2),metrics,flush=True)
    torch.cuda.synchronize()
    duration=time.monotonic()-start
    output=ROOT/"training"
    output.mkdir()
    checkpoint=output/f"step{step:06d}.pt"
    with checkpoint.open("xb")as stream:
        torch.save({"EMA":{k:v.state_dict()for k,v in ema.items()},"raw":{k:v.state_dict()for k,v in nets.items()},
                    "optimizer":optimizer.state_dict(),"seed":SEED,"step":step},stream)
    scalar=float(ema["constant"].logit.sigmoid().item())
    write_json(output/"completed.json",{"driver":reference(__file__),"parent":wide["parent"],
          "frozen_phase_checkpoint":wide["frozen_phase_checkpoint"],"near_training":old,
          "wide_training":source["wide_training"],"wide_checkpoint":wide["checkpoint"],
          "features":artifact,"checkpoint":reference(checkpoint),"seconds":duration,
          "updates_per_head":step,"photos":count,"visits_per_head":count*EPOCHS,"queries_per_head":count*EPOCHS*3,
          "seed":SEED,"epochs":EPOCHS,"EMA":.99,"directions_weight":weight,"optimizer":direction["optimizer"],
          "arms":{"constant":"One shared scalar for both changes","shared-gate":"Shared bounded contextual weight",
                  "separate-gates":"Separate contextual weights parallel and orthogonal to the near correction"},
          "constant_Ema_gate":scalar,"progress":history})


if __name__=="__main__":
    {"prepare":prepare,"train":train}[sys.argv[1]]()
