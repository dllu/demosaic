"""Time single fixed, wide and adaptive crop corrections on one CPU core."""
import os
import time

import numpy as np
import torch

from shrinkage import ROOT,complex_parts,witnesses,rgb_residual
from evaluate_shrinkage import apply,load
from wide_mixture import inputs
from mixture import PRIOR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from review_quiet import wire_inputs
import evaluate_gap_head as review


@torch.inference_mode()
def run():
    torch.set_num_threads(1)
    core=max(os.sched_getaffinity(0))
    os.sched_setaffinity(0,[core])
    model,receipt,state=load(raw_weights=False)
    frozen,_,gates=model
    link=reference(PRIOR/'wire-parent.json')
    data=read_json(checked(link))
    rows={entry['id']:entry for entry in data['rows']}
    plan=read_json(checked(data['plan']))
    cases=read_json(checked(data['inputs']))['rows']
    case=next(row for row in cases if row['index']==12 and row['noise']=='iso6400')
    sample,parents,proof=wire_inputs(case,rows,None)
    noise=plan['profiles'][case['noise']]
    layout=sample['colors'][0]
    vicinity=review.exterior(sample['full'],layout,noise,plan['query'])
    parent=parents['local20k'][0]
    common=(sample['packed'][0],layout,noise,plan['query'],vicinity,parent,
            sample['wb'][0],sample['matrix'][0])
    def single(mode,i):
        field,_,coeff,experts,desc=inputs(*common,frozen[0],mode=mode)
        out=frozen[i](torch.from_numpy(desc),torch.from_numpy(complex_parts(coeff)),
                      torch.from_numpy(experts)).numpy()
        return parent+rgb_residual(out[...,0]+1j*out[...,1],field)
    def bounded():
        field,_,left,_,pieces,features,_=witnesses(*common,frozen)
        out=apply(gates['EMA']['separate-gates'],torch.from_numpy(features),
             torch.from_numpy(complex_parts(left)),torch.from_numpy(complex_parts(np.stack(pieces,axis=-1))))
        return parent+rgb_residual(out,field)
    modes={'nearest':lambda:single('nearest',1),'ring8':lambda:single('ring8',2),'separate-gates':bounded}
    stats={name:[]for name in modes}
    for call in modes.values():
        assert np.isfinite(call()).all()
    for i in range(12):
        labels=list(modes)
        for name in labels[i%3:]+labels[:i%3]:
            start=time.perf_counter()
            modes[name]()
            stats[name].append(time.perf_counter()-start)
    write_json(ROOT/'runtime.json',{'driver':reference(__file__),'training':receipt,
      'input':case['input'],'parent':proof,'noise':noise,'CPU_affinity':[core],'seconds':stats,
      'median_ms':{k:float(np.median(v)*1000)for k,v in stats.items()},
      'scope':'Single 256-pixel correction starting from a retained parent array. 12 interleaved warm measurements on one CPU core.'})


if __name__=='__main__':
    run()
