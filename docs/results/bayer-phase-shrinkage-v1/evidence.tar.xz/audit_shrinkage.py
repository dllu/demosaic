"""Check complex bounds and summarize learned gates in exact weak-wire regions."""
from concurrent.futures import ThreadPoolExecutor
import sys
import time

import numpy as np
import torch

from shrinkage import ROOT,ARMS,parts,complex_parts,witnesses
from evaluate_shrinkage import load,compose
from mixture import PRIOR
from demosaic.phase_witness import XI,YI
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
import evaluate_gap_head as review

CORE=(2*YI+16>=64)&(2*YI+16<192)&(2*XI+16>=64)&(2*XI+16<192)


def check(routers):
    rng=np.random.default_rng(7062447)
    near=(rng.normal(size=(225,86))+1j*rng.normal(size=(225,86))).astype(np.complex64)*.01
    wide=(rng.normal(size=near.shape)+1j*rng.normal(size=near.shape)).astype(np.complex64)*.02
    near[0]=0
    wide[1]=near[1]=0
    u,v=parts(near,wide)
    norms=np.abs(u)**2+np.abs(v)**2
    err=float(np.max(abs(u+v-(wide-near))))
    cross=float(np.max(abs((u*v.conj()).real)))
    assert err<=8e-9 and cross<3e-9
    gates=torch.zeros(*near.shape,16)
    radii=[]
    for name,net in routers.items():
        evidence=net.weights(gates)
        assert bool(((evidence>=0)&(evidence<=1)).all())
        shape=torch.from_numpy(complex_parts(near))
        corrections=torch.from_numpy(complex_parts(np.stack((u,v),axis=-1)))
        out=net(gates,shape,corrections).numpy()
        residual=(out[...,0]+1j*out[...,1])-near
        drift=float((abs(residual)**2-norms).max())
        assert drift<5e-9
        radii.append(drift)
    return {"reconstruction_max_abs":err,"orthogonality_max_abs":cross,"bound_residual_excess_max":max(radii),
            "tested_complex_modes":near.size}


def row(task,receipt,models,plan):
    data,parents,proof=review_quiet_wire(task,receipt)
    cfa=data['colors'][0]
    profile=plan["profiles"][task["noise"]]
    parent=parents["local20k"][0]
    scene=plan["sources"][task["index"]]
    donor=review.exterior(data["full"],cfa,profile,plan["query"])
    ordinary=np.lib.stride_tricks.sliding_window_view(data["support"],(8,8))[2*YI+12,2*XI+12].mean((1,2))
    masks={"intact":CORE&(ordinary>=.97),"true-gap":CORE&(ordinary<=.01)}
    for key,value in masks.items():
        if not value.any() and key=="intact":
            raise ValueError("Missing intact anchor")
    frozen,_,gates=models
    field,_,near,wide,vectors,features,_=witnesses(data["packed"][0],cfa,profile,plan["query"],
            donor,parent,data["wb"][0],data["matrix"][0],frozen)
    norms=np.maximum(abs(wide-near)**2,1e-30)
    record={}
    for name,gate in gates["EMA"].items():
        with torch.inference_mode():
            values=np.broadcast_to(gate.weights(torch.from_numpy(features)).numpy(),(*norms.shape,1 if name!="separate-gates"else 2))
        record[name]={}
        for region,mask in masks.items():
            if mask.any():
                rate=values[mask]
                mass=norms[mask]
                record[name][region]={
                    "change_weighted_mean":((rate*mass[...,None]).sum((0,1))/mass.sum()).tolist(),
                    "unweighted_mean":rate.mean((0,1)).tolist(),
                    "n":int(mask.sum()),
                }
    return {"noise":task["noise"],"id":scene["source"]["id"],"input":task["input"],"parent":proof,"records":record}


def review_quiet_wire(task,lookup):
    from review_quiet import wire_inputs
    return wire_inputs(task,lookup,None)


def main():
    torch.set_num_threads(1)
    start=time.monotonic()
    model,pointer,endpoint=load(raw_weights=False)
    audit=check(model[2]["EMA"])
    upstream=reference(PRIOR/"wire-parent.json")
    proof=read_json(checked(upstream))
    tasks=read_json(checked(proof["inputs"]))["rows"]
    plan=read_json(checked(proof["plan"]))
    lookup={item["id"]:item for item in proof["rows"]}
    with ThreadPoolExecutor(3)as workers:
        rows=list(workers.map(lambda r:row(r,lookup,model,plan),tasks))
    result={}
    for iso in ("iso400","iso6400"):
        result[iso]={}
        for arm in ARMS:
            result[iso][arm]={}
            for name in ("intact","true-gap"):
                fields=[r["records"][arm][name]["change_weighted_mean"]for r in rows
                        if r["noise"]==iso and name in r["records"][arm]]
                result[iso][arm][name]=np.asarray(fields).mean(0).tolist()
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"training":pointer,"checkpoint":endpoint["checkpoint"],
        "source":upstream,"checks":audit,"overview":result,"rows":rows,"seconds":time.monotonic()-start,
        "scope":"Gate means weight by the squared wide-minus-near correction. Exact region labels are used only to score the delivered gate."})


if __name__=="__main__":
    main()
