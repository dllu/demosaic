"""Evaluate direction-separated training against matched gap and conditional controls."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from shrinkage import ROOT,WIDE,ARMS,Gate,witnesses
from train_shrinkage import load_wide
from demosaic.phase_witness import SIDE
from mixture import PRIOR, Mixture, combine, complex_parts, rgb_residual

sys.path.insert(0,str(ROOT.parent/"local-phase-envelope-v1"))
from gap_projection import subspace, summarize
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_quiet import LOCAL, SCENE, CORE, photo_inputs, wire_inputs, numeric, load as old_models
from demosaic.archive_metrics import photometry
import evaluate_gap_head as review




COMPARATORS=("constant","directional","ring8","shared-hard")


def load(*,raw_weights=True):
    (fixed,near,wide),prior,old=load_wide(raw_weights=False)
    binding=reference(ROOT/"training/completed.json")
    recipe=read_json(checked(binding))
    assert recipe["wide_training"]==prior and old["parent"]==recipe["parent"]
    assert recipe["wide_checkpoint"]==old["checkpoint"] and recipe["near_training"]==old["prior_training"]
    state=torch.load(checked(recipe["checkpoint"]),weights_only=True,map_location="cpu")
    trained={}
    for kind in ("EMA","raw") if raw_weights else ("EMA",):
        trained[kind]={}
        for name in ARMS:
            net=Gate(name)
            net.load_state_dict(state[kind][name],strict=True)
            trained[kind][name]=net.eval().requires_grad_(False)
    return ((fixed,near["directional"],wide["EMA"]["ring8"]),near,trained),binding,recipe


def apply(net,features,near,parts):
    score=net(features,near,parts).numpy()
    return score[...,0]+1j*score[...,1]


@torch.inference_mode()
def compose(raw,cfa,noise,box,donors,parent,wb,matrix,models):
    frozen,nets,routers=models
    field,_,left,right,parts,data,base=witnesses(raw,cfa,noise,box,donors,parent,wb,matrix,frozen)
    *_,simple,experts,desc,_=base
    prior=combine(nets,field,simple,experts,desc)
    parts=torch.from_numpy(complex_parts(np.stack(parts,axis=-1)))
    near=torch.from_numpy(complex_parts(left))
    input=torch.from_numpy(data)
    offset=torch.from_numpy(np.roll(data.reshape(SIDE,SIDE,*data.shape[1:]),(5,7),axis=(0,1)).reshape(data.shape))
    modes={"ring8":right}
    for name in ARMS:
        head=routers["EMA"][name]
        modes[name]=apply(head,input,near,parts)
        if name!="constant":
            modes[name+"-shifted"]=apply(head,offset,near,parts)
        if "raw" in routers:
            modes[name+"-raw"]=apply(routers["raw"][name],input,near,parts)
    shared=routers["EMA"]["shared-gate"]
    hard=(shared.weights(input)>=.5).to(parts.dtype)
    scores=(near+(parts*hard[...,None]).sum(-2)).numpy()
    modes["shared-hard"]=scores[...,0]+1j*scores[...,1]
    sep=routers["EMA"]["separate-gates"]
    loss=parts.clone()
    loss[...,1,:]=0
    modes["parallel-only"]=apply(sep,input,near,loss)
    loss=parts.clone()
    loss[...,0,:]=0
    modes["orthogonal-only"]=apply(sep,input,near,loss)
    weights={name:head.weights(input).numpy()for name,head in routers["EMA"].items()}
    prior|={key:rgb_residual(value,field)for key,value in modes.items()}
    images={key:parent+value for key,value in prior.items()}
    assert all(v.dtype==np.float32 and np.isfinite(v).all()for v in images.values())
    return images,weights


def predict(native,surround,noise,box,parents,models,_include=True):
    donors=review.exterior(surround,native["colors"][0],noise,box)
    output={}
    for raw,cfa,matrix,wb,parent in zip(native["packed"],native["colors"],native["matrix"],
                                      native["wb"],parents[LOCAL],strict=True):
        variants,_=compose(raw,cfa,noise,box,donors,parent,wb,matrix,models)
        for name,values in variants.items():
            output.setdefault(name,[]).append(values)
    return {key:np.stack(v)for key,v in output.items()}


def scaled_models(composed, local, scales):
    return composed | {f"{expert}-scaled-to-{name}":local+np.float32(gain)*(composed[expert]-local)
                       for name,settings in scales.items()for expert,gain in settings.items()}


def photo_row(pointer, models, scales):
    test, data, parents, proof = photo_inputs(pointer)
    variants = predict(data, data["scene_packed"], test["profile"], test["box"], parents, models)
    outputs = parents | scaled_models(variants, parents[LOCAL], scales)
    exact = review.old.target_coeff(data["target"], data, review.old.ROI)
    increment = exact[0] - exact[1]
    anchor = review.old.target_coeff(parents[LOCAL], data, review.old.ROI)
    exposure = test["profile"]["exposure"]
    results = {}
    for name, restored in outputs.items():
        bands = review.old.target_coeff(restored, data, review.old.ROI)
        response = bands[0] - bands[1]
        dot, energy = review.aligned(increment.ravel(), response.ravel())
        results[name] = {
            "increment_rms": review.old.source_rms(response-increment, 96**2),
            "present_rms": review.old.source_rms(bands[0]-exact[0], 96**2),
            "flat_rms": review.old.source_rms(bands[2], 96**2),
            "flat_added": review.old.source_rms(bands[2]-anchor[2], 96**2),
            "attenuated_added": review.old.source_rms(bands[1]-anchor[1], 96**2),
            "intact_dot": dot, "intact_power": energy,
            "srgb_present_psnr": float(photometry(restored/exposure,
                data | {"target":data["target"]/exposure})["srgb_psnr"][0]),
        }
    return {"id":test["id"], "source_id":test["source"], "profile":test["profile"]["name"], "draw":test["draw"],
            "input":test["input"],"local20k_outputs":proof,"metrics":results | {"matched":results[LOCAL]}}


def wire_row(task, models, plan, scales, lookup, v120):
    data, parents, proof = wire_inputs(task, lookup, v120)
    scene = plan["sources"][task["index"]]
    noise = plan["profiles"][task["noise"]]
    names = predict(data, data["full"], noise, plan["query"], parents, models)
    results = parents | scaled_models(names, parents[LOCAL], scales)
    clean = review.old.luma(data["target"], data)[..., CORE[0], CORE[1]]
    local = review.old.luma(parents[LOCAL], data)[..., CORE[0], CORE[1]]
    support = data["support"][CORE]
    intact = support >= .97
    gap = support <= .01
    family = scene["geometry"]["family"]
    dip = (support>.01) & (support<=.65) if family in ("smooth-dip","contrast-step") else np.zeros_like(gap)
    target = clean[0]-clean[1]
    design=subspace(scene["geometry"],gap)
    present_design=subspace(scene["geometry"],intact)
    measures = {}
    for arm, rgb in results.items():
        restored = review.old.luma(rgb,data)[..., CORE[0], CORE[1]]
        pair = restored[0]-restored[1]
        delta = restored-local
        dot, power = review.aligned(target[intact],pair[intact])
        d_dot,d_power = review.aligned(target[dip],pair[dip])
        measures[arm] = {
            "intact_rms": review.rms((pair-target)[intact]),
            "intact_dot":dot,"intact_power":power,"dip_dot":d_dot,"dip_power":d_power,
            "present_rms":review.rms(restored[0]-clean[0]),
            "gap_added":review.rms(delta[0][gap]) if gap.any() else None,
            "gap_exact":review.rms((restored[0]-clean[0])[gap]) if gap.any() else None,
            "gap_pair":review.rms((pair-target)[gap]) if gap.any() else None,
            "dip_exact":review.rms((pair-target)[dip]) if dip.any() else None,
            "weak_free_added":review.rms(delta[2]),"flat_added":review.rms(delta[3,8:-8,8:-8]),
        }
        measures[arm].update(summarize(delta[0],restored[0]-clean[0],gap,design))
        if design is not None:
            pixels=gap.sum()
            scale=65535/np.sqrt(pixels)
            q=design[1]
            measures[arm]["gap_strong_band_error"]=float(scale*np.linalg.norm(q.T@(restored[0]-clean[0])[gap]))
            measures[arm]["gap_weak_band_pair"]=float(scale*np.linalg.norm(design[2].T@(pair-target)[gap]))
        else:
            measures[arm]["gap_strong_band_error"]=None
            measures[arm]["gap_weak_band_pair"]=None
        measures[arm]["intact_weak_band_error"]=float(65535/np.sqrt(intact.sum()) *
                np.linalg.norm(present_design[2].T@(pair-target)[intact]))
    return {"id":f'{task["index"]:03d}-{task["noise"]}',"source_id":scene["source"]["id"],"profile":task["noise"],
            "family":family,"input":task["input"],"local20k_output":proof,
            "gap_pixels":int(gap.sum()),"metrics":measures | {"matched":measures[LOCAL]}}


def scale_to_targets(earlier,measure):
    overview=review.score_group(earlier)
    return {arm:{base:overview[arm][measure]["mean"]/max(overview[base][measure]["mean"],1e-12)
                 for base in COMPARATORS if base!=arm}
            for arm in ARMS[1:]}


def main(mode):
    torch.set_num_threads(1)
    models,pointer,training=load()
    main_control=reference(PRIOR/"natural-results.json")
    natural=read_json(checked(main_control))
    previous=reference(WIDE/f"{mode}-holdout.json")
    stamp={"driver":reference(__file__),"training":pointer,"checkpoint":training["checkpoint"],
           "parent":training["parent"],"frozen_phase":training["frozen_phase_checkpoint"],
           "previous_matched_inputs":previous}
    start=time.monotonic()
    training_only=models
    labels=[(name,base)for name in ARMS[1:]for base in
            (LOCAL,"100k","V120","directional","ring8","constant",f"{name}-shifted","parallel-only","orthogonal-only","shared-hard")]
    labels.extend((name,base+"-scaled-to-"+name)for name in ARMS[1:]
                  for base in COMPARATORS)
    labels.append(("separate-gates","shared-gate"))
    if mode=="photo":
        records=read_json(checked(natural["inputs"]))["records"]
        membership=review.panel_membership()
        links=[]
        for record in records:
            metadata=read_json(checked(read_json(checked(record))["case"]))
            if metadata["source"]in membership and metadata["profile"]["name"]=="iso6400" and metadata["draw"]=="independent":
                links.append(record)
        assert len(links)==16
        tune=review.run(links,partial(photo_row,models=training_only,scales={}))
        scales=scale_to_targets(tune,"flat_added")
        calibration=ROOT/"photo-calibration.json"
        write_json(calibration,stamp|{"rows":tune,"scales":scales})
        results=review.run(records,partial(photo_row,models=models,scales=scales))
        retained=[row for row in results if row["source_id"]not in membership]
        assert len(retained)==192 and len(results)==256
        cohorts={iso+"/"+draw:[row for row in retained if (row["profile"],row["draw"])==(iso,draw)]
                 for iso in ("iso400","iso6400")for draw in ("coupled","independent")}
        scores=("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")
    else:
        control=read_json(checked(reference(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")))
        def run(prefix,networks,scales,v120):
            binding=reference(PRIOR/f"{prefix}-parent.json")
            incoming=read_json(checked(binding))
            lookup={row["id"]:row for row in incoming["rows"]}
            sources=read_json(checked(incoming["inputs"]))["rows"]
            plan=read_json(checked(incoming["plan"]))
            return review.run(sources,partial(wire_row,models=networks,plan=plan,scales=scales,lookup=lookup,v120=v120))
        tune=run("wire-tune",training_only,{},None)
        gaps=[row for row in tune if row["gap_pixels"]]
        assert len(gaps)==12
        scales=scale_to_targets(gaps,"gap_added")
        calibration=ROOT/"wire-calibration.json"
        write_json(calibration,stamp|{"rows":tune,"scales":scales})
        v120={row["input"]["sha256"]:row for row in control["rows"]}
        results=run("wire",models,scales,v120)
        assert len(results)==48
        cohorts={iso:[row for row in results if row["profile"]==iso]for iso in ("iso400","iso6400")}
        scores=("intact_response","intact_rms","gap_exact","gap_added","gap_pair","flat_added",
                "gap_strong_band_error","gap_weak_band_error","gap_weak_band_pair",
                "gap_other_error","gap_weak_band_added","intact_weak_band_error","dip_response")
    prior=read_json(checked(previous))
    existing={row["id"]:row for row in prior["rows"]}
    for row in results:
        old=existing.get(row["id"])
        if old is None:
            continue
        assert old["input"]==row["input"] and old["source_id"]==row["source_id"]
        key="local20k_outputs"if mode=="photo" else "local20k_output"
        assert old[key]==row[key]
        names=("increment_rms","flat_rms") if mode=="photo" else ("intact_rms","gap_exact","flat_added")
        for arm in ("directional","ring8","conditional","Bayer-gated","local_power"):
            for key in names:
                a=row["metrics"][arm][key]
                b=old["metrics"][arm][key]
                if a is not None:
                    assert abs(a-b)<.001,(row["id"],arm,key,a,b)
    write_json(ROOT/(mode+"-holdout.json"),stamp|{"calibration":reference(calibration),"scales":scales,
       "rows":results,"reports":numeric(cohorts,labels,scores),"seconds":time.monotonic()-start})


if __name__=="__main__":
    main(sys.argv[1])
