"""Use disjoint, coarse scene gradients to direct the local Bayer measurement aperture."""
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter, map_coordinates
import torch

ROOT = Path(__file__).resolve().parent
PREV = ROOT.parent/"query-phase-support-v1"
sys.path.insert(0,str(PREV))
from support import CURVE,anchored,curvature,local,torch_phase

ARMS = ("wide","along","across")
N = 256
GRID = 16
CENTERS = np.clip(np.arange(GRID)*16+7.5,32,223)


def guide_tensor(packed,colors,box):
    """Derive low-frequency orientation over all supplied RAW using Q0/Q1 only."""
    x0,y0,w,h = box
    assert (w,h)==(N,N) and x0%2==y0%2==0
    y,x = np.indices(packed.shape[-2:])
    with anchored((0,0)):
        labels = local.partition()
    mask = labels[(y-y0//2)%128,(x-x0//2)%128]<2
    green = packed[np.flatnonzero(colors==1)].astype(np.float64).mean(0)
    density = gaussian_filter(mask.astype(float),2.8)
    assert density.min()>.1
    smooth = gaussian_filter(np.where(mask,green,0.),2.8)/density
    gy,gx = np.gradient(smooth)
    # Convert gradients per packed cell to gradients per native pixel.
    gy,gx = gy*.5,gx*.5
    trace = gaussian_filter(gx*gx+gy*gy,7.)
    diagonal = gaussian_filter(gx*gx-gy*gy,7.)
    off = gaussian_filter(2*gx*gy,7.)
    ys,xs = np.meshgrid((y0+CENTERS-.5)/2,(x0+CENTERS-.5)/2,indexing="ij")
    sample = lambda z:map_coordinates(z,[ys.ravel(),xs.ravel()],order=1,prefilter=False)
    orientation = np.stack((sample(diagonal),sample(off)),axis=-1)
    # Fixed noise floor makes the geometry nearly round in textureless areas.
    return .64*orientation/(sample(trace)[:,None]+6e-7)


def aligned_fits(packed,variance,colors,parent,weak,strong,tensor):
    device = packed.device
    green = torch.where(colors[0]==1)[0]
    row,col = torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    yy = (2*row+green[:,None,None]//2).flatten()
    xx = (2*col+green[:,None,None]%2).flatten()
    values = torch.cat((packed[:,green].flatten(1),parent[:,1,yy,xx])).double()
    noise = variance[:,green].flatten(1).repeat(2,1).double()
    labels = torch.from_numpy(local.partition()).to(device).expand(2,-1,-1).flatten()
    sign = torch.stack((torch.ones_like(row),-torch.ones_like(row))).flatten()
    YY,XX = yy.double(),xx.double()
    y,x = (YY-127.5)/128,(XX-127.5)/128
    z = torch.as_tensor(CENTERS,device=device)
    cy,cx = torch.meshgrid(z,z,indexing="ij")
    dy,dx = YY[None]-cy.reshape(-1,1),XX[None]-cx.reshape(-1,1)
    a,b = torch.as_tensor(tensor,device=device).T.unsqueeze(-1)
    base = dx.square()+dy.square()
    direction = a*(dx.square()-dy.square())+2*b*dx*dy
    det_root = (1-a.square()-b.square()).sqrt()
    valid = (x.abs()<=.70)&(y.abs()<=.70)
    phase = torch_phase(XX,YY,weak)
    competitor = torch_phase(XX,YY,strong)
    c,s = competitor.cos(),competitor.sin()
    design = torch.stack((torch.ones_like(x),x,y,sign,sign*x,sign*y,c,s,c*x,c*y,s*x,s*y,
                          phase.cos(),phase.sin()),dim=-1)
    out = {}
    for key,mult in (("along",1),("across",-1)):
        dist = (base+mult*direction)/det_root
        weights = (-dist/(2*9**2)).exp()*valid*(dist<30**2)
        out[key] = [local.solve(design[mask],values[:,mask],noise[:,mask],weights[:,mask])
                    for mask in (labels==2,labels==3)]
    return out


def estimate(args,parent,geometry,weak,tensor):
    if not geometry:
        return {n:torch.zeros_like(parent)for n in ("strong","weak",*ARMS)}
    assert weak in (0,1) and tensor.shape==(GRID*GRID,2)
    packed,variance,colors,wb,matrix = args
    gains = torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
    gains = (gains/gains[:,1:2])[:,:,None,None]
    curve = any(p[2] for p in geometry)
    fit = curvature.local_fits if curve else local.delivery_fits
    lift = curvature.lift if curve else local.lift
    n = len(parent)
    with anchored((0,0)):
        fitted = []
        possible = {}
        for i,shape in enumerate(geometry):
            other = geometry[1-i]
            target,competitor = (shape,other)if curve else (shape[:2],other[:2])
            fixed = fit(packed,variance,colors,parent,target,competitor)
            value = local.amplitude("exterior",fixed,n)
            fitted.append((lift(value,target)[:,None]*gains).to(parent.dtype))
            if i==weak:
                modes = aligned_fits(packed,variance,colors,parent,shape,other,tensor)
                for k,measurement in modes.items():
                    value = local.amplitude("exterior",fixed|{"local":measurement},n)
                    possible[k] = (lift(value,target)[:,None]*gains).to(parent.dtype)
    background,secondary = fitted[1-weak],fitted[weak]
    return {"strong":background,"weak":secondary,"wide":background+secondary,
            **{k:background+v for k,v in possible.items()}}
