"""Freeze new photos with aligned occlusions, contrast steps and independent gaps."""
import hashlib
import importlib.util
import math
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
PREV = ROOT.parent/"query-phase-support-v1"
spec = importlib.util.spec_from_file_location("previous_fixture",PREV/"prepare.py")
before = importlib.util.module_from_spec(spec)
spec.loader.exec_module(before)
SEED = 430713046225
TYPES = ("occluded","contrast","independent")


def targets(photo,layout):
    base,gap,weak = before.geometry.clean_targets(photo,layout)
    coord = torch.arange(512,dtype=photo.dtype)-255.5
    y,x = torch.meshgrid(coord,coord,indexing="ij")
    a = layout["foreground_angle"]
    signed = x*math.cos(a)+y*math.sin(a)-layout["foreground_shift"]
    field = layout["support"]
    if field=="independent":
        return base,gap,weak
    envelope = (0.5-signed/7).clamp(0,1)
    if field=="contrast":
        weak = weak*(.48+.52*envelope)
        envelope = torch.ones_like(envelope)
    frame = torch.maximum(x.abs(),y.abs())
    envelope = torch.maximum(envelope,((frame-92)/27).clamp(0,1))
    strong = base[2]
    return (strong+weak*envelope,*base[1:]),envelope,weak


def run():
    previous = reference(PREV/"plan.json")
    ref = read_json(checked(previous))
    cursor,records = ref["curve_reference"],list(ref["sources"])
    while cursor:
        plan = read_json(checked(cursor))
        records.extend(plan.get("sources",plan.get("heldout_rows",[])))
        cursor = next((plan[k]for k in ("preceding","comparison","prior","exclusion")if k in plan),None)
    repeat = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    identifiers = {r["source"]["id"]for r in records+repeat["rows"]}
    cohort = read_json(checked(ref["cohort"]))
    available = [r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
                 and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in identifiers]
    order = sorted(available,key=lambda r:hashlib.sha256(f"{SEED}/{r['id']}".encode()).hexdigest())
    material = before.geometry.fields
    material.ROOT,material.SEED,material.clean_targets = ROOT,SEED,targets
    rows = []
    for i,s in enumerate(order[:24]):
        box, = scene_crop_boxes(s["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"source crop"))
        layout = material.draw(i)
        k = (-1)**(i//3)*(.000027+i*.0000013) if (i//3)%3 else 0.
        kind = TYPES[i%3]
        layout.update({"support":kind,"step":True,"shape":"ellipse","contrast_step":kind=="contrast",
                       "weak_tangential_curvature_cycles_per_px2":k,
                       "strong_tangential_curvature_cycles_per_px2":-.65*k})
        rows.append(material.row_for(s,i,SEED)|{"box":box,"layout":layout})
    assert len({r["source"]["id"]for r in rows})==24
    write_json(ROOT/"plan.json",{
        **{k:ref[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"previous":previous,"generator":reference(material.__file__),
        "sources":rows,"seed":SEED,"fit_indices":[],"test_indices":list(range(len(rows))),
        "scope":"Eight side-occluded weak families, eight continuous real contrast transitions and eight elliptical gaps independent of the foreground edge. Common native geometry and two redraws per control."})
    material.construct()


if __name__=="__main__":
    run()
