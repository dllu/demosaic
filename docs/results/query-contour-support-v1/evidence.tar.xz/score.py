"""Score fixed scene-guided apertures and strength-matched wide controls."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from contour import ARMS,CENTERS,PREV,ROOT
from run_restore import observations
from score_panel import luma

CROP = np.s_[...,64:192,64:192]
METHODS = ("baseline",*ARMS,"uniform-along","uniform-across")
SAFETY = ("false_gap_projection","added_gap","absolute_gap","gap_pair_RMS")


def load(mode):
    receipt = reference(ROOT/f"restoration-{mode}.json")
    saved = read_json(checked(receipt))
    material = read_json(checked(saved["observations"]))
    plan = read_json(checked(material["plan"]))
    records = []
    for solved in saved["rows"]:
        i = solved["index"]
        source,capture = plan["sources"][i],material["rows"][i]
        assert i==source["index"]==capture["index"]
        observed = observations(capture)
        with np.load(checked(solved["output"]),allow_pickle=False)as data:
            y = {k:luma(data[k],observed)for k in ("baseline","strong","weak",*ARMS)}
            orientation = data["orientation"]
        exact = luma(observed["target"],observed)
        intact = observed["region"][CROP]==1
        gap = observed["region"][CROP]==0
        phase = observed["weak_linear_nominal"][CROP]
        valid = exact[0,0]-exact[0,1]
        assert intact.any() and np.all(valid[gap]==0)
        assert np.all(exact[:,3]==exact[:,3,:1,:1])
        layout = source["layout"]
        coords = np.arange(64,192)-127.5
        yy,xx = np.meshgrid(coords,coords,indexing="ij")
        a,shift = layout["foreground_angle"],layout["foreground_shift"]
        signed = xx*np.cos(a)+yy*np.sin(a)-shift
        gy,gx = np.meshgrid(CENTERS-127.5,CENTERS-127.5,indexing="ij")
        distance = gx*np.cos(a)+gy*np.sin(a)-shift
        strength = np.linalg.norm(orientation[:,0],axis=-1)
        theta = np.arctan2(orientation[:,0,:,1],orientation[:,0,:,0])
        near = (np.abs(distance.ravel())<24)&(np.max(np.abs(np.stack([gx,gy])),axis=0).ravel()<80)
        used = (strength>.15)&near
        error = np.rad2deg(.5*np.arccos(np.cos(theta-2*a).clip(-1,1)))
        diagnostic = {
            "weighted_cells_near_edge":int(used.sum()),"all_cells_near_edge":int(near.sum())*2,
            "median_abs_orientation_error_degrees":float(np.median(error[used]))if used.any()else None,
        }
        records.append({"i":i,"source":source,"capture":capture,"output":solved["output"],"exact":exact,
            "intact":intact,"gap":gap,"valid":valid,"template":phase,"lifts":y,"signed":signed,"guide":diagnostic})
    return receipt,records


def rms(array):
    return float(65535*np.sqrt((array.reshape(array.shape[0],-1)**2).mean(1)).mean())


def signed_ratio(x,t):
    return (100*(x*t[None]).sum(1)/(t*t).sum()).mean().item()


def score(r,method,scale,uniform):
    f = r["lifts"]
    if method=="baseline":
        delta = np.zeros_like(f["baseline"])
    elif method.startswith("uniform"):
        delta = scale*(f["strong"]+uniform[method.removeprefix("uniform-")]*f["weak"])
    else:
        delta = scale*f[method]
    out = f["baseline"]+delta
    gold = r["exact"]
    diff = out[:,0]-out[:,1]
    support,missing,template = (r[k]for k in ("intact","gap","valid"))
    boundary = np.abs(r["signed"])<28
    metrics = {
        "intact_projection":signed_ratio(diff[:,support],template[support]),
        "edge_projection":signed_ratio(diff[:,support&boundary],template[support&boundary]),
        "intact_error":rms((diff-template)[:,support]),
        "edge_error":rms((diff-template)[:,support&boundary]),
        "added_flat":rms(delta[:,3]),
        "absolute_flat":rms(out[:,3]-gold[:,3]),
    }
    if missing.any():
        gap_amp = 100*(diff[:,missing]*r["template"][missing]).sum(1)/(r["template"][missing]**2).sum()
        metrics.update({"false_gap_projection":float(np.abs(gap_amp).mean()),
                        "added_gap":rms(delta[:,0][:,missing]),"gap_pair_RMS":rms(diff[:,missing]),
                        "absolute_gap":rms((out[:,0]-gold[:,0])[:,missing])})
    if r["source"]["layout"]["support"]=="contrast":
        lower = (r["signed"]>4)&(r["signed"]<28)
        metrics["lower_contrast_response"] = signed_ratio(diff[:,lower],template[lower])
    return metrics


def reduce(rows):
    random = np.random.default_rng(84391525)
    sample = random.integers(len(rows),size=(10000,len(rows)))
    comparisons = (("along","wide"),("along","across"),("along","uniform-along"),("across","uniform-across"))
    saved = {}
    for k in rows[0]["metrics"]["along"]:
        columns = {m:np.array([x["metrics"][m][k]for x in rows])for m in METHODS}
        uncertainty = {}
        for a,b in comparisons:
            dif = columns[a]-columns[b]
            uncertainty[f"{a}_vs_{b}"] = [float(dif.mean()),*np.quantile(dif[sample].mean(1),(.025,.975)).tolist()]
        saved[k] = {"mean":{m:float(x.mean())for m,x in columns.items()},"paired_95pct":uncertainty}
    return saved


def main():
    old = reference(PREV/"scores.json")
    scale = read_json(checked(old))["scale"]
    cal,calibration = load("fit")
    fresh,rows = load("fresh")
    amplitude = {k:float(np.mean([rms((x["lifts"][k]-x["lifts"]["strong"])[:,0][:,x["intact"]])
                                 for x in calibration]))for k in ARMS}
    uniform = {k:amplitude[k]/amplitude["wide"]for k in ("along","across")}
    rows = [{"index":r["i"],"kind":r["source"]["layout"]["support"],"guide":r["guide"],
             "metrics":{k:score(r,k,scale,uniform)for k in METHODS}}for r in rows]
    values = {}
    for kind in ("occluded","contrast","independent"):
        block = [r for r in rows if r["kind"]==kind]
        assert len(block)==8
        values[kind] = reduce(block)
    write_json(ROOT/"scores.json",{"driver":reference(__file__),"scale_source":old,"scale":scale,
               "fit":cal,"fresh":fresh,"uniform_factors":uniform,"fit_intact_strength_DN16":amplitude,
               "groups":values,"rows":rows})
    print(uniform,flush=True)


def native():
    torch.set_num_threads(2)
    bound = reference(ROOT/"scores.json")
    scorecard = read_json(checked(bound))
    fresh,rows = load("fresh")
    decisions = read_json(ROOT/"forecasts.json")["rows"]
    chosen = [next(r for r in rows if r["source"]["layout"]["support"]==kind
                   and decisions[r["i"]]["trials"][0]["geometry"])for kind in ("occluded","contrast","independent")]
    cards = []
    output = ROOT/"native"
    output.mkdir()
    for record in chosen:
        camera = observations(record["capture"])
        with np.load(checked(record["output"]),allow_pickle=False)as data:
            base = data["baseline"][0]
            rgb = {k:base+scorecard["scale"]*data[k][0]for k in ARMS}
            rgb["uniform-along"] = base+scorecard["scale"]*(data["strong"][0]+scorecard["uniform_factors"]["along"]*data["weak"][0])
        noisy = malvar(torch.from_numpy(camera["packed"][0]),torch.from_numpy(camera["colors"][0])).numpy()
        rgb.update({"baseline":base,"noisy":noisy,"GT":camera["target"][0]})
        transforms = {k:camera[k][0]for k in ("wb","matrix")}
        rendered = {k:np.rint(display(img,transforms,exposure=2)[...,48:208,48:208]
                    .transpose(0,2,3,1)*255).astype(np.uint8)for k,img in rgb.items()}
        for name,index,names in (
            ("comparison",0,("baseline",*ARMS,"uniform-along","GT")),
            ("triplet",0,("noisy","along","GT")),
            ("outside-only",1,("baseline",*ARMS,"GT")),
            ("quiet",3,("baseline",*ARMS,"GT")),
        ):
            path = output/f"{record['i']:03d}-{name}.png"
            Image.fromarray(np.concatenate([rendered[k][index]for k in names],axis=1)).save(path,optimize=True)
            source = record["source"]
            cards.append({"image":reference(path),"index":record["i"],"kind":source["layout"]["support"],"role":name,
                "source":source["source"],"source_box":source["box"],"ROI":[48,48,160,160],"order":names,
                "camera_profile":{"shot":.00128,"read":6.5536e-6,"capture_exposure":.33},
                "display_exposure":2,"repeat":0,"CFA":source["camera"]["pattern"],"raw":record["capture"],
                "local_prediction":record["output"]})
    write_json(output/"manifest.json",{"driver":reference(__file__),"scores":bound,"restoration":fresh,
                "checkpoint":read_json(checked(fresh))["checkpoint"],
                "selection":"First active repeat-zero present case per type, checked before consulting scores.",
                "rows":cards})


if __name__=="__main__":
    main()
    native()
