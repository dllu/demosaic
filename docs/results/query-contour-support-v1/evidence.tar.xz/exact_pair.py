"""Supply true center geometry as a diagnostic for the eight side occlusions."""
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from contour import ARMS,ROOT,estimate,guide_tensor
from run_restore import ARGS,observations
import score


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    original = reference(ROOT/"restoration-fresh.json")
    restored = read_json(checked(original))
    fields = read_json(checked(restored["observations"]))
    plan = read_json(checked(fields["plan"]))
    out = ROOT/"predictions-exact-pair"
    out.mkdir()
    records = []
    started = time.monotonic()
    with ieee_fp32():
        for item in restored["rows"]:
            index=item["index"]
            layout=plan["sources"][index]["layout"]
            if layout["support"]!="occluded":
                continue
            camera=fields["rows"][index]
            with np.load(checked(camera["capture"]),allow_pickle=False)as raw:
                source={k:raw[k]for k in ("packed","colors")}
            values=observations(camera)
            args=[torch.tensor(values[k].reshape((-1,*values[k].shape[2:])),device="cuda")for k in ARGS]
            with np.load(checked(item["output"]),allow_pickle=False)as f:
                base=torch.from_numpy(f["baseline"].reshape(8,3,256,256)).cuda()
            exact=[[*layout[f"{k}_frequency_xy"],layout[f"{k}_tangential_curvature_cycles_per_px2"]]
                   for k in ("strong","weak")]
            orientation=np.zeros((2,4,256,2))
            methods=("strong","weak",*ARMS)
            saved={k:torch.empty_like(base)for k in methods}
            for n in range(8):
                rep,role=divmod(n,4)
                guide=guide_tensor(source["packed"][rep,role],source["colors"][rep,role],plan["query_box"])
                orientation[rep,role]=guide
                correction=estimate([a[n:n+1]for a in args],base[n:n+1],exact,1,guide)
                for k,x in correction.items():
                    saved[k][n:n+1]=x
            with (out/f"{index:03d}.npz").open("xb")as stream:
                np.savez(stream,orientation=orientation,**{k:v.cpu().numpy().reshape(2,4,3,256,256)
                                                          for k,v in (saved|{"baseline":base}).items()})
            records.append({"index":index,"output":reference(out/f"{index:03d}.npz")})
            print(index,round(time.monotonic()-started,2),flush=True)
    receipt=ROOT/"restoration-exact.json"
    write_json(receipt,{"driver":reference(__file__),"observations":restored["observations"],
        "source":original,"checkpoint":plan["base"],"rows":records,
        "scope":"Provide exact frequencies and tangential curvature to the same fits on every role. The aperture, complex phase and amplitude remain measured from RAW."})
    bound=reference(ROOT/"scores.json")
    standard=read_json(checked(bound))
    exact,rows=score.load("exact")
    grouped=[{"index":r["i"],"metrics":{name:score.score(r,name,standard["scale"],standard["uniform_factors"])
               for name in score.METHODS}}for r in rows]
    assert len(grouped)==8
    write_json(ROOT/"exact-scores.json",{"receipt":exact,"standard":bound,"rows":grouped,"results":score.reduce(grouped)})
