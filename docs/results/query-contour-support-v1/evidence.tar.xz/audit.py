"""Independently check aperture geometry, source exclusions and sample separation."""
import importlib.util
import json

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from contour import ARMS,PREV,ROOT,anchored,estimate,guide_tensor,local
from run_restore import ARGS,observations

spec = importlib.util.spec_from_file_location("phase_audit",PREV/"audit.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    source = reference(ROOT/"restoration-fresh.json")
    result = read_json(checked(source))
    prepared = read_json(checked(result["observations"]))
    plan = read_json(checked(prepared["plan"]))
    choices = read_json(checked(result["forecasts"]))
    stamp = read_json(ROOT.parent/"scene-full-epoch-v1"/"plan.json")["train_manifest"]
    with checked(stamp).open()as f:
        catalog = {json.loads(x)["id"]for x in f}
    used = {r["source"]["id"]for r in plan["sources"]}
    assert len(used)==24 and len(catalog)==90692 and not used&catalog
    older = read_json(checked(plan["previous"]))
    assert not used&{r["source"]["id"]for r in older["sources"]}
    query = plan["query_box"]
    x0,y0,_,_ = query
    with anchored((0,0)):
        partition = local.partition()
    held = partition>=2
    yy,xx = np.indices((256,256))
    outside = held[(yy-y0//2)%128,(xx-x0//2)%128]
    pseudo = np.random.default_rng(118241)
    checks = []
    selected = []
    by_kind = {}
    for entry,predict in zip(choices["rows"],result["rows"],strict=True):
        i=entry["index"]
        layout=plan["sources"][i]["layout"]
        kind=layout["support"]
        for case in (c for c in entry["trials"]if c["role"]=="present"and c["geometry"]):
            rep=case["repeat"]
            geometry,weak = case["geometry"],case["weaker"]["index"]
            name=module.identity(geometry,layout)
            selected.append({"index":i,"repeat":rep,"kind":kind,"both_geometry_within_three_DFT_bins":name is not None,
                             "exact_weak":name,"chosen_weak":weak})
            if by_kind.get(kind,0)>=2:
                continue
            by_kind[kind]=by_kind.get(kind,0)+1
            capture=prepared["rows"][i]
            with np.load(checked(capture["capture"]),allow_pickle=False)as raw:
                full=raw["packed"][rep,0].copy()
                color=raw["colors"][rep,0].copy()
            coarse = guide_tensor(full,color,query)
            test=full.copy()
            test[:,outside]=pseudo.uniform(.0,.9,(4,int(outside.sum())))
            np.testing.assert_array_equal(guide_tensor(test,color,query),coarse)
            observed=observations(capture)
            args=[observed[k][rep,0:1].copy()for k in ARGS]
            tensors=[torch.from_numpy(t)for t in args]
            with np.load(checked(predict["output"]),allow_pickle=False)as archive:
                parent=torch.from_numpy(archive["baseline"][rep,0:1].copy())
                np.testing.assert_array_equal(coarse,archive["orientation"][rep,0])
                actual=estimate(tensors,parent,geometry,weak,coarse)
                rounder=estimate(tensors,parent,geometry,weak,np.zeros_like(coarse))
                changed=[t.copy()for t in args]
                for arr in changed[:2]:
                    arr[...,~held]=pseudo.uniform(.01,.9,(1,4,int((~held).sum())))
                same=estimate([torch.from_numpy(t)for t in changed],parent,geometry,weak,coarse)
                residual={}
                for k in ("strong","weak",*ARMS):
                    v=actual[k].numpy()
                    np.testing.assert_array_equal(v,same[k].numpy())
                    np.testing.assert_allclose(v,archive[k][rep,0:1],rtol=0,atol=3e-8)
                    residual[k]=float(np.max(abs(v-archive[k][rep,0:1])))
                for k in ARMS[1:]:
                    np.testing.assert_allclose(rounder[k].numpy(),rounder["wide"].numpy(),rtol=0,atol=3e-8)
                checks.append({"index":i,"repeat":rep,"global_Q2_Q3_replaced_cells":int(outside.sum()),
                               "CPU_GPU_max_absolute":residual,"round_matches_wide":True})
    assert by_kind=={"occluded":1,"contrast":2,"independent":2}
    score=reference(ROOT/"scores.json")
    report=read_json(checked(score))
    assert report["fresh"]==source
    capture = read_json(ROOT/"standing/manifest.json")
    assert capture["parameters"]==score
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"train_manifest":stamp,
              "training_ids":len(catalog),"overlap":0,"prediction_source":source,"scores":score,
              "checks":checks,"present_geometry":selected,"standing":reference(ROOT/"standing/manifest.json"),
              "scope":"Q2/Q3 replacement leaves the full-context coarse guide unchanged. With fixed guide, parent and shape, Q0/Q1 replacement leaves the Bayer fit unchanged."})
    print(len(checks),len(selected),sum(q["both_geometry_within_three_DFT_bins"]for q in selected),
          max(v for x in checks for v in x["CPU_GPU_max_absolute"].values()),flush=True)


if __name__=="__main__":
    main()
