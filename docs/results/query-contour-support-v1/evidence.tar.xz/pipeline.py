"""Bind forecasts and compare scene-contour apertures with the archived wide fit."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from contour import ARMS,PREV,ROOT,estimate,guide_tensor
from forecasts import nominate
from run_restore import ARGS,observations,setup_models


def select():
    captured = reference(ROOT/"fields.json")
    material = read_json(checked(captured))
    saved = []
    with ThreadPoolExecutor(3)as pool:
        for n,result in enumerate(pool.map(nominate,((r,None)for r in material["rows"])),1):
            saved.append(result)
            print("forecasts",n,flush=True)
    write_json(ROOT/"forecasts.json",{"observations":captured,"driver":reference(__file__),
                                    "nomination_code":reference(PREV/"forecasts.py"),"rows":saved})


@torch.inference_mode()
def process(stage):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    older = reference(PREV/"restoration-fit.json")if stage=="fit"else None
    historical = read_json(checked(older))if older else None
    prior = {entry["index"]:entry for entry in historical["rows"]}if older else {}
    selection = historical["forecasts"]if older else reference(ROOT/"forecasts.json")
    selected = read_json(checked(selection))
    data = read_json(checked(selected["observations"]))
    plan = read_json(checked(data["plan"]))
    box = plan["query_box"]
    end = ROOT/f"predictions-{stage}"
    end.mkdir()
    saved = []
    start = time.monotonic()
    with ieee_fp32():
        net = None
        if not older:
            net = setup_models({"models":{"Corpus100k":plan["base"]}})["Corpus100k"]
            net.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for entry in selected["rows"]:
            i = entry["index"]
            row = data["rows"][i]
            assert row["capture"]==entry["capture"]
            with np.load(checked(row["capture"]),allow_pickle=False)as raw:
                full = {k:raw[k]for k in ("packed","colors")}
            camera = observations(row)
            args = [torch.from_numpy(camera[k].reshape((-1,*camera[k].shape[2:]))).cuda()for k in ARGS]
            args[:2] = [t.contiguous(memory_format=torch.channels_last)for t in args[:2]]
            reference_fields = None
            if older:
                with np.load(checked(prior[i]["output"]),allow_pickle=False)as f:
                    parent = torch.tensor(f["baseline"].reshape(8,3,256,256),device="cuda")
                    reference_fields = {k:f[k]for k in ("strong","weak","wide")}
            else:
                parent = net(*args)
            output = {k:torch.zeros_like(parent)for k in ("strong","weak",*ARMS)}
            tensor = np.zeros((2,4,256,2))
            for j,choice in enumerate(entry["trials"]):
                rep,role = divmod(j,4)
                assert choice["repeat"]==rep
                if not choice["geometry"]:
                    continue
                orientation = guide_tensor(full["packed"][rep,role],full["colors"][rep,role],box)
                tensor[rep,role] = orientation
                fields = estimate([p[j:j+1]for p in args],parent[j:j+1],choice["geometry"],
                                  choice["weaker"]["index"],orientation)
                for key,value in fields.items():
                    output[key][j:j+1] = value
            output["baseline"] = parent
            fields = {k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in output.items()}
            if older:
                for k,v in reference_fields.items():
                    np.testing.assert_allclose(fields[k],v,rtol=0,atol=4e-8)
            assert np.isfinite(tensor).all() and all(np.isfinite(v).all()for v in fields.values())
            path = end/f"{i:03d}.npz"
            with path.open("xb")as stream:
                np.savez(stream,**fields,orientation=tensor)
            saved.append({"index":i,"output":reference(path)})
            print(stage,len(saved),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/f"restoration-{stage}.json",{"driver":reference(__file__),"forecasts":selection,
               "checkpoint":plan["base"],"configuration":reference(ROOT/"contour.py"),"older_outputs":older,
               "observations":selected["observations"],"rows":saved,"seconds":time.monotonic()-start})


if __name__=="__main__":
    action=sys.argv[1]
    select()if action=="select"else process(action)
