"""Render the first active native examples across both redraws."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from contour import ARMS,CENTERS,PREV,ROOT
from run_restore import observations
from score_panel import luma

from score import load

def native():
    torch.set_num_threads(2)
    bound = reference(ROOT/"scores.json")
    scorecard = read_json(checked(bound))
    fresh,rows = load("fresh")
    decisions = read_json(ROOT/"forecasts.json")["rows"]
    chosen = [next((r,trial["repeat"])for r in rows if r["source"]["layout"]["support"]==kind
                   for trial in decisions[r["i"]]["trials"]if trial["role"]=="present"and trial["geometry"])
              for kind in ("occluded","contrast","independent")]
    cards = []
    output = ROOT/"native"
    output.mkdir()
    for record,rep in chosen:
        camera = observations(record["capture"])
        with np.load(checked(record["output"]),allow_pickle=False)as data:
            base = data["baseline"][rep]
            rgb = {k:base+scorecard["scale"]*data[k][rep]for k in ARMS}
            rgb["uniform-along"] = base+scorecard["scale"]*(data["strong"][rep]+scorecard["uniform_factors"]["along"]*data["weak"][rep])
        noisy = malvar(torch.from_numpy(camera["packed"][rep]),torch.from_numpy(camera["colors"][rep])).numpy()
        rgb.update({"baseline":base,"noisy":noisy,"GT":camera["target"][rep]})
        transforms = {k:camera[k][rep]for k in ("wb","matrix")}
        rendered = {k:np.rint(display(img,transforms,exposure=2)[...,48:208,48:208]
                    .transpose(0,2,3,1)*255).astype(np.uint8)for k,img in rgb.items()}
        for name,index,names in (
            ("comparison",0,("baseline",*ARMS,"uniform-along","GT")),
            ("triplet",0,("noisy","along","GT")),
            ("outside-only",1,("baseline",*ARMS,"GT")),
            ("quiet",3,("baseline",*ARMS,"GT")),
        ):
            path = output/f"{record['i']:03d}-{name}.png"
            Image.fromarray(np.concatenate([rendered[k][index]for k in names],axis=1)).save(path,optimize=True)
            source = record["source"]
            cards.append({"image":reference(path),"index":record["i"],"kind":source["layout"]["support"],"role":name,
                "source":source["source"],"source_box":source["box"],"ROI":[48,48,160,160],"order":names,
                "camera_profile":{"shot":.00128,"read":6.5536e-6,"capture_exposure":.33},
                "display_exposure":2,"repeat":rep,"CFA":source["camera"]["pattern"],"raw":record["capture"],
                "local_prediction":record["output"]})
    write_json(output/"manifest.json",{"driver":reference(__file__),"scores":bound,"restoration":fresh,
                "checkpoint":read_json(checked(fresh))["checkpoint"],
                "selection":"First present case with active geometry per type, then its first active repeat. The occluded example is repeat one.",
                "rows":cards})



if __name__=="__main__":
    native()
