"""Score saved exact-geometry predictions without rerunning the restoration."""
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from native_views import ROOT,module

bound=reference(ROOT/"scores.json")
comparison=read_json(checked(bound))
receipt,rows=module.load("exact")
output=[{"index":r["i"],"metrics":{name:module.score(r,name,comparison["scale"],comparison["uniform_factors"])
                                  for name in module.METHODS}}for r in rows]
assert len(output)==8
write_json(ROOT/"exact-scores.json",{"driver":reference(__file__),"receipt":receipt,"standard":bound,
                                    "rows":output,"results":module.reduce(output)})
