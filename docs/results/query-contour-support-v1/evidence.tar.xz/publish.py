"""Preserve both native panels and the contour/true-pair numerical diagnostics."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPORT=Path("docs/results/query-contour-support-v1")
IMAGES=Path("docs/images/query-contour-support-v1")


def publish():
    REPORT.mkdir(exist_ok=True)
    reference_scores=reference(ROOT/"scores.json")
    scores=read_json(checked(reference_scores))
    exact=reference(ROOT/"exact-scores.json")
    target=read_json(checked(exact))
    assert target["standard"]==reference_scores
    review=read_json(ROOT/"audit.json")
    camera=read_json(ROOT/"standing/manifest.json")
    native=read_json(ROOT/"native/manifest.json")
    assert native["scores"]==camera["parameters"]==review["scores"]==reference_scores
    assert native["checkpoint"]==camera["checkpoint"]
    groups={"native":native,"standing":camera}
    notes={
      "occluded":"The facade edge is visible. The faint remaining carrier is still easier to see in the exact target, with little visual difference among the fits.",
      "contrast":"The edge and blue-green bar are retained. Both diagonal patterns are stronger in the exact target and the along and across outputs look similar.",
      "independent":"The main diagonal and background shades survive. A faint lattice is easier to see in the target. The compared fits look similar.",
    }
    for key,group in groups.items():
        for row in group["rows"]:
            source=checked(row["image"])
            destination=IMAGES/key/source.name
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,destination)
            assert reference(destination)["sha256"]==row["image"]["sha256"]
            row["image"]={"path":str(destination),"sha256":row["image"]["sha256"]}
            if key=="native":
                if row["role"]=="quiet":
                    row["viewing"]="The flat core is smooth across the outputs."
                elif row["role"]=="outside-only":
                    row["viewing"]="The stronger carrier and foreground step remain visible. Differences between fits are small."
                else:
                    row["viewing"]=notes[row["kind"]]
                boxes=[(160*i,0,160,160)for i in range(len(row["order"]))]
            else:
                ident=row["id"]
                if ident.endswith("mesh-right"):
                    reason="Both available carrier families are visible above the parent. The contour and wide variants look alike. Fine crosses are incomplete under this profile."
                elif ident.endswith("mesh-left"):
                    reason="The restoration equals the parent. Reference cab diamonds remain weak."
                elif "chain-link-fence" in ident:
                    reason="Both coarse crossing directions are retained. The new orientation causes no apparent improvement."
                elif "overcast-sky" in ident:
                    reason="All methods return the same smooth sky as the parent."
                else:
                    reason="All additional fits return the parent. Thin details remain soft."
                row["viewing"]=reason
                boxes=[p["png_xywh"]for p in row["panels"]]
            with Image.open(destination)as f:
                assert all(w==h==160 and x+w<=f.width and y+h<=f.height for x,y,w,h in boxes)
                f.verify()
    assert [len(m["rows"])for m in groups.values()]==[12,8]
    manifest=IMAGES/"manifest.json"
    write_json(manifest,groups|{"actual_native_viewing_complete":True})
    archive=REPORT/"evidence.tar.xz"
    names=("prepare.py","contour.py","pipeline.py","score.py","native_views.py","native-views-initial.py",
           "cameras.py","audit.py","exact_pair.py","score_exact.py","publish.py","plan.json","fields.json",
           "forecasts.json","restoration-fit.json","restoration-fresh.json","scores.json","audit.json",
           "restoration-exact.json","exact-scores.json","native/manifest.json","standing/manifest.json",
           "prepare.log","select.log","fit.log","fresh.log","score.log","native-views.log",
           "native-views-initial.log","cameras.log","audit.log","exact.log","score-exact.log","tests.log")
    with tarfile.open(archive,"x:xz")as f:
        for name in names:
            f.add(ROOT/name,arcname=name)
    maximum={k:max(row["camera_metrics"][k]["camera_RGB_RMS_to_wide_DN16"]
                   for row in camera["rows"])for k in camera["rows"][0]["camera_metrics"]}
    write_json(REPORT/"publication.json",{
        "experiment":"query-contour-support-v1","training_performed":False,"numeric_evaluation_complete":True,
        "actual_native_viewing_complete":True,"checkpoint":native["checkpoint"],
        "scale":scores["scale"],"uniform_factors":scores["uniform_factors"],"groups":scores["groups"],
        "prediction_audit":review,"exact_pair_diagnostic":target["results"],"exact_pair_receipt":exact,
        "max_standing_change_from_wide_RMS_camera_DN16":maximum,"manifest":reference(manifest),"archive":reference(archive),
        "scope":"24 fresh fixed construction fields, both standing GFX families and a supplied-geometry diagnostic. No comparable full427 or measured-camera panel score.",
    })


if __name__=="__main__":
    publish()
