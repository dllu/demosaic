"""Re-evaluate both standing camera scenes on the exact saved RAW and parent RGB."""
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.reporting import display_crop
from contour import ARMS,CURVE,PREV,ROOT,estimate,guide_tensor
from run_restore import ARGS

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

LABELS={"wide":"Wide curved backup","along":"Along scene contours","across":"Across scene contours",
        "uniform-along":"Uniform strength match"}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    stamp = reference(PREV/"forecasts-standing.json")
    linked = read_json(checked(stamp))
    choices = {r["id"]:r for r in linked["rows"]}
    source = reference(CURVE/"standing/manifest.json")
    old = read_json(checked(source))
    baseline_binding = reference(PREV/"standing/manifest.json")
    previous = {r["id"]:r for r in read_json(checked(baseline_binding))["rows"]}
    scores = reference(ROOT/"scores.json")
    parameters = read_json(checked(scores))
    scale = parameters["scale"]
    strength = parameters["uniform_factors"]["along"]
    folder = ROOT/"standing"
    folder.mkdir()
    cards = []
    with ieee_fp32():
        for record in old["rows"]:
            key = record["id"]
            prediction = choices[key]
            box = prediction["window"]
            assert prediction["raw"]==record["noisy_source"] and box==record["fit_box"]
            left,top,_,_ = box
            patch = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            with np.load(checked(prediction["raw"]),allow_pickle=False)as f:
                guide = guide_tensor(f["packed"][0],f["colors"][0],box)
                args = [torch.from_numpy(f[k][patch].copy()if k in ARGS[:2]else f[k])for k in ARGS]
            wb,matrix = args[-2:]
            parent = torch.from_numpy(np.load(checked(record["parent"]),allow_pickle=False)
                                      [...,top:top+256,left:left+256].copy())
            x,y,w,h = record["ROI"]["ROI_xywh"]
            roi = (x-left,y-top,w,h)
            weaker = prediction["weaker"]
            corrected = estimate(args,parent,prediction["geometry"],weaker["index"]if weaker else None,guide)
            views = {k:parent+scale*corrected[k]for k in ARMS}
            views["uniform-along"] = parent+scale*(corrected["strong"]+strength*corrected["weak"])
            with np.load(checked(previous[key]["output"]),allow_pickle=False)as earlier:
                np.testing.assert_array_equal(earlier["wide"],views["wide"].numpy())
            with Image.open(checked(record["image"]))as f:
                image = np.asarray(f.convert("RGB"))
            data = {p["name"]:image[b:b+d,a:a+c]for p in record["panels"]for a,b,c,d in (p["png_xywh"],)}
            expose = record["display_exposure"]
            before = np.rint(display_crop(parent,wb,matrix,roi,exposure=expose)*255).astype(np.uint8)
            np.testing.assert_array_equal(before,data["Parent 100k EMA"])
            panes = [(k,data[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")if k in data]
            metrics = {}
            rx,ry,rw,rh = roi
            sl = np.s_[...,ry:ry+rh,rx:rx+rw]
            for method,value in views.items():
                pixels = np.rint(display_crop(value,wb,matrix,roi,exposure=expose)*255).astype(np.uint8)
                panes.append((LABELS[method],pixels))
                d = (value-views["wide"])[sl].numpy().astype(float)
                metrics[method] = {"camera_RGB_RMS_to_wide_DN16":float(65535*np.sqrt(np.mean(d*d))),
                                   "changed_display_components_vs_parent":int((pixels!=before).sum())}
            panes += [(k,data[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in data]
            result = native_png(folder/(key+".png"),panes)
            output = folder/(key+".npz")
            with output.open("wb")as stream:
                np.savez(stream,parent=parent.numpy(),guide=guide,**{k:v.numpy()for k,v in views.items()})
            cards.append(result|{"id":key,"shot_read":record["noise"],"display_exposure":expose,
                "references":record["references"],"ROI":record["ROI"],"query_box":box,
                "input":prediction["raw"],"parent":record["parent"],"comparison_source":record["image"],
                "output":reference(output),"guide_strength_median":float(np.median(np.linalg.norm(guide,axis=-1))),
                "correction_selected":bool(weaker),"camera_metrics":metrics})
            print(key,{k:round(v["camera_RGB_RMS_to_wide_DN16"],4)for k,v in metrics.items()},flush=True)
    assert len(cards)==8
    write_json(folder/"manifest.json",{"driver":reference(__file__),"selectors":stamp,
         "parameters":scores,"source":source,"wide_archived":baseline_binding,"checkpoint":old["checkpoint"],"rows":cards})


if __name__=="__main__":
    main()
