"""Check geometry recall and the fixed held-quarter gain with known true frequencies."""
from collections import Counter
import importlib.util
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("side_select",ROOT/"select.py")
side=importlib.util.module_from_spec(spec)
spec.loader.exec_module(side)
spec=importlib.util.spec_from_file_location("phase_audit",side.PREVIOUS.parent/"query-phase-support-v1"/"audit.py")
phase=importlib.util.module_from_spec(spec)
spec.loader.exec_module(phase)


def score(fit,evaluate):
    train,u=fit
    test,v=evaluate
    full=np.linalg.solve(train,u)
    values=[]
    for omit in (slice(4,6),slice(6,8)):
        keep=np.ones(8,dtype=bool)
        keep[omit]=False
        null=np.zeros(8)
        null[keep]=np.linalg.solve(train[np.ix_(keep,keep)],u[keep])
        delta=full-null
        norm=np.sqrt(max(1e-20,delta@test@delta))
        values.append(float((2*delta@v+null@test@null-full@test@full)/(2*norm)))
    return values


def main():
    raw_source=reference(ROOT/"geometry-screen.json")
    src=read_json(checked(raw_source))
    forecasts=read_json(checked(src["source"]))
    fixtures=read_json(checked(forecasts["observations"]))
    plan=read_json(checked(fixtures["plan"]))
    x,y,w,h=plan["query_box"]
    counts=Counter()
    given=[]
    for row,request in zip(src["rows"],plan["sources"],strict=True):
        layout=request["layout"]
        kind=layout["support"]
        for d in row["trials"]:
            k=f"{kind}/{d['role']}"
            result=d["result"]
            counts[k+"/trials"]+=1
            counts[k+"/new_accepted"]+=bool(result["accepted"])
            counts[k+"/nominated"]+=bool(result.get("planar"))
            counts[k+"/nominated_within_3_DFT_bins"]+=bool(result.get("planar") and phase.identity(result["planar"],layout)is not None)
        if kind!="occluded":
            continue
        full=checked(row["input"])
        with np.load(full,allow_pickle=False)as f:
            packed=f["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            variance=f["variance"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            colors=f["colors"]
        seeds=[{"frequency_xy":layout[f"{k}_frequency_xy"]}for k in ("strong","weak")]
        yy,xx=np.indices((128,128))*2-127.
        signed=xx*np.cos(layout["foreground_angle"])+yy*np.sin(layout["foreground_angle"])-layout["foreground_shift"]
        true_side=signed < -7.
        for rep in range(2):
            for j,role in enumerate(("present","outside-only","strong-only","quiet-query")):
                with side.anchored((0,0)):
                    records=side.local.green_records(packed[rep,j],variance[rep,j],colors[rep,j])
                    localized=score(*side.moments(records,seeds,true_side,None))
                    global_scores=score(*side.moments(records,seeds,np.ones_like(true_side),None))
                given.append({"index":row["index"],"repeat":rep,"role":role,
                              "measured_phase_Q1_at_exact_side_and_centers":localized,
                              "measured_phase_Q1_at_exact_centers":global_scores})
    output={"driver":reference(__file__),"sweep":raw_source,"automatic":dict(counts),
            "exact_geometry_and_side_diagnostic":given}
    write_json(ROOT/"audit.json",output)
    for role in ("present","outside-only","strong-only","quiet-query"):
        subset=[r for r in given if r["role"]==role]
        print(role,*[sum(min(r[k])>=3.25 for r in subset)for k in (
              "measured_phase_Q1_at_exact_side_and_centers","measured_phase_Q1_at_exact_centers")],flush=True)
    print("Nominal geometry within three bins",[(k,v)for k,v in counts.items()
          if k.endswith("within_3_DFT_bins")and "present" in k],flush=True)


if __name__=="__main__":
    main()
