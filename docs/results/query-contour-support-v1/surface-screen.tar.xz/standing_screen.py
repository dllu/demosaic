"""Apply the fixed surface screen to the same eight standing GFX inputs."""
from pathlib import Path
import importlib.util

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("side_select",ROOT/"select.py")
side=importlib.util.module_from_spec(spec)
spec.loader.exec_module(side)
binding=reference(ROOT.parent/"query-phase-support-v1"/"forecasts-standing.json")
stored=read_json(checked(binding))
rows=[]
for row in stored["rows"]:
    if row["geometry"]:
        choice={"existing_pair":True,"accepted":False}
    else:
        x,y,w,h=row["window"]
        roi=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
        with np.load(checked(row["raw"]),allow_pickle=False)as f:
            choice=side.hypotheses(f["packed"][0][roi],f["variance"][0][roi],f["colors"][0])
    rows.append({"case":row["id"],"raw":row["raw"],"window":row["window"],"result":choice})
    print(row["id"],choice.get("existing_pair"),choice["accepted"],flush=True)
write_json(ROOT/"standing-screen.json",{"driver":reference(__file__),"source":binding,"rows":rows})
