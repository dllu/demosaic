"""Seek one pair on one visible surface, then check it on a reserved Bayer quarter."""
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter,map_coordinates

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/"query-contour-support-v1"
sys.path.insert(0,str(PREVIOUS))
from contour import anchored, local
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def boundary(packed,colors):
    green=packed[np.flatnonzero(colors==1)].mean(0)
    mask=local.partition()==0
    guide=gaussian_filter(np.where(mask,green,0.),2.8)/gaussian_filter(mask.astype(float),2.8)
    theta=np.arange(36)*np.pi/36
    offset=np.arange(-46.,47.,4)
    along=np.linspace(-58,58,33)
    ux,uy=np.cos(theta),np.sin(theta)
    cx=offset[None,:,None]*ux[:,None,None]-along[None,None,:]*uy[:,None,None]
    cy=offset[None,:,None]*uy[:,None,None]+along[None,None,:]*ux[:,None,None]
    sampled=np.stack([map_coordinates(guide,[
        (cy+d*uy[:,None,None]+127.)*.5,(cx+d*ux[:,None,None]+127.)*.5],
        order=1,prefilter=False)for d in (-17,-7,7,17)])
    step=sampled[2]-sampled[1]
    sides=np.maximum(abs((sampled[3]-sampled[2]).mean(-1)),abs((sampled[1]-sampled[0]).mean(-1)))
    value=step.mean(-1)
    contrast=abs(value)
    sharpness=contrast-.75*sides
    wins=(contrast>=.009)&((np.sign(step)*np.sign(value[...,None])>0).mean(-1)>=.8)&(sharpness>=.0045)
    if not wins.any():
        return None
    a,i=np.unravel_index(np.argmax(np.where(wins,sharpness,-np.inf)),wins.shape)
    return float(theta[a]),float(offset[i]),float(value[a,i])


def moments(records,candidates,mask,side):
    yy,xx=np.indices((128,128))
    parts=[[]for _ in (0,1)]
    for tag in (0,1):
        for plane,value,var in records:
            group=(local.partition()==tag)&mask
            x,y=xx[group]*2+plane%2,yy[group]*2+plane//2
            center=(x-127.5)/128,(y-127.5)/128
            sign=1. if plane==records[0][0]else -1.
            nuisance=[np.ones_like(x),*center,np.full_like(x,sign,dtype=float)]
            harmonics=[]
            for row in candidates:
                fx,fy=row["frequency_xy"]
                amp=(x*fx+y*fy)*(2*np.pi)
                harmonics.extend((np.cos(amp),np.sin(amp)))
            spatial=np.exp(-(center[0]**2+center[1]**2)/(2*.56**2))
            weight=np.sqrt(spatial/var[group])
            parts[tag].append((np.column_stack((*nuisance,*harmonics))*weight[:,None],value[group]*weight))
    out=[]
    for fold in parts:
        A=np.concatenate([x for x,_ in fold])
        b=np.concatenate([x for _,x in fold])
        out.append((A.T@A,A.T@b))
    return out


def hypotheses(packed,variance,colors):
    with anchored((0,0)):
        fitted=boundary(packed,colors)
        if fitted is None:
            return {"boundary":None,"accepted":False}
        a,shift,sharp=fitted
        records=local.green_records(packed,variance,colors)
        y,x=np.indices((128,128))*2-127.
        signed=x*np.cos(a)+y*np.sin(a)-shift
        proposals=[]
        for side in (-1,1):
            mask=side*signed>=7.
            taper=((side*signed-5)/15).clip(0,1)
            localized=[(q,v*taper,n*taper**2)for q,v,n in records]
            seeds=local.local_bank(localized)
            if len(seeds)<2:
                continue
            (train,raw),(reserved,witness)=moments(records,seeds,mask,side)
            common=list(range(4))
            for i,j in combinations(range(len(seeds)),2):
                first,second=(np.asarray(seeds[n]["frequency_xy"])for n in (i,j))
                separation=abs(first[0]*second[1]-first[1]*second[0])/(np.linalg.norm(first)*np.linalg.norm(second))
                if separation<.35:
                    continue
                selection=common+[4+2*i,5+2*i,4+2*j,5+2*j]
                matrix=train[np.ix_(selection,selection)]
                response=raw[selection]
                beta=np.linalg.solve(matrix,response)
                if not np.isfinite(beta).all():
                    continue
                norms=[]
                delta=[]
                for remove in (slice(4,6),slice(6,8)):
                    keep=np.ones(8,dtype=bool)
                    keep[remove]=False
                    controlled=np.zeros(8)
                    controlled[keep]=np.linalg.solve(matrix[np.ix_(keep,keep)],response[keep])
                    difference=beta-controlled
                    delta.append((controlled,difference))
                    norms.append(float(np.sqrt(max(0,difference@matrix@difference))))
                if min(norms)<3.5:
                    continue
                proposals.append((sum(norms),min(norms),side,i,j,first,second,
                                  beta,delta,reserved[np.ix_(selection,selection)],witness[selection]))
        if not proposals:
            return {"boundary":fitted,"accepted":False}
        _,_,side,i,j,first,second,beta,delta,reserved,witness=max(proposals,key=lambda v:v[:5])
        checks=[]
        for null,change in delta:
            norm=np.sqrt(max(1e-20,change@reserved@change))
            score=(2*change@witness+null@reserved@null-beta@reserved@beta)/(2*norm)
            checks.append(float(score))
        return {"boundary":fitted,"accepted":min(checks)>=3.25,"side":side,
                "conditional_Q1":checks,"planar":[[*first,0.],[*second,0.]]}


def main():
    source=reference(PREVIOUS/"forecasts.json")
    review=read_json(checked(source))
    material=read_json(checked(review["observations"]))
    plan=read_json(checked(material["plan"]))
    x,y,w,h=plan["query_box"]
    observations=[]
    for r in review["rows"]:
        with np.load(checked(r["capture"]),allow_pickle=False)as f:
            packed=f["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            variance=f["variance"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            colors=f["colors"]
        tests=[]
        for j,t in enumerate(r["trials"]):
            repeat,role=divmod(j,4)
            if t["geometry"]:
                result={"accepted":False,"existing_pair":True}
            else:
                result=hypotheses(packed[repeat,role],variance[repeat,role],colors[repeat,role])
            tests.append({"repeat":repeat,"role":t["role"],"result":result})
        observations.append({"index":r["index"],"trials":tests,"input":r["capture"]})
        print(r["index"],[t["role"]for t in tests if t["result"]["accepted"]],flush=True)
    write_json(ROOT/"geometry-screen.json",{"driver":reference(__file__),"source":source,"rows":observations,
        "scope":"Exploratory replay on the previous contour photo fields. Select one side/pair using Q0 and apply one fixed Q1 evaluation."})


if __name__=="__main__":
    main()
