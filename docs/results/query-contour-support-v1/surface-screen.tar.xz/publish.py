"""Package the measured-side and exact-side geometry diagnostics."""
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
OUTPUT=Path("docs/results/query-contour-support-v1")

audit=reference(ROOT/"audit.json")
result=read_json(checked(audit))
cameras=reference(ROOT/"standing-screen.json")
standing=read_json(checked(cameras))
assert len(standing["rows"])==8
assert all(not sample["result"]["accepted"]for sample in standing["rows"])
sweep=result["automatic"]
assert len(sweep)==48
assert not any(v for k,v in sweep.items()if k.endswith("/new_accepted"))
archive=OUTPUT/"surface-screen.tar.xz"
with tarfile.open(archive,"x:xz")as f:
    for name in ("select.py","audit.py","standing_screen.py","publish.py","geometry-screen.json","audit.json",
                 "standing-screen.json","select.log","audit.log","standing-screen.log"):
        f.add(ROOT/name,arcname=name)
write_json(OUTPUT/"surface-screen.json",{
    "scope":"Exploratory evaluation of one candidate per observation on the contour panel and its standing cameras. Zero new corrections delivered.",
    "data":result,"audit":audit,"standing":standing,"standing_receipt":cameras,"archive":reference(archive),
})
