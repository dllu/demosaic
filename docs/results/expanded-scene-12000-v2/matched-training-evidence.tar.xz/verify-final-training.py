"""Check the completed 12k endpoints and freeze their compact training receipts."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
matched = root / "matched-training.json"
training = read_json(matched)
plan = read_json(checked(training["plan"]))
assert training["trained"] and not training["numerically_evaluated"] and not training["native_viewed"]
assert plan["steps"] == 12000 and plan["crops_per_scene"] == 4
durations = {}
for k in ("none", "spatial"):
    endpoint = training["endpoints"][k]
    source = read_json(checked(endpoint["result"]))
    assert source["mode"] == k and source["steps"] == 12000 and source["DINO_unchanged"]
    assert endpoint["EMA"] == source["checkpoints"][-1]
    checked(endpoint["EMA"])
    durations[k] = source["seconds"]
left, right = [checked(ref) for ref in training["shared_observation_traces"]]
order_path = checked(plan["photo_epoch_order"])
order = read_json(order_path)["order"]
indices = np.load(checked(order | {"path": str(order_path.parent / order["path"])}), allow_pickle=False)
with checked(plan["train_manifest"]).open() as f:
    id_order = [json.loads(line)["id"] for line in f]
assert len(indices) == 24_000 and len(id_order) == 90_692
selected = set()
count = 0
with left.open("rb") as a, right.open("rb") as b:
    for index, (first, second, choice) in enumerate(zip(a, b, indices, strict=True)):
        assert first == second
        row = json.loads(first)
        assert row["index"] == index and row["source_id"] == id_order[choice]
        selected.add(row["source_id"])
        assert len(row["boxes_xywh"]) == 4
        assert row["crop_fingerprints"] and all(fp["shape"][0] == 4 for fp in row["crop_fingerprints"].values())
        count += len(row["boxes_xywh"])
assert len(selected) == 24_000 and count == 96_000

output = repo / "docs" / "results" / "expanded-scene-12000-v2"
original = output / "matched-training.json"
shutil.copyfile(matched, original)
files = {name: root / name for name in ("verify-final-training.py", "verify-final-training-first.py", "verify-final-training-first.log", "plan.json", "launch.json", "run.py", "matched-training.json",
         "none/completed.json", "spatial/completed.json", "none-exit.json", "spatial-exit.json", "spatial-launch.json")}
archive = output / "matched-training-evidence.tar.xz"
with tarfile.open(archive, "x:xz") as f:
    for name, path in files.items():
        f.add(path, arcname=name)
with tarfile.open(archive, "r:xz") as f:
    for name, path in files.items():
        assert hashlib.sha256(f.extractfile(name).read()).hexdigest() == reference(path)["sha256"]


def repository_path(path):
    return reference(path) | {"path": str(path.relative_to(repo))}


write_json(output / "training-completion.json", {"record": repository_path(original), "archive": repository_path(archive),
    "verified_sources": {name: reference(path) for name, path in files.items()}, "training_seconds": durations,
    "checkpoint_weights": "Both checkpoint files contain raw and EMA weights. Subsequent inference uses EMA.",
    "training_complete": True, "broad_evaluation_complete": False, "spatial_native_viewed": False,
    "verified_distinct_scenes_per_arm": len(selected), "verified_native_crops_per_arm": count,
    "planned_reviews": {k: reference(root.parent / k / "observe.py") for k in (
                         "expanded-scene-12000-native-v1", "expanded-scene-12000-primary-v1", "scene-wire-gap-12k-v1")}})
