"""Freeze completed fixed camera panels and native viewing before full427 closes."""

import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root=Path(__file__).resolve().parent
producer=root.parent
repo=producer.parents[2]
published=repo/'docs/results/expanded-scene-12000-v2'
images=repo/'docs/images/expanded-scene-12000-primary-camera-v1'
images.mkdir()
plan_file=producer/'full-plan.json'
plan=read_json(plan_file)
completed=read_json(producer/'full/progress.json')
assert completed['completed_cases']>=54
prior=read_json(repo/'docs/results/full-corpus-long100k-camera-v1/publication.json')
with tarfile.open(checked(prior['archive'])) as bundle:
    import json
    prior_panels={stage:json.load(bundle.extractfile(f'{stage}/analysis.json'))for stage in ('known','unseen')}
models=plan['models']
assert set(models)=={'V120','parent100k','none','spatial'}


def portable(p):
    return reference(p)|{'path':str(p.relative_to(repo))}


viewed={
 'known-2pilesofplates':'All four denoised crops keep the same quiet gray gradient and soft lower boundary.',
 'known-7D-1':'The raised texture near the diagonal edge stays visible at similar contrast, with fine ridges soft in all four methods.',
 'known-MuseeL-CopteArch-C500D':'Faint irregular texture remains soft. Changes across the learned methods are subtle at native size.',
 'known-D60-2':'Broad vertical streaks and the diagonal boundary persist, with fine texture attenuated in every arm.',
 'unseen-LucieB_3apples':'Text and the diagonal edge retain similar shapes and edge softness across the reconstructions.',
 'unseen-LucieB_Coulicoco':'The brown field stays nearly smooth in all four learned predictions.',
 'unseen-LucieB_bedroom_tapestry':'Faint mottled colored features persist. Some fine texture visible in the independent AHD stays soft.',
 'unseen-LucieB_stick_figurine':'Dark reddish surface looks close across all four methods, with soft mottling and little fine structure.',
 'unseen-LucieB_top_of_Expedit':'All four outputs keep the field quiet, with weak diagonal variation softer than in the AHD reference.',
}
files={n:root/n for n in ('analyze_scene_primary_cameras.py','render_scene_primary_cameras.py','close-camera.sh','known.log','close.log','publish.py','publish-first.py')}
files['full-plan.json']=plan_file
panel_info={}; views=[]
for stage,n,scenes in (('known',24,4),('unseen',30,5)):
    source=root/stage/'result.json'
    data=read_json(source)
    assert data['weights']=='EMA' and data['models']==models
    assert len(data['cases'])==n and len(data['per_scene'])==scenes*len(models)
    assert len(data['metric_checks'])==n*len(models) and all(x['scores_bit_exact'] for x in data['metric_checks'])
    assert sum(x['native_predictions'] for x in data['metric_checks'])==scenes*18*len(models)
    assert data['plan']==reference(plan_file)
    out={r['model']: {k:m['mean'] for k,m in r['metrics'].items()} for r in data['summary']['overall']}
    legacy=prior_panels[stage]
    assert len(legacy['cases'])==len(data['cases'])
    for former, current in zip(legacy['cases'], data['cases'], strict=True):
        x,y=(read_json(checked(r))for r in (former,current))
        assert (x['stage'],x['batch'],x['canonical_arrays'])==(y['stage'],y['batch'],y['canonical_arrays'])
    drift={}
    for arm,reference_arm in (('V120','V120'),('parent100k','scale-long100k')):
        comparison=prior['results'][stage]['overall'][reference_arm]['sensor_psnr']
        assert models[arm]['checkpoint']==legacy['models'][reference_arm]['checkpoint']
        drift[arm]=out[arm]['sensor_psnr']-comparison
        assert abs(drift[arm])<1e-6,(stage,arm,comparison)
    render=root/f'{stage}-native'/'result.json'
    gallery=read_json(render)
    assert len(gallery['boards'])==scenes
    for row in gallery['boards']:
        p=checked(row['image']);dest=images/p.name
        shutil.copyfile(p,dest)
        with Image.open(dest) as f:
            assert all((w,h)==(160,160) and 0<=x<=f.width-w and 0<=y<=f.height-h
                       for x,y,w,h in (m['png_xywh'] for m in row['panels']))
        bound=portable(dest)
        assert bound['sha256']==row['image']['sha256']
        views.append({**row,'image':bound,'stage':stage,'actual_viewing':viewed[row['id']]})
    files[f'{stage}/analysis.json']=source
    files[f'{stage}/per-crop.csv']=checked(data['per_crop'])
    files[f'{stage}/render.json']=render
    for ref in data['cases']:
        p=checked(ref); c=read_json(p)
        files[f'{stage}/case-{c["batch"]:05d}.json']=p
    panel_info[stage]={'batches':n,'scenes':scenes,'crops_per_model':scenes*18,'overall':out,
        'analysis':reference(source),'difference_from_prior_CPU_controls':drift,'native_views_verified':len(gallery['boards'])}
assert len(views)==9
view=published/'matched-primary-camera-viewing.json'
write_json(view,{'recorded_utc':datetime.now(UTC).isoformat(),'models':models,'native_viewed':True,'boards':views})
files['native-viewing.json']=view
archive=published/'matched-primary-cameras.tar.xz'
with tarfile.open(archive,'x:xz',preset=4) as bundle:
    for key,path in files.items():bundle.add(path,arcname=key)
with tarfile.open(archive,'r:xz') as bundle:
    for key,path in files.items():
        assert hashlib.sha256(bundle.extractfile(key).read()).hexdigest()==reference(path)['sha256']
write_json(published/'matched-primary-cameras.json',{
    'archive':portable(archive),'viewing':portable(view),'panels':panel_info,'models':models,'weights':'EMA',
    'complete_camera_panels':True,'complete_full427':False,'plan':reference(plan_file),'canonical_inputs':plan['canonical_inputs'],
    'prior_controls':portable(repo/'docs/results/full-corpus-long100k-camera-v1/publication.json'),
    'files':{k:reference(v)for k,v in files.items()},'complete_native_review':True,
    'scope':'Complete known and unseen fixed camera panels. All measured-CFA scores recomputed bit-exact from saved native predictions with matching checkpoints, input arrays and measured sensor masks. V120 and Corpus 100k use identical checkpoint and input bindings and agree with their existing CPU means to within 1e-6 dB. Nine first-crop boards viewed, with independent AHD as an auxiliary reference. The photo collection remains in progress.'})
