#!/bin/bash
set -euo pipefail
run_root="$1"
repo_root="$2"
python_path="$repo_root/.venv/bin/python"
observer="$run_root/camera-only"
producer_pid="$($python_path -c 'import json,sys; print(json.load(open(sys.argv[1]))["pid"])' "$run_root/full-launch.json")"
while [[ ! -f "$run_root/full/unseen-00029/result.json" ]]; do
    kill -0 "$producer_pid" 2>/dev/null || exit 1
    sleep 5
done
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
$python_path "$observer/analyze_scene_primary_cameras.py" "$run_root" unseen "$observer/unseen"
for panel in known unseen; do
    $python_path "$observer/render_scene_primary_cameras.py" "$observer/$panel/result.json" "$observer/$panel-native"
done
