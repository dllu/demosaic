"""Execute and audit both fixed whole-scene training arms after qualification."""

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import exclusive_run, owner_identity

ROOT = Path(__file__).resolve().parent


def child(plan, name, args):
    work=Path(plan["work"])
    driver=checked(plan["training_script"])
    env=dict(os.environ,PYTHONPATH=f"{work}/src:{work}/scripts",OPENBLAS_NUM_THREADS="1",
             OMP_NUM_THREADS="2",MKL_NUM_THREADS="2",PYTHONUNBUFFERED="1")
    env.pop("CUDA_VISIBLE_DEVICES",None)
    command=[sys.executable,str(driver),*map(str,args)]
    with (ROOT/f"{name}.log").open("xb") as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        receipt={"pid":process.pid,"created":psutil.Process(process.pid).create_time(),"command":command}
        write_json(ROOT/f"{name}-launch.json",receipt)
        write_json(ROOT/"status.json",{"stage":name,"owner":owner_identity(),"child":receipt},replace=True)
        code=process.wait()
    write_json(ROOT/f"{name}-exit.json",{"returncode":code})
    if code:
        raise RuntimeError(f"{name} worker exited with {code}; see its original log")


def resources(plan):
    while (
        psutil.virtual_memory().available < plan["minimum_start_RAM_GiB"] * 2**30
        or shutil.disk_usage(ROOT).free < plan["minimum_disk_GiB"] * 2**30
    ):
        write_json(ROOT/"status.json",{"stage":"resource-wait","owner":owner_identity()},replace=True)
        time.sleep(20)


def audit(plan_path, plan):
    records=[]
    endings={}
    for arm in plan["modes"]:
        path=ROOT/arm/"completed.json"
        result=read_json(path)
        assert result["steps"]==plan["steps"] and result["mode"]==arm and result["DINO_unchanged"]
        assert result["plan"]==reference(plan_path)
        endings[arm]={"result":reference(path),"EMA":reference(checked(result["checkpoints"][-1]))}
        records.append(result["observations"])
    assert len(records)==2 and records[0]["sha256"]==records[1]["sha256"]
    left=checked(records[0])
    order_path=checked(plan["photo_epoch_order"])
    order=read_json(order_path)
    indices=np.load(checked(order["order"] | {"path":str(order_path.parent/order["order"]["path"])}))
    with checked(plan["train_manifest"]).open() as manifest:
        ids=[json.loads(line)["id"] for line in manifest]
    with left.open() as stream:
        for index, (line, row) in enumerate(zip(stream,indices,strict=True)):
            actual=json.loads(line)
            assert actual["source_id"]==ids[row],index
    write_json(ROOT/"matched-training.json",{
        "plan":reference(plan_path),"endpoints":endings,"shared_observation_traces":records,
        "actual_scene_draws_per_arm":len(indices),"actual_distinct_scene_ids_per_arm":len(np.unique(indices)),
        "native_examples_per_arm":len(indices)*plan["crops_per_scene"],
        "trained":True,"numerically_evaluated":False,"native_viewed":False,
    })
    write_json(ROOT/"status.json",{"stage":"trained","owner":owner_identity()},replace=True)


def main():
    with exclusive_run(ROOT):
        plan_path=ROOT/"plan.json"
        plan=read_json(plan_path)
        verify_plan(plan)
        resources(plan)
        destination=ROOT/"preflight"
        child(plan,"preflight",["preflight",plan_path,destination])
        preflight=read_json(destination/"result.json")
        assert preflight["all_modes_passed"] and preflight["plan"]==reference(plan_path)
        controls, spatial=preflight["results"]
        assert controls["mode"]=="none" and spatial["mode"]=="spatial"
        assert controls["discarded_updates"]==spatial["discarded_updates"]==2
        assert controls["training_observations"]==spatial["training_observations"]
        for arm in plan["modes"]:
            resources(plan)
            child(plan,arm,["train",plan_path,ROOT/arm,"--mode",arm])
        audit(plan_path,plan)


if __name__=="__main__":
    main()
