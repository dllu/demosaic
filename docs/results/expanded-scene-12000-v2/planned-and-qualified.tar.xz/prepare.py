"""Bind a larger original-corpus scene continuation from the trained 100k EMA."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "expanded-scene-epoch-corpus-v1"
PARENT = Path("docs/results/full-corpus-long100k-training-v1/endpoint-admission.json")
STEPS = 12_000


def prepare():
    old = read_json(PREVIOUS/"plan.json")
    admission = read_json(PARENT)
    assert admission["trained"] and admission["model"]["step"]==100_000
    parent = admission["model"]["checkpoint"]
    checked(parent)
    source = checked(old["photo_epoch_order"])
    header = read_json(source)
    payload = dict(header["order"])
    payload["path"] = str(source.parent/payload["path"])
    scheduled = np.load(checked(payload), allow_pickle=False)
    scenes = old["scenes_per_step"]
    planned = scheduled[:STEPS*scenes].copy()
    assert scenes==2 and len(planned)==len(set(planned))==24_000
    order = ROOT/"photo-order"
    order.mkdir()
    order_file = order/"ordinary-photo-order.npy"
    with order_file.open("xb") as stream:
        np.save(stream, planned, allow_pickle=False)
    order_header = order/"photo-epoch-order.json"
    write_json(order_header, header | {
        "horizon_steps": STEPS,
        "order":{"path":order_file.name,"sha256":reference(order_file)["sha256"]},
        "prefix_source":reference(source),
    })
    work, files = freeze_sources(Path.cwd(), ROOT, ["train_scene_context.py"])
    driver = work/"scripts/train_scene_context.py"
    failed=ROOT.parent/"expanded-scene-12000-v1"
    assert read_json(failed/"preflight-exit.json")["returncode"]!=0
    assert "declared SHA256" in (failed/"preflight.log").read_text()
    history=[reference(failed/item) for item in ("plan.json","preflight.log","preflight-exit.json","controller.log")]
    write_json(ROOT/"plan.json",old | {
        "steps":STEPS,"root":str(ROOT),"work":str(work),"frozen_files":files,"parent":parent,
        "modes":["none","spatial"],"training_script":reference(driver),
        "base_lr":3e-6,"checkpoint_every":3000,"log_every":50,"maximum_GPU_GiB":12,
        "maximum_arm_seconds":21600,"photo_epoch_order":reference(order_header),
        "inputs":[*history,reference(PREVIOUS/"plan.json"),reference(PREVIOUS/"audit.json"),reference(source),reference(PARENT),
                  reference(__file__),reference(order_header),reference(order_file),parent,
                  old["train_manifest"],old["development_manifest"]],
        "scientific_primary":"Matched local-only versus aligned spatial complete-scene features. Each arm starts from the exact restored 100k EMA and independently initializes a zero-output scene adapter.",
        "evaluation_limits":"The earlier 64 scene development sources are outside this continuation, but the 100k parent saw them. A source-disjoint quality claim requires canonical held-out photos and fresh constructed controls. Both standing GFX families and their siblings are excluded.",
        "scope":"12k updates per arm, eight native bin4 crops per update from two independently corrupted complete noisy scenes. Fixed common source order is the first 24,000 distinct photos of the admitted 90,692-source shuffled order.",
    })
    print("Bound",len(planned),"distinct scenes and",len(planned)*old["crops_per_scene"],"native crops per arm")


if __name__=="__main__":
    prepare()
