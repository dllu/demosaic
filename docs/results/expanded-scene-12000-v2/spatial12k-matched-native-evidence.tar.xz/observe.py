"""Bind and collect standing native and held-out scene comparisons for both arms."""

import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

ROOT=Path(__file__).resolve().parent
TRAIN=ROOT.parent/"expanded-scene-12000-v2"
HISTORICAL=ROOT.parent/"scene-context-native-review-v2"


def run_child(work, driver, plan, arm):
    command=[sys.executable,str(driver),str(plan),arm]
    env=dict(os.environ,CUDA_VISIBLE_DEVICES="",
             PYTHONPATH=f"{work}/src:{work}/scripts",OMP_NUM_THREADS="2",OPENBLAS_NUM_THREADS="1")
    with (ROOT/f"{arm}.log").open("xb") as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
        write_json(ROOT/f"{arm}-launch.json",{"command":command,"pid":child.pid,
                       "created":psutil.Process(child.pid).create_time()})
        code=child.wait()
    write_json(ROOT/f"{arm}-exit.json",{"returncode":code})
    if code:
        raise RuntimeError(f"Native {arm} exited with {code}")


def verify_inputs(report, checks):
    assert len(report["records"])==len(checks)==10
    for a,b in zip(report["records"],checks,strict=True):
        assert a["id"]==b["id"] and a["input_fingerprints"]==b["input_fingerprints"]
        checked(a["prediction"])


def prepare():
    earlier=HISTORICAL/"plan.json"
    template=read_json(earlier)
    assert len(template["observations"])==10
    train=TRAIN/"plan.json"
    now=read_json(train)
    work,sources=freeze_sources(Path.cwd(),ROOT,["review_scene_context_native.py"])
    driver=work/"scripts/review_scene_context_native.py"
    binds=[reference(earlier),reference(train),reference(__file__),reference(TRAIN/"launch.json")]
    binds.extend(o["arrays"] for o in template["observations"])
    binds.extend(template[k] for k in ("main_full_RAW","mesh_full_RAW","baseline_collection"))
    for binding in binds:
        checked(binding)
    path=ROOT/"plan.json"
    write_json(path,template | {
        "root":str(ROOT),"training_plan":reference(train),"training_output_root":str(TRAIN),
        "parent":now["parent"],"sources":sources|{r["path"]:r["sha256"] for r in binds},
        "script":reference(driver),"CPU_affinity":[12,13],
        "scope":"Same archived observations, both standing GFX families and older scene development cases. Development sources may overlap the 100k parent's exposure. Fixed full427, camera and independently constructed wire/gap evidence are separate.",
    })
    return work,driver,path,template


def main():
    with exclusive_run(ROOT):
        work,driver,path,template=prepare()
        checks=read_json(checked(template["baseline_collection"]))["records"]
        run_child(work,driver,path,"parent")
        verify_inputs(read_json(ROOT/"parent/collection.json"),checks)
        marker=TRAIN/"matched-training.json"
        owner=read_json(TRAIN/"launch.json")
        while not marker.is_file():
            if not owner_live(owner):
                raise RuntimeError("Training exited without the matched endpoint receipt")
            time.sleep(15)
        trained=read_json(marker)
        assert trained["trained"] and trained["actual_distinct_scene_ids_per_arm"]==24_000
        reports={}
        for arm in ("none","spatial"):
            run_child(work,driver,path,arm)
            receipt=ROOT/arm/"collection.json"
            report=read_json(receipt)
            verify_inputs(report,checks)
            assert report["checkpoint"]["sha256"]==trained["endpoints"][arm]["EMA"]["sha256"]
            reports[arm]=reference(receipt)
        write_json(ROOT/"collection.json",{"plan":reference(path),"training":reference(marker),
            "V120":template["baseline_collection"],"parent":reference(ROOT/"parent/collection.json"),
            "epochs":reports,"numeric_complete":False,"native_viewed":False})


if __name__=="__main__":
    main()
