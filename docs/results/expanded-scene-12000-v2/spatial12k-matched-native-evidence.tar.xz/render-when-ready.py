"""Render bound native comparisons after both models finish their collections."""
import os
import subprocess
import sys
import time
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

root = Path(__file__).resolve().parent
os.sched_setaffinity(0, [12, 13])
os.nice(12)
owner = read_json(root / "launch.json")
while not (root / "collection.json").is_file():
    if not owner_live(owner):
        if (root / "collection.json").is_file():
            break
        raise RuntimeError("The native observer exited before binding both collections")
    time.sleep(12)
subprocess.run([sys.executable, str(root / "render.py")], check=True)
write_json(root / "render-completed.json", {"driver": reference(__file__), "machine_boards": reference(root / "render" / "result.json"), "actual_native_viewing_pending": True})
