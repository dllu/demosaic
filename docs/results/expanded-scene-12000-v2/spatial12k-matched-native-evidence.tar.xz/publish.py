"""Publish the completed matched native boards with a separate viewing record."""
import hashlib
import shutil
import tarfile
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
images = repo/'docs/images/expanded-scene-spatial12k-v1'
out = repo/'docs/results/expanded-scene-12000-v2'
raw = read_json(root/'collection.json')
summary = read_json(root/'render/result.json')
viewing = read_json(root/'actual-viewing.json')
plan = read_json(checked(raw['plan']))
train = read_json(checked(raw['training']))
assert train['trained'] and train['native_examples_per_arm']==96000
assert summary['matched_training']==raw['training']
assert set(summary['collections'])=={'V120','parent100k','none','spatial'}
all_collections = {arm:read_json(checked(ref)) for arm,ref in summary['collections'].items()}
for arm in ('none','spatial'):
    assert all_collections[arm]['checkpoint']==train['endpoints'][arm]['EMA']
    assert all_collections[arm]['weights']=='EMA'
    assert len(all_collections[arm]['records'])==10
    assert all_collections[arm]['counts']=={'root':10,'encoder':16 if arm=='spatial' else 10}
for arm, collection in all_collections.items():
    if arm=='V120':
        continue
    for a,b in zip(all_collections['V120']['records'],collection['records'],strict=True):
        assert a['id']==b['id'] and a['input_fingerprints']==b['input_fingerprints']
        checked(b['prediction'])


def portable(p):
    return reference(p) | {'path':str(p.relative_to(repo))}


def publish(source, panels=None):
    p = checked(source)
    dest = images/p.name
    shutil.copyfile(p,dest)
    assert reference(dest)['sha256']==source['sha256']
    if panels:
        with Image.open(dest) as im:
            for panel in panels:
                x,y,w,h = panel['png_xywh']
                assert (w,h)==(160,160) and x+w<=im.width and y+h<=im.height
    return portable(dest)


matching = {'development-0-shadows-crop0','development-1-iso12800-prior-crop0'}
expected = {r['id'] for r in summary['boards'] if not r['id'].startswith('development-')} | matching
assert len(expected)==10 and set(viewing['notes'])==expected
views = []
for r in summary['boards']:
    if r['id'] in expected:
        views.append(r | {'image':publish(r['image'],r['panels']), 'actual_viewing':viewing['notes'][r['id']]})
triplets = [r | {'image':publish(r['image']), 'metadata':publish(r['metadata'])} for r in summary['triplets'] if r['id'] in matching]
assert len(triplets)==2 and len(views)==10
fields = {arm: {row['id']: row['prediction'] for row in run['records']} for arm,run in all_collections.items()}
for board in views:
    if board['id'].startswith('development-'):
        continue
    x,y,w,h = board['case']['ROI_xywh']
    crops = {arm:np.load(checked(records[board['observation']]),allow_pickle=False)[0,:,y:y+h,x:x+w].astype(float)
             for arm,records in fields.items()}
    board['comparison_rms_DN16'] = {arm:float(np.sqrt(np.mean((crops['spatial'] - crops[arm])**2))*65535)
                                    for arm in ('V120','parent100k','none')}
files = {name:root/name for name in ('plan.json','observe.py','render-when-ready.py','render.py','publish.py','render-completed.json','collection.json',
     'render/result.json','actual-viewing.json','none.log','spatial.log','none-launch.json','spatial-launch.json','none-exit.json','spatial-exit.json')}
for name in ('none','spatial','parent'):
    files[name+'/collection.json']=root/name/'collection.json'
bundle=out/'spatial12k-matched-native-evidence.tar.xz'
with tarfile.open(bundle,'x:xz') as tar:
    for name,p in files.items():
        tar.add(p,arcname=name)
with tarfile.open(bundle,'r:xz') as tar:
    for name,p in files.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==reference(p)['sha256']
write_json(out/'spatial12k-matched-native.json',{
    'archive':portable(bundle), 'archived_originals':{name:reference(p) for name,p in files.items()},
    'training':raw['training'], 'collections':summary['collections'], 'numeric_development_complete':True, 'actual_native_viewed':True,
    'native_CPU_collection_seconds':{arm:all_collections[arm]['seconds'] for arm in ('none','spatial')},
    'development_condition_means':summary['development_condition_means'], 'boards':views, 'triplets':triplets,
    'scope':'Matched V120, 100k, local-only 12k and spatial 12k EMA on identical development and both standing GFX families. Eight real and two exact-reference crops reviewed at native resolution. Photographic score scope is limited to development. ISO100 AHD and camera JPEGs serve as qualitative references.'})
