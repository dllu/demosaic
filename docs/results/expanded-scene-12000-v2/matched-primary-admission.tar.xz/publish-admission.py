"""Publish the canonical qualification and both preserved earlier errors."""
import hashlib
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
out = repo / 'docs/results/expanded-scene-12000-v2'
plan = read_json(root/'full-plan.json')
qualified = read_json(checked(plan['preflight']))
assert qualified['all_complete'] and qualified['cases']==3
assert set(qualified['models'])=={'V120','parent100k','none','spatial'}
assert set(plan['models'])==set(qualified['models'])
for arm,x in qualified['models'].items():
    assert x['weights']=='EMA' and x['checkpoint']==plan['models'][arm]['checkpoint']
seen = set()
for pkg in qualified['case_records']:
    row=read_json(checked(pkg));seen.add((row['stage'],row['batch']))
    assert len(row['variants'])==4
    for variant in row['variants']:
        checked(variant['prediction'])
assert seen=={('known',0),('unseen',0),('photo',16)}
original = {name:root/name for name in ('observe.py','publish-admission.py','preflight.log','preflight-plan.json','preflight-exit.json','preflight-launch.json','preflight/result.json','full-plan.json','full-launch.json')}
original.update({'src/collect_scene_primary.py':checked(plan['driver']), 'src/demosaic/scene_inference.py': root/'work/src/demosaic/scene_inference.py'})
for attempt, receipts in plan['failed_preflights'].items():
    original.update({attempt+'/'+k:checked(v) for k,v in receipts.items()})
archive = out/'matched-primary-admission.tar.xz'
with tarfile.open(archive,'x:xz') as f:
    for n,p in original.items(): f.add(p,arcname=n)
with tarfile.open(archive,'r:xz') as f:
    for n,p in original.items():
        assert hashlib.sha256(f.extractfile(n).read()).hexdigest()==reference(p)['sha256']
write_json(out/'matched-primary-admission.json', {
    'archive':reference(archive)|{'path':str(archive.relative_to(repo))}, 'archive_members':{n:reference(p) for n,p in original.items()},
    'models':qualified['models'], 'qualified_canonical_cases':sorted(seen), 'qualified_checkpoint_bindings':True,
    'full_collection_launched':True, 'broad_scores_complete':False,
    'scope':'Both initial preflight attempts preserve their logs. The corrected inherited collector binds both the independent 100k parent and the scene checkpoint parents to their declared digests. The successful preflight qualifies one known, one unseen and one photo case. Broader metric publication follows only after all fixed panels close.'})
