"""Archive the completed fixed-query intervention and viewed native crops."""
import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
out = repo / 'docs/results/expanded-scene-12000-v2'
images = repo / 'docs/images/expanded-scene-spatial12k-v1'
images.mkdir()
review = read_json(root/'review/result.json')
raw = read_json(checked(review['collection']))
original = read_json(root.parent/'scene-wire-gap-v1/result.json')
assert len(raw['cases']) == len(original['cases']) == 32
for current, old in zip(raw['cases'], original['cases'], strict=True):
    assert current['case'] == old['case']
    assert current['local_fingerprints'] == old['local_fingerprints']
    assert current['context_fingerprints'] == old['context_fingerprints']
    receipt = root/'cases'/(current['case']+'.json')
    assert read_json(receipt) == current
plan = read_json(checked(raw['plan']))
selection = {'iso400-g0-r0-wire-contrast8': ('board', 'triplet'), 'iso400-g4-r0-wire-contrast8': ('board', 'triplet'),
             'iso6400-g4-r0-wire-contrast8': ('board',), 'iso6400-g4-r0-gap': ('board',)}
notes = {
    'iso400-g0-r0-wire-contrast8': 'Strong green wire remains clear. All models render the weak crossing much less distinctly than the exact faint wire.',
    'iso400-g4-r0-wire-contrast8': 'Analogous weak-wire loss with the strong wire running closer to horizontal. No visible guide-specific gain.',
    'iso6400-g4-r0-wire-contrast8': 'Weak wire remains missing. All arms share slight strong-wire distortion and residual background variations.',
    'iso6400-g4-r0-gap': 'No convincing visible extension of the weak line in any arm. The parent has small existing variations in the gray field.',
}

def portable(p):
    return reference(p) | {'path': str(p.relative_to(repo))}

boards = []
for view in review['boards']:
    if view['id'] not in selection:
        continue
    bound = {k: value for k, value in view.items() if k not in ('board', 'triplet')}
    for name in selection[view['id']]:
        orig = view[name]
        path = checked(orig['image'])
        dest = images / path.name
        shutil.copyfile(path, dest)
        assert reference(dest)['sha256'] == orig['image']['sha256']
        with Image.open(dest) as im:
            assert all((w,h) == (160,160) and x+w <= im.width and y+h <= im.height
                       for cell in orig['panels'] for x,y,w,h in [cell['png_xywh']])
        bound[name] = {'image': portable(dest), 'panels': orig['panels']}
    bound['actual_viewing'] = notes[view['id']]
    boards.append(bound)
assert len(boards) == 4
files = {name: root/name for name in ('plan.json','result.json','review/result.json','probe.py','report.py','publish.py','observe.py','completed.json','probe.log','report.log')}
files.update({f'cases/{p.name}': p for p in (root/'cases').glob('*.json')})
archive = out/'spatial12k-wire-gap-evidence.tar.xz'
with tarfile.open(archive, 'x:xz') as f:
    for name, path in files.items():
        f.add(path, arcname=name)
with tarfile.open(archive, 'r:xz') as f:
    for name, path in files.items():
        assert hashlib.sha256(f.extractfile(name).read()).hexdigest() == reference(path)['sha256']
write_json(out/'spatial12k-wire-gap.json', {
    'published_utc': datetime.now(UTC).isoformat(), 'training': plan['matched_training'],
    'pilot': plan['prior_evidence'], 'raw_case_fingerprints_equal_to_pilot': 32,
    'archive': portable(archive), 'archived_originals': {name: reference(p) for name,p in files.items()},
    'scoped_numerical_evaluation_complete': True, 'native_synthetic_crops_viewed': True,
    'standing_GFX_native_viewed': False, 'summary': review['summary'], 'selected_native_boards': boards,
    'scope': 'A causal intervention on fixed synthetic RAW with exact targets. The same 32 pairs and distant previews as the earlier 2k study. Four synthetic scenes inspected across both priors, including both exact-GT triplets published here. No broad photo or camera metrics.',
})
