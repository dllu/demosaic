"""Run the fixed-query whole-scene intervention when matched training closes."""
import os
import subprocess
import sys
import time
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

root = Path(__file__).resolve().parent
train = root.parent / "expanded-scene-12000-v2"
os.sched_setaffinity(0, [12, 13])
os.nice(10)
with exclusive_run(root):
    owner = read_json(train / "launch.json")
    marker = train / "matched-training.json"
    while not marker.is_file():
        if not owner_live(owner) and not marker.is_file():
            raise RuntimeError("Matched training exited before publishing the endpoint receipt")
        time.sleep(12)
    endpoints = read_json(marker)
    for k in ("none", "spatial"):
        checked(endpoints["endpoints"][k]["EMA"])
    for stage in ("probe", "report"):
        with (root / (stage + ".log")).open("xb") as log:
            subprocess.run([sys.executable, str(root / (stage + ".py"))], stdout=log, stderr=subprocess.STDOUT, check=True)
    write_json(root / "completed.json", {"training": reference(marker), "result": reference(root / "review" / "result.json"), "native_viewing_pending": True})
