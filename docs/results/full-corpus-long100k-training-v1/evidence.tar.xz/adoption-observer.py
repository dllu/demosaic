"""Independently audit all executed source and conditioning rows at the 100k endpoint."""

import hashlib
import json
import time
from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
EVAL=ROOT.parent/"full-corpus-long100k-review-v1"
PREVIOUS=Path("docs/results/full-corpus-long86k-native-v1/source-audit.json")
HORIZON=100000


def wait_parent():
    launch=read_json(EVAL/"launch.json")
    path=EVAL/"endpoint-admission.json"
    while not path.is_file():
        p=psutil.Process(launch["pid"])
        assert p.create_time()==launch["create_time"] and p.status()!=psutil.STATUS_ZOMBIE
        time.sleep(10)
    return reference(path)


def intersection(rects):
    return max(0,min(x+w for x,y,w,h in rects)-max(x for x,y,w,h in rects)) * max(
        0,min(y+h for x,y,w,h in rects)-max(y for x,y,w,h in rects),
    )


def exact_area(rects):
    return sum((-1)**(count+1)*sum(intersection(g) for g in combinations(rects,count))
               for count in range(1,len(rects)+1))


def audit(admission):
    lineage=read_json(checked(admission))
    phases=[read_json(checked(lineage[k])) for k in ("first_phase","final_phase")]
    final=phases[-1]
    base=read_json(PREVIOUS)
    end=read_json(EVAL/"plan.json")
    assert base["training_plan"]==end["training_plan"]==final["production_plan"]
    assert base["completed_prefix_updates"]==86000 and final["to_step"]==final["LR_horizon"]==HORIZON
    hash_path=checked(base["order"])
    header=read_json(hash_path)
    order=np.load(checked(header["order"] | {"path":str(hash_path.parent/header["order"]["path"])}))
    with checked(header["source_manifest"]).open() as f:
        native=[r for line in f if (r:=json.loads(line))["split"]=="train"]
    ids=[r["id"] for r in native]
    areas={r["id"]:int(np.prod(r["shape"][:2])) for r in native}
    assert len(ids)==len(set(ids))==90778 and len(order)==HORIZON*16
    boxes=defaultdict(list)
    visits,domains,families=Counter(),Counter(),Counter()
    epochs={}
    traces=[]
    for last,phase,prior in zip((1000,HORIZON),phases,base["source_prefixes"],strict=True):
        binding=phase["source_crop_observations"]
        path=checked(binding)
        assert path==Path(prior["path"])
        digest=hashlib.sha256()
        with path.open("rb") as f:
            for step in range(phase["from_step"]+1,last+1):
                raw=next(f)
                digest.update(raw)
                if step==prior["step"]:
                    assert f.tell()==prior["prefix_bytes"] and digest.hexdigest()==prior["prefix_sha256"]
                row=json.loads(raw)
                pos=(step-1)*16
                assert (row["step"],row["global_draw_start"])==(step,pos)
                seed=hashlib.sha256(f"data:70:{step}".encode()).digest()
                assert row["data_RNG_seed"]==int.from_bytes(seed[:8],"little")%2**63
                domain=row["domain"]
                domains[domain]+=1
                idx=order[pos:pos+16]
                if domain!="commons":
                    assert not row["sources"] and np.all(idx==-1)
                    continue
                for item,k in zip(row["sources"],idx,strict=True):
                    if k==-1:
                        if item["kind"]=="photographic":
                            assert item["reviewed_roi_xywh"] is not None
                            families["reviewed"]+=1
                        else:
                            families["procedural"]+=1
                        continue
                    sid=ids[k]
                    assert item["kind"]=="photographic" and item["reviewed_roi_xywh"] is None
                    assert item["source_id"]==sid and item["draw_seed"]==70+item["draw_index"]
                    assert item["photo_epoch_order_sha256"]==base["order"]["sha256"]
                    boxes[sid].append(tuple(item["cache_xywh"]))
                    families["ordinary"]+=1
                    count=len(boxes[sid])
                    visits[count]+=1
                    if visits[count]==len(ids):
                        epochs[count]=step
            assert not f.read(1)
        assert digest.hexdigest()==binding["sha256"]
        traces.append(binding)
    assert dict(families)==header["summary"]["Commons_families"]
    assert dict(domains)==header["summary"]["domains"]
    assert epochs=={int(k):v for k,v in base["epochs_completed_at_update"].items()}
    sixth={key:rects for key,rects in boxes.items() if len(rects)==6}
    assert len(sixth)==header["summary"]["partial_epoch_draws"]
    sixth_area_deltas=[(exact_area(r)-exact_area(r[:5]))/areas[k] for k,r in sixth.items()]
    assert min(sixth_area_deltas)>=0
    counts=Counter()
    min_signal={}
    files=[]
    start=1
    for phase in phases:
        for pointer in phase["corruption_condition_files"]:
            with np.load(checked(pointer)) as f:
                samples=f["values"]
                n=len(f["steps"])
                np.testing.assert_array_equal(f["steps"],np.arange(start,start+n))
                assert samples.shape==(n,16,14) and np.isfinite(samples).all()
                for name in set(f["domains"]):
                    pair=samples[f["domains"]==name,:,:2].reshape(-1,2).astype(float)
                    assert (pair>=0).all()
                    sigma=np.sqrt(pair.sum(axis=1))*65535*.97
                    counts[name,"all"]+=len(pair)
                    counts[name,"ADC-only"]+=int((sigma==0).sum())
                    counts[name,"0 < sigma <= 8"]+=int(((sigma>0)&(sigma<=8)).sum())
                    positive=sigma[sigma>0]
                    if len(positive):
                        min_signal[name]=min(min_signal.get(name,100000),float(positive.min()))
                start+=n
                files.append(pointer)
    assert start==HORIZON+1 and len(files)==400
    assert sum(v for (k,role),v in counts.items() if role=="all")==HORIZON*16
    receipt=ROOT/"audit.json"
    write_json(receipt,{
        "producer":reference(__file__),"parent_admission":admission,"checkpoint":lineage["model"]["checkpoint"],
        "prefix_from_86k":reference(PREVIOUS),"source_traces":traces,"observed_source_counts":dict(families),
        "completed_epoch_steps":epochs,"photo_draw_histogram":Counter(map(len,boxes.values())),
        "ordinary_distinct":len(boxes),"sixth_ordinary_partial":len(sixth),
        "sixth_added_area_ratio_p10_p50_p90":np.quantile(sixth_area_deltas,[.10,.5,.9]).tolist(),
        "sixth_unchanged_area_count":sum(x==0 for x in sixth_area_deltas),
        "domain_updates":dict(domains),"total_target_slots":HORIZON*16,"conditioning_files":files,
        "actual_noise_profile_counts":{"|".join(k):v for k,v in counts.items()},
        "minimum_positive_sigma_codes_at_reference_black_0p03":min_signal,
        "training_loop_phase_seconds":lineage["train_phase_seconds"],
        "scope":"Full observed training source, condition and timing table. Cached rectangle areas before "
                "augmentation, separated from restored-image quality and inference runtime.",
    })
    print("Audited full 100k:",dict(families),len(sixth),"sixth visits.",flush=True)


if __name__=="__main__":
    audit(wait_parent())
