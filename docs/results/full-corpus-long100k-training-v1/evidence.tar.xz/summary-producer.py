"""Bind the actual trained 100k endpoint and its independent coverage proof."""

import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
EVAL=ROOT.parent/"full-corpus-long100k-review-v1"
DEST=Path("docs/results/full-corpus-long100k-training-v1")


def main():
    admission=read_json(EVAL/"endpoint-admission.json")
    end=read_json(ROOT/"audit.json")
    assert end["parent_admission"]==reference(EVAL/"endpoint-admission.json")
    assert end["checkpoint"]==admission["model"]["checkpoint"]
    assert admission["trained"] and admission["model"]["step"]==100000
    assert end["ordinary_distinct"]==90778 and end["total_target_slots"]==1600000
    DEST.mkdir()
    sources={
        "endpoint-admission.json":EVAL/"endpoint-admission.json",
        "source-audit.json":ROOT/"audit.json",
        "completed-phase.json":checked(admission["final_phase"]),
        "initial-phase.json":checked(admission["first_phase"]),
        "controller-stage.json":checked(admission["stage"]),
        "adoption-observer.py":ROOT/"run-when-ready.py",
        "adoption-observer-launch.json":ROOT/"launch.json",
        "summary-producer.py":Path(__file__),
    }
    for role in ("endpoint-admission.json","source-audit.json"):
        shutil.copyfile(sources[role],DEST/role)
    payload=DEST/"evidence.tar.xz"
    with tarfile.open(payload,"x:xz",preset=6) as f:
        for name,path in sources.items():
            info=f.gettarinfo(path,arcname=name)
            info.mtime=info.uid=info.gid=0
            info.uname=info.gname=""
            with path.open("rb") as s: f.addfile(info,s)
    with tarfile.open(payload) as f:
        assert all(f.extractfile(k).read()==p.read_bytes() for k,p in sources.items())
    receipt={
        "endpoint":reference(DEST/"endpoint-admission.json"),
        "coverage":reference(DEST/"source-audit.json"),
        "evidence":reference(payload),"model":admission["model"],
        "training_completed":True,"source_coverage_audited":True,
        "canonical_benchmark_complete":False,"native_review_complete":False,
    }
    write_json(DEST/"publication.json",receipt)
    print(receipt["model"])
    for k in ("observed_source_counts","photo_draw_histogram","domain_updates","training_loop_phase_seconds",
              "sixth_added_area_ratio_p10_p50_p90","sixth_unchanged_area_count","actual_noise_profile_counts"):
        print(k,end[k])


if __name__=="__main__":
    main()
