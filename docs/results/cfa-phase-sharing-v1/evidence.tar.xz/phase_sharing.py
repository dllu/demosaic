"""Compare green-only and cross-colour phase proposals with held-green scoring."""

import numpy as np

from demosaic._mesh_pooled import (
    _CENTERS,
    _POOLED_FOOTPRINT,
    _POOLED_HALO,
    _SMOOTH,
    _STRIDE,
    _WINDOW,
    _correction,
    _dominant,
    _inverse,
    _measure_nodes,
    _phase_template,
    _rgb,
    _wave,
    _windows,
)
from demosaic.mesh_carrier_fit import _positions, _sites

ARMS = ("weak_only", "open_rank", "shared_phase")
POSITIVE_Z = 2.0
MAX_GAIN = 2.0


def fuse(green, witnesses, direction):
    """Express measured R/B coefficients in green units and combine precisions."""
    green_coeff = green[0][:, direction]
    green_precision = green[1][:, direction]
    green_energy = np.sum(green_coeff**2, axis=1)
    green_noise = 1 / green_precision
    moment = green_precision[:, None] * green_coeff
    precision = green_precision.copy()
    extra_moment = np.zeros_like(moment)
    extra_precision = np.zeros_like(precision)
    ratios = []
    for coefficient, info in witnesses:
        values = coefficient[:, direction]
        noise = 1 / info[:, direction]
        # The cross term has zero mean for independent sensor noise.
        weight = 1 / (noise + green_noise)
        joint = np.einsum("ni,ni->n", green_coeff, values)
        cov = weight @ joint
        signal = weight @ (green_energy - 2 * green_noise)
        # Under vanishing shared response the colour phase is uninformative.
        null_sd = np.sqrt(np.sum(weight**2 * noise * green_energy))
        if cov <= POSITIVE_Z * null_sd or signal <= 0:
            ratios.append(0.0)
            continue
        ratio = min(MAX_GAIN, cov / signal)
        other_precision = info[:, direction]
        extra_moment += (other_precision * ratio)[:, None] * values
        extra_precision += other_precision * ratio**2
        ratios.append(float(ratio))
    # Cap the combined auxiliary weight at the measured green weight.
    cap = np.minimum(1, green_precision / np.maximum(extra_precision, 1e-12))
    precision += extra_precision * cap
    moment += extra_moment * cap[:, None]
    return moment / precision[:, None], precision, ratios


def fields(scene, colors, origin):
    x, y = origin
    all_positions = tuple(np.ndindex(2, 2))
    green = _positions(colors, x, y)
    other = tuple(p for p in all_positions if p not in green)
    chroma = tuple(sorted(other, key=lambda rc: colors[2 * ((y + rc[0]) % 2) + (x + rc[1]) % 2]))
    return (
        green,
        chroma,
        {
            (r, c): _sites(
                scene,
                x - _POOLED_HALO,
                y - _POOLED_HALO,
                _POOLED_FOOTPRINT,
                r,
                c,
            ).astype(np.float64)
            for r, c in all_positions
        },
    )


def template(global_wave, phases, fit_position, witnesses, direction):
    if witnesses:
        coef, info, ratios = fuse(phases[fit_position], [phases[p] for p in witnesses], direction)
    else:
        coeff, precision = phases[fit_position]
        coef, info, ratios = coeff[:, direction], precision[:, direction], []
    field = _phase_template(global_wave[..., direction, :], coef, info)
    return field, ratios


def apply_sharing(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    x, y, w, h = local
    crop = parent[:, y : y + h, x : x + w]
    context = parent[1, y - 16 : y + h + 16, x - 16 : x + w + 16]
    blank = {"weak": None, "direction_rms_DN16": {}, "ratios": {}}
    if peaks is None:
        return {key: crop for key in ARMS}, blank
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    shot, read = noise["shot"], noise["read"]
    greens, chroma, planes = fields(scene, colors, roi[:2])
    global_wave = _wave(_POOLED_FOOTPRINT, peaks)
    terms = {
        pos: _measure_nodes(plane, global_wave, pos, shot, read) for pos, plane in planes.items()
    }
    first, second = (_dominant(*terms[pos]) for pos in greens)
    weak = 1 - first if first is not None and first == second else None
    directions = (0, 1) if weak is None else (weak,)
    waves = _wave(_WINDOW, peaks)
    parent_basis = np.concatenate((_SMOOTH, waves.reshape(_WINDOW, _WINDOW, 4)), axis=-1)
    projector = _inverse(parent_basis.reshape(_WINDOW**2, -1))[-4:]
    patches = _windows(context, _WINDOW, _STRIDE).reshape(len(_CENTERS), -1)
    parent_coef = np.einsum("dp,np->nd", projector, patches).reshape(-1, 2, 2)
    observed = tuple(_windows(planes[pos], _WINDOW // 2, _STRIDE // 2) for pos in greens)
    fixed, pooled, shared = [], [], []
    ratios = {}
    for direction in range(2):
        args = (waves, direction, greens, observed)
        suffix = (patches, parent_coef[:, direction], shot, read)
        if direction not in directions:
            planar = _correction(*args, None, *suffix)
            fixed.append(planar)
            pooled.append(planar)
            shared.append(planar)
            continue
        guide = tuple(template(global_wave, terms, pos, (), direction)[0] for pos in greens)
        extra = tuple(template(global_wave, terms, pos, chroma, direction) for pos in greens)
        ratios[str(direction)] = [gain for _, gain in extra]
        pooled.append(_correction(*args, guide, *suffix))
        if any(any(gain) for _, gain in extra):
            shared.append(_correction(*args, tuple(g for g, _ in extra), *suffix))
        else:
            shared.append(pooled[-1])
        fixed.append(_correction(*args, None, *suffix) if weak is None else pooled[-1])

    def combine(parts):
        if weak is None:
            return crop + _rgb(parts[0] + parts[1], neutral, crop.dtype)
        return (
            crop
            + _rgb(parts[1 - weak], neutral, crop.dtype)
            + _rgb(parts[weak], neutral, crop.dtype)
        )

    output = {
        name: combine(parts) for name, parts in zip(ARMS, (fixed, pooled, shared), strict=True)
    }
    rms = {
        key: [
            float(np.sqrt(np.mean((_rgb(new - old, neutral, "d")) ** 2)) * 65535)
            for new, old in zip(part, base, strict=True)
        ]
        for key, part, base in (
            ("open_vs_weak", pooled, fixed),
            ("shared_vs_open", shared, pooled),
        )
    }
    return output, {"weak": weak, "direction_rms_DN16": rms, "ratios": ratios}


def independence():
    """Swap every held green pixel while keeping each fit-side preview fixed."""
    from demosaic.cfa import PATTERNS

    rng = np.random.default_rng(7925)
    peaks = np.array(((0.1015625, 0.0703125), (0.10546875, -0.06640625)))
    waves = _wave(_POOLED_FOOTPRINT, peaks)
    noise = (0.00128, 6.5536e-6)
    count = 0
    for colors in PATTERNS.values():
        scene = np.full((4, 128, 128), 0.06, dtype="d")
        greens, chroma, planes = fields(scene, colors, (33, 31))
        scene_patch = 0.08 + np.sum(waves[..., 0], axis=-1) * 0.012
        for i, pos in enumerate(planes):
            r, c = pos
            planes[pos] = scene_patch[r::2, c::2] * (1 + 0.1 * i)
            planes[pos] += rng.normal(0, 0.004, size=planes[pos].shape)
        for fit, held in (greens, greens[::-1]):
            terms = {p: _measure_nodes(a, waves, p, *noise) for p, a in planes.items()}
            original = template(waves, terms, fit, chroma, 0)
            changed = dict(planes)
            changed[held] = rng.uniform(0.0, 0.2, size=planes[held].shape)
            terms = {p: _measure_nodes(a, waves, p, *noise) for p, a in changed.items()}
            replay = template(waves, terms, fit, chroma, 0)
            np.testing.assert_array_equal(original[0], replay[0])
            assert original[1] == replay[1] and all(v > 0 for v in original[1])
            count += 1
    return count
