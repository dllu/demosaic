"""Replay phase sharing on frozen optical observations and standing GFX crops."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from demosaic.prediction_archive import fingerprint

from phase_sharing import ARMS, apply_sharing, independence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = Path("/mnt/external/demosaic") / HERE.name
POOLED = OUT.with_name("local-pooled-carrier-v1")
PARITY = OUT.with_name("local-pooled-carrier-api-v1") / "parity-final.json"
sys.path.insert(0, str(HERE.with_name(POOLED.name)))

from weak_only_pool import WeakOnly
from capture_envelope import RAW
from score_envelope import FIXED, ROI, Measure, arrays, display, native_board, section
from review_pool import METRICS, interval, source_bootstrap

SENSOR_ROI = (176, 176, 160, 160)
SELECTED = (13, 14)
LABELS = {
    "weak_only": "Green weak-only",
    "open_rank": "Green rank open",
    "shared_phase": "Shared R/G/B phase",
}
SUBSET = np.array((0, 2, 3, 4, 5))


def view_synthetic(case, data, parents, outputs, src, plan):
    attrs = {key: data[key][None] for key in ("colors", "wb", "matrix")}
    attrs["packed"] = data["packed"][:1]
    frames = [
        noisy_malvar(attrs)[0],
        parents[0],
        *(outputs[key][0] for key in ARMS),
        data["target"][0],
    ]
    return native_board(
        OUT / "exact",
        case["id"],
        frames,
        attrs,
        {
            "source": case,
            "input": src,
            "weights": plan["weights"],
            "exposure": plan["noise"]["exposure"],
            "optical_sigma": plan["sigma"],
            "noise": plan["noise"],
            "query": plan["query"],
        },
        labels=["Noisy Malvar", "Local 50k", *LABELS.values(), "Exact GT"],
        triplet_indices=(0, 4, 5),
    )


def score_one(case, data, parent, scene, noise, geometry, expected):
    src = SENSOR_ROI
    colors, wb, matrix = (data[key] for key in ("colors", "wb", "matrix"))
    peaks = _spacing(scene, colors, *src[:2], clearance=48)
    prediction = {key: parent.copy() for key in ARMS}
    details = []
    for i, patch in enumerate(data["packed"]):
        scene[RAW] = patch
        crops, info = apply_sharing(parent[i], ROI, scene, src, colors, peaks, noise, wb, matrix)
        assert fingerprint(crops["weak_only"]) == expected[i]["expected"], (case["id"], i)
        for key in ARMS:
            section(prediction[key][i], *ROI)[:] = crops[key]
        details.append(info)
    measure = Measure(data, geometry)
    scores = {"parent": measure(parent, parent)}
    scores.update({key: measure(prediction[key], parent) for key in ARMS})
    return prediction, scores, details


def score_warped(source, prior, parity):
    capture = read_json(checked(source["captures"]))
    plan = read_json(checked(capture["plan"]))
    golden = {row["id"]: row["draws"] for row in parity["panels"]["warped"]}
    rows = []
    for case, row in zip(plan["cases"], capture["rows"], strict=True):
        name = case["id"]
        if name not in golden:
            continue
        readouts = []
        geom = case["geometry"] | {"warp": case["warp"]}
        for index, (inside, outer, expected) in enumerate(
            zip(
                row["observations"]["warped"],
                row["observations"]["straight"],
                golden[name],
                strict=True,
            )
        ):
            f = arrays(inside["input"])
            scene = arrays(outer["input"])["scene_packed"].copy()
            parent = f["local50k"]
            output, scores, info = score_one(
                case, f, parent, scene, plan["noise"], geom, expected["roles"]
            )
            board = (
                view_synthetic(case, f, parent, output, inside["input"], plan)
                if (index == 0 and case["index"] in SELECTED)
                else None
            )
            readouts.append(
                {
                    "input": inside["input"],
                    "donor": outer["input"],
                    "scores": scores,
                    "details": info,
                    "native": board,
                }
            )
        rows.append({"id": name, "family": geom["family"], "draws": readouts})
        if len(rows) % 5 == 0:
            print("warped", len(rows), flush=True)
    assert len(rows) == 20
    return {"source": source["captures"], "rows": rows}


def score_straight(source, parity):
    plan = read_json(checked(source["secondary"]["plan"]))
    parents = read_json(checked(source["secondary"]["parents"]))
    golden = {row["id"]: row["draws"] for row in parity["panels"]["secondary"]}
    rows = []
    for case, row in zip(plan["sources"], parents["records"], strict=True):
        geom = case["geometry"]
        name = case["id"]
        readouts = []
        for stream, expected in zip(row["streams"], golden[name], strict=True):
            f = arrays(stream["data"])
            scene = f["scene_packed"].copy()
            parent = np.load(checked(stream["outputs"]["local50k"]), allow_pickle=False)[SUBSET]
            for key in ("packed", "target", "variance"):
                f[key] = f[key][SUBSET]
            if geom["family"] == "smooth-dip":
                assert np.all(f["support"] > 0)
                f["support"] = np.ones_like(f["support"])
            _, scores, info = score_one(
                case, f, parent, scene, plan["noise"], geom, expected["roles"]
            )
            readouts.append(
                {
                    "input": stream["data"],
                    "parent": stream["outputs"]["local50k"],
                    "scores": scores,
                    "details": info,
                }
            )
        rows.append({"id": name, "family": geom["family"], "draws": readouts})
        if len(rows) % 8 == 0:
            print("straight", len(rows), flush=True)
    assert len(rows) == 32
    return {
        "source": source["secondary"]["plan"],
        "parents": source["secondary"]["parents"],
        "rows": rows,
    }


def standing(parity):
    binding = reference(FIXED)
    original = read_json(checked(binding))
    gold = {r["id"]: r for r in parity["standing"]["rows"]}
    results = []
    for row in original["standing"]:
        f = arrays(row["input"])
        raw, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(row["local_ROI"])
        peaks = _spacing(raw, colors, *roi[:2], clearance=16)
        arms, info = apply_sharing(p, roi, raw, roi, colors, peaks, row["noise"], wb, matrix)
        assert fingerprint(arms["weak_only"]) == gold[row["id"]]["expected"]
        result = {
            "id": row["id"],
            "raw": row["raw"],
            "roi": row["global_ROI"],
            "noise": row["noise"],
            "input": row["input"],
            "parent": row["predictions"]["local50k"],
            "details": info,
            "difference": {
                key: float(np.sqrt(np.mean((a.astype("d") - arms["weak_only"]) ** 2)) * 65535)
                for key, a in arms.items()
            },
            "native": [],
        }
        for view in row["displays"]:
            source = view["board"]
            exposure = view["exposure"]
            with Image.open(checked(source["image"])) as frame:
                saved = np.asarray(frame)
            crops = {}
            for item in source["panels"]:
                x, y, w, h = item["png_xywh"]
                crops[item["name"]] = saved[y : y + h, x : x + w]
            views = [(k, crops[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            views += [(LABELS[key], display(arms[key], wb, matrix, exposure)) for key in ARMS]
            views += [
                (k, crops[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in crops
            ]
            canvas = Image.new("RGB", (8 + 168 * len(views), 192), "#eeeeee")
            draw = ImageDraw.Draw(canvas)
            panels = []
            for i, (label, image) in enumerate(views):
                x = 8 + 168 * i
                canvas.paste(Image.fromarray(image), (x, 24))
                draw.text((x, 5), label, fill="black")
                panels.append({"label": label, "xywh": [x, 24, 160, 160]})
            path = OUT / "standing" / f"{row['id']}-x{exposure:g}.png"
            canvas.save(path)
            result["native"].append(
                {
                    "image": reference(path),
                    "exposure": exposure,
                    "panels": panels,
                    "reference": source,
                }
            )
        results.append(result)
        print(row["id"], result["difference"], flush=True)
    return {"reference": binding, "checkpoints": original["checkpoints"], "rows": results}


def summary(panel):
    data = {}
    for base, alternative in (
        ("weak_only", "open_rank"),
        ("open_rank", "shared_phase"),
        ("weak_only", "shared_phase"),
    ):
        rng = np.random.default_rng(202611200217)
        details = {}
        for metric in METRICS:
            entries = []
            for r in panel["rows"]:
                if metric in r["draws"][0]["scores"][base]:
                    delta = [
                        d["scores"][alternative][metric] - d["scores"][base][metric]
                        for d in r["draws"]
                    ]
                    entries.append({"family": r["family"], "difference": np.mean(delta)})
            idx = source_bootstrap(entries, rng)
            details[metric] = {
                "n": len(entries),
                "difference": interval(np.array([r["difference"] for r in entries])[idx].mean(1)),
            }
        data[f"{alternative}_minus_{base}"] = details
    return data


def main():
    torch.set_num_threads(2)
    start = monotonic()
    for sub in ("standing", "exact"):
        (OUT / sub).mkdir(exist_ok=True)
    parity_source = reference(PARITY)
    parity = read_json(checked(parity_source))
    old = read_json(checked(parity["reference"]))
    audit = independence()
    real = standing(parity)
    if "--standing-only" in sys.argv:
        write_json(OUT / "standing.json", real)
        return
    warped = score_warped(old, parity["reference"], parity)
    straight = score_straight(old, parity)
    output = {
        "scope": "Inference-only replay on previously used controls and standing observations.",
        "driver": reference(__file__),
        "phase_source": reference(HERE / "phase_sharing.py"),
        "package_sources": [
            reference(ROOT / "src/demosaic" / f"{name}.py")
            for name in ("_mesh_pooled", "mesh_carrier_fit")
        ],
        "archive_source": reference(sys.modules["weak_only_pool"].__file__),
        "golden_comparison": parity_source,
        "held_green_replacement_audit": audit,
        "standing": real,
        "warped": warped | {"summary": summary(warped)},
        "straight": straight | {"summary": summary(straight)},
        "seconds": monotonic() - start,
    }
    write_json(OUT / "result.json", output)


if __name__ == "__main__":
    main()
