"""Measure whether colour samples help known phase on fresh procedural fixtures."""

from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json

from phase_sharing import _measure_nodes, _wave, apply_sharing, fields, template

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ROLES = ("aligned", "absent", "opposite", "unrelated", "local_reversal")
NOISE = {"shot": 0.00128, "read": 6.5536e-6}
COUNT = 48
SALT = 202611200218
CENTER = np.s_[32:-32, 32:-32]


def simulate(seed):
    rng = np.random.default_rng(seed)
    peaks = np.array(
        [
            [rng.uniform(0.09, 0.125), rng.uniform(0.058, 0.09)],
            [rng.uniform(0.082, 0.111), -rng.uniform(0.06, 0.088)],
        ]
    )
    y, x = np.indices((192, 192), dtype=np.float64) - 95.5
    wave = _wave(192, peaks)
    phase = rng.uniform(-np.pi, np.pi) + (
        rng.uniform(0.7, 2.5) * x / 96 + rng.uniform(-1.6, 1.6) * (y**2 - x * y) / 96**2
    ) * rng.choice([-1, 1])
    weak = wave[..., 1, 0] * np.cos(phase) - wave[..., 1, 1] * np.sin(phase)
    strong = 0.009 * (wave[..., 0, 0] + 0.25 * wave[..., 0, 1])
    amp = rng.uniform(0.002, 0.0045)
    field = 0.06 + 0.005 * (x + y) / 160 + 0.01 * np.tanh((x - 1.4 * y + 32) / 10)
    shifts = np.cos(2 * np.pi * ((peaks[1, 0] + 0.014) * x + (peaks[1, 1] - 0.016) * y) + phase)
    ellipse = (x / 32) ** 2 + (y / 43) ** 2
    reverse = np.clip((1.2 - ellipse) / 0.4, 0, 1)
    patch = (ellipse <= 0.8)[CENTER]
    mixed = weak * (1 - 2 * reverse)
    profiles = {
        "aligned": (weak, weak),
        "absent": (0.0, 0.0),
        "opposite": (-weak, -weak),
        "unrelated": (shifts, -shifts),
        "local_reversal": (mixed, mixed),
    }
    colors = tuple(PATTERNS.values())[(seed - SALT) % 4]
    roi = (33, 31, 160, 160)
    packed = np.zeros((4, 128, 128), dtype=np.float64)
    green, chroma, _ = fields(packed, colors, roi[:2])
    pos = (*green, *chroma)
    eps = {p: rng.standard_normal((96, 96)) for p in pos}
    core = {p: (slice(p[0], None, 2), slice(p[1], None, 2)) for p in pos}
    terms = {}

    def sample(clean, position):
        clean = clean[core[position]]
        noisy = clean + eps[position] * np.sqrt(NOISE["read"] + NOISE["shot"] * clean)
        return _measure_nodes(noisy, wave, position, **NOISE)

    for p in green:
        terms[p] = sample(field + strong + amp * weak, p)
    results = {}
    true = weak[CENTER]
    for role in ROLES:
        for p, level, pattern in zip(chroma, (0.90, 1.10), profiles[role], strict=True):
            terms[p] = sample(level * (field + strong + amp * pattern), p)
        scores = []
        for p in green:
            base, _ = template(wave, terms, p, (), 1)
            fused, ratios = template(wave, terms, p, chroma, 1)
            values = {}
            for name, estimated in (("green", base[CENTER]), ("shared", fused[CENTER])):
                values["correlation_" + name] = correlation(estimated, true)
                values["patch_" + name] = correlation(estimated[patch], true[patch])
            scores.append(values | {"ratios": ratios})
        results[role] = scores

    # Force a valid two-carrier nomination and exact flat green. R/B contain
    # both candidates at above their shared-phase strengths.
    packed.fill(0.08)
    xx, yy = roi[:2]
    for pr, pc in chroma:
        top, left = yy - 16 + pr, xx - 16 + pc
        phase_index = 2 * (top % 2) + left % 2
        packed[phase_index, top // 2 : top // 2 + 96, left // 2 : left // 2 + 96] = (
            0.08 + 3 * (strong + amp * weak)[pr::2, pc::2]
        )
    parent = np.full((3, 192, 192), 0.08)
    outputs, _ = apply_sharing(
        parent, (16, 16, 160, 160), packed, roi, colors, peaks, NOISE, np.ones(3), np.eye(3)
    )
    for out in outputs.values():
        np.testing.assert_array_equal(out, parent[:, 16:-16, 16:-16])
    return {"seed": seed, "scores": results, "phase_only_chroma_green_flat_exact": True}


def correlation(values, target):
    return float(np.sum(values * target) / (np.linalg.norm(values) * np.linalg.norm(target)))


def main():
    rows = [simulate(SALT + i) for i in range(COUNT)]
    rng = np.random.default_rng(SALT)
    indices = rng.integers(0, COUNT, (6000, COUNT))
    groups = {}
    for role in ROLES:
        fold_results = [r["scores"][role] for r in rows]
        groups[role] = {
            "colour_admitted_folds": sum(any(s["ratios"]) for pair in fold_results for s in pair)
        }
        for kind in ("correlation", "patch"):
            baseline, candidate = (
                np.array([np.mean([s[kind + "_" + name] for s in pair]) for pair in fold_results])
                for name in ("green", "shared")
            )
            delta = candidate - baseline
            groups[role][kind] = {
                "green": float(baseline.mean()),
                "shared": float(candidate.mean()),
                "difference": float(delta.mean()),
                "bootstrap_95": np.quantile(delta[indices].mean(1), (0.025, 0.975)).tolist(),
            }
    write_json(
        OUT / "chroma-stress-local.json",
        {
            "source": reference(__file__),
            "phase_source": reference(HERE / "phase_sharing.py"),
            "noise": NOISE,
            "views": COUNT,
            "roles": ROLES,
            "rows": rows,
            "summary": groups,
            "pure_chroma_flat_green_verified": COUNT,
        },
    )
    print(groups, flush=True)


if __name__ == "__main__":
    main()
