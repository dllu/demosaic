"""Render the stationary GFX reviews over one registered parent per crop."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from restore_scene import ROOT,RESERVE,METHODS,ARGS,restore

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

LABELS = {
    "central":"Single query",
    "anchored-median":"Anchored median",
    "consensus":"Consensus pair",
    "fixed-frequency-median":"Consensus pair median",
    "exterior-shortlist":"Exterior shortlist",
    "shortlist-consensus":"Shortlist consensus",
}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    new = reference(ROOT/"nominations-standing.json")
    recorded = read_json(checked(new))
    scores = reference(ROOT/"scores.json")
    metrics = read_json(checked(scores))
    previous = read_json(RESERVE/"standing/manifest.json")
    upstream = read_json(checked(read_json(checked(previous["proposal_source"]))["upstream"]))
    binding = read_json(checked(upstream["upstream"]))
    desk = read_json(checked(binding["display_parent_boards"]))
    register = {r["id"]:r for r in binding["rows"]}
    candidates = {r["id"]:r for r in recorded["rows"]}
    output = ROOT/"standing"
    output.mkdir(exist_ok=True)
    rows = []
    with ieee_fp32():
        for region in desk["boards"]:
            k = region["id"]
            if k not in candidates:
                continue
            evidence = candidates[k]
            kept = register[region["observation"]]
            archive = evidence["raw"]
            assert archive==kept["raw"]["arrays"]==region["input_arrays"]
            with np.load(checked(archive),allow_pickle=False)as f:
                inputs = {name:f[name]for name in ARGS}
            assert {k:fingerprint(v)for k,v in inputs.items()}==kept["inputs"]
            left,top,_,_ = evidence["fit_xywh"]
            roi = region["case"]["ROI_xywh"]
            x,y,w,h = roi
            native = (x-left,y-top,w,h)
            parent = np.load(checked(kept["parent"]),allow_pickle=False)
            halo = torch.from_numpy(parent[...,top-16:top+272,left-16:left+272].copy())
            args = [torch.from_numpy(inputs[v])for v in ARGS]
            wb,matrix = args[-2:]
            lifted,plain = restore(args,halo,[evidence],(left,top))
            with Image.open(checked(region["image"]))as src:
                older = np.asarray(src.convert("RGB"))
            cells = {p["label"]:older[b:b+d,a:a+c]for p in region["panels"]
                     for a,b,c,d in (p["png_xywh"],)}
            first = [(n,cells[n])for n in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")
                     if n in cells]
            old = display_crop(plain,wb,matrix,native,exposure=region["display_exposure"])
            decoded = np.rint(old*255).astype(np.uint8)
            np.testing.assert_array_equal(decoded,cells["Parent 100k EMA"])
            changes = {}
            stored = {"baseline":plain.numpy()}
            a,b,c,d = native
            view = np.s_[...,b:b+d,a:a+c]
            for mode in METHODS:
                image = plain+metrics["calibration_scales"][mode]*lifted[mode]
                data = display_crop(image,wb,matrix,native,exposure=region["display_exposure"])
                photo = np.rint(data*255).astype(np.uint8)
                first.append((LABELS[mode],photo))
                add = (image-plain)[view].numpy().astype(float)
                changes[mode] = {"added_RGB_DN16":float(np.sqrt(np.mean(add**2))*65535),
                                 "changed_RGB_values":int((photo!=decoded).sum())}
                stored[mode] = image.numpy()
            first += [(name,cells[name])for name in ("ISO100 AHD reference","ISO100 camera JPEG")if name in cells]
            bound = native_png(output/(k+".png"),first)
            path = output/(k+".npz")
            with path.open("wb")as f:
                np.savez(f,**stored)
            rows.append(bound|{"id":k,"raw":archive,"parent_pixels":kept["parent"],
                         "noisy_fit_box":evidence["fit_xywh"],"outputs":reference(path),
                         "inherited_board":region["image"],"case":region["case"],"noise":region["noise"],
                         "reference_role":region["reference_role"],"exposure":region["display_exposure"],
                         "changes":changes})
            print(k,{m:round(o["added_RGB_DN16"],4)for m,o in changes.items()},flush=True)
    assert len(rows)==8
    write_json(output/"manifest.json",{"driver":reference(__file__),"nominations":new,"scores":scores,
                                       "checkpoint":previous["parent"],"rows":rows})


if __name__=="__main__":
    main()
