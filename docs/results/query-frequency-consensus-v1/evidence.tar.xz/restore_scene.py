"""Make matched single-origin and pooled Bayer corrections."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from consensus import ROOT,RESERVE,DONOR,OFFSETS,anchored,local
from run_restore import ARGS,setup_models

METHODS = ("central","anchored-median","consensus","fixed-frequency-median",
           "exterior-shortlist","shortlist-consensus")


def peaks(record):
    return [p["frequency_xy"]for p in record["peaks"]]


def grouped(args,parent,choices,offset):
    out = torch.zeros_like(parent)
    bins = defaultdict(list)
    for n,frequencies in enumerate(choices):
        if len(frequencies)==2:
            bins[tuple(tuple(f)for f in frequencies)].append(n)
    with anchored(offset):
        for key,samples in bins.items():
            out[samples] = local.restore([v[samples]for v in args],parent[samples],key)
    return out


def fit_window(values,parent,x,y,nominal):
    cx,cy = nominal
    native = np.s_[...,y//2:y//2+128,x//2:x//2+128]
    args = [v[native]if i<2 else v for i,v in enumerate(values)]
    # parent is a fixed 288-pixel halo around the nominal query.
    px,py = x-cx+16,y-cy+16
    anchor = parent[...,py:py+256,px:px+256]
    assert anchor.shape[-2:]==(256,256)
    return args,anchor


def aligned(change,offset):
    dx,dy = offset
    width = 224
    top,left = 16-dy,16-dx
    middle = change[...,top:top+width,left:left+width]
    assert middle.shape[-2:]==(width,width)
    return middle


def med(stack):
    return F.pad(torch.stack(stack).median(dim=0).values,(16,16,16,16))


def restore(values,parent,origins,nominal):
    x,y = nominal
    args,anchor = fit_window(values,parent,x,y,nominal)
    selectors = {"central":"center","consensus":"consensus","exterior-shortlist":"exterior-shortlist",
                 "shortlist-consensus":"shortlist-consensus"}
    by_method = {}
    seen = {}
    for label,policy in selectors.items():
        bank = [peaks(n["methods"][policy])for n in origins]
        key = tuple(tuple(tuple(p)for p in row)for row in bank)
        if key not in seen:
            seen[key] = grouped(args,anchor,bank,(0,0))
        by_method[label] = seen[key]
    fixed = [peaks(n["methods"]["consensus"])for n in origins]
    local_views,fixed_views = [],[]
    for n,offset in enumerate(OFFSETS):
        if offset==(0,0):
            local_lift,fixed_lift = by_method["central"],by_method["consensus"]
        else:
            dx,dy = offset
            args,base = fit_window(values,parent,x+dx,y+dy,nominal)
            picked = [peaks(r["views"][n]["local"])for r in origins]
            local_lift = grouped(args,base,picked,offset)
            fixed_lift = local_lift if picked==fixed else grouped(args,base,fixed,offset)
        local_views.append(aligned(local_lift,offset))
        fixed_views.append(aligned(fixed_lift,offset))
    by_method.update({"anchored-median":med(local_views),"fixed-frequency-median":med(fixed_views)})
    return by_method,anchor


def material(record,device):
    with np.load(checked(record["capture"]),allow_pickle=False)as f:
        data = {k:f[k]for k in f.files}
    assert {k:fingerprint(v)for k,v in data.items()}==record["fingerprints"]
    args = [torch.from_numpy(data[k].reshape((-1,*data[k].shape[2:]))).to(device)for k in ARGS]
    return args


@torch.inference_mode()
def run(mode):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    device = torch.device("cuda")
    nomination_ref = reference(ROOT/f"nominations-{mode}.json")
    candidate = read_json(checked(nomination_ref))
    checked(candidate["selector"])
    fields = read_json(checked(candidate["upstream"]))
    plan = read_json(checked(fields["plan"]))
    result = ROOT/f"outputs-{mode}"
    result.mkdir(exist_ok=True)
    reusable = reference(RESERVE/"predictions-replay.json")if mode=="fit" else None
    saved = read_json(checked(reusable))if reusable else None
    if saved:
        assert plan["base"]==saved["checkpoint"]
    started = time.monotonic()
    rows = []
    with ieee_fp32():
        model = None
        if mode=="fresh":
            model = setup_models({"models":{"Corpus 100k":plan["base"]}})["Corpus 100k"]
            model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for state in candidate["rows"]:
            i = state["index"]
            original = fields["rows"][i]
            assert original["index"]==i and original["capture"]==state["capture"]
            destination = result/f"{i:03d}.npz"
            if not destination.exists():
                arguments = material(original,device)
                if saved:
                    with np.load(checked(saved["rows"][i]["output"]),allow_pickle=False)as f:
                        parent = torch.from_numpy(f["baseline"].reshape(-1,3,256,256)).to(device)
                else:
                    args,_ = fit_window(arguments,torch.empty((1,3,288,288),device=device),128,128,(128,128))
                    args[:2] = [a.contiguous(memory_format=torch.channels_last)for a in args[:2]]
                    parent = model(*args)
                # Active parent samples always stay inside the true center fit.
                extended = F.pad(parent,(16,16,16,16),mode="replicate")
                output,center = restore(arguments,extended,state["trials"],(128,128))
                torch.testing.assert_close(parent,center,rtol=0,atol=0)
                frames = {"baseline":parent,**output}
                payload = {k:p.cpu().numpy().reshape(2,4,3,256,256)for k,p in frames.items()}
                temp = destination.with_suffix(".incomplete")
                with temp.open("wb")as stream:
                    np.savez(stream,**payload)
                temp.rename(destination)
            rows.append({"index":i,"output":reference(destination)})
            print(mode,len(rows),round(time.monotonic()-started,1),flush=True)
    write_json(ROOT/f"predictions-{mode}.json",{"driver":reference(__file__),"nominations":nomination_ref,
            "replayed_parent":reusable,"checkpoint":plan["base"],"rows":rows,
            "seconds":time.monotonic()-started})


if __name__=="__main__":
    run(sys.argv[1])
