"""Retest locally witnessed frequency consensus on sensor-anchored Bayer splits."""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import maximum_filter

ROOT = Path(__file__).resolve().parent
RESERVE = ROOT.parent/"query-bayer-reserve-v1"
DONOR = ROOT.parent/"donor-peak-prominence-v1"
sys.path[:0] = [str(RESERVE),str(DONOR)]
import reserved as local
from discover import grids,intersects,tile_scores

OFFSETS = ((0,0),(-8,0),(8,0),(0,-8),(0,8),(-16,-16),(-16,16),(16,-16),(16,16))
METHODS = ("central","anchored-median","consensus","exterior-shortlist","shortlist-consensus")
CENTER = local.partition()
ACTIVE_PARTITION = ContextVar("sensor_partition",default=CENTER)
local.partition = ACTIVE_PARTITION.get


@lru_cache(maxsize=1)
def padded_partition():
    rng = np.random.default_rng(993823)
    random_order = np.argsort(rng.random((72,72,4)),axis=2)
    labels = random_order.reshape(72,72,2,2).transpose(0,2,1,3).reshape(144,144)
    labels[8:136,8:136] = CENTER
    return labels


@contextmanager
def anchored(offset):
    x,y = (v//2+8 for v in offset)
    cells = padded_partition()[y:y+128,x:x+128].copy()
    assert cells.shape==(128,128) and np.bincount(cells.ravel()).tolist()==[4096]*4
    token = ACTIVE_PARTITION.set(cells)
    try:
        yield
    finally:
        ACTIVE_PARTITION.reset(token)


def cut(arrays,x,y):
    area = np.s_[...,y//2:y//2+128,x//2:x//2+128]
    return (arrays["packed"][0][area],arrays["variance"][0][area],arrays["colors"][0])


def bank_exterior(arrays,x,y):
    # The four 112-pixel displacements keep all discovery tiles outside all nine queries.
    boxes = [(a,b,96,96)for t in (0,80,160)
             for a,b in ((x-112,y+t),(x+272,y+t),(x+t,y-112),(x+t,y+272))]
    weights = [tile_scores(arrays,t)[1]for t in boxes]
    near = [maximum_filter(v,5,mode="wrap")for v in weights]
    score = np.zeros_like(weights[0])
    for i,j in combinations(range(len(weights)),2):
        if intersects(boxes[i],boxes[j]):
            continue
        overlap = np.maximum(np.minimum(weights[i],near[j]),np.minimum(weights[j],near[i]))
        score = np.maximum(score,overlap)
    fy,fx,valid,*_ = grids()
    radius = np.hypot(fx,fy)
    maximum = score==maximum_filter(score,7,mode="wrap")
    peaks = []
    for lo,hi in zip(local.BANDS[:-1],local.BANDS[1:],strict=True):
        mask = valid&maximum&(score>=1.35)&(radius>=lo)&(radius<hi)
        coords = np.argwhere(mask)[np.argsort(score[mask],kind="stable")[::-1]][:3]
        peaks.extend({"frequency_xy":[float(fx[a,b]),float(fy[a,b])],
                      "origin":"exterior shortlist","score":float(score[a,b])}for a,b in coords)
    return peaks,boxes


def proposal(arrays,x,y,offset,outside):
    dx,dy = offset
    with anchored(offset):
        records = local.green_records(*cut(arrays,x+dx,y+dy))
        bank = local.local_bank(records)
        union = bank+[p for p in outside if all(
            local.distance(p["frequency_xy"],b["frequency_xy"])>.0035 for b in bank)]
        return {"offset":offset,"local":local.conditional_pair(records,bank),
                "shortlist":local.conditional_pair(records,union)}


def grouped(pairs):
    """Select paired directions with five supporting placements and reject dispersed votes."""
    rejected = {"peaks":[],"supports":[],"votes":0}
    valid = [(view,np.array([p["frequency_xy"]for p in row["peaks"]]),sum(row["supports"]))
             for view,row in enumerate(pairs)if len(row["peaks"])==2]
    groups = []
    for i,first,support in valid:
        hits = []
        for j,second,weight in valid:
            options = [second,second[::-1]]
            best = min(options,key=lambda v:sum(local.distance(a,b)for a,b in zip(first,v)))
            if any(local.distance(a,b)>2/256 for a,b in zip(first,best)):
                continue
            aligned = best*np.where(np.sum(first*best,axis=1)<0,-1,1)[:,None]
            hits.append((j,aligned,weight))
        if len(hits)>=5:
            groups.append((len(hits),sum(hit[2]for hit in hits),support,-i,hits))
    if not groups:
        return rejected
    votes,_,_,_,matches = max(groups,key=lambda item:item[:4])
    frequencies = np.median(np.stack([m[1]for m in matches]),axis=0)
    return {"peaks":[{"frequency_xy":p.tolist(),"origin":"placement consensus"}for p in frequencies],
            "votes":votes,"placements":[m[0]for m in matches]}


def nominations(arrays,x,y):
    outside,donors = bank_exterior(arrays,x,y)
    views = [proposal(arrays,x,y,d,outside)for d in OFFSETS]
    result = {"center":views[0]["local"],"exterior-shortlist":views[0]["shortlist"]}
    for key,method in (("local","consensus"),("shortlist","shortlist-consensus")):
        candidate = grouped([q[key]for q in views])
        with anchored((0,0)):
            data = local.green_records(*cut(arrays,x,y))
            accepted = local.conditional_pair(data,candidate["peaks"])
        result[method] = accepted|{"votes":candidate["votes"],"voters":candidate.get("placements",[])}
    return {"views":views,"methods":result,"exterior":outside,"exterior_tiles":donors}
