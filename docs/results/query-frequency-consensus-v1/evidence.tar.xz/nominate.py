"""Evaluate anchored candidate searches on calibrated and fresh scenes."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from consensus import ROOT,DONOR,RESERVE,nominations,OFFSETS

ROLES = ("present","outside-only","strong-only","quiet-query")


def select_case(job):
    capture,source = job
    with np.load(checked(capture["capture"]),allow_pickle=False)as raw:
        arrays = {k:raw[k]for k in ("packed","variance","colors")}
    assert {k:fingerprint(v)for k,v in arrays.items()}=={k:capture["fingerprints"][k]for k in arrays}
    trials = []
    for i in range(2):
        for j,role in enumerate(ROLES):
            context = {k:v[i,j:j+1]for k,v in arrays.items()}
            result = nominations(context,128,128)
            trials.append({"repeat":i,"role":role,**result})
    return {"index":source["index"],"capture":capture["capture"],"trials":trials}


def scenes(mode):
    if mode=="fresh":
        frozen = reference(ROOT/"fields.json")
    else:
        source = read_json(DONOR/"physical-proposals.json")
        frozen = source["fields"]
    saved = read_json(checked(frozen))
    plan = read_json(checked(saved["plan"]))
    ids = set(plan["fit_indices"] if mode=="fit" else plan["test_indices"])
    jobs = [(a,b)for a,b in zip(saved["rows"],plan["sources"],strict=True)if b["index"]in ids]
    outputs = []
    with ThreadPoolExecutor(3)as pool:
        for i,item in enumerate(pool.map(select_case,jobs),1):
            outputs.append(item)
            print(mode,i,len(jobs),flush=True)
    write_json(ROOT/f"nominations-{mode}.json",{"driver":reference(__file__),"selector":reference(ROOT/"consensus.py"),
             "upstream":frozen,"rows":outputs})


def standing():
    receipt = reference(RESERVE/"proposals-camera.json")
    before = read_json(checked(receipt))
    answer = []
    for record in before["rows"]:
        cells = record["raw"]
        with np.load(checked(cells),allow_pickle=False)as f:
            context = {k:f[k]for k in ("packed","variance","colors")}
        fit = record["fit_xywh"]
        result = nominations(context,*fit[:2])
        assert result["methods"]["center"]==record["methods"]["reserved"]
        item = result|{"id":record["id"],"fit_xywh":fit,"raw":cells}
        answer.append(item)
        print(item["id"],[(k,len(v["peaks"]),v.get("votes"))for k,v in result["methods"].items()],flush=True)
        print([(k,[p["frequency_xy"]for p in v["peaks"]])for k,v in result["methods"].items()],flush=True)
    write_json(ROOT/"nominations-standing.json",{"driver":reference(__file__),"selector":reference(ROOT/"consensus.py"),
             "upstream":receipt,"offsets":OFFSETS,"rows":answer})


if __name__=="__main__":
    mode = sys.argv[1]
    standing() if mode=="standing" else scenes(mode)
