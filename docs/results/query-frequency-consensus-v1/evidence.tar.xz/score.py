"""Measure median and consensus variants at the same two calibration limits."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from restore_scene import METHODS,ROOT,RESERVE
import score_panel as shared
from run_restore import observations

shared.METHODS = METHODS
DISPLAY = ("baseline",*METHODS)
COMPARISONS = (("anchored-median","central"),("consensus","central"),
               ("fixed-frequency-median","central"),("fixed-frequency-median","anchored-median"),
               ("exterior-shortlist","central"),("shortlist-consensus","consensus"))


def bind(mode):
    p = reference(ROOT/f"predictions-{mode}.json")
    predicted = read_json(checked(p))
    nominees = read_json(checked(predicted["nominations"]))
    captures = read_json(checked(nominees["upstream"]))
    spec = read_json(checked(captures["plan"]))
    return p,predicted,nominees,captures,spec


def panels(mode):
    ref,predictions,nominees,captures,plan = bind(mode)
    rows = []
    for target,row in zip(predictions["rows"],nominees["rows"],strict=True):
        i = target["index"]
        source = captures["rows"][i]
        assert i==source["index"]==row["index"]
        assert source["capture"]==row["capture"]
        scored = shared.analyze(source,target)
        rows.append((plan["sources"][i],row,scored))
    return ref,rows


def measure(cases,scales):
    return [{"index":data["index"],"source":data["source"]["id"],"curvature":data["layout"].get("weak_tangential_curvature_cycles_per_px2",0),
             "methods":{k:shared.values(active,k,scales.get(k,1))for k in DISPLAY}}for data,_,active in cases]


def summarize(rows):
    generator = np.random.default_rng(677104)
    sampled = generator.integers(len(rows),size=(10000,len(rows)))
    out = {}
    for z in shared.METRICS:
        values = {k:np.array([r["methods"][k][z]for r in rows])for k in DISPLAY}
        differences = {}
        for a,b in COMPARISONS:
            difference = values[a]-values[b]
            lo,hi = np.quantile(difference[sampled].mean(-1),(.025,.975))
            differences[f"{a}_vs_{b}"] = [float(difference.mean()),float(lo),float(hi)]
        out[z] = {"means":{k:float(v.mean())for k,v in values.items()},"paired_difference_and_95pct_interval":differences}
    return out


def frequency_counts(cases):
    result = {}
    for role in ("present","outside-only","strong-only","quiet-query"):
        views = [t for _,n,_ in cases for t in n["trials"]if t["role"]==role]
        result[role] = {"observations":len(views),
            "pair_nominations":{k:sum(len(d["methods"][k]["peaks"])==2 for d in views)
                                for k in views[0]["methods"]}}
    return result


def main():
    left,fit = panels("fit")
    right,fresh = panels("fresh")
    old = reference(RESERVE/"scores.json")
    predecessor = read_json(checked(old))
    limits = predecessor["limits"]
    fit_metrics = measure(fit,{})
    risk = {key:{k:float(np.mean([x["methods"][k][key]for x in fit_metrics]))for k in METHODS}for key in limits}
    factors = {k:min([1.,*(limit/risk[key][k]for key,limit in limits.items()if risk[key][k]>0)])for k in METHODS}
    assert abs(factors["central"]-predecessor["scales"]["reserved"])<1e-10
    test = measure(fresh,factors)
    nominal = measure(fresh,{})
    report = {"fit":left,"fresh":right,"driver":reference(__file__),"calibration_reference":old,"limits":limits,
              "calibration_scales":factors,"original_fit_risk":risk,"fit_rows":fit_metrics,
              "fresh_nominations":frequency_counts(fresh),"matched_rows":test,"matched":summarize(test),
              "nominal_rows":nominal,"nominal":summarize(nominal),
              "by_curvature":{"curved":summarize([r for r in test if r["curvature"]]),
                               "straight":summarize([r for r in test if not r["curvature"]])}}
    write_json(ROOT/"scores.json",report)
    print(factors,flush=True)


def render():
    torch.set_num_threads(2)
    score = reference(ROOT/"scores.json")
    r = read_json(checked(score))
    stamp,output,_,captures,plan = bind("fresh")
    assert stamp==r["fresh"]
    folder = ROOT/"native"
    folder.mkdir(exist_ok=True)
    boards = []
    for index in (0,3):
        source = plan["sources"][index]
        capture = captures["rows"][index]
        predicted = output["rows"][index]
        meta = observations(capture)
        with np.load(checked(predicted["output"]),allow_pickle=False)as f:
            values = {"baseline":f["baseline"][0],
                      **{k:f["baseline"][0]+r["calibration_scales"][k]*f[k][0]for k in METHODS}}
        raw = malvar(torch.from_numpy(meta["packed"][0]),torch.from_numpy(meta["colors"][0])).numpy()
        linear = values|{"noisy":raw,"GT":meta["target"][0]}
        wb = {k:meta[k][0]for k in ("wb","matrix")}
        pixels = {k:np.rint(display(a,wb,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
                  for k,a in linear.items()}
        for role,n in (("present",0),("outside-only",1),("quiet-query",3)):
            versions = [("all",(*DISPLAY,"GT"))]
            if role=="present":
                versions.append(("triplet",("noisy","fixed-frequency-median","GT")))
            for label,names in versions:
                p = folder/f"{index:03d}-{role}-{label}.png"
                Image.fromarray(np.concatenate([pixels[k][n]for k in names],axis=1)).save(p,optimize=True)
                boards.append({"image":reference(p),"order":names,"repeat":0,"role":role,"index":index,
                               "source":source["source"],"capture":capture,"prediction":predicted,
                               "source_box":source["box"],"query_box":plan["query_box"],"display_ROI":[48,48,160,160],
                               "noise":plan["profile"],"CFA":source["camera"]["pattern"],
                               "render_exposure":2,"WB_from_capture":True})
    write_json(folder/"manifest.json",{"scores":score,"driver":reference(__file__),"rows":boards,
                                    "checkpoint":plan["base"],"transform":"shared WB and matrix, ×2 exposure and clipped sRGB8"})


if __name__=="__main__":
    main()
    render()
