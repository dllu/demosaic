"""Publish the evaluated consensus variants and native comparison evidence."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
KEY = "query-frequency-consensus-v1"
OUT = Path("docs/results")/KEY
GALLERY = Path("docs/images")/KEY


def keep(binding,group,regions):
    original = checked(binding)
    dest = GALLERY/group/original.name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original,dest)
    assert binding["sha256"]==reference(dest)["sha256"]
    with Image.open(dest)as f:
        for x,y,w,h in regions:
            assert w==h==160 and x+w<=f.width and y+h<=f.height
        f.verify()
    return {"path":str(dest),"sha256":binding["sha256"]}


def publish():
    OUT.mkdir(exist_ok=True)
    scores = reference(ROOT/"scores.json")
    measured = read_json(checked(scores))
    audits = reference(ROOT/"audit.json")
    verify = read_json(checked(audits))
    exact = read_json(ROOT/"native/manifest.json")
    standing = read_json(ROOT/"standing/manifest.json")
    assert standing["scores"]==exact["scores"]==scores
    assert verify["camera"]["standing"]==reference(ROOT/"standing/manifest.json")
    assert exact["checkpoint"]==standing["checkpoint"]
    for row in exact["rows"]:
        row["image"] = keep(row["image"],"exact",[(i*160,0,160,160)for i,_ in enumerate(row["order"])])
        view = {
            (0,"present"):"The richer exact modulation over the patterned material is subdued in every restored variant.",
            (3,"present"):"The shared bands and step remain visible. The weak curved family stays faint through the higher-contrast area.",
            (0,"outside-only"):"The interior has the remaining true periodic component. The different delivered fits are visually close.",
            (3,"outside-only"):"The strong component stays faint, with no clear added second family in the central area.",
            (0,"quiet-query"):"The flat center equals the parent of the displayed corrections.",
            (3,"quiet-query"):"The center is smooth and matches the parent in all correction arms.",
        }
        row["viewing"] = view[(row["index"],row["role"])]
    for item in standing["rows"]:
        item["image"] = keep(item["image"],"standing",[p["png_xywh"]for p in item["panels"]])
        if item["id"].endswith("fine-green-mesh-right"):
            note = "Both right-cab diagonal families stay visible with the median, with incomplete and uneven intersections. The wider exterior bank gives a weaker visible lift."
        elif "sky" in item["id"]:
            note = "All reconstruction variants return the smooth parent pixel for pixel."
        elif "chain-link" in item["id"]:
            note = "Coarse crossings stay visible without an obvious new pattern."
        elif "building" in item["id"]:
            note = "All variants keep the parent; fine cables remain soft."
        elif "foliage" in item["id"]:
            note = "The crops match the parent and the fine leaf boundaries remain soft."
        else:
            note = "Both left crops return their respective 100k parent pixels and the lattice remains faint."
        item["viewing"] = note
    assert len(exact["rows"])==8 and len(standing["rows"])==8
    manifest = GALLERY/"manifest.json"
    write_json(manifest,{"exact":exact,"standing":standing,"actual_native_viewing_complete":True})
    archive = OUT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        names = ("prepare.py","consensus.py","nominate.py","restore_scene.py","score.py","camera_review.py",
                 "audit.py","audit-first.py","publish.py","audit.json","audit-first.json","audit-final.log",
                 "plan.json","fields.json","nominations-fit.json","nominations-fresh.json",
                 "nominations-standing.json","predictions-fit.json","predictions-fresh.json","scores.json",
                 "native/manifest.json","standing/manifest.json","prepare.log","nominate-standing.log",
                 "nominate-fit.log","nominate-fresh.log","restore-fit.log","restore-fresh.log",
                 "score.log","camera.log")
        for name in names:
            f.add(ROOT/name,arcname=name)
    write_json(OUT/"publication.json",{
        "experiment":KEY,"trained":False,"numerical_review_complete":True,"actual_native_review_complete":True,
        "base_parent":exact["checkpoint"],"score_receipt":scores,"audit":verify,
        "calibration_scales":measured["calibration_scales"],"calibration_limits":measured["limits"],
        "matched":measured["matched"],"nominal":measured["nominal"],
        "by_curvature":measured["by_curvature"],"nominations":measured["fresh_nominations"],
        "manifest":reference(manifest),"archive":reference(archive),
        "scope":"Inference-only comparison on 16 fresh exact photographic fields and eight standing GFX crops. Fixed full427 and known/unseen camera PSNR are outside this scoped study.",
    })


if __name__=="__main__":
    publish()
