"""Audit sensor-coordinate separation and measure real correction stability."""
import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from restore_scene import ROOT,RESERVE,DONOR,OFFSETS,METHODS,ARGS,anchored,local,peaks,grouped,fit_window
from consensus import nominations,padded_partition

RIGHT = ("mesh-nominal-fine-green-mesh-right","mesh-profile3879-fine-green-mesh-right")


def overlap_check():
    global_mask = padded_partition()
    audited = []
    for offset in OFFSETS:
        with anchored(offset):
            x,y = map(lambda n:n//2+8,offset)
            chosen = local.partition()
        np.testing.assert_array_equal(chosen,global_mask[y:y+128,x:x+128])
        for a in range(0,128,2):
            pieces = chosen[a:a+2].reshape(2,64,2).transpose(1,0,2).reshape(64,4)
            np.testing.assert_array_equal(np.sort(pieces,axis=1),np.broadcast_to(np.arange(4),(64,4)))
        audited.append({"native_dxdy":offset,"scene_coordinate_alignment":True,
                        "cells_each_partition":[4096]*4})
    return audited


def held_groups(full):
    fields = read_json(checked(full["upstream"]))
    dataset = read_json(checked(fields["plan"]))
    manifest = read_json(ROOT.parent.joinpath("scene-full-epoch-v1","plan.json"))["train_manifest"]
    with checked(manifest).open()as handle:
        source_ids = {json.loads(row)["id"]for row in handle}
    heldout = {r["source"]["id"]for r in dataset["sources"]}
    assert len(heldout)==16 and len(source_ids)==90692 and not heldout.intersection(source_ids)
    rng = np.random.default_rng(342109)
    edits = []
    for node in full["rows"]:
        row = node["trials"][0]
        if len(row["methods"]["consensus"]["peaks"])!=2:
            continue
        with np.load(checked(node["capture"]),allow_pickle=False)as f:
            context = {k:f[k][0,0:1].copy()for k in ("packed","variance","colors")}
        mask = padded_partition()>=2
        changed = {k:v.copy()for k,v in context.items()}
        for k in ("packed","variance"):
            changed[k][...,56:200,56:200][...,mask] = rng.uniform(.01,.97,(1,4,int(mask.sum()))).astype(np.float32)
        frozen = nominations(context,128,128)
        assert json.loads(json.dumps(frozen))=={k:row[k]for k in ("views","methods","exterior","exterior_tiles")}
        assert frozen==nominations(changed,128,128)
        edits.append({"index":node["index"],"role":row["role"],
                      "replaced_packed_cells":int(mask.sum()),"all_candidates_unchanged":True})
        if len(edits)==4:
            break
    assert len(edits)>=2
    return {"sample_changes":edits,"train_manifest":manifest,"heldout_overlap":0}


def cosine(a,b):
    a,b = a.astype(np.float64,copy=False),b.astype(np.float64,copy=False)
    scale = np.linalg.norm(a)*np.linalg.norm(b)
    return float(np.clip(np.dot(a,b)/scale,-1,1))if scale else None


@torch.inference_mode()
def phase_stability():
    mode = reference(ROOT/"standing/manifest.json")
    before = read_json(checked(mode))
    nominated = read_json(checked(before["nominations"]))
    old = reference(RESERVE/"placement-delivery.json")
    previous = {r["id"]:r for r in read_json(checked(old))["rows"]}
    scales = read_json(checked(before["scores"]))["calibration_scales"]
    summary = []
    with ieee_fp32():
        for board in before["rows"]:
            id = board["id"]
            if id not in RIGHT:
                continue
            src = next(r for r in nominated["rows"]if r["id"]==id)
            assert board["raw"]==src["raw"]
            with np.load(checked(src["raw"]),allow_pickle=False)as f:
                arguments = [torch.from_numpy(f[k])for k in ARGS]
            rgb = np.load(checked(board["parent_pixels"]),allow_pickle=False)
            x,y,_,_ = src["fit_xywh"]
            X,Y,w,h = board["case"]["ROI_xywh"]
            halo = torch.from_numpy(rgb[...,y-16:y+272,x-16:x+272].copy())
            special = peaks(src["methods"]["consensus"])
            choices = ("anchored with local peaks","anchored with consensus peaks")
            lifts = {k:[]for k in choices}
            for shift,detail in zip(OFFSETS,src["views"],strict=True):
                dx,dy = shift
                u,v = x+dx,y+dy
                args,base = fit_window(arguments,halo,u,v,(x,y))
                native = np.s_[...,Y-v:Y-v+h,X-u:X-u+w]
                for kind,f in zip(choices,(peaks(detail["local"]),special),strict=True):
                    add = grouped(args,base,[f],shift)*scales["central"]
                    delta = ((base+add)-base)[native].numpy().astype(float)
                    lifts[kind].append(delta)
            with np.load(checked(board["outputs"]),allow_pickle=False)as f:
                native = np.s_[...,Y-y:Y-y+h,X-x:X-x+w]
                center = (f["central"]-f["baseline"])[native]
            np.testing.assert_array_equal(center,lifts[choices[0]][0])
            results = {}
            for kind,layer in lifts.items():
                values = [cosine(center.ravel(),r.ravel())for r in layer]
                floor = min(x for x in values[1:]if x is not None)
                med = np.median(layer,axis=0)
                results[kind] = {"center_cosines":values,"minimum_shifted_cosine":floor,
                                 "median_over_nominal_signal_projection":float(np.sum(med*center)/np.sum(center**2))}
            moving = previous[id]
            results["moving Bayer groups"] = {"center_cosines":[v["cosine_over_native_RGB"] for v in moving["views"]],
                                              "minimum_shifted_cosine":min(v["cosine_over_native_RGB"]for v in moving["views"][1:]),
                                              "median_over_nominal_signal_projection":moving["median_projection_onto_center"]}
            print(id,results,flush=True)
            summary.append({"id":id,"measures":results})
    assert len(summary)==2
    return {"standing":mode,"moving_reference":old,"scope":"Same RAW, parent and 160px ROI; measure cosine with the center correction. All per-placement methods use the same center scale for this numerical stability test.","rows":summary}


def main():
    torch.set_num_threads(2)
    p = reference(ROOT/"nominations-fresh.json")
    result = {"driver":reference(__file__),"fresh":p,"coordinates":overlap_check(),
              "holdout":held_groups(read_json(checked(p))),"camera":phase_stability()}
    write_json(ROOT/"audit.json",result)


if __name__=="__main__":
    main()
