"""Close actual native viewing and source-level robustness checks without neural work."""
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path('.cache/experiments/scene-development64-context-review-v1').resolve()
analysis = read_json(root / 'analysis-v1/result.json')
native = read_json(root / 'native-review-v1/result.json')
notes = [
    'Real rigging is visible in exact GT sky; all learned outputs erase almost all cords. No visible new grid.',
    'Quiet blue sky remains smooth across all methods; low-frequency color differs slightly from GT.',
    'Backlit tree branches and leaves remain smoother than GT; no convincing extra bark or crossing detail. This is the best coarse-quiet metric crop, not a visibly large gain.',
    'Defocused brown/highlight shapes remain heavily smoothed; differences among continuations are subtle at native scale.',
    'Cloud edges and internal cloud texture are smoothed in all learned outputs; the selected metric gain does not restore GT cloud detail.',
    'Bright snow and cast shadow lose fine granular texture in all outputs. Spatial context does not make this weak-detail regression visually better.',
    'Dense branches and mesh-like lines have visibly missing fine structure versus GT, including on the dark diagonal trunk. Masking changes RGB without clearly restoring the missing structure.',
    'Brick facade remains simplified and softened. Correct, masked and shuffled context look close; no obvious novel grid or large color fringes in this native ROI.',
]
assert len(native['boards']) == len(notes) == 8
write_json(root / 'native-review-v1/native-viewing.json', {
    'recorded_UTC': datetime.now(timezone.utc).isoformat(),
    'reviewer': 'Codex primary agent, actual view_image calls in this turn',
    'boards': [{'image': b['image'], 'id': b['id'], 'opened': True, 'note': n}
               for b, n in zip(native['boards'], notes, strict=True)],
    'scope': 'All eight final 160px native boards actually opened. Two fixed controls and six disclosed extrema; center ROIs need not contain the extreme error pixel. No resampling, no claim representative of all64 sources. Both protected GFX families for exactly these endpoints were previously actually viewed in the linked first-native report.',
})

robustness = []
for condition in ['shadows', 'iso12800-prior']:
    for metric in ['quiet_coarse_luma_RMS_DN16', 'quiet_coarse_chroma_RMS_DN16',
                   'weak_detail_error_RMS_DN16', 'weak_detail_projection_gain']:
        a = {r['source']: r['metrics'][metric] for r in analysis['per_source']
             if r['variant'] == 'spatial' and r['condition'] == condition and r['metrics'][metric] is not None}
        b = {r['source']: r['metrics'][metric] for r in analysis['per_source']
             if r['variant'] == 'none' and r['condition'] == condition and r['metrics'][metric] is not None}
        identities = sorted(set(a) & set(b))
        values = np.array([a[k] - b[k] for k in identities])
        loo = (values.sum() - values) / (len(values) - 1)
        order = np.argsort(values)
        robustness.append({'condition': condition, 'metric': metric, 'sources': len(values),
                           'mean': float(values.mean()), 'median': float(np.median(values)),
                           'leave_one_source_out_mean_range': [float(loo.min()), float(loo.max())],
                           'best_source': identities[order[0]], 'best_source_difference': float(values[order[0]]),
                           'without_best_source_mean': float(loo[order[0]]),
                           'worst_source': identities[order[-1]], 'worst_source_difference': float(values[order[-1]])})
write_json(root / 'analysis-v1/source-robustness.json', {
    'producer': reference(__file__), 'analysis': reference(root / 'analysis-v1/result.json'),
    'comparisons': robustness,
    'scope': 'Spatial-minus-local-only source means; only existing diagnostic outputs. Median/leave-one-source-out describe sensitivity to source tails, not extra independent experiments. No neural, GPU, RAW, optimizer or noise work.',
})
print('Closed eight viewed boards and eight source-robustness comparisons')
for row in robustness:
    print(row['condition'], row['metric'], 'median', row['median'], 'without_best', row['without_best_source_mean'])
