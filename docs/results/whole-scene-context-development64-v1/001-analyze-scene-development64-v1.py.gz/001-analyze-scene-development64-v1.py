"""Source-balanced context/intervention results and target-only quiet/detail diagnostics."""
import csv
import math
import os
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def box(value,size):
    radius=size//2
    horizontal=F.avg_pool2d(F.pad(value,(radius,radius,0,0),mode='reflect'),(1,size),1)
    return F.avg_pool2d(F.pad(horizontal,(0,0,radius,radius),mode='reflect'),(size,1),1)


def finite(value):
    return float(value) if math.isfinite(float(value)) else None


def masked_rms(value,mask):
    count=mask.flatten(1).sum(1)*value.shape[1]
    energy=(value.square()*mask).flatten(1).sum(1)/count.clamp_min(1)
    return torch.where(count>=1024,energy.sqrt()*65535,energy.new_full((),float('nan')))


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[6,7]);torch.set_num_threads(2)
    root=Path('.cache/experiments/scene-development64-context-review-v1').resolve()
    terminal=read_json(root/'result.json');assert len(terminal['cases'])==128 and terminal['DINO_unchanged']
    plan=read_json(checked(terminal['plan']))
    output=root/'analysis-v1';output.mkdir()
    observations=[]
    for binding in terminal['cases']:
        case=read_json(checked(binding))
        with np.load(checked(case['inputs']),allow_pickle=False)as data:arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
        exposure=case['recipe']['exposure'];wb=arrays['crop_wb'];matrix=arrays['crop_matrix']
        def linear(rgb):return torch.einsum('bij,bjhw->bihw',matrix,rgb*wb[...,None,None])/exposure
        truth=linear(arrays['crop_target'])[...,8:-8,8:-8].double()
        local_mean=box(truth,7)
        local_std=(box(truth.square(),7)-local_mean.square()).clamp_min(0).mean(1,keepdim=True).sqrt()
        quiet=local_std<32/65535
        weak=(local_std>=32/65535)&(local_std<=256/65535)
        detail_truth=truth-local_mean
        predictions={v['variant']:linear(torch.from_numpy(np.load(checked(v['prediction']),allow_pickle=False)))[...,8:-8,8:-8].double()for v in case['variants']}
        for variant in case['variants']:
            label=variant['variant'];prediction=predictions[label];error=prediction-truth
            coarse=box(error,31);luma=(coarse*coarse.new_tensor([.2126,.7152,.0722])[None,:,None,None]).sum(1,keepdim=True)
            chroma=coarse-coarse.mean(1,keepdim=True)
            detail=prediction-box(prediction,7);detail_error=detail-detail_truth
            weak_count=weak.flatten(1).sum(1)*3
            gt_power=(detail_truth.square()*weak).flatten(1).sum(1)
            gt_rms=(gt_power/weak_count.clamp_min(1)).sqrt()*65535
            gain=(detail*detail_truth*weak).flatten(1).sum(1)/gt_power.clamp_min(1e-20)
            gain=torch.where((weak_count>=1024)&(gt_rms>=1),gain,gain.new_full((),float('nan')))
            mask_metrics={'quiet_coarse_luma_RMS_DN16':masked_rms(luma,quiet),
                          'quiet_coarse_chroma_RMS_DN16':masked_rms(chroma,quiet),
                          'weak_detail_error_RMS_DN16':masked_rms(detail_error,weak),
                          'weak_detail_projection_gain':gain,
                          'quiet_fraction':quiet.float().flatten(1).mean(1),
                          'weak_fraction':weak.float().flatten(1).mean(1),
                          'weak_GT_detail_RMS_DN16':gt_rms}
            intervention=prediction-predictions['spatial']
            mask_metrics['change_from_correct_spatial_RMS_DN16']=intervention.square().flatten(1).mean(1).sqrt()*65535
            for index in range(4):
                row={'case':case['id'],'source':case['source_id'],'condition':plan['conditions'][0]['name']if case['id'].endswith(plan['conditions'][0]['name'])else plan['conditions'][1]['name'],
                     'crop':index,'variant':label,'case_receipt':binding,
                     'metrics':{k:finite(v[index])for k,v in mask_metrics.items()}}
                row['metrics'].update({k:v[index]for k,v in variant['metrics'].items()})
                observations.append(row)
        print(case['id'],flush=True)
    assert len(observations)==3072
    grouped=defaultdict(list)
    for row in observations:grouped[row['variant'],row['condition'],row['source']].append(row)
    source_rows=[]
    for (variant,condition,source),values in grouped.items():
        metrics={k:[v['metrics'][k]for v in values if v['metrics'][k]is not None]for k in values[0]['metrics']}
        source_rows.append({'variant':variant,'condition':condition,'source':source,
                            'metrics':{k:float(np.mean(v))if v else None for k,v in metrics.items()}})
    means={}
    for variant,condition in sorted({(r['variant'],r['condition'])for r in source_rows}):
        rows=[r for r in source_rows if r['variant']==variant and r['condition']==condition]
        means[variant+'|'+condition]={k:float(np.mean([r['metrics'][k]for r in rows if r['metrics'][k]is not None]))
                                    for k in rows[0]['metrics']if any(r['metrics'][k]is not None for r in rows)}
    comparisons=[]
    for candidate,control in [('none','V120'),('pooled','none'),('spatial','none'),('spatial','pooled'),('spatial','spatial-masked'),('spatial','spatial-shuffled')]:
        for condition in [c['name']for c in plan['conditions']]:
            first={r['source']:r for r in source_rows if r['variant']==candidate and r['condition']==condition}
            second={r['source']:r for r in source_rows if r['variant']==control and r['condition']==condition}
            assert len(first)==len(second)==64
            for metric in ['srgb_psnr','gradient_mae','chroma_mae','quiet_coarse_luma_RMS_DN16','quiet_coarse_chroma_RMS_DN16','weak_detail_error_RMS_DN16','weak_detail_projection_gain']:
                identities=[k for k in sorted(first)if first[k]['metrics'][metric]is not None and second[k]['metrics'][metric]is not None]
                values=np.array([first[k]['metrics'][metric]-second[k]['metrics'][metric]for k in identities])
                if not len(values):continue
                generator=np.random.default_rng(7417);boot=values[generator.integers(len(values),size=(2000,len(values)))].mean(1)
                comparisons.append({'candidate':candidate,'control':control,'condition':condition,'metric':metric,'sources':len(values),
                                    'mean_difference':float(values.mean()),'source_bootstrap95':np.quantile(boot,[.025,.975]).tolist(),
                                    'positive_sources':int((values>0).sum()),'negative_sources':int((values<0).sum()),
                                    'minimum_difference':float(values.min()),'maximum_difference':float(values.max())})
    table=output/'per-crop.csv'
    metrics=list(observations[0]['metrics'])
    with table.open('x',newline='')as stream:
        writer=csv.DictWriter(stream,fieldnames=['case','source','condition','crop','variant',*metrics]);writer.writeheader()
        writer.writerows({**{k:r[k]for k in ['case','source','condition','crop','variant']},**r['metrics']}for r in observations)
    write_json(output/'result.json',{'producer':reference(__file__),'terminal':reference(root/'result.json'),'observations':observations,'per_source':source_rows,
               'means':means,'comparisons':comparisons,'per_crop_csv':reference(table),
               'mask_protocol':{'linear_domain':'Unclipped linear sRGB after WB/matrix, divided by declared scene exposure; units DN16=65535 per scene-linear unit.',
               'quiet':'GT local7x7 RGB std<32DN16','weak':'GT local7x7 RGB std32..256DN16','detail':'RGB minus native7x7 box mean',
               'coarse_error':'Native31x31 box mean of final RGB error','mask_and_sum_precision':'Float64;separable box filters avoid cancellation in nearly flat GT fields. Original stored benchmark metrics stay unchanged.',
               'minimum_samples':1024,'projection_minimum_GT_detail_RMS_DN16':1,
               'scope':'Target-only diagnostic masks, never inference inputs or calibrated confidence. Box filters describe these operators, not an exact Fourier passband. Gains can exceed1; phase-unaligned detail still incurs error.'},
               'scope':'Complete fixed64 sources,2 conditions,RGGB,4 crops,6 variants;3072 evaluated crop/variant rows. Means balance crops within source; bootstrap64 paired sources, not pixels/crops. No new model/encoder/GPU/noise/RAW/optimizer calls. Narrow context-development evaluation, not full427/known-unseen or a lifetime/scaling-independent holdout. Native viewing separate.'})
    print('complete64-source analysis',len(observations),'crop rows')


if __name__=='__main__':main()
