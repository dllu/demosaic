"""Native fixed examples plus disclosed extrema from the completed64-source study."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image,ImageDraw

from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop,save_triplet

torch.set_num_threads(2)
root=Path('.cache/experiments/scene-development64-context-review-v1').resolve();analysis=read_json(root/'analysis-v1/result.json')
terminal=read_json(root/'result.json');cases={read_json(checked(p))['id']:read_json(checked(p))for p in terminal['cases']}
table={(r['case'],r['crop'],r['variant']):r for r in analysis['observations']}
selected={}
def choose(identity,crop,reason):selected.setdefault((identity,crop),[]).append(reason)
choose('development-0-shadows',1,'Fixed sky-rigging example from the initial preselected source.')
choose('development-1-iso12800-prior',0,'Fixed quiet-sky example from the initial preselected source.')
candidates=[r for r in analysis['observations']if r['variant']=='spatial'and r['condition']=='iso12800-prior']
for metric,title in [('quiet_coarse_luma_RMS_DN16','quiet coarse luma'),('weak_detail_error_RMS_DN16','weak-region detail error')]:
    pairs=[(r['metrics'][metric]-table[r['case'],r['crop'],'none']['metrics'][metric],r)for r in candidates
           if r['metrics'][metric]is not None and table[r['case'],r['crop'],'none']['metrics'][metric]is not None]
    for direction,label in [(min,'Largest improvement'),(max,'Largest regression')]:
        value,row=direction(pairs,key=lambda item:item[0]);choose(row['case'],row['crop'],f'{label} in {title} versus local-only,selected from all256 ISO12800 crops:delta{value:.8g}.')
for variant,label in [('spatial-masked','masked'),('spatial-shuffled','shuffled')]:
    row=max((r for r in analysis['observations']if r['variant']==variant and r['condition']=='iso12800-prior'),key=lambda r:r['metrics']['change_from_correct_spatial_RMS_DN16'])
    choose(row['case'],row['crop'],f'Largest final-RGB response to {label} scene context among256 ISO12800 crops.')
output=root/'native-review-v1';output.mkdir();boards=[];triplets=[]
variants=['V120','none','pooled','spatial','spatial-masked','spatial-shuffled']
labels={'V120':'V120 EMA','none':'Local-only2k','pooled':'Pooled2k','spatial':'Spatial2k','spatial-masked':'Spatial masked','spatial-shuffled':'Spatial shuffled'}
for (identity,index),reasons in selected.items():
    case=cases[identity]
    with np.load(checked(case['inputs']),allow_pickle=False)as data:arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
    wb=arrays['crop_wb'][index:index+1];matrix=arrays['crop_matrix'][index:index+1]
    predictions={v['variant']:torch.from_numpy(np.load(checked(v['prediction']),allow_pickle=False))for v in case['variants']}
    noisy=malvar(arrays['crop_packed'],arrays['crop_colors'],arrays['crop_wb'])
    roi=[48,48,160,160];exposure=1/case['recipe']['exposure']
    def display(value):return display_crop(value[index:index+1],wb,matrix,roi,exposure=exposure)
    panels=[('Noisy (Malvar)',display(noisy)),*[(labels[v],display(predictions[v]))for v in variants],('Exact GT',display(arrays['crop_target']))]
    key=identity+'-crop'+str(index);path=output/(key+'.png');image=Image.new('RGB',(8+168*len(panels),192),'#eeeeee');draw=ImageDraw.Draw(image);rectangles=[]
    def pixels(value):
        assert value.shape==(160,160,3)and np.isfinite(value).all()
        return np.rint(value.clip(0,1)*255).astype(np.uint8)
    for i,(label,value)in enumerate(panels):
        x=8+168*i;draw.text((x,5),label,fill='black');image.paste(Image.fromarray(pixels(value)),(x,24));rectangles.append({'label':label,'png_xywh':[x,24,160,160]})
    image.save(path);reread=np.asarray(Image.open(path))
    for rectangle,(_,value)in zip(rectangles,panels,strict=True):
        x,y,w,h=rectangle['png_xywh'];np.testing.assert_array_equal(reread[y:y+h,x:x+w],pixels(value))
    x,y,w,h=case['boxes_xywh'][index]
    metadata={'id':key,'selection':reasons,'source_id':case['source_id'],'source_cache':case['source_cache'],
              'source_context_xywh':[x,y,w,h],'ROI_xywh':roi,'source_ROI_xywh':[x+48,y+48,160,160],
              'inputs':case['inputs'],'recipe':case['recipe'],'display_exposure':exposure,'WB':wb[0].tolist(),'camera_to_sRGB':matrix[0].tolist(),
              'endpoints':terminal['endpoints'],'weights':'EMA','reference':'Exact synthetic clean target;context-probe holdout only,not parent-lifetime/scaling-independent holdout.'}
    boards.append({'image':reference(path),'panels':rectangles,**metadata})
    triplet=save_triplet(output/'triplets',key,[('Noisy (Malvar)',display(noisy)),('Spatial2k EMA',display(predictions['spatial'])),('Exact GT',display(arrays['crop_target']))],caption=key,metadata=metadata)
    triplets.append({'image':reference(output/'triplets'/triplet['image']),'metadata':reference((output/'triplets'/triplet['image']).with_suffix('.json')),'id':key})
write_json(output/'result.json',{'analysis':reference(root/'analysis-v1/result.json'),'renderer':reference(__file__),'boards':boards,'triplets':triplets,
           'native_pixel_size':[160,160],'actual_viewing':'pending','scope':'Two fixed earlier controls plus disclosed best/worst quiet/detail and largest-intervention responses. ROI is always the center160 of the selected256 crop;selection metrics score the border-trimmed240,not only thiscenter. Identical display/ROI across methods,original noisy scene/targets,no resampling. Reread every PNG panel.0 neural/noise/GPU/RAW/optimizer calls;not a representative mean-quality gallery.'})
print('native_boards',len(boards),'triplets',len(triplets));print([(b['id'],b['selection'])for b in boards])
