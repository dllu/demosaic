"""Independently re-read saved sources, tensors, metrics and native pixels; no models."""
import gzip
import hashlib
import json
import os
import re
import tarfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from demosaic.cfa import malvar
from demosaic.color import render
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.losses import psnr
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop

os.sched_setaffinity(0, [6, 7])
torch.set_num_threads(2)
repo = Path.cwd()
study = repo / '.cache/experiments/scene-development64-context-review-v1'
primary = repo / '.cache/experiments/scene-primary-cpu-v1'
checks = []
publications = []
for name in ['whole-scene-context-development64-v1', 'whole-scene-context-primary-admission-v1']:
    path = repo / 'docs/results' / name / 'publication.json'
    pub = read_json(path)
    publications.append(reference(path))
    for item in pub['archives']:
        data = gzip.decompress(checked(item['published']).read_bytes())
        assert hashlib.sha256(data).hexdigest() == item['original']['sha256']
        assert data == checked(item['original']).read_bytes()
    for package in pub['source_snapshots']:
        expected = {v['member']: v for v in package['members']}
        with tarfile.open(checked(package['published']), 'r:gz') as tar:
            assert set(expected) == set(tar.getnames())
            for name, item in expected.items():
                assert tar.extractfile(name).read() == checked(item['original']).read_bytes()
    for asset in pub['native_assets']:
        assert checked(asset['original']).read_bytes() == checked(asset['published']).read_bytes()
    checks.append({'publication': reference(path), 'exact_archives': len(pub['archives']),
                   'exact_frozen_members': sum(len(p['members']) for p in pub['source_snapshots']),
                   'exact_native_assets': len(pub['native_assets'])})
print('All publication archives and frozen sources exact', flush=True)

terminal = read_json(study / 'result.json')
analysis = read_json(study / 'analysis-v1/result.json')
assert len(terminal['cases']) == 128 and terminal['DINO_unchanged']
assert sum(v['root'] for v in terminal['actual_calls'].values()) == 752
assert sum(v['encoder'] for v in terminal['actual_calls'].values()) == 880
assert terminal['reused_native_predictions'] == 16
rows = {(r['case'], r['variant'], r['crop']): r for r in analysis['observations']}
assert len(rows) == 3072
cases, arrays_by_case, predictions = {}, {}, {}
with torch.inference_mode(), ieee_fp32():
    for binding in terminal['cases']:
        case = read_json(checked(binding))
        cases[case['id']] = case
        with np.load(checked(case['inputs']), allow_pickle=False) as data:
            arrays = {k: torch.from_numpy(data[k].copy()) for k in data.files}
        args = {k: arrays['crop_' + k] for k in ['packed', 'variance', 'colors', 'wb', 'matrix']}
        assert {k: fingerprint(v) for k, v in args.items()} == case['input_fingerprints']
        truth = render(arrays['crop_target'][..., 8:-8, 8:-8], args['wb'], args['matrix'])
        for variant in case['variants']:
            prediction = torch.from_numpy(np.load(checked(variant['prediction']), allow_pickle=False))
            assert prediction.shape == (4, 3, 256, 256) and torch.isfinite(prediction).all()
            measured = psnr(render(prediction[..., 8:-8, 8:-8], args['wb'], args['matrix']), truth)
            assert measured.tolist() == variant['metrics']['srgb_psnr']
            for index, score in enumerate(measured.tolist()):
                assert rows[case['id'], variant['variant'], index]['metrics']['srgb_psnr'] == score
        if len(cases) % 32 == 0:
            print('Native study metrics checked', len(cases), flush=True)
    source_groups = defaultdict(list)
    for row in rows.values():
        source_groups[row['variant'], row['condition'], row['source']].append(row['metrics'])
    independently_grouped = {}
    for key, group in source_groups.items():
        assert len(group) == 4
        independently_grouped[key] = {m: float(np.mean([r[m] for r in group if r[m] is not None]))
                                     if any(r[m] is not None for r in group) else None for m in group[0]}
    for item in analysis['per_source']:
        assert item['metrics'] == independently_grouped[item['variant'], item['condition'], item['source']]
    for comparison in analysis['comparisons']:
        metric, condition = comparison['metric'], comparison['condition']
        sources = sorted(k[2] for k, v in independently_grouped.items()
                         if k[:2] == (comparison['candidate'], condition) and v[metric] is not None
                         and independently_grouped[comparison['control'], condition, k[2]][metric] is not None)
        differences = np.array([independently_grouped[comparison['candidate'], condition, source][metric]
                                - independently_grouped[comparison['control'], condition, source][metric] for source in sources])
        assert len(differences) == comparison['sources']
        assert float(differences.mean()) == comparison['mean_difference']
        rng = np.random.default_rng(7417)
        boot = differences[rng.integers(len(differences), size=(2000, len(differences)))].mean(1)
        assert np.quantile(boot, [.025, .975]).tolist() == comparison['source_bootstrap95']
    native = read_json(study / 'native-review-v1/result.json')
    viewed = read_json(study / 'native-review-v1/native-viewing.json')
    assert [r['image'] for r in viewed['boards']] == [r['image'] for r in native['boards']]
    assert all(r['opened'] for r in viewed['boards'])
    for board in native['boards']:
        identity, index = board['id'].rsplit('-crop', 1)
        index = int(index)
        case = cases[identity]
        with np.load(checked(case['inputs']), allow_pickle=False) as data:
            arrays = {k: torch.from_numpy(data[k].copy()) for k in data.files}
        values = [malvar(arrays['crop_packed'], arrays['crop_colors'], arrays['crop_wb'])]
        values += [torch.from_numpy(np.load(checked(v['prediction']), allow_pickle=False)) for v in case['variants']]
        values += [arrays['crop_target']]
        image = np.asarray(Image.open(checked(board['image'])))
        assert image.shape == (192, 1352, 3)
        for panel, tensor in zip(board['panels'], values, strict=True):
            value = display_crop(tensor[index:index+1], arrays['crop_wb'][index:index+1],
                                 arrays['crop_matrix'][index:index+1], board['ROI_xywh'], exposure=board['display_exposure'])
            rendered = np.rint(value.clip(0, 1) * 255).astype(np.uint8)
            x, y, w, h = panel['png_xywh']
            np.testing.assert_array_equal(image[y:y+h, x:x+w], rendered)
        triplet = next(r for r in native['triplets'] if r['id'] == board['id'])
        t = np.asarray(Image.open(checked(triplet['image'])))
        metadata = read_json(checked(triplet['metadata']))
        # save_triplet native layout is documented by its own per-panel rectangles.
        for label, board_index in [('Noisy (Malvar)', 0), ('Spatial2k EMA', 4), ('Exact GT', 7)]:
            panel = next(p for p in metadata['panels'] if p['label'] == label)
            x, y, w, h = panel['png_xywh']
            bx, by, bw, bh = board['panels'][board_index]['png_xywh']
            assert [w, h] == [bw, bh] == [160, 160]
            np.testing.assert_array_equal(t[y:y+h, x:x+w], image[by:by+bh, bx:bx+bw])
checks.append({'complete_cases': 128, 'input_fingerprints_exact': True, 'saved_PSNR_recomputed_crop_rows': 3072,
               'source_means_and_bootstrap_exact': len(analysis['comparisons']), 'native_boards_all_panels_exact': 8,
               'exact_GT_triplet_subsets': 8, 'actual_viewing_separate_receipt': True})

plan = read_json(primary / 'full-plan.json')
export = read_json(checked(plan['canonical_inputs']))
witnesses = {name: [json.loads(line) for line in checked(stage['input_witness']).read_text().splitlines()]
             for name, stage in plan['stages'].items()}
assert len(export['records']) == 3162 and export['module_forwards'] == 0
for number, record in enumerate(export['records']):
    with np.load(checked(record['arrays']), allow_pickle=False) as data:
        fingerprints = {k: fingerprint(torch.from_numpy(data[k])) for k in data.files}
    assert fingerprints == record['fingerprints']
    witness = witnesses[record['stage']][record['batch']]
    for key, digest in witness['argument_fingerprints'].items():
        assert fingerprints[key]['sha256'] == digest
    if record['stage'] == 'photo':
        assert fingerprints['target']['sha256'] == witness['observation']['input_fingerprints']['target']
    if (number + 1) % 500 == 0:
        print('Canonical historical batches independently checked', number + 1, flush=True)
assert read_json('.cache/experiments/scene-primary-camera-lineage-v1/result.json')['total_crops'] == 162
assert read_json('.cache/experiments/scene-primary-cpu-compatibility-v1/result.json')['all_passed'] is False
for directory in ['scene-primary-batch-qualification-v1', 'scene-primary-frozen-replay-v1']:
    assert read_json(repo / '.cache/experiments' / directory / 'result.json')['all_passed']
threads = read_json('.cache/experiments/scene-primary-thread-qualification-v1/result.json')
assert len(threads['records']) == 8 and threads['all_bit_exact']
for record in threads['records']:
    assert checked(record['two_thread_prediction']).read_bytes() == checked(record['four_thread_prediction']).read_bytes()
preflight = read_json(primary / 'preflight/result.json')
assert preflight['all_complete'] and preflight['DINO_unchanged'] and len(preflight['case_records']) == 3
assert preflight['counts']['new_roots'] == 9 and preflight['counts']['local_DINO_executions'] == 3
checks.append({'canonical_exact_historic_input_batches': 3162, 'photo_targets_exact': True,
               'original_cross_device_failure_preserved': True, 'byte_exact_CPU_thread_adoptions': 8,
               'actual_three_case_preflight_closed': True, 'full_primary_scores_still_pending': True})

documents = ['docs/whole-scene-context-development64.md', 'docs/whole-scene-context-primary-admission.md',
             'docs/whole-scene-context-native-review.md', 'docs/whole-scene-context-next-test.md',
             'docs/current-model.md', 'docs/experiments.md', 'docs/research.md', 'docs/full-corpus-scaling.md',
             'docs/index.md', 'docs/gfx-qualitative.md', 'docs/gfx-green-mesh.md', 'diary/index.md',
             'diary/2026-11-17-04-17-00-scene-development64-primary-admission.md']
links = 0
for document in documents:
    path = repo / document
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        target = target.split('#')[0].strip('<>')
        if target.endswith('/independent-review.json') and not (path.parent / target).exists():
            continue
        assert (path.parent / target).exists(), (document, target)
        links += 1
checks.append({'current_document_links_checked': links, 'README_lines': len((repo / 'README.md').read_text().splitlines())})
receipt = {'verifier': reference(__file__), 'publications': publications, 'all_passed': True, 'checks': checks,
           'scope': 'Independent exact source/archive/input/native-pixel and saved-PSNR/aggregation audit. No new model, DINO, optimizer, noise or RAW work. Actual native viewing is separately recorded. No new completed primary score, source-bound registry point or chart; V120/V131 remain last broad measurements.'}
write_json(repo / '.cache/scene-development64-primary-independent-v2.json', receipt)
for name in ['whole-scene-context-development64-v1', 'whole-scene-context-primary-admission-v1']:
    write_json(repo / 'docs/results' / name / 'independent-review.json', receipt)
print('Independent verification all passed; links', links)
