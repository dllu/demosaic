"""Fixed64-scene CPU comparison and controlled spatial-context interventions."""
import math
import os
import shutil
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import psutil
import torch
from profile_raw_kernel_inference import model_hash

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.metrics import quality_metrics
from demosaic.models import load_model
from demosaic.prediction_archive import fingerprint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import SceneRecipe, observe_scene, scene_crop_boxes
from demosaic.scene_inference import load_scene_checkpoint, perturb_scene
from demosaic.scene_restoration import EncodedScene, WholeSceneRestorer


def shuffle_preserving_pooled(scene, seed):
    generator=torch.Generator().manual_seed(seed);fields=[]
    for feature,stride in zip(scene.features,[4,8,16,32],strict=True):
        h,w=feature.shape[-2:]
        ay=(scene.grid.preview_hw[0]-torch.arange(h)*stride).clamp(0,stride)
        ax=(scene.grid.preview_hw[1]-torch.arange(w)*stride).clamp(0,stride)
        area=(ay[:,None]*ax[None]).flatten();order=torch.arange(h*w)
        for weight in area.unique():
            group=torch.nonzero(area==weight).flatten()
            order[group]=group[torch.randperm(len(group),generator=generator)]
        fields.append(feature.flatten(2).index_select(2,order.to(feature.device)).reshape_as(feature))
    return EncodedScene(tuple(fields),scene.grid)


@torch.inference_mode()
def main(plan_path):
    plan=read_json(plan_path);verify_plan(plan)
    assert reference(__file__)==plan['driver']
    os.sched_setaffinity(0,[8,9]);os.nice(10);torch.set_num_threads(2)
    assert not torch.cuda.is_initialized()
    root=Path(plan['root']);(root/'controller.claim').open('x').close()
    waiting=read_json(checked(plan['native_queue_launch']));deadline=time.monotonic()+7200
    native=read_json(checked(plan['native_plan']));native_root=Path(native['root'])
    while not (native_root/'native-review-queue-result.json').exists() or psutil.virtual_memory().available<32*2**30:
        assert time.monotonic()<deadline,'Bounded native-collection/RAM wait expired, no retry'
        try:
            owner=psutil.Process(waiting['pid']);live=owner.create_time()==waiting['create_time'] and owner.status()!=psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:live=False
        if not live and not (native_root/'native-review-queue-result.json').exists():raise RuntimeError('Native controller ended without terminal receipt')
        write_json(root/'progress.json',{'status':'waiting-for-native-collection-or-RAM','same_native_controller_live':live},replace=True)
        time.sleep(10)
    assert read_json(native_root/'native-review-queue-result.json')['all_succeeded']
    training=read_json(checked(native['training_plan']))
    original={'V120':read_json(checked(native['baseline_collection']))}
    models={};endpoints={};counts={}
    base,_=load_model('v120',checkpoint=checked(native['parent']),device='cpu')
    models['V120']=WholeSceneRestorer(base,mode='none',adapter_width=training['adapter_width']);endpoints['V120']=native['parent']
    for arm in ['none','pooled','spatial']:
        original[arm]=read_json(native_root/arm/'collection.json');endpoint=original[arm]['checkpoint']
        models[arm],_=load_scene_checkpoint(checked(endpoint),weights='ema',expected_sha256=endpoint['sha256']);endpoints[arm]=endpoint
    for arm,model in models.items():
        model.eval().to(memory_format=torch.contiguous_format)
        assert model_hash(model.base.context.backbone)==native['DINO_sha256']
        counts[arm]={'root':0,'encoder':0}
        model.register_forward_pre_hook(lambda *_,c=counts[arm]:c.__setitem__('root',c['root']+1))
        model.base.context.backbone.register_forward_pre_hook(lambda *_,c=counts[arm]:c.__setitem__('encoder',c['encoder']+1))
    rows=[__import__('json').loads(line)for line in checked(plan['development_manifest']).read_text().splitlines()]
    assert len(rows)==64
    (root/'cases').mkdir();began=time.monotonic();cases=[]
    with ieee_fp32():
        for index,row in enumerate(rows):
            if psutil.virtual_memory().available<24*2**30:raise RuntimeError('Runtime RAM floor reached')
            if shutil.disk_usage(root).free<96*2**30:raise RuntimeError('Runtime disk reserve reached')
            if time.monotonic()-began>plan['maximum_collection_seconds']:raise TimeoutError('Declared CPU diagnostic budget reached; no restart')
            source=checked({'path':str((Path(plan['development_manifest']['path']).parent/row['cache']).resolve()),'sha256':row['cache_sha256']})
            array=np.load(source,allow_pickle=False);assert list(array.shape)==row['shape'] and array.dtype==np.uint16
            rgb=torch.from_numpy(array.astype(np.float32)).permute(2,0,1)/65535
            rgb=rgb[:,:rgb.shape[1]//2*2,:rgb.shape[2]//2*2]
            boxes=scene_crop_boxes(rgb.shape[-2:],count=4,patch_size=256,seed=710+index)
            for condition_index,condition in enumerate(plan['conditions']):
                identity=f'development-{index}-{condition["name"]}';folder=root/'cases'/identity;folder.mkdir()
                if index<2:
                    old=next(o for o in native['observations']if o['id']==identity)
                    with np.load(checked(old['arrays']),allow_pickle=False)as data:arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
                    args={k:arrays['crop_'+k]for k in ['packed','variance','colors','wb','matrix']};target=arrays['crop_target'];scene_packed=arrays['scene_packed'];inputs=old['arrays'];recipe=old['recipe']
                else:
                    recipe=SceneRecipe('RGGB',tuple(plan['wb']),tuple(tuple(v)for v in plan['inverse']),condition['exposure'],condition['shot'],condition['read'],.03,71000+102*index+condition_index)
                    obs=observe_scene(rgb,recipe);batch=obs.crops(boxes)
                    args={k:batch[k]for k in ['packed','variance','colors','wb','matrix']};target=batch['target'];scene_packed=obs.packed
                    path=folder/'inputs.npz'
                    with path.open('xb')as stream:np.savez_compressed(stream,scene_packed=scene_packed.numpy(),**{'crop_'+k:v.numpy()for k,v in batch.items()})
                    inputs=reference(path);recipe=asdict(recipe)
                fingerprints={k:fingerprint(v)for k,v in args.items()}
                encoded=models['spatial'].encode_scene(scene_packed,args['colors'][0],args['wb'][0],args['matrix'][0],long_side=native['preview_long_side'],exposure=native['preview_exposure'])
                shuffled=shuffle_preserving_pooled(encoded,73000+index*2+condition_index)
                if index==condition_index==0:
                    a=models['pooled'].adapter(encoded,boxes,(32,32),mode='pooled')
                    b=models['pooled'].adapter(shuffled,boxes,(32,32),mode='pooled')
                    invariant=float((a-b).abs().max());assert invariant<1e-5
                    write_json(root/'pooled-shuffle-invariance.json',{'maximum_offset_difference':invariant,'tolerance':1e-5,'adapter_calls':2,'scope':'Same learned pooled adapter. Shuffle only among feature cells with identical valid native-preview area; the pooled descriptor is preserved, including padding/partial cells. No extra root or DINO call.'})
                variants=[]
                for variant in ['V120','none','pooled','spatial','spatial-masked','spatial-shuffled']:
                    arm='spatial'if variant.startswith('spatial-')else variant;model=models[arm];model.base.set_noise(condition['shot'],condition['read'])
                    reused=index<2 and variant in models
                    if reused:
                        old_row=next(r for r in original[arm]['records']if r['id']==identity)
                        assert fingerprints==old_row['input_fingerprints']
                        prediction=torch.from_numpy(np.load(checked(old_row['prediction']),allow_pickle=False));binding=old_row['prediction'];seconds=0.
                    else:
                        context=None if arm in ['V120','none']else encoded
                        if variant=='spatial-masked':context=perturb_scene(encoded,'masked')
                        if variant=='spatial-shuffled':context=shuffled
                        t=time.monotonic();prediction=model(*(args[k]for k in ['packed','variance','colors','wb','matrix']),scene=context,boxes_xywh=boxes);seconds=time.monotonic()-t
                        path=folder/(variant+'-RGB-f32.npy')
                        with path.open('xb')as stream:np.save(stream,prediction.numpy(),allow_pickle=False)
                        binding=reference(path)
                    metrics={k:[float(x)if math.isfinite(float(x))else None for x in values]for k,values in quality_metrics(prediction[...,8:-8,8:-8],target[...,8:-8,8:-8],args['wb'],args['matrix']).items()}
                    variants.append({'variant':variant,'checkpoint':endpoints[arm],'prediction':binding,'metrics':metrics,'reused':reused,'inference_seconds':seconds})
                receipt={'id':identity,'source_id':row['id'],'source_cache':reference(source),'inputs':inputs,'boxes_xywh':boxes,'recipe':recipe,'input_fingerprints':fingerprints,
                         'scene_feature_fingerprints':[fingerprint(f)for f in encoded.features],'variants':variants}
                write_json(folder/'result.json',receipt);cases.append(reference(folder/'result.json'))
                write_json(root/'progress.json',{'status':'collecting-CPU','completed_cases':len(cases),'total_cases':128,'seconds':time.monotonic()-began,'actual_calls':counts},replace=True)
                print(identity,len(cases),'of128',flush=True)
    assert sum(v['root']for v in counts.values())==752 and sum(v['encoder']for v in counts.values())==880
    assert not torch.cuda.is_initialized()
    assert all(model_hash(m.base.context.backbone)==native['DINO_sha256']for m in models.values())
    write_json(root/'result.json',{'plan':reference(plan_path),'cases':cases,'endpoints':endpoints,'actual_calls':counts,'reused_native_predictions':16,
               'seconds':time.monotonic()-began,'DINO_unchanged':True,'scope':'Fixed64 context-development sources,2 positive-noise conditions,RGGB only,4 native crops per scene;6 variants incl spatial masks and pooled-preserving spatial shuffle. CPU IEEE FP32.752 new roots/880 encoder calls,16 existing predictions reused. Not full427 or known/unseen camera panels, not an independent scaling holdout. Numerical analysis/actual viewing separate; no GPU/training/quality-based stopping.'})


if __name__=='__main__':main(Path(sys.argv[1]))
