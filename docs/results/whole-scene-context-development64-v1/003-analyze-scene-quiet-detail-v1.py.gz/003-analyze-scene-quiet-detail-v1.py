"""Supplement quiet-region coarse errors with explicit false-fine-detail error."""
import importlib.util
import os
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

os.sched_setaffinity(0,[6,7]);torch.set_num_threads(2)
helper=Path('.cache/analyze-scene-development64-v1.py').resolve();spec=importlib.util.spec_from_file_location('closed64_helpers',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=Path('.cache/experiments/scene-development64-context-review-v1').resolve();terminal=read_json(root/'result.json');rows=[]
with torch.inference_mode():
    # Analytic fixtures: true,erased,inverted and orthogonal details. A constant
    # target with a predicted grid must have nonzero quiet fine-detail error.
    x=torch.arange(128,dtype=torch.float64);yy,xx=torch.meshgrid(x,x,indexing='ij')
    truth=(.3+.003*torch.sin(2*torch.pi*xx/16))[None,None].expand(1,3,-1,-1)
    signal=truth-m.box(truth,7);energy=signal.square().sum()
    gains={}
    for name,value in [('correct',truth),('erased',torch.ones_like(truth)*.3),('inverted',.6-truth),('orthogonal',(.3+.003*torch.sin(2*torch.pi*yy/16))[None,None].expand_as(truth))]:
        band=value-m.box(value,7);gains[name]=float((band*signal).sum()/energy)
    assert abs(gains['correct']-1)<1e-12 and abs(gains['erased'])<1e-12 and abs(gains['inverted']+1)<1e-12 and abs(gains['orthogonal'])<1e-6
    flat=torch.ones_like(truth)*.3;grid_error=m.masked_rms(signal,torch.ones(1,1,128,128,dtype=torch.bool));assert grid_error[0]>0
    for binding in terminal['cases']:
        case=read_json(checked(binding))
        with np.load(checked(case['inputs']),allow_pickle=False)as data:arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
        def linear(value):return (torch.einsum('bij,bjhw->bihw',arrays['crop_matrix'],value*arrays['crop_wb'][...,None,None])/case['recipe']['exposure'])[...,8:-8,8:-8].double()
        truth=linear(arrays['crop_target']);mean=m.box(truth,7)
        std=(m.box(truth.square(),7)-mean.square()).clamp_min(0).mean(1,keepdim=True).sqrt();quiet=std<32/65535;detail=truth-mean
        for variant in case['variants']:
            prediction=linear(torch.from_numpy(np.load(checked(variant['prediction']),allow_pickle=False)));band=prediction-m.box(prediction,7)
            values=m.masked_rms(band-detail,quiet)
            for index,value in enumerate(values):rows.append({'case':case['id'],'source':case['source_id'],'crop':index,'variant':variant['variant'],'condition':'shadows'if case['id'].endswith('shadows')else'iso12800-prior','quiet_detail_error_RMS_DN16':m.finite(value)})
    grouped=defaultdict(list)
    for row in rows:
        if row['quiet_detail_error_RMS_DN16']is not None:grouped[row['variant'],row['condition'],row['source']].append(row['quiet_detail_error_RMS_DN16'])
    source_rows=[{'variant':k[0],'condition':k[1],'source':k[2],'value':float(np.mean(v))}for k,v in grouped.items()]
    comparisons=[]
    for control in ['none','pooled','spatial-masked','spatial-shuffled']:
        for condition in ['shadows','iso12800-prior']:
            a={r['source']:r['value']for r in source_rows if r['variant']=='spatial'and r['condition']==condition};b={r['source']:r['value']for r in source_rows if r['variant']==control and r['condition']==condition}
            ids=sorted(set(a)&set(b));d=np.array([a[k]-b[k]for k in ids]);generator=np.random.default_rng(7417);boot=d[generator.integers(len(d),size=(2000,len(d)))].mean(1)
            comparisons.append({'candidate':'spatial','control':control,'condition':condition,'sources':len(d),'mean_difference':float(d.mean()),'source_bootstrap95':np.quantile(boot,[.025,.975]).tolist(),'positive_sources':int((d>0).sum()),'negative_sources':int((d<0).sum())})
write_json(root/'analysis-v1/quiet-detail-supplement.json',{'producer':reference(__file__),'helpers':reference(helper),'terminal':reference(root/'result.json'),'rows':rows,'per_source':source_rows,'comparisons':comparisons,
           'diagnostic_fixtures':{'GT_projection_gains':gains,'quiet_false_grid_error_RMS_DN16':float(grid_error[0])},
           'scope':'Same target-only quiet mask as the main analysis,RGB7x7 high-pass prediction-vs-GT error,exposure-compensated linear-sRGB DN16. Detects fine false texture that a31x31 coarse metric could average away;does not assume quiet GT is identically flat. Float64 filters/sums.3072 existing crop/variant outputs,0 new model/GPU/noise/RAW/optimizer work. Original analysis bytes unchanged.'})
print('quiet-fine detail supplement complete',len(rows))
