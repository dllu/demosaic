"""Compare earlier smooth attenuation and equal-strength uniform cuts on the same rear correction."""

import argparse
import importlib.util
import os
from pathlib import Path
import sys

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("executed_fresh_driver", ROOT/"panel-fixed.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
sys.path.append(str(ROOT.parent/"mesh-step-continuity-v1"))
from demosaic.isolated_line import native_sites
from sided import audit as earlier_gap
from deliver import CENTRE, DISPLAY, Carrier, proposals, score, window
from mesh import ribbon


def run(part, profiles):
    plan = read_json(ROOT/"fixed-plan.json")
    sources = [v for v in plan["cases"] if v["kind"]=="gaps"]
    results = []
    for entry in sources[part::2]:
        name = entry["id"]
        path = ROOT/"fresh"/f"{name}.json"
        case = read_json(path)
        noise = plan["noise"][entry["profile"]]
        sample = next(r for r in case["proof"]["matching"]["roles"] if r["role"]==1)
        if "central_pair" not in sample:
            results.append({"id":name,"source":reference(path),"applicable":False,
                            "scores":{k:case["metrics"]["matching/broad"] for k in ("sided","uniform")}})
            continue
        obs, contexts, _, _, _ = driver.observe(entry,noise)
        cfa = obs["colors"][1].numpy()
        scene = contexts["matching"]
        packed,var = (obs[k][1].numpy() for k in ("packed","variance"))
        _, trace = proposals(scene,cfa,(256,256,256,256),noise,80)
        config, moved, _ = driver.base.prepare(lambda x,y,s: window(scene,(x,y,s,s),phase=2),trace,cfa,
                                               noise,(383.5,383.5))
        with np.load(checked(case["arrays"]),allow_pickle=False) as arrays:
            parent, truth, broad, footprint = (arrays[k] for k in ("parent","target","matching/broad","matching/footprint"))
            masks = {k:arrays[k] for k in ("strong_phase","weak_phase","support")}
        replay, rear, receipt = driver.base.reconstruct(parent[1],packed,var,cfa,CENTRE,DISPLAY,noise,config,
                                                          moved if sample["carried"] else None)
        np.testing.assert_array_equal(replay,broad[1])
        local = window(packed,CENTRE,phase=2)
        x,y = native_sites(local.shape[-2:],(-127.5,-127.5))
        a,b = (ribbon(x,y,Carrier(**d)) for d in sample["central_pair"])
        cut, notes = earlier_gap(local,cfa,a,b,noise,CENTRE,DISPLAY)
        prior = broad.copy()
        prior[1] = (replay - rear*cut[None]).astype(replay.dtype)
        # Every method sees the same admitted correction. Match the RMS
        # attenuation of finite support with a single global rear fraction.
        rms_match = footprint.copy()
        weight = np.linalg.norm((footprint[1]-replay).astype(float))/max(np.linalg.norm(rear),1e-20)
        rms_match[1] = (replay - weight*rear).astype(replay.dtype)
        results.append({"id":name,"source":reference(path),"applicable":True,
                        "scores":{"sided":score(parent,prior,truth,masks),"uniform":score(parent,rms_match,truth,masks)},
                        "sided_proof":notes,"mean_uniform_weight":float(weight),
                        "matched_attenuation_ratio":float(np.linalg.norm((rms_match[1]-replay).astype(float))
                                /max(np.linalg.norm((footprint[1]-replay).astype(float)),1e-20))})
        print(name,notes["passed"],[(k,v["gap_error_RMS_DN16"]) for k,v in results[-1]["scores"].items()],flush=True)
    write_json(ROOT/f"compare-{part}.json",{"driver":reference(__file__),"cases":results,
       "earlier":reference(ROOT.parent/"mesh-step-continuity-v1"/"sided.py"),
       "scope":"Retrospective comparison on the fixed fresh gaps. Stable rear reconstruction is reverified exactly. Uniform attenuation RMS matches the finite attenuation. Earlier side-dependent audit cuts the rear only. Earlier and uniform scores are diagnostics, not new prospective arms."})


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--part",type=int,choices=(0,1),required=True)
    args=parser.parse_args()
    os.sched_setaffinity(0,[12+args.part]); os.nice(12)
    run(args.part,())
