"""Publish the reviewed native crops and complete, hash-bound experiment receipts."""

from datetime import datetime, UTC
import hashlib
from pathlib import Path
import shutil
from statistics import mean
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
IMAGES = REPO/"docs/images/mesh-shrunk-footprint-v1"
RESULTS = REPO/"docs/results/mesh-shrunk-footprint-v1"


def relative(p):
    return {"path":p.relative_to(REPO).as_posix(),"sha256":reference(p)["sha256"]}


def image_export(binding, panels):
    f = checked(binding)
    dest = IMAGES/f.name
    shutil.copyfile(f,dest)
    with Image.open(dest) as image:
        for panel in panels:
            x,y,w,h = panel["png_xywh"]
            assert w==h==160 and x+w<=image.width and y+h<=image.height
    ref = relative(dest)
    assert ref["sha256"] == binding["sha256"]
    return ref


def matched_results(summary):
    runs = [reference(ROOT/f"matched-{j}.json") for j in (0,1)]
    by_id = {row["id"]:row["measurements"] for row in summary["rows"]}
    observed = [r for key in runs for r in read_json(checked(key))["cases"]]
    assert len(observed) == 12 and len({r["id"] for r in observed}) == 12
    for row in observed:
        if row.get("matched_scale",0):
            row["matched_sided_valid_footprint"] = row["max_scaled_cut"] <= 1
            assert abs(row["matched_attenuation_ratio"]-1)<1e-7
    cells = {}
    for profile in ("iso400","iso6400"):
        kinds = ("broad","footprint","sided","uniform","matched_sided")
        group = [r for r in observed if r["id"].startswith(profile)]
        assert len(group)==6
        cells[profile] = {}
        for k in kinds:
            if k == "matched_sided" and any(not r.get("matched_sided_valid_footprint", True) for r in group):
                cells[profile][k] = None
                continue
            vals = [r["scores"][k] if k in r["scores"] else by_id[r["id"]]["matching/"+k] for r in group]
            cells[profile][k] = {"gap_error_RMS_DN16":mean(r["gap_error_RMS_DN16"] for r in vals),
                                "gap_added_RMS_DN16":mean(r["gap_added_RMS_DN16"] for r in vals),
                                "increment_RMS_DN16":mean(r["increment_RMS_DN16"][0] for r in vals)}
    return {"runs":runs,"comparisons":observed,"means":cells}


def main():
    summary = read_json(ROOT/"summary.json")
    assert summary["exact_metric_checks"] == 152 and len(summary["rows"]) == 24
    camera = read_json(checked(summary["camera"]))
    repeats = read_json(ROOT/"repeated.json")
    assert len(repeats["cases"]) == 16
    IMAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    camera_notes = {
        "main-overcast-sky-main-overcast-sky": "Smooth sky.",
        "main-building-detail-main-building-detail": "Fine beam and rail remain soft.",
        "main-foliage-main-foliage": "Soft leaf edges and quiet shadows.",
        "main-chain-link-fence-main-chain-link-fence": "Mild contrast loss within the cut; crossing lines remain visible.",
        "mesh-nominal-fine-green-mesh-left": "A faint portion of the lattice beside the post softens.",
        "mesh-nominal-fine-green-mesh-right": "Both directions retain their weak crossings.",
        "mesh-profile3879-fine-green-mesh-left": "The faint lattice remains with the same uneven dark background.",
        "mesh-profile3879-fine-green-mesh-right": "Both directions and dark background structure remain.",
    }
    synthetic_notes = {
        "iso400-ellipse-g191-role1": "Rear modulation decreases within the ellipse and remains visible around it.",
        "iso400-disk-g192-role1": "Several weak repeats diminish inside the disk. Faint texture remains within the known gap.",
        "iso6400-ellipse-g194-role1": "Rear repeats remain where the exact target has a break.",
        "iso400-step-g190-role0": "The stronger foreground pattern dominates. The effect on the missing rear is subtle.",
        "iso400-step-g190-role1": "The slight rear direction remains visible across parts of the step.",
    }
    cameras, synthetic = [], []
    for record in camera["views"]:
        for item in ("RAW","source","parent","arrays"):
            checked(record[item])
        cameras.append(record | {"image":image_export(record["image"],record["panels"]),
                                 "viewing_note":camera_notes[record["id"]]})
    for record in summary["boards"]:
        identity = record["id"]
        assert identity in synthetic_notes
        for k in ("arrays","checkpoint","case"):
            checked(record[k])
        modes = ("board","triplet") if identity in summary["triplets"] else ("board",)
        proof = {k:v for k,v in record.items() if k not in ("board","triplet")}
        for mode in modes:
            image = record[mode]
            proof[mode] = image | {"image":image_export(image["image"],image["panels"])}
        synthetic.append(proof | {"viewing_note":synthetic_notes[identity]})
    assert len(cameras)==8 and len(synthetic)==5
    view = RESULTS/"viewing.json"
    viewing = {"actual_native_viewing":True,"camera":cameras,"camera_checkpoint":camera["checkpoint"],
               "synthetic":synthetic,"scope":"Eight GFX comparison boards, five synthetic boards and two synthetic triplets opened."}
    if view.exists():
        previous = read_json(view)
        assert {k:previous[k] for k in viewing} == viewing
    else:
        write_json(view, viewing | {"recorded_utc":datetime.now(UTC).isoformat()})
    match = ROOT/"matched-summary.json"
    write_json(match,matched_results(summary))
    for name in ("summary.json","repeated.json","matched-summary.json"):
        shutil.copyfile(ROOT/name,RESULTS/name)
    archive = RESULTS/"evidence.tar.xz"
    inputs = sorted([p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py",".json",".log")]
                    + list((ROOT/"fresh").glob("*.json")))
    bundle = {p.relative_to(ROOT).as_posix():p for p in inputs}
    with tarfile.open(archive,"x:xz",preset=4) as tar:
        for name,p in bundle.items():
            tar.add(p,arcname=name)
    with tarfile.open(archive,"r:xz") as tar:
        for name,p in bundle.items():
            assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==reference(p)["sha256"]
    paths = ("viewing.json","summary.json","matched-summary.json","repeated.json")
    dependencies = ("mesh-refined-edge-v1","mesh-step-continuity-v1","mesh-envelope-support-v1","donor-phase-transport-v1")
    write_json(RESULTS/"publication.json", {
        "scope":"New exact synthetic panel, high-noise guide diagnostic and both standing GFX100S families. All inference uses issued EMA weights.",
        "published_receipts":[relative(RESULTS/name) for name in paths],
        "archive":relative(archive),"archive_contents":{name:reference(p) for name,p in bundle.items()},
        "earlier_archives":[relative(REPO/"docs/results"/name/"evidence.tar.xz") for name in dependencies],
    })


if __name__ == "__main__":
    main()
