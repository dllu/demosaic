"""Fit one foreground step and screen finite rear support on reserved Bayer sites."""

from dataclasses import dataclass
from itertools import product
import math

import numpy as np

from demosaic.isolated_line import coordinates
from edge import fit_edge, forecasts, nuisance, step_profile
from envelope_nuisance import observation, partition
from qualified_step import KNOTS


@dataclass(frozen=True)
class Footprint:
    kind: str
    center: tuple[float, float]
    width: float
    angle: float = 0.

    def mask(self, x, y):
        a, b = x - self.center[0], y - self.center[1]
        radius = np.hypot(a, b) if self.kind == "disk" else abs(a * math.cos(self.angle) + b * math.sin(self.angle))
        ramp = np.clip((self.width + 10 - radius) / 10, 0, 1)
        return ramp*ramp*(3 - 2*ramp)


def library():
    return tuple(
        [Footprint("disk", (x,y), width) for x,y,width in product(range(-48,49,24),range(-48,49,24),(25,43,59))]
        + [Footprint("band", (u*math.cos(a),u*math.sin(a)), width,a)
           for a,u,width in product(np.arange(0,180,30)*np.pi/180, (-32,0,32),(20,36))]
    )


def choose(data, model, wave, reserve):
    x, y = (axis[reserve] for axis in data.positions)
    colors = data.colors[reserve]
    values = data.raw[reserve]
    fit = model[reserve]
    wave = wave[reserve]
    assert values.ndim == x.ndim == y.ndim == 1 and fit.ndim == wave.ndim == 2
    rows = []
    for color in range(3):
        keep = colors == color
        factors, triangular = np.linalg.qr(fit[keep], mode="reduced")
        residual = values[keep] - factors @ (factors.T @ values[keep])
        coeff = np.linalg.solve(triangular, factors.T @ values[keep])
        contribution = wave[keep] @ coeff[-wave.shape[1]:]
        variance = data.shot*max(float(np.median(values[keep])), 1e-4) + data.read
        rows.append((keep, factors, residual, contribution, variance))
    bank = library()
    best = None
    for k in range(0, len(bank), 12):
        group = bank[k:k+12]
        templates = np.column_stack([f.mask(x,y) for f in group])
        overlap, power = np.zeros(len(group)), np.zeros(len(group))
        for keep, factors, residual, contribution, variance in rows:
            delta = -templates[keep]*contribution[:,None]
            projection = factors.T @ delta
            overlap += (residual @ delta)/variance
            power += ((delta*delta).sum(0)-(projection*projection).sum(0))/variance
        strength = np.clip(overlap / np.maximum(power, 1e-12), 0, 1)
        delta_gain = 2*strength*overlap - strength*strength*power
        index = int(delta_gain.argmax())
        candidate = (float(delta_gain[index]), group[index], float(strength[index]))
        if best is None or candidate[0] > best[0]:
            best = candidate
    return best


def validate_support(data, bg, wave, selected, minus):
    before = np.column_stack((bg, wave))
    after = np.column_stack((bg, wave*(1-minus[:,None])))
    assert before.shape == after.shape and minus.ndim == 1
    result = []
    for a,b in selected:
        overlap = power = 0.
        for color in range(3):
            learn, test = a&(data.colors == color), b&(data.colors == color)
            raw = data.raw[learn]
            variance = data.shot*max(float(np.median(raw)),1e-4) + data.read
            base, altered = (f[test] @ np.linalg.solve(f[learn].T@f[learn], f[learn].T@raw)
                            for f in (before,after))
            change = altered-base
            overlap += float((data.raw[test]-base)@change)/variance
            power += float(change@change)/variance
        result.append({"gain":2*overlap-power, "z":overlap/math.sqrt(max(power,1e-20)), "power":power})
    return result


def admitted(rows, amplitude, thresholds):
    return bool(all(amplitude*r["gain"] + amplitude*(1-amplitude)*r["power"] > 0 and r["z"] > z
                    for r,z in zip(rows,thresholds,strict=True)))


def audit(raw, colors, p, q, noise, query, roi):
    data = observation(raw,colors,p,q,noise,KNOTS,flexible=True)
    slot = partition(raw.shape,"distributed")
    a,b,d = (slot == j for j in (1,2,3))
    splits = ((a,b),(b,a),(a|b,d))
    shape, edge = fit_edge(data,slot == 0)
    bg = nuisance(data,p,shape,"refined")
    wave = data.wave[:,None]
    if shape is not None:
        step = step_profile(*data.positions,shape)[0]
        wave = np.column_stack((wave,data.wave*step))
    proof = forecasts(data,bg,wave,splits)
    verdicts = {f: shape is None or admitted(proof,s,(1.75,)*3)
                for f,s in (("hard",1.),("half",.5))}
    mask = np.zeros((roi[3],roi[2]), dtype=float)
    reserve_gain, footprint, fraction = choose(data,np.column_stack((bg,wave)),wave,slot==0)
    selected = {"reserve_gain":reserve_gain,"footprint":vars(footprint),"fraction":fraction,"passed":False}
    if reserve_gain >= 9 and verdicts["half"]:
        cut = fraction * footprint.mask(*data.positions)
        evidence = validate_support(data,bg,wave,splits,cut)
        selected.update(forecast=evidence,passed=admitted(evidence,.5,(1.25,1.25,1.65)))
        if selected["passed"]:
            origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
            x,y=coordinates(roi[3],roi[2],origin=origin)
            mask=.5*fraction*footprint.mask(x,y)
    return verdicts,mask,{"edge":edge,"forecast":proof,"verdicts":verdicts,"gap":selected,
                          "max_cut":float(mask.max()),"mean_cut":float(mask.mean())}
