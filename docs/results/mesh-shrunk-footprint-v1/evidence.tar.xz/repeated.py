"""Fresh independent high-noise draws with previously studied exact guide geometry."""

import importlib.util
import os
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
EARLIER = ROOT.parent/"mesh-refined-edge-v1"
SOURCE = ROOT.parent/"mesh-envelope-support-v1"
sys.path[:0] = [str(SOURCE),str(EARLIER)]
spec = importlib.util.spec_from_file_location("previous_exact_scene_generator", EARLIER/"scenes.py")
scenes = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scenes)
from deliver import CENTRE, DISPLAY, Carrier, window
from mesh import ribbon
from gate import audit, admitted


def run():
    origin = read_json(EARLIER/"plan.json")
    fresh = []
    for g,layout in ((183,"step"),(184,"ellipse")):
        for draw in range(8):
            fresh.append({"g":g,"layout":layout,"independent":True,"rotated":False,
                         "profile":"iso6400","seed":1932872411+g*8337+draw*86171,"draw":draw})
    plan = ROOT/"repeated-plan.json"
    write_json(plan,{"geometry_ref":reference(EARLIER/"scenes.py"),
                     "driver":reference(__file__),"gate":reference(ROOT/"gate.py"),"cases":fresh,
                     "noise":origin["noise"]["iso6400"],
                     "scope":"Conditional on exact wire geometry. All draws new and independent. No donor discovery, parent input or delivered image."})
    out=[]
    for entry in fresh:
        items,_,masks,meta,known=scenes.observe(entry,origin["noise"]["iso6400"])
        nx,ny=native_sites((128,128),(-127.5,-127.5))
        a,b=(ribbon(nx,ny,Carrier(**s)) for s in known["case_geometry"])
        proofs=[]
        for role in (0,1):
            raw=window(items["packed"][role].numpy(),CENTRE,phase=2)
            cfa=items["colors"][role].numpy()
            assert raw.shape==a.shape==b.shape
            verdict,mask,checks=audit(raw,cfa,a,b,origin["noise"]["iso6400"],CENTRE,DISPLAY)
            if role==1 and entry["draw"]==0:
                changed=raw.copy()
                from envelope_nuisance import partition
                held=partition(raw.shape,"distributed").reshape(raw.shape)==3
                changed[held] += .002
                _,_,retest=audit(changed,cfa,a,b,origin["noise"]["iso6400"],CENTRE,DISPLAY)
                assert retest["edge"]==checks["edge"] and retest["forecast"][:2]==checks["forecast"][:2]
                for key in ("reserve_gain","footprint","fraction"):
                    assert retest["gap"][key] == checks["gap"][key]
                if "forecast" in checks["gap"] and "forecast" in retest["gap"]:
                    assert checks["gap"]["forecast"][:2] == retest["gap"]["forecast"][:2]
                checks["audit_separation_check"] = "Held-out perturbation leaves early fits and nomination identical."
            proofs.append({"role":role,"result":checks,"input_sha256":fingerprint(items["packed"][role])})
        actual={"spec":entry,"proofs":proofs,"sensor":meta}
        out.append(actual)
        print(entry["g"],entry["draw"],[r["result"]["verdicts"]for r in proofs],flush=True)
    write_json(ROOT/"repeated.json",{"plan":reference(plan),"cases":out})


if __name__ == "__main__":
    os.sched_setaffinity(0,[15])
    os.nice(12)
    torch.set_num_threads(1)
    run()
