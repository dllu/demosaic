"""Recompute the frozen fresh metrics and render native examples of finite support."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board
from deliver import DISPLAY, score

ROOT = Path(__file__).resolve().parent
MODES = ("broad","hard","half","footprint")
LABELS = ("Wide delivery","Hard check","Half forecast","Finite support")


def rms(x):
    return float(np.sqrt(np.mean(x.astype(float)**2))*65535)


def collect():
    plan_ref = reference(ROOT/"fixed-plan.json")
    plan = read_json(checked(plan_ref))
    parts = [reference(ROOT/f"part-{j}.json") for j in (0,1)]
    saved, show = {}, {}
    for item in parts:
        source = read_json(checked(item))
        assert source["plan"] == plan_ref
        for result in source["measurements"]:
            row = read_json(checked(result))
            name = row["entry"]["id"]
            assert name not in saved
            saved[name] = result
    assert len(saved) == len(plan["cases"]) == 24
    checks = 0
    rows = []
    for case in plan["cases"]:
        name = case["id"]
        row = read_json(checked(saved[name]))
        with np.load(checked(row["arrays"]),allow_pickle=False) as f:
            values = dict(f)
        assert row["entry"] == case
        parent, target = (values[k] for k in ("parent","target"))
        masks = {k:values[k] for k in ("strong_phase","weak_phase","support")}
        x,y,w,h = DISPLAY
        roi = np.s_[...,y:y+h,x:x+w]
        uncut = np.zeros_like(values["matching/broad"])
        region = (masks["weak_phase"][roi] > .10) & (masks["support"][roi] > .9999)
        output = {}
        for name_method, expected in row["metrics"].items():
            correction = None if name_method == "parent" else values[name_method]
            tested = score(parent,correction,target,masks)
            assert tested == expected,(name,name_method)
            checks += 1
            field = parent[roi]+(uncut if correction is None else correction)
            error = field-target[roi]
            guide = name_method.split("/")[0] if "/" in name_method else "matching"
            baseline = values[guide+"/broad"]
            tested.update(
                present_RMS_DN16=rms(error[1]),
                intact_wire_RMS_DN16=rms(error[1][:,region]),
                change_from_broad=[rms(d) for d in (uncut if correction is None else correction)-baseline],
            )
            output[name_method] = tested
        rows.append({"id":name,"case":case,"measurements":output,"source":saved[name],
                     "donor_roles":row["proof"]["matching"]["roles"],"CFA":row["traits"]["CFA"]})
    assert checks == 152, checks

    summary = {}
    for prior in ("iso400","iso6400"):
        for group in ("continuity","gaps"):
            relevant = [row for row in rows if (row["case"]["profile"],row["case"]["kind"]) == (prior,group)]
            assert len(relevant)==6
            methods = {}
            for method in ("parent",*("matching/"+k for k in MODES)):
                selected = [r["measurements"][method] for r in relevant]
                def average(field):
                    values = [v[field] for v in selected if v[field] is not None]
                    return mean(values) if values else None
                methods[method] = {k:average(k) for k in ("intact_wire_RMS_DN16","gap_error_RMS_DN16",
                   "gap_added_RMS_DN16","present_RMS_DN16")}
                methods[method].update(
                    edited=[sum(v["change_from_broad"][i]>0 for v in selected) for i in range(3)],
                    response_pct=100*mean(v["response"][0] for v in selected),
                    wire_increment_RMS_DN16=mean(v["increment_RMS_DN16"][0] for v in selected),
                )
            summary[f"{prior}/{group}"] = methods

    ranked = sorted([r for r in rows if r["case"]["profile"]=="iso400" and r["case"]["kind"]=="gaps"],
                    key=lambda r:r["measurements"]["matching/broad"]["gap_error_RMS_DN16"]-
                                 r["measurements"]["matching/footprint"]["gap_error_RMS_DN16"],reverse=True)
    examples = [(r["id"],1) for r in ranked[:2]]
    high = [r for r in rows if r["case"]["profile"]=="iso6400" and r["case"]["kind"]=="gaps"]
    examples.append((max(high,key=lambda r:r["measurements"]["matching/half"]["gap_added_RMS_DN16"])["id"],1))
    examples.extend((("iso400-step-g190",0),("iso400-step-g190",1)))
    for r in rows:
        if r["measurements"]["matching/hard"] != r["measurements"]["matching/half"]:
            examples.append((r["id"],1))
    examples = list(dict.fromkeys(examples))
    dest = ROOT/"native"
    dest.mkdir(exist_ok=True)
    for name,i in examples:
        rec = read_json(checked(saved[name]))
        with np.load(checked(rec["arrays"]),allow_pickle=False) as f:
            a = dict(f)
        trunk = a["parent"][i]
        spectrum = [noisy_malvar(a)[i],trunk]
        x,y,w,h = DISPLAY
        roi = np.s_[...,y:y+h,x:x+w]
        for method in MODES:
            RGB = trunk.copy()
            RGB[roi] += a["matching/"+method][i]
            spectrum.append(RGB)
        spectrum.append(a["target"][i])
        metadata = {"role":i,"case":saved[name],"checkpoint":plan["checkpoint"],"arrays":rec["arrays"],
                    "CFA":rec["traits"]["CFA"],"noise":plan["noise"][rec["entry"]["profile"]],
                    "seed":rec["entry"]["seed"]}
        triplet = (0,5,6)
        show[(name,i)] = native_board(dest,f"{name}-role{i}",spectrum,{k:a[k][i:i+1] for k in ("wb","matrix")},
            metadata,labels=("Noisy Malvar","Local trunk",*LABELS,"Exact GT"),triplet_indices=triplet,
            exposure=1,roi=DISPLAY,contrast=8)
    write_json(ROOT/"summary.json",{"script":reference(__file__),"plan":plan_ref,"runs":parts,
        "rows":rows,"groups":summary,"boards":list(show.values()),
        "triplets":[f"{r['id']}-role1" for r in ranked[:2]],"exact_metric_checks":checks,
        "camera":reference(ROOT/"camera.json")})


if __name__ == "__main__":
    os.sched_setaffinity(0,[14])
    os.nice(12)
    collect()
