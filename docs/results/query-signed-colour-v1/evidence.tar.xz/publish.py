"""Archive the frozen colour test, repeat controls and native camera review."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
RESULT=Path('docs/results/query-signed-colour-v1')
IMAGE=Path('docs/images/query-signed-colour-v1')


def activate(old, group, note):
    src=checked(old['image'])
    target=IMAGE/group/src.name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,target)
    bound=reference(target)
    assert bound['sha256']==old['image']['sha256']
    with Image.open(target) as f:
        if 'panels' in old:
            for pane in old['panels']:
                x,y,w,h=pane['png_xywh']
                assert w==h==160 and x+w<=f.width and y+h<=f.height
        else:
            assert f.size==(160*len(old['order']),160)
        f.verify()
    return old|{'image':{'path':str(target),'sha256':bound['sha256']},'actual_viewing':note}


def exact_note(index, role):
    if role=='quiet':
        return 'The exact-flat center stays visually uniform. The reserved path matches the existing restoration pixel for pixel.'
    if index==1:
        return 'The faint diagonals gain a slight green-grey tint. Strong edges retain their shape and the exact target still separates the thin crossings more cleanly.'
    return 'A slight tint along the weaker diagonals is visible near the pale vertical detail. The exact target still has appreciably finer crossings and near-gap structure.'


def camera_note(label):
    if 'sky' in label:
        return 'The overcast sky stays smooth and matches the preceding result pixel for pixel.'
    if 'mesh' in label:
        return 'Fine crossings remain incomplete and mottled. Reserved colour reproduces both priors exactly. The unchecked left change is slight.'
    if 'fence' in label:
        return 'Both coarse directions and their visible crossings match the previous result.'
    return 'Thin structure stays soft. Both paths match the previous crop pixel for pixel.'


def main():
    board=read_json(ROOT/'native/manifest.json')
    camera=read_json(ROOT/'standing/manifest.json')
    summary=read_json(checked(board['source']))
    assert board['checkpoint']==camera['checkpoint']==summary['checkpoint']
    panels=[]
    for row in board['rows']:
        panels.append(row|{'boards':[activate(b,'exact',exact_note(row['index'],b['role'])) for b in row['boards']]})
    reviews=[activate(row,'standing',camera_note(row['id']))for row in camera['rows']]
    assert len(panels)==2 and sum(len(r['boards']) for r in panels)==6 and len(reviews)==8
    manifest=IMAGE/'manifest.json'
    write_json(manifest,{'exact':board|{'rows':panels},'standing':camera|{'rows':reviews},
                       'actual_native_viewing_complete':True})
    RESULT.mkdir(exist_ok=True,parents=True)
    archive=RESULT/'evidence.tar.xz'
    needed=(ROOT.parent/'query-shared-gap-v1/check.py',ROOT.parent/'query-shared-gap-v1/review.py',
            ROOT.parent/'query-shape-routing-v1/routing.py',ROOT.parent/'query-checked-junctions-v1/model_delivery.py')
    with tarfile.open(archive,'x:xz') as pack:
        patterns=('*.py','*.json','*.log','initial/*.py','initial/*.log','native/manifest.json','standing/manifest.json')
        for pattern in patterns:
            for path in sorted(ROOT.glob(pattern)):
                pack.add(path,arcname=path.relative_to(ROOT))
        for path in needed:
            pack.add(path,arcname='frozen/'+path.parent.name+'/'+path.name)
    write_json(RESULT/'publication.json',{'archive':reference(archive),'manifest':reference(manifest),
                    'numeric_review_complete':True,'actual_native_viewing_complete':True,
                    'checkpoint':board['checkpoint'],'training_performed':False,
                    'primary':summary['summary'],'sources':{k:reference(ROOT/(k+'.json'))for k in ('scores','controls','gap-colour','frequency-ceiling','audit')},
                    'standing_colour_deltas':{r['id']:r['measurements']for r in reviews},
                    'helpers':[reference(f)for f in needed],
                    'scope':'No weight updates. 24 fresh photo IDs at two ISO priors plus 48 older neutral replays and both camera sets. No full-photo or measured-camera PSNR.'})


if __name__=='__main__':
    main()
