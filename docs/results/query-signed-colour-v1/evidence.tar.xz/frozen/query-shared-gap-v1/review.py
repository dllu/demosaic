"""Score routed gap edits on new photographs and the earlier interruption panel."""
from collections import Counter
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from check import ROOT,METHODS
from demosaic.archive_metrics import display,linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ARMS=("parent","directional",*METHODS)
LUMA=np.array([.2126,.7152,.0722])
CORE=np.s_[64:192,64:192]
ROI=np.s_[...,48:208,48:208]


def fields(row):
    with np.load(checked(row["input"]),allow_pickle=False)as f:
        data={k:f[k]for k in ("packed","target","colors","wb","matrix","support")}
    data["packed"]=data["packed"][...,64:192,64:192]
    data["target"]=data["target"][...,128:384,128:384]
    with np.load(checked(row["output"]),allow_pickle=False)as f:
        methods={k:f[k]for k in (*ARMS,"rotated_base",*("rotated_"+n for n in METHODS))}
    return data,methods


def luma(value,cal):
    return np.einsum("c,bchw->bhw",LUMA,linear_rgb(value,{k:cal[k]for k in ("wb","matrix")}))


def rms(a):
    return float(np.sqrt(np.mean(a*a))*65535)


def score(row,fixture):
    data,outputs=fields(row)
    gold=luma(data["target"],data)
    y={k:luma(v,data)for k,v in outputs.items()}
    exact=(gold[0]-gold[1])[CORE]
    concentration=data["support"][CORE]
    gap=concentration==0
    assert (not gap.any()) or not np.any(exact[gap])
    intact=concentration>=.97
    if not intact.any():
        intact=np.ones_like(gap)
    target=exact[intact]
    phase0=np.array(fixture["geometry"]["frequency"])[0]
    coord=np.arange(128)-63.5
    i,j=np.meshgrid(coord,coord,indexing="ij")
    angle=2*np.pi*(phase0[0]*j+phase0[1]*i)
    taper=np.sqrt(np.outer(np.hanning(128),np.hanning(128))).ravel()
    trig=np.stack((np.cos(angle).ravel(),np.sin(angle).ravel()),axis=1)
    strong_probe=np.linalg.pinv(taper[:,None]*trig)*taper
    metrics={}
    for k in ARMS:
        present=y[k][0]
        addition=(present-y["parent"][0])[CORE]
        changed=(present-y["directional"][0])[CORE]
        increment=(present-y[k][1])[CORE]
        result={"intact_response":float(100*target@increment[intact]/(target@target)),
                "intact_increment_RMS_DN16":rms((increment-exact)[intact]),
                "full_increment_RMS_DN16":rms(increment-exact),
                "present_RMS_DN16":rms((present-gold[0])[CORE]),
                "intact_change_RMS_DN16":rms(changed[intact]),
                "strong_fundamental_change_RMS_DN16":float(65535*np.linalg.norm(strong_probe@changed.ravel())/np.sqrt(2))}
        if gap.any():
            result["added_in_gap_RMS_DN16"]=rms(addition[gap])
            result["total_gap_RMS_DN16"]=rms((present-gold[0])[CORE][gap])
        metrics[k]=result
    selection=row["checks"]["matching"][0]
    holds={}
    for style in ("fundamental","shared"):
        geom=selection.get("chosen",{}).get(style)
        signal=selection.get("held",{}).get(style)
        if geom is not None and signal is not None:
            holds[style]=signal["pooled"]
    return {"index":row["index"],"noise":row["noise"],"family":fixture["geometry"]["family"],"metrics":metrics,
            "route_admitted":row["source_geometry"][0]["matching"]["state"].startswith("donor-"),
            "active_orders":selection.get("active_orders",[]),"held":holds,"cut":selection["cut"]}


def summarize(rows):
    rng=np.random.default_rng(180761)
    out={}
    for noise in sorted({r["noise"]for r in rows}):
        sets=[r for r in rows if r["noise"]==noise]
        families=sorted({r["family"]for r in sets})
        buckets={}
        for kind,choose in [("all",lambda q:True),("any-gap",lambda q:"added_in_gap_RMS_DN16" in q["metrics"]["parent"]),
                ("continuous",lambda q:"added_in_gap_RMS_DN16" not in q["metrics"]["parent"]),
                *((k,lambda r,n=k:r["family"]==n)for k in families)]:
            selected=[r for r in sets if choose(r)]
            if not selected:
                continue
            ids=rng.integers(len(selected),size=(10000,len(selected)))
            metric=set.intersection(*(set(x["metrics"]["parent"])for x in selected))
            values={}
            for m in sorted(metric):
                a={k:np.array([x["metrics"][k][m]for x in selected])for k in ARMS}
                tests={}
                for ls,rs in ((*[(k,"directional")for k in METHODS],("shared","fundamental"))):
                    d=a[ls]-a[rs]
                    tests[ls+"-vs-"+rs]=[float(d.mean()),*np.quantile(d[ids].mean(1),(.025,.975)).tolist()]
                values[m]={"mean":{k:float(v.mean())for k,v in a.items()},"paired":tests}
            counts=Counter(k for r in selected for k in r["cut"])
            buckets[kind]={"count":len(selected),"delivered":sum(r["route_admitted"]for r in selected),
                           "cut":{k:counts[k]for k in METHODS},"scores":values}
        out[noise]=buckets
    return out


def plot_crop(row,source,noise,dest,method):
    data,models=fields(row)
    models["noisy"]=malvar(torch.from_numpy(data["packed"]),torch.from_numpy(data["colors"])).numpy()
    models["GT"]=data["target"]
    outputs={}
    for key,v in models.items():
        z=display(v[ROI],{k:data[k]for k in ("wb","matrix")},exposure=2)
        outputs[key]=np.rint(z.transpose(0,2,3,1)*255).astype(np.uint8)
    stack=[]
    for name,role,labels in (
        ("triplet",0,("noisy",method,"GT")),
        ("comparison",0,("noisy",*ARMS,"GT")),
        ("quiet",3,("noisy",*ARMS,"GT")),
    ):
        png=dest/f"{row['index']:03d}-{row['noise']}-{name}.png"
        Image.fromarray(np.concatenate([outputs[label][role]for label in labels],axis=1)).save(png,optimize=True)
        stack.append({"image":reference(png),"role":name,"order":labels})
    return {"index":row["index"],"noise":row["noise"],"source":source["source"],"source_box":source["box"],
            "CFA":source["camera"]["pattern"],"profile":noise,"exposure":2,"ROI":[48,48,160,160],
            "draw":0,"labeled_as":source["geometry"]["family"],"input":row["input"],"output":row["output"],
            "shown_arm":method,"boards":stack}


def main():
    torch.set_num_threads(2)
    full={}
    references={}
    for tag in ("replay","fresh"):
        path=reference(ROOT/f"{tag}-gap.json")
        checked_outputs=read_json(checked(path))
        dataset=read_json(checked(checked_outputs["observations"]))
        plan=read_json(checked(dataset["source"]))
        label={r["index"]:r for r in plan["sources"]}
        rows=[score(row,label[row["index"]])for row in checked_outputs["rows"]]
        full[tag]={"raw":path,"hub":dataset["source"],"per_case":rows,"summary":summarize(rows)}
        references[tag]=(checked_outputs,plan)
    scores=ROOT/"scores.json"
    write_json(scores,{"driver":reference(__file__),"cohorts":full})
    dest=ROOT/"native"
    dest.mkdir()
    native=[]
    descriptions=[]
    for tag in ("fresh","replay"):
        frozen,plan=references[tag]
        rows=full[tag]["per_case"]
        candidates=[r for r in rows if r["noise"]=="iso6400"and "added_in_gap_RMS_DN16"in r["metrics"]["parent"]]
        priority=lambda r: (r["metrics"]["directional"]["added_in_gap_RMS_DN16"]
                            -r["metrics"]["shared"]["added_in_gap_RMS_DN16"], -r["index"])
        target=max(candidates,key=priority)
        match=next(q for q in frozen["rows"]if (q["index"],q["noise"])==(target["index"],target["noise"]))
        chosen=plot_crop(match,plan["sources"][match["index"]],plan["profiles"][match["noise"]],dest,"shared")
        native.append(chosen|{"cohort":tag})
    assert references["fresh"][0]["checkpoint"]==references["replay"][0]["checkpoint"]
    write_json(dest/"manifest.json",{"scores":reference(scores),"driver":reference(__file__),
        "checkpoint":references["fresh"][0]["checkpoint"],"rows":native,
        "selection":"Largest reduction in added gap RMS from the shared waveform on ISO6400, one example from each cohort."})


if __name__=="__main__":
    main()
