"""Locate a weak-direction deficit with a shared phase-locked RAW waveform."""
from functools import lru_cache
from itertools import product
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent
SHAPE=ROOT.parent/"query-shape-routing-v1"
sys.path.insert(0,str(ROOT.parent/"query-checked-junctions-v1"))
from model_delivery import choose_nuisance,interior,phases,valid_terms

METHODS=("fundamental","shared","sharp")
SHARP_THRESHOLD=2.0
DEFICIT_THRESHOLD=3.25


@lru_cache(maxsize=1)
def shapes():
    locations=(-32.,-16.,0.,16.,32.)
    angles=np.arange(6)*np.pi/6
    ellipses=[(0,x,y,r,s,b)for (x,y),r,s,b in product(product(locations,repeat=2),
                  (21.,31.),(36.,51.),angles)]
    strips=[(1,v,0.,r,1.,b)for v,r,b in product(locations,(18.,28.,37.),np.arange(12)*np.pi/12)]
    return np.asarray([*ellipses,*strips],dtype=float)


def area(x,y,design):
    kind,xc,yc,width,length,angle=np.atleast_2d(design).T
    x=x[:,None]
    y=y[:,None]
    cb,sb=np.cos(angle),np.sin(angle)
    u=(x-xc)*cb+(y-yc)*sb
    v=-(x-xc)*sb+(y-yc)*cb
    strip=(x*cb+y*sb-xc)/width
    radius=np.where(kind==0,np.hypot(u/width,v/length),np.abs(strip))
    hard=np.clip((1.32-radius)/.32,0,1)
    return hard*hard*(3-2*hard),np.exp(-.5*radius*radius)


def regress(design,w,y):
    cov=np.linalg.pinv((design.T*w)@design,rcond=1e-9,hermitian=True)
    return cov@((design.T*w)@y),cov


def latent(data,boundary,geometry):
    x,y,plane,z,var,fold=data
    main,carriers=choose_nuisance(data,boundary,geometry)
    angles=phases(x,y,geometry)
    options=valid_terms(geometry)
    keys=[(1,0),(0,1)]+[tuple(item[1])for item in options]
    few=[angles@key for key in keys]
    wave=np.column_stack([p for a in few for p in (np.cos(a),np.sin(a))])
    all_design=np.column_stack((main,wave))
    width=len(main[0])
    domain=np.maximum(abs(x),abs(y))<=98
    taper=np.exp(-.5*(x*x+y*y)/83**2)
    coefficients=[]
    errors=[]
    for part in (0,1):
        r=domain&(fold==part)
        b,f=regress(all_design[r],taper[r]/var[r],z[r])
        coefficients.append(b[width:].reshape(-1,2))
        errors.append(np.diag(f)[width:].reshape(-1,2).mean(1))
    canonical=np.array(coefficients[0])
    target=int(np.argmin(np.linalg.norm(canonical[:2],axis=1)))
    continuing=np.zeros_like(canonical)
    present=np.maximum(np.linalg.norm(canonical[:2],axis=1),1e-20)
    continuing[target]=canonical[target]
    active=[target]
    for j,key in enumerate(keys[2:],2):
        if key[target]==0:
            continue
        cross=float(coefficients[0][j]@coefficients[1][j])
        floor=float(np.sqrt(errors[0][j]*errors[1][j]))
        total=np.linalg.norm(canonical[j])
        if total<=1e-20 or cross<=2*floor:
            continue
        shrink=max(0.,1-floor/cross)
        continuing[j]=canonical[j]*shrink*min(1.,present[target]*1.6/total)
        active.append(j)
    # Model smooth and step-dependent changes in both directions as nuisance.
    plane_x=x[:,None]/128
    plane_y=y[:,None]/128
    axes=[all_design,carriers*plane_x,carriers*plane_y]
    if boundary is not None:
        ang,shift,_=boundary
        side=np.clip(.5+(x*np.cos(ang)+y*np.sin(ang)-shift)/5,0,1)
        axes.append(wave*side[:,None])
    for j in active[1:]:
        band=wave[:,2*j:2*j+2]
        axes.extend((band*plane_x,band*plane_y))
    background=np.column_stack(axes)
    mono=wave[:,2*target:2*target+2]@continuing[target]
    compound=wave@continuing.ravel()
    return {"target":target,"all_orders":keys,"active_orders":[keys[i]for i in active],
            "discovery_bands":continuing.tolist(),"g_fundamental":mono,"g_shared":compound,
            "amplitude":float(present[target]),"nuisance":background, "domain":domain,"taper":taper}


def residual(value,basis,variance,taper):
    w=taper/variance
    candidate,_=regress(basis,w,value)
    return value-basis@candidate


def pick(data,model,style):
    x,y,_,raw,var,fold=data
    use=model["domain"]&(fold<2)
    phase=model["g_"+style][use]
    base=model["nuisance"][use]
    t=model["taper"][use]
    var=var[use]
    rraw=residual(raw[use],base,var,t)
    w=t/var
    best=None
    for i in range(0,len(shapes()),32):
        bank=shapes()[i:i+32]
        hard,_=area(x[use],y[use],bank)
        masks=-(hard*phase[:,None])
        left=(hard>.92).sum(0)
        around=(hard<.05).sum(0)
        projected=residual(masks,base,var,t)
        support=np.square(projected).T@(w*w*var)
        dot=projected.T@(w*rraw)
        power=np.square(projected).T@w
        z=dot/np.maximum(support,1e-20)**.5
        z[(left<150)|(around<600)|(power<3)]=-np.inf
        winner=int(z.argmax())
        if best is None or z[winner]>best["z"]:
            best={"index":i+winner,"shape":bank[winner].tolist(),"z":float(z[winner]),
                  "fraction":float(dot[winner]/max(power[winner],1e-20))}
    if best is None or best["z"]<2.0:
        return None
    return best


def held(data,model,style,candidate,sharp=False):
    if candidate is None:
        return None
    x,y,_,raw,var,fold=data
    trial=[]
    for part in (2,3):
        use=model["domain"]&(fold==part)
        h,s=area(x[use],y[use],candidate["shape"])
        trigger=-(h*model["g_"+style][use,None])
        b=np.column_stack((model["nuisance"][use],h,s))
        if sharp:
            b=np.column_stack((b,s*model["g_"+style][use,None]))
        varpart=var[use]
        t=model["taper"][use]
        w=t/varpart
        clean=residual(trigger,b,varpart,t).ravel()
        signal=float((raw[use]*clean*w).sum())
        noise=float(((clean*w)**2*varpart).sum())
        energy=float((clean**2*w).sum())
        trial.append((signal,noise,energy))
    score=[s/max(n,1e-20)**.5 for s,n,_ in trial]
    strength=sum(q[0]for q in trial)
    joint=strength/max(1e-20,sum(q[1]for q in trial))**.5
    frac=strength / max(1e-20,sum(q[2]for q in trial))
    return {"scores":score,"pooled":joint,"fraction":frac}


def analyze(raw,cfa,noise,geometry):
    data,_,boundary=interior(raw,cfa,noise)
    model=latent(data,boundary,geometry)
    chosen={k:pick(data,model,k)for k in ("fundamental","shared")}
    scores={"fundamental":held(data,model,"fundamental",chosen["fundamental"]),
            "shared":held(data,model,"shared",chosen["shared"]),
            "sharp":held(data,model,"shared",chosen["shared"],True)}
    cut={}
    for method in METHODS:
        base="fundamental"if method=="fundamental"else "shared"
        nomination=chosen[base]
        tested=scores[base]
        if tested and tested["pooled"]>=DEFICIT_THRESHOLD and min(tested["scores"])>=.85:
            if method=="sharp" and (scores["sharp"]["pooled"]<SHARP_THRESHOLD or min(scores["sharp"]["scores"])<=0):
                continue
            cut[method]=float(np.clip(min(tested["fraction"],nomination["fraction"])*.85,0,.85))
    return {k:model[k]for k in ("target","active_orders","discovery_bands","amplitude")}|{
        "geometry":geometry,"boundary":boundary,"chosen":chosen,"held":scores,"cut":cut}


def apply(parent,restored,evidence,method):
    strength=evidence["cut"].get(method,0.)
    if strength==0:
        return restored
    name="fundamental"if method=="fundamental"else "shared"
    coord=np.arange(256)-127.5
    y,x=np.meshgrid(coord,coord,indexing="ij")
    z=phases(x.ravel(),y.ravel(),evidence["geometry"])
    a=[1,0]if evidence["target"]==0 else [0,1]
    orders=[a]if method=="fundamental"else evidence["active_orders"]
    # Attenuate the same supported weak bands in the existing correction.
    delta=(restored-parent).astype(float)
    raw_energy=np.mean(delta**2,axis=0)
    fast=gaussian_filter(raw_energy,3.5,mode="constant")
    slow=gaussian_filter(raw_energy,10,mode="constant")
    shape=np.minimum(1,np.sqrt(fast/np.maximum(slow,1e-20)))
    total=np.zeros_like(delta)
    for key in orders:
        unit=np.exp(1j*(z@key).reshape(x.shape))
        env=gaussian_filter(delta*unit.conj(),(0,10,10),mode="constant",truncate=3.)
        total+=2*np.real(env*unit)
    restraint=area(x.ravel(),y.ravel(),evidence["chosen"][name]["shape"])[0][:,0].reshape(x.shape)
    return restored-(shape*restraint*total*strength).astype(restored.dtype)
