"""Prove reserved-score isolation, signed chroma and luminance conservation."""
import json

import numpy as np

from colour import LUMA, POLICIES, ROOT, X, Y, anchored, fit, local, render
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

PATTERNS=((0,1,1,2),(2,1,1,0),(1,0,2,1),(1,2,0,1))
OFFSETS=((0,0),(0,1),(1,0),(1,1))
PAIR=[[.116,.047,0.],[.078,-.062,0.]]


def camera_pack(rgb,cfa):
    return np.stack([rgb[c,dv::2,du::2]for c,(dv,du) in zip(cfa,OFFSETS,strict=True)])


def check_geometry():
    rgb_matrix=np.array([[1.04,-.03,-.01],[-.01,1.02,-.01],[-.02,.04,.98]])
    wb=np.array([1.31,1.0,1.19])
    bank=np.linalg.inv(rgb_matrix)/wb[:,None]
    a=np.cos(2*np.pi*(PAIR[0][0]*X+PAIR[0][1]*Y)+.8)
    b=np.cos(2*np.pi*(PAIR[1][0]*X+PAIR[1][1]*Y)-.7)
    firm=.31+.019*a+.01*X/128
    proposed=np.broadcast_to((firm+.009*b)[None],(3,256,256))
    signed=np.array([-.009,.006,-.005])
    signed-=LUMA@signed
    target=proposed+signed[:,None,None]*b
    in_camera=lambda v:np.einsum('ij,jhw->ihw',bank,v)
    base,donor,expected=[in_camera(v) for v in (np.broadcast_to(firm,(3,256,256)),proposed,target)]
    profile={'shot':0.,'read':1e-8}
    problem={'geometry':PAIR}
    coord=np.s_[...,64:192,64:192]
    entries=[]
    with anchored((0,0)):
        reserved=local.partition()>=2
    for p in map(np.array,PATTERNS):
        raw=camera_pack(expected,p)
        pri=fit(raw,p,profile,wb,rgb_matrix,problem)
        assert pri['admit'] and pri['direction']==1,pri
        result=render(base,donor,wb,rgb_matrix,pri,'colour-confirmed')
        assert np.linalg.norm((result-expected)[coord])<.5*np.linalg.norm((donor-expected)[coord])
        y=np.einsum('c,chw->hw',(LUMA@rgb_matrix)*wb,result-donor)
        np.testing.assert_allclose(y,0,atol=2e-13,rtol=0)
        mutated=raw.copy()
        mutated[:,reserved]=np.random.default_rng(248767).uniform(.15,.34,(4,int(reserved.sum())))
        check=fit(mutated,p,profile,wb,rgb_matrix,problem)
        assert pri['phase']==check['phase'] and pri['colour_direction']==check['colour_direction']
        assert pri['folds'][:2]==check['folds'][:2] and pri['folds'][2:]!=check['folds'][2:]
        neutral=fit(camera_pack(donor,p),p,profile,wb,rgb_matrix,problem)
        assert not neutral['admit']
        np.testing.assert_array_equal(donor,render(base,donor,wb,rgb_matrix,neutral,'colour-confirmed'))
        entries.append({'cfa':p.tolist(),'signal_exists':True,'neutral_reject':True,
                        'held_preserves_discovery':True,'luma_absolute_max':float(abs(y).max()),
                        'remaining_RGB_error_ratio':float(np.linalg.norm((result-expected)[coord])/np.linalg.norm((donor-expected)[coord]))})
    return entries


def run():
    publication=read_json(ROOT/'plan.json')
    ids={r['source']['id'] for r in publication['sources']}
    assert len(ids)==24
    with checked(publication['training_manifest']).open()as f:
        train={json.loads(q)['id'] for q in f}
    assert len(train)==90692 and not ids&train
    for item in (publication['prior'],*publication['excluded']):
        selected=read_json(checked(item))
        before={r['source']['id'] for r in selected.get('sources',selected.get('rows',selected.get('heldout_rows',[])))}
        assert not before&ids
    write_json(ROOT/'audit.json',{'source':reference(ROOT/'plan.json'),'driver':reference(__file__),
              'noiseless_CFA_audit':check_geometry(),'distinct_photos':len(ids),'training_overlap':0,
              'nearby_photo_overlap':0,'prior_repeat_overlap':sum(r['in_prior_repeat_evaluation']for r in publication['sources'])})


if __name__=='__main__':
    run()
