"""Evaluate chroma recovery and neutral controls with the same native Bayer inputs."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'query-shared-gap-v1'))
from review import CORE, fields, rms
from colour import LUMA, POLICIES, ROOT, fit, render
from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ARMS=('parent','shared',*POLICIES)


def separated(rgb):
    y=np.einsum('c,bchw->bhw',LUMA,rgb)
    return y,rgb-y[:,None]


def score(row,plan,output):
    original,fixture=row
    data,outputs=fields(original)
    before=outputs['shared']
    parent=outputs['parent']
    pred={'parent':parent,'shared':before}|{k:before.copy() for k in POLICIES}
    profile=plan['profiles'][original['noise']]
    with np.load(checked(original['input']),allow_pickle=False)as f:
        alternate=f['rotated_packed'][...,64:192,64:192]
    receipts={}
    for name,observation in (('matching',data['packed']),('rotated',alternate)):
        saved=before if name=='matching'else outputs['rotated_shared']
        guard=original['checks'][name]
        shapes=[]
        for role,state in enumerate(guard):
            channels=[data[k][role]for k in ('wb','matrix')]
            option=fit(observation[role],data['colors'][role],profile,*channels,state)
            shapes.append(option)
            for policy in POLICIES:
                restored=render(parent[role],saved[role],*channels,option,policy)
                if name=='matching':
                    pred[policy][role]=restored
                if role>0 or name=='rotated':
                    assert np.array_equal(restored,saved[role]),(original['index'],original['noise'],name,role,policy)
        receipts[name]=shapes
    reference_rgb=linear_rgb(data['target'],data)
    truth_y,truth_c=separated(reference_rgb)
    base_y,base_c=separated(linear_rgb(before,data))
    exact=(truth_c[0]-truth_c[1])[:,CORE[0],CORE[1]]
    exact_y=(truth_y[0]-truth_y[1])[CORE]
    g=data['support'][CORE]
    intact=g>=.97
    if not intact.any():
        intact=np.ones_like(intact)
    selected=np.s_[...,CORE[0],CORE[1]]
    truth=exact[:,intact]
    energy=float(np.square(truth).sum())
    metrics={}
    for policy,value in pred.items():
        y,c=separated(linear_rgb(value,data))
        increment=(c[0]-c[1])[selected]
        yinc=(y[0]-y[1])[CORE]
        current=increment[:,intact]
        delta=(c[0]-base_c[0])[selected]
        entry={'present_colour_RMS_DN16':rms((c[0]-truth_c[0])[selected]),
               'intact_chroma_increment_RMS_DN16':rms((current-truth)),
               'full_chroma_increment_RMS_DN16':rms(increment-exact),
               'chroma_edit_RMS_DN16':rms(delta),
               'max_luma_change_DN16':float(np.max(abs(y-base_y))*65535),
               'luma_response':float(100*yinc[intact]@exact_y[intact]/(exact_y[intact]@exact_y[intact])),
               'aligned_chroma_response':None if energy<1e-7 else float(100*(current*truth).sum()/energy)}
        if (g==0).any():
            entry['inside_gap_new_colour_RMS_DN16']=rms(delta[:,g==0])
        if policy in POLICIES:
            assert entry['max_luma_change_DN16']<.024, entry
        metrics[policy]=entry
    output_file=output/f'{original["index"]:03d}-{original["noise"]}.npz'
    np.savez(output_file,**pred)
    return {k:original[k]for k in ('index','noise','input')}|{
        'earlier':original['output'],'prediction':reference(output_file),
        'color_role':fixture['geometry']['color_role'],'geometry_type':fixture['geometry']['family'],
        'metrics':metrics,'condition':receipts}


def cohort(rows):
    rng=np.random.default_rng(73116)
    assembled={}
    for profile in ('iso400','iso6400'):
        cases=[q for q in rows if q['noise']==profile]
        panels={}
        for label in ('neutral','green','signed','colored'):
            some=[q for q in cases if q['color_role']==label or (label=='colored'and q['color_role']!='neutral')]
            indexes=rng.integers(len(some),size=(10000,len(some)))
            controls={}
            for arm in ARMS:
                values={}
                for m in some[0]['metrics'][arm]:
                    if any(q['metrics'][arm].get(m)is None for q in some):
                        continue
                    v=np.array([q['metrics'][arm][m]for q in some])
                    base=np.array([q['metrics']['shared'][m]for q in some])
                    difference=v-base
                    values[m]={'mean':float(v.mean()),'paired_difference':[float(difference.mean()),*np.quantile(difference[indexes].mean(1),[.025,.975]).tolist()]}
                if arm in POLICIES:
                    edits=sum(q['metrics'][arm]['chroma_edit_RMS_DN16']>0 for q in some)
                else:
                    edits=0
                controls[arm]={'metrics':values,'nonzero_edit_count':edits}
            panels[label]={'accepted_donor':sum(r['condition']['matching'][0] is not None for r in some),'count':len(some),'arms':controls}
        assembled[profile]=panels
    return assembled


def main():
    link=reference(ROOT/'fresh-gap.json')
    values=read_json(checked(link))
    obs=read_json(checked(values['observations']))
    plan=read_json(checked(obs['source']))
    assert len(values['rows'])==48
    out=ROOT/'resolved'
    out.mkdir()
    jobs=((r,plan['sources'][r['index']])for r in values['rows'])
    started=time.monotonic()
    rows=[]
    with ThreadPoolExecutor(3)as pool:
        for r in pool.map(partial(score,plan=plan,output=out),jobs):
            rows.append(r)
            print(r['index'],r['noise'],r['color_role'],round(time.monotonic()-started,2),flush=True)
    write_json(ROOT/'scores.json',{'driver':reference(__file__),'policy':reference(ROOT/'colour.py'),'source':link,
          'checkpoint':values['checkpoint'],'summary':cohort(rows),'cases':rows,
          'scope':'48 fixtures from 24 photo IDs, two ISO priors, external-donor baseline with shared gap gating. Native held chroma compares inc, false-color controls and physical luma invariance.'})


if __name__=='__main__':
    main()
