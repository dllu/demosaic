"""Test which coloured misses remain with the planted frequency pair supplied."""
import numpy as np

from colour import ROOT,fit
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def run():
    checked_scores=reference(ROOT/'scores.json')
    excerpt=read_json(checked(checked_scores))
    spec=read_json(ROOT/'plan.json')
    probes=[]
    for result in excerpt['cases']:
        before=result['condition']['matching'][0]
        if before is not None and before['admit']:
            continue
        config=spec['sources'][result['index']]['geometry']
        candidate=[[*xy,0.] for xy in config['frequency']]
        rotated=[[*np.roll(x,1),0.] for x in config['frequency']]
        noise=spec['profiles'][result['noise']]
        with np.load(checked(result['input']),allow_pickle=False) as arrays:
            raw=arrays['packed'][0,:,64:192,64:192]
            cfa,wb,mat=[arrays[k][0]for k in ('colors','wb','matrix')]
        correct=fit(raw,cfa,noise,wb,mat,{'geometry':candidate})
        opposite=fit(raw,cfa,noise,wb,mat,{'geometry':rotated})
        probes.append({'id':result['index'],'noise':result['noise'],'colour':config['color_role'],
            'preceding_geometry_available':before is not None,'correct':correct,'transposed_frequency':opposite})
    labels={}
    for noise in spec['profiles']:
        vals={}
        for category in ('coloured','neutral'):
            group=[r for r in probes if r['noise']==noise and (r['colour']=='neutral')==(category=='neutral')]
            vals[category]={'count':len(group),'correct_weak_accepts':sum(v['correct']['admit'] and v['correct']['direction']==1 for v in group),
                            'opposite_weak_accepts':sum(v['transposed_frequency']['admit'] for v in group)}
        labels[noise]=vals
    write_json(ROOT/'frequency-ceiling.json',{'scores':checked_scores,'driver':reference(__file__),'sets':labels,
            'probes':probes,'scope':'Score-only evaluation on previous rejected roles. Planted frequencies enter the diagnostic. No evidence enters delivered restoration.'})


if __name__=='__main__':
    run()
