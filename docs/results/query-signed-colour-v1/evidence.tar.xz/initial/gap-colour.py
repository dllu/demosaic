"""Replay the new colour delta under the already confirmed shared gap taper."""
import numpy as np

from controls import assemble, measure
from colour import ROOT,X,Y
from check import area
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def run():
    score_binding=reference(ROOT/'scores.json')
    scores=read_json(checked(score_binding))
    shared=read_json(checked(scores['source']))
    evidence={}
    for noise in ('iso400','iso6400'):
        rows=[]
        for record, earlier in zip(scores['cases'],shared['rows'],strict=True):
            if record['noise']!=noise or record['color_role']=='neutral':
                continue
            case=assemble(record,earlier)
            old=earlier['checks']['matching'][0]
            profile=old['cut'].get('shared',0.)
            if profile>0:
                shape=old['chosen']['shared']['shape']
                gap=area(X.ravel(),Y.ravel(),shape)[0][:,0].reshape(X.shape)[64:192,64:192]
                strength=1.-profile*gap
            else:
                strength=1.
            target=case['shared'] + (case['colour-confirmed']-case['shared'])*strength
            rows.append(case|{'gap-taper':target})
        act='intact_response'
        target=measure(rows,'gap-taper',1.)[act]
        lo=measure(rows,'colour-confirmed',0.)[act]
        hi=measure(rows,'colour-confirmed',1.)[act]
        factor=(target-lo)/(hi-lo)
        evidence[noise]={
            'original':measure(rows,'colour-confirmed',1.),
            'existing_gap_taper':measure(rows,'gap-taper',1.),
            'same_response_uniform':measure(rows,'colour-confirmed',factor),
            'uniform_scale_from_exact_targets':factor,
            'rows_with_true_gap':sum((r['support']==0).any()for r in rows),
            'case_count':len(rows),
        }
    write_json(ROOT/'gap-colour.json',{'scores':score_binding,'driver':reference(__file__),
          'measurements':evidence,'scope':'Exploratory numerical replay on the primary test panel. Existing Bayer taper modulates the fixed edit. Exact target adjusts only the equal-response diagnostic. The rendered boards use the prospective policy.'})


if __name__=='__main__':
    run()
