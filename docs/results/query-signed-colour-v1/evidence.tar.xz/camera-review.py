"""Inspect a constrained chroma update above both standing GFX donor paths."""
import sys

import numpy as np
from PIL import Image
import torch

from colour import LUMA, POLICIES, PRIOR, ROOT, fit, render
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    mark=reference(PRIOR/'standing/manifest.json')
    previous=read_json(checked(mark))
    witness=reference(ROOT.parent/'query-checked-junctions-v1/standing/manifest.json')
    from_query={row['id']:row for row in read_json(checked(witness))['rows']}
    dest=ROOT/'standing'
    dest.mkdir()
    rows=[]
    for row in previous['rows']:
        key=row['id']
        x,y,w,h=row['box']
        a,b,c,d=row['ROI']
        box=(a-x,b-y,c,d)
        core=np.s_[...,box[1]:box[1]+d,box[0]:box[0]+c]
        with np.load(checked(row['base_input']),allow_pickle=False)as f:
            raw=f['packed'][0,:,y//2:(y+h)//2,x//2:(x+w)//2]
            cfa,wb,mat=[f[k][0]for k in ('colors','wb','matrix')]
        with np.load(checked(row['arrays']),allow_pickle=False)as f:
            parent,before=[f[k]for k in ('parent','shared')]
        other=from_query[key]
        assert other['query_box']==row['box'] and other['input']==row['base_input']
        state=row['fit']
        path='exterior'
        if 'geometry' not in state:
            path='existing-local'
            state=other['new_geometry'] or {}
        evidence=fit(raw,cfa,row['noise'],wb,mat,state)
        results={k:render(parent,before,wb,mat,evidence,k)for k in POLICIES}
        image=np.asarray(Image.open(checked(row['image'])).convert('RGB'))
        available={p['name']:image[y:y+h,x:x+w]for p in row['panels']for x,y,w,h in (p['png_xywh'],)}
        labels=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Shared-wave deficit')
        panels=[(k,available[k])for k in labels if k in available]
        addition={}
        for method,caption in zip(POLICIES,('Unchecked colour','Reserved Bayer colour'),strict=True):
            pixels=results[method]
            delta=(pixels[core].astype(float)-before[core])
            luma=np.einsum('c,chw->hw',(LUMA@mat)*wb,delta)
            addition[method]={'camera_RGB_RMS_DN16':float(np.sqrt(np.mean(delta**2))*65535),
                              'max_linear_luma_change_DN16':float(np.max(abs(luma))*65535)}
            rgba=display_crop(torch.from_numpy(pixels[None]),torch.from_numpy(wb[None]),
                         torch.from_numpy(mat[None]),box,exposure=row['display_exposure'])
            panels.append((caption,np.rint(rgba*255).astype(np.uint8)))
        panels.extend((k,available[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in available)
        board=native_png(dest/(key+'.png'),panels)
        path_to=dest/(key+'.npz')
        np.savez(path_to, parent=parent, shared=before,**results)
        rows.append({k:row[k]for k in ('id','ROI','box','noise','display_exposure','base_input')}|board|
                    {'gate':evidence,'candidate_source':path,'earlier_arrays':row['arrays'],
                     'output':reference(path_to),'earlier_pixels':row['image'],'measurements':addition})
        print(key,evidence and evidence['admit'],addition,flush=True)
    assert len(rows)==8
    write_json(dest/'manifest.json',{'driver':reference(__file__),'checkpoint':previous['checkpoint'],
                             'previous':mark,'geometry':witness,'rows':rows})


if __name__=='__main__':
    main()
