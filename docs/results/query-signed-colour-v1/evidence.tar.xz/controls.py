"""Measure neutral replay and compare a uniform correction at matched chroma response."""
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'query-shared-gap-v1'))
from review import CORE, fields, rms
from colour import ROOT, fit, render
from score_cases import separated
from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def assemble(record, original):
    data,_=fields(original)
    Y,C=separated(linear_rgb(data['target'],data))
    ix=np.s_[...,CORE[0],CORE[1]]
    target=C[ix]
    with np.load(checked(record['prediction']),allow_pickle=False)as f:
        predictions={k:separated(linear_rgb(f[k],data))[1][ix]for k in ('shared','colour-confirmed','colour-unchecked')}
    return {'index':record['index'],'label':record['color_role'],'target':target,'support':data['support'][CORE]} | predictions


def measure(rows, method, factor):
    information=[]
    for row in rows:
        base=row['shared']
        current=base+factor*(row[method]-base)
        alive=row['support']>=.97
        if not alive.any():
            alive=np.ones_like(alive)
        actual=(current[0]-current[1])[:,alive]
        true=(row['target'][0]-row['target'][1])[:,alive]
        g=row['support']==0
        denom=(true*true).sum()
        values={'present_RMS':rms(current[0]-row['target'][0]),
                'increment_intact_RMS':rms(actual-true),'edit_RMS':rms(current[0]-base[0]),
                'intact_response':float(100*(actual*true).sum()/denom)if denom>1e-7 else None,
                'gap_added_RMS':rms((current[0]-base[0])[:,g])if g.any()else None}
        information.append(values)
    return {k:float(np.mean([r[k] for r in information if r[k] is not None])) if any(r[k] is not None for r in information)else None
            for k in information[0]}


def compare_strength():
    source=reference(ROOT/'scores.json')
    score=read_json(checked(source))
    foundation=read_json(checked(score['source']))
    controls={}
    for noise in ('iso400','iso6400'):
        actual=[assemble(r,p)for r,p in zip(score['cases'],foundation['rows'],strict=True)if r['noise']==noise]
        colored=[r for r in actual if r['label']!='neutral']
        neutral=[r for r in actual if r['label']=='neutral']
        index='intact_response'
        target=measure(colored,'colour-confirmed',1.)[index]
        plain=measure(colored,'colour-unchecked',0.)[index]
        high=measure(colored,'colour-unchecked',1.)[index]
        factor=(target-plain)/(high-plain)
        own={'shared':('shared',0.),'validated':('colour-confirmed',1.),
             'unchecked':('colour-unchecked',1.),'response-matched-unchecked':('colour-unchecked',factor)}
        controls[noise]={'gain_for_matched_response':factor,'uses_exact_RGB_for_scale':True,
                         'colored':{arm:measure(colored,*choice) for arm,choice in own.items()},
                         'neutral':{arm:measure(neutral,*choice) for arm,choice in own.items()}}
    return controls


def neutral_archive():
    data=[]
    for study in ('query-shared-gap-v1','query-gap-shoulders-v1'):
        upstream=reference(ROOT.parent/study/'fresh-gap.json')
        legend=read_json(checked(upstream))
        cohort=read_json(checked(legend['observations']))
        plan=read_json(checked(cohort['source']))
        cohort=[]
        for row in legend['rows']:
            info,images=fields(row)
            state=row['checks']['matching'][0]
            norm,mat=[info[k][0]for k in ('wb','matrix')]
            origin,baseline=images['parent'][0],images['shared'][0]
            evidence=fit(info['packed'][0],info['colors'][0],plan['profiles'][row['noise']],norm,mat,state)
            chroma_before=separated(linear_rgb(baseline[None],{k:info[k][:1]for k in ('wb','matrix')}))[1][0]
            from_gate={}
            for method in ('colour-unchecked','colour-confirmed'):
                result=render(origin,baseline,norm,mat,evidence,method)
                after=separated(linear_rgb(result[None],{k:info[k][:1]for k in ('wb','matrix')}))[1][0]
                from_gate[method]=rms((after-chroma_before)[:,CORE[0],CORE[1]])
            cohort.append({'index':row['index'],'input':row['input'],'baseline':row['output'],'evidence':evidence,'mean_chroma_change_DN16':from_gate})
        data.append({'source':upstream,'study':study,'cases':cohort})
    return data


if __name__=='__main__':
    write_json(ROOT/'controls.json',{'driver':reference(__file__),'metrics':reference(ROOT/'scores.json'),
          'neutral_replays':neutral_archive(),'matched_response':compare_strength(),
          'scope':'48 older neutral photo roles and an exact-target calibrated strength control. The render uses frozen inference gains.'})
