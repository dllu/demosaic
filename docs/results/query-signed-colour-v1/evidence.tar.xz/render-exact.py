"""Publish unresized green and signed-colour holdout examples."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from colour import ROOT,POLICIES
from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

PIX=np.s_[...,48:208,48:208]


def main():
    torch.set_num_threads(2)
    evidence=reference(ROOT/'scores.json')
    measured=read_json(checked(evidence))
    plan=read_json(ROOT/'plan.json')
    destination=ROOT/'native'
    destination.mkdir()
    rows=[]
    for key in (1,20):
        r=next(q for q in measured['cases']if q['noise']=='iso6400'and q['index']==key)
        assert r['condition']['matching'][0]['admit']
        photo=plan['sources'][key]
        with np.load(checked(r['input']),allow_pickle=False) as physics:
            noisy=malvar(torch.from_numpy(physics['packed'][...,64:192,64:192].copy()),torch.from_numpy(physics['colors'])).numpy()
            reference_linear=physics['target'][...,128:384,128:384]
            calibrate={k:physics[k]for k in ('wb','matrix')}
        with np.load(checked(r['prediction']),allow_pickle=False) as f:
            predictions={k:f[k]for k in ('parent','shared',*POLICIES)}
        views={k:np.rint(display(v[PIX],calibrate,exposure=2).transpose(0,2,3,1)*255).astype(np.uint8)
              for k,v in (predictions|{'noisy':noisy,'GT':reference_linear}).items()}
        board=[]
        for label,role,names in (
            ('triplet',0,('noisy','colour-confirmed','GT')),
            ('comparison',0,('noisy','parent','shared',*POLICIES,'GT')),
            ('quiet',3,('noisy','parent','shared',*POLICIES,'GT')),
        ):
            path=destination/f'{key:03d}-iso6400-{label}.png'
            Image.fromarray(np.concatenate([views[name][role]for name in names],axis=1)).save(path,optimize=True)
            board.append({'image':reference(path),'role':label,'order':names})
        rows.append({'index':key,'source':photo['source'],'source_box':photo['box'],'CFA':photo['camera']['pattern'],
                     'profile':plan['profiles'][r['noise']],'capture_black':photo['camera']['black'],'color':r['color_role'],
                     'luminance_noise':'Independent ISO6400 observed present versus absent',
                     'ROI':[48,48,160,160],'display_exposure':2,'input':r['input'],'output':r['prediction'],'boards':board})
    write_json(destination/'manifest.json',{'driver':reference(__file__),'source':evidence,'checkpoint':measured['checkpoint'],
                 'selection':'One green and one signed-color example improving exact intact chroma error, displayed at native 100%.',
                 'rows':rows})


if __name__=='__main__':
    main()
