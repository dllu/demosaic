"""Qualify an intensity-boundary nuisance on the phase reserve alone."""

import math
import os
from itertools import product

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from fresh import CENTRE, DISPLAY, ROOT, infer_geometry, score, window
from gap import complete_mask, measurement
from oracle import partition
from rank import run_policy


def column(x, y, angle, offset, width):
    return np.tanh((np.cos(angle) * x + np.sin(angle) * y - offset) / width)


def select_step(data):
    x, y, colors, slots, wave, nuisance, raw, noise = data
    reserve = slots == 0
    positions = x[reserve], y[reserve]
    basis = np.column_stack((nuisance, wave))[reserve]
    groups = []
    for color in range(3):
        take = colors[reserve] == color
        q, _ = np.linalg.qr(basis[take], mode="reduced")
        values = raw[reserve][take]
        residual = values - q @ (q.T @ values)
        variance = noise["shot"] * max(1e-4, np.median(values)) + noise["read"]
        groups.append((take, q, residual, variance))

    def best(search):
        choice = None
        for start in range(0, len(search), 24):
            options = search[start:start + 24]
            predictors = np.column_stack([column(*positions, *candidate) for candidate in options])
            gains = np.zeros(len(options))
            for take, q, residual, variance in groups:
                design = predictors[take]
                design -= q @ (q.T @ design)
                gains += (residual @ design)**2 / (
                    np.maximum(np.sum(design**2, axis=0), 1e-12) * variance)
            idx = int(gains.argmax())
            if choice is None or gains[idx] > choice[0]:
                choice = float(gains[idx]), tuple(map(float, options[idx]))
        return choice

    rough = list(product(np.arange(12) * np.pi / 12, range(-72, 73, 24), (2.5, 8)))
    strength, shape = best(rough)
    if strength < 48:
        return data, {"screen_gain": strength}
    angle, offset, _ = shape
    refined = list(product(
        angle + np.deg2rad([-6, -3, 0, 3, 6]),
        offset + np.arange(-12, 13, 3), (2.5, 5, 8),
    ))
    refined_strength, refined_shape = best(refined)
    if refined_strength > strength:
        strength, shape = refined_strength, refined_shape
    new_basis = np.column_stack((nuisance, column(x, y, *shape)))
    return (*data[:5], new_basis, *data[6:]), {"screen_gain": strength, "shape": shape}


def main():
    source = read_json(ROOT / "fresh.json")
    plan = read_json(checked(source["plan"]))
    cases = []
    for binding in source["cases"]:
        row = read_json(checked(binding))
        with np.load(checked(row["source"]), allow_pickle=False) as archive:
            saved = dict(archive)
        broad = saved["matching-wide"]
        modified = broad.copy()
        trace = row["witnesses"]["matching"]["source_geometry"]
        noise = plan["noise"][row["entry"]["profile"]]
        notes = []
        for role, correction in enumerate(broad):
            if not correction.any():
                continue
            raw = window(saved["packed"][role], CENTRE, phase=2)
            cfa = saved["colors"][role]
            geometry, _ = infer_geometry(trace, raw, cfa, noise, (383.5, 383.5))
            data = measurement(raw, cfa, geometry, noise)
            data = (*data[:3], partition(raw.shape, "balanced"), *data[4:])
            data, step = select_step(data)
            mark, evidence = run_policy(data, "proxy")
            if mark is not None:
                x, y, w, h = DISPLAY
                mask = complete_mask([mark, mark], (CENTRE[3], CENTRE[2]))
                tx, ty = x - CENTRE[0], y - CENTRE[1]
                modified[role] = correction * (1 - mask[ty:ty + h, tx:tx + w][None])
            notes.append({"role": role, "step": step, "evidence": evidence})
        masks = {key: saved[key] for key in ("strong_phase", "weak_phase", "support")}
        outcome = score(saved["parent"], modified, saved["target"], masks)
        base = row["metrics"]["matching-balanced-proxy"]
        cases.append({"id": row["id"], "case": binding, "notes": notes, "outcome": outcome, "base": base})
        print(row["id"], [(x["step"], x["evidence"]["status"]) for x in notes],
              [round(100*s["response"][0], 2) for s in (base, outcome)],
              [s["gap_added_RMS_DN16"] for s in (base, outcome)], flush=True)
    write_json(ROOT / "step-replay.json", {
        "source": reference(ROOT / "fresh.json"), "driver": reference(__file__),
        "scope": "Exploratory matching-exterior replay after viewing fresh outcomes. Select an intensity step using phase-reserve pixels only. All compared forecasts use the shared nuisance. The phase and correction remain fixed.",
        "cases": cases,
    })


if __name__ == "__main__":
    os.sched_setaffinity(0, [12, 13])
    os.nice(12)
    main()
