"""Crossed gap tests on the 30 previous exact Bayer cases."""

import os
import time
from pathlib import Path

import numpy as np

from oracle import ROOT,PREVIOUS,CENTRE,infer_geometry,window
from replay import score,DISPLAY
from rank import apply,exact_rank
from gap import REGIONS, forecast, measurement
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

POLICIES=('columns-proxy','columns-exact','balanced-proxy','balanced-exact')


def main():
    old=read_json(PREVIOUS/'fresh.json');plan=read_json(checked(old['plan']));out=ROOT/'development';out.mkdir()
    rows=[];start=time.monotonic(); verified=False
    for pkg in old['cases']:
        case=read_json(checked(pkg));name=case['id'];noise=plan['noise'][case['entry']['profile']]
        with np.load(checked(case['arrays']),allow_pickle=False)as f:
            saved=dict(f)
        all_policies={};stats={}; stored={}
        for exterior in ('matching','unrelated'):
            broad=saved[exterior+'-projective']; trace=case['witness'][exterior]['exterior']
            masks={k:saved[k]for k in ('strong_phase','weak_phase','support')}
            stats[exterior]={}; all_policies[exterior]={}
            phases=[]
            for i,d in enumerate(broad):
                if np.any(d):
                    packed=window(saved['packed'][i],CENTRE,phase=2)
                    pair,_=infer_geometry(trace,packed,saved['colors'][i],noise,(383.5,383.5))
                    if not verified:
                        data=measurement(packed,saved['colors'][i],pair,noise)
                        subset=data[3]==1
                        example=REGIONS[91:98]
                        formula=exact_rank(data,subset,example)[:,0]
                        direct=[forecast(data,subset,subset,r.mask(*data[:2]))['gain']for r in example]
                        np.testing.assert_allclose(formula,direct,atol=2e-8,rtol=0)
                        verified=True
                else:
                    pair=None
                phases.append(pair)
            for policy in POLICIES:
                diffs=[];reports=[]
                for i,d in enumerate(broad):
                    result,note=apply(d,saved['packed'][i],saved['colors'][i],phases[i],noise,CENTRE,DISPLAY,policy)
                    diffs.append(result);reports.append(note)
                result=np.stack(diffs)
                if policy=='columns-proxy':
                    np.testing.assert_array_equal(result,saved[exterior+'-crossed'])
                assert not (np.abs(result)>np.abs(broad)).any()
                stored[exterior+'-'+policy]=result
                stats[exterior][policy]=score(saved['parent'],result,saved['target'],masks)
                all_policies[exterior][policy]=reports
        destination=out/(name+'.npz');np.savez_compressed(destination,**stored)
        rows.append({'id':name,'source':pkg,'phase_matrix_verified':verified,'entry':case['entry'],'metrics':stats,'notes':all_policies,'deltas':reference(destination)})
        print(name,[(k,r[1]['status'],[round(v['z'],2)for v in r[1].get('predictions',[])],round(stats['matching'][k]['gap_added_RMS_DN16'] or 0,2))for k,r in all_policies['matching'].items()],round(time.monotonic()-start,1),flush=True)
    assert len(rows)==30 and verified
    write_json(ROOT/'development.json',{'driver':reference(__file__),'method':reference(ROOT/'rank.py'),'source':reference(PREVIOUS/'fresh.json'),
      'scope':'Development replay with matched measured guides. Holdout phases stay unchanged across four policies. Exact-fit proposal scores are independently compared with the direct fit. Columns and proxy ranking reproduce the previous crossed predictions bitwise.','cases':rows})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
