"""Publish renderings and bind the compact measurements and frozen sources."""

import hashlib
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
repo = root.parents[2]
images = repo / "docs/images/local-mesh-distributed-audit-v1"
results = repo / "docs/results/local-mesh-distributed-audit-v1"
images.mkdir(exist_ok=True)
results.mkdir(exist_ok=True)


def portable(path):
    return {"path": str(path.relative_to(repo)), "sha256": reference(path)["sha256"]}


def publish_image(binding, panels):
    source = checked(binding)
    target = images / source.name
    shutil.copyfile(source, target)
    with Image.open(target) as board:
        for panel in panels:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160) and x + w <= board.width and y + h <= board.height
    bound = portable(target)
    assert bound["sha256"] == binding["sha256"]
    return bound


notes = {
    "iso400-band-g141": "The distributed fit reduces the faint short repeats within the gap. The bright diagonal wires and a soft edge remain visible.",
    "iso400-disk-g141": "The distributed output matches the local trunk within the scored round gap. The weaker direction outside remains softer than the exact target.",
    "iso400-disk-g143": "The two audits preserve the same added fine diagonal continuation inside the gap. Some is visible as faint modulation by the strong green lines.",
    "iso400-step-g145": "The continuous rear direction becomes fainter through part of the step in the distributed output. The strong green wires remain intact.",
    "main-chain-link-fence-main-chain-link-fence": "Both audit layouts preserve visible coarse crossings and the same out-of-focus strip near the mark.",
    "main-foliage-main-foliage": "Leaf borders and dark background have matching texture in the two layouts.",
    "main-overcast-sky-main-overcast-sky": "Even gray sky after the shared local estimate. Both layouts show the same absence of pattern.",
    "main-building-detail-main-building-detail": "Thin structure remains soft in the same places in both layouts.",
    "mesh-nominal-fine-green-mesh-left": "The same faint lattice left of the post remains with both layouts.",
    "mesh-nominal-fine-green-mesh-right": "The right mesh remains soft with incomplete crossings.",
    "mesh-profile3879-fine-green-mesh-left": "Both retain the faint lattice and the same background unevenness.",
    "mesh-profile3879-fine-green-mesh-right": "Faint diagonal structure and residual unevenness are identical. The fine crossings remain incomplete.",
}
camera = read_json(root / "camera.json")
checked(camera["source"])
checked(camera["checkpoint"])
published_camera = []
for row in camera["results"]:
    assert row["changes_DN16"] == 0
    for key in ("source", "RAW", "input", "native_delta"):
        checked(row[key])
    view = {k: v for k, v in row.items() if k not in ("image", "balanced", "columns")}
    view["image"] = publish_image(row["image"], row["panels"])
    view["observation"] = notes[row["id"]]
    published_camera.append(view)
assert len(published_camera) == 8

summary = read_json(root / "summary.json")
assert summary["metrics_recomputed_exactly"]
published_synthetic = []
for row in summary["native"]:
    view = {k: v for k, v in row.items() if k not in ("board", "triplet")}
    for key in ("case", "arrays", "checkpoint"):
        checked(row[key])
    for key in ("board", "triplet"):
        if key == "triplet" and row["id"] not in ("iso400-band-g141", "iso400-disk-g141"):
            continue
        original = row[key]
        view[key] = {
            "image": publish_image(original["image"], original["panels"]),
            "panels": original["panels"],
        }
    view["observation"] = notes[row["id"]]
    published_synthetic.append(view)
assert len(published_synthetic) == 4 and sum("triplet" in r for r in published_synthetic) == 2
viewing = results / "viewing.json"
write_json(viewing, {
    "recorded_utc": datetime.now(UTC).isoformat(),
    "actual_native_viewing": True,
    "camera_checkpoint": camera["checkpoint"],
    "camera": published_camera,
    "exact_synthetic": published_synthetic,
})

for name in ("summary.json", "step-replay.json"):
    shutil.copyfile(root / name, results / name)

names = (
    "oracle.py", "oracle.json", "oracle.log", "rank.py", "observations.py",
    "development.py", "development.json", "development.log", "fresh.py", "fresh-plan.json",
    "fresh.json", "fresh.log", "camera.py", "camera.json", "camera.log",
    "report-data.py", "summary.json", "summary.log", "step-replay.py", "step-replay.json",
    "step-replay.log", "publish.py",
)
files = {name: root / name for name in names}
files.update({p.relative_to(root).as_posix(): p for p in (root / "fresh").glob("*.json")})
assert len(files) == len(names) + 30
bundle = results / "evidence.tar.xz"
with tarfile.open(bundle, "x:xz", preset=4) as packed:
    for name, source in files.items():
        packed.add(source, arcname=name)
contents = {name: reference(path) for name, path in files.items()}
with tarfile.open(bundle, "r:xz") as packed:
    assert set(packed.getnames()) == set(files)
    for name, bound in contents.items():
        assert hashlib.sha256(packed.extractfile(name).read()).hexdigest() == bound["sha256"]

previous = repo / "docs/results/local-mesh-gap-support-v1/evidence.tar.xz"
wide = repo / "docs/results/local-mesh-projective-v1/evidence.tar.xz"
if not wide.exists():
    wide = next((repo / "docs/results").glob("local-mesh-projective*/evidence.tar.xz"))
write_json(results / "publication.json", {
    "scope": "Paired research replay with the archived wide donor fit. No model training. No full primary metrics. Large arrays and local inputs are retained in cache and recorded by digest.",
    "synthetic": portable(results / "summary.json"),
    "fresh_cases": len(summary["cases"]),
    "after_viewing_step_replay": portable(results / "step-replay.json"),
    "actual_viewing": portable(viewing),
    "camera_crops": len(published_camera),
    "archive": portable(bundle),
    "archive_contents": contents,
    "prior_source_archives": [portable(previous), portable(wide)],
})
