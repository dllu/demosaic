"""Validate a spatially distributed RAW audit on fresh exact-reference mesh gaps."""

import importlib.util
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from oracle import ROOT,PREVIOUS,CENTRE,infer_geometry,window
from replay import SOURCE,DISPLAY,score
from deliver import proposals,shift_prior
from rank import apply
from run import SHIFTS
from stabilize import median_correction


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m


sampler=module(ROOT/'observations.py','gap_observations')
refined=module(SOURCE/'deliver-short.py','projected_fit')
short=module(SOURCE/'short-support.py','short_support')
MODES=('wide','short','columns-proxy','balanced-proxy')


def observe(g,layout,noise,seed,stress):
    inputs,exterior,masks,sensor,geometry=sampler.observe(g,layout,noise,seed)
    if stress:
        # Add common row and column variation after the existing ADC pass.
        raw=inputs['packed']; packed_h,packed_w=raw.shape[-2:]
        random=torch.Generator().manual_seed(seed+190459)
        dy=torch.randn(2*packed_h,generator=random)*1.6e-4
        dx=torch.randn(2*packed_w,generator=random)*1.0e-4
        f=torch.stack([dy[j::2,None]+dx[i::2][None,:]for j,i in ((0,0),(0,1),(1,0),(1,1))])
        inputs['packed']=(raw+f[None]).clamp(0,1)
        inputs['variance']=sampler.variance_map(inputs['packed'],noise['shot'],noise['read'])
    return inputs,exterior,masks,sensor,geometry


def estimate(field,packed,var,layout,proposal,trace,noise):
    if proposal is None:
        empty=np.zeros_like(window(field,DISPLAY));return {k:empty for k in MODES},{}
    wide=[];narrow=[]
    for dx,dy in SHIFTS:
        box=(CENTRE[0]+dx,CENTRE[1]+dy,*CENTRE[2:])
        f,g=shift_prior(*proposal['projective'],dx,dy)
        correction,detail=refined.correction(field,packed,var,layout,box,DISPLAY,f,g,noise,packed_offset=dx//2)
        wide.append(correction)
        narrow.append(short.shorten(correction,window(packed,box,phase=2),layout,detail.get('phase_candidates'),noise,box,DISPLAY,dx//2))
    broad,small=median_correction(wide),median_correction(narrow)
    output={'wide':broad,'short':small}; details={}
    pair=None
    if np.any(broad):
        pair,_=infer_geometry(trace,window(packed,CENTRE,phase=2),layout,noise,(383.5,383.5))
    for key in ('columns-proxy','balanced-proxy'):
        output[key],details[key]=apply(broad,packed,layout,pair,noise,CENTRE,DISPLAY,key)
    return output,details


@torch.inference_mode()
def main():
    previous=read_json(PREVIOUS/'fresh-plan.json'); bound=previous['checkpoint']
    dest=ROOT/'fresh';dest.mkdir()
    entries=[('iso400',l,g)for l in ('continuous','step','band','disk')for g in range(140,146)]
    entries += [('iso6400','band'if g%2 else'disk',g)for g in range(140,146)]
    entries=[{'profile':p,'layout':l,'g':g,'seed':38042712331+i*437+g*283,'read_stress':g%2==0}
             for i,(p,l,g)in enumerate(entries)]
    plan={'runner':reference(__file__),'code':[reference(ROOT/f'{name}.py')for name in ('oracle','rank','observations')],
        'checkpoint':bound,'reference':reference(PREVIOUS/'fresh-plan.json'),'cases':entries,'variants':MODES,
        'shifts':SHIFTS,'noise':previous['noise'],'query':CENTRE,'ROI':DISPLAY,
        'read_stress':{'row_std':1.6e-4,'column_std':1e-4,'scope':'Shared native row and column additive variation, after ADC, clipped to RAW range, same in paired roles. Nominal prior passed unchanged.'},
        'scope':'All 30 new inputs share their local prediction across the four attenuation policies. Phase selection retains its original reserve. Rotated and matching exterior patches produce separate diagnostics. The new balanced allocator changes only crossed/audit membership on nonphase sites.'}
    write_json(ROOT/'fresh-plan.json',plan)
    model,state=load_scene_checkpoint(checked(bound),device='cuda',weights='ema',expected_sha256=bound['sha256'])
    assert state['step']==2000
    model.mode='none';del state
    begin=time.monotonic(); results=[]
    with ieee_fp32():
        for entry in entries:
            layout,g,profile,seed=(entry[key]for key in ('layout','g','profile','seed'))
            name=f'{profile}-{layout}-g{g}';noise=plan['noise'][profile]
            inputs,outsides,masks,sensor,shape=observe(g,layout,noise,seed,entry['read_stress'])
            model.base.set_noise(noise['shot'],noise['read'])
            parent=model(*(inputs[k].cuda()for k in ('packed','variance','colors','wb','matrix'))).cpu().numpy()
            raw,var,colors,target=(inputs[key].numpy()for key in ('packed','variance','colors','target'))
            metrics={'parent':score(parent,None,target,masks)}; trials={}; resume={}
            for context,scene in outsides.items():
                f,trace=proposals(scene,colors[0],(256,256,256,256),noise,80)
                now={}; matters=[]
                for i in (0,1,2):
                    variants,review=estimate(parent[i],raw[i],var[i],colors[i],f,trace,noise)
                    matters.append(review)
                    for key,d in variants.items():now.setdefault(key,[]).append(d)
                trials[context]={'source_geometry':trace,'evidence':matters}
                for kind,values in now.items():
                    key=context+'-'+kind
                    delta=np.stack(values);resume[key]=delta;metrics[key]=score(parent,delta,target,masks)
            output=dest/(name+'.npz');np.savez_compressed(output,**{k:v.numpy()for k,v in inputs.items()},**masks,parent=parent,**resume)
            d={'id':name,'entry':entry,'shape':shape,'sensor':sensor,'witnesses':trials,'metrics':metrics,
               'source':reference(output),'fingerprints':{key:fingerprint(v)for key,v in inputs.items()}}
            path=dest/(name+'.json');write_json(path,d);results.append(reference(path))
            print(name,[(k,round(v['response'][0],4),round(v['gap_added_RMS_DN16'] or 0,3),v['changed'])for k,v in metrics.items()if k.startswith('matching-')],round(time.monotonic()-begin,1),flush=True)
    assert len(results)==30
    write_json(ROOT/'fresh.json',{'plan':reference(ROOT/'fresh-plan.json'),'cases':results,'seconds':time.monotonic()-begin})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
