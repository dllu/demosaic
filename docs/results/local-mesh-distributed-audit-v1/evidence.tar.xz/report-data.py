"""Recompute fresh metrics and compose native exact-reference boards."""

from statistics import mean

import numpy as np
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board

from fresh import DISPLAY, MODES, ROOT, score


def main():
    source = read_json(ROOT / "fresh.json")
    plan = read_json(checked(source["plan"]))
    image_dir = ROOT / "native"
    image_dir.mkdir(exist_ok=True)
    selected = {
        "iso400-band-g141",
        "iso400-disk-g141",
        "iso400-step-g145",
        "iso400-disk-g143",
    }
    rows, boards = [], []
    for binding in source["cases"]:
        row = read_json(checked(binding))
        name, entry = row["id"], row["entry"]
        with np.load(checked(row["source"]), allow_pickle=False) as file:
            arrays = dict(file)
        masks = {key: arrays[key] for key in ("strong_phase", "weak_phase", "support")}
        parent, target = arrays["parent"], arrays["target"]
        measurements = {}
        for key, expected in row["metrics"].items():
            correction = None if key == "parent" else arrays[key]
            actual = score(parent, correction, target, masks)
            assert actual == expected, (name, key)
            if correction is not None:
                context, _ = key.split("-", 1)
                wide = arrays[context + "-wide"]
                actual["changed_from_wide"] = [
                    not np.array_equal(candidate, baseline)
                    for candidate, baseline in zip(correction, wide, strict=True)
                ]
            measurements[key] = actual
        rows.append({
            "id": name,
            "entry": entry,
            "record": binding,
            "metrics": measurements,
        })
        if name not in selected:
            continue
        role = 1
        labels = (
            "Noisy Malvar", "Local trunk", "Wide support", "Short support",
            "Column Bayer audit", "Distributed Bayer audit", "Exact GT",
        )
        x, y, w, h = DISPLAY
        views = [noisy_malvar(arrays)[role], parent[role]]
        for method in MODES:
            candidate = parent[role].copy()
            candidate[:, y:y + h, x:x + w] += arrays["matching-" + method][role]
            views.append(candidate)
        views.append(target[role])
        metadata = {
            "case": binding,
            "arrays": row["source"],
            "checkpoint": plan["checkpoint"],
            "noise": plan["noise"][entry["profile"]],
            "CFA": row["shape"]["CFA"],
            "seed": entry["seed"],
            "read_stress": entry["read_stress"],
        }
        boards.append(native_board(
            image_dir, name, views,
            {key: arrays[key][role:role + 1] for key in ("wb", "matrix")},
            metadata, labels=labels, triplet_indices=(0, 5, 6),
            roi=DISPLAY, exposure=1, contrast=8,
        ))

    means = {}
    for layout in ("continuous", "step", "band", "disk", "gaps"):
        cases = [
            row for row in rows
            if (row["entry"]["profile"] == "iso6400" if layout == "gaps" else
                row["entry"]["profile"] == "iso400" and row["entry"]["layout"] == layout)
        ]
        assert len(cases) == 6
        means[layout] = {}
        for key in cases[0]["metrics"]:
            values = [row["metrics"][key] for row in cases]
            result = {
                "weak_response_pct": 100 * mean(v["response"][0] for v in values),
                "weak_error_DN16": mean(v["increment_RMS_DN16"][0] for v in values),
                "changed": [sum(v["changed"][i] for v in values) for i in range(3)],
            }
            if "changed_from_wide" in values[0]:
                result["changed_from_wide"] = [
                    sum(v["changed_from_wide"][i] for v in values) for i in range(3)
                ]
            for metric in ("gap_added_RMS_DN16", "gap_error_RMS_DN16"):
                if values[0][metric] is not None:
                    result[metric] = mean(v[metric] for v in values)
            means[layout][key] = result
            if key.startswith("matching-"):
                print(layout, key, result)
    assert len(rows) == 30 and len(boards) == 4
    write_json(ROOT / "summary.json", {
        "driver": reference(__file__), "fresh": reference(ROOT / "fresh.json"),
        "cases": rows, "means": means, "native": boards, "metrics_recomputed_exactly": True,
    })


if __name__ == "__main__":
    main()
