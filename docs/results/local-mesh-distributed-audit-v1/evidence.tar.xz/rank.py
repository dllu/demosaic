"""Search gap shapes under the same nuisance model used to audit them."""

import math

import numpy as np

from oracle import partition
from gap import REGIONS, complete_mask, forecast, measurement, nominate


def _fit_score(q, y, m):
    """Residual energy explained by one wave after projecting out one mask."""
    power = np.sum(m*m, axis=0)
    p = np.maximum(power, 1e-12)
    cross = np.sum(q*m, axis=0)
    projection = np.sum(q*y[:,None], axis=0) - cross*(y@m)/p
    denominator = np.sum(q*q, axis=0) - cross*cross/p
    return projection**2 / np.maximum(denominator,1e-12)


def exact_rank(data, selection, candidates=REGIONS):
    x,y,c,_,q,nuisance,raw,noise=data
    subsets=[]
    for color in range(3):
        keep=selection&(c==color)
        d,_=np.linalg.qr(nuisance[keep],mode='reduced')
        y0=raw[keep]; v=1/(noise['shot']*max(1e-4,float(np.median(y0)))+noise['read'])
        s=y0-d@(d.T@y0);p=q[keep];perp=p-d@(d.T@p)
        amplitude=float(perp@s/max(perp@perp,1e-12))
        subsets.append((x[keep],y[keep],p,perp,d,s,v,amplitude))
    values=[]
    for start in range(0,len(candidates),24):
        current=candidates[start:start+24]
        best=np.zeros(len(current)); signal=np.zeros(len(current))
        for u,w,p,perp,d,s,v,amp in subsets:
            mask=np.stack([mark.mask(u,w)for mark in current],axis=1)
            stripped=p[:,None]*(1-mask)
            m=mask-d@(d.T@mask)
            b=stripped-d@(d.T@stripped)
            gain=_fit_score(b,s,m)-_fit_score(perp[:,None],s,m)
            best+=v*gain
            signal+=v*amp**2*(perp**2)@(mask*mask)
        values.extend(zip(best,signal,strict=True))
    return np.asarray(values)


def exact_nominate(data, selection):
    scores=exact_rank(data,selection)
    available=scores[:,1]>=4
    if not available.any():
        return None
    index=int(np.argmax(np.where(available,scores[:,0],-np.inf)))
    return float(scores[index,0]),REGIONS[index]


def run_policy(data, mode):
    _,_,_,slot,*_=data
    a,b,d=slot==1,slot==2,slot==3
    method=nominate if mode=='proxy' else exact_nominate
    proposed=[]
    scores=[]
    for train,test in ((a,b),(b,a),(a|b,d)):
        item=method(data,train)
        if item is None:
            return None,{'status':'no proposal','predictions':scores}
        gain, region=item
        proposed.append(region)
        scores.append(forecast(data,train,test,region.mask(*data[:2]))|{'search_score':gain,'region':vars(region)})
    passed=min(s['z']for s in scores[:2])>0.75 and scores[2]['z']>1.5
    return proposed[2] if passed else None, {'status':'accepted'if passed else 'withheld','predictions':scores}


def apply(broad, packed, colors, pair, noise, box, roi, policy):
    if not np.any(broad):
        return broad,{'status':'parent'}
    scheme,search=policy.split('-')
    x,y,w,h=box
    raw=packed[:,y//2:(y+h)//2,x//2:(x+w)//2]
    observation=measurement(raw, colors, pair, noise)
    data=(*observation[:3],partition(raw.shape,scheme),*observation[4:])
    mark,note=run_policy(data,search)
    if mark is None:
        return broad,note
    a,b,w,h=roi
    n=complete_mask([mark,mark],(box[3],box[2]))[b-y:b-y+h,a-x:a-x+w]
    return (broad*(1-n[None])).astype(broad.dtype),note
