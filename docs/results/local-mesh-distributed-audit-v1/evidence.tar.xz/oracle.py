"""Separate missing-gap localization from phase and held-out prediction limits."""

import os
import sys
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'local-mesh-gap-v1'
sys.path.insert(0, str(PREVIOUS))
from gap import forecast, measurement
from replay import CENTRE, infer_geometry, window
from mesh import Carrier


def partition(raw_shape, style):
    y,x=np.indices(raw_shape[-2:])
    phase=(x%4)==0
    if style=='columns':
        rest=x%4
    elif style=='balanced':
        rest=1+(x%4-1+y)%3
    else:
        raise ValueError(style)
    return np.broadcast_to(np.where(phase,0,rest),raw_shape).ravel()


def checks(observation, mask):
    _,_,_,slot,*_=observation
    a,b=slot==1,slot==2
    scores=[forecast(observation,train,test,mask)for train,test in ((a,b),(b,a),(a|b,slot==3))]
    z=[s['z']for s in scores]
    return {'scores':scores,'passed':min(z[:2])>.75 and z[-1]>1.5}


def main():
    source=read_json(PREVIOUS/'fresh.json'); plan=read_json(checked(source['plan']))
    rows=[]
    for binding in source['cases']:
        row=read_json(checked(binding));entry=row['entry']
        if entry['layout'] not in ('band','disk'):
            continue
        with np.load(checked(row['arrays']),allow_pickle=False)as f:
            raw=window(f['packed'][1],CENTRE,phase=2); colors=f['colors'][1]
            keep=window(f['support'],CENTRE); active=bool(np.any(f['matching-projective'][1]))
        prior=plan['noise'][entry['profile']]
        trace=row['witness']['matching']['exterior']
        if not trace.get('prior_frequencies'):
            continue
        measured,_=infer_geometry(trace,raw,colors,prior,(383.5,383.5))
        actual=[Carrier(**data)for data in row['shape']['case_geometry']]
        mask=np.stack([1-keep[dy::2,dx::2]for dy,dx in ((0,0),(0,1),(1,0),(1,1))]).ravel()
        scores={}
        for label,pair in (('measured',measured),('true',actual)):
            saved=measurement(raw,colors,pair,prior)
            for scheme in ('columns','balanced'):
                data=(*saved[:3],partition(raw.shape,scheme),*saved[4:])
                scores[label+'-'+scheme]=checks(data,mask)
        rows.append({'id':row['id'],'entry':entry,'broad_active':active,'metrics':scores})
        print(row['id'],active,{name:([round(s['z'],2)for s in d['scores']],d['passed'])for name,d in scores.items()},flush=True)
    write_json(ROOT/'oracle.json',{'program':reference(__file__),'source':reference(PREVIOUS/'fresh.json'),'rows':rows,
      'scope':'Uses the true gap support mask. The true-carrier arms also use the exact projected fields from the synthetic input. These are diagnostic controls. The measured-geometry arms use precisely the earlier nominal phase fit.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
