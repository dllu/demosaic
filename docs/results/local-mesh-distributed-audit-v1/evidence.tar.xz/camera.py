"""Compare the alternate Bayer assignment on both standing cached camera scenes."""

import importlib.util
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from oracle import ROOT,PREVIOUS,infer_geometry,window
from replay import SOURCE
from rank import apply
from standing import legacy


def load(path):
    spec=importlib.util.spec_from_file_location(path.stem,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod


wider=load(SOURCE/'wider-camera.py')


def main():
    archived=read_json(PREVIOUS/'camera.json'); control=read_json(SOURCE/'camera.json')
    scene_inputs=read_json(SOURCE/'wider-camera.json')
    raw_sources={r['id']:r for r in scene_inputs['views']}
    originals={r['id']:r for r in control['views']}
    photos={}; out=ROOT/'camera';out.mkdir();results=[]
    for row in archived['results']:
        key=row['id']; guide=raw_sources[key];base_row=originals[key]
        with np.load(checked(row['binding']),allow_pickle=False)as f:
            raw,colors=f['packed'][0],f['colors'][0]
            metadata={k:f[k]for k in ('wb','matrix')}
        with np.load(checked(row['arrays']),allow_pickle=False)as f:
            existing=np.load(checked(base_row['parent']),allow_pickle=False)[0]
            broad=f['broad'];old=f['Crossed and audited']
        q,roi,noise=(row[k]for k in ('query','ROI','noise'))
        if broad.any():
            path=checked(guide['RAW']); assert (Path.cwd()/'.cache').resolve() in path.resolve().parents
            if path not in photos: photos[path]=read_raw(path)[0]
            stored=photos[path]
            x,y,w,h=guide['absolute_box']
            np.testing.assert_array_equal(wider.packed(stored[y:y+h,x:x+w]),raw)
            record,added=wider.augment(stored,guide['absolute_box'],q,base_row['donor_windows'],colors,noise)
            assert added==guide['added_donors']
            pair,note=infer_geometry(record,window(raw,q,phase=2),colors,noise,np.asarray(q[:2])+127.5)
            assert note['donor_fit']==guide['fit']
        else:
            pair=None
        first,n1=apply(broad,raw,colors,pair,noise,q,roi,'columns-proxy')
        np.testing.assert_array_equal(first,old)
        second,n2=apply(broad,raw,colors,pair,noise,q,roi,'balanced-proxy')
        cmp=float(np.sqrt(np.mean((second.astype(float)-first)**2))*65535)
        old_board={'image':row['image'],'panels':[p for p in row['panels'] if p['label'] not in ('Local deficit','Audited gap','Median, anchored split')]}
        parent=window(existing,roi)
        rendered=legacy.pixel(parent+second,metadata,(0,0,roi[2],roi[3]),row['exposure'])
        image,labels=legacy.insert_camera_panels(out,key,old_board,'Crossed and audited',[('Distributed Bayer audit',rendered)])
        path=out/(key+'.npz');np.savez_compressed(path,columns=first,balanced=second)
        results.append({'id':key,'image':image,'panels':labels,'source':row['image'],'RAW':guide['RAW'],'input':row['binding'],'noise':noise,
                        'exposure':row['exposure'],'ROI':roi,'native_delta':reference(path),'changes_DN16':cmp,'columns':n1,'balanced':n2})
        print(key,n1['status'],n2['status'],cmp,[round(x['z'],2)for x in n2.get('predictions',[])],flush=True)
    assert len(results)==8
    write_json(ROOT/'camera.json',{'source':reference(PREVIOUS/'camera.json'),'driver':reference(__file__),'checkpoint':archived['checkpoint'],'results':results})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
