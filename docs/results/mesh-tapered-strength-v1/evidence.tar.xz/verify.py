"""Independently check bounded strengths, disjoint selection and rendered attenuation."""

import math
import os
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import lstsq

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import coordinates,native_sites

ROOT=Path(__file__).resolve().parent
POOLED=ROOT.parent/"mesh-pooled-gap-evidence-v1"
AVERAGE=ROOT.parent/"mesh-averaged-gap-v1"
FOOT=ROOT.parent/"mesh-shrunk-footprint-v1"
sys.path[:0]=[str(ROOT.parent/"mesh-envelope-support-v1"),str(ROOT.parent/"mesh-refined-edge-v1"),
              str(FOOT),str(POOLED),str(AVERAGE)]
from deliver import CENTRE,DISPLAY,Carrier,window
from mesh import ribbon
from tapered_delivery import ANCHOR,MINIMUM,MAXIMUM,PRIOR_INFORMATION,audit,coefficients,core_weight
from averaged_footprints import footprints,proposal_bank
from pooled_gap_audit_20261118 import fitted_terms,sound_template


def arbitrary_quadratics():
    g=np.random.default_rng(2281309)
    worst=0.
    kinds=set()
    sample_count=512
    tests=g.uniform(MINIMUM,MAXIMUM,size=(64,2))
    for i in range(sample_count):
        components=g.standard_normal((6,2))*g.uniform(.2,12)
        H=components.T@components
        v=g.normal(0,35,size=2)+H@g.uniform(-.3,1.4,size=2)
        trial=coefficients(v,H)
        assert np.all(trial>=MINIMUM) and np.all(trial<=MAXIMUM)
        effective=H+PRIOR_INFORMATION*np.eye(2)
        gradient=effective@trial-v-ANCHOR*PRIOR_INFORMATION
        lo=trial==MINIMUM
        hi=trial==MAXIMUM
        free=~(lo|hi)
        assert np.all(gradient[lo]>=-1e-9) and np.all(gradient[hi]<=1e-9)
        np.testing.assert_allclose(gradient[free],0,atol=5e-10)
        residuals=tests-trial
        differences=np.einsum("ij,jk,ik->i",residuals,effective,residuals)+2*residuals@gradient
        assert differences.min()>-1e-10
        kinds.add(int(free.sum()))
        worst=max(worst,float(np.max(np.abs(gradient[free]),initial=0)))
    assert kinds=={0,1,2}
    return {"quadratics":sample_count,"tested_configurations":"corner, edge and interior","max_free_gradient":worst}


def check_fit(path,plan):
    row=read_json(path)
    noise=plan["noise"][row["entry"]["profile"]]
    with np.load(checked(row["arrays"]),allow_pickle=False)as f:
        block=window(f["packed"][1],CENTRE,phase=2)
        cfa=f["colors"][1]
    role=next(v for v in row["proof"]["matching"]["roles"]if v["role"]==1)
    positions=native_sites(block.shape[-2:],(-127.5,-127.5))
    p,q=(ribbon(*positions,Carrier(**v))for v in role["central_pair"])
    assert block.shape==p.shape==q.shape
    fx,fy=role["central_pair"][0]["frequency"]
    start=math.atan2(fy,fx)
    cuts,proof=audit(block,cfa,p,q,noise,CENTRE,DISPLAY,start)
    assert proof["mean"]["accepted"]
    assert np.all(cuts["taper"]<=cuts["uniform"]+1e-11)
    data,reserve,slots,bg,rear,edge=fitted_terms(block,cfa,p,q,noise)
    design=np.column_stack((bg,rear))
    grid=coordinates(160,160,origin=(-79.5,-79.5))
    angle=edge["shape"][0]if "shape" in edge else start
    bank=proposal_bank(angle)
    model,draw,_=footprints(data,design,rear,reserve,bank,grid)["mean"]
    delta,sigma,_=sound_template(data,design,rear,reserve,model)
    blend=core_weight(model,max(float(model.max()),float(draw.max())))
    mixed=np.column_stack((delta*blend,delta*(1-blend)))
    gram=np.zeros((2,2));overlap=np.zeros(2)
    for color in range(3):
        t=~reserve&(data.colors==color)
        X=design[t]
        Z=mixed[t]
        unexplained=Z-X@lstsq(X,Z,lapack_driver="gelsy")[0]
        gram+=(unexplained.T@unexplained)/sigma[color]
        overlap+=(unexplained.T@data.raw[t])/sigma[color]
    previous=proof["reconstruction"]
    np.testing.assert_allclose(previous["energy"],gram,atol=1e-9,rtol=1e-9)
    np.testing.assert_allclose(previous["overlap"],overlap,atol=3e-8,rtol=1e-9)
    changed=block.copy()
    mask=slots[2].reshape(block.shape)
    changed[mask]+=.015*(p[mask]-.65*q[mask])
    _,audit_again=audit(changed,cfa,p,q,noise,CENTRE,DISPLAY,start)
    assert audit_again["mean"]["proposal"]==proof["mean"]["proposal"]
    assert audit_again["mean"]["holdout"]["z"]!=proof["mean"]["holdout"]["z"]
    return {"case":reference(path),"projection_gram":gram.tolist(),"projection_overlap":overlap.tolist(),
            "reproduced_both_strength_terms":True,"nomination_unchanged_after_audit_perturbation":True}


def main():
    previous=read_json(AVERAGE/"measured-plan.json")
    paths=[AVERAGE/"scored"/f"{key}.json" for key in
           ("iso400-ellipse-g215","iso6400-ellipse-g215","iso6400-compound-g214")]
    numerical=arbitrary_quadratics()
    crops=[check_fit(p,previous)for p in paths]
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"quadratics":numerical,"physical_cases":crops})


if __name__=="__main__":
    os.sched_setaffinity(0,[14]);os.nice(12)
    main()
