"""Plot fitted cut fractions over the exact support of one high-noise native crop."""

import math
from pathlib import Path
import sys

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT.parent/name)for name in ("mesh-envelope-support-v1","mesh-refined-edge-v1",
         "mesh-shrunk-footprint-v1","mesh-pooled-gap-evidence-v1","mesh-averaged-gap-v1")]
from deliver import CENTRE,DISPLAY,Carrier,window
from mesh import ribbon
from tapered_delivery import audit

summary=read_json(ROOT/"summary.json")
active=[x for x in summary["cases"] if x["entry"]["profile"]=="iso6400"
        and x["entry"]["kind"]=="gaps" and x["matched"].get("taper",{}).get("same_strength")]
assert active
largest=max(active,key=lambda x:x["matched"]["taper"]["uniform"]["outside_attenuation_DN16"]
                              -x["matched"]["taper"]["candidate"]["outside_attenuation_DN16"])
row=read_json(checked(largest["source"]))
with np.load(checked(row["arrays"]),allow_pickle=False)as f:
    raw=window(f["packed"][1],CENTRE,phase=2)
    colors=f["colors"][1]
    known=window(1-f["support"],DISPLAY)
meta=next(r for r in row["proof"]["matching"]["roles"]if r["role"]==1)
site=native_sites(raw.shape[-2:],(-127.5,-127.5))
p,q=(ribbon(*site,Carrier(**e))for e in meta["central_pair"])
fx,fy=meta["central_pair"][0]["frequency"]
settings=read_json(checked(summary["plan"]))
masks,check=audit(raw,colors,p,q,settings["noise"]["iso6400"],CENTRE,DISPLAY,math.atan2(fy,fx))
assert check["mean"]["accepted"]
ratio=largest["matched"]["taper"]["ratio"]
old=ratio*masks["uniform"]
panels=[("Exact gap footprint",known),("Uniform, matched strength",old),("Tapered refit",masks["taper"]),
        ("Separate strengths",masks["separate"])]
fig,axes=plt.subplots(1,4,figsize=(9.1,2.9),layout="constrained")
for i,(axis,(label,image)) in enumerate(zip(axes,panels,strict=True)):
    bar=axis.imshow(image,vmin=0,vmax=1,cmap="viridis",interpolation="nearest")
    if i:
        axis.contour(known,levels=[.5],colors="white",linewidths=.65)
    axis.set_title(label,fontsize=9)
    axis.set_xticks([])
    axis.set_yticks([])
    for side in axis.spines.values():side.set_visible(False)
fig.suptitle(f"Rear-wire cut fractions on {row['entry']['id']}",fontsize=12)
cb=fig.colorbar(bar,ax=list(axes),fraction=.04,shrink=.87)
cb.set_label("Fraction of rear removed",fontsize=9)
f=ROOT/"support-footprint.png"
fig.savefig(f,dpi=155)
write_json(ROOT/"support-figure.json",{"source":reference(__file__),"case":largest["source"],
         "image":reference(f),"ROI":DISPLAY,"matched_uniform_ratio":ratio,
         "scope":"Exact synthetic missing region and three independently reproduced native-grid cut fields. White line marks the target footprint's half value."})
