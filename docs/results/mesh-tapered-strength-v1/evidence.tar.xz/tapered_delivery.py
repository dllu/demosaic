"""Fit a central and diffuse rear-wire attenuation after disjoint shape validation."""

import math

import numpy as np

from demosaic.isolated_line import coordinates
from averaged_footprints import footprints, proposal_bank
from pooled_gap_audit_20261118 import (
    SIGNED_OVERLAP, admitted, fitted_terms, forecasts, read_score, sound_template,
)

DELIVERIES = ("fixed", "uniform", "taper", "separate", "best-uniform")
ANCHOR = .5
PRIOR_INFORMATION = 16.
MINIMUM = .25
MAXIMUM = .85


def coefficients(overlap, gram):
    # This two-dimensional box-constrained quadratic reaches its minimum in
    # the interior or on one of four edges. Examine all edge optima and the
    # unconstrained solution when it falls within bounds.
    hessian=gram+PRIOR_INFORMATION*np.eye(2)
    direction=overlap+ANCHOR*PRIOR_INFORMATION
    interior=np.linalg.solve(hessian,direction)
    options=[]
    if np.all(interior>=MINIMUM) and np.all(interior<=MAXIMUM):
        options.append(interior)
    for side,edge in ((0,MINIMUM),(0,MAXIMUM),(1,MINIMUM),(1,MAXIMUM)):
        coordinate=np.empty(2)
        coordinate[side]=edge
        other=1-side
        coordinate[other]=np.clip((direction[other]-hessian[other,side]*edge)/
                                   hessian[other,other],MINIMUM,MAXIMUM)
        options.append(coordinate)
    return min(options,key=lambda value:float(value@hessian@value-2*direction@value))


def core_weight(a,peak):
    t=np.clip((a/max(peak,1e-12)-.30)/.60,0.,1.)
    return t*t*(3.-2*t)


def projection(data,design,delta,sigma,outer,keep):
    assert delta.ndim==outer.ndim==data.raw.ndim==1 and design.ndim==2
    assert delta.shape==outer.shape==data.raw.shape
    H=np.zeros((2,2))
    v=np.zeros(2)
    core=delta-outer
    template=np.column_stack((core,outer))
    for color in range(3):
        test=keep&(data.colors==color)
        Q=np.linalg.qr(design[test],mode="reduced")[0]
        q=template[test]
        q=q-Q@(Q.T@q)
        H+=(q.T@q)/sigma[color]
        v+=(q.T@data.raw[test])/sigma[color]
    return v,H


def fit_one(score):
    power=score["projected_energy"]
    overlap=score["z"]*math.sqrt(max(0.,power))
    result=(overlap+.5*PRIOR_INFORMATION)/(power+PRIOR_INFORMATION)
    return float(np.clip(result,MINIMUM,MAXIMUM))


def audit(raw,cfa,p,q,noise,query,roi,approx_angle):
    data,reserve,groups,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    a,b,d=groups
    global_ok="shape" not in edge or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    design=np.column_stack((bg,rear))
    angle=edge["shape"][0]if "shape" in edge else approx_angle
    bank=proposal_bank(angle)
    origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5)
    native=coordinates(roi[3],roi[2],origin=origin)
    hypotheses=footprints(data,design,rear,reserve,bank,native)
    field={mode:np.zeros_like(native[0])for mode in DELIVERIES}
    proof={"edge":edge,"global_keep":global_ok}
    for operation,(cut,render,proposal) in hypotheses.items():
        delta,sigma,_=sound_template(data,design,rear,reserve,cut)
        hold=read_score(data.raw,data.colors,design,delta,sigma,~reserve)
        accepted=bool(global_ok and hold["z"]>SIGNED_OVERLAP and hold["half_displacement_gain"]>0)
        proof[operation]={"holdout":hold,"accepted":accepted,"proposal":proposal}
        if not accepted:
            continue
        uniform=fit_one(hold)
        proof[operation]["uniform"]=uniform
        if operation=="top":
            field["best-uniform"]=render*uniform
            continue
        peak=max(float(cut.max()),float(render.max()))
        on_raw=core_weight(cut,peak)
        on_canvas=core_weight(render,peak)
        overlap,gram=projection(data,design,delta,sigma,delta*(1.-on_raw),~reserve)
        np.testing.assert_allclose(gram.sum(),hold["projected_energy"],rtol=5e-11,atol=1e-9)
        np.testing.assert_allclose(overlap.sum(),
                hold["z"]*np.sqrt(hold["projected_energy"]),rtol=2e-9,atol=1e-7)
        core=render*on_canvas
        fringe=render-core
        amp=coefficients(overlap,gram)
        predicted={
            "fixed":np.array([.5,.5]),
            "uniform":np.array([uniform,uniform]),
            "taper":np.array([uniform,min(.5,uniform)]),
            "separate":amp,
        }
        for mode,coeff in predicted.items():
            field[mode]=coeff[0]*core+coeff[1]*fringe
        gains={key:float(2*coeff@overlap-coeff@gram@coeff)for key,coeff in predicted.items()}
        proof["reconstruction"]={"coefficients":{k:v.tolist()for k,v in predicted.items()},
                     "gain_on_fit_samples":gains,"energy":gram.tolist(),"overlap":overlap.tolist(),
                     "max_cut":{k:float(v.max())for k,v in field.items()},"peak":peak}
    return field,proof
