"""Archive verified crop scores, model sources and reviewed native comparisons."""

from datetime import datetime,UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
IMAGES=REPO/"docs/images/mesh-tapered-strength-v1"
RESULTS=REPO/"docs/results/mesh-tapered-strength-v1"


def relative(p):
    return {"path":p.relative_to(REPO).as_posix(),"sha256":reference(p)["sha256"]}


def export(image,panels=()):
    source=checked(image)
    target=IMAGES/source.name
    shutil.copyfile(source,target)
    with Image.open(target)as f:
        for panel in panels:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and x+w<=f.width and y+h<=f.height
    result=relative(target)
    assert result["sha256"]==image["sha256"]
    return result


def main():
    summary=read_json(ROOT/"summary.json")
    assert summary["scores_recomputed"]==248 and len(summary["cases"])==24
    verification=read_json(ROOT/"verification.json")
    assert len(verification["physical_cases"])==3 and verification["quadratics"]["quadratics"]==512
    repeat=summary["repeat"]["groups"]["all"]
    assert repeat["gap"]["accepted"]=={"mean":19,"top":16}
    assert repeat["continuing"]["accepted"]=={"mean":0,"top":1}
    controls=[v for v in summary["cases"] if v["entry"]["rotated"]]
    assert len(controls)==8 and all(not any(r["changed"]) for v in controls for k,r in v["numerical"].items()
                                  if k.startswith("unrelated/"))
    assert all(not r["changed"][2] for v in summary["cases"] for k,r in v["numerical"].items()
               if k.startswith("matching/"))
    IMAGES.mkdir()
    RESULTS.mkdir()
    view_notes={
        "iso400-compound-g224":"Some rear repeats within the true holes fade. Modulation in the brighter area remains stronger than the background.",
        "iso6400-compound-g224":"The high-noise refits have subtle differences and leave some repeat structure through the missing patches.",
        "iso400-step-g224":"Continuous rear modulation weakens near the edge. The true target remains continuous there.",
    }
    native=[]
    for item in summary["boards"]:
        for k in ("source_case","arrays","checkpoint"):
            checked(item[k])
        used={k:v for k,v in item.items()if k not in ("board","triplet")}
        for k in ("board","triplet")if item["id"]in summary["triplets"] else ("board",):
            cell=item[k]
            used[k]=cell|{"image":export(cell["image"],cell["panels"])}
        native.append(used|{"observation":view_notes[item["id"]]})
    assert len(native)==3 and sum("triplet" in s for s in native)==2
    camera_notes={
        "main-overcast-sky-main-overcast-sky":"Smooth gray sky.",
        "main-building-detail-main-building-detail":"Fine rails and steelwork remain soft.",
        "main-foliage-main-foliage":"Same soft fine edges and dark shadow contrast.",
        "main-chain-link-fence-main-chain-link-fence":"Coarse crossings stay visible with slightly less contrast under the three strength fits.",
        "mesh-nominal-fine-green-mesh-left":"Some faint modulation next to the post fades. The differences between refits are subtle.",
        "mesh-nominal-fine-green-mesh-right":"Both recovered directions remain with exact adjacent-donor pixels.",
        "mesh-profile3879-fine-green-mesh-left":"Weak diagonal modulation is visible amid dark background variations.",
        "mesh-profile3879-fine-green-mesh-right":"Both directions remain visible. The local attenuation is small.",
    }
    prior=read_json(ROOT/"camera.json")
    viewed=[]
    for view in prior["views"]:
        for k in ("source","parent","RAW","arrays"):
            checked(view[k])
        viewed.append(view|{"image":export(view["image"],view["panels"]),"observation":camera_notes[view["id"]]})
    assert len(viewed)==8
    figure=read_json(ROOT/"support-figure.json")
    figure["image"]=export(figure["image"])
    view=RESULTS/"viewing.json"
    write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
        "scope":"Viewed all eight standing GFX boards, three synthetic comparisons, two native triplets and the support plot.",
        "camera_checkpoint":prior["checkpoint"],"camera":viewed,"synthetic":native,"support_plot":figure})
    extras=("summary.json","verification.json")
    for name in extras:shutil.copyfile(ROOT/name,RESULTS/name)
    archive=RESULTS/"evidence.tar.xz"
    paths=sorted([f for f in ROOT.iterdir() if f.is_file() and f.suffix in (".py",".json",".log")]
                 +list((ROOT/"scored").glob("*.json")))
    files={str(p.relative_to(ROOT)):p for p in paths}
    with tarfile.open(archive,"x:xz",preset=4)as f:
        for key,p in files.items():f.add(p,arcname=key)
    with tarfile.open(archive,"r:xz")as f:
        assert set(f.getnames())==set(files)
        for key,p in files.items():
            assert hashlib.sha256(f.extractfile(key).read()).hexdigest()==reference(p)["sha256"]
    previous=("mesh-averaged-gap-v1","mesh-pooled-gap-evidence-v1","mesh-shrunk-footprint-v1","mesh-refined-edge-v1")
    write_json(RESULTS/"publication.json",{"scope":"Same EMA crop models. Twenty-four fresh exact scenes, twenty-four independent conditional support pairs, both standing camera scenes.",
        "archive":relative(archive),"verified_receipts":[relative(RESULTS/f)for f in (*extras,"viewing.json")],
        "archive_contents":{key:reference(p)for key,p in files.items()},
        "earlier_sources":[relative(REPO/"docs/results"/n/"evidence.tar.xz")for n in previous]})


if __name__=="__main__":
    main()
