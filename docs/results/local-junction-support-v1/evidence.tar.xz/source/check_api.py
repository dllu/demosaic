"""Verify exact research-to-package parity and time the public crop entry."""

from pathlib import Path
from statistics import median, mean
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
import junction_gate as model
from review_junction import FIXED

MODES = ("weak-internal-phase", "weak-junction-phase")
SOURCES = (
    "src/demosaic/_mesh_junction.py",
    "src/demosaic/mesh_carrier_fit.py",
    "tests/test_mesh_carrier_fit.py",
)


def check(parent, local, raw, colors, roi, noise, wb, matrix, clearance=48):
    x, y, w, h = local
    previous, trace = model.apply(
        parent, local, raw, colors, roi, noise, wb, matrix, clearance=clearance
    )
    crop = model.crop(parent, local)
    seconds = {}
    differences = {}
    modes = {}
    for method, halo, key in ((MODES[0], 16, "baseline"), (MODES[1], 48, "wire/0")):
        start = monotonic()
        result = refine_raw_mesh_carriers(
            crop,
            raw,
            colors,
            roi,
            shot=noise["shot"],
            read=noise["read"],
            white_balance=wb,
            camera_to_srgb=matrix,
            donor_clearance=clearance,
            method=method,
            parent_context=model.crop(parent, (x - halo, y - halo, w + 2 * halo, h + 2 * halo)),
        )
        seconds[method] = monotonic() - start
        differences[method] = float(np.max(abs(result.astype(np.float64) - previous[key])) * 65535)
        modes[method] = result
    assert max(differences.values()) < 0.002, (differences, trace)
    changed = not np.array_equal(*modes.values())
    if trace["state"] != "delivered":
        assert not changed
    return {
        "seconds": seconds,
        "error_DN16": differences,
        "changed": changed,
        "state": trace["state"],
    }


def main():
    torch.set_num_threads(2)
    source = reference(model.OUT / "independent.json")
    data = read_json(checked(source))
    lock = read_json(checked(data["calibration"]))
    assert lock["policy"]["primary"]["choice"] == ["wire/0", 1.0]
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    region = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    rows = []
    for scene in data["rows"]:
        for d in scene["draws"]:
            with np.load(checked(d["input"]), allow_pickle=False) as f:
                samples = {k: f[k] for k in f.files}
            values = np.load(checked(d["outputs"]["local50k"]), allow_pickle=False)
            raw = samples["scene_packed"].copy()
            results = []
            for index, (parent, packed) in enumerate(zip(values, samples["packed"], strict=True)):
                raw[cut] = packed
                results.append(
                    check(
                        parent,
                        region,
                        raw,
                        samples["colors"],
                        roi,
                        plan["noise"],
                        samples["wb"],
                        samples["matrix"],
                    )
                )
            rows.append({"id": scene["id"], "draw": d["draw"], "results": results})
        if len(rows) % 16 == 0:
            print("Verified", len(rows), "draws", flush=True)
    sensor = reference(FIXED)
    real = []
    for region in read_json(checked(sensor))["standing"]:
        with np.load(checked(region["input"]), allow_pickle=False) as file:
            raw, colors, wb, mat = (file[k][0] for k in ("packed", "colors", "wb", "matrix"))
        value = np.load(checked(region["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(region["local_ROI"])
        real.append(
            {
                "id": region["id"],
                "results": [check(value, roi, raw, colors, roi, region["noise"], wb, mat, 16)],
            }
        )
    grouped = [p for q in rows for p in q["results"]]
    changed = [p for p in grouped if p["changed"]]
    max_diff = {
        method: max(v["error_DN16"][method] for row in rows + real for v in row["results"])
        for method in MODES
    }
    medians = {
        name: {method: 1000 * median(v["seconds"][method] for v in group) for method in MODES}
        for name, group in (("all", grouped), ("changed", changed))
    }
    write_json(
        model.OUT / "api-proof.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "standing": sensor,
            "code": {p: reference(p) for p in SOURCES},
            "synthetic": rows,
            "real": real,
            "counts": {"synthetic": len(grouped), "changed": len(changed), "real": len(real)},
            "peak_error_DN16": max_diff,
            "median_cpu_ms": medians,
        },
    )
    print(max_diff, medians, flush=True)


if __name__ == "__main__":
    main()
