"""Collect image-domain effects and the held true-gap tradeoff."""

from pathlib import Path
import sys

import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replay_junction as score
import junction_gate as model

OUT = model.OUT
KEYS = (
    "calibration",
    "independent",
    "api-proof",
    "station-audit",
    "natural-replay",
    "board-camera",
    "board-exact",
)


def chart(records):
    fig, panels = plt.subplots(1, 2, figsize=(9.5, 4.1), sharey=True, layout="constrained")
    colors = {"uniform_full": "#82607f", "primary": "#08775e"}
    for (name, title), ax in zip(
        (("calibration", "24 calibration photos"), ("independent", "24 new confirmation photos")),
        panels,
        strict=True,
    ):
        r = records[name]["summary"]
        base = r["metrics"]["baseline"]["means"][score.RESPONSE]
        for k, label in (("uniform_full", "Crop-wide sideband"), ("primary", "Local wire check")):
            values = r["metrics"][k]["means"]
            x, y = values[score.GAP], values[score.RESPONSE] - base
            ax.plot([0, x], [0, y], lw=2.1, color=colors[k], label=label)
            ax.scatter(x, y, s=48, color=colors[k], zorder=3)
        selected = r["metrics"]["primary"]["means"]
        target = r["matched"]["scores"]["means"]
        x, y = target[score.GAP], target[score.RESPONSE] - base
        ax.hlines(y, selected[score.GAP], x, lw=1, color="#666666", linestyles="--")
        ax.scatter(
            x,
            y,
            facecolor="white",
            edgecolor=colors["uniform_full"],
            label="Equal recovery",
            s=50,
            zorder=3,
        )
        ax.axvline(0.35, color="#7c8484", lw=0.8, linestyle=":", label="Calibration gap limit")
        ax.set(xlabel="Added luma in exact gaps (DN16)", title=title)
        ax.grid(alpha=0.25)
    panels[0].set_ylabel("Added interaction response (percentage points)")
    panels[0].legend(frameon=False, loc="best", fontsize=8)
    f = OUT / "gap-versus-interaction.png"
    fig.savefig(f, dpi=155)
    plt.close(fig)
    return reference(f)


def main():
    refs = {name: reference(OUT / f"{name}.json") for name in KEYS}
    values = {k: read_json(checked(v)) for k, v in refs.items()}
    independent = values["independent"]
    plan = read_json(checked(independent["plan"]))
    component = values["calibration"]["policy"]
    output = {
        "driver": reference(Path(__file__)),
        "receipts": refs,
        "calibration": values["calibration"]["summary"],
        "independent": independent["summary"],
        "lock": {n: component[n] for n in ("limits", "uniform", "primary", "variants")},
        "coupled_draws": 2,
        "nominal_noise": plan["noise"],
        "training_visits_checked": plan["training_photo_visits_audited"],
        "standing": {r["id"]: r["change_DN16"] for r in values["board-camera"]["data"]["rows"]},
        "exact": [
            {n: r[n] for n in ("id", "selection", "response_change", "draw", "scores", "criterion")}
            for r in values["board-exact"]["data"]["boards"]
        ],
        "api": {k: values["api-proof"][k] for k in ("counts", "peak_error_DN16", "median_cpu_ms")},
        "natural": values["natural-replay"]["summary"],
        "chart": chart(values),
    }
    write_json(OUT / "summary.json", output)


if __name__ == "__main__":
    main()
