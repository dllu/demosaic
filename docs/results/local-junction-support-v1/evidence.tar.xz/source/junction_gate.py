"""Localize a held-Bayer-certified difference-frequency readout."""

from functools import lru_cache
from itertools import product
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "query-checked-junctions-v1"))
import model_delivery as old

from demosaic._mesh_near_phase import _pixel_map
from demosaic.mesh_carrier_fit import _spacing, _sites, refine_raw_mesh_carriers

SIZE = 160
QUERY = 256
MARGIN = 48
CUTS = (0.0, 0.65, 1.3)
FAMILIES = ("wire", "difference", "joint")
OPTIONS = tuple((family, cut, f"{family}/{cut:g}") for family, cut in product(FAMILIES, CUTS))
ARMS = ("baseline", "uniform", *(name for _, _, name in OPTIONS))
N = 10
STATION = 16


def relative_colors(cfa, x, y):
    return np.asarray([cfa[2 * ((y + r) % 2) + (x + c) % 2] for r, c in np.ndindex(2, 2)])


def crop(array, roi):
    x, y, w, h = roi
    return array[..., y : y + h, x : x + w]


def prepare(scene, colors, roi, noise, clearance):
    x, y, _, _ = roi
    f = _spacing(scene, colors, x, y, clearance=clearance)
    if f is None:
        return None, None, None
    qx, qy = x - MARGIN, y - MARGIN
    target = np.stack([_sites(scene, qx, qy, QUERY, r, c) for r, c in np.ndindex(2, 2)])
    return target, relative_colors(colors, qx, qy), np.c_[f, np.zeros(2)].tolist()


def select_difference(packed, cfa, noise, geometry):
    record = old.select(packed, cfa, noise, geometry)
    if not record["observed"]:
        return None, record
    difference = next((x for x in record["modes"]["locked"] if x["name"] == "difference"), None)
    return difference if difference and difference["accepted"] else None, record


def residual_terms(samples, nuisance, signal, weight):
    design = nuisance * weight[:, None]
    test = signal * weight
    coef = np.linalg.lstsq(design, test, rcond=1e-8)[0]
    residual = test - design @ coef
    return float(residual @ (samples * weight)), float(residual @ residual)


def local_scores(packed, cfa, noise, selected, difference):
    data, _, _ = old.interior(packed, cfa, noise)
    x, y, phase, raw, var, fold = data
    geometry = selected["geometry"]
    angles = old.phases(x, y, geometry) + np.asarray(selected["Q0_angles"])[None]
    waves = np.stack([np.cos(angles), np.sin(angles)], axis=-1)
    direction = angles[:, 0] - angles[:, 1]
    axis = difference["local_axis"]
    interaction = axis[0] * np.cos(direction) + axis[1] * np.sin(direction)
    shape = np.asarray([term["integer_phase"] for term in selected["modes"]["locked"]])
    other = angles @ shape.T
    other_bands = np.stack((np.cos(other), np.sin(other)), axis=-1)
    # Score against alternate nuisance terms in the same CFA lattice, at fixed phase.
    local = (abs(x) < SIZE / 2) & (abs(y) < SIZE / 2) & (fold >= 2)
    keys = ((y + SIZE / 2) // STATION).astype(int) * N + ((x + SIZE / 2) // STATION).astype(int)
    green = np.unique(phase)
    totals = np.zeros((N * N, 3, 2, 2), dtype=np.float64)
    rival_bands = shape.tolist().index([1, -1])
    held = local
    for station in range(N * N):
        for k, site in enumerate(green):
            use = held & (keys == station) & (phase == site)
            if not use.any():
                continue
            cx = (x[use] - x[use].mean()) / STATION
            cy = (y[use] - y[use].mean()) / STATION
            nuisance = np.c_[np.ones(len(cx)), cx, cy, cx**2, cx * cy, cy**2]
            base = waves[use]
            additions = other_bands[use]
            w = 1 / np.sqrt(var[use])
            value = raw[use]
            # Competing higher orders are nuisance in the difference-frequency test.
            full = np.c_[
                nuisance,
                base.reshape(len(cx), 4),
                np.delete(additions, rival_bands, axis=1).reshape(len(cx), -1),
            ]
            controls = (np.c_[nuisance, base[:, 1]], np.c_[nuisance, base[:, 0]], full)
            signal = (base[:, 0, 0], base[:, 1, 0], interaction[use])
            for j, (term, contrast) in enumerate(zip(controls, signal, strict=True)):
                if len(value) >= term.shape[1] + 3:
                    totals[station, j, k] = residual_terms(value, term, contrast, w)
    moment, power = np.moveaxis(totals, -1, 0)
    local_z = moment / np.sqrt(np.maximum(1e-10, power))
    pooled = moment.sum(axis=-1) / np.sqrt(np.maximum(1e-10, power.sum(axis=-1)))
    limited = np.minimum(pooled, local_z.min(axis=-1) + 1.5)
    return limited


def station_map(values):
    local = values.reshape(N, N).repeat(STATION, axis=0).repeat(STATION, axis=1)
    return np.minimum(_pixel_map(values), local)


def apply(parent, local, scene, colors, roi, noise, wb, matrix, *, clearance=48):
    """Return images and fixed, held score maps under the same ancestor output."""
    x, y, w, h = local
    section = crop(parent, local)
    profile = noise["shot"], noise["read"]
    anchor = refine_raw_mesh_carriers(
        section,
        scene,
        colors,
        roi,
        shot=profile[0],
        read=profile[1],
        white_balance=wb,
        camera_to_srgb=matrix,
        method="weak-internal-phase",
        parent_context=crop(parent, (x - 16, y - 16, 192, 192)),
        donor_clearance=clearance,
    )
    packed, cfa, geometry = prepare(scene, colors, roi, noise, clearance)
    if geometry is None:
        return dict.fromkeys(ARMS, anchor), {"admitted": False, "state": "no frequencies"}
    term, record = select_difference(packed, cfa, noise, geometry)
    if term is None:
        return dict.fromkeys(ARMS, anchor), {
            "admitted": False,
            "state": "difference unavailable",
            "nomination": geometry,
            "record": record,
        }
    context = crop(parent, (x - MARGIN, y - MARGIN, QUERY, QUERY)).copy()
    assert context.shape == (3, QUERY, QUERY)
    context[:, MARGIN : MARGIN + w, MARGIN : MARGIN + h] = anchor
    # Preserve the pre-existing higher orders as nuisance. Only difference is delivered.
    detector = record | {
        "modes": {
            "locked": [
                row | {"accepted": row["name"] == "difference"} for row in record["modes"]["locked"]
            ],
            "free": [],
        }
    }
    field = old.render(packed, cfa, noise, context, wb, matrix, detector)["locked"]
    update = old.GAIN * field[:, MARGIN : MARGIN + w, MARGIN : MARGIN + h].astype(np.float64)
    if not update.any():
        return dict.fromkeys(ARMS, anchor), {
            "admitted": True,
            "state": "no measured increment",
            "nomination": geometry,
            "record": record,
        }
    scores = local_scores(packed, cfa, noise, record, term)
    repeated = np.minimum(scores[:, 0], scores[:, 1])
    choices = {
        "wire": repeated,
        "difference": scores[:, 2],
        "joint": np.minimum(repeated, scores[:, 2]),
    }
    outputs = {"baseline": anchor, "uniform": (anchor + update).astype(anchor.dtype)}
    for family, cut, name in OPTIONS:
        strength = np.clip((choices[family] - cut) / 1.5, 0, 1)
        weight = station_map(strength)
        outputs[name] = (anchor + weight * update).astype(anchor.dtype)
    return outputs, {
        "admitted": True,
        "state": "delivered",
        "nomination": geometry,
        "record": record,
        "max_z": {k: float(v.max()) for k, v in choices.items()},
        "stations_above_point65": {k: int((v > 0.65).sum()) for k, v in choices.items()},
        "scores": scores.tolist(),
    }
