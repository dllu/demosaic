"""Check that the local junction witness uses held sensor samples."""

from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import junction_gate as model

FREQUENCY = np.asarray(((0.115234375, 0.07421875), (0.087890625, -0.072265625)))
NOISE = {"shot": 0.00128, "read": 6.5536e-6}
STATION = (5, 4)


def main():
    y, x = np.indices((256, 256), dtype=np.float64) - 127.5
    coordinates = np.stack((x, y), axis=-1)
    p, q = np.moveaxis(2 * np.pi * (coordinates @ FREQUENCY.T) + (0.4, -0.8), -1, 0)
    surface = 0.13 + 0.025 * np.cos(p) + 0.024 * np.cos(q) - 0.008 * np.cos(p - q)
    scene = np.stack([surface[r::2, c::2] for r, c in np.ndindex(2, 2)]).astype(np.float32)
    new = np.zeros(100)
    new[STATION[0] * 10 + STATION[1]] = 1.0
    allowed = np.zeros((160, 160), dtype=bool)
    row, col = (16 * v for v in STATION)
    allowed[row : row + 16, col : col + 16] = True
    weight = model.station_map(new)
    assert np.max(weight) > 0.8 and not weight[~allowed].any()
    records = []
    geometry = np.c_[FREQUENCY, np.zeros(2)].tolist()
    for pattern, cfa in PATTERNS.items():
        colors = np.asarray(cfa)
        a, _ = model.old.interior(scene, colors, NOISE)[:2]
        idx = STATION[0] * 10 + STATION[1]
        before, record = model.select_difference(scene, colors, NOISE, geometry)
        assert before is not None
        original = model.local_scores(scene, colors, NOISE, record, before)
        changed = scene.copy()
        for phase in np.flatnonzero(colors == 1):
            x, y, p, _, _, fold = a
            chosen = p == phase
            i = ((y[chosen] + 80) // 16).astype(int)
            j = ((x[chosen] + 80) // 16).astype(int)
            edit = (((i == STATION[0]) & (j == STATION[1])) & (fold[chosen] >= 2)).reshape(128, 128)
            changed[phase][edit] += np.random.default_rng(102).uniform(-0.03, 0.03, edit.sum())
        _, after = model.select_difference(changed, colors, NOISE, geometry)
        proposal = next(t for t in after["modes"]["locked"] if t["name"] == "difference")
        assert (
            proposal["local_axis"] == before["local_axis"]
            and proposal["discovery"] == before["discovery"]
        )
        np.testing.assert_array_equal(after["Q0_angles"], record["Q0_angles"])
        remade = model.local_scores(changed, colors, NOISE, record, before)
        keep = np.arange(100) != idx
        np.testing.assert_array_equal(original[keep], remade[keep])
        assert not np.array_equal(original[idx], remade[idx])
        records.append(
            {
                "pattern": pattern,
                "discovery_bit_identical": True,
                "untouched_station_scores_bit_identical": True,
                "scores_before": original[idx].tolist(),
                "scores_after": remade[idx].tolist(),
            }
        )
    write_json(
        model.OUT / "station-audit.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "held_station_index": STATION,
            "interpolation_excludes_neighboring_stations": True,
            "rows": records,
        },
    )


if __name__ == "__main__":
    main()
