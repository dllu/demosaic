"""Check unplanted recipients with authentic and intentionally mismatched exterior."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_gate as model

LOCAL = (48, 48, 160, 160)
ROI = (176, 176, 160, 160)
CUT = np.s_[..., 64:192, 64:192]


def main():
    natural = reference(model.OUT.with_name("local-weak-contrast-v1") / "natural-controls.json")
    context = reference(model.OUT.with_name("local-near-phase-v1") / "contexts-calibration.json")
    scenarios = read_json(checked(context))
    profile = read_json(checked(scenarios["plan"]))["noise"]
    records = []
    for a, b in zip(read_json(checked(natural))["rows"], scenarios["records"], strict=True):
        assert a["id"] == b["id"]
        with np.load(checked(a["input"]), allow_pickle=False) as f:
            d = {k: f[k] for k in f.files}
        alt = b["streams"][0]["far_phase"]
        mismatch = np.load(checked(alt), allow_pickle=False)
        mismatch[CUT] = d["scene_packed"][CUT]
        np.testing.assert_array_equal(mismatch[CUT], d["packed"][0])
        cameras = (d["colors"], d["wb"], d["matrix"])
        results = {}
        for condition, raw in (("authentic", d["scene_packed"]), ("mismatch", mismatch)):
            method, trace = model.apply(
                d["parent"], LOCAL, raw, cameras[0], ROI, profile, *cameras[1:]
            )
            baseline = method["baseline"].astype(np.float64)
            result = {
                n: float(np.sqrt(np.mean((method[k].astype(np.float64) - baseline) ** 2)) * 65535)
                for n, k in (("full", "uniform"), ("local", "wire/0"))
            }
            results[condition] = {"state": trace["state"], "changed_from_baseline": result}
        records.append({"id": a["id"], "input": a["input"], "mismatch": alt, "results": results})
    summary = {}
    for name in ("authentic", "mismatch"):
        data = [r["results"][name] for r in records]
        summary[name] = {
            "changed": {
                k: sum(r["changed_from_baseline"][k] > 0 for r in data) for k in ("full", "local")
            },
            "average_DN16": {
                k: mean(r["changed_from_baseline"][k] for r in data) for k in ("full", "local")
            },
        }
    write_json(
        model.OUT / "natural-replay.json",
        {
            "driver": reference(Path(__file__)),
            "source": natural,
            "alternate_donors": context,
            "rows": records,
            "summary": summary,
        },
    )


if __name__ == "__main__":
    main()
