"""Publish the coupled exact study and source-bound crop proof."""

from hashlib import file_digest
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_gate as model

ROOT = Path.cwd()
OUT = model.OUT
ASSETS = ROOT / "docs/assets" / model.HERE.name
RESULTS = ROOT / "docs/results" / model.HERE.name
FILES = (
    "calibration.json",
    "independent.json",
    "station-audit.json",
    "api-proof.json",
    "natural-replay.json",
    "board-camera.json",
    "board-exact.json",
    "summary.json",
    *(
        f"{g}/{part}"
        for g in ("calibration", "independent")
        for part in ("plan.json", "inputs.json", "parent/result.json")
    ),
)
BORROWED = (
    "query-checked-junctions-v1/model_delivery.py",
    "query-exterior-witness-v1/witness.py",
    "query-contour-support-v1/contour.py",
    "query-edge-side-selection-v1/select.py",
    "query-frequency-consensus-v1/consensus.py",
    "query-bayer-reserve-v1/reserved.py",
    "query-phase-curvature-v1/curvature.py",
    "query-phase-support-v1/support.py",
    "local-replicated-phase-v1/capture_balanced.py",
    "local-weak-contrast-v1/capture_contrast.py",
    "local-nested-support-v1/replay_nested_parents.py",
    "green-covariance-refit-v1/wire_math.py",
    "sensor-optical-transfer-v1/capture_optical.py",
    "sensor-optical-transfer-v1/capture_coupled.py",
)


def local(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def image(ref):
    source = checked(ref)
    dest = ASSETS / source.name
    shutil.copyfile(source, dest)
    result = local(dest)
    assert result["sha256"] == ref["sha256"]
    return result


def board(record):
    result = image(record["image"])
    with Image.open(ROOT / result["path"]) as png:
        for item in record["panels"]:
            x, y, w, h = item["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= png.width and 0 <= y < y + h <= png.height
    return record | {"image": result}


def main():
    refs = {file: reference(OUT / file) for file in FILES}
    data = {key: read_json(checked(value)) for key, value in refs.items()}
    for item in data.values():
        for key in ("driver", "operator", "old_operator"):
            if key in item:
                checked(item[key])
    for key in ("independent", "board-camera", "board-exact"):
        assert data[f"{key}.json"]["calibration"] == refs["calibration.json"]
    for key in ("api-proof", "board-camera", "board-exact"):
        assert data[f"{key}.json"]["source"] == refs["independent.json"]
    proof = data["api-proof.json"]
    assert proof["counts"]["synthetic"] == 336 and proof["counts"]["real"] == 8
    assert proof["peak_error_DN16"] == {"weak-junction-phase": 0.0, "weak-internal-phase": 0.0}
    assert data["independent.json"]["summary"]["within"]["primary"]
    assert data["summary.json"]["receipts"]["api-proof"] == refs["api-proof.json"]
    blocked = set()
    for kind in ("calibration", "independent"):
        manifest = data[f"{kind}.json"]
        parent = data[f"{kind}/parent/result.json"]
        inputs = data[f"{kind}/inputs.json"]
        assert refs[f"{kind}/parent/result.json"] == manifest["source"]
        assert refs[f"{kind}/plan.json"] == manifest["plan"] == inputs["plan"]
        assert refs[f"{kind}/inputs.json"] == parent["inputs"]
        plan = data[f"{kind}/plan.json"]
        assert len(plan["sources"]) == 24
        source = {r["source"][k] for r in plan["sources"] for k in ("id", "cache_sha256")}
        assert source.isdisjoint(blocked)
        blocked.update(source)
        for weight in parent["weights"].values():
            checked(weight)
        for a, b in zip(inputs["observations"], parent["records"], strict=True):
            assert a["id"] == b["id"]
            for original, output in zip(a["streams"], b["streams"], strict=True):
                assert original["data"] == output["data"]
                checked(original["data"])
                for path in output["outputs"].values():
                    checked(path)
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    bindings = {f"receipts/{name}": value for name, value in refs.items()}
    bindings.update(
        {f"source/{path.name}": reference(path) for path in sorted(model.HERE.glob("*.py"))}
    )
    bindings.update({f"reused/{key}": reference(model.HERE.parent / key) for key in BORROWED})
    test = "tests/test_mesh_carrier_fit.py"
    prior_test = reference(OUT / "preliminary/test_mesh_carrier_fit-before-lint.py")
    assert prior_test["sha256"] == proof["code"][test]["sha256"]
    bindings.update({path: source for path, source in proof["code"].items() if path != test})
    bindings[test] = reference(ROOT / test)
    bindings["source/preliminary/test_mesh_carrier_fit-before-lint.py"] = prior_test
    log = reference(OUT / "focused-tests.log")
    assert "97 passed" in checked(log).read_text()
    bindings["receipts/focused-tests.log"] = log
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for k, v in bindings.items():
            tar.add(checked(v), arcname=k, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == bindings.keys()
        for k, v in bindings.items():
            with tar.extractfile(k) as r:
                assert file_digest(r, "sha256").hexdigest() == v["sha256"]
    camera = [
        r | {"native": [board(b) for b in r["native"]]}
        for r in data["board-camera.json"]["data"]["rows"]
    ]
    exact = [
        r | {k: board(r[k]) for k in ("board", "triplet")}
        for r in data["board-exact.json"]["data"]["boards"]
    ]
    assert sum(len(r["native"]) for r in camera) == 12 and len(exact) == 2
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest, {"camera": camera, "exact": exact, "chart": image(data["summary.json"]["chart"])}
    )
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(refs["summary.json"]), summary)
    write_json(
        RESULTS / "publication.json",
        {
            "parent_revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip(),
            "manifest": local(manifest),
            "summary": local(summary),
            "archive": local(archive),
            "receipt_bindings": refs,
            "archive_members": bindings,
            "prior_component": local(ROOT / "docs/results/cab-local-frequency-v1/publication.json"),
            "prior_harmonic_replay": local(
                ROOT / "docs/results/query-checked-junctions-v1/publication.json"
            ),
            "packaged_mode": "weak-junction-phase",
            "new_weights": None,
            "standing_native_boards_viewed": 12,
            "exact_triplets_viewed": 2,
        },
    )


if __name__ == "__main__":
    main()
