"""Wait for summary completion before measuring quiet fine error."""

import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path(__file__).resolve().parent
frozen = root / "work"
owner = read_json(root / "watch-summary-launch.json")
audit = root / "summary-return.json"
deadline = time.monotonic() + 5000
while not audit.exists():
    process = psutil.Process(owner["pid"])
    assert (
        process.create_time() == owner["create_time"] and process.status() != psutil.STATUS_ZOMBIE
    )
    if time.monotonic() > deadline:
        raise TimeoutError("Summary wait deadline. Upstream workers are independent.")
    time.sleep(6)
assert read_json(audit)["returncode"] == 0
env = {
    **os.environ,
    "PYTHONPATH": f"{frozen}/scripts:{frozen}/src",
    "CUDA_VISIBLE_DEVICES": "",
    "OPENBLAS_NUM_THREADS": "2",
    "OMP_NUM_THREADS": "2",
}
os.sched_setaffinity(0, [6, 7])
os.nice(12)
for label, script in (("quiet-texture", "quiet-texture.py"),):
    cmd = [sys.executable, str(root / script)]
    with (root / f"{label}.log").open("xb") as log:
        child = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    write_json(
        root / f"{label}-return.json",
        {
            "returncode": child.returncode,
            "command": cmd,
            "driver": reference(root / script),
            "audit": reference(audit),
        },
    )
    assert child.returncode == 0
