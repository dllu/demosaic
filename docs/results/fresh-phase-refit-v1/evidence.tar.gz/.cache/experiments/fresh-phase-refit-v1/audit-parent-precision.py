"""Check CPU and retained CUDA V143 output on one identical development batch."""

import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32

root = Path(__file__).resolve().parent
plan_path = root / "plan.json"
plan = read_json(plan_path)
old_report_path = checked(plan["development_report"])
old_report = read_json(old_report_path)
old_plan = read_json(checked(old_report["plan"]))
case = next(
    v
    for v in old_plan["groups"]
    if (v["source"], v["profile"], v["placement"], v["CFA"]) == (0, "iso400", "far", "RGGB")
)
torch.set_num_threads(2)
torch.set_num_interop_threads(1)
checkpoint, _ = load_checkpoint(checked(plan["parent"]), "cpu")
checkpoint.eval().requires_grad_(False).to(memory_format=torch.contiguous_format)
with np.load(checked(case["arrays"])) as data:
    args = [torch.from_numpy(data[k]) for k in ("packed", "variance", "colors", "wb", "matrix")]
checkpoint.set_noise(case["noise"]["shot"], case["noise"]["read"])
start = time.monotonic()
with torch.inference_mode(), ieee_fp32():
    current = checkpoint(*args).numpy()
duration = time.monotonic() - start
previous = np.load(checked(case["parent"]))
assert (
    current.shape == previous.shape == (3, 3, 512, 512)
    and current.dtype == previous.dtype == np.float32
)
assert np.isfinite(current).all() and not torch.cuda.is_initialized()
difference = (current.astype(np.float64) - previous) * 65535
roi = difference[..., 128:384, 128:384]
write_json(
    root / "parent-device-check.json",
    {
        "plan": reference(plan_path),
        "driver": reference(__file__),
        "source_case": case["id"],
        "arrays": case["arrays"],
        "CUDA_reference": case["parent"],
        "checkpoint": plan["parent"],
        "fresh_CPU_forward_seconds": duration,
        "fresh_CPU_batch_size": 3,
        "full_RMS_DN16": float(np.sqrt(np.mean(difference * difference))),
        "central_query_RMS_DN16": float(np.sqrt(np.mean(roi * roi))),
        "central_query_max_abs_DN16": float(np.max(abs(roi))),
        "scope": "One identical development batch compared against its retained V143 CUDA parent."
        " This is numerical context for the device change; no fresh benchmark observation.",
    },
)
print(
    "One matched old batch", duration, float(np.sqrt(np.mean(roi * roi))), float(np.max(abs(roi)))
)
