"""Publish the fresh comparison, native crops and replay evidence."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
review = root / "review"
report = read_json(review / "result.json")
plan = read_json(checked(report["plan"]))
summary = read_json(review / "summary.json")
audit = read_json(review / "independent-audit.json")
view = read_json(review / "actual-native-viewing.json")
assert audit["status"] == "passed" and audit["native_reductions"] == 768
assert len(report["fixed_thresholds"]) == 512 and len(report["frozen_budget_results"]) == 128
assert len(view["boards"]) == 4 and all(v["viewed"] for v in view["boards"])
images = repo / "docs/images/fresh-phase-refit-v1"
results = repo / "docs/results/fresh-phase-refit-v1"
images.mkdir()
results.mkdir()
items = []
for row in report["boards"]:
    for kind in ("board", "triplet"):
        image = checked(row[kind]["image"])
        dest = images / image.name
        shutil.copyfile(image, dest)
        v = reference(dest)
        assert row[kind]["image"]["sha256"] == v["sha256"]
        items.append({"id": row["id"], "kind": kind, "image": v, "native": row})
figure = images / "quiet-tradeoff.png"
shutil.copyfile(checked(summary["plot"]), figure)
assert reference(figure)["sha256"] == summary["plot"]["sha256"]
previous = repo / "docs/images/phase-refit-delivery-v1"
camera = []
for row in plan["retained_camera_review"]:
    file = previous / Path(row["image"]["path"]).name
    copied = reference(file)
    assert copied["sha256"] == row["image"]["sha256"]
    camera.append({"id": row["id"], "published": copied, "native": row})
assert len(items) == len(camera) == 8
write_json(
    images / "manifest.json",
    {
        "images": items,
        "plot": reference(figure),
        "fresh_native_viewing": reference(review / "actual-native-viewing.json"),
        "adopted_camera_images": camera,
        "camera_viewing_source": reference(
            repo / "docs/results/phase-refit-delivery-v1/actual-native-viewing.json"
        ),
    },
)
for name in ("summary.json", "independent-audit.json", "actual-native-viewing.json"):
    shutil.copyfile(review / name, results / name)
    assert reference(review / name)["sha256"] == reference(results / name)["sha256"]
for name in ("parent-device-check.json", "absolute-quiet-diagnostic.json", "quiet-texture.json"):
    shutil.copyfile(root / name, results / name)
    assert reference(root / name)["sha256"] == reference(results / name)["sha256"]
members = []
output = results / "evidence.tar.gz"
with (
    output.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped,
    tarfile.open(fileobj=zipped, mode="w") as tar,
):
    for item in sorted(root.rglob("*")):
        if (
            item.is_file()
            and item.suffix in (".py", ".json", ".log")
            and "__pycache__" not in item.parts
        ):
            name = str(item.relative_to(repo))
            members.append({"member": name, **reference(item)})
            tar.add(item, arcname=name, recursive=False)
with tarfile.open(output) as tar:
    for row in members:
        assert hashlib.sha256(tar.extractfile(row["member"]).read()).hexdigest() == row["sha256"]
write_json(
    results / "publication.json",
    {
        "archive": reference(output),
        "members": members,
        "all_member_hashes_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "fresh_query_roles": 96,
        "fresh_native_boards_opened": 4,
        "adopted_previously_reviewed_camera_boards": 8,
        "scope": "Fresh fixed-cohort evaluation with settings frozen on earlier sources.",
    },
)
print(len(members), len(items), len(camera), "publication verified")
