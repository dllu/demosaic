"""Independently check frozen calibration and fresh delivered image reductions."""

from collections import defaultdict
from hashlib import sha256
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
archive = read_json(checked(report["collection"]))
old = read_json(checked(plan["development_report"]))
metrics = (
    "quiet_RMS_DN16",
    "query_RMS_DN16",
    "weak_increment_RMS_DN16",
    "strong_gain",
    "weak_gain",
    "weak_absent_projection",
)


def calibration(setting):
    method = {"fold-average": "square", "weighted-refit": "weighted-refit"}[setting["method"]]
    rows = [
        r
        for r in old["fixed_threshold_metrics"]
        if (r["profile"], r["placement"]) == (setting["profile"], setting["placement"])
    ]
    choices = []
    for threshold in plan["thresholds"]:
        outcomes = [r for r in rows if r["method"] == f"{method}-t{threshold:g}"]
        assert len(outcomes) == 32 and {r["source"] for r in outcomes} == set(range(8))
        q = np.add.reduce([r["moments"]["quiet_mse"] for r in outcomes]) / 32
        w = np.add.reduce([r["moments"]["weak_gain"] for r in outcomes]) / 32
        baseline = np.sqrt(q[0])
        cap = (baseline + setting["budget_DN16"]) ** 2

        def difference(s, q=q, cap=cap):
            return (q[2] * s + q[1]) * s + q[0] - cap

        if w[1] <= 0:
            scale = 0
        else:
            scale = 1 if difference(1) <= 0 else brentq(difference, 0, 1, xtol=1e-14)
        choices.append(
            (w[0] + scale * w[1], -threshold, scale, np.sqrt(difference(scale) + cap) - baseline)
        )
    chosen = max(choices)
    np.testing.assert_allclose(
        chosen,
        [
            setting["calibration_weak_gain"],
            -setting["threshold"],
            setting["scale"],
            setting["calibration_quiet_delta_DN16"],
        ],
        rtol=0,
        atol=2e-11,
    )


for v in plan["settings"]:
    calibration(v)
assert len(plan["settings"]) == 16
assert len(archive["cases"]) == 32 and archive["counts"] == {"root": 32, "DINO": 32}
assert archive["query_roles"] == 96 and archive["parent_state_unchanged"]
assert not set(plan["sources"]) & set(range(8))
lookup = defaultdict(list)
for row in report["frozen_budget_results"]:
    lookup[row["id"]].append(row)


def noise_keys(metadata, roles):
    return {
        (
            metadata["recipe"]["seed"],
            metadata["identities"][i],
            metadata["noise"]["name"],
            metadata["pattern"],
        )
        for i in roles
    }


def rms(v):
    return float(np.sqrt(np.mean(v * v)) * 65535)


region = np.s_[..., 128:384, 128:384]
query_keys = set()
raw_fingerprints = set()
checks, maximum = 0, 0.0
for binding, group in zip(archive["cases"], plan["groups"], strict=True):
    case = read_json(checked(binding))
    assert case["id"] == group["id"] and len(lookup[group["id"]]) == 4
    assert case["source"] == case["metadata"]["recipe"]["source"]
    assert (
        case["metadata"]["repeat"] == group["repeat"]
        and case["metadata"]["pattern"] == group["CFA"]
    )
    assert case["metadata"]["placement"] == group["placement"]
    assert case["metadata"]["noise"] == plan["profiles"][group["profile"]]
    assert len(case["fits"]) == 3
    for fit in case["fits"]:
        assert fit["guide_frequencies_xy"] == archive["donors"][case["guide_key"]]["frequencies"]
        assert (
            fit["compare_pooled_refit"] and fit["parent_used_for_discovery_or_validation"] is False
        )
    query_keys |= noise_keys(case["metadata"], range(3))
    with np.load(checked(case["sensor"])) as a:
        assert set(a.files) == {"packed", "variance", "colors", "wb", "matrix"}
        for row in a["packed"]:
            raw_fingerprints.add(sha256(row.tobytes()).hexdigest())
    with np.load(checked(case["target"])) as a:
        actual = a["target"].astype(np.float64)
        quiet = a["quiet"][region]
    w = (actual[2] - actual[1]).ravel()
    s = (actual[1] - actual[0]).ravel()
    base = np.load(checked(case["parent"])).astype(np.float64)
    with np.load(checked(case["predictions"])) as estimates:
        for v in lookup[case["id"]]:
            name = f"{v['method']}-t{v['threshold']:g}"
            delivered = base.copy()
            delivered[region] = (1 - v["scale"]) * base[region] + v["scale"] * estimates[name]
            err = delivered - actual
            values = np.array(
                [
                    rms(err[region][..., quiet]),
                    rms(err[region]),
                    rms((delivered[2] - delivered[1]).ravel() - w),
                    (delivered[1] - delivered[0]).ravel() @ s / (s @ s),
                    (delivered[2] - delivered[1]).ravel() @ w / (w @ w),
                    err[1].ravel() @ w / (w @ w),
                ]
            )
            expected = np.array([v[k] for k in metrics])
            np.testing.assert_allclose(values, expected, rtol=0, atol=3e-10)
            maximum = max(maximum, float(np.max(abs(values - expected))))
            checks += len(values)
donor_keys = set()
for d in archive["donors"].values():
    donor_keys |= noise_keys(d["metadata"], (2,))
    with np.load(checked(d["arrays"])) as raw:
        assert set(raw.files) == {"packed", "colors"}
        assert sha256(raw["packed"].tobytes()).hexdigest() not in raw_fingerprints
    supported = np.min(d["scores"], axis=0) >= plan["guide_half_threshold_each_fold"]
    assert supported.tolist() == d["accepted"]
    np.testing.assert_array_equal(
        np.array(d["original"]) * np.where(supported[:, None], 0.5, 1), d["frequencies"]
    )
assert len(query_keys) == len(raw_fingerprints) == 96 and len(donor_keys) == 16
assert not query_keys & donor_keys and checks == 768
for v in report["boards"]:
    x, y = [np.asarray(Image.open(checked(v[k]["image"]))) for k in ("board", "triplet")]
    for i, j in enumerate((0, 3, 5)):

        def area(panel):
            a, b, w, h = panel["png_xywh"]
            assert w == h == 160
            return np.s_[b : b + h, a : a + w]

        np.testing.assert_array_equal(
            x[area(v["board"]["panels"][j])], y[area(v["triplet"]["panels"][i])]
        )
for v in plan["retained_camera_review"]:
    checked(v["image"])
assert len(plan["retained_camera_review"]) == 8 and len(report["boards"]) == 4
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "frozen_calibrations_recomputed": 16,
        "fresh_queries_with_distinct_noise_keys_and_RAW": 96,
        "separate_donor_keys": 16,
        "actual_model_batch_calls": 32,
        "native_reductions": checks,
        "largest_error": maximum,
        "exact_triplet_subsets": 4,
        "adopted_camera_boards_verified": 8,
        "status": "passed",
    },
)
print(checks, maximum, "fresh audit passed")
