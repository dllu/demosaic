"""Summarize independent source pairs and plot the frozen operating points."""

from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
source = root / "review/result.json"
report = read_json(source)
plan = read_json(checked(report["plan"]))
metric_names = (
    "weak_gain",
    "strong_gain",
    "quiet_RMS_DN16",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "query_RMS_DN16",
    "abs_weak_absent_projection",
)
modes = ("fold-average", "weighted-refit")


def vector(r):
    return np.array(
        [
            r["weak_gain"],
            r["strong_gain"],
            r["quiet_RMS_DN16"],
            r["delta_from_parent"]["quiet_RMS_DN16"],
            r["weak_increment_RMS_DN16"],
            r["query_RMS_DN16"],
            abs(r["weak_absent_projection"]),
        ]
    )


samples = defaultdict(dict)
for row in report["frozen_budget_results"]:
    p = (row["profile"], row["placement"], row["budget_DN16"], row["method"])
    samples[p][row["source"]] = vector(row)
fixed = defaultdict(list)
for row in report["fixed_thresholds"]:
    fixed[row["profile"], row["placement"], row["method"], row["threshold"]].append(row)
assert all(len(v) == 8 for v in samples.values())
assert all(len(v) == 8 for v in fixed.values())
rng = np.random.default_rng(731143)
draws = rng.integers(0, 8, size=(12_000, 8))
summary = []
fig, ax = plt.subplots(2, 2, figsize=(10, 8), layout="constrained")
for i, profile in enumerate(("iso400", "iso6400")):
    for j, placement in enumerate(("far", "near")):
        axis = ax[i, j]
        for mode, color, marker in zip(modes, ("#4656a5", "#b55020"), ("o", "^"), strict=True):
            x, y = [], []
            for t in plan["thresholds"]:
                selected = fixed[profile, placement, mode, t]
                x.append(
                    float(
                        np.mean(
                            [
                                r["quiet_RMS_DN16"] - np.sqrt(r["moments"]["quiet_mse"][0])
                                for r in selected
                            ]
                        )
                    )
                )
                y.append(100 * float(np.mean([r["weak_gain"] for r in selected])))
            axis.plot(
                x,
                y,
                linewidth=1.3,
                markersize=4,
                marker=marker,
                color=color,
                label="Fold average" if mode == "fold-average" else "Weighted refit",
            )
            primary = np.array(list(samples[profile, placement, 0.02, mode].values())).mean(0)
            axis.scatter(
                primary[3],
                primary[0] * 100,
                marker="D",
                edgecolors="#252525",
                linewidth=0.7,
                s=42,
                color=color,
                zorder=5,
            )
        axis.set_title(
            f"{profile.upper()} · {placement} from edge"
            if placement == "far"
            else f"{profile.upper()} · near edge",
            loc="left",
            fontweight="bold",
        )
        axis.set_xlabel("Quiet RMS change from V143 (DN16)")
        axis.set_ylabel("Weak response (%)")
        axis.grid(alpha=0.14)
        axis.spines[["top", "right"]].set_visible(False)
        if (i, j) == (0, 0):
            axis.scatter(
                [],
                [],
                marker="D",
                facecolors="white",
                edgecolors="#252525",
                label="Frozen tight-budget setting",
            )
            axis.legend(frameon=False, fontsize=8)
        for budget in (0.02, 0.1):
            matrices = {
                mode: np.stack(
                    [samples[profile, placement, budget, mode][s] for s in plan["sources"]]
                )
                for mode in modes
            }
            difference = matrices["weighted-refit"] - matrices["fold-average"]
            samples_mean = {mode: values.mean(0).tolist() for mode, values in matrices.items()}
            baseline_rms = matrices["fold-average"][:, 2] - matrices["fold-average"][:, 3]
            summary.append(
                {
                    "profile": profile,
                    "placement": placement,
                    "budget_DN16": budget,
                    "parent_quiet_RMS_mean_DN16": float(baseline_rms.mean()),
                    "means": samples_mean,
                    "paired_difference": difference.tolist(),
                    "paired_difference_mean": difference.mean(0).tolist(),
                    "paired_descriptive_interval": np.quantile(
                        difference[draws].mean(axis=1), [0.025, 0.975], axis=0
                    ).tolist(),
                    "sources_with_more_response": int((difference[:, 0] > 0).sum()),
                    "sources_with_lower_increment_error": int((difference[:, 4] < 0).sum()),
                    "sources_exceeding_calibration_quiet_budget": {
                        mode: int((values[:, 3] > budget + 1e-10).sum())
                        for mode, values in matrices.items()
                    },
                }
            )
fig.suptitle("Frozen RAW refit settings on fresh wire geometries", fontweight="bold")
plot = root / "review/quiet-tradeoff.png"
fig.savefig(plot, dpi=150)
guide = report["guide_audit"]
coverage = defaultdict(list)
for item, outcome in guide.items():
    coverage[item.split("-")[0]].append(outcome)
guide_summary = {}
for profile, outcomes in coverage.items():
    pairs = np.array([r["errors_native_bins"] for r in outcomes])
    guide_summary[profile] = {
        "both_within_one_native_bin": int((pairs.max(axis=1) <= 1).sum()),
        "total": len(pairs),
        "maximum_error_native_bins": float(pairs.max()),
        "accepted_half_frequencies": sum(sum(r["accepted_halves"]) for r in outcomes),
    }
assert len(summary) == 8
write_json(
    root / "review/summary.json",
    {
        "source": reference(source),
        "driver": reference(__file__),
        "metrics": list(metric_names),
        "sources": plan["sources"],
        "frozen_budget_results": summary,
        "donor_coverage": guide_summary,
        "plot": reference(plot),
        "scope": "Paired source means and descriptive source-bootstrap intervals."
        " Fixed curves and frozen operating points use the same fresh fields. No threshold selection here.",
    },
)
for s in summary:
    print(s["profile"], s["placement"], s["budget_DN16"], s["means"], s["paired_difference_mean"])
print(guide_summary)
