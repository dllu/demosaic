"""Compare the two transferred ISO400 far estimators at exactly +0.02 DN16."""

from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, evaluated, measure
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
path = root / "plan.json"
plan = read_json(path)
selection = {"profile": "iso400", "placement": "far"}
target_budget = 0.02
settings = {
    v["method"]: v
    for v in plan["settings"]
    if all(v[k] == x for k, x in selection.items()) and v["budget_DN16"] == target_budget
}
groups = [g for g in plan["groups"] if all(g[k] == x for k, x in selection.items())]
assert len(groups) == 8 and len(settings) == 2
moments = {method: [] for method in settings}
records = []
for g in groups:
    p = root / "output" / (g["id"] + ".json")
    r = read_json(p)
    records.append(reference(p))
    with np.load(checked(r["target"])) as a:
        truth, quiet = a["target"].astype(np.float64), a["quiet"][ROI]
    parent = np.load(checked(r["parent"])).astype(np.float64)
    with np.load(checked(r["predictions"])) as a:
        for method, v in settings.items():
            moments[method].append(
                measure(parent, truth, quiet, a[f"{method}-t{v['threshold']:g}"])
            )


def operating_point(rows, frozen_scale):
    names = ("weak_gain", "quiet_RMS_DN16", "weak_increment_RMS_DN16", "weak_absent_projection")
    original_quiet = np.mean([evaluated(v, 0)["quiet_RMS_DN16"] for v in rows])

    def statistics(multiplier):
        values = [evaluated(v, frozen_scale * multiplier) for v in rows]
        return np.array(
            [[v[k] if k != "weak_absent_projection" else abs(v[k]) for k in names] for v in values]
        )

    def excess(multiplier):
        return statistics(multiplier)[:, 1].mean() - original_quiet - target_budget

    assert excess(0) < 0 < excess(1)
    multiplier = brentq(excess, 0, 1)
    scores = statistics(multiplier)
    assert abs(scores[:, 1].mean() - original_quiet - target_budget) < 1e-12
    return {
        "multiplier_on_frozen_scale": multiplier,
        "final_scale": frozen_scale * multiplier,
        "means": dict(zip(names, scores.mean(0).tolist(), strict=True)),
        "by_source": dict(zip((str(g["source"]) for g in groups), scores.tolist(), strict=True)),
        "metrics": list(names),
    }


rows = {
    method: operating_point(values, settings[method]["scale"]) for method, values in moments.items()
}
write_json(
    root / "absolute-quiet-diagnostic.json",
    {
        "plan": reference(path),
        "driver": reference(__file__),
        "case_records": records,
        "stratum": selection,
        "measured_budget_above_parent_DN16": target_budget,
        "diagnostic": rows,
        "scope": "Post-hoc ISO400 far diagnostic using fresh quiet targets. It scales each arm uniformly"
        " across the eight sources to reach the same observed mean quiet error. It retains"
        " the previous panel's selected thresholds and does not estimate an inference gate.",
    },
)
for method, v in rows.items():
    print(method, v["means"], v["final_scale"])
