"""Check unsupported fine error in the zero-wire observations."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.ndimage import binary_erosion, uniform_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
closed = read_json(checked(report["collection"]))
case_settings = defaultdict(list)
for row in report["frozen_budget_results"]:
    if row["budget_DN16"] == 0.02:
        case_settings[row["id"]].append(row)
rows = []
region = np.s_[..., 128:384, 128:384]


def measure(prediction, target, support, edge):
    residual = prediction - target
    detail = residual - uniform_filter(residual, size=(1, 7, 7), mode="reflect")
    detail = detail[region][:, support]
    luma = detail.mean(axis=0)
    chroma = detail - luma
    return {
        "quiet_fine_luma_RMS_DN16": float(np.sqrt(np.mean(luma**2)) * 65535),
        "quiet_fine_chroma_RMS_DN16": float(np.sqrt(np.mean(chroma**2)) * 65535),
        "near_edge_RGB_RMS_DN16": (
            float(np.sqrt(np.mean(residual[region][:, edge] ** 2)) * 65535) if edge.any() else None
        ),
    }


for link in closed["cases"]:
    case = read_json(checked(link))
    with np.load(checked(case["target"])) as data:
        target = data["target"][0].astype(np.float64)
        quiet = binary_erosion(data["quiet"], structure=np.ones((7, 7), bool))[region]
        edge = data["edge_band"][region]
    assert quiet.sum() > 1000
    base = np.load(checked(case["parent"]))[0].astype(np.float64)
    variants = [("parent", base)]
    with np.load(checked(case["predictions"])) as data:
        for v in case_settings[case["id"]]:
            delivered = base.copy()
            delivered[region] += v["scale"] * (
                data[f"{v['method']}-t{v['threshold']:g}"][0] - base[region]
            )
            variants.append((v["method"], delivered))
    assert len(variants) == 3
    for label, prediction in variants:
        rows.append(
            {
                "id": case["id"],
                "profile": case["profile"],
                "placement": case["placement"],
                "method": label,
                "source": case["source"],
                "quiet_sites": int(quiet.sum()),
                "edge_sites": int(edge.sum()),
                **measure(prediction, target, quiet, edge),
            }
        )
assert len(rows) == 96
metrics = ("quiet_fine_luma_RMS_DN16", "quiet_fine_chroma_RMS_DN16", "near_edge_RGB_RMS_DN16")
summaries = []
for profile in ("iso400", "iso6400"):
    for placement in ("far", "near"):
        means = {}
        for method in ("parent", "fold-average", "weighted-refit"):
            cells = [
                r
                for r in rows
                if (r["profile"], r["placement"], r["method"]) == (profile, placement, method)
            ]
            assert len(cells) == 8
            means[method] = {}
            for key in metrics:
                values = [r[key] for r in cells if r[key] is not None]
                means[method][key] = float(np.mean(values)) if values else None
        summaries.append({"profile": profile, "placement": placement, "means": means})
write_json(
    root / "quiet-texture.json",
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "results": rows,
        "summaries": summaries,
        "scope": "Fresh background-only sensor role at frozen 0.02-DN16 development settings."
        " Camera-linear mean RGB and residual chroma after a 7×7 high-pass; exact quiet mask"
        " eroded by a square 7×7 support. Near-edge RGB uses the exact scene edge mask."
        " Means average source-level RMS, in units of 65535 values per camera-linear unit.",
    },
)
for row in summaries:
    print(row)
