"""Publish frozen RAW phase measurements and the native GFX and exact comparisons."""

from copy import deepcopy
from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay import metric
import junction_phase_field as model

OUT = model.OUT
HERE = model.HERE
ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "replay-calibration",
    "replay-independent",
    "replay-straight",
    "camera-phase",
    "reference-phase",
    "phase-accuracy",
    "audit",
    "ordinary",
    "views-camera",
    "views-exact",
    "pool-camera",
    "pool-calibration",
    "pool-independent",
    "lock-pool-calibration",
    "lock-pool-independent",
    *(
        f"{kind}/{p}"
        for kind in ("calibration", "independent")
        for p in ("plan", "inputs", "parent/result")
    ),
)
REUSED = (
    "local-junction-support-v1/capture_junction.py",
    "local-junction-support-v1/review_junction.py",
    "local-junction-support-v1/replay_junction.py",
    "local-nested-support-v1/replay_nested_parents.py",
)


def binding(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def save(row):
    src = checked(row["image"])
    dest = ASSETS / src.name
    shutil.copyfile(src, dest)
    ref = binding(dest)
    assert ref["sha256"] == row["image"]["sha256"]
    with Image.open(dest) as frame:
        for tile in row["panels"]:
            x, y, w, h = tile["png_xywh"]
            assert (
                (w, h) == (160, 160)
                and 0 <= x < x + w <= frame.width
                and 0 <= y < y + h <= frame.height
            )
    return row | {"image": ref}


def main():
    refs = {k: reference(OUT / f"{k}.json") for k in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in refs.items()}
    for k, v in data.items():
        for key in ("operator", "driver"):
            if key in v:
                checked(v[key])
    fixture_panels = {}
    visited = set()
    for kind in ("calibration", "independent"):
        plan = data[f"{kind}/plan"]
        inputs = data[f"{kind}/inputs"]
        parents = data[f"{kind}/parent/result"]
        assert data[f"replay-{kind}"]["source"] == refs[f"{kind}/parent/result"]
        assert refs[f"{kind}/plan"] == inputs["plan"] == data[f"replay-{kind}"]["plan"]
        assert refs[f"{kind}/inputs"] == parents["inputs"]
        assert len(plan["sources"]) == (24 if kind == "calibration" else 32)
        assert all(r["source"]["split"] == "val" for r in plan["sources"])
        for source, actual, pred in zip(
            plan["sources"], inputs["observations"], parents["records"], strict=True
        ):
            assert source["id"] == actual["id"] == pred["id"]
            g = source["source"]
            ident = {g["id"], g["cache_sha256"]}
            assert visited.isdisjoint(ident)
            visited.update(ident)
            checked({"path": g["cache"], "sha256": g["cache_sha256"]})
            for a, b in zip(actual["streams"], pred["streams"], strict=True):
                assert a["data"] == b["data"]
                checked(a["data"])
                for v in b["outputs"].values():
                    checked(v)
        for ck in parents["weights"].values():
            checked(ck)
        fixture_panels[kind] = parents["weights"]
    assert fixture_panels["calibration"] == fixture_panels["independent"]
    assert (
        data["replay-independent"]["calibration"]
        == data["replay-straight"]["calibration"]
        == refs["replay-calibration"]
    )
    assert data["lock-pool-independent"]["calibration"] == refs["lock-pool-calibration"]
    for k in ("calibration", "independent"):
        assert data[f"lock-pool-{k}"]["source"] == refs[f"pool-{k}"]
    for k in ("views-camera", "views-exact"):
        r = data[k]
        assert (
            r["locked_recipe"] == refs["replay-calibration"]
            and r["evaluation"] == refs["replay-independent"]
        )
    assert not any(any(x.values()) for x in data["ordinary"]["changes"].values())
    camera = deepcopy(data["views-camera"]["report"]["rows"])
    exact = deepcopy(data["views-exact"]["report"]["rows"])
    assert len(camera) == 8 and len(exact) == 2
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    for r in camera:
        r["native"] = [save(x) for x in r["native"]]
    for r in exact:
        for k in ("all", "triplet"):
            r[k] = save(r[k])
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {
            "checkpoints": fixture_panels["independent"],
            "exact": exact,
            "camera": camera,
            "recipe": refs["replay-calibration"],
        },
    )
    files = {f"receipts/{k}.json": v for k, v in refs.items()}
    files.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    files.update({f"log/{p.name}": reference(p) for p in OUT.glob("*.log")})
    files.update({f"reused/{p}": reference(HERE.parent / p) for p in REUSED})
    files.update(
        {
            f"implementation/{p}": reference(ROOT / p)
            for p in (
                "src/demosaic/_mesh_junction.py",
                "src/demosaic/mesh_carrier_fit.py",
                "configs/gfx-qualitative-20231231.json",
                "configs/gfx-green-mesh-20231231.json",
            )
        }
    )
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for name, item in files.items():
            tar.add(checked(item), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == files.keys()
        for name, item in files.items():
            with tar.extractfile(name) as f:
                assert file_digest(f, "sha256").hexdigest() == item["sha256"]
    local = data["replay-independent"]["summary"]["panels"]["varying"]["scores"]
    pool = data["lock-pool-independent"]["summary"]["panels"]["varying"]["scores"]
    phase_recovery = (
        pool["primary"]["means"][metric.RESPONSE] - pool["baseline"]["means"][metric.RESPONSE]
    )
    at_equal_gap = local["primary"]["means"][metric.GAP] / pool["primary"]["means"][metric.GAP]
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            "calibration": data["replay-calibration"]["summary"],
            "independent": data["replay-independent"]["summary"],
            "straight": data["replay-straight"]["summary"],
            "pool": data["lock-pool-independent"]["summary"],
            "pooled_response_gain_at_matched_gap_DN16": at_equal_gap * phase_recovery,
            "phase_accuracy": data["phase-accuracy"]["summary"],
            "ordinary": data["ordinary"]["changes"],
            "isolated_fold_audit": data["audit"]["layouts"],
            "camera": {r["id"]: r["difference_DN16"] for r in camera},
            "camera_phase": data["reference-phase"]["rows"],
        },
    )
    write_json(
        RESULTS / "publication.json",
        {
            "archive": binding(archive),
            "native": binding(manifest),
            "summary": binding(summary),
            "members": files,
            "scope": "Held phase and matched exact photo crop evaluation. Frozen EMA, no training.",
        },
    )
    print(binding(archive), flush=True)


if __name__ == "__main__":
    main()
