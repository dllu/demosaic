"""Render fixed optical junction tests with independently varied local phase."""

from pathlib import Path
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PREVIOUS = OUT.with_name("phase-screened-conditioning-v1") / "independent/plan.json"
sys.path.append(str(HERE.parent / "local-junction-support-v1"))
import capture_junction as base

ENGINE = base.source.last.run
SEED = {"calibration": 202611200744, "independent": 202611200745}


def choose(kind, root):
    before = reference(PREVIOUS)
    if kind == "calibration":
        original = read_json(checked(before))
    else:
        ENGINE.OUT = root
        ENGINE.SEED = SEED[kind]
        ENGINE.COUNT = 32
        older = lambda folder, room: OUT.with_name(folder) / room / "plan.json"
        ENGINE.prior.EXCLUSIONS += (
            PREVIOUS,
            base.ORIGINAL,
            older("local-junction-support-v1", "calibration"),
            older("local-junction-support-v1", "independent"),
            older("cfa-junction-phase-v1", "held"),
            *(
                older("local-replicated-phase-v1", g)
                for g in ("fresh", "verification", "station-confirm")
            ),
            older("local-unranked-phase-v1", "fresh"),
            older("local-near-phase-v1", "fresh"),
            older("local-phase-transport-v2", "fresh"),
        )
        original = ENGINE.freeze()
    for r in original["sources"]:
        i = r["index"]
        g = r["geometry"]
        rng = np.random.default_rng(scene_seed(SEED[kind], i, "junction-phase-field"))
        r["id"] = f"warped-{kind}-{i:02d}"
        g["interaction_ratio"] = float(rng.uniform(0.72, 1.14))
        g["strength"][1] = float(g["strength"][0] * rng.uniform(0.72, 1.20))
        g["relative_interaction_polarity"] = 1 if (i // 2 + i // 8) % 2 else -1
        signs = 1 if i % 2 else -1
        g["bend_cycles"] = [
            float(-signs * rng.uniform(0.00, 0.11)),
            float(signs * rng.uniform(0.14, 0.32)),
        ]
        g["drift_cycles"] = rng.uniform(-0.12, 0.12, (2, 2)).tolist()
        # In these controls the junction band stays planar despite the curved wires.
        g["stationary_junction"] = i % (4 if kind == "independent" else 6) == 0
    return original | {
        "driver": reference(__file__),
        "previous": before,
        "roles": base.ROLES,
        "seed": SEED[kind],
        "scope": "Counterfactual crossings with spatial phase drift, matched additive roles, and a planar-interaction control.",
    }


def fields(x, y, g):
    result = []
    extent = torch.maximum(x.abs(), y.abs())
    taper = ((151 - extent) / 39).clamp(0, 1)
    for frequency, phase, bends, drift in zip(
        g["frequency"], g["phase"], g["bend_cycles"], g["drift_cycles"], strict=True
    ):
        fx, fy = frequency
        ref = 2 * np.pi * (fx * x + fy * y) + phase
        u, v = x / 80, y / 80
        tangent = (-fy * u + fx * v) / np.hypot(fx, fy)
        drift_1, drift_2 = drift
        shift = 2 * np.pi * (bends * tangent.square() + drift_1 * u + drift_2 * v) * taper
        result.append((ref, shift))
    return result


def warped(case):
    loader = base.source.last.run.prior.earlier.capture_wide.wire_math
    photo = loader.decode(case["source"], case["box"])
    g = case["geometry"]
    axis = torch.arange(512) - 255.5
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    extent = torch.maximum(x.abs(), y.abs())
    shell = ((extent - 132) / 27).clamp(0, 1)
    tones = (
        0.085
        + 0.52 * F.avg_pool2d(photo[None], 11, stride=1, padding=5, count_include_pad=False)[0]
    )
    distance = x * np.cos(g["angle"]) + y * np.sin(g["angle"]) - g["edge"]
    step = torch.sigmoid(distance / 1.3)
    tones = tones + torch.as_tensor(g["tint"])[:, None, None] * step
    phase, phase_offset = zip(*fields(x, y, g), strict=True)
    first, second = [a + b for a, b in zip(phase, phase_offset, strict=True)]

    def wire(p, width):
        return sum(
            np.exp(-2 * np.pi**2 * width**2 * (h * h - 1)) * (h * p).cos() for h in range(1, 6)
        )

    head = tones + g["strength"][0] * wire(first, g["width"][0])
    rear = g["strength"][1] * wire(second, g["width"][1]) * (0.70 + 0.30 * step)
    _, _, support, _ = loader.exact(photo, g)
    difference = (phase[0] - phase[1]) if g["stationary_junction"] else first - second
    factor = g["relative_interaction_polarity"] * g["interaction_ratio"] * g["strength"][1] / 2
    term = difference.cos() * factor * support * (0.75 + 0.25 * step)
    together = head + rear * support
    fade = ((128 - extent) / 57).clamp(0, 1)
    flat = together[:, 198:314, 198:314].mean((-2, -1), keepdim=True).expand_as(tones).clone()
    exterior = tones + 0.025 * phase[0].cos() + 0.025 * phase[1].cos()
    roles = (
        together + term,
        together,
        head + rear,
        head,
        torch.lerp(together, flat, fade),
        tones,
        flat,
    )
    clean = tuple(torch.lerp(img, exterior, shell) for img in roles)
    junctions = (first.cos() > 0.55) & (second.cos() > 0.55) & (support > 0.95)
    assert all(0 < float(im.min()) and float(im.max()) < 1 for im in clean)
    return clean, support, junctions


def main(kind):
    torch.set_num_threads(2)
    root = OUT / kind
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    plan_file = root / "plan.json"
    if not plan_file.exists():
        write_json(plan_file, choose(kind, root))
    plan = read_json(plan_file)
    assert plan["driver"] == reference(__file__)
    receipt = root / "inputs.json"
    if not receipt.exists():
        start = monotonic()
        rows = []
        with patch.object(base, "clean_scenes", warped):
            for r in plan["sources"]:
                rows.append(
                    {
                        "id": r["id"],
                        "streams": list(
                            base.save_case(
                                r, SEED[kind], plan["noise"], plan["sigma"], root / "inputs"
                            )
                        ),
                    }
                )
                if len(rows) % 8 == 0:
                    print(kind, "captured", len(rows), flush=True)
        write_json(
            receipt,
            {
                "driver": reference(__file__),
                "plan": reference(plan_file),
                "observations": rows,
                "seconds": monotonic() - start,
            },
        )
    ENGINE.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        ENGINE.prior.parents.main()


if __name__ == "__main__":
    main(sys.argv[1])
