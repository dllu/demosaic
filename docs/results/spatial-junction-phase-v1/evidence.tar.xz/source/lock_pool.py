"""Lock a pooled-amplitude dose on the earlier calibration captures."""

from pathlib import Path
import sys

from replay import OUT, lock, summary, metric
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main(kind):
    source = reference(OUT / f"pool-{kind}.json")
    data = read_json(checked(source))
    calibration = None if kind == "calibration" else reference(OUT / "lock-pool-calibration.json")
    policy = (
        lock(data["rows"]) if calibration is None else read_json(checked(calibration))["policy"]
    )
    table = summary(data["rows"], policy)
    print(table["choices"]["primary"], flush=True)
    measurements = (metric.RESPONSE, metric.JUNCTION, metric.GAP, metric.ADD, metric.CONTINUOUS_ADD)
    for name, record in table["panels"].items():
        for m in ("baseline", "primary", "supplied"):
            counts = record["scores"][m]["means"]
            print(kind, name, m, [round(counts[key], 4) for key in measurements], flush=True)
    write_json(
        OUT / f"lock-pool-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "calibration": calibration,
            "policy": policy,
            "summary": table,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
