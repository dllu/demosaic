"""Compare pooled and local amplitude under identical spatial-phase admissions."""

from pathlib import Path
import sys
from statistics import mean
from unittest.mock import patch

import numpy as np

import junction_phase_field as model
from replay import collect, metric, subsets, BASE
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

J = model.j
OUT = model.OUT
LOCAL = J._amplitudes
ARMS = model.ARMS
METHODS = ("affine", "curved", "curved-replicated")


def pool(obs, cols, index, sign, maximum, parent):
    cutoff = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    w = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2) / obs.variance
    stack = np.c_[obs.raw, parent]
    values = []
    variances = []
    for fold in (1, 2, 3):
        use = cutoff & (obs.fold == fold)
        a = cols[use]
        left = a.T * w[use]
        covariance = np.linalg.pinv(left @ a, hermitian=True, rcond=1e-9)
        values.append(sign * covariance[index] @ (left @ stack[use]))
        variances.append(covariance[index, index] * sign**2)
    positive = np.maximum(0, np.asarray(values)[:, 0])
    pairs = ((0, 1), (0, 2), (1, 2))
    product = mean(positive[a] * positive[b] for a, b in pairs)
    floor = mean(np.sqrt(variances[a] * variances[b]) for a, b in pairs)
    strength = max(0, 1 - floor / max(1e-20, product))
    target, ancestor = np.average(values, axis=0, weights=1 / np.asarray(variances))
    return float(np.clip(strength * target - max(0, ancestor), 0, 1.5 * maximum))


def pooled(obs, cols, index, sign, maximum, parent, *, sigma=35, radius=80):
    return np.full((256, 256), pool(obs, cols, index, sign, maximum, parent))


def evaluate(group):
    original = model.deliver

    def deliver(*args, **kwargs):
        with patch.object(J, "_amplitudes", pooled):
            return original(*args, **kwargs)

    source = reference(OUT / group / "parent/result.json")
    with patch.object(model, "deliver", deliver):
        rows, plan, seconds = collect(source)
    baseline = reference(OUT / f"replay-{group}.json")
    local = read_json(checked(baseline))
    assert local["source"] == source and local["plan"] == plan
    values = {}
    for (name, a), (other, b) in zip(
        subsets(rows).items(), subsets(local["rows"]).items(), strict=True
    ):
        assert name == other
        values[name] = {}
        for mode in METHODS:
            key = (mode, 1)
            summary = metric.score(a, key)
            values[name][mode] = {
                "pool": summary,
                "pool_vs_base": metric.paired(a, key, BASE),
                "local": metric.score(b, key),
            }
            print(
                group,
                name,
                mode,
                summary["means"][metric.RESPONSE],
                summary["means"][metric.JUNCTION],
                summary["means"][metric.GAP],
                flush=True,
            )
    return {"input": source, "local": baseline, "rows": rows, "summary": values, "seconds": seconds}


def camera():
    original = model.deliver

    def deliver(*args, **kwargs):
        with patch.object(J, "_amplitudes", pooled):
            return original(*args, **kwargs)

    binding = reference(OUT / "camera-phase.json")
    source = read_json(checked(binding))
    fixed = read_json(checked(source["source"]))
    rows = []
    for r in fixed["standing"]:
        with np.load(checked(r["input"]), allow_pickle=False) as f:
            raw, cfa, wb, matrix = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        p = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = r["local_ROI"]
        with patch.object(model, "deliver", deliver):
            results, record = model.replay(
                p, roi, raw, cfa, roi, r["noise"], wb, matrix, clearance=16
            )
        diffs = {
            k: float(np.sqrt(np.mean((v.astype(float) - results["baseline"]) ** 2)) * 65535)
            for k, v in results.items()
        }
        print(r["id"], {k: round(v, 3) for k, v in diffs.items()}, flush=True)
        rows.append({"id": r["id"], "pooled": diffs, "record": record})
    return {"source": binding, "rows": rows}


if __name__ == "__main__":
    group = sys.argv[1]
    readout = camera() if group == "camera" else evaluate(group)
    write_json(
        OUT / f"pool-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            **readout,
        },
    )
