"""Test a spatial difference phase against a fixed carrier with varying amplitude."""

from pathlib import Path

import numpy as np

from demosaic import _mesh_junction as j
from demosaic.mesh_carrier_fit import _sites, _spacing, refine_raw_mesh_carriers

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ARMS = ("baseline", "affine", "curved", "curved-replicated", "curved-quarter")
CROP = np.s_[..., 48:208, 48:208]
FULL_X = j._GRID_X.ravel()
FULL_Y = j._GRID_Y.ravel()


def crop(im, roi):
    x, y, w, h = roi
    return im[..., y : y + h, x : x + w]


def prepare(packed, colors, roi, noise, clearance):
    x, y = roi[:2]
    f = _spacing(packed, colors, x, y, clearance=clearance)
    if f is None:
        return None
    bands = j._distinct_bands(f)
    if j._DIFFERENCE not in bands:
        return None
    x -= 48
    y -= 48
    scene = np.stack([_sites(packed, x, y, 256, r, c) for r, c in np.ndindex(2, 2)])
    greens = [
        2 * r + c for r, c in np.ndindex(2, 2) if colors[2 * ((y + r) % 2) + (x + c) % 2] == 1
    ]
    if not np.isfinite(scene[greens]).all():
        return None
    return j._Observation.make(scene, greens, f, noise["shot"], noise["read"]), f, bands


def coordinates(x, y):
    x, y = x / 80, y / 80
    return np.column_stack((np.ones_like(x), x, y))


def basis(x, y, frequencies, curved):
    u = coordinates(x, y)
    for fx, fy in frequencies:
        if curved:
            z = (-fy * u[:, 1] + fx * u[:, 2]) / np.hypot(fx, fy)
            yield np.column_stack((u, z * z))
        else:
            yield u


def solve(a, weight, y, penalty=0):
    design = a.T * weight
    gram = design @ a
    if np.isscalar(penalty):
        return np.linalg.pinv(gram, hermitian=True, rcond=1e-10) @ (design @ y)
    return np.linalg.solve(gram + np.diag(np.diag(gram) * penalty), design @ y)


def fit_envelopes(obs, f, bands, fold, curved, inner, taper):
    # The fixed higher orders are nuisance in the fundamental phase fit.
    wave = j._quadratures(obs.angles)
    selected = inner & (obs.fold == fold)
    harm = j._quadratures(obs.angles @ np.asarray(bands).T).reshape(len(wave), -1)
    base = np.c_[obs.nuisance, harm]
    size = 4 if curved else 3
    terms = [
        (wave[:, d, :, None] * geom[:, None, :]).reshape(len(wave), -1)
        for d, geom in enumerate(basis(obs.x, obs.y, f, curved))
    ]
    model = np.column_stack((base, *terms))
    ridge = np.r_[np.zeros(base.shape[1]), np.tile(np.r_[0.0, np.full(size - 1, 0.10)], 4)]
    fitted = solve(
        model[selected], taper[selected] / obs.variance[selected], obs.raw[selected], ridge
    )
    return fitted[-4 * size :].reshape(2, 2, size)


def phases(x, y, coeff, frequencies, curved):
    result = []
    for d, m in enumerate(basis(x, y, frequencies, curved)):
        c = coeff[d]
        neutral = complex(c[0, 0], -c[1, 0])
        q = m @ c[0] - 1j * (m @ c[1])
        # Disallow an amplitude zero crossing from rotating the phase by half a cycle.
        direction = neutral / max(1e-12, abs(neutral))
        q = q * direction.conjugate()
        bounded = np.maximum(0.30 * abs(neutral), q.real) + 1j * q.imag
        result.append(np.angle(bounded * direction))
    return j._wave_angles(x, y, frequencies) + np.stack(result, axis=-1)


def stationary(obs, inner, taper):
    sel = inner & (obs.fold == 0)
    q = j._quadratures(obs.angles).reshape(len(obs.x), -1)
    a = np.c_[obs.nuisance, q]
    b = solve(a[sel], taper[sel] / obs.variance[sel], obs.raw[sel])[-4:].reshape(2, 2)
    return np.arctan2(-b[:, 1], b[:, 0])


def field_agreement(a, b, static, taper, inner):
    # Check the spatial departure after removing a constant disagreement.
    delta = a - b
    rotation = np.angle(np.sum(taper[inner, None] * np.exp(1j * delta[inner]), axis=0))
    fund = np.sum(taper[inner, None] * np.cos(delta[inner] - rotation), axis=0) / taper[inner].sum()
    a, b = [q[:, 0] - q[:, 1] - (static[0] - static[1]) for q in (a, b)]
    return fund.tolist(), float(np.mean(np.cos((a - b)[inner] - (rotation[0] - rotation[1]))))


def stationary_side(x, y, angles, center):
    q = angles[:, 0] - angles[:, 1] + center[0] - center[1]
    u, v = x / 80, y / 80
    rows = np.column_stack((np.ones_like(u), u, v, u * u, u * v, v * v))
    return np.column_stack((np.cos(q)[:, None] * rows, np.sin(q)))


def shape_baseline(obs, f, bands, center, dynamic):
    a = j._quadratures(dynamic).reshape(len(obs.x), -1)
    # Rival harmonic carriers curve with the wires. The tested difference stays in the stationary model.
    rest = np.array([v for v in bands if v != j._DIFFERENCE], dtype=float).reshape(-1, 2)
    rivals = j._quadratures(dynamic @ rest.T).reshape(len(obs.x), -1)
    s = stationary_side(obs.x, obs.y, obs.angles, center)
    return np.column_stack((obs.nuisance, a, rivals, s)), s.shape[1]


def predict(obs, f, bands, mode, inner, taper, center):
    is_curved = mode != "affine"
    coeff = fit_envelopes(obs, f, bands, 0, is_curved, inner, taper)
    other = fit_envelopes(obs, f, bands, 1, is_curved, inner, taper)
    a, b = [phases(obs.x, obs.y, k, f, is_curved) for k in (coeff, other)]
    agreement, relative = field_agreement(a, b, center, taper, inner)
    allowed = min(agreement) >= 0.82 and relative >= 0.76

    # Average circular estimates only in the replicated control. Neither sees held RAW values.
    def average(x, y):
        initial, replica = [phases(x, y, k, f, is_curved) for k in (coeff, other)]
        if mode != "curved-replicated":
            return initial
        return initial + 0.5 * np.angle(np.exp(1j * (replica - initial)))

    return average, allowed, agreement, relative


def supplied_phase(geometry):
    f = np.asarray(geometry["frequency"])
    center = np.asarray(geometry["phase"])
    bend = np.asarray(geometry["bend_cycles"])
    drift = np.asarray(geometry["drift_cycles"])

    def forecast(x, y):
        uv = np.column_stack((x, y)) / 80
        tangent = f[:, ::-1] * (-1, 1) / np.linalg.norm(f, axis=1)[:, None]
        collar = np.clip((151 - np.maximum(abs(x), abs(y))) / 39, 0, 1)
        shift = 2 * np.pi * ((uv @ tangent.T) ** 2 * bend + uv @ drift.T) * collar[:, None]
        return j._wave_angles(x, y, f) + center + shift

    return forecast


def candidate(obs, f, bands, mode, inner, taper, center, geometry):
    if mode == "supplied":
        phase, replicated, pair, closure = supplied_phase(geometry), True, [1.0, 1.0], 1.0
    else:
        phase, replicated, pair, closure = predict(obs, f, bands, mode, inner, taper, center)
    known = phase(obs.x, obs.y)
    record = {"phase_pair": pair, "phase_closure": closure, "replicated": replicated}
    waves = j._quadratures(known)
    fundamentals = []
    for d in (0, 1):
        nuisance = np.c_[obs.nuisance, waves[:, 1 - d]]
        z, each = obs.held_score(waves[:, d, 0], nuisance, inner)
        fundamentals.append([float(z), float(each)])
    record["fundamentals"] = fundamentals
    if not all(z >= 2.75 and each > 0 for z, each in fundamentals):
        return None, record
    if mode == "curved-replicated" and not replicated:
        return None, record
    basis_side, count = shape_baseline(obs, f, bands, center, known)
    shift = np.pi / 2 if mode == "curved-quarter" else 0
    signal = np.cos(known[:, 0] - known[:, 1] + shift)
    used = inner & (obs.fold == 0)
    w = taper[used] / obs.variance[used]
    decomposition = solve(basis_side[used], w, signal[used])
    remnant = signal - basis_side @ decomposition
    ratio = (w @ remnant[used] ** 2) / (w @ signal[used] ** 2)
    maximum = (w * remnant[used]) @ obs.raw[used] / max(1e-20, w @ remnant[used] ** 2)
    sign = np.sign(maximum)
    score, each = obs.held_score(sign * signal, basis_side, inner)
    record.update(
        {
            "ratio": float(ratio),
            "amplitude_DN16": float(maximum * 65535),
            "score": [float(score), float(each)],
        }
    )
    if ratio < 0.025 or score < 3.25 or each < 0.90:
        return None, record
    return (sign, abs(maximum), basis_side, signal, phase, shift, decomposition[-count:]), record


def replay(nominal, local, packed, colors, roi, noise, wb, matrix, *, clearance=48, geometry=None):
    x, y, w, h = local
    context = crop(nominal, (x - 48, y - 48, w + 96, h + 96))
    anchor = refine_raw_mesh_carriers(
        crop(nominal, local),
        packed,
        colors,
        roi,
        shot=noise["shot"],
        read=noise["read"],
        white_balance=wb,
        camera_to_srgb=matrix,
        method="weak-junction-refit",
        parent_context=context,
        donor_clearance=clearance,
    )
    obs = prepare(packed, colors, roi, noise, clearance)
    if obs is None:
        modes = ARMS if geometry is None else (*ARMS, "supplied")
        return dict.fromkeys(modes, anchor), {"status": "no frequencies", "arms": {}}
    return deliver(anchor, context, *obs, wb, matrix, geometry=geometry)


def deliver(anchor, context, obs, f, bands, wb, matrix, *, geometry=None):
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    taper = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2)
    center = stationary(obs, inner, taper)
    ancestor = context[1].copy()
    ancestor[CROP] = anchor[1]
    rgb = ancestor[(obs.y + j._CENTER).astype(int), (obs.x + j._CENTER).astype(int)]
    neutral = np.linalg.solve(matrix.astype(float), np.ones(3)) / wb
    neutral /= neutral[1]
    result = {"baseline": anchor}
    report = {}
    modes = ARMS[1:] if geometry is None else (*ARMS[1:], "supplied")
    for mode in modes:
        estimate, record = candidate(obs, f, bands, mode, inner, taper, center, geometry)
        if estimate is None:
            report[mode] = record | {"change": False, "admitted": False}
            result[mode] = anchor
            continue
        sign, cap, nuisance, signal, forecast, shift, station = estimate
        known = forecast(obs.x, obs.y)
        wire = j._local_wire_support(obs, known)
        at_image = forecast(FULL_X, FULL_Y)
        # Deliver only the component outside the stationary carrier, without any smooth nuisance.
        stationary_span = stationary_side(FULL_X, FULL_Y, j._wave_angles(FULL_X, FULL_Y, f), center)
        harmonic = sign * (
            np.cos(at_image[:, 0] - at_image[:, 1] + shift) - stationary_span @ station
        ).reshape(256, 256)
        amplitude = j._amplitudes(
            obs, np.c_[nuisance, signal], nuisance.shape[1], sign, cap, rgb, sigma=35, radius=80
        )
        edge = j._FIELD_EDGE[:, None] * j._FIELD_EDGE
        term = j._GAINS * wire * (amplitude * harmonic * edge)[CROP]
        out = (anchor + term * neutral[:, None, None]).astype(anchor.dtype)
        result[mode] = out
        report[mode] = record | {
            "change": not np.array_equal(anchor, out),
            "admitted": True,
            "wire_fraction": float(wire.mean()),
        }
    return result, {"status": "measured", "frequency": f.tolist(), "arms": report}
