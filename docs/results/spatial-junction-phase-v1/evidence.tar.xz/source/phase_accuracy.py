"""Compare estimated relative phase with the known optical-fixture geometry."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_phase_field as model

OUT = model.OUT
J = model.j


def offset(angles):
    return angles[..., 0] - angles[..., 1]


def one(fixture, binding, profile):
    with np.load(checked(binding), allow_pickle=False) as f:
        colors, scene, inside, truth = [
            f[k] for k in ("colors", "scene_packed", "packed", "support")
        ]
    scene[:, 64:192, 64:192] = inside[0]
    ob = model.prepare(scene, colors, (176, 176, 160, 160), profile, 48)
    if ob is None:
        return None
    obs, freq, bands = ob
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    taper = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2)
    center = model.stationary(obs, inner, taper)
    x, y = J._GRID_X[J._CORE].ravel(), J._GRID_Y[J._CORE].ravel()
    planar = J._wave_angles(x, y, freq) + center
    geo = fixture["geometry"]
    exact = model.supplied_phase(geo)(x, y)
    if geo["stationary_junction"]:
        exact = J._wave_angles(x, y, geo["frequency"]) + np.asarray(geo["phase"])
    keep = truth[J._CORE].ravel() >= 0.95
    functions = {"static": planar}
    trace = {}
    for arm in ("affine", "curved", "curved-replicated"):
        phase, agree, per, relative = model.predict(obs, freq, bands, arm, inner, taper, center)
        functions[arm] = phase(x, y)
        trace[arm] = {"replicated": agree, "wire_agreement": per, "relative_agreement": relative}
    error = {name: offset(p)[keep] - offset(exact)[keep] for name, p in functions.items()}
    return {
        "agreement": {
            k: {
                "absolute": float(np.mean(np.cos(v))),
                "ignoring_constant": float(abs(np.exp(1j * v).mean())),
            }
            for k, v in error.items()
        },
        "phase_repetition": trace,
        "error_in_nominated_frequency": float(
            np.linalg.norm(freq - np.asarray(geo["frequency"]), axis=1).max()
        ),
    }


def main():
    source = reference(OUT / "independent/inputs.json")
    data = read_json(checked(source))
    plan = read_json(checked(data["plan"]))
    report = []
    for fixture, item in zip(plan["sources"], data["observations"], strict=True):
        assert fixture["id"] == item["id"]
        record = [one(fixture, b["data"], plan["noise"]) for b in item["streams"]]
        report.append(
            {
                "id": item["id"],
                "stationary": fixture["geometry"]["stationary_junction"],
                "views": record,
            }
        )
    result = {}
    for key in ("varying", "stationary"):
        draws = [
            [s["agreement"] for s in r["views"] if s is not None]
            for r in report
            if r["stationary"] == (key == "stationary")
        ]
        fields = [r for r in draws if r]
        result[key] = {
            "count": len(fields),
            "phase": {
                arm: {
                    measure: mean(mean(d[arm][measure] for d in row) for row in fields)
                    for measure in ("absolute", "ignoring_constant")
                }
                for arm in fields[0][0]
            },
        }
    print(result, flush=True)
    write_json(
        OUT / "phase-accuracy.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "source": source,
            "rows": report,
            "summary": result,
        },
    )


if __name__ == "__main__":
    main()
