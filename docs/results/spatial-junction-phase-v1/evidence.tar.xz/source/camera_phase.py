"""Measure whether local phase improves native Bayer support on the two captures."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_phase_field as model

FIXED = model.OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"


def main():
    source = reference(FIXED)
    old = read_json(checked(source))
    rows = []
    for row in old["standing"]:
        with np.load(checked(row["input"]), allow_pickle=False) as streams:
            raw, colors, wb, matrix = [
                streams[key][0] for key in ("packed", "colors", "wb", "matrix")
            ]
        parent = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        arguments = row["local_ROI"]
        outputs, report = model.replay(
            parent, arguments, raw, colors, arguments, row["noise"], wb, matrix, clearance=16
        )
        a = outputs["baseline"].astype(float)
        delta = {name: float(np.sqrt(np.mean((v - a) ** 2)) * 65535) for name, v in outputs.items()}
        estimates = report["arms"]
        print(
            row["id"],
            {
                key: (v.get("score"), v.get("phase_closure"), round(delta[key], 4))
                for key, v in estimates.items()
            },
            flush=True,
        )
        rows.append(
            {
                "id": row["id"],
                "input": row["input"],
                "noise": row["noise"],
                "ROI": row["global_ROI"],
                "phase": report,
                "difference_DN16": delta,
            }
        )
    write_json(
        model.OUT / "camera-phase.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "source": source,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
