"""Evaluate independently checked spatial phase on paired optical fixtures."""

from pathlib import Path
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np

import junction_phase_field as model
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.append(str(model.HERE.parent / "local-junction-support-v1"))
import replay_junction as metric

OUT = model.OUT
KEYS = (*model.ARMS, "supplied")
LIMITS = {
    "gap_DN16": 0.15,
    "additive_DN16": 0.075,
    "quiet_peak_DN16": 0.50,
    "stationary_error_change_DN16": 0.10,
}
BASE = ("baseline", 1)


def collect(source, *, oracle=True):
    parent = read_json(checked(source))
    plan_ref = read_json(checked(parent["inputs"]))["plan"]
    plan = read_json(checked(plan_ref))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    result = []
    start = monotonic()
    for fixture, binding in zip(plan["sources"], parent["records"], strict=True):
        assert fixture["id"] == binding["id"]
        shape = fixture["geometry"] if oracle else None
        views = []
        for settings in binding["streams"]:
            with np.load(checked(settings["data"]), allow_pickle=False) as f:
                data = {k: f[k] for k in f.files}
            output = np.load(checked(settings["outputs"]["local50k"]), allow_pickle=False)

            class Adapter:
                ARMS = KEYS if oracle else model.ARMS

                @staticmethod
                def apply(*args, **kwargs):
                    return model.replay(*args, **kwargs, geometry=shape)

            with patch.object(metric, "model", Adapter):
                score = metric.assess(
                    fixture,
                    plan["noise"],
                    output,
                    data,
                    data["scene_packed"].copy(),
                    cut,
                    local,
                    roi,
                )
            views.append(
                score
                | {
                    "draw": settings["draw"],
                    "input": settings["data"],
                    "outputs": settings["outputs"],
                }
            )
        result.append(
            {
                "fixture": fixture,
                "draws": views,
                "family": fixture["geometry"]["family"],
                "id": fixture["id"],
            }
        )
        if len(result) % 8 == 0:
            print("Replayed", len(result), flush=True)
    return result, plan_ref, monotonic() - start


def subsets(rows):
    return {
        "all": rows,
        "varying": [
            r for r in rows if not r["fixture"]["geometry"].get("stationary_junction", False)
        ],
        "stationary": [
            r for r in rows if r["fixture"]["geometry"].get("stationary_junction", False)
        ],
    }


def within(s, stationary, reference_):
    return (
        s["means"][metric.GAP] <= LIMITS["gap_DN16"]
        and max(s["means"][k] for k in (metric.ADD, metric.CONTINUOUS_ADD))
        <= LIMITS["additive_DN16"]
        and max(s["peak"][k] for k in metric.QUIET) <= LIMITS["quiet_peak_DN16"]
        and (
            stationary["means"][metric.JUNCTION] - reference_
            <= LIMITS["stationary_error_change_DN16"]
        )
    )


def lock(rows):
    split = subsets(rows)
    base = metric.score(split["stationary"], BASE)["means"][metric.JUNCTION]
    arms = {}
    for arm in model.ARMS[1:]:
        choices = []
        for scale in np.linspace(0, 1, 21):
            dose = (arm, float(scale))
            drift, constant, all_ = [
                metric.score(split[k], dose) for k in ("varying", "stationary", "all")
            ]
            choices.append(
                {
                    "choice": dose,
                    "varying": drift,
                    "stationary": constant,
                    "all": all_,
                    "within": within(all_, constant, base),
                }
            )
        chosen = max(
            (v for v in choices if v["within"]),
            key=lambda v: (
                v["varying"]["means"][metric.RESPONSE],
                -v["varying"]["means"][metric.JUNCTION],
            ),
        )
        arms[arm] = {"locked": chosen, "sweep": choices}
    win = max(
        (v["locked"] for k, v in arms.items() if k != "curved-quarter"),
        key=lambda q: (
            q["varying"]["means"][metric.RESPONSE],
            -q["varying"]["means"][metric.JUNCTION],
        ),
    )
    return {"limits": LIMITS, "trials": arms, "primary": win}


def summary(rows, policy, *, oracle=True):
    chosen = {"baseline": BASE, "primary": policy["primary"]["choice"]}
    for arm in KEYS[1:] if oracle else model.ARMS[1:]:
        chosen[arm] = (arm, 1)
    data = {}
    for kind, panel in subsets(rows).items():
        if not panel:
            continue
        scores = {}
        for name, dose in chosen.items():
            scores[name] = metric.score(panel, dose)
            if name != "baseline":
                scores[name]["change"] = metric.paired(panel, dose, BASE)
        admission = {}
        for name in model.ARMS[1:] + (("supplied",) if oracle else ()):
            roles = []
            for i in range(7):
                traces = [
                    d["trace"][i]["arms"].get(name, {}) for row in panel for d in row["draws"]
                ]
                roles.append(
                    {
                        "admitted": sum(r.get("admitted", False) for r in traces),
                        "changed": sum(r.get("change", False) for r in traces),
                    }
                )
            admission[name] = roles
        data[kind] = {"count": len(panel), "scores": scores, "admission": admission}
    return {"choices": chosen, "panels": data}


if __name__ == "__main__":
    group = sys.argv[1]
    archive = OUT if group != "straight" else OUT.with_name("phase-screened-conditioning-v1")
    source = reference(
        archive / ("independent" if group == "straight" else group) / "parent/result.json"
    )
    data, plan, seconds = collect(source, oracle=group != "straight")
    calibration = None if group == "calibration" else reference(OUT / "replay-calibration.json")
    policy = lock(data) if calibration is None else read_json(checked(calibration))["policy"]
    result = summary(data, policy, oracle=group != "straight")
    print("Choice", result["choices"]["primary"], flush=True)
    for k, panel in result["panels"].items():
        for name, x in panel["scores"].items():
            print(
                k,
                name,
                [
                    round(x["means"][metric_], 4)
                    for metric_ in (
                        metric.RESPONSE,
                        metric.JUNCTION,
                        metric.GAP,
                        metric.ADD,
                        metric.CONTINUOUS_ADD,
                    )
                ],
                flush=True,
            )
    write_json(
        OUT / f"replay-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "group": group,
            "source": source,
            "plan": plan,
            "calibration": calibration,
            "policy": policy,
            "summary": result,
            "seconds": seconds,
            "rows": data,
        },
    )
