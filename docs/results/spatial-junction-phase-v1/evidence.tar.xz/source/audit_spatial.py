"""Audit fold isolation and native odd-origin phase sampling."""

from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import junction_phase_field as model

J = model.j
F = np.asarray(((0.1171875, 0.07421875), (0.091796875, -0.095703125)))
PRIOR = {"shot": 0.00128, "read": 6.5536e-6}
ROI = (175, 171, 160, 160)
GEOMETRY = {
    "frequency": F.tolist(),
    "phase": [1.05, -0.7],
    "bend_cycles": [0.11, -0.23],
    "drift_cycles": [[0.04, 0.02], [-0.07, 0.07]],
}


def observation(raw, colors):
    x, y = ROI[:2]
    selected = np.stack([model._sites(raw, x - 48, y - 48, 256, r, c) for r, c in np.ndindex(2, 2)])
    green = [2 * r + c for r, c in np.ndindex(2, 2) if colors[2 * ((y + r) % 2) + (x + c) % 2] == 1]
    return J._Observation.make(selected, green, F, PRIOR["shot"], PRIOR["read"])


def pack(image):
    return np.stack([image[y::2, x::2] for y, x in np.ndindex(2, 2)])


def check_coordinates():
    r = np.random.default_rng(95103)
    case = model.supplied_phase(GEOMETRY)
    cutx, cuty = ROI[0] - 48, ROI[1] - 48
    yy, xx = np.indices((544, 544))
    known = case(xx.ravel() - cutx - J._CENTER, yy.ravel() - cuty - J._CENTER).reshape(544, 544, 2)
    p = known[..., 0] - known[..., 1]
    raw = 0.17 + 0.030 * np.cos(known[..., 0]) + 0.027 * np.cos(known[..., 1]) - 0.01 * np.cos(p)
    output = {}
    for label, colors in PATTERNS.items():
        a = observation(pack(raw), colors)
        assert (
            np.max(
                abs(
                    a.raw
                    - (
                        0.17
                        + 0.030 * np.cos(case(a.x, a.y)[:, 0])
                        + 0.027 * np.cos(case(a.x, a.y)[:, 1])
                        - 0.01 * np.cos(case(a.x, a.y)[:, 0] - case(a.x, a.y)[:, 1])
                    )
                )
            )
            < 3e-15
        )
        changed = raw.copy()
        x0, y0 = np.meshgrid(np.arange(256), np.arange(256), indexing="xy")
        held = np.repeat(np.repeat(J._folds() >= 2, 2, axis=0), 2, axis=1)
        where = (cuty + y0[held], cutx + x0[held])
        changed[where] = r.uniform(0.07, 0.36, size=where[0].shape)
        b = observation(pack(changed), colors)
        np.testing.assert_array_equal(a.variance, b.variance)
        np.testing.assert_array_equal(a.nuisance, b.nuisance)
        k = np.maximum(abs(a.x), abs(a.y)) <= 96
        w = np.exp(-0.5 * (a.x * a.x + a.y * a.y) / 75**2)
        bands = J._distinct_bands(F)
        anchor = model.stationary(a, k, w)
        centers = [model.stationary(o, k, w) for o in (a, b)]
        np.testing.assert_array_equal(centers[0], centers[1])
        for mode in model.ARMS[1:]:
            fn = [model.predict(o, F, bands, mode, k, w, anchor)[0] for o in (a, b)]
            np.testing.assert_array_equal(fn[0](a.x, a.y), fn[1](a.x, a.y))
        phase = model.predict(a, F, bands, "curved-replicated", k, w, anchor)[0]
        truth = case(a.x[k], a.y[k])
        const = a.angles[k] + anchor
        inferred = phase(a.x[k], a.y[k])
        err = [
            np.mean(np.cos(v[:, 0] - v[:, 1] - (truth[:, 0] - truth[:, 1])))
            for v in (const, inferred)
        ]
        assert err[1] > err[0] + 0.03, err
        output[label] = {
            "nominal_closure_cos": float(err[0]),
            "measured_closure_cos": float(err[1]),
        }
    return output


if __name__ == "__main__":
    audit = check_coordinates()
    print(audit, flush=True)
    write_json(
        model.OUT / "audit.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "odd_origin": ROI,
            "layouts": audit,
        },
    )
