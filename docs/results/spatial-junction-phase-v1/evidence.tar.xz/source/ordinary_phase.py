"""Measure the spatial phase change on ordinary photos and incompatible donors."""

from pathlib import Path
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_phase_field as model

OUT = model.OUT
ROI = (176, 176, 160, 160)
FITTED = (48, 48, 160, 160)
RAW_REGION = np.s_[..., 64:192, 64:192]


def main():
    refs = {
        k: reference(OUT.with_name(g) / n)
        for k, g, n in (
            ("photos", "local-weak-contrast-v1", "natural-controls.json"),
            ("donors", "local-near-phase-v1", "contexts-calibration.json"),
        )
    }
    a, b = [read_json(checked(refs[k])) for k in ("photos", "donors")]
    profile = read_json(checked(b["plan"]))["noise"]
    rows = []
    start = monotonic()
    for actual, swap in zip(a["rows"], b["records"], strict=True):
        assert actual["id"] == swap["id"]
        with np.load(checked(actual["input"]), allow_pickle=False) as f:
            d = {k: f[k] for k in f.files}
        alternative = swap["streams"][0]["far_phase"]
        scene = np.load(checked(alternative), allow_pickle=False)
        scene[RAW_REGION] = d["scene_packed"][RAW_REGION]
        np.testing.assert_array_equal(scene[RAW_REGION], d["packed"][0])
        modes = {}
        for name, bayer in (("authentic", d["scene_packed"]), ("mismatch", scene)):
            outputs, trace = model.replay(
                d["parent"], FITTED, bayer, d["colors"], ROI, profile, d["wb"], d["matrix"]
            )
            modes[name] = {
                k: float(np.sqrt(np.mean((v.astype(float) - outputs["baseline"]) ** 2)) * 65535)
                for k, v in outputs.items()
            }
        rows.append(
            {
                "id": actual["id"],
                "input": actual["input"],
                "altered_guide": alternative,
                "modes": modes,
            }
        )
    counts = {
        name: {k: sum(r["modes"][name][k] > 0 for r in rows) for k in model.ARMS[1:]}
        for name in ("authentic", "mismatch")
    }
    print(counts, flush=True)
    write_json(
        OUT / "ordinary.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "sources": refs,
            "changes": counts,
            "rows": rows,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
