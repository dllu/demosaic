"""Compare spatial phase across the separate camera references without using them to restore."""

from pathlib import Path

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
import junction_phase_field as model

J = model.j
FIXED = model.OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"
CONFIGS = {
    "main": Path("configs/gfx-qualitative-20231231.json"),
    "mesh": Path("configs/gfx-green-mesh-20231231.json"),
}


def prepare_reference(raw, colors, xy, frequencies):
    x, y = xy
    x -= 48
    y -= 48
    matrix = raw[y : y + 256, x : x + 256]
    assert matrix.shape == (256, 256)
    packed = np.stack([matrix[a::2, b::2] for a, b in np.ndindex(2, 2)])
    green = [2 * r + c for r, c in np.ndindex(2, 2) if colors[2 * ((y + r) % 2) + (x + c) % 2] == 1]
    return J._Observation.make(packed, green, frequencies, 0, 1)


def center(phase):
    return np.angle(np.mean(np.exp(1j * phase)))


def values(obs, frequencies, bands, mode):
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    taper = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2)
    center_f = model.stationary(obs, inner, taper)
    dynamic = model.predict(obs, frequencies, bands, mode, inner, taper, center_f)[0]
    field = dynamic(obs.x, obs.y)
    base, _ = model.shape_baseline(obs, frequencies, bands, center_f, field)
    scalar = np.cos(field[:, 0] - field[:, 1])
    residuals = []
    sign = None
    for k in (0, 2, 3):
        use = inner & (obs.fold == k)
        w = taper[use] / obs.variance[use]
        design = base[use]
        score = scalar[use] - design @ model.solve(design, w, scalar[use])
        measured = (w * score) @ obs.raw[use] / max(1e-20, w @ score**2)
        design_value = obs.raw[use] - design @ model.solve(design, w, obs.raw[use])
        if k == 0:
            sign = np.sign(measured)
        else:
            correlation = float(
                (w * score) @ design_value / np.sqrt((w @ score**2) * (w @ design_value**2))
            )
            residuals.append(
                {
                    "aligned_correlation": float(sign * correlation),
                    "fitted_amplitude_DN16": float(sign * measured * 65535),
                }
            )
    x, y = J._GRID_X[J._CORE].ravel(), J._GRID_Y[J._CORE].ravel()
    v = dynamic(x, y) - J._wave_angles(x, y, frequencies) - center_f
    spatial_change = v[:, 0] - v[:, 1]
    return residuals, spatial_change


def main():
    src = reference(FIXED)
    f = read_json(checked(src))
    rows = []
    for kind, config in CONFIGS.items():
        doc = read_json(config)
        fp = doc["reference"] if kind == "main" else doc["sources"]["reference"]["path"]
        binding = reference(fp)
        if kind == "mesh":
            assert binding["sha256"] == doc["sources"]["reference"]["sha256"]
        raw, meta = read_raw(str(checked(binding)))
        assert meta.iso == 100
        cfa = PATTERNS[meta.pattern]
        for v in f["standing"]:
            if not v["id"].startswith(kind):
                continue
            with np.load(checked(v["input"]), allow_pickle=False) as input_:
                high, colors = [input_[k][0] for k in ("packed", "colors")]
            high = model.prepare(high, colors, v["local_ROI"], v["noise"], 16)
            if high is None:
                continue
            high, freq, bands = high
            cfg = next(r for r in doc["regions"] if v["id"].endswith(r["name"]))
            xy = cfg["reference_xy"] if kind == "main" else cfg["reference_raw_xywh"][:2]
            low = prepare_reference(raw, cfa, xy, freq)
            modes = {}
            for variant in ("affine", "curved", "curved-replicated"):
                plan, a = values(high, freq, bands, variant)
                witness, b = values(low, freq, bands, variant)
                difference = a - b
                modes[variant] = {
                    "relative_field_agreement": float(
                        np.mean(np.cos(difference - center(difference)))
                    ),
                    "rms_disagreement_cycles": float(
                        np.sqrt(
                            np.mean(np.angle(np.exp(1j * (difference - center(difference)))) ** 2)
                        )
                        / (2 * np.pi)
                    ),
                    "high": plan,
                    "low": witness,
                }
            rows.append(
                {
                    "id": v["id"],
                    "input": v["input"],
                    "reference": binding,
                    "reference_ROI": [*xy, 160, 160],
                    "last_profile": v["noise"],
                    "modes": modes,
                }
            )
            print(
                v["id"],
                {
                    k: (
                        [round(p["aligned_correlation"], 4) for p in q["high"]],
                        [round(p["aligned_correlation"], 4) for p in q["low"]],
                        round(q["rms_disagreement_cycles"], 3),
                    )
                    for k, q in modes.items()
                },
                flush=True,
            )
    write_json(
        model.OUT / "reference-phase.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "source": src,
            "configurations": {k: reference(v) for k, v in CONFIGS.items()},
            "scope": "Independent, approximately registered camera exposures. Same guide frequencies and separately estimated phases and station amplitudes.",
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
