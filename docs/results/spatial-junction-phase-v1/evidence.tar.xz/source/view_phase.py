"""Render exact native triplets and both standing GFX families."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_phase_field as model
from replay import metric
from pool_probe import pooled

sys.path.append(str(model.HERE.parent / "local-junction-support-v1"))
from review_junction import image, board

OUT = model.OUT
LABELS = (
    "Regional RAW refit",
    "Affine phase",
    "Curved phase",
    "Replicated phase",
    "Pooled affine",
    "Pooled curved",
)


def fields(parent, local, scene, colors, roi, noise, wb, matrix, clearance):
    args = (parent, local, scene, colors, roi, noise, wb, matrix)
    images, trace = model.replay(*args, clearance=clearance)
    original = model.deliver

    def replay_pool(*a, **k):
        with patch.object(model.j, "_amplitudes", pooled):
            return original(*a, **k)

    with patch.object(model, "deliver", replay_pool):
        further, _ = model.replay(*args, clearance=clearance)
    values = tuple(images[k] for k in ("baseline", "affine", "curved", "curved-replicated")) + (
        further["affine"],
        further["curved"],
    )
    return list(zip(LABELS, values, strict=True)), trace


def exact(src, room):
    data = read_json(checked(src))
    plan = read_json(checked(data["plan"]))
    assert data["summary"]["choices"]["primary"] == ["curved", 1.0]
    x, y, w, h = plan["query"]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    selected = {}
    for q in data["rows"]:
        if q["fixture"]["geometry"]["stationary_junction"]:
            continue
        for r in q["draws"]:
            b = metric.values(r, ("baseline", 1))
            m = metric.values(r, ("curved", 1))
            key = "exact gap" if metric.GAP in m else "continuous"
            change = b[metric.JUNCTION] - m[metric.JUNCTION]
            if key not in selected or change > selected[key][0]:
                selected[key] = change, q, r
    views = []
    for reason, (gain, q, r) in selected.items():
        parent = np.load(checked(r["outputs"]["local50k"]), allow_pickle=False)[0]
        with np.load(checked(r["input"]), allow_pickle=False) as f:
            inputs = {k: f[k] for k in f.files}
        scene = inputs["scene_packed"].copy()
        scene[cut] = inputs["packed"][0]
        wb, matrix, colors = [inputs[k] for k in ("wb", "matrix", "colors")]
        test, trace = fields(parent, local, scene, colors, roi, plan["noise"], wb, matrix, 48)
        noisy = noisy_malvar(
            {
                "packed": inputs["packed"][:1],
                **{k: inputs[k][None] for k in ("colors", "wb", "matrix")},
            }
        )[0]
        truth = model.crop(inputs["target"][0], local)
        tiles = [
            ("Noisy Malvar", model.crop(noisy, local)),
            ("Local 50k", model.crop(parent, local)),
            *test,
            ("Exact GT", truth),
        ]
        views_native = [(label, image(img, wb, matrix, 2.0)) for label, img in tiles]
        out = board(views_native, room / f"{q['id']}-comparison.png")
        triplet = board(
            [views_native[k] for k in (0, 4, len(views_native) - 1)],
            room / f"{q['id']}-triplet.png",
        )
        views.append(
            {
                "id": q["id"],
                "fixture": q["fixture"],
                "input": r["input"],
                "outputs": r["outputs"],
                "draw": r["draw"],
                "selection": reason,
                "junction_decrease_DN16": gain,
                "noise": plan["noise"],
                "exposure": 2.0,
                "ROI": local,
                "query": plan["query"],
                "trace": trace,
                "all": out,
                "triplet": triplet,
            }
        )
        print(q["id"], reason, gain, flush=True)
    return {"source": src, "rows": views}


def camera(room):
    phase_receipt = reference(OUT / "camera-phase.json")
    previous = read_json(checked(read_json(checked(phase_receipt))["source"]))
    rows = []
    for item in previous["standing"]:
        roi = item["local_ROI"]
        with np.load(checked(item["input"]), allow_pickle=False) as f:
            scene, colors, wb, matrix = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        parent = np.load(checked(item["predictions"]["local50k"]), allow_pickle=False)[0]
        test, trace = fields(parent, roi, scene, colors, roi, item["noise"], wb, matrix, 16)
        res = []
        for native in item["displays"]:
            with Image.open(checked(native["board"]["image"])) as raster:
                src = np.asarray(raster)
            previous_tiles = {}
            for t in native["board"]["panels"]:
                x, y, w, h = t["png_xywh"]
                previous_tiles[t["name"]] = src[y : y + h, x : x + w]
            ex = native["exposure"]
            np.testing.assert_array_equal(
                image(model.crop(parent, roi), wb, matrix, ex), previous_tiles["Local 50k"]
            )
            tiles = [(k, previous_tiles[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            tiles.extend((k, image(v, wb, matrix, ex)) for k, v in test)
            tiles.extend(
                (k, previous_tiles[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in previous_tiles
            )
            res.append(
                board(tiles, room / f"{item['id']}-x{ex:g}.png")
                | {"exposure": ex, "source": native["board"]}
            )
        delta = {
            k: float(np.sqrt(np.mean((v.astype(float) - test[0][1]) ** 2)) * 65535) for k, v in test
        }
        rows.append(
            {
                "id": item["id"],
                "input": item["input"],
                "RAW": item["raw"],
                "noise": item["noise"],
                "ROI": item["global_ROI"],
                "local_ROI": roi,
                "trace": trace,
                "difference_DN16": delta,
                "compared": item["predictions"]["local50k"],
                "native": res,
            }
        )
        print(item["id"], {k: round(v, 4) for k, v in delta.items()}, flush=True)
    return {"source": phase_receipt, "rows": rows, "checkpoints": previous["checkpoints"]}


if __name__ == "__main__":
    torch.set_num_threads(2)
    kind = sys.argv[1]
    folder = OUT / "native" / kind
    folder.mkdir(exist_ok=True, parents=True)
    exact_src = reference(OUT / "replay-independent.json")
    data = exact(exact_src, folder) if kind == "exact" else camera(folder)
    write_json(
        OUT / f"views-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "locked_recipe": reference(OUT / "replay-calibration.json"),
            "report": data,
            "evaluation": exact_src,
        },
    )
