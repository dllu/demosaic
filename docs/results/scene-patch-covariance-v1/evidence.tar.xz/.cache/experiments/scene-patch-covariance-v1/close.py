"""Recheck controller strength and make a paired transfer curve."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replay

ROOT = Path(__file__).resolve().parent
MODES = {
    "matched": ("Full covariance", "#176f71", "o"),
    "diagonal": ("Diagonal", "#cc6b20", "^"),
    "transposed": ("Transposed", "#8b63a9", "s"),
    "confirmed": ("Confirmed covariance", "#315bc8", "D"),
    "confirmed_diagonal": ("Confirmed diagonal", "#bb4267", "v"),
}


def reconcile(first, extended):
    base = {r["case"]["id"]: r for r in first["cases"]}
    largest = 0.0
    for row in extended["cases"]:
        old = base.pop(row["case"]["id"])
        assert old["case"] == row["case"] and old["atlas_windows"] == row["atlas_windows"]
        for mode in old["terms"]:
            for band in old["terms"][mode]:
                for metric in old["terms"][mode][band]:
                    left = old["terms"][mode][band][metric]
                    right = row["terms"][mode][band][metric]
                    exact = np.max(np.abs(np.asarray(left) - right))
                    largest = max(largest, exact)
                    np.testing.assert_allclose(left, right, atol=1e-8, rtol=0)
    assert not base
    return largest


def curve(rows, settings):
    d = np.arange(0, 2.51, 0.5)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.4), layout="constrained")
    controls = {
        metric: replay.estimate(replay.arrays(rows, "parent", "fine", metric), metric, 0)
        for metric in ("response", "flat", "increment")
    }
    for mode, (label, color, marker) in MODES.items():
        gain = d[:, None] * settings[mode]["dose_for_1_DN16_added_flat"]
        detail = {
            m: replay.estimate(replay.arrays(rows, mode, "fine", m), m, gain) - controls[m]
            for m in controls
        }
        for ax, metric in zip(axes, ("flat", "increment"), strict=True):
            ax.plot(detail[metric], detail["response"], color=color, marker=marker, label=label)
    titles = ("Change in flat error (DN16)", "Change in paired increment error (DN16)")
    for ax, xlabel in zip(axes, titles, strict=True):
        ax.set_xlabel(xlabel)
        ax.grid(alpha=0.18)
        ax.axvline(0, color="#444444", linewidth=0.8)
    axes[0].set_ylabel("Change in signed fine response (percentage points)")
    axes[0].legend(loc="upper left", frameon=False, fontsize=8)
    fig.suptitle("ISO6400 transfer to 24 photos with independent noise")
    path = ROOT / "response-error.png"
    fig.savefig(path, dpi=150, facecolor="white")
    plt.close(fig)
    return reference(path)


def main():
    files = ("replay.json", "confirmed-replay.json", "independent-fit.json")
    bindings = {name: reference(ROOT / name) for name in files}
    first, extended, independent = [read_json(checked(bindings[k])) for k in files]
    legacy = reconcile(first, extended)
    replay.DOSES = np.unique(
        np.concatenate((np.arange(101) / 10000, np.arange(11, 101) / 1000, np.arange(11, 81) / 100))
    )
    carried = [r for r in extended["cases"] if r["case"]["partition"] != "calibration"]
    calibration = [
        r
        for r in extended["cases"]
        if r["case"]["partition"] == "calibration" and r["case"]["profile"]["name"] == "iso6400"
    ]
    graph = curve(
        [r for r in extended["cases"] if r["case"]["partition"] == "transfer"],
        replay.fit(calibration),
    )
    write_json(
        ROOT / "closure.json",
        {
            "driver": reference(__file__),
            "receipts": bindings,
            "first_stage_max_difference": legacy,
            "dose_grid": replay.DOSES.tolist(),
            "same_views_curve": graph,
            "coupled": replay.summary(extended["cases"]),
            "independent": replay.summary(independent["cases"] + carried),
        },
    )


if __name__ == "__main__":
    main()
