"""Test the same calibration sources with independently corrupted role pairs."""

import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay import ROOT, evaluate, summary


def main():
    receipt = reference(ROOT / "confirmed-replay.json")
    other = read_json(checked(receipt))
    old_parents = read_json(checked(other["inputs"]["old_parents"]))
    cases = {}
    for row in old_parents["records"]:
        arc = read_json(checked(row["source"]))
        if arc["case"] < 32 and arc["draw"] == "independent":
            cases[arc["id"]] = arc | {"rgb": row["rgb"], "rgb_key": row["npz_field"]}
    rows = []
    start = time.monotonic()
    with ThreadPoolExecutor(4) as pool:
        jobs = []
        for row in other["cases"]:
            record = row["case"]
            if record["partition"] != "calibration":
                continue
            alternative = cases[record["id"].replace("-coupled", "-independent")]
            assert alternative["source"] == record["source"]["id"]
            assert (
                alternative["box"] == record["box"] and alternative["profile"] == record["profile"]
            )
            with (
                np.load(checked(record["input"]), allow_pickle=False) as first,
                np.load(checked(alternative["input"]), allow_pickle=False) as second,
            ):
                np.testing.assert_array_equal(first["target"], second["target"])
            jobs.append(
                record | {k: alternative[k] for k in ("id", "draw", "input", "rgb", "rgb_key")}
            )
        assert len(jobs) == 64
        for value in pool.map(evaluate, jobs):
            rows.append(value)
            if len(rows) % 16 == 0:
                print(len(rows), time.monotonic() - start, flush=True)
    wider = rows + [r for r in other["cases"] if r["case"]["partition"] != "calibration"]
    write_json(
        ROOT / "independent-fit.json",
        {
            "driver": reference(__file__),
            "original": receipt,
            "same_clean_targets": True,
            "cases": rows,
            "seconds": time.monotonic() - start,
            "summary": summary(wider),
        },
    )


if __name__ == "__main__":
    main()
