"""Check the achievable tradeoff when the exterior repeats the right structure."""

from pathlib import Path

import numpy as np

from demosaic import scene_patch_covariance as patch
from demosaic.experiments.artifacts import reference, write_json

ROOT = Path(__file__).resolve().parent
SEED = 202611191755
N = 512
DONORS = 32
SIGMA = 0.014


def trial(colors, rng):
    basis = patch.patch_basis(colors)
    k = len(basis.image)
    # Choose two horizontal DCT modes with distinct scales. The transpose
    # has no overlapping basis vectors with the actual signal.
    pure = np.flatnonzero(np.max(np.ptp(basis.image, axis=1), axis=1) < 1e-14)
    assert len(pure) >= 3
    active = pure[[0, 2]]
    shape = np.zeros(k)
    shape[active] = [0.8, 0.6]
    assert np.dot(shape, shape[basis.transpose]) == 0
    donor_amplitude = rng.choice([-1, 1], size=(N, DONORS)) * rng.uniform(
        0.07, 0.13, size=(N, DONORS)
    )
    donor = donor_amplitude[..., None, None] * shape
    g = basis.projection.shape[-1]
    noise = rng.normal(0, SIGMA, size=(N, DONORS, 2, g))
    observed_donor = donor + np.einsum("gkp,ndgp->ndgk", basis.projection, noise)
    weights = np.full((N, DONORS), 1 / DONORS)
    matched = patch.covariance(observed_donor / (np.sqrt(2) * SIGMA), weights)
    floor = np.sqrt(k * np.sum(weights**2, axis=1))
    wrong = matched[:, basis.transpose][:, :, basis.transpose]
    diagonal = matched * np.eye(k)
    exact = 0.023 * rng.choice([-1, 1], size=(N, 1)) * shape
    parent = 0.4 * exact
    result = {}
    for name, target, base in (
        ("present", exact, parent),
        ("flat", np.zeros_like(exact), np.zeros_like(parent)),
    ):
        noise = rng.normal(0, SIGMA, size=(N, 2, g))
        raw = target[:, None, :] + np.einsum("gkp,ngp->ngk", basis.projection, noise)
        difference = raw.mean(axis=1) - base
        scores = {}
        for mode, moment in (("matched", matched), ("diagonal", diagonal), ("transposed", wrong)):
            value = patch.filter_innovation(moment, difference, floor)
            scores[mode] = value
        result[name] = scores
    return exact, parent, result


def main():
    rng = np.random.default_rng(SEED)
    layouts = [(0, 1, 1, 2), (1, 0, 2, 1), (1, 2, 0, 1), (2, 1, 1, 0)]
    result = [trial(colors, rng) for colors in layouts]
    exact = np.concatenate([a for a, _, _ in result])
    parent = np.concatenate([a for _, a, _ in result])
    rows = {}
    for mode in ("matched", "diagonal", "transposed"):
        fields = {
            k: np.concatenate([v[k][mode] for _, _, v in result]) for k in ("present", "flat")
        }
        relative = np.sum(fields["present"] * exact) / np.sum(exact**2)
        gain = max(0, min(1.0, 0.10 / max(relative, 1e-8)))
        report = {"raw_signed_response": float(relative), "gain": float(gain)}
        for k in ("present", "flat"):
            base = parent - exact if k == "present" else np.zeros_like(parent)
            error = base + gain * fields[k]
            report[k + "_rms_DN16"] = float(
                np.sqrt(np.sum(error**2, axis=-1).mean()) * 65535 / patch.SIZE
            )
        rows[mode] = report | {"response": float(40 + 100 * gain * relative)}
    write_json(
        ROOT / "repeated-basis.json",
        {
            "seed": SEED,
            "noise_sigma": SIGMA,
            "rows_per_layout": N,
            "donors_per_row": DONORS,
            "driver": reference(__file__),
            "module": reference(patch.__file__),
            "fixed_40_percent_parent": float(
                np.sqrt(np.sum((parent - exact) ** 2, axis=-1).mean()) * 65535 / patch.SIZE
            ),
            "scores": rows,
        },
    )


if __name__ == "__main__":
    main()
