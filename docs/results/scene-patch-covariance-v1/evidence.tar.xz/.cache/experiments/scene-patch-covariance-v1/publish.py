"""Bind reviewed native PNGs to their source, algorithm, and unchanged receipts."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import os
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay import ROOT

REPO = ROOT.parents[2]
OUT = REPO / "docs/results" / ROOT.name
IMAGES = REPO / "docs/images" / ROOT.name
EXTERNAL = Path("/mnt/external/demosaic") / ROOT.name


def cells(b):
    out = {}
    with Image.open(checked(b["image"])) as source:
        image = np.asarray(source.convert("RGB"))
    for p in b["panels"]:
        x, y, w, h = p["png_xywh"]
        assert (w, h) == (160, 160) and x + w <= image.shape[1] and y + h <= image.shape[0]
        out[p.get("name", p.get("label"))] = image[y:y+h, x:x+w]
    return out


def keep(binding, folder):
    p = checked(binding)
    n = IMAGES / folder / p.name
    shutil.copyfile(p, n)
    assert reference(n)["sha256"] == binding["sha256"]
    return binding | {"path": str(n.relative_to(IMAGES))}


def board(b, folder):
    return b | {"image": keep(b["image"], folder)}


def main():
    refs = {k: reference(ROOT / k) for k in (
        "closure.json", "replay.json", "confirmed-replay.json", "independent-fit.json",
        "repeated-basis.json", "native/result.json")}
    close, first, confirmed, independent, repeated, native = [read_json(checked(r)) for r in refs.values()]
    assert native["measurement"] == refs["confirmed-replay.json"]
    assert close["first_stage_max_difference"] == 0.0 and independent["same_clean_targets"]
    assert len(confirmed["cases"]) == len(first["cases"]) == 152 and len(independent["cases"]) == 64
    assert all(v["optimized"] == 0 for c in close["independent"].values() for v in c["settings"].values())
    assert reference(ROOT / "first/scene_patch_covariance.py")["sha256"] == first["core"]["sha256"]
    assert reference(ROOT / "first/replay.py")["sha256"] == first["driver"]["sha256"]
    assert confirmed["core"] == repeated["module"]
    for record, key in ((confirmed, "core"), (confirmed, "driver"), (close, "driver"),
                        (independent, "driver"), (repeated, "driver"), (native, "driver")):
        checked(record[key])
    (IMAGES / "exact").mkdir(parents=True)
    (IMAGES / "standing").mkdir()
    assert len(native["exact"]) == 4 and len(native["standing"]) == 8
    assert sum(len(r["displays"]) for r in native["standing"]) == 12
    notes = {
        "exact": {
            "transfer-35": "The denoised tower accents remain soft. Both local flat controls are visually similar and preserve the smooth core.",
            "transfer-37": "The bright diagonal edge survives. Fine wing markings stay soft. The two-green output is visually close to the parent on both roles.",
        },
        "main": "The sky stays smooth and the coarse crossing pattern is coherent. Fine bracing and leaf subdivisions stay soft.",
        "mesh": "At both displays and both conditioning profiles, the left crossings remain mostly unresolved. The transferred right retains the clearest diagonals. The visible crossing gaps and color stay close to the parent.",
    }
    sheets = [reference(ROOT / (s + ".png")) for s in (
        "inspect-exact", "inspect-main-x4", "inspect-mesh-x4", "inspect-mesh-x16",
        "inspect-mesh-jpeg-x4", "inspect-mesh-jpeg-x16")]
    exact = []
    for r in native["exact"]:
        full, small = (cells(r[t]) for t in ("board", "triplet"))
        assert list(small) == ["Noisy Malvar", "Two-green confirmation", "Exact GT"]
        assert all(np.array_equal(roi, full[name]) for name, roi in small.items())
        exact.append(r | {t: board(r[t], "exact") for t in ("board", "triplet")})
    standing = []
    for r in native["standing"]:
        displays = []
        for v in r["displays"]:
            panels = cells(v["board"])
            assert {"Noisy (Malvar)", "V120 EMA", "Corpus 100k", "ISO100 AHD reference",
                    "Two-green confirmation"} <= panels.keys()
            if r["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= panels.keys()
            displays.append(v | {"board": board(v["board"], "standing")})
        standing.append(r | {"displays": displays})
    graph = keep(close["same_views_curve"], "")
    m = IMAGES / "manifest.json"
    write_json(m, {k: native[k] for k in ("measurement", "weights", "links", "strengths")} | {
        "exact": exact, "standing": standing, "curve": graph, "viewing": {
            "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "notes": notes, "inspected_sheets": sheets,
        }})
    OUT.mkdir()
    evidence = OUT / "evidence.tar.xz"
    files = [*refs.values(), *confirmed["inputs"].values(), *native["links"].values(),
             native["driver"], close["driver"], independent["driver"],
             confirmed["driver"], confirmed["core"], repeated["driver"],
             *[reference(ROOT / p) for p in ("first/replay.py", "first/scene_patch_covariance.py", "publish.py")],
             reference(REPO / "tests/test_scene_patch_covariance.py"), reference(m)]
    staged = EXTERNAL / "evidence.tar.xz"
    members = {}
    with tarfile.open(staged, "x:xz", preset=4) as stream:
        for binding in {r["path"]: r for r in files}.values():
            p = checked(binding)
            key = p.relative_to(REPO).as_posix()
            stream.add(p, arcname=key)
            members[key] = binding["sha256"]
    with tarfile.open(staged, "r:xz") as stream:
        for p, digest in members.items():
            assert sha256(stream.extractfile(p).read()).hexdigest() == digest
    temporary = OUT / ".evidence.tar.xz"
    try:
        with staged.open("rb") as src, temporary.open("xb") as dst:
            shutil.copyfileobj(src, dst)
            dst.flush()
            os.fsync(dst.fileno())
        assert reference(temporary)["sha256"] == reference(staged)["sha256"]
        os.link(temporary, evidence)
    finally:
        temporary.unlink(missing_ok=True)
    write_json(OUT / "publication.json", {
        "scope": "Frozen-weight component inference. Exact natural detail and flat controls, ideal repeated modes, and native standing GFX reviews. No training and no full427 or known/unseen camera-panel scores.",
        "weights": native["weights"], "calibration": 32, "held_out": 32, "transfer": 24,
        "seconds": {"with_confirmation": confirmed["seconds"], "independent_calibration": independent["seconds"]},
        "native_manifest": reference(m), "evidence": reference(evidence), "archive_members": members,
        "receipts": refs, "curves_and_scores": close["coupled"],
        "independent_strengths": {iso: {k: row["optimized"] for k, row in g["settings"].items()}
                                  for iso, g in close["independent"].items()},
        "ideal_repeated_modes": repeated["scores"],
    })


if __name__ == "__main__":
    main()
