"""Score source-disjoint context operators on unchanged noisy observations."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import dctn

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic import scene_patch_covariance as patch

ROOT = Path(__file__).resolve().parent
OLD = ROOT.with_name("natural-raw-donor-evidence-v1") / "full-parent.json"
PANEL = ROOT.with_name("scene-local-contrast-2400-v1") / "evaluation-plan.json"
TRANSFER = ROOT.with_name("green-covariance-refit-v1") / "fresh.json"
BASE_SHA = "87b96f3c487b9edaf1c477742b6c38f2a82cc6b20a94716d51cc8cf46a17a760"
LUMA = np.array([0.2126, 0.7152, 0.0722])
FREQ = np.hypot.outer(np.arange(16) / 32, np.arange(16) / 32)
BANDS = {"lower": (FREQ >= 1 / 32) & (FREQ < 1 / 8), "fine": (FREQ >= 1 / 8) & (FREQ < 1 / 3)}
X0 = 80
NC = 96
DOSES = np.arange(81) / 100


def read_inputs(row):
    with np.load(checked(row["input"]), allow_pickle=False) as f:
        fields = {k: f[k] for k in ("packed", "scene_packed", "colors", "wb", "matrix")}
    rgb = row["rgb"]
    if row["rgb_key"] is None:
        parent = np.load(checked(rgb), allow_pickle=False)
        v120 = None
    else:
        with np.load(checked(rgb), allow_pickle=False) as f:
            parent = f[row["rgb_key"]]
            v120 = f["v120"] if "v120" in f else None
    return fields, parent, v120


def apply_delta(rgb, delta, wb, matrix, gain):
    unit = np.linalg.solve(matrix, np.ones(3)) / wb
    if unit[1] <= 0 or np.any(unit < 0):
        raise ValueError("Expected a positive camera-neutral direction")
    return rgb + (gain * (unit / unit[1])[..., None, None] * delta).astype(rgb.dtype)


def fields_for_record(row, fields, parent):
    cfa, wb, matrix = (fields[k] for k in ("colors", "wb", "matrix"))
    box = row["box"]
    profile = row["profile"]
    noise = profile["shot"], profile["read"]
    exterior = patch.build_exterior(fields["scene_packed"], cfa, box, *noise)
    fields_by_mode = {k: [] for k in patch.MODES}
    for raw, base in zip(fields["packed"], parent, strict=True):
        selected = patch.corrections(raw, base[1], cfa, *noise, box, exterior)
        # Convert from green-channel amplitude to the exact color-space scale used below.
        for name, value in selected.items():
            fields_by_mode[name].append(apply_delta(np.zeros_like(base), value, wb, matrix, 1.0))
    return {k: np.stack(v) for k, v in fields_by_mode.items()}, (
        len(exterior.coords) if exterior is not None else 0
    )


def transform(rgb, fields):
    cal = {
        k: np.broadcast_to(fields[k][None], (len(rgb), *fields[k].shape)) for k in ("wb", "matrix")
    }
    # Keep signed RGB differences linear, including negative corrections.
    linear = np.einsum("bij,bjhw->bihw", cal["matrix"], rgb * cal["wb"][..., None, None])
    luma = np.einsum("i,bihw->bhw", LUMA, linear[..., X0 : X0 + NC, X0 : X0 + NC])
    blocks = luma.reshape(len(luma), 6, 16, 6, 16).swapaxes(-2, -3).reshape(len(luma), 36, 16, 16)
    coeff = dctn(blocks, axes=(-1, -2), norm="ortho") * (65535 / NC)
    return {k: coeff[..., band] for k, band in BANDS.items()}


def quadratic(error, correction):
    return [
        float(v) for v in [np.sum(error**2), 2 * np.sum(error * correction), np.sum(correction**2)]
    ]


def terms(base, adjustment, target):
    absolute = base - target
    increment = target[0] - target[1]
    former = base[0] - base[1]
    delta = adjustment[0] - adjustment[1]
    return {
        "present": quadratic(absolute[0], adjustment[0]),
        "absent": quadratic(absolute[1], adjustment[1]),
        "flat": quadratic(absolute[2], adjustment[2]),
        "increment": quadratic(former - increment, delta),
        "response": [
            float(np.sum(former * increment)),
            float(np.sum(delta * increment)),
            float(np.sum(increment**2)),
        ],
    }


def evaluate(row):
    input_, base, v120 = read_inputs(row)
    # Finish the operational path before opening exact synthetic references.
    corrections, donors = fields_for_record(row, input_, base)
    with np.load(checked(row["input"]), allow_pickle=False) as f:
        exact = transform(f["target"], input_)
    parent = transform(base, input_)
    output = {"parent": parent, **{k: transform(v, input_) for k, v in corrections.items()}}
    if v120 is not None:
        output["v120"] = transform(v120, input_)
    coeff = {}
    for name, option in output.items():
        basis = option if name in ("parent", "v120") else parent
        coeff[name] = {
            band: terms(
                basis[band], np.zeros_like(v) if name in ("parent", "v120") else v, exact[band]
            )
            for band, v in option.items()
        }
    return {"case": row, "atlas_windows": donors, "terms": coeff}


def schedules():
    refs = {
        k: reference(p)
        for k, p in (("old_parents", OLD), ("old_protocol", PANEL), ("transfer", TRANSFER))
    }
    old = read_json(checked(refs["old_parents"]))
    assert read_json(checked(old["plan"]))["model"]["sha256"] == BASE_SHA
    protocol = read_json(checked(refs["old_protocol"]))
    assert protocol["score_ROI_xywh"] == [X0, X0, NC, NC]
    earlier = []
    for record in old["records"]:
        case = read_json(checked(record["source"]))
        i = case["case"]
        if case["draw"] != ("coupled" if i < 32 else "independent"):
            continue
        source = protocol["rows"][i]["source"]
        assert source["id"] == case["source"]
        earlier.append(
            {k: case[k] for k in ("id", "profile", "box", "input", "draw")}
            | {
                "source": source,
                "partition": "calibration" if i < 32 else "held_out",
                "rgb": record["rgb"],
                "rgb_key": record["npz_field"],
            }
        )
    transfer = read_json(checked(refs["transfer"]))
    plan = read_json(checked(transfer["plan"]))
    assert plan["checkpoints"]["100k"]["sha256"] == BASE_SHA
    newer = [
        {
            "id": f"transfer-{r['source']['index']:02}",
            "source": r["source"]["source"],
            "profile": plan["profile"],
            "box": r["box"],
            "input": r["input"],
            "rgb": r["predictions"],
            "rgb_key": "parent",
            "draw": "independent",
            "partition": "transfer",
        }
        for r in transfer["rows"]
        if r["source"]["kind"] == "natural"
    ]
    for key in ("id", "cache_sha256"):
        assert not {r["source"][key] for r in newer}.intersection(r["source"][key] for r in earlier)
    assert len(earlier) == 128 and len(newer) == 24
    return refs, earlier + newer


def arrays(rows, key, band, metric):
    return np.array([r["terms"][key][band][metric] for r in rows])


def estimate(terms, metric, gain, sample=None):
    base, change, third = np.moveaxis(terms, -1, 0)
    if metric == "response":
        response = base + change * gain
        if sample is not None:
            response, third = response[sample], third[sample]
        return 100 * response.sum(-1) / third.sum(-1)
    score = np.sqrt(np.maximum(base + gain * change + gain**2 * third, 0))
    return score.mean(-1) if sample is None else score[sample].mean(-1)


def fit(rows):
    settings = {}
    for mode in patch.MODES:
        curves = {}
        for band in BANDS:
            curves[band] = {
                key: estimate(arrays(rows, mode, band, key), key, DOSES[:, None])
                for key in ("flat", "present", "increment", "response")
            }
        selected = np.ones(len(DOSES), dtype=bool)
        for band, values in curves.items():
            selected &= values["flat"] <= values["flat"][0] + 0.05
            selected &= values["present"] <= values["present"][0] + 0.02
        selected &= curves["fine"]["response"] >= curves["fine"]["response"][0]
        i = np.argmin(np.where(selected, curves["fine"]["increment"], np.inf))
        settings[mode] = {
            "optimized": float(DOSES[i]),
            "dose_for_1_DN16_added_flat": float(
                min(0.8, 1 / np.sqrt(max(1e-12, arrays(rows, mode, "fine", "flat")[:, 2].mean())))
            ),
            "curves": {
                band: {k: v.tolist() for k, v in curve.items()} for band, curve in curves.items()
            },
        }
    return settings


def summary(results):
    result = {}
    rng = np.random.default_rng(202611191752)
    for iso in ("iso400", "iso6400"):
        all_iso = [r for r in results if r["case"]["profile"]["name"] == iso]
        fit_rows = [r for r in all_iso if r["case"]["partition"] == "calibration"]
        settings = fit(fit_rows)
        result[iso] = {"settings": settings, "partitions": {}}
        for group in ("calibration", "held_out", "transfer"):
            rows = [r for r in all_iso if r["case"]["partition"] == group]
            if not rows:
                continue
            n = len(rows)
            sample = np.vstack((np.arange(n), rng.integers(n, size=(5000, n))))
            out = {}
            for level in ("optimized", "dose_for_1_DN16_added_flat"):
                variants = {"parent": 0, **{k: v[level] for k, v in settings.items()}}
                if group == "transfer":
                    variants["v120"] = 0
                out[level] = {}
                for band in BANDS:
                    values = {
                        mode: {
                            metric: estimate(arrays(rows, mode, band, metric), metric, g, sample)
                            for metric in ("present", "absent", "flat", "increment", "response")
                        }
                        for mode, g in variants.items()
                    }
                    out[level][band] = {
                        mode: {
                            k: {
                                "value": float(series[0]),
                                **{
                                    compare: [
                                        float(d[0]),
                                        *np.quantile(d[1:], [0.025, 0.975]).tolist(),
                                    ]
                                    for compare in ("parent", "diagonal")
                                    for d in [series - values[compare][k]]
                                },
                            }
                            for k, series in value.items()
                        }
                        for mode, value in values.items()
                    }
            result[iso]["partitions"][group] = out
    return result


def main():
    refs, rows = schedules()
    result = []
    now = time.monotonic()
    with ThreadPoolExecutor(4) as pool:
        for r in pool.map(evaluate, rows):
            result.append(r)
            if len(result) % 16 == 0:
                print(len(result), round(time.monotonic() - now, 2), flush=True)
    digest = reference(patch.__file__)
    record = {
        "inputs": refs,
        "core": digest,
        "driver": reference(__file__),
        "weights": BASE_SHA,
        "cases": result,
        "seconds": time.monotonic() - now,
    }
    write_json(ROOT / "replay.json", record | {"summary": summary(result)})


if __name__ == "__main__":
    main()
