"""Render fixed exposure native crops for the green innovation replay."""

from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop

from replay import ROOT, apply_delta, fields_for_record, read_inputs
from demosaic import scene_patch_covariance as patch

sys.path[:0] = ["scripts", str(ROOT.with_name("paired-luminance-detail-v1"))]
from report_scene_wave_guides import native_board
from render import native_png

LABEL = "Matched patch covariance"
CONFIRMED = "Two-green confirmation"
BASE = Path("docs/images/green-covariance-refit-v1/manifest.json")
GEOMETRY = ROOT.with_name("scene-spectrum-detail-v1") / "standing-parent-phase/manifest.json"
REFERENCES = ROOT.with_name("wire-regional-amplitude-v1") / "standing/result.json"
V120_CONFIG = Path("configs/current-model.json")
DOSE = "dose_for_1_DN16_added_flat"


def choose(rows, scales):
    def delta(row):
        change = []
        for k in ("confirmed", "confirmed_diagonal"):
            coefficients = row["terms"][k]["fine"]["increment"]
            amount = scales[k][DOSE]
            change.append(float(np.sqrt(np.dot(coefficients, [1, amount, amount**2]))))
        return change[0] - change[1]

    return sorted(rows, key=delta)[:: len(rows) - 1]


def exact_boards(receipt, scales, folder):
    candidates = [r for r in receipt["cases"] if r["case"]["partition"] == "transfer"]
    output = []
    for case in choose(candidates, scales):
        row = case["case"]
        fields, base, v120 = read_inputs(row)
        corrections, _ = fields_for_record(row, fields, base)
        calibration = {k: fields[k][None] for k in ("colors", "wb", "matrix")}
        matched = base + scales["matched"][DOSE] * corrections["matched"]
        diagonal = base + scales["diagonal"][DOSE] * corrections["diagonal"]
        confirmed = base + scales["confirmed"][DOSE] * corrections["confirmed"]
        with np.load(checked(row["input"]), allow_pickle=False) as f:
            target = f["target"]
        for role, name in ((0, "present"), (2, "flat")):
            noisy = noisy_malvar(calibration | {"packed": fields["packed"][role : role + 1]})[0]
            board = native_board(
                folder,
                f"{row['id']}-{name}",
                [
                    noisy,
                    v120[role],
                    base[role],
                    diagonal[role],
                    matched[role],
                    confirmed[role],
                    target[role],
                ],
                calibration,
                {
                    "row": row,
                    "role": name,
                    "strengths": {k: scales[k][DOSE] for k in ("matched", "diagonal", "confirmed")},
                    "weights": receipt["weights"],
                    "layout": fields["colors"].tolist(),
                },
                labels=(
                    "Noisy Malvar",
                    "V120 EMA",
                    "Corpus 100k",
                    "Diagonal control",
                    LABEL,
                    CONFIRMED,
                    "Exact GT",
                ),
                triplet_indices=(0, 5, 6),
                exposure=1 / row["profile"]["exposure"],
                contrast=2,
                roi=(48, 48, 160, 160),
            )
            output.append({"id": row["id"], "role": name, "scores": case["terms"], **board})
    return output


def pixels(board):
    with Image.open(checked(board["image"])) as source:
        image = np.asarray(source.convert("RGB"))
    return {
        p.get("name", p.get("label")): image[y : y + h, x : x + w]
        for p in board["panels"]
        for x, y, w, h in (p["png_xywh"],)
    }


def standing(receipt, scales, folder, links):
    base, geometry, prior = [
        read_json(checked(links[k])) for k in ("base", "geometry", "references")
    ]
    assert base["checkpoints"]["100k"]["sha256"] == receipt["weights"]
    assert (
        base["checkpoints"]["V120"]["sha256"]
        == read_json(checked(links["v120_config"]))["checkpoint"]["sha256"]
    )
    baseline = {v["id"]: v for v in base["standing"]}
    old = {v["id"]: v for v in prior["rows"]}
    rows = []
    for family in ("main", "mesh"):
        fields = [r for r in geometry["rows"] if r["id"].startswith(family)]
        source = fields[0]["raw_source"]
        path = checked(source)
        assert path.is_relative_to(ROOT.parents[1])
        image, camera = read_raw(path)
        layout = color_indices(camera.pattern).numpy()
        h, w = (n // 2 * 2 for n in image.shape)
        raw = np.stack([image[g // 2 : h : 2, g % 2 : w : 2] for g in range(4)])
        del image
        for item in fields:
            id_ = item["id"]
            refs = old[id_]
            former = baseline[id_]
            assert refs["raw_source"] == item["raw_source"] == former["raw"] == source
            x, y, w, h = box = item["query_xywh"]
            rx, ry, rw, rh = item["ROI_raw_xywh"]
            crop = np.s_[..., ry - y : ry - y + rh, rx - x : rx - x + rw]
            bx, by, _, _ = refs["native_box"]
            assert [
                bx + refs["ROI_xywh"][0],
                by + refs["ROI_xywh"][1],
                *refs["ROI_xywh"][2:],
            ] == item["ROI_raw_xywh"]
            obs = raw[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
            assert former["native_sensor_box"] == refs["native_box"]
            assert former["roi"] == refs["ROI_xywh"]
            local_x, local_y = x - bx, y - by
            with np.load(checked(former["input"]), allow_pickle=False) as f:
                calibration = {k: f[k] for k in ("wb", "matrix")}
                np.testing.assert_array_equal(f["colors"][0], layout)
                np.testing.assert_array_equal(
                    f["packed"][
                        0, :, local_y // 2 : (local_y + h) // 2, local_x // 2 : (local_x + w) // 2
                    ],
                    obs,
                )
            parent_ref = former["parent_images"]["parent100k"]
            parent = np.load(checked(parent_ref), allow_pickle=False)[
                0, :, local_y : local_y + h, local_x : local_x + w
            ]
            assert parent.shape[-2:] == (h, w)
            n = item["noise"]
            assert all(
                np.isclose(n[k], refs["condition"][k], rtol=1e-13, atol=0) for k in ("shot", "read")
            )
            noise = n["shot"], n["read"]
            exterior = patch.build_exterior(raw, layout, box, *noise)
            selected = patch.corrections(obs, parent[1], layout, *noise, box, exterior)
            rendered = {
                k: apply_delta(
                    parent,
                    unscaled,
                    calibration["wb"][0],
                    calibration["matrix"][0],
                    scales[k][DOSE],
                )
                for k, unscaled in selected.items()
            }
            scores = {
                k: float(np.sqrt(np.mean((img[crop].astype(float) - parent[crop]) ** 2)) * 65535)
                for k, img in rendered.items()
            }
            displays = []
            for row in refs["displays"]:
                exposure = row["exposure"]
                comparison = pixels(row["board"])
                panels = [
                    (k, comparison[k])
                    for k in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA")
                    if k in comparison
                ]

                def raster(p):
                    rendered = display_crop(
                        torch.from_numpy(p[None]),
                        torch.from_numpy(calibration["wb"]),
                        torch.from_numpy(calibration["matrix"]),
                        (rx - x, ry - y, rw, rh),
                        exposure=exposure,
                    )
                    return np.rint(255 * rendered).astype(np.uint8)

                panels.extend(
                    [
                        ("Corpus 100k", raster(parent)),
                        ("Diagonal control", raster(rendered["diagonal"])),
                        (LABEL, raster(rendered["matched"])),
                        (CONFIRMED, raster(rendered["confirmed"])),
                        ("Confirmed diagonal", raster(rendered["confirmed_diagonal"])),
                        ("Transposed covariance", raster(rendered["transposed"])),
                    ]
                )
                if exposure == former["exposure"]:
                    binding = former["board"]["image"]
                    published = str(BASE.parent / binding["path"])
                    earlier = pixels(former["board"] | {"image": binding | {"path": published}})
                    np.testing.assert_array_equal(raster(parent), earlier["Parent 100k EMA"])
                    np.testing.assert_array_equal(comparison["V120 EMA"], earlier["V120 EMA"])
                panels.extend(
                    (k, comparison[k])
                    for k in ("ISO100 AHD reference", "ISO100 camera JPEG")
                    if k in comparison
                )
                displays.append(
                    {
                        "exposure": exposure,
                        "board": native_png(folder / f"{id_}-x{exposure:g}.png", panels),
                    }
                )
            rows.append(
                {
                    "id": id_,
                    "query": box,
                    "native_ROI": item["ROI_raw_xywh"],
                    "raw": source,
                    "noise": n,
                    "donor_windows": len(exterior.coords),
                    "parent_input": former["input"],
                    "parent_prediction": parent_ref,
                    "previous_display": refs["displays"],
                    "camera_RGB_change_DN16": scores,
                    "displays": displays,
                }
            )
            print(id_, {k: round(v, 3) for k, v in scores.items()}, flush=True)
        del raw
    assert len(rows) == 8 and sum(len(r["displays"]) for r in rows) == 12
    return rows


def main():
    torch.set_num_threads(2)
    doc = reference(ROOT / "confirmed-replay.json")
    receipt = read_json(checked(doc))
    scale = receipt["summary"]["iso6400"]["settings"]
    links = {
        k: reference(p)
        for k, p in (
            ("base", BASE),
            ("geometry", GEOMETRY),
            ("references", REFERENCES),
            ("v120_config", V120_CONFIG),
        )
    }
    p = ROOT / "native"
    (p / "exact").mkdir(parents=True, exist_ok=True)
    (p / "standing").mkdir(exist_ok=True)
    write_json(
        p / "result.json",
        {
            "driver": reference(__file__),
            "measurement": doc,
            "links": links,
            "weights": {
                "Corpus 100k": receipt["weights"],
                "V120": read_json(checked(links["v120_config"]))["checkpoint"],
            },
            "strengths": {k: v[DOSE] for k, v in scale.items()},
            "exact": exact_boards(receipt, scale, p / "exact"),
            "standing": standing(receipt, scale, p / "standing", links),
        },
    )


if __name__ == "__main__":
    main()
