"""Arrange native cells for human review without resampling."""

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native import ROOT, pixels


def sheet(rows, labels, path):
    dst = Image.new("RGB", (8 + 168 * len(labels), 30 + 179 * len(rows)), "#eeeeee")
    draw = ImageDraw.Draw(dst)
    for i, label in enumerate(labels):
        draw.text((8 + 168 * i, 5), label, fill="black")
    for j, (name, board) in enumerate(rows):
        bitmap = pixels(board)
        draw.text((8, 191 + 179 * j), name, fill="black")
        for i, label in enumerate(labels):
            tile = Image.fromarray(bitmap[label])
            assert tile.size == (160, 160)
            dst.paste(tile, (8 + 168 * i, 30 + 179 * j))
    dst.save(path)
    return reference(path)


def main():
    basis = reference(ROOT / "native/review.json")
    rows = read_json(checked(basis))
    labels = [
        "Noisy (Malvar)",
        "V120 EMA",
        "Corpus 100k",
        "Donor-validated covariance",
        "Donor and query check",
        "ISO100 AHD reference",
    ]
    views = {}
    for kind, exposures in (("main", (4,)), ("mesh", (4, 16))):
        for e in exposures:
            selected = [
                (r["id"], d["board"])
                for r in rows["standing"]
                if r["id"].startswith(kind)
                for d in r["displays"]
                if d["exposure"] == e
            ]
            name = f"{kind}-x{e}"
            views[name] = sheet(selected, labels, ROOT / f"inspect-{name}.png")
            if kind == "mesh":
                label = [
                    "ISO6400 camera JPEG",
                    "Confirmed diagonal",
                    "Donor-validated diagonal",
                    "Transposed prior",
                    "ISO100 camera JPEG",
                ]
                views[name + "-refs"] = sheet(selected, label, ROOT / f"inspect-{name}-refs.png")
    labels = [
        "Noisy Malvar",
        "V120 EMA",
        "Corpus 100k",
        "Confirmed diagonal",
        "Donor-validated covariance",
        "Exact GT",
    ]
    views["exact"] = sheet(
        [(r["id"], r["board"]) for r in rows["exact"]], labels, ROOT / "inspect-exact.png"
    )
    write_json(
        ROOT / "sheets.json", {"driver": reference(__file__), "review": basis, "views": views}
    )


if __name__ == "__main__":
    main()
