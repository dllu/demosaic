"""Render the frozen matched-quiet policy on exact queries and standing crops."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic import scene_patch_covariance as patch
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop
from score import OLD, ROOT, deltas, replay

sys.path[:0] = ["scripts", str(ROOT.with_name("paired-luminance-detail-v1"))]
from render import native_png
from render_review import pixels
from report_scene_wave_guides import native_board

POLICY = "quiet"
CANDIDATE = "donor_validated"
CONTROL = "confirmed_diagonal"
LABELS = {
    "matched": "Single covariance",
    "confirmed_diagonal": "Confirmed diagonal",
    "donor_validated": "Donor-validated covariance",
    "validated_diagonal": "Donor-validated diagonal",
    "validated_transposed": "Transposed prior",
    "donor_and_query": "Donor and query check",
}


def exact_views(rows, settings, room):
    def compared(row):
        return [
            float(replay.estimate([row["terms"][k]["fine"]["increment"]], "increment", settings[k]))
            for k in (CANDIDATE, CONTROL)
        ]

    def change(a):
        b, c = compared(a)
        return b - c

    candidates = sorted(rows, key=change)
    chosen = (candidates[0], candidates[-1])
    exact = []
    for item in chosen:
        case = item["case"]
        raw, parent, v120 = replay.read_inputs(case)
        correction, _ = deltas(case, raw, parent, validate_donors=True)
        older, _ = deltas(case, raw, parent, validate_donors=False)
        op = {k: parent + settings[k] * v for k, v in (correction | older).items() if k in LABELS}
        with np.load(checked(case["input"]), allow_pickle=False) as f:
            target = f["target"]
        for role, key in ((0, "present"), (2, "flat")):
            cal = {k: raw[k][None] for k in ("colors", "wb", "matrix")}
            noisy = noisy_malvar(cal | {"packed": raw["packed"][role : role + 1]})[0]
            fact = {
                "record": case,
                "role": key,
                "weights": settings,
                "increment_RMS_change_vs_confirmed_diagonal": float(change(item)),
            }
            labels = (
                "Noisy Malvar",
                "V120 EMA",
                "Corpus 100k",
                *(LABELS[k] for k in LABELS),
                "Exact GT",
            )
            data = [noisy, v120[role], parent[role], *(op[k][role] for k in LABELS), target[role]]
            choice = list(labels).index(LABELS[CANDIDATE])
            exact.append(
                native_board(
                    room,
                    f"{case['id']}-{key}",
                    data,
                    cal,
                    fact,
                    labels=labels,
                    triplet_indices=(0, choice, len(labels) - 1),
                    exposure=1 / 0.33,
                    contrast=2,
                    roi=(48, 48, 160, 160),
                )
            )
    return exact


def review_camera(settings, room, binding):
    previous = read_json(checked(binding))
    sensor = read_json(checked(previous["links"]["references"]))
    stored = {r["id"]: r for r in sensor["rows"]}
    results = []
    for family in ("main", "mesh"):
        all_ = [r for r in previous["standing"] if r["id"].startswith(family)]
        path = checked(all_[0]["raw"])
        assert path.is_relative_to(ROOT.parents[1])
        rgb, meta = read_raw(path)
        height, width = (2 * (n // 2) for n in rgb.shape)
        raw = np.stack([rgb[k // 2 : height : 2, k % 2 : width : 2] for k in range(4)])
        del rgb
        cfa = color_indices(meta.pattern).numpy()
        for r in all_:
            id_ = r["id"]
            records = stored[id_]
            assert r["raw"] == all_[0]["raw"] == records["raw_source"]
            x, y, w, h = r["query"]
            qx, qy, rw, rh = r["native_ROI"]
            ix, iy, _, _ = records["native_box"]
            ox, oy = x - ix, y - iy
            roi = (qx - x, qy - y, rw, rh)
            core = np.s_[..., roi[1] : roi[1] + rh, roi[0] : roi[0] + rw]
            obs = raw[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
            with np.load(checked(r["parent_input"]), allow_pickle=False) as f:
                np.testing.assert_array_equal(f["colors"][0], cfa)
                np.testing.assert_array_equal(
                    f["packed"][0, :, oy // 2 : (oy + h) // 2, ox // 2 : (ox + w) // 2], obs
                )
                wb, matrix = (f[k] for k in ("wb", "matrix"))
            p = np.load(checked(r["parent_prediction"]), allow_pickle=False)[
                0, :, oy : oy + h, ox : ox + w
            ]
            s, v = (r["noise"][k] for k in ("shot", "read"))
            ext = patch.build_exterior(raw, cfa, r["query"], s, v)
            legacy = patch.corrections(obs, p[1], cfa, s, v, r["query"], ext)
            active = patch.corrections(obs, p[1], cfa, s, v, r["query"], ext, validate_donors=True)
            outputs = {
                k: replay.apply_delta(p, field, wb[0], matrix[0], settings[k])
                for k, field in (legacy | active).items()
                if k in LABELS
            }
            ds = {}
            for k, b in outputs.items():
                difference = (b[core].astype(float) - p[core]) * 65535
                ds[k] = float(np.sqrt(np.mean(difference**2)))
            rows = []
            for d in r["displays"]:
                exposure = d["exposure"]
                prior = pixels(d["board"])

                def render(t):
                    shot = display_crop(
                        torch.from_numpy(t[None]),
                        torch.from_numpy(wb),
                        torch.from_numpy(matrix),
                        roi,
                        exposure=exposure,
                    )
                    return np.rint(np.clip(shot, 0, 1) * 255).astype(np.uint8)

                np.testing.assert_array_equal(render(p), prior["Corpus 100k"])
                panels = [
                    (k, prior[k])
                    for k in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Corpus 100k")
                    if k in prior
                ]
                panels += [(LABELS[k], render(outputs[k])) for k in LABELS]
                panels += [
                    (k, prior[k])
                    for k in ("ISO100 AHD reference", "ISO100 camera JPEG")
                    if k in prior
                ]
                rows.append(
                    {
                        "exposure": exposure,
                        "board": native_png(room / f"{id_}-x{exposure:g}.png", panels),
                    }
                )
            results.append(
                {
                    k: r[k]
                    for k in (
                        "id",
                        "raw",
                        "noise",
                        "query",
                        "native_ROI",
                        "parent_input",
                        "parent_prediction",
                    )
                }
                | {"donor_windows": len(ext.coords), "camera_RGB_change_DN16": ds, "displays": rows}
            )
            print(id_, {k: round(v, 3) for k, v in ds.items()}, flush=True)
        del raw
    return results


def main():
    torch.set_num_threads(2)
    old = reference(OLD / "native/result.json")
    proof = reference(ROOT / "evaluation.json")
    m = read_json(checked(proof))
    fits = read_json(checked(m["calibration"]))
    assert fits["kernel"] == reference(patch.__file__)
    settings = {k: v[POLICY] for k, v in fits["settings"]["iso6400"].items()}
    output = ROOT / "native"
    (output / "exact").mkdir(parents=True, exist_ok=True)
    (output / "standing").mkdir(exist_ok=True)
    exact = exact_views(
        [r for r in m["cases"] if r["case"]["partition"] == "fresh"], settings, output / "exact"
    )
    standing = review_camera(settings, output / "standing", old)
    assert len(standing) == 8 and sum(len(r["displays"]) for r in standing) == 12
    write_json(
        output / "review.json",
        {
            "driver": reference(__file__),
            "evaluation": proof,
            "old_camera_review": old,
            "operating_point": POLICY,
            "settings": settings,
            "exact": exact,
            "standing": standing,
        },
    )


if __name__ == "__main__":
    main()
