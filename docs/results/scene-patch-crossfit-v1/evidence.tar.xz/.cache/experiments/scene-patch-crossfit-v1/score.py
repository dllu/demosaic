"""Calibrate on independent pairs, then evaluate finite-sample donor screening."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import sys
import time

import numpy as np
from scipy.optimize import brentq

from demosaic import scene_patch_covariance as patch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
OLD = ROOT.with_name("scene-patch-covariance-v1")
EXTERNAL = Path("/mnt/external/demosaic") / ROOT.name
PRIOR = {k: OLD / f"{k}.json" for k in ("confirmed-replay", "independent-fit", "closure")}
MODES = ("matched", "diagonal", "confirmed", "confirmed_diagonal", *patch.VALIDATED_MODES)
BUDGET = 0.15
MAX = 0.8
METRICS = ("present", "absent", "flat", "increment", "response")

sys.path.insert(0, str(OLD))
import replay


def deltas(row, fields, parent, *, validate_donors):
    cfa, wb, matrix = (fields[k] for k in ("colors", "wb", "matrix"))
    box = row["box"]
    p = row["profile"]
    noise = p["shot"], p["read"]
    exterior = patch.build_exterior(fields["scene_packed"], cfa, box, *noise)
    accepted = {m: [] for m in (patch.VALIDATED_MODES if validate_donors else patch.MODES)}
    for raw, b in zip(fields["packed"], parent, strict=True):
        output = patch.corrections(
            raw, b[1], cfa, *noise, box, exterior, validate_donors=validate_donors
        )
        for name, v in output.items():
            accepted[name].append(replay.apply_delta(np.zeros_like(b), v, wb, matrix, 1.0))
    return {name: np.stack(v) for name, v in accepted.items()}, (
        len(exterior.coords) if exterior is not None else 0
    )


def score_row(row, previous=None):
    fields, parent, v120 = replay.read_inputs(row)
    if "packed" in row:
        assert fingerprint(fields["packed"]) == row["packed"]
    corrections, donors = deltas(row, fields, parent, validate_donors=True)
    if previous is None:
        before, old_windows = deltas(row, fields, parent, validate_donors=False)
        assert old_windows == donors
        corrections.update({k: v for k, v in before.items() if k in MODES})
    with np.load(checked(row["input"]), allow_pickle=False) as f:
        exact = replay.transform(f["target"], fields)
    parent_coeff = replay.transform(parent, fields)
    by_mode = {} if previous is None else previous["terms"].copy()
    for name, output in corrections.items():
        option = replay.transform(output, fields)
        by_mode[name] = {
            band: replay.terms(value, option[band], exact[band])
            for band, value in parent_coeff.items()
        }
    parent_terms = {
        band: replay.terms(value, np.zeros_like(value), exact[band])
        for band, value in parent_coeff.items()
    }
    if previous is None:
        by_mode["parent"] = parent_terms
        if v120 is not None:
            by_mode["v120"] = {
                band: replay.terms(value, np.zeros_like(value), exact[band])
                for band, value in replay.transform(v120, fields).items()
            }
    else:
        assert previous["case"] == row and previous["atlas_windows"] == donors
        assert parent_terms == by_mode["parent"]
    return {"case": row, "atlas_windows": donors, "terms": by_mode}


def unchanged_prior(records):
    for before in (records[0], records[len(records) // 2], records[-1]):
        row = before["case"]
        fields, old, _ = replay.read_inputs(row)
        measured, _ = deltas(row, fields, old, validate_donors=False)
        parent = replay.transform(old, fields)
        with np.load(checked(row["input"]), allow_pickle=False) as r:
            gt = replay.transform(r["target"], fields)
        for name in patch.MODES:
            prediction = replay.transform(measured[name], fields)
            for band, old_band in parent.items():
                assert (
                    replay.terms(old_band, prediction[band], gt[band])
                    == before["terms"][name][band]
                )


def evaluate(rows, callback):
    result = []
    now = time.monotonic()
    with ThreadPoolExecutor(4) as pool:
        for val in pool.map(callback, rows):
            result.append(val)
            if len(result) % 16 == 0:
                print(len(result), round(time.monotonic() - now, 2), flush=True)
    return result, time.monotonic() - now


def tune(rows):
    x = np.unique(np.r_[np.arange(801) / 10000, np.arange(9, 81) / 100])
    out = {}
    for mode in MODES:
        chosen = {}
        for band in replay.BANDS:
            terms = {k: replay.arrays(rows, mode, band, k) for k in METRICS}
            chosen[band] = {k: replay.estimate(src, k, x[:, None]) for k, src in terms.items()}
        strict = np.ones(len(x), dtype=bool)
        for values in chosen.values():
            strict &= values["flat"] <= values["flat"][0] + 0.05
            strict &= values["present"] <= values["present"][0] + 0.02
        fine = chosen["fine"]
        strict &= fine["response"] >= fine["response"][0]
        optimum = x[np.argmin(np.where(strict, fine["increment"], np.inf))]
        flat_terms = replay.arrays(rows, mode, "fine", "flat")

        def excess(g):
            return replay.estimate(flat_terms, "flat", g) - fine["flat"][0] - BUDGET

        quiet = brentq(excess, 0, MAX) if excess(MAX) > 0 else MAX
        amount = replay.arrays(rows, mode, "fine", "response").sum(axis=0)
        gain = min(MAX, 0.001 * amount[2] / amount[1]) if amount[1] > 1e-20 else 0.0
        out[mode] = {
            "fitted": float(optimum),
            "quiet": float(quiet),
            "response": float(gain),
            "calibrated_fine_flat_delta": excess(quiet) + BUDGET,
            "calibrated_response_delta": float(100 * gain * amount[1] / amount[2]),
        }
    return out


def recalibrate(result):
    return {
        iso: tune([r for r in result if r["case"]["profile"]["name"] == iso])
        for iso in ("iso400", "iso6400")
    }


def checked_configuration():
    links = {k: reference(v) for k, v in PRIOR.items()}
    original = {k: read_json(checked(v)) for k, v in links.items()}
    return links, original


def calibration():
    links, original = checked_configuration()
    before = original["independent-fit"]["cases"]
    assert len(before) == 64 and all(r["case"]["draw"] == "independent" for r in before)
    unchanged_prior(before)
    result, elapsed = evaluate(before, lambda r: score_row(r["case"], r))
    strengths = recalibrate(result)
    print(
        {
            iso: {k: round(v["fitted"], 4) for k, v in rows.items()}
            for iso, rows in strengths.items()
        },
        flush=True,
    )
    write_json(
        ROOT / "calibration.json",
        {
            "driver": reference(__file__),
            "kernel": reference(patch.__file__),
            "basis_metrics": reference(replay.__file__),
            "earlier": links,
            "quiet_budget": BUDGET,
            "seconds": elapsed,
            "settings": strengths,
            "rows": result,
            "source_count": 32,
            "noise_draw_law": "independent",
        },
    )


def summarize(rows, settings):
    buckets = {}
    for r in rows:
        c = r["case"]
        buckets.setdefault((c["partition"], c["profile"]["name"]), []).append(r)
    rng = np.random.default_rng(202611191817)
    result = {}
    for (cohort, iso), group in buckets.items():
        n = len(group)
        draw = np.vstack((np.arange(n), rng.integers(0, n, size=(8000, n))))
        by_mode = {}
        for operating in ("quiet", "response", "fitted"):
            values = {k: v[operating] for k, v in settings[iso].items()} | {"parent": 0.0}
            if all("v120" in r["terms"] for r in group):
                values["v120"] = 0.0
            results = {}
            for band in replay.BANDS:
                results[band] = {}
                for metric in METRICS:
                    metric_values = {
                        k: replay.estimate(
                            replay.arrays(group, k, band, metric), metric, gain, draw
                        )
                        for k, gain in values.items()
                    }
                    buckets_ = {}
                    for mode, vals in metric_values.items():
                        comparisons = {}
                        for name in (
                            "parent",
                            "confirmed_diagonal",
                            "validated_diagonal",
                            "donor_validated",
                        ):
                            d = vals - metric_values[name]
                            comparisons[name] = [
                                float(d[0]),
                                *np.quantile(d[1:], [0.025, 0.975]).tolist(),
                            ]
                        buckets_[mode] = {"value": float(vals[0]), "differences": comparisons}
                    results[band][metric] = buckets_
            by_mode[operating] = results
        result.setdefault(cohort, {})[iso] = {"count": n, "results": by_mode}
    return result


def transfer():
    lock = reference(ROOT / "calibration.json")
    calibrated = read_json(checked(lock))
    assert calibrated["driver"] == reference(__file__) and calibrated["kernel"] == reference(
        patch.__file__
    )
    links, original = checked_configuration()
    assert links == calibrated["earlier"]
    inherited = [
        r for r in original["confirmed-replay"]["cases"] if r["case"]["partition"] != "calibration"
    ]
    refs = reference(EXTERNAL / "parents.json")
    fresh = read_json(checked(refs))
    assert fresh["checkpoints"]["parent"]["sha256"] == replay.BASE_SHA
    for key in ("id", "cache_sha256"):
        forbidden = {r["case"]["source"][key] for r in calibrated["rows"] + inherited}
        candidate = {r["source"][key] for r in fresh["rows"]}
        assert len(candidate) == 32 and not candidate & forbidden
    exact, new_time = evaluate(fresh["rows"], score_row)
    old, old_time = evaluate(inherited, lambda r: score_row(r["case"], r))
    metrics = summarize(exact + old, calibrated["settings"])
    write_json(
        ROOT / "evaluation.json",
        {
            "driver": reference(__file__),
            "calibration": lock,
            "fresh_parents": refs,
            "seconds": {"fresh": new_time, "previous": old_time},
            "cases": exact + old,
            "summary": metrics,
        },
    )


if __name__ == "__main__":
    flags = argparse.ArgumentParser()
    flags.add_argument("stage", choices=("calibrate", "transfer"))
    args = flags.parse_args()
    calibration() if args.stage == "calibrate" else transfer()
