"""Render the wire-flat-matched detail policy and record paired intervals."""

from collections import defaultdict

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native import ROOT, native_board
from score import deltas, replay

CANDIDATE = "donor_and_query"
CONTROL = "confirmed_diagonal"


def result(r, mode, measure):
    return r["results"]["matched-flat"][mode][measure]


def comparisons(rows):
    by_family = defaultdict(list)
    for r in rows:
        by_family[r["family"]].append(r)
    rng = np.random.default_rng(202611191819)
    keys = {m for r in rows for m in r["base"]}
    output = {}
    for m in sorted(keys):
        draws = []
        values = []
        for block in by_family.values():
            v = np.array(
                [result(a, CANDIDATE, m) - result(a, CONTROL, m) for a in block if m in a["base"]]
            )
            if len(v):
                values.extend(v)
                draws.append(v[rng.integers(0, len(v), size=(8000, len(v)))].sum(axis=1))
        pooled = np.sum(draws, axis=0) / len(values)
        output[m] = {
            "n": len(values),
            "delta": float(np.mean(values)),
            "conditional_interval": np.quantile(pooled, [0.025, 0.975]).tolist(),
        }
    return output


def main():
    torch.set_num_threads(2)
    src = reference(ROOT / "wire-tradeoff.json")
    result_ = read_json(checked(src))
    previous = read_json(checked(result_["original_replay"]))
    rows = dict(
        zip((p["input"]["sha256"] for p in previous["rows"]), previous["rows"], strict=True)
    )
    room = ROOT / "native/wire"
    room.mkdir()
    valid = [p for p in result_["cases"] if "gap_weak_RMS_DN16" in p["base"]]
    hi = max(
        valid,
        key=lambda r: (
            result(r, CANDIDATE, "weak_response_pp") - result(r, CONTROL, "weak_response_pp")
        ),
    )
    other = [r for r in valid if r is not hi]
    adverse = max(
        other,
        key=lambda r: (
            result(r, CANDIDATE, "gap_weak_RMS_DN16") - result(r, CONTROL, "gap_weak_RMS_DN16")
        ),
    )
    exact = []
    for case, note in (
        (hi, "largest extra weak response among exact gaps"),
        (adverse, "largest extra false-gap error among the other exact gaps"),
    ):
        r = rows[case["input"]["sha256"]]
        fields, parent, v120 = replay.read_inputs(r)
        p, _ = deltas(r, fields, parent, validate_donors=True)
        q, _ = deltas(r, fields, parent, validate_donors=False)
        scale = result_["gains"][case["family"]]
        upper = parent[0] + p[CANDIDATE][0] * scale[CANDIDATE]["gain"]
        former = parent[0] + q[CONTROL][0] * scale[CONTROL]["gain"]
        cal = {k: fields[k][None] for k in ("colors", "wb", "matrix")}
        noisy = noisy_malvar(cal | {"packed": fields["packed"][:1]})[0]
        with np.load(checked(r["input"]), allow_pickle=False) as f:
            gt = f["target"][0]
        key = r["source"]["id"][:10]
        exact.append(
            native_board(
                room,
                f"wire-{key}",
                [noisy, v120[0], parent[0], former, upper, gt],
                cal,
                {
                    "record": r,
                    "role": "present",
                    "display_choice": note,
                    "strengths": scale,
                    "matched_wire_result": case["results"],
                },
                labels=(
                    "Noisy Malvar",
                    "V120 EMA",
                    "Corpus 100k",
                    "Confirmed diagonal",
                    "Donor and query check",
                    "Exact GT",
                ),
                triplet_indices=(0, 4, 5),
                exposure=2,
                contrast=1,
                roi=(48, 48, 160, 160),
            )
        )
    write_json(
        ROOT / "wire-native.json",
        {
            "driver": reference(__file__),
            "source": src,
            "viewable": exact,
            "comparison": comparisons(result_["cases"]),
            "interval": "Photo bootstrap within each geometry family with frozen fold gains.",
        },
    )


if __name__ == "__main__":
    main()
