"""Transfer the frozen natural-photo strengths to retained exact wires and gaps."""

import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score import OLD, ROOT, MODES, deltas, evaluate, replay

sys.path.insert(0, str(ROOT.with_name("scene-mixture-wire-gaps-v1")))
from scoring import WireMetric

SOURCE = ROOT.with_name("green-covariance-refit-v1") / "fresh.json"


def replay_case(item, profile, settings):
    r = {
        "source": item["source"]["source"],
        "box": item["box"],
        "profile": profile,
        "input": item["input"],
        "rgb": item["predictions"],
        "rgb_key": "parent",
    }
    fields, base, v120 = replay.read_inputs(r)
    updates, atlas = deltas(r, fields, base, validate_donors=True)
    earlier, _ = deltas(r, fields, base, validate_donors=False)
    updates.update({k: v for k, v in earlier.items() if k in MODES})
    with np.load(checked(r["input"]), allow_pickle=False) as f:
        data = fields | {"target": f["target"], "support": f["support"]}
    geometry = item["source"]["geometry"]
    if geometry["family"] == "smooth-dip":
        assert (data["support"] > 0).all()
        data["support"] = np.ones_like(data["support"])
    score = WireMetric(data, geometry)
    values = {
        op: {k: score(base + settings[k][op] * v) for k, v in updates.items()}
        | {"parent": score(base), "v120": score(v120)}
        for op in ("quiet", "response")
    }
    return r | {
        "geometry": geometry,
        "atlas": atlas,
        "true_gap_pixels": int(score.gap.sum()),
        "results": values,
    }


def summary(rows):
    rng = np.random.default_rng(202611191818)
    means = {}
    for op in rows[0]["results"]:
        means[op] = {}
        keys = sorted({key for r in rows for key in r["results"][op]["parent"]})
        for key in keys:
            selected = [r["results"][op] for r in rows if key in r["results"][op]["parent"]]
            n = len(selected)
            index = np.vstack((np.arange(n), rng.integers(n, size=(6000, n))))
            boot = {
                k: np.array([r[k][key] for r in selected])[index].mean(axis=1) for k in selected[0]
            }
            comparisons = {}
            for mode, series in boot.items():
                entry = {"mean": float(series[0]), "n": n}
                for name in ("parent", "matched", "validated_diagonal"):
                    diff = series - boot[name]
                    entry[name] = [float(diff[0]), *np.quantile(diff[1:], [0.025, 0.975]).tolist()]
                comparisons[mode] = entry
            means[op][key] = comparisons
    return means


def main():
    calibration = reference(ROOT / "calibration.json")
    chosen = read_json(checked(calibration))
    source = reference(SOURCE)
    cohort = read_json(checked(source))
    plan = read_json(checked(cohort["plan"]))
    assert plan["checkpoints"]["100k"]["sha256"] == replay.BASE_SHA
    profile = plan["profile"]
    settings = chosen["settings"][profile["name"]]
    locked = [r for r in cohort["rows"] if r["source"]["kind"] == "wire"]
    assert len(locked) == 24
    old = read_json(checked(reference(OLD / "confirmed-replay.json")))
    for k in ("id", "cache_sha256"):
        assert not {r["case"]["source"][k] for r in old["cases"]}.intersection(
            a["source"]["source"][k] for a in locked
        )
    rows, seconds = evaluate(locked, lambda r: replay_case(r, profile, settings))
    assert sum(r["true_gap_pixels"] > 0 for r in rows) == 12
    write_json(
        ROOT / "wires.json",
        {
            "driver": reference(__file__),
            "metric": reference(sys.modules["scoring"].__file__),
            "calibration": calibration,
            "source": source,
            "summary": summary(rows),
            "rows": rows,
            "seconds": seconds,
        },
    )


if __name__ == "__main__":
    main()
