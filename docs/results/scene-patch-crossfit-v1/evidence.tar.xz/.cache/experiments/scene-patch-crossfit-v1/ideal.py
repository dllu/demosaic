"""Compare donor validation in coherent, decorrelated, and mismatched groups."""

from pathlib import Path

import numpy as np

from demosaic import scene_patch_covariance as patch
from demosaic.experiments.artifacts import reference, write_json

ROOT = Path(__file__).resolve().parent
SEED = 202611191810
SIGMA = 0.014
DONORS = 32
N = 384
GROUPS = ("coherent", "changing_phase", "half_perpendicular", "wrong_context")
LAYOUTS = [(0, 1, 1, 2), (1, 0, 2, 1), (1, 2, 0, 1), (2, 1, 1, 0)]
MODES = ("single_covariance", "single_diagonal", *patch.VALIDATED_MODES)


def trial(colors, group, rng):
    basis = patch.patch_basis(colors)
    k = len(basis.image)
    pure = np.flatnonzero(np.max(np.ptp(basis.image, axis=1), axis=1) < 1e-14)
    assert len(pure) >= 3
    active = pure[[0, 2]]
    shape = np.zeros(k)
    shape[active] = [0.8, 0.6]
    amp = rng.choice((-1, 1), (N, DONORS)) * rng.uniform(0.07, 0.13, (N, DONORS))
    exact_donor = amp[..., None] * shape
    if group == "changing_phase":
        exact_donor[..., active[1]] *= rng.choice((-1, 1), (N, DONORS))
    if group == "half_perpendicular":
        exact_donor[:, 1::2] = exact_donor[:, 1::2, basis.transpose]
    if group == "wrong_context":
        exact_donor = exact_donor[..., basis.transpose]
    period = basis.projection.shape[-1]
    raw = rng.normal(0, SIGMA, size=(N, DONORS, 2, period))
    observations = exact_donor[:, :, None] + np.einsum("gkp,ndgp->ndgk", basis.projection, raw)
    donors = observations / (np.sqrt(2) * SIGMA)
    weights = np.full((N, DONORS), 1 / DONORS)
    moment = patch.covariance(donors, weights)
    diag = moment * np.eye(k)
    floor = np.sqrt(k * np.sum(weights**2, axis=1))
    exact = 0.023 * rng.choice((-1, 1), (N, 1)) * shape
    parent = 0.4 * exact
    out = {}
    for name, target, base in (
        ("present", exact, parent),
        ("flat", np.zeros_like(exact), np.zeros_like(exact)),
    ):
        raw = rng.normal(0, SIGMA, size=(N, 2, period))
        measured = target[:, None] + np.einsum("gkp,ngp->ngk", basis.projection, raw)
        innovation = measured.mean(axis=1) - base
        candidate = patch.donor_validated_fields(
            donors, weights, innovation, measured, np.full(N, SIGMA), basis
        )
        candidate["single_covariance"] = patch.filter_innovation(moment, innovation, floor)
        candidate["single_diagonal"] = patch.filter_innovation(diag, innovation, floor)
        out[name] = candidate
    return exact, parent, out


def generate(seed, group):
    rng = np.random.default_rng(seed)
    all_ = [trial(layout, group, rng) for layout in LAYOUTS]
    exact = np.concatenate([v[0] for v in all_])
    parent = np.concatenate([v[1] for v in all_])
    outputs = {
        role: {m: np.concatenate([v[2][role][m] for v in all_]) for m in MODES}
        for role in ("present", "flat")
    }
    return exact, parent, outputs


def scores(exact, parent, fields, gain):
    present, flat = fields
    to_dn16 = 65535 / patch.SIZE
    error = parent + gain * present - exact
    return {
        "gain": float(gain),
        "response": float(100 * np.sum((parent + gain * present) * exact) / np.sum(exact**2)),
        "intact_DN16": float(to_dn16 * np.sqrt(np.sum(error**2, axis=-1).mean())),
        "flat_DN16": float(to_dn16 * gain * np.sqrt(np.sum(flat**2, axis=-1).mean())),
    }


def main():
    # Fix one gain per operator using coherent repeats, then draw fresh donors and
    # query noise. The mismatched groups receive the same frozen settings.
    gt, _, fit = generate(SEED, "coherent")
    strengths = {
        m: float(min(1, 0.10 * np.sum(gt**2) / max(1e-20, np.sum(fit["present"][m] * gt))))
        for m in MODES
    }
    target_flat = min(
        np.sqrt(np.mean(np.sum(fit["flat"][m] ** 2, axis=-1))) * strengths[m]
        for m in ("single_diagonal", "donor_validated", "validated_diagonal")
    )
    quiet = {
        m: float(
            min(1, target_flat / max(1e-20, np.sqrt(np.mean(np.sum(fit["flat"][m] ** 2, axis=-1)))))
        )
        for m in MODES
    }
    study = {}
    for i, group in enumerate(GROUPS):
        exact, parent, out = generate(SEED + 57 + i, group)
        study[group] = {
            mode: {
                m: scores(exact, parent, (out["present"][m], out["flat"][m]), scale[m])
                for m in MODES
            }
            for mode, scale in (("fit_response", strengths), ("fit_flat", quiet))
        }
    write_json(
        ROOT / "ideal.json",
        {
            "driver": reference(__file__),
            "model": reference(patch.__file__),
            "seed": SEED,
            "sigma": SIGMA,
            "donors": DONORS,
            "cases_per_group": N * len(LAYOUTS),
            "strengths": strengths,
            "quiet_strengths": quiet,
            "scores": study,
        },
    )


if __name__ == "__main__":
    main()
