"""Draw restoration tradeoffs from the immutable native-query reductions."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score import ROOT, replay

LABELS = {
    "matched": ("Single covariance", "#88939b", "o"),
    "confirmed_diagonal": ("Confirmed diagonal", "#b56926", "^"),
    "donor_validated": ("Donor-validated covariance", "#137965", "s"),
    "validated_diagonal": ("Donor-validated diagonal", "#c34e75", "D"),
    "validated_transposed": ("Transposed prior", "#6f64a9", "v"),
    "donor_and_query": ("Donor and query check", "#2357b8", "P"),
}
METRICS = ("flat", "response", "increment")
SCALES = np.arange(0, 2.01, 0.4)


def main():
    binding = reference(ROOT / "evaluation.json")
    score = read_json(checked(binding))
    choices = read_json(checked(score["calibration"]))["settings"]["iso6400"]
    rows = [r for r in score["cases"] if r["case"]["partition"] == "fresh"]
    assert len(rows) == 32
    start = {m: replay.estimate(replay.arrays(rows, "parent", "fine", m), m, 0) for m in METRICS}
    curve = {}
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.4), layout="constrained")
    for mode, (title, color, marker) in LABELS.items():
        g = SCALES[:, None] * choices[mode]["quiet"]
        change = {
            m: replay.estimate(replay.arrays(rows, mode, "fine", m), m, g) - start[m]
            for m in METRICS
        }
        curve[mode] = {m: v.tolist() for m, v in change.items()}
        for ax, metric in zip(axes, ("response", "increment"), strict=True):
            ax.plot(change["flat"], change[metric], color=color, marker=marker, label=title)
    for ax, label in zip(
        axes,
        ("Fine response change (percentage points)", "Fine increment RMS change (DN16)"),
        strict=True,
    ):
        ax.set(xlabel="Fine flat RMS change (DN16)", ylabel=label)
        ax.grid(alpha=0.2)
        ax.axhline(0, color="#333333", linewidth=0.7)
    axes[0].legend(loc="upper left", fontsize=8, frameon=False)
    fig.suptitle("Fresh independent ISO6400 photos, relative to Corpus 100k")
    path = ROOT / "fresh-frontier.png"
    fig.savefig(path, dpi=150, facecolor="white")
    plt.close(fig)
    write_json(
        ROOT / "figure.json",
        {
            "driver": reference(__file__),
            "evaluation": binding,
            "scales": SCALES.tolist(),
            "image": reference(path),
            "curve": curve,
        },
    )


if __name__ == "__main__":
    main()
