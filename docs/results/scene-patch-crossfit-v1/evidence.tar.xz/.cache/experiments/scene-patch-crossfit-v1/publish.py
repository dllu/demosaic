"""Publish reviewed native comparisons and bind immutable research receipts."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import os
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native import CANDIDATE, ROOT, pixels
from score import EXTERNAL, OLD

REPO = ROOT.parents[2]
IMG = REPO / "docs/images" / ROOT.name
OUT = REPO / "docs/results" / ROOT.name
FILES = (
    "calibration.json",
    "evaluation.json",
    "ideal.json",
    "wires.json",
    "wire-tradeoff.json",
    "native/review.json",
    "wire-native.json",
    "figure.json",
    "sheets.json",
)


def keep(image, folder):
    original = checked(image)
    dest = IMG / folder / original.name
    shutil.copyfile(original, dest)
    assert reference(dest)["sha256"] == image["sha256"]
    return image | {"path": str(dest.relative_to(IMG))}


def board(record, folder):
    cells = pixels(record)
    assert all(p.shape == (160, 160, 3) for p in cells.values())
    return record | {"image": keep(record["image"], folder)}


def exact(record, folder, label):
    triplet = pixels(record["triplet"])
    compare = pixels(record["board"])
    assert list(triplet) == ["Noisy Malvar", label, "Exact GT"]
    assert all(np.array_equal(p, compare[k]) for k, p in triplet.items())
    return record | {k: board(record[k], folder) for k in ("board", "triplet")}


def main():
    refs = {Path(p).stem: reference(ROOT / p) for p in FILES}
    status = {k: read_json(checked(v)) for k, v in refs.items()}
    cal, evaluated, ideal, wires, wire_fit, native, wire, figure, sheets = (
        status[k]
        for k in (
            "calibration",
            "evaluation",
            "ideal",
            "wires",
            "wire-tradeoff",
            "review",
            "wire-native",
            "figure",
            "sheets",
        )
    )
    assert all(v["fitted"] == 0 for g in cal["settings"].values() for v in g.values())
    assert all(v["evaluation"] == refs["evaluation"] for v in (native, figure))
    assert evaluated["calibration"] == wires["calibration"] == refs["calibration"]
    assert wire_fit["original_replay"] == refs["wires"] and wire["source"] == refs["wire-tradeoff"]
    assert cal["kernel"] == ideal["model"] and sheets["review"] == refs["review"]
    assert len(native["exact"]) == 4 and len(wire["viewable"]) == 2 and len(native["standing"]) == 8
    assert sum(len(r["displays"]) for r in native["standing"]) == 12
    for b in sheets["views"].values():
        checked(b)
    fresh = read_json(checked(evaluated["fresh_parents"]))
    frozen = read_json(checked(fresh["plan"]))
    legacy = reference(ROOT / "legacy_patch_covariance.py")
    prior = read_json(checked(cal["earlier"]["confirmed-replay"]))
    assert legacy["sha256"] == prior["core"]["sha256"]
    assert len(fresh["rows"]) == 32 and frozen["parent_photo_visits_checked"] == 559808

    (IMG / "exact").mkdir(parents=True)
    (IMG / "wire").mkdir()
    (IMG / "standing").mkdir()
    native_artifacts = [exact(r, "exact", "Donor-validated covariance") for r in native["exact"]]
    wire_artifacts = [exact(r, "wire", "Donor and query check") for r in wire["viewable"]]
    cameras = []
    for row in native["standing"]:
        displays = []
        for d in row["displays"]:
            labels = pixels(d["board"]).keys()
            assert {
                "Noisy (Malvar)",
                "Corpus 100k",
                "V120 EMA",
                "ISO100 AHD reference",
                "Donor-validated covariance",
                "Donor and query check",
            } <= labels
            if row["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= labels
            displays.append(d | {"board": board(d["board"], "standing")})
        cameras.append(row | {"displays": displays})

    observations = {
        "natural": "Marktbreit preserves the beams while the smallest window and trim detail stays soft. The jet scene has clean sky color and rounded dark transitions. Both exact-flat centers appear smooth.",
        "wire": "The strip example keeps its strong parallel set, with weak crossing contrast below the exact target. The ellipse example has incomplete weak lines and looks close to the matched control.",
        "main": "The sky stays visually smooth. Coarse crossings are coherent, with soft fine bracing and leaf tips.",
        "fine_cab": "Both left crops remain largely unresolved. Transferred right diagonals remain clearest, with incomplete fine crossings in both displays and noise profiles.",
    }
    image_manifest = IMG / "manifest.json"
    write_json(
        image_manifest,
        {
            "weights": fresh["checkpoints"],
            "naturals": native_artifacts,
            "wire": wire_artifacts,
            "standing": cameras,
            "chart": keep(figure["image"], ""),
            "operating_point": native["operating_point"],
            "native_settings": native["settings"],
            "inspection": {
                "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                "assets": refs["sheets"],
                "notes": observations,
            },
        },
    )
    OUT.mkdir()
    evidence = OUT / "evidence.tar.xz"
    package = [
        *refs.values(),
        evaluated["fresh_parents"],
        fresh["plan"],
        frozen["driver"],
        frozen["fixture"],
        cal["kernel"],
        cal["basis_metrics"],
        legacy,
        *cal["earlier"].values(),
        wires["source"],
        wires["metric"],
        native["old_camera_review"],
        reference(image_manifest),
        reference(__file__),
        reference(REPO / "tests/test_scene_patch_covariance.py"),
        *[r["driver"] for r in status.values()],
    ]
    staged = EXTERNAL / "publication-evidence.tar.xz"
    members = {}
    with tarfile.open(staged, "x:xz", preset=4) as out:
        for bind in {v["path"]: v for v in package}.values():
            path = checked(bind)
            filename = (
                path.relative_to(REPO)
                if path.is_relative_to(REPO)
                else Path("external") / path.relative_to(EXTERNAL.parent)
            )
            out.add(path, arcname=filename.as_posix())
            members[filename.as_posix()] = bind["sha256"]
    with tarfile.open(staged, "r:xz") as inp:
        for file, digest in members.items():
            assert sha256(inp.extractfile(file).read()).hexdigest() == digest
    temporary = OUT / ".evidence.tar.xz"
    try:
        with staged.open("rb") as src, temporary.open("xb") as dest:
            shutil.copyfileobj(src, dest)
            dest.flush()
            os.fsync(dest.fileno())
        assert reference(temporary)["sha256"] == reference(staged)["sha256"]
        os.link(temporary, evidence)
    finally:
        temporary.unlink(missing_ok=True)

    write_json(
        OUT / "publication.json",
        {
            "study": ROOT.name,
            "weights": fresh["checkpoints"],
            "scope": "Frozen-weight inference. Two earlier natural test cohorts, 32 new photos, exact wires, and both native GFX100S reviews. No fixed 427 or measured CFA PSNR.",
            "native": reference(image_manifest),
            "archive": reference(evidence),
            "member_hashes": members,
            "receipts": refs,
            "fresh_plan": fresh["plan"],
            "fresh_parents": evaluated["fresh_parents"],
            "strengths": cal["settings"],
            "ideal": ideal["scores"],
            "natural": evaluated["summary"],
            "wire_matches": wire_fit["summary"],
            "wire_paired_differences": wire["comparison"],
            "time_seconds": {
                "fresh_parent_loop": fresh["seconds"],
                "calibration": cal["seconds"],
                "natural_replay": evaluated["seconds"],
                "wire_replay": wires["seconds"],
                "wire_tradeoff": wire_fit["time_seconds"],
            },
        },
    )


if __name__ == "__main__":
    main()
