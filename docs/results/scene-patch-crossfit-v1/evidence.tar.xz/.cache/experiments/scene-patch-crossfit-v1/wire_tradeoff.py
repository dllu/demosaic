"""Match observed wire-flat error with each complete geometry family held out."""

import numpy as np
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score import ROOT, MODES, deltas, evaluate, replay
from wires import WireMetric, summary

BUDGET = 0.10
RESPONSE = "weak_response_pp"
FLAT = "exact_flat_RMS_DN16"


def coefficients(row):
    fields, base, _ = replay.read_inputs(row)
    outputs, count = deltas(row, fields, base, validate_donors=True)
    older, _ = deltas(row, fields, base, validate_donors=False)
    outputs.update({k: v for k, v in older.items() if k in MODES})
    assert count == row["atlas"]
    with np.load(checked(row["input"]), allow_pickle=False) as f:
        data = fields | {k: f[k] for k in ("target", "support")}
    if row["geometry"]["family"] == "smooth-dip":
        data["support"] = np.ones_like(data["support"])
    metric = WireMetric(data, row["geometry"])
    base = base.astype(np.float64)
    b = metric(base)
    result = {}
    for mode, change in outputs.items():
        positive, negative = metric(base + change), metric(base - change)
        scores = {}
        for m, v in b.items():
            p, n = positive[m], negative[m]
            scores[m] = (
                [v, (p - n) / 2, 0.0]
                if m == RESPONSE
                else [v**2, (p**2 - n**2) / 2, (p**2 + n**2) / 2 - v**2]
            )
        result[mode] = scores
    return {"family": row["geometry"]["family"], "input": row["input"], "base": b, "terms": result}


def at_strength(row, mode, metric, gain):
    a, b, c = row["terms"][mode][metric]
    result = a + gain * (b + gain * c)
    return result if metric == RESPONSE else np.sqrt(max(0, result))


def fit(family, all_):
    calibration = [r for r in all_ if r["family"] != family]
    total = np.mean([r["base"][FLAT] for r in calibration])
    fitted = {}
    for mode in MODES:

        def excess(x):
            return np.mean([at_strength(r, mode, FLAT, x) for r in calibration]) - total - BUDGET

        gain = brentq(excess, 0, 0.8) if excess(0.8) > 0 else 0.8
        fitted[mode] = {"gain": float(gain), "fit_flat_increase": float(excess(gain) + BUDGET)}
    return fitted


def main():
    link = reference(ROOT / "wires.json")
    saved = read_json(checked(link))
    calibration = read_json(checked(saved["calibration"]))["settings"]["iso6400"]
    records, elapsed = evaluate(saved["rows"], coefficients)
    assert len(records) == 24 and len({r["family"] for r in records}) == 4
    max_diff = 0.0
    for old, dep in zip(saved["rows"], records, strict=True):
        for op in ("quiet", "response"):
            for mode in MODES:
                for metric, value in old["results"][op][mode].items():
                    actual = at_strength(dep, mode, metric, calibration[mode][op])
                    max_diff = max(max_diff, abs(actual - value))
    assert max_diff < 0.001
    folds = {k: fit(k, records) for k in sorted({r["family"] for r in records})}
    result = []
    for a, b in zip(saved["rows"], records, strict=True):
        by_mode = {
            mode: {m: at_strength(b, mode, m, folds[b["family"]][mode]["gain"]) for m in b["base"]}
            for mode in MODES
        }
        by_mode |= {"parent": b["base"], "v120": a["results"]["quiet"]["v120"]}
        result.append(b | {"results": {"matched-flat": by_mode}})
    write_json(
        ROOT / "wire-tradeoff.json",
        {
            "driver": reference(__file__),
            "original_replay": link,
            "quiet_budget_DN16": BUDGET,
            "time_seconds": elapsed,
            "max_replay_diff": max_diff,
            "gains": folds,
            "summary": summary(result),
            "cases": result,
        },
    )


if __name__ == "__main__":
    main()
