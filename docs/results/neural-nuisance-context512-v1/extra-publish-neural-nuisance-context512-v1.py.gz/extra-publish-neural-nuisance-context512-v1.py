"""Exact archive publication, after the complete neural-nuisance review."""
import gzip,html,shutil,sys,tarfile,io
from pathlib import Path
import numpy as np
from PIL import Image
from audit_checkpoint_pilot import crop
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
from demosaic.archive_metrics import noisy_malvar
R=Path.cwd();root=R/'.cache/experiments/neural-nuisance-context512-pilot-v1';docs=R/'docs/results/neural-nuisance-context512-v1';images=R/'docs/images/neural-nuisance-context512-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
assert read_json(root/'followup/result.json')['returncode']==0
plan=read_json(root/'plan.json');collection=read_json(root/'collection.json');records={r['id']:r for r in collection['rows']}
report=read_json(root/'native/report.json');base=read_json(root/'report/report.json');summary=read_json(root/'summary-review/summary.json')
docs.mkdir(exist_ok=False);images.mkdir(exist_ok=False);archives=[];figures=[];channels=0
def archive(source,name):
 source=Path(source);dest=docs/(name+'.gz');data=source.read_bytes();encoded=gzip.compress(data,mtime=0)
 with dest.open('xb')as f:f.write(encoded)
 assert gzip.decompress(dest.read_bytes())==data
 archives.append({'original':reference(source),'published':reference(dest),'decompressed_bytes_exact':True})
def copy_image(source,relative,metadata):
 dest=images/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(checked(source),dest);assert reference(dest)['sha256']==source['sha256'];figures.append({'original':source,'published':reference(dest),'relative':relative,'metadata':metadata})
for figure in report['figures']+report['stress_figures']+read_json(root/'extra-stress/report.json')['figures']:
 row=figure['source'];sample=row['sample'];roi=figure['ROI_xywh'];exposure=figure['display_exposure'];png=np.asarray(Image.open(checked(figure['image'])))
 with np.load(checked(row['arrays']),allow_pickle=False)as z:
  data={k:z[k][sample:sample+1]for k in ['wb','matrix','packed','colors']};noisy=z['noisy_rgb']if row['kind']=='mesh'else noisy_malvar(data)
 parent=np.load(checked(row['parent']))[sample:sample+1]
 for panel in figure['panels']:
  label=panel['label'];x,y,w,h=panel['xywh']
  if label=='512 analytic t2':value=np.load(checked(records[row['id']]['predictions']['conditional-local-t2']))[None]
  elif label=='512 neural t2':value=np.load(checked(records[row['id']]['predictions']['local-t2']))[None]
  elif label=='Noisy Malvar':value=noisy
  elif label in ['V120','V143']:value=parent
  else:
   original=np.asarray(Image.open(checked(figure['original_aggregation_board'])));np.testing.assert_array_equal(png[y:y+h,x:x+w],original[y:y+h,x:x+w]);channels+=h*w*3;continue
  expected=crop(value,data,roi,exposure);np.testing.assert_array_equal(png[y:y+h,x:x+w],expected);channels+=expected.size
 copy_image(figure['image'],('stress/'if 'selection'in figure else'matched/')+Path(figure['image']['path']).name,figure)
for case in ['iso400-index0008-role2','iso400-index0024-role2']:
 f=next(f for f in base['figures']if Path(f['image']['path']).stem==case+'-triplet');copy_image(f['image'],'triplets/'+Path(f['image']['path']).name,f)
for figure in summary['plots']:copy_image(figure,'plots/'+Path(figure['path']).name,{'kind':'fixed-threshold-tradeoff-plot'})
assert len(figures)==34
text='<!doctype html><meta charset="utf-8"><title>Neural nuisance reconstruction</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:28px 0;overflow:auto}img{max-width:none}</style><h1>Fixed analytic proposals with neural nuisance</h1><p>Native crop pixels are unresized; use browser zoom100%. Matched conditional analytic and neural-nuisance localt2 controls. Two-source adaptive development pilot, three noise priors. ISO100/AHD real references are qualitative, never exact GT; both cab JPEGs retained. Stress ROIs selected after inference by largest correction RMS, without reference. Plot pixels are charts.</p>'
for f in figures:
 name=html.escape(f['relative']);text+='<figure><figcaption>'+name+'</figcaption><a href="'+name+'"><img src="'+name+'"></a></figure>\n'
(images/'native-viewer.html').write_text(text)
for file in sorted(root.rglob('*')):
 if not file.is_file()or root/'work'in file.parents or file.suffix not in ['.json','.log','.py']:continue
 archive(file,'producer-'+str(file.relative_to(root)).replace('/','--'))
for file in [R/'.cache/neural-nuisance-tests-v1.log',R/'.cache/neural-nuisance-tests-v2.log',R/'.cache/neural-nuisance-input-audit-v1.log',Path(__file__),R/'scripts/audit_neural_nuisance_inputs.py',R/'.cache/extra-neural-context512-stress-v1.py',R/'scripts/compare_neural_nuisance_proposals.py',R/'.cache/neural-nuisance-tests-v3-fixed-proposals.log',R/'.cache/neural-nuisance-fixed-input-audit-v1.log']:
 archive(file,'extra-'+file.name)
files=[p for p in (root/'work').rglob('*.py')];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as tar:
 for p in sorted(files):
  data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(root/'work')));info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
compressed=gzip.compress(buffer.getvalue(),mtime=0);source_tar=docs/'executed-source.tar.gz';source_tar.write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz')as tar:
 for member in tar.getmembers():assert tar.extractfile(member).read()==(root/'work'/member.name).read_bytes()
write_json(root/'publication-prepared.json',{'archives':archives,'source_snapshot':reference(source_tar),'source_files_exact':len(files),'images':figures,'viewer':reference(images/'native-viewer.html'),'matched_stress_RGB_channels_exact':channels,'base_independent_audit':reference(root/'independent-audit.json'),'background_input_independent_audit':reference(root/'background-independent-audit.json'),'script':reference(__file__),'new_neural_forwards':0,'viewing':'pending; actual viewing receipt required before final publication','scope':'Exact source/receipt archive and native boards. Generic frozen reporter wording H1/aggregation is inherited; this experiment compares neural nuisance/conditional H1 with global masks, not phase aggregation or historical-mask equivalence.'})
print('prepared',len(figures),'images;',channels,'matched/stress exact channels; archives',len(archives),flush=True)
