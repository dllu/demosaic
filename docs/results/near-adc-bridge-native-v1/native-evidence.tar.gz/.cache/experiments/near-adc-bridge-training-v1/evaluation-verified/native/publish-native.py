"""Publish the complete near-ADC matched native report and machine evidence."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
report = read_json(root / "report/result.json")
summary = read_json(root / "report/native-summary.json")
actual = read_json(root / "report/actual-native-viewing.json")
audit = read_json(checked(summary["independent_audit"]))
assert len(actual["boards"]) == 26 and all(v["viewed"] for v in actual["boards"])
assert audit["status"] == "passed" and audit["counts"]["metric_rows"] == 384
assert audit["matched_previous_V120_and_long100k_EMA_predictions_bitexact"] == 220
images = repo / "docs/images/near-adc-bridge-native-v1"
out = repo / "docs/results/near-adc-bridge-native-v1"
images.mkdir()
out.mkdir()
asset = []
for role, items in (("board", report["boards"]), ("triplet", report["triplets"])):
    for item in items:
        source = checked(item["image"])
        dest = images / source.name
        shutil.copyfile(source, dest)
        assert reference(dest)["sha256"] == item["image"]["sha256"]
        asset.append({"id": item["id"], "role": role, "image": reference(dest), "provenance": item})
assert len(asset) == 48
write_json(
    images / "manifest.json",
    {
        "images": asset,
        "actual_viewing": reference(root / "report/actual-native-viewing.json"),
        "scope": "Fixed native comparisons and exact triplet subsets for all 110 retained input cases.",
    },
)
for src, name in [
    (root / "report/native-summary.json", "native-summary.json"),
    (root / "report/actual-native-viewing.json", "actual-native-viewing.json"),
    (checked(summary["independent_audit"]), "independent-audit.json"),
]:
    shutil.copyfile(src, out / name)
    assert reference(src)["sha256"] == reference(out / name)["sha256"]
patterns = {".py", ".json", ".log", ".csv", ".jsonl"}
files = [
    p
    for p in root.rglob("*")
    if p.is_file() and p.suffix in patterns and "__pycache__" not in p.parts
]
files.append(root.parent.parent / "independent-native-audit-verified.py")
archive = out / "native-evidence.tar.gz"
members = []
with (
    archive.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as gz,
    tarfile.open(fileobj=gz, mode="w") as tar,
):
    for path in sorted(files):
        name = str(path.relative_to(repo))
        members.append({**reference(path), "member": name})
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive) as tar:
    for row in members:
        assert hashlib.sha256(tar.extractfile(row["member"]).read()).hexdigest() == row["sha256"]
write_json(
    out / "publication.json",
    {
        "archive": reference(archive),
        "members": members,
        "all_archive_members_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "images": len(asset),
        "actual_native_boards_viewed": 26,
        "exact_existing_control_outputs": 220,
        "training_publication": reference(repo / "docs/results/near-adc-bridge-training-v1/completed-training.json"),
        "scope": "Completed retained native and material review. Targeted low-noise and fixed primary panels are separate.",
    },
)
print(len(members), len(asset))
