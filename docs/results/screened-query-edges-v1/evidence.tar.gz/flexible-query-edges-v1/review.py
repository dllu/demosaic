"""Audit the fixed-guide boundary replay, score it and render native comparisons."""

import importlib.util
from collections import Counter
from itertools import product
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from probe_flexible_query_edges import MODES, predict
from probe_local_phase_bounds import compare, fresh_structure, structure_module
from probe_surface_aggregation import field
from report_fold_support_pooling import ROI, evaluated, insert_camera_panels, measure
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "local-phase-bounds-v1/review.py"
spec = importlib.util.spec_from_file_location("closed_local_bound_review", OLD)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)


def read_task(label, plan_path):
    output = read_json(ROOT / f"{label}.json")
    assert checked(output["plan"]) == plan_path
    return output


def exact_copy(row, arrays):
    with np.load(checked(row["before"])) as f:
        for name in f.files:
            np.testing.assert_array_equal(arrays[name], f[name])
        return len(f.files)


def synth(done, plan, out, split):
    results, boards, cases, verified = [], [], [], 0
    guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
    offsets = (0, 1)
    modes = ("weighted-refit", "local-energy", *MODES)
    for row in done["rows"]:
        c, parent, gt, quiet, v = prior.read_case(row, split)
        verified += exact_copy(row, v)
        moments = {k: measure(parent, gt, quiet, p) for k, p in v.items()}
        nominal = plan["settings"][c["profile"]]
        for key in ("scene-curved2", "scene-curved4"):
            brute = prior.direct.direct(parent, gt, quiet, v[key], nominal["scale"])
            measured = evaluated(moments[key], nominal["scale"])
            for k, num in brute.items():
                if k == "background_quiet_mse":
                    continue
                np.testing.assert_allclose(
                    measured[k.replace("_mse", "_RMS_DN16")],
                    np.sqrt(num) if k.endswith("_mse") else num,
                    atol=2e-9,
                    rtol=2e-9,
                )
        cases.append({"id": row["id"], "profile": c["profile"], "moments": moments})
        if split != "synthetic" or c["profile"] != "iso400" or c["source"] not in (88, 89):
            continue
        with np.load(checked(c["sensor"])) as raw:
            ctx = {name: raw[name][2:3] for name in ("colors", "wb", "matrix")}
            ctx["packed"] = raw["packed"][2:3, :, 64:192, 64:192]
        cols = {
            "scene-weighted-refit": "Parallel steps",
            "scene-curved2": "Two smooth boundaries",
            "scene-curved4": "Four smooth boundaries",
            "exact-center-weighted-refit": "Exact guide parallel",
            "exact-center-curved4": "Exact guide four boundaries",
        }
        p = parent[2][ROI]
        pixels = [
            noisy_malvar(ctx)[0],
            p,
            *(p + nominal["scale"] * (v[k][2] - p) for k in cols),
            gt[2][ROI],
        ]
        boards.append(
            native_board(
                out,
                c["id"],
                pixels,
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": c["CFA"],
                    "noise": c["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": nominal,
                },
                labels=["Noisy Malvar", "V143 EMA", *cols.values(), "Exact GT"],
                triplet_indices=(0, 4, 7),
                contrast=5,
            )
        )
    for profile, setting in plan["settings"].items():
        rows = [r["moments"] for r in cases if r["profile"] == profile]
        for guide in guides:
            keys = [
                "parent",
                *(
                    field(guide, m, t)
                    for m, t in product(modes, offsets)
                    if field(guide, m, t) in rows[0]
                ),
            ]
            moments = {
                k: {n: np.mean([r[k][n] for r in rows], axis=0) for n in rows[0][k]} for k in keys
            }
            fixed = {k: evaluated(m, setting["scale"]) for k, m in moments.items()}
            ceiling = fixed[field(guide, "weighted-refit", 0)]["quiet_RMS_DN16"]
            results.append(
                {
                    "panel": split,
                    "profile": profile,
                    "guide": guide,
                    "count": len(rows),
                    "quiet_ceiling_DN16": ceiling,
                    "fixed": fixed,
                    "matched": prior.capped(moments, fixed, ceiling, setting["scale"]),
                }
            )
    return results, boards, verified


def real(done, plan, out):
    source = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    names = {
        "scene-weighted-refit": "Scene parallel",
        "scene-local-energy": "Scene local energy",
        "scene-curved2": "Scene two boundaries",
        "scene-curved4": "Scene four boundaries",
        "spectral-weighted-refit": "Spectra parallel",
        "spectral-curved2": "Spectra two boundaries",
        "spectral-curved4": "Spectra four boundaries",
    }
    results, verified = [], 0
    for row, old in zip(done["rows"], source, strict=True):
        key, s = row["id"], old["source"]
        assert key == old["id"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = s["query_box"]
        crop = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            values = dict(f)
        verified += exact_copy(row, values)
        with np.load(checked(s["query_arrays"])) as f:
            ctx = {n: f[n] for n in ("wb", "matrix")}
        exposure = old["display_exposure"]
        added = [
            (
                title,
                np.rint(
                    display(values[n][None], ctx, exposure=exposure)[0][crop].transpose(1, 2, 0)
                    * 255
                ).astype(np.uint8),
            )
            for n, title in names.items()
        ]
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        selected = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, panels = insert_camera_panels(
            out, key, old | {"panels": selected}, "V120 EMA", added
        )
        ax, ay, *_ = s["absolute_query_xywh"]
        results.append(
            {
                "id": key,
                "image": image,
                "panels": panels,
                "display_exposure": exposure,
                "noise": noise[key],
                "checkpoint": s["checkpoint"],
                "ROI_xywh": [x - qx + ax, y - qy + ay, w, h],
                "calibration": s["query_arrays"],
                "predictions": row["predictions"],
                "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
                "fits": row["flexible_edges"],
                "delta_RMS_DN16": {
                    name: float(
                        np.sqrt(np.mean((a[crop].astype(float) - values["parent"][crop]) ** 2))
                        * 65535
                    )
                    for name, a in values.items()
                },
            }
        )
    return results, verified


def null_summary(rows):
    styles = sorted({r["style"] for r in rows})
    if "two-rails" in styles:
        styles.append("all-rail")
    groups = {}
    for style in styles:
        pool = [
            r
            for r in rows
            if r["style"] == style or (style == "all-rail" and r["style"] != "sloped-flat")
        ]
        info = {}
        for key in pool[0]["metrics"]:
            v = [r["metrics"][key] for r in pool]
            info[key] = {
                "cases": len(v),
                "changed": sum(a["changed_pixels"] > 0 for a in v),
                "RMS_DN16": float(np.sqrt(np.mean([a["RMS_DN16"] ** 2 for a in v]))),
                "peak_DN16": max(a["max_abs_DN16"] for a in v),
            }
        edges = {}
        for arm in MODES:
            counts = []
            for r in pool:
                for folds in r["boundaries"][arm]:
                    counts.extend(
                        len(f[1]) if f is not None else 0 for f in folds["flexible_edges"]
                    )
            edges[arm] = dict(sorted(Counter(counts).items()))
        groups[style] = {"metrics": info, "fitted_flexible_edges": edges}
    return groups


def null_plate(rows, plan, out):
    row = max(
        (r for r in rows if r["style"] == "two-rails"),
        key=lambda r: r["metrics"]["null-weighted-refit"]["max_abs_DN16"],
    )
    recipe = structure_module(plan["structure"])
    truth = fresh_structure(row["style"], row["angle_radians"], *row["width_shift_level_height"])
    color = np.asarray(PATTERNS[row["CFA"]])
    quality = plan["profiles"][row["profile"]]
    rng = np.random.default_rng(np.random.SeedSequence(row["noise_seed"]))
    packed = recipe.corrupt(truth, color, rng, quality)
    guide = {"active": [True, True], "frequencies_xy": row["guide_frequencies_xy"]}
    from dataclasses import replace

    base = LocalWaveConfig(**plan["config"])
    cfg = {m: replace(base, background=n) for m, n in MODES.items()}
    level = plan["settings"][row["profile"]]["threshold"]
    out_new, _ = predict(truth, packed, color, guide, quality, recipe.QUERY, cfg, level)
    old, _ = prior_delivery(truth, packed, color, guide, quality, recipe.QUERY, base, level)
    old_f = old["null-weighted-refit"]
    clipped = compare(truth, old_f, old["null-tangent-predictive-gate"])["local-energy"]
    values = {
        "weighted-refit": (old_f, "Parallel nuisance"),
        "local-energy": (clipped, "Prior local energy"),
        "curved2": (out_new["curved2", 0], "Two boundaries"),
        "curved4": (out_new["curved4", 0], "Four boundaries"),
    }
    image = Image.new("RGB", (176 * len(values) + 8, 198), "#eee")
    d = ImageDraw.Draw(image)
    for i, (name, (v, label)) in enumerate(values.items()):
        q = np.max(np.abs(v[recipe.MEASURE].astype(float) - truth[recipe.MEASURE]) * 65535, axis=0)
        np.testing.assert_allclose(q.max(), row["metrics"][f"null-{name}"]["max_abs_DN16"])
        pixels = np.rint(np.clip(q / 64, 0, 1) * 255).astype(np.uint8)
        x = 8 + i * 176
        d.text((x, 5), label, fill="black")
        d.text((x, 185), f"Peak {q.max():.2f} DN16", fill="black")
        image.paste(Image.fromarray(pixels).convert("RGB"), (x, 22))
    p = out / "double-rail-correction.png"
    image.save(p)
    return {
        "image": reference(p),
        "profile": row["profile"],
        "trial": row["trial"],
        "scale_DN16": [0, 64],
        "ROI_xywh": [48, 48, 160, 160],
        "CFA": row["CFA"],
    }


def prior_delivery(rgb, packed, color, guide, noise, query, cfg, t):
    from probe_surface_aggregation import deliver

    return deliver(rgb, packed, color, {"null": guide}, noise, query, cfg, t)


def main():
    path = ROOT / "plan.json"
    plan = read_json(path)
    results = {
        label: read_task(label, path)
        for label in ("synthetic", "disjoint", "camera", "fresh", "retained")
    }
    out = ROOT / "review"
    out.mkdir()
    primary, boards, a = synth(results["synthetic"], plan, out, "synthetic")
    disjoint, _, b = synth(results["disjoint"], plan, out, "disjoint")
    camera, c = real(results["camera"], plan, out)
    scopes = {name: null_summary(results[name]["rows"]) for name in ("retained", "fresh")}
    write_json(
        out / "result.json",
        {
            "plan": reference(path),
            "producer": reference(__file__),
            "earlier_review": reference(OLD),
            "receipts": {name: reference(ROOT / f"{name}.json") for name in results},
            "seconds": {name: data["CPU_wall_seconds"] for name, data in results.items()},
            "results": primary + disjoint,
            "nulls": scopes,
            "boards": boards,
            "camera": camera,
            "rail_plate": null_plate(results["fresh"]["rows"], plan, out),
            "verified_arrays": a + b + c,
        },
    )


if __name__ == "__main__":
    main()
