"""Verify frozen controls and report fixed and quiet-matched guarded outputs."""

import importlib.util
from collections import Counter
from dataclasses import replace
from itertools import product
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from probe_flexible_query_edges import predict
from probe_local_phase_bounds import structure_module
from probe_screened_query_edges import ARMS
from probe_surface_aggregation import field
from report_fold_support_pooling import ROI, evaluated, insert_camera_panels, measure
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "flexible-query-edges-v1/review.py"
spec = importlib.util.spec_from_file_location("prior_flexible_review", OLD)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
PANELS = ("synthetic", "disjoint", "camera", "retained", "fresh", "replication", "sensitivity")


def exact_controls(row, before, array_key):
    count = 0
    with np.load(checked(row[array_key])) as now, np.load(checked(before[array_key])) as old:
        for key in now.files:
            if key in old:
                np.testing.assert_array_equal(now[key], old[key])
                count += 1
    return count


def summarize_synth(done, plan, out, split):
    old = read_json(checked(plan["curved_receipts"][split]))["rows"]
    guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
    cells, moments, verified = [], [], 0
    for row, before in zip(done["rows"], old, strict=True):
        assert row["id"] == before["id"]
        verified += exact_controls(row, before, "prediction")
        case, p, gt, quiet, v = prior.prior.read_case(row, split)
        m = {k: measure(p, gt, quiet, part) for k, part in v.items()}
        alpha = plan["settings"][case["profile"]]["scale"]
        for label in ("scene-curved4", "scene-screened"):
            exact = prior.prior.direct.direct(p, gt, quiet, v[label], alpha)
            result = evaluated(m[label], alpha)
            for key, value in exact.items():
                if key == "background_quiet_mse":
                    continue
                np.testing.assert_allclose(
                    result[key.replace("_mse", "_RMS_DN16")],
                    np.sqrt(value) if key.endswith("_mse") else value,
                    atol=2e-9,
                    rtol=2e-9,
                )
        moments.append((case["profile"], m))
        if split != "synthetic" or case["profile"] != "iso400" or case["source"] not in (88, 89):
            continue
        with np.load(checked(case["sensor"])) as f:
            ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
            ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
        names = {
            "scene-weighted-refit": "Parallel steps",
            "scene-curved4": "Curved boundaries",
            "scene-screened": "Screened curves",
            "exact-center-weighted-refit": "Exact guide parallel",
            "exact-center-curved4": "Exact guide curved",
            "exact-center-screened": "Exact guide screened",
        }
        parent = p[2][ROI]
        pixels = [
            noisy_malvar(ctx)[0],
            parent,
            *(parent + alpha * (v[k][2] - parent) for k in names),
            gt[2][ROI],
        ]
        cells.append(
            native_board(
                out,
                case["id"],
                pixels,
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": case["CFA"],
                    "noise": case["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": plan["settings"][case["profile"]],
                },
                labels=["Noisy Malvar", "V143 EMA", *names.values(), "Exact GT"],
                triplet_indices=(0, 4, 8),
                contrast=5,
            )
        )
    results = []
    for profile, setting in plan["settings"].items():
        group = [m for p, m in moments if p == profile]
        alpha = setting["scale"]
        for guide in guides:
            keys = [
                "parent",
                *(
                    field(guide, a, t)
                    for a, t in product(("weighted-refit", *ARMS), (0, 1))
                    if field(guide, a, t) in group[0]
                ),
            ]
            means = {
                k: {n: np.mean([r[k][n] for r in group], axis=0) for n in group[0][k]} for k in keys
            }
            fixed = {k: evaluated(v, alpha) for k, v in means.items()}
            limit = fixed[field(guide, "weighted-refit", 0)]["quiet_RMS_DN16"]
            results.append(
                {
                    "panel": split,
                    "guide": guide,
                    "profile": profile,
                    "count": len(group),
                    "quiet_ceiling": limit,
                    "fixed": fixed,
                    "matched": prior.prior.capped(means, fixed, limit, alpha),
                }
            )
    return results, cells, verified


def camera(done, plan, out):
    earlier = read_json(checked(plan["curved_receipts"]["camera"]))["rows"]
    base = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        f["board"]["id"]: f["noise"]
        for f in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    names = {
        "scene-weighted-refit": "Scene parallel",
        "scene-curved4": "Scene curved",
        "scene-screened": "Scene screened",
        "spectral-weighted-refit": "Spectra parallel",
        "spectral-curved4": "Spectra curved",
        "spectral-screened": "Spectra screened",
    }
    rows, verified = [], 0
    for row, previous, old in zip(done["rows"], earlier, base, strict=True):
        key, s = old["id"], old["source"]
        assert key == row["id"] == previous["id"]
        verified += exact_controls(row, previous, "predictions")
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = s["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            variants = dict(f)
        with np.load(checked(s["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = old["display_exposure"]
        extra = [
            (
                label,
                np.rint(
                    display(variants[k][None], ctx, exposure=exposure)[0][region].transpose(1, 2, 0)
                    * 255
                ).astype(np.uint8),
            )
            for k, label in names.items()
        ]
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            out, key, old | {"panels": panels}, "V120 EMA", extra
        )
        ax, ay, *_ = s["absolute_query_xywh"]
        rows.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "noise": noise[key],
                "display_exposure": exposure,
                "ROI_xywh": [x - qx + ax, y - qy + ay, w, h],
                "checkpoint": s["checkpoint"],
                "calibration": s["query_arrays"],
                "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
                "predictions": row["predictions"],
                "guide_fits": row["flexible_edges"],
                "delta_RMS_DN16": {
                    k: float(
                        np.sqrt(
                            np.mean((a[region].astype(float) - variants["parent"][region]) ** 2)
                        )
                        * 65535
                    )
                    for k, a in variants.items()
                },
            }
        )
    return rows, verified


def verify_nulls(rows, plan, label):
    if label == "replication":
        assert len(rows) == 48
        return
    previous = read_json(checked(plan["curved_receipts"][label]))["rows"]
    for row, old in zip(rows, previous, strict=True):
        for k in ("profile", "style", "trial", "noise_seed"):
            assert row[k] == old[k]
        for mode, values in row["metrics"].items():
            if mode in old["metrics"]:
                assert values == old["metrics"][mode]
        assert row["boundaries"]["curved4"] == old["boundaries"]["curved4"]


def null_summary(rows):
    classes = {r["style"] for r in rows}
    groups = {}
    for kind in [*sorted(classes), "straight", "complex"]:
        if kind == "straight":
            choices = {"step", "rail"}
        elif kind == "complex":
            choices = {"wedge", "bent-rail", "two-rails"}
        else:
            choices = {kind}
        pool = [r for r in rows if r["style"] in choices]
        if not pool:
            continue
        label = "null-parallel" if "null-parallel" in pool[0]["metrics"] else "null-weighted-refit"
        stats = {}
        for name, which in product((label, "null-curved4", "null-screened"), ("", "-strict")):
            key = name + which
            m = [r["metrics"][key] for r in pool]
            stats[key] = {
                "count": len(m),
                "changed": sum(d["changed_pixels"] > 0 for d in m),
                "pooled_RMS_DN16": float(np.sqrt(np.mean([d["RMS_DN16"] ** 2 for d in m]))),
                "peak_DN16": max(d["max_abs_DN16"] for d in m),
            }
        folds = Counter()
        for row in pool:
            screened = row["boundaries"]["screened"][0]
            scores = screened["flexible_screen"]
            shapes = screened["flexible_edges"]
            folds["total"] += len(scores)
            folds["accepted"] += sum(s["accepted"] for s in scores)
            folds["used"] += sum(g is not None for g in shapes)
            folds["hard-only positives"] += sum(
                bool(s["vs_hard"] is not None and s["vs_hard"] > 3 and not s["accepted"])
                for s in scores
            )
        groups[kind] = {"metrics": stats, "folds": dict(folds)}
    return groups


def render_null(rows, plan, out):
    recipe = structure_module(plan["structure"])
    base = LocalWaveConfig(**plan["config"])
    cfg = {"parallel": base, **{k: replace(base, background=v) for k, v in ARMS.items()}}
    from probe_local_phase_bounds import fresh_structure

    plates = []
    declarations = (
        (
            "straight-step",
            max(
                (r for r in rows if r["style"] == "step"),
                key=lambda r: (
                    r["metrics"]["null-curved4"]["max_abs_DN16"]
                    - r["metrics"]["null-screened"]["max_abs_DN16"]
                ),
            ),
            24.0,
        ),
        (
            "double-rail",
            max(
                (r for r in rows if r["style"] == "two-rails"),
                key=lambda r: r["metrics"]["null-parallel"]["max_abs_DN16"],
            ),
            64.0,
        ),
    )
    for ident, r, span in declarations:
        build = recipe.construct if r["style"] == "step" else fresh_structure
        truth = build(r["style"], r["angle_radians"], *r["width_shift_level_height"])
        cfa = np.asarray(PATTERNS[r["CFA"]])
        noise = plan["profiles"][r["profile"]]
        rng = np.random.default_rng(np.random.SeedSequence(r["noise_seed"]))
        pixels = recipe.corrupt(truth, cfa, rng, noise)
        guide = {"active": [True, True], "frequencies_xy": r["guide_frequencies_xy"]}
        out_img, _ = predict(
            truth,
            pixels,
            cfa,
            guide,
            noise,
            recipe.QUERY,
            cfg,
            plan["settings"][r["profile"]]["threshold"],
        )
        arm_labels = {
            "parallel": "Parallel waves",
            "curved4": "Curved boundaries",
            "screened": "Screened curves",
        }
        image = Image.new("RGB", (176 * len(arm_labels) + 8, 198), "#eee")
        draw = ImageDraw.Draw(image)
        for i, (arm, label) in enumerate(arm_labels.items()):
            d = np.max(
                np.abs(out_img[arm, 0][recipe.MEASURE].astype(float) - truth[recipe.MEASURE])
                * 65535,
                axis=0,
            )
            np.testing.assert_allclose(d.max(), r["metrics"][f"null-{arm}"]["max_abs_DN16"])
            value = np.rint(np.clip(d / span, 0, 1) * 255).astype(np.uint8)
            x = 8 + 176 * i
            draw.text((x, 5), label, fill="black")
            draw.text((x, 185), f"Peak {d.max():.2f} DN16", fill="black")
            image.paste(Image.fromarray(value).convert("RGB"), (x, 22))
        path = out / f"{ident}-residual.png"
        image.save(path)
        plates.append(
            {
                "image": reference(path),
                "id": ident,
                "profile": r["profile"],
                "trial": r["trial"],
                "CFA": r["CFA"],
                "ROI_xywh": [48, 48, 160, 160],
                "scale_DN16": [0, span],
            }
        )
    return plates


def main():
    plan_path = ROOT / "plan.json"
    plan = read_json(plan_path)
    stages = {p: read_json(ROOT / f"{p}.json") for p in PANELS}
    assert all(checked(v["plan"]) == plan_path for v in stages.values())
    out = ROOT / "review"
    out.mkdir()
    primary, boards, a = summarize_synth(stages["synthetic"], plan, out, "synthetic")
    other, _, b = summarize_synth(stages["disjoint"], plan, out, "disjoint")
    real, c = camera(stages["camera"], plan, out)
    nulls = {}
    for label in ("retained", "fresh", "replication"):
        cases = stages[label]["rows"]
        verify_nulls(cases, plan, label)
        nulls[label] = null_summary(cases)
    write_json(
        out / "result.json",
        {
            "plan": reference(plan_path),
            "producer": reference(__file__),
            "earlier_review": reference(OLD),
            "stages": {k: reference(ROOT / f"{k}.json") for k in stages},
            "seconds": {
                k: v["CPU_wall_seconds"] for k, v in stages.items() if "CPU_wall_seconds" in v
            },
            "results": primary + other,
            "camera": real,
            "boards": boards,
            "nulls": nulls,
            "plates": render_null(stages["replication"]["rows"], plan, out),
            "verified_arrays": a + b + c,
        },
    )


if __name__ == "__main__":
    main()
