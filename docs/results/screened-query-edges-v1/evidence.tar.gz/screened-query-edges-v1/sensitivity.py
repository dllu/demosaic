"""Replay known-center weak wires beside rails with the nested background screen."""

import importlib.util
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from probe_flexible_query_edges import predict
from probe_local_phase_bounds import structure_module

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "flexible-query-edges-v1/sensitivity.py"
spec = importlib.util.spec_from_file_location("declared_rail_sensitivity", OLD)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    path = ROOT / "plan.json"
    plan = read_json(path)
    recipe = structure_module(plan["structure"])
    cfg = replace(LocalWaveConfig(**plan["config"]), background="screened_curved4_step")
    source_path = checked(plan["curved_receipts"]["sensitivity"])
    retained = read_json(source_path)
    original = [
        r
        for r in read_json(checked(retained["source"]))["rows"]
        if r["style"] in ("bent-rail", "two-rails")
    ]
    rows = []
    for i, (case, previous) in enumerate(zip(original, retained["rows"], strict=True)):
        profile = case["profile"]
        noise, setting = plan["profiles"][profile], plan["settings"][profile]
        assert i == previous["case"] and case["style"] == previous["style"]
        parent, strong, both, frequencies, quiet = source.targets(case)
        np.testing.assert_array_equal(frequencies, previous["wire_frequency"])
        colors = np.asarray(PATTERNS[case["CFA"]])
        guide = {"active": [True, True], "frequencies_xy": frequencies.tolist()}
        fitted = []
        scores = []
        for role, signal in enumerate((strong, both)):
            rng = np.random.default_rng(np.random.SeedSequence([source.SEED, 1, i, role]))
            pixels = recipe.corrupt(signal, colors, rng, noise)
            result, witness = predict(
                parent,
                pixels,
                colors,
                guide,
                noise,
                recipe.QUERY,
                {"screened": cfg},
                setting["threshold"],
            )
            fitted.append(result)
            scores.append(witness)
        truth = (both.astype(float) - strong).ravel()
        norm = truth @ truth
        metrics = dict(previous["metrics"])
        for stop in (0, 1):
            image = fitted[1]["screened", stop].astype(float)
            correction = setting["scale"] * (image - fitted[0]["screened", stop]).ravel()
            quiet_error = setting["scale"] * (image[:, quiet] - parent[:, quiet])
            metrics[f"screened{'-strict' if stop else ''}"] = {
                "weak_projection": float(correction @ truth / norm),
                "increment_RMS_DN16": float(np.sqrt(np.mean((correction - truth) ** 2)) * 65535),
                "quiet_RMS_DN16": float(np.sqrt(np.mean(quiet_error**2)) * 65535),
            }
        rows.append(previous | {"metrics": metrics, "screens": scores})
        print(profile, case["style"], case["trial"], flush=True)
    assert len(rows) == 16
    write_json(
        ROOT / "sensitivity.json",
        {
            "plan": reference(path),
            "producer": reference(__file__),
            "source": reference(source_path),
            "target_recipe": reference(OLD),
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
