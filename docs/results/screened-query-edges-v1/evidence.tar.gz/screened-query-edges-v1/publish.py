"""Publish the measured nested-screen replay and inspected native crops."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
review = read_json(root / "review/result.json")
sensitivity = read_json(checked(review["stages"]["sensitivity"]))
assert len(review["boards"]) == 2 and len(review["camera"]) == 8 and len(review["plates"]) == 2
assert review["verified_arrays"] == 728
assert len(sensitivity["rows"]) == 16
for stage, count in (
    ("synthetic", 16),
    ("disjoint", 16),
    ("camera", 8),
    ("retained", 36),
    ("fresh", 32),
    ("replication", 48),
):
    assert len(read_json(checked(review["stages"][stage]))["rows"]) == count
images.mkdir()
results.mkdir()


def adopt(binding):
    source = checked(binding)
    out = images / source.name
    shutil.copyfile(source, out)
    assert reference(out)["sha256"] == binding["sha256"]
    return out.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Ten native comparison boards, two 100% triplets and two native-pixel residual boards inspected. "
        "AHD and cab camera JPEGs are independent qualitative references.",
        "synthetic": [
            r | {key: r[key] | {"file": adopt(r[key]["image"])} for key in ("board", "triplet")}
            for r in review["boards"]
        ],
        "camera": [
            {k: v for k, v in r.items() if k != "delta_RMS_DN16"}
            | {
                "file": adopt(r["image"]),
                "CFA": "RGGB",
                "reference": "DSCF3880 ISO100 AHD"
                if r["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and DSCF3842/DSCF3835 camera JPEGs",
            }
            for r in review["camera"]
        ],
        "residuals": [r | {"file": adopt(r["image"])} for r in review["plates"]],
    },
)
summary = results / "summary.json"
scores = {}
for profile in ("iso400", "iso6400"):
    rows = [r for r in sensitivity["rows"] if r["profile"] == profile]
    scores[profile] = {}
    for arm in rows[0]["metrics"]:
        columns = {
            k: np.asarray([r["metrics"][arm][k] for r in rows]) for k in rows[0]["metrics"][arm]
        }
        scores[profile][arm] = {
            k: float(np.sqrt(np.mean(v**2)) if k.endswith("RMS_DN16") else v.mean())
            for k, v in columns.items()
        }
write_json(
    summary,
    {
        "plan": review["plan"],
        "stages": review["stages"],
        "seconds": review["seconds"],
        "verified_arrays": review["verified_arrays"],
        "results": review["results"],
        "nulls": review["nulls"],
        "rail_sensitivity": {"source": review["stages"]["sensitivity"], "scores": scores},
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "delta_RMS_DN16", "checkpoint", "noise")}
            for r in review["camera"]
        ],
    },
)
earlier = root.parent / "flexible-query-edges-v1"
members = {
    root: [
        "plan.json",
        *(f"{k}.json" for k in review["stages"]),
        *(f"{k}.log" for k in review["stages"]),
        "tests.log",
        "sensitivity.py",
        "review.py",
        "review.log",
        "review/result.json",
        "publish.py",
        "work/src/demosaic/flexible_edge.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/scripts/probe_flexible_query_edges.py",
        "work/scripts/probe_screened_query_edges.py",
    ],
    earlier: ["review.py", "sensitivity.py", "sensitivity.json", "fresh.json", "retained.json"],
    root.parent / "local-phase-bounds-v1": ["review.py"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            p = folder / name
            entry = bundle.gettarinfo(str(p), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with p.open("rb") as f:
                bundle.addfile(entry, f)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "rail_residuals_viewed": 2,
        "new_checkpoint": None,
    },
)
