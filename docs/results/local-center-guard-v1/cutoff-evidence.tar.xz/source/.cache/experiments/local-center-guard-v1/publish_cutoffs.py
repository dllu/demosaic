"""Publish the sensitivity sweep and fixed-cutoff native review."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
OUT = Path("/mnt/external/demosaic") / HERE.name
RESULTS = REPO / "docs/results" / OUT.name
ASSETS = REPO / "docs/assets" / OUT.name


def main():
    base = read_json(RESULTS / "publication.json")
    ref = reference(OUT / "cutoff-and-native.json")
    sweep = read_json(checked(ref))
    assert sweep["methods"] == base["exact_and_GFX"]
    exact = [(r["native"][k]["image"], size) for r in sweep["results"]["confirmation"]["rows"] if "native" in r
             for k, size in (("triplet", 3), ("board", 6))]
    real = [(v["image"], v["columns"]) for r in sweep["standing"] for v in r["native"]]
    assert len(exact) == 4 and len(real) == 12
    archive = RESULTS / "cutoff-evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=3) as bundle:
        bundle.add(checked(ref), arcname="receipts/cutoff-and-native.json", recursive=False)
        for path in (Path(__file__), checked(sweep["driver"])):
            bundle.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
    images = []
    for item, frames in exact + real:
        source = checked(item)
        with Image.open(source) as pic:
            assert pic.size == (8 + frames*168, 192)
        target = ASSETS / source.name
        shutil.copyfile(source, target)
        assert reference(target)["sha256"] == item["sha256"]
        images.append({"path": str(target.relative_to(REPO)), "sha256": item["sha256"]})
    write_json(RESULTS / "cutoffs.json", {
        "scope": "Exploratory cutoff sensitivity holding the broad coefficient and 32px support geometry fixed.",
        "base_publication": reference(RESULTS / "publication.json"), "receipt": ref,
        "archive": {"path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "summary": {k: {"eligible": v["intact_role_eligible"], "cutoffs": v["summary"]}
                    for k, v in sweep["results"].items()},
        "matched_response": sweep["matched_response"],
        "standing_RGB_RMS_DN16": {r["id"]: r["RMS_DN16"] for r in sweep["standing"]},
        "images": images,
    })


if __name__ == "__main__":
    main()
