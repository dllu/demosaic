"""Measure the fixed central-evidence sensitivity curve without varying the fit."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from score_center_guard import BOARD_IDS, OUT, display, frozen_inputs, native_board, noisy_malvar, section
from center_guard import CenterGuard
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from evaluate_ring import ABSOLUTE, FALSE, FLAT, GAP, LENGTH, ROI, WireFundamental, arrays, coefficients, interval, response_match, source_bootstrap, support_for_scoring
from ring_refit import EDGE, GAIN, OFFSET, OUTER, TAPER, WIDTH, unpack


CUTOFFS = (0., 1.5, 3., 6.)


def nom_truth(nomination, geometry):
    freq = np.array(geometry["frequency"])
    # Nominations have positive horizontal frequency. A conjugate sign
    # describes the same real-valued carrier.
    dist = np.minimum(np.linalg.norm(nomination[:, None] - freq, axis=-1),
                      np.linalg.norm(nomination[:, None] + freq, axis=-1))
    where = dist.argmin(axis=0)
    if set(where) != {0, 1} or np.any(dist[where, np.arange(2)] > .025):
        return None
    return where[1]


def apply(parent, scene, rectangle, frequency, profile, wb, matrix, geo, support):
    out = {str(c): section(parent, *ROI) for c in CUTOFFS}
    counts = {str(c): {"passes": [0, 0], "weak_passes": {k: 0 for k in ("intact", "gap", "boundary")}}
              for c in CUTOFFS}
    totals = dict.fromkeys(("intact", "gap", "boundary"), 0)
    if frequency is None:
        return out, counts, totals
    x, y, _, _ = rectangle
    weak = None if geo is None else nom_truth(frequency, geo)
    fit = CenterGuard(np.array(profile["colors"]), x, y, frequency)
    raw = unpack(scene)
    p = section(parent, *ROI, padding=OFFSET)
    fields = np.zeros((len(CUTOFFS), ROI[3], ROI[2]))
    mass = np.zeros((ROI[3], ROI[2]))
    for dy in range(0, ROI[3] - WIDTH + 1, WIDTH//2):
        for dx in range(0, ROI[2] - WIDTH + 1, WIDTH//2):
            a, b = x + dx - OFFSET, y + dy - OFFSET
            tile = raw[b:b+OUTER, a:a+OUTER].astype(np.float64)
            (coef_a, score_a), (coef_b, score_b) = [
                fit.fold(tile, fold, profile["shot"], profile["read"])["guarded"] for fold in (0, 1)
            ]
            measured = (coef_a + coef_b) / 2
            old = (fit.outer_parent_fit @ p[1, dy:dy+OUTER, dx:dx+OUTER].ravel()).reshape(2, 2)
            if weak is not None:
                tile_support = support[dy:dy+WIDTH, dx:dx+WIDTH]
                category = "gap" if np.all(tile_support == 0) else "intact" if np.all(tile_support > 0) else "boundary"
                totals[category] += 1
            sl = np.s_[dy:dy+WIDTH, dx:dx+WIDTH]
            for j, cutoff in enumerate(CUTOFFS):
                delta = np.maximum(0., np.minimum(score_a, score_b) - cutoff)
                if cutoff:
                    factor = delta / (delta + cutoff)
                else:
                    factor = delta > 0
                correction = (measured - old) * factor[:, None]
                length = np.linalg.norm(measured, axis=1)
                norm = np.linalg.norm(correction, axis=1).clip(min=1e-12)
                correction *= np.minimum(1., length / norm)[:, None]
                fields[j][sl] += np.sum(fit.wave * correction[None, None], axis=(2, 3)) * TAPER
                rec = counts[str(cutoff)]
                rec["passes"] = (np.array(rec["passes"]) + (delta > 0)).tolist()
                if weak is not None and delta[weak] > 0:
                    rec["weak_passes"][category] += 1
            mass[sl] += TAPER
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    for cutoff, field in zip(CUTOFFS, fields, strict=True):
        delta = field / np.maximum(.02, mass) * EDGE[:, None] * EDGE[None, :]
        out[str(cutoff)] = out[str(cutoff)] + (GAIN * (neutral / neutral[1])[:, None, None] * delta).astype(parent.dtype)
    return out, counts, totals


def examine(row, profile, expected, checkpoint, dest):
    f = frozen_inputs(row)
    values, scene, parent, roi = (f[n] for n in ("input", "scene", "parent", "phase_correction_roi"))
    sharp = arrays(f["case"]["inputs"]["0.0"])
    mask = support_for_scoring(values["support"])
    geometry = f["case"]["fixture"]["geometry"]
    absolute = WireFundamental(sharp | {"support": mask}, geometry)
    metric = WireFundamental(values | {"support": mask}, geometry)
    poses = {str(c): parent.copy() for c in CUTOFFS}
    counts, eligible = [], []
    for i, sample in enumerate(values["packed"]):
        scene[f["cut"]] = sample
        nomination = _spacing(scene, values["colors"], roi[0], roi[1])
        corrected, active, total = apply(
            parent[i], scene, roi, nomination, profile | {"colors": values["colors"]},
            values["wb"], values["matrix"], geometry, section(mask, *ROI),
        )
        counts.append(active)
        eligible.append(total)
        for arm, im in corrected.items():
            section(poses[arm][i], *ROI)[:] = im
    def measure(v):
        return metric(v) | {ABSOLUTE: absolute(v)[LENGTH]}

    measurements = {k: measure(v) for k, v in poses.items()}
    assert measurements["6.0"] == expected["scores"]["guarded"]
    assert all(activity["6.0"]["passes"] == f["guarded"] for activity, f in zip(counts, expected["active"], strict=True))
    key = f["case"]["id"]
    result = {
        "id": key, "family": geometry["family"], "scores": measurements, "counts": counts, "eligible": eligible,
        "response_balance": coefficients(parent, poses, measure) | {
            "broad": expected["response_balance"]["broad"],
        },
    }
    if key in BOARD_IDS:
        camera = {n: values[n][None] for n in ("colors", "wb", "matrix")}
        camera["packed"] = values["packed"][:1]
        frames = [noisy_malvar(camera)[0], parent[0], *(poses[c][0] for c in ("1.5", "3.0", "6.0")),
                  values["target"][0]]
        result["native"] = native_board(
            dest, key + "-cutoffs", frames, camera, {
                "input": row["input"], "fixture": expected["fixture"], "checkpoint": checkpoint,
                "optical_sigma": .85, "noise": profile, "query": [128, 128, 256, 256],
            }, labels=["Noisy Malvar", "Local 50k", "Center 1.5", "Center 3", "Center 6", "Exact GT"],
            triplet_indices=(0, 3, 5),
        )
    return result


def standing(result, dest):
    payload = read_json(checked(result["standing"]["fixed_review"]))
    rows = []
    old_rows = {r["id"]: r for r in result["standing"]["rows"]}
    for row in payload["standing"]:
        rid = row["id"]
        f = arrays(row["input"])
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(row["local_ROI"])
        raw, colors, white, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        peaks = _spacing(raw, colors, *roi[:2])
        # Apply the same fixed 160px delivery with coordinates in this GFX tile.
        y0, x0 = roi[1]-ROI[1], roi[0]-ROI[0]
        p_local = p[..., y0:y0+256, x0:x0+256]
        assert p_local.shape == (3, 256, 256)
        newer, _, _ = apply(
            p_local, raw, roi, peaks, row["noise"] | {"colors": colors}, white, matrix,
            None, None,
        )
        checkpoint = payload["checkpoints"]["local50k"]
        parent = section(p, *roi)
        rms = {k: float(np.sqrt(np.mean((value.astype(float) - parent)**2))*65535) for k, value in newer.items()}
        assert rms["6.0"] == old_rows[rid]["RGB_RMS_DN16"]["guarded"]
        views = []
        for prior in old_rows[rid]["native"]:
            with Image.open(checked(prior["image"])) as img:
                unchanged = np.asarray(img).copy()
            exp = prior["exposure"]
            old_columns = prior["columns"]
            frames = []
            for column in old_columns:
                name = column["name"]
                x, y, w, h = column["PNG_xywh"]
                if name == "Center check":
                    frames.extend((f"Center cutoff {k}", display(newer[k], white, matrix, exp))
                                  for k in ("1.5", "3.0", "6.0"))
                if name == "Center amplitude":
                    continue
                if name != "Center check":
                    frames.append((name, unchanged[y:y+h, x:x+w]))
            image = Image.new("RGB", (8 + 168*len(frames), 192), "#eeeeee")
            draw = ImageDraw.Draw(image)
            for i, (name, pixels) in enumerate(frames):
                x = 8+168*i
                image.paste(Image.fromarray(pixels), (x, 24))
                draw.text((x, 5), name, fill="black")
            path = dest / f"{rid}-x{exp:g}-cutoffs.png"
            image.save(path)
            views.append({"image": reference(path), "exposure": exp, "columns": len(frames)})
        rows.append({"id": rid, "RMS_DN16": rms, "native": views, "checkpoint": checkpoint})
    return rows

def main():
    torch.set_num_threads(2)
    start = time.monotonic()
    dest = OUT / "cutoff-native"
    dest.mkdir(exist_ok=True)
    reference_methods = reference(OUT / "result.json")
    earlier = read_json(checked(reference_methods))
    proof = read_json(checked(earlier["proof"]))
    all_results = {}
    for partition, group in proof["panels"].items():
        compared = {r["id"]: r for r in earlier["exact"][partition]["rows"]}
        rows = [examine(r, group["profile"], compared[r["case"]["id"]], proof["checkpoint"], dest)
                for r in group["rows"]]
        fields = (ABSOLUTE, GAP, FALSE, FLAT)
        summary = {}
        for c in map(str, CUTOFFS):
            per_arm = {k: [r["scores"][c][k] - compared[r["id"]]["scores"]["parent"][k] for r in rows
                           if k in r["scores"][c]] for k in fields}
            summary[c] = {
                "mean_difference_versus_parent": {k: float(np.mean(v)) for k, v in per_arm.items()},
                "flat_sources_with_passes": sum(any(r["counts"][3][c]["passes"]) for r in rows),
                "intact_direction_2_passes": sum(r["counts"][0][c]["passes"][1] for r in rows),
                "intact_role_nominal_weak_passes": {k: sum(r["counts"][0][c]["weak_passes"][k] for r in rows)
                                                      for k in ("intact", "gap", "boundary")},
            }
        all_results[partition] = {
            "rows": rows, "summary": summary,
            "intact_role_eligible": {k: sum(r["eligible"][0][k] for r in rows)
                                     for k in ("intact", "gap", "boundary")},
        }
    previous, confirmation = (all_results[k]["rows"] for k in ("previous", "confirmation"))
    matching = {c: response_match(previous, confirmation, ("broad", c), source_bootstrap, interval)
                for c in ("1.5", "3.0")}
    write_json(OUT / "cutoff-and-native.json", {"driver": reference(__file__), "methods": reference_methods,
              "matched_response": matching, "standing": standing(earlier, dest),
              "analysis": "Fixed 64px estimate and 32px support. Positive score gate is hard at zero.",
              "results": all_results, "seconds": time.monotonic() - start})


if __name__ == "__main__":
    main()
