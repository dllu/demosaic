"""Score the center guard with fixed reconstruction geometry and Bayer inputs."""

from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image, ImageDraw
import torch

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
EXTERIOR = OUT.with_name("local-exterior-phase-transfer-v1")
sys.path.insert(0, str(HERE.with_name(EXTERIOR.name)))

from center_guard import VENTURES, correct, verify_folds
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers
from evaluate_ring import (
    ABS, ABSOLUTE, BOARD_IDS, FALSE, FIXED, FLAT, GAP, LENGTH, ROI, WireFundamental,
    arrays, coefficients, display, frozen_inputs, interval, native_board, response_match,
    source_bootstrap, support_for_scoring,
)
from ring_refit import GAIN, OFFSET, THRESHOLD


LABELS = {
    "parent": "Local 50k",
    "local64": "Existing 64px",
    "broad": "Broad evidence",
    "guarded": "Center check",
    "phase_only": "Center amplitude",
}
METHODS = ("local64", *VENTURES)
FIELDS = (LENGTH, ABSOLUTE, ABS, GAP, FALSE, FLAT)


def section(value, x, y, w, h, padding=0):
    return value[..., y-padding:y+h+padding, x-padding:x+w+padding]


def correction(original, scene, colors, roi, local, profile, white, matrix):
    current = section(original, *local)
    context = section(original, *local, padding=OFFSET)
    peaks = _spacing(scene, colors, roi[0], roi[1])
    restored, counts = correct(current, context, scene, colors, roi, peaks, profile, white, matrix)
    baseline = refine_raw_mesh_carriers(
        current, scene, colors, roi, shot=profile["shot"], read=profile["read"],
        white_balance=white, camera_to_srgb=matrix,
    )
    return restored | {"local64": baseline}, counts, None if peaks is None else peaks.tolist()


def exact_case(row, group):
    fixture = frozen_inputs(row)
    f, parent, case = (fixture[k] for k in ("input", "parent", "case"))
    scene, roi = (fixture[k] for k in ("scene", "phase_correction_roi"))
    records = {k: parent.copy() for k in METHODS}
    active, frequencies = [], []
    for i, sample in enumerate(f["packed"]):
        scene[fixture["cut"]] = sample
        views, counts, geometry = correction(
            parent[i], scene, f["colors"], roi, ROI, group["profile"], f["wb"], f["matrix"],
        )
        active.append(counts)
        frequencies.append(geometry)
        for key, value in views.items():
            section(records[key][i], *ROI)[:] = value

    sharp = arrays(case["inputs"]["0.0"])
    support = support_for_scoring(f["support"])
    np.testing.assert_array_equal(sharp["support"], f["support"])
    geometry = case["fixture"]["geometry"]
    target = WireFundamental(sharp | {"support": support}, geometry)
    operator = WireFundamental(f | {"support": support}, geometry)

    def measure(value):
        return operator(value) | {ABSOLUTE: target(value)[LENGTH]}

    outputs = {"parent": parent} | records
    receipt = {
        "id": case["id"], "fixture": case["fixture"], "inputs": row["input"], "parent": row["output"],
        "family": geometry["family"], "scores": {k: measure(v) for k, v in outputs.items()},
        "active": active, "spacing_by_role": frequencies,
        "response_balance": coefficients(parent, records, measure),
        "clean_fundamental_RMS_DN16": float(np.sqrt(target.clean_norm / target.intact.sum()) * 65535),
    }
    return f, outputs, receipt


def paired(rows):
    rng = np.random.default_rng(202611200101)
    order = sorted(rows, key=lambda r: r["clean_fundamental_RMS_DN16"])
    suites = {"all": rows, "faintest_half": order[:len(order)//2]}
    result = {}
    for cohort, subjects in suites.items():
        summary = {}
        for key in FIELDS:
            group = [r for r in subjects if key in r["scores"]["parent"]]
            draw = source_bootstrap(group, rng)
            series = {k: np.array([r["scores"][k][key] for r in group])[draw].mean(1) for k in LABELS}
            summary[key] = {
                "n": len(group), "parent": interval(series["parent"]),
                "versus_parent": {k: interval(series[k] - series["parent"]) for k in METHODS},
                "versus_broad": {k: interval(series[k] - series["broad"]) for k in METHODS if k != "broad"},
            }
        result[cohort] = summary
    return result


def bench(proof, old):
    dest = OUT / "exact"
    dest.mkdir(exist_ok=True)
    panels = {}
    for name, group in proof["panels"].items():
        rows = []
        controls = {r["id"]: r for r in old["exact"][name]["rows"]}
        for row in group["rows"]:
            f, output, record = exact_case(row, group)
            key = record["id"]
            saved = controls[key]["scores"]
            assert record["scores"]["parent"] == saved["parent"]
            assert record["scores"]["local64"] == saved["local64"]
            if key in BOARD_IDS:
                camera = {n: f[n][None] for n in ("colors", "wb", "matrix")}
                camera["packed"] = f["packed"][:1]
                frames = [noisy_malvar(camera)[0], *(output[k][0] for k in LABELS), f["target"][0]]
                record["native"] = native_board(
                    dest, key, frames, camera, {
                        "id": key, "input": row["input"], "fixture": record["fixture"],
                        "query": [128, 128, 256, 256], "noise": group["profile"],
                        "checkpoint": proof["checkpoint"], "optical_sigma": .85,
                    }, labels=["Noisy Malvar", *LABELS.values(), "Exact GT"], triplet_indices=(0, 4, 6),
                )
            rows.append(record)
            if len(rows) % 8 == 0:
                print("Exact", name, len(rows), flush=True)
        panels[name] = {"input_source": group["source"], "rows": rows, "summary": paired(rows)}
    return panels


def standing(proof, old):
    source = reference(FIXED)
    fixed = read_json(checked(source))
    assert fixed["checkpoints"]["local50k"] == proof["checkpoint"]
    dest = OUT / "standing"
    dest.mkdir(exist_ok=True)
    old_rows = {r["id"]: r for r in old["standing"]["rows"]}
    rows = []
    for r in fixed["standing"]:
        f = arrays(r["input"])
        original = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        rectangle = tuple(r["local_ROI"])
        p = section(original, *rectangle)
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        new, active, peaks = correction(original, scene, colors, rectangle, rectangle, r["noise"], wb, matrix)
        diff = {k: float(np.sqrt(np.mean((out.astype(float) - p)**2)) * 65535) for k, out in new.items()}
        assert diff["local64"] == old_rows[r["id"]]["RGB_RMS_DN16"]["local64"]
        images = []
        for view in r["displays"]:
            exp = view["exposure"]
            existing = view["board"]
            with Image.open(checked(existing["image"])) as pic:
                a = np.asarray(pic)
            previous = {}
            for panel in existing["panels"]:
                x, y, w, h = panel["png_xywh"]
                previous[panel["name"]] = a[y:y+h, x:x+w]
            np.testing.assert_array_equal(display(p, wb, matrix, exp), previous["Local 50k"])
            labels = ("Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Local 50k")
            inputs = [(k, previous[k]) for k in labels]
            inputs.extend((LABELS[k], display(new[k], wb, matrix, exp)) for k in METHODS)
            inputs.extend((k, previous[k]) for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                          if k in previous)
            board = Image.new("RGB", (8 + 168 * len(inputs), 192), "#eeeeee")
            draw = ImageDraw.Draw(board)
            columns = []
            for i, (name, pixels) in enumerate(inputs):
                x = 8 + 168*i
                assert pixels.shape == (160, 160, 3)
                board.paste(Image.fromarray(pixels), (x, 24))
                draw.text((x, 5), name, fill="black")
                columns.append({"name": name, "PNG_xywh": [x, 24, 160, 160]})
            path = dest / f'{r["id"]}-x{exp:g}.png'
            board.save(path)
            images.append({"image": reference(path), "exposure": exp, "archive_columns": existing, "columns": columns})
        rows.append({
            "id": r["id"], "raw": r["raw"], "input": r["input"], "parent": r["predictions"]["local50k"],
            "noise": r["noise"], "ROI_xywh": r["global_ROI"], "peaks": peaks, "active": active,
            "RGB_RMS_DN16": diff, "native": images,
        })
    assert len(rows) == 8
    return {"fixed_review": source, "rows": rows}


def main():
    torch.set_num_threads(2)
    verify_folds()
    start = time.monotonic()
    source = reference(EXTERIOR / "parent/result.json")
    proof = read_json(checked(source))
    control = reference(EXTERIOR / "ring/result.json")
    old = read_json(checked(control))
    assert proof["dose"] == "0.85" and proof["precision"] == "CUDA IEEE FP32 EMA"
    assert old["parent_replay"] == source and old["parent_checkpoint"] == proof["checkpoint"]
    exact = bench(proof, old)
    response = {
        f"{right}_minus_{left}": response_match(
            exact["previous"]["rows"], exact["confirmation"]["rows"],
            (left, right), source_bootstrap, interval,
        )
        for left, right in (("broad", "guarded"), ("broad", "phase_only"), ("local64", "guarded"))
    }
    write_json(OUT / "result.json", {
        "driver": reference(__file__), "proof": source, "bound_controls": control,
        "policy": {"checkpoint": proof["checkpoint"], "precision": proof["precision"],
                   "gain": GAIN, "fold_threshold": THRESHOLD, "fitting": 64, "delivery": 32},
        "exact": exact, "matched_response": response, "standing": standing(proof, old),
        "seconds": time.monotonic() - start,
    })
    print("Completed", OUT / "result.json", flush=True)


if __name__ == "__main__":
    main()
