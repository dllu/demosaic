"""Bind the paired center-check measurements and reviewed native crops."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
OUT = Path("/mnt/external/demosaic") / HERE.name
RESULTS = REPO / "docs/results" / OUT.name
ASSETS = REPO / "docs/assets" / OUT.name


def main():
    receipt = reference(OUT / "result.json")
    result = read_json(checked(receipt))
    old = read_json(checked(result["bound_controls"]))
    parent = read_json(checked(result["proof"]))
    assert old["parent_replay"] == result["proof"]
    assert result["policy"]["checkpoint"] == old["parent_checkpoint"] == parent["checkpoint"]
    panels = result["exact"]
    assert len(panels["previous"]["rows"]) == 32
    confirm = panels["confirmation"]
    assert len(confirm["rows"]) == 24
    assert len({r["fixture"]["source"]["cache_sha256"] for v in panels.values() for r in v["rows"]}) == 56
    standing = result["standing"]["rows"]
    assert len(standing) == 8
    exact = [(r["native"][kind]["image"], 3 if kind == "triplet" else 7)
             for r in confirm["rows"] if "native" in r for kind in ("triplet", "board")]
    real = [(item["image"], len(item["columns"])) for r in standing for item in r["native"]]
    assert len(exact) == 4 and len(real) == 12
    active = {}
    for partition, values in panels.items():
        summary = {}
        for role, i in zip(("intact", "long_exterior_only", "weak_absent", "flat"), range(4), strict=True):
            rows = values["rows"]
            activity = {}
            for method in ("broad", "guarded", "phase_only"):
                counts = [r["active"][i][method] for r in rows]
                activity[method] = {
                    "sources_with_any": sum(any(c) for c in counts),
                    "passes_by_nominated_direction": [sum(c[j] for c in counts) for j in range(2)],
                }
            summary[role] = {
                "sources": len(rows), "nominated": sum(r["spacing_by_role"][i] is not None for r in rows),
                "windows_per_direction_per_source": 81, "methods": activity,
            }
        active[partition] = summary
    ASSETS.mkdir()
    RESULTS.mkdir()
    images = []
    for item, frames in exact + real:
        source = checked(item)
        with Image.open(source) as pic:
            assert pic.size == (8 + frames * 168, 192)
        dest = ASSETS / source.name
        shutil.copyfile(source, dest)
        assert reference(dest)["sha256"] == item["sha256"]
        images.append({"path": str(dest.relative_to(REPO)), "sha256": item["sha256"]})
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=3) as bundle:
        for name, binding in {
            "result.json": receipt, "parent.json": result["proof"], "control.json": result["bound_controls"],
        }.items():
            bundle.add(checked(binding), arcname=f"receipts/{name}", recursive=False)
        for path in (
            Path(__file__), checked(result["driver"]), HERE / "center_guard.py",
            checked(old["driver"]), checked(old["implementation"]),
            REPO / "src/demosaic/mesh_carrier_fit.py",
        ):
            bundle.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
    write_json(RESULTS / "publication.json", {
        "scope": "Scoped inference-only Bayer carrier correction on Local 50k. Reused optical sources and standing GFX families.",
        "parent": result["proof"], "exact_and_GFX": receipt, "policy": result["policy"],
        "archive": {"path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "correction_review_seconds": result["seconds"], "confirmation": confirm["summary"],
        "matched_response": result["matched_response"], "site_activity": active,
        "images": images, "native_images_viewed": len(exact) + len(real),
        "standing_RGB_RMS_DN16": {r["id"]: r["RGB_RMS_DN16"] for r in standing},
    })


if __name__ == "__main__":
    main()
