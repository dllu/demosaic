"""Estimate phase outside a delivery patch and validate on both greens inside it."""


import numpy as np

from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers

from review_raw import box_wave, nuisance, planes, unpack

WIDTH = 32
OUTER = 64
OFFSET = (OUTER - WIDTH) // 2
ROI_WIDTH = 160
TAPER = np.sin(np.pi * (np.arange(WIDTH) + .5) / WIDTH)**2
TAPER = TAPER[:, None] * TAPER
EDGE = np.minimum(1., np.minimum(np.arange(ROI_WIDTH) + .5, np.arange(ROI_WIDTH)[::-1] + .5) / 12)
METHODS = ("ring32", "local32", "local64")
GAIN = .73
THRESHOLD = 6.


def sample(array, position):
    return array[position[0]::2, position[1]::2]


def outside_coefficients(ring, operators):
    coefs = []
    for region, fit in operators:
        values = ring[region]
        coefs.append((fit @ values).reshape(2, 2))
    return np.mean(coefs, axis=0)


class Patch:
    def __init__(self, colors, x, y, frequencies):
        positions = planes(np.asarray(colors), (x, y, WIDTH))
        self.positions = positions
        inner = box_wave((0, 0, WIDTH), ((WIDTH-1)/2,)*2, frequencies)
        ring = box_wave((0, 0, OUTER), ((OUTER-1)/2,)*2, frequencies)
        outside = np.ones((OUTER, OUTER), dtype=bool)
        outside[OFFSET:-OFFSET, OFFSET:-OFFSET] = False
        design = np.concatenate((nuisance(OUTER, "cosine"), ring.reshape(OUTER, OUTER, 4)), axis=-1)
        self.outside = []
        for y0, x0 in positions:
            p = np.zeros_like(outside)
            p[y0::2, x0::2] = True
            selected = p & outside
            fit = np.linalg.pinv(design[selected], rcond=1e-8)[-4:]
            self.outside.append((selected, fit))

        self.wave = inner
        smooth = nuisance(WIDTH, "cosine")
        base = np.concatenate((smooth, inner.reshape(WIDTH, WIDTH, 4)), axis=-1)
        self.parent_fit = np.linalg.pinv(base.reshape(WIDTH**2, -1), rcond=1e-8)[-4:]
        self.folds = []
        for train, test in (positions, positions[::-1]):
            banks = []
            for d in range(2):
                cols = np.concatenate((smooth, inner[..., 1-d, :]), axis=-1)
                a, b = (sample(cols, lattice).reshape(-1, cols.shape[-1]) for lattice in (train, test))
                ca, cb = (sample(inner[..., d, :], lattice).reshape(-1, 2) for lattice in (train, test))
                base_fit = np.linalg.pinv(a, rcond=1e-8)
                coefs = base_fit @ ca
                ra, rb = ca - a @ coefs, cb - b @ coefs
                banks.append((a, b, base_fit, ra, rb, np.linalg.pinv(ra, rcond=1e-8)))
            self.folds.append(banks)

    def predict(self, ring, parent, shot, read):
        context = outside_coefficients(ring, self.outside)
        unit = context / np.linalg.norm(context, axis=1, keepdims=True).clip(min=1e-12)
        detail = ring[OFFSET:-OFFSET, OFFSET:-OFFSET]
        fits = {label: [] for label in METHODS[:2]}
        gains = {label: [] for label in METHODS[:2]}
        for lattice, complement, bases in zip(self.positions, self.positions[::-1], self.folds, strict=True):
            u, v = (sample(detail, idx).ravel() for idx in (lattice, complement))
            var = max(2e-11, shot * max(0., u.mean()) + read)
            decisions = {name: [] for name in METHODS[:2]}
            weights = {name: [] for name in METHODS[:2]}
            for d, (a, b, base, ra, rb, free) in enumerate(bases):
                beta = base @ u
                delta = u - a @ beta
                hold = v - b @ beta
                guide = unit[d]
                design = ra @ guide
                positive = max(0., float(design @ delta / max(design @ design, 1e-12)))
                choices = {"ring32": positive * guide, "local32": free @ delta}
                for name, coef in choices.items():
                    predicted = rb @ coef
                    gain = (2 * hold @ predicted - predicted @ predicted) / var
                    decisions[name].append(coef)
                    weights[name].append(gain)
            for method in METHODS[:2]:
                fits[method].append(decisions[method])
                gains[method].append(weights[method])

        old = (self.parent_fit @ parent.ravel()).reshape(2, 2)
        out, support = {}, {}
        for label in METHODS[:2]:
            passes = np.clip(np.min(gains[label], axis=0) - THRESHOLD, 0, None)
            gate = passes / (passes + THRESHOLD)
            measured = np.mean(fits[label], axis=0)
            correction = (measured - old) * gate[:, None]
            extent = np.linalg.norm(measured, axis=-1)
            power = np.linalg.norm(correction, axis=-1).clip(min=1e-12)
            correction *= np.minimum(1., extent / power)[:, None]
            out[label] = np.sum(self.wave * correction[None, None], axis=(2, 3))
            support[label] = gate > 0
        return out, support


def correct(parent, scene, colors, roi, frequency, profile, wb, matrix):
    """Apply the fixed geometry gate and deliver only support in the 32-pixel patch."""
    x, y, w, h = roi
    output = {method: parent for method in METHODS}
    counts = {name: [0, 0] for name in METHODS[:2]}
    if frequency is None:
        return output, counts
    assert parent.shape == (3, ROI_WIDTH, ROI_WIDTH)
    assert w == h == ROI_WIDTH
    patch = Patch(colors, x, y, frequency)
    raw = unpack(scene)
    fields = {k: np.zeros((h, w)) for k in METHODS[:2]}
    mass = np.zeros((h, w))
    for dy in range(0, h - WIDTH + 1, WIDTH // 2):
        for dx in range(0, w - WIDTH + 1, WIDTH // 2):
            tile = np.s_[dy:dy+WIDTH, dx:dx+WIDTH]
            a, b = x + dx - OFFSET, y + dy - OFFSET
            ring = raw[b:b+OUTER, a:a+OUTER].astype(np.float64)
            assert ring.shape == (OUTER, OUTER)
            delta, support = patch.predict(ring, parent[1][tile], profile["shot"], profile["read"])
            for k in METHODS[:2]:
                fields[k][tile] += delta[k] * TAPER
                counts[k] = (np.asarray(counts[k]) + support[k]).tolist()
            mass[tile] += TAPER
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    for k, values in fields.items():
        delta = values / np.maximum(.02, mass) * EDGE[:, None] * EDGE[None, :]
        output[k] = parent + (GAIN * (neutral / neutral[1])[:, None, None] * delta).astype(parent.dtype)
    output["local64"] = refine_raw_mesh_carriers(
        parent, scene, colors, roi, shot=profile["shot"], read=profile["read"],
        white_balance=wb, camera_to_srgb=matrix,
    )
    return output, counts


def independence():
    colors = (0, 1, 1, 2)
    rng = np.random.default_rng(20261120)
    raw = rng.random((OUTER, OUTER))
    changed = raw.copy()
    changed[OFFSET:-OFFSET, OFFSET:-OFFSET] = rng.random((WIDTH, WIDTH))
    patch = Patch(colors, 0, 0, ((.1152, .0742), (.0898, -.0723)))
    np.testing.assert_array_equal(outside_coefficients(raw, patch.outside), outside_coefficients(changed, patch.outside))
