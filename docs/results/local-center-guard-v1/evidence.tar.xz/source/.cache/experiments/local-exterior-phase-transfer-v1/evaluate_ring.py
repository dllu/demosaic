"""Evaluate the 64-to-32 exterior ring correction on bound photos and both GFX scenes."""

import sys
import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from demosaic.reporting import display_crop
from review_raw import FIXED, HERE, OUT
from ring_refit import GAIN, METHODS, THRESHOLD, correct, independence

sys.path[:0] = [str(HERE.with_name("sensor-optical-transfer-v1")), str(HERE.with_name("local-optical-mixture-v1"))]
from capture_optical import ABSOLUTE, LENGTH, WireFundamental, arrays, native_board, support_for_scoring
from optical_response_balance import coefficients, compare as response_match
from summarize_optical import interval, source_bootstrap

ROI = (48, 48, 160, 160)
ABS = "fundamental_intact_RMS_DN16"
GAP = "gap_continuing_strong_RMS_DN16"
FALSE = "fundamental_false_RMS_DN16"
FLAT = "exact_flat_RMS_DN16"
LABELS = {"parent": "Local 50k", "ring32": "Ring phase, 32px", "local32": "Local phase, 32px", "local64": "Local phase, 64px"}
BOARD_IDS = {"fresh-02", "fresh-08"}


def frozen_inputs(row):
    case = row["case"]
    f = arrays(row["input"])
    p = np.load(checked(row["output"]), allow_pickle=False)
    assert p.shape == f["target"].shape and p.dtype == np.float32
    scene = f["scene_packed"].copy()
    assert scene.shape == (4, 256, 256)
    x, y, w, h = (128, 128, 256, 256)
    cut = np.s_[..., y//2:(y+h)//2, x//2:(x+w)//2]
    np.testing.assert_array_equal(scene[cut], f["packed"][1])
    roi = (x + ROI[0], y + ROI[1], *ROI[2:])
    return {"case": case, "input": f, "input_receipt": row["input"],
            "parent": p, "scene": scene, "phase_correction_roi": roi, "cut": cut}


def methods_for(fixture, profile):
    f, p = fixture["input"], fixture["parent"]
    scene = fixture["scene"]
    roi = fixture["phase_correction_roi"]
    x, y, w, h = ROI
    white, matrix = f["wb"], f["matrix"]
    records = {k: p.copy() for k in METHODS}
    active, frequencies = [], []
    for index, sample in enumerate(f["packed"]):
        scene[fixture["cut"]] = sample
        fit = _spacing(scene, f["colors"], roi[0], roi[1])
        frequencies.append(None if fit is None else fit.tolist())
        output, counts = correct(p[index, :, y:y+h, x:x+w], scene, f["colors"], roi, fit,
                                 profile, white, matrix)
        for k, image in output.items():
            records[k][index, :, y:y+h, x:x+w] = image
        active.append(counts)
    scores = {"parent": p} | records
    sharp = arrays(fixture["case"]["inputs"]["0.0"])
    support = support_for_scoring(f["support"])
    assert np.array_equal(sharp["support"], f["support"])
    geometry = fixture["case"]["fixture"]["geometry"]
    clean = WireFundamental(sharp | {"support": support}, geometry)
    operator = WireFundamental(f | {"support": support}, geometry)

    def score(rgb):
        return operator(rgb) | {ABSOLUTE: clean(rgb)[LENGTH]}

    metrics = {k: score(v) for k, v in scores.items()}
    coeff = coefficients(p, records, score)
    return metrics, scores, active, frequencies, coeff, float(np.sqrt(clean.clean_norm / clean.intact.sum()) * 65535)


def bench(sources, dest, checkpoint):
    data = {}
    for panel in ("previous", "confirmation"):
        rows = []
        group = sources["panels"][panel]
        for row in group["rows"]:
            f = frozen_inputs(row)
            s, outputs, counts, frequencies, fit, strength = methods_for(f, group["profile"])
            key = f["case"]["id"]
            receipt = {
                "id": key, "fixture": f["case"]["fixture"], "inputs": row["input"], "parent": row["output"],
                "family": f["case"]["fixture"]["geometry"]["family"], "scores": s, "active": counts,
                "spacing_by_role": frequencies,
                "response_balance": fit, "clean_fundamental_RMS_DN16": strength,
            }
            if key in BOARD_IDS:
                args = f["input"]
                camera = {name: args[name][None] for name in ("colors", "wb", "matrix")}
                camera["packed"] = args["packed"][:1]
                ref = args["target"][0]
                frames = [noisy_malvar(camera)[0], *(outputs[k][0] for k in LABELS), ref]
                receipt["native"] = native_board(
                    dest, key, frames, camera, {
                        "input": row["input"], "fixture": f["case"]["fixture"], "query": [128, 128, 256, 256],
                        "noise": group["profile"], "checkpoint": checkpoint, "optical_sigma": .85,
                    }, labels=["Noisy Malvar", *LABELS.values(), "Exact GT"], triplet_indices=(0, 2, 5),
                )
            rows.append(receipt)
            if len(rows) % 8 == 0:
                print("Ring", panel, len(rows), flush=True)
        data[panel] = {"input_source": group["source"], "rows": rows, "summary": paired(rows)}
    return data


def paired(rows):
    rng = np.random.default_rng(202611200047)
    stats = {}
    order = sorted(rows, key=lambda r: r["clean_fundamental_RMS_DN16"])
    for cohort, subjects in (("all", rows), ("faintest_half", order[:len(order)//2])):
        series = {}
        for key in (LENGTH, ABSOLUTE, ABS, GAP, FALSE, FLAT):
            group = [r for r in subjects if key in r["scores"]["parent"]]
            if not group:
                continue
            draws = source_bootstrap(group, rng)
            values = {k: np.array([x["scores"][k][key] for x in group])[draws].mean(1) for k in LABELS}
            series[key] = {
                "n": len(group), "means": {k: interval(v) for k, v in values.items()},
                "versus_parent": {k: interval(values[k] - values["parent"]) for k in METHODS},
                "ring_minus_local32": interval(values["ring32"] - values["local32"]),
                "ring_minus_local64": interval(values["ring32"] - values["local64"]),
            }
        stats[cohort] = series
    return stats


def display(value, wb, matrix, exposure):
    return np.rint(np.clip(display_crop(
        torch.from_numpy(value[None]), torch.from_numpy(wb[None]), torch.from_numpy(matrix[None]),
        (0, 0, 160, 160), exposure=exposure
    ), 0., 1.) * 255).astype(np.uint8)


def standing(checkpoint, root):
    fixed_ref = reference(FIXED)
    fixed = read_json(checked(fixed_ref))
    assert fixed["checkpoints"]["local50k"] == checkpoint
    rows = []
    for r in fixed["standing"]:
        f = arrays(r["input"])
        p = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)
        x, y, w, h = r["local_ROI"]
        rect = np.s_[..., y:y+h, x:x+w]
        orig = p[0][rect]
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        peaks = _spacing(scene, colors, x, y)
        result, count = correct(orig, scene, colors, tuple(r["local_ROI"]), peaks, r["noise"], wb, matrix)
        deltas = {k: float(np.sqrt(np.mean((out.astype(float) - orig)**2)) * 65535) for k, out in result.items()}
        image_rows = []
        for view in r["displays"]:
            exposure = view["exposure"]
            existing = view["board"]
            with Image.open(checked(existing["image"])) as pic:
                a = np.asarray(pic)
                original = {}
                for panel in existing["panels"]:
                    qx, qy, qw, qh = panel["png_xywh"]
                    original[panel["name"]] = a[qy:qy+qh, qx:qx+qw]
            np.testing.assert_array_equal(display(orig, wb, matrix, exposure), original["Local 50k"])
            names = ("Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Local 50k")
            frames = [(k, original[k]) for k in names]
            frames.extend((LABELS[k], display(result[k], wb, matrix, exposure)) for k in METHODS)
            frames.extend((k, original[k]) for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                          if k in original)
            board = Image.new("RGB", (8 + 168*len(frames), 192), "#eeeeee")
            d = ImageDraw.Draw(board)
            for column, (name, pixels) in enumerate(frames):
                assert pixels.shape == (160, 160, 3)
                start = 8 + 168*column
                board.paste(Image.fromarray(pixels), (start, 24))
                d.text((start, 5), name, fill="black")
            dest = root / f'{r["id"]}-x{exposure:g}.png'
            board.save(dest)
            image_rows.append({"image": reference(dest), "exposure": exposure, "archive_columns": existing})
        rows.append({
            "id": r["id"], "raw": r["raw"], "input": r["input"], "parent": r["predictions"]["local50k"],
            "noise": r["noise"], "ROI_xywh": r["global_ROI"],
            "peak_frequencies": None if peaks is None else peaks.tolist(), "active": count,
            "RGB_RMS_DN16": deltas, "native": image_rows,
        })
    assert len(rows) == 8
    return {"fixed_review": fixed_ref, "rows": rows}


def main():
    torch.set_num_threads(2)
    independence()
    source = reference(OUT / "parent/result.json")
    proof = read_json(checked(source))
    assert proof["dose"] == "0.85" and proof["precision"] == "CUDA IEEE FP32 EMA"
    dest = OUT / "ring"
    dest.mkdir(exist_ok=True)
    real = dest / "standing"
    real.mkdir(exist_ok=True)
    exact = dest / "exact"
    exact.mkdir(exist_ok=True)
    start = time.monotonic()
    cached = dest / "exact-results.json"
    if cached.exists():
        outcome = read_json(cached)
    else:
        outcome = bench(proof, exact, proof["checkpoint"])
        write_json(cached, outcome)
    matching = response_match(
        outcome["previous"]["rows"], outcome["confirmation"]["rows"],
        ("local64", "ring32"), source_bootstrap, interval,
    )
    gfx = standing(proof["checkpoint"], real)
    write_json(dest / "result.json", {
        "driver": reference(__file__), "implementation": reference(HERE / "ring_refit.py"),
        "parent_replay": source, "parent_checkpoint": proof["checkpoint"],
        "nominal_gain": GAIN, "reciprocal_gain_each_green_cutoff": THRESHOLD,
        "native_roi": ROI, "exact": outcome, "matched_recovery_ring_minus_local64": matching, "standing": gfx,
        "seconds": time.monotonic() - start,
    })


if __name__ == "__main__":
    main()
