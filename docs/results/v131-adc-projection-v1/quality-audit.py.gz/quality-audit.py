"""Independent native/channelwise photo reductions; no Torch import or inference."""
from pathlib import Path
import gzip,hashlib,json,sys,time,os
import numpy as np
from PIL import Image
from receipt_helpers import read_json,checked,write_json,reference
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());os.nice(10);began=time.monotonic();closed=read_json(root/'collection.json');expected={(r['id'],r['pattern']):r for r in read_json(root/'photo-rows.json')};errors={k:0. for k in ['linear_psnr','srgb_psnr','chroma_mae','gradient_mae']};fields=0
# Separate channel sums and L2 norms, without the producer's einsum/reduction helper.
def srgb(v):
 v=np.clip(v,0,1);return np.where(v<=.0031308,12.92*v,1.055*np.power(v,1/2.4)-.055)
def rgb(v,d):
 v=v.astype(np.float64)*d['wb'].astype(np.float64)[...,None,None];return np.stack([sum(v[:,j]*d['matrix'][:,i,j,None,None].astype(np.float64)for j in range(3))for i in range(3)],axis=1)
def psnr(v):return float(-10*np.log10(max(float(np.vdot(v,v).real)/v.size,1e-12)))
for item in closed['rows']:
 if item['stage']!='photo':continue
 row=item['original'];p=np.load(checked(item['prediction']),allow_pickle=False)
 with np.load(checked(row['supervision']),allow_pickle=False)as z:d={k:z[k]for k in z.files}
 a,b=(rgb(v[...,8:-8,8:-8],d)for v in [p,d['target']]);a,b=srgb(a),srgb(b);error=a-b;linear=np.clip(p[...,8:-8,8:-8].astype(np.float64),0,1)-np.clip(d['target'][...,8:-8,8:-8].astype(np.float64),0,1)
 for i,ident in enumerate(row['context']['ids']):
  measures={'linear_psnr':psnr(linear[i]),'srgb_psnr':psnr(error[i]),'chroma_mae':float(np.abs(error[i]-error[i].mean(0,keepdims=True)).mean()),'gradient_mae':float((np.abs(np.diff(a[i],axis=-1)-np.diff(b[i],axis=-1)).mean()+np.abs(np.diff(a[i],axis=-2)-np.diff(b[i],axis=-2)).mean())/2)}
  for k,v in measures.items():errors[k]=max(errors[k],abs(v-expected[(ident,row['context']['pattern'])]['metrics'][k]));fields+=1
assert fields==1772*4 and max(errors.values())<1e-10
# Independent display sum versus encoded cells for new material/color boards.
manifest=read_json(repo/'docs/images/v131-adc-projection-v1/manifest.json');native_channels=0;native_boards=0
# Retain existing independently implemented Malvar only for the noisy display cell.
from demosaic.archive_metrics import noisy_malvar
for figure in manifest['images']:
 path=checked(figure['image'])
 if '/protected/'in str(path):
  assert path.read_bytes()==checked(figure['original_image']).read_bytes();continue
 color='adc-color' in path.name;row=figure['record']if color else figure['parent'];idx=0 if color else figure['sample']
 with np.load(checked(row['supervision']),allow_pickle=False)as z:d={k:z[k][idx:idx+1]for k in z.files}
 p=np.load(checked(row['prediction']))[idx:idx+1];q=np.load(checked(figure['projected_record']['prediction']if color else figure['projected']))[idx:idx+1];values=[noisy_malvar(d),q,d['target']]if path.stem.endswith('triplet')else[noisy_malvar(d),p,q,d['target']]
 with Image.open(path)as im:png=np.asarray(im)
 for value,cell in zip(values,figure['panels'],strict=True):
  pixels=np.rint(srgb(rgb(value,d))[0,:,48:208,48:208].transpose(1,2,0)*255).astype(np.uint8);x,y,w,h=cell['xywh'];assert np.array_equal(png[y:y+h,x:x+w],pixels);native_channels+=pixels.size
 native_boards+=1
assert native_boards==5 and 'torch'not in sys.modules
write_json(root/'independent-audit.json',{'script':reference(__file__),'collection':reference(root/'collection.json'),'photo_metric_fields':fields,'maximum_absolute_discrepancies':errors,'native_boards':native_boards,'native_RGB_channels_exact':native_channels,'protected_boards_byte_exact':8,'Torch_imported':False,'new_neural_forwards':0,'seconds':time.monotonic()-began,'scope':'Independent channelwise float64 display and L2 photo reductions on all1772 ADC observations, including64 procedural observations;427photo source bootstrap remains separately archived. Five newly rendered boards checked pixel-exact; eight protected adopted PNGs checked byte-exact. No independent second texture/projection-kernel implementation claimed.'});print('audit passed',fields,errors,native_channels,flush=True)
