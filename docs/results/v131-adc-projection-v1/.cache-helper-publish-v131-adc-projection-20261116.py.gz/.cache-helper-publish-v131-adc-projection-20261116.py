"""Publish the fixed ADC repair with matched native material and color evidence."""
import gzip,hashlib,json,shutil,tarfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from demosaic.archive_metrics import display,noisy_malvar
from demosaic.experiments.artifacts import read_json,write_json,checked,reference
R=Path.cwd();E=R/'.cache/experiments';p=E/'v131-adc-projection-quality-v2';out=R/'docs/images/v131-adc-projection-v1';pub=R/'docs/results/v131-adc-projection-v1';out.mkdir(exist_ok=False);pub.mkdir(exist_ok=False);export=read_json(E/'v131-adc-malvar-export-v1/receipt.json');closed=read_json(p/'collection.json');triplets=read_json(E/'v131-broad-independent-v1/work/audit-output/photo/result.json')['native_triplets'];figures=[]
def board(name,values,labels,data,metadata):
 canvas=Image.new('RGB',(8+168*len(values),192),'#eee');draw=ImageDraw.Draw(canvas);panels=[]
 for j,(label,value)in enumerate(zip(labels,values,strict=True)):
  pixels=np.rint(display(value[...,48:208,48:208],data)[0].transpose(1,2,0)*255).astype(np.uint8);assert pixels.shape==(160,160,3);x=8+j*168;canvas.paste(Image.fromarray(pixels),(x,24));draw.text((x,5),label,fill='black');panels.append({'label':label,'xywh':[x,24,160,160],'pixel_sha256':hashlib.sha256(pixels.tobytes()).hexdigest()})
 path=out/(name+'.png');canvas.save(path)
 with Image.open(path)as im:encoded=np.array(im)
 for cell in panels:
  x,y,w,h=cell['xywh'];assert hashlib.sha256(encoded[y:y+h,x:x+w].tobytes()).hexdigest()==cell['pixel_sha256']
 return dict(metadata,image=reference(path),panels=panels,ROI_xywh=[48,48,160,160],native_context=[256,256],display_exposure=1,display_contrast=1,no_resize=True,display_transform='Shared saved WB/matrix, NumPy64 clipped sRGB, round-to-nearest uint8',checkpoint_export=export['export_sha256'])
for item in triplets:
 row=next(x for x in closed['rows']if x['stage']=='photo'and item['source_id']in x['original']['context']['ids']and x['original']['context']['pattern']=='RGGB');record=row['original'];idx=record['context']['ids'].index(item['source_id']);
 with np.load(checked(record['supervision']),allow_pickle=False)as z:data={k:z[k][idx:idx+1]for k in z.files}
 parent=np.load(checked(record['prediction']))[idx:idx+1];projected=np.load(checked(row['prediction']))[idx:idx+1];metadata={'source':item['source'],'source_id':item['source_id'],'parent':record,'projected':row['prediction'],'sample':idx,'conditioning':record['context']['condition'],'white_balance':data['wb'].tolist(),'camera_to_srgb':data['matrix'].tolist(),'GT':'Exact synthetic target saved by original evaluator','selection':'Same two material sources and160 ROI as the prior broad audit; ADC RGGB variant, no crop search.'};name='bark'if'Coffee' in item['source']['title']else'fur'
 figures.append(board(name+'-triplet',[noisy_malvar(data),projected,data['target']],['Noisy Malvar','V131 ADC Malvar','Exact synthetic GT'],data,metadata));figures.append(board(name+'-comparison',[noisy_malvar(data),parent,projected,data['target']],['Noisy Malvar','V131','V131 ADC Malvar','Exact synthetic GT'],data,metadata))
# The already published worst-mean-color case, now with projected triplet.
source=read_json(R/'docs/images/v131-broad-completed-v1/manifest.json');case=next(x for x in source['images']if Path(x['image']['path']).name=='adc-color-outlier-comparison.png');record=case['record'];item=case['projected_record'];
with np.load(checked(record['supervision']),allow_pickle=False)as z:data={k:z[k]for k in z.files}
value=np.load(checked(item['prediction']));figures.append(board('adc-color-outlier-triplet',[noisy_malvar(data),value,data['target']],['Noisy Malvar','V131 ADC Malvar','Exact constructed GT'],data,case))
# Same endpoint protected positive-prior outputs are adopted, never recalculated.
for item in source['images']:
 if '/protected/'in item['image']['path']:
  dest=out/'protected'/Path(item['image']['path']).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(checked(item['image']).read_bytes());figures.append(dict(item,image=reference(dest),positive_prior_policy='Existing projection bypass: unchanged V131, exact original PNG bytes',original_image=item['image']))
write_json(out/'manifest.json',{'images':figures,'export_receipt':reference(E/'v131-adc-malvar-export-v1/receipt.json'),'collection':reference(p/'collection.json'),'scope':'New native ADC material/color boards; same positive-prior V131 protected views adopted exactly. No new neural work in publication; variant export keeps91 learned tensors unchanged.','no_resize':True})
body=['<!doctype html><meta charset="utf-8"><title>V131 ADC Malvar native review</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:24px 0;overflow:auto}img{max-width:none}</style><h1>V131 fixed ADC projection</h1><p>One native pixel per PNG pixel; browser zoom100%. Horizontal scrolling preserves pixels. ADC changes only; protected positive-prior outputs unchanged.</p>']
for item in figures:
 rel=Path(item['image']['path']).relative_to(out);body.append(f'<figure><figcaption>{rel}</figcaption><img src="{rel}"></figure>')
(out/'native-viewer.html').write_text('\n'.join(body)+'\n');archives=[]
for root,prefix,names in[(p,'quality',['run.py','receipt_helpers.py','plan.json','launch.json','collection.json','result.json','photo-rows.json','texture-rows.json','output.log']), (E/'v131-adc-projection-color-v1','color',['run.py','plan.json','launch.json','collection.json','scores.json','output.log']), (E/'v131-adc-malvar-export-v1','export',['receipt.json']), (E/'v131-adc-observation-recovery-v1','failed-recovery',['result.json']), (E/'v131-adc-projection-quality-v1','failed-prelaunch',['run.py','output.log','output-detached.log','launch.pid','launch-detached.json']), (R,'.cache-helper',['.cache/probe-adc-observation-recovery.py','.cache/publish-v131-adc-projection-20261116.py'])]:
 for name in names:
  src=root/name
  if not src.exists():continue
  dest=pub/(prefix+'-'+Path(name).name+'.gz');dest.write_bytes(gzip.compress(src.read_bytes(),mtime=0));assert gzip.decompress(dest.read_bytes())==src.read_bytes();archives.append({'original':reference(src),'published':reference(dest),'decompressed_bytes_exact':True})
with tarfile.open(pub/'export-source.tar.gz','x:gz')as t:
 for file in sorted((E/'v131-adc-malvar-export-v1/source').glob('*.py')):t.add(file,arcname=file.name)
write_json(pub/'publication.json',{'archives':archives,'export_source':reference(pub/'export-source.tar.gz'),'manifest':reference(out/'manifest.json'),'publisher':reference(__file__),'parent_frozen_numerical_sources':'../v131-broad-completed-v1/producer-executed-sources.tar.gz','new_neural_forwards_for_quality':0,'separate_integration_smoke_budget':4})
print('published',len(figures),'native boards',len(archives),'exact gzip receipts')
