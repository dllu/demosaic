"""Fixed existing ADC projection above closed V131 predictions, full ADC panels."""
import inspect,json,os,random,time
from pathlib import Path
import numpy as np
import torch,yaml
from demosaic import suite
from demosaic.cfa import adc_cfa_projection,color_indices,mosaic
from demosaic.data import CleanDataset,synthetic
from demosaic.prediction_archive import fingerprint
from demosaic.archive_metrics import photometry,texture
from receipt_helpers import read_json,write_json,reference,checked
from audit_quality_archive import paired_changes
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());prod=repo/'.cache/experiments/v131-broad-primary-v5';audit=repo/'.cache/experiments/v131-broad-independent-v1';old=repo/'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-independent-audit-v1/work/audit-output'
assert Path(suite.__file__).is_relative_to(prod/'work');(root/'run.claim').open('x').close();os.nice(10);torch.set_num_threads(2);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:]);torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=True
original=read_json(prod/'plan.json');manifests={s:checked(read_json(prod/f'work/artifacts/{s}/result.json')['archive'])for s in ['photo','texture']};records={s:[json.loads(line)for line in p.read_text().splitlines()]for s,p in manifests.items()};selected={s:[r for r in rr if r['context']['condition']['shot']==r['context']['condition']['read']==0]for s,rr in records.items()};assert len(selected['photo'])==444 and len(selected['texture'])==56
plan={'script':reference(__file__),'original_plan':reference(prod/'plan.json'),'archives':{s:reference(p)for s,p in manifests.items()},'checkpoint':original['checkpoints'][0],'policy':'Existing fixed adc_cfa_projection(mode=malvar), no training, kernel/threshold selection or target fit. Parent outputs unchanged. Positive-prior outputs bypass.','sources':{str(p.relative_to(prod/'work')):reference(p)for p in (prod/'work/src/demosaic').glob('*.py')},'scope':'Regenerate only original ADC photo observations with frozen original source cache/observation pipeline, requiring every exact input fingerprint and target witness. Texture missing inputs recovered via deterministic ADC quantization of retained clean targets, with identical exact input witnesses required. This uses clean arrays only to recover historical inputs, not to fit/choose the fixed operator. Save all500 outputs before any new quality scoring. Zero neural/DINO/RAW/optimizer calls or new independent noise;444 photo observation reconstruction batches and56 texture deterministic recovery batches. No original personal RAW media access.'}
write_json(root/'plan.json',plan);began=time.monotonic();saved=[]
def project(stage,row,batch):
 expected=row['context']['input_fingerprints'];actual={k:fingerprint(batch[k])for k in expected}
 if actual!=expected:raise ValueError(f"Exact original input mismatch {stage}/{row['index']}: {[k for k in expected if actual[k]!=expected[k]]}")
 assert fingerprint(batch['target'])==row['supervision_values']['target']
 parent=np.load(checked(row['prediction']),allow_pickle=False);p=torch.from_numpy(parent.copy());cpu={k:(v.detach().cpu()if isinstance(v,torch.Tensor)else torch.from_numpy(v.copy()))for k,v in batch.items()};value=adc_cfa_projection(p,cpu['packed'],cpu['colors'],cpu['wb'],mode='malvar').numpy();assert value.shape==parent.shape and value.dtype==np.float32 and np.isfinite(value).all()
 folder=root/stage;folder.mkdir(exist_ok=True);path=folder/f"batch-{row['index']:06d}.npy"
 with path.open('xb')as f:np.save(f,value,allow_pickle=False)
 saved.append({'stage':stage,'original':row,'prediction':reference(path),'exact_input_fingerprints':actual})
with torch.inference_mode():
 spec=original['stages']['photo'];protocol=yaml.safe_load(checked(spec['protocol']).read_text());data=CleanDataset(checked(spec['manifest']),split='val',patch_size=256,native_crop=True,records=[json.loads(s)for s in checked(spec['manifest']).read_text().splitlines()]);entries=[('photo',data.rows[i]['id'],i)for i in range(427)]+[('synthetic',f'synthetic-{i}',i)for i in range(16)];lookup={tuple(r['context']['ids'])+(r['context']['pattern'],):r for r in selected['photo']}
 for start in range(0,len(entries),4):
  current=entries[start:start+4];rgb=torch.stack([data[i]['rgb']if kind=='photo'else synthetic(256,random.Random(1_000_000+i))for kind,_,i in current]).to('cuda');ids=[ident for _,ident,_ in current]
  for pattern in protocol['patterns']:
   row=lookup[tuple(ids)+(pattern,)];batch=suite.observation(rgb,ids,row['context']['condition'],pattern,protocol['white_balance'],protocol['camera_to_srgb'],protocol.get('seed',42))
   for name in ['packed','variance']:batch[name]=batch[name].contiguous(memory_format=torch.channels_last)
   project('photo',row,batch)
  if start%40==0:print('photo sources',start+len(current),'saved',len(saved),flush=True)
 for row in selected['texture']:
  with np.load(checked(row['supervision']),allow_pickle=False)as z:batch={k:torch.from_numpy(z[k].copy())for k in z.files}
  target=batch['target'];colors=color_indices(row['context']['pattern'])[None].expand(len(target),-1);sampled=mosaic(target.clamp_min(0),colors);packed=(((sampled*.97+.03).clamp(0,1)*65535).round()/65535-.03)/.97;batch.update(packed=packed,variance=torch.zeros_like(packed),colors=colors);project('texture',row,batch)
write_json(root/'collection.json',{'plan':reference(root/'plan.json'),'rows':saved,'outputs':len(saved),'observations':1996,'new_neural_forwards':0,'physical_projection_calls':500,'seconds':time.monotonic()-began,'all_original_input_and_target_witnesses_exact':True});print('All500 outputs closed; scoring now',flush=True)
newrows={s:[]for s in selected}
for item in saved:
 stage=item['stage'];row=item['original'];v=np.load(checked(item['prediction']),allow_pickle=False)
 with np.load(checked(row['supervision']),allow_pickle=False)as z:targets={k:z[k]for k in z.files}
 metrics=photometry(v,targets)if stage=='photo'else texture(v,targets,period=row['context']['period']if row['context']['kind']=='carrier'else None)
 for i,identity in enumerate(row['context']['ids']):
  context=row['context'];metadata={'id':identity,'kind':'synthetic'if identity.startswith('synthetic-')else'photo'}if stage=='photo'else{k:context[k]for k in ['kind','level','contrast','period']};newrows[stage].append(dict(metadata,id=identity,condition='adc-only',pattern=context['pattern'],metrics={k:float(value[i])for k,value in metrics.items()}))
comparisons=[]
for stage,rr in newrows.items():
 write_json(root/f'{stage}-rows.json',rr)
 if stage=='photo':
  for name,path,sha in [('V131',audit/'work/audit-output/photo/rows.json',original['checkpoints'][0]['sha256']),('V120',old/'photo/rows.json','a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb')]:
   control=[r for r in read_json(path)if r['checkpoint_sha256']==sha and r['condition']=='adc-only']
   for metric in ['srgb_psnr','linear_psnr','chroma_mae','gradient_mae']:comparisons.append({'control':name,**paired_changes(rr,control,stage='photo',metric=metric)})
summary=[]
for kind in ['carrier','flat']:
 for label,path,sha in [('V131',audit/'work/audit-output/texture/rows.json',original['checkpoints'][0]['sha256']),('V120',old/'texture/rows.json','a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb'),('V131 ADC projection',root/'texture-rows.json',None)]:
  rr=[r for r in read_json(path)if r['condition']=='adc-only'and r['kind']==kind and(sha is None or r['checkpoint_sha256']==sha)];summary.append({'kind':kind,'method':label,'cases':len(rr),'means':{k:float(np.mean([r['metrics'][k]for r in rr]))for k in rr[0]['metrics']}})
write_json(root/'result.json',{'collection':reference(root/'collection.json'),'photo_comparisons':comparisons,'texture_summary':summary,'new_neural_forwards':0,'seconds':time.monotonic()-began,'scope':'Fixed existing operator atop saved V131 predictions. Positive-prior outputs unchanged by definition; no new real/noisy quality claim. ADC-only paired427-source comparisons; exact original corruption witnesses; texture ADC duplicates not independent draws.'});print('COMPLETE',[(r['control'],r['change'])for r in comparisons if r['metric']=='srgb_psnr'],flush=True)
