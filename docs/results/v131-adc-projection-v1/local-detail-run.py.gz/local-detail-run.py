from pathlib import Path
import os,sys,json,psutil
from diagnose_archive_local_detail import analyze,binding
r=Path(sys.argv[1]);p=json.loads((r/'plan.json').read_text())
for item in [p['first_manifest'],p['second_manifest'],*p['sources'].values()]:assert binding(item['path'])==item
os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:])
with(r/'run.claim').open('x'):pass
result=analyze(p['first_manifest']['path'],p['first_sha'],p['second_manifest']['path'],p['second_sha'],r/'work/local-detail',expected_images=p['expected_images'],maximum_seconds=p['maximum_seconds'])
assert result['paired_source_noise_CFA_observations']==p['expected_observations'] and result['unique_source_blocks']==p['expected_unique_blocks'] and 'torch'not in sys.modules
with(r/'completed.json').open('x')as f:json.dump({'result':binding(r/'work/local-detail/result-v1.json'),'plan':binding(r/'plan.json'),'new_neural_forwards':0},f,indent=2);f.write('\n')
print(result['photographic_sources'],result['paired_source_noise_CFA_observations'],result['seconds'],flush=True)
