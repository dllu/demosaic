"""Fixed existing Malvar residual projection on closed V131 ADC color outputs."""
from pathlib import Path
import os,sys,time
import numpy as np
import torch
from demosaic.cfa import adc_cfa_projection,mosaic
from demosaic.archive_metrics import color
from demosaic.experiments.artifacts import read_json,reference,checked,write_json,freeze_sources
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists())
(root/'run.claim').open('x').close();os.nice(10);torch.set_num_threads(2);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-2:])
producer=repo/'.cache/experiments/v131-broad-primary-v5';p=read_json(producer/'plan.json');result=read_json(Path(p['stages']['color']['output'])/'result.json')
rows=[__import__('json').loads(s)for s in checked(result['archive']).read_text().splitlines()]
selected=[r for r in rows if r['context']['definition']['condition']['name']=='adc-only']
assert len(rows)==1176 and len(selected)==588 and all(r['model']['sha256']==p['checkpoints'][0]['sha256']for r in rows)
work,files=freeze_sources(repo,root);plan={'source':reference(__file__),'original_color_result':reference(Path(p['stages']['color']['output'])/'result.json'),'original_archive':result['archive'],'checkpoint':p['checkpoints'][0],'policy':'Existing fixed adc_cfa_projection(mode=malvar), explicit shot=read=0, fixed valid interval1/65535..1-1/65535, unchanged WB-aware Malvar. No kernel/threshold/target fitting.','selected_cases':[r['context']['case_index']for r in selected],'frozen_files':files,'scope':'Input-only postprocess of588 ADC observations using saved predictions/packed RAW/colors/WB only; all outputs close before target loading. Other588 positive-prior outputs logically bypass projection and are adopted unchanged. Zero new neural/DINO/source/noise/RAW/optimizer work;588 fixed physical projections. Development diagnostic, photographic/texture tradeoffs remain separate.'};write_json(root/'plan.json',plan)
out=root/'predictions';out.mkdir();records=[];began=time.monotonic()
with torch.inference_mode():
 for row in selected:
  c=row['context']['definition']['condition'];assert c['shot']==c['read']==0
  with np.load(checked(row['supervision']),allow_pickle=False)as z:inputs={k:z[k]for k in ['packed','colors','wb']}
  parent=np.load(checked(row['prediction']),allow_pickle=False);tensors={k:torch.from_numpy(v.copy())for k,v in inputs.items()}
  value=adc_cfa_projection(torch.from_numpy(parent.copy()),tensors['packed'],tensors['colors'],tensors['wb'],mode='malvar').numpy()
  assert value.shape==parent.shape and value.dtype==np.float32 and np.isfinite(value).all()
  path=out/f"case-{row['context']['case_index']:04d}.npy"
  with path.open('xb')as f:np.save(f,value,allow_pickle=False)
  records.append({'case':row['context']['case_index'],'original':row,'prediction':reference(path)})
write_json(root/'collection.json',{'plan':reference(root/'plan.json'),'rows':records,'target_arrays_loaded':0,'new_neural_forwards':0,'physical_projection_calls':588,'seconds':time.monotonic()-began})
scored=[]
for item in records:
 with np.load(checked(item['original']['supervision']),allow_pickle=False)as z:gt={k:z[k]for k in ['target','wb','matrix','packed','colors']}
 parent=np.load(checked(item['original']['prediction']),allow_pickle=False);value=np.load(checked(item['prediction']),allow_pickle=False)
 scored.append({'case':item['case'],'definition':item['original']['context']['definition'],'parent':color(parent,gt),'projected':color(value,gt)})
def largest(key):return max(max(abs(v)for v in r[key]['camera_RGB_mean_error'])*65535 for r in scored)
write_json(root/'scores.json',{'collection':reference(root/'collection.json'),'rows':scored,'largest_mean_RGB_error_DN16':{'V131':largest('parent'),'V131_Malvar_projection':largest('projected')},'scope':'Same588 ADC cases, independent NumPy64 reductions after all projected outputs close. No claim for new positive-noise or real-photo behavior; original outputs/receipts preserved.'})
print('maximum meanRGB DN16',largest('parent'),largest('projected'),'seconds',time.monotonic()-began,flush=True)
