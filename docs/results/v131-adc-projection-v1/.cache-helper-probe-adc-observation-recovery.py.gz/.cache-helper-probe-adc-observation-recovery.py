"""Test exact ADC input recovery from retained clean arrays, no prediction reads."""
from pathlib import Path
import json,os
import numpy as np
import torch
from demosaic.cfa import mosaic,color_indices
from demosaic.prediction_archive import fingerprint
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
root=Path('.cache/experiments/v131-adc-observation-recovery-v1');root.mkdir(exist_ok=False)
torch.set_num_threads(2);os.nice(10);bad=[];counts={};records=[]
for stage in ['photo','texture']:
 result=Path('.cache/experiments/v131-broad-primary-v5/work/artifacts')/stage/'result.json';manifest=checked(read_json(result)['archive']);rows=[json.loads(s)for s in manifest.read_text().splitlines()];selected=[r for r in rows if r['context']['condition']['shot']==r['context']['condition']['read']==0];counts[stage]={'batches':len(selected),'observations':sum(len(r['context']['ids'])for r in selected)}
 for row in selected:
  with np.load(checked(row['supervision']),allow_pickle=False)as z:target=torch.from_numpy(z['target'].copy());wb=z['wb'];matrix=z['matrix']
  colors=color_indices(row['context']['pattern'])[None].expand(len(target),-1);sampled=mosaic(target.clamp_min(0),colors);packed=(((sampled*.97+.03).clamp(0,1)*65535).round()/65535-.03)/.97
  values={'packed':packed,'colors':colors,'variance':torch.zeros_like(packed),'wb':wb,'matrix':matrix};actual={k:fingerprint(v)for k,v in values.items()};expected=row['context']['input_fingerprints'];differ=[k for k in expected if actual[k]!=expected[k]]
  if differ:bad.append({'stage':stage,'index':row['index'],'ids':row['context']['ids'],'fields':differ})
  records.append({'stage':stage,'index':row['index'],'exact_fields':[k for k in expected if actual[k]==expected[k]]})
write_json(root/'result.json',{'script':reference(__file__),'counts':counts,'mismatches':bad,'checked':records,'scope':'Development test only: no prediction read, neural forward, new independent noise, source decode or RAW decode. Zero-noise quantization is deterministic. Existing clean targets reconstruct missing ADC observations; exact original input fingerprints are mandatory before using them in the already-fixed physical operator. This is recovery of historical inputs, not deployment target access.'})
print(counts,'mismatches',len(bad),bad[:3],flush=True)
