"""Four real model calls: exported ADC policy and exact positive-prior bypass."""
from pathlib import Path
import json,time,torch,numpy as np
from demosaic.models.registry import load_model
from demosaic.cfa import adc_cfa_projection
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if(p/'PROMPT.md').exists());torch.set_num_threads(2);torch.backends.cudnn.benchmark=True;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.set_float32_matmul_precision('highest')
triplet=read_json(repo/'.cache/experiments/v131-broad-independent-v1/work/audit-output/photo/result.json')['native_triplets'][0];records=[json.loads(s)for s in (repo/'.cache/experiments/v131-broad-primary-v5/work/artifacts/photo/archive/records.jsonl').read_text().splitlines()];chosen=[next(r for r in records if triplet['source_id']in r['context']['ids']and r['context']['pattern']=='RGGB'and r['context']['condition']['name']==condition)for condition in ['iso12800-prior','adc-only']];export=read_json(repo/'.cache/experiments/v131-adc-malvar-export-v1/receipt.json');write_json(root/'plan.json',{'script':reference(__file__),'export_receipt':reference(repo/'.cache/experiments/v131-adc-malvar-export-v1/receipt.json'),'observations':chosen,'neural_forward_budget':4,'scope':'Same exported91-tensor model, toggle only existing policy bool between two calls percondition. Verify positive-prior output byte-exact and ADC output equals direct fixed GPU projection of same-process unprojected output. CPU/GPU operator precision diagnostic on ADC. Not an independent quality sample or full-frame benchmark.'});began=time.monotonic();model,payload=load_model('v131-adc-malvar',checkpoint=export['export'],device='cuda');model.eval().to(memory_format=torch.channels_last);results=[]
with torch.inference_mode():
 for row in chosen:
  with np.load(checked(row['supervision']),allow_pickle=False)as z:inputs={k:torch.from_numpy(z[k].copy()).cuda()for k in ['packed','colors','wb','matrix']}
  condition=row['context']['condition'];inputs['variance']=inputs['packed'].clamp_min(0)*condition['shot']+condition['read'];args=[inputs[k]for k in ['packed','variance','colors','wb','matrix']];model.set_noise(condition['shot'],condition['read']);model.pretrained_rgb.adc_projection=True;projected=model(*args);model.pretrained_rgb.adc_projection=False;parent=model(*args)
  if condition['shot']+condition['read']:
   assert torch.equal(projected,parent);results.append({'condition':condition,'positive_prior_byte_exact':True})
  else:
   direct=adc_cfa_projection(parent,inputs['packed'],inputs['colors'],inputs['wb'],mode='malvar');assert torch.equal(projected,direct);cpu=adc_cfa_projection(parent.cpu(),inputs['packed'].cpu(),inputs['colors'].cpu(),inputs['wb'].cpu(),mode='malvar');delta=(cpu.double()-projected.cpu().double())*65535;results.append({'condition':condition,'integrated_equals_direct_GPU_byte_exact':True,'CPU_vs_GPU_max_DN16':float(delta.abs().max()),'CPU_vs_GPU_RMS_DN16':float(delta.square().mean().sqrt())})
 model.pretrained_rgb.adc_projection=True
write_json(root/'result.json',{'plan':reference(root/'plan.json'),'results':results,'neural_forwards':4,'encoder_forwards':4,'seconds':time.monotonic()-began,'export_sha256':payload['loaded_sha256']});print(results,flush=True)
