"""Review the retained 86k EMA on the same 110 native inputs as 50k."""

import importlib.util
import os
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "full-corpus-long50k-native-queue-v1"
CONTROL = ("V120", "scale-long50k")
NEW = "scale-long86k"
STEP = 86000

module = importlib.util.spec_from_file_location("native_stages", OLD / "watch.py")
watch = importlib.util.module_from_spec(module)
module.loader.exec_module(watch)


def main():
    earlier = read_json(OLD / "plan.json")
    before = read_json(OLD / "collection/result.json")
    assert len(before["records"]) == len(earlier["observations"]) == 110
    assert before["plan"] == reference(OLD / "plan.json")
    selection = []
    for obs, item in zip(earlier["observations"], before["records"], strict=True):
        record = read_json(checked(item))
        assert record["id"] == obs["id"]
        assert record["input_fingerprints"] == obs["input_fingerprints"]
        by_label = {v["label"]: v for v in record["variants"]}
        saved = [by_label[model] for model in CONTROL]
        for variant in saved:
            checked(variant["prediction"])
            assert variant["checkpoint"] == earlier["models"][variant["label"]]["checkpoint"]
        selection.append(saved)
    state = {
        "checkpoint": reference(ROOT / "step086000.pt"),
        "weights": "EMA",
        "step": STEP,
        "display_label": "Long schedule 86k EMA",
        "retained_progress": True,
        "training_horizon": 100000,
    }
    write_json(
        ROOT / "checkpoint.json",
        state
        | {
            "producer": reference(__file__),
            "source": "Byte-for-byte copy of the rolling original-horizon last.pt after the 86,000 save",
            "run": earlier["training_plan"],
            "target_slots": STEP * 16,
        },
    )
    selected = ROOT / "new-model"
    selected.mkdir()
    work = Path(earlier["work"])
    inputs = [
        *earlier["inputs"],
        reference(OLD / "plan.json"),
        reference(OLD / "collection/result.json"),
        reference(ROOT / "checkpoint.json"),
        state["checkpoint"],
    ]
    fresh = earlier | {
        "root": str(selected),
        "models": {NEW: state},
        "triplet_model": NEW,
        "inputs": inputs,
        "retained_checkpoint_receipt": reference(ROOT / "checkpoint.json"),
        "scope": "Original 100k horizon 86k EMA, fresh CPU inference on the 110 retained V120/50k observations.",
    }
    fresh_path = selected / "plan.json"
    write_json(fresh_path, fresh)
    os.sched_setaffinity(0, earlier["CPU_affinity"])
    os.nice(6)
    env = {
        **os.environ,
        "CUDA_VISIBLE_DEVICES": "",
        "PYTHONPATH": f"{work}/scripts:{work}/src",
        "OPENBLAS_NUM_THREADS": "2",
        "OMP_NUM_THREADS": "2",
    }
    watch.run_phase(
        ROOT,
        "collection",
        work / "scripts/collect_full_corpus_checkpoint_review.py",
        fresh_path,
        env,
    )
    binding = reference(selected / "collection/result.json")
    new = read_json(checked(binding))
    assert new["plan"] == reference(fresh_path) and new["models"] == {NEW: state}
    assert new["root_calls"] == {NEW: {"root": 110}}
    assert new["local_DINO"] == {"requests": 110, "executions": 110, "replays": 0}
    combined = fresh | {
        "root": str(ROOT),
        "models": {**{k: earlier["models"][k] for k in CONTROL}, NEW: state},
        "inputs": [*inputs, binding],
        "scope": "Original 100k horizon 86k EMA with saved V120/50k EMA controls and exact native inputs.",
    }
    plan_path = ROOT / "plan.json"
    write_json(plan_path, combined)
    out = ROOT / "collection"
    out.mkdir()
    records = []
    for i, (obs, saved, item) in enumerate(
        zip(earlier["observations"], selection, new["records"], strict=True)
    ):
        record = read_json(checked(item))
        assert record["id"] == obs["id"]
        assert record["input_fingerprints"] == obs["input_fingerprints"]
        assert len(record["variants"]) == 1 and record["variants"][0]["label"] == NEW
        assert record["variants"][0]["checkpoint"] == state["checkpoint"]
        target = out / f"case-{i:03d}.json"
        write_json(target, record | {"variants": [*saved, *record["variants"]]})
        records.append(reference(target))
    path = out / "result.json"
    write_json(
        path,
        {
            "plan": reference(plan_path),
            "records": records,
            "models": combined["models"],
            "fresh_collection": binding,
            "saved_controls": reference(OLD / "collection/result.json"),
            "fresh_root_calls": new["root_calls"],
            "fresh_local_DINO": new["local_DINO"],
            "fresh_collection_seconds": new["seconds"],
            "saved_predictions_reused": 220,
        },
    )
    watch.run_phase(
        ROOT, "report", work / "scripts/report_full_corpus_checkpoint_review.py", ROOT, env
    )
    write_json(
        ROOT / "complete.json",
        {
            "collection": reference(path),
            "report": reference(ROOT / "report/result.json"),
            "quality_status": "Numerical results and native boards produced. Independent audit and viewing pending.",
        },
    )


if __name__ == "__main__":
    main()
