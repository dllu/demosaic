"""Bind the 86k rolling checkpoint, LR horizon, executed logs and training time."""

import hashlib
import json
from pathlib import Path

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
experiment = root.parent / "full-corpus-scaling-v3"
checkpoint = checked(read_json(root / "checkpoint.json")["checkpoint"])
state = torch.load(checkpoint, map_location="cpu", mmap=True, weights_only=False)
assert state["step"] == 86000 and state["config"]["steps"] == 100000
assert len(state["model"]) == len(state["ema"]) == 91
assert len(state["optimizer"]["state"]) == 89
assert all(x["step"].item() == 86000 for x in state["optimizer"]["state"].values())


def milestone(path, step, expect_start, *, checkpointed=True):
    digest = hashlib.sha256()
    started, train, done = None, None, None
    with path.open("rb") as f:
        for line in f:
            digest.update(line)
            if not line.startswith(b'{"'):
                continue
            e = json.loads(line)
            if e.get("event") == "start":
                started = e["start_step"]
            if e.get("event") == "train" and e.get("step") == step:
                train = e
            if (
                e.get("event") == "checkpoint"
                and e.get("step") == step
                and e.get("phase") == "complete"
            ):
                done = e
                break
        stop = f.tell()
    assert started == expect_start and train and (done or not checkpointed)
    return {
        "log_prefix": {"path": str(path), "bytes": stop, "sha256": digest.hexdigest()},
        "start_step": started,
        "step": step,
        "train_log_at_milestone": train,
        "checkpoint_complete": done,
        "elapsed_through_training_log_seconds": train["seconds_per_step"] * (step - started),
    }


first = milestone(experiment / "00-scale-long100k.log", 1000, 0, checkpointed=False)
long = milestone(experiment / "production-handoff-v7/01-scale-long100k.log", 86000, 1000)
timing = sum(m["elapsed_through_training_log_seconds"] for m in (first, long))
write_json(
    root / "training-timing.json",
    {
        "auditor": reference(__file__),
        "checkpoint": reference(checkpoint),
        "recipe": read_json(root / "checkpoint.json")["run"],
        "first": first,
        "initial_worker_result": reference(experiment / "00-scale-long100k-result.json"),
        "resumed": long,
        "elapsed_through_training_logs_seconds": timing,
        "global_step": 86000,
        "optimizer_slots": len(state["optimizer"]["state"]),
        "examples": 86000 * 16,
        "model_tensors": len(state["model"]),
        "EMA_tensors": len(state["ema"]),
        "scope": "Training loop elapsed time before final validation/save events, separate from CPU inference time.",
    },
)
print(f"Training logs total {timing:.3f} seconds.")
