"""Select the donor waveform with measured second-harmonic evidence."""
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent
BANDLIMIT=ROOT.parent/"query-donor-bandlimit-v1"
COMPOSITION=ROOT.parent/"query-donor-composition-v1"
sys.path.insert(0,str(BANDLIMIT))
from bandlimit import CHECKED,GAIN,SIGMA,limit,phases,render
sys.path.insert(0,str(COMPOSITION))
from compose import composed

ARMS=("parent","ribbon","restricted","whole-query","directional")


def second_band(old,query,choice,terms,wb,matrix):
    """Preserve only independently supported donor second bands."""
    coordinates=np.arange(256)-127.5
    y,x=np.meshgrid(coordinates,coordinates,indexing="ij")
    known=phases(x.ravel(),y.ravel(),choice["geometry"])+choice["Q0_angles"]
    delta=(old-query).astype(float)
    intensity=np.mean(delta**2,axis=0)
    fast=gaussian_filter(intensity,3.5,mode="constant")
    slow=gaussian_filter(intensity,SIGMA,mode="constant")
    support=np.minimum(1,np.sqrt(fast/np.maximum(slow,1e-20)))
    weights=np.linalg.solve(matrix,np.ones(3))/wb
    weights/=weights[1]
    sum_aligned=np.zeros(x.shape,dtype=float)
    for term in terms:
        phi=(known@term["integer_phase"]).reshape(x.shape)
        sign=term["local_axis"][0]
        assert abs(sign)==1 and term["local_axis"][1]==0
        direction=sign*np.exp(1j*phi)
        coef=gaussian_filter(delta[1]*direction.conj(),SIGMA,mode="constant",truncate=3)
        amp=np.clip(2*coef.real,0,1.5*term["discovery"])
        sum_aligned+=amp*direction.real
    return (weights[:,None,None]*sum_aligned[None]*support[None]).astype(query.dtype)


def from_existing(query,donor,broad,raw,colors,noise,wb,matrix,state):
    if state["state"] not in ("donor-only","donor-and-checked-bands"):
        return {name:broad for name in ARMS},[]
    fundamentals,limited,_=limit(query,donor,raw,colors,wb,matrix,noise,state)
    choice=state["refined_result"]
    second=[r for r in choice["modes"]["locked"]if r["name"].startswith("second-")and r["accepted"]]
    if second:
        prior=fundamentals+second_band(donor,query,choice,second,wb,matrix)
        directional=prior+GAIN*render(raw,colors,noise,prior,wb,matrix,choice)["locked"]
    else:
        directional=limited
    return {"parent":query,"ribbon":broad,"restricted":limited,
            "whole-query":broad if second else limited,"directional":directional},[r["name"]for r in second]


def fit(raw,variance,colors,parent,box,noise,wb,matrix,span):
    x,y,w,h=box
    query=parent[...,y:y+h,x:x+w]
    local_raw=raw[...,y//2:(y+h)//2,x//2:(x+w)//2]
    donor,broad,state=composed(raw,variance,colors,parent,box,noise,wb,matrix,span)
    restored,terms=from_existing(query,donor,broad,local_raw,colors,noise,wb,matrix,state)
    selected=state.get("refined_result")
    history={"state":state["state"],"exterior":state.get("prior"),
             "geometry":state.get("refined"),"second":terms}
    if selected:
        history["witness"]=selected
    return restored,history
