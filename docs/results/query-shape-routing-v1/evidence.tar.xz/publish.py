"""Publish the scoped photo study and both reviewed GFX camera families."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from routing import BANDLIMIT,COMPOSITION,ROOT

RESULTS=Path("docs/results/query-shape-routing-v1")
IMAGES=Path("docs/images/query-shape-routing-v1")


def photo_note(name,index):
    if name=="quiet":
        return "Quiet core matches the base under all methods and looks smooth."
    if name=="absent":
        return "The stronger direction remains visible. The algorithms match the base restoration."
    if name=="wrong":
        return "After changing only the exterior orientation, the candidate matches the base. The matching exterior adds a faint second direction."
    if index==1:
        return "The broad donor keeps a slightly sharper wire profile. The directional output keeps both directions and softens some of the sharper crossings."
    if index==3:
        return "Some weak traces remain inside the true central gap. The directional output softens them slightly but the missing region still blends into the surrounding pattern."
    if index==4:
        return "The very faint second direction is most visible in the colored areas. The exact target has stronger crossing contrast."
    return "The donor preserves the narrow strong direction. Per-direction filtering softens the weak family. Fine intersections remain subtler than in the exact target."


def copy_board(row,directory,note):
    old=row["image"]
    src=checked(old)
    dst=IMAGES/directory/src.name
    dst.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(src,dst)
    assert reference(dst)["sha256"]==old["sha256"]
    with Image.open(dst)as f:
        if "order"in row:
            assert f.size==(160*len(row["order"]),160)
        else:
            for panel in row["panels"]:
                x,y,w,h=panel["png_xywh"]
                assert w==h==160 and x+w<=f.width and y+h<=f.height
        f.verify()
    return row|{"image":{"path":str(dst),"sha256":old["sha256"]},"actual_viewing":note}


def main():
    nonlocal_results=reference(ROOT/"scores.json")
    overview=read_json(checked(nonlocal_results))
    strength=read_json(ROOT/"strength.json")
    exact=read_json(ROOT/"native/manifest.json")
    verification=read_json(ROOT/"audit.json")
    real=read_json(checked(verification["standing"]))
    assert nonlocal_results==strength["scores"]==exact["scores"]==verification["scores"]
    assert exact["checkpoint"]==real["checkpoint"]
    synthetic=[]
    for groups in (exact["rows"],strength["figures"]):
        for t in groups:
            synthetic.append(t|{"boards":[copy_board(b,"exact",photo_note(b["title"],t["index"]))for b in t["boards"]]})
    camera=[]
    for row in real["rows"]:
        name=row["id"]
        if name.endswith("mesh-left"):
            note="Both gates select the restricted profile. The two fine directions remain faintly visible, with softer crossings than the earlier exterior result."
        elif "sky" in name:
            note="The sky remains smooth and byte-identical."
        elif "chain-link" in name or name.endswith("mesh-right"):
            note="The previous checked lattice output is reproduced. The fine right crossings remain uneven and lack definition."
        else:
            note="The preceding result remains pixel-identical. Fine building or leaf detail stays soft."
        camera.append(copy_board(row,"standing",note))
    assert len(synthetic)==4 and sum(len(r["boards"])for r in synthetic)==20
    assert len(camera)==8
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"exact":exact|{"rows":synthetic},"standing":real|{"rows":camera},
                         "actual_native_viewing_complete":True})
    RESULTS.mkdir(parents=True,exist_ok=True)
    bundle=RESULTS/"evidence.tar.xz"
    frozen=(BANDLIMIT/"bandlimit.py",COMPOSITION/"compose.py",COMPOSITION/"probe.py",
            ROOT.parent/"query-checked-junctions-v1"/"model_delivery.py",
            Path("src/demosaic/_mesh_profiles.py"),Path("src/demosaic/_mesh_frequency.py"),
            Path("src/demosaic/mesh_refinement.py"))
    with tarfile.open(bundle,"x:xz")as archive:
        for glob in ("*.py","*.json","*.log","initial/*.py","initial/*.log","native/manifest.json","standing/manifest.json"):
            for f in sorted(ROOT.glob(glob)):
                archive.add(f,arcname=f.relative_to(ROOT))
        for f in frozen:
            archive.add(f,arcname="preceding/"+f.name)
    write_json(RESULTS/"publication.json",{"study":"query-shape-routing-v1","checkpoint":exact["checkpoint"],
          "training_performed":False,"numeric_evaluation_complete":True,"actual_native_viewing_complete":True,
          "scoped_photo_panel":overview["summary"],"admission_states":overview["states"],"strength_control":strength["matched_mixed_strength"],
          "standing_shape_routing":{r["id"]:r["camera_RGB_RMS_to_ribbon_DN16"]for r in real["rows"]},
          "numeric_source":nonlocal_results,"frozen_sources":[reference(f)for f in frozen],
          "audit":reference(ROOT/"audit.json"),"manifest":reference(manifest),"archive":reference(bundle),
          "scope":"Evaluated automatic exterior-frequency crop inference on 24 synthetic photo backgrounds at two sensor priors, with both standing GFX families viewed. No comparable full-photo or camera scores."})


if __name__=="__main__":
    main()
