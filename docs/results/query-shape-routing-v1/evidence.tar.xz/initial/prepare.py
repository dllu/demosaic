"""Freeze disjoint photo fields for automatic RAW donor shape routing."""
from collections import Counter
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/"query-checked-junctions-v1"
sys.path.insert(0,str(ROOT.parent/"weak-edge-distill-v1"))
from edge_data import decode,row_for

SEED=438902601747
KINDS=("broad","narrow","mixed","interrupted")
TYPES=("present","outside-only","strong-only","quiet")
PROFILES={"iso400":{"shot":8e-5,"read":2.56e-8,"exposure":.33},
          "iso6400":{"shot":.00128,"read":6.5536e-6,"exposure":.33}}
BOX=(128,128,256,256)


def freeze():
    marker=reference(PREVIOUS/"plan.json")
    base=read_json(checked(marker))
    extra=tuple(reference(ROOT.parent/p)for p in (
        "query-donor-composition-v1/plan.json","query-donor-bandlimit-v1/width-plan.json",
        "paired-repeat-stability-v2/evaluation-plan.json"))
    blocked=set()
    for record in (marker,*extra,*base["excluded"]):
        item=read_json(checked(record))
        blocked.update(x["source"]["id"]for x in item.get("sources",item.get("rows",item.get("heldout_rows",[]))))
    cohort=base["cohort"]
    eligible=[row for row in read_json(checked(cohort))["source_metadata"]if row["split"]=="val"
              and row["bin_factor"]==4 and min(row["shape"][:2])>=512 and np.prod(row["shape"][:2])<=7_000_000
              and row["id"]not in blocked]
    order=sorted(eligible,key=lambda p:hashlib.sha256(f"{SEED}/{p['id']}".encode()).hexdigest())
    assert len(order)>=24, len(order)
    train=read_json(ROOT.parent/"scene-full-epoch-v1/plan.json")["train_manifest"]
    with checked(train).open()as f:
        train_ids={json.loads(z)["id"]for z in f}
    sources=[]
    for i,photo in enumerate(order[:24]):
        assert photo["id"]not in train_ids
        patch,=scene_crop_boxes(photo["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"source-box"))
        rng=np.random.default_rng(scene_seed(SEED,i,"geometry"))
        incl=rng.uniform(.42,.85,2)
        f=rng.uniform(.082,.128,2)
        geometry=[[f[0]*math.cos(incl[0]),f[0]*math.sin(incl[0])],
                  [f[1]*math.cos(incl[1]),-f[1]*math.sin(incl[1])]]
        reg={"family":KINDS[i%4],"frequency":geometry,"phase":rng.uniform(-math.pi,math.pi,2).tolist(),
             "strength":[float(rng.uniform(.009,.015)),float(rng.uniform(.0048,.010))],
             "width":rng.uniform(.088,.132,2).tolist(),"edge":float(rng.uniform(-25,25)),
             "angle":float(rng.uniform(-1.6,1.6)),"tint":rng.uniform(.07,.16,3).tolist()}
        sources.append(row_for(photo,i,SEED)|{"box":patch,"geometry":reg})
    write_json(ROOT/"plan.json",{"driver":reference(__file__),"prior":marker,"cohort":cohort,
               "excluded":list(extra)+base["excluded"],"training_manifest":train,
               "base":base["base"],"profiles":PROFILES,"roles":TYPES,"query":BOX,"sources":sources,
               "donor_span":80,"seed":SEED,"scope":"24 new photo IDs in four waveform groups. Automatic exterior frequency nomination. Matching and rotated exteriors share native Bayer samples. One sensor draw per role and noise prior."})


def exact(photo,geometry):
    axis=torch.arange(512)-255.5
    y,x=torch.meshgrid(axis,axis,indexing="ij")
    grid=torch.maximum(x.abs(),y.abs())
    outer=((grid-132)/27).clamp(0,1)
    exterior_only=((grid-108)/18).clamp(0,1)
    flat=((128-grid)/57).clamp(0,1)
    smooth=.085+.52*F.avg_pool2d(photo[None],11,stride=1,padding=5,count_include_pad=False)[0]
    z=x*math.cos(geometry["angle"])+y*math.sin(geometry["angle"])-geometry["edge"]
    step=torch.sigmoid(z/1.3)
    base=smooth+torch.tensor(geometry["tint"])[:,None,None]*step

    def phases(rotation):
        c,s=math.cos(rotation),math.sin(rotation)
        return [2*math.pi*((fx*c-fy*s)*x+(fx*s+fy*c)*y)+p
                for (fx,fy),p in zip(geometry["frequency"],geometry["phase"],strict=True)]

    def profile(phase,width,narrow):
        result=phase.cos()
        if narrow:
            for m in range(2,9):
                result=result+math.exp(-2*math.pi**2*width**2*(m*m-1))*(m*phase).cos()
        return result

    tag=geometry["family"]
    p,q=phases(0)
    a,b=(profile(p,geometry["width"][0],tag!="broad"),
         profile(q,geometry["width"][1],tag in ("narrow","interrupted")))
    side,weak=geometry["strength"]
    front=base+side*a
    footprint=torch.ones_like(x)
    if tag=="interrupted":
        angle=geometry["angle"]+.8
        u=x*math.cos(angle)+y*math.sin(angle)
        v=-x*math.sin(angle)+y*math.cos(angle)
        footprint=((torch.hypot((u-10)/29,v/50)-1)*4).clamp(0,1)
    amplitude=.58+.42*step
    support=torch.maximum(footprint,exterior_only)
    addition=weak*b*amplitude*(1-.28*(.5+.5*p.cos()))+.19*weak*p.cos()*q.cos()
    signal=front+addition*support
    outside=front+addition*exterior_only
    flat_color=signal[:,198:314,198:314].mean((-2,-1),keepdim=True)
    quiet=torch.where(flat==1,flat_color,torch.lerp(signal,flat_color,flat))
    cp,cq=phases(.57)
    shell=base+.025*p.cos()+.025*q.cos()
    bad=base+.025*cp.cos()+.025*cq.cos()
    targets=tuple(torch.lerp(v,shell,outer)for v in (signal,outside,front,quiet))
    assert all(0<float(z.min()) and float(z.max())<1 for z in (*targets,bad))
    return targets,bad,support,addition


def collect():
    torch.set_num_threads(2)
    frozen=reference(ROOT/"plan.json")
    plan=read_json(checked(frozen))
    path=ROOT/"inputs"
    path.mkdir()
    files=[]
    for row in plan["sources"]:
        i=row["index"]
        targets,wrong,support,increment=exact(decode(row["source"],row["box"]),row["geometry"])
        for noise,setting in PROFILES.items():
            camera=replace(sample_scene_recipe(SEED),**(row["camera"]|setting))
            seeds=[scene_seed(SEED,i,f"{noise}/{role}")for role in (*TYPES,"rotated")]
            scans=[observe_scene(z,replace(camera,noise_seed=s))for z,s in zip((*targets,wrong),seeds,strict=True)]
            stored={k:torch.stack([getattr(v,k)for v in scans[:4]]).numpy()
                    for k in ("packed","variance","colors","wb","matrix","target")}
            mask=np.ones((256,256),bool)
            mask[48:208,48:208]=False
            for name in ("packed","variance"):
                original=stored[name]
                other=original.copy()
                other[...,mask]=getattr(scans[-1],name).numpy()[None,...,mask]
                np.testing.assert_array_equal(other[...,48:208,48:208],original[...,48:208,48:208])
                stored["rotated_"+name]=other
            stored["support"]=support.numpy()[128:384,128:384]
            stored["weak_linear"]=increment.numpy()[128:384,128:384]
            output=path/f"{i:03d}-{noise}.npz"
            np.savez(output,**stored)
            files.append({"index":i,"noise":noise,"seeds":seeds,"input":reference(output),
                          "fingerprints":{key:fingerprint(v)for key,v in stored.items()}})
        print(i,row["geometry"]["family"],flush=True)
    assert Counter(r["geometry"]["family"]for r in plan["sources"])=={k:6 for k in KINDS}
    write_json(ROOT/"captures.json",{"source":frozen,"rows":files,"driver":reference(__file__)})


if __name__=="__main__":
    freeze()
    collect()
