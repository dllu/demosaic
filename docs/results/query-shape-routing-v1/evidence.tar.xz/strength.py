"""Compare mixed profiles at equal aligned response and show the gap tradeoff."""
from itertools import permutations

import numpy as np
import torch

from review import CENTER,ROOT,harmonic_readout,luma,native,read_fields,rms
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def aligned_permutation(record,frequency):
    f=np.array(record["geometry"])[:,:2]
    g=np.array(frequency)
    by_column=[sum(min(np.linalg.norm(f[i]-g[k]),np.linalg.norm(f[i]+g[k]))for i,k in enumerate(order))
               for order in permutations(range(2))]
    return (0,1)if by_column[0]<=by_column[1]else (1,0)


def main():
    torch.set_num_threads(2)
    bound=reference(ROOT/"scores.json")
    totals=read_json(checked(bound))
    raw=read_json(checked(totals["results"]))
    plan=read_json(checked(totals["config"]))
    photos={x["index"]:x for x in plan["sources"]}
    ids={(r["index"],r["noise"]):r for r in raw["rows"]}
    figures=[]
    output=ROOT/"supplement"
    output.mkdir()
    for family in ("narrow","interrupted"):
        chosen=next(r for r in totals["rows"]if r["noise"]=="iso6400"and r["family"]==family
                    and r["present_routed"]["matching"])
        case=ids[chosen["index"],chosen["noise"]]
        figures.append(native(case,photos[case["index"]],plan,output,"directional"))
    summary={}
    for noise in ("iso400","iso6400"):
        table=totals["summary"][noise]["mixed"]["metrics"]["true_response_pct"]["means"]
        pop=table["matching/parent"]
        gain=float((table["matching/directional"]-pop)/(table["matching/whole-query"]-pop))
        family=[x for x in totals["rows"]if x["noise"]==noise and x["family"]=="mixed"]
        comparisons=[]
        for selected in family:
            row=ids[selected["index"],noise]
            source=photos[row["index"]]
            nominal=source["geometry"]["frequency"]
            fields,outputs=read_fields(row)
            known=luma(fields["target"],fields)
            target_increment=(known[0]-known[1])[CENTER]
            baseline=outputs["parent"]
            control=baseline+gain*(outputs["whole-query"]-baseline)
            supervised=harmonic_readout(nominal)
            measured={}
            for key,model in (("whole-query-at-matched-response",control),("directional",outputs["directional"])):
                y=luma(model,fields)
                residual=(y[0]-y[1])[CENTER]-target_increment
                measured[key]={"increment_RMS_DN16":rms(residual),
                    "weak_second_error_DN16":float(np.linalg.norm(supervised@residual.ravel())*65535/np.sqrt(2))}
            choice=row["decisions"][0]["matching"]
            supports=[]
            if choice["geometry"]:
                ordering=aligned_permutation(choice,nominal)
                supports=[("strong","weak")[ordering[int(term[-1])]]for term in choice["second"]]
            comparisons.append({"index":row["index"],"admitted_direction_truth_assignment":supports,"metrics":measured})
        summary[noise]={"ribbon_gain_relative_to_parent":gain,"per_case":comparisons,
                         "means":{m:{k:float(np.mean([r["metrics"][m][k]for r in comparisons]))
                                    for k in comparisons[0]["metrics"][m]}for m in comparisons[0]["metrics"]}}
    write_json(ROOT/"strength.json",{"driver":reference(__file__),"scores":bound,"matched_mixed_strength":summary,
        "figures":figures,"scope":"Fixed outputs. Retrospective cohort-level gain on mixed cases matches mean exact weak response before reading the projected residual harmonics."})


if __name__=="__main__":
    main()
