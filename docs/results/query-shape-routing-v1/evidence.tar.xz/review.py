"""Score and render the complete automatic shape-routing comparison."""
from collections import Counter
from itertools import permutations
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from routing import ROOT,ARMS
from demosaic.archive_metrics import display,linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint

LUMA=np.array([.2126,.7152,.0722])
QUERY=np.s_[...,128:384,128:384]
PACKED=np.s_[...,64:192,64:192]
ROI=np.s_[...,48:208,48:208]
CENTER=np.s_[64:192,64:192]
KINDS=("broad","narrow","mixed","interrupted")
CONTEXT=("matching","rotated")


def read_fields(row):
    with np.load(checked(row["input"]),allow_pickle=False)as f:
        data={k:f[k]for k in ("packed","colors","wb","matrix","target","support","weak_linear")}
    data["target"]=data["target"][QUERY]
    data["packed"]=data["packed"][PACKED]
    with np.load(checked(row["prediction"]),allow_pickle=False)as f:
        result={k:f[k]for k in f.files}
    return data,result


def luma(value,data):
    calibration={k:data[k]for k in ("wb","matrix")}
    return np.einsum("c,bchw->bhw",LUMA,linear_rgb(value,calibration))


def rms(value):
    return float(np.sqrt(np.mean(value**2))*65535)


def harmonic_readout(freq):
    vis=np.arange(128)-63.5
    y,x=np.meshgrid(vis,vis,indexing="ij")
    a,b=(2*np.pi*(x*fx+y*fy) for fx,fy in freq)
    nuisance=[np.ones_like(x),x/64,y/64,x*x/4096,y*y/4096,x*y/4096]
    orders=(*[a,b,2*a,a+b,a-b,3*a,3*b],2*b)
    design=np.column_stack([e.ravel()for e in (nuisance+[e for q in orders for e in (np.cos(q),np.sin(q))])])
    kernel=np.sqrt(np.outer(np.hanning(128),np.hanning(128))).ravel()
    return np.linalg.pinv(kernel[:,None]*design)[-2:]*kernel


def geometry_error(actual,nominal):
    if actual is None:
        return None
    current=np.asarray(actual)[:,:2]
    def distance(v,w):
        return min(np.linalg.norm(v-w),np.linalg.norm(v+w))
    tests=[[float(distance(p,q))for p,q in zip(current,choice,strict=True)] for choice in permutations(np.asarray(nominal))]
    return min(tests,key=lambda r:sum(r))


def score(row,source):
    data,output=read_fields(row)
    base=luma(output["parent"],data)
    exact=luma(data["target"],data)
    raw=(exact[0]-exact[1])[CENTER]
    true_flat=exact[3][CENTER]
    assert np.all(true_flat==true_flat[0,0])
    control=(exact[1]-exact[2])[CENTER]
    assert not control.any()
    gap=data["support"][CENTER]==0
    if gap.any():
        assert not raw[gap].any()
    projection=harmonic_readout(source["geometry"]["frequency"])
    result={}
    for ctx in CONTEXT:
        for name in ARMS:
            predicted=output["rotated_"+name if ctx=="rotated"and name!="parent"else name]
            value=luma(predicted,data)
            change=value-base
            recovered=(value[0]-value[1])[CENTER]
            error=recovered-raw
            second_error=projection@error.ravel()
            measurements={"true_response_pct":float(100*np.sum(raw*recovered)/np.sum(raw*raw)),
                          "increment_RMS_DN16":rms(error),"present_RMS_DN16":rms((value-exact)[0][CENTER]),
                          "weak_second_error_DN16":float(np.linalg.norm(second_error)*65535/np.sqrt(2)),
                          "present_added_RMS_DN16":rms(change[0][CENTER]),
                          "quiet_added_RMS_DN16":rms(change[3][CENTER]),"outside_only_added_RMS_DN16":rms(change[1][CENTER]),
                          "strong_only_added_RMS_DN16":rms(change[2][CENTER])}
            if gap.any():
                measurements["gap_added_RMS_DN16"]=rms(change[0][CENTER][gap])
            result[ctx+"/"+name]=measurements
    primary=row["decisions"][0]["matching"]
    secondary=row["decisions"][0]["rotated"]
    err={k:geometry_error(v["geometry"],source["geometry"]["frequency"])
         for k,v in zip(CONTEXT,(primary,secondary),strict=True)}
    return {"index":row["index"],"noise":row["noise"],"family":source["geometry"]["family"],"metrics":result,
            "present_geometry_error_cycles_per_pixel":err,
            "present_routed":{k:r["state"].startswith("donor-")
                               for k,r in zip(CONTEXT,(primary,secondary),strict=True)},
            "second":{k:r["second"]for k,r in zip(CONTEXT,(primary,secondary),strict=True)}}


def aggregate(all_metrics):
    settings={}
    rand=np.random.default_rng(4281567)
    for noise in ("iso400","iso6400"):
        scopes={}
        for family in ("all",*KINDS):
            rows=[r for r in all_metrics if r["noise"]==noise and family in ("all",r["family"])]
            draws=rand.integers(len(rows),size=(10000,len(rows)))
            use=list(rows[0]["metrics"]["matching/parent"])
            if family!="interrupted" and "gap_added_RMS_DN16"in use:
                use.remove("gap_added_RMS_DN16")
            result={}
            for f in use:
                numbers={key:np.asarray([r["metrics"][key][f]for r in rows]) for key in rows[0]["metrics"]}
                pairs=(("directional","ribbon"),("whole-query","ribbon"),("restricted","ribbon"),
                       ("directional","whole-query"),("directional","restricted"),
                       ("directional","parent"))
                intervals={}
                for a,b in pairs:
                    x=numbers["matching/"+a]-numbers["matching/"+b]
                    intervals[a+"-vs-"+b]=[float(x.mean()),*np.quantile(x[draws].mean(1),(0.025,0.975)).tolist()]
                result[f]={"means":{k:float(v.mean())for k,v in numbers.items()},"source_paired_95pct":intervals}
            scopes[family]={"count":len(rows),"metrics":result,
                            "matching_active":sum(r["present_routed"]["matching"]for r in rows),
                            "mismatched_active":sum(r["present_routed"]["rotated"]for r in rows),
                            "matching_has_second":sum(bool(r["second"]["matching"])for r in rows)}
        settings[noise]=scopes
    return settings


def native(row,source,plan,dest,arm):
    data,models=read_fields(row)
    files={}
    for k,v in (models|{"exact":data["target"],"noisy":malvar(torch.from_numpy(data["packed"]),
                                                            torch.from_numpy(data["colors"])).numpy()}).items():
        rgb=display(v[ROI],{k:data[k]for k in ("wb","matrix")},exposure=2).transpose(0,2,3,1)
        files[k]=np.rint(rgb*255).astype(np.uint8)
    all_variants=("noisy",*ARMS,"exact")
    galleries=[]
    for name,items,role in (
        ("triplet",("noisy",arm,"exact"),0),("comparison",all_variants,0),
        ("absent",all_variants,1),("quiet",all_variants,3),
        ("wrong",("noisy","parent",arm,"rotated_"+arm,"exact"),0),
    ):
        path=dest/f"{row['index']:03d}-{row['noise']}-{name}.png"
        Image.fromarray(np.concatenate([files[m][role]for m in items],axis=1)).save(path,optimize=True)
        galleries.append({"image":reference(path),"order":items,"case_role":role,"title":name})
    return {"index":row["index"],"noise":row["noise"],"source":source["source"],"source_box":source["box"],
            "native_ROI":[48,48,160,160],"profile":plan["profiles"][row["noise"]],
            "display_exposure":2,"input":row["input"],"prediction":row["prediction"],
            "CFA":source["camera"]["pattern"],"primary_arm":arm,"boards":galleries}


def main():
    torch.set_num_threads(2)
    measured=reference(ROOT/"results.json")
    answer=read_json(checked(measured))
    parent=read_json(checked(answer["parent_receipts"]))
    dataset=read_json(checked(parent["captures"]))
    plan=read_json(checked(dataset["source"]))
    rows=[]
    for row in answer["rows"]:
        rows.append(score(row,plan["sources"][row["index"]]))
    summaries=aggregate(rows)
    states={}
    for noise in plan["profiles"]:
        for ctx in CONTEXT:
            for j,label in enumerate(plan["roles"]):
                states[noise+"/"+ctx+"/"+label]=dict(Counter(r["decisions"][j][ctx]["state"]for r in answer["rows"]if r["noise"]==noise))
    result=ROOT/"scores.json"
    write_json(result,{"driver":reference(__file__),"results":measured,"config":dataset["source"],"summary":summaries,"states":states,"rows":rows})
    output=ROOT/"native"
    output.mkdir()
    seen=[]
    for group in ("broad","mixed"):
        candidates=[r for r in rows if r["family"]==group and r["present_routed"]["matching"]]
        if not candidates:
            candidates=[r for r in rows if r["family"]==group]
        shown=sorted(candidates,key=lambda r:(r["noise"]!="iso6400",
                                               not bool(r["second"]["matching"])if group=="mixed"else False,r["index"]))[0]
        source=plan["sources"][shown["index"]]
        match=next(r for r in answer["rows"]if r["index"]==shown["index"]and r["noise"]==shown["noise"])
        seen.append(native(match,source,plan,output,"directional"))
    write_json(output/"manifest.json",{"driver":reference(__file__),"scores":reference(result),
        "checkpoint":answer["checkpoint"],"rows":seen,
        "selection":"First active ISO6400 broad and mixed; prefer admitted second in mixed. Fall back to other retained inputs when none pass."})


if __name__=="__main__":
    main()
