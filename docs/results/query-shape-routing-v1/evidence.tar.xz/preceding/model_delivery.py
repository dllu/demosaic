"""Test phase-locked second harmonics and cross terms with reserved native green sites."""
import math
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import map_coordinates

ROOT=Path(__file__).resolve().parent
EXTERIOR=ROOT.parent/"query-exterior-witness-v1"
sys.path.insert(0,str(EXTERIOR))
from witness import curvature,design_terms,interior,project

TERMS=(("second-0",(2,0)),("second-1",(0,2)),("sum",(1,1)),("difference",(1,-1)))
MODES=("locked","free")
CENTER=np.array([-72.,-24.,24.,72.])
GAIN=.6318481533720487


def fit(a,w,y):
    inv=np.linalg.inv((a.T*w)@a)
    return inv@((a.T*w)@y),inv


def phases(x,y,geometry):
    fields=[]
    for fx,fy,k in geometry:
        tangent=(-fy*x+fx*y)/math.hypot(fx,fy)
        fields.append(2*math.pi*(fx*x+fy*y+.5*k*tangent*tangent))
    return np.stack(fields,axis=1)


def valid_terms(geometry):
    f=np.array(geometry)[:,:2]
    result=[]
    for label,key in TERMS:
        frequency=np.array(key)@f
        if np.abs(frequency).sum()>=.48 or np.linalg.norm(frequency)<.037:
            continue
        too_close=lambda f2:min(np.linalg.norm(frequency-f2),np.linalg.norm(frequency+f2))<.018
        if any(too_close(p)for p in f)or any(too_close(row[2])for row in result):
            continue
        result.append((label,key,frequency))
    return result


def choose_nuisance(data,boundary,pair):
    x,y,p,*_=data
    bg,principal=design_terms(data,pair)
    b=np.column_stack((bg,x*x/128**2,y*y/128**2,x*y/128**2))
    if boundary is not None:
        a,d,_=boundary
        dist=x*math.cos(a)+y*math.sin(a)-d
        # A measured step can carry both its own color offset and spatial slope.
        f=np.clip(.50+dist/5,0,1)
        b=np.column_stack((b,f[:,None]*bg))
    return b,principal


def witness_out(x,y,raw,var,fold,used,terms,nuisance):
    raw_scores=[]
    for i in (2,3):
        choose=used&(fold==i)
        radial=np.exp(-.5*(x[choose]**2+y[choose]**2)/75**2)
        w=radial/var[choose]
        residual=project(terms[choose],nuisance[choose],w).ravel()
        signal=float((w*residual*raw[choose]).sum())
        proxy=float(((w*residual)**2*var[choose]).sum())
        raw_scores.append((signal,proxy))
    standardized=[s/max(v,1e-20)**.5 for s,v in raw_scores]
    combined=sum(s for s,_ in raw_scores)/max(1e-20,sum(v for _,v in raw_scores))**.5
    return {"scores":standardized,"pooled":float(combined)}


def select(packed,colors,noise,geometry):
    if not geometry:
        return {"observed":False,"modes":{k:[]for k in MODES}}
    data,_,boundary=interior(packed,colors,noise)
    x,y,p,raw,var,fold=data
    primitive,carrier=choose_nuisance(data,boundary,geometry)
    inner=np.maximum(abs(x),abs(y))<=96
    trained=inner&(fold==0)
    w=np.exp(-.5*(x[trained]**2+y[trained]**2)/75**2)/var[trained]
    coeff,_=fit(np.column_stack((primitive[trained],carrier[trained])),w,raw[trained])
    beta=coeff[-4:].reshape(2,2)
    angles=np.arctan2(-beta[:,1],beta[:,0])
    known=phases(x,y,geometry)+angles
    fundamentals=[]
    for direction in (0,1):
        hold=1-direction
        primary=np.cos(known[:,direction])
        null=np.column_stack((primitive,carrier[:,2*hold:2*hold+2]))
        fundamentals.append(witness_out(x,y,raw,var,fold,inner,primary,null))
    # The original pair may involve Q1. New harmonic decisions require support on Q2 and Q3.
    family=valid_terms(geometry)
    if not family:
        return {"observed":False,"modes":{k:[]for k in MODES},"fundamentals":fundamentals}
    individual=[known@key for _,key,_ in family]
    locked=np.stack([angle for a in individual for angle in (np.cos(a),)],axis=1)
    both=np.stack([angle for a in individual for angle in (np.cos(a),np.sin(a))],axis=1)
    prim=np.column_stack((primitive,carrier))
    gamma,_=fit(np.column_stack((prim[trained],locked[trained])),w,raw[trained])
    theta,_=fit(np.column_stack((prim[trained],both[trained])),w,raw[trained])
    outputs={key:[]for key in MODES}
    admitted=all(p["pooled"]>=2.75 and min(p["scores"])>0 for p in fundamentals)
    for j,(label,key,frequency) in enumerate(family):
        levels=((gamma[len(prim[0])+j],0.),theta[len(prim[0])+2*j:len(prim[0])+2*j+2])
        for mode,values in zip(MODES,levels,strict=True):
            sign=np.array(values,dtype=float)
            magnitude=np.linalg.norm(sign)
            sign=sign/max(magnitude,1e-20)
            target=both[:,2*j:2*j+2]@sign
            suffix=np.delete(both,[2*j,2*j+1],axis=1)
            null=np.column_stack((prim,suffix))
            support=witness_out(x,y,raw,var,fold,inner,target,null)
            outputs[mode].append({"name":label,"integer_phase":list(key),"frequency":frequency.tolist(),
               "local_axis":sign.tolist(),"discovery":float(magnitude),**support,
               "accepted":bool(admitted and min(support["scores"])>=.9 and support["pooled"]>=3.25)})
    return {"observed":True,"fundamentals":fundamentals,"Q0_angles":angles.tolist(),
            "geometry":geometry,"boundary":boundary,"modes":outputs}


def render(packed,colors,noise,parent,wb,matrix,selected):
    zero=np.zeros_like(parent)
    if not selected["observed"]or not any(t["accepted"]for v in selected["modes"].values()for t in v):
        return {k:zero for k in MODES}
    data,_,boundary=interior(packed,colors,noise)
    x,y,p,raw,var,fold=data
    first,carrier=choose_nuisance(data,boundary,selected["geometry"])
    rad=np.maximum(abs(x),abs(y))<=101
    known=phases(x,y,selected["geometry"])+np.array(selected["Q0_angles"])
    coords=np.arange(256)-127.5
    Y,X=np.meshgrid(coords,coords,indexing="ij")
    output_phase=phases(X.ravel(),Y.ravel(),selected["geometry"])+np.array(selected["Q0_angles"])
    coords_green=parent[1,(y+127.5).astype(int),(x+127.5).astype(int)]
    gains=np.linalg.solve(matrix,np.ones(3))/wb
    gains=gains/gains[1]
    edge=(112-abs(coords))/24
    taper=edge.clip(0,1)[:,None]*edge.clip(0,1)[None,:]
    coarse=(coords-CENTER[0])/48
    gy,gx=np.meshgrid(coarse,coarse,indexing="ij")
    base=np.column_stack((first,carrier))
    result={}
    for mode,records in selected["modes"].items():
        accepted=[j for j,item in enumerate(records)if item["accepted"]]
        response=np.zeros((256,256))
        if not accepted:
            result[mode]=zero
            continue
        extra=[]
        for r in records:
            angle=known@r["integer_phase"]
            extra.extend((np.cos(angle),np.sin(angle)))
        design=np.column_stack((base,*extra))
        coef=[]
        for y0 in CENTER:
            for x0 in CENTER:
                field=(x-x0)**2+(y-y0)**2
                weight=np.exp(-.5*field/35**2)
                pieces=[]
                for part in (1,2,3):
                    mask=rad&(fold==part)&(field<=80**2)
                    w=weight[mask]/var[mask]
                    delta=np.stack((raw[mask],coords_green[mask]),axis=1)
                    local=design[mask]
                    cov=np.linalg.pinv((local.T*w)@local,hermitian=True,rcond=1e-9)
                    beta=cov@((local.T*w)@delta)
                    pieces.append((beta[len(base[0]):],cov[len(base[0]):,len(base[0]):]))
                coef.append(pieces)
        for index in accepted:
            item=records[index]
            vector=np.array(item["local_axis"])
            s=slice(2*index,2*index+2)
            weights=[]
            for triplet in coef:
                waves=np.array([vector@p[0][s]for p in triplet])
                v=np.array([vector@p[1][s,s]@vector for p in triplet])
                # Subtract the parent along the accepted fixed axis after pooling phases.
                # Bound the correction by the whole-query Q0 coefficient.
                evidence=np.mean([max(0,waves[a,0])*max(0,waves[b,0]) for a,b in ((0,1),(0,2),(1,2))])
                floor=np.mean([(v[a]*v[b])**.5 for a,b in ((0,1),(0,2),(1,2))])
                shrink=max(0.,1-floor/max(evidence,1e-20))
                before=np.average(waves,weights=1/v,axis=0)
                cv=float(np.clip(before[0]*shrink-max(0,before[1]),0,item["discovery"]*1.5))
                weights.append(cv)
            scalars=map_coordinates(np.asarray(weights).reshape(4,4),[gy,gx],order=1,mode="nearest",prefilter=False)
            phase=output_phase@item["integer_phase"]
            response+=scalars*(vector[0]*np.cos(phase)+vector[1]*np.sin(phase)).reshape(256,256)
        result[mode]=(response[None]*gains[:,None,None]*taper[None]).astype(np.float32)
    return result
