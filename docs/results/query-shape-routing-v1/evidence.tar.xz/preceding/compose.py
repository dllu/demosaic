"""Apply the checked harmonic residual above a verified exterior donor fit."""
from pathlib import Path
import sys

import numpy as np

from demosaic.mesh_refinement import _overlap_correction
from probe import probe

ROOT=Path(__file__).resolve().parent
LAST=ROOT.parent/"query-checked-junctions-v1"
sys.path.insert(0,str(LAST))
from model_delivery import GAIN, render


def composed(raw, variance, colors, full_parent, box, noise, wb, matrix, span):
    left,top,w,h=box
    roi=(left+16,top+16,w-32,h-32)
    region=np.s_[...,top:top+h,left:left+w]
    query=full_parent[region]
    pick=probe(raw,colors,box,noise,span)
    if pick is None:
        return query,query,{"state":"no-donor-pair"}
    choice=pick["refined_result"]
    if not all(z["pooled"]>=2.75 and min(z["scores"])>0 for z in choice["fundamentals"]):
        return query,query,pick|{"state":"query-fundamentals-rejected"}
    old,_=_overlap_correction(full_parent,raw,variance,colors,box,roi,noise,pick["prior"])
    if old is None or not np.any(old):
        return query,query,pick|{"state":"overlap-rejected"}
    donor=query.copy()
    donor[...,16:240,16:240]+=old
    cropped=raw[...,top//2:(top+h)//2,left//2:(left+w)//2]
    above=render(cropped,colors,noise,donor,wb,matrix,choice)["locked"]
    return donor,donor+GAIN*above,pick|{"state":"donor-and-checked-bands" if np.any(above)else "donor-only"}
