"""Suppress unchecked higher bands implied by a donor ribbon profile."""
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent
COMPOSE=ROOT.parent/"query-donor-composition-v1"
CHECKED=ROOT.parent/"query-checked-junctions-v1"
sys.path.insert(0,str(CHECKED))
from model_delivery import GAIN,phases,render

SIGMA=10.0


def isolate(delta,geometry):
    """Keep the two measured fundamental bands and their complex envelopes."""
    height,width=delta.shape[-2:]
    x=(np.arange(width)-.5*(width-1))
    y=(np.arange(height)-.5*(height-1))
    yy,xx=np.meshgrid(y,x,indexing="ij")
    bank=phases(xx.ravel(),yy.ravel(),geometry).T.reshape(2,height,width)
    result=np.zeros(delta.shape,dtype=float)
    signal=delta.astype(float)
    for phase in bank:
        carrier=np.exp(1j*phase)
        mix=signal*carrier.conj()
        envelope=gaussian_filter(mix,sigma=(0,SIGMA,SIGMA),mode="constant",truncate=3.0)
        result+=2*np.real(carrier*envelope)
    return result.astype(delta.dtype)


def limit(parent,donor,raw,cfa,wb,matrix,noise,state):
    """Restore only measured fundamentals, then add verified RAW residual bands."""
    if state["state"] not in ("donor-only","donor-and-checked-bands"):
        return donor,donor,None
    choice=state["refined_result"]
    selected=choice["geometry"]
    delta=donor-parent
    assert delta.shape==(3,256,256)
    bands=isolate(delta,selected)
    # Keep the coarse footprint from the supported ribbon fit. The attenuation
    # counteracts envelope blur at crop boundaries and abrupt support changes.
    energy=np.mean(delta.astype(float)**2,axis=0)
    fast=gaussian_filter(energy,3.5,mode="constant")
    slow=gaussian_filter(energy,SIGMA,mode="constant")
    support=np.minimum(1.,np.sqrt(fast/np.maximum(slow,1e-20)))
    guarded=(bands*support[None]).astype(parent.dtype)
    fundamental=parent+guarded
    extra=render(raw,cfa,noise,fundamental,wb,matrix,choice)["locked"]
    total=fundamental+GAIN*extra
    note={"rms_original":float(np.sqrt(np.mean(delta.astype(float)**2))*65535),
          "rms_fundamentals":float(np.sqrt(np.mean(bands.astype(float)**2))*65535),
          "rms_removed":float(np.sqrt(np.mean((delta-bands).astype(float)**2))*65535)}
    return fundamental,total,note
