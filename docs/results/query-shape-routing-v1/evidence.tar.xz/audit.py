"""Verify the measured-frequency routing intervention and directional isolation."""
import json

import numpy as np

from routing import ROOT,ARMS,second_band
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint


def synthetic_test():
    x=np.arange(256,dtype=float)-127.5
    yy,xx=np.meshgrid(x,x,indexing="ij")
    geom=[[.110,.065,0.],[.090,-.083,0.]]
    phases=2*np.pi*np.stack([xx*f+yy*g for f,g,_ in geom])+np.array([.22,-.51])[:,None,None]
    first,second=np.cos(2*phases)
    donor=np.broadcast_to(.006*first+.006*second,(3,256,256)).copy()
    parent=np.zeros_like(donor)
    choice={"geometry":geom,"Q0_angles":[.22,-.51]}
    confirm=[{"integer_phase":[2,0],"local_axis":[1.,0.],"discovery":.010}]
    value=second_band(donor,parent,choice,confirm,np.ones(3),np.eye(3))
    area=np.s_[64:192,64:192]
    vectors=np.column_stack((first[area].ravel(),second[area].ravel()))
    coeff,*_=np.linalg.lstsq(vectors,value[1][area].ravel(),rcond=None)
    assert .0056<coeff[0]<.0063 and abs(coeff[1])<.00001
    zero=second_band(-donor,parent,choice,confirm,np.ones(3),np.eye(3))
    assert float(np.abs(zero[:,64:192,64:192]).max())<.00001
    return {"supported_band_amplitude":float(coeff[0]),"unsupported_band_amplitude":float(coeff[1]),
            "max_wrong_phase_value":float(np.abs(zero[:,64:192,64:192]).max())}


def main():
    evidence=reference(ROOT/"results.json")
    data=read_json(checked(evidence))
    parents=read_json(checked(data["parent_receipts"]))
    capture=read_json(checked(parents["captures"]))
    plan=read_json(checked(capture["source"]))
    assert len(plan["sources"])==24
    registered={r["source"]["id"]for r in plan["sources"]}
    with checked(plan["training_manifest"]).open()as f:
        training={json.loads(row)["id"]for row in f}
    assert len(training)==90692 and not training&registered
    collated=[]
    for a,b,c in zip(data["rows"],parents["rows"],capture["rows"],strict=True):
        assert (a["index"],a["noise"],a["input"])==(b["index"],b["noise"],c["input"]) and a["parent"]==b["parent"]
        with np.load(checked(a["input"]),allow_pickle=False)as f:
            saved={k:fingerprint(f[k])for k in f.files}
            assert saved==c["fingerprints"]
            for key in ("packed","variance"):
                np.testing.assert_array_equal(f[key][...,48:208,48:208],f["rotated_"+key][...,48:208,48:208])
            assert not np.array_equal(f["packed"],f["rotated_packed"])
        stored=np.load(checked(a["parent"]),allow_pickle=False)[...,32:288,32:288]
        catalogue={}
        with np.load(checked(a["prediction"]),allow_pickle=False)as f:
            np.testing.assert_array_equal(stored,f["parent"])
            for group,prefix in (("matching",""),("rotated","rotated_")):
                delta={}
                for j,route in enumerate(a["decisions"]):
                    used=route[group]
                    terms=used["second"]
                    vals={k:f[prefix+k][j]for k in ARMS if k!="parent"}
                    target=vals["ribbon"]if terms else vals["restricted"]
                    np.testing.assert_array_equal(vals["whole-query"],target)
                    if not terms:
                        np.testing.assert_array_equal(vals["restricted"],vals["directional"])
                    if not used["state"].startswith("donor-"):
                        assert all(np.array_equal(v,stored[j])for v in vals.values())
                    delta[str(j)]={k:not np.array_equal(v,stored[j]) for k,v in vals.items()}
                catalogue[group]=delta
        collated.append({"index":a["index"],"noise":a["noise"],"changed_outputs":catalogue})
    assert len(collated)==48
    scope=reference(ROOT/"standing/manifest.json")
    real=read_json(checked(scope))
    for r in real["rows"]:
        with np.load(checked(r["prediction"]),allow_pickle=False)as f:
            np.testing.assert_array_equal(f["whole-query"],f["directional"])
            np.testing.assert_array_equal(f["restricted"],f["directional"])
            if not r["id"].endswith("mesh-left"):
                np.testing.assert_array_equal(f["ribbon"],f["directional"])
    score=reference(ROOT/"scores.json")
    assert read_json(checked(score))["results"]==evidence
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"result":evidence,"scores":score,"standing":scope,
                                  "shape_math":synthetic_test(),"intervention":collated,"training_overlap":0,
                                  "native_crop_channel_values_validated":48*4*3*256*256})
    print(len(collated),synthetic_test(),flush=True)


if __name__=="__main__":
    main()
