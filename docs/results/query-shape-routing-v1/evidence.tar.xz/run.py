"""Fit automatic exterior policies on matching and mismatched RAW."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from routing import ARMS,ROOT,fit


def evaluate(task):
    parents,role,raw,profile,query,span=task
    full=np.zeros((3,512,512),np.float32)
    full[:,96:416,96:416]=parents[role]
    args=[raw[k][role]for k in ("colors","wb","matrix")]
    by_context={}
    for group,tag in (("matching",""),("rotated","rotated_")):
        fields=[raw[tag+k][role]for k in ("packed","variance")]
        models,history=fit(*fields,args[0],full,query,profile,args[1],args[2],span)
        by_context[group]=(models,history)
    return by_context


def main():
    roots=reference(ROOT/"parents.json")
    evidence=read_json(checked(roots))
    source=read_json(checked(evidence["captures"]))
    plan=read_json(checked(source["source"]))
    archive=ROOT/"predictions"
    archive.mkdir()
    records=[]
    elapsed=time.monotonic()
    with ThreadPoolExecutor(4)as pool:
        for fixture,parent in zip(source["rows"],evidence["rows"],strict=True):
            assert fixture["input"]==parent["input"] and fixture["noise"]==parent["noise"]
            with np.load(checked(fixture["input"]),allow_pickle=False)as f:
                data={k:f[k]for k in ("packed","variance","colors","wb","matrix","rotated_packed","rotated_variance")}
            image=np.load(checked(parent["parent"]),allow_pickle=False)
            noise=plan["profiles"][fixture["noise"]]
            definitions=(image,data,noise,plan["query"],plan["donor_span"])
            options=({k:[]for k in ARMS},{k:[]for k in ARMS})
            notes=[]
            for result in pool.map(evaluate,((definitions[0],n,*definitions[1:])for n in range(4))):
                row={}
                for mode,accumulate in zip(("matching","rotated"),options,strict=True):
                    parts,trace=result[mode]
                    for k,v in parts.items():
                        accumulate[k].append(v)
                    row[mode]=trace
                notes.append(row)
            for key in ARMS:
                for a in options[0][key]+options[1][key]:
                    assert np.isfinite(a).all()
            np.testing.assert_array_equal(options[0]["parent"],options[1]["parent"])
            named={k:np.stack(v)for k,v in options[0].items()}|{
                "rotated_"+k:np.stack(v)for k,v in options[1].items()if k!="parent"}
            result=archive/Path(fixture["input"]["path"]).name
            np.savez(result,**named)
            record={k:fixture[k]for k in ("index","noise","input")}|{
                "parent":parent["parent"],"prediction":reference(result),"decisions":notes}
            write_json(result.with_suffix(".json"),record)
            records.append(record)
            print(fixture["index"],fixture["noise"],round(time.monotonic()-elapsed,2),
                  [(n["matching"]["state"],n["matching"]["second"],n["rotated"]["state"])for n in notes],flush=True)
    write_json(ROOT/"results.json",{"driver":reference(__file__),"parent_receipts":roots,
          "shape_policy":reference(ROOT/"routing.py"),"checkpoint":plan["base"],"rows":records})


if __name__=="__main__":
    main()
