"""Compare the measured shape policies across both standing camera tests."""
import sys

import numpy as np
from PIL import Image
import torch

from routing import ARMS,COMPOSITION,ROOT,from_existing
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    prior=reference(COMPOSITION/"standing/manifest.json")
    source=read_json(checked(prior))
    output=ROOT/"standing"
    output.mkdir()
    collected=[]
    for row in source["rows"]:
        left,top,w,h=row["box"]
        with np.load(checked(row["base_input"]),allow_pickle=False)as f:
            raw=f["packed"][0,:,top//2:(top+h)//2,left//2:(left+w)//2]
            cfa,wb,matrix=(f[k][0]for k in ("colors","wb","matrix"))
        with np.load(checked(row["outputs"]),allow_pickle=False)as f:
            local,donor,ribbon=(f[n]for n in ("old","donor","composed"))
        models,terms=from_existing(local,donor,ribbon,raw,cfa,row["noise"],wb,matrix,row["state"])
        sx,sy,rw,rh=row["ROI"]
        roi=sx-left,sy-top,rw,rh
        bounds=np.s_[...,roi[1]:roi[1]+rh,roi[0]:roi[0]+rw]
        with Image.open(checked(row["image"]))as f:
            strip=np.asarray(f.convert("RGB"))
        crops={p["name"]:strip[y:y+h,x:x+w]for p in row["panels"]for x,y,w,h in (p["png_xywh"],)}
        keep=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","With exterior and checked bands")
        panels=[(k,crops[k])for k in keep if k in crops]
        for key,label in (("restricted","Restricted bands"),("whole-query","Whole-query shape gate"),
                          ("directional","Per-direction gate")):
            m=models[key]
            display=display_crop(torch.from_numpy(m[None]),torch.from_numpy(wb[None]),
                                 torch.from_numpy(matrix[None]),roi,exposure=row["display_exposure"])
            panels.append((label,np.rint(display*255).astype(np.uint8)))
        for k in ("ISO100 AHD reference","ISO100 camera JPEG"):
            if k in crops:
                panels.append((k,crops[k]))
        image=native_png(output/(row["id"]+".png"),panels)
        metrics={key:float(np.sqrt(np.mean((value[bounds].astype(float)-ribbon[bounds])**2))*65535)
                 for key,value in models.items()}
        file=output/(row["id"]+".npz")
        np.savez(file,**models)
        collected.append({k:row[k]for k in ("id","base_input","ROI","box","noise","display_exposure")}|image|
                         {"prior":row["image"],"prediction":reference(file),"second":terms,
                          "camera_RGB_RMS_to_ribbon_DN16":metrics})
        print(row["id"],terms,metrics,flush=True)
    write_json(output/"manifest.json",{"checkpoint":source["checkpoint"],"input":prior,
                                       "driver":reference(__file__),"rows":collected})


if __name__=="__main__":
    main()
