"""Seal46 actually viewed figures; preserve the original44-image preparation."""
import gzip
from datetime import datetime, timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
destination = repo / 'docs/results/neural-nuisance-fine-sinusoidal129-v1'
assert read_json(root / 'evidence-result.json')['all_stages_succeeded']
prepared = read_json(root / 'publication-prepared.json')
manifests = {'base': root / 'contact-sheets/manifest.json',
             'extra': root / 'extra-NN1600/contact-sheets/manifest.json'}
extra = read_json(root / 'publication-NN1600-extra-prepared.json')
figures = prepared['images'] + extra['images']
batches = sorted(root.glob('viewing-batch-*.json'))
viewed = {group: [] for group in manifests}
for path in batches:
    batch = read_json(path)
    assert batch['actually_viewed'] and batch['notes']
    assert batch['manifest'] == reference(manifests[batch['group']])
    for ref in batch['sheet_images']:
        checked(ref)
    viewed[batch['group']].extend(batch['sheets'])
for group, path in manifests.items():
    manifest = read_json(path)
    assert sorted(viewed[group]) == list(range(len(manifest['sheets'])))
assert len(prepared['images']) == 44 and len(extra['images']) == 2 and len(figures) == 46
decision = read_json(root / 'quality-decision.json')
assert decision['actually_viewed_figures'] == 46 and decision['limitations']
archives = list(prepared['archives'])
already = {item['original']['path'] for item in archives}
sources = [p for p in sorted(root.rglob('*')) if p.is_file()
           and root / 'work' not in p.parents and p.suffix in {'.json', '.log', '.py'}]
sources.extend(repo / n for n in [
    '.cache/finalize-fine-sinusoidal129-publication-v1.py',
    '.cache/fine-sinusoidal129-evidence-queue-v1.log',
    '.cache/fine-sinusoidal129-H1-parity-v1.py', '.cache/fine-sinusoidal129-H1-parity-v1.log',
    '.cache/fine-sinusoidal129-scene-maxima-v1.py', '.cache/fine-sinusoidal129-scene-maxima-v1.log',
    '.cache/compare-fine-sinusoidal129-v1.py', '.cache/compare-fine-sinusoidal129-v1.log',
    '.cache/native-contact-sheets-v1.log',
    '.cache/add-fine-sinusoidal129-NN1600-triplets-v1.py',
    '.cache/add-fine-sinusoidal129-NN1600-triplets-v1.log',
    '.cache/fine-sinusoidal129-extra-NN1600-sheets-v1.log',
])
for source in sources:
    ref = reference(source)
    if ref['path'] in already:
        continue
    name = str(source.relative_to(root) if root in source.parents else source.name).replace('/', '--')
    target = destination / ('addendum-' + name + '.gz')
    with target.open('xb') as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    archives.append({'original': ref, 'published': reference(target), 'decompressed_bytes_exact': True})
    already.add(ref['path'])
for item in archives:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
for item in figures:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
prepared.update(
    archives=archives, images=figures, original_preparation=reference(root / 'publication-prepared.json'),
    extra_preparation=reference(root / 'publication-NN1600-extra-prepared.json'),
    original_viewer=prepared['viewer'],
    viewer=reference(repo / 'docs/images/neural-nuisance-fine-sinusoidal129-v1/native-viewer-with-NN1600.html'),
    viewing={'actually_viewed': True, 'figures': 46, 'contact_sheets': 14,
             'manifests': {group: reference(path) for group, path in manifests.items()},
             'batches': [reference(p) for p in batches]},
    quality_decision=decision,
    comparison=reference(root / 'closed-comparison.json'),
    correction_maxima=reference(root / 'scene-correction-maxima.json'),
    H1_control_parity=reference(root / 'all-H1-control-parity.json'),
    admission=reference(repo / 'docs/results/fine-sinusoidal129-setup-v1/publication.json'),
    comparison_baselines=[reference(repo / 'docs/results' / n / 'publication.json')
                         for n in ['neural-nuisance-fine-phase129-v1', 'neural-nuisance-guided-phase129-v1']],
    status='complete; exact interpretation and limitations in quality_decision',
    inherited_renderer_scope='Phase naming in generic source filenames or prose is inherited. '
        'Current output is original broad guided phase plus fine sinusoidal full-fit carrier '
        'delivery with conditional full/null support; fine has no range/phase/edge-side kernel. '
        'Both nuisance arms retain separate RGB coefficients. Not an isolated harmonic-only '
        'ablation, strict cutoff or calibrated confidence.',
    published_UTC=datetime.now(timezone.utc).isoformat(),
)
assert not (destination / 'publication.json').exists()
write_json(destination / 'publication.json', prepared)
print(len(archives), 'exact archives;', len(prepared['images']), 'actually viewed figures on',
      14, 'sheets')
