"""Launch the phase129 measurement pilot and closed-output review."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, write_json, verify_plan

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1"
plan = read_json(root / "plan.json")
verify_plan(plan)
assert not (root / "launch.json").exists()
assert len(plan["rows"]) == 48 and plan["prediction_cache"] is None
cache = read_json(checked(plan["background_cache"]))
assert {r["id"] for r in cache["rows"]} == {r["id"] for r in plan["rows"]}
assert cache["new_root_forwards"] == cache["new_encoder_forwards"] == 0
assert plan["geometry_config"]["frequency_weighting"] == "hann-inverse-variance"
assert plan["geometry_config"]["amplitude_window"] == 0
assert plan["aggregation_config"] == {"bins":32,"window":129,"query_stride":32,"edge_stopping":True,"parent_projection":"conditional_null"}
assert not plan["full_panel"]
assert plan["phase_guide"] and plan["add_fine_carriers"]
assert plan["fine_reconstruction"] == "sinusoidal"
audit_script = root / "audit_neural_nuisance_inputs.py"
shutil.copyfile(repo / "scripts/audit_neural_nuisance_inputs.py", audit_script)
old = repo / ".cache/experiments/neural-nuisance-full-edge512-pilot-v1"
controller = (old / "controller.py").read_text().replace(
    "sorted(os.sched_getaffinity(0))[-4:-2]", "[16,17]"
).replace("Full edge NN t2", "Broad+fine H1 NN t2").replace("Full edge H1 t2", "Broad+fine H1 A t2")
needle = "for name,args,gpu in stages:"
replacement = "stages.insert(1,('background-audit',[py,str(root/'audit_neural_nuisance_inputs.py'),str(root),str(root/'background-independent-audit.json')],False))\n" + needle
assert controller.count(needle) == 1
(root / "controller.py").write_text(controller.replace(needle, replacement))
follow = root / "followup"
follow.mkdir()
shutil.copyfile(repo / "scripts/review_neural_nuisance.py", follow / "review_neural_nuisance.py")
shutil.copyfile(old / "followup/controller.py", follow / "controller.py")
env = dict(os.environ, PYTHONPATH=str(repo / "src"), OMP_NUM_THREADS="2",
           OPENBLAS_NUM_THREADS="2", MKL_NUM_THREADS="2")
with (root / "controller.log").open("x") as log:
    producer = subprocess.Popen([sys.executable, str(root / "controller.py"), str(root)],
                               stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
identity = {"pid": producer.pid, "create_time": psutil.Process(producer.pid).create_time(),
            "plan": reference(root / "plan.json"), "controller": reference(root / "controller.py")}
write_json(root / "launch.json", identity)
write_json(follow / "plan.json", {"producer": identity, "root": str(root),
    "script": reference(follow / "review_neural_nuisance.py"), "output": str(root / "summary-review"),
    "work": plan["work"]})
with (follow / "controller.log").open("x") as log:
    reviewer = subprocess.Popen([sys.executable, str(follow / "controller.py"), str(follow)],
                               stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
psutil.Process(reviewer.pid).cpu_affinity([16, 17])
write_json(follow / "launch.json", {"pid": reviewer.pid,
    "create_time": psutil.Process(reviewer.pid).create_time(), "plan": reference(follow / "plan.json")})
write_json(root / "study.json", {"plan": reference(root / "plan.json"),
    "baseline": reference(repo / ".cache/experiments/neural-nuisance-fine-phase129-pilot-v1/plan.json"), "broad_only_baseline": reference(repo / ".cache/experiments/neural-nuisance-guided-phase129-pilot-v1/plan.json"), "launcher": reference(__file__),
    "development_test_revision": "Initial conditional-difference delivery lost27.176% of a known faint red coefficient. Exact initial source/test log retained; full-fit carrier delivery now passes independent per-color amplitude/phase and actual withholding checks on all4CFAs. This is adaptive development, not blinded validation.",
    "diagnostics": [reference(repo / ".cache/fine-band-proposal-diagnostic-v1.json"), reference(repo / ".cache/fine-band-proposal-diagnostic-v2.json")],
    "intervention": "Retain guided broad reconstruction and exactly the same additional fine proposals. Fine delivery uses native129/stride32 per-color local H1 full-fit carrier coefficients, conditional full/null support and frozen global joint-fit broad/background nuisance. Identical fixed RAW/parent map; no fine phase/range/edge-side pooling. This changes fine waveform/fit/delivery/support and is not an isolated harmonic-only ablation or strict spectral cutoff. Separate RGB amplitudes remain independent.",
    "new_neural_forwards_expected": 0, "cached_fields": 88,
    "primary_comparison": "analytic fine sinusoidal conditional-local-t2 vs completed fine phase conditional-local-t2; broad-only guided baseline secondary. Fixed0/2/4, neural-nuisance arms and original H1 controls retained. No threshold choice from new outcomes.",
    "scope": "Same adaptive two-source48-case development cohort/all3 priors/6 controls/thresholds0,2,4; all corrections close before new quality analysis; both standing GFX families/ROIs/profiles/JPEGs retained; no GT/reference in fitting",
})
print("producer", identity)
print("reviewer", read_json(follow / "launch.json"))
