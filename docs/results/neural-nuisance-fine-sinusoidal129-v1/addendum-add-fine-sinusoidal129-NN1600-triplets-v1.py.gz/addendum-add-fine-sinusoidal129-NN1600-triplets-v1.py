"""Add two exact audited NN1600 triplets without rewriting44-image preparation."""
import shutil
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
assert read_json(root / 'evidence-result.json')['all_stages_succeeded']
prepared = read_json(root / 'publication-prepared.json')
report = read_json(root / 'report/report.json')
images = repo / 'docs/images/neural-nuisance-fine-sinusoidal129-v1'
figures = []
for case in ['iso1600-index0008-role2', 'iso1600-index0024-role2']:
    f = next(f for f in report['figures'] if Path(f['image']['path']).stem == case + '-triplet')
    relative = 'triplets/' + Path(f['image']['path']).name
    dest = images / relative
    assert not dest.exists()
    shutil.copyfile(checked(f['image']), dest)
    assert dest.read_bytes() == checked(f['image']).read_bytes()
    figures.append({'original': f['image'], 'published': reference(dest), 'relative': relative,
                    'metadata': {**f, 'method': 'local-t2',
                                 'scope': 'Broad guided phase plus fine sinusoidal full-fit NN nuisance; exact constructed GT. Original audited noisy/restored/GT PNG bytes unchanged.'}})
extra = root / 'extra-NN1600'
extra.mkdir()
binding = {'images': figures, 'base_preparation': reference(root / 'publication-prepared.json'),
           'script': reference(__file__), 'new_neural_forwards': 0,
           'scope': 'Two extra audited native160 NN nuisance1600/far exact-GT triplets; preserve original44-image preparation/viewer/manifest bytes.'}
write_json(root / 'publication-NN1600-extra-prepared.json', binding)
write_json(extra / 'publication-prepared.json', binding)
text = checked(prepared['viewer']).read_text()
text += '<p>Two additional neural-nuisance1600/far native triplets; exact constructed GT, identical ROI/exposure/calibration. Broad guided phase plus sinusoidal fine carriers.</p>'
for f in figures:
    text += '<figure><figcaption>' + f['relative'] + '</figcaption><img src="' + f['relative'] + '"></figure>\n'
path = images / 'native-viewer-with-NN1600.html'
assert not path.exists()
path.write_text(text)
print('Two audited NN1600 triplets added; original44-image artifacts unchanged')
