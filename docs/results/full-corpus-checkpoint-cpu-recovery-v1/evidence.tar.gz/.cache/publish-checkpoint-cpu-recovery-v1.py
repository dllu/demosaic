"""Seal recurrent stall, exact state/source admission and real resumed draw witnesses."""
import gzip
import io
import tarfile
import json
from pathlib import Path
from datetime import datetime,timezone
import psutil
import numpy as np
from demosaic.experiments.artifacts import read_json,reference,write_json,checked

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v3';recovery=root/'checkpoint-recovery-v7';failure=root/'checkpoint-stall-step14000-v1'
plan_path=root/'production-handoff-plan-v7.json';plan=read_json(plan_path)
launch_path=root/'production-handoff-v7/00-scale-control20k-launch.json';launch=read_json(launch_path);p=psutil.Process(launch['pid']);assert p.create_time()==launch['create_time']
run=recovery/'work/artifacts/train/control20k';phase=run/'phase-013001-020000'
with(phase/'source-crop-observations.jsonl').open()as stream:prefix=''.join(next(stream)for _ in range(250))
new=[json.loads(l)for l in prefix.splitlines()];old=[json.loads(l)for l in(failure/'failed-source-crop-observations.jsonl').read_text().splitlines()if 13001<=json.loads(l)['step']<=13250]
assert new==old and len(new)==250
assert [v['global_draw_start']for v in new]==list(range(208000,212000,16))
prefix_path=recovery/'first250-replayed-source-observations.jsonl';prefix_path.open('x').write(prefix)
a=phase/'conditions-013001-013250.npz';b=root/'checkpoint-recovery-v6/work/artifacts/train/control20k/phase-006001-020000/conditions-013001-013250.npz'
with np.load(a,allow_pickle=False)as x,np.load(b,allow_pickle=False)as y:
    assert x.files==y.files
    for key in x.files:np.testing.assert_array_equal(x[key],y[key])
log=root/'production-handoff-v7/00-scale-control20k.log';snapshot=recovery/'actual-progress-log-snapshot.log';snapshot.open('xb').write(log.read_bytes())
events=[json.loads(l)for l in snapshot.read_text().splitlines()if l.startswith('{')];start=next(v for v in events if v['event']=='start');trained=[v for v in events if v['event']=='train']
assert start['start_step']==13000 and start['steps']==20000 and start['train_sources']==90778 and trained[-1]['step']>=13250
write_json(recovery/'actual-progress.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),
 'launch':reference(launch_path),'owner':{'pid':p.pid,'create_time':p.create_time()},'start':start,'last_observed_train_step':trained[-1]['step'],
 'snapshot_log':reference(snapshot),'first250_source_rows':reference(prefix_path),'first250_source_rows_exact_to_abandoned_segment':True,
 'conditioning':{'new':reference(a),'previous':reference(b),'all250x16x14_values_and_steps_domains_exact':True},
 'scope':'Actual13k state resume with original20k horizon,90778-photo sampler and exact replayed13001–13250 source/conditioning. Unserialized13k→14k optimizer work is recomputed, not counted twice. This is progress, not liveness or another completed checkpoint/endpoint/quality claim.'})
out=repo/'docs/results/full-corpus-checkpoint-cpu-recovery-v1';out.mkdir()
files=[p for p in failure.iterdir()if p.is_file()and p.suffix!='pt'and p.suffix!='.tmp']
# Large checkpoint/partial bytes remain local, bound by diagnosis/stop receipts.
files=[p for p in files if p.suffix not in ['.pt','.tmp']]
files += [root/'production-handoff-plan-v6.json',root/'production-handoff-v6/production-result.json',root/'production-handoff-v6/00-scale-control20k-result.json',
 root/'production-handoff-v6/00-scale-control20k-launch.json',plan_path,launch_path,root/'production-handoff-v7-launch.json',root/'checkpoint-cpu-snapshot-qualification-v1/result.json',
 recovery/'admission.json',recovery/'actual-progress.json',snapshot,prefix_path,recovery/'control20k-continuation.yaml',recovery/'long100k-continuation.yaml',
 Path(plan['controller_script']['path']),a,b,Path(read_json(root/'checkpoint-cpu-snapshot-qualification-v1/result.json')['train_source']['path']),
 repo/'tests/test_checkpoint_retention.py',repo/'tests/test_training.py',repo/'tests/test_training_execution.py',Path(__file__).resolve()]
files += [p for p in(recovery/'work').rglob('*')if p.is_file()and 'artifacts'not in p.relative_to(recovery/'work').parts and '__pycache__'not in p.parts]
for stem in ['diagnose-control-checkpoint-stall-v2','stop-diagnosed-control-checkpoint-stall-v2','stop-diagnosed-control-checkpoint-stall-v3',
 'qualify-checkpoint-cpu-snapshot-v1','prepare-full-corpus-checkpoint-recovery-v7','launch-full-corpus-checkpoint-recovery-v7','checkpoint-cpu-snapshot-tests-v1']:
    files += list((repo/'.cache').glob(stem+'.*'))
paths=sorted(set(p.resolve()for p in files));archive=out/'evidence.tar.gz';index=[]
with archive.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
    for p in paths:
        data=p.read_bytes();name=str(p.relative_to(repo));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));index.append({'source':reference(p),'member':name})
with tarfile.open(archive,'r:gz')as tar:
    for v in index:assert tar.extractfile(v['member']).read()==Path(v['source']['path']).read_bytes()
write_json(out/'publication.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'archive':reference(archive),
 'all_archive_bytes_verified':True,'members':index,'diagnosis':read_json(failure/'diagnosis.json'),'stop':read_json(failure/'operator-stop.json'),
 'qualification':read_json(root/'checkpoint-cpu-snapshot-qualification-v1/result.json'),'admission':read_json(recovery/'admission.json'),'actual_progress':read_json(recovery/'actual-progress.json'),
 'scope':'Second actual serialization stall, first last.tmp at14k; previous best-link fix insufficient. Retain actual13k state; CPU-snapshot storage-only source,37 regression tests, twice actual CUDA13k→CPU serialize/reload with every value exact. Original schedules/states/noise/source order unchanged. SIGTERM exact owned worker; no other process stopped. Lost1000 updates replayed. Realprogress and first250 source/conditioning exact; next checkpoint/20k endpoint/fullquality pending. Failurev2 stop-path assertion occurred before any signal and is preserved. No exact CUDA/C++ root-cause claim.'})
print('Published CPU checkpoint recovery with actual resumed step',trained[-1]['step'],len(paths),'evidence files')
