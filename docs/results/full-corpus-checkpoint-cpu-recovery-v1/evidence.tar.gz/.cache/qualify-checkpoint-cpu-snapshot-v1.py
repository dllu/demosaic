"""Qualify CPU-only serialization using the actual thirteen-thousand-step state."""
import random
from pathlib import Path
from types import SimpleNamespace
import torch
from demosaic.train import save_checkpoint,retain_checkpoint
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

torch.set_num_threads(2)
root=Path('.cache/experiments/full-corpus-scaling-v3').resolve()
out=root/'checkpoint-cpu-snapshot-qualification-v1';out.mkdir()
binding=read_json(root/'checkpoint-stall-step14000-v1/diagnosis.json')['checkpoint']
state=torch.load(checked(binding),map_location='cpu',weights_only=True)
assert state['step']==13000 and len(state['optimizer']['state'])==89

def to_cuda(value):
    if isinstance(value,torch.Tensor):return value.to('cuda')
    if isinstance(value,dict):return {k:to_cuda(v) for k,v in value.items()}
    if isinstance(value,list):return [to_cuda(v)for v in value]
    if isinstance(value,tuple):return tuple(to_cuda(v)for v in value)
    return value

def equal(a,b):
    if isinstance(a,torch.Tensor):
        assert isinstance(b,torch.Tensor) and b.device.type=='cpu'
        assert torch.equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert type(a)==type(b) and len(a)==len(b)
        for x,y in zip(a,b,strict=True):equal(x,y)
    else:assert a==b

raw,ema,optimizer=[to_cuda(state[k])for k in ['model','ema','optimizer']]
model=SimpleNamespace(restoration_state_dict=lambda:raw,config=SimpleNamespace(to_dict=lambda:state['model_config']))
opt=SimpleNamespace(state_dict=lambda:optimizer)
random.setstate(state['python_rng']);torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state_all(state['cuda_rng'])
for index in range(2):
    save_checkpoint(out/'last.pt',model,opt,ema,state['step'],state['config'],state['best'])
    actual=torch.load(out/'last.pt',map_location='cpu',weights_only=True)
    equal(state,actual)
    retain_checkpoint(out/'last.pt',out/'best.pt')
    equal(state,torch.load(out/'best.pt',map_location='cpu',weights_only=True))
write_json(out/'result.json',{'producer':reference(__file__),'source_checkpoint':binding,
 'train_source':reference('src/demosaic/train.py'),'last':reference(out/'last.pt'),'best':reference(out/'best.pt'),
 'save_and_reload_repetitions':2,'raw_tensors':91,'EMA_tensors':91,'Adam_states':89,'step':13000,
 'every_state_value_bitexact':True,'all_serialized_tensors_CPU':True,
 'scope':'Actual13k checkpoint raw/EMA/Adam moved to CUDA, then new CPU snapshot serialized/reloaded twice. Every nested value including RNG/config exact to retained source. No model construction/learned forward/noise/optimizer update. Production training resume remains separately observed; cause of original CUDA serialization stall not claimed.'})
print('Actual13k CUDA-to-CPU checkpoint qualification passed twice')
