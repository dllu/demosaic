"""Freeze CPU-only checkpoint serialization; adopt actual13k/1k states exactly."""
import os
import shutil
from pathlib import Path
import yaml
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v3';prior=read_json(root/'production-handoff-plan-v6.json')
stop=read_json(root/'checkpoint-stall-step14000-v1/operator-stop.json')
assert read_json(root/'production-handoff-v6/00-scale-control20k-result.json')['returncode']==-15
assert '37 passed' in (repo/'.cache/checkpoint-cpu-snapshot-tests-v1.log').read_text()
qualification=root/'checkpoint-cpu-snapshot-qualification-v1/result.json';q=read_json(qualification)
assert q['every_state_value_bitexact'] and q['all_serialized_tensors_CPU'] and q['step']==13000
old_train=Path(prior['work'])/'src/demosaic/train.py';new_train=repo/'src/demosaic/train.py'
old,new=old_train.read_text(),new_train.read_text()
normalized=new[:new.index('def checkpoint_cpu_snapshot(')]+old[old.index('def save_checkpoint('):old.index('def train(')]+new[new.index('def train('):]
normalized=normalized.replace('            if step % checkpoint_interval and step != steps:\n                save_checkpoint(run / "last.pt", model, optimizer, ema, step, config, best)', '            save_checkpoint(run / "last.pt", model, optimizer, ema, step, config, best)')
assert normalized==old,'Unrelated training computation changed'
assert reference(new_train)==q['train_source']
recovery=root/'checkpoint-recovery-v7';recovery.mkdir();work=recovery/'work'
for directory in ['src','scripts','configs','third_party']:
    shutil.copytree(Path(prior['work'])/directory,work/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ['pyproject.toml','uv.lock']:shutil.copyfile(Path(prior['work'])/name,work/name)
shutil.copyfile(new_train,work/'src/demosaic/train.py')
worker=work/'scripts/run_full_corpus_continuation_v7.py';shutil.copyfile(checked(prior['worker_script']),worker)
controller=repo/'.cache/full-corpus-and-context-controller-v7.py'
controller.open('x').write(checked(prior['controller_script']).read_text().replace('Declared100k/control20k/three-context-arm allocation','Declared control20k/100k allocation'))
adopted={'control20k':stop['checkpoint'],'long100k':prior['adopted_states']['long100k']};configs=dict(prior['configs'])
for arm in ['control20k','long100k']:
    original=yaml.safe_load(checked(prior['configs'][arm]).read_text());cfg=dict(original)
    run=work/'artifacts/train'/arm;run.mkdir(parents=True)
    os.link(checked(adopted[arm]),run/'last.pt')
    shutil.copyfile(Path(original['run'])/'initialization.json',run/'initialization.json')
    if arm=='control20k':os.link(checked(read_json(root/'checkpoint-stall-step14000-v1/diagnosis.json')['previous_best']),run/'best.pt')
    cfg['run']=str(run)
    assert {k:v for k,v in cfg.items()if k!='run'}=={k:v for k,v in original.items()if k!='run'}
    path=recovery/(arm+'-continuation.yaml');path.open('x').write(yaml.safe_dump(cfg,sort_keys=False));configs[arm]=reference(path)
write_json(recovery/'admission.json',{'producer':reference(__file__),'qualification':reference(qualification),
 'old_train':reference(old_train),'new_train':reference(work/'src/demosaic/train.py'),'all_non_checkpoint_training_source_exact':True,
 'tests':reference('.cache/checkpoint-cpu-snapshot-tests-v1.log'),'stop':reference(root/'checkpoint-stall-step14000-v1/operator-stop.json'),
 'adopted_states':adopted,'scope':'Storage-only change: CPU snapshot before serialization, explicit progress, no stale temporary overwrite, no duplicate final serialization. Same raw/EMA/Adam/RNG/global draw/20k and100k horizons. Unserialized13k→14k segment is replayed, not counted twice. Original source/log/partial bytes preserved.'})
plan={**prior,'work':str(work),'worker_script':reference(worker),'configs':configs,'controller_script':reference(controller),
 'allocation_root':str(root/'production-handoff-v7'),'adopted_states':adopted,
 'previous_controller_result':reference(root/'production-handoff-v6/production-result.json'),
 'checkpoint_write_recovery':reference(root/'checkpoint-stall-step14000-v1/operator-stop.json'),
 'frozen_files':{str(p):reference(p)['sha256']for p in work.rglob('*')if p.is_file()and'artifacts'not in p.relative_to(work).parts},
 'inputs':[reference(root/'production-handoff-plan-v6.json'),reference(recovery/'admission.json'),reference(qualification),*configs.values(),prior['profile_plan'],prior['parent'],*adopted.values()],
 'compute_schedule':[dict(kind='scale',arm='control20k',updates=7000,maximum_seconds=64800),dict(kind='scale',arm='long100k',updates=99000,maximum_seconds=259200)],
 'scope':'Explicit continuation after verified first-last serialization stall. Adopt complete13k control and1k long; remaining7k then99k. Snapshot tensors to CPU before torch.save; reuse saved final checkpoint. All learning/data/noise/optimizer/precision/EMA/horizons identical. Replay only lost13001–14000 state from valid13k with original draws; preserve failed evidence; no automatic retry.'}
write_json(root/'production-handoff-plan-v7.json',plan)
print('Admitted control13000→20000 then long1000→100000',reference(root/'production-handoff-plan-v7.json')['sha256'])
