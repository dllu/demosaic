"""Stop only the proven stalled owned worker; preserve its completed and partial bytes."""
import shutil
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path('.cache/experiments/full-corpus-scaling-v3').resolve()
out = root / 'checkpoint-stall-step14000-v1'
diagnosis = read_json(out / 'diagnosis.json')
launch = read_json(checked(diagnosis['launch']))
p = psutil.Process(launch['pid'])
assert p.create_time() == launch['create_time'] == 1794918978.22
assert reference(root / 'checkpoint-recovery-v6/work/artifacts/train/control20k/last.pt')['sha256'] == diagnosis['checkpoint']['sha256']
run = root / 'checkpoint-recovery-v6/work/artifacts/train/control20k'
assert (run / 'last.tmp').stat().st_mtime_ns == diagnosis['second']['files'][str(run / 'last.tmp')]['mtime_ns']
fd_bindings = []
for fd in Path(f'/proc/{p.pid}/fd').iterdir():
    try:
        target = fd.readlink()
        if str(target).startswith(str(root)):
            fd_bindings.append({'fd': fd.name, 'target': str(target),
                                'fdinfo': (Path(f'/proc/{p.pid}/fdinfo') / fd.name).read_text()})
    except FileNotFoundError:
        pass
assert any(v['target'] == str(run / 'last.tmp') for v in fd_bindings)
began = time.time()
p.terminate()
kill_needed = False
try:
    p.wait(timeout=20)
except psutil.TimeoutExpired:
    assert p.create_time() == launch['create_time']
    raise RuntimeError('Owned worker did not terminate; inspect before further action')
closed = []
sources = [run / 'last.tmp', root / 'production-handoff-v6/00-scale-control20k.log',
           run / 'metrics.jsonl', run / 'source-loss.jsonl',
           run / 'phase-006001-020000/source-crop-observations.jsonl']
for source in sources:
    target = out / ('failed-' + source.name)
    shutil.copyfile(source, target)
    assert reference(target)['sha256'] == reference(source)['sha256']
    closed.append({'original': reference(source), 'retained': reference(target)})
write_json(out / 'operator-stop.json', {
    'script': reference(__file__), 'diagnosis': reference(out / 'diagnosis.json'),
    'stopped_owner': {'pid': launch['pid'], 'create_time': launch['create_time']},
    'fd_evidence_at_stop': fd_bindings, 'terminate_unix': began, 'ended_unix': time.time(),
    'SIGKILL_needed_after20s': kill_needed, 'closed_evidence': closed,
    'checkpoint': diagnosis['checkpoint'],
    'scope': 'Operator stops the exact owned worker after a verified>30min checkpoint serialization stall with last.tmp open, no training/source/checkpoint progress and valid complete13k state. Not a training deadline/quality stop or observation-cell timeout; no exact CUDA/C++ cause known because debugger attachment was denied. Other processes and the CPU primary collector are untouched. Preserve failed prefix/source/partial bytes. A separately admitted recovery must adopt step13000 Adam/EMA/RNG, source order and the original20k/100k horizons; replay only the unserialized13001–14000 from the complete13k state.',
})
print('Stopped diagnosed owned checkpoint stall, retained complete13000 and partial last; SIGKILL', kill_needed)
