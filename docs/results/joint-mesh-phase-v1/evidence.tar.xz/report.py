"""Bind matched mesh tests and render the native fit and reference panels."""

import hashlib
import shutil
import tarfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
REFINED=ROOT.parent/"joint-mesh-phase-refinement-v1"
CAMERA_BANK=ROOT.parent/"joint-mesh-phase-bank-v1"
REPO=Path.cwd()
OUT=REPO/"docs/images/joint-mesh-phase-v1"
DEST=REPO/"docs/results/joint-mesh-phase-v1"
NATIVE = ("iso400-occluded-g80-r0","iso6400-occluded-g83-r0",
          "iso400-additive-g80-r0","iso400-broken-g83-r0")


def read(location):
    raw=read_json(location/"result.json")
    plan=read_json(checked(raw["plan"]))
    rows=[read_json(checked(r)) for r in raw["records"]]
    assert len(rows)==len({r["id"] for r in rows})==72
    for key in ("driver","method","checkpoint"):
        checked(plan[key])
    return raw,plan,{r["id"]:r for r in rows}


def summary(cases,method):
    rows=[r["measurements"][method] for r in cases]
    baseline=[r["measurements"]["parent"] for r in cases]
    return {
        "pairs":len(rows),
        "response_percent":[mean(r["response"][k] for r in rows)*100 for k in range(3)],
        "increment_RMS_DN16":[mean(r["increment_RMS_DN16"][k] for r in rows) for k in range(3)],
        "better_increment_RMS":[sum(r["increment_RMS_DN16"][k]<b["increment_RMS_DN16"][k]
                                    for r,b in zip(rows,baseline,strict=True)) for k in range(3)],
        "modified_roles":[sum(r["changed"][k] for r in rows) for k in range(3)],
        "negative_added_mean_RMS_DN16":[mean(r["negative_added_RMS_DN16"][k] for r in rows) for k in range(2)],
        "negative_added_max_RMS_DN16":[max(r["negative_added_RMS_DN16"][k] for r in rows) for k in range(2)],
        "mean_gap_added_RMS_DN16":mean(r["gap_added_RMS_DN16"] for r in rows) if rows[0]["gap_added_RMS_DN16"] is not None else None,
        "max_gap_added_RMS_DN16":max(r["gap_added_RMS_DN16"] for r in rows) if rows[0]["gap_added_RMS_DN16"] is not None else None,
        "present_occlusion_choices":sum(k["basis"]=="occlusion" and k["blend"]>0 for r in rows for k in r.get("fits",[[],[],[]])[1]),
    }


def native_ref(d):
    src=checked(d)
    return d|{"path":str(src.relative_to(REPO))}


def audit_metric(prediction,case,method,data):
    crop=np.s_[...,48:208,48:208]
    p=prediction.astype(float)[crop]
    truth=data["target"].astype(float)[crop]
    strong=data["strong_phase"][crop]
    weak=data["weak_phase"][crop]
    real=(weak>.10)&(data["support"][crop]>.9999)
    masks=(real,real&(strong>.45),real&(strong<.12))
    exact=truth[1]-truth[0]
    measured=p[1]-p[0]
    response=[float(np.dot(exact[:,m].ravel(),measured[:,m].ravel())/np.linalg.norm(exact[:,m])**2) for m in masks]
    error=[float(65535*np.linalg.norm((measured-exact)[:,m])/np.sqrt(exact[:,m].size)) for m in masks]
    np.testing.assert_allclose(response,case["measurements"][method]["response"],atol=1e-12,rtol=1e-12)
    np.testing.assert_allclose(error,case["measurements"][method]["increment_RMS_DN16"],atol=1e-11,rtol=1e-12)


def score_shift(orig,variant):
    pairs=[]
    for a,b in zip(orig,variant,strict=True):
        f=np.linalg.norm(np.asarray(a["frequency"])-b["frequency"])
        phase_error=abs((a["offset"]-b["offset"]+.5)%1-.5)
        pairs.append({"frequency_error_cycles_per_pixel":float(f),"center_phase_error_cycles":float(phase_error)})
    return pairs


def main():
    first, plan, records=read(ROOT)
    second, refining, extension=read(REFINED)
    assert records.keys()==extension.keys()
    assert refining["original_panel"]==reference(ROOT/"result.json")
    OUT.mkdir(parents=True,exist_ok=True)
    DEST.mkdir(parents=True,exist_ok=True)
    groups=defaultdict(list)
    boards,geometry=[],[]
    n=0
    for name,r in records.items():
        q=extension[name]
        assert q["fingerprints"]==r["fingerprints"]
        assert q["measurements"]["parent"]==r["measurements"]["parent"]
        combined=r|{"measurements":r["measurements"]|q["measurements"]}
        groups[r["profile"],r["layout"]].append(combined)
        oracle=r["guides"]["exact"]
        geometry.append({"case":name,"noise":r["profile"],"layout":r["layout"],
            "phase_given_true_geometry":score_shift(oracle,r["guides"]["exterior"]),
            "before":score_shift(oracle,q["guides"]["perturbed"]),
            "after":score_shift(oracle,q["guides"]["refined"]) if q["guides"]["refined"] else None})
        if not r["retained"]:
            continue
        with (np.load(checked(r["retained"]),allow_pickle=False) as a,
              np.load(checked(q["retained"]),allow_pickle=False) as b):
            left,right=dict(a),dict(b)
        assert {k:fingerprint(left[k]) for k in r["fingerprints"]}==r["fingerprints"]
        for base in ("packed","colors","variance","wb","matrix","target","pred_parent"):
            np.testing.assert_array_equal(left[base],right[base])
        arrays=left|right
        for method in combined["measurements"]:
            audit_metric(arrays["pred_"+method],combined,method,arrays)
        n+=1
        if name not in NATIVE:
            continue
        bayer={k:left[k][1:2] for k in ("packed","colors","wb","matrix")}
        values=[noisy_malvar(bayer)[0],*[arrays["pred_"+e][1] for e in (
            "parent","additive-exterior","adaptive-exterior","refined-adaptive")],left["target"][1]]
        labels=["Noisy Malvar","Local trunk","Additive fit","Joint crossing","Frequency refined","Exact GT"]
        displayed=native_board(OUT,name,values,bayer,{
             "case":name,"sensor_seed":r["seed"],"noise":plan["priors"][r["profile"]],
             "colors":left["colors"][1].tolist(),"checkpoint":plan["checkpoint"]},
             labels=labels,triplet_indices=(0,3,5),contrast=8,exposure=1)
        for k in ("board","triplet"):
            displayed[k]["image"]=native_ref(displayed[k]["image"])
        boards.append(displayed)
    assert n==12 and len(boards)==4
    stills=[]
    still_out=OUT/"standing"
    still_out.mkdir(exist_ok=True)
    for row in read_json(CAMERA_BANK/"standing/result.json")["rows"]:
        p=checked(row["image"])
        dst=still_out/p.name
        shutil.copyfile(p,dst)
        assert row["image"]["sha256"]==reference(dst)["sha256"]
        stills.append(row|{"image":native_ref(reference(dst))})
    assert len(stills)==8
    files={"report.py":Path(__file__),"initial/run-first.py":ROOT/"run-first.py",
           "initial/run-first.log":ROOT/"run-first.log","initial/plan-first.json":ROOT/"plan-first.json"}
    for tag,location in (("initial",ROOT),("refined",REFINED)):
        result=read_json(location/"result.json")
        for key in ("plan.json","run.py","mesh.py","result.json","standing.py","standing/result.json","run.log"):
            files[f"{tag}/{key}"]=location/key
        for r in result["records"]:
            path=checked(r)
            files[f"{tag}/cases/{path.name}"]=path
    files["refined/refine.py"]=REFINED/"refine.py"
    for name in ("bank.py","mesh.py","refine.py","standing.py","standing/result.json","standing.log"):
        files[f"camera-bank/{name}"]=CAMERA_BANK/name
    files["prior/raw-frequency-bank-camera.json"]=ROOT.parent/"donor-frequency-bank-v1/camera.json"
    archive=DEST/"evidence.tar.xz"
    refs={k:reference(p)["sha256"] for k,p in files.items()}
    with tarfile.open(archive,"x:xz",preset=4) as bundle:
        for k,p in sorted(files.items()):
            bundle.add(p,arcname=k)
    with tarfile.open(archive,"r:xz") as bundle:
        for k,v in refs.items():
            assert hashlib.file_digest(bundle.extractfile(k),"sha256").hexdigest()==v
    write_json(DEST/"publication.json",{
       "source_trials":[reference(ROOT/"result.json"),reference(REFINED/"result.json")],
       "closed_pairs":len(records),"retained_arrays_independently_rechecked":n,
       "archive":native_ref(reference(archive)),"archive_members":refs,
       "rows":[{"noise":p,"layout":l,"method":m,**summary(group,m)}
               for (p,l),group in sorted(groups.items()) for m in group[0]["measurements"]],
       "geometry":geometry,"synthetic":boards,"camera":stills,
       "camera_trials":[reference(p/"standing/result.json") for p in (ROOT,REFINED,CAMERA_BANK)],
       "scope":"Scoped exact-reference known-carrier and biased-frequency tests with held-out Bayer support. Both real scenes use actual saved inputs and matched EMA controls. No model training or comparable primary panel.",
    })


if __name__=="__main__":
    main()
