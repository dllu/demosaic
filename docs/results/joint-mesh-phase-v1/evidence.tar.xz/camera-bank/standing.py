"""Qualitative replay using a bound shortlist and fresh exterior phase checks."""

import dataclasses
import importlib.util
import os
import sys
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.prediction_archive import fingerprint
from mesh import Carrier,restore
from refine import refine
from bank import bank_search

ROOT=Path(__file__).resolve().parent
EARLIER=ROOT.parent/"multiline-raw-shoulders-v1"
BANK=ROOT.parent/"donor-frequency-bank-v1/camera.json"
sys.path.append(str(EARLIER))
spec=importlib.util.spec_from_file_location("standing_binding",EARLIER/"standing.py")
legacy=importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)


def evidence(scene,colors,query,frequency,width,noise):
    left,top,_,_=query
    x,y=native_sites(scene.shape[-2:],(-left-127.5,-top-127.5))
    outer=(np.abs(x)>159.5)|(np.abs(y)>159.5)
    valid=(np.asarray(colors)[:,None,None]==1)&outer
    distance=frequency[0]*x+frequency[1]*y
    across=(-frequency[1]*x+frequency[0]*y)/np.linalg.norm(frequency)
    z=[]
    for side in (-1,1):
        sample=valid&(side*across>96)
        if sample.sum()<500:
            return None, {"status":"insufficient exterior coverage"}
        raw=scene[sample].astype(float)
        u,v=x[sample],y[sample]
        phase=2*np.pi*distance[sample]
        design=np.column_stack((np.ones(sample.sum()),u/256,v/256,np.cos(phase),np.sin(phase)))
        normal=design.T@design
        a=np.linalg.solve(normal,design.T@raw)
        var=max(float(np.median(raw)),1e-4)*noise["shot"]+noise["read"]
        cov=var*np.linalg.inv(normal)[-2:,-2:]
        snr=np.sqrt(a[-2:]@np.linalg.solve(cov,a[-2:]))
        angle=np.arctan2(a[4],a[3])
        z.append((angle,float(snr),float(np.hypot(a[3],a[4]))))
    angle=np.exp(1j*np.array([a[0] for a in z]))
    diff=float(abs(np.angle(angle[0]*angle[1].conjugate()))/(2*np.pi))
    result={"offsets_cycles":[float(q[0]/(2*np.pi)%1) for q in z],
            "nominal_scores":[q[1] for q in z],"amplitude":[q[2] for q in z],"phase_difference_cycles":diff}
    if diff>0.15 or min(q[1] for q in z)<3.5:
        return None,result|{"status":"phase or significance agreement missing"}
    new=Carrier(tuple(frequency),float(np.angle(angle.sum())/(2*np.pi)%1),width)
    return new,result|{"status":"passed"}


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    torch.set_num_threads(2)
    source=read_json(legacy.SAVED)
    plan=read_json(checked(source["plan"]))
    archived=read_json(BANK)
    by_id={r["id"]:r for r in archived["rows"]}
    kind={r["id"]:r for r in plan["observations"]}
    base_path=legacy.PREVIOUS/"none/collection.json"
    base=read_json(base_path)
    assert base["plan"]==source["plan"]
    snapshots={r["id"]:r for r in base["records"]}
    prior_path=EARLIER/"standing/result.json"
    previously={r["id"]:r for r in read_json(prior_path)["results"]}
    output=ROOT/"standing"
    output.mkdir()
    rows=[]
    for row in source["boards"]:
        obs=kind[row["observation"]]
        if obs["kind"] not in ("gfx","mesh"):
            continue
        id_=obs["id"]
        if obs["kind"]=="mesh":
            id_+= "-left" if row["id"].endswith("-left") else "-right"
        guide=by_id[id_]
        archive_fits=guide["fits"]
        label=next((l for l in ("spectral","scene") if all(archive_fits[l]["active"])),None)
        if label is None:
            label=next((l for l in ("scene","spectral") if archive_fits[l].get("frequencies_xy")),None)
        old=previously[row["id"]]
        found=snapshots[row["observation"]]
        with np.load(checked(obs["arrays"]),allow_pickle=False) as f:
            arrays={k:f[k] for k in ("packed","variance","colors","wb","matrix")}
        assert {k:fingerprint(v) for k,v in arrays.items()}==found["input_fingerprints"]
        pred=np.load(checked(found["prediction"]),allow_pickle=False)[0]
        box=old["native_query"]
        x,y,w,h=old["native_ROI"]
        roi=(x-box[0],y-box[1],w,h)
        p=legacy.window(pred,box)
        raw,var,c=(arrays[k][0] for k in ("packed","variance","colors"))
        candidates = [
            f for payload in guide["bank_records"].values()
            for f in payload.get("bank", {}).get("compatible_frequencies", ())
        ]
        for f in guide["fits"].values():
            candidates.extend(f.get("frequencies_xy", ()))
        proposals, statistics = bank_search(raw, c, box, candidates, obs["noise"])
        evidence_records = [statistics]
        ready = len(proposals) == 2
        additions, effects=[],{}
        for title,policy,local in (
            ("Additive mesh","add",False),("Joint crossing","adaptive",False),
            ("Local joint crossing","adaptive",True),
        ):
            changed,witness=p,[]
            if ready:
                changed,witness=restore(p,legacy.window(raw,box,phase=2),legacy.window(var,box,phase=2),c,
                         proposals,(obs["noise"]["shot"],obs["noise"]["read"]),method=policy,local=local)
            correction=65535*legacy.window(changed.astype(float)-p,roi)
            effects[title]={"rms_DN16":float(np.sqrt(np.mean(correction**2))),
                            "peak_DN16":float(np.abs(correction).max()),"fits":witness}
            additions.append((title,legacy.pixel(changed,arrays,roi,row["display_exposure"])))
        compact=row|{"panels":[v for v in row["panels"] if v["label"] not in ("Pooled2k","Spatial2k")]}
        image,panels=legacy.insert_camera_panels(output,row["id"],compact,"Local-only2k",additions)
        rows.append({"id":row["id"],"noise":obs["noise"],"native_query":box,"native_ROI":old["native_ROI"],
                     "display_exposure":row["display_exposure"],"image":image,"panels":panels,
                     "old_guide_query":guide["query"],"old_guide_label":"combined retained bank","evidence":evidence_records,
                     "accepted_both_exterior_phases":bool(ready),"parent_checkpoint":base["checkpoint"],
                     "parent":found["prediction"],"effects":effects})
        print(row["id"],label,bool(ready),[round(v["rms_DN16"],4) for v in effects.values()],flush=True)
    assert len(rows)==8
    write_json(output/"result.json",{
        "driver":reference(__file__),"archived_guide_bank":reference(BANK),"native_plan":source["plan"],
        "previous_native_queries":reference(prior_path),"method":reference(ROOT/"mesh.py"),"rows":rows,
        "scope":"Union of archived outer frequencies, ranked by first/second-side phase coherence and refined outside the query. In particular, a prior unvalidated direction is at most a proposed frequency. Both phase fits use only current exterior RAW with a 32px moat and two separated sides. The fitted paired model is checked on local Bayer before output.",
    })

if __name__=="__main__":
    main()
