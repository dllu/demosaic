"""Exterior phase screening over previously retained frequency candidates."""

import numpy as np

from demosaic.isolated_line import native_sites
from mesh import Carrier
from refine import Section,responses,refine


def projected_section(values, x, y, noise):
    des=np.column_stack((np.ones(len(x)), x/256, y/256))
    fit=np.linalg.solve(des.T@des,des.T@values)
    r=values-des@fit
    minimum=np.sqrt(noise["shot"]*max(1e-4,float(np.median(values)))+noise["read"])
    scale=max(minimum,1.4826*np.median(abs(r)),1e-7)
    return Section(np.column_stack((x,y)),(r/scale).clip(-8,8),scale,len(x))


def bank_search(scene,colors,box,candidates,noise):
    data=np.unique(np.rint(np.asarray(candidates,dtype=float).reshape(-1,2)*1536)/1536,axis=0)
    if len(data)==0:
        return [],{"candidate_count":0,"status":"no prior candidates"}
    data=np.where((data[:,0]<0)[:,None],-data,data)
    same=np.linalg.norm(data,axis=1)
    data=np.unique(data[(same>.033)&(same<.20)],axis=0)
    if len(data)==0:
        return [],{"candidate_count":0,"status":"outside carrier band"}
    x,y=native_sites(scene.shape[-2:],(-box[0]-127.5,-box[1]-127.5))
    green=np.broadcast_to(np.asarray(colors)[:,None,None]==1,scene.shape)
    q=[]
    for axis in (0,1):
        v=(x,y)[axis]
        # Carriers with a mostly horizontal normal have a vertical tangent.
        best=(np.abs(data[:,1])>np.abs(data[:,0])) if axis==0 else (np.abs(data[:,0])>=np.abs(data[:,1]))
        frequencies=data[best]
        sections=[]
        for sign in (-1,1):
            take=green&(sign*v>159.5)
            if take.sum()<1000:break
            sections.append(projected_section(scene[take].astype(float),x[take],y[take],noise))
        if len(sections)!=2 or not len(frequencies):
            continue
        a,b=(responses(s,frequencies) for s in sections)
        dot=np.real(a*np.conjugate(b))
        coh=dot/np.maximum(np.maximum(np.abs(a),np.abs(b)),1e-20)
        for f,score in zip(frequencies,coh,strict=True):
            q.append((float(score),tuple(f)))
    ordered=sorted(q,reverse=True)
    accepted=[]
    tested=[]
    for strength,f in ordered:
        if strength<3.5 or len(tested)==12:
            break
        if any(np.linalg.norm(np.asarray(f)-t[1]) < 2.5/256 for t in tested):
            continue
        tested.append((strength,np.asarray(f)))
        new,details=refine(scene,colors,box,Carrier(f,0,.080),noise)
        if new:
            accepted.append((new,strength,details))
    witnesses=[{"frequency":list(g.frequency),"score":s,"details":d} for g,s,d in accepted]
    for i,(one,a,r) in enumerate(accepted):
        for two,b,t in accepted[i+1:]:
            f=np.asarray([one.frequency,two.frequency])
            angle=abs(np.linalg.det(f)/np.prod(np.linalg.norm(f,axis=1)))
            if angle>.5:
                return [one,two],{"candidate_count":len(data),"individual":witnesses,"status":"pair"}
    return [],{"candidate_count":len(data),"individual":witnesses,"status":"no nonparallel coherent pair"}
