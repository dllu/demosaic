"""Require two exterior halves to corroborate a nearby carrier frequency."""

import dataclasses
from collections import namedtuple
import numpy as np

from demosaic.isolated_line import native_sites
from mesh import Carrier

Section = namedtuple("Section", "xy residual w count")


def outer_sections(raw,colors,box,guide,noise):
    x,y=native_sites(raw.shape[-2:],(-box[0]-127.5,-box[1]-127.5))
    fx,fy=guide.frequency
    gx,gy=guide.perspective
    direction=(-fy*x+fx*y)/np.hypot(fx,fy)
    mask=((np.abs(x)>159.5)|(np.abs(y)>159.5))&(np.asarray(colors)[:,None,None]==1)
    sections=[]
    for sign in (-1,1):
        # Both grants exclude the query and the moat and do not share pixels.
        keep=mask&(sign*direction>96)
        if keep.sum()<1000:
            return []
        s=raw[keep].astype(float)
        # Fit one affine camera-linear background per exterior side.
        design=np.column_stack((np.ones(len(s)),x[keep]/256,y[keep]/256))
        nuisance=np.linalg.solve(design.T@design,design.T@s)
        residual=s-design@nuisance
        med=np.median(s)
        scale=np.sqrt(noise["shot"]*max(med,1e-4)+noise["read"])
        standard=np.median(np.abs(residual))*1.4826
        scale=max(float(scale),float(standard),1e-7)
        response=(residual / scale).clip(-8,8)
        divide=1+gx*x[keep]+gy*y[keep]
        xy=np.column_stack((x[keep]/divide,y[keep]/divide))
        sections.append(Section(xy,response,scale,len(s)))
    return sections


def responses(section,frequencies):
    result=[]
    for start in range(0,len(frequencies),8):
        projected=2*np.pi*(section.xy@frequencies[start:start+8].T)
        score=(np.cos(projected).T@section.residual)+1j*(np.sin(projected).T@section.residual)
        result.extend(score/np.sqrt(section.count/2))
    return np.asarray(result)


def proposals(start,units):
    delta=np.asarray([(a,b) for a in units for b in units])
    return np.asarray(start)[None]+delta


def refine(raw,colors,box,start,noise):
    sections=outer_sections(raw,colors,box,start,noise)
    if not sections:
        return None,{"status":"coverage"}
    unit=np.arange(-2,3)/512
    bank=proposals(start.frequency,unit)
    witnesses=[]
    for i,(a,b) in enumerate((sections,sections[::-1])):
        r=responses(a,bank)
        initial=bank[np.argmax(np.abs(r))]
        finer=proposals(initial,np.arange(-1,2)/2048)
        tight=responses(a,finer)
        j=int(np.argmax(np.abs(tight)))
        f=finer[j]
        ta=tight[j]
        tb=responses(b,f[None])[0]
        in_phase=float(np.real(tb*np.conjugate(ta))/max(abs(ta),1e-20))
        witnesses.append({"frequency":f.tolist(),"training":float(abs(ta)),
                          "holdout":in_phase,"phase":float(np.angle(ta)/(2*np.pi)%1),
                          "holdout_phase":float(np.angle(tb)/(2*np.pi)%1)})
    da,db=(np.asarray(r["frequency"]) for r in witnesses)
    close=np.linalg.norm(da-db)<1.1/512
    if not close or min(r["holdout"] for r in witnesses)<3.5:
        return None,{"status":"withheld exterior or frequency agreement","halves":witnesses}
    average=(da+db)/2
    gain=np.array([responses(x,average[None])[0] for x in sections])
    diff=abs(np.angle(gain[0]*gain[1].conjugate()))/(2*np.pi)
    if diff>0.14 or np.abs(gain).min()<3.5:
        return None,{"status":"averaged phase agreement","halves":witnesses,"phase_difference":float(diff)}
    new=dataclasses.replace(start,frequency=tuple(average),offset=float(np.angle(gain.sum())/(2*np.pi)%1))
    return new,{"status":"passed","halves":witnesses,"phase_difference":float(diff)}
