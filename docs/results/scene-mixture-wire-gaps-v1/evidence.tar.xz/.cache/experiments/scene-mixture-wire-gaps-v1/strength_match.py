"""Calibrate comparator strength on development; score the same held-out captures."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'

import numpy as np

from collect import ROOT,load_data
from scoring import WireMetric,synthesize,base_fields,CROP_SCORED,ARM,summarize
from upper import luma
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

MODE=('supported','uniform','reversed')


def measurements(record,fit):
    args=load_data(record['case'])
    with np.load(checked(record['prediction']),allow_pickle=False)as stored:
        base,deltas,_=base_fields(stored['Corpus 100k'],stored['aligned'],args,record['profile'],fit)
    energy={k:float(np.mean(luma(v,args['wb'],args['matrix'])[CROP_SCORED]**2)) for k,v in deltas.items()}
    return args,base,deltas,energy


def main():
    plan=reference(ROOT/'strength-match-plan.json')
    development=read_json(checked(read_json(checked(plan))['fit']))
    predicted=read_json(checked(development['parent']))
    fit=read_json(checked(predicted['fit']))['fits'][ARM]
    scope=read_json(checked(development['protocol']))
    excluded=set(scope['excluded_wire_confirmation_source_ids'])
    dev=[r for r in predicted['rows'] if r['panel']=='development' and r['case']['noise']=='iso6400']
    cases=[r for r in predicted['rows'] if r['panel']=='confirmation' and r['source']['source']['id'] not in excluded]
    assert len(dev)==24 and len(cases)==18
    strength=development['fits']['supported']['gain']
    assert strength<0
    values=[measurements(row,fit)[-1] for row in dev]
    means={k:float(np.mean([r[k] for r in values])) for k in MODE}
    gain={k:strength*np.sqrt(means['supported']/means[k]) for k in MODE}
    held=[]
    for row in cases:
        args,base,deltas,energy=measurements(row,fit)
        metric=WireMetric(args,row['source']['geometry'])
        scores={k:metric(synthesize(base,deltas[k],gain[k])) for k in MODE}
        held.append(dict(source=row['source']['source']['id'],scores=scores,gap_pixels=int(metric.gap.sum()),
                    energy={k:float(v*gain[k]**2) for k,v in energy.items()}))
    summary={k:summarize(held,'supported',k) for k in MODE[1:]}
    held_energy={k:float(np.sqrt(np.mean([r['energy'][k] for r in held]))*65535) for k in MODE}
    write_json(ROOT/'strength-match.json',dict(driver=reference(__file__),plan=plan,gains=gain,
                 chosen_development_RMS_DN16=float(np.sqrt(means['supported'])*abs(strength)*65535),
                 held_RMS_DN16=held_energy,rows=held,summary=summary))
    print(gain,held_energy,flush=True)


if __name__=='__main__':
    main()
