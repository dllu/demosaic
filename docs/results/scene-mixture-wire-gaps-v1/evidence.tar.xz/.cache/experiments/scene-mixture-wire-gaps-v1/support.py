"""Restrict an endpoint-difference correction using agreement with native green measurements."""
from scipy.ndimage import gaussian_filter,map_coordinates
import numpy as np

from audit_delivery import compose_guarded
from upper import cap_band,luma,shape_delta,taper

FAMILIES=('supported','uniform','reversed')
WINDOW=4.0
PHASE_BAND_SMOOTH=1.15
AMPLITUDE_GRID=np.linspace(0,2,17)


def phase_support(raw,profile,roi,field):
    """Empirical same-observation score. Both neural predictions have seen the full CFA."""
    x0,y0,w,h=roi
    native_field=np.zeros(tuple(n*2 for n in raw['packed'].shape[-2:]),dtype=np.float64)
    native_field[y0:y0+h,x0:x0+w]=field
    y,x=np.meshgrid(np.arange(y0,y0+h),np.arange(x0,x0+w),indexing='ij')
    scores=[]
    for phase in np.flatnonzero(raw['colors']==1):
        dy,dx=divmod(phase,2)
        value=raw['packed'][phase].astype(np.float64)
        increment=native_field[dy::2,dx::2]
        level=gaussian_filter(value,PHASE_BAND_SMOOTH,mode='reflect')
        sensor=value-level
        increment=increment-gaussian_filter(increment,PHASE_BAND_SMOOTH,mode='reflect')
        variance=np.maximum(profile['shot']*np.maximum(0,level)+profile['read'],1e-12)
        covariance=gaussian_filter(sensor*increment,WINDOW,mode='reflect')
        variance_weighted_energy=gaussian_filter(variance*increment**2,WINDOW,mode='reflect')
        score=covariance*np.sqrt(4*np.pi)*WINDOW/np.sqrt(variance_weighted_energy+1e-20)
        scores.append(map_coordinates(score,[(y-dy)/2,(x-dx)/2],order=1,prefilter=False,mode='nearest'))
    assert len(scores)==2
    # Both green phases must support the sign. Smooth saturation limits
    # the influence of very large responses to a strong continuing edge.
    value=np.clip(np.minimum(*scores)/3,0,1)
    return value*value*(3-2*value)


def candidate_fields(parent,spatial,raw,profile,roi,scene,box,fit):
    guarded=compose_guarded(parent,spatial,raw,profile,roi,scene,box,fit)
    _,_,detail=shape_delta(parent,spatial,roi)
    wb,matrix=raw['wb'],raw['matrix']
    neutral=np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    wave=cap_band(-luma(detail,wb,matrix)/taper())
    # The measured increment is evaluated in the actual green phase positions.
    gate=phase_support(raw,profile,roi,wave*taper()*neutral[1])
    def correction(weight):
        return (neutral[:,None,None]*(cap_band(weight*wave)*taper())).astype(np.float32)
    return guarded,{'supported':correction(gate),'uniform':correction(1.),
                    'reversed':correction(gate[::-1,::-1])},gate


def restore(guarded,delta,strength,roi):
    x,y,w,h=roi
    rgb=guarded.copy()
    rgb[:,y:y+h,x:x+w]+=(delta*strength).astype(np.float32)
    return rgb
