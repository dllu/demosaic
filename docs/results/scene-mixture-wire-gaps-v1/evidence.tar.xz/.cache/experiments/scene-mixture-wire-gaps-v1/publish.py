"""Publish native crops, normalized pixel-band statistics and reproducible receipts."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from scoring import FINE,measure
from support import phase_support
from collect import ROOT,PRIOR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

IMAGES=Path('docs/images')/ROOT.name
RESULTS=Path('docs/results')/ROOT.name
BASE='Band-limited mix'
PARENT='Corpus 100k'


def preserve(board):
    source=checked(board['image'])
    subdir=source.parent.name
    assert subdir in ('exact','standing')
    rel=Path(subdir)/source.name
    target=IMAGES/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert reference(target)['sha256']==board['image']['sha256']
    image=np.asarray(Image.open(target).convert('RGB'))
    pixels={}
    for panel in board['panels']:
        x,y,w,h=panel['png_xywh']
        assert (w,h)==(160,160)
        pixels[panel.get('label',panel.get('name'))]=image[y:y+h,x:x+w]
    board['image']['path']=str(rel)
    return pixels


def algebra_check():
    axis=np.arange(160)
    xx,yy=np.meshgrid(axis,axis)
    field=.008*np.sin(2*np.pi*(.15*xx+.06*yy))
    colors=np.array([0,1,1,2])
    raw={'packed':np.full((4,80,80),.25),'colors':colors}
    profile={'shot':.00128,'read':6.5536e-6}
    roi=(0,0,160,160)
    view=np.s_[40:120,40:120]
    flat=phase_support(raw,profile,roi,field)
    raw['packed'][1]+=field[::2,1::2]
    raw['packed'][2]+=field[1::2,::2]
    agrees=phase_support(raw,profile,roi,field)
    raw['packed'][2]-=2*field[1::2,::2]
    opposing=phase_support(raw,profile,roi,field)
    assert float(flat.max())<1e-20 and float(opposing[view].max())<1e-20
    assert np.all((0<=agrees)&(agrees<=1)) and float(agrees[view].mean())>.8
    return {'constant_max':float(flat.max()),'joint_signal_mean':float(agrees[view].mean()),
            'opposing_center_max':float(opposing[view].max()),
            'meaning':'Algebraic sign and bounded-weight check on noiseless known fields.'}


def photo_summary(rows, pairs):
    # Parseval's identity on the orthonormal DCT. The collector averages only
    # selected coefficients, so include the zero coefficients in pixel RMS.
    assert np.array_equal(FINE,measure.BANDS['fine'])
    factor=float(np.sqrt(FINE.sum()/FINE.size))
    rng=np.random.default_rng(202611191028)
    output={}
    for arm,control in pairs:
        stats={}
        for key in rows[0]['scores'][arm]:
            valid=[row['scores'] for row in rows if row['scores'][arm][key] is not None]
            samples=np.vstack((np.arange(len(valid)),rng.integers(len(valid),size=(7000,len(valid)))))
            values=np.asarray([[row[name][key] for row in valid] for name in (arm,control)])
            if key.endswith('RMS_DN16'):
                totals=factor*np.sqrt(np.mean(values[:,samples]**2,axis=-1))
            else:
                totals=np.mean(values[:,samples],axis=-1)
            deltas=totals[0]-totals[1]
            stats[key]=dict(candidate=float(totals[0,0]),control=float(totals[1,0]),count=len(valid),
                            delta=float(deltas[0]),interval=np.quantile(deltas[1:],[.025,.975]).tolist())
        output[f'{arm} vs {control}']=stats
    return output


def main():
    RESULTS.mkdir(parents=True,exist_ok=True)
    names=('evaluation-plan','damping-plan','calibration','predictions','scores','confirmation-plan',
           'confirmation','strength-match-plan','strength-match','native','delivery')
    refs={name:reference(ROOT/f'{name}.json') for name in names}
    proof={name:read_json(checked(src)) for name,src in refs.items()}
    scores=proof['scores']
    fresh=proof['confirmation']
    fitted=proof['calibration']
    predictions=proof['predictions']
    visual=deepcopy(proof['native'])
    assert refs['scores']==visual['scored']==proof['delivery']['scores']
    assert refs['predictions']==scores['parent']==fitted['parent']
    assert refs['calibration']==scores['calibration']==proof['confirmation-plan']['frozen_fit']
    assert refs['strength-match-plan']==proof['strength-match']['plan']
    assert refs['confirmation-plan']==fresh['protocol']
    assert predictions['checkpoints']==fresh['checkpoints']==visual['checkpoints']
    assert len(scores['wire'])==18 and len(fresh['rows'])==24 and len(scores['photo'])==48
    assert sum(r['gap_pixels']>0 for r in scores['wire'])==8
    older_sources={r['source'] for r in scores['wire']+scores['photo']+fitted['calibration']+fitted['photo_calibration']}
    assert older_sources.isdisjoint(proof['confirmation-plan']['ids'])
    for item in predictions['checkpoints'].values():
        checked(item)
    assert visual['applied_gain']==scores['gains']['supported']==fitted['fits']['supported']['gain']
    assert not visual['standing']['same_recipe_gain_zero']
    for group in visual['standing']['rows']:
        cells=preserve(group['output'])
        assert 'Bayer-gated damping' in cells and 'ISO100 AHD reference' in cells
        if group['id'].startswith('mesh-'):
            assert all(k in cells for k in ('ISO100 camera JPEG','ISO6400 camera JPEG'))
    for view in visual['exact']:
        cells=preserve(view['board'])
        triplet=preserve(view['triplet'])
        assert list(triplet)==['Noisy Malvar','Bayer-gated damping','Exact GT']
        assert all(np.array_equal(tile,cells[name])for name,tile in triplet.items())
    assert len(visual['standing']['rows'])==8 and len(visual['exact'])==2
    manifest=IMAGES/'manifest.json'
    write_json(manifest,{**visual,'reviewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    archive=RESULTS/'evidence.tar.xz'
    paths=list(ROOT.glob('*.py'))+list(ROOT.glob('*.log'))+[checked(src) for src in refs.values()]
    paths.extend([PRIOR/'upper.py',PRIOR/'native.py',PRIOR/'fresh.py',PRIOR/'audit_delivery.py',
                  PRIOR.with_name('scene-gated-mixture-v1')/'mixture.py',
                  Path('scripts/report_scene_wave_guides.py'),Path('configs/gfx-qualitative-20231231.json'),
                  Path('configs/gfx-green-mesh-20231231.json')])
    for panel in predictions['protocol'].values():
        paths.extend(checked(ref) for ref in panel.values())
    paths.extend((checked(predictions['coefficients']),checked(predictions['fit'])))
    members={str(src.absolute().relative_to(Path.cwd())):src for src in paths}
    with tarfile.open(archive,'x:xz',preset=4) as tar:
        for name,path in sorted(members.items()):
            tar.add(path,arcname=name,recursive=False)
    with tarfile.open(archive) as tar:
        for name,path in members.items():
            with tar.extractfile(name)as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==reference(path)['sha256']
    supported=f"supported/{scores['gains']['supported']:g}"
    photo_this=photo_summary(scores['photo'],[(BASE,PARENT),(supported,BASE),(supported,PARENT)])
    extra='Bayer-gated damping'
    photo_fresh=photo_summary(fresh['rows'],[(extra,BASE),(extra,PARENT)])
    result=dict(checkpoints=predictions['checkpoints'],coefficients=predictions['coefficients'],
                weights=scores['gains'],fit_evidence={key:{k:value[k]for k in ('gain','feasible','feasible_nonnegative','chosen','zero')}
                                                    for key,value in fitted['fits'].items()},
                wire=scores['wire_summary'],wire_strength_match=proof['strength-match']['summary'],
                realized_damping_RMS_DN16=proof['strength-match']['held_RMS_DN16'],
                fixed_natural=photo_this,fresh_natural=photo_fresh,views=reference(manifest),
                delivered_bands=proof['delivery']['summary'],
                max_post_rounding_color_residue_DN16=proof['delivery']['max_post_rounding_color_residue_DN16'],
                receipts=refs,archive=reference(archive),algebra=algebra_check())
    write_json(RESULTS/'publication.json',result)
    print('Published',len(members),'archived members,',len(list(IMAGES.rglob('*.png'))),'native files',flush=True)


if __name__=='__main__':
    main()
