"""Measure recovery, continuing structure, and absence on disjoint held-out scenes."""
import os
import time

os.environ["OPENBLAS_NUM_THREADS"] = "1"

import numpy as np
from scipy.special import expit

from collect import ROOT,PRIOR,BOX,load_data
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from upper import ROI,SCORE,tile_dct,luma,load,metadata,measure
from native import apply
from support import AMPLITUDE_GRID,FAMILIES,candidate_fields,restore

ARM='limited_guard'
NATIVE=np.s_[...,48:208,48:208]
SCORED=np.s_[...,64:192,64:192]
CROP_SCORED=np.s_[...,16:144,16:144]
FINE=(np.hypot(*np.meshgrid(np.arange(16)/32,np.arange(16)/32))>=1/8)
FINE &= (np.hypot(*np.meshgrid(np.arange(16)/32,np.arange(16)/32))<1/3)
PLAN=ROOT/'evaluation-plan.json'
AMENDMENT=ROOT/'damping-plan.json'
GRID=np.r_[-AMPLITUDE_GRID[:0:-1],AMPLITUDE_GRID]


def rms(y):
    return np.sqrt(np.mean(y*y,axis=-1))*65535


def space(terms):
    matrix=np.column_stack(terms)
    u,s,_=np.linalg.svd(matrix,full_matrices=False)
    return u[:,s>s[0]*1e-8]


def remove_basis(y,basis):
    return y-(y@basis)@basis.T


def wire_bases(geometry,mask):
    y,x=np.meshgrid(np.arange(256)-127.5,np.arange(256)-127.5,indexing='ij')
    x=x[64:192,64:192][mask]
    y=y[64:192,64:192][mask]
    strong,weak=np.asarray(geometry['frequency'])
    def frequencies(vectors):
        terms=[]
        for freq in vectors:
            if not np.max(np.abs(freq))<.5 or not np.any(freq):
                continue
            phase=2*np.pi*(freq[0]*x+freq[1]*y)
            terms.extend((np.cos(phase),np.sin(phase)))
        return terms
    slope=geometry['angle']
    edge=x*np.cos(slope)+y*np.sin(slope)-geometry['edge']
    soft=expit(edge/1.3)
    nuisance=space([np.ones_like(x),x/64,y/64,x*x/4096,x*y/4096,y*y/4096,soft,soft*x/64,soft*y/64])
    directional=np.column_stack(frequencies([strong*n for n in (1,2,3,4)]))
    strong_basis=space(remove_basis(directional.T,nuisance))
    clean=np.column_stack((nuisance,strong_basis))
    weak_vector=[weak*n for n in (1,2,3,4)]+[weak+strong,weak-strong]
    weak_terms=np.column_stack(frequencies(weak_vector))
    orthogonal=space(remove_basis(weak_terms.T,clean))
    return clean,strong_basis,orthogonal


class WireMetric:
    def __init__(self,args,geometry):
        self.truth=luma(args['target'],args['wb'],args['matrix'])[SCORED]
        self.geometry=geometry
        support=args['support'][64:192,64:192]
        self.intact=support>=.97
        self.gap=support==0
        if geometry['family'] in ('ellipse','strip'):
            assert np.count_nonzero(self.gap)>=64
            np.testing.assert_array_equal(self.truth[0,self.gap],self.truth[2,self.gap])
            self.gap_nuisance,self.strong_basis,self.weak_basis=wire_bases(geometry,self.gap)
        else:
            assert not self.gap.any()
        self.intact_nuisance,_,_=wire_bases(geometry,self.intact)
        exact=(self.truth[0]-self.truth[2])[self.intact]
        self.truth_weak=remove_basis(exact,self.intact_nuisance)
        self.strength=self.truth_weak@self.truth_weak
        assert self.strength>0
        self.wb=args['wb']
        self.matrix=args['matrix']

    def __call__(self,pred):
        tone=luma(pred,self.wb,self.matrix)[SCORED]
        delta=remove_basis((tone[0]-tone[2])[self.intact],self.intact_nuisance)
        absence=tone[3]
        value={'weak_response_pp':float(100*(delta@self.truth_weak)/self.strength),
               'intact_increment_RMS_DN16':float(rms(delta-self.truth_weak)),
               'exact_flat_RMS_DN16':float(np.std(absence)*65535)}
        if self.gap.any():
            error=(tone[0]-self.truth[0])[self.gap]
            normalization=65535/np.sqrt(len(error))
            exterior=((tone[1]-tone[2])-(self.truth[1]-self.truth[2]))[self.gap]
            value.update(gap_RMS_DN16=float(rms(error)),
                         gap_continuing_strong_RMS_DN16=float(np.linalg.norm(error@self.strong_basis)*normalization),
                         gap_weak_RMS_DN16=float(np.linalg.norm(error@self.weak_basis)*normalization),
                         exterior_only_weak_RMS_DN16=float(np.linalg.norm(exterior@self.weak_basis)*normalization))
        return value


def base_fields(p,q,args,profile,fit):
    bases,deltas,gate=[],{f:[]for f in FAMILIES},[]
    for i in range(len(p)):
        raw={k:args[k]for k in ('wb','matrix','colors')}|{'packed':args['packed'][i]}
        base,scale,support=candidate_fields(p[i],q[i],raw,profile,ROI,args['scene_packed'],BOX,fit)
        bases.append(base)
        gate.append(support)
        for key,value in scale.items():
            deltas[key].append(value)
    return np.stack(bases),{k:np.stack(v)for k,v in deltas.items()},np.stack(gate)


def synthesize(base,delta,gain):
    result=base.copy()
    result[NATIVE]+=(delta*gain).astype(np.float32)
    return result


def reduce_wire(records,arm,metric):
    return float(np.mean([row[arm][metric] for row in records if row[arm].get(metric) is not None]))


def photo_metrics(args,pred):
    x,y,w,h=SCORE
    crop=np.s_[...,y:y+h,x:x+w]
    def band(v):
        return tile_dct(luma(v[crop],args['wb'],args['matrix']))[...,FINE]
    restored,truth=band(pred),band(args['target'])
    increment=restored[0]-restored[1]
    expected=truth[0]-truth[1]
    energy=float(np.sum(expected**2))
    return {'quiet_fine_RMS_DN16':float(rms((restored[2]-truth[2]).ravel())),
            'fine_increment_RMS_DN16':float(rms((increment-expected).ravel())),
            'fine_response_pp':float(100*np.sum(increment*expected)/energy) if energy>0 else None}


def evaluate_natural(fit,partition,gains=None):
    prior,view,_,_=metadata()
    frozen=read_json(checked(reference(PRIOR/'upper.json')))
    keys=set(frozen['split'][partition])
    rows=[row for row in view['source_metrics'] if row['source'] in keys and row['profile']=='iso6400' and row['draw']=='independent']
    assert len(rows)==(16 if partition=='calibration' else 48)
    outputs=[]
    for case in rows:
        settings,args,pred=load(case)
        p,q=pred['100k'],pred['spatial--matching']
        # The natural panel uses its own original query origins in the full measured scene.
        bases,deltas=[],{k:[]for k in FAMILIES}
        for i in range(3):
            raw={k:args[k]for k in ('wb','matrix','colors')}|{'packed':args['packed'][i]}
            base,candidates,_=candidate_fields(p[i],q[i],raw,settings['profile'],ROI,
                                               args['scene_packed'],settings['box'],fit)
            bases.append(base)
            for key,candidate in candidates.items():
                deltas[key].append(candidate)
        bases=np.stack(bases)
        deltas={k:np.stack(v)for k,v in deltas.items()}
        result={'Corpus 100k':photo_metrics(args,p),'Band-limited mix':photo_metrics(args,bases)}
        for key in FAMILIES:
            for gain in GRID if gains is None else (gains[key],):
                result[f'{key}/{gain:g}']=photo_metrics(args,synthesize(bases,deltas[key],gain))
        outputs.append(dict(source=case['source'],prediction=case['prediction_receipt'],scores=result))
    return outputs


def test_wire(record,prior,gains=None):
    args=load_data(record['case'])
    geometry=record['source']['geometry']
    metric=WireMetric(args,geometry)
    profile=record['profile']
    with np.load(checked(record['prediction']),allow_pickle=False)as stored:
        p,q,flip,v120=(stored[key] for key in ('Corpus 100k','aligned','reversed','V120'))
    model=prior['fits'][ARM]
    base,deltas,support=base_fields(p,q,args,profile,model)
    scores={'Corpus 100k':metric(p),'Band-limited mix':metric(base),'Spatial 40k':metric(q),'V120':metric(v120)}
    if gains is not None:
        reversed_base,_,_=base_fields(p,flip,args,profile,model)
        scores['Band-limited mix with reversed scene']=metric(reversed_base)
        wide=[]
        for i in range(4):
            raw={k:args[k]for k in ('wb','matrix','colors')}|{'packed':args['packed'][i]}
            wide.append(apply(p[i],q[i],raw,profile,ROI,args['scene_packed'],BOX,prior)['previous'])
        scores['Previous signed mix']=metric(np.stack(wide))
    for family in FAMILIES:
        for gain in GRID if gains is None else (gains[family],):
            scores[f'{family}/{gain:g}']=metric(synthesize(base,deltas[family],gain))
    return dict(source=record['source']['source']['id'],index=record['case']['index'],geometry=geometry['family'],
                profile=record['case']['noise'],panel=record['panel'],scores=scores,
                gap_pixels=int(metric.gap.sum()),green_phase_gate=dict(quiet_mean=float(support[3].mean()),
                  present_mean=float(support[0].mean())))


def fit_gains(dev,natural):
    wire=[r['scores'] for r in dev if r['profile']=='iso6400']
    photo=[r['scores'] for r in natural]
    ceilings={'wire_flat':reduce_wire(wire,'Corpus 100k','exact_flat_RMS_DN16'),
              'actual_gap':reduce_wire(wire,'Corpus 100k','gap_RMS_DN16'),
              'weak_gap':reduce_wire(wire,'Corpus 100k','gap_weak_RMS_DN16'),
              'natural_flat':reduce_wire(photo,'Corpus 100k','quiet_fine_RMS_DN16'),
              'wire_increment':reduce_wire(wire,'Corpus 100k','intact_increment_RMS_DN16'),
              'photo_increment':reduce_wire(photo,'Corpus 100k','fine_increment_RMS_DN16')}
    fits={}
    for family in FAMILIES:
        proposals=[]
        for gain in GRID:
            key=f'{family}/{gain:g}'
            metrics=dict(wire_flat=reduce_wire(wire,key,'exact_flat_RMS_DN16'),
                         actual_gap=reduce_wire(wire,key,'gap_RMS_DN16'),
                         weak_gap=reduce_wire(wire,key,'gap_weak_RMS_DN16'),
                         natural_flat=reduce_wire(photo,key,'quiet_fine_RMS_DN16'),
                         wire_increment=reduce_wire(wire,key,'intact_increment_RMS_DN16'),
                         photo_increment=reduce_wire(photo,key,'fine_increment_RMS_DN16'))
            response=reduce_wire(wire,key,'weak_response_pp')
            proposals.append(dict(gain=float(gain),metrics=metrics,response=response,
                                  eligible=all(metrics[k]<=val for k,val in ceilings.items())))
        feasible=[p for p in proposals if p['eligible']]
        zero=next(row for row in proposals if row['gain']==0)
        winner=max(feasible,key=lambda row:(row['response'],-abs(row['gain']))) if feasible else zero
        fits[family]=dict(gain=winner['gain'],feasible=len(feasible),
                          feasible_nonnegative=sum(row['gain']>=0 for row in feasible),
                          zero=zero,chosen=winner,sweep=proposals)
    return fits,ceilings


def summarize(records,left,right):
    rows=[r['scores'] for r in records]
    rng=np.random.default_rng(202611191025)
    result={}
    for metric in rows[0][left]:
        delta=np.asarray([r[left][metric]-r[right][metric]for r in rows if r[left].get(metric) is not None and r[right].get(metric) is not None])
        if not len(delta):
            continue
        sample=rng.integers(len(delta),size=(6000,len(delta)))
        result[metric]=dict(count=len(delta),candidate=reduce_wire(rows,left,metric),
                            control=reduce_wire(rows,right,metric),delta=float(delta.mean()),
                            interval=np.quantile(delta[sample].mean(1),(.025,.975)).tolist())
    # The first row can be a non-gap geometry.
    gap=[r for r in records if r.get('gap_pixels',0)>0]
    if gap and 'gap_RMS_DN16' not in result:
        result.update({k:v for k,v in summarize(gap,left,right).items() if k.startswith(('gap','exterior'))})
    return result


def main():
    start=time.monotonic()
    proof=reference(ROOT/'predictions.json')
    receipt=read_json(checked(proof))
    prior=read_json(checked(receipt['fit']))
    settings=read_json(PLAN)
    amendment=read_json(AMENDMENT)
    assert amendment['original_protocol']==reference(PLAN)
    assert settings['predicted_protocol']==receipt['protocol']
    dev=[row for row in receipt['rows'] if row['panel']=='development']
    excluded=set(settings['excluded_wire_confirmation_source_ids'])
    held=[row for row in receipt['rows'] if row['panel']=='confirmation' and row['source']['source']['id'] not in excluded]
    assert len(dev)==48 and len(held)==18
    calibration=[test_wire(row,prior)for row in dev]
    natural_calibration=evaluate_natural(prior['fits'][ARM],'calibration')
    fit,ceilings=fit_gains(calibration,natural_calibration)
    gains={key:value['gain']for key,value in fit.items()}
    print('Fitted gains',gains,{key:value['feasible'] for key,value in fit.items()},flush=True)
    write_json(ROOT/'calibration.json',dict(driver=reference(__file__),protocol=reference(PLAN),amendment=reference(AMENDMENT),parent=proof,
               calibration=calibration,photo_calibration=natural_calibration,fits=fit,ceilings=ceilings))
    held_wire=[test_wire(row,prior,gains)for row in held]
    held_photo=evaluate_natural(prior['fits'][ARM],'test',gains)
    support=f"supported/{gains['supported']:g}"
    comparisons=[('Band-limited mix','Corpus 100k'),('Band-limited mix','V120'),
                 ('Band-limited mix','Spatial 40k'),('Band-limited mix','Previous signed mix'),
                 ('Band-limited mix','Band-limited mix with reversed scene'),
                 (support,'Band-limited mix'),(support,f"uniform/{gains['uniform']:g}"),
                 (support,f"reversed/{gains['reversed']:g}"),(support,'Corpus 100k')]
    wire_summary={f'{a} vs {b}':summarize(held_wire,a,b)for a,b in comparisons}
    photo_summary={f'{a} vs {b}':summarize(held_photo,a,b)for a,b in comparisons
                   if {a,b}.issubset(held_photo[0]['scores'])}
    write_json(ROOT/'scores.json',dict(driver=reference(__file__),protocol=reference(PLAN),amendment=reference(AMENDMENT),parent=proof,
        calibration=reference(ROOT/'calibration.json'),gains=gains,wire=held_wire,photo=held_photo,
        wire_summary=wire_summary,photo_summary=photo_summary,wall_seconds=time.monotonic()-start))
    print('Finished',round(time.monotonic()-start,2),flush=True)


if __name__=='__main__':
    main()
