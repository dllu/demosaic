"""Check delivered upper-band luma and chroma after the signed local damping."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'

import numpy as np

from collect import ROOT,PRIOR
from scoring import ARM,synthesize
from support import candidate_fields
from upper import ROI,SCORE,metadata,load,tile_dct,luma,measure
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def magnitudes(pred,args):
    x,y,w,h=SCORE
    view=np.s_[...,y:y+h,x:x+w]
    error=luma((pred-args['target'])[view],args['wb'],args['matrix'])
    dct=tile_dct(error)
    result={}
    for band in ('lower','upper'):
        mask=measure.BANDS[band]
        result[band+'_increment']=float(np.linalg.norm((dct[0]-dct[1])[...,mask])*65535/96)
        result[band+'_flat']=float(np.linalg.norm(dct[2,...,mask])*65535/96)
    return result


def main():
    records=reference(ROOT/'scores.json')
    receipt=read_json(checked(records))
    proof=read_json(checked(receipt['parent']))
    frozen=read_json(checked(proof['fit']))
    settings=frozen['fits'][ARM]
    gain=receipt['gains']['supported']
    photo={row['source']:row for row in receipt['photo']}
    _,reviews,_,_=metadata()
    cases=[case for case in reviews['source_metrics']
           if case['source'] in photo and case['profile']=='iso6400' and case['draw']=='independent']
    assert len(cases)==48
    audits=[]
    for case in cases:
        assert case['prediction_receipt']==photo[case['source']]['prediction']
        condition,args,pred=load(case)
        p,q=pred['100k'],pred['spatial--matching']
        base,adjustment=[],[]
        for i in range(3):
            raw={k:args[k]for k in ('colors','wb','matrix')}|{'packed':args['packed'][i]}
            current,delta,_=candidate_fields(p[i],q[i],raw,condition['profile'],ROI,args['scene_packed'],condition['box'],settings)
            base.append(current)
            adjustment.append(delta['supported'])
        base,adjustment=np.stack(base),np.stack(adjustment)
        candidate=synthesize(base,adjustment,gain)
        color=np.einsum('ji,bihw->bjhw',args['matrix'],(candidate.astype(float)-base)*args['wb'][None,:,None,None])
        max_color_residue=float(np.max(np.abs(color-color.mean(1,keepdims=True)))*65535)
        assert max_color_residue<.02
        audits.append(dict(source=case['source'],prediction=case['prediction_receipt'],max_color_residue_DN16=max_color_residue,
                 parent=magnitudes(p,args),base=magnitudes(base,args),damping=magnitudes(candidate,args)))
    rng=np.random.default_rng(202611191031)
    n=len(audits)
    samples=np.vstack((np.arange(n),rng.integers(n,size=(6000,n))))
    summaries={}
    for key in audits[0]['base']:
        values={method:np.sqrt(np.mean(np.asarray([row[method][key]for row in audits])[samples]**2,axis=1))
                for method in ('parent','base','damping')}
        deltas={method:values['damping']-values[method] for method in ('parent','base')}
        summaries[key]={'means':{k:float(v[0]) for k,v in values.items()},
                         'deltas':{k:{'point':float(v[0]),'interval':np.quantile(v[1:],[.025,.975]).tolist()}
                                   for k,v in deltas.items()}}
    write_json(ROOT/'delivery.json',dict(driver=reference(__file__),scores=records,rows=audits,summary=summaries,
                 max_post_rounding_color_residue_DN16=max(row['max_color_residue_DN16']for row in audits)))
    print(summaries,flush=True)


if __name__=='__main__':
    main()
