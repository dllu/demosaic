"""Render the calibrated composition and exact held-out gap targets at native scale."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'

import numpy as np
import torch

from collect import ROOT,PRIOR,BOX,load_data
from scoring import ARM,base_fields,synthesize
from upper import ROI
from native import old_pixels,native_png
from support import candidate_fields,restore
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

STANDING=ROOT.parent.parent.parent/'docs/images/scene-mixture-upper-band-v1/manifest.json'


def exact(predictions, scored, frozen, gain):
    cases=[row for row in scored['wire'] if row['gap_pixels']]
    arm=f'supported/{gain:g}'
    control='Corpus 100k'
    ranks=sorted(cases,key=lambda row:row['scores'][arm]['gap_weak_RMS_DN16']-row['scores'][control]['gap_weak_RMS_DN16'])
    out=ROOT/'exact'
    out.mkdir(exist_ok=True)
    renders=[]
    for selected in (ranks[0],ranks[-1]):
        item=next(r for r in predictions['rows'] if r['panel']=='confirmation' and r['case']['index']==selected['index'])
        args=load_data(item['case'])
        with np.load(checked(item['prediction']),allow_pickle=False) as f:
            p,q,v=(f[k]for k in ('Corpus 100k','aligned','V120'))
        base,deltas,_=base_fields(p,q,args,item['profile'],frozen['fits'][ARM])
        supported=synthesize(base,deltas['supported'],gain)
        a={k:args[k][None]for k in ('colors','wb','matrix')}|{'packed':args['packed'][0:1]}
        shown=[noisy_malvar(a)[0],v[0],p[0],q[0],base[0],supported[0],args['target'][0]]
        label=('Noisy Malvar','V120 EMA','Corpus 100k EMA','Spatial 40k EMA','Band-limited mix','Bayer-gated damping','Exact GT')
        settings=dict(source=item['source'],source_case=item['case'],profile=item['profile'],query_xywh=BOX,
                      exposure=2,contrast=1,checkpoints=predictions['checkpoints'],fit=predictions['coefficients'],
                      gain=gain)
        key=f"{selected['index']:03d}-iso6400"
        renders.append(native_board(out,key,shown,a,settings,labels=label,
                                     triplet_indices=(0,5,6),exposure=2,roi=ROI))
    return renders


def standing(frozen,gain):
    current=reference(STANDING)
    proof=read_json(checked(current))
    assert proof['models']==frozen['checkpoints']
    if gain==0:
        previous=[]
        original=STANDING.parent
        for row in proof['standing']['rows']:
            path=original/row['output']['image']['path']
            seen=reference(path)
            assert seen['sha256']==row['output']['image']['sha256']
            previous.append({'row':row,'source_bound_image':seen})
        assert len(previous)==8
        return {'published_reference':current,'same_recipe_gain_zero':True,'rows':previous}
    earlier=read_json(checked(proof['standing']['earlier']))
    assert earlier['models']==frozen['checkpoints']
    out=ROOT/'standing'
    out.mkdir(exist_ok=True)
    records=[]
    torch.set_num_threads(2)
    for group in ('main','mesh'):
        rows=[row for row in earlier['standing']['records'] if row['id'].startswith(group+'-')]
        source=rows[0]['raw']
        mosaic,meta=read_raw(checked(source))
        h,w=mosaic.shape
        scene=np.stack([mosaic[y:h//2*2:2,x:w//2*2:2] for y in range(2) for x in range(2)])
        del mosaic
        for row in rows:
            x,y,w,h=row['native_sensor_box']
            with np.load(checked(row['input']),allow_pickle=False) as data:
                raw={k:data[k][0]for k in ('packed','colors','wb','matrix')}
            assert np.array_equal(raw['colors'],color_indices(meta.pattern))
            assert np.array_equal(raw['packed'],scene[:,y//2:(y+h)//2,x//2:(x+w)//2])
            p,q=(np.load(checked(row['parent_images'][k]),allow_pickle=False)[0]for k in ('parent100k','spatial'))
            roi=row['roi']
            base,delta,gate=candidate_fields(p,q,raw,row['conditioning'],roi,scene,
                                            row['native_sensor_box'],frozen['fits'][ARM])
            delivered=restore(base,delta['supported'],gain,roi)
            old=old_pixels(row['board'])
            wb,matrix=(torch.from_numpy(raw[k][None])for k in ('wb','matrix'))
            def display(rgb):
                view=display_crop(torch.from_numpy(rgb[None]),wb,matrix,roi,exposure=row['display_exposure'])
                return np.rint(view.clip(0,1)*255).astype(np.uint8)
            selectors=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Spatial 40k EMA')
            boards=[(key,old[key])for key in selectors if key in old]
            boards.extend([('Band-limited mix',display(base)),('Bayer-gated damping',display(delivered))])
            boards.extend((key,old[key])for key in ('ISO100 AHD reference','ISO100 camera JPEG')if key in old)
            delta_rgb=delivered.astype(float)-base
            x,y,w,h=roi
            rms=float(np.sqrt(np.mean(delta_rgb[:,y:y+h,x:x+w]**2))*65535)
            records.append(dict(id=row['id'],raw=source,roi=roi,context=row['native_sensor_box'],
                   input=row['input'],native_reference=row['board'],parent_images=row['parent_images'],
                   shot_read=row['conditioning'],exposure=row['display_exposure'],gate_mean=float(gate.mean()),
                   compared_RMS_DN16=rms,output=native_png(out/f"{row['id']}.png",boards)))
        del scene
    assert len(records)==8
    return {'published_reference':current,'same_recipe_gain_zero':False,'rows':records}


def main():
    proof=reference(ROOT/'scores.json')
    scores=read_json(checked(proof))
    predicts=read_json(checked(scores['parent']))
    fixed=read_json(checked(predicts['fit']))
    gain=scores['gains']['supported']
    exact_views=exact(predicts,scores,fixed,gain)
    standing_views=standing(fixed,gain)
    write_json(ROOT/'native.json',dict(driver=reference(__file__),scored=proof,checkpoints=predicts['checkpoints'],
         applied_gain=gain,exact=exact_views,standing=standing_views))
    print('rendered',len(exact_views),len(standing_views['rows']),gain,flush=True)


if __name__=='__main__':
    main()
