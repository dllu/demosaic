"""Confirm the fixed damping on additional unplanted photos and fresh noise."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import time

import numpy as np
import torch

from collect import ROOT,PRIOR,PANELS
from fresh import config,numpy_input,networks,predictions,prepare_eval
import fresh
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from scoring import ARM,photo_metrics,summarize,synthesize
from support import candidate_fields
from upper import ROI

SEED=202611191023


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    fit,cohort,profiles,couplings,source_protocol=config()
    parent=reference(ROOT/'calibration.json')
    gains={k:v['gain'] for k,v in read_json(checked(parent))['fits'].items()}
    original=read_json(checked(reference(ROOT/'evaluation-plan.json')))
    sources=[panel['plan'] for panel in original['predicted_protocol'].values()]
    removed={row['source']['id'] for plan in sources for row in read_json(checked(plan))['sources']}
    selected=[row for row in cohort if row['source']['id'] not in removed]
    assert len(selected)==24
    profile=next(p for p in profiles if p['name']=='iso6400')
    assert 'independent' in couplings
    protocol=dict(frozen_fit=parent,original_source=source_protocol,exclusion_sources=sources,
                  ids=[r['source']['id'] for r in selected],profile=profile,draw='independent',new_seed=SEED)
    write_json(ROOT/'confirmation-plan.json',protocol)
    models=networks(fit['checkpoints'])
    fresh.SEED=SEED
    begin=time.monotonic()
    inference=0.
    receipts=[]
    for row in selected:
        photo=prepare_eval.load_photo(row)
        args=numpy_input(row,photo,profile,'independent')
        settings={'box':row['box'],'profile':profile}
        before=time.monotonic()
        values,previews=predictions(models,args,settings)
        inference+=time.monotonic()-before
        p,q=values['100k'],values['spatial--matching']
        base,update=[],[]
        for i in range(3):
            raw={k:args[k]for k in ('wb','matrix','colors')}|{'packed':args['packed'][i]}
            guarded,delta,_=candidate_fields(p[i],q[i],raw,profile,ROI,args['scene_packed'],row['box'],fit['fits'][ARM])
            base.append(guarded)
            update.append(delta['supported'])
        base,update=np.stack(base),np.stack(update)
        candidate=synthesize(base,update,gains['supported'])
        scores={'Corpus 100k':photo_metrics(args,p),'Band-limited mix':photo_metrics(args,base),
                'Bayer-gated damping':photo_metrics(args,candidate)}
        receipts.append(dict(source=row,pixels={k:fingerprint(v) for k,v in args.items()},
                             previews=previews,predictions={k:fingerprint(v) for k,v in values.items()},scores=scores))
        if len(receipts)%6==0:
            print(len(receipts),round(time.monotonic()-begin,2),flush=True)
    comparisons=[('Bayer-gated damping','Band-limited mix'),('Bayer-gated damping','Corpus 100k')]
    stats={f'{a} vs {b}':summarize(receipts,a,b)for a,b in comparisons}
    write_json(ROOT/'confirmation.json',dict(driver=reference(__file__),protocol=reference(ROOT/'confirmation-plan.json'),
                 checkpoints=fit['checkpoints'],rows=receipts,summary=stats,
                 inference_seconds=inference,wall_seconds=time.monotonic()-begin))
    print('Finished',round(time.monotonic()-begin,2),flush=True)


if __name__=='__main__':
    main()
