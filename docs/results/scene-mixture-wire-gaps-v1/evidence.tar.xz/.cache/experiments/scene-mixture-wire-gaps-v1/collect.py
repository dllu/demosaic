"""Replay the frozen Corpus and spatial EMAs on independent true-gap observations."""
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
PRIOR=ROOT.with_name('scene-mixture-upper-band-v1')
sys.path[:0]=[str(PRIOR),str(Path('scripts').resolve())]
from fresh import networks, scene_preview, encode
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

BOX=(128,128,256,256)
PACKED_ROI=np.s_[:,64:192,64:192]
NATIVE_ROI=np.s_[:,:,128:384,128:384]
ROLES=('present','outside-only','strong-only','quiet')
FROZEN_FIT=Path('docs/results/scene-mixture-upper-band-v1/coefficients.json')
PANELS={'development':ROOT.with_name('query-exterior-colour-v1'),
        'confirmation':ROOT.with_name('query-gap-shoulders-v1')}


def source_panels():
    sources,protocol=[],{}
    found=set()
    for name,root in PANELS.items():
        release=reference(root/'captures.json')
        records=read_json(checked(release))
        plan=read_json(checked(records['source']))
        assert tuple(plan['roles'])==ROLES and tuple(plan['query'])==BOX
        assert len(plan['sources'])==24
        ids={row['source']['id'] for row in plan['sources']}
        assert len(ids)==24 and found.isdisjoint(ids)
        found|=ids
        manifest=checked(plan['training_manifest'])
        with manifest.open() as stream:
            assert not ids.intersection(json.loads(line)['id'] for line in stream)
        sources.extend((name,plan['sources'][case['index']],case,plan['profiles'][case['noise']])
                       for case in records['rows'])
        protocol[name]={'plan':records['source'],'captures':release}
    assert len(sources)==72
    return sources,protocol


def load_data(case):
    with np.load(checked(case['input']),allow_pickle=False) as src:
        full=src['packed']
        assert full.shape==(4,4,256,256)
        packed=full[:,:,64:192,64:192]
        args={'packed':packed,'variance':src['variance'][:,:,64:192,64:192]}
        for key in ('colors','wb','matrix'):
            cam=src[key]
            assert np.all(cam==cam[0])
            args[key]=cam[0]
        args['scene_packed']=full[1]
        args['target']=src['target'][NATIVE_ROI]
        args['support']=src['support']
        args['weak_linear']=src['weak_linear']
    return args


@torch.inference_mode()
def predict(parent,spatial,v120,args,profile):
    for model in (parent,spatial.base,v120):
        model.set_noise(profile['shot'],profile['read'])
    camera=[torch.from_numpy(args[k]).cuda()for k in ('colors','wb','matrix')]
    packed=torch.from_numpy(args['packed']).cuda()
    variance=torch.from_numpy(args['variance']).cuda()
    source=torch.from_numpy(args['scene_packed']).cuda()
    query=[x.contiguous(memory_format=torch.channels_last) for x in (packed,variance)]
    query += [v[None].expand(4,*v.shape) for v in camera]
    encodings,preview_hashes={},{}
    with ieee_fp32():
        for name,base in (('aligned',source),('reversed',source.flip((-2,-1)))):
            encodings[name]=[]
            preview_hashes[name]=[]
            for role in packed:
                scene=base.clone()
                scene[PACKED_ROI].copy_(role)
                assert torch.equal(scene[PACKED_ROI],role)
                assert torch.equal(scene[:,:64],base[:,:64]) and torch.equal(scene[:,192:],base[:,192:])
                preview,grid=scene_preview(scene,*camera,long_side=1024,exposure=1)
                preview_hashes[name].append(fingerprint(preview.cpu()))
                encodings[name].append(encode(spatial,preview,grid))
        predictions={'Corpus 100k':parent(*query).cpu().numpy(),'V120':v120(*query).cpu().numpy()}
        for name,scene in encodings.items():
            predictions[name]=spatial(*query,scene=scene,boxes_xywh=[BOX]*4).cpu().numpy()
    assert all(y.shape==(4,3,256,256) and np.isfinite(y).all() for y in predictions.values())
    return predictions,preview_hashes


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,10*2**30/torch.cuda.get_device_properties(0).total_memory))
    rows,protocol=source_panels()
    frozen=reference(PRIOR/'upper.json')
    prior=read_json(checked(frozen))
    coefficients=reference(FROZEN_FIT)
    assert coefficients['sha256']=='bb70c73e03859c2e03f4e7f8535e24ecf0650e4d86c3765fb133556fadae96cb'
    base,spatial=networks(prior['checkpoints'])
    checkpoint=prior['checkpoints']['V120']
    v120,state=load_checkpoint(checked(checkpoint),'cuda',tiled_inference=True)
    assert 'ema' in state and checkpoint['sha256']==state['loaded_sha256']
    del state
    v120.eval().to(memory_format=torch.channels_last)
    out=ROOT/'predictions'
    out.mkdir(exist_ok=True)
    receipts=[]
    inference_seconds=0.
    begin=time.monotonic()
    for panel,source,case,profile in rows:
        args=load_data(case)
        stem=f"{panel}-{case['index']:03d}-{case['noise']}"
        target=out/f'{stem}.npz'
        start=time.monotonic()
        predictions,previews=predict(base,spatial,v120,args,profile)
        inference_seconds+=time.monotonic()-start
        np.savez_compressed(target,**predictions)
        receipts.append(dict(panel=panel,source=source,case=case,profile=profile,
                             prediction=reference(target),previews=previews,
                             exterior_source_role='outside-only'))
        if len(receipts)%8==0:
            print(len(receipts),round(time.monotonic()-begin,2),round(inference_seconds,2),flush=True)
    write_json(ROOT/'predictions.json',dict(driver=reference(__file__),protocol=protocol,
               fit=frozen,coefficients=coefficients,checkpoints=prior['checkpoints'],rows=receipts,
               query=BOX,roles=ROLES,inference_seconds=inference_seconds,wall_seconds=time.monotonic()-begin,
               precision='CUDA IEEE FP32 EMA',exterior_control='packed phase grids reversed, same query'))
    print('complete',len(receipts),round(inference_seconds,2),flush=True)


if __name__=='__main__':
    main()
