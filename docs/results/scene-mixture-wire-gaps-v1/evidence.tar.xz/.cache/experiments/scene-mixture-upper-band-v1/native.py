"""Apply the spectral refit at native scale on frozen photo and GFX comparisons."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from upper import ROOT,PREVIOUS,L,ROI,SCORE,measure,tile_dct,luma,load,maps,metadata
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
from render import native_png

LABELS={
    'previous':'Previous signed mix',
    'signed_guard':'Wide boost with guard',
    'limited_no_refit':'Low-pass only',
    'limited_local':'Refit, local gate',
    'limited_registered':'Refit, registered gate',
    'limited_guard':'Band-limited guarded mix',
}
ARMS=tuple(LABELS)


def apply(p,q,raw,noise,roi,scene,box,fit):
    low,high,g,terms=maps(p,q,raw,noise,roi,scene,box)
    wb=raw['wb']
    matrix=raw['matrix']
    direction=np.linalg.solve(matrix.astype(float),np.ones(3))/np.asarray(wb,dtype=float)
    assert abs(float(luma(direction[:,None,None],wb,matrix)[0,0])-1.)<1e-13
    result={}
    x,y,w,h=roi
    for name in ARMS:
        if name in ('previous','limited_no_refit'):
            op='wide' if name=='previous' else 'limited'
            weights=fit['previous_parameters']
        else:
            model=fit['fits'][name]
            op=model['operator']
            weights=model['coefficients']
        lo,hi,signed=np.split(np.asarray(weights),3)
        gain1,gain2=(np.einsum('i,ihw->hw',v,g)for v in (lo,hi))
        assert lo.min()>=0 and hi.min()>=0 and signed.min()>=0
        assert abs(lo.sum()-1.)<1e-7 and abs(hi.sum()+signed.sum()-1.)<1e-7
        field=np.einsum('i,ihw->hw',signed,terms[2 if op=='wide' else 3])
        out=p.copy()
        out[:,y:y+h,x:x+w]+=(gain1*low+gain2*high+direction[:,None,None]*field).astype(np.float32)
        result[name]=out
    return result


def exact(fit):
    _,review,_,settings=metadata()
    key={m['prediction_receipt']['sha256']:m for m in fit['rows']}
    out=ROOT/'exact'
    out.mkdir(exist_ok=True)
    samples=[]
    for item in fit['examples']:
        source=next(n for n in review['source_metrics'] if (n['source'],n['profile'],n['draw'])==
                    (item['source'],item['profile'],item['draw']))
        case,data,predicted=load(source)
        archive=key[source['prediction_receipt']['sha256']]
        roi=ROI
        renders={n:[]for n in ARMS}
        for i in range(3):
            raw={k:data[k]for k in ('colors','wb','matrix')}|{'packed':data['packed'][i]}
            values=apply(predicted['100k'][i],predicted['spatial--matching'][i],raw,case['profile'],
                         roi,data['scene_packed'],case['box'],fit)
            for name,arr in values.items():
                renders[name].append(arr)
        x,y,w,h=SCORE
        region=np.s_[...,y:y+h,x:x+w]
        truth=tile_dct(luma(data['target'][region],data['wb'],data['matrix']))
        checks={}
        for name,values in renders.items():
            dct=tile_dct(luma(np.stack(values)[region],data['wb'],data['matrix']))
            delta=dct-truth
            for band,mask in measure.BANDS.items():
                difference=(delta[0]-delta[1])[...,mask]
                actual=float(np.linalg.norm(difference)*65535./96)
                expected=float(np.sqrt(archive['scores'][name][band]['increment']))
                checks[name+'/'+band]=abs(actual-expected)
        assert max(checks.values())<.002
        coeff={k:data[k][None]for k in ('colors','wb','matrix')}|{'packed':data['packed'][:1]}
        variants=('Noisy Malvar','Corpus 100k EMA','Spatial 40k EMA',*(LABELS[n] for n in ARMS),'Exact GT')
        fields=(noisy_malvar(coeff)[0],predicted['100k'][0],predicted['spatial--matching'][0],
                *(renders[n][0]for n in ARMS),data['target'][0])
        row=settings['rows'][case['case']]
        samples.append(native_board(out,case['id']+'-upper-band',fields,coeff,
           {'source':row['source'],'CFA':row['camera']['pattern'],'query':case['box'],
            'noise':case['profile'],'ADC_bits':16,'black_level':row['camera']['black'],
            'input':case['input'],'checkpoints':fit['checkpoints'],'fine_increment_change_DN16':item['delta_DN16'],
            'native_synthesis_check_max_DN16':max(checks.values())},
           labels=variants,triplet_indices=(0,variants.index(LABELS['limited_guard']),len(variants)-1),
           roi=roi,exposure=1/case['profile']['exposure'],contrast=2))
    return samples


def old_pixels(board):
    image=np.asarray(Image.open(checked(board['image'])).convert('RGB'))
    return {c.get('label',c.get('name')):image[y:y+h,x:x+w]for c in board['panels']
             for x,y,w,h in [c['png_xywh']]}


def standing(fit):
    provenance=reference(PREVIOUS/'native.json')
    earlier=read_json(checked(provenance))
    assert earlier['models']==fit['checkpoints']
    wdir=ROOT/'standing'
    wdir.mkdir(exist_ok=True)
    torch.set_num_threads(2)
    results=[]
    for group in ('main','mesh'):
        picked=[row for row in earlier['standing']['records']if row['id'].startswith(group+'-')]
        source=picked[0]['raw']
        mosaic,meta=read_raw(checked(source))
        h,w=mosaic.shape
        scene=np.stack([mosaic[y:h//2*2:2,x:w//2*2:2]for y in range(2)for x in range(2)])
        del mosaic
        cfa=np.asarray(color_indices(meta.pattern))
        for row in picked:
            assert row['raw']==source
            box=row['native_sensor_box']
            x,y,w,h=box
            with np.load(checked(row['input']),allow_pickle=False)as f:
                raw={k:f[k][0]for k in ('packed','colors','wb','matrix')}
            assert np.array_equal(raw['colors'],cfa)
            assert np.array_equal(raw['packed'],scene[:,y//2:(y+h)//2,x//2:(x+w)//2])
            p,q=(np.load(checked(row['parent_images'][key]),allow_pickle=False)[0] for key in ('parent100k','spatial'))
            roi=row['roi']
            a=apply(p,q,raw,row['conditioning'],roi,scene,box,fit)
            wb,matrix=(torch.from_numpy(raw[k][None])for k in ('wb','matrix'))
            display_exposure=row['display_exposure']
            def display(v):
                rgb=display_crop(torch.from_numpy(v[None]),wb,matrix,roi,exposure=display_exposure)
                return np.rint(rgb.clip(0,1)*255).astype(np.uint8)
            previous=old_pixels(row['board'])
            assert np.array_equal(display(p),previous['Parent 100k EMA'])
            assert np.array_equal(display(q),previous['Spatial 40k EMA'])
            assert np.array_equal(display(a['previous']),previous['Registered detail gate'])
            selectors=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Spatial 40k EMA')
            ordered=[(k,previous[k])for k in selectors if k in previous]
            ordered += [(LABELS[k],display(a[k]))for k in ('previous','signed_guard','limited_no_refit','limited_guard')]
            ordered += [(k,previous[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in previous]
            x,y,w,h=roi
            cut=np.s_[:,y:y+h,x:x+w]
            def rms(left,right):
                return float(np.sqrt(np.mean((left[cut].astype(float)-right[cut])**2))*65535)
            measurements={k:{'vs_parent':rms(v,p),'vs_previous':rms(v,a['previous'])}for k,v in a.items()}
            result=native_png(wdir/f"{row['id']}.png",ordered)
            results.append({'id':row['id'],'input':row['input'],'reference':row['board'],
                'raw':source,'roi':roi,'native_sensor_box':box,'noise':row['conditioning'],
                'display_exposure':display_exposure,'model_arrays':row['parent_images'],
                'output':result,'camera_RGB_RMS_DN16':measurements})
            print(row['id'],measurements['limited_guard'],flush=True)
        del scene
    assert len(results)==8
    return dict(earlier=provenance,rows=results)


def main():
    source=reference(ROOT/'upper.json')
    fit=read_json(checked(source))
    rows=exact(fit)
    photos=standing(fit)
    write_json(ROOT/'native.json',dict(driver=reference(__file__),study=source,checkpoints=fit['checkpoints'],
              exact=rows,standing=photos))


if __name__=='__main__':
    main()
