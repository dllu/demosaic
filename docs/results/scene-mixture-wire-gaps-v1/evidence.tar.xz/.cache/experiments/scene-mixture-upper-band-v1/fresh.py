"""Evaluate the frozen response and upper-band calibration on a separate 32-photo cohort."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

from upper import ROOT,L,BANDS,TERMS,preparation,score,checked,read_json,reference,write_json
from demosaic.experiments.artifacts import verify_plan
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_context import scene_preview
from demosaic.scene_inference import load_scene_checkpoint
from probe_scene_context_extent import encode

SOURCE = ROOT.with_name('paired-repeat-stability-v2')/'evaluation-plan.json'
TRAIN_PLAN = ROOT.with_name('scene-full-epoch-v1')/'plan.json'
PANEL_HELPERS = ROOT.with_name('scene-local-contrast-2400-v1')
sys.path.insert(0,str(PANEL_HELPERS))
import prepare_eval

ARGS=('packed','variance','colors','wb','matrix')
ARM_NAMES=('parent','previous','spatial_40k','limited_registered','limited_guard')
SEED=202611190934


def aggregate(records):
    out={}
    rng=np.random.default_rng(48191963)
    for profile,draw,partition in sorted({(r['profile'],r['draw'],r['sample'])for r in records}):
        selected=[r for r in records if (r['profile'],r['draw'],r['sample'])==(profile,draw,partition)]
        n=len(selected)
        batches=np.vstack((np.arange(n),rng.integers(n,size=(7000,n))))
        result={}
        for band in BANDS:
            means={}
            for name in selected[0]['scores']:
                values=[r['scores'][name][band] for r in selected]
                projection=np.asarray([v['signed_projection']for v in values])
                truth=np.asarray([v['truth']for v in values])
                means[name]={'response_pp':100*projection[batches].sum(1)/truth[batches].sum(1)}
                for term in TERMS:
                    means[name][term+'_RMS_DN16']=np.sqrt(np.asarray([v[term]for v in values])[batches].mean(1))
            deltas={}
            comparisons=[(a,'parent')for a in means if a!='parent']
            comparisons += [(a,'previous')for a in means if a not in ('parent','previous','spatial_40k')]
            comparisons += [('limited_guard','limited_registered'),('limited_registered','limited_local')]
            for a,b in comparisons:
                if a not in means or b not in means:
                    continue
                delta={k:v-means[b][k]for k,v in means[a].items()}
                deltas[a+' vs '+b]={k:dict(point=float(v[0]),interval=np.quantile(v[1:],(.025,.975)).tolist())
                                     for k,v in delta.items()}
            result[band]=dict(mean={name:{k:float(v[0])for k,v in quantities.items()}
                                    for name,quantities in means.items()},delta=deltas)
        out['/'.join((profile,draw,partition))]=result
    return out



def config():
    experiment = reference(ROOT/'upper.json')
    results = read_json(checked(experiment))
    cohort_ref=reference(SOURCE)
    old=read_json(checked(cohort_ref))
    cohort=[r for r in old['rows'] if r['cohort']=='fresh32']
    ids={r['source']['id']for r in cohort}
    assert len(cohort)==len(ids)==32 and ids.isdisjoint(results['split']['calibration']+results['split']['test'])
    routine=read_json(TRAIN_PLAN)
    manifest=checked(routine['train_manifest'])
    with manifest.open() as f:
        overlap=ids.intersection(json.loads(line)['id']for line in f)
    assert not overlap,overlap
    checked(results['checkpoints']['100k'])
    checked(results['checkpoints']['spatial'])
    return results,cohort,old['profiles'],old['coupling'],dict(fit=experiment,source_plan=cohort_ref,
           continuation_manifest=routine['train_manifest'],new_noise_seed=SEED,overlap_with_fit_or_continuation=0)


def numpy_input(row,photo,profile,draw):
    present=prepare_eval.patch(photo,row['box'],.22)
    masked=prepare_eval.patch(photo,row['box'],0.)
    roles={'present':present,'masked-fine':masked,'flat':prepare_eval.flat_patch(masked)}
    # Reuse the monitor's paired and exact-flat recipe. Bind a new master seed
    # for every role, including the measured scene outside the query.
    true_seed=prepare_eval.SEED
    prepare_eval.SEED=SEED
    try:
        return prepare_eval.observed_group(photo,roles,row,profile,draw)
    finally:
        prepare_eval.SEED=true_seed


def networks(models):
    parent,state = load_checkpoint(checked(models['100k']),'cuda',tiled_inference=True)
    assert state['step']==100000 and 'ema' in state and state['loaded_sha256']==models['100k']['sha256']
    del state
    spec=models['spatial']
    spatial,state=load_scene_checkpoint(checked(spec),device='cuda',weights='ema',expected_sha256=spec['sha256'])
    assert state['step']==40000 and state['mode']=='spatial' and state['loaded_sha256']==spec['sha256']
    del state
    return [net.eval().to(memory_format=torch.channels_last)for net in (parent,spatial)]


@torch.inference_mode()
def predictions(models,args,settings):
    p,q=models
    H = settings['profile']
    p.set_noise(H['shot'],H['read'])
    q.base.set_noise(H['shot'],H['read'])
    raw={k:torch.from_numpy(args[k]).cuda()for k in (*ARGS,'scene_packed')}
    x,y,w,h=(v//2 for v in settings['box'])
    encs=[]
    traces=[]
    calibration=[raw[k]for k in ('colors','wb','matrix')]
    with ieee_fp32():
        for a in raw['packed']:
            field=raw['scene_packed'].clone()
            field[:,y:y+h,x:x+w].copy_(a)
            assert torch.equal(field[:,y:y+h,x:x+w],a)
            assert torch.equal(field[:,:y],raw['scene_packed'][:,:y])
            assert torch.equal(field[:,y+h:],raw['scene_packed'][:,y+h:])
            assert torch.equal(field[:,y:y+h,:x],raw['scene_packed'][:,y:y+h,:x])
            assert torch.equal(field[:,y:y+h,x+w:],raw['scene_packed'][:,y:y+h,x+w:])
            preview,grid=scene_preview(field,*calibration,long_side=1024,exposure=1.0)
            encs.append(encode(q,preview,grid))
            traces.append(fingerprint(preview.cpu()))
        query=[raw[k].contiguous(memory_format=torch.channels_last) for k in ARGS[:2]]
        query.extend(raw[k][None].expand(3,*raw[k].shape)for k in ARGS[2:])
        y0=p(*query).float().cpu().numpy()
        y1=q(*query,scene=encs,boxes_xywh=[settings['box']]*3).float().cpu().numpy()
    assert y0.shape==y1.shape==(3,3,256,256) and np.isfinite(y0).all() and np.isfinite(y1).all()
    return {'100k':y0,'spatial--matching':y1},traces


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    fit,cohort,profiles,couplings,protocol=config()
    models=networks(fit['checkpoints'])
    previous=np.asarray(fit['previous_parameters'])
    parent=np.zeros(3*L)
    spatial=parent.copy()
    spatial[[1,L+1]]=1.
    selected={n:('limited',np.asarray(fit['fits'][n]['coefficients']))for n in ARM_NAMES if n.startswith('limited')}
    selected.update(parent=('wide',parent),spatial_40k=('wide',spatial),previous=('wide',previous))
    rows=[]
    start=time.monotonic()
    elapsed=0.
    for row in cohort:
        photo=prepare_eval.load_photo(row)
        source=row['source']['id']
        for profile in reversed(profiles):
            for draw in couplings:
                args=numpy_input(row,photo,profile,draw)
                settings={'box':row['box'],'profile':profile}
                t0=time.monotonic()
                predicted,trace=predictions(models,args,settings)
                elapsed += time.monotonic()-t0
                base=dict(operators=preparation(settings,args,predicted))
                values={n:score(base,w,mode)for n,(mode,w) in selected.items()}
                rows.append(dict(source=source,index=row['index'],profile=profile['name'],draw=draw,sample='confirmation',
                       raw={k:fingerprint(v)for k,v in args.items()},preview_fingerprints=trace,
                       predictions={k:fingerprint(v)for k,v in predicted.items()},scores=values))
        if len(rows)%8==0:
            print(len(rows),round(time.monotonic()-start,2),round(elapsed,2),flush=True)
    assert len(rows)==128
    total_time=time.monotonic()-start
    out=aggregate(rows)
    write_json(ROOT/'fresh.json',dict(driver=reference(__file__),checkpoints=fit['checkpoints'],
        protocol=protocol,rows=rows,scopes=out,inference_seconds=elapsed,wall_seconds=total_time,
        precision='CUDA IEEE FP32 EMA, full matched exterior with each query inserted'))
    print('finished',total_time,flush=True)


if __name__=='__main__':
    main()
