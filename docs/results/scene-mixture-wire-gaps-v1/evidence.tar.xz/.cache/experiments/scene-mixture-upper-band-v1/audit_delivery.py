"""Verify a single-filter implementation and inspect delivered chroma and color."""
import time

import numpy as np

from upper import (ROOT,PREVIOUS,SCORE,ROI,AMPLITUDE,cap_band,checked,gate_maps,load,luma,metadata,
                   read_json,reference,shape_delta,taper,tile_dct,transfer,write_json)
from native import apply
from color_audit import metric


def compose_guarded(parent,spatial,raw,noise,roi,scene,box,model):
    wb,matrix=raw['wb'],raw['matrix']
    delta,coarse,detail=shape_delta(parent,spatial,roi)
    gates=gate_maps(raw['packed'],raw['colors'],noise,roi,delta,scene=scene,box=box)
    c,d,a=np.split(np.asarray(model['coefficients']),3)
    gains=np.einsum('ij,jhw->ihw',np.stack((c,d,a)),gates)
    boost=cap_band(-AMPLITUDE*gains[2]*luma(detail,wb,matrix)/taper())*taper()
    neutral=np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    update=gains[0]*coarse+gains[1]*detail+neutral[:,None,None]*boost
    x,y,w,h=roi
    out=parent.copy()
    out[:,y:y+h,x:x+w]+=update.astype(np.float32)
    return out


def verify_filters():
    x=np.arange(160,dtype=float)
    lo=np.broadcast_to(np.cos(2*np.pi*(3/16)*x)[None],(160,160))
    hi=np.broadcast_to(np.cos(2*np.pi*(7/16)*x)[None],(160,160))
    target=np.s_[48:112,48:112]
    result=[float(np.linalg.norm(cap_band(a)[target])/np.linalg.norm(a[target])) for a in (lo,hi)]
    assert transfer(208,208)[0,39]==1 and transfer(208,208)[0,91]==0
    assert abs(result[0]-1)<.01 and result[1]<.01
    assert np.array_equal(cap_band(np.ones_like(lo)),np.ones_like(lo))
    return {'native_sinusoid_cycles_per_pixel':[3/16,7/16],'central_amplitude_ratios':result,
        'unit_DC_exact':True,'FFT_bin_passed_39':True,'FFT_bin_stopped_91':True}


def main():
    protocol=reference(ROOT/'upper.json')
    limited=read_json(checked(protocol))
    _,review,_,_=metadata()
    held=set(limited['split']['test'])
    by_key={r['prediction_receipt']['sha256']:r for r in limited['rows']}
    previous=reference(PREVIOUS/'color-audit.json')
    old=read_json(checked(previous))
    assertions=verify_filters()
    wall=time.monotonic()
    receipts=[]
    maximum_error=0.
    maximum_single_filter_diff=0.
    single_seconds=0.
    for i,row in enumerate(review['source_metrics']):
        if row['source'] not in held:
            continue
        case,data,pred=load(row)
        stored=by_key[row['prediction_receipt']['sha256']]['scores']['limited_guard']['fine']
        output=[]
        for j in range(3):
            camera={k:data[k]for k in ('colors','wb','matrix')}|{'packed':data['packed'][j]}
            args=(pred['100k'][j],pred['spatial--matching'][j],camera,case['profile'],ROI,
                  data['scene_packed'],case['box'])
            t0=time.perf_counter()
            delivered=compose_guarded(*args,limited['fits']['limited_guard'])
            single_seconds+=time.perf_counter()-t0
            if i%11==0:
                compiled=apply(*args,limited)['limited_guard']
                error=float(np.max(np.abs(compiled-delivered)))
                maximum_single_filter_diff=max(maximum_single_filter_diff,error)
                assert error<5e-8
            output.append(delivered)
        x,y,w,h=SCORE
        desired=tile_dct(luma(data['target'][...,y:y+h,x:x+w],data['wb'],data['matrix']))
        supervision={k:np.broadcast_to(data[k][None],(3,*data[k].shape))for k in ('wb','matrix')}
        results={'parent':metric(pred['100k'],data['target'],supervision,desired,case['profile']),
                 'limited_guard':metric(np.stack(output),data['target'],supervision,desired,case['profile'])}
        error=abs(results['limited_guard']['increment_RMS_DN16']-float(np.sqrt(stored['increment'])))
        maximum_error=max(maximum_error,error)
        assert error<.002
        original=next(r for r in old['per_case']if r['prediction_receipt']==row['prediction_receipt'])
        results['previous']=original['scores']['registered']
        assert len(results['previous'])==len(results['limited_guard'])
        receipts.append({k:row[k]for k in ('source','profile','draw','prediction_receipt')}|{'scores':results})
        if len(receipts)%32==0:
            print(len(receipts),round(time.monotonic()-wall,1),flush=True)
    assert len(receipts)==192
    scopes={}
    rng=np.random.default_rng(657243)
    for iso,draw in sorted({(r['profile'],r['draw'])for r in receipts}):
        a=[r['scores']for r in receipts if (r['profile'],r['draw'])==(iso,draw)]
        ids=np.vstack((np.arange(48),rng.integers(48,size=(6000,48))))
        changes={}
        for metric_name in a[0]['limited_guard']:
            val={}
            for arm in a[0]:
                values=np.array([r[arm][metric_name]for r in a])[ids]
                val[arm]=np.sqrt(np.square(values).mean(1)) if metric_name.endswith('_RMS_DN16') else values.mean(1)
            delta=val['limited_guard']-val['parent']
            changes[metric_name]={'mean':{arm:float(v[0])for arm,v in val.items()},
                'delta':{'point':float(delta[0]),'interval':np.quantile(delta[1:],(.025,.975)).tolist()}}
        scopes[iso+'/'+draw]=changes
    write_json(ROOT/'delivery.json',dict(driver=reference(__file__),source=protocol,previous_color=previous,
        projected_vs_delivered_max_DN16=maximum_error,single_filter_max_camera_unit_change=maximum_single_filter_diff,
        single_filter_seconds=single_seconds,filter_checks=assertions,rows=receipts,scopes=scopes,
        scope='CPU synthesis and metrics only; archived frozen network outputs are reused.'))
    print(maximum_error,maximum_single_filter_diff,single_seconds,flush=True)


if __name__=='__main__':
    main()
