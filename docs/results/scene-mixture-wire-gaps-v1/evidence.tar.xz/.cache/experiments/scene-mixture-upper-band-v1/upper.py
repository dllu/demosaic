"""Refit the regional mixture with a band-limited signed correction."""
from functools import lru_cache
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import irfft2, rfft2
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name('scene-gated-mixture-v1')
sys.path.insert(0,str(PREVIOUS))
from mixture import (BANDS, FAMILIES, GATES, NATIVE, ROI, SCORE, TERMS, checked, gate_maps, load,
                     luma, measure, metadata, quadratic, read_json, reference, shape_delta,
                     tile_dct, write_json)

L = len(GATES)
AMPLITUDE = .5
GUARD_TERMS = ('quiet','increment')
TRANSITION = (.24,.32)
MARGIN = 24
ARMS = {
    'signed_replay':('wide',False,'registered'),
    'signed_guard':('wide',True,'registered'),
    'limited_local':('limited',False,'local'),
    'limited_registered':('limited',False,'registered'),
    'limited_guard':('limited',True,'registered'),
}
SCALES = {'fine':1.,'lower':.3,'upper':.2}
WEIGHT = {'increment':1.,'present':.5,'attenuated':.5,'quiet':8.}


@lru_cache(maxsize=1)
def taper():
    axis = np.minimum(1., np.minimum(np.arange(NATIVE)+.5,np.arange(NATIVE)[::-1]+.5)/12.)
    return axis[:,None]*axis[None,:]


@lru_cache(maxsize=4)
def transfer(h,w):
    frequencies = np.hypot(np.fft.fftfreq(h)[:,None],np.fft.rfftfreq(w)[None,:])
    low,high = TRANSITION
    phase = np.clip((frequencies-low)/(high-low),0,1)
    return .5+.5*np.cos(np.pi*phase)


def cap_band(planes):
    border = ((0,0),)*(planes.ndim-2)+((MARGIN,MARGIN),(MARGIN,MARGIN))
    window = np.pad(planes,border,mode='reflect')
    hw = window.shape[-2:]
    values = irfft2(rfft2(window,workers=1)*transfer(*hw),s=hw,workers=1)
    return values[...,MARGIN:-MARGIN,MARGIN:-MARGIN]


def maps(p,q,raw,noise,roi,scene,box):
    wb,matrix=raw['wb'],raw['matrix']
    diff,low,high=shape_delta(p,q,roi)
    g=gate_maps(raw['packed'],raw['colors'],noise,roi,diff,scene=scene,box=box)
    # Preserve the previously reviewed coarse and positive detail basis.
    base_low=g*luma(low,wb,matrix)
    base_high=g*luma(high,wb,matrix)
    wide=-AMPLITUDE*base_high
    # Restrict the neutral correction after multiplying by the gate.
    # The same edge taper is applied one time, after this spectral restriction.
    signed = -AMPLITUDE*g*luma(high,wb,matrix)/taper()
    restricted=cap_band(signed)*taper()
    return low,high,g,(base_low,base_high,wide,restricted)


def preparation(case,data,predicted):
    x,y,w,h=SCORE
    response=lambda v:tile_dct(luma(v[...,y:y+h,x:x+w],data['wb'],data['matrix']))
    p=predicted['100k']
    q=predicted['spatial--matching']
    material=[]
    for i in range(3):
        raw={k:data[k]for k in ('wb','matrix','colors')}|{'packed':data['packed'][i]}
        _,_,_,parts=maps(p[i],q[i],raw,case['profile'],ROI,data['scene_packed'],case['box'])
        material.append(parts)
    # Stack native synthesized basis in exactly the delivered order.
    offset=SCORE[0]-ROI[0]
    basis = np.array(material).transpose(1,2,0,3,4)[...,offset:offset+96,offset:offset+96]
    dct=tile_dct(basis)
    base,target=response(p),response(data['target'])
    return {name:quadratic(base,target,np.concatenate((dct[0],dct[1],dct[i])))
            for i,name in ((2,'wide'),(3,'limited'))}


def indices(family):
    used=[GATES.index(k)for k in FAMILIES[family]]
    return np.array([i+o for o in (0,L,2*L)for i in used])


def sum_risk(rows,variant,ix,band,term):
    total=np.sum([r['operators'][variant][band][term][2][np.ix_(ix,ix)] for r in rows],axis=0)
    linear=np.sum([r['operators'][variant][band][term][1][ix] for r in rows],axis=0)
    return total,linear


def response(rows,variant,ix):
    feat=np.sum([row['operators'][variant]['fine']['response'][1][ix] for row in rows],axis=0)
    truth=sum(row['operators'][variant]['fine']['truth'] for row in rows)
    return feat/truth


def solve(calibration,variant,guard,family):
    start=time.perf_counter()
    ix=indices(family)
    n=len(ix)//3
    H=np.zeros((len(ix),len(ix)))
    linear=np.zeros(len(ix))
    for band,s in SCALES.items():
        for term,w in WEIGHT.items():
            h,l=sum_risk(calibration,variant,ix,band,term)
            H+=s*w*h
            linear+=s*w*l
    norm=max(1.,np.trace(H)/len(H))
    H/=norm
    linear/=norm
    sums=np.zeros((2,len(ix)))
    sums[0,:n]=1
    sums[1,n:]=1
    start_at=np.zeros(len(ix))
    start_at[[0,n]]=1
    constraints=[{'type':'eq','fun':lambda w:sums@w-1.,'jac':lambda w:sums}]
    check_response={}
    check_guards={}
    for profile,draw in sorted({(r['profile'],r['draw']) for r in calibration}):
        chosen=[r for r in calibration if (r['profile'],r['draw'])==(profile,draw)]
        assert len(chosen)==16
        group=profile+'/'+draw
        aligned=response(chosen,variant,ix)
        constraints.append({'type':'ineq','fun':lambda w,a=aligned:float(a@w),'jac':lambda w,a=aligned:a})
        check_response[group]=aligned
        for term in GUARD_TERMS:
            h,l=sum_risk(chosen,variant,ix,'upper',term)
            check_guards[group+'/'+term]=(h,l)
            if guard:
                scale=max(1.,np.trace(h)/len(h),np.linalg.norm(l))
                ht,lt=h/scale,l/scale
                constraints.append({'type':'ineq',
                   'fun':lambda w,A=ht,b=lt:-float(w@A@w+2*b@w),
                   'jac':lambda w,A=ht,b=lt:-2*(A@w+b)})
    reg=.0001
    optim=minimize(lambda w:float(w@H@w+2*linear@w+reg*(w@w)),start_at,
                   jac=lambda w:2*(H@w+linear+reg*w),method='SLSQP',constraints=constraints,
                   bounds=[(0.,1.)]*len(start_at),options={'ftol':1e-11,'maxiter':350})
    assert optim.success,(variant,guard,family,optim.status,optim.message)
    assert np.max(abs(sums@optim.x-1))<1e-7
    response_checks={k:float(100*(v@optim.x))for k,v in check_response.items()}
    guard_checks={k:float((optim.x@h@optim.x+2*l@optim.x)/16)for k,(h,l)in check_guards.items()}
    assert min(response_checks.values()) >= -1e-7
    if guard:
        assert max(guard_checks.values()) < 1e-5,(variant,guard_checks)
    full=np.zeros(3*L)
    full[ix]=optim.x
    return dict(operator=variant,upper_guard=guard,family=family,coefficients=full.tolist(),
                iterations=optim.nit,opt_seconds=time.perf_counter()-start,
                response_change_pp=response_checks,upper_mean_squared_error_changes=guard_checks)


def score(row,w,variant):
    values={}
    for band,q in row['operators'][variant].items():
        base,gain=q['response']
        result=dict(signed_projection=float(base+w@gain),truth=float(q['truth']))
        for name in TERMS:
            b,l,H=q[name]
            result[name]=float(max(0.,b+2*l@w+w@H@w))
        values[band]=result
    return values


def aggregate(records):
    out={}
    rng=np.random.default_rng(48191963)
    for profile,draw,partition in sorted({(r['profile'],r['draw'],r['sample'])for r in records}):
        selected=[r for r in records if (r['profile'],r['draw'],r['sample'])==(profile,draw,partition)]
        n=len(selected)
        batches=np.vstack((np.arange(n),rng.integers(n,size=(7000,n))))
        result={}
        for band in BANDS:
            means={}
            for name in selected[0]['scores']:
                values=[r['scores'][name][band] for r in selected]
                projection=np.asarray([v['signed_projection']for v in values])
                truth=np.asarray([v['truth']for v in values])
                means[name]={'response_pp':100*projection[batches].sum(1)/truth[batches].sum(1)}
                for term in TERMS:
                    means[name][term+'_RMS_DN16']=np.sqrt(np.asarray([v[term]for v in values])[batches].mean(1))
            deltas={}
            comparisons=[(a,'parent')for a in means if a!='parent']
            comparisons += [(a,'previous')for a in means if a not in ('parent','previous','spatial_40k')]
            comparisons += [('limited_guard','limited_registered'),('limited_registered','limited_local')]
            for a,b in comparisons:
                delta={k:v-means[b][k]for k,v in means[a].items()}
                deltas[a+' vs '+b]={k:dict(point=float(v[0]),interval=np.quantile(v[1:],(.025,.975)).tolist())
                                     for k,v in delta.items()}
            result[band]=dict(mean={name:{k:float(v[0])for k,v in quantities.items()}
                                    for name,quantities in means.items()},delta=deltas)
        out['/'.join((profile,draw,partition))]=result
    return out


def main():
    start=time.monotonic()
    prior_ref=reference(PREVIOUS/'signed.json')
    prior=read_json(checked(prior_ref))
    panel,review,plan,settings=metadata()
    assert prior['panel']==panel and prior['models']==plan['models']
    by_receipt={row['prediction_receipt']['sha256']:row for row in prior['rows']}
    seen=[]
    for item in review['source_metrics']:
        case,data,rgb=load(item)
        old=by_receipt[item['prediction_receipt']['sha256']]
        row={k:old[k]for k in ('source','case','profile','draw','prediction_receipt','input','sample')}
        row['operators']=preparation(case,data,rgb)
        same=score(row,np.zeros(3*L),'wide')
        for band in BANDS:
            for term in (*TERMS,'truth','signed_projection'):
                assert np.isclose(same[band][term],old['scores']['parent'][band][term],rtol=1e-10,atol=1e-9)
        seen.append(row)
        if len(seen)%32==0:
            print('native basis',len(seen),round(time.monotonic()-start,2),flush=True)
    assert len(seen)==256
    sample=[row for row in seen if row['sample']=='calibration']
    assert len(sample)==64 and len({r['source']for r in sample})==16
    fits={n:solve(sample,*recipe)for n,recipe in ARMS.items()}
    old=prior['fits']['registered/preserve_response']
    old_coeffs=np.r_[old['positive'],np.asarray(old['neutral_boost'])/AMPLITUDE]
    assert np.max(abs(np.asarray(fits['signed_replay']['coefficients'])-old_coeffs))<2e-4
    adopted={k:(recipe['operator'],np.asarray(recipe['coefficients']))for k,recipe in fits.items()}
    adopted['limited_no_refit']=('limited',old_coeffs)
    records=[]
    for row in seen:
        old=by_receipt[row['prediction_receipt']['sha256']]
        results={'parent':old['scores']['parent'],'previous':old['scores']['registered/preserve_response'],
                 'spatial_40k':old['scores']['spatial']}
        results.update({k:score(row,w,op)for k,(op,w)in adopted.items()})
        records.append({k:v for k,v in row.items()if k!='operators'}|{'scores':results})
    scope=aggregate(records)
    chosen=[v for v in records if (v['profile'],v['draw'],v['sample'])==('iso6400','independent','test')]
    arm='limited_guard'
    fn=lambda row:np.sqrt(row['scores'][arm]['fine']['increment'])-np.sqrt(row['scores']['parent']['fine']['increment'])
    examples=[{k:r[k]for k in ('case','source','profile','draw')}|{'delta_DN16':float(fn(r))}
              for r in (min(chosen,key=fn),max(chosen,key=fn))]
    write_json(ROOT/'upper.json',dict(driver=reference(__file__),previous=prior_ref,panel=panel,
          checkpoints=prior['models'],split=prior['partitions'],transition=list(TRANSITION),reflection_margin=MARGIN,
          fits=fits,previous_parameters=old_coeffs.tolist(),scopes=scope,rows=records,examples=examples,
          fit_seconds=sum(recipe['opt_seconds']for recipe in fits.values()),seconds=time.monotonic()-start))
    print('finished',round(time.monotonic()-start,2),flush=True)


if __name__=='__main__':
    main()
