"""Fit bounded, scene-dependent mixtures of two frozen restoration paths."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
from scipy.ndimage import gaussian_filter, map_coordinates
from scipy.optimize import minimize

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
TRIAL=ROOT.with_name('scene-full-epoch-v1')
REVIEW=TRIAL/'review-full-040000/evaluation/results.json'
sys.path.extend((str(Path('scripts').resolve()), str(ROOT.with_name('scene-raw-covariance-v1'))))
from evaluate import measure, split

ROI=(48,48,160,160)
SCORE=(80,80,96,96)
NATIVE=160
GATES=('zero','one','local_edge','weak_edge','local_texture','quiet_texture',
       'disagreement','agreement','scene_texture','scene_smooth','local_and_scene','local_without_scene')
FAMILIES={'static':GATES[:2],'local':GATES[:8],'registered':GATES,'shuffled':GATES}
BANDS=('lower','fine','upper')
TERMS=('increment','present','attenuated','quiet')
POLICIES=('risk','preserve_response')


def metadata():
    src=reference(REVIEW)
    reviewed=read_json(checked(src))
    plan=read_json(checked(reviewed['plan']))
    settings=read_json(checked(plan['panel']))
    assert tuple(settings['score_ROI_xywh']) == SCORE
    return src,reviewed,plan,settings


def load(item):
    record=read_json(checked(item['prediction_receipt']))
    case=read_json(checked(record['case']))
    with np.load(checked(case['input']),allow_pickle=False) as file:
        data={k:file[k] for k in ('packed','variance','colors','wb','matrix','target','scene_packed')}
    assert all(fingerprint(a)==case['fingerprints'][key] for key,a in data.items())
    with np.load(checked(record['saved']),allow_pickle=False) as file:
        rgb={k:file[k] for k in ('100k','none','spatial--matching')}
    return case,data,rgb


def patch_grid(a,y,x,block=16):
    values=np.lib.stride_tricks.sliding_window_view(a,(block,block))[y,x]
    return values.reshape(len(y),-1)


def cells(shape,step):
    y,x=np.meshgrid(np.arange(0,shape[0]-15,step),np.arange(0,shape[1]-15,step),indexing='ij')
    return y.ravel(),x.ravel()


def green_pair(packed,colors):
    return packed[np.asarray(colors)==1].mean(0)


def filters(green):
    def blur(s):
        return gaussian_filter(green,sigma=s,mode='reflect')
    low=blur(2.7)
    middle=blur(.85)-low
    edge=np.hypot(*np.gradient(low))
    return low,middle,edge


def descriptor(fields,y,x,noise):
    a,b,e=(patch_grid(f,y,x) for f in fields)
    tone=a.mean(1).clip(0,1)
    sigma=np.sqrt(np.maximum(1e-12,noise['shot']*tone+noise['read']))
    contrast=np.sqrt(np.mean(b*b,axis=1)) / (.23*sigma)
    gradient=np.sqrt(np.mean(e*e,axis=1)) / (.13*sigma)
    return tone, contrast, gradient


def scene_donors(scene, colors, excluded, noise, shuffle=False):
    x0,y0,w,h=excluded
    green=green_pair(scene,colors)
    y,x=cells(green.shape,16)
    selection=(x*2+32<=x0)|(x*2>=x0+w)|(y*2+32<=y0)|(y*2>=y0+h)
    # Keep the signal preprocessing disjoint as well. Gaussian filters can read
    # nearby samples up to their default four-sigma support.
    selection &= ((x*2+56<=x0)|(x*2-24>=x0+w)|(y*2+56<=y0)|(y*2-24>=y0+h))
    y,x=y[selection],x[selection]
    assert len(y)>=12
    tone,middle,gradient=descriptor(filters(green),y,x,noise)
    if shuffle:
        ordering=np.arange(len(y))[::-1]
        tone,middle,gradient=(v[ordering] for v in (tone,middle,gradient))
    return np.stack((x*2+16,y*2+16),axis=1),tone,middle,gradient


def exterior(data,case,positions,tone,shuffle):
    coords, means, texture, gradient = scene_donors(data['scene_packed'],data['colors'],case['box'],
                                                     case['profile'],shuffle)
    # Tone-conditioned nearest external windows, retaining a 24-pixel guard.
    d2=np.sum(np.square(positions[:,None]-coords[None,:]),axis=2)
    similarity=np.abs(np.log((tone[:,None]+.012)/(means[None,:]+.012)))
    ranking=d2/(192.**2) + 4*similarity**2
    j=np.argpartition(ranking,7,axis=1)[:,:8]
    tr=texture[j]
    signal=np.median(tr,axis=1)
    return signal/(signal+2)


def interpolated(values):
    step=np.clip((np.arange(NATIVE)-15.5)/16,0,8)
    y,x=np.meshgrid(step,step,indexing='ij')
    return map_coordinates(values.reshape(9,9),[y,x],order=1,mode='nearest',prefilter=False)


def gate_maps(packed,colors,noise,roi,delta,scene=None,box=None,shuffled=False):
    ox,oy,w,h=roi
    assert (w,h)==(NATIVE,NATIVE)
    x0,y0=ox%2,oy%2
    # Patch origins on the sensor lattice. Odd review crops shift the
    # group of packed samples by at most one native pixel.
    green=green_pair(packed,colors)
    y,x=np.meshgrid((oy-y0)//2+8*np.arange(9),(ox-x0)//2+8*np.arange(9),indexing='ij')
    y,x=y.ravel(),x.ravel()
    tone,texture,gradient=descriptor(filters(green),y,x,noise)
    local=texture/(texture+2.)
    edge=gradient/(gradient+2.)
    disagreement=np.sqrt(np.mean(delta**2,axis=0))
    dy,dx=(np.broadcast_to(k,(9,9)).ravel() for k in (np.arange(9)[:,None]*16,np.arange(9)[None,:]*16))
    diff=np.sqrt(np.mean(patch_grid(disagreement,dy,dx,32)**2,axis=1))
    sensor=np.sqrt(np.maximum(1e-12,noise['shot']*tone+noise['read']))
    diff=diff/(diff+(.12*sensor))
    stored=[np.zeros(len(x)),np.ones(len(x)),edge,1-edge,local,1-local,diff,1-diff]
    if scene is not None:
        case={'box':box,'profile':noise}
        coords=np.stack((x*2+box[0]+16,y*2+box[1]+16),axis=1)
        context=exterior({'scene_packed':scene,'colors':colors},case,coords,tone,shuffled)
        stored += [context,1-context,local*context,local*(1-context)]
    return np.stack([interpolated(v) for v in stored])


def shape_delta(a,b,roi):
    x,y,w,h=roi
    d=b-a
    smooth=gaussian_filter(d,sigma=(0,.92,.92),mode='reflect')
    view=np.s_[:,y:y+h,x:x+w]
    edge=np.minimum(1,np.minimum(np.arange(NATIVE)+.5,np.arange(NATIVE)[::-1]+.5)/12)
    taper=edge[:,None]*edge[None,:]
    return d[view],smooth[view]*taper,(d[view]-smooth[view])*taper


def design(data,case,rgb,roi=ROI,bed='spatial--matching'):
    parent=rgb['100k']
    quieter=rgb[bed]
    mats={'registered':[], 'shuffled':[]}
    for i in range(len(parent)):
        diff, low, high = shape_delta(parent[i],quieter[i],roi)
        for name in mats:
            g=gate_maps(data['packed'][i],data['colors'],case['profile'],roi,diff,
                        scene=data['scene_packed'],box=case['box'],shuffled=name=='shuffled')
            mats[name].append(np.stack([g[:,None]*low,g[:,None]*high]).reshape(2*len(GATES),3,NATIVE,NATIVE))
    return {key:np.stack(v,axis=1) for key,v in mats.items()}


def tile_dct(y):
    blocks=y.reshape(*y.shape[:-2],6,16,6,16).swapaxes(-2,-3)
    blocks=blocks.reshape(*y.shape[:-2],36,16,16)
    return measure.DCT@blocks@measure.DCT.T


def luma(image,wb,matrix):
    color=measure.LUMA@np.asarray(matrix)
    return np.einsum('...chw,c->...hw',image,np.asarray(color)*wb)


def inputs_for_quadratic(case,data,rgb,settings,bed='spatial--matching'):
    supervise={k:np.broadcast_to(data[k][None],(3,*data[k].shape))for k in ('wb','matrix')}
    supervise['exposure']=case['profile']['exposure']
    pred=rgb['100k']; truth=data['target']
    x,y,w,h=SCORE
    base=tile_dct(luma(pred[...,y:y+h,x:x+w],data['wb'],data['matrix']))
    desired=tile_dct(luma(truth[...,y:y+h,x:x+w],data['wb'],data['matrix']))
    offset=SCORE[0]-ROI[0]
    d=design(data,case,rgb,bed=bed)
    modes={n:tile_dct(luma(a[...,offset:offset+96,offset:offset+96],data['wb'],data['matrix']))for n,a in d.items()}
    return base,desired,modes


METRIC_SCALE=65535.**2/(36*16*16)


def quadratic(base,gt,design):
    compiled={}
    for label,mask in measure.BANDS.items():
        b=base[...,mask].reshape(3,-1)
        p=gt[...,mask].reshape(3,-1)
        z=design[...,mask].reshape(len(design),3,-1)
        error=b-p
        target=p[0]-p[1]; estimated=b[0]-b[1]
        compiled[label]={'response':(np.dot(estimated,target), (z[:,0]-z[:,1]) @ target),
                         'truth':np.dot(target,target)}
        for name, e, change in (('increment',error[0]-error[1],z[:,0]-z[:,1]),
                                ('present',error[0],z[:,0]),('attenuated',error[1],z[:,1]),
                                ('quiet',error[2],z[:,2])):
            compiled[label][name] = (float(np.dot(e,e)*METRIC_SCALE), (change@e)*METRIC_SCALE,
                                      (change@change.T)*METRIC_SCALE)
    return compiled


def index(family):
    use=[GATES.index(i) for i in FAMILIES[family]]
    return np.array([*use,*(i+len(GATES) for i in use)])


def compress(rows,key):
    return {b:{field:np.asarray([case[b][field][key] for case in rows]) for field in TERMS}
            for b in BANDS}


def accumulate(cal,family):
    picked=[r['terms']['shuffled' if family=='shuffled' else 'registered'] for r in cal]
    indices=index(family)
    H=np.zeros((len(indices),len(indices)))
    v=np.zeros(len(indices))
    # Measured objectives on the delivered output. Score increments separately
    # from absolute content and exact-flat errors.
    for band, weight_scale in (('fine',1),('lower',.3),('upper',.2)):
        for name,weight in (('increment',1.),('present',.5),('attenuated',.5),('quiet',8.)):
            z=weight*weight_scale
            for case in picked:
                _,s,q=case[band][name]
                H += z*q[np.ix_(indices,indices)]
                v += z*s[indices]
    retained = np.sum([r['fine']['response'][1][indices] for r in picked],axis=0)
    truth = sum(r['fine']['truth'] for r in picked)
    norm=max(np.trace(H)/len(H),1)
    return H/norm,v/norm,retained/max(truth,1e-20)


def fit(cal,family,mode):
    start=time.perf_counter()
    H,v,resp=accumulate(cal,family)
    d=len(H)//2
    constraints_matrix=np.zeros((2,2*d))
    constraints_matrix[0,:d]=1
    constraints_matrix[1,d:]=1
    init=np.zeros(2*d)
    init[[0,d]]=1
    constraints=[{'type':'eq','fun':lambda w:constraints_matrix @ w - 1,'jac':lambda w:constraints_matrix}]
    if mode=='preserve_response':
        constraints.append({'type':'ineq','fun':lambda w:float(resp@w),'jac':lambda w:resp})
    opt=minimize(lambda w:float(w@H@w + 2*v@w + .0001*(w@w)),init,
                 jac=lambda w:2*(H@w+v+.0001*w),method='SLSQP',
                 constraints=constraints,bounds=[(0.,1.) for _ in init],
                 options={'ftol':1e-11,'maxiter':250})
    assert opt.success,(family,mode,opt.message)
    assert np.max(abs(constraints_matrix @ opt.x-1)) < 1e-7
    assert mode!='preserve_response' or resp@opt.x >= -1e-9
    full=np.zeros(2*len(GATES))
    full[index(family)]=opt.x
    return {'weights':full.tolist(),'iterations':opt.nit,'seconds':time.perf_counter()-start,
            'fitted_relative_fine_response_pp':float(100*(resp@opt.x))}


def scalar(w):
    v=np.zeros(2*len(GATES))
    v[[0,len(GATES)]]=1-w
    v[[1,len(GATES)+1]]=w
    return v


def oracle_weight(row):
    common=scalar(1)
    residual=0.
    strength=0.
    for label,factor in (('fine',1.),('lower',.3),('upper',.2)):
        for term,weight in (('increment',1.),('present',.5),('attenuated',.5),('quiet',8.)):
            _,law,cov=row['terms']['registered'][label][term]
            residual += factor*weight*(law@common)
            strength += factor*weight*(common@cov@common)
    return float(np.clip(-residual/max(strength,1e-10),0,1))


def score_case(row, family, weights):
    matrix=row['terms']['shuffled' if family=='shuffled' else 'registered']
    values={}
    for band in BANDS:
        data=matrix[band]
        old, delta=data['response']
        v={'truth':float(data['truth']), 'signed_projection':float(old+delta@weights)}
        for name in TERMS:
            e,s,H=data[name]
            v[name]=float(max(0.,e+2*s@weights+weights@H@weights))
        values[band]=v
    return values


def summary(rows,weights,arm_groups):
    rng=np.random.default_rng(5019227)
    output={}
    for profile,draw,sample in sorted({(r['profile'],r['draw'],r['sample']) for r in rows}):
        picked=[r for r in rows if (r['profile'],r['draw'],r['sample'])==(profile,draw,sample)]
        count=len(picked)
        index_boot=np.vstack((np.arange(count),rng.integers(count,size=(6000,count))))
        d={}
        for band in BANDS:
            stat={}
            for arm in (*weights,'photo_oracle'):
                cell=[r['scores'][arm][band] for r in picked]
                aligned=np.asarray([z['signed_projection'] for z in cell])
                expect=np.asarray([z['truth'] for z in cell])
                populations={label+'_RMS_DN16':np.sqrt(np.asarray([z[label] for z in cell])[index_boot].mean(1)) for label in TERMS}
                populations['response_pp']=100*aligned[index_boot].sum(1)/expect[index_boot].sum(1)
                stat[arm]=populations
            column={'mean':{a:{metric:float(b[0])for metric,b in z.items()}for a,z in stat.items()},'paired':{}}
            pairs=[(arm,'parent') for arm in stat if arm!='parent'] + [
                   ('registered/risk','local/risk'),('registered/risk','shuffled/risk'),
                   ('registered/risk','static/risk'),('registered/preserve_response','static/preserve_response'),
                   ('registered/preserve_response','local/preserve_response')]
            for a,b in pairs:
                delta={m:stat[a][m]-stat[b][m] for m in stat[a]}
                column['paired'][a+' vs '+b]={m:{'point':float(z[0]),'interval':np.quantile(z[1:],(.025,.975)).tolist()} for m,z in delta.items()}
            d[band]=column
        output['/'.join((profile,draw,sample))]=d
    return output


def run():
    start=time.monotonic()
    panel,reviewed,plan,settings=metadata()
    ids=split(reviewed['source_metrics'])
    cal_ids=set(ids['calibration'])
    train,measured=[],[]
    for row in reviewed['source_metrics']:
        case,data,rgb=load(row)
        scope='calibration' if row['source'] in cal_ids else 'test'
        b,g,delta=inputs_for_quadratic(case,data,rgb,settings)
        q={f:quadratic(b,g,features) for f,features in delta.items()}
        proof={k:row[k] for k in ('profile','draw','source','prediction_receipt')}
        proof.update(case=case['case'],sample=scope,input=case['input'],terms=q)
        anchor=q['registered']['fine']
        target=row['metrics']['100k']['band']['fine']
        assert np.isclose(np.sqrt(anchor['increment'][0]),target['increment_RMS_DN16'],atol=1e-5,rtol=0)
        if scope=='calibration':
            train.append(proof)
        measured.append(proof)
        if len(measured)%16==0:
            print('feature quadratics',len(measured),round(time.monotonic()-start,2),flush=True)
    assert len(measured)==256 and len(train)==64
    fits={}
    weights={'parent':scalar(0),'spatial':scalar(1),'equal_mix':scalar(.5)}
    belonging={name:'registered' for name in weights}
    for mode in POLICIES:
        for family in FAMILIES:
            k=family+'/'+mode
            fits[k]=fit(train,family,mode)
            weights[k]=np.asarray(fits[k]['weights'])
            belonging[k]=family
    results=[]
    examples={}
    for row in measured:
        observed={k:score_case(row,belonging[k],w) for k,w in weights.items()}
        o=oracle_weight(row)
        observed['photo_oracle']=score_case(row,'registered',scalar(o))
        result={k:v for k,v in row.items()if k!='terms'}
        result.update(scores=observed,oracle_spatial_weight=o)
        results.append(result)
    cross=summary(results,weights,belonging)
    for name in ('registered/risk','registered/preserve_response'):
        qualifying=[r for r in results if (r['profile'],r['draw'],r['sample'])==('iso6400','independent','test')]
        sort=sorted(qualifying,key=lambda r:np.sqrt(r['scores'][name]['fine']['increment'])-
                                           np.sqrt(r['scores']['parent']['fine']['increment']))
        examples[name]=[{k:r[k]for k in ('source','case','profile','draw')} for r in (sort[0],sort[-1])]
    write_json(ROOT/'scores.json',{'driver':reference(__file__),'panel':panel,'models':plan['models'],
             'fit_time_seconds':sum(v['seconds']for v in fits.values()),'runtime_seconds':time.monotonic()-start,
             'fits':fits,'partitions':ids,'weights':{k:v.tolist() for k,v in weights.items()},
             'families':belonging,'summary':cross,'rows':results,'examples':examples})
    print('finished',round(time.monotonic()-start,2),flush=True)


if __name__=='__main__':
    run()
