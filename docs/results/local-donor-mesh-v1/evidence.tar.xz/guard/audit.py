"""Measure fixed Bayer prediction on an additional, unused quarter of query samples."""

import importlib.util
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from mesh import ribbon,projected_fit
from support import query_phases

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("guard_camera",ROOT/"standing.py")
standing=importlib.util.module_from_spec(spec)
spec.loader.exec_module(standing)


def heldout(raw,colors,prior,noise):
    phases,reserved,scores=query_phases(raw,colors,prior,noise,refine=True)
    h,w=raw.shape[-2:]
    x,y=native_sites((h,w),(-(2*w-1)/2,-(2*h-1)/2))
    slot=np.broadcast_to(np.indices((h,w))[1]%4,raw.shape)
    assert np.array_equal(slot[0]==0,reserved)
    cfa=np.broadcast_to(np.asarray(colors)[:,None,None],raw.shape)
    p,q=(ribbon(x,y,v) for v in phases)
    affine=np.stack((np.ones_like(x),x/128,y/128),axis=-1)
    errors={"front":0.,"rear":0.,"shifted_rear":0.}
    crosschecks=[]
    import dataclasses
    shifted=ribbon(x,y,dataclasses.replace(phases[1],offset=(phases[1].offset+.31)%1))
    for role,other,trial in (("front",q,p),("rear",p,q),("shifted_rear",p,shifted)):
        row={}
        for a in ((1,),(2,),(1,2)):
            result=0.
            for color in range(3):
                base=(cfa==color)
                tr=base&np.isin(slot,a)
                test=base&(slot==(3 if len(a)==2 else 3-a[0]))
                # Only the training quarter(s) determine noise scale,
                # nuisance coefficients and the proposed amplitude.
                med=max(1e-4,float(np.median(raw[tr])))
                variance=noise["shot"]*med+noise["read"]
                x1=np.concatenate((affine,other[...,None]),axis=-1)
                off,projection,gain,_,_=projected_fit(x1[tr],trial[tr,None],raw[tr],
                                                       np.full(np.count_nonzero(tr),1/variance))
                delta=(trial[test,None]-x1[test]@projection)@gain
                residual=raw[test]-x1[test]@off
                result+=float(np.sum(delta*(2*residual-delta))/variance)
            key="audit" if len(a)==2 else f"train_{a[0]}_check_{3-a[0]}"
            row[key]=result
        crosschecks.append({"component":role,**row})
    return {"reserved_phase_scores":scores,"fits":crosschecks,
            "untouched_audit_samples":int(np.count_nonzero(slot==3))}


def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    view=ROOT/"standing/result.json"
    checked_views=read_json(view)
    original=read_json(checked(checked_views["source_plan"]))
    data={v["id"]:v for v in original["observations"]}
    main_pair=next(v["evidence"]["80"]["prior_frequencies"] for v in checked_views["rows"]
                   if "chain-link" in v["id"])
    rows=[]
    for row in checked_views["rows"]:
        source=next(name for name in data if row["id"].startswith(name+"-"))
        obs=data[source]
        with np.load(checked(obs["arrays"]),allow_pickle=False) as values:
            packed=values["packed"][0]
            color=values["colors"][0]
        q=standing.legacy.window(packed,row["query"],phase=2)
        prior=row["evidence"]["112" if "mesh" in row["id"] else "80"].get("prior_frequencies")
        effects={}
        if prior:
            effects["selected"]=heldout(q,color,prior,obs["noise"])
        effects["forced_coarse"]=heldout(q,color,main_pair,obs["noise"])
        rows.append({"id":row["id"],"inputs":obs["arrays"],"query":row["query"],"prior":prior,**effects})
        print(row["id"],[(arm,[round(s["audit"],2) for s in v["fits"]]) for arm,v in effects.items()],flush=True)
    assert len(rows)==8
    write_json(ROOT/"extra-holdout.json",{
        "driver":reference(__file__),"camera":reference(view),"rows":rows,
        "scope":"Fit RAW nuisance and phase predictions on the non-audit halves with phase chosen on a separate reserve. Measure independent score on extra query samples unused in that fit. Models are affine + the other carrier with or without the test carrier. Train/check scores and an unrelated phase shift are retained. Sensor samples can be correlated on real cameras. No neural parent or ISO100/JPEG references enter the score.",
    })


if __name__=="__main__":
    main()
