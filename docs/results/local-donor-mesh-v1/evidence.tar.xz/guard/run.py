"""Measure whether the camera-motivated joint local gate controls missing-wire error."""

import importlib.util
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from guard import dual_support

ROOT=Path(__file__).resolve().parent
FIRST=ROOT.parent/"local-donor-mesh-v1"
OTHER=ROOT.parent/"local-donor-mesh-replay-v1"
spec=importlib.util.spec_from_file_location("target_metrics",ROOT.parent/"joint-mesh-phase-v1/run.py")
metrics_import=importlib.util.module_from_spec(spec)
spec.loader.exec_module(metrics_import)

def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(11)
    path=FIRST/"result.json"
    initial=read_json(path)
    plan=read_json(checked(initial["plan"]))
    replayed=read_json(OTHER/"result.json")
    by_id={Path(r["path"]).stem:read_json(checked(r)) for r in replayed["records"]}
    out=ROOT/"cases"
    out.mkdir()
    closed=[]
    for ref in initial["records"]:
        row=read_json(checked(ref))
        if row["retained"] is None:
            continue
        latest=by_id[row["id"]]
        with (np.load(checked(row["retained"]),allow_pickle=False) as data,
              np.load(checked(latest["retained"]),allow_pickle=False) as saved):
            arrays,previous=dict(data),dict(saved)
        assert row["fingerprints"]=={k:fingerprint(arrays[k]) for k in row["fingerprints"]}
        assert latest["fingerprints"]==row["fingerprints"]
        p=arrays["pred_parent"]
        np.testing.assert_array_equal(p,previous["pred_parent"])
        target=arrays["target"]
        masks={k:arrays[k] for k in ("strong_phase","weak_phase","support")}
        all_metrics={}
        witnesses={}
        predictions={}
        for context in ("matching","unrelated","quiet","center-given"):
            each=[]
            witness=[]
            for i in (0,1,2):
                y,r=dual_support(p[i],arrays["packed"][i],arrays["variance"][i],arrays["colors"][i],
                               row["frequency"][context],plan["noise"][row["profile"]])
                each.append(y)
                witness.append(r)
            batch=np.asarray(each)
            for i,title in enumerate(("rear","both","guarded")):
                method=context+"-"+title
                predictions[method]=batch[:,i]
                all_metrics[method]=metrics_import.metrics(batch[:,i],p,target,masks)
            witnesses[context]=witness
        retained=out/(row["id"]+".npz")
        np.savez_compressed(retained,**{f"pred_{k}":v for k,v in predictions.items()})
        dest=out/(row["id"]+".json")
        write_json(dest,{"id":row["id"],"profile":row["profile"],"layout":row["layout"],
              "source":ref,"source_arrays":row["retained"],"methods":all_metrics,
              "witnesses":witnesses,"predictions":reference(retained)})
        closed.append(reference(dest))
        print(row["id"],all_metrics["matching-rear"]["response"][0],
              all_metrics["matching-guarded"]["response"][0],flush=True)
    assert len(closed)==12
    write_json(ROOT/"result.json",{
      "scope":"Diagnostic replay of the 12 retained pairs. Both directions must improve held-out RAW error. The local guard carries their broad fitted amplitudes only where the same two proposed directions are supported on smaller query windows. The exact retained parents and noise tensors are reused.",
      "source":reference(path),"replay":reference(OTHER/"result.json"),
      "runner":reference(__file__),"guard":reference(ROOT/"guard.py"),"method":reference(ROOT/"mesh.py"),
      "closed":closed,
    })

if __name__=="__main__":
    main()
