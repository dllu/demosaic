"""Use the fixed additional RAW prediction check as an optional delivery gate."""

import importlib.util
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from audit import heldout
from guard import dual_support

ROOT=Path(__file__).resolve().parent
FIRST=ROOT.parent/"local-donor-mesh-v1"
REPLAY=ROOT.parent/"local-donor-mesh-replay-v1"

spec=importlib.util.spec_from_file_location("panel_metrics",ROOT.parent/"joint-mesh-phase-v1/run.py")
panel=importlib.util.module_from_spec(spec)
spec.loader.exec_module(panel)


def admit(record):
    if not record:
        return False
    f,r,w=record["fits"]
    assert [v["component"] for v in (f,r,w)]==["front","rear","shifted_rear"]
    positive=all(m[k]>0 for m in (f,r) for k in ("train_1_check_2","train_2_check_1","audit"))
    return bool(positive and r["audit"]>max(0.,w["audit"]))


def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(12)
    source=read_json(ROOT/"result.json")
    original=read_json(FIRST/"result.json")
    plan=read_json(checked(original["plan"]))
    extra=[]
    for bound in source["closed"]:
        r=read_json(checked(bound))
        old=read_json(checked(r["source"]))
        with (np.load(checked(r["source_arrays"]),allow_pickle=False) as raw,
              np.load(checked(r["predictions"]),allow_pickle=False) as saved):
            arrays,predictions=dict(raw),dict(saved)
        p=arrays["pred_parent"]
        masks={key:arrays[key] for key in ("strong_phase","weak_phase","support")}
        noise=plan["noise"][r["profile"]]
        decisions={}
        scores={}
        for context in ("matching","unrelated","quiet","center-given"):
            freq=old["frequency"][context]
            out=[]
            checks=[]
            for i in range(3):
                fit=heldout(arrays["packed"][i],arrays["colors"][i],freq,noise) if freq else None
                passed=admit(fit)
                out.append(predictions[f"pred_{context}-guarded"][i] if passed else p[i])
                checks.append({"pass":passed,"record":fit})
            pred=np.stack(out)
            predictions[f"pred_{context}-confirmed"]=pred
            scores[context]=panel.metrics(pred,p,arrays["target"],masks)
            decisions[context]=checks
        dest=ROOT/"cases"/(r["id"]+"-confirmed.npz")
        np.savez_compressed(dest,**{k:v for k,v in predictions.items() if k.endswith("-confirmed")})
        extra.append({"id":r["id"],"noise":r["profile"],"layout":r["layout"],
                      "source":bound,"predictions":reference(dest),"decisions":decisions,"scores":scores})
    assert len(extra)==12
    write_json(ROOT/"confirmed.json",{
       "source":reference(ROOT/"result.json"),"driver":reference(__file__),
       "audit_code":reference(ROOT/"audit.py"),"rows":extra,
       "scope":"Post-review empirical safety gate. Both cross-check training directions must improve unweighted-by-parent RAW prediction, then both must improve prediction on the additional raw verification quarter. The measured rear phase must beat a 0.31-cycle shift there. Same delivery image and weights if admitted.",
    })

if __name__=="__main__":
    main()
