"""Test localized donor inference against exact frequency and unrelated-context controls."""

import dataclasses
import importlib.util
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import mosaic,PATTERNS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise,variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from mesh import Carrier,ribbon
from standing import choose
from support import infer_prior,query_phases,contained_tiles

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"joint-mesh-phase-v1"
WIRE=ROOT.parent/"scene-wire-gap-v1"
spec=importlib.util.spec_from_file_location("mesh_synthetic_archive",PRIOR/"run.py")
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
BOX=(256,256,256,256)
LAYOUTS=("additive","occluded","broken")
GEOMETRIES=range(90,96)
PRIORS=prior.PRIORS


def simulate(g,layout,noise,seed):
    geometry=prior.guides(g)
    gt,masks=prior.clean(g,layout,geometry)
    a,b,flat=gt
    pattern=tuple(PATTERNS)[g%4]
    inputs,metadata=paired_observation(a[None],b[None],noise,[pattern],torch.ones(1,3),torch.eye(3)[None],seed)
    store={k:torch.from_numpy(inputs[k]) for k in ("packed","variance","target","colors","wb","matrix")}
    c=store["colors"][0]
    flat_raw=add_noise(mosaic(flat[None],c),noise["shot"],noise["read"],black_level=.03,
                       generator=torch.Generator().manual_seed(seed+2393))
    for k,extra in (("packed",flat_raw),("variance",variance_map(flat_raw,noise["shot"],noise["read"])),
                    ("target",flat[None]),("colors",store["colors"][:1]),
                    ("wb",store["wb"][:1]),("matrix",store["matrix"][:1])):
        store[k]=torch.cat((store[k],extra))
    x,y=coordinates(768,768,origin=(-383.5,-383.5))
    flat=np.array([.24,.29,.34])[:,None,None]+.026*x/768+.017*y/768
    edge=.5+.5*np.tanh((.58*x-y-90)/3)
    colour=np.array([.025,-.016,.035])[:,None,None]
    baseline=flat+.3*colour*edge
    # Three localized regions bracket the query along different axes. Their
    # positions, widths and support are fixed by the generation recipe.
    regions=np.zeros_like(x)
    offsets=np.array([[-200,0],[246,(g%3-1)*50],[(g%3-1)*82,226]])
    for k,(cx,cy) in enumerate(offsets):
        u=np.maximum(np.abs(x-cx),(np.abs(y-cy)+k*5))
        r=np.clip((103-u)/20,0,1)
        regions=np.maximum(regions,r*r*(3-2*r))
    theta=.35
    twist=np.array([[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]])
    unrelated=tuple(dataclasses.replace(carrier,frequency=tuple(twist@carrier.frequency))
                    for carrier in geometry)
    scenes={}
    for layout_name,carriers in (("matching",geometry),("unrelated",unrelated),("quiet",None)):
        outer=baseline.copy()
        if carriers:
            p,q=(ribbon(x,y,carrier) for carrier in carriers)
            outer=outer+regions*(.095*prior.STRONG*p+.063*prior.FAINT*q)
        sensor=mosaic(torch.from_numpy(outer.astype(np.float32))[None],c)
        scenes[layout_name]=add_noise(sensor,noise["shot"],noise["read"],black_level=.03,
            generator=torch.Generator().manual_seed(seed+794))[0].numpy()
    return store,masks,scenes,geometry,metadata


def independent_query_check(packed,colors,frequencies,noise):
    q,reserved,score=query_phases(packed,colors,frequencies,noise)
    altered=packed.copy()
    rng=np.random.default_rng(810294)
    altered[:,~reserved]+=rng.normal(0,.02,(4,(~reserved).sum())).astype(packed.dtype)
    t,other,s2=query_phases(altered,colors,frequencies,noise)
    assert q==t and score==s2 and np.array_equal(reserved,other)
    return {"reserved_packed_cells":int(reserved.sum()),"changed_other_native_sites":int(4*(~reserved).sum()),
            "identical_selected_carriers_and_scores":True}


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    binding=read_json(WIRE/"plan.json")["checkpoint"]
    plan={
        "driver":reference(__file__),"method":reference(ROOT/"mesh.py"),"standing":reference(ROOT/"standing.py"),
        "support":reference(ROOT/"support.py"),"target_generation":reference(PRIOR/"run.py"),
        "checkpoint":binding,"geometries":list(GEOMETRIES),"layouts":LAYOUTS,"noise":PRIORS,
        "seed":178627819918,"native_shape":768,"query":BOX,"ROI":prior.CROP,"donor_span":80,
        "scope":"Fresh cases with periodic evidence in three bounded exterior fields. The fit estimates frequencies there, then fits phase on an independent quarter of the query. Exact center frequency arm measures the cost of first-stage geometry. The wrong context rotates both donors, with identical local inputs.",
    }
    write_json(ROOT/"plan.json",plan)
    model,payload=load_scene_checkpoint(checked(binding),device="cuda",weights="ema",expected_sha256=binding["sha256"])
    assert payload["step"]==2000
    model.mode="none"
    cases=ROOT/"cases"
    cases.mkdir()
    began=time.monotonic()
    results=[]
    with ieee_fp32():
        for ni,(profile,noise) in enumerate(PRIORS.items()):
            model.base.set_noise(noise["shot"],noise["read"])
            for li,layout in enumerate(LAYOUTS):
                for g in GEOMETRIES:
                    for repeat in (0,1):
                        key=f"{profile}-{layout}-g{g}-r{repeat}"
                        seed=178627819918+90001*ni+4003*li+121*g+19*repeat
                        store,masks,contexts,geometry,metadata=simulate(g,layout,noise,seed)
                        order=("packed","variance","colors","wb","matrix")
                        parent=model(*(store[k].cuda() for k in order)).cpu().numpy()
                        raw,var,c,truth=(store[k].numpy() for k in ("packed","variance","colors","target"))
                        metrics={"parent":prior.metrics(parent,parent,truth,masks)}
                        pred={"parent":parent}
                        exact=[d.frequency for d in geometry]
                        if g==90 and repeat==li==ni==0:
                            write_json(ROOT/"independence.json",independent_query_check(raw[1],c[1],exact,noise))
                            assert all(
                                not (x+80>BOX[0]-32 and y+80>BOX[1]-32 and x<BOX[0]+288 and y<BOX[1]+288)
                                for x,y in contained_tiles(contexts["matching"],BOX,80)
                            )
                        donors={"center-given":exact}
                        inferences={}
                        for name,observed in contexts.items():
                            p,d=infer_prior(observed,c[0],BOX,noise)
                            donors[name]=p
                            inferences[name]=d
                        for name,freq in donors.items():
                            values,witness=[],[]
                            for i in (0,1,2):
                                y,r=choose(parent[i],raw[i],var[i],c[i],freq,noise)
                                values.append(y)
                                witness.append(r)
                            batch=np.asarray(values)
                            for i,arm in enumerate(("additive","joint","local")):
                                id_=name+"-"+arm
                                pred[id_]=batch[:,i]
                                metrics[id_]=prior.metrics(pred[id_],parent,truth,masks)
                            inferences[name+"-delivery"]=witness
                        retained=None
                        if repeat==0 and g in (91,94):
                            bundle=cases/(key+".npz")
                            np.savez_compressed(bundle,**{k:v.numpy() for k,v in store.items()},
                                               **{f"pred_{k}":v for k,v in pred.items()},**masks)
                            retained=reference(bundle)
                        row=cases/(key+".json")
                        write_json(row,{"id":key,"layout":layout,"profile":profile,"geometry":g,"repeat":repeat,
                            "seed":seed,"measurements":metrics,"evidence":inferences,"frequency":donors,
                            "physical":metadata,"retained":retained,
                            "fingerprints":{k:fingerprint(v) for k,v in store.items()}})
                        results.append(reference(row))
                        print(key, [inferences[k]["best_window_pair_count"] for k in contexts],
                              np.round(metrics["matching-joint"]["response"],3),round(time.monotonic()-began,2),flush=True)
    assert len(results)==72
    write_json(ROOT/"result.json",{"plan":reference(ROOT/"plan.json"),"records":results,
                                   "seconds":time.monotonic()-began})


if __name__=="__main__":
    main()
