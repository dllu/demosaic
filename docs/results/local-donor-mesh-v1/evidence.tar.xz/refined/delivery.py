"""Keep independent front and weak RAW checks when relaxing phase screening."""

import dataclasses

from mesh import restore
from support import query_phases


def delivery(parent,raw,var,colors,freq,noise,*,refine=False,local=False):
    if freq is None:
        return parent,{"admission":"no exterior pair"}
    carriers,reserved,strength=query_phases(raw,colors,freq,noise,refine=refine)
    n=(noise["shot"],noise["read"])
    _,front=restore(parent,raw,var,colors,carriers[::-1],n,method="add",reserved=reserved)
    ready=max(strength)>=3 and front[0]["basis"] is not None
    admission={"local_carriers":[dataclasses.asdict(g) for g in carriers],
               "reserved_phase_scores":strength,"front_check":front}
    if not ready:
        return parent,admission|{"admission":"front check"}
    result,witness=restore(parent,raw,var,colors,carriers,n,method="adaptive",
                           local=local,reserved=reserved)
    return result,admission|{"admission":"tested the rear direction","witness":witness}
