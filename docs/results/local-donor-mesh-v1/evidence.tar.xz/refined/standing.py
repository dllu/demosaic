"""Compare localized donor support on the fixed standing GFX crops."""

import dataclasses
import importlib.util
import os
import sys
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from mesh import restore
from support import infer_prior, query_phases

ROOT=Path(__file__).resolve().parent
EARLIER=ROOT.parent/"multiline-raw-shoulders-v1"
sys.path.append(str(EARLIER))
spec=importlib.util.spec_from_file_location("native_reference_layout",EARLIER/"standing.py")
legacy=importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)


from delivery import delivery


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[12,13])
    os.nice(12)
    torch.set_num_threads(2)
    source=read_json(legacy.SAVED)
    plan=read_json(checked(source["plan"]))
    prior_path=EARLIER/"standing/result.json"
    last={r["id"]:r for r in read_json(prior_path)["results"]}
    base_path=legacy.PREVIOUS/"none/collection.json"
    base=read_json(base_path)
    assert base["plan"]==source["plan"]
    observed={r["id"]:r for r in plan["observations"]}
    snapshots={r["id"]:r for r in base["records"]}
    destination=ROOT/"standing"
    destination.mkdir()
    rows=[]
    for row in source["boards"]:
        obs=observed[row["observation"]]
        if obs["kind"] not in ("gfx","mesh"):
            continue
        old=last[row["id"]]
        found=snapshots[row["observation"]]
        with np.load(checked(obs["arrays"]),allow_pickle=False) as f:
            arrays={k:f[k] for k in ("packed","variance","colors","wb","matrix")}
        assert {k:fingerprint(v) for k,v in arrays.items()}==found["input_fingerprints"]
        image=np.load(checked(found["prediction"]),allow_pickle=False)[0]
        box=old["native_query"]
        x,y,w,h=old["native_ROI"]
        roi=(x-box[0],y-box[1],w,h)
        raw,var,colors=(arrays[k][0] for k in ("packed","variance","colors"))
        p=legacy.window(image,box)
        neighbors={}
        for span in (80,112):
            found_freqs,diagnostic=infer_prior(raw,colors,box,obs["noise"],span=span)
            neighbors[str(span)]=diagnostic
        phase_methods=(("80px relaxed",80,False),("80px refined",80,True),("112px refined",112,True))
        additions,effects,admission=[],{},{}
        for name,span,refined in phase_methods:
            freq=neighbors[str(span)].get("prior_frequencies")
            restored,report=delivery(p,legacy.window(raw,box,phase=2),legacy.window(var,box,phase=2),colors,
                                     freq,obs["noise"],refine=refined)
            admission[name]=report
            residual=65535*legacy.window(restored.astype(float)-p,roi)
            effects[name]={"RMS_DN16":float(np.sqrt(np.mean(residual**2))),
                           "peak_DN16":float(np.abs(residual).max())}
            additions.append((name,legacy.pixel(restored,arrays,roi,row["display_exposure"])))
        compact=row|{"panels":[v for v in row["panels"] if v["label"] not in ("Pooled2k","Spatial2k")]}
        output,panels=legacy.insert_camera_panels(destination,row["id"],compact,"Local-only2k",additions)
        rows.append({"id":row["id"],"noise":obs["noise"],"native_roi":old["native_ROI"],"query":box,
            "pixels":output,"parent":found["prediction"],"checkpoint":base["checkpoint"],"panels":panels,
            "display_exposure":row["display_exposure"],"evidence":neighbors,
            "local_admission":admission,"effects":effects})
        print(row["id"],[neighbors[str(k)]["best_window_pair_count"] for k in (80,112)],
              [v["admission"] for v in admission.values()], [round(v["RMS_DN16"],3) for v in effects.values()],flush=True)
    assert len(rows)==8
    write_json(destination/"result.json",{
        "driver":reference(__file__),"support":reference(ROOT/"support.py"),"method":reference(ROOT/"mesh.py"),
        "previous_coordinates":reference(prior_path),"source_plan":source["plan"],"rows":rows,
        "scope":"80px and 112px exterior windows. A disjoint query subset discovers phase. Only the stronger phase has a reserve score requirement. Both physical directions retain held-out query checks. This real panel is qualitative.",
    })

if __name__=="__main__":
    main()
