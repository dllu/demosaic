"""Publish localized mesh measurements and native comparisons."""

import hashlib
import importlib.util
import shutil
import tarfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
FIRST=ROOT.parent/"local-donor-mesh-v1"
REPLAY=ROOT.parent/"local-donor-mesh-replay-v1"
REPO=Path.cwd()
OUT=REPO/"docs/images/local-donor-mesh-v1"
DEST=REPO/"docs/results/local-donor-mesh-v1"
SELECTED=("iso400-additive-g94-r0","iso400-occluded-g91-r0",
          "iso400-broken-g91-r0","iso6400-occluded-g94-r0")

spec=importlib.util.spec_from_file_location("mesh_measurements",ROOT.parent/"joint-mesh-phase-v1/run.py")
measures=importlib.util.module_from_spec(spec)
spec.loader.exec_module(measures)


def portable(r):
    return r|{"path":str(checked(r).relative_to(REPO))}


def load_trial(root):
    d=read_json(root/"result.json")
    plan=read_json(checked(d["plan"]))
    for k in ("driver","method","support","checkpoint"):
        checked(plan[k])
    by_id={}
    for r in d["records"]:
        obj=read_json(checked(r))
        by_id[obj["id"]]=obj
    assert len(by_id)==72
    return d,plan,by_id


def summarize(rows):
    gap=[r["gap_added_RMS_DN16"] for r in rows if r["gap_added_RMS_DN16"] is not None]
    return {
        "cases":len(rows),
        "response_percent":[100*mean(r["response"][i] for r in rows) for i in range(3)],
        "increment_RMS_DN16":[mean(r["increment_RMS_DN16"][i] for r in rows) for i in range(3)],
        "changed_roles":[sum(r["changed"][i] for r in rows) for i in range(3)],
        "max_negative_RMS_DN16":[max(r["negative_added_RMS_DN16"][i] for r in rows) for i in range(2)],
        "mean_gap_added_RMS_DN16":mean(gap) if gap else None,
    }


def main():
    a,p,first=load_trial(FIRST)
    b,q,replay=load_trial(REPLAY)
    assert q["first_panel"]==reference(FIRST/"result.json")
    assert first.keys()==replay.keys() and p["checkpoint"]==q["checkpoint"]
    groups=defaultdict(list)
    for k,r in first.items():
        t=replay[k]
        assert r["measurements"]["parent"]==t["measurements"]["parent"]
        assert r["fingerprints"]==t["fingerprints"] and r["frequency"]==t["frequency"]
        groups[r["profile"],r["layout"]].append(r["measurements"]|t["measurements"])
    controlled=read_json(ROOT/"result.json")
    guarded={Path(r["path"]).stem:read_json(checked(r)) for r in controlled["closed"]}
    checked_extra=read_json(ROOT/"confirmed.json")
    confirmation={r["id"]:r for r in checked_extra["rows"]}
    assert guarded.keys()==confirmation.keys() and len(guarded)==12
    OUT.mkdir(parents=True,exist_ok=True)
    DEST.mkdir(parents=True,exist_ok=True)
    boards=[]
    groups_control=defaultdict(list)
    for key,r in guarded.items():
        original=first[key]
        t=confirmation[key]
        assert t["source"]==reference(ROOT/"cases"/(key+".json"))
        archives=[original["retained"],replay[key]["retained"],r["predictions"],t["predictions"]]
        maps=[]
        for archive in archives:
            with np.load(checked(archive),allow_pickle=False) as d:
                maps.append(dict(d))
        local,new,reconstructed,confirmed=maps
        assert original["fingerprints"]=={k:fingerprint(local[k]) for k in original["fingerprints"]}
        for k in ("packed","target","variance","colors","matrix","wb","pred_parent"):
            np.testing.assert_array_equal(local[k],new[k])
        target=local["target"]
        parent=local["pred_parent"]
        masks={k:local[k] for k in ("strong_phase","weak_phase","support")}
        for method,ground in r["methods"].items():
            measured=measures.metrics(reconstructed["pred_"+method],parent,target,masks)
            np.testing.assert_allclose(ground["increment_RMS_DN16"],measured["increment_RMS_DN16"],atol=1e-10)
            assert ground["changed"]==measured["changed"]
        for condition,ground in t["scores"].items():
            measured=measures.metrics(confirmed["pred_"+condition+"-confirmed"],parent,target,masks)
            np.testing.assert_allclose(ground["increment_RMS_DN16"],measured["increment_RMS_DN16"],atol=1e-10)
            assert ground["changed"]==measured["changed"]
        groups_control[r["profile"]].append({"parent":original["measurements"]["parent"]}|r["methods"]|
                      {k+"-confirmed":v for k,v in t["scores"].items()})
        if key not in SELECTED:
            continue
        arrays={k:local[k][1:2] for k in ("packed","colors","wb","matrix")}
        inputs=[noisy_malvar(arrays)[0],parent[1],new["pred_matching-refined"][1],
                reconstructed["pred_matching-both"][1],reconstructed["pred_matching-guarded"][1],
                confirmed["pred_matching-confirmed"][1],target[1]]
        native=native_board(OUT,key,inputs,arrays,{"case":key,"checkpoint":p["checkpoint"],
                            "noise":p["noise"][r["profile"]],"sensor_seed":original["seed"],
                            "Bayer_indices":local["colors"][1].tolist()},
                labels=("Noisy Malvar","Local trunk","Rear only","Both directions",
                        "Local support","Extra RAW check","Exact GT"),
                triplet_indices=(0,5,6),exposure=1,contrast=8)
        for k in ("board","triplet"):
            native[k]["image"]=portable(native[k]["image"])
        boards.append(native)
    assert len(boards)==4
    camera_path=ROOT/"confirmed-standing/result.json"
    camera=read_json(camera_path)
    images=OUT/"standing"
    images.mkdir(exist_ok=True)
    published=[]
    for row in camera["rows"]:
        orig=checked(row["pixels"])
        dest=images/orig.name
        shutil.copyfile(orig,dest)
        new=portable(reference(dest))
        assert row["pixels"]["sha256"]==new["sha256"]
        published.append(row|{"pixels":new})
    assert len(published)==8
    files={"publisher.py":Path(__file__),"first/independence.json":FIRST/"independence.json"}
    for tag,root in (("first",FIRST),("refined",REPLAY),("guard",ROOT)):
        paths=("run.py","mesh.py","support.py","result.json","standing.py","standing/result.json","run.log","standing.log")
        for name in paths:
            files[f"{tag}/{name}"]=root/name
        method=read_json(root/"result.json")
        if "plan" in method:
            files[f"{tag}/plan.json"]=checked(method["plan"])
        for link in method["records"] if "records" in method else method["closed"]:
            obj=checked(link)
            files[f"{tag}/cases/{obj.name}"]=obj
    for name in ("confirmed.json","confirmed-standing/result.json","guard.py","audit.py","confirm.py",
                 "confirmed-standing.py","extra-holdout.json","audit.log","confirmed-standing.log"):
        files[f"guard/{name}"]=ROOT/name
    files["refined/delivery.py"]=REPLAY/"delivery.py"
    for name in ("mesh.py","run.log","standing.log","plan.json"):
        absent=FIRST/"first-attempt"/name
        if absent.exists():
            files[f"first-attempt/{name}"]=absent
    archive=DEST/"evidence.tar.xz"
    member_hashes={name:reference(f)["sha256"] for name,f in files.items()}
    with tarfile.open(archive,"x:xz",preset=4) as bundle:
        for name,f in sorted(files.items()):
            bundle.add(f,arcname=name)
    with tarfile.open(archive) as bundle:
        assert set(bundle.getnames())==set(member_hashes)
        for name,expected in member_hashes.items():
            assert hashlib.file_digest(bundle.extractfile(name),"sha256").hexdigest()==expected
    write_json(DEST/"publication.json",{
        "closed_fresh_pairs":72,"retained_replay_pairs":12,"archive":portable(reference(archive)),
        "members":member_hashes,"native":boards,"standing":published,
        "additional_holdout":reference(ROOT/"extra-holdout.json"),
        "fresh_summary":[{"profile":n,"layout":l,"method":m,**summarize([x[m] for x in v])}
                     for (n,l),v in sorted(groups.items()) for m in v[0]],
        "guard_summary":[{"profile":n,"method":m,**summarize([x[m] for x in v])}
                     for n,v in sorted(groups_control.items()) for m in v[0]],
        "scope":"Experimental RAW component. Fresh 72-pair local donor inference and matched phase recentering. Guard and extra query confirmation are post-review diagnostics on the retained subset and fixed camera views.",
    })


if __name__=="__main__":
    main()
