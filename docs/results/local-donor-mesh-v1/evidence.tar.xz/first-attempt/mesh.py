"""Local held-out Bayer tests of a repeating crossing and its component wires."""

from dataclasses import dataclass
import math

import numpy as np

from demosaic.isolated_line import coordinates, native_sites


@dataclass(frozen=True)
class Carrier:
    frequency: tuple[float, float]
    offset: float
    width: float
    perspective: tuple[float, float] = (0.0, 0.0)


def phase(x, y, carrier):
    f, g = carrier.frequency, carrier.perspective
    return (f[0] * x + f[1] * y) / (1 + g[0] * x + g[1] * y) - carrier.offset


def ribbon(x, y, carrier):
    value = phase(x, y, carrier)
    period = value - np.rint(value)
    d = period / carrier.width
    return np.exp(-0.5*d*d)


def noise_weights(values, colors, shot, read, take):
    medians = np.array([np.median(values[take & (colors==c)]) for c in range(3)])
    return 1/(np.maximum(medians,1e-4)*shot+max(read,1e-10))


def projected_fit(x, u, y, w):
    """Fit candidate and null with one nuisance model on these Bayer samples."""
    root = np.sqrt(w)
    xx = root[:,None]*x
    yy = root*y
    uu = root[:,None]*u
    solution = np.linalg.solve(xx.T@xx, xx.T@np.column_stack((yy,uu)))
    residual = uu - xx@solution[:,1:]
    # A small ridge on the residualized columns only for the flexible joint fit.
    precision = residual.T @ residual
    penalty = 0.04*np.trace(precision)/len(precision) if len(precision)>1 else 0
    a = np.linalg.solve(precision + penalty*np.eye(len(precision)), residual.T @ (yy-xx@solution[:,0]))
    return solution[:,0],solution[:,1:],a,residual,precision


def split_fit(x, u, y, c, fold, noise, method):
    """Only A samples select weights and coefficients for prediction on B."""
    held = []
    for a in (0,1):
        train=fold==a
        test=~train
        wc=noise_weights(y,c,*noise,train)
        increments, residuals = [],[]
        for k in range(3):
            v=train&(c==k)
            b=test&(c==k)
            if v.sum()<64 or b.sum()<64:
                return []
            if method=="adaptive":
                options=(u["add"],u["occlusion"])
            else:
                options=(u[method],)
            models=[]
            for shape in options:
                offset, decor, amplitude, r, _=projected_fit(x[v],shape[v],y[v],np.full(v.sum(),wc[k]))
                increment=(shape[b]-x[b]@decor)@amplitude
                residual=y[b]-x[b]@offset
                score=np.dot(increment,increment)*wc[k]
                overlap=np.dot(increment,residual)*wc[k]
                models.append((increment,residual,overlap,score,amplitude.tolist()))
            increments.append(models)
        comparisons=[]
        for option in range(len(increments[0])):
            o=sum(v[option][2] for v in increments)
            power=sum(v[option][3] for v in increments)
            comparisons.append((2*o-power,o/math.sqrt(max(power,1e-20))))
        held.append(comparisons)
    return held


def evidence(witness, method, level):
    if not witness:
        return None,0.
    if method=="adaptive":
        # Each model's prediction was fixed before evaluating the other half.
        # Consensus margin chooses linked occlusion vs the additive null.
        linked=all(row[1][0]>row[0][0]+1 for row in witness)
        option=int(linked)
        label="occlusion" if linked else "add"
    else:
        option=0
        label=method
    if not all(row[option][0]>0 and row[option][1]>level for row in witness):
        return None,0.
    strength=min(row[option][1] for row in witness)
    return label,float(np.clip((strength-level)/2,0,1))


def fields(x, y, carriers):
    p,q=(ribbon(x,y,g) for g in carriers)
    u={
        "add":q[...,None],
        "occlusion":(q*(1-p))[...,None],
        "separate":np.stack([q,p*q],axis=-1),
    }
    return p,u


def restore(parent, packed, variance, colors, carriers, noise, *, method, level=1.75, local=False, reserved=None):
    h,w=parent.shape[-2:]
    xn,yn=native_sites(packed.shape[-2:], (-(w-1)/2,-(h-1)/2))
    x,y=coordinates(h,w,origin=(-(w-1)/2,-(h-1)/2))
    # Fold identity is tied to actual packed CFA sites rather than phase.
    index=np.indices(packed.shape[-2:]).sum(0)%2
    folds=np.broadcast_to(index,packed.shape)
    c=np.broadcast_to(np.asarray(colors)[:,None,None],packed.shape)
    p,u=fields(xn,yn,carriers)
    _,display_fields=fields(x,y,carriers)
    candidate=np.stack((np.ones_like(xn),xn/128,yn/128,p),axis=-1)
    sites=(c,(yn+(h-1)/2).astype(int),(xn+(w-1)/2).astype(int))
    parent_samples=parent[sites]
    roles=[(None,None)] if not local else [(i,j) for i in (-64,64) for j in (-64,64)]
    result=np.zeros_like(parent,dtype=float)
    normalization=np.zeros((h,w),float)
    witnesses=[]
    for cx,cy in roles:
        if cx is None:
            keep=np.ones_like(packed,dtype=bool)
            taper=np.ones_like(x)
        else:
            keep=(np.abs(xn-cx)<=80)&(np.abs(yn-cy)<=80)
            rampx=np.clip((x+24)/48,0,1)
            rampy=np.clip((y+24)/48,0,1)
            taper=(rampx if cx>0 else 1-rampx)*(rampy if cy>0 else 1-rampy)
        if reserved is not None:
            keep &= ~reserved[None]
        z=candidate[keep]
        b={k:v[keep] for k,v in u.items()}
        raw=packed[keep].astype(float)
        rgb=c[keep]
        reserved=split_fit(z,b,raw,rgb,folds[keep],noise,method)
        label,gain=evidence(reserved,method,level)
        normalization+=taper
        entry={"scores":reserved,"basis":label,"blend":gain,"center":[cx,cy]}
        if label is not None:
            weights=1/np.maximum(variance[keep],1e-12)
            alphas=[]
            for k in range(3):
                sel=rgb==k
                design, test=z[sel], b[label][sel]
                _,_,raw_gain,projected,_=projected_fit(design,test,raw[sel],weights[sel])
                # Replace the corresponding phase-subspace projection in the parent.
                _,_,old_gain,_,_=projected_fit(design,test,parent_samples[keep][sel],weights[sel])
                difference=raw_gain-old_gain
                result[k]+=(display_fields[label]@difference)*taper*gain
                alphas.append(difference.tolist())
            entry["amplitude_change"]=alphas
        witnesses.append(entry)
    return (parent+result/np.maximum(normalization,1e-12)[None]).astype(parent.dtype),witnesses
