"""Fit native local pattern amplitude on the same or the other Bayer half."""
from functools import lru_cache
from pathlib import Path
import sys

import numpy as np

from collect import ROOT, mask

COV=ROOT.with_name("scene-raw-covariance-v1")
sys.path.insert(0,str(COV))
from covariance import bank_basis, SIZE, STRIDE, QUERY

ARMS=("parent","half_average","half_same","half_other","full_other_unadjusted",
      "full_same","full_other","full_signed","all_guide")
THRESHOLD=1.5


@lru_cache(maxsize=64)
def stats_geometry(planes_and_parities):
    design,start,_=bank_basis()
    rows=[]; keep=[]
    for x,y,px,py in planes_and_parities:
        selected=mask(SIZE//2,SIZE//2)
        if (px+py)%2:
            selected=~selected
        keep.append(selected.ravel())
        rows.append(design[y::2,x::2].reshape(-1,design.shape[-1]))
    parts=[]
    for side in (True,False):
        A=np.concatenate([row[k if side else ~k]for row,k in zip(rows,keep,strict=True)])
        inv=np.linalg.inv(A.T@A)
        assert np.linalg.cond(inv)<500
        precision=np.linalg.inv(inv[start:,start:])
        parts.append((A@inv[:,start:],precision))
    return keep,parts


def windows(raw, cfa, roi):
    x,y,w,h=roi
    box_size=SIZE//2
    stride=STRIDE//2
    shots=[]
    pattern=[]
    for phase in np.flatnonzero(cfa==1):
        dx,dy=phase%2,phase//2
        local_x,local_y=(dx-x)%2,(dy-y)%2
        bx,by=(x+local_x-dx)//2,(y+local_y-dy)//2
        patch=raw[phase,by:by+h//2,bx:bx+w//2]
        matrix=np.lib.stride_tricks.sliding_window_view(patch,(box_size,box_size))
        shots.append(matrix[::stride,::stride].reshape(-1,box_size**2).astype(float))
        pattern.append((local_x,local_y,bx%2,by%2))
    keep,geometry=stats_geometry(tuple(pattern))
    return [np.concatenate([m[:,p if side else ~p]for m,p in zip(shots,keep,strict=True)],axis=1)
            for side in (True,False)],geometry


def dense_field(rgb,roi,fine):
    x,y,w,h=roi
    p=np.lib.stride_tricks.sliding_window_view(rgb[1,y:y+h,x:x+w],(SIZE,SIZE))
    data=p[::STRIDE,::STRIDE].reshape(-1,SIZE**2).astype(float)
    data-=data.mean(1,keepdims=True)
    return data@fine/SIZE**2


def projection(pattern, parent, raw, precision, variance, signed=False):
    """Use one fixed direction and one empirical Gaussian uncertainty proxy."""
    u=pattern@precision
    power=np.maximum(1e-20,np.sum(u*pattern,axis=1))
    gain=np.sum((raw-parent)*u,axis=1)/power
    stderr=np.sqrt(variance/power)
    soft=np.sign(gain)*np.maximum(0.,abs(gain)-THRESHOLD*stderr)
    applied=np.clip(soft,-.5 if signed else 0,.75)
    return pattern*applied[:,None],int(np.count_nonzero(applied))


def assemble(raw, full, halves, cfa,wb,matrix,noise,roi=QUERY):
    x,y,w,h=roi
    assert (w,h)==(160,160)
    law=tuple(noise[k]for k in ("shot","read"))
    design,start,_=bank_basis()
    fine=design[...,start:].reshape(SIZE**2,-1)
    measured,structure=windows(raw,cfa,roi)
    c=[]
    variance=[]
    for values,(projector,precision) in zip(measured,structure,strict=True):
        mu=values.mean(1,keepdims=True)
        c.append((values-mu)@projector)
        variance.append(np.maximum(1e-20,law[0]*np.maximum(0.,mu[:,0])+law[1]))
    p=[dense_field(frame,roi,fine)for frame in halves]
    all_coeff=dense_field(full,roi,fine)
    half_average=(halves[0]+halves[1])*.5
    delta={}
    counts={}
    for tag in ARMS[2:]:
        two=[]
        n=[]
        for i in (0,1):
            j=1-i if tag not in ("half_same","full_same") else i
            guide=p[i] if tag!="all_guide" else all_coeff
            reference=p[i] if tag.startswith("half_") or tag=="full_other_unadjusted" else all_coeff
            delta_stage, number=projection(guide,reference,c[j],structure[j][1],variance[i],
                                           signed=tag=="full_signed")
            two.append(delta_stage)
            n.append(number)
        delta[tag]=(two[0]+two[1])*.5
        counts[tag]=n
    line=np.hanning(SIZE).clip(min=.02)
    blend=line[None]*line[:,None]
    positions=[(j,i)for j in range(0,h-SIZE+1,STRIDE)for i in range(0,w-SIZE+1,STRIDE)]
    strong=np.zeros((h,w),dtype=float)
    footprint=np.minimum(1.,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12.)
    taper=footprint[:,None]*footprint[None,:]
    for top,left in positions:
        strong[top:top+SIZE,left:left+SIZE]+=blend
    neutral=np.linalg.solve(matrix.astype(float),np.ones(3))/wb
    neutral/=neutral[1]
    results={"parent":full,"half_average":half_average}
    for tag,v in delta.items():
        spatial=(v@fine.T).reshape(len(positions),SIZE,SIZE)
        added=np.zeros((h,w),dtype=np.float64)
        for (top,left),field in zip(positions,spatial,strict=True):
            added[top:top+SIZE,left:left+SIZE]+=field*blend
        added/=strong
        added=(added-np.sum(added*taper)/np.sum(taper))*taper
        base=half_average if tag.startswith("half_") else full
        frame=base.copy()
        frame[:,y:y+h,x:x+w]+=(neutral[:,None,None]*added).astype(np.float32)
        results[tag]=frame
    return results,counts
