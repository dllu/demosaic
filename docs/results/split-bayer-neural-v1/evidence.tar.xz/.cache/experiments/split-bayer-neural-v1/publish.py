"""Verify matched Bayer half experiments and retain native evidence."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
IMAGES = Path('docs/images') / ROOT.name
RESULT = Path('docs/results') / ROOT.name


def panels(spec):
    with Image.open(checked(spec['image'])) as image:
        pixels = np.asarray(image.convert('RGB'))
    cells = {p.get('label', p.get('name')):pixels[y:y+h,x:x+w] for p in spec['panels']
             for x,y,w,h in [p['png_xywh']]}
    assert all(cell.shape == (160,160,3) for cell in cells.values())
    return cells


def retain(spec, subdir):
    cells = panels(spec)
    source = checked(spec['image'])
    target = IMAGES / subdir / source.name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source,target)
    assert reference(target)['sha256'] == spec['image']['sha256']
    spec['image']['path'] = target.relative_to(IMAGES).as_posix()
    return cells


def main():
    names = [('neighbor','score.json'),('lattice','score-lattice.json'),('inflated','score-inflated.json')]
    sources = {name:reference(ROOT/path) for name,path in names}
    scores = {name:read_json(checked(src)) for name,src in sources.items()}
    native_ref = reference(ROOT/'native-extended.json')
    native = read_json(checked(native_ref))
    assert len(native['standing']['rows']) == 8 and len(native['exact']) == 2
    for name,source in sources.items():
        assert native[name] == source
    checkpoint = scores['neighbor']['checkpoint']
    collections = {}
    for name,score in scores.items():
        assert score['checkpoint'] == checkpoint and len(score['rows']) == 128
        assert score['summary']['split'] == scores['neighbor']['summary']['split']
        for profile,source in score['masked'].items():
            batch = read_json(checked(source))
            assert len(batch['rows']) == 64 and batch['checkpoint'] == checkpoint
            collections[name,profile] = batch
        for current,prior in zip(score['rows'],scores['neighbor']['rows'],strict=True):
            for field in ('case','source','profile','prediction_receipt'):
                assert current[field] == prior[field]
            for field in ('parent','all_guide'):
                assert current['stats'][field] == prior['stats'][field], (name,field)
    for profile in ('iso400','iso6400'):
        rows = [collections[name,profile]['rows'] for name in scores]
        for variants in zip(*rows,strict=True):
            for key in ('profile','source','index','input','full_reference'):
                assert variants[0][key] == variants[1][key] == variants[2][key], key
    for row in native['exact']:
        assert row['checkpoint'] == checkpoint
        a, b = retain(row['board'],'exact'), retain(row['triplet'],'exact')
        assert len(b) == 3 and all(np.array_equal(a[key],value) for key,value in b.items())
    for row in native['standing']['rows']:
        a, b = retain(row['board'],'standing'), panels(row['reference_board'])
        assert row['checkpoint'] == checkpoint
        common = a.keys() & b.keys()
        assert {'Noisy (Malvar)','Parent 100k EMA','ISO100 AHD reference'} <= common
        assert all(np.array_equal(a[key],b[key]) for key in common),row['id']
    manifest = IMAGES/'manifest.json'
    write_json(manifest,{**native,'source':native_ref,
                         'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()},replace=True)
    raw = [ROOT/path for _,path in names] + [checked(native_ref),ROOT/'validation.json']
    raw.extend(checked(src) for score in scores.values() for src in score['masked'].values())
    raw.extend(ROOT.glob('*.py'))
    raw.extend(ROOT.glob('*.log'))
    raw += [ROOT.with_name('scene-raw-covariance-v1')/name for name in ('covariance.py','evaluate.py')]
    raw += [ROOT.with_name('scene-local-contrast-2400-v1')/'measure.py',
            Path('scripts/report_scene_wave_guides.py'),Path('src/demosaic/cfa.py')]
    RESULT.mkdir(exist_ok=True)
    archive = RESULT/'evidence.tar.xz'
    members = {p.resolve().relative_to(Path.cwd()).as_posix():p for p in raw}
    with tarfile.open(archive,'w:xz',preset=4) as out:
        for name,p in sorted(members.items()):
            out.add(p,arcname=name,recursive=False)
    with tarfile.open(archive) as inp:
        for name,p in members.items():
            with inp.extractfile(name) as fd:
                assert hashlib.file_digest(fd,'sha256').hexdigest() == reference(p)['sha256']
    write_json(RESULT/'publication.json',dict(sources=sources,native=reference(manifest),archive=reference(archive),
          checkpoint=checkpoint,validation=read_json(ROOT/'validation.json'),
          cal_and_test={name:score['summary']['split'] for name,score in scores.items()},
          test={name:{k:{mode:m['fine'] for mode,m in v.items()} for k,v in score['summary']['output'].items() if k.endswith('/test')}
                for name,score in scores.items()},
          scope='Existing Corpus 100k EMA. Six paired masked inference sweeps, 48 held-out tests at two priors, exact crop triplets and both standing GFX families. No new weights or broad panels.'),replace=True)
    print('Verified',len(members),'archive members and twelve native images')


if __name__ == '__main__':
    main()
