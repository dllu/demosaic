"""Score the delivered split-input directions against the frozen 100k parent."""
from pathlib import Path
import sys
import time

import numpy as np

from assemble import ARMS, ROOT, assemble
from collect import plan_data
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

sys.path.insert(0,str(ROOT.with_name("scene-raw-covariance-v1")))
from evaluate import coefficients, measure, split, stats


def inputs(item, detail):
    historical=read_json(checked(item["prediction_receipt"]))
    cfg=read_json(checked(historical["case"]))
    assert detail["input"]==cfg["input"] and detail["full_reference"]==item["prediction_receipt"]
    with np.load(checked(cfg["input"]),allow_pickle=False) as f:
        arrays={k:f[k] for k in ("packed","wb","matrix","colors","target")}
    with np.load(checked(detail["predictions"]),allow_pickle=False) as f:
        folds=f["folds"]
    with np.load(checked(historical["saved"]),allow_pickle=False) as f:
        parent=f["100k"]
    images={arm:[] for arm in ARMS}
    counts=[]
    noise=cfg["profile"]
    for i in range(len(parent)):
        result,info=assemble(arrays["packed"][i],parent[i],folds[:,i],arrays["colors"],
                            arrays["wb"],arrays["matrix"],noise)
        for arm,value in result.items():
            images[arm].append(value)
        counts.append(info)
    return cfg,arrays,folds,{k:np.stack(v)for k,v in images.items()},counts


def summary(rows):
    split_map=split(rows)
    bank={}
    examples=[]
    rng=np.random.default_rng(26220009)
    # Half-input methods are scored as delivered. Full-input corrections
    # share a development-set quiet budget without using held test targets.
    calibration=[r for r in rows if r["profile"]=="iso6400" and r["source"] in set(split_map["calibration"])]
    assert len(calibration)==16
    controls=ARMS[4:]
    full_dose={a:float(np.mean([np.sqrt(r["stats"][a]["fine"]["quiet"][2]) for r in calibration])) for a in controls}
    assert min(full_dose.values())>0.
    budget=min(.25,*full_dose.values())
    doses={key:budget/value for key,value in full_dose.items()}
    for iso in ("iso400","iso6400"):
        for name,ids in split_map.items():
            selected=[r for r in rows if r["profile"]==iso and r["source"] in set(ids)]
            assert len(selected)==len(ids)
            samples=np.vstack((np.arange(len(ids)),rng.integers(len(ids),size=(10000,len(ids)))))
            output={}
            for policy in ("unit","matched quiet"):
                scoped={}
                for band in measure.BANDS:
                    extracted={}
                    for arm in ARMS:
                        dose=doses.get(arm,1.) if policy=="matched quiet" else 1.
                        active=[r["stats"][arm][band] for r in selected]
                        ref=np.asarray([v["truth"]for v in active])
                        val=np.asarray([v["response"] for v in active])
                        estimates={"response_pp":100*(val[:,0]+dose*val[:,1])[samples].sum(1)/ref[samples].sum(1)}
                        for field in ("increment","present","quiet"):
                            values=np.asarray([v[field] for v in active])
                            s=values[:,0]+2*dose*values[:,1]+dose*dose*values[:,2]
                            estimates[field+"_RMS_DN16"]=np.sqrt(np.maximum(0.,s[samples].mean(1)))
                            if field=="increment" and band=="fine" and (iso,name,policy,arm)==("iso6400","test","matched quiet","full_other"):
                                delta=np.sqrt(np.maximum(s,0))-np.sqrt(values[:,0])
                                extreme=(int(np.argmin(delta)),int(np.argmax(delta)))
                                examples.extend({"source":selected[i]["source"],"index":selected[i]["case"],
                                                 "paired_delta_DN16":float(delta[i])} for i in extreme)
                        estimates["added_quiet_RMS_DN16"]=np.sqrt(np.asarray([v["quiet"][2]for v in active]))[samples].mean(1)*dose
                        extracted[arm]=estimates
                    pairs=[(a,"parent") for a in ARMS[1:]]
                    pairs += [("half_other","half_same"),("half_other","half_average"),
                        ("full_other","full_same"),("full_other","all_guide"),("full_signed","full_other")]
                    means={name:{k:float(v[0])for k,v in d.items()} for name,d in extracted.items()}
                    estimates={}
                    for x,y in pairs:
                        diff={k:extracted[x][k]-extracted[y][k] for k in extracted[x]}
                        estimates[x+"_vs_"+y]={k:{"point":float(v[0]),"interval":np.quantile(v[1:],(.025,.975)).tolist()}for k,v in diff.items()}
                    scoped[band]={"means":means,"delta":estimates}
                output[policy]=scoped
            bank[iso+"/"+name]=output
    return {"split":split_map,"quiet_budget":budget,"doses":doses,
            "unit_added_quiet_calibration":full_dose,"output":bank,"examples":examples}


def run(method):
    t0=time.monotonic()
    root,seen,spec=plan_data()
    setting=read_json(checked(spec["panel"]))
    prefix="masked" if method=="neighbor" else "lattice"
    receipts={profile:reference(ROOT/f"{prefix}-{profile}.json")for profile in ("iso400","iso6400")}
    by_key={}
    for profile,source in receipts.items():
        record=read_json(checked(source))
        assert record["checkpoint"]==spec["models"]["100k"] and record["panel"]==root
        by_key.update({(profile,row["source"]):row for row in record["rows"]})
    audit=[]
    for item in seen["source_metrics"]:
        if item["draw"]!="independent":
            continue
        row=by_key[item["profile"],item["source"]]
        case,data,folds,images,counts=inputs(item,row)
        supervised={key:np.broadcast_to(data[key][None],(3,*data[key].shape))for key in ("wb","matrix")}
        supervised["exposure"]=case["profile"]["exposure"]
        assert measure.parts(supervised,images["parent"],data["target"],setting)==item["metrics"]["100k"]
        roi=setting["score_ROI_xywh"]
        gt=coefficients(data["target"],supervised,roi)
        parent=coefficients(images["parent"],supervised,roi)
        measures={}
        for arm,frames in images.items():
            delta=coefficients(frames-images["parent"],supervised,roi)
            measures[arm]={k:stats(gt,parent,delta,fltr)for k,fltr in measure.BANDS.items()}
        audit.append({"case":case["case"],"source":item["source"],"profile":item["profile"],
                      "prediction_receipt":item["prediction_receipt"],"stats":measures,"counts":counts})
        if len(audit)%8==0:
            print(len(audit),round(time.monotonic()-t0,1),flush=True)
    assert len(audit)==128
    output="score.json" if method=="neighbor" else "score-lattice.json"
    write_json(ROOT/output,{"driver":reference(__file__),"imputation":method,"operator":reference(ROOT/"assemble.py"),
                                 "checkpoint":spec["models"]["100k"],
              "panel":root,"settings":spec["panel"],"masked":receipts,
              "rows":audit,"summary":summary(audit),"seconds":time.monotonic()-t0},replace=True)


if __name__=="__main__":
    run(sys.argv[1] if len(sys.argv)>1 else "neighbor")
