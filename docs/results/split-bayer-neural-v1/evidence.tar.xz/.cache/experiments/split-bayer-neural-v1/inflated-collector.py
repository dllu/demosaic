"""Qualify the lattice guide with doubled in-band noise in the neural input."""
from pathlib import Path
import sys

from collect import ROOT


def run(which):
    if which in ("iso400","iso6400"):
        source=ROOT/"collect.py"
        changes={
            'net.set_noise(p["shot"],p["read"])':'net.set_noise(2*p["shot"],2*p["read"])',
            'inputs["packed"],inputs["variance"],':'inputs["packed"],2*inputs["variance"],',
            'else "lattice-data"':'else "inflated-data"',
            "else 'lattice'":"else 'inflated'",
            'else "neighbor")':'else "lattice")',
            '"imputation":method,':'"imputation":method,"noise_multiplier":2.,',
            'reference(__file__)':'reference(root/"inflated.py")',
        }
        filename=str(source)
        args=[filename,which,"lattice"]
    elif which=="score":
        source=ROOT/"score.py"
        changes={
            'else "lattice"':'else "inflated"',
            'else "score-lattice.json"':'else "score-inflated.json"',
            'else "neighbor")':'else "inflated")',
            'reference(__file__)':'reference(root/"inflated.py")',
        }
        filename=str(source)
        args=[filename, "inflated"]
    else:
        raise ValueError("Expected a photo profile or score")
    code=source.read_text()
    for old,new in changes.items():
        assert code.count(old)==1,old
        code=code.replace(old,new)
    sys.argv[:] = args
    exec(compile(code,filename,"exec"),{"__name__":"__main__","__file__":filename,"root":ROOT})


if __name__=="__main__":
    run(sys.argv[1])
