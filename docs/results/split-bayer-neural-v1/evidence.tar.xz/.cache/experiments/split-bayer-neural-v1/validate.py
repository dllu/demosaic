"""Verify actual sample isolation and checkerboard spectral transfer."""
import numpy as np

from collect import ROOT,fill,lattice_fill,mask
from assemble import bank_basis, windows
from demosaic.experiments.artifacts import reference,write_json


def check():
    rng=np.random.default_rng(281977)
    base=rng.normal(.22,.006,(3,4,128,128)).astype(np.float32)
    variance=np.float32(.00128)*base+np.float32(6.5536e-6)
    flags=mask(128,128)
    assert flags.sum()==8192 and (~flags).sum()==8192
    errors=[]
    for cls in (fill,lattice_fill):
        for observed in (flags,~flags):
            hidden=base.copy()
            hidden[...,~observed]=np.nan
            masked_var=variance.copy()
            masked_var[...,~observed]=np.nan
            expected=cls(base,variance,observed)
            new=cls(hidden,masked_var,observed)
            for actual,other in zip(expected,new,strict=True):
                np.testing.assert_array_equal(actual,other)
            np.testing.assert_array_equal(new[0][...,observed],base[...,observed])
            np.testing.assert_array_equal(new[1][...,observed],variance[...,observed])
            assert all(np.isfinite(v).all()for v in new)
        # A cosine well inside the diamond earns a wider response than
        # neighbor interpolation. Compare the interior only for both masks.
        col,row=np.meshgrid(np.arange(128),np.arange(128))
        truth=(.22+.012*np.cos(2*np.pi*25*col/128)*np.cos(2*np.pi*17*row/128)).astype(np.float32)
        stack=np.broadcast_to(truth,(1,4,*truth.shape)).copy()
        obtained=np.mean([cls(stack,variance[:1],side)[0]for side in (flags,~flags)],axis=0)[0,0]
        crop=np.s_[28:-28,28:-28]
        witness=truth[crop]-.22
        measured=obtained[crop]-.22
        errors.append({"method":cls.__name__,"interior_response":float(np.sum(witness*measured)/np.sum(witness**2)),
                  "RMS_DN16":float(np.sqrt(np.mean((obtained[crop]-truth[crop])**2))*65535)})
    assert errors[1]["interior_response"]>.95 and errors[0]["interior_response"]<.85
    design,start,_=bank_basis()
    coeff=rng.normal(scale=.001,size=design.shape[-1])
    for x,y in ((48,48),(49,49),(49,48),(48,49)):
        native=np.full((256,256),.22)
        native[y:y+32,x:x+32]=.22+design@coeff
        packed=np.stack([native[dy::2,dx::2] for dy in range(2) for dx in range(2)])
        for layout in ((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0)):
            raw,fit=windows(packed,np.asarray(layout),(x,y,160,160))
            for samples,(inverse,_) in zip(raw,fit,strict=True):
                np.testing.assert_allclose((samples[0]-samples[0].mean())@inverse,coeff[start:],
                                           atol=1e-12,rtol=0.)
    write_json(ROOT/"validation.json",{"driver":reference(__file__),"physical_CFA_layout_cases":16,
        "hidden_values_and_variance_replaced_by_NaN":True,
        "known_signal_packed_cycles":[25/128,17/128],"interior_transfer":errors},replace=True)
    print(errors)


if __name__=="__main__":
    check()
