"""Inspect half-data corrections on exact photos and both standing GFX scenes."""
from pathlib import Path
import sys

import numpy as np
import torch
from PIL import Image

from assemble import ROOT, assemble
from collect import input_forwards, plan_data
from score import inputs
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

sys.path.insert(0,str(ROOT.with_name("paired-luminance-detail-v1")))
from render import native_png

STUDY=ROOT.with_name("scene-full-epoch-v1")/"review-native-040000"
NAMES={"parent":"Corpus 100k EMA","half_average":"Average of masks",
       "half_other":"Other-half check on masked",
       "full_same":"Same-half check","full_other":"Other-half check",
       "full_signed":"Other-half signed","full_other_unadjusted":"Unchecked parent transfer"}
VIEW=("parent","half_average","half_other","full_same","full_other","full_signed")


def blended(full,value,dose):
    return full+np.float32(dose)*(value-full)


def exact(neighbor,lattice,inflated):
    result=read_json(checked(neighbor))
    better=read_json(checked(lattice))
    enlarged=read_json(checked(inflated))
    panel,bank,spec=plan_data()
    settings=read_json(checked(result["settings"]))
    assert result["panel"]==better["panel"]==enlarged["panel"]==panel
    files=[read_json(checked(t["masked"]["iso6400"])) for t in (result,better,enlarged)]
    chosen=better["summary"]["examples"]
    assert len(chosen)==2 and chosen[0]["source"]!=chosen[1]["source"]
    folder=ROOT/"exact"
    folder.mkdir(exist_ok=True)
    records=[]
    for proof in chosen:
        case=next(row for row in bank["source_metrics"] if row["source"]==proof["source"] and (row["profile"],row["draw"])==("iso6400","independent"))
        plans=[next(r for r in item["rows"]if r["source"]==proof["source"])for item in files]
        stage,source,_,outputs,_=inputs(case,plans[1])
        _,_,_,prev,_=inputs(case,plans[0])
        _,_,_,twice,_=inputs(case,plans[2])
        a,b,c=(obj["summary"]["doses"] for obj in (result,better,enlarged))
        p=outputs["parent"]
        refs={k:source[k][None]for k in ("colors","wb","matrix")}
        refs["packed"]=source["packed"][:1]
        candidates=(noisy_malvar(refs)[0],p[0],prev["half_average"][0],outputs["half_average"][0],
                    blended(p[0],prev["full_other"][0],a["full_other"]),
                    blended(p[0],outputs["full_other"][0],b["full_other"]),
                    blended(p[0],outputs["full_signed"][0],b["full_signed"]),
                    twice["half_average"][0],blended(p[0],twice["full_other"][0],c["full_other"]),source["target"][0])
        captions=("Noisy Malvar",NAMES["parent"],"Neighbor-filled average","Lattice-filled average",
                  "Neighbor other-half check","Lattice other-half check","Lattice other-half signed","Lattice double-noise average","Lattice double-noise lift","Exact GT")
        row=settings["rows"][stage["case"]]
        records.append(native_board(folder,f'{row["index"]:03d}-iso6400-split',candidates,refs,
            {"source":row["source"],"CFA":row["camera"]["pattern"],"query":stage["box"],
             "noise":stage["profile"],"ADC_bits":16,"black":.03,"checkpoint":result["checkpoint"],
             "input":stage["input"],"selection_gradient":proof,"dose":{"neighbor":a,"lattice":b,"inflated":c}},
            labels=captions,triplet_indices=(0,5,len(captions)-1),exposure=1/stage["profile"]["exposure"],
            contrast=2,roi=tuple(settings["native_display_ROI_xywh"])))
    return records


def pixels(row):
    with Image.open(checked(row["image"])) as src:
        return {p["label"]:np.asarray(src.crop((x,y,x+w,y+h)).convert("RGB"))
                for p in row["panels"] for x,y,w,h in (p["png_xywh"],)}


@torch.inference_mode()
def standing(neighbor,lattice,inflated):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    result,alt,increased=(read_json(checked(value)) for value in (neighbor,lattice,inflated))
    a,b,c=(obj["summary"]["doses"]for obj in (result,alt,increased))
    binding=result["checkpoint"]
    net,record=load_checkpoint(checked(binding),"cuda",tiled_inference=True)
    assert record["loaded_sha256"]==binding["sha256"] and record["step"]==100000 and "ema" in record
    net.eval()
    whole=reference(STUDY/"work/render/result.json")
    prior=read_json(checked(whole))
    parents=read_json(checked(prior["collections"]["parent100k"]))
    assert parents["checkpoint"]["sha256"]==binding["sha256"]
    base={r["id"]:r for r in parents["records"]}
    manifest=read_json("docs/images/scene-raw-covariance-v1/manifest.json")
    fixed={r["id"]:r for r in manifest["native"]["standing"]["rows"]}
    folder=ROOT/"standing"
    folder.mkdir(exist_ok=True)
    results=[]
    for previous in prior["boards"]:
        name=previous["id"]
        if name not in fixed:
            continue
        archived=fixed[name]
        original=base[previous["observation"]]
        assert archived["input"]==previous["input_arrays"] and archived["parent"]==original["prediction"]
        assert archived["noise"]==previous["noise"]
        with np.load(checked(previous["input_arrays"]),allow_pickle=False) as stream:
            arrays={key:stream[key] for key in ("packed","variance","colors","wb","matrix")}
        for key,array in arrays.items():
            assert fingerprint(array)==original["input_fingerprints"][key]
        x,y,w,h=previous["case"]["ROI_xywh"]
        cx,cy=2*((x-48)//2),2*((y-48)//2)
        roi=[x-cx,y-cy,w,h]
        assert roi==archived["roi"]
        assert cx>=0 and cy>=0
        raw=arrays["packed"][...,cy//2:cy//2+128,cx//2:cx//2+128]
        variance=arrays["variance"][...,cy//2:cy//2+128,cx//2:cx//2+128]
        p=np.load(checked(original["prediction"]),allow_pickle=False)[0,:,cy:cy+256,cx:cx+256]
        machine=[]
        for arm,strength,mult in (("neighbor",a,1.),("lattice",b,1.),("lattice",c,2.)):
            net.set_noise(mult*previous["noise"]["shot"],mult*previous["noise"]["read"])
            folds,trace=input_forwards(raw,mult*variance,*(arrays[k]for k in ("colors","wb","matrix")),net,arm)
            alternatives,counts=assemble(raw[0],p,folds[:,0],*(arrays[k][0]for k in ("colors","wb","matrix")),
                                        previous["noise"],roi)
            tested={k:blended(p,z,strength.get(k,1.))for k,z in alternatives.items()}
            machine.append((tested,trace,counts))
        panels=pixels(previous)
        scale=previous["display_exposure"]
        wb,matrix=(torch.from_numpy(arrays[k])for k in ("wb","matrix"))

        def display(z):
            out=display_crop(torch.from_numpy(z[None]),wb,matrix,roi,exposure=scale)
            return np.rint(out.clip(0,1)*255).astype(np.uint8)

        np.testing.assert_array_equal(display(p),panels["Parent 100k EMA"])
        lead=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")
        order=[(key,panels[key])for key in lead if key in panels]
        m,n,u=(value[0]for value in machine)
        paths={"Neighbor-filled guide":m["half_average"],"Lattice-filled guide":n["half_average"],
               "Neighbor other-half check":m["full_other"],"Lattice other-half check":n["full_other"],
               "Lattice signed lift":n["full_signed"],"Double-noise lattice guide":u["half_average"],
               "Double-noise other-half lift":u["full_other"]}
        order.extend((k,display(v))for k,v in paths.items())
        order.extend((k,panels[k]) for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in panels)
        crop=np.s_[:,roi[1]:roi[1]+160,roi[0]:roi[0]+160]
        differences={k:float(np.sqrt(np.mean((v[crop].astype(float)-p[crop])**2))*65535)for k,v in paths.items()}
        results.append({"id":name,"input":previous["input_arrays"],"raw":archived["raw"],"native_box":archived["native_box"],
                "source_crop":previous["case"],"roi":roi,"checkpoint":binding,"parent":original["prediction"],
                "noise":previous["noise"],"display_exposure":scale,"board":native_png(folder/f"{name}.png",order),
                "reference_board":previous,"neighbor":{"folds":machine[0][1],"counts":machine[0][2]},
                "lattice":{"folds":machine[1][1],"counts":machine[1][2]},"inflated":{"folds":machine[2][1],"counts":machine[2][2]},
                "RGB_RMS_DN16":differences})
        print(name,differences,flush=True)
    assert len(results)==8
    return {"rows":results,"operator_source":whole}


def main():
    neighbor=reference(ROOT/"score.json")
    lattice=reference(ROOT/"score-lattice.json")
    enlarged=reference(ROOT/"score-inflated.json")
    views=exact(neighbor,lattice,enlarged)
    write_json(ROOT/"native-extended.json",{"driver":reference(__file__),"neighbor":neighbor,"lattice":lattice,
                             "inflated":enlarged,"exact":views,"standing":standing(neighbor,lattice,enlarged)},replace=True)


if __name__=="__main__":
    main()
