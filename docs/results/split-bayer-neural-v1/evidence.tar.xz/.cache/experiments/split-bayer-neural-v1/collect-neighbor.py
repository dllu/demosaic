"""Run the same frozen neural parent on two complementary Bayer cell masks."""
from pathlib import Path
import sys
import time

import numpy as np
import torch
from scipy.ndimage import correlate

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
SCENE=ROOT.with_name("scene-full-epoch-v1")
MONITOR=SCENE/"review-full-040000/evaluation/results.json"
KERNEL=np.array(((0.,1.,0.),(1.,0.,1.),(0.,1.,0.)),dtype=np.float32)


def mask(height,width):
    y,x=np.ogrid[:height,:width]
    return (y+x)%2==0


def fill(packed,variance,keep):
    """Copy measured same-phase values and fill from the other four cells."""
    m=keep.astype(np.float32)
    mass=correlate(m,KERNEL,mode="constant",cval=0)
    admissible=~keep
    assert (mass[admissible]>0).all()
    mass[mass==0]=1
    original=np.where(keep,packed,np.float32(0))
    old_variance=np.where(keep,variance,np.float32(0))
    A=np.stack([correlate(p,KERNEL,mode="constant",cval=0)/mass for p in original.reshape(-1,*keep.shape)])
    V=np.stack([correlate(p,KERNEL,mode="constant",cval=0)/mass**2 for p in old_variance.reshape(-1,*keep.shape)])
    return np.where(keep,original,A.reshape(packed.shape)),np.where(keep,old_variance,V.reshape(variance.shape))


def input_forwards(packed, variance, colors, wb, matrix, model):
    first=mask(*packed.shape[-2:])
    frames=[]
    metadata=[]
    for side in (first,~first):
        values,variances=fill(packed,variance,side)
        np.testing.assert_array_equal(values[...,side],packed[...,side])
        np.testing.assert_array_equal(variances[...,side],variance[...,side])
        device="cuda"
        args=[torch.as_tensor(v,device=device)for v in (values,variances,colors,wb,matrix)]
        args[:2]=[x.contiguous(memory_format=torch.channels_last)for x in args[:2]]
        with ieee_fp32():
            output=model(*args).float().cpu().numpy()
        frames.append(output)
        metadata.append({"filled":fingerprint(values),"variance":fingerprint(variances),
                         "observed_count":int(side.sum()),"missing_count":int((~side).sum())})
    return np.stack(frames),metadata


def plan_data():
    root=reference(MONITOR)
    seen=read_json(checked(root))
    spec=read_json(checked(seen["plan"]))
    return root,seen,spec


@torch.inference_mode()
def collect(iso):
    start=time.monotonic()
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    panel,seen,spec=plan_data()
    binding=spec["models"]["100k"]
    net,checkpoint=load_checkpoint(checked(binding),"cuda",tiled_inference=True)
    assert checkpoint["loaded_sha256"]==binding["sha256"] and "ema" in checkpoint and checkpoint["step"]==100000
    net.eval()
    dest=ROOT/"data"
    dest.mkdir(exist_ok=True)
    rows=[]
    for row in seen["source_metrics"]:
        if (row["profile"],row["draw"])!=(iso,"independent"):
            continue
        manifest=read_json(checked(row["prediction_receipt"]))
        case=read_json(checked(manifest["case"]))
        with np.load(checked(case["input"]),allow_pickle=False)as f:
            required=("packed","variance","colors","wb","matrix")
            inputs={k:f[k]for k in required}
        assert {key:fingerprint(value)for key,value in inputs.items()}==manifest["exact_query_inputs"]
        n=len(inputs["packed"])
        p=case["profile"]
        net.set_noise(p["shot"],p["read"])
        frames,splits=input_forwards(inputs["packed"],inputs["variance"],
             *(np.broadcast_to(inputs[k],(n,*inputs[k].shape)).copy() for k in ("colors","wb","matrix")),net)
        assert frames.shape==(2,3,3,256,256) and np.isfinite(frames).all()
        item=dest/(case["id"]+".npz")
        np.savez(item,folds=frames)
        rows.append({"profile":iso,"source":row["source"],"index":case["case"],"input":case["input"],
             "predictions":reference(item),"full_reference":row["prediction_receipt"],"fold_inputs":splits,
             "elapsed_s":time.monotonic()-start})
        if len(rows)%4==0:
            print(iso,len(rows),round(time.monotonic()-start,2),flush=True)
    assert len(rows)==64
    write_json(ROOT/f"masked-{iso}.json",{"driver":reference(__file__),"panel":panel,
        "checkpoint":binding,"rows":rows,"seconds":time.monotonic()-start,
        "precision":"CUDA IEEE FP32","mask":"Complementary parity over packed cells, all CFA phases sampled in each fold."},replace=True)


if __name__=="__main__":
    collect(sys.argv[1])
