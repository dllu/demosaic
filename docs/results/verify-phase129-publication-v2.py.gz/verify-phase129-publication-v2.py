"""Verify exact publication bytes, source identity and current documentation links."""
import gzip
import io
import re
import tarfile
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-phase129-pilot-v1'
publication = repo / 'docs/results/neural-nuisance-phase129-v1/publication.json'
p = read_json(publication)
assert p['viewing']['actually_viewed'] and p['viewing']['figures'] == 38
for a in p['archives']:
    assert gzip.decompress(checked(a['published']).read_bytes()) == checked(a['original']).read_bytes()
for f in p['images']:
    assert checked(f['published']).read_bytes() == checked(f['original']).read_bytes()
with tarfile.open(fileobj=io.BytesIO(checked(p['source_snapshot']).read_bytes()), mode='r:gz') as t:
    members = t.getmembers()
    for m in members:
        assert t.extractfile(m).read() == (root / 'work' / m.name).read_bytes()
    source_count = len(members)
plan = read_json(root / 'plan.json')
old = Path(plan['work']) / 'src'
current = {str(q.relative_to(repo/'src')):reference(q)['sha256'] for q in (repo/'src').rglob('*.py')}
frozen = {str(q.relative_to(old)):reference(q)['sha256'] for q in old.rglob('*.py')}
assert current == frozen
names = ['README.md','docs/index.md','docs/research.md','docs/weak-detail-literature-2026-11.md',
         'docs/global-background-full-panel.md','docs/global-background-phase-reconstruction.md',
         'diary/2026-11-16-19-10-15-fixed-background-phase-reconstruction.md']
links, missing = 0, []
for name in names:
    f = repo / name
    for target in re.findall(r'\]\(([^)]+)\)', f.read_text()):
        target = target.split('#')[0]
        if not target or '://' in target:
            continue
        path = f.parent / target
        if not path.exists():
            missing.append(str(path))
        links += 1
assert not missing, missing
result = {'publication':reference(publication),'script':reference(__file__),
    'archives_exact':len(p['archives']),'images_exact':len(p['images']),
    'executed_source_files_exact':source_count,'current_package_matches_executed_snapshot':True,
    'local_MD_links_checked':links,'new_neural_forwards':0,
    'quality':'Mixed: higher finite response, higher neural quiet/increment error and real bands; no new fine cab crossings.'}
write_json(repo / 'docs/results/phase129-publication-verification-v2.json', result)
print(result)
