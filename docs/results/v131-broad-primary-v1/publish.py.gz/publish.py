from pathlib import Path
from datetime import datetime,timezone
import ast,gzip,json,tarfile,shutil,psutil
from demosaic.experiments.artifacts import read_json,reference,checked,write_json
repo=Path.cwd();root=Path(__file__).absolute().parent;dest=repo/'docs/results/v131-broad-primary-v1';dest.mkdir(parents=True,exist_ok=False)
state=read_json(root/'status.json');owner=psutil.Process(state['owner']['pid']);assert owner.create_time()==state['owner']['created'] and owner.is_running()
child=psutil.Process(state['child']['pid']);assert child.create_time()==state['child']['created'] and child.is_running()
lines=(root/'photo.log').read_text().splitlines();progress=[ast.literal_eval(s)for s in lines if s.startswith("{'stage': 'photo'")]
assert progress and progress[-1]['batches']>0
write_json(root/'running-observation.json',{'observed_UTC':datetime.now(timezone.utc).isoformat(),'state':state,'exact_controller_and_child_alive':True,'last_photo_forward_progress':progress[-1],'photo_log_tail':lines[-4:],'available_RAM_GiB':psutil.virtual_memory().available/2**30,'free_internal_GiB':shutil.disk_usage(root).free/2**30,'scope':'Confirmed live V131 broad photo worker after positive neural-forward progress. Progress snapshot, not completed panel/score/audit evidence. All new results remain internal; failed prior runs preserved.'})
archives=[]
def archive(p,name):
 data=p.read_bytes();target=dest/(name+'.gz')
 with target.open('xb')as f:f.write(gzip.compress(data,mtime=0))
 assert gzip.decompress(target.read_bytes())==data
 archives.append({'original':reference(p),'archive':reference(target),'encoding':'gzip; exact original bytes'})
for name in ['plan.json','launch.json','compatibility.json','running-observation.json','publish.py']:archive(root/name,name)
for v in [1,2,3,4]:
 old=root.with_name(f'v131-broad-primary-v{v}')
 for name in ['plan.json','launch.json','status.json','compatibility.log','compatibility.json','photo.log']:
  p=old/name
  if p.exists():archive(p,f'failed-v{v}-'+name)
 archive(old/'work/scripts/evaluate_v131_broad.py',f'failed-v{v}-wrapper.py')
diag=root.with_name('v131-primary-runtime-diagnostic-v1')
for name in ['inputs.json','launch.json','result.json','run.py','output.log']:archive(diag/name,'same-process-diagnostic-'+name)
plan=read_json(root/'plan.json');work=Path(plan['work']);target=dest/'executed-sources.tar.gz'
with tarfile.open(target,'x:gz')as t:
 for path,digest in plan['frozen_files'].items():
  p=checked({'path':path,'sha256':digest});t.add(p,arcname=str(p.relative_to(work)))
archives.append({'archive':reference(target),'encoding':'tar.gz; exact75 historical files plus wrapper','plan':reference(root/'plan.json')})
target=dest/'evaluate_v131_broad.py';shutil.copyfile(repo/'scripts/evaluate_v131_broad.py',target);archives.append({'original':reference(repo/'scripts/evaluate_v131_broad.py'),'archive':reference(target),'encoding':'identical source bytes'})
write_json(dest/'publication.json',{'status':'V131-broad-primary-live-with-verified-photo-forwards','archives':archives,'active_plan':reference(dest/'plan.json.gz'),'compatibility':reference(dest/'compatibility.json.gz'),'running_observation':reference(dest/'running-observation.json.gz'),'failed_attempts_preserved':[1,2,3,4],'scope':'Active five-panel V131-only comparison, not completed scores. Two corrected precision probes pass; old/new implementations agree exactly within a shared process. Historical-model parser drops only2 disabled flags. First failed run omitted noise conditioning, second mismatched layout, third tight roundoff bound, fourth cache outside frozen write root. Current cache lies within work and declared output paths are preflighted. No prior failed run produced a broad panel forward record. Original input witnesses, source/data/metric code and all91 EMA/backbone identities remain exact. No restart/signal to existing V132 training, endpoint reviewer or frozen analytic panel.'})
print(len(archives),'archives; live photo batches',progress[-1]['batches'])
