import importlib.util,sys,os,json,hashlib
from pathlib import Path
import numpy as np
import torch
root=Path(__file__).absolute().parent;repo=next(p for p in root.parents if (p/'PROMPT.md').exists())
def ref(path):
 p=Path(path).absolute()
 with p.open('rb')as f:return {'path':str(p),'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
def save(name,value):
 with(root/name).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
(root/'run.claim').open('x').close();os.nice(10);torch.set_num_threads(2)
torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
old=repo/'.cache/experiments/v131-broad-primary-v2/work/src/demosaic'
spec=importlib.util.spec_from_file_location('demosaic_primary',old/'__init__.py',submodule_search_locations=[str(old)])
package=importlib.util.module_from_spec(spec);sys.modules[spec.name]=package;spec.loader.exec_module(package)
from demosaic_primary.model import ModelConfig as OldConfig
from demosaic_primary.inference import load_checkpoint as old_load
from demosaic.inference import load_checkpoint as new_load
original=OldConfig.from_checkpoint
def parse(cls,values):
 extra={k:v for k,v in values.items()if k not in cls.__dataclass_fields__}
 assert extra=={'raw_frequency_features':False,'raw_spatial_features':False}
 return original({k:v for k,v in values.items()if k not in extra})
OldConfig.from_checkpoint=classmethod(parse)
plan=json.loads((repo/'.cache/experiments/v131-broad-primary-v2/plan.json').read_text());checkpoint=plan['checkpoints'][0]
assert ref(checkpoint['path'])['sha256']==checkpoint['sha256']
save('inputs.json',{'checkpoint':checkpoint,'probes':plan['probes'],'script':ref(__file__),'old_python_sources':[ref(p)for p in old.rglob('*.py')],'new_python_sources':[ref(p)for p in (repo/'.cache/experiments/raw-spatial-continuation-v2/work/src/demosaic').rglob('*.py')],'scope':'Two native implementations, identical91 EMA tensors/backbone, same process/GPU. Two saved inputs, both cuDNN benchmark modes, two repeats:16 root/encoder forwards. No GT/source/noise/RAW/optimizer work.'})
models=[]
for loader in [old_load,new_load]:
 model,state=loader(checkpoint['path'],device='cuda');model.eval().requires_grad_(False)
 assert len(model.restoration_state_dict())==91
 for key,value in model.restoration_state_dict().items():assert torch.equal(value.cpu(),state['ema'][key])
 models.append(model)
assert all(torch.equal(v,models[1].context.backbone.state_dict()[k])for k,v in models[0].context.backbone.state_dict().items())
counts=[{'root':0,'encoder':0}for _ in models]
for i,model in enumerate(models):
 def hook(*_,i=i):counts[i]['root']+=1
 def encoder(*_,i=i):counts[i]['encoder']+=1
 model.register_forward_pre_hook(hook);model.context.backbone.register_forward_pre_hook(encoder)
rows=[]
with torch.inference_mode():
 for index,row in enumerate(plan['probes']):
  assert ref(row['arrays']['path'])==row['arrays'];assert ref(row['saved_V131']['path'])==row['saved_V131']
  with np.load(row['arrays']['path'],allow_pickle=False)as z:batch=[torch.from_numpy(z[k]).cuda()for k in ['packed','variance','colors','wb','matrix']]
  saved=np.load(row['saved_V131']['path']);values={}
  for benchmark in [False,True]:
   torch.backends.cudnn.benchmark=benchmark
   outputs=[]
   for m,model in enumerate(models):
    model.set_noise(row['noise']['shot'],row['noise']['read'])
    for repeat in range(2):
     value=model(*batch).cpu().numpy();assert np.isfinite(value).all();values[benchmark,m,repeat]=value
     path=root/f'case{index}-benchmark{benchmark}-model{m}-repeat{repeat}.npy'
     with path.open('xb')as f:np.save(f,value,allow_pickle=False)
   a,b=values[benchmark,0,0],values[benchmark,1,0]
   rows.append({'case':row['id'],'benchmark':benchmark,'old_new_bit_exact':a.tobytes()==b.tobytes(),'old_new_max_camera_DN16':float(np.max(np.abs(a.astype(float)-b))*65535),'old_targeted_max_camera_DN16':float(np.max(np.abs(a.astype(float)-saved))*65535),'repeat_bit_exact':[values[benchmark,m,0].tobytes()==values[benchmark,m,1].tobytes()for m in range(2)],'old_fixed_autotuned_max_camera_DN16':float(np.max(np.abs(values[False,0,0].astype(float)-values[benchmark,0,0]))*65535)})
save('result.json',{'inputs':ref(root/'inputs.json'),'rows':rows,'counts':counts,'all_EMA_backbone_tensors_exact':True,'scope':'Same-process old/new implementation equality; differences to previously saved targeted runtime and fixed/autotuned algorithms remain explicit. No tolerance relaxation or broad evaluation follows automatically.'})
print(json.dumps({'rows':rows,'counts':counts}),flush=True)
