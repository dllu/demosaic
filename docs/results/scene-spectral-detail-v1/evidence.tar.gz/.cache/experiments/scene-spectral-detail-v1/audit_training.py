"""Independently verify the admitted dataset, observations and training endpoint."""

import hashlib
import json
import math
import random
from pathlib import Path

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-detail-v1")
REV = Path(".cache/experiments/scene-spectral-detail-review-v1")


def lines(path):
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]


def main():
    doc = ROOT / "plan.json"
    plan = read_json(doc)
    terminal = ROOT / "training/completed.json"
    done = read_json(terminal)
    total = plan["steps"]
    assert done["plan"] == reference(doc) and done["steps_per_mode"] == total
    assert done["parent"] == plan["parent"] and not done["discarded_preflight"]
    sources = lines(checked(plan["train_manifest"]))
    evaluation = lines(checked(plan["development_manifest"]))
    assert len(sources) == 24660 and len(evaluation) == 64
    allowed = {r["id"] for r in sources}
    protected = {r["id"] for r in evaluation}
    assert len(allowed) == len(sources) and not allowed & protected
    assert all(
        r["bin_factor"] == 4 and r["dtype"] == "uint16" and len(r["cache_sha256"]) == 64
        for r in sources
    )
    assert not any(
        pattern in (r["title"] + " " + r["download_path"]).lower()
        for r in sources
        for pattern in ("dscf3879", "dscf3880", "dscf3835", "dscf3842")
    )
    holdout = read_json(checked(read_json(REV / "plan.json")["development"]))
    assert {read_json(checked(row))["source_id"] for row in holdout["cases"]} == protected
    obs = lines(checked(done["observations"]))
    trace = lines(checked(done["training_log"]))
    assert len(obs) == len(trace) == total
    for index, (row, logged) in enumerate(zip(obs, trace, strict=True)):
        rng = hashlib.sha256(f"{plan['data_seed']}:{index}:source".encode()).digest()[:8]
        chooser = random.Random(int.from_bytes(rng, "little") % 2**62)
        selected = sources[chooser.randrange(len(sources))]
        assert row["source_id"] == selected["id"] and row["index"] == index
        assert row["cache_sha256"] == selected["cache_sha256"]
        assert len(row["boxes_xywh"]) == plan["crops_per_scene"] == 4
        h, w = row["native_hw"]
        for x, y, tw, th in row["boxes_xywh"]:
            assert x % 2 == y % 2 == 0 and tw == th == 256
            assert x + tw <= w and y + th <= h and min(x, y) >= 0
        assert logged["step"] == index + 1
        assert set(logged["terms"]) == {"pooled", "spatial"}
        assert all(math.isfinite(v) for mode in logged["terms"].values() for v in mode.values())
    assert len({r["source_id"] for r in obs}) == done["distinct_source_ids"]
    checkpoints = {}
    for mode, pointer in done["endpoints_raw_and_ema"].items():
        endpoint = torch.load(checked(pointer), map_location="cpu", weights_only=True)
        assert endpoint["step"] == endpoint["data_draw_index"] == total
        assert endpoint["mode"] == mode and endpoint["plan"] == done["plan"]
        assert (
            endpoint["parent"] == plan["parent"] and endpoint["DINO_sha256"] == plan["DINO_sha256"]
        )
        assert endpoint["model"].keys() == endpoint["ema"].keys()
        states = endpoint["optimizer"]["state"]
        assert len(states) == len(endpoint["model"])
        assert all(s["step"] == total for s in states.values())
        assert all(
            a.shape == b.shape
            and a.dtype == b.dtype
            and torch.isfinite(a).all()
            and torch.isfinite(b).all()
            for a, b in zip(endpoint["model"].values(), endpoint["ema"].values(), strict=True)
        )
        gate = endpoint["ema"]["scene_adapter.output.weight"]
        assert gate.abs().sum() > 0
        checkpoints[mode] = {
            "checkpoint": pointer,
            "trainable_parameters": sum(v.numel() for v in endpoint["model"].values()),
            "ema_gate_weight_L2": float(gate.norm()),
            "invocation": endpoint["mode"],
        }
    write_json(
        ROOT / "training-audit.json",
        {
            "driver": reference(__file__),
            "status": "passed",
            "terminal": reference(terminal),
            "updates_per_arm": total,
            "observation_fingerprints": len(obs),
            "train_development_overlap": [],
            "distinct_training_source_ids": done["distinct_source_ids"],
            "checked_checkpoints": checkpoints,
        },
    )


if __name__ == "__main__":
    main()
