import numpy as np
import torch
from scipy.fft import dctn
from train_scene_spectral_detail import WeakBands

torch.set_num_threads(1)
bands = WeakBands("cpu")
v = torch.full((1, 3, 64, 64), 0.3)
wave = (bands.basis[3, :, None] @ bands.basis[0, None, :]).repeat(2, 2)
clean = v + 0.02 * wave
original = clean.numpy().reshape(1, 3, 2, 32, 2, 32).swapaxes(-3, -2)
direct = dctn(original.astype(np.float64), norm="ortho", axes=(-2, -1))
candidate = bands.spectrum(clean).numpy()
error = float(np.abs(direct - candidate).max() * 65535 / 32)
assert error < 0.02  # DN16 RMS-equivalent for an individual orthonormal coefficient.
inside = bands.targets(clean)
assert [int(valid.sum()) for valid, _ in inside[1]] == [12, 12]
assert bands.loss(clean, inside).item() == 0
signed_reversed = (2 * v - clean).requires_grad_(True)
loss = bands.loss(signed_reversed, inside)
loss.backward()
assert loss.item() > 0 and signed_reversed.grad.abs().sum() > 0
sat = torch.full_like(v, 0.99)
assert bands.loss(v, bands.targets(sat)).item() == 0
print("FP64 SciPy DCT vs training FP32, max DN16 coefficient difference", error)
print("Signed reversal gives nonzero gradients, exact reconstruction and fully invalid sensor targets give zero loss.")
