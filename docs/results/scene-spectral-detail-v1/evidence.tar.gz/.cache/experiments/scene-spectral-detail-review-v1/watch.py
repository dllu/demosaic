"""Continue into the frozen quality review upon the owned training terminal receipt."""

import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-detail-review-v1").resolve()


def main():
    (ROOT / "watch.claim").open("x").close()
    plan = read_json(ROOT / "plan.json")
    qualified = ROOT / "qualification/result.json"
    probe = read_json(qualified)
    assert probe["plan"] == reference(ROOT / "plan.json") and probe["preflight"] is True
    assert len(probe["records"]) == 2
    training = Path(read_json(checked(plan["training"]))["root"]) / "training"
    owner = read_json(training / "owner.json")
    terminal = training / "completed.json"
    write_json(
        ROOT / "watch-launch.json",
        {
            "watch_pid": os.getpid(),
            "source": reference(__file__),
            "upstream_owner": owner,
            "qualification": reference(qualified),
            "evaluation_plan": reference(ROOT / "plan.json"),
        },
    )
    began = time.monotonic()
    while not terminal.exists():
        try:
            proc = psutil.Process(owner["pid"])
            live = proc.create_time() == owner["created"] and proc.status() != psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:
            live = False
        if not live and not terminal.exists():
            raise RuntimeError("The declared trainer exited without closing its endpoint receipt")
        if time.monotonic() - began > 14400:
            raise TimeoutError("Declared endpoint wait deadline reached")
        time.sleep(10)
    completed = read_json(terminal)
    assert completed["plan"] == plan["training"] and completed["discarded_preflight"] is False
    for endpoint in completed["endpoints_raw_and_ema"].values():
        checked(endpoint)
    env = {
        **os.environ,
        "PYTHONPATH": str(ROOT / "work/src"),
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "2",
    }
    result = []
    for stage, command in (
        ("collection", [checked(plan["driver"]), ROOT / "plan.json"]),
        (
            "report",
            [checked(plan["reporter"]), ROOT / "plan.json", ROOT / "collection/result.json"],
        ),
    ):
        at = time.monotonic()
        with (ROOT / f"{stage}.log").open("x") as log:
            proc = subprocess.run(
                [sys.executable, *(str(v) for v in command)],
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=False,
            )
        result.append(
            {"stage": stage, "returncode": proc.returncode, "seconds": time.monotonic() - at}
        )
        if proc.returncode:
            break
    write_json(
        ROOT / "watch-result.json",
        {
            "training": reference(terminal),
            "steps": result,
            "complete": len(result) == 2 and all(v["returncode"] == 0 for v in result),
        },
    )


if __name__ == "__main__":
    main()
