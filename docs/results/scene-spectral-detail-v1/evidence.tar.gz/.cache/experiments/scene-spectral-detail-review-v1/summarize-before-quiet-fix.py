"""Reduce paired source metrics and independently measure the longer weak-detail band."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.fft import dctn

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-detail-review-v1")
METHODS = ("parent", "pooled", "spatial", "spatial-shifted")
LUMA = np.array([0.2126, 0.7152, 0.0722])
FREQ = np.arange(32) / 64
RADIUS = np.hypot(FREQ[None, :], FREQ[:, None])
LOW = (RADIUS >= 1 / 32) & (RADIUS < 1 / 8)


def blocks(v):
    return v[..., 16:240, 16:240].reshape(*v.shape[:-2], 7, 32, 7, 32).swapaxes(-3, -2)


def field(v, wb, matrix):
    return np.einsum(
        "bij,bjhw->bihw", matrix.astype(np.float64), v.astype(np.float64) * wb[..., None, None]
    )


def spectrum(rgb):
    luma = np.einsum("c,bchw->bhw", LUMA, rgb)
    windows = blocks(luma)
    return dctn(windows, axes=(-2, -1), norm="ortho")[..., LOW], windows.mean((-2, -1))


def combine(rows, area):
    if not rows:
        return None
    z = {k: sum(r[k] for r in rows) for k in ("blocks", "target", "prediction", "cross", "error")}
    # All reductions use the exact spatial energy denominator per block.
    signal = z["target"] > 0
    gain = z["cross"] / z["target"] if signal else 0
    rms = np.sqrt(z["error"] / z["blocks"] / area) * 65535
    orthogonal = max(0, z["prediction"] - gain * z["cross"])
    return {
        "blocks": z["blocks"],
        "RMS_DN16": float(rms),
        "gain": float(gain) if signal else None,
        "orthogonal_RMS_DN16": float(np.sqrt(orthogonal / z["blocks"] / area) * 65535),
    }


def rms(v):
    return float(np.sqrt(np.mean(v**2)) * 65535)


def main():
    review_path = ROOT / "review/result.json"
    review = read_json(review_path)
    collection = read_json(checked(review["collection"]))
    plan = read_json(checked(collection["plan"]))
    dev = read_json(checked(plan["development"]))
    group = defaultdict(list)
    for row in review["metrics"]:
        group[row["id"], row["method"]].append(row)
    assert len(group) == 512
    results = []
    for source_ref, predicted in zip(dev["cases"], collection["records"][:128], strict=True):
        case = read_json(checked(source_ref))
        record = read_json(checked(predicted))
        assert case["id"] == record["id"]
        with np.load(checked(case["inputs"]), allow_pickle=False) as z:
            truth, wb, matrix = [z[k] for k in ("crop_target", "crop_wb", "crop_matrix")]
        rgb = field(truth, wb, matrix)
        target, mean = spectrum(rgb)
        target_rms = np.sqrt((target**2).sum(-1)) / 32
        mask = ((blocks(rgb) >= 0) & (blocks(rgb) <= 1)).all((1, -2, -1))
        mask &= (mean >= 0.02) & (mean <= 0.9)
        mask &= (target_rms >= 1e-5) & (target_rms < 0.02 * mean)
        selected = target[mask]
        variants = {
            name: np.load(checked(ref), allow_pickle=False)
            for name, ref in {"parent": record["parent"], **record["variants"]}.items()
        }
        for name, prediction in variants.items():
            rows = group[record["id"], name]
            assert len(rows) == 4
            coeff, _ = spectrum(field(prediction, wb, matrix))
            p = coeff[mask]
            low = []
            if len(p):
                low = [
                    {
                        "blocks": len(p),
                        "target": float(np.vdot(selected, selected)),
                        "prediction": float(np.vdot(p, p)),
                        "cross": float(np.vdot(selected, p)),
                        "error": float(np.vdot(p - selected, p - selected)),
                    }
                ]
            band_names = {"weak": "0", "ordinary": "1", "quiet": "quiet"}
            high = {
                label: combine([r["bands"][key] for r in rows if key in r["bands"]], 256)
                for label, key in band_names.items()
            }
            results.append(
                {
                    "id": case["id"],
                    "source_id": case["source_id"],
                    "method": name,
                    "noise": case["id"].split("-", 2)[-1],
                    "psnr_dB": float(np.mean([r["srgb_psnr"] for r in rows])),
                    "high_bands": high,
                    "lower_weak_band": combine(low, 1024),
                    "difference_from_parent_DN16": rms(
                        prediction.astype(np.float64) - variants["parent"]
                    ),
                }
            )
    assert len(results) == 512
    means = []
    for noise in ("shadows", "iso12800-prior"):
        for method in METHODS:
            used = [x for x in results if (x["noise"], x["method"]) == (noise, method)]
            assert len(used) == 64
            row = {
                "noise": noise,
                "method": method,
                "mean_photo_PSNR_dB": float(np.mean([x["psnr_dB"] for x in used])),
                "mean_output_change_DN16": float(
                    np.mean([x["difference_from_parent_DN16"] for x in used])
                ),
            }
            for label, entries in (
                ("weak_low", [x["lower_weak_band"] for x in used]),
                *[
                    (f"{k}_high", [x["high_bands"][k] for x in used])
                    for k in ("quiet", "weak", "ordinary")
                ],
            ):
                subset = [x for x in entries if x is not None]
                row[label] = {"sources": len(subset), "blocks": sum(x["blocks"] for x in subset)}
                for key in ("RMS_DN16", "gain", "orthogonal_RMS_DN16"):
                    values = [x[key] for x in subset if x[key] is not None]
                    row[label][key] = float(np.mean(values)) if values else None
            means.append(row)
    write_json(
        ROOT / "summary.json",
        {
            "driver": reference(__file__),
            "numerical_review": reference(review_path),
            "source_balanced": means,
            "per_source": results,
            "real_qualitative_prediction_changes": [
                r["output_change_DN16_RMS"] | {"id": r["id"]}
                for r in review["boards"]
                if not r["id"].startswith("development-")
            ],
        },
    )
    for x in means:
        print(
            x["noise"],
            x["method"],
            x["mean_photo_PSNR_dB"],
            x["weak_low"]["RMS_DN16"],
            x["weak_high"]["RMS_DN16"],
            x["quiet_high"]["RMS_DN16"],
            x["mean_output_change_DN16"],
        )


if __name__ == "__main__":
    main()
