"""Validate the accepted cases and native plots against the saved observations."""

from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REV = Path(".cache/experiments/scene-spectral-detail-review-v1")


def pixels(board):
    with Image.open(checked(board["image"])) as file:
        return {
            p["label"]: np.asarray(file.crop((x, y, x + w, y + h)))
            for p in board["panels"]
            for x, y, w, h in [p["png_xywh"]]
        }


def main():
    source_path = REV / "review/result.json"
    r = read_json(source_path)
    collection = read_json(checked(r["collection"]))
    plan = read_json(checked(collection["plan"]))
    fixed = {b["id"]: b for b in read_json(checked(plan["native_boards"]))["boards"]}
    cases = {v["id"]: v for v in (read_json(checked(e)) for e in collection["records"])}
    parents = [read_json(checked(v)) for v in read_json(checked(plan["development"]))["cases"]]
    ids = {(x["id"], x["crop"], x["method"]) for x in r["metrics"]}
    assert len(cases) == 134 and len(ids) == len(r["metrics"]) == 2048
    assert len(r["boards"]) == 16
    assert collection["scene_calls"] == 130 and collection["new_V120_calls"] == 0
    for item in parents:
        record = cases[item["id"]]
        assert record["physical"] == item["input_fingerprints"]
        checked(record["parent"])
    counts, max_rms_delta = 0, 0.0
    view = []
    for board in r["boards"]:
        old = fixed[board["id"]]
        original = pixels(old)
        new = pixels(board)
        for label in original.keys() & new.keys():
            np.testing.assert_array_equal(original[label], new[label])
            counts += 1
        case = cases[board["observation"]]
        x, y, w, h = board["case"]["ROI_xywh"]
        i = board["case"]["crop_index"]
        roi = (i, slice(None), slice(y, y + h), slice(x, x + w))
        base = np.load(checked(case["parent"]), mmap_mode="r")[roi].astype(np.float64)
        assert (w, h) == (160, 160)
        names = {
            "pooled": "Pooled spectral",
            "spatial": "Spatial spectral",
            "spatial-shifted": "Shifted spatial spectral",
        }
        row = {"id": board["id"], "changed_display_channels_from_parent": {}}
        for method, label in names.items():
            val = np.load(checked(case["variants"][method]), mmap_mode="r")[roi]
            target = np.sqrt(np.mean((val - base) ** 2)) * 65535
            max_rms_delta = max(
                max_rms_delta, abs(target - board["output_change_DN16_RMS"][method])
            )
            row["changed_display_channels_from_parent"][method] = int(
                np.count_nonzero(new[label] != new["V120 EMA"])
            )
        view.append(row)
    assert counts == 56 and max_rms_delta < 1e-12
    write_json(
        REV / "review-audit.json",
        {
            "driver": reference(__file__),
            "report": reference(source_path),
            "status": "passed",
            "development_inputs_matched": len(parents),
            "matched_metric_rows": len(ids),
            "retained_native_cells_exact": counts,
            "verified_ROI_changes": len(view) * 3,
            "maximum_ROI_RMS_reduction_difference": max_rms_delta,
            "native_display_changes": view,
        },
    )


if __name__ == "__main__":
    main()
