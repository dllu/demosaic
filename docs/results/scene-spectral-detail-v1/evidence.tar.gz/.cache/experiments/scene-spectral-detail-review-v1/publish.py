"""Bind the result and native boards to the completed training endpoints."""

import tarfile
from pathlib import Path
from shutil import copyfile

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

RAW = Path(".cache/experiments/scene-spectral-detail-v1")
REV = Path(".cache/experiments/scene-spectral-detail-review-v1")
DOC = Path("docs/results/scene-spectral-detail-v1")
IMG = Path("docs/images/scene-spectral-detail-v1")
TRIPLET_IDS = {"development-0-iso12800-prior-crop1", "development-1-shadows-crop0"}


def triplet(board):
    with Image.open(checked(board["image"])) as whole:
        layout = ("Noisy (Malvar)", "Spatial spectral", "Exact GT")
        selected = {x["label"]: x["png_xywh"] for x in board["panels"]}
        canvas = Image.new("RGB", (512, 192), "#eeeeee")
        draw = ImageDraw.Draw(canvas)
        cells = []
        for i, label in enumerate(layout):
            x, y, w, h = selected[label]
            assert (w, h) == (160, 160)
            pixel = whole.crop((x, y, x + w, y + h))
            box = (8 + 168 * i, 24)
            canvas.paste(pixel, box)
            draw.text((box[0], 5), label, fill="black")
            cells.append((pixel, box))
        target = IMG / (board["id"] + "-triplet.png")
        canvas.save(target)
        with Image.open(target) as saved:
            for cell, (x, y) in cells:
                np.testing.assert_array_equal(saved.crop((x, y, x + 160, y + 160)), cell)
    return reference(target)


def main():
    review = read_json(REV / "review/result.json")
    collection = read_json(checked(review["collection"]))
    summary = read_json(REV / "summary.json")
    inspected = read_json(REV / "viewing.json")
    audit = read_json(RAW / "training-audit.json")
    done = read_json(checked(audit["terminal"]))
    assert audit["status"] == "passed" and collection["heads"] == done["endpoints_raw_and_ema"]
    assert summary["numerical_review"] == reference(REV / "review/result.json")
    notes = {r["id"]: r for r in inspected["notes"]}
    assert len(notes) == len(review["boards"]) == 16
    DOC.mkdir()
    IMG.mkdir()
    recorded = []
    for board in review["boards"]:
        group = {**board, "view": notes[board["id"]]["observation"]}
        assert notes[board["id"]]["image"] == board["image"]
        original = checked(board["image"])
        target = IMG / original.name
        copyfile(original, target)
        group["published"] = reference(target)
        assert group["published"]["sha256"] == board["image"]["sha256"]
        if board["id"] in TRIPLET_IDS:
            group["triplet"] = triplet(board)
        recorded.append(group)
    manifest = IMG / "manifest.json"
    write_json(
        manifest,
        {
            "checkpoint_parent": done["parent"],
            "heads": collection["heads"],
            "weights": "EMA",
            "notes_version": reference(REV / "viewing.json"),
            "boards": recorded,
        },
    )
    for name, directory in (
        ("summary.json", REV),
        ("training-audit.json", RAW),
        ("viewing.json", REV),
        ("review-audit.json", REV),
        ("alignment.json", REV),
    ):
        copyfile(directory / name, DOC / name)
    evidence = [
        RAW / name
        for name in (
            "plan.json",
            "preflight.log",
            "preflight/completed.json",
            "preflight/train.jsonl",
            "training.log",
            "training/completed.json",
            "training/train.jsonl",
            "training/observations.jsonl",
            "audit_training.py",
            "training-audit.json",
            "focused-tests.log",
            "audit_band_fixture.py",
            "band-audit.log",
        )
    ] + [
        REV / name
        for name in (
            "plan.json",
            "qualification.log",
            "shift-qualification.log",
            "qualification/result.json",
            "watch.py",
            "watch-launch.json",
            "watch-result.json",
            "collection.log",
            "collection/result.json",
            "review/result.json",
            "summarize.py",
            "summary.json",
            "summarize-before-quiet-fix.py",
            "summary-before-quiet-fix.json",
            "summary-v2.log",
            "audit_review.py",
            "review-audit.json",
            "alignment.json",
            "viewing.json",
            "publish.py",
        )
    ]
    evidence += sorted((REV / "collection").glob("*.json"))
    evidence = list(dict.fromkeys(evidence))
    for directory in (RAW, REV):
        evidence.extend(sorted((directory / "work/scripts").glob("*.py")))
        evidence.extend(
            directory / "work/src/demosaic" / n
            for n in (
                "late_spectral_detail.py",
                "scene_spectral_detail.py",
                "scene_restoration.py",
            )
        )
    archive = DOC / "evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for item in evidence:
            tar.add(item, arcname=item)
    write_json(
        DOC / "publication.json",
        {
            "archive": reference(archive),
            "members": [reference(x) for x in evidence],
            "manifest": reference(manifest),
            "scope": "Completed component EMA quality review with 64 sources and both standing camera scenes.",
        },
    )


if __name__ == "__main__":
    main()
