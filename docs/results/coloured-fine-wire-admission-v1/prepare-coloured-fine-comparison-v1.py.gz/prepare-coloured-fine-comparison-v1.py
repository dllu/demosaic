"""Admit four fixed variants on the closed new48-input/96-field cohort."""
from copy import deepcopy
from pathlib import Path

from demosaic.experiments.artifacts import checked,read_json,reference,verify_plan,write_json

repo=Path.cwd();cohort=repo/'.cache/experiments/coloured-fine-wire-neural-v1'
source=read_json(cohort/'plan.json');verify_plan(source)
assert read_json(cohort/'neural-completed.json')['counts']=={'parent':48,'masked':96,'encoder':144}
parent_groups={g['group']:g['parent']for g in read_json(cohort/'parents-collection.json')['groups']}
base=read_json(repo/'.cache/experiments/neural-nuisance-joint-fine129-pilot-v1/plan.json')
rows=[dict(r,parent=parent_groups[r['group']])for r in source['rows']]
specifications=[('broad',False,'phase','independent',[8,9]),
                ('fine-phase',True,'phase','independent',[10,11]),
                ('fine-sinusoidal',True,'sinusoidal','independent',[12,13]),
                ('joint-fine',True,'sinusoidal','joint',[16,17])]
variants=[]
for name,add_fine,reconstruction,support,cpus in specifications:
    root=cohort/'variants'/name;root.mkdir(parents=True,exist_ok=False)
    model={'kind':'Matched frozen V120 JDD parent with broad guided phase and declared fine variant',
           'parent_label':'V120','parent_checkpoint':source['checkpoint'],'backbone_sha256':source['backbone_sha256'],
           'geometry':base['geometry_config'],'aggregation_config':base['aggregation_config'],
           'phase_guide':True,'add_fine_carriers':add_fine,'fine_reconstruction':reconstruction,'fine_support':support,
           'source':reference(Path(source['work'])/'src/demosaic/neural_nuisance.py'),
           'joint_source':reference(Path(source['work'])/'src/demosaic/joint_colour_evidence.py'),
           'scope':'New coloured development scenes; all methods use the same V120 full parent and genuine masked fields. Source GT frequencies/colour parameters are metadata only, never supplied to restoration.'}
    write_json(root/'analytic-model.json',model)
    plan=deepcopy(base)
    plan.update(root=str(root),work=source['work'],python=source['python'],
                script=reference(Path(source['work'])/'scripts/pilot_neural_nuisance.py'),
                model=reference(root/'analytic-model.json'),rows=rows,finite_groups=[],
                background_configuration=source['background_configuration'],
                background_cache=reference(cohort/'masked-backgrounds-collection.json'),
                prediction_cache=None,full_panel=False,fixed_analytic_frequencies=True,
                add_fine_carriers=add_fine,fine_reconstruction=reconstruction,fine_support=support,
                thresholds=[2],primary='conditional-local-t2',positive_noise_cases=48,
                background_field_count=96,maximum_new_neural_forwards=0,
                standalone_H1_checks=[rows[2]['id'],rows[-1]['id']],
                frozen_files=source['frozen_files'],
                inputs=[reference(cohort/'plan.json'),reference(cohort/'neural-completed.json'),
                        reference(cohort/'masked-backgrounds-collection.json'),reference(cohort/'parents-collection.json'),
                        reference(root/'analytic-model.json'),source['checkpoint'],
                        *[g['arrays']for g in source['groups']],*parent_groups.values()],
                scope='New adaptive48-observation coloured fine-wire cohort:2 sources x4CFAs x2 priors x3 independently noised roles, one far bright edge and two broad structured nuisance carriers.48 fresh V120 full parents/96 fresh A-only fields already closed and unchanged; zero additional neural calls in any analytic variant. Compare broad-only, fine phase, independent-colour fine H1 and joint-colour fine H1, all6 global/local controls at fixed threshold2. All192 variant corrections must close before new GT scoring. Primary joint-versus-independent fine H1: weak sensor-RGB response plus quiet/increment/colour-orthogonal errors; per-colour responses retained so neutralization cannot count as recovery. Not a camera generalization/calibrated confidence study. No protected media or training/weight updates.')
    write_json(root/'plan.json',plan);verify_plan(plan)
    variants.append({'name':name,'root':str(root),'plan':reference(root/'plan.json'),'cpus':cpus})
write_json(cohort/'comparison-plan.json',{'cohort':reference(cohort/'plan.json'),'neural':reference(cohort/'neural-completed.json'),
           'script':reference(__file__),'variants':variants,'expected_variant_cases':192,
           'primary':'joint-fine::conditional-local-t2 vs fine-sinusoidal::conditional-local-t2; NN secondary, broad/fine-phase/rawH1 controls retained',
           'scope':'No new noise draw/NN replay/target analysis during this admission. All four48-case producers close before score; fixed t2 and identical V120 parent/fields. Fresh synthetic development evidence, not blinded camera validation.'})
print('Four variants admitted;192 corrections before scoring')
