"""Launch only new full-parent and genuine masked neural fields once."""
import os
import subprocess
import sys
from pathlib import Path

import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

repo=Path.cwd();root=repo/'.cache/experiments/coloured-fine-wire-neural-v1'
plan=read_json(root/'plan.json');verify_plan(plan)
assert not(root/'neural-launch.json').exists()and not(root/'neural.claim').exists()
env=dict(os.environ,PYTHONPATH=plan['work']+'/src:'+plan['work']+'/scripts',CUDA_VISIBLE_DEVICES='0',
         OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
args=[sys.executable,str(checked(plan['script'])),'neural',str(root)]
with(root/'neural.log').open('x')as log:
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'neural-launch.json',{'pid':process.pid,'create_time':psutil.Process(process.pid).create_time(),
           'plan':reference(root/'plan.json'),'script':reference(__file__),'command':args})
print(process.pid,psutil.Process(process.pid).create_time(),flush=True)
