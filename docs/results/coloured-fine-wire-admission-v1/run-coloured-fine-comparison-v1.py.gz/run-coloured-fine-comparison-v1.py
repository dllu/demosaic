"""Reuse closed neural fields, then run four independent CPU variants once."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_identity

repo=Path.cwd();cohort=repo/'.cache/experiments/coloured-fine-wire-neural-v1'
plan=read_json(cohort/'comparison-plan.json')
(cohort/'comparison.claim').open('x').close();os.nice(10)
stages=[]
for variant in plan['variants']:
    root=Path(variant['root']);p=read_json(checked(variant['plan']));work=Path(p['work'])
    for stage,args,cuda in [
        ('backgrounds',[str(checked(p['script'])),'backgrounds',str(root)],'0'),
        ('background-audit',[str(work/'scripts/audit_neural_nuisance_inputs.py'),str(root),str(root/'background-independent-audit.json')],'')]:
        env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES=cuda,
                 OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
        with(root/(stage+'.log')).open('x')as log:
            child=subprocess.Popen([sys.executable,*args],stdout=log,stderr=subprocess.STDOUT,env=env)
            write_json(root/(stage+'-launch.json'),{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':args,'controller':owner_identity()})
            code=child.wait()
        stages.append({'variant':variant['name'],'stage':stage,'returncode':code})
        if code:
            write_json(cohort/'comparison-result.json',{'stages':stages,'all_corrections_closed':False,'failed':variant['name']+':'+stage});sys.exit(code)
children=[]
for variant in plan['variants']:
    root=Path(variant['root']);p=read_json(checked(variant['plan']));work=Path(p['work'])
    env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUDA_VISIBLE_DEVICES='',
             OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
    command=['taskset','-c',','.join(map(str,variant['cpus'])),sys.executable,str(checked(p['script'])),'predict',str(root)]
    log=(root/'predict.log').open('x');child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env)
    identity={'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,'controller':owner_identity(),'plan':variant['plan']}
    write_json(root/'predict-launch.json',identity);children.append((variant,child,log));print('launched',variant['name'],identity,flush=True)
for variant,child,log in children:
    code=child.wait();log.close();stages.append({'variant':variant['name'],'stage':'predict','returncode':code})
success=all(s['returncode']==0 for s in stages)
if success:
    for variant,_,_ in children:
        data=read_json(Path(variant['root'])/'collection.json');assert len(data['rows'])==48 and data['new_neural_forwards']==0 and data['target_or_reference_arrays_loaded']==0
write_json(cohort/'comparison-result.json',{'plan':reference(cohort/'comparison-plan.json'),'script':reference(__file__),
           'stages':stages,'all_corrections_closed':success,'cases':192 if success else None,
           'scope':'All four variants terminated. No target scoring or new neural/RAW/noise calls in this controller; no automatic retry.'})
print('all192 corrections closed',success,flush=True)
