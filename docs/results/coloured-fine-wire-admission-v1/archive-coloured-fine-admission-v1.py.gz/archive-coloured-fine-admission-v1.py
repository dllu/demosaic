"""Preserve completed neural preparation and immutable running-comparison admission."""
import gzip
import io
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/coloured-fine-wire-neural-v1'
dest=repo/'docs/results/coloured-fine-wire-admission-v1';dest.mkdir(exist_ok=False)
done=read_json(root/'neural-completed.json');assert done['counts']=={'parent':48,'masked':96,'encoder':144}
files=[root/n for n in ['plan.json','neural-launch.json','neural-owner.json','neural-completed.json',
 'masked-backgrounds-collection.json','parents-collection.json','comparison-plan.json','comparison-launch.json',
 'comparison-early-launch-failure-v1.json','comparison-controller.log','neural.log']]
files+=sorted((root/'neural').glob('*-receipt.json'))
comparison=read_json(root/'comparison-plan.json')
for variant in comparison['variants']:
    folder=Path(variant['root'])
    files += [folder/n for n in ['plan.json','analytic-model.json','backgrounds-launch.json','background-audit-launch.json',
                               'backgrounds-collection.json','background-independent-audit.json','predict-launch.json']]
files += [repo/n for n in ['scripts/colored_fine_wire_data.py','scripts/prepare_colored_fine_neural.py','tests/test_colored_fine_wire_data.py',
 '.cache/coloured-fine-data-test-source-v1.py','.cache/coloured-fine-data-tests-v1.log','.cache/coloured-fine-data-tests-v2.log',
 '.cache/coloured-fine-data-ruff-v1.log','.cache/coloured-fine-data-ruff-v2.log','.cache/coloured-fine-neural-ruff-v1.log',
 '.cache/prepare-coloured-fine-wire-neural-v1.log','.cache/launch-coloured-fine-wire-neural-v1.py','.cache/launch-coloured-fine-wire-neural-v1.log',
 '.cache/prepare-coloured-fine-comparison-v1.py','.cache/prepare-coloured-fine-comparison-v1.log','.cache/run-coloured-fine-comparison-v1.py',
 '.cache/archive-coloured-fine-admission-v1.py']]
archives=[]
for f in dict.fromkeys(files):
    name=str(f.relative_to(root)if root in f.parents else f.name).replace('/','--')
    path=dest/(name+'.gz')
    with path.open('xb')as stream:stream.write(gzip.compress(f.read_bytes(),mtime=0))
    assert gzip.decompress(path.read_bytes())==f.read_bytes()
    archives.append({'original':reference(f),'published':reference(path),'decompressed_bytes_exact':True})
buffer=io.BytesIO();members=[]
with tarfile.open(fileobj=buffer,mode='w')as tar:
    for f in sorted((root/'work').rglob('*.py')):
        name=str(f.relative_to(root/'work'));data=f.read_bytes();assert data==(repo/name).read_bytes()
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
        members.append({'member':name,'original':reference(f)})
path=dest/'frozen-source.tar.gz'
with path.open('xb')as stream:stream.write(gzip.compress(buffer.getvalue(),mtime=0))
with tarfile.open(path,'r:gz')as tar:
    for m in members:assert tar.extractfile(m['member']).read()==checked(m['original']).read_bytes()
write_json(dest/'publication.json',{'neural_completion':reference(root/'neural-completed.json'),
           'comparison':reference(root/'comparison-plan.json'),'archives':archives,
           'frozen_source':{'archive':reference(path),'members':members},
           'status':'48 parents/96 genuine masked fields complete; four192-case comparison still awaiting correction closure/scoring/viewing',
           'scope':'Fresh synthetic inputs, independent noise and actual144 V120/DINO calls explicitly recorded; all91 weights/backbone unchanged. Inference never accesses targets/true variance. Preserve initial FP32 test tolerance failure and early controller launch race before any correction. Running logs/progress intentionally excluded; no new-cohort quality claim.'})
print(len(archives),'exact admission/neural/failure archives;',len(members),'frozen sources')
