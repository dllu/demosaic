"""Check the 40 unshared source IDs and the least-contrast half of the panel."""

from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_direct import OUT, summarize


if __name__ == "__main__":
    readout = reference(OUT / "evaluated-held.json")
    info = read_json(checked(readout))
    cohort = reference(OUT / "source-coverage.json")
    known = set(read_json(checked(cohort))["full427_overlapping_ids"])
    rows = {r["id"]: r for r in read_json(checked(info["source"]))["rows"]}
    full = info["rows"]
    separate = [r for r in full if rows[r["id"]]["source"]["id"] not in known]
    faint = sorted(full, key=lambda r: r["scores"]["nominal"]["truth"])[: len(full) // 2]
    assert len(separate) == 48 - len(known)
    report = {
        key: {
            "count": len(selected),
            "ids": [r["id"] for r in selected],
            "metrics": summarize(selected, info["policy"]),
        }
        for key, selected in (("outside_full427", separate), ("fainter", faint))
    }
    write_json(
        OUT / "sensitivity.json",
        {
            "driver": reference(Path(__file__)),
            "source": readout,
            "coverage": cohort,
            "panels": report,
        },
    )
    for k, arm in report.items():
        print(
            k,
            arm["count"],
            arm["metrics"]["comparisons"]["nominal"]["signed-response locked"],
            flush=True,
        )
