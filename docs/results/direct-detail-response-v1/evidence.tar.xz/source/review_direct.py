"""Render natural, wire and standing GFX fixtures with the frozen gate strengths."""

from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import direct_detail as model
from review_selector import board, crop, image, named_pixels, wire_scorer
from evaluate_direct import (
    Cases,
    DISPLAY,
    OUT,
    OLD,
    ARMS,
    weights,
    apply,
    fixed_heuristic,
    previous_values,
)

EXACT = (48, 48, 160, 160)
SELECTED = "signed-response"
FAMILIES = (
    "nominal",
    "heuristic",
    "prior_local",
    "error",
    "response",
    "signed-error",
    "signed-response",
)


def render(case, models, prior, cases, policy, *, at_full=False):
    row, d, p, _ = case
    selected, n, gain = apply(d, p, row, models, prior, cases.old_dose)
    roots = {"nominal": p["nominal"]}
    for k, v in selected.items():
        weight = [1, 1] if at_full or k == "prior_local" else policy["arms"][k]["locked"]["dose"]
        correction = (v * np.asarray(weight)[None, :, None, None]).sum(axis=1)
        roots[k] = (roots["nominal"] + correction[:, None] * n[None, :, None, None]).astype(
            p["nominal"].dtype
        )
    if "scene_packed" in d:
        roots["heuristic"] = fixed_heuristic(d, p, row, cases.heuristic)
    if "v120" in p:
        roots["v120"] = p["v120"]
    return roots, {k: x.mean((1, 2)).tolist() for k, x in gain.items()}


def exact(nets, prior, policy, loc):
    measured = reference(OUT / "evaluated-held.json")
    overlay = read_json(checked(measured))
    rows = overlay["rows"]
    locked = policy["arms"][SELECTED]["locked"]["dose"]
    dose = locked if any(locked) else (1, 1)
    measures = (
        previous_values(rows, SELECTED, dose)["increment"]
        - previous_values(rows, "nominal", (1, 1))["increment"]
    )
    examples = {}
    for idx, sign in (
        (int(measures.argmin()), "largest reduction"),
        (int(measures.argmax()), "largest increase"),
    ):
        examples[rows[idx]["id"]] = (sign, float(measures[idx]))
    if len(examples) == 1:
        examples[rows[-1]["id"]] = ("second source", float(measures[-1]))
    cases = Cases("held")
    images = []
    for case in cases:
        r, d, p, bindings = case
        if r["id"] not in examples:
            continue
        out, gains = render(case, nets, prior, cases, policy, at_full=not any(locked))
        noisy = noisy_malvar(
            {
                "packed": d["packed"],
                **{
                    k: np.broadcast_to(d[k], (len(d["packed"]), *d[k].shape)).copy()
                    for k in ("colors", "wb", "matrix")
                },
            }
        )
        e = 1 / r["profile"]["exposure"]
        frames = {}
        for idx, role in ((0, "present"), (2, "flat")):
            rgba = lambda v: image(crop(v[idx], EXACT), d["wb"], d["matrix"], e)
            seen = {"Noisy Malvar": rgba(noisy), "Exact GT": rgba(d["target"])}
            all_ = ("v120", *FAMILIES) if "v120" in out else FAMILIES
            seen.update((DISPLAY[x], rgba(out[x])) for x in all_)
            frames[role] = board(
                list(seen.items())[:1] + list(seen.items())[2:] + list(seen.items())[1:2],
                loc / f"{r['id']}-{role}.png",
            )
            if idx == 0:
                frames["triplet"] = board(
                    [(k, seen[k]) for k in ("Noisy Malvar", DISPLAY[SELECTED], "Exact GT")],
                    loc / f"{r['id']}-triplet.png",
                )
        reason, change = examples[r["id"]]
        images.append(
            {
                "fixture": r,
                "source": bindings,
                "frames": frames,
                "ROI": EXACT,
                "display_exposure": e,
                "selection": reason,
                "increment_delta_DN16": change,
                "dose": dose,
                "mean_gates": gains,
            }
        )
        print(r["id"], reason, change, flush=True)
    return {"evaluation": measured, "rows": images}


def standing(nets, prior, policy, loc):
    before = reference(OLD / "review-camera.json")
    matched = {r["id"]: r for r in read_json(checked(before))["report"]["rows"]}
    rows = []
    cases = Cases("camera")
    for case in cases:
        r, d, _, bindings = case
        saved = matched[r["id"]]
        assert saved["input"] == r["input"] and saved["ROI"] == r["global_ROI"]
        outputs, gains = render(case, nets, prior, cases, policy)
        roi = r["local_ROI"]
        drawings = []
        for view in saved["native"]:
            display = view["exposure"]
            old = named_pixels(view)
            emit = lambda x: image(crop(x[0], roi), d["wb"], d["matrix"], display)
            np.testing.assert_array_equal(emit(outputs["nominal"]), old["Local 50k"])
            pictures = [
                (x, old[x]) for x in ("Noisy (Malvar)", "V120 EMA", "Earlier whole-photo gate")
            ]
            pictures.extend((DISPLAY[x], emit(y)) for x, y in outputs.items())
            pictures.extend(
                (x, old[x])
                for x in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if x in old
            )
            board_ = board(pictures, loc / f"{r['id']}-x{display:g}.png")
            drawings.append(board_ | {"exposure": display, "reference_board": view})
        base = outputs["nominal"].astype(float)
        change = {
            k: float(np.sqrt(np.mean(crop(v - base, roi) ** 2)) * 65535) for k, v in outputs.items()
        }
        rows.append(
            {
                "id": r["id"],
                "RAW": r["raw"],
                "input": r["input"],
                "outputs": bindings,
                "ROI": r["global_ROI"],
                "local_ROI": roi,
                "noise": r["noise"],
                "gains": gains,
                "difference_DN16": change,
                "native": drawings,
            }
        )
        print(r["id"], change, flush=True)
    return {"previous": before, "rows": rows}


def wire(nets, prior, policy):
    bind, scorer = wire_scorer()
    cases = Cases("wires")
    rows = []
    for c in cases:
        r, d, p, provenance = c
        g = r["fixture"]["geometry"]
        shown = d | {"support": np.ones_like(d["support"])} if g["family"] == "smooth-dip" else d
        measure = scorer(shown, g)
        panel, _ = render(c, nets, prior, cases, policy)
        rows.append(
            {
                "id": r["id"],
                "provenance": provenance,
                "measure": {k: measure(x) for k, x in panel.items()},
            }
        )
    return {
        "scorer": bind,
        "rows": rows,
        "scores": {
            name: {
                k: mean(r["measure"][name][k] for r in rows if k in r["measure"][name])
                for k in sorted({k for r in rows for k in r["measure"][name]})
            }
            for name in rows[0]["measure"]
        },
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    job = sys.argv[1]
    fit, models, prior = weights()
    locked = reference(OUT / "evaluated-calibration.json")
    policy = read_json(checked(locked))["policy"]
    folder = OUT / "native" / job
    folder.mkdir(exist_ok=True, parents=True)
    t = monotonic()
    if job == "exact":
        output = exact(models, prior, policy, folder)
    elif job == "camera":
        output = standing(models, prior, policy, folder)
    else:
        output = wire(models, prior, policy)
    write_json(
        OUT / f"review-{job}.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "lock": locked,
            "report": output,
            "seconds": monotonic() - t,
        },
    )
