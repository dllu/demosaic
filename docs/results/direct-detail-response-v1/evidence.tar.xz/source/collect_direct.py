"""Collect direct supervision and a new, source-disjoint natural test panel."""

from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import random
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import _attenuate_local_contrast, scene_seed
import direct_detail as model
from collect_training import batch, load_model, PROFILES
from benchmark_shared_local_encoding import forward

OUT = model.OUT
OLD = model.old.OUT
SEED = 202611200912
COUNT = 768
HOLD = 48
CHUNK = 32
ISO = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": 0.33}
OLD_SOURCE = OLD / "training/plan.json"
OLD_DATA = OLD / "review-features.json"
VAL = Path("/mnt/external/demosaic/commons-frozen44732-bin4-v1/manifest.jsonl")


def identities(items):
    out = set()
    for r in items:
        out.update((r["id"], r["cache_sha256"]))
    return out


def freeze(mode):
    before = reference(OLD_SOURCE)
    old = read_json(checked(before))
    source = old["train_manifest"] if mode != "held" else reference(VAL)
    eval_old = read_json(checked(old["observations_for_evaluation"]))
    protected = identities(old["samples"])
    for group in ("calibration", "transfer", "wires"):
        for x in eval_old["groups"][group]:
            row = x["source"] if isinstance(x["source"], dict) else x["fixture"]["source"]
            protected.update((row["id"], row["cache_sha256"]))
    for plan in (
        "/mnt/external/demosaic/junction-occlusion-v1/independent/plan.json",
        "/mnt/external/demosaic/cfa-gap-support-v1/independent/plan.json",
    ):
        protected |= identities(r["source"] for r in read_json(plan)["sources"])
    if mode == "held":
        with checked(old["train_manifest"]).open() as f:
            protected |= identities(map(json.loads, f))
    rows = []
    expected = "val" if mode == "held" else "train"
    with checked(source).open() as f:
        for row in map(json.loads, f):
            h, w = row["shape"][:2]
            if (
                row["split"] == expected
                and row["bin_factor"] == 4
                and min(h, w) >= 512
                and max(h, w) <= 1750
                and not {row["id"], row["cache_sha256"]} & protected
            ):
                rows.append(row)
    rows.sort(key=lambda x: sha256(f"{SEED}/{x['id']}".encode()).digest())
    n = HOLD if mode == "held" else 8 if mode == "preflight" else COUNT
    selected = []
    seen = set()
    for row in rows:
        tag = {row["id"], row["cache_sha256"]}
        if seen.isdisjoint(tag):
            selected.append(row)
            seen |= tag
        if len(selected) == n:
            break
    assert len(selected) == n
    history = reference(OLD / "fit-training/result.json")
    return {
        "driver": reference(__file__),
        "operator": reference(model.__file__),
        "previous": before,
        "evaluation_overlap_reference": reference(OLD_DATA),
        "prior_head": read_json(checked(history))["checkpoints"]["local"],
        "parent": old["parent"],
        "source_manifest": source,
        "recipe_seed": SEED,
        "eligible": len(rows),
        "samples": selected,
        "mode": mode,
        "noise": "ISO6400 for held, mixed positive noise for training",
        "precision": "CUDA IEEE FP32 EMA; exact local encoder reuse",
    }


def acquire(row, index, held):
    raw = checked({"path": row["cache"], "sha256": row["cache_sha256"]})
    mat = np.load(raw, mmap_mode="r", allow_pickle=False)
    assert mat.dtype == np.uint16 and list(mat.shape) == row["shape"]
    u = torch.from_numpy(np.array(mat, dtype=np.float32, copy=True)).permute(2, 0, 1) / 65535
    u = u[:, : u.shape[1] // 2 * 2, : u.shape[2] // 2 * 2]
    rng = random.Random(scene_seed(SEED, index, "scene"))
    rotate, flip = rng.randrange(4), rng.random() < 0.5
    u = torch.rot90(u, rotate, (-2, -1))
    if flip:
        u = u.flip(-1)
    box = tuple(
        scene_crop_boxes(
            u.shape[-2:], patch_size=256, count=1, seed=scene_seed(SEED, index, "crop")
        )[0]
    )
    x, y, w, h = box
    replica = (0, 0, 256, 256)
    crop = u[:, y : y + h, x : x + w].contiguous()
    recipe = sample_scene_recipe(scene_seed(SEED, index, "camera"))
    shot, read = rng.choices(PROFILES, weights=(0.2, 0.60, 0.2))[0]
    luma = 2 ** rng.uniform(-2.6, -0.1)
    if held:
        shot, read, luma = (ISO[k] for k in ("shot", "read", "exposure"))
        recipe = replace(recipe, pattern=tuple(PATTERNS)[index % 4], black=0.03)
    recipe = replace(recipe, shot=shot, read=read, exposure=luma)
    roles = (rng.uniform(0.52, 0.98), rng.uniform(0.02, 0.16), 0.0)
    volume = []
    for k, q in enumerate(roles):
        use = replace(recipe, noise_seed=scene_seed(SEED, index, f"role-{k}"))
        if held and k == 0:
            image = _attenuate_local_contrast(u, box, q, flat_core=False)
            capture = observe_scene(image.contiguous(), use)
            scene = capture.packed.numpy()
            volume.append(capture.crops([box]))
        else:
            new = _attenuate_local_contrast(crop, replica, q, flat_core=k == 2)
            volume.append(observe_scene(new.contiguous(), use).crops([replica]))
    data = {k: torch.cat([x[k] for x in volume]).numpy() for k in ("packed", "variance", "target")}
    data.update({k: volume[0][k][0].numpy() for k in ("colors", "wb", "matrix")})
    if held:
        data["scene_packed"] = scene
    profile = {"shot": shot, "read": read, "exposure": luma}
    return (
        data,
        profile,
        {
            "id": f"direct-{index:04}",
            "source": row if held else row["id"],
            "cache_sha256": row["cache_sha256"],
            "profile": profile,
            "D4": [rotate, flip],
            "box": box,
            "camera": asdict(recipe),
            "scale": roles,
            "observed": fingerprint(torch.from_numpy(data["packed"])),
            "target": fingerprint(torch.from_numpy(data["target"])),
        },
    )


@torch.inference_mode()
def run(mode):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    root = OUT / mode
    root.mkdir(exist_ok=True)
    p = root / "plan.json"
    if not p.is_file():
        write_json(p, freeze(mode))
    plan = reference(p)
    params = read_json(checked(plan))
    assert params["driver"] == reference(__file__) and params["operator"] == reference(
        model.__file__
    )
    net = load_model(params["parent"])
    stat = []
    records = []
    size = len(params["samples"])
    total = monotonic()
    with ieee_fp32():
        for i, row in enumerate(params["samples"]):
            if i % CHUNK == 0:
                start = monotonic()
                if mode != "held":
                    end = min(i + CHUNK, size)
                    resume = root / f"statistics-{i:04}-{end:04}.json"
                    if resume.exists():
                        stat.append(reference(resume))
                        checked(read_json(resume)["data"])
            if mode != "held" and resume.exists():
                continue
            obs, noise, meta = acquire(row, i, held=mode == "held")
            p = forward(net, batch(obs), noise, reuse=True)
            preds = {k: v.cpu().numpy() for k, v in p.items()}
            if mode == "held":
                path = root / f"{meta['id']}.npz"
                with path.open("xb") as f:
                    np.savez(f, **obs, **preds)
                records.append(meta | {"panel": reference(path)})
            else:
                fields = model.stats(obs, preds, noise)
                assert all(np.isfinite(v).all() for v in fields.values())
                records.append((fields, meta))
                if (i + 1) % CHUNK == 0 or i + 1 == size:
                    path = resume.with_suffix(".npz")
                    interim = path.with_suffix(".partial")
                    with interim.open("wb") as f:
                        np.savez(
                            f, **{k: np.stack([r[k] for r, _ in records]) for k in records[0][0]}
                        )
                    interim.replace(path)
                    write_json(
                        resume,
                        {
                            "samples": [m for _, m in records],
                            "data": reference(path),
                            "seconds": monotonic() - start,
                        },
                    )
                    stat.append(reference(resume))
                    records = []
            if (i + 1) % CHUNK == 0 or i + 1 == size:
                print(mode, i + 1, "of", size, "seconds", round(monotonic() - total, 2), flush=True)
    write_json(
        root / "completed.json",
        {
            "plan": plan,
            "stats": stat,
            "rows": records,
            "processed": size,
            "seconds": monotonic() - total,
        },
    )


if __name__ == "__main__":
    for argument in sys.argv[1:]:
        run(argument)
