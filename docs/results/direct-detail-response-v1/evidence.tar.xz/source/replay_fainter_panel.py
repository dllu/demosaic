"""Recapture the wholly held photo IDs at the earlier weak-only contrast strength."""

from dataclasses import replace
from pathlib import Path
from time import monotonic
from unittest.mock import patch
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from collect_direct import OUT, ISO, load_model, batch, forward
import evaluate_direct as evaluation

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("scene-local-contrast-2400-v1")))
import prepare_eval as weak

ROOM = OUT / "faint-recapture"
SCALE = 0.22
V120_CONFIG = Path("configs/current-model.json")


@torch.inference_mode()
def capture():
    base = reference(OUT / "held/completed.json")
    rooms = reference(OUT / "source-coverage.json")
    exclusions = set(read_json(checked(rooms))["full427_overlapping_ids"])
    fixed = reference(OUT / "evaluated-calibration.json")
    stable = read_json(checked(base))
    src = read_json(checked(stable["plan"]))
    chosen = [r for r in stable["rows"] if r["source"]["id"] not in exclusions]
    assert len(chosen) == 40
    ROOM.mkdir(exist_ok=True)
    older = read_json(V120_CONFIG)["checkpoint"]
    plan = ROOM / "plan.json"
    if not plan.exists():
        write_json(
            plan,
            {
                "driver": reference(__file__),
                "source": base,
                "scope": rooms,
                "locked_calibration": fixed,
                "parent": src["parent"],
                "v120": older,
                "renderer": reference(weak.__file__),
                "strength": SCALE,
                "coordinates": "Same D4, Bayer pattern, exposure and native queries as broad holdout.",
                "cases": [x["id"] for x in chosen],
            },
        )
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    local = load_model(src["parent"])
    standard, state = load_checkpoint(checked(older), "cuda", tiled_inference=True)
    assert state["loaded_sha256"] == older["sha256"] and "ema" in state
    standard = standard.eval().to(memory_format=torch.channels_last)
    del state
    standard.set_noise(ISO["shot"], ISO["read"])
    start = monotonic()
    receipts = []
    with ieee_fp32(), patch.object(weak, "SEED", 202611200921):
        for i, r in enumerate(chosen):
            f = ROOM / f"{r['id']}.npz"
            if not f.exists():
                source = r["source"] | {"cache": str(checked(r["physical_cache"]))}
                card = {"index": i, "source": source, "box": r["box"], "camera": r["camera"]}
                full = weak.load_photo(card)
                turns, flip = r["D4"]
                full = torch.rot90(full, turns, (-2, -1))
                if flip:
                    full = full.flip(-1)
                present = weak.patch(full, r["box"], SCALE)
                absent = weak.patch(full, r["box"], 0)
                item = weak.observed_group(
                    full.contiguous(),
                    {"present": present, "masked-fine": absent, "flat": weak.flat_patch(absent)},
                    card,
                    ISO,
                    "independent",
                )
                x = batch(item)
                predictions = forward(local, x, ISO, reuse=True)
                predictions["v120"] = standard(
                    x["packed"].contiguous(memory_format=torch.channels_last),
                    x["variance"].contiguous(memory_format=torch.channels_last),
                    x["colors"],
                    x["wb"],
                    x["matrix"],
                )
                result = {k: v.cpu().numpy() for k, v in predictions.items()}
                assert all(
                    v.shape == (3, 3, 256, 256) and np.isfinite(v).all() for v in result.values()
                )
                tmp = f.with_suffix(".partial")
                with tmp.open("wb") as stream:
                    np.savez(stream, **item, **result)
                tmp.replace(f)
            r = r | {
                "panel": reference(f),
                "broad_panel": r["panel"],
                "seed_index": i,
                "contrast": SCALE,
            }
            receipts.append(r)
            if len(receipts) % 8 == 0:
                print(len(receipts), round(monotonic() - start, 2), flush=True)
    write_json(
        ROOM / "completed.json",
        {
            "driver": reference(__file__),
            "plan": reference(plan),
            "rows": receipts,
            "seconds": monotonic() - start,
        },
    )


class FaintCases(evaluation.Cases):
    def __init__(self, mode):
        super().__init__("held")
        self.source = reference(ROOM / "completed.json")
        self.cases = read_json(checked(self.source))["rows"]
        self.v120 = reference(ROOM / "plan.json")

    def __iter__(self):
        for r in self.cases:
            with np.load(checked(r["panel"]), allow_pickle=False) as f:
                predictions = {k: f[k] for k in ("crisp", "nominal", "smooth", "v120")}
                data = {k: f[k] for k in f.files if k not in predictions}
            yield (
                r,
                data,
                predictions,
                {"input": r["panel"], "broad_input": r["broad_panel"], "v120": self.v120},
            )


def score():
    with patch.object(evaluation, "Cases", FaintCases):
        evaluation.main("faint")


def view():
    import review_direct as staging

    p = OUT / "evaluated-faint.json"
    ancestor = reference(p)
    cal = reference(OUT / "evaluated-calibration.json")
    lock = read_json(checked(cal))["policy"]
    fit, net, prior = evaluation.weights()

    def bind(f):
        return ancestor if Path(f) == OUT / "evaluated-held.json" else reference(f)

    room = OUT / "native" / "faint"
    room.mkdir(exist_ok=True, parents=True)
    with patch.object(staging, "reference", bind), patch.object(staging, "Cases", FaintCases):
        result = staging.exact(net, prior, lock, room)
    assert result["evaluation"] == ancestor
    write_json(
        OUT / "review-faint.json",
        {"driver": reference(__file__), "fit": fit, "lock": cal, "report": result},
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    for mode in sys.argv[1:]:
        {"capture": capture, "score": score, "view": view}[mode]()
