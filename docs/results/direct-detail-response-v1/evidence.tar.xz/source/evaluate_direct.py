"""Lock delivery on the established calibration panel and score new sources."""

from itertools import product
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import direct_detail as model
from train_direct import gain
from evaluate_selector import Cases as PreviousCases, deltas, values as previous_values
import mild_score as fixed
import score

OUT = model.OUT
OLD = model.old.OUT
ARMS = model.NAMES
DISPLAY = {
    "nominal": "Local 50k EMA",
    "heuristic": "Earlier whole-photo gate",
    "prior_local": "Earlier learned local",
    "error": "Exact-risk trained",
    "response": "Response trained",
    "signed-error": "Signed exact-risk",
    "signed-response": "Signed response",
    "v120": "V120 Small EMA",
}


def weights(phase="training"):
    summary = reference(OUT / f"fit-{phase}/result.json")
    check = read_json(checked(summary))
    data = {}
    for name, ref in check["checkpoints"].items():
        stored = torch.load(checked(ref), map_location="cpu", weights_only=True)
        network = model.Head(stored["with_signed"])
        network.load_state_dict(stored["ema"])
        data[name] = (network.eval(), stored["normal"])
    previous = torch.load(checked(check["prior_head"]), map_location="cpu", weights_only=True)
    earlier = model.old.Selector()
    earlier.load_state_dict(previous["ema"])
    return summary, data, (earlier.eval(), previous["normalization"]["local"])


class Cases:
    def __init__(self, group):
        self.group = group
        self.prior = reference(fixed.OUT / "mild-calibration.json")
        self.heuristic = read_json(checked(self.prior))["policy"]["specs"]["whole"]["chosen"]
        prior_weights = reference(OLD / "evaluate-calibration.json")
        self.old_dose = read_json(checked(prior_weights))["policy"]["arms"]["local"]["locked"][
            "dose"
        ]
        if group == "held":
            self.source = reference(OUT / "held/completed.json")
            self.cases = read_json(checked(self.source))["rows"]
            v = OUT / "held-v120.json"
            self.v120 = reference(v) if v.exists() else None
            self.v120_map = (
                {r["id"]: r for r in read_json(checked(self.v120))["rows"]} if self.v120 else {}
            )
        else:
            self.parent = PreviousCases(group)
            self.source = self.parent.binding
            self.v120 = None

    def __iter__(self):
        if self.group == "held":
            for r in self.cases:
                with np.load(checked(r["panel"]), allow_pickle=False) as f:
                    p = {k: f[k] for k in ("crisp", "nominal", "smooth")}
                    d = {k: f[k] for k in f.files if k not in p}
                if r["id"] in self.v120_map:
                    key = self.v120_map[r["id"]]
                    assert key["input"] == r["panel"]
                    p["v120"] = np.load(checked(key["output"]), allow_pickle=False)
                yield r, d, p, {"input": r["panel"], "v120": self.v120_map.get(r["id"])}
            return
        for r, d, p, _feature, metadata in self.parent:
            yield r, d, p, metadata | {"input": r["input"]}


@torch.no_grad()
def apply(meta, pred, item, nets, prior_gate, old_dose):
    x, s, c, k, n = model.local(meta, pred, item["profile"])
    x, s, c = (torch.from_numpy(v) for v in (x, s, c))
    policies = {key: gain(net, x, s, c, norm) for key, (net, norm) in nets.items()}
    prior, norm = prior_gate
    raw = ((x - norm["mean"]) / norm["sd"]).clamp(-6, 6)
    policies["prior_local"] = prior(
        raw, c, torch.zeros((*x.shape[:-1], 40), dtype=x.dtype)
    ) * torch.tensor(old_dose)
    corrections = {key: deltas(k, g) for key, g in policies.items()}
    return corrections, n, policies


def fixed_heuristic(d, p, r, parameters):
    atlas = fixed.score.signatures(d, r)
    return fixed.synthesis(p["nominal"], *fixed.ingredients(p, d), atlas, parameters)


def readout(case, nets, old, cases):
    item, d, p, bind = case
    candidates, neutral, g = apply(d, p, item, nets, old, cases.old_dose)
    if cases.group == "held":
        x, s, c, proposals, _ = model.local(d, p, item["profile"])
        x, s, c = (torch.from_numpy(v) for v in (x, s, c))
        net, norm = nets["signed-response"]
        moved = s.roll((s.shape[-3] // 2, s.shape[-2] // 2), dims=(-3, -2))
        with torch.no_grad():
            shifted = gain(net, x, moved, c, norm)
        candidates["rolled signed"] = deltas(proposals, shifted)
        g["rolled signed"] = shifted
    luma = model.old.luma(p["nominal"], d)
    nil = np.zeros_like(luma)
    candidates["nominal"] = np.stack((nil, nil), axis=1)
    older = fixed_heuristic(d, p, item, cases.heuristic)
    candidates["heuristic"] = np.stack((model.old.luma(older, d) - luma, nil), axis=1)
    if "v120" in p:
        candidates["v120"] = np.stack((model.old.luma(p["v120"], d) - luma, nil), axis=1)
    gt, anchor = [score.stats(x, d) for x in (d["target"], p["nominal"])]
    terms = {
        k: fixed.terms(gt, anchor, fixed.coefficients(v[:, 0]), fixed.coefficients(v[:, 1]))
        for k, v in candidates.items()
    }
    return {
        "id": item["id"],
        "scores": terms,
        "model": bind,
        "mean_gains": {k: v.mean((1, 2)).tolist() for k, v in g.items()},
    }


def lock(rows):
    anchor = score.evaluate(previous_values(rows, "nominal", (1, 1)))
    audit = {}
    for arm in ARMS:
        values = []
        for dose in product((0.0, 0.125, 0.25, 0.5, 0.75, 1.0), repeat=2):
            q = score.evaluate(previous_values(rows, arm, dose))
            values.append(
                {
                    "dose": dose,
                    "scores": q,
                    "valid": all(q[k] - anchor[k] <= t for k, t in score.LIMITS.items()),
                }
            )
        selected = max(
            (v for v in values if v["valid"]),
            key=lambda r: (r["scores"]["response_pp"], -r["scores"]["increment"]),
        )
        audit[arm] = {"locked": selected, "alternatives": values}
    return {"limits": score.LIMITS, "arms": audit, "nominal": anchor}


def summarize(rows, policy):
    labels = {k: (k, (1, 1)) for k in rows[0]["scores"]}
    for arm, r in policy["arms"].items():
        labels[arm + " locked"] = (arm, r["locked"]["dose"])
    if "rolled signed" in labels:
        labels["rolled signed"] = (
            "rolled signed",
            policy["arms"]["signed-response"]["locked"]["dose"],
        )
    vals = {k: previous_values(rows, *a) for k, a in labels.items()}
    table = {k: score.evaluate(q) for k, q in vals.items()}
    # A matched-response comparison uses one common retrospective scale for the earlier rule.
    finish = table["signed-response locked"]["response_pp"]
    base = table["nominal"]["response_pp"]
    older = table["heuristic"]["response_pp"]
    controls = {}
    factor = (finish - base) / (older - base) if older > base else -1
    if 0 <= factor <= 1:
        key = "equal-response heuristic"
        vals[key] = previous_values(rows, "heuristic", (factor, factor))
        table[key] = score.evaluate(vals[key])
        controls[key] = (factor, factor)
    n = len(rows)
    rng = np.random.default_rng(202611200913)
    resample = np.vstack((np.arange(n), rng.integers(n, size=(12000, n))))

    def stats(a):
        return {k: np.sqrt(np.mean(a[k][resample] ** 2, axis=1)) for k in score.LIMITS} | {
            "response_pp": 100
            * a["projection"][resample].sum(axis=1)
            / a["true"][resample].sum(axis=1)
        }

    curves = {k: stats(q) for k, q in vals.items()}
    details = {}
    for ref in (
        "nominal",
        "heuristic",
        "prior_local",
        "error locked",
        "response locked",
        "signed-response locked",
    ):
        details[ref] = {
            k: {
                m: [float(d[0]), *np.quantile(d[1:], (0.025, 0.975)).tolist()]
                for m in stats_
                if (d := stats_[m] - curves[ref][m]) is not None
            }
            for k, stats_ in curves.items()
        }
    return {"scores": table, "comparisons": details, "retro": controls}


def main(group):
    torch.set_num_threads(2)
    study = Cases(group)
    bind, nets, earlier = weights()
    tic = monotonic()
    rows = []
    for subject in study:
        rows.append(readout(subject, nets, earlier, study))
        if len(rows) % 8 == 0:
            print(group, len(rows), flush=True)
    prior = reference(OUT / "evaluated-calibration.json") if group != "calibration" else None
    policy = read_json(checked(prior))["policy"] if prior else lock(rows)
    results = summarize(rows, policy)
    for key, r in results["scores"].items():
        print(key, r, flush=True)
    write_json(
        OUT / f"evaluated-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "fit": bind,
            "source": study.source,
            "calibration": prior,
            "heuristic": study.prior,
            "v120": study.v120,
            "rows": rows,
            "policy": policy,
            "summary": results,
            "seconds": monotonic() - tic,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
