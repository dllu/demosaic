"""Resolve cache names relative to the validation manifest that owns them."""

from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import collect_direct as source


if __name__ == "__main__":
    plan = reference(source.OUT / "held/plan.json")
    frozen = read_json(checked(plan))
    owner = checked(frozen["source_manifest"]).parent
    acquire = source.acquire
    assert Path(frozen["samples"][0]["cache"]).is_absolute() is False
    assert not (source.OUT / "held/completed.json").exists()
    assert not list((source.OUT / "held").glob("direct-*.npz"))

    def run(row, index, held):
        path = owner / row["cache"]
        data, noise, meta = acquire(row | {"cache": str(path)}, index, held)
        return data, noise, meta | {"source": row, "physical_cache": reference(path)}

    with patch.object(source, "acquire", run):
        source.run("held")
    write_json(
        source.OUT / "held/cache-resolution.json",
        {
            "driver": reference(Path(__file__)),
            "plan": plan,
            "owner": str(owner),
            "completed": reference(source.OUT / "held/completed.json"),
            "scope": "Validation manifest cache paths are relative to the source manifest.",
        },
    )
