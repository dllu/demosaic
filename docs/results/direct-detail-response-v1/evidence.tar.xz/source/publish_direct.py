"""Publish trained response endpoints and matched quality evidence."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from direct_detail import OUT, HERE

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "preflight/plan",
    "preflight/completed",
    "fit-preflight/result",
    "audit",
    "training/plan",
    "training/completed",
    "fit-training/result",
    "held/plan",
    "held/completed",
    "held/cache-resolution",
    "held-v120",
    "source-audit",
    "source-coverage",
    "evaluated-calibration",
    "evaluated-held",
    "evaluated-transfer",
    "sensitivity",
    "review-exact",
    "review-camera",
    "review-wires",
    "faint-recapture/plan",
    "faint-recapture/completed",
    "evaluated-faint",
    "review-faint",
    "matched-faint",
)


def bind(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def figure(data):
    names = {
        "nominal": ("Local 50k", "#333333", "s"),
        "v120": ("V120 Small", "#aa3377", "d"),
        "heuristic": ("Earlier Bayer gate", "#555555", "v"),
        "prior_local": ("Earlier learned local", "#777777", "x"),
        "error locked": ("Risk loss", "#4477aa", "o"),
        "response locked": ("Response loss", "#ee7733", "o"),
        "signed-error locked": ("Risk + signed features", "#882255", "o"),
        "signed-response locked": ("Response + signed features", "#228833", "o"),
        "rolled signed": ("Rolled signed features", "#33bbee", "+"),
    }
    f, axes = plt.subplots(1, 2, figsize=(10.8, 4.2), layout="constrained")
    x = data["nominal"]
    for axis, m, title in zip(
        axes, ("increment", "flat"), ("Weak increment", "Exact-flat region"), strict=True
    ):
        axis.axhline(0, color="#999", linestyle=":", linewidth=1)
        axis.axvline(0, color="#999", linestyle=":", linewidth=1)
        for name, (label, color, marker) in names.items():
            q = data[name]
            axis.scatter(
                q[m] - x[m],
                q["response_pp"] - x["response_pp"],
                label=label,
                c=color,
                marker=marker,
                s=45,
            )
        axis.set_xlabel("RMS change from Local 50k (DN16)")
        axis.set_title(title)
    axes[0].set_ylabel("Fine-response change (percentage points)")
    axes[1].legend(loc="best", frameon=False, fontsize=8)
    file = ASSETS / "response-error.png"
    f.savefig(file, dpi=165)
    return bind(file)


def tile(ref):
    src = checked(ref["image"])
    out = ASSETS / src.name
    shutil.copyfile(src, out)
    obj = bind(out)
    assert obj["sha256"] == ref["image"]["sha256"]
    with Image.open(out) as a:
        for k in ref["panels"]:
            x, y, w, h = k["png_xywh"]
            assert w == h == 160 and a.width >= x + w and a.height >= y + h
    return ref | {"image": obj}


def audit(verify, refs):
    bound = verify["training/completed"]
    plan = verify["training/plan"]
    assert (
        len(plan["samples"]) == bound["processed"] == 768 and bound["plan"] == refs["training/plan"]
    )
    assert len(verify["held/completed"]["rows"]) == 48
    assert verify["held/completed"]["plan"] == refs["held/plan"]
    assert verify["held-v120"]["source"] == refs["held/completed"]
    assert verify["held/cache-resolution"]["completed"] == refs["held/completed"]
    assert verify["held/cache-resolution"]["plan"] == refs["held/plan"]
    assert verify["fit-training/result"]["collection"] == refs["training/completed"]
    assert verify["fit-training/result"]["source_count"] == 768
    assert verify["fit-training/result"]["prior_head"] == plan["prior_head"]
    assert verify["source-audit"]["training"] == refs["training/plan"]
    assert verify["source-audit"]["held"] == refs["held/plan"]
    coeff = []
    stamps = {}
    for i, p in enumerate(bound["stats"]):
        row = read_json(checked(p))
        checked(row["data"])
        coeff.extend(row["samples"])
        stamps[f"training/statistics-{i:02}.json"] = p
    assert len(coeff) == len({r["source"] for r in coeff}) == len(plan["samples"])
    for expected, actual in zip(plan["samples"], coeff, strict=True):
        assert (
            expected["id"] == actual["source"]
            and expected["cache_sha256"] == actual["cache_sha256"]
        )
        assert actual["observed"]["shape"] == [3, 4, 128, 128] and actual["target"]["shape"] == [
            3,
            3,
            256,
            256,
        ]
    for raw, v120, p in zip(
        verify["held/completed"]["rows"],
        verify["held-v120"]["rows"],
        verify["held/plan"]["samples"],
        strict=True,
    ):
        assert raw["id"] == v120["id"] and raw["panel"] == v120["input"]
        assert raw["source"] == p
        assert raw["physical_cache"]["sha256"] == p["cache_sha256"]
        checked(raw["panel"])
        checked(v120["output"])
    checked(plan["parent"])
    checked(plan["prior_head"])
    for method, p in verify["fit-training/result"]["checkpoints"].items():
        stamps[f"checkpoints/{method}.pt"] = p
        checked(p)
    return stamps


def main():
    refs = {k: reference(OUT / f"{k}.json") for k in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in refs.items()}
    for r in data.values():
        for name in ("driver", "operator"):
            if name in r:
                checked(r[name])
    book = audit(data, refs)
    cal = refs["evaluated-calibration"]
    for k in ("held", "transfer"):
        assert data[f"evaluated-{k}"]["calibration"] == cal
    for name in (
        "evaluated-calibration",
        "evaluated-held",
        "evaluated-transfer",
        "review-exact",
        "review-camera",
        "review-wires",
    ):
        assert data[name]["fit"] == refs["fit-training/result"]
    for name in ("review-exact", "review-camera", "review-wires"):
        assert data[name]["lock"] == cal
    assert (
        data["sensitivity"]["source"]
        == data["review-exact"]["report"]["evaluation"]
        == refs["evaluated-held"]
    )
    assert data["sensitivity"]["coverage"] == refs["source-coverage"]
    assert data["evaluated-faint"]["calibration"] == data["review-faint"]["lock"] == cal
    assert (
        data["evaluated-faint"]["fit"] == data["review-faint"]["fit"] == refs["fit-training/result"]
    )
    assert (
        data["review-faint"]["report"]["evaluation"]
        == data["matched-faint"]["source"]
        == refs["evaluated-faint"]
    )
    assert data["evaluated-faint"]["source"] == refs["faint-recapture/completed"]
    assert data["faint-recapture/plan"]["locked_calibration"] == cal
    assert data["faint-recapture/completed"]["plan"] == refs["faint-recapture/plan"]
    broad = {r["id"]: r for r in data["held/completed"]["rows"]}
    special = data["faint-recapture/completed"]["rows"]
    assert len(special) == 40
    for r in special:
        assert r["broad_panel"] == broad[r["id"]]["panel"]
        assert r["box"] == broad[r["id"]]["box"] and r["camera"] == broad[r["id"]]["camera"]
        checked(r["panel"])

    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    photo = data["review-faint"]["report"]["rows"]
    camera = data["review-camera"]["report"]["rows"]
    assert len(photo) == 2 and len(camera) == 8 and sum(len(v["native"]) for v in camera) == 12
    for r in photo:
        r["frames"] = {k: tile(p) for k, p in r["frames"].items()}
    for r in camera:
        for v in r["native"]:
            labels = {t["label"] for t in v["panels"]}
            assert "ISO100 AHD reference" in labels
            if r["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= labels
        r["native"] = [tile(p) for p in r["native"]]
    plot = figure(data["evaluated-faint"]["summary"]["scores"])
    new = RESULTS / "summary.json"
    weights = data["fit-training/result"]["checkpoints"]
    write_json(
        new,
        {
            "training": data["fit-training/result"],
            "raw_preparation_seconds": data["training/completed"]["seconds"],
            "audit": data["audit"],
            "source_coverage": data["source-coverage"],
            "locks": data["evaluated-calibration"]["policy"],
            "held": data["evaluated-held"]["summary"],
            "faint": data["evaluated-faint"]["summary"],
            "matched_faint": data["matched-faint"],
            "continuity": data["evaluated-transfer"]["summary"],
            "wire": data["review-wires"]["report"]["scores"],
            "subsets": data["sensitivity"]["panels"],
            "camera": {r["id"]: r["difference_DN16"] for r in camera},
        },
    )
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {
            "weights": weights,
            "parent": data["training/plan"]["parent"],
            "v120": data["held-v120"]["checkpoint"],
            "photo": photo,
            "camera": camera,
            "plot": plot,
        },
    )

    book.update({f"receipts/{k}.json": v for k, v in refs.items()})
    book.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    book["source/finish_direct.sh"] = reference(HERE / "finish_direct.sh")
    book["source/complete_held.sh"] = reference(HERE / "complete_held.sh")
    for name in (
        "detail_selector.py",
        "collect_training.py",
        "benchmark_shared_local_encoding.py",
        "review_selector.py",
        "evaluate_selector.py",
    ):
        book[f"prior/{name}"] = reference(HERE.with_name("scene-detail-selector-v1") / name)
    for name in ("capture.py", "context_gate.py", "mild_score.py", "score.py"):
        book[f"prior/heuristic/{name}"] = reference(
            HERE.with_name("context-conditioned-detail-v1") / name
        )
    book["prior/prepare_eval.py"] = reference(
        HERE.with_name("scene-local-contrast-2400-v1") / "prepare_eval.py"
    )
    for file in (
        "src/demosaic/scene_data.py",
        "src/demosaic/scene_training_data.py",
        "configs/gfx-qualitative-20231231.json",
        "configs/gfx-green-mesh-20231231.json",
    ):
        book[f"repo/{file}"] = reference(ROOT / file)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for path, v in book.items():
            tar.add(checked(v), arcname=path, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == book.keys()
        for k, v in book.items():
            with tar.extractfile(k) as g:
                assert file_digest(g, "sha256").hexdigest() == v["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "members": book,
            "archive": bind(archive),
            "native": bind(manifest),
            "summary": bind(new),
            "weights": weights,
            "scope": "Trained direct fine-detail component and fixed RAW quality study",
        },
    )
    print(bind(archive), flush=True)


if __name__ == "__main__":
    main()
