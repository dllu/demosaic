"""Verify overlap with the fixed photo panel and count terminal observations."""

from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_direct import OUT


if __name__ == "__main__":
    first = reference(OUT / "source-audit.json")
    old = read_json(checked(first))
    benchmark = read_json(checked(old["full427"]))
    assert len(benchmark["source_ids"]) == 427
    latest = read_json(checked(old["held"]))
    hashes = {r["id"] for r in latest["samples"]}
    overlap = sorted(hashes.intersection(benchmark["source_ids"]))
    write_json(
        OUT / "source-coverage.json",
        {
            "driver": reference(Path(__file__)),
            "source_audit": first,
            "full427_ids": len(benchmark["source_ids"]),
            "full427_overlapping_ids": overlap,
            "local_terminal_logged_observations": old["local_terminal_logged_updates"],
            "scope": "Explicit fixed-panel IDs and interpretation of the terminal observation-count field.",
        },
    )
    print("Overlapping fixed benchmarks:", len(overlap))
