"""Run the recommended V120 EMA on the same new Bayer panel."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from collect_direct import OUT, batch

CONFIG = Path("configs/current-model.json")


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    config = reference(CONFIG)
    binding = read_json(checked(config))["checkpoint"]
    assert binding["sha256"] == "a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb"
    net, state = load_checkpoint(checked(binding), "cuda", tiled_inference=True)
    assert state["loaded_sha256"] == binding["sha256"] and "ema" in state
    net = net.eval().to(memory_format=torch.channels_last)
    del state
    cases = reference(OUT / "held/completed.json")
    rows = read_json(checked(cases))["rows"]
    room = OUT / "v120"
    room.mkdir(exist_ok=True)
    stamps = []
    since = monotonic()
    with ieee_fp32():
        for row in rows:
            f = room / f"{row['id']}.npy"
            if not f.is_file():
                with np.load(checked(row["panel"]), allow_pickle=False) as data:
                    a = batch(
                        {k: data[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
                    )
                profile = row["profile"]
                net.set_noise(profile["shot"], profile["read"])
                output = (
                    net(
                        a["packed"].contiguous(memory_format=torch.channels_last),
                        a["variance"].contiguous(memory_format=torch.channels_last),
                        a["colors"],
                        a["wb"],
                        a["matrix"],
                    )
                    .cpu()
                    .numpy()
                )
                assert output.shape == (3, 3, 256, 256) and np.isfinite(output).all()
                temporary = f.with_suffix(".partial")
                with temporary.open("wb") as stream:
                    np.save(stream, output, allow_pickle=False)
                temporary.replace(f)
            stamps.append({"id": row["id"], "input": row["panel"], "output": reference(f)})
    write_json(
        OUT / "held-v120.json",
        {
            "driver": reference(Path(__file__)),
            "source": cases,
            "recommendation": config,
            "checkpoint": binding,
            "policy": "CUDA IEEE FP32 EMA",
            "seconds": monotonic() - since,
            "rows": stamps,
        },
    )


if __name__ == "__main__":
    run()
