"""Fit a factorial comparison of direct response loss and signed Bayer features."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import direct_detail as model

OUT = model.OUT
UPDATES = 1400
BATCH = 48
LR = 5e-4
EMA = 0.993
SEED = 202611200913


def observations(source):
    info = read_json(checked(source))
    rows = []
    for ref in info["stats"]:
        stem = read_json(checked(ref))
        with np.load(checked(stem["data"]), allow_pickle=False) as data:
            rows.append({k: data[k] for k in data.files})
    return {k: torch.from_numpy(np.concatenate([r[k] for r in rows])).cuda() for k in rows[0]}


def normalize(a, params):
    return ((a - params["mean"]) / params["sd"]).clamp(-6, 6)


def gain(net, v, s, mask, normal):
    return net(normalize(v, normal["base"]), normalize(s, normal["signed"]), mask)


def reg(val, b, m):
    return 2 * (val * b).sum(-1) + torch.einsum("...i,...ij,...j->...", val, m, val)


def objective(v, d, pull):
    f = model.flatten(v)
    p = f[:, :2, :].reshape(len(v), 64)
    relative = reg(f, d["linear"], d["gram"]) / (d["role_energy"] + 36**2)
    pair = (reg(p, d["pair_linear"], d["pair_gram"]) - 2 * pull * (p * d["signal"]).sum(-1)) / (
        d["pair_energy"] + 48**2
    )
    quiet = (relative[:, 2] + 0.3 * relative[:, 2].relu()).mean()
    return 0.60 * relative[:, 0].mean() + 0.25 * relative[:, 1].mean() + 1.7 * quiet + pair.mean()


def fit(run):
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    root = OUT / f"fit-{run}"
    root.mkdir(exist_ok=True)
    files = reference(OUT / run / "completed.json")
    prior = read_json(checked(read_json(checked(files))["plan"]))["prior_head"]
    old = torch.load(checked(prior), map_location="cpu", weights_only=True)
    data = observations(files)
    local = {k: v.cuda() for k, v in old["normalization"]["local"].items()}
    z = data["signed"]
    dims = tuple(range(z.ndim - 1))
    normal = {
        "base": local,
        "signed": {"mean": z.mean(dims), "sd": z.std(dims, unbiased=False).clamp_min(0.05)},
    }
    nets = {}
    avg = {}
    for method in model.NAMES:
        extra = method.startswith("signed")
        net = model.Head(extra)
        net.startup(old["ema"])
        nets[method] = net.cuda()
        peer = model.Head(extra).cuda()
        peer.load_state_dict(net.state_dict())
        avg[method] = peer.requires_grad_(False)
    test = {k: v[:2] for k, v in data.items()}
    existing = model.old.Selector().cuda()
    existing.load_state_dict(old["ema"])
    with torch.no_grad():
        x = normalize(test["base"], local)
        target = existing(x, test["support"], torch.zeros((*x.shape[:-1], 40), device=x.device))
        for t in nets.values():
            torch.testing.assert_close(
                gain(t, test["base"], test["signed"], test["support"], normal),
                target,
                atol=5e-7,
                rtol=0,
            )
    optim = {
        k: torch.optim.AdamW(n.parameters(), lr=LR, weight_decay=1e-4) for k, n in nets.items()
    }
    samples = len(data["base"])
    draws = min(samples, BATCH)
    steps = 5 if run == "preflight" else UPDATES
    generator = torch.Generator().manual_seed(SEED)
    log = {k: [] for k in nets}
    time = monotonic()
    for i in range(1, steps + 1):
        selection = torch.randint(samples, (draws,), generator=generator).cuda()
        piece = {k: v[selection] for k, v in data.items()}
        for name, net in nets.items():
            optim[name].zero_grad(set_to_none=True)
            out = gain(net, piece["base"], piece["signed"], piece["support"], normal)
            tilt = model.RESP_PULL if name.endswith("response") else 0.0
            loss = objective(out, piece, tilt)
            assert torch.isfinite(loss)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1)
            optim[name].step()
            with torch.no_grad():
                torch._foreach_lerp_(list(avg[name].parameters()), list(net.parameters()), 1 - EMA)
            if i in (1, steps) or i % 100 == 0:
                log[name].append(
                    {
                        "step": i,
                        "loss": loss.item(),
                        "gain": out.detach().mean((0, 1, 2, 3)).tolist(),
                    }
                )
        if i in (1, steps) or i % 100 == 0:
            print(
                run,
                i,
                round(monotonic() - time, 2),
                {k: z[-1]["loss"] for k, z in log.items()},
                flush=True,
            )
    weights = {}
    for name in nets:
        dst = root / f"{name}.pt"
        tmp = dst.with_suffix(".partial")
        torch.save(
            {
                "raw": {k: v.cpu() for k, v in nets[name].state_dict().items()},
                "ema": {k: v.cpu() for k, v in avg[name].state_dict().items()},
                "normal": {k: {y: v.cpu() for y, v in p.items()} for k, p in normal.items()},
                "optimizer": optim[name].state_dict(),
                "updates": steps,
                "source": files,
                "prior_head": prior,
                "mode": name,
                "with_signed": nets[name].with_signed,
                "rng": generator.get_state(),
            },
            tmp,
        )
        tmp.replace(dst)
        weights[name] = reference(dst)
        raw = torch.load(checked(weights[name]), weights_only=True, map_location="cpu")
        assert raw["updates"] == steps
        for key, w in avg[name].state_dict().items():
            torch.testing.assert_close(w.cpu(), raw["ema"][key], rtol=0, atol=0)
    write_json(
        root / "result.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "collection": files,
            "prior_head": prior,
            "updates": steps,
            "batch": draws,
            "source_count": samples,
            "unique_role_examples": 3 * samples,
            "role_visits_per_arm": 3 * steps * draws,
            "learning_rate": LR,
            "ema_decay": EMA,
            "checkpoints": weights,
            "logs": log,
            "seconds": monotonic() - time,
            "response_weight": model.RESP_PULL,
        },
    )


if __name__ == "__main__":
    fit(sys.argv[1])
