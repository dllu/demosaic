"""Compare learned gains at equal contrast and show the measured error frontier."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_direct import OUT, previous_values, score


if __name__ == "__main__":
    source = reference(OUT / "evaluated-faint.json")
    data = read_json(checked(source))
    obs = data["rows"]
    base = data["summary"]["scores"]["nominal"]
    methods = {
        "heuristic": ("heuristic", (1, 1)),
        "signed-response": (
            "signed-response",
            data["policy"]["arms"]["signed-response"]["locked"]["dose"],
        ),
        "rolled signed": (
            "rolled signed",
            data["policy"]["arms"]["signed-response"]["locked"]["dose"],
        ),
    }
    full = {k: score.evaluate(previous_values(obs, *v)) for k, v in methods.items()}
    target = full["heuristic"]["response_pp"] - base["response_pp"]
    raw = {}
    feasible = {}
    for k, (method, scale) in methods.items():
        gain = full[k]["response_pp"] - base["response_pp"]
        blend = target / gain
        sample = lambda t: previous_values(obs, method, (t * scale[0], t * scale[1]))
        assert 0 <= blend <= 1
        raw[k] = sample(blend)
        trials = []
        for t in np.linspace(0, 1, 101):
            record = score.evaluate(sample(t))
            if all(record[m] <= base[m] + v for m, v in score.LIMITS.items()):
                trials.append((t, record))
        feasible[k] = max(trials, key=lambda q: q[1]["response_pp"])
    n = len(obs)
    rng = np.random.default_rng(202611200923)
    draws = np.vstack((np.arange(n), rng.integers(n, size=(12000, n))))
    rms = {
        k: {m: np.sqrt(np.mean(v[m][draws] ** 2, axis=-1)) for m in score.LIMITS}
        for k, v in raw.items()
    }
    contrasts = {}
    for other, vals in rms.items():
        curves = {m: rms["signed-response"][m] - z for m, z in vals.items()}
        contrasts[other] = {
            m: [float(d[0]), *np.quantile(d[1:], (0.025, 0.975)).tolist()]
            for m, d in curves.items()
        }
    print(contrasts, feasible, flush=True)
    write_json(
        OUT / "matched-faint.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "matched_response_pp": full["heuristic"]["response_pp"],
            "contrast": contrasts,
            "scores": {k: score.evaluate(v) for k, v in raw.items()},
            "retrospective_feasible": feasible,
            "scope": "Strength matching using the measured recapture; diagnostic comparisons only.",
        },
    )
