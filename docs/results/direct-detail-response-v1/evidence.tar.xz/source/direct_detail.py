"""Use exact delivered fine-band risk and signed response to fit a bounded gate."""

from functools import cache
from pathlib import Path
import sys

import numpy as np
from scipy.fft import dctn
from scipy.ndimage import gaussian_filter
import torch
from torch import nn

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("scene-detail-selector-v1")))
import detail_selector as old

NAMES = ("error", "response", "signed-error", "signed-response")
RESP_PULL = 0.65
CENTER = np.s_[..., 80:176, 80:176]
STATIONS = np.s_[..., 2:6, 2:6, :]
DIM = 8
CODE = 32

axis = np.arange(16) / 32
radii = np.hypot(axis[:, None], axis)
BAND = (radii >= 1 / 8) & (radii < 1 / 3)


def fine(core):
    pieces = old.block_pixels(core, 16)
    return dctn(pieces, axes=(-2, -1), norm="ortho")[..., BAND].reshape(*core.shape[:-2], -1)


@cache
def windows():
    # Only these 16 stations have a nonzero bilinear footprint in the 96px scored core.
    grids = torch.nn.functional.pad(torch.eye(16).reshape(1, 16, 4, 4), (2, 2, 2, 2))
    pixel = torch.nn.functional.interpolate(
        grids, size=(256, 256), mode="bilinear", align_corners=False
    )
    return pixel.numpy()[CENTER][0].astype(float)


def signed_raw(meta, pred, fields, neutral, profile):
    raw = meta["packed"]
    colors = meta["colors"]
    r = []
    for phase in np.flatnonzero(colors == 1):
        i, j = divmod(int(phase), 2)
        observed = raw[:, phase].astype(float)
        fits = pred["nominal"][:, 1, i::2, j::2].astype(float)
        innovation = observed - fits
        bpf = lambda x: gaussian_filter(x, (0, 0.85, 0.85)) - gaussian_filter(x, (0, 2.25, 2.25))
        scaled = bpf(innovation)
        emitted = fields[..., i::2, j::2] * neutral[1]
        scale = np.sqrt(
            np.maximum(
                2e-11,
                profile["shot"] * old.block_pixels(observed, 16).mean(axis=(-2, -1)).clip(0)
                + profile["read"],
            )
        )
        a, c, u = [old.block_pixels(x, 16) for x in (scaled, emitted, bpf(fits))]
        power = np.sqrt(np.mean(c * c, axis=(-2, -1)))
        sensor = (c * a[:, None]).mean(axis=(-2, -1)) / np.maximum(1e-10, power * scale[:, None])
        image = (c * u[:, None]).mean(axis=(-2, -1)) / np.maximum(1e-10, power * scale[:, None])
        r.append((sensor, image))
    # The two green phases remain separate, in native Bayer order.
    return np.concatenate([z for pair in r for z in pair], axis=1).transpose(0, 2, 3, 1)


def local(meta, pred, profile):
    base, items, neutral = old.ingredients(pred, meta)
    raw, support = old.local_features(meta["packed"], base, items, meta["colors"], profile)
    signs = signed_raw(meta, pred, items, neutral, profile).astype(np.float32)
    return raw, signs, support, items, neutral


def stats(meta, pred, profile):
    x, signed, cap, field, _ = local(meta, pred, profile)
    src = old.luma(pred["nominal"], meta)
    truth = old.luma(meta["target"], meta)
    f = 65535 / 96
    e = fine((src - truth)[CENTER]) * f
    td = fine((truth[0] - truth[1])[CENTER]) * f
    dims = field.shape[0]
    assert dims == 3
    d = fine((field[CENTER][:, :, None] * windows()).reshape(dims, 32, 96, 96)) * f
    q = d @ d.transpose(0, 2, 1)
    linear = (d @ e[..., None])[..., 0]
    p = np.concatenate((d[0], -d[1]), axis=0)
    pp = e[0] - e[1]
    gains = p @ td
    payload = {
        "base": x[STATIONS],
        "signed": signed[STATIONS],
        "support": cap[:, 2:6, 2:6],
        "gram": q,
        "linear": linear,
        "role_energy": np.sum(e * e, axis=1),
        "pair_gram": p @ p.T,
        "pair_linear": p @ pp,
        "pair_energy": pp @ pp,
        "signal": gains,
        "truth_energy": td @ td,
    }
    return {k: np.asarray(v, dtype=np.float32) for k, v in payload.items()}


class Head(nn.Module):
    def __init__(self, with_signed):
        super().__init__()
        self.with_signed = with_signed
        self.net = nn.Sequential(
            nn.Linear(11 + (DIM if with_signed else 0), 32),
            nn.SiLU(),
            nn.Linear(32, 16),
            nn.SiLU(),
            nn.Linear(16, 2),
        )

    def forward(self, x, signed, support):
        if self.with_signed:
            x = torch.cat((x, signed), dim=-1)
        result = self.net(x).sigmoid()
        return result * torch.stack((support, torch.ones_like(support)), dim=-1)

    def startup(self, weights):
        tensors = {key.removeprefix("network."): t for key, t in weights.items()}
        self.net.load_state_dict(
            tensors
            | {
                "0.weight": torch.nn.functional.pad(
                    tensors["0.weight"][:, :11], (0, DIM if self.with_signed else 0)
                )
            }
        )


def flatten(gates):
    shape = gates.shape
    return gates.transpose(-1, -3).transpose(-1, -2).reshape(*shape[:-3], 32)
