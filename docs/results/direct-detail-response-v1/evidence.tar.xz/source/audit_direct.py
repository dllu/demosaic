"""Check that the training loss measures the delivered pixels and the signed contrast."""

from pathlib import Path

import numpy as np
import torch
from torch.nn.functional import interpolate

from demosaic.experiments.artifacts import reference, write_json
import direct_detail as model
from evaluate_direct import Cases, weights, readout
from train_direct import reg


if __name__ == "__main__":
    torch.set_num_threads(2)
    rng = np.random.default_rng(202611200900)
    case = Cases("calibration")
    item, d, p, b = next(iter(case))
    raw, signed, c, fields, neutral = model.local(d, p, item["profile"])
    t = model.stats(d, p, item["profile"])
    altered = d | {"packed": d["packed"].copy()}
    rg = np.flatnonzero(d["colors"] != 1)
    altered["packed"][:, rg] = rng.uniform(0, 0.8, altered["packed"][:, rg].shape)
    again = model.signed_raw(altered, p, fields, neutral, item["profile"]).astype(np.float32)
    np.testing.assert_array_equal(again, signed)
    q = rng.uniform(0, 1, (3, 4, 4, 2)).astype(np.float32)
    q[..., 0] *= c[:, 2:6, 2:6]
    simple = model.flatten(torch.from_numpy(q))
    plane = np.zeros((3, 8, 8, 2), dtype=np.float32)
    plane[:, 2:6, 2:6] = q
    amp = interpolate(
        torch.from_numpy(plane).permute(0, 3, 1, 2),
        size=(256, 256),
        mode="bilinear",
        align_corners=False,
    ).numpy()
    rendered = (fields * amp).sum(axis=1)
    scalar = 65535 / 96
    truth = model.old.luma(d["target"], d)
    delta = model.fine((truth[0] - truth[1])[model.CENTER]) * scalar
    residual = model.old.luma(p["nominal"], d) - truth
    e = model.fine(residual[model.CENTER]) * scalar
    h = model.fine(rendered[model.CENTER]) * scalar
    hpair = h[0] - h[1]
    epair = e[0] - e[1]
    direct = np.r_[
        (2 * e * h + h * h).sum(axis=1), np.sum(2 * epair * hpair + hpair * hpair), hpair @ delta
    ]
    v = simple[:2].reshape(64)
    rec = lambda x: torch.from_numpy(t[x])
    fit = np.r_[
        reg(simple, rec("linear"), rec("gram")).numpy(),
        reg(v, rec("pair_linear"), rec("pair_gram")).item(),
        (v * rec("signal")).sum().item(),
    ]
    np.testing.assert_allclose(fit, direct, rtol=4e-6, atol=1e-4)
    bind, models, prior = weights("preflight")
    note = readout((item, d, p, b), models, prior, case)
    assert np.isfinite(note["scores"]["signed-response"]["flat"]).all()
    msg = {
        "driver": reference(Path(__file__)),
        "preflight": bind,
        "inputs": case.source,
        "example": item["id"],
        "direct_values": direct.tolist(),
        "quadratic_values": fit.tolist(),
        "maximum_absolute_difference": float(abs(direct - fit).max()),
        "red_blue_perturbation_invariant": True,
    }
    write_json(model.OUT / "audit.json", msg)
    print(msg, flush=True)
