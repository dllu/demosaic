#!/bin/bash
set -euo pipefail

pid=$1
code=.cache/experiments/direct-detail-response-v1
study=/mnt/external/demosaic/direct-detail-response-v1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 PYTHONPATH=scripts
test "$(tr '\0' ' ' < /proc/"$pid"/cmdline)" = ".venv/bin/python $code/replay_held_cache_paths.py "
while kill -0 "$pid" 2>/dev/null; do sleep 3; done
test -s "$study/held/completed.json" && test -s "$study/held/cache-resolution.json"
test -s "$study/evaluated-calibration.json"
.venv/bin/python "$code/capture_v120_comparator.py" > "$study/v120.log" 2>&1
.venv/bin/python "$code/evaluate_direct.py" held > "$study/held.log" 2>&1
.venv/bin/python "$code/sensitivity_direct.py" > "$study/sensitivity.log" 2>&1
.venv/bin/python "$code/evaluate_direct.py" transfer > "$study/retained.log" 2>&1
for mode in exact camera wires; do
  .venv/bin/python "$code/review_direct.py" "$mode" > "$study/review-$mode.log" 2>&1
done
