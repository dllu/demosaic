"""Check source IDs and cached pixels against the existing parent visit records."""

import json
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_direct import OUT, OLD

CORPUS = Path("docs/results/full-corpus-long100k-training-v1/source-audit.json")
LOCAL = Path("docs/results/scene-full-epoch-v1/local-050000-training.json")
FIXED = Path(".cache/experiments/full427-faint-adc-v1/cohort.json")


def matches(item, blocked):
    if isinstance(item, dict):
        return any(
            (
                k in ("id", "source_id", "commons_id", "cache_sha256", "sha1", "sha1_hex")
                and isinstance(v, str)
                and v in blocked
            )
            or matches(v, blocked)
            for k, v in item.items()
        )
    if isinstance(item, list):
        return any(matches(v, blocked) for v in item)
    return False


if __name__ == "__main__":
    new = reference(OUT / "training/plan.json")
    held = reference(OUT / "held/plan.json")
    p = read_json(checked(new))
    v = read_json(checked(held))
    old = read_json(checked(p["previous"]))

    def fingerprints(rows):
        return {x[k] for x in rows for k in ("id", "cache_sha256")}

    a, b, c = (fingerprints(x["samples"]) for x in (p, v, old))
    assert len(a) == 1536 and len(b) == 96 and len(c) == 3200
    assert a.isdisjoint(b) and a.isdisjoint(c) and b.isdisjoint(c)

    earlier = reference(CORPUS)
    info = read_json(checked(earlier))
    assert info["checkpoint"] == read_json(checked(reference(LOCAL)))["parent"]
    visited = 0
    for ref in info["source_traces"]:
        with checked(ref).open() as f:
            for row in map(json.loads, f):
                for sample in row["sources"]:
                    if sample["kind"] == "photographic":
                        assert not matches(sample, b), sample
                        visited += 1
    assert visited == 559808
    local = reference(LOCAL)
    deriv = read_json(checked(local))
    assert deriv["checkpoint"] == p["parent"]
    steps = 0
    for segment in deriv["segments"]:
        with checked(segment["observations"]).open() as f:
            for row in map(json.loads, f):
                assert not matches(row, b)
                steps += 1
    full = reference(FIXED)
    calibration = read_json(checked(full))
    num427 = sum(matches(x, b) for x in calibration.get("sources", calibration.get("cases", [])))
    write_json(
        OUT / "source-audit.json",
        {
            "driver": reference(Path(__file__)),
            "training": new,
            "held": held,
            "corpus_audit": earlier,
            "corpus_photo_visits": visited,
            "local_terminal": local,
            "local_terminal_logged_updates": steps,
            "full427": full,
            "full427_overlap_count": num427,
            "scope": "Photo IDs and cached pixel hashes. The Local 50k manifest and retained terminal traces are checked; the Corpus 100k traces cover the entire recorded training schedule.",
        },
    )
    print(visited, steps, num427, flush=True)
