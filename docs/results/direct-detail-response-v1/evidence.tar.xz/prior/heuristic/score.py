"""Calibrate the output tradeoff at fixed flat and fine-increment error."""

from pathlib import Path
import sys

import numpy as np
from scipy.fft import dctn
from scipy.ndimage import gaussian_filter
from scipy.special import expit

from capture import OUT
import context_gate as gate
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

GUIDES = ("constant", "local", "near", "whole", "permuted", "risk")
THRESHOLDS = {
    "constant": np.linspace(0, 1, 11).tolist(),
    "risk": [-1, -0.5, 0, 0.5, 1, 1.5, 2],
    **{k: [-1, 0, 0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 6] for k in GUIDES[1:-1]},
}
DOSES = (0.0, 0.125, 0.25, 0.5, 0.75, 1.0)
LUMA = np.array([0.2126, 0.7152, 0.0722])
CORE = np.s_[..., 80:176, 80:176]
SCALE = 65535**2 / 96**2
D = A = np.arange(16) / 32
F = np.hypot(D[:, None], D)
BANDS = {
    "lower": (F >= 1 / 32) & (F < 1 / 8),
    "fine": (F >= 1 / 8) & (F < 1 / 3),
    "upper": F >= 1 / 3,
}
LIMITS = {"flat": 0.05, "increment": 0.10, "present": 0.10}
WARMUP = False


def items(group):
    captures = reference(OUT / f"capture-{group}.json")
    summary = read_json(checked(captures))
    study = read_json(checked(summary["plan"]))
    for item, record in zip(study["groups"][group], summary["rows"], strict=True):
        assert item["id"] == record["id"] and item["input"] == record["input"]
        with np.load(checked(record["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        with np.load(checked(record["output"]), allow_pickle=False) as f:
            result = {k: f[k] for k in f.files}
        yield item, data, result, record["output"]


def luma(rgb, data):
    signal = (LUMA @ data["matrix"]) * data["wb"]
    return np.einsum("...chw,c->...hw", rgb, signal)


def stats(rgb, data):
    q = luma(rgb, data)[CORE]
    tiles = q.reshape(-1, 6, 16, 6, 16).transpose(0, 1, 3, 2, 4).reshape(-1, 36, 16, 16)
    return dctn(tiles, axes=(-2, -1), norm="ortho")


def parts(actual, target, move, *, flat=2, absent=1, bands=("fine",)):
    result = {}
    for name in bands:
        mask = BANDS[name]
        v, t, u = [a[..., mask] for a in (actual, target, move)]
        diff = v[0] - v[absent]
        shift = u[0] - u[absent]
        true = t[0] - t[absent]
        terms = lambda x, d: [float(np.sum(z) * SCALE) for z in (x**2, 2 * x * d, d**2)]
        result[name] = {
            "response": [float(np.sum(vv * true)) for vv in (diff, shift)],
            "true": float(np.sum(true**2)),
            "flat": terms(v[flat] - t[flat], u[flat]),
            "present": terms(v[0] - t[0], u[0]),
            "increment": terms(diff - true, shift),
        }
    return result


def signatures(data, item):
    x, y, w, h = item["box"]
    p = item["profile"]
    colors = data["colors"]
    context = gate.make_atlas(data["scene_packed"], colors, p["shot"], p["read"], (x, y, w, h))
    maps = [
        gate.guides(raw, colors, p["shot"], p["read"], (x, y), context) for raw in data["packed"]
    ]
    return {k: np.stack([v[k] for v in maps]) for k in maps[0]}


def risk_summaries(out, data):
    risk = {name: gate.risk(out, data, name) for name in ("crisp", "smooth")}
    difference = (risk["smooth"][0] + risk["smooth"][1].mean(0)) - (
        risk["crisp"][0] + risk["crisp"][1].mean(0)
    )
    # DN16² stabilization is fixed before looking at exact-target risk.
    score = np.arcsinh(difference / 1000.0)
    diagnosis = {}
    for name, (naive, derivative, true) in risk.items():
        # These averages are per-source and role. The 16 locations are used only to describe within-source behavior.
        choose = np.s_[..., 92:164:24, 92:164:24]
        sites = lambda a: a[choose].reshape(len(data["packed"]), -1)
        diagnosis[name] = {
            "naive": sites(naive).tolist(),
            "one": sites(naive + derivative[0]).tolist(),
            "two": sites(naive + derivative[1]).tolist(),
            "estimate": sites(naive + derivative.mean(0)).tolist(),
            "exact": sites(true).tolist(),
        }
    return score, diagnosis


def alpha(maps, family, threshold):
    return (
        threshold
        if family == "constant"
        else expit((maps[family] - threshold) * (2 if family == "risk" else 1))
    )


def delta(out, maps, family, threshold):
    q = alpha(maps, family, threshold)
    if not np.isscalar(q):
        q = q[:, None]
    return (out["crisp"] - out["nominal"]) * q + (out["smooth"] - out["nominal"]) * (1 - q)


def output(out, maps, family, threshold, dose):
    base = out["nominal"]
    if dose == 0:
        return base
    return (base + dose * delta(out, maps, family, threshold)).astype(base.dtype)


def collect(group):
    result = []
    for item, data, out, bind in items(group):
        maps = signatures(data, item)
        estimated, diagnosis = risk_summaries(out, data)
        maps["risk"] = estimated
        a, t = [stats(f, data) for f in (out["nominal"], data["target"])]
        fits = {}
        for family, levels in THRESHOLDS.items():
            arms = []
            for v in levels:
                shift = stats(delta(out, maps, family, v), data)
                arms.append(parts(a, t, shift))
            fits[family] = arms
        robust_fine = np.s_[..., 80:176, 80:176]
        approx = gate.bandpass(luma(out["nominal"], data) - luma(data["target"], data))
        direction = gate.bandpass(luma(out["crisp"] - out["nominal"], data))
        rms = lambda u: gaussian_filter(u, (0, 12, 12))
        fit = np.clip(-rms(approx * direction) / np.maximum(1e-12, rms(direction**2)), 0, 1)
        exact = (out["crisp"] - out["nominal"]) * fit[:, None]
        fits["oracle"] = [parts(a, t, stats(exact, data))]
        result.append(
            {
                "id": item["id"],
                "input": item["input"],
                "output": bind,
                "fits": fits,
                "risk": diagnosis,
                "scene_levels": {
                    k: np.mean(v[robust_fine], axis=(-2, -1)).tolist() for k, v in maps.items()
                },
            }
        )
        if len(result) % 8 == 0:
            print(group, len(result), flush=True)
    return result


def matrix(rows, family, index, dose, band="fine"):
    mat = [r["fits"][family][index][band] for r in rows]
    resp = np.asarray([d["response"] for d in mat])
    keys = {
        key: np.sqrt(
            np.maximum(0, np.asarray([r[key] for r in mat]) @ np.array([1, dose, dose * dose]))
        )
        for key in ("increment", "present", "flat")
    }
    return keys | {
        "projection": resp @ np.array([1, dose]),
        "true": np.asarray([r["true"] for r in mat]),
    }


def evaluate(fit):
    return {
        k: float(np.sqrt(np.mean(v**2))) for k, v in fit.items() if k not in ("projection", "true")
    } | {
        "response_pp": float(100 * fit["projection"].sum() / fit["true"].sum()),
        "flat_peak": float(fit["flat"].max()),
    }


def choose(rows):
    base = evaluate(matrix(rows, "constant", 0, 0))
    overview = {}
    for family, grid in THRESHOLDS.items():
        options = []
        for i, level in enumerate(grid):
            for dose in DOSES:
                actual = evaluate(matrix(rows, family, i, dose))
                eligible = all(actual[k] - base[k] <= v + 1e-8 for k, v in LIMITS.items())
                options.append(
                    {
                        "family": family,
                        "index": i,
                        "threshold": level,
                        "dose": dose,
                        "scores": actual,
                        "within": eligible,
                    }
                )
        pick = max(
            (v for v in options if v["within"]),
            key=lambda q: (q["scores"]["response_pp"], -q["scores"]["increment"], -q["dose"]),
        )
        overview[family] = {"tested": options, "chosen": pick}
        print(family, pick["threshold"], pick["dose"], pick["scores"], flush=True)
    return {"baseline": base, "limits": LIMITS, "trials": overview}


def scores(rows, selected):
    res = {}
    n = len(rows)
    rng = np.random.default_rng(202611200717)
    boot = np.vstack((np.arange(n), rng.integers(n, size=(10000, n))))
    paths = {
        "baseline": ("constant", 0, 0),
        "crisp": ("constant", 10, 1),
        "smooth": ("constant", 0, 1),
        "oracle": ("oracle", 0, 1),
    }
    paths.update(
        {
            k: (v["chosen"]["family"], v["chosen"]["index"], v["chosen"]["dose"])
            for k, v in selected["trials"].items()
        }
    )
    bs = {}
    for key, path in paths.items():
        f = matrix(rows, *path)
        bs[key] = {
            m: np.sqrt(np.mean(f[m][boot] ** 2, axis=1)) for m in ("increment", "present", "flat")
        } | {"response_pp": 100 * f["projection"][boot].sum(1) / f["true"][boot].sum(1)}
        res[key] = evaluate(f)
    contrast = {}
    for name, v in bs.items():
        for prior in ("baseline", "local"):
            terms = {m: v[m] - bs[prior][m] for m in v}
            contrast[f"{name} vs {prior}"] = {
                m: [float(a[0]), *np.quantile(a[1:], [0.025, 0.975]).tolist()]
                for m, a in terms.items()
            }
    return {"means": res, "paired": contrast}


def inspect(rows):
    supported = {}
    for k in ("crisp", "smooth"):
        by_role = {}
        for i, name in enumerate(("present", "attenuated", "flat")):
            fields = {
                m: np.array([r["risk"][k][m][i] for r in rows]).ravel() for m in rows[0]["risk"][k]
            }
            truth = fields["exact"]
            entries = {}
            for proxy in ("naive", "estimate"):
                y = fields[proxy]
                entries[proxy] = {
                    "bias_DN16_sq": float(np.mean(y - truth)),
                    "sign_agreement": float(np.mean((y > 0) == (truth > 0))),
                    "corr": float(np.corrcoef(y, truth)[0, 1]),
                }
            entries["exact_crisper_fraction"] = float(np.mean(truth < 0))
            entries["probe_agreement"] = float(np.corrcoef(fields["one"], fields["two"])[0, 1])
            by_role[name] = entries
        supported[k] = by_role
    return supported


if __name__ == "__main__":
    kind = sys.argv[1]
    receipts = {}
    record = {"driver": reference(Path(__file__)), "operator": reference(Path(gate.__file__))}
    for group in ("calibration", "transfer") if kind == "both" else (kind,):
        rows = collect(group)
        upstream = reference(OUT / f"capture-{group}.json")
        if group == "calibration":
            policies = choose(rows)
        else:
            locked = reference(OUT / "evaluation-calibration.json")
            policies = read_json(checked(locked))["policy"]
            record["locked"] = locked
        summary = scores(rows, policies)
        for method, x in summary["means"].items():
            print(group, method, x, flush=True)
        write_json(
            OUT / f"evaluation-{group}.json",
            record
            | {
                "source": upstream,
                "rows": rows,
                "policy": policies,
                "summary": summary,
                "risk_proxy": inspect(rows),
            },
        )
