"""Build phase-independent conditioning maps from nearby and whole-scene Bayer data."""

from functools import cache

import numpy as np
from scipy.ndimage import gaussian_filter, map_coordinates

SIDE = 32
N = SIDE // 2
AXIS = np.arange(N)
HANN = np.hanning(N)
WINDOW = HANN[:, None] * HANN
WINDOW /= np.sqrt(np.mean(WINDOW**2))
FX, FY = np.meshgrid(np.fft.fftfreq(N, d=2), np.fft.fftfreq(N, d=2), indexing="xy")
RADIUS = np.hypot(FX, FY)
BAND = (RADIUS >= 0.085) & (RADIUS <= 0.205)
COARSE = (RADIUS >= 0.03) & (RADIUS < 0.085)


def tiles(scene, coords):
    y, x = np.asarray(coords).T // 2
    return scene[
        :, (y[:, None, None] + AXIS[None, :, None]), (x[:, None, None] + AXIS[None, None, :])
    ].transpose(1, 0, 2, 3)


def raw_features(data, colors, shot, read):
    green = np.flatnonzero(colors == 1)
    red = np.flatnonzero(colors == 0)[0]
    blue = np.flatnonzero(colors == 2)[0]
    levels = np.mean(data, (-2, -1), dtype=np.float64).clip(0.002)
    chroma = np.log(levels[:, [red, blue]]) - np.log(levels[:, green].mean(1, keepdims=True))
    z = data[:, green].astype(np.float64) - levels[:, green, None, None]
    w = np.fft.fft2(z * WINDOW)
    dy, dx = (green[0] // 2 - green[1] // 2, green[0] % 2 - green[1] % 2)
    alignment = np.exp(-2j * np.pi * (FY * dy + FX * dx))
    product = (w[:, 0] * w[:, 1].conj() * alignment).real / N**4
    broad, fine = product[:, COARSE].sum(1), product[:, BAND].sum(1)
    level = levels[:, green].mean(1)
    variance = np.maximum(1e-12, shot * level + read)
    broad = np.arcsinh(broad / (variance * np.sqrt(COARSE.sum()) / N**2))
    fine_z = fine / (variance * np.sqrt(BAND.sum()) / N**2)
    descriptor = np.c_[np.log(level), chroma, np.clip(broad, 0, 5)]
    return fine_z, descriptor


def atlas_grid(shape, limit=1536):
    y, x = [np.arange(0, 2 * s - SIDE + 1, SIDE) for s in shape]
    xy = np.stack(np.meshgrid(y, x, indexing="ij"), axis=-1).reshape(-1, 2)
    if len(xy) > limit:
        xy = xy[np.linspace(0, len(xy) - 1, limit).astype(int)]
    return xy


def make_atlas(scene, colors, shot, read, exclude=None, coords=None):
    if coords is None:
        coords = atlas_grid(scene.shape[-2:])
    if exclude is not None:
        x, y, w, h = exclude
        py, px = coords.T
        keep = (
            (px + SIDE <= x - SIDE)
            | (px >= x + w + SIDE)
            | (py + SIDE <= y - SIDE)
            | (py >= y + h + SIDE)
        )
        coords = coords[keep]
    if len(coords) == 0:
        return coords, None, None
    z, desc = raw_features(tiles(scene, coords), colors, shot, read)
    return coords, z, desc


@cache
def query_grid(packed_side):
    query = atlas_grid((packed_side, packed_side))
    return query, int(2 * packed_side // SIDE)


def field(grid, side):
    h, w = side
    source = grid.reshape(h // SIDE, w // SIDE)
    y, x = np.indices(side, dtype=float)
    return map_coordinates(
        source,
        [(y + 0.5) / SIDE - 0.5, (x + 0.5) / SIDE - 0.5],
        order=1,
        mode="nearest",
        prefilter=False,
    )


def guides(packed, colors, shot, read, origin, atlas):
    query, count = query_grid(packed.shape[-1])
    assert packed.shape[-1] == packed.shape[-2]
    z, desc = raw_features(tiles(packed, query), colors, shot, read)
    outside, oz, od = atlas
    native = (2 * packed.shape[-1],) * 2
    base = np.arcsinh(z)
    if oz is None:
        halo = np.zeros_like(base)
        diverse = halo
        wrong = halo
    else:
        scale = np.array([0.28, 0.20, 0.20, 1.8])
        features = np.square((desc[:, None] - od[None]) / scale).sum(-1)
        weights = np.exp(-0.5 * features)
        distance = np.linalg.norm(
            query[:, None] + np.asarray(origin)[None, None, ::-1] - outside[None], axis=-1
        )
        distance_limit = max(192, float(np.quantile(np.min(distance, axis=1), 0.90) + 48))
        region = weights * np.exp(-0.5 * (distance / distance_limit) ** 2)
        donors = np.clip(np.arcsinh(oz), -3, 4)

        def pooled(w, a):
            return (w @ a) / (w.sum(1) + 1.0)

        halo = pooled(region, donors)
        diverse = pooled(weights, donors)
        wrong = pooled(weights, np.roll(donors, len(donors) // 2))
    return {
        "local": field(base, native),
        "near": field(base + halo, native),
        "whole": field(base + diverse, native),
        "permuted": field(base + wrong, native),
    }


def mosaic(body, colors):
    return np.stack(
        [body[..., colors[2 * r + c], r::2, c::2] for r, c in np.ndindex(2, 2)], axis=-3
    )


def native_green(raw, colors):
    y = np.zeros((*raw.shape[:-3], 2 * raw.shape[-2], 2 * raw.shape[-1]), dtype=float)
    for i in np.flatnonzero(colors == 1):
        y[..., i // 2 :: 2, i % 2 :: 2] = 2 * raw[..., i, :, :]
    return y


def bandpass(image):
    # Band inside the quincunx green sampling region, independently of CFA origin.
    h, w = image.shape[-2:]
    f = np.fft.fftfreq(h)[:, None]
    g = np.fft.rfftfreq(w)[None, :]
    radial = np.hypot(f, g)
    filt = np.clip((radial - 0.094) / 0.031, 0, 1) * np.clip((0.304 - radial) / 0.044, 0, 1)
    return np.fft.irfft2(np.fft.rfft2(image) * filt, s=(h, w), axes=(-2, -1))


def risk(out, data, key):
    colors = data["colors"]
    anchor = mosaic(out["nominal"], colors)
    h = mosaic(out[key], colors) - anchor
    base = bandpass(native_green(anchor - data["packed"], colors))
    delta = bandpass(native_green(h, colors))
    terms = []
    for i in range(2):
        sensor = bandpass(native_green(out[f"eps{i}"], colors))
        derivative = bandpass(native_green(out[f"df{i}-{key}"], colors))
        terms.append(2 * sensor * derivative)
    # Filter the effective heteroscedastic Gaussian risk difference after subtracting the common term.
    empirical = 2 * base * delta + delta**2
    sampled = np.stack([gaussian_filter(v, (0, 12, 12)) * 65535**2 for v in terms])
    naive = gaussian_filter(empirical, (0, 12, 12)) * 65535**2
    truth = None
    if "target" in data:
        true = bandpass(native_green(anchor - mosaic(data["target"], colors), colors))
        truth = gaussian_filter((2 * true * delta + delta**2), (0, 12, 12)) * 65535**2
    return naive, sampled, truth
