"""Apply a bounded luminance-only lift and separate quiet-region smoothing."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

from capture import OUT
import context_gate as gate
import score
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

FAMILIES = ("uniform", "local", "near", "whole", "permuted")
LEVEL = (0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0)
CRISP_DOSE = (0.0, 0.125, 0.25, 0.5, 0.75, 1.0)
SMOOTH_DOSE = (0.0, 0.125, 0.25, 0.5, 0.75, 1.0)
CAP = 24.0 / 65535.0


def paired_items(group):
    rec = reference(OUT / f"mild-capture-{group}.json")
    info = read_json(checked(rec))
    for (item, data, out, original), new in zip(score.items(group), info["rows"], strict=True):
        assert new["id"] == item["id"] and new["input"] == item["input"]
        with np.load(checked(new["output"]), allow_pickle=False) as f:
            altered = {k: f[k] for k in ("crisp", "smooth")}
        yield (
            item,
            data,
            altered | {"nominal": out["nominal"]},
            {"initial": original, "mild": new["output"]},
        )


def ingredients(out, data):
    rgb = np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"]
    luma = {}
    for k in ("crisp", "smooth"):
        a = gate.bandpass(score.luma(out[k].astype(float) - out["nominal"], data))
        norm = np.sqrt(gaussian_filter(a * a, (0, 12, 12)))
        luma[k] = a * np.minimum(1.0, CAP / np.maximum(1e-9, norm))
    return luma, rgb


def spatial(maps, family, threshold):
    if family == "uniform":
        return np.ones_like(maps["local"]), np.ones_like(maps["local"])
    # A broad context can supply or withhold support only where the query has positive evidence.
    safe = np.clip(maps["local"] / 1.5, 0, 1)
    sharp = np.clip((maps[family] - threshold) / 2, 0, 1) * safe
    smooth = np.clip((0.9 - maps["local"]) / 1.8, 0, 1)
    return sharp, smooth


def synthesis(base, fields, neutral, maps, policy):
    k = policy["family"]
    strong, quiet = spatial(maps, k, policy["threshold"])
    s, t = policy["dose"]
    addition = s * strong * fields["crisp"] + t * quiet * fields["smooth"]
    if not addition.any():
        return base
    return (base + addition[:, None] * neutral[None, :, None, None]).astype(base.dtype)


def coefficients(field):
    identity = {"matrix": np.eye(3), "wb": np.ones(3)}
    # A camera-neutral correction has unit luminance regardless of the camera transform.
    return score.stats(np.broadcast_to(field[:, None], (len(field), 3, *field.shape[1:])), identity)


def terms(target, base, crisp, smooth, mask=score.BANDS["fine"]):
    t, b, c, s = [a[..., mask] for a in (target, base, crisp, smooth)]
    delta = lambda x: x[0] - x[1]
    tdelta, bdelta, cdelta, sdelta = map(delta, (t, b, c, s))
    dot = lambda x, y: float(np.sum(x * y))

    def expansion(x, g, h):
        return [
            value * score.SCALE
            for value in (
                dot(x, x),
                2 * dot(x, g),
                2 * dot(x, h),
                dot(g, g),
                2 * dot(g, h),
                dot(h, h),
            )
        ]

    return {
        "truth": dot(tdelta, tdelta),
        "response": [dot(x, tdelta) for x in (bdelta, cdelta, sdelta)],
        "increment": expansion(bdelta - tdelta, cdelta, sdelta),
        "present": expansion(b[0] - t[0], c[0], s[0]),
        "flat": expansion(b[2] - t[2], c[2], s[2]),
    }


def collect(group):
    rows = []
    for item, data, out, bindings in paired_items(group):
        maps = score.signatures(data, item)
        fields, _ = ingredients(out, data)
        a, t = [score.stats(x, data) for x in (out["nominal"], data["target"])]
        opts = {}
        for family in FAMILIES:
            options = []
            for threshold in LEVEL if family != "uniform" else (0.0,):
                sharp, quiet = spatial(maps, family, threshold)
                c, s = [
                    coefficients(x * y)
                    for x, y in ((sharp, fields["crisp"]), (quiet, fields["smooth"]))
                ]
                options.append(terms(t, a, c, s))
            opts[family] = options
        rows.append(
            {
                "id": item["id"],
                "input": item["input"],
                "predictions": bindings,
                "measurements": opts,
            }
        )
        if len(rows) % 8 == 0:
            print(group, len(rows), flush=True)
    return rows


def values(rows, family, index, s, t):
    records = [r["measurements"][family][index] for r in rows]
    expansion = np.array([1, s, t, s * s, s * t, t * t])
    return {
        k: np.sqrt(np.maximum(0, np.asarray([r[k] for r in records]) @ expansion))
        for k in ("increment", "present", "flat")
    } | {
        "projection": np.asarray([r["response"] for r in records]) @ np.array([1, s, t]),
        "true": np.asarray([r["truth"] for r in records]),
    }


def calibrate(rows):
    base = score.evaluate(values(rows, "uniform", 0, 0, 0))
    specs = {}
    for family in FAMILIES:
        trials = []
        for i, level in enumerate(LEVEL if family != "uniform" else (0.0,)):
            for s in CRISP_DOSE:
                for t in SMOOTH_DOSE:
                    result = score.evaluate(values(rows, family, i, s, t))
                    within = all(result[k] - base[k] <= tol for k, tol in score.LIMITS.items())
                    trials.append(
                        {
                            "family": family,
                            "index": i,
                            "threshold": level,
                            "dose": [s, t],
                            "scores": result,
                            "within": within,
                        }
                    )
        select = lambda pool: max(
            pool, key=lambda x: (x["scores"]["response_pp"], -x["scores"]["increment"])
        )
        specs[family] = {
            "chosen": select(x for x in trials if x["within"]),
            "descriptive": select(
                x
                for x in trials
                if x["scores"]["flat"] - base["flat"] <= 0.25
                and x["scores"]["increment"] - base["increment"] <= 0.5
            ),
            "trials": trials,
        }
        print(family, specs[family]["chosen"], "relaxed", specs[family]["descriptive"], flush=True)
    return {"control": base, "limits": score.LIMITS, "specs": specs}


def compare(rows, lock):
    n = len(rows)
    rng = np.random.default_rng(202611200718)
    draws = np.vstack((np.arange(n), rng.integers(n, size=(10000, n))))
    chosen = {family: spec["chosen"] for family, spec in lock["specs"].items()}
    chosen |= {f"{family} relaxed": spec["descriptive"] for family, spec in lock["specs"].items()}
    chosen["baseline"] = {"family": "uniform", "index": 0, "dose": [0.0, 0.0]}
    data = {k: values(rows, v["family"], v["index"], *v["dose"]) for k, v in chosen.items()}
    boot = {}
    stats = {}
    for k, row in data.items():
        boot[k] = {
            m: np.sqrt(np.mean(row[m][draws] ** 2, axis=1))
            for m in ("increment", "present", "flat")
        } | {"response_pp": 100 * row["projection"][draws].sum(1) / row["true"][draws].sum(1)}
        stats[k] = score.evaluate(row)
    pairs = {}
    for k in ("baseline", "uniform", "local"):
        for name, row in boot.items():
            pairs[f"{name} vs {k}"] = {
                metric: [float(d[0]), *np.quantile(d[1:], (0.025, 0.975)).tolist()]
                for metric, value in row.items()
                if (d := value - boot[k][metric]) is not None
            }
    return {"scores": stats, "vs": pairs}


if __name__ == "__main__":
    name = sys.argv[1]
    if name == "transfer":
        locked = reference(OUT / "mild-calibration.json")
        lock = read_json(checked(locked))["policy"]
    else:
        locked = None
    rows = collect(name)
    if locked is None:
        lock = calibrate(rows)
    summary = compare(rows, lock)
    for v, row in summary["scores"].items():
        print(name, v, row, flush=True)
    write_json(
        OUT / f"mild-{name}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(gate.__file__)),
            "score": reference(Path(score.__file__)),
            "base": reference(OUT / f"capture-{name}.json"),
            "mild": reference(OUT / f"mild-capture-{name}.json"),
            "frozen_calibration": locked,
            "rows": rows,
            "policy": lock,
            "summary": summary,
        },
    )
