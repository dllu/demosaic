"""Test exact reuse of local encoder outputs across noise conditioning strengths."""

from contextlib import contextmanager
from pathlib import Path
from statistics import median
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from collect_training import capture, load_model, batch, run, CHOICES
from detail_selector import OUT


@contextmanager
def shared_encoding(context, *, compare=True):
    source = context.forward
    pool = {}
    calls = {"used": 0, "executed": 0}

    def encode(preview, size, **flags):
        key = (tuple(size), tuple(sorted(flags.items())))
        calls["used"] += 1
        if key not in pool:
            pool[key] = (preview, source(preview, size, **flags))
            calls["executed"] += 1
        else:
            old, _ = pool[key]
            if compare:
                torch.testing.assert_close(preview, old, rtol=0, atol=0)
        return pool[key][1]

    with patch.object(context, "forward", encode):
        yield calls


def forward(model, x, noise, *, reuse=False, verify=True):
    if reuse:
        with shared_encoding(model.base.context, compare=verify) as count:
            maps = {
                name: run(model, x, x["packed"], x["variance"], noise, v)
                for name, v in CHOICES.items()
            }
        assert count == {"used": 3, "executed": 1}
    else:
        maps = {
            name: run(model, x, x["packed"], x["variance"], noise, v) for name, v in CHOICES.items()
        }
    return maps


@torch.inference_mode()
def profile():
    torch.set_num_threads(2)
    p = reference(OUT / "preflight/plan.json")
    params = read_json(checked(p))
    model = load_model(params["parent"])
    verified = []
    times = {"standard": [], "reuse_exact_checked": []}
    with ieee_fp32():
        for i, record in enumerate(params["samples"]):
            data, _, noise, _, desc = capture(record, i)
            x = batch(data)
            a = forward(model, x, noise)
            b = forward(model, x, noise, reuse=True)
            for key, t in a.items():
                assert torch.equal(t, b[key]), (i, key, (t - b[key]).abs().max().item())
            verified.append({"fixture": desc, "max_rgb_DN16": 0})
            for method, reuse in (("standard", False), ("reuse_exact_checked", True))[
                :: (-1 if i % 2 else 1)
            ]:
                torch.cuda.synchronize()
                t = monotonic()
                forward(model, x, noise, reuse=reuse)
                torch.cuda.synchronize()
                times[method].append(monotonic() - t)
    write_json(
        OUT / "shared-local-preview.json",
        {
            "driver": reference(Path(__file__)),
            "parent": params["parent"],
            "plan": p,
            "cases": verified,
            "paired_timing_seconds": times,
            "medians_seconds": {k: median(v) for k, v in times.items()},
            "scope": "Interleaved proof while feature collection may share the GPU. Timing excludes source decode and model load.",
        },
    )
    print({k: median(t) for k, t in times.items()}, flush=True)


if __name__ == "__main__":
    profile()
