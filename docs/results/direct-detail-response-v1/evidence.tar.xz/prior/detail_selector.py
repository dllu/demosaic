"""Predict bounded gains for two fixed noise-conditioned restoration differences."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter
import torch
from torch import nn
from torch.nn import functional as F

from demosaic.scene_restoration import encode_scene
from demosaic.scene_context import sample_scene_features

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("context-conditioned-detail-v1")))
import context_gate as old

STATION = 32
MAX_DETAIL_DN16 = 24.0
PREVIEW = 448
FEATURE_LEVELS = (1, 2)
DIM = 20
RES = ("crisp", "smooth")
ARMS = ("local", "pooled", "spatial")
LUMA = np.asarray([0.2126, 0.7152, 0.0722])


def luma(rgb, meta):
    return np.einsum("...chw,c->...hw", rgb, (LUMA @ meta["matrix"]) * meta["wb"])


def block_pixels(value, factor=32):
    h, w = value.shape[-2:]
    return value.reshape(*value.shape[:-2], h // factor, factor, w // factor, factor).swapaxes(
        -3, -2
    )


def rms_field(a):
    return np.sqrt(np.mean(block_pixels(a) ** 2, axis=(-2, -1)))


def ingredients(pred, meta):
    rgb = np.linalg.solve(meta["matrix"].astype(float), np.ones(3)) / meta["wb"]
    anchor = luma(pred["nominal"], meta)
    proposals = []
    for k in RES:
        d = old.bandpass(luma(pred[k], meta) - anchor)
        e = np.sqrt(gaussian_filter(d * d, (0, 12, 12)))
        proposals.append(d * np.minimum(1, MAX_DETAIL_DN16 / 65535 / np.maximum(1e-9, e)))
    return anchor, np.stack(proposals, axis=1), rgb


def local_features(packed, anchor, proposals, colors, profile):
    shape = anchor.shape[-2:]
    count = (shape[0] // STATION, shape[1] // STATION)
    coords = old.atlas_grid(packed.shape[-2:], limit=1024)
    src = []
    for raw in packed:
        z, fields = old.raw_features(
            old.tiles(raw, coords), colors, profile["shot"], profile["read"]
        )
        src.append(np.c_[np.arcsinh(z), fields].reshape(*count, -1))
    base = np.stack(src)
    band = rms_field(old.bandpass(anchor)) * 65535
    tuning = rms_field(proposals) * 65535
    rms = np.log1p(tuning).transpose(0, 2, 3, 1)
    clip = np.mean(
        block_pixels(np.mean((packed <= 0.001) | (packed >= 0.99), axis=1), 16), axis=(-2, -1)
    )
    noise = np.broadcast_to(
        np.log(np.asarray([profile["shot"], profile["read"]]) + 1e-10) + [7, 12], (*band.shape, 2)
    )
    vector = np.concatenate((base, np.log1p(band)[..., None], rms, clip[..., None], noise), axis=-1)
    # Do not let context generate a sharp correction in a station without
    # any positive cross-green power. The slower branch has no such restriction.
    support = np.clip(base[..., 0] / 1.5, 0, 1)
    return vector.astype(np.float32), support.astype(np.float32)


def scene_without_query(raw, box):
    x, y, w, h = (v // 2 for v in box)
    result = raw.clone()
    sh, sw = raw.shape[-2:]
    lo, hi = max(0, x - 8), min(sw, x + w + 8)
    top, bottom = max(0, y - 8), min(sh, y + h + 8)
    area = raw[..., max(0, top - 20) : min(sh, bottom + 20), max(0, lo - 20) : min(sw, hi + 20)]
    region = raw[..., top:bottom, lo:hi]
    n = area.shape[-2] * area.shape[-1] - region.shape[-2] * region.shape[-1]
    if not n:
        mask = torch.zeros_like(raw)
        return mask
    # Sum exterior strips directly so changing recipient values cannot affect the preview.
    blocks = (
        raw[..., max(0, top - 20) : top, max(0, lo - 20) : min(sw, hi + 20)],
        raw[..., bottom : min(sh, bottom + 20), max(0, lo - 20) : min(sw, hi + 20)],
        raw[..., top:bottom, max(0, lo - 20) : lo],
        raw[..., top:bottom, hi : min(sw, hi + 20)],
    )
    mean = sum(v.sum((-2, -1), keepdim=True) for v in blocks) / n
    result[..., top:bottom, lo:hi] = mean
    return result


@torch.no_grad()
def scene_features(model, scene, cfa, wb, matrix, box):
    scene = torch.as_tensor(scene, device="cuda", dtype=torch.float32)
    cfa = torch.as_tensor(cfa, device="cuda")
    wb = torch.as_tensor(wb, device="cuda")
    matrix = torch.as_tensor(matrix, device="cuda")
    filled = scene_without_query(scene, box)
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        observed = encode_scene(model.base.context, filled, cfa, wb, matrix, long_side=PREVIEW)
    h, w = box[3] // STATION, box[2] // STATION
    features = []
    pooled = []
    for level in FEATURE_LEVELS:
        f = observed.features[level].float()
        stride = 4 * 2**level
        z = F.layer_norm(f.movedim(1, -1), (f.shape[1],)).movedim(-1, 1)
        rng = np.random.default_rng(202611200823 + level)
        mix = rng.normal(0, 1 / np.sqrt(z.shape[1]), (DIM, z.shape[1], 1, 1)).astype(np.float32)
        field = F.conv2d(z, torch.from_numpy(mix).to(z.device))
        context = sample_scene_features(field, observed.grid, stride, [box], (h, w))[0]
        h_native, w_native = observed.grid.preview_hw
        yy = (h_native - torch.arange(field.shape[-2], device=z.device) * stride).clamp(0, stride)
        xx = (w_native - torch.arange(field.shape[-1], device=z.device) * stride).clamp(0, stride)
        areas = yy[:, None] * xx[None, :]
        features.append(context.cpu().numpy())
        pooled.append(((field[0] * areas).sum((-2, -1)) / areas.sum()).cpu().numpy())
    return np.concatenate(features).transpose(1, 2, 0), np.concatenate(pooled)


def gram(residual, terms):
    # Each overlapping output coefficient is trained on its station. Explicit
    # evaluation below renders the final interpolated field before scoring.
    t = block_pixels(terms * 65535)
    r = block_pixels(residual * 65535)
    linear = np.einsum("...dxyhw,...xyhw->...xyd", t, r) / (STATION**2)
    quad = np.einsum("...dxyhw,...exyhw->...xyde", t, t) / (STATION**2)
    level = (r * r).mean(axis=(-2, -1))
    return linear.astype(np.float32), quad.astype(np.float32), level.astype(np.float32)


def training_payload(obs, predictions, profile, scene_context):
    anchor, proposals, _ = ingredients(predictions, obs)
    density, support = local_features(obs["packed"], anchor, proposals, obs["colors"], profile)
    raw_target = luma(obs["target"], obs)
    error = old.bandpass(anchor - raw_target)
    linear, quad, level = gram(error, proposals)
    td = old.bandpass(raw_target[0] - raw_target[1])
    # Extra emphasis on correctly signed weak contrast in the present/absent pair.
    pd = old.bandpass(anchor[0] - anchor[1]) - 1.10 * td
    pv = np.concatenate((proposals[0], -proposals[1]), axis=0)
    paired = gram(pd, pv)
    return {
        "features": density,
        "support": support,
        "scene": scene_context[0],
        "pooled": scene_context[1],
        "linear": linear,
        "quad": quad,
        "level": level,
        "p_linear": paired[0],
        "p_quad": paired[1],
        "p_level": paired[2],
    }


class Selector(nn.Module):
    def __init__(self, input_features=11):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_features + 2 * DIM, 32),
            nn.SiLU(),
            nn.Linear(32, 16),
            nn.SiLU(),
            nn.Linear(16, 2),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.constant_(self.network[-1].bias, -2.2)

    def forward(self, raw, support, scene):
        out = self.network(torch.cat((raw, scene), dim=-1)).sigmoid()
        return out * torch.stack((support, torch.ones_like(support)), dim=-1)


def context_slots(local, spatial, pooled, arm):
    p = pooled[..., None, None, :].expand_as(spatial)
    z = torch.zeros_like(spatial) if arm == "local" else p if arm == "pooled" else spatial
    if arm == "shuffled":
        z = spatial.roll((spatial.shape[-3] // 2, spatial.shape[-2] // 2), dims=(-3, -2))
    return z.unsqueeze(-4).expand(*local.shape[:-1], z.shape[-1])


def render(anchor, proposals, neutral, gains, base):
    h, w = anchor.shape[-2:]
    gates = F.interpolate(
        gains.permute(0, 3, 1, 2), size=(h, w), mode="bilinear", align_corners=False
    )
    update = (proposals * gates.cpu().numpy()).sum(axis=1)
    return (base + neutral[None, :, None, None] * update[:, None]).astype(base.dtype)
