"""Freeze and process distinct full-context training photos without saving RGB crops."""

from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import random
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_inference import load_scene_checkpoint
from demosaic.scene_training_data import _attenuate_local_contrast, scene_seed

import detail_selector as head
from capture import batch, run

OUT = head.OUT
PLAN_SOURCE = head.HERE.with_name("scene-full-epoch-v1") / "plan.json"
PARENT = Path("docs/results/scene-full-epoch-v1/local-050000-training.json")
PRIOR = OUT.with_name("context-conditioned-detail-v1") / "plan.json"
SEED = 202611200842
COUNT = 1600
BLOCK = 32
PROFILES = ((0.00032, 4.096e-7), (0.00128, 6.5536e-6), (0.00256, 2.62144e-5))
CHOICES = {"crisp": 0.90, "nominal": 1.0, "smooth": 1.15}


def manifest(root, minimum):
    upstream = reference(PLAN_SOURCE)
    candidate = read_json(checked(upstream))["train_manifest"]
    earlier = reference(PRIOR)
    holdout = read_json(checked(earlier))
    prohibited = set()
    for role in ("calibration", "transfer", "wires"):
        for item in holdout["groups"][role]:
            p = item["source"]
            if isinstance(p, str):
                prohibited.add(p)
            else:
                prohibited.update((p["id"], p["cache_sha256"]))
    selected = []
    for line in checked(candidate).open():
        row = json.loads(line)
        h, w = row["shape"][:2]
        if row["split"] != "train" or min(h, w) < 512 or max(h, w) > 1750:
            continue
        if {row["id"], row["cache_sha256"]}.isdisjoint(prohibited):
            key = sha256(f"{SEED}/scene-selector/{row['id']}".encode()).hexdigest()
            selected.append((key, row))
    selected.sort(key=lambda z: z[0])
    pool = [v for k, v in selected]
    assert len(pool) >= minimum
    material = pool[:minimum]
    assert len({v["cache_sha256"] for v in material}) == len(material)
    return {
        "driver": reference(__file__),
        "head": reference(head.__file__),
        "count": minimum,
        "seed": SEED,
        "parent": read_json(PARENT)["checkpoint"],
        "source_plan": upstream,
        "observations_for_evaluation": earlier,
        "train_manifest": candidate,
        "eligible_sources": len(pool),
        "factors": CHOICES,
        "samples": material,
        "precision": "CUDA IEEE FP32 for restoration; shared scene encoder BF16",
    }


def capture(row, index):
    raw = Path(row["cache"])
    checked({"path": str(raw), "sha256": row["cache_sha256"]})
    payload = np.load(raw, mmap_mode="r", allow_pickle=False)
    assert list(payload.shape) == row["shape"] and payload.dtype == np.uint16
    x = torch.from_numpy(np.array(payload, dtype=np.float32, copy=True)).permute(2, 0, 1) / 65535
    x = x[:, : x.shape[1] // 2 * 2, : x.shape[2] // 2 * 2]
    rng = random.Random(scene_seed(SEED, index, "data"))
    degrees, flip = rng.randrange(4), rng.random() >= 0.5
    x = torch.rot90(x, degrees, (-2, -1))
    if flip:
        x = x.flip(-1)
    # Keep the outside scene intact. Alter only the selected central query.
    box = tuple(
        scene_crop_boxes(
            x.shape[-2:], patch_size=256, count=1, seed=scene_seed(SEED, index, "box")
        )[0]
    )
    recipe = sample_scene_recipe(scene_seed(SEED, index, "camera"))
    sensor = rng.choices(PROFILES, weights=(0.25, 0.55, 0.20))[0]
    recipe = replace(recipe, shot=sensor[0], read=sensor[1], exposure=2 ** rng.uniform(-2.6, -0.1))
    scale = (rng.uniform(0.50, 1), rng.uniform(0.0, 0.18), 0.0)
    ob = []
    for ordinal, strength in enumerate(scale):
        data = _attenuate_local_contrast(x, box, strength, flat_core=ordinal == 2)
        record = observe_scene(
            data.contiguous(),
            replace(recipe, noise_seed=scene_seed(SEED, index, f"noise{ordinal}")),
        )
        if ordinal == 0:
            scene = record.packed
        ob.append(record.crops([box]))
    arrays = {k: torch.cat([b[k] for b in ob]).numpy() for k in ("packed", "variance", "target")}
    arrays.update({k: ob[0][k][0].numpy() for k in ("colors", "wb", "matrix")})
    noise = {"shot": sensor[0], "read": sensor[1], "exposure": recipe.exposure}
    return (
        arrays,
        scene,
        noise,
        box,
        {
            "source": row["id"],
            "sha256": row["cache_sha256"],
            "box": box,
            "roles": scale,
            "profile": noise,
            "recipe": asdict(recipe),
            "D4": [degrees, flip],
            "observed": fingerprint(torch.from_numpy(arrays["packed"])),
            "target": fingerprint(torch.from_numpy(arrays["target"])),
        },
    )


def load_model(weight):
    model, state = load_scene_checkpoint(
        checked(weight), weights="ema", expected_sha256=weight["sha256"]
    )
    assert state["step"] == 50000 and state["mode"] == "none"
    return (
        _stage_tiled_cuda(model, torch.device("cuda")).eval().to(memory_format=torch.channels_last)
    )


@torch.inference_mode()
def main(mode):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 10 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    root = OUT / mode
    root.mkdir(exist_ok=True)
    fp = root / "plan.json"
    if not fp.exists():
        write_json(fp, manifest(root, 8 if mode == "preflight" else COUNT))
    p = read_json(fp)
    assert p["driver"] == reference(__file__) and p["head"] == reference(head.__file__)
    data = p["samples"]
    t0 = monotonic()
    net = load_model(p["parent"])
    done = []
    with ieee_fp32():
        for start in range(0, len(data), BLOCK):
            end = min(start + BLOCK, len(data))
            dest = root / f"selection-{start:04}-{end:04}.npz"
            meta = dest.with_suffix(".json")
            if meta.is_file():
                assert reference(dest) == read_json(meta)["data"]
            else:
                terms = []
                identity = []
                t = monotonic()
                for i in range(start, end):
                    obs, scene, noise, box, prov = capture(data[i], i)
                    x = batch(obs)
                    pred = {
                        n: run(net, x, x["packed"], x["variance"], noise, f).cpu().numpy()
                        for n, f in CHOICES.items()
                    }
                    ctxt = head.scene_features(
                        net, scene, obs["colors"], obs["wb"], obs["matrix"], box
                    )
                    row = head.training_payload(obs, pred, noise, ctxt)
                    assert all(np.isfinite(v).all() for v in row.values())
                    terms.append(row)
                    identity.append(prov)
                tar = dest.with_suffix(".partial")
                with tar.open("wb") as f:
                    np.savez(f, **{k: np.stack([r[k] for r in terms]) for k in terms[0]})
                tar.rename(dest)
                write_json(
                    meta, {"data": reference(dest), "samples": identity, "seconds": monotonic() - t}
                )
            done.append(reference(meta))
            print(mode, end, "of", len(data), "elapsed", round(monotonic() - t0, 2), flush=True)
    write_json(
        root / "completed.json",
        {"plan": reference(fp), "chunks": done, "seconds": monotonic() - t0},
    )


if __name__ == "__main__":
    main(sys.argv[1])
