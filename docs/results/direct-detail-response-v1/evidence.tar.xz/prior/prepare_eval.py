"""Freeze held-out scenes to measure contextual weak-detail recovery and false texture."""

import argparse
from collections import Counter
from dataclasses import asdict,replace
import hashlib
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe,scene_crop_boxes
from demosaic.scene_training_data import _attenuate_local_contrast,scene_seed

ROOT=Path(__file__).resolve().parent
NUM=64
ARGS=("packed","variance","colors","wb","matrix")
PROFILES=(
    {"name":"iso400","shot":8e-5,"read":2.56e-8,"exposure":.33},
    {"name":"iso6400","shot":.00128,"read":6.5536e-6,"exposure":.33},
)
DRAWS=("coupled","independent")
ROLES=("present","masked-fine","flat")
SEED=202611180781


def make_plan():
    cohort=reference(ROOT.parent/"full427-faint-adc-v1"/"cohort.json")
    validation=read_json(checked(cohort))
    sources=[r for r in validation["source_metadata"] if r["split"]=="val" and
             r["bin_factor"]==4 and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000]
    assert len(sources)>=NUM
    train=read_json(ROOT/"plan.json")
    picked=sorted(sources,key=lambda r:hashlib.sha256(("localized-scene-real-v1|"+r["id"]).encode()).digest())[:NUM]
    assert len({r["id"]for r in picked})==NUM and validation["training_overlap"]==[]
    photos=[]
    for i,row in enumerate(picked):
        h,w=(int(n)//2*2 for n in row["shape"][:2])
        (box,)=scene_crop_boxes((h,w),patch_size=256,count=1,seed=scene_seed(SEED,i,"box"))
        conf=sample_scene_recipe(scene_seed(SEED,i,"camera"))
        photos.append({"source":row,"index":i,"box":box,"camera":asdict(conf)|{
                       "pattern":tuple(PATTERNS)[i%4],"black":.03}})
    assert Counter(r["camera"]["pattern"]for r in photos)==dict.fromkeys(PATTERNS,NUM//4)
    write_json(ROOT/"evaluation-plan.json",{"source":reference(__file__),"training_plan":reference(ROOT/"plan.json"),
        "cohort":cohort,"rows":photos,"profiles":PROFILES,"draws":DRAWS,"roles":ROLES,
        "expected_cases":NUM*len(PROFILES)*len(DRAWS),"expected_checkpoint_labels":["V120","100k",
           "plain-none","plain-spatial","localized-none","localized-spatial"],
        "scene_preview_policies":["matching","blur-distant","neutral","wrong-distant"],
        "halo_preview_px":16,"transition_preview_px":16,"blur_sigma_preview_px":24,
        "score_ROI_xywh":[80,80,96,96],"native_display_ROI_xywh":[48,48,160,160],
        "comparison":"Primary compare localized versus plain spatial-local gain for measured signed weak increment and fine error. Secondary fix each query RAW, change only exterior preview, retaining identical near preview. Exact uniform core measures false texture near naturally busy surroundings.",
        "scope":"All64 source files held out under the declared full-current training manifest. No source resizing, distinct physical camera/CFAs. Independent draw and a separate coupled differential diagnostic. At each draw all role exteriors share the same actual noisy samples."})


def load_photo(row):
    record=row["source"]
    source=Path(record["cache"])
    assert source.is_relative_to(Path("/mnt/external")) and reference(source)["sha256"]==record["cache_sha256"]
    with source.open("rb")as stream:
        data=np.load(stream,allow_pickle=False)
    assert list(data.shape)==record["shape"] and data.dtype==np.uint16
    h,w=(n//2*2 for n in data.shape[:2])
    return torch.from_numpy(data[:h,:w].astype(np.float32)).permute(2,0,1).contiguous()/65535.


def patch(image,box,scale):
    x,y,w,h=box
    values=_attenuate_local_contrast(image,box,scale)
    crop=values[:,y:y+h,x:x+w]
    return crop.contiguous()


def flat_patch(crop):
    # The center 96px remains exactly constant. Its surround keeps natural
    # image structure through a smooth 14px skirt outside the scored region.
    xy=torch.arange(256,dtype=crop.dtype)
    z=((65-(xy-127.5).abs())/14).clamp(0,1)
    a=z.square()*(3-2*z)
    weights=a[:,None]*a[None,:]
    mean=crop[:,80:176,80:176].mean((-1,-2),keepdim=True)
    mixed=torch.lerp(crop,mean,weights)
    v=torch.where(weights==1,mean,mixed)
    assert torch.equal(v[:,80:176,80:176],mean.expand(3,96,96))
    return v


def save(path,arrays):
    with path.open("xb")as stream:
        np.savez(stream,**arrays)
    return reference(path)


def sensor(row,profile,role,draw):
    rng=scene_seed(SEED,row["index"],"/".join((profile["name"],role,draw)))
    fields=row["camera"]|{k:profile[k]for k in ("shot","read","exposure")}|{"noise_seed":rng}
    return replace(sample_scene_recipe(SEED),**fields)


def ordinary(image,recipe):
    obs=observe_scene(image,recipe)
    return {k:getattr(obs,k).numpy() for k in (*ARGS,"target")}


def observed_group(rgb,patches,row,profile,draw):
    original=ordinary(rgb,sensor(row,profile,"exterior",draw))
    if draw=="coupled":
        p=sensor(row,profile,"pair",draw)
        pair,_=paired_observation(
           patches["present"][None],patches["masked-fine"][None],profile,[p.pattern],
           torch.tensor(p.wb)[None],torch.tensor(p.camera_inverse)[None],p.noise_seed,
        )
        locals={name:{k:pair[k][j]for k in (*ARGS,"target")}for j,name in enumerate(ROLES[:2])}
    else:
        locals={name:ordinary(patches[name],sensor(row,profile,name,draw))for name in ROLES[:2]}
    locals["flat"]=ordinary(patches["flat"],sensor(row,profile,"flat",draw))
    for p in locals.values():
        for k in ("colors","wb","matrix"):
            np.testing.assert_array_equal(p[k],original[k])
    for p in (locals["flat"]["target"],):
        np.testing.assert_array_equal(p[:,80:176,80:176],np.broadcast_to(p[:,80:81,80:81],(3,96,96)))
    values={k:locals["present"][k]for k in ("colors","wb","matrix")}
    values["scene_packed"]=original["packed"]
    for key in ("packed","variance","target"):
        values[key]=np.stack([locals[role][key]for role in ROLES])
    return values


def produce(part):
    os.sched_setaffinity(0,[14+part]);os.nice(11);torch.set_num_threads(1)
    declared=reference(ROOT/"evaluation-plan.json")
    spec=read_json(checked(declared))
    assert reference(__file__)==spec["source"]
    output=ROOT/"observations"
    output.mkdir(exist_ok=True)
    recorded=[]
    for row in spec["rows"][part::2]:
        image=load_photo(row)
        # Only the photo's own local residual rises in the present version.
        # The Gaussian-like background and the rest of the scene are common.
        present=patch(image,row["box"],.22)
        masked=patch(image,row["box"],0.)
        values={"present":present,"masked-fine":masked,"flat":flat_patch(masked)}
        assert all(v.shape==(3,256,256) and torch.isfinite(v).all()for v in values.values())
        before=torch.stack([v[:,80:176,80:176] for v in (present,masked)])
        actual=float((before[0]-before[1]).square().mean().sqrt()*65535)
        for profile in spec["profiles"]:
            for draw in spec["draws"]:
                arrays=observed_group(image,values,row,profile,draw)
                root=f"{row['index']:03d}-{profile['name']}-{draw}"
                product=save(output/(root+".npz"),arrays)
                match=output/(root+".json")
                write_json(match,{"input":product,"id":root,"case":row["index"],"source":row["source"]["id"],
                           "plan":declared,"box":row["box"],"profile":profile,"draw":draw,"roles":ROLES,
                           "physical_seeds":{key:sensor(row,profile,key,draw).noise_seed for key in
                                             ("exterior","pair","present","masked-fine","flat")},
                           "clean_linear_increment_RMS_DN16":actual,
                           "fingerprints":{k:fingerprint(v)for k,v in arrays.items()}})
                recorded.append(reference(match))
        if row["index"]%8==part:
            print(part,row["index"],round(actual,2),flush=True)
    write_json(ROOT/f"observation-shard-{part}.json",{"plan":declared,"records":recorded})
    print("completed shard",part,len(recorded),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    parser.add_argument("--part",type=int,choices=(0,1))
    args=parser.parse_args()
    make_plan() if args.plan else produce(args.part)
