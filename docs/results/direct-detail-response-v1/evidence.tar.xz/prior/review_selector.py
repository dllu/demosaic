"""Review natural textures, planted wires and both native GFX100S captures."""

import ast
from pathlib import Path
from statistics import mean
from time import monotonic
from types import ModuleType
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy.special import expit
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
import detail_selector as head
from evaluate_selector import (
    Cases,
    DISPLAY,
    FAMILIES,
    EARLIER,
    OUT,
    fixed,
    gains,
    load_heads,
    values,
)

ROI = (48, 48, 160, 160)
PUBLISHED = ("nominal", "heuristic", "local", "pooled", "spatial", "shuffled")
V120 = "a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb"


def crop(v, xywh):
    x, y, w, h = xywh
    return v[..., y : y + h, x : x + w]


def image(raw, wb, matrix, expo):
    r = display_crop(
        torch.as_tensor(raw[None].copy()),
        torch.as_tensor(wb[None]),
        torch.as_tensor(matrix[None]),
        (0, 0, 160, 160),
        exposure=expo,
    )
    return np.rint(np.clip(r * 255, 0, 255)).astype(np.uint8)


def board(cells, file):
    canvas = Image.new("RGB", (8 + 168 * len(cells), 192), "#eee")
    draw = ImageDraw.Draw(canvas)
    coords = []
    for i, (text, pixels) in enumerate(cells):
        x = 8 + i * 168
        assert pixels.shape == (160, 160, 3)
        canvas.paste(Image.fromarray(pixels), (x, 24))
        draw.text((x, 5), text, fill="#202020")
        coords.append({"label": text, "png_xywh": [x, 24, 160, 160]})
    canvas.save(file)
    return {"image": reference(file), "panels": coords}


def named_pixels(meta):
    with Image.open(checked(meta["image"])) as img:
        return {
            p["label"]: np.asarray(img.crop((x, y, x + w, y + h)))
            for p in meta["panels"]
            for x, y, w, h in [p["png_xywh"]]
        }


def correction(case, nets, policy, prior, *, force_full=False):
    r, d, p, features, origin = case
    nominal = p["nominal"]
    y, proposals, neutral = head.ingredients(p, d)
    f = gains(nets, features, None)
    chosen = {k: torch.tensor(v["locked"]["dose"]) for k, v in policy["arms"].items()}
    chosen["shuffled"] = chosen["spatial"]
    result = {"nominal": nominal}
    for label, gain in f.items():
        result[label] = head.render(
            y, proposals, neutral, gain if force_full else gain * chosen[label], nominal
        )
    if "scene_packed" in d:
        atlas = fixed.score.signatures(d, r)
    else:
        # The stored camera heuristic already used the full frame. Its exact
        # pixels are included via that older native board, never used as inputs.
        atlas = None
    if atlas is not None:
        result["heuristic"] = fixed.synthesis(nominal, *fixed.ingredients(p, d), atlas, prior)
    return result, {k: v.mean((1, 2)).tolist() for k, v in f.items()}


def fmt_current(arr, wb, matrix, roi, expo, role=0):
    return image(crop(arr[role], roi), wb, matrix, expo)


def exact(nets, lock, folder, reference_):
    current = read_json(checked(reference_))
    rows = current["rows"]
    cases = Cases("transfer")
    locked = lock["arms"]["spatial"]["locked"]["dose"]
    choice = locked if any(locked) else (1.0, 1.0)
    x = values(rows, "spatial", choice)["increment"] - values(rows, "nominal", (1, 1))["increment"]
    best = {
        rows[i]["id"]: label
        for i, label in ((int(x.argmin()), "best increment"), (int(x.argmax()), "worst increment"))
    }
    if len(best) < 2:
        best[rows[-1]["id"]] = "second native example"
    results = []
    for case in cases:
        r, d, p, _, origin = case
        if r["id"] not in best:
            continue
        result, diagnostic = correction(
            case, nets, lock, cases.heuristic, force_full=not any(locked)
        )
        render = noisy_malvar(
            {
                "packed": d["packed"],
                **{
                    k: np.broadcast_to(d[k], (len(d["packed"]), *d[k].shape)).copy()
                    for k in ("colors", "wb", "matrix")
                },
            }
        )
        fields = {"noisy": render, **result, "GT": d["target"]}
        exposure = 1 / r["profile"]["exposure"]
        names = {"noisy": "Noisy Malvar", "GT": "Exact GT"} | DISPLAY
        comparison = {}
        for role, branch in ((0, "present"), (2, "flat")):
            tmp = {
                k: fmt_current(v, d["wb"], d["matrix"], ROI, exposure, role)
                for k, v in fields.items()
            }
            comp = board(
                [(names[k], tmp[k]) for k in ("noisy", *PUBLISHED, "GT")],
                folder / f"{r['id']}-{branch}.png",
            )
            comparison[branch] = comp
            if role == 0:
                comparison["triplet"] = board(
                    [(names[k], tmp[k]) for k in ("noisy", "spatial", "GT")],
                    folder / f"{r['id']}-triplet.png",
                )
        results.append(
            {
                "fixture": r,
                "comparison": comparison,
                "roi": ROI,
                "exposure": exposure,
                "input": r["input"],
                "source": origin,
                "gates": diagnostic,
                "selection": best[r["id"]],
                "shown_dose": choice,
            }
        )
    return {"holdout": reference_, "rows": results, "selection_dose": choice}


def camera(nets, lock, folder):
    ref = reference(
        OUT.with_name("adaptive-junction-phase-v1") / "views-camera-all-references.json"
    )
    historical = read_json(checked(ref))["report"]["rows"]
    old = {r["id"]: r for r in historical}
    earlier = reference(EARLIER / "review-camera.json")
    older = {r["id"]: r for r in read_json(checked(earlier))["report"]["rows"]}
    rows = []
    cases = Cases("camera")
    for case in cases:
        r, d, p, _, origin = case
        identifier = r["id"]
        first = old[identifier]
        assert first["input"] == r["input"] and first["ROI"] == r["global_ROI"]
        checked(r["raw"])
        result, diagnostic = correction(case, nets, lock, cases.heuristic)
        roi = r["local_ROI"]
        frames = []
        for prior in first["native"]:
            expo = prior["exposure"]
            originals = named_pixels(prior)
            np.testing.assert_array_equal(
                fmt_current(result["nominal"], d["wb"], d["matrix"], roi, expo),
                originals["Local 50k"],
            )
            from_old = next(v for v in older[identifier]["native"] if v["exposure"] == expo)
            base = named_pixels(from_old)
            test = [(k, originals[k]) for k in ("Noisy (Malvar)", "V120 EMA")]
            out = lambda p: fmt_current(p, d["wb"], d["matrix"], roi, expo)
            test.append((DISPLAY["heuristic"], base["Whole-photo Bayer gate"]))
            test.extend((DISPLAY[k], out(v)) for k, v in result.items())
            test.extend(
                (k, originals[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in originals
            )
            frames.append(
                board(test, folder / f"{identifier}-x{expo:g}.png")
                | {"exposure": expo, "previous": prior, "heuristic_board": from_old}
            )
        change = {
            k: float(np.sqrt(np.mean(crop(v.astype(float) - result["nominal"], roi) ** 2)) * 65535)
            for k, v in result.items()
        }
        print(identifier, change, flush=True)
        rows.append(
            {
                "id": identifier,
                "raw": r["raw"],
                "input": r["input"],
                "model": origin,
                "ROI": r["global_ROI"],
                "local_ROI": roi,
                "sensor_box": r["sensor_box"],
                "noise": r["noise"],
                "changes_DN16": change,
                "gains": diagnostic,
                "native": frames,
            }
        )
    return {"standing_source": ref, "heuristic_standing": earlier, "rows": rows}


def wire_scorer():
    binding = reference(head.HERE.with_name("scene-mixture-wire-gaps-v1") / "scoring.py")
    src = checked(binding)
    tree = ast.parse(src.read_text(), filename=str(src))
    known = {"rms", "space", "remove_basis", "wire_bases", "WireMetric"}
    functions = [
        f for f in tree.body if isinstance(f, (ast.FunctionDef, ast.ClassDef)) and f.name in known
    ]
    assert {f.name for f in functions} == known
    env = ModuleType("scoped_wire_measure")
    env.__dict__.update(
        np=np,
        expit=expit,
        SCORED=np.s_[..., 64:192, 64:192],
        luma=lambda a, wb, m: head.luma(a, {"wb": wb, "matrix": m}),
    )
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(src), "exec"), env.__dict__)
    return binding, env.WireMetric


def wires(nets, lock):
    binding, wire_s = wire_scorer()
    data = Cases("wires")
    gathered = []
    for pack in data:
        r, d, _, _, where = pack
        geometry = r["fixture"]["geometry"]
        if geometry["family"] == "smooth-dip":
            d = d | {"support": np.ones_like(d["support"])}
        measure = wire_s(d, geometry)
        preds, _ = correction(pack, nets, lock, data.heuristic)
        gathered.append(
            {
                "id": r["id"],
                "fixture": r["fixture"],
                "source": where,
                "report": {k: measure(a) for k, a in preds.items()},
            }
        )
    keys = {k for r in gathered for k in r["report"]["nominal"]}
    means = {}
    for name in gathered[0]["report"]:
        means[name] = {
            k: mean(r["report"][name][k] for r in gathered if k in r["report"][name]) for k in keys
        }
        print(name, means[name], flush=True)
    return {"scorer": binding, "rows": gathered, "means": means}


if __name__ == "__main__":
    torch.set_num_threads(2)
    role = sys.argv[1]
    fit, nets = load_heads()
    cal = reference(OUT / "evaluate-calibration.json")
    policy = read_json(checked(cal))["policy"]
    loc = OUT / "native" / role
    loc.mkdir(exist_ok=True, parents=True)
    t0 = monotonic()
    if role == "camera":
        report = camera(nets, policy, loc)
    elif role == "exact":
        report = exact(nets, policy, loc, reference(OUT / "evaluate-transfer.json"))
    else:
        report = wires(nets, policy)
    write_json(
        OUT / f"review-{role}.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "calibration": cal,
            "report": report,
            "seconds": monotonic() - t0,
        },
    )
