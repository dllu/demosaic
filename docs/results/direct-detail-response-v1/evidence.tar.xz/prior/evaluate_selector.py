"""Compare matched learned gates, fixed heuristics and exact-target headroom."""

from dataclasses import dataclass
from itertools import product
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch
from torch.nn.functional import interpolate

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import detail_selector as head
from train_selector import normalized_gain
import mild_score as fixed
import score

OUT = head.OUT
EARLIER = fixed.OUT
FAMILIES = (*head.ARMS, "shuffled", "swapped", "oracle")
DISPLAY = {
    "nominal": "Local 50k",
    "heuristic": "Earlier whole-photo gate",
    "local": "Learned local",
    "pooled": "Learned pooled scene",
    "spatial": "Learned aligned scene",
    "shuffled": "Rolled alignment",
    "swapped": "Different photo",
    "oracle": "Exact-target diagnostic",
}


def load_heads(which="training"):
    bind = reference(OUT / f"fit-{which}/result.json")
    raw = read_json(checked(bind))
    result = {}
    for name, weight in raw["checkpoints"].items():
        state = torch.load(checked(weight), map_location="cpu", weights_only=True)
        net = head.Selector()
        net.load_state_dict(state["ema"])
        result[name] = (net.eval(), state["normalization"])
    return bind, result


@dataclass
class Cases:
    group: str

    def __post_init__(self):
        f = reference(OUT / "review-features.json")
        self.binding = f
        self.entries = read_json(checked(f))["groups"][self.group]["cases"]
        self.previous_lock = reference(EARLIER / "mild-calibration.json")
        self.heuristic = read_json(checked(self.previous_lock))["policy"]["specs"]["whole"][
            "chosen"
        ]

    def __iter__(self):
        for item, meta, pred, source in fixed.paired_items(self.group):
            if self.group == "camera":
                meta = {
                    k: (v[0] if k in ("colors", "wb", "matrix") else v) for k, v in meta.items()
                }
            info = self.entries[item["id"]]
            assert info["input"] == item["input"]
            with np.load(checked(info["features"]), allow_pickle=False) as f:
                feat = {k: torch.from_numpy(f[k]) for k in f.files}
            yield item, meta, pred, feat, source | {"feature": info["features"]}


def ideal(meta, predictions, ctxt, profile):
    """Minimize the station RGB task's luma surrogate with access to exact targets."""
    stat = head.training_payload(
        meta, predictions, profile, (ctxt["scene"].numpy(), ctxt["pooled"].numpy())
    )
    sharp_cap = stat["support"]
    limits = np.stack((sharp_cap, np.ones_like(sharp_cap)), axis=-1).astype(float)
    pa = np.concatenate((stat["linear"][0], stat["linear"][1]), axis=-1)
    pq = np.zeros((*pa.shape[:-1], 4, 4))
    pq[..., :2, :2] = stat["quad"][0]
    pq[..., 2:, 2:] = stat["quad"][1]
    pa *= 0.55
    pq *= 0.55
    pa[3:5, 3:5] += 1.35 * stat["p_linear"][3:5, 3:5]
    pq[3:5, 3:5] += 1.35 * stat["p_quad"][3:5, 3:5]
    gains = np.zeros_like(pa)
    cap = np.concatenate((limits[0], limits[1]), axis=-1)
    for _ in range(36):
        for axis in range(4):
            cross = (pq[..., axis, :] * gains).sum(axis=-1) - pq[..., axis, axis] * gains[..., axis]
            gains[..., axis] = np.clip(
                -(pa[..., axis] + cross) / np.maximum(1e-8, pq[..., axis, axis]), 0, cap[..., axis]
            )
    l, q = stat["linear"][2], stat["quad"][2]
    quiet = np.zeros_like(l, dtype=float)
    for _ in range(24):
        for axis in range(2):
            off = 1 - axis
            quiet[..., axis] = np.clip(
                -(l[..., axis] + q[..., axis, off] * quiet[..., off])
                / np.maximum(1e-8, q[..., axis, axis]),
                0,
                limits[2, ..., axis],
            )
    return torch.from_numpy(np.stack((gains[..., :2], gains[..., 2:], quiet)).astype(np.float32))


@torch.no_grad()
def gains(heads, ft, swapped):
    out = {mode: normalized_gain(net, ft, mode, norm) for mode, (net, norm) in heads.items()}
    net, norm = heads["spatial"]
    out["shuffled"] = normalized_gain(net, ft, "shuffled", norm)
    if swapped is not None:
        other = ft | {"scene": swapped}
        out["swapped"] = normalized_gain(net, other, "spatial", norm)
    return out


def deltas(items, gate):
    h, w = items.shape[-2:]
    v = interpolate(gate.permute(0, 3, 1, 2), size=(h, w), mode="bilinear", align_corners=False)
    return items * v.cpu().numpy()


def evaluate_case(case, heads, swap, heuristic):
    row, meta, pred, ft, prov = case
    assert pred["nominal"].shape[0] == len(ft["features"])
    y, items, _ = head.ingredients(pred, meta)
    fields = gains(heads, ft, swap)
    fields["oracle"] = ideal(meta, pred, ft, row["profile"])
    d = {k: deltas(items, gate) for k, gate in fields.items()}
    basic = fixed.score.signatures(meta, row)
    reference_ = fixed.synthesis(pred["nominal"], *fixed.ingredients(pred, meta), basic, heuristic)
    d["heuristic"] = np.stack((head.luma(reference_, meta) - y, np.zeros_like(y)), axis=1)
    b, t = [score.stats(v, meta) for v in (pred["nominal"], meta["target"])]
    d["nominal"] = np.stack((np.zeros_like(y), np.zeros_like(y)), axis=1)
    terms = {
        k: fixed.terms(t, b, fixed.coefficients(u[:, 0]), fixed.coefficients(u[:, 1]))
        for k, u in d.items()
    }
    return {
        "id": row["id"],
        "input": row["input"],
        "provenance": prov,
        "scores": terms,
        "mean_gains": {k: v.mean((1, 2)).tolist() for k, v in fields.items()},
    }


def values(rows, arm, dose):
    records = [r["scores"][arm] for r in rows]
    a, b = dose
    coeff = np.array([1, a, b, a * a, a * b, b * b])
    result = {
        m: np.sqrt(np.maximum(0, np.asarray([r[m] for r in records]) @ coeff)) for m in score.LIMITS
    }
    result.update(
        projection=np.asarray([r["response"] for r in records]) @ np.array([1, a, b]),
        true=np.asarray([r["truth"] for r in records]),
    )
    return result


def lock(rows):
    b = score.evaluate(values(rows, "nominal", (1, 1)))
    result = {}
    steps = (0.0, 0.125, 0.25, 0.5, 0.75, 1.0)
    for arm in head.ARMS:
        tried = []
        for dose in product(steps, repeat=2):
            s = score.evaluate(values(rows, arm, dose))
            tried.append(
                {
                    "dose": dose,
                    "scores": s,
                    "admissible": all(s[k] - b[k] <= u for k, u in score.LIMITS.items()),
                }
            )
        result[arm] = {
            "locked": max(
                (p for p in tried if p["admissible"]),
                key=lambda r: (r["scores"]["response_pp"], -r["scores"]["increment"]),
            ),
            "trials": tried,
        }
    return {"limits": score.LIMITS, "arms": result, "baseline": b}


def summary(rows, policy):
    chosen = {k: (k, (1.0, 1.0)) for k in ("nominal", "heuristic", *FAMILIES)}
    chosen.update({k + " locked": (k, r["locked"]["dose"]) for k, r in policy["arms"].items()})
    chosen.update(
        {
            k + " locked": (k, policy["arms"]["spatial"]["locked"]["dose"])
            for k in ("shuffled", "swapped")
        }
    )
    raw = {n: values(rows, *c) for n, c in chosen.items()}
    rng = np.random.default_rng(202611200846)
    n = len(rows)
    draw = np.vstack((np.arange(n), rng.integers(n, size=(12000, n))))

    def aggregate(z):
        return {k: np.sqrt(np.mean(z[k][draw] ** 2, axis=1)) for k in score.LIMITS} | {
            "response_pp": 100 * z["projection"][draw].sum(1) / z["true"][draw].sum(1)
        }

    mats = {k: aggregate(z) for k, z in raw.items()}

    def interval(z):
        return [float(z[0]), *np.quantile(z[1:], (0.025, 0.975)).tolist()]

    return {
        "configuration": chosen,
        "scores": {k: score.evaluate(z) for k, z in raw.items()},
        "contrasts": {
            n: {
                m: {metric: interval(r[metric] - mats[n][metric]) for metric in r}
                for m, r in mats.items()
            }
            for n in ("nominal", "heuristic", "local locked", "pooled locked", "spatial locked")
        },
    }


def collect(which, heads):
    data = Cases(which)
    swapped = []
    for case in data:
        swapped.append(case[3]["scene"])
    rows = []
    for i, case in enumerate(data):
        other = swapped[(i + len(swapped) // 2) % len(swapped)]
        assert case[3]["scene"].shape == other.shape
        rows.append(evaluate_case(case, heads, other, data.heuristic))
        if len(rows) % 8 == 0:
            print(which, len(rows), flush=True)
    return rows, data


def evaluate(group):
    t0 = monotonic()
    bind, nets = load_heads()
    prior = reference(OUT / "evaluate-calibration.json") if group == "transfer" else None
    rows, cases = collect(group, nets)
    policy = read_json(checked(prior))["policy"] if prior else lock(rows)
    scores = summary(rows, policy)
    print(
        policy["arms"]["local"]["locked"],
        policy["arms"]["pooled"]["locked"],
        policy["arms"]["spatial"]["locked"],
        flush=True,
    )
    for k, v in scores["scores"].items():
        print(k, v, flush=True)
    write_json(
        OUT / f"evaluate-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "head": reference(head.__file__),
            "fit": bind,
            "prior": prior,
            "features": cases.binding,
            "earlier_policy": cases.previous_lock,
            "summary": scores,
            "policy": policy,
            "rows": rows,
            "seconds": monotonic() - t0,
        },
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    evaluate(sys.argv[1])
