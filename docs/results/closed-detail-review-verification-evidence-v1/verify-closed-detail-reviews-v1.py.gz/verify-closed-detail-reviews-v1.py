"""Independent final archive/source/contact-pixel/statistics/link checks, no inference."""
import gzip
import re
import tarfile
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
output = repo/'docs/results/closed-detail-reviews-verification-v1.json'
assert not output.exists()
publications = [repo/'docs/results'/name/'publication.json' for name in [
    'neural-nuisance-guided-phase129-full-v1', 'coloured-fine-wire-v1']]
results = []
for binding, figures, sheets in zip(publications, [70, 40], [18, 10], strict=True):
    p = read_json(binding)
    assert p['viewing']['actually_viewed'] and p['viewing']['figures'] == figures
    assert len(p['images']) == figures and p['viewing']['contact_sheets'] == sheets
    for item in p['archives']:
        assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
    for item in p['images']:
        assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
    checked(p['viewer'])
    snapshots = p.get('source_snapshots', [p.get('frozen_source')])
    source_members = 0
    for snapshot in snapshots:
        with tarfile.open(checked(snapshot['archive']), 'r:gz') as tar:
            assert len(tar.getmembers()) == len(snapshot['members'])
            for member in snapshot['members']:
                assert tar.extractfile(member['member']).read() == checked(member['original']).read_bytes()
                source_members += 1
    receipt_members = 0
    if 'per_case_receipts' in p:
        snapshot = p['per_case_receipts']
        with tarfile.open(checked(snapshot['archive']), 'r:gz') as tar:
            assert len(tar.getmembers()) == len(snapshot['members']) == 2328
            for member in snapshot['members']:
                assert tar.extractfile(member['member']).read() == checked(member['original']).read_bytes()
                receipt_members += 1
    manifest = read_json(checked(p['viewing']['manifest']))
    indices = []
    for ref in p['viewing']['batches']:
        b = read_json(checked(ref))
        assert b['actually_viewed'] and b['notes'] and b['manifest'] == p['viewing']['manifest']
        indices.extend(b['sheets'])
    assert sorted(indices) == list(range(sheets))
    seen = set()
    channels = 0
    for sheet in manifest['sheets']:
        pixels = np.asarray(Image.open(checked(sheet['image'])).convert('RGB'))
        for cell in sheet['cells']:
            source = np.asarray(Image.open(checked(cell['source'])).convert('RGB'))
            assert checked(cell['source']).read_bytes() == checked(cell['published']).read_bytes()
            x, y, w, h = cell['xywh']
            assert source.shape == (h, w, 3)
            np.testing.assert_array_equal(pixels[y:y+h, x:x+w], source)
            assert cell['source']['path'] not in seen
            seen.add(cell['source']['path'])
            channels += source.size
    assert seen == {i['original']['path'] for i in p['images']}
    results.append({'publication': reference(binding), 'archives_exact': len(p['archives']),
                    'source_members_exact': source_members, 'per_case_receipt_members_exact': receipt_members,
                    'images_exact': figures, 'actually_viewed_sheets': sheets, 'contact_RGB_channels_exact': channels})

full = read_json(repo/'.cache/experiments/neural-nuisance-guided-phase129-full-review-v1/cross-study-comparison.json')
assert full['paired_input_cases_exact'] == 1164 and full['maximum_parent_metric_error'] == 0
fields = ['weak_gain', 'strong_gain', 'quiet_error_RMS_DN16', 'weak_increment_error_RMS_DN16', 'full_error_RMS_DN16']
count = 0
for mean in full['means']:
    rows = [r for r in full['rows'] if all(r[k] == mean[k] for k in ['profile', 'placement', 'method'])]
    assert len(rows) == 64
    for key in fields:
        assert abs(float(np.mean([r[key] for r in rows])) - mean[key]) < 1e-12
        count += 1
doc = read_json(repo/'.cache/guided-phase129-full-documentation-summary-v1.json')
for cell in doc['cells']:
    a, b = [cell['means'][k] for k in ['current-analytic', 'prior256-NN']]
    assert a['weak_increment_error_RMS_DN16'] > b['weak_increment_error_RMS_DN16']
far = next(c for c in doc['cells'] if (c['profile'], c['placement']) == ('iso400', 'far'))
assert far['paired_view_counts']['current-analytic']['weak_up_quiet_and_increment_not_up'] == 0

colour = repo/'.cache/experiments/coloured-fine-wire-neural-v1'
scores = read_json(colour/'scores-v1.json')
assert len(scores['rows']) == 400 and len(scores['means']) == 50
colour_fields = [k for k in scores['means'][0] if k not in ['profile', 'method']]
for mean in scores['means']:
    rows = [r for r in scores['rows'] if (r['profile'], r['method']) == (mean['profile'], mean['method'])]
    assert len(rows) == 8
    for key in colour_fields:
        assert abs(float(np.mean([r[key] for r in rows])) - mean[key]) < 1e-12
        count += 1
source_summary = read_json(colour/'paired-source-summary-v1.json')
for mean in source_summary['source_means']:
    rows = [r for r in scores['rows'] if all(r[k] == mean[k] for k in ['profile', 'source', 'method'])]
    assert len(rows) == 4
    for key in mean.keys()-{'profile', 'source', 'method'}:
        assert abs(float(np.mean([r[key] for r in rows])) - mean[key]) < 1e-12
        count += 1
signed = next(c for c in source_summary['contrasts'] if (c['profile'], c['source'], c['arm']) == ('iso1600', 1, 'conditional-local-t2'))
assert signed['fields']['weak_increment_error_RMS_DN16']['minimum_delta'] > 0
assert signed['fields']['weak_colour_orthogonal_RMS_DN16']['mean_delta'] > 0
assert abs(signed['fields']['weak_gain']['mean_delta']) < 3e-6

names = ['README.md', 'docs/current-model.md', 'docs/index.md', 'docs/research.md', 'docs/experiments.md',
         'docs/weak-detail-literature-2026-11.md', 'docs/neural-guided-phase-pooling.md',
         'docs/neural-guided-phase-full-panel.md', 'docs/coloured-fine-wire-benchmark.md',
         'docs/joint-fine-colour-support.md', 'diary/index.md',
         'diary/2026-11-16-23-10-59-full-guided-coloured-review.md']
links = 0
for name in names:
    path = repo/name
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        target = target.split('#')[0]
        if not target or '://' in target:
            continue
        resolved = (path.parent/target).resolve()
        assert resolved == output or resolved.exists(), (name, target)
        links += 1
result = {'script': reference(__file__), 'publications': results, 'independent_mean_fields': count,
          'local_MD_links_checked': links, 'paired_full_input_parent_cases': 1164,
          'coloured_independent_audit': reference(colour/'independent-audit-v1.json'),
          'new_neural_forwards': 0,
          'scope': 'Both completed reviews:110 actually viewed original native figures, exact archives/frozen executed sources/2328 per-case receipts, contact pixels, scalar means and current documentation links. Existing independent metric/physical-input audits retained. Full guided response/full-error gain has higher increment error; fresh signed-colour weak gain absent. Not new model training or general-camera validation.'}
write_json(output, result)
print(result)
