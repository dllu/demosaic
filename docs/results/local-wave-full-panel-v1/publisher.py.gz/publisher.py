"""Publish closed full-cohort evidence, byte-preserving receipts and native pixels."""
import copy,gzip,hashlib,html,io,json,shutil,tarfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from demosaic.archive_metrics import display,noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
R=Path.cwd();E=R/'.cache/experiments';OLD=R/'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-quality-v1/work/artifacts'
newsha='4d78e6302f6e72d68acb03fe58eb7106763b8129ccb059747ef5d2cfbd3ec1e1';oldsha='a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb'
def archive(src,dest):
 payload=src.read_bytes()
 with dest.open('xb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as z:z.write(payload)
 assert gzip.decompress(dest.read_bytes())==payload
 return {'original':reference(src),'published':reference(dest),'decompressed_bytes_exact':True}
def sources(src,dest):
 with tarfile.open(dest,'x:gz')as t:
  for p in sorted(src.rglob('*')):
   if p.is_file()and p.suffix=='.py':t.add(p,arcname=str(p.relative_to(src)))
 with tarfile.open(dest,'r:gz')as t:
  for m in t.getmembers():assert t.extractfile(m).read()==(src/m.name).read_bytes()
 return reference(dest)
def cpfigure(item,out,folder=None):
 item=copy.deepcopy(item);src=checked(item['image']);dest=out/(folder or '')/src.name;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb')as f:f.write(src.read_bytes())
 assert dest.read_bytes()==src.read_bytes();item['original_image']=item['image'];item['image']=reference(dest);return item
def gallery(out,items,title):
 body=['<!doctype html><meta charset="utf-8"><title>'+html.escape(title)+'</title><style>body{font:16px system-ui;background:#ddd;margin:20px}figure{margin:30px 0;overflow:auto}img{max-width:none}figcaption{margin:8px 0}a{color:#174d88}</style><h1>'+html.escape(title)+'</h1><p>One native pixel per image pixel. Use browser zoom 100%. Horizontal scrolling preserves pixels. Metadata is in manifest.json.</p>']
 for i in items:
  path=Path(i['image']['path']).relative_to(out);body.append('<figure><figcaption>'+html.escape(str(path))+'</figcaption><a href="'+str(path)+'"><img src="'+str(path)+'"></a></figure>')
 (out/'native-viewer.html').write_text('\n'.join(body)+'\n')
def rows(path):return[json.loads(s)for s in path.read_text().splitlines()]
def native_board(out,name,values,labels,data,metadata):
 arrays=[np.rint(display(v[...,48:208,48:208],data)[0].transpose(1,2,0)*255).astype(np.uint8)for v in values]
 canvas=Image.new('RGB',(8+168*len(values),192),'#eee');draw=ImageDraw.Draw(canvas);cells=[]
 for j,(a,label)in enumerate(zip(arrays,labels,strict=True)):
  assert a.shape==(160,160,3);x=8+j*168;canvas.paste(Image.fromarray(a),(x,24));draw.text((x,5),label,fill='black');cells.append({'label':label,'xywh':[x,24,160,160],'pixel_sha256':hashlib.sha256(a.tobytes()).hexdigest()})
 dest=out/(name+'.png');canvas.save(dest)
 with Image.open(dest)as im:encoded=np.asarray(im)
 for a,c in zip(arrays,cells,strict=True):
  x,y,w,h=c['xywh'];assert np.array_equal(encoded[y:y+h,x:x+w],a)
 return dict(metadata,image=reference(dest),panels=cells,ROI_xywh=[48,48,160,160],exposure=1,contrast=1,no_resize=True,display='Shared NumPy64 WB/matrix, clipped sRGB, round-to-nearest uint8')
# Closed analytic full panel.
p=E/'local-wave-panel-review-v1';prod=E/'local-validated-wave-panel-v1';out=R/'docs/images/local-wave-full-panel-v1';pub=R/'docs/results/local-wave-full-panel-v1';out.mkdir(exist_ok=False);pub.mkdir(exist_ok=False)
report=read_json(p/'report.json');items=[cpfigure(x,out)for x in report['finite_figures']+report['protected_real_figures']]
stress=read_json(p/'protected-stress-adoption.json');items +=[cpfigure(x,out,'stress')for x in stress['figures']]
for name in ['response-quiet.png','response-increment.png']:shutil.copyfile(p/name,out/name)
viewed=[str(Path(i['image']['path']).relative_to(out))for i in items if 'comparison' in Path(i['image']['path']).name or '/stress/' in i['image']['path']]
viewed +=[f'iso400-source{s}-far-triplet.png'for s in [1,7,2,4]]+['response-quiet.png','response-increment.png']
assert len(viewed)==68
write_json(out/'manifest.json',{'images':items,'source_report':reference(p/'report.json'),'audit':reference(p/'independent-audit.json'),'no_resize':True})
write_json(p/'viewing.json',{'actually_viewed':viewed,'count':len(viewed),'scope':'48 finite comparisons,8 protected real comparisons,4 finite triplets,6 maximum-correction stress boards and2 plots actually viewed. Remaining native triplets were audited byte-for-byte, not separately visually viewed.','findings':'Source1/2 drive low-prior far gains; most weaker structure and crossings remain absent. Higher-prior views mostly flat. Sky stays smooth, foliage painted, building soft. Local suppresses global cab ripples but leaves unsupported periodic modulation, particularly profile3879 stress crop.'})
gallery(out,items,'Full local/global conditional-wave panel')
archives=[]
for root,prefix,names in [(p,'review',['plan.json','launch.json','report.json','rows.json','summary.json','independent-audit.json','completed.json','matching-audit.json','protected-stress-adoption.json','viewing.json']), (prod,'producer',['plan.json','launch.json','analytic-model.json','analytic-model-v2.json','finite-scores.json','finite-scores-v2.json','collection.json','collection-v2.json','lineage-correction-result.json','parent-lineage-addendum.json'])]:
 for name in names:
  q=root/name
  if q.exists():archives.append(archive(q,pub/(prefix+'-'+name+'.gz')))
srcs=[sources(p/'work',pub/'review-executed-sources.tar.gz'),sources(prod/'work',pub/'producer-executed-sources.tar.gz')]
write_json(pub/'publication.json',{'archives':archives,'executed_sources':srcs,'manifest':reference(out/'manifest.json'),'publisher':reference(__file__),'new_inference_calls':0,'all_receipt_payloads_preserved':True})
# Broad V131, exact independent audit, local detail and fixed projection diagnostic.
p=E/'v131-broad-independent-v1';prod=E/'v131-broad-primary-v5';detail=E/'v131-broad-local-detail-v1';projection=E/'v131-adc-projection-color-v1';out=R/'docs/images/v131-broad-completed-v1';pub=R/'docs/results/v131-broad-completed-v1';out.mkdir(exist_ok=False);pub.mkdir(exist_ok=False)
audit=read_json(p/'work/audit-output/photo/result.json');items=[cpfigure(x,out)for x in audit['native_triplets']]
parent_records=rows(OLD/'photo/archive/records.jsonl');new_records=rows(Path(read_json(prod/'work/artifacts/photo/result.json')['archive']['path']))
for triplet in audit['native_triplets']:
 record=new_records[triplet['record_index']];idx=record['context']['ids'].index(triplet['source_id'])
 old=next(x for x in parent_records if x['context']==record['context']and x['model']['sha256']==oldsha)
 assert old['supervision_values']==record['supervision_values']
 with np.load(checked(record['supervision']),allow_pickle=False)as z:data={k:z[k][idx:idx+1]for k in z.files}
 a=np.load(checked(old['prediction']))[idx:idx+1];b=np.load(checked(record['prediction']))[idx:idx+1]
 name='bark'if'Coffee' in triplet['source']['title']else'fur'
 items.append(native_board(out,name+'-comparison',[noisy_malvar(data),a,b,data['target']],['Noisy Malvar','V120','V131','Exact synthetic GT'],data,{'source':triplet['source'],'source_id':triplet['source_id'],'current_record':record,'parent_record':old,'sample':idx,'conditioning':record['context']['condition'],'source_triplet':triplet}))
# Largest V131 ADC mean-error case, selected explicitly after numerical scoring.
newrecords=rows(Path(read_json(prod/'work/artifacts/color/result.json')['archive']['path']));oldrecords=rows(Path(read_json(OLD/'color/result.json')['archive']['path']))
new=next(r for r in newrecords if r['context']['case_index']==1001);old=next(r for r in oldrecords if r['context']==new['context']and r['model']['sha256']==oldsha);assert old['supervision_values']==new['supervision_values']
with np.load(checked(new['supervision']),allow_pickle=False)as z:data={k:z[k]for k in z.files}
a=np.load(checked(old['prediction']));b=np.load(checked(new['prediction']));projected=next(x for x in read_json(projection/'collection.json')['rows']if x['case']==1001);v=np.load(checked(projected['prediction']))
meta={'selection':'Largest V131 ADC-only absolute mean camera-RGB error, selected after scores. Case1001, h030-s0.98-l0.90,BGGR. Not a representative photo.','record':new,'parent_record':old,'projected_record':projected,'GT':'Exact constructed constant target','conditioning':new['context']['definition']['condition'],'WB':data['wb'].tolist(),'matrix':data['matrix'].tolist()}
items.append(native_board(out,'adc-color-outlier-comparison',[noisy_malvar(data),a,b,v,data['target']],['Noisy Malvar','V120','V131','V131 ADC projection','Exact constructed GT'],data,meta))
items.append(native_board(out,'adc-color-outlier-triplet',[noisy_malvar(data),b,data['target']],['Noisy Malvar','V131','Exact constructed GT'],data,meta))
# Exact adoption of same endpoint protected qualitative views and known targeted gain/cost.
endpoint=read_json(R/'docs/images/v131-endpoint-v1/manifest.json')
for item in endpoint['images']:
 name=item['name']
 if(name.startswith('main-')or name.startswith('mesh-'))and name.endswith('-comparison'):
  assert item['checkpoint']['sha256']==newsha;items.append(cpfigure(item,out,'protected'))
# Derive compact audited texture/color summaries with no quality threshold.
metrics={}
for stage in ['texture','color']:
 current=read_json(p/f'work/audit-output/{stage}/rows.json');control=read_json(R/f'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-independent-audit-v1/work/audit-output/{stage}/rows.json')
 control=[x for x in control if x['checkpoint_sha256']==oldsha];assert len(control)==len(current)
 for condition in ['adc-only','iso12800-prior']:
  for label,rr in [('V120',control),('V131',current)]:
   rr=[x for x in rr if x['condition']==condition]
   if stage=='color':
    case=max(rr,key=lambda x:max(abs(v)for v in x['metrics']['camera_RGB_mean_error']));val={'max_abs_mean_RGB_error_DN16':max(abs(v)for v in case['metrics']['camera_RGB_mean_error'])*65535,'worst_case':case,'cases':len(rr)}
   else:
    val={}
    for kind in ['carrier','flat']:
     subset=[x for x in rr if x['kind']==kind];keys=subset[0]['metrics'];val[kind]={'cases':len(subset),'arithmetic_means':{k:float(np.mean([x['metrics'][k]for x in subset]))for k in keys}}
   metrics[f'{stage}/{condition}/{label}']=val
write_json(p/'texture-color-summary.json',{'metrics':metrics,'scope':'Independent NumPy64 rows. Carrier means mix fixed periods/contrasts/levels; inspect per-case rows for failures. ADC repeats are deterministic duplicates, not independent sensor draws.','candidate_sha256':newsha,'control_sha256':oldsha})
write_json(out/'manifest.json',{'images':items,'photo_audit':reference(p/'work/audit-output/photo/result.json'),'endpoint_manifest':reference(R/'docs/images/v131-endpoint-v1/manifest.json'),'new_inference_calls':0,'no_resize':True})
gallery(out,items,'V131 completed broad review: native evidence')
archives=[]
for root,prefix,names in [(prod,'producer',['plan.json','launch.json','status.json','completed.json','compatibility.json']), (p,'audit',['plan.json','launch.json','completed.json','audited-comparisons-v2.json','photo-training-id-check.json','texture-color-summary.json']), (detail,'local-detail',['plan.json','launch.json','completed.json','work/local-detail/result-v1.json','work/local-detail/per-source-v1.json','work/local-detail/selected-inputs-v1.json']), (projection,'adc-projection',['plan.json','launch.json','collection.json','scores.json','run.py','output.log'])]:
 for name in names:
  q=root/name
  if q.exists():archives.append(archive(q,pub/(prefix+'-'+name.replace('/','-')+'.gz')))
for stage in ['photo','known','unseen','texture','color']:
 for root,prefix,names in [(prod/'work/artifacts'/stage,'producer-'+stage,['result.json','archive/records.jsonl']), (p/'work/audit-output'/stage,'audit-'+stage,['result.json','rows.json','paired-V120.json'])]:
  for name in names:
   q=root/name
   if q.exists():archives.append(archive(q,pub/(prefix+'-'+name.replace('/','-')+'.gz')))
srcs=[sources(root/'work',pub/(prefix+'-executed-sources.tar.gz'))for root,prefix in[(prod,'producer'),(p,'audit'),(detail,'local-detail'),(projection,'adc-projection')]]
write_json(pub/'publication.json',{'archives':archives,'executed_sources':srcs,'manifest':reference(out/'manifest.json'),'publisher':reference(__file__),'new_inference_calls':0,'all_receipt_payloads_preserved':True,'historical_live_snapshot_preserved':'docs/results/v131-broad-primary-v1/'})
print('Published two completed review cohorts; verify viewing addendum separately.')
