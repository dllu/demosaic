"""Run a fresh CUDA native review against the endpoint's archived input plan."""
from pathlib import Path
import os
import subprocess
import sys

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

BASE = Path(__file__).resolve().parent
old = BASE / "endpoint-native"
root = BASE / "endpoint-native-cuda"
old_ref = reference(old / "plan.json")
previous = read_json(checked(old_ref))
marker = reference(BASE / "matched-050000.json")
matched = read_json(checked(marker))
assert previous["training_plan"] == matched["plan"]
root.mkdir()
source = checked(previous["script"])
text = source.read_text()
changes = {
    "from demosaic.io import read_raw": "from demosaic.io import read_raw\nfrom demosaic.inference import _stage_tiled_cuda",
    '    os.sched_setaffinity(0, plan.get("CPU_affinity", [8, 9]))\n    os.nice(10)\n': '',
    '    model.eval().to(memory_format=torch.contiguous_format)': '    model = _stage_tiled_cuda(model.eval(), "cuda")',
    '            t = time.monotonic()\n            prediction = model(': '''            fields = {k: v.cuda() for k,v in args.items()}
            for k in ("packed", "variance"):
                fields[k] = fields[k].contiguous(memory_format=torch.channels_last)
            torch.cuda.synchronize()
            t = time.monotonic()
            prediction = model(''',
    '*(args[k] for k in ["packed", "variance", "colors", "wb", "matrix"])':
        '*(fields[k] for k in ["packed", "variance", "colors", "wb", "matrix"])',
    '            inference_seconds = time.monotonic() - t': '''            torch.cuda.synchronize()
            inference_seconds = time.monotonic() - t
            prediction = prediction.cpu()''',
    'CPU IEEE FP32 contiguous B4': 'CUDA IEEE FP32 channels-last B4',
}
for a,b in changes.items():
    assert a in text
    text = text.replace(a,b)
driver = root/"review_scene_native_cuda.py"
driver.write_text(text)
new = previous | {"root":str(root),"script":reference(driver),
    "sources":previous["sources"]|{old_ref["path"]:old_ref["sha256"],marker["path"]:marker["sha256"],
                                   str(driver):reference(driver)["sha256"]}}
plan = root / "plan.json"
write_json(plan,new)
env=os.environ|{"PYTHONPATH":f"{old}/work/src:{old}/work/scripts"}
result={}
for arm in ("none","spatial"):
    with (root/f"{arm}.log").open("x")as stream:
        subprocess.run([sys.executable,"-u",str(driver),str(plan),arm],env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
    result[arm]=reference(root/arm/"collection.json")
    assert read_json(checked(result[arm]))["checkpoint"]==matched["arms"][arm]["checkpoint"]
prior=BASE.parent/"expanded-scene-12000-native-v1"
closed=read_json(prior/"collection.json")
ready=dict(plan=reference(plan),training=marker,V120=closed["V120"],parent=closed["parent"],epochs=result,
           actual_native_viewed=False)
write_json(root/"collection.json",ready)
renderer=(prior/"render.py").read_text()
swaps={
    "assert training['trained'] and training['native_examples_per_arm']==96000":
        "assert training['training_complete'] and training['through_update']==50000",
    "training['endpoints'][arm]['EMA']": "training['arms'][arm]['checkpoint']",
    "Local-only 12k EMA": "Local-only 50k EMA", "Spatial 12k EMA": "Spatial 50k EMA",
    "spatial 12k EMA": "spatial 50k EMA", "ISO100 AHD, not GT": "ISO100 AHD reference",
}
for old,new in swaps.items():
    assert old in renderer
    renderer=renderer.replace(old,new)
file=root/"render.py"
file.write_text(renderer)
subprocess.run([sys.executable,"-u",str(file)],env=env,check=True)
