"""Publish viewed 50k crops without changing the original render or training receipts."""
from copy import deepcopy
from datetime import datetime
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

base=Path(__file__).resolve().parent
root=base/"endpoint-native-cuda"
target=Path("docs/results/scene-050000-native-v1")
images=Path("docs/images/scene-050000-native-v1")
proof=reference(root/"work/render/result.json")
report=read_json(checked(proof))
completion=reference("docs/results/scene-full-epoch-v1/paired-prefix-050000.json")
training=read_json(checked(completion))
assert training["matched_marker"]==report["matched_training"]
collections={k:read_json(checked(v)) for k,v in report["collections"].items()}
for k in ("none","spatial"):
    assert collections[k]["checkpoint"]==training["arms"][k]["checkpoint"]
    assert collections[k]["DINO_unchanged"] and collections[k]["weights"]=="EMA"
    assert "CUDA IEEE FP32" in collections[k]["scope"]
first={"development-0-shadows-crop0","development-1-iso12800-prior-crop0"}
text={
 "development-0-shadows-crop0":"Both endpoints keep the canopy seams. The fine suspension lines in the exact target remain faint or missing.",
 "development-1-iso12800-prior-crop0":"All four trained restores preserve a smooth blue sky. The spatial endpoint has a faint tonal gradient with no visible added texture.",
 "main-building-detail-main-building-detail":"No obvious added color. The finest building wires and braces stay soft.",
 "main-chain-link-fence-main-chain-link-fence":"Main fence crossings remain coherent. The spatial version shows little change in the finest junctions.",
 "main-foliage-main-foliage":"The main leaves retain similar shapes in both 50k arms. Fine foliage detail remains soft.",
 "main-overcast-sky-main-overcast-sky":"Both 50k endpoints keep a smooth sky with no visible periodic pattern or colored splotches.",
 "mesh-nominal-fine-green-mesh-left":"The rail is clear and most of the nearby mesh remains very weak.",
 "mesh-nominal-fine-green-mesh-right":"Some sloping lines are visible. Fine intersections are still inconspicuous.",
 "mesh-profile3879-fine-green-mesh-left":"Both 50k restorations retain faint short mesh diagonals with the transferred prior. The lower crossings remain soft.",
 "mesh-profile3879-fine-green-mesh-right":"The two directions are clearer with the transferred prior. The spatial image still lacks many of the crossings visible in the independent ISO100 references.",
}
target.mkdir()
images.mkdir()

def copy(ref):
    file=checked(ref)
    dst=images/file.name
    shutil.copyfile(file,dst)
    assert reference(dst)["sha256"]==ref["sha256"]
    return ref|{"path":dst.name}

dataset={
    k:{r["id"]:r["prediction"] for r in arm["records"]}
    for k,arm in collections.items()
}
boards=[]
for item in report["boards"]:
    name=item["id"]
    if name not in text:
        continue
    board=deepcopy(item)
    board["image"]=copy(board["image"])
    with Image.open(images/board["image"]["path"]) as im:
        for panel in board["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and max(x+w-im.width,y+h-im.height)<=0
    board["actual_viewing"]=text[name]
    if name not in first:
        x,y,w,h=board["case"]["ROI_xywh"]
        crop=np.s_[0,:,y:y+h,x:x+w]
        predictions={
            k:np.load(checked(records[board["observation"]]),allow_pickle=False)[crop].astype(float)
            for k,records in dataset.items()
        }
        board["spatial_RMS_DN16"]={k:float(np.sqrt(np.mean((predictions["spatial"]-predictions[k])**2))*65535)
                                   for k in ("V120","parent100k","none")}
    boards.append(board)
assert len(boards)==len(text)==10
triplets=[]
for item in report["triplets"]:
    if item["id"] in first:
        triplets.append(item | {key:copy(item[key]) for key in ("image","metadata")})
assert len(triplets)==2
write_json(images/"manifest.json", dict(boards=boards,triplets=triplets,checkpoints={k:v["checkpoint"] for k,v in collections.items()},
    policy="Final 50k outputs use CUDA IEEE FP32, archived V120 and Corpus 100k use CPU IEEE FP32.",
    creation_local=datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()))
archive=target/"evidence.tar.xz"
sources=[root/"plan.json",root/"collection.json",root/"review_scene_native_cuda.py",root/"render.py",
         root/"none.log",root/"spatial.log",base/"native-cuda-050000.log",base/"native_cuda_replay.py",Path(__file__),
         checked(proof),checked(completion),*(checked(x)for x in report["collections"].values())]
with tarfile.open(archive,"x:xz") as out:
    for f in sources:
        out.add(f,arcname=str(f.absolute().relative_to(Path.cwd())))
write_json(target/"publication.json", dict(
    matched_training=completion,render_receipt=proof,archive=reference(archive),plan=report["plan"],
    native_manifest=reference(images/"manifest.json"), final_weights="EMA",training_complete=True,
    development_numerical_complete=True,actual_standing_native_viewed=True, controlled64_complete=False,
    fixed427_and_measured_cameras_complete=False, review_policy="CUDA IEEE FP32", development_means=report["development_condition_means"],
    measured_forward_seconds={k:sum(x["inference_seconds"] for x in collections[k]["records"])for k in ("none","spatial")},
    standing_RGB_RMS_to_local50k_DN16={b["id"]:b["spatial_RMS_DN16"]["none"] for b in boards if b["id"] not in first},
))
