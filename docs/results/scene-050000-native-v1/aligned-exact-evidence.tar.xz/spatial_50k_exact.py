"""Test aligned and reversed scene context at the matched 50k endpoint."""
from pathlib import Path
from collections import defaultdict
import time
import numpy as np
import torch

from review_continuation import ROOT, KEYS, metrics
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

PREVIOUS = ROOT.with_name("green-covariance-refit-v1")
MATCHED = Path("docs/results/scene-full-epoch-v1/paired-prefix-050000.json")


def restore(models, arrays, box, profile):
    for model in models.values():
        model.base.set_noise(profile["shot"],profile["read"])
    camera = [torch.from_numpy(arrays[key]).cuda() for key in ("colors","wb","matrix")]
    packed, variance = [torch.from_numpy(arrays[key]).cuda().contiguous(memory_format=torch.channels_last)
                        for key in ("packed","variance")]
    count = len(packed)
    arguments = (packed,variance,*[a[None].expand(count,*a.shape)for a in camera])
    scene = torch.from_numpy(arrays["scene_packed"]).cuda()
    x,y,w,h = (i//2 for i in box)
    result = {"Local 50k": models["none"](*arguments).cpu().numpy()}
    witnesses = {}
    for title,field in (("Spatial 50k",scene),("Spatial 50k reversed",scene.flip((-1,-2)))):
        contexts, witness = [], []
        for role in packed:
            query = field.clone()
            query[:,y:y+h,x:x+w].copy_(role)
            assert torch.equal(query[:,y:y+h,x:x+w],role)
            witness.append(fingerprint(query))
            context = models["spatial"].encode_scene(query,*camera,long_side=1024,exposure=1.0)
            contexts.append(context)
        result[title] = models["spatial"](*arguments, scene=contexts, boxes_xywh=[box]*count).cpu().numpy()
        witnesses[title] = witness
    assert all(np.isfinite(output).all() for output in result.values())
    return result,witnesses


def compare(rows, left,right, pooled=False):
    rng=np.random.default_rng(202611191147)
    output={}
    all_keys = sorted({k for row in rows for k in row["metrics"][left]})
    for key in all_keys:
        both = np.array([[r["metrics"][m][key]for m in (left,right)]for r in rows
                         if r["metrics"][left].get(key) is not None and r["metrics"][right].get(key) is not None])
        if not len(both):continue
        select = np.vstack([np.arange(len(both)), rng.integers(len(both),size=(6500,len(both)))])
        scores=both[select].mean(1)
        if pooled and key.endswith("RMS_DN16"):
            scores=np.sqrt((both[select]**2).mean(1))
        change = scores[:,0]-scores[:,1]
        output[key]=dict(left=float(scores[0,0]),right=float(scores[0,1]), delta=float(change[0]),
                         interval=np.quantile(change[1:],[.025,.975]).tolist(),sources=len(both))
    return output


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root = ROOT / "spatial-50k-exact"
    root.mkdir()
    publication = reference(MATCHED)
    trained = read_json(checked(publication))
    fresh = reference(PREVIOUS / "fresh.json")
    old = reference(PREVIOUS / "transport-fresh.json")
    earlier = read_json(checked(old))
    stored = {r["index"]:r for r in earlier["rows"]}
    archive = read_json(checked(fresh))
    spec = read_json(checked(archive["plan"]))
    profile = spec["profile"]
    assert len(stored) == len(archive["rows"]) == 48
    models = {}
    for mode,r in trained["arms"].items():
        binding=r["checkpoint"]
        model,state=load_scene_checkpoint(checked(binding),weights="ema",expected_sha256=binding["sha256"])
        assert state["mode"]==mode and state["step"]==50000
        models[mode]=_stage_tiled_cuda(model,"cuda")
    rows=defaultdict(list)
    start=time.monotonic()
    with ieee_fp32():
        for i, record in enumerate(archive["rows"],start=1):
            n=record["source"]["index"]
            assert stored[n]["input"]==record["input"]
            with np.load(checked(record["input"]),allow_pickle=False) as f:
                args={k:f[k]for k in f.files}
            begin=time.monotonic()
            outputs,witness=restore(models,args,record["box"],profile)
            forward=time.monotonic()-begin
            with np.load(checked(stored[n]["predictions"]),allow_pickle=False)as p:
                old_out={k:p[v]for k,v in (("Local 47.5k","local"),("Spatial 47.5k","aligned"))}
            with np.load(checked(record["predictions"]),allow_pickle=False)as p:
                orig={k:p[v]for k,v in (("V120","v120"),("Corpus 100k","parent"))}
            scores={k:metrics(record,v,args)for k,v in (outputs|old_out|orig).items()}
            artifact=root/f'{n:02d}.npz'
            with artifact.open("xb")as stream:
                np.savez(stream,**outputs)
            rows[record["source"]["kind"]].append(
                dict(index=n,source=record["source"],input=record["input"],contexts=witness,
                     output=reference(artifact),seconds=forward,metrics=scores))
            if i%8==0:print(i,round(time.monotonic()-start,2),flush=True)
    summary={
        g:{left+" vs "+right:compare(items,left,right,pooled=(g=="natural"))for left,right in (
            ("Spatial 50k","Local 50k"),("Spatial 50k","Spatial 50k reversed"),
            ("Local 50k","Local 47.5k"),("Spatial 50k","Spatial 47.5k"),
            ("Spatial 50k","Corpus 100k"), ("Spatial 50k","V120"))}
        for g,items in rows.items()
    }
    write_json(root/"result.json",dict(
        training=publication, driver=reference(__file__), captures=fresh, matched_47500=old, policy="CUDA IEEE FP32 EMA",
        metrics=rows, summary=summary, noise=profile, seconds=time.monotonic()-start))

if __name__=="__main__":
    main()
