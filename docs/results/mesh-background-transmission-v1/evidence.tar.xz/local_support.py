"""Measure whether local Bayer support removes layer continuation inside gaps."""

import argparse
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from experiment import ROOT,PLAN,SIZE
from delivery import checked_guard,delivery,metrics
from layered import measure

BIND=ROOT/"local-plan.json"
WIDTH=64
STEP=32
CENTERS=np.arange(0,SIZE-WIDTH+1,STEP)+WIDTH//2


def freeze():
    write_json(BIND,{
        "driver":reference(__file__),"delivered":reference(ROOT/"delivery.json"),
        "core_fit":reference(ROOT/"layered.py"),"simulation":reference(PLAN),
        "block":WIDTH,"stride":STEP,"centers":CENTERS.tolist(),
        "weight":"Require positive prediction gains in both folds. Weight rises linearly from 0 at min z 1.5 to 1 at min z 3.0. Bilinear interpolate within supports and extend boundary weights to the field edge.",
        "scope":"Follow-up to the measured global transmission gap spill. Refit the same hypotheses within each window using only the original measured Bayer groups. Gate two fixed global predictions without changing their fitted amplitudes. No known gap masks enter the local support estimate.",
    })


def plane(packed):
    result=np.empty((SIZE,SIZE),packed.dtype)
    for i,v in enumerate(packed):
        y,x=divmod(i,2)
        result[y::2,x::2]=v
    return result


def support(raw, colors, profile, p, q, methods):
    scores={key:np.zeros((len(CENTERS),len(CENTERS)))for key in methods}
    for yy, y in enumerate(CENTERS):
        for xx,x in enumerate(CENTERS):
            window=np.s_[y-WIDTH//2:y+WIDTH//2,x-WIDTH//2:x+WIDTH//2]
            _,checks=measure(raw[window],colors,profile,p[window],q[window])
            for name, values in scores.items():
                fold=checks[name]["folds"]
                if all(r["gain"]>0 for r in fold):
                    values[yy,xx]=np.clip((min(r["z"]for r in fold)-1.5)/1.5,0,1)
    grids={}
    for name,values in scores.items():
        xpass=np.array([np.interp(np.arange(SIZE),CENTERS,row)for row in values])
        grid=np.array([np.interp(np.arange(SIZE),CENTERS,row)for row in xpass.T]).T
        grids[name]=(grid,values.tolist())
    return grids


def compare(shard):
    spec=read_json(BIND)
    assert checked(spec["driver"])==Path(__file__)
    data=read_json(checked(spec["delivered"]))
    output=ROOT/"localized"
    output.mkdir(exist_ok=True)
    samples=[]
    for item in data["cases"][shard::2]:
        observation=read_json(checked(item["observation"]))
        with np.load(checked(observation["readout"]),allow_pickle=False)as f:
            values={k:f[k]for k in ("packed","colors","wb","matrix","front","rear","gap","target","aligned_transmission","aligned_adaptive")}
        with np.load(checked(item["prediction"]),allow_pickle=False)as f:
            parent=f["parent"]
        cfa,wb,mat=[values[s]for s in ("colors","wb","matrix")]
        profile=item["profile"]
        trace_a=observation["fits"]["aligned"]["claims"]
        trace_b=observation["fits"]["shifted"]["claims"]
        fields={"wb":np.broadcast_to(wb,(4,3)),"matrix":np.broadcast_to(mat,(4,3,3))}
        results={"local-transmission":[],"local-guarded":[]}
        applied=[]
        for i,p in enumerate(parent):
            strict=checked_guard(trace_a[i],trace_b[i])
            selected=trace_a[i]["adaptive"]["chosen"]
            roles={
                "local-transmission":("transmission",values["aligned_transmission"][i]),
                "local-guarded":(selected,values["aligned_adaptive"][i] if strict else
                                              np.zeros_like(values["aligned_adaptive"][i])),
            }
            candidates={method for method,shape in roles.values()if np.any(shape)}
            fit=support(plane(values["packed"][i]),cfa,profile,values["front"],values["rear"],candidates) if candidates else {}
            notes={}
            for tag,(method,delta) in roles.items():
                if np.any(delta):
                    grid,knots=fit[method]
                    result,coeff=delivery(p,delta*grid,wb,mat)
                    notes[tag]={"mask_mean":float(grid.mean()),"grid":knots,"lift":coeff}
                else:
                    result=p
                    notes[tag]={"mask_mean":0.,"grid":None,"lift":0.}
                results[tag].append(result)
            applied.append(notes)
        results={method:np.stack(vals)for method,vals in results.items()}
        path=output/(item["id"]+".npz")
        with path.open("xb")as f:
            np.savez(f,**results)
        all_score={}
        for method,out in results.items():
            all_score[method]=metrics(out,values["target"],fields,values["front"],values["rear"],values["gap"],parent)
        samples.append({"id":item["id"],"noise":profile,"localized":reference(path),
                        "estimate":applied,"metrics":all_score,"observation":item["observation"]})
        print(item["id"],[(m,round(s["gap_addition_RMS_DN16"],3))for m,s in all_score.items()],flush=True)
    assert len(samples)==24
    write_json(ROOT/f"local-{shard}.json",{"plan":reference(BIND),"cases":samples})


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plan",action="store_true")
    p.add_argument("--shard",type=int,choices=(0,1))
    args=p.parse_args()
    freeze() if args.plan else compare(args.shard)
