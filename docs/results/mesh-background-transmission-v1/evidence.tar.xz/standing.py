"""Replay the standing GFX crops with the donor geometry and layer fit."""

import argparse
from pathlib import Path
import sys

import numpy as np
from PIL import Image,ImageDraw
import torch

from demosaic._mesh_frequency import ADJACENT_SEARCH,adjacent_prior,infer_prior
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_refinement import _overlap_correction
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from delivery import checked_guard,delivery,softmask
from experiment import ROOT
from layered import integrate_footprint,measure,shift_pair

REPO=ROOT.parents[2]
BIND=ROOT/"standing-plan.json"
PRIOR=ROOT.parent/"local-mesh-phase-evidence-v1"/"camera.json"
PORT=ROOT.parent/"donor-phase-transport-v1"/"port.json"
SHOW=ROOT.parent/"mesh-donor-tint-v2"/"camera.json"
PLANS=("affine","transmission","guarded-adaptive")


def freeze():
    inputs=read_json(PRIOR)
    package=read_json(PORT)
    restored=read_json(SHOW)
    assert len(inputs["views"])==len(package["cases"])==len(restored["views"])==8
    write_json(BIND,{
        "driver":reference(__file__),"raw_view_plan":reference(PRIOR),"adjacent_replay":reference(PORT),
        "native_panels":reference(SHOW),"delivery":reference(ROOT/"delivery.py"),
        "fit_code":reference(ROOT/"layered.py"),
        "package_sources":{str(p):reference(p)["sha256"] for p in
            (REPO/"src/demosaic"/name for name in ("mesh_refinement.py","_mesh_frequency.py","_mesh_profiles.py"))},
        "scope":"Perform conditional re-fit for regions in which the earlier packaged adjacent-donor correction admits a mesh. Reproduce the stored package output to bind the exact central geometry. All arms share the same old local-only 2k parent and independently demosaiced ISO100 AHD/JPEG display references. No original RAW decode or fitting to a clean camera reference.",
    })


def crop(value,box,by=1):
    x,y,w,h=(i//by for i in box)
    return value[...,y:y+h,x:x+w]


def plane(value):
    h,w=(i*2 for i in value.shape[-2:])
    out=np.empty((h,w),dtype=value.dtype)
    for k in range(4):
        a,b=divmod(k,2)
        out[a::2,b::2]=value[k]
    return out


def basis_guarded_raw(parent,raw,variance,cfa,box,roi,noise,span,reference_shape):
    trunk=crop(parent,roi)
    shapes={n:trunk for n in PLANS}
    if np.array_equal(trunk,reference_shape):
        return shapes,None,{m:0. for m in PLANS}
    prior=infer_prior(raw,cfa,box,noise,span=span)
    delta,carriers=_overlap_correction(parent,raw,variance,cfa,box,roi,noise,prior)
    if delta is None or not delta.any():
        prior=adjacent_prior(raw,cfa,box,noise)
        delta,carriers=_overlap_correction(parent,raw,variance,cfa,box,roi,noise,prior,search=ADJACENT_SEARCH)
    assert delta is not None and carriers is not None
    np.testing.assert_array_equal(trunk+delta,reference_shape)
    x,y,w,h=box
    value=plane(crop(raw,box,2))
    mask=(np.indices((h,w))[1]//2)%4==0
    groups=[]
    for p,q in (carriers,shift_pair(*carriers,.31)):
        p,q=(integrate_footprint(h,w,c)for c in (p,q))
        groups.append(measure(value,cfa,noise,p,q,reserve=mask))
    return groups,carriers,None


def composite(parent,raw,variance,cfa,box,roi,noise,span,reference_shape,wb,matrix):
    stages,carriers,no_effect=basis_guarded_raw(parent,raw,variance,cfa,box,roi,noise,span,reference_shape)
    if carriers is None:
        return stages,None,no_effect
    (inc,aligned),(_,shifted)=stages
    x,y,w,h=box
    rx,ry,rw,rh=roi
    in_box=(rx-x,ry-y,rw,rh)
    taper=np.zeros((h,w))
    crop(taper,in_box)[:]=softmask(rh,rw)
    trunk=crop(parent,box)
    out,scales={},{}
    for name in PLANS:
        if name=="guarded-adaptive":
            contribution=inc["adaptive"] if checked_guard(aligned,shifted) else np.zeros_like(inc["adaptive"])
        else:
            contribution=inc[name]
        fixed,coeff=delivery(trunk,contribution,wb[0],matrix[0],taper)
        out[name]=crop(fixed,in_box)
        scales[name]=coeff
    return out,{"carriers":[vars(c)for c in carriers],"aligned":aligned,"shifted":shifted},scales


def image(archived,output,values,wb,matrix,exposure):
    panels=[p for p in archived["panels"]if p["label"] in (
                "ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Local-only2k",
                "Crop helper + adjacent","ISO100 AHD, not GT","ISO100 camera JPEG")]
    before=np.asarray(Image.open(checked(archived["image"]))).copy()
    names={"affine":"Affine rear fit","transmission":"Wire transmission","guarded-adaptive":"Guarded wire fit"}
    added=[]
    for key,new in values.items():
        cell=display_crop(torch.from_numpy(new[None]),torch.from_numpy(wb),
                         torch.from_numpy(matrix),[0,0,160,160],exposure=exposure)
        added.append((names[key],np.rint(np.clip(cell,0,1)*255).astype(np.uint8)))
    fields=[]
    for column in panels:
        x,y,w,h=column["png_xywh"]
        assert w==h==160
        fields.append((column["label"].replace("ISO100 AHD, not GT","ISO100 AHD reference"),before[y:y+h,x:x+w]))
        if column["label"]=="Crop helper + adjacent":
            fields.extend(added)
    actual=Image.new("RGB",(8+168*len(fields),192),"#eeeeee")
    diagram=ImageDraw.Draw(actual)
    rectangles=[]
    for k,(name,value) in enumerate(fields):
        x=8+168*k
        actual.paste(Image.fromarray(value),(x,24))
        diagram.text((x,5),name,fill="black")
        rectangles.append({"label":name,"png_xywh":[x,24,160,160]})
    path=output/(archived["id"]+".png")
    actual.save(path)
    encoded=np.asarray(Image.open(path))
    for r,(_,tile) in zip(rectangles,fields,strict=True):
        x,y,w,h=r["png_xywh"]
        np.testing.assert_array_equal(encoded[y:y+h,x:x+w],tile)
    return reference(path),rectangles


def compare():
    torch.set_num_threads(1)
    spec=read_json(BIND)
    assert checked(spec["driver"])==Path(__file__)
    for name,sha in spec["package_sources"].items():
        checked({"path":name,"sha256":sha})
    source,replay,previous=(read_json(checked(spec[k]))for k in ("raw_view_plan","adjacent_replay","native_panels"))
    old={r["id"]:r for r in previous["views"]}
    package={r["id"]:r for r in replay["cases"]}
    assert source["checkpoint"]["sha256"]==previous["checkpoint"]["sha256"]
    dest=ROOT/"standing-native"
    dest.mkdir()
    records=[]
    for r in source["views"]:
        key=r["id"]
        row,pkg=old[key],package[key]
        assert pkg["input"]==r["input"]
        box,roi,noise=r["query"],r["ROI"],r["noise"]
        with np.load(checked(r["input"]),allow_pickle=False)as f:
            raw,variance,cfa=(f[k][0]for k in ("packed","variance","colors"))
            wb,matrix=[f[k]for k in ("wb","matrix")]
        with np.load(checked(pkg["native_array"]),allow_pickle=False)as f:
            fallback=f["adjacent"]
        parent=np.load(checked(r["parent"]),allow_pickle=False)[0]
        assert fingerprint(parent)==pkg["fingerprints"]["parent"]
        values,trace,scales=composite(parent,raw,variance,cfa,box,roi,noise,pkg["noise"]["donor_span"],
                                      fallback,wb,matrix)
        render,display=image(row,dest,values,wb,matrix,r["exposure"])
        trunk=crop(parent,roi)
        delta=lambda x:float(np.sqrt(np.mean(x.astype(np.float64)**2))*65535)
        result={"id":key,"roi":roi,"query":box,"noise":noise,"display_exposure":r["exposure"],
                "raw":r["input"],"parent":r["parent"],"packaged":pkg["native_array"],
                "displacements_DN16":{k:delta(v-trunk)for k,v in values.items()},
                "model_delta_vs_adjacent_DN16":{k:delta(v-fallback)for k,v in values.items()},
                "trace":trace,"scales":scales,"image":render,"panels":display,"old_png":row["image"]}
        records.append(result)
        print(key,result["displacements_DN16"],flush=True)
    assert len(records)==8
    write_json(ROOT/"standing.json",{"plan":reference(BIND),"native_boards":records,
                                    "training_parent":source["checkpoint"],"actual_viewing":"pending"})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else compare()
