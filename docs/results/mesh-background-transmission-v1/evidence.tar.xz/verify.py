"""Verify the physical fit and reserve isolation on exact native fields."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import reference,write_json
from demosaic.prediction_archive import fingerprint
import layered
from experiment import PLAN, ROOT, carrier


def check():
    size=96
    y,x=np.indices((size,size),dtype=np.float64)
    front,rear=(layered.integrate_footprint(size,size,c) for c in
        (carrier(.6,16.7,.29,.91),carrier(2.1,13.2,.71,.70)))
    bg=np.stack([.04+.00023*x-.00016*y,.056-.00032*x+.00018*y,.06+.00029*x])
    color=np.array([.055,.050,.071])[:,None,None]
    steel=np.array([.031,.069,.045])[:,None,None]
    strong=.5*front
    actual=.24*(1-strong)*rear*(steel-bg)
    rgb=(1-strong)*bg+strong*color+actual
    labels=((0,1,1,2),(2,1,1,0),(1,0,2,1),(1,2,0,1))
    noise={"shot":.00008,"read":2.56e-8}
    hold=((x.astype(int)//2+y.astype(int)//2)%2)!=0
    saved=layered.fit
    summary=[]
    for cfa in labels:
        calls=[]
        def track(a,b):
            calls.append((fingerprint(a),fingerprint(b)))
            return saved(a,b)
        layered.fit=track
        t=layered.bayer(rgb,cfa)
        output,stamp=layered.measure(t,cfa,noise,front,rear)
        common=tuple(calls[:len(calls)//2])
        calls.clear()
        injected=t.copy()
        injected[hold]+=.002*rear[hold]
        _,altered=layered.measure(injected,cfa,noise,front,rear)
        assert common==tuple(calls[:len(calls)//2])
        assert stamp["transmission"]["folds"][0]["opacity"] == altered["transmission"]["folds"][0]["opacity"]
        assert stamp["transmission"]["folds"][0]["z"] != altered["transmission"]["folds"][0]["z"]
        assert stamp["transmission"]["accepted"]
        np.testing.assert_allclose(output["transmission"],actual,atol=1.e-11,rtol=0)
        summary.append({"CFA":cfa,"maximum_clean_transmission_error":float(abs(output["transmission"]-actual).max())})
    layered.fit=saved
    write_json(ROOT/"verification.json",{"plan":reference(PLAN),"driver":reference(__file__),
        "layout_checks":summary,"training_arguments_identical_under_heldout_change":True,
        "native_integration":16,"exact_planted_transmission":.24})


if __name__=="__main__":
    check()
