"""Show the measured effect of local support on the same native test crops."""

import sys
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from experiment import ROOT,ROI

from report_scene_wave_guides import native_board


def render():
    summary=read_json(ROOT/"local-summary.json")
    present=read_json(checked(summary["source"]))
    arms={row["id"]:row for row in present["cases"]}
    chosen={row["id"]:row for source in summary["localized"] for row in read_json(checked(source))["cases"]}
    prior=read_json(ROOT/"native/result.json")
    output=ROOT/"local-native"
    output.mkdir()
    pairs=[]
    for sample in prior["boards"]:
        identifier,role_str=sample["id"].rsplit("-role",1)
        role=int(role_str)
        item=arms[identifier]
        local=chosen[identifier]
        record=read_json(checked(item["observation"]))
        with np.load(checked(record["readout"]),allow_pickle=False)as f:
            values={k:f[k][role:role+1]if k in ("packed","variance")else f[k][None]
                     for k in ("packed","variance","colors","wb","matrix")}
            target=f["target"][role]
        with np.load(checked(item["prediction"]),allow_pickle=False)as f:
            globals_=[f[name][role]for name in ("parent","affine","transmission")]
        with np.load(checked(local["localized"]),allow_pickle=False)as f:
            masked=f["local-transmission"][role]
        keys=("photo","parent","CFA","noise","selection","role","observation","source_patch_offset")
        details={k:sample[k]for k in keys}
        pairs.append(native_board(output,sample["id"],[noisy_malvar(values)[0],*globals_,masked,target],
                  values,details|{"localized":local["localized"],"global_filter":item["prediction"]},
                  labels=("Noisy Malvar","Corpus 100k EMA","Affine rear fit","Wire transmission",
                          "Local transmission","Exact GT"),
                  triplet_indices=(0,4,5),exposure=4,contrast=2,roi=(16,16,160,160)))
    write_json(output/"result.json",{"driver":reference(__file__),"summary":reference(ROOT/"local-summary.json"),"boards":pairs})


if __name__=="__main__":
    render()
