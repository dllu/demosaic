"""Cross-fitted additive and translucent wire models on the measured Bayer grid."""

import numpy as np

from demosaic._mesh_profiles import Carrier

METHODS=("additive", "affine", "transmission", "adaptive")
OPACITIES=(.06,.12,.18,.24,.30,.40)
Z_MIN=2.5


def integrate_footprint(height,width,carrier):
    """Average a Gaussian wire ribbon over the native photosite footprint."""
    y,x=np.indices((height,width),dtype=np.float64)
    x-=.5*(width-1)
    y-=.5*(height-1)
    fx,fy=carrier.frequency
    base=fx*x+fy*y-carrier.offset
    total=np.zeros_like(base)
    for dx in (-.375,-.125,.125,.375):
        for dy in (-.375,-.125,.125,.375):
            p=base+dx*fx+dy*fy
            total+=np.exp(-.5*((p-np.rint(p))/carrier.width)**2)
    return total/16.


def basis(n):
    """Smooth quadratic splines with a partition of unity on the fitting grid."""
    xy=np.linspace(0,4,n)
    def bs(z):
        v=abs(z)
        return np.where(v<=.5,.75-v*v,np.maximum(0.,1.5-v)**2*.5)
    feat=bs(xy[:,None]-np.arange(-1,6))
    result=np.einsum("hi,wj->hwij",feat,feat).reshape(n,n,-1)
    return result


def cfa_channels(colors,n):
    py,px=np.indices((n,n))
    return np.asarray(colors).reshape(2,2)[py%2,px%2]


def bayer(rgb,colors):
    channels=cfa_channels(colors,rgb.shape[-1])
    y,x=np.indices(channels.shape)
    return rgb[channels,y,x]


def fit(design, target):
    coef,_,_,_=np.linalg.lstsq(design,target,rcond=1e-8)
    assert np.isfinite(coef).all()
    return coef


def shift_pair(front,rear,amount):
    """An optional measured phase-reserve intervention shifts the rear only."""
    return front,Carrier(rear.frequency,(rear.offset+amount)%1,rear.width)


def fields(front,rear,backdrop,front_alpha=.50):
    cover=front_alpha*front
    visible=(1-cover)[...,None]
    null=np.concatenate((visible*backdrop,cover[...,None]),axis=-1)
    sine=visible[...,0]*rear
    return cover,visible,null,sine


def supported(views):
    return all(row["z"]>Z_MIN and row["gain"]>0 for row in views)


def measure(plane,colors,noise,front,rear,reserve=None):
    h,w=plane.shape
    assert h==w
    y,x=np.indices(plane.shape)
    cfa=cfa_channels(colors,h)
    assert np.isfinite(plane).all()
    design=basis(h)
    _,_,null,q=fields(front,rear,design)
    xx,yy=(x-(w-1)/2)/(w/2),(y-(h-1)/2)/(h/2)
    q_affine=np.stack((q,q*xx,q*yy),axis=-1)
    if reserve is None:
        reserve=x<0
    side=(x//2+y//2)%2
    candidates={k:[]for k in METHODS[:-1]}
    increments={k:[]for k in METHODS[:-1]}
    for index in (0,1):
        fitting=(side==index)&~reserve
        holding=(side!=index)&~reserve
        masks=[(fitting&(cfa==k),holding&(cfa==k))for k in range(3)]
        color_weights=[1./(noise["shot"]*max(.0001,float(plane[t].mean()))+noise["read"])for t,_ in masks]
        null_setup=[]
        for k,(train,held) in enumerate(masks):
            Xt=null[train]
            yt=plane[train]
            q_basis=np.linalg.pinv(Xt,rcond=1e-8)
            null_setup.append((Xt,yt,q_basis,null[held],plane[held],color_weights[k]))
        displacements={}
        checks={}
        for method in ("additive","affine","transmission"):
            strength_bank=OPACITIES if method=="transmission" else (0.,)
            evidence=[]
            for amount in strength_bank:
                err=0.
                proposed=[]
                for color,(train,held) in enumerate(masks):
                    Xt,yt,pinv,Xh,yh,wt=null_setup[color]
                    if method=="transmission":
                        layer=np.concatenate((null.copy(),(q*amount)[...,None]),axis=-1)
                        layer[...,:design.shape[-1]]*=1-amount*rear[...,None]
                        coeff=fit(layer[train],yt)
                        bg=design@coeff[:design.shape[-1]]
                        value=amount*q*(coeff[-1]-bg)
                        estimate=layer[train]@coeff
                    else:
                        full=q_affine[...,:1]if method=="additive" else q_affine
                        phase=full[train]
                        residual=phase-Xt@(pinv@phase)
                        alpha=fit(residual,yt-Xt@(pinv@yt))
                        value=full@alpha
                        estimate=Xt@(pinv@(yt-phase@alpha))+phase@alpha
                    err+=wt*float(np.sum((estimate-yt)**2))
                    proposed.append(value)
                evidence.append((err,amount,np.stack(proposed)))
            _,amount,inc=min(evidence,key=lambda entry:entry[0])
            dot=energy=0.
            for color,(train,held) in enumerate(masks):
                Xt,yt,pinv,Xh,yh,wt=null_setup[color]
                prediction=inc[color,held]-Xh@(pinv@inc[color,train])
                residual=yh-Xh@(pinv@yt)
                dot+=wt*float(prediction@residual)
                energy+=wt*float(prediction@prediction)
            checks[method]={"gain":2*dot-energy,"z":dot/max(1.e-18,energy)**.5,"opacity":float(amount)}
            displacements[method]=inc
        for key,item in checks.items():
            candidates[key].append(item)
            increments[key].append(displacements[key])
    selection="affine"
    if supported(candidates["transmission"]) and all(
          t["gain"]>a["gain"]+1 for t,a in zip(candidates["transmission"],candidates["affine"],strict=True)):
        selection="transmission"
    trace={k:{"folds":v,"accepted":supported(v)}for k,v in candidates.items()}
    trace["adaptive"]=trace[selection]|{"chosen":selection}
    result={k:np.mean(v,axis=0) if trace[k]["accepted"] else np.zeros((3,h,w))
            for k,v in increments.items()}
    return result | {"adaptive":result[selection]},trace
