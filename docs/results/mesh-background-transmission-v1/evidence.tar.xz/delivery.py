"""Compare native wire delivery above a fixed Corpus 100k checkpoint."""

import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
from scipy.ndimage import gaussian_filter
import torch

from demosaic.archive_metrics import linear_rgb, photometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from experiment import PLAN, PRE, ROOT, ROLES
from layered import METHODS

sys.path.insert(0,str(PRE))
from evaluate import setup_models

DELIVERY=ROOT/"delivery-plan.json"
ROI=(16,16,160,160)
POLICIES=("parent",*METHODS,"guarded-adaptive")
LUMA=np.array([.2126,.7152,.0722])


def freeze():
    base=PRE/"pilot/plan.json"
    write_json(DELIVERY,{
        "driver":reference(__file__),"simulation":reference(PLAN),
        "parent":read_json(base)["models"]["100k"],"parent_origin":reference(base),
        "observations":reference(ROOT/"raw-summary.json"),
        "profiles":POLICIES,"precision":"CUDA IEEE FP32 B4, channels last",
        "delivery":"Recover the missing measured luminance component, using the same Gaussian band, projection and 14-pixel taper for each hypothesis. Guarded adaptive separately requires both observed gains over the same method at a rear phase shifted 0.31 cycle. Guard added after seeing several no-rear accepts in running simulation logs. Input RAW and fitted coefficients are fixed.",
    })


def highpass(rgb):
    rgb=np.asarray(rgb,np.float64)
    return rgb-gaussian_filter(rgb,(0,2.5,2.5),mode="reflect")


def softmask(h,w):
    def one(n):
        p=np.clip(np.minimum(np.arange(n)+.5,n-.5-np.arange(n))/14,0,1)
        return p**2*(3-2*p)
    return one(h)[:,None]*one(w)[None,:]


def delivery(parent,increment,wb,matrix,taper=None):
    if not np.any(increment):
        return parent,0.
    tc=matrix.astype(np.float64)*wb[None,:]
    inverse=np.linalg.inv(tc)
    true_luma=lambda x: np.einsum("c,cj,jyx->yx",LUMA,tc,x)
    parent_band=true_luma(highpass(parent))
    projected=true_luma(highpass(increment))
    roi=softmask(*parent_band.shape) if taper is None else taper
    projected-=np.sum(projected*roi)/np.sum(roi)
    weight=np.sum(roi*projected**2)
    have=np.sum(roi*parent_band*projected)/max(weight,1.e-18)
    coefficient=float(np.clip(1-have,0.,.90))
    correction=coefficient*roi*projected
    rgb=inverse.sum(axis=1)[:,None,None]*correction
    assert np.max(abs(rgb.sum(axis=(1,2))))<1e-11
    outcome=(parent.astype(np.float64)+rgb).astype(parent.dtype)
    return outcome,coefficient


def checked_guard(aligned,shifted):
    if not aligned["adaptive"]["accepted"]:
        return False
    chosen=aligned["adaptive"]["chosen"]
    claim=aligned[chosen]["folds"]
    opponent=shifted[chosen]["folds"]
    return all(a["gain"]>b["gain"]+1. for a,b in zip(claim,opponent,strict=True))


def metrics(all_rgb,targets,fields,front,rear,gap,base):
    scored=np.s_[...,16:176,16:176]
    target=linear_rgb(targets,fields)[scored]
    restoration=linear_rgb(all_rgb,fields)[scored]
    raw_parent=linear_rgb(base,fields)[scored]
    luminance=lambda x:np.einsum("c,bchw->bhw",LUMA,x)
    x,y=luminance(restoration),luminance(target)
    note=(x-x[3:])-(y-y[3:])
    true=(y-y[3:])
    sqrt=lambda v:float(65535*np.sqrt(np.mean(v**2)))
    phases=np.s_[16:176,16:176]
    wire=(rear[phases]>.38)&(gap[phases]>0)
    junction=wire&(front[phases]>.50)
    void=gap[phases]==0
    assert wire.any() and junction.any() and void.any()
    return {
        "full_increment_RMS_DN16":[sqrt(row)for row in note[:3]],
        "wire_increment_RMS_DN16":[sqrt(row[wire])for row in note[:3]],
        "junction_increment_RMS_DN16":[sqrt(row[junction])for row in note[:3]],
        "gap_addition_RMS_DN16":sqrt((x-luminance(raw_parent))[2,void]),
        "no_rear_correction_RMS_DN16":sqrt(x[3]-luminance(raw_parent)[3]),
        "projected_increment_dot":[float(np.sum((x[i]-x[3])*true[i]))for i in range(3)],
        "exact_increment_squared":[float(np.sum(v*v))for v in true[:3]],
        "rendered_psnr":photometry(all_rgb*4,fields|{"target":targets*4})["srgb_psnr"].tolist()
    }


@torch.inference_mode()
def run():
    os.sched_setaffinity(0,[17,18])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,4.5*2**30/torch.cuda.get_device_properties(0).total_memory))
    plan=read_json(DELIVERY)
    assert checked(plan["driver"])==Path(__file__)
    raw=read_json(checked(plan["observations"]))
    assert raw["plan"]==plan["simulation"]
    model=setup_models({"models":{"100k":plan["parent"]}})["100k"]
    records=[r for p in raw["shards"]for r in read_json(checked(p))["observations"]]
    output=ROOT/"delivered"
    output.mkdir()
    paired=[]
    kernels=("packed","variance","colors","wb","matrix")
    started=time.monotonic()
    with ieee_fp32():
        for observation in records:
            spec=read_json(checked(observation))
            keys=(*kernels,"front","rear","gap","target",*[k for policy in METHODS for k in ("aligned_"+policy,)])
            with np.load(checked(spec["readout"]),allow_pickle=False)as data:
                inputs={k:data[k]for k in keys}
            assert all(fingerprint(v)==spec["arrays"][k]for k,v in inputs.items())
            cfa,wb,matrix=[inputs[k]for k in ("colors","wb","matrix")]
            query=[]
            for key in kernels:
                value=torch.from_numpy(inputs[key]).cuda()
                if key in ("packed","variance"):
                    value=value.contiguous(memory_format=torch.channels_last)
                else:
                    value=value[None].expand(4,*value.shape)
                query.append(value)
            profile=spec["profile"]
            model.set_noise(profile["shot"],profile["read"])
            parent=model(*query).cpu().numpy()
            assert parent.shape==inputs["target"].shape and np.isfinite(parent).all()
            color_fields={"wb":np.broadcast_to(wb,(4,3)),"matrix":np.broadcast_to(matrix,(4,3,3))}
            current={"parent":parent}
            quantities={}
            for label in POLICIES[1:]:
                estimates=np.copy(inputs[f"aligned_{label if label in METHODS else 'adaptive'}"])
                if label=="guarded-adaptive":
                    for j in range(4):
                        if not checked_guard(spec["fits"]["aligned"]["claims"][j],spec["fits"]["shifted"]["claims"][j]):
                            estimates[j]=0.
                fitted=[delivery(p,t,wb,matrix) for p,t in zip(parent,estimates,strict=True)]
                views,gains=zip(*fitted,strict=True)
                current[label]=np.stack(views)
                quantities[label]=gains
            acquired={k:metrics(v,inputs["target"],color_fields,inputs["front"],inputs["rear"],inputs["gap"],parent)
                      for k,v in current.items()}
            npz=output/(spec["case"]+".npz")
            with npz.open("xb")as file:
                np.savez(file,**current)
            paired.append({"observation":observation,"cases":list(ROLES),"prediction":reference(npz),"id":spec["case"],
                 "source":spec["source"],"profile":profile,"fit_scales":quantities,"metrics":acquired})
            print(spec["case"],round(time.monotonic()-started,2),flush=True)
    assert len(paired)==48
    write_json(ROOT/"delivery.json",{"plan":reference(DELIVERY),"cases":paired,"observations":192,
                                    "measurement_wall_seconds":time.monotonic()-started})


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plan",action="store_true")
    freeze() if p.parse_args().plan else run()
