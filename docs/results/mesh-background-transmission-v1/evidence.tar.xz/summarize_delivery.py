"""Report paired wire, junction and ghosting errors on the preserved comparisons."""

import argparse
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from delivery import ROI,metrics
from experiment import ROOT
from report_scene_wave_guides import native_board

FULL=ROOT/"delivery.json"
MEASURES=("full_increment_RMS_DN16","wire_increment_RMS_DN16","junction_increment_RMS_DN16",
          "gap_addition_RMS_DN16","no_rear_correction_RMS_DN16")


def statistics(values):
    rng=np.random.default_rng(3961883)
    cols=rng.integers(len(values),size=(5000,len(values)))
    return {"mean":np.asarray(values.mean(0)).tolist(),
            "median":np.asarray(np.median(values,axis=0)).tolist(),
            "interval_95":np.percentile(values[cols].mean(1),[2.5,97.5],axis=0).tolist()}


def reduce(localized=False):
    original=read_json(FULL)
    measured={}
    additions=[]
    lookup={}
    rows=original["cases"]
    if localized:
        for j in (0,1):
            name=ROOT/f"local-{j}.json"
            additions.append(reference(name))
            lookup.update({row["id"]:row for row in read_json(checked(additions[-1]))["cases"]})
        assert len(lookup)==48
    for name in ("iso400","iso6400"):
        devices=[v for v in rows if v["profile"]["name"]==name]
        deltas=[]
        assert len(devices)==24
        scales={}
        if localized:
            for n in ("transmission","guarded-adaptive"):
                m="local-transmission" if n=="transmission" else "local-guarded"
                scales[n]=(np.mean([lookup[r["id"]]["metrics"][m]["gap_addition_RMS_DN16"]for r in devices])/
                           np.mean([r["metrics"][n]["gap_addition_RMS_DN16"]for r in devices]))
        for row in devices:
            all_score=dict(row["metrics"])
            if localized:
                all_score.update(lookup[row["id"]]["metrics"])
                capture=read_json(checked(row["observation"]))
                with np.load(checked(capture["readout"]),allow_pickle=False)as npz:
                    fields={k:npz[k]for k in ("wb","matrix","target","front","rear","gap")}
                channels={k:np.broadcast_to(fields[k],(4,*fields[k].shape))for k in ("wb","matrix")}
                with np.load(checked(row["prediction"]),allow_pickle=False)as npz:
                    base=npz["parent"]
                    for key,scale in scales.items():
                        corrected=base+scale*(npz[key]-base)
                        all_score[sweep_name(key)]=metrics(corrected,fields["target"],channels,
                                                          fields["front"],fields["rear"],fields["gap"],base)
            deltas.append(all_score)
        report={}
        for method in deltas[0]:
            record=[p[method]for p in deltas]
            base=[p["parent"]for p in deltas]
            former=[p["affine"]for p in deltas]
            row={}
            for key in MEASURES:
                current,saved,affine=(np.array([entry[key]for entry in values])
                                      for values in (record,base,former))
                row[key]={"absolute":statistics(current),"vs_parent":statistics(current-saved),
                          "vs_affine":statistics(current-affine)}
            response=np.array([v["projected_increment_dot"]for v in record]).sum(0)/np.maximum(
                1e-12,np.array([v["exact_increment_squared"]for v in record]).sum(0))
            row["pooled_signed_response"]=response.tolist()
            report[method]=row
        measured[name]={"variants":report,"matched_gap_scales":scales,"sample_count":len(devices)}
    write_json(ROOT/("local-summary.json"if localized else "summary.json"),{
        "source":reference(FULL),"localized":additions,"driver":reference(__file__),
        "mean_and_two_sided_source_bootstrap":measured,
        "scope":"Each bootstrap sample resamples each complete source, including the same corresponding baseline in paired errors. Scalar matched-gap controls use the known-zero gap only for diagnostic level matching.",
    })


def sweep_name(key):
    return key+"-gap-matched-scalar"


def render():
    book=read_json(FULL)
    parent=read_json(checked(book["plan"]))["parent"]
    data=[x for x in book["cases"]if x["profile"]["name"]=="iso6400"]
    delta=lambda case: case["metrics"]["affine"]["wire_increment_RMS_DN16"][0] - case["metrics"]["transmission"]["wire_increment_RMS_DN16"][0]
    options=[(r,0,"two largest transmissive wire-error gains over affine")for r in sorted(data,key=delta,reverse=True)[:2]]
    options += [(max(data,key=lambda v:v["metrics"]["transmission"]["gap_addition_RMS_DN16"]),2,"largest added variation inside known gap")]
    options += [(max(data,key=lambda v:v["metrics"]["transmission"]["no_rear_correction_RMS_DN16"]),3,"largest false correction with no rear wire")]
    output=ROOT/"native"
    output.mkdir()
    boards=[]
    for case,role,rule in options:
        witness=read_json(checked(case["observation"]))
        with np.load(checked(witness["readout"]),allow_pickle=False)as f:
            inputs={k:f[k][role:role+1] if k in ("packed","variance")else f[k][None]
                    for k in ("packed","variance","colors","wb","matrix")}
            target=f["target"][role]
        with np.load(checked(case["prediction"]),allow_pickle=False)as f:
            paths=[f[k][role]for k in ("parent","affine","transmission","guarded-adaptive")]
        boards.append(native_board(output,case["id"]+f"-role{role}",[noisy_malvar(inputs)[0],*paths,target],inputs,
                    {"parent":parent,"photo":case["source"]["source"],"CFA":case["source"]["pattern"],"noise":case["profile"],
                     "selection":rule,"role":case["cases"][role],"prediction":case["prediction"],
                     "observation":case["observation"],"source_patch_offset":[32,32]},
                    labels=("Noisy Malvar","Corpus 100k EMA","Affine rear fit","Wire transmission",
                            "Guarded wire fit","Exact GT"),triplet_indices=(0,3,5),
                    exposure=4,contrast=2,roi=ROI))
    write_json(output/"result.json",{"driver":reference(__file__),"delivery":reference(FULL),"boards":boards})


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("reduce","local","render"))
    args=p.parse_args()
    {"reduce":reduce,"local":lambda:reduce(True),"render":render}[args.action]()
