"""Apply local transmission support to the same real-camera candidates."""

import argparse
from pathlib import Path

import numpy as np
from PIL import Image,ImageDraw
import torch

from demosaic._mesh_profiles import Carrier
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from delivery import delivery,softmask
from experiment import ROOT
from layered import integrate_footprint,measure
from local_support import CENTERS,WIDTH,SIZE
from standing import BIND,crop,plane

PLAN=ROOT/"standing-local-plan.json"


def freeze():
    write_json(PLAN,{
        "driver":reference(__file__),"global_real":reference(ROOT/"standing.json"),
        "synthetic_local":reference(ROOT/"local-plan.json"),
        "geometry_source":reference(BIND),
        "scope":"Replay native guarded geometry. Local transmission weights use 64 pixel overlapping tiles and the same rule as simulation. The camera phase reserve remains withheld from all tile fits. Compare the same lift on the 2k trunk and on the established adjacent result.",
    })


def check_windows(raw,colors,noise,front,rear,reserve):
    weights=np.zeros((len(CENTERS),len(CENTERS)))
    for iy,y in enumerate(CENTERS):
        for ix,x in enumerate(CENTERS):
            region=np.s_[y-WIDTH//2:y+WIDTH//2,x-WIDTH//2:x+WIDTH//2]
            _,scored=measure(raw[region],colors,noise,front[region],rear[region],reserve=reserve[region])
            views=scored["transmission"]["folds"]
            if all(v["gain"]>0 for v in views):
                weights[iy,ix]=np.clip((min(v["z"]for v in views)-1.5)/1.5,0.,1.)
    along=np.array([np.interp(np.arange(SIZE),CENTERS,lane)for lane in weights])
    return np.array([np.interp(np.arange(SIZE),CENTERS,lane)for lane in along.T]).T,weights.tolist()


def run():
    torch.set_num_threads(1)
    scope=read_json(PLAN)
    assert checked(scope["driver"])==Path(__file__)
    former=read_json(checked(scope["global_real"]))
    folder=ROOT/"standing-local-native"
    folder.mkdir()
    saved=[]
    for row in former["native_boards"]:
        box,roi=(row[name]for name in ("query","roi"))
        px,py,w,h=box
        rx,ry,rw,rh=roi
        local_x,local_y=rx-px,ry-py
        sub_x,sub_y=(int(v-16)//2*2 for v in (local_x,local_y))
        support_box=(sub_x,sub_y,SIZE,SIZE)
        roi_sub=(local_x-sub_x,local_y-sub_y,rw,rh)
        trace=row["trace"]
        with np.load(checked(row["raw"]),allow_pickle=False)as original:
            raw=original["packed"][0]
            cfa=original["colors"][0]
            wb,mat=[original[k]for k in ("wb","matrix")]
        net=np.load(checked(row["parent"]),allow_pickle=False)[0]
        with np.load(checked(row["packaged"]),allow_pickle=False)as old:
            adjacent=old["adjacent"]
        query=crop(net,box)
        nearby=crop(query,support_box)
        base=crop(nearby,roi_sub)
        np.testing.assert_array_equal(crop(net,roi),base)
        parent={"Local only":base,"Local + adjacent":adjacent}
        weights=None
        measure_gain=0.
        if trace is not None:
            value=plane(crop(raw,box,2))
            full_reserve=(np.indices((h,w))[1]//2)%4==0
            p,q=(integrate_footprint(h,w,Carrier(**d))for d in trace["carriers"])
            detail,note=measure(value,cfa,row["noise"],p,q,reserve=full_reserve)
            assert note==trace["aligned"]
            pred=crop(detail["transmission"],support_box)
            if np.any(pred):
                m,weights=check_windows(crop(value,support_box),cfa,row["noise"],
                          crop(p,support_box),crop(q,support_box),crop(full_reserve,support_box))
                mask=np.zeros((SIZE,SIZE))
                crop(mask,roi_sub)[:]=softmask(rh,rw)
                for label,predicted in parent.copy().items():
                    start=nearby.copy()
                    crop(start,roi_sub)[:]=predicted
                    merged,gain=delivery(start,pred*m,wb[0],mat[0],mask)
                    parent[label]=crop(merged,roi_sub)
                    if label=="Local + adjacent":
                        measure_gain=gain
        note={k:float(65535*np.sqrt(np.mean((v.astype(float)-b)**2)))for (k,v),b in
                 zip(parent.items(),(base,adjacent),strict=True)}
        render=render_board(row,parent,wb,mat,folder)
        saved.append({"id":row["id"],"roi":roi,"query":box,"noise":row["noise"],
                      "RGB_RMS_DN16_relative_to_own_parent":note,"native_tiles":weights,
                      "added_to_adjacent_coef":measure_gain,"render":render,
                      "unchanged_background":trace is None})
        print(row["id"],note,flush=True)
    assert len(saved)==8
    write_json(ROOT/"standing-local.json",{"plan":reference(PLAN),"native_boards":saved})


def render_board(old,new,wb,mat,output):
    pixels=np.asarray(Image.open(checked(old["image"]))).copy()
    kept=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Local-only2k","Crop helper + adjacent",
          "Wire transmission","ISO100 AHD reference","ISO100 camera JPEG")
    panes=[]
    for row in old["panels"]:
        name=row["label"]
        if name in kept:
            x,y,w,h=row["png_xywh"]
            panes.append((name,pixels[y:y+h,x:x+w]))
        if name=="Wire transmission":
            for name,values in new.items():
                rgb=display_crop(torch.from_numpy(values[None]),torch.from_numpy(wb),torch.from_numpy(mat),
                                [0,0,160,160],exposure=old["display_exposure"])
                panes.append((name,np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)))
    board=Image.new("RGB",(8+168*len(panes),192),"#eeeeee")
    text=ImageDraw.Draw(board)
    labels=[]
    for i,(label,values)in enumerate(panes):
        x=8+168*i
        board.paste(Image.fromarray(values),(x,24))
        text.text((x,5),label,fill="black")
        labels.append({"label":label,"png_xywh":[x,24,160,160]})
    out=output/(old["id"]+".png")
    board.save(out)
    reread=np.asarray(Image.open(out))
    for row,(_,values) in zip(labels,panes,strict=True):
        x,y,w,h=row["png_xywh"]
        np.testing.assert_array_equal(reread[y:y+h,x:x+w],values)
    return {"image":reference(out),"panels":labels}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plan",action="store_true")
    freeze() if p.parse_args().plan else run()
