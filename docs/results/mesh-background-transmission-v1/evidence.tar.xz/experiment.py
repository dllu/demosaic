"""Add weak radiometric mesh layers to protected-by-split natural backgrounds."""

import argparse
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic._mesh_profiles import Carrier
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from layered import METHODS,OPACITIES,Z_MIN,bayer,integrate_footprint,measure,shift_pair

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/"scene-local-contrast-2400-v1"
PLAN=ROOT/"simulation-plan.json"
SIZE=192
ROI=np.s_[16:176,16:176]
BLACK=.03
ROLES=("transmissive","additive","broken","no-rear")


def freeze():
    source=PRE/"evaluation-plan.json"
    data=read_json(source)
    by_cfa=defaultdict(list)
    for row in data["rows"]:
        by_cfa[row["camera"]["pattern"]].append(row)
    rows=[]
    for pattern, entries in by_cfa.items():
        for i in range(6):
            # Spread through each fixed held-out layout without ranking outcomes.
            src=entries[i*2]
            idx=src["index"]
            rows.append({"source":src["source"],"pattern":pattern,"index":idx,
                         "photo":reference(PRE/"observations"/f"{idx:03d}-iso400-coupled.json"),
                         "geometry_seed":80725057+idx*19403,
                         "noise_seeds":[62811329+idx*14997+i*1901 for i in range(8)]})
    assert len(rows)==24 and len({r["source"]["id"] for r in rows}) == 24
    write_json(PLAN,{
        "driver":reference(__file__),"fit_source":reference(ROOT/"layered.py"),
        "source_photo_panel":reference(source),"inputs":rows,"roles":ROLES,
        "roi":[16,16,160,160],"native_size":SIZE,
        "noise":[{"name":"iso400","shot":.00008,"read":2.56e-8},
                 {"name":"iso6400","shot":.00128,"read":6.5536e-6}],
        "opacity_bank":OPACITIES,"gate_z":Z_MIN,
        "matching_control_scope":"Same measured background across roles. A natural image is used as the exact base within each four-role capture group. Both models receive the same registered foreground and rear geometry. Inference gets no clean background, wire color, transmission coefficient or true gap.",
    })


def carrier(angle,period,offset,width):
    return Carrier((float(np.cos(angle)/period),float(np.sin(angle)/period)),
                   float(offset),float(width/period))


def textures(case):
    src=read_json(checked(case["photo"]))
    assert src["source"]==case["source"]["id"]
    with np.load(checked(src["input"]),allow_pickle=False)as data:
        backdrop=data["target"][1,:,32:224,32:224].astype(np.float64)
        colors,wb,matrix=(data[k] for k in ("colors","wb","matrix"))
    q=float(np.quantile(np.maximum(0,backdrop),.85))
    if q > .00005:
        backdrop=.012+.075*np.clip(backdrop/q,0,2)
    else:
        backdrop=.018+np.maximum(0,backdrop)
    RNG=np.random.default_rng(case["geometry_seed"])
    tilt=RNG.uniform(-.28,.28)
    front=carrier(.75+tilt,RNG.uniform(16,20),RNG.random(),RNG.uniform(.8,1.2))
    rear=carrier(2.1+tilt,RNG.uniform(12,17),RNG.random(),RNG.uniform(.55,.98))
    front_field,rear_field=(integrate_footprint(SIZE,SIZE,item)for item in (front,rear))
    med=np.median(backdrop,axis=(1,2))
    post_color=np.array([.68,.79,.66])*med+.009
    wire_color=np.array([.86,1.12,.84])*med+.004
    opacity=RNG.uniform(.13,.31)
    dy,dx=RNG.uniform(-25,25,2)
    yy,xx=np.indices((SIZE,SIZE),dtype=np.float64)
    shift=np.hypot(xx-95.5-dx,(yy-95.5-dy)*.8)
    gap=np.clip((shift-RNG.uniform(22,38))/9,0,1)
    gap=gap**2*(3-2*gap)
    f=.50*front_field
    q=(1-f)*rear_field
    no_rear=(1-f)*backdrop+f*post_color[:,None,None]
    transmitted=opacity*q*(wire_color[:,None,None]-backdrop)
    additive=q*np.array([-.0028,.0036,.0022])[:,None,None]
    target=np.stack((no_rear+transmitted,no_rear+additive,no_rear+transmitted*gap[None],no_rear)).astype(np.float32)
    assert np.min(target) > 0
    return target, (colors,wb,matrix), (front,rear), (front_field,rear_field), gap, opacity


def adc(value,profile,seed):
    rng=np.random.default_rng(seed)
    shot, read=profile["shot"],profile["read"]
    pixels=shot*rng.poisson(value/shot)+rng.normal(size=value.shape)*np.sqrt(read)
    quant=np.rint(np.clip(BLACK+(1-BLACK)*pixels,0,1)*65535)
    return ((quant/65535-BLACK)/(1-BLACK)).astype(np.float32)


def pack(value):
    return np.stack([value[...,y::2,x::2]for y in (0,1)for x in (0,1)],axis=-3)


def score(inc,truth,colors):
    true=bayer(truth,colors)[ROI]
    y=bayer(inc,colors)[ROI]
    ref=float(np.sum(true**2))
    return {"increment_rms_DN16":float(np.sqrt(np.mean((y-true)**2))*65535),
            "no_correction_rms_DN16":float(np.sqrt(np.mean(true**2))*65535),
            "exact_power":ref,"dot":float(np.sum(y*true)),
            "proposal_rms_DN16":float(np.sqrt(np.mean(y**2))*65535)}


def collect(shard):
    spec=read_json(PLAN)
    assert checked(spec["driver"])==Path(__file__)
    checked(spec["fit_source"])
    folder=ROOT/"observations"
    folder.mkdir(exist_ok=True)
    records=[]
    for row in spec["inputs"][shard::2]:
        target, calibration, carriers, geometry, gap, opacity=textures(row)
        front,rear=geometry
        cfa,wb,matrix=calibration
        for j,profile in enumerate(spec["noise"]):
            raw=np.stack([adc(bayer(t,cfa),profile,row["noise_seeds"][4*j+i])for i,t in enumerate(target)])
            variance=profile["shot"]*np.maximum(0,pack(raw))+profile["read"]
            fits={}
            arrays={"target":target,"wb":wb,"matrix":matrix,"colors":cfa,"packed":pack(raw),
                    "variance":variance.astype(np.float32),"front":front,"rear":rear,"gap":gap}
            for option, (pf,qf) in (("aligned",(front,rear)),
                                    ("shifted",(front,integrate_footprint(SIZE,SIZE,shift_pair(*carriers,.31)[1])))):
                policies=defaultdict(list)
                proofs=[]
                for i,measurement in enumerate(raw):
                    output,trace=measure(measurement,cfa,profile,pf,qf)
                    proofs.append(trace)
                    for key,value in output.items():
                        policies[key].append(value.astype(np.float32))
                for key,estimates in policies.items():
                    arrays[f"{option}_{key}"]=np.stack(estimates)
                role_metrics={}
                for key in METHODS:
                    role_metrics[key]=[score(v,target[i]-target[3],cfa)
                                       for i,v in enumerate(policies[key])]
                    delta=arrays[f"{option}_{key}"][2,:,16:176,16:176]
                    zero_gap=gap[ROI]==0.
                    role_metrics[key][2]["false_gap_RMS_DN16"]=float(np.sqrt(np.mean(delta[:,zero_gap]**2))*65535)
                fits[option]={"claims":proofs,"roles":role_metrics}
            key=f"{row['index']:03d}-{profile['name']}"
            result=folder/(key+".npz")
            with result.open("xb")as stream:
                np.savez(stream,**arrays)
            entry=folder/(key+".json")
            write_json(entry,{"plan":reference(PLAN),"source":row,"profile":profile,"readout":reference(result),
                "case":key,"fits":fits,"phases":[vars(line)for line in carriers],
                "true_opacity":float(opacity),"arrays":{k:fingerprint(v)for k,v in arrays.items()}})
            records.append(reference(entry))
            print(key,[(m,[r[m]['accepted']for r in fits['aligned']['claims']])for m in METHODS],flush=True)
    assert len(records)==24
    write_json(ROOT/f"shard-{shard}.json",{"plan":reference(PLAN),"observations":records})


def summary():
    files=[ROOT/f"shard-{k}.json"for k in (0,1)]
    row=[read_json(checked(binding))for file in files for binding in read_json(file)["observations"]]
    grouped={}
    assert len(row)==48
    for prior in ("iso400","iso6400"):
        grouped[prior]={}
        conditions=[r for r in row if r["profile"]["name"]==prior]
        for guide in ("aligned","shifted"):
            method={}
            for label in METHODS:
                out={}
                for role, name in enumerate(ROLES):
                    values=[r["fits"][guide]["roles"][label][role]for r in conditions]
                    numerator=sum(b["dot"]for b in values)
                    denominator=sum(b["exact_power"]for b in values)
                    out[name]={"accepted":sum(r["fits"][guide]["claims"][role][label]["accepted"]for r in conditions),
                        "paired_response":numerator/denominator if denominator else None}
                    for key in values[0]:
                        if key not in {"dot","exact_power"}:
                            out[name][key]=float(np.mean([r[key]for r in values]))
                method[label]=out
            grouped[prior][guide]=method
    write_json(ROOT/"raw-summary.json",{"plan":reference(PLAN),"shards":list(map(reference,files)),
                                        "raw_query_groups":len(row),"grouped":grouped})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("plan","collect","summary"))
    parser.add_argument("--shard",type=int,choices=(0,1))
    a=parser.parse_args()
    {"plan":freeze,"collect":lambda:collect(a.shard),"summary":summary}[a.action]()
