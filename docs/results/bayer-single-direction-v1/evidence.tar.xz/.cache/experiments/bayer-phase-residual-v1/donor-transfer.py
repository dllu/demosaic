"""Audit whether a coherent single direction predicts disjoint query quadrants."""
import numpy as np

from residual import ROOT
from rotate import NEAR
from screen import nominate
from evidence import coefficients, windows, phase
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CUTS=(0.,1.,2.,3.,4.)
SPLITS=(([0,1],[2,3]),([0,2],[1,3]))
LOCATIONS=tuple((x,y) for y in phase.CENTERS for x in phase.CENTERS)


def precision_sum(rows):
    inv=np.linalg.inv([covariance for _,covariance in rows])
    combined=inv.sum(axis=0)
    rhs=np.einsum("nij,nj->i",inv,np.stack([c for c,_ in rows]))
    covariance=np.linalg.inv(combined)
    return covariance@rhs,covariance


def transfers(samples,geometry,noise,sector):
    four=[precision_sum([tuple(part[sector] for part in coefficients(stencil,geometry,noise))
                         for stencil in fold]) for fold in samples]
    checks=[]
    for first,second in SPLITS:
        a,ca=precision_sum([four[k] for k in first])
        b,cb=precision_sum([four[k] for k in second])
        forward=(a@b)/np.sqrt(max(1e-24,a@cb@a))
        reverse=(a@b)/np.sqrt(max(1e-24,b@ca@b))
        checks.append([float(forward),float(reverse)])
    return checks


def main():
    rec=reference(ROOT/"single-direction.json")
    fixed=read_json(checked(rec))
    screen,supplement=(read_json(checked(fixed["sources"][k])) for k in ("screen","prospective-screen"))
    route=read_json(checked(fixed["pair_routes"]))
    collections=screen["groups"]|{"prospective":supplement["rows"]}
    out={}
    for name,rows in collections.items():
        candidates=[c for c in fixed["candidates"][name] if c["score"]>fixed["cutoff"]]
        trace=route["groups"][name]["records"]
        # All three old panels hold the same input conditioning and role order.
        source=read_json(checked(supplement["plan"]))
        rect=source["query_box"]
        noise=source["profile"]
        annotated=[]
        for row, prior in zip(rows,trace,strict=True):
            available=[c for c in candidates if c["source"]==row["source"]]
            if not available:
                continue
            assert row["input"]==prior["input"]
            x,y,w,h=rect
            with np.load(checked(row["input"]),allow_pickle=False) as f:
                assert f["packed"].shape[:2]==(source["repeat_count"],len(source["roles"]))
                layout=f["colors"]
                packed=f["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            for case in available:
                label=next(r for r in row["rows"] if r["role"]==case["role"] and r["draw"]==case["draw"])
                sector,=np.flatnonzero(label["near"]["local-warped"]["families_pass"])
                index=case["draw"],source["roles"].index(case["role"])
                seed=np.asarray(case["seed"])
                samples=windows(phase.unpack(packed[index]),layout[index],phase.ROI[:2],seed[:,:2],LOCATIONS)
                scores=transfers(samples,nominate.tangent_terms(seed),noise,sector)
                annotated.append(case|{"scores":scores,"worst_score":float(np.min(scores))})
        assert len(annotated)==len(candidates)
        out[name]=annotated
    performance={}
    for cutoff in CUTS:
        performance[str(cutoff)]={}
        for name,rows in out.items():
            kept=[r for r in rows if r["worst_score"]>cutoff]
            performance[str(cutoff)][name]={"count":len(kept),
                "intact_weak":sum(r["role"]=="present" and r["identity"]=="weak" for r in kept),
                "unmatched_or_absent":sum(not r["correct"] for r in kept)}
    write_json(ROOT/"donor-transfer.json",{"driver":reference(__file__),"candidates":rec,
           "rows":out,"sweep":performance,"scope":"Empirical extra spatial check reusing the query after prior candidate screening. Direction estimates are fit on disjoint halves before each reciprocal score. No delivered image."},replace=True)
    print(performance)


if __name__=="__main__":
    main()
