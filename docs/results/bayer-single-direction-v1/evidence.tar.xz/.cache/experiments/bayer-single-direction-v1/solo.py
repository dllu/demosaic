"""Deliver one exterior-supported Bayer direction while fitting its neighbor."""
from functools import lru_cache
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

import numpy as np
from scipy.special import expit

ROOT=Path(__file__).resolve().parent
RESIDUAL=ROOT.with_name("bayer-phase-residual-v1")
PRIOR=ROOT.with_name("bayer-local-phase-transfer-v1")
sys.path[:0]=[str(PRIOR),str(RESIDUAL)]
from rotate import cross, guard, old, phase, TILE_TAPER, WIDTH
from screen import nominate
from evidence import verify, windows

source=spec_from_file_location("frozen_donor_transfer",RESIDUAL/"donor-transfer.py")
transfer=module_from_spec(source)
source.loader.exec_module(transfer)

QUERY_FLOOR=17.96251260524093
SPATIAL_FLOOR=4.
ARMS=("single", "spatial", "edge", "edge_energy_control", "local_gap", "local_energy_control")


def admit(result,tile,cfa,roi,noise):
    directions=np.flatnonzero(result["families_pass"])
    if len(directions)!=1:
        return None
    sector=int(directions[0])
    seed=np.asarray(result["seed"])
    f=seed[:,:2]
    terms=nominate.tangent_terms(seed)
    fits=verify(tile,cfa,roi,f,terms,noise)
    score=fits["by_family"][sector]
    if score<=QUERY_FLOOR:
        return None
    samples=windows(phase.unpack(tile),cfa,roi[:2],f,transfer.LOCATIONS)
    scores=transfer.transfers(samples,terms,noise,sector)
    return {"sector":sector,"seed":seed.tolist(),"score":score,"spatial_score":float(np.min(scores)),
            "fold_scores":scores}


@lru_cache(maxsize=1)
def edge_designs():
    y,x=np.indices((WIDTH,WIDTH),dtype=float)-(WIDTH-1)/2
    steps=np.arange(-24.,25.,8.)
    angles=np.arange(12,dtype=float)*np.pi/12
    projection=y[...,None]*np.sin(angles)+x[...,None]*np.cos(angles)
    return expit((projection[...,None]-steps)/.85).reshape(WIDTH,WIDTH,-1)


def coef(A,x):
    normal=A.T@A
    if np.linalg.cond(normal)>1e7:
        return None
    return np.linalg.solve(normal,A.T@x)


def support(A,x,B,y,cols,noise):
    full=coef(A,x)
    sub=coef(A[:,cols],x)
    if full is None or sub is None:
        return 0.,None
    remain=y-B@full
    omit=y-B[:,cols]@sub
    return float((omit@omit-remain@remain)/phase.variance(x,noise)),full


def propose_edge(A,x,B,y,E,F,noise):
    fit=coef(A,x)
    if fit is None:
        return None
    Q=np.linalg.qr(A,mode="reduced")[0]
    side=E-Q@(Q.T@E)
    gain=np.square(side.T@(x-A@fit))/np.maximum(1e-9,np.square(side).sum(0))
    k=int(gain.argmax())
    if gain[k]/phase.variance(x,noise)<=24.:
        return None
    D=np.column_stack((E[:,k],A))
    V=np.column_stack((F[:,k],B))
    hold,_=support(D,x,V,y,np.arange(1,D.shape[1]),noise)
    return k if hold>9. else None


def edge_fit(raw,parent,layout,absolute,wave,noise,sector):
    edges=edge_designs()
    design=np.concatenate((phase.TONE,wave),axis=-1)
    offsets=phase.planes(layout,absolute)
    observations=[tuple(phase.clip_samples(value,p) for value in (design,raw,edges)) for p in offsets]
    indices=np.array([design.shape[-1]-4+sector,design.shape[-1]-2+sector])
    gain=[]
    residual=[]
    choices=[]
    for (A,x,E),(B,y,F) in (observations,observations[::-1]):
        k=propose_edge(A,x,B,y,E,F,noise)
        choices.append(k)
        if k is not None:
            A=np.column_stack((A,E[:,k]))
            B=np.column_stack((B,F[:,k]))
            field=np.concatenate((design,edges[...,k:k+1]),axis=-1)
        else:
            field=design
        keep=np.ones(A.shape[1],dtype=bool)
        keep[indices]=False
        observed,beta=support(A,x,B,y,keep,noise)
        if beta is None:
            return np.zeros_like(raw,dtype=np.float64),choices
        p=coef(field.reshape(-1,field.shape[-1]),parent.ravel())
        if p is None:
            return np.zeros_like(raw,dtype=np.float64),choices
        gain.append(observed)
        residual.append((beta[indices],p[indices]))
    if all(k is None for k in choices):
        return cross.fit_bands(raw,parent,layout,absolute,wave,noise)[sector],choices
    measured,restored=np.asarray(residual).mean(0)
    evidence=max(0.,min(gain)-6.)
    delta=(measured-restored)*evidence/(evidence+6.)
    delta*=min(1.,np.linalg.norm(measured)/max(1e-10,np.linalg.norm(delta)))
    return wave[..., [sector,sector+2]]@delta,choices


def deliver(tile,parent,cfa,wb,matrix,noise,candidate,roi=phase.ROI):
    x,y,w,h=roi
    assert w==h==160
    native=phase.unpack(tile)[y:y+h,x:x+w]
    guide=parent[1,y:y+h,x:x+w]
    k=candidate["sector"]
    seed=np.asarray(candidate["seed"])
    terms=nominate.tangent_terms(seed)
    sums=np.zeros((3,h,w),dtype=np.float64)
    mass=np.zeros((h,w),dtype=np.float64)
    use_spatial=candidate["spatial_score"]>SPATIAL_FLOOR
    edges=0
    for top in range(0,h-WIDTH+1,WIDTH//2):
        for left in range(0,w-WIDTH+1,WIDTH//2):
            sl=np.s_[top:top+WIDTH,left:left+WIDTH]
            start,features=phase.coords(left,top,seed[:,:2])
            design=phase.wave(start,features,terms)
            origin=(x+left,y+top,WIDTH)
            fit=cross.fit_bands(native[sl],guide[sl],cfa,origin,design,noise)
            sums[0][sl]+=fit[k]*TILE_TAPER
            if use_spatial:
                filtered,choices=edge_fit(native[sl],guide[sl],cfa,origin,design,noise,k)
                edges+=sum(v is not None for v in choices)
                sums[1][sl]+=filtered*TILE_TAPER
                local,_=guard.envelope(native[sl],design,cfa,origin[:2],noise)
                sums[2][sl]+=fit[k]*TILE_TAPER*local[k]
            mass[sl]+=TILE_TAPER
    taper=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    scale=(taper[:,None]*taper[None,:])/np.maximum(.02,mass)*old.DOSE
    mono=sums*scale
    gains=np.linalg.solve(matrix,np.ones(3))/wb
    outputs=np.zeros((len(ARMS),*parent.shape),dtype=np.float32)
    rf=gains/gains[1]
    outputs[0,:,y:y+h,x:x+w]=rf[:,None,None]*mono[0]
    if use_spatial:
        matched=np.linalg.norm(mono[1])/max(1e-12,np.linalg.norm(mono[0]))
        outputs[1,:,y:y+h,x:x+w]=outputs[0,:,y:y+h,x:x+w]
        outputs[2,:,y:y+h,x:x+w]=rf[:,None,None]*mono[1]
        outputs[3,:,y:y+h,x:x+w]=rf[:,None,None]*mono[0]*matched
        outputs[4,:,y:y+h,x:x+w]=rf[:,None,None]*mono[2]
        attenuation=np.linalg.norm(mono[2])/max(1e-12,np.linalg.norm(mono[0]))
        outputs[5,:,y:y+h,x:x+w]=rf[:,None,None]*mono[0]*attenuation
    return dict(zip(ARMS,outputs,strict=True)),{"edge_fold_count":edges}
