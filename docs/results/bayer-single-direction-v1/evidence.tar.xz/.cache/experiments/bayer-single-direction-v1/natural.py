"""Check the same automatic fallback on unplanted photographic fine detail."""
import sys
from pathlib import Path
import time

import numpy as np

from solo import ROOT, ARMS, admit, deliver, nominate, phase, verify
from rotate import old, render
from screen import near_configuration
from noisy_centers import blind
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

SCENE=ROOT.with_name("scene-full-epoch-v1")
MONITOR=SCENE/"review-full-040000/evaluation/results.json"
MODULE=ROOT.with_name("scene-local-contrast-2400-v1")
sys.path.insert(0,str(MODULE))
import measure


def choose(raw,cfa,box,local,noise):
    xy=(box[0]+phase.ROI[0],box[1]+phase.ROI[1])
    native=phase.unpack(raw)
    x,y=xy
    wid=phase.ROI[2]
    covers_primary=(x>=128 and y>=128 and x+wid+128<=native.shape[1] and y+wid+128<=native.shape[0])
    if covers_primary:
        f, admitted, _ = phase.geometry(raw,cfa,box,phase.ROI)
        if admitted:
            terms, _ = blind.measure(native,cfa,xy,f,noise)
            terms = old.bends.check_query(local,cfa,f,phase.ROI,terms,noise)[0]
            return "primary",(f,terms),None
    far = nominate.nominal_geometry(native,cfa,xy,noise)
    with near_configuration():
        near = nominate.nominal_geometry(native,cfa,xy,noise)
    for name,state in (("far",far),("near",near)):
        if state is None:
            continue
        item=state["local-warped"]
        if not item["admitted"]:
            continue
        seed=np.asarray(item["seed"])
        f=seed[:,:2]
        terms=nominate.tangent_terms(seed)
        if verify(local,cfa,phase.ROI,f,terms,noise)["cross"]>4.734528924409914:
            return name,(f,terms),None
    return "abstain",None,admit(near["local-warped"],local,cfa,phase.ROI,noise) if near is not None else None


def main():
    started=time.monotonic()
    monitor=reference(MONITOR)
    anchor=read_json(checked(monitor))
    plan=read_json(checked(anchor["plan"]))
    settings=read_json(checked(plan["panel"]))
    output=ROOT/"natural"
    output.mkdir(exist_ok=True)
    rows=[]
    for item in anchor["source_metrics"]:
        if (item["profile"],item["draw"])!=("iso6400","independent"):
            continue
        saved=read_json(checked(item["prediction_receipt"]))
        case=read_json(checked(saved["case"]))
        with np.load(checked(case["input"]),allow_pickle=False) as file:
            fields={k:file[k] for k in ("packed","variance","colors","wb","matrix","target","scene_packed")}
        assert all(fingerprint(data)==case["fingerprints"][key] for key,data in fields.items())
        with np.load(checked(saved["saved"]),allow_pickle=False) as f:
            parent=f["100k"]
        recipe=case["profile"]
        noise={k:recipe[k] for k in ("shot","read")}
        images={k:parent.copy() for k in ("parent","rotation",*ARMS)}
        traces=[]
        x,y,w,h=case["box"]
        assert not x%2 and not y%2 and (w,h)==(256,256)
        for i,tile in enumerate(fields["packed"]):
            scene=fields["scene_packed"].copy()
            scene[:,y//2:(y+h)//2,x//2:(x+w)//2]=tile
            photo=parent[i]
            cfa,wb,matrix=(fields[k] for k in ("colors","wb","matrix"))
            route,geometry,solo=choose(scene,cfa,case["box"],tile,noise)
            if geometry is not None:
                corrections,_=render(tile,photo,cfa,wb,matrix,noise,*geometry)
                for name in ("rotation",*ARMS):
                    images[name][i]+=corrections["rotation"]
            if solo is not None:
                parts,_=deliver(tile,photo,cfa,wb,matrix,noise,solo)
                for name,delta in parts.items():
                    images[name][i]+=delta
            traces.append({"role":case["roles"][i],"route":route,"solo":solo,
                "local_gap_RMS_DN16":float(np.sqrt(np.mean((images["local_gap"][i].astype(float)-images["rotation"][i])**2))*65535)})
        supervised={k:np.broadcast_to(fields[k][None],(3,*fields[k].shape)) for k in ("wb","matrix")}
        supervised["exposure"]=recipe["exposure"]
        scores={k:measure.parts(supervised,v,fields["target"],settings) for k,v in images.items()}
        assert scores["parent"]==item["metrics"]["100k"]
        row={"source":item["source"],"profile":item["profile"],"draw":item["draw"],
             "case":saved["case"],"prediction_receipt":item["prediction_receipt"],"metrics":scores,"routes":traces}
        if traces[0]["local_gap_RMS_DN16"]:
            source=settings["rows"][case["case"]]
            args={k:fields[k][0:1] if k=="packed" else fields[k][None] for k in ("packed","colors","wb","matrix")}
            row["board"]=old.native_board(output,f'{case["case"]:03d}',[noisy_malvar(args)[0],parent[0],
                images["rotation"][0],images["local_gap"][0],fields["target"][0]],args,
                {"source":source["source"],"query":case["box"],"noise":case["profile"],
                 "input":case["input"],"checkpoint":plan["models"]["100k"],"source_receipt":saved["case"],"role":traces[0]["role"]},
                labels=("Noisy Malvar","Corpus 100k","Pair route","Single fallback","Exact GT"),
                triplet_indices=(0,3,4),exposure=1/recipe["exposure"],contrast=2,
                roi=tuple(settings["native_display_ROI_xywh"]))
        rows.append(row)
        print(case["case"],[(r["route"],r["local_gap_RMS_DN16"]) for r in traces],flush=True)
    assert len(rows)==64
    write_json(ROOT/"natural.json",{"driver":reference(__file__),"source":monitor,
        "checkpoint":plan["models"]["100k"],"rows":rows,"pooled":measure.reduce(rows),
        "seconds":time.monotonic()-started,"scope":"Freeze the 64-source independent ISO6400 scene-intervention panel, with unplanted photo structure, attenuated pair and exact-flat controls."},replace=True)


if __name__=="__main__":
    main()
