"""Bind the delivered fallback, native crops and unplanted scene test."""
from datetime import datetime
import hashlib
from pathlib import Path
import sys
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from solo import ROOT, PRIOR, RESIDUAL, ARMS, phase, nominate
from screen import NEAR
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0,str(ROOT.with_name("paired-luminance-detail-v1")))
from render import native_png

DEST = Path("docs/images")/ROOT.name
RESULTS = Path("docs/results")/ROOT.name
PREVIOUS = Path("docs/images")/PRIOR.name
EXAMPLES=("011-0","014-0","007-1")


def read_cells(path,spec):
    with Image.open(path) as image:
        pixels=np.asarray(image.convert("RGB"))
    cells={}
    for panel in spec["panels"]:
        x,y,w,h=panel["png_xywh"]
        patch=pixels[y:y+h,x:x+w]
        assert patch.shape==(h,w,3)==(160,160,3)
        cells[panel.get("label",panel.get("name"))]=patch
    return cells


def render(path,cells):
    assert path.is_relative_to(DEST)
    path.parent.mkdir(exist_ok=True,parents=True)
    receipt=native_png(path,cells)
    receipt["image"]["path"]=path.relative_to(DEST).as_posix()
    return receipt


def coverage(data):
    routes=[]
    geo={"near":(NEAR,64),"far":(nominate.ORIGINS,64),
          "primary":(((-128,16),(160,16),(16,-128),(16,160)),128)}
    frames={key:0 for key in geo}
    for row in data["rows"]:
        original=row["metrics"]["parent"]
        assert all(v==original for v in row["metrics"].values())
        case=read_json(checked(row["case"]))
        x,y=[a+b for a,b in zip(phase.ROI[:2],case["box"][:2],strict=True)]
        h,w=[v*2 for v in case["fingerprints"]["scene_packed"]["shape"][-2:]]
        for key,(bank,width) in geo.items():
            frames[key]+=all(x+dx>=0 and y+dy>=0 and x+dx+width<=w and y+dy+width<=h for dx,dy in bank)
        routes.extend(row["routes"])
    assert len(data["rows"])==64 and len(routes)==192
    assert all(r["route"]=="abstain" and r["solo"] is None and r["local_gap_RMS_DN16"]==0 for r in routes)
    return {"photo_groups":64,"role_captures":192,"bounds_eligible_by_route":frames,"all_routes_abstained":True}


def main():
    refs={k:reference(ROOT/f"{k}.json") for k in ("replay","camera","natural")}
    actual={k:read_json(checked(v)) for k,v in refs.items()}
    replay=actual["replay"]
    photos=coverage(actual["natural"])
    assert replay["checkpoint"]["sha256"]==actual["natural"]["checkpoint"]["sha256"]
    previous=reference(PREVIOUS/"manifest.json")
    base={r["id"]:r for r in read_json(checked(previous))["standing"]}
    standing=read_json(checked(actual["camera"]["manifest"]))
    deltas={r["id"]:r for r in actual["camera"]["observations"]}
    assert len(standing["rows"])==len(deltas)==len(base)==8
    cov=[]
    for row in standing["rows"]:
        name=row["id"]
        former=base[name]
        for key in ("raw","input","parent","native_box","roi","noise","display_exposure"):
            assert row[key]==former[key]
        previous_image=PREVIOUS/former["board"]["image"]["path"]
        assert reference(previous_image)["sha256"]==former["board"]["image"]["sha256"]
        expected=read_cells(previous_image,former["board"])
        origin=checked(row["board"]["image"])
        cells=read_cells(origin,row["board"])
        assert all(np.array_equal(cells[label],expected[label]) for label in cells.keys()&expected.keys())
        keep=("Noisy (Malvar)","V120 EMA","Parent 100k EMA","Local-only 20k EMA",
              "Measured local phase","Single donor fallback","Local gap fallback",
              "One-band diagnostic","ISO100 AHD reference")
        keep=tuple(k for k in keep if k!="One-band diagnostic" or name=="mesh-profile3879-fine-green-mesh-right")
        if name.startswith("mesh-"):
            keep=("ISO6400 camera JPEG",*keep,"ISO100 camera JPEG")
        for policy in ("spatial","edge","local_gap"):
            assert deltas[name]["deltas"][policy]["RMS_DN16"]==0
        assert np.array_equal(cells["Local gap fallback"],cells["Measured local phase"])
        row["unabridged"]=row["board"]
        row["board"]=render(DEST/"standing"/origin.name,[(key,cells[key]) for key in keep])
        row["changes_vs_prior"]=deltas[name]
        cov.append(row)
    assert sum(r["deltas"]["single"]["RMS_DN16"]>0 for r in deltas.values())==1

    boards={}
    for row in replay["groups"]["prospective"]["records"]:
        for item in row["native"]:
            if item["id"] not in EXAMPLES:
                continue
            source=checked(item["board"]["image"])
            cells=read_cells(source,item["board"])
            item["capture_ADC_bits"]=16
            item["black_level"]=.03
            item["board"]=render(DEST/"exact"/source.name,list(cells.items()))
            if item["id"]!="007-1":
                item["triplet"]=render(DEST/"exact"/f'{item["id"]}-triplet.png',
                                       [(k,cells[k]) for k in ("Noisy Malvar","Local gap check","Exact GT")])
            else:
                item.pop("triplet")
            boards[item["id"]]=item
    assert set(boards)==set(EXAMPLES)
    manifest=DEST/"manifest.json"
    write_json(manifest,{"checkpoint":replay["checkpoint"],"previous_standing":previous,
        "standing":cov,"exact":[boards[k] for k in EXAMPLES],"natural":photos,
        "viewed_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "visual":"Three exact-target comparisons and all eight standing captures were viewed. Foliage is visually close and fine cab crossings stay incomplete."},replace=True)
    RESULTS.mkdir(exist_ok=True)
    evidence=RESULTS/"evidence.tar.xz"
    files=[checked(v) for v in refs.values()]+[checked(actual["camera"]["manifest"])]
    files+=sorted(ROOT.glob("*.py"))+sorted(ROOT.glob("*.log"))
    files+=[PRIOR/p for p in ("replay.py","rotate.py","standing.py","noisy_centers.py")]
    files+=[RESIDUAL/p for p in ("donor-transfer.py","single-direction.json","donor-transfer.json")]
    files+=[ROOT.with_name("scene-local-contrast-2400-v1")/"measure.py"]
    names={str(f.resolve().relative_to(Path.cwd())):f for f in files}
    with tarfile.open(evidence,"w:xz",preset=4) as output:
        for name,file in sorted(names.items()):
            output.add(file,arcname=name,recursive=False)
    with tarfile.open(evidence) as inp:
        for name,file in names.items():
            with inp.extractfile(name) as payload:
                assert hashlib.file_digest(payload,"sha256").hexdigest()==reference(file)["sha256"]
    write_json(RESULTS/"publication.json",{"checkpoint":replay["checkpoint"],"sources":refs,
        "manifest":reference(manifest),"archive":reference(evidence),"natural":photos,
        "panels":{k:v["summary"]["all"] for k,v in replay["groups"].items()},
        "standing_delta":{key:value["deltas"] for key,value in deltas.items()},
        "scope":"Inference-only. No new fixed 427-photo or known/unseen measured-camera scores. Sixty planted backgrounds and 64 independent ISO6400 photos plus eight standing crops."},replace=True)
    print("Verified three exact boards, their two triplets, eight standing boards and 192 natural inputs.")


if __name__=="__main__":
    main()
