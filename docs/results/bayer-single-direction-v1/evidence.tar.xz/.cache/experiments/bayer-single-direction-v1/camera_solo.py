"""Replay the standing outputs with an automatic single-direction fallback."""
from importlib.util import module_from_spec,spec_from_file_location
from unittest.mock import patch

import numpy as np

from solo import ARMS, PRIOR, RESIDUAL, ROOT, admit, deliver, phase
from rotate import NEAR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

path=PRIOR/"standing.py"
spec=spec_from_file_location("prior_standing_phase",path)
previous=module_from_spec(spec)
spec.loader.exec_module(previous)

LABELS={**previous.CAPTIONS,"single":"Single donor fallback","spatial":"Disjoint-half fallback",
        "edge":"Edge-aware fallback","local_gap":"Local gap fallback","single_witness":"One-band diagnostic"}
LABELS.pop("opposite")
source=reference(NEAR/"screen.json")
near={r["id"]:r for r in read_json(checked(source))["real"]}
new=[]


def stats(a,b,bounds):
    difference=(a[bounds].astype(float)-b[bounds])*65535
    return {"RMS_DN16":float(np.sqrt((difference**2).mean())), "peak_DN16":float(np.max(abs(difference)))}


def camera(raw,cfa,wb,matrix,noise,box,surround,parent,policy,roi=None):
    before=previous.camera(raw,cfa,wb,matrix,noise,box,surround,parent,policy,roi)
    legacy,refits,observations=policy
    roi=phase.ROI if roi is None else tuple(roi)
    key=tuple(b+r for b,r in zip(box[:2],roi[:2],strict=True))
    profile="nominal" if abs(noise["shot"]-.00128)<1e-12 else "transferred"
    passed=refits[(key,profile)]
    name=passed["id"]
    cached=near[name]
    up=passed["candidate"] is not None
    bounds=np.s_[...,roi[1]:roi[1]+160,roi[0]:roi[0]+160]
    assert cached["binding"]["roi"]==list(roi) and passed["binding"]["native_box"]==list(box)
    candidate=admit(cached["near"]["local-warped"],raw,cfa,roi,noise)
    outputs={k:before["rotation"] for k in (*ARMS,"single_witness")}
    notes=None
    if candidate is not None:
        stored=cached["near"]["local-warped"]["query"]["by_family"][candidate["sector"]]
        assert np.isclose(candidate["score"],stored,atol=1e-10,rtol=0)
        delta,notes=deliver(raw,before["distant"],cfa,wb,matrix,noise,candidate,roi)
        if not up:
            assert np.array_equal(before["distant"],before["rotation"])
            outputs.update({k:before["rotation"]+d for k,d in delta.items()})
        outputs["single_witness"]=before["distant"]+delta["single"]
    row={"id":name,"before_has_pair":up,"candidate":candidate,"notes":notes,
         "deltas":{name:stats(variant,before["rotation"],bounds) for name,variant in outputs.items()},
         "single_witness_vs_distant":stats(outputs["single_witness"],before["distant"],bounds) if candidate else None}
    print(name,row,flush=True)
    new.append(row)
    return {k:(before|outputs)[k] for k in LABELS}


def main():
    earlier=previous.prior
    runner=earlier.preceding
    learned,receipt=runner.setup()
    binding=reference(previous.PREVIOUS/"nomination.json")
    upstream=read_json(checked(binding))
    base=read_json(checked(upstream["previous"]))
    setup=(learned,{tuple(r["box"]):r for r in base["camera"]},
            {tuple(r["box"]):r for r in upstream["camera"]})
    fit=reference(NEAR/"recenter.json")
    records=read_json(checked(fit))
    refits={}
    for row in records["real"]:
        provenance=row["binding"]
        key=tuple(b+r for b,r in zip(provenance["native_box"][:2],provenance["roi"][:2],strict=True))
        profile="transferred" if "profile3879" in row["id"] else "nominal"
        refits[(key,profile)]=row
    assert len(refits)==8
    traces=[]
    with patch.object(runner,"ROOT",ROOT),patch.object(runner,"CAPTIONS",LABELS),patch.object(runner,"render_models",camera):
        runner.standing((setup,refits,traces),receipt|{
            "driver":reference(__file__),"checked_prior":fit,"nomination":binding},None)
    fixed=reference(PRIOR/"camera.json")
    for row,old in zip(traces,read_json(checked(fixed))["observations"],strict=True):
        assert all(row[k]==old[k] for k in ("id","noise","crop","changes"))
    assert len(new)==8
    write_json(ROOT/"camera.json",{"driver":reference(__file__),"prior":fixed,"near":source,
        "manifest":reference(ROOT/"standing/manifest.json"),"observations":new},replace=True)


if __name__=="__main__":
    main()
