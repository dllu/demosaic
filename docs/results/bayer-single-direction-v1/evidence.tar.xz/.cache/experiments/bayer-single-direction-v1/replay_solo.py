"""Evaluate delivered single-direction fallbacks on 60 frozen photo backgrounds."""
import time

import numpy as np

from solo import ARMS, PRIOR, RESIDUAL, ROOT, admit, deliver, phase
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

REPLAY=PRIOR/"replay.py"
CAPTIONS={"single":"Single donor","spatial":"Disjoint-half check","edge":"Edge-aware single donor",
          "edge_energy_control":"Equal edge energy","local_gap":"Local gap check",
          "local_energy_control":"Equal attenuation energy"}


def expand(plan, prior, fallback, raw, mosaic, target, parent, values, collection):
    base=values["rotation"]
    for name in ARMS:
        values[name]=base.copy()
    key=prior["source"]
    candidates=[r for r in descriptor["rows"][collection] if r["source"]==key]
    source=plan["sources"][prior["i"]]
    native=[]
    evidence=[]
    output=ROOT/"exact"
    output.mkdir(exist_ok=True)
    for item in candidates:
        draw,role=item["draw"],item["role"]
        b=plan["roles"].index(role)
        upstream=next(r for r in fallback["rows"] if (r["draw"],r["role"])==(draw,role))
        band=upstream["near"]["local-warped"]
        assert not upstream["previous"] and band["seed"]==item["seed"]
        assert np.array_equal(parent[draw,b],base[draw,b])
        cfa,wb,matrix=(raw[k][draw,b] for k in ("colors","wb","matrix"))
        tile=mosaic[draw,b]
        candidate=admit(band,tile,cfa,phase.ROI,plan["profile"])
        assert candidate is not None
        assert candidate["score"]==item["score"] and candidate["spatial_score"]==item["worst_score"]
        updates,context=deliver(tile,parent[draw,b],cfa,wb,matrix,plan["profile"],candidate)
        changes={}
        for name,delta in updates.items():
            values[name][draw,b]+=delta
            changes[name]={"RMS_DN16":float(np.sqrt(np.mean(delta.astype(float)**2))*65535)}
        trace={"case":item,"parameters":candidate,"context":context,"updates":changes}
        if (collection=="prospective" and role=="present" and
                (item["identity"]=="weak" or not item["correct"]) and updates["spatial"].any()):
            frame={k:raw[k][draw,b:b+1] for k in ("colors","wb","matrix")}|{"packed":mosaic[draw,b:b+1]}
            pictures=[module["noisy_malvar"](frame)[0],base[draw,b],*(values[k][draw,b] for k in ARMS),target[draw,b]]
            titles=("Noisy Malvar","Prior phase rotation",*CAPTIONS.values(),"Exact GT")
            identity=f'{prior["i"]:03d}-{draw}'
            compare={"source":source["source"],"source_box":source["box"],"CFA":source["camera"]["pattern"],
                    "query":plan["query_box"],"noise":plan["profile"],"input":prior["input"],"checkpoint":plan["base"],
                    "parent":prior["parent"],"repeat":draw,"role":role,"frequency":item,"record":trace}
            board=module["old"].native_board(output,identity,pictures,frame,compare,labels=titles,exposure=2,
                contrast=1,triplet_indices=(0,titles.index(CAPTIONS["edge"]),len(titles)-1))
            native.append(board)
        evidence.append(trace)
    return evidence,native


def summarize(rows):
    rng=np.random.default_rng(3222074)
    selections=rng.integers(len(rows),size=(10000,len(rows)))
    comparisons=[(k,"rotation") for k in ARMS]+[("edge","spatial"),("edge","edge_energy_control"),
        ("local_gap","spatial"),("local_gap","local_energy_control")]
    table={}
    for key in rows[0]["scores"]["rotation"]:
        measures={label:np.asarray([r["scores"][label][key] for r in rows])
                  for label in ("parent","rotation",*ARMS)}
        result={}
        for a,b in comparisons:
            d=measures[a]-measures[b]
            result[f"{a}_vs_{b}"]={"mean":float(d.mean()),"interval_95":np.quantile(d[selections].mean(1),[.025,.975]).tolist()}
        table[key]={"mean":{k:float(v.mean()) for k,v in measures.items()},"delta":result}
    return table


def main():
    global module,descriptor
    before=reference(RESIDUAL/"donor-transfer.json")
    descriptor=read_json(checked(before))
    text=REPLAY.read_text()
    replacements={
        "from rotate import ROOT,NEAR,CROSS,phase,nominate,old,MODES,render":
            "from rotate import NEAR,CROSS,phase,nominate,old,MODES,render\nfrom solo import ROOT",
        '    scores={key:old.totals(rgb,parent,target,raw)for key,rgb in values.items()}':
            '    one,output=expand(plan,prior,fallback,raw,mosaic,target,parent,values,collection)\n'
            '    scores={key:old.totals(rgb,parent,target,raw)for key,rgb in values.items()}',
        '"local_traces":trace,"native":native}':
            '"local_traces":trace,"native":output,"activation":one}',
        'reference(ROOT/"rotate.py")':'reference(ROOT/"solo.py")',
        'summarize([r for r in rows if r["shape"]==k])':'summarize_solo([r for r in rows if r["shape"]==k])',
    }
    for old,new in replacements.items():
        assert text.count(old)==1
        text=text.replace(old,new)
    module={"__name__":"single_direction_deliver","__file__":str(REPLAY),"expand":expand,"summarize_solo":summarize}
    exec(compile(text,str(REPLAY),"exec"),module)
    module["main"]()
    data=read_json(ROOT/"replay.json")
    former=reference(PRIOR/"replay.json")
    for name,group in read_json(checked(former))["groups"].items():
        out=data["groups"][name]
        for earlier,row in zip(group["records"],out["records"],strict=True):
            assert row["source"]==earlier["source"] and row["input"]==earlier["input"]
            assert all(row["scores"][k]==v for k,v in earlier["scores"].items())
        out["summary"]["all"]=summarize(out["records"])
        assert sum(len(row["activation"]) for row in out["records"])==len(
            [r for r in descriptor["rows"][name] if r["source"] in {row["source"] for row in out["records"]}])
    data["driver"]=reference(__file__)
    data["upstream_driver"]=reference(REPLAY)
    data["prior"]=former
    data["donor_transfer"]=before
    write_json(ROOT/"replay.json",data,replace=True)


if __name__=="__main__":
    main()
