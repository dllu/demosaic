"""Evaluate the same local phase shift using automatically nominated donor pairs."""
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
import sys
import time

import numpy as np
import torch

from rotate import ROOT,NEAR,CROSS,phase,old,render,nominate
from controlled import make,luma,metric,summary,KEYS,ROLES,PROFILES
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from screen import near_configuration

spec=spec_from_file_location("automatic_center_bend",nominate.EXTERIOR/"blind.py")
blind=module_from_spec(spec)
spec.loader.exec_module(blind)
from evidence import verify


def donor(raw,cfa,noise,tile):
    placement=(176,176)
    spacing,admitted,_=phase.geometry(raw,cfa,(128,128,256,256),phase.ROI)
    native=phase.unpack(raw)
    if admitted:
        terms,checks=blind.measure(native,cfa,placement,spacing,noise)
        terms=old.bends.check_query(tile,cfa,spacing,phase.ROI,terms,noise)[0]
        return "primary",(spacing,terms)
    far=nominate.nominal_geometry(native,cfa,placement,noise)["local-warped"]
    with near_configuration():
        near=nominate.nominal_geometry(native,cfa,placement,noise)["local-warped"]
    for mode,result in (("far",far),("near",near)):
        if not result["admitted"]:
            continue
        seed=np.asarray(result["seed"])
        spacing,terms=seed[:,:2],nominate.tangent_terms(seed)
        if verify(tile,cfa,phase.ROI,spacing,terms,noise)["cross"]>4.734528924409914:
            return mode,(spacing,terms)
    return "abstain",None


def full_scene_generator():
    here=Path(__file__).resolve().parent
    file=here/"controlled.py"
    text=file.read_text()
    replacements={
       "np.indices((256,256),dtype=float)-127.5":"np.indices((512,512),dtype=float)-255.5",
       "photo[y+128:y+384,x+128:x+384]":"photo[y:y+512,x:x+512]",
    }
    for a,b in replacements.items():
        assert text.count(a)==1
        text=text.replace(a,b)
    namespace={"__name__":"full_scene_synthetic","__file__":str(file)}
    exec(compile(text,str(file),"exec"),namespace)
    return namespace["make"]


@torch.inference_mode()
def main():
    started=time.monotonic()
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    tests=reference(CROSS/"plan.json")
    plan=read_json(checked(tests))
    binding=plan["base"]
    model,w=load_checkpoint(binding["path"],"cuda",tiled_inference=True)
    assert w["loaded_sha256"]==binding["sha256"] and "ema" in w
    model.eval()
    a,b=PROFILES["ISO6400"]
    noise={"shot":a,"read":b}
    model.set_noise(a,b)
    prepare=full_scene_generator()
    results={k:[]for k in ("known","automatic")}
    for row in plan["sources"]:
        full,r,freq,terms,recipe=prepare(plan,row,"ISO6400")
        data={k:(value[...,64:192,64:192] if k in ("packed","variance") else
                 value[...,128:384,128:384] if k=="target" else value)for k,value in full.items()}
        region={k:value[128:384,128:384]for k,value in r.items()}
        assert np.array_equal(data["packed"],full["packed"][...,64:192,64:192])
        args=[torch.as_tensor(data[k],device="cuda")for k in KEYS[:5]]
        args[:2]=[x.contiguous(memory_format=torch.channels_last)for x in args[:2]]
        with ieee_fp32():
            base=model(*args).cpu().numpy()
        for name in results:
            predictions={k:base.copy()for k in ("parent","baseline","local","uniform","reversed","rotation","opposite")}
            routes=[]
            for n,role in enumerate(ROLES):
                camera=[data[k][n]for k in ("colors","wb","matrix")]
                tile=data["packed"][n]
                tag,parameters=("known",(freq,terms)) if name=="known" else donor(full["packed"][n],camera[0],noise,tile)
                if parameters is not None:
                    images,_=render(tile,base[n],*camera,noise,*parameters)
                    for k,value in images.items():
                        predictions[k][n]+=value
                changed=bool(np.any(predictions["rotation"][n]!=predictions["local"][n]))
                routes.append({"role":role,"origin":tag,"phase_delivery":changed})
            scores={k:metric(v,data,region,luma(predictions["local"],data))for k,v in predictions.items()}
            results[name].append({"index":row["index"],"source":row["source"]["id"],"recipe":recipe,
                                  "routes":routes,"scores":scores})
        print(row["index"],[(g["role"],g["origin"],g["phase_delivery"])for g in results["automatic"][-1]["routes"]],flush=True)
    write_json(ROOT/"noisy-centers.json",{"driver":reference(__file__),"checkpoint":binding,"plan":tests,
        "source_generator":reference(ROOT/"controlled.py"),"rows":results,
        "summary":{name:summary(records)for name,records in results.items()},"seconds":time.monotonic()-started,
        "scope":"Matched exact versus automatic center geometry in the same fresh 512px RAWs. Retain existing primary/far/near donor eligibility."})


if __name__=="__main__":
    main()
