"""Move an existing Bayer carrier toward a new phase supported by both greens."""
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parent
LAST=ROOT.with_name("bayer-local-deficit-v1")
NEAR=ROOT.with_name("bayer-near-donors-v1")
CROSS=ROOT.with_name("bayer-cross-evidence-v1")
sys.path.insert(0,str(LAST))
import phase_veto as guard
from phase_veto import phase,cross,old,TILE_TAPER,WIDTH,INNER,STATIONS,BLEND,TONE
from phase_veto import solve,compare,coherent_orthogonal,LOW,HIGH,MAX_CUT,matched

from screen import nominate

MODES=("baseline","local","uniform","reversed","rotation","opposite")
MAX_ANGLE=np.pi/2
PHASE_SCORE=3.
PHASE_AGREEMENT=np.pi/6


def angle(a,b):
    cross_term=a[:,0]*b[:,1]-a[:,1]*b[:,0]
    return np.arctan2(cross_term,np.sum(a*b,axis=1))


def test_phase(outer,inner,held):
    shift=angle(outer[0],inner[0])
    unit=inner[0]/np.maximum(1e-12,np.linalg.norm(inner[0],axis=1,keepdims=True))
    fixed=unit*np.linalg.norm(outer[0],axis=1,keepdims=True)
    residual,previous=held[0]-fixed,held[0]-outer[0]
    delta=(previous-residual)[:,:,None]
    total=np.linalg.solve(held[1],(previous+residual)[:,:,None])
    improvement=(delta*total).sum((1,2))
    return shift, improvement


def local_fields(raw,carriers,layout,origin,noise):
    design=np.concatenate((TONE,carriers),axis=-1)
    colors=phase.planes(layout,(*origin,WIDTH))
    total=np.zeros((2,WIDTH,WIDTH),dtype=np.float64)
    angles=np.zeros_like(total)
    mass=np.zeros((WIDTH,WIDTH),dtype=np.float64)
    diagnoses=[]
    full=[solve(raw,design,np.ones((WIDTH,WIDTH),dtype=bool),plane,noise) for plane in colors]
    for y,x in STATIONS:
        region=np.s_[y:y+INNER,x:x+INNER]
        core=np.zeros((WIDTH,WIDTH),dtype=bool)
        core[region]=True
        a,b=pair=[solve(raw,design,~core,plane,noise) for plane in colors]
        inner=[solve(raw,design,core,plane,noise) for plane in colors]
        z=np.zeros(2)
        cut=np.zeros(2)
        blocked=np.zeros(2,dtype=bool)
        established=np.zeros(2,dtype=bool)
        phase_gain=np.zeros((2,2))
        change=np.zeros(2)
        if all(item is not None for item in (*pair,*inner)):
            forward=compare((a,b),inner[1])
            reverse=compare((b,a),inner[0])
            z=np.minimum(forward[0],reverse[0])
            fraction=np.clip(np.minimum(forward[1],reverse[1]),0,1)
            confidence=np.clip((z-LOW)/(HIGH-LOW),0,1)
            blocked=coherent_orthogonal(pair,inner)
            cut=MAX_CUT*fraction*confidence*(np.minimum(forward[2],reverse[2])>0)*~blocked
            if blocked.any() and all(item is not None for item in full):
                values=[test_phase(full[k],inner[k],inner[1-k]) for k in (0,1)]
                shifts,phase_gain=np.array(values).transpose(1,0,2)
                distance=np.angle(np.exp(1j*(shifts[0]-shifts[1])))
                average=np.angle(np.exp(1j*shifts).sum(axis=0))
                established=blocked & (phase_gain.min(0)>PHASE_SCORE) & (np.abs(distance)<PHASE_AGREEMENT)
                change=np.where(established,np.clip(average,-MAX_ANGLE,MAX_ANGLE),0)
        total[:,region[0],region[1]]+=cut[:,None,None]*BLEND
        angles[:,region[0],region[1]]+=change[:,None,None]*BLEND
        mass[region]+=BLEND
        diagnoses.append({"xy":[x,y],"deficit_z":z.tolist(),"cut":cut.tolist(),"phase_veto":blocked.tolist(),
                          "phase_shift":change.tolist(),"query_holdout_gain":phase_gain.tolist()})
    return 1-total/mass,angles/mass,diagnoses


def perpendicular(wave,bands):
    """Return the same two directional amplitudes at a 90 degree offset."""
    value=[]
    for band,k in zip(bands,range(2),strict=True):
        carrier=wave[..., [k,k+2]]
        mat=carrier.reshape(-1,2)
        c=np.linalg.solve(mat.T@mat,mat.T@band.ravel().astype(float))
        np.testing.assert_allclose(carrier@c,band,rtol=1e-7,atol=1e-10)
        value.append(carrier@np.array((-c[1],c[0])))
    return np.stack(value)


def render(raw,parent,cfa,wb,matrix,noise,spacing,terms,roi=phase.ROI):
    x,y,w,h=roi
    assert (w,h)==(160,160)
    native=phase.unpack(raw)[y:y+h,x:x+w]
    prior=parent[1,y:y+h,x:x+w]
    weights=np.zeros((h,w),dtype=np.float64)
    sums=np.zeros((len(MODES),h,w),dtype=np.float64)
    receipt=[]
    for top in range(0,h-WIDTH+1,WIDTH//2):
        for left in range(0,w-WIDTH+1,WIDTH//2):
            sl=np.s_[top:top+WIDTH,left:left+WIDTH]
            nominal,indices=phase.coords(left,top,spacing)
            wave=phase.wave(nominal,indices,terms)
            p=(x+left,y+top)
            bands=cross.fit_bands(native[sl],prior[sl],cfa,(*p,WIDTH),wave,noise)
            old_tile=bands[2]*TILE_TAPER
            sums[0][sl]+=old_tile
            if np.any(bands[2]):
                gain,rotation,tests=local_fields(native[sl],wave,cfa,p,noise)
                uniform,flipped=matched(gain,bands[:2])
                receipt.append({"tile":[left,top],"subwindows":tests,
                                "uniform_strength":uniform[:,0,0].tolist()})
                for ix,control in enumerate((gain,uniform,flipped),start=1):
                    if np.all(control==1):
                        weighted=old_tile
                    else:
                        adjusted=bands[2]+((control-1)*bands[:2]).sum(0)
                        weighted=adjusted*TILE_TAPER
                    sums[ix][sl]+=weighted
                    if ix==1:
                        checked_tile=weighted
                if rotation.any():
                    quadrature=perpendicular(wave,bands[:2])
                    common=(np.cos(rotation)-1)*bands[:2]
                    signed=np.sin(rotation)*quadrature
                    for k,sign in enumerate((1,-1),start=4):
                        extra=(gain*(common+sign*signed)).sum(0)*TILE_TAPER
                        sums[k][sl]+=checked_tile+extra
                else:
                    sums[4:,sl[0],sl[1]]+=checked_tile
            else:
                sums[1:,sl[0],sl[1]]+=old_tile
            weights[sl]+=TILE_TAPER
    edge=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    normal=(edge[:,None]*edge[None,:])/np.maximum(.02,weights)
    ratios=np.linalg.solve(matrix,np.ones(3))/wb
    rgb=np.zeros((len(MODES),*parent.shape),dtype=np.float32)
    rgb[:,:,y:y+h,x:x+w]=(ratios/ratios[1])[None,:,None,None]*(sums*normal)[:,None]
    return dict(zip(MODES,np.float32(old.DOSE)*rgb,strict=True)),receipt
