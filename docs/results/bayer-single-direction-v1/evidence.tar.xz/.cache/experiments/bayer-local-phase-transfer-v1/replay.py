"""Apply a local amplitude check to the exact previously scored fallback outputs."""
import json
from pathlib import Path
import time

import numpy as np

from rotate import ROOT,NEAR,CROSS,phase,nominate,old,MODES,render
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

LABELS={"parent":"Corpus 100k EMA","baseline":"Near and far fallback",
        "local":"Local check with phase veto","uniform":"Same attenuation, uniform",
            "reversed":"Same attenuation, reversed",
        "rotation":"Measured local phase","opposite":"Opposite phase shift"}


def reprocess(plan,prior,fit,upstream,known,fallback,cutoff,collection):
    i=prior["i"]
    assert all(v["input"]==prior["input"] for v in (fit,upstream,known,fallback))
    assert all(v["parent"]==prior["parent"] for v in (fit,known))
    with np.load(checked(prior["input"]),allow_pickle=False) as f:
        raw={k:f[k] for k in f.files}
    with np.load(checked(prior["parent"]),allow_pickle=False) as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    mosaic=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
    target=raw["target"][...,y:y+h,x:x+w]
    values={k:parent.copy() for k in LABELS}
    trace=[]
    native=[]
    for routes,candidate,seeds,old_check,near in zip(prior["changes"],fit["rows"],upstream["rows"],known["rows"],fallback["rows"],strict=True):
        draw,role=routes["draw"],routes["role"]
        assert (draw,role)==(candidate["draw"],candidate["role"])==(seeds["repeat"],seeds["role"])
        assert (draw,role)==(near["draw"],near["role"])==(old_check["draw"],old_check["role"])
        r=plan["roles"].index(role)
        chosen=None
        if candidate["eligible"]:
            detail=candidate["candidate"]
            assert not routes["near_fallback"]
            spacing=np.array(detail["spacing"])
            terms=np.array(detail["prior"])
            label="original"
        else:
            if old_check["active_candidate"] is not None and old_check["active_candidate"]["cross"]>cutoff:
                chosen=seeds["selected"]["local-warped"]
                label="far"
            if routes["near_fallback"]:
                assert chosen is None
                chosen=near["near"]["local-warped"]
                label="near"
            if chosen is None:
                continue
            seed=np.array(chosen["seed"])
            spacing,terms=seed[:,:2],nominate.tangent_terms(seed)
        detail=[raw[k][draw,r] for k in ("colors","wb","matrix")]
        raw_crop=mosaic[draw,r]
        pred=parent[draw,r]
        noise=plan["profile"]
        updates,fit_report=render(raw_crop,pred,*detail,noise,spacing,terms)
        exact=old.bends.correction(raw_crop,pred,*detail,noise,spacing,phase.ROI,old.DOSE,True,{"locked":terms})["locked"]
        np.testing.assert_array_equal(updates["baseline"],exact)
        if not np.any(exact):
            assert all(np.array_equal(exact,u) for u in updates.values())
        for k,u in updates.items():
            values[k][draw,r]+=u
        nonzero=any(max(s["cut"])>0 for window in fit_report for s in window["subwindows"])
        trial={"draw":draw,"role":role,"route":label,"nonzero_attenuation":nonzero,
               "nonzero_change":bool(np.any(updates["local"]!=exact)),
               "max_abs_DN16":float(np.max(np.abs(updates["local"].astype(float)-exact))*65535),
               "local_evidence":fit_report,
               "rotation_rms_DN16":float(np.sqrt(np.square(updates["rotation"].astype(float)-updates["local"]).mean())*65535)}
        trace.append(trial)
        if collection=="independent" and i in (5,7) and routes["near_fallback"] and role=="present":
            source=plan["sources"][i]
            frame={k:raw[k][draw,:1]for k in ("colors","wb","matrix")}|{"packed":mosaic[draw,:1]}
            photos=[noisy_malvar(frame)[0],*(values[k][draw,r]for k in LABELS),target[draw,r]]
            titles=("Noisy Malvar",*LABELS.values(),"Exact GT")
            native.append(old.native_board(ROOT/"native",f"case-{i:03d}-draw{draw}",photos,frame,
                           {"CFA":source["camera"]["pattern"],"noise":noise,"input":prior["input"],
                            "source":source["source"],"source_box":source["box"],"query":plan["query_box"],
                            "parent":prior["parent"],"draw":draw,"role":role},
                           labels=titles,exposure=2,contrast=1,
                           triplet_indices=(0,titles.index(LABELS["rotation"]),len(titles)-1)))
    scores={key:old.totals(rgb,parent,target,raw)for key,rgb in values.items()}
    assert scores["baseline"]==prior["scores"]["near-fallback"]
    return {k:prior[k] for k in ("i","source","shape","input","parent")}|{"scores":scores,"local_traces":trace,"native":native}


def summarize(rows):
    rng=np.random.default_rng(6418131)
    ids=rng.integers(len(rows),size=(10000,len(rows)))
    table={}
    for label in rows[0]["scores"]["baseline"]:
        values={k:np.asarray([r["scores"][k][label]for r in rows])for k in LABELS}
        result={}
        for a,b in (("local","baseline"),("uniform","baseline"),("local","uniform"),("local","reversed"),
                    ("rotation","local"),("opposite","local"),("rotation","opposite")):
            d=values[a]-values[b]
            result[a+"_vs_"+b]={"point":float(d.mean()),"interval_95":np.quantile(d[ids].mean(1),[.025,.975]).tolist()}
        table[label]={"means":{k:float(x.mean()) for k,x in values.items()},"delta":result}
    return table


def main():
    t0=time.monotonic()
    study=reference(NEAR/"delivery.json")
    result=read_json(checked(study))
    screen,prospect,fit=[read_json(checked(result["sources"][k]))
                          for k in ("screen","prospective-screen","recenter")]
    evidence=read_json(checked(screen["detection"]))
    prior=read_json(checked(evidence["sources"]["nomination"]))
    replica=read_json(checked(evidence["sources"]["replication"]))
    larger=read_json(checked(prospect["source"]))
    folds={**screen["groups"],"prospective":prospect["rows"]}
    guarded=read_json(ROOT.with_name("bayer-local-deficit-v1")/"replay-phase.json")
    cutoff=evidence["thresholds"]["active_candidate"]["cross_0"]
    (ROOT/"native").mkdir(exist_ok=True)
    out={}
    fixed=(("initial",prior["plan"],prior["rows"],evidence["rows"]["initial"]),
           ("independent",replica["plan"],replica["nominations"],evidence["rows"]["independent"]),
           ("prospective",prospect["plan"],prospect["far_nominations"],larger["detections"]))
    for name,binding,nominations,old_ranks in fixed:
        plan=read_json(checked(binding))
        model=result["groups"][name]["records"]
        args=zip(model,fit["groups"][name],nominations,old_ranks,folds[name],strict=True)
        rows=[reprocess(plan,*a,cutoff,name)for a in args]
        for r,a in zip(rows,guarded["groups"][name]["records"],strict=True):
            for k in ("parent","baseline","local","uniform","reversed"):
                assert r["scores"][k]==a["scores"][k],(name,r["i"],k)
        geometry={k:summarize([r for r in rows if r["shape"]==k])
                  for k in sorted({r["shape"]for r in rows})}
        out[name]={"records":rows,"summary":geometry}
        print(name,len(rows),[(r["i"],sum(t["nonzero_change"]for t in r["local_traces"]))for r in rows if r["local_traces"]],flush=True)
    write_json(ROOT/"replay.json",{"driver":reference(__file__),"operator":reference(ROOT/"rotate.py"),
               "input":study,"checkpoint":result["checkpoint"],"groups":out,"seconds":time.monotonic()-t0})


if __name__=="__main__":
    main()
