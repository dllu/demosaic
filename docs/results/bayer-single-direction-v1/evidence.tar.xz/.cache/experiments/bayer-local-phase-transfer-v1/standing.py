"""Replay the local Bayer amplitude check on the fixed camera crops."""
from importlib.util import module_from_spec,spec_from_file_location
from unittest.mock import patch

import numpy as np

from rotate import ROOT,NEAR,phase,render
from screen import PREVIOUS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

spec=spec_from_file_location("preexisting_warped_camera_path",PREVIOUS/"standing.py")
prior=module_from_spec(spec)
spec.loader.exec_module(prior)
CAPTIONS={k:v for k,v in prior.CAPTIONS.items() if k in ("Bayer-gated","distant","fixed","previous")}
CAPTIONS.update({"local":"Phase veto only","rotation":"Measured local phase",
                 "opposite":"Opposite phase shift"})


def camera(raw,cfa,wb,matrix,noise,box,surround,parent,policy,roi=None):
    legacy,refits,observations=policy
    before=prior.render(raw,cfa,wb,matrix,noise,box,surround,parent,legacy,roi)
    roi=phase.ROI if roi is None else tuple(roi)
    key=tuple(b+r for b,r in zip(box[:2],roi[:2],strict=True))
    profile="nominal" if abs(noise["shot"]-.00128)<1e-12 else "transferred"
    diagnostic=refits[(key,profile)]
    assert diagnostic["binding"]["native_box"]==list(box) and diagnostic["binding"]["roi"]==list(roi)
    candidate=diagnostic["candidate"]
    if candidate is None:
        updates={k:before["previous"] for k in ("local","uniform","reversed","rotation","opposite")}
        scores=[]
    else:
        values,scores=render(raw,before["distant"],cfa,wb,matrix,noise,
                             np.asarray(candidate["spacing"]),np.asarray(candidate["prior"]),roi)
        np.testing.assert_array_equal(before["distant"]+values["baseline"],before["previous"])
        updates={k:before["distant"]+v for k,v in values.items() if k!="baseline"}
    bounds=np.s_[...,roi[1]:roi[1]+160,roi[0]:roi[0]+160]
    metrics={}
    for name,current in updates.items():
        difference=(current[bounds].astype(float)-before["previous"][bounds])*65535
        metrics[name]={"RMS_DN16":float(np.sqrt((difference**2).mean())),
                       "peak_DN16":float(np.abs(difference).max())}
    actual=(updates["rotation"][bounds].astype(float)-updates["local"][bounds])*65535
    metrics["rotation_vs_veto"]={"RMS_DN16":float(np.sqrt((actual**2).mean())),
                                "peak_DN16":float(np.abs(actual).max())}
    observations.append({"id":diagnostic["id"],"noise":noise,"crop":list(roi),"changes":metrics,"tiles":scores})
    print(diagnostic["id"],metrics,flush=True)
    return {k:(before|updates)[k] for k in CAPTIONS}


def main():
    learned,receipt=prior.preceding.setup()
    seed=reference(PREVIOUS/"nomination.json")
    prerequisites=read_json(checked(seed))
    earlier=read_json(checked(prerequisites["previous"]))
    setup=(learned,{tuple(r["box"]):r for r in earlier["camera"]},
            {tuple(r["box"]):r for r in prerequisites["camera"]})
    source=reference(NEAR/"recenter.json")
    saved=read_json(checked(source))
    refits={}
    observations=[]
    for row in saved["real"]:
        binding=row["binding"]
        key=tuple(b+r for b,r in zip(binding["native_box"][:2],binding["roi"][:2],strict=True))
        profile="transferred" if "profile3879" in row["id"] else "nominal"
        refits[(key,profile)]=row
    assert len(refits)==8
    with patch.object(prior.preceding,"ROOT",ROOT),patch.object(prior.preceding,"CAPTIONS",CAPTIONS),patch.object(prior.preceding,"render_models",camera):
        prior.preceding.standing((setup,refits,observations),receipt|
                                 {"driver":reference(__file__),"checked_prior":source,"nomination":seed}, None)
    assert len(observations)==8
    write_json(ROOT/"camera.json",{"source":source,"driver":reference(__file__),
        "manifest":reference(ROOT/"standing/manifest.json"),"observations":observations})


if __name__=="__main__":
    main()
