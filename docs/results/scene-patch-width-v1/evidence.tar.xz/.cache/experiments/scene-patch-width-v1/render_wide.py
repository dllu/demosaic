"""Render fixed native crops and measure the two RAW-supported real cab peaks."""

import argparse
import sys

import numpy as np
from PIL import Image
import torch

from demosaic import scene_patch_covariance as patch
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop
from evaluate_wide import (
    BANDS,
    HOLE,
    LENGTH,
    OLDER,
    ROOT,
    fields_for_record,
    luminance_corrections,
    replay,
    values,
)

sys.path[:0] = ["scripts", str(ROOT.with_name("paired-luminance-detail-v1"))]
from render import native_png
from report_scene_wave_guides import native_board

POLICY = "quiet"
LABELS = {
    "legacy16": "Original 16 px",
    "mid16": "16 px same band",
    "mid32": "32 px same band",
    "low32": "32 px low band",
    "low32_diagonal": "Low band diagonal",
    "mid32_plus_low": "32 px two bands",
    "legacy16_plus_low": "16 px plus low band",
}
LONG = "low32"
CAMERA_PEAKS = ((0.1171875, 0.07421875), (-0.08984375, 0.0703125))


def pixels(info):
    with Image.open(checked(info["image"])) as source:
        image = np.asarray(source.convert("RGB"))
    return {
        p.get("name", p.get("label")): image[y : y + h, x : x + w]
        for p in info["panels"]
        for x, y, w, h in (p["png_xywh"],)
    }


def exact(settings, lock):
    test = reference(ROOT / "wire-study.json")
    cohort = read_json(checked(test))
    assert cohort["calibration"] == lock
    finite = [r for r in cohort["test"] if r["gap_pixels"]]
    ref = "legacy16"

    def difference(r, metric):
        return float(
            values([r], LONG, metric, settings[LONG])[0]
            - values([r], ref, metric, settings[ref])[0]
        )

    promising = max(finite, key=lambda r: difference(r, LENGTH))
    fragile = max((r for r in finite if r is not promising), key=lambda r: difference(r, HOLE))
    targets = [
        (promising, "largest added signed fundamental"),
        (fragile, "largest extra false-gap projection"),
    ]
    room = ROOT / "native/exact"
    room.mkdir(parents=True)
    results = []
    for r, intent in targets:
        case = r["case"]
        fields, base, v120 = replay.read_inputs(case)
        changes, _ = fields_for_record(case, fields, base)
        cal = {k: fields[k][None] for k in ("wb", "matrix", "colors")}
        with np.load(checked(case["input"]), allow_pickle=False) as f:
            truth = f["target"]
        for role, name in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(cal | {"packed": fields["packed"][role : role + 1]})[0]
            options = ("legacy16", "mid32", "low32", "low32_diagonal", "mid32_plus_low")
            labels = (
                "Noisy Malvar",
                "V120 EMA",
                "Corpus 100k",
                *(LABELS[k] for k in options),
                "Exact GT",
            )
            images = [
                noisy,
                v120[role],
                base[role],
                *[base[role] + settings[k] * changes[k][role] for k in options],
                truth[role],
            ]
            board = native_board(
                room,
                f"{case['id']}-{name}",
                images,
                cal,
                {
                    "source": case,
                    "role": name,
                    "settings": settings,
                    "selection": intent,
                    "fundamental_change_points": difference(r, LENGTH),
                    "false_fundamental_change_DN16": difference(r, HOLE),
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS[LONG]), len(labels) - 1),
                exposure=2,
                contrast=1,
                roi=(48, 48, 160, 160),
            )
            results.append(board)
    write_json(
        room / "result.json",
        {"driver": reference(__file__), "strengths": lock, "measurements": test, "rows": results},
    )


def peak_fit(raw, parent, variants, colors, roi):
    """Compare projected output with the same input's two green-lattice measurements."""
    x, y, w, h = roi
    matrices = []
    data = {"observed": [], "parent": [], **{k: [] for k in variants}}
    frames = {"parent": parent, **variants}
    for g in np.flatnonzero(colors == 1):
        py, px = g // 2, g % 2
        yy, xx = np.indices(raw.shape[-2:])
        yy, xx = 2 * yy + py, 2 * xx + px
        zone = (yy >= y) & (yy < y + h) & (xx >= x) & (xx < x + w)
        yy, xx = yy[zone], xx[zone]
        fy = (yy - y + 0.5) / h
        fx = (xx - x + 0.5) / w
        taper = np.sin(np.pi * fx) * np.sin(np.pi * fy)
        harmonics = [
            term(2 * np.pi * (u * xx + v * yy))
            for u, v in CAMERA_PEAKS
            for term in (np.cos, np.sin)
        ]
        design = np.column_stack((np.ones_like(fx), fx, fy, *harmonics))
        kernel = np.linalg.pinv(design * taper[:, None])[-4:] * taper[None, :]
        data["observed"].append(kernel @ raw[g][zone])
        for k, v in frames.items():
            data[k].append(kernel @ v[1, yy, xx])
    raw_signal = np.mean(data["observed"], axis=0).reshape(2, 2)
    scores = {}
    for k, v in data.items():
        p = np.mean(v, axis=0).reshape(2, 2)
        ratio = np.sum(p * raw_signal, axis=1) / np.maximum(1e-20, np.sum(raw_signal**2, axis=1))
        scores[k] = {"cos_sin": p.tolist(), "percent_of_observed": (100 * ratio).tolist()}
    return scores


def camera(settings, lock):
    ancestor = reference(OLDER / "native/review.json")
    saved = read_json(checked(ancestor))
    paths = read_json(checked(saved["old_camera_review"]))
    proof = {row["id"]: row for row in paths["standing"]}
    room = ROOT / "native/standing"
    room.mkdir(parents=True, exist_ok=True)
    rows = []
    for category in ("main", "mesh"):
        records = [r for r in saved["standing"] if r["id"].startswith(category)]
        binding = records[0]["raw"]
        location = checked(binding)
        assert location.is_relative_to(ROOT.parents[1])
        raw, meta = read_raw(location)
        H, W = (2 * (v // 2) for v in raw.shape)
        packed = np.stack([raw[k // 2 : H : 2, k % 2 : W : 2] for k in range(4)])
        del raw
        color = color_indices(meta.pattern).numpy()
        for r in records:
            name = r["id"]
            prev = proof[name]
            assert r["raw"] == binding == prev["raw"] and r["parent_input"] == prev["parent_input"]
            x, y, w, h = r["query"]
            X, Y, rw, rh = r["native_ROI"]
            area = (X - x, Y - y, rw, rh)
            view = np.s_[..., area[1] : area[1] + rh, area[0] : area[0] + rw]
            # Derive the crop within the archived 512/768 native input from the
            # previously reviewed sensor coordinate and exact reference ROI.
            ref_main = read_json(checked(paths["links"]["references"]))
            ref = next(z for z in ref_main["rows"] if z["id"] == name)
            bx, by, _, _ = ref["native_box"]
            ix, iy = x - bx, y - by
            observed = packed[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
            with np.load(checked(r["parent_input"]), allow_pickle=False) as f:
                np.testing.assert_array_equal(f["colors"][0], color)
                np.testing.assert_array_equal(
                    f["packed"][0, :, iy // 2 : (iy + h) // 2, ix // 2 : (ix + w) // 2], observed
                )
                wb, matrix = f["wb"], f["matrix"]
            parent = np.load(checked(r["parent_prediction"]), allow_pickle=False)[
                0, :, iy : iy + h, ix : ix + w
            ]
            fields = {"scene_packed": packed, "colors": color}
            deltas = luminance_corrections(observed, parent, fields, r["query"], r["noise"])
            choices = {
                k: replay.apply_delta(parent, deltas[k], wb[0], matrix[0], settings[k])
                for k in LABELS
            }
            rms = {
                k: float(65535 * np.sqrt(np.mean((a[view].astype(float) - parent[view]) ** 2)))
                for k, a in choices.items()
            }
            displays = []
            for d in r["displays"]:
                exp = d["exposure"]
                former = pixels(d["board"])

                def render(b):
                    rgb = display_crop(
                        torch.from_numpy(b[None]),
                        torch.from_numpy(wb),
                        torch.from_numpy(matrix),
                        area,
                        exposure=exp,
                    )
                    return np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)

                np.testing.assert_array_equal(render(parent), former["Corpus 100k"])
                columns = [
                    (k, former[k])
                    for k in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Corpus 100k")
                    if k in former
                ]
                columns.extend((LABELS[k], render(choices[k])) for k in LABELS)
                columns.extend(
                    (k, former[k])
                    for k in ("ISO100 AHD reference", "ISO100 camera JPEG")
                    if k in former
                )
                displays.append(
                    {"exposure": exp, "board": native_png(room / f"{name}-x{exp:g}.png", columns)}
                )
            measurement = (
                peak_fit(observed, parent, choices, color, area) if category == "mesh" else {}
            )
            row = {
                k: r[k]
                for k in (
                    "id",
                    "query",
                    "native_ROI",
                    "noise",
                    "parent_input",
                    "parent_prediction",
                    "raw",
                )
            }
            rows.append(
                row | {"DN16": rms, "displays": displays, "peak_observational": measurement}
            )
            print(name, {k: round(v, 3) for k, v in rms.items()}, flush=True)
        del packed
    assert len(rows) == 8 and sum(len(r["displays"]) for r in rows) == 12
    write_json(
        room / "result.json",
        {
            "driver": reference(__file__),
            "strengths": lock,
            "prior": ancestor,
            "observed_peak_xy": CAMERA_PEAKS,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    torch.set_num_threads(2)
    p = argparse.ArgumentParser()
    p.add_argument("which", choices=("camera", "exact"))
    cmd = p.parse_args()
    lock = reference(ROOT / "frozen-strengths.json")
    selected = {k: v[POLICY] for k, v in read_json(checked(lock))["settings"].items()}
    camera(selected, lock) if cmd.which == "camera" else exact(selected, lock)
