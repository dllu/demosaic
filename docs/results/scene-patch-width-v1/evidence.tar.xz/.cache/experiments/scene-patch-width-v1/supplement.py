"""Render measured-width examples and plot both independent wire tradeoffs."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_wide import FLAT, HOLE, LENGTH, ROOT, replay, values
from render_wide import LABELS, fields_for_record, native_board, noisy_malvar

SHORT = "gap_continuing_strong_RMS_DN16"


def draw_examples(entries, folder, scale, compare, choice, count, exposure, contrast):
    folder.mkdir()
    boards = []
    for row, provenance in entries:
        case = row["case"]
        f, parent, v120 = replay.read_inputs(case)
        updated, _ = fields_for_record(case, f, parent)
        with np.load(checked(case["input"]), allow_pickle=False) as snapshot:
            truth = snapshot["target"]
        role = 0
        args = {k: f[k][None] for k in ("wb", "matrix", "colors")}
        noisy = noisy_malvar(args | {"packed": f["packed"][role : role + 1]})[0]
        labels = (
            "Noisy Malvar",
            "V120 EMA",
            "Corpus 100k",
            LABELS[compare],
            LABELS[choice],
            "Exact GT",
        )
        images = [
            noisy,
            v120[role],
            parent[role],
            parent[role] + scale[compare] * updated[compare][role],
            parent[role] + scale[choice] * updated[choice][role],
            truth[role],
        ]
        boards.append(
            native_board(
                folder,
                case["id"],
                images,
                args,
                {"source": case, "selection": provenance, "calibration": scale},
                labels=labels,
                triplet_indices=(0, 4, 5),
                exposure=exposure,
                contrast=contrast,
                roi=(48, 48, 160, 160),
            )
        )
    assert len(boards) == count
    return boards


def curves(rows, s):
    fig, axs = plt.subplots(1, 2, figsize=(10.4, 4.2), layout="constrained")
    styling = {
        "legacy16": ("#a4aeb2", "o"),
        "mid16": ("#a16738", "^"),
        "mid32": ("#187d6c", "s"),
        "low32": ("#325ec4", "D"),
        "low32_diagonal": ("#bd4678", "v"),
        "mid32_plus_low": ("#7555b0", "P"),
    }
    scales = np.array([0, 0.5, 1, 1.5, 2])
    out = {}
    gaps = [r for r in rows if r["gap_pixels"]]
    for mode, (color, marker) in styling.items():
        x = {
            metric: np.array([values(obs, mode, metric, s[mode] * g).mean() for g in scales])
            - values(obs, "origin", metric, 0).mean()
            for metric, obs in ((LENGTH, rows), (FLAT, rows), (HOLE, gaps), (SHORT, gaps))
        }
        out[mode] = {k: v.tolist() for k, v in x.items()}
        axs[0].plot(x[HOLE], x[LENGTH], color=color, marker=marker, label=LABELS[mode])
        axs[1].plot(x[FLAT], x[SHORT], color=color, marker=marker, label=LABELS[mode])
    axs[0].set(
        xlabel="Change in false long-wave gap RMS (DN16)",
        ylabel="Change in long-wave response (percentage points)",
    )
    axs[1].set(
        xlabel="Change in flat RMS (DN16)", ylabel="Change in continuing short-wire error (DN16)"
    )
    for ax in axs:
        ax.grid(alpha=0.2)
        ax.axhline(0, color="#444444", linewidth=0.8)
        ax.axvline(0, color="#444444", linewidth=0.8)
    axs[0].legend(loc="upper left", fontsize=7.5, frameon=False)
    fig.suptitle("Independent ISO6400 wire confirmation, relative to Corpus 100k")
    output = ROOT / "response-curves.png"
    fig.savefig(output, dpi=150, facecolor="white")
    plt.close(fig)
    return out, reference(output)


def main():
    torch.set_num_threads(2)
    w = reference(ROOT / "wire-study.json")
    n = reference(ROOT / "natural.json")
    wire, nat = [read_json(checked(x)) for x in (w, n)]
    assert wire["calibration"] == nat["calibration"]
    gains = {k: v["quiet"] for k, v in read_json(checked(wire["calibration"]))["settings"].items()}
    gaps = [r for r in wire["test"] if r["gap_pixels"]]

    def delta(r, metric):
        return float(
            values([r], "mid32", metric, gains["mid32"])[0]
            - values([r], "mid16", metric, gains["mid16"])[0]
        )

    best = min(gaps, key=lambda r: delta(r, SHORT))
    adverse = max((r for r in gaps if r is not best), key=lambda r: delta(r, HOLE))
    mid = [
        (
            r,
            {
                "continuing_short_change_DN16": delta(r, SHORT),
                "long_false_change_DN16": delta(r, HOLE),
            },
        )
        for r in (best, adverse)
    ]

    def lower(r):
        t = np.array([r["terms"]["low32"]["lower"]["increment"]])
        return float(
            replay.estimate(t, "increment", gains["low32"]) - replay.estimate(t, "increment", 0)
        )

    ascending = sorted(nat["rows"], key=lower)
    exact = [(r, {"lower_increment_change_DN16": lower(r)}) for r in (ascending[0], ascending[-1])]
    width = draw_examples(mid, ROOT / "native/mid", gains, "mid16", "mid32", 2, 2, 1)
    natural = draw_examples(
        exact, ROOT / "native/natural", gains, "mid32_plus_low", "low32", 2, 1 / 0.33, 2
    )
    curve, image = curves(wire["test"], gains)
    write_json(
        ROOT / "supplement.json",
        {
            "driver": reference(__file__),
            "wire": w,
            "natural": n,
            "width_views": width,
            "natural_views": natural,
            "image": image,
            "curves": curve,
        },
    )


if __name__ == "__main__":
    main()
