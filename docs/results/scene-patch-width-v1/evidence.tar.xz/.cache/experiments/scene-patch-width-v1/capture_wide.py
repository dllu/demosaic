"""Capture source-disjoint long and short crossing wires with exact gaps."""

from dataclasses import asdict, replace
from hashlib import sha256
import math
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
EXPERIMENTS = ROOT.parent
OUT = Path("/mnt/external/demosaic") / ROOT.name
SEED = 202611191825
PROFILE = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": 0.33}
ROLES = ("long-present", "long-exterior-only", "short-only", "flat")
FOOTPRINTS = ("strip", "ellipse", "smooth-dip", "contrast-step")
KEYS = ("packed", "variance", "colors", "wb", "matrix")
N = 48
QUERY = (128, 128, 256, 256)

sys.path[:0] = [
    str(EXPERIMENTS / d) for d in ("scene-patch-crossfit-v1", "green-covariance-refit-v1")
]
from capture import lines, scan
import wire_math


def geometry(index):
    rng = np.random.default_rng(scene_seed(SEED, index, "geometry"))
    a, b = rng.uniform(0.46, 0.86, 2)
    strong, weak = rng.uniform(0.094, 0.142), 1 / rng.uniform(24, 35)
    return {
        "family": FOOTPRINTS[(index // 4) % 4],
        "frequency": [
            [strong * math.cos(a), strong * math.sin(a)],
            [weak * math.cos(b), -weak * math.sin(b)],
        ],
        "phase": rng.uniform(-np.pi, np.pi, 2).tolist(),
        "strength": rng.uniform([0.011, 0.0045], [0.015, 0.0085]).tolist(),
        "width": rng.uniform(0.10, 0.16, 2).tolist(),
        "edge": float(rng.uniform(-25, 25)),
        "tint": rng.uniform(0.05, 0.12, 3).tolist(),
        "gap_center": rng.uniform(-18, 18, 2).tolist(),
        "gap_width": float(rng.uniform(23, 36)),
        "gap_length": float(rng.uniform(35, 58)),
        "gap_orientation": float(rng.uniform(0, np.pi)),
        "angle": float(rng.uniform(-1.6, 1.6)),
    }


def freeze():
    old = reference("/mnt/external/demosaic/scene-patch-crossfit-v1/plan.json")
    prior = read_json(checked(old))
    exclusions = [
        old,
        *prior["source_exclusions"],
        reference("/mnt/external/demosaic/wire-guide-refinement-v1/fresh/plan.json"),
        reference("/mnt/external/demosaic/wire-blind-spot-v1/fresh/plan.json"),
    ]
    blocked = set()
    for binding in exclusions:
        scan(read_json(checked(binding)), blocked)
    for r in lines(prior["training_manifest"]):
        scan(r, blocked)
    rows = []
    for rec in lines(prior["source_pool"]):
        h, w = rec["shape"][:2]
        if (
            rec["split"] == "val"
            and rec["bin_factor"] == 4
            and min(h, w) >= 512
            and rec["id"] not in blocked
            and rec["cache_sha256"] not in blocked
        ):
            rows.append(rec)
    rows.sort(key=lambda r: sha256(f"{SEED}/{r['id']}".encode()).digest())
    chosen = []
    for r in rows:
        if r["id"] in blocked or r["cache_sha256"] in blocked:
            continue
        blocked.update((r["id"], r["cache_sha256"]))
        i = len(chosen)
        (box,) = scene_crop_boxes(
            r["shape"][:2], patch_size=512, count=1, seed=scene_seed(SEED, i, "field")
        )
        conf = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        conf.update(
            pattern=tuple(PATTERNS)[i % 4],
            shot=PROFILE["shot"],
            read=PROFILE["read"],
            exposure=PROFILE["exposure"],
            black=0.03,
        )
        chosen.append(
            {
                "source": r,
                "box": box,
                "camera": conf,
                "geometry": geometry(i),
                "index": i,
                "partition": "calibration" if i < 16 else "confirmation",
            }
        )
        if len(chosen) == N:
            break
    assert len(chosen) == N
    ids = {r["source"]["id"] for r in chosen}
    pixels = {r["source"]["cache_sha256"] for r in chosen}
    found = 0
    for binding in read_json(checked(prior["parent_trace"]))["source_traces"]:
        for update in lines(binding):
            for r in update["sources"]:
                if r["kind"] == "photographic":
                    found += 1
                    assert r["source_id"] not in ids and r["cache_sha256"] not in pixels
    assert found == prior["parent_photo_visits_checked"] == 559808
    plan = OUT / "plan.json"
    write_json(
        plan,
        {
            "driver": reference(__file__),
            "fixture": reference(wire_math.__file__),
            "source_exclusions": exclusions,
            "source_pool": prior["source_pool"],
            "training_manifest": prior["training_manifest"],
            "parent_traces": prior["parent_trace"],
            "parent_visits_checked": found,
            "weights": prior["checkpoints"],
            "noise": PROFILE,
            "query": QUERY,
            "sources": chosen,
            "seed": SEED,
            "roles": ROLES,
        },
    )
    return plan


def capture(photo):
    photo_rgb = wire_math.decode(photo["source"], photo["box"])
    sources, _, support, _ = wire_math.exact(photo_rgb, photo["geometry"])
    seeds = {k: scene_seed(SEED, photo["index"], k) for k in ROLES}
    capture = [
        observe_scene(
            v, replace(sample_scene_recipe(SEED), **(photo["camera"] | {"noise_seed": seeds[name]}))
        )
        for name, v in zip(ROLES, sources, strict=True)
    ]
    values = {k: np.stack([getattr(x, k).numpy() for x in capture]) for k in (*KEYS, "target")}
    assert values["packed"].shape == (4, 4, 256, 256)
    data = {k: values[k][0] for k in KEYS[2:]}
    assert all(np.all(values[k] == data[k]) for k in data)
    data |= {
        "scene_packed": values["packed"][1],
        "support": support.numpy()[128:384, 128:384],
        "target": values["target"][..., 128:384, 128:384],
    }
    data |= {k: values[k][..., 64:192, 64:192].copy() for k in KEYS[:2]}
    return data, seeds


@torch.inference_mode()
def run(plan):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    bound = reference(plan)
    settings = read_json(checked(bound))
    assert settings["driver"] == reference(__file__)
    models = {}
    for label, binding in settings["weights"].items():
        net, state = load_checkpoint(checked(binding), "cuda", tiled_inference=True)
        assert "ema" in state and state["loaded_sha256"] == binding["sha256"]
        del state
        net.set_noise(PROFILE["shot"], PROFILE["read"])
        models[label] = net.eval().to(memory_format=torch.channels_last)
    dest = OUT / "observations"
    dest.mkdir()
    rows = []
    start = time.monotonic()
    with ieee_fp32():
        for fixture in settings["sources"]:
            fields, seeds = capture(fixture)
            key = f"long-{fixture['index']:02}"
            i = dest / f"{key}-input.npz"
            with i.open("xb") as stream:
                np.savez(stream, **fields)
            inp = [
                torch.from_numpy(fields[k]).cuda().contiguous(memory_format=torch.channels_last)
                for k in KEYS[:2]
            ]
            inp.extend(
                torch.from_numpy(fields[k]).cuda()[None].expand(4, *fields[k].shape)
                for k in KEYS[2:]
            )
            predictions = {k: net(*inp).cpu().numpy() for k, net in models.items()}
            assert all(
                a.shape == (4, 3, 256, 256) and a.dtype == np.float32 and np.isfinite(a).all()
                for a in predictions.values()
            )
            j = dest / f"{key}-parents.npz"
            with j.open("xb") as stream:
                np.savez(stream, **predictions)
            rows.append(
                {
                    "id": key,
                    "fixture": fixture,
                    "source": fixture["source"],
                    "box": QUERY,
                    "profile": PROFILE,
                    "input": reference(i),
                    "rgb": reference(j),
                    "rgb_key": "parent",
                    "seeds": seeds,
                    "draw": "independent",
                    "partition": fixture["partition"],
                    "packed": fingerprint(fields["packed"]),
                }
            )
            if len(rows) % 8 == 0:
                print(len(rows), round(time.monotonic() - start, 2), flush=True)
    assert len({v for r in rows for v in r["seeds"].values()}) == 4 * N
    write_json(
        OUT / "parents.json",
        {
            "plan": bound,
            "precision": "CUDA IEEE FP32 EMA",
            "weights": settings["weights"],
            "seconds": time.monotonic() - start,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    run(freeze())
