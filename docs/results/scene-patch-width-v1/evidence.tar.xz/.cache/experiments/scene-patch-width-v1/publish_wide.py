"""Bind the measured window-scale results, reviewed crops, and frozen parents."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import os
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from render_wide import ROOT, pixels

REPO = ROOT.parents[2]
DEST = REPO / "docs/results" / ROOT.name
IMAGES = REPO / "docs/images" / ROOT.name
OUT = Path("/mnt/external/demosaic") / ROOT.name


def copy(bound, folder):
    src = checked(bound)
    end = IMAGES / folder / src.name
    shutil.copyfile(src, end)
    assert reference(end)["sha256"] == bound["sha256"]
    return bound | {"path": str(end.relative_to(IMAGES))}


def board(row, folder):
    assert all(x.shape == (160, 160, 3) for x in pixels(row).values())
    return row | {"image": copy(row["image"], folder)}


def exact(row, folder, method):
    full, trip = (pixels(row[k]) for k in ("board", "triplet"))
    assert list(trip) == ["Noisy Malvar", method, "Exact GT"]
    assert all(np.array_equal(v, full[k]) for k, v in trip.items())
    return row | {k: board(row[k], folder) for k in ("board", "triplet")}


def main():
    specs = {
        "calibration": "frozen-strengths.json",
        "wires": "wire-study.json",
        "natural": "natural.json",
        "geometry": "basis-audit.json",
        "exact": "native/exact/result.json",
        "standing": "native/standing/result.json",
        "supplement": "supplement.json",
        "sheets": "sheets.json",
    }
    refs = {k: reference(ROOT / p) for k, p in specs.items()}
    report = {k: read_json(checked(v)) for k, v in refs.items()}
    a, w, n, g, x, c, s, views = (report[k] for k in specs)
    assert (
        w["calibration"]
        == n["calibration"]
        == x["strengths"]
        == c["strengths"]
        == refs["calibration"]
    )
    assert s["wire"] == x["measurements"] == refs["wires"] and s["natural"] == refs["natural"]
    assert views["references"] == {key: refs[key] for key in ("exact", "standing", "supplement")}
    assert a["model"] == g["kernel"] and g["same_legacy_terms"]
    parents = read_json(checked(a["parents"]))
    fresh = read_json(checked(parents["plan"]))
    assert fresh["parent_visits_checked"] == 559808
    assert len(a["calibration"]) == 16 and len(w["test"]) == len(n["rows"]) == 32
    assert len(x["rows"]) == 4 and len(s["width_views"]) == len(s["natural_views"]) == 2
    assert len(c["rows"]) == 8 and sum(len(r["displays"]) for r in c["rows"]) == 12
    for img in views["views"].values():
        checked(img)
    for folder in ("exact", "mid", "natural", "standing"):
        (IMAGES / folder).mkdir(parents=True)
    image_index = {
        k: [exact(r, k, method) for r in group]
        for k, group, method in (
            ("exact", x["rows"], "32 px low band"),
            ("mid", s["width_views"], "32 px same band"),
            ("natural", s["natural_views"], "32 px low band"),
        )
    }
    image_index["standing"] = []
    for row in c["rows"]:
        displays = []
        for d in row["displays"]:
            names = pixels(d["board"]).keys()
            assert {
                "Noisy (Malvar)",
                "V120 EMA",
                "Corpus 100k",
                "32 px same band",
                "32 px low band",
                "ISO100 AHD reference",
            } <= names
            if row["id"].startswith("mesh"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= names
            displays.append(d | {"board": board(d["board"], "standing")})
        image_index["standing"].append(row | {"displays": displays})
    manifest = IMAGES / "manifest.json"
    notes = {
        "long": "Both long-band boards retain softer long crossings than the exact target. The higher false-gap example looks close to the parent.",
        "same_band": "The shorter family is slightly more coherent on the cedar example and still soft across the diagonal transition.",
        "natural": "The island sky gradient is visually smooth. The woodland keeps soft leaves and edge detail close to the parent.",
        "main": "The sky looks smooth and the coarse fence is coherent. Small leaves and building wires remain soft.",
        "fine_cab": "Both noise profiles and both native exposures retain incomplete fine crossings. The right diagonal traces remain clearest under transferred conditioning.",
    }
    write_json(
        manifest,
        image_index
        | {
            "checkpoints": parents["weights"],
            "strengths": refs["calibration"],
            "figure": copy(s["image"], ""),
            "inspection": {
                "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                "reviewed_sheets": refs["sheets"],
                "notes": notes,
            },
        },
    )

    original = reference(ROOT / "previous-patch-code.py")
    past = read_json(checked(read_json(checked(g["source"]))["calibration"]))
    assert original["sha256"] == past["kernel"]["sha256"]
    package = [
        *refs.values(),
        *[(r["driver"]) for r in report.values()],
        a["model"],
        a["parents"],
        parents["plan"],
        fresh["fixture"],
        fresh["driver"],
        w["fixture_metric"],
        n["source"],
        c["prior"],
        g["source"],
        original,
        reference(manifest),
        reference(__file__),
        reference(REPO / "tests/test_scene_patch_covariance.py"),
    ]
    staged = OUT / "publication-evidence.tar.xz"
    members = {}
    with tarfile.open(staged, "x:xz", preset=4) as arc:
        for ref in {v["path"]: v for v in package}.values():
            src = checked(ref)
            name = (
                src.relative_to(REPO)
                if src.is_relative_to(REPO)
                else Path("external") / src.relative_to(OUT.parent)
            ).as_posix()
            arc.add(src, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(staged, "r:xz") as arc:
        assert all(sha256(arc.extractfile(k).read()).hexdigest() == v for k, v in members.items())
    DEST.mkdir()
    archive = DEST / "evidence.tar.xz"
    tmp = DEST / ".evidence.tar.xz"
    try:
        with staged.open("rb") as src, tmp.open("xb") as to:
            shutil.copyfileobj(src, to)
            to.flush()
            os.fsync(to.fileno())
        assert reference(tmp)["sha256"] == reference(staged)["sha256"]
        os.link(tmp, archive)
    finally:
        tmp.unlink(missing_ok=True)
    write_json(
        DEST / "publication.json",
        {
            "study": ROOT.name,
            "checkpoints": parents["weights"],
            "scope": "Frozen-weight inference on fresh planted wires, natural photos and standing GFX. No fixed 427 or measured CFA PSNR.",
            "strengths": a["settings"],
            "wire_confirmation": w["summary"],
            "natural": n["summary"],
            "renderer": reference(manifest),
            "archive": reference(archive),
            "archive_members": members,
            "receipts": refs,
            "fresh_plan": parents["plan"],
            "fresh_parents": a["parents"],
            "execution_seconds": {
                "parent_loop": parents["seconds"],
                "calibration": a["elapsed"],
                "confirmation": w["seconds"],
                "natural": n["elapsed"],
            },
        },
    )


if __name__ == "__main__":
    main()
