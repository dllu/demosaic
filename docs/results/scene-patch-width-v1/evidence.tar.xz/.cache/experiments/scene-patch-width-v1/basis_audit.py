"""Measure exact theoretical projection from each physical green grid."""

import numpy as np

from demosaic import scene_patch_covariance as patch
from demosaic.experiments.artifacts import read_json, reference, write_json
from evaluate_wide import BANDS, OLDER, ROOT, replay

LAYOUTS = ((0, 1, 1, 2), (1, 0, 2, 1), (1, 2, 0, 1), (2, 1, 1, 0))
FREQUENCIES = {
    "planted_27p69": (np.cos(0.63) / 27.69, -np.sin(0.63) / 27.69),
    "DSCF3842_real_A": (0.1171875, 0.07421875),
    "DSCF3842_real_B": (-0.08984375, 0.0703125),
}


def projection(band, freq, layout, phi):
    basis = patch.patch_basis(layout, band)
    coords = np.arange(band.size) + 0.5
    grid = 2 * np.pi * (freq[0] * coords[None, :] + freq[1] * coords[:, None]) + phi
    color = 0.3 + 0.015 * np.cos(grid)
    raw = np.stack([color[i // 2 :: 2, i % 2 :: 2] for i in range(4)])[None]
    _, values, _, _ = patch.encode(raw, basis, 0.00128, 6.5536e-6)
    signal = np.cos(grid) * 0.015
    fits = np.einsum("gk,kyx->gyx", values[0], basis.image)
    return [float(np.sum(signal * fit) / np.sum(signal**2)) for fit in fits]


def main():
    before = reference(OLDER / "evaluation.json")
    previous = read_json(before["path"])
    sample = previous["cases"][3]
    args, parent, _ = replay.read_inputs(sample["case"])
    row = sample["case"]
    profile = row["profile"]
    noise = profile["shot"], profile["read"]
    atlas = patch.build_exterior(args["scene_packed"], args["colors"], row["box"], *noise)
    members = [
        patch.corrections(
            raw, base[1], args["colors"], *noise, row["box"], atlas, validate_donors=True
        )["donor_and_query"]
        for raw, base in zip(args["packed"], parent, strict=True)
    ]
    disp = np.stack(
        [
            replay.apply_delta(np.zeros_like(img), v, args["wb"], args["matrix"], 1.0)
            for img, v in zip(parent, members, strict=True)
        ]
    )
    with np.load(row["input"]["path"], allow_pickle=False) as f:
        target = replay.transform(f["target"], args)
    measured = replay.transform(disp, args)
    check = {
        k: replay.terms(v, measured[k], target[k])
        for k, v in replay.transform(parent, args).items()
    }
    assert check == sample["terms"]["donor_and_query"]
    out = {}
    for name, xy in FREQUENCIES.items():
        out[name] = {
            k: np.asarray(
                [projection(b, xy, p, q) for p in LAYOUTS for q in np.arange(16) * np.pi / 8]
            )
            .ravel()
            .tolist()
            for k, b in BANDS.items()
        }
    write_json(
        ROOT / "basis-audit.json",
        {
            "driver": reference(__file__),
            "kernel": reference(patch.__file__),
            "source": before,
            "same_legacy_terms": True,
            "parity_case": row["id"],
            "frequencies": FREQUENCIES,
            "values": out,
        },
    )


if __name__ == "__main__":
    main()
