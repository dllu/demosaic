"""Prepare unscaled contact sheets for checking the recorded crop pixels."""

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from render_wide import ROOT, pixels


def board(rows, labels, key):
    image = Image.new("RGB", (8 + 168 * len(labels), 30 + 179 * len(rows)), "#eeeeee")
    text = ImageDraw.Draw(image)
    for j, name in enumerate(labels):
        text.text((8 + 168 * j, 5), name, fill="black")
    for i, (name, meta) in enumerate(rows):
        all_ = pixels(meta)
        for j, label in enumerate(labels):
            tile = Image.fromarray(all_[label])
            assert tile.size == (160, 160)
            image.paste(tile, (8 + 168 * j, 30 + i * 179))
        text.text((8, 191 + i * 179), name, fill="black")
    path = ROOT / f"inspect-{key}.png"
    image.save(path)
    return reference(path)


def main():
    refs = {
        key: reference(ROOT / path)
        for key, path in (
            ("exact", "native/exact/result.json"),
            ("standing", "native/standing/result.json"),
            ("supplement", "supplement.json"),
        )
    }
    exact, camera, supp = [
        read_json(checked(refs[key])) for key in ("exact", "standing", "supplement")
    ]
    views = {}
    for key, rows, labels in (
        (
            "low",
            exact["rows"],
            ("Noisy Malvar", "Corpus 100k", "32 px same band", "32 px low band", "Exact GT"),
        ),
        (
            "mid",
            supp["width_views"],
            ("Noisy Malvar", "Corpus 100k", "16 px same band", "32 px same band", "Exact GT"),
        ),
        (
            "natural",
            supp["natural_views"],
            ("Noisy Malvar", "Corpus 100k", "32 px two bands", "32 px low band", "Exact GT"),
        ),
    ):
        views[key] = board([(r["id"], r["board"]) for r in rows], labels, key)
    for name, level in (("main", 4), ("mesh", 4), ("mesh", 16)):
        records = [
            (r["id"], d["board"])
            for r in camera["rows"]
            if r["id"].startswith(name)
            for d in r["displays"]
            if d["exposure"] == level
        ]
        key = f"{name}-x{level}"
        views[key] = board(
            records,
            (
                "Noisy (Malvar)",
                "V120 EMA",
                "Corpus 100k",
                "16 px same band",
                "32 px same band",
                "ISO100 AHD reference",
            ),
            key,
        )
        if name == "mesh":
            views[key + "-refs"] = board(
                records,
                ("ISO6400 camera JPEG", "32 px low band", "32 px two bands", "ISO100 camera JPEG"),
                key + "-refs",
            )
    write_json(
        ROOT / "sheets.json", {"driver": reference(__file__), "references": refs, "views": views}
    )


if __name__ == "__main__":
    main()
