"""Measure one restored variant per policy with identical staging."""
import os
import time

import numpy as np
import torch

from audit import ROOT, LOCAL, PRIOR, review, setup, wire_inputs
from distant import prepare, complex_values, rgb_residual
from exterior import nominated
from quadrature import subtract, witnesses
from demosaic.phase_witness import _unit
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


@torch.inference_mode()
def main():
    models, receipt = setup()
    networks, _, doses, routers = models
    core = max(os.sched_getaffinity(0))
    os.sched_setaffinity(0, [core])
    pointer = reference(PRIOR / "wire-parent.json")
    data = read_json(checked(pointer))
    plan = read_json(checked(data["plan"]))
    cases = read_json(checked(data["inputs"]))["rows"]
    case = next(r for r in cases if r["index"] == 12 and r["noise"] == "iso6400")
    sample, parent, proof = wire_inputs(case, {r["id"]:r for r in data["rows"]}, None)
    raw, layout, wb, matrix = (sample[k][0] for k in ("packed","colors","wb","matrix"))
    noise, box = plan["profiles"]["iso6400"], plan["query"]
    donors = review.exterior(sample["full"], layout, noise, box)
    parent = parent[LOCAL][0]
    common = (raw, layout, noise, box, donors, parent, wb, matrix, networks)

    def fixed():
        field, _, near, wide, *_ = witnesses(*common)
        restored = parent + rgb_residual(wide, field)
        phase = _unit(np.where(abs(wide) > 1e-8, wide, near))
        seen, predicted, sigma = subtract(raw, layout, noise, restored)
        coefficient = nominated(raw, layout, noise, phase, seen, predicted, sigma)["exterior-only"]
        return restored + np.float32(doses["exterior-only"]) * rgb_residual(coefficient, field)

    def learned():
        field, _, _, restored, basis, _, context, _ = prepare(*common)
        response = routers["EMA"]["distant"](torch.from_numpy(context["matching"]),
                                             torch.from_numpy(complex_values(basis))).numpy()
        return restored + rgb_residual(response[..., 0] + 1j*response[..., 1], field)

    policy = {"fixed phase": fixed, "distant gate": learned}
    for fn in policy.values():
        assert np.isfinite(fn()).all()
    observed = {k:[] for k in policy}
    for i in range(16):
        for k in list(policy)[::1 if i%2 == 0 else -1]:
            start = time.perf_counter()
            policy[k]()
            observed[k].append(1000*(time.perf_counter()-start))
    folder = os.path.join("docs", "results", ROOT.name)
    write_json(os.path.join(folder, "matched-runtime.json"), receipt | {
        "driver": reference(__file__), "input": case["input"], "parent_output": proof, "cpu_affinity": [core],
        "median_ms": {k:float(np.median(v)) for k,v in observed.items()}, "samples_ms": observed,
        "scope": "One warmed 256-pixel Bayer correction on one CPU core. Both arms start with the same retained parent and exterior donation bank. Each delivers one output. Neither includes parent inference or input decode.",
    })


if __name__ == "__main__":
    main()
