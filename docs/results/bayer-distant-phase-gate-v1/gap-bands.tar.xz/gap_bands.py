"""Audit leakage into the missing wire family inside exact gap footprints."""
from functools import partial
from pathlib import Path
import sys

import numpy as np

from review_gate import ROOT, PRIOR, LOCAL, CORE, predict, review, setup, wire_inputs
from review_quiet import numeric
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0, str(ROOT.parent / "local-phase-envelope-v1"))
from gap_projection import subspace, summarize

LABELS = ("ring8", "exterior-only", "constant", "near", "distant", "distant-rotated", "distant-shifted")


def examine(case, plan, lookup, models):
    data, parents, baseline = wire_inputs(case, lookup, None)
    side = data["support"][CORE]
    gap = side <= .01
    if not np.any(gap):
        return None
    scene = plan["sources"][case["index"]]
    noise = plan["profiles"][case["noise"]]
    restored = predict(data, data["full"], noise, plan["query"], parents[LOCAL], models, True)
    solution = subspace(scene["geometry"], gap)
    def luma(a):
        return review.old.luma(a, data)[0, CORE[0], CORE[1]].astype(np.float64)
    clean = luma(data["target"])
    wide = luma(restored["ring8"])
    scores = {}
    for arm in LABELS:
        result = luma(restored[arm])
        scores[arm] = summarize(result-wide, result-clean, gap, solution)
    return {"source_id":scene["source"]["id"], "profile":case["noise"],
            "input":case["input"], "parent_output":baseline, "gap_pixels":int(gap.sum()),
            "metrics":scores | {"matched":scores["ring8"]}}


if __name__ == "__main__":
    model, binding = setup()
    inputs = reference(PRIOR / "wire-parent.json")
    bound = read_json(checked(inputs))
    rows = review.run(read_json(checked(bound["inputs"]))["rows"],
                      partial(examine, plan=read_json(checked(bound["plan"])),
                              lookup={row["id"]:row for row in bound["rows"]}, models=model))
    kept = [r for r in rows if r is not None]
    panels = {iso:[r for r in kept if r["profile"] == iso]for iso in ("iso400","iso6400")}
    assert all(len(v)==12 for v in panels.values())
    summary = numeric(panels, [("distant",key)for key in LABELS if key!="distant"],
                      ("gap_weak_band_error","gap_weak_band_added","gap_other_error","gap_strong_band_added"))
    write_json(ROOT / "gap-bands.json", binding | {"driver":reference(__file__), "rows":kept, "inputs":inputs,
                                                  "reports":summary})
