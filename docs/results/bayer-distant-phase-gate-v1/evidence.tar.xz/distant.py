"""Gate a frozen exterior correction with separate longer-range Bayer measurements."""
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
QUADRATURE = ROOT.parent / "bayer-phase-quadrature-v1"
sys.path.insert(0, str(QUADRATURE))

from quadrature import subtract, witnesses, rgb_residual
from wide_witness import AXIAL, CORNERS, NEAR, choose, contributions, references, TRANSPORT
from demosaic.phase_witness import MEAN_RESPONSE, SIDE, UNIQUE, _gather, _transform, _unit

ARMS = ("constant", "near", "distant")
NEAR_LABELS = (
    "cardinal-reserved-support", "diagonal-reserved-support", "cross-fit-phase-cosine",
    "frequency-agreement-Y", "frequency-agreement-X", "activation", "parallel-deficit-sigma",
    "quadrature-deficit-sigma", "green-A-parallel", "green-B-parallel",
    "green-A-perpendicular", "green-B-perpendicular", "shot-log", "read-log",
    "frequency-cycles-Y", "frequency-cycles-X",
)
FAR_LABELS = (
    "tangent-signed-first-frequency", "tangent-signed-second-frequency",
    "normal-signed-first-frequency", "normal-signed-second-frequency",
    "tangent-quadrature-first-frequency", "tangent-quadrature-second-frequency",
    "normal-quadrature-first-frequency", "normal-quadrature-second-frequency",
    "directed-positive-first-frequency", "directed-positive-second-frequency",
    "available-tangent-first", "available-tangent-second",
)
LABELS = NEAR_LABELS + FAR_LABELS
RANGES = np.array((.39, .62), dtype=np.float32)


def complex_values(values):
    return np.stack((values.real, values.imag), axis=-1).astype(np.float32)


class Router(nn.Module):
    def __init__(self, mode):
        super().__init__()
        self.mode = mode
        self.level = nn.Parameter(torch.logit(torch.from_numpy(RANGES.copy())))
        if mode != "constant":
            self.net = nn.Sequential(nn.Linear(len(LABELS), 32), nn.SiLU(), nn.Linear(32, 24),
                                     nn.SiLU(), nn.Linear(24, 2))
            nn.init.zeros_(self.net[-1].weight)
            nn.init.zeros_(self.net[-1].bias)

    def forward(self, evidence, basis):
        weights = self.level
        if self.mode != "constant":
            if self.mode == "near":
                evidence = torch.cat((evidence[..., :len(NEAR_LABELS)],
                                      torch.zeros_like(evidence[..., len(NEAR_LABELS):])), dim=-1)
            weights = weights + self.net(evidence)
        return (weights.sigmoid()[..., None] * basis).sum(dim=-2)


def reciprocal_fit(direct, noise_var):
    cardinal, diagonal = [contributions(direct, noise_var, g) for g in (NEAR, CORNERS)]
    gains, scores, slots, origin = [], [], [], []
    for donor, reserved, geometry in ((cardinal, diagonal, CORNERS), (diagonal, cardinal, NEAR)):
        values, power = donor
        held, held_power = reserved
        offset, selected = choose(values, power, True)
        _, counts = contributions(direct, np.ones_like(noise_var), geometry)
        sample = lambda value: np.take_along_axis(value, selected, axis=1)
        witness = sample(held)
        nominated = _unit(sample(values))
        hold_z = (witness * nominated.conj()).real / np.sqrt(sample(held_power)).clip(min=2e-5)
        gains.append(witness * MEAN_RESPONSE[offset] / sample(counts).clip(min=1))
        scores.append(hold_z)
        slots.append(selected)
        origin.append(nominated)
    cosine = (_unit(gains[0]) * _unit(gains[1]).conj()).real
    weights = [np.maximum(z-1, 0) for z in scores]
    gate = np.sqrt(weights[0] / (1 + weights[0]) * weights[1] / (1 + weights[1])) * cosine.clip(min=0)
    return gains, scores, slots, origin, cosine, gate


def distant_support(values, variance, selected, nominated, rotated):
    """Score the fixed nomination on the four disjoint farther axial windows."""
    field = values.reshape(SIDE, SIDE, -1)
    noise = variance.reshape(SIDE, SIDE)
    frequency = UNIQUE[selected]
    normal = frequency / np.maximum(1, np.linalg.norm(frequency, axis=-1, keepdims=True))
    projections, available = [], []
    for offset in AXIAL:
        query, donor = references(*offset)
        transported = np.zeros_like(field)
        transported[query] = field[donor] * TRANSPORT[offset]
        seen = np.take_along_axis(transported.reshape(values.shape), selected, axis=1)
        std = np.zeros((SIDE, SIDE), dtype=np.float32)
        std[query] = np.sqrt(noise[donor])
        sigma = std.reshape(-1, 1)
        # Frequency is fixed before these windows are read.
        z = seen * nominated.conj() / sigma.clip(min=2e-5)
        projections.append(z)
        available.append(sigma > 0)
    support = np.stack(projections)
    available = np.stack(available)
    align = np.square(np.einsum("wfk,dk->dwf", normal, np.asarray(AXIAL)) / 4)
    tangent = align if rotated else 1-align
    axes = [available * w for w in (tangent, 1-tangent)]
    denominator = [np.sqrt((w**2).sum(axis=0)).clip(min=.5) for w in axes]
    totals = [(w * support).sum(axis=0)/d for w, d in zip(axes, denominator, strict=True)]
    positive = (axes[0] * (support.real > 1)).sum(axis=0) / axes[0].sum(axis=0).clip(min=.5)
    return totals[0].real, totals[1].real, totals[0].imag, totals[1].imag, positive, axes[0].sum(axis=0)


def observations(raw, layout, noise, phase, seen, predicted, sigma, *, controls):
    transform, variance = _transform(raw, float(noise["shot"]), float(noise["read"]))
    greens = np.flatnonzero(layout == 1)
    direct = (_gather(transform, greens[0]) + _gather(transform, greens[1])) * .5
    green_variance = variance[:, greens].sum(1) * .25
    gains, support, slots, phases, cosine, evidence = reciprocal_fit(direct, green_variance)
    innovation = ((gains[0] + gains[1]) * .5 - predicted.mean(axis=0)) * phase.conj()
    same_sites = (seen - predicted) * phase.conj()
    local_diff = same_sites / sigma
    standard = sigma.mean(axis=0)
    limit = 2 * standard
    # The arm can attenuate each measured component independently.
    bases = phase[..., None] * evidence[..., None] * np.stack((
        innovation.real.clip(-limit, limit), 1j * innovation.imag.clip(-limit, limit),
    ), axis=-1)
    disagreement = (UNIQUE[slots[0]] - UNIQUE[slots[1]]) / 4
    freq = (UNIQUE[slots[0]] + UNIQUE[slots[1]]) / 64
    shared = [np.arcsinh(s) for s in support] + [
        cosine, disagreement[..., 0], disagreement[..., 1], evidence,
        np.arcsinh(innovation.real/standard), np.arcsinh(innovation.imag/standard),
        np.arcsinh(local_diff[0].real), np.arcsinh(local_diff[1].real),
        np.arcsinh(local_diff[0].imag), np.arcsinh(local_diff[1].imag),
        np.full_like(evidence, np.log10(max(1e-10, noise["shot"])) + 4.),
        np.full_like(evidence, np.log10(max(1e-11, noise["read"])) + 7.),
        freq[..., 0], freq[..., 1],
    ]
    variants = {}
    for rotated in (False, True) if controls else (False,):
        left, right = [distant_support(direct, green_variance, idx, z, rotated)
                       for idx, z in zip(slots, phases, strict=True)]
        extra = [a for pair in zip(left, right, strict=True) for a in pair]
        extra[:8] = [np.arcsinh(a) for a in extra[:8]]
        values = np.stack((*shared, *extra), axis=-1).clip(-6, 6).astype(np.float32)
        assert values.shape[-1] == len(LABELS)
        variants["rotated" if rotated else "matching"] = values
    if controls:
        values = variants["matching"]
        extra = values[..., len(NEAR_LABELS):].reshape(SIDE, SIDE, *values.shape[1:-1], len(FAR_LABELS))
        replaced = np.roll(extra, (5, 7), axis=(0, 1)).reshape(*values.shape[:-1], len(FAR_LABELS))
        variants["shifted"] = np.concatenate((values[..., :len(NEAR_LABELS)], replaced), axis=-1)
    return bases.astype(np.complex64), same_sites.mean(axis=0).imag * innovation.imag > 0, variants


@torch.inference_mode()
def prepare(raw, layout, noise, box, donors, parent, wb, matrix, networks, target=None, *, controls=False):
    field, std, near, wide, _, _, baseline = witnesses(
        raw, layout, noise, box, donors, parent, wb, matrix, networks, target,
    )
    restored = parent + rgb_residual(wide, field)
    phase = _unit(np.where(abs(wide) > 1e-8, wide, near))
    seen, predicted, sigma = subtract(raw, layout, noise, restored)
    extra, local, descriptor = observations(raw, layout, noise, phase, seen, predicted, sigma, controls=controls)
    return field, std, wide, restored, extra, local, descriptor, baseline
