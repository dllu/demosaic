"""Evaluate the learned Bayer gate against controls on unchanged inputs."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from distant import ARMS, ROOT, QUADRATURE, Router, complex_values, prepare, rgb_residual
from composed import setup as exterior_setup
from mixture import PRIOR, combine
from review_quiet import LOCAL, CORE, numeric, photo_inputs, wire_inputs
import evaluate_gap_head as review
from demosaic.archive_metrics import photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CAPTIONS = {
    "Bayer-gated": "Bayer-gated refit", "ring8": "Eight-donor EMA",
    "exterior-phase-locked": "Fixed exterior amplitude", "exterior-only": "Fixed exterior phase",
    "constant": "Learned scalar", "near": "Near Bayer gate", "distant": "Distant Bayer gate",
    "distant-rotated": "Distant gate, rotated evidence", "distant-shifted": "Distant gate, shifted evidence",
}
NEIGHBOR_MODES = ("near", "distant", "distant-shifted", "distant-rotated")
MATCH_CONTROLS = ("constant", "near", "exterior-only", "exterior-phase-locked")


def setup():
    torch.set_num_threads(1)
    (frozen, upstream, doses), earlier = exterior_setup()
    binding = reference(ROOT / "training" / "completed.json")
    info = read_json(checked(binding))
    assert all(info[k] == earlier[v] for k, v in (("parent", "parent"), ("wide_checkpoint", "checkpoint"),
                                                  ("wide_training", "wide_training"), ("frozen_phase", "frozen_phase")))
    checkpoint = torch.load(checked(info["checkpoint"]), weights_only=True, map_location="cpu")
    weights = {}
    for kind in ("EMA", "raw"):
        weights[kind] = {}
        for mode in ARMS:
            network = Router(mode)
            network.load_state_dict(checkpoint[kind][mode])
            weights[kind][mode] = network.eval().requires_grad_(False)
    receipt = earlier | {"driver": reference(__file__), "training": binding,
                         "frozen_wide_checkpoint": info["wide_checkpoint"], "checkpoint": info["checkpoint"],
                         "inference": "EMA routers, CUDA FP32 retained parent, FP32 CPU head and native overlap"}
    return (frozen, upstream, doses, weights), receipt


@torch.inference_mode()
def compose(raw, layout, wb, matrix, noise, box, donations, parent, models, include_controls):
    frozen, upstream, doses, weights = models
    field, _, _, base, basis, veto, evidence, earlier = prepare(
        raw, layout, noise, box, donations, parent, wb, matrix, frozen, controls=include_controls,
    )
    *_, transported, experts, descriptors, _ = earlier
    results = {"ring8": base, "Bayer-gated": parent + combine(upstream, field, transported, experts, descriptors)["Bayer-gated"]}
    for name, component in (("exterior-phase-locked", basis[..., 0]), ("exterior-only", basis[..., 1]),
                            ("exterior-local", basis[..., 1]*veto)):
        results[name] = base + np.float32(doses[name]) * rgb_residual(component, field)
    basis = torch.from_numpy(complex_values(basis))
    modes = [(mode, "matching", "EMA", mode) for mode in ARMS]
    if include_controls:
        modes += [("distant", evidence, "EMA", "distant-" + evidence) for evidence in ("rotated", "shifted")]
        modes += [("distant", "matching", "raw", "distant-raw")]
    for mode, context, kind, name in modes:
        values = weights[kind][mode](torch.from_numpy(evidence[context]), basis).numpy()
        results[name] = base + rgb_residual(values[..., 0] + 1j*values[..., 1], field)
    assert all(v.dtype == np.float32 and np.isfinite(v).all() for v in results.values())
    return results


def render_models(raw, layout, wb, matrix, noise, box, exterior, parent, models, _unused=None):
    donations = review.exterior(exterior, layout, noise, box)
    results = compose(raw, layout, wb, matrix, noise, box, donations, parent, models, True)
    return {key: results[key] for key in CAPTIONS}


def predict(data, raw, noise, box, parent, models, controls):
    donations = review.exterior(raw, data["colors"][0], noise, box)
    output = {}
    for view, layout, wb, matrix, image in zip(data["packed"], data["colors"], data["wb"],
                                             data["matrix"], parent, strict=True):
        results = compose(view, layout, wb, matrix, noise, box, donations, image, models, controls)
        for key, value in results.items():
            output.setdefault(key, []).append(value)
    return {key: np.stack(values) for key, values in output.items()}


def with_matching(results, scales):
    base = results["ring8"]
    return results | {arm+"-matched": base + np.float32(scale)*(results[arm]-base) for arm, scale in scales.items()}


def photo_row(pointer, models, scales, controls):
    item, data, parents, proof = photo_inputs(pointer)
    predictions = predict(data, data["scene_packed"], item["profile"], item["box"], parents[LOCAL], models, controls)
    outputs = parents | with_matching(predictions, scales)
    def bands(value):
        return review.old.target_coeff(value, data, review.old.ROI)
    target = bands(data["target"])
    increment = target[0] - target[1]
    anchor = bands(outputs["ring8"])[2]
    exposure = item["profile"]["exposure"]
    metrics = {}
    for key, value in outputs.items():
        c = bands(value)
        response = c[0] - c[1]
        dot, power = review.aligned(increment.ravel(), response.ravel())
        metrics[key] = {
            "increment_rms": review.old.source_rms(response-increment, 96**2),
            "flat_rms": review.old.source_rms(c[2], 96**2),
            "flat_added": review.old.source_rms(c[2]-anchor, 96**2),
            "intact_dot": dot, "intact_power": power,
            "srgb_present_psnr": float(photometry(value/exposure, data | {"target": data["target"]/exposure})["srgb_psnr"][0]),
        }
    return {"id": item["id"], "source_id": item["source"], "profile": item["profile"]["name"], "draw": item["draw"],
            "input": item["input"], "parent_output": proof, "metrics": metrics | {"matched": metrics["ring8"]}}


def wire_row(task, models, scales, plan, lookup, v120, controls):
    data, parents, proof = wire_inputs(task, lookup, v120)
    scene = plan["sources"][task["index"]]
    noise = plan["profiles"][task["noise"]]
    predictions = predict(data, data["full"], noise, plan["query"], parents[LOCAL], models, controls)
    outputs = parents | with_matching(predictions, scales)
    def luma(value):
        return review.old.luma(value, data)[..., CORE[0], CORE[1]]
    target = luma(data["target"])
    anchor = luma(outputs["ring8"])
    area = data["support"][CORE]
    intact, gap = area >= .97, area <= .01
    increment = (target[0] - target[1])[intact]
    metrics = {}
    for key, value in outputs.items():
        rgb = luma(value)
        response = (rgb[0]-rgb[1])[intact]
        dot, power = review.aligned(increment, response)
        flat = np.s_[3, 8:-8, 8:-8]
        metrics[key] = {
            "intact_dot": dot, "intact_power": power, "intact_rms": review.rms(response-increment),
            "gap_exact": review.rms((rgb[0]-target[0])[gap]) if gap.any() else None,
            "gap_added": review.rms((rgb[0]-anchor[0])[gap]) if gap.any() else None,
            "flat_rms": review.rms((rgb-target)[flat]),
            "flat_added": review.rms((rgb-anchor)[flat]),
        }
    return {"id": f'{task["index"]:03d}-{task["noise"]}', "source_id": scene["source"]["id"], "profile": task["noise"],
            "input": task["input"], "parent_output": proof, "gap_pixels": int(gap.sum()),
            "metrics": metrics | {"matched": metrics["ring8"]}}


def dose(rows, key):
    strengths = review.score_group(rows)
    target = strengths["distant"][key]["mean"]
    doses = {arm: target/max(strengths[arm][key]["mean"], 1e-12) for arm in MATCH_CONTROLS}
    assert all(np.isfinite(v) for v in doses.values())
    return doses


def evaluate(panel):
    models, receipt = setup()
    start = time.monotonic()
    if panel == "photo":
        prior = reference(PRIOR / "natural-results.json")
        natural = read_json(checked(prior))
        sources = read_json(checked(natural["inputs"]))["records"]
        calibration, holdout = [], []
        membership = review.panel_membership()
        for pointer in sources:
            info = read_json(checked(read_json(checked(pointer))["case"]))
            if info["draw"] == "independent":
                if info["source"] not in membership:
                    holdout.append(pointer)
                elif info["profile"]["name"] == "iso6400":
                    calibration.append(pointer)
        assert len(calibration) == 16 and len(holdout) == 96
        tune = review.run(calibration, partial(photo_row, models=models, scales={}, controls=False))
        scales = dose(tune, "flat_added")
        rows = review.run(holdout, partial(photo_row, models=models, scales=scales, controls=True))
        earlier = reference(QUADRATURE / "natural-screen.json")
        older = {r["id"]: r for r in read_json(checked(earlier))["rows"]}
        for row in rows:
            before = older[row["id"]]
            assert (row["input"], row["parent_output"]) == (before["input"], before["local20k_outputs"])
            for name in ("ring8", "exterior-only", "exterior-phase-locked"):
                for key in ("increment_rms", "flat_rms", "srgb_present_psnr"):
                    assert abs(row["metrics"][name][key]-before["metrics"][name][key]) < .001
        fields = ("intact_response", "increment_rms", "flat_rms", "flat_added", "srgb_present_psnr")
    else:
        hold = reference(PRIOR / "wire-parent.json")
        tune_source = reference(PRIOR / "wire-tune-parent.json")
        earlier = reference(QUADRATURE / "exterior-screen.json")
        v120_receipt = read_json(checked(reference(ROOT.parent / "learned-spectral-detail-v1" / "v120-wire.json")))
        v120 = {r["input"]["sha256"]: r for r in v120_receipt["rows"]}
        def measure(pointer, scales, controls):
            info = read_json(checked(pointer))
            by_id = {r["id"]: r for r in info["rows"]}
            plan = read_json(checked(info["plan"]))
            samples = read_json(checked(info["inputs"]))["rows"]
            return review.run(samples, partial(wire_row, models=models, scales=scales, plan=plan, lookup=by_id,
                                                v120=v120 if controls else None, controls=controls))
        tune = measure(tune_source, {}, False)
        assert len(tune) == 24
        scales = dose([r for r in tune if r["gap_pixels"]], "gap_added")
        rows = measure(hold, scales, True)
        assert len(rows) == 48
        older = {r["id"]: r for r in read_json(checked(earlier))["rows"]["wire"]}
        for row in rows:
            before = older[row["id"]]
            assert (row["input"], row["parent_output"]) == (before["input"], before["local20k_output"])
            gram = before["products"]["exterior-only"]["intact_rms"]
            expected = 65535*np.sqrt((gram[0]+2*.62*gram[1]+.62**2*gram[2])/gram[3])
            assert abs(row["metrics"]["exterior-only"]["intact_rms"]-expected) < .001
        fields = ("intact_response", "intact_rms", "gap_exact", "gap_added", "flat_rms", "flat_added")
    assert {row["source_id"] for row in tune}.isdisjoint(row["source_id"] for row in rows)
    groups = {iso: [r for r in rows if r["profile"] == iso] for iso in ("iso400", "iso6400")}
    comparisons = [(k, "ring8") for k in (*NEIGHBOR_MODES, "constant", "distant-raw", "exterior-only", "exterior-phase-locked")]
    comparisons += [("distant", k) for k in ("near", "constant", "distant-shifted", "distant-rotated",
                                              "V120", "100k", *[c+"-matched" for c in MATCH_CONTROLS])]
    write_json(ROOT / (panel+"-holdout.json"), receipt | {"prior_inputs_and_scores": earlier, "rows": rows,
               "calibration": tune, "scales": scales, "reports": numeric(groups, comparisons, fields),
               "wall_seconds": time.monotonic()-start})


if __name__ == "__main__":
    evaluate(sys.argv[1])
