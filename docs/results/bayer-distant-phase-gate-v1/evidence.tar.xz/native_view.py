"""Rearrange review boards with their original, unscaled crop pixels."""
from pathlib import Path
import sys

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json


def show(source, output, rows, keys):
    output.mkdir(exist_ok=True)
    for row in rows:
        view = keys(row)
        with Image.open(checked(view["image"])) as original:
            panels = view["panels"]
            result = Image.new("RGB", (680, ((len(panels)+3)//4)*192), "#eeeeee")
            for i, panel in enumerate(panels):
                x, y, w, h = panel["png_xywh"]
                assert w == h == 160
                result.paste(original.crop((x, 0, x+w, y+h)), (8+i%4*168, i//4*192))
            result.save(output / (Path(view["image"]["path"]).name))


if __name__ == "__main__":
    base = Path(sys.argv[1])
    record = read_json(base)
    if "native" in record:
        show(base, base.parent / "view", record["native"], lambda row: row["board"])
    elif "boards" in record:
        show(base, base.parent / "view", [r for r in record["boards"] if r["id"].startswith(("main-", "mesh-"))],
             lambda row: row)
    else:
        show(base, base.parent / "view", record["rows"], lambda row: row["board"])
