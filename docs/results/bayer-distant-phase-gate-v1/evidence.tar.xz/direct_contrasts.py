"""Compare frozen phase and the learned policy at their original doses."""
import numpy as np

from review_gate import ROOT
from derive_contrasts import contrast
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

if __name__ == "__main__":
    rng = np.random.default_rng(74239)
    panels = {"photo": ("intact_response","increment_rms","flat_rms"),
              "wire": ("intact_response","intact_rms","gap_exact","flat_rms")}
    output = {}
    for kind, metrics in panels.items():
        receipt = reference(ROOT / f"{kind}-holdout.json")
        rows = [row for row in read_json(checked(receipt))["rows"] if row["profile"] == "iso6400"]
        output[kind] = {"source": receipt,
                        "distant_minus_fixed_phase": {m:contrast(rows,"distant","exterior-only",m,rng) for m in metrics}}
    write_json(ROOT / "direct-contrasts.json", {"driver": reference(__file__), "panels": output})
