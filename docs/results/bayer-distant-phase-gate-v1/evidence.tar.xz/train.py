"""Train matched scalar, crop and distant-evidence routers on the fixed panel."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import sys
import time

import numpy as np
import torch

from distant import ARMS, LABELS, QUADRATURE, ROOT, Router, complex_values, prepare
from train_shrinkage import frozen
from direction import FABRIC
from train_directions import losses, samples
from train_gap_head import EPOCHS, PHOTOS, SEED, batch, choose_tiles, objective
from head_corrected_broad import EXACT_FLAT, NATIVE_I, NATIVE_J, SYNTH, exterior
from exterior import nominated
from quadrature import subtract
from demosaic.phase_witness import _unit
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def encode(case, row, networks, target_coefficients, check_delivery):
    metadata = read_json(checked(row["measurement"]))
    assert case["index"] == row["index"] == metadata["index"]
    parents = np.load(checked(row["parent"]), allow_pickle=False)
    with np.load(checked(metadata["input"]), allow_pickle=False) as archive:
        data = {k: archive[k] for k in ("packed", "scene_packed", "colors", "wb", "matrix", "target")}
    donations = exterior(data["scene_packed"], data["colors"][0], case["noise"], case["box"])
    args = tuple(zip(data["packed"], data["colors"], parents, data["wb"], data["matrix"], data["target"], strict=True))
    output = [prepare(a, b, case["noise"], case["box"], donations, c, d, e, networks, target=f)
              for a, b, c, d, e, f in args]
    standard = np.maximum(np.mean([r[1] for r in output[:2]], axis=0), .002)
    for item, exact in zip(output, target_coefficients, strict=True):
        calculated = complex_values(item[0].desired / standard).astype(np.float16)
        np.testing.assert_array_equal(calculated, exact)
    if check_delivery:
        for item, (raw, layout, *_rest) in zip(output, args, strict=True):
            _, _, coefficient, image, proposed, veto, _, baseline = item
            nearest = baseline[-1]
            phase = _unit(np.where(abs(coefficient) > 1e-8, coefficient, nearest))
            seen, predicted, sigma = subtract(raw, layout, case["noise"], image)
            old = nominated(raw, layout, case["noise"], phase, seen, predicted, sigma)
            np.testing.assert_allclose(proposed[..., 0], old["exterior-phase-locked"], atol=5e-8, rtol=1e-5)
            np.testing.assert_allclose(proposed[..., 1], old["exterior-only"], atol=5e-8, rtol=1e-5)
            np.testing.assert_allclose(proposed[..., 1]*veto, old["exterior-local"], atol=5e-8, rtol=1e-5)
    return {"wide": np.stack([complex_values(r[2] / standard) for r in output]),
            "extras": np.stack([complex_values(r[4] / standard[..., None]) for r in output]),
            "evidence": np.stack([r[6]["matching"] for r in output])}


def collect():
    torch.set_num_threads(1)
    networks, binding, recipe = frozen()
    feature_source = reference(FABRIC / "features.json")
    previous = read_json(checked(feature_source))
    parents = read_json(checked(previous["prior_training_parents"]))
    plan = read_json(checked(parents["plan"]))
    exact = np.load(checked(previous["tensors"]["target"]), allow_pickle=False, mmap_mode="r")
    cache = ROOT / "features"
    cache.mkdir()
    arrays = {}
    start = time.monotonic()

    def collect_one(spec):
        case, row = spec
        i = case["index"]
        return encode(case, row, networks, exact[i], i < 8)

    with ThreadPoolExecutor(3) as pool:
        for i, ready in enumerate(pool.map(collect_one, zip(plan["batches"], parents["rows"], strict=True))):
            for k, value in ready.items():
                assert np.isfinite(value).all()
                if k not in arrays:
                    arrays[k] = np.lib.format.open_memmap(cache / f"{k}.npy", mode="w+", dtype=np.float16,
                                                         shape=(len(parents["rows"]), *value.shape))
                arrays[k][i] = value
            if (i+1) % 28 == 0:
                print(i+1, round(time.monotonic()-start, 2), flush=True)
    for value in arrays.values():
        value.flush()
    stamp = {"driver": reference(__file__), "operator": reference(ROOT / "distant.py"),
             "source": feature_source, "sources": len(parents["rows"]), "wide_training": binding,
             "wide_checkpoint": recipe["checkpoint"], "parent": recipe["parent"],
             "tensors": {k: reference(cache / f"{k}.npy") for k in arrays},
             "preparation_seconds": time.monotonic()-start, "original_exact_features_reproduced": True,
             "legacy_delivery_check": "All three roles of the first eight sources."}
    write_json(ROOT / "features.json", stamp)


def train():
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    device = "cuda"
    total = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1., 5*2**30/total))
    binding = reference(ROOT / "features.json")
    stamp = read_json(checked(binding))
    source = read_json(checked(stamp["source"]))
    upstream = reference(ROOT.parent / "directional-gap-training-v1" / "training" / "completed.json")
    previous = read_json(checked(upstream))
    assert previous["features"] == stamp["source"]
    projection = read_json(checked(previous["directions"]))
    arrays = {k: np.load(checked(v), allow_pickle=False, mmap_mode="r")
              for k, v in source["tensors"].items() if k in ("target", "baseline", "void", "void_weight")}
    projected = {k: np.load(checked(v), allow_pickle=False, mmap_mode="r") for k, v in projection["tensors"].items()}
    new = {k: np.load(checked(v), allow_pickle=False, mmap_mode="r") for k, v in stamp["tensors"].items()}
    wide = read_json(checked(stamp["wide_training"]))
    networks = {key: Router(key).to(device) for key in ARMS}
    networks["distant"].load_state_dict(networks["near"].state_dict())
    ema = {key: deepcopy(model).requires_grad_(False) for key, model in networks.items()}
    opt = torch.optim.AdamW([p for model in networks.values() for p in model.parameters()], lr=.001, weight_decay=.001)
    count = stamp["sources"]
    updates = count // PHOTOS * EPOCHS
    weight = float(previous["gradient_match"]["weights"]["directional"])
    taper = torch.tensor(SYNTH**2, device=device, dtype=torch.float32)
    coordinates = tuple(torch.tensor(a, device=device) for a in (NATIVE_I, NATIVE_J))
    rng = np.random.default_rng(SEED)
    log = []
    start = time.monotonic()
    step = 0
    for epoch in range(EPOCHS):
        ids = rng.permutation(count)
        for offset in range(0, count, PHOTOS):
            selected = ids[offset:offset+PHOTOS]
            tile = choose_tiles(rng, arrays["void_weight"], selected)
            data = samples(arrays, projected, selected, tile, device)
            extra = batch(new, selected, tile, device)
            flat = torch.as_tensor(EXACT_FLAT[tile], device=device)
            step += 1
            lr = .001*step/24 if step <= 24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(updates-24)))
            opt.param_groups[0]["lr"] = float(lr)
            opt.zero_grad(set_to_none=True)
            seen = {}
            for label, model in networks.items():
                predicted = extra["wide"] + model(extra["evidence"], extra["extras"])
                main, error, aligned = objective(predicted, data["target"], data["baseline"], flat)
                guide = losses(error, data, taper, coordinates)[2]
                value = main + weight * guide
                value.backward()
                norm = torch.nn.utils.clip_grad_norm_(tuple(model.parameters()), 2.)
                assert torch.isfinite(norm)
                seen[label] = torch.stack((value, main, guide, aligned, norm)).detach()
            opt.step()
            with torch.no_grad():
                for label in ARMS:
                    torch._foreach_lerp_(tuple(ema[label].parameters()), tuple(networks[label].parameters()), .01)
            if step == 1 or step % 48 == 0 or step == updates:
                row = {"step": step, "values": {label: v.tolist() for label, v in seen.items()}}
                log.append(row)
                print(step, round(time.monotonic()-start, 2), row["values"], flush=True)
    assert step == updates
    torch.cuda.synchronize()
    seconds = time.monotonic()-start
    folder = ROOT / "training"
    folder.mkdir()
    checkpoint = folder / f"step{step:06d}.pt"
    with checkpoint.open("xb") as output:
        torch.save({"EMA": {k:v.state_dict() for k,v in ema.items()},
                    "raw": {k:v.state_dict() for k,v in networks.items()},
                    "optimizer": opt.state_dict(), "step": step, "seed": SEED}, output)
    write_json(folder / "completed.json", {
        "driver": reference(__file__), "parent": wide["parent"], "wide_training": stamp["wide_training"],
        "wide_checkpoint": wide["checkpoint"], "frozen_phase": wide["frozen_phase_checkpoint"],
        "checkpoint": reference(checkpoint), "features": binding, "direction_training": upstream,
        "seconds": seconds, "seed": SEED, "epochs": EPOCHS, "EMA": .99, "updates_per_arm": step,
        "photos": count, "visits": count*EPOCHS, "queries": 3*count*EPOCHS, "optimizer": previous["optimizer"],
        "directions_weight": weight, "progress": log, "arms": ARMS, "evidence": LABELS,
        "constant_gains_ema": [float(x) for x in ema["constant"].level.sigmoid()],
    })


if __name__ == "__main__":
    {"prepare": collect, "train": train}[sys.argv[1]]()
