"""Verify support isolation and measure warmed Bayer correction cost."""
import os
import time

import numpy as np
import torch

from distant import ROOT, NEAR_LABELS, observations
from demosaic.phase_witness import BASE, SIDE
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from mixture import PRIOR
from review_gate import setup, compose
from review_quiet import LOCAL, wire_inputs
from composed import render_models as fixed_phase
import evaluate_gap_head as review


def isolation():
    rng = np.random.default_rng(701606)
    profile = {"shot": .00128, "read": 6.5536e-6}
    layout = np.array((0, 1, 1, 2))
    coords_y, coords_x = np.indices((128, 128)) * 2
    signal = np.cos(2*np.pi*(.125*coords_x+.0625*coords_y))
    image = (.15+ .012*signal[None]+.006*rng.normal(size=(4, 128, 128))).astype(np.float32)
    shape = (SIDE**2, len(BASE))
    phase = np.ones(shape, dtype=np.complex64)
    seen = np.zeros((2, *shape), dtype=np.complex64)
    sigma = np.full((2, SIDE**2, 1), .007, dtype=np.float32)
    center = 8*SIDE+8
    def run(raw):
        bases, veto, variants = observations(raw, layout, profile, phase, seen, seen, sigma, controls=True)
        return bases[center], veto[center], {key: data[center] for key, data in variants.items()}
    base, veto, features = run(image)
    altered = image.copy()
    altered[:,32:48,64:80] += .025*signal[32:48,64:80]
    same, vote, distant = run(altered)
    np.testing.assert_array_equal(base, same)
    np.testing.assert_array_equal(veto, vote)
    np.testing.assert_array_equal(features["matching"][:, :len(NEAR_LABELS)], distant["matching"][:, :len(NEAR_LABELS)])
    far_delta = float(abs(distant["matching"]-features["matching"]).max())
    assert far_delta > .05
    swapped = float(abs(features["matching"]-features["rotated"]).max())
    assert swapped > .05
    return {"far_donor_pixels_changed": "packed rows 32:48, columns 64:80",
            "tested_station": center, "max_far_feature_change": far_delta,
            "max_rotated_feature_change": swapped,
            "near_measurements_and_proposal_bit_identical": True}


@torch.inference_mode()
def time_cpu(models):
    torch.set_num_threads(1)
    core = max(os.sched_getaffinity(0))
    os.sched_setaffinity(0,[core])
    data = read_json(checked(reference(PRIOR / "wire-parent.json")))
    plan = read_json(checked(data["plan"]))
    cases = read_json(checked(data["inputs"]))["rows"]
    case = next(r for r in cases if r["index"] == 12 and r["noise"] == "iso6400")
    sample, parent, proof = wire_inputs(case, {r["id"]:r for r in data["rows"]}, None)
    raw, layout, wb, matrix = (sample[k][0] for k in ("packed", "colors", "wb", "matrix"))
    box, noise = plan["query"], plan["profiles"]["iso6400"]
    donations = review.exterior(sample["full"], layout, noise, box)
    old_models = models[:3]
    a = lambda: fixed_phase(raw, layout, wb, matrix, noise, box, sample["full"], parent[LOCAL][0], old_models)
    b = lambda: compose(raw, layout, wb, matrix, noise, box, donations, parent[LOCAL][0], models, False)
    for key in ("ring8", "exterior-only", "exterior-phase-locked"):
        np.testing.assert_allclose(a()[key], b()[key], atol=1e-7, rtol=0)
    arms = {"fixed exterior": a, "learned gates": b}
    duration = {k:[] for k in arms}
    for i in range(14):
        for k in list(arms)[::1 if i%2 == 0 else -1]:
            start = time.perf_counter()
            arms[k]()
            duration[k].append(1000*(time.perf_counter()-start))
    return {"scope": "One CPU core, 14 interleaved warm runs from a retained 256-pixel parent. Both paths return multiple variants.",
            "CPU_affinity": [core], "input": case["input"], "parent_output": proof, "samples_ms": duration,
            "median_ms": {k:float(np.median(v)) for k,v in duration.items()}}


if __name__ == "__main__":
    models, receipt = setup()
    write_json(ROOT / "audit.json", receipt | {"driver": reference(__file__),
               "isolation": isolation(), "runtime": time_cpu(models)})
