"""Bind exact and standing boards, scoped metrics, checkpoint and executable sources."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results") / ROOT.name
IMAGES = Path("docs/images") / ROOT.name
UPSTREAM = ROOT.parent / "bayer-phase-quadrature-v1"

OBSERVED = {
    "exact": "Cathedral trim stays soft. Planted strong diagonals remain visible. The weak cross-family and the dip stay soft.",
    "standing": "The sky is smooth. Both coarse fence directions are coherent. Thin building wires and leaf detail stay soft. Both fine cab ROIs retain incomplete intersections and mottling. The transferred right diagonals remain visible.",
}


def publish_board(record, output, image_root):
    src = checked(record["image"])
    output.mkdir(parents=True, exist_ok=True)
    dest = output / src.name
    shutil.copyfile(src, dest)
    assert reference(dest)["sha256"] == record["image"]["sha256"]
    record["image"]["path"] = dest.relative_to(image_root).as_posix()
    crops = {}
    with Image.open(dest) as image:
        for panel in record["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert w == h == 160 and 0 <= x <= image.width-w and 0 <= y <= image.height-h
            crops[panel.get("label") or panel["name"]] = image.crop((x, y, x+w, y+h))
    assert len(crops) == len(record["panels"])
    return crops


def copy_and_check_images(receipt):
    results = {}
    for scope, count in (("exact", 3), ("standing", 8)):
        raw = read_json(ROOT / scope / "manifest.json")
        assert raw["training"] == receipt and len(raw["rows"]) == count
        checked(raw["driver"])
        for row in raw["rows"]:
            source = publish_board(row["board"], IMAGES / scope, IMAGES)
            if scope == "exact":
                for triplet in (row["triplet"], *row["other_triplets"].values()):
                    parts = publish_board(triplet, IMAGES / scope, IMAGES)
                    assert len(parts) == 3
                    assert all(ImageChops.difference(source[key], value).getbbox() is None for key,value in parts.items())
        results[scope] = raw | {"observations_at_native_scale": OBSERVED[scope], "review_completed": True}
    dest = IMAGES / "manifest.json"
    write_json(dest, results)
    return {"path": f"../../images/{ROOT.name}/manifest.json", "sha256": reference(dest)["sha256"]}


def main():
    OUT.mkdir(exist_ok=True)
    completed = reference(ROOT / "training" / "completed.json")
    training = read_json(checked(completed))
    features = read_json(checked(training["features"]))
    for key in ("driver", "features", "parent", "wide_checkpoint", "wide_training", "frozen_phase", "direction_training"):
        checked(training[key])
    for key in ("driver", "operator", "source"):
        checked(features[key])
    archived = {
        p: ROOT / p for p in ("distant.py", "train.py", "review_gate.py", "render_gate.py", "audit.py", "publish.py",
          "native_view.py", "features.json", "prepare.log", "train.log", "tests-final.log", "tests.log",
          "exact/manifest.json", "exact.log", "standing/manifest.json", "standing.log", "audit.json", "audit.log",
          "photo-holdout.json", "photo.log", "wire-holdout.json", "wire.log", "training/completed.json",
          "training/step000672.pt", "direct-contrasts.json", "direct_contrasts.py")
    }
    archived.update({f"upstream/{p}": UPSTREAM / p for p in ("quadrature.py", "exterior.py", "composed.py")})
    summaries = {}
    for panel, count in (("photo",96), ("wire",48)):
        raw = read_json(ROOT / (panel+"-holdout.json"))
        assert raw["training"] == completed and raw["checkpoint"] == training["checkpoint"]
        assert len(raw["rows"]) == count
        checked(raw["driver"])
        checked(raw["prior_inputs_and_scores"])
        for row in (*raw["rows"], *raw["calibration"]):
            checked(row["input"])
            checked(row["parent_output"])
        selected = raw["reports"]["iso6400"]
        summaries[panel] = {"calibration_scales": raw["scales"],
                            "overview": {key: selected["overview"][key] for key in ("ring8","near","distant","exterior-only")},
                            "contrasts": {key: selected["contrasts"][key] for key in (
                                "distant-ring8","distant-near","distant-near-matched","distant-exterior-only-matched",
                                "distant-distant-rotated","distant-distant-shifted","distant-V120","distant-100k")}}
    audit = read_json(ROOT / "audit.json")
    checked(audit["driver"])
    assert audit["training"] == completed
    views = copy_and_check_images(completed)
    path = OUT / "evidence.tar.xz"
    with tarfile.open(path, "x:xz", preset=4) as archive:
        for name,file in sorted(archived.items()):
            archive.add(file, arcname=name, recursive=False)
    with tarfile.open(path) as archive:
        assert archive.getnames() == sorted(archived)
        for name, file in archived.items():
            with archive.extractfile(name) as stream:
                assert stream.read() == file.read_bytes()
    write_json(OUT / "publication.json", {
        "archive": {"path": path.name, "sha256": reference(path)["sha256"], "entries": len(archived)},
        "checkpoint": training["checkpoint"], "parent": training["parent"], "frozen_wide": training["wide_checkpoint"],
        "training": completed, "training_completed": True, "numerical_review_completed": True,
        "native_image_reviews_completed": True, "native_review": views, "runtime": audit["runtime"],
        "iso6400": summaries, "unscaled_fixed_phase_comparison": read_json(ROOT / "direct-contrasts.json"),
        "scope": "Scoped Bayer phase component with exact wires and natural interventions, plus both standing scenes.",
        "fixed427_and_camera_panels": None,
    })


if __name__ == "__main__":
    main()
