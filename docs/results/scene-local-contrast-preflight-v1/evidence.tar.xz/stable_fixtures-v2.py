"""Check the training reader and constant-preserving filter on actual bound source crops."""

import os
from pathlib import Path
from statistics import mean

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_training_data import ScenePhotoDataset,_attenuate_local_contrast
from preflight import LUMA,attenuate_local,energies,ref_view

ROOT=Path(__file__).resolve().parent


def check_pixels(result):
    rows=[]
    for crop in result["rows"]:
        if not crop["qualified"]:
            continue
        source=checked(crop["input"])
        image=torch.from_numpy(np.load(source,allow_pickle=False).astype(np.float32)).permute(2,0,1)/65535.
        h,w=crop["scene_shape"]
        clean=image[:,:h,:w].contiguous()
        x,y,*_=crop["crop_xywh"]
        scale=crop["scale"]
        updated=_attenuate_local_contrast(clean,crop["crop_xywh"],scale)
        older,mask=attenuate_local(clean,x,y,scale)
        # Float64 validation bounds the legitimate difference from a numerically
        # stable DC center. Outside the support the original bytes stay exact.
        max_change=float((updated-older).abs().max())
        exact=_attenuate_local_contrast(clean.double(),crop["crop_xywh"],scale)
        error=float((updated.double()-exact).abs().max())
        assert error<2e-7 and torch.equal(updated[:,~mask],clean[:,~mask])
        final=energies((ref_view(updated,x,y)*LUMA).sum(0)[64:192,64:192])
        ratios={k:final[k]/crop["energy"]["unmodified"][k] for k in ("low","fine")}
        rows.append({"source":crop["source"],"prototype_delta_max":max_change,"stable_FP64_error_max":error,
                     "final_relative_band_RMS":ratios})
    assert len(rows)==45
    return rows


def actual_reader(plan):
    manifest=checked(plan["train_manifest"])
    order=plan["photo_epoch_order"]
    options={"seed":plan["data_seed"],"patch_size":plan["patch_size"],
        "crops_per_scene":plan["crops_per_scene"],"photo_epoch_order":checked(order),
        "photo_epoch_order_sha256":order["sha256"]}
    ordinary=ScenePhotoDataset(manifest,**options)
    locally_faint=ScenePhotoDataset(manifest,**options,local_contrast_fraction=1.)
    rows=[]
    for index in range(8):
        first,second=ordinary[index],locally_faint[index]
        assert all(first.metadata[k]==second.metadata[k]for k in ("source_id","recipe","boxes_xywh",
                                                                  "D4_quarter_turns","mirror_x"))
        box=second.metadata["local_contrast"]["box_xywh"]
        x,y,w,h=box
        beginx,endx=x+56,x+200
        beginy,endy=y+56,y+200
        prior=first.observation.sensor_target
        inside=second.observation.sensor_target
        away=torch.ones(prior.shape[-2:],dtype=torch.bool)
        away[beginy:endy,beginx:endx]=False
        assert torch.equal(prior[:,away],inside[:,away])
        actual=second.observation.crops(second.metadata["boxes_xywh"])
        for k in second.crops:
            assert torch.equal(second.crops[k],actual[k])
        rows.append({"draw":index,"source":second.metadata["source_id"],"recipe":second.metadata["recipe"],
                     "box":box,"scale":second.metadata["local_contrast"]["scale"],
                     "identical_outside_clean_sites":int(away.sum()),
                     "max_changed_clean_camera_value":float((prior-inside).abs().max()),
                     "source_and_recipe_identical":True,"crops_reproduce_own_RAW":True,
                     "input_fingerprints":second.metadata["crop_fingerprints"]})
    assert all(row["max_changed_clean_camera_value"]>0 for row in rows)
    return rows


if __name__=="__main__":
    os.sched_setaffinity(0,[19]);os.nice(10);torch.set_num_threads(1)
    origin=reference(ROOT/"result.json")
    results=read_json(checked(origin))
    actual=reference(ROOT/"actual-trainer-stable"/"plan.json")
    prototype=check_pixels(results)
    readers=actual_reader(read_json(checked(actual)))
    write_json(ROOT/"stable-fixtures.json",{"source":reference(__file__),"earlier":origin,"reader_plan":actual,
        "actual_reader":readers,"verified_targets":prototype,
        "low_and_fine_retained_fraction":{band:mean(r["final_relative_band_RMS"][band] for r in prototype)
                                         for band in ("low","fine")}})
    print("45 measured crops and 8 actual reader draws verified",flush=True)
