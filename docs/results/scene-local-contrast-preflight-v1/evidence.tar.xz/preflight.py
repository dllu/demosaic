"""Prepare faint native texture beside an unchanged wider photographic scene."""

from dataclasses import asdict,replace
import hashlib
import os
import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image,ImageDraw
from torch.nn import functional as F

from demosaic.data import attenuate_photographic_contrast
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe
from diagnose_local_material_detail import fft_dct

ROOT=Path(__file__).resolve().parent
EXP=ROOT.parent
LUMA=torch.tensor([.2126,.7152,.0722])[:,None,None]
PROFILES=(("iso400",8e-5,2.56e-8),("iso6400",.00128,6.5536e-6))
GRID=np.hypot(np.arange(16)[:,None]/32,np.arange(16)[None,:]/32)
FINE=(GRID>=1/8)&(GRID<1/3)
LOW=(GRID>=1/32)&(GRID<1/8)


def attenuate_local(rgb,x,y,factor):
    region=rgb[:,y-4:y+260,x-4:x+260]
    assert region.shape==(3,264,264)
    low=F.avg_pool2d(region,9,stride=1)
    crop=rgb[:,y:y+256,x:x+256]
    grid=torch.arange(256,dtype=rgb.dtype)
    ramp=((72-abs(grid-127.5))/20).clamp(0,1)
    ramp=ramp*ramp*(3-2*ramp)
    support=ramp[:,None]*ramp[None,:]
    result=rgb.clone()
    changed=torch.where(support>0,crop+(1-factor)*support*(low-crop),crop)
    result[:,y:y+256,x:x+256]=changed
    mask=torch.zeros(rgb.shape[-2:],dtype=torch.bool)
    mask[y:y+256,x:x+256]=support>0
    return result,mask


def energies(crop):
    a=np.asarray(crop,dtype=float)
    cells=a.reshape(8,16,8,16).swapaxes(1,2).reshape(64,16,16)
    coeff=fft_dct(fft_dct(cells,-1),-2)
    values={}
    for name,mask in (("fine",FINE),("low",LOW)):
        values[name]=float(np.sqrt(np.mean(np.sum(coeff[...,mask]**2,-1))/256))
    values["average"]=float(a.mean())
    return values


def render(values,dest,name):
    panel=Image.new("RGB",(4*168+8,192),"#eeeeee")
    draw=ImageDraw.Draw(panel)
    for j,(label,v) in enumerate(values):
        rgb=v.detach().numpy()[...,48:208,48:208].transpose(1,2,0).clip(0,1)
        srgb=np.where(rgb<=.0031308,12.92*rgb,1.055*np.power(rgb,1/2.4)-.055)
        cell=np.rint(srgb*255).astype(np.uint8)
        x=8+168*j
        panel.paste(Image.fromarray(cell),(x,24))
        draw.text((x,5),label,fill="black")
        np.testing.assert_array_equal(np.asarray(panel)[24:184,x:x+160],cell)
    file=dest/f"{name}.png"
    panel.save(file)
    return reference(file)


def ref_view(rgb,x,y):
    return rgb[:,y:y+256,x:x+256]


def probe(row,manifest,case,sensor):
    cache=(manifest.parent/row["cache"]).resolve()
    assert cache.is_relative_to(Path("/mnt/external")) and row["split"]=="train"
    assert reference(cache)["sha256"]==row["cache_sha256"]
    with cache.open("rb") as stream:
        used=np.load(stream,allow_pickle=False)
    assert used.dtype==np.uint16 and list(used.shape)==row["shape"]
    image=torch.from_numpy(used.astype(np.float32)).permute(2,0,1)/65535.
    h,w=image.shape[-2:]
    image=image[:,:h//2*2,:w//2*2].contiguous()
    h,w=image.shape[-2:]
    rng=random.Random(int(hashlib.sha256(row["id"].encode()).hexdigest()[:14],16))
    at_y,at_x=(rng.randrange(4,(n-260)//2)*2 for n in (h,w))
    original=ref_view(image,at_x,at_y)
    no=energies((original*LUMA).sum(0)[64:192,64:192])
    if no["fine"]/max(no["average"],1e-8)<.007 or no["average"]<.035:
        return {"source":row["id"],"qualified":False,"input":reference(cache),"initial":no}
    before=RandomFreeze(rng.uniform(-3,-1))
    factor=2**before.value
    statewide=attenuate_photographic_contrast(original,before)
    local,mask=attenuate_local(image,at_x,at_y,factor)
    after=ref_view(local,at_x,at_y)
    assert torch.equal(image[:,~mask],local[:,~mask])
    assert float(local.min())>=float(image.min())-1e-7 and float(local.max())<=float(image.max())+1e-7
    result={"source":row["id"],"qualified":True,"input":reference(cache),"source_metadata":row,
            "crop_xywh":[at_x,at_y,256,256],"scene_shape":[h,w],"scale":factor,
            "support_fraction":float(mask.float().mean()),
            "energy":{"unmodified":no,"whole_crop":energies((statewide*LUMA).sum(0)[64:192,64:192]),
                      "localized":energies((after*LUMA).sum(0)[64:192,64:192])}}
    if sensor:
        name,shot,read=PROFILES[case%2]
        base=sample_scene_recipe(rng.randrange(2**62))
        profile=replace(base,exposure=.5,shot=shot,read=read,black=.03)
        before_raw=observe_scene(image,profile)
        after_raw=observe_scene(local,replace(profile,noise_seed=profile.noise_seed+1))
        phase_cover=mask[None,None].reshape(1,1,h//2,2,w//2,2).permute(0,1,3,5,2,4).reshape(4,h//2,w//2)
        packed=torch.where(phase_cover,after_raw.packed,before_raw.packed)
        variance=torch.where(phase_cover,after_raw.variance,before_raw.variance)
        shared=replace(after_raw,packed=packed,variance=variance)
        assert torch.equal(shared.packed[~phase_cover],before_raw.packed[~phase_cover])
        assert torch.equal(shared.variance[~phase_cover],before_raw.variance[~phase_cover])
        assert torch.equal(shared.sensor_target[:,~mask],before_raw.sensor_target[:,~mask])
        original_crop=before_raw.crops([(at_x,at_y,256,256)])
        candidate_crop=shared.crops([(at_x,at_y,256,256)])
        for field in ("colors","wb","matrix","shot","read"):
            assert torch.equal(original_crop[field],candidate_crop[field])
        result["physical_pair"]={"recipe":asdict(profile),"changed_seed":after_raw.recipe.noise_seed,"noise":name,
            "outside_sensor_pixels_bit_identical":int((~phase_cover).sum()),"raw_same_outside":True,
            "original":{"packed":fingerprint(before_raw.packed),"sensor_target":fingerprint(before_raw.sensor_target)},
            "localized":{"packed":fingerprint(shared.packed),"sensor_target":fingerprint(shared.sensor_target)}}
    dest=ROOT/"native"
    if sensor:
        spread=torch.zeros_like(after)
        spread[:,mask[at_y:at_y+256,at_x:at_x+256]]=.35
        result["board"]=render([("Original target",original),("Whole-crop contrast",statewide),
                                ("Localized fine contrast",after),("Changed-pixel support",spread)],dest,row["id"])
    return result


class RandomFreeze:
    def __init__(self,value):
        self.value=value

    def uniform(self,minimum,maximum):
        assert (minimum,maximum)==(-3,-1)
        return self.value


def main():
    os.sched_setaffinity(0,[19]);os.nice(12);torch.set_num_threads(1)
    expansion=reference(EXP/"expanded-scene-12000-v2"/"plan.json")
    training=read_json(checked(expansion))["train_manifest"]
    manifest=checked(training)
    import json
    with manifest.open() as f:
        rows=[json.loads(line)for line in f]
    held=read_json(EXP/"full427-faint-adc-v1"/"cohort.json")["source_ids"]
    assert not (set(held)&{r["id"]for r in rows})
    selected=sorted((r for r in rows if min(r["shape"][:2])>=384 and max(r["shape"][:2])<=1100),
                    key=lambda r:hashlib.sha256(("local-faint-v1"+r["id"]).encode()).digest())[:48]
    assert len(selected)==48 and all(row["split"]=="train" and row["bin_factor"]==4 for row in selected)
    recipe=ROOT/"plan.json"
    write_json(recipe,{"source":reference(__file__),"train_manifest":training,"previous_12k":expansion,
        "source_ids":[r["id"]for r in selected],"held_out_overlap":[],"sensor_noise":PROFILES,
        "scope":"Read-only training-data preflight. Fixed train-only bin4 sources. The first two qualifying sources get paired full-scene RAW and native target boards. No optimizer/learned inference."})
    (ROOT/"native").mkdir()
    results=[]
    sensor_count=0
    for row in selected:
        result=probe(row,manifest,sensor_count,sensor_count<2)
        results.append(result)
        sensor_count+=int("physical_pair"in result)
    assert sensor_count==2
    write_json(ROOT/"result.json",{"plan":reference(recipe),"rows":results})
    print(sum(r["qualified"]for r in results),"qualified out of",len(results),"paired renders",sensor_count,flush=True)


if __name__=="__main__":
    main()
