"""Bind the training-only target comparisons and both CUDA preflight receipts."""

import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
DEST=REPO/"docs/results/scene-local-contrast-preflight-v1"
IMAGES=REPO/"docs/images/scene-local-contrast-preflight-v1"


def rel(path):
    return {"path":path.relative_to(REPO).as_posix(),"sha256":reference(path)["sha256"]}


def main():
    witnesses=read_json(ROOT/"result.json")["rows"]
    stable=read_json(ROOT/"stable-fixtures.json")
    assert sum(row["qualified"]for row in witnesses)==45
    assert len(stable["actual_reader"])==8 and len(stable["verified_targets"])==45
    maximum=max(row["stable_FP64_error_max"]for row in stable["verified_targets"])*65535
    assert maximum<.06
    images=[]
    DEST.mkdir()
    IMAGES.mkdir()
    for row in witnesses:
        if "board" not in row:
            continue
        old=checked(row["board"])
        new=IMAGES/old.name
        shutil.copyfile(old,new)
        assert rel(new)["sha256"]==row["board"]["sha256"]
        with Image.open(new)as image:
            assert image.size==(680,192)
        images.append({"source":row["source"],"image":rel(new),"crop_xywh":row["crop_xywh"],
             "panels":[[8+i*168,24,160,160]for i in range(4)],
             "observation":"Native target and matched local and uniform contrast were viewed. "
             "The localized change softens real texture inside its visible transition."})
    assert len(images)==2
    copies=("result.json","stable-fixtures.json")
    files={p.name:p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py",".json",".log")}
    checks=[]
    for name in ("actual-trainer","actual-trainer-stable"):
        base=ROOT/name
        run=read_json(base/"outputs/result.json")
        assert run["all_modes_passed"]
        a,b=run["results"]
        assert [a["mode"],b["mode"]]==["none","spatial"]
        assert a["training_observations"]==b["training_observations"]
        assert all(r["discarded_updates"]==2 and r["DINO_unchanged"]for r in (a,b))
        for item in (a,b):
            checked(item["roundtrip_checkpoint"])
        for relative in ("plan.json","check.log","launch.json","outputs/result.json",
                         "work/src/demosaic/scene_training_data.py","work/scripts/train_scene_context.py"):
            files[f"{name}/{relative}"]=base/relative
        checks.append(reference(base/"outputs/result.json"))
    final=DEST/"cuda-preflight.json"
    shutil.copyfile(checked(checks[-1]),final)
    for name in copies:
        shutil.copyfile(ROOT/name,DEST/name)
    archive=DEST/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=4)as out:
        for name,path in sorted(files.items()):
            out.add(path,arcname=name)
    contents={name:reference(path)["sha256"] for name,path in files.items()}
    with tarfile.open(archive)as out:
        for name,digest in contents.items():
            assert hashlib.sha256(out.extractfile(name).read()).hexdigest()==digest
    write_json(DEST/"publication.json",{"source_crop_reports":[rel(DEST/n)for n in copies],
          "archive":rel(archive),"archived_sha256":contents,"actual_native_viewing":True,
          "native":images,"trainer_preflight":rel(final),"archived_trainer_checks":checks,
          "maximum_FP32_vs_FP64_full_scale_DN16":maximum,
          "scope":"Training-only crop intervention and discarded CUDA checks. No production checkpoints or restoration quality scores."})


if __name__=="__main__":
    main()
