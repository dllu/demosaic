"""Exercise the actual whole-scene trainer with the new data option enabled."""

from pathlib import Path
import os
import subprocess
import sys

from demosaic.experiments.artifacts import checked,freeze_sources,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
previous=reference(ROOT.parent/"expanded-scene-12000-v2"/"plan.json")
root=ROOT/"actual-trainer"
root.mkdir()
work,frozen=freeze_sources(REPO,root,["train_scene_context.py"])
plan=read_json(checked(previous))
plan.update(root=str(root),work=str(work),frozen_files=frozen,training_script=reference(work/"scripts/train_scene_context.py"),
            maximum_GPU_GiB=8,local_contrast_fraction=1.0,
            scope="Discarded native CUDA preflight for the actual localized scene contrast reader, "
                  "one matched control and contextual architecture, two optimizer smoke updates each.")
plan["inputs"]=[plan["parent"],plan["train_manifest"],plan["development_manifest"],
                plan["photo_epoch_order"],previous]
path=root/"plan.json"
write_json(path,plan)
command=["taskset","-c","18,19",sys.executable,str(checked(plan["training_script"])),
         "preflight",str(path),str(root/"outputs")]
env=os.environ|{"PYTHONPATH":f"{work/'src'}:{work/'scripts'}","OPENBLAS_NUM_THREADS":"1",
                "OMP_NUM_THREADS":"1"}
with (root/"check.log").open("x")as log:
    proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
write_json(root/"launch.json",{"driver":reference(__file__),"pid":proc.pid,"command":command,"plan":reference(path)})
print(proc.pid,flush=True)
