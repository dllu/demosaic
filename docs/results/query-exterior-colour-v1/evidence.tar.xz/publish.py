"""Publish checked evidence, source and native crops without copying RAW files."""
from pathlib import Path
import shutil
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
NAME = ROOT.name
OUT = Path('docs/results')/NAME
IMAGES = Path('docs/images')/NAME

def main():
    OUT.mkdir()
    IMAGES.mkdir()
    complete = {}
    for group in ('native','standing'):
        source = reference(ROOT/group/'manifest.json')
        original = read_json(checked(source))
        target = IMAGES/('exact' if group=='native' else group)
        target.mkdir()
        for row in original['rows']:
            for item in (row['boards'] if group=='native' else [row]):
                image = checked(item['image'])
                path = shutil.copy2(image, target/image.name)
                published = reference(path)
                assert published['sha256'] == item['image']['sha256']
                item['image'] = {**published,'path':str(Path(path))}
        complete[group] = original
    write_json(IMAGES/'manifest.json',complete)
    items = ('prepare.py','plan.json','captures.json','parent.py','parents.json','routing-run.py','results.json',
             'run_gap.py','fresh-gap.json','measure.py','measure.json','fallback.py','compare.py','fresh-comparison.json',
             'replay-comparison.json','audit.py','audit.json','native.py','native/manifest.json',
             'standing.py','standing/manifest.json','publish.py')
    archive = OUT/'evidence.tar.xz'
    files = {}
    with tarfile.open(archive,'x:xz') as tar:
        for relative in items:
            path = ROOT/relative
            files[relative] = reference(path)['sha256']
            tar.add(path,arcname=relative)
        upstream = ROOT.parent/'query-signed-colour-v1'/'colour.py'
        files['preceding/colour.py'] = reference(upstream)['sha256']
        tar.add(upstream,arcname='preceding/colour.py')
    fresh = read_json(ROOT/'fresh-comparison.json')
    replay = read_json(ROOT/'replay-comparison.json')
    write_json(OUT/'publication.json',{'checkpoint':fresh['checkpoint'],'scope':'Fixed-weight analytic CRGB fallback',
               'fresh_summary':fresh['summary'],'replay_summary':replay['summary'],'native_manifest':reference(IMAGES/'manifest.json'),
               'archive':reference(archive),'member_sha256':files,
               'actual_views':{'exact_triplets_and_comparisons':2,'GFX_native_boards':8}})

if __name__=='__main__':
    main()
