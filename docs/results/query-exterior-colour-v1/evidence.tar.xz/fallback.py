"""Offer a colour-only fallback when exterior geometry survives a green-only veto."""
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'query-signed-colour-v1'
sys.path.insert(0, str(PREVIOUS))
from colour import LUMA, X, Y, anchored, basis, fit, local, phases, valid_terms

REJECTED = ('query-fundamentals-rejected', 'overlap-rejected')
SIGMA = 19.
LOCAL_Z = 1.25


def candidate(raw, cfa, noise, wb, matrix, route):
    if route.get('state') not in REJECTED or route.get('exterior') is None:
        return None
    planar = [[*xy, 0.] for xy in route['exterior']]
    return fit(raw, cfa, noise, wb, matrix, {'geometry': planar})


def location(raw, cfa, noise, evidence, carrier, orders):
    """Verify a local signed contrast on separate Bayer sites before applying it."""
    with anchored((0, 0)):
        groups = local.partition()
    discover = groups < 2
    q0 = groups == 0
    density = gaussian_filter(q0.astype(float), 3.)
    contrast = np.asarray(evidence['colour_direction']) @ np.asarray(evidence['contrast_projection'])
    # For a normalized separable Gaussian, its squared kernel is proportional
    # to a Gaussian at sigma/sqrt(2). Compute the discrete normalization.
    grid = np.arange(-round(4 * SIGMA), round(4 * SIGMA) + 1)
    weights = np.exp(-0.5 * (grid / SIGMA)**2)
    weights /= weights.sum()
    squared_mass = np.sum(weights**2)**2
    signed = np.zeros((2, 256, 256))
    variance = np.zeros_like(signed)
    for color in range(3):
        layouts = [(slice(p//2, None, 2), slice(p%2, None, 2)) for p in np.flatnonzero(cfa == color)]
        planes = np.flatnonzero(cfa == color)
        x, y, z, v, tone, keep = [], [], [], [], [], []
        for p, index in zip(planes, layouts, strict=True):
            observation = raw[p].astype(float)
            guide = gaussian_filter(np.where(q0, observation, 0.), 3.) / density
            x.append(X[index].ravel())
            y.append(Y[index].ravel())
            z.append(observation.ravel())
            v.append((noise['shot'] * guide.clip(min=0) + noise['read']).clip(2e-11).ravel())
            tone.append(np.full(observation.size, p))
            keep.append(discover.ravel())
        x, y, z, v, tone, keep = (np.concatenate(a) for a in (x, y, z, v, tone, keep))
        design, start = basis(x, y, tone, evidence['edge'], evidence['frequency'], orders)
        keep &= (np.maximum(abs(x), abs(y)) <= 102)
        weight = np.exp(-0.5*(x[keep]**2+y[keep]**2)/90**2)/v[keep]
        lhs = (design[keep].T * weight) @ design[keep]
        rhs = (design[keep].T * weight) @ z[keep]
        coefficients = np.linalg.pinv(lhs, rcond=1e-9, hermitian=True) @ rhs
        direction = evidence['direction']
        coefficients[[start+direction, start+len(orders)+direction]] = 0
        residuals = (z - design @ coefficients).reshape(len(planes), 128, 128)
        v = v.reshape(len(planes), 128, 128)
        for fold, selected in enumerate((discover, ~discover)):
            numerator, power = (np.zeros_like(X) for _ in range(2))
            for slot, index in enumerate(layouts):
                g = carrier[index]
                use = selected & (np.maximum(abs(X[index]), abs(Y[index])) <= 112)
                w = np.where(use, 1 / v[slot], 0)
                numerator[index] = w * g * residuals[slot]
                power[index] = w * g**2
            norm = gaussian_filter(power, SIGMA, mode='constant').clip(min=1e-15)
            signed[fold] += contrast[color] * gaussian_filter(numerator, SIGMA, mode='constant') / norm
            noise_energy = gaussian_filter(power, SIGMA/np.sqrt(2), mode='constant') * squared_mass
            variance[fold] += (contrast[color] / norm)**2 * noise_energy
    floor = np.sqrt(variance) * LOCAL_Z
    local_amp = np.maximum(np.min(signed - floor, axis=0), 0.)
    discover_amp = max(evidence['discovery'], 1e-12)
    # Limit leverage toward the boundary where Gaussian mass falls away.
    taper = np.clip((112 - np.maximum(abs(X), abs(Y))) / 20, 0., 1.)
    return np.clip(local_amp / discover_amp, 0., 1.) * taper


def render(raw, cfa, noise, baseline, wb, matrix, evidence):
    if evidence is None or not evidence['admit']:
        return baseline, None
    j = evidence['direction']
    orders = [(1, 0), (0, 1), *[term for _, term, _ in valid_terms(evidence['frequency'])]]
    angle = phases(X.ravel(), Y.ravel(), evidence['frequency'])[:,j].reshape(X.shape)
    phase = np.asarray(evidence['phase'])
    carrier = phase[0] * np.cos(angle) + phase[1] * np.sin(angle)
    coverage = location(raw, cfa, noise, evidence, carrier, orders)
    if not np.any(coverage):
        return baseline, coverage
    x, y = X.ravel(), Y.ravel()
    controls, start = basis(x, y, np.zeros_like(x), evidence['edge'], evidence['frequency'], orders)
    w = coverage.ravel() * np.exp(-0.5*(x*x+y*y)/70**2)
    projection = np.asarray(evidence['contrast_projection'])
    direction = np.asarray(evidence['colour_direction'])
    signal = direction @ projection @ baseline.reshape(3, -1)
    beta = np.linalg.pinv((controls.T*w)@controls, rcond=1e-9, hermitian=True) @ ((controls.T*w)@signal)
    prior = float(phase @ beta[[start+j, start+len(orders)+j]])
    target = min(1.25 * evidence['discovery'], evidence['held_amplitude'])
    green = abs(np.median(np.asarray(evidence['fitted_amplitudes'])[:,1]))
    amount = 0.65 * np.clip(target - prior, 0, 1.25 * green)
    luma = (LUMA @ matrix) * wb
    neutral_luma = np.linalg.solve(np.vstack((projection, luma)), np.array([*direction, 0.]))
    correction = neutral_luma[:,None,None] * (amount * coverage * carrier)[None]
    np.testing.assert_allclose(luma @ correction.reshape(3, -1), 0, atol=4e-9, rtol=0)
    return baseline + correction.astype(baseline.dtype), coverage
