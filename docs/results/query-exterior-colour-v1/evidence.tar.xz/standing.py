"""Run the exterior-frequency policy on the eight cached GFX native queries."""
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
import fallback
from compare import rms, transform

sys.path.insert(0,str(fallback.ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    source = reference(fallback.PREVIOUS/'standing/manifest.json')
    prior = reference(fallback.ROOT.parent/'query-donor-composition-v1/standing/manifest.json')
    previous = read_json(checked(source))
    decisions = {r['id']:r for r in read_json(checked(prior))['rows']}
    out = fallback.ROOT/'standing'
    out.mkdir()
    rows = []
    for row in previous['rows']:
        key = row['id']
        decision = decisions[key]
        assert all(decision[k]==row[k] for k in ('base_input','box','ROI','noise','display_exposure'))
        x,y,w,h = row['box']
        lx,ly,rw,rh = row['ROI']
        roi = (lx-x,ly-y,rw,rh)
        core = np.s_[...,roi[1]:roi[1]+rh,roi[0]:roi[0]+rw]
        with np.load(checked(row['base_input']),allow_pickle=False) as f:
            raw = f['packed'][0,:,y//2:(y+h)//2,x//2:(x+w)//2]
            cfa,wb,matrix = (f[k][0] for k in ('colors','wb','matrix'))
        with np.load(checked(row['output']),allow_pickle=False) as f:
            confirmed = f['colour-confirmed']
        route = decision['state']
        chosen = fallback.candidate(raw,cfa,row['noise'],wb,matrix,
                                    {'state':route['state'],'exterior':route.get('prior')})
        restored, coverage = fallback.render(raw,cfa,row['noise'],confirmed,wb,matrix,chosen)
        values = {'wb':wb[None],'matrix':matrix[None]}
        c0,y0 = transform(confirmed[None],values)
        c1,y1 = transform(restored[None],values)
        with Image.open(checked(row['image'])) as f:
            raster = np.asarray(f.convert('RGB'))
        views = {p['name']:raster[b:b+d,a:a+c] for p in row['panels'] for a,b,c,d in (p['png_xywh'],)}
        labels = ('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Reserved Bayer colour')
        panels = [(k,views[k]) for k in labels if k in views]
        rgb = display_crop(torch.from_numpy(restored[None]),torch.from_numpy(wb[None]),torch.from_numpy(matrix[None]),
                           roi,exposure=row['display_exposure'])
        pixels = np.rint(rgb*255).astype(np.uint8)
        panels.append(('Exterior-frequency colour',pixels))
        panels.extend((k,views[k]) for k in ('ISO100 AHD reference','ISO100 camera JPEG') if k in views)
        board = native_png(out/(key+'.png'),panels)
        file = out/(key+'.npz')
        np.savez(file,confirmed=confirmed,restored=restored,coverage=np.zeros_like(fallback.X) if coverage is None else coverage)
        measured = {'camera_RGB_RMS_DN16':rms(restored[core].astype(float)-confirmed[core]),
                    'chroma_RMS_DN16':rms((c1-c0)[core]), 'max_linear_luma_change_DN16':float(abs(y1-y0).max())*65535,
                    'changed_native_display_pixels':int(np.any(pixels!=views['Reserved Bayer colour'],axis=2).sum())}
        rows.append({k:row[k] for k in ('id','ROI','box','noise','display_exposure','base_input')} | board |
                    {'route':route['state'],'gate':chosen,'output':reference(file),'preceding_image':row['image'],'measurements':measured})
        print(key,route['state'],chosen and chosen['admit'],measured,flush=True)
    write_json(out/'manifest.json',{'driver':reference(__file__),'previous':source,'routes':prior,
                                  'checkpoint':previous['checkpoint'],'rows':rows})


if __name__ == '__main__':
    main()
