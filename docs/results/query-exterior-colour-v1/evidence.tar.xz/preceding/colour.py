"""Confirm signed Bayer chroma along an already measured weak wire."""
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'query-shared-gap-v1'
sys.path.insert(0,str(PRIOR))
from check import interior, latent, phases, valid_terms
from witness import anchored, local

LUMA=np.array([.2126,.7152,.0722])
POLICIES=('colour-unchecked','colour-confirmed')
Q=np.arange(256)-127.5
Y,X=np.meshgrid(Q,Q,indexing='ij')


def geometry(raw,cfa,noise,state):
    data,_,edge=interior(raw,cfa,noise)
    model=latent(data,edge,state['geometry'])
    j=model['target']
    v=np.asarray(model['discovery_bands'][j],dtype=float)
    return edge,j,v/max(np.linalg.norm(v),1e-20)


def basis(x,y,planes,edge,geometry,orders):
    xs,ys=x/128,y/128
    poly=np.column_stack((np.ones_like(xs),xs,ys,xs*xs,xs*ys,ys*ys))
    if np.unique(planes).size>1:
        marker=planes==planes[0]
        poly=np.column_stack((poly,marker,marker*xs,marker*ys))
    if edge is not None:
        theta,distance,_=edge
        step=np.clip(.5+(x*np.cos(theta)+y*np.sin(theta)-distance)/5,0,1)
        poly=np.column_stack((poly,step,step*xs,step*ys))
    native=phases(x,y,geometry)
    wave=native@np.asarray(orders).T
    return np.column_stack((poly,np.cos(wave),np.sin(wave))), poly.shape[1]


def fits(raw,cfa,noise,edge,geometry,orders,direction,phase):
    with anchored((0,0)):
        fold=local.partition()
    safe=(fold==0)
    blur=gaussian_filter(safe.astype(float),3.)
    yy,xx=np.indices(fold.shape)
    means=[]
    variances=[]
    for color in range(3):
        sites=np.flatnonzero(cfa==color)
        coordinates=[]
        for i in sites:
            x,y=2*xx+i%2-127.5,2*yy+i//2-127.5
            patch=raw[i].astype(float)
            guide=gaussian_filter(np.where(safe,patch,0.),3.)/blur
            vv=(noise['shot']*np.maximum(guide,0)+noise['read']).clip(2e-11)
            coordinates.append((x,y,np.full(x.shape,i),fold,patch,vv))
        x,y,loc,p,z,var=(np.concatenate([r[n].ravel()for r in coordinates])for n in range(6))
        design,geometry_offset=basis(x,y,loc,edge,geometry,orders)
        axis=np.zeros(design.shape[1])
        axis[geometry_offset+direction]=phase[0]
        axis[geometry_offset+len(orders)+direction]=phase[1]
        radius=np.maximum(abs(x),abs(y))<=98
        taper=np.exp(-.5*(x*x+y*y)/83.**2)
        per_fold=[]
        noise_fold=[]
        for k in range(4):
            sample=radius&(p==k)
            b=design[sample]
            v=var[sample]
            w=taper[sample]/v
            omega=b.T*w
            cov=np.linalg.pinv(omega@b,rcond=1e-9,hermitian=True)
            contrast=axis@cov@omega
            per_fold.append(float(contrast@z[sample]))
            noise_fold.append(float((contrast**2)@v))
        means.append(per_fold)
        variances.append(noise_fold)
    return np.array(means).T,np.array(variances).T


def summarize(coeff,proxy,neutral):
    r,g,b=neutral/neutral[1]
    proj=np.array([[1.,-r,0.],[0.,-b,1.]])
    colour=coeff@proj.T
    variance=np.asarray([(proj*row)@proj.T for row in proxy])
    info=np.linalg.inv(variance)
    score=np.einsum('bij,bj->bi',info,colour)
    known=np.linalg.solve(info[:2].sum(0),score[:2].sum(0))
    length=np.linalg.norm(known)
    candidate=known/max(length,1e-20)
    slopes=score@candidate
    powers=candidate@info@candidate
    z=slopes/np.sqrt(powers.clip(1e-20))
    q01=float(slopes[:2].sum()/max(1e-20,powers[:2].sum())**.5)
    q23=float(slopes[2:].sum()/max(1e-20,powers[2:].sum())**.5)
    strength=float(slopes[2:].sum()/max(1e-20,powers[2:].sum()))
    return {'contrast_projection':proj,'colour_direction':candidate,'discovery':float(length),'held_amplitude':strength,
            'folds':z.tolist(),'discovery_pool':q01,'reserve_pool':q23,
            'admit':bool(q01>=2.5 and min(z[:2])>.45 and q23>=3.25 and min(z[2:])>.75)}


def fit(raw,cfa,noise,wb,matrix,state):
    if 'geometry' not in state:
        return None
    edge,j,phase=geometry(raw,cfa,noise,state)
    orders=[(1,0),(0,1),*[t for _,t,_ in valid_terms(state['geometry'])]]
    coeff,var=fits(raw,cfa,noise,edge,state['geometry'],orders,j,phase)
    neutral=np.linalg.solve(matrix,np.ones(3))/wb
    output=summarize(coeff,var,neutral)
    return {k:v.tolist() if isinstance(v,np.ndarray)else v for k,v in output.items()}|{
        'frequency':state['geometry'],'direction':int(j),'phase':phase.tolist(),'edge':edge,'fitted_amplitudes':coeff.tolist()}


def render(parent,before,wb,matrix,evidence,mode):
    if evidence is None or (mode=='colour-confirmed' and not evidence['admit']):
        return before
    j=evidence['direction']
    angle=phases(X.ravel(),Y.ravel(),evidence['frequency'])[:,j].reshape(X.shape)
    q=np.asarray(evidence['phase'])
    carrier=q[0]*np.cos(angle)+q[1]*np.sin(angle)
    phase=np.arctan2(q[1],q[0])
    demod=np.exp(1j*(angle-phase))
    drift=2*abs(gaussian_filter((before[1]-parent[1]).astype(float)*demod.conj(),10.,mode='constant',truncate=3))
    coverage=np.clip(drift/max(np.quantile(drift[64:192,64:192],.72),1e-20),0,1)
    probe=np.exp(-.5*(X*X+Y*Y)/70**2) * coverage
    proj=np.asarray(evidence['contrast_projection'])
    direction=np.asarray(evidence['colour_direction'])
    rows=(proj@before.reshape(3,-1)).reshape(2,256,256)
    x,y=X.ravel(),Y.ravel()
    orders=[(1,0),(0,1),*[t for _,t,_ in valid_terms(evidence['frequency'])]]
    controls,start=basis(x,y,np.zeros_like(x),evidence['edge'],evidence['frequency'],orders)
    w=probe.ravel()
    b=(controls.T*w)@controls
    observed=np.linalg.pinv(b,rcond=1e-9,hermitian=True)@((controls.T*w)@rows.reshape(2,-1).T)
    axis=q@observed[[start+j,start+len(orders)+j]]
    along=float(direction@axis)
    green=abs(np.median(np.asarray(evidence['fitted_amplitudes'])[:,1]))
    target=evidence['discovery'] if mode=='colour-unchecked' else max(0.,min(1.25*evidence['discovery'],evidence['held_amplitude']))
    amplitude=np.clip(target-along,-1.25*green,1.25*green)*.65
    if amplitude==0.:
        return before
    luma=(LUMA@matrix)*wb
    zero_luma=np.linalg.solve(np.vstack((proj,luma)),np.array([*direction,0.]))
    update=zero_luma[:,None,None]*(amplitude*coverage*carrier)[None]
    np.testing.assert_allclose(luma@update.reshape(3,-1),0,atol=4e-9,rtol=0)
    return before+update.astype(before.dtype)
