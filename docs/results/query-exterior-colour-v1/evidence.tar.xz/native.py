"""Render native synthetic triplets at a common transform and maintain source bindings."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from fallback import ROOT

PIX = np.s_[...,48:208,48:208]


def panel(label, key, noise, destination):
    binding = reference(ROOT/f'{label}-comparison.json')
    score = read_json(checked(binding))
    plan = read_json(checked(score['cohort']))
    row = next(q for q in score['rows'] if q['noise']==noise and q['index']==key)
    photo = plan['sources'][key]
    with np.load(checked(row['input']),allow_pickle=False) as data:
        raw = data['packed'][...,64:192,64:192].copy()
        noisy = malvar(torch.from_numpy(raw),torch.from_numpy(data['colors'])).numpy()
        truth = data['target'][...,128:384,128:384]
        cal = {k:data[k] for k in ('wb','matrix')}
    with np.load(checked(row['output']),allow_pickle=False) as values:
        images = {k:values[k] for k in ('parent','confirmed','exterior')}
    native = {k:np.rint(display(v[PIX],cal,exposure=2).transpose(0,2,3,1)*255).astype(np.uint8)
              for k,v in (images|{'noisy':noisy,'GT':truth}).items()}
    boards = []
    for name, role, order in (
        ('triplet',0,('noisy','exterior','GT')),
        ('comparison',0,('noisy','parent','confirmed','exterior','GT')),
        ('quiet',3,('noisy','confirmed','exterior','GT')),
    ):
        path = destination/f'{label}-{key:03d}-{noise}-{name}.png'
        Image.fromarray(np.concatenate([native[arm][role] for arm in order],axis=1)).save(path,optimize=True)
        boards.append({'image':reference(path),'kind':name,'order':order,'role':role,'cell_native_pixels':[160,160]})
    return {'experiment':label,'index':key,'profile_id':noise,'metrics':row['metrics'],'source':photo['source'],
            'source_box':photo['box'],'CFA':photo['camera']['pattern'],'profile':plan['profiles'][noise],
            'capture_black':photo['camera']['black'],'kind':row['kind'],'colour':row['colour'],
            'ROI':[48,48,160,160],'display_exposure':2,'input':row['input'],'output':row['output'],
            'measurements':binding,'checkpoint':score['checkpoint'],'boards':boards}


def main():
    torch.set_num_threads(2)
    destination = ROOT/'native'
    destination.mkdir()
    entries = [(label,int(index),noise) for label,index,noise in (entry.split('/') for entry in sys.argv[1:])]
    rows = [panel(*entry,destination) for entry in entries]
    write_json(destination/'manifest.json',{'driver':reference(__file__),'rows':rows})


if __name__ == '__main__':
    main()
