"""Verify previous pixels, reserved-evidence isolation and crop provenance."""
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import fallback


def main():
    root = fallback.ROOT
    old = read_json(checked(reference(fallback.PREVIOUS/'scores.json')))
    replay = read_json(checked(reference(root/'replay-comparison.json')))
    for a,b in zip(old['cases'],replay['rows'],strict=True):
        assert a['input']==b['input']
        with np.load(checked(a['prediction']),allow_pickle=False) as older, np.load(checked(b['output']),allow_pickle=False) as newer:
            np.testing.assert_array_equal(older['colour-confirmed'],newer['confirmed'])
    cohort = read_json(checked(replay['cohort']))
    baseline = next(x for x in replay['rows'] if x['index']==2 and x['noise']=='iso6400')
    with np.load(checked(baseline['input']),allow_pickle=False) as f:
        cfa, wb, mat = (f[k][0] for k in ('colors','wb','matrix'))
        raw = f['packed'][0,:,64:192,64:192].copy()
    setting = cohort['profiles']['iso6400']
    with fallback.anchored((0,0)):
        held = fallback.local.partition()>1
    e = baseline['gates']['matching'][0]['candidate']
    original = {'state':baseline['gates']['matching'][0]['route'],
                'exterior':[g[:2] for g in e['frequency']]}
    initial = fallback.candidate(raw,cfa,setting,wb,mat,original)
    np.testing.assert_equal(e,initial)
    rng = np.random.default_rng(2)
    alternate = raw.copy()
    alternate[:,held] += rng.normal(0,.025,(4,int(held.sum()))).astype(np.float32)
    shifted = fallback.candidate(alternate,cfa,setting,wb,mat,original)
    for key in ('phase','colour_direction','frequency','discovery','discovery_pool'):
        assert shifted[key]==initial[key]
    assert shifted['folds'][:2]==initial['folds'][:2]
    assert shifted['folds'][2:]!=initial['folds'][2:]
    standing = read_json(checked(reference(root/'standing/manifest.json')))
    for item in standing['rows']:
        with np.load(checked(item['output']),allow_pickle=False) as f:
            np.testing.assert_array_equal(f['confirmed'],f['restored'])
        with Image.open(checked(item['image'])) as f:
            for region in item['panels']:
                assert region['png_xywh'][2:]==[160,160]
    write_json(root/'audit.json',{'driver':reference(__file__),'replay':reference(root/'replay-comparison.json'),
          'preceding':reference(fallback.PREVIOUS/'scores.json'),'matches_old_confirmed_arrays':len(replay['rows']),
          'held_intervention':{'input':baseline['input'],'changed_sites':4*int(held.sum()),'original':initial['folds'],'changed':shifted['folds']},
          'standing_exact_query_arrays':len(standing['rows']),'standing':reference(root/'standing/manifest.json')})


if __name__=='__main__':
    main()
