"""Probe Bayer chroma at exterior frequencies even when green-only delivery abstains."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_frequency import native_modulation, residual_sensor
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'query-signed-colour-v1'
sys.path.insert(0, str(PREVIOUS))
from colour import fit


def exterior_polish(raw, colours, noise, box, pair):
    """Refine donor frequencies in an exterior annulus, reserving all query samples."""
    h, w = raw.shape[-2:]
    yy, xx = np.indices((h, w))
    x, y, width, height = box
    dx, dy = 2 * xx + .5 - (x + (width - 1) / 2), 2 * yy + .5 - (y + (height - 1) / 2)
    distance = np.maximum(abs(dx), abs(dy))
    inner, outer = max(width, height) / 2 + 32, max(width, height) / 2 + 126
    weight = np.sin(np.pi * ((distance - inner) / (outer - inner)).clip(0, 1))**2
    discovery = (weight > 0) & ((xx + yy) % 2 == 0)
    if np.count_nonzero(discovery) < 1000:
        return None
    prepared = residual_sensor(raw, colours, noise, discovery, weight)
    result = []
    for initial in pair:
        f = np.asarray(initial)
        for step in (.002, .0005):
            grid = np.linspace(-2 * step, 2 * step, 5)
            bank = f + np.array(np.meshgrid(grid, grid)).reshape(2, -1).T
            amplitude = native_modulation((h, w), prepared, discovery, weight, bank)
            f = bank[np.argmax(abs(amplitude))]
        outside = (weight > 0) & ~discovery
        fit_amp = native_modulation((h, w), prepared, discovery, weight, [f])[0]
        held_amp = native_modulation((h, w), prepared, outside, weight, [f])[0]
        held = float(np.real(held_amp * fit_amp.conjugate()) / max(abs(fit_amp), 1e-20))
        if held < 3:
            return None
        result.append([*f, 0.])
    return result


def photo(task):
    fixture, route, plan = task
    profile = plan['profiles'][fixture['noise']]
    box = plan['query']
    x, y, w, h = box
    output = {}
    with np.load(checked(fixture['input']), allow_pickle=False) as data:
        for context, prefix in (('matching', ''), ('rotated', 'rotated_')):
            records = []
            for i, probe in enumerate(route['decisions']):
                state = probe[context]
                cfa, wb, matrix = (data[k][i] for k in ('colors', 'wb', 'matrix'))
                raw = data[prefix+'packed'][i]
                crop = raw[:, y//2:(y+h)//2, x//2:(x+w)//2]
                output_candidates = {}
                if state['exterior'] is not None:
                    candidates = {
                        'original-exterior': [[*f, 0.] for f in state['exterior']],
                        'green-refined': state['geometry'],
                        'exterior-polish': exterior_polish(raw, cfa, profile, box, state['exterior']),
                    }
                    for name, geometry in candidates.items():
                        if geometry is not None:
                            output_candidates[name] = fit(crop, cfa, profile, wb, matrix, {'geometry': geometry})
                records.append({'route':state['state'], 'candidates':output_candidates})
            output[context] = records
    return {k:fixture[k] for k in ('index','noise','input')} | {
        'color': plan['sources'][fixture['index']]['geometry']['color_role'], 'evaluations':output
    }


def main():
    plan_ref = reference(PREVIOUS/'plan.json')
    route_ref = reference(PREVIOUS/'results.json')
    capture_ref = reference(PREVIOUS/'captures.json')
    plan = read_json(checked(plan_ref))
    route = read_json(checked(route_ref))
    captures = read_json(checked(capture_ref))
    tasks = [(f, r, plan) for f, r in zip(captures['rows'], route['rows'], strict=True)]
    for f, r, _ in tasks:
        assert f['input'] == r['input']
    with ThreadPoolExecutor(4) as pool:
        evaluations = []
        for record in pool.map(photo, tasks):
            evaluations.append(record)
            vals = record['evaluations']['matching'][0]['candidates']
            print(record['index'], record['noise'], record['color'],
                  record['evaluations']['matching'][0]['route'],
                  {name: (v['admit'], round(v['reserve_pool'],2)) for name,v in vals.items()}, flush=True)
    write_json(ROOT/'measure.json', {'driver':reference(__file__), 'plan':plan_ref, 'captures':capture_ref,
                                    'routes':route_ref, 'evaluations':evaluations})


if __name__ == '__main__':
    main()
