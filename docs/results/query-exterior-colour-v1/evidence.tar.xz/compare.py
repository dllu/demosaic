"""Replay the current colour path and compare an exterior-frequency fallback."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import sys

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import fallback
from colour import LUMA, fit, render

CORE = np.s_[64:192, 64:192]
FLAT = np.s_[72:184, 72:184]
SENSOR = np.s_[...,64:192,64:192]
QUERY = np.s_[...,128:384,128:384]
PROFILES = ('iso400','iso6400')
ARMS = ('parent','confirmed','exterior')


def rms(data):
    return float(np.sqrt(np.mean(data**2)) * 65535)


def transform(data, inputs):
    rgb = linear_rgb(data, inputs).astype(float)
    y = np.einsum('c,bchw->bhw',LUMA,rgb)
    return rgb-y[:,None],y


def score(fixture, cohort, output):
    settings = cohort['profiles'][fixture['noise']]
    record = cohort['sources'][fixture['index']]
    with np.load(checked(fixture['input']), allow_pickle=False) as f:
        inputs = {k:f[k] for k in ('wb','matrix','colors','support')}
        inputs['target'] = f['target'][QUERY]
        mosaic = {k:f[prefix+'packed'][SENSOR] for k,prefix in (('matching',''),('rotated','rotated_'))}
    with np.load(checked(fixture['output']), allow_pickle=False) as f:
        parent = f['parent']
        shared = {'matching':f['shared'], 'rotated':f['rotated_shared']}
    cache = {'parent':parent, 'shared':shared['matching']}
    gates = {}
    control = {}
    for context in ('matching','rotated'):
        values = mosaic[context]
        before = shared[context]
        confirmed = before.copy()
        exterior = before.copy()
        footprint = np.zeros((4,256,256))
        entries = []
        for role, raw in enumerate(values):
            wb, matrix, cfa = (inputs[k][role] for k in ('wb','matrix','colors'))
            state = fixture['checks'][context][role]
            previous = fit(raw,cfa,settings,wb,matrix,state)
            confirmed[role] = render(parent[role],before[role],wb,matrix,previous,'colour-confirmed')
            route = fixture['source_geometry'][role][context]
            candidate = fallback.candidate(raw,cfa,settings,wb,matrix,route)
            exterior[role], mask = fallback.render(raw,cfa,settings,confirmed[role],wb,matrix,candidate)
            if mask is not None:
                footprint[role] = mask
            entries.append({'route':route['state'],'old':previous,'candidate':candidate,
                            'footprint_max':float(footprint[role].max())})
        c,y = transform(confirmed,inputs)
        cnew,ynew = transform(exterior,inputs)
        picked = (cnew-c)[...,CORE[0],CORE[1]]
        quiet = (cnew-c)[3,:,FLAT[0],FLAT[1]]
        if np.any(abs(y-ynew) > .02/65535):
            raise ValueError('Unexpected luma change')
        control[context] = {'query_chroma_DN16':[rms(image) for image in picked],
                            'max_camera_edit_DN16':[float(abs(image).max())*65535 for image in exterior.astype(float)-confirmed],
                            'exact_flat_core_added_chroma_DN16':rms(quiet),
                            'exact_flat_core_peak_chroma_DN16':float(abs(quiet).max())*65535,
                            'maximum_luma_change_DN16':float(abs(y-ynew).max())*65535}
        prefix = '' if context == 'matching' else 'rotated_'
        cache.update({prefix+'confirmed':confirmed,prefix+'exterior':exterior,prefix+'coverage':footprint.astype(np.float32)})
        gates[context] = entries
    truth,_ = transform(inputs['target'],inputs)
    truth = truth[...,CORE[0],CORE[1]]
    intact = inputs['support'][CORE] >= .97
    gap = inputs['support'][CORE] == 0
    target = (truth[0]-truth[1])[:,intact]
    energy = (target*target).sum()
    baseline = transform(cache['confirmed'],inputs)[0][...,CORE[0],CORE[1]]
    metrics = {}
    for arm in ARMS:
        c,_ = transform(cache[arm],inputs)
        c = c[...,CORE[0],CORE[1]]
        recovered = (c[0]-c[1])[:,intact]
        metrics[arm] = {'response_percent':float(100*(recovered*target).sum()/energy) if energy>1e-7 else None,
                        'intact_chroma_increment_DN16':rms(recovered-target),
                        'present_chroma_DN16':rms(c[0]-truth[0]),
                        'gap_added_colour_DN16':rms((c[0]-baseline[0])[:,gap]) if gap.any() else None}
    path = output/f'{fixture["index"]:03d}-{fixture["noise"]}.npz'
    np.savez(path,**cache)
    return {k:fixture[k] for k in ('index','noise','input')} | {
        'fixture':fixture['output'], 'output':reference(path),
        'colour':record['geometry']['color_role'], 'kind':record['geometry']['family'],
        'gates':gates, 'controls':control, 'metrics':metrics,
    }


def summary(rows):
    rng = np.random.default_rng(713825)
    tables = {}
    for profile in PROFILES:
        current = [r for r in rows if r['noise']==profile]
        coloured = [r for r in current if r['colour']!='neutral']
        activated = [r for r in coloured if r['controls']['matching']['max_camera_edit_DN16'][0]>0]
        table = {}
        for arm in ARMS:
            stats = {}
            for key in coloured[0]['metrics'][arm]:
                group = [r for r in coloured if r['metrics'][arm][key] is not None]
                if not group:
                    continue
                values = np.array([r['metrics'][arm][key] for r in group])
                diff = values - [r['metrics']['confirmed'][key] for r in group]
                sample = rng.integers(len(group),size=(10000,len(group)))
                stats[key] = [float(values.mean()),float(diff.mean()),*np.quantile(diff[sample].mean(axis=1),[.025,.975]).tolist()]
            table[arm] = stats
        counts = {}
        for context in ('matching','rotated'):
            counts[context] = {}
            for category, group in (('neutral',[r for r in current if r['colour']=='neutral']),('coloured',coloured)):
                counts[context][category] = [sum(r['controls'][context]['max_camera_edit_DN16'][role]>0 for r in group)
                                             for role in range(4)]
        tables[profile] = {'values':table,'counts':counts,
                           'active_coloured':[r['index'] for r in activated],
                           'flat_max_peak_DN16':max(r['controls'][c]['exact_flat_core_peak_chroma_DN16'] for r in current for c in ('matching','rotated')),
                           'max_luma_DN16':max(r['controls'][c]['maximum_luma_change_DN16']for r in current for c in ('matching','rotated'))}
    return tables


def main(label):
    source = fallback.PREVIOUS if label=='replay' else fallback.ROOT
    marker = reference(source/'fresh-gap.json')
    scores = read_json(checked(marker))
    physical = read_json(checked(scores['observations']))
    cohort = read_json(checked(physical['source']))
    output = fallback.ROOT/f'{label}-restoration'
    output.mkdir()
    rows=[]
    with ThreadPoolExecutor(3) as pool:
        for row in pool.map(partial(score,cohort=cohort,output=output),scores['rows']):
            rows.append(row)
            m = row['controls']['matching']
            print(row['index'],row['noise'],row['colour'],m['query_chroma_DN16'],m['exact_flat_core_added_chroma_DN16'],flush=True)
    write_json(fallback.ROOT/f'{label}-comparison.json',{'driver':reference(__file__),'implementation':reference(Path(fallback.__file__)),
               'upstream':marker,'cohort':physical['source'],'checkpoint':scores['checkpoint'],'rows':rows,'summary':summary(rows)})


if __name__ == '__main__':
    main(sys.argv[1])
