"""Compare unmodified local support with an independently fixed scalar lift."""

from pathlib import Path

import numpy as np

from delivery import metrics
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from summarize_delivery import statistics

HERE = Path(__file__).resolve().parent
DEVELOPMENT = HERE.parent / "mesh-background-transmission-v1"
CASES = [DEVELOPMENT, HERE]
PAIRS = (("affine", "parent"), ("local-transmission", "transmission"),
         ("local-transmission", "affine"), ("local-transmission", "frozen-scalar"),
         ("local-transmission", "rescaled-scalar"))
MEASURES = ("transmissive_wire", "additive_wire", "gap_addition", "no_rear_addition")

def components(result):
    return np.array([
        result["wire_increment_RMS_DN16"][0],
        result["wire_increment_RMS_DN16"][1],
        result["gap_addition_RMS_DN16"],
        result["no_rear_correction_RMS_DN16"],
    ])

def cohort(root, fixed):
    summary = read_json(root/"local-summary.json")["mean_and_two_sided_source_bootstrap"]
    scored = read_json(root/"delivery.json")["cases"]
    stored = {row["id"]: row for j in (0,1) for row in read_json(root/f"local-{j}.json")["cases"]}
    out = {}
    for name,scale in fixed.items():
        group = [row for row in scored if row["profile"]["name"] == name]
        correct = {}
        recalibrated = summary[name]["matched_gap_scales"]["transmission"]
        for row in group:
            score = {**row["metrics"], **stored[row["id"]]["metrics"]}
            obs = read_json(checked(row["observation"]))
            with np.load(checked(obs["readout"]),allow_pickle=False) as arrays:
                fields = {k:arrays[k] for k in ("wb","matrix","target","front","rear","gap")}
            channels = {k:np.broadcast_to(fields[k], (4,*fields[k].shape)) for k in ("wb","matrix")}
            with np.load(checked(row["prediction"]),allow_pickle=False) as arrays:
                parent = arrays["parent"]
                delta = arrays["transmission"] - parent
                for key,strength in (("frozen-scalar",scale),("rescaled-scalar",recalibrated)):
                    score[key] = metrics(parent+strength*delta,fields["target"],channels,
                                         fields["front"],fields["rear"],fields["gap"],parent)
            for key,result in score.items():
                correct.setdefault(key,[]).append(components(result))
        assert len(group) == 24
        absolute = {key:statistics(np.asarray(values)) for key,values in correct.items()}
        differences = {f"{a} minus {b}":statistics(np.asarray(correct[a])-np.asarray(correct[b]))
                       for a,b in PAIRS}
        out[name] = {"absolute":absolute,"paired_differences":differences,
                     "frozen_scalar":scale,"within_cohort_matched_scalar":recalibrated}
    return {"summary":reference(root/"local-summary.json"),"readouts":out}

def main():
    scope = read_json(DEVELOPMENT/"local-summary.json")["mean_and_two_sided_source_bootstrap"]
    fixed = {name:row["matched_gap_scales"]["transmission"] for name,row in scope.items()}
    write_json(HERE/"fixed-strength.json",{
        "driver":reference(__file__),"metrics_order":MEASURES,
        "frozen_scalar_source":"Development gap means fix a common scalar on the global lift. Replication does not use its own target to choose that scalar.",
        "cohort_matched_scalar":"A second diagnostic selects the scalar within each cohort to match its added gap RMS.",
        "cohorts":{root.name:cohort(root,fixed) for root in CASES},
    })

if __name__=="__main__":
    main()
