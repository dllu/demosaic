#!/usr/bin/env bash
set -euo pipefail
d=.cache/experiments/mesh-background-transmission-replication-v1
export PYTHONPATH=scripts:src OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
for ((attempt=0; attempt<240; attempt++)); do
    if [[ -f "$d/delivery-plan.json" ]]; then break; fi
    sleep 4
done
.venv/bin/python "$d/delivery.py" > "$d/delivery-finished.log" 2>&1
.venv/bin/python "$d/summarize_delivery.py" reduce
.venv/bin/python "$d/local_support.py" --plan
taskset -c 9 nice -n 12 .venv/bin/python "$d/local_support.py" --shard 0 > "$d/local-0.log" 2>&1 &
first=$!
taskset -c 11 nice -n 12 .venv/bin/python "$d/local_support.py" --shard 1 > "$d/local-1.log" 2>&1 &
second=$!
wait "$first"
wait "$second"
.venv/bin/python "$d/summarize_delivery.py" local
.venv/bin/python "$d/summarize_delivery.py" render
.venv/bin/python "$d/view_local.py"
