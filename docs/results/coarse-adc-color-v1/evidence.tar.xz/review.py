"""Test a coarse measured-color correction between near-ADC and ordinary noise."""

import argparse
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from report_full_faint_photo_panel import source_balance

from demosaic.adc_bins import near_adc_residual_projection
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import bilinear, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prior import box_mean
from report_scene_wave_guides import native_board

import sys

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "noisy-cfa-residual-v1"
sys.path.insert(0, str(OLD))
from probe import DN16, GFX, inputs_and_variants, score

WINDOW = 7
BLACK = 0.03
CODE_STEP = 1 / (DN16 * (1 - BLACK))
MINIMUM_CODES = 8
MAXIMUM_CODES = 160


def coarse_color(prediction, arrays, noise):
    shot, read = noise["shot"], noise["read"]
    code_sigma = (shot + read)**0.5 / CODE_STEP
    if not MINIMUM_CODES < code_sigma <= MAXIMUM_CODES:
        return prediction
    y, colors = (torch.from_numpy(arrays[k]) for k in ("packed","colors"))
    measured = mosaic(torch.from_numpy(prediction), colors)
    variance = shot * measured.clamp(0,1) + read + CODE_STEP**2 / 12
    margin = 2 * variance.sqrt()
    valid = (y > -BLACK / (1 - BLACK) + margin) & (y < 1 - margin)
    residual = torch.where(valid,y-measured,0)
    support = box_mean(valid.float(),WINDOW)
    divisor = support.clamp_min(1 / WINDOW**2)
    average = box_mean(residual,WINDOW) / divisor
    rms = ((box_mean(residual.square(),WINDOW)/divisor - average.square()).clamp_min(0)).sqrt()
    threshold = torch.maximum(8 * box_mean(variance,WINDOW).sqrt(),3 * rms)
    excess = average.sign() * (average.abs()-threshold).clamp_min(0)
    excess = torch.where((support>=0.8) & valid,excess,0)
    # A same-color estimate follows the measured residual. Share the green
    # offset between its two Bayer phases to avoid injecting a checkerboard.
    green = colors[:, :, None, None] == 1
    greens = (excess * green).sum(1,keepdim=True)/2
    correction = torch.where(green,greens,excess)
    return prediction + bilinear(correction,colors).numpy()


def variants(p, arrays, noise):
    packed,colors,wb = (torch.from_numpy(arrays[k]) for k in ("packed","colors","wb"))
    base = torch.from_numpy(p)
    earlier = near_adc_residual_projection(base,packed,colors,wb,shot=noise["shot"],read=noise["read"],black_level=BLACK)
    new = coarse_color(p,arrays,noise) if earlier is base else earlier.numpy()
    return {"raw":p,"guarded":new}


def palette(location):
    result=[]
    boards=[]
    for obs, a, predictions, models in inputs_and_variants(location):
        with np.load(checked(obs["target"])) as f:
            t=f["target"]
        for label,p in predictions.items():
            bundle = variants(p,a,obs["noise"])
            for policy,output in bundle.items():
                err=(output.astype(float)-t)[...,48:208,48:208]*DN16
                bias=err.mean((-2,-1),keepdims=True)
                centered=np.sqrt(np.mean((err-bias)**2,axis=(1,2,3)))
                for i,name in enumerate(obs["source_ids"]):
                    result.append({"id":obs["id"],"profile":obs["noise"]["name"],"CFA":obs["pattern"],"material":name,
                                   "model":label,"policy":policy,"bias_DN16":float(np.abs(bias[i]).max()),
                                   "centered_RMS_DN16":float(centered[i])})
            role={"noisy-residual-reserved-palette-v1":"magenta","nulls":"bright-yellow"}[location.name]
            if label != "scale-long86k" or obs["noise"]["name"]!="intermediate" or obs["pattern"]!="GBRG":
                continue
            i=obs["source_ids"].index(role)
            fields={k:a[k][i:i+1] for k in ("packed","colors","wb","matrix")}
            boards.append(native_board(
                ROOT/"review",f"{location.name}-{role}",[noisy_malvar(fields)[0],p[i],bundle["guarded"][i],t[i]], fields,
                {"source":role,"observation":obs,"models":models}, exposure=1,
                labels=("Noisy Malvar","86k raw EMA","86k coarse measured color","Exact GT"),
                triplet_indices=(0,2,3),
            ))
    return result,boards


def photos():
    fit=read_json(OLD/"calibration.json")["parameters"]
    plan=read_json(OLD/"plan.json")
    groups=defaultdict(list)
    boards=[]
    ids=sorted(s for group in plan["source_groups"] for s in group)[:2]
    for binding in plan["heldout"]:
        for o,a,ps,models in inputs_and_variants(checked(binding).parent,lambda obs:obs["noise"]["name"]=="intermediate"):
            selected={m:variants(p,a,o["noise"]) for m,p in ps.items()}
            computed,_,t=score(o,a,
                {model+"|"+policy:pred for model,arms in selected.items() for policy,pred in arms.items()},
                fit,
            )
            for r in computed:
                if r["policy"]=="raw":
                    name,policy=r["model"].split("|")
                    groups["intermediate"].append(r | {"model":name,"policy":policy})
            if o["pattern"]!="RGGB":
                continue
            for i,key in enumerate(o["source_ids"]):
                if key not in ids:
                    continue
                model=selected["scale-long86k"]
                local={k:a[k][i:i+1] for k in ("packed","colors","wb","matrix")}
                boards.append(native_board(
                    ROOT/"review",key,[noisy_malvar(local)[0],model["raw"][i],model["guarded"][i],t[i]],local,
                    {"source":key,"observation":o,"models":models},
                    exposure=1,contrast=20,labels=("Noisy Malvar","86k raw EMA","86k coarse measured color","Exact GT"),
                    triplet_indices=(0,2,3),
                ))
    summary={}
    for key,rows in groups.items():
        balance=source_balance(rows)
        summary[key]=[
            r | {"mean_sRGB":mean(x["PSNR_sRGB"] for x in rows if (x["model"],x["policy"])==(r["model"],r["policy"]))}
            for r in balance if r["band"] == "0"
        ]
    assert len(boards)==2
    return dict(groups),summary,boards


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    destination=ROOT/"review"
    destination.mkdir()
    cases, summary, photo_boards=photos()
    first, old_boards=palette(OLD/"nulls")
    reserve, reserve_boards=palette(ROOT.parent/"noisy-residual-reserved-palette-v1")
    assert len(first)==256 and len(reserve)==128
    comparisons=[]
    for o,a,predictions,_ in inputs_and_variants(GFX,lambda x:x["kind"] in ("mesh","gfx")):
        for model,p in predictions.items():
            assert variants(p,a,o["noise"])["guarded"] is p
            comparisons.append({"id":o["id"],"model":model,"bypass":True})
    assert len(comparisons)==18
    write_json(destination/"result.json",{
        "source":reference(__file__),"photo_rows":cases,"photo_summary":summary,
        "prior_controls":first,"reserved_colors":reserve,
        "camera_bypasses":comparisons,"boards":[*photo_boards,*old_boards,*reserve_boards],
        "data_plans":[reference(k) for k in (OLD/"plan.json",OLD/"nulls/plan.json",ROOT.parent/"noisy-residual-reserved-palette-v1/plan.json",GFX/"plan.json")],
        "scoring_fit":reference(OLD/"calibration.json"),
        "scope":"Saved EMA replays and exact synthetic color/edge targets. The reviewed intermediate prior falls within the coarse correction range. "
           "Both previously-viewed higher-noise GFX profiles bypass the treatment.",
    })
    for a in summary["intermediate"]:
        print(a["model"],a["policy"],a["mean_sRGB"],a["equal_source_RMS_DN16"],flush=True)
    for p in ("raw","guarded"):
        rows=[r for r in reserve if (r["model"],r["profile"],r["policy"])==("scale-long86k","intermediate",p)]
        print("palette",p,max(r["bias_DN16"] for r in rows),max(r["centered_RMS_DN16"] for r in rows),flush=True)


if __name__=="__main__":
    main()
