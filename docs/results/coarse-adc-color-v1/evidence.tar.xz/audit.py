"""Match the library correction against saved-study inputs and check zero activations."""

from pathlib import Path

import numpy as np
import torch

import review
from demosaic.adc_bins import coarse_adc_color_projection
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"noisy-cfa-residual-v1"


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    plan=read_json(OLD/"plan.json")
    datasets={checked(p).parent.name:checked(p).parent for p in plan["heldout"]}
    datasets.update({"original-nulls":OLD/"nulls","reserved-colors":ROOT.parent/"noisy-residual-reserved-palette-v1",
                     "GFX":review.GFX})
    contracts={}
    for name,directory in datasets.items():
        rows=[]
        keep=(lambda o:o["kind"] in ("mesh","gfx")) if name=="GFX" else (lambda o:True)
        for o,a,predictions,_ in review.inputs_and_variants(directory,keep):
            n=o["noise"]
            for model,p in predictions.items():
                expected=review.coarse_color(p,a,n)
                x=torch.from_numpy(p)
                y=coarse_adc_color_projection(x,torch.from_numpy(a["packed"]),torch.from_numpy(a["colors"]),
                                              shot=n["shot"],read=n["read"],black_level=0.03)
                np.testing.assert_array_equal(y.numpy(),expected)
                if name.startswith("heldout") or name=="GFX":
                    assert y is x
                rows.append({"observation":o["id"],"model":model,
                             "changed_samples":int(np.count_nonzero(y.numpy()!=p)),
                             "original_object":y is x})
        contracts[name]={"attested_tensor_results":len(rows),"rows":rows,
                         "source":reference(directory/"collection/result.json")}
    assert sum(len(contracts[k]["rows"]) for k in datasets if k.startswith("heldout"))==128
    assert len(contracts["GFX"]["rows"])==18
    write_json(ROOT/"library-replay.json", {
        "source":reference(__file__),"implementation":reference("src/demosaic/adc_bins.py"),
        "prototype":reference(ROOT/"review.py"),"contracts":contracts,
    })
    print("Prototype parity verified; all 128 photo predictions and 18 GFX predictions returned unchanged.")


if __name__=="__main__":
    main()
