"""Experimental measurement corrections for calibrated ADC and near-ADC inputs."""

import math
from functools import lru_cache

import torch
from torch.nn.functional import max_pool2d

from .cfa import bilinear, malvar, mosaic
from .precision import ieee_fp32
from .prior import box_mean


def _settings(bit_depth, black_level, quantizer_precision):
    if type(bit_depth) is not int or not 8 <= bit_depth <= 16:
        raise ValueError("ADC bit depth must be an integer in8..16")
    if not math.isfinite(black_level) or not 0 <= black_level < 1:
        raise ValueError("ADC black fraction must be in[0,1)")
    if quantizer_precision not in {"float32", "float64"}:
        raise ValueError("Declare float32 or float64 ADC simulator arithmetic")
    dtype = getattr(torch, quantizer_precision)
    if float(torch.tensor(black_level, dtype=dtype)) >= 1:
        raise ValueError("Black fraction rounds to one at the declared precision")
    return (1 << bit_depth) - 1, dtype


def _encode(value, levels, black_level, dtype):
    value = value.to(dtype)
    black = torch.as_tensor(black_level, dtype=dtype, device=value.device)
    return ((value * (1 - black) + black).clamp(0, 1) * levels).round().long()


def _decode(codes, levels, black_level, dtype):
    black = torch.as_tensor(black_level, dtype=dtype, device=codes.device)
    return ((codes.to(dtype) / levels - black) / (1 - black)).float()


def _ordered_float(keys):
    # Monotone unsigned ordering across finite float32 values and infinities;
    # NaNs lie outside the searched interval. Both signed zeros are retained.
    bits = torch.where(keys >= 0x80000000, keys ^ 0x80000000, ~keys) & 0xFFFFFFFF
    return bits.to(torch.int32).view(torch.float32)


@lru_cache(maxsize=4)
def _bounds_table(bit_depth, black_level, quantizer_precision):
    levels, dtype = _settings(bit_depth, black_level, quantizer_precision)
    codes = torch.arange(levels + 1, dtype=torch.int64)
    low = torch.full_like(codes, 0x007FFFFF)  # ordered -infinity
    high = torch.full_like(codes, 0xFF800000)  # ordered +infinity
    for _ in range(32):
        middle = (low + high) // 2
        above = _encode(_ordered_float(middle), levels, black_level, dtype) >= codes
        high = torch.where(above, middle, high)
        low = torch.where(above, low, middle + 1)
    if not torch.equal(low, high):
        raise RuntimeError("ADC inverse search did not converge")
    lower = _ordered_float(low)
    upper_keys = torch.cat((low[1:] - 1, low.new_tensor([0xFF800000])))
    upper = _ordered_float(upper_keys)
    if not torch.all(lower <= upper):
        raise RuntimeError("ADC code has no representable float32 preimage")
    return lower, upper, _decode(codes, levels, black_level, dtype)


@lru_cache(maxsize=4)
def _device_table(bit_depth, black_level, quantizer_precision, device):
    return tuple(
        table.to(device) for table in _bounds_table(bit_depth, black_level, quantizer_precision)
    )


def adc_bin_bounds(packed, *, bit_depth, black_level, quantizer_precision):
    """Exact float32 preimages of the declared ADC encoder, including tie rules.

    CPU simulator arithmetic is calibration metadata: the historical FP64 faint
    quantizer and FP32 color-grid quantizer have slightly different boundaries.
    Saturated endpoint codes have one-sided intervals. The packed input must
    match the declared CPU decoder exactly; arbitrary floating RAW is not
    assumed to use this calibration. Tables are constructed on CPU and copied
    to the processing device so CUDA rounding cannot redefine the source codec.
    """
    if packed.dtype != torch.float32 or not torch.isfinite(packed).all():
        raise ValueError("ADC bins require finite float32 packed observations")
    levels, dtype = _settings(bit_depth, black_level, quantizer_precision)
    black = torch.tensor(black_level, dtype=dtype)
    # Invert decoded bin centers in double precision to recover integer codes.
    # This is deliberately separate from encoding signals near bin boundaries.
    codes = ((packed.double() * float(1 - black) + float(black)) * levels).round().long()
    if not ((codes >= 0) & (codes <= levels)).all():
        raise ValueError("Packed values do not match the declared ADC decoder")
    lower, upper, decoded = _device_table(
        bit_depth, black_level, quantizer_precision, str(packed.device)
    )
    if not torch.equal(decoded[codes], packed):
        raise ValueError("Packed values do not match the declared ADC decoder")
    return lower[codes], upper[codes]


def _projection_colors(prediction, packed, colors):
    if packed.ndim != 4 or packed.shape[1] != 4:
        raise ValueError("Expected four packed CFA phases")
    if prediction.shape != (len(packed), 3, packed.shape[2] * 2, packed.shape[3] * 2):
        raise ValueError("Prediction and packed dimensions differ")
    if not torch.isfinite(prediction).all():
        raise ValueError("Prediction must be finite")
    if colors.ndim == 1:
        colors = colors[None].expand(len(packed), -1)
    if colors.shape != (len(packed), 4):
        raise ValueError("One four-phase CFA description is required per image")
    patterns = colors.new_tensor([[0, 1, 1, 2], [2, 1, 1, 0], [1, 0, 2, 1], [1, 2, 0, 1]])
    if not ((colors[:, None] == patterns[None]).all(-1).any(-1)).all():
        raise ValueError("Expected a Bayer color pattern")
    return colors


def adc_bin_projection(
    prediction,
    packed,
    colors,
    wb=None,
    *,
    bit_depth,
    black_level,
    quantizer_precision,
    shot,
    read,
    mode="malvar",
):
    """Clamp measured ADC sites and optionally lift their residual into missing colors.

    Positive photon/read noise returns the original prediction object. At zero
    noise, only incompatible measured predictions are clamped to their nearest
    feasible float32 value. Malvar lifts the residual with cross-color terms,
    bilinear interpolation uses only same-color residuals, and sites leaves
    missing channels unchanged. Flat-aware delivery uses bilinear where each
    phase's measured codes are constant across its packed 3x3 neighborhood.
    Measured channels are restored exactly after FP32 interpolation. Their
    camera-space squared error cannot increase when truth is in the declared
    bins. Missing-color, rendered-color and spatial errors have no such bound.
    This helper is opt-in; no model config or default inference path calls it.
    """
    if mode not in ("malvar", "bilinear", "sites", "flat-aware"):
        raise ValueError("ADC bin projection mode must be malvar, bilinear, sites or flat-aware")
    if any(not math.isfinite(v) or v < 0 for v in (shot, read)):
        raise ValueError("Noise coefficients must be finite and nonnegative")
    if shot > 0 or read > 0:
        return prediction
    colors = _projection_colors(prediction, packed, colors)
    with torch.autocast(prediction.device.type, enabled=False), ieee_fp32():
        p = prediction.float()
        lower, upper = adc_bin_bounds(
            packed,
            bit_depth=bit_depth,
            black_level=black_level,
            quantizer_precision=quantizer_precision,
        )
        observed = mosaic(p, colors)
        compatible = (observed >= lower) & (observed <= upper)
        nearest = torch.where(compatible, observed, observed.clamp(min=lower, max=upper))
        residual = nearest - observed
        if not residual.count_nonzero():
            return prediction
        if mode == "sites":
            output = p.clone()
        else:
            correction = (
                bilinear(residual, colors) if mode == "bilinear" else malvar(residual, colors, wb)
            )
            if mode == "flat-aware":
                high = max_pool2d(packed, 3, stride=1, padding=1)
                low = -max_pool2d(-packed, 3, stride=1, padding=1)
                flat = (low == high).all(dim=1, keepdim=True)
                flat_pixels = flat.repeat_interleave(2, dim=-2).repeat_interleave(2, dim=-1)
                correction = torch.where(flat_pixels, bilinear(residual, colors), correction)
            output = torch.where(correction != 0, p + correction, p)
        for b in range(len(p)):
            for phase, channel in enumerate(colors[b]):
                y, x = divmod(phase, 2)
                output[b, int(channel), y::2, x::2] = nearest[b, phase]
        return output


def near_adc_residual_projection(prediction, packed, colors, wb=None, *, shot, read, black_level):
    """Lift a robust measured residual for a calibrated 16-bit low-noise input.

    The original prediction is returned at zero noise and above eight codes
    RMS at full signal. Within that range, the update blends a noise-weighted
    measured residual with its excess above four estimated standard deviations.
    Samples near clipping are excluded. Malvar lifts the update onto native RGB.
    This separate opt-in operation does not constrain output to ADC bins.
    """
    if any(not math.isfinite(v) or v < 0 for v in (shot, read)):
        raise ValueError("Noise coefficients must be finite and nonnegative")
    levels, _ = _settings(16, black_level, "float32")
    step = 1 / (levels * (1 - black_level))
    if shot + read == 0 or math.sqrt(shot + read) > 8 * step:
        return prediction
    colors = _projection_colors(prediction, packed, colors)
    if packed.dtype != torch.float32 or not torch.isfinite(packed).all():
        raise ValueError("Near-ADC projection requires finite float32 packed observations")
    with torch.autocast(prediction.device.type, enabled=False), ieee_fp32():
        p = prediction.float()
        measured = mosaic(p, colors)
        sigma = (shot * measured.clamp(0, 1) + read + step**2 / 12).sqrt()
        floor = -black_level / (1 - black_level)
        valid = (packed > floor + 2 * sigma) & (packed < 1 - 2 * sigma)
        residual = torch.where(valid, packed - measured, 0)
        sigma_dn16 = sigma * levels
        weight = 4 / (4 + sigma_dn16)
        excess = residual.sign() * (residual.abs() - 4 * sigma_dn16 / levels).clamp_min(0)
        correction = weight * residual + (1 - weight) * excess
        return p + malvar(correction, colors, wb)


def coarse_adc_color_projection(prediction, packed, colors, *, shot, read, black_level):
    """Correct coherent color errors in the 8–160 ADC code RMS gap.

    For calibrated 16-bit inputs, use a local same-phase mean of the
    measured residual. Apply only the part exceeding both the local
    sensor-noise and residual-scatter thresholds. Share the coarse green
    correction between the two green phases and interpolate by color.
    This experimental correction does not lift individual fine residuals.
    """
    if any(not math.isfinite(v) or v < 0 for v in (shot, read)):
        raise ValueError("Noise coefficients must be finite and nonnegative")
    levels, _ = _settings(16, black_level, "float32")
    step = 1 / (levels * (1 - black_level))
    full_signal_codes = math.sqrt(shot + read) / step
    if not 8 < full_signal_codes <= 160:
        return prediction
    colors = _projection_colors(prediction, packed, colors)
    if packed.dtype != torch.float32 or not torch.isfinite(packed).all():
        raise ValueError("Coarse ADC color projection requires finite float32 packed observations")
    with torch.autocast(prediction.device.type, enabled=False), ieee_fp32():
        p = prediction.float()
        measured = mosaic(p, colors)
        variance = shot * measured.clamp(0, 1) + read + step**2 / 12
        black_floor = -black_level / (1 - black_level)
        margin = 2 * variance.sqrt()
        valid = (packed > black_floor + margin) & (packed < 1 - margin)
        residual = torch.where(valid, packed - measured, 0)
        window = 7
        support = box_mean(valid.float(), window)
        divisor = support.clamp_min(1 / window**2)
        mean = box_mean(residual, window) / divisor
        scatter = (box_mean(residual.square(), window) / divisor - mean.square()).clamp_min(0)
        threshold = torch.maximum(8 * box_mean(variance, window).sqrt(), 3 * scatter.sqrt())
        excess = mean.sign() * (mean.abs() - threshold).clamp_min(0)
        excess = torch.where((support >= 0.8) & valid, excess, 0)
        if not excess.count_nonzero():
            return prediction
        green = colors[:, :, None, None] == 1
        green_mean = (excess * green).sum(1, keepdim=True) / 2
        correction = torch.where(green, green_mean, excess)
        return p + bilinear(correction, colors)
