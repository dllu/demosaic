"""Check the gate algebra independent of model weights and observations."""
from pathlib import Path

import torch

from demosaic.experiments.artifacts import reference, write_json
from quiet_heads import ROOT, evidenced_delta


def main():
    rng = torch.Generator().manual_seed(8193)
    base = torch.randn(2048, 2, generator=rng, dtype=torch.float64)
    before = torch.randn(2048, 2, generator=rng, dtype=torch.float64)
    empty = torch.zeros(2048, 8, dtype=torch.float64)
    out = evidenced_delta(before, base, empty)
    same = evidenced_delta(before, base, empty+3)
    torch.testing.assert_close(same, before, atol=1e-12, rtol=1e-12)
    opposite = (out*base).sum(-1)
    assert (opposite <= 1e-12).all()
    assert (torch.linalg.vector_norm(base+out,dim=-1) <= torch.linalg.vector_norm(base,dim=-1)+1e-12).all()
    cross = (out[:,0]*base[:,1]-out[:,1]*base[:,0]).abs()
    assert cross.max() < 1e-12
    assert torch.count_nonzero(evidenced_delta(before,torch.zeros_like(base),empty)) == 0
    write_json(ROOT/"gate-audit.json",{
        "driver":reference(__file__),"head":reference(ROOT/"quiet_heads.py"),"vectors":len(base),
        "max_cross_phase_without_evidence":float(cross.max()),
        "max_delta_when_parent_and_evidence_zero":0.,
        "scope":"Complex coefficient rule, verified against true empty and full support cases.",
    })


if __name__=="__main__":
    main()
