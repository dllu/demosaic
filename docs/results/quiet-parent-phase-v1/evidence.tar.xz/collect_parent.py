"""Collect the frozen local-only 20k parent for matched training and wire tests."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import amp_context, ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
SCENE = ROOT.parent / "scene-full-epoch-v1"
MATCHED = SCENE / "matched-020000.json"
TRAINING = ROOT.parent / "learned-spectral-gaps-v1"
WIRE_GROUPS = {
    "wire": "query-exterior-colour-v1",
    "wire-tune": "query-gap-shoulders-v1",
}
KEYS = ("packed", "variance", "colors", "wb", "matrix")


def local_model(marker, device):
    artifact = read_json(checked(marker))
    assert artifact["through_update"] == 20_000 and artifact["matched_input_traces"]
    binding = artifact["arms"]["none"]["checkpoint"]
    model, state = load_scene_checkpoint(checked(binding), device=device, weights="ema",
                                         expected_sha256=binding["sha256"])
    assert state["step"] == 20_000 and state["mode"] == "none"
    assert state["loaded_sha256"] == binding["sha256"]
    model.eval().to(memory_format=torch.channels_last)
    return model, binding


def args_for(data, span=None):
    parts = [torch.from_numpy(data[k][span] if span is not None and k in KEYS[:2] else data[k]).cuda()
             for k in KEYS]
    parts[:2] = [x.contiguous(memory_format=torch.channels_last) for x in parts[:2]]
    return parts


def training(model, parent, matched):
    observed = reference(TRAINING / "observations.json")
    bank = read_json(checked(observed))
    schedule = read_json(checked(bank["plan"]))
    directory = ROOT / "train-parents"
    directory.mkdir()
    rows = []
    start = time.monotonic()
    for note, case in zip(bank["rows"], schedule["batches"], strict=True):
        capture = read_json(checked(note))
        assert capture["index"] == case["index"]
        model.base.set_noise(case["noise"]["shot"], case["noise"]["read"])
        with np.load(checked(capture["input"]), allow_pickle=False) as data:
            args = args_for(data)
        with amp_context("cuda", dtype="float16"):
            output = model(*args)
        values = output.cpu().numpy()
        assert values.shape == (3, 3, 256, 256) and values.dtype == np.float32 and np.isfinite(values).all()
        dest = directory / f'{case["index"]:03d}.npy'
        np.save(dest, values, allow_pickle=False)
        rows.append({"index": case["index"], "measurement": note, "parent": reference(dest)})
        if len(rows) % 40 == 0:
            print("training", len(rows), round(time.monotonic() - start, 2), flush=True)
    write_json(ROOT / "training-parent.json", {
        "driver": reference(__file__), "observations": observed, "plan": bank["plan"], "checkpoint": parent,
        "matched_binding": matched, "precision": "Standard CUDA FP16 autocast with FP32 native outputs",
        "rows": rows, "forward_seconds_wall": time.monotonic() - start,
    })


def wire(name, model, parent, matched):
    panel = ROOT.parent / WIRE_GROUPS[name]
    captures, spec = (reference(panel / file) for file in ("fresh-gap.json", "plan.json"))
    plan = read_json(checked(spec))
    items = read_json(checked(captures))["rows"]
    assert plan["query"] == [128, 128, 256, 256]
    output = ROOT / (name + "-parent")
    output.mkdir()
    rows = []
    start = time.monotonic()
    for row in items:
        cond = plan["profiles"][row["noise"]]
        model.base.set_noise(cond["shot"], cond["read"])
        with np.load(checked(row["input"]), allow_pickle=False) as store:
            args = args_for(store, np.s_[..., 48:208, 48:208])
        with ieee_fp32():
            full = model(*args).cpu().numpy()
        assert full.shape == (4, 3, 320, 320) and full.dtype == np.float32 and np.isfinite(full).all()
        result = np.ascontiguousarray(full[..., 32:288, 32:288])
        name_id = f'{row["index"]:03d}-{row["noise"]}'
        pixels = output / (name_id + ".npy")
        np.save(pixels, result, allow_pickle=False)
        rows.append({"id": name_id, "input": row["input"], "parent": reference(pixels)})
        if len(rows) % 12 == 0:
            print(name, len(rows), round(time.monotonic() - start, 2), flush=True)
    write_json(ROOT / (name + "-parent.json"), {
        "driver": reference(__file__), "inputs": captures, "plan": spec, "checkpoint": parent, "matched_binding": matched,
        "precision": "CUDA IEEE FP32 at native320 with a 32-pixel halo removed", "rows": rows,
        "forward_seconds_wall": time.monotonic() - start,
    })


@torch.inference_mode()
def main(*groups):
    torch.set_num_threads(2)
    limit = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1., 5 * 2**30 / limit))
    matched = reference(MATCHED)
    model, binding = local_model(matched, "cuda")
    print("loaded local 20k", binding["sha256"], flush=True)
    for part in groups:
        if part == "training":
            training(model, binding, matched)
        else:
            wire(part, model, binding, matched)


if __name__ == "__main__":
    main(*sys.argv[1:])
