"""Fit transported phase heads individually on the quieter frozen 20k parent."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import measure_witnesses
from quiet_heads import ARMS, REFERENCE, ROOT, GatedTransport, TransportHead
from phase import PARENT
from train_gap_head import SEED, EPOCHS, PHOTOS, EXACT_FLAT, batch, choose_tiles, design, objective


def assemble(entry):
    case, triplet = entry
    sources = design(entry)
    observation = read_json(checked(triplet["measurement"]))
    assert observation["index"] == case["index"]
    with np.load(checked(observation["input"]), allow_pickle=False) as store:
        measures = [measure_witnesses(mosaic, pattern, case["noise"])
                    for mosaic, pattern in zip(store["packed"], store["colors"], strict=True)]
    scale = np.maximum(np.mean([p.noise for p in measures[:2]], axis=0), .002)
    initial = sources["basis"][..., 0, 0]+1j * sources["basis"][..., 0, 1]
    proposal = np.stack([q.proposal(old, scale) for q, old in zip(measures, initial, strict=True)])
    proposal = np.stack((proposal.real, proposal.imag), axis=-1)
    witnesses = np.stack([p.features for p in measures])
    return sources | {"proposal": proposal, "witness": witnesses}


def collect():
    observed = reference(ROOT / "training-parent.json")
    parent = read_json(checked(observed))
    plan = read_json(checked(parent["plan"]))
    assert parent["observations"] == reference(PARENT / "observations.json")
    cases = plan["batches"]
    path = ROOT / "features"
    path.mkdir()
    stored = {}
    start = time.monotonic()
    with ThreadPoolExecutor(3) as workers:
        for i, features in enumerate(workers.map(assemble, zip(cases, parent["rows"], strict=True))):
            for key, array in features.items():
                assert np.isfinite(array).all()
                if key not in stored:
                    stored[key] = np.lib.format.open_memmap(
                        path / f"{key}.npy", mode="w+",
                        dtype=np.bool_ if key == "void" else np.float16,
                        shape=(len(cases), *array.shape),
                    )
                stored[key][i] = array
            if (i + 1) % 50 == 0:
                print(i + 1, round(time.monotonic()-start, 2), flush=True)
    for values in stored.values():
        values.flush()
    write_json(ROOT / "features.json", {"driver": reference(__file__), "parent": observed,
               "base_cache_routines": reference(PARENT / "train_gap_head.py"),
               "witness_source": reference("src/demosaic/phase_witness.py"),
               "tensors": {k: reference(path/f"{k}.npy") for k in stored},
               "photos": len(cases), "seconds": time.monotonic()-start})


def squared_flat(prediction, mask):
    support = mask[..., None, None]
    denominator = mask.sum().clamp_min(1) * prediction.shape[-2] * prediction.shape[-1]
    return (prediction[:, 2].square() * support).sum() / denominator


def train():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    device = "cuda"
    limit = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1., 5 * 2**30 / limit))
    pointer = reference(ROOT / "features.json")
    prepared = read_json(checked(pointer))
    prior = reference(REFERENCE / "training/completed.json")
    control = read_json(checked(prior))
    arrays = {k: np.load(checked(v), allow_pickle=False, mmap_mode="r") for k, v in prepared["tensors"].items()}
    photos = prepared["photos"]
    ordinary = TransportHead().to(device)
    guarded = GatedTransport().to(device)
    guarded.load_state_dict(ordinary.state_dict())
    nets = {"fit": ordinary, "quiet-fit": deepcopy(ordinary), "witness-gated": guarded}
    smoothed = {name: deepcopy(net).requires_grad_(False) for name, net in nets.items()}
    optimizer = torch.optim.AdamW([p for n in nets.values() for p in n.parameters()], lr=.001, weight_decay=.001)
    random = np.random.default_rng(SEED)
    output = ROOT / "training"
    output.mkdir()
    start = time.monotonic()
    step, budget = 0, photos // PHOTOS * EPOCHS
    traces = []
    for epoch in range(EPOCHS):
        order = random.permutation(photos)
        for offset in range(0, photos, PHOTOS):
            indices = order[offset:offset+PHOTOS]
            selected = choose_tiles(random, arrays["void_weight"], indices)
            fields = batch(arrays, indices, selected, device)
            local = torch.cat((fields["features"], fields["witness"]), dim=-1)
            basis = torch.cat((fields["basis"], fields["proposal"][..., None, :]), dim=-2)
            flat = torch.as_tensor(EXACT_FLAT[selected], device=device)
            step += 1
            lr = .001*step/24 if step <= 24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(budget-24)))
            optimizer.param_groups[0]["lr"] = float(lr)
            optimizer.zero_grad(set_to_none=True)
            losses = {}
            for name, net in nets.items():
                delta = net(local, fields["context"], basis)
                if step == 1:
                    assert not torch.any(delta)
                energy = squared_flat(delta, flat)
                value, _, projection = objective(delta, fields["target"], fields["basis"][..., 0, :], flat)
                loss = value + 3.3 * energy if name == "quiet-fit" else value
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(tuple(net.parameters()), 2.)
                if not torch.isfinite(norm):
                    raise FloatingPointError(step)
                losses[name] = torch.stack((loss, value, projection, energy)).detach()
            optimizer.step()
            with torch.no_grad():
                for name in ARMS:
                    torch._foreach_lerp_(tuple(smoothed[name].parameters()), tuple(nets[name].parameters()), .01)
            if step in (1,budget) or step % 48 == 0:
                item = {name: values.cpu().tolist() for name, values in losses.items()}
                traces.append({"step":step, "epoch":epoch+1, "losses":item})
                print(step,round(time.monotonic()-start,2),item,flush=True)
    torch.cuda.synchronize()
    seconds = time.monotonic()-start
    assert step == budget
    checkpoint = output/f"step{step:06d}.pt"
    with checkpoint.open("xb") as stream:
        torch.save({"raw":{k:n.state_dict()for k,n in nets.items()},
                    "EMA":{k:n.state_dict()for k,n in smoothed.items()},
                    "optimizer":optimizer.state_dict(),"steps":step,"seed":SEED},stream)
    write_json(output / "completed.json", {
        "driver":reference(__file__), "heads":reference(ROOT/"quiet_heads.py"),"checkpoint":reference(checkpoint),
        "parent":read_json(checked(prepared["parent"]))["checkpoint"],"old_phase":prior,"inputs":pointer,
        "photos":photos,"updates_per_head":step,"epochs":EPOCHS,"weights":"FP32 training, raw and EMA .99",
        "photo_visits_per_head":photos*EPOCHS,"native_queries_per_head":photos*EPOCHS*3,
        "optimizer":control["optimizer"],"training_seed":SEED,"seconds":seconds,
        "arms":{"fit":"Same transported-phase objective above new local parent",
                "quiet-fit":"Same fit with exact-flat correction energy weight raised from .70 to 4.0",
                "witness-gated":"Original weighting with complex attenuation and signed Bayer evidence for the remaining change"},
        "progress":traces,
    })


if __name__ == "__main__":
    {"features": collect,"train": train}[sys.argv[1]]()
