"""Verify bound receipts and copy native panels with their original pixels."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
ID = ROOT.name
OUT = Path("docs/results") / ID
IMAGES = Path("docs/images") / ID


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def write(path, record):
    path.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + "\n")


def check(binding, path=None):
    assert sha(path or Path(binding["path"])) == binding["sha256"], binding


def copy_image(binding, directory):
    stamp = binding["image"]
    original = Path(stamp["path"])
    path = IMAGES / directory / original.name
    path.parent.mkdir(parents=True, exist_ok=True)
    check(stamp, original)
    shutil.copyfile(original, path)
    check(stamp, path)
    stamp["path"] = path.relative_to(IMAGES).as_posix()
    tiles = {}
    with Image.open(path) as board:
        for panel in binding["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x <= board.width - w and 0 <= y <= board.height - h
            tiles[panel.get("label") or panel["name"]] = board.crop((x, y, x+w, y+h))
    assert len(tiles) == len(binding["panels"])
    return tiles


def presentation(training):
    record = {}
    for source, target, count in (("standing", "standing", 8), ("exact-final", "exact", 3), ("flat", "flat", 2)):
        manifest = read(f"{source}/manifest.json")
        assert len(manifest["rows"]) == count
        assert manifest["model"] == training["checkpoint"]
        assert manifest["local_parent_checkpoint"] == training["parent"]
        for row in manifest["rows"]:
            board = copy_image(row["board"], target)
            if target == "standing":
                continue
            for binding in (row["triplet"], *row.get("other_triplets", {}).values()):
                triplet = copy_image(binding, target)
                assert len(triplet) == 3
                for label, tile in triplet.items():
                    assert ImageChops.difference(tile, board[label]).getbbox() is None
        record[target] = manifest
    record["reviewed"] = {
        "standing": 8, "exact_boards": 3, "exact_triplets": 9, "flat_boards": 2, "flat_triplets": 2,
        "findings": "Sky stays visually smooth and coarse crossings stay coherent. Some right cab diagonals gain contrast. The left mesh is diffuse and fine junctions remain incomplete. The exact-flat core looks smooth in the displayed crops despite higher fine-band error over local 20k."
    }
    path = IMAGES / "manifest.json"
    write(path, record)
    return {"path": f"../../images/{ID}/manifest.json", "sha256": sha(path)}


def archive(label, sources):
    names = sorted(sources)
    path = OUT / label
    with tarfile.open(path, "w:xz", preset=4) as handle:
        for name in names:
            handle.add(sources[name], arcname=name, recursive=False)
    with tarfile.open(path) as handle:
        assert handle.getnames() == names
        for name in names:
            with handle.extractfile(name) as stream:
                assert hashlib.file_digest(stream, "sha256").hexdigest() == sha(sources[name])
    return {"path": label, "sha256": sha(path), "entries": len(names)}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    training = read("training/completed.json")
    checkpoint = training["checkpoint"]
    for key in ("checkpoint", "driver", "heads", "inputs", "old_phase", "parent"):
        check(training[key])
    prior = json.loads(Path(training["old_phase"]["path"]).read_text())
    check(prior["checkpoint"])
    checked = {
        "wire-results.json": (48, "initial-review/review_quiet.py"),
        "wire-calibration.json": (24, "initial-review/review_quiet.py"),
        "natural-results.json": (256, "review_quiet.py"),
        "natural-calibration.json": (16, "review_quiet.py"),
        "standing/manifest.json": (8, "initial-review/native_quiet.py"),
        "exact-final/manifest.json": (3, "native_quiet.py"),
        "flat/manifest.json": (2, "flat_quiet.py"),
        "calibrated-components.json": (256, "calibrate_components.py")
    }
    for name, (count, driver) in checked.items():
        receipt = read(name)
        check(receipt["driver"], ROOT / driver)
        assert receipt.get("checkpoint", receipt.get("model")) == checkpoint
        assert len(receipt["rows"]) == count, (name, len(receipt["rows"]))
    file_names = [
        *checked, "training/completed.json", f"training/{Path(checkpoint['path']).name}",
        "collect_parent.py", "train_local_phase.py", "quiet_heads.py", "features.json",
        "training-parent.json", "wire-parent.json", "wire-tune-parent.json",
        "audit_gate.py", "gate-audit.json", "review_quiet.py", "native_quiet.py",
        "flat_quiet.py", "calibrate_components.py", "tests.log",
        "initial-review/review_quiet.py", "initial-review/native_quiet.py",
        "publish_quiet.py"
    ]
    files = {name: ROOT / name for name in file_names}
    upstream = {
        "upstream/phase_witness.py": Path("src/demosaic/phase_witness.py"),
        "upstream/phase.py": ROOT.parent / "subbin-spectral-witness-v1/phase.py",
        "upstream/models.py": ROOT.parent / "subbin-spectral-witness-v1/models.py",
        "upstream/review_subbin.py": ROOT.parent / "subbin-spectral-witness-v1/review_subbin.py",
        "upstream/train_gap_head.py": ROOT.parent / "learned-spectral-gaps-v1/train_gap_head.py",
        "upstream/evaluate_gap_head.py": ROOT.parent / "learned-spectral-gaps-v1/evaluate_gap_head.py",
        "upstream/transported-completed.json": Path(training["old_phase"]["path"]),
    }
    check(read("wire-results.json")["witness"], upstream["upstream/phase_witness.py"])
    evidence = archive("evidence.tar.xz", files | upstream)
    initial = archive("initial-review.tar.xz", {
        p.relative_to(ROOT).as_posix(): p for p in (ROOT / "initial-review").iterdir()
    })
    write(OUT / "publication.json", {
        "experiment": ID,
        "checkpoint": {"path_in_archive": f"training/{Path(checkpoint['path']).name}", "sha256": checkpoint["sha256"]},
        "parent": training["parent"],
        "transported_earlier_head": prior["checkpoint"],
        "training": {"complete": True, **{key: training[key] for key in (
            "seconds", "updates_per_head", "photos", "photo_visits_per_head", "native_queries_per_head",
            "epochs", "training_seed", "optimizer", "arms", "weights")}},
        "presentation_weights": "EMA 0.99. Raw weights and their numerical evaluations are archived.",
        "scoped_numerical_evaluation_complete": True,
        "native_image_review_complete": True,
        "fixed_427_photo_and_camera_panels": "Outside this crop component study",
        "presentation": presentation(training),
        "evidence": evidence,
        "preserved_initial_review": initial,
        "upstream_sources": {name: sha(path) for name, path in upstream.items()}
    })
    print("Verified training, scoped panels, image hashes and exact triplet pixels.")


if __name__ == "__main__":
    main()
