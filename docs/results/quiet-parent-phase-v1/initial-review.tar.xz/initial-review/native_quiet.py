"""Render matched local-parent phase comparisons at the fixed native coordinates."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board
from review_quiet import (ROOT, SCENE, LOCAL, CAPTIONS, BASELINE_CAPTIONS, load,
                          photo_inputs, wire_inputs, predict)
import evaluate_gap_head as review

sys.path.insert(0, str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


def raw_full(saved):
    image, metadata = read_raw(checked(saved))
    height, width = (d//2*2 for d in image.shape)
    return np.stack([image[p//2:height:2,p%2:width:2]for p in range(4)]),np.asarray(
        color_indices(metadata.pattern).tolist(), dtype=np.int64)


def original_panels(board):
    with Image.open(checked(board["image"])) as image:
        return {p["label"]:np.array(image.crop((x,y,x+w,y+h)).convert("RGB"))
                for p in board["panels"] for x,y,w,h in (p["png_xywh"],)}


def standing():
    models, head, endpoint = load(raw_weights=False)
    archive = SCENE / "review-native-020000"
    rendered = reference(archive / "work/render/result.json")
    book = read_json(checked(rendered))
    old = read_json(checked(book["collections"]["none"]))
    assert old["checkpoint"] == endpoint["parent"]
    source = {r["id"]:r for r in old["records"]}
    setup = read_json(checked(book["plan"]))
    fields = {r["id"]:r for r in setup["observations"]}
    cfg = read_json("configs/gfx-green-mesh-20231231.json")
    predecessor = reference(ROOT.parent/"subbin-spectral-witness-v1/standing/manifest.json")
    prior = {r["id"]:r for r in read_json(checked(predecessor))["rows"]}
    outputs = ROOT/"standing"
    outputs.mkdir()
    collection = []
    for kind in ("main","mesh"):
        cases = [r for r in book["boards"]if r["id"].startswith(kind+"-")]
        real = prior[cases[0]["id"]]["raw"]
        exterior, actual_cfa = raw_full(real)
        for spec in cases:
            name = spec["id"]
            observed = fields[spec["observation"]]
            parents = source[spec["observation"]]
            assert spec["input_arrays"]==observed["arrays"]==prior[name]["input"]
            assert spec["noise"]==observed["noise"] and real==prior[name]["raw"]
            x,y,w,h = spec["case"]["ROI_xywh"]
            left,top = 2*((x-48)//2),2*((y-48)//2)
            if kind=="main":
                origin = observed["metadata"]["context_xywh"][:2]
            else:
                origin = cfg["raw_context_xywh"][:2]
            box = [origin[0]+left,origin[1]+top,256,256]
            assert box==prior[name]["box"]
            original = np.load(checked(parents["prediction"]),allow_pickle=False)
            local_parent = original[...,top:top+256,left:left+256]
            assert local_parent.shape==(1,3,256,256)
            with np.load(checked(observed["arrays"]),allow_pickle=False) as data:
                r = {k:data[k]for k in ("packed","colors","wb","matrix")}
            for key,value in r.items():
                assert fingerprint(value) == parents["input_fingerprints"][key], (name,key)
            r["packed"] = r["packed"][..., top//2:top//2+128,left//2:left//2+128]
            np.testing.assert_array_equal(r["colors"][0],actual_cfa)
            bx,by=box[:2]
            np.testing.assert_array_equal(r["packed"][0],exterior[:,by//2:by//2+128,bx//2:bx//2+128])
            actual = predict(r,exterior,spec["noise"],box,{LOCAL:local_parent},models,include_100k=False)
            exposure = spec["display_exposure"]
            roi = [x-left,y-top,w,h]
            panels = original_panels(spec)
            balance,conversion = (torch.from_numpy(r[k])for k in ("wb","matrix"))
            def display(values):
                frame=display_crop(torch.from_numpy(values),balance,conversion,roi,exposure=exposure)
                return np.rint(frame.clip(0,1)*255).astype(np.uint8)
            np.testing.assert_array_equal(display(local_parent),panels["Local-only 20k EMA"])
            begin = ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Spatial 20k EMA",
                     "Local-only 20k EMA")
            end = ("ISO100 AHD reference","ISO100 camera JPEG")
            pictures = [(k,panels[k])for k in begin if k in panels]
            pictures += [(CAPTIONS[k],display(img))for k,img in actual.items()]
            pictures += [(k,panels[k])for k in end if k in panels]
            image = native_png(outputs/(name+".png"),pictures)
            rgb = outputs/(name+".npz")
            np.savez_compressed(rgb, parent=local_parent, **actual)
            region = np.s_[...,roi[1]:roi[1]+160,roi[0]:roi[0]+160]
            measured = {k:float(np.sqrt(np.mean((v[region].astype(np.float64)-local_parent[region])**2))*65535)
                        for k,v in actual.items()}
            collection.append({"id":name,"raw":real,"input":observed["arrays"],"parent":parents["prediction"],
                "checkpoint":endpoint["checkpoint"],"paired_native_board":spec["image"],"display_exposure":exposure,
                "roi":roi,"native_box":box,"noise":spec["noise"],"board":image,
                "predictions":reference(rgb),"camera_RGB_RMS_DN16":measured})
            print(name, measured, flush=True)
        del exterior
    assert len(collection)==8
    write_json(outputs/"manifest.json",{"driver":reference(__file__),"training":head,"model":endpoint["checkpoint"],
         "local_parent_checkpoint":endpoint["parent"],"earlier_standing":rendered,"raw_crop_alignment":predecessor,
         "display":"Matched 20k archived 8-bit sRGB display_crop and native pixels",
         "rows":collection})


def exact():
    models, head, endpoint = load(raw_weights=False)
    directory = ROOT/"exact"
    directory.mkdir()
    natural = reference(review.NATURAL/"evaluation/collected.json")
    nr,wire_ref = (read_json(checked(natural))["records"],reference(ROOT/"wire-parent.json"))
    test, data, parents, proof = photo_inputs(next(r for r in nr
        if Path(r["path"]).stem=="001-iso6400-independent"))
    natural_plan = read_json(checked(test["plan"]))
    sample = natural_plan["rows"][test["case"]]
    cases = [("001-iso6400-independent",data,parents,data["scene_packed"],test["profile"],test["box"],
              {"source":sample["source"],"CFA":sample["camera"]["pattern"],"input":test["input"],"local_parent":proof},
              1/test["profile"]["exposure"],2.)]
    wire = read_json(checked(wire_ref))
    plan = read_json(checked(wire["plan"]))
    sources = read_json(checked(wire["inputs"]))
    saved = {r["id"]:r for r in wire["rows"]}
    prev = read_json(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")
    v120 = {r["input"]["sha256"]:r for r in prev["rows"]}
    for index in (12,14):
        captured=next(r for r in sources["rows"] if (r["noise"],r["index"])==("iso6400",index))
        data,bases,frozen = wire_inputs(captured,saved,v120)
        sample = plan["sources"][index]
        detail = {"source":sample["source"],"CFA":sample["camera"]["pattern"],"source_box":sample["box"],
                  "input":captured["input"],"local_parent":frozen,"family":sample["geometry"]["family"]}
        cases.append((f"{index:03d}-iso6400",data,bases,data["full"],plan["profiles"]["iso6400"],
                      plan["query"],detail,2.,1.))
    results=[]
    for name,raw,parents,exterior,noise,box,stamp,expo,contrast in cases:
        selection={k:raw[k][:1]for k in ("packed","colors","wb","matrix")}
        individual={k:v[:1]for k,v in parents.items()}
        predictions = predict(selection,exterior,noise,box,individual,models)
        comparison = individual | predictions
        names = [k for k in BASELINE_CAPTIONS if k in comparison] + list(CAPTIONS)
        labels=["Noisy Malvar"]+[(BASELINE_CAPTIONS | CAPTIONS)[key]for key in names]+["Exact GT"]
        noisy=noisy_malvar(selection)[0]
        exact=raw["target"][0]
        inputs=[noisy,*[comparison[k][0] for k in names],exact]
        tags=stamp | {"query":box,"noise":noise}
        full=native_board(directory,name,inputs,selection,tags,labels=labels,exposure=expo,
            contrast=contrast,triplet_indices=(0,labels.index(CAPTIONS["witness-gated"]),len(labels)-1))
        smaller={}
        for name2 in ("fit","quiet-fit"):
            output=native_board(directory,name+"-"+name2,[noisy,comparison[name2][0],exact],selection,tags,
                labels=("Noisy Malvar",CAPTIONS[name2],"Exact GT"),exposure=expo,contrast=contrast,
                triplet_indices=(0,1,2))
            smaller[name2]=output["triplet"]
        results.append(full | {"other_triplets":smaller})
    write_json(directory/"manifest.json",{"driver":reference(__file__),"weights":head,"model":endpoint["checkpoint"],
       "local_parent_checkpoint":endpoint["parent"],"rows":results,"natural_observations":natural,"wire_predictions":wire_ref})


if __name__=="__main__":
    torch.set_num_threads(1)
    {"standing":standing,"exact":exact}[sys.argv[1]]()
