"""Score delivered periodic terms and render frozen native exact comparisons."""
from collections import Counter
import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from model import GAIN,MODES,ROOT
from run_restore import observations
from score_panel import luma

MODES_ALL=("baseline","wide",*MODES)
CORE=np.s_[64:192,64:192]


def load():
    mark=reference(ROOT/"restoration.json")
    values=read_json(checked(mark))
    nominations=read_json(checked(values["proposal"]))
    archives=read_json(checked(nominations["inputs"]))
    plan=read_json(checked(archives["plan"]))
    assert len(values["rows"])==len(archives["rows"])==len(plan["sources"])==27
    return mark,values,nominations,archives,plan


def rms(data):
    return float(np.sqrt(np.mean(data.reshape(len(data),-1)**2,axis=1)).mean()*65535)


def measure():
    mark,values,nominations,archives,plan=load()
    stats=[]
    admission={}
    for outputs,decision,raw,source in zip(values["rows"],nominations["rows"],archives["rows"],plan["sources"],strict=True):
        i=outputs["index"]
        assert i==decision["index"]==source["index"]==raw["index"]
        category=source["layout"]["junction_kind"]
        camera=observations(raw)
        with np.load(checked(outputs["prediction"]),allow_pickle=False)as f:
            predictions={k:luma(f[k],camera)for k in MODES_ALL}
        gold=luma(camera["target"],camera)
        truth=(gold[0,0]-gold[0,1])
        inside=camera["region"][CORE]==1
        if category=="pure":
            assert not truth.any()
        else:
            assert np.any(truth)
        used={}
        for key,prediction in predictions.items():
            delta=prediction-predictions["wide"]
            difference=(prediction[:,0]-prediction[:,1])
            data={"increment_RMS":rms(difference-truth),"marked_increment_RMS":rms((difference-truth)[:,inside]),
                  "present_exact_RMS":rms((prediction-gold)[:,0]),"outside_only_added_from_wide":rms(delta[:,1]),
                  "strong_only_added_from_wide":rms(delta[:,2]),"flat_added_from_wide":rms(delta[:,3])}
            if category=="pure":
                data["pure_present_added_from_wide"]=rms(delta[:,0])
            else:
                data["projected_response"]=float((100*np.sum(difference*truth,axis=(1,2))/np.sum(truth**2)).mean())
                data["marked_projection"]=float((100*np.sum(difference[:,inside]*truth[inside],axis=1)
                                                  /np.sum(truth[inside]**2)).mean())
            used[key]=data
        for t in decision["trials"]:
            totals=admission.setdefault(category+"/"+t["role"],Counter())
            totals["draws"]+=1
            totals["prior_pair_present"]+=bool(t["prior"]["geometry"])
            for m,terms in t["proposal"]["modes"].items():
                totals[m+"_draws"]=totals[m+"_draws"]+any(q["accepted"]for q in terms)
                for q in terms:
                    totals[m+"_"+q["name"]]+=int(q["accepted"])
        stats.append({"index":i,"class":category,"metrics":used,"inputs":raw["capture"],"outputs":outputs["prediction"]})
    random=np.random.default_rng(83387)
    table={}
    for category in ("interaction","harmonics","pure"):
        rows=[r for r in stats if r["class"]==category]
        assert len(rows)==9
        resample=random.integers(len(rows),size=(10000,len(rows)))
        results={}
        for field in rows[0]["metrics"]["wide"]:
            sets={name:np.array([r["metrics"][name][field]for r in rows])for name in MODES_ALL}
            comparisons={}
            for a,b in (("free","wide"),("locked","wide"),("locked","free")):
                value=sets[a]-sets[b]
                comparisons[a+"-vs-"+b]=[float(value.mean()),*np.quantile(value[resample].mean(1),(.025,.975)).tolist()]
            results[field]={"mean":{k:float(v.mean())for k,v in sets.items()},"paired_95pct":comparisons}
        table[category]=results
    write_json(ROOT/"scores.json",{"driver":reference(__file__),"restoration":mark,
               "summary":table,"rows":stats,"nominations":{k:dict(v)for k,v in admission.items()}})


def native():
    torch.set_num_threads(2)
    mark,values,nomination,archives,plan=load()
    frozen=reference(ROOT/"scores.json")
    preliminary=[]
    for category in ("interaction","harmonics"):
        for row,source in zip(nomination["rows"],plan["sources"],strict=True):
            if source["layout"]["junction_kind"]!=category:
                continue
            usable=[q["repeat"]for q in row["trials"]
                    if q["role"]=="present"and any(v["accepted"]for v in q["proposal"]["modes"]["locked"])]
            if usable:
                preliminary.append((row["index"],usable[0]))
                break
    assert len(preliminary)==2
    out=ROOT/"native"
    out.mkdir()
    items=[]
    for i,repeated in preliminary:
        binding=values["rows"][i]["prediction"]
        capture=archives["rows"][i]
        observation=observations(capture)
        source=plan["sources"][i]
        with np.load(checked(binding),allow_pickle=False)as f:
            fields={k:f[k][repeated]for k in MODES_ALL}
        fields["noisy"]=malvar(torch.from_numpy(observation["packed"][repeated]),
                             torch.from_numpy(observation["colors"][repeated])).numpy()
        fields["target"]=observation["target"][repeated]
        transform={k:observation[k][repeated]for k in ("wb","matrix")}
        boxed={key:np.rint(display(a,transform,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
               for key,a in fields.items()}
        for name,r,columns in (
            ("triplet",0,("noisy","locked","target")),
            ("comparison",0,(*MODES_ALL,"target")),
            ("outside",1,(*MODES_ALL,"target")),
            ("quiet",3,(*MODES_ALL,"target")),
        ):
            path=out/f"{i:03d}-{name}.png"
            Image.fromarray(np.concatenate([boxed[v][r]for v in columns],axis=1)).save(path,optimize=True)
            items.append({"image":reference(path),"index":i,"condition":source["layout"]["junction_kind"],
                          "role":name,"repeat":repeated,"source":source["source"],"box":source["box"],
                          "CFA":source["camera"]["pattern"],"ROI_in_query":[48,48,160,160],
                          "order":columns,"capture":capture,"output":binding,"display_exposure":2,
                          "conditioning":plan["profile"]})
    write_json(out/"manifest.json",{"driver":reference(__file__),"restoration":mark,"score":frozen,
               "checkpoint":values["checkpoint"],"rows":items,
               "selection":"First two fields, one per higher-order geometry, in which a present draw passes the phase-locked rule."})


if __name__=="__main__":
    measure()
    native()
