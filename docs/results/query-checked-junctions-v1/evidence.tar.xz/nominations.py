"""Bind the measured frequency pairs and the added-term witnesses."""
from concurrent.futures import ThreadPoolExecutor
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from model import EXTERIOR,ROOT,select
from forecasts import nominate

ROLES=("present","outside-only","strong-only","quiet-query")


def test(job):
    row,plan=job
    with np.load(checked(row["capture"]),allow_pickle=False)as f:
        inputs={k:f[k]for k in ("packed","colors")}
    base=nominate((row,None))
    x,y,w,h=plan["query_box"]
    specs=[]
    for before in base["trials"]:
        rep=before["repeat"]
        role=ROLES.index(before["role"])
        packed=inputs["packed"][rep,role,:,y//2:(y+h)//2,x//2:(x+w)//2]
        colors=inputs["colors"][rep,role]
        choice=select(packed,colors,plan["profile"],before["geometry"])
        specs.append({"repeat":rep,"role":before["role"],"prior":before,"proposal":choice})
    return {"index":row["index"],"input":row["capture"],"trials":specs}


def fresh():
    stamp=reference(ROOT/"fields.json")
    records=read_json(checked(stamp))
    plan=read_json(checked(records["plan"]))
    results=[]
    t=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        for i,row in enumerate(pool.map(test,((p,plan)for p in records["rows"])),1):
            results.append(row)
            print(i,round(time.monotonic()-t,2),flush=True)
    write_json(ROOT/"nominations.json",{"driver":reference(__file__),"inputs":stamp,
        "prior_method":reference(ROOT.parent/"query-phase-support-v1"/"forecasts.py"),
        "model":reference(ROOT/"model.py"),"rows":results})


def standing():
    p=reference(EXTERIOR/"specificity-standing.json")
    a=read_json(checked(p))
    b=read_json(EXTERIOR/"standing/manifest.json")
    maps={r["id"]:r for r in b["rows"]}
    out=[]
    for row in a["rows"]:
        case=maps[row["id"]]
        meta=row["previous"]
        x,y,w,h=meta["window"]
        with np.load(checked(meta["raw"]),allow_pickle=False)as f:
            pixels=f["packed"][0,:,y//2:(y+h)//2,x//2:(x+w)//2]
            colors=f["colors"][0]
        choice=select(pixels,colors,case["shot_read"],meta["geometry"])
        out.append({"id":row["id"],"camera":meta["raw"],"model":choice,"box":meta["window"]})
    exact=reference(ROOT/"standing-nomination.json")
    archived=read_json(checked(exact))
    assert archived["rows"]==__import__("json").loads(__import__("json").dumps(out))
    write_json(ROOT/"standing-nomination-audit.json",{"original":exact,"driver":reference(__file__),
                "new_run_byte_identical_rows":True})


if __name__=="__main__":
    standing() if len(sys.argv)>1 else fresh()
