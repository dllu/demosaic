"""Render the native higher-order correction on both standing GFX families."""
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from model_delivery import GAIN,EXTERIOR,ROOT,MODES,render

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    now=reference(ROOT/"standing-nomination.json")
    data=read_json(checked(now))
    old=reference(EXTERIOR/"standing/manifest.json")
    historical=read_json(checked(old))
    cases={r["id"]:r for r in historical["rows"]}
    out=ROOT/"standing"
    out.mkdir()
    rows=[]
    for p in data["rows"]:
        row=cases[p["id"]]
        x,y,w,h=p["box"]
        assert p["camera"]==row["input"] and p["box"]==row["query_box"]
        with np.load(checked(p["camera"]),allow_pickle=False)as a:
            packed=a["packed"][0,:,y//2:(y+h)//2,x//2:(x+w)//2]
            colors,wb,matrix=(a[k][0]for k in ("colors","wb","matrix"))
        with np.load(checked(row["inherited_arrays"]),allow_pickle=False)as a:
            baseline=a["wide"][0].copy()
        computed=render(packed,colors,row["shot_read"],baseline,wb,matrix,p["model"])
        rx,ry,rw,rh=row["ROI"]["ROI_xywh"]
        box=(rx-x,ry-y,rw,rh)
        with Image.open(checked(row["image"]))as f:
            strip=np.asarray(f.convert("RGB"))
        panels={q["name"]:strip[v:v+b,u:u+a]for q in row["panels"]for u,v,a,b in (q["png_xywh"],)}
        choices=["ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Neighbor-frequency check"]
        seen=[(key,panels[key])for key in choices if key in panels]
        numerical={}
        ox,oy,d,e=box
        roi=np.s_[...,oy:oy+e,ox:ox+d]
        for label,name in (("locked","Phase-locked bands"),("free","Free-phase bands")):
            delta=computed[label]
            predicted=baseline+GAIN*delta
            pixels=np.rint(display_crop(torch.from_numpy(predicted[None]),torch.from_numpy(wb[None]),
                   torch.from_numpy(matrix[None]),box,exposure=row["display_exposure"])*255).astype(np.uint8)
            seen.append((name,pixels))
            numerical[label]={"RMS_change_DN16":float(65535*np.sqrt(np.mean((GAIN*delta[roi].astype(float))**2))),
                 "changed_display_components":int((pixels!=panels["Neighbor-frequency check"]).sum())}
        seen.extend((k,panels[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in panels)
        rendered=native_png(out/(p["id"]+".png"),seen)
        rgb=out/(p["id"]+".npz")
        with rgb.open("wb")as f:
            np.savez(f,wide=baseline,**computed)
        rows.append(row|rendered|{"previous_image":row["image"],"guarded_statistics":numerical,
                                  "prediction":reference(rgb),"new_geometry":p["model"]})
        print(p["id"],numerical,flush=True)
    write_json(out/"manifest.json",{"driver":reference(__file__),"nominations":now,"prior_boards":old,
                                   "checkpoint":historical["checkpoint"],"gain":GAIN,"delivery_model":reference(ROOT/"model_delivery.py"),"rows":rows})


if __name__=="__main__":
    run()
