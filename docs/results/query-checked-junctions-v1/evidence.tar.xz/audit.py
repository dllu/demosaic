"""Verify phase selection isolation, physical sample coordinates and held camera support."""
from copy import deepcopy
import json

import numpy as np
import torch

from demosaic.cfa import color_indices,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from model import ROOT,MODES,choose_nuisance,interior,phases,select,witness_out
from model_delivery import render,GAIN
from witness import anchored,local
from run_restore import observations


def synthetic():
    coord=np.arange(256)-127.5
    y,x=np.meshgrid(coord,coord,indexing="ij")
    pair=[[.105,.066,1e-5],[.084,-.078,-1e-5]]
    phi=phases(x.ravel(),y.ravel(),pair)+[.63,-.32]
    a,b=phi.T
    parent=(.31+.014*np.cos(a)+.009*np.cos(b)).reshape(256,256)
    added=(.0042*np.cos(a)*np.cos(b)+.0033*np.cos(2*a)).reshape(256,256)
    clean=np.broadcast_to(parent,(3,256,256)).copy()
    input=torch.from_numpy((clean+added).astype(np.float32))[None]
    noise={"shot":0.,"read":1e-10}
    result={}
    for layout in ("RGGB","GRBG","GBRG","BGGR"):
        order=color_indices(layout)[None]
        packed=mosaic(input,order)[0].numpy()
        proposal=select(packed,order[0].numpy(),noise,pair)
        pixels=render(packed,order[0].numpy(),noise,clean,np.ones(3),np.eye(3),proposal)
        for k,prediction in pixels.items():
            central=np.s_[...,64:192,64:192]
            err=float(abs(prediction[central]-added[central]).max())
            result[layout+"/"+k]={"estimated_phase_max_abs":err}
        oracle=deepcopy(proposal)
        oracle["Q0_angles"]=[.63,-.32]
        for terms in oracle["modes"].values():
            for t in terms:
                t["local_axis"]=[1.,0.]
                t["accepted"]=t["name"] in ("second-0","sum","difference")
        pixels=render(packed,order[0].numpy(),noise,clean,np.ones(3),np.eye(3),oracle)
        for k,prediction in pixels.items():
            err=float(abs(prediction[central]-added[central]).max())
            assert err<1e-6,(layout,k,err)
            result[layout+"/"+k]["supplied_phase_max_abs"]=err
    return result


def real_witness(archive):
    scores=[]
    profiles={r["id"]:r["shot_read"]for r in read_json(ROOT/"standing/manifest.json")["rows"]}
    for row in archive["rows"]:
        choice=row["model"]
        if not choice["observed"]:
            continue
        x0,y0,w,h=row["box"]
        with np.load(checked(row["camera"]),allow_pickle=False)as file:
            packed=file["packed"][0,:,y0//2:(y0+h)//2,x0//2:(x0+w)//2]
            colors=file["colors"][0]
        noise=profiles[row["id"]]
        data,_,boundary=interior(packed,colors,noise)
        x,y,p,raw,var,fold=data
        bg,carriers=choose_nuisance(data,boundary,choice["geometry"])
        known=phases(x,y,choice["geometry"])+np.array(choice["Q0_angles"])
        components=choice["modes"]["locked"]
        bins=[]
        for term in components:
            angle=known@term["integer_phase"]
            bins.append(np.column_stack((np.cos(angle),np.sin(angle))))
        for i,t in enumerate(components):
            axis=np.asarray(t["local_axis"])
            shifted=np.array([-axis[1],axis[0]])
            null=np.column_stack((bg,carriers,*(c for j,c in enumerate(bins)if i!=j)))
            inside=np.maximum(abs(x),abs(y))<=96
            fixed=witness_out(x,y,raw,var,fold,inside,bins[i]@axis,null)
            assert abs(fixed["pooled"]-t["pooled"])<1e-9,(row["id"],t["name"])
            reference=witness_out(x,y,raw,var,fold,inside,bins[i]@shifted,null)
            scores.append({"camera":row["id"],"band":t["name"],"checked":fixed,
                "ninety_degree_rotation":reference,"accepted":t["accepted"]})
    return scores


def run():
    torch.set_num_threads(2)
    pre=synthetic()
    receipt=reference(ROOT/"restoration.json")
    predictions=read_json(checked(receipt))
    choices=read_json(checked(predictions["proposal"]))
    assets=read_json(checked(choices["inputs"]))
    plan=read_json(checked(assets["plan"]))
    training=read_json(ROOT.parent/"scene-full-epoch-v1"/"plan.json")["train_manifest"]
    with checked(training).open()as f:
        train={json.loads(row)["id"]for row in f}
    sources={r["source"]["id"]for r in plan["sources"]}
    assert len(sources)==27 and len(train)==90692 and not sources&train
    for node in plan["excluded"]:
        r=read_json(checked(node))
        assert not sources&{p["source"]["id"]for p in r.get("sources",r.get("heldout_rows",[]))}
    altered=np.random.default_rng(46382)
    with anchored((0,0)):
        held=local.partition()>=2
    tests=[]
    for row,decision,source in zip(predictions["rows"],choices["rows"],assets["rows"],strict=True):
        i=row["index"]
        assert i==decision["index"]==source["index"]
        q=next((t for t in decision["trials"]if t["role"]=="present"
                and any(v["accepted"]for v in t["proposal"]["modes"]["locked"])),None)
        if q is None:
            continue
        material=observations(source)
        repeat=q["repeat"]
        raw,colors,wb,matrix=(material[k][repeat,0]for k in ("packed","colors","wb","matrix"))
        plan_of=q["proposal"]
        got=select(raw,colors,plan["profile"],q["prior"]["geometry"])
        assert json.loads(json.dumps(got))==plan_of
        within=raw.copy()
        within[:,held]=altered.uniform(.001,.6,(4,int(held.sum())))
        swapped=select(within,colors,plan["profile"],q["prior"]["geometry"])
        assert swapped["Q0_angles"]==got["Q0_angles"]
        for kind in MODES:
            for a,b in zip(swapped["modes"][kind],got["modes"][kind],strict=True):
                assert all(a[k]==b[k]for k in ("discovery","local_axis","frequency"))
        with np.load(checked(row["prediction"]),allow_pickle=False)as p:
            base=p["wide"][repeat,0]
            positions=render(raw,colors,plan["profile"],base,wb,matrix,plan_of)
            for k,result in positions.items():
                np.testing.assert_array_equal(base+GAIN*result,p[k][repeat,0])
        tests.append({"index":i,"repeat":repeat,"Q0_choices_unchanged":True,"delivery_roundtrip_equal":True})
        if len(tests)==5:
            break
    assert len(tests)==5
    cameras=reference(ROOT/"standing-nomination.json")
    rows=real_witness(read_json(checked(cameras)))
    score=reference(ROOT/"scores.json")
    assert read_json(checked(score))["restoration"]==receipt
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"restoration":receipt,"score":score,"training":training,
                "train_overlap":0,"noiseless_CFA_error":pre,"four_fold_checks":tests,"standing_inputs":cameras,
                "held_rotation_control_real":rows,
                "scope":"Holding the previous geometry fixed, altering Q2/Q3 preserves Q0 phase and coefficient estimates. Real nominal and transferred priors weight the same capture."})
    print(len(tests),pre,len(rows),flush=True)


if __name__=="__main__":
    run()
