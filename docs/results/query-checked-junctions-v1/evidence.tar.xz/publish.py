"""Bind fixed evidence and inspected native boards to the composed checkpoint."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path("docs/results/query-checked-junctions-v1")
IMAGES = Path("docs/images/query-checked-junctions-v1")

REAL_NOTES = {
    "main-overcast-sky-main-overcast-sky": "Sky stays smooth and matches the previous output pixel for pixel.",
    "main-building-detail-main-building-detail": "The girders and wires match the previous output. Narrow lines remain softer than in ISO100.",
    "main-foliage-main-foliage": "Leaf edges and shadow detail match the previous output. Small edges remain soft.",
    "main-chain-link-fence-main-chain-link-fence": "Both lattice directions stay visible. Crossings look slightly better defined, with much smaller differences between restorations than between restoration and reference.",
    "mesh-nominal-fine-green-mesh-left": "Faint diagonal fragments and soft detail around the green post match the previous output.",
    "mesh-nominal-fine-green-mesh-right": "Some crossings below the pale diagonal become better defined. The fine lattice stays uneven and softer than in either ISO100 reference.",
    "mesh-profile3879-fine-green-mesh-left": "Faint diagonal fragments near the post match the previous output. Both ISO100 references show many missing crossings.",
    "mesh-profile3879-fine-green-mesh-right": "The lower central crossings and some repeat texture above the diagonal become slightly clearer. Background mottling and incomplete crossings remain.",
}

EXACT_NOTES = {
    "interaction": "The crossing texture is clearer in the dark band. The exact target has more modulation on the pale background.",
    "harmonics": "Mesh texture remains strongest on the dark side. Fine modulation on the light side remains weaker than the exact target.",
    "outside": "The coarse scene edges and both fundamentals remain. No apparent new pattern from the added branch.",
    "quiet": "The exact-flat crop stays smooth across the compared paths.",
}


def publish():
    score = reference(ROOT / "scores.json")
    evidence = read_json(checked(score))
    audit = read_json(ROOT / "audit.json")
    exact = read_json(ROOT / "native/manifest.json")
    real = read_json(ROOT / "standing/manifest.json")
    standing_audit = read_json(ROOT / "standing-nomination-audit.json")
    assert exact["checkpoint"] == real["checkpoint"]
    assert exact["score"] == audit["score"] == score
    assert exact["restoration"] == audit["restoration"] == evidence["restoration"]
    assert real["nominations"] == standing_audit["original"] == audit["standing_inputs"]
    records = {"exact": exact, "standing": real}
    for family, manifest in records.items():
        for row in manifest["rows"]:
            binding = row["image"]
            source = checked(binding)
            path = IMAGES / family / source.name
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, path)
            assert reference(path)["sha256"] == binding["sha256"]
            row["image"] = {"path": str(path), "sha256": binding["sha256"]}
            if family == "exact":
                boxes = [(j * 160, 0, 160, 160) for j in range(len(row["order"]))]
                role = row["role"] if row["role"] in ("quiet", "outside") else row["condition"]
                row["actual_viewing"] = EXACT_NOTES[role]
            else:
                boxes = [p["png_xywh"] for p in row["panels"]]
                row["actual_viewing"] = REAL_NOTES[row["id"]]
            with Image.open(path) as board:
                assert all(w == h == 160 and x+w <= board.width and y+h <= board.height for x,y,w,h in boxes)
                board.verify()
    assert len(exact["rows"]) == len(real["rows"]) == 8
    manifest = IMAGES / "manifest.json"
    write_json(manifest, records | {"actual_native_viewing_complete": True})
    RESULT.mkdir(exist_ok=True)
    archive = RESULT / "evidence.tar.xz"
    rules = ("*.py", "*.json", "*.log", "initial/*.py", "initial/*.log",
             "initial/standing/manifest.json", "native/manifest.json", "standing/manifest.json")
    with tarfile.open(archive, "x:xz") as bundle:
        for rule in rules:
            for source in sorted(ROOT.glob(rule)):
                bundle.add(source, arcname=source.relative_to(ROOT))
    write_json(RESULT / "publication.json", {
        "study": "query-checked-junctions-v1",
        "training_performed": False,
        "numeric_evaluation_complete": True,
        "actual_native_viewing_complete": True,
        "checkpoint": exact["checkpoint"],
        "parent_weights": "EMA",
        "weak_residual_gain": real["gain"],
        "standing_statistics": {r["id"]: r["guarded_statistics"] for r in real["rows"]},
        "audit": audit,
        "source_bound_inputs": evidence["nominations"],
        "exact_summary": evidence["summary"],
        "nominations": evidence["nominations"],
        "manifest": reference(manifest),
        "archive": reference(archive),
        "scope": "27 held-out exact-target photo backgrounds and eight native standing GFX review boards. No full427 or measured-camera panel for this component."
    })


if __name__ == "__main__":
    publish()
