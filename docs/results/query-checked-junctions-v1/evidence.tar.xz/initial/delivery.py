"""Add held higher-order corrections over the same Corpus 100k and wide pair path."""
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from model import curvature,GAIN,MODES,ROOT,render
from run_restore import ARGS,observations,setup_models


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    source=reference(ROOT/"nominations.json")
    nominated=read_json(checked(source))
    assets=read_json(checked(nominated["inputs"]))
    plan=read_json(checked(assets["plan"]))
    root=ROOT/"predictions"
    root.mkdir()
    records=[]
    timer=time.monotonic()
    with ieee_fp32():
        net=setup_models({"models":{"Corpus100k":plan["base"]}})["Corpus100k"]
        net.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for captured,record in zip(assets["rows"],nominated["rows"],strict=True):
            i=captured["index"]
            args=observations(captured)
            samples=[torch.from_numpy(args[k].reshape((-1,*args[k].shape[2:]))).cuda()for k in ARGS]
            samples[:2]=[s.contiguous(memory_format=torch.channels_last)for s in samples[:2]]
            restored=net(*samples)
            parents=restored.cpu().numpy().reshape(2,4,3,256,256)
            wide=parents.copy()
            gains={k:np.zeros_like(parents)for k in MODES}
            for group,case in enumerate(record["trials"]):
                repeat,role=divmod(group,4)
                assert case["repeat"]==repeat and record["index"]==i
                primary=case["prior"]["geometry"]
                if not primary:
                    continue
                previous=curvature.deliver([x[group:group+1]for x in samples],restored[group:group+1],primary)
                wide[repeat,role]+=GAIN*previous[0].cpu().numpy()
                facts=[args[k][repeat,role]for k in ("packed","colors","wb","matrix")]
                local=render(*facts[:2],plan["profile"],wide[repeat,role],*facts[2:],case["proposal"])
                for key,val in local.items():
                    gains[key][repeat,role]=val*GAIN
            out=root/f"{i:03d}.npz"
            assert all(np.isfinite(q).all()for q in (parents,wide,*gains.values()))
            with out.open("xb")as f:
                np.savez(f,baseline=parents,wide=wide,**{k:wide+val for k,val in gains.items()})
            records.append({"index":i,"input":captured["capture"],"prediction":reference(out)})
            print(i,round(time.monotonic()-timer,2),flush=True)
    write_json(ROOT/"restoration.json",{"driver":reference(__file__),"proposal":source,"checkpoint":plan["base"],
              "gain":GAIN,"rows":records,"seconds":time.monotonic()-timer})


if __name__=="__main__":
    run()
