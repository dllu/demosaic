"""Freeze photo fields with sharp periodic structure and exact absent-band controls."""
from collections import Counter
import hashlib
import importlib.util
import math
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/"query-contour-support-v1"
spec=importlib.util.spec_from_file_location("exact_targets",BASE/"prepare.py")
previous=importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
SEED=56811600651


def clean_targets(photo,geom):
    other,_,weak=previous.before.geometry.clean_targets(photo,geom)
    strong=other[2]
    n=torch.arange(512,dtype=photo.dtype)-255.5
    y,x=torch.meshgrid(n,n,indexing="ij")
    frame=torch.maximum(x.abs(),y.abs())
    vanish=((frame-104)/19).clamp(0,1)

    def angle(kind):
        fx,fy=geom[kind+"_frequency_xy"]
        bend=geom[kind+"_tangential_curvature_cycles_per_px2"]
        t=(-fy*x+fx*y)/math.hypot(fx,fy)
        phase=2*math.pi*(fx*x+fy*y+.5*bend*t*t)
        return phase+geom[kind+"_phase"]

    a,b=angle("strong"),angle("weak")
    p=(x*math.cos(geom["gap_angle"])+y*math.sin(geom["gap_angle"])-geom["offset"])/geom["envelope_width"]
    intact=torch.ones_like(x)
    env=intact if not geom["limited"] else .4+.6*((p+1)*.5).clamp(0,1)
    magnitude=geom["added_amplitude"]
    if geom["junction_kind"]=="interaction":
        extra=magnitude*a.cos()*b.cos()*env
        mark=(abs(a.cos())>=.7)&(abs(b.cos())>=.7)
    elif geom["junction_kind"]=="harmonics":
        extra=magnitude*(.60*(2*a).cos()+.40*(2*b).cos())*env
        mark=(abs(a.cos())>=.7)|(abs(b.cos())>=.7)
    else:
        extra=torch.zeros_like(a)
        mark=torch.ones_like(a,dtype=torch.bool)
    flat=((124-frame)/46).clamp(0,1)
    original=strong+weak
    core=original[:,192:320,192:320].mean((-1,-2),keepdim=True)
    quiet=torch.where(flat==1,core,torch.lerp(original+extra,core,flat))
    return (original+extra,original+extra*vanish,strong,quiet),mark.float(),extra


def run():
    lock=reference(ROOT.parent/"query-local-gap-v1"/"plan.json")
    trace=lock
    blocked=set()
    notes=[]
    while trace:
        item=read_json(checked(trace))
        blocked.update(r["source"]["id"]for r in item.get("sources",item.get("heldout_rows",[])))
        notes.append(trace)
        trace=next((item[k]for k in ("previous","curve_reference","preceding","comparison","prior","exclusion")if k in item),None)
    current=read_json(checked(lock))
    replay=read_json(ROOT.parent/"paired-repeat-stability-v2"/"evaluation-plan.json")
    blocked.update(q["source"]["id"]for q in replay["rows"])
    pool=read_json(checked(current["cohort"]))
    photos=[p for p in pool["source_metadata"]if p["split"]=="val" and p["bin_factor"]==4
            and min(p["shape"][:2])>=512 and np.prod(p["shape"][:2])<=4_000_000 and p["id"] not in blocked]
    photos.sort(key=lambda p:hashlib.sha256(f"{SEED}/{p['id']}".encode()).hexdigest())
    build=previous.before.geometry.fields
    build.ROOT,build.SEED,build.clean_targets=ROOT,SEED,clean_targets
    records=[]
    for i,p in enumerate(photos[:30]):
        box,=scene_crop_boxes(p["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"photo"))
        g=build.draw(i)
        generator=np.random.default_rng(scene_seed(SEED,i,"model"))
        strong=np.asarray(g["strong_frequency_xy"]); weak=np.asarray(g["weak_frequency_xy"])
        strong*=generator.uniform(.068,.115)/np.linalg.norm(strong)
        weak*=generator.uniform(.093,.150)/np.linalg.norm(weak)
        bend=.000034*(-1)**i if i%4==0 else 0.
        g.update({"junction_kind":("interaction","harmonics","pure")[i%3],
                  "strong_frequency_xy":strong.tolist(),"weak_frequency_xy":weak.tolist(),
                  "strong_tangential_curvature_cycles_per_px2":-.6*bend,"weak_tangential_curvature_cycles_per_px2":bend,
                  "weak_amplitude":float(generator.uniform(.0060,.010)),
                  "added_amplitude":float(generator.uniform(.0038,.0068))*((-1.)**(i//3)),
                  "limited":bool(i%2),"envelope_width":float(generator.uniform(12,29)),
                  "offset":float(generator.uniform(-28,28))})
        records.append(build.row_for(p,i,SEED)|{"box":box,"layout":g})
    assert Counter(x["layout"]["junction_kind"]for x in records)=={"interaction":10,"harmonics":10,"pure":10}
    write_json(ROOT/"plan.json",{
        **{k:current[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"sources":records,"previous":lock,"excluded":notes,"seed":SEED,
        "fit_indices":[],"test_indices":list(range(30)),
        "scope":"30 disjoint color photo fields. Ten interaction, ten second harmonic and ten pure-fundamental controls. Two ISO6400 redraws, each in four roles."})
    build.construct()


if __name__=="__main__":
    run()
