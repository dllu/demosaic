"""Publish inspected native crops and hash-bound perspective experiment evidence."""

import shutil
import tarfile
from pathlib import Path

from probe_shared_projective_phase import PANELS

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
review = root / "review"
slug = "shared-projective-phase-v1"
results = Path("docs/results") / slug
images = Path("docs/images") / slug
groups = {
    "standardized": root.parent / "shared-projective-phase-v1",
    "predictive": root.parent / "shared-projective-predictive-v1",
    "transfer": root,
}
synthetic = read_json(review / "fresh.json")
camera = read_json(review / "camera.json")["rows"]
archive_review = read_json(review / "archive.json")
sparse = read_json(root / "sparse-verification.json")
assert len(synthetic["boards"]) == 2 and len(camera) == 8 and len(sparse["rows"]) == 40
candidate_source = checked(sparse["tested"])
assert " passed" in (root / "tests-expanded.log").read_text()
results.mkdir()
images.mkdir()


def adopt(binding):
    source = checked(binding)
    target = images / source.name
    shutil.copyfile(source, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return target.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "review_date_local": "2026-11-17",
        "review_timezone": "America/Los_Angeles",
        "scope": "Two native synthetic GT triplets and their method boards, and eight native GFX crops. "
        "GFX references are independent qualitative captures.",
        "synthetic": [
            row | {k: row[k] | {"file": adopt(row[k]["image"])} for k in ("board", "triplet")}
            for row in synthetic["boards"]
        ],
        "camera": [row | {"file": adopt(row["image"])} for row in camera],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {
        "runs": {
            name: {"plan": reference(path / "plan.json")}
            | {p: reference(path / f"{p}.json") for p in PANELS}
            for name, path in groups.items()
        },
        "constructed": synthetic["scores"],
        "archived_ordinary_wires": {k: archive_review[k] for k in ("synthetic", "disjoint")},
        "forced_guide_nulls": read_json(review / "nulls.json"),
        "camera": [
            {k: row[k] for k in ("id", "ROI_xywh", "checkpoint", "noise", "RMS_from_V120_DN16")}
            for row in camera
        ],
        "sparse_selector_check": sparse,
        "new_checkpoint": None,
    },
)

sources = [
    "work/src/demosaic/donor_frequency_bank.py",
    "work/src/demosaic/shared_projective_phase.py",
    "work/scripts/probe_shared_projective_phase.py",
]
members = {
    f"{path.name}/{file}": path / file
    for path in groups.values()
    for file in ("plan.json", *sources, *(f"{p}.{ext}" for p in PANELS for ext in ("json", "log")))
}
extras = (
    "review.py",
    "publish.py",
    "verify_sparse.py",
    "sparse-verification.json",
    "verify-sparse.log",
    "tests-final.log",
    "tests-expanded.log",
    "review/archive.json",
    "review/camera.json",
    "review/fresh.json",
    "review/nulls.json",
)
members.update({f"{root.name}/{file}": root / file for file in extras})
for name in ("standardized", "predictive"):
    path = groups[name]
    members[f"{path.name}/tests.log"] = path / "tests.log"
members["sparse-src/shared_projective_phase.py"] = candidate_source
members["local-phase-bounds-v1/review.py"] = root.parent / "local-phase-bounds-v1/review.py"
members["matched-query-evidence-v1/structure_null.py"] = (
    root.parent / "matched-query-evidence-v1/structure_null.py"
)
archive = results / "evidence.tar.xz"
with tarfile.open(archive, "x:xz", preset=8) as bundle:
    for name, path in sorted(members.items()):
        metadata = bundle.gettarinfo(str(path), arcname=name)
        metadata.mtime = metadata.uid = metadata.gid = 0
        metadata.uname = metadata.gname = ""
        with path.open("rb") as stream:
            bundle.addfile(metadata, stream)
with tarfile.open(archive) as bundle:
    for item in bundle:
        assert bundle.extractfile(item).read() == members[item.name].read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": len(members),
        "comparisons_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
