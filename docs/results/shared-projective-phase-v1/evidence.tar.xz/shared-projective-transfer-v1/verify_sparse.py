"""Verify the reserve-only phase columns against the full-field implementation."""

import importlib.util
import time
from dataclasses import replace
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.shared_projective_phase import reserve_projective_phase

root = Path(__file__).resolve().parent
baseline_source = root / "work/src/demosaic/shared_projective_phase.py"
spec = importlib.util.spec_from_file_location(
    "demosaic.full_grid_projective_reference", baseline_source
)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
plan = read_json(root / "plan.json")
config = replace(LocalWaveConfig(**plan["config"]), background="screened_curved4_step")
prior_guides = read_json(checked(plan["previous"]))["camera"]
ref = read_json(checked(plan["camera_baseline"]))["camera"]
profile_by_id = {
    r["board"]["id"]: r["noise"] for r in read_json(checked(plan["camera_conditions"]))["camera"]
}
cases = []
for guide, source in zip(prior_guides, ref, strict=True):
    id = source["id"]
    assert guide["id"] == id
    query = guide["query"]
    x, y, w, h = source["source"]["query_box"]
    with np.load(checked(source["source"]["query_arrays"])) as f:
        packed, colors = (
            f["packed"][0, :, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2],
            f["colors"][0],
        )
    noise = profile_by_id[id]
    for g, geometry in guide["fits"].items():
        cases.append((f"{id}-{g}", packed, colors, query, geometry, noise))
old = root.parent / "shared-projective-predictive-v1"
for panel in ("projective400", "projective6400"):
    for row in read_json(old / f"{panel}.json")["rows"]:
        with np.load(checked(row["prediction"])) as f:
            cases.append(
                (
                    f"{panel}-{row['case']}",
                    f["packed"],
                    f["cfa"],
                    (512, 512, 256, 256),
                    row["guide"],
                    plan["profiles"][row["profile"]],
                )
            )
times = {"full": 0.0, "sparse": 0.0}
rows = []
for key, packed, colors, query, guide, noise in cases:
    observed = {}
    for name, fn in (
        ("full", prior.reserve_projective_phase),
        ("sparse", reserve_projective_phase),
    ):
        t = time.monotonic()
        observed[name] = fn(
            packed, colors, query, guide, shot=noise["shot"], read=noise["read"], config=config
        )
        times[name] += time.monotonic() - t
    (a, old_trace), (b, new_trace) = observed["full"], observed["sparse"]
    np.testing.assert_array_equal(a, b)
    assert old_trace == new_trace
    rows.append({"id": key, "accepted": [r["accepted"] for r in new_trace.get("directions", [])]})
assert len(rows) == 40
write_json(
    root / "sparse-verification.json",
    {
        "baseline": reference(baseline_source),
        "tested": reference(Path.cwd() / "src/demosaic/shared_projective_phase.py"),
        "producer": reference(__file__),
        "rows": rows,
        "CPU_wall_seconds": times,
    },
)
print(times, flush=True)
