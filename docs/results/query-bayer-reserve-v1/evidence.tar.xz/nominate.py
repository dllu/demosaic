"""Collect the reserved frequency proposals before creating any restorations."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from reserved import PREVIOUS,discover,distance,partition
from discover import propose

ROOT = Path(__file__).resolve().parent
CAPTURE = ("packed","variance","colors")
ROLES = ("present","outside-only","strong-only","quiet-query")


def read_capture(row):
    with np.load(checked(row["capture"]),allow_pickle=False)as f:
        arrays = {k:f[k]for k in CAPTURE}
    assert {k:fingerprint(v)for k,v in arrays.items()}=={k:row["fingerprints"][k]for k in CAPTURE}
    return arrays


def annotate(discovery,layout):
    for a in discovery["methods"].values():
        found = [p["frequency_xy"]for p in a["peaks"]]
        a["bin_distances"] = {k:(float(256*min(distance(f,layout[k+"_frequency_xy"])for f in found))if found else None)
                              for k in ("strong","weak")}
    return discovery


def source_proposals(job):
    (row,layout),old = job
    original = read_capture(row)
    pairs = []
    for r in range(2):
        for j,role in enumerate(ROLES):
            item = {k:v[r,j:j+1]for k,v in original.items()}
            exact = old["draws"][r*4+j]["methods"] if old else propose(item,128,128)
            ext = [p["frequency_xy"]for p in exact["prominence"]["proposals"]]
            query = [item[k][0,...,64:192,64:192]for k in CAPTURE[:2]]+[item["colors"][0]]
            found = annotate(discover(*query,ext),layout["layout"])
            pairs.append({"repeat":r,"role":role,**found,"exterior":ext})
    return {"index":row["index"],"capture":row["capture"],"draws":pairs}


def scenes(mode):
    old_binding = reference(PREVIOUS/"physical-proposals.json")
    previous = read_json(checked(old_binding))
    fields = previous["fields"] if mode=="replay" else reference(ROOT/"fields.json")
    source = read_json(checked(fields))
    plan = read_json(checked(source["plan"]))
    saved = previous["outputs"] if mode=="replay" else [None]*len(source["rows"])
    done = []
    jobs = zip(zip(source["rows"],plan["sources"],strict=True),saved,strict=True)
    with ThreadPoolExecutor(3)as pool:
        for i,out in enumerate(pool.map(source_proposals,jobs),1):
            done.append(out)
            print(f"{mode} {i}/{len(source['rows'])}",flush=True)
    write_json(ROOT/f"proposals-{mode}.json",{"driver":reference(__file__),"finder":reference(ROOT/"reserved.py"),
               "fields":fields,"old_exterior":old_binding,"rows":done})


def cameras():
    old_binding = reference(PREVIOUS/"standing-proposals.json")
    base = read_json(checked(old_binding))
    output = []
    for prior in base["rows"]:
        left,top,_,_ = prior["box"]
        roi = np.s_[0,...,top//2:top//2+128,left//2:left//2+128]
        with np.load(checked(prior["input"]),allow_pickle=False)as f:
            args = [f[k][roi].copy()for k in CAPTURE[:2]] + [f["colors"][0]]
        exterior = [p["frequency_xy"]for p in prior["methods"]["prominence"]["proposals"]]
        result = discover(*args,exterior)
        output.append({"id":prior["id"],"raw":prior["input"],"fit_xywh":prior["box"],**result})
        print(prior["id"],{k:[(r["frequency_xy"],r["origin"])for r in value["peaks"]]
                          for k,value in result["methods"].items()},flush=True)
        print("support",[(k,r["supports"])for k,r in result["methods"].items()],flush=True)
    write_json(ROOT/"proposals-camera.json",{"driver":reference(__file__),"finder":reference(ROOT/"reserved.py"),
               "upstream":old_binding,"rows":output})


if __name__=="__main__":
    if sys.argv[1]=="camera":
        cameras()
    else:
        scenes(sys.argv[1])
