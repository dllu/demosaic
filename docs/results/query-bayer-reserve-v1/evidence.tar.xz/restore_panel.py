"""Run the frozen reserved Bayer delivery on the exact replay and fresh fields."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from reserved import MODES,PREVIOUS,restore
from run_restore import ARGS,observations

ROOT = Path(__file__).resolve().parent
METHODS = ("outside-full",*MODES,"exact-half")


def group_lifts(args,parent,peaks):
    groups = {}
    out = torch.zeros_like(parent)
    for n,values in enumerate(peaks):
        key = tuple(tuple(f)for f in values)
        if len(key)==2:
            groups.setdefault(key,[]).append(n)
    for key,rows in groups.items():
        out[rows] = restore([v[rows]for v in args],parent[rows],key)
    return out


@torch.inference_mode()
def execute(mode):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    source = reference(ROOT/f"proposals-{mode}.json")
    proposed = read_json(checked(source))
    checked(proposed["finder"])
    inputs = read_json(checked(proposed["fields"]))
    plan = read_json(checked(inputs["plan"]))
    baseline = reference(PREVIOUS/"restorations.json" if mode == "replay" else ROOT/"fp32-first/predictions-fresh.json")
    original = read_json(checked(baseline))
    assert original["checkpoint"]==plan["base"]
    out = ROOT/f"restored-{mode}"
    out.mkdir(exist_ok=True)
    device = torch.device("cuda")
    saved = []
    start = time.monotonic()
    with ieee_fp32():
        for capture,nominations,source_record in zip(inputs["rows"],proposed["rows"],plan["sources"],strict=True):
            row = capture["index"]
            assert row==nominations["index"]==source_record["index"]
            assert capture["capture"]==nominations["capture"]
            target = out/f"{row:03d}.npz"
            if not target.exists():
                package = observations(capture)
                arguments = [torch.from_numpy(package[k].reshape((-1,*package[k].shape[2:]))).to(device)for k in ARGS]
                arguments[:2] = [v.contiguous(memory_format=torch.channels_last)for v in arguments[:2]]
                item = original["cases" if mode=="replay" else "rows"][row]
                assert item["index"]==row
                named = item["output"]
                archived = named if mode=="replay" else named|{"path":str(ROOT/"fp32-first/restored-fresh"/Path(named["path"]).name)}
                with np.load(checked(archived),allow_pickle=False)as f:
                    neutral,external = f["baseline"],f["prominence" if mode=="replay" else "outside-full"]
                base = torch.from_numpy(neutral.reshape(-1,3,256,256)).to(device)
                record = {"baseline":neutral,"outside-full":external}
                geometry = source_record["layout"]
                oracle = tuple(geometry[k+"_frequency_xy"]for k in ("strong","weak"))
                for label in (*MODES,"exact-half"):
                    peaks = [
                        oracle if label=="exact-half" else
                        [p["frequency_xy"]for p in d["methods"][label]["peaks"]]
                        for d in nominations["draws"]
                    ]
                    answer = group_lifts(arguments,base,peaks)
                    record[label] = answer.cpu().numpy().reshape(2,4,3,256,256)
                temp = target.with_suffix(".incomplete")
                with temp.open("wb")as f:
                    np.savez(f,**record)
                temp.rename(target)
            saved.append({"index":row,"output":reference(target)})
            print(mode,len(saved),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/f"predictions-{mode}.json",{
        "driver":reference(__file__),"nominations":source,"reuse_baseline":baseline,"mode":mode,
        "checkpoint":plan["base"],"rows":saved,"seconds":time.monotonic()-start})


if __name__=="__main__":
    execute(sys.argv[1])
