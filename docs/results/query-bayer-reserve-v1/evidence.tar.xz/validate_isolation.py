"""Intervene on reserved sample sets and audit the previous cab frequency measurements."""
import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from reserved import discover,distance,partition,restore

ROOT = Path(__file__).resolve().parent


def bind_fresh():
    guesses = reference(ROOT/"proposals-fresh.json")
    forecast = reference(ROOT/"predictions-fresh.json")
    options = read_json(checked(guesses))
    proposals = read_json(checked(forecast))
    assert proposals["nominations"]==guesses
    captures = read_json(checked(options["fields"]))
    plan = read_json(checked(captures["plan"]))
    train = read_json(ROOT.parent/"scene-full-epoch-v1/plan.json")["train_manifest"]
    with checked(train).open()as stream:
        photos = {json.loads(l)["id"]for l in stream}
    check = {r["source"]["id"]for r in plan["sources"]}
    assert len(check)==16 and not check.intersection(photos)
    return options,proposals,captures,train


@torch.inference_mode()
def splits():
    options,predictions,captures,train = bind_fresh()
    rng = np.random.default_rng(8125025)
    low = partition()<2
    tests = []
    with ieee_fp32():
        for row,pred,f in zip(options["rows"],predictions["rows"],captures["rows"],strict=True):
            options = row["draws"][0]
            peaks = [r["frequency_xy"]for r in options["methods"]["combined"]["peaks"]]
            if len(peaks)!=2:
                continue
            with np.load(checked(f["capture"]),allow_pickle=False)as stream:
                packed,variance = (stream[k][0,0,:,64:192,64:192].copy()for k in ("packed","variance"))
                colors,wb,matrix = (stream[k][0,0].copy()for k in ("colors","wb","matrix"))
            with np.load(checked(pred["output"]),allow_pickle=False)as stream:
                parent = stream["baseline"][0,0].copy()
                orig = stream["combined"][0,0].copy()
            assert float(np.abs(orig).max()) > 0
            discovery_a = discover(packed,variance,colors,options["exterior"])
            changed = [a.copy()for a in (packed,variance)]
            for data in changed:
                data[:,~low] = rng.uniform(.1,.9,(4,int((~low).sum()))).astype(np.float32)
            discovery_b = discover(*changed,colors,options["exterior"])
            assert discovery_a==discovery_b
            for key in ("outside-half","reserved","combined"):
                expected = {k:v for k,v in options["methods"][key].items()if k!="bin_distances"}
                assert discovery_a["methods"][key]==expected

            def output(packed,variance):
                args = [torch.from_numpy(i[None])for i in (packed,variance,colors,wb,matrix)]
                return restore(args,torch.from_numpy(parent[None]),peaks).numpy()[0]

            nominal = output(packed,variance)
            replaced = [a.copy()for a in (packed,variance)]
            for data in replaced:
                data[:,low] = rng.uniform(.1,.9,(4,int(low.sum()))).astype(np.float32)
            np.testing.assert_array_equal(output(*replaced),nominal)
            np.testing.assert_allclose(nominal,orig,rtol=0,atol=4e-6)
            tests.append({"source_index":row["index"],"query_cells_swapped_each_intervention":int(low.sum()),
                          "candidate_lists_equal":True,"delivery_equal_with_fixed_parent_and_frequencies":True,
                          "saved_CUDA_and_CPU_max_difference":float(np.abs(orig-nominal).max())})
            if len(tests)==6:
                break
    assert len(tests)>=3
    return {"cases":tests,"fresh_overlap_with_full_epoch_training":0,"training_manifest":train,
            "scope":"Frequency nominations exclude groups 2 and 3. The analytic correction excludes groups 0 and 1 with fixed peaks and fixed parent. Corpus 100k parent itself sees all groups."}


def camera():
    earlier = reference("docs/results/green-phase-cross-spectrum-v1.json")
    measured = read_json(checked(earlier))["executed_result"]["cases"]
    proposal = reference(ROOT/"proposals-camera.json")
    known = read_json(checked(proposal))
    audit = []
    for row in known["rows"]:
        if not row["id"].startswith("mesh"):
            continue
        side = row["id"].split("-")[-1]
        prior = next(r for r in measured if r["name"]==side)
        assert prior["context_xywh"]==row["fit_xywh"]
        both = [p["native_frequency_xy"]for p in prior["peaks"]if "absolute_cross" in p["selected_by"]][:2]
        results = {}
        for name,item in row["methods"].items():
            results[name] = [min((256*distance(f,p["frequency_xy"])for p in item["peaks"]),default=None)for f in both]
        audit.append({"id":row["id"],"earlier_input_only_frequencies_xy":both,
                     "nearest_distances_in_query_bins":results})
    return {"earlier_measurement":earlier,"proposal":proposal,"rows":audit}


if __name__=="__main__":
    torch.set_num_threads(2)
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"isolation":splits(),"camera":camera()})
