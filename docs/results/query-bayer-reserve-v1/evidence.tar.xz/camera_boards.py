"""Render both standing GFX families with the calibrated reserved search."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from restore_panel import ARGS,MODES,PREVIOUS,restore
from run_restore import correction

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

LABEL = {
    "outside-full":"Exterior peaks, full fit","outside-half":"Exterior peaks, half fit",
    "reserved":"Reserved query peaks","combined":"Query and exterior peaks",
}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    nominate = reference(ROOT/"proposals-camera.json")
    candidates = read_json(checked(nominate))
    checked(candidates["finder"])
    older = read_json(checked(candidates["upstream"]))
    inputs = read_json(checked(older["upstream"]))
    baseline = read_json(checked(inputs["display_parent_boards"]))
    lookup = {r["id"]:r for r in inputs["rows"]}
    proposals = {r["id"]:r for r in candidates["rows"]}
    score = reference(ROOT/"scores.json")
    metric = read_json(checked(score))
    scale = metric["scales"]
    previous = read_json(PREVIOUS/"standing/manifest.json")
    destination = ROOT/"standing"
    destination.mkdir(exist_ok=True)
    views = []
    with ieee_fp32():
        for region in baseline["boards"]:
            key = region["id"]
            if key not in proposals:
                continue
            p = proposals[key]
            old = lookup[region["observation"]]
            source = p["raw"]
            assert source==old["raw"]["arrays"]==region["input_arrays"]
            with np.load(checked(source),allow_pickle=False)as f:
                data = {k:f[k]for k in ARGS}
            assert {k:fingerprint(a)for k,a in data.items()}==old["inputs"]
            left,top,_,_ = p["fit_xywh"]
            x,y,w,h = region["case"]["ROI_xywh"]
            roi = (x-left,y-top,w,h)
            core = np.s_[...,top:top+256,left:left+256]
            px = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            parent = torch.from_numpy(np.load(checked(old["parent"]),allow_pickle=False)[core].copy())
            args = [torch.from_numpy(data[k][px].copy()if k in ("packed","variance")else data[k])for k in ARGS]
            wb,matrix = args[-2:]
            with Image.open(checked(region["image"]))as original:
                paper = np.asarray(original.convert("RGB"))
            inherited = {panel["label"]:paper[b:b+d,a:a+c]for panel in region["panels"]
                         for a,b,c,d in (panel["png_xywh"],)}
            for_comparison = [(k,inherited[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")
                              if k in inherited]
            base = display_crop(parent,wb,matrix,roi,exposure=region["display_exposure"])
            decoded = np.rint(base*255).astype(np.uint8)
            np.testing.assert_array_equal(decoded,inherited["Parent 100k EMA"])
            x0,y0,xw,yh = roi
            window = np.s_[...,y0:y0+yh,x0:x0+xw]
            matrices = {}
            changes = {}
            for mode in ("outside-full",*MODES):
                chooser = "outside-half" if mode=="outside-full" else mode
                peaks = [f["frequency_xy"]for f in p["methods"][chooser]["peaks"]]
                resolver = correction if mode=="outside-full" else restore
                delivered = parent+scale[mode]*resolver(args,parent,peaks)
                view = display_crop(delivered,wb,matrix,roi,exposure=region["display_exposure"])
                pixels = np.rint(view*255).astype(np.uint8)
                for_comparison.append((LABEL[mode],pixels))
                d = (delivered-parent)[window].numpy().astype(float)
                changes[mode] = {"RGB_RMS_DN16":float(np.sqrt((d**2).mean())*65535),
                                 "display_values_changed":int(np.count_nonzero(pixels!=decoded))}
                matrices[mode] = delivered.numpy()
            for_comparison += [(k,inherited[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in inherited]
            bindings = native_png(destination/(key+".png"),for_comparison)
            path = destination/(key+".npz")
            with path.open("wb")as f:
                np.savez(f,parent=parent.numpy(),**matrices)
            views.append(bindings|{"id":key,"restorations":reference(path),"input":source,"baseline":old["parent"],
                         "inherited_display":region["image"],"fit_window_xywh":p["fit_xywh"],"case":region["case"],
                         "exposure":region["display_exposure"],"noise":region["noise"],"reference_role":region["reference_role"],
                         "frequencies":p["methods"],"change":changes})
            print(key,{k:round(v["RGB_RMS_DN16"],4)for k,v in changes.items()},flush=True)
    assert len(views)==8
    write_json(destination/"manifest.json",{
        "driver":reference(__file__),"score":score,"proposal_source":nominate,
        "parent":previous["checkpoint"],"rows":views})


if __name__=="__main__":
    main()
