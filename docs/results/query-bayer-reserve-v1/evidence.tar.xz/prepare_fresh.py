"""Freeze an independent set of ISO6400 fields for the reserved Bayer search."""
import hashlib
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent/"donor-peak-prominence-v1"
sys.path.insert(0,str(PREVIOUS))
import prepare_fields as material

SEED = 841590122303
COUNT = 16


def prepare():
    previous = reference(PREVIOUS/"plan.json")
    old = read_json(checked(previous))
    earlier = read_json(checked(old["prior"]))
    study = read_json(checked(earlier["exclusion"]))
    cohort = read_json(checked(old["cohort"]))
    repeat = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    used = {r["source"]["id"]for r in [*old["sources"],*earlier["sources"],*study["heldout_rows"],*repeat["rows"]]}
    available = [r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
                 and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in used]
    ranked = sorted(available,key=lambda r:hashlib.sha256(f'{SEED}/{r["id"]}'.encode()).hexdigest())
    material.ROOT = ROOT
    material.SEED = SEED
    rows = []
    for i,p in enumerate(ranked[:COUNT]):
        box, = scene_crop_boxes(p["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"new outer box"))
        rows.append(material.row_for(p,i,SEED)|{"box":box,"layout":material.draw(i)})
    assert len({r["source"]["id"]for r in rows})==COUNT
    write_json(ROOT/"plan.json",{
        **{k:old[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"generator":reference(PREVIOUS/"prepare_fields.py"),"comparison":previous,
        "sources":rows,"seed":SEED,"fit_indices":[],"test_indices":list(range(COUNT)),
        "scope":"16 fresh photographic backgrounds, carrier frequencies, interruption footprints and independent noisy observations using the previous four-role simulator. No calibration on these cases."})
    material.construct()


if __name__=="__main__":
    prepare()
