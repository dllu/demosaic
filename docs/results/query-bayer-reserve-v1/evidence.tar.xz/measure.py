"""Calibrate once on the archival fit split and evaluate the complete fresh split."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from restore_panel import METHODS,PREVIOUS,MODES,observations
import score_panel as prior_metrics

ROOT = Path(__file__).resolve().parent
prior_metrics.METHODS = METHODS
ALL = ("baseline",*METHODS)


def bind(mode):
    source = reference(ROOT/f"predictions-{mode}.json")
    predictions = read_json(checked(source))
    selections = read_json(checked(predictions["nominations"]))
    material = read_json(checked(selections["fields"]))
    plan = read_json(checked(material["plan"]))
    return source,predictions,selections,material,plan


def read_rows(mode):
    source,restorations,proposals,material,plan = bind(mode)
    rows = []
    for capture,restored,selected,details in zip(material["rows"],restorations["rows"],proposals["rows"],plan["sources"],strict=True):
        i = capture["index"]
        assert i==restored["index"]==selected["index"]==details["index"]
        assert capture["capture"]==selected["capture"]
        data = prior_metrics.analyze(capture,restored)
        rows.append((i,details["source"]["id"],selected,data))
    return source,plan,rows


def summarize(rows):
    rng = np.random.default_rng(5882401985)
    idx = rng.integers(len(rows),size=(10000,len(rows)))
    output = {}
    pairs = (("combined","outside-full"),("combined","outside-half"),("combined","reserved"),
             ("combined","baseline"),("reserved","outside-half"),("exact-half","combined"))
    for key in prior_metrics.METRICS:
        vectors = {k:np.array([r["metrics"][k][key]for r in rows])for k in ALL}
        comparisons = {}
        for a,b in pairs:
            change = vectors[a]-vectors[b]
            lo,hi = np.quantile(change[idx].mean(-1),(.025,.975))
            comparisons[f"{a}_vs_{b}"] = [float(change.mean()),float(lo),float(hi)]
        output[key] = {"means":{k:float(v.mean())for k,v in vectors.items()},"paired_diff_95pct":comparisons}
    return output


def nominations(cases):
    counts = {}
    for role in ("present","outside-only","strong-only","quiet-query"):
        counts[role] = {}
        for method in MODES:
            pieces = [r["methods"][method]for _,_,field,_ in cases for r in field["draws"]if r["role"]==role]
            hits = []
            for bound in (1,2,3):
                for p in pieces:
                    assert p["bin_distances"].keys()=={"strong","weak"}
                hit = [{k:v is not None and v<=bound for k,v in p["bin_distances"].items()}for p in pieces]
                hits.append({"query_bins":bound,"strong":sum(r["strong"]for r in hit),
                             "weak":sum(r["weak"]for r in hit),"both":sum(all(r.values())for r in hit)})
            counts[role][method] = {"draws":len(pieces),"pairs":sum(len(r["peaks"])==2 for r in pieces),
                                     "one_exterior":sum(any(p["origin"]=="exterior prominence"for p in r["peaks"])for r in pieces),
                                     "hits":hits}
    return counts


def main():
    replay_ref,replay_plan,replay = read_rows("replay")
    fresh_ref,fresh_plan,fresh = read_rows("fresh")
    assert not {row[1]for row in replay}.intersection(row[1]for row in fresh)
    assert not fresh_plan["fit_indices"]
    calibrate = [r for r in replay if r[0] in replay_plan["fit_indices"]]
    heldout = [r for r in replay if r[0] in replay_plan["test_indices"]]
    budget_ref = reference(PREVIOUS/"gap-budget.json")
    prior = read_json(checked(budget_ref))
    limits = prior["limits"]
    calibration = {key:{method:float(np.mean([prior_metrics.values(r[-1],method,1)[key]
                  for r in calibrate]))for method in METHODS}for key in limits}
    scales = {name:min([1.0,*(limits[k]/r[name]for k,r in calibration.items()if r[name]>0)])for name in METHODS}
    assert abs(scales["outside-full"]-prior["scales"]["prominence"])<1e-12

    def metrics(cases, scale):
        return [{"index":q,"id":photo,"metrics":{k:prior_metrics.values(data,k,scale.get(k,1))for k in ALL}}
                for q,photo,_,data in cases]

    arms = {}
    for name,cases in (("replay",heldout),("fresh",fresh)):
        matched,original = metrics(cases,scales),metrics(cases,{})
        arms[name] = {"nominations":nominations(cases),"matched":summarize(matched),
                      "nominal":summarize(original),"matched_rows":matched,"nominal_rows":original}
    write_json(ROOT/"scores.json",{
        "driver":reference(__file__),"replay_predictions":replay_ref,"fresh_predictions":fresh_ref,
        "budget_source":budget_ref,"limits":limits,"scales":scales,"fit_metrics_nominal":calibration,
        "calibration_rows":metrics(calibrate,{}),**arms})
    print("scales",scales,flush=True)


def render():
    torch.set_num_threads(2)
    score_ref = reference(ROOT/"scores.json")
    info = read_json(checked(score_ref))
    source,predictions,_,material,plan = bind("fresh")
    assert source==info["fresh_predictions"]
    view = ROOT/"native"
    view.mkdir(exist_ok=True)
    result = []
    for shape in ("stripe","ellipse"):
        row = next(r for r in plan["sources"]if r["layout"]["shape"]==shape)
        i = row["index"]
        raw = material["rows"][i]
        rec = predictions["rows"][i]
        camera = observations(raw)
        with np.load(checked(rec["output"]),allow_pickle=False)as f:
            base = f["baseline"][0]
            methods = {"baseline":base,**{m:base+info["scales"][m]*f[m][0]for m in METHODS}}
        noisy = malvar(torch.from_numpy(camera["packed"][0]),torch.from_numpy(camera["colors"][0])).numpy()
        all_images = methods|{"noisy":noisy,"GT":camera["target"][0]}
        meta = {k:camera[k][0]for k in ("wb","matrix")}
        converted = {
            n:np.rint(display(v,meta,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
            for n,v in all_images.items()
        }
        for role,number in (("present",0),("outside-only",1),("quiet-query",3)):
            styles = [("all",(*ALL,"GT"))]
            if role=="present":
                styles.append(("triplet",("noisy","combined","GT")))
            for style,ordering in styles:
                image = np.concatenate([converted[o][number]for o in ordering],axis=1)
                assert image.shape==(160,160*len(ordering),3)
                dest = view/f"{i:03d}-{role}-{style}.png"
                Image.fromarray(image).save(dest,optimize=True)
                result.append({"image":reference(dest),"source_index":i,"source":row["source"],"source_box":row["box"],
                               "capture":raw,"linear_output":rec,"native_query_ROI_xywh":[48,48,160,160],
                               "role":role,"repeat":0,"profile":plan["profile"],"CFA":row["camera"]["pattern"],
                               "windows":{"query":plan["query_box"],"display":2},"pane_modes":ordering})
    write_json(view/"manifest.json",{"scores":score_ref,"driver":reference(__file__),"parent":plan["base"],
            "transform":"common sensor WB and matrix, exposure ×2, clipped sRGB8","rows":result})


if __name__=="__main__":
    main()
    render()
