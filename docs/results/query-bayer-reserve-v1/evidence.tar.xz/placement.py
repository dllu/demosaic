"""Measure query-only Bayer nominations after changing the crop origin."""
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from reserved import discover,distance

ROOT = Path(__file__).resolve().parent
OFFSETS = ((0,0),(-8,0),(8,0),(0,-8),(0,8),(-16,-16),(-16,16),(16,-16),(16,16))


def run():
    input_ref = reference(ROOT/"proposals-camera.json")
    data = read_json(checked(input_ref))
    prior_ref = reference("docs/results/green-phase-cross-spectrum-v1.json")
    measured = read_json(checked(prior_ref))["executed_result"]["cases"]
    outputs = []
    for field in data["rows"]:
        if "mesh-" not in field["id"] and "sky" not in field["id"]:
            continue
        with np.load(checked(field["raw"]),allow_pickle=False)as captured:
            packed,variance,colors = (captured[k][0].copy()for k in ("packed","variance","colors"))
        center = [p["frequency_xy"]for p in field["methods"]["reserved"]["peaks"]]
        x,y,_,_ = field["fit_xywh"]
        point = []
        ref = None
        if field["id"].startswith("mesh"):
            side = field["id"].split("-")[-1]
            p = next(r for r in measured if r["name"]==side)
            ref = [v["native_frequency_xy"]for v in p["peaks"]if "absolute_cross" in v["selected_by"]][:2]
        for dx,dy in OFFSETS:
            a,b = x+dx,y+dy
            roi = np.s_[...,b//2:b//2+128,a//2:a//2+128]
            outcome = discover(packed[roi],variance[roi],colors,[])["methods"]["reserved"]
            found = [v["frequency_xy"]for v in outcome["peaks"]]
            if not (dx or dy):
                assert found==center
            near = None if ref is None else [
                min((256*distance(a,b)for b in found),default=None)for a in ref
            ]
            point.append({"native_shift_xy":[dx,dy],"discovery":outcome,"distances_in_query_bins":near})
        print(field["id"],sum(len(r["discovery"]["peaks"])==2 for r in point),
              sum(all(x is not None and x<=1 for x in (r["distances_in_query_bins"]or [None]))for r in point),
              flush=True)
        outputs.append({"id":field["id"],"earlier_measurement_frequencies_xy":ref,"placements":point})
    write_json(ROOT/"placement.json",{"driver":reference(__file__),"proposals":input_ref,"prior":prior_ref,
          "scope":"Query-only frequency nominations at nine fixed even offsets, ignoring exterior proposals. Each crop receives its original relative Bayer partition. Measures sensitivity to crop position and sample assignment together.","rows":outputs})


if __name__=="__main__":
    run()
