"""Publish the reserved-portable solver, measured results, and viewed native evidence."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
RESULTS = Path("docs/results/query-bayer-reserve-v1")
IMAGES = Path("docs/images/query-bayer-reserve-v1")


def copy_image(item,scope,windows):
    source = checked(item)
    target = IMAGES/scope/source.name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert reference(target)["sha256"]==item["sha256"]
    with Image.open(target)as f:
        for x,y,w,h in windows:
            assert w==h==160 and x+w<=f.width and y+h<=f.height
        f.verify()
    return {"path":str(target),"sha256":item["sha256"]}


def main():
    RESULTS.mkdir(exist_ok=True)
    score_ref = reference(ROOT/"scores.json")
    score = read_json(checked(score_ref))
    verification = reference(ROOT/"verification.json")
    audit = read_json(checked(verification))
    assert len(audit["isolation"]["cases"])==6
    placement = reference(ROOT/"placement.json")
    spot = read_json(checked(placement))
    exact = read_json(ROOT/"native/manifest.json")
    standing = read_json(ROOT/"standing/manifest.json")
    assert exact["scores"]==standing["score"]==score_ref
    assert exact["parent"]==standing["parent"]
    assert standing["proposal_source"]==audit["camera"]["proposal"]==spot["proposals"]
    for row in exact["rows"]:
        order = row["pane_modes"]
        row["image"] = copy_image(row["image"],"exact",[(160*i,0,160,160)for i,_ in enumerate(order)])
        row["viewing"] = {
            (0,"present"):"The strong diagonals stay visible across the bars and the finer carrier is faint. The exact target has more modulation.",
            (2,"present"):"Both directions are visible over the darker background; the exact target has clearer, more even crossings.",
            (0,"outside-only"):"Mostly the strong diagonals remain in the interior.",
            (2,"outside-only"):"The strong carrier remains visible and a second crossing family is absent from the central region.",
            (0,"quiet-query"):"The scored exact-flat core remains smooth.",
            (2,"quiet-query"):"The checked branches reproduce the parent. Faint angled structure near the bottom appears in the parent or exterior-only branches.",
        }[(row["source_index"],row["role"])]
    for row in standing["rows"]:
        row["image"] = copy_image(row["image"],"standing",[p["png_xywh"]for p in row["panels"]])
        key = row["id"]
        if key.endswith("fine-green-mesh-right"):
            note = "Both diagonal directions are clearer after the automatic query proposals. Some intersections are soft or discontinuous and side coverage is uneven."
        elif key.endswith("fine-green-mesh-left"):
            note = "The checked query methods return the 100k parent. The soft diagonals and background texture remain."
        elif "sky" in key:
            note = "The sky matches the parent pixel for pixel."
        elif "building" in key:
            note = "Long edges and thicker wires remain, with the finest cables soft. The two query banks differ slightly in the building region."
        elif "foliage" in key:
            note = "The checked query methods return the parent. Small leaf boundaries remain soft."
        else:
            note = "Both crossing directions remain clear; the localized query fit adds a small modulation with the same coarse pattern."
        row["viewing"] = note
    assert len(exact["rows"])==len(standing["rows"])==8
    manifest = IMAGES/"manifest.json"
    write_json(manifest,{"exact":exact,"standing":standing,"actual_native_viewing_complete":True})
    archive = RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for k in (
            "prepare_fresh.py","reserved.py","nominate.py","restore_panel.py","measure.py","camera_boards.py",
            "validate_isolation.py","placement.py","publish.py","plan.json","fields.json",
            "proposals-replay.json","proposals-fresh.json","proposals-camera.json","predictions-replay.json",
            "predictions-fresh.json","scores.json","verification.json","placement.json","native/manifest.json",
            "standing/manifest.json","prepare.log","camera.log","camera-final.log","camera-final2.log",
            "replay-final.log","fresh-final.log","restore-replay.log","restore-fresh.log","measure.log",
            "verify.log","placement.log","render-cameras.log","fp32-first/reserved.py","fp32-first/restore_panel.py",
            "fp32-first/predictions-fresh.json","fp32-first/predictions-replay.json","fp32-first/scores.json",
            "fp32-first/verify.log",
        ):
            f.add(ROOT/k,arcname=k)
    write_json(RESULTS/"publication.json",{
        "experiment":"query-bayer-reserve-v1","training_performed":False,
        "numeric_evaluation_complete":True,"actual_native_viewing_complete":True,"parent":standing["parent"],
        "manifest":reference(manifest),"archive":reference(archive),"score_ref":score_ref,"audit":audit,
        "scales":score["scales"],"matched_calibration_limits":score["limits"],
        "fresh_scores":{k:score["fresh"][k]for k in ("nominal","matched","nominations")},
        "replay_scores":{k:score["replay"][k]for k in ("nominal","matched","nominations")},
        "placement_summary":{r["id"]:{
            "tested":len(r["placements"]),
            "pairs":sum(len(x["discovery"]["peaks"])==2 for x in r["placements"]),
            "both_within_query_bin":sum(all(v is not None and v<=1 for v in (x["distances_in_query_bins"]or [None])) for x in r["placements"]),
        }for r in spot["rows"]},
        "scope":"Scoped inference replay, fresh held-out four-role photo crops, and eight standing GFX100S boards. No registration of an endpoint on the canonical full427 or measured camera panels.",
    })


if __name__=="__main__":
    main()
