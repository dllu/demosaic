"""Find green carriers on two reserved CFA subsets, then deliver on two others."""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter,map_coordinates,maximum_filter,uniform_filter
import torch

ROOT = Path(__file__).resolve().parent
PILOT = ROOT.parent/"green-gap-validation-v1"
PREVIOUS = ROOT.parent/"donor-peak-prominence-v1"
sys.path[:0] = [str(PREVIOUS),str(PILOT)]
from resolve import amplitude,lift,solve

MODES = ("outside-half","reserved","combined")
SIZE = 256
GRID = 16
NFFT = 256
BANDS = (.055,.080,.110,.155,.22)


@lru_cache(maxsize=1)
def partition():
    """One independently permuted group per fold in every four packed Bayer cells."""
    rng = np.random.default_rng(411935)
    leading = np.argsort(rng.random((64,64,4)),axis=2)
    folds = leading.reshape(64,64,2,2).transpose(0,2,1,3).reshape(128,128)
    assert [int((folds==k).sum())for k in range(4)]==[4096]*4
    return folds


def green_records(packed,variance,colors):
    colors = np.asarray(colors)
    selected = np.flatnonzero(colors==1)
    mask = partition()==0
    near = gaussian_filter(mask.astype(float),3.5,mode="reflect")
    assert near.min()>.03
    records = []
    for phase in selected:
        raw = packed[phase].astype(float)
        var = variance[phase].astype(float)
        # Selection uses a common background and weights built only from fold zero.
        observed = np.where(mask,raw,0)
        guide = gaussian_filter(observed,3.5,mode="reflect")/near
        proxy = gaussian_filter(np.where(mask,var,0),5,mode="reflect")
        norm = gaussian_filter(mask.astype(float),5,mode="reflect")
        noise = (proxy/norm).clip(min=1e-10)
        records.append((phase,raw-guide,noise))
    return records


@lru_cache(maxsize=1)
def spectral_geometry():
    grid = np.fft.fftfreq(NFFT)/2
    fy,fx = np.meshgrid(grid,grid,indexing="ij")
    radius = np.hypot(fx,fy)
    half = (fx>0)|((fx==0)&(fy>0))
    direction = np.stack((fy,fx))/radius.clip(min=1e-12)
    sides = [((np.stack((fy,fx))+ds*direction)*2*NFFT)%NFFT for ds in (-.018,.018)]
    hanning = np.hanning(128)
    window = hanning[:,None]*hanning[None,:]
    return fy,fx,radius,half,sides,window


def distance(f,g):
    a,b = np.asarray(f),np.asarray(g)
    return min(np.linalg.norm(a-b),np.linalg.norm(a+b))


def surface(records):
    fy,fx,_,_,_,window = spectral_geometry()
    a,b = [
        np.fft.fft2(np.where(partition()==0,signal*window,0),s=(NFFT,NFFT))
        * np.exp(-2j*np.pi*((phase%2)*fx+(phase//2)*fy))
        / np.sqrt(np.where(partition()==0,variance*window**2,0).sum())
        for phase,signal,variance in records
    ]
    cross = uniform_filter((a*b.conj()).real,3,mode="wrap")
    strength = [uniform_filter(np.abs(s)**2,3,mode="wrap")for s in (a,b)]
    coherence = cross/(strength[0]*strength[1]).clip(min=1e-20)**.5
    return cross,coherence


def local_bank(records):
    cross,coherence = surface(records)
    fy,fx,radius,half,sides,_ = spectral_geometry()
    side = [map_coordinates(cross,t,order=1,prefilter=False,mode="grid-wrap")for t in sides]
    background = np.maximum(1,np.maximum(*side))
    score = (cross-background)/(1.5+background)
    candidates = []
    maxima = score==maximum_filter(score,5,mode="wrap")
    valid = half&maxima&(cross>3)&(coherence>.55)&(score>.65)
    for low,high in zip(BANDS[:-1],BANDS[1:],strict=True):
        eligible = valid & (radius>=low) & (radius<high)
        values = np.argwhere(eligible)[np.argsort(score[eligible],kind="stable")[::-1]]
        span = 0
        for y,x in values:
            chosen = [float(fx[y,x]),float(fy[y,x])]
            if any(distance(chosen,r["frequency_xy"])<.007 for r in candidates):
                continue
            candidates.append({"frequency_xy":chosen,"origin":"reserve spectrum","score":float(score[y,x])})
            span += 1
            if span == 3:
                break
    return candidates


def moments(records,bank):
    y,x = np.indices((128,128))
    axis = np.arange(128)-63.5
    taper = np.exp(-(axis[:,None]**2+axis[None]**2)/(2*48**2))
    arrays = []
    for tag in (0,1):
        selected = partition()==tag
        parts = []
        for phase,signal,variance in records:
            cols = []
            for peak in bank:
                a,b = peak["frequency_xy"]
                angle = 2*np.pi*(a*(2*x[selected]+phase%2)+b*(2*y[selected]+phase//2))
                cols.extend((np.cos(angle),np.sin(angle)))
            weight = (taper[selected]/variance[selected])**.5
            parts.append((np.column_stack(cols)*weight[:,None],signal[selected]*weight))
        matrix = np.concatenate([m for m,_ in parts])
        vector = np.concatenate([v for _,v in parts])
        arrays.append((matrix.T@matrix,matrix.T@vector))
    return arrays


def conditional_pair(records,bank):
    if len(bank)<2:
        return {"peaks":[],"supports":[],"bank_size":len(bank)}
    (fit,source),(check,witness) = moments(records,bank)
    chosen = []
    for i,j in combinations(range(len(bank)),2):
        first,second = [np.asarray(bank[k]["frequency_xy"])for k in (i,j)]
        separation = abs(first[0]*second[1]-first[1]*second[0])/(np.linalg.norm(first)*np.linalg.norm(second))
        if separation < .35:
            continue
        columns = [2*i,2*i+1,2*j,2*j+1]
        pos = np.ix_(columns,columns)
        train = fit[pos]
        measured = source[columns]
        hold = check[pos]
        h = witness[columns]
        beta = np.linalg.solve(train,measured)
        gains = []
        for omit,keep in ((i,slice(2,4)),(j,slice(0,2))):
            reduced = np.zeros(4)
            reduced[keep] = np.linalg.solve(train[keep,keep],measured[keep])
            delta = beta-reduced
            norm = np.sqrt(max(1e-20,delta@hold@delta))
            gains.append(float((2*delta@h+reduced@hold@reduced-beta@hold@beta)/(2*norm)))
        if min(gains)>=2.75:
            chosen.append((sum(gains),min(gains),i,j,gains))
    if not chosen:
        return {"peaks":[],"supports":[],"bank_size":len(bank)}
    _,_,i,j,gains = max(chosen)
    return {"peaks":[bank[i],bank[j]],"supports":gains,"bank_size":len(bank)}


def discover(packed,variance,colors,exterior):
    records = green_records(packed,variance,colors)
    local = local_bank(records)
    outside = [{"frequency_xy":p,"origin":"exterior prominence"}for p in exterior]
    union = local+[r for r in outside if all(distance(r["frequency_xy"],b["frequency_xy"])>.004 for b in local)]
    return {
        "local_bank":local,
        "methods":{
            "outside-half":{"peaks":outside,"supports":[],"bank_size":len(outside)},
            "reserved":conditional_pair(records,local),
            "combined":conditional_pair(records,union),
        },
    }


def delivery_fits(packed,variance,colors,parent,signal,competitor):
    device = packed.device
    green = torch.where(colors[0]==1)[0]
    row,col = torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    yy = (2*row+green[:,None,None]//2).flatten()
    xx = (2*col+green[:,None,None]%2).flatten()
    folds = torch.from_numpy(partition()).to(device).expand(2,-1,-1).flatten()
    sign = torch.stack((torch.ones_like(row),-torch.ones_like(row))).flatten()
    values = torch.cat((packed[:,green].flatten(1),parent[:,1,yy,xx]))
    noise = variance[:,green].flatten(1).repeat(2,1)
    y,x = (yy-127.5)/128,(xx-127.5)/128
    center = (torch.arange(GRID,device=device)*16+7.5).clamp(32,223)
    cy,cx = torch.meshgrid(center,center,indexing="ij")
    rsq = (xx[None]-cx.reshape(-1,1)).square()+(yy[None]-cy.reshape(-1,1)).square()
    active = (x.abs()<=.70)&(y.abs()<=.70)
    weights = {"local":(-rsq/(2*9**2)).exp()*active*(rsq<30**2),
               "exterior":(-rsq/(2*42**2)).exp()*active*(rsq>=30**2)}

    def wave(frequency):
        phase = (xx*frequency[0]+yy*frequency[1])*(2*torch.pi)
        return phase.cos(),phase.sin()

    c,s = wave(competitor)
    wc,ws = wave(signal)
    basis = torch.stack((torch.ones_like(x),x,y,sign,sign*x,sign*y,c,s,c*x,c*y,s*x,s*y,wc,ws),dim=-1)
    splits = [folds==k for k in (2,3)]
    return {name:[solve(basis[f],values[:,f],noise[:,f],w[:,f])for f in splits]for name,w in weights.items()}


def restore(args,parent,peaks):
    if len(peaks)<2:
        return torch.zeros_like(parent)
    packed,variance,colors,wb,matrix = args
    assert torch.equal(colors,colors[:1].expand_as(colors))
    gains = torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
    gains = gains/gains[:,1:2]
    total = torch.zeros_like(parent)
    for a,b in (peaks,peaks[::-1]):
        fits = delivery_fits(packed,variance,colors,parent,a,b)
        local = lift(amplitude("exterior",fits,packed.shape[0]),a)
        total += local[:,None]*gains[:,:,None,None]
    return total
