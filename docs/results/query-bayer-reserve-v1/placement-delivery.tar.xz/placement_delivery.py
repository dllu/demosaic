"""Measure alignment of the delivered fine correction across fixed crop shifts."""
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from reserved import PREVIOUS,restore

ROOT = Path(__file__).resolve().parent
ARGS = ("packed","variance","colors","wb","matrix")


def rms(v):
    return float(np.sqrt(np.mean(v*v))*65535)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    placed = reference(ROOT/"placement.json")
    raw_placements = read_json(checked(placed))
    full = read_json(checked(raw_placements["proposals"]))
    discovered = {r["id"]:r for r in full["rows"]}
    native = reference(ROOT/"standing/manifest.json")
    cameras = read_json(checked(native))
    rendered = {r["id"]:r for r in cameras["rows"]}
    metric = read_json(checked(cameras["score"]))
    scale = metric["scales"]["reserved"]
    shots = []
    with ieee_fp32():
        for r in raw_placements["rows"]:
            tag = r["id"]
            crop = rendered[tag]
            n = discovered[tag]
            assert crop["input"]==n["raw"]
            with np.load(checked(n["raw"]),allow_pickle=False)as f:
                arrays = {k:f[k]for k in ARGS}
            parent = np.load(checked(crop["baseline"]),allow_pickle=False)
            qx,qy,_,_ = n["fit_xywh"]
            x,y,w,h = crop["case"]["ROI_xywh"]
            correction = []
            for row in r["placements"]:
                dx,dy = row["native_shift_xy"]
                a,b = qx+dx,qy+dy
                packed = np.s_[...,b//2:b//2+128,a//2:a//2+128]
                camera = [torch.from_numpy(arrays[k][packed].copy()if k in ARGS[:2]else arrays[k])for k in ARGS]
                base = torch.from_numpy(parent[...,b:b+256,a:a+256].copy())
                signals = [v["frequency_xy"]for v in row["discovery"]["peaks"]]
                forecast = base+scale*restore(camera,base,signals)
                offset = np.s_[...,y-b:y-b+h,x-a:x-a+w]
                native_delta = (forecast-base)[offset].numpy().astype(float)
                correction.append(native_delta)
            with np.load(checked(crop["restorations"]),allow_pickle=False)as f:
                region = np.s_[...,y-qy:y-qy+h,x-qx:x-qx+w]
                np.testing.assert_array_equal(correction[0],(f["reserved"]-f["parent"])[region])
            delta_main = correction[0].ravel()
            lengths = np.linalg.norm(delta_main)
            telemetry = []
            for placed_row,delta in zip(r["placements"],correction,strict=True):
                vec = delta.ravel()
                norm = lengths*np.linalg.norm(vec)
                telemetry.append({"native_shift_xy":placed_row["native_shift_xy"],
                                  "change_DN16_RMS":rms(delta),
                                  "cosine_over_native_RGB":float(np.dot(delta_main,vec)/norm)if norm else None,
                                  "from_center_delta_DN16_RMS":rms(delta-correction[0])})
            med = np.median(np.stack(correction),axis=0)
            ratio = float(np.sum(med.ravel()*delta_main)/np.sum(delta_main**2))if lengths else None
            result = {"id":tag,"views":telemetry,"median_change_DN16_RMS":rms(med),
                          "median_projection_onto_center":ratio}
            print(tag,round(rms(correction[0]),4),[v["cosine_over_native_RGB"]for v in telemetry],ratio,flush=True)
            shots.append(result)
    write_json(ROOT/"placement-delivery.json",{"driver":reference(__file__),"nominations":placed,
       "standing":native,"rows":shots,"scope":"Matched parent and fixed native displayed ROI in every view. Cosine measures consistency of the added RGB field across overlapping crops, using the nominal field as its descriptive anchor. No qualitative reference enters the calculation and overlapping fields share RAW."})


if __name__=="__main__":
    main()
