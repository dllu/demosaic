"""Change scene corridors while keeping the query and four donor RAWs fixed."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.screened_scene_donors import donor_affinities, screening_preview

from replay_routes import FROZEN, make_encoder, OUT, bench
from routes import affinities

HERE = Path(__file__).resolve().parent
SIZE = 1792
QUERY = (768, 768, 256, 256)
ARMS = ("window_scene", "window_matched_line", "window_geodesic")
SELECT = (88, 89, 90, 91)


def transfer(box):
    x, y, w, h = box
    u, v = x + w // 2 - 640, y + h // 2 - 640
    return (SIZE // 2 + 7 * u // 4 - w // 2, SIZE // 2 + 7 * v // 4 - h // 2, w, h)


def background(seed, colors, noise, open_vertical):
    h = SIZE // 2
    y, x = np.ogrid[-h:h, -h:h]
    parity = colors.reshape(2, 2)[y % 2, x % 2]
    a = np.asarray((0.10, 0.14, 0.10))
    b = np.asarray((0.04, 0.047, 0.058))
    wall = np.asarray((0.085, 0.055, 0.31))
    paths = (abs(x) < 110) | (abs(y) < 110)
    base = np.where(paths, a[parity], b[parity])
    for vertical in (False, True):
        long, short = (y, x) if vertical else (x, y)
        width = 40 if vertical == open_vertical else 178
        blocked = (abs(abs(long) - 224) < 24) & (abs(short) < width)
        base = np.where(blocked, wall[parity], base)
    rng = np.random.default_rng(seed)
    return (
        base + rng.standard_normal(base.shape) * np.sqrt(noise["shot"] * base + noise["read"])
    ).astype("f")


def ranks(raw, role, case, settings, views, boxes, net, wb, matrix):
    preview, grid = screening_preview(raw, case["CFA"], wb, matrix, **settings)
    scene = make_encoder(net, preview, grid)
    endpoints = donor_affinities(scene.features, grid, boxes, QUERY)
    graph, line, _ = affinities(scene, preview, QUERY, boxes, endpoints)
    return dict(zip(ARMS, (endpoints, line, graph), strict=True)), fingerprint(preview)


def matches(fit, targets):
    boxes = fit.get("windows", [])

    def in_region(box, frame):
        x, y, w, h = box
        i, j, a, b = frame
        return i <= x and x + w <= i + a and j <= y and y + h <= j + b

    return len(boxes) == 2 and all(any(in_region(b, t) for t in targets) for b in boxes)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    start = monotonic()
    old = reference(FROZEN / "output" / "collection.json")
    original = read_json(checked(old))
    source = read_json(checked(original["plan"]))
    net = bench.load_encoder(source["encoder"])
    context = net.base.context
    context.backbone = context.backbone.cuda()
    context.mean = context.mean.cuda()
    context.std = context.std.cuda()
    cfg = LocalWaveConfig(**source["config"])
    folder = OUT / "layouts"
    folder.mkdir(exist_ok=True)
    records = []
    with ieee_fp32():
        for old_row in original["synthetic"]:
            case = read_json(checked(old_row["case"]))
            if case["source"] not in SELECT:
                continue
            profile = source["profiles"][case["profile"]]
            t = source["settings"][case["profile"]]["threshold"]
            packed, colors = bench.sensor_box(case["sensor"], source["query_xywh"])
            with np.load(checked(case["sensor"])) as sensor:
                wb, matrix = sensor["wb"], sensor["matrix"]
            views = [
                (p, c, transfer(b))
                for p, c, b in bench.unpack(old_row["donors"] + case["donors"][2:])
            ]
            boxes = bench.catalog([item[2] for item in views], QUERY, [(128, 64), (192, 64)])
            intended = [v[2] for v in views[:2]]
            true_vertical = intended[0][0] == intended[1][0]
            signatures = {}
            raw = background(case["source"] + 19811, colors[0], profile, true_vertical)
            other = background(case["source"] + 19811, colors[0], profile, not true_vertical)
            for p, c, b in views:
                bench.place(raw, p, c, b)
                bench.place(other, p, c, b)
            priors = {}
            for position in (0, 2):
                q = packed[position]
                for name, image in (("matching", raw), ("swapped", other)):
                    bench.place(image, q, colors[position], QUERY)
                    prior, signature = ranks(
                        image,
                        position,
                        case,
                        source["preview"],
                        views,
                        boxes,
                        net,
                        wb[position],
                        matrix[position],
                    )
                    for key, values in prior.items():
                        priors[position, name, key] = values
                    signatures[position, name] = signature
                for b in (QUERY, *[v[2] for v in views]):
                    np.testing.assert_array_equal(bench.crop(raw, b), bench.crop(other, b))
            fits = bench.rank_scene_windows(
                [(bench.crop(raw, b), colors[0], b) for b in boxes],
                QUERY,
                shot=profile["shot"],
                read=profile["read"],
                affinities=priors,
            )
            with np.load(checked(old_row["prediction"])) as container:
                parent = container["parent"]
            predictions = {}
            scores = {}
            for position in (0, 2):
                scores[str(position)] = {}
                for name in ("matching", "swapped"):
                    values = {key: fits[position, name, key] for key in ARMS}
                    delivered = bench.deliver_options(
                        parent[position],
                        packed[position],
                        colors[position],
                        values,
                        QUERY,
                        profile,
                        cfg,
                        t,
                    )
                    scores[str(position)][name] = {
                        key: {"intended": matches(fit, intended), "fit": fit}
                        for key, fit in values.items()
                    }
                    for key, value in delivered.items():
                        predictions[f"{position}-{name}-{key}"] = value
            fn = bench.write_array(folder / f"{case['id']}.npz", **predictions)
            records.append(
                {
                    "id": case["id"],
                    "case": old_row["case"],
                    "parent": old_row["prediction"],
                    "prediction": fn,
                    "boxes": boxes,
                    "intended": intended,
                    "query": QUERY,
                    "signatures": {f"{i}-{name}": v for (i, name), v in signatures.items()},
                    "scores": scores,
                }
            )
            print(
                case["id"],
                {
                    name: {key: m["intended"] for key, m in group.items()}
                    for name, group in scores["2"].items()
                },
                flush=True,
            )
    assert len(records) == 8
    write_json(
        OUT / "layout-probe.json",
        {
            "driver": reference(__file__),
            "retained": old,
            "records": records,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
