"""Archive immutable donor-route receipts and publish the reviewed crop assets."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
EXPERIMENT = "scene-geodesic-donors-v1"
LOCAL = ROOT / ".cache/experiments" / EXPERIMENT
EXTERNAL = Path("/mnt/external/demosaic") / EXPERIMENT
IMAGES = ROOT / "docs/images" / EXPERIMENT
RESULTS = ROOT / "docs/results" / EXPERIMENT
RECEIPTS = (
    "collection",
    "review",
    "layout-probe",
    "negative-probe",
    "route-audit",
    "route-support",
    "padded-route",
)


def publish_image(data):
    path = checked(data)
    target = IMAGES / path.name
    shutil.copyfile(path, target)
    ref = reference(target)
    assert ref["sha256"] == data["sha256"]
    return ref | {"path": str(target.relative_to(ROOT))}


def publish_board(data):
    board = data | {"image": publish_image(data["image"])}
    with Image.open(ROOT / board["image"]["path"]) as png:
        for panel in board["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= png.width and 0 <= y < y + h <= png.height
    return board


def equal_graphs(rows, key):
    for item in rows:
        with np.load(checked(item[key])) as a:
            assert np.array_equal(a["window_geodesic"], a["window_graph_local"])
    return len(rows)


def main():
    prior = reference(ROOT / "docs/results/scene-window-donors-v1/publication.json")
    inputs = {k: reference(EXTERNAL / f"{k}.json") for k in RECEIPTS}
    original = {k: read_json(checked(v)) for k, v in inputs.items()}
    collection = original["collection"]
    review = original["review"]
    padded = original["padded-route"]
    layout = original["layout-probe"]
    negatives = original["negative-probe"]
    assert padded["matches_full_graph_windows"] and padded["matches_parent"]
    assert padded["max_affinity_delta"] == 0
    assert review["audit"] == {"arrays_reproduced": 264, "arrays_differing": []}
    assert all(all(row["both_roles"].values()) for row in negatives["rows"])
    assert (
        len(collection["synthetic"]), len(collection["camera"]), len(layout["records"]), negatives["n"]
    ) == (16, 8, 8, 36)

    for name in ("review", "route-audit", "route-support", "padded-route"):
        assert original[name]["collection"] == inputs["collection"]
    assert review["layout"] == original["route-audit"]["layouts"] == inputs["layout-probe"]
    assert layout["retained"] == collection["retained"]

    members = {f"receipts/{Path(v['path']).name}": v for v in inputs.values()}
    sources = [
        collection["source"],
        collection["operator"],
        collection["bench"],
        *(original[k]["driver"] for k in RECEIPTS[1:]),
        reference(__file__),
    ]
    members.update({f"source/{Path(v['path']).name}": v for v in sources})
    dependencies = [
        collection["plan"],
        collection["retained"],
        review["legacy_review"],
        negatives["generator"],
        negatives["previous"],
    ]
    members.update({f"prior/{Path(v['path']).name}": v for v in dependencies})

    IMAGES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    native = {
        "synthetic": [
            item | {"board": publish_board(item["board"]), "triplet": publish_board(item["triplet"])}
            for item in review["native_exact"]
        ],
        "camera": [],
        "layout": {
            "id": review["layout_figure"]["id"],
            "image": publish_image(review["layout_figure"]["image"]),
            "preview_only": True,
        },
    }
    for item in review["native_camera"]:
        meta = {k: item[k] for k in (
            "id", "ROI_xywh", "display_exposure", "noise", "checkpoint",
            "camera_inputs", "arrays", "old_affinity", "predictions"
        )}
        native["camera"].append(meta | publish_board({
            "image": item["image"],
            "panels": item["panels"],
        }))
    native_manifest = IMAGES / "manifest.json"
    write_json(native_manifest, native)

    source_revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    aggregate = {
        "source_revision": source_revision,
        "parent_checkpoints": {
            "synthetic_V143_EMA": review["native_exact"][0]["checkpoint"],
            "camera_V120_EMA": review["native_camera"][0]["checkpoint"],
        },
        "encoder": collection["encoder"],
        "fixed_inputs": collection["plan"],
        "screening_independence": collection["A_only"],
        "detour_fixture": collection["path_fixture"],
        "legacy_prediction_replay": review["audit"],
        "full_and_restricted_bit_exact": {
            "synthetic": equal_graphs(collection["synthetic"], "prediction"),
            "camera": equal_graphs(collection["camera"], "predictions"),
        },
        "seconds": {k: original[k]["seconds"] for k in RECEIPTS if "seconds" in original[k]},
        "synthetic": {
            "aggregates": review["aggregates"],
            "quiet_error_budget": review["budget"],
            "selection_counts": review["selection"],
        },
        "layout": {
            "intended_counts": review["layout_summary"],
            "RGB_results": original["route-audit"]["layout_RGB"],
        },
        "negative": negatives["false_donor_confirmation"],
        "camera": [
            {k: item[k] for k in ("id", "ROI_xywh", "distance", "fits", "vs_endpoint_DN16")}
            for item in review["native_camera"]
        ],
        "nominal_left_support": original["route-support"],
        "nominal_left_with_interpolation_margin": padded,
    }
    output = RESULTS / "summary.json"
    write_json(output, aggregate)

    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, mode="x:xz") as tar:
        for name, binding in members.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == members.keys()
        for name, info in members.items():
            with tar.extractfile(name) as handle:
                assert hashlib.file_digest(handle, "sha256").hexdigest() == info["sha256"]
    notes = {
        "archive": reference(archive),
        "summary": reference(output),
        "native_manifest": reference(native_manifest),
        "original_receipts": inputs,
        "members": members,
        "prior_publication": prior,
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "layout_previews_viewed": 1,
        "new_checkpoint": None,
    }
    write_json(RESULTS / "publication.json", notes)


if __name__ == "__main__":
    main()
