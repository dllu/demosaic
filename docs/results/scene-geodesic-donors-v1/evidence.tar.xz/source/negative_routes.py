"""Replay the frozen flat, single-step and rail-only donor controls."""

from collections import Counter
from itertools import product
from pathlib import Path
from time import monotonic
import importlib.util

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.screened_scene_donors import screening_preview

from replay_routes import FROZEN, OUT, bench, make_encoder, retained, rank, BASE, GRAPH

spec = importlib.util.spec_from_file_location("old_nulls", FROZEN / "null_search_final.py")
earlier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    mark = monotonic()
    prior = reference(FROZEN / "null-search-final.json")
    archived = read_json(checked(prior))
    plan = read_json(checked(archived["plan"]))
    net = bench.load_encoder(plan["encoder"])
    ctx = net.base.context
    ctx.backbone = ctx.backbone.cuda()
    ctx.mean = ctx.mean.cuda()
    ctx.std = ctx.std.cuda()
    boxes = bench.catalog((earlier.frame,), earlier.query, plan["camera_windows"])
    accepted = Counter()
    rows = []
    with ieee_fp32():
        for (pi, (profile, noise)), (si, style), trial in product(
            enumerate(plan["profiles"].items()),
            enumerate(("flat", "step", "rail")),
            range(earlier.trials),
        ):
            old = next(
                row
                for row in archived["rows"]
                if (row["profile"], row["style"], row["trial"]) == (profile, style, trial)
            )
            angle = old["angle_radians"]
            params = old["rail_width_shift_level_height"]
            raw = earlier.raw_field((pi, si, trial), angle, style, *params, noise)
            preview, grid = screening_preview(raw, "RGGB", [1, 1, 1], np.eye(3), **plan["preview"])
            scene = make_encoder(net, preview, grid)
            near = make_encoder(net, retained(preview, grid, earlier.frame), grid)
            opts = rank(scene, near, boxes, earlier.query)
            donors = [(bench.crop(raw, box), np.array((0, 1, 1, 2)), box) for box in boxes]
            newer = bench.rank_scene_windows(
                donors, earlier.query, shot=noise["shot"], read=noise["read"], affinities=opts
            )
            for arm, fit in newer.items():
                accepted[f"{style} / {arm}"] += int(any(fit["active"]))
            unchanged = {k: newer[k]["active"] == old["fits"][k]["active"] for k in BASE}
            rows.append(
                {
                    "profile": profile,
                    "trial": trial,
                    "style": style,
                    "both_roles": unchanged,
                    "fits": newer,
                }
            )
            print(profile, style, trial, [any(newer[k]["active"]) for k in GRAPH], flush=True)
    write_json(
        OUT / "negative-probe.json",
        {
            "driver": reference(__file__),
            "previous": prior,
            "generator": reference(FROZEN / "null_search_final.py"),
            "n": len(rows),
            "rows": rows,
            "false_donor_confirmation": dict(accepted),
            "seconds": monotonic() - mark,
        },
    )


if __name__ == "__main__":
    main()
