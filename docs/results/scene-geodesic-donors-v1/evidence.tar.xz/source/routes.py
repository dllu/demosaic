"""Rank donor routes on a graph of A-only scene features and preview boundaries."""

import numpy as np
from scipy.ndimage import map_coordinates
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
import torch
from torch.nn import functional as F

from demosaic.scene_context import sample_scene_features

STRIDES = (4, 8, 16)
LEVEL_WEIGHT = (0.4, 0.35, 0.25)
NODE_SCALE = 6.0
EDGE_SCALE = 2.0
EDGE_REFERENCE = 0.10


def descriptor_cost(scene, query, shape):
    h, w = scene.grid.native_hw
    x, y, qw, qh = query
    middle = (x + qw / 4, y + qh / 4, qw / 2, qh / 2)
    cost = 0.0
    for feature, stride, weight in zip(scene.features[:3], STRIDES, LEVEL_WEIGHT, strict=True):
        points = sample_scene_features(feature, scene.grid, stride, [middle], (5, 5))
        anchor = F.normalize(F.normalize(points[0].flatten(1), dim=0).mean(dim=1), dim=0)
        cell = F.normalize(feature.float(), dim=1)
        angle = (1 - torch.einsum("d,bdyx->byx", anchor, cell)).clamp(0, 2)[..., None, :, :]
        distance = sample_scene_features(angle, scene.grid, stride, [(0, 0, w, h)], shape)
        cost = cost + weight * distance[0, 0]
    return cost.detach().cpu().numpy()


def _coord(xy, native_hw, graph_hw):
    scale = np.asarray(graph_hw[::-1], dtype="d") / np.asarray(native_hw[::-1], dtype="d")
    return np.asarray(xy, dtype="d") * scale - 0.5


def graph_cost(node, rgb, spacing):
    """Create one undirected connected graph with four orthogonal neighbors."""
    h, w = node.shape
    index = np.arange(h * w).reshape(h, w)
    endpoints = []
    values = []
    for axis, step in enumerate(spacing):
        a, b = (np.s_[:-1, :], np.s_[1:, :]) if axis == 0 else (np.s_[:, :-1], np.s_[:, 1:])
        edge = np.sqrt(np.mean((rgb[a] - rgb[b]) ** 2, axis=-1))
        delta = np.minimum(1, edge / EDGE_REFERENCE)
        cost = step * (1 + NODE_SCALE * (node[a] + node[b]) / 2 + EDGE_SCALE * delta)
        endpoints.append((index[a].ravel(), index[b].ravel()))
        values.append(cost.ravel())
    x, y = map(np.concatenate, zip(*endpoints, strict=True))
    data = np.concatenate(values)
    return coo_matrix(
        (np.concatenate((data, data)), (np.r_[x, y], np.r_[y, x])), shape=(h * w, h * w)
    ).tocsr()


def routes(node, rgb, query, boxes, native_hw, bounds=None):
    """Compare graph routes and straight routes under the same appearance cost."""
    shape = node.shape
    spacing = np.asarray(native_hw, dtype="d") / shape
    qx, qy, qw, qh = query
    anchor = _coord((qx + qw / 2, qy + qh / 2), native_hw, shape)
    col, row = np.rint(anchor).astype(int)
    if bounds is not None:
        bx, by, bw, bh = bounds
        yy, xx = (np.indices(shape) + 0.5) * spacing[:, None, None]
        inside = (xx >= bx) & (xx < bx + bw) & (yy >= by) & (yy < by + bh)
        assert inside[row, col]
        node = np.where(inside, node, 1e4)
    graph = graph_cost(node, rgb, spacing)
    costs = dijkstra(graph, indices=row * shape[1] + col).reshape(shape)
    candidates = np.asarray(boxes, dtype="d")
    grid = (np.arange(5) + 0.5) / 5
    dx, dy = np.meshgrid(grid, grid, indexing="xy")
    coords = _coord(
        candidates[:, None, :2] + candidates[:, None, 2:] * np.c_[dx.ravel(), dy.ravel()],
        native_hw,
        shape,
    )
    xy = coords.reshape(-1, 2)
    delta = xy - [col, row]
    minimum = (abs(delta) * spacing[::-1]).sum(axis=1).clip(min=1e-6)

    route = map_coordinates(costs, xy.T[::-1], order=1, mode="nearest")
    affinity = np.exp(-np.maximum(0, route / minimum - 1)).reshape(len(boxes), -1)
    cell = np.arange(24) + 0.5
    positions = np.array([col, row]) + delta[:, None, :] * (cell[None, :, None] / len(cell))
    flat = positions.reshape(-1, 2)
    profile = map_coordinates(node, flat.T[::-1], order=1, mode="nearest").reshape(
        len(xy), len(cell)
    )
    pixels = np.stack(
        [
            map_coordinates(rgb[..., k], flat.T[::-1], order=1, mode="nearest").reshape(
                profile.shape
            )
            for k in range(3)
        ],
        axis=-1,
    )
    edge = np.sqrt(np.mean(np.diff(pixels, axis=1) ** 2, axis=-1))
    # Image differences are accumulated over the route's physical length.
    # Scale each step to the length of a graph edge before applying its cap.
    nominal_steps = np.abs(delta).sum(axis=-1).clip(min=1)
    per_step = edge * len(cell) / nominal_steps[:, None]
    total = NODE_SCALE * profile.mean(axis=1) + EDGE_SCALE * np.clip(
        per_step / EDGE_REFERENCE, 0, 1
    ).mean(axis=1)
    straight = np.exp(-total).reshape(len(boxes), -1)
    return np.quantile(affinity, 0.25, axis=1), np.quantile(straight, 0.25, axis=1)


def affinities(scene, preview, query, boxes, endpoint, bounds=None):
    if not boxes:
        return np.empty(0), np.empty(0)
    shape = tuple(max(2, (i + 3) // 4) for i in scene.grid.preview_hw)
    cost = descriptor_cost(scene, query, shape)
    rgb = F.interpolate(preview, size=shape, mode="area")[0].permute(1, 2, 0).detach().cpu().numpy()
    graph, line = routes(cost, rgb, query, boxes, scene.grid.native_hw)
    restricted = (
        routes(cost, rgb, query, boxes, scene.grid.native_hw, bounds)[0] if bounds else graph
    )
    return np.sqrt(endpoint * graph), np.sqrt(endpoint * line), np.sqrt(endpoint * restricted)


def independence_test():
    node = np.zeros((48, 48), dtype="d")
    rgb = np.full((48, 48, 3), 0.2)
    query = (4, 20, 8, 8)
    boxes = [(39, 20, 4, 8)]
    # Both endpoints match. The direct path crosses a blue barrier with room to detour.
    node[15:34, 21:27] = 1
    rgb[15:34, 21:27] = (0.11, 0.22, 0.70)
    graph, line = routes(node, rgb, query, boxes, (48, 48))
    assert graph[0] > line[0]
    node[:, 21:27] = 1
    rgb[:, 21:27] = (0.11, 0.22, 0.70)
    closed, _ = routes(node, rgb, query, boxes, (48, 48))
    assert graph[0] > closed[0]
    return {"detour": float(graph[0]), "straight": float(line[0]), "closed": float(closed[0])}
