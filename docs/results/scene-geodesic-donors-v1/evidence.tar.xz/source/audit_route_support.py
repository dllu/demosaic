"""Trace the grid support of the native left-cab candidate affinities."""

import numpy as np
from scipy.ndimage import map_coordinates
from scipy.sparse.csgraph import dijkstra
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.screened_scene_donors import screening_preview

from audit_routes import trace_path
from replay_routes import OUT, bench, make_encoder
from routes import _coord, descriptor_cost, graph_cost


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    collection = reference(OUT / "collection.json")
    data = read_json(checked(collection))
    plan = read_json(checked(data["plan"]))
    row = next(entry for entry in data["camera"] if entry["id"] == "mesh-nominal-left")
    raw, meta = bench.read_raw(checked(plan["photos"]["mesh"]))
    encoder = bench.load_encoder(plan["encoder"])
    context = encoder.base.context
    context.backbone = context.backbone.cuda()
    context.mean = context.mean.cuda()
    context.std = context.std.cuda()
    preview, grid = screening_preview(
        raw, meta.pattern, meta.white_balance, meta.camera_to_srgb, **plan["preview"]
    )
    with ieee_fp32():
        scene = make_encoder(encoder, preview, grid)
        shape = tuple(max(2, (d + 3) // 4) for d in grid.preview_hw)
        node = descriptor_cost(scene, row["query"], shape)
    rgb = F.interpolate(preview, size=shape, mode="area")[0].permute(1, 2, 0).numpy()
    spacing = np.asarray(grid.native_hw, dtype="d") / shape
    qx, qy, qw, qh = row["query"]
    col, line = np.rint(_coord((qx + qw / 2, qy + qh / 2), grid.native_hw, shape)).astype(int)
    origin = line * shape[1] + col
    bx, by, bw, bh = row["frame"]
    yy, xx = (np.indices(shape) + 0.5) * spacing[:, None, None]
    inside = (xx >= bx) & (xx < bx + bw) & (yy >= by) & (yy < by + bh)
    unrestricted, prev = dijkstra(
        graph_cost(node, rgb, spacing), indices=origin, return_predecessors=True
    )
    restricted = dijkstra(graph_cost(np.where(inside, node, 1e4), rgb, spacing), indices=origin)
    fractions = (np.arange(5) + 0.5) / 5
    dx, dy = np.meshgrid(fractions, fractions, indexing="xy")
    cells = np.c_[dx.ravel(), dy.ravel()]
    result = []
    for arm in ("window_geodesic", "window_graph_local", "window_scene"):
        for x, y, w, h in row["fits"][arm]["windows"]:
            xy = _coord((x, y) + cells * (w, h), grid.native_hw, shape)
            lower, upper = np.floor(xy).astype(int), np.ceil(xy).astype(int)
            any_outside = []
            for (j, i), (k, m) in zip(lower, upper, strict=True):
                choices = [a * shape[1] + b for a in {i, m} for b in {j, k}]
                traces = [trace_path(prev, origin, ch, shape, spacing) for ch in choices]
                any_outside.append(
                    any(
                        np.any((p[:, 0] < bx) | (p[:, 0] >= bx + bw) |
                               (p[:, 1] < by) | (p[:, 1] >= by + bh))
                        for p in traces
                    )
                )
            length = (np.abs(xy - [col, line]) * spacing[::-1]).sum(axis=1)
            affinity = {}
            for name, costs in (("full", unrestricted), ("restricted", restricted)):
                path = map_coordinates(costs.reshape(shape), xy.T[::-1], order=1, mode="nearest")
                affinity[name] = float(np.quantile(np.exp(-np.maximum(0, path / length - 1)), 0.25))
            result.append(
                {
                    "chosen_by": arm,
                    "box_xywh": [x, y, w, h],
                    "route_sample_count": len(xy),
                    "full_route_samples_using_exterior": int(sum(any_outside)),
                    "route_cost_affinity": affinity,
                }
            )
    write_json(
        OUT / "route-support.json",
        {
            "driver": reference(__file__),
            "collection": collection,
            "scene": row["id"],
            "restricted_frame_xywh": row["frame"],
            "windows": result,
        },
    )


if __name__ == "__main__":
    main()
