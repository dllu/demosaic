"""Keep interpolation support inside the restricted left-cab graph."""

from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.screened_scene_donors import screening_preview

from replay_routes import OUT, bench, make_encoder
from routes import affinities


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    mark = monotonic()
    source = reference(OUT / "collection.json")
    data = read_json(checked(source))
    plan = read_json(checked(data["plan"]))
    key = "mesh-nominal-left"
    row = next(r for r in data["camera"] if r["id"] == key)
    raw, meta = bench.read_raw(checked(plan["photos"]["mesh"]))
    encoder = bench.load_encoder(plan["encoder"])
    context = encoder.base.context
    context.backbone = context.backbone.cuda()
    context.mean = context.mean.cuda()
    context.std = context.std.cuda()
    preview, grid = screening_preview(
        raw, meta.pattern, meta.white_balance, meta.camera_to_srgb, **plan["preview"]
    )
    sy, sx = np.asarray(grid.native_hw) / [max(2, (i + 3) // 4) for i in grid.preview_hw]
    x, y, w, h = row["frame"]
    bounds = (x - sx, y - sy, w + 2 * sx, h + 2 * sy)
    boxes = row["scene_window_boxes"]
    endpoint = np.asarray(row["scene_window_affinities"]["window_scene"])
    query = row["query"]
    with ieee_fp32():
        scene = make_encoder(encoder, preview, grid)
        full, _, padded = affinities(scene, preview, query, boxes, endpoint, bounds)
    np.testing.assert_allclose(
        full, row["scene_window_affinities"]["window_geodesic"], rtol=0, atol=0
    )
    noise = next(
        r["noise"] for r in read_json(checked(plan["camera_conditions"]))["camera"]
        if r["board"]["id"] == key
    )
    arrays = next(
        r["source"]["query_arrays"] for r in read_json(checked(plan["camera_baseline"]))["camera"]
        if r["id"] == key
    )
    with np.load(checked(arrays)) as f:
        colors = f["colors"][0]
        np.testing.assert_array_equal(f["packed"][0], bench.crop(raw, row["frame"]))
    label = "window_graph_padded"
    fits = bench.rank_scene_windows(
        [(bench.crop(raw, b), colors, b) for b in boxes],
        query,
        shot=noise["shot"],
        read=noise["read"],
        affinities={label: padded},
    )
    with np.load(checked(row["predictions"])) as predictions:
        rgb = bench.deliver_options(
            predictions["parent"], bench.crop(raw, query), colors, fits,
            query, noise, bench.LocalWaveConfig(**plan["config"]), 2, edge=True
        )[label]
        same_graph = np.array_equal(rgb, predictions["window_geodesic"])
        same_parent = np.array_equal(rgb, predictions["parent"])
    write_json(
        OUT / "padded-route.json",
        {
            "driver": reference(__file__),
            "collection": source,
            "id": key,
            "padded_bounds_xywh": bounds,
            "max_affinity_delta": float(np.max(abs(full - padded))),
            "fit": fits[label],
            "matches_full_graph_windows": fits[label]["windows"] == row["fits"]["window_geodesic"]["windows"],
            "matches_full_graph_output": same_graph,
            "matches_parent": same_parent,
            "seconds": monotonic() - mark,
        },
    )


if __name__ == "__main__":
    main()
