"""Measure actual path extent and local-query changes on the altered layouts."""

from time import monotonic

import numpy as np
from scipy.sparse.csgraph import dijkstra
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.screened_scene_donors import screening_preview

from replay_routes import OUT, bench, make_encoder
from routes import _coord, descriptor_cost, graph_cost


def layout_errors(layout, plan):
    result = []
    for r in layout["records"]:
        case = read_json(checked(r["case"]))
        setting = plan["settings"][case["profile"]]
        x, y, w, h = plan["query_xywh"]
        roi = np.s_[:, y : y + h, x : x + w]
        with np.load(checked(case["target"])) as f:
            gt = f["target"]
        with np.load(checked(r["parent"])) as f:
            parent = f["parent"]
        scores = {}
        with np.load(checked(r["prediction"])) as f:
            for condition in ("matching", "swapped"):
                arm = {}
                for flag in ("window_scene", "window_matched_line", "window_geodesic"):
                    full = f[f"2-{condition}-{flag}"].astype("d")
                    background = f[f"0-{condition}-{flag}"].astype("d")
                    parent_crop = parent[2].astype("d")
                    error = parent_crop + setting["scale"] * (full - parent_crop) - gt[2][roi]
                    b = background - parent[0]
                    arm[flag] = {
                        "present_RGB_DN16": float(np.sqrt(np.mean(error**2)) * 65535),
                        "background_added_DN16": float(np.sqrt(np.mean(b**2)) * 65535),
                    }
                scores[condition] = arm
        result.append({"id": r["id"], "profile": case["profile"], "scores": scores})
    return result


def trace_path(predecessor, origin, final, shape, spacing):
    ids = []
    while final != origin:
        ids.append(int(final))
        final = int(predecessor[final])
        assert final >= 0 and len(ids) < len(predecessor)
    ids.append(int(origin))
    yy, xx = np.unravel_index(ids[::-1], shape)
    points = (np.stack((xx, yy), axis=1) + 0.5) * spacing[::-1]
    return points


@torch.inference_mode()
def real_routes(review, plan):
    row = next(r for r in review["camera"] if r["id"] == "mesh-nominal-left")
    raw, meta = bench.read_raw(checked(plan["photos"]["mesh"]))
    graph_probe = bench.load_encoder(plan["encoder"])
    ctx = graph_probe.base.context
    ctx.backbone = ctx.backbone.cuda()
    ctx.mean = ctx.mean.cuda()
    ctx.std = ctx.std.cuda()
    preview, grid = screening_preview(
        raw, meta.pattern, meta.white_balance, meta.camera_to_srgb, **plan["preview"]
    )
    with ieee_fp32():
        enc = make_encoder(graph_probe, preview, grid)
        shape = tuple(max(2, (i + 3) // 4) for i in grid.preview_hw)
        cost = descriptor_cost(enc, row["query"], shape)
    rgb = F.interpolate(preview, size=shape, mode="area")[0].permute(1, 2, 0).numpy()
    spacing = np.asarray(grid.native_hw, dtype="d") / shape
    graph = graph_cost(cost, rgb, spacing)
    x, y, w, h = row["query"]
    cx, cy = np.rint(_coord((x + w / 2, y + h / 2), grid.native_hw, shape)).astype(int)
    origin = cy * shape[1] + cx
    result = []
    _, previous = dijkstra(graph, indices=origin, return_predecessors=True)
    bx, by, bw, bh = row["frame"]
    for k in ("window_geodesic", "window_graph_local"):
        found = []
        for x, y, w, h in row["fits"][k].get("windows", []):
            ix, iy = np.rint(_coord((x + w / 2, y + h / 2), grid.native_hw, shape)).astype(int)
            p = trace_path(previous, origin, iy * shape[1] + ix, shape, spacing)
            outside = (p[:, 0] < bx) | (p[:, 0] >= bx + bw) | (p[:, 1] < by) | (p[:, 1] >= by + bh)
            found.append(
                {
                    "window": [x, y, w, h],
                    "path": p.tolist(),
                    "outside_nodes": int(outside.sum()),
                    "all_nodes": len(p),
                }
            )
        result.append({"method_windows": k, "full_graph_routes": found})
    return {
        "scene": row["id"],
        "frame": row["frame"],
        "native_hw": grid.native_hw,
        "preview_hw": grid.preview_hw,
        "paths": result,
    }


def main():
    torch.set_num_threads(2)
    start = monotonic()
    src = reference(OUT / "collection.json")
    raw = read_json(checked(src))
    data = read_json(checked(raw["plan"]))
    synthetic = reference(OUT / "layout-probe.json")
    a = layout_errors(read_json(checked(synthetic)), data)
    trace = real_routes(raw, data)
    write_json(
        OUT / "route-audit.json",
        {
            "driver": reference(__file__),
            "collection": src,
            "layouts": synthetic,
            "layout_RGB": a,
            "standing_left_paths": trace,
            "seconds": monotonic() - start,
        },
    )
    print(
        [
            (
                x["method_windows"],
                [(r["outside_nodes"], r["all_nodes"]) for r in x["full_graph_routes"]],
            )
            for x in trace["paths"]
        ],
        flush=True,
    )


if __name__ == "__main__":
    main()
