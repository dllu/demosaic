"""Replay scene donor ranks with the same RAW windows and different spatial paths."""

from pathlib import Path
from time import monotonic
from types import SimpleNamespace
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

import probe_scene_window_donors as bench
from demosaic.screened_scene_donors import screening_preview
from demosaic.search_donor_geometry import screening_mask
from routes import affinities, independence_test

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
FROZEN = HERE.with_name("scene-window-donors-v1")
GRAPH = ("window_geodesic", "window_graph_local", "window_matched_line")
BASE = ("window_spectral", "window_near", "window_scene", "window_corridor")
ENCODE = bench.encode
NEAR = bench.retain_near_preview
AFFINITIES = bench.affinities
pending_box = None


def make_encoder(model, preview, grid):
    global pending_box
    scope = pending_box
    pending_box = None
    device = model.base.context.mean.device
    prior = ENCODE(model, preview.to(device), grid)
    return SimpleNamespace(features=prior.features, grid=prior.grid, preview=preview, bounds=scope)


def retained(preview, grid, box):
    global pending_box
    assert pending_box is None
    pending_box = tuple(box)
    return NEAR(preview, grid, box)


def rank(full, near, boxes, query):
    a = AFFINITIES(full, near, boxes, query)
    graph, straight, local = affinities(
        full, full.preview, query, boxes, a["window_scene"], near.bounds
    )
    return a | dict(zip(GRAPH, (graph, local, straight), strict=True))


def audited_preview():
    data = np.random.default_rng(117).uniform(0.09, 0.11, (192, 260)).astype("f")
    known = screening_mask((0, 0, 260, 192))
    options = {"pattern": "RGGB", "wb": np.ones(3), "matrix": np.eye(3)}
    first, grid = screening_preview(data, **options)
    changed = data.copy()
    changed[~known] = np.linspace(0.01, 0.6, (~known).sum(), dtype="f")
    guarded, other = screening_preview(changed, **options)
    assert grid == other
    torch.testing.assert_close(first, guarded, rtol=0, atol=0)
    return {"exact": fingerprint(first), "mosaic_changed": int(np.count_nonzero(changed != data))}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    start = monotonic()
    previous = reference(FROZEN / "output" / "collection.json")
    plan_binding = reference(FROZEN / "plan.json")
    stored = read_json(checked(previous))
    assert stored["plan"] == plan_binding
    plan = read_json(checked(plan_binding))
    encoder = bench.load_encoder(plan["encoder"])
    device = "cpu" if "--cpu" in sys.argv else "cuda"
    context = encoder.base.context
    context.backbone = context.backbone.to(device)
    context.mean = context.mean.to(device)
    context.std = context.std.to(device)
    bench.encode = make_encoder
    bench.retain_near_preview = retained
    bench.affinities = rank
    bench.RANKS = BASE + GRAPH
    config = LocalWaveConfig(**plan["config"])
    target = OUT / "predictions"
    target.mkdir(exist_ok=True)
    with ieee_fp32():
        synthetic = bench.synthetic(plan, stored["synthetic"], encoder, config, target)
        camera = bench.camera(plan, stored["camera"], encoder, config, target)
    for source, rows in ((stored["synthetic"], synthetic), (stored["camera"], camera)):
        for old, new in zip(source, rows, strict=True):
            assert old["id"] == new["id"]
            raw_signature = next(k for k in ("preview_hashes", "preview") if k in old)
            assert old[raw_signature] == new[raw_signature]
    write_json(
        OUT / "collection.json",
        {
            "source": reference(__file__),
            "operator": reference(HERE / "routes.py"),
            "bench": reference(Path(bench.__file__)),
            "plan": plan_binding,
            "retained": previous,
            "encoder": {
                k: reference(Path(plan["encoder"]) / k)
                for k in ("config.json", "model.safetensors")
            },
            "device": device,
            "A_only": audited_preview(),
            "path_fixture": independence_test(),
            "arms": ["parent", "parallel", *BASE, *GRAPH],
            "synthetic": synthetic,
            "camera": camera,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
