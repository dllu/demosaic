"""Render native donor reconstructions and measure pose-independent selection."""

from pathlib import Path
from time import monotonic
import importlib.util

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.screened_scene_donors import screening_preview
from demosaic.prediction_archive import fingerprint

from replay_routes import OUT, FROZEN, bench, BASE, GRAPH
from layout_probe import background, QUERY, transfer

spec = importlib.util.spec_from_file_location("original_donor_review", FROZEN / "review.py")
earlier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)

NAMES = {
    "window_geodesic": "Graph route",
    "window_graph_local": "Restricted route",
    "window_matched_line": "Matched straight route",
}


def audit(newer, older):
    same = 0
    other = []
    for group, key in (("synthetic", "prediction"), ("camera", "predictions")):
        for r, s in zip(newer[group], older[group], strict=True):
            assert r["id"] == s["id"]
            with np.load(checked(r[key])) as current, np.load(checked(s[key])) as original:
                for label in original.files:
                    if np.array_equal(original[label], current[label]):
                        same += 1
                    else:
                        assert label in BASE
                        other.append(
                            {
                                "id": r["id"],
                                "arm": label,
                                "peak_abs_DN16": float(
                                    np.max(abs(original[label].astype("d") - current[label]))
                                    * 65535
                                ),
                            }
                        )
    return {"arrays_reproduced": same, "arrays_differing": other}


def compare_geometry(rows, arms):
    result = []
    for r in rows:
        c = read_json(checked(r["case"]))
        result.append(
            {
                "id": r["id"],
                "profile": c["profile"],
                "appearance": c["appearance"],
                "roles": earlier.stats(r, c, arms),
            }
        )
    return result


def describe_layout(layout, older, plan, out):
    overview = None
    matches = {r["id"]: r for r in older["synthetic"]}
    for item in layout["records"]:
        if item["id"] != "iso400-source89-BGGR":
            continue
        orig = matches[item["id"]]
        case = read_json(checked(item["case"]))
        noise = plan["profiles"][case["profile"]]
        q, color = bench.sensor_box(case["sensor"], plan["query_xywh"])
        with np.load(checked(case["sensor"])) as arrays:
            wb, mat = arrays["wb"][2], arrays["matrix"][2]
        views = [
            (p, c, transfer(b)) for p, c, b in bench.unpack(orig["donors"] + case["donors"][2:])
        ]
        intended = [p[2] for p in views[:2]]
        vertical = intended[0][0] == intended[1][0]
        panel = None
        draw = None
        for i, label in enumerate(("matching", "swapped")):
            raw = background(
                case["source"] + 19811, color[0], noise, vertical if i == 0 else not vertical
            )
            for p, c, b in views:
                bench.place(raw, p, c, b)
            bench.place(raw, q[2], color[2], QUERY)
            rendered, grid = screening_preview(raw, case["CFA"], wb, mat, **plan["preview"])
            assert fingerprint(rendered) == item["signatures"][f"2-{label}"]
            a = np.rint(np.clip(rendered[0].permute(1, 2, 0).numpy(), 0, 1) * 255).astype("u1")
            h, w = a.shape[:2]
            if panel is None:
                panel = Image.new("RGB", (2 * w + 24, h + 70), "#eee")
                draw = ImageDraw.Draw(panel)
            bx, by = 8 + i * (w + 8), 34
            panel.paste(Image.fromarray(a), (bx, by))
            draw.text(
                (bx, 12), "Matching route open" if i == 0 else "Distractor route open", fill="black"
            )
            sc = np.asarray((w, h)) / np.asarray(grid.native_hw[::-1])

            def rectangle(b, color):
                x, y, w0, h0 = b
                a = np.array(((x, y), (x + w0, y + h0))) * sc + (bx, by)
                draw.rectangle([*a[0], *a[1]], outline=color, width=2)

            rectangle(QUERY, "white")
            for key, hue in (("window_scene", "#ffbb41"), ("window_geodesic", "#83fbff")):
                for b in item["scores"]["2"][label][key]["fit"].get("windows", []):
                    rectangle(b, hue)
        draw.text(
            (8, panel.height - 22),
            "White  query     Amber  endpoint ranking     Cyan  graph route ranking",
            fill="black",
        )
        path = out / "layout-source89.png"
        panel.save(path)
        overview = {
            "id": item["id"],
            "image": reference(path),
            "layout": item["scores"]["2"],
            "preview_only": True,
            "receipt": item["case"],
        }
    return overview


def main():
    torch.set_num_threads(2)
    start = monotonic()
    receipt = reference(OUT / "collection.json")
    done = read_json(checked(receipt))
    prior = read_json(checked(done["retained"]))
    plan = read_json(checked(done["plan"])) | {
        "arms": [
            "parent",
            "parallel",
            *BASE,
            "window_matched_line",
            "window_graph_local",
            "window_geodesic",
        ]
    }
    out = OUT / "native"
    out.mkdir(exist_ok=True)
    earlier.prior.LABELS.update(NAMES)
    diagnostic = compare_geometry(done["synthetic"], plan["arms"])
    aggregate, diagnoses, figures = earlier.prior.synth(plan, done, out)
    camera = earlier.prior.camera(plan, done, out)
    outputs = []
    for view, new in zip(camera, done["camera"], strict=True):
        x, y, w, h = view["ROI_xywh"]
        qx, qy, *_ = new["query"]
        roi = np.s_[..., y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(new["predictions"])) as a:
            base = a["window_scene"][roi].astype("d")
            deltas = {}
            for key in GRAPH:
                v = a[key][roi].astype("d") - base
                deltas[key] = float(np.sqrt(np.mean(v * v)) * 65535)
        outputs.append(view | {"vs_endpoint_DN16": deltas})
    layout_source = reference(OUT / "layout-probe.json")
    layout = read_json(checked(layout_source))
    layout_summary = {}
    for mode in ("matching", "swapped"):
        layout_summary[mode] = {
            k: sum(r["scores"]["2"][mode][k]["intended"] for r in layout["records"])
            for k in ("window_scene", "window_matched_line", "window_geodesic")
        }
        layout_summary[mode]["donor_gate_any_in_flat"] = {
            k: sum(any(r["scores"]["0"][mode][k]["fit"]["active"]) for r in layout["records"])
            for k in ("window_scene", "window_matched_line", "window_geodesic")
        }
    write_json(
        OUT / "review.json",
        {
            "driver": reference(__file__),
            "collection": receipt,
            "audit": audit(done, prior),
            "legacy_review": reference(FROZEN / "review.py"),
            "geometry": diagnostic,
            "selection": earlier.summarize(diagnostic, plan["arms"][1:]),
            "aggregates": aggregate,
            "budget": earlier.budget_scores(done["synthetic"], plan),
            "diagnostics": diagnoses,
            "native_exact": figures,
            "native_camera": outputs,
            "layout": layout_source,
            "layout_summary": layout_summary,
            "layout_figure": describe_layout(layout, prior, plan, out),
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
