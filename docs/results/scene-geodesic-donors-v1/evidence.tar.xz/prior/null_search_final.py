"""Check false guide acceptance with the expanded search on fresh no-wire scenes."""

from collections import Counter
from itertools import product
from pathlib import Path

import numpy as np
import torch
from probe_scene_context_extent import encode
from probe_scene_window_donors import affinities, catalog, load_encoder
from probe_screened_scene_donors import crop

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.scene_window_donors import rank_scene_windows
from demosaic.screened_scene_donors import retain_near_preview, screening_preview

root = Path(__file__).resolve().parent
query = (256, 256, 256, 256)
frame = (128, 128, 512, 512)
size = 768
trials = 6
seed = 202611171959


def raw_field(i, angle, style, width, shift, level, height, noise):
    yy, xx = np.ogrid[:size, :size]
    a, b = np.cos(angle), np.sin(angle)
    position = a * (xx - (size - 1) / 2) + b * (yy - (size - 1) / 2) - shift
    step = np.zeros((size, size), dtype=np.float64)
    if style != "flat":
        for dx, dy in product(np.linspace(-0.4, 0.4, 5), repeat=2):
            p = position + a * dx + b * dy
            above = p > 0
            step += (above if style == "step" else above & (p < width)) / 25
    cfa = np.array([[0.84, 1], [1, 0.79]])[yy % 2, xx % 2]
    truth = (level + step * height) * cfa
    rng = np.random.default_rng(np.random.SeedSequence([seed, 1, *i]))
    shot, read = noise["shot"], noise["read"]
    observed = rng.poisson(truth / shot) * shot + rng.normal(0, np.sqrt(read), truth.shape)
    return (np.rint(np.clip(observed + 0.03, 0, 1) * 65535) / 65535 - 0.03).astype(np.float32)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    plan = read_json(root / "plan.json")
    model = load_encoder(plan["encoder"])
    boxes = catalog((frame,), query, plan["camera_windows"])
    rows, tally = [], Counter()
    for (pi, (profile, noise)), (si, style), trial in product(
        enumerate(plan["profiles"].items()), enumerate(("flat", "step", "rail")), range(trials)
    ):
        rng = np.random.default_rng(np.random.SeedSequence([seed, 0, si, trial]))
        angle = float(rng.uniform(0.02, np.pi - 0.02))
        params = (
            float(rng.uniform(5, 17)),
            float(rng.uniform(-40, 40)),
            float(rng.uniform(0.028, 0.065)),
            float(rng.uniform(0.06, 0.19)),
        )
        raw = raw_field((pi, si, trial), angle, style, *params, noise)
        preview, grid = screening_preview(raw, "RGGB", [1, 1, 1], np.eye(3), **plan["preview"])
        scene = encode(model, preview, grid)
        local = encode(model, retain_near_preview(preview, grid, frame), grid)
        priors = affinities(scene, local, boxes, query)
        donors = [(crop(raw, box), np.array([0, 1, 1, 2]), box) for box in boxes]
        fits = rank_scene_windows(
            donors, query, shot=noise["shot"], read=noise["read"], affinities=priors
        )
        for arm, fit in fits.items():
            tally[profile, style, arm] += any(fit["active"])
        rows.append(
            {
                "profile": profile,
                "style": style,
                "trial": trial,
                "angle_radians": angle,
                "rail_width_shift_level_height": params,
                "fits": fits,
            }
        )
        print(profile, style, trial, [fit["active"] for fit in fits.values()], flush=True)
    write_json(
        root / "null-search-final.json",
        {
            "producer": reference(__file__),
            "plan": reference(root / "plan.json"),
            "seed": seed,
            "trials_per_cell": trials,
            "query": query,
            "frame": frame,
            "candidate_count": len(boxes),
            "false_acceptance": {" / ".join(key): count for key, count in tally.items()},
            "rows": rows,
            "scope": "Donor gate after full window catalog ranking, before query delivery.",
        },
    )


if __name__ == "__main__":
    main()
