"""Check retained predictions, score the exact targets and render native camera crops."""

import importlib.util
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
previous_review = root.parent / "localized-donor-parallel-v1/review.py"
spec = importlib.util.spec_from_file_location("previous_native_review", previous_review)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
prior.LABELS.update(
    {
        "window_spectral": "Window spectra",
        "window_near": "Near ranking",
        "window_scene": "Full-frame ranking",
        "window_corridor": "Full-frame path",
    }
)


def covered(window, region):
    x, y, w, h = window
    a, b, p, q = region
    intersection = max(0, min(x + w, a + p) - max(x, a)) * max(0, min(y + h, b + q) - max(y, b))
    return intersection / (w * h)


def stats(r, case, arms):
    intended_frames = [a["box"] for a in r["donors"]]
    local = []
    for a in r["donors"]:
        x, y, *_ = a["box"]
        dx, dy, w, h = a["remaining_surface_xywh"]
        local.append((x + dx, y + dy, w, h))
    physical = case["metadata"]["recipe"]
    angles = np.asarray(physical["wire_angles"])
    known = np.stack((np.cos(angles), np.sin(angles)), 1) / np.asarray(physical["periods"])[:, None]
    result = []
    for i, new_fits in enumerate(r["scene_window_fits"]):
        parallel = r["refined_fits_by_role"][i]["parallel"]
        fits = {"parallel": parallel} | new_fits
        result.append(
            {
                arm: {
                    "same_source_frame": all(
                        max(covered(box, frame) for frame in intended_frames) == 1
                        for box in fit["windows"]
                    )
                    if fit.get("windows")
                    else False,
                    "matching_area_fractions": [
                        max(covered(box, truth) for truth in local)
                        for box in fit.get("windows", [])
                    ],
                    "accepted": fit["active"],
                    "center_error_bins": prior.distance(fit, known),
                    "windows": fit.get("windows", []),
                }
                for arm, fit in fits.items()
                if arm in arms
            }
        )
    return result


def summarize(per_case, arms):
    counts = Counter()
    for case in per_case:
        for role, fits in enumerate(case["roles"]):
            for arm in arms:
                f = fits[arm]
                for scope in ("all", case["appearance"]):
                    prefix = (case["profile"], scope, str(role), arm)
                    counts[prefix + ("cases",)] += 1
                    counts[prefix + ("both intended frames",)] += f["same_source_frame"]
                    fractions = f["matching_area_fractions"]
                    counts[prefix + ("both majority true area",)] += (
                        len(fractions) == 2 and min(fractions) >= 0.5
                    )
                    counts[prefix + ("any active",)] += any(f["accepted"])
                    counts[prefix + ("both active",)] += all(f["accepted"])
                    weak = f["center_error_bins"][1]
                    counts[prefix + ("weak near within 1.5 bins",)] += (
                        weak is not None and weak <= 1.5
                    )
    return {" / ".join(k): v for k, v in counts.items()}


def budget_scores(rows, plan):
    score = prior.SCORING
    cases = [read_json(checked(row["case"])) | {"prediction": row["prediction"]} for row in rows]
    arms = plan["arms"]
    output = []
    for profile, setting in plan["settings"].items():
        raw = []
        for case in (r for r in cases if r["profile"] == profile):
            parent, truth, quiet, pred = score.load(case)
            raw.append({arm: score.measure(parent, truth, quiet, pred[arm]) for arm in arms})
        means = {
            arm: {k: np.mean([r[arm][k] for r in raw], axis=0) for k in raw[0][arm]} for arm in arms
        }
        nominal = setting["scale"]
        cap = setting["budget_DN16"]
        measured = {}
        for arm, moments in means.items():
            scale = min(nominal, score.scale_at_budget(moments["quiet_mse"], cap))
            measured[arm] = score.evaluated(moments, scale) | {"scale": scale}
        limit = measured["parent"]["quiet_RMS_DN16"] + cap
        assert all(m["quiet_RMS_DN16"] <= limit + 1e-9 for m in measured.values())
        output.append({"profile": profile, "quiet_limit_DN16": limit, "budgeted": measured})
    return output


def neighborhoods(plan, done, out):
    base = {r["id"]: r for r in read_json(checked(plan["camera_baseline"]))["camera"]}
    labels = ["Query center", "Near 1", "Near 2", "Full 1", "Full 2", "Path 1", "Path 2"]
    plotted = []
    for r in done["camera"]:
        if not r["id"].startswith("mesh-"):
            continue
        key = r["id"]
        row, scene = base[key], base[key]["source"]
        x, y, w, h = r["query"]
        windows = [[x + w // 2 - 64, y + h // 2 - 64, 128, 128]]
        for arm in ("window_near", "window_scene", "window_corridor"):
            windows.extend(r["fits"][arm].get("windows", [None, None]))
        ox, oy, *_ = r["frame"]
        parent = np.load(checked(scene["parent_prediction"]), mmap_mode="r")
        with np.load(checked(scene["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        sheet = Image.new("RGB", (len(labels) * 138 + 8, 158), "#eeeeee")
        draw = ImageDraw.Draw(sheet)
        cells = []
        for i, (label, box) in enumerate(zip(labels, windows, strict=True)):
            px, py = 8 + i * 138, 22
            draw.text((px, 6), label, fill="black")
            if box is None:
                continue
            x, y, w, h = box
            rendered = display(
                parent[..., y - oy : y - oy + h, x - ox : x - ox + w],
                ctx,
                exposure=row["display_exposure"],
            )[0]
            sheet.paste(
                Image.fromarray(np.rint(rendered.transpose(1, 2, 0) * 255).astype(np.uint8)),
                (px, py),
            )
            cells.append({"label": label, "source_xywh": box, "png_xywh": [px, py, w, h]})
        image = out / f"{key}-donors.png"
        sheet.save(image)
        plotted.append(
            {
                "id": key,
                "image": reference(image),
                "cells": cells,
                "checkpoint": scene["checkpoint"],
                "parent": scene["parent_prediction"],
                "display_exposure": row["display_exposure"],
            }
        )
    return plotted


def main():
    source = root / "output/collection.json"
    done = read_json(source)
    plan = read_json(checked(done["plan"]))
    old = read_json(checked(plan["previous"]))
    out = root / "review"
    out.mkdir()
    count = 0
    for section, key in (("synthetic", "prediction"), ("camera", "predictions")):
        for x, y in zip(old[section], done[section], strict=True):
            assert x["id"] == y["id"]
            with np.load(checked(x[key])) as a, np.load(checked(y[key])) as b:
                for name in a.files:
                    np.testing.assert_array_equal(a[name], b[name])
                    count += 1
    aggregates, diagnostics, boards = prior.synth(plan, done, out)
    geometry = []
    for r in done["synthetic"]:
        case = read_json(checked(r["case"]))
        geometry.append(
            {
                "id": r["id"],
                "profile": case["profile"],
                "appearance": case["appearance"],
                "roles": stats(r, case, plan["arms"]),
            }
        )
    camera = prior.camera(plan, done, out)
    for row in camera:
        distances = row["distance"]
        with np.load(checked(row["predictions"])) as f:
            source_row = next(a for a in done["camera"] if a["id"] == row["id"])
            x, y, w, h = row["ROI_xywh"]
            qx, qy, *_ = source_row["query"]
            pixels = np.s_[..., y - qy : y - qy + h, x - qx : x - qx + w]
            for arm in plan["arms"]:
                distances[arm]["vs_fixed_bracket_DN16"] = float(
                    np.sqrt(np.mean((f[arm][pixels].astype(float) - f["parallel"][pixels]) ** 2))
                    * 65535
                )
    write_json(
        out / "result.json",
        {
            "producer": reference(__file__),
            "comparison_script": reference(previous_review),
            "scoring_code": reference(prior.SUMMARY),
            "collection": reference(source),
            "retained_arrays_bit_exact": count,
            "aggregates": aggregates,
            "budget_constrained": budget_scores(done["synthetic"], plan),
            "diagnostics": diagnostics,
            "selection_detail": geometry,
            "selection_counts": summarize(geometry, plan["arms"][1:]),
            "boards": boards,
            "camera": camera,
            "neighborhoods": neighborhoods(plan, done, out),
        },
    )


if __name__ == "__main__":
    main()
