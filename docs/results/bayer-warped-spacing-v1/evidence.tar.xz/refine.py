"""Refine an admitted spectral geometry without expanding candidate admission."""
from importlib.util import spec_from_file_location,module_from_spec
import time

import numpy as np

from nominate import ROOT, EXTERIOR, ORIGINS, tangent_terms, phase
from geometry import windows
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def load(name,path):
    spec=spec_from_file_location(name,path)
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

deliver=load("spacing_refined_delivery",ROOT/"delivery.py")
previous=load("spacing_refined_base",EXTERIOR/"blind.py")


def fit(samples,initial,basis,noise):
    # Movement stays within one nominal grid step for the center and bend.
    bound=np.array((.18,.18,.12))
    params=np.zeros((2,3))
    weights=initial.copy()
    for step in range(5):
        direction,incumbent=previous.projected_step(samples,weights,basis,noise)
        if np.max(abs(direction))<.0005:
            break
        for amount in (1.,.5,.25):
            candidate=np.clip(params+amount*np.clip(direction,-bound,bound),-bound,bound)
            applied=initial+np.einsum("fik,fk->fi",basis,candidate)
            needed=sum(np.square(phase.estimate(tile,applied)[3]).sum()/phase.variance(tile[0],noise) for tile in samples)
            if needed<incumbent:
                weights,params=applied,candidate
                break
        else:
            break
    return weights


def refinement(raw,layout,xy,seed,noise):
    center=seed[:,:2]
    initial=tangent_terms(seed)
    available=windows(raw,layout,xy,center,ORIGINS)
    banks=(available,[pair[::-1]for pair in available])
    model=previous.family_axes(center)
    fitted=[fit([tile[0]for tile in fold],initial,model,noise)for fold in banks]
    return phase.accept(banks,initial,fitted,noise)


def observe(row,plan,nomination,history,original):
    assert row["input"]==nomination["input"]==history["input"]==original["input"]
    assert row["parent"]==history["parent"]==original["parent"]
    with np.load(checked(row["input"]),allow_pickle=False)as f:
        raw={name:f[name]for name in f.files}
    with np.load(checked(row["parent"]),allow_pickle=False)as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    roi=phase.ROI
    anchor=(x+roi[0],y+roi[1])
    crop=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
    target=raw["target"][...,y:y+h,x:x+w]
    predictions={k:parent.copy()for k in ("before","refined")}
    noise=plan["profile"]
    attempts=[]
    for item,prior in zip(nomination["rows"],history["rows"],strict=True):
        a,b=item["repeat"],plan["roles"].index(item["role"])
        assert item["formerly"]==prior["nomination"]
        cfa,wb,matrix=(raw[k][a,b]for k in ("colors","wb","matrix"))
        old,_=deliver.added(crop[a,b],parent[a,b],cfa,wb,matrix,noise,item["selected"],prior)
        baseline=old["warped-query"]
        corrected=baseline
        candidate=item["selected"]["local-warped"]
        if not prior["nomination"]["admitted"] and candidate["admitted"]:
            seed=np.asarray(candidate["seed"])
            center=seed[:,:2]
            parameters,notes=refinement(phase.unpack(raw["packed"][a,b]),cfa,anchor,seed,noise)
            original_ok,old_marks=deliver.query_check(crop[a,b],cfa,roi,center,tangent_terms(seed),noise)
            new_ok,new_marks=deliver.query_check(crop[a,b],cfa,roi,center,parameters,noise)
            if new_ok:
                corrected=deliver.bends.correction(crop[a,b],parent[a,b],cfa,wb,matrix,noise,center,roi,
                          deliver.DOSE,True,{"proposal":parameters})["proposal"]
            attempts.append({"draw":a,"role":item["role"],"old_pass":original_ok,"new_pass":new_ok,
                             "fit":notes,"old_query":old_marks,"new_query":new_marks})
        predictions["before"][a,b]+=baseline
        predictions["refined"][a,b]+=corrected
    stats={k:deliver.totals(v,parent,target,raw)for k,v in predictions.items()}
    assert stats["before"]==original["metrics"]["warped-query"]
    return {"i":row["i"],"source":row["source"],"shape":row["shape"],"input":row["input"],"parent":row["parent"],
            "metrics":stats,"attempts":attempts}


def summary(data):
    rng=np.random.default_rng(9826411)
    chosen=rng.integers(len(data),size=(10000,len(data)))
    out={}
    for k in data[0]["metrics"]["before"]:
        delta=np.array([r["metrics"]["refined"][k]-r["metrics"]["before"][k]for r in data])
        out[k]={"delta":float(delta.mean()),"interval_95":np.quantile(delta[chosen].mean(1),[.025,.975]).tolist()}
    return out


def main():
    begin=time.monotonic()
    refs={p:reference(ROOT/(p+".json"))for p in ("nomination","delivery","replication","replication-checks")}
    originals={k:read_json(checked(p))for k,p in refs.items()}
    nomination=originals["nomination"]
    audit=originals["delivery"]
    trial=originals["replication"]
    assert audit["nominations"]==refs["nomination"] and trial["prior"]==refs["delivery"]
    direct=read_json(checked(nomination["previous"]))["rows"]
    groups={}
    for label,n,b,r,plan in (("initial",nomination["rows"],direct,audit["records"],nomination["plan"]),
                             ("independent",trial["nominations"],trial["baseline"],trial["records"],trial["plan"])):
        plan=read_json(checked(plan))
        results=[observe(row,plan,source,history,row)for source,history,row in zip(n,b,r,strict=True)]
        groups[label]={"rows":results,"summary":{key:summary([r for r in results if r["shape"]==key])for key in ("bent","straight")}}
    write_json(ROOT/"refinement.json",{"driver":reference(__file__),"inputs":refs,"checkpoint":trial["checkpoint"],
              "groups":groups,"seconds":time.monotonic()-begin,
              "scope":"Follow-up after independent replay. Candidate list, base dose and validation thresholds are fixed. Controlled continuous refinement only on the admitted candidates, before the same central check."})


if __name__=="__main__":
    main()
