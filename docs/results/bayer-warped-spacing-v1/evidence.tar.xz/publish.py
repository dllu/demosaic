"""Publish scope, source bindings and actual native warped-spacing observations."""
from pathlib import Path
import hashlib
import shutil
import tarfile

from PIL import Image,ImageChops
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
OUT=Path("docs/results")/ROOT.name
VIEWS=Path("docs/images")/ROOT.name
SAVED=Path("docs/images/bayer-exterior-bend-v1/manifest.json")


def regions(image,panels):
    result={}
    for panel in panels:
        x,y,w,h=panel["png_xywh"]
        assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
        result[panel.get("label") or panel["name"]]=image.crop((x,y,x+w,y+h))
    assert len(result)==len(panels)
    return result


def copy(entry,group):
    path=checked(entry["image"])
    dest=VIEWS/group/path.name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,dest)
    assert reference(dest)["sha256"]==entry["image"]["sha256"]
    entry["image"]["path"]=dest.relative_to(VIEWS).as_posix()
    with Image.open(dest)as image:
        return regions(image,entry["panels"])


def same(x,y):
    return ImageChops.difference(x,y).getbbox() is None


def main():
    OUT.mkdir(exist_ok=True)
    keys=("nomination","delivery","replication","replication-checks","refinement")
    sources={k:reference(ROOT/f"{k}.json")for k in keys}
    data={k:read_json(checked(v))for k,v in sources.items()}
    nomination,development,replica,oracle,refine=(data[k]for k in keys)
    for d in data.values():
        checked(d["driver"])
    assert development["nominations"]==sources["nomination"] and replica["prior"]==sources["delivery"]
    assert oracle["replication"]==sources["replication"]
    assert refine["inputs"]=={k:sources[k]for k in keys[:-1]}
    assert len(development["records"])==20 and len(replica["records"])==16
    ids=set()
    for r in development["records"]+replica["records"]:
        assert r["source"] not in ids
        ids.add(r["source"])
        checked(r["input"])
        checked(r["parent"])
    previous={r["id"]:r for r in read_json(SAVED)["standing"]["rows"]}
    wire=read_json(ROOT/"standing-bound/standing/manifest.json")
    assert wire["nominations"]==sources["nomination"] and len(wire["rows"])==len(previous)==8
    native={}
    for r in wire["rows"]:
        prev=previous[r["id"]]
        assert all(r[k]==prev[k]for k in ("raw","input","noise","roi","native_box","display_exposure","parent"))
        saved=prev["board"]
        original=SAVED.parent/saved["image"]["path"]
        assert reference(original)["sha256"]==saved["image"]["sha256"]
        with Image.open(original)as im:
            pixels=regions(im,saved["panels"])
        new=copy(r["board"],"standing")
        for k in new.keys()&pixels.keys():
            assert same(pixels[k],new[k])
        for label in ("Prior joint crop check","Flat donor fallback","Warped donor fallback","Warped, check query"):
            assert same(pixels["Joint fit, check crop"],new[label])
        r["fallback_returned_prior"]=True
    native["standing"]=wire
    for label,segment in (("initial",development),("replication",replica)):
        boards=[r["native"]for r in segment["records"]if r["native"]]
        for row in boards:
            panels=copy(row["board"],label)
            triplet=copy(row["triplet"],label)
            assert set(triplet)=={"Noisy Malvar","Warped donor fallback","Exact GT"}
            assert all(same(value,panels[key])for key,value in triplet.items())
        native[label]=boards
    assert len(native["initial"])==2 and len(native["replication"])==1
    native["checkpoint"]=development["checkpoint"]
    native["viewed"]={"standing":8,"initial":2,"replication":1,"observations":
          "The initial panels gain some faint second-direction modulation. The held-source example shows little visible change. Sky, foliage, building and coarse fence reproduce the preceding result. Fine cab crossings remain incomplete. Both JPEGs and independent AHD were viewed."}
    manifest=VIEWS/"manifest.json"
    write_json(manifest,native,replace=True)
    files={f"{k}.json":checked(value)for k,value in sources.items()}
    labels=("nominate.py","delivery.py","replicate.py","audit_replication.py","refine.py","standing.py","publish.py",
            "nomination.log","delivery.log","replication.log","replication-preflight.log","replication-field-name-preflight.log",
            "replication-checks.log","refinement.log","standing-bound.log","standing-centered-preflight.log",
            "standing-bound/standing/manifest.json")
    files.update({k:ROOT/k for k in labels})
    for name in ("blind.py","geometry.py","delivery.py"):
        files["previous/"+name]=ROOT.with_name("bayer-exterior-bend-v1")/name
    archive=OUT/"evidence.tar.xz"
    with tarfile.open(archive,"w:xz",preset=4)as pack:
        for name,src in sorted(files.items()):
            pack.add(src,arcname=name,recursive=False)
    with tarfile.open(archive)as pack:
        for name,src in files.items():
            with pack.extractfile(name)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==reference(src)["sha256"]
    write_json(OUT/"publication.json",{"archive":{"path":archive.name,"sha256":reference(archive)["sha256"],"entries":len(files)},
       "manifest":{"path":f"../../images/{ROOT.name}/manifest.json","sha256":reference(manifest)["sha256"]},
       "sources":sources,"checkpoint":development["checkpoint"],"initial_summary":development["summary"],"replication_summary":replica["summary"],
       "followup_refinement":{k:v["summary"]for k,v in refine["groups"].items()},"replication_query_diagnostic":oracle["rows"],
       "initial_nomination_seconds":nomination["seconds"],"replication_seconds":replica["seconds"],
       "scope":"Inference-only. Scoped comparison of 20 development and 16 independent sources, plus eight viewed standing native crops."},replace=True)
    print("Published 36 matched synthetic sources, 11 inspected boards and equivalent standing outputs.")


if __name__=="__main__":
    main()
