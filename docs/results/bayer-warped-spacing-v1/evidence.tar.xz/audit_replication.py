"""Locate the cause of failed query checks in the independent replay."""
from importlib.util import spec_from_file_location,module_from_spec

import numpy as np

from nominate import ROOT, tangent_terms
from diagnose import known_geometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    loader=spec_from_file_location("spacing_audit_delivery",ROOT/"delivery.py")
    deliver=module_from_spec(loader)
    loader.loader.exec_module(deliver)
    bound=reference(ROOT/"replication.json")
    replay=read_json(checked(bound))
    plan=read_json(checked(replay["plan"]))
    note=[]
    for i,source in enumerate(replay["nominations"]):
        if source["geometry"]!="bent":
            continue
        shape=plan["sources"][i]
        frequency,terms=known_geometry(shape["layout"])
        order=np.argsort(-frequency[:,1])
        frequency,terms=frequency[order],terms[order]
        proposal=[row for row in source["rows"] if row["role"]=="present" and row["selected"]["local-warped"]["admitted"]]
        if not proposal:
            continue
        x,y,w,h=plan["query_box"]
        with np.load(checked(source["input"]),allow_pickle=False)as f:
            raw=f["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
            layouts=f["colors"]
        for row in proposal:
            rep=row["repeat"]
            q=plan["roles"].index("present")
            candidate=np.array(row["selected"]["local-warped"]["seed"])
            noise=plan["profile"]
            options={"observed":(candidate[:,:2],tangent_terms(candidate)),
                     "exact_spacing_world_bend":(frequency,terms),
                     "exact_spacing_flat":(frequency,np.zeros_like(terms))}
            verdict={}
            for k,(a,b) in options.items():
                allowed,gain=deliver.query_check(raw[rep,q],layouts[rep,q],deliver.phase.ROI,a,b,noise)
                verdict[k]={"passed":allowed,"reciprocal_gain":gain}
            note.append({"i":i,"repeat":rep,"source":source["source_id"],"input":source["input"],"seed":candidate.tolist(),
                         "exact":frequency.tolist(),"f_error":row["selected"]["local-warped"]["exact_distance"],
                         "query_check":verdict})
    assert len(note)==2
    write_json(ROOT/"replication-checks.json",{"driver":reference(__file__),"replication":bound,"rows":note,
         "scope":"Exact geometry is an evidence diagnostic only. No active-path threshold or delivered image uses these values."})
    print([(r["i"],r["repeat"],r["f_error"],{k:v["passed"]for k,v in r["query_check"].items()})for r in note])


if __name__=="__main__":
    main()
