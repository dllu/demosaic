"""Render the three donor controls at full diagnostic strength."""

from pathlib import Path
from unittest.mock import patch

import torch

from demosaic.experiments.artifacts import reference, write_json

import evaluate_crossfit as r


def render():
    torch.set_num_threads(2)
    plan, models = r.models()
    dose = dict.fromkeys(r.METHODS, 1.0)
    display = {}
    for mode, build in (("camera", r.review.standing), ("exact", r.review.exact)):
        path = r.OUT / "native-full" / mode
        path.mkdir(parents=True, exist_ok=True)
        display[mode] = build(models, dose, path)
    write_json(r.OUT / "review-full.json", {
        "driver": reference(Path(__file__)), "fit": plan, "doses": dose, "views": display,
        "lock": reference(r.OUT / "score-calibration.json"),
        "held": reference(r.OUT / "score-held.json"),
    })


if __name__ == "__main__":
    with patch.object(r.review, "run", render):
        r.run("review")
