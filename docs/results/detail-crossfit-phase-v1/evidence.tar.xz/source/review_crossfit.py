"""Apply the frozen 256-pixel operator to matched native areas of larger cached RAWs."""

from pathlib import Path
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import reference, write_json

import evaluate_crossfit as r
import full_crossfit as full

SIZE = r.operator.SIZE
STATION = 2 * r.operator.local.STRIDE
ORIGINAL_FIELDS = r.operator.fields
PREVIOUS_FIELDS = r.previous.operator.fields
ORIGINAL_PREPARE = r.prepare
CAMERA = {}


def prepare(row, raw, parent, nets):
    if "local_ROI" not in row:
        return ORIGINAL_PREPARE(row, raw, parent, nets)
    x, y, w, h = row["local_ROI"]
    height, width = parent["nominal"].shape[-2:]
    offset = lambda origin, extent, size: int(np.clip(
        round((origin + (extent - SIZE) / 2) / STATION) * STATION, 0, size - SIZE
    ))
    ox, oy = offset(x, w, width), offset(y, h, height)
    if not (32 <= x - ox <= SIZE - w - 32 and 32 <= y - oy <= SIZE - h - 32):
        raise ValueError("Native display ROI would need boundary-padded station inputs")
    area = np.s_[..., oy:oy + SIZE, ox:ox + SIZE]
    plane = np.s_[..., oy // 2:(oy + SIZE) // 2, ox // 2:(ox + SIZE) // 2]

    def crop_fields(operator):
        def receive(d, p, profile):
            packed = d | {"packed": d["packed"][plane]}
            base = p | {"nominal": p["nominal"][area]}
            fields, neutral, notes = operator(packed, base, profile)
            enlarged = {}
            for key, value in fields.items():
                added = np.zeros((len(value), height, width), dtype=value.dtype)
                added[area] = value
                enlarged[key] = added
            return enlarged, neutral, notes

        return receive

    case = {
        "input": row["input"], "raw": row["raw"], "display_roi": row["local_ROI"],
        "operator_roi": [ox, oy, SIZE, SIZE], "global_display_roi": row["global_ROI"],
    }
    assert CAMERA.setdefault(row["id"], case) == case
    with (
        patch.object(r.operator, "fields", crop_fields(ORIGINAL_FIELDS)),
        patch.object(r.previous.operator, "fields", crop_fields(PREVIOUS_FIELDS)),
    ):
        return ORIGINAL_PREPARE(row, raw, parent, nets)


if __name__ == "__main__":
    with patch.object(r, "prepare", prepare):
        r.run("review")
        with patch.object(r.review, "run", full.render):
            r.run("review")
    assert len(CAMERA) == 8
    write_json(r.OUT / "native-adapter.json", {
        "driver": reference(Path(__file__)), "operator": reference(Path(r.operator.__file__)),
        "plan": reference(r.OUT / "plan.json"), "rows": CAMERA,
        "camera": reference(r.OUT / "review-camera.json"),
        "exact": reference(r.OUT / "review-exact.json"),
        "full": reference(r.OUT / "review-full.json"),
        "scope": "A station-aligned 256-pixel RAW slice for the new and prior wide phase operators. Parent, narrow comparator and display pixels remain bound to the full saved input.",
    })
