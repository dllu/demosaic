"""Measure false output on global flat, ramp and edge-only RAW fields."""

from pathlib import Path
from time import monotonic

import numpy as np
from scipy.special import expit

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_crossfit import OUT, operator

SEED = 202611201130
KINDS = ("uniform", "ramp", "edge")
N = 16
PROFILE = {"shot": 0.00128, "read": 6.5536e-6}
COLORS = np.array((0, 1, 1, 2))
ROI = np.s_[..., 64:192, 64:192]


def targets(kind, rng):
    y, x = np.meshgrid(np.arange(256) - 127.5, np.arange(256) - 127.5, indexing="ij")
    light = rng.uniform(0.07, 0.27, size=(N, 1, 1))
    angle = rng.uniform(0, np.pi, size=(N, 1, 1))
    axis = x * np.cos(angle) + y * np.sin(angle)
    delta = rng.uniform(0.035, 0.095, size=(N, 1, 1))
    if kind == "edge":
        edge = rng.uniform(-36, 36, size=(N, 1, 1))
        value = light + delta * expit((axis - edge) / 1.3)
    elif kind == "ramp":
        value = light + delta * axis / 256
    else:
        value = np.broadcast_to(light, (N, 256, 256))
    return value


def observe(exact, rng):
    shot, read = PROFILE["shot"], PROFILE["read"]
    count = rng.poisson(exact / shot) * shot
    analog = count + rng.normal(0, np.sqrt(read), size=count.shape)
    q = np.round(np.clip(analog, 0, 1) * 65535).astype(np.float32) / 65535
    return np.stack([q[:, i::2, j::2] for i, j in ((0, 0), (0, 1), (1, 0), (1, 1))], axis=1)


def evaluate():
    start = monotonic()
    rng = np.random.default_rng(SEED)
    cal = reference(OUT / "score-calibration.json")
    stamp = read_json(checked(cal))
    strengths = {k: v["locked"]["dose"] for k, v in stamp["policy"]["arms"].items()}
    older = reference(OUT.with_name("detail-wide-phase-v1") / "score-calibration.json")
    prev = read_json(checked(older))["policy"]["arms"]
    strengths |= {name: prev[k]["locked"]["dose"] for k, name in (
        ("wide", "old wide"), ("directional", "old harmonic")
    )}
    data = {}
    for kind in KINDS:
        exact = targets(kind, rng)
        raw = observe(exact, rng)
        rows = []
        for i in range(0, N, 4):
            d = {"packed": raw[i:i+4], "colors": COLORS, "matrix": np.eye(3), "wb": np.ones(3)}
            p = {"nominal": np.repeat(exact[i:i+4, None], 3, axis=1)}
            fields, _, _ = operator.fields(d, p, PROFILE)
            prior, _, _ = operator.wide.fields(d, p, PROFILE)
            groups = {k: fields[k] for k in ("split", "directional", "donor only")} | {
                "old wide": prior["wide"], "old harmonic": prior["harmonic"]
            }
            values = {k: np.sqrt(np.mean((m[ROI] * 65535) ** 2, axis=(-2, -1))) for k, m in groups.items()}
            for j in range(len(d["packed"])):
                rows.append({k: {"locked": float(strengths[k] * s[j]), "full": float(s[j])}
                             for k, s in values.items()})
        data[kind] = rows
    result = {kind: {arm: {level: {
        "mean_DN16": float(np.mean([r[arm][level] for r in group])),
        "max_DN16": float(np.max([r[arm][level] for r in group])),
    } for level in ("locked", "full")} for arm in group[0]} for kind, group in data.items()}
    print(result, flush=True)
    write_json(OUT / "null-controls.json", {
        "driver": reference(Path(__file__)), "calibration": cal, "prior_calibration": older,
        "seed": SEED, "profile": PROFILE, "fixtures_per_class": N,
        "scope": "Added linear luma RMS against an exact underlay. Independent noisy RAW supplies all gates.",
        "summary": result, "rows": data, "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    evaluate()
