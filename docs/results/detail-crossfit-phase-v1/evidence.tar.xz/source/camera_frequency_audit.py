"""Check whether the wide folds nominate the earlier measured cab frequencies."""

from pathlib import Path
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_crossfit import OUT, operator, review

# Measured exterior RAW pairs reported by the prior Bayer carrier scale study.
# Convert its (fx, fy) notation to the operator's (fy, fx).
PAIR = {
    "left": np.array([(0.1152, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
    "right": np.array([(0.1172, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
}
TOL = 0.009


def count(details, rf, station):
    follow = lambda q: q["nominated"] & station
    result = []
    for f in rf:
        parts = []
        for q in details:
            observed = q["phase"]
            e = np.minimum(np.linalg.norm(observed - f, axis=-1),
                           np.linalg.norm(observed + f, axis=-1))
            match = follow(q) & (e <= TOL)
            parts.append((match, match & q["checked"], match & q["checked"] & q["center"]))
        result.append([int(np.logical_or(x, y).sum()) for x, y in zip(*parts, strict=True)])
    return result


def supplied(prior, swap, size):
    a, b = prior[::(-1 if swap else 1)]
    return tuple((np.broadcast_to(f, (size, 4, 2)), np.full((size, 4), 1e6)) for f in (a, b))


if __name__ == "__main__":
    adapter = reference(OUT / "native-adapter.json")
    plan = read_json(checked(adapter))
    rows = {}
    for item, d, p, metadata in review.Cases("camera"):
        label = item["id"]
        if not label.startswith("mesh-"):
            continue
        roi = plan["rows"][label]
        assert roi["input"] == item["input"]
        ox, oy, w, h = roi["operator_roi"]
        x, y, dw, dh = roi["display_roi"]
        area = np.s_[..., oy:oy+h, ox:ox+w]
        raw = np.s_[..., oy//2:(oy+h)//2, ox//2:(ox+w)//2]
        station = np.arange(16, 256, 32)
        selected = ((station+oy >= y) & (station+oy < y+dh))[:, None] & (
            (station+ox >= x) & (station+ox < x+dw)
        )[None, :]
        profile = item["profile"]
        packed = d | {"packed": d["packed"][raw]}
        base = p | {"nominal": p["nominal"][area]}
        pair = PAIR[label.rsplit("-", 1)[-1]]
        _, _, usual = operator.fields(packed, base, profile)
        original = count(usual, pair, selected)
        fixed = []
        for index in range(2):
            proposal = supplied(pair, index == 0, len(packed["packed"]))
            with patch.object(operator, "nominate", lambda _: proposal):
                _, _, seen = operator.fields(packed, base, profile)
            fixed.append(count(seen, pair, selected)[index])
        rows[label] = {"input": item["input"], "stations": int(selected.sum()),
                       "earlier_measured_pair_fy_fx": pair.tolist(), "ordinary": original, "supplied": fixed}
    write_json(OUT / "camera-frequency.json", {
        "driver": reference(Path(__file__)), "review": adapter, "tolerance_cycles_per_pixel": TOL,
        "source": reference(Path.cwd() / "docs/bayer-carrier-scale.md"),
        "column_order": ["frequency nominated", "exterior phase validated", "both witnesses pass"],
        "rows": rows, "scope": "Real measured frequency diagnostic. Earlier noisy exterior peaks are supplied in the weak slot one at a time. No clean target is used.",
    })
