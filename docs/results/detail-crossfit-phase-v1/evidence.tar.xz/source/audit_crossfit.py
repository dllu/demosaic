"""Audit source separation and sparse false admissions at native stations."""

import json
from pathlib import Path
import sys
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_crossfit import HERE, OUT, operator, scoring
from collect_wire_gate import identities

sys.path.insert(0, str(HERE.with_name("direct-detail-response-v1")))
from audit_sources import CORPUS, LOCAL, matches

TOL = 0.0234375
ROI = np.s_[2:6, 2:6]


def dataset():
    plan = reference(OUT / "confirmation/plan.json")
    selection = read_json(checked(plan))
    ids = identities(r["source"] for r in selection["groups"]["held"])
    assert len(ids) == 112
    historical = selection["prior_confirmations"] | {"original": selection["previous_plan"]}
    for ref in historical.values():
        prior = read_json(checked(ref))["groups"]
        assert all(ids.isdisjoint(identities(r["source"] for r in rows)) for rows in prior.values())
    with checked(selection["training_manifest"]).open() as f:
        assert ids.isdisjoint(identities(map(json.loads, f)))
    assert ids.isdisjoint(identities(read_json(checked(selection["fixed427"]))["source_metadata"]))
    corpus, local = reference(CORPUS), reference(LOCAL)
    lineage, last = read_json(checked(corpus)), read_json(checked(local))
    assert lineage["checkpoint"] == last["parent"] and last["checkpoint"] == selection["parent"]
    checked_rows = 0
    for ref in lineage["source_traces"]:
        with checked(ref).open() as f:
            for observation in map(json.loads, f):
                for s in observation["sources"]:
                    if s["kind"] == "photographic":
                        assert not matches(s, ids)
                        checked_rows += 1
    local_rows = 0
    for ref in last["segments"]:
        with checked(ref["observations"]).open() as f:
            for s in map(json.loads, f):
                assert not matches(s, ids)
                local_rows += 1
    assert (checked_rows, local_rows) == (559808, 5000)
    return {"source_plan": plan, "prior_plans": historical, "sources": len(ids) // 2,
            "corpus": corpus, "corpus_visits": checked_rows, "local": local, "local_visits": local_rows}


def summarize_station(role, box, weak, details):
    stages = {"nomination": [], "local only": [], "held only": [],
              "both gates": [], "rotated": [], "weak both gates": []}
    for v in details:
        f = v["phase"][role][ROI]
        df = np.minimum(np.linalg.norm(f - weak, axis=-1), np.linalg.norm(f + weak, axis=-1))
        base = v["nominated"][role][ROI] & box
        center = v["center"][role][ROI]
        checked = v["checked"][role][ROI]
        rotated = v["rotated"][role][ROI]
        stages["nomination"].append(base)
        stages["local only"].append(base & center)
        stages["held only"].append(base & checked)
        stages["both gates"].append(base & checked & center)
        stages["rotated"].append(base & rotated & center)
        stages["weak both gates"].append(base & checked & center & (df <= TOL))
    return {
        "unique_stations": int(box.sum()),
        "any_fold": {k: int(np.logical_or.reduce(v).sum()) for k, v in stages.items()},
        "station_folds": {k: int(np.sum(v)) for k, v in stages.items()},
    }


def spatial_counts(source):
    output = []
    for row, d, p, ref in scoring.loads(source):
        if row["kind"] != "wire":
            continue
        _, _, phase = operator.fields(d, p, row["profile"])
        geom = row["fixture"]["geometry"]
        weak = np.asarray(geom["frequency"][1])[::-1]
        sup = d["support"].reshape(8, 32, 8, 32)
        gap = ((sup == 0).mean((1, 3)) >= 0.25)[ROI]
        intact = ((sup >= 0.97).mean((1, 3)) >= 0.85)[ROI]
        if geom["family"] not in ("ellipse", "strip"):
            gap[:] = False
            intact[:] = True
        unit = np.ones_like(gap)
        scores = {name: summarize_station(j, mask, weak, phase) for name, j, mask in (
            ("intact", 0, intact), ("gap", 0, gap), ("exterior only", 1, gap),
            ("strong only", 2, unit), ("flat", 3, unit),
        )}
        output.append({"id": row["id"], "input": ref, "scores": scores})
    group = {}
    for k, scores in output[0]["scores"].items():
        rows = [r["scores"][k] for r in output]
        group[k] = {"unique_stations": sum(r["unique_stations"] for r in rows)}
        for how in ("any_fold", "station_folds"):
            group[k][how] = {m: sum(r[how][m] for r in rows) for m in scores[how]}
    return group, output


if __name__ == "__main__":
    start = monotonic()
    source = reference(OUT / "confirmation/held/completed.json")
    separation = dataset()
    totals, rows = spatial_counts(source)
    print(totals, flush=True)
    write_json(OUT / "audit.json", {
        "driver": reference(Path(__file__)), "operator": reference(Path(operator.__file__)),
        "collection": source, "source_audit": separation, "summary": totals, "rows": rows,
        "seconds": monotonic() - start, "tolerance_cycles_per_pixel": TOL,
    })
