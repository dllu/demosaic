"""Capture a fresh matched source panel for independently validated wide nominations."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
OLD = "detail-wide-phase-v1"
SEED = 202611201126
spec = spec_from_file_location("wide_capture_design", HERE.with_name(OLD) / "capture_wide.py")
wide = module_from_spec(spec)
spec.loader.exec_module(wide)


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    layout = folder / "plan.json"
    if not layout.exists():
        with patch.object(wide, "SEED", SEED), patch.object(wide, "PROTECTED", (*wide.PROTECTED, OLD)):
            plan = wide.select()
        write_json(layout, plan | {"followup_driver": reference(Path(__file__)),
                                   "selection_operator": reference(Path(wide.__file__))})
    with patch.object(wide.prior.c, "OUT", folder), patch.object(wide.prior.c, "SEED", SEED):
        wide.prior.c.collect("held")
