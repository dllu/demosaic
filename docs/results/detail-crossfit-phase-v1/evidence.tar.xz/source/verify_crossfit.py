"""Check fold independence, signed alignment and finite native delivery."""

from pathlib import Path
import sys

import numpy as np

from crossfit_phase import data_in_fold, nominate, confidence, fields, split_layout, HERE, SIZE

sys.path.insert(0, str(HERE.with_name("detail-wide-phase-v1")))
from verify_wide import field, PROFILE, FREQUENCIES

if __name__ == "__main__":
    data = field()
    masks = split_layout()
    assert (masks.sum(axis=0) == 1).all()
    for k in (0, 1):
        source = data_in_fold(data, PROFILE, k)
        reserved = data_in_fold(data, PROFILE, 1 - k)
        assert not np.any(source[4] & reserved[4])
        planned = nominate(source)
        replacement = data["packed"].copy()
        replacement[..., masks[1-k]] = 0.83 - replacement[..., masks[1-k]]
        intervened = nominate(data_in_fold(data | {"packed": replacement}, PROFILE, k))
        for a, b in zip(planned, intervened, strict=True):
            for x, y in zip(a, b, strict=True):
                np.testing.assert_array_equal(x, y)
        assert np.max(np.linalg.norm(planned[1][0] - FREQUENCIES[1], axis=-1)) <= 0.008
        (valid, evidence), (rotated, wrong) = confidence(source, reserved, planned)
        assert np.min(evidence) > 2.5 and np.min(valid) > 0.5
        assert np.max(rotated) == 0
        print("fold", k, "signed", evidence.round(4).tolist(), "quarter-cycle", wrong.round(4).tolist())
    data |= {"matrix": np.eye(3), "wb": np.ones(3)}
    parent = {"nominal": np.full((1, 3, SIZE, SIZE), 0.135)}
    moves, neutral, _ = fields(data, parent, PROFILE)
    assert all(np.isfinite(x).all() and x.shape == (1, SIZE, SIZE) for x in moves.values())
    assert np.linalg.norm(moves["directional"]) > np.linalg.norm(moves["rolled directional"])
