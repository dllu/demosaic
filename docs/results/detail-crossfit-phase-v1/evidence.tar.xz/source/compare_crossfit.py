"""Compare validated and unchecked donor proposals at the same measured wire response."""

from pathlib import Path
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_crossfit import OUT, METHODS, scoring

METRICS = (
    "weak_response_pp", "intact_increment_RMS_DN16", "gap_continuing_strong_RMS_DN16",
    "gap_weak_RMS_DN16", "gap_RMS_DN16", "exterior_only_weak_RMS_DN16", "exact_flat_RMS_DN16",
)
EVALUATIONS = ("calibration", "prior-held", "held")


def compare(data):
    rows = [r for r in data["rows"] if r["kind"] == "wire"]
    lock = {k: v["locked"]["dose"] for k, v in data["policy"]["arms"].items()}
    stat = lambda arm, metric, dose: scoring.wire_values(rows, arm, metric, dose)
    gain = lambda k, d: float((stat(k, METRICS[0], d) - stat("nominal", METRICS[0], 0)).mean())
    earlier = ("old wide", "old harmonic")
    a, b = "split", "directional"
    maximums = {k: gain(k, 1) for k in (a, b)}
    common = min(maximums.values())
    matched = {k: common / v for k, v in maximums.items()} if common > 1e-10 else {}
    tiers = {k: gain(k, 0) for k in earlier}
    rng = np.random.default_rng(202611201131)
    effects = {}
    for metric in METRICS:
        here = stat(b, metric, lock[b])
        other = {
            "checked minus unchecked, locked": (here, stat(a, metric, lock[a])),
            "checked minus rotated, locked": (here, stat("rolled directional", metric, lock[b])),
            "checked minus earlier harmonic, locked": (here, stat("old harmonic", metric, 0)),
            "checked minus earlier plain, locked": (here, stat("old wide", metric, 0)),
        }
        if matched:
            other["checked minus unchecked, matched"] = (
                stat(b, metric, matched[b]), stat(a, metric, matched[a])
            )
        for k, response in tiers.items():
            if 0 < response < maximums[b]:
                other[f"checked minus {k}, matched"] = (
                    stat(b, metric, response / maximums[b]), stat(k, metric, 0)
                )
        intervals = {}
        for name, (u, v) in other.items():
            difference = u - v
            choice = rng.integers(len(difference), size=(12000, len(difference)))
            intervals[name] = [float(difference.mean()),
                               *np.quantile(difference[choice].mean(1), [0.025, 0.975]).tolist()]
        effects[metric] = intervals
    return {
        "locked_weak_gain": {k: gain(k, lock[k]) for k in METHODS},
        "full_weak_gain": maximums,
        "common_weak_response": common,
        "matched_doses": matched,
        "prior_operating_point_response": tiers,
        "intervals": effects,
    }


if __name__ == "__main__":
    refs = {g: reference(OUT / f"score-{g}.json") for g in EVALUATIONS}
    with patch.object(scoring, "METHODS", METHODS):
        records = {k: compare(read_json(checked(v))) for k, v in refs.items()}
    print(records["held"], flush=True)
    write_json(OUT / "comparisons.json", {
        "driver": reference(Path(__file__)), "inputs": refs, "results": records,
        "scope": "Matched responses are post-evaluation diagnostics with fixed target means. Locked results keep the pre-confirmation strengths.",
    })
