"""Reduce fresh evidence and render exact-reference native crop triplets."""

import os
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from replay import ROOT,DISPLAY,score


METHODS=('projective','short','audited','crossed','local deficit')


def main():
    old=read_json(ROOT/'fresh.json');plan=read_json(checked(old['plan']))
    alternate=read_json(ROOT/'local-fresh.json')
    additions={r['id']:r for r in alternate['rows']}
    choices={
      'iso400-disk-g132':'crossed', 'iso400-disk-g135':'crossed',
      'iso400-band-g130':'audited','iso400-step-g135':'audited',
      'iso400-disk-g131':'crossed',
    }
    pictures=ROOT/'native';pictures.mkdir();images=[];rows=[]
    for binding in old['cases']:
        item=read_json(checked(binding)); name=item['id']; entry=item['entry']; local=additions[name]
        assert local['case']==binding
        with np.load(checked(item['arrays']),allow_pickle=False)as values:
            arrays=dict(values)
        with np.load(checked(local['parts']),allow_pickle=False)as parts:
            searched=dict(parts)
        measurements={}
        for ctx in ('matching','unrelated'):
            stats={};masks={k:arrays[k]for k in ('strong_phase','weak_phase','support')}
            candidates={m:(searched[ctx] if m=='local deficit'else arrays[ctx+'-'+m])for m in METHODS}
            baseline=candidates['projective']
            measurements[ctx]={}
            for m,d in candidates.items():
                expected=local['metrics'][ctx]if m=='local deficit'else item['metrics'][ctx+'-'+m]
                actual=score(arrays['parent'],d,arrays['target'],masks)
                np.testing.assert_allclose(actual['response'],expected['response'],rtol=0,atol=1e-12)
                for k in ('gap_added_RMS_DN16','gap_error_RMS_DN16'):
                    if actual[k]is not None:
                        np.testing.assert_allclose(actual[k],expected[k],rtol=0,atol=1e-12)
                difference=d.astype(float)-baseline
                stats[m]=actual|{'extra_attenuation':[bool(np.any(a))for a in difference],
                                  'extra_RMS_DN16':[float(np.sqrt(np.mean(a*a))*65535)for a in difference]}
            measurements[ctx]=stats
        rows.append({'id':name,'profile':entry['profile'],'layout':entry['layout'],'record':binding,'values':measurements})
        if name in choices:
            role=1
            labels=['Noisy Malvar','Local trunk','Wide support','Short support','Audited gap','Crossed and audited','Local deficit','Exact GT']
            parent=arrays['parent'][role]
            vals=[noisy_malvar(arrays)[role],parent]
            x,y,w,h=DISPLAY
            for m in METHODS:
                corr=searched['matching']if m=='local deficit'else arrays['matching-'+m]
                rendered=parent.copy();rendered[:,y:y+h,x:x+w]+=corr[role]; vals.append(rendered)
            vals.append(arrays['target'][role])
            metadata={'case':binding,'arrays':item['arrays'],'checkpoint':plan['checkpoint'],
                     'noise':plan['noise'][entry['profile']],'CFA':item['shape']['CFA'],'seed':entry['seed']}
            images.append(native_board(pictures,name,vals,{k:arrays[k][role:role+1]for k in ('wb','matrix')},
                metadata,labels=tuple(labels),triplet_indices=(0,2+METHODS.index(choices[name]),len(vals)-1),
                roi=DISPLAY,exposure=1,contrast=8))
    assert len(images)==5 and len(rows)==30
    groupings={
        **{f'iso400/{l}':[i for i in rows if i['profile']=='iso400'and i['layout']==l]
           for l in ('continuous','step','band','disk')},
        'iso6400/gaps':[i for i in rows if i['profile']=='iso6400']}
    summary={}
    for key,data in groupings.items():
        assert len(data)==6
        summaries={}
        for ctx in ('matching','unrelated'):
            summaries[ctx]={}
            for m in METHODS:
                vals=[r['values'][ctx][m]for r in data]
                result={
                    'weak_response':mean(v['response'][0]for v in vals)*100,
                    'wire_error':mean(v['increment_RMS_DN16'][0]for v in vals),
                    'altered_roles':[sum(v['changed'][i]for v in vals)for i in range(3)],
                    'attenuated_roles':[sum(v['extra_attenuation'][i]for v in vals)for i in range(3)],
                }
                for k in ('gap_added_RMS_DN16','gap_error_RMS_DN16'):
                    if vals[0][k]is not None:
                        result[k]=mean(v[k]for v in vals);result['max_'+k]=max(v[k]for v in vals)
                summaries[ctx][m]=result
        summary[key]=summaries
        print(key)
        for m,d in summaries['matching'].items():
            print(m,round(d['weak_response'],2),round(d['wire_error'],2),
                  tuple(round(d.get(k,0),2)for k in ('gap_added_RMS_DN16','gap_error_RMS_DN16')),
                  d['altered_roles'],d['attenuated_roles'])
    write_json(ROOT/'summary.json',{'driver':reference(__file__),'primary':reference(ROOT/'fresh.json'),
              'local_deficit':reference(ROOT/'local-fresh.json'),'rows':rows,'means':summary,'native':images})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
