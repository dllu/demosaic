"""Isolate local-deficit evidence on saved RAW and broad predictions."""

import argparse
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from deficit import search
from replay import ROOT,SOURCE,CENTRE,DISPLAY,infer_geometry,score,window
from standing import legacy


def apply(broad, raw, colors, pair, noise, query, roi):
    if not np.any(broad):
        return broad,{'status':'parent'}
    p=window(raw,query,phase=2)
    mask,note=search(p,colors,pair,noise)
    if mask is None:
        return broad,note
    x,y,w,h=roi
    cropped=window(mask,(x-query[0],y-query[1],w,h))
    return (broad*(1-cropped[None])).astype(broad.dtype),note


def synth(mode):
    label='local-'+mode
    original=read_json((SOURCE if mode=='dev' else ROOT)/'fresh.json')
    plan=read_json(checked(original['plan']));out=ROOT/label;out.mkdir()
    rows=[]
    for binding in original['cases']:
        case=read_json(checked(binding))
        entry=case if mode=='dev'else case['entry']
        noise=plan['noise'][entry['profile']]
        with np.load(checked(case['array' if mode=='dev'else'arrays']),allow_pickle=False)as a:
            values=dict(a)
        rgb=values['parent'];raw=values['packed'];color=values['colors']
        outcomes={};notes={};arrays={}
        for tag in ('matching','unrelated'):
            broad=values[tag+'-projective']
            trace=case['priors'][tag]if mode=='dev'else case['witness'][tag]['exterior']
            output=[];where=[]
            for i in range(len(broad)):
                guide=None
                if np.any(broad[i]):
                    scene=window(raw[i],CENTRE,phase=2)
                    guide,_=infer_geometry(trace,scene,color[i],noise,(383.5,383.5))
                delta,note=apply(broad[i],raw[i],color[i],guide,noise,CENTRE,DISPLAY)
                output.append(delta);where.append(note)
            d=np.stack(output)
            assert np.max(np.abs(d)-np.abs(broad))<=1e-12
            arrays[tag]=d;notes[tag]=where
            outcomes[tag]=score(rgb,d,values['target'],{k:values[k]for k in ('strong_phase','weak_phase','support')})
        dest=out/(case['id']+'.npz');np.savez_compressed(dest,**arrays)
        delta=outcomes['matching']; where=notes['matching'][1]
        print(case['id'],where['status'],round(where.get('audit',{}).get('z',0),2),where.get('patches_nonzero',0),
            round(delta['response'][0],3),round(delta['gap_added_RMS_DN16'] or 0,3),flush=True)
        rows.append({'id':case['id'],'case':binding,'profile':entry['profile'],'layout':entry['layout'],
            'parts':reference(dest),'notes':notes,'metrics':outcomes})
    write_json(ROOT/(label+'.json'),{'method':reference(ROOT/'deficit.py'),'driver':reference(__file__),
        'input':reference((SOURCE if mode=='dev'else ROOT)/'fresh.json'),'rows':rows})


def camera():
    cached=read_json(SOURCE/'camera.json'); earlier=read_json(ROOT/'pooled-camera.json')
    aligned={r['id']:r for r in cached['views']}
    out=ROOT/'local-camera';out.mkdir();rows=[]
    for case in earlier['rows']:
        view=aligned[case['id']]
        with np.load(checked(view['input']),allow_pickle=False)as a:
            data={k:a[k]for k in ('packed','colors','wb','matrix')}
        raw=data['packed'][0];color=data['colors'][0];box=case['query'];roi=case['ROI']
        with np.load(checked(case['delta']),allow_pickle=False)as a:
            correction=a['broad']
        pair=None
        if np.any(correction):
            pair,_=infer_geometry(view['donor_windows'],window(raw,box,phase=2),color,view['noise'],np.asarray(box[:2])+127.5)
        d,notes=apply(correction,raw,color,pair,view['noise'],box,roi)
        field=np.load(checked(view['matched_parent'] if 'matched_parent'in view else view['parent']),allow_pickle=False)[0]
        base=window(field,roi)
        old={'image':case['image'],'panels':[p for p in case['panels']if p['label']!='Audited gap']}
        x,y,w,h=roi
        candidate=legacy.pixel(base+d,data,(0,0,w,h),case['exposure'])
        image,rects=legacy.insert_camera_panels(out,case['id'],old,'Crossed and audited',[('Local deficit',candidate)])
        new=out/(case['id']+'.npy');np.save(new,d,allow_pickle=False)
        rms=float(np.sqrt(np.mean((d.astype(float)-correction)**2))*65535)
        print(case['id'],notes['status'],notes.get('audit'),round(rms,3),flush=True)
        rows.append({'id':case['id'],'source':case['image'],'image':image,'panels':rects,'notes':notes,
          'extra_RMS_DN16':rms,'delta':reference(new),'ROI':roi,'noise':view['noise'],'exposure':case['exposure']})
    write_json(ROOT/'local-camera.json',{'method':reference(ROOT/'deficit.py'),'driver':reference(__file__),
        'source':reference(ROOT/'pooled-camera.json'),'checkpoint':cached['checkpoint'],'rows':rows})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('dev','fresh','camera'));args=p.parse_args()
    camera()if args.mode=='camera'else synth(args.mode)
