"""Look for evidence against continuing an already measured rear carrier."""

from dataclasses import dataclass
from itertools import product
import math

import numpy as np

from demosaic.isolated_line import coordinates, native_sites


@dataclass(frozen=True)
class Region:
    family: str
    u: float
    v: float
    center: float
    radius: float

    def mask(self,x,y):
        if self.family=='band':
            distance=abs(self.u*x+self.v*y-self.center)
        else:
            distance=np.hypot(x-self.u,y-self.v)
        t=np.clip((self.radius+12-distance)/12,0,1)
        return t*t*(3-2*t)


REGIONS = tuple(
    Region('band',math.cos(angle),math.sin(angle),center,radius)
    for angle,center,radius in product(np.arange(12)*np.pi/12,range(-48,49,16),(20,30,40))
) + tuple(
    Region('disk',x,y,0.0,radius) for x,y,radius in product(range(-48,49,24),range(-48,49,24),(24,36,48))
)


def measurement(raw, colors, pair, noise, offset=0, *, occluded=True):
    """Use native Bayer positions and reserve whole columns for a final audit."""
    from mesh import ribbon
    x,y=native_sites(raw.shape[-2:],(-(2*raw.shape[-1]-1)/2,-(2*raw.shape[-2]-1)/2))
    p,q=(ribbon(x,y,c) for c in pair)
    if occluded:
        q=q*(1-p)
    c=np.broadcast_to(np.asarray(colors)[:,None,None],raw.shape)
    folds=np.broadcast_to((np.indices(raw.shape[-2:])[1]+offset)%4,raw.shape)
    nuis=np.stack((np.ones_like(x),x/128,y/128,x*x/16384,x*y/16384,y*y/16384,p),axis=-1)
    return x.ravel(),y.ravel(),c.ravel(),folds.ravel(),q.ravel(),nuis.reshape((-1,nuis.shape[-1])),raw.ravel().astype(float),noise


def coefficients(a,b):
    return np.linalg.solve(a.T@a,a.T@b)


def nominate(data,train):
    x,y,colors,_,wave,nuis,raw,noise=data
    x,y=x[train],y[train]
    vote=np.zeros(len(x));power=np.zeros(len(x))
    for color in range(3):
        use=colors[train]==color
        q,b,v=wave[train][use],nuis[train][use],raw[train][use]
        root=1/math.sqrt(noise['shot']*max(1e-4,float(np.median(v)))+noise['read'])
        q=q-b@coefficients(b,q)
        v=v-b@coefficients(b,v)
        amp=float(q@v/max(q@q,1e-16))
        change=-(amp*root)*q
        vote[use]=change*(v*root+change)
        power[use]=change*change
    best=None
    for j in range(0,len(REGIONS),24):
        chunk=REGIONS[j:j+24]
        weights=np.stack([m.mask(x,y) for m in chunk],axis=1)
        total=power@(weights*weights)
        contrast=vote@weights-0.5*total
        score=contrast/np.sqrt(np.maximum(total,1e-12))
        score=np.where(total>=4,score,-np.inf)
        k=int(np.argmax(score))
        proposal=(float(score[k]),chunk[k])
        if np.isfinite(score[k]) and (best is None or proposal[0]>best[0]):
            best=proposal
    return best


def forecast(data, train, test, spatial):
    _,_,colors,_,wave,nuis,raw,noise=data
    overlap=power=0.0
    for color in range(3):
        discover=train&(colors==color)
        check=test&(colors==color)
        y1,y2=raw[discover],raw[check]
        both=np.column_stack((nuis,spatial))
        narrow=wave*(1-spatial)
        args=(both[discover],both[check])
        norm=1/(noise['shot']*max(1e-4,float(np.median(y1)))+noise['read'])
        w0=np.column_stack((args[0],wave[discover])); w1=np.column_stack((args[0],narrow[discover]))
        p0=np.column_stack((args[1],wave[check]))@coefficients(w0,y1)
        p1=np.column_stack((args[1],narrow[check]))@coefficients(w1,y1)
        delta=p1-p0
        overlap+=norm*float((y2-p0)@delta)
        power+=norm*float(delta@delta)
    return {'z':(overlap-.5*power)/math.sqrt(max(power,1e-12)), 'gain':2*overlap-power,'change_power':power}


def confirm_gap(raw, colors, pair, noise, offset=0, *, occluded=True):
    """Find a drop in repeated structure, compare both folds, then audit once."""
    data=measurement(raw,colors,pair,noise,offset,occluded=occluded)
    x,y,_,partition,*_=data
    a,b=partition==1,partition==2
    marks=[nominate(data,t) for t in (a,b)]
    if any(m is None for m in marks):
        return None,{'status':'no proposal'}
    candidate=[m.mask(x,y) for _,m in marks]
    passes=[forecast(data,t,v,mask)for (t,v),mask in zip(((a,b),(b,a)),candidate,strict=True)]
    intersection=float(np.minimum(*candidate).sum()/max(np.maximum(*candidate).sum(),1e-12))
    exact_mask=np.minimum(*candidate)
    audit=forecast(data,a|b,partition==3,exact_mask) if intersection>=.4 else None
    stable=(audit is not None and min(p['z']for p in passes)>0.75 and audit['z']>1.0)
    receipt={'status':'accepted'if stable else 'withheld','candidates':[vars(m)for _,m in marks],
             'proposal_scores':[z for z,_ in marks],'overlap':intersection,'cross':passes,'audit':audit}
    return ([m for _,m in marks] if stable else None),receipt


def complete_mask(proposals, shape):
    x,y=coordinates(*shape,origin=(-(shape[1]-1)/2,-(shape[0]-1)/2))
    return np.minimum(*(proposal.mask(x,y)for proposal in proposals))
