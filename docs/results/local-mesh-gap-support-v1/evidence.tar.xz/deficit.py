"""Estimate local evidence against continuing a measured mesh amplitude."""

import math

import numpy as np

from demosaic.isolated_line import coordinates
from gap import coefficients,forecast,measurement

CENTERS=tuple(range(-108,109,27))
HALF_WIDTH=34
TAPER=32


def orthogonal(values, nuisance):
    return values-nuisance@coefficients(nuisance,values)


def contrast(data, train, test, distant, local):
    _,_,colors,_,wave,nuisance,raw,noise=data
    power=signal=prediction_variance=0.0
    for k in range(3):
        outer=train&distant&(colors==k)
        inner=test&local&(colors==k)
        if not (outer.sum()>72 and inner.sum()>48):
            return 0.0,1.0
        outside=orthogonal(np.column_stack((wave[outer],raw[outer])),nuisance[outer])
        a,v=outside.T
        fit_info=float(a@a)
        if fit_info<1e-8:
            return 0.0,1.0
        gain=float(a@v)/fit_info
        inside=orthogonal(np.column_stack((wave[inner],raw[inner])),nuisance[inner])
        b,v=inside.T
        noise_power=noise['shot']*max(float(np.median(raw[outer])),1e-4)+noise['read']
        info=float(b@b)
        power+=gain**2*info/noise_power
        signal+=gain*float(b@v)/noise_power
        prediction_variance+=gain**2*info**2/(noise_power*fit_info)
    if power<4:
        return 0.0,1.0
    return (power-signal)/math.sqrt(power+prediction_variance),signal/power


def search(raw,colors,pair,noise,*,occluded=True):
    data=measurement(raw,colors,pair,noise,occluded=occluded)
    x,y,_,slots,*_=data
    a,b=slots==1,slots==2
    centers=[]
    for cx in CENTERS:
        for cy in CENTERS:
            distance=np.maximum(abs(x-cx),abs(y-cy))
            outer=distance>HALF_WIDTH+16
            local=distance<=HALF_WIDTH
            both=[contrast(data,t,e,outer,local)for t,e in ((a,b),(b,a))]
            z=min(s[0]for s in both)
            fraction=max(s[1]for s in both)
            certainty=np.clip((z-1.25)/1.75,0,1)
            difference=np.clip((0.8-fraction)/0.6,0,1)
            strength=float(certainty*difference)
            centers.append((cx,cy,strength,tuple(both)))
    # Determine one field on A/B, then make one forecast on untouched D.
    proposed=paint(x,y,centers)
    count=sum(v[2]>0 for v in centers)
    if not count:
        return None,{'status':'no local deficit','patches_nonzero':0}
    audit=forecast(data,a|b,slots==3,proposed)
    result={'status':'accepted'if audit['z']>1.5 else 'withheld','audit':audit,
            'patches_nonzero':count,'witness':centers}
    if audit['z']<=1.5:
        return None,result
    w,h=raw.shape[-1]*2,raw.shape[-2]*2
    u,v=coordinates(h,w,origin=(-(w-1)/2,-(h-1)/2))
    return paint(u,v,centers),result


def paint(x,y,centers):
    numerator=np.zeros_like(x);denominator=np.zeros_like(x)
    for cx,cy,amount,_ in centers:
        weight=np.maximum(0,1-abs(x-cx)/TAPER)*np.maximum(0,1-abs(y-cy)/TAPER)
        numerator+=amount*weight
        denominator+=weight
    return numerator/np.maximum(denominator,1e-12)
