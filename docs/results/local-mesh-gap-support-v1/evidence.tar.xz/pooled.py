"""Pool two discovery quarters and test one fixed gap prediction on the third."""

import numpy as np

from gap import complete_mask, forecast, measurement, nominate


def detect(raw, colors, pair, noise, *, occluded=True):
    if not np.isfinite(raw).all():
        raise ValueError('Require finite RAW in the fitting box')
    data=measurement(raw,colors,pair,noise,occluded=occluded)
    x,y,_,split,*_=data
    train=(split==1)|(split==2)
    withhold=split==3
    pooled=nominate(data,train)
    if pooled is None:
        return None, {'status':'no proposal'}
    proposed_z,region=pooled
    confirmed=forecast(data,train,withhold,region.mask(x,y))
    selected=confirmed['z']>1.5
    # Record independent A/B evidence; it never selects the region or audits it.
    folds=[]
    for source,other in ((split==1,split==2),(split==2,split==1)):
        fit=nominate(data,source)
        folds.append(forecast(data,source,other,fit[1].mask(x,y)) if fit else None)
    return (region if selected else None), {
        'status':'accepted' if selected else 'withheld','proposed':vars(region),
        'search_score':proposed_z,'audit':confirmed,'cross':folds,
    }


def weights(region, shape):
    if region is None:
        return None
    return complete_mask([region,region],shape)
