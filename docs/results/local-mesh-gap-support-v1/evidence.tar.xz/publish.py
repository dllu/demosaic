"""Publish the audited gap experiment and freeze the exact executable sources."""

import hashlib
import shutil
import tarfile
from datetime import UTC,datetime
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

root=Path(__file__).resolve().parent
repo=root.parents[2]
images=repo/'docs/images/local-mesh-gap-support-v1'
result=repo/'docs/results/local-mesh-gap-support-v1'
images.mkdir();result.mkdir()


def portable(path):
    return reference(path)|{'path':str(path.relative_to(repo))}


def save(binding,panels):
    src=checked(binding);dst=images/src.name
    shutil.copyfile(src,dst)
    with Image.open(dst)as cropped:
        assert all((w,h)==(160,160) and x+w<=cropped.width and y+h<=cropped.height
                   for p in panels for x,y,w,h in [p['png_xywh']])
    bound=portable(dst);assert bound['sha256']==binding['sha256']
    return bound


observed={
    'main-overcast-sky-main-overcast-sky':'Flat dark gray sky. All policies equal the local-only parent. The ISO100 AHD shows subtle grain.',
    'main-building-detail-main-building-detail':'The fine braces and hanging wires remain soft. Every revision matches the parent.',
    'main-foliage-main-foliage':'The same large leaf edges and shadow regions persist. None of the policies adds texture.',
    'main-chain-link-fence-main-chain-link-fence':'Both discrete gap policies keep the wider-donor output and its coarse crossings. The local deficit adjusts a small part of the pattern.',
    'mesh-nominal-fine-green-mesh-left':'The crossed result keeps the broad faint crossings left of the post. The short-support panel fades part of that lattice.',
    'mesh-nominal-fine-green-mesh-right':'Soft diagonal structure with incomplete crossings. Each correction preserves its parent.',
    'mesh-profile3879-fine-green-mesh-left':'The final audit alone fades crossings near and below the horizontal wire. The crossed result preserves all of the wider-donor lattice.',
    'mesh-profile3879-fine-green-mesh-right':'Weak diagonal repeats and unevenness remain. No new gaps or crossings appear.',
    'iso400-disk-g132':'The crossed panel reduces the visible second direction inside a rounded region. Fine lines outside still appear softer than the exact target.',
    'iso400-disk-g135':'The crossed cut removes faint texture in the exact gap. The diagonal strong wires remain visible through it. Some residual background variation remains.',
    'iso400-disk-g131':'The crossed result keeps the wider correction, including incorrect faint continuation over the round gap. Short support reduces some of the additional pattern.',
    'iso400-band-g130':'A narrow near-vertical false repeat is visible inside the gap with wide support. The audit-only arm removes much of it. The crossed arm remains identical to the wider fit.',
    'iso400-step-g135':'The audit-only panel weakens the continuous companion around the step. The crossed rule retains the same visible continuous texture as the wider fit.',
}

camera=read_json(root/'camera.json');published_camera=[]
for row in camera['results']:
    for k in ('binding','RAW','arrays'):checked(row[k])
    assert row['additional_RMS_DN16']['Crossed and audited']==0
    view={k:row[k]for k in ('id','panels','ROI','noise','exposure','binding','additional_RMS_DN16')}
    view['image']=save(row['image'],row['panels']);view['observation']=observed[row['id']]
    published_camera.append(view)
assert len(published_camera)==8

raw_summary=read_json(root/'summary.json');native=[]
for row in raw_summary['native']:
    copy={k:v for k,v in row.items()if k not in ('board','triplet')}
    copy['board']={'image':save(row['board']['image'],row['board']['panels']),'panels':row['board']['panels']}
    if row['id'] in ('iso400-disk-g132','iso400-disk-g135'):
        copy['triplet']={'image':save(row['triplet']['image'],row['triplet']['panels']),'panels':row['triplet']['panels']}
    copy['observation']=observed[row['id']]
    native.append(copy)
assert len(native)==5 and sum('triplet'in v for v in native)==2
view=result/'actual-viewing.json'
write_json(view,{'recorded_utc':datetime.now(UTC).isoformat(),'actual_native_viewing':True,'camera':published_camera,
                 'synthetic':native,'scope':'Both GFX scenes, both cab noise profiles and the independent camera JPEGs viewed. Five exact synthetic comparisons and two representative triplets viewed. All cells keep their original 160 output pixels across.'})
shutil.copyfile(root/'summary.json',result/'summary.json')
shutil.copyfile(root/'port-parity.json',result/'port-parity.json')
port=read_json(result/'port-parity.json')
assert port['synthetic']['scored_roles']==180
assert all(row['exact_unchanged'] for row in port['native_helper']['views'])
for file in port['code']:checked(file)
files={name:root/name for name in (
    'gap.py','replay.py','development.log','development.json','pooled.py','pooled-dev.py','pooled-dev.json','pooled-dev.log',
    'pooled-camera.json','deficit.py','deficit-replay.py','local-dev.json','local-dev.log','local-fresh.json','local-fresh.log',
    'fresh.py','fresh-plan.json','fresh.log','fresh.json','camera.py','camera.log','camera.json','parity.py','parity.log',
    'port-parity.json','port-parity-first.json','parity-first.log','report-data.py','summary.json','summary.log','publish.py')}
files.update({f'fresh/{p.name}':p for p in (root/'fresh').glob('*.json')})
for code in ('_mesh_gap.py','mesh_refinement.py','_mesh_profiles.py'):
    files['packaged/'+code]=repo/'src/demosaic'/code
files['packaged/test_mesh_refinement.py']=repo/'tests/test_mesh_refinement.py'
bundle=result/'evidence.tar.xz'
with tarfile.open(bundle,'x:xz',preset=4) as t:
    for name,path in files.items():t.add(path,arcname=name)
with tarfile.open(bundle,'r:xz') as t:
    assert set(t.getnames())==set(files)
    for name,path in files.items():
        assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==reference(path)['sha256'],name
write_json(result/'publication.json',{
    'summary':portable(result/'summary.json'),'actual_viewing':portable(view),'port_parity':portable(result/'port-parity.json'),
    'archive':portable(bundle),'archive_contents':{name:reference(path)for name,path in files.items()},
    'camera':published_camera,'synthetic':native,'training':False,'scoped_numeric_review_complete':True,'actual_native_viewing':True,
    'primary_panel_scores':None,'scope':'Archived projective study and optional planar crop API. All large predictions, cached RAW captures and synthetic packs are bound by digests in retained machine receipts. The archive contains the sources and compact measurements.'})
