"""Check all adaptive policies on both exact archived GFX fields."""

import importlib.util
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from replay import ROOT,SOURCE,infer_geometry,window
from pooled import detect,weights
from deficit import search
from standing import legacy


def module(path):
    spec=importlib.util.spec_from_file_location(path.stem,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result


wider=module(SOURCE/'wider-camera.py')


def main():
    before=read_json(SOURCE/'wider-camera.json'); traces=read_json(SOURCE/'camera.json')
    local={r['id']:r for r in traces['views']}
    out=ROOT/'camera';out.mkdir(); results=[];cache={}
    for row in before['views']:
        view=local[row['id']];q=view['query'];roi=view['ROI'];noise=view['noise']
        with np.load(checked(row['input']),allow_pickle=False)as f:
            scene,colors=f['packed'][0],f['colors'][0]
            rgb={k:f[k]for k in ('wb','matrix')}
        field=np.load(checked(view['parent']),allow_pickle=False)[0]; parent=window(field,roi)
        with np.load(checked(row['deltas']),allow_pickle=False)as f:
            broad=f['wider'];short=f['narrow']
        state={'status':'parent'}; deficit={'status':'parent'}
        variants={k:broad for k in ('Audited gap','Crossed and audited','Local deficit')}
        fit=None
        if np.any(broad):
            source=checked(row['RAW'])
            assert (Path.cwd()/'.cache').resolve() in source.resolve().parents,source
            if source not in cache:
                cache[source]=read_raw(source)[0]
            full=cache[source]
            left,top,w,h=row['absolute_box']
            np.testing.assert_array_equal(wider.packed(full[top:top+h,left:left+w]),scene)
            donor_trace, added=wider.augment(full,row['absolute_box'],q,view['donor_windows'],colors,noise)
            assert added==row['added_donors']
            raw=window(scene,q,phase=2)
            pair,fit=infer_geometry(donor_trace,raw,colors,noise,np.asarray(q[:2])+127.5)
            assert fit['donor_fit']==row['fit']
            rx,ry,rw,rh=roi
            def keep(mask):
                if mask is None:
                    return broad
                support=window(mask,(rx-q[0],ry-q[1],rw,rh))
                return (broad*(1-support[None])).astype(broad.dtype)
            region,state=detect(raw,colors,pair,noise)
            if region:
                variants['Audited gap']=keep(weights(region,(q[3],q[2])))
                c=state['cross']
                if all(x and x['z']>.75 for x in c):
                    variants['Crossed and audited']=variants['Audited gap']
            d,deficit=search(raw,colors,pair,noise)
            variants['Local deficit']=keep(d)
        old={'image':row['image'],'panels':[r for r in row['panels']if r['label']!='Donor projective']}
        panels=[(tag,legacy.pixel(parent+delta,rgb,(0,0,roi[2],roi[3]),row['exposure']))for tag,delta in variants.items()]
        image,rects=legacy.insert_camera_panels(out,row['id'],old,'Short support',panels)
        arrays=out/(row['id']+'.npz');np.savez_compressed(arrays,broad=broad,short=short,**variants)
        extras={tag:float(np.sqrt(np.mean((v.astype(float)-broad)**2))*65535)for tag,v in variants.items()}
        result={'id':row['id'],'binding':row['input'],'RAW':row['RAW'],'source':row['image'],'image':image,'panels':rects,
          'arrays':reference(arrays),'ROI':roi,'query':q,'noise':noise,'exposure':row['exposure'],
          'scores':state,'local_deficit':deficit,'phase':fit,'additional_RMS_DN16':extras}
        results.append(result)
        print(row['id'],state.get('audit'),deficit.get('audit'),{k:round(v,4)for k,v in extras.items()},flush=True)
    assert len(results)==8
    write_json(ROOT/'camera.json',{'driver':reference(__file__),'input':reference(SOURCE/'wider-camera.json'),
        'checkpoint':traces['checkpoint'],'results':results,
        'scope':'Native matched correction replay, no new training or neural inference. The central detection uses the same exterior and nominal RAW phase as the wider-donor continuation, verified against the previous trace. It attenuates the already delivered median.'})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    main()
