"""Check pooled discovery on the previous panel and both wider-donor GFX families."""

import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from pooled import detect,weights
from replay import ROOT,SOURCE,CENTRE,DISPLAY,infer_geometry,score,window
from deliver import geometry
from standing import legacy


def corrected(correct, raw, colors, pair, box, roi, noise):
    if not np.any(correct):
        return correct,{'status':'parent'},correct
    found,note=detect(raw,colors,pair,noise)
    if found is None:
        return correct,note,correct
    x,y,w,h=roi
    weight=window(weights(found,(box[3],box[2])),(x-box[0],y-box[1],w,h))
    cut= (correct*(1-weight[None])).astype(correct.dtype)
    votes=[c['z']for c in note['cross']if c is not None]
    staged=cut if len(votes)==2 and min(votes)>0.75 else correct
    return cut,note,staged


def synth():
    previous=read_json(SOURCE/'fresh.json'); plan=read_json(checked(previous['plan']))
    dest=ROOT/'pooled-dev';dest.mkdir();rows=[]
    for binding in previous['cases']:
        case=read_json(checked(binding)); noise=plan['noise'][case['profile']]
        with np.load(checked(case['array']),allow_pickle=False)as a:
            data={k:a[k]for k in ('target','packed','colors','parent','matching-projective','strong_phase','weak_phase','support')}
        packed,colors,base,old=(data[k]for k in ('packed','colors','parent','matching-projective'))
        rendered=[];strong=[];notes=[]
        for i,d in enumerate(old):
            if np.any(d):
                q=window(packed[i],CENTRE,phase=2)
                pair,trace=infer_geometry(case['priors']['matching'],q,colors[i],noise,(383.5,383.5))
                new,note,strict=corrected(d,q,colors[i],pair,CENTRE,DISPLAY,noise)
                note['phase']=trace
            else:
                new,note,strict=d,{'status':'parent'},d
            rendered.append(new);strong.append(strict);notes.append(note)
        arrays={'pooled':np.stack(rendered),'crossed':np.stack(strong)}
        metrics={key:score(base,out,data['target'],{k:data[k]for k in ('strong_phase','weak_phase','support')}) for key,out in arrays.items()}
        path=dest/(case['id']+'.npz');np.savez_compressed(path,**arrays)
        rows.append({'id':case['id'],'source':binding,'note':notes,'predictions':reference(path),'methods':metrics})
        print(case['id'],notes[1].get('status'),round(notes[1].get('audit',{}).get('z',0),2),
              [(k,round(v['response'][0],3),round(v['gap_added_RMS_DN16'] or 0,3))for k,v in metrics.items()],flush=True)
    write_json(ROOT/'pooled-dev.json',{'driver':reference(__file__),'source':reference(SOURCE/'fresh.json'),'rows':rows})


def camera():
    source=read_json(SOURCE/'wider-camera.json'); original=read_json(SOURCE/'camera.json')
    local={r['id']:r for r in original['views']}
    dest=ROOT/'pooled-camera';dest.mkdir();rows=[]
    for r in source['views']:
        ident=r['id']; earlier=local[ident];q=earlier['query'];roi=earlier['ROI'];noise=earlier['noise']
        with np.load(checked(r['input']),allow_pickle=False)as a:
            raw,colors=a['packed'][0],a['colors'][0]
            rgb={k:a[k]for k in ('wb','matrix')}
        with np.load(checked(r['deltas']),allow_pickle=False)as f:
            old=f['wider'];narrow=f['narrow']
        parent=np.load(checked(earlier['parent']),allow_pickle=False)[0];base=window(parent,roi)
        if np.any(old):
            packed=window(raw,q,phase=2)
            pair,receipt=infer_geometry(earlier['donor_windows'],packed,colors,noise,np.asarray(q[:2])+127.5)
            retained,note,strict=corrected(old,packed,colors,pair,q,roi,noise)
            note['phase']=receipt
        else:
            retained,note,strict=old,{'status':'parent'},old
        prev={'image':r['image'],'panels':[p for p in r['panels']if p['label']!='Donor projective']}
        x,y,w,h=roi
        images=[(label,legacy.pixel(base+val,rgb,(0,0,w,h),r['exposure']))for label,val in (('Audited gap',retained),('Crossed and audited',strict))]
        img,panels=legacy.insert_camera_panels(dest,ident,prev,'Short support',images)
        path=dest/(ident+'.npz');np.savez_compressed(path,broad=old,narrow=narrow,pooled=retained,crossed=strict)
        edits=[float(np.sqrt(np.mean((v.astype(float)-old)**2))*65535)for v in (retained,strict)]
        rows.append({'id':ident,'original':r['image'],'image':img,'panels':panels,'input':r['input'],'delta':reference(path),
                     'extra_RMS_DN16':edits,'noise':noise,'exposure':r['exposure'],'ROI':roi,'query':q,'note':note})
        print(ident,note['status'],note.get('audit'),edits,flush=True)
    write_json(ROOT/'pooled-camera.json',{'driver':reference(__file__),'source':reference(SOURCE/'wider-camera.json'),'rows':rows,
               'checkpoint':original['checkpoint']})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    synth();camera()
