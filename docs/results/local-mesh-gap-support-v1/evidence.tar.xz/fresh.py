"""Validate audited spatial attenuation on fresh rotated and bounded mesh gaps."""

import dataclasses
import importlib.util
import math
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS,mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise,variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from replay import ROOT,SOURCE,CENTRE,DISPLAY,geometry,infer_geometry,score,window
from deliver import proposals,shift_prior
from mesh import ribbon
from run import SHIFTS,prior
from stabilize import median_correction


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod


refine=load('projective_with_carriers',SOURCE/'deliver-short.py')
short=load('short_support',SOURCE/'short-support.py')
filter_gap=load('gap_delivery',ROOT/'pooled-dev.py')


def smooth(t):
    s=np.clip(t,0,1)
    return s*s*(3-2*s)


def observe(index,layout,noise,seed):
    guides=prior.guides(index)
    cfa=tuple(PATTERNS)[index%4]
    x,y=coordinates(320,320,origin=(-159.5,-159.5))
    first,second=(ribbon(x,y,k)for k in guides)
    base=np.array([.24,.28,.35])[:,None,None]+.015*x/320-.021*y/320
    base=base+.0024*np.sin(.025*x+.021*y)
    i=index-130
    angle=math.radians((8,42,73,103,132,161)[i]); normal=(math.cos(angle),math.sin(angle))
    offset=(-19,22,-33,30,12,-26)[i]
    radius=(24,28,34,21,32,26)[i]
    dx=(-26,32,-28,14,31,-17)[i];dy=(20,19,-34,29,-12,-28)[i]
    extent=np.ones_like(x)
    if layout=='band':
        extent=smooth((abs(normal[0]*x+normal[1]*y-offset)-radius)/14)
    if layout=='disk':
        extent=smooth((np.hypot(x-dx,y-dy)-(radius+8))/14)
    strong=.039*prior.STRONG*first
    if layout!='continuous':
        beta=angle+(.48 if i%2 else -.52)
        across=math.cos(beta)*x+math.sin(beta)*y+13
        jump=.5+.5*np.tanh(across/2.3)
        strong=strong+np.array([.017,.024,.010])[:,None,None]*jump
    clean=base+strong
    amplitude=.0044 if i%2 else .0040
    detailed=clean+amplitude*prior.FAINT*(1-first)*second*extent
    p,q,flat=(torch.from_numpy(v.astype(np.float32))for v in (clean,detailed,base))
    raw,meta=paired_observation(p[None],q[None],noise,[cfa],torch.ones(1,3),torch.eye(3)[None],seed)
    batch={k:torch.from_numpy(raw[k])for k in ('target','packed','variance','colors','wb','matrix')}
    colors=batch['colors'][0]
    quiet=add_noise(mosaic(flat[None],colors),noise['shot'],noise['read'],black_level=.03,
                    generator=torch.Generator().manual_seed(seed+1225))
    parts={'target':flat[None],'packed':quiet,'variance':variance_map(quiet,noise['shot'],noise['read']),
           **{k:batch[k][:1]for k in ('wb','matrix','colors')}}
    batch={k:torch.cat((v,parts[k]))for k,v in batch.items()}
    xx,yy=coordinates(768,768,origin=(-383.5,-383.5))
    context=np.array([.255,.285,.343])[:,None,None]+.015*xx/768-.02*yy/768
    patch=np.zeros_like(xx)
    for cx,cy in ((-230,55),(233,(i%3-1)*38),((i%3-1)*61,223)):
        w=smooth((113-np.maximum(abs(xx-cx),abs(yy-cy)))/21)
        patch=np.maximum(patch,w)
    theta=.45
    rotate=np.array([[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]])
    off_axis=[dataclasses.replace(c,frequency=tuple(rotate@c.frequency))for c in guides]
    exterior={}
    for tag,geom in (('matching',guides),('unrelated',off_axis)):
        dr,ds=(ribbon(xx,yy,c)for c in geom)
        a=context+patch*(.10*prior.STRONG*dr+.066*prior.FAINT*ds)
        mosaic_raw=mosaic(torch.from_numpy(a.astype(np.float32))[None],colors)
        exterior[tag]=add_noise(mosaic_raw,noise['shot'],noise['read'],black_level=.03,
            generator=torch.Generator().manual_seed(seed+1709))[0].numpy()
    return batch,exterior,{'strong_phase':first,'weak_phase':second,'support':extent},meta,{
        'case_geometry':[vars(q)for q in guides],'cut_normal':normal,'cut_radius':radius,'cut_offset':offset,
        'disk_center':[dx,dy],'amplitude':amplitude,'CFA':cfa,
    }


def infer(field,raw,var,colors,proposal,trace,noise):
    if proposal is None:
        d=np.zeros_like(window(field,DISPLAY))
        return {'projective':d,'short':d,'audited':d,'crossed':d},{'status':'no donor pair'}
    a=[];b=[]
    xy=CENTRE[:2]
    for dx,dy in SHIFTS:
        box=(xy[0]+dx,xy[1]+dy,*CENTRE[2:])
        f,g=shift_prior(*proposal['projective'],dx,dy)
        d,details=refine.correction(field,raw,var,colors,box,DISPLAY,f,g,noise,packed_offset=dx//2)
        restricted=short.shorten(d,window(raw,box,phase=2),colors,details.get('phase_candidates'),noise,box,DISPLAY,dx//2)
        a.append(d);b.append(restricted)
    broad,narrow=median_correction(a),median_correction(b)
    if not np.any(broad):
        return {'projective':broad,'short':narrow,'audited':broad,'crossed':broad},{'status':'parent'}
    packed=window(raw,CENTRE,phase=2)
    pair,_=infer_geometry(trace,packed,colors,noise,(383.5,383.5))
    point,note,strict=filter_gap.corrected(broad,packed,colors,pair,CENTRE,DISPLAY,noise)
    return {'projective':broad,'short':narrow,'audited':point,'crossed':strict},note


@torch.inference_mode()
def main():
    previous=read_json(SOURCE/'fresh-plan.json'); bound=previous['checkpoint']
    dst=ROOT/'fresh';dst.mkdir()
    seeds=[('iso400',layout,g)for layout in ('continuous','step','band','disk')for g in range(130,136)]
    seeds += [('iso6400','band' if g%2 else 'disk',g)for g in range(130,136)]
    window_schema=[{'profile':p,'layout':l,'g':g,'seed':280511043013+i*12139+g*139}for i,(p,l,g)in enumerate(seeds)]
    plan={'driver':reference(__file__),'checkpoint':bound,'phase_plan':reference(SOURCE/'fresh-plan.json'),
          'method_sources':[reference(ROOT/(s+'.py'))for s in ('gap','pooled','pooled-dev','replay')],
          'cases':window_schema,'query':CENTRE,'ROI':DISPLAY,'noise':previous['noise'],'shifts':SHIFTS,
          'scope':'Thirty new synthetic pairs. Continuous and discontinuous layouts in exact camera RGB. Compare only attenuation of a broad same-observation prediction. Projective and unconditional short-support baselines use the established amplitude delivery. The gap decision may remove only existing correction values. A central fixed partition reserves one quarter for phase and another quarter for audit. The primary crossed policy requires positive A-to-B and B-to-A predictions beyond the audit requirement.'}
    write_json(ROOT/'fresh-plan.json',plan)
    model,metadata=load_scene_checkpoint(checked(bound),device='cuda',weights='ema',expected_sha256=bound['sha256'])
    assert metadata['step']==2000
    model.mode='none';del metadata
    began=time.monotonic();rows=[]
    with ieee_fp32():
        for entry in window_schema:
            p,l,g,seed=(entry[k]for k in ('profile','layout','g','seed'))
            name=f'{p}-{l}-g{g}';noise=plan['noise'][p]
            inputs,exterior,masks,sensor,shape=observe(g,l,noise,seed)
            model.base.set_noise(noise['shot'],noise['read'])
            local=model(*(inputs[k].cuda()for k in ('packed','variance','colors','wb','matrix'))).cpu().numpy()
            raw,var,color,target=(inputs[k].numpy()for k in ('packed','variance','colors','target'))
            all_metrics={'parent':score(local,None,target,masks)}; old_records={}; corrections={}
            for tag,scene in exterior.items():
                f,trace=proposals(scene,color[0],(256,256,256,256),noise,80)
                policies={};query_results=[]
                for i in range(3):
                    views,note=infer(local[i],raw[i],var[i],color[i],f,trace,noise)
                    query_results.append(note)
                    for policy,d in views.items():policies.setdefault(policy,[]).append(d)
                old_records[tag]={'exterior':trace,'query_check':query_results}
                for k,v in policies.items():
                    key=tag+'-'+k;corrections[key]=np.stack(v)
                    all_metrics[key]=score(local,corrections[key],target,masks)
            array=dst/(name+'.npz')
            np.savez_compressed(array,**{k:v.numpy()for k,v in inputs.items()},**masks,parent=local,**corrections)
            record={'id':name,'entry':entry,'shape':shape,'sensor':sensor,'inputs':{k:fingerprint(v)for k,v in inputs.items()},
                'arrays':reference(array),'metrics':all_metrics,'witness':old_records}
            path=dst/(name+'.json');write_json(path,record);rows.append(reference(path))
            print(name,old_records['matching']['query_check'][1]['status'],
                [(k,round(v['response'][0],4),round(v['gap_added_RMS_DN16'] or 0,3),v['changed'])for k,v in all_metrics.items()if k.startswith('matching-')],
                round(time.monotonic()-began,1),flush=True)
    assert len(rows)==30
    write_json(ROOT/'fresh.json',{'plan':reference(ROOT/'fresh-plan.json'),'cases':rows,'seconds':time.monotonic()-began})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
