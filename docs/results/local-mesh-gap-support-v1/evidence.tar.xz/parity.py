"""Verify the packaged gap detector and optional native helper."""

import os
from pathlib import Path

import numpy as np

from demosaic._mesh_gap import confirmed_gap
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites
from demosaic.mesh_refinement import refine_local_raw_mesh
from replay import CENTRE,DISPLAY,ROOT,SOURCE,infer_geometry,window
from mesh import ribbon


def masks_equal():
    fresh=read_json(ROOT/'fresh.json');plan=read_json(checked(fresh['plan']))
    checked_roles=0;changes=[]
    for ref in fresh['cases']:
        case=read_json(checked(ref));noise=plan['noise'][case['entry']['profile']]
        with np.load(checked(case['arrays']),allow_pickle=False)as f:
            arrays=dict(f)
        for context in ('matching','unrelated'):
            broad=arrays[context+'-projective']
            answer=[]
            for d,scene,color in zip(broad,arrays['packed'],arrays['colors'],strict=True):
                projected=None
                if d.any():
                    raw=window(scene,CENTRE,phase=2)
                    pair,_=infer_geometry(case['witness'][context]['exterior'],raw,color,noise,(383.5,383.5))
                    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
                    p,q=(ribbon(x,y,c)for c in pair)
                    projected=confirmed_gap(raw,color,p,q,noise['shot'],noise['read'])
                if projected is not None:
                    mask=window(projected,(DISPLAY[0]-CENTRE[0],DISPLAY[1]-CENTRE[1],*DISPLAY[2:]))
                    d=(d*(1-mask[None])).astype(d.dtype)
                    changes.append([case['id'],context,len(answer)])
                answer.append(d)
                checked_roles+=1
            np.testing.assert_array_equal(np.stack(answer),arrays[context+'-crossed'])
    return {'scored_roles':checked_roles,'attenuated_roles':changes,'source':reference(ROOT/'fresh.json')}


def real_helper():
    original=ROOT.parent/'local-mesh-stable-v1/camera.json'
    results=[]
    for row in read_json(original)['rows']:
        with np.load(checked(row['input']),allow_pickle=False)as f:
            raw,var,color=(f[k][0]for k in ('packed','variance','colors'))
        field=np.load(checked(row['matched_parent']),allow_pickle=False)[0]
        args=(field,raw,var,color,row['native_query'],row['native_ROI'])
        options={k:row['noise'][k]for k in ('shot','read')}
        span=112 if row['id'].startswith('mesh-')else 80
        base=window(field,row['native_ROI'])
        with np.load(checked(row['corrections']),allow_pickle=False)as f:
            expected=base+f['combined']
        public=refine_local_raw_mesh(*args,**options,donor_span=span)
        alternate=refine_local_raw_mesh(*args,**options,donor_span=span,suppress_gaps=True)
        np.testing.assert_array_equal(public,expected)
        delta=(alternate.astype(float)-public)
        results.append({'id':row['id'],'extra_RMS_DN16':float(np.sqrt(np.mean(delta**2))*65535),
                        'exact_unchanged':bool(np.array_equal(alternate,public))})
        print(row['id'],results[-1]['extra_RMS_DN16'],flush=True)
    return {'archive':reference(original),'views':results}


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    results=masks_equal()
    write_json(ROOT/'port-parity.json',{'driver':reference(__file__),'synthetic':results,'native_helper':real_helper(),
      'code':[reference(Path('src/demosaic')/p)for p in ('_mesh_gap.py','mesh_refinement.py')]})
