"""Replay the recent fixed panel using only RAW to localize attenuation."""
import importlib.util
import os
import sys
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from gap import confirm_gap,complete_mask

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'local-mesh-phase-evidence-v1'
sys.path.insert(0,str(SOURCE))
from deliver import CENTRE,DISPLAY,geometry,window,score


def infer_geometry(trace, raw, colors, noise, donor_center):
    pos,f,usable,division=geometry.donor_arrays(trace,donor_center)
    recovered,g,note=geometry.fit_geometry(pos,f,usable)
    pair, strengths = geometry.reserve_candidates(raw,colors,recovered,g,noise)
    return pair, {'phase_scores':strengths,'donor_fit':note}


def recover(delta, packed, colors, noise, pair, box, roi):
    if not np.any(delta):
        return delta, {'status':'parent'}
    raw=window(packed,box,phase=2)
    proposals,note=confirm_gap(raw,colors,pair,noise)
    if not proposals:
        return delta,note
    x,y,w,h=roi
    attenuation=window(complete_mask(proposals,(box[3],box[2])),(x-box[0],y-box[1],w,h))
    return (delta*(1-attenuation[None])).astype(delta.dtype),note


def synthetic():
    previous=read_json(SOURCE/'fresh.json');old_plan=read_json(checked(previous['plan']))
    dest=ROOT/'development';dest.mkdir()
    rows=[]
    for b in previous['cases']:
        case=read_json(checked(b));noise=old_plan['noise'][case['profile']]
        with np.load(checked(case['array']),allow_pickle=False)as a:
            truth,packed,colors,field,prior=(a[k]for k in ('target','packed','colors','parent','matching-projective'))
            masks={k:a[k]for k in ('strong_phase','weak_phase','support')}
        notes=[];deltas=[]
        for role in range(3):
            if not np.any(prior[role]):
                delta,note=prior[role],{'status':'parent'}
            else:
                q=window(packed[role],CENTRE,phase=2)
                pair,trace=infer_geometry(case['priors']['matching'],q,colors[role],noise,(383.5,383.5))
                delta,note=recover(prior[role],packed[role],colors[role],noise,pair,CENTRE,DISPLAY)
                note['phase']=trace
            deltas.append(delta);notes.append(note)
        corrections=np.stack(deltas)
        output=dest/(case['id']+'.npz');np.savez_compressed(output,adaptive=corrections)
        d={'id':case['id'],'source':b,'notes':notes,'delta':reference(output),'metrics':score(field,corrections,truth,masks)}
        rows.append(d)
        t=notes[1]; print(case['id'],t.get('status'),t.get('overlap'),t.get('proposal_scores'),
            [round(v['z'],2)for v in t.get('cross',[])],round(t['audit']['z'],2)if t.get('audit') else None,
            round(d['metrics']['response'][0],3),round(d['metrics']['gap_added_RMS_DN16'] or 0,3),flush=True)
    assert len(rows)==24
    write_json(ROOT/'development.json',{'driver':reference(__file__),'method':reference(ROOT/'gap.py'),'source':reference(SOURCE/'fresh.json'),'cases':rows})


if __name__=='__main__':
    os.sched_setaffinity(0,[12,13]);os.nice(12)
    synthetic()
