"""Pair the fixed photo panel by source before comparing mean redraw and Corpus 100k."""

from collections import defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import tarfile

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
HISTORY = "docs/results/version-PSNR-history-corpus-v12.json"
CORPUS = "docs/results/full-corpus-long100k-primary-v1/primary.json"
MEAN = "docs/results/local-redraw-stability-primary-v1/publication.json"
ARMS = ("prior-mean", "V120")
SEED = 202611192328


def paired(values):
    values = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(SEED)
    samples = rng.integers(0, len(values), size=(10000, len(values)))
    return {
        "source_count": len(values), "mean": float(values.mean()),
        "median": float(np.median(values)), "paired_95_percent": np.quantile(values[samples].mean(1), (.025,.975)).tolist(),
        "quantiles_05_95": np.quantile(values, (.05,.95)).tolist(),
        "higher": int((values > 0).sum()), "lower": int((values < 0).sum()),
    }


def main():
    registry = reference(REPO / HISTORY)
    history = read_json(checked(registry))
    sources = {r["path"]: r["sha256"] for r in history["sources"]}

    def indexed(path):
        return checked({"path": REPO / path, "sha256": sources[path]})

    old_path, new_path = indexed(CORPUS), indexed(MEAN)
    old, new = read_json(old_path), read_json(new_path)
    assert old["canonical_inputs"] == new["canonical_inputs"]
    assert old["photo_sources"] == new["photo_sources"] == 427
    points = {p.get("label"): p for p in history["points"] if p.get("label") is not None}
    parent, candidate = points["Corpus 100k"], points["Mean draw +512"]
    assert parent["checkpoint_sha256"] == old["models"]["scale-long100k"]["checkpoint"]["sha256"]
    assert candidate["checkpoint_sha256"] == new["models"]["prior-mean"]["checkpoint"]["sha256"]
    old_archive = indexed(old["archive"]["path"])
    new_archive = indexed(new["archive"]["path"])
    assert old["archive"]["sha256"] == digest(old_archive)
    assert new["archive"]["sha256"] == digest(new_archive)

    received = {arm: defaultdict(dict) for arm in ARMS}
    with tarfile.open(new_archive) as archive:
        primary = archive.extractfile("collector-result.json").read()
        assert sha256(primary).hexdigest() == new["collector"]["sha256"]
        declaration = json.loads(primary)
        assert declaration["complete"] and declaration["models"] == new["models"]
        batches = {Path(r["path"]).stem: r["sha256"] for r in declaration["cases"]}
        for i in range(3108):
            data = archive.extractfile(f"photo/{i:05d}.json").read()
            assert sha256(data).hexdigest() == batches[f"photo-{i:05d}"]
            case = json.loads(data)
            for arm in ARMS:
                for row in case["variants"][arm]["rows"]:
                    if row["kind"] != "photo":
                        continue
                    axis = (row["condition"], row["pattern"])
                    values = received[arm][row["id"]]
                    assert axis not in values and math.isfinite(row["metrics"]["srgb_psnr"])
                    values[axis] = row["metrics"]["srgb_psnr"]

    a = old["source_averages"]
    assert set(a) == set(received["prior-mean"]) == set(received["V120"])
    assert all(len(c) == 28 for by_arm in received.values() for c in by_arm.values())
    photos = {}
    v120_checks = []
    for id_ in sorted(a):
        av = {arm: math.fsum(received[arm][id_].values()) / 28 for arm in ARMS}
        base = a[id_]["scale-long100k"]["srgb_psnr"]
        photos[id_] = {"mean_redraw": av["prior-mean"], "corpus100k": base,
                       "delta_dB": av["prior-mean"] - base}
        v120_checks.append(av["V120"] - a[id_]["V120"]["srgb_psnr"])
    assert max(abs(x) for x in v120_checks) < .00002

    effects = paired([row["delta_dB"] for row in photos.values()])
    assert abs(effects["mean"] - (candidate["photo_srgb_PSNR"] - parent["photo_srgb_PSNR"])) < 1e-11
    scores = {}
    axes = sorted(set(k for row in received["prior-mean"].values() for k in row))
    for condition in sorted({c for c, _ in axes}):
        matching = [(c, f) for c, f in axes if c == condition]
        row = [math.fsum(m[k] for k in matching) / 4 for m in received["prior-mean"].values()]
        comparable = old["per_condition_srgb_PSNR"][condition]["scale-long100k"]
        scores[condition] = {
            "mean_redraw": float(np.mean(row)), "corpus100k": comparable,
            "delta_dB": float(np.mean(row)) - comparable,
        }
    write_json(REPO / "docs/results/local-redraw-average-v1/fixed-photo-mean-vs-corpus.json", {
        "driver": reference(__file__), "registry": registry,
        "sources": [reference(p) for p in (old_path, old_archive, new_path, new_archive)],
        "checkpoints": {"mean_redraw": candidate, "corpus100k": parent},
        "canonical_inputs": old["canonical_inputs"],
        "V120_source_mean_max_CPU_CUDA_delta_dB": max(abs(x) for x in v120_checks),
        "delta_mean_redraw_minus_corpus": effects,
        "conditions": scores, "sources_photo": photos, "bootstrap_seed": SEED,
    })
    print(effects)
    print({condition: info["delta_dB"] for condition,info in scores.items()})


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


if __name__ == "__main__":
    main()
