"""Exact paired checks and standing views of both matched local continuations."""
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
from collections import Counter
from pathlib import Path
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
BASELINE = ROOT.with_name("local50000-scoped-v1")
sys.path.insert(0, str(BASELINE))
from replay import BEFORE, STANDING, restore
from review_endpoint import comparisons
from local_band_review import photo, fine_region, flat_color
from fit_local import metric_for_wire
from upper import ROI
from native import native_png, old_pixels
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint
from report_scene_wave_guides import native_board

ARMS = {"individual": "Individual redraw loss", "mean": "Mean redraw loss"}
PRIOR = ROOT.with_name("local-paired-continuation-v1")
SINGLE_PAIR = "Single-pair EMA"
LOCAL = "Local 50k EMA"
V120 = "V120"
CORPUS = "Corpus 100k"
KEYS = ("packed", "variance", "colors", "wb", "matrix")


def output_path(folder, tag, label):
    return folder / f"{tag}-{label}.npy"


def predict(models, data, profile, folder, key):
    outputs, timings = {}, {}
    for name, model in models.items():
        path = output_path(folder, key, name)
        output, duration = restore(model, data, profile)
        with path.open("xb") as stream:
            np.save(stream, output, allow_pickle=False)
        outputs[name] = reference(path)
        timings[name] = duration
    return outputs, timings


def metrics(case, output, args):
    if case["source"]["kind"] == "wire":
        wire = metric_for_wire(args, case["source"]["geometry"])
        return wire(output) | fine_region(output, args, 2) | {
            "flat_chroma_RMS_DN16": flat_color(output, args, 3, (64, 64, 128, 128))
        }
    return photo(output, args)


def exact(model, previous, recipe, folder, root):
    rows = []
    previous_study = read_json(PRIOR / "review/result.json")
    historical = {r["source"]["index"]:r for r in previous_study["wire"]+previous_study["photo"]}
    for case in previous["wire"] + previous["photo"]:
        index = case["source"]["index"]
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            arrays = {k: archive[k] for k in archive.files}
        outputs, seconds = predict(model, arrays, recipe["profile"], folder, f"{index:02d}")
        scores = {key: case["scores"][key] for key in (LOCAL, CORPUS, V120)}
        earlier = historical[index]
        assert earlier["input"] == case["input"] and earlier["source"] == case["source"]
        scores[SINGLE_PAIR] = earlier["scores"]["Paired continuation"]
        for arm, label in ARMS.items():
            values = np.load(checked(outputs[arm]), allow_pickle=False)
            scores[label] = metrics(case, values, arrays)
        rows.append(dict(case, scores=scores, outputs=outputs, forward_seconds=seconds, previous_pair_output=earlier["outputs"]["paired"]))
    assert len(rows) == 48
    wires = [row for row in rows if row["source"]["kind"] == "wire"]
    photos = [row for row in rows if row["source"]["kind"] == "natural"]
    assert len(wires) == len(photos) == 24
    import review_endpoint

    review_endpoint.END = ARMS["mean"]
    aggregates = {}
    for comp in (ARMS["individual"], LOCAL, SINGLE_PAIR):
        lab = review_endpoint.LAST
        try:
            review_endpoint.LAST = comp
            aggregates[comp] = {
                "natural": comparisons(photos, True),
                "wire": comparisons(wires, False),
            }
        finally:
            review_endpoint.LAST = lab
    selected = [
        min((r for r in wires if r["gap_pixels"]),
            key=lambda row: delta(row, "gap_RMS_DN16")),
        min(photos, key=lambda row: delta(row, "fine_increment_RMS_DN16")),
        max(photos, key=lambda row: delta(row, "fine_increment_RMS_DN16")),
    ]
    triplets = []
    root.mkdir()
    for case in selected:
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            args = {k: archive[k] for k in (*KEYS, "target")}
        with np.load(checked(case["model_outputs"]), allow_pickle=False) as archive:
            reference_rgb = archive["v120"][0], archive["parent"][0]
        endpoint = np.load(checked(case["endpoint_output"]), allow_pickle=False)[0]
        candidate = tuple(np.load(checked(case["outputs"][arm]), allow_pickle=False)[0] for arm in ARMS)
        camera = {k: args[k][None] for k in ("wb", "matrix", "colors")}
        camera["packed"] = args["packed"][:1]
        previous_rgb=np.load(checked(case["previous_pair_output"]),allow_pickle=False)[0]
        images = [noisy_malvar(camera)[0], *reference_rgb, endpoint, previous_rgb, *candidate, args["target"][0]]
        short = f'{case["source"]["index"]:02d}-{case["source"]["kind"]}-iso6400'
        wire = case["source"]["kind"] == "wire"
        triplets.append(native_board(
            root, short, images, camera,
            {"source": case["source"], "query": case["box"], "inputs": case["input"],
             "outputs": case["outputs"], "previous_pair": case["previous_pair_output"], "iso_profile": recipe["profile"]},
            labels=("Noisy Malvar", V120, CORPUS, LOCAL, SINGLE_PAIR, *ARMS.values(), "Exact GT"),
            triplet_indices=(0, 6, 7), exposure=2 if wire else 1 / .33,
            contrast=1 if wire else 2, roi=ROI,
        ))
    return dict(photo=photos, wire=wires, summary=aggregates, exact=triplets)


def delta(row, key):
    return row["scores"][ARMS["mean"]][key] - row["scores"][ARMS["individual"]][key]


def standing_review(models, previous, folder, root):
    root.mkdir()
    before = {row["id"]: row for row in previous["standing"]}
    previous_study = read_json(PRIOR / "review/result.json")
    historical = {row["id"]: row for row in previous_study["standing"]}
    rows = []
    cache = {}
    for case in read_json(STANDING)["rows"]:
        old = before[case["id"]]
        assert all(old[k] == case[k] for k in ("input", "raw", "roi", "noise", "exposure"))
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            args = {k: archive[k] for k in KEYS}
        args.update({k: args[k][0] for k in ("colors", "wb", "matrix")})
        key = case["input"]["sha256"], str(case["noise"])
        if key not in cache:
            cache[key] = predict(models, args, case["noise"], folder, case["id"])
        outputs, seconds = cache[key]
        pixels = old_pixels(old["board"])
        p = np.load(checked(old["prediction"]), allow_pickle=False)
        pos = case["roi"]
        wb, matrix = (torch.from_numpy(args[k][None]) for k in ("wb", "matrix"))

        def display(x):
            y = display_crop(torch.from_numpy(x), wb, matrix, pos, exposure=case["exposure"])
            return np.rint(np.clip(y, 0, 1) * 255).astype(np.uint8)

        np.testing.assert_array_equal(pixels[LOCAL], display(p))
        labels = ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Parent 100k EMA", LOCAL)
        columns = [(label, pixels[label]) for label in labels if label in pixels]
        baseline = historical[case["id"]]
        assert all(baseline[k] == case[k] for k in ("input", "raw", "roi", "noise", "exposure"))
        prior = np.load(checked(baseline["outputs"]["paired"]), allow_pickle=False)
        columns.append((SINGLE_PAIR, display(prior)))
        changes = {}
        for arm, label in ARMS.items():
            q = np.load(checked(outputs[arm]), allow_pickle=False)
            columns.append((label, display(q)))
            x, y, w, h = pos
            cut = np.s_[..., y:y+h, x:x+w]
            changes[arm] = float(np.sqrt(np.mean((q[cut].astype(float) - p[cut]) ** 2)) * 65535)
        columns.extend((label, pixels[label]) for label in ("ISO100 AHD reference", "ISO100 camera JPEG") if label in pixels)
        board = native_png(root / f'{case["id"]}.png', columns)
        part = {k: case[k] for k in ("id", "input", "raw", "noise", "roi", "exposure", "native_sensor_box")}
        rows.append(dict(part, board=board, outputs=outputs, difference_vs_local_DN16=changes))
    assert len(rows) == 8
    timings = {name: sum(seconds[name] for _, seconds in cache.values()) for name in ARMS}
    return rows, timings


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    checkpoint = reference(ROOT / "training/completed.json")
    finished = read_json(checked(checkpoint))
    assert not finished["qualification"] and finished["DINO_unchanged"]
    assert finished["pair_draws_per_source"] == 2 and finished["native_observations_per_arm"] == 3072
    plan = read_json(checked(finished["plan"]))
    schedule = read_json(checked(plan["schedule"]))
    examples = Counter((row["kind"], row["iso"], row["pattern"], row["law"]) for row in schedule)
    assert len(examples) == 32 and set(examples.values()) == {16}
    source_ids = {row["source"]["id"] for row in schedule}
    assert len(source_ids) == finished["source_photos_per_arm"] == 512
    old_recipe = read_json(BASELINE / "plan.json")
    previous_ref = reference(BASELINE / "review.json")
    previous = read_json(checked(previous_ref))
    prior = read_json(checked(old_recipe["exact_capture"]))
    assert source_ids.isdisjoint(row["source"]["source"]["id"] for row in prior["rows"])
    assert old_recipe["checkpoint"] == finished["parent"] == previous["checkpoint"]
    models = {}
    for arm, binding in finished["checkpoints"].items():
        model, state = load_scene_checkpoint(checked(binding), weights="ema", expected_sha256=binding["sha256"])
        assert state["continued_from"] == finished["parent"] and state["training_arm"] == arm
        models[arm] = _stage_tiled_cuda(model.eval(), "cuda")
    output = ROOT / "review"
    output.mkdir()
    raw = output / "predictions"
    raw.mkdir()
    recipe = read_json(checked(prior["plan"]))
    start = time.monotonic()
    result = exact(models, previous, recipe, raw, output / "exact")
    result["standing"], result["standing_forward_seconds"] = standing_review(
        models, previous, raw, output / "standing")
    write_json(output / "result.json", dict(result, plan=finished["plan"], endpoint=checkpoint,
        driver=reference(__file__), previous_review=previous_ref, weights="EMA",
        precision="CUDA IEEE FP32", elapsed_seconds=time.monotonic() - start))
    print("Completed", len(result["photo"]), len(result["wire"]), len(result["standing"]), flush=True)


if __name__ == "__main__":
    main()
