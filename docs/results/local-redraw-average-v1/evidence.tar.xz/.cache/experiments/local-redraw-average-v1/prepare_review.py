"""Reuse the fixed review geometry and add the prior single-pair arm."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.with_name("local-paired-continuation-v1")


def adapt(name, other, edits):
    original = (PRIOR/name).read_text()
    for before, after in edits:
        assert before in original, before
        original = original.replace(before, after)
    (ROOT/other).write_text(original)


adapt("review_continuation.py", "review_redraw_average.py", [
    ('ARMS = {"absolute": "Absolute continuation", "paired": "Paired continuation"}',
     'ARMS = {"individual": "Individual redraw loss", "mean": "Mean redraw loss"}\n'
     'PRIOR = ROOT.with_name("local-paired-continuation-v1")\nSINGLE_PAIR = "Single-pair EMA"'),
    ('ARMS["paired"]', 'ARMS["mean"]'), ('ARMS["absolute"]', 'ARMS["individual"]'),
    ('    rows = []\n    for case in previous["wire"] + previous["photo"]:',
     '''    rows = []
    previous_study = read_json(PRIOR / "review/result.json")
    historical = {r["source"]["index"]:r for r in previous_study["wire"]+previous_study["photo"]}
    for case in previous["wire"] + previous["photo"]:'''),
    ('        scores = {key: case["scores"][key] for key in (LOCAL, CORPUS, V120)}',
     '''        scores = {key: case["scores"][key] for key in (LOCAL, CORPUS, V120)}
        earlier = historical[index]
        assert earlier["input"] == case["input"] and earlier["source"] == case["source"]
        scores[SINGLE_PAIR] = earlier["scores"]["Paired continuation"]'''),
    ('dict(case, scores=scores, outputs=outputs, forward_seconds=seconds)',
     'dict(case, scores=scores, outputs=outputs, forward_seconds=seconds, previous_pair_output=earlier["outputs"]["paired"])'),
    ('    for comp in (ARMS["individual"], LOCAL):',
     '    for comp in (ARMS["individual"], LOCAL, SINGLE_PAIR):'),
    ('images = [noisy_malvar(camera)[0], *reference_rgb, endpoint, *candidate, args["target"][0]]',
     '''previous_rgb=np.load(checked(case["previous_pair_output"]),allow_pickle=False)[0]
        images = [noisy_malvar(camera)[0], *reference_rgb, endpoint, previous_rgb, *candidate, args["target"][0]]'''),
    ('labels=("Noisy Malvar", V120, CORPUS, LOCAL, *ARMS.values(), "Exact GT"),',
     'labels=("Noisy Malvar", V120, CORPUS, LOCAL, SINGLE_PAIR, *ARMS.values(), "Exact GT"),'),
    ('triplet_indices=(0, 5, 6)', 'triplet_indices=(0, 6, 7)'),
    ('"outputs": case["outputs"], "iso_profile": recipe["profile"]}',
     '"outputs": case["outputs"], "previous_pair": case["previous_pair_output"], "iso_profile": recipe["profile"]}'),
    ('    before = {row["id"]: row for row in previous["standing"]}',
     '''    before = {row["id"]: row for row in previous["standing"]}
    previous_study = read_json(PRIOR / "review/result.json")
    historical = {row["id"]: row for row in previous_study["standing"]}'''),
    ('        changes = {}\n        for arm, label in ARMS.items():',
     '''        baseline = historical[case["id"]]
        assert all(baseline[k] == case[k] for k in ("input", "raw", "roi", "noise", "exposure"))
        prior = np.load(checked(baseline["outputs"]["paired"]), allow_pickle=False)
        columns.append((SINGLE_PAIR, display(prior)))
        changes = {}
        for arm, label in ARMS.items():'''),
    ('    assert not finished["qualification"] and finished["DINO_unchanged"]',
     '    assert not finished["qualification"] and finished["DINO_unchanged"]\n'
     '    assert finished["pair_draws_per_source"] == 2 and finished["native_observations_per_arm"] == 3072'),
])

adapt("review_new_redraws.py", "review_redraw_decomposition.py", [
    ('from review_continuation import ROOT, BASELINE, ARMS, LOCAL, restore',
     'from review_redraw_average import ROOT, BASELINE, ARMS, LOCAL, PRIOR, SINGLE_PAIR, restore'),
    ('ARMS["paired"]', 'ARMS["mean"]'), ('ARMS["absolute"]', 'ARMS["individual"]'),
    ('for comp in (ARMS["individual"], LOCAL)', 'for comp in (ARMS["individual"], LOCAL, SINGLE_PAIR)'),
    ('    grouped = defaultdict(list)',
     '''    grouped = defaultdict(list)
    earlier_file = reference(PRIOR / "redraw/results.json")
    earlier = read_json(checked(earlier_file))
    original = {r["case"]["id"]:r for groups in earlier["cases"].values() for r in groups}'''),
    ('        grouped[case["coupling"]].append({"case": case, "arms": scores})',
     '''        prior = original[case["id"]]
        assert case == prior["case"]
        scores[SINGLE_PAIR] = prior["arms"]["Paired continuation"]
        grouped[case["coupling"]].append({"case": case, "arms": scores})'''),
    ('        seconds=time.monotonic()-started, plan=', '        prior_single_pair=earlier_file, seconds=time.monotonic()-started, plan='),
])

(ROOT/"continuation_redraw_math.py").write_text((PRIOR/"continuation_redraw_math.py").read_text())
