"""Schedule the full canonical panel for both trained redraw endpoints."""
from pathlib import Path
import os
import subprocess
import sys
import time

from demosaic.experiments.artifacts import read_json
from demosaic.experiments.runtime import owner_live

root=Path(__file__).resolve().parent
receipt=root/"training/completed.json"
owner=read_json(root/"training/owner.json")
while not receipt.is_file():
    if not owner_live(owner) and not receipt.is_file():
        raise RuntimeError("Training exited before a checkpoint closure")
    time.sleep(8)
end=read_json(receipt)
assert not end["qualification"] and end["pair_draws_per_source"]==2
fixed=root.with_name("scene-compact-050000-v1")
training=root.with_name("scene-full-epoch-v1")
destination=root/"primary"
subprocess.run([sys.executable,"scripts/collect_scene_primary_compact.py","prepare",str(destination),
    str(fixed/"plan.json"),str(training/"matched-050000.json"),"--continuation",str(receipt),
    "--only-continuation"],check=True)
env=os.environ|{"PYTHONPATH":str(destination/"work/src")}
for stage in ("preflight","full"):
    subprocess.run([sys.executable,"-u",str(destination/"work/scripts/collect_scene_primary_compact.py"),
        stage,str(destination/"plan.json")],env=env,check=True)
