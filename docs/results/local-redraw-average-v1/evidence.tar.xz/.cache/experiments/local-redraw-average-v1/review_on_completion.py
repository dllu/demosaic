"""Run the two reviews once the exact endpoint is bound."""
from pathlib import Path
import subprocess
import sys
import time

from demosaic.experiments.artifacts import checked, read_json
from demosaic.experiments.runtime import owner_live

base=Path(__file__).resolve().parent
owner=read_json(base/"training/owner.json")
receipt=base/"training/completed.json"
while not receipt.is_file():
    if not owner_live(owner):
        if not receipt.is_file():
            raise RuntimeError("Training exited without a completion receipt")
        break
    time.sleep(10)
run=read_json(receipt)
assert run["updates_per_arm"]==512 and run["native_observations_per_arm"]==3072
for binding in run["checkpoints"].values():
    checked(binding)
for review in ("review_redraw_average", "review_redraw_decomposition"):
    with (base/f"{review}.log").open("xb")as log:
        subprocess.run([sys.executable,"-u",str(base/(review+".py"))],
                       stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, check=True)
