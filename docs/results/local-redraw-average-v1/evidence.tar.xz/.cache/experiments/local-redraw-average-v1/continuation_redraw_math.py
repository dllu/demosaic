"""Legacy fixed-panel DCT and independent-redraw reduction."""
import numpy as np
from demosaic.archive_metrics import linear_rgb
from diagnose_local_material_detail import basis, fft_dct

LUMA=np.array([.2126,.7152,.0722])

FREQ=np.arange(16)/32

RADIAL=np.hypot(FREQ[:,None],FREQ[None,:])

BANDS={"lower":(RADIAL>=1/32)&(RADIAL<1/8),"fine":(RADIAL>=1/8)&(RADIAL<1/3),"upper":RADIAL>=1/3}

DCT=basis(16)

def coeffs(luma,roi):
    x,y,w,h=roi
    assert w==h==96
    sample=luma[...,y:y+h,x:x+w]
    blocks=sample.reshape(*sample.shape[:-2],6,16,6,16).swapaxes(-2,-3).reshape(*sample.shape[:-2],36,16,16)
    result=DCT@blocks@DCT.T
    other=fft_dct(fft_dct(blocks,-1),-2)
    np.testing.assert_allclose(result,other,rtol=0,atol=1e-14)
    return result

def contributions(coefficients, target, mask):
    truth = target[0][:, mask] - target[1][:, mask]
    actual = coefficients[:, 0][:, :, mask] - coefficients[:, 1][:, :, mask]
    errors = actual - truth[None]
    scale = 65535**2 / (36 * 16 * 16)
    actual_rms = np.sqrt(np.sum(errors**2, axis=(1, 2)) * scale)
    square = np.mean(actual_rms**2)
    variation = np.sum(errors.var(axis=0, ddof=1)) * scale
    products = [np.sum(errors[a] * errors[b]) for a, b in ((0, 1), (0, 2), (1, 2))]
    shared = np.mean(products) * scale
    np.testing.assert_allclose(square, shared + variation, rtol=1e-13, atol=1e-9)
    quiet = coefficients[:, 2][:, :, mask]
    assert np.max(abs(target[2][:, mask])) < 1e-14
    return {
        "aligned_dot": float(np.sum(actual.mean(axis=0) * truth)),
        "clean_power": float(np.sum(truth**2)),
        "mean_increment_RMS_DN16": float(actual_rms.mean()),
        "mean_quiet_RMS_DN16": float(np.sqrt(np.sum(quiet**2, axis=(1, 2)) * scale).mean()),
        "mean_present_RMS_DN16": float(np.sqrt(np.sum(
            (coefficients[:, 0][:, :, mask] - target[None, 0][:, :, mask])**2,
            axis=(1, 2)
        ) * scale).mean()),
        "increment_MSE_DN16_squared": float(square),
        "shared_error_product_DN16_squared": float(shared),
        "swapped_draw_variance_DN16_squared": float(variation),
        "repeat_increment_RMS_DN16": actual_rms.tolist(),
    }

def channel_coefficients(output, field, roi):
    image = linear_rgb(output, field)
    luma = np.einsum("c,bchw->bhw", LUMA, image)
    return image, coeffs(luma, roi)

