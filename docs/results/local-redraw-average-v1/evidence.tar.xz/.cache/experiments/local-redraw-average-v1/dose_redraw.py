"""Measure the response and false-detail tradeoff between matched trained endpoints."""
from pathlib import Path
import time
import numpy as np

from review_redraw_average import ROOT, ARMS, metrics
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

DOSE=(0.,.25,.5,.75,1.)
SCORES={
    "photo":("fine_response_pp","fine_increment_RMS_DN16","exact_flat_fine_RMS_DN16"),
    "wire":("weak_response_pp","intact_increment_RMS_DN16","exact_flat_RMS_DN16","gap_weak_RMS_DN16"),
}


def measure(rows, keys):
    curves={d:[]for d in DOSE}
    for row in rows:
        with np.load(checked(row["input"]),allow_pickle=False)as vals:
            raw={n:vals[n]for n in vals.files}
        old=np.load(checked(row["outputs"]["individual"]),allow_pickle=False)
        new=np.load(checked(row["outputs"]["mean"]),allow_pickle=False)
        for dose in DOSE:
            if dose == 0:
                sample=old
            elif dose == 1:
                sample=new
            else:
                sample=(old*(1.-dose)+new*dose).astype(np.float32)
            measurements = metrics(row,sample,raw)
            if dose in (0.,1.):
                reference_score=row["scores"][ARMS["individual" if dose==0 else "mean"]]
                assert measurements == reference_score
            curves[dose].append(dict(source=row["source"]["source"]["id"],
                measurements={k:measurements.get(k)for k in keys}))
    output=[]
    for dose,group in curves.items():
        table={}
        for key in keys:
            values=[r["measurements"][key]for r in group if r["measurements"][key] is not None]
            if not values: continue
            mean=float(np.sqrt(np.mean(np.square(values))) if key.startswith(("fine_increment","exact_flat_fine"))
                       else np.mean(values))
            table[key]=dict(cases=len(values),value=mean)
        output.append(dict(dose=dose,rows=group,averages=table))
    return output


def main():
    src=reference(ROOT/"review/result.json")
    r=read_json(checked(src))
    began=time.monotonic()
    panels={g:measure(r[g],keys)for g,keys in SCORES.items()}
    write_json(ROOT/"dose-evidence.json",dict(review=src,driver=reference(__file__),panels=panels,
        mixing="Fixed linear camera-RGB output mixtures with no fit. Both models use the same query and precision.",
        scope="Descriptive held-out ISO6400 response and measured quiet/gap error curve.",
        seconds=time.monotonic()-began))
    for panel,curves in panels.items():
        print(panel,[(r['dose'],{k:round(v['value'],4)for k,v in r['averages'].items()})for r in curves],flush=True)

if __name__=="__main__":
    main()
