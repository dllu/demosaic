"""Replay the existing bit-depth corrections with the trained EMA predictions."""

import os
from importlib.machinery import SourceFileLoader
from pathlib import Path
from statistics import mean

import numpy as np
import torch

from demosaic.adc_bins import coarse_adc_color_projection, near_adc_residual_projection
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_full_faint_photo_panel import source_balance
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
stats=SourceFileLoader("measures",str(ROOT/"score-verified.py")).load_module()
EVAL=ROOT/"evaluation-verified"
ORIGINAL=ROOT.parent/"noisy-cfa-residual-v1"
PALETTE=ROOT.parent/"noisy-residual-reserved-palette-v1"
PANELS={"weak-photo-0":ORIGINAL/"heldout-0","weak-photo-1":ORIGINAL/"heldout-1",
        "flat-and-edge":ORIGINAL/"nulls","reserved-flats":PALETTE}
OUT=ROOT/"fixed-projection-replay"


def repair(prediction,inputs,noise):
    y,c,wb=(torch.from_numpy(inputs[key]) for key in ("packed","colors","wb"))
    value=torch.from_numpy(prediction)
    optical={"shot":noise["shot"],"read":noise["read"],"black_level":.03}
    fine=near_adc_residual_projection(value,y,c,wb,**optical)
    result=coarse_adc_color_projection(fine,y,c,**optical)
    return prediction if result is value else result.numpy()


def panels(root):
    return stats.inputs_and_variants(root)


def camera_exact():
    root=EVAL/"native"
    plan=read_json(root/"plan.json")
    result=read_json(root/"collection/result.json")
    count=0
    for obs,path in zip(plan["observations"],result["records"],strict=True):
        if obs["kind"] not in ("gfx","mesh"):
            continue
        case=read_json(checked(path))
        with np.load(checked(obs["arrays"]),allow_pickle=False) as data:
            args={k:data[k] for k in ("packed","colors","wb")}
        for arm in case["variants"]:
            p=np.load(checked(arm["prediction"]),allow_pickle=False)
            assert repair(p,args,obs["noise"]) is p
            count+=1
    assert count==24
    return count


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[18,19])
    os.nice(10)
    torch.set_num_threads(2)
    OUT.mkdir()
    rows, nulls, boards, identities=[], [], [], []
    for label, old_path in PANELS.items():
        pinned=EVAL/label
        for new,old in zip(panels(pinned),panels(old_path),strict=True):
            observation,inputs,predictions,models=new
            assert observation==old[0] and all(np.array_equal(v,old[1][k]) for k,v in inputs.items())
            predictions={"V120":old[2]["V120"],**predictions}
            models={"V120":old[3]["V120"],**models}
            noise=observation["noise"]
            repaired={k:repair(p,inputs,noise) for k,p in predictions.items()}
            variants={f"{m}-{policy}":p for policy,group in (("raw",predictions),("repair",repaired)) for m,p in group.items()}
            identities.append({"panel":label,"case":observation["id"],"identical":[m for m in predictions if repaired[m] is predictions[m]]})
            if label.startswith("weak-photo"):
                rows.extend(stats.score_photo(observation,inputs,variants))
            else:
                with np.load(checked(observation["target"])) as data:
                    target=data["target"]
                nulls.extend(stats.score_null(observation,target,variants,label))
                if label=="reserved-flats" and observation["pattern"]=="GBRG":
                    m="bridge-trained"
                    i=observation["source_ids"].index("magenta")
                    local={k:inputs[k][i:i+1] for k in ("packed","colors","wb","matrix")}
                    base=noisy_malvar(local)[0]
                    boards.append(native_board(OUT,noise["name"]+"-magenta",
                                 [base,predictions[m][i],repaired[m][i],target[i]],local,
                                 {"profile":noise,"observation":observation,"models":models},
                                 labels=("Noisy Malvar","Near-ADC EMA","Fixed repair","Exact GT"),
                                 exposure=1,triplet_indices=(0,2,3)))
    assert len(rows)==2048 and len(nulls)==768 and len(boards)==2
    summary=[]
    for condition in sorted({r["profile"] for r in rows}):
        photo=[r for r in rows if r["profile"]==condition]
        relative=source_balance(photo)
        for model in sorted({r["model"] for r in photo}):
            applicable=[r for r in photo if r["model"]==model]
            weak=next(r for r in relative if r["band"]=="0" and r["model"]==model)
            summary.append({"profile":condition,"model":model,
                            "mean_sRGB_PSNR":mean(r["PSNR_sRGB"] for r in applicable),
                            "weakest_RMS_DN16":weak["equal_source_RMS_DN16"]})
    cameras=camera_exact()
    aggregates=stats.null_summary(nulls)
    write_json(OUT/"result.json",{"producer":reference(__file__),
        "fixed_corrections":reference("src/demosaic/adc_bins.py"),"photo_summary":summary,
        "null_summary":aggregates,"photo_rows":rows,"null_rows":nulls,
        "identity_per_case":identities,"real_GFX_unchanged_predictions":cameras,
        "source_collections":{k:[reference(EVAL/k/"collection/result.json"),
                                reference(v/"collection/result.json")] for k,v in PANELS.items()},
        "boards":boards,"scope":"Original two frozen corrections, no threshold fitting. V120 cases adopted on exact same arrays. Actual native viewing is separate."})
    for r in aggregates:
        if r["panel"]=="reserved-flats":
            print(r["profile"],r["model"],r["worst_channel_abs_bias_DN16"]["worst_channel_abs_bias_DN16"])


if __name__=="__main__":
    main()
