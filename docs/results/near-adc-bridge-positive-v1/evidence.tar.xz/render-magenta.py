"""Render the preregistered GBRG magenta checks at a common unclipped exposure."""

from importlib.machinery import SourceFileLoader
from pathlib import Path

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board

ROOT=Path(__file__).resolve().parent
worker=SourceFileLoader("fixed_projection",str(ROOT/"repair-verified.py")).load_module()
OUT=ROOT/"fixed-projection-replay"/"exposure-half"


@torch.inference_mode()
def main():
    OUT.mkdir()
    boards=[]
    for ob,arrays,predictions,models in worker.panels(worker.EVAL/"reserved-flats"):
        if ob["pattern"]!="GBRG":
            continue
        i=ob["source_ids"].index("magenta")
        raw=predictions["bridge-trained"]
        repaired=worker.repair(raw,arrays,ob["noise"])
        with np.load(checked(ob["target"]),allow_pickle=False) as f:
            ground=f["target"]
        local={k:arrays[k][i:i+1] for k in ("packed","colors","wb","matrix")}
        boards.append(native_board(OUT,ob["noise"]["name"]+"-magenta",
            [noisy_malvar(local)[0],raw[i],repaired[i],ground[i]],local,
            {"models":models,"observation":ob,"source":"Reserved magenta GBRG"},
            labels=("Noisy Malvar","Near-ADC EMA","Fixed repair","Exact GT"),
            exposure=.5,triplet_indices=(0,2,3)))
    assert len(boards)==2
    write_json(OUT/"result.json",{"source":reference(__file__),"boards":boards})


if __name__=="__main__":
    main()
