"""Check fold isolation, terminal rejection, and ordinary-image controls."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import adaptive_phase_field as model
from audit_spatial import F, GEOMETRY, ROI, observation, pack
import ordinary_phase

J = model.j


def isolation():
    rng = np.random.default_rng(95104)
    phase = model.spatial.supplied_phase(GEOMETRY)
    x0, y0 = ROI[0] - 48, ROI[1] - 48
    y, x = np.indices((544, 544))
    angles = phase(x.ravel() - x0 - J._CENTER, y.ravel() - y0 - J._CENTER).reshape(544, 544, 2)
    difference = np.cos(angles[..., 0] - angles[..., 1])
    raw = 0.17 + 0.03 * np.cos(angles[..., 0]) + 0.027 * np.cos(angles[..., 1]) - 0.01 * difference

    def propose(s):
        use = np.maximum(abs(s.x), abs(s.y)) <= 96
        w = np.exp(-0.5 * (s.x**2 + s.y**2) / 75**2)
        center = model.spatial.stationary(s, use, w)
        templates, margin = model.discover(s, F, J._distinct_bands(F), use, w, center)
        return templates, margin, [model.select_family(templates, margin, a) for a in model.MARGINS]

    cut = np.s_[y0 : y0 + 256, x0 : x0 + 256]
    outputs = {}
    for name, colors in PATTERNS.items():
        obs = observation(pack(raw), colors)
        baseline, improvement, selected = propose(obs)
        across = {}
        for group, threshold in {"selection": 1, "held": 2}.items():
            changed = raw.copy()
            mask = J._folds() >= threshold
            mask = np.repeat(np.repeat(mask, 2, axis=0), 2, axis=1)
            changed[cut][mask] = rng.uniform(0.04, 0.38, size=mask.sum())
            candidate = observation(pack(changed), colors)
            np.testing.assert_array_equal(candidate.variance, obs.variance)
            np.testing.assert_array_equal(candidate.nuisance, obs.nuisance)
            templates, after, chosen = propose(candidate)
            for arm in baseline:
                a, b = baseline[arm], templates[arm]
                for field in ("coefficients", "angles", "signal", "nuisance", "station"):
                    np.testing.assert_array_equal(getattr(a, field), getattr(b, field))
                assert a.amplitude == b.amplitude and a.ratio == b.ratio
            if group == "held":
                assert after == improvement and chosen == selected
                for arm in baseline:
                    assert templates[arm].vote == baseline[arm].vote
                    assert templates[arm].loss_gain == baseline[arm].loss_gain
            else:
                assert after != improvement
            across[group] = {"Q1_curve_advantage": after, "selected": chosen}

        anchor = np.zeros((3, 160, 160), dtype=np.float32)
        context = np.zeros((3, 256, 256), dtype=np.float32)
        nominations = {family for family in selected if family is not None}
        assert len(nominations) == 1
        rejected = baseline[next(iter(nominations))].curved
        alternate = anchor + np.float32(0.01)

        def validate(_, template, __):
            return template.curved != rejected, {}

        with (
            patch.object(model, "validate", validate),
            patch.object(model, "render", return_value=((alternate, alternate, alternate), 1, 1)),
        ):
            result, report = model.deliver(
                anchor, context, obs, F, J._distinct_bands(F), np.ones(3), np.eye(3)
            )
        for margin, rejected_family in zip(model.MARGINS, selected, strict=True):
            assert report["arms"][f"select-{margin:g}"]["family"] == rejected_family
            assert not report["arms"][f"select-{margin:g}"]["admitted"]
            np.testing.assert_array_equal(result[f"select-{margin:g}"], anchor)
        outputs[name] = {
            "before": {"Q1_curve_advantage": improvement, "selected": selected},
            "after_replacement": across,
            "no_held_fallback": True,
        }
    return outputs


if __name__ == "__main__":
    if sys.argv[1] == "ordinary":
        with (
            patch.object(ordinary_phase, "model", model),
            patch.object(ordinary_phase, "OUT", model.OUT),
        ):
            ordinary_phase.main()
    else:
        data = isolation()
        print(data)
        write_json(
            model.OUT / "audit.json",
            {
                "operator": reference(Path(model.__file__)),
                "driver": reference(Path(__file__)),
                "ROI": ROI,
                "layouts": data,
            },
        )
