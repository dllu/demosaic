"""Create native comparison sheets for visual inspection; preserve source tile pixels."""


from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json
from adaptive_phase_field import OUT


def make(entries, labels, path):
    tile = 160
    vert = 190
    canvas = Image.new("RGB", (len(labels) * tile, vert * len(entries)), "#202020")
    draw = ImageDraw.Draw(canvas)
    for i, (name, board) in enumerate(entries):
        with Image.open(checked(board["image"])) as source:
            tiles = {r["label"]: r["png_xywh"] for r in board["panels"]}
            for j, (key, short) in enumerate(labels):
                if key not in tiles:
                    continue
                x, y, w, h = tiles[key]
                assert (w, h) == (tile, tile)
                canvas.paste(source.crop((x, y, x + w, y + h)), (j * tile, i * vert + 30))
                draw.text((j * tile + 3, i * vert + 15), short, fill="#ddd")
        draw.text((3, i * vert), name, fill="#eee")
    canvas.save(path)


def main():
    root = OUT / "inspection"
    root.mkdir(exist_ok=True)
    source = read_json(OUT / "views-camera-all-references.json")["report"]
    camera = [(f"{r['id']} / {b['exposure']:g}x", b) for r in source["rows"] for b in r["native"]]
    labels = (
        ("Regional RAW refit", "Regional RAW refit"),
        ("Selected phase", "Selected phase"),
        ("Affine preference + support", "Affine preference + support"),
        ("ISO100 AHD reference", "ISO100 AHD"),
        ("ISO6400 camera JPEG", "ISO6400 JPEG"),
        ("ISO100 camera JPEG", "ISO100 JPEG"),
    )
    for index in range(0, len(camera), 4):
        make(camera[index : index + 4], labels, root / f"camera-{index // 4}.png")
    examples = read_json(OUT / "views-exact.json")["report"]["rows"]
    exact = [(r["id"] + " / " + r["phase_class"], r["all"]) for r in examples]
    make(
        exact,
        (
            ("Noisy Malvar", "Noisy Malvar"),
            ("Regional RAW refit", "Regional RAW refit"),
            ("Selected phase", "Selected phase"),
            ("Selected + local support", "Selected + support"),
            ("Exact GT", "Exact GT"),
        ),
        root / "exact.png",
    )


if __name__ == "__main__":
    main()
