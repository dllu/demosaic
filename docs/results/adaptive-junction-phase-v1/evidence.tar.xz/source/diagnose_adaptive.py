"""Measure selection errors and retrospective equal-gap contrasts."""

from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_adaptive import BASE, OUT, metric, panel_rows, selection


def diagnostics(binding):
    result = read_json(checked(binding))
    panels = panel_rows(result["rows"])
    choices = result["summary"]["choices"]
    comparisons = {}
    for target, given in (
        ("adaptive-local", "earlier_curve"),
        ("adaptive-guarded", "fixed-pooled"),
        ("fixed-guarded", "fixed-pooled"),
    ):
        target_gap, other_gap = (
            metric.score(panels["all"], choices[k])["means"][metric.GAP] for k in (target, given)
        )
        estimate = target_gap / other_gap * choices[given][1]
        assert 0 <= estimate <= 1
        runs = (choices[target], (choices[given][0], estimate))
        comparisons[target] = {
            "choices": runs,
            "same_gap_DN16": target_gap,
            "variable": [metric.score(panels["varying"], arm) for arm in runs],
            "paired_on_variable": metric.paired(panels["varying"], *runs),
        }

    decisions = {}
    for key, rows in panels.items():
        events = [draw["trace"][0] for row in rows for draw in row["draws"]]
        decisions[key] = {}
        for name in ("select-0", "select-0.5", "select-1"):
            nomination_admission = Counter()
            opportunities = Counter()
            for trace in events:
                arms = trace["arms"]
                nominated = arms.get(name, {}).get("family") or "none"
                nomination_admission[
                    f"{nominated}:{arms.get(name, {}).get('admitted', False)}"
                ] += 1
                viable = {
                    key for key in ("affine", "curved") if arms.get(key, {}).get("admitted", False)
                }
                if viable and nominated not in viable:
                    opportunities["viable_alternate"] += 1
                if len(viable) > 1:
                    opportunities["both_viable"] += 1
            margins = [tr["Q1_curve_advantage"] for tr in events if "Q1_curve_advantage" in tr]
            decisions[key][name] = {
                "nominations_and_admissions": dict(nomination_admission),
                "admission_diagnostics": dict(opportunities),
                "signed_advantage_25_50_75": np.quantile(margins, [0.25, 0.5, 0.75]).tolist(),
            }
    return {"source": binding, "diagnostic_equal_gap": comparisons, "decisions": decisions}


if __name__ == "__main__":
    source = reference(OUT / "evaluate-independent.json")
    result = diagnostics(source)
    print(result["decisions"])
    for name, v in result["diagnostic_equal_gap"].items():
        print(name, v["choices"], v["same_gap_DN16"], v["paired_on_variable"][metric.RESPONSE])
    write_json(OUT / "diagnostics.json", {"driver": reference(Path(__file__)), **result})
