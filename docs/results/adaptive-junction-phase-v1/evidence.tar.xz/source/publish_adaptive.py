"""Publish the frozen adaptive-junction receipts and validated native tiles."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from adaptive_phase_field import OUT, HERE

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "evaluate-calibration",
    "evaluate-independent",
    "diagnostics",
    "audit",
    "ordinary",
    "views-exact",
    "views-camera-report",
    "views-camera-all-references",
    "independent/plan",
    "independent/inputs",
    "independent/parent/result",
)


def bind(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def tile(d):
    src = checked(d["image"])
    dest = ASSETS / src.name
    assert not dest.exists()
    shutil.copyfile(src, dest)
    with Image.open(dest) as im:
        for panel in d["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert w == h == 160 and x + w <= im.width and y + h <= im.height
    copy = bind(dest)
    assert copy["sha256"] == d["image"]["sha256"]
    return d | {"image": copy}


def check_panel(receipt):
    source = read_json(checked(receipt["source"]))
    inputs = read_json(checked(source["inputs"]))
    assert inputs["plan"] == receipt["plan"]
    plan = read_json(checked(receipt["plan"]))
    names, hashes = set(), set()
    for row, samples, recorded, scored in zip(
        plan["sources"], inputs["observations"], source["records"], receipt["rows"], strict=True
    ):
        assert row["id"] == samples["id"] == recorded["id"] == scored["id"]
        assert row == scored["fixture"]
        img = row["source"]
        assert (
            img["id"] not in names and img["cache_sha256"] not in hashes and img["split"] == "val"
        )
        names.add(img["id"])
        hashes.add(img["cache_sha256"])
        checked({"path": img["cache"], "sha256": img["cache_sha256"]})
        for a, b, c in zip(samples["streams"], recorded["streams"], scored["draws"], strict=True):
            assert a["data"] == b["data"] == c["input"]
            assert b["outputs"] == c["outputs"]
            checked(b["data"])
            for v in b["outputs"].values():
                checked(v)
    assert len(names) == len(plan["sources"])
    for v in source["weights"].values():
        checked(v)
    return names, hashes, source["weights"]


def main():
    refs = {kind: reference(OUT / f"{kind}.json") for kind in RECEIPTS}
    data = {kind: read_json(checked(val)) for kind, val in refs.items()}
    for r in data.values():
        for k in ("operator", "driver"):
            if k in r:
                checked(r[k])
    calib, held = (data[f"evaluate-{key}"] for key in ("calibration", "independent"))
    assert (
        held["calibration"] == refs["evaluate-calibration"] == data["views-exact"]["locked_recipe"]
    )
    assert held["calibration"] == data["views-camera-all-references"]["locked_recipe"]
    assert (
        data["diagnostics"]["source"]
        == refs["evaluate-independent"]
        == data["views-exact"]["holdout"]
    )
    assert data["views-camera-all-references"]["source"] == refs["views-camera-report"]
    assert held["source"] == refs["independent/parent/result"]
    assert held["plan"] == refs["independent/plan"] == data["independent/inputs"]["plan"]
    a, b, weights = check_panel(calib)
    c, d, matched_weights = check_panel(held)
    assert (
        len(a) == 24
        and len(c) == 32
        and a.isdisjoint(c)
        and b.isdisjoint(d)
        and weights == matched_weights
    )
    for binding in data["independent/plan"]["excluded_spatial_panels"]:
        characters = [r["source"] for r in read_json(checked(binding))["sources"]]
        assert all(r["id"] not in c and r["cache_sha256"] not in d for r in characters)

    camera = data["views-camera-all-references"]["report"]["rows"]
    exact = data["views-exact"]["report"]["rows"]
    assert len(camera) == 8 and len(exact) == 2
    assert not any(any(x.values()) for x in data["ordinary"]["changes"].values())
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    for r in camera:
        for b in r["native"]:
            labels = {t["label"] for t in b["panels"]}
            assert "ISO100 AHD reference" in labels
            if r["id"].startswith("mesh-"):
                assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= labels
        r["native"] = [tile(d) for d in r["native"]]
    for r in exact:
        for label in ("all", "triplet"):
            r[label] = tile(r[label])
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {"weights": weights, "locked": calib["policy"]["locked"], "exact": exact, "camera": camera},
    )
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            "calibration": calib["summary"],
            "holdout": held["summary"],
            "audit": data["audit"]["layouts"],
            "equal_gap": data["diagnostics"]["diagnostic_equal_gap"],
            "selection": data["diagnostics"]["decisions"],
            "ordinary": data["ordinary"]["changes"],
            "camera_DN16": {r["id"]: r["difference_DN16"] for r in camera},
        },
    )
    files = {f"receipts/{k}.json": v for k, v in refs.items()}
    files.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    for file in (
        "spatial-junction-phase-v1/capture_warped.py",
        "spatial-junction-phase-v1/junction_phase_field.py",
        "spatial-junction-phase-v1/replay.py",
        "spatial-junction-phase-v1/pool_probe.py",
        "spatial-junction-phase-v1/audit_spatial.py",
        "spatial-junction-phase-v1/ordinary_phase.py",
        "local-junction-support-v1/capture_junction.py",
        "local-junction-support-v1/replay_junction.py",
        "local-junction-support-v1/review_junction.py",
        "local-nested-support-v1/replay_nested_parents.py",
    ):
        files[f"reused/{file}"] = reference(HERE.parent / file)
    for file in (
        "src/demosaic/_mesh_junction.py",
        "src/demosaic/mesh_carrier_fit.py",
        "configs/gfx-qualitative-20231231.json",
        "configs/gfx-green-mesh-20231231.json",
    ):
        files[f"repo/{file}"] = reference(ROOT / file)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as stream:
        for name, item in files.items():
            stream.add(checked(item), arcname=name, recursive=False)
    with tarfile.open(archive) as stream:
        assert set(stream.getnames()) == files.keys()
        for name, item in files.items():
            with stream.extractfile(name) as f:
                assert file_digest(f, "sha256").hexdigest() == item["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "archive": bind(archive),
            "native": bind(manifest),
            "summary": bind(summary),
            "members": files,
            "scope": "Frozen-model phase selection, optical crop panel and qualitative GFX100S review.",
        },
    )
    print(bind(archive), flush=True)


if __name__ == "__main__":
    main()
