"""Freeze an amplitude and shape policy on the earlier calibration photos."""

from collections import Counter
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import adaptive_phase_field as model
import replay as spatial_eval

metric = spatial_eval.metric
OUT = model.OUT
BASE = ("baseline", 1)
LIMITS = spatial_eval.LIMITS
CHOICES = {
    "fixed-local": ("affine", "curved"),
    "fixed-guarded": ("affine-guard", "curved-guard"),
    "fixed-pooled": ("affine-pool", "curved-pool"),
    "adaptive-local": tuple(f"select-{x:g}" for x in model.MARGINS),
    "adaptive-guarded": tuple(f"guard-{x:g}" for x in model.MARGINS),
}
REPORTED = {
    "ancestor": BASE,
    "earlier_curve": ("curved", 1),
    "affine_full": ("affine", 1),
    "adaptive_half_local_full": ("select-0.5", 1),
    "adaptive_half_guarded_full": ("guard-0.5", 1),
}


def panel_rows(rows):
    panels = spatial_eval.subsets(rows)
    for key in ("affine", "curved"):
        relevant = [row for row in rows if row["fixture"]["geometry"].get("phase_class") == key]
        if relevant:
            panels[key] = relevant
    return panels


def lock(rows):
    split = panel_rows(rows)
    pre = metric.score(split["stationary"], BASE)["means"][metric.JUNCTION]
    trials = {}
    for name in model.ARMS[1:]:
        trials[name] = []
        for dose in np.linspace(0, 1, 21):
            setting = (name, float(dose))
            all_, varying, stationary = (
                metric.score(split[key], setting) for key in ("all", "varying", "stationary")
            )
            trials[name].append(
                {
                    "setting": setting,
                    "all": all_,
                    "varying": varying,
                    "stationary": stationary,
                    "admissible": spatial_eval.within(all_, stationary, pre),
                }
            )

    def best(options):
        return max(
            (v for name in options for v in trials[name] if v["admissible"]),
            key=lambda v: (
                v["varying"]["means"][metric.RESPONSE],
                -v["varying"]["means"][metric.JUNCTION],
            ),
        )

    return {
        "limits": LIMITS,
        "trials": trials,
        "locked": {name: best(options)["setting"] for name, options in CHOICES.items()},
    }


def selection(rows):
    roles = []
    for role in range(7):
        counts = {}
        for key in model.ARMS[1:]:
            events = [
                draw["trace"][role]["arms"].get(key, {}) for row in rows for draw in row["draws"]
            ]
            counts[key] = {
                "nominated": dict(Counter(e.get("family") or "none" for e in events)),
                "admitted": sum(e.get("admitted", False) for e in events),
                "changed": sum(e.get("change", False) for e in events),
            }
        roles.append(counts)
    return roles


def summarize(rows, policy):
    choices = REPORTED | policy["locked"]
    results = {}
    for name, panel in panel_rows(rows).items():
        if not panel:
            continue
        scores = {}
        for key, arm in choices.items():
            result = metric.score(panel, arm)
            if arm != BASE:
                result["against_ancestor"] = metric.paired(panel, arm, BASE)
                result["against_earlier_curve"] = metric.paired(
                    panel, arm, REPORTED["earlier_curve"]
                )
            scores[key] = result
        results[name] = {"count": len(panel), "scores": scores, "selection": selection(panel)}
    return {"choices": choices, "panels": results}


def evaluate(group):
    root = OUT if group == "independent" else model.spatial.OUT
    source = reference(root / group / "parent/result.json")
    calibration = None if group == "calibration" else reference(OUT / "evaluate-calibration.json")
    with patch.object(spatial_eval, "model", model):
        rows, plan, seconds = spatial_eval.collect(source, oracle=False)
    policy = lock(rows) if calibration is None else read_json(checked(calibration))["policy"]
    summary = summarize(rows, policy)
    print(policy["locked"], flush=True)
    for key, group_data in summary["panels"].items():
        for name, record in group_data["scores"].items():
            print(
                key,
                name,
                [
                    round(record["means"][k], 5)
                    for k in (metric.RESPONSE, metric.JUNCTION, metric.GAP, metric.ADD)
                ],
                flush=True,
            )
    write_json(
        OUT / f"evaluate-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "source": source,
            "plan": plan,
            "calibration": calibration,
            "policy": policy,
            "summary": summary,
            "rows": rows,
            "seconds": seconds,
        },
    )


if __name__ == "__main__":
    evaluate(sys.argv[1])
