"""Capture a new held mixture of affine, curved and stationary junctions."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "spatial-junction-phase-v1"))
import capture_warped as prior

RENDERER = Path(prior.__file__)
SPATIAL = prior.OUT
SEED = 202611200800


def choose(kind, root):
    assert kind == "independent"
    engine = prior.ENGINE
    previous = SPATIAL
    prior_original = engine.freeze

    def freeze():
        engine.COUNT = 32
        engine.prior.EXCLUSIONS += tuple(
            previous / group / "plan.json" for group in ("calibration", "independent")
        )
        return prior_original()

    with patch.object(engine, "freeze", freeze):
        original = OLD_CHOOSE(kind, root)
    for r in original["sources"]:
        i = r["index"]
        r["id"] = f"adaptive-{i:02d}"
        g = r["geometry"]
        # Mix the three phase classes across source families and illumination.
        kind_index = ((i % 8) + i // 8) % 8
        category = "affine" if kind_index < 3 else "curved" if kind_index < 6 else "stationary"
        g["phase_class"] = category
        g["stationary_junction"] = category == "stationary"
        if category == "affine":
            rng = np.random.default_rng(scene_seed(SEED, i, "junction-affine-fixture"))
            g["bend_cycles"] = [0.0, 0.0]
            signs = np.where(rng.uniform(size=2) < 0.5, -1.0, 1.0)
            g["drift_cycles"] = [(-0.5 * signs * rng.uniform(.13, .27, 2)).tolist(),
                                 (+0.5 * signs * rng.uniform(.13, .27, 2)).tolist()]
    relatives = [reference(previous / group / "plan.json") for group in ("calibration", "independent")]
    known = {
        (r["source"]["id"], r["source"]["cache_sha256"])
        for binding in relatives for r in read_json(checked(binding))["sources"]
    }
    assert len(original["sources"]) == 32
    for r in original["sources"]:
        assert all(r["source"]["id"] != name and r["source"]["cache_sha256"] != digest
                   for name, digest in known)
    return original | {
        "driver": reference(__file__),
        "renderer": reference(RENDERER),
        "excluded_spatial_panels": relatives,
        "scope": "Disjoint optical holdout with 12 affine, 12 curved, and 8 stationary difference bands",
    }


OLD_CHOOSE = prior.choose

if __name__ == "__main__":
    with patch.object(prior, "__file__", __file__), patch.object(prior, "OUT", OUT), patch.object(
        prior, "choose", choose
    ), patch.dict(prior.SEED, {"independent": SEED}):
        prior.main("independent")
