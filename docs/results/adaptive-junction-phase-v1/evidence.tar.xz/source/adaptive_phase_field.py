"""Select one spatial Bayer junction template before opening validation folds."""

from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "spatial-junction-phase-v1"))
import junction_phase_field as spatial
from pool_probe import pool

j = spatial.j
FAMILIES = ("affine", "curved")
MARGINS = (0.0, 0.5, 1.0)
ARMS = (
    "baseline",
    "affine",
    "curved",
    "affine-guard",
    "curved-guard",
    "affine-pool",
    "curved-pool",
    *(name for margin in MARGINS for name in (f"select-{margin:g}", f"guard-{margin:g}")),
)


@dataclass
class Template:
    curved: bool
    coefficients: np.ndarray
    angles: np.ndarray
    nuisance: np.ndarray
    signal: np.ndarray
    station: np.ndarray
    amplitude: float
    ratio: float
    vote: float = 0.0
    loss_gain: float = 0.0


def discover(obs, f, bands, inner, taper, center):
    learn = inner & (obs.fold == 0)
    weight = taper[learn] / obs.variance[learn]
    templates = {}
    for mode in FAMILIES:
        curved = mode == "curved"
        coeff = spatial.fit_envelopes(obs, f, bands, 0, curved, inner, taper)
        angles = spatial.phases(obs.x, obs.y, coeff, f, curved)
        nuisance, count = spatial.shape_baseline(obs, f, bands, center, angles)
        signal = np.cos(angles[:, 0] - angles[:, 1])
        projected = spatial.solve(nuisance[learn], weight, signal[learn])
        residual = signal[learn] - nuisance[learn] @ projected
        power = weight @ residual**2
        templates[mode] = Template(
            curved,
            coeff,
            angles,
            nuisance,
            signal,
            projected[-count:],
            float((weight * residual) @ obs.raw[learn] / max(1e-20, power)),
            float(power / max(1e-20, weight @ signal[learn] ** 2)),
        )

    # Both forecasts face the same nuisance subspace on Q1. Q0 fixes their signs and
    # effect sizes. Columns from both families remove competing fundamentals and harmonics.
    select = inner & (obs.fold == 1)
    affine, curved = templates.values()
    offset = obs.nuisance.shape[1]
    n_station = len(affine.station)
    common = np.c_[affine.nuisance, curved.nuisance[:, offset:-n_station]][select]
    a = np.column_stack((affine.signal[select], curved.signal[select]))
    weight = taper[select] / obs.variance[select]
    residual = a - common @ spatial.solve(common, weight, a)
    moment = (residual.T * weight) @ obs.raw[select]
    power = weight @ residual**2
    moment_cov = (residual.T * (weight**2 * obs.variance[select])) @ residual

    # Predictive squared-error reduction, normalized by its noise SD. The pairwise
    # SD includes covariance because two forecasts use the same Q1 observations.
    effects = np.array([a.amplitude for a in templates.values()])
    votes = np.sign(effects) * moment / np.sqrt(np.maximum(1e-20, np.diag(moment_cov)))
    loss_gain = effects * (2 * moment - effects * power)
    difference = effects * (-1.0, 1.0)
    uncertainty = float(2 * np.sqrt(max(1e-20, difference @ moment_cov @ difference)))
    for a, vote, gain in zip(templates.values(), votes, loss_gain, strict=True):
        a.vote, a.loss_gain = float(vote), float(gain)
    return templates, float((loss_gain[1] - loss_gain[0]) / uncertainty)


def select_family(templates, improvement, margin):
    affine, curved = templates.values()
    if affine.ratio < 0.025:
        return "curved" if curved.ratio >= 0.025 and curved.loss_gain > 0 else None
    if curved.ratio >= 0.025 and curved.loss_gain > 0 and improvement > margin:
        return "curved"
    return "affine"


def validate(obs, a, inner):
    waves = j._quadratures(a.angles)
    fundamentals = [
        list(
            map(float, obs.held_score(waves[:, d, 0], np.c_[obs.nuisance, waves[:, 1 - d]], inner))
        )
        for d in (0, 1)
    ]
    score = list(map(float, obs.held_score(np.sign(a.amplitude) * a.signal, a.nuisance, inner)))
    allowed = (
        a.ratio >= 0.025
        and score[0] >= 3.25
        and score[1] >= 0.90
        and all(z >= 2.75 and each > 0 for z, each in fundamentals)
    )
    return allowed, {
        "fundamentals": fundamentals,
        "score": score,
        "ratio": a.ratio,
        "Q1_signed_z": a.vote,
        "Q1_weighted_loss_gain": a.loss_gain,
        "Q0_amplitude_DN16": a.amplitude * 65535,
    }


def station_window():
    centers = np.arange(-72, 73, 16)
    y, x = np.meshgrid(centers, centers, indexing="ij")
    return x.ravel(), y.ravel()


def difference_support(obs, a):
    # Estimate local support for the correction itself on Q2 and Q3. A wider
    # neighborhood supplies samples, but each 16-pixel cell owns its verdict.
    gx, gy = station_window()
    radius = 20.0
    votes, powers = [], []
    sign = np.sign(a.amplitude)
    template = sign * a.signal
    for fold in (2, 3):
        val = obs.fold == fold
        x, y = obs.x[val], obs.y[val]
        indices = np.stack(
            [
                np.flatnonzero((abs(x - u) < radius) & (abs(y - v) < radius))
                for u, v in zip(gx, gy, strict=True)
            ]
        )
        dx, dy = x[indices] - gx[:, None], y[indices] - gy[:, None]
        variance = obs.variance[val][indices]
        w = np.exp(-0.5 * (dx**2 + dy**2) / 13**2) / variance
        basis = a.nuisance[val][indices]
        target = template[val][indices]
        weighted = basis * w[..., None]
        gram = basis.transpose(0, 2, 1) @ weighted
        # The local step/bias/span controls can become exactly collinear in a station.
        projector = np.linalg.pinv(gram, hermitian=True, rcond=1e-9) @ weighted.transpose(0, 2, 1)
        remnant = target - (basis @ (projector @ target[..., None]))[..., 0]
        signed = w * remnant
        votes.append(np.sum(signed * obs.raw[val][indices], axis=1))
        powers.append(np.sum(signed**2 * variance, axis=1))
    votes, powers = np.asarray(votes), np.asarray(powers)
    per_fold = votes / np.sqrt(np.maximum(1e-20, powers))
    pooled = votes.sum(axis=0) / np.sqrt(np.maximum(1e-20, powers.sum(axis=0)))
    support = np.clip(np.minimum(pooled, per_fold.min(axis=0) + 0.75) / 1.75, 0, 1)
    own = support.reshape(j._SIDE, j._SIDE).repeat(j._CELL, axis=0).repeat(j._CELL, axis=1)
    return np.minimum(j._pixel_map(support), own)


def render(anchor, context, obs, f, center, a, wb, matrix):
    rgb = context[1].copy()
    rgb[spatial.CROP] = anchor[1]
    raw_rgb = rgb[(obs.y + j._CENTER).astype(int), (obs.x + j._CENTER).astype(int)]
    neutral = np.linalg.solve(matrix.astype(float), np.ones(3)) / wb
    neutral /= neutral[1]

    wire = j._local_wire_support(obs, a.angles)
    full = (spatial.FULL_X, spatial.FULL_Y)
    angles = spatial.phases(*full, a.coefficients, f, a.curved)
    stationary = spatial.stationary_side(*full, j._wave_angles(*full, f), center)
    sign, cap = np.sign(a.amplitude), abs(a.amplitude)
    harmonic = sign * (np.cos(angles[:, 0] - angles[:, 1]) - stationary @ a.station).reshape(
        256, 256
    )
    edge = j._FIELD_EDGE[:, None] * j._FIELD_EDGE
    field = j._GAINS * wire * (harmonic * edge)[spatial.CROP]

    columns = np.c_[a.nuisance, a.signal]
    local = j._amplitudes(
        obs, columns, a.nuisance.shape[1], sign, cap, raw_rgb, sigma=35, radius=80
    )
    whole = pool(obs, columns, a.nuisance.shape[1], sign, cap, raw_rgb)
    local_support = difference_support(obs, a) if whole > 0 else np.zeros_like(wire)
    trial = (local[spatial.CROP], whole * local_support, whole)
    values = tuple(
        (anchor + (field * amp) * neutral[:, None, None]).astype(anchor.dtype) for amp in trial
    )
    return values, float(wire.mean()), float(local_support.mean())


def deliver(anchor, context, obs, f, bands, wb, matrix, *, geometry=None):
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    taper = np.exp(-0.5 * (obs.x**2 + obs.y**2) / 75**2)
    center = spatial.stationary(obs, inner, taper)
    templates, improvement = discover(obs, f, bands, inner, taper, center)
    selected = {f"{margin:g}": select_family(templates, improvement, margin) for margin in MARGINS}

    # All selection is finished before this point. A rejected nominated family returns the anchor.
    output = dict.fromkeys(ARMS, anchor)
    trace = {}
    for key, a in templates.items():
        allowed, trace[key] = validate(obs, a, inner)
        if allowed:
            estimates, wire, support = render(anchor, context, obs, f, center, a, wb, matrix)
            for name, result in zip((key, f"{key}-guard", f"{key}-pool"), estimates, strict=True):
                output[name] = result
            trace[key].update({"wire_fraction": wire, "guard_fraction": support})
        trace[key]["admitted"] = allowed
    for margin, family in selected.items():
        for prefix, suffix in (("select", ""), ("guard", "-guard")):
            name = f"{prefix}-{margin}"
            if family is None:
                trace[name] = {"family": None, "admitted": False, "change": False}
                continue
            output[name] = output[family + suffix]
            trace[name] = trace[family] | {"family": family}
    for key in ARMS[1:]:
        family = key.removesuffix("-guard").removesuffix("-pool")
        trace.setdefault(key, trace[family].copy() if family in trace else {})
        trace[key]["change"] = not np.array_equal(anchor, output[key])
    return output, {
        "status": "measured",
        "Q1_curve_advantage": improvement,
        "frequency": f.tolist(),
        "arms": trace,
    }


def replay(*args, **kwargs):
    from unittest.mock import patch

    with patch.object(spatial, "ARMS", ARMS), patch.object(spatial, "deliver", deliver):
        return spatial.replay(*args, **kwargs)
