"""Attach the same camera references to both noise-profile boards."""

from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from view_adaptive import OUT, board

REFERENCES = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")


def panels(binding):
    with Image.open(checked(binding["image"])) as image:
        return [
            (item["label"], np.asarray(image.crop((x, y, x + w, y + h))))
            for item in binding["panels"]
            for x, y, w, h in [item["png_xywh"]]
        ]


if __name__ == "__main__":
    src = reference(OUT / "views-camera-report.json")
    data = read_json(checked(src))
    rows = data["report"]["rows"]
    nominal = {
        r["id"].split("mesh-nominal-")[1]: r for r in rows if r["id"].startswith("mesh-nominal-")
    }
    output = OUT / "native/camera-all-references"
    output.mkdir(exist_ok=True)
    for row in rows:
        if not row["id"].startswith("mesh-profile3879-"):
            continue
        comparable = nominal[row["id"].split("mesh-profile3879-")[1]]
        assert row["ROI"] == comparable["ROI"] and row["RAW"] == comparable["RAW"]
        from_nominal = {b["exposure"]: b for b in comparable["native"]}
        updated = []
        for native in row["native"]:
            reference_board = from_nominal[native["exposure"]]
            existing = panels(native)
            controls = [(k, img) for k, img in panels(reference_board) if k in REFERENCES]
            assert tuple(name for name, _ in controls) == REFERENCES
            expected = dict(controls)
            for label, pixels in existing:
                if label in expected:
                    np.testing.assert_array_equal(pixels, expected[label])
            existing = [(k, img) for k, img in existing if k not in REFERENCES]
            dest = output / Path(native["image"]["path"]).name
            updated.append(
                board([*existing, *controls], dest)
                | {
                    "exposure": native["exposure"],
                    "source": native,
                    "same_coordinates_references": reference_board["image"],
                }
            )
        row["native"] = updated
    write_json(
        OUT / "views-camera-all-references.json",
        {
            "driver": reference(__file__),
            "source": src,
            "locked_recipe": data["locked_recipe"],
            "report": data["report"],
        },
    )
