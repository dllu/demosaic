"""Render native exact and standing GFX comparisons for the frozen policy."""

from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import adaptive_phase_field as model
from evaluate_adaptive import metric

sys.path.append(str(model.HERE.parent / "local-junction-support-v1"))
from review_junction import image, board

OUT = model.OUT
CROP = model.spatial.crop
FIXED = OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"


def fields(parent, local, scene, colors, roi, noise, wb, matrix, clearance, policy):
    outputs, trace = model.replay(
        parent, local, scene, colors, roi, noise, wb, matrix, clearance=clearance
    )
    choices = {
        "Regional RAW refit": ("baseline", 1),
        "Fixed affine": ("affine", 1),
        "Fixed curve": ("curved", 1),
        "Selected phase": policy["adaptive-local"],
        "Selected + local support": policy["adaptive-guarded"],
        "Affine preference (0.5 SD)": ("select-0.5", 1),
        "Affine preference + support": ("guard-0.5", 1),
        "Fixed + local support": policy["fixed-guarded"],
        "Fixed + whole-region pool": policy["fixed-pooled"],
    }
    baseline = outputs["baseline"]
    rendered = []
    for label, (name, dose) in choices.items():
        result = outputs[name]
        if dose != 1:
            result = (baseline + dose * (result.astype(float) - baseline)).astype(baseline.dtype)
        rendered.append((label, result))
    return rendered, trace


def exact(src, room, policy):
    data = read_json(checked(src))
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    selected = {}
    for row in data["rows"]:
        kind = row["fixture"]["geometry"]["phase_class"]
        if kind == "stationary":
            continue
        for draw in row["draws"]:
            ancestor = metric.values(draw, ("baseline", 1))
            restored = metric.values(draw, policy["adaptive-local"])
            change = ancestor[metric.JUNCTION] - restored[metric.JUNCTION]
            if kind not in selected or change > selected[kind][0]:
                selected[kind] = change, row, draw
    views = []
    for kind, (gain, row, draw) in selected.items():
        parent = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)[0]
        with np.load(checked(draw["input"]), allow_pickle=False) as f:
            inputs = {k: f[k] for k in f.files}
        scene = inputs["scene_packed"].copy()
        scene[cut] = inputs["packed"][0]
        wb, matrix, colors = [inputs[k] for k in ("wb", "matrix", "colors")]
        tests, trace = fields(
            parent, local, scene, colors, roi, plan["noise"], wb, matrix, 48, policy
        )
        noisy = noisy_malvar(
            {
                "packed": inputs["packed"][:1],
                **{k: inputs[k][None] for k in ("colors", "wb", "matrix")},
            }
        )[0]
        tiles = [
            ("Noisy Malvar", CROP(noisy, local)),
            ("Local 50k", CROP(parent, local)),
            *tests,
            ("Exact GT", CROP(inputs["target"][0], local)),
        ]
        panels = {label: image(value, wb, matrix, 2.0) for label, value in tiles}
        out = board(list(panels.items()), room / f"{row['id']}-comparison.png")
        triplet = board(
            [(k, panels[k]) for k in ("Noisy Malvar", "Selected phase", "Exact GT")],
            room / f"{row['id']}-triplet.png",
        )
        views.append(
            {
                "id": row["id"],
                "fixture": row["fixture"],
                "input": draw["input"],
                "outputs": draw["outputs"],
                "draw": draw["draw"],
                "phase_class": kind,
                "junction_decrease_DN16": gain,
                "noise": plan["noise"],
                "exposure": 2.0,
                "ROI": local,
                "scene_ROI": roi,
                "trace": trace,
                "all": out,
                "triplet": triplet,
            }
        )
        print(row["id"], kind, gain, flush=True)
    return {"source": src, "rows": views}


def camera(room, policy):
    fixed = reference(FIXED)
    previous = read_json(checked(fixed))
    rows = []
    for item in previous["standing"]:
        roi = item["local_ROI"]
        with np.load(checked(item["input"]), allow_pickle=False) as f:
            scene, colors, wb, matrix = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        parent = np.load(checked(item["predictions"]["local50k"]), allow_pickle=False)[0]
        tests, trace = fields(
            parent, roi, scene, colors, roi, item["noise"], wb, matrix, 16, policy
        )
        views = []
        for native in item["displays"]:
            with Image.open(checked(native["board"]["image"])) as raster:
                source = np.asarray(raster)
            previous_tiles = {}
            for t in native["board"]["panels"]:
                x, y, w, h = t["png_xywh"]
                previous_tiles[t["name"]] = source[y : y + h, x : x + w]
            ex = native["exposure"]
            np.testing.assert_array_equal(
                image(CROP(parent, roi), wb, matrix, ex), previous_tiles["Local 50k"]
            )
            tiles = [(k, previous_tiles[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            tiles.extend((k, image(v, wb, matrix, ex)) for k, v in tests)
            tiles.extend(
                (k, previous_tiles[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in previous_tiles
            )
            views.append(
                board(tiles, room / f"{item['id']}-x{ex:g}.png")
                | {"exposure": ex, "source": native["board"]}
            )
        delta = {
            k: float(np.sqrt(np.mean((v.astype(float) - tests[0][1]) ** 2)) * 65535)
            for k, v in tests
        }
        rows.append(
            {
                "id": item["id"],
                "input": item["input"],
                "RAW": item["raw"],
                "noise": item["noise"],
                "ROI": item["global_ROI"],
                "local_ROI": roi,
                "trace": trace,
                "difference_DN16": delta,
                "compared": item["predictions"]["local50k"],
                "native": views,
            }
        )
        arms = trace["arms"]
        print(
            item["id"],
            trace.get("Q1_curve_advantage"),
            arms.get(policy["adaptive-local"][0], {}).get("family"),
            {k: round(v, 5) for k, v in delta.items()},
            flush=True,
        )
    return {"source": fixed, "rows": rows, "checkpoints": previous["checkpoints"]}


if __name__ == "__main__":
    torch.set_num_threads(2)
    kind = sys.argv[1]
    root = OUT / "native" / kind
    root.mkdir(exist_ok=True, parents=True)
    recipe = reference(OUT / "evaluate-calibration.json")
    policy = read_json(checked(recipe))["policy"]["locked"]
    src = reference(OUT / "evaluate-independent.json") if kind == "exact" else None
    rendered = exact(src, root, policy) if kind == "exact" else camera(root, policy)
    write_json(
        OUT / f"views-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(model.__file__)),
            "locked_recipe": recipe,
            "holdout": src,
            "report": rendered,
        },
    )
