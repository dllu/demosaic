"""Measure whether station interpolation transfers residue into exact gaps."""

from pathlib import Path
from statistics import mean
from unittest.mock import patch

import numpy as np
from scipy.ndimage import distance_transform_edt
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replay_replicated as review
import replicated_phase as model

OUT = model.OUT


def station_cells(grid):
    return np.repeat(np.repeat(grid.reshape(10, 10), 16, axis=0), 16, axis=1)


def main():
    torch.set_num_threads(2)
    source = reference(OUT / "verification.json")
    data = read_json(checked(source))
    lock = read_json(checked(data["preselected_policy"]))
    arm, dose = lock["candidate"]["choice"]
    original_field = model.rank.field
    method, cut = arm.split("/")
    shape = lambda grid: np.minimum(original_field(grid), station_cells(grid))
    plan = read_json(checked(data["plan"]))
    y, x = plan["query"][1], plan["query"][0]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    cutout = np.s_[..., y // 2 : (y + 256) // 2, x // 2 : (x + 256) // 2]
    clipped, layers = [], []
    with (
        patch.object(model, "OPTIONS", ((method, float(cut), arm),)),
        patch.object(model, "ARMS", ("near", "unchecked", arm)),
    ):
        for row in data["rows"]:
            draws = []
            for draw in row["draws"]:
                f = review.replay.arrays(draw["input"])
                pred = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)
                raw = f["scene_packed"].copy()
                if (
                    review.MISSING in draw["nominal"]["near"]
                    and draw["evidence"][0]["state"] == "ambiguous rank"
                ):
                    raw[cutout] = f["packed"][0]
                    model_args = (
                        pred[0],
                        local,
                        raw,
                        f["colors"],
                        roi,
                        np.asarray(draw["actual_frequency"]),
                        plan["noise"],
                        f["wb"],
                        f["matrix"],
                    )
                    _, fields, _ = model.qualify(*model_args)
                    absent = fields[arm]
                    if absent is not None:
                        support = review.replay.support_for_scoring(f["support"])
                        metric = review.replay.WireFundamental(
                            f | {"target": f["target"][:4], "support": support},
                            row["fixture"]["geometry"],
                        )
                        distance = distance_transform_edt(metric.gap)
                        values = (
                            review.replay.luma(
                                absent[None, :, 16:144, 16:144], f["wb"], f["matrix"]
                            )[0]
                            ** 2
                        )
                        total = values[metric.gap].sum()
                        by_dist = [
                            float(values[(distance > low) & (distance <= high)].sum())
                            for low, high in ((0, 4), (4, 8), (8, 16), (16, np.inf))
                        ]
                        np.testing.assert_allclose(total, sum(by_dist), rtol=1e-12)
                        layers.append(
                            {
                                "id": row["id"],
                                "draw": draw["draw"],
                                "energy_by_depth": by_dist,
                                "total": float(total),
                                "input": draw["input"],
                            }
                        )
                with patch.object(model.rank, "field", shape):
                    result = review.evaluate(
                        row["fixture"], plan["noise"], pred, f, raw, cutout, roi
                    )
                draws.append(result | {"draw": draw["draw"], "input": draw["input"]})
            clipped.append(row | {"draws": draws})
            if len(clipped) % 8 == 0:
                print("Clipped station render", len(clipped), flush=True)
    original = review.arm_stats(data["rows"], (arm, dose))
    changed = review.arm_stats(clipped, (arm, dose))
    gain = (
        original["means"][review.RESPONSE]
        - review.arm_stats(data["rows"], ("near", 1))["means"][review.RESPONSE]
    )
    adjusted_gain = (
        changed["means"][review.RESPONSE]
        - review.arm_stats(clipped, ("near", 1))["means"][review.RESPONSE]
    )
    matched_dose = dose * adjusted_gain / gain
    equal = review.arm_stats(data["rows"], (arm, matched_dose))
    indexed = []
    # Ground-truth gap pixels are used only for analysis and never to set the rendering mask.
    for a, b in zip(clipped, data["rows"], strict=True):
        row = []
        for result, prior in zip(a["draws"], b["draws"], strict=True):
            row.append(
                result
                | {"powers": result["powers"] | {"equal_response_original": prior["powers"][arm]}}
            )
        indexed.append(a | {"draws": row})
    fraction = (
        np.sum([r["energy_by_depth"] for r in layers], axis=0) / sum(r["total"] for r in layers)
    ).tolist()
    output = {
        "driver": reference(Path(__file__)),
        "verification": source,
        "preselected_policy": data["preselected_policy"],
        "energy_depths": [[0, 4], [4, 8], [8, 16], [16, None]],
        "shares_pooled": fraction,
        "evidence": layers,
        "fixed_dose": {"original": original, "clipped": changed},
        "equal_recovery": {
            "original_dose": matched_dose,
            "original": equal,
            "clipped": changed,
            "paired": review.paired(
                indexed, (arm, dose), ("equal_response_original", matched_dose)
            ),
        },
    }
    assert adjusted_gain >= 0 and matched_dose <= dose
    write_json(OUT / "gap-support.json", output)
    print(
        "shares",
        fraction,
        "fixed dose",
        original["means"][review.MISSING],
        changed["means"][review.MISSING],
        "matched original",
        equal["means"][review.MISSING],
        "gains",
        gain,
        adjusted_gain,
        flush=True,
    )


if __name__ == "__main__":
    main()
