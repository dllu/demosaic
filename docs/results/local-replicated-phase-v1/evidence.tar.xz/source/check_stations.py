"""Verify fixed donor phase and held tangent replication on all Bayer patterns."""

from pathlib import Path

import numpy as np

from demosaic._mesh_near_phase import _observations, _pool_phases
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import replicated_phase as model

ROI = (151, 149, 160, 160)
CELL = (4, 4)
FREQUENCY = np.asarray(((0.115, 0.074), (0.089, -0.079)))


def patch_nolift(raw, weak, cell, value, *, site=None):
    dx, dy = ROI[0] + 16 * cell[1], ROI[1] + 16 * cell[0]
    here = np.s_[dy : dy + 16, dx : dx + 16]
    if site is None:
        raw[here] += value * weak[here]
    else:
        row, col = site
        raw[here][row::2, col::2] += value * weak[here][row::2, col::2]


def packed(raw):
    return np.stack([raw[r::2, c::2] for r, c in model._SITES]).astype(np.float32)


def main():
    y, x = np.indices((480, 480))
    inside = (x >= ROI[0]) & (x < ROI[0] + 160) & (y >= ROI[1]) & (y < ROI[1] + 160)
    strong, weak = (
        amplitude * np.cos(2 * np.pi * (f[0] * x + f[1] * y) + phase)
        for amplitude, f, phase in zip((0.018, 0.018), FREQUENCY, (0.8, -0.7), strict=True)
    )
    index = CELL[0] * 10 + CELL[1]
    tangent = (CELL[0] + 1, CELL[1] + 1)
    base = 0.09 + strong + np.where(inside, 0, weak)
    single = base.copy()
    patch_nolift(single, weak, CELL, 1)
    pair = single.copy()
    patch_nolift(pair, weak, tangent, 1)
    reverse = single.copy()
    patch_nolift(reverse, weak, tangent, -1)
    shot, read = 0.0001, 6e-7
    outputs = []
    for layout, colors in PATTERNS.items():
        pos = model._positions(colors, *ROI[:2])
        one_green = base.copy()
        patch_nolift(one_green, weak, CELL, 1)
        patch_nolift(one_green, weak, CELL, -1, site=pos[0])
        states = []
        fixed = []
        for raw in (single, pair, reverse, one_green):
            scene = packed(raw)
            sites = [model._sites(scene, *ROI[:2], 160, r, c) for r, c in model._SITES]
            eligible, scores = model.support(scene, ROI[:2], pos, FREQUENCY, 1, sites, shot, read)
            assert eligible[index]
            states.append({k: float(v[index]) for k, v in scores.items()})
            fixed.append(_observations(scene, ROI[:2], FREQUENCY, 1, shot, read))
        for donors in fixed[1:]:
            for a, b in zip(donors, fixed[0], strict=True):
                np.testing.assert_array_equal(a, b)
        first, good, bad, asymmetric = states
        assert first["center"] > 3 and first["neighbor"] < 1
        assert good["both_and_neighbor"] > 3 and bad["neighbor"] < 1
        assert asymmetric["both_greens"] < 0.01 and asymmetric["center"] > 1
        outputs.append(
            {
                "layout": layout,
                "isolated": first,
                "tangent_repeat": good,
                "tangent_phase_reversal": bad,
                "single_green": asymmetric,
            }
        )
    write_json(
        model.OUT / "station-audit.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "origin": ROI[:2],
            "station": CELL,
            "tangent_neighbor": tangent,
            "donors_bit_identical": True,
            "tests": outputs,
        },
    )


if __name__ == "__main__":
    main()
