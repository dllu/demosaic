"""Render the actual capped crop method on exactly matched native pixels."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replicated_phase as model
from replay_replicated import RESPONSE, MISSING
from check_station_api import call, MODE
from review_replicated import select, view

LABELS = {
    "parent": "Local 50k",
    "nested": "Nearby phase",
    "unbounded": "Tangent replication",
    "ring_phase": "Station-capped phase",
}


def arms(parent, local, raw, colors, roi, frequency, noise, wb, matrix, choice):
    clearance = 16 if roi == local else 48
    result, _, trace = model.qualify(
        parent, local, raw, colors, roi, frequency, noise, wb, matrix, clearance=clearance
    )
    bounded = call(
        parent, local, raw, colors, roi, noise, wb, matrix, clearance=clearance, method=MODE
    )
    return {
        "parent": view.section(parent, *local),
        "nested": result["near"],
        "unbounded": select(result, choice),
        "ring_phase": bounded,
    }, trace


def exact(confirmation, dest, choice):
    data = read_json(checked(confirmation))
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    dose = choice[1]
    chosen = {}
    for row in data["rows"]:
        for draw in row["draws"]:
            if draw["evidence"][0]["state"] != "ambiguous rank":
                continue
            capped = model.replay.metrics_at(draw["powers"]["station_cap"], dose)
            open_ = model.replay.metrics_at(draw["powers"][choice[0]], dose)
            gain = capped[RESPONSE] - draw["nominal"]["near"][RESPONSE]
            label, benefit = (
                ("largest gap change prevented", open_[MISSING] - capped[MISSING])
                if MISSING in capped
                else ("largest continuous-wire gain", gain)
            )
            if label not in chosen or benefit > chosen[label][0]:
                chosen[label] = (benefit, row, draw, gain, capped.get(MISSING), open_.get(MISSING))
    assert len(chosen) == 2
    boards = []
    for label, (_, row, draw, gain, gap, unbounded_gap) in chosen.items():
        f = model.replay.arrays(draw["input"])
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")} | {"packed": f["packed"][:1]}
        parent, v120 = (
            np.load(checked(draw["outputs"][k]), allow_pickle=False)[0]
            for k in ("local50k", "v120")
        )
        raw = f["scene_packed"].copy()
        raw[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2] = f["packed"][0]
        nomination = np.asarray(draw["actual_frequency"])
        versions, trace = arms(
            parent, local, raw, colors, roi, nomination, plan["noise"], wb, matrix, choice
        )
        images = [noisy_malvar(camera)[0], v120]
        for data in versions.values():
            composed = parent.copy()
            view.section(composed, *local)[:] = data
            images.append(composed)
        images.append(f["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(LABELS[k] for k in versions), "Exact GT"]
        boards.append(
            view.native_board(
                dest,
                row["id"],
                images,
                camera,
                {
                    "query": plan["query"],
                    "input": draw["input"],
                    "fixture": row["fixture"],
                    "selected_for": label,
                    "draw": draw["draw"],
                    "noise": plan["noise"],
                    "optical_sigma": plan["sigma"],
                    "weights": plan["checkpoints"],
                    "nomination": nomination.tolist(),
                    "trace": trace,
                    "added_second_response_points": gain,
                    "absent_DN16_capped": gap,
                    "absent_DN16_unbounded": unbounded_gap,
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS["ring_phase"]), len(labels) - 1),
            )
        )
    return {"source": confirmation, "boards": boards}


def main(kind):
    torch.set_num_threads(2)
    capture = reference(model.OUT / "station-confirm.json")
    lock = read_json(checked(capture))["preselected_policy"]
    choice = read_json(checked(lock))["candidate"]
    out = model.OUT / "station-boards" / kind
    out.mkdir(exist_ok=True, parents=True)
    if kind == "camera":
        view.arcs = arms
        view.NAMES = LABELS
        data = view.standing(choice, out)
    else:
        data = exact(capture, out, choice)
    write_json(
        model.OUT / f"station-board-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "preselected_policy": lock,
            "source": capture,
            "data": data,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
