"""Freeze the successful tangent variant before capturing a third set of photos."""

from pathlib import Path

import torch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import capture_balanced as capture
import replay_replicated as replay

OUT = capture.OUT
SEED = 202611200607
ARM = "both_and_neighbor"
COUNT = 24


def freeze_lock():
    calcium = reference(OUT / "calibration.json")
    confirm = reference(OUT / "fresh.json")
    cal, new = (read_json(checked(binding)) for binding in (calcium, confirm))
    selected = cal["policy"]["per_family"][ARM]
    assert list(selected["choice"]) == new["summary"]["choices"][ARM]
    assert not new["summary"]["within_budgets"]["primary"]
    assert new["summary"]["within_budgets"][ARM]
    return {
        "driver": reference(__file__),
        "calibration": calcium,
        "confirmation": confirm,
        "preselected_family": ARM,
        "candidate": selected,
        "reason": "Both-green tangent replication passes all four limits on both panels and has lower peak absent-direction leakage than the other passing variant. Its dose and cutoff were fitted on calibration.",
        "seed": SEED,
        "source_count": COUNT,
        "limits": cal["policy"]["budgets"],
    }


def prep():
    torch.set_num_threads(2)
    root = OUT / "verification"
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    lock_path = OUT / "verification-lock.json"
    if not lock_path.exists():
        write_json(lock_path, freeze_lock())
    lock = reference(lock_path)
    if not (root / "plan.json").exists():
        capture.last.run.OUT = root
        capture.last.run.SEED = SEED
        capture.last.run.COUNT = COUNT
        paths = (
            *(OUT / name / "plan.json" for name in ("calibration", "fresh")),
            capture.PREVIOUS / "fresh" / "plan.json",
            capture.last.PREVIOUS / "fresh" / "plan.json",
            capture.last.CALIBRATION,
        )
        capture.last.run.prior.EXCLUSIONS += paths
        plan = capture.last.run.freeze()
        for row in plan["sources"]:
            row["target_balance"] = capture.balance(row, plan["sigma"], SEED)
            row["id"] = f"replicated-verification-{row['index']:02d}"
        plan |= {
            "driver": reference(__file__),
            "balance_source": reference(capture.__file__),
            "preselected_policy": lock,
            "primary": "Third source-disjoint check of both-green tangent replication.",
        }
        write_json(root / "plan.json", plan)
    plan = read_json(root / "plan.json")
    assert plan["preselected_policy"] == lock
    receipt = root / "inputs.json"
    if not receipt.exists():
        capture.last.run.prior.earlier.SEED = SEED
        rows = []
        for fixture in plan["sources"]:
            rows.append(
                capture.last.run.prior.earlier.capture(fixture, plan["noise"], root / "inputs")
            )
            if len(rows) % 8 == 0:
                print("Captured verification", len(rows), flush=True)
        write_json(
            receipt,
            {
                "driver": reference(__file__),
                "plan": reference(root / "plan.json"),
                "observations": rows,
            },
        )
    capture.last.run.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        capture.last.run.prior.parents.main()
    return lock


def main():
    lock = prep()
    locked = read_json(checked(lock))
    rows, parent, plan = replay.load("verification")
    policy = read_json(checked(locked["calibration"]))["policy"]
    final = policy | {"primary": locked["candidate"]}
    results = replay.summary(rows, final)
    op = reference(replay.model.__file__)
    assert op == read_json(checked(locked["calibration"]))["operator"]
    for key in ("near", "previous", "primary", "both_greens", "neighbor"):
        v = results["scores"][key]
        print(
            key,
            {
                m: round(v["means"][m], 6)
                for m in (replay.RESPONSE, replay.ABS, replay.FALSE, replay.MISSING, replay.ADDED)
            },
            "peak absent",
            v["peak"][replay.MISSING],
            "quiet",
            v["quiet_added"],
            "passes",
            results["within_budgets"][key],
            flush=True,
        )
    write_json(
        OUT / "verification.json",
        {
            "driver": reference(__file__),
            "operator": op,
            "preselected_policy": lock,
            "source": parent,
            "plan": plan,
            "summary": results,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
