"""Verify a locked station interpolation cap on a fourth photo panel."""

from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import capture_balanced as capture
import replicated_phase as model
import replay_replicated as review

OUT = capture.OUT
COUNT = 24
SEED = 202611200612
FRONTIER = model.rank.field


def local_cap(stations):
    own = np.repeat(np.repeat(stations.reshape(10, 10), 16, axis=0), 16, axis=1)
    return np.minimum(FRONTIER(stations), own)


def freeze_lock():
    v = reference(OUT / "verification.json")
    gap = reference(OUT / "gap-support.json")
    trace = read_json(checked(gap))
    assert trace["verification"] == v
    replicate = read_json(checked(trace["preselected_policy"]))
    return {
        "driver": reference(__file__),
        "seed": SEED,
        "count": COUNT,
        "parent_trial": v,
        "candidate": replicate["candidate"]["choice"],
        "caps": replicate["limits"],
        "diagnostic": gap,
        "render": "Station taper is capped by its containing station's value before applying the fixed dose.",
        "confirmation_rule": "Evaluate average and peak absent-direction luma, false projection and peak quiet change using the previous bounds.",
    }


def capture_panel():
    torch.set_num_threads(2)
    root = OUT / "station-confirm"
    (root / "inputs").mkdir(parents=True, exist_ok=True)
    lock_path = OUT / "station-lock.json"
    if not lock_path.exists():
        write_json(lock_path, freeze_lock())
    lock = reference(lock_path)
    plan_path = root / "plan.json"
    if not plan_path.exists():
        capture.last.run.OUT = root
        capture.last.run.SEED = SEED
        capture.last.run.COUNT = COUNT
        capture.last.run.prior.EXCLUSIONS += (
            *(OUT / name / "plan.json" for name in ("calibration", "fresh", "verification")),
            capture.PREVIOUS / "fresh" / "plan.json",
            capture.last.PREVIOUS / "fresh" / "plan.json",
            capture.last.CALIBRATION,
        )
        plan = capture.last.run.freeze()
        for row in plan["sources"]:
            row["target_balance"] = capture.balance(row, plan["sigma"], SEED)
            row["id"] = f"station-fresh-{row['index']:02d}"
        plan |= {
            "driver": reference(__file__),
            "balance_source": reference(capture.__file__),
            "preselected_policy": lock,
            "primary": "Confirm a fixed cap on interpolation with source-disjoint exact targets.",
        }
        write_json(plan_path, plan)
    plan = read_json(plan_path)
    assert plan["preselected_policy"] == lock
    input_path = root / "inputs.json"
    if not input_path.exists():
        capture.last.run.prior.earlier.SEED = SEED
        inputs = []
        for row in plan["sources"]:
            inputs.append(
                capture.last.run.prior.earlier.capture(row, plan["noise"], root / "inputs")
            )
            if len(inputs) % 8 == 0:
                print("Captured station confirmation", len(inputs), flush=True)
        write_json(
            input_path,
            {"driver": reference(__file__), "plan": reference(plan_path), "observations": inputs},
        )
    capture.last.run.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        capture.last.run.prior.parents.main()
    return lock


def main():
    lock = capture_panel()
    candidate = read_json(checked(lock))
    assert review.CONTROLS == candidate["caps"]
    arm, dose = candidate["candidate"]
    _, cut = arm.split("/")
    family = model.METHODS[-1]
    with (
        patch.object(model, "OPTIONS", ((family, float(cut), arm),)),
        patch.object(model, "ARMS", ("near", "unchecked", arm)),
    ):
        baseline, source, plan = review.load("station-confirm")
        with patch.object(model.rank, "field", local_cap):
            clipped, repeated, identical_plan = review.load("station-confirm")
    assert source == repeated and plan == identical_plan
    combined = []
    for normal, local in zip(baseline, clipped, strict=True):
        assert normal["id"] == local["id"]
        draws = []
        for a, b in zip(normal["draws"], local["draws"], strict=True):
            assert a["input"] == b["input"]
            assert a["powers"]["near"] == b["powers"]["near"]
            draws.append(
                a
                | {
                    "powers": a["powers"] | {"station_cap": b["powers"][arm]},
                    "nominal": a["nominal"] | {"station_cap": b["nominal"][arm]},
                }
            )
        combined.append(normal | {"draws": draws})
    choices = {
        "near": ("near", 1),
        "unchecked": ("unchecked", 1),
        "replicated": (arm, dose),
        "station_cap": ("station_cap", dose),
    }
    stats = {k: review.arm_stats(combined, v) for k, v in choices.items()}
    delta = stats["station_cap"]["means"][review.RESPONSE] - stats["near"]["means"][review.RESPONSE]
    unbounded_gain = (
        stats["replicated"]["means"][review.RESPONSE] - stats["near"]["means"][review.RESPONSE]
    )
    scaled = (arm, dose * delta / unbounded_gain)
    assert 0 < scaled[1] <= dose
    caps = {k: bool(review.within(v, stats["near"])) for k, v in stats.items()}
    comparisons = {
        k: review.paired(combined, v, choices["near"]) for k, v in choices.items() if k != "near"
    }
    match = {
        "control": scaled,
        "control_scores": review.arm_stats(combined, scaled),
        "contrast_fixed_effect": review.paired(combined, choices["station_cap"], scaled),
    }
    for k, r in stats.items():
        print(
            k,
            "response",
            r["means"][review.RESPONSE],
            "absent mean and peak",
            r["means"][review.MISSING],
            r["peak"][review.MISSING],
            "quiet",
            r["quiet_added"],
            "passes",
            caps[k],
            flush=True,
        )
    write_json(
        OUT / "station-confirm.json",
        {
            "driver": reference(__file__),
            "preselected_policy": lock,
            "source": source,
            "plan": plan,
            "operator": reference(model.__file__),
            "choices": choices,
            "scores": stats,
            "within_budgets": caps,
            "vs_near": comparisons,
            "matched_recovery": match,
            "rows": combined,
        },
    )


if __name__ == "__main__":
    main()
