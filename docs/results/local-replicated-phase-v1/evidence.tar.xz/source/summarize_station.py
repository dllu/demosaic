"""Plot the matched false-detail curves and collect immutable outcome bindings."""

from collections import Counter
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replay_replicated as review
import replicated_phase as model

OUT = model.OUT


def chart(final, diagnostic):
    colors = {"unbounded": "#716583", "capped": "#007764"}
    figure, axes = plt.subplots(1, 2, figsize=(9.6, 4), layout="constrained")
    x = review.MISSING
    y = review.RESPONSE
    verification = diagnostic["fixed_dose"]
    # The y axis uses each panel's own frozen nearby-phase baseline.
    verification_base = read_json(OUT / "verification.json")["summary"]["scores"]["near"]["means"][
        y
    ]
    target = final["scores"]["near"]["means"][y]
    for axis, title, base, stats, matched in (
        (
            axes[0],
            "24 photos used to diagnose interpolation",
            verification_base,
            (verification["original"], verification["clipped"]),
            diagnostic["equal_recovery"]["original"],
        ),
        (
            axes[1],
            "24 new confirmation photos",
            target,
            (final["scores"]["replicated"], final["scores"]["station_cap"]),
            final["matched_recovery"]["control_scores"],
        ),
    ):
        for key, label, node in zip(
            colors, ("Tangent replication", "Within-station cap"), stats, strict=True
        ):
            values = node["means"]
            xp, yp = values[x], values[y] - base
            axis.plot([0, xp], [0, yp], color=colors[key], lw=2.3, label=label)
            axis.scatter(xp, yp, color=colors[key], s=48, zorder=3)
        here = matched["means"]
        anchor_y = stats[1]["means"][y] - base
        axis.scatter(
            here[x],
            anchor_y,
            facecolor="white",
            edgecolor=colors["unbounded"],
            s=42,
            zorder=3,
            label="Matched recovery",
        )
        axis.hlines(anchor_y, stats[1]["means"][x], here[x], color="#777777", lw=1, ls="--")
        axis.set_title(title, fontsize=11)
        axis.set_xlabel("Added missing-direction luma in gaps (DN16)")
        axis.grid(lw=0.7, alpha=0.30)
        axis.set_ylim(-0.04, 1.64)
    axes[0].set_ylabel("Added second-direction contrast (percentage points)")
    axes[1].legend(loc="lower right", fontsize=8, frameon=False)
    path = OUT / "station-gap-tradeoff.png"
    figure.savefig(path, dpi=155)
    plt.close(figure)
    return reference(path)


def main():
    names = (
        "calibration",
        "fresh",
        "verification",
        "verification-lock",
        "gap-support",
        "station-lock",
        "station-confirm",
        "station-board-camera",
        "station-board-exact",
        "station-audit",
        "natural-replay",
        "api-proof",
    )
    files = {k: reference(OUT / f"{k}.json") for k in names}
    values = {k: read_json(checked(v)) for k, v in files.items()}
    final = values["station-confirm"]
    plan = read_json(checked(final["plan"]))
    ar = final["rows"]
    active = Counter(d["evidence"][0]["state"] for row in ar for d in row["draws"])
    ambiguous_gap = sum(
        d["evidence"][0]["state"] == "ambiguous rank" and review.MISSING in d["nominal"]["near"]
        for row in ar
        for d in row["draws"]
    )
    active_calibration = {}
    for k in ("calibration", "fresh", "verification"):
        s = values[k]["summary"]
        active_calibration[k] = {
            "scores": s["scores"],
            "limits": s["within_budgets"],
            "states": s["states"],
            "ambiguous_exact_gap": s["ambiguous_intact_draws_with_exact_gaps"],
            "vs_near": s["vs_near"],
        }
    sources = {}
    for name, result in (
        ("calibration", values["calibration"]),
        ("confirmation", values["fresh"]),
        ("verification", values["verification"]),
        ("station-confirm", final),
    ):
        binding = result["plan"]
        group = read_json(checked(binding))
        ratio = [a["target_balance"]["resulting_clean_rms_ratio"] for a in group["sources"]]
        sources[name] = {
            "plan": binding,
            "count": len(ratio),
            "clean_RMS_ratio_range": [min(ratio), max(ratio)],
            "families": group["family_counts"],
        }
    output = {
        "driver": reference(Path(__file__)),
        "receipts": files,
        "source_groups": sources,
        "first_three_panels": active_calibration,
        "verification_decision": values["verification-lock"]["candidate"],
        "station_lock": values["station-lock"],
        "gap_support": {
            k: values["gap-support"][k]
            for k in ("energy_depths", "shares_pooled", "fixed_dose", "equal_recovery")
        },
        "station_confirmation": {k: v for k, v in final.items() if k != "rows"},
        "encoded_training_photo_visits_audited": plan["training_photo_visits_audited"],
        "station_active_rank_counts": dict(active),
        "station_ambiguous_exact_gap_draws": ambiguous_gap,
        "standing": {
            r["id"]: r["delta"]["ring_phase"] | {"evidence": r["support"]}
            for r in values["station-board-camera"]["data"]["rows"]
        },
        "exact": [
            {
                k: b[k]
                for k in (
                    "id",
                    "draw",
                    "selected_for",
                    "added_second_response_points",
                    "absent_DN16_capped",
                    "absent_DN16_unbounded",
                )
            }
            for b in values["station-board-exact"]["data"]["boards"]
        ],
        "timings": values["api-proof"]["times_ms_median"],
        "parity": values["api-proof"]["parity"],
        "natural_uncapped": values["natural-replay"]["summary"],
        "chart": chart(final, values["gap-support"]),
    }
    write_json(OUT / "summary.json", output)


if __name__ == "__main__":
    main()
