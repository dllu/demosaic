"""Freeze direction balance using the exact injected wires before drawing noise."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
from scipy.ndimage import gaussian_filter
import torch

from demosaic._mesh_pooled import _measure_nodes, _wave
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-unranked-phase-v1"))
import capture_rank as last

PREVIOUS = OUT.with_name("local-unranked-phase-v1")
SEED = {"calibration": 202611200602, "fresh": 202611200603}


def balance(case, sigma, seed):
    source = last.run.prior.earlier.capture_wide.wire_math
    geometry = case["geometry"]
    photo = source.decode(case["source"], case["box"])
    strength = geometry["strength"][0]
    isolated = [
        source.exact(photo, geometry | {"strength": pair})[0][0][1].numpy()
        for pair in ([0., 0.], [strength, 0.], [0., strength])
    ]
    radius = 96
    powers = []
    guide = _wave(2 * radius, np.asarray(geometry["frequency"]))
    for d, value in enumerate(isolated[1:]):
        signal = gaussian_filter(value - isolated[0], sigma, mode="reflect", truncate=4)
        middle = signal[256-radius:256+radius, 256-radius:256+radius]
        # Pool all four native parity grids so the intended balance is independent of layout.
        by_site = []
        for row, col in np.ndindex(2, 2):
            coefficients, _ = _measure_nodes(middle[row::2, col::2], guide, (row,col), 0, 1)
            by_site.append(float(np.median(np.square(coefficients[:, d]).sum(axis=-1))))
        powers.append(float(np.mean(by_site)))
    target = float(np.random.default_rng(scene_seed(seed, case["index"], "balanced-template-power"))
                   .uniform(.95, 1.05))
    ratio = float(np.clip(target * np.sqrt(powers[0] / max(1e-12, powers[1])), .75, 2.6))
    geometry["strength"][1] = ratio * strength
    return {"power_at_equal_preblur_amplitude": powers, "target_rms_ratio": target,
            "resulting_clean_rms_ratio": float(ratio*np.sqrt(powers[1]/powers[0])),
            "injected_amplitude_ratio": ratio}


def plan_for(group):
    base = reference(PREVIOUS / group / "plan.json")
    if group == "calibration":
        plan = read_json(checked(base))
        plan["sources"] = [row for row in plan["sources"] if row["index"] % 12 < 8]
    else:
        last.run.OUT = OUT / "fresh"
        last.run.SEED = SEED[group]
        last.run.COUNT = 32
        last.run.prior.EXCLUSIONS += (last.CALIBRATION, Path(base["path"]), last.PREVIOUS / "fresh" / "plan.json")
        plan = last.run.freeze()
    for case in plan["sources"]:
        case["geometry"].pop("unscaled_second_to_first", None)
        case["target_balance"] = balance(case, plan["sigma"], SEED[group])
        case["id"] = f"replicated-{group}-{case['index']:02d}"
    assert len(plan["sources"]) == 32
    return plan | {"driver": reference(__file__), "source_count": 32, "seed": SEED[group],
                   "earlier_experiment": base, "family_counts": {name: 8 for name in last.run.prior.earlier.FAMILIES},
                   "primary": "Match the planted post-optics median direction amplitude before any Bayer noise. Calibrate local checks on both exact gaps and flat controls.",
                   "hypothesis": "A replicate phase check rejects isolated false matches without rejecting coherent second-direction detail."}


def main(group):
    torch.set_num_threads(2)
    last.run.prior.earlier.SEED = SEED[group]
    start = monotonic()
    dest = OUT / group
    (dest / "inputs").mkdir(exist_ok=True, parents=True)
    plan_path = dest / "plan.json"
    if not plan_path.exists():
        write_json(plan_path, plan_for(group))
    plan = read_json(plan_path)
    assert plan["driver"] == reference(__file__)
    inputs_path = dest / "inputs.json"
    if not inputs_path.exists():
        observations = []
        for case in plan["sources"]:
            observations.append(last.run.prior.earlier.capture(case, plan["noise"], dest / "inputs"))
            if len(observations) % 8 == 0:
                print("Captured", group, len(observations), flush=True)
        write_json(inputs_path, {"driver": reference(__file__), "plan": reference(plan_path),
                                 "observations": observations, "seconds": monotonic() - start})
    last.run.prior.parents.OUT = dest
    if not (dest / "parent" / "result.json").exists():
        last.run.prior.parents.main()


if __name__ == "__main__":
    main(sys.argv[1])
