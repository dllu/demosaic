"""Render the held-dose methods at identical native Bayer crop coordinates."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replicated_phase as model
from replay_replicated import RESPONSE, MISSING
import review_near as previous

view = previous.view
LABELS = {
    "parent": "Local 50k",
    "nested": "Nearby phase",
    "old": "Single-station collar",
    "ring_phase": "Two-green check",
    "adjacent": "Tangent replication",
}


def select(values, choice):
    arm, dose = choice
    near = values["near"]
    return (near.astype(np.float64) + dose * (values[arm].astype(np.float64) - near)).astype(
        near.dtype
    )


def arms(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    clearance = 16 if local == roi else 48
    values, _, trace = model.qualify(
        parent, local, scene, colors, roi, peaks, noise, wb, matrix, clearance=clearance
    )
    return {
        "parent": view.section(parent, *local),
        "nested": values["near"],
        "old": values["center/1.5"],
        "ring_phase": select(values, policy["primary"]["choice"]),
        "adjacent": select(values, policy["per_family"]["both_and_neighbor"]["choice"]),
    }, trace


def exact(policy, dest):
    source = reference(model.OUT / "fresh.json")
    data = read_json(checked(source))
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    arm, dose = policy["primary"]["choice"]
    selection = {}
    for row in data["rows"]:
        for draw in row["draws"]:
            if draw["evidence"][0]["state"] != "ambiguous rank":
                continue
            proposed = model.replay.metrics_at(draw["powers"][arm], dose)
            prior = draw["nominal"]["near"]
            score = proposed[RESPONSE] - prior[RESPONSE]
            if MISSING in proposed:
                key, weight = "worst_absent_direction", proposed[MISSING]
            else:
                key, weight = "largest_continuous_gain", score
            if key not in selection or weight > selection[key][0]:
                selection[key] = (weight, row, draw, score, proposed.get(MISSING))
    assert len(selection) == 2
    results = []
    for label, (_, row, draw, score, missing) in selection.items():
        f = model.replay.arrays(draw["input"])
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")} | {"packed": f["packed"][:1]}
        parent, v120 = (
            np.load(checked(draw["outputs"][k]), allow_pickle=False)[0]
            for k in ("local50k", "v120")
        )
        scene = f["scene_packed"].copy()
        scene[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2] = f["packed"][0]
        frequency = np.asarray(draw["actual_frequency"])
        options, trace = arms(
            parent, local, scene, colors, roi, frequency, plan["noise"], wb, matrix, policy
        )
        frames = [noisy_malvar(camera)[0], v120]
        for value in options.values():
            full = parent.copy()
            view.section(full, *local)[:] = value
            frames.append(full)
        frames.append(f["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(LABELS[k] for k in options), "Exact GT"]
        results.append(
            view.native_board(
                dest,
                row["id"],
                frames,
                camera,
                {
                    "selection": label,
                    "input": draw["input"],
                    "fixture": row["fixture"],
                    "query": plan["query"],
                    "noise": plan["noise"],
                    "optical_sigma": plan["sigma"],
                    "draw": draw["draw"],
                    "weights": plan["checkpoints"],
                    "policy": policy["primary"]["choice"],
                    "nomination": frequency.tolist(),
                    "gain_points": score,
                    "absent_added_DN16": missing,
                    "trace": trace,
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS["ring_phase"]), len(labels) - 1),
            )
        )
    return {"source": source, "boards": results}


def main(mode):
    torch.set_num_threads(2)
    source = reference(model.OUT / "calibration.json")
    policy = read_json(checked(source))["policy"]
    dest = model.OUT / "boards" / mode
    dest.mkdir(exist_ok=True, parents=True)
    if mode == "camera":
        view.arcs = arms
        view.NAMES = LABELS
        result = view.standing(policy, dest)
    else:
        result = exact(policy, dest)
    write_json(
        model.OUT / f"board-{mode}.json",
        {"driver": reference(Path(__file__)), "calibration": source, "data": result},
    )


if __name__ == "__main__":
    main(sys.argv[1])
