"""Measure the locked tangent check on ordinary photos under two contexts."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import replicated_phase as model
from review_replicated import select

ROI = (176, 176, 160, 160)
LOCAL = (48, 48, 160, 160)
QUERY = np.s_[..., 64:192, 64:192]
RGB = np.s_[..., 48:208, 48:208]


def main():
    lock = reference(model.OUT / "verification-lock.json")
    policy = read_json(checked(lock))["candidate"]["choice"]
    natural = reference(model.OUT.parent / "local-weak-contrast-v1/natural-controls.json")
    alternate = reference(model.OUT.parent / "local-near-phase-v1/contexts-calibration.json")
    plants = read_json(checked(alternate))
    noise = read_json(checked(plants["plan"]))["noise"]
    records = []
    for first, second in zip(read_json(checked(natural))["rows"], plants["records"], strict=True):
        assert first["id"] == second["id"]
        input_ = model.replay.arrays(first["input"])
        swapped = second["streams"][0]["far_phase"]
        mismatch = np.load(checked(swapped), allow_pickle=False)
        mismatch[QUERY] = input_["scene_packed"][QUERY]
        np.testing.assert_array_equal(mismatch[QUERY], input_["packed"][0])
        cams = tuple(input_[k] for k in ("colors", "wb", "matrix"))
        target = input_["target"][RGB].astype(np.float64)
        base = input_["parent"][RGB].astype(np.float64)
        outcomes = {}
        for name, raw in (("authentic", input_["scene_packed"]), ("mismatch", mismatch)):
            frequencies = _spacing(raw, cams[0], *ROI[:2], clearance=48)
            values, _, trace = model.qualify(
                input_["parent"], LOCAL, raw, cams[0], ROI, frequencies, noise, *cams[1:]
            )
            paths = {
                "near": values["near"],
                "old": values["center/1.5"],
                "replicated": select(values, policy),
            }

            def diff(a, b):
                return float(np.sqrt(np.mean((a.astype(np.float64) - b) ** 2)) * 65535)

            scores = {
                label: {
                    "added_from_near_DN16": diff(image, values["near"]),
                    "added_from_parent_DN16": diff(image, base),
                    "target_luma_RMS_DN16": diff(
                        model.replay.luma((image - target)[None], *cams[1:]), 0
                    ),
                }
                for label, image in paths.items()
            }
            outcomes[name] = {"state": trace["state"], "scores": scores}
        records.append(
            {"id": first["id"], "input": first["input"], "donors": swapped, "contexts": outcomes}
        )
    summary = {}
    for context in ("authentic", "mismatch"):
        columns = [r["contexts"][context] for r in records]
        summary[context] = {
            "ambiguous": sum(r["state"] == "ambiguous rank" for r in columns),
            "methods": {
                method: {
                    "means": {
                        key: mean(r["scores"][method][key] for r in columns)
                        for key in columns[0]["scores"][method]
                    },
                    "changed": sum(
                        r["scores"][method]["added_from_near_DN16"] > 0 for r in columns
                    ),
                }
                for method in columns[0]["scores"]
            },
        }
    write_json(
        model.OUT / "natural-replay.json",
        {
            "driver": reference(Path(__file__)),
            "preselected_policy": lock,
            "natural": natural,
            "altered_donors": alternate,
            "rows": records,
            "summary": summary,
        },
    )


if __name__ == "__main__":
    main()
