"""Bind all four photo panels, native comparisons and the packaged code."""

from hashlib import file_digest
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import replicated_phase as model

ROOT = Path.cwd()
OUT = model.OUT
ASSETS = ROOT / "docs/assets" / model.HERE.name
RESULTS = ROOT / "docs/results" / model.HERE.name
GROUPS = ("calibration", "fresh", "verification", "station-confirm")
FILES = (
    "calibration.json",
    "fresh.json",
    "verification-lock.json",
    "verification.json",
    "gap-support.json",
    "station-lock.json",
    "station-confirm.json",
    "board-camera.json",
    "board-exact.json",
    "station-board-camera.json",
    "station-board-exact.json",
    "station-audit.json",
    "natural-replay.json",
    "api-proof.json",
    "summary.json",
    *(
        f"{name}/{part}"
        for name in GROUPS
        for part in ("plan.json", "inputs.json", "parent/result.json")
    ),
)
REUSE = (
    "local-nested-support-v1/freeze_nested.py",
    "local-nested-support-v1/replay_nested_parents.py",
    "local-weak-contrast-v1/capture_contrast.py",
    "local-weak-support-v1/replay_exterior_support.py",
    "local-unranked-phase-v1/unranked_phase.py",
    "local-bayer-presence-v1/review_presence.py",
    "scene-patch-width-v1/evaluate_wide.py",
    "green-covariance-refit-v1/wire_math.py",
)
EARLY = {
    name: reference(OUT / "frozen" / name)
    for name in ("capture_balanced-preformat.py", "review_replicated-camera.py")
}


def local(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def verify_source(binding):
    for earlier in EARLY.values():
        if earlier["sha256"] == binding["sha256"]:
            return checked(earlier)
    return checked(binding)


def copy_image(binding):
    source = checked(binding)
    dest = ASSETS / source.name
    shutil.copyfile(source, dest)
    result = local(dest)
    assert result["sha256"] == binding["sha256"]
    return result


def board(value):
    copied = copy_image(value["image"])
    with Image.open(ROOT / copied["path"]) as img:
        for panel in value["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= img.width and 0 <= y < y + h <= img.height
    return value | {"image": copied}


def main():
    refs = {name: reference(OUT / name) for name in FILES}
    data = {name: read_json(checked(value)) for name, value in refs.items()}
    for item in data.values():
        for key in ("driver", "operator", "balance_source"):
            if key in item:
                verify_source(item[key])
    assert data["fresh.json"]["calibration"] == refs["calibration.json"]
    assert data["verification-lock.json"]["confirmation"] == refs["fresh.json"]
    assert data["verification.json"]["preselected_policy"] == refs["verification-lock.json"]
    assert data["gap-support.json"]["verification"] == refs["verification.json"]
    assert data["station-lock.json"]["diagnostic"] == refs["gap-support.json"]
    assert data["station-confirm.json"]["preselected_policy"] == refs["station-lock.json"]
    assert data["station-confirm.json"]["within_budgets"]["station_cap"]
    for value in ("station-board-camera", "station-board-exact", "api-proof"):
        assert data[f"{value}.json"]["source"] == refs["station-confirm.json"]
    proof = data["api-proof.json"]
    assert proof["parity"] == {"maximum_new_DN16": 0.0, "maximum_baseline_DN16": 0.0}
    assert proof["counts"]["synthetic"] == 288 and proof["counts"]["real"] == 8
    assert all(
        data["summary.json"]["receipts"][key[:-5]] == refs[key]
        for key in refs
        if key[:-5] in data["summary.json"]["receipts"]
    )
    all_sources = set()
    for group in GROUPS:
        parent = data[f"{group}/parent/result.json"]
        inputs = data[f"{group}/inputs.json"]
        plan = data[f"{group}/plan.json"]
        assert parent["inputs"] == refs[f"{group}/inputs.json"]
        assert inputs["plan"] == refs[f"{group}/plan.json"]
        assert data[f"{group}.json"]["plan"] == refs[f"{group}/plan.json"]
        assert data[f"{group}.json"]["source"] == refs[f"{group}/parent/result.json"]
        keys = {r["source"][k] for r in plan["sources"] for k in ("id", "cache_sha256")}
        assert keys.isdisjoint(all_sources)
        all_sources.update(keys)
        assert len(plan["sources"]) == (32 if group in ("fresh", "calibration") else 24)
        for checkpoint in parent["weights"].values():
            checked(checkpoint)
        for first, second in zip(inputs["observations"], parent["records"], strict=True):
            assert first["id"] == second["id"]
            for raw, result in zip(first["streams"], second["streams"], strict=True):
                assert raw["data"] == result["data"] and raw["draw"] == result["draw"]
                checked(raw["data"])
                for binding in result["outputs"].values():
                    checked(binding)

    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    members = {f"receipts/{key}": binding for key, binding in refs.items()}
    members.update({f"source/{p.name}": reference(p) for p in sorted(model.HERE.glob("*.py"))})
    members.update({f"source/previous/{key}": binding for key, binding in EARLY.items()})
    members.update({f"reused/{name}": reference(model.HERE.parent / name) for name in REUSE})
    members.update(proof["production_files"])
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for name, binding in members.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == members.keys()
        for name, binding in members.items():
            with tar.extractfile(name) as read:
                assert file_digest(read, "sha256").hexdigest() == binding["sha256"]

    camera = [
        r | {"native": [board(x) for x in r["native"]]}
        for r in data["station-board-camera.json"]["data"]["rows"]
    ]
    exact = [
        r | {"board": board(r["board"]), "triplet": board(r["triplet"])}
        for r in data["station-board-exact.json"]["data"]["boards"]
    ]
    assert sum(len(r["native"]) for r in camera) == 12 and len(exact) == 2
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {"camera": camera, "exact": exact, "chart": copy_image(data["summary.json"]["chart"])},
    )
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(refs["summary.json"]), summary)
    write_json(
        RESULTS / "publication.json",
        {
            "parent_revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip(),
            "manifest": local(manifest),
            "summary": local(summary),
            "archive": local(archive),
            "receipt_bindings": refs,
            "archive_members": members,
            "prior_publication": local(
                ROOT / "docs/results/local-unranked-phase-v1/publication.json"
            ),
            "packaged_mode": "weak-replicated-phase",
            "new_weights": None,
            "standing_native_boards_viewed": 12,
            "native_triplets_viewed": 2,
        },
    )


if __name__ == "__main__":
    main()
