"""Render native diagnostics for both accepted ISO400 far geometries."""

from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
source = root / "output/collection.json"
done = read_json(source)
plan = read_json(checked(done["plan"]))
s = next(
    x
    for x in plan["settings"]
    if (x["profile"], x["placement"], x["budget_DN16"]) == ("iso400", "far", 0.02)
)
rows = []
for item in done["synthetic"]:
    case = read_json(checked(item["case"]))
    fit = done["donors"][item["guide_key"]]["fit"]
    if (case["profile"], case["placement"]) != ("iso400", "far") or not any(fit["accepted"]):
        continue
    parent = np.load(checked(case["parent"]))[2][ROI].astype(np.float64)
    with np.load(checked(case["target"])) as data:
        target = data["target"][2][ROI]
    with np.load(checked(case["sensor"])) as data:
        ctx = {k: data[k][2:3] for k in ("colors", "wb", "matrix")}
        ctx["packed"] = data["packed"][2:3, :, 64:192, 64:192]
    with np.load(checked(item["prediction"])) as data:
        results = [
            parent + s["scale"] * (data[f"{arm}--t{s['threshold']:g}"][2] - parent)
            for arm in plan["arms"]
        ]
    rows.append(
        native_board(
            root / "review",
            case["id"] + "-accepted",
            [noisy_malvar(ctx)[0], parent, *results, target],
            ctx,
            {
                "case_receipt": item["case"],
                "operating_point": s,
                "selected_on": "Any donor direction accepted",
                "curvature_directions": fit["accepted"],
            },
            labels=(
                "Noisy Malvar",
                "V143 EMA",
                "Guarded guide",
                "Fixed planar",
                "Donor curvature",
                "Exact GT",
            ),
            triplet_indices=(0, 4, 5),
            contrast=5,
        )
    )
assert len(rows) == 2
write_json(
    root / "review/accepted-views.json",
    {"source": reference(__file__), "collection": reference(source), "boards": rows},
)
