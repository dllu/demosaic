"""Independently reproduce delivery metrics and evaluate measured phase geometry."""

from collections import defaultdict
from itertools import permutations
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ROI = np.s_[..., 128:384, 128:384]


def direct(parent, truth, quiet, cropped, alpha):
    out = parent.copy()
    out[ROI] += (cropped.astype(np.float64) - parent[ROI]) * alpha
    error = out - truth
    weak, strong = truth[2] - truth[1], truth[1] - truth[0]
    return (
        np.mean((error[ROI][..., quiet] * 65535) ** 2),
        np.mean((error[ROI] * 65535) ** 2),
        np.mean(((error[2] - error[1]) * 65535) ** 2),
        np.vdot(out[2] - out[1], weak) / np.vdot(weak, weak),
        np.vdot(out[1] - out[0], strong) / np.vdot(strong, strong),
        np.vdot(error[1], weak) / np.vdot(weak, weak),
    )


def expected_phase(donor):
    r = donor["metadata"]["recipe"]
    directions = np.stack((np.cos(r["wire_angles"]), np.sin(r["wire_angles"])), axis=1)
    perpendicular = np.stack((-directions[:, 1], directions[:, 0]), axis=1)
    q, t = np.asarray(r["phase_drifts"]).T
    H = (
        q[:, None, None] * directions[:, :, None] * directions[:, None, :]
        + t[:, None, None] * perpendicular[:, :, None] * perpendicular[:, None, :]
    ) / 256**2
    return directions / np.asarray(r["periods"])[:, None], H


def geo_audit(donor):
    f, H = expected_phase(donor)
    pred = np.asarray(donor["fit"]["frequencies_xy"])
    hessians = np.asarray(donor["fit"]["hessians_xy"])
    distances = np.minimum(
        np.linalg.norm(pred[:, None] - f, axis=2), np.linalg.norm(pred[:, None] + f, axis=2)
    )
    order = min(permutations((0, 1)), key=lambda p: sum(distances[i, j] for i, j in enumerate(p)))
    y, x = np.indices((256, 256), dtype=np.float64) - 127.5
    xy = np.stack((x, y), -1)
    out = []
    for i, j in enumerate(order):
        sign = np.sign(pred[i] @ f[j])
        phase_error = xy @ (pred[i] - f[j] * sign)
        h_diff = hessians[i] - H[j] * sign
        deform = 0.5 * ((xy @ h_diff) * xy).sum(-1)
        planar = phase_error - 0.5 * ((xy @ (H[j] * sign)) * xy).sum(-1)
        out.append(
            {
                "direction": j,
                "accepted": donor["fit"]["accepted"][i],
                "center_error_in_native_bins": float(distances[i, j] * 256),
                "hessian_error_scaled_Frobenius": float(np.linalg.norm(h_diff) * 256**2),
                "planar_phase_error_cycles": float(np.std(planar)),
                "transport_phase_error_cycles": float(np.std(phase_error + deform)),
            }
        )
    return out


def independent():
    result_path = ROOT / "review/result.json"
    result = read_json(result_path)
    plan = read_json(checked(result["plan"]))
    done = read_json(checked(result["collection"]))
    source = read_json(checked(plan["previous_collection"]))
    assert len(done["synthetic"]) == len(source["synthetic"]) == 32
    assert done["new_neural_calls"] == 0
    metrics = (
        "quiet_RMS_DN16",
        "query_RMS_DN16",
        "weak_increment_RMS_DN16",
        "weak_gain",
        "strong_gain",
        "weak_absent_projection",
    )
    acc = defaultdict(list)
    old_baselines = 0
    for produced, old in zip(done["synthetic"], source["synthetic"], strict=True):
        assert produced["case"] == old
        c = read_json(checked(produced["case"]))
        donor = done["donors"][produced["guide_key"]]
        assert not set(c["metadata"]["identities"]).intersection(donor["metadata"]["identities"])
        p = np.load(checked(c["parent"])).astype(np.float64)
        with np.load(checked(c["target"])) as f:
            t = f["target"].astype(np.float64)
            q = f["quiet"][ROI]
        with np.load(checked(produced["prediction"])) as f, np.load(checked(c["prediction"])) as g:
            for key in f.files:
                if key.startswith("guarded"):
                    np.testing.assert_array_equal(f[key], g[key.replace("guarded", "planar")])
                    old_baselines += 1
            for j, a in enumerate(result["aggregates"]):
                s = a["setting"]
                if (c["profile"], c["placement"]) != (s["profile"], s["placement"]) or a[
                    "kind"
                ] not in ("all", c["kind"]):
                    continue
                for arm in plan["arms"]:
                    pix = f[f"{arm}--t{s['threshold']:g}"]
                    for mode, scale in (
                        ("fixed", s["scale"]),
                        ("matched", a["matched"][arm]["scale"]),
                    ):
                        acc[j, arm, mode].append(direct(p, t, q, pix, scale))
    for (j, arm, mode), rows in acc.items():
        mean = np.mean(rows, 0)
        mean[:3] **= 0.5
        scores = result["aggregates"][j][mode][arm]
        np.testing.assert_allclose(mean, [scores[m] for m in metrics], rtol=1e-10, atol=1e-10)
    for r in result["boards"]:
        with (
            Image.open(checked(r["board"]["image"])) as a,
            Image.open(checked(r["triplet"]["image"])) as b,
        ):
            for ia, ib in zip((0, 4, 5), (0, 1, 2), strict=True):
                xa, xb = 8 + 168 * ia, 8 + 168 * ib
                np.testing.assert_array_equal(
                    a.crop((xa, 24, xa + 160, 184)), b.crop((xb, 24, xb + 160, 184))
                )
    cameras = []
    for board in result["camera"]:
        roi_x, roi_y, w, h = board["ROI_xywh"]
        query_x, query_y, _, _ = board["source"]["query_box"]
        x, y = roi_x - query_x, roi_y - query_y
        roi = np.s_[:, y : y + h, x : x + w]
        with (
            np.load(checked(board["drift_prediction"])) as a,
            np.load(checked(board["crosscheck_prediction"])) as b,
        ):
            delta = a["corrected"][roi].astype(np.float64) - b["corrected"][roi]
        dn16 = float(np.sqrt(np.mean(delta**2)) * 65535)
        assert np.isclose(dn16, board["change_DN16"], rtol=0, atol=1e-13)
        cameras.append(
            {
                "id": board["id"],
                "rms_DN16": dn16,
                "exact_match": not np.any(delta),
                "fit_status": board["drift_fit"]["status"],
                "accepted": board["drift_fit"]["accepted"],
            }
        )
    write_json(
        ROOT / "review/independent-audit.json",
        {
            "producer": reference(__file__),
            "report": reference(result_path),
            "original_guarded_outputs_replayed": old_baselines,
            "recomputed_metrics": len(acc) * len(metrics),
            "donors": {k: geo_audit(d) for k, d in done["donors"].items()},
            "camera": cameras,
            "verified_triplet_cells": 6,
        },
    )


if __name__ == "__main__":
    independent()
