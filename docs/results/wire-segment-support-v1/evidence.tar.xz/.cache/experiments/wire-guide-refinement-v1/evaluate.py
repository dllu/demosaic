"""Apply exterior frequency confirmation upstream of the frozen RAW verifier."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.heldout_wire_frequency import refine_wire_frequencies

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("wire-blind-spot-v1")
sys.path.insert(0, str(PREVIOUS))
from diagnose import OFFSETS, neighbors, solve_predictor, templates
from verifier import affine_contrast, fitted_exterior, measure, normalize, select_shrinkage
from estimated_phase import exterior_design, fit_profile

FRESH = Path("/mnt/external/demosaic/wire-guide-refinement-v1/fresh/panel.json")
METHODS = ("fixed", "affine", "innovation")


def inspect(data, case, profile, guide, method):
    raw = data["packed"].transpose(0, 2, 3, 1).astype(float)
    shape_hw = (raw.shape[1] * 2, raw.shape[2] * 2)
    parameters = {
        k: case["geometry"][k] for k in ("angles", "periods", "gap_center", "gap_axes", "gap_angle")
    }
    skeleton = parameters | {"phases": (0.0, 0.0), "widths": (0.1, 0.1)}
    trend, _, radius = templates(skeleton, shape_hw)

    wb, matrix, colors = (data[k] for k in ("wb", "matrix", "colors"))
    neutral = (np.linalg.solve(matrix.astype(float), np.ones(3)) / wb)[colors]
    ys, xs = np.indices(raw.shape[1:3])
    parity = (ys + xs) % 2
    safe = (ys >= 3) & (ys < raw.shape[1] - 3) & (xs >= 3) & (xs < raw.shape[2] - 3)
    outside = (radius.min(2) > 1.4) & safe
    safe_stencil = neighbors(outside[..., None]).all(2)
    inner = radius < 1
    ring = outside & (radius.min(2) > 1.45) & (radius.max(2) < 3.1)
    far = outside & safe_stencil & (radius.min(2) > 1.55) & (radius.max(2) < 3.2)
    selector = (ys // 5 + 2 * (xs // 5)) % 4 == 0
    naive = np.zeros((4 * len(OFFSETS), 4))
    for n, (dy, dx) in enumerate(OFFSETS):
        if abs(dy) + abs(dx) == 1:
            naive[4 * n : 4 * (n + 1)] = np.eye(4) / 4
    clean = (
        mosaic(torch.from_numpy(data["target"]), torch.from_numpy(colors))
        .numpy()
        .transpose(0, 2, 3, 1)
        .astype(float)
    )
    true_scale = case["geometry"]["strengths"][0] * profile["exposure"]
    results = []
    for role, y in enumerate(raw):
        folds = []
        for fold in (0, 1):
            outer = ring & (parity != fold)
            noise = np.sqrt(
                profile["shot"] * np.median(y[outer], axis=0).clip(min=0) + profile["read"]
            )
            refinement = {"chosen": guide.tolist(), "accepted": False}
            if method != "fixed":
                refinement = refine_wire_frequencies(
                    y,
                    radius,
                    guide,
                    neutral,
                    shot=profile["shot"],
                    read=profile["read"],
                    discovery_parity=1 - fold,
                    innovation=method == "innovation",
                )
            vectors = np.asarray(refinement["chosen"])
            hypothesis = parameters | {
                "angles": np.arctan2(vectors[:, 1], vectors[:, 0]).tolist(),
                "periods": (1 / np.linalg.norm(vectors, axis=1)).tolist(),
            }
            sinusoidal = exterior_design(shape_hw, hypothesis)
            fitted = fit_profile(y, sinusoidal, trend[..., :3], outer, noise, neutral)
            fitted |= {k: hypothesis[k] for k in ("angles", "periods")}
            design, wave, _ = templates(hypothesis | fitted, shape_hw)
            shape = wave * neutral
            predicted, outer_scale, z = fitted_exterior(y, design, outer, noise, neutral)
            standardized = y / noise
            carrier = shape / noise
            resid = (y - predicted) / noise
            X = neighbors(resid)
            Xphi = neighbors(carrier)
            site = np.nonzero(inner & (parity[..., None] == fold) & safe[..., None])
            c_affine, _ = affine_contrast(design, carrier, site)
            c_exterior, _ = normalize(carrier[site])
            curve = standardized[site] @ c_affine
            residual = resid - X @ naive
            c_neighbor, _ = normalize((carrier - Xphi @ naive)[site])
            nearest = residual[site] @ c_neighbor
            witness = far & (parity == fold)
            train, valid = witness & ~selector, witness & selector
            assert min(train.sum(), valid.sum()) >= 25
            trained, learning = solve_predictor(X, resid, train, valid)
            c_trained, _ = normalize((carrier - Xphi @ trained)[site])
            blend = select_shrinkage(
                standardized, residual, site, outside, safe_stencil, c_affine, c_neighbor
            )
            alpha = blend["blend"]
            value = {
                "inner_affine": curve,
                "exterior_affine": resid[site] @ c_exterior,
                "neighbor": nearest,
                "exterior_learned": (resid - X @ trained)[site] @ c_trained,
                "fixed_midpoint": 0.5 * curve + 0.5 * nearest,
                "placebo_shrinkage": (1 - alpha) * curve + alpha * nearest,
                "exact_background": ((y - clean[1 if role < 2 else 2]) / noise)[site] @ c_exterior,
            }
            folds.append(
                dict(
                    amplitude={name: float(v) for name, v in value.items()},
                    outside_amplitude=outer_scale,
                    outside_z=z,
                    blend=blend,
                    learned=learning,
                    waveform=fitted,
                    refinement=refinement,
                    scored_pixels=len(site[0]),
                    prediction_fingerprint=fingerprint(
                        np.r_[predicted[site], (X @ naive)[site], (X @ trained)[site], alpha]
                    ),
                    influence_fingerprint=fingerprint(
                        np.r_[c_affine, c_exterior, c_neighbor, c_trained]
                    ),
                )
            )
        results.append(folds)
    return {"true_amplitude": true_scale, "roles": results}


def vectors(case):
    angles = np.asarray(case["geometry"]["angles"])
    periods = np.asarray(case["geometry"]["periods"])
    return np.stack((np.cos(angles), np.sin(angles)), axis=1) / periods[:, None]


def guide_for(case, guide):
    exact = vectors(case)
    if guide == "rounded":
        return np.rint(256 * exact) / 256
    if guide == "radial":
        direction = exact / np.linalg.norm(exact, axis=1, keepdims=True)
        sign = 1 if case["index"] % 2 == 0 else -1
        return exact + sign * np.array([[1], [-1]]) * direction * 0.5 / 256
    return exact


def sampling_summary(values):
    stats = {}
    for method in METHODS:
        fields = []
        for row in values:
            g = np.asarray(row["truth"])
            for result in row["methods"][method]:
                for role_index, role in enumerate(result["roles"]):
                    for fold in role:
                        candidate = np.asarray(fold["refinement"]["chosen"])
                        e = 256 * np.linalg.norm(g - candidate, axis=1)
                        fields.append(
                            (role_index, float(e[0]), float(e[1]), fold["refinement"]["accepted"])
                        )
        p = np.asarray(fields)
        stats[method] = {
            "continuing_median_bin_error": np.median(p[p[:, 0] == 0, 1:3], axis=0).tolist(),
            "double_gap_median_bin_error": np.median(p[p[:, 0] == 1, 1:3], axis=0).tolist(),
            "continuing_move_fraction": float(p[p[:, 0] == 0, 3].mean()),
        }
    return stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("guide", choices=("exact", "rounded", "radial"))
    parser.add_argument("--panel", type=Path, default=FRESH)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    source = reference(args.panel)
    panel = read_json(checked(source))
    started = time.monotonic()
    rows = []
    for row in panel["rows"]:
        guide = guide_for(row, args.guide)
        views = {method: [] for method in METHODS}
        profile = row.get("profile", panel.get("profile"))
        for draw in row["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                data = {k: f[k] for k in f.files}
            assert fingerprint(data["packed"]) == draw["packed"]
            assert fingerprint(data["target"]) == row["clean"]
            for method in METHODS:
                views[method].append(inspect(data, row, profile, guide, method))
        rows.append(
            {
                "source": row["source"]["id"],
                "index": row["index"],
                "ISO": profile.get("iso", "ISO6400"),
                "CFA": row["CFA"],
                "truth": vectors(row).tolist(),
                "provided": guide.tolist(),
                "methods": views,
            }
        )
        if (row["index"] + 1) % 8 == 0:
            print(row["index"] + 1, round(time.monotonic() - started, 2), flush=True)
    results = {}
    for iso in sorted({r["ISO"] for r in rows}):
        v = [r for r in rows if r["ISO"] == iso]
        results[iso] = {
            "decisions": {m: measure([{"draws": r["methods"][m]} for r in v]) for m in METHODS},
            "frequency": sampling_summary(v),
        }
    write_json(
        args.output,
        {
            "guide": args.guide,
            "panel": source,
            "driver": reference(__file__),
            "kernel": reference(Path.cwd() / "src/demosaic/heldout_wire_frequency.py"),
            "results": results,
            "rows": rows,
            "seconds": time.monotonic() - started,
            "scope": "Matched exterior-only proposal and confirmation. True wavevectors enter the declared "
            "experimental guide and the separate frequency-error audit. The inner RAW is withheld from "
            "both proposal and confirmation. Phase and width are re-estimated after each decision.",
        },
    )
    for iso, data in results.items():
        print(
            iso,
            data["frequency"],
            {
                m: d["placebo_shrinkage"]["counts_exterior"]["0.5"]
                for m, d in data["decisions"].items()
            },
            flush=True,
        )


if __name__ == "__main__":
    main()
