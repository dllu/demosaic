"""Score identical fresh RAW arrays with the aligned-control and V120 EMAs."""

from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_identity
from demosaic.inference import _stage_tiled_cuda
from demosaic.models import load_model
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

EXPERIMENTS = Path(".cache/experiments").absolute()
ROOT = Path("/mnt/external/demosaic/wire-segment-support-v1")


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    q = ROOT / "parents"
    q.mkdir()
    write_json(q / "owner.json", owner_identity())
    fresh = reference(ROOT / "fresh/panel.json")
    src = read_json(checked(fresh))
    parent_trial = reference(EXPERIMENTS / "local-continuing-wire-v1/training/completed.json")
    preferred = reference("configs/current-model.json")
    parent = read_json(checked(parent_trial))["checkpoints"]["wire-aligned"]
    v120 = read_json(checked(preferred))["checkpoint"]
    model, state = load_scene_checkpoint(
        checked(parent), weights="ema", expected_sha256=parent["sha256"]
    )
    scene = reference(EXPERIMENTS / "scene-full-epoch-v1/plan.json")
    foundation = read_json(checked(scene))["parent"]
    assert state["base_parent"] == foundation and state["mode"] == "none"
    assert foundation["sha256"] != v120["sha256"]
    del state
    primary, _ = load_model("v120", checkpoint=checked(v120), expected_sha256=v120["sha256"])
    models = {
        name: _stage_tiled_cuda(net, "cuda")
        for name, net in (("aligned", model), ("v120", primary))
    }
    began = time.monotonic()
    cases = []
    with ieee_fp32():
        for row in src["rows"]:
            noise = row["profile"]
            model.base.set_noise(noise["shot"], noise["read"])
            primary.set_noise(noise["shot"], noise["read"])
            observations = []
            for number, draw in enumerate(row["draws"]):
                with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                    data = {k: f[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
                assert fingerprint(data["packed"]) == draw["packed"]
                count = len(data["packed"])
                b = [
                    torch.from_numpy(data[key]).cuda().contiguous(memory_format=torch.channels_last)
                    for key in ("packed", "variance")
                ]
                b.extend(
                    torch.from_numpy(data[key]).cuda()[None].expand(count, *data[key].shape)
                    for key in ("colors", "wb", "matrix")
                )
                result = {label: net(*b).cpu().numpy() for label, net in models.items()}
                assert all(
                    val.shape == (count, 3, 256, 256)
                    and val.dtype == np.float32
                    and np.isfinite(val).all()
                    for val in result.values()
                )
                p = q / f"{row['index']:02d}-{number}.npz"
                with p.open("xb") as stream:
                    np.savez(stream, **result)
                observations.append({"input": draw["arrays"], "outputs": reference(p)})
            cases.append({"source": row["source"]["id"], "draws": observations})
            if (row["index"] + 1) % 8 == 0:
                print(row["index"] + 1, round(time.monotonic() - began, 2), flush=True)
    write_json(
        q / "completed.json",
        {
            "panel": fresh,
            "prior": parent_trial,
            "scene": scene,
            "base_corpus_100k": foundation,
            "preferred": preferred,
            "driver": reference(__file__),
            "checkpoints": {"aligned": parent, "v120": v120},
            "cases": cases,
            "seconds": time.monotonic() - began,
            "policy": "EMA. Torch CUDA IEEE FP32 native 256px crops; nominal sensor shot/read.",
        },
    )


if __name__ == "__main__":
    main()
