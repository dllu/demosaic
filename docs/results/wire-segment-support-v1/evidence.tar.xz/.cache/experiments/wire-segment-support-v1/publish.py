"""Publish the segment support experiments and native board bindings."""

from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
EXTERNAL = Path("/mnt/external/demosaic") / ROOT.name
IMAGES = REPO / "docs/images" / ROOT.name
OUT = REPO / "docs/results" / ROOT.name
RECEIPTS = {
    "evaluation": "evaluation/result.json",
    "camera": "standing-bound/result.json",
    "checked_original_camera": "standing/result.json",
    "curves": "curve.json",
    "diagnostics": "diagnostics.json",
    "viewing": "viewing.json",
}


def cells(board):
    data = {}
    with Image.open(checked(board["image"])) as f:
        image = np.asarray(f.convert("RGB"))
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert (w, h) == (160, 160)
        tile = image[y : y + h, x : x + w]
        assert tile.shape == (160, 160, 3)
        data[panel.get("label", panel.get("name"))] = tile
    return data


def keep(board, folder):
    file = checked(board["image"])
    dest = IMAGES / folder / file.name
    shutil.copyfile(file, dest)
    assert reference(dest)["sha256"] == board["image"]["sha256"]
    return board | {"image": board["image"] | {"path": str(dest.relative_to(IMAGES))}}


def main():
    refs = {key: reference(ROOT / name) for key, name in RECEIPTS.items()}
    state = {k: read_json(checked(v)) for k, v in refs.items()}
    exact, camera, extra, curve, viewed = (
        state[k] for k in ("evaluation", "camera", "diagnostics", "curves", "viewing")
    )
    assert viewed["exact"] == refs["evaluation"] and viewed["camera"] == refs["camera"]
    assert curve["evaluation"] == refs["evaluation"] and viewed["plot"] == curve["image"]
    assert exact["panel"] == extra["panel"] and exact["parents"] == extra["parent"]
    assert camera["previous_execution"] == refs["checked_original_camera"]
    assert camera["aligned"] == exact["checkpoints"]["aligned"]
    assert camera["engine"] == exact["engine"] and camera["kernel"] == exact["windows"]
    for target in (*exact["checkpoints"].values(), exact["engine"], exact["windows"]):
        checked(target)
    parents = read_json(checked(exact["parents"]))
    panel = read_json(checked(exact["panel"]))
    assert (
        parents["panel"] == exact["panel"]
        and len(panel["rows"]) == len(exact["rows"]) == len(extra["rows"]) == 48
    )
    assert (
        len(extra["sample_isolation"]) == 4
        and sum(len(v["folds"]) for v in extra["sample_isolation"]) == 8
    )
    assert all(x["target_replacement_invariant"] for x in extra["sample_isolation"])

    IMAGES.mkdir()
    OUT.mkdir()
    for group in ("exact", "standing"):
        (IMAGES / group).mkdir()
    exact_set = []
    for case in exact["views"]:
        both = cells(case["board"])
        trio = cells(case["triplet"])
        assert list(trio) == ["Noisy Malvar", "Directional windows", "Exact GT"]
        assert all(np.array_equal(both[k], a) for k, a in trio.items())
        assert viewed["exact_notes"][case["id"]]["images"] == [
            case[k]["image"] for k in ("board", "triplet")
        ]
        exact_set.append(
            case
            | {k: keep(case[k], "exact") for k in ("board", "triplet")}
            | {"review": viewed["exact_notes"][case["id"]]["note"]}
        )
    camera_set = []
    for case in camera["rows"]:
        notes = viewed["camera_notes"][case["id"]]
        assert notes["images"] == [d["board"]["image"] for d in case["displays"]]
        for display in case["displays"]:
            rgb = cells(display["board"])
            assert {
                "Noisy (Malvar)",
                "ISO100 AHD reference",
                "V120 EMA",
                "Aligned control",
            } <= rgb.keys()
            if case["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= rgb.keys()
        camera_set.append(
            case
            | {
                "displays": [d | {"board": keep(d["board"], "standing")} for d in case["displays"]],
                "review": notes["note"],
            }
        )
    assert (
        len(exact_set) == 4
        and len(camera_set) == 8
        and sum(len(c["displays"]) for c in camera_set) == 12
    )
    figure = checked(curve["image"])
    shutil.copyfile(figure, IMAGES / figure.name)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "exact": exact_set,
            "standing": camera_set,
            "curve": curve["image"] | {"path": figure.name},
            "inputs": refs,
            "checkpoints": exact["checkpoints"],
            "iso100_references": "Independent AHD and camera JPEGs.",
        },
    )

    bundle = OUT / "evidence.tar.xz"
    previous = ROOT.with_name("wire-blind-spot-v1")
    ancestor = ROOT.with_name("wire-guide-refinement-v1")
    sources = [
        *[
            ROOT / name
            for name in (
                "capture_segments.py",
                "replay_parents.py",
                "segment.py",
                "evaluate_segments.py",
                "camera_segments.py",
                "camera_segments_bound.py",
                "visualize_segments.py",
                "diagnostics.py",
                "record_views.py",
                "publish.py",
            )
        ],
        *[previous / name for name in ("diagnose.py", "estimated_phase.py", "verifier.py")],
        *[ancestor / name for name in ("evaluate.py", "camera_review.py")],
        ROOT.with_name("paired-luminance-detail-v1") / "render.py",
        REPO / "src/demosaic/wire_segment_support.py",
        REPO / "tests/test_wire_segment_support.py",
        REPO / "scripts/report_scene_wave_guides.py",
        REPO / "scripts/train_local_paired_continuation.py",
        REPO / "configs/gfx-qualitative-20231231.json",
        REPO / "configs/gfx-green-mesh-20231231.json",
    ]
    archived = [
        *refs.values(),
        exact["parents"],
        exact["panel"],
        panel["plan"],
        camera["previous_query"],
        camera["previous_left_donors"],
        reference(manifest),
        *(reference(p) for p in sources),
    ]
    with tarfile.open(bundle, "x:xz", preset=4) as f:
        for binding in {r["path"]: r for r in archived}.values():
            path = checked(binding)
            name = (
                path.relative_to(REPO)
                if path.is_relative_to(REPO)
                else Path("external") / path.relative_to(EXTERNAL)
            )
            f.add(path, arcname=name)
    scope = {
        "training": "Existing EMA weights",
        "numerical_and_native": "Complete results and inspected plots",
        "full427_known_unseen": "Outside this scoped inference replay",
        "sources": 48,
        "CFA_count_per_ISO": 6,
        "synthetic_draws_per_role_per_source": 2,
        "guide": "Supplied aperture and rounded nominal frequencies, plus frozen measured proposals for cameras",
    }
    write_json(
        OUT / "publication.json",
        {
            "study": ROOT.name,
            "scope": scope,
            "input_receipts": refs,
            "synthetic_panel": exact["panel"],
            "frozen_parent": exact["parents"],
            "weights": exact["checkpoints"],
            "foundation_corpus100k": parents["base_corpus_100k"],
            "timings": {
                "parent_FP32_replay": parents["seconds"],
                "CPU_evaluation_including_wait": exact["elapsed_wall_including_wait_seconds"],
            },
            "summary": exact["summary"],
            "subgroups": exact["subgroups"],
            "gap_mask_oracle": extra["summary"],
            "camera": {
                c["id"]: {
                    "correction_vs_aligned": c["rgb_RMS_DN16"],
                    "directional_vs_uniform": c["local_minus_uniform_DN16"],
                }
                for c in camera["rows"]
            },
            "manifest": reference(manifest),
            "evidence": reference(bundle),
        },
    )
    print(
        "Published four native triplets, twelve camera boards and the measured tradeoff curve",
        flush=True,
    )


if __name__ == "__main__":
    main()
