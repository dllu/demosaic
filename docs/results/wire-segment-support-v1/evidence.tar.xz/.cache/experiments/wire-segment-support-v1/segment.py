"""Run reciprocal Bayer confidence checks on directional support windows."""

import math
import sys
from pathlib import Path

import numpy as np

from demosaic.prediction_archive import fingerprint
from demosaic.wire_segment_support import (
    directional_windows,
    energy_matched_gain,
    soft_wire_support,
    window_contrast,
)

ROOT = Path(__file__).resolve().parent
BLIND = ROOT.with_name("wire-blind-spot-v1")
sys.path.insert(0, str(BLIND))
from diagnose import as_cells, neighbors, templates
from estimated_phase import exterior_design, fit_profile
from verifier import affine_contrast, fitted_exterior, normalize, select_shrinkage

METHODS = ("global_hard", "global_soft", "local", "energy_matched")
LABELS = {
    "v120": "V120 EMA",
    "aligned": "Aligned control",
    "global_hard": "Whole aperture hard",
    "global_soft": "Whole aperture soft",
    "local": "Directional windows",
    "energy_matched": "Uniform matched RMS",
}


def fixed_geometry(geometry, *, quantize):
    actual = {k: geometry[k] for k in ("angles", "periods", "gap_center", "gap_axes", "gap_angle")}
    if not quantize:
        return actual
    angles = np.asarray(actual["angles"])
    frequencies = (
        np.stack((np.cos(angles), np.sin(angles)), axis=1) / np.asarray(actual["periods"])[:, None]
    )
    guides = np.rint(frequencies * 256) / 256
    return actual | {
        "angles": np.arctan2(guides[:, 1], guides[:, 0]).tolist(),
        "periods": (1 / np.linalg.norm(guides, axis=1)).tolist(),
    }


def dims_to_native(cells):
    h, w = cells.shape[:2]
    return cells.reshape(h, w, 2, 2).transpose(0, 2, 1, 3).reshape(h * 2, w * 2)


def same_color_average(cells):
    return 0.25 * sum(
        np.roll(cells, shift, axis=(0, 1)) for shift in ((0, 1), (0, -1), (1, 0), (-1, 0))
    )


def per_segment(carrier, planes, competitor, windows, values, site):
    channels = np.eye(4)[site[2]]
    affine = (channels[:, :, None] * planes[site][:, None, :]).reshape(-1, 12)
    nuisance = np.column_stack((affine, channels * competitor[site][:, None]))
    local_weights = np.column_stack((np.ones(len(channels)), windows[site]))
    measurements, errors = [], []
    for weight in local_weights.T:
        support, contrast, error = window_contrast(carrier[site], nuisance, weight)
        estimates = None if contrast is None else float(contrast @ values[site][support])
        measurements.append(estimates)
        errors.append(error)
    return measurements, errors


def compose_segment(data, base, geometry, profile, *, return_fields=False):
    """Return analytic lifts and support receipts for one observation batch."""
    raw = data["packed"].transpose(0, 2, 3, 1).astype(np.float64)
    ph, pw = raw.shape[1:3]
    native_hw = ph * 2, pw * 2
    x0, y0 = geometry["gap_center"]
    y, x = np.indices(native_hw, dtype=float)
    x -= (native_hw[1] - 1) / 2
    y -= (native_hw[0] - 1) / 2
    shape = geometry | {"phases": (0.0, 0.0), "widths": (0.1, 0.1)}
    trend, _, radius = templates(shape, native_hw)
    sinusoidal = exterior_design(native_hw, geometry)
    theta = geometry["angles"][0]
    # The supplied aperture sets scale, including the camera circles.
    windows = directional_windows(x - x0, y - y0, theta, *geometry["gap_axes"])
    packed_windows = np.moveaxis(as_cells(windows.transpose(2, 0, 1)), 0, -1)
    py, px = np.indices((ph, pw))
    parity = (px + py) % 2
    safe = (py >= 3) & (px >= 3) & (py < ph - 3) & (px < pw - 3)
    outside = (radius.min(2) > 1.4) & safe
    safe_stencil = neighbors(outside[..., None]).all(2)
    ring = outside & (radius.min(2) > 1.45) & (radius.max(2) < 3.1)
    inner = (radius < 1) & safe[..., None]
    phase_color = np.asarray(data["colors"])
    neutral_rgb = np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"]
    neutral = neutral_rgb[phase_color]
    sampled_base = np.stack(
        [base[:, int(c), i // 2 :: 2, i % 2 :: 2] for i, c in enumerate(phase_color)], axis=-1
    )
    raw_dif = raw - sampled_base.astype(float)
    outputs = {name: base.copy() for name in METHODS}
    receipts = []
    fields = []
    for role, (observed, delta) in enumerate(zip(raw, raw_dif, strict=True)):
        folds, carriers = [], []
        for fold in (0, 1):
            fit = ring & (parity != fold)
            variance = (
                profile["shot"] * np.median(observed[fit], axis=0).clip(min=0) + profile["read"]
            )
            noise = np.sqrt(np.maximum(variance, 1e-12))
            fitted = fit_profile(observed, sinusoidal, trend[..., :3], fit, noise, neutral)
            design, wave, _ = templates(geometry | fitted, native_hw)
            angle = geometry["angles"][1]
            u = (math.cos(angle) * x + math.sin(angle) * y) / geometry["periods"][1] + fitted[
                "phases"
            ][1]
            width = fitted["widths"][1]
            competitor = as_cells(
                np.exp(-0.5 * ((u - np.rint(u)) / width) ** 2) - math.sqrt(math.tau) * width
            )
            design[..., 4] = competitor
            prediction, outer, z_out = fitted_exterior(observed, design, fit, noise, neutral)
            if (observed[fit] >= 0.98).any():
                z_out = 0.0
            site = np.nonzero(inner & (parity == fold)[..., None])
            phi = wave * neutral / noise
            innovation = (observed - prediction) / noise
            corrected = innovation - same_color_average(innovation)
            a, _ = affine_contrast(design, phi, site)
            b, _ = normalize((phi - same_color_average(phi))[site])
            blend = select_shrinkage(innovation, corrected, site, outside, safe_stencil, a, b)[
                "blend"
            ]
            legacy = float((1 - blend) * (innovation[site] @ a) + blend * (corrected[site] @ b))
            residual = delta / noise
            deficit = float(
                (1 - blend) * (residual[site] @ a)
                + blend * ((residual - same_color_average(residual))[site] @ b)
            )
            estimates, errors = per_segment(
                phi,
                design[..., :3],
                competitor * neutral / noise,
                packed_windows,
                observed / noise,
                site,
            )
            carriers.append(dims_to_native(wave))
            folds.append(
                {
                    "outside": outer,
                    "exterior_z": z_out,
                    "legacy_amplitude": legacy,
                    "blend": blend,
                    "deficit": deficit,
                    "amplitude": estimates,
                    "error": errors,
                    "phase_width": fitted,
                    "outer_prediction_fingerprint": fingerprint(prediction[site]),
                    "contrast_fingerprint": fingerprint(np.r_[a, b]),
                }
            )
        amplitude = float(np.mean([q["outside"] for q in folds]))
        exterior_ok = (
            min(f["exterior_z"] for f in folds) >= 3
            and amplitude > 0
            and not ((observed >= 0.98) & (radius < 1.8)).any()
        )
        deficit = float(np.mean([q["deficit"] for q in folds]))
        amount = float(np.clip(deficit, 0, max(0, 0.5 * amplitude))) if exterior_ok else 0.0
        soft = soft_wire_support(
            np.array([f["amplitude"] for f in folds], dtype=float),
            np.array([f["error"] for f in folds], dtype=float),
            amplitude,
        )
        hard = np.mean([f["legacy_amplitude"] for f in folds]) > 0.5 * amplitude
        carrier = np.mean(carriers, axis=0)
        support = windows @ soft[1:]
        gains = {
            "global_hard": float(hard),
            "global_soft": float(soft[0]),
            "local": support,
            "energy_matched": energy_matched_gain(support, carrier),
        }
        for name in METHODS:
            lifts = amount * gains[name] * carrier
            outputs[name][role] = (base[role] + neutral_rgb[:, None, None] * lifts).astype(
                np.float32
            )
        receipts.append(
            {
                "folds": folds,
                "qualified": bool(exterior_ok),
                "shared_deficit": deficit,
                "applied_cap_amount": amount,
                "directional_support": soft[1:].tolist(),
                "whole_soft": float(soft[0]),
                "global_hard": bool(hard),
                "energy_matched_gain": gains["energy_matched"],
            }
        )
        if return_fields:
            fields.append({"support": support, "carrier": carrier, "amount": amount})
    return outputs, receipts, fields
