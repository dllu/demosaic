"""Audit sample isolation and the headroom from known break locations."""

from pathlib import Path

import numpy as np
import torch

from evaluate_segments import PANEL, PARENT, ROOT, await_case, geometry_row, read_data, score
from segment import compose_segment
from diagnose import as_cells
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

COLUMNS = (
    "partial_weak_response_pp",
    "partial_intact_RMS_DN16",
    "partial_gap_RMS_DN16",
    "partial_gap_false_line_DN16",
    "partial_all_added_RMS_DN16",
)


def check_isolation(case, data, base):
    _, initial, _ = compose_segment(data, base, geometry_row(case), case["profile"])
    py, px = np.indices(data["packed"].shape[-2:])
    lane = ((py + px) % 2)[..., None]
    inner = as_cells(data["inside"])
    tests = []
    for fold in (0, 1):
        mask = (inner & (lane == fold)).transpose(2, 0, 1)
        altered = data["packed"].copy()
        altered[:, mask] = 0.55 - 0.5 * altered[:, mask]
        renamed = data | {"packed": altered, "target": 0.3 + data["target"] * 0.1}
        _, seen, _ = compose_segment(renamed, base, geometry_row(case), case["profile"])
        unchanged = (
            "outside",
            "exterior_z",
            "phase_width",
            "outer_prediction_fingerprint",
            "contrast_fingerprint",
            "blend",
            "error",
        )
        for a, b in zip(initial, seen, strict=True):
            a, b = a["folds"][fold], b["folds"][fold]
            assert all(a[k] == b[k] for k in unchanged)
            assert a["amplitude"] != b["amplitude"]
        tests.append(
            {"fold": fold, "sites_per_role": int(mask.sum()), "unchanged_fields": unchanged}
        )
    return tests


def run():
    torch.set_num_threads(2)
    panel_ref = reference(PANEL)
    panel = read_json(checked(panel_ref))
    owner = read_json(PARENT.parent / "owner.json")
    rows = []
    audited = []
    for case in panel["rows"]:
        files = await_case(case["index"], len(panel["rows"]), owner)
        trials = []
        for j, (obs, binding) in enumerate(zip(case["draws"], files, strict=True)):
            data = read_data(obs["arrays"])
            base = read_data(binding)["aligned"]
            output, _, fields = compose_segment(
                data, base, geometry_row(case), case["profile"], return_fields=True
            )
            f = fields[1]
            candidate = output["local"]
            raw_wave = f["carrier"]
            energy = np.mean(np.square(raw_wave * f["support"]))
            keep = raw_wave * (~data["missing"])
            gain = min(1.0, np.sqrt(energy / max(np.mean(np.square(keep)), 1e-24)))
            direction = np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"]
            updated = candidate.copy()
            updated[1] = (base[1] + f["amount"] * gain * keep * direction[:, None, None]).astype(
                np.float32
            )
            m = {
                mode: score(value, base, data)
                for mode, value in (
                    ("local", candidate),
                    ("energy_matched", output["energy_matched"]),
                    ("gap_mask_oracle", updated),
                )
            }
            trials.append(
                {
                    "capture": obs["arrays"],
                    "parent": binding,
                    "scores": m,
                    "oracle_gain": float(gain),
                }
            )
            if case["index"] in (0, 1, 2, 3) and j == 0:
                checked_folds = check_isolation(case, data, base)
                _, first, _ = compose_segment(data, base, geometry_row(case), case["profile"])
                _, second, _ = compose_segment(
                    data | {"target": 0.31 + data["target"] * 0.1},
                    base,
                    geometry_row(case),
                    case["profile"],
                )
                assert first == second
                audited.append(
                    {
                        "index": case["index"],
                        "folds": checked_folds,
                        "capture": obs["arrays"],
                        "target_replacement_invariant": True,
                    }
                )
        rows.append(
            {
                "index": case["index"],
                "source": case["source"]["id"],
                "iso": case["profile"]["iso"],
                "draws": trials,
            }
        )
        if (case["index"] + 1) % 8 == 0:
            print(case["index"] + 1, flush=True)

    parent = reference(PARENT)
    bound = read_json(checked(parent))
    assert bound["panel"] == panel_ref
    for row, b in zip(rows, bound["cases"], strict=True):
        assert row["source"] == b["source"]
        assert [q["parent"] for q in row["draws"]] == [q["outputs"] for q in b["draws"]]
    summary = {}
    for iso in ("ISO400", "ISO6400"):
        summary[iso] = {
            mode: {
                key: float(
                    np.mean(
                        [
                            d["scores"][mode][key]
                            for r in rows
                            if r["iso"] == iso
                            for d in r["draws"]
                        ]
                    )
                )
                for key in COLUMNS
            }
            for mode in ("local", "energy_matched", "gap_mask_oracle")
        }
    write_json(
        ROOT / "diagnostics.json",
        {
            "panel": panel_ref,
            "parent": parent,
            "driver": reference(__file__),
            "sample_isolation": audited,
            "summary": summary,
            "rows": rows,
            "oracle_scope": "Known exact missing pixels zero the partial-role carrier only. Match the local correction energy subject to its existing cap. All other role outputs remain from the directional method. Ground truth is used only in this diagnostic.",
        },
    )


if __name__ == "__main__":
    run()
