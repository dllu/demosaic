"""Record the inspected native views before publishing."""

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
EXACT = {
    "ISO400-best-03-draw1": "The already visible diagonals stay largely in place. The smaller difference in the break is subtle in the full native crop.",
    "ISO400-adverse-46-draw1": "Bright instrument edges stay intact. All methods retain broad structure and miss parts of the faint pattern.",
    "ISO6400-best-30-draw1": "The pale wall stays close to the aligned parent. Narrow vertical structure around the frame is still soft.",
    "ISO6400-adverse-33-draw0": "Directional and uniform corrections look close across the bright folds. The larger false projection is localized within the exact break.",
}
CAMERA = {
    "main-overcast-sky-main-overcast-sky": "Smooth sky, with no proposal and no edit.",
    "main-building-detail-main-building-detail": "The directional change is smaller than the hard-gate correction. Fine lines and small braces stay soft.",
    "main-foliage-main-foliage": "The leaf subdivisions remain soft. Empty bank and unchanged aligned colors.",
    "main-chain-link-fence-main-chain-link-fence": "Coarse crossings stay coherent. Directional and uniform lifts look similar.",
    "mesh-nominal-fine-green-mesh-left": "The post and mottled background remain, with no connected lattice. The earlier donor over Corpus 100k shows a stronger regular pattern.",
    "mesh-nominal-fine-green-mesh-right": "The central aperture has a small regular patch. The directional lift dims it slightly compared with the hard gate.",
    "mesh-profile3879-fine-green-mesh-left": "Faint lower left diagonals persist. No convincing new linked crossings away from the post.",
    "mesh-profile3879-fine-green-mesh-right": "The clearest right diagonals persist. Missing intersections and regular contrast within the aperture persist.",
}


def main():
    e = reference(ROOT / "evaluation/result.json")
    c = reference(ROOT / "standing-bound/result.json")
    view = read_json(checked(e))
    camera = read_json(checked(c))
    assert set(EXACT) == {x["id"] for x in view["views"]}
    assert set(CAMERA) == {x["id"] for x in camera["rows"]}
    write_json(
        ROOT / "viewing.json",
        {
            "exact": e,
            "camera": c,
            "plot": read_json(ROOT / "curve.json")["image"],
            "viewed_native_cell_px": 160,
            "both_cab_JPEGs_and_AHD_viewed": True,
            "exact_notes": {
                x["id"]: {
                    "note": EXACT[x["id"]],
                    "images": [x[k]["image"] for k in ("board", "triplet")],
                }
                for x in view["views"]
            },
            "camera_notes": {
                x["id"]: {
                    "note": CAMERA[x["id"]],
                    "images": [d["board"]["image"] for d in x["displays"]],
                }
                for x in camera["rows"]
            },
            "viewing_time_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(
                timespec="seconds"
            ),
        },
    )


if __name__ == "__main__":
    main()
