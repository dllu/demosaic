"""Score reconstruction from a fixed panel with partially absent weak wires."""

from pathlib import Path
import time

import numpy as np
import torch

from segment import LABELS, METHODS, ROOT, compose_segment, fixed_geometry
from report_scene_wave_guides import native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from demosaic.prediction_archive import fingerprint

EXTERNAL = Path("/mnt/external/demosaic/wire-segment-support-v1")
PANEL = EXTERNAL / "fresh/panel.json"
PARENT = EXTERNAL / "parents/completed.json"
ATTENUATIONS = (0.25, 0.5, 0.75, 1.0)


def luma(values, data):
    weights = (np.array([0.2126, 0.7152, 0.0722]) @ data["matrix"].astype(float)) * data["wb"]
    return np.einsum("...chw,c->...hw", values.astype(float), weights)


def geometry_row(case):
    return fixed_geometry(case["geometry"], quantize=True)


def read_path(name):
    return read_json(checked(name))


def read_data(binding):
    with np.load(checked(binding), allow_pickle=False) as f:
        return {k: f[k] for k in f.files}


def await_case(index, count, owner):
    # Seeing the producer open the following source proves both prior files closed.
    sentinel = PARENT.parent / f"{index + 1:02d}-0.npz" if index + 1 < count else PARENT
    while not sentinel.exists():
        if not owner_live(owner) and not PARENT.exists():
            raise RuntimeError(f"Parent replay exited before source {index} was bound")
        time.sleep(2)
    return [reference(PARENT.parent / f"{index:02d}-{i}.npz") for i in (0, 1)]


def rms(value):
    return float(np.sqrt(np.mean(np.square(value))) * 65535)


def projection(value, reference_signal):
    return float(100 * (value @ reference_signal) / (reference_signal @ reference_signal))


def score(rgb, parent, data):
    y = luma(rgb, data)
    ref = luma(data["target"], data)
    default = luma(parent, data)
    intact, broken, query = (data[k] for k in ("preserved", "missing", "inside"))
    weak = ref[0] - ref[2]
    error = y - ref
    change = y - default

    def false_line(signal, mask):
        carrier = weak[mask]
        return float(
            65535 * abs(signal[mask] @ carrier) / np.linalg.norm(carrier) / np.sqrt(len(carrier))
        )

    return {
        "partial_weak_response_pp": projection((y[1] - y[2])[intact], weak[intact]),
        "intact_weak_response_pp": projection((y[0] - y[2])[query], weak[query]),
        "partial_intact_RMS_DN16": rms(error[1, intact]),
        "partial_gap_RMS_DN16": rms(error[1, broken]),
        "partial_gap_false_line_DN16": false_line(error[1], broken),
        "partial_gap_added_RMS_DN16": rms(change[1, broken]),
        "partial_intact_added_RMS_DN16": rms(change[1, intact]),
        "partial_all_added_RMS_DN16": rms(change[1]),
        "absent_false_line_DN16": false_line(error[2], query),
        "absent_added_RMS_DN16": rms(change[2, query]),
        "flat_RMS_DN16": rms(error[3, query]),
        "flat_added_RMS_DN16": rms(change[3, query]),
    }


def validate_targets(data):
    preserved, missing, inside = (data[k] for k in ("preserved", "missing", "inside"))
    assert (preserved & missing).sum() == 0
    assert ((preserved | missing) & ~inside).sum() == 0
    target = data["target"]
    np.testing.assert_array_equal(target[1][:, preserved], target[0][:, preserved])
    np.testing.assert_array_equal(target[1][:, missing], target[2][:, missing])


def evaluate_draw(case, draw, model):
    data = read_data(draw["arrays"])
    assert fingerprint(data["packed"]) == draw["packed"]
    assert fingerprint(data["target"]) == case["clean"]
    validate_targets(data)
    parents = read_data(model)
    restorations, gates, _ = compose_segment(
        data, parents["aligned"], geometry_row(case), case["profile"]
    )
    rendered = parents | restorations
    scores = {m: score(p, parents["aligned"], data) for m, p in rendered.items()}
    curve = {}
    for name in METHODS:
        parent = parents["aligned"]
        delta = rendered[name].astype(np.float64) - parent
        curve[name] = [
            score(parent + change * delta, parent, data) if change != 1.0 else scores[name]
            for change in ATTENUATIONS
        ]
    masses = (
        scores["local"]["partial_all_added_RMS_DN16"],
        scores["energy_matched"]["partial_all_added_RMS_DN16"],
    )
    assert abs(masses[0] - masses[1]) < 0.003, masses
    return {
        "input": draw["arrays"],
        "parent": model,
        "scores": scores,
        "curve": curve,
        "gates": gates,
    }


def statistics(group):
    rng = np.random.default_rng(202611191716)
    names = tuple(group[0]["redraws"][0]["scores"])
    metrics = tuple(group[0]["redraws"][0]["scores"]["aligned"])
    values = np.asarray(
        [
            [[np.mean([q["scores"][m][k] for q in row["redraws"]]) for k in metrics] for m in names]
            for row in group
        ]
    )
    order = rng.integers(len(group), size=(6500, len(group)))
    samples = values[order].mean(1)
    policy_mean = {
        m: {k: float(v) for k, v in zip(metrics, arr, strict=True)}
        for m, arr in zip(names, values.mean(0), strict=True)
    }
    comparisons = {}
    for control in ("aligned", "v120", "global_hard", "global_soft", "energy_matched"):
        a, b = names.index("local"), names.index(control)
        bounds = np.quantile((samples[:, a] - samples[:, b]), (0.025, 0.975), axis=0).T
        comparisons[control] = {
            key: {"delta": float(value), "CI95": interval.tolist()}
            for key, value, interval in zip(
                metrics, (values[:, a] - values[:, b]).mean(0), bounds, strict=True
            )
        }
    curves = {
        m: {
            str(level): {
                k: float(np.mean([d["curve"][m][i][k] for r in group for d in r["redraws"]]))
                for k in metrics
            }
            for i, level in enumerate(ATTENUATIONS)
        }
        for m in METHODS
    }
    return {
        "sources": len(group),
        "values": policy_mean,
        "paired_local_delta_vs": comparisons,
        "curves": curves,
    }


def images(panel, results, bound, directory):
    rows = []
    for iso in ("ISO400", "ISO6400"):
        cohort = [r for r in results if r["iso"] == iso]
        for selector, suffix in ((min, "best"), (max, "adverse")):
            key = "partial_gap_false_line_DN16"
            locate = lambda d: d["scores"]["local"][key] - d["scores"]["energy_matched"][key]  # noqa: E731
            picked = selector(cohort, key=lambda r: np.mean([locate(d) for d in r["redraws"]]))
            draw = selector(picked["redraws"], key=locate)
            number = picked["redraws"].index(draw)
            case = panel["rows"][picked["index"]]
            data = read_data(draw["input"])
            parents = read_data(draw["parent"])
            variants, _, _ = compose_segment(
                data, parents["aligned"], geometry_row(case), case["profile"]
            )
            camera = {k: data[k][None] for k in ("colors", "wb", "matrix")} | {
                "packed": data["packed"][1:2]
            }
            values = parents | variants
            view = native_board(
                directory,
                f"{iso}-{suffix}-{case['index']:02d}-draw{number}",
                [noisy_malvar(camera)[0], *(values[k][1] for k in LABELS), data["target"][1]],
                camera,
                {
                    "source": case["source"],
                    "crop": case["crop"],
                    "checkpoint": bound["checkpoints"],
                    "noise": case["profile"],
                    "CFA": case["CFA"],
                    "role": "partial-break",
                    "geometry": case["geometry"],
                    "guide_geometry": geometry_row(case),
                    "scores": draw["scores"],
                    "change_vs_uniform_DN16": locate(draw),
                    "input": draw["input"],
                },
                labels=("Noisy Malvar", *LABELS.values(), "Exact GT"),
                triplet_indices=(0, 5, 7),
                exposure=2,
                roi=(48, 48, 160, 160),
            )
            rows.append(view)
    return rows


def run():
    torch.set_num_threads(2)
    panel_ref = reference(PANEL)
    panel = read_path(panel_ref)
    owner = read_json(PARENT.parent / "owner.json")
    directory = ROOT / "evaluation"
    directory.mkdir()
    start = time.monotonic()
    results = []
    for case in panel["rows"]:
        i = case["index"]
        parent = await_case(i, len(panel["rows"]), owner)
        redraws = [
            evaluate_draw(case, data, b) for data, b in zip(case["draws"], parent, strict=True)
        ]
        results.append(
            {
                "index": i,
                "source": case["source"]["id"],
                "iso": case["profile"]["iso"],
                "boundary": case["geometry"]["boundary"],
                "step": case["geometry"]["step_present"],
                "tinted": case["geometry"]["tinted"],
                "redraws": redraws,
            }
        )
        if (i + 1) % 8 == 0:
            print(i + 1, round(time.monotonic() - start, 2), flush=True)
    bound_ref = reference(PARENT)
    bound = read_path(bound_ref)
    assert bound["panel"] == panel_ref
    for row, parent in zip(results, bound["cases"], strict=True):
        assert row["source"] == parent["source"]
        for raw, check in zip(row["redraws"], parent["draws"], strict=True):
            assert raw["input"] == check["input"] and raw["parent"] == check["outputs"]
    main = {
        iso: statistics([r for r in results if r["iso"] == iso]) for iso in ("ISO400", "ISO6400")
    }
    subgroup = {}
    for key in ("boundary", "step", "tinted"):
        subgroup[key] = {
            iso: {
                str(t): statistics([r for r in results if r["iso"] == iso and r[key] == t])
                for t in sorted({r[key] for r in results if r["iso"] == iso})
            }
            for iso in main
        }
    reviews = images(panel, results, bound, directory)
    write_json(
        directory / "result.json",
        {
            "panel": panel_ref,
            "parents": bound_ref,
            "checkpoints": bound["checkpoints"],
            "driver": reference(__file__),
            "engine": reference(ROOT / "segment.py"),
            "windows": reference(Path("src/demosaic/wire_segment_support.py")),
            "rows": results,
            "summary": main,
            "subgroups": subgroup,
            "views": reviews,
            "elapsed_wall_including_wait_seconds": time.monotonic() - start,
            "scope": "Same frozen RAW/FP32 parent. Supplied aperture and rounded nominal frequencies. Independent role redraws. Ground truth masks used only in scoring.",
        },
    )


if __name__ == "__main__":
    run()
