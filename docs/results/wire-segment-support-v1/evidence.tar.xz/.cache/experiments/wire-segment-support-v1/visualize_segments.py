"""Make native review sheets and error-versus-response plots."""

import argparse
import os

from PIL import Image, ImageDraw

from evaluate_segments import ROOT
from segment import LABELS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def inspect_sheet(name, rows, columns):
    canvas = Image.new("RGB", (168 * len(columns) + 8, 192 * len(rows)), "#161c21")
    draw = ImageDraw.Draw(canvas)
    for i, (name_label, item) in enumerate(rows):
        y0 = 192 * i
        draw.text((8, y0 + 2), name_label, fill="#f0f4f6")
        cells = {p.get("name", p.get("label")): p["png_xywh"] for p in item["panels"]}
        with Image.open(checked(item["image"])) as board:
            for j, key in enumerate(columns):
                x, y, w, h = cells[key]
                assert (w, h) == (160, 160)
                p = j * 168 + 8
                canvas.paste(board.crop((x, y, x + w, y + h)), (p, y0 + 29))
                draw.text((p, y0 + 15), key, fill="#d0d5dc")
    canvas.save(ROOT / f"inspect-{name}.png")


def cameras():
    result = read_json(ROOT / "standing/result.json")
    for family in ("main", "mesh"):
        for exposure in (4, 16):
            subset = [
                (r["id"], d["board"])
                for r in result["rows"]
                if r["id"].startswith(family)
                for d in r["displays"]
                if d["exposure"] == exposure
            ]
            if not subset:
                continue
            labels = [
                "V120 EMA",
                "Aligned control",
                LABELS["global_hard"],
                LABELS["local"],
                LABELS["energy_matched"],
                "ISO100 AHD reference",
            ]
            inspect_sheet(f"{family}-x{exposure}", subset, labels)
            if family == "mesh":
                inspect_sheet(
                    f"{family}-refs-x{exposure}",
                    subset,
                    (
                        "ISO6400 camera JPEG",
                        "Noisy (Malvar)",
                        "ISO100 AHD reference",
                        "ISO100 camera JPEG",
                    ),
                )


def synthetic():
    bound = reference(ROOT / "evaluation/result.json")
    data = read_json(checked(bound))
    for iso in ("ISO400", "ISO6400"):
        rows = [(r["id"], r["board"]) for r in data["views"] if iso in r["id"]]
        inspect_sheet(
            iso,
            rows,
            (
                "Noisy Malvar",
                LABELS["aligned"],
                LABELS["global_hard"],
                LABELS["local"],
                LABELS["energy_matched"],
                "Exact GT",
            ),
        )
    os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "matplotlib"))
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.7), constrained_layout=True)
    colors = {
        "global_hard": "#476882",
        "global_soft": "#9e692d",
        "local": "#117d69",
        "energy_matched": "#815aa0",
    }
    for i, (iso, summary) in enumerate(data["summary"].items()):
        initial = summary["values"]["aligned"]
        for j, key in enumerate(("partial_gap_false_line_DN16", "partial_gap_RMS_DN16")):
            ax = axes[i, j]
            ax.set_title(iso)
            ax.grid(color="#e4e8eb", linewidth=0.8)
            for method, color in colors.items():
                sequence = [initial] + list(summary["curves"][method].values())
                xx = [r[key] - initial[key] for r in sequence]
                yy = [
                    r["partial_weak_response_pp"] - initial["partial_weak_response_pp"]
                    for r in sequence
                ]
                ax.plot(xx, yy, color=color, marker=".", linewidth=1.6, label=LABELS[method])
            ax.axvline(0, color="#8996a1", linewidth=0.8)
            ax.axhline(0, color="#8996a1", linewidth=0.8)
            if j == 0:
                ax.set_ylabel("Change in intact weak response (pp)")
            if i == 1:
                title = "False-line projection" if j == 0 else "Total luma error"
                ax.set_xlabel(f"{title} in the break, change (DN16)")
    axes[0, 1].legend(frameon=False, fontsize=8)
    path = ROOT / "wire-response-vs-gap.png"
    fig.savefig(path, dpi=170, facecolor="white")
    plt.close(fig)
    write_json(
        ROOT / "curve.json",
        {
            "driver": reference(__file__),
            "evaluation": bound,
            "image": reference(path),
            "scope": "Identity plus four fixed attenuation steps 0.25, 0.50, 0.75 and 1.00. Curves show mean changes versus aligned EMA over identical source/draws.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("cameras", "synthetic"))
    (cameras if parser.parse_args().mode == "cameras" else synthetic)()
