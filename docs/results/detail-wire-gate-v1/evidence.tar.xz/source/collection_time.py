"""Bind preparation timing across the interruption and completed continuation."""

from pathlib import Path
import re

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT

if __name__ == "__main__":
    original = reference(OUT / "training.log")
    restarted = reference(OUT / "training-resume.log")
    final = reference(OUT / "training/completed.json")
    first = Path(original["path"]).read_text()
    again = Path(restarted["path"]).read_text()
    shows = lambda s: [
        (int(n), float(t)) for n, t in re.findall(r"^training (\d+) (\d+\.\d+)$", s, re.M)
    ]
    before, after = shows(first), shows(again)
    done = read_json(checked(final))
    assert 0 < before[-1][0] < after[0][0] <= after[-1][0] == done["count"] == 480
    assert abs(done["seconds"] - after[-1][1]) < 0.10
    write_json(
        OUT / "collection-time.json",
        {
            "driver": reference(Path(__file__)),
            "initial": original,
            "resumed": restarted,
            "completed": final,
            "recorded_initial_captures": before[-1][0],
            "recorded_initial_seconds": before[-1][1],
            "measured_resume_seconds": done["seconds"],
            "measured_total_seconds_lower_bound": before[-1][1] + done["seconds"],
            "scope": "Elapsed capture and statistics time through the last initial receipt plus the measured continuation. Unrecorded work in the interrupted interval is excluded.",
        },
    )
