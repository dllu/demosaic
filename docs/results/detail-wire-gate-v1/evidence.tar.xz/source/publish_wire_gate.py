"""Publish source-bound wire training, calibrated transfer and native comparisons."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from PIL import Image
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import HERE, OUT
from score_wire_gate import METHODS, separated, wire_values

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "plan",
    "audit",
    "preflight/completed",
    "fit-preflight/result",
    "training/completed",
    "collection-time",
    "fit-training/result",
    "calibration/completed",
    "held/completed",
    "score-calibration",
    "score-held",
    "score-off-grid",
    "matched",
    "new-headroom",
    "held-gate-use",
    "review-camera",
    "review-exact",
)
PRIORITY = "response-priority/"
PRIORITY_RECEIPTS = (
    "intervention",
    "fit-training/result",
    "score-calibration",
    "score-held",
    "score-off-grid",
    "held-gate-use",
    "matched",
    "review-camera",
    "review-exact",
    "review-full",
)
RECEIPTS += tuple(PRIORITY + n for n in PRIORITY_RECEIPTS)
OTHER = {
    "detail-directional-proposal-v1": (
        "proposal.py",
        "proposal_ceiling.py",
        "ceiling_frontier.py",
        "deficit.py",
        "measure_proposal.py",
    ),
    "detail-regime-router-v1": (
        "collect_router.py",
        "confirm_router.py",
        "confirm_capture.py",
        "review_router.py",
        "fit_split.py",
        "fit_router.py",
        "regime_router.py",
        "score_router.py",
    ),
    "detail-redraw-gate-v1": ("redraw_gate.py", "collect_redraw.py"),
    "direct-detail-response-v1": (
        "direct_detail.py",
        "train_direct.py",
        "collect_direct.py",
        "evaluate_direct.py",
        "audit_sources.py",
    ),
    "scene-detail-selector-v1": (
        "detail_selector.py",
        "review_selector.py",
        "evaluate_selector.py",
        "train_selector.py",
        "collect_training.py",
        "benchmark_shared_local_encoding.py",
    ),
    "scene-local-contrast-2400-v1": ("prepare_eval.py",),
    "context-conditioned-detail-v1": ("context_gate.py", "score.py", "mild_score.py", "capture.py"),
    "scene-mixture-wire-gaps-v1": ("scoring.py",),
    "green-covariance-refit-v1": ("wire_math.py",),
}


def bound(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def tile(v, folder):
    src = checked(v["image"])
    dst = folder / src.name
    shutil.copyfile(src, dst)
    updated = bound(dst)
    assert updated["sha256"] == v["image"]["sha256"]
    with Image.open(dst) as diagram:
        for q in v["panels"]:
            x, y, w, h = q["png_xywh"]
            assert w == h == 160 and x + w <= diagram.width and y + h <= diagram.height
    return v | {"image": updated}


def plot(replay, folder):
    wires, _ = separated(replay["rows"])
    panel, axes = plt.subplots(1, 2, figsize=(10.6, 4.25), layout="constrained")
    chosen = {k: r["locked"]["dose"] for k, r in replay["policy"]["arms"].items()}
    labels = {
        "constant": ("Fixed learned gains", "#777777"),
        "conditioning": ("Learned conditioning", "#4477aa"),
        "directional": ("Learned directional", "#228833"),
        "rolled directional": ("Rolled descriptors", "#ee7733"),
    }
    resp = "weak_response_pp"
    anchor = wire_values(wires, "nominal", resp, 0).mean()
    for a, m, name, cap in zip(
        axes,
        ("intact_increment_RMS_DN16", "gap_weak_RMS_DN16"),
        ("Intact paired error", "Weak-direction error in true gaps"),
        (0.10, 0.05),
        strict=True,
    ):
        q = wire_values(wires, "nominal", m, 0).mean()
        sample = lambda k, d: (
            wire_values(wires, k, m, d).mean() - q,
            wire_values(wires, k, resp, d).mean() - anchor,
        )
        for key, (title, color) in labels.items():
            xx, yy = zip(*(sample(key, d) for d in np.linspace(0, 1, 41)), strict=True)
            a.plot(xx, yy, color=color, label=title)
            x, y = sample(key, chosen.get(key, chosen["directional"]))
            a.scatter(x, y, s=22, color=color, zorder=3)
        a.scatter(
            *sample("router", 0), marker="s", color="#882255", s=30, label="Earlier Bayer blend"
        )
        a.scatter(
            *sample("parent phase", 0),
            marker="d",
            color="#ccbb44",
            s=30,
            label="Parent-phase deficit",
        )
        a.axhline(0, ls=":", color="#888", lw=1)
        a.axvline(0, ls=":", color="#888", lw=1)
        a.axvline(cap, ls="--", color="#222", lw=1)
        a.set_xlabel("RMS difference from Local 50k (DN16)")
        a.set_title(name)
    axes[0].set_ylabel("Weak response gain (percentage points)")
    axes[1].legend(frameon=False, fontsize=7.4)
    out = folder / "weak-response-and-error.png"
    panel.savefig(out, dpi=160)
    return bound(out)


def verify(data, refs, book):
    plan = data["plan"]
    assert data["audit"]["coverage"]["plan"] == refs["plan"]
    assert data["collection-time"]["completed"] == refs["training/completed"]
    for name in ("initial", "resumed"):
        book[f"logs/collection-{name}.txt"] = data["collection-time"][name]
    assert data["audit"]["arithmetic"]["preflight"] == refs["preflight/completed"]
    for group in ("preflight", "training", "calibration", "held"):
        c = data[f"{group}/completed"]
        assert c["plan"] == refs["plan"]
        targets = plan["groups"][group]
        rows = []
        for i, f in enumerate(c["chunks"]):
            info = read_json(checked(f))
            assert info["plan"] == refs["plan"]
            rows.extend(info["rows"])
            book[f"chunks/{group}/{i:02}.json"] = f
            if "stats" in info:
                checked(info["stats"])
        assert len(rows) == len(targets) == c["count"]
        for a, b in zip(rows, targets, strict=True):
            assert a["source"]["cache_sha256"] == b["source"]["cache_sha256"]
            assert a["source"]["id"] == b["source"]["id"] and a["kind"] == b["kind"]
            assert len(set(a["noise_seeds"])) == 4
            if "file" in a:
                checked(a["file"])
        if group in ("calibration", "held"):
            score = data[f"score-{group}"]
            assert score["source"] == refs[f"{group}/completed"]
            assert all(
                r["id"] == a["id"] and r["file"] == a["proof"]["input"]
                for r, a in zip(rows, score["rows"], strict=True)
            )
    for group in ("preflight", "training"):
        model = data[f"fit-{group}/result"]
        assert model["collection"] == refs[f"{group}/completed"]
        assert model["plan"] == refs["plan"]
        for k, f in model["checkpoints"].items():
            book[f"checkpoints/{group}/{k}.pt"] = f
    for group in ("calibration", "held", "off-grid"):
        assert data[f"score-{group}"]["weights"] == refs["fit-training/result"]
    for group in ("held", "off-grid"):
        assert data[f"score-{group}"]["calibration"] == refs["score-calibration"]
        assert data["matched"]["sources"][group] == refs[f"score-{group}"]
    assert data["score-off-grid"]["source"] == plan["prior_off_grid"]
    assert data["new-headroom"]["source"] == refs["held/completed"]
    assert data["new-headroom"]["evaluation"] == refs["score-held"]
    assert data["held-gate-use"]["from"] == refs["score-held"]
    assert data["held-gate-use"]["fit"] == refs["fit-training/result"]
    for k in ("review-camera", "review-exact"):
        assert data[k]["fit"] == refs["fit-training/result"]
        assert data[k]["lock"] == refs["score-calibration"]
        assert data[k]["deficit"] == data["score-calibration"]["deficit"]
    assert data["review-exact"]["report"]["reference"] == refs["score-held"]

    p = {k: data[PRIORITY + k] for k in PRIORITY_RECEIPTS}
    bound = {k: refs[PRIORITY + k] for k in PRIORITY_RECEIPTS}
    assert p["intervention"]["motivation"] == refs["score-calibration"]
    fit = p["fit-training/result"]
    assert fit["plan"] == refs["plan"] and fit["response_weight_wire"] == 5.4
    assert fit["collection"]["sha256"] == refs["training/completed"]["sha256"]
    assert (
        Path(fit["collection"]["path"]).resolve()
        == Path(refs["training/completed"]["path"]).resolve()
    )
    for name, ref in fit["checkpoints"].items():
        book[f"checkpoints/response-priority/{name}.pt"] = ref
    for group in ("calibration", "held", "off-grid"):
        r = p[f"score-{group}"]
        assert r["weights"] == bound["fit-training/result"]
        expected = data["score-" + group]["source"]
        assert Path(r["source"]["path"]).resolve() == Path(expected["path"]).resolve()
        assert r["source"]["sha256"] == expected["sha256"]
        assert [row["id"] for row in r["rows"]] == [
            row["id"] for row in data["score-" + group]["rows"]
        ]
        if group != "calibration":
            assert r["calibration"] == bound["score-calibration"]
            assert p["matched"]["sources"][group] == bound[f"score-{group}"]
    assert p["held-gate-use"]["from"] == bound["score-held"]
    assert p["held-gate-use"]["fit"] == bound["fit-training/result"]
    for name in ("review-camera", "review-exact"):
        assert p[name]["fit"] == bound["fit-training/result"]
        assert p[name]["lock"] == bound["score-calibration"]
    assert p["review-exact"]["report"]["reference"] == bound["score-held"]
    full = p["review-full"]
    assert full["fit"] == bound["fit-training/result"]
    assert full["lock"] == bound["score-calibration"]
    assert full["held"] == full["exact"]["reference"] == bound["score-held"]
    assert all(x == 1.0 for x in full["doses"].values())


def run():
    refs = {k: reference(OUT / (k + ".json")) for k in RECEIPTS}
    data = {k: read_json(checked(r)) for k, r in refs.items()}
    for k, r in data.items():
        for attr in ("driver", "operator"):
            if attr in r:
                checked(r[attr])
    book = {f"receipts/{k}.json": r for k, r in refs.items()}
    verify(data, refs, book)
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    stages = {}
    summary_data = {}
    for prefix, dir_ in (("", ASSETS), (PRIORITY, ASSETS / "response-priority")):
        dir_.mkdir(exist_ok=True)
        scalar = data[prefix + "review-exact"]["doses"]
        photo = data[prefix + "review-exact"]["report"]["rows"]
        video = data[prefix + "review-camera"]["report"]["rows"]
        locked_camera = {r["id"]: r["RGB_RMS_DN16"] for r in video}
        if prefix:
            full = data[prefix + "review-full"]
            scalar = full["doses"]
            photo = full["exact"]["rows"]
            video = full["camera"]["rows"]
        assert len(photo) == 3 and sum(len(r["views"]) for r in video) == 12
        for row in photo:
            row["views"] = {k: tile(v, dir_) for k, v in row["views"].items()}
        for row in video:
            row["views"] = [tile(v, dir_) for v in row["views"]]
            for x in row["views"]:
                labels = {s["label"] for s in x["panels"]}
                assert "ISO100 AHD reference" in labels
                if row["id"].startswith("mesh-"):
                    assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= labels
        graph = plot(data[prefix + "score-held"], dir_)
        fit = data[prefix + "fit-training/result"]
        key = prefix.rstrip("/") if prefix else "initial"
        stages[key] = {
            "weights": fit["checkpoints"],
            "doses": scalar,
            "scope": "Full-strength diagnostic" if prefix else "Calibration lock",
            "photo": photo,
            "camera": video,
            "plot": graph,
        }
        summary_data[key] = {
            "training": {k: v for k, v in fit.items() if k != "logs"},
            "locks": {
                k: {m: v for m, v in r.items() if m != "trials"}
                for k, r in data[prefix + "score-calibration"]["policy"]["arms"].items()
            },
            "scores": {
                k: data[prefix + f"score-{k}"]["summary"]
                for k in ("calibration", "held", "off-grid")
            },
            "matched": data[prefix + "matched"]["results"],
            "gate_usage": data[prefix + "held-gate-use"]["summary"],
            "third_branch_ablation": data[prefix + "held-gate-use"]["full_minus_omit_mean"],
            "camera": {r["id"]: r["RGB_RMS_DN16"] for r in video},
            "locked_camera": locked_camera,
        }
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            "arms": summary_data,
            "collection_timing": data["collection-time"],
            "exact_headroom": data["new-headroom"]["summary"],
            "source_audit": data["audit"]["coverage"],
        },
    )
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {
            "parent": data["plan"]["parent"],
            "v120": data["plan"]["v120"],
            "stages": stages,
        },
    )
    for file in sorted(HERE.glob("*.py")):
        book[f"source/{file.name}"] = reference(file)
    for folder, files in OTHER.items():
        for file in files:
            book[f"sources/previous/{folder}/{file}"] = reference(HERE.with_name(folder) / file)
    for file in ("configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json"):
        book[file] = reference(ROOT / file)
    target = RESULTS / "evidence.tar.xz"
    with tarfile.open(target, "x:xz", preset=4) as f:
        for k, r in book.items():
            f.add(checked(r), arcname=k, recursive=False)
    with tarfile.open(target) as f:
        assert set(f.getnames()) == book.keys()
        for k, r in book.items():
            with f.extractfile(k) as block:
                assert file_digest(block, "sha256").hexdigest() == r["sha256"], k
    write_json(
        RESULTS / "publication.json",
        {
            "scope": "Trained spectral-gain component with fresh source and optical wire panels",
            "archive": bound(target),
            "summary": bound(summary),
            "manifest": bound(manifest),
            "members": book,
            "checkpoints": {k: m["weights"] for k, m in stages.items()},
        },
    )
    print(bound(target), flush=True)


if __name__ == "__main__":
    run()
