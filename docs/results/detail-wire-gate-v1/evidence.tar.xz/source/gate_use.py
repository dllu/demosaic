"""Measure held gain maps and isolate the directional field's actual contribution."""

from pathlib import Path
import sys
from unittest.mock import patch
from statistics import mean

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT, ingredients, normalized, wire_scorer, ROI
import score_wire_gate
from score_wire_gate import loads, load_models
from evaluate_selector import deltas


def run():
    torch.set_num_threads(2)
    fit, net = load_models()
    bound = reference(OUT / "score-held.json")
    evidence = read_json(checked(bound))
    dose = evidence["policy"]["arms"]["directional"]["locked"]["dose"]
    ablation = dose if dose > 0 else 1.0
    _, meter = wire_scorer()
    by_kind = {}
    wire_rows = []
    for r, d, p, input_ in loads(evidence["source"]):
        f, cap, mode, neutral = ingredients(d, p, r["profile"])
        x = normalized(torch.from_numpy(f), net["normal"])
        c = torch.from_numpy(cap)
        with torch.no_grad():
            g = net["net"]["directional"](x, c)
        fields = deltas(mode, g)
        role_values = np.sqrt(np.mean(fields[ROI] ** 2, axis=(-1, -2))) * 65535
        g_points = g[:, 1:7, 1:7].numpy()
        info = {
            "id": r["id"],
            "input": input_,
            "gain_by_role_and_branch": g_points.mean(axis=(1, 2)).tolist(),
            "proposal_RMS_by_role_and_branch_DN16": role_values.tolist(),
        }
        by_kind.setdefault(r["kind"], []).append(info)
        if r["kind"] != "wire":
            continue
        shape = r["fixture"]["geometry"]
        if shape["family"] in ("smooth-dip", "contrast-step"):
            d = d | {"support": np.ones_like(d["support"])}
        metric = meter(d, shape)
        spread = neutral[None, :, None, None]
        whole = (p["nominal"] + ablation * fields.sum(1)[:, None] * spread).astype(
            p["nominal"].dtype
        )
        omit = (p["nominal"] + ablation * fields[:, :2].sum(1)[:, None] * spread).astype(
            p["nominal"].dtype
        )
        wire_rows.append(
            {"id": r["id"], "composed": metric(whole), "omit_directional": metric(omit)}
        )
    result = {
        k: {
            "mean_unscaled_station_gain": np.mean(
                [r["gain_by_role_and_branch"] for r in rows], axis=0
            ).tolist(),
            "median_unscaled_branch_RMS_DN16": np.median(
                [r["proposal_RMS_by_role_and_branch_DN16"] for r in rows], axis=0
            ).tolist(),
        }
        for k, rows in by_kind.items()
    }
    part = {}
    for key in wire_rows[0]["composed"]:
        values = [
            r["composed"][key] - r["omit_directional"][key]
            for r in wire_rows
            if key in r["composed"]
        ]
        part[key] = mean(values)
    print(result, part, flush=True)
    write_json(
        OUT / "held-gate-use.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "from": bound,
            "dose": dose,
            "ablation_dose": ablation,
            "measures": by_kind,
            "summary": result,
            "omission": wire_rows,
            "full_minus_omit_mean": part,
        },
    )


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "priority":
        OUT = OUT / "response-priority"
        with patch.object(score_wire_gate, "OUT", OUT):
            run()
    else:
        run()
