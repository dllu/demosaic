"""Check the same exact-target headroom on the newly captured optical fixtures."""

from pathlib import Path
from statistics import mean
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT, ROI, base, wire_scorer, ingredients, remove
from proposal_ceiling import native_proposal_columns, fit_exact
from ceiling_frontier import curve
from score_wire_gate import loads


def run():
    torch.set_num_threads(2)
    held = reference(OUT / "held/completed.json")
    after = reference(OUT / "score-held.json")
    settled = read_json(checked(after))
    assert settled["source"] == held
    checked(settled["calibration"])
    t0 = monotonic()
    certificate, make = wire_scorer()
    rows = []
    for r, obs, p, proof in loads(held):
        if r["kind"] != "wire":
            continue
        geo = r["fixture"]["geometry"]
        d = (
            obs | {"support": np.ones_like(obs["support"])}
            if geo["family"] in ("smooth-dip", "contrast-step")
            else obs
        )
        target = make(d, geo)
        parent = base.old.luma(p["nominal"], d)[ROI]
        y = remove((parent[0] - parent[2])[target.intact], target.intact_nuisance)
        _, cap, basis, _ = ingredients(d, p, r["profile"])
        options = {
            "conditioning": (basis[:, :2], cap[..., :2].transpose(0, 3, 1, 2)),
            "directional": (basis, cap.transpose(0, 3, 1, 2)),
        }
        report = {}
        for name, (field, maxima) in options.items():
            A, ceiling = native_proposal_columns(field, maxima, target)
            t = target.truth_weak
            fit = fit_exact(A, ceiling, t, y, t)
            steps = curve(A, ceiling, t, y)
            report[name] = {"oracle": fit, "curve": steps}
        rows.append(
            {
                "id": r["id"],
                "source": proof,
                "nominal": target(p["nominal"]),
                "report": report,
            }
        )
        if len(rows) % 8 == 0:
            print(len(rows), round(monotonic() - t0, 2), flush=True)
    assert len(rows) == 40
    summary = {}
    feature = "maximum_signed_response_pp"
    for arm in ("conditioning", "directional"):
        kept = [x for x in rows if all(x["report"][k]["curve"]["2.0"] is not None for k in options)]
        summary[arm] = {
            "mean_maximum_extra_response": mean(
                x["report"][arm]["oracle"][feature] - x["nominal"]["weak_response_pp"] for x in rows
            ),
            "number_at_two_points": sum(x["report"][arm]["curve"]["2.0"] is not None for x in rows),
            "mean_intact_RMS_delta_at_two_points_common": mean(
                x["report"][arm]["curve"]["2.0"]["paired_RMS"]
                - x["nominal"]["intact_increment_RMS_DN16"]
                for x in kept
            )
            if kept
            else None,
            "common_at_two_points": len(kept),
        }
    print(summary, flush=True)
    write_json(
        OUT / "new-headroom.json",
        {
            "driver": reference(Path(__file__)),
            "source": held,
            "evaluation": after,
            "scorer": certificate,
            "rows": rows,
            "summary": summary,
            "seconds": monotonic() - t0,
            "scope": "Exact-target gains by role. Intact-wire loss and response only.",
        },
    )


if __name__ == "__main__":
    run()
