"""Review full-strength behavior from the follow-up when calibration chooses zero."""

from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import score_wire_gate as score
import review_wire_gate as review
import torch

OUT = review.OUT / "response-priority"

if __name__ == "__main__":
    torch.set_num_threads(2)
    lock = reference(OUT / "score-calibration.json")
    assert read_json(checked(lock))["policy"]["arms"]["directional"]["locked"]["dose"] == 0
    dose = {k: 1.0 for k in score.METHODS}
    frames = {}
    with patch.object(score, "OUT", OUT), patch.object(review, "OUT", OUT):
        fit, models = score.load_models()
        for k, method in (("camera", review.standing), ("exact", review.exact)):
            folder = OUT / "native-full" / k
            folder.mkdir(exist_ok=True, parents=True)
            frames[k] = method(models, dose, folder)
    write_json(
        OUT / "review-full.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "lock": lock,
            "doses": dose,
            "held": reference(OUT / "score-held.json"),
            "camera": frames["camera"],
            "exact": frames["exact"],
            "scope": "Full-strength diagnostic for the response-weighted fit. The locked strength remains zero.",
        },
    )
