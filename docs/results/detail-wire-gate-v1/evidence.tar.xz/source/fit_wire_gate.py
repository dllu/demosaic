"""Compare fixed, conditioning and directional gates under the same exact losses."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch
from torch import nn

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import HERE, OUT, Gate, normalized, objective, WIRE_RESPONSE_WEIGHT

METHODS = ("constant", "conditioning", "directional")
UPDATES = 1400
BATCH = (24, 12)
LR = 0.00065
EMA = 0.993
SEED = 202611201026


class Constant(nn.Module):
    def __init__(self):
        super().__init__()
        self.logit = nn.Parameter(torch.tensor([-3.5, -2.3, -3.5]))

    def forward(self, f, cap):
        return self.logit.sigmoid() * cap


def load_stats(ref, device):
    seen = set()
    rows = []
    blocks = []
    for stamp in read_json(checked(ref))["chunks"]:
        page = read_json(checked(stamp))
        with np.load(checked(page["stats"]), allow_pickle=False) as f:
            blocks.append({k: f[k] for k in f.files})
        for row in page["rows"]:
            source = {row["source"]["id"], row["source"]["cache_sha256"]}
            assert source.isdisjoint(seen)
            assert len(set(row["noise_seeds"])) == 4
            seen |= source
            rows.append(row)
    q = {k: torch.from_numpy(np.concatenate([r[k] for r in blocks])).to(device) for k in blocks[0]}
    assert len(q["features"]) == len(rows)
    return rows, q


def fit(which):
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    pre = which == "preflight"
    device = "cpu" if pre else "cuda"
    if not pre:
        torch.cuda.set_per_process_memory_fraction(
            min(1.0, 3 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
        )
        torch.backends.cuda.matmul.allow_tf32 = False
    completed = reference(OUT / which / "completed.json")
    source = read_json(checked(completed))
    rows, data = load_stats(completed, device)
    attr = data["features"]
    axis = tuple(range(attr.ndim - 1))
    normal = {"mean": attr.mean(axis), "sd": attr.std(axis, unbiased=False).clamp_min(0.05)}
    data["features"] = normalized(attr, normal)
    weave = {
        k: torch.tensor([j for j, row in enumerate(rows) if (row["kind"] == "wire") == k])
        for k in (True, False)
    }
    models = {
        "constant": Constant().to(device),
        "conditioning": Gate(False).to(device),
        "directional": Gate(True).to(device),
    }
    models["directional"].load_state_dict(models["conditioning"].state_dict())
    averages = {
        name: (Constant() if name == "constant" else Gate(name == "directional"))
        .to(device)
        .requires_grad_(False)
        for name in METHODS
    }
    for name, net in averages.items():
        net.load_state_dict(models[name].state_dict())
    with torch.no_grad():
        check = data["features"][:1], data["support"][:1]
        a, b, c = (net(*check) for net in models.values())
        torch.testing.assert_close(c, a, rtol=0, atol=0)
        torch.testing.assert_close(b[..., :2], a[..., :2], rtol=0, atol=0)
    optim = {
        k: torch.optim.AdamW(n.parameters(), lr=LR, weight_decay=1e-4) for k, n in models.items()
    }
    random = torch.Generator().manual_seed(SEED)
    sites = {k: min(len(weave[k]), BATCH[j]) for j, k in enumerate((True, False))}
    steps = 7 if pre else UPDATES
    trace = {}
    start = monotonic()
    for i in range(1, steps + 1):
        examples = []
        for wire in (True, False):
            pool = weave[wire]
            j = pool[torch.randint(len(pool), (sites[wire],), generator=random)].to(device)
            examples.append({k: v[j] for k, v in data.items()})
        report = {}
        for k, net in models.items():
            opt = optim[k]
            opt.zero_grad(set_to_none=True)
            maps = [net(x["features"], x["support"]) for x in examples]
            x = objective(maps[0], examples[0], WIRE_RESPONSE_WEIGHT)
            y = objective(maps[1], examples[1], 0.35)
            loss = x + 0.7 * y
            assert torch.isfinite(loss)
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()
            with torch.no_grad():
                torch._foreach_lerp_(
                    list(averages[k].parameters()), list(net.parameters()), 1 - EMA
                )
            if i in (1, steps) or i % 100 == 0:
                report[k] = {
                    "wire": x.item(),
                    "natural": y.item(),
                    "wire_mean_gain": maps[0].detach().reshape(-1, 3).mean(0).tolist(),
                }
        if report:
            trace[i] = report
            print(i, round(monotonic() - start, 2), report, flush=True)
    root = OUT / f"fit-{which}"
    root.mkdir(exist_ok=True)
    checkpoints = {}
    for k, net in models.items():
        dest = root / (k + ".pt")
        tmp = dest.with_suffix(".partial")
        state = {
            "raw": {name: v.cpu() for name, v in net.state_dict().items()},
            "ema": {name: v.cpu() for name, v in averages[k].state_dict().items()},
            "normal": {name: v.cpu() for name, v in normal.items()},
            "optimizer": optim[k].state_dict(),
            "updates": steps,
            "role": k,
            "collection": completed,
            "rng": random.get_state(),
        }
        torch.save(state, tmp)
        tmp.replace(dest)
        checkpoints[k] = reference(dest)
        revised = torch.load(checked(checkpoints[k]), weights_only=True, map_location="cpu")
        assert revised["collection"] == completed and revised["updates"] == steps
        for key, v in state["ema"].items():
            assert torch.equal(revised["ema"][key], v)
    write_json(
        root / "result.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(HERE / "wire_gate.py"),
            "collection": completed,
            "plan": source["plan"],
            "checkpoints": checkpoints,
            "sources": len(rows),
            "wire_natural_batch": [sites[True], sites[False]],
            "updates": steps,
            "unique_role_examples": 4 * len(rows),
            "total_role_visits_per_arm": 4 * sum(sites.values()) * steps,
            "response_weight_wire": WIRE_RESPONSE_WEIGHT,
            "response_weight_natural": 0.35,
            "seconds": monotonic() - start,
            "lr": LR,
            "ema_decay": EMA,
            "logs": trace,
            "seed": SEED,
        },
    )


if __name__ == "__main__":
    fit(sys.argv[1])
