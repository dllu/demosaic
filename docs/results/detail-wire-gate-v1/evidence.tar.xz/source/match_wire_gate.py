"""Compare wire error at fixed or matched weak-response gains."""

from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_wire_gate import OUT, separated, wire_values

PAIR_METRICS = (
    "intact_increment_RMS_DN16",
    "gap_weak_RMS_DN16",
    "exterior_only_weak_RMS_DN16",
    "exact_flat_RMS_DN16",
    "gap_continuing_strong_RMS_DN16",
    "weak_response_pp",
)


def match(rows):
    wires, _ = separated(rows)
    groups = (
        ("directional", "conditioning"),
        ("directional", "constant"),
        ("directional", "rolled directional"),
    )
    control = float(wire_values(wires, "nominal", "weak_response_pp", 0).mean())
    rng = np.random.default_rng(202611201039)
    matches = {}
    for a, b in groups:
        nominal = {
            k: float(wire_values(wires, k, "weak_response_pp", 1).mean()) - control for k in (a, b)
        }
        common = min(nominal.values())
        if common <= 0:
            matches[f"{a} versus {b}"] = {
                "status": "no shared positive gain through the full-strength arms"
            }
            continue
        scale = {k: common / v for k, v in nominal.items()}
        measurements = {}
        for m in PAIR_METRICS:
            u, v = (wire_values(wires, k, m, scale[k]) for k in (a, b))
            n = len(u)
            ids = np.vstack((np.arange(n), rng.integers(n, size=(12000, n))))
            delta = (u - v)[ids].mean(1)
            measurements[m] = [float(delta[0]), *np.quantile(delta[1:], (0.025, 0.975)).tolist()]
        matches[f"{a} versus {b}"] = {
            "common_extra_response": common,
            "scales": scale,
            "effects": measurements,
        }
    return matches


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "priority":
        OUT = OUT / "response-priority"
    evidence = {k: reference(OUT / f"score-{k}.json") for k in ("held", "off-grid")}
    results = {k: match(read_json(checked(s))["rows"]) for k, s in evidence.items()}
    print(results, flush=True)
    write_json(
        OUT / "matched.json",
        {
            "driver": reference(Path(__file__)),
            "sources": evidence,
            "results": results,
            "scope": "Retrospective full-strength linear scaling at the same response.",
        },
    )
