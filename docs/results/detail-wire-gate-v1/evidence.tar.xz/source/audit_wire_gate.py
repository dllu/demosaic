"""Check the quadratic controls against native delivery and verify held source separation."""

import json
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from wire_gate import OUT, base, ROI, ingredients, prior_delta, wire_scorer, remove
from collect_wire_gate import identities
from evaluate_selector import deltas

sys.path.insert(0, str(Path(__file__).resolve().parent.with_name("direct-detail-response-v1")))
from audit_sources import CORPUS, LOCAL, matches


def arithmetic():
    bound = reference(OUT / "preflight/completed.json")
    collect = read_json(checked(bound))
    page = read_json(checked(collect["chunks"][0]))
    with np.load(checked(page["stats"]), allow_pickle=False) as x:
        data = {k: x[k] for k in x.files}
    ref, factory = wire_scorer()
    rng = np.random.default_rng(162)
    cases = {}
    for i, row in enumerate(page["rows"]):
        with np.load(checked(row["file"]), allow_pickle=False) as npz:
            d = {k: npz[k] for k in npz.files}
        _, cap, fields, neutral = ingredients(d, d, row["profile"])
        gains = rng.random(cap.shape, dtype=np.float32) * cap
        move = deltas(fields, torch.from_numpy(gains)).sum(1)
        done = d["nominal"].astype(np.float64) + move[:, None] * neutral[None, :, None, None]
        y, t, z = (base.old.luma(x, d)[ROI] for x in (d["nominal"], d["target"], done))
        gain = gains[:, 1:7, 1:7].transpose(0, 3, 1, 2).reshape(4, -1).astype(np.float64)
        pair = np.r_[gain[0], gain[2]]
        ext = np.r_[gain[1], gain[2]]
        delta = lambda p, G, B: (
            2 * np.sum(p * B, axis=-1) + (p[..., None, :] @ G @ p[..., None])[..., 0, 0]
        )
        factor = 65535 / 128
        exact = (
            np.sum(base.fine(z - t) ** 2, axis=-1) * factor**2
            - np.sum(base.fine(y - t) ** 2, axis=-1) * factor**2
        )
        errors = {}
        errors["absolute"] = float(
            np.max(np.abs(exact - delta(gain, data["roleG"][i], data["roleB"][i])))
        )
        shape = row["fixture"]["geometry"]
        if shape is None:
            fn = lambda x: base.fine(x) * factor
        else:
            arg = (
                d | {"support": np.ones_like(d["support"])}
                if shape["family"] in ("smooth-dip", "contrast-step")
                else d
            )
            m = factory(arg, shape)
            dn = 65535 / np.sqrt(np.count_nonzero(m.intact))
            fn = lambda x: remove(x[m.intact], m.intact_nuisance) * dn
            before, after = (m(x) for x in (d["nominal"], done))
            for key, vec, tag in (
                ("gap_weak_RMS_DN16", gain[0], "gap"),
                ("exterior_only_weak_RMS_DN16", ext, "ext"),
            ):
                if key in before:
                    actual = after[key] ** 2 - before[key] ** 2
                    obtain = delta(vec, data[tag + "G"][i], data[tag + "B"][i])
                    errors[tag] = float(abs(actual - obtain))
        target = fn(t[0] - t[2])
        begin, end = (fn(x[0] - x[2]) - target for x in (y, z))
        val = (end @ target) - (begin @ target)
        errors["signal"] = float(abs(val - pair @ data["signal"][i]))
        errors["pair"] = float(
            abs((end @ end - begin @ begin) - delta(pair, data["pairG"][i], data["pairB"][i]))
        )
        assert max(errors.values()) < 0.003, (row["id"], errors)
        cases[row["id"]] = errors
    return {"preflight": bound, "scorer": ref, "error_DN16_squared": cases}


def sources():
    plan = reference(OUT / "plan.json")
    d = read_json(checked(plan))
    known = {k: identities(r["source"] for r in rows) for k, rows in d["groups"].items()}
    assert all(len(t) == 2 * len(d["groups"][k]) for k, t in known.items())
    assert len(set.union(*known.values())) == sum(map(len, known.values()))
    test = known["calibration"] | known["held"]
    with checked(d["training_manifest"]).open() as stream:
        assert identities(map(json.loads, stream)).isdisjoint(test)
    full = read_json(checked(d["fixed427"]))["source_metadata"]
    assert len(full) == 427 and test.isdisjoint(identities(full))
    local = reference(LOCAL)
    corpus = reference(CORPUS)
    data = read_json(checked(local))
    prev = read_json(checked(corpus))
    assert d["parent"] == data["checkpoint"] and data["parent"] == prev["checkpoint"]
    visits = 0
    for b in prev["source_traces"]:
        with checked(b).open() as f:
            for q in map(json.loads, f):
                for s in q["sources"]:
                    if s["kind"] == "photographic":
                        assert not matches(s, test)
                        visits += 1
    seen = 0
    for b in data["segments"]:
        with checked(b["observations"]).open() as f:
            for q in map(json.loads, f):
                assert not matches(q, test)
                seen += 1
    assert visits == 559808 and seen == 5000
    return {
        "plan": plan,
        "corpus": corpus,
        "local": local,
        "recorded_photo_visits": visits,
        "terminal_observations": seen,
        "groups": {k: len(v) // 2 for k, v in known.items()},
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    a = arithmetic()
    b = sources()
    print(a, b, flush=True)
    write_json(
        OUT / "audit.json", {"driver": reference(Path(__file__)), "arithmetic": a, "coverage": b}
    )
