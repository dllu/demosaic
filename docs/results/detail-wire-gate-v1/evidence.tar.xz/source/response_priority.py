"""Increase the wire response weight after calibration and retain all original controls."""

import sys
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import fit_wire_gate as fit
import score_wire_gate as score
import review_wire_gate as review

ROOT = fit.OUT
OUT = ROOT / "response-priority"
RESPONSE_WEIGHT = 5.4


def setup():
    OUT.mkdir(exist_ok=True)
    for name in ("training", "calibration", "held"):
        link = OUT / name
        if not link.exists():
            link.symlink_to(ROOT / name, target_is_directory=True)
        assert link.resolve() == (ROOT / name).resolve()
    note = OUT / "intervention.json"
    if not note.exists():
        before = reference(ROOT / "score-calibration.json")
        truth = read_json(checked(before))
        assert all(w["locked"]["dose"] == 0 for w in truth["policy"]["arms"].values())
        write_json(
            note,
            {
                "driver": reference(Path(__file__)),
                "motivation": before,
                "fit_driver": reference(Path(fit.__file__)),
                "score_driver": reference(Path(score.__file__)),
                "review_driver": reference(Path(review.__file__)),
                "training_response_weight_before": 0.9,
                "training_response_weight_after": RESPONSE_WEIGHT,
                "scope": "Only the signed wire response weight changes. Same initialization, coefficient data, sampled sources and buffered calibration.",
            },
        )


if __name__ == "__main__":
    setup()
    task = sys.argv[1]
    if task == "fit":
        with (
            patch.object(fit, "OUT", OUT),
            patch.object(fit, "WIRE_RESPONSE_WEIGHT", RESPONSE_WEIGHT),
        ):
            fit.fit("training")
    elif task == "review":
        with patch.object(score, "OUT", OUT), patch.object(review, "OUT", OUT):
            review.run()
    else:
        with patch.object(score, "OUT", OUT):
            score.run(task)
