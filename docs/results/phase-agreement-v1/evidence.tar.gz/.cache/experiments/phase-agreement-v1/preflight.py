"""Qualify prior report compatibility and the first agreement outputs."""
from pathlib import Path
import numpy as np
from report_fold_support_pooling import matched_quiet, report_camera
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root=Path(__file__).resolve().parent
plan=read_json(root/"plan.json")
prior=read_json(checked(plan["adopted_report"]))
prior_plan=read_json(checked(prior["plan"]))
prior_collection=read_json(checked(prior["collection"]))
out=root/"preflight"
out.mkdir()
boards=report_camera(prior_plan,prior_collection,out)
prior_signatures={v["id"]: v["image"]["sha256"] for v in prior["camera_boards"]}
assert prior_signatures=={v["id"]:v["image"]["sha256"] for v in boards}
replayed=matched_quiet(prior["fixed_threshold_metrics"],prior_plan["thresholds"],
                       prior_plan["positive_quiet_RMS_budgets_DN16"])
assert replayed==prior["leave_one_geometry_out"]
inspected=[]
changes=0
for group in plan["groups"][:8]:
    path=root/"output"/f"{group['id']}.json"
    value=read_json(path)
    for row in value["rows"]:
        with np.load(checked(row["prediction"])) as a, np.load(checked(row["adopted_prediction"])) as b:
            np.testing.assert_array_equal(a["pooled-t2"],b["pooled-t2"])
            assert all(np.isfinite(a[k]).all() for k in a.files)
            changes += int(np.any(a["agreement-t0"] != b["minimum-t0"]))
        agreement=np.asarray(row["fits"]["records"][0]["phase_agreement"])
        assert agreement.shape==(2,3) and np.isfinite(agreement).all() and np.max(abs(agreement))<=1
    inspected.append(reference(path))
assert changes>0
write_json(root/"preflight.json",{"driver":reference(__file__), "plan":reference(root/"plan.json"),
    "old_camera_PNGs_bitexact":8,"old_calibration_rows_bitexact":len(replayed),
    "first_pooled_control_arrays_bitexact":24,"new_t0_corrections_changed":changes,
    "groups":inspected})
print("8 unchanged camera boards, 192 exact calibration rows and 24 unchanged pooled control arrays.",changes,"new corrections at threshold zero.")
