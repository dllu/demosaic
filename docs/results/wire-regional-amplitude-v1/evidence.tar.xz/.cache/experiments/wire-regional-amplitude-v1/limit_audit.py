"""Check the effect of the half-exterior cap without changing measured support."""

import argparse
from pathlib import Path

import numpy as np
import torch

from evaluate_regions import ROOT, data_root, geometry_row, read_data, score
from regional import compose_regional, dims_to_native
from diagnose import as_cells, templates
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.regional_wire_amplitude import regional_deficit
from demosaic.wire_segment_support import directional_windows

RULES = ("local", "tangent_pool")
FIELDS = (
    "partial_weak_response_pp",
    "partial_gap_false_line_DN16",
    "partial_gap_RMS_DN16",
    "partial_intact_RMS_DN16",
    "partial_all_added_RMS_DN16",
    "absent_false_line_DN16",
    "flat_added_RMS_DN16",
)


def deliver_at_limit(base, data, geometry, gates, limit):
    h, w = base.shape[-2:]
    y, x = np.indices((h, w), dtype=float)
    x -= (w - 1) / 2 + geometry["gap_center"][0]
    y -= (h - 1) / 2 + geometry["gap_center"][1]
    windows = directional_windows(x, y, geometry["angles"][0], *geometry["gap_axes"])
    direction = np.linalg.solve(data["matrix"].astype(float), np.ones(3)) / data["wb"]
    outputs = {k: base.copy() for k in RULES}
    for j, role in enumerate(gates):
        cap = (
            max(0.0, limit * np.mean([q["outside"] for q in role["folds"]]))
            if role["qualified"]
            else 0.0
        )
        if not cap:
            continue
        wave = np.mean(
            [
                dims_to_native(templates(geometry | f["phase_width"], (h, w))[1])
                for f in role["folds"]
            ],
            axis=0,
        )
        support = np.asarray(role["directional_support"])
        pooled = np.asarray([f["along_wire_deficit"] for f in role["folds"]], dtype=float)
        amounts = {
            "local": np.clip(role["shared_deficit"], 0, cap) * support,
            "tangent_pool": regional_deficit(pooled, cap, reciprocal=True) * support,
        }
        for key, amp in amounts.items():
            outputs[key][j] = (base[j] + direction[:, None, None] * (windows @ amp) * wave).astype(
                np.float32
            )
    return outputs


def verify_partition(data, base, case):
    torch.set_num_threads(2)
    geo = geometry_row(case)
    _, orig = compose_regional(data, base, geo, case["profile"])
    y, x = np.indices(data["packed"].shape[-2:])
    parity = ((x + y) % 2)[..., None]
    inner = as_cells(data["inside"])
    results = []
    for q in (0, 1):
        mask = (inner & (parity == q)).transpose(2, 0, 1)
        edited = data["packed"].copy()
        edited[:, mask] = 0.75 - 0.5 * edited[:, mask]
        _, replay = compose_regional(data | {"packed": edited}, base, geo, case["profile"])
        fields = (
            "regional_deficit",
            "along_wire_deficit",
            "amplitude",
            "error",
            "phase_width",
            "outer_prediction_fingerprint",
            "exterior_z",
            "outside",
        )
        for a, b in zip(orig, replay, strict=True):
            assert all(a["folds"][1 - q][key] == b["folds"][1 - q][key] for key in fields)
            assert all(
                a["folds"][q][key] != b["folds"][q][key]
                for key in ("regional_deficit", "along_wire_deficit")
            )
        results.append(
            {
                "changed_fold": q,
                "samples_per_role": int(mask.sum()),
                "other_fold_unchanged": list(fields),
            }
        )
    return results


def run(phase):
    torch.set_num_threads(2)
    studied = reference(ROOT / phase / "result.json")
    original = read_json(checked(studied))
    source = read_json(checked(original["panel"]))
    rows = []
    isolation = []
    for case, results in zip(source["rows"], original["rows"], strict=True):
        records = []
        for i, d in enumerate(results["draws"]):
            data = read_data(d["input"])
            base = read_data(d["parent"])["aligned"]
            if case["index"] < 4 and i == 0:
                isolation.append(
                    {"source": case["source"]["id"], "tests": verify_partition(data, base, case)}
                )
            geo = geometry_row(case)
            historical = deliver_at_limit(base, data, geo, d["gates"], 0.5)
            changed = deliver_at_limit(base, data, geo, d["gates"], 1.0)
            summaries = {}
            for method in RULES:
                a, b = score(historical[method], base, data), score(changed[method], base, data)
                assert max(abs(a[k] - d["scores"][method][k]) for k in FIELDS) < 0.0003
                summaries[method] = {"half": a, "full": b}
            records.append({"input": d["input"], "parent": d["parent"], "scores": summaries})
        rows.append(
            {"source": case["source"]["id"], "iso": case["profile"]["iso"], "draws": records}
        )
        if len(rows) % 16 == 0:
            print(phase, len(rows), flush=True)
    summary = {}
    for iso in ("ISO400", "ISO6400"):
        selected = [r for r in rows if r["iso"] == iso]
        rng = np.random.default_rng(202611191731)
        boot = rng.integers(len(selected), size=(6500, len(selected)))
        results = {}
        for m in RULES:
            deltas = np.array(
                [
                    [
                        np.mean(
                            [
                                r["scores"][m]["full"][k] - r["scores"][m]["half"][k]
                                for r in s["draws"]
                            ]
                        )
                        for k in FIELDS
                    ]
                    for s in selected
                ]
            )
            cis = np.quantile(deltas[boot].mean(1), (0.025, 0.975), axis=0).T
            results[m] = {
                k: {"delta": float(d), "CI95": confidence.tolist()}
                for k, d, confidence in zip(FIELDS, deltas.mean(0), cis, strict=True)
            }
        summary[iso] = results
    write_json(
        ROOT / phase / "limit-audit.json",
        {
            "study": studied,
            "driver": reference(__file__),
            "scope": "Replay the fixed gains and exterior fields with a one-exterior-amplitude cap. Same noise, phase, measured deficit, clipping checks and support. Ground truth enters only metrics.",
            "isolation": isolation,
            "summary": summary,
            "rows": rows,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("development", "held_out"))
    run(parser.parse_args().phase)
