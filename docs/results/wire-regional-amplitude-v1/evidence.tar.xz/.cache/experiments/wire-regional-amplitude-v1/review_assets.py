"""Render full native triplets and the matched-strength amplitude comparisons."""

import argparse
import os

from PIL import Image, ImageDraw

from evaluate_regions import ROOT, geometry_row, read_data
from regional import LABELS, compose_regional
from report_scene_wave_guides import native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

DISPLAY = (
    "v120",
    "aligned",
    "local",
    "regional_mean",
    "regional_reciprocal",
    "tangent_pool",
    "same_support_uniform",
)
MEASURE = "partial_gap_false_line_DN16"


def sheet(name, rows, labels):
    canvas = Image.new("RGB", (168 * len(labels) + 8, 192 * len(rows)), "#181b21")
    draw = ImageDraw.Draw(canvas)
    for row, (case, board) in enumerate(rows):
        sy = row * 192
        draw.text((8, sy + 2), case, fill="#f1f3f5")
        coords = {c.get("name", c.get("label")): c["png_xywh"] for c in board["panels"]}
        with Image.open(checked(board["image"])) as f:
            for col, label in enumerate(labels):
                x, y, w, h = coords[label]
                assert (w, h) == (160, 160)
                sx = col * 168 + 8
                canvas.paste(f.crop((x, y, x + w, y + h)), (sx, sy + 28))
                draw.text((sx, sy + 15), label, fill="#d4d7dc")
    canvas.save(ROOT / f"inspect-{name}.png")


def camera():
    camera = read_json(ROOT / "standing/result.json")
    for family in ("main", "mesh"):
        for x in (4, 16):
            rows = [
                (r["id"], d["board"])
                for r in camera["rows"]
                if r["id"].startswith(family)
                for d in r["displays"]
                if d["exposure"] == x
            ]
            if not rows:
                continue
            sheet(
                f"{family}-x{x}",
                rows,
                (
                    LABELS["v120"],
                    LABELS["aligned"],
                    LABELS["local"],
                    LABELS["regional_mean"],
                    LABELS["tangent_pool"],
                    LABELS["same_support_uniform"],
                    "ISO100 AHD reference",
                ),
            )
            if family == "mesh":
                sheet(
                    f"{family}-references-x{x}",
                    rows,
                    (
                        "Noisy (Malvar)",
                        "ISO6400 camera JPEG",
                        "ISO100 AHD reference",
                        "ISO100 camera JPEG",
                    ),
                )


def plot(held):
    os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "matplotlib"))
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(9.3, 6.5), constrained_layout=True)
    colors = {
        "local": "#4c6580",
        "regional_mean": "#965c27",
        "regional_reciprocal": "#8a5595",
        "tangent_pool": "#167968",
        "same_support_uniform": "#be6a78",
    }
    for i, (iso, details) in enumerate(held["summary"].items()):
        baseline = details["values"]["aligned"]
        for j, (metric, title) in enumerate(
            (
                (MEASURE, "False-line projection in gaps"),
                ("partial_gap_RMS_DN16", "Total gap luma RMS"),
            )
        ):
            ax = axes[i, j]
            ax.set_title(iso)
            ax.grid(color="#e8eaec", lw=0.8)
            for name, color in colors.items():
                points = [baseline] + list(details["curves"][name].values())
                p = "partial_weak_response_pp"
                ax.plot(
                    [r[metric] - baseline[metric] for r in points],
                    [r[p] - baseline[p] for r in points],
                    marker=".",
                    color=color,
                    label=LABELS[name],
                    linewidth=1.7,
                )
            ax.axvline(0, lw=0.8, color="#9a9ea5")
            ax.axhline(0, lw=0.8, color="#9a9ea5")
            if j == 0:
                ax.set_ylabel("Change in preserved weak response (pp)")
            if i == 1:
                ax.set_xlabel(f"{title}, change (DN16)")
    axes[0, 1].legend(frameon=False, fontsize=7.9)
    dest = ROOT / "response-and-false-detail.png"
    fig.savefig(dest, dpi=170, facecolor="white")
    plt.close(fig)
    return reference(dest)


def change(draw):
    return draw["scores"]["tangent_pool"][MEASURE] - draw["scores"]["same_support_uniform"][MEASURE]


def synthetic():
    held_ref = reference(ROOT / "held_out/result.json")
    held = read_json(checked(held_ref))
    cases = read_json(checked(held["panel"]))
    local = ROOT / "native"
    local.mkdir()
    rendered = []
    for iso in ("ISO400", "ISO6400"):
        group = [r for r in held["rows"] if r["iso"] == iso]
        for choose, suffix in ((min, "beneficial"), (max, "adverse")):
            selected = choose(group, key=lambda r: sum(change(d) for d in r["draws"]))
            ordinal = choose(range(2), key=lambda i: change(selected["draws"][i]))
            observation = selected["draws"][ordinal]
            case = cases["rows"][selected["index"]]
            data = read_data(observation["input"])
            parents = read_data(observation["parent"])
            result, _ = compose_regional(
                data, parents["aligned"], geometry_row(case), case["profile"]
            )
            values = parents | result
            display = {k: data[k][None] for k in ("colors", "wb", "matrix")} | {
                "packed": data["packed"][1:2]
            }
            board = native_board(
                local,
                f"{iso}-{suffix}-{case['index']:02d}-draw{ordinal}",
                [
                    noisy_malvar(display)[0],
                    *(values[name][1] for name in DISPLAY),
                    data["target"][1],
                ],
                display,
                {
                    "source": case["source"],
                    "crop": case["crop"],
                    "noise": case["profile"],
                    "CFA": case["CFA"],
                    "weights": held["checkpoints"],
                    "scores": observation["scores"],
                    "input": observation["input"],
                    "role": "partial-break",
                    "guide_geometry": geometry_row(case),
                    "false_line_delta_to_uniform": change(observation),
                },
                labels=("Noisy Malvar", *map(LABELS.__getitem__, DISPLAY), "Exact GT"),
                triplet_indices=(0, DISPLAY.index("tangent_pool") + 1, len(DISPLAY) + 1),
                exposure=2,
            )
            rendered.append(board)
            print(board["id"], case["source"]["title"], change(observation), flush=True)
        sheet(
            iso,
            [(r["id"], r["board"]) for r in rendered if iso in r["id"]],
            (
                "Noisy Malvar",
                LABELS["aligned"],
                LABELS["local"],
                LABELS["tangent_pool"],
                LABELS["same_support_uniform"],
                "Exact GT",
            ),
        )
    write_json(
        local / "result.json",
        {
            "evaluation": held_ref,
            "driver": reference(__file__),
            "boards": rendered,
            "chart": plot(held),
            "scope": "Extremes of paired false-line projection versus the equal-RMS uniform arm, selected by source with the most extreme redraw.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scope", choices=("cameras", "synthetic"))
    (camera if parser.parse_args().scope == "cameras" else synthetic)()
