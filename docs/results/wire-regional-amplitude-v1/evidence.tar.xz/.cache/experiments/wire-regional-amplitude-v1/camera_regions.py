"""Replay regional amplitude policies on the fixed standing camera crops."""

from pathlib import Path
import sys

import numpy as np
import torch

from regional import LABELS, METHODS, ROOT, compose_regional, fixed_geometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

PREVIOUS = ROOT.with_name("wire-guide-refinement-v1")
sys.path.insert(0, str(PREVIOUS))
from camera_review import native_display, native_png, old_pixels, read_arrays


def render_main():
    torch.set_num_threads(2)
    before = reference(PREVIOUS / "camera-v2/result.json")
    donor_ref = reference(PREVIOUS / "camera-donors/result.json")
    raw = read_json(checked(before))
    older = read_json(checked(donor_ref))
    assert older["main"] == before
    donors = {row["id"]: row for row in older["rows"]}
    directory = ROOT / "standing"
    directory.mkdir()
    ancestor = reference(ROOT.with_name("wire-segment-support-v1") / "standing-bound/result.json")
    baseline = {r["id"]: r for r in read_json(checked(ancestor))["rows"]}
    records = []
    for row in raw["rows"]:
        name = row["id"]
        donor = donors.get(name)
        old = baseline[name]
        assert old["input"] == row["input"] and old["parent"] == row["predictions_parent"]
        source = read_arrays(row["input"])
        parent = np.load(checked(row["predictions_parent"]), allow_pickle=False)
        x, y, w, h = row["fit_in_context"]
        cut = np.s_[..., y : y + h, x : x + w]
        cells = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
        data = {k: source[k][0] for k in ("colors", "wb", "matrix")} | {
            "packed": source["packed"][cells]
        }
        prior = donor["evidence"] if donor else row["proposals"]
        correction = {k: np.zeros_like(parent) for k in METHODS}
        details = []
        for candidate in prior:
            guide = fixed_geometry(candidate["geometry"], quantize=False)
            outputs, receipts = compose_regional(data, parent[cut], guide, row["noise"])
            for method in METHODS:
                correction[method][cut] += outputs[method] - parent[cut]
            details.append({"geometry": guide, "scores": receipts[0]})
        displays = []
        roi = row["ROI_xywh"]
        for v in old["displays"]:
            exposure = v["exposure"]
            comparison = old_pixels(v["board"])

            panels = [
                (k, comparison[k])
                for k in (
                    "ISO6400 camera JPEG",
                    "Noisy (Malvar)",
                    "V120 EMA",
                    "Aligned control",
                    "Corpus 100k + earlier donor",
                )
                if k in comparison
            ]
            rendered = {
                m: native_display(parent + value, source, roi, exposure)
                for m, value in correction.items()
            }
            for m in ("global_hard", "local"):
                np.testing.assert_array_equal(
                    comparison[LABELS[m]], rendered[m], err_msg=f"{name} {m}"
                )
            panels.extend((LABELS[m], rendered[m]) for m in METHODS)
            panels.extend(
                (k, comparison[k])
                for k in ("ISO100 AHD reference", "ISO100 camera JPEG")
                if k in comparison
            )
            board = native_png(directory / f"{name}-x{exposure:g}.png", panels)
            displays.append({"exposure": exposure, "board": board})
        a, b, c, d = roi
        pick = np.s_[..., b : b + d, a : a + c]
        rgb = {
            m: float(np.sqrt(np.mean(v[pick].astype(float) ** 2)) * 65535)
            for m, v in correction.items()
        }
        loc = correction["tangent_pool"][pick].astype(float)
        uni = correction["same_support_uniform"][pick].astype(float)
        position_rms = float(np.sqrt(np.mean((loc - uni) ** 2)) * 65535)
        records.append(
            {
                "pool_minus_uniform_DN16": position_rms,
                "id": name,
                "input": row["input"],
                "raw_source": row["source"],
                "condition": row["noise"],
                "ROI_xywh": roi,
                "native_box": row["native_box"],
                "fit_in_context": row["fit_in_context"],
                "frozen_input_bank": "exterior donor" if donor else "query",
                "parent": row["predictions_parent"],
                "evidence": details,
                "rgb_RMS_DN16": rgb,
                "displays": displays,
            }
        )
        print(name, rgb, flush=True)
    assert len(records) == 8
    write_json(
        directory / "result.json",
        {
            "driver": reference(__file__),
            "previous_query": before,
            "previous_left_donors": donor_ref,
            "previous_execution": ancestor,
            "engine": reference(ROOT / "regional.py"),
            "window_kernel": reference(Path("src/demosaic/wire_segment_support.py")),
            "amplitude_kernel": reference(Path("src/demosaic/regional_wire_amplitude.py")),
            "aligned": raw["matched_parent"],
            "rows": records,
            "scope": "Fixed noisy-only query nominations and the archived left donor pair. Same observed crops, radiometric references and fixed circular apertures. No new candidate discovery.",
        },
    )


if __name__ == "__main__":
    render_main()
