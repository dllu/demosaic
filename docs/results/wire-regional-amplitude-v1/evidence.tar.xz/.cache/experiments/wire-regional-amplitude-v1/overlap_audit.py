"""Check both photo panels against the actual excluded IDs and full cache hashes."""

import json
from pathlib import Path

from capture_regions import source_ids

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PANELS = {
    key: Path("/mnt/external/demosaic") / experiment / "fresh/panel.json"
    for key, experiment in (
        ("development", "wire-segment-support-v1"),
        ("held_out", "wire-regional-amplitude-v1"),
    )
}


def main():
    observed = {}
    for key, path in PANELS.items():
        source = reference(path)
        panel = read_json(checked(source))
        plan = read_json(checked(panel["plan"]))
        cache = {r["source"]["cache_sha256"] for r in panel["rows"]}
        ids = {r["source"]["id"] for r in panel["rows"]}
        exclusions = []
        # The last item is the candidate pool itself. The preceding item is the training manifest.
        for binding in plan["source_exclusions"][:-1]:
            doc = checked(binding)
            pool = set()
            if doc.suffix == ".jsonl":
                with doc.open() as stream:
                    for line in stream:
                        source_ids(json.loads(line), pool)
            else:
                source_ids(read_json(doc), pool)
            exclusions.append(
                {
                    "binding": binding,
                    "identities": len(pool),
                    "id_overlap": sorted(ids & pool),
                    "cache_hash_overlap": sorted(cache & pool),
                }
            )
        assert len(ids) == len(cache) == 48
        observed[key] = {
            "panel": source,
            "checked": exclusions,
            "disjoint": all(not (r["id_overlap"] or r["cache_hash_overlap"]) for r in exclusions),
        }
        print(
            key,
            [
                (
                    Path(r["binding"]["path"]).name,
                    r["identities"],
                    len(r["id_overlap"]),
                    len(r["cache_hash_overlap"]),
                )
                for r in exclusions
            ],
            flush=True,
        )
    write_json(ROOT / "overlap-audit.json", {"driver": reference(__file__), "panels": observed})
    assert all(r["disjoint"] for r in observed.values())


if __name__ == "__main__":
    main()
