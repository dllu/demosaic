"""Freeze source-disjoint continuation/double-gap observations on external scratch."""

import argparse
from collections import Counter
from dataclasses import replace
import json
import math
from pathlib import Path
import random

import numpy as np
import torch
from train_local_paired_continuation import BOX, FORWARD_ARGS, PROFILES, clean_crop, wire_pair

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe
from demosaic.scene_training_data import scene_seed

EXPERIMENTS = Path(".cache/experiments").absolute()
PREVIOUS = EXPERIMENTS / "green-covariance-refit-v1/plan.json"
SEED = 202611191725
COUNT = 48
ROLES = ("continuing", "partial-break", "absent-in-aperture", "exact-flat")


def source_ids(obj, values):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if (
                key in ("id", "source_id", "commons_id")
                and isinstance(value, str)
                and len(value) == 40
            ):
                values.add(value)
            elif (
                key in ("cache_sha256", "image_sha256")
                and isinstance(value, str)
                and len(value) == 64
            ):
                values.add(value)
            elif isinstance(value, (dict, list)):
                source_ids(value, values)
    elif isinstance(obj, list):
        for value in obj:
            source_ids(value, values)


def choose():
    controls = reference(PREVIOUS)
    earlier = read_json(checked(controls))
    references = [
        controls,
        earlier["rejected_full427"],
        earlier["excluded_prior_wires"],
        reference(EXPERIMENTS / "local-continuing-wire-v1/double-gap-inputs/panel.json"),
        reference(EXPERIMENTS / "local-wire-response-v1/wire-redraw-inputs/panel.json"),
        reference(EXPERIMENTS / "local-band-mixture-v1/plan.json"),
        reference("/mnt/external/demosaic/wire-blind-spot-v1/fresh/plan.json"),
        reference("/mnt/external/demosaic/wire-guide-refinement-v1/fresh/plan.json"),
        reference("/mnt/external/demosaic/wire-segment-support-v1/fresh/plan.json"),
    ]
    excluded = set()
    for ref in references:
        source_ids(read_json(checked(ref)), excluded)
    with checked(earlier["training_manifest"]).open() as stream:
        for line in stream:
            source_ids(json.loads(line), excluded)
    with checked(earlier["source_pool"]).open() as stream:
        candidates = [
            row
            for line in stream
            if (row := json.loads(line))["split"] == "val"
            and min(row["shape"][:2]) >= 256
            and row["id"] not in excluded
            and row["cache_sha256"] not in excluded
            and row["bin_factor"] == 4
        ]
    candidates.sort(key=lambda row: row["id"])
    assert len(candidates) > COUNT
    selection = random.Random(SEED).sample(candidates, COUNT)
    assert len({r["id"] for r in selection}) == len({r["cache_sha256"] for r in selection}) == COUNT
    return selection, references + [earlier["training_manifest"], earlier["source_pool"]]


def textures(photo, rng, *, staggered, step, tinted):
    _, _, old = wire_pair(photo, rng)
    # Place a weaker test carrier across a continuing competing direction.
    angles = old["angles"][::-1]
    widths = old["widths"][::-1]
    periods = old["periods"][::-1]
    phases = old["phases"][::-1]
    strengths = old["strengths"][::-1]
    side = photo.shape[-1]
    center = (rng.uniform(-8, 8), rng.uniform(-8, 8))
    axes = (rng.uniform(29, 37), rng.uniform(46, 54))
    pos = torch.arange(side) - (side - 1) / 2
    y, x = torch.meshgrid(pos, pos, indexing="ij")

    def normal_tangent(theta, xx, yy):
        c, s = math.cos(theta), math.sin(theta)
        return c * xx + s * yy, -s * xx + c * yy

    normal, tangent = normal_tangent(angles[0], x - center[0], y - center[1])
    radius = torch.hypot(normal / axes[0], tangent / axes[1])
    outside = ((radius - 1) * 2.5).clamp(0, 1)
    phases_at_sites = [
        normal_tangent(a, x, y)[0] / period + p
        for a, period, p in zip(angles, periods, phases, strict=True)
    ]
    carriers = [
        torch.exp(-0.5 * ((u - u.round()) / w).square()) - math.sqrt(math.tau) * w
        for u, w in zip(phases_at_sites, widths, strict=True)
    ]
    tint = torch.tensor(old["tint"] if tinted else [1.0, 1.0, 1.0])[:, None, None]
    majority = 0.05 + 0.75 * photo + strengths[1] * carriers[1]
    step_angle = (angles[0] + rng.uniform(0.25, 1.1)) % math.tau
    step_offset = rng.uniform(-11, 11)
    if step:
        edge, _ = normal_tangent(step_angle, x - center[0], y - center[1])
        majority += 0.042 * torch.tanh((edge - step_offset) / 1.4)
    full = majority + strengths[0] * carriers[0] * tint
    absent = majority + strengths[0] * carriers[0] * tint * outside
    offset = rng.choice((-1, 1)) * rng.uniform(9, 16)
    if staggered:
        phase = phases_at_sites[0]
        offset = torch.where(phase.round().remainder(2) == 0, offset, -offset)
    half_gap = rng.uniform(8, 15)
    cut = 1 - ((abs(tangent - offset) - half_gap) / 3).clamp(0, 1)
    missing = cut * (1 - outside)
    partial = full + (absent - full) * cut
    flat = (
        photo[:, side // 2 : side // 2 + 1, side // 2 : side // 2 + 1].expand_as(photo).contiguous()
    )
    truth = {
        "inside": radius < 1,
        "preserved": (radius < 1) & (missing == 0),
        "missing": (radius < 1) & (missing == 1),
    }
    assert torch.equal(partial[:, truth["preserved"]], full[:, truth["preserved"]])
    assert torch.equal(partial[:, truth["missing"]], absent[:, truth["missing"]])
    assert all(f.sum() > 100 for f in truth.values())
    geometry = {
        "angles": angles,
        "widths": widths,
        "periods": periods,
        "phases": phases,
        "strengths": strengths,
        "gap_center": center,
        "gap_axes": axes,
        "gap_angle": angles[0],
        "boundary": "staggered wire breaks" if staggered else "shared strip break",
        "step_present": step,
        "step_angle": step_angle,
        "step_offset": step_offset,
        "tinted": tinted,
        "tint": tint.flatten().tolist(),
    }
    return (full, partial, absent, flat), geometry, truth


def capture(root):
    torch.set_num_threads(2)
    chosen, source_refs = choose()
    root.mkdir(parents=True)
    sequence = [
        (iso, pattern)
        for iso in ("ISO400", "ISO6400")
        for pattern in PATTERNS
        for _ in range(COUNT // 8)
    ]
    random.Random(SEED + 1).shuffle(sequence)
    plan = root / "plan.json"
    write_json(
        plan,
        {
            "id": root.name,
            "seed": SEED,
            "source_exclusions": source_refs,
            "roles": ROLES,
            "source_schedule": [
                {"source": photo, "iso": iso, "pattern": cfa}
                for photo, (iso, cfa) in zip(chosen, sequence, strict=True)
            ],
            "driver": reference(__file__),
        },
    )
    rows = []
    for index, (source, (iso, pattern)) in enumerate(zip(chosen, sequence, strict=True)):
        rng = random.Random(scene_seed(SEED, index, "background"))
        patch, crop = clean_crop(source, rng)
        scenes, geometry, support = textures(
            patch,
            rng,
            staggered=bool(index % 2),
            step=bool((index // 2) % 2),
            tinted=bool((index // 4) % 2),
        )
        shot, read = PROFILES[iso]
        profile = {"shot": shot, "read": read, "exposure": 0.33, "iso": iso}
        camera = replace(
            sample_scene_recipe(scene_seed(SEED, index, "camera")),
            pattern=pattern,
            black=0.03,
            shot=shot,
            read=read,
            exposure=profile["exposure"],
        )
        saved = []
        clean = None
        for redraw in range(2):
            seeds = {role: scene_seed(SEED, index, f"{redraw}:{role}") for role in ROLES}
            captures = [
                observe_scene(image, replace(camera, noise_seed=seeds[role])).crops([BOX])
                for image, role in zip(scenes, ROLES, strict=True)
            ]
            arrays = {
                key: torch.cat([r[key] for r in captures]).numpy()
                for key in (*FORWARD_ARGS, "target")
            }
            for key in ("colors", "wb", "matrix"):
                assert np.all(arrays[key] == arrays[key][0])
                arrays[key] = arrays[key][0]
            identity = fingerprint(arrays["target"])
            assert clean in (None, identity)
            clean = identity
            path = root / f"{index:02d}-{redraw}.npz"
            with path.open("xb") as handle:
                np.savez(handle, **arrays, **{k: v.numpy() for k, v in support.items()})
            saved.append(
                {
                    "arrays": reference(path),
                    "packed": fingerprint(arrays["packed"]),
                    "role_seeds": seeds,
                }
            )
        rows.append(
            {
                "source": source,
                "index": index,
                "crop": crop,
                "CFA": pattern,
                "geometry": geometry,
                "profile": profile,
                "camera": vars(camera),
                "draws": saved,
                "clean": clean,
            }
        )
        if index % 8 == 7:
            print(index + 1, flush=True)
    assert set(Counter((r["CFA"], r["profile"]["iso"]) for r in rows).values()) == {COUNT // 8}
    seeds = [seed for r in rows for d in r["draws"] for seed in d["role_seeds"].values()]
    assert len(set(seeds)) == len(seeds) == COUNT * len(ROLES) * 2
    write_json(
        root / "panel.json",
        {
            "plan": reference(plan),
            "driver": reference(__file__),
            "rows": rows,
            "roles": ROLES,
            "scope": "48 held-out photo backgrounds with independent weak-carrier breaks and explicit competing structure.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    capture(parser.parse_args().root.absolute())
