"""Publish audited weak-wire amplitude metrics and unchanged native PNG cells."""

from pathlib import Path
import os
import shutil
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
EXTERNAL = Path("/mnt/external/demosaic")
IMAGES = REPO / "docs/images" / ROOT.name
OUT = REPO / "docs/results" / ROOT.name
STAGED_BUNDLE = EXTERNAL / ROOT.name / "publication-evidence.tar.xz"
RECEIPTS = {
    "development": "development/result.json",
    "held_out": "held_out/result.json",
    "development_limit": "development/limit-audit.json",
    "held_out_limit": "held_out/limit-audit.json",
    "camera": "standing/result.json",
    "camera_limit": "standing-limit/result.json",
    "native": "native/result.json",
    "native_limit": "limit-native/result.json",
    "overlap_audit": "overlap-audit.json",
    "viewing": "viewing.json",
}


def cells(board):
    with Image.open(checked(board["image"])) as f:
        image = np.asarray(f.convert("RGB"))
    values = {}
    for cell in board["panels"]:
        x, y, w, h = cell["png_xywh"]
        assert (
            (w, h) == (160, 160)
            and 0 <= x
            and 0 <= y
            and y + h <= image.shape[0]
            and x + w <= image.shape[1]
        )
        values[cell.get("name", cell.get("label"))] = image[y : y + h, x : x + w]
    return values


def keep(board, folder):
    src = checked(board["image"])
    dest = IMAGES / folder / src.name
    shutil.copyfile(src, dest)
    assert reference(dest)["sha256"] == board["image"]["sha256"]
    return board | {"image": board["image"] | {"path": str(dest.relative_to(IMAGES))}}


def publish_native(results, refs):
    held, asset, camera, view = (results[k] for k in ("held_out", "native", "camera", "viewing"))
    assert asset["evaluation"] == refs["held_out"] and view["exact"] == refs["native"]
    assert view["camera"] == refs["camera"] and view["chart"] == asset["chart"]
    extra, cap = (results[k] for k in ("native_limit", "camera_limit"))
    assert (
        extra["cap_evaluation"] == refs["held_out_limit"]
        and view["exact_limit"] == refs["native_limit"]
    )
    assert cap["previous"] == refs["camera"] and view["camera_limit"] == refs["camera_limit"]
    assert cap["checkpoint"] == camera["aligned"] and len(cap["rows"]) == 8
    assert len(extra["boards"]) == 2 and sum(len(r["displays"]) for r in cap["rows"]) == 12
    assert len(asset["boards"]) == 4 and len(camera["rows"]) == 8
    assert sum(len(row["displays"]) for row in camera["rows"]) == 12
    IMAGES.mkdir()
    for folder in ("standing", "exact", "standing-limit"):
        (IMAGES / folder).mkdir()
    exact = []
    for case in asset["boards"] + extra["boards"]:
        a, b = cells(case["board"]), cells(case["triplet"])
        method = "Full exterior cap" if "cap_scores" in case else "Along-wire pool"
        assert list(b) == ["Noisy Malvar", method, "Exact GT"]
        assert all(np.array_equal(a[k], v) for k, v in b.items())
        assert view["exact_notes"][case["id"]]["images"] == [
            case[k]["image"] for k in ("board", "triplet")
        ]
        exact.append(
            case
            | {k: keep(case[k], "exact") for k in ("board", "triplet")}
            | {"inspection": view["exact_notes"][case["id"]]["note"]}
        )
    standing = []
    for row in camera["rows"]:
        note = view["camera_notes"][row["id"]]
        assert note["images"] == [r["board"]["image"] for r in row["displays"]]
        displays = []
        for render in row["displays"]:
            c = cells(render["board"])
            assert {
                "Noisy (Malvar)",
                "V120 EMA",
                "Aligned control",
                "ISO100 AHD reference",
            } <= c.keys()
            if row["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= c.keys()
            displays.append(render | {"board": keep(render["board"], "standing")})
        standing.append(row | {"displays": displays, "inspection": note["note"]})
    widened = []
    for row in cap["rows"]:
        assert view["camera_cap_images"][row["id"]] == [
            d["board"]["image"] for d in row["displays"]
        ]
        for d in row["displays"]:
            names = cells(d["board"])
            assert {
                "Noisy (Malvar)",
                "V120 EMA",
                "Aligned control",
                "ISO100 AHD reference",
                "Full exterior cap",
            } <= names.keys()
            if row["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= names.keys()
        widened.append(
            row
            | {
                "displays": [
                    d | {"board": keep(d["board"], "standing-limit")} for d in row["displays"]
                ]
            }
        )
    plot = checked(asset["chart"])
    shutil.copyfile(plot, IMAGES / plot.name)
    path = IMAGES / "manifest.json"
    write_json(
        path,
        {
            "exact": exact,
            "standing": standing,
            "standing_limit": widened,
            "chart": asset["chart"] | {"path": plot.name},
            "weights": held["checkpoints"],
            "binding": refs,
        },
    )
    return reference(path)


def main():
    refs = {k: reference(ROOT / path) for k, path in RECEIPTS.items()}
    result = {k: read_json(checked(v)) for k, v in refs.items()}
    dev, held, cam, overlap = (
        result[k] for k in ("development", "held_out", "camera", "overlap_audit")
    )
    parents = {}
    source_plans = []
    for index, value in (("development", dev), ("held_out", held)):
        boundary = result[index + "_limit"]
        assert boundary["study"] == refs[index] and len(boundary["isolation"]) == 4
        assert sum(len(test["tests"]) for test in boundary["isolation"]) == 8
        parent = read_json(checked(value["parents"]))
        panel = read_json(checked(value["panel"]))
        asserted = overlap["panels"][index]
        assert asserted["disjoint"] and asserted["panel"] == value["panel"]
        assert (
            parent["panel"] == value["panel"] and len(panel["rows"]) == len(parent["cases"]) == 48
        )
        assert value["checkpoints"] == parent["checkpoints"] == held["checkpoints"]
        parents[index] = parent
        source_plans.append(panel["plan"])
    assert cam["aligned"] == held["checkpoints"]["aligned"]
    assert all(dev[k] == held[k] == cam[k] for k in ("engine", "window_kernel", "amplitude_kernel"))
    for ref in (
        *held["checkpoints"].values(),
        held["engine"],
        held["window_kernel"],
        held["amplitude_kernel"],
    ):
        checked(ref)

    manifest = publish_native(result, refs)
    OUT.mkdir()
    bundle = OUT / "evidence.tar.xz"
    older = ROOT.with_name("wire-segment-support-v1")
    blind = ROOT.with_name("wire-blind-spot-v1")
    guide = ROOT.with_name("wire-guide-refinement-v1")
    drivers = [
        *[
            ROOT / name
            for name in (
                "regional.py",
                "capture_regions.py",
                "replay_parents.py",
                "evaluate_regions.py",
                "camera_regions.py",
                "camera_limit.py",
                "cap_native.py",
                "limit_audit.py",
                "overlap_audit.py",
                "review_assets.py",
                "record_views.py",
                "exact-view-notes.json",
                "publish.py",
            )
        ],
        older / "segment.py",
        older / "evaluate_segments.py",
        guide / "camera_review.py",
        guide / "evaluate.py",
        blind / "diagnose.py",
        blind / "estimated_phase.py",
        blind / "verifier.py",
        blind / "deliver.py",
        ROOT.with_name("paired-luminance-detail-v1") / "render.py",
        REPO / "src/demosaic/wire_segment_support.py",
        REPO / "src/demosaic/regional_wire_amplitude.py",
        REPO / "tests/test_regional_wire_amplitude.py",
        REPO / "scripts/report_scene_wave_guides.py",
        REPO / "scripts/train_local_paired_continuation.py",
        REPO / "configs/gfx-qualitative-20231231.json",
        REPO / "configs/gfx-green-mesh-20231231.json",
    ]
    original = [
        dev["panel"],
        held["panel"],
        dev["parents"],
        held["parents"],
        *source_plans,
        cam["previous_execution"],
        cam["previous_query"],
        cam["previous_left_donors"],
    ]
    with tarfile.open(STAGED_BUNDLE, "x:xz", preset=4) as f:
        inputs = [*refs.values(), *original, manifest, *(reference(p) for p in drivers)]
        for item in {r["path"]: r for r in inputs}.values():
            p = checked(item)
            name = (
                p.relative_to(REPO)
                if p.is_relative_to(REPO)
                else Path("external") / p.relative_to(EXTERNAL)
            )
            f.add(p, arcname=name)
    temporary = OUT / ".evidence.tar.xz"
    try:
        with STAGED_BUNDLE.open("rb") as src, temporary.open("xb") as dest:
            shutil.copyfileobj(src, dest)
            dest.flush()
            os.fsync(dest.fileno())
        assert reference(temporary)["sha256"] == reference(STAGED_BUNDLE)["sha256"]
        os.link(temporary, bundle)
    finally:
        temporary.unlink(missing_ok=True)
    scope = {
        "model": "Frozen EMA weights",
        "development_photos": 48,
        "independent_photos": 48,
        "full427_known_unseen": "Outside this component inference study",
        "signed_amplitude": "Fixed support with supplied geometry",
        "native_inspection": True,
    }
    write_json(
        OUT / "publication.json",
        {
            "study": ROOT.name,
            "scope": scope,
            "weights": held["checkpoints"],
            "foundation_corpus100k": parents["held_out"]["base_corpus_100k"],
            "receipts": refs,
            "panel": held["panel"],
            "parent_replay": held["parents"],
            "manifest": manifest,
            "evidence": reference(bundle),
            "timings": {
                "FP32_parent": parents["held_out"]["seconds"],
                "development_CPU": dev["seconds_including_wait"],
                "held_out_CPU_with_wait": held["seconds_including_wait"],
            },
            "development": dev["summary"],
            "held_out": held["summary"],
            "held_out_subgroups": held["subgroups"],
            "widened_cap": result["held_out_limit"]["summary"],
            "camera_cap_DN16": {c["id"]: c["change_DN16"] for c in result["camera_limit"]["rows"]},
            "camera": {
                c["id"]: {
                    "RGB_RMS_DN16": c["rgb_RMS_DN16"],
                    "pool_minus_uniform_DN16": c["pool_minus_uniform_DN16"],
                }
                for c in cam["rows"]
            },
        },
    )
    print("Published six native triplets, 24 camera boards and two matched panels", flush=True)


if __name__ == "__main__":
    main()
