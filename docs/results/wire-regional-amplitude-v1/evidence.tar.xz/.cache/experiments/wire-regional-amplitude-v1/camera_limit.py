"""Replay both amplitude caps with the same verified camera supports."""

from pathlib import Path
import sys

import numpy as np
import torch

from limit_audit import deliver_at_limit
from evaluate_regions import ROOT, read_data
from review_assets import sheet
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0, str(ROOT.with_name("wire-guide-refinement-v1")))
from camera_review import native_display, native_png, old_pixels


def run():
    torch.set_num_threads(2)
    record = reference(ROOT / "standing/result.json")
    frozen = read_json(checked(record))
    destination = ROOT / "standing-limit"
    destination.mkdir()
    rows = []
    for row in frozen["rows"]:
        prior = read_data(row["input"])
        base = np.load(checked(row["parent"]), allow_pickle=False)
        x, y, w, h = row["fit_in_context"]
        region = np.s_[..., y : y + h, x : x + w]
        crop = base[region]
        data = {k: prior[k][0] for k in ("colors", "wb", "matrix")}
        correction = {limit: np.zeros_like(base) for limit in (0.5, 1.0)}
        for hypothesis in row["evidence"]:
            for k in correction:
                results = deliver_at_limit(
                    crop, data, hypothesis["geometry"], [hypothesis["scores"]], k
                )
                correction[k][region] += results["tangent_pool"] - crop
        roi = row["ROI_xywh"]
        x, y, w, h = roi
        area = np.s_[..., y : y + h, x : x + w]
        difference = correction[1.0][area].astype(float) - correction[0.5][area]
        rms = float(np.sqrt(np.mean(np.square(difference))) * 65535)
        displays = []
        for variant in row["displays"]:
            exposure = variant["exposure"]
            saved = old_pixels(variant["board"])
            half = native_display(base + correction[0.5], prior, roi, exposure)
            np.testing.assert_array_equal(half, saved["Along-wire pool"])
            full = native_display(base + correction[1.0], prior, roi, exposure)
            labels = (
                "ISO6400 camera JPEG",
                "Noisy (Malvar)",
                "V120 EMA",
                "Aligned control",
                "Directional windows",
                "Along-wire pool",
            )
            columns = [(k, saved[k]) for k in labels if k in saved] + [("Full exterior cap", full)]
            columns.extend(
                (k, saved[k]) for k in ("ISO100 AHD reference", "ISO100 camera JPEG") if k in saved
            )
            board = native_png(destination / f"{row['id']}-cap-x{exposure:g}.png", columns)
            displays.append({"exposure": exposure, "board": board})
        rows.append(
            {
                "id": row["id"],
                "native_ROI": roi,
                "raw": row["raw_source"],
                "noise": row["condition"],
                "half_cap_RMS_DN16_vs_aligned": row["rgb_RMS_DN16"]["tangent_pool"],
                "full_cap_RMS_DN16_vs_aligned": float(
                    np.sqrt(np.mean(np.square(correction[1.0][area].astype(float)))) * 65535
                ),
                "change_DN16": rms,
                "displays": displays,
            }
        )
        print(row["id"], round(rms, 5), flush=True)
    for family in ("main", "mesh"):
        for exp in (4, 16):
            cases = [
                (r["id"], d["board"])
                for r in rows
                if r["id"].startswith(family)
                for d in r["displays"]
                if d["exposure"] == exp
            ]
            if cases:
                sheet(
                    f"cap-{family}-x{exp}",
                    cases,
                    (
                        "Aligned control",
                        "Along-wire pool",
                        "Full exterior cap",
                        "ISO100 AHD reference",
                    ),
                )
    write_json(
        destination / "result.json",
        {
            "previous": record,
            "driver": reference(__file__),
            "limit_driver": reference(ROOT / "limit_audit.py"),
            "checkpoint": frozen["aligned"],
            "scope": "Same direction, spatial support and measurement. Only the maximum possible added contrast changes. Both ISO100 references remain visual.",
            "rows": rows,
        },
    )


if __name__ == "__main__":
    run()
