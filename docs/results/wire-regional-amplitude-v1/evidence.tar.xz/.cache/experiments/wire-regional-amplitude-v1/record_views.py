"""Attach actual inspection notes to the exact native boards reviewed."""

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
CAMERA = {
    "main-overcast-sky-main-overcast-sky": "No candidates. The overcast sky stays smooth in every replay.",
    "main-building-detail-main-building-detail": "The regional fit adds less horizontal contrast. Fine wires and bracing stay soft.",
    "main-foliage-main-foliage": "Leaf silhouettes and soft subdivisions match the aligned result.",
    "main-chain-link-fence-main-chain-link-fence": "The coarse lattice stays coherent. Local contrast changes are subtle and no new crossings stand out.",
    "mesh-nominal-fine-green-mesh-left": "The nominal left stays mottled beside the vertical post. No connected new lattice is visible.",
    "mesh-nominal-fine-green-mesh-right": "A central patch with both directions remains visible. Its spacing looks too regular and fine crossings still disappear outside the patch.",
    "mesh-profile3879-fine-green-mesh-left": "Faint lower diagonals persist. Small amplitude changes leave the crossing gaps visible.",
    "mesh-profile3879-fine-green-mesh-right": "The transferred profile shows the clearest diagonals. Pooling raises contrast slightly near the central patch, with remaining missing crossings.",
}


def record(exact_notes):
    e, c = reference(ROOT / "native/result.json"), reference(ROOT / "standing/result.json")
    exact, camera = read_json(checked(e)), read_json(checked(c))
    er, cr = (
        reference(ROOT / "limit-native/result.json"),
        reference(ROOT / "standing-limit/result.json"),
    )
    extended, cap = read_json(checked(er)), read_json(checked(cr))
    all_exact = exact["boards"] + extended["boards"]
    assert set(exact_notes) == {r["id"] for r in all_exact}
    assert set(CAMERA) == {r["id"] for r in camera["rows"]}
    write_json(
        ROOT / "viewing.json",
        {
            "exact": e,
            "camera": c,
            "exact_limit": er,
            "camera_limit": cr,
            "chart": exact["chart"],
            "viewed_at_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(
                timespec="seconds"
            ),
            "review_cell_px": 160,
            "both_cab_JPEGs_and_AHD_viewed": True,
            "exact_notes": {
                r["id"]: {
                    "note": exact_notes[r["id"]],
                    "images": [r[k]["image"] for k in ("board", "triplet")],
                }
                for r in all_exact
            },
            "camera_notes": {
                r["id"]: {
                    "note": CAMERA[r["id"]],
                    "images": [d["board"]["image"] for d in r["displays"]],
                }
                for r in camera["rows"]
            },
            "camera_cap_images": {
                r["id"]: [d["board"]["image"] for d in r["displays"]] for r in cap["rows"]
            },
            "camera_cap_note": "All eight cap cases viewed at the configured displays. The extra nominal right correction strengthens the regular patch, with missing left crossings and little visible change on the main scene.",
        },
    )


if __name__ == "__main__":
    record(read_json(ROOT / "exact-view-notes.json"))
