"""Compare amplitude policies on frozen parents and two photo panels."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from regional import METHODS, ROOT, compose_regional
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from demosaic.prediction_archive import fingerprint

SEGMENT = ROOT.with_name("wire-segment-support-v1")
sys.path.insert(0, str(SEGMENT))
from evaluate_segments import geometry_row, read_data, score, validate_targets

DATA_ROOT = Path("/mnt/external/demosaic")
ATTENUATIONS = (0.25, 0.5, 0.75, 1.0)
COMPARISONS = (
    ("regional_mean", "local"),
    ("regional_reciprocal", "regional_mean"),
    ("regional_reciprocal", "local"),
    ("tangent_pool", "regional_reciprocal"),
    ("tangent_pool", "local"),
    ("tangent_pool", "same_support_uniform"),
    ("tangent_pool", "aligned"),
    ("same_support_uniform", "local"),
)


def data_root(phase):
    return DATA_ROOT / (SEGMENT.name if phase == "development" else ROOT.name)


def await_case(directory, index, count, owner):
    # The next input begins only after both preceding archives have been closed.
    next_file = (
        directory / f"{index + 1:02d}-0.npz" if index + 1 < count else directory / "completed.json"
    )
    while not next_file.exists():
        if not owner_live(owner) and not (directory / "completed.json").exists():
            raise RuntimeError(f"Parent replay exited before both redraws of source {index}")
        time.sleep(2)
    return [reference(directory / f"{index:02d}-{i}.npz") for i in (0, 1)]


def draw_scores(case, draw, model):
    data = read_data(draw["arrays"])
    assert fingerprint(data["packed"]) == draw["packed"]
    assert fingerprint(data["target"]) == case["clean"]
    validate_targets(data)
    parents = read_data(model)
    variants, gates = compose_regional(
        data, parents["aligned"], geometry_row(case), case["profile"]
    )
    predicted = parents | variants
    scores = {key: score(v, parents["aligned"], data) for key, v in predicted.items()}
    matched = ("tangent_pool", "same_support_uniform")
    assert abs(np.subtract(*(scores[m]["partial_all_added_RMS_DN16"] for m in matched))) < 0.003
    curve = {}
    for mode in METHODS:
        base = parents["aligned"]
        delta = predicted[mode].astype(float) - base
        curve[mode] = [
            scores[mode] if strength == 1 else score(base + strength * delta, base, data)
            for strength in ATTENUATIONS
        ]
    return {
        "input": draw["arrays"],
        "parent": model,
        "scores": scores,
        "curve": curve,
        "gates": gates,
    }


def stats(group):
    rng = np.random.default_rng(202611191729)
    names = tuple(group[0]["draws"][0]["scores"])
    keys = tuple(group[0]["draws"][0]["scores"]["aligned"])
    points = np.asarray(
        [
            [
                [np.mean([draw["scores"][m][k] for draw in row["draws"]]) for k in keys]
                for m in names
            ]
            for row in group
        ]
    )
    picks = rng.integers(len(group), size=(6500, len(group)))
    trials = points[picks].mean(1)
    result = {}
    for method, control in COMPARISONS:
        a, b = names.index(method), names.index(control)
        delta = (points[:, a] - points[:, b]).mean(0)
        limits = np.quantile(trials[:, a] - trials[:, b], [0.025, 0.975], axis=0).T
        result[f"{method} versus {control}"] = {
            k: {"delta": float(v), "CI95": p.tolist()}
            for k, v, p in zip(keys, delta, limits, strict=True)
        }
    mean = {
        m: dict(zip(keys, y.tolist(), strict=True))
        for m, y in zip(names, points.mean(0), strict=True)
    }
    curves = {}
    for m in METHODS:
        curves[m] = {
            str(level): {
                k: float(np.mean([d["curve"][m][i][k] for row in group for d in row["draws"]]))
                for k in keys
            }
            for i, level in enumerate(ATTENUATIONS)
        }
    return {"n_photos": len(group), "values": mean, "paired_delta": result, "curves": curves}


def run(phase):
    torch.set_num_threads(2)
    root = data_root(phase)
    panel_ref = reference(root / "fresh/panel.json")
    panel = read_json(checked(panel_ref))
    parent_dir = root / "parents"
    owner = read_json(parent_dir / "owner.json")
    directory = ROOT / phase
    directory.mkdir()
    began = time.monotonic()
    results = []
    for case in panel["rows"]:
        idx = case["index"]
        bindings = await_case(parent_dir, idx, len(panel["rows"]), owner)
        views = [draw_scores(case, raw, p) for raw, p in zip(case["draws"], bindings, strict=True)]
        results.append(
            {
                "index": idx,
                "source": case["source"]["id"],
                "iso": case["profile"]["iso"],
                "step": case["geometry"]["step_present"],
                "tinted": case["geometry"]["tinted"],
                "boundary": case["geometry"]["boundary"],
                "draws": views,
            }
        )
        if (idx + 1) % 8 == 0:
            print(idx + 1, round(time.monotonic() - began, 2), flush=True)
    par = reference(parent_dir / "completed.json")
    parent = read_json(checked(par))
    assert parent["panel"] == panel_ref
    for row, model in zip(results, parent["cases"], strict=True):
        assert row["source"] == model["source"]
        for draw, expected in zip(row["draws"], model["draws"], strict=True):
            assert draw["input"] == expected["input"] and draw["parent"] == expected["outputs"]
    summary = {
        iso: stats([row for row in results if row["iso"] == iso]) for iso in ("ISO400", "ISO6400")
    }
    groups = {
        key: {
            iso: {
                str(v): stats([r for r in results if r["iso"] == iso and r[key] == v])
                for v in sorted({r[key] for r in results if r["iso"] == iso})
            }
            for iso in summary
        }
        for key in ("step", "tinted", "boundary")
    }
    if phase == "development":
        prev = reference(SEGMENT / "evaluation/result.json")
        older = read_json(checked(prev))
        assert older["panel"] == panel_ref and older["parents"] == par
        for row, before in zip(results, older["rows"], strict=True):
            assert row["source"] == before["source"]
            for a, b in zip(row["draws"], before["redraws"], strict=True):
                for m in ("local", "global_hard", "aligned", "v120"):
                    assert a["scores"][m] == b["scores"][m], (row["index"], m)
    else:
        prev = None
    write_json(
        directory / "result.json",
        {
            "phase": phase,
            "panel": panel_ref,
            "parents": par,
            "previous_directional_run": prev,
            "checkpoints": parent["checkpoints"],
            "rows": results,
            "summary": summary,
            "subgroups": groups,
            "engine": reference(ROOT / "regional.py"),
            "window_kernel": reference("src/demosaic/wire_segment_support.py"),
            "amplitude_kernel": reference("src/demosaic/regional_wire_amplitude.py"),
            "driver": reference(__file__),
            "seconds_including_wait": time.monotonic() - began,
            "policy": "Received rounded frequencies and aperture. Same directional support and amplitude cap for all amplitude refits. Actual held-out sample partitions use both parities in the final result.",
        },
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("phase", choices=("development", "held_out"))
    run(p.parse_args().phase)
