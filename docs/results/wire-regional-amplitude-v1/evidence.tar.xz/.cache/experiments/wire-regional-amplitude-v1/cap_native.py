"""Retain ISO6400 exact-target cases for the widened cap diagnostic."""

import numpy as np
import torch

from evaluate_regions import ROOT, geometry_row, read_data
from limit_audit import deliver_at_limit
from report_scene_wave_guides import native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    torch.set_num_threads(2)
    r = reference(ROOT / "held_out/limit-audit.json")
    limit = read_json(checked(r))
    holdout = read_json(checked(limit["study"]))
    panel = read_json(checked(holdout["panel"]))
    directory = ROOT / "limit-native"
    directory.mkdir()
    boards = []
    for kind, metric in (
        ("response", "partial_weak_response_pp"),
        ("false-line", "partial_gap_false_line_DN16"),
    ):

        def change(draw):
            v = draw["scores"]["tangent_pool"]
            return v["full"][metric] - v["half"][metric]

        group = [
            (i, d)
            for i, s in enumerate(limit["rows"])
            if s["iso"] == "ISO6400"
            for d, _ in enumerate(s["draws"])
        ]
        i, d = max(group, key=lambda g: change(limit["rows"][g[0]]["draws"][g[1]]))
        case = panel["rows"][i]
        saved = holdout["rows"][i]["draws"][d]
        data = read_data(saved["input"])
        parent = read_data(saved["parent"])["aligned"]
        fresh = deliver_at_limit(parent, data, geometry_row(case), saved["gates"], 1.0)[
            "tangent_pool"
        ]
        prior = deliver_at_limit(parent, data, geometry_row(case), saved["gates"], 0.5)[
            "tangent_pool"
        ]
        camera = {k: data[k][None] for k in ("colors", "wb", "matrix")} | {
            "packed": data["packed"][1:2]
        }
        record = limit["rows"][i]["draws"][d]
        cells = [noisy_malvar(camera)[0], parent[1], prior[1], fresh[1], data["target"][1]]
        board = native_board(
            directory,
            f"iso6400-cap-{kind}-{i:02d}-draw{d}",
            cells,
            camera,
            {
                "source": case["source"],
                "crop": case["crop"],
                "noise": case["profile"],
                "CFA": case["CFA"],
                "input": saved["input"],
                "weights": holdout["checkpoints"],
                "cap_scores": record["scores"],
                "selected_on": metric,
                "change": change(record),
            },
            labels=(
                "Noisy Malvar",
                "Aligned control",
                "Half exterior cap",
                "Full exterior cap",
                "Exact GT",
            ),
            triplet_indices=(0, 3, 4),
            exposure=2,
        )
        boards.append(board)
        print(board["id"], case["source"]["title"], round(change(record), 5), flush=True)
    write_json(
        directory / "result.json",
        {
            "driver": reference(__file__),
            "cap_evaluation": r,
            "boards": boards,
            "scope": "Two ISO6400 redraws chosen for the largest pointwise response gain and the largest increase in false projection.",
        },
    )


if __name__ == "__main__":
    main()
