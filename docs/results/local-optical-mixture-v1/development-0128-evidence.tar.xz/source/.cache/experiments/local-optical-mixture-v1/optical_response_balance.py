"""Compare false-detail costs at a response calibrated on separate optical sources."""

import numpy as np

FIELDS = (
    "sharp_normalized_fundamental_response",
    "fundamental_response",
    "gap_continuing_strong_RMS_DN16",
    "fundamental_false_RMS_DN16",
    "exact_flat_RMS_DN16",
)
RESPONSE = FIELDS[0]
LINEAR = frozenset(FIELDS[:2])
BLUR = "0.85"


def coefficients(parent, updates, measure):
    """Keep only the linear response and squared-norm coefficients per source."""
    origin = parent.astype(np.float64)
    zero = measure(origin)
    output = {}
    for label, prediction in updates.items():
        delta = prediction - origin
        plus, minus = measure(origin + delta), measure(origin - delta)
        fit = {}
        for key in FIELDS:
            if key not in zero:
                continue
            c, p, m = zero[key], plus[key], minus[key]
            fit[key] = (
                [c, (p - m) / 2]
                if key in LINEAR
                else [c * c, (p * p - m * m) / 2, (p * p + m * m) / 2 - c * c]
            )
        output[label] = fit
    return output


def evaluate(powers, key, gain):
    data = np.asarray(powers, dtype=np.float64)
    values = data[..., 0] + gain * data[..., 1]
    return values if key in LINEAR else np.sqrt(np.maximum(values + gain * gain * data[..., 2], 0))


def values(rows, label, key, gain):
    return evaluate([r["response_balance"][label][key] for r in rows], key, gain)


def calibration(rows, arms):
    start = float(values(rows, arms[0], RESPONSE, 0).mean())
    np.testing.assert_array_equal(values(rows, arms[0], RESPONSE, 0), values(rows, arms[1], RESPONSE, 0))
    end = {arm: float(values(rows, arm, RESPONSE, 1).mean()) for arm in arms}
    low = max(min(start, q) for q in end.values())
    high = min(max(start, q) for q in end.values())
    common = max((low, high), key=lambda x: abs(x - start))
    target = (start + common) / 2
    if abs(target - start) < 1e-6:
        return {"calibrated": False, "parent": start, "endpoints": end}
    gains = {arm: (target - start) / (end[arm] - start) for arm in arms}
    for arm, gain in gains.items():
        assert 0 < gain <= 1
        assert abs(float(values(rows, arm, RESPONSE, gain).mean()) - target) < 1e-8
    return {
        "calibrated": True, "parent": start, "endpoints": end, "target": target, "gains": gains,
    }


def compare(cal, confirm, arms, source_bootstrap, interval):
    assert len(arms) == 2
    fit = calibration(cal, arms)
    report = {
        "dose_pixels": float(BLUR), "calibration_ids": [r["id"] for r in cal],
        "confirmation_ids": [r["id"] for r in confirm], "fit": fit, "confirmation": {},
    }
    if not fit["calibrated"]:
        return report
    rng = np.random.default_rng(202611200005)
    for key in FIELDS:
        rows = [r for r in confirm if key in r["response_balance"][arms[0]]]
        draw = source_bootstrap(rows, rng)
        metrics = {
            arm: values(rows, arm, key, fit["gains"][arm])[draw].mean(1) for arm in arms
        }
        report["confirmation"][key] = {
            "source_count": len(rows),
            "means": {arm: interval(mean) for arm, mean in metrics.items()},
            "mixed_minus_sharp": interval(metrics[arms[1]] - metrics[arms[0]]),
        }
    return report
