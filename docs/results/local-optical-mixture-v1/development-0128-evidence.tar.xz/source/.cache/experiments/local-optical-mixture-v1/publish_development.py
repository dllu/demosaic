"""Publish the development audit, preserved crops and the response-matching protocol."""

from pathlib import Path
import shutil
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ROOT

REPO = ROOT.parents[2]
DEST = REPO / "docs/results" / ROOT.name
ASSETS = REPO / "docs/assets/local-optical-mixture-development"
STEP = 128


def main():
    result_ref = reference(ARCHIVE / f"development-{STEP:04d}/result.json")
    result = read_json(checked(result_ref))
    audit_ref = reference(ROOT / "training-optics-audit.json")
    audit = read_json(checked(audit_ref))
    assert result["checkpoint_update"] == STEP
    assert result["training_plan"] == audit["plan"] and len(audit["rows"]) == 256
    assert len(result["rows"]) == 32
    assert all(r["id"].startswith("long-") for r in result["rows"])
    ASSETS.mkdir(exist_ok=True)
    native = []
    for row in result["rows"]:
        for view in row["native"]:
            for kind in ("triplet", "board"):
                item = view[kind]["image"]
                src = checked(item)
                dest = ASSETS / src.name
                shutil.copyfile(src, dest)
                assert reference(dest)["sha256"] == item["sha256"]
                native.append({"repo_path": str(dest.relative_to(REPO)), "sha256": item["sha256"]})
    assert len(native) == 4

    scripts = [
        ROOT / name for name in (
            "review_development.py", "measure_training_optics.py", "review_optical.py",
            "optical_response_balance.py", Path(__file__).name,
        )
    ]
    tar_path = DEST / "development-0128-evidence.tar.xz"
    with tarfile.open(tar_path, "x:xz") as tar:
        for path in scripts:
            tar.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
        for item in (result_ref, audit_ref):
            path = checked(item)
            tar.add(path, arcname="receipts/" + path.parent.name + "/" + path.name, recursive=False)
    archive = {"repo_path": str(tar_path.relative_to(REPO)), "sha256": reference(tar_path)["sha256"]}
    write_json(DEST / "development-0128.json", {
        "source": result_ref, "checkpoint_update": STEP, "checkpoints": result["checkpoints"],
        "training_plan": result["training_plan"], "archive": archive, "scope": result["scope"],
        "native_crops": native, "scores": result["scores"],
        "target_audit": {"binding": audit_ref, "stats": audit["summary"]},
        "endpoint_response_balance": {
            "analysis": reference(ROOT / "optical_response_balance.py"),
            "endpoint_driver": reference(ROOT / "review_optical.py"),
            "calibration": "32 existing development cases at sigma 0.85",
            "confirmation": "24 fresh cases at sigma 0.85",
            "parent": "Local 50k", "scope": "diagnostic interpolation along each EMA delta",
        },
    })


if __name__ == "__main__":
    main()
