"""Hold the archived sharp capture and couple photons/read noise across blur doses."""

from dataclasses import replace
import sys
import time
from unittest.mock import patch

from capture_optical import (
    ABSOLUTE, DOSES, LENGTH, PARENTS, ROOT, WireFundamental, arrays, bind_models,
    capture_wide, filtered_observation, run_model, support_for_scoring,
)
import numpy as np
import torch

from demosaic import scene_data
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import variance_map
from demosaic.precision import ieee_fp32
from demosaic.scene_training_data import scene_seed

MODEL = "local50k"
SALT = 202611192344


def generator(seed):
    return torch.Generator(device="cpu").manual_seed(seed)


def adc(signal, black):
    levels = 65535
    return (((signal * (1 - black) + black).clamp(0, 1) * levels).round() / levels - black) / (1 - black)


def sample_roles(case, sharp, blurred):
    fixture = case["fixture"]
    photo = capture_wide.wire_math.decode(fixture["source"], fixture["box"])
    scenes, _, _, _ = capture_wide.wire_math.exact(photo, fixture["geometry"])
    records = [a.copy() for a in blurred]

    for i, (role, rgb) in enumerate(zip(capture_wide.ROLES, scenes, strict=True)):
        recipe = replace(capture_wide.sample_scene_recipe(SALT), **(
            fixture["camera"] | {"noise_seed": case["seeds"][role]}
        ))
        shot, read, black = (
            torch.as_tensor(x, dtype=torch.float32) for x in (recipe.shot, recipe.read, recipe.black)
        )
        # Use the ordinary observation's exact camera + mosaic mean, omitting the draw.
        with patch.object(scene_data, "add_noise", lambda clean, *args, **kwargs: clean):
            rates = torch.stack([
                filtered_observation(rgb, recipe, sigma).packed for sigma in DOSES
            ]).clamp_min(0) / shot
        minimum = rates.amin(0)
        rng = generator(recipe.noise_seed)
        historical = torch.poisson(rates[0][None], generator=rng)[0]
        read_addition = torch.randn((1, *historical.shape), dtype=torch.float32, generator=rng)[0] * read.sqrt()
        observed = adc(historical * shot + read_addition, black)
        query = np.s_[..., 64:192, 64:192]
        np.testing.assert_array_equal(observed[query].numpy(), sharp["packed"][i])
        if i == 1:
            np.testing.assert_array_equal(observed.numpy(), sharp["scene_packed"])
        # Conditional thinning retains the archived marginal. A shared minimum count
        # plus independent Poisson excess supplies each filtered dose's marginal.
        index = fixture["index"] * 4 + i
        common = torch.binomial(historical, minimum / rates[0].clamp_min(1e-12), generator=generator(
            scene_seed(SALT, index, "common-photons")
        ))
        for j, (rate, data) in enumerate(zip(rates[1:], records, strict=True)):
            excess = torch.poisson(rate - minimum, generator=generator(
                scene_seed(SALT, index, f"excess-photons-{j}")
            ))
            noisy = adc((common + excess) * shot + read_addition, black)
            data["packed"][i] = noisy[query].numpy()
            data["variance"][i] = variance_map(noisy, shot, read)[query].numpy()
            if i == 1:
                data["scene_packed"] = noisy.numpy()
    return records


@torch.inference_mode()
def main(stage):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    out = ROOT / "coupled"
    out.mkdir(exist_ok=True)
    start = time.monotonic()
    parent_ref = reference(PARENTS)
    parents = read_json(checked(parent_ref))
    plan_ref = reference(ROOT / "inputs.json")
    plan = read_json(checked(plan_ref))
    capture_wide.ROLES = tuple(read_json(checked(parents["plan"]))["roles"])
    samples = {
        "driver": reference(__file__), "parent_receipt": parent_ref, "standard_input_plan": plan_ref,
        "rng_salt": SALT, "model": MODEL, "checkpoint": plan["checkpoints"][MODEL],
        "dose_sampling": "conditional thinning to minimum shot counts with shared historic read noise",
        "inputs": [],
    }
    manifest = out / "samples.json"
    if stage == "inputs":
        for case, row in zip(parents["rows"], plan["inputs"], strict=True):
            key = case["id"]
            assert key == row["case"]
            sharp = arrays(case["input"])
            blurred = [arrays(row["inputs"][str(sigma)]) for sigma in DOSES[1:]]
            refs = {}
            for sigma, data in zip(DOSES[1:], sample_roles(case, sharp, blurred), strict=True):
                fp = out / f'{key}-sigma-{sigma:g}.npz'
                np.savez(fp, **data)
                refs[str(sigma)] = reference(fp)
            samples["inputs"].append({"id": key, "observations": refs})
            if len(samples["inputs"]) % 8 == 0:
                print("Coupled captures", len(samples["inputs"]), round(time.monotonic() - start, 1), flush=True)
        write_json(manifest, samples)
        return

    original = read_json(checked(plan["scene_results"]))
    original = {row["case"]["id"]: row["predictions"][MODEL] for row in original["offgrid_predictions"]}
    for k, value in samples.items():
        if k != "inputs":
            assert read_json(manifest)[k] == value
    samples = read_json(manifest)

    torch.cuda.set_per_process_memory_fraction(
        min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    model = bind_models({MODEL: samples["checkpoint"]})[MODEL]
    with ieee_fp32():
        rows = []
        for case, record in zip(parents["rows"], samples["inputs"], strict=True):
            key = case["id"]
            assert record["id"] == key
            geometry = case["fixture"]["geometry"]
            sharp = arrays(case["input"])
            support = support_for_scoring(sharp["support"])
            sharp_metric = WireFundamental(sharp | {"support": support}, geometry)
            original_output = np.load(checked(original[key]), allow_pickle=False)
            scores = {str(DOSES[0]): sharp_metric(original_output) | {ABSOLUTE: sharp_metric(original_output)[LENGTH]}}
            for sigma in DOSES[1:]:
                token = str(sigma)
                data = arrays(record["observations"][token])
                metric = WireFundamental(data | {"support": support}, geometry)
                output = run_model(model, MODEL, data, case["profile"])
                assert output.shape == data["target"].shape and np.isfinite(output).all()
                scores[token] = metric(output) | {ABSOLUTE: sharp_metric(output)[LENGTH]}
            rows.append({"id": key, "family": geometry["family"], "scores": scores})
            if len(rows) % 8 == 0:
                print("Coupled scores", len(rows), round(time.monotonic() - start, 1), flush=True)
    assert len(rows) == 32
    write_json(out / "result.json", {
        "samples": reference(manifest), "rows": rows, "seconds": time.monotonic() - start,
    })


if __name__ == "__main__":
    main(sys.argv[1])
