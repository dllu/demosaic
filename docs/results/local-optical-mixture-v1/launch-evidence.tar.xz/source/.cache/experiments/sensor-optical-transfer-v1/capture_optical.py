"""Replay frozen off-grid fixtures under a centered, pre-Bayer optical perturbation."""
from functools import partial
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

os.environ["OPENBLAS_NUM_THREADS"] = "1"
import numpy as np
from scipy.ndimage import gaussian_filter, maximum_filter
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda, load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import observe_scene
from demosaic.scene_inference import load_scene_checkpoint

HERE = Path(__file__).resolve().parent
ROOT = Path("/mnt/external/demosaic") / HERE.name
PARENTS = ROOT.with_name("scene-coherent-fourier-v1") / "transfer/parents.json"
REGIONAL = ROOT.with_name("local-regional-wire-v1") / "review-1024/result.json"
DOSES = (0., .55, .85)
VIEWS = ("long-01", "long-10")
SUPPORT_RADIUS = round(4 * max(DOSES))
BASE = ("v120", "parent")
SCENE = ("local50k", "global-aligned", "regional-aligned")
LABELS = ("Noisy Malvar", "V120", "Corpus 100k", "Local 50k", "Whole core", "Regional", "Exact GT")
ABSOLUTE = "sharp_normalized_fundamental_response"

sys.path[:0] = [str(HERE.with_name(name)) for name in (
    "scene-staggered-phase-v1", "scene-patch-width-v1",
)]
sys.path.append("scripts")
from score_staggered import WireFundamental
from evaluate_wide import LENGTH
import capture_wide
from report_scene_wave_guides import native_board


def arrays(ref):
    with np.load(checked(ref), allow_pickle=False) as stream:
        return {k: stream[k] for k in stream.files}


def filtered_observation(linear, recipe, sigma):
    if sigma:
        blurred = gaussian_filter(linear.numpy(), (0., sigma, sigma), mode="reflect", truncate=4)
        linear = torch.from_numpy(blurred)
    return observe_scene(linear, recipe)


def from_fixture(case, sigma):
    with patch.object(capture_wide, "observe_scene", partial(filtered_observation, sigma=sigma)):
        result, seeds = capture_wide.capture(case["fixture"])
    assert seeds == case["seeds"]
    return result


def support_for_scoring(support):
    near = maximum_filter(support, 2 * SUPPORT_RADIUS + 1, mode="nearest") > 0
    return np.where((support == 0) & near, np.float32(1e-4), support)


def bind_models(checkpoints):
    loaded = {}
    for k, binding in checkpoints.items():
        if k in BASE:
            model, state = load_checkpoint(checked(binding), "cuda", tiled_inference=True)
            assert "ema" in state
        else:
            model, state = load_scene_checkpoint(
                checked(binding), expected_sha256=binding["sha256"], weights="ema"
            )
            model = _stage_tiled_cuda(model, torch.device("cuda"))
        assert state["loaded_sha256"] == binding["sha256"]
        loaded[k] = model.eval().to(memory_format=torch.channels_last)
    return loaded


def run_model(model, k, data, profile):
    (model.base if k in SCENE else model).set_noise(profile["shot"], profile["read"])
    inputs = [
        torch.from_numpy(data[key]).cuda().contiguous(memory_format=torch.channels_last)
        for key in capture_wide.KEYS[:2]
    ]
    inputs.extend(
        torch.from_numpy(data[key]).cuda()[None].expand(len(data["packed"]), *data[key].shape)
        for key in capture_wide.KEYS[2:]
    )
    return model(*inputs).cpu().numpy()


def capture_inputs(parents, plan):
    previous = read_json(checked(parents["plan"]))
    capture_wide.SEED = previous["seed"]
    capture_wide.ROLES = tuple(previous["roles"])
    started = time.monotonic()
    pending = []
    for case in parents["rows"]:
        sharp = arrays(case["input"])
        source = case["fixture"]["source"]
        checked({"path": source["cache"], "sha256": source["cache_sha256"]})
        original = from_fixture(case, 0.)
        assert sharp.keys() == original.keys()
        for key in sharp:
            np.testing.assert_array_equal(original[key], sharp[key], err_msg=f'{case["id"]}/{key}')
        variants = {0.: case["input"]}
        for sigma in DOSES[1:]:
            data = from_fixture(case, sigma)
            for key in ("support", "wb", "colors", "matrix"):
                np.testing.assert_array_equal(data[key], sharp[key])
            # Only the central score region is exactly flat. Its exterior remains photographic.
            np.testing.assert_array_equal(
                data["target"][3, :, 64:192, 64:192], sharp["target"][3, :, 64:192, 64:192]
            )
            assert np.any(data["packed"] != sharp["packed"])
            dest = ROOT / "inputs" / f'{case["id"]}-{sigma:g}.npz'
            np.savez(dest, **data)
            variants[sigma] = reference(dest)
        pending.append({"case": case["id"], "inputs": variants})
        if len(pending) % 8 == 0:
            print("Exact sigma-zero fixture regenerations", len(pending), flush=True)
    assert len(pending) == 32
    plan.update(inputs=pending, seconds_capture=time.monotonic() - started)
    write_json(ROOT / "inputs.json", plan)


@torch.inference_mode()
def main(stage):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    ROOT.mkdir(parents=True, exist_ok=True)
    for folder in ("inputs", "native", "scores"):
        (ROOT / folder).mkdir(exist_ok=True)
    parents_ref = reference(PARENTS)
    regional_ref = reference(REGIONAL)
    parents = read_json(checked(parents_ref))
    regional = read_json(checked(regional_ref))
    checkpoints = parents["weights"] | regional["checkpoints"]
    plan = {
        "driver": reference(__file__), "parents": parents_ref, "scene_results": regional_ref,
        "weights": "EMA", "precision": "CUDA IEEE FP32",
        "checkpoints": checkpoints, "sigmas": DOSES, "gap_erosion_pixels": SUPPORT_RADIUS,
        "input_fields": reference(capture_wide.__file__), "wire_fixture": reference(capture_wide.wire_math.__file__),
        "scorer": reference(sys.modules["evaluate_wide"].__file__),
        "base_scorer": reference(sys.modules["scoring"].__file__),
        "scene_inference": reference(HERE.with_name("local50000-scoped-v1") / "replay.py"),
        "camera_observe": reference(sys.modules[observe_scene.__module__].__file__),
        "display": reference(sys.modules[native_board.__module__].__file__),
        "native_view_ids": VIEWS,
        "preparation": "separable Gaussian, reflect padding, truncate 4 sigma, scene-linear FP32 before camera/ADC/CFA",
        "sampling": "same archived seeds by source and role; changed Poisson mean does not lock the noise realization",
    }
    if stage == "inputs":
        assert not (ROOT / "inputs.json").exists()
        capture_inputs(parents, plan)
        return

    bind = reference(ROOT / "inputs.json")
    prepared = read_json(checked(bind))
    assert all(prepared[k] == json_value(v) for k, v in plan.items())
    assert set(checkpoints) == {*BASE, *SCENE}
    new_refs = {x["case"]["id"]: x for x in regional["offgrid_predictions"]}
    assert len(new_refs) == len(parents["rows"]) == len(prepared["inputs"]) == 32
    assert all(new_refs[case["id"]]["case"] == case for case in parents["rows"])
    torch.cuda.set_per_process_memory_fraction(
        min(1, 10 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    models = bind_models(checkpoints)
    start = time.monotonic()
    rows = []
    with ieee_fp32():
        for case, record in zip(parents["rows"], prepared["inputs"], strict=True):
            ident = case["id"]
            assert record["case"] == ident
            receipt = ROOT / "scores" / f"{ident}.json"
            if receipt.exists():
                stored = read_json(receipt)
                assert stored["input_plan"] == bind
                rows.append(reference(receipt))
                continue
            scores = {}
            geometry = case["fixture"]["geometry"]
            sharp = arrays(case["input"])
            scored_support = support_for_scoring(sharp["support"])
            sharp_metric = WireFundamental(sharp | {"support": scored_support}, geometry)
            native = []
            for sigma in DOSES:
                token = str(sigma)
                data = arrays(record["inputs"][token])
                metric = sharp_metric if sigma == 0 else WireFundamental(
                    data | {"support": scored_support}, geometry
                )
                assert np.array_equal(metric.intact, sharp_metric.intact)
                assert np.array_equal(metric.gap, sharp_metric.gap)
                if sigma == 0:
                    outputs = arrays(case["rgb"]) | {
                        k: np.load(checked(v), allow_pickle=False)
                        for k, v in new_refs[ident]["predictions"].items()
                    }
                    if ident == parents["rows"][0]["id"]:
                        for k, model in models.items():
                            replayed = run_model(model, k, data, case["profile"])
                            np.testing.assert_array_equal(replayed, outputs[k], err_msg=k)
                else:
                    outputs = {k: run_model(models[k], k, data, case["profile"]) for k in models}
                stats = {}
                for k, out in outputs.items():
                    assert out.shape == data["target"].shape and out.dtype == np.float32 and np.isfinite(out).all()
                    stats[k] = metric(out) | {ABSOLUTE: sharp_metric(out)[LENGTH]}
                scores[token] = {
                    "methods": stats, "target_transfer": sharp_metric(data["target"])[LENGTH],
                    "gap_pixels": int(metric.gap.sum()),
                    "sharp_strength": float(np.sqrt(sharp_metric.clean_norm / sharp_metric.intact.sum()) * 65535),
                }
                if ident in VIEWS:
                    meta = {k: data[k][None] for k in ("wb", "matrix", "colors")}
                    meta["packed"] = data["packed"][:1]
                    values = [noisy_malvar(meta)[0], *(outputs[k][0] for k in (*BASE, *SCENE)), data["target"][0]]
                    native.append(native_board(
                        ROOT / "native", f"{ident}-sigma-{sigma:g}", values, meta,
                        {"fixture": case["fixture"], "model_query_in_fixture": case["box"],
                         "input": record["inputs"][token], "ISO_profile": case["profile"],
                         "checkpoints": checkpoints, "weights": "EMA", "sigma_pixels": sigma},
                        labels=LABELS, triplet_indices=(0, 3, 6),
                    ))
            write_json(receipt, {
                "id": ident, "input_plan": bind, "scores": scores, "native": native,
                "family": geometry["family"], "geometry": geometry,
            })
            rows.append(reference(receipt))
            print(ident, geometry["family"], round(time.monotonic() - start, 1), flush=True)
    write_json(ROOT / "result.json", {
        "input_plan": bind, "rows": rows, "run_seconds": time.monotonic() - start,
    })


def json_value(x):
    return list(x) if isinstance(x, tuple) else x


if __name__ == "__main__":
    main(sys.argv[1])
