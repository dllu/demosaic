"""Bind the trained optical arm to the existing fixed photo and camera collector."""

from pathlib import Path

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, PRIOR

CONTROL_MODELS = ("V120", "parent100k", "local50k", "regional-aligned")


def main():
    train_ref = reference(ARCHIVE / "train/completed.json")
    completed = read_json(checked(train_ref))
    plan = read_json(checked(completed["plan"]))
    assert completed["completed_schedule"] and completed["step"] == plan["steps"]
    assert completed["DINO_unchanged"] and not completed["qualification"]
    review = read_json(checked(plan["review_inputs"]))
    fixed = read_json(checked(review["standing_fixed_and_canonical"]))
    ref = reference(PRIOR / "canonical/plan.json")
    template = read_json(checked(ref))
    assert template["canonical_inputs"] == fixed["canonical_inputs"]
    assert template["models"]["local50k"]["checkpoint"] == completed["parent"]
    assert template["models"]["regional-aligned"]["checkpoint"] == plan["original_control"]
    assert template["DINO_sha256"] == plan["DINO_sha256"]
    assert template["stages"]["known"]["manifest"] == fixed["known_cameras"]
    assert template["stages"]["unseen"]["manifest"] == fixed["unseen_cameras"]

    root = ARCHIVE / "canonical"
    root.mkdir()
    work, frozen = freeze_sources(Path.cwd(), root, ["collect_scene_primary_compact.py"])
    models = {name: template["models"][name] for name in CONTROL_MODELS}
    models[ARM] = {"kind": "scene", "step": completed["step"], "checkpoint": completed["checkpoints"][ARM]}
    inputs = [train_ref, completed["plan"], plan["review_inputs"], ref,
              *(m["checkpoint"] for m in models.values()),
              *(template[k] for k in ("canonical_inputs", "photo_inventory", "parent_CPU_probes")),
              *(m["manifest"] for m in template["stages"].values() if "manifest" in m)]
    keys = ("canonical_inputs", "photo_inventory", "parent_CPU_probes", "preview_long_side",
            "preview_exposure", "stages", "DINO_sha256", "policy")
    document = {k: template[k] for k in keys}
    document.update(
        root=str(root), inputs=inputs, probe_only=False, models=models, frozen_files=frozen,
        driver=reference(work / "scripts/collect_scene_primary_compact.py"),
        reference_replay={"plan": ref, "root": template["root"], "models": dict(zip(CONTROL_MODELS, CONTROL_MODELS))},
    )
    write_json(root / "plan.json", document)
    print(root / "plan.json", flush=True)


if __name__ == "__main__":
    main()
