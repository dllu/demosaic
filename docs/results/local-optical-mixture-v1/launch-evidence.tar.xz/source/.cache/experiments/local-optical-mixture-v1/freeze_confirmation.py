"""Freeze disjoint fresh photos and optical RAW draws before inspecting trained outputs."""

from collections import Counter
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed
from prepare_optical import ARCHIVE, CACHE, ROOT

sys.path.insert(0, str(CACHE / "sensor-optical-transfer-v1"))
from capture_coupled import sample_roles
from capture_optical import DOSES, capture_wide, filtered_observation
sys.path.insert(0, str(CACHE / "scene-staggered-phase-v1"))
from capture_confirmation import carrier

SEED = 202611192355
COUNT = 24
FAMILIES = ("strip", "ellipse", "smooth-dip", "contrast-step")
ROLE_NAMES = ("long-present", "long-exterior-only", "short-only", "flat")


def select():
    train_ref = reference(ROOT / "plan.json")
    train = read_json(checked(train_ref))
    validations = read_json(checked(train["review_inputs"]))
    previous_ref = validations["wire_transfer"]
    previous = read_json(checked(previous_ref))
    last = read_json(checked(previous["plan"]))
    review = read_json(checked(validations["standing_fixed_and_canonical"]))
    train_sources = [r["source"] for p in train["schedule"].values() for r in read_json(checked(p))]
    exclude = [*[r["source"] for r in previous["rows"]], *train_sources,
               *[r["source"]["source"] for group in review["exact"].values() for r in group]]
    frozen_exclusions = [
        *last["source_exclusions"],
        *(ref for ref in train["inputs"] if ref["path"].endswith("development.jsonl")),
        last["training_manifest"],
    ]
    blocked = set()
    capture_wide.scan(exclude, blocked)
    for marker in frozen_exclusions:
        fp = checked(marker)
        if fp.suffix == ".jsonl":
            for row in capture_wide.lines(marker):
                capture_wide.scan(row, blocked)
        else:
            capture_wide.scan(read_json(fp), blocked)
    eligible = [
        r for r in capture_wide.lines(last["source_pool"])
        if r["split"] == "val" and r["bin_factor"] == 4 and min(r["shape"][:2]) >= 512
        and r["id"] not in blocked and r["cache_sha256"] not in blocked
    ]
    eligible.sort(key=lambda r: sha256(f"{SEED}/{r['id']}".encode()).digest())
    capture_wide.SEED = SEED
    chosen = []
    for row in eligible:
        i = len(chosen)
        if not {row["id"], row["cache_sha256"]}.isdisjoint(blocked):
            continue
        blocked.update((row["id"], row["cache_sha256"]))
        (box,) = scene_crop_boxes(
            row["shape"][:2], patch_size=512, count=1, seed=scene_seed(SEED, i, "crop")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        camera.update(pattern=tuple(PATTERNS)[i % 4], black=0.03, **{
            key: last["noise"][key] for key in ("shot", "read", "exposure")
        })
        rng = np.random.default_rng(scene_seed(SEED, i, "geometry-independent"))
        geometry = capture_wide.geometry(i)
        geometry.update(
            family=FAMILIES[i // 6],
            frequency=[carrier(rng, 1, (7.25, 8.90)), carrier(rng, -1, (7.20, 9.25))],
            strength=rng.uniform([.010, .0035], [.016, .009]).tolist(),
        )
        chosen.append({
            "source": row, "box": box, "index": i, "camera": camera,
            "geometry": geometry, "partition": "optical_confirmation",
        })
        if len(chosen) == COUNT:
            break
    assert len(chosen) == COUNT and len({r["source"]["cache_sha256"] for r in chosen}) == COUNT
    chosen_ids = {r["source"][k] for r in chosen for k in ("id", "cache_sha256")}
    trace = read_json(checked(last["parent_traces"]))
    visits = 0
    for record in trace["source_traces"]:
        for update in capture_wide.lines(record):
            for source in update["sources"]:
                if source["kind"] == "photographic":
                    assert chosen_ids.isdisjoint({source["source_id"], source["cache_sha256"]})
                    visits += 1
    assert visits == last["parent_visits_checked"] == 559808
    return {
        "driver": reference(__file__), "training_plan": train_ref, "reference_wire_panel": previous_ref,
        "source_pool": last["source_pool"], "excluded_sources": frozen_exclusions, "seed": SEED,
        "source_count": COUNT, "family_counts": dict(Counter(r["geometry"]["family"] for r in chosen)),
        "archive_photo_visits_checked": visits, "sources": chosen, "roles": ROLE_NAMES,
        "camera_profile": last["noise"], "query_box": [128, 128, 256, 256], "dose_pixels": DOSES,
        "primary": "difference in sharp-normalized weak fundamental at sigma 0.85 vs the sharp-only control",
        "coupled_generator": reference(sys.modules[sample_roles.__module__].__file__),
        "filter_generator": reference(sys.modules[filtered_observation.__module__].__file__),
    }


def capture(plan, folder):
    from functools import partial
    from unittest.mock import patch

    capture_wide.ROLES = plan["roles"]
    records = []
    for fixture in plan["sources"]:
        case = {"id": f"fresh-{fixture['index']:02d}", "fixture": fixture}
        data, case["seeds"] = capture_wide.capture(fixture)
        blurred = []
        for sigma in DOSES[1:]:
            with patch.object(capture_wide, "observe_scene", partial(filtered_observation, sigma=sigma)):
                paired, seeds = capture_wide.capture(fixture)
            assert seeds == case["seeds"]
            blurred.append(paired)
        coupled = sample_roles(case, data, blurred)
        case["inputs"] = {}
        for sigma, inputs in zip(DOSES, [data, *coupled], strict=True):
            name = folder / f'{case["id"]}-{sigma:g}.npz'
            with name.open("xb") as stream:
                np.savez(stream, **inputs)
            case["inputs"][str(sigma)] = reference(name)
        records.append(case)
    return records


def main():
    torch.set_num_threads(2)
    selected = select()
    folder = ARCHIVE / "confirmation"
    folder.mkdir(parents=True)
    start = time.monotonic()
    plan_path = ROOT / "confirmation-plan.json"
    write_json(plan_path, selected)
    rows = capture(selected, folder)
    receipt = folder / "inputs.json"
    write_json(receipt, {
        "plan": reference(plan_path), "rows": rows, "capture_seconds": time.monotonic() - start,
    })
    print("Frozen", len(rows), "fresh scenes and all", len(DOSES) * len(rows), "optical captures.", flush=True)


if __name__ == "__main__":
    main()
