"""Check optical transfer on frozen prior and independent held-out source photos."""

import argparse
import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from prepare_optical import ARCHIVE, ARM, CACHE, OPTICAL, ROOT

sys.path.insert(0, str(CACHE / "sensor-optical-transfer-v1"))
from capture_optical import (
    ABSOLUTE, DOSES, LENGTH, WireFundamental, arrays, bind_models,
    native_board, run_model, support_for_scoring,
)
from summarize_optical import source_bootstrap, interval

MODELS = ("v120", "parent", "local50k", "regional-aligned", ARM)
LABELS = ("Noisy Malvar", "V120", "Corpus 100k", "Local 50k", "Sharp regional", "Mixed optics", "Exact GT")
NATIVE_IDS = {"fresh-02", "fresh-08"}
METRICS = (
    LENGTH, ABSOLUTE, "fundamental_intact_RMS_DN16", "gap_continuing_strong_RMS_DN16",
    "fundamental_false_RMS_DN16", "exact_flat_RMS_DN16",
)


def bindings(plan):
    review = read_json(checked(plan["review_inputs"]))
    prior_ref = review["optical_shared_noise"]
    paired = read_json(checked(prior_ref))
    observed = read_json(checked(paired["standard_input_plan"]))
    panel = read_json(checked(observed["parents"]))
    prior_result = read_json(checked(observed["scene_results"]))
    original = {item["case"]["id"]: item["predictions"] for item in prior_result["offgrid_predictions"]}
    fresh_ref = reference(ARCHIVE / "confirmation/inputs.json")
    fresh = read_json(checked(fresh_ref))
    fresh_plan = read_json(checked(fresh["plan"]))
    assert checked(fresh_plan["training_plan"]) == ROOT / "plan.json"
    sources = {"confirmation": (fresh_ref, fresh_plan["camera_profile"], fresh["rows"])}
    replay = []
    for row, dose in zip(panel["rows"], paired["inputs"], strict=True):
        assert row["id"] == dose["id"]
        replay.append({
            "id": row["id"], "fixture": row["fixture"],
            "inputs": {"0.0": row["input"]} | dose["observations"],
            "sharp_base": row["rgb"], "sharp_scene": original[row["id"]],
        })
    sources["previous"] = (prior_ref, panel["rows"][0]["profile"], replay)
    base = {k: observed["checkpoints"][k] for k in MODELS[:-1]}
    assert base["regional-aligned"] == plan["original_control"] and base["local50k"] == plan["parent"]
    return sources, base


def source_panel(name, items, models, checkpoints, out):
    binding, profile, photos = items
    rows = []
    native = []
    for photo in photos:
        geometry = photo["fixture"]["geometry"]
        ident = photo["id"]
        sharp = arrays(photo["inputs"]["0.0"])
        support = support_for_scoring(sharp["support"])
        sharp_metric = WireFundamental(sharp | {"support": support}, geometry)
        results = {}
        for dose in DOSES:
            data = sharp if dose == 0.0 else arrays(photo["inputs"][str(dose)])
            scorer = WireFundamental(data | {"support": support}, geometry) if dose else sharp_metric
            assert np.array_equal(scorer.gap, sharp_metric.gap)
            assert np.array_equal(scorer.intact, sharp_metric.intact)
            if models is None:
                results[str(dose)] = {"exact_gap_pixels": int(scorer.gap.sum())}
                continue
            if dose == 0 and name == "previous":
                saved = arrays(photo["sharp_base"])
                saved.update({
                    k: np.load(checked(photo["sharp_scene"][k]), allow_pickle=False)
                    for k in ("local50k", "regional-aligned")
                })
                saved[ARM] = run_model(models[ARM], "regional-aligned", data, profile)
            else:
                saved = {
                    k: run_model(models[k], "regional-aligned" if k == ARM else k, data, profile)
                    for k in MODELS
                }
            assert all(a.shape == data["target"].shape and np.isfinite(a).all() for a in saved.values())
            results[str(dose)] = {"scores": {
                k: scorer(saved[k]) | {ABSOLUTE: sharp_metric(saved[k])[LENGTH]} for k in MODELS
            }}
            if ident in NATIVE_IDS:
                meta = {k: data[k][None] for k in ("wb", "matrix", "colors")}
                meta["packed"] = data["packed"][:1]
                prediction = [saved[k][0] for k in MODELS]
                native.append(native_board(
                    out, f"{ident}-sigma-{dose:g}", [noisy_malvar(meta)[0], *prediction, data["target"][0]],
                    meta, {
                        "source": photo["fixture"], "input": photo["inputs"][str(dose)],
                        "noise": profile, "model_query_xywh": [128, 128, 256, 256],
                        "dose_native_px": dose, "checkpoints": checkpoints,
                    }, labels=LABELS, triplet_indices=(0, 5, 6),
                ))
        rows.append({
            "id": ident, "family": geometry["family"], "results": results,
            "strength_DN16": float(np.sqrt(sharp_metric.clean_norm / sharp_metric.intact.sum()) * 65535),
        })
        if models is not None and len(rows) % 4 == 0:
            print(name, len(rows), "/", len(photos), flush=True)
    return {"source_binding": binding, "rows": rows, "native": native}


def aggregate(rows):
    report = {}
    rng = np.random.default_rng(202611192359)
    ranked = sorted(rows, key=lambda r: r["strength_DN16"])
    for label, selected in (("all", rows), ("faintest_half", ranked[:len(ranked) // 2])):
        cohort = {}
        for key in METRICS:
            sample = [r for r in selected if key in r["results"]["0.0"]["scores"][ARM]]
            if not sample:
                continue
            draws = source_bootstrap(sample, rng)
            scores = {
                k: {
                    str(dose): np.asarray([r["results"][str(dose)]["scores"][k][key] for r in sample])[draws].mean(1)
                    for dose in DOSES
                } for k in MODELS
            }
            contrast = {}
            for control in MODELS[:-1]:
                differences = {d: scores[ARM][d] - scores[control][d] for d in scores[ARM]}
                contrast[control] = {
                    "difference": {d: interval(v) for d, v in differences.items()},
                    "interaction_vs_sharp": {d: interval(v - differences["0.0"]) for d, v in differences.items()},
                }
            cohort[key] = {
                "count": len(sample), "mean": {k: {d: interval(v) for d, v in s.items()} for k, s in scores.items()},
                "mixed_minus_control": contrast,
            }
        report[label] = cohort
    return report


@torch.inference_mode()
def main(verify_only):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    panels, checkpoints = bindings(plan)
    if verify_only:
        for name, items in panels.items():
            result = source_panel(name, items, None, checkpoints, None)
            expected = 12 if name == "confirmation" else 16
            assert sum(r["results"]["0.0"]["exact_gap_pixels"] > 0 for r in result["rows"]) == expected
            print(name, len(result["rows"]), "input groups scored for support before training results", flush=True)
        return
    training_ref = reference(ARCHIVE / "train/completed.json")
    training = read_json(checked(training_ref))
    assert training["plan"] == plan_ref and training["completed_schedule"] and training["step"] == plan["steps"]
    assert training["DINO_unchanged"] and not training["qualification"]
    checkpoints |= training["checkpoints"]
    out = ARCHIVE / "optical-review"
    out.mkdir(exist_ok=True)
    pics = out / "native"
    pics.mkdir(exist_ok=True)
    start = time.monotonic()
    torch.cuda.set_per_process_memory_fraction(
        min(1, 11 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    models = bind_models(checkpoints)
    with ieee_fp32():
        for name, items in panels.items():
            target = out / f"{name}.json"
            if target.exists():
                result = read_json(target)
                assert result["checkpoints"] == checkpoints and result["source_binding"] == items[0]
                continue
            result = source_panel(name, items, models, checkpoints, pics)
            write_json(target, result | {
                "driver": reference(__file__), "finished_training": training_ref, "checkpoints": checkpoints,
                "scores": aggregate(result["rows"]), "weights": "CUDA IEEE FP32 EMA", "wall_seconds": time.monotonic() - start,
            })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    main(parser.parse_args().verify_only)
