"""Verify matched sharp inputs, unchanged acquisition geometry and protected flat cores."""

import json
from pathlib import Path
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ROOT


def main():
    binding = reference(ROOT / "plan.json")
    plan = read_json(checked(binding))
    script = checked(plan["shared_driver"])
    sys.path.insert(0, str(script.parent))
    from train_local_paired_continuation import CORE, observations

    old = read_json(checked(plan["original_completion"]))
    baseline = read_json(checked(old["plan"]))
    qual = read_json(checked(baseline["qualification"]))
    selected = {}
    torch.set_num_threads(2)
    for name, historical in (("qualification", qual), ("train", old)):
        rows = read_json(checked(plan["schedule"][name]))
        with checked(historical["trace"]).open() as stream:
            historic = [json.loads(line) for line in stream if line.strip()]
        assert len(historic) == len(rows)
        checks = []
        count = len(rows) if name == "qualification" else 40
        for row, prev in zip(rows[:count], historic[:count], strict=True):
            index = prev["index"]
            sharp, meta = observations(row | {"optical_sigma": 0.}, index, pair_draws=2, seed=plan["seed"])
            assert meta.pop("optical_sigma") == 0 and json.loads(json.dumps(meta)) == prev
            actual, fields = observations(row, index, pair_draws=2, seed=plan["seed"])
            sigma = fields.pop("optical_sigma")
            assert all(fields[k] == meta[k] for k in meta if k != "arrays")
            assert all(t.dtype == sharp[k].dtype and t.shape == sharp[k].shape and torch.isfinite(t).all()
                       for k, t in actual.items())
            assert len(actual["target"]) == 6
            for k in ("wb", "matrix", "colors"):
                torch.testing.assert_close(actual[k], sharp[k], atol=0, rtol=0)
            for k in ("target", "sensor_target"):
                torch.testing.assert_close(
                    actual[k][4, :, CORE, CORE], sharp[k][4, :, CORE, CORE], atol=0, rtol=0
                )
            if sigma:
                for k in ("packed", "target", "sensor_target", "variance"):
                    assert not torch.equal(actual[k], sharp[k]), k
            else:
                assert meta["arrays"] == fields["arrays"]
            checks.append({"index": index, "sigma_native_px": sigma, "kind": meta["kind"], "law": meta["law"],
                           "source": meta["source_id"], "optical": fields["arrays"],
                           "archived_sharp": prev["arrays"]})
        selected[name] = checks
    assert {r["sigma_native_px"] for r in selected["train"]} == {0., .4, .65}
    assert {r["law"] for r in selected["qualification"] if r["sigma_native_px"]} == {"coupled", "independent"}
    write_json(ROOT / "input-audit.json", {"driver": reference(__file__), "plan": binding, "checks": selected})
    print("48 sharp trace replays match archive. Mixed inputs retain CFA, seeds, and exact flat cores.", flush=True)


if __name__ == "__main__":
    main()
