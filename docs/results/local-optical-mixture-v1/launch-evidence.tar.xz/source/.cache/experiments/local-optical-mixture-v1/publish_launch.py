"""Archive the actual launch, qualified inputs and frozen review before endpoint scoring."""

import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from prepare_optical import ARCHIVE, ARM, CACHE, ROOT

REPO = CACHE.parents[1]
DEST = REPO / "docs/results" / ROOT.name


def main():
    DEST.mkdir(exist_ok=True)
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    audit_ref = reference(ROOT / "first-updates-audit.json")
    audit = read_json(checked(audit_ref))
    assert audit["plan"] == plan_ref and owner_live(audit["live_worker"])
    qual_ref = reference(ARCHIVE / "qualification/completed.json")
    qual = read_json(checked(qual_ref))
    assert qual["plan"] == plan_ref and qual["step"] == 8 and qual["qualification"]
    assert qual["DINO_unchanged"]
    inputs_ref = reference(ROOT / "input-audit.json")
    inputs = read_json(checked(inputs_ref))
    assert inputs["plan"] == plan_ref
    confirmation_ref = reference(ARCHIVE / "confirmation/inputs.json")
    confirmation = read_json(checked(confirmation_ref))
    confirm_plan = read_json(checked(confirmation["plan"]))
    assert confirm_plan["training_plan"] == plan_ref
    assert len(confirmation["rows"]) == confirm_plan["source_count"] == 24
    assert all(len(r["inputs"]) == 3 for r in confirmation["rows"])
    files = [
        plan_ref, plan["review_inputs"], *plan["schedule"].values(), audit_ref, qual_ref,
        qual["trace"], qual["log"], inputs_ref, confirmation_ref, confirmation["plan"],
    ]
    snapshot = [
        *ROOT.glob("*.py"), *ROOT.glob("*.sh"), *ROOT.glob("work/scripts/*.py"),
        checked(confirm_plan["coupled_generator"]), checked(confirm_plan["filter_generator"]),
    ]
    archive = DEST / "launch-evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as pack:
        for path in sorted(set(snapshot)):
            pack.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
        for binding in files:
            path = checked(binding)
            arc = path.relative_to(ROOT) if path.is_relative_to(ROOT) else path.relative_to(ARCHIVE)
            pack.add(path, arcname="receipts/" + str(arc), recursive=False)
    write_json(DEST / "launch.json", {
        "status": "qualified and running", "plan": plan_ref,
        "archive": {"repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "report": "docs/local-optical-mixture.md", "qualified_worker": qual_ref, "input_audit": inputs_ref,
        "live_prefix_verified": audit, "parent": plan["parent"], "matched_regional_control": plan["original_control"],
        "arm": ARM, "planned_updates": plan["steps"], "native_roles_per_group": plan["members"],
        "optical_schedule": plan["optics"], "fresh_confirmation": confirmation_ref,
        "fresh_confirmation_sources": confirm_plan["source_count"],
        "protected_review_profile": plan["review_inputs"],
    })
    print("Published source and launch receipt with", audit["attempt_completed_updates_verified"], "verified updates.")


if __name__ == "__main__":
    main()
