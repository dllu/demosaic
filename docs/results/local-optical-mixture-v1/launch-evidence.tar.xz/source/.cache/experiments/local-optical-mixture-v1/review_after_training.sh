#!/usr/bin/env bash
# Verify the specific recorded worker, then collect independent review panels.
set -u
study_root=/mnt/external/demosaic/local-optical-mixture-v1
study_code=.cache/experiments/local-optical-mixture-v1
study_python=.venv/bin/python
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$PWD/scripts"
study_worker_pid=$("$study_python" -c 'import sys,json; print(json.load(open(sys.argv[1]))["pid"])' "$study_root/owner.json")
printf 'Waiting for training worker %s\n' "$study_worker_pid"
while [[ ! -f "$study_root/train/completed.json" ]]; do
    "$study_python" - "$study_root/owner.json" "$study_worker_pid" <<'PY'
from pathlib import Path
import sys
from demosaic.experiments.artifacts import read_json
from demosaic.experiments.runtime import owner_live
identity = read_json(Path(sys.argv[1]))
raise SystemExit(0 if identity["pid"] == int(sys.argv[2]) and owner_live(identity) else 1)
PY
    if [[ $? != 0 && ! -f "$study_root/train/completed.json" ]]; then
        printf 'Training worker %s exited before completing the schedule\n' "$study_worker_pid" >&2
        exit 1
    fi
    sleep 30
done
"$study_python" -u "$study_code/audit_live.py" --complete || exit 1
"$study_python" -u "$study_code/review_fixed.py" > "$study_root/fixed-review.log" 2>&1
fixed_status=$?
"$study_python" -u "$study_code/review_optical.py" > "$study_root/optical-review.log" 2>&1
optical_status=$?
study_canonical="$study_root/canonical"
if "$study_python" -u "$study_code/prepare_canonical.py" > "$study_root/canonical-prepare.log" 2>&1; then
    PYTHONPATH="$PWD/src" "$study_python" -u "$study_canonical/work/scripts/collect_scene_primary_compact.py" preflight "$study_canonical/plan.json" > "$study_root/canonical-preflight.log" 2>&1 &&
        PYTHONPATH="$PWD/src" "$study_python" -u "$study_canonical/work/scripts/collect_scene_primary_compact.py" cameras "$study_canonical/plan.json" > "$study_root/canonical-cameras.log" 2>&1 &&
        PYTHONPATH="$PWD/src" "$study_python" -u "$study_canonical/work/scripts/collect_scene_primary_compact.py" full "$study_canonical/plan.json" > "$study_root/canonical-full.log" 2>&1
    canonical_status=$?
else
    canonical_status=$?
fi
printf 'Review exits. Fixed %s, optical %s, canonical %s\n' "$fixed_status" "$optical_status" "$canonical_status"
[[ "$fixed_status" == 0 && "$optical_status" == 0 && "$canonical_status" == 0 ]]
