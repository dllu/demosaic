"""Compare the recorded updates to the archived control and frozen optical schedule."""

from collections import Counter
import json
import math
import sys

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from prepare_optical import ARCHIVE, ARM, ROOT

CONTROL = "regional-aligned"


def finished_lines(file):
    content = file.read_bytes()
    return [json.loads(line) for line in content.split(b"\n")[:-1]]


def verify(complete):
    prefix = reference(ROOT / "plan.json")
    plan = read_json(checked(prefix))
    matched = read_json(checked(plan["original_completion"]))
    old_obs = finished_lines(checked(matched["trace"]))
    old_train = finished_lines(checked(matched["log"]))
    new_obs = finished_lines(ARCHIVE / "train/observations.jsonl")
    new_train = finished_lines(ARCHIVE / "train/train.jsonl")
    records = read_json(checked(plan["schedule"]["train"]))
    assert 0 < len(new_train) <= len(new_obs) <= len(records)
    assert len(old_train) == len(old_obs) == len(records) == plan["steps"]
    assert new_train[0][ARM] == old_train[0][CONTROL]
    assert records[0]["optical_sigma"] == 0.0
    seen = Counter()
    for i, (observed, trained, previous, matched_metrics, slot) in enumerate(
        zip(new_obs, new_train, old_obs, old_train, records)
    ):
        assert trained["step"] == matched_metrics["step"] == i + 1 == observed["index"]
        assert trained["lr"] == matched_metrics["lr"]
        assert all(observed[k] == previous[k] for k in previous if k != "arrays")
        sigma = slot["optical_sigma"]
        assert observed["optical_sigma"] == sigma
        assert all(math.isfinite(v) for v in trained[ARM].values())
        if sigma == 0:
            assert observed["arrays"] == previous["arrays"]
        else:
            for k in ("packed", "variance", "target", "sensor_target"):
                assert observed["arrays"][k] != previous["arrays"][k]
            for k in ("colors", "matrix", "wb"):
                assert observed["arrays"][k] == previous["arrays"][k]
        seen[str(sigma)] += 1

    details = {
        "driver": reference(__file__), "plan": prefix, "attempt_completed_updates_verified": len(new_train),
        "dose_counts": dict(seen), "sharp_first_step_loss_and_gradient_exact": True,
        "scheduled_sources_matched": len(new_train), "all_values_finite": True,
    }
    if complete:
        completion = reference(ARCHIVE / "train/completed.json")
        run = read_json(checked(completion))
        assert run["plan"] == prefix and run["completed_schedule"] and run["DINO_unchanged"]
        assert run["step"] == len(new_train) == len(new_obs) == len(records)
        assert run["native_observations_per_arm"] == len(records) * 6
        assert dict(seen) == {"0.0": 512, "0.4": 256, "0.65": 256}
        checked(run["checkpoints"][ARM])
        checked(run["trace"])
        checked(run["log"])
        details["completion"] = completion
        dest = ROOT / "completed-audit.json"
    else:
        owner = read_json(ARCHIVE / "owner.json")
        assert owner_live(owner)
        details["live_worker"] = owner
        dest = ROOT / "first-updates-audit.json"
    write_json(dest, details)
    print(dest, len(new_train), dict(seen), flush=True)


if __name__ == "__main__":
    verify("--complete" in sys.argv)
