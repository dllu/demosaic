"""Freeze one optical augmentation arm of the completed regional training comparison."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

ROOT = Path(__file__).resolve().parent
CACHE = ROOT.parent
ARCHIVE = Path("/mnt/external/demosaic") / ROOT.name
PRIOR = ARCHIVE.with_name("local-regional-wire-v1")
OPTICAL = ARCHIVE.with_name("sensor-optical-transfer-v1")
SEED = 202611192352
ARM = "regional-optical-mix"
OPTICS = (0., .4, .65)

OPTICS_INSERT = '''
    sigma = case.get("optical_sigma", 0.0)
    if sigma:
        def optical(rgb):
            result = gaussian_filter(rgb.numpy(), (0.0, sigma, sigma), truncate=4, mode="reflect")
            return torch.from_numpy(result)

        present, absent, flat, crop = [optical(rgb) for rgb in (present, absent, flat, crop)]
        assert torch.equal(flat[:, CORE, CORE], flat[:, 80:81, 80:81].expand(3, 96, 96))
'''


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


def snapshots(baseline):
    folder = ROOT / "work" / "scripts"
    folder.mkdir(parents=True)
    driver = folder / "train_regional_optical.py"
    shared = folder / "train_local_paired_continuation.py"
    originals = [checked(baseline[name]) for name in ("driver", "shared_driver")]
    assert "regional_objective.py" in {p.name for p in originals[0].parent.iterdir()}
    objective = originals[0].with_name("regional_objective.py")
    assert reference(objective)["sha256"] == baseline["frozen_files"][str(objective)]
    shutil.copyfile(objective, folder / objective.name)

    src = originals[1].read_text()
    src = replace_once(src, "import torch\n", "import torch\nfrom scipy.ndimage import gaussian_filter\n")
    marker = "    shot, read = PROFILES[case[\"iso\"]]"
    src = replace_once(src, marker, OPTICS_INSERT + "\n" + marker)
    src = replace_once(src, '        "geometry": geometry,\n', '        "geometry": geometry,\n        "optical_sigma": sigma,\n')
    compile(src, str(shared), "exec")
    shared.write_text(src)

    src = originals[0].read_text()
    src = replace_once(src, 'ARMS = ("global-aligned", "regional-aligned")', f"ARMS = ({ARM!r},)")
    src = replace_once(src, str(PRIOR), str(ARCHIVE))
    src = replace_once(src, 'ROOT / "plan-v3.json"', 'ROOT / "plan.json"')
    src = replace_once(src, '''        qualified = read_json(checked(plan["qualification"]))
        assert qualified["plan"] == plan["qualification_base"] and qualified["qualification"]
''', '''        qualified = read_json(output.parent / "qualification/completed.json")
        assert qualified["plan"] == plan_binding and qualified["qualification"]
''')
    src = replace_once(src, '''                    alignment = redraw["aligned"] if arm == ARMS[0] else local
                    weight = loss_weights["aligned"] if arm == ARMS[0] else loss_weights["regional_aligned"]
''', '''                    alignment = local
                    weight = loss_weights["regional_aligned"]
''')
    start = src.index("                if step == 1:\n")
    end = src.index("                if not torch.isfinite(total):", start)
    src = src[:start] + src[end:]
    compile(src, str(driver), "exec")
    driver.write_text(src)
    return driver, shared, originals


def augment_schedule(originals, qualification):
    train = read_json(checked(originals["train"]))
    check = read_json(checked(originals["qualification"]))
    indices = defaultdict(list)
    for i, record in enumerate(train):
        indices[tuple(record[k] for k in ("kind", "iso", "pattern", "law"))].append(i)
    assert len(indices) == 32 and all(len(v) == 32 for v in indices.values())
    rng = random.Random(SEED)
    for ids in indices.values():
        shuffled = ids[:]
        rng.shuffle(shuffled)
        groups = (16, 8, 8)
        doses = [sigma for sigma, count in zip(OPTICS, groups, strict=True) for _ in range(count)]
        if 0 in shuffled:
            position = shuffled.index(0)
            doses[0], doses[position] = doses[position], doses[0]
        for i, dose in zip(shuffled, doses, strict=True):
            train[i]["optical_sigma"] = dose
    assert Counter(row["optical_sigma"] for row in train) == {0.: 512, .4: 256, .65: 256}
    assert len(check) == qualification["step"] == 8
    for row, sigma in zip(check, (0., .4, .65, .65, .65, 0., .65, .4), strict=True):
        row["optical_sigma"] = sigma
    bindings = {}
    for name, rows in (("train", train), ("qualification", check)):
        path = ROOT / f"{name}-schedule.json"
        write_json(path, rows)
        bindings[name] = reference(path)
    return bindings


def source_ids(entries):
    return {r[k] for r in entries for k in ("id", "cache_sha256")}


def prepare():
    prior_ref = reference(PRIOR / "train/completed.json")
    prior = read_json(checked(prior_ref))
    baseline = read_json(checked(prior["plan"]))
    verify_plan(baseline)
    qualification = read_json(checked(baseline["qualification"]))
    assert prior["completed_schedule"] and prior["DINO_unchanged"] and prior["start"] == 0
    assert prior["step"] == baseline["steps"] == 1024
    original = prior["checkpoints"]["regional-aligned"]
    checked(original)
    plan_ref = baseline["review_inputs"]
    review = read_json(checked(plan_ref))
    doses_ref = reference(OPTICAL / "inputs.json")
    doses = read_json(checked(doses_ref))
    paired_ref = reference(OPTICAL / "coupled/samples.json")
    paired = read_json(checked(paired_ref))
    assert paired["standard_input_plan"] == doses_ref
    held = read_json(checked(review["transfer"]))
    assert held["rows"] == read_json(checked(doses["parents"]))["rows"]
    fixed_ids = source_ids(r["source"]["source"] for group in review["exact"].values() for r in group)
    held_ids = source_ids(r["source"] for r in held["rows"])
    cases = [r for binding in baseline["schedule"].values() for r in read_json(checked(binding))]
    assert len(cases) == len({r["source"]["id"] for r in cases}) == 1032
    training_ids = source_ids(r["source"] for r in cases)
    assert training_ids.isdisjoint(fixed_ids | held_ids)
    assert all(r["source"]["split"] == "train" and "commons-" in r["source"]["cache"] for r in cases)
    fixed_configs = review["GFX_configs"]
    for ref in fixed_configs:
        document = read_json(checked(ref))
        for raw in document.get("sources", {}).values():
            assert raw["sha256"] not in training_ids
    assert {0.55, 0.85}.isdisjoint(OPTICS)
    driver, shared, originals = snapshots(baseline)
    schedule = augment_schedule(baseline["schedule"], qualification)
    review_inputs = {
        "standing_fixed_and_canonical": plan_ref, "wire_transfer": review["transfer"],
        "optical_same_seed": doses_ref, "optical_shared_noise": paired_ref,
        "training_photo_overlap": {"standing": 0, "fixed_exact": 0, "transfer": 0},
        "primary_optical_dose": 0.85, "interpolated_optical_dose": 0.55, "sharp_check": 0.0,
        "primary_noise_protocol": "coupled across blur doses, separately drawn per source and role",
        "primary_measure": "source-paired change in sharp-normalized weak fundamental",
        "retained_measures": ["continuing-strand and false weak gap RMS", "exact-flat RMS", "natural fine increments"],
    }
    review_path = ROOT / "review.json"
    write_json(review_path, review_inputs)
    frozen = dict(baseline["frozen_files"])
    for file in (*driver.parent.glob("*.py"), Path(__file__)):
        asset = reference(file)
        frozen[asset["path"]] = asset["sha256"]

    plan = {k: baseline[k] for k in (
        "parent", "parent_training", "parent_update", "adapter_width", "DINO_sha256", "seed",
        "runtime", "steps", "report_every", "save_steps", "ordinary_source_count",
        "wire_source_count", "members", "optimizer", "loss",
    )}
    plan.update(
        experiment=ROOT.name, arms=[ARM], shared_driver=reference(shared), driver=reference(driver),
        scope="All 1,024 regional source groups replayed; only the pre-camera optical augmentation varies.",
        schedule=schedule, frozen_files=frozen, review_inputs=reference(review_path),
        original_control=original, original_completion=prior_ref, original_plan=prior["plan"],
        optics={
            "widths_native_px": OPTICS, "counts": [512, 256, 256], "seed": SEED,
            "order": "assigned within every kind/ISO/Bayer/noise-law stratum",
            "placement": "unit-sum scene-linear Gaussian before exposure, camera conversion, CFA, shot/read and ADC",
            "targets": "post-optics, matching the sensor observation",
        },
        inputs=[*baseline["inputs"], prior["plan"], prior_ref, original, prior["trace"], baseline["qualification"],
                *schedule.values(), reference(review_path), plan_ref, doses_ref, paired_ref, *fixed_configs,
                *map(reference, originals)],
        repo_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    )
    write_json(ROOT / "plan.json", plan)
    verify_plan(plan)
    print("frozen", plan["experiment"], "controls", original["sha256"], "training 512/256/256", flush=True)


if __name__ == "__main__":
    prepare()
