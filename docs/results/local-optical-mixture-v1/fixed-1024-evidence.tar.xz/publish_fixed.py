"""Publish the completed exact and standing native comparisons of the final EMA."""

from pathlib import Path
import shutil
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, ROOT

REPO = ROOT.parents[2]
DEST = REPO / "docs/results" / ROOT.name
IMAGES = REPO / "docs/assets/local-optical-mixture-endpoint"
CONTROL = "regional-aligned"


def main():
    training_ref = reference(DEST / "training-1024.json")
    training = read_json(checked(training_ref))
    result_ref = reference(ARCHIVE / "fixed-review/result.json")
    result = read_json(checked(result_ref))
    assert result["training"] == training["training_receipt"]
    assert result["checkpoints"][ARM] == training["checkpoint"]
    assert result["checkpoints"][CONTROL] == training["matched_control"]
    assert result["weights"] == "EMA" and result["precision"] == "CUDA IEEE FP32"
    assert len(result["standing"]) == 8 and len(result["exact_boards"]) == 4
    exact = {kind: group["scores"] for kind, group in result["exact"].items()}
    assert set(exact) == {"photo", "wire"}
    assert all(len(payload["rows"]) == 24 for payload in result["exact"].values())
    images = [board[kind]["image"] for board in result["exact_boards"] for kind in ("triplet", "board")]
    standing = []
    for row in result["standing"]:
        images.extend([display["board"]["image"] for display in row["displays"]])
        a, b = (np.load(checked(row["predictions"][key]), allow_pickle=False) for key in (ARM, CONTROL))
        x, y, w, h = row["local_ROI"]
        cut = np.s_[..., y:y+h, x:x+w]
        delta = a[cut].astype(float) - b[cut]
        standing.append({"id": row["id"], "source": row["raw"], "ROI_xywh": row["global_ROI"],
                         "mixed_minus_control_RMS_DN16": float(np.sqrt(np.mean(delta * delta)) * 65535),
                         "RMS_vs_Local_50k_DN16": row["RGB_RMS_vs_parent_DN16"], "noise": row["noise"]})
    IMAGES.mkdir(exist_ok=True)
    bindings = []
    assert len(images) == 20
    for binding in images:
        image = checked(binding)
        dest = IMAGES / image.name
        shutil.copyfile(image, dest)
        assert reference(dest)["sha256"] == binding["sha256"]
        bindings.append({"repo_path": str(dest.relative_to(REPO)), "sha256": binding["sha256"]})

    archive = DEST / "fixed-1024-evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for name, source in (("fixed-result.json", result_ref), ("review_fixed.py", result["driver"]),
                             ("publish_fixed.py", reference(__file__))):
            tar.add(checked(source), arcname=name, recursive=False)
    write_json(DEST / "fixed-1024.json", {
        "source": result_ref, "training_publication": training_ref, "checkpoints": result["checkpoints"],
        "precision": result["precision"], "weights": result["weights"],
        "scope": "48 fixed exact cases and both GFX comparison families, full optical and canonical reviewed separately",
        "standing_native_views_inspected": 12, "exact_native_triplets_inspected": 4,
        "fixed_scores": exact, "images": bindings, "standing_RGB_differences": standing,
        "archive": {"repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
    })
    print("Bound 48 exact cases, 8 GFX crops and 20 native-resolution figures.", flush=True)


if __name__ == "__main__":
    main()
