"""Review the trained optical arm on the fixed exact and standing GFX inputs."""

from collections import defaultdict
import sys
import time

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint
from prepare_optical import ARCHIVE, ARM, CACHE, PRIOR

sys.path.insert(0, str(CACHE / "local-regional-wire-v1"))
import review_regional as review

CONTROL = "regional-aligned"
PARENT = "local50k"


def saved_predictions(before, fixed):
    mapping = {}
    for key, section in fixed["exact"].items():
        archive = before["exact"][key]["rows"]
        assert len(archive) == len(section)
        for old, new in zip(archive, section, strict=True):
            assert old["case"] == new
            tag = f'{key}-{new["source"]["index"]:02}'
            mapping[tag] = {kind: old["predictions"][kind] for kind in (CONTROL, PARENT)}

    arms = defaultdict(dict)
    for old, new in zip(before["standing"], fixed["standing"], strict=True):
        assert all(old[k] == new[k] for k in ("id", "raw", "noise", "input", "local_ROI", "global_ROI"))
        tag = old["predictions"][PARENT]["path"].split("/")[-1].removesuffix(f"-{PARENT}.npy")
        for name in (CONTROL, PARENT):
            previous = old["predictions"][name]
            assert name not in arms[tag] or arms[tag][name] == previous
            assert previous["path"].endswith(f"/{tag}-{name}.npy")
            arms[tag][name] = previous
    return mapping | arms


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    trained = reference(ARCHIVE / "train/completed.json")
    receipt = read_json(checked(trained))
    plan = read_json(checked(receipt["plan"]))
    assert receipt["completed_schedule"] and receipt["step"] == plan["steps"]
    assert receipt["DINO_unchanged"] and not receipt["qualification"]
    review_inputs = read_json(checked(plan["review_inputs"]))
    fixed_ref = review_inputs["standing_fixed_and_canonical"]
    fixed = read_json(checked(fixed_ref))
    before_ref = reference(PRIOR / "review-1024/result.json")
    before = read_json(checked(before_ref))
    assert before["review_inputs"] == fixed_ref
    assert before["checkpoints"][CONTROL] == plan["original_control"]
    assert before["checkpoints"][PARENT] == plan["parent"]
    assert before["precision"] == "CUDA IEEE FP32" and before["weights"] == "EMA"
    before_rgb = saved_predictions(before, fixed)
    used = set()

    root = ARCHIVE / "fixed-review"
    root.mkdir()
    folders = {name: root / name for name in ("exact", "standing", "predictions")}
    for folder in folders.values():
        folder.mkdir()
    bind = receipt["checkpoints"][ARM]
    device = torch.device("cuda")
    total = torch.cuda.get_device_properties(device).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, 10 * 2**30 / total))
    model, state = load_scene_checkpoint(checked(bind), expected_sha256=bind["sha256"], weights="ema")
    assert state["step"] == receipt["step"] and state["DINO_sha256"] == plan["DINO_sha256"]
    assert state["plan"] == receipt["plan"] and state["training_arm"] == ARM and state["mode"] == "none"
    del state
    models = {ARM: _stage_tiled_cuda(model.eval(), device)}

    original_predict = review.predict

    def predict(*args):
        tag = args[-1]
        assert tag in before_rgb and tag not in used
        output, timings = original_predict(*args)
        used.add(tag)
        return output | before_rgb[tag], timings

    review.ARMS = (CONTROL, ARM)
    review.GLOBAL, review.REGIONAL = "Sharp regional", "Mixed optics"
    review.LABELS = {PARENT: review.PARENT, CONTROL: review.GLOBAL, ARM: review.REGIONAL}
    review.predict = predict
    start = time.monotonic()
    scores = review.exact(models, fixed["exact"], folders["predictions"])
    native = review.chosen_crops(scores, folders["exact"])
    standing = review.standing(models, fixed["standing"], folders["predictions"], folders["standing"])
    assert used == set(before_rgb)
    write_json(root / "result.json", {
        "driver": reference(__file__), "training": trained, "review_inputs": fixed_ref, "reused": before_ref,
        "weights": "EMA", "precision": "CUDA IEEE FP32",
        "checkpoints": {CONTROL: plan["original_control"], PARENT: plan["parent"], ARM: bind},
        "exact": scores, "exact_boards": native, "standing": standing, "wall_seconds": time.monotonic() - start,
    })


if __name__ == "__main__":
    main()
