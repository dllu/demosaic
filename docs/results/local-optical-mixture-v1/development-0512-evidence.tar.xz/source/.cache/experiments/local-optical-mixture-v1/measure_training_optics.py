"""Measure the optical contrast the actual regional weak-harmonic targets retain."""

import json
import math
import sys
import time

import numpy as np
from scipy.ndimage import binary_erosion
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ROOT


def modulation(sigma, period, angle):
    radius = int(4 * sigma + .5)
    x = np.arange(-radius, radius + 1)
    weights = np.exp(-0.5 * (x / sigma)**2)
    weights /= weights.sum()
    frequencies = np.array([math.cos(angle), math.sin(angle)]) / period
    return float(np.prod(np.cos(np.pi * 2 * frequencies[:, None] * x) @ weights))


def coefficient(batch, banks, core):
    weights = (torch.tensor([.2126, .7152, .0722]) @ batch["matrix"][0]) * batch["wb"][0]
    camera = batch["sensor_target"]
    signal = ((camera[0] - camera[1]) * weights[:, None, None]).sum(0)[core, core]
    values = []
    for region, projection, _ in banks:
        if projection is not None:
            values.append(signal[region].reshape(-1) @ projection)
    return torch.cat(values).double()


def distribution(values):
    return {
        "mean": float(np.mean(values)),
        "p10_median_p90": np.quantile(values, (.10, .50, .90)).tolist(),
    }


def summarize(records):
    report = {}
    for sigma in sorted({r["sigma_native_px"] for r in records}):
        matching = [r for r in records if r["sigma_native_px"] == sigma]
        shortest = sorted(matching, key=lambda r: r["weak_period"])[:len(matching) // 4]
        faintest = sorted(matching, key=lambda r: r["sharp_coefficient_norm_DN16"])[:len(matching) // 2]
        report[str(sigma)] = {}
        for group, sample in (("all", matching), ("shortest_quarter", shortest), ("faintest_half", faintest)):
            report[str(sigma)][group] = {
                "count": len(sample),
                **{k: distribution([r[k] for r in sample]) for k in (
                    "weak_period", "measured_fraction", "discrete_Gaussian_response",
                    "sharp_coefficient_norm_DN16", "opposite_phase_fraction", "exact_gap_pixels",
                )},
            }
    return report


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    proof = reference(ROOT / "plan.json")
    plan = read_json(checked(proof))
    prior = read_json(checked(plan["original_completion"]))
    old = checked(prior["trace"])
    with old.open() as f:
        trace = [json.loads(line) for line in f if line.strip()]
    script = checked(plan["shared_driver"])
    sys.path.insert(0, str(script.parent))
    from train_local_paired_continuation import CORE, observations
    from regional_objective import geometry_axes, projections
    schedule = read_json(checked(plan["schedule"]["train"]))

    start = time.monotonic()
    records = []
    for index, (slot, previous) in enumerate(zip(schedule, trace, strict=True), 1):
        sigma = slot["optical_sigma"]
        if slot["kind"] != "wire" or sigma == 0.:
            continue
        sharp, original = observations(slot | {"optical_sigma": 0.}, index, pair_draws=2, seed=plan["seed"])
        soft, fields = observations(slot, index, pair_draws=2, seed=plan["seed"])
        assert original["arrays"] == previous["arrays"]
        assert all(fields[k] == original[k] for k in fields if k not in {"arrays", "optical_sigma"})
        geometry = fields["geometry"]["wire"]
        banks = projections(geometry)
        ref = coefficient(sharp, banks, CORE)
        out = coefficient(soft, banks, CORE)
        norm = ref @ ref
        assert norm > 0
        fraction = float(out @ ref / norm)
        phase = float((out - fraction * ref).norm() / norm.sqrt())

        _, _, radius, _ = geometry_axes(geometry)
        gap = radius.numpy() <= 1
        halo = 2 * int(4 * sigma + .5) + 1
        eroded = binary_erosion(gap, structure=np.ones((halo, halo), bool))
        np.testing.assert_array_equal(
            soft["sensor_target"][0, :, CORE, CORE].numpy()[:, eroded],
            soft["sensor_target"][1, :, CORE, CORE].numpy()[:, eroded],
        )
        torch.testing.assert_close(
            soft["sensor_target"][4, :, CORE, CORE], sharp["sensor_target"][4, :, CORE, CORE], atol=0, rtol=0
        )
        period, angle = geometry["periods"][1], geometry["angles"][1]
        records.append({
            "update": index, "source_id": previous["source_id"], "sigma_native_px": sigma, "iso": previous["iso"],
            "weak_period": period, "sharp_coefficient_norm_DN16": float(norm.sqrt() * 65535),
            "measured_fraction": fraction, "discrete_Gaussian_response": modulation(sigma, period, angle),
            "opposite_phase_fraction": phase, "exact_gap_pixels": int(eroded.sum()),
        })
        if len(records) % 32 == 0:
            print(f"Actual blur target groups {len(records)}/256", flush=True)
    assert len(records) == 256
    assert len({r["source_id"] for r in records}) == 256
    result = summarize(records)
    assert all(g["all"]["count"] == 128 for g in result.values())
    write_json(ROOT / "training-optics-audit.json", {
        "driver": reference(__file__), "plan": proof, "sharp_trace": prior["trace"],
        "summary": result, "rows": records, "elapsed_s": time.monotonic() - start,
        "scope": "All 256 blurred planted-wire groups, comparing exact clean targets on the same regional quadrature banks.",
    })


if __name__ == "__main__":
    main()
