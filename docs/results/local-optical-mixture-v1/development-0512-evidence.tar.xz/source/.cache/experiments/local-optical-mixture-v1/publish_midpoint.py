"""Package the matched midpoint and the finer-period data-preflight evidence."""

from pathlib import Path
import shutil
import sys
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, CACHE, ROOT

sys.path.insert(0, str(CACHE / "sensor-optical-transfer-v1"))
from summarize_optical import interval, source_bootstrap

REPO = ROOT.parents[2]
DEST = REPO / "docs/results" / ROOT.name
ASSETS = REPO / "docs/assets/local-optical-mixture-midpoint"
CANDIDATE = CACHE / "local-optical-fine-data-v1"
CONTROL = "regional-aligned"
FIELDS = (
    "sharp_normalized_fundamental_response", "fundamental_response",
    "gap_continuing_strong_RMS_DN16", "fundamental_false_RMS_DN16", "exact_flat_RMS_DN16",
)
DOSES = ("0.0", "0.55", "0.85")


def changes(earlier, mid):
    assert earlier["shared_noise_inputs"] == mid["shared_noise_inputs"]
    assert earlier["training_plan"] == mid["training_plan"]
    current = {r["id"]: r for r in mid["rows"]}
    previous = {r["id"]: r for r in earlier["rows"]}
    assert len(current) == len(previous) == 32 and set(current) == set(previous)
    for name, sample in current.items():
        assert sample["family"] == previous[name]["family"]
        assert sample["sharp_fundamental_RMS_DN16"] == previous[name]["sharp_fundamental_RMS_DN16"]
        for dose in DOSES:
            assert sample["scores"][dose]["local50k"] == previous[name]["scores"][dose]["local50k"]

    rng = np.random.default_rng(202611200013)
    result = {}
    for field in FIELDS:
        rows = [r for r in mid["rows"] if field in r["scores"]["0.0"][ARM]]
        sampled = source_bootstrap(rows, rng)
        by_dose = {}
        for d in DOSES:
            mixed = np.array([r["scores"][d][ARM][field] for r in rows])
            sharp = np.array([r["scores"][d][CONTROL][field] for r in rows])
            earlier_mixed = np.array([previous[r["id"]]["scores"][d][ARM][field] for r in rows])
            earlier_sharp = np.array([previous[r["id"]]["scores"][d][CONTROL][field] for r in rows])
            by_dose[d] = {
                "step_512_minus_128_mixed": interval((mixed - earlier_mixed)[sampled].mean(1)),
                "step_512_minus_128_sharp": interval((sharp - earlier_sharp)[sampled].mean(1)),
                "matched_optics_effect_change": interval(
                    (mixed - sharp - earlier_mixed + earlier_sharp)[sampled].mean(1)
                ),
            }
        result[field] = {"source_count": len(rows), "doses": by_dose}
    return result


def copy_images(mid):
    ASSETS.mkdir(exist_ok=True)
    recorded = []
    for src in mid["rows"]:
        for board in src["native"]:
            for kind in ("triplet", "board"):
                original = board[kind]["image"]
                image = checked(original)
                path = ASSETS / image.name
                shutil.copyfile(image, path)
                assert reference(path)["sha256"] == original["sha256"]
                recorded.append({"repo_path": str(path.relative_to(REPO)), "sha256": original["sha256"]})
    assert len(recorded) == 4
    return recorded


def main():
    early_ref = reference(ARCHIVE / "development-0128/result.json")
    mid_ref = reference(ARCHIVE / "development-0512/result.json")
    early = read_json(checked(early_ref))
    mid = read_json(checked(mid_ref))
    assert (early["checkpoint_update"], mid["checkpoint_update"]) == (128, 512)
    dataset_ref = reference(CANDIDATE / "dataset-audit.json")
    dataset = read_json(checked(dataset_ref))
    assert dataset["plan"] == mid["training_plan"]
    assert len(dataset["audit"]["matched_wire_targets"]) == 512
    native = copy_images(mid)
    archive = DEST / "development-0512-evidence.tar.xz"
    optics_gen = reference(ROOT / "measure_training_optics.py")
    legacy_scorer = reference(ROOT / "review_development.py")
    assert mid["driver"] == legacy_scorer
    with tarfile.open(archive, "x:xz") as tar:
        for item in (dataset["generator"], dataset["driver"], optics_gen, legacy_scorer, reference(__file__),
                     reference(CANDIDATE / "work/regional_objective.py")):
            path = checked(item)
            tar.add(path, arcname="source/" + str(path.relative_to(REPO)), recursive=False)
        for item in (early_ref, mid_ref, dataset_ref, dataset["schedule"]):
            path = checked(item)
            tar.add(path, arcname=f"receipts/{path.parent.name}/{path.name}", recursive=False)
    write_json(DEST / "development-0512.json", {
        "review_source": mid_ref, "earlier_review_source": early_ref, "checkpoint_update": 512,
        "training_plan": mid["training_plan"], "checkpoints": mid["checkpoints"], "scores": mid["scores"],
        "paired_changes_from_128": changes(early, mid), "native_crops": native,
        "scope": mid["scope"], "data_preflight": {"source": dataset_ref, "result": dataset["audit"]["summary"]},
        "archive": {"repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
    })


if __name__ == "__main__":
    main()
