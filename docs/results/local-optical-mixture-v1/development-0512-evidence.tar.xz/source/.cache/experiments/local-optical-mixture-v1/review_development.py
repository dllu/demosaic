"""Read an intermediate EMA pair using only the existing optical development panel."""

import argparse
import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint
from prepare_optical import ARCHIVE, ARM, CACHE, OPTICAL, PRIOR, ROOT

sys.path.insert(0, str(CACHE / "sensor-optical-transfer-v1"))
from capture_optical import (
    ABSOLUTE, DOSES, LENGTH, WireFundamental, arrays, native_board, run_model, support_for_scoring,
)
from summarize_optical import interval, source_bootstrap

CONTROL = "regional-aligned"
PARENT = "local50k"
METRICS = (
    ABSOLUTE, LENGTH, "fundamental_intact_RMS_DN16", "gap_continuing_strong_RMS_DN16",
    "fundamental_false_RMS_DN16", "exact_flat_RMS_DN16",
)
NATIVE = {"long-01", "long-10"}
LABELS = ("Noisy Malvar", "Sharp regional", "Mixed optics", "Exact GT")


def scores(rows):
    rng = np.random.default_rng(202611200002)
    ranked = sorted(rows, key=lambda row: row["sharp_fundamental_RMS_DN16"])
    output = {}
    for subset, selected in (("all", rows), ("faintest_half", ranked[:len(ranked) // 2])):
        stats = {}
        for key in METRICS:
            sample = [row for row in selected if key in row["scores"]["0.0"][ARM]]
            if not sample:
                continue
            sample_ix = source_bootstrap(sample, rng)
            values = {
                name: {str(sigma): np.asarray([
                    row["scores"][str(sigma)][name][key] for row in sample
                ])[sample_ix].mean(1) for sigma in DOSES}
                for name in (PARENT, CONTROL, ARM)
            }
            effect = {}
            for baseline in (PARENT, CONTROL):
                delta = {s: measured - values[baseline][s] for s, measured in values[ARM].items()}
                effect[baseline] = {
                    "paired": {s: interval(d) for s, d in delta.items()},
                    "interaction_vs_sharp": {s: interval(d - delta["0.0"]) for s, d in delta.items()},
                }
            stats[key] = {
                "n": len(sample), "means": {name: {s: interval(v) for s, v in measured.items()}
                                           for name, measured in values.items()},
                "mixed_minus_baseline": effect,
            }
        output[subset] = stats
    return output


def load_pair(plan_ref, checkpoint_pair, step):
    plan = read_json(checked(plan_ref))
    models = {}
    for label, binding in checkpoint_pair.items():
        model, state = load_scene_checkpoint(checked(binding), expected_sha256=binding["sha256"], weights="ema")
        assert state["mode"] == "none" and state["step"] == step and state["training_arm"] == label
        assert state["DINO_sha256"] == plan["DINO_sha256"]
        assert state["continued_from"] == plan["parent"]
        assert state["plan"] == (plan_ref if label == ARM else plan["original_plan"])
        models[label] = _stage_tiled_cuda(model.eval(), torch.device("cuda"))
    return models


def compare(photo, snapshots, sharp_ref, historical, models, root):
    case = photo["case"]
    sharp = arrays(case["input"])
    geometry = case["fixture"]["geometry"]
    support = support_for_scoring(sharp["support"])
    original_metric = WireFundamental(sharp | {"support": support}, geometry)
    native = []
    results = {}
    for sigma in DOSES:
        token = str(sigma)
        if sigma:
            observation = checked(snapshots["observations"][token])
            data = arrays(snapshots["observations"][token])
            op = WireFundamental(data | {"support": support}, geometry)
            old = run_model(models[CONTROL], CONTROL, data, case["profile"])
        else:
            observation = checked(case["input"])
            data, op = sharp, original_metric
            old = np.load(checked(sharp_ref), allow_pickle=False)
            if case["id"] == "long-00":
                regenerated = run_model(models[CONTROL], CONTROL, data, case["profile"])
                np.testing.assert_array_equal(regenerated, old)
        new = run_model(models[ARM], CONTROL, data, case["profile"])
        assert new.shape == old.shape == data["target"].shape and np.isfinite(new).all() and np.isfinite(old).all()
        results[token] = {
            PARENT: historical["scores"][token],
            CONTROL: op(old) | {ABSOLUTE: original_metric(old)[LENGTH]},
            ARM: op(new) | {ABSOLUTE: original_metric(new)[LENGTH]},
        }
        if case["id"] in NATIVE and sigma == .85:
            camera = {k: data[k][None] for k in ("wb", "matrix", "colors")}
            camera["packed"] = data["packed"][:1]
            crop = native_board(
                root / "native", f'{case["id"]}-sigma-{sigma:g}',
                [noisy_malvar(camera)[0], old[0], new[0], data["target"][0]], camera,
                {"fixture": case["fixture"], "model_query_xywh": case["box"],
                 "ISO_profile": case["profile"], "observation": reference(observation), "dose_native_px": sigma},
                labels=LABELS, triplet_indices=(0, 2, 3),
            )
            native.append(crop)
    return {
        "id": case["id"], "family": geometry["family"], "scores": results, "native": native,
        "sharp_fundamental_RMS_DN16": float(np.sqrt(original_metric.clean_norm / original_metric.intact.sum()) * 65535),
    }


@torch.inference_mode()
def main(step):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    folder = f"step-{step:04d}"
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    saved_ref = reference(ARCHIVE / "train" / folder / "checkpoint.json")
    saved = read_json(checked(saved_ref))
    prior_ref = reference(PRIOR / "train" / folder / "checkpoint.json")
    prior = read_json(checked(prior_ref))
    assert saved["plan"] == plan_ref and prior["plan"] == plan["original_plan"]
    assert saved["step"] == prior["step"] == step < plan["steps"]
    checkpoints = saved["arms"] | {CONTROL: prior["arms"][CONTROL]}
    matches = reference(PRIOR / f"review-{step:04d}/result.json")
    after = read_json(checked(matches))
    assert after["checkpoints"][CONTROL] == checkpoints[CONTROL] and after["checkpoints"][PARENT] == plan["parent"]
    assert after["checkpoint_pair"] == prior_ref and after["weights"] == "EMA"
    assert after["precision"] == "CUDA IEEE FP32" and after["step"] == step

    optical_plan = read_json(checked(plan["review_inputs"]))
    samples_ref = optical_plan["optical_shared_noise"]
    samples = read_json(checked(samples_ref))
    assert samples["checkpoint"] == plan["parent"]
    historic_ref = reference(OPTICAL / "coupled/result.json")
    historic = read_json(checked(historic_ref))
    assert historic["samples"] == samples_ref
    shared = {x["id"]: x for x in samples["inputs"]}
    by_id = {x["id"]: x for x in historic["rows"]}
    assert len(shared) == len(by_id) == len(after["offgrid_predictions"]) == 32
    assert samples["standard_input_plan"] == optical_plan["optical_same_seed"]
    assert all(row["case"]["input"] == dose["inputs"]["0.0"] for row, dose in zip(
        after["offgrid_predictions"], read_json(checked(samples["standard_input_plan"]))["inputs"], strict=True
    ))

    output = ARCHIVE / f"development-{step:04d}"
    output.mkdir(exist_ok=True)
    (output / "native").mkdir(exist_ok=True)
    models = load_pair(plan_ref, checkpoints, step)
    started = time.monotonic()
    records = []
    with ieee_fp32():
        for photo in after["offgrid_predictions"]:
            key = photo["case"]["id"]
            dest = output / f"{key}.json"
            if dest.exists():
                item = read_json(dest)
                assert item["checkpoints"] == checkpoints and item["shared_noise_inputs"] == samples_ref
            else:
                item = compare(photo, shared[key], photo["predictions"][CONTROL], by_id[key], models, output)
                item.update(checkpoints=checkpoints, shared_noise_inputs=samples_ref)
                write_json(dest, item)
            records.append(item)
            if len(records) % 4 == 0:
                print(f"Update {step} on development sources {len(records)}/32", flush=True)
    write_json(output / "result.json", {
        "driver": reference(__file__), "training_plan": plan_ref, "mixed_checkpoint": saved_ref,
        "sharp_checkpoint": prior_ref, "checkpoints": checkpoints | {PARENT: plan["parent"]},
        "checkpoint_update": step, "historical_sharp_inputs_and_outputs": matches,
        "shared_noise_inputs": samples_ref, "local50k_coupled_scores": historic_ref,
        "scope": "32 previously evaluated optical development photos, separate frozen confirmation reserved",
        "precision": "CUDA IEEE FP32 EMA",
        "rows": records, "scores": scores(records), "wall_seconds": time.monotonic() - started,
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("update", type=int)
    main(parser.parse_args().update)
