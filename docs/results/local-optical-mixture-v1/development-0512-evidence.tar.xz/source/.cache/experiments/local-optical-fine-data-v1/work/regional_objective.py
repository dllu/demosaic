"""Training-only spatial supervision for an intact and an absent weak direction."""

import math

import torch

PATCH = 256
CORE_START = 80
CORE_STOP = 176
SIZE = 48
STRIDE = 24
CORE = slice(CORE_START, CORE_STOP)
EPS = 1e-4


def geometry_axes(wire):
    side = torch.arange(CORE_START, CORE_STOP, dtype=torch.float64) - (PATCH - 1) / 2
    y, x = torch.meshgrid(side, side, indexing="ij")
    dx, dy = x - wire["gap_center"][0], y - wire["gap_center"][1]
    angle = wire["gap_angle"]
    a, b = wire["gap_axes"]
    u = math.cos(angle) * dx + math.sin(angle) * dy
    v = -math.sin(angle) * dx + math.cos(angle) * dy
    rho = torch.hypot(u / a, v / b)
    phases = [
        math.tau * ((x * math.cos(theta) + y * math.sin(theta)) / period + phase)
        for theta, period, phase in zip(wire["angles"], wire["periods"], wire["phases"], strict=True)
    ]
    return x, y, rho, phases


def projector(weights, nuisance, candidate):
    """Project out the plane and competing wire on the same weighted pixels."""
    weights = weights.flatten()
    active = weights > 0
    if int(active.sum()) < 96 or float(weights.norm()) < 2:
        return None
    nuisance = nuisance.reshape(-1, nuisance.shape[-1])
    candidate = candidate.reshape(-1, candidate.shape[-1])
    basis, scale = torch.linalg.qr(nuisance * weights[:, None], mode="reduced")
    if float(scale.diag().abs().min()) < 1e-7:
        return None
    direction = candidate * weights[:, None]
    direction -= basis @ (basis.T @ direction)
    axes, scale = torch.linalg.qr(direction, mode="reduced")
    if float(scale.diag().abs().min()) < 1e-7:
        return None
    return (axes * weights[:, None] / weights.norm()).float()


def projections(wire):
    """Build regional held-direction contrasts entirely from clean training geometry."""
    x, y, rho, (strong, weak) = geometry_axes(wire)
    curves = [torch.ones_like(x), x / 32, y / 32]
    for k in (1, 2, 3):
        curves.extend(((strong * k).cos(), (strong * k).sin()))
    nuisance = torch.stack(curves, dim=-1)
    target = torch.stack((weak.cos(), weak.sin()), dim=-1)
    intact = ((rho - 1) * 2.5).clamp(0, 1)
    missing = (1 - rho.square()).clamp_min(0)
    t = torch.hann_window(SIZE, periodic=False, dtype=torch.float64)
    taper = t[:, None] * t[None]
    masks = []
    for dy in range(0, len(x) - SIZE + 1, STRIDE):
        for dx in range(0, len(x) - SIZE + 1, STRIDE):
            region = (slice(dy, dy + SIZE), slice(dx, dx + SIZE))
            response = projector(taper * intact[region], nuisance[region], target[region])
            absence = projector(taper * missing[region], nuisance[region], target[region])
            masks.append((region, response, absence))
    assert any(item[1] is not None for item in masks)
    return masks


def loss(prediction, batch, banks, luminance):
    """Measure the pair's response and absolute error where the weak wire is absent."""
    clean = batch["sensor_target"][:4, :, CORE, CORE]
    weights = (luminance @ batch["matrix"][0]) * batch["wb"][0]
    error = ((prediction[:4, :, CORE, CORE].float() - clean) * weights[None, :, None, None]).sum(1)
    valid = ((clean >= 0) & (clean < .98)).all(dim=1)
    response_terms = []
    absent_terms = []
    gap_terms = []
    for region, response, gap in banks:
        residual = error[(slice(None), *region)].flatten(1)
        mask = valid[(slice(None), *region)].flatten(1)
        if response is not None:
            included = response.abs().sum(1) > 0
            supported = (mask | ~included[None]).all(dim=1)
            projected = residual @ response
            pair = projected[0:4:2] - projected[1:4:2]
            response_terms.append(robust(pair.mean(dim=0)) * supported.all())
            # The same template applies to the withheld weak direction,
            # using its exact background as the absolute target per draw.
            absent_terms.append((robust(projected[1:4:2]) * supported[1:4:2]).mean())
        if gap is not None:
            included = gap.abs().sum(1) > 0
            supported = (mask | ~included[None]).all(dim=1)
            gap_terms.append((robust(residual @ gap) * supported).mean())
    zero = error.sum() * 0
    response = torch.stack(response_terms).mean() if response_terms else zero
    absent = torch.stack(absent_terms).mean() if absent_terms else zero
    if gap_terms:
        absent = 0.5 * (absent + torch.stack(gap_terms).mean())
    return response, absent


def robust(term):
    return (term.square().sum(dim=-1) + EPS**2).sqrt() - EPS
