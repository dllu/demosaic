"""Build and validate a fine-period variant of the matched optics data schedule."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import random
import shutil
import sys
import time

import numpy as np
from scipy.ndimage import binary_erosion
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent
PARENT = CACHE / "local-optical-mixture-v1"
SEED = 202611200010
BAND = (6.5, 11.5)
OPTICAL_TEST_BAND = (7.2, 9.25)
TREATMENT = "fine_weak_periods"

sys.path.insert(0, str(PARENT))
from measure_training_optics import coefficient, distribution


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


def source_snapshot(plan):
    base = checked(plan["shared_driver"])
    root = HERE / "work"
    root.mkdir()
    objective = base.with_name("regional_objective.py")
    assert reference(objective)["sha256"] == plan["frozen_files"][str(objective)]
    shutil.copyfile(objective, root / objective.name)
    src = base.read_text()
    src = replace_once(
        src, "def wire_pair(photo, rng, *, strong_continues=None):",
        "def wire_pair(photo, rng, *, strong_continues=None, fine_weak_periods=None):",
    )
    marker = "    periods = (rng.uniform(7, 29), rng.uniform(6, 25))\n"
    src = replace_once(src, marker, marker + '''
    if fine_weak_periods is not None:
        low, high = fine_weak_periods
        quantile = (periods[1] - 6.0) / 19.0
        periods = (periods[0], low + (high - low) * quantile)
''')
    src = replace_once(
        src, '            crop, rng, strong_continues=case.get("strong_continues")\n',
        '''            crop, rng, strong_continues=case.get("strong_continues"),
            fine_weak_periods=case.get("fine_weak_periods"),
''',
    )
    dst = root / base.name
    compile(src, str(dst), "exec")
    dst.write_text(src)
    return dst


def schedule(binding):
    base = read_json(checked(binding))
    cells = defaultdict(list)
    for i, row in enumerate(base):
        if row["kind"] == "wire":
            key = tuple(row[k] for k in ("iso", "pattern", "law", "optical_sigma"))
            cells[key].append(i)
    assert len(cells) == 48
    rng = random.Random(SEED)
    change = set()
    for ids in cells.values():
        assert len(ids) % 2 == 0
        change.update(rng.sample(ids, len(ids) // 2))
    assert len(change) == 256
    candidate = [r | {TREATMENT: BAND} if i in change else r for i, r in enumerate(base)]
    path = HERE / "fine-schedule.json"
    write_json(path, candidate)
    return reference(path), candidate


def verify(sharp_trace, original_driver, treatment_driver, plan, candidate):
    torch.set_num_threads(2)
    sys.path.insert(0, str(treatment_driver.parent))
    from train_local_paired_continuation import CORE, observations
    from regional_objective import geometry_axes, projections

    with checked(sharp_trace).open() as stream:
        recorded = [json.loads(line) for line in stream if line.strip()]
    assert len(recorded) == len(candidate)
    start = time.monotonic()
    wire = []
    unchanged = Counter()
    for i, (slot, rec) in enumerate(zip(candidate, recorded, strict=True), 1):
        if slot["kind"] != "wire" and len(unchanged) >= 8:
            continue
        key = (slot["pattern"], slot["law"])
        if slot["kind"] != "wire" and key in unchanged:
            continue
        before, original = observations({k: v for k, v in slot.items() if k != TREATMENT},
                                        i, pair_draws=2, seed=plan["seed"])
        original_wire = original["geometry"].get("wire")
        if TREATMENT not in slot:
            if slot["optical_sigma"] == 0:
                assert original["arrays"] == rec["arrays"]
            if original_wire is None:
                unchanged[key] += 1
                continue
            new_wire = original_wire
            ratio, flat, gap = 1.0, True, True
            isolate = None
        else:
            after, fields = observations(slot, i, pair_draws=2, seed=plan["seed"])
            assert all(fields[k] == original[k] for k in fields if k not in {"geometry", "arrays"})
            new_wire = fields["geometry"]["wire"]
            assert all(new_wire[k] == original_wire[k] for k in new_wire if k != "periods")
            assert new_wire["periods"][0] == original_wire["periods"][0]
            assert BAND[0] <= new_wire["periods"][1] <= BAND[1]
            for k in ("target", "sensor_target"):
                torch.testing.assert_close(after[k][1::2], before[k][1::2], atol=0, rtol=0)
                torch.testing.assert_close(after[k][4], before[k][4], atol=0, rtol=0)
                assert not torch.equal(after[k][0], before[k][0])
            for k in ("packed", "variance"):
                torch.testing.assert_close(after[k][4:], before[k][4:], atol=0, rtol=0)
                if slot["law"] == "independent":
                    torch.testing.assert_close(after[k][1:4:2], before[k][1:4:2], atol=0, rtol=0)
            _, _, radius, _ = geometry_axes(new_wire)
            halo = 2 * int(4 * slot["optical_sigma"] + .5) + 1
            protected = binary_erosion(radius.numpy() <= 1, structure=np.ones((halo, halo), bool))
            assert np.count_nonzero(protected) >= 64
            np.testing.assert_array_equal(
                after["sensor_target"][0, :, CORE, CORE].numpy()[:, protected],
                after["sensor_target"][1, :, CORE, CORE].numpy()[:, protected],
            )
            original_coeff = coefficient(before, projections(original_wire), CORE).norm()
            new_banks = projections(new_wire)
            new_coeff = coefficient(after, new_banks, CORE)
            assert original_coeff > 0 and new_coeff.norm() > 0
            ratio, flat, gap = float(new_coeff.norm() / original_coeff), True, True
            isolate = 1.0
            if slot["optical_sigma"]:
                sharp, _ = observations(slot | {"optical_sigma": 0.}, i, pair_draws=2, seed=plan["seed"])
                sharp_coeff = coefficient(sharp, new_banks, CORE)
                isolate = float(new_coeff @ sharp_coeff / (sharp_coeff @ sharp_coeff))
        wire.append({
            "index": i, "source_id": rec["source_id"], "sigma": slot["optical_sigma"],
            "original_period": original_wire["periods"][1], "candidate_period": new_wire["periods"][1],
            "assigned_fine": TREATMENT in slot, "ratio_of_post_optical_norms": ratio, "retained_after_blur": isolate,
            "flat_control_exact": flat, "eroded_gap_exact": gap,
        })
        if len(wire) % 64 == 0:
            print(f"Checked wire controls {len(wire)}/512", flush=True)

    assert len(wire) == 512 and len(unchanged) == 8
    counts = {}
    for tag, selected in (
        ("all_wires", wire), ("blurred_wires", [r for r in wire if r["sigma"]]),
        ("sharp_wires", [r for r in wire if not r["sigma"]]),
    ):
        counts[tag] = {
            "groups": len(selected), "changed": sum(r["assigned_fine"] for r in selected),
            "original_inside_test_band": sum(OPTICAL_TEST_BAND[0] <= r["original_period"] <= OPTICAL_TEST_BAND[1] for r in selected),
            "candidate_inside_test_band": sum(OPTICAL_TEST_BAND[0] <= r["candidate_period"] <= OPTICAL_TEST_BAND[1] for r in selected),
        }
    for width in (0.4, 0.65):
        subset = [r for r in wire if r["assigned_fine"] and r["sigma"] == width]
        assert len(subset) == 64
        counts[str(width)] = {"fine_groups": len(subset),
                              "retained_after_blur": distribution([r["retained_after_blur"] for r in subset])}
    return {"matched_wire_targets": wire, "natural_probe_groups": len(unchanged), "summary": counts,
            "seconds": time.monotonic() - start, "prior_generator": reference(original_driver)}


def main():
    plan_ref = reference(PARENT / "plan.json")
    plan = read_json(checked(plan_ref))
    original = checked(plan["shared_driver"])
    snapshot = source_snapshot(plan)
    schedule_ref, candidate = schedule(plan["schedule"]["train"])
    receipt = read_json(checked(plan["original_completion"]))
    audit = verify(receipt["trace"], original, snapshot, plan, candidate)
    write_json(HERE / "dataset-audit.json", {
        "plan": plan_ref, "prior_schedule": plan["schedule"]["train"], "schedule": schedule_ref,
        "generator": reference(snapshot), "driver": reference(__file__),
        "optical_test_period_band": OPTICAL_TEST_BAND, "candidate_period_band": BAND, "assignment_seed": SEED,
        "scope": "Frozen alternate data recipe on the same ordered sources. CPU input and clean-target audit.",
        "audit": audit,
    })
    print(json.dumps(audit["summary"], indent=2), flush=True)


if __name__ == "__main__":
    main()
