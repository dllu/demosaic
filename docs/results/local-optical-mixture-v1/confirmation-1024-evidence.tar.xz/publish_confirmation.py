"""Publish primary held-out optical scores with the two preselected native crops."""

from pathlib import Path
import shutil
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, ROOT

REPO = ROOT.parents[2]
DOC = REPO / "docs"
DEST = DOC / "results" / ROOT.name
ASSETS = DOC / "assets/local-optical-mixture-endpoint"
CONTROL = "regional-aligned"


def main():
    source = reference(ARCHIVE / "optical-review/confirmation.json")
    result = read_json(checked(source))
    training_ref = reference(DEST / "training-1024.json")
    training = read_json(checked(training_ref))
    assert result["finished_training"] == training["training_receipt"]
    assert result["checkpoints"][ARM] == training["checkpoint"]
    assert result["checkpoints"][CONTROL] == training["matched_control"]
    assert result["weights"] == "CUDA IEEE FP32 EMA"
    assert len(result["rows"]) == 24 and all(r["id"].startswith("fresh-") for r in result["rows"])
    pending = read_json(checked(result["source_binding"]))
    lock = read_json(checked(pending["plan"]))
    assert lock["training_plan"] == training["training_plan"]
    assert result["source_binding"] == reference(ARCHIVE / "confirmation/inputs.json")
    chosen = [b for b in result["native"] if b["dose_native_px"] == .85]
    assert len(chosen) == 2
    figures = []
    for item in chosen:
        for kind in ("board", "triplet"):
            img = item[kind]["image"]
            file = checked(img)
            dest = ASSETS / file.name
            shutil.copyfile(file, dest)
            assert reference(dest)["sha256"] == img["sha256"]
            figures.append({"repo_path": str(dest.relative_to(REPO)), "sha256": img["sha256"]})
    archive = DEST / "confirmation-1024-evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for key, ref in (
            ("confirmation.json", source), ("inputs.json", result["source_binding"]), ("plan.json", pending["plan"]),
            ("review_optical.py", result["driver"]), ("publish_confirmation.py", reference(__file__)),
            ("optical_response_balance.py", reference(ROOT / "optical_response_balance.py")),
        ):
            tar.add(checked(ref), arcname=key, recursive=False)
    write_json(DEST / "confirmation-1024.json", {
        "scope": "24 fresh optical sources at 3 blur doses with shared photons and read noise",
        "source": source, "training": training_ref, "archive": {
            "repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"],
        },
        "checkpoints": result["checkpoints"], "primary_dose": .85,
        "scores": result["scores"], "native": figures, "native_primary_triplets_inspected": 2,
        "source_plan": pending["plan"], "weights": result["weights"],
    })
    print("Bound 24 fresh optical test sources and four reviewed primary-dose figures.", flush=True)


if __name__ == "__main__":
    main()
