"""Bind the completed earlier optical replay and independent response-matching comparison."""

from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, ROOT

REPO = ROOT.parents[2]
OUTPUT = REPO / "docs/results" / ROOT.name
DATA = ARCHIVE / "optical-review"
CONTROL = "regional-aligned"


def main():
    replay_ref = reference(DATA / "previous.json")
    replay = read_json(checked(replay_ref))
    matched_ref = reference(DATA / "response-balance.json")
    matched = read_json(checked(matched_ref))
    fresh_artifact = reference(OUTPUT / "confirmation-1024.json")
    fresh = read_json(checked(fresh_artifact))
    assert matched["inputs"] == {"previous": replay_ref, "confirmation": fresh["source"]}
    assert replay["checkpoints"] == matched["checkpoints"] == fresh["checkpoints"]
    assert len(replay["rows"]) == 32 and all(r["id"].startswith("long-") for r in replay["rows"])
    assert matched["calibration_ids"] == [r["id"] for r in replay["rows"]]
    primary = read_json(checked(fresh["source"]))
    assert matched["confirmation_ids"] == [row["id"] for row in primary["rows"]]
    assert len(matched["confirmation_ids"]) == 24 and matched["dose_pixels"] == .85
    assert not set(matched["calibration_ids"]).intersection(matched["confirmation_ids"])
    assert set(matched["fit"]["endpoints"]) == {ARM, CONTROL}
    if matched["fit"]["calibrated"]:
        assert set(matched["fit"]["gains"]) == {ARM, CONTROL}
        assert all(0 < v <= 1 for v in matched["fit"]["gains"].values())
        assert matched["confirmation"]["sharp_normalized_fundamental_response"]["source_count"] == 24

    bundle = OUTPUT / "optical-replay-1024-evidence.tar.xz"
    with tarfile.open(bundle, "x:xz") as tar:
        for name, binding in (
            ("previous.json", replay_ref), ("response-balance.json", matched_ref),
            ("review.py", replay["driver"]), ("balance.py", matched["driver"]), ("publication.py", reference(__file__)),
        ):
            tar.add(checked(binding), arcname=name, recursive=False)
    write_json(OUTPUT / "optical-replay-1024.json", {
        "scope": "32 earlier optical sources plus response matching evaluated on the 24 fresh optical sources",
        "earlier_replay": replay_ref, "fresh_publication": fresh_artifact, "checkpoints": replay["checkpoints"],
        "response_balance_source": matched_ref, "response_balance": matched,
        "earlier_scores": replay["scores"], "archive": {
            "repo_path": str(bundle.relative_to(REPO)), "sha256": reference(bundle)["sha256"],
        },
    })


if __name__ == "__main__":
    main()
