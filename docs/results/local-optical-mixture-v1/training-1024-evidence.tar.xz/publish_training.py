"""Bind and publish the completed 1,024-update checkpoint and training evidence."""

from pathlib import Path
import tarfile

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from prepare_optical import ARCHIVE, ARM, ROOT, PRIOR

REPO = ROOT.parents[2]
DEST = REPO / "docs/results" / ROOT.name


def main():
    torch.set_num_threads(2)
    complete = reference(ARCHIVE / "train/completed.json")
    audit_ref = reference(ROOT / "completed-audit.json")
    completed = read_json(checked(complete))
    audit = read_json(checked(audit_ref))
    assert audit["completion"] == complete and audit["plan"] == completed["plan"]
    assert completed["step"] == audit["attempt_completed_updates_verified"] == 1024
    plan_ref = completed["plan"]
    plan = read_json(checked(plan_ref))
    control = read_json(checked(plan["original_completion"]))
    assert control["step"] == completed["step"] and control["parent"] == completed["parent"] == plan["parent"]
    checkpoint = completed["checkpoints"][ARM]
    raw = torch.load(checked(checkpoint), map_location="cpu", weights_only=True)
    assert raw["step"] == 1024 and raw["training_arm"] == ARM and raw["mode"] == "none"
    assert raw["plan"] == plan_ref and raw["continued_from"] == plan["parent"]
    assert raw["DINO_sha256"] == plan["DINO_sha256"] and completed["DINO_unchanged"]
    assert raw["model"].keys() == raw["ema"].keys()
    for stream in ("model", "ema"):
        assert all(torch.isfinite(t).all() for t in raw[stream].values())
    different = sum(not torch.equal(raw["model"][k], raw["ema"][k]) for k in raw["model"])
    assert different > 0
    assert all(torch.isfinite(t).all() for entry in raw["optimizer"]["state"].values()
               for t in entry.values() if isinstance(t, torch.Tensor))
    stem = "training-1024"
    archive = DEST / f"{stem}-evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for item in (complete, audit_ref, completed["trace"], completed["log"], reference(__file__)):
            p = checked(item)
            tar.add(p, arcname=p.name, recursive=False)
    write_json(DEST / f"{stem}.json", {
        "scope": "Completed mixed-optics arm, training integrity and exact schedule only",
        "archive": {"repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "training_receipt": complete, "training_audit": audit_ref, "training_plan": plan_ref,
        "parent": plan["parent"], "matched_control": plan["original_control"],
        "checkpoint": checkpoint, "raw_and_ema_finite": True, "distinct_weight_tensors": different,
        "frozen_DINO_sha256": raw["DINO_sha256"], "effective_recipe": plan["optics"],
        "steps": completed["step"], "observations": completed["native_observations_per_arm"],
        "training_wall_seconds": completed["training_wall_seconds_including_checkpoint"],
        "model_step_wall_seconds": completed["arm_seconds"][ARM], "review_inputs": plan["review_inputs"],
        "semantic_status": "training complete, endpoint reviews separate",
    })
    print("Verified final raw/EMA and AdamW tensors, complete trace, and exact source schedule.", flush=True)


if __name__ == "__main__":
    main()
