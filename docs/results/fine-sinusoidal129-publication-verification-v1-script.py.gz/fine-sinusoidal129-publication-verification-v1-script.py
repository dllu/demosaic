"""Independent final evidence/source/pixel/summary/link check; no inference."""
import gzip
import re
import tarfile
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
baseline = repo / '.cache/experiments/neural-nuisance-fine-phase129-pilot-v1'
binding = repo / 'docs/results/neural-nuisance-fine-sinusoidal129-v1/publication.json'
output = repo / 'docs/results/fine-sinusoidal129-publication-verification-v1.json'
p = read_json(binding)
assert p['viewing']['actually_viewed'] and p['viewing']['figures'] == 46
assert p['viewing']['contact_sheets'] == 14
assert len(p['archives']) == 208 and len(p['images']) == 46
for item in p['archives']:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
for item in p['images']:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
for key in ['viewer', 'original_viewer', 'original_preparation', 'extra_preparation']:
    checked(p[key])
with tarfile.open(checked(p['source_snapshot']), 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == p['source_files_exact'] == 167
    for member in members:
        data = tar.extractfile(member).read()
        assert data == (root / 'work' / member.name).read_bytes()
        assert data == (repo / member.name).read_bytes()

seen = set()
channels = 0
for group, ref in p['viewing']['manifests'].items():
    m = read_json(checked(ref))
    indices = []
    for batch_ref in p['viewing']['batches']:
        batch = read_json(checked(batch_ref))
        assert batch['actually_viewed'] and batch['notes']
        if batch['group'] == group:
            assert batch['manifest'] == ref
            indices.extend(batch['sheets'])
            for sheet_ref in batch['sheet_images']:
                checked(sheet_ref)
    assert sorted(indices) == list(range(len(m['sheets'])))
    for sheet in m['sheets']:
        pixels = np.asarray(Image.open(checked(sheet['image'])).convert('RGB'))
        for cell in sheet['cells']:
            source = np.asarray(Image.open(checked(cell['source'])).convert('RGB'))
            assert checked(cell['published']).read_bytes() == checked(cell['source']).read_bytes()
            x, y, w, h = cell['xywh']
            assert source.shape == (h, w, 3)
            np.testing.assert_array_equal(pixels[y:y+h, x:x+w], source)
            assert cell['source']['path'] not in seen
            seen.add(cell['source']['path'])
            channels += source.size
assert seen == {f['original']['path'] for f in p['images']}

keys = ['weak_gain', 'strong_gain', 'quiet_error_RMS_DN16', 'weak_increment_error_RMS_DN16']
summaries = []
summary_fields = 0
for folder in [baseline, root]:
    scores = read_json(folder / 'finite-scores.json')['rows']
    summary = read_json(folder / 'summary-review/summary.json')
    for row in summary['means']:
        values = [r for r in scores if all(r[k] == row[k] for k in ['profile', 'placement', 'method'])]
        assert len(values) == 2
        for key in keys:
            assert abs(float(np.mean([r[key] for r in values])) - row[key]) < 1e-12
            summary_fields += 1
    summaries.append(summary)
parent_errors = []
for row in summaries[0]['means']:
    if row['method'] != 'V143':
        continue
    paired = next(r for r in summaries[1]['means'] if all(r[k] == row[k] for k in ['profile', 'placement', 'method']))
    parent_errors.extend(abs(row[k] - paired[k]) for k in keys)
assert max(parent_errors) == 0

comparisons = []
for profile, placement in [('iso400', 'far'), ('iso1600', 'far')]:
    for method in ['conditional-local-t2', 'local-t2']:
        pair = [next(r for r in s['means'] if (r['profile'], r['placement'], r['method']) == (profile, placement, method))
                for s in summaries]
        comparisons.append({'profile': profile, 'placement': placement, 'method': method,
                            'broad_only': {k: pair[0][k] for k in keys},
                            'broad_plus_fine': {k: pair[1][k] for k in keys}})
inputs = [read_json(folder / 'collection.json')['rows'] for folder in [baseline, root]]
assert len(inputs[0]) == len(inputs[1]) == 48
for a, b in zip(inputs[0], inputs[1], strict=True):
    assert a['id'] == b['id']
    for key in ['parent_values', 'packed_values', 'colors_values']:
        assert a[key] == b[key]
parity = read_json(checked(p['H1_control_parity']))
assert parity['all48_actual_input_parent_fingerprints_exact'] and parity['H1_arrays_byte_exact_values'] == 288

names = ['README.md', 'docs/current-model.md', 'docs/index.md', 'docs/research.md',
         'docs/weak-detail-literature-2026-11.md', 'docs/neural-guided-phase-pooling.md',
         'docs/neural-guided-phase-full-panel.md', 'docs/fine-frequency-proposals.md', 'docs/fine-sinusoidal-carriers.md', 'docs/experiments.md',
         'diary/2026-11-16-21-21-39-sinusoidal-fine-carriers.md', 'diary/index.md']
links = 0
for name in names:
    path = repo / name
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        target = target.split('#')[0]
        if not target or '://' in target:
            continue
        resolved = (path.parent / target).resolve()
        assert resolved == output or resolved.exists(), (name, target)
        links += 1
queue = read_json(repo / 'docs/results/guided-phase129-full-setup-v1/publication-queue-v1.json')
assert len(queue['archives']) == 6
for item in queue['archives']:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
setup = read_json(repo / 'docs/results/fine-sinusoidal129-setup-v1/publication.json')
assert len(setup['archives']) == 38
for item in setup['archives']:
    assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
with tarfile.open(checked(setup['frozen_source']['archive']), 'r:gz') as tar:
    assert len(tar.getmembers()) == len(setup['frozen_source']['members']) == 167
    for item in setup['frozen_source']['members']:
        assert tar.extractfile(item['member']).read() == checked(item['original']).read_bytes()
comparison = read_json(checked(p['comparison']))
assert comparison['paired_tiles'] == 50 and comparison['broad_diagnostic_arms_exact'] == 100
assert comparison['fine_geometry_arms_exact'] == 100
result = {
    'publication': reference(binding), 'script': reference(__file__),
    'archives_exact': len(p['archives']), 'images_exact': len(p['images']),
    'executed_source_members_exact_and_equal_current': len(members),
    'actually_viewed_sheets': 14, 'native_contact_RGB_channels_exact': channels,
    'paired_input_parent_fingerprints_exact': 48, 'H1_parity_outputs': 288,
    'independent_summary_fields': summary_fields, 'maximum_parent_summary_error': max(parent_errors),
    'primary_comparisons': comparisons, 'local_MD_links_checked': links,
    'separate_full_queue_archives_exact': 6, 'new_neural_forwards': 0,
    'admission_archives_exact': 38, 'admission_frozen_sources_exact': 167,
    'broad_diagnostic_arms_exact': 100, 'fine_geometry_arms_exact': 100,
    'scope': 'Adaptive48-case result, all46 native figures/14 sheets viewed. NN1600 errors lower with less weak response than fine phase; analytic response/errors regress. Cab grid persists/building bands increase, no faithful recovery or real-GT claim. Original44-image preparation/source/receipts and failed tests preserved. No full-run source edit or partial quality peek.',
}
write_json(output, result)
assert output.is_file()
print({k: v for k, v in result.items() if k not in ['primary_comparisons', 'scope']})
