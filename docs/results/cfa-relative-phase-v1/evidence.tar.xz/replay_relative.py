"""Score fit-side color waveform estimates and render the standing RAW controls."""

from pathlib import Path
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

from relative_phase import ARMS, LABELS, apply_relative, independence
import directional_chroma
import replay_chroma as replay

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-directional-chroma-v1")


def standing():
    fixed = reference(replay.FIXED)
    review = read_json(checked(fixed))
    rows = []
    for r in review["standing"]:
        sample = replay.arrays(r["input"])
        scene, colors, wb, matrix = (sample[key][0] for key in ("packed", "colors", "wb", "matrix"))
        p = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(r["local_ROI"])
        peaks = _spacing(scene, colors, *roi[:2], clearance=16)
        restored, info = apply_relative(p, roi, scene, roi, colors, peaks, r["noise"], wb, matrix)
        differences = {m: replay.rms(x - restored["conditional"]) for m, x in restored.items()}
        figures = []
        for v in r["displays"]:
            before = v["board"]
            exposure = v["exposure"]
            with Image.open(checked(before["image"])) as pic:
                base = np.asarray(pic)
            panes = {}
            for cell in before["panels"]:
                x, y, w, h = cell["png_xywh"]
                panes[cell["name"]] = base[y : y + h, x : x + w]
            images = [(k, panes[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            images += [
                (LABELS[k], replay.display(restored[k], wb, matrix, exposure))
                for k in ("conditional", "own_phase_sign", "transport", "affine", "field_sign")
            ]
            images += [
                (k, panes[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in panes
            ]
            img = Image.new("RGB", (8 + 168 * len(images), 192), "#eee")
            painter = ImageDraw.Draw(img)
            panels = []
            for j, (label, pixels) in enumerate(images):
                x = 8 + j * 168
                img.paste(Image.fromarray(pixels), (x, 24))
                painter.text((x, 5), label, fill="black")
                panels.append({"label": label, "xywh": [x, 24, 160, 160]})
            path = OUT / "standing" / f"{r['id']}-x{exposure:g}.png"
            img.save(path)
            figures.append(
                {
                    "image": reference(path),
                    "panels": panels,
                    "baseline": before,
                    "exposure": exposure,
                }
            )
        rows.append(
            {
                "id": r["id"],
                "input": r["input"],
                "raw": r["raw"],
                "noise": r["noise"],
                "roi": r["global_ROI"],
                "parent": r["predictions"]["local50k"],
                "differences_DN16": differences,
                "details": info,
                "views": figures,
            }
        )
        print(r["id"], differences, flush=True)
    return {"source": fixed, "rows": rows, "weights": review["checkpoints"]}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    for folder in ("exact", "standing"):
        (OUT / folder).mkdir(exist_ok=True)
    capture = reference(OUT / "inputs.json")
    sources = read_json(checked(capture))
    old = reference(PRIOR / "own-phase" / "review.json")
    prior = read_json(checked(old))
    matches = {f"prior_{k}": v["source"] for k, v in prior["panels"].items()}
    pairs = matches | sources["panels"]
    directional_chroma.ARMS = ARMS
    replay.ARMS = ARMS
    replay.LABELS = LABELS
    replay.apply_directional = apply_relative
    replay.OUT = OUT
    old_board = replay.native_board

    def native(folder, case, images, *args, **kwargs):
        kwargs["triplet_indices"] = (0, len(images) - 2, len(images) - 1)
        return old_board(folder, case, images, *args, **kwargs)

    replay.native_board = native
    real = standing()
    results = {}
    for key, p in pairs.items():
        rows = replay.photos(p, key)
        if key in matches:
            current = prior["panels"][key.removeprefix("prior_")]["rows"]
            for a, b in zip(current, rows, strict=True):
                assert a["id"] == b["id"]
                for before, after in zip(a["draws"], b["draws"], strict=True):
                    for method in set(before["scores"]) & set(after["scores"]):
                        assert before["scores"][method] == after["scores"][method]
        results[key] = {"source": p, "rows": rows, "summary": replay.summary(rows)}
    write_json(
        OUT / "result.json",
        {
            "driver": reference(__file__),
            "capture": capture,
            "prior": old,
            "operator": reference(HERE / "relative_phase.py"),
            "independent_fields": independence(),
            "standing": real,
            "results": results,
            "elapsed": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
