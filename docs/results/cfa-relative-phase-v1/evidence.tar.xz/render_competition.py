"""Render the changed coarse fence from the wider held color check."""

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from relative_competition import evaluate, ARMS
import replay_relative as review


def main():
    torch.set_num_threads(2)
    binding = reference(review.OUT / "competition" / "result.json")
    result = read_json(checked(binding))
    frozen = read_json(checked(result["standing"]["source"]))
    rows = []
    review.directional_chroma.ARMS = ARMS
    for expected in result["standing"]["rows"]:
        if expected["differences_DN16"]["compete"] == 0:
            continue
        row = next(r for r in frozen["standing"] if r["id"] == expected["id"])
        f = review.replay.arrays(row["input"])
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        raw, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        region = tuple(row["local_ROI"])
        peaks = _spacing(raw, colors, *region[:2], clearance=16)
        arms, info = evaluate(p, region, raw, region, colors, peaks, row["noise"], wb, matrix)
        assert info == expected["details"]
        assert (
            review.replay.rms(arms["compete"] - arms["conditional"])
            == expected["differences_DN16"]["compete"]
        )
        for board in row["displays"]:
            previous = board["board"]
            with Image.open(checked(previous["image"])) as im:
                original = np.asarray(im)
            panes = {}
            for cell in previous["panels"]:
                x, y, w, h = cell["png_xywh"]
                panes[cell["name"]] = original[y : y + h, x : x + w]
            exposure = board["exposure"]
            labels = {
                "conditional": "Local conditional",
                "field_sign": "Color field + sign",
                "compete": "Held color comparison",
            }
            views = [(k, panes[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            views += [
                (label, review.replay.display(arms[k], wb, matrix, exposure))
                for k, label in labels.items()
            ]
            views += [("ISO100 AHD reference", panes["ISO100 AHD reference"])]
            native = Image.new("RGB", (8 + 168 * len(views), 192), "#eee")
            painter = ImageDraw.Draw(native)
            footprint = []
            for j, (label, pixels) in enumerate(views):
                x = 8 + j * 168
                native.paste(Image.fromarray(pixels), (x, 24))
                painter.text((x, 5), label, fill="black")
                footprint.append({"title": label, "xywh": [x, 24, 160, 160]})
            name = review.OUT / "competition" / f"{row['id']}-x{exposure:g}-changed.png"
            native.save(name)
            rows.append(
                {
                    "image": reference(name),
                    "base_board": previous,
                    "panels": footprint,
                    "input": row["input"],
                    "noise": row["noise"],
                    "weights": frozen["checkpoints"],
                    "native_roi": row["global_ROI"],
                    "exposure": exposure,
                    "counts": info["competition"],
                }
            )
    assert len(rows) == 1
    write_json(
        review.OUT / "competition-board.json",
        {"driver": reference(__file__), "result": binding, "images": rows},
    )


if __name__ == "__main__":
    main()
