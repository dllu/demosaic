"""Offer the color field on green-supported windows where it beats neutral on held RAW."""

from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic._mesh_pooled import _rgb
from relative_phase import (
    ARMS,
    LABELS,
    _CORE,
    _POOLED_FOOTPRINT,
    _STRIDE,
    _WINDOW,
    _measure_nodes,
    _wave,
    _windows,
    base,
    fields,
    transported,
    fit_field,
    subfit,
    compose,
    apply_relative,
)
import replay_relative as report

OUT = report.OUT
METHOD = "compete"
BASE_CORRECTION = base._correction
BASE_PATCHES = base.channel_patches


def evaluate(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    # The review retains the published rescue arm alongside this wider offer.
    restored, info = apply_relative(parent, local, scene, roi, colors, peaks, noise, wb, matrix)
    if peaks is None:
        return restored | {METHOD: restored["field_sign"]}, info | {"competition": {}}
    x, y = roi[:2]
    global_wave = _wave(_POOLED_FOOTPRINT, peaks)
    wave = _wave(_WINDOW, peaks)
    greens, _, planes = fields(scene, colors, roi[:2])
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    last_green = None
    guides = {}
    count = {}
    difference = None

    def capture_green(*args):
        nonlocal last_green
        last_green = BASE_CORRECTION(*args)
        return last_green

    def compete(plane, site, phase, rival, prior, active, shot, read, nominal):
        nonlocal difference
        old, veto = BASE_PATCHES(plane, site, phase, rival, prior, active, shot, read, nominal)
        selected = active & ~veto
        if not selected.any():
            return old, veto
        d = int(np.array_equal(rival, wave[..., 0, :]))
        if d not in guides:
            nodes = [_measure_nodes(planes[p], global_wave, p, shot, read) for p in greens]
            guides[d] = transported(global_wave, nodes, d)
        pair = guides[d]
        samples = _windows(plane, _WINDOW // 2, _STRIDE // 2)[selected]
        bg = np.concatenate((base._FIT_BASIS, rival[base._FIT]), axis=-1)
        middle = np.concatenate((base._CENTER_BASIS, rival[_CORE]), axis=-1)
        field = tuple(
            _windows(
                fit_field(plane, pair, global_wave[..., 1 - d, :], site, shot, read, i),
                _WINDOW,
                _STRIDE,
            )[selected, ..., None]
            for i in (0, 1)
        )
        phase_windows = _windows(phase, _WINDOW, _STRIDE)[selected]
        neutral_amplitude = nominal[~veto[active]]
        reference = base.analyses(
            samples[:, 4:-4, 4:-4],
            phase_windows[:, base._FIT[0], base._FIT[1]],
            bg,
            site,
            shot,
            read,
            nominal=neutral_amplitude,
        )
        ref_center = base.analyses(
            samples[:, 8:-8, 8:-8],
            phase_windows[:, _CORE[0], _CORE[1]],
            middle,
            site,
            shot,
            read,
            nominal=neutral_amplitude,
        )
        compare = []
        for i, v in enumerate(field):
            a, s = subfit(
                samples[:, 4:-4, 4:-4], v[:, base._FIT[0], base._FIT[1]], bg, site, shot, read, i
            )
            _, c = subfit(
                samples[:, 8:-8, 8:-8],
                v[:, _CORE[0], _CORE[1]],
                middle,
                site,
                shot,
                read,
                i,
                supplied=a,
            )
            compare.append((s - reference[i][2] > 1.0) & (c - ref_center[i][2] > 0.2))
        measured = compose(samples, field, bg, middle, site, prior[selected], shot, read)(1.5)
        accept = compare[0] & compare[1] & np.any(measured, axis=(1, 2))
        if accept.any():
            r, c = site
            channel = colors[2 * ((y + r) % 2) + ((x + c) % 2)]
            if difference is None:
                difference = np.zeros((3, *last_green.shape))
            target = np.flatnonzero(selected)[accept]
            difference[channel, target] += measured[accept] - neutral[channel] * last_green[target]
            count[str(channel)] = count.get(str(channel), 0) + int(accept.sum())
        return old, veto

    try:
        base._correction = capture_green
        base.channel_patches = compete
        base.apply_delivery(parent, local, scene, roi, colors, peaks, noise, wb, matrix)
    finally:
        base._correction = BASE_CORRECTION
        base.channel_patches = BASE_PATCHES
    refined = restored["field_sign"]
    if difference is not None:
        refined = refined + np.stack([_rgb(d, np.ones(1), refined.dtype)[0] for d in difference])
    np.testing.assert_array_equal(refined[1], restored["conditional"][1])
    return restored | {METHOD: refined}, info | {"competition": count}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    prior = reference(OUT / "result.json")
    original = read_json(checked(prior))
    destination = OUT / "competition"
    (destination / "exact").mkdir(parents=True, exist_ok=True)
    (destination / "standing").mkdir(exist_ok=True)
    report.directional_chroma.ARMS = ARMS
    report.replay.ARMS = ARMS + (METHOD,)
    report.replay.LABELS = LABELS | {METHOD: "Held color comparison"}
    report.replay.apply_directional = evaluate
    report.replay.OUT = destination
    report.OUT = destination
    report.apply_relative = evaluate
    orig = report.replay.native_board

    def show(folder, case, images, *args, **kwargs):
        kwargs["triplet_indices"] = (0, len(images) - 2, len(images) - 1)
        return orig(folder, case, images, *args, **kwargs)

    report.replay.native_board = show
    standing = report.standing()
    panels = {}
    for name in ("iso1600", "iso6400"):
        ref = original["results"][name]
        runs = report.replay.photos(ref["source"], name)
        counts = {}
        for one, two in zip(ref["rows"], runs, strict=True):
            for b, a in zip(one["draws"], two["draws"], strict=True):
                assert all(a["scores"][k] == v for k, v in b["scores"].items())
                for role, fit in enumerate(a["fits"]):
                    group = counts.setdefault(str(role), {})
                    for color, n in fit["competition"].items():
                        group[color] = group.get(color, 0) + n
        data = report.replay.summary(runs)
        panels[name] = {
            "source": ref["source"],
            "rows": runs,
            "summary": data,
            "extra_windows": counts,
        }
        print(name, counts, flush=True)
    write_json(
        destination / "result.json",
        {
            "driver": reference(__file__),
            "baseline": prior,
            "panels": panels,
            "standing": standing,
            "elapsed": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
