"""Render two fresh photo crops with measured color-field changes."""

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

from relative_phase import ARMS, apply_relative
import replay_relative as review

EXAMPLES = (("iso1600", "relative-color-18"), ("iso6400", "relative-color-15"))


def main():
    torch.set_num_threads(2)
    store = review.OUT / "recovered"
    store.mkdir(exist_ok=True)
    before = reference(review.OUT / "result.json")
    report = read_json(checked(before))
    review.directional_chroma.ARMS = ARMS
    figures = []
    for profile, name in EXAMPLES:
        panel = report["results"][profile]
        row = next(r for r in panel["rows"] if r["id"] == name)["draws"][0]
        inputs = read_json(checked(panel["source"]))
        plan = read_json(checked(inputs["plan"]))
        case = next(x for x in plan["cases"] if x["id"] == name)
        f = review.replay.arrays(row["input"])
        p = f["local50k"][0]
        scene = f["scene_packed"].copy()
        scene[review.replay.RAW] = f["packed"][0]
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        roi = review.replay.SENSOR_ROI
        peaks = _spacing(scene, colors, *roi[:2], clearance=48)
        arms, info = apply_relative(
            p, review.replay.ROI, scene, roi, colors, peaks, plan["noise"], wb, matrix
        )
        assert info == row["fits"][0]
        attrs = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        attrs["packed"] = f["packed"][:1]
        members = [noisy_malvar(attrs)[0], p]
        for k in ("conditional", "own_phase_sign", "affine", "field_sign"):
            img = p.copy()
            review.replay.section(img, *review.replay.ROI)[:] = arms[k]
            members.append(img)
        members.append(f["target"][0])
        label = f"{profile}-{name}"
        board = review.replay.native_board(
            store,
            label,
            members,
            attrs,
            {
                "source": case,
                "input": row["input"],
                "weights": plan["weights"],
                "noise": plan["noise"],
                "query": plan["query"],
                "optical_sigma": plan["sigma"],
            },
            labels=[
                "Noisy Malvar",
                "Local 50k",
                "Local conditional",
                "Planar + sign",
                "Affine quadratures",
                "Color field + sign",
                "Exact GT",
            ],
            triplet_indices=(0, 5, 6),
        )
        diff = arms["field_sign"].astype("d") - arms["conditional"]
        y, x = np.where(np.any(diff != 0, axis=0))
        figures.append(
            {
                "id": name,
                "profile": profile,
                "score": row["scores"],
                "info": board,
                "nonzero_xywh": [
                    int(x.min()),
                    int(y.min()),
                    int(x.max() + 1 - x.min()),
                    int(y.max() + 1 - y.min()),
                ],
                "peak_DN16": float(np.max(abs(diff)) * 65535),
            }
        )
        print(label, figures[-1]["nonzero_xywh"], figures[-1]["peak_DN16"], flush=True)
    write_json(
        review.OUT / "recovered.json",
        {"driver": reference(__file__), "matching_review": before, "figures": figures},
    )


if __name__ == "__main__":
    main()
