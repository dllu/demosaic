"""Measure how much clean signed contrast each candidate basis can represent."""

from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from relative_phase import (
    AFFINE,
    _CORE,
    _POOLED_FOOTPRINT,
    _STRIDE,
    _WINDOW,
    _measure_nodes,
    _wave,
    _windows,
    base,
    fields,
    fit_field,
    transported,
)
from directional_chroma import BASE_PATCHES
import replay_relative as replay


def project(template, contrast):
    broad = template[:, base._FIT[0], base._FIT[1]]
    design = broad.reshape(len(broad), -1, broad.shape[-1])
    signal = contrast[:, base._FIT[0], base._FIT[1]].reshape(len(broad), -1)
    beta = np.einsum("ncp,np->nc", np.linalg.pinv(design, rcond=1e-8), signal)
    prediction = np.einsum("nyxc,nc->nyx", template[:, _CORE[0], _CORE[1]], beta)
    gt = contrast[:, _CORE[0], _CORE[1]]
    error = ((prediction - gt) ** 2).sum(axis=(1, 2))
    return 1 - error / (gt**2).sum(axis=(1, 2)).clip(min=1e-14)


def sample(data, noise):
    raw = data["scene_packed"].copy()
    raw[replay.replay.RAW] = data["packed"][0]
    colors, wb, matrix = (data[k] for k in ("colors", "wb", "matrix"))
    roi = replay.replay.SENSOR_ROI
    peaks = _spacing(raw, colors, *roi[:2], clearance=48)
    if peaks is None:
        return []
    target = (data["target"][0] - data["target"][1])[:, 32:224, 32:224]
    wave = _wave(_POOLED_FOOTPRINT, peaks)
    local = _wave(_WINDOW, peaks)
    green, _, planes = fields(raw, colors, roi[:2])
    shot, read = noise["shot"], noise["read"]
    terms = [_measure_nodes(planes[p], wave, p, shot, read) for p in green]
    live = []

    def check(plane, pos, shape, rival, parent, active, sample_shot, sample_read, nominal):
        old, veto = BASE_PATCHES(
            plane, pos, shape, rival, parent, active, sample_shot, sample_read, nominal
        )
        use = veto & ~np.any(old, axis=(1, 2))
        if not use.any() or not np.array_equal(rival, local[..., 0, :]):
            return old, veto
        site = colors[2 * ((roi[1] + pos[0]) % 2) + ((roi[0] + pos[1]) % 2)]
        contrast = _windows(target[site], _WINDOW, _STRIDE)[use].astype("d")
        central = contrast[:, _CORE[0], _CORE[1]]
        energy = np.sqrt(np.mean(central**2, axis=(1, 2))) * 65535
        use[use] = energy >= 8
        contrast = contrast[energy >= 8]
        if not use.any():
            return old, veto
        pair = transported(wave, terms, 1)
        features = np.stack(
            [_windows(pair[..., d], _WINDOW, _STRIDE)[use] for d in (0, 1)], axis=-1
        )
        const = np.broadcast_to(local[..., 1, :], features.shape)
        affine = np.concatenate(
            (
                features,
                features * AFFINE[None, ..., 0, None],
                features * AFFINE[None, ..., 1, None],
            ),
            axis=-1,
        )
        field = tuple(
            _windows(fit_field(plane, pair, wave[..., 0, :], pos, shot, read, i), _WINDOW, _STRIDE)[
                use, ..., None
            ]
            for i in (0, 1)
        )
        values = {
            "planar": project(const, contrast),
            "transport": project(features, contrast),
            "affine": project(affine, contrast),
            "estimated_field": 0.5 * (project(field[0], contrast) + project(field[1], contrast)),
        }
        live.append(
            {
                "color": int(site),
                "energy_DN16": energy[energy >= 8].tolist(),
                "energy_explained": {key: a.tolist() for key, a in values.items()},
            }
        )
        return old, veto

    try:
        base.channel_patches = check
        base.apply_delivery(
            data["local50k"][0], replay.replay.ROI, raw, roi, colors, peaks, noise, wb, matrix
        )
    finally:
        base.channel_patches = BASE_PATCHES
    return live


def main():
    torch.set_num_threads(2)
    start = monotonic()
    result_source = reference(replay.OUT / "result.json")
    replayed = read_json(checked(result_source))
    stats = {}
    for name, source in replayed["results"].items():
        capture = read_json(checked(source["source"]))
        plan = read_json(checked(capture["plan"]))
        rows = [
            {
                "id": row["id"],
                "observations": [
                    {
                        "input": d["input"],
                        "windows": sample(replay.replay.arrays(d["input"]), plan["noise"]),
                    }
                    for d in row["observations"]["warped"]
                ],
            }
            for row in capture["rows"]
        ]
        vals = [
            a["energy_explained"] for r in rows for d in r["observations"] for a in d["windows"]
        ]
        means = {}
        if vals:
            for key in vals[0]:
                v = np.concatenate([a[key] for a in vals])
                means[key] = {"n": len(v), "median": float(np.median(v)), "mean": float(np.mean(v))}
        print(name, means, flush=True)
        stats[name] = {"source": source["source"], "means": means, "rows": rows}
    write_json(
        replay.OUT / "basis-audit.json",
        {
            "driver": reference(__file__),
            "replay": result_source,
            "elapsed": monotonic() - start,
            "results": stats,
        },
    )


if __name__ == "__main__":
    main()
