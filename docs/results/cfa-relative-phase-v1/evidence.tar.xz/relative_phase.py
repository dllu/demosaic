"""Transport green phase, then estimate color-specific quadratures and spatial variation."""

from pathlib import Path
import sys

import numpy as np
from scipy.linalg import solve
from scipy.ndimage import map_coordinates

from demosaic._mesh_pooled import (
    _CENTER,
    _CORE,
    _INTERPOLATION,
    _NODE,
    _NODE_BACKGROUND,
    _POOLED_FOOTPRINT,
    _SIDE,
    _STRIDE,
    _WINDOW,
    _inverse,
    _laplacian,
    _measure_nodes,
    _nodes,
    _phase_template,
    _scores,
    _variance,
    _wave,
    _windows,
)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("cfa-directional-chroma-v1")))
import directional_chroma as previous
from directional_chroma import NODE_PARITY, base
from own_chroma_phase import own_candidates
from regional_phase import fields

ARMS = ("conditional", "own_phase", "own_phase_sign", "transport", "affine", "field", "field_sign")
LABELS = {
    "conditional": "Local conditional",
    "own_phase": "Planar R/B",
    "own_phase_sign": "Planar + sign",
    "transport": "Transported phase",
    "affine": "Affine quadratures",
    "field": "Pooled color field",
    "field_sign": "Color field + sign",
}
RIDGE = 0.35
FIELD_SMOOTHING = 0.35
Y, X = (np.indices((_WINDOW, _WINDOW)) - (_WINDOW - 1) / 2) / (base._FIT_WIDTH / 2)
AFFINE = np.stack((X, Y), axis=-1)


def transported(wave, nodes, direction):
    coefficients = np.stack([coef[:, direction] for coef, _ in nodes])
    precisions = np.stack([prec[:, direction] for _, prec in nodes])
    precision = precisions.sum(axis=0)
    value = np.sum(coefficients * precisions[..., None], axis=0) / precision[:, None]
    rotated = np.stack((-value[:, 1], value[:, 0]), axis=1)
    w = wave[..., direction, :]
    return np.stack([_phase_template(w, a, precision) for a in (value, rotated)], axis=-1)


def subfit(raw, patches, background, site, shot, read, split, supplied=None, affine=False):
    r, c = site
    design = patches[:, r::2, c::2].reshape(len(patches), -1, patches.shape[-1]).transpose(0, 2, 1)
    observed = raw.reshape(len(raw), -1)
    keep = base._CHECKER[background.shape[0]]
    if split:
        keep = ~keep
    operator = base.projection(background, site, keep)
    fit, held = operator.residual(observed[:, keep], observed[:, ~keep])
    a, b = operator.residual(design[:, :, keep], design[:, :, ~keep])
    if supplied is None:
        gram = np.einsum("ncp,ndp->ncd", a, a)
        rhs = np.einsum("ncp,np->nc", a, fit)
        diagonal = np.arange(gram.shape[-1])
        scales = gram.diagonal(axis1=1, axis2=2)[:, :2].mean(axis=1).clip(min=1e-12)
        gram[:, diagonal, diagonal] += 1e-10 * scales[:, None]
        if affine:
            gram[:, diagonal[2:], diagonal[2:]] += RIDGE * scales[:, None]
        coefficients = np.linalg.solve(gram, rhs[..., None])[..., 0]
        if coefficients.shape[-1] == 1:
            coefficients = np.maximum(0, coefficients)
    else:
        coefficients = supplied
    predicted = np.einsum("ncp,nc->np", b, coefficients)
    return coefficients, _scores(held, predicted, _variance(observed[:, keep], shot, read))


def fit_field(plane, pair, rival, pos, shot, read, fold):
    """Estimate an unnormalized, possibly sign-changing color waveform."""
    row, col = pos
    keep = NODE_PARITY if fold == 0 else ~NODE_PARITY
    nuisance = _NODE_BACKGROUND[row::2, col::2].reshape(1, (_NODE // 2) ** 2, -1)
    nuisance = np.broadcast_to(nuisance, (_SIDE**2, *nuisance.shape[1:]))
    competing = _nodes(rival[row::2, col::2])
    wide = np.concatenate((nuisance, competing), axis=-1)
    A = wide[:, keep]
    W = _nodes(pair[row::2, col::2])[:, keep]
    a_inv = np.linalg.pinv(A, rcond=1e-8)
    residual = W - A @ (a_inv @ W)
    raw = _nodes(plane)[:, keep]
    gram = residual.swapaxes(1, 2) @ residual
    moment = np.einsum("npi,np->ni", residual, raw)
    beta = np.linalg.pinv(gram, rcond=1e-8, hermitian=True) @ moment[..., None]
    double_information = np.trace(gram, axis1=1, axis2=2) / _variance(raw, shot, read)
    precision = (double_information / 2).clip(min=1e-10)
    system = np.diag(precision) + FIELD_SMOOTHING * np.median(precision) * _laplacian()
    smooth = solve(system, precision[:, None] * beta[..., 0], assume_a="pos", check_finite=False)
    coefficients = np.stack(
        [
            map_coordinates(
                smooth[:, i].reshape(_SIDE, _SIDE), _INTERPOLATION, order=1, mode="nearest"
            )
            for i in range(2)
        ],
        axis=-1,
    )
    return np.sum(coefficients * pair, axis=-1)


def compose(raw, bases, background, center, site, prior, shot, read, *, affine=False):
    local = tuple(x[:, base._FIT[0], base._FIT[1]] for x in bases)
    core = tuple(x[:, _CORE[0], _CORE[1]] for x in bases)
    first = tuple(
        subfit(raw[:, 4:-4, 4:-4], v, background, site, shot, read, i, affine=affine)
        for i, v in enumerate(local)
    )
    second = tuple(
        subfit(raw[:, 8:-8, 8:-8], v, center, site, shot, read, i, supplied=first[i][0])
        for i, v in enumerate(core)
    )
    broad = np.minimum(first[0][1], first[1][1])
    narrow = np.minimum(second[0][1], second[1][1])
    prediction = tuple(
        np.einsum("nyxc,nc->nyx", v, fit[0]) for v, fit in zip(core, first, strict=True)
    )
    coherent = np.sum(prediction[0] * prediction[1], axis=(1, 2)) > 0
    nuisance = background.reshape(base._FIT_WIDTH**2, -1)
    project = _inverse(nuisance)
    measured = []
    for i, v in enumerate(local):
        shape = v.reshape(len(v), base._FIT_WIDTH**2, -1)
        trend = np.einsum("dp,npc->ndc", project, shape)
        residue = shape - np.einsum("pd,ndc->npc", nuisance, trend)
        target = prior[:, base._FIT[0], base._FIT[1]].reshape(len(v), -1)
        fit_fill = np.linalg.pinv(residue, rcond=1e-8)
        inherited = np.einsum("ncp,np->nc", fit_fill, target)
        existing = np.einsum("nyxc,nc->nyx", core[i], inherited)
        delta = prediction[i] - existing
        measured.append(
            delta
            * np.minimum(
                1,
                np.linalg.norm(prediction[i], axis=(1, 2))
                / np.linalg.norm(delta, axis=(1, 2)).clip(min=1e-12),
            )[:, None, None]
        )
    wave_delta = (measured[0] + measured[1]) / 2

    def delivered(threshold):
        margin = np.maximum(0, np.stack((broad - 6, narrow - threshold), axis=-1))
        gain = np.min(margin / (margin + (6.0, 1.5)), axis=1) * coherent
        return gain[:, None, None] * wave_delta

    return delivered


def apply_relative(parent, local, scene, roi, colors, peaks, noise, wb, matrix):
    """Use the old contradiction and green decisions for all arms."""
    original = previous.candidate_patches
    if peaks is None:
        return previous.apply_directional(
            parent, local, scene, roi, colors, peaks, noise, wb, matrix
        )
    lattice = _wave(_POOLED_FOOTPRINT, peaks)
    local_wave = _wave(_WINDOW, peaks)
    guides = {}

    def candidates(plane, pos, phase, rival, prior, use, shot, read, freq, global_rival):
        plain = own_candidates(plane, pos, phase, rival, prior, use, shot, read, freq, global_rival)
        arms = {k: plain[k] for k in ("own_phase", "own_phase_sign")}
        d = int(np.array_equal(rival, local_wave[..., 0, :]))
        if d not in guides:
            green, _, planes = fields(scene, colors, roi[:2])
            nodes = [_measure_nodes(planes[p], lattice, p, shot, read) for p in green]
            guides[d] = transported(lattice, nodes, d)
        pair = guides[d]
        np.testing.assert_array_equal(pair[..., 0], phase)
        raw = _windows(plane, _WINDOW // 2, _STRIDE // 2)[use]
        background = np.concatenate((base._FIT_BASIS, rival[base._FIT]), axis=-1)
        center = np.concatenate((base._CENTER_BASIS, rival[_CORE]), axis=-1)
        window = np.stack([_windows(pair[..., i], _WINDOW, _STRIDE)[use] for i in (0, 1)], axis=-1)
        spatial = np.concatenate(
            (window, window * AFFINE[None, ..., 0, None], window * AFFINE[None, ..., 1, None]),
            axis=-1,
        )
        by_fold = tuple(
            _windows(fit_field(plane, pair, global_rival, pos, shot, read, i), _WINDOW, _STRIDE)[
                use, ..., None
            ]
            for i in (0, 1)
        )
        arms["transport"] = compose(
            raw, (window, window), background, center, pos, prior[use], shot, read
        )(1.5)
        arms["affine"] = compose(
            raw, (spatial, spatial), background, center, pos, prior[use], shot, read, affine=True
        )(1.5)
        field = compose(raw, by_fold, background, center, pos, prior[use], shot, read)
        arms["field"] = field(1.5)
        arms["field_sign"] = field(0.0)
        return arms

    try:
        previous.candidate_patches = candidates
        return previous.apply_directional(
            parent, local, scene, roi, colors, peaks, noise, wb, matrix
        )
    finally:
        previous.candidate_patches = original


def independence():
    rng = np.random.default_rng(26383)
    freq = np.array(((0.101, 0.078), (0.105, -0.072)))
    wave = _wave(_POOLED_FOOTPRINT, freq)
    keep = np.indices((96, 96)).sum(axis=0) % 2 == 0
    output = []
    for r, c in np.ndindex(2, 2):
        obs = 0.08 + 0.004 * wave[r::2, c::2, 0, 0] + rng.normal(0, 0.012, (96, 96))
        for f, mask in enumerate((keep, ~keep)):
            first = fit_field(obs, wave[..., 0, :], wave[..., 1, :], (r, c), 0.00128, 6.5536e-6, f)
            shifted = obs.copy()
            shifted[~mask] = rng.uniform(0.025, 0.135, (~mask).sum())
            second = fit_field(
                shifted, wave[..., 0, :], wave[..., 1, :], (r, c), 0.00128, 6.5536e-6, f
            )
            np.testing.assert_array_equal(first, second)
            output.append({"site": [r, c], "fold": f})
    return output
