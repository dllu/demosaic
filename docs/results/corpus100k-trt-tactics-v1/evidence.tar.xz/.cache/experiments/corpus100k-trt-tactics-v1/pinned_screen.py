"""Run the resident tactic screen with production pinned checkpoint staging."""
from full_quality import bound_model
import tactics

tactics.load = bound_model
tactics.screen([3, 5])
