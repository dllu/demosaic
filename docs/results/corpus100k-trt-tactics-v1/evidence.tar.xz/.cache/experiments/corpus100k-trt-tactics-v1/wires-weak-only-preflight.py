"""Measure weak oriented response and quiet noise using full 512-pixel contexts."""
from statistics import mean

import numpy as np
import torch

from full_quality import (ROOT, bound_model, build_refs, engine_set, prepare, read_json,
                          checked, reference, selected, write_json)
from demosaic.archive_metrics import linear_rgb
from demosaic.precision import amp_context

SOURCE = ROOT.with_name('query-exterior-colour-v1')
KEYS = ('packed','variance','colors','wb','matrix')
LUMA = np.array([.2126,.7152,.0722])


def evaluate(rgb, data, fit, support, truth_luma, target_chroma, carrier):
    image = linear_rgb(rgb, data)
    lum = np.einsum('c,bchw->bhw',LUMA,image)
    step = (lum[0]-lum[2])[192:320,192:320][support]
    response = fit @ step
    lflat = lum[3,200:312,200:312]
    flat = image[3,:,200:312,200:312]
    chroma = flat-lflat[None]
    return {
        'weak_response_pct':float(100*response[-2:]@carrier[-2:]/(carrier[-2:]@carrier[-2:])),
        'strong_response_pct':float(100*response[:2]@carrier[:2]/(carrier[:2]@carrier[:2])),
        'increment_RMS_DN16':float(np.sqrt(np.mean((step-truth_luma)**2))*65535),
        'flat_luma_RMS_DN16':float(np.std(lflat)*65535),
        'flat_chroma_RMS_DN16':float(np.sqrt(np.mean((chroma-chroma.mean((1,2),keepdims=True))**2))*65535),
        'worst_flat_bias_DN16':float(np.max(np.abs((flat-target_chroma).mean((1,2))))*65535),
    }


@torch.inference_mode()
def main():
    prepare()
    full = read_json(ROOT/'full.json')
    model, checkpoint = bound_model()
    assert checkpoint == full['checkpoint']
    engines = engine_set(build_refs(full['level']))
    plan, captures = (read_json(SOURCE / f'{name}.json') for name in ('plan','captures'))
    x, y = np.meshgrid(np.arange(128,dtype=float)-63.5,np.arange(128,dtype=float)-63.5)
    x, y = x.ravel(), y.ravel()
    keys = ('eager','dynamic','static')
    rows = []
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for case in captures['rows']:
            profile = plan['profiles'][case['noise']]
            geom = plan['sources'][case['index']]['geometry']
            with np.load(checked(case['input']),allow_pickle=False) as src:
                data = {key:src[key] for key in (*KEYS,'target')}
                support = src['support'][64:192,64:192]>=.97
            assert data['packed'].shape == (4,4,256,256)
            z = 2*np.pi*(np.asarray(geom['frequency'])@np.stack([x,y]))
            terms = np.column_stack([np.ones_like(x),x,y,x*x,x*y,y*y,
                                     np.cos(z[0]),np.sin(z[0]),np.cos(z[1]),np.sin(z[1])])[support.ravel()]
            fit = np.linalg.pinv(terms)[-4:]
            truth = linear_rgb(data['target'],data)
            truth_luma = np.einsum('c,chw->hw',LUMA,truth[0]-truth[2])[192:320,192:320][support]
            target = truth[3,:,200:312,200:312]
            carrier = fit@truth_luma
            args = [torch.from_numpy(data[key]).cuda() for key in KEYS]
            args[0] = args[0].contiguous(memory_format=torch.channels_last)
            model.set_noise(profile['shot'],profile['read'])
            scores = {}
            for key in keys:
                with selected(model,engines[key]), amp_context('cuda', dtype='float16'):
                    output = model(*args).cpu().numpy()
                scores[key] = evaluate(output,data,fit,support,truth_luma,target,carrier)
            rows.append({'source':case['index'],'profile':case['noise'],'input':case['input'],'scores':scores})
            if len(rows) % 12 == 0:
                print(len(rows), flush=True)
    assert len(rows) == 48
    summary = {}
    for prior in ('iso400','iso6400'):
        selected_cases = [row['scores'] for row in rows if row['profile'] == prior]
        assert len(selected_cases) == 24
        summary[prior] = {}
        for mode in ('dynamic','static'):
            differences = {}
            for metric in selected_cases[0]['eager']:
                values = [row[mode][metric]-row['eager'][metric] for row in selected_cases]
                differences[metric] = {'mean':mean(values),'min':min(values),'max':max(values)}
            summary[prior][mode] = differences
    write_json(ROOT/'wires.json',dict(driver=reference(__file__),checkpoint=checkpoint,
        plans=full['plans'],plan=reference(SOURCE/'plan.json'),captures=reference(SOURCE/'captures.json'),
        input_native_side=512,scored_native_side=128,flat_native_side=112,rows=rows,deltas_vs_eager=summary))
    print(summary,flush=True)


if __name__ == '__main__':
    main()
