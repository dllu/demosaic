"""Verify and publish the paired TensorRT precision experiment."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
IMAGES = Path('docs/images') / ROOT.name
RESULTS = Path('docs/results') / ROOT.name
PREVIOUS = ROOT.with_name('corpus100k-faster-inference-v1')
MIXED = ROOT.with_name('corpus100k-mixed-precision-v1')
TILE = ROOT.with_name('corpus100k-fp16-throughput-v1')


def retained_board(spec):
    source = checked(spec['image'])
    target = IMAGES / source.name
    shutil.copyfile(source, target)
    assert reference(target)['sha256'] == spec['image']['sha256']
    with Image.open(target) as image:
        pixels = np.asarray(image.convert('RGB'))
    cells = {}
    for panel in spec['panels']:
        x, y, w, h = panel['png_xywh']
        cell = pixels[y:y+h, x:x+w]
        assert cell.shape == (160, 160, 3)
        cells[panel.get('label', panel.get('name'))] = cell
    spec['image']['path'] = target.name
    return cells


def main():
    IMAGES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    refs = {name:reference(ROOT/f'{name}.json') for name in ('screen','screen-default-stream','full','quality','paired-tiles','outliers','wires')}
    receipts = {name:read_json(checked(binding)) for name,binding in refs.items()}
    screen, screen_default, full, quality, paired, outliers, wires = (receipts[name] for name in refs)
    assert screen_default['engine_plans'] == screen['engine_plans']
    assert paired['full'] == outliers['full'] == refs['full']
    assert paired['plans'] == wires['plans'] == full['plans']
    assert paired['checkpoint'] == wires['checkpoint'] == full['checkpoint']
    assert len(paired['rows']) == 130 and len(wires['rows']) == 48
    assert len({tuple(xy) for row in paired['rows'] for xy in row['origins_xy']}) == 520
    assert all(row['timings']['dynamic']['wall_seconds'] < row['timings']['eager']['wall_seconds']
               for row in paired['rows'])
    for path in (full['FP32_anchor'],full['source'],*full['exports'].values()):
        checked(path)
    assert screen['checkpoint'] == full['checkpoint'] == quality['checkpoint']
    assert refs['full'] == quality['full_receipt']
    assert full['plans'] == quality['plans']
    assert screen['engine_plans'][f"static-{full['level']}"] == full['plans']['static']
    assert screen['engine_plans']['dynamic-2'] == full['plans']['dynamic']
    assert len(full['events']) == 6 and all(row['restore']['tiles']==520 for row in full['events'])
    assert all(row['channels'] == 305987556 for row in full['paired'].values())
    assert all(row['export']['sha256'] == full['exports'][row['arm']]['sha256'] for row in full['events'])
    assert len(quality['main']) == len(quality['cab']) == 4 and len(quality['exact']) == 6
    visuals = deepcopy(quality)
    for row in visuals['main'] + visuals['cab']:
        cells = retained_board(row['board'])
        assert 'IEEE FP32' in cells and 'Static TensorRT FP16' in cells
        assert sum('ISO100' in label for label in cells) == (2 if row in visuals['cab'] else 1)
    for row in visuals['exact'][:2]:
        cells = retained_board(row['board']['board'])
        triplet = retained_board(row['board']['triplet'])
        assert list(triplet) == ['Noisy Malvar', 'Static TensorRT FP16', 'Exact GT']
        assert all(np.array_equal(value, cells[label]) for label,value in triplet.items())
    outlier_views = deepcopy(outliers)
    for row in outlier_views['rows'].values():
        assert len(retained_board(row['board'])) == 4
    manifest = IMAGES/'manifest.json' 
    write_json(manifest,{**visuals,'source':refs['quality'],
         'RGB16_outliers':outlier_views,'native_review_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()},replace=True)
    builds = [p for p in ROOT.glob('static-*.json') if not p.name.endswith('.layers.json')]
    assert len(builds) >= 2
    for path in builds:
        build = read_json(path)
        assert build['checkpoint'] == full['checkpoint']
        for key in ('driver','base_builder','plan','layers'):
            checked(build[key])
    paths = [checked(src) for src in refs.values()] + list(ROOT.glob('*.py')) + list(ROOT.glob('*.log'))
    paths += builds + list(ROOT.glob('static-*.layers.json'))
    paths += [PREVIOUS/'trt_hidden.py', MIXED/'screen.py', MIXED/'first-fp32.json',
              MIXED/'full_production.py', TILE/'review_throughput.py', TILE/'full_throughput.py',
              Path('src/demosaic/inference.py'), Path('scripts/report_scene_wave_guides.py'),
              Path('configs/gfx-qualitative-20231231.json'), Path('configs/gfx-green-mesh-20231231.json'),
              ROOT.with_name('paired-luminance-detail-v1')/'render.py',
              TILE/'screen_throughput.py', checked(quality['sources']['exact']),
              checked(wires['plan']), checked(wires['captures'])]
    members = {str(p.resolve().relative_to(Path.cwd())):p for p in paths}
    archive = RESULTS/'evidence.tar.xz'
    with tarfile.open(archive,'w:xz',preset=4) as out:
        for name,p in sorted(members.items()):
            out.add(p,arcname=name,recursive=False)
    with tarfile.open(archive) as inp:
        for name,p in members.items():
            with inp.extractfile(name) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest() == reference(p)['sha256']
    summary = {key:full[key] for key in ('level','settings','medians','paired','versions','plans','FP32_anchor')}
    summary['runs'] = [{key:row[key] for key in ('arm','restore','export_seconds','export')} for row in full['events']]
    summary['implementation'] = {'builds':[read_json(path) for path in sorted(builds)],
        'resident_medians':screen['medians'], 'resident_quality':screen['quality']}
    summary.update(checkpoint=full['checkpoint'],sources=refs,archive=reference(archive),
                   paired_tile_timings=paired['summary'], wire_score_changes=wires['deltas_vs_eager'],
                   manifest=reference(manifest),notes='Same trained EMA. Native quality uses six exact-target contexts, 48 exact weak-wire inputs and both GFX families.')
    write_json(RESULTS/'publication.json',summary,replace=True)
    print(len(members),'verified archive members and fourteen native images')


if __name__ == '__main__':
    main()
