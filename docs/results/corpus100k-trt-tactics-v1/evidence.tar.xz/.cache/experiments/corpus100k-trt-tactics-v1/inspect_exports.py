"""Render the largest scored TIFF differences at unchanged native scale."""
import numpy as np
import tifffile
import torch

from full_quality import (ROOT, checked, display_sensor, native_png,
                          read_json, read_raw, reference, write_json)


def main():
    torch.set_num_threads(2)
    row = read_json(ROOT/'full.json')
    _, meta = read_raw(checked(row['source']))
    assert meta.flip == 0
    wb, mat = torch.tensor(meta.white_balance)[None], torch.tensor(meta.camera_to_srgb)[None]
    images = {key:tifffile.memmap(checked(src)) for key,src in
              {**row['exports'],'ieee-fp32':row['FP32_anchor']}.items()}
    results = {}
    for measurement in ('static_vs_eager','static_vs_dynamic'):
        baseline = measurement.rsplit('_',1)[-1]
        magnitude, (x,y,c) = row['paired'][measurement]['max_DN16_and_sensor_xy_channel']
        assert abs(int(images['static'][y,x,c])-int(images[baseline][y,x,c])) == magnitude
        x0 = min(max(0,x-80), images['static'].shape[1]-160)
        y0 = min(max(0,y-80), images['static'].shape[0]-160)
        panels = []
        for arm, label in (('ieee-fp32','IEEE FP32'),('eager','Eager FP16'),
                           ('dynamic','Previous TRT FP16'),('static','Static TRT FP16')):
            crop = torch.from_numpy(images[arm][y0:y0+160,x0:x0+160].astype(np.float32)).permute(2,0,1)/65535
            panels.append((label,display_sensor(crop,wb,mat,(0,0,160,160),1)))
        results[measurement] = {
            'difference_DN16':magnitude,'coordinate':[x,y,c],'xywh':[x0,y0,160,160],
            'display_exposure':1,'board':native_png(ROOT/f'{measurement}-outlier.png',panels)}
    write_json(ROOT/'outliers.json',dict(driver=reference(__file__),full=reference(ROOT/'full.json'),rows=results))


if __name__ == '__main__':
    main()
