"""Use staged weights and the explicit CUDA stream used by the full benchmark."""
import torch
from full_quality import bound_model
import tactics

tactics.load = bound_model
with torch.cuda.stream(torch.cuda.Stream()):
    tactics.screen([3, 5])
