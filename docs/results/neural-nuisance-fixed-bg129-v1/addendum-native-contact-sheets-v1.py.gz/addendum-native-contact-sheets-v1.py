import sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from demosaic.experiments.artifacts import read_json,write_json,reference,checked
root=Path(sys.argv[1]);prepared=read_json(root/'publication-prepared.json');output=root/'contact-sheets';output.mkdir();font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10);batches=[];current=[];height=0
for f in prepared['images']:
 im=Image.open(checked(f['original'])).convert('RGB')
 if current and(len(current)==4 or height+im.height+20>1800):batches.append(current);current=[];height=0
 current.append((f,im));height+=im.height+20
if current:batches.append(current)
sheets=[];channels=0
for i,batch in enumerate(batches):
 canvas=Image.new('RGB',(max(im.width for f,im in batch),sum(im.height+20 for f,im in batch)),'#ddd');draw=ImageDraw.Draw(canvas);y=0;cells=[]
 for f,im in batch:
  draw.text((8,y+3),Path(f['original']['path']).name,font=font,fill='black');canvas.paste(im,(0,y+20));cells.append({'source':f['original'],'published':f['published'],'xywh':[0,y+20,im.width,im.height]});y+=im.height+20
 path=output/f'sheet-{i:02d}.png';canvas.save(path);encoded=np.asarray(Image.open(path))
 for cell,(_,im)in zip(cells,batch,strict=True):
  x,y,w,h=cell['xywh'];np.testing.assert_array_equal(encoded[y:y+h,x:x+w],np.asarray(im));channels+=w*h*3
 sheets.append({'image':reference(path),'cells':cells})
write_json(output/'manifest.json',{'preparation':reference(root/'publication-prepared.json'),'script':reference(__file__),'sheets':sheets,'source_images':len(prepared['images']),'unchanged_RGB_channels':channels,'no_resize':True,'scope':'Exact native source boards copied into contact sheets with separate filename strips. Every source RGB pixel reread exactly; crop pixels never resized. RGBA plots converted to visible RGB only. Actual tools.view_image review remains pending.'});print('sheets',len(sheets),'sources',len(prepared['images']),'exactRGB',channels)
