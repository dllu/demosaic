"""Two matched native analytic triplets, preserving audited noisy and GT cells."""
from copy import deepcopy
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from audit_checkpoint_pilot import crop
from report_checkpoint_pilot import pixels
from demosaic.experiments.artifacts import checked, read_json, write_json, reference

root = Path.cwd() / ".cache/experiments/neural-nuisance-fixed-bg129-pilot-v1"
report = read_json(root / "report/report.json")
records = {r["id"]: r for r in read_json(root / "collection.json")["rows"]}
output = root / "analytic-triplets"
output.mkdir()
figures = []
for case in ["iso400-index0008-role2", "iso400-index0024-role2"]:
    original = next(f for f in report["figures"] if Path(f["image"]["path"]).stem == case + "-triplet")
    metadata = deepcopy(original)
    row = metadata["source"]
    with np.load(checked(row["arrays"]), allow_pickle=False) as archive:
        data = {k: archive[k][row["sample"]:row["sample"] + 1] for k in ["wb", "matrix"]}
    value = np.load(checked(records[case]["predictions"]["conditional-local-t2"]))[None]
    expected = crop(value, data, metadata["ROI_xywh"], metadata["display_exposure"])
    np.testing.assert_array_equal(expected, pixels(value, data, metadata["ROI_xywh"], metadata["display_exposure"]))
    source = np.asarray(Image.open(checked(original["image"])))
    canvas = Image.fromarray(source.copy())
    px, py, width, height = metadata["panels"][1]["xywh"]
    assert expected.shape == (height, width, 3)
    canvas.paste(Image.fromarray(expected), (px, py))
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((px, 0, px + width - 1, py - 1), fill="#eeeeee")
    draw.text((px, 5), "Fixed BG H1 t2", fill="black", font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10))
    path = output / (case + "-analytic-triplet.png")
    canvas.save(path)
    encoded = np.asarray(Image.open(path))
    for index, panel in enumerate(metadata["panels"]):
        x, y, w, h = panel["xywh"]
        reference_pixels = expected if index == 1 else source[y:y+h, x:x+w]
        np.testing.assert_array_equal(encoded[y:y+h, x:x+w], reference_pixels)
    metadata.update(image=reference(path), original_audited_NN_triplet=original["image"],
                    prediction=records[case]["predictions"]["conditional-local-t2"],
                    method="conditional-local-t2", all_encoded_crop_channels_exact=3*height*width*3)
    metadata["panels"][1]["label"] = "Fixed BG H1 t2"
    figures.append(metadata)
write_json(output / "report.json", {"figures": figures, "script": reference(__file__),
    "new_neural_forwards": 0, "no_resize": True,
    "scope": "Two analytic Hann noisy/restored/exact constructed GT triplets; native160 unchanged coordinates/transforms. Noisy/GT pixels copied exactly from independently audited triplets; middle computed and independently checked from analytic prediction."})
print("two native analytic triplets exact")
