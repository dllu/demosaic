import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-fixed-bg129-pilot-v1"
destination = repo / "docs/results/neural-nuisance-fixed-bg129-v1"
notes = [
    ([0,1,2,3], "All12 procedural comparisons and material/sky/building primary views inspected. Low-prior strong modulation remains, weak crossings largely absent; high-noise outputs mostly parent-like. Bark/fur/foliage remain soft, sky quiet. Primary analytic building has green/magenta bands; neural arm largely removes them."),
    ([4,5,6,7], "All protected foliage/coarse-fence/cab views, both profiles/ROIs/JPEGs and stress views inspected. Fine cab crossings still missing. Neural building stress/analytic-max views much closer to parent than prior local-nuisance arm, but analytic large colored bands remain. Neural cab stress shows small modulation, not clear crossing recovery. Both NN triplets inspected."),
    ([8,9,10], "Both analytic native160 noisy/restored/exact-GT triplets and both fixed0/2/4 charts inspected. Most weak template still missing; threshold0 adds response with larger quiet costs.1600/far weak response below parent. No retrospective threshold change."),
]
for i, (sheets, note) in enumerate(notes):
    write_json(root / f"viewing-batch-{i}.json", {"sheets": sheets, "actually_viewed": True,
        "method": "Exact unresized contact sheets through tools.view_image", "notes": note})
prepared = read_json(root / "publication-prepared.json")
manifest = read_json(root / "contact-sheets/manifest.json")
assert manifest["source_images"] == len(prepared["images"]) == 36
assert sorted(s for group, _ in notes for s in group) == list(range(len(manifest["sheets"])))
archives = list(prepared["archives"])
for source in [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *sorted(root.glob("viewing-batch-*.json")), repo / ".cache/native-contact-sheets-v1.py", Path(__file__)]:
    target = destination / ("addendum-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})
for item in archives:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in prepared["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
prepared.update(archives=archives,
    viewing={"actually_viewed": True, "figures": 36, "contact_sheets": 11,
             "manifest": reference(root / "contact-sheets/manifest.json"),
             "batches": [reference(p) for p in sorted(root.glob("viewing-batch-*.json"))]},
    status="complete; neural building-artifact reduction with lower weak response and residual real-detail limitations",
    quality_decision="Expose fixed-global neural background with local amplitudes as stronger-detail experimental choice. It reduces prior neural building artifact but loses weak response and raises increment error; analytic bands persist, fine cab crossings absent. Broader source/CFA/noise validation required, general V120 recommendation unchanged.",
    comparison_baselines=[reference(repo / "docs/results" / name / "publication.json") for name in [
        "neural-nuisance-spatial129-v1", "neural-nuisance-hann512-v1", "neural-nuisance-fixed-v1"]],
    scope_clarification="amplitude_nuisance=global freezes the original broad-context joint-fit background operator; only four carrier residual coefficients vary over129-native query boxes. Full/null predictions share the same fixed background, and parent projection uses identical global residualization. No new learned weights/inference/GT inputs.",
    published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination / "publication.json", prepared)
print(len(archives), "exact archives;36 source figures actually viewed")
