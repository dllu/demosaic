from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from report_checkpoint_pilot import pixels
from audit_checkpoint_pilot import crop
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import read_json,reference,write_json,checked
root=Path.cwd()/'.cache/experiments/neural-nuisance-fixed-bg129-pilot-v1';output=root/'extra-stress';output.mkdir();plan=read_json(root/'plan.json');collection=read_json(root/'collection.json');assert len(collection['rows'])==48
row=next(r for r in plan['rows']if r['id']=='main-building-detail');record=next(r for r in collection['rows']if r['id']==row['id']);sample=row['sample']
with np.load(checked(row['arrays']),allow_pickle=False)as z:data={k:z[k][sample:sample+1]for k in ['packed','colors','wb','matrix']}
parent=np.load(checked(row['parent']))[sample:sample+1];analytic=np.load(checked(record['predictions']['conditional-local-t2']))[None];neural=np.load(checked(record['predictions']['local-t2']))[None]
error=np.mean((analytic[0].astype('f8')-parent[0])**2,axis=0);integ=np.pad(error.cumsum(0).cumsum(1),((1,0),(1,0)));energy=integ[160:,160:]-integ[:-160,160:]-integ[160:,:-160]+integ[:-160,:-160];y,x=np.unravel_index(energy.argmax(),energy.shape)
figures=[];channels=0
for name,roi,selection in [('main-building-analytic-max',[int(x),int(y),160,160],'Post-inference maximum conditional analytic H1 correction RMS, deterministic first maximum; no GT/reference selection.'),('main-building-historical-failure',[76,260,160,160],'Previously published phase-aggregation failure ROI, retained unchanged; no new coordinate selection.')]:
 canvas=Image.new('RGB',(680,192),'#eeeeee');draw=ImageDraw.Draw(canvas);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10);panels=[]
 for j,(label,value)in enumerate(zip(['Noisy Malvar','V120','Fixed BG H1 t2','Fixed BG NN t2'],[noisy_malvar(data),parent,analytic,neural],strict=True)):
  cell=pixels(value,data,roi,row['display_exposure']);np.testing.assert_array_equal(cell,crop(value,data,roi,row['display_exposure']));px=8+j*168;canvas.paste(Image.fromarray(cell),(px,24));draw.text((px,5),label,fill='black',font=font);panels.append({'label':label,'xywh':[px,24,160,160]});channels+=cell.size
 path=output/(name+'.png');canvas.save(path);png=np.asarray(Image.open(path))
 for panel,value in zip(panels,[noisy_malvar(data),parent,analytic,neural],strict=True):
  px,py,w,h=panel['xywh'];np.testing.assert_array_equal(png[py:py+h,px:px+w],crop(value,data,roi,row['display_exposure']))
 xx,yy,w,h=roi;figures.append({'image':reference(path),'panels':panels,'source':row,'ROI_xywh':roi,'display_exposure':row['display_exposure'],'display_contrast':1,'no_resize':True,'selection':selection,'analytic_correction_ROI_RMS_DN16':float(np.sqrt(np.mean((analytic[0,:,yy:yy+h,xx:xx+w].astype('f8')-parent[0,:,yy:yy+h,xx:xx+w])**2))*65535),'neural_correction_ROI_RMS_DN16':float(np.sqrt(np.mean((neural[0,:,yy:yy+h,xx:xx+w].astype('f8')-parent[0,:,yy:yy+h,xx:xx+w])**2))*65535)})
write_json(output/'report.json',{'script':reference(__file__),'collection':reference(root/'collection.json'),'figures':figures,'RGB_channels_exact':channels,'new_neural_forwards':0,'scope':'Two supplementary native stress boards preserve the analytic-control maximum and prior aggregation failure coordinates alongside the neural maximum-correction view. No real-reference pixel scores.'})
print([(f['ROI_xywh'],f['analytic_correction_ROI_RMS_DN16'])for f in figures])
