"""Publish the inspected native comparisons and immutable replay evidence."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
report = read_json(root / "review/result.json")
sensitivity = read_json(root / "sensitivity.json")
assert len(report["boards"]) == 2 and len(report["camera"]) == 8
assert report["verified_arrays"] == 600 and len(sensitivity["rows"]) == 16
assert sensitivity["plan"] == report["plan"]
for name, count in (
    ("synthetic", 16),
    ("disjoint", 16),
    ("camera", 8),
    ("retained", 36),
    ("fresh", 32),
):
    assert len(read_json(checked(report["receipts"][name]))["rows"]) == count
images.mkdir()
results.mkdir()


def adopt(binding):
    source = checked(binding)
    out = images / source.name
    shutil.copyfile(source, out)
    assert reference(out)["sha256"] == binding["sha256"]
    return out.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Ten native comparisons, two standalone triplets and one double-rail residual board inspected. "
        "The DSCF3880 and DSCF3835 AHD and cab JPEGs are independent qualitative references.",
        "synthetic": [
            r | {k: r[k] | {"file": adopt(r[k]["image"])} for k in ("board", "triplet")}
            for r in report["boards"]
        ],
        "camera": [
            {k: v for k, v in r.items() if k != "delta_RMS_DN16"}
            | {
                "file": adopt(r["image"]),
                "CFA": "RGGB",
                "reference": "DSCF3880 ISO100 AHD"
                if r["id"].startswith("main-")
                else "DSCF3835 ISO100 AHD and DSCF3842/DSCF3835 camera JPEGs",
            }
            for r in report["camera"]
        ],
        "rail_plate": report["rail_plate"] | {"file": adopt(report["rail_plate"]["image"])},
    },
)
arm_summary = {}
for profile in ("iso400", "iso6400"):
    rows = [r for r in sensitivity["rows"] if r["profile"] == profile]
    arm_summary[profile] = {}
    for arm in rows[0]["metrics"]:
        columns = {
            k: np.asarray([r["metrics"][arm][k] for r in rows]) for k in rows[0]["metrics"][arm]
        }
        arm_summary[profile][arm] = {
            k: float(np.sqrt(np.mean(v**2)) if k.endswith("RMS_DN16") else v.mean())
            for k, v in columns.items()
        }
summary = results / "summary.json"
write_json(
    summary,
    {
        "plan": report["plan"],
        "receipts": report["receipts"],
        "seconds": report["seconds"],
        "results": report["results"],
        "verified_arrays": report["verified_arrays"],
        "nulls": report["nulls"],
        "sensitivity": {
            "source": reference(root / "sensitivity.json"),
            "scope": sensitivity["scope"],
            "scores": arm_summary,
        },
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "delta_RMS_DN16", "checkpoint", "noise")}
            for r in report["camera"]
        ],
    },
)
members = {
    root: [
        "plan.json",
        "synthetic.json",
        "disjoint.json",
        "camera.json",
        "fresh.json",
        "retained.json",
        "synthetic.log",
        "disjoint.log",
        "camera.log",
        "fresh.log",
        "retained.log",
        "tests.log",
        "sensitivity.py",
        "sensitivity.json",
        "sensitivity.log",
        "review.py",
        "review.log",
        "review/result.json",
        "publish.py",
        "work/src/demosaic/flexible_edge.py",
        "work/src/demosaic/full_frame_edge.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/src/demosaic/surface_phase_aggregation.py",
        "work/scripts/probe_flexible_query_edges.py",
    ],
    root.parent / "local-phase-bounds-v1": ["review.py", "null-fresh.json", "null-retained.json"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
    root.parent / "affinity-first-fresh-v3": ["review.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            source = folder / name
            entry = bundle.gettarinfo(str(source), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with source.open("rb") as f:
                bundle.addfile(entry, f)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "rail_residual_viewed": 1,
        "new_checkpoint": None,
    },
)
