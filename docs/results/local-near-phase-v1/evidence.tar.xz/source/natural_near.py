"""Check ordinary-photo recipients with authentic and phase-incompatible far context."""

from pathlib import Path
from statistics import mean
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import _spacing
from near_phase import OUT,qualify,replay

ROI = (176,176,160,160)
LOCAL = (48,48,160,160)
QUERY = np.s_[...,64:192,64:192]
RGB = np.s_[...,48:208,48:208]


def main():
    calibration = reference(OUT/'calibration.json')
    policy = read_json(checked(calibration))['policy']
    new_contexts = reference(OUT/'contexts-calibration.json')
    natural = reference(OUT.parent/'local-weak-contrast-v1/natural-controls.json')
    scenes = read_json(checked(natural))
    paired = read_json(checked(new_contexts))
    plan = read_json(checked(paired['plan']))
    rows = []
    modes = {'combined':'combined','contrast':'contrast','replace':policy['replace']['choice'],'lift':policy['lift']['choice']}
    for org,transfer in zip(scenes['rows'],paired['records'],strict=True):
        assert org['id']==transfer['id']
        f = replay.arrays(org['input'])
        other = np.load(checked(transfer['streams'][0]['far_phase']),allow_pickle=False)
        other[QUERY] = f['scene_packed'][QUERY]
        np.testing.assert_array_equal(other[QUERY],f['packed'][0])
        colors,wb,matrix = f['colors'],f['wb'],f['matrix']
        baseline = f['parent'][RGB].astype('d')
        target = f['target'][RGB].astype('d')
        evaluations = {}
        for name,arr in (('natural',f['scene_packed']),('phase_mismatch',other)):
            freq = _spacing(arr,colors,*ROI[:2],clearance=48)
            levels, trace = qualify(f['parent'],LOCAL,arr,colors,ROI,freq,plan['noise'],wb,matrix,clearance=48)
            abs_ = lambda pred: float(np.sqrt(np.mean(replay.luma((pred-target)[None],wb,matrix)**2))*65535)
            dif = lambda pred: float(np.sqrt(np.mean((pred-baseline)**2))*65535)
            scores = {k:{'added_rgb_DN16':dif(levels[v]),'luma_error_DN16':abs_(levels[v])} for k,v in modes.items()}
            scores['parent'] = {'added_rgb_DN16':0.,'luma_error_DN16':abs_(baseline)}
            evaluations[name] = {'scores':scores,'frequency_found':freq is not None,'weak_admitted':bool(trace['selected'])}
        rows.append({'id':org['id'],'input':org['input'],'nomination_context':transfer['streams'][0]['far_phase'],'observations':evaluations})
    summary = {}
    for name in ('natural','phase_mismatch'):
        group = [r['observations'][name] for r in rows]
        avg = {label:{k:mean(q['scores'][label][k] for q in group) for k in ('added_rgb_DN16','luma_error_DN16')}
               for label in group[0]['scores']}
        summary[name] = {'means':avg,'with_frequency_pair':sum(x['frequency_found'] for x in group),
                         'admitted_weak_crops':sum(x['weak_admitted'] for x in group)}
    write_json(OUT/'natural-replay.json',{'driver':reference(Path(__file__)),'calibration':calibration,'source':natural,
                                         'alternate_donors':new_contexts,'observations':rows,'summary':summary})


if __name__=='__main__':
    main()
