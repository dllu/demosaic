"""Compare near-phase alternatives at the frozen choices and matched gap error."""

from pathlib import Path
from statistics import mean
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from near_phase import OUT,METHODS
from replay_near import one_context
from reduce_support import RESPONSE,ADDED,FALSE,compare,evaluate,means,QUIET

ABS = 'fundamental_intact_RMS_DN16'
PRIMARY = ('response','lift','ring','outer')


def extent(rows,key):
    return {m: {'nonzero_draws':sum(value>0 for value in values),'max_DN16':max(values)} for m in QUIET
            if (values:=[evaluate(d,(key,1))[m] for row in rows for d in row['draws'] if m in d['powers'][key]])}


def matched(rows,choice,goal_key):
    first,second = (means(rows,(c,1))[goal_key] for c in (choice,'contrast'))
    if goal_key==RESPONSE:
        anchor = means(rows,('combined',1))[goal_key]
        first,second = first-anchor,second-anchor
    delivered = min(first,second)
    assert delivered >= 0
    a,b = [(k,delivered/p if p>0 else 1.) for k,p in ((choice,first),('contrast',second))]
    return {'tapered_arms':(a,b),'paired':compare(rows,a,b)}


def evidence(rows):
    stats = {}
    for index,title in ((0,'intact'),(1,'outside_only'),(2,'strong_only'),(3,'flat_core'),(4,'edge_only'),(5,'uniform')):
        crops = [d['evidence'][index] for r in rows for d in r['draws']]
        applied = [e for e in crops if e.get('selected')]
        failed = [e for e in applied if not e['far_eligible']]
        stats[title] = {'total':len(crops),'weak_selected':len(applied),'far_available':len(applied)-len(failed),
                        'local_available':{m:sum(e['guides'][m]['eligible']>0 for e in failed) for m in METHODS},
                        'local_scores_above_2_5':{m:sum(e['guides'][m]['above_2_5'] for e in failed) for m in METHODS}}
    return stats


def perturbation(records):
    matched_pairs = [d for case in records for d in case['streams'] if d['original_frequency'] is not None and d['far_frequency'] is not None]
    errors = [np.linalg.norm(np.asarray(d['original_frequency'])-np.asarray(d['far_frequency']),axis=-1) for d in matched_pairs]
    return {'draws_with_both_frequency_pairs':len(errors),'identical_frequency_pairs':sum(bool(np.all(i==0)) for i in errors),
            'maximum_absolute_frequency_shift':float(np.max(errors))}


def source_verify(before,after):
    keys = {'combined':'combined','weak':'weak','fixed':'phase_guard','contrast':'guarded_hard_-5'}
    maxima = dict.fromkeys(keys,0.)
    for a,b in zip(before,after,strict=True):
        assert a['id']==b['id']
        for first,other in zip(a['draws'],b['draws'],strict=True):
            assert first['input']==other['input'] and first['outputs']==other['outputs']
            for new,old in keys.items():
                for metric,value in first['nominal'][old].items():
                    delta = abs(other['nominal'][new][metric]-value)
                    maxima[new] = max(maxima[new],delta)
    assert max(maxima.values())<1e-10, maxima
    return maxima


def main():
    lock = reference(OUT/'calibration.json')
    calibration = read_json(checked(lock))
    policy = calibration['policy']
    checks = {'combined':'combined','weak':'weak','fixed':'fixed','contrast':'contrast',
              'replace':policy['replace']['choice'],'lift':policy['lift']['choice'],
              'ring':policy['by_family']['ring64/replace']['choice'],
              'outer':policy['by_family']['collar32/replace']['choice']}
    new = reference(OUT/'confirmation.json')
    held = read_json(checked(new))
    assert held['calibration']==lock and len(held['rows'])==32
    result = {}
    for name,ref,data in (('calibration',lock,calibration),('confirmation',new,held)):
        context = read_json(checked(data['source']))
        score = {'source':ref,'frequency_audit':perturbation(context['records'])}
        for key in ('authentic','shifted'):
            rows = one_context(data['rows'],key)
            arms = {k:means(rows,(v,1)) for k,v in checks.items()}
            pairs = {k:{'nominal':compare(rows,(v,1),('contrast',1)),
                      'matched_gap':matched(rows,v,ADDED),'matched_response':matched(rows,v,RESPONSE),
                      'quiet':extent(rows,v)} for k,v in checks.items() if k in ('replace','lift','ring','outer')}
            score[key] = {'means':arms,'against_contrast':pairs,'assessments':evidence(rows),'quiet':extent(rows,'contrast')}
            if name=='calibration' and key=='authentic':
                prior = reference(OUT.parent/'local-weak-contrast-v1/fresh.json')
                score['original_matches_prior'] = {'prior':prior,'maximum_difference':source_verify(read_json(checked(prior))['rows'],rows)}
            print(name,key,score[key]['assessments']['intact'],flush=True)
            for m,v in arms.items():
                print(m,*[round(v[k],6) for k in (RESPONSE,ABS,ADDED,FALSE)],flush=True)
        result[name]=score
    write_json(OUT/'summary.json',{'driver':reference(Path(__file__)),'policy':lock,'arms':checks,'panels':result})


if __name__=='__main__':
    main()
