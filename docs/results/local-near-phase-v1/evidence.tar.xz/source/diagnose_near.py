"""Inspect phase eligibility on both standing camera crops."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import _spacing
from near_phase import OUT, guides, qualify
from review_presence import FIXED, arrays


def main():
    reference_panels = reference(FIXED)
    output = []
    for item in read_json(checked(reference_panels))['standing']:
        f = arrays(item['input'])
        raw,colors,wb,matrix = [f[k][0] for k in ('packed','colors','wb','matrix')]
        roi = tuple(item['local_ROI']); noise=item['noise']
        frequency = _spacing(raw,colors,*roi[:2],clearance=16)
        parent = np.load(checked(item['predictions']['local50k']),allow_pickle=False)[0]
        values,trace = qualify(parent,roi,raw,colors,roi,frequency,noise,wb,matrix,clearance=16)
        support = []
        if frequency is not None:
            for direction in (0,1):
                proposal = guides(raw,colors,roi,frequency,direction,noise['shot'],noise['read'])
                counts = {k:{'eligible':int(valid.sum()),'above_2_5':int((valid&(score>2.5)).sum()),
                      'above_3_5':int((valid&(score>3.5)).sum()),
                      'peak':float(score[valid].max()) if valid.any() else None} for k,(valid,score,_) in proposal.items()}
                support.append(counts)
        changes = {k:float(np.sqrt(np.mean((v.astype('d')-values['contrast'])**2))*65535) for k,v in values.items()}
        print(item['id'],trace['weak'],trace.get('far_eligible'),
              [{key:(v['eligible'],v['above_2_5'],v['above_3_5']) for key,v in d.items()} for d in support],
              max((value,key) for key,value in changes.items() if '/' in key),flush=True)
        output.append({'id':item['id'],'input':item['input'],'noise':noise,'trace':trace,
                       'guides_both_directions':support,'difference_from_contrast_DN16':changes})
    write_json(OUT/'standing-diagnostics.json',{'driver':reference(Path(__file__)),
                                                'source':reference_panels,'rows':output})


if __name__=='__main__':
    main()
