"""Freeze new exact targets and capture paired, phase-incompatible far context."""

from dataclasses import replace
from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_training_data import scene_seed
from demosaic.mesh_carrier_fit import _spacing
from near_phase import OUT
import capture_contrast as prior
from capture_optical import filtered_observation

FRESH = OUT/'fresh'
SEED = 202611200530
CONTEXT_SEED = 202611209031
QUERY = np.s_[...,64:192,64:192]


def capture_fresh():
    dev = OUT.parent/'local-weak-contrast-v1/fresh/plan.json'
    prior.OUT = FRESH
    prior.SEED = SEED
    prior.COUNT = 32
    prior.prior.EXCLUSIONS = (*prior.prior.EXCLUSIONS,dev)
    prior.main()


def far_variant(fixture):
    wire = prior.prior.earlier.capture_wide.wire_math
    background = wire.decode(fixture['source'],fixture['box'])
    geo = fixture['geometry']
    recipient = wire.exact(background,geo)[0][1]
    y,x = torch.meshgrid(torch.arange(512)-255.5,torch.arange(512)-255.5,indexing='ij')
    shell = ((torch.maximum(x.abs(),y.abs())-132)/27).clamp(0,1)
    fx,fy = geo['frequency'][1]
    phase = 2*torch.pi*(fx*x+fy*y)+geo['phase'][1]
    x_weight = torch.sigmoid((x.abs()-y.abs())/4)
    x_shift = torch.where(x>0,0.,torch.pi)
    y_shift = torch.where(y>0,torch.pi/2,-torch.pi/2)
    shift = x_weight*x_shift + (1-x_weight)*y_shift
    alternative = recipient + .025*shell*(torch.cos(phase+shift)-torch.cos(phase))
    torch.testing.assert_close(recipient[...,124:388,124:388],alternative[...,124:388,124:388],rtol=0,atol=0)
    assert torch.isfinite(alternative).all() and 0 < alternative.min() and alternative.max() < 1
    return alternative


def pair_contents(name):
    start = monotonic()
    location = FRESH if name=='fresh' else OUT.parent/'local-weak-contrast-v1/fresh'
    inputs = reference(location/'inputs.json')
    parent = reference(location/'parent/result.json')
    records = read_json(checked(inputs))
    plan = read_json(checked(records['plan']))
    destination = OUT/f'exterior-{name}'
    destination.mkdir(exist_ok=True)
    result = []
    for fixture,observation in zip(plan['sources'],records['observations'],strict=True):
        assert fixture['id']==observation['id']
        source = far_variant(fixture)
        streams = []
        for draw in observation['streams']:
            binding = draw['data']
            seed = scene_seed(CONTEXT_SEED,fixture['index']*2+draw['draw'],'separate-far-noise')
            settings = fixture['camera'] | {'noise_seed':seed}
            recipe = replace(sample_scene_recipe(SEED),**settings)
            sensor = filtered_observation(source,recipe,plan['sigma'])
            with np.load(checked(binding),allow_pickle=False) as file:
                context = sensor.packed.numpy().copy()
                previous = file['scene_packed']
                colors = file['colors']
                np.testing.assert_array_equal(sensor.colors.numpy(),colors)
                context[QUERY] = previous[QUERY]
                np.testing.assert_array_equal(context[QUERY],previous[QUERY])
                original_frequency = _spacing(previous,colors,176,176,clearance=48)
                modified_frequency = _spacing(context,colors,176,176,clearance=48)
                bound = destination/f'{fixture["id"]}-draw{draw["draw"]}.npy'
                with bound.open('xb') as handle:
                    np.save(handle,context,allow_pickle=False)
            streams.append({'original':binding,'far_phase':reference(bound),'noise_seed':seed,'draw':draw['draw'],
                            'original_frequency':None if original_frequency is None else original_frequency.tolist(),
                            'far_frequency':None if modified_frequency is None else modified_frequency.tolist()})
        result.append({'id':fixture['id'],'streams':streams})
        if len(result)%8==0:
            print('Paired far context',name,len(result),flush=True)
    write_json(OUT/f'contexts-{name}.json',{'driver':reference(Path(__file__)),'plan':records['plan'],'inputs':inputs,
                                          'parent':parent,'records':result,'seconds':monotonic()-start})


if __name__=='__main__':
    torch.set_num_threads(2)
    name = sys.argv[1]
    if name=='prepare-fresh':
        capture_fresh()
        pair_contents('fresh')
    else:
        pair_contents(name)
