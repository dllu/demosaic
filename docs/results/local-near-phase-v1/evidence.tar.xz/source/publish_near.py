"""Publish paired context experiments, the packaged crop fit and native evidence."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from near_phase import HERE,OUT

ROOT = Path.cwd()
ASSETS=ROOT/'docs/assets'/HERE.name
RESULTS=ROOT/'docs/results'/HERE.name
RECEIPTS=('calibration.json','confirmation.json','contexts-calibration.json','contexts-fresh.json',
          'fresh/plan.json','fresh/inputs.json','fresh/parent/result.json','summary.json','chart.json',
          'support-audit.json','standing-diagnostics.json','natural-replay.json','board-camera.json',
          'board-exact.json','api-proof.json')


def binding(path):
    return reference(path)|{'path':str(path.relative_to(ROOT))}


def image(ref):
    source=checked(ref)
    dest=ASSETS/source.name
    shutil.copyfile(source,dest)
    result=binding(dest)
    assert result['sha256']==ref['sha256']
    return result


def board(row):
    pixels=image(row['image'])
    with Image.open(ROOT/pixels['path']) as png:
        for item in row['panels']:
            x,y,w,h=item['png_xywh']
            assert (w,h)==(160,160)
            assert 0<=x<x+w<=png.width and 0<=y<y+h<=png.height
    return row|{'image':pixels}


def main():
    ASSETS.mkdir(exist_ok=True,parents=True)
    RESULTS.mkdir(exist_ok=True,parents=True)
    refs={key:reference(OUT/key) for key in RECEIPTS}
    data={key:read_json(checked(ref)) for key,ref in refs.items()}
    for entry in data.values():
        for key in ('driver','operator'):
            if key in entry:
                checked(entry[key])
    for key in ('confirmation','board-camera','board-exact','natural-replay'):
        assert data[f'{key}.json']['calibration']==refs['calibration.json']
    assert data['board-exact.json']['data']['source']==refs['confirmation.json']
    assert data['calibration.json']['source']==refs['contexts-calibration.json']
    assert data['confirmation.json']['source']==refs['contexts-fresh.json']
    assert data['confirmation.json']['parents']==refs['fresh/parent/result.json']
    assert data['confirmation.json']['plan']==refs['fresh/plan.json']
    assert data['fresh/parent/result.json']['inputs']==refs['fresh/inputs.json']
    assert data['fresh/inputs.json']['plan']==refs['fresh/plan.json']
    assert data['chart.json']['summary']==refs['summary.json']
    assert data['support-audit.json']['contexts']==refs['contexts-fresh.json']
    proof=data['api-proof.json']
    assert proof['source']==refs['confirmation.json'] and proof['maximum_difference_DN16']<.002
    assert proof['counts']['authentic']==proof['counts']['shifted']==384 and len(proof['camera'])==8
    for test in data['fresh/parent/result.json']['records']:
        for draw in test['streams']:
            checked(draw['data'])
            for pred in draw['outputs'].values():
                checked(pred)
    for kind in ('calibration','fresh'):
        for test in data[f'contexts-{kind}.json']['records']:
            for draw in test['streams']:
                checked(draw['original'])
                checked(draw['far_phase'])
    evidence={f'receipts/{key}':ref for key,ref in refs.items()}
    evidence.update({f'source/{p.name}':reference(p) for p in sorted(HERE.glob('*.py'))})
    evidence.update(proof['production_files'])
    evidence['tests/test_mesh_carrier_fit.py']=reference(ROOT/'tests/test_mesh_carrier_fit.py')
    archive=RESULTS/'evidence.tar.xz'
    with tarfile.open(archive,'x:xz') as tar:
        for name,ref in evidence.items():
            tar.add(checked(ref),arcname=name,recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames())==evidence.keys()
        for name,ref in evidence.items():
            with tar.extractfile(name) as loading:
                assert hashlib.file_digest(loading,'sha256').hexdigest()==ref['sha256']
    camera=[r|{'native':[board(pic) for pic in r['native']]} for r in data['board-camera.json']['data']['rows']]
    exact=[r|{'board':board(r['board']),'triplet':board(r['triplet'])} for r in data['board-exact.json']['data']['boards']]
    manifest=ASSETS/'manifest.json'
    write_json(manifest,{'camera':camera,'exact':exact,'chart':image(data['chart.json']['image'])})
    summary=RESULTS/'summary.json'
    shutil.copyfile(checked(refs['summary.json']),summary)
    assert binding(summary)['sha256']==refs['summary.json']['sha256']
    write_json(RESULTS/'publication.json',{
        'parent_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'manifest':binding(manifest),'summary':binding(summary),'archive':binding(archive),
        'prior_publication':binding(ROOT/'docs/results/local-weak-contrast-v1/publication.json'),
        'receipt_bindings':refs,'archive_members':evidence,
        'standing_native_boards_viewed':sum(len(x['native']) for x in camera),'native_triplets_viewed':len(exact),
        'new_weights':None})


if __name__=='__main__':
    main()
