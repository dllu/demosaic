"""Prove that each candidate phase omits the samples it will test."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import _positions,_spacing
from near_phase import OUT,annular_coefficient,center_score,guides,observations

CROP = (176,176,160,160)
PAIR = np.s_[...,64:192,64:192]


def main():
    record = reference(OUT/'contexts-fresh.json')
    parent = read_json(checked(record))
    plan = read_json(checked(parent['plan']))
    checks = {}
    random = np.random.default_rng(205315)
    shot,read = [plan['noise'][k] for k in ('shot','read')]
    pos = CROP[:2]
    for case,prior in zip(plan['sources'][:4],parent['records'][:4],strict=True):
        capture = prior['streams'][0]
        with np.load(checked(capture['original']),allow_pickle=False) as archive:
            scene, colors = archive['scene_packed'].copy(), archive['colors']
            scene[PAIR] = archive['packed'][0]
        other = np.load(checked(capture['far_phase']),allow_pickle=False)
        other[PAIR] = scene[PAIR]
        freq = _spacing(scene,colors,*pos,clearance=48)
        assert freq is not None
        ordinary = guides(scene,colors,CROP,freq,1,shot,read)
        transferred = guides(other,colors,CROP,freq,1,shot,read)
        for mode in ordinary:
            for one,two in zip(ordinary[mode],transferred[mode],strict=True):
                np.testing.assert_array_equal(one,two)
        changed = scene.copy()
        y,x = pos[1]//2,pos[0]//2
        changed[:,y:y+80,x:x+80] += random.normal(0,.01,(4,80,80))
        for width in (16,32,48):
            a = observations(scene,pos,freq,1,shot,read,width)
            b = observations(changed,pos,freq,1,shot,read,width)
            for one,two in zip(a,b,strict=True):
                np.testing.assert_array_equal(one,two)
        changed = scene.copy()
        greens = tuple(2*r+c for r,c in _positions(colors,*pos))
        row,col = 4,6
        within = np.s_[...,y+row*8-4:y+row*8+12,x+col*8-4:x+col*8+12]
        changed[within] += random.normal(0,.035,(4,16,16))
        a = annular_coefficient(scene,pos,freq,1,shot,read,greens)
        b = annular_coefficient(changed,pos,freq,1,shot,read,greens)
        n = row*10+col
        for one,two in zip(a,b,strict=True):
            np.testing.assert_array_equal(one[n],two[n])
        # Put a fixed, nonzero template on the checked cell even if its real annulus has no support.
        fixed = np.zeros_like(a[0])
        fixed[n,:,0] = .01
        original = center_score(scene,pos,freq,1,shot,read,fixed,greens,annular=True)
        after = center_score(changed,pos,freq,1,shot,read,fixed,greens,annular=True)
        max_change = float(abs(after[n]-original[n]))
        assert max_change>0
        checks[case['camera']['pattern']] = {'input':capture['original'],'far':capture['far_phase'],
            'all_held_center_values_changed_for_collar':25600,'held_values_changed_for_annulus':1024,
            'maximum_score_change':max_change}
    assert len(checks)==4
    write_json(OUT/'support-audit.json',{'driver':reference(Path(__file__)),'contexts':record,'layouts':checks})


if __name__=='__main__':
    main()
