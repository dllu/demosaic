"""Render the locked near-phase alternatives and matching exact RGB targets."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from near_phase import OUT,qualify,replay
import review_presence as view

LABELS = {'parent':'Local 50k','nested':'Combined check','weak':'Weak posterior','contrast':'Weak phase contrast',
          'ring_phase':'Near phase replacement','lift':'Near phase lift','annular':'64px annulus','pooled':'Whole collar'}


def arms(parent,local,scene,colors,roi,peaks,noise,wb,matrix,policy):
    values,trace = qualify(parent,local,scene,colors,roi,peaks,noise,wb,matrix,clearance=16 if local==roi else 48)
    keys = {'nested':'combined','weak':'weak','contrast':'contrast','ring_phase':policy['replace']['choice'],
            'lift':policy['lift']['choice'],'annular':policy['by_family']['ring64/replace']['choice'],
            'pooled':policy['by_family']['collar32/replace']['choice']}
    return {'parent':view.section(parent,*local)} | {k:values[v] for k,v in keys.items()},trace


def exact(policy,dest):
    source = reference(OUT/'confirmation.json')
    data = read_json(checked(source))
    plan = read_json(checked(data['plan']))
    x,y,w,h = plan['query']
    local = replay.ROI
    roi = (x+local[0],y+local[1],*local[2:])
    chosen = []
    for family in ('strip','ellipse'):
        options = []
        for r in data['rows']:
            if r['family']!=family:
                continue
            for row in r['draws']:
                nom = row['contexts']['shifted']['nominal']
                key = replay.ABSOLUTE
                improvement = nom[policy['replace']['choice']][key]-nom['contrast'][key]
                if row['draw']==0 and r['fixture']['camera']['pattern']=='BGGR':
                    options.append((improvement,r,row))
        chosen.append(max(options,key=lambda row:row[0]))
    results = []
    for change,row,draw in chosen:
        f = replay.arrays(draw['input'])
        alt = np.load(checked(draw['far_phase']),allow_pickle=False)
        alt[:,y//2:(y+h)//2,x//2:(x+w)//2] = f['packed'][0]
        colors,wb,matrix = (f[k] for k in ('colors','wb','matrix'))
        camera = {'colors':colors[None],'wb':wb[None],'matrix':matrix[None],'packed':f['packed'][:1]}
        outputs = [np.load(checked(draw['outputs'][label]),allow_pickle=False)[0] for label in ('local50k','v120')]
        actual = draw['contexts']['shifted']['actual_frequency']
        params = None if actual is None else np.asarray(actual)
        original,v120=outputs
        options, trace = arms(original,local,alt,colors,roi,params,plan['noise'],wb,matrix,policy)
        listed = [noisy_malvar(camera)[0],v120]
        for item in options.values():
            full = original.copy()
            view.section(full,*local)[:] = item
            listed.append(full)
        listed.append(f['target'][0])
        labels = ['Noisy Malvar','V120 EMA',*(LABELS[k] for k in options),'Exact GT']
        exact = view.native_board(dest,row['id'],listed,camera,{'input':draw['input'],'shifted_exterior':draw['far_phase'],
            'fixture':row['fixture'],'query':plan['query'],'noise':plan['noise'],'weights':plan['checkpoints'],
            'optical_sigma':plan['sigma'],'draw':draw['draw'],'trace':trace,'response_change_points':change},labels=labels,
            triplet_indices=(0,labels.index(LABELS['ring_phase']),len(labels)-1))
        results.append(exact)
    return {'source':source,'selection':'Largest replacement gain among BGGR draw-zero strips and ellipses','boards':results}


def main(kind):
    torch.set_num_threads(2)
    source = reference(OUT/'calibration.json')
    policy = read_json(checked(source))['policy']
    dest = OUT/'boards'/kind
    dest.mkdir(exist_ok=True,parents=True)
    if kind=='camera':
        view.arcs=arms
        view.NAMES=LABELS
        result = view.standing(policy,dest)
    else:
        result = exact(policy,dest)
    write_json(OUT/f'board-{kind}.json',{'driver':reference(Path(__file__)),'calibration':source,'data':result})


if __name__=='__main__':
    main(sys.argv[1])
