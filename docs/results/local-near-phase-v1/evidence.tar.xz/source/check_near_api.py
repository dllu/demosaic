"""Check pixel parity with the frozen near-phase fallback on all held crops."""

from pathlib import Path
from statistics import median
from time import monotonic
import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import _spacing,refine_raw_mesh_carriers
from near_phase import OUT,qualify,replay
from review_presence import FIXED,arrays,section

MODES = ('weak-near-phase','weak-phase-contrast')


def check(parent,local,raw,colors,roi,profile,wb,matrix,key):
    x,y,w,h=local
    crop=section(parent,*local)
    halo=16 if local==roi else 48
    context=parent[:,y-16:y+h+16,x-16:x+w+16]
    f = _spacing(raw,colors,*roi[:2],clearance=halo)
    expected,trace=qualify(parent,local,raw,colors,roi,f,profile,wb,matrix,clearance=halo)
    args={'shot':profile['shot'],'read':profile['read'],'white_balance':wb,'camera_to_srgb':matrix,
          'parent_context':context,'donor_clearance':halo}
    values,seconds={},{}
    for method in MODES:
        start=monotonic()
        values[method]=refine_raw_mesh_carriers(crop,raw,colors,roi,method=method,**args)
        seconds[method]=monotonic()-start
    error = float(np.max(np.abs(values[MODES[0]].astype('d')-expected[key]))*65535)
    assert error<.003,error
    differs=not np.array_equal(values[MODES[0]],values[MODES[1]])
    if trace.get('far_eligible') or not trace.get('guides',{}).get('tangent32',{}).get('eligible'):
        assert not differs
    return {'maximum_difference_DN16':error,'different_from_contrast':differs,
            'far_eligible':trace.get('far_eligible',False), 'near_eligible':trace.get('guides',{}).get('tangent32',{}).get('eligible',0)>0,
            'seconds':seconds}


def main():
    torch.set_num_threads(2)
    source=reference(OUT/'confirmation.json')
    data=read_json(checked(source))
    plan=read_json(checked(data['plan']))
    key=read_json(checked(data['calibration']))['policy']['replace']['choice']
    assert key=='tangent32/replace/2.5'
    x,y,w,h=plan['query']; local=replay.ROI; roi=(x+local[0],y+local[1],*local[2:])
    cut=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    rows=[]
    for sample in data['rows']:
        for d in sample['draws']:
            f=arrays(d['input'])
            parents=np.load(checked(d['outputs']['local50k']),allow_pickle=False)
            vals={}
            for name,b in (('authentic',f['scene_packed'].copy()),('shifted',np.load(checked(d['far_phase']),allow_pickle=False))):
                tests=[]
                for parent,raw in zip(parents,f['packed'],strict=True):
                    b[cut]=raw
                    tests.append(check(parent,local,b,f['colors'],roi,plan['noise'],f['wb'],f['matrix'],key))
                vals[name]=tests
            rows.append({'id':sample['id'],'draw':d['draw'],'results':vals})
        if len(rows)%16==0:
            print('Verified same-recipient pairs',len(rows),flush=True)
    camera_ref=reference(FIXED)
    cameras=[]
    for row in read_json(checked(camera_ref))['standing']:
        f=arrays(row['input'])
        roi=tuple(row['local_ROI'])
        parent=np.load(checked(row['predictions']['local50k']),allow_pickle=False)[0]
        a=check(parent,roi,f['packed'][0],f['colors'][0],roi,row['noise'],f['wb'][0],f['matrix'][0],key)
        cameras.append({'id':row['id'],'result':a})
    measured={name:[r for record in rows for r in record['results'][name]] for name in ('authentic','shifted')}
    measured['locally_eligible']=[r for records in measured.values() for r in records if r['near_eligible']]
    timing={k:{m:float(1000*median(r['seconds'][m] for r in vals)) for m in MODES} for k,vals in measured.items()}
    max_error=max(r['maximum_difference_DN16'] for r in [*measured['authentic'],*measured['shifted'],*(c['result'] for c in cameras)])
    tracked=['src/demosaic/mesh_carrier_fit.py','src/demosaic/_mesh_weak_posterior.py',
             'src/demosaic/_mesh_weak_phase.py','src/demosaic/_mesh_near_phase.py']
    write_json(OUT/'api-proof.json',{'driver':reference(Path(__file__)),'source':source,'standing':camera_ref,
        'production_files':{f:reference(f) for f in tracked},'pairs':rows,'camera':cameras,'maximum_difference_DN16':max_error,
        'median_cpu_ms':timing,'counts':{n:len(rs) for n,rs in measured.items()}})


if __name__=='__main__':
    main()
