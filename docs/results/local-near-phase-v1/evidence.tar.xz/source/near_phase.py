"""Use nearby Bayer samples to verify a weak correction when distant phase fails."""

from functools import lru_cache
from itertools import product
from pathlib import Path
import sys

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.ndimage import map_coordinates

from demosaic._mesh_weak_phase import _PIXEL_COORDS, _carrier, _cells
from demosaic.mesh_carrier_fit import _positions

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic')/HERE.name
sys.path.insert(0,str(HERE.with_name('local-weak-contrast-v1')))
import weak_contrast as contrast
from conditional import replay

SITES = tuple(np.ndindex(2,2))
CELL, ROI = 16,160
CELLS = 100
SQUARES = np.indices((10,10),dtype='d').reshape(2,-1).T*CELL + 7.5
METHODS = ('collar16','collar32','collar48','tangent32','ring64')
CUTS = (1.5,2.5,3.5)
KINDS = ('replace','lift')
OPTIONS = tuple((m,k,c,f'{m}/{k}/{c:g}') for m,k,c in product(METHODS,KINDS,CUTS))
ARMS = ('combined','weak','fixed','contrast',*(row[-1] for row in OPTIONS))


def rect(scene,origin,width,height,site):
    x,y = origin
    r,c = site
    xx,yy = x+c,y+r
    return scene[2*(yy%2)+xx%2,yy//2:yy//2+height//2,xx//2:xx//2+width//2]


@lru_cache(maxsize=12)
def background(width,height):
    y,x = (np.indices((height,width),dtype='d')+0.5)/np.array((height,width))[:,None,None]-.5
    return np.stack((np.ones_like(x),x,y,x*x,x*y,y*y),axis=-1)


def wave(width,height,left,top,frequencies):
    y,x = np.indices((height,width),dtype='d')
    phi = 2*np.pi*((x+left)[...,None]*frequencies[:,0]+(y+top)[...,None]*frequencies[:,1])
    return np.stack((np.cos(phi),np.sin(phi)),axis=-1)


def noise_term(value,shot,read):
    return np.maximum(2e-11,shot*np.maximum(0,value)+read)


def observations(scene,origin,freq,direction,shot,read,width):
    """Measure 20 disjoint rectangles surrounding the complete crop."""
    ox,oy = origin
    steps = range(0,ROI,32)
    parts = ([(i,-width,32,width) for i in steps]+[(i,ROI,32,width) for i in steps]+
             [(-width,j,width,32) for j in steps]+[(ROI,j,width,32) for j in steps])
    positions, values, information = [], [], []
    for x,y,w,h in parts:
        design = np.concatenate((background(w,h),wave(w,h,x,y,freq).reshape(h,w,4)),axis=-1)
        pairs, weights = [], []
        for r,c in SITES:
            samples = rect(scene,(ox+x,oy+y),w,h,(r,c)).ravel()
            model = design[r::2,c::2].reshape(len(samples),10)
            fit = np.linalg.pinv(model,rcond=1e-8)[6+direction*2:8+direction*2]
            pairs.append(fit@samples)
            weights.append(1/(noise_term(samples.mean(),shot,read)*np.square(fit).sum(axis=1).mean()))
        values.append(pairs)
        information.append(weights)
        positions.append((y+(h-1)/2,x+(w-1)/2))
    return np.asarray(positions),np.asarray(values),np.asarray(information)


def green_check(phase,power,coherence,greens):
    norm = np.linalg.norm(phase,axis=-1)
    units = phase/np.maximum(1e-15,norm[...,None])
    one,two = greens
    agreement = (units[:,one]*units[:,two]).sum(axis=1)
    good = (coherence>=.65) & (norm**2*power>=16)
    eligible = good[:,greens].all(axis=1)&(agreement>=.5)
    return np.where(good[...,None],phase,0.),eligible,agreement


def pooled_coefficient(positions,phase,power,greens,freq,mode):
    if mode=='tangent32':
        d = SQUARES[:,None]-positions[None]
        normal = freq[::-1]/np.linalg.norm(freq)
        tangent = normal[::-1]*[-1,1]
        weights = np.exp(-.5*((d@normal/50)**2+(d@tangent/100)**2))
    else:
        weights = np.ones((CELLS,len(positions)))
    effective = weights@power
    average = np.einsum('nd,dsi,ds->nsi',weights,phase,power)/np.maximum(1e-12,effective)[...,None]
    oriented = (weights@(np.linalg.norm(phase,axis=-1)*power))/np.maximum(effective,1e-12)
    coherence = np.linalg.norm(average,axis=-1)/np.maximum(oriented,1e-12)
    precision = effective**2/np.maximum(1e-12,weights**2@power)
    return green_check(average,precision,coherence,greens)


def annular_coefficient(scene,origin,frequencies,direction,shot,read,greens):
    """Fit a fully disjoint local ring for each 16-pixel check cell."""
    x,y = origin
    size = ROI+48
    shape = _carrier(64,-24,-24,frequencies)
    design = np.concatenate((background(64,64),shape.reshape(64,64,4)),axis=-1)
    rows,cols = np.indices((64,64))
    outer = (np.maximum(abs(rows-31.5),abs(cols-31.5))>=16)
    pairs, powers = [], []
    for r,c in SITES:
        samples = rect(scene,(x-24,y-24),size,size,(r,c))
        stencil = sliding_window_view(samples,(32,32))[::8,::8].reshape(CELLS,32,32)
        mask = outer[r::2,c::2]
        values = stencil[:,mask]
        solution = np.linalg.pinv(design[r::2,c::2][mask],rcond=1e-8)[6+direction*2:8+direction*2]
        pairs.append(values@solution.T)
        powers.append(1/(noise_term(values.mean(axis=1),shot,read)*np.square(solution).sum(axis=1).mean()))
    phases = np.stack(pairs,axis=1)
    return green_check(phases,np.stack(powers,axis=1),np.ones((CELLS,4)),greens)


def center_score(scene,origin,freq,direction,shots,read,phases,greens,*,annular=False):
    if annular:
        shape = np.broadcast_to(_carrier(16,0,0,freq),(CELLS,16,16,2,2))
    else:
        carrier = _carrier(160,0,0,freq)
        shape = carrier.reshape(10,16,10,16,2,2).swapaxes(1,2).reshape(CELLS,16,16,2,2)
    numerators,denominators = [],[]
    for s,(r,c) in enumerate(SITES):
        samples = _cells(rect(scene,origin,160,160,(r,c))).astype('d')
        smooth = np.broadcast_to(background(16,16)[r::2,c::2].reshape(1,64,6),(CELLS,64,6))
        strong = shape[:,r::2,c::2,1-direction,:].reshape(CELLS,64,2)
        nuisance = np.concatenate((smooth,strong),axis=-1)
        design = shape[:,r::2,c::2,direction,:].reshape(CELLS,64,2)
        template = (design@phases[:,s,:,None])[...,0]
        projection = (np.linalg.pinv(nuisance,rcond=1e-8)@template[...,None])[...,0]
        template -= np.einsum('npi,ni->np',nuisance,projection)
        denominator = noise_term(samples.mean(axis=1),shots,read)
        numerators.append(np.einsum('np,np->n',template,samples)/denominator)
        denominators.append(np.einsum('np,np->n',template,template)/denominator)
    signal,power = np.asarray(numerators),np.asarray(denominators)
    local = signal/np.sqrt(np.maximum(1e-10,power))
    pooled = signal.sum(axis=0)/np.sqrt(np.maximum(1e-10,power.sum(axis=0)))
    return np.minimum(pooled,local[list(greens)].min(axis=0)+1.5)


def guides(scene,colors,roi,freq,direction,shot,read):
    origin = roi[:2]
    greens = tuple(2*r+c for r,c in _positions(colors,*origin))
    bank = {w:observations(scene,origin,freq,direction,shot,read,w) for w in (16,32,48)}
    result = {}
    for m in METHODS:
        annular = m=='ring64'
        if annular:
            phase,valid,agreement = annular_coefficient(scene,origin,freq,direction,shot,read,greens)
        else:
            width = 32 if m=='tangent32' else int(m[6:])
            phase,valid,agreement = pooled_coefficient(*bank[width],greens,freq[direction],m)
        score = center_score(scene,origin,freq,direction,shot,read,phase,greens,annular=annular)
        result[m] = (valid,score,agreement)
    return result


def interpolate(points):
    return map_coordinates(points.reshape(10,10),_PIXEL_COORDS,order=1,mode='nearest',prefilter=False)


def qualify(parent,local,scene,colors,roi,freq,noise,wb,matrix,*,clearance=48):
    controls, detail = contrast.qualify(parent,local,scene,colors,roi,freq,noise,wb,matrix,clearance=clearance)
    baseline = controls['guarded_hard_-5']
    arms = dict.fromkeys(ARMS,baseline) | {'combined':controls['combined'],'weak':controls['weak'],'fixed':controls['phase_guard']}
    if not detail.get('selected') or detail.get('guard_phase_eligible'):
        return arms, {'weak':detail['weak'],'selected':detail.get('selected',[]),
                      'far_eligible':detail.get('guard_phase_eligible',False)}
    weak = detail['weak']
    station = guides(scene,colors,roi,freq,weak,noise['shot'],noise['read'])
    anchor = controls['combined']
    full = controls['hard_strength_-5']
    audit = {}
    valid_area = {}
    for method,(valid,z,agreement) in station.items():
        valid_area[method] = interpolate(valid.astype('d'))
        audit[method] = {'eligible':int(valid.sum()),'above_2_5':int((valid&(z>2.5)).sum()),
                         'station_scores':z.tolist(),'valid':valid.tolist(),
                         'minimum_green_phase_agreement':float(agreement.min())}
    for method,kind,cut,key in OPTIONS:
        use,z,_ = station[method]
        strength = np.clip(1 + (z-cut)/2,0,1) if kind=='replace' else np.clip((z-cut)/2,0,1)
        weight = interpolate(np.where(use,strength,0.))
        if kind=='replace':
            result = (1-valid_area[method])*baseline + valid_area[method]*anchor
            result += contrast.GUARD_GAIN*weight*(full.astype('d')-anchor)
        else:
            result = baseline + weight*(anchor + contrast.GUARD_GAIN*(full.astype('d')-anchor)-baseline)
        arms[key] = result.astype(anchor.dtype)
    return arms, {'weak':weak,'selected':detail['selected'],'far_eligible':False,'guides':audit}
