"""Plot guide availability and the actual weak recovery/gap tradeoff."""

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from near_phase import OUT
from reduce_support import ADDED,RESPONSE


def main():
    binding = reference(OUT/'summary.json')
    scored = read_json(checked(binding))['panels']['confirmation']
    fig,(left,right)=plt.subplots(1,2,figsize=(10.7,3.8),layout='constrained')
    availability=[]
    for panel in ('authentic','shifted'):
        x=scored[panel]['assessments']['intact']
        far=x['far_available'];near=x['local_available']['tangent32']
        availability.append([far,near,x['weak_selected']-far-near,x['total']-x['weak_selected']])
    prior=np.zeros(2)
    labels=('Distant accepted','Nearby available','Phase unavailable','Weak fit absent')
    palette=('#356393','#207365','#ca9561','#d6d8db')
    for values,label,color in zip(np.asarray(availability).T,labels,palette,strict=True):
        left.barh((0,1),values,left=prior,color=color,label=label,height=.46)
        for i,(size,origin) in enumerate(zip(values,prior,strict=True)):
            if size>=5:
                left.text(origin+size/2,i,f'{size:g}',ha='center',va='center',fontsize=9,
                          color='white' if label in labels[:2] else '#2d3435')
        prior+=values
    left.set_yticks((0,1),('Matched context','Shifted context'))
    left.invert_yaxis()
    left.set_xlim(0,64)
    left.set_xlabel('Intact draws')
    left.set_title('Phase coverage on the same 64 draws',loc='left',fontweight='bold',fontsize=10)
    left.legend(loc='upper center',bbox_to_anchor=(.5,-.27),ncols=2,frameon=False,fontsize=8)
    cells=scored['shifted']['means']
    details={
        'contrast':('Weak phase contrast','#356393','o',(-3,13)),
        'replace':('Near replacement','#207365','s',(-43,-18)),
        'lift':('Near lift','#825c91','^',(-18,10)),
        'ring':('64px annulus','#808b91','v',(2,-15)),
        'outer':('Whole collar','#c17a42','D',(6,8)),
    }
    for arm,(label,color,marker,offset) in details.items():
        score=cells[arm];p=(score[RESPONSE],score[ADDED])
        right.scatter(*p,color=color,marker=marker,s=43,zorder=3)
        right.annotate(label,p,xytext=offset,textcoords='offset points',fontsize=8,color='#30383d')
    right.set_xlim(16.55,18.12)
    right.set_ylim(.081,.151)
    right.set_title('Recovery when distant phase is shifted',loc='left',fontweight='bold',fontsize=10)
    right.set_xlabel('Recovered weak contrast (%)')
    right.set_ylabel('Added gap luma RMS (DN16)')
    right.grid(alpha=.16)
    for ax in (left,right):
        ax.spines[['top','right']].set_visible(False)
    plot=OUT/'near-phase-coverage-and-gap.png'
    fig.savefig(plot,dpi=160,facecolor='white',bbox_inches='tight',pad_inches=.08)
    write_json(OUT/'chart.json',{'driver':reference(Path(__file__)),'summary':binding,'image':reference(plot)})


if __name__=='__main__':
    main()
