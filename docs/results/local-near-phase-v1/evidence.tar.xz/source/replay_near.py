"""Lock a near-phase fallback and replay identical recipients under two far contexts."""

from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
import near_phase as model
from near_phase import OUT,replay
from reduce_support import ADDED,FALSE,RESPONSE
import replay_exterior_support as scoring


def load(name):
    context = reference(OUT/f'contexts-{name}.json')
    record = read_json(checked(context))
    parent = read_json(checked(record['parent']))
    plan = read_json(checked(record['plan']))
    assert record['inputs']==parent['inputs']
    x,y,w,h=plan['query']
    local = replay.ROI
    roi = (x+local[0],y+local[1],*local[2:])
    cut = np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    complete = []
    for fixture,entity,observed in zip(plan['sources'],parent['records'],record['records'],strict=True):
        assert fixture['id']==entity['id']==observed['id']
        draws = []
        for output,pair in zip(entity['streams'],observed['streams'],strict=True):
            assert output['data']==pair['original'] and output['draw']==pair['draw']
            f = replay.arrays(output['data'])
            data = np.load(checked(output['outputs']['local50k']),allow_pickle=False)
            altered = np.load(checked(pair['far_phase']),allow_pickle=False)
            scene = f['scene_packed']
            np.testing.assert_array_equal(scene[cut],altered[cut])
            repeated = {}
            for policy,raw in (('authentic',scene),('shifted',altered)):
                v = scoring.assess(fixture,plan['noise'],data,f,raw.copy(),cut,roi,f['sharp_target'])
                repeated[policy] = v
            draws.append({'draw':output['draw'],'input':output['data'],'outputs':output['outputs'],
                          'far_phase':pair['far_phase'],'contexts':repeated})
        complete.append({'id':fixture['id'],'fixture':fixture,'family':fixture['geometry']['family'],'draws':draws})
        if len(complete)%8==0:
            print('Same center, paired context',name,len(complete),flush=True)
    return context,record,complete


def one_context(rows,key):
    return [r|{'draws':[d['contexts'][key]|{n:d[n] for n in ('input','outputs','far_phase','draw')} for d in r['draws']]} for r in rows]


def locked(rows):
    samples = [d['nominal'] for r in one_context(rows,'shifted') for d in r['draws']]

    def summary(key):
        fields = [d[key] for d in samples]
        return {'choice':key,'means':{n:mean(d[n] for d in fields if n in d) for n in (RESPONSE,ADDED,FALSE,'flat_added_DN16')}}

    base = summary('contrast')['means']
    nominal = [summary(key)|{'fit':method,'delivery':kind,'cut':cut} for method,kind,cut,key in model.OPTIONS]
    result = {'controls':{x:summary(x) for x in ('combined','weak','fixed','contrast')},'budget':base[ADDED],
              'choices':nominal,'by_family':{}}
    for k in model.KINDS:
        estimates = [p for p in nominal if p['delivery']==k]
        accepted = [p for p in estimates if p['means'][ADDED] <= base[ADDED]+1e-12]
        if accepted:
            best = max(accepted,key=lambda v:(v['means'][RESPONSE],-v['means'][ADDED]))
            result[k] = best | {'calibration_budget_met':True}
        else:
            best = min(estimates,key=lambda v:(v['means'][ADDED],-v['means'][RESPONSE]))
            result[k] = best | {'calibration_budget_met':False}
        for proposal in model.METHODS:
            group = [p for p in estimates if p['fit']==proposal]
            accepted_group = [p for p in group if p['means'][ADDED]<=base[ADDED]+1e-12]
            choose = max(accepted_group,key=lambda v:(v['means'][RESPONSE],-v['means'][ADDED])) if accepted_group else min(group,key=lambda v:(v['means'][ADDED],-v['means'][RESPONSE]))
            result['by_family'][f'{proposal}/{k}'] = choose | {'calibration_budget_met':bool(accepted_group)}
    return result


def main(kind):
    torch.set_num_threads(2)
    start = monotonic()
    scoring.model=model
    binding = {'driver':reference(Path(__file__)),'operator':reference(model.__file__)}
    if kind=='calibration':
        context, record, rows = load(kind)
        write_json(OUT/'calibration.json',binding | {'source':context,'parents':record['parent'],'plan':record['plan'],
                                                    'rows':rows,'policy':locked(rows),'seconds':monotonic()-start})
    else:
        calibration = reference(OUT/'calibration.json')
        assert read_json(checked(calibration))['operator']==binding['operator']
        context, record, rows = load(kind)
        write_json(OUT/'confirmation.json',binding | {'source':context,'parents':record['parent'],'plan':record['plan'],
                                                      'rows':rows,'calibration':calibration,'seconds':monotonic()-start})


if __name__=='__main__':
    main(sys.argv[1])
