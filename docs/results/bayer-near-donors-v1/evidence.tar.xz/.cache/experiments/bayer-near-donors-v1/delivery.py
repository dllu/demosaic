"""Deliver disjoint near proposals and checked refits at the frozen local dose."""
from pathlib import Path
import time

import numpy as np

from screen import ROOT,LAST,phase,nominate,NEGATIVES
from evidence import old
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LABELS={"parent":"Corpus 100k EMA","cross":"Far proposal, Bayer check",
        "near-fallback":"Near fallback, Bayer check","near-refit":"Near refit",
        "half-refit":"Near half-step refit"}


def checked_terms(diagnostic, cutoff):
    accepted=[value is not None and value>cutoff for value in diagnostic["near_vs_prior"]]
    terms=np.where(np.array(accepted)[:,None],diagnostic["near"],diagnostic["prior"])
    return terms,accepted


def addition(raw,parent,data,noise,seed=None,spacing=None,terms=None,roi=phase.ROI):
    if seed is not None:
        values=np.asarray(seed)
        spacing=values[:,:2]
        terms=nominate.tangent_terms(values)
    return old.bends.correction(raw,parent,*data,noise,np.asarray(spacing),roi,old.DOSE,True,
                                {"locked":np.asarray(terms)})["locked"]


def observe(plan,decision,refit,half,prior,far,data,new_cutoff,fit_cutoff,half_cutoff,far_cutoff,group):
    assert len({row["input"]["sha256"] for row in (decision,refit,half,prior,far,data)})==1
    assert len({row["parent"]["sha256"] for row in (decision,refit,half,prior,data)})==1
    with np.load(checked(decision["input"]),allow_pickle=False)as f:
        raw={k:f[k]for k in f.files}
    with np.load(checked(decision["parent"]),allow_pickle=False)as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    packed=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
    target=raw["target"][...,y:y+h,x:x+w]
    noise=plan["profile"]
    shape=decision["shape"]
    values={a:parent.copy()for a in LABELS}
    marks=[]
    chosen=[]
    for evidence,optim,relaxed,previous,upstream in zip(decision["rows"],refit["rows"],half["rows"],
                                                        prior["rows"],far["rows"],strict=True):
        a,role=evidence["draw"],evidence["role"]
        assert (a,role)==(optim["draw"],optim["role"])==(relaxed["draw"],relaxed["role"])
        assert (a,role)==(previous["draw"],previous["role"])==(upstream["repeat"],upstream["role"])
        assert evidence["previous"]==optim["eligible"]==relaxed["eligible"]==upstream["formerly"]["admitted"]
        k=plan["roles"].index(role)
        tile=packed[a,k]
        control=parent[a,k]
        calibration=[raw[key][a,k]for key in ("colors","wb","matrix")]
        near_flag=False
        shape_flags=(False,False)
        half_flags=(False,False)
        if optim["eligible"]:
            fit=optim["candidate"]
            assert relaxed["candidate"]["prior"]==fit["prior"]
            kwargs={"spacing":fit["spacing"]}
            anchor=addition(tile,control,calibration,noise,terms=fit["prior"],**kwargs)
            shape_terms,shape_flags=checked_terms(fit,fit_cutoff)
            half_terms,half_flags=checked_terms(relaxed["candidate"],half_cutoff)
            shape_trial=addition(tile,control,calibration,noise,terms=shape_terms,**kwargs) if any(shape_flags) else anchor
            half_trial=addition(tile,control,calibration,noise,terms=half_terms,**kwargs) if any(half_flags) else anchor
            fallback=anchor
        else:
            far_seed=upstream["selected"]["local-warped"]
            far_check=previous["active_candidate"]
            assert far_seed["admitted"]==(far_check is not None)
            anchor=(addition(tile,control,calibration,noise,seed=far_seed["seed"])
                    if far_check is not None and far_check["cross"]>far_cutoff else np.zeros_like(control))
            fallback=anchor
            nearby=evidence["near"]["local-warped"]
            if (far_check is None or far_check["cross"]<=far_cutoff) and nearby["admitted"] and nearby["query"]["cross"]>new_cutoff:
                near_flag=True
                fallback=addition(tile,control,calibration,noise,seed=nearby["seed"])
            shape_trial=half_trial=anchor
        for key,delta in zip(tuple(LABELS)[1:],(anchor,fallback,shape_trial,half_trial),strict=True):
            values[key][a,k]+=delta
        marks.append({"draw":a,"role":role,"near_fallback":near_flag,"near_refit":shape_flags,
                      "half_refit":half_flags})
        if role=="present" and (near_flag or any(shape_flags) or any(half_flags)):
            chosen.append((a,"near-fallback" if near_flag else "near-refit" if any(shape_flags) else "half-refit"))
    scores={k:old.totals(a,parent,target,raw)for k,a in values.items()}
    assert scores["cross"]==data["metrics"]["cross-route"],(group,decision["i"])
    return {k:decision[k] for k in ("i","source","shape","input","parent")}|{"scores":scores,"changes":marks,"examples":chosen}


def bootstrap(rows):
    rng=np.random.default_rng(87711)
    order=rng.integers(len(rows),size=(10000,len(rows)))
    result={}
    for metric in rows[0]["scores"]["cross"]:
        table={k:np.array([r["scores"][k][metric]for r in rows])for k in LABELS}
        row={"mean":{k:float(a.mean()) for k,a in table.items()},
             "delta_vs_cross":{}}
        for label,array in table.items():
            if label in ("parent","cross"):
                continue
            delta=array-table["cross"]
            row["delta_vs_cross"][label]={"point":float(delta.mean()),"interval_95":
                np.quantile(delta[order].mean(1),(.025,.975)).tolist()}
        result[metric]=row
    return result


def main():
    start=time.monotonic()
    names=("screen","prospective-screen","recenter","half-recenter")
    sources={k:reference(ROOT/f"{k}.json") for k in names}
    screen,panel,fit,half=[read_json(checked(sources[key])) for key in names]
    detection=read_json(checked(screen["detection"]))
    known=read_json(checked(detection["sources"]["nomination"]))
    replay=read_json(checked(detection["sources"]["replication"]))
    old_rgb=reference(LAST/"delivery-fair.json")
    old_camera=read_json(checked(old_rgb))
    prospective=read_json(checked(panel["source"]))
    far_cutoff=detection["thresholds"]["active_candidate"]["cross_0"]
    controls=[p["near"]["local-warped"]["query"]["cross"]for r in screen["groups"]["initial"]for p in r["rows"]
              if not p["previous"] and p["role"] in NEGATIVES and p["near"]["local-warped"]["admitted"]]
    cutoff=max([far_cutoff,*controls])
    paths=(("initial",known["plan"],known["rows"],screen["groups"]["initial"]),
           ("independent",replay["plan"],replay["nominations"],screen["groups"]["independent"]),
           ("prospective",panel["plan"],panel["far_nominations"],panel["rows"]))
    output={}
    for label,source,nominations,local in paths:
        plan=read_json(checked(source))
        base=prospective["rows"] if label=="prospective" else old_camera["groups"][label]["rows"]
        detection_rows=prospective["detections"] if label=="prospective" else detection["rows"][label]
        args=(local,fit["groups"][label],half["groups"][label],detection_rows,nominations,base)
        records=[observe(plan,*fields,cutoff,fit["cutoff"],half["cutoff"],far_cutoff,label)
                 for fields in zip(*args,strict=True)]
        output[label]={"records":records,"summary":{geometry:bootstrap([r for r in records if r["shape"]==geometry])
                                                      for geometry in sorted({r["shape"]for r in records})}}
        print(label,len(records),[(p["i"],p["examples"])for p in records if p["examples"]],flush=True)
    write_json(ROOT/"delivery.json",{"driver":reference(__file__),"sources":sources,"previous_delivery":old_rgb,
           "checkpoint":old_camera["checkpoint"],"near_fallback_cutoff":cutoff,"near_fallback_controls":controls,
           "refit_cutoffs":{"full":fit["cutoff"],"half":half["cutoff"]},"groups":output,"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
