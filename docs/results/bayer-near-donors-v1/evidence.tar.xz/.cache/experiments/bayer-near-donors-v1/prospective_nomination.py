"""Replay near donors on the later 24-photo bent-wire panel after calibration."""
from pathlib import Path

import numpy as np

from screen import ROOT,LAST,nominate,phase,near_configuration,observe,known_geometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    trial=reference(LAST/"prospective.json")
    first=read_json(checked(trial))
    source=read_json(checked(first["plan"]))
    query=source["query_box"]
    xy=tuple(q+r for q,r in zip(query[:2],phase.ROI[:2],strict=True))
    metadata=[]
    for e in first["detections"]:
        with np.load(checked(e["input"]),allow_pickle=False)as f:
            packed,colors=f["packed"],f["colors"]
        modes=[]
        for item in e["rows"]:
            repeat,role=item["draw"],item["role"]
            k=source["roles"].index(role)
            raw,cfa=packed[repeat,k],colors[repeat,k]
            _,admitted,_=phase.geometry(raw,cfa,query,phase.ROI)
            nominee=nominate.nominal_geometry(phase.unpack(raw),cfa,xy,source["profile"])
            active=item["active_candidate"]
            assert (active is not None)==(not admitted and nominee["local-warped"]["admitted"])
            modes.append({"repeat":repeat,"role":role,"formerly":{"admitted":admitted},
                          "selected":{name:d|{"exact_distance":None}for name,d in nominee.items()}})
        metadata.append({"input":e["input"],"rows":modes})
    with near_configuration():
        scores=observe(first["detections"],source,known_geometry,metadata)
    write_json(ROOT/"prospective-screen.json",{"driver":reference(__file__),"source":trial,"plan":first["plan"],
                 "rows":scores,"far_nominations":metadata})


if __name__=="__main__":
    main()
