"""Fit an existing Bayer-supported pair in closer disjoint RAW geometry windows."""
from importlib.util import module_from_spec,spec_from_file_location
import sys
import time
from unittest.mock import patch

import numpy as np

from screen import ROOT,LAST,PREVIOUS,NEAR,FAR,nominate,phase
from geometry import windows
from evidence import old, known_geometry, cross_products
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw

spec=spec_from_file_location("near_donor_blind",nominate.EXTERIOR/"blind.py")
blind=module_from_spec(spec)
spec.loader.exec_module(blind)
NEGATIVES=("outside-only","strong-only","quiet-query")


def support(raw, green, placement, spacing, from_terms, into_terms, noise):
    samples=windows(raw,green,placement,spacing,[(x,y)for y in phase.CENTERS for x in phase.CENTERS])
    assert len(samples)==4
    scores=np.stack([phase.reserve_gain(w,from_terms,into_terms,noise)
                     for w in (samples,[p[::-1]for p in samples])])
    a=cross_products(samples,from_terms,noise)
    b=cross_products(samples,into_terms,noise)
    return {"gain_by_green":scores.tolist(),"raw_improvement":scores.min(0).tolist(),
            "cross_before":a["score"],"cross_after":b["score"]}


def measure(raw,tile,layout,origin,local_origin,spacing,prior,noise):
    with patch.object(blind,"CARDINAL",NEAR),patch.object(blind,"DIAGONAL",()):
        shape,passes=blind.measure(raw,layout,origin,spacing,noise)
    with patch.object(blind,"CARDINAL",FAR),patch.object(blind,"DIAGONAL",()):
        wide,far=blind.measure(raw,layout,origin,spacing,noise)
    previous=old.bends.check_query(tile,layout,spacing,(*local_origin,160,160),wide,noise)[0]
    if prior is not None:
        np.testing.assert_allclose(previous,prior,rtol=0,atol=2e-14)
        previous=prior
    assert tile.shape == (4,128,128)
    nearby=shape
    score=support(phase.unpack(tile),layout,local_origin,spacing,previous,nearby,noise)
    flag=passes["verification"]["accepted"]
    # Check only the directions for which the donors accepted a new geometry.
    evaluated=[float(v) if a else None for a,v in zip(flag,score["raw_improvement"],strict=True)]
    return {"spacing":spacing.tolist(),"prior":previous.tolist(),"near":nearby.tolist(),
            "near_check":passes,"far_check":far,"score":score,"near_vs_prior":evaluated}


def simulation(rows,plan,previous_nominations):
    output=[]
    x,y,w,h=plan["query_box"]
    cx,cy=phase.ROI[:2]
    origin=(x+cx,y+cy)
    crop=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    for row in rows:
        i=row["i"]
        if previous_nominations:
            assert row["input"]==previous_nominations[i]["input"]
        source=plan["sources"][i]
        truth,shape=known_geometry(source["layout"])
        sorter=np.argsort(-truth[:,1])
        truth,shape=truth[sorter],shape[sorter]
        valid_truth=np.prod(truth[:,1])<0
        trials=[]
        with np.load(checked(row["input"]),allow_pickle=False) as f:
            raw,colors=f["packed"],f["colors"]
        for a in range(plan["repeat_count"]):
            for k,role in enumerate(plan["roles"]):
                values,layout=raw[a,k],colors[a,k]
                mosaic=phase.unpack(values)
                spacing,eligible,proof=phase.geometry(values,layout,plan["query_box"],phase.ROI)
                if previous_nominations:
                    last=previous_nominations[i]["rows"][len(trials)]
                    assert (a,role)==(last["draw"],last["role"]) and eligible==last["nomination"]["admitted"]
                    assert last["nomination"]["frequencies_xy"]==spacing.tolist()
                    prior=np.asarray(last["accepted_terms"]["joint-checked"])
                else:
                    prior=None
                candidate=measure(mosaic,values[crop],layout,origin,(cx,cy),spacing,prior,plan["profile"]) if eligible else None
                if candidate and valid_truth:
                    parameters=shape.copy()
                    parameters[:,:2]=(truth-spacing)*64
                    candidate["exact"]=parameters.tolist()
                trials.append({"draw":a,"role":role,"eligible":eligible,"candidate":candidate})
        output.append({k:row[k] for k in ("i","shape","source","input","parent")}|{"rows":trials})
    return output


def camera(previous):
    output=[]
    working={"raw":None,"image":None,"layout":None}
    nearby=read_json(ROOT/"screen.json")
    scene=ROOT.with_name("scene-full-epoch-v1")
    book=read_json(scene/"review-native-020000/work/render/result.json")
    observations={r["id"]:r for r in read_json(checked(book["plan"]))["observations"]}
    manifests={r["id"]:r for r in book["boards"]}
    mesh_origin=read_json("configs/gfx-green-mesh-20231231.json")["raw_context_xywh"][:2]
    for row in nearby["real"]:
        proof=row["binding"]
        with np.load(checked(proof["input"]),allow_pickle=False) as data:
            assert "packed" in data.files
            observation=observations[manifests[row["id"]]["observation"]]
            assert observation["arrays"]==proof["input"]
            origin=mesh_origin if row["id"].startswith("mesh-") else observation["metadata"]["context_xywh"][:2]
            dx,dy=[a-b for a,b in zip(proof["native_box"][:2],origin,strict=True)]
            assert dx%2==dy%2==0
            packed=data["packed"][0,:,dy//2:dy//2+128,dx//2:dx//2+128]
            cfa=data["colors"].reshape(-1,4)[0]
        if proof["raw"]!=working["raw"]:
            image,meta=read_raw(checked(proof["raw"]))
            working={"raw":proof["raw"],"image":image,"layout":color_indices(meta.pattern).numpy()}
        x,y,w,h=proof["native_box"]
        xx,yy=proof["roi"][:2]
        np.testing.assert_array_equal(cfa,working["layout"])
        np.testing.assert_array_equal(phase.unpack(packed),working["image"][y:y+h,x:x+w])
        lookup=next(p for p in previous if p["raw"]==proof["raw"] and list(p["box"][:2])==[x+xx,y+yy])
        gate=lookup["original_admission"]
        choice=None
        if gate:
            origin=(x+xx,y+yy)
            spacing=np.asarray(row["original_pair"])
            expected=np.asarray(lookup["profiles"][row["profile"]]["parameters"])
            previous_term=old.bends.check_query(packed,cfa,spacing,proof["roi"],expected,proof["noise"])[0]
            choice=measure(working["image"],packed,cfa,origin,(xx,yy),spacing,previous_term,proof["noise"])
        output.append({"id":row["id"],"binding":proof,"candidate":choice,"original_admission":gate})
        print(row["id"],choice["near_vs_prior"] if choice else None, flush=True)
    return output


def main():
    start=time.monotonic()
    screen=reference(ROOT/"screen.json")
    evidence=read_json(checked(read_json(checked(screen))["detection"]))
    original=read_json(checked(evidence["sources"]["nomination"]))
    saved=read_json(checked(original["previous"]))
    independent=read_json(checked(evidence["sources"]["replication"]))
    prospects=read_json(LAST/"prospective.json")
    src=(("initial",original["plan"],saved["rows"],evidence["rows"]["initial"]),
         ("independent",independent["plan"],independent["baseline"],evidence["rows"]["independent"]),
         ("prospective",prospects["plan"],None,prospects["detections"]))
    groups={}
    for name,plan,prior,inputs in src:
        groups[name]=simulation(inputs,read_json(checked(plan)),prior)
        print(name,len(groups[name]),flush=True)
    controls=[v for row in groups["initial"] for d in row["rows"]
              if d["role"] in NEGATIVES and d["candidate"] is not None
              for v in d["candidate"]["near_vs_prior"] if v is not None]
    cutoff=max([phase.MIN_GAIN,*controls])
    views=camera(saved["camera"])
    write_json(ROOT/"recenter.json",{"driver":reference(__file__),"screen":screen,
        "groups":groups,"real":views,"cutoff":cutoff,"control_measurements":controls,
        "checkpoint":independent["checkpoint"],"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
