"""Bind native crops, calibration and actual restored outputs to the near-donor replay."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

from PIL import Image, ImageChops

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
LAST=ROOT.with_name("bayer-cross-evidence-v1")
PRIOR=ROOT.with_name("bayer-warped-spacing-v1")
OLD=Path("docs/images")/PRIOR.name
IMAGES=Path("docs/images")/ROOT.name
RESULTS=Path("docs/results")/ROOT.name


def panels(file,spec):
    data={}
    with Image.open(file) as image:
        for rec in spec["panels"]:
            x,y,w,h=rec["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            data[rec.get("label") or rec["name"]]=image.crop((x,y,x+w,y+h))
    assert len(data)==len(spec["panels"])
    return data


def copies(spec,group):
    origin=checked(spec["image"])
    dest=IMAGES/group/origin.name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(origin,dest)
    assert reference(dest)["sha256"]==spec["image"]["sha256"]
    spec["image"]["path"]=dest.relative_to(IMAGES).as_posix()
    return panels(dest,spec)


def same(a,b):
    return ImageChops.difference(a,b).getbbox() is None


def frame_audit(data):
    earlier=reference(OLD/"manifest.json")
    former={r["id"]:r for r in read_json(checked(earlier))["standing"]["rows"]}
    changed=[]
    for row in data["rows"]:
        old=former[row["id"]]
        for field in ("raw","noise","roi","native_box","input","parent","display_exposure"):
            assert old[field]==row[field]
        former_image=OLD/old["board"]["image"]["path"]
        assert reference(former_image)["sha256"]==old["board"]["image"]["sha256"]
        old_cells=panels(former_image,old["board"])
        cells=copies(row["board"],"standing")
        for label in old_cells.keys() & cells.keys():
            assert same(cells[label],old_cells[label]),(row["id"],label)
        delta={name:ImageChops.difference(cells["Prior joint crop check"],cells[name]).getextrema()
               for name in ("Near refit","Near half-step refit")}
        row["native_max_srgb8_delta"]={name:max(extreme[1] for extreme in values) for name,values in delta.items()}
        if any(row["native_max_srgb8_delta"].values()):
            changed.append(row["id"])
    assert changed==["main-chain-link-fence-main-chain-link-fence"]
    return earlier,changed


def thresholds(screen,prospective,delivery):
    variants={**screen["groups"],"prospective":prospective["rows"]}
    lower=max(delivery["near_fallback_controls"])
    result={}
    for label,rows in variants.items():
        result[label]=[]
        for row in rows:
            for case in row["rows"]:
                n=case["near"]["local-warped"]
                if not case["previous"] and n["admitted"] and lower<n["query"]["cross"]<=delivery["near_fallback_cutoff"]:
                    result[label].append({"source":row["source"],"i":row["i"],
                      "draw":case["draw"],"role":case["role"],"score":n["query"]["cross"]})
    assert [c["role"]for c in result["prospective"]]==["outside-only","present"]
    return {"near_only_development_max":lower,"additional_attempts":result}


def main():
    RESULTS.mkdir(exist_ok=True)
    IMAGES.mkdir(exist_ok=True)
    keys=("screen","prospective-screen","recenter","half-recenter","delivery","native")
    refs={k:reference(ROOT/f"{k}.json") for k in keys}
    refs["standing"]=reference(ROOT/"standing/manifest.json")
    data={k:read_json(checked(v))for k,v in refs.items()}
    delivery=data["delivery"]
    assert data["native"]["source"]==refs["delivery"]
    folds={k:v["records"] for k,v in delivery["groups"].items()}
    ids=[row["source"] for rows in folds.values() for row in rows]
    assert len(ids)==len(set(ids))==60
    assert all(not row["near_fallback"] for subject in folds.values() for record in subject
               for row in record["changes"] if row["role"]!="present")
    links,changed=frame_audit(data["standing"])
    for board in data["native"]["boards"]:
        full=copies(board["board"],"independent")
        triplet=copies(board["triplet"],"independent")
        assert set(triplet)=={"Noisy Malvar","Near fallback, Bayer check","Exact GT"}
        assert all(same(full[k],v) for k,v in triplet.items())
    assert len(data["native"]["boards"])==2
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"checkpoint":delivery["checkpoint"],"standing":data["standing"],
           "previous_standing":links,"exact":data["native"]["boards"],
           "native_review_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
           "observation":"Both native triplets and all eight standing comparisons were viewed. A slight coarse-phase change is visible. Fine cab intersections stay incomplete."},replace=True)
    files = [checked(v)for v in refs.values()]
    files += [ROOT/n for n in ("screen.py","recenter.py","half_recenter.py","delivery.py","native.py","standing.py",
         "prospective_nomination.py","publish.py","screen.log","recenter.log","half-recenter.log","delivery.log",
         "prospective-screen.log","native.log","standing.log","preflight.log","subpixel-preflight.log","native-preflight.log")]
    files += [LAST/n for n in ("evidence.py","detection.json","delivery-fair.json","prospective.json")]
    files += [PRIOR/n for n in ("nominate.py","delivery.py","standing.py")]
    folder=ROOT.with_name("bayer-exterior-bend-v1")
    files += [folder/n for n in ("blind.py","geometry.py","delivery.py")]
    paths={str(f.resolve().relative_to(Path.cwd())):f for f in files}
    archive=RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"w:xz",preset=4) as out:
        for name,path in sorted(paths.items()):
            out.add(path,arcname=name,recursive=False)
    with tarfile.open(archive) as out:
        for name,path in paths.items():
            with out.extractfile(name) as s:
                assert hashlib.file_digest(s,"sha256").hexdigest()==reference(path)["sha256"]
    write_json(RESULTS/"publication.json",{"checkpoint":delivery["checkpoint"],"sources":refs,
       "archive":reference(archive),"manifest":reference(manifest),"changed_standing":changed,
       "effects":{k:g["summary"]for k,g in delivery["groups"].items()},
       "cutoffs":{"fallback":delivery["near_fallback_cutoff"],**delivery["refit_cutoffs"]},
       "lower_cutoff_sensitivity":thresholds(data["screen"],data["prospective-screen"],delivery),
       "scope":"Same frozen synthetic and standing compositions. 20 calibrating, 16 independent replay and 24 later bent photo fields. Actual rendered synthetic triplets and standing native crops inspected."},replace=True)
    print("Verified",len(ids),"sources,",len(former:=data["standing"]["rows"]),"standing views and the two native triplets")


if __name__=="__main__":
    main()
