"""Compare the checked close refits against the exact archived standing fit."""
from functools import partial
from importlib.util import module_from_spec,spec_from_file_location
from unittest.mock import patch

import numpy as np

import delivery as study
from screen import ROOT,PREVIOUS,phase
from demosaic.experiments.artifacts import checked,read_json,reference

spec=spec_from_file_location("near_comparison_standing",PREVIOUS/"standing.py")
previous=module_from_spec(spec)
spec.loader.exec_module(previous)
CAPTIONS={k:v for k,v in previous.CAPTIONS.items() if k in ("Bayer-gated","distant","fixed","previous")}
CAPTIONS.update({"near-refit":"Near refit","half-refit":"Near half-step refit"})


def render(raw,cfa,wb,matrix,noise,box,surround,parent,policy,roi=None):
    legacy,variants=policy
    result=previous.render(raw,cfa,wb,matrix,noise,box,surround,parent,legacy,roi)
    roi=phase.ROI if roi is None else tuple(roi)
    key=(box[0]+roi[0],box[1]+roi[1])
    profile="nominal" if abs(noise["shot"]-.00128)<1e-12 else "transferred"
    changed={}
    for name,record,cutoff in variants:
        row=record[(key,profile)]
        assert row["binding"]["native_box"]==list(box) and row["binding"]["roi"]==list(roi)
        if row["candidate"] is None:
            changed[name]=result["previous"]
            continue
        candidate=row["candidate"]
        terms,flags=study.checked_terms(candidate,cutoff)
        kwargs={"spacing":candidate["spacing"],"roi":roi}
        def restore(terms):
            delta=study.addition(raw,result["distant"],(cfa,wb,matrix),noise,terms=terms,**kwargs)
            return result["distant"]+delta
        np.testing.assert_array_equal(restore(candidate["prior"]),result["previous"])
        changed[name]=restore(terms) if any(flags) else result["previous"]
        weighted=np.sqrt(np.mean((changed[name].astype(np.float64)-result["previous"])**2))*65535
        print(key,profile,name,flags,float(weighted),flush=True)
    return {k:(changed|result)[k] for k in CAPTIONS}


def main():
    learned,receipt=previous.preceding.setup()
    shown=reference(PREVIOUS/"nomination.json")
    old=read_json(checked(shown))
    geometry=read_json(checked(old["previous"]))
    legacy=(learned,{tuple(r["box"]):r for r in geometry["camera"]},
            {tuple(r["box"]):r for r in old["camera"]})
    variants=[]
    dependencies={}
    for name,file in (("near-refit","recenter"),("half-refit","half-recenter")):
        dependencies[name]=reference(ROOT/f"{file}.json")
        latest=read_json(checked(dependencies[name]))
        table={}
        for row in latest["real"]:
            bind=row["binding"]
            origin=tuple(bind["native_box"][i]+bind["roi"][i] for i in (0,1))
            condition="transferred" if "profile3879" in row["id"] else "nominal"
            table[(origin,condition)]=row
        assert len(table)==8
        variants.append((name,table,latest["cutoff"]))
    with patch.object(previous.preceding,"ROOT",ROOT),patch.object(previous.preceding,"CAPTIONS",CAPTIONS),patch.object(previous.preceding,"render_models",render):
        previous.preceding.standing((legacy,variants),
            receipt|{"driver":reference(__file__),"disjoint_geometry":dependencies,
                     "old_nominations":shown,"old_shape":old["previous"]},None)


if __name__=="__main__":
    main()
