"""Render both newly admitted independent bent observations at native scale."""
from pathlib import Path
import json
from unittest.mock import patch

import numpy as np

import delivery as study
from screen import ROOT, LAST
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    source=reference(ROOT/"delivery.json")
    result=read_json(checked(source))
    screen,fit,half=[read_json(checked(result["sources"][key]))
                    for key in ("screen","recenter","half-recenter")]
    evidence=read_json(checked(screen["detection"]))
    replay=read_json(checked(evidence["sources"]["replication"]))
    prior=read_json(checked(result["previous_delivery"]))
    plan=read_json(checked(replay["plan"]))
    archive=ROOT/"independent-native"
    archive.mkdir(exist_ok=True)
    rendered=[]
    for item in result["groups"]["independent"]["records"]:
        chosen=[n for n,method in item["examples"] if method=="near-fallback" and item["shape"]=="bent"]
        if not chosen:
            continue
        i=item["i"]
        recorded=[]
        metric=study.old.totals
        def store(image,*args):
            recorded.append(image.copy())
            return metric(image,*args)
        label="independent"
        rows=(screen["groups"][label],fit["groups"][label],half["groups"][label],
              evidence["rows"][label],replay["nominations"],prior["groups"][label]["rows"])
        args=[r[i] for r in rows]
        with patch.object(study.old,"totals",store):
            recovered=study.observe(plan,*args,result["near_fallback_cutoff"],result["refit_cutoffs"]["full"],
                result["refit_cutoffs"]["half"],evidence["thresholds"]["active_candidate"]["cross_0"],label)
        assert json.loads(json.dumps(recovered))==item and len(recorded)==len(study.LABELS)
        with np.load(checked(item["input"]),allow_pickle=False)as f:
            raw={k:f[k]for k in f.files}
        x,y,w,h=plan["query_box"]
        packed=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
        truth=raw["target"][...,y:y+h,x:x+w]
        scene=plan["sources"][i]
        for draw in chosen:
            data={k:raw[k][draw,:1]for k in ("wb","matrix","colors")}|{"packed":packed[draw,:1]}
            columns=[noisy_malvar(data)[0],*(z[draw,0]for z in recorded),truth[draw,0]]
            labels=("Noisy Malvar",*study.LABELS.values(),"Exact GT")
            board=study.old.native_board(archive,f"case-{i:03d}-draw{draw}",columns,data,
                   {"source":scene["source"],"source_box":scene["box"],"CFA":scene["camera"]["pattern"],
                    "checkpoint":result["checkpoint"],"input":item["input"],"parent":item["parent"],
                    "query":plan["query_box"],"noise":plan["profile"],"role":"present","draw":draw},
                   labels=labels,exposure=2,contrast=1,
                   triplet_indices=(0,labels.index(study.LABELS["near-fallback"]),len(labels)-1))
            rendered.append(board)
    assert len(rendered)==2
    write_json(ROOT/"native.json",{"driver":reference(__file__),"source":source,"boards":rendered})


if __name__=="__main__":
    main()
