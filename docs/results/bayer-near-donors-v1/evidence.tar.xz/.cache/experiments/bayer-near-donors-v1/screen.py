"""Test whether disjoint donors closer to the delivered crop recover missed frequencies."""
from contextlib import contextmanager
from pathlib import Path
import sys
import time
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parent
LAST = ROOT.with_name("bayer-cross-evidence-v1")
sys.path.insert(0,str(LAST))
from evidence import PREVIOUS, known_geometry, phase, verify, cross_products
import nominate
from geometry import windows
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

OFFSETS = (-64,48,160)
NEAR = tuple((x,y) for y in OFFSETS for x in OFFSETS if (x,y)!=(48,48))
FAR = nominate.ORIGINS
assert len(NEAR)==8 and all(x+64<=0 or y+64<=0 or min(x,y)==160 or x==160 or y==160
                            for x,y in NEAR)
NEGATIVES = ("outside-only","strong-only","quiet-query")


@contextmanager
def near_configuration():
    # Cache only within the one node that uses the alternative registered positions.
    nominate.positions.cache_clear()
    try:
        with patch.object(nominate,"ORIGINS",NEAR):
            yield
    finally:
        nominate.positions.cache_clear()


def axes(raw,cfa,xy,noise,proposals):
    records = {}
    for k in ("local-flat","local-warped"):
        item = proposals[k]
        seed=np.asarray(item["seed"])
        shape=nominate.tangent_terms(seed)
        terms=windows(raw,cfa,xy,seed[:,:2],NEAR)
        support = cross_products(terms,shape,noise)["score"]
        records[k] = item | {"support":support}
    return records


def observe(data,plan,known,metadata):
    x,y,w,h = plan["query_box"]
    op=(x+phase.ROI[0],y+phase.ROI[1])
    offsets=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    stencils=[]
    for entry in data:
        i=entry["i"]
        pan = metadata[i]
        assert entry["input"]==pan["input"]
        expected,exact_shape=known_geometry(plan["sources"][i]["layout"])
        rank=np.argsort(-expected[:,1])
        expected,exact_shape=expected[rank],exact_shape[rank]
        separated = bool(np.prod(expected[:,1])<0)
        with np.load(checked(entry["input"]),allow_pickle=False) as f:
            packed,colors=f["packed"],f["colors"]
        local=[]
        for j,rows in enumerate(zip(entry["rows"],pan["rows"],strict=True)):
            a,b=rows
            repeat,role=a["draw"],a["role"]
            assert (repeat,role)==(b["repeat"],b["role"])
            idx=plan["roles"].index(role)
            values=phase.unpack(packed[repeat,idx])
            layout=colors[repeat,idx]
            near=nominate.nominal_geometry(values,layout,op,plan["profile"])
            result=axes(values,layout,op,plan["profile"],near)
            for method in result:
                seed=np.asarray(result[method]["seed"])
                crop=verify(packed[repeat,idx][offsets],layout,phase.ROI,seed[:,:2],nominate.tangent_terms(seed),plan["profile"])
                result[method].update(query={k:crop[k] for k in ("cross","held","old_accept","by_family")},
                                      distance=np.linalg.norm(seed[:,:2]-expected,axis=1).tolist() if separated else None)
            local.append({"draw":repeat,"role":role,"previous":b["formerly"]["admitted"],
                          "far":{name:{"admitted":item["admitted"],"distance":item["exact_distance"]}
                                 for name,item in b["selected"].items()},"near":result})
        stencils.append({k:entry[k] for k in ("i","source","input","parent","shape")} | {"rows":local})
        if (i+1)%4==0:
            print("scored",i+1,flush=True)
    return stencils


def camera(before):
    from collections import defaultdict
    manifest=read_json("docs/images/bayer-warped-spacing-v1/manifest.json")["standing"]
    lookup=defaultdict(list)
    for row in before:
        lookup[row["raw"]["path"]].append(row)
    outputs=[]
    for key,cases in lookup.items():
        raw,meta=read_raw(checked(cases[0]["raw"]))
        cfa=np.array(color_indices(meta.pattern))
        for item in cases:
            xy=tuple(item["box"][:2])
            for condition in item["profiles"]:
                name=next(x["id"] for x in manifest["rows"] if
                          x["raw"]==item["raw"] and x["id"].endswith("-"+item["region"])
                          and ("mesh-profile3879" in x["id"])==(condition=="transferred"))
                bound=next(x for x in manifest["rows"] if x["id"]==name)
                # Retain full-sensor Bayer phase, including the odd cab ROI offset.
                x,y,w,h=bound["native_box"]
                q=raw[y:y+h,x:x+w]
                packed=np.stack([q[dy::2,dx::2] for dy in (0,1) for dx in (0,1)])
                layout=np.roll(np.roll(cfa.reshape(2,2),-(y%2),axis=0),-(x%2),axis=1).reshape(-1)
                noise=bound["noise"]
                assert tuple(bound["native_box"][k]+bound["roi"][k] for k in range(2))==xy
                near=axes(raw,cfa,xy,noise,nominate.nominal_geometry(raw,cfa,xy,noise))
                for value in near.values():
                    seed=np.asarray(value["seed"])
                    crop=verify(packed,layout,bound["roi"],seed[:,:2],nominate.tangent_terms(seed),noise)
                    value["query"]={k:crop[k] for k in ("cross","held","old_accept","by_family")}
                inherited=np.asarray(item["frequencies_xy"])
                samples=windows(raw,cfa,xy,inherited,NEAR)
                near_original=cross_products(samples,np.zeros((2,5)),noise)
                far_original=cross_products(windows(raw,cfa,xy,inherited,FAR),np.zeros((2,5)),noise)
                outputs.append({"id":name,"binding":bound,"profile":condition,"near":near,
                                "far":item["profiles"][condition],"original_pair":inherited.tolist(),
                                "original_pair_near_agreement":near_original,"original_pair_far_agreement":far_original})
                print(name,[x["admitted"] for x in near.values()],
                      near_original["score"],far_original["score"],flush=True)
    assert len(outputs)==8
    return outputs


def main():
    t0=time.monotonic()
    detection_ref=reference(LAST/"detection.json")
    prior=read_json(checked(detection_ref))
    sources={k:read_json(checked(v)) for k,v in prior["sources"].items()}
    cases=(("initial",sources["nomination"]["plan"],sources["nomination"]["rows"]),
           ("independent",sources["replication"]["plan"],sources["replication"]["nominations"]))
    args={}
    with near_configuration():
        for label,src,meta in cases:
            args[label]=observe(prior["rows"][label],read_json(checked(src)),known_geometry,meta)
        real=camera(sources["nomination"]["camera"])
    write_json(ROOT/"screen.json",{"driver":reference(__file__),"checkpoint":sources["delivery"]["checkpoint"],
               "detection":detection_ref,"groups":args,"real":real,"near_origins_xy":NEAR,"far_origins_xy":FAR,
               "seconds":time.monotonic()-t0})


if __name__=="__main__":
    main()
