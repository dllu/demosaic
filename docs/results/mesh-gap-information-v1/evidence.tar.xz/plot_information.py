"""Show the source of audited high-noise evidence for the known-gap diagnostic."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
source=reference(ROOT/"information.json")
rows=[r for r in read_json(checked(source))["cases"] if r["entered"] and r["id"].startswith("iso6400")]
labels=[row["id"].replace("iso6400-","").replace("-g","\ng") for row in rows]
location=np.arange(len(labels))
fig,axes=plt.subplots(1,2,figsize=(9.3,3.9),layout="constrained")

scores=lambda key:[row[key]for row in rows]
axes[0].bar(location-.18,scores("nominal_footprint_z"),.34,label="Measured wire template",color="#2A6F9E")
axes[0].bar(location+.18,scores("true_template_existing_projection"),.34,label="Exact wire template",color="#77A347")
axes[0].axhline(3.25,color="#693E66",lw=1,ls="--",label="Signed cutoff 3.25")
axes[0].set_title("Same foreground and continuing-wire projection")
direction=[row["expected_projection"]["background_and_rear"]["true_signal_along_estimated_direction"] for row in rows]
axes[1].bar(location-.24,direction,.22,label="True gap signal",color="#2A6F9E")
axes[1].bar(location,scores("continuous_null_model_bias_Z"),.22,label="Continuing model bias",color="#DC8854")
axes[1].bar(location+.24,scores("noise_residual_Z"),.22,label="Noise on this draw",color="#7C67A7")
axes[1].set_title("Contributions with the measured template")
for axis in axes:
    axis.set_ylabel("Signed overlap Z")
    axis.set_xticks(location,labels,fontsize=8)
    axis.axhline(0,color="#767676",lw=.6)
    axis.spines[["top","right"]].set_visible(False)
    axis.legend(fontsize=8,frameon=False,loc="upper left")
axes[0].set_ylim(0,9.8)
axes[1].set_ylim(-2,9.8)
fig.suptitle("ISO6400 Bayer audit with exact gap geometry",fontsize=13,weight="bold")
path=ROOT/"gap-information.png"
fig.savefig(path,dpi=155)
write_json(ROOT/"information-figure.json",{"image":reference(path),"source":reference(__file__),"data":source,
    "role":"Synthetic diagnostic using hidden support. The five cases shown had measured carriers and entered the audit."})
