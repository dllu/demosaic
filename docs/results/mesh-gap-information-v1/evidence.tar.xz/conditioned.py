"""Separate smooth carrier contrast and curved foregrounds from missing wire."""

import math

import numpy as np

from demosaic.isolated_line import coordinates
from averaged_footprints import proposal_bank
from edge import forecasts, step_profile
from optimized_footprints import ReservedFit, fields, nominations
from pooled_gap_audit_20261118 import SIGNED_OVERLAP, admitted, fitted_terms, read_score, sound_template

MODES = ("standard", "affine", "curved", "joint", "joint-audit-only")


def curved_position(x, y, shape):
    theta, offset, width, sag = shape
    u, v = math.cos(theta), math.sin(theta)
    tangent = (-v*x+u*y)/128.
    normal = u*x+v*y-offset-sag*tangent**2
    return np.tanh(normal/width), tangent


def refine_edge(data, reserve, front, seed):
    # Choose geometry from fixed, phase-stratified foreground observations.
    x,y=(axis[reserve] for axis in data.positions)
    p=front.ravel()[reserve]
    color=data.colors[reserve]
    values=data.raw[reserve]
    anchor=np.column_stack((data.nuisance, data.wave))[reserve]
    models=[]
    for c in range(3):
        selected=color==c
        Q=np.linalg.qr(anchor[selected],mode="reduced")[0]
        y_color=values[selected]
        variance=data.shot*max(1e-4,np.median(y_color))+data.read
        models.append((selected,Q,y_color-Q@(Q.T@y_color),variance))

    def evidence(shape):
        step,_=curved_position(x,y,shape)
        term=np.column_stack((step,step*p))
        value=0.
        for selected,Q,r,v in models:
            spatial=term[selected]
            u=spatial-Q@(Q.T@spatial)
            co=np.linalg.lstsq(u,r,rcond=None)[0]
            predicted=u@co
            value+=float(predicted@predicted)/v
        return value

    start=np.array((*seed,0.))
    scales=np.array([np.deg2rad(4.),5.,1.75,8.])
    lower=start-np.array([np.deg2rad(12.),14.,8.,20.])
    upper=start+np.array([np.deg2rad(12.),14.,8.,20.])
    lower[2],upper[2]=1.4,12.
    best=start
    rank=evidence(best)
    initial=rank
    for granularity in (1.,.5,.25):
        for _ in range(2):
            for coordinate in np.eye(4):
                trial=[np.clip(best+sign*scales*coordinate*granularity,lower,upper) for sign in (1,-1)]
                scores=[evidence(shape) for shape in trial]
                hit=int(np.argmax(scores))
                if scores[hit]>rank+1e-8:
                    best=trial[hit]
                    rank=scores[hit]
    return best.tolist(),[initial,rank]


def affine_basis(data, step=None, tangent=None):
    x,y=(v/128. for v in data.positions)
    wave=data.wave
    terms=[wave,wave*x,wave*y]
    if step is not None:
        terms.extend([wave*step,wave*step*tangent])
    return np.column_stack(terms)


def nomination(data,design,rear,reserve,theta,native):
    bank=proposal_bank(theta)
    fit=ReservedFit(data,design,rear,reserve)
    _,bank,ranking,sizes,path=nominations(fit,bank)
    raw,canvas,trace=fields(bank,ranking,sizes,data.positions,native)["mean"]
    return raw,canvas,{"shape":trace,"refinement":path}


def audit(raw,cfa,p,q,noise,query,roi,guess):
    data,reserve,splits,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    a,b,d=splits
    seed=edge.get("shape")
    keep=seed is None or admitted(forecasts(data,bg,rear,((a,b),(b,a),(a|b,d))),.5,(1.75,)*3)
    if seed is None:
        theta=guess
        old_affine=affine_basis(data)
        warped,warped_affine,warped_bg=rear,old_affine,bg
        contour=None
        offset_scores=None
    else:
        x,y=data.positions
        theta=seed[0]
        step,tangent=curved_position(x,y,(*seed,0.))
        old_affine=affine_basis(data,step,tangent)
        contour,offset_scores=refine_edge(data,reserve,p,seed)
        new_step,new_tangent=curved_position(x,y,contour)
        warped=np.column_stack((data.wave,data.wave*new_step))
        warped_affine=affine_basis(data,new_step,new_tangent)
        warped_bg=np.column_stack((data.nuisance,new_step,p.ravel()*new_step))
    native=coordinates(roi[3],roi[2],origin=(roi[0]-query[0]-127.5,roi[1]-query[1]-127.5))
    variants=(("standard",bg,rear,theta),("affine",bg,old_affine,theta),
              ("curved",warped_bg,warped,contour[0] if contour else theta),
              ("joint",warped_bg,warped_affine,contour[0] if contour else theta),
              ("joint-audit-only",warped_bg,warped_affine,theta))
    crops,policies,previous={}, {}, {}
    for name,background,model,angle in variants:
        design=np.column_stack((background,model))
        if name=="joint-audit-only":
            raw_cut,canvas,trace=previous["standard"]
        elif not contour and name=="curved":
            raw_cut,canvas,trace=previous["standard"]
        elif not contour and name=="joint":
            raw_cut,canvas,trace=previous["affine"]
        else:
            raw_cut,canvas,trace=nomination(data,design,model,reserve,angle,native)
        previous[name]=(raw_cut,canvas,trace)
        delta,sigma,_=sound_template(data,design,model,reserve,raw_cut)
        audit_score=read_score(data.raw,data.colors,design,delta,sigma,~reserve)
        accepted=bool(keep and audit_score["z"]>SIGNED_OVERLAP and audit_score["half_displacement_gain"]>0)
        out=.5*canvas if accepted else np.zeros_like(canvas)
        policies[name]={"accepted":accepted,"holdout":audit_score,"nomination":trace,
                        "max_cut":float(out.max())}
        crops[name]=out
    return crops,{"edge":edge,"curved_edge":contour,"curved_fit_gain":offset_scores,
                  "global_keep":keep,"policies":policies}
