"""Locate the loss between available gap information and the measured RAW score."""

import math
import os
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "mesh-refined-footprint-v1"
sys.path.insert(0, str(PREVIOUS))
from panel import CENTRE, Carrier, observe, ribbon, window
from pooled_gap_audit_20261118 import fitted_terms, project, read_score, sound_template


def bayer(field):
    return np.stack([field[j::2,i::2] for j,i in ((0,0),(0,1),(1,0),(1,1))])


def vector_terms(fields, basis, color, select, variances):
    samples=[]
    for i in range(3):
        at = select & (color==i)
        Q = np.linalg.qr(basis[at], mode="reduced")[0]
        subset=fields[at]
        samples.append((subset-Q@(Q.T@subset))/np.sqrt(variances[i]))
    return np.concatenate(samples)


def diagnostic(case, plan):
    row = read_json(checked(case["source"]))
    role = row["proof"]["matching"]["roles"][1]
    if "central_pair" not in role:
        return {"id":case["id"],"entered":False,"source":case["source"]}
    noise = plan["noise"][row["entry"]["profile"]]
    altered_entry=dict(row["entry"],layout="step")
    with np.load(checked(row["arrays"]), allow_pickle=False) as saved:
        fits=saved["packed"]
        raw=window(fits[1],CENTRE,phase=2)
        cfa=saved["colors"][1]
        gt=saved["target"]
        cut_bayer=bayer(window(1-saved["support"],CENTRE))
    clean=observe(altered_entry,noise)[0]["target"].numpy()
    np.testing.assert_array_equal(gt[0],clean[0])
    def samples(a):
        return mosaic(torch.from_numpy(np.ascontiguousarray(window(a,CENTRE)))[None],torch.from_numpy(cfa))[0].numpy()
    without_gap=samples(clean[1])
    with_gap=samples(gt[1])
    rear_exact=samples(clean[1] - clean[0])
    expected_change=with_gap-without_gap
    np.testing.assert_allclose(-cut_bayer*rear_exact,expected_change,atol=6e-8,rtol=0.)
    coordinates=native_sites(raw.shape[-2:],(-127.5,-127.5))
    for a in range(len(coordinates)):
        indexes=(coordinates[a]+127.5).astype(int)
        assert indexes.min()==0 and indexes.max()==255
    calculated=bayer(window(1-read_mask(row),CENTRE))
    np.testing.assert_array_equal(calculated,cut_bayer)
    p,q=(ribbon(*coordinates,Carrier(**params)) for params in role["central_pair"])
    data,reserve,splits,bg,rear,edge=fitted_terms(raw,cfa,p,q,noise)
    cut=cut_bayer.ravel()
    U=np.column_stack((bg,rear))
    delta,variance,coefficient=sound_template(data,U,rear,reserve,cut)
    no_bg=np.ones((len(delta),1))
    true_delta=expected_change.ravel().astype(float)
    constant_null=without_gap.ravel().astype(float)
    fields=np.column_stack((delta,true_delta,data.raw-constant_null))
    terms={}
    for label,basis in (("background",bg),("background_and_rear",U)):
        col=vector_terms(fields,basis,data.colors,~reserve,variance)
        estimated,true,measured=col.T
        m_n=np.linalg.norm(estimated)
        e_n=np.linalg.norm(true)
        terms[label]={"estimated_template_norm":float(m_n),"exact_template_norm":float(e_n),
                      "true_signal_along_estimated_direction":float((estimated@true)/max(1e-20,m_n)),
                      "template_cosine":float((estimated@true)/max(1e-20,m_n*e_n)),
                      "true_null_subtracted_measured_z":float((estimated@measured)/max(1e-20,m_n))}
    return {"id":case["id"],"source":case["source"],"entered":True,
            "nominal_footprint_z":read_score(data.raw,data.colors,U,delta,variance,~reserve)["z"],
            "true_template_existing_projection":read_score(data.raw,data.colors,U,true_delta,variance,~reserve)["z"],
            "expected_projection":terms,
            "continuous_null_model_bias_Z":read_score(constant_null,data.colors,U,delta,variance,~reserve)["z"],
            "noise_residual_Z":read_score(data.raw-with_gap.ravel(),data.colors,U,delta,variance,~reserve)["z"]}


def read_mask(row):
    with np.load(checked(row["arrays"]),allow_pickle=False) as vals:
        return vals["support"]


if __name__ == "__main__":
    os.sched_setaffinity(0,[14]); os.nice(12); torch.set_num_threads(1)
    summary_ref=reference(PREVIOUS/"summary.json")
    summary=read_json(checked(summary_ref))
    plan=read_json(checked(summary["plan"]))
    rows=[diagnostic(case,plan) for case in summary["cases"] if case["entry"]["kind"]=="gaps"]
    for row in rows:
        if row["entered"]:
            terms=row["expected_projection"]
            b,a=(terms[k] for k in ("background","background_and_rear"))
            print(row["id"],"proj",round(a["exact_template_norm"]/b["exact_template_norm"],3),
                  "alignment",round(a["template_cosine"],3),"expected",round(a["true_signal_along_estimated_direction"],3),
                  "measured/perfect",round(row["nominal_footprint_z"],3),round(row["true_template_existing_projection"],3),
                  "bias",round(row["continuous_null_model_bias_Z"],3),flush=True)
    write_json(ROOT/"information.json",{"driver":reference(__file__),"summary":summary_ref,"cases":rows,
        "scope":"Exact clean continuing and gapped targets enter this diagnostic only. No reconstruction. Site order checked against exact signal difference."})
