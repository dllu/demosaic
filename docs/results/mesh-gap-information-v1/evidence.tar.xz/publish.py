"""Archive verified crop scores, model sources and reviewed native comparisons."""

from datetime import datetime,UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
IMAGES=REPO/"docs/images/mesh-gap-information-v1"
RESULTS=REPO/"docs/results/mesh-gap-information-v1"


def relative(p):
    return {"path":p.relative_to(REPO).as_posix(),"sha256":reference(p)["sha256"]}


def export(image,panels=()):
    source=checked(image)
    target=IMAGES/source.name
    shutil.copyfile(source,target)
    with Image.open(target)as f:
        for panel in panels:
            x,y,w,h=panel["png_xywh"]
            assert w==h==160 and x+w<=f.width and y+h<=f.height
    result=relative(target)
    assert result["sha256"]==image["sha256"]
    return result


def main():
    summary=read_json(ROOT/"summary.json")
    assert summary["scores_recomputed"]==248 and len(summary["cases"])==24
    verification=read_json(ROOT/"verification.json")
    assert len(verification["cases"])==3 and verification["decomposition"]["maximum_z_error"]<2e-6
    repeat=summary["repeat"]["groups"]["all"]
    assert repeat["gap"]["accepted"]=={"standard":14,"affine":14,"curved":13,"joint":13,"joint-audit-only":14}
    assert repeat["continuing"]["accepted"]=={"standard":0,"affine":0,"curved":0,"joint":0,"joint-audit-only":0}
    controls=[v for v in summary["cases"] if v["entry"]["rotated"]]
    assert len(controls)==8
    diagnostics={"rotated_donor_roles_with_changes":{
        arm:sum(any(v["numerical"]["unrelated/"+arm]["changed"]) for v in controls)
        for arm in ("broad","central","standard","affine","curved","joint","joint-audit-only")},
        "edge_only_crops_with_changes":{
        arm:sum(v["numerical"]["matching/"+arm]["changed"][2] for v in summary["cases"])
        for arm in ("broad","central","standard","affine","curved","joint","joint-audit-only")}}
    IMAGES.mkdir()
    RESULTS.mkdir()
    view_notes=read_json(ROOT/"native-notes.json")
    assert {b["id"] for b in summary["boards"]}==set(view_notes)
    native=[]
    for item in summary["boards"]:
        for k in ("source_case","arrays","checkpoint"):
            checked(item[k])
        used={k:v for k,v in item.items()if k not in ("board","triplet")}
        for k in ("board","triplet")if item["id"]in summary["triplets"] else ("board",):
            cell=item[k]
            used[k]=cell|{"image":export(cell["image"],cell["panels"])}
        native.append(used|{"observation":view_notes[item["id"]]})
    assert len(native)==3 and sum("triplet" in s for s in native)==2
    camera_notes={
        "main-overcast-sky-main-overcast-sky":"All policies retain the same smooth gray sky pixels.",
        "main-building-detail-main-building-detail":"Rail and structural detail stay relatively soft across policies.",
        "main-foliage-main-foliage":"All arms keep the same soft shadow leaves and dark contrast.",
        "main-chain-link-fence-main-chain-link-fence":"Joint and affine give the adjacent-donor pixels. Both preserve the local crossing contrast that the straight-step cut weakens.",
        "mesh-nominal-fine-green-mesh-left":"The rear weave to the left of the post remains faint, with little difference across models.",
        "mesh-nominal-fine-green-mesh-right":"Both rear directions remain visible. Joint brings the grid close to the adjacent-donor contrast, with the sloping foreground tie wire clearly visible.",
        "mesh-profile3879-fine-green-mesh-left":"Faint weave remains in both directions amid background mottle. The contrast remains well below the reference.",
        "mesh-profile3879-fine-green-mesh-right":"Both directions remain visible. Dark crossings have less contrast than the independent references.",
    }
    prior=read_json(ROOT/"camera.json")
    viewed=[]
    for view in prior["views"]:
        for k in ("source","parent","RAW","arrays"):
            checked(view[k])
        viewed.append(view|{"image":export(view["image"],view["panels"]),"observation":camera_notes[view["id"]]})
    assert len(viewed)==8
    figure=read_json(ROOT/"information-figure.json")
    figure["image"]=export(figure["image"])
    view=RESULTS/"viewing.json"
    write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
        "scope":"Viewed all eight standing GFX boards, three synthetic comparisons, two native triplets and the information plot.",
        "camera_checkpoint":prior["checkpoint"],"camera":viewed,"synthetic":native,"information_plot":figure})
    extras=("summary.json","verification.json","information.json")
    for name in extras:shutil.copyfile(ROOT/name,RESULTS/name)
    archive=RESULTS/"evidence.tar.xz"
    paths=sorted([f for f in ROOT.iterdir() if f.is_file() and f.suffix in (".py",".json",".log")]
                 +list((ROOT/"scored").glob("*.json"))
                 +[ROOT/"gap-information.png"])
    files={str(p.relative_to(ROOT)):p for p in paths}
    with tarfile.open(archive,"x:xz",preset=4)as f:
        for key,p in files.items():f.add(p,arcname=key)
    with tarfile.open(archive,"r:xz")as f:
        assert set(f.getnames())==set(files)
        for key,p in files.items():
            assert hashlib.sha256(f.extractfile(key).read()).hexdigest()==reference(p)["sha256"]
    previous=("mesh-refined-footprint-v1","mesh-tapered-strength-v1","mesh-averaged-gap-v1","mesh-pooled-gap-evidence-v1","mesh-shrunk-footprint-v1","mesh-refined-edge-v1")
    write_json(RESULTS/"publication.json",{"scope":"Same EMA crop models. Twenty-four fresh exact scenes, twenty-four independent conditional support pairs, both standing camera scenes.",
        "archive":relative(archive),"verified_receipts":[relative(RESULTS/f)for f in (*extras,"viewing.json")],
        "archive_contents":{key:reference(p)for key,p in files.items()},"negative_controls":diagnostics,
        "earlier_sources":[relative(REPO/"docs/results"/n/"evidence.tar.xz")for n in previous]})


if __name__=="__main__":
    main()
