"""Verify that curved geometry and smooth rear hypotheses respect the Bayer split."""

import math
import os
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/"mesh-refined-footprint-v1"
from panel import CENTRE, DISPLAY, Carrier, ribbon, window
from conditioned import audit, curved_position
from edge import step_profile
from optimized_footprints import audit as old_audit
from pooled_gap_audit_20261118 import masks


def case(name, plan):
    source_ref=reference(PREVIOUS/"scored"/f"{name}.json")
    old=read_json(checked(source_ref))
    role=old["proof"]["matching"]["roles"][1]
    noise=plan["noise"][old["entry"]["profile"]]
    with np.load(checked(old["arrays"]),allow_pickle=False) as w:
        raw=window(w["packed"][1],CENTRE,phase=2)
        cfa=w["colors"][1]
    x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
    p,q=(ribbon(x,y,Carrier(**v)) for v in role["central_pair"])
    fx,fy=role["central_pair"][0]["frequency"]
    angle=math.atan2(fy,fx)
    block,proof=audit(raw,cfa,p,q,noise,CENTRE,DISPLAY,angle)
    expected,evidence=old_audit(raw,cfa,p,q,noise,CENTRE,DISPLAY,angle)
    np.testing.assert_array_equal(block["standard"],expected["refined-mean"])
    assert proof["policies"]["standard"]["holdout"]==evidence["policies"]["refined-mean"]["holdout"]
    assert proof["policies"]["joint-audit-only"]["nomination"]==proof["policies"]["standard"]["nomination"]
    assert proof["global_keep"]==evidence["global_keep"]
    if "shape" in proof["edge"]:
        straight=proof["edge"]["shape"]
        np.testing.assert_allclose(curved_position(x,y,(*straight,0.))[0],
                                   step_profile(x,y,straight)[0],atol=6e-14,rtol=0)
        theta,position,width,arc=proof["curved_edge"]
        assert abs(theta-straight[0])<=np.deg2rad(12.)+1e-10
        assert abs(position-straight[1])<=14.+1e-10 and 1.4<=width<=12. and abs(arc)<=20.
        assert proof["curved_fit_gain"][1]>=proof["curved_fit_gain"][0]-1e-8
    reserve,segments=masks(raw)
    changed=raw.copy()
    selected=segments[-1].reshape(raw.shape)
    assert not np.any(selected.reshape(-1)&reserve)
    changed[selected]+=.014*(p[selected]-.47*q[selected])
    _,after=audit(changed,cfa,p,q,noise,CENTRE,DISPLAY,angle)
    assert after["curved_edge"]==proof["curved_edge"]
    for name,original in proof["policies"].items():
        assert after["policies"][name]["nomination"]==original["nomination"]
        assert after["policies"][name]["holdout"]["z"]!=original["holdout"]["z"]
    return {"source":source_ref,"same_standard_output":True,"same_shape_after_audit_perturbation":True,
            "curved_edge":proof["curved_edge"],"curved_fit_gain":proof["curved_fit_gain"]}


if __name__=="__main__":
    os.sched_setaffinity(0,[19]);os.nice(12)
    source=reference(PREVIOUS/"measured-plan.json")
    plan=read_json(checked(source))
    records=[case(name,plan)for name in ("iso400-step-g233","iso6400-band-g233","iso400-ellipse-g235")]
    information=reference(ROOT/"information.json")
    residuals=[]
    for row in read_json(checked(information))["cases"]:
        if row["entered"]:
            projected=row["expected_projection"]["background_and_rear"]
            composed=projected["true_signal_along_estimated_direction"]+row["continuous_null_model_bias_Z"]+row["noise_residual_Z"]
            residuals.append(abs(composed-row["nominal_footprint_z"]))
    assert len(residuals)==11 and max(residuals)<2e-6
    write_json(ROOT/"verification.json",{"source":reference(__file__),"earlier_plan":source,
         "cases":records,"decomposition":{"receipt":information,"maximum_z_error":max(residuals)}})
    print("Three crops match the previous standard. All five nominations retain the independent sample boundary.",flush=True)
