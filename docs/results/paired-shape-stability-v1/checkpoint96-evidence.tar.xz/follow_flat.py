"""Run fixed exact-flat response calibration after the matching evaluation closes."""
import subprocess
import sys

from demosaic.experiments.artifacts import read_json
from train_projected import ROOT
from follow import wait_until

if __name__=="__main__":
    controller=read_json(ROOT/"follow-launch.json")
    wait_until(ROOT/"endpoint/results.json",controller)
    subprocess.run([sys.executable,str(ROOT/"flat_matched_transfer.py"),"endpoint"],check=True)
