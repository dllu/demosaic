"""Calibrate equal exact-flat error on the original photos, then score fresh photos."""
import argparse

import numpy as np
from scipy.optimize import brentq, minimize_scalar

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from review_projected import CONTRASTS,compare_at_strength
from train_projected import ROOT


def flat_curve(rows,name):
    expression=np.asarray([r["moments"][name]["flat"] for r in rows])
    def at(strength):
        score=expression@np.array([1.,strength,strength**2])
        return float(np.sqrt(np.maximum(score,0)).mean())
    return at


def match_on(rows,first,second):
    curves={label:flat_curve(rows,label) for label in (first,second)}
    nominal={label:curve(1.) for label,curve in curves.items()}
    budget=min(nominal.values())
    scales={}
    for label,curve in curves.items():
        if abs(curve(1.)-budget)<1e-12:
            scales[label]=1.
            continue
        middle=minimize_scalar(curve,method="bounded",bounds=(0.,1.),options={"xatol":1e-10})
        p=min((0.,middle.x,1.),key=curve)
        low=curve(p)
        if low-budget>1e-11:
            return budget,None,nominal
        if abs(low-budget)<1e-11:
            scales[label]=p
        else:
            scales[label]=brentq(lambda strength:curve(strength)-budget,p,1.,xtol=1e-13)
        if scales[label]<=1e-6:
            return budget,None,nominal
    assert all(abs(curves[label](s)-budget)<2e-10 for label,s in scales.items())
    return budget,scales,nominal


def report(which):
    src=ROOT/("first-transfer.json" if which=="first" else "endpoint/results.json")
    bound=reference(src)
    data=read_json(checked(bound))
    random=np.random.default_rng(3619812781)
    cells={}
    for profile in ("iso400","iso6400"):
        for law in ("coupled","independent"):
            rows=[r for r in data["rows"] if r["law"]==law and r.get("profile","iso6400")==profile]
            if not rows:
                continue
            fit=[r for r in rows if r["cohort"]=="original64"]
            test=[r for r in rows if r["cohort"]=="fresh32"]
            assert (len(fit),len(test))==(64,32)
            contrasts={}
            for a,b in CONTRASTS:
                budget,scales,nominal=match_on(fit,a,b)
                fit_record={"calibrated_flat_RMS_DN16":budget,"nominal_original64_flat_RMS_DN16":nominal}
                if scales:
                    fit_record["scales"]=scales
                    fit_record["original64_calibrated"]=compare_at_strength(fit,a,b,scales,random)
                    fit_record["fresh32_fixed_scale"]=compare_at_strength(test,a,b,scales,random)
                else:
                    fit_record["status"]="The quieter nominal budget has no nonzero match at a weaker strength."
                contrasts[f"{a}-vs-{b}"]=fit_record
            cells.setdefault(profile,{})[law]=contrasts
    write_json(ROOT/(which+"-flat-matched.json"),{
        "driver":reference(__file__),"source":bound,"evaluation":which,"cells":cells,
        "rule":"The lower of two original64 nominal exact-flat RMS values is the budget. Each method chooses the highest <=1 strength producing that same value. Scales are carried unchanged to fresh32.",
    })


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("scope",choices=("first","endpoint"))
    report(p.parse_args().scope)
