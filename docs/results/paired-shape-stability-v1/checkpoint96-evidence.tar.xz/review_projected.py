"""Evaluate single-frame projected-repeat models and match recoverable detail on separate photos."""
import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from train_projected import METHODS, ROOT, STABILITY
from evaluate_repeat import (
    as_cuda, bind_upstream, channel_coefficients, head, packed_inputs, predictions,
    read_parent, score_triplet_sets,
)
from measure import BANDS
from strength_moments import measure, value
from summarize import summarize_group

SCORED_METHODS=("V120","100k","paired-init",*METHODS)
CONTRASTS=(("projected-repeat","repeat"),("projected-repeat","control"),
           ("repeat","control"),("projected-repeat","paired-init"))


def pretrained(plan, checkpoint):
    states=torch.load(checked(plan["initial_head"]),map_location="cpu",weights_only=True)
    result={"paired-init":head(states,"paired")}
    new=torch.load(checked(checkpoint),map_location="cpu",weights_only=True)
    assert new["plan"]==reference(ROOT/"plan.json") and new["parent_frozen"]
    result.update({label:head(new,label) for label in METHODS})
    return result


def evaluate_strength(case, observations, truth, fields, roi):
    _, target=channel_coefficients(truth,fields,roi)
    values = {
        label: np.stack([channel_coefficients(view[label],fields,roi)[1] for view in observations])
        for label in ("100k","paired-init",*METHODS)
    }
    base=values["100k"]
    return {label:measure(base,arr-base,target,BANDS["fine"]) for label,arr in values.items()}


DELTA_KEYS=("increment_DN16","present_DN16","flat_DN16","variance_DN16_squared","shared_DN16_squared")


def compare_at_strength(rows, compared, anchor, scales, random):
    a,b = (label for label in (compared,anchor))
    first=[value(r["moments"][a],scales[a]) for r in rows]
    second=[value(r["moments"][b],scales[b]) for r in rows]
    metrics=np.array([[new[k]-old[k] for k in DELTA_KEYS] for new,old in zip(first,second,strict=True)])
    alignment=np.array([new["aligned_dot"]-old["aligned_dot"] for new,old in zip(first,second,strict=True)])
    strength=np.array([new["target_power"] for new in first])
    samples=random.integers(0,len(rows),(4000,len(rows)))
    values=metrics.mean(axis=0)
    means=metrics[samples].mean(axis=1)
    interval=np.quantile(means,[.025,.975],axis=0)
    result={k:[float(values[i]),float(interval[0,i]),float(interval[1,i])] for i,k in enumerate(DELTA_KEYS)}
    response=100*alignment[samples].sum(1)/strength[samples].sum(1)
    result["response_percentage_points"]=[float(100*alignment.sum()/strength.sum()),*np.quantile(response,[.025,.975]).tolist()]
    return result


def cross_calibrate(rows, random):
    fit=[row for row in rows if row["cohort"]=="original64"]
    verify=[row for row in rows if row["cohort"]=="fresh32"]
    assert (len(fit),len(verify))==(64,32)
    table={}
    for compared,anchor in CONTRASTS:
        label=f"{compared}-vs-{anchor}"
        fit_gains={m:sum(row["moments"][m]["aligned"][1] for row in fit) for m in (compared,anchor)}
        default={compared:1.,anchor:1.}
        row={"calibration_gains_dot_product":fit_gains,
             "fresh_nominal_delta":compare_at_strength(verify,compared,anchor,default,random)}
        gain=min(fit_gains.values())
        if gain>0:
            scales={m:gain/v for m,v in fit_gains.items()}
            row["response_matched_scales"]=scales
            row["exact_calibration_check"]=compare_at_strength(fit,compared,anchor,scales,random)
            assert abs(row["exact_calibration_check"]["response_percentage_points"][0])<1e-11
            row["fresh_matched_delta"]=compare_at_strength(verify,compared,anchor,scales,random)
        else:
            row["response_match_scope"]="Both head corrections must add positive target-aligned response for a nonzero down-scaled match."
        table[label]=row
    return table


@torch.inference_mode()
def review(stage):
    os.sched_setaffinity(0,[8,9,19])
    os.nice(12)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,7*2**30/torch.cuda.get_device_properties(0).total_memory))
    frozen=read_json(ROOT/"plan.json")
    earlier=read_json(STABILITY/"evaluation-plan.json")
    archive_path, parents, stored, sources=bind_upstream()
    artifact = ROOT/"training/complete.json"
    if stage=="endpoint":
        state=read_json(artifact)
        binding=state["head_checkpoint"]
        assert state["updates"]==frozen["steps"]
    else:
        artifact=ROOT/"training/step000096.pt"
        binding=reference(artifact)
    models=pretrained(frozen,binding)
    guard=(read_json(checked(frozen["guard"]))["threshold"],
           read_json(checked(frozen["guard_long"]))["threshold_0_to_1"][0])
    folder=ROOT/stage
    folder.mkdir()
    plan=folder/"plan.json"
    write_json(plan,{
        "driver":reference(__file__),"summary_module":reference(ROOT/"strength_moments.py"),
        "scope":stage,"checkpoint":binding,"initial_ema":frozen["initial_head"],
        "training_receipt":reference(artifact),"training_plan":reference(ROOT/"plan.json"),
        "parents":parents["models"],"parent_archive":reference(archive_path),"guard":frozen["guard"],
        "evaluation":reference(STABILITY/"evaluation-plan.json"),
    })
    out=[]
    start=time.monotonic()
    with ieee_fp32():
        for case in sources:
            if stage!="endpoint" and (case["index"]>=16 or case["profile"]["name"]!="iso6400"):
                continue
            observed=[]
            for repeat, record in enumerate(stored[case["id"]]):
                arrays=packed_inputs(case,repeat)
                fields=as_cuda(arrays)
                observed.append(predictions(models,fields,read_parent(record),guard))
            parameters={key:arrays[key] for key in ("wb","matrix")}
            roi=earlier["score_ROI_xywh"]
            scores=score_triplet_sets(observed,arrays["target"],parameters,roi)
            metrics=evaluate_strength(case,observed,arrays["target"],parameters,roi)
            for label,built in metrics.items():
                exact=value(built,1.)
                np.testing.assert_allclose(exact["variance_DN16_squared"],
                                           scores[label]["fine"]["swapped_draw_variance_DN16_squared"],rtol=1e-13,atol=1e-9)
                np.testing.assert_allclose(exact["increment_DN16"],scores[label]["fine"]["mean_increment_RMS_DN16"],
                                           rtol=1e-13,atol=1e-10)
            out.append({"id":case["id"],"source":case["source"],"profile":case["profile"]["name"],
                        "law":case["coupling"],"cohort":case["cohort"],"CFA":case["CFA"],
                        "metrics":scores,"moments":metrics})
            if len(out)%16==0:
                print(stage,len(out),round(time.monotonic()-start,2),flush=True)
    assert len(out)==(384 if stage=="endpoint" else 32)
    rng=np.random.default_rng(30468423)
    summaries={}
    for profile in sorted({r["profile"] for r in out}):
        for law in ("coupled","independent"):
            cell=[r for r in out if (r["profile"],r["law"])==(profile,law)]
            groups={"all":cell}
            if stage=="endpoint":
                groups.update({part:[x for x in cell if x["cohort"]==part] for part in ("original64","fresh32")})
            section={k:summarize_group(v,SCORED_METHODS,rng) for k,v in groups.items()}
            if stage=="endpoint":
                section["calibrate_original64_score_fresh32"]=cross_calibrate(cell,rng)
            else:
                condition={}
                for a,b in CONTRASTS:
                    gain={m:sum(row["moments"][m]["aligned"][1] for row in cell) for m in (a,b)}
                    floor=min(gain.values())
                    if floor>0:
                        scalars={k:floor/v for k,v in gain.items()}
                        condition[f"{a}-vs-{b}"]={"scale":scalars,
                            "on_same_panel":compare_at_strength(cell,a,b,scalars,rng)}
                section["descriptive_same_panel_response_match"]=condition
            summaries.setdefault(profile,{})[law]=section
    write_json(folder/"results.json",{
        "plan":reference(plan),"rows":out,"pooled":summaries,
        "seconds":time.monotonic()-start,
        "matched_scope":"Endpoint response matching uses one scalar per method and noise condition chosen on the 64 original exact-target photos. The additional 32 sources measure transfer at the fixed scales.",
    })


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage",choices=("first","endpoint"))
    review(p.parse_args().stage)
