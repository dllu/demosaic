"""Exact scalar adjustment of fine-band error after composing the RGB correction."""
import numpy as np

FACTOR = 65535**2/(36*16*16)
RMS_METRICS = ("increment","present","flat")


def triplet(original, step, axes):
    return np.stack([
        (original*original).sum(axis=axes),
        2*(original*step).sum(axis=axes),
        (step*step).sum(axis=axes),
    ], axis=-1)*FACTOR


def extract(coeffs, mask):
    return coeffs[..., mask]


def measure(base, correction, target, mask):
    """Predict band metrics for y = base + scale * correction."""
    original = extract(base,mask)
    change = extract(correction,mask)
    truth = extract(target,mask)
    assert np.max(abs(truth[2]))<1e-14
    increment = truth[0]-truth[1]
    original_increment = original[:,0]-original[:,1]
    added_increment = change[:,0]-change[:,1]
    error = original_increment-increment[None]
    stable = error-error.mean(axis=0)
    stable_change = added_increment-added_increment.mean(axis=0)
    return {
        "aligned": [float(np.sum(original_increment.mean(axis=0)*increment)),
                    float(np.sum(added_increment.mean(axis=0)*increment))],
        "target_power": float(np.sum(increment**2)),
        "increment": triplet(error,added_increment,(-2,-1)).tolist(),
        "present": triplet(original[:,0]-truth[None,0],change[:,0],(-2,-1)).tolist(),
        "flat": triplet(original[:,2],change[:,2],(-2,-1)).tolist(),
        "repeat_variance": (triplet(stable,stable_change,(0,1,2))/(len(error)-1)).tolist(),
    }


def value(data, scale):
    q=np.array([1,scale,scale**2],dtype=float)
    terms={key: np.maximum(0,np.asarray(data[key])@q) for key in RMS_METRICS}
    out={key+"_DN16": float(np.sqrt(a).mean()) for key,a in terms.items()}
    out["increment_mean_squared_DN16"]=float(terms["increment"].mean())
    out["variance_DN16_squared"]=float(np.asarray(data["repeat_variance"])@q)
    out["shared_DN16_squared"]=out["increment_mean_squared_DN16"]-out["variance_DN16_squared"]
    out["aligned_dot"]=data["aligned"][0]+scale*data["aligned"][1]
    out["target_power"]=data["target_power"]
    return out
