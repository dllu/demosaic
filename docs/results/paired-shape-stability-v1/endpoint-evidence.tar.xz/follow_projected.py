"""Run the first fixed checkpoint and endpoint reviews once training provides them."""
import os
import sys

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json
from train_projected import ROOT, STABILITY
from follow import command,wait_until
import follow


if __name__=="__main__":
    follow.ROOT=ROOT
    trainer=read_json(ROOT/"training/launch.json")
    write_json(ROOT/"follow-launch.json",{
        "pid":os.getpid(),"created":psutil.Process().create_time(),"trainer":trainer,
        "driver":reference(__file__),"evaluation_archive":reference(STABILITY/"parent-predictions/complete.json"),
    })
    early=wait_until(ROOT/"training/step000096.pt",trainer)
    command("review_projected.py","first",report="first.log")
    final=wait_until(ROOT/"training/complete.json",trainer)
    command("review_projected.py","endpoint",report="endpoint.log")
    command("render_projected.py",report="render.log")
    write_json(ROOT/"follow-complete.json",{
        "training":final,"first":early,
        "evaluation":reference(ROOT/"endpoint/results.json"),
        "native_render":reference(ROOT/"endpoint/native/publication.json"),
        "actual_native_viewing_complete":False,
    })
