"""Train matched paired heads with and without a response-preserving repeat loss."""
import argparse
from collections import Counter
import json
import math
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import psutil
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.paired_detail import PairedLuminanceDetail, fine_band
from demosaic.precision import ieee_fp32
from demosaic.scene_training_data import scene_seed
from project_repeat import inner, reference_strength_pair

ROOT = Path(__file__).resolve().parent
STABILITY = ROOT.parent / "paired-repeat-stability-v2"
sys.path.insert(0,str(STABILITY))
from train_repeat import (ARGS, CORE, balanced_camera, ema_update, paired_gates, robust,
                          save_checkpoint, setup_models, shaped, training_observations)
from profile_raw_kernel_inference import model_hash
from measure import DCT, BANDS

SEED = 849300591241
INDEX_OFFSET = 9600
STEPS = 384
PER_UPDATE = 2
METHODS = ("control", "repeat", "projected-repeat")


def freeze():
    earlier = read_json(STABILITY/"plan.json")
    earlier_sources = read_json(checked(earlier["schedule"]))
    first_sources = read_json(checked(earlier_sources["prior_training_sources"]))
    panel = read_json(checked(reference(STABILITY/"evaluation-plan.json")))
    input_source = checked(earlier_sources["manifest"])
    records = [json.loads(line) for line in input_source.read_text().splitlines() if line.strip()]
    nearby = {r["id"] for r in (*earlier_sources["rows"], *earlier_sources["qualification"], *first_sources["rows"])}
    heldout = {r["source"]["id"] for r in panel["rows"]}
    assert len(records)==90692 and all(r["split"]=="train" for r in records)
    assert {r["id"] for r in records}.isdisjoint(heldout)
    eligible = [r for r in records if r["id"] not in nearby | heldout]
    chosen = random.Random(SEED).sample(eligible,STEPS*PER_UPDATE+6)
    assert len({r["id"] for r in chosen})==len(chosen)
    schedule = ROOT/"schedule.json"
    write_json(schedule,{
        "manifest":earlier_sources["manifest"],"rows":chosen[:STEPS*PER_UPDATE],
        "qualification":chosen[STEPS*PER_UPDATE:],"excluded_holds":reference(STABILITY/"evaluation-plan.json"),
        "disjoint_prior_schedules":[earlier["schedule"],earlier_sources["prior_training_sources"]],
    })
    design = Counter((i//PER_UPDATE%2,*balanced_camera(i+INDEX_OFFSET)) for i in range(STEPS*PER_UPDATE))
    assert len(design)==16 and set(design.values())=={48}
    python_sources = [
        Path(__file__),ROOT/"project_repeat.py",ROOT/"qualify_projection.py",STABILITY/"train_repeat.py",
        *[checked(path) for path in earlier["sources"]],
    ]
    write_json(ROOT/"plan.json",{
        "driver":reference(__file__),"sources":[reference(p) for p in dict.fromkeys(python_sources)],
        "models":earlier["models"],"initial_head":earlier["initial_head"],"guard":earlier["guard"],
        "guard_long":earlier["guard_long"],"training_seed":SEED,"physical_seed_index_offset":INDEX_OFFSET,
        "schedule":reference(schedule),"matched_arms":METHODS,"steps":STEPS,"photos":STEPS*PER_UPDATE,
        "precision":"CUDA IEEE FP32; EMA inference; frozen Corpus 100k and selected paired EMA teacher.",
        "loss":"Same absolute, flat and 0.65 signed pair loss. Both repeat arms add weight 0.75 on differences between independent redraws. The projected arm removes the deviation parallel to the frozen teacher correction and exact clean fine increment before computing only the repeat term.",
        "conditioning":"Same delivered support windows in all arms. Explicit target band 1/8 to 1/3 cycles per pixel in the projection. Only single observations go into the network or inference guard.",
        "optimizer":"Separate AdamW for each matched head, 48-update warmup from zero, 1e-4 to 1e-5 cosine and .995 EMA.",
    })


def pair(field):
    values = shaped(field)
    return (values[:,:,0] - values[:,:,1])[CORE]


def clean_basis(native, transform, mask):
    b, draws, channels, h, w = native.shape
    blocks = native.reshape(b,draws,channels,h//16,16,w//16,16).swapaxes(-3,-2)
    coeffs = transform @ blocks @ transform.T
    fine = transform.T @ (coeffs * mask) @ transform
    return fine.swapaxes(-3,-2).reshape_as(native)


def rate(step):
    if step <=48:
        return 1e-4*step/48
    return 1e-5+9e-5*(.5+.5*math.cos(math.pi*(step-48)/(STEPS-48)))


def configure():
    os.sched_setaffinity(0,[8,9,19])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,11*2**30/torch.cuda.get_device_properties(0).total_memory))


def objective(predicted, desired, noise, pair_noise, teacher_pair, true_pair, tag):
    residual = predicted-desired
    delta = residual/noise
    absolute = .6*robust(delta[CORE])+.4*robust(delta)
    quiet = shaped(predicted/noise)[:,:,2][CORE].square().mean()
    delivered_pair, ideal_pair = pair(predicted),pair(desired)
    scored_pair = delivered_pair-ideal_pair
    signed = robust(scored_pair / pair_noise[:,None])
    repeat_vector = scored_pair
    if tag=="projected-repeat":
        canonical=reference_strength_pair(delivered_pair,teacher_pair,true_pair)
        repeat_vector = canonical-ideal_pair
    repeat_loss = robust((repeat_vector[:,0]-repeat_vector[:,1])/(math.sqrt(2)*pair_noise))
    total=absolute+.25*quiet+.65*signed
    if tag!="control":
        total=total+.75*repeat_loss
    return total,(absolute,quiet,signed,repeat_loss),delivered_pair


def train(qualification):
    p=ROOT/"plan.json"
    plan=read_json(p)
    assert checked(plan["driver"])==Path(__file__) and tuple(plan["matched_arms"])==METHODS
    for source in plan["sources"]:
        checked(source)
    records=read_json(checked(plan["schedule"]))["qualification" if qualification else "rows"]
    count=3 if qualification else STEPS
    offset=INDEX_OFFSET+(STEPS*PER_UPDATE if qualification else 0)
    out=ROOT/("qualification" if qualification else "training")
    out.mkdir()
    write_json(out/"launch.json",{
        "plan":reference(p),"pid":os.getpid(),"created":psutil.Process().create_time(),
        "qualification_only":qualification,
    })
    configure()
    frozen=setup_models(plan)["Corpus 100k"].requires_grad_(False)
    verified=model_hash(frozen)
    initial=torch.load(checked(plan["initial_head"]),weights_only=True,map_location="cpu")["weights"]["paired"]["ema"]
    arms={k:PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last) for k in METHODS}
    teacher=PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).requires_grad_(False).eval()
    for model in (*arms.values(),teacher):
        model.load_state_dict(initial,strict=True)
    teacher_hash=model_hash(teacher)
    averages={k:{n:v.clone() for n,v in a.state_dict().items()} for k,a in arms.items()}
    optimizer={k:torch.optim.AdamW(a.parameters(),lr=1e-4) for k,a in arms.items()}
    gates=(read_json(checked(plan["guard"]))["threshold"],read_json(checked(plan["guard_long"]))["threshold_0_to_1"][0])
    basis=torch.as_tensor(DCT,dtype=torch.float32,device="cuda")
    mask=torch.as_tensor(BANDS["fine"],device="cuda")
    began=time.monotonic()
    checkpoints=[]
    strata=Counter()
    with (out/"observations.jsonl").open("x") as receipt,ieee_fp32():
        for step in range(1,count+1):
            rng=random.Random(scene_seed(SEED,step,"profile"))
            iso,shot,read=("iso6400",.00128,6.5536e-6) if step%2 else ("iso400",8e-5,2.56e-8)
            jitter=2**rng.uniform(-.45,.45)
            profile={"shot":shot*jitter,"read":read*jitter**2,"exposure":2**rng.uniform(-2.3,-.25)}
            base=(step-1)*PER_UPDATE
            samples=[training_observations(records[base+i],base+i+offset,profile) for i in range(PER_UPDATE)]
            for _, row in samples:
                strata[f"{iso}/{row['pattern']}/{row['coupling']}"]+=1
            data={k:torch.cat([s[0][k] for s in samples]).cuda() for k in (*ARGS,"target")}
            for key in ("packed","variance","target"):
                data[key]=data[key].contiguous(memory_format=torch.channels_last)
            args=tuple(data[k] for k in ARGS)
            frozen.set_noise(profile["shot"],profile["read"])
            with torch.no_grad():
                parent=torch.cat([frozen(*(v[sl] for v in args)) for sl in (slice(0,6),slice(6,None))])
                _,guard=paired_gates(*args[:3],*gates)
                clean=teacher.scene_luma(data["target"],*args[-2:])
                desired=fine_band(clean-teacher.scene_luma(parent,*args[-2:]))
                exact=clean_basis(pair(clean),basis,mask)
                base_output=teacher.luminance_delta(parent,*args)*guard
                teacher_pair=pair(base_output)
                noise=data["variance"].mean((1,2,3)).sqrt().clamp_min(.001)[:,None,None,None]
                pair_noise=shaped(noise)[:,:,:2].mean(dim=(1,2))
                if step==1:
                    # A pure scale of the same delivered correction cannot reduce this loss.
                    replay=reference_strength_pair(.4*teacher_pair,teacher_pair,exact)
                    torch.testing.assert_close(replay,teacher_pair,rtol=1e-5,atol=1e-7)
            scores={}
            for tag,model in arms.items():
                opt=optimizer[tag]
                opt.param_groups[0]["lr"]=rate(step)
                opt.zero_grad(set_to_none=True)
                prediction=model.luminance_delta(parent,*args)*guard
                if step==1:
                    assert torch.equal(prediction,base_output)
                loss, terms, reconstruction=objective(prediction,desired,noise,pair_noise,teacher_pair,exact,tag)
                loss.backward()
                norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
                opt.step()
                ema_update(averages[tag],model)
                with torch.no_grad():
                    gain=float((inner(reconstruction,exact).sum()/inner(exact,exact).sum().clamp_min(1e-12)).item())
                scores[tag]=[float(value.detach()) for value in (loss,*terms,norm)]+[gain]
            receipt.write(json.dumps({"step":step,"samples":[r[1] for r in samples],"scores":scores})+"\n")
            receipt.flush()
            if step%48==0 or step==count:
                print(step,round(time.monotonic()-began,2),scores,flush=True)
            if step==count or step in (96,192,288):
                checkpoints.append(save_checkpoint(out,step,arms,averages,optimizer,reference(p)))
    assert model_hash(frozen)==verified and model_hash(teacher)==teacher_hash
    final=torch.load(checked(checkpoints[-1]),weights_only=True,map_location="cpu")
    assert final["step"]==count
    assert all(torch.isfinite(w).all() for h in final["weights"].values() for w in h["ema"].values())
    if not qualification:
        assert len(strata)==16 and set(strata.values())=={48}
    write_json(out/"complete.json",{
        "plan":reference(p),"head_checkpoint":checkpoints[-1],"milestones":checkpoints,
        "parent":plan["models"]["Corpus 100k"],"initial_head":plan["initial_head"],
        "parent_weights_unchanged":verified,"teacher_weights_unchanged":teacher_hash,
        "measured_train_seconds":time.monotonic()-began,"updates":count,
        "distinct_photos":count*PER_UPDATE,"examples_per_head":count*PER_UPDATE*6,
        "training_cells":dict(strata),"observations":reference(out/"observations.jsonl"),
        "qualification_only":qualification,
    })


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("plan","qualify","train"))
    action=parser.parse_args().action
    freeze() if action=="plan" else train(action=="qualify")
