"""Render the fixed native synthetic and standing photo comparisons."""
import os
from pathlib import Path
import time

import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from report_scene_wave_guides import native_board

from review_projected import SCORED_METHODS, bind_upstream, pretrained
from evaluate_repeat import as_cuda, packed_inputs, predictions, read_parent
from train_projected import ARGS, METHODS, ROOT, STABILITY
import render_repeat

LABELS={
 "V120":"V120 EMA","100k":"Parent 100k EMA","paired-init":"Prior paired EMA",
 "control":"Matched control","repeat":"Standard repeat","projected-repeat":"Projected repeat",
}


def native_photos(out, report, models, short_and_long):
    _, _, baselines, inputs=bind_upstream()
    panel=read_json(STABILITY/"evaluation-plan.json")
    source={r["id"]:r for r in inputs}
    fresh=[r for r in report["rows"] if
           (r["cohort"],r["profile"],r["law"])==("fresh32","iso6400","independent")]
    assert len(fresh)==32
    def difference(r,key):
        return r["metrics"]["projected-repeat"]["fine"][key] - r["metrics"]["repeat"]["fine"][key]
    ranked=sorted(fresh,key=lambda r:difference(r,"mean_increment_RMS_DN16"))
    highest_flat=max(fresh,key=lambda r:difference(r,"mean_quiet_RMS_DN16"))
    selected=(
        (ranked[0],0,"Largest fine-increment RMS reduction versus standard repeat"),
        (ranked[-1],0,"Largest fine-increment RMS increase versus standard repeat"),
        (highest_flat,2,"Largest flat-band RMS increase versus standard repeat"),
    )
    images=[]
    for row,role,selection in selected:
        case=source[row["id"]]
        photo=panel["rows"][case["index"]]
        assert case["source"]==photo["source"]["id"]
        native=packed_inputs(case,0)
        result=predictions(models,as_cuda(native),read_parent(baselines[case["id"]][0]),short_and_long)
        fields={k:native[k][role:role+1] for k in ARGS}
        panels=[noisy_malvar(fields)[0], *[result[k][role] for k in SCORED_METHODS],native["target"][role]]
        images.append(native_board(out,f"{case['id']}-r0-role{role}",panels,fields,{
            "source_photo":photo["source"],"bbox_native":case["native_box"],"profile":case["profile"],
            "CFA":case["CFA"],"draw":case["coupling"],"observation":case["draws"][0],
            "selection":selection,"checkpoint_plan":report["plan"],"display_draw":0,
        },labels=("Noisy Malvar",*[LABELS[key] for key in SCORED_METHODS],"Exact GT"),
            triplet_indices=(0,1+SCORED_METHODS.index("projected-repeat"),len(panels)-1),
            exposure=1/case["profile"]["exposure"],contrast=2,roi=tuple(panel["native_display_ROI_xywh"])))
    return images


@torch.inference_mode()
def render():
    os.sched_setaffinity(0,[8,9,19])
    os.nice(12)
    torch.set_num_threads(2)
    product=ROOT/"endpoint"
    analysis=read_json(product/"results.json")
    plan=read_json(checked(analysis["plan"]))
    train=read_json(checked(plan["training_plan"]))
    models=pretrained(train,plan["checkpoint"])
    short_and_long=(read_json(checked(train["guard"]))["threshold"],
                    read_json(checked(train["guard_long"]))["threshold_0_to_1"][0])
    render_repeat.SHOW=("paired-init",*METHODS)
    render_repeat.DISPLAY=LABELS
    emit=product/"native"
    emit.mkdir()
    began=time.monotonic()
    with ieee_fp32():
        camera=render_repeat.show_camera(models,short_and_long,emit)
        photo=native_photos(emit,analysis,models,short_and_long)
    write_json(emit/"publication.json",{
        "driver":reference(__file__),"standing_renderer":reference(render_repeat.__file__),
        "bound_plan":analysis["plan"],"camera":camera,"photo":photo,
        "actual_native_viewing_complete":False,"render_seconds":time.monotonic()-began,
    })


if __name__=="__main__":
    render()
