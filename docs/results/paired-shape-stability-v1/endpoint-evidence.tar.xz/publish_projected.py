"""Archive the completed projected-repeat endpoint and inspected native comparisons."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from train_projected import ROOT

DEST=Path("docs/results/paired-shape-stability-v1")
IMAGES=Path("docs/images/paired-shape-stability-v1")

FILES=(
    "plan.json","schedule.json","training/launch.json","training/complete.json","training/observations.jsonl",
    "train_projected.py","project_repeat.py","review_projected.py","strength_moments.py",
    "follow_projected.py","follow-complete.json","follow-flat.log","follow_flat.py",
    "flat_matched_transfer.py","render_projected.py","endpoint-flat-matched.json",
    "endpoint/plan.json","endpoint/results.json","endpoint/native/publication.json",
    "train.log","endpoint.log","render.log","endpoint-viewing-notes.json",
    "endpoint-training-audit.json","publish_projected.py",
)


def run():
    final=read_json(ROOT/"training/complete.json")
    state=checked(final["head_checkpoint"])
    assert final["updates"]==384 and final["distinct_photos"]==768
    binding=Path("/mnt/external/demosaic/models/paired-shape-stability-v1-step000384.pt")
    if not binding.exists():
        shutil.copyfile(state,binding)
    assert reference(binding)["sha256"]==final["head_checkpoint"]["sha256"]
    photos=read_json(ROOT/"endpoint/results.json")
    flat=read_json(ROOT/"endpoint-flat-matched.json")
    assert checked(flat["source"])==ROOT/"endpoint/results.json"
    rendered=read_json(ROOT/"endpoint/native/publication.json")
    # The reviewer records concrete observations after inspecting each board.
    review=read_json(ROOT/"endpoint-viewing-notes.json")
    lookup=review["rows"]
    images=[*rendered["camera"],*rendered["photo"]]
    assert len(images)==len(lookup)==11 and set(row["id"] for row in images)==lookup.keys()
    assert rendered["bound_plan"]==photos["plan"]
    assert read_json(checked(photos["plan"]))["checkpoint"]==final["head_checkpoint"]
    IMAGES.mkdir(exist_ok=True)
    def publish(board):
        source=checked(board["image"])
        dest=IMAGES/source.name
        shutil.copyfile(source,dest)
        assert reference(dest)["sha256"]==board["image"]["sha256"]
        with Image.open(dest) as image:
            for item in board["panels"]:
                x,y,w,h=item["png_xywh"]
                assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            image.verify()
        board["image"]["path"]=str(dest)
    for row in rendered["camera"]:
        publish(row)
        row["observed"]=lookup[row["id"]]
    for row in rendered["photo"]:
        publish(row["board"])
        publish(row["triplet"])
        row["observed"]=lookup[row["id"]]
    rendered["actual_native_viewing_complete"]=True
    bundled=DEST/"endpoint-evidence.tar.xz"
    with tarfile.open(bundled,"x:xz") as tf:
        for file in FILES:
            tf.add(ROOT/file,arcname=file)
    highlights={}
    for profile,conditions in photos["pooled"].items():
        highlights[profile]={}
        for law,panels in conditions.items():
            highlights[profile][law]={
                "nominal":{k:panels[k]["table"] for k in ("all","original64","fresh32")},
                "separate_response_match":panels["calibrate_original64_score_fresh32"],
                "separate_exact_flat_match":flat["cells"][profile][law],
            }
    write_json(DEST/"endpoint-summary.json",{
        "training_execution":final,"retained_endpoint":reference(binding),
        "training_execution_audit":reference(ROOT/"endpoint-training-audit.json"),
        "execution_scope":"Completed component training. 96 exact-target natural photos at two priors and both pair types; native GFX qualitative review completed. No full427 or measured-camera history panel for the composed component.",
        "ema":True,"parent_weights_unchanged":final["parent_weights_unchanged"],
        "evaluated_policy":read_json(checked(photos["plan"])),
        "metric_seconds_with_saved_parents":photos["seconds"],
        "highlights":highlights,"native_review":rendered,"source_evidence":reference(bundled),
    })


if __name__=="__main__":
    run()
