"""Remove the uniform frozen correction direction from a repeat-only loss."""
import torch


def inner(first, second):
    return (first * second).sum(dim=tuple(range(1, first.ndim)), keepdim=True)


def remove_component(value, axis):
    """Project off a fixed axis shared by the two draws of each source."""
    energy = inner(axis, axis)
    scale = inner(value, axis) / energy.clamp_min(torch.finfo(axis.dtype).tiny)
    return value - scale * axis


def reference_strength_pair(delivered, teacher, true_increment):
    """Restore the teacher's aligned and radial components for the repeat loss.

    Input shapes are source × two draws × channel × height × width.
    Teacher and clean truth are fixed. No projection changes delivered inference.
    """
    orthogonal_teacher = remove_component(teacher, true_increment)
    remaining_energy = inner(orthogonal_teacher, orthogonal_teacher)
    teacher_energy = inner(teacher, teacher)
    independent = remaining_energy > 32 * torch.finfo(teacher.dtype).eps * teacher_energy
    orthogonal_teacher = torch.where(independent, orthogonal_teacher, 0)
    deviation = remove_component(delivered - teacher, true_increment)
    deviation = remove_component(deviation, orthogonal_teacher)
    return teacher + deviation
