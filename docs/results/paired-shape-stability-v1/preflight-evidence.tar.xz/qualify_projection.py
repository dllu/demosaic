"""Check the repeat projection's forward and gradient invariants."""
import torch
from project_repeat import inner, reference_strength_pair

rng = torch.Generator().manual_seed(2723719)
teacher = torch.randn(4, 2, 1, 19, 21, generator=rng, dtype=torch.float64)
fixed = torch.randn(4, 1, 1, 19, 21, generator=rng, dtype=torch.float64).expand_as(teacher).clone()
scale = torch.tensor([.15, .45, 1., 1.25], dtype=torch.float64).reshape(4, 1, 1, 1, 1)
test = lambda first, second: torch.testing.assert_close(first, second, rtol=0., atol=2e-12)
test(reference_strength_pair(teacher * scale, teacher, fixed), teacher)
changed = torch.randn(teacher.shape, generator=rng, dtype=torch.float64).requires_grad_()
projected = reference_strength_pair(changed, teacher, fixed)
test(inner(projected - teacher, teacher), torch.zeros_like(scale))
test(inner(projected - teacher, fixed), torch.zeros_like(scale))
target = torch.randn(teacher.shape, generator=rng, dtype=torch.float64)
loss = ((projected[:,0]-projected[:,1]) - (target[:,0]-target[:,1])).square().mean()
(gradient,) = torch.autograd.grad(loss, changed)
test(inner(gradient, teacher), torch.zeros_like(scale))
test(inner(gradient, fixed), torch.zeros_like(scale))
assert gradient.abs().max() > 0.
empty = torch.zeros_like(teacher)
assert torch.equal(reference_strength_pair(changed, empty, empty), changed)
assert torch.isfinite(reference_strength_pair(changed, empty, fixed)).all()
test(inner(reference_strength_pair(teacher, fixed, fixed) - fixed, fixed), torch.zeros_like(scale))
test(reference_strength_pair(fixed * .5, fixed, fixed), fixed)
print("Exact reference-strength projection and gradient invariants verified.")
