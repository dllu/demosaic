"""Check exterior curvature with the original center frequency held fixed."""
from functools import partial
import time

import numpy as np

from geometry import ROOT, PRIOR, CARDINAL, DIAGONAL, phase, assess, fit, windows
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

METHODS = ("fixed-center","fixed-center-spatial")


def estimate(raw,layout,xy,frequency,noise):
    cardinal=windows(raw,layout,xy,frequency,CARDINAL)
    diagonal=windows(raw,layout,xy,frequency,DIAGONAL)
    zero=np.zeros((2,5),dtype=np.float64)
    if cardinal is None or diagonal is None:
        return {k:zero for k in METHODS},{"complete":False}
    fy,fx=(frequency/np.linalg.norm(frequency,axis=1,keepdims=True)).T
    tangent=np.stack((fx*fx,-fx*fy,fy*fy),axis=-1)
    full=cardinal+diagonal
    reverse=lambda bank:[tile[::-1]for tile in bank]
    global_folds=(full,reverse(full))
    models=(global_folds,(cardinal,reverse(diagonal)))
    reserves=(global_folds,(diagonal,reverse(cardinal)))
    admitted,checks={},{"complete":True}
    for name,parts,tests in zip(METHODS,models,reserves,strict=True):
        fits=[fit([r[0]for r in fold],zero,tangent,noise)for fold in parts]
        admitted[name],checks[name]=phase.accept(tests,zero,fits,noise)
    return admitted,checks


def sample(row,plan,diagnostic):
    source=diagnostic[row["index"]]
    assert source["input"]==row["capture"]
    frequency=np.asarray(source["exact_centers_xy"])
    truth=np.asarray(source["exact_terms"])
    x,y=plan["query_box"][:2]
    anchor=(x+48,y+48)
    with np.load(checked(row["capture"]),allow_pickle=False)as fields:
        packed,layouts=fields["packed"],fields["colors"]
    values=[]
    query_bypass=None
    for i in range(packed.shape[0]):
        for j,role in enumerate(plan["roles"]):
            sample=phase.unpack(packed[i,j])
            result,checks=estimate(sample,layouts[i,j],anchor,frequency,plan["profile"])
            if role=="present" and i==0:
                varied=sample.copy()
                varied[y:y+256,x:x+256]=-17
                fixed,verification=estimate(varied,layouts[i,j],anchor,frequency,plan["profile"])
                assert all(np.array_equal(fixed[key],value)for key,value in result.items()) and verification==checks
                query_bypass=True
            values.append({"repeat":i,"role":role,"parameters":{k:v.tolist()for k,v in result.items()},"checks":checks,
                   "phase_error":{k:assess(v,truth)for k,v in result.items()}})
    assert query_bypass
    return {"i":row["index"],"input":row["capture"],"geometry":source["geometry"],
            "query_perturbation_bit_exact":query_bypass,"rows":values}


def camera(diagnostic):
    fixtures=read_json(checked(diagnostic["camera_inputs"]))
    rows=[]
    for fixture in fixtures["inputs"].values():
        link=fixture["media"]["noisy"]
        raw,metadata=read_raw(checked(link))
        cfa=np.asarray(color_indices(metadata.pattern))
        for row in diagnostic["camera"]:
            if row["raw"]!=link:
                continue
            values={}
            for label in row["checks"]:
                result,checks=estimate(raw,cfa,row["box"][:2],np.asarray(row["frequencies_xy"]),fixtures["profiles"][label])
                values[label]={"parameters":{k:v.tolist()for k,v in result.items()},"checks":checks}
            rows.append({key:row[key]for key in ("region","box","raw","original_admission")}|{"profiles":values})
    return rows


def main():
    start=time.monotonic()
    binding=reference(ROOT/"geometry.json")
    reference_run=read_json(checked(binding))
    captures=read_json(checked(reference_run["fields"]))
    plan=read_json(checked(reference_run["plan"]))
    diagnostic=read_json(checked(reference_run["source"]))
    rows=phase.review.run(captures["rows"],partial(sample,plan=plan,diagnostic=diagnostic["exact_geometry"]))
    cameras=camera(diagnostic)
    assert len(rows)==20 and len(cameras)==6
    write_json(ROOT/"anchored.json",{"driver":reference(__file__),"variation_of":binding,"simulated":rows,
         "camera":cameras,"seconds":time.monotonic()-start,
         "scope":"Freeze center frequency where the preceding exterior variant fitted a linear shift first. Replacing every query sample leaves the estimator bit-exact for all tested sources."})


if __name__=="__main__":
    main()
