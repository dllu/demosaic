"""Replay exterior estimates and query verification at a common delivery dose."""
from functools import partial
from unittest.mock import patch
import time

import numpy as np

from geometry import ROOT, PRIOR, phase
from curve_delivery import DOSE, score, native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ARMS = ("fixed","exterior-linear","exterior-curved","spatial-curved","query-checked",
        "fixed-center","fixed-center-spatial","fixed-center-query-checked","exact-curved")
CAPTIONS = {
    "parent":"Corpus 100k EMA", "fixed":"Fixed exact center",
    "exterior-linear":"Exterior linear", "exterior-curved":"Exterior bend",
    "spatial-curved":"Checked donor locations", "query-checked":"Checked in crop",
    "fixed-center":"Bend at fixed center", "fixed-center-spatial":"Bend with held donors",
    "fixed-center-query-checked":"Fixed center, check crop", "exact-curved":"Exact curve diagnostic",
}


def check_query(raw,cfa,frequency,roi,parameters,noise):
    x,y,w,h=roi
    mosaic=phase.unpack(raw)[y:y+h,x:x+w]
    splits=[phase.make_station(mosaic,cfa,(x,y),(c,r),frequency)
            for r in phase.CENTERS for c in phase.CENTERS]
    zero=np.zeros_like(parameters)
    forward=phase.reserve_gain(splits,zero,parameters,noise)
    reverse=phase.reserve_gain([pair[::-1]for pair in splits],zero,parameters,noise)
    pass_both=np.minimum(forward,reverse)>phase.MIN_GAIN
    parameters=np.where(pass_both[:,None],parameters,zero)
    return parameters, {"gain_each_green":[forward.tolist(),reverse.tolist()],"accepted":pass_both.tolist()}


def correction(raw,parent,cfa,wb,matrix,noise,spacing,roi,dose,admitted,arms):
    with patch.object(phase,"ARMS",tuple(arms)),patch.object(phase,"measure_geometry",return_value=(arms,None)):
        return phase.correction(raw,parent,cfa,wb,matrix,noise,spacing,roi,dose,admitted)[0]


def observe(row, plan, frames, fixed_center, parent_plan, old_geometry, old_delivery, render):
    i=row["index"]
    source=plan["sources"][i]
    prototype=frames[i]
    anchored=fixed_center[i]
    frozen=old_geometry[i]
    old=old_delivery[i]
    bound=parent_plan[i]
    assert prototype["input"]==anchored["input"]==row["capture"]==frozen["input"]==old["case"]
    assert prototype["source_id"]==source["source"]["id"]==old["id"]
    assert bound["output"]==old["parent"]
    with np.load(checked(row["capture"]),allow_pickle=False)as f:
        data={k:f[k]for k in f.files}
    with np.load(checked(bound["output"]),allow_pickle=False)as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    assert w==h==256
    capture=data["packed"][..., y//2:(y+h)//2,x//2:(x+w)//2]
    truth=data["target"][...,y:y+h,x:x+w]
    spacing=np.asarray(frozen["exact_centers_xy"])
    expected=np.asarray(frozen["exact_terms"])
    noise=plan["profile"]
    predictions={"parent":parent,**{key:parent.copy()for key in ARMS}}
    receipts=[]
    for item,anchor in zip(prototype["rows"],anchored["rows"],strict=True):
        assert (item["repeat"],item["role"])==(anchor["repeat"],anchor["role"])
        i1,i2=item["repeat"],plan["roles"].index(item["role"])
        values=item["parameters"]|anchor["parameters"]
        parameters={k:np.asarray(values[k])for k in ARMS if k in values}
        cfa=data["colors"][i1,i2]
        raw=capture[i1,i2]
        accepted,checked_query=check_query(raw,cfa,spacing,phase.ROI,parameters["exterior-curved"],noise)
        accepted_fixed,checked_fixed=check_query(raw,cfa,spacing,phase.ROI,parameters["fixed-center"],noise)
        receipts.append({"repeat":i1,"role":item["role"],"verification":checked_query,"fixed_center_verification":checked_fixed})
        parameters.update(fixed=np.zeros((2,5)),**{"exact-curved":expected,"query-checked":accepted,"fixed-center-query-checked":accepted_fixed})
        values=correction(raw,parent[i1,i2],cfa,data["wb"][i1,i2],data["matrix"][i1,i2],noise,
                          spacing,phase.ROI,DOSE,True,parameters)
        for key,image in values.items():
            predictions[key][i1,i2]+=image
    scores={key:score(result,parent,truth,data)for key,result in predictions.items()}
    for k in ("parent","fixed","exact-curved"):
        assert scores[k]==old["scores"][k],(i,k)
    board=None
    if i in render:
        arrays={k:data[k][0,:1]for k in ("colors","wb","matrix")}
        arrays["packed"]=capture[0,:1]
        images=[noisy_malvar(arrays)[0],*(predictions[k][0,0]for k in CAPTIONS),truth[0,0]]
        labels=("Noisy Malvar",*CAPTIONS.values(),"Exact GT")
        board=native_board(ROOT/"exact",f'bent-{i:03d}',images,arrays,
               {"CFA":source["camera"]["pattern"],"noise":noise,"input":row["capture"],"source":source["source"],
                "source_box":source["box"],"query":plan["query_box"],"parent":bound["output"],"repeat":0,"role":"present"},
               labels=labels,exposure=2,contrast=1,triplet_indices=(0,labels.index(CAPTIONS["exterior-curved"]),len(labels)-1))
    return {"i":i,"id":old["id"],"geometry":old["geometry"],"input":row["capture"],"parent":bound["output"],
            "board":board,"checks":receipts,"metrics":scores|{"central-tangent":old["scores"]["tangent"]}}


def summarize(rows):
    rng=np.random.default_rng(21901302)
    seeds=rng.integers(len(rows),size=(10000,len(rows)))
    result={}
    for metric in rows[0]["metrics"]["parent"]:
        values={key:np.array([v["metrics"][key][metric]for v in rows])for key in rows[0]["metrics"]}
        diffs={}
        for key in values:
            if key=="fixed":
                continue
            delta=values[key]-values["fixed"]
            diffs[key]={"mean":float(delta.mean()),"interval_95":np.quantile(delta[seeds].mean(axis=1),[.025,.975]).tolist()}
        result[metric]={"mean":{key:float(v.mean())for key,v in values.items()},"difference_from_fixed":diffs}
    return result


def main():
    start=time.monotonic()
    new=reference(ROOT/"geometry.json")
    geometry=read_json(checked(new))
    anchored_ref=reference(ROOT/"anchored.json")
    anchored=read_json(checked(anchored_ref))
    series=reference(ROOT/"serial-audit.json")
    audit=read_json(checked(series))
    prior=audit["serial_result"]
    parent=read_json(checked(prior))
    assert anchored["variation_of"]==new
    assert geometry["source"]==parent["dependencies"]["diagnostic.json"]
    assert geometry["fields"]==parent["dependencies"]["fields.json"]
    archived=read_json(checked(geometry["fields"]))
    plan=read_json(checked(archived["plan"]))
    packs=read_json(checked(parent["dependencies"]["predictions-fresh.json"]))
    earliest=read_json(checked(geometry["source"]))
    assert packs["checkpoint"]==parent["checkpoint"]==plan["base"]
    (ROOT/"exact").mkdir(exist_ok=True)
    chosen=[row["i"]for row in geometry["simulated"]if row["geometry"]=="bent"][:2]
    # The delivery helper overrides a process-local diagnostic function. Run
    # serially so independent crops cannot inherit one another's geometry.
    render=partial(observe,plan=plan,frames=geometry["simulated"],fixed_center=anchored["simulated"],parent_plan=packs["rows"],
                   old_geometry=earliest["exact_geometry"],old_delivery=parent["rows"], render=chosen)
    results=[render(row)for row in archived["rows"]]
    assert len(results)==20
    write_json(ROOT/"delivery.json",{"driver":reference(__file__),"geometry":new,"anchored":anchored_ref,"prior_delivery":prior,"serial_audit":series,
              "checkpoint":packs["checkpoint"],"records":results,"summary":{
                  key:summarize([row for row in results if row["geometry"]==key])for key in ("bent","straight")},
              "dose":DOSE,"seconds":time.monotonic()-start,
              "scope":"Matched previously observed cohorts. Candidate geometry uses only exterior data. The extra query check tests the candidate against the fixed center using reciprocal green samples in the native delivery crop."})


if __name__=="__main__":
    main()
