"""Fit a shared bend using disjoint RAW windows entirely outside the delivery crop."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.with_name("bayer-shared-phase-v1")
sys.path.insert(0,str(PRIOR))
import shared_phase as phase
from diagnose import assess
from tangent import fit
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

MID = 48
OUTSIDE = (-112, MID, 208)
CARDINAL = ((OUTSIDE[0],MID),(OUTSIDE[-1],MID),(MID,OUTSIDE[0]),(MID,OUTSIDE[-1]))
DIAGONAL = tuple((x,y)for y in OUTSIDE[::2]for x in OUTSIDE[::2])
KEYS = ("exterior-linear","exterior-curved","spatial-linear","spatial-curved")


def windows(raw,layout,xy,freq,origins):
    frames=[]
    edge=phase.SIZE
    for x,y in origins:
        native=(xy[0]+x,xy[1]+y)
        lx,ly=native
        if min(lx,ly)<0 or lx+edge>raw.shape[1] or ly+edge>raw.shape[0]:
            return None
        angle,polynomial=phase.coords(x,y,freq)
        crop=raw[ly:ly+edge,lx:lx+edge]
        offsets=phase.planes(layout,(*native,edge))
        frames.append(tuple((phase.clip_samples(crop,p).astype(np.float64),
              phase.clip_samples(phase.TONE,p),phase.clip_samples(angle,p),
              phase.clip_samples(polynomial,p))for p in offsets))
    return frames


def geometry(raw, cfa, xy, frequency, noise):
    cardinal=windows(raw,cfa,xy,frequency,CARDINAL)
    diagonal=windows(raw,cfa,xy,frequency,DIAGONAL)
    zero=np.zeros((2,5))
    if cardinal is None or diagonal is None:
        return {a:zero for a in KEYS},{"complete":False}
    fy,fx=(frequency/np.linalg.norm(frequency,axis=1,keepdims=True)).T
    tangent=np.stack((fx*fx,-fx*fy,fy*fy),axis=-1)
    frames=(cardinal+diagonal)
    all_folds=frames,[tile[::-1]for tile in frames]
    # For the spatial check each fit predicts an untrained Bayer plane at
    # donor locations outside its fitting set. Only per-tile amplitudes and
    # tone are fitted there, using the opposite green from the scored sites.
    spatial_fit=(cardinal,[tile[::-1]for tile in diagonal])
    spatial_test=(diagonal,[tile[::-1]for tile in cardinal])
    result={}
    notes={"complete":True}
    for name, fit_folds, test_folds in (
        ("exterior",all_folds,all_folds),("spatial",spatial_fit,spatial_test)
    ):
        fit_halves=[[tile[0]for tile in fold]for fold in fit_folds]
        linear=[phase.optimize(split,zero,2,noise)for split in fit_halves]
        shared,linear_note=phase.accept(test_folds,zero,linear,noise)
        curved=[fit(split,start,tangent,noise)for split,start in zip(fit_halves,linear,strict=True)]
        final,curve_note=phase.accept(test_folds,shared,curved,noise,references=linear)
        result[name+"-linear"]=shared
        result[name+"-curved"]=final
        notes[name]={"recenter":linear_note,"curvature":curve_note}
    return result,notes


def simulated(row,plan,first):
    material=first[row["index"]]
    assert material["input"]==row["capture"]
    bound=plan["sources"][row["index"]]
    assert bound["source"]["id"]==material["source_id"]
    frequency=np.asarray(material["exact_centers_xy"])
    truth=np.asarray(material["exact_terms"])
    x,y=plan["query_box"][:2]
    anchor=(x+48,y+48)
    with np.load(checked(row["capture"]),allow_pickle=False)as fields:
        packed,layouts=fields["packed"],fields["colors"]
    numbers=[]
    for repeat in range(len(packed)):
        for k,role in enumerate(plan["roles"]):
            sample=phase.unpack(packed[repeat,k])
            fit,checks=geometry(sample,layouts[repeat,k],anchor,frequency,plan["profile"])
            assert checks["complete"]
            numbers.append({"repeat":repeat,"role":role,"checks":checks,
                   "parameters":{a:v.tolist()for a,v in fit.items()},
                   "phase_error":{a:assess(v,truth)for a,v in fit.items()}})
    return {"i":row["index"],"source_id":material["source_id"],"input":row["capture"],
            "geometry":material["geometry"],"rows":numbers}


def camera(diagnostic):
    fixtures=read_json(checked(diagnostic["camera_inputs"]))
    rows=[]
    for archives in fixtures["inputs"].values():
        source=archives["media"]["noisy"]
        sensor,metadata=read_raw(checked(source))
        cfa=np.array(color_indices(metadata.pattern))
        for pic in diagnostic["camera"]:
            if pic["raw"]!=source:
                continue
            anchor=pic["box"][:2]
            frequency=np.asarray(pic["frequencies_xy"])
            profiles={}
            for key in pic["checks"]:
                values,audit=geometry(sensor,cfa,anchor,frequency,fixtures["profiles"][key])
                profiles[key]={"parameters":{a:v.tolist()for a,v in values.items()},
                               "checks":audit}
            rows.append({"region":pic["region"],"box":pic["box"],"raw":pic["raw"],
                         "original_admission":pic["original_admission"],"profiles":profiles})
    return rows


def main():
    start=time.monotonic()
    source=reference(PRIOR/"diagnostic.json")
    diagnostic=read_json(checked(source))
    field=read_json(checked(diagnostic["exact_source"]))
    plan=read_json(checked(field["plan"]))
    known=diagnostic["exact_geometry"]
    rows=phase.review.run(field["rows"],partial(simulated,plan=plan,first=known))
    assert len(rows)==20
    cameras=camera(diagnostic)
    assert len(cameras)==6
    write_json(ROOT/"geometry.json",{"driver":reference(__file__),"source":source,
         "fields":diagnostic["exact_source"],"plan":field["plan"],"donor_origin_offsets":{"cardinal":CARDINAL,"diagonal":DIAGONAL},
         "simulated":rows,"camera":cameras,"seconds":time.monotonic()-start,
         "scope":"Exact generator center frequencies in simulated geometry audit only. Standing candidates inherit noisy exterior nomination. No query samples enter estimator."})


if __name__=="__main__":
    main()
