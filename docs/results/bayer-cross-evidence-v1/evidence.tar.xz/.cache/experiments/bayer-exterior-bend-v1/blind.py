"""Estimate center frequency and bend together from noisy exterior Bayer data."""
from functools import partial
import time

import numpy as np

from anchored import estimate as fixed_center
from delivery import correction, check_query
from geometry import ROOT, PRIOR, CARDINAL, DIAGONAL, phase, windows, assess
from curve_delivery import score, DOSE
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

MODES = ("fixed","anchored","joint","joint-checked")


def family_axes(frequency):
    fy,fx=(frequency/np.linalg.norm(frequency,axis=1,keepdims=True)).T
    basis=np.zeros((2,5,3))
    basis[:,0,0]=basis[:,1,1]=1
    basis[:,2:,2]=np.stack((fx*fx,-fx*fy,fy*fy),axis=-1)
    return basis


def projected_step(stations, weights, basis, noise):
    arrays,targets=[],[]
    for item in stations:
        design,gram,coeff,residual,wave=phase.estimate(item,weights)
        delta=2*np.pi*(-wave[:,2:]*coeff[-4:-2]+wave[:,:2]*coeff[-2:])
        local=np.einsum("ni,fij->nfj",item[3],basis)
        jacobian=(delta[...,None]*local).reshape(len(delta),6)
        jacobian-=design@np.linalg.solve(gram,design.T@jacobian)
        unit=np.sqrt(phase.variance(item[0],noise))
        arrays.append(jacobian/unit)
        targets.append(residual/unit)
    J,y=np.concatenate(arrays),np.concatenate(targets)
    normal=J.T@J
    move=np.linalg.solve(normal+np.diag(.1*np.diag(normal)+.01),J.T@y)
    return move.reshape(2,3),float(y@y)


def minimize(stations, basis, noise):
    parameters=np.zeros((2,3))
    weights=np.zeros((2,5))
    for _ in range(7):
        step,error=projected_step(stations,weights,basis,noise)
        if np.max(abs(step))<.0005:
            break
        for fraction in (1.,.5,.25):
            candidate=np.clip(parameters+fraction*np.clip(step,-.15,.15),-.35,.35)
            state=np.einsum("fik,fk->fi",basis,candidate)
            loss=sum(np.square(phase.estimate(item,state)[3]).sum()/phase.variance(item[0],noise)for item in stations)
            if loss<error:
                weights,parameters=state,candidate
                break
        else:
            break
    return weights


def measure(raw,cfa,xy,frequency,noise):
    stations=windows(raw,cfa,xy,frequency,CARDINAL+DIAGONAL)
    if stations is None:
        return np.zeros((2,5)),{"complete":False}
    banks=(stations,[tile[::-1]for tile in stations])
    basis=family_axes(frequency)
    fits=[minimize([item[0]for item in bank],basis,noise)for bank in banks]
    result,verification=phase.accept(banks,np.zeros((2,5)),fits,noise)
    return result,{"complete":True,"verification":verification}


def candidate_parameters(raw, crop, cfa, xy, spacing, placement, noise, admitted):
    output={k:np.zeros((2,5))for k in MODES}
    if not admitted:
        return output,None
    bends,_=fixed_center(raw,cfa,xy,spacing,noise)
    joint,checks=measure(raw,cfa,xy,spacing,noise)
    confirmed,check=check_query(crop,cfa,spacing,placement,joint,noise)
    output.update(anchored=bends["fixed-center"],joint=joint,**{"joint-checked":confirmed})
    return output,{"exterior":checks,"query":check}


def sample(row,plan,reference_shape,previous):
    index=row["index"]
    saved=reference_shape[index]
    parent_ref=previous[index]["output"]
    assert saved["input"]==row["capture"]
    with np.load(checked(row["capture"]),allow_pickle=False)as data:
        captured={k:data[k]for k in data.files}
    with np.load(checked(parent_ref),allow_pickle=False)as data:
        parent=data["baseline"]
    x,y,w,h=plan["query_box"]
    q=(x,y,w,h)
    raw_slices=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    roi=phase.ROI
    xy=(x+roi[0],y+roi[1])
    noise=plan["profile"]
    truth=captured["target"][...,y:y+h,x:x+w]
    estimates={"parent":parent,**{k:parent.copy()for k in MODES}}
    first=np.asarray(saved["exact_centers_xy"])
    second=np.asarray(saved["exact_terms"])
    order=np.argsort(-first[:,1])
    # The noisy nomination estimates one direction in each of the two half-planes.
    supported=bool(np.prod(first[:,1])<0)
    rows=[]
    for a in range(2):
        for b,role in enumerate(plan["roles"]):
            packed=captured["packed"][a,b]
            tile=packed[raw_slices]
            native=phase.unpack(packed)
            cfa=captured["colors"][a,b]
            spacing,admitted,nomination=phase.geometry(packed,cfa,q,roi)
            arms,checks=candidate_parameters(native,tile,cfa,xy,spacing,roi,noise,admitted)
            additions=correction(tile,parent[a,b],cfa,captured["wb"][a,b],captured["matrix"][a,b],
                                 noise,spacing,roi,DOSE,admitted,arms)
            for k,v in additions.items():
                estimates[k][a,b]+=v
            row_scores={}
            if supported:
                exact=second[order].copy()
                exact[:,:2]=(first[order]-spacing)*64
                for k,value in arms.items():
                    row_scores[k]=assess(value,exact)
            rows.append({"draw":a,"role":role,"nomination":nomination,"checks":checks,
                         "accepted_terms":{k:a.tolist()for k,a in arms.items()},
                         "sector_specific_phase_error":row_scores,
                         "sector_specific_known_spacing_error":np.linalg.norm(first[order]-spacing,axis=1).tolist()
                            if supported else None})
    return {"i":index,"id":saved["source_id"],"geometry":saved["geometry"],"input":row["capture"],
            "parent":parent_ref,"rows":rows,"metrics":{k:score(out,parent,truth,captured)for k,out in estimates.items()}}


def camera(diagnostic):
    plots=read_json(checked(diagnostic["camera_inputs"]))
    output=[]
    for group in plots["inputs"].values():
        path=group["media"]["noisy"]
        full,metadata=read_raw(checked(path))
        cfa=np.asarray(color_indices(metadata.pattern))
        for row in diagnostic["camera"]:
            if row["raw"]!=path:
                continue
            fits={}
            for p in row["checks"]:
                answer,verdict=measure(full,cfa,row["box"][:2],np.asarray(row["frequencies_xy"]),plots["profiles"][p])
                fits[p]={"parameters":answer.tolist(),"check":verdict}
            output.append({k:row[k]for k in ("region","box","raw","original_admission")}|{"profiles":fits})
    return output


def main():
    from delivery import summarize
    start=time.monotonic()
    past_ref=reference(ROOT/"delivery.json")
    past=read_json(checked(past_ref))
    bound=read_json(checked(past["geometry"]))
    witness=read_json(checked(bound["source"]))
    data=read_json(checked(bound["fields"]))
    plan=read_json(checked(bound["plan"]))
    corrected=read_json(checked(past["prior_delivery"]))
    previous=read_json(checked(corrected["dependencies"]["predictions-fresh.json"]))
    assert previous["checkpoint"]==past["checkpoint"]==plan["base"]
    run=partial(sample,plan=plan,reference_shape=witness["exact_geometry"],previous=previous["rows"])
    records=[run(row)for row in data["rows"]]
    output=camera(witness)
    assert len(records)==20 and len(output)==6
    write_json(ROOT/"blind.json",{"driver":reference(__file__),"prior":past_ref,"checkpoint":plan["base"],
         "rows":records,"camera":output,"seconds":time.monotonic()-start,
         "summary":{key:summarize([r for r in records if r["geometry"]==key])for key in ("bent","straight")},
         "scope":"Same 20 previously observed backgrounds. No supplied truth enters the active path. The fixed, fixed-center bend, joint fit and query-confirmed joint fit use the same original noisy-only multiscale admission."})


if __name__=="__main__":
    main()
