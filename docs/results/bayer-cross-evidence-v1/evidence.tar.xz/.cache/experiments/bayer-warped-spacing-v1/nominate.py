"""Align power from disjoint Bayer tiles to the center frequency of a curved wave."""
from functools import lru_cache, partial
from pathlib import Path
import sys
import time

import numpy as np
from scipy.ndimage import map_coordinates, uniform_filter

ROOT=Path(__file__).resolve().parent
EXTERIOR=ROOT.with_name("bayer-exterior-bend-v1")
sys.path.insert(0,str(EXTERIOR))
from geometry import CARDINAL, DIAGONAL, phase
from carrier_scale import PAD, FX, FY, RADIAL, spectrum
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw

ORIGINS=CARDINAL+DIAGONAL
CURVATURES=np.array([0.,2.5e-5,-2.5e-5,5.e-5,-5.e-5,7.5e-5,-7.5e-5])
BAND=(RADIAL>=.077)&(RADIAL<=.195)&(FX>0)&(np.abs(FY)>=.26*FX)&(np.abs(FY)<=3.8*FX)
FYX=np.column_stack((FY[BAND],FX[BAND]))
FREQ=FYX[:,::-1]
SECTOR=(FREQ[:,1]>0,FREQ[:,1]<0)
MIN_RECIPROCAL_GAIN=12.
MIN_SUPPORTING_TILES=3
AGREE_RADIUS=.009
AGREE_PHASE=.18


@lru_cache(maxsize=1)
def positions():
    # For phi=f0.x + k(t.x)^2/2, grad phi at tile offset d is
    # f0 + k t(t.d). Terms are in native cycles/pixel and native pixels.
    direction=FREQ/np.linalg.norm(FREQ,axis=1,keepdims=True)
    tangent=np.column_stack((-direction[:,1],direction[:,0]))
    stations=np.asarray(ORIGINS,dtype=np.float64)+31.5-79.5
    shift=(stations@tangent.T)[...,None]*tangent[None]
    grid=(FREQ+CURVATURES[:,None,None,None]*shift[None])[...,::-1]*2*PAD
    return np.moveaxis(grid,-1,0)


def tile_spectra(raw,layout,xy,noise):
    sequence=[]
    for tx,ty in ORIGINS:
        x,y=xy[0]+tx,xy[1]+ty
        block=raw[y:y+phase.SIZE,x:x+phase.SIZE] if min(x,y)>=0 else np.empty((0,0))
        if block.shape!=(phase.SIZE,phase.SIZE):
            return None
        sample=np.array(spectrum(block,phase.planes(layout,(x,y,phase.SIZE))))
        power=(sample.real**2+sample.imag**2)/phase.variance(block,noise)
        # The local noise-relative floor limits votes from broad spectral leakage.
        floor=np.maximum(1.,uniform_filter(power,size=(1,13,13),mode="wrap"))
        sequence.append(np.log1p(np.maximum(0.,power/floor-1)).clip(max=4))
    return np.stack(sequence,axis=1)


def independently_choose(tiles, correct_bend):
    coordinate=positions()
    count=len(CURVATURES) if correct_bend else 1
    trailed=np.stack([map_coordinates(power,coordinate[:,:count,i],order=1,mode="grid-wrap",prefilter=False)
                      for i,power in enumerate(tiles)],axis=1)
    score=trailed.sum(1) - .05 * (abs(CURVATURES[:count])/2.5e-5)[:,None]
    pair=[]
    for sector in SECTOR:
        tier,index=np.unravel_index(np.where(sector,score,-np.inf).argmax(),score.shape)
        pair.append((*FREQ[index],CURVATURES[tier],score[tier,index]))
    return np.array(pair,dtype=np.float64)


def tangent_terms(nominal):
    f=nominal[:,:2]
    u=np.column_stack((-f[:,1],f[:,0]))/np.linalg.norm(f,axis=1,keepdims=True)
    out=np.zeros((len(f),5))
    out[:,2:]=nominal[:,2:3]*64**2*np.column_stack((u[:,0]**2,u.prod(1),u[:,1]**2))
    return out


def held_gain(windows,terms,noise):
    measured=[]
    for first,held in windows:
        full,R,c,_,_=phase.estimate(first,terms)
        raw,tone,start,shape=held
        V=np.concatenate((tone,phase.wave(start,shape,terms)),axis=-1)
        err=raw-V@c
        destination=full.T@first[0]
        follow=[]
        for family in range(2):
            index=np.ones(len(c),dtype=bool)
            index[len(c)-4+family::2]=False
            lower=np.linalg.solve(R[index][:,index],destination[index])
            base=raw-V[:,index]@lower
            follow.append(float((base@base-err@err)/phase.variance(first[0],noise)))
        measured.append(follow)
    return np.array(measured)


def nominal_geometry(raw,cfa,xy,noise):
    from geometry import windows
    spectrum=tile_spectra(raw,cfa,xy,noise)
    if spectrum is None:
        return None
    records={}
    for mode,correct_bend in (("local-flat",False),("local-warped",True)):
        proposals=np.stack([independently_choose(tile,correct_bend)for tile in spectrum])
        fits=[tangent_terms(p)for p in proposals]
        measured=[]
        for i,f in enumerate(proposals[:,:,:2]):
            stations=windows(raw,cfa,xy,f,ORIGINS)
            if i==1:
                stations=[r[::-1]for r in stations]
            measured.append(held_gain(stations,fits[i],noise))
        gains=np.stack(measured)
        agree=np.linalg.norm(proposals[0,:,:2]-proposals[1,:,:2],axis=-1)
        difference=(fits[0]-fits[1]).copy()
        difference[:,:2]=(proposals[0,:,:2]-proposals[1,:,:2])*64
        errors=[]
        for y in phase.CENTERS:
            for x in phase.CENTERS:
                _,polynomial=phase.coords(x,y,np.zeros((2,2)))
                errors.append(np.ptp(polynomial@difference.T,axis=(0,1)))
        extent=np.max(errors,axis=0)
        # Every sensing fold independently supports each direction. The two
        # folds are evaluated separately before fitting any combined phase.
        valid=(gains.sum(1).min(0)>MIN_RECIPROCAL_GAIN)&(
              (gains>0).sum(1).min(0)>=MIN_SUPPORTING_TILES)&(agree<AGREE_RADIUS)&(extent<AGREE_PHASE)
        seed=proposals[:,:,:3].mean(0)
        records[mode]={"independent_proposals":proposals.tolist(),"seed":seed.tolist(),
                       "reserve_tiles":gains.tolist(),"consensus_radius":agree.tolist(),
                       "phase_disagreement":extent.tolist(),"families_pass":valid.tolist(),"admitted":bool(valid.all())}
    return records


def synthetic(item,plan,old,known):
    i=item["index"]
    previous=old[i]
    exact=known[i]
    assert item["capture"]==previous["input"]==exact["input"]
    truth=np.asarray(exact["exact_centers_xy"])
    truth=truth[np.argsort(-truth[:,1])]
    supported=bool(np.prod(truth[:,1])<0)
    qx,qy=plan["query_box"][:2]
    xy=(qx+48,qy+48)
    with np.load(checked(item["capture"]),allow_pickle=False)as raw:
        capture,colors=raw["packed"],raw["colors"]
    result=[]
    for prior in previous["rows"]:
        repeat,role=prior["draw"],prior["role"]
        number=plan["roles"].index(role)
        native=phase.unpack(capture[repeat,number])
        observed=nominal_geometry(native,colors[repeat,number],xy,plan["profile"])
        assert observed is not None
        for arm,row in observed.items():
            freq=np.array(row["seed"])[:,:2]
            row["exact_distance"]=np.linalg.norm(freq-truth,axis=1).tolist()if supported else None
        result.append({"repeat":repeat,"role":role,"formerly":prior["nomination"],"previous_exact_distance":prior["sector_specific_known_spacing_error"],
                       "selected":observed})
    return {"i":i,"source_id":previous["id"],"geometry":previous["geometry"],"input":item["capture"],"rows":result}


def camera(diagnostic):
    study=read_json(checked(diagnostic["camera_inputs"]))
    results=[]
    for scene in study["inputs"].values():
        source=scene["media"]["noisy"]
        raw,meta=read_raw(checked(source))
        cfa=np.asarray(color_indices(meta.pattern))
        for r in diagnostic["camera"]:
            if r["raw"]!=source:
                continue
            chosen={p:nominal_geometry(raw,cfa,r["box"][:2],study["profiles"][p])for p in r["checks"]}
            results.append({k:r[k]for k in ("region","box","raw","original_admission","frequencies_xy")}|{"profiles":chosen})
    return results


def main():
    started=time.monotonic()
    source=reference(EXTERIOR/"blind.json")
    earlier=read_json(checked(source))
    delivery=read_json(checked(earlier["prior"]))
    geometry=read_json(checked(delivery["geometry"]))
    panel=read_json(checked(geometry["fields"]))
    plan=read_json(checked(geometry["plan"]))
    diagnostic=read_json(checked(geometry["source"]))
    positions()
    run=partial(synthetic,plan=plan,old=earlier["rows"],known=diagnostic["exact_geometry"])
    rows=phase.review.run(panel["rows"],run)
    views=camera(diagnostic)
    assert len(rows)==20 and len(views)==6
    write_json(ROOT/"nomination.json",{"driver":reference(__file__),"previous":source,"plan":geometry["plan"],"input_rows":geometry["fields"],
              "operator_reference":reference(EXTERIOR/"geometry.py"),"rows":rows,"camera":views,"seconds":time.monotonic()-started,
              "scope":"Previously observed 20 synthetic sources for nomination failure analysis. Top one seed per oblique sector on each green lattice, then fixed cross-green support."})


if __name__=="__main__":
    main()
