"""Verify the fallback on both fixed camera scenes with prior crop RGB replay."""
from importlib.util import spec_from_file_location,module_from_spec
from unittest.mock import patch

import numpy as np

from nominate import ROOT, EXTERIOR, phase
import render_phase as preceding
from demosaic.experiments.artifacts import checked, read_json, reference

spec=spec_from_file_location("standing_warped_delivery",ROOT/"delivery.py")
deploy=module_from_spec(spec)
spec.loader.exec_module(deploy)

CAPTIONS={
  "Bayer-gated":"Bayer-gated refit","distant":"Distant Bayer gate","fixed":"64-pixel carrier fit",
  "previous":"Prior joint crop check","flat-fallback":"Flat donor fallback",
  "warped-fallback":"Warped donor fallback","warped-query":"Warped, check query",
}


def render(raw,cfa,wb,matrix,noise,box,surround,parent,policy,roi=None):
    (models,dose),geometry,nomination=policy
    assert dose==deploy.DOSE
    roi=phase.ROI if roi is None else tuple(roi)
    x,y,w,_=roi
    key=(box[0]+x,box[1]+y,w)
    profile="nominal" if abs(noise["shot"]-.00128)<1e-12 else "transferred"
    frequency,admitted,_=phase.select(surround,cfa,box,roi)
    proof=nomination[key]
    np.testing.assert_allclose(frequency,proof["frequencies_xy"],rtol=0,atol=1e-12)
    assert proof["original_admission"]==admitted==geometry[key]["original_admission"]
    selection=proof["profiles"][profile]
    assert not any(row["admitted"]for row in selection.values())
    donor=phase.review.exterior(surround,cfa,noise,box)
    core=phase.compose(raw,cfa,wb,matrix,noise,box,donor,parent,models,False)
    baseline=core["distant"]
    imposed=np.asarray(geometry[key]["profiles"][profile]["parameters"])
    confirmed=deploy.bends.check_query(raw,cfa,frequency,roi,imposed,noise)[0] if admitted else imposed
    # The new nominations all fail their exterior check. Each fallback
    # resolves to the already admitted prior fit at the registered crop.
    # The cab views have an odd y offset within the packed query.
    fixed=deploy.bends.correction(raw,baseline,cfa,wb,matrix,noise,frequency,roi,dose,admitted,
                                  {"fixed":np.zeros((2,5)),"previous":confirmed})
    retained=fixed["previous"]
    additions={name:retained for name in ("flat-fallback","warped-fallback","warped-query")}
    rendered=core|{k:baseline+value for k,value in (fixed|additions).items()}
    for name in ("flat-fallback","warped-fallback","warped-query"):
        np.testing.assert_array_equal(rendered[name],rendered["previous"])
    return {k:rendered[k]for k in CAPTIONS}


def main():
    learned,receipt=preceding.setup()
    marked=reference(ROOT/"nomination.json")
    proposals=read_json(checked(marked))
    before=read_json(checked(proposals["previous"]))
    def by_box(entries):
        return {tuple(r["box"]):r for r in entries}
    policy=learned,by_box(before["camera"]),by_box(proposals["camera"])
    registered=ROOT/"standing-bound"
    registered.mkdir(exist_ok=True)
    with patch.object(preceding,"ROOT",registered),patch.object(preceding,"CAPTIONS",CAPTIONS),patch.object(preceding,"render_models",render):
        preceding.standing(policy,receipt|{"driver":reference(__file__),"nominations":marked,"previous":proposals["previous"]},None)


if __name__=="__main__":
    main()
