"""Replay frozen spacing and delivery on a separate 16-photo archived cohort."""
from functools import partial
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
import time

import numpy as np

from nominate import ROOT, EXTERIOR, phase, synthetic
from diagnose import known_geometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def module(name,path):
    spec=spec_from_file_location(name,path)
    loaded=module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def main():
    start=time.monotonic()
    deliver=module("warped_replay_delivery",ROOT/"delivery.py")
    former=module("warped_replay_baseline",EXTERIOR/"blind.py")
    source=ROOT.with_name("query-frequency-consensus-v1")
    capture_ref=reference(source/"fields.json")
    capture=read_json(checked(capture_ref))
    plan=read_json(checked(capture["plan"]))
    prediction=reference(source/"predictions-fresh.json")
    archived=read_json(checked(prediction))
    seeds=read_json(checked(archived["nominations"]))
    trials_ref=reference(ROOT/"delivery.json")
    prior=read_json(checked(trials_ref))
    assert prior["driver"]==reference(ROOT/"delivery.py")
    assert read_json(checked(prior["nominations"]))["driver"]==reference(ROOT/"nominate.py")
    assert archived["checkpoint"]==prior["checkpoint"]==plan["base"] and seeds["upstream"]==capture_ref
    assert len(capture["rows"])==len(archived["rows"])==len(seeds["rows"])==len(plan["sources"])==16
    excluded={r["source"]for r in prior["records"]}
    current=[]
    for i,(p,r,b,d) in enumerate(zip(plan["sources"],capture["rows"],archived["rows"],seeds["rows"],strict=True)):
        assert r["index"]==b["index"]==p["index"]==d["index"]==i and r["capture"]==d["capture"]
        sid=p["source"]["id"]
        assert sid not in excluded
        excluded.add(sid)
        g,k=known_geometry(p["layout"])
        current.append({"input":r["capture"],"source_id":sid,"exact_centers_xy":g.tolist(),"exact_terms":k.tolist(),
                        "geometry":"bent"if np.any(k)else "straight"})
    saved=[former.sample(row,plan,current,archived["rows"]) for row in capture["rows"]]
    matched=phase.review.run(capture["rows"],partial(synthetic,plan=plan,old=saved,known=current))
    examples={}
    for row in matched:
        if row["geometry"]!="bent":
            continue
        for proof in row["rows"]:
            if proof["role"]=="present" and proof["selected"]["local-warped"]["admitted"] and not proof["formerly"]["admitted"]:
                examples[row["i"]]=proof["repeat"]
                break
        if len(examples)==2:
            break
    directory=ROOT/"replication"
    directory.mkdir(exist_ok=True)
    result=[deliver.observe(row,plan,saved,archived["rows"],directory,examples.get(row["i"]))for row in matched]
    write_json(ROOT/"replication.json",{"driver":reference(__file__),"checkpoint":plan["base"],"nomination":reference(ROOT/"nominate.py"),
           "delivery":reference(ROOT/"delivery.py"),"prior":trials_ref,"predictions":prediction,"capture":capture_ref,"plan":capture["plan"],
           "examples":examples,"nominations":matched,"baseline":saved,"records":result,
           "summary":{g:deliver.summary([r for r in result if r["shape"]==g])for g in ("bent","straight")},
           "seconds":time.monotonic()-start,
           "scope":"Independent source panel for the fixed algorithm. It reuses earlier synthetic observations and exact controls. None of these sources occurs in the 20-photo investigation."})


if __name__=="__main__":
    main()
