"""Deliver the registered new spacing hypotheses where the previous fit abstains."""
from pathlib import Path
import sys
import time

import numpy as np

from nominate import ROOT, EXTERIOR, phase, held_gain, tangent_terms
from geometry import windows
from curve_delivery import score, luma, CORE, DOSE, native_board
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

# Both experiment roots have a delivery.py. Import the previously executed
# helper by file identity so the renderer receives the matched operator.
from importlib.util import module_from_spec,spec_from_file_location
implementation=spec_from_file_location("exterior_bend_delivery",EXTERIOR/"delivery.py")
bends=module_from_spec(implementation)
implementation.loader.exec_module(bends)

ARMS=("parent","previous","flat-fallback","warped-fallback","warped-query")
CAPTIONS={
    "parent":"Corpus 100k EMA","previous":"Previous joint fit",
    "flat-fallback":"Flat donor fallback","warped-fallback":"Warped donor fallback","warped-query":"Warped, check query",
}


def query_check(tile,layout,roi,frequency,shape,noise):
    mosaic=phase.unpack(tile)
    origins=[(x,y)for y in phase.CENTERS for x in phase.CENTERS]
    samples=windows(mosaic,layout,roi[:2],frequency,origins)
    if samples is None:
        return False,None
    support=np.stack([held_gain(samples,shape,noise),held_gain([p[::-1]for p in samples],shape,noise)])
    accept=bool((support.sum(1)>12.).all() and ((support>0).sum(1)>=2).all())
    return accept,support.tolist()


def added(tile,parent,cfa,wb,matrix,noise,selection,prior):
    arguments=(tile,parent,cfa,wb,matrix,noise)
    roi=phase.ROI
    fallback={k:np.zeros_like(parent)for k in ARMS[1:]}
    if prior["nomination"]["admitted"]:
        held=np.asarray(prior["nomination"]["frequencies_xy"])
        old=np.asarray(prior["accepted_terms"]["joint-checked"])
        output=bends.correction(*arguments,held,roi,DOSE,True,{"locked":old})["locked"]
        return {k:output for k in fallback},None
    receipt={}
    for arm,source in (("flat-fallback","local-flat"),("warped-fallback","local-warped")):
        chosen=selection[source]
        if not chosen["admitted"]:
            continue
        seed=np.asarray(chosen["seed"])
        frequency=seed[:,:2]
        shape=tangent_terms(seed)
        admitted,marks=query_check(tile,cfa,roi,frequency,shape,noise)
        delivered=bends.correction(*arguments,frequency,roi,DOSE,True,{"candidate":shape})["candidate"]
        receipt[arm]={"query_support":marks,"query_pass":admitted,
                      "applied_RMS_DN16":float(np.sqrt(np.mean(delivered.astype(float)**2))*65535)}
        fallback[arm]=delivered
        if arm=="warped-fallback" and admitted:
            fallback["warped-query"]=delivered
    return fallback,receipt


def totals(output,old,target,captured):
    value=score(output,old,target,captured)
    projected=luma(output-old,captured)
    nominal=captured["weak_linear_nominal"][CORE]
    ref=np.linalg.norm(nominal)
    for index,name in ((1,"outside_only"),(2,"strong_only"),(3,"exact_flat")):
        raw=projected[:,index]
        aligned=(raw*nominal[None]).sum(axis=(-2,-1))
        value[name+"_coherent_added_DN16"]=float(np.mean(np.abs(aligned)*65535/ref/np.sqrt(nominal.size)))
        value[name+"_added_RMS_DN16"]=float(np.mean(np.sqrt(np.mean(raw**2,axis=(1,2))))*65535)
    return value


def observe(case,plan,previous,parent_archive,folder,select=None):
    i=case["i"]
    before=previous[i]
    source=plan["sources"][i]
    output=parent_archive[i]["output"]
    assert before["input"]==case["input"] and before["parent"]==output
    with np.load(checked(case["input"]),allow_pickle=False)as f:
        raw={key:f[key]for key in f.files}
    with np.load(checked(output),allow_pickle=False)as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    crop=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
    target=raw["target"][...,y:y+h,x:x+w]
    noise=plan["profile"]
    prediction={label:parent.copy()for label in ARMS}
    records=[]
    for material,history in zip(case["rows"],before["rows"],strict=True):
        a,role=material["repeat"],material["role"]
        assert (a,role)==(history["draw"],history["role"]) and material["formerly"]==history["nomination"]
        b=plan["roles"].index(role)
        arguments=tuple(raw[k][a,b]for k in ("colors","wb","matrix"))
        updates,notes=added(crop[a,b],parent[a,b],*arguments,noise,material["selected"],history)
        for label,delta in updates.items():
            prediction[label][a,b]+=delta
        records.append({"repeat":a,"role":role,"fallback":notes})
    metrics={key:totals(image,parent,target,raw)for key,image in prediction.items()}
    for k,v in before["metrics"]["joint-checked"].items():
        assert abs(metrics["previous"][k]-v)<1e-9,(i,k,metrics["previous"][k],v)
    illustration=None
    if select is not None:
        a=select
        arrays={k:raw[k][a,:1]for k in ("colors","wb","matrix")}|{"packed":crop[a,:1]}
        cols=[noisy_malvar(arrays)[0],*(prediction[k][a,0]for k in ARMS),target[a,0]]
        labels=("Noisy Malvar",*(CAPTIONS[a]for a in ARMS),"Exact GT")
        illustration=native_board(folder,f'bent-{i:03d}',cols,arrays,
                {"CFA":source["camera"]["pattern"],"noise":noise,"input":case["input"],"source":source["source"],
                 "source_box":source["box"],"query":plan["query_box"],"parent":output,"repeat":a,"role":"present"},
                labels=labels,exposure=2,contrast=1,triplet_indices=(0,labels.index(CAPTIONS["warped-fallback"]),len(labels)-1))
    return {"i":i,"source":case["source_id"],"shape":case["geometry"],"input":case["input"],"parent":output,
            "native":illustration,"review_records":records,"metrics":metrics}


def summary(rows):
    rng=np.random.default_rng(261111916)
    selections=rng.integers(len(rows),size=(10000,len(rows)))
    changes=(("flat-fallback","previous"),("warped-fallback","previous"),("warped-query","previous"),
             ("warped-fallback","flat-fallback"),("warped-query","warped-fallback"))
    result={}
    for key in rows[0]["metrics"]["previous"]:
        scores={label:np.asarray([r["metrics"][label][key]for r in rows])for label in ARMS}
        delta={}
        for a,b in changes:
            values=scores[a]-scores[b]
            delta[f'{a}_vs_{b}']={"mean":float(values.mean()),"interval_95":np.quantile(values[selections].mean(1),[.025,.975]).tolist()}
        result[key]={"mean":{k:float(y.mean())for k,y in scores.items()},"delta":delta}
    return result


def main():
    start=time.monotonic()
    marker=reference(ROOT/"nomination.json")
    detail=read_json(checked(marker))
    blind=read_json(checked(detail["previous"]))
    former=read_json(checked(blind["prior"]))
    earlier=read_json(checked(former["prior_delivery"]))
    models=read_json(checked(earlier["dependencies"]["predictions-fresh.json"]))
    shape=read_json(checked(detail["plan"]))
    assert models["checkpoint"]==blind["checkpoint"]==shape["base"]
    output=ROOT/"exact"
    output.mkdir(exist_ok=True)
    examples={}
    for row in detail["rows"]:
        if row["geometry"]!="bent":
            continue
        for trial in row["rows"]:
            if trial["role"]=="present" and not trial["formerly"]["admitted"] and trial["selected"]["local-warped"]["admitted"]:
                examples[row["i"]]=trial["repeat"]
                break
        if len(examples)==2:
            break
    assert len(examples)==2
    rows=[observe(row,shape,blind["rows"],models["rows"],output,examples.get(row["i"]))for row in detail["rows"]]
    write_json(ROOT/"delivery.json",{"driver":reference(__file__),"nominations":marker,
            "checkpoint":models["checkpoint"],"examples":examples,"records":rows,
            "summary":{g:summary([r for r in rows if r["shape"]==g])for g in ("bent","straight")},
            "seconds":time.monotonic()-start,
            "scope":"Test-only fallbacks on the previously viewed 20-photo diagnostic. Prior certified pairs and their exact geometry retain the previous joint checked result."})


if __name__=="__main__":
    main()
