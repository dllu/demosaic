"""Replay coefficient cross-evidence at the same crop and delivery strength."""
import time

import numpy as np

from evidence import ROOT, PREVIOUS, phase, old, tangent_terms
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ARMS=("parent","previous","warped-query","held-route","cross-route","cross-weak")
CAPTIONS={"parent":"Corpus 100k EMA","previous":"Prior joint fit","warped-query":"Prior crop check",
          "held-route":"Calibrated held residual","cross-route":"Cross-evidence gate","cross-weak":"Cross-evidence, weak only"}
LIMITS = tuple((y,x)for y in range(0,160-phase.SIZE+1,phase.SIZE//2)
                       for x in range(0,160-phase.SIZE+1,phase.SIZE//2))


def fit_bands(observed,parent,layout,absolute,carrier,noise):

    offsets=phase.planes(layout,absolute)
    mat=np.concatenate((phase.TONE,carrier),axis=-1)
    samples=[(phase.clip_samples(observed,o).astype(np.float64),phase.clip_samples(mat,o))for o in offsets]
    res=[]
    gains=[]
    for (raw,M),(held,V) in (samples,samples[::-1]):
        gram=M.T@M
        moment=M.T@raw
        coeff=np.linalg.solve(gram,moment)
        residual=held-V@coeff
        errors=[]
        for k in range(2):
            keep=np.ones(len(coeff),dtype=bool)
            keep[len(coeff)-4+k::2]=False
            omit=np.linalg.solve(gram[keep][:,keep],moment[keep])
            left=held-V[:,keep]@omit
            errors.append((left@left-residual@residual)/phase.variance(raw,noise))
        gains.append(errors)
        res.append(coeff[-4:].reshape(2,2).T)
    support=np.maximum(0,np.min(gains,axis=0)-6.)
    measured=np.mean(res,axis=0)
    dense=mat.reshape(-1,mat.shape[-1])
    restored=np.linalg.solve(dense.T@dense,dense.T@parent.ravel())[-4:].reshape(2,2).T
    delta=(measured-restored)*(support/(support+6.))[:,None]
    delta*=np.minimum(1,np.linalg.norm(measured,axis=-1)/np.maximum(np.linalg.norm(delta,axis=-1),1e-10))[:,None]
    # Retain three columns. The first two give the two individual directions.
    # The last is the summed contraction for the matched reference check.
    expanded=np.zeros((4,2,2))
    expanded[0,0,0],expanded[2,0,0]=delta[0]
    expanded[1,1,1],expanded[3,1,1]=delta[1]
    return np.stack((carrier@expanded[:,0,0],carrier@expanded[:,1,1],carrier@delta.T.ravel())).astype(np.float32)


def decompose(raw,parent,cfa,wb,matrix,noise,seed,roi):
    x,y,w,h=roi
    assert w==h==160
    shape=tangent_terms(seed)
    header=seed[:,:2]
    native=phase.unpack(raw)[y:y+h,x:x+w]
    past=parent[1,y:y+h,x:x+w]
    weights=np.zeros((h,w),dtype=np.float64)
    sums=np.zeros((3,h,w),dtype=np.float64)
    taper=phase.BLENDS[phase.SIZE]
    for dy,dx in LIMITS:
        sl=np.s_[dy:dy+phase.SIZE,dx:dx+phase.SIZE]
        nominal,indices=phase.coords(dx,dy,header)
        bands=phase.wave(nominal,indices,shape)
        part=fit_bands(native[sl],past[sl],cfa,(x+dx,y+dy,phase.SIZE),bands,noise)
        sums[:,sl[0],sl[1]]+=part*taper
        weights[sl]+=taper
    edge=np.minimum(1,np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)/12)
    normal=(edge[:,None]*edge[None,:])/np.maximum(.02,weights)
    gains=np.linalg.solve(matrix,np.ones(3))/wb
    output=np.zeros((3,*parent.shape),dtype=np.float32)
    output[:,:,y:y+h,x:x+w]=(gains/gains[1])[None,:,None,None]*(sums*normal)[:,None]
    return np.float32(old.DOSE)*output


def observe(row,plan,trial,baseline,prior,folder,examples,threshold,held_threshold):
    i=row["i"]
    source=plan["sources"][i]
    assert row["input"]==trial["input"]==baseline["input"]==prior["input"]
    assert row["parent"]==baseline["parent"]==prior["parent"]
    with np.load(checked(row["input"]),allow_pickle=False) as f:
        raw={k:f[k]for k in f.files}
    with np.load(checked(row["parent"]),allow_pickle=False) as f:
        parent=f["baseline"]
    x,y,w,h=plan["query_box"]
    tile=raw["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
    target=raw["target"][...,y:y+h,x:x+w]
    prediction={a:parent.copy()for a in ARMS}
    noise=plan["profile"]
    traces=[]
    for obs,nom,prior_case in zip(row["rows"],trial["rows"],baseline["rows"],strict=True):
        rep,role=obs["draw"],obs["role"]
        assert (rep,role)==(nom["repeat"],nom["role"])==(prior_case["draw"],prior_case["role"])
        ix=plan["roles"].index(role)
        calib=[raw[k][rep,ix]for k in ("colors","wb","matrix")]
        actions,_=old.added(tile[rep,ix],parent[rep,ix],*calib,noise,nom["selected"],prior_case)
        branches={k:actions["warped-query"]for k in ARMS[1:]}
        branches["previous"]=actions["previous"]
        evidence=obs["active_candidate"]
        if evidence:
            chosen=nom["selected"]["local-warped"]
            assert chosen["admitted"] and not prior_case["nomination"]["admitted"]
            decision=evidence["cross"]>threshold
            held=evidence["held"]>held_threshold
            branches["held-route"]=actions["warped-fallback"] if held else actions["previous"]
            branches["cross-route"]=branches["cross-weak"]=actions["previous"]
            if decision:
                seed=np.asarray(chosen["seed"])
                weak=int(np.argmin(np.asarray(chosen["reserve_tiles"]).sum(axis=(0,1))))
                bands=decompose(tile[rep,ix],parent[rep,ix],*calib,noise,seed,phase.ROI)
                np.testing.assert_array_equal(bands[2],actions["warped-fallback"])
                branches["cross-route"]=actions["warped-fallback"]
                branches["cross-weak"]=bands[weak]
            traces.append({"repeat":rep,"role":role,"old_accept":evidence["old_accept"],"cross_accept":decision,"held_accept":held})
        for k,values in branches.items():
            prediction[k][rep,ix]+=values
    values={name:old.totals(rgb,parent,target,raw)for name,rgb in prediction.items()}
    assert values["warped-query"]==prior["metrics"]["warped-query"]
    assert values["previous"]==prior["metrics"]["previous"]
    cards=[]
    for repeat in examples.get(i,()):
        frame={k:raw[k][repeat,:1]for k in ("colors","wb","matrix")}|{"packed":tile[repeat,:1]}
        photos=[noisy_malvar(frame)[0],*(prediction[a][repeat,0]for a in ARMS),target[repeat,0]]
        captions=("Noisy Malvar",*(CAPTIONS[a]for a in ARMS),"Exact GT")
        cards.append(old.native_board(folder,f'case-{i:03d}-draw{repeat}',photos,frame,
                  {"CFA":source["camera"]["pattern"],"noise":noise,"input":row["input"],"source":source["source"],
                   "source_box":source["box"],"query":plan["query_box"],"parent":row["parent"],"repeat":repeat,"role":"present"},
                   labels=captions,exposure=2,contrast=1,triplet_indices=(0,captions.index(CAPTIONS["cross-route"]),len(captions)-1)))
    return {k:row[k]for k in ("i","source","shape","input","parent")}|{"metrics":values,"native":cards,"gates":traces}


def summarize(rows):
    rng=np.random.default_rng(8262441)
    repeat=rng.integers(len(rows),size=(10000,len(rows)))
    result={}
    for metric in rows[0]["metrics"]["parent"]:
        fixed={name:np.asarray([r["metrics"][name][metric] for r in rows])for name in ARMS}
        changes={}
        for label in ("held-route","cross-route","cross-weak"):
            for other in ("warped-query","previous") + (("held-route",) if label!="held-route" else ()):
                delta=fixed[label]-fixed[other]
                changes[f'{label}_vs_{other}']={"point":float(delta.mean()),
                     "interval_95":np.quantile(delta[repeat].mean(1),[.025,.975]).tolist()}
        result[metric]={"mean":{name:float(v.mean())for name,v in fixed.items()},"delta":changes}
    return result


def main():
    start=time.monotonic()
    ev=reference(ROOT/"detection.json")
    found=read_json(checked(ev))
    links={k:read_json(checked(v))for k,v in found["sources"].items()}
    nom,delivery,replay=(links[k]for k in ("nomination","delivery","replication"))
    old_blind=read_json(checked(nom["previous"]))
    threshold=found["thresholds"]["active_candidate"]["cross_0"]
    held_threshold=found["thresholds"]["active_candidate"]["held_0"]
    arms=(("initial",nom["plan"],nom["rows"],old_blind["rows"],delivery["records"]),
          ("independent",replay["plan"],replay["nominations"],replay["baseline"],replay["records"]))
    tree={}
    for label,plan,proposed,former,before in arms:
        plan=read_json(checked(plan))
        folder=ROOT/(label+"-fair")
        folder.mkdir(exist_ok=True)
        candidates={}
        for row in found["rows"][label]:
            for d in row["rows"]:
                gate=d["active_candidate"]
                if d["role"]=="present" and gate is not None and not gate["old_accept"] and gate["cross"]>threshold:
                    candidates.setdefault(row["i"],[]).append(d["draw"])
        # First admitted formerly rejected source in evaluation order.
        selected=dict(list(candidates.items())[:1])
        results=[observe(a,plan,b,c,d,folder,selected,threshold,held_threshold)
                 for a,b,c,d in zip(found["rows"][label],proposed,former,before,strict=True)]
        tree[label]={"rows":results,"summary":{key:summarize([r for r in results if r["shape"]==key])
                                            for key in ("bent","straight")}}
    write_json(ROOT/"delivery-fair.json",{"driver":reference(__file__),"detection":ev,"checkpoint":delivery["checkpoint"],
           "cross_threshold":threshold,"held_threshold":held_threshold,"groups":tree,"seconds":time.monotonic()-start,
           "scope":"Cross-evidence and calibrated held-residual gates use the same fixed noisy exterior proposals and zero development activations on eligible controls. The weak-only variant chooses the direction with less reciprocal donor support and keeps the same conditional local lift."})


if __name__=="__main__":
    main()
