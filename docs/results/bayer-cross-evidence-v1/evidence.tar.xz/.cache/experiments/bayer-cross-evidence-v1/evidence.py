"""Cross products of independently estimated Bayer coefficients as local evidence."""
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.with_name("bayer-warped-spacing-v1")
sys.path.insert(0,str(PREVIOUS))
from nominate import phase, tangent_terms
from geometry import windows
from diagnose import known_geometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

def load_delivery():
    spec=spec_from_file_location("warped_spacing_for_cross_evidence",PREVIOUS/"delivery.py")
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

old=load_delivery()
NEGATIVES=("outside-only","strong-only","quiet-query")


def coefficients(station,terms,noise):
    design,normal,fit,residual,_=phase.estimate(station,terms)
    indices=np.arange(len(fit)-4,len(fit)).reshape(2,2).T
    inverse=np.linalg.solve(normal,np.eye(len(fit)))
    sigma=phase.variance(station[0],noise)
    positions=np.stack([inverse[np.ix_(i,i)] for i in indices])*sigma
    return fit[indices],positions


def cross_products(samples,terms,noise):
    signal=np.zeros(2)
    variance=np.zeros(2)
    fits=[]
    for first,second in samples:
        a,CA=coefficients(first,terms,noise)
        b,CB=coefficients(second,terms,noise)
        distances=[]
        for k in range(2):
            common=np.linalg.inv(CA[k]+CB[k])
            value=float(a[k]@common@b[k])
            spread=float(np.trace(CA[k]@common@CB[k]@common))
            signal[k]+=value
            variance[k]+=spread
            distances.append((value,spread))
        fits.append(distances)
    return {"score":(signal/np.sqrt(variance)).tolist(),"each":fits,
            "coefficient_cross_sum":signal.tolist(),"null_variance":variance.tolist()}


def verify(tile,cfa,roi,frequencies,terms,noise):
    native=phase.unpack(tile)
    locations=[(x,y)for y in phase.CENTERS for x in phase.CENTERS]
    fits=windows(native,cfa,roi[:2],frequencies,locations)
    scores=cross_products(fits,terms,noise)
    gate,gain=old.query_check(tile,cfa,roi,frequencies,terms,noise)
    tally=np.array(gain)
    # The original gate also requires at least two supportive windows per direction.
    prev=tally.sum(1).min(0)
    return {"cross":float(min(scores["score"])),"by_family":scores["score"],
            "raw_cross":scores,"held":float(prev.min()),"held_by_family":prev.tolist(),
            "old_accept":gate,"old_tile_counts":(tally>0).sum(1).tolist()}


def record(row,plan,nomination):
    i=row["i"]
    assert row["input"]==nomination["input"]
    field=plan["sources"][i]
    exact,terms=known_geometry(field["layout"])
    order=np.argsort(-exact[:,1])
    exact,terms=exact[order],terms[order]
    x,y,w,h=plan["query_box"]
    with np.load(checked(row["input"]),allow_pickle=False)as f:
        bayer=f["packed"][...,y//2:(y+h)//2,x//2:(x+w)//2]
        colors=f["colors"]
    condition=plan["profile"]
    result=[]
    for shake in nomination["rows"]:
        a=shake["repeat"]
        role=shake["role"]
        rid=plan["roles"].index(role)
        raw,cfa=bayer[a,rid],colors[a,rid]
        q=phase.ROI
        exact_geometry=verify(raw,cfa,q,exact,terms,condition)
        choice=shake["selected"]["local-warped"]
        observed=None
        if choice["admitted"] and not shake["formerly"]["admitted"]:
            selected=np.asarray(choice["seed"])
            observed=verify(raw,cfa,q,selected[:,:2],tangent_terms(selected),condition)
        result.append({"draw":a,"role":role,"exact":exact_geometry,"active_candidate":observed})
    return {"i":i,"source":row["source"],"input":row["input"],"parent":row["parent"],"shape":row["shape"],"rows":result}


def budget(rows,key,method,count):
    scored=[r[key][method]for s in rows for r in s["rows"]if r["role"]in NEGATIVES and r[key] is not None]
    assert len(scored)>count
    return max(0.,float(sorted(scored,reverse=True)[count]))


def performance(rows,category,thresholds):
    result={}
    for geometry in ("bent","straight"):
        group=[r for r in rows if r["shape"]==geometry]
        result[geometry]={}
        for role in ("present",*NEGATIVES):
            candidates=[r[category]for row in group for r in row["rows"]if r["role"]==role and r[category]is not None]
            fields={"eligible":len(candidates),"original_gate":sum(c["old_accept"]for c in candidates)}
            for k,gate in thresholds.items():
                fields[k]=sum(c[k.split("_")[0]]>gate for c in candidates)
            result[geometry][role]=fields
    return result


def main():
    t=time.monotonic()
    refs={label:reference(PREVIOUS/(label+".json"))for label in ("nomination","delivery","replication")}
    saved={label:read_json(checked(v))for label,v in refs.items()}
    initial,local,replay=(saved[x]for x in refs)
    assert local["nominations"]==refs["nomination"] and replay["prior"]==refs["delivery"]
    panels={}
    for key,deliveries,nominations,plan in (("initial",local["records"],initial["rows"],initial["plan"]),
                                           ("independent",replay["records"],replay["nominations"],replay["plan"])):
        layout=read_json(checked(plan))
        panels[key]=[record(a,layout,b)for a,b in zip(deliveries,nominations,strict=True)]
    thresholds={key:{f"{metric}_{rank}":budget(panels["initial"],key,metric,rank)
                     for metric in ("cross","held")for rank in (0,1,2)}for key in ("exact","active_candidate")}
    reports={name:{key:performance(rows,key,thresholds[key])for key in thresholds}for name,rows in panels.items()}
    write_json(ROOT/"detection.json",{"driver":reference(__file__),"sources":refs,"thresholds":thresholds,
              "rows":panels,"results":reports,"seconds":time.monotonic()-t,
              "scope":"Compare approximate null-standardized cross products of conditional Bayer coefficients with held residual improvement. Thresholds use only development negative roles. Correct centers and tangents are a separate diagnostic."})
    print(thresholds)


if __name__=="__main__":
    main()
