"""Render the prospective captures where the two calibrated gates disagree."""
from evidence import ROOT, known_geometry, old
from delivery_fair import observe
from nominate import EXTERIOR, synthetic
from prospective import imported
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    case_ref = reference(ROOT/"prospective.json")
    trial = read_json(checked(case_ref))
    parents = read_json(checked(trial["predictions"]))
    data = read_json(checked(parents["fields"]))
    plan = read_json(checked(trial["plan"]))
    thresholds = plan["thresholds"]
    blind = imported("disagreement_prior", "blind.py", EXTERIOR)
    folder = ROOT/"disagreement-native"
    folder.mkdir(exist_ok=True)
    results = []
    for row in trial["rows"]:
        selected = [g["repeat"] for g in row["gates"] if g["role"]=="present"
                    and g["cross_accept"] and not g["held_accept"]]
        if not selected:
            continue
        i = row["i"]
        item = data["rows"][i]
        exact, terms = known_geometry(plan["sources"][i]["layout"])
        geometry = {i:{"input":item["capture"],"source_id":plan["sources"][i]["source"]["id"],
                      "geometry":"bent","exact_centers_xy":exact.tolist(),"exact_terms":terms.tolist()}}
        prior = blind.sample(item,plan,geometry,parents["rows"])
        choice = synthetic(item,plan,{i:prior},geometry)
        previous = old.observe(choice,plan,{i:prior},parents["rows"],folder)
        out = observe(trial["detections"][i],plan,choice,prior,previous,folder,
                      {i:selected},thresholds["cross_0"],thresholds["held_0"])
        assert out["gates"]==row["gates"] and out["metrics"]==row["metrics"]
        results.append(out)
    assert len(results)==2
    write_json(ROOT/"disagreement.json",{"driver":reference(__file__),"source":case_ref,"rows":results})


if __name__=="__main__":
    main()
