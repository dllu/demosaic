"""Freeze and run a disjoint bent-wire panel using the two existing gate thresholds."""
from functools import partial
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent

COUNT = 24
SEED = 99120895471
KEYS = ("packed", "variance", "colors", "wb", "matrix")
ARCHIVE = ROOT.with_name("query-frequency-consensus-v1")
PIECES = ROOT.with_name("donor-peak-prominence-v1")


def imported(name, source, directory):
    spec = spec_from_file_location(name, directory / source)
    obj = module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def freeze_and_generate():
    torch.set_num_threads(2)
    controls = read_json(ROOT/"detection.json")
    prior = read_json(checked(controls["sources"]["replication"]))
    previous = reference(ARCHIVE/"plan.json")
    props = read_json(checked(previous))
    cohort = read_json(checked(props["cohort"]))
    forbidden = {entry["source"] for group in controls["rows"].values() for entry in group}
    for name in ("query-bayer-reserve-v1", "green-gap-validation-v1",
                 "donor-peak-prominence-v1"):
        for row in read_json(ROOT.with_name(name)/"plan.json")["sources"]:
            forbidden.add(row["source"]["id"])
    for row in read_json(ROOT.with_name("paired-repeat-stability-v2")/"evaluation-plan.json")["rows"]:
        forbidden.add(row["source"]["id"])
    ranked = sorted((r for r in cohort["source_metadata"] if r["split"]=="val"
                    and r["bin_factor"]==4 and min(r["shape"][:2])>=512
                    and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in forbidden),
                    key=lambda r:hashlib.sha256(f"{SEED}/{r['id']}".encode()).hexdigest())[:COUNT]
    assert len(ranked)==len({r["id"] for r in ranked})==COUNT
    selected = {r["id"] for r in ranked}
    selected_hashes = {r["cache_sha256"] for r in ranked}
    audit = reference("docs/results/full-corpus-long100k-training-v1/source-audit.json")
    for trace in read_json(checked(audit))["source_traces"]:
        with checked(trace).open() as stream:
            for line in stream:
                for row in json.loads(line)["sources"]:
                    if row["kind"]=="photographic":
                        assert row["source_id"] not in selected
                        assert row["cache_sha256"] not in selected_hashes
    sys.path.insert(0, str(PIECES))
    generator = imported("consensus_source_geometry", "prepare.py", ARCHIVE)
    fields = generator.fields
    fields.ROOT, fields.SEED, fields.clean_targets = ROOT, SEED, generator.clean_targets
    entries = []
    for i, source in enumerate(ranked):
        box, = scene_crop_boxes(source["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"box"))
        geometry = fields.draw(i)
        bend = (-1 if i%2 else 1) * (.000032+.000002*(i%8))
        geometry.update(weak_tangential_curvature_cycles_per_px2=bend,
                        strong_tangential_curvature_cycles_per_px2=-bend*.65)
        entries.append(fields.row_for(source,i,SEED)|{"box":box,"layout":geometry})
    plan = ROOT/"plan.json"
    write_json(plan,{k:props[k] for k in ("cohort","base","roles","profile","repeat_count","query_box")}
        | {"driver":reference(__file__),"seed":SEED,"fit_indices":[],"test_indices":list(range(COUNT)),
           "training_exclusion":audit,"development":reference(ROOT/"detection.json"),
           "comparison":reference(ROOT/"delivery-fair.json"),"geometry":reference(ARCHIVE/"prepare.py"),
           "sensor_generator":reference(PIECES/"prepare_fields.py"),"sources":entries,
           "thresholds":controls["thresholds"]["active_candidate"],
           "scope":"24 held-out photo backgrounds seeded before outcomes. Both carriers bend on all cases. "
                   "Original exterior candidates, two central gates, local correction and dose are frozen."})
    assert props["base"]==prior["checkpoint"]
    fields.construct()


@torch.inference_mode()
def predictions():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    manifest = reference(ROOT/"fields.json")
    data = read_json(checked(manifest))
    plan = read_json(checked(data["plan"]))
    model, state = load_checkpoint(plan["base"]["path"], "cuda", tiled_inference=True)
    assert state["loaded_sha256"]==plan["base"]["sha256"] and state["step"]==100000 and "ema" in state
    model.eval()
    model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
    folder = ROOT/"parent"
    folder.mkdir(exist_ok=True)
    rows = []
    x,y,w,h = plan["query_box"]
    for r in data["rows"]:
        with np.load(checked(r["capture"]),allow_pickle=False) as f:
            values = {k:f[k] for k in KEYS}
        args = [torch.from_numpy(values[k].reshape((-1,*values[k].shape[2:]))).cuda() for k in KEYS]
        for i in range(2):
            args[i] = args[i][...,y//2:(y+h)//2,x//2:(x+w)//2].contiguous(memory_format=torch.channels_last)
        with ieee_fp32():
            restored = model(*args)
        assert restored.dtype==torch.float32 and torch.isfinite(restored).all()
        path = folder/f'{r["index"]:03d}.npz'
        with path.open("xb") as stream:
            np.savez(stream,baseline=restored.cpu().numpy().reshape(2,4,3,h,w))
        rows.append({"index":r["index"],"output":reference(path)})
        print("parent",len(rows),flush=True)
    write_json(ROOT/"parents.json",{"rows":rows,"checkpoint":plan["base"],"fields":manifest})


def evaluate():
    from evidence import known_geometry, old, record
    from delivery_fair import observe, summarize
    from nominate import EXTERIOR, synthetic

    t0 = time.monotonic()
    blind = imported("prospective_previous_blind", "blind.py", EXTERIOR)
    data = read_json(ROOT/"fields.json")
    checkpoint = reference(ROOT/"parents.json")
    saved = read_json(checked(checkpoint))
    plan = read_json(checked(data["plan"]))
    thresholds = plan["thresholds"]
    examples = 0
    folder = ROOT/"prospective-native"
    folder.mkdir(exist_ok=True)
    result=[]
    all_detections=[]
    for i, item in enumerate(data["rows"]):
        exact, terms = known_geometry(plan["sources"][i]["layout"])
        donor = {"input":item["capture"],"source_id":plan["sources"][i]["source"]["id"],"geometry":"bent",
                 "exact_centers_xy":exact.tolist(),"exact_terms":terms.tolist()}
        truth = {i:donor}
        prior = blind.sample(item,plan,truth,saved["rows"])
        nom = synthetic(item,plan,{i:prior},truth)
        previous = old.observe(nom,plan,{i:prior},saved["rows"],folder,None)
        detections = record(previous,plan,nom)
        use = {}
        for lens in detections["rows"]:
            p = lens["active_candidate"]
            if p is not None and lens["role"]=="present" and p["cross"]>thresholds["cross_0"]:
                if examples<2:
                    use.setdefault(i,[]).append(lens["draw"])
        examples += bool(use)
        out = observe(detections,plan,nom,prior,previous,folder,use,thresholds["cross_0"],thresholds["held_0"])
        result.append(out)
        all_detections.append(detections)
        print("scored",i,len(out["gates"]),out["gates"],flush=True)
    from evidence import performance
    write_json(ROOT/"prospective.json",{"driver":reference(__file__),"plan":data["plan"],"predictions":checkpoint,
        "checkpoint":saved["checkpoint"],"rows":result,"detections":all_detections,
        "detected":performance(all_detections,"active_candidate",thresholds)["bent"],
        "oracle":performance(all_detections,"exact",read_json(ROOT/"detection.json")["thresholds"]["exact"])["bent"],
        "summary":summarize(result),"scoring_seconds":time.monotonic()-t0})


if __name__=="__main__":
    globals()[sys.argv[1]]()
