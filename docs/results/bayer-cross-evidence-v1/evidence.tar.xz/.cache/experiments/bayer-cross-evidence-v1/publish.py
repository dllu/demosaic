"""Verify real abstentions, native pixels and frozen paired phase receipts."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

from PIL import Image, ImageChops

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.with_name("bayer-warped-spacing-v1")
OLD_MANIFEST = Path("docs/images") / PREVIOUS.name / "manifest.json"
IMAGES = Path("docs/images") / ROOT.name
RESULTS = Path("docs/results") / ROOT.name


def panels(path, boxes):
    with Image.open(path) as image:
        result = {}
        for box in boxes:
            x,y,w,h = box["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            result[box.get("label") or box["name"]] = image.crop((x,y,x+w,y+h))
    assert len(result)==len(boxes)
    return result


def copy(field, group):
    source = checked(field["image"])
    path = IMAGES/group/source.name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,path)
    assert reference(path)["sha256"] == field["image"]["sha256"]
    field["image"]["path"] = str(path.relative_to(IMAGES))
    return panels(path,field["panels"])


def index_from_nomination(standing, nomination):
    cases = {}
    for row in nomination["camera"]:
        for profile,candidate in row["profiles"].items():
            region=row["region"]
            if region.startswith("fine-green"):
                stem="profile3879" if profile=="transferred" else profile
                name=f"mesh-{stem}-{region}"
            else:
                assert profile=="nominal"
                name=f"main-{region}-main-{region}"
            assert not candidate["local-warped"]["admitted"]
            cases[name]={"name":name,"warped_exterior_admitted":False,
                         "raw":row["raw"],"outside_origin_xy":row["box"][:2],"profile":profile}
    assert len(cases)==len(standing["rows"])==8
    result = []
    for row in standing["rows"]:
        proposal = cases[row["id"]]
        assert proposal["raw"]==row["raw"] and row["fallback_returned_prior"]
        checked(row["input"])
        checked(row["parent"])
        board = row["board"]
        assert [row["native_box"][n]+row["roi"][n] for n in (0,1)]==proposal["outside_origin_xy"]
        image = OLD_MANIFEST.parent/board["image"]["path"]
        assert reference(image)["sha256"]==board["image"]["sha256"]
        cells = panels(image,board["panels"])
        assert ImageChops.difference(cells["Prior joint crop check"],cells["Warped, check query"]).getbbox() is None
        result.append(proposal|{k:row[k] for k in ("noise","roi","native_box","display_exposure","input","parent")}
                      |{"view":reference(image),"reproduced_panel":"Prior joint crop check"})
    return result


def main():
    IMAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    detection_ref, delivery_ref, prospective_ref = [
        reference(ROOT/name) for name in ("detection.json","delivery-fair.json","prospective.json")
    ]
    detection, delivered, prospective = [read_json(checked(x)) for x in (detection_ref,delivery_ref,prospective_ref)]
    assert delivered["detection"]==detection_ref and delivered["checkpoint"]==prospective["checkpoint"]
    assert checked(prospective["plan"])==ROOT/"plan.json"
    groups = {key:g["rows"] for key,g in delivered["groups"].items()}|{"prospective":prospective["rows"]}
    assert [len(group) for group in groups.values()]==[20,16,24]
    ids = [row["source"] for group in groups.values() for row in group]
    assert len(set(ids))==len(ids)
    binding = read_json(OLD_MANIFEST)["standing"]
    nomination_ref = detection["sources"]["nomination"]
    assert nomination_ref==binding["nominations"]
    standing = index_from_nomination(binding,read_json(checked(nomination_ref)))
    surveyed = {key:[] for key in groups}
    for key,rows in groups.items():
        for row in rows:
            for board in row["native"]:
                assert board["parent"]==row["parent"] and board["input"]==row["input"]
                methods = copy(board["board"],key)
                triplet = copy(board["triplet"],key)
                assert set(triplet)=={"Noisy Malvar","Cross-evidence gate","Exact GT"}
                assert all(ImageChops.difference(methods[k],v).getbbox() is None for k,v in triplet.items())
                surveyed[key].append(board)
    disagree_ref=reference(ROOT/"disagreement.json")
    disagreements=read_json(checked(disagree_ref))
    assert disagreements["source"]==prospective_ref
    surveyed["disagreement"]=[]
    for row in disagreements["rows"]:
        reference_row=prospective["rows"][row["i"]]
        assert row["metrics"]==reference_row["metrics"] and row["gates"]==reference_row["gates"]
        for board in row["native"]:
            methods=copy(board["board"],"disagreement")
            triplet=copy(board["triplet"],"disagreement")
            assert all(ImageChops.difference(methods[k],v).getbbox() is None for k,v in triplet.items())
            surveyed["disagreement"].append(board)
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"checkpoint":delivered["checkpoint"],"cases":surveyed,
        "standing":standing,"prior_standing_manifest":reference(OLD_MANIFEST),
        "reviewed_local":datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "observation":"All native cases and eight original standing boards inspected. The standing branch abstains before either crop score."},
        replace=True)
    files = [ROOT/f for f in ("evidence.py","delivery.py","delivery_fair.py","prospective.py","publish.py",
              "detection.json","delivery.json","delivery-fair.json","plan.json","fields.json","parents.json",
              "prospective.json","disagreement.py","disagreement.json","disagreement.log","detection.log","delivery-fair.log","prospective.log","prospective-preflight.log")]
    files += [checked(f) for f in detection["sources"].values()]
    files += [PREVIOUS/n for n in ("nominate.py","delivery.py","replicate.py","standing.py",
               "standing-bound/standing/manifest.json")]
    files += [checked(read_json(checked(prospective["plan"]))[key])for key in ("geometry","sensor_generator")]
    files += [Path("scripts/report_scene_wave_guides.py")]
    for name in ("carrier_scale.py","blind.py","geometry.py","delivery.py","anchored.py","diagnose.py","curve_delivery.py"):
        path=ROOT.with_name("bayer-exterior-bend-v1")/name
        if path.is_file():
            files.append(path)
    paths = {str(file.resolve().relative_to(Path.cwd())):file for file in files}
    archive=RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"w:xz",preset=4)as packet:
        for name,path in sorted(paths.items()):
            packet.add(path,arcname=name,recursive=False)
    with tarfile.open(archive)as packet:
        for name,path in paths.items():
            with packet.extractfile(name)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==reference(path)["sha256"]
    write_json(RESULTS/"publication.json",{"checkpoint":delivered["checkpoint"],
        "sources":{"detection":detection_ref,"matched_delivery":delivery_ref,"prospective":prospective_ref,"disagreement":disagree_ref},
        "archive":reference(archive),"native_manifest":reference(manifest),"initial_and_independent":detection["results"],
        "delivered_effects":{k:v["summary"]for k,v in delivered["groups"].items()},
        "prospective_passes":prospective["detected"],"prospective_effects":prospective["summary"],
        "standing_outputs_reused":len(standing),
        "scope":"Inference-only fixed 20-source development, 16-source independent replay, 24 further bent sources and eight standing native views."},
        replace=True)
    print("Published",len(ids),"unique source IDs and",sum(map(len,surveyed.values())),"native synthetic boards")


if __name__=="__main__":
    main()
