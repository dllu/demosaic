"""Construct wide exact fields with independently captured weak structures and gaps."""
import hashlib
import math
import random
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe,scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/"green-gap-validation-v1"
sys.path.insert(0,str(ROOT.parent/"weak-edge-distill-v1"))
from edge_data import ARGS,decode,row_for

SEED = 522200181913
SIZE = 512
QUERY = (128,128,256,256)
PROFILES = {"ISO6400":{"shot":.00128,"read":6.5536e-6,"exposure":.33}}
ROLES = ("present","outside-only","strong-only","quiet-query")
FIT = 12
COUNT = 32


def draw(index):
    rand = random.Random(scene_seed(SEED,index,"frequency geometry"))
    a = rand.uniform(.32,.8) * rand.choice((-1,1))
    b = a + rand.uniform(.86,1.72) * rand.choice((-1,1))
    s = rand.uniform(.048,.109)
    w = rand.uniform(.084,.176)
    amp = (.0045,.0065,.0085)[index%3]
    return {"strong_frequency_xy":[s*math.cos(a),s*math.sin(a)],
            "weak_frequency_xy":[w*math.cos(b),w*math.sin(b)],
            "strong_phase":rand.uniform(-math.pi,math.pi),"weak_phase":rand.uniform(-math.pi,math.pi),
            "strong_amplitude":.013,"weak_amplitude":amp,
            "foreground_angle":rand.uniform(0,2*math.pi),"foreground_shift":rand.uniform(-28,28),
            "foreground_height":[rand.uniform(.09,.18) for _ in range(3)],
            "gap_angle":rand.uniform(0,2*math.pi),"gap_radius":rand.uniform(11,25),
            "shape":("stripe","ellipse")[(index//2)%2],"step":bool((index//4+index)%2)}


def freeze():
    prior = reference(OLD/"plan.json")
    old = read_json(checked(prior))
    weak = read_json(checked(old["exclusion"]))
    cohort = read_json(checked(old["source_cohort"]))
    replay = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    excluded = {r["source"]["id"] for r in [*old["sources"],*weak["heldout_rows"],*replay["rows"]]}
    available = [r for r in cohort["source_metadata"] if r["split"]=="val" and r["bin_factor"]==4
                 and min(r["shape"][:2])>=SIZE and np.prod(r["shape"][:2])<=4_000_000
                 and r["id"] not in excluded]
    order = sorted(available,key=lambda s:hashlib.sha256(f'{SEED}/{s["id"]}'.encode()).hexdigest())
    selected = []
    for i,source in enumerate(order[:COUNT]):
        field, = scene_crop_boxes(source["shape"][:2],patch_size=SIZE,count=1,
                                  seed=scene_seed(SEED,i,"outer box"))
        selected.append(row_for(source,i,SEED) | {"box":field,"layout":draw(i)})
    assert len({r["source"]["id"]for r in selected}) == COUNT
    write_json(ROOT/"plan.json",{
        "driver":reference(__file__),"prior":prior,"cohort":old["source_cohort"],"base":old["base"],
        "sources":selected,"roles":ROLES,"profile":PROFILES["ISO6400"],"repeat_count":2,
        "seed":SEED,"query_box":QUERY,"fit_indices":list(range(FIT)),"test_indices":list(range(FIT,COUNT)),
        "scope":"Fixed physical field and camera for two independent repeats of four roles. The prior and this experiment use different validation source IDs. Outside-only has the entire nominal weak carrier outside the central area but exactly zero weak carrier in the scored region. Quiet-query keeps the two exterior carriers and supplies an exactly constant query core."})


def clean_targets(photo,geom):
    coords = torch.arange(SIZE,dtype=photo.dtype)
    y,x = torch.meshgrid(coords,coords,indexing="ij")
    center = (SIZE-1)/2
    dx,dy = x-center,y-center
    frame = torch.maximum(dx.abs(),dy.abs())
    flat_window = ((124-frame)/46).clamp(0,1)
    vanished = ((frame-104)/19).clamp(0,1)
    haze = F.avg_pool2d(photo[None],9,stride=1,padding=4,count_include_pad=False)[0]
    natural = .055+.58*haze
    if geom["step"]:
        a = geom["foreground_angle"]
        distance = dx*math.cos(a)+dy*math.sin(a)-geom["foreground_shift"]
        natural.add_(torch.tensor(geom["foreground_height"])[:,None,None]*torch.sigmoid(distance/.63))
    angle = geom["gap_angle"]
    u = dx*math.cos(angle)+dy*math.sin(angle)
    v = -dx*math.sin(angle)+dy*math.cos(angle)
    radius = geom["gap_radius"]
    distance = u.abs() if geom["shape"]=="stripe" else torch.hypot(u,v*radius/39)
    gap = ((distance-radius)/6).clamp(0,1)
    # The exterior carriers are continuous. The stripe is restricted to the query.
    gap = torch.maximum(gap,((frame-92)/27).clamp(0,1))

    def carrier(tag):
        fx,fy = geom[tag+"_frequency_xy"]
        return geom[tag+"_amplitude"]*torch.cos(2*math.pi*(fx*x+fy*y)+geom[tag+"_phase"])

    strong = natural+carrier("strong")
    weak = carrier("weak")
    middle = strong[:,192:320,192:320].mean((-1,-2),keepdim=True)
    constant = torch.where(flat_window==1,middle,torch.lerp(strong+weak,middle,flat_window))
    targets = strong+weak*gap,strong+weak*vanished,strong,constant
    assert all((t.min()>0 and t.max()<1)for t in targets)
    return targets,gap,weak


def construct():
    torch.set_num_threads(2)
    binding = reference(ROOT/"plan.json")
    plan = read_json(checked(binding))
    output = ROOT/"fields"
    output.mkdir(exist_ok=True)
    rows = []
    for source in plan["sources"]:
        i = source["index"]
        targets,gap,weak = clean_targets(decode(source["source"],source["box"]),source["layout"])
        camera = replace(sample_scene_recipe(SEED),**(source["camera"]|plan["profile"]))
        seeds = [[scene_seed(SEED,i,f"obs/{r}/{role}")for role in ROLES]for r in range(2)]
        assert len(set(sum(seeds,[]))) == 8
        draws = [[observe_scene(t,replace(camera,noise_seed=s)) for t,s in zip(targets,ss,strict=True)]for ss in seeds]
        arr = {k:torch.stack([torch.stack([getattr(o,k)for o in row])for row in draws]).numpy()
               for k in (*ARGS,"target")}
        np.testing.assert_array_equal(arr["target"][0],arr["target"][1])
        arr["region"] = gap.numpy()[128:384,128:384]
        arr["weak_linear_nominal"] = weak.numpy()[128:384,128:384]
        path = output/f"{i:03d}.npz"
        with path.open("xb")as f:
            np.savez(f,**arr)
        rows.append({"index":i,"capture":reference(path),"seeds":seeds,
                     "fingerprints":{k:fingerprint(v)for k,v in arr.items()}})
        print(f"{i+1}/{len(plan['sources'])}",flush=True)
    write_json(ROOT/"fields.json",{"plan":binding,"rows":rows})


if __name__=="__main__":
    freeze()
    construct()
