"""Make new exact fields with a mix of straight and slowly varying fringe frequencies."""
from pathlib import Path
import hashlib
import math
import sys

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
Q = ROOT.parent/"query-bayer-reserve-v1"
EXT = ROOT.parent/"donor-peak-prominence-v1"
sys.path.insert(0,str(EXT))
import prepare_fields as fields

SEED = 514804557903
COUNT = 16


def clean_targets(photo,geometry):
    coords = torch.arange(512,dtype=photo.dtype)-255.5
    y,x = torch.meshgrid(coords,coords,indexing="ij")
    frame = torch.maximum(x.abs(),y.abs())
    flat = ((124-frame)/46).clamp(0,1)
    only_exterior = ((frame-104)/19).clamp(0,1)
    soft = F.avg_pool2d(photo[None],9,stride=1,padding=4,count_include_pad=False)[0]
    natural = .055+.58*soft
    if geometry["step"]:
        a = geometry["foreground_angle"]
        signed = x*math.cos(a)+y*math.sin(a)-geometry["foreground_shift"]
        height = torch.tensor(geometry["foreground_height"])[:,None,None]
        natural = natural+height*torch.sigmoid(signed/.63)
    a = geometry["gap_angle"]
    u,v = x*math.cos(a)+y*math.sin(a),-x*math.sin(a)+y*math.cos(a)
    radius = geometry["gap_radius"]
    gap = ((u.abs() if geometry["shape"]=="stripe" else torch.hypot(u,v*radius/39))-radius).div(6).clamp(0,1)
    gap = torch.maximum(gap,((frame-92)/27).clamp(0,1))

    def wave(which):
        a,b = geometry[which+"_frequency_xy"]
        magnitude = math.hypot(a,b)
        tangential = (-b*x+a*y)/magnitude
        perpendicular = (a*x+b*y)/magnitude
        k = geometry[which+"_tangential_curvature_cycles_per_px2"]
        cycle = perpendicular*magnitude+.5*k*tangential.square()
        return geometry[which+"_amplitude"]*torch.cos(2*math.pi*cycle+geometry[which+"_phase"])

    strong = natural+wave("strong")
    weak = wave("weak")
    level = strong[:,192:320,192:320].mean((-1,-2),keepdim=True)
    quiet = torch.where(flat==1,level,torch.lerp(strong+weak,level,flat))
    targets = strong+weak*gap,strong+weak*only_exterior,strong,quiet
    assert all((t.min()>0 and t.max()<1)for t in targets)
    return targets,gap,weak


def prepare():
    base = reference(Q/"plan.json")
    last = read_json(checked(base))
    old = read_json(checked(last["comparison"]))
    first = read_json(checked(old["prior"]))
    weak = read_json(checked(first["exclusion"]))
    repeat = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    cohort = read_json(checked(old["cohort"]))
    used = {r["source"]["id"]for r in [*last["sources"],*old["sources"],*first["sources"],*weak["heldout_rows"],*repeat["rows"]]}
    available = [r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
                 and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"] not in used]
    ranked = sorted(available,key=lambda r:hashlib.sha256(f'{SEED}/{r["id"]}'.encode()).hexdigest())
    fields.ROOT = ROOT
    fields.SEED = SEED
    fields.clean_targets = clean_targets
    entries = []
    for i,s in enumerate(ranked[:COUNT]):
        box, = scene_crop_boxes(s["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"box"))
        settings = fields.draw(i)
        scale = (0 if i%2==0 else (-1 if i%4==1 else 1)*(.000032+i*.000001))
        settings.update({"weak_tangential_curvature_cycles_per_px2":scale,
                         "strong_tangential_curvature_cycles_per_px2":-scale*.65})
        entries.append(fields.row_for(s,i,SEED)|{"box":box,"layout":settings})
    assert len({r["source"]["id"]for r in entries})==COUNT
    write_json(ROOT/"plan.json",{
        **{k:last[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"generator":reference(EXT/"prepare_fields.py"),"preceding":base,
        "sources":entries,"seed":SEED,"fit_indices":[],"test_indices":list(range(COUNT)),
        "scope":"16 unused validation sources with fresh redraws. Eight fields curve both carrier directions. Scoring uses exact spatially varying targets, with no fresh strength calibration."})
    fields.construct()


if __name__=="__main__":
    prepare()
