"""Review the native narrow-wire assay, preserving fixed displays."""

import argparse
import importlib.util
from collections import defaultdict
from itertools import product
from pathlib import Path

import numpy as np
from probe_finite_wire_profiles import ARMS
from probe_surface_aggregation import field
from report_fold_support_pooling import evaluated, insert_camera_panels, measure, scale_at_budget
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PLAN = read_json(ROOT / "plan.json")
OUT = ROOT / "review"
PRIOR = ROOT.parent / "shared-projective-transfer-v1/review.py"
spec = importlib.util.spec_from_file_location("projective_review", PRIOR)
proj = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proj)
read_case = proj.prior.read_case


def camera():
    references = read_json(checked(PLAN["camera_baseline"]))["camera"]
    captures = read_json(ROOT / "camera.json")["rows"]
    old = {row["id"]: row for row in read_json(proj.ROOT / "review/camera.json")["rows"]}
    result = []
    for source, row in zip(references, captures, strict=True):
        key = source["id"]
        assert key == row["id"]
        x, y, w, h = source["ROI_xywh"]
        qx, qy, *_ = source["source"]["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(source["source"]["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        metrics, columns = {}, []
        labels = {"flexible": "eight knots", "narrow": "narrow", "narrow-companion": "companion"}
        with np.load(checked(row["predictions"])) as f:
            parent = f["parent"][region].astype(float)
            for g, (arm, label) in product(("scene", "spectral"), labels.items()):
                name = field(g, arm, 0)
                pixels = f[name][region]
                display_rgb = display(pixels[None], ctx, exposure=source["display_exposure"])
                columns.append(
                    (
                        f"{g.title()} {label}",
                        np.rint(display_rgb[0].transpose(1, 2, 0) * 255).astype(np.uint8),
                    )
                )
                metrics[name] = float(np.sqrt(np.mean((pixels - parent) ** 2)) * 65535)
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in source["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, panels = insert_camera_panels(
            OUT, key, source | {"panels": panels}, "V120 EMA", columns
        )
        result.append(
            old[key]
            | {
                "image": image,
                "panels": panels,
                "predictions": row["predictions"],
                "selection": row["flexible_edges"],
                "RMS_from_V120_DN16": metrics,
            }
        )
    return {"rows": result}


def reduce_fresh(rows, powers, labels, threshold_suffix=""):
    m, scales = {}, {}
    original = "transfer-flexible" if "transfer-flexible" in labels else "baseline"
    key = original + threshold_suffix
    if key not in rows[0]["metrics"]:
        key = original
    baseline = np.sqrt(np.mean([r["metrics"][key]["quiet_RMS_DN16"] ** 2 for r in rows]))
    for arm in labels:
        key = arm + threshold_suffix
        if key not in rows[0]["metrics"]:
            continue
        rms = np.sqrt(np.mean([r["metrics"][key]["quiet_RMS_DN16"] ** 2 for r in rows]))
        cap = min(1, baseline / rms) if rms else 1
        m[arm] = {}
        scales[arm] = cap
        for stage, scale in (("fixed", 1), ("quiet_capped", cap)):
            p, e, q, s = np.mean(
                [
                    proj.math_row(r, power, scale, key)
                    for r, power in zip(rows, powers, strict=True)
                ],
                axis=0,
            )
            m[arm][stage] = {
                "weak_projection": p,
                "increment_RMS_DN16": float(np.sqrt(e)),
                "quiet_RMS_DN16": float(np.sqrt(q)),
                "strong_projection": s,
                "scale_multiplier": scale,
            }
    return m


def fresh(focused=False):
    boards, result = [], {}
    for panel, profile in (("projective400", "iso400"), ("projective6400", "iso6400")):
        panels = (
            ROOT.parent / "focused-finite-wire-v1" / f"{profile}.json"
            if focused
            else ROOT / f"{panel}.json"
        )
        rows = read_json(panels)["rows"]
        original = read_json(checked(PLAN["previous_panels"][panel]))["rows"]
        powers = []
        for row, base in zip(rows, original, strict=True):
            assert row["case"] == base["case"]
            with np.load(checked(base["prediction"])) as f:
                parent = f["parent"].astype(float)
                weak = f["target"].astype(float) - f["strong"]
                powers.append(float(np.mean((weak * 65535) ** 2)))
                if focused or profile != "iso400" or row["case"] not in (2, 7):
                    continue
                with np.load(checked(row["prediction"])) as pictures:
                    names = (
                        "planar-flexible",
                        "planar-narrow",
                        "transfer-flexible",
                        "transfer-narrow",
                        "transfer-narrow-companion",
                    )
                    labels = (
                        "Eight knots",
                        "Narrow",
                        "Warp eight knots",
                        "Warp narrow",
                        "Warp companion",
                    )
                    data = [
                        parent + PLAN["settings"][profile]["scale"] * (pictures[a] - parent)
                        for a in names
                    ]
                ctx = {
                    "packed": f["packed"][None],
                    "colors": f["cfa"][None],
                    "wb": np.ones((1, 3)),
                    "matrix": np.eye(3)[None],
                }
                boards.append(
                    native_board(
                        OUT,
                        row["id"],
                        [noisy_malvar(ctx)[0], *data, f["target"]],
                        ctx,
                        {
                            "ROI_xywh": [48, 48, 160, 160],
                            "noise": PLAN["profiles"][profile],
                            "operating": PLAN["settings"][profile],
                            "CFA": row["CFA"],
                            "case": row["case"],
                            "kind": row["kind"],
                            "observations": base["prediction"],
                            "predictions": row["prediction"],
                            "parent": "Exact analytic rail",
                            "checkpoint_sha256": None,
                            "color_transform": "Identity WB and camera matrix, fixed clipped sRGB",
                        },
                        labels=("Noisy Malvar", *labels, "Exact GT"),
                        triplet_indices=(0, 5, 6),
                        roi=(48, 48, 160, 160),
                        exposure=4,
                    )
                )
        arms = (
            ("baseline", "focused-flexible", "focused-narrow-companion")
            if focused
            else tuple(f"{g}-{a}" for g, a in product(("planar", "transfer"), ARMS))
        )
        results = {}
        for k in ("shared", "different", "planar"):
            selected = [i for i in range(len(rows)) if rows[i]["kind"] == k]
            r, p = [[s[i] for i in selected] for s in (rows, powers)]
            results[k] = {
                suffix or "nominal": reduce_fresh(r, p, arms, suffix)
                for suffix in (("", "-strict", "-positive") if focused else ("", "-strict"))
            }
        result[profile] = results
    return {"scores": result, "boards": boards}


def nulls():
    groups = defaultdict(list)
    for profile in ("null400", "null6400"):
        for row in read_json(ROOT / f"{profile}.json")["rows"]:
            k = (
                "flat"
                if row["style"].endswith("flat")
                else "straight"
                if row["style"] in ("step", "rail")
                else "complex"
            )
            groups[k].append(row)
    return {
        k: {
            "count": len(rs),
            "accepted_profile_count": sum(
                sum(d["accepted"] for d in r["witness"]["directions"]) for r in rs
            ),
            "metrics": {
                arm: {
                    "RMS_DN16": float(
                        np.sqrt(np.mean([r["metrics"][arm]["RMS_DN16"] ** 2 for r in rs]))
                    ),
                    "max_abs_DN16": max(r["metrics"][arm]["max_abs_DN16"] for r in rs),
                }
                for arm in rs[0]["metrics"]
            },
        }
        for k, rs in groups.items()
    }


def archived():
    result = {}
    for split in ("synthetic", "disjoint"):
        moments = defaultdict(list)
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        for row in read_json(ROOT / f"{split}.json")["rows"]:
            case, p, truth, quiet, images = read_case(row, split)
            for guide, offset in product(guides, (0, 1)):
                names = ["parent", *(field(guide, a, offset) for a in ARMS)]
                moments[(case["profile"], guide, offset)].append(
                    {name: measure(p, truth, quiet, images[name]) for name in names}
                )
        result[split] = {}
        for (profile, guide, offset), group in moments.items():
            assert len(group) == 8
            means = {
                a: {k: np.mean([v[a][k] for v in group], axis=0) for k in m}
                for a, m in group[0].items()
            }
            scale = PLAN["settings"][profile]["scale"]
            fixed = {a: evaluated(m, scale) for a, m in means.items()}
            limit = fixed[field(guide, "flexible", offset)]["quiet_RMS_DN16"]
            budget = max(0, limit - fixed["parent"]["quiet_RMS_DN16"])
            capped = {
                a: evaluated(m, min(scale, scale_at_budget(m["quiet_mse"], budget)))
                for a, m in means.items()
            }
            result[split].setdefault(profile, {})[field(guide, "comparison", offset)] = {
                "fixed": fixed,
                "quiet_capped": capped,
                "count": len(group),
            }
    return result


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("task", choices=("camera", "fresh", "archived", "nulls", "focused"))
    key = cli.parse_args().task
    OUT.mkdir(exist_ok=True)
    fn = {
        "camera": camera,
        "fresh": fresh,
        "archived": archived,
        "nulls": nulls,
        "focused": lambda: fresh(True),
    }
    write_json(OUT / f"{key}.json", {"producer": reference(__file__), **fn[key]()})
