"""Publish the retained diagnostic, replays and inspected native crops."""

import shutil
import tarfile
from pathlib import Path

from probe_finite_wire_profiles import PANELS, REPEAT_PANELS

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
cache = root.parent
slug = "finite-wire-profiles-v1"
docs = Path("docs")
results = docs / "results" / slug
images = docs / "images" / slug
groups = {
    "positive_margin": (cache / "finite-wire-profiles-v1", PANELS),
    "unit_margin": (cache / "finite-wire-margin-v1", (*PANELS, *REPEAT_PANELS)),
    "focused_unit_margin": (cache / "focused-wire-margin-v1", (*PANELS, *REPEAT_PANELS)),
    "focused_conditional_margin": (root, (*PANELS, *REPEAT_PANELS)),
}
diagnostic = cache / "wire-proposal-delivery-v1"
pilot = cache / "focused-finite-wire-v1"
primary = {k: read_json(root / f"review/{k}.json") for k in ("fresh", "camera")}
assert len(primary["fresh"]["boards"]) == 2
assert len(primary["camera"]["rows"]) == 8
assert "118 passed" in (groups["unit_margin"][0] / "tests.log").read_text()
results.mkdir()
images.mkdir()


def adopt(item):
    source = checked(item)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == item["sha256"]
    return output.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "scope": "Two native synthetic GT triplets and their comparison boards, and eight native GFX crops. "
        "Independent GFX references are qualitative.",
        "synthetic": [
            row | {k: row[k] | {"file": adopt(row[k]["image"])} for k in ("board", "triplet")}
            for row in primary["fresh"]["boards"]
        ],
        "camera": [row | {"file": adopt(row["image"])} for row in primary["camera"]["rows"]],
    },
)


def reviewed(path, panels):
    stages = ("fresh", "archived", "nulls", "camera")
    if REPEAT_PANELS[0] in panels:
        stages += ("repeat",)
    out = {}
    for k in stages:
        val = read_json(path / f"review/{k}.json")
        if k == "camera":
            val["rows"] = [
                {f: r[f] for f in ("id", "ROI_xywh", "checkpoint", "noise", "RMS_from_V120_DN16")}
                for r in val["rows"]
            ]
        elif k == "fresh":
            val.pop("boards")
        out[k] = val
    return out


summary = results / "summary.json"
write_json(
    summary,
    {
        "runs": {
            name: {
                "plan": reference(path / "plan.json"),
                "receipts": {p: reference(path / f"{p}.json") for p in panels},
            }
            for name, (path, panels) in groups.items()
        },
        "metrics": {name: reviewed(path, panels) for name, (path, panels) in groups.items()},
        "headroom": read_json(diagnostic / "diagnostic.json"),
        "initial_footprint_pilot": read_json(groups["positive_margin"][0] / "review/focused.json")[
            "scores"
        ],
        "new_checkpoint": None,
    },
)

sources = (
    "work/src/demosaic/local_validated_waves.py",
    "work/src/demosaic/finite_wire_profiles.py",
    "work/scripts/probe_finite_wire_profiles.py",
)
members = {
    f"{path.name}/{file}": path / file
    for path, panels in groups.values()
    for file in ("plan.json", *sources, *(f"{p}.{ext}" for p in panels for ext in ("json", "log")))
}
for path, _ in groups.values():
    for file in sorted((path / "review").glob("*.json")):
        members[f"{path.name}/review/{file.name}"] = file
    for file in ("review.py", "tests.log"):
        if (path / file).exists():
            members[f"{path.name}/{file}"] = path / file
for path, files in (
    (diagnostic, ("diagnose.py", "diagnostic.json", "diagnose.log")),
    (pilot, ("pilot.py", "iso400.json", "iso400.log", "iso6400.json", "iso6400.log")),
    (root, ("review_all.py", "publish.py")),
    (cache / "local-phase-bounds-v1", ("review.py",)),
    (cache / "shared-projective-transfer-v1", ("review.py",)),
):
    members.update({f"{path.name}/{file}": path / file for file in files})

archive = results / "evidence.tar.xz"
with tarfile.open(archive, "x:xz", preset=8) as bundle:
    for name, path in sorted(members.items()):
        metadata = bundle.gettarinfo(str(path), arcname=name)
        metadata.mtime = metadata.uid = metadata.gid = 0
        metadata.uname = metadata.gname = ""
        with path.open("rb") as stream:
            bundle.addfile(metadata, stream)
with tarfile.open(archive) as bundle:
    for item in bundle:
        assert bundle.extractfile(item).read() == members[item.name].read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": len(members),
        "comparisons_viewed": 10,
        "triplets_viewed": 2,
        "new_checkpoint": None,
    },
)
