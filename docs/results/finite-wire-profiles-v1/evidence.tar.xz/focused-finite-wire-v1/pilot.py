"""Test shared footprint and selected narrow phase with the same independent gate."""

import argparse
from dataclasses import replace
from pathlib import Path

import numpy as np
from probe_local_phase_bounds import structure_module
from probe_shared_projective_phase import target
from probe_wire_envelopes import score

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.finite_wire_profiles import reserve_wire_profiles
from demosaic.local_validated_waves import LocalWaveConfig, restore_local_waves
from demosaic.reserved_wire_footprint import select_wire_footprint
from demosaic.search_donor_geometry import screening_mask
from demosaic.shared_projective_phase import projective_hessians

ROOT = Path(__file__).resolve().parent
ORIG = ROOT.parent / "shared-projective-transfer-v1"
PLAN = read_json(ORIG / "plan.json")
RECIPE = structure_module(PLAN["structure"])
CONFIG = replace(LocalWaveConfig(**PLAN["config"]), background="screened_curved4_step")


def run(profile):
    panel = "projective400" if profile == "iso400" else "projective6400"
    noise = PLAN["profiles"][profile]
    settings = PLAN["settings"][profile]
    rows = []
    for original in read_json(ORIG / f"{panel}.json")["rows"]:
        i = original["case"]
        p, strong, both, frequencies, _, quiet, metadata = target(i, PLAN["geometry_seed"])
        guide = original["guide"]
        with np.load(checked(original["prediction"])) as f:
            cfa = f["cfa"]
        capture = []
        witnesses = []
        for role, truth in enumerate((strong, both)):
            seed = np.random.SeedSequence(
                [PLAN["geometry_seed"], 1, i, int(profile == "iso6400"), role]
            )
            packed = RECIPE.corrupt(truth, cfa, np.random.default_rng(seed), noise)
            prior = original["selection"][role]["directions"][0]
            hessians = None
            if prior["accepted"]:
                hessians = projective_hessians(
                    frequencies, np.asarray(prior["proposed"]) / min(quiet.shape)
                )
                hessians[0] = 0
            footprints, loc = select_wire_footprint(
                packed,
                cfa,
                RECIPE.QUERY,
                guide["frequencies_xy"],
                guide["active"],
                shot=noise["shot"],
                read=noise["read"],
                config=CONFIG,
                record_partner=True,
            )
            confirmed = footprints["confirmed"]
            use_footprint = confirmed is not None and loc["winner"]["direction"] == 0
            spatial = np.stack((np.ones(quiet.shape), confirmed)) if use_footprint else None
            shapes, witness = reserve_wire_profiles(
                packed,
                cfa,
                RECIPE.QUERY,
                guide,
                shot=noise["shot"],
                read=noise["read"],
                config=CONFIG,
                hessians=hessians,
                envelopes=spatial,
            )
            witnesses.append(
                {
                    "location": loc,
                    "footprint_transferred": use_footprint,
                    "profile": witness,
                }
            )
            stop = settings["threshold"]
            thresholds = (stop, stop + 1, 0.0)
            modes = {
                "baseline": (None, None),
                "focused-flexible": (spatial, None),
                "focused-narrow-companion": (
                    spatial,
                    (None, shapes[1]) if shapes[1] is not None else None,
                ),
            }
            saved = {}
            seen = {}
            for name, (env, prof) in modes.items():
                key = (env is not None, prof is not None)
                if key not in seen:
                    seen[key], _ = restore_local_waves(
                        p,
                        packed,
                        cfa,
                        shot=noise["shot"],
                        read=noise["read"],
                        config=CONFIG,
                        thresholds=thresholds,
                        evidence_mask=~screening_mask(RECIPE.QUERY),
                        guide_frequencies_xy=guide["frequencies_xy"],
                        guide_phase_hessians_xy=hessians,
                        guide_envelopes=env,
                        guide_profiles=prof,
                        phase_bins=8,
                        shrink_phase_fit=True,
                        compare_pooled_support=True,
                        compare_pooled_refit=True,
                        active_guide_directions=guide["active"],
                    )
                saved.update({(name, t): seen[key]["weighted-refit", t] for t in thresholds})
            capture.append(saved)
        with np.load(checked(original["prediction"])) as f:
            np.testing.assert_array_equal(capture[1]["baseline", stop], f["transfer"])
        rows.append(
            {
                "case": i,
                "kind": metadata["kind"],
                "profile": profile,
                "witnesses": witnesses,
                "metrics": score(p, strong, both, capture, quiet, settings["scale"], stop),
            }
        )
        print(profile, i, use_footprint, flush=True)
    write_json(
        ROOT / f"{profile}.json",
        {
            "plan": reference(ORIG / "plan.json"),
            "producer": reference(__file__),
            "rows": rows,
        },
    )


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("profile", choices=("iso400", "iso6400"))
    run(cli.parse_args().profile)
