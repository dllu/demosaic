"""Disentangle finite-wave model error from noise and delivery weights."""

from dataclasses import replace
from pathlib import Path

import numpy as np
from probe_local_phase_bounds import structure_module
from probe_shared_projective_phase import target

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import geometry, stratified_split
from demosaic.local_validated_waves import (
    LocalWaveConfig,
    _fixed_phase_offset,
    _phase_bin_weights,
    _refit_phase_components,
    conditional_scores,
    fit_local_candidate,
    phase_fit_reliability,
    pooled_support_score,
    support_weight,
)
from demosaic.search_donor_geometry import _native_view, screening_mask

OUT = Path(__file__).resolve().parent
ORIGINAL = OUT.parent / "shared-projective-transfer-v1"
PLAN = read_json(ORIGINAL / "plan.json")
CFG = replace(LocalWaveConfig(**PLAN["config"]), background="screened_curved4_step")
RECIPE = structure_module(PLAN["structure"])


def envelope(index, shape):
    """Recover the original envelope from its declared construction RNG."""
    rng = np.random.default_rng(np.random.SeedSequence([PLAN["geometry_seed"], 0, index]))
    angle, _, shift, _, _ = rng.uniform([0.1, 6, -24, 0.036, 0.06], [3.02, 14, 24, 0.085, 0.145])
    rng.uniform([48, 5], [68, 15])
    rng.uniform([10, 12], [14, 18])
    rng.uniform(0, 2 * np.pi)
    rng.uniform(0.10, 0.19)
    yy, xx = np.indices(shape) - (np.asarray(shape)[:, None, None] - 1) / 2
    x = xx - np.cos(angle) * (shift + 6)
    y = yy - np.sin(angle) * (shift + 6)
    along = -np.sin(angle) * x + np.cos(angle) * y - rng.uniform(-23, 23)
    across = np.cos(angle) * x + np.sin(angle) * y
    rad = np.hypot(along / rng.uniform(96, 112), across / rng.uniform(64, 78))
    return np.where(rad < 1, np.cos(np.pi * np.minimum(rad, 1) / 2) ** 2, 0)


def compare(raw, layout, f, h, taper, parent, threshold, noise):
    reserve = screening_mask(RECIPE.QUERY)
    a = stratified_split(raw.shape, CFG.split_seed)
    folds = a & ~reserve, ~a & ~reserve
    fit = [
        fit_local_candidate(
            raw,
            layout,
            mask,
            shot=noise["shot"],
            read=noise["read"],
            config=CFG,
            guide_frequencies_xy=f,
            guide_phase_hessians_xy=h,
            phase_bins=8,
            guide_envelopes=None if taper is None else np.stack([taper] * 2),
        )
        for mask in folds
    ]
    reliabilities = [phase_fit_reliability(c, layout) for c in fit]
    estimates = {}
    for suffix, rel in (("", reliabilities), ("-no-shrink", (None, None))):
        scores = [
            conditional_scores(
                c,
                raw,
                layout,
                valid,
                window=CFG.validation_window,
                stride=CFG.validation_stride,
                reliability=weight,
            )[0]
            for c, valid, weight in zip(fit, folds[::-1], rel, strict=True)
        ]
        pool = pooled_support_score(*scores)
        focus = [
            _refit_phase_components(c, raw, layout, parent, dict(enumerate(pool)))[1] for c in fit
        ]
        corrected = (
            (focus[0] + focus[1]) / 2
            if suffix
            else sum(x * w[:, :, None, None] / 2 for x, w in zip(focus, rel, strict=True))
        )
        for key, weight in [
            ("nominal", support_weight(pool, threshold)),
            ("positive", support_weight(pool, 0)),
            ("ungated", 1),
        ]:
            estimates[key + suffix] = (corrected * weight).sum(axis=0)
    return estimates


def exact_responses(raw, layout, parent, strong, weak, noise):
    """Use exact direction shapes and fit their signed amplitudes to sampled RAW."""
    sigma = np.sqrt(noise["read"] + noise["shot"] * np.maximum(parent, 1e-6))
    fields = np.stack((strong, weak), axis=-1)
    result = np.empty_like(parent, dtype=float)
    for c in range(3):
        measured = layout == c
        design = fields[c][measured] / sigma[c, measured, None]
        values = (raw[measured] - parent[c, measured]) / sigma[c, measured]
        coef = np.linalg.lstsq(design, values, rcond=1e-10)[0]
        result[c] = fields[c] @ coef
    return result


def rgbonly_truth_projection(weak, frequency, hessian, taper):
    xx, yy, _, _ = geometry(taper.shape)
    knots = _phase_bin_weights(
        xx, yy, frequency, 8, offset=_fixed_phase_offset(xx, yy, taper.shape, hessian)
    )
    basis = knots[:, :-1] - knots[:, -1:]
    weak = weak.reshape(3, -1).T
    result = {}
    for label, design in (("uniform", basis), ("exact-support", basis * taper.ravel()[:, None])):
        estimate = design @ np.linalg.lstsq(design, weak, rcond=1e-10)[0]
        result[label] = {
            "recovered_energy": float(np.sum(estimate * weak) / np.sum(weak**2)),
            "increment_RMS_DN16": float(np.sqrt(np.mean((estimate - weak) ** 2)) * 65535),
        }
    return result


def describe(two, one, weak, quiet, scale):
    estimate = (two - one) * scale
    return {
        "projection": float(np.sum(estimate * weak) / np.sum(weak**2)),
        "increment_RMS_DN16": float(np.sqrt(np.mean((estimate - weak) ** 2)) * 65535),
        "quiet_RMS_DN16": float(np.sqrt(np.mean((two[:, quiet] * scale) ** 2)) * 65535),
        "false_RMS_DN16": float(np.sqrt(np.mean((one[:, quiet] * scale) ** 2)) * 65535),
    }


def run():
    rows = []
    for profile in ("iso400", "iso6400"):
        settings = PLAN["settings"][profile]
        noise = PLAN["profiles"][profile]
        prior = ORIGINAL / ("projective400.json" if profile == "iso400" else "projective6400.json")
        for r in read_json(prior)["rows"]:
            i = r["case"]
            p, strong, both, f, h, quiet, _ = target(i, PLAN["geometry_seed"])
            taper = envelope(i, quiet.shape)
            np.testing.assert_array_equal(taper == 0, quiet)
            weak = both.astype(float) - strong
            outputs = []
            with np.load(checked(r["prediction"])) as saved:
                np.testing.assert_array_equal(saved["target"], both)
                cfa = saved["cfa"]
                for role, truth in enumerate((strong, both)):
                    seed = np.random.SeedSequence(
                        [PLAN["geometry_seed"], 1, i, int(profile == "iso6400"), role]
                    )
                    packed = RECIPE.corrupt(truth, cfa, np.random.default_rng(seed), noise)
                    if role:
                        np.testing.assert_array_equal(packed, saved["packed"])
                    raw, layout = _native_view(packed, cfa, RECIPE.QUERY)
                    corrections = {}
                    for label, footprint in (("uniform", None), ("exact-support", taper)):
                        corrections.update(
                            {
                                label + "-" + k: v
                                for k, v in compare(
                                    raw, layout, f, h, footprint, p, settings["threshold"], noise
                                ).items()
                            }
                        )
                    corrections["exact-shape-RAW"] = exact_responses(
                        raw, layout, p, strong - p, weak, noise
                    )
                    outputs.append(corrections)
                np.testing.assert_allclose(
                    p + outputs[1]["uniform-nominal"],
                    saved["oracle"],
                    atol=3e-8,
                    rtol=0,
                )
            rows.append(
                {
                    "case": i,
                    "profile": profile,
                    "kind": r["kind"],
                    "archive": r["prediction"],
                    "truth_projection": rgbonly_truth_projection(weak, f[1], h[1], taper),
                    "estimates": {
                        arm: describe(v, outputs[0][arm], weak, quiet, settings["scale"])
                        for arm, v in outputs[1].items()
                    },
                }
            )
            print(profile, i, r["kind"], flush=True)
    write_json(
        OUT / "diagnostic.json",
        {
            "source": reference(__file__),
            "previous_plan": reference(ORIGINAL / "plan.json"),
            "rows": rows,
        },
    )


if __name__ == "__main__":
    run()
