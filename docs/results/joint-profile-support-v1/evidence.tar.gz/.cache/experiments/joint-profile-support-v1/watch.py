"""Run the frozen report and independent audit when the exact worker closes."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path(".cache/experiments/joint-profile-support-v1").resolve()
launch = read_json(root/"launch.json")
path = root/"output/collection.json"
deadline = time.monotonic() + 3600
while not path.exists():
    owner = psutil.Process(launch["pid"])
    assert owner.create_time() == launch["create_time"] and owner.status() != psutil.STATUS_ZOMBIE
    if time.monotonic() > deadline:
        raise TimeoutError("Review observation deadline. No collector restart.")
    time.sleep(4)
work = root/"work"
os.sched_setaffinity(0,[6,7])
os.nice(2)
env = {**os.environ, "PYTHONPATH": f"{work}/scripts:{work}/src", "CUDA_VISIBLE_DEVICES": "",
       "OPENBLAS_NUM_THREADS": "2", "OMP_NUM_THREADS": "2"}
for label, script, args in [
    ("report",work/"scripts/report_joint_profile_support.py",[str(root/"plan.json")]),
    ("audit",root/"audit.py",[]),
]:
    command = [sys.executable,str(script),*args]
    with (root/(label+".log")).open("xb") as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    write_json(root/(label+"-return.json"), {"returncode": result.returncode,
               "command": command, "driver": reference(script), "collection": reference(path)})
    assert result.returncode == 0
