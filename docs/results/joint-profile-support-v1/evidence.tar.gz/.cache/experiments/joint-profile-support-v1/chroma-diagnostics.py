"""Measure exact per-channel wire response and centered chroma error."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def chroma(rgb):
    return rgb - rgb.mean(axis=0, keepdims=True)


root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
prior = read_json(checked(plan["adopted_collection"]))
roi = np.s_[..., 128:384, 128:384]
methods = ("square", "joint", "joint-veto")
tight_budget = min(plan["positive_quiet_RMS_budgets_DN16"])
held = {
    (r["profile"], r["placement"], r["source"], r["method"]): r
    for r in report["leave_one_geometry_out"]
    if r["budget_DN16"] == tight_budget
}
groups = defaultdict(list)
rows = []
for group, observed, old in zip(
    plan["groups"], collection["synthetic"], prior["synthetic"], strict=True
):
    assert group["id"] == observed["id"] == old["id"]
    profile, placement, source = [group[k] for k in ("profile", "placement", "source")]
    with np.load(checked(group["arrays"])) as files:
        target = files["target"].astype(np.float64)
        quiet = files["quiet"][roi]
    parent = np.load(checked(group["parent"])).astype(np.float64)
    target_delta = target[2] - target[1]
    target_power = np.sum(target_delta**2, axis=(1, 2))
    assert np.all(target_power > 0)
    fixed = {(m, 2) for m in methods}
    calibrated = {(m, held[profile, placement, source, m]["threshold"]) for m in methods}
    restored = defaultdict(list)
    for view, old_view in zip(observed["rows"], old["rows"], strict=True):
        with (
            np.load(checked(view["prediction"])) as current,
            np.load(checked(old_view["prediction"])) as control,
        ):
            for method, threshold in fixed | calibrated:
                name = f"{method}-t{threshold:g}"
                if method == "square" and threshold != 2:
                    prefix = (
                        "subharmonic" if old["changed"] else ("pooled" if threshold else "minimum")
                    )
                    value = control[f"{prefix}-t{threshold:g}"]
                else:
                    value = current[name]
                restored[method, threshold].append(value.astype(np.float64))
    for operating_point in ("t2", f"heldout-budget-{tight_budget:g}"):
        for method in ("parent", *methods):
            if method == "parent":
                prediction = parent
            else:
                setting = held[profile, placement, source, method]
                threshold, scale = (
                    (2, 1.0)
                    if operating_point == "t2"
                    else (setting["threshold"], setting["scale"])
                )
                prediction = parent.copy()
                prediction[roi] += scale * (np.stack(restored[method, threshold]) - parent[roi])
            delta = prediction[2] - prediction[1]
            increment_error = chroma(delta - target_delta)
            quiet_error = chroma((prediction[0] - target[0])[roi][..., quiet])
            quiet_error -= quiet_error.mean(axis=1, keepdims=True)
            data = {
                "weak_R_G_B_gain": (
                    np.sum(delta * target_delta, axis=(1, 2)) / target_power
                ).tolist(),
                "weak_increment_chroma_MSE_DN16": float(np.mean(increment_error**2) * 65535**2),
                "absent_quiet_centered_chroma_MSE_DN16": float(np.mean(quiet_error**2) * 65535**2),
            }
            key = (profile, placement, source, operating_point, method)
            groups[key].append(data)
            rows.append(
                {"id": group["id"], "operating_point": operating_point, "method": method, **data}
            )

means = defaultdict(list)
for (profile, placement, source, operating_point, method), items in groups.items():
    assert len(items) == 4
    means[profile, placement, operating_point, method].append(
        (
            np.mean([item["weak_R_G_B_gain"] for item in items], axis=0),
            np.sqrt(np.mean([item["weak_increment_chroma_MSE_DN16"] for item in items])),
            np.sqrt(np.mean([item["absent_quiet_centered_chroma_MSE_DN16"] for item in items])),
        )
    )
out = []
for (profile, placement, operating_point, method), items in means.items():
    assert len(items) == 8
    gain, weak, quiet = zip(*items, strict=True)
    out.append(
        {
            "profile": profile,
            "placement": placement,
            "operating_point": operating_point,
            "method": method,
            "mean_weak_R_G_B_gain": np.mean(gain, axis=0).tolist(),
            "mean_weak_increment_chroma_RMS_DN16": float(np.mean(weak)),
            "mean_absent_quiet_centered_chroma_RMS_DN16": float(np.mean(quiet)),
        }
    )
assert len(rows) == 1024 and len(out) == 32
write_json(
    root / "chroma-diagnostics.json",
    {
        "producer": reference(__file__),
        "report": reference(report_path),
        "rows": rows,
        "stratum_means": out,
        "scope": (
            "Exact camera-linear target difference, with per-color projection over the full field. Chroma removes"
            " the RGB mean of each pixel. Quiet no-wire chroma also removes spatial mean within each color."
            " Mean RMS pools squared errors across CFA layouts within each geometry and averages eight geometries."
        ),
    },
)
print(len(rows), len(out))
