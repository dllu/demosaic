"""Test a distant same-direction guide on an exact weak-wire and gap pair."""

import math
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.noise import add_noise, variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / "scene-context-extent-v1/collection.json"
SIDE = 768
BOX = (256, 256, 256, 256)
ROI = (48, 48, 160, 160)
DEVICE = "cuda"
ARMS = ("local", "neutral", "aligned", "orthogonal")
PRIORS = {
    "iso400": {"shot": 8e-5, "read": 2.56e-8, "exposure": 1.0},
    "iso6400": {"shot": 0.00128, "read": 6.5536e-6, "exposure": 1.0},
}


def smoothstep(value):
    value = value.clamp(0, 1)
    return value.square() * (3 - 2 * value)


def ribbon(distance, width):
    return torch.exp(-0.5 * (distance / width).square()) * smoothstep(4 - distance.abs() / width)


def pattern(geometry):
    axis = torch.arange(SIDE, dtype=torch.float32) - (SIDE - 1) / 2
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    angle = (geometry * 13 + 17) * math.pi / 180
    trans = math.cos(angle) * y - math.sin(angle) * x - (geometry % 4 - 1.5) * 4
    travel = math.sin(angle) * y + math.cos(angle) * x
    radius = torch.maximum(x.abs(), y.abs())
    inside = smoothstep((123 - radius) / 24)
    outside = smoothstep((radius - 165) / 32) * smoothstep((364 - radius) / 16)
    tint = torch.tensor([-0.45, 1.0, -0.32])[:, None, None]
    mean = torch.tensor([0.26, 0.29, 0.32])[:, None, None]
    base = mean + 0.015 * y / SIDE + 0.012 * x / SIDE
    strong = 0.039 * inside * ribbon(travel - 7.7, 1.55)
    absent = base + tint * strong
    present = absent + tint * (0.0055 * inside * ribbon(trans, 1.12))
    aligned = absent + tint * (0.135 * outside * ribbon(trans, 2.8))
    orthogonal = absent + tint * (0.135 * outside * ribbon(travel, 2.8))
    quiet = (travel - 7.7).abs() >= 8
    return absent, present, aligned, orthogonal, quiet


def query(frame, *, packed):
    factor = 2 if packed else 1
    x, y, w, h = [v // factor for v in BOX]
    return frame[..., y:y+h, x:x+w]


def observe(geometry, prior, seed):
    absent, present, aligned, orthogonal, quiet = pattern(geometry)
    bayer = tuple(PATTERNS)[geometry % 4]
    arrays, _ = paired_observation(absent[None], present[None], prior, [bayer],
                                   torch.ones(1,3), torch.eye(3)[None], seed)
    arrays={key:torch.from_numpy(arrays[key]) for key in ("packed","variance","colors","wb","matrix","target")}
    local={k:query(v,packed=k!="target") if k in ("packed","variance","target") else v for k,v in arrays.items()}
    neutral=arrays["packed"]
    change_fields={"neutral":neutral}
    for j,(name,truth) in enumerate((("aligned",aligned),("orthogonal",orthogonal))):
        support=mosaic((truth!=absent).any(0)[None,None].expand(1,3,-1,-1).float(),arrays["colors"][0]).bool()[0]
        guide=mosaic(truth[None],arrays["colors"][0])
        simulated=add_noise(guide,prior["shot"],prior["read"],black_level=.03,
                            generator=torch.Generator().manual_seed(seed+17+19*j))[0]
        changed=torch.where(support,simulated,neutral)
        assert torch.equal(query(changed,packed=True),local["packed"])
        assert torch.equal(changed[:,~support],neutral[:,~support])
        assert (changed!=neutral).any()
        change_fields[name]=changed
    quiet=query(quiet,packed=False)
    return local, change_fields, quiet, bayer


def render_data(local, quiet, prediction):
    x,y,w,h=ROI
    region=np.s_[..., y:y+h, x:x+w]
    t=local["target"].cpu().numpy().astype(np.float64)[region]
    p=prediction.cpu().numpy().astype(np.float64)[region]
    q=quiet.numpy()[region]
    d=t[1]-t[0]
    e=p[1]-p[0]
    f=p[0]-t[0]
    use=(np.abs(d).max(0)>1e-8)&q
    denom=np.sum(d[:,q]**2)
    assert denom>0 and use.any() and q.any()
    return {
        "increment_projection":float(np.sum(e[:,q]*d[:,q])/denom),
        "false_projection":float(np.sum(f[:,q]*d[:,q])/denom),
        "quiet_RMS_DN16":float(65535*np.sqrt(np.mean(f[:,q]**2))),
        "wire_support_increment_RMS_DN16":float(65535*np.sqrt(np.mean((e[:,use]-d[:,use])**2))),
        "all_quiet_increment_RMS_DN16":float(65535*np.sqrt(np.mean((e[:,q]-d[:,q])**2))),
        "quiet_pixels":int(q.sum()),
        "wire_pixels":int(use.sum()),
    }


@torch.inference_mode()
def main():
    os.sched_setaffinity(0,[6,7])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1, 6*2**30/torch.cuda.get_device_properties(0).total_memory))
    source=read_json(ARCHIVE)
    bound=source["checkpoint"]
    plan={"producer":reference(__file__),"checkpoint":bound,"prior_evidence":reference(ARCHIVE),
          "arms":ARMS,"priors":PRIORS,"geometries":list(range(8)),"repeats":[0,1],
          "scene_native_size":SIDE,"query_native_box":BOX,"ROI_xywh":ROI,"exposure":1,
          "scope":"Exact constructed targets. Weak present/absent pair uses coupled physical noise with independent repeats. Outer guide changes disjoint RAW locations beyond the fixed crop. Each arm shares byte-identical packed query, variance and camera inputs for each role. Local is the same trained trunk with the spatial adapter disabled. The forward may see the entire input; this is a causal intervention, not withheld validation."}
    write_json(ROOT/"plan.json",plan)
    model,payload=load_scene_checkpoint(checked(bound),device=DEVICE,weights="ema",expected_sha256=bound["sha256"])
    assert payload["step"]==2000 and model.mode=="spatial"
    del payload
    output=ROOT/"cases"
    output.mkdir()
    rows=[]
    began=time.monotonic()
    with ieee_fp32():
        for name,prior in PRIORS.items():
            model.base.set_noise(prior["shot"],prior["read"])
            for geometry in plan["geometries"]:
                for repeat in plan["repeats"]:
                    case=f"{name}-g{geometry}-r{repeat}"
                    seed=20261118000+repeat*100+geometry+list(PRIORS).index(name)*10000
                    local, scenes, quiet, bayer=observe(geometry,prior,seed)
                    arguments=[local[k].cuda() for k in ("packed","variance","colors","wb","matrix")]
                    records={}
                    saved={}
                    for arm in ARMS:
                        model.mode="none" if arm=="local" else "spatial"
                        encoded=None if arm=="local" else [
                            model.encode_scene(field.cuda(),arguments[2][j],arguments[3][j],arguments[4][j])
                            for j,field in enumerate(scenes[arm])
                        ]
                        prediction=model(*arguments,scene=encoded,boxes_xywh=[BOX,BOX])
                        assert torch.isfinite(prediction).all()
                        records[arm]=render_data(local,quiet,prediction)
                        if repeat==0 and geometry in (0,4):
                            saved[arm]=prediction.cpu().numpy()
                    if saved:
                        filename=output/f"{case}.npz"
                        with filename.open("xb") as f:
                            np.savez_compressed(f, **{k:v.numpy() for k,v in local.items()}, **saved)
                        retained=reference(filename)
                    else:
                        retained=None
                    row={"case":case,"geometry":geometry,"repeat":repeat,"noise":name,"seed":seed,
                         "Bayer":bayer,"metrics":records,"retained":retained,
                         "local_fingerprints":{k:fingerprint(v) for k,v in local.items()},
                         "context_fingerprints":{k:fingerprint(v) for k,v in scenes.items()}}
                    rows.append(row)
                    write_json(output/f"{case}.json",row)
                    print(len(rows),case,flush=True)
    write_json(ROOT/"result.json",{"plan":reference(ROOT/"plan.json"),"cases":rows,"seconds":time.monotonic()-began})


if __name__=="__main__":
    main()
