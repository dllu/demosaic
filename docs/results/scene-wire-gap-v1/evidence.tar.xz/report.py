"""Score and render the paired whole-scene wire and gap intervention."""

from pathlib import Path
from statistics import mean

import numpy as np
from report_scene_wave_guides import native_board

import probe
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
OUT = ROOT/"review"


def score_all(result, plan):
    rows=result["cases"]
    assert len(rows)==32 and len({r["case"] for r in rows})==32
    values=[]
    for profile in plan["priors"]:
        cases=[r for r in rows if r["noise"]==profile]
        assert len(cases)==16 and len({r["geometry"] for r in cases})==8
        for arm in plan["arms"]:
            data=[r["metrics"][arm] for r in cases]
            values.append({
                "profile":profile,"arm":arm,"cases":len(cases),
                "response_percent":mean(r["increment_projection"] for r in data)*100,
                "mean_absolute_false_projection_percent":mean(abs(r["false_projection"]) for r in data)*100,
                "quiet_RMS_DN16":mean(r["quiet_RMS_DN16"] for r in data),
                "wire_support_increment_RMS_DN16":mean(r["wire_support_increment_RMS_DN16"] for r in data),
            })
    return values


def verify_retained(case, arrays):
    quiet=probe.query(probe.pattern(case["geometry"])[-1],packed=False).numpy()[48:208,48:208]
    target=arrays["target"][...,48:208,48:208].astype(np.float64)
    desired=target[1]-target[0]
    selected=quiet&(np.abs(desired).max(0)>1e-8)
    template=desired[:,quiet].ravel()
    energy=float(np.dot(template,template))
    for arm,value in case["metrics"].items():
        rgb=arrays[arm][...,48:208,48:208].astype(np.float64)
        measured=rgb[1]-rgb[0]
        absolute=rgb[0]-target[0]
        expected={
            "increment_projection":np.dot(measured[:,quiet].ravel(),template)/energy,
            "false_projection":np.dot(absolute[:,quiet].ravel(),template)/energy,
            "quiet_RMS_DN16":65535*np.linalg.norm(absolute[:,quiet])/np.sqrt(3*int(quiet.sum())),
            "wire_support_increment_RMS_DN16":
                65535*np.linalg.norm((measured-desired)[:,selected])/np.sqrt(3*int(selected.sum())),
        }
        for key,x in expected.items():
            np.testing.assert_allclose(x,value[key],rtol=3e-13,atol=1e-14)


def main():
    result=read_json(ROOT/"result.json")
    plan=read_json(checked(result["plan"]))
    assert plan["producer"]==reference(ROOT/"probe.py")
    OUT.mkdir()
    boards=[]
    for case in result["cases"]:
        if case["retained"] is None:
            continue
        with np.load(checked(case["retained"]),allow_pickle=False) as decompressed:
            arrays={k:decompressed[k] for k in decompressed.files}
        assert {k:fingerprint(arrays[k]) for k in case["local_fingerprints"]}==case["local_fingerprints"]
        verify_retained(case,arrays)
        for role, index in (("gap",0),("wire",1)):
            local={k:arrays[k][index:index+1] for k in ("packed","colors","wb","matrix")}
            values=[noisy_malvar(local)[0], *[arrays[k][index] for k in plan["arms"]], arrays["target"][index]]
            name=case["case"]+"-"+role
            meta={"case":case["case"],"role":role,"noise":plan["priors"][case["noise"]],
                  "checkpoint":plan["checkpoint"],"conditioning":case["Bayer"],"seed":case["seed"],
                  "source":"Exact constructed wire and gap, generation bound to the collection plan."}
            labels=("Noisy Malvar","Local trunk","Neutral scene","Aligned guide","Orthogonal guide","Exact GT")
            boards.append(native_board(OUT,name,values,local,meta,labels=labels,triplet_indices=(0,3,5),exposure=1))
            if role=="wire":
                boards.append(native_board(OUT,name+"-contrast8",values,local,meta,
                                          labels=labels,triplet_indices=(0,3,5),exposure=1,contrast=8))
    assert len(boards)==12
    summary=score_all(result,plan)
    write_json(OUT/"result.json",{"source":reference(__file__),"collection":reference(ROOT/"result.json"),
        "summary":summary,"boards":boards,"independently_checked_saved_cases":4,"native_viewing_complete":False})
    for row in summary:
        print(row)


if __name__=="__main__":
    main()
