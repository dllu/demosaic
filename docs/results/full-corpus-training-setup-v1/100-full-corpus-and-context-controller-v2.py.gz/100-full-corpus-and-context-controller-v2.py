"""Execute the declared compute allocation with exact stateful100k continuation."""
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.experiments.runtime import owner_identity

plan_path=Path(sys.argv[1]);plan=read_json(plan_path);base_root=Path(plan['root']);root=Path(plan.get('allocation_root',plan['root']));root.mkdir(exist_ok=True)
(root/'production-controller.claim').open('x').close()
os.sched_setaffinity(0,list(range(12,20)))
assert read_json(base_root/'profile-result.json')['all_cases_succeeded']
assert read_json(checked(plan['operator_retention_addendum']))['retained_step8']
ctx_plan=read_json(checked(plan['context_plan']))
assert read_json(checked(plan['context_preflight']))['all_modes_passed']
results=[]
for index,stage in enumerate(plan['compute_schedule']):
    stage_name=f'{index:02d}-{stage["kind"]}-{stage["arm"]}'
    while (psutil.virtual_memory().available<plan['minimum_start_RAM_GiB']*2**30
           or shutil.disk_usage(root).free<plan['minimum_disk_GiB']*2**30):
        write_json(root/'production-progress.json',{'owner':owner_identity(),'stage':stage_name,
                   'status':'waiting-for-RAM-or-disk','completed_stages':results},replace=True)
        time.sleep(10)
    if stage['kind']=='scale':
        command=[sys.executable,str(checked(plan['worker_script'])),str(plan_path),stage['arm'],
                 '--updates',str(stage['updates'])]
        work=Path(plan['work'])
    else:
        work=Path(ctx_plan['work'])
        output=work/'artifacts/train'/stage['arm']
        command=[sys.executable,str(checked(ctx_plan['training_script'])),'train',plan['context_plan']['path'],
                 str(output),'--mode',stage['arm']]
    env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),CUBLAS_WORKSPACE_CONFIG=':4096:8',
             OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
    began=time.time()
    with (root/(stage_name+'.log')).open('x')as log:
        child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        identity={'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,
                  'controller':owner_identity(),'production_plan':reference(plan_path),'stage':stage_name}
        write_json(root/(stage_name+'-launch.json'),identity)
        write_json(root/'production-progress.json',{'owner':owner_identity(),'stage':stage_name,
                   'status':'running','child':identity,'completed_stages':results},replace=True)
        try:code=child.wait(timeout=stage['maximum_seconds'])
        except subprocess.TimeoutExpired:
            child.terminate()
            try:child.wait(timeout=30)
            except subprocess.TimeoutExpired:child.kill();child.wait()
            code=124
    result={'stage':stage_name,'returncode':code,'seconds':time.time()-began,
            'production_plan':reference(plan_path),'owner':owner_identity()}
    write_json(root/(stage_name+'-result.json'),result);results.append(result)
    if code:break
write_json(root/'production-result.json',{'all_stages_succeeded':len(results)==len(plan['compute_schedule'])and all(r['returncode']==0 for r in results),
           'stages':results,'production_plan':reference(plan_path),'controller':reference(__file__),
           'scope':'Declared100k/control20k/three-context-arm allocation complete or stopped on explicit failure. No automatic retry, reset, quality stopping or new horizon. Post-training independent source/crop/noise/quality/native review remains required.'})
