"""Append an independent-review index without changing original publication bytes."""
import gzip
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
verification = repo / '.cache/scene-scale-independent-setup-verification-v1.json'
assert read_json(verification)['all_passed']
sources = [repo / '.cache' / name for name in [
    'publish-scene-scale-setup-v1.log', 'verify-scene-scale-setup-v1.py',
    'verify-scene-scale-setup-v1.log', 'scene-scale-independent-setup-verification-v1.json',
    'seal-scene-scale-setup-v1.py']]
for family in ['whole-scene-context-training-setup-v1', 'full-corpus-training-setup-v1']:
    destination = repo / 'docs/results' / family
    archives = []
    for index, source in enumerate(sources):
        data = source.read_bytes()
        target = destination / f'verification-{index:02d}-{source.name}.gz'
        with target.open('xb') as stream:
            stream.write(gzip.compress(data, mtime=0))
        assert gzip.decompress(target.read_bytes()) == data
        archives.append({'original': reference(source), 'published': reference(target), 'decompressed_bytes_exact': True})
    write_json(destination / 'independent-review.json', {
        'publication': reference(destination / 'publication.json'), 'archives': archives,
        'all_passed': True, 'scope': 'Exact archive/source-member audit, source-order prefix, three actual profile witnesses, both scene qualification versions, CPU model/EMA/Adam1000 state and actual source/crop/condition accounting.153 current local documentation links checked. No new forward or quality score. Missing discarded6-step checkpoint stays explicitly missing.'})
    print(family)
