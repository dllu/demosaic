"""Declare full-corpus20k/100k continuations before profiling or production."""
from pathlib import Path
import yaml

from demosaic.experiments.artifacts import read_json, reference, write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v1'
assert not root.exists();root.mkdir()
base=yaml.safe_load((repo/'configs/quality-v120-photo-epoch-v135.yaml').read_text())
for name,horizon in [('control20k',20000),('long100k',100000)]:
    config=dict(base)
    config.pop('photo_epoch_order');config.pop('photo_epoch_order_sha256')
    config.update(steps=horizon,run=str(root/'runs'/name),training_execution='throughput-v1',workers=0,
                  paired_workers=0,raw_clean_workers=0,validation_images=32,checkpoint_every=1000,
                  trace_observations=True,log_every=25,
                  experiment_notes='Full-model V120 Small continuation from untouched EMA. Cleaned90778/33, shuffled ordinary-photo epochs,5% reviewed, bin4->geometry->area2, native/paired25% each, flat/synthetic retained, fixed loss.100k long horizon versus fresh matched20k annealed control; checkpoints20/50/100k are progress along one trajectory, not schedule-isolated compute effects. Retain complete optimizer/EMA/RNG/order/global indices across planned resumes. Throughput execution and bounded worker choice qualified prospectively.32-photo lightweight monitoring; broad native/weak/quiet/camera/standingGFX review at useful milestones. No predeclared image-quality gain.')
    (root/(name+'-reader.yaml')).write_text(yaml.safe_dump(config,sort_keys=True))
write_json(root/'recipe-admission.json',{'source':reference(repo/'configs/quality-v120-photo-epoch-v135.yaml'),
           'recipes':[reference(root/(n+'-reader.yaml'))for n in ['control20k','long100k']],
           'parent':base['initialize_parent'],'reviewed_quota':.05,'architecture_unchanged':True,
           'scope':'New scaling study uses existing verified photographic-epoch machinery and cleaned90778 cohort, not the older90781 membership. Full100k horizon with intended20/50/100k milestones, independent20k control. No new training/quality evaluation. Worker/execution profile follows before production. Original V134/V135 queued receipts/checks retained, no completed equivalent checkpoint found.'})
print(root)
