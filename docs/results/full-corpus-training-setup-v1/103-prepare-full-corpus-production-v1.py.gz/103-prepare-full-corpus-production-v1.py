"""Choose the measured execution policy and declare both training objectives."""
import json
import shutil
from pathlib import Path
import yaml

from demosaic.experiments.artifacts import read_json,reference,verify_plan,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v3'
profile_plan=read_json(root/'plan.json');verify_plan(profile_plan)
assert read_json(root/'profile-result.json')['all_cases_succeeded']
results={name:read_json(root/'profiles'/name/'result.json')for name in ['strict0','fast0','fast2']}
witnesses=results['fast0']['sampled_input_witnesses_outside_measurement']
assert all(r['sampled_input_witnesses_outside_measurement']==witnesses for r in results.values())
workers=2 if results['fast2']['patches_per_second']>1.05*results['fast0']['patches_per_second']else 0
work=Path(profile_plan['work']);worker=work/'scripts/run_full_corpus_continuation.py'
assert not worker.exists();shutil.copyfile(repo/'scripts/run_full_corpus_continuation.py',worker)
configs={}
for name in ['long100k','control20k','operator-check']:
    base='long100k'if name=='operator-check'else name
    config=yaml.safe_load((root/(base+'-bound.yaml')).read_text())
    config.update(training_execution='throughput-v1',workers=workers,paired_workers=workers,raw_clean_workers=workers,
                  trace_observations=False)
    if name=='operator-check':config['run']=str(work/'artifacts/train/operator-check')
    path=root/(name+'-production.yaml');path.write_text(yaml.safe_dump(config,sort_keys=True));configs[name]=reference(path)
ctx=repo/'.cache/experiments/whole-scene-context-ablation-v1'
assert read_json(ctx/'preflight/result.json')['all_modes_passed']
approved=Path(yaml.safe_load((root/'long100k-bound.yaml').read_text())['manifest'])
identities={json.loads(line)['id']for line in approved.read_text().splitlines()if line.strip()}
for family in ['train','development']:
    items=[json.loads(line)for line in (ctx/f'manifest-{family}.jsonl').read_text().splitlines()if line.strip()]
    assert {r['id']for r in items}<=identities
write_json(ctx/'cleaned-cohort-membership-addendum.json',{'plan':reference(ctx/'plan.json'),
           'approved90778_manifest':reference(approved),'all_admitted_context_sources_still_approved':True,
           'scope':'All native>=768 context sources remain in the later cleaned90778 cohort. The3 later-excluded90781 photos have short axes756/702/557 and were already ineligible. Original context plan/source/preflight bytes unchanged.'})
plan={'root':str(root),'work':str(work),'profile_plan':reference(root/'plan.json'),
      'parent':profile_plan['parent'],'DINO_sha256':profile_plan['DINO_sha256'],
      'worker_script':reference(worker),'configs':configs,'chosen_workers':workers,
      'execution_policy':'throughput-v1','profile_results':{k:reference(root/'profiles'/k/'result.json')for k in results},
      'sampled_input_witnesses_exact_across_execution_and_workers':True,
      'retained_steps':[1000,5000,10000,20000,50000,100000],
      'minimum_start_RAM_GiB':52,'minimum_disk_GiB':96,
      'context_plan':reference(ctx/'plan.json'),'context_preflight':reference(ctx/'preflight/result.json'),
      'compute_schedule':[
          {'kind':'scale','arm':'long100k','updates':1000,'maximum_seconds':7200},
          *[{'kind':'context','arm':mode,'updates':2000,'maximum_seconds':21600}for mode in ['none','pooled','spatial']],
          {'kind':'scale','arm':'control20k','updates':20000,'maximum_seconds':64800},
          {'kind':'scale','arm':'long100k','updates':99000,'maximum_seconds':259200}],
      'scope':'Two additive research tracks: a100k full V120/90778 epoch continuation with a fresh20k matched-data control, and the separately qualified three-arm whole-scene context probe. Long100k first runs1000 updates, then resumes exactly the saved Adam/EMA/RNG/source-order state after context probes/control; its100k LR horizon never resets. No quality-based early stopping, no automatic retries or stale-job restarts. Save immutable20/50/100k states and complete optimizer states. Training/crop/corruption coverage and actual runtime recorded separately. All photos/protected families remain under the existing cleaned source/holdout policy. No trained-quality or end-to-end speed claim from warm short profiling.'}
write_json(root/'production-plan.json',plan)
print('Production admitted:',workers,'workers;100k first1000,context3x2000,matched20k,100k resume99000')
