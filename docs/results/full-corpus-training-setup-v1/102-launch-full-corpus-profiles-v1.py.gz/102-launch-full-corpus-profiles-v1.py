import os
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v1'
assert not (root/'profile-launch.json').exists()
command=[sys.executable,str(repo/'.cache/full-corpus-profile-controller-v1.py'),str(root)]
with (root/'profile-controller.log').open('x')as log:
    child=subprocess.Popen(command,env=dict(os.environ,PYTHONPATH=str(repo/'src')),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record={'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,
        'plan':reference(root/'plan.json'),'launcher':reference(__file__)}
write_json(root/'profile-launch.json',record)
print(record)
