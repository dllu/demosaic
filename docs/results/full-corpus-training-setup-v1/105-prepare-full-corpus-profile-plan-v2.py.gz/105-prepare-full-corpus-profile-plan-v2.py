"""Correct the zero-update frozen-worktree run path; adopt original epoch bytes."""
from pathlib import Path
import yaml

from demosaic.experiments.artifacts import freeze_sources, read_json, reference, verify_plan, write_json

repo=Path.cwd();old=repo/'.cache/experiments/full-corpus-scaling-v1'
root=repo/'.cache/experiments/full-corpus-scaling-v2'
assert not root.exists()
failure=read_json(old/'profile-result.json');assert not failure['all_cases_succeeded']
assert failure['cases']==[{'case':'strict0','returncode':1,'seconds':failure['cases'][0]['seconds']}]
assert 'Output must be inside' in (old/'strict0-profile.log').read_text()
assert not (old/'profiles/strict0/run/last.pt').exists()
root.mkdir()
original=read_json(old/'plan.json')
for name in ['control20k','long100k']:
    config=yaml.safe_load((old/(name+'-bound.yaml')).read_text())
    config['run']=str(root/'work/artifacts/train'/name)
    (root/(name+'-bound.yaml')).write_text(yaml.safe_dump(config,sort_keys=True))
work,files=freeze_sources(repo,root,entries=('profile_full_corpus_training.py','profile_raw_kernel_inference.py'))
profiles={}
for case,policy,workers in [('strict0','deterministic-v1',0),('fast0','throughput-v1',0),('fast2','throughput-v1',2)]:
    config=yaml.safe_load((root/'long100k-bound.yaml').read_text())
    config.update(run=str(work/'artifacts/profiles'/case),training_execution=policy,workers=workers,
                  paired_workers=workers,raw_clean_workers=workers,trace_observations=False,source_loss_every=0)
    path=root/(case+'-profile.yaml');path.write_text(yaml.safe_dump(config,sort_keys=True));profiles[case]=reference(path)
plan={**original,'root':str(root),'work':str(work),'frozen_files':files,
      'profile_script':reference(work/'scripts/profile_full_corpus_training.py'),'profiles':profiles,
      'previous_zero_update_failure':reference(old/'profile-result.json'),
      'scope':original['scope']+' Corrected run locations inside the new frozen worktree. Original failed admission/source/logs unchanged; no model/optimizer/sensor draws occurred before that output-path refusal.'}
plan['inputs']=[original['parent'],*profiles.values(),*original['epochs'].values(),
               reference(old/'order20k/ordinary-photo-order.npy'),reference(old/'order100k/ordinary-photo-order.npy'),
               reference(root/'control20k-bound.yaml'),reference(root/'long100k-bound.yaml'),
               reference(old/'profile-result.json'),reference(old/'strict0-profile.log')]
config=yaml.safe_load((root/'long100k-bound.yaml').read_text())
plan['inputs'] += [reference(config[field])for field in ['manifest','reviewed_roi_catalogue','photo_sampling_reference_manifest','paired_manifest','raw_clean_manifest','validation_manifest']]
write_json(root/'plan.json',plan);verify_plan(plan)
write_json(root/'path-correction-addendum.json',{'original_plan':reference(old/'plan.json'),
           'original_failure':reference(old/'profile-result.json'),'new_plan':reference(root/'plan.json'),
           'source':reference(__file__),'scope':'The trainer rooted in a frozen worktree correctly refused an outer run directory before model construction. New paths use work/artifacts; all original epoch/header bytes adopted. No silent restart, previous numeric trial or original receipt overwritten.'})
print(root)
