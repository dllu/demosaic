"""Run the three declared execution/loader checks sequentially, without retry."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import owner_identity

root=Path(sys.argv[1]);plan=read_json(root/'plan.json');verify_plan(plan)
os.sched_setaffinity(0,list(range(12,20)));os.nice(10)
assert psutil.virtual_memory().available > plan['minimum_start_RAM_GiB']*2**30
(root/'profile-controller.claim').open('x').close()
env=dict(os.environ,PYTHONPATH=plan['work']+'/src:'+plan['work']+'/scripts',
         CUBLAS_WORKSPACE_CONFIG=':4096:8',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
results=[]
for case in ['strict0','fast0','fast2']:
    command=[sys.executable,str(checked(plan['profile_script'])),str(root/'plan.json'),case]
    began=time.time()
    with (root/(case+'-profile.log')).open('x')as log:
        child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        write_json(root/(case+'-profile-launch.json'),{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),
                   'command':command,'controller':owner_identity(),'plan':reference(root/'plan.json')})
        code=child.wait()
    results.append({'case':case,'returncode':code,'seconds':time.time()-began})
    write_json(root/'profile-progress.json',{'owner':owner_identity(),'cases':results},replace=True)
    if code:break
write_json(root/'profile-result.json',{'all_cases_succeeded':len(results)==3 and all(r['returncode']==0 for r in results),
           'cases':results,'plan':reference(root/'plan.json'),'script':reference(__file__),
           'scope':'Discarded current-model execution/loader checks only. No automatic restart. Production must wait for successful terminal receipt and input-witness comparison.'})
