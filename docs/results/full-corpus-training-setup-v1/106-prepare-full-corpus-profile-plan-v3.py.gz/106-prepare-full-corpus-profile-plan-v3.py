"""Include the full trainer's packaging/license snapshot inputs, preserving failures."""
import shutil
from pathlib import Path
import yaml

from demosaic.experiments.artifacts import freeze_sources,read_json,reference,verify_plan,write_json

repo=Path.cwd();old=repo/'.cache/experiments/full-corpus-scaling-v2'
root=repo/'.cache/experiments/full-corpus-scaling-v3';assert not root.exists()
failure=read_json(old/'profile-result.json');assert not failure['all_cases_succeeded']
assert 'pyproject.toml' in (old/'strict0-profile.log').read_text()
assert not (old/'work/artifacts/profiles/strict0/last.pt').exists()
original=read_json(old/'plan.json');root.mkdir()
work,files=freeze_sources(repo,root,entries=('profile_full_corpus_training.py','profile_raw_kernel_inference.py'))
metadata=['pyproject.toml','uv.lock','third_party/gaussian/Noise2VST-LICENSE',
          'third_party/gaussian/KAIR-LICENSE','third_party/dinov3/LICENSE.md','configs/evaluation.yaml']
for name in metadata:
    target=work/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/name,target);files[str(target)]=reference(target)['sha256']
for name in ['control20k','long100k']:
    config=yaml.safe_load((old/(name+'-bound.yaml')).read_text())
    config.update(run=str(work/'artifacts/train'/name),validation_protocol=str(work/'configs/evaluation.yaml'))
    (root/(name+'-bound.yaml')).write_text(yaml.safe_dump(config,sort_keys=True))
profiles={}
for case,policy,workers in [('strict0','deterministic-v1',0),('fast0','throughput-v1',0),('fast2','throughput-v1',2)]:
    config=yaml.safe_load((root/'long100k-bound.yaml').read_text())
    config.update(run=str(work/'artifacts/profiles'/case),training_execution=policy,workers=workers,
                  paired_workers=workers,raw_clean_workers=workers,trace_observations=False,source_loss_every=0)
    path=root/(case+'-profile.yaml');path.write_text(yaml.safe_dump(config,sort_keys=True));profiles[case]=reference(path)
plan={**original,'root':str(root),'work':str(work),'frozen_files':files,
      'profile_script':reference(work/'scripts/profile_full_corpus_training.py'),'profiles':profiles,
      'previous_metadata_failure':reference(old/'profile-result.json'),
      'scope':original['scope']+' Both prior full-trainer setup refusals occurred before model construction. This complete worktree also binds pyproject/lock/third-party license/protocol metadata required by the core trainer snapshot. Prior source/failure bytes retained; no numerical trial restarted.'}
base=repo/'.cache/experiments/full-corpus-scaling-v1'
plan['inputs']=[original['parent'],*profiles.values(),*original['epochs'].values(),
               reference(base/'order20k/ordinary-photo-order.npy'),reference(base/'order100k/ordinary-photo-order.npy'),
               reference(root/'control20k-bound.yaml'),reference(root/'long100k-bound.yaml'),
               reference(old/'profile-result.json'),reference(old/'strict0-profile.log'),
               *[reference(work/name)for name in metadata]]
config=yaml.safe_load((root/'long100k-bound.yaml').read_text())
plan['inputs'] += [reference(config[k])for k in ['manifest','reviewed_roi_catalogue','photo_sampling_reference_manifest','paired_manifest','raw_clean_manifest','validation_manifest']]
write_json(root/'plan.json',plan);verify_plan(plan)
write_json(root/'metadata-correction-addendum.json',{'prior_plan':reference(old/'plan.json'),
            'prior_failure':reference(old/'profile-result.json'),'new_plan':reference(root/'plan.json'),
            'added_metadata':[reference(work/name)for name in metadata],
            'scope':'Full trainer source snapshot needs project/lock/license/protocol bytes in addition to Python import closure. Source admission now complete; original source/receipts unmodified. No model forward or optimizer update preceded either setup refusal.'})
print(root)
