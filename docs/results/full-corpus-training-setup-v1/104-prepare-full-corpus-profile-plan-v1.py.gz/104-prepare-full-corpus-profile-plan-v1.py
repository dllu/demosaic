"""Bind epoch horizons, current model and fresh execution/loader profiling cases."""
from pathlib import Path
import numpy as np
import yaml

from demosaic.experiments.artifacts import freeze_sources, read_json, reference, verify_plan, write_json

repo=Path.cwd();root=repo/'.cache/experiments/full-corpus-scaling-v1'
assert not (root/'plan.json').exists()
headers={name:root/f'order{horizon//1000}k/photo-epoch-order.json'for name,horizon in [('control20k',20000),('long100k',100000)]}
for name,path in headers.items():
    header=read_json(path);assert header['summary']['epoch_order_unique_photos']==90778
    config=yaml.safe_load((root/(name+'-reader.yaml')).read_text())
    config['photo_epoch_order']=str(path);config['photo_epoch_order_sha256']=reference(path)['sha256']
    (root/(name+'-bound.yaml')).write_text(yaml.safe_dump(config,sort_keys=True))
a=np.load(root/'order20k/ordinary-photo-order.npy',mmap_mode='r');b=np.load(root/'order100k/ordinary-photo-order.npy',mmap_mode='r')
np.testing.assert_array_equal(a,b[:len(a)])
work,files=freeze_sources(repo,root,entries=('profile_full_corpus_training.py','profile_raw_kernel_inference.py'))
profiles={}
for case,policy,workers in [('strict0','deterministic-v1',0),('fast0','throughput-v1',0),('fast2','throughput-v1',2)]:
    config=yaml.safe_load((root/'long100k-bound.yaml').read_text())
    config.update(run=str(root/'profiles'/case/'run'),training_execution=policy,workers=workers,
                  paired_workers=workers,raw_clean_workers=workers,trace_observations=False,source_loss_every=0)
    path=root/(case+'-profile.yaml');path.write_text(yaml.safe_dump(config,sort_keys=True));profiles[case]=reference(path)
parent=reference('/mnt/external/demosaic/models/v120-final20000.pt')
inputs=[parent,*profiles.values(),*[reference(p)for p in headers.values()],
        reference(root/'order20k/ordinary-photo-order.npy'),reference(root/'order100k/ordinary-photo-order.npy'),
        reference(root/'control20k-bound.yaml'),reference(root/'long100k-bound.yaml')]
sourceconfig=yaml.safe_load((root/'long100k-bound.yaml').read_text())
for field in ['manifest','reviewed_roi_catalogue','photo_sampling_reference_manifest','paired_manifest','raw_clean_manifest','validation_manifest']:
    inputs.append(reference(sourceconfig[field]))
plan={'root':str(root),'work':str(work),'python':str(repo/'.venv/bin/python'),'frozen_files':files,
      'profile_script':reference(work/'scripts/profile_full_corpus_training.py'),'profiles':profiles,
      'parent':parent,'DINO_sha256':'691963f0f796aac860d818d59d9d14287a4675612829fbe9467c7f5df8ce5b14',
      'epochs':{k:reference(v)for k,v in headers.items()},'twenty_k_source_prefix_exact':True,
      'source_coverage':{k:read_json(v)['summary']for k,v in headers.items()},
      'minimum_start_RAM_GiB':52,'minimum_runtime_RAM_GB':32,'maximum_GPU_GiB':16,'minimum_disk_GiB':96,
      'maximum_profile_seconds':1800,'inputs':inputs,
      'scope':'Full-restoration scaling follows actual V120 execution/loader qualification.3 fresh native256/B16/BF16 cases,25warm+50timed updates plus2 valid resumed checks under unchanged100k horizon. Compare strict0 versus throughput0 and throughput2; select throughput workers2 only if sampled resumed input witnesses match and speed improves by>5%, else workers0. No neural-quality claim; no every-step GPU batch hashing in timed window. Both20k/100k source orders cover all90778 photos; first320k slot indices exact. Production schedule, worker choice and full optimizer checkpoint/resume are declared separately before launch.'}
write_json(root/'plan.json',plan);verify_plan(plan)
print('Exact20k/100k source prefix;100k ordinary',plan['source_coverage']['long100k']['Commons_families']['ordinary'],'visits;5 complete epochs')
