"""Audit native alignment, absence, Bayer-plane sensitivity and replay source coverage."""

from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import proposal
import deficit
from measure_proposal import FWD
from collect_router import OUT as ROUTER
import score


def synth(pattern, x):
    code = np.array(["RGB".index(k) for k in pattern])
    raws = np.stack([x[..., oy::2, ox::2] for oy, ox in ((0, 0), (0, 1), (1, 0), (1, 1))], axis=1)
    return {"colors": code, "packed": raws, "matrix": np.eye(3), "wb": np.ones(3)}


def layout():
    y, x = np.mgrid[:256, :256]
    tone = 0.14 + 0.0012 * np.cos(2 * np.pi * (x + 2 * y) / 24 + 0.3)
    wave = (tone - 0.14)[48:-48, 48:-48].ravel()
    quiet = {"shot": 0.0, "read": 1e-8}
    summary = {}
    for cfa in PATTERNS:
        mosaics = synth(cfa, tone[None])
        nominal = np.broadcast_to(
            (0.14 + 0.15 * (tone - 0.14))[None, None], (1, 3, 256, 256)
        ).copy()
        geometry = {"nominal": nominal}
        none = {"nominal": np.broadcast_to(tone[None, None], (1, 3, 256, 256)).copy()}
        absent = synth(cfa, np.full((1, 256, 256), 0.14))
        flat = {"nominal": np.full((1, 3, 256, 256), 0.14)}
        color = mosaics["packed"].copy()
        color[:, mosaics["colors"] != 1] += 0.027
        shallow = {}
        for arm in (proposal, deficit):
            a, _ = arm.fields(mosaics, geometry, quiet)
            b, _ = arm.fields(mosaics | {"packed": color}, geometry, quiet)
            no, _ = arm.fields(mosaics, none, quiet)
            empty, _ = arm.fields(absent, flat, quiet)
            for key, v in a.items():
                np.testing.assert_array_equal(v, b[key])
                assert not np.any(no[key]) and not np.any(empty[key])
                checked_phase = v[0, 48:-48, 48:-48].ravel()
                similarity = float(np.corrcoef(wave, checked_phase)[0, 1])
                assert similarity > 0.997 and (checked_phase @ wave) > 0
                shallow[key] = {
                    "phase_correlation": similarity,
                    "amplitude": float((checked_phase @ wave) / (wave @ wave)),
                }
        summary[cfa] = shallow
    return summary


def coverage():
    off = reference(FWD)
    raw = read_json(checked(off))
    prior = read_json(checked(raw["source"]))
    source_plan = read_json(checked(prior["plan"]))
    assert source_plan["parent_visits_checked"] == 559808
    init = reference(proposal.OUT / "calibration.json")
    held = reference(proposal.OUT / "wires.json")
    a = read_json(checked(init))["wires"]
    b = read_json(checked(held))["rows"]

    def identity(rows):
        return {r["fixture"]["source"][k] for r in rows for k in ("cache_sha256", "id")}

    keys = [identity(x) for x in (a, b, raw["rows"])]
    assert len(set.union(*keys)) == sum(map(len, keys))
    src1 = read_json(checked(read_json(checked(init))["source"]))
    src2 = read_json(checked(read_json(proposal.OUT / "natural.json")["source"]))

    def people(stamp, role):
        s = read_json(checked(stamp["plan"]))
        return {r[k] for r in s["groups"][role] for k in ("cache_sha256", "id")}

    u, v = people(src1, "calibration"), people(src2, "confirm")
    assert u.isdisjoint(v)
    # Natural and wire photos are separate under this replay.
    assert set.union(*keys).isdisjoint(u | v)
    return {
        "off_grid": off,
        "original_wire_plan": prior["plan"],
        "local_training_manifest_overlap": raw["source_overlap_local_manifest"],
        "observed_photo_visits_checked": source_plan["parent_visits_checked"],
        "wire_rows": [len(a), len(b), len(raw["rows"])],
        "calibration": init,
        "retained": held,
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    valid = layout()
    sources = coverage()
    print(
        sources, min(v["phase_correlation"] for a in valid.values() for v in a.values()), flush=True
    )
    write_json(
        proposal.OUT / "audit.json",
        {
            "driver": reference(Path(__file__)),
            "operators": [reference(proposal.__file__), reference(deficit.__file__)],
            "sine_phase_alignment": valid,
            "noiseless_no_residual_is_zero": True,
            "red_blue_change_within_clip_is_invariant": True,
            "sources": sources,
        },
    )
