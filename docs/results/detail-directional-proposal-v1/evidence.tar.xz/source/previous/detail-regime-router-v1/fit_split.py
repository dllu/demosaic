"""Test separate convex routing for sharpening and smoothing."""

from pathlib import Path
from time import monotonic

import torch
from torch import nn

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT
from regime_router import INPUTS, quadratic
from fit_router import UPDATES, PER_REGIME, SEED, LR, EMA, experts_for, training_data

METHODS = ("split static", "split Bayer")


class SplitRouter(nn.Module):
    def __init__(self, adaptive):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(3, 2))
        self.network = None
        if adaptive:
            self.network = nn.Sequential(nn.Linear(INPUTS, 24), nn.SiLU(), nn.Linear(24, 6))
            nn.init.zeros_(self.network[-1].weight)
            nn.init.zeros_(self.network[-1].bias)

    def forward(self, x):
        if self.network is None:
            return self.bias.softmax(-2).expand(*x.shape[:-1], 3, 2)
        score = self.network(x).reshape(*x.shape[:-1], 3, 2)
        return (self.bias + score).softmax(-2)


def fit():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    plan = reference(OUT / "plan.json")
    info = read_json(checked(plan))
    nets, scales = experts_for(info, "cpu")
    normal = nets["plain"][1]
    weak, weak_ids = training_data(info["references"]["redraw"], nets, scales, "cpu", normal, False)
    strong, strong_ids = training_data(
        info["references"]["direct"], nets, scales, "cpu", normal, False
    )
    assert weak_ids["source"].isdisjoint(strong_ids["source"])
    x = {name: SplitRouter(name == "split Bayer") for name in METHODS}
    avg = {name: SplitRouter(name == "split Bayer").requires_grad_(False) for name in METHODS}
    opts = {name: torch.optim.AdamW(net.parameters(), lr=LR) for name, net in x.items()}
    for k, p in avg.items():
        p.load_state_dict(x[k].state_dict())
    torch.testing.assert_close(
        x[METHODS[0]](weak["features"][:2]), x[METHODS[1]](weak["features"][:2])
    )
    resample = torch.Generator().manual_seed(SEED)
    log = {}
    start = monotonic()
    for step in range(1, UPDATES + 1):
        sample = []
        for data in (weak, strong):
            q = torch.randint(len(data["expert"]), (PER_REGIME,), generator=resample)
            sample.append({k: p[q] for k, p in data.items()})
        status = {}
        for k, net in x.items():
            opts[k].zero_grad(set_to_none=True)
            ra, rb = [
                quadratic((net(v["features"]) * v["expert"]).sum(-2), v, weak=weak_role)
                for weak_role, v in zip((True, False), sample, strict=True)
            ]
            loss = ra + rb
            assert torch.isfinite(loss)
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 1)
            opts[k].step()
            with torch.no_grad():
                torch._foreach_lerp_(list(avg[k].parameters()), list(net.parameters()), 1 - EMA)
            status[k] = [ra.item(), rb.item()]
        if step in (1, UPDATES) or step % 100 == 0:
            log[step] = status
            print(step, round(monotonic() - start, 2), status, flush=True)
    root = OUT / "fit-split"
    root.mkdir(exist_ok=True)
    weights = {}
    for name in METHODS:
        path = root / (name.replace(" ", "-").lower() + ".pt")
        tmp = path.with_suffix(".pending")
        d = {
            "plan": plan,
            "raw": x[name].state_dict(),
            "ema": avg[name].state_dict(),
            "optimizer": opts[name].state_dict(),
            "normal": normal,
            "scales": scales,
            "name": name,
            "update": UPDATES,
            "rng": resample.get_state(),
        }
        torch.save(d, tmp)
        tmp.replace(path)
        weights[name] = reference(path)
        saved = torch.load(checked(weights[name]), weights_only=True, map_location="cpu")
        assert saved["update"] == UPDATES
        for k in saved["ema"]:
            assert torch.equal(saved["ema"][k], d["ema"][k])
    write_json(
        root / "result.json",
        {
            "driver": reference(Path(__file__)),
            "plan": plan,
            "checkpoints": weights,
            "updates": UPDATES,
            "batch_each": PER_REGIME,
            "lr": LR,
            "ema_decay": EMA,
            "train_photos": [len(weak["expert"]), len(strong["expert"])],
            "unique_role_examples": 6 * len(weak["expert"]) + 3 * len(strong["expert"]),
            "role_visits_per_arm": 9 * UPDATES * PER_REGIME,
            "seconds": monotonic() - start,
            "logs": log,
        },
    )


if __name__ == "__main__":
    fit()
