"""Lock methods with a paired uncertainty allowance and evaluate on fresh sources."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT, REGIMES, base
from confirm_capture import OUT as CONFIRM
from fit_split import METHODS as SPLIT, SplitRouter
from regime_router import expert_gains, features
from score_router import ARMS, GRID, captures, changes, load_nets, meters
from evaluate_selector import deltas, values
import mild_score as math
import score

Z = 1.2815515655446004
MODES = (*ARMS, *SPLIT)


def networks():
    common, heads, scales, routes = load_nets()
    fork = reference(OUT / "fit-split/result.json")
    extras = {}
    for k, ref in read_json(checked(fork))["checkpoints"].items():
        net = SplitRouter(k == "split Bayer")
        data = torch.load(checked(ref), weights_only=True, map_location="cpu")
        net.load_state_dict(data["ema"])
        assert data["scales"] == scales
        extras[k] = net.requires_grad_(False).eval()
    return (common, fork), (heads, scales, routes, extras)


@torch.no_grad()
def all_changes(meta, pred, profile, full):
    heads, scales, routes, extra = full
    reduced, neutral, probabilities = changes(meta, pred, profile, heads, scales, routes)
    raw, signed, support, wave, _ = base.local(meta, pred, profile)
    x, s, c = (torch.from_numpy(v) for v in (raw, signed, support))
    vote = expert_gains(x, s, c, heads, scales)
    f = features(x, s, heads["plain"][1])
    p = {k: net(f) for k, net in extra.items()}
    roll = f.roll((f.shape[-3] // 2, f.shape[-2] // 2), dims=(-3, -2))
    p["split rolled"] = extra["split Bayer"](roll)
    for k, a in p.items():
        using = deltas(wave, (a * vote).sum(-2))
        reduced[k] = (using[:, 0], using[:, 1])
        probabilities[k] = a[:, 2:6, 2:6, :].mean(dim=(1, 2)).tolist()
    return reduced, neutral, probabilities


def coefficient_data(rows, k):
    components = tuple(score.LIMITS) + ("response", "truth")
    return {m: np.asarray([r["scores"][k][m] for r in rows]) for m in components}


def options(k):
    if k in SPLIT:
        return [(float(t), float(t)) for t in GRID]
    if k == "fixed mix":
        return [(float(GRID[a]), float(GRID[b])) for a in range(41) for b in range(41 - a)]
    return [(float(t), 0.0) for t in GRID]


def assess(terms, ref, strength):
    a, b = strength
    scale = np.array((1, a, b, a * a, a * b, b * b))
    report, bounds, var = {}, {}, {}
    for m in score.LIMITS:
        q, r = np.maximum(0, terms[m] @ scale), np.maximum(0, ref[m][:, 0])
        v, base_rms = np.sqrt(q.mean()), np.sqrt(r.mean())
        residual = q / max(2 * v, 1e-9) - r / max(2 * base_rms, 1e-9)
        se = np.std(residual, ddof=1) / np.sqrt(len(q))
        report[m] = float(v)
        var[m] = float(se)
        bounds[m] = float(v - base_rms + Z * se)
    report["response_pp"] = float(
        100 * (terms["response"] @ scale[:3]).sum() / terms["truth"].sum()
    )
    return {"scores": report, "se": var, "upper_delta": bounds}


def choose(rows):
    by_regime = meters(rows)
    nominal = {k: coefficient_data(v, "nominal") for k, v in by_regime.items()}
    chosen = {}
    for name in MODES:
        data = {k: coefficient_data(v, name) for k, v in by_regime.items()}
        trials = [
            {"dose": point, "regimes": {k: assess(data[k], nominal[k], point) for k in REGIMES}}
            for point in options(name)
        ]

        def feasible(trial):
            return all(
                r["upper_delta"][k] <= v
                for r in trial["regimes"].values()
                for k, v in score.LIMITS.items()
            )

        locked = max(
            (t for t in trials if feasible(t)),
            key=lambda t: (
                t["regimes"]["faint"]["scores"]["response_pp"],
                -t["regimes"]["faint"]["scores"]["increment"],
            ),
        )
        chosen[name] = {"locked": locked, "trials": trials}
    selected = max(
        ("routed", "split Bayer"),
        key=lambda k: chosen[k]["locked"]["regimes"]["faint"]["scores"]["response_pp"],
    )
    return {"arms": chosen, "primary": selected, "z": Z, "limits": score.LIMITS}


def locked_points(policy, first):
    routes = {k: r["locked"]["dose"] for k, r in policy["arms"].items()}
    options_ = {k: (k, d) for k, d in routes.items()}
    options_ |= {
        "nominal": ("nominal", (0, 0)),
        "v120": ("v120", (1, 0)),
        "plain original": ("plain", (1, 0)),
        "stable original": ("stable", (1, 0)),
        "routed original": ("routed", first["arms"]["routed"]["joint"]["dose"]),
        "rolled": ("rolled", routes["routed"]),
        "split rolled": ("split rolled", routes["split Bayer"]),
    }
    return options_


def show(rows, policy, first, *, hold):
    options_ = locked_points(policy, first)
    rng = np.random.default_rng(202611200958)
    ids = np.vstack((np.arange(len(rows)), rng.integers(len(rows), size=(12000, len(rows)))))
    result = {}
    for mode, block in meters(rows).items():
        terms = {k: values(block, name, d) for k, (name, d) in options_.items()}
        scores = {k: score.evaluate(v) for k, v in terms.items()}
        sample = {
            n: {k: np.sqrt(np.mean(v[k][ids] ** 2, axis=1)) for k in score.LIMITS}
            | {"response_pp": 100 * v["projection"][ids].sum(axis=1) / v["true"][ids].sum(axis=1)}
            for n, v in terms.items()
        }
        intervals = {}
        for k, outcome in sample.items():
            intervals[k] = {}
            for control in ("nominal", "fixed mix", "split static", "routed", "routed original"):
                delta = {m: a - sample[control][m] for m, a in outcome.items()}
                intervals[k][control] = {
                    m: [float(a[0]), *np.quantile(a[1:], (0.025, 0.975)).tolist()]
                    for m, a in delta.items()
                }
        e = np.argsort(terms["nominal"]["true"])[: len(rows) // 2]
        worst = {
            k: score.evaluate({m: v[e] for m, v in cells.items()}) for k, cells in terms.items()
        }
        p = policy["primary"]
        curves = (
            {
                k: [
                    {
                        "scale": float(s),
                        "scores": score.evaluate(
                            values(block, options_[k][0], tuple(np.asarray(options_[k][1]) * s))
                        ),
                    }
                    for s in GRID
                ]
                for k in ("stable original", "fixed mix", "routed", "split static", "split Bayer")
            }
            if hold
            else {}
        )
        result[mode] = {
            "scores": scores,
            "intervals": intervals,
            "weakest_half": worst,
            "curves": curves,
            "primary_per_source_increment_delta_range": [
                float(x)
                for x in np.quantile(
                    terms[p]["increment"] - terms["nominal"]["increment"], [0, 0.1, 0.5, 0.9, 1]
                )
            ],
        }
    return result


def run(which):
    torch.set_num_threads(2)
    hold = which == "confirm"
    root = CONFIRM if hold else OUT
    dataset = reference(root / which / "completed.json")
    first = reference(OUT / "score-calibration.json")
    earlier = read_json(checked(first))["policy"]
    binding, params = networks()
    tic = monotonic()
    rows = []
    for case, captures_ in captures(dataset):
        items = {}
        for regime, (d, p) in captures_.items():
            delta, _, prob = all_changes(d, p, case["profile"], params)
            v = base.old.luma(p["v120"], d) - base.old.luma(p["nominal"], d)
            delta["v120"] = (v, np.zeros_like(v))
            anchor, target = (score.stats(p["nominal"], d), score.stats(d["target"], d))
            terms = {
                k: math.terms(target, anchor, math.coefficients(a), math.coefficients(b))
                for k, (a, b) in delta.items()
            }
            items[regime] = {"scores": terms, "probability": prob}
        rows.append(
            {
                "id": case["id"],
                "source": case["source"]["id"],
                "inputs": case["inputs"],
                "regimes": items,
            }
        )
        if len(rows) % 8 == 0:
            print(which, len(rows), round(monotonic() - tic, 2), flush=True)
    cal = reference(OUT / "robust-calibration.json") if hold else None
    if cal:
        locked = read_json(checked(cal))
        policy = locked["policy"]
        assert locked["fit"] == list(binding)
    else:
        policy = choose(rows)
    results = show(rows, policy, earlier, hold=hold)
    print(
        policy["primary"], {k: v["locked"]["dose"] for k, v in policy["arms"].items()}, flush=True
    )
    for k, v in results.items():
        print(k, v["scores"], flush=True)
    write_json(
        OUT / ("score-confirm.json" if hold else "robust-calibration.json"),
        {
            "driver": reference(Path(__file__)),
            "source": dataset,
            "fit": binding,
            "first_policy": first,
            "robust_calibration": cal,
            "rows": rows,
            "policy": policy,
            "results": results,
            "seconds": monotonic() - tic,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
