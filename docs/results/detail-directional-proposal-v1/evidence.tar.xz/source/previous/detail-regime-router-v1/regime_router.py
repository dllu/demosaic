"""Mix frozen detail gates with a parent fallback on the delivered native grid."""

import torch
from torch import nn

from collect_router import base
from train_direct import gain, normalize, reg

CLASSES = ("parent", "plain", "stable")
METHODS = ("static", "routed")
INPUTS = 11 + base.DIM


class Router(nn.Module):
    def __init__(self, spatial):
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(len(CLASSES)))
        self.network = None
        if spatial:
            self.network = nn.Sequential(nn.Linear(INPUTS, 24), nn.SiLU(), nn.Linear(24, 3))
            nn.init.zeros_(self.network[-1].weight)
            nn.init.zeros_(self.network[-1].bias)

    def forward(self, feature):
        if self.network is None:
            return self.bias.softmax(-1).expand(*feature.shape[:-1], len(CLASSES))
        return (self.bias + self.network(feature)).softmax(-1)


def features(raw, signed, norm):
    return torch.cat((normalize(raw, norm["base"]), normalize(signed, norm["signed"])), dim=-1)


def expert_gains(raw, signed, cap, experts, scales):
    g = [
        gain(net, raw, signed, cap, norm) * raw.new_tensor(scales[name])
        for name, (net, norm) in experts.items()
    ]
    assert tuple(experts) == CLASSES[1:]
    return torch.stack((torch.zeros_like(g[0]), *g), dim=-2)


def mix(probabilities, expert):
    return (probabilities[..., None] * expert).sum(dim=-2)


def quadratic(values, data, *, weak):
    flat = base.flatten(values)
    pairs = flat[..., :2, :].reshape(*flat.shape[:-2], 64)
    role = reg(flat, data["linear"], data["gram"]) / (data["role_energy"] + 36**2)
    raw_pair = reg(pairs, data["pair_linear"], data["pair_gram"])
    target = 2 * base.RESP_PULL * (pairs * data["signal"]).sum(-1) if weak else 0
    pair = (raw_pair - target) / (data["pair_energy"] + 48**2)
    quiet = role[..., 2]
    losses = 0.60 * role[..., 0] + 0.25 * role[..., 1] + 1.7 * (quiet + 0.3 * quiet.relu())
    if weak:
        return (losses + pair).mean()
    # Penalize positive incremental risk even when the stronger training batch
    # has a few large improvements that would otherwise hide regressions.
    return (losses + 2 * pair + pair.relu()).mean()
