"""Freeze matched weak and stronger Bayer observations on new photos."""

from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import random
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("detail-redraw-gate-v1")))
from redraw_gate import OUT as PREVIOUS, base
from collect_redraw import ISO, VAL, batch, forward, identities, load_model, renderer, save

SEED = 202611200953
REGIMES = {"faint": (0.22, 0.0), "stronger": (0.78, 0.06)}
SIZES = {"preflight": 4, "calibration": 32, "held": 48}
CHUNK = 16


def freeze():
    latest_plan = reference(PREVIOUS / "plan.json")
    latest = read_json(checked(latest_plan))
    prior_training = read_json(checked(latest["previous_dataset"]))
    old = read_json(checked(prior_training["previous"]))
    observations = read_json(checked(old["observations_for_evaluation"]))
    refs = {
        "previous": latest_plan,
        "redraw": reference(PREVIOUS / "training/completed.json"),
        "direct": reference(base.OUT / "training/completed.json"),
        "experts": reference(PREVIOUS / "fit-training/result.json"),
        "expert_policy": reference(PREVIOUS / "score-calibration.json"),
    }
    excluded = set()
    for cases in latest["cases"].values():
        excluded |= identities(cases)
    with checked(latest["training_manifest"]).open() as f:
        excluded |= identities(map(json.loads, f))
    excluded |= identities(read_json(checked(latest["full427"]))["source_metadata"])
    excluded |= identities(read_json(checked(latest["previous_held"]))["samples"])
    excluded |= identities(
        r["source"] if isinstance(r["source"], dict) else r["fixture"]["source"]
        for g in ("calibration", "transfer", "wires")
        for r in observations["groups"][g]
    )
    with checked(latest["validation_manifest"]).open() as f:
        candidates = [
            r
            for r in map(json.loads, f)
            if r["split"] == "val"
            and r["bin_factor"] == 4
            and min(r["shape"][:2]) >= 512
            and max(r["shape"][:2]) <= 1800
        ]
    result = {}
    for name, size in SIZES.items():
        order = sorted(
            candidates, key=lambda r: sha256(f"{SEED}/{name}/{r['id']}".encode()).digest()
        )
        rows = []
        for row in order:
            code = {row["id"], row["cache_sha256"]}
            if code.intersection(excluded):
                continue
            rows.append(row)
            excluded.update(code)
            if len(rows) == size:
                break
        assert len(rows) == size
        result[name] = rows
    fit = read_json(checked(refs["experts"]))
    return {
        "driver": reference(__file__),
        "references": refs,
        "parent": latest["parent"],
        "v120": latest["v120"],
        "full427": latest["full427"],
        "groups": result,
        "training_manifest": latest["training_manifest"],
        "strengths": REGIMES,
        "seed": SEED,
        "renderer": reference(renderer.__file__),
        "expert_checkpoints": {
            k: v for k, v in fit["checkpoints"].items() if k in ("plain", "stable")
        },
        "precision": "CUDA IEEE FP32 EMA with checked shared local encoder, RGB deliverables stay linear",
    }


def photo(spec, index, tag):
    source = Path(spec["cache"])
    source = source if source.is_absolute() else VAL.parent / source
    card = spec | {"cache": str(source)}
    y = renderer.load_photo({"source": card})
    rng = random.Random(scene_seed(SEED, index, tag))
    turns, flip = rng.randrange(4), bool(rng.randrange(2))
    y = torch.rot90(y, turns, (-2, -1))
    if flip:
        y = y.flip(-1)
    (box,) = scene_crop_boxes(
        y.shape[-2:], patch_size=256, count=1, seed=scene_seed(SEED, index, tag + "/crop")
    )
    box = tuple(map(int, box))
    physical = sample_scene_recipe(scene_seed(SEED, index, tag + "/camera"))
    physical = replace(
        physical,
        pattern=tuple(PATTERNS)[index % 4],
        black=0.03,
        **{k: ISO[k] for k in ("shot", "read", "exposure")},
    )
    return (
        y,
        {
            "id": f"{tag}-{index:03}",
            "source": card,
            "box": box,
            "D4": [turns, flip],
            "profile": ISO,
            "camera": asdict(physical),
        },
        physical,
    )


def observations(image, meta, camera, index):
    raws = {}
    seed_book = []
    for regime, (a, b) in REGIMES.items():
        p = renderer.patch(image, meta["box"], a)
        z = renderer.patch(image, meta["box"], b)
        data = []
        for role, rgb in zip(renderer.ROLES, (p, z, renderer.flat_patch(z)), strict=True):
            seed = scene_seed(SEED, index, f"{meta['id']}/{regime}/{role}")
            seed_book.append(seed)
            data.append(renderer.ordinary(rgb, replace(camera, noise_seed=seed)))
        raw = {k: data[0][k] for k in ("colors", "wb", "matrix")}
        raw |= {k: np.stack([x[k] for x in data]) for k in ("packed", "variance", "target")}
        np.testing.assert_array_equal(
            raw["target"][2, :, 80:176, 80:176],
            np.broadcast_to(raw["target"][2, :, 80:81, 80:81], (3, 96, 96)),
        )
        raws[regime] = raw
    assert len(set(seed_book)) == 6
    return raws, seed_book


@torch.inference_mode()
def capture(mode):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    path = OUT / "plan.json"
    if not path.exists():
        write_json(path, freeze())
    bound = reference(path)
    plan = read_json(checked(bound))
    assert plan["driver"] == reference(__file__)
    role = OUT / mode
    role.mkdir(exist_ok=True)
    model = load_model(plan["parent"])
    recommend, state = load_checkpoint(checked(plan["v120"]), "cuda", tiled_inference=True)
    assert state["loaded_sha256"] == plan["v120"]["sha256"] and "ema" in state
    recommend = recommend.eval().to(memory_format=torch.channels_last)
    recommend.set_noise(ISO["shot"], ISO["read"])
    del state
    tic = monotonic()
    inputs = []
    stamp = []
    with ieee_fp32():
        for i, case in enumerate(plan["groups"][mode]):
            stop = i % CHUNK == CHUNK - 1 or i + 1 == len(plan["groups"][mode])
            interval = role / f"chunk-{i // CHUNK:02}.json"
            if interval.exists():
                if stop:
                    stamp.append(reference(interval))
                continue
            img, description, camera = photo(case, i, mode)
            elements, seeds = observations(img, description, camera, i)
            captures = {}
            for regime, d in elements.items():
                x = batch(d)
                outputs = forward(model, x, ISO, reuse=True)
                outputs["v120"] = recommend(
                    x["packed"].contiguous(memory_format=torch.channels_last),
                    x["variance"].contiguous(memory_format=torch.channels_last),
                    x["colors"],
                    x["wb"],
                    x["matrix"],
                )
                result = {k: v.cpu().numpy() for k, v in outputs.items()}
                assert all(np.isfinite(v).all() for v in result.values())
                f = role / f"{description['id']}-{regime}.npz"
                captures[regime] = save(f, d | result)
            inputs.append(description | {"inputs": captures, "seeds": seeds})
            if stop:
                write_json(interval, {"plan": bound, "rows": inputs})
                inputs = []
                stamp.append(reference(interval))
                print(mode, i + 1, round(monotonic() - tic, 2), flush=True)
    write_json(
        role / "completed.json",
        {"plan": bound, "chunks": stamp, "source_count": i + 1, "seconds": monotonic() - tic},
    )


if __name__ == "__main__":
    capture(sys.argv[1])
