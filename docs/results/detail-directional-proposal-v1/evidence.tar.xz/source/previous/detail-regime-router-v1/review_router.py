"""Render both standing RAW families and exact target crop comparisons."""

from pathlib import Path
from statistics import mean
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT, PREVIOUS
from confirm_router import networks, all_changes, locked_points
from score_router import captures, meters
from evaluate_selector import values
from evaluate_direct import Cases
from review_selector import board, crop, image, named_pixels, wire_scorer

ROI = (48, 48, 160, 160)
LABELS = {
    "nominal": "Local 50k EMA",
    "v120": "V120 EMA",
    "target": "Exact GT",
    "plain original": "Earlier direct head",
    "stable original": "Earlier stability head",
    "routed original": "Single router, original",
    "routed": "Single router, buffered",
    "fixed mix": "Fixed mix, buffered",
    "split static": "Branchwise fixed",
    "split Bayer": "Branchwise Bayer",
}
REFERENCES = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
LINES = (
    "nominal",
    "stable original",
    "fixed mix",
    "routed original",
    "routed",
    "split static",
    "split Bayer",
)


def render(d, p, r, params, options):
    move, neutral, _ = all_changes(d, p, r["profile"], params)
    outputs = dict(p)
    for k, (name, scale) in options.items():
        if k not in LABELS or name not in move or name == "nominal":
            continue
        a, b = scale
        u, v = move[name]
        luma = a * u + b * v
        outputs[k] = (p["nominal"] + luma[:, None] * neutral[None, :, None, None]).astype(
            p["nominal"].dtype
        )
    return outputs


def natural(net, options, primary, folder):
    rows = reference(OUT / "score-confirm.json")
    data = read_json(checked(rows))
    faint = meters(data["rows"])["faint"]
    inc0 = values(faint, "nominal", (0, 0))["increment"]
    inc1 = values(faint, *options[primary])["increment"]
    diff = inc1 - inc0
    candidates = {
        data["rows"][i]["id"]: (why, float(diff[i]))
        for why, i in (
            ("lowest increment delta", int(diff.argmin())),
            ("highest increment delta", int(diff.argmax())),
        )
    }
    results = []
    for row, raw in captures(data["source"]):
        if row["id"] not in candidates:
            continue
        present = {}
        exp = 1 / row["profile"]["exposure"]
        for role, idx in (("faint", 0), ("flat", 2), ("stronger", 0)):
            d, p = raw["stronger" if role == "stronger" else "faint"]
            noisy = noisy_malvar(
                {
                    "packed": d["packed"],
                    **{
                        k: np.broadcast_to(d[k], (3, *d[k].shape)).copy()
                        for k in ("colors", "wb", "matrix")
                    },
                }
            )
            out = render(d, p, row, net, options) | {"target": d["target"]}

            def stamp(x):
                return image(crop(x[idx], ROI), d["wb"], d["matrix"], exp)

            displayed = [("Noisy Malvar", stamp(noisy))] + [
                (LABELS[k], stamp(out[k])) for k in ("v120", *LINES, "target")
            ]
            present[role] = board(displayed, folder / f"{row['id']}-{role}.png")
            if role == "faint":
                triplet = [displayed[0], (LABELS[primary], stamp(out[primary])), displayed[-1]]
                present["triplet"] = board(triplet, folder / f"{row['id']}-triplet.png")
        results.append(
            {
                "fixture": row,
                "score_change": candidates[row["id"]],
                "display_exposure": exp,
                "ROI": ROI,
                "views": present,
            }
        )
        print(row["id"], candidates[row["id"]], flush=True)
    assert len(results) == 2
    return {"evaluation": rows, "rows": results}


def standing(net, options, folder):
    origin = reference(PREVIOUS / "review-camera.json")
    saved = {r["id"]: r for r in read_json(checked(origin))["report"]["rows"]}
    out = []
    for row, raw, p, bind in Cases("camera"):
        before = saved[row["id"]]
        q = render(raw, p, row, net, options)
        assert row["input"] == before["input"] and row["global_ROI"] == before["ROI"]
        rendered = []
        local = row["local_ROI"]
        for snapshot in before["native"]:
            e = snapshot["exposure"]
            old = named_pixels(snapshot)

            def stamp(x):
                return image(crop(x[0], local), raw["wb"], raw["matrix"], e)

            np.testing.assert_array_equal(stamp(q["nominal"]), old["Local 50k EMA"])
            np.testing.assert_array_equal(stamp(q["stable original"]), old["Redraw stability"])
            head = [(s, old[s]) for s in ("Noisy (Malvar)", "V120 EMA", "Earlier whole-photo gate")]
            content = head + [(LABELS[k], stamp(q[k])) for k in LINES]
            content += [(k, old[k]) for k in REFERENCES if k in old]
            file = folder / f"{row['id']}-x{e:g}.png"
            rendered.append(board(content, file) | {"reference_board": snapshot, "exposure": e})
        anchor = crop(q["nominal"], local).astype(np.float64)
        rms = {k: float(np.sqrt(np.mean((crop(q[k], local) - anchor) ** 2)) * 65535) for k in LINES}
        out.append(
            {
                "id": row["id"],
                "RAW": row["raw"],
                "input": row["input"],
                "source": bind,
                "ROI": row["global_ROI"],
                "noise": row["noise"],
                "views": rendered,
                "RGB_change_DN16": rms,
            }
        )
        print(row["id"], rms, flush=True)
    assert len(out) == 8 and sum(len(x["views"]) for x in out) == 12
    return {"previous": origin, "rows": out}


def wires(net, options):
    ref, scorer = wire_scorer()
    result = []
    for r, d, p, bind in Cases("wires"):
        geom = r["fixture"]["geometry"]
        if geom["family"] == "smooth-dip":
            d = d | {"support": np.ones_like(d["support"])}
        q = render(d, p, r, net, options)
        metric = scorer(d, geom)
        result.append({"id": r["id"], "source": bind, "scores": {k: metric(q[k]) for k in LINES}})
    summary = {
        k: {
            m: mean(r["scores"][k][m] for r in result if m in r["scores"][k])
            for m in sorted({a for r in result for a in r["scores"][k]})
        }
        for k in LINES
    }
    print(summary, flush=True)
    return {"reference": ref, "rows": result, "summary": summary}


def run(mode):
    torch.set_num_threads(2)
    announced = reference(OUT / "robust-calibration.json")
    first = reference(OUT / "score-calibration.json")
    payload = read_json(checked(announced))
    o = locked_points(payload["policy"], read_json(checked(first))["policy"])
    primary = payload["policy"]["primary"]
    fit, net = networks()
    folder = OUT / "native" / mode
    folder.mkdir(exist_ok=True, parents=True)
    result = {
        "natural": lambda: natural(net, o, primary, folder),
        "camera": lambda: standing(net, o, folder),
        "wires": lambda: wires(net, o),
    }[mode]()
    write_json(
        OUT / f"review-{mode}.json",
        {
            "driver": reference(Path(__file__)),
            "calibration": announced,
            "fit": fit,
            "doses": o,
            "primary": primary,
            "report": result,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
