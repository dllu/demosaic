"""Lock one policy on both contrast regimes and measure source-level transfer."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import OUT, REGIMES, base
from regime_router import METHODS, Router, expert_gains, features, mix
from fit_router import experts_for
from evaluate_selector import deltas, values
import mild_score as math
import score

ARMS = ("plain", "stable", "static", "routed", "fixed mix")
ONLY_ONE = set(ARMS) - {"fixed mix"}
DISPLAY = {
    "nominal": "Local 50k EMA",
    "v120": "V120 EMA",
    "plain": "Direct loss, locked",
    "stable": "Redraw stability, locked",
    "static": "Learned constant blend",
    "routed": "Bayer-routed blend",
    "fixed mix": "Calibrated constant blend",
    "rolled": "Rolled Bayer route",
}
GRID = np.linspace(0, 1, 41)


def load_nets():
    bound = reference(OUT / "fit-training/result.json")
    fit = read_json(checked(bound))
    spec = read_json(checked(fit["plan"]))
    experts, doses = experts_for(spec, "cpu")
    networks = {}
    for k, ref in fit["checkpoints"].items():
        raw = torch.load(checked(ref), map_location="cpu", weights_only=True)
        m = Router(k == "routed")
        m.load_state_dict(raw["ema"])
        networks[k] = m.requires_grad_(False).eval()
        assert raw["scales"] == doses
    return bound, experts, doses, networks


def captures(stamp):
    complete = read_json(checked(stamp))
    expected = read_json(checked(complete["plan"]))
    label = Path(stamp["path"]).parent.name
    i = 0
    for chunk in complete["chunks"]:
        data = read_json(checked(chunk))
        assert data["plan"] == complete["plan"]
        for row in data["rows"]:
            spec = expected["groups"][label][i]
            assert row["source"]["id"] == spec["id"]
            assert row["source"]["cache_sha256"] == spec["cache_sha256"]
            assert len(set(row["seeds"])) == 6
            item = {}
            for k, ref in row["inputs"].items():
                with np.load(checked(ref), allow_pickle=False) as f:
                    outs = {n: f[n] for n in ("nominal", "crisp", "smooth", "v120")}
                    obs = {n: f[n] for n in f.files if n not in outs}
                item[k] = obs, outs
            yield row, item
            i += 1
    assert i == complete["source_count"]


@torch.no_grad()
def changes(meta, pred, profile, experts, doses, networks):
    ordinary, signs, cap, proposed, neutral = base.local(meta, pred, profile)
    x, s, c = (torch.from_numpy(t) for t in (ordinary, signs, cap))
    alternatives = expert_gains(x, s, c, experts, doses)
    z = features(x, s, experts["plain"][1])
    p = {k: m(z) for k, m in networks.items()}
    move = z.roll((z.shape[-3] // 2, z.shape[-2] // 2), dims=(-3, -2))
    p["rolled"] = networks["routed"](move)
    gates = {k: mix(v, alternatives) for k, v in p.items()}
    gates |= {k: alternatives[..., i, :] for i, k in enumerate(("plain", "stable"), start=1)}
    result = {k: deltas(proposed, g).sum(axis=1) for k, g in gates.items()}
    zeros = np.zeros_like(result["plain"])
    q = {k: (v, zeros) for k, v in result.items()}
    q["fixed mix"] = (result["plain"], result["stable"])
    q["nominal"] = (zeros, zeros)
    means = {k: v[:, 2:6, 2:6, :].mean(dim=(1, 2)).tolist() for k, v in p.items()}
    return q, neutral, means


def additional(meta, pred, profile, experts, doses, networks):
    correction, _, means = changes(meta, pred, profile, experts, doses, networks)
    luminance = base.old.luma(pred["v120"], meta) - base.old.luma(pred["nominal"], meta)
    correction["v120"] = (luminance, np.zeros_like(luminance))
    a, t = (score.stats(q, meta) for q in (pred["nominal"], meta["target"]))
    r = {
        k: math.terms(t, a, math.coefficients(p), math.coefficients(q))
        for k, (p, q) in correction.items()
    }
    return r, means


def meters(rows):
    return {k: [{"scores": r["regimes"][k]["scores"]} for r in rows] for k in REGIMES}


def attempts(name):
    if name in ONLY_ONE:
        return [(float(t), 0.0) for t in GRID]
    return [(float(GRID[a]), float(GRID[b])) for a in range(41) for b in range(41 - a)]


def calibration(rows):
    panels = meters(rows)
    nom = {k: score.evaluate(values(v, "nominal", (0, 0))) for k, v in panels.items()}
    out = {}
    for label in ARMS:
        candidates = []
        for dose in attempts(label):
            result = {k: score.evaluate(values(v, label, dose)) for k, v in panels.items()}
            passed = {
                k: all(result[k][m] <= nom[k][m] + add for m, add in score.LIMITS.items())
                for k in panels
            }
            candidates.append({"dose": dose, "scores": result, "passed": passed})

        def select(labels):
            return max(
                (row for row in candidates if all(row["passed"][k] for k in labels)),
                key=lambda row: (
                    row["scores"]["faint"]["response_pp"],
                    -row["scores"]["faint"]["increment"],
                ),
            )

        out[label] = {
            "joint": select(REGIMES),
            "faint-only diagnostic": select(("faint",)),
            "scores": candidates,
        }
    return {"limits": score.LIMITS, "nominal": nom, "arms": out}


def doses(policy):
    selection = {k: p["joint"]["dose"] for k, p in policy["arms"].items()}
    return selection | {
        "rolled": selection["routed"],
        "plain original": (1, 0),
        "stable original": (1, 0),
        "nominal": (0, 0),
        "v120": (1, 0),
    }


def summary(rows, policy):
    panels = meters(rows)
    strengths = doses(policy)
    name = {"plain original": "plain", "stable original": "stable"}
    n = len(rows)
    rng = np.random.default_rng(202611200957)
    sample = np.vstack((np.arange(n), rng.integers(0, n, (12000, n))))
    out = {}
    for regime, panel in panels.items():
        physical = {
            k: values(panel, name.get(k, k), strengths[k])
            for k in (*ARMS, "nominal", "v120", "rolled", "plain original", "stable original")
        }
        scores = {k: score.evaluate(data) for k, data in physical.items()}
        boot = {
            k: {m: np.sqrt(np.mean(a[m][sample] ** 2, axis=1)) for m in score.LIMITS}
            | {
                "response_pp": 100
                * a["projection"][sample].sum(axis=1)
                / a["true"][sample].sum(axis=1)
            }
            for k, a in physical.items()
        }
        effect = {}
        for k in (
            "routed",
            "static",
            "rolled",
            "fixed mix",
            "plain",
            "stable",
            "plain original",
            "stable original",
        ):
            effect[k] = {}
            for c in ("nominal", "fixed mix", "routed"):
                effect[k][c] = {}
                for m, item in boot[k].items():
                    d = item - boot[c][m]
                    effect[k][c][m] = [float(d[0]), *np.quantile(d[1:], (0.025, 0.975)).tolist()]
        weakest = np.argsort(physical["nominal"]["true"])[: n // 2]
        weak_results = {
            k: score.evaluate({m: a[weakest] for m, a in v.items()}) for k, v in physical.items()
        }
        per_photo = {
            k: {
                m: np.quantile(v[m] - physical["nominal"][m], (0, 0.5, 0.9, 1)).tolist()
                for m in score.LIMITS
            }
            for k, v in physical.items()
        }
        traces = {
            k: [
                {
                    "scale": float(s),
                    "scores": score.evaluate(values(panel, k, tuple(s * np.asarray(strengths[k])))),
                }
                for s in (*GRID[:40], 1.0)
            ]
            for k in ARMS
        }
        out[regime] = {
            "scores": scores,
            "comparisons": effect,
            "weakest_half": weak_results,
            "per_photo_delta_quantiles": per_photo,
            "curve": traces,
            "mean_router_by_role": {
                k: np.mean([r["regimes"][regime]["routes"][k] for r in rows], axis=0).tolist()
                for k in ("static", "routed", "rolled")
            },
        }
    return out


def evaluate(group):
    torch.set_num_threads(2)
    dataset = reference(OUT / group / "completed.json")
    binding, experts, expert_doses, networks = load_nets()
    tic = monotonic()
    choices = []
    for r, items in captures(dataset):
        terms = {}
        for name, (data, pred) in items.items():
            q, avg = additional(data, pred, r["profile"], experts, expert_doses, networks)
            terms[name] = {"scores": q, "routes": avg}
        choices.append(
            {"id": r["id"], "source": r["source"]["id"], "inputs": r["inputs"], "regimes": terms}
        )
        if len(choices) % 8 == 0:
            print(group, len(choices), round(monotonic() - tic, 2), flush=True)
    previous = reference(OUT / "score-calibration.json") if group == "held" else None
    lock = read_json(checked(previous))["policy"] if previous else calibration(choices)
    table = summary(choices, lock)
    print({k: v["joint"]["dose"] for k, v in lock["arms"].items()}, flush=True)
    for mode, panel in table.items():
        print(mode, panel["scores"], flush=True)
    write_json(
        OUT / f"score-{group}.json",
        {
            "driver": reference(__file__),
            "fit": binding,
            "source": dataset,
            "calibration": previous,
            "policy": lock,
            "rows": choices,
            "summary": table,
            "seconds": monotonic() - tic,
        },
    )


if __name__ == "__main__":
    evaluate(sys.argv[1])
