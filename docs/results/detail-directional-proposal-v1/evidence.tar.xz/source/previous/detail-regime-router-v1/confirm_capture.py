"""Capture a new confirmation panel after the first router transfer."""

from hashlib import sha256
import json
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import collect_router as original

OUT = original.OUT / "confirmation"
N = 48
SEED = 202611200954


def select():
    preceding = reference(original.OUT / "plan.json")
    prior = read_json(checked(preceding))
    old = read_json(checked(prior["references"]["previous"]))
    blocked = original.identities(row for group in prior["groups"].values() for row in group)
    blocked |= original.identities(row for group in old["cases"].values() for row in group)
    blocked |= original.identities(read_json(checked(old["full427"]))["source_metadata"])
    blocked |= original.identities(read_json(checked(old["previous_held"]))["samples"])
    with checked(old["training_manifest"]).open() as stream:
        blocked |= original.identities(map(json.loads, stream))
    earlier = read_json(checked(read_json(checked(old["previous_dataset"]))["previous"]))
    cached = read_json(checked(earlier["observations_for_evaluation"]))
    blocked |= original.identities(
        r["source"] if isinstance(r["source"], dict) else r["fixture"]["source"]
        for arm in ("calibration", "transfer", "wires")
        for r in cached["groups"][arm]
    )
    with checked(old["validation_manifest"]).open() as stream:
        eligible = [
            r
            for r in map(json.loads, stream)
            if r["split"] == "val"
            and r["bin_factor"] == 4
            and min(r["shape"][:2]) >= 512
            and max(r["shape"][:2]) <= 1800
        ]
    eligible.sort(key=lambda r: sha256(f"{SEED}/{r['id']}".encode()).digest())
    rows = []
    for row in eligible:
        key = {row["id"], row["cache_sha256"]}
        if key & blocked:
            continue
        rows.append(row)
        blocked |= key
        if len(rows) == N:
            break
    assert len(rows) == N
    return prior | {
        "followup_driver": reference(Path(__file__)),
        "prior_plan": preceding,
        "groups": {"confirm": rows},
        "selection_seed": SEED,
    }


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    file = OUT / "plan.json"
    if not file.exists():
        write_json(file, select())
    with patch.object(original, "OUT", OUT):
        original.capture("confirm")
