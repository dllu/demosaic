"""Fit fixed and Bayer-dependent mixtures on the same two captured ensembles."""

from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_router import HERE, OUT, base
from regime_router import CLASSES, METHODS, Router, features, expert_gains, mix, quadratic

UPDATES = 1200
PER_REGIME = 24
SEED = 202611200955
LR = 0.001
EMA = 0.993
FIELDS = (
    "base",
    "signed",
    "support",
    "gram",
    "linear",
    "role_energy",
    "pair_gram",
    "pair_linear",
    "pair_energy",
    "signal",
)


def experts_for(plan, device):
    old = read_json(checked(plan["references"]["expert_policy"]))["results"]["doses"]
    scales = {name: old[name] for name in CLASSES[1:]}
    experts = {}
    for name in CLASSES[1:]:
        f = plan["expert_checkpoints"][name]
        src = torch.load(checked(f), map_location=device, weights_only=True)
        net = base.Head(True).to(device)
        net.load_state_dict(src["ema"])
        experts[name] = net.requires_grad_(False).eval(), src["normal"]
    return experts, scales


def training_data(receipt, prior, scales, device, normalization, small):
    made = []
    identity = {"source": set(), "cache": set()}
    for step in read_json(checked(receipt))["stats"]:
        page = read_json(checked(step))
        with np.load(checked(page["data"]), allow_pickle=False) as block:
            count = 4 if small else len(block["base"])
            made.append({k: block[k][:count] for k in FIELDS})
        for row in page["samples"][:count]:
            source_id = row["source"] if isinstance(row["source"], str) else row["source"]["id"]
            assert source_id not in identity["source"]
            identity["source"].add(source_id)
            identity["cache"].add(row.get("cache_sha256", row.get("cache", {}).get("sha256")))
        if small:
            break
    pack = {k: torch.from_numpy(np.concatenate([d[k] for d in made])).to(device) for k in FIELDS}
    raw, signed, cap = (pack.pop(name) for name in ("base", "signed", "support"))
    with torch.no_grad():
        pack["expert"] = expert_gains(raw, signed, cap, prior, scales)
        pack["features"] = features(raw, signed, normalization)
    assert len(identity["source"]) == len(identity["cache"]) == len(pack["expert"])
    return pack, identity


def fit(mode):
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    binding = reference(OUT / "plan.json")
    frozen = read_json(checked(binding))
    small = mode == "preflight"
    device = "cpu"
    experts, scales = experts_for(frozen, device)
    norm = experts["plain"][1]
    weak, seen_weak = training_data(
        frozen["references"]["redraw"], experts, scales, device, norm, small
    )
    stronger, seen_strong = training_data(
        frozen["references"]["direct"], experts, scales, device, norm, small
    )
    for key in seen_weak:
        assert seen_weak[key].isdisjoint(seen_strong[key])
    assert (
        set()
        .union(seen_weak["source"], seen_strong["source"])
        .isdisjoint(r["id"] for group in frozen["groups"].values() for r in group)
    )
    nets = {k: Router(k == "routed") for k in METHODS}
    average = {k: Router(k == "routed").requires_grad_(False) for k in METHODS}
    for k, net in nets.items():
        average[k].load_state_dict(net.state_dict())
    with torch.no_grad():
        torch.testing.assert_close(
            nets["static"](weak["features"][:1]), nets["routed"](weak["features"][:1])
        )
    optimizer = {k: torch.optim.AdamW(net.parameters(), lr=LR) for k, net in nets.items()}
    rng = torch.Generator().manual_seed(SEED)
    losses = {}
    steps = 6 if small else UPDATES
    n = min(PER_REGIME, len(weak["features"]), len(stronger["features"]))
    tic = monotonic()
    for i in range(1, steps + 1):
        minibatches = []
        for data in (weak, stronger):
            j = torch.randint(len(data["features"]), (n,), generator=rng)
            minibatches.append({k: v[j] for k, v in data.items()})
        stat = {}
        for k, router in nets.items():
            opts = optimizer[k]
            opts.zero_grad(set_to_none=True)
            rewards = []
            mean_p = []
            for is_weak, sample in zip((True, False), minibatches, strict=True):
                p = router(sample["features"])
                out = mix(p, sample["expert"])
                rewards.append(quadratic(out, sample, weak=is_weak))
                mean_p.append(p.detach().reshape(-1, 3).mean(0).tolist())
            reward = rewards[0] + rewards[1]
            assert torch.isfinite(reward)
            reward.backward()
            torch.nn.utils.clip_grad_norm_(router.parameters(), 1)
            opts.step()
            with torch.no_grad():
                torch._foreach_lerp_(
                    list(average[k].parameters()), list(router.parameters()), 1 - EMA
                )
            stat[k] = {
                "weak": rewards[0].item(),
                "stronger": rewards[1].item(),
                "mean_routing": mean_p,
            }
        if i in (1, steps) or i % 100 == 0:
            losses[i] = stat
            print(i, round(monotonic() - tic, 3), stat, flush=True)
    root = OUT / f"fit-{mode}"
    root.mkdir(exist_ok=True)
    checks = {}
    for k, m in nets.items():
        save = {
            "plan": binding,
            "mode": k,
            "raw": m.state_dict(),
            "ema": average[k].state_dict(),
            "normal": norm,
            "optimizer": optimizer[k].state_dict(),
            "scales": scales,
            "update": steps,
            "rng": rng.get_state(),
        }
        target = root / (k + ".pt")
        tmp = target.with_suffix(".partial")
        torch.save(save, tmp)
        tmp.replace(target)
        checks[k] = reference(target)
        loaded = torch.load(checked(checks[k]), weights_only=True, map_location="cpu")
        for name in loaded["ema"]:
            assert torch.equal(loaded["ema"][name], save["ema"][name])
    write_json(
        root / "result.json",
        {
            "driver": reference(__file__),
            "operator": reference(HERE / "regime_router.py"),
            "plan": binding,
            "checkpoints": checks,
            "stats": losses,
            "seconds": monotonic() - tic,
            "train_photos": [len(weak["features"]), len(stronger["features"])],
            "updates": steps,
            "per_regime_batch": n,
            "role_visits_per_arm": steps * n * 9,
            "unique_role_examples": len(weak["features"]) * 6 + len(stronger["features"]) * 3,
            "ema_decay": EMA,
            "lr": LR,
            "scales": scales,
        },
    )


if __name__ == "__main__":
    fit(sys.argv[1])
