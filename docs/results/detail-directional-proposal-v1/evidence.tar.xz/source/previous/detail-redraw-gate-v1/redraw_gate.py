"""Exact fine-band statistics for repeated independent captures of the same weak signal."""

from pathlib import Path
import sys

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("direct-detail-response-v1")))
sys.path.insert(0, str(HERE.with_name("scene-local-contrast-2400-v1")))

import direct_detail as base
from train_direct import reg

STUDY = ("plain", "shared", "stable")
EXTRA_WEIGHT = 1.5


def repeated_stats(meta, predictions, noise):
    stacked = {k: np.concatenate([d[k] for d in meta]) for k in ("packed", "target")}
    stacked |= {k: meta[0][k] for k in ("colors", "wb", "matrix")}
    pred = {k: np.concatenate([p[k] for p in predictions]) for k in predictions[0]}
    raw, signed, cap, proposals, _ = base.local(stacked, pred, noise)
    target = base.old.luma(stacked["target"], stacked)
    anchor = base.old.luma(pred["nominal"], stacked)
    factor = 65535 / 96
    residual = (base.fine((anchor - target)[base.CENTER]) * factor).reshape(2, 3, -1)
    truth = base.fine((target[0] - target[1])[base.CENTER]) * factor
    role_basis = (
        base.fine(
            (proposals[base.CENTER][:, :, None] * base.windows()).reshape(6, 32, 96, 96)
        ).reshape(2, 3, 32, -1)
        * factor
    )
    pair_basis = np.concatenate((role_basis[:, 0], -role_basis[:, 1]), axis=1)
    pair_residual = residual[:, 0] - residual[:, 1]
    unit = truth / max(np.linalg.norm(truth), 1e-12)
    result = {
        "base": raw[base.STATIONS].reshape(2, 3, 4, 4, 11),
        "signed": signed[base.STATIONS].reshape(2, 3, 4, 4, base.DIM),
        "support": cap[:, 2:6, 2:6].reshape(2, 3, 4, 4),
        "gram": role_basis @ role_basis.swapaxes(-1, -2),
        "linear": (role_basis @ residual[..., None])[..., 0],
        "role_energy": np.sum(residual**2, axis=-1),
        "pair_gram": pair_basis @ pair_basis.swapaxes(-1, -2),
        "pair_linear": (pair_basis @ pair_residual[..., None])[..., 0],
        "pair_energy": np.sum(pair_residual**2, axis=-1),
        "signal": pair_basis @ truth,
    }
    for name, direction in (("shared", 1), ("stable", -1)):
        e = (pair_residual[0] + direction * pair_residual[1]) / 2
        p = np.concatenate((pair_basis[0], direction * pair_basis[1])) / 2
        e -= (e @ unit) * unit
        p -= np.outer(p @ unit, unit)
        result[name + "_gram"] = p @ p.T
        result[name + "_linear"] = p @ e
    return {k: np.asarray(v, dtype=np.float32) for k, v in result.items()}


def energy_delta(flat, data, name):
    paired = flat[:, :, :2].reshape(len(flat), 128)
    return reg(paired, data[name + "_linear"], data[name + "_gram"])


def loss(gains, data, name):
    flat = base.flatten(gains)
    paired = flat[:, :, :2].reshape(len(flat), 2, 64)
    rms_delta = reg(flat, data["linear"], data["gram"]) / (data["role_energy"] + 36**2)
    pair_delta = reg(paired, data["pair_linear"], data["pair_gram"])
    reward = 2 * base.RESP_PULL * (paired * data["signal"]).sum(-1)
    paired_weight = data["pair_energy"] + 48**2
    quiet = rms_delta[:, :, 2]
    plain = (
        0.60 * rms_delta[:, :, 0].mean()
        + 0.25 * rms_delta[:, :, 1].mean()
        + 1.7 * (quiet + 0.3 * quiet.relu()).mean()
        + ((pair_delta - reward) / paired_weight).mean()
    )
    if name == "plain":
        return plain
    return plain + EXTRA_WEIGHT * (energy_delta(flat, data, name) / paired_weight.mean(-1)).mean()
