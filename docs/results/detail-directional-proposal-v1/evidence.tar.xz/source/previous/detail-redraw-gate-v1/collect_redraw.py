"""Capture two independent redraws and collect their frozen Local 50k coefficients."""

from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import random
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

from redraw_gate import HERE, OUT, base, repeated_stats
from collect_direct import PROFILES, ISO, VAL, batch, forward, load_model, identities
import prepare_eval as renderer

SEED = 202611200934
SIZES = {"preflight": 6, "training": 512, "calibration": 32, "held": 48}
CHUNK = 24
V120 = Path("configs/current-model.json")
COHORT = Path(".cache/experiments/full427-faint-adc-v1/cohort.json")


def freeze():
    bound = reference(base.OUT / "training/plan.json")
    previous = read_json(checked(bound))
    local = read_json(checked(previous["previous"]))
    held = reference(base.OUT / "held/plan.json")
    fixed_panel = reference(COHORT)
    prior = reference(base.OUT / "fit-training/result.json")
    observed = read_json(checked(local["observations_for_evaluation"]))
    excluded_training = identities(previous["samples"]) | identities(local["samples"])
    excluded_eval = (
        identities(read_json(checked(held))["samples"])
        | identities(read_json(checked(fixed_panel))["source_metadata"])
        | identities(
            item["source"] if isinstance(item["source"], dict) else item["fixture"]["source"]
            for group in ("calibration", "transfer", "wires")
            for item in observed["groups"][group]
        )
    )
    training = previous["source_manifest"]
    with checked(training).open() as f:
        full_training = list(map(json.loads, f))
    validation = reference(VAL)
    with checked(validation).open() as f:
        full_validation = list(map(json.loads, f))
    options = {
        "train": (full_training, excluded_training | excluded_eval),
        "val": (full_validation, identities(full_training) | excluded_training | excluded_eval),
    }
    result = {}
    for mode, count in SIZES.items():
        split = "train" if mode in ("training", "preflight") else "val"
        pool, blocked = options[split]
        tag = set(blocked)
        eligible = [
            r
            for r in pool
            if r["split"] == split
            and r["bin_factor"] == 4
            and min(r["shape"][:2]) >= 512
            and max(r["shape"][:2]) <= 1800
        ]
        eligible.sort(key=lambda r: sha256(f"{SEED}/{mode}/{r['id']}".encode()).digest())
        picked = []
        for row in eligible:
            code = {row["id"], row["cache_sha256"]}
            if code & tag:
                continue
            picked.append(row)
            tag |= code
            if len(picked) == count:
                break
        assert len(picked) == count
        result[mode] = picked
        blocked.update(identities(picked))
    return {
        "driver": reference(__file__),
        "operator": reference(HERE / "redraw_gate.py"),
        "renderer": reference(renderer.__file__),
        "previous_dataset": bound,
        "previous_held": held,
        "training_manifest": training,
        "validation_manifest": validation,
        "full427": fixed_panel,
        "reference_training": prior,
        "init": read_json(checked(prior))["checkpoints"]["signed-response"],
        "parent": previous["parent"],
        "v120": read_json(V120)["checkpoint"],
        "sample_seed": SEED,
        "cases": result,
        "weak_contrast": {"training_range": [0.16, 0.40], "evaluation": 0.22},
        "noise": "Two independent redraws of present, absent, and flat; roles also independent.",
        "precision": "CUDA IEEE FP32 EMA, exact local DINO reuse within each conditioning triple.",
    }


def acquire(row, index, mode):
    root = VAL.parent
    path = Path(row["cache"])
    path = path if path.is_absolute() else root / path
    physical = checked({"path": str(path), "sha256": row["cache_sha256"]})
    source = row | {"cache": str(physical)}
    image = renderer.load_photo({"source": source})
    rng = random.Random(scene_seed(SEED, index, mode))
    turns, flip = rng.randrange(4), rng.randrange(2)
    image = torch.rot90(image, turns, (-2, -1))
    if flip:
        image = image.flip(-1)
    (box,) = scene_crop_boxes(
        image.shape[-2:], patch_size=256, count=1, seed=scene_seed(SEED, index, mode + "/crop")
    )
    box = tuple(map(int, box))
    tune = mode in ("training", "preflight")
    recipe = sample_scene_recipe(scene_seed(SEED, index, mode + "/camera"))
    if tune:
        shot, read = rng.choices(PROFILES, weights=(0.2, 0.6, 0.2))[0]
        profile = {"shot": shot, "read": read, "exposure": 2 ** rng.uniform(-2.6, -0.1)}
        strength = rng.uniform(0.16, 0.40)
    else:
        recipe = replace(recipe, pattern=tuple(PATTERNS)[index % 4], black=0.03)
        profile = ISO.copy()
        strength = 0.22
    physics = {k: profile[k] for k in ("shot", "read", "exposure")}
    recipe = replace(recipe, **physics)
    present = renderer.patch(image, box, strength)
    absent = renderer.patch(image, box, 0.0)
    flat = renderer.flat_patch(absent)
    gt = [present, absent, flat]
    seeds = []
    observations = []
    for repeat in (0, 1):
        captured = []
        for role, clean in zip(renderer.ROLES, gt, strict=True):
            seed = scene_seed(SEED, index, f"{mode}/{repeat}/{role}")
            seeds.append(seed)
            captured.append(renderer.ordinary(clean, replace(recipe, noise_seed=seed)))
        obs = {k: captured[0][k] for k in ("colors", "wb", "matrix")}
        obs |= {k: np.stack([x[k] for x in captured]) for k in ("packed", "variance", "target")}
        if repeat == 0 and not tune:
            exterior = scene_seed(SEED, index, mode + "/exterior")
            obs["scene_packed"] = observe_scene(
                image.contiguous(), replace(recipe, noise_seed=exterior)
            ).packed.numpy()
        observations.append(obs)
    assert len(set(seeds)) == 6
    np.testing.assert_array_equal(observations[0]["target"], observations[1]["target"])
    assert all(
        not np.array_equal(a, b)
        for a, b in zip(observations[0]["packed"], observations[1]["packed"], strict=True)
    )
    return observations, {
        "id": f"{mode}-{index:03}",
        "source": source,
        "cache": reference(physical),
        "D4": [turns, bool(flip)],
        "box": box,
        "profile": profile,
        "camera": asdict(recipe),
        "contrast": strength,
        "role_seeds": seeds,
    }


def save(path, data):
    tmp = path.with_suffix(".partial")
    with tmp.open("wb") as f:
        np.savez(f, **data)
    tmp.replace(path)
    return reference(path)


@torch.inference_mode()
def collect(mode):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    file = OUT / "plan.json"
    if not file.exists():
        write_json(file, freeze())
    plan = reference(file)
    frozen = read_json(checked(plan))
    assert frozen["driver"] == reference(__file__)
    assert frozen["operator"] == reference(HERE / "redraw_gate.py")
    root = OUT / mode
    root.mkdir(exist_ok=True)
    model = load_model(frozen["parent"])
    tune = mode in ("preflight", "training")
    v120 = None
    if not tune:
        v120, weights = load_checkpoint(checked(frozen["v120"]), "cuda", tiled_inference=True)
        assert weights["loaded_sha256"] == frozen["v120"]["sha256"] and "ema" in weights
        v120 = v120.eval().to(memory_format=torch.channels_last)
        del weights
    records = []
    seconds = monotonic()
    with ieee_fp32():
        for start in range(0, len(frozen["cases"][mode]), CHUNK):
            end = min(start + CHUNK, len(frozen["cases"][mode]))
            receipt = root / f"chunk-{start:03}-{end:03}.json"
            if receipt.exists():
                records.append(reference(receipt))
                continue
            batch_time = monotonic()
            fields, bindings = [], []
            for i in range(start, end):
                obs, row = acquire(frozen["cases"][mode][i], i, mode)
                preds = []
                for redraw in obs:
                    x = batch(redraw)
                    maps = forward(model, x, row["profile"], reuse=True)
                    if v120 is not None:
                        v120.set_noise(row["profile"]["shot"], row["profile"]["read"])
                        maps["v120"] = v120(
                            x["packed"].contiguous(memory_format=torch.channels_last),
                            x["variance"].contiguous(memory_format=torch.channels_last),
                            x["colors"],
                            x["wb"],
                            x["matrix"],
                        )
                    preds.append({k: p.cpu().numpy() for k, p in maps.items()})
                if tune:
                    values = repeated_stats(obs, preds, row["profile"])
                    assert all(np.isfinite(v).all() for v in values.values())
                    fields.append(values)
                if not tune or mode == "preflight":
                    row["draws"] = [
                        save(root / f"{row['id']}-{j}.npz", d | p)
                        for j, (d, p) in enumerate(zip(obs, preds, strict=True))
                    ]
                bindings.append(row)
            ref = {
                "samples": bindings,
                "plan": plan,
                "seconds": monotonic() - batch_time,
            }
            if fields:
                ref["data"] = save(
                    receipt.with_suffix(".npz"),
                    {k: np.stack([v[k] for v in fields]) for k in fields[0]},
                )
            write_json(receipt, ref)
            records.append(reference(receipt))
            print(mode, end, round(monotonic() - seconds, 2), flush=True)
    write_json(
        root / "completed.json",
        {"plan": plan, "stats": records, "source_count": end, "seconds": monotonic() - seconds},
    )


if __name__ == "__main__":
    collect(sys.argv[1])
