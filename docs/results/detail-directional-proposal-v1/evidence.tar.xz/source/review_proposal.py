"""Render the locked measured proposals at native resolution."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import proposal
import deficit
from proposal import OUT
from measure_proposal import binding, off_grid, FWD, wires
from collect_router import OUT as ROUTER
from evaluate_direct import Cases
from review_router import render as make_router
from review_selector import board, crop, image, named_pixels

EXACT = (48, 48, 160, 160)
LABELS = {
    "nominal": "Local 50k EMA",
    "router": "Earlier Bayer blend",
    "radial": "Radial proposal",
    "directional": "Directional residual",
    "residual checked": "Residual phase check",
    "raw deficit": "Raw deficit",
    "parent phase": "Parent-phase deficit",
}
REF_TAGS = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
ORDER = ("nominal", "router", *proposal.ARMS, *deficit.ARMS)


def compose(raw, p, row, params, rule, strengths):
    key = rule["name"]
    root = make_router(raw, p, row, params, {key: rule["dose"]})[key]
    first, neutral = proposal.fields(raw, p, row["profile"])
    second, twin = deficit.fields(raw, p, row["profile"])
    np.testing.assert_array_equal(neutral, twin)
    base = {"router": root, "nominal": p["nominal"]}
    for k, image_ in (first | second).items():
        base[k] = (root + strengths[k] * image_[:, None] * neutral[None, :, None, None]).astype(
            root.dtype
        )
    return base


def standing(params, run, strengths, root):
    before = reference(ROUTER / "review-camera.json")
    history = {r["id"]: r for r in read_json(checked(before))["report"]["rows"]}
    result = []
    for row, raw, p, origin in Cases("camera"):
        existing = history[row["id"]]
        assert existing["input"] == row["input"] and existing["ROI"] == row["global_ROI"]
        local = row["local_ROI"]
        views = []
        added = compose(raw, p, row, params, run, strengths)
        for view in existing["views"]:
            shown = named_pixels(view)
            e = view["exposure"]

            def apply(x):
                return image(crop(x[0], local), raw["wb"], raw["matrix"], e)

            np.testing.assert_array_equal(apply(added["router"]), shown["Branchwise Bayer"])
            np.testing.assert_array_equal(apply(added["nominal"]), shown["Local 50k EMA"])
            images = [
                (x, shown[x]) for x in ("Noisy (Malvar)", "V120 EMA", "Earlier whole-photo gate")
            ]
            images += [(LABELS[k], apply(added[k])) for k in ORDER]
            images += [(q, shown[q]) for q in REF_TAGS if q in shown]
            f = root / f"{row['id']}-x{e:g}.png"
            views.append(board(images, f) | {"exposure": e, "historical_reference": view})
        all_rms = {}
        for name, v in added.items():
            all_rms[name] = {}
            for compare in ("nominal", "router"):
                q = crop(v.astype(float) - added[compare], local)
                all_rms[name][compare] = float(np.sqrt(np.mean(q * q)) * 65535)
        result.append(
            {
                "id": row["id"],
                "RAW": row["raw"],
                "roi": row["global_ROI"],
                "input": row["input"],
                "source": origin,
                "reference": existing,
                "noise": row["noise"],
                "views": views,
                "RGB_change_DN16": all_rms,
            }
        )
    assert len(result) == 8 and sum(len(r["views"]) for r in result) == 12
    return {"source": before, "rows": result}


def exact(params, run, strengths, root):
    source = reference(OUT / "deficit/off-grid.json")
    observed = read_json(checked(source))
    records = observed["rows"]
    correct = "parent phase"
    metric = "intact_increment_RMS_DN16"
    a = np.asarray([r["coefficients"][correct][metric] for r in records])
    w = strengths[correct]
    measure = np.sqrt(np.maximum(0, a @ np.asarray([1, w, w * w])))
    old = np.asarray([r["controls"]["router"][metric] for r in records])
    shift = measure - old
    key = {
        records[i]["id"]: (reason, float(shift[i]))
        for i, reason in (
            (int(shift.argmin()), "lowest paired error change"),
            (int(shift.argmax()), "highest paired error change"),
        )
    }
    selected = []
    for row, raw, p, source_b in off_grid(reference(FWD)):
        if row["id"] not in key:
            continue
        outputs = compose(raw, p, row, params, run, strengths)
        names = {"noisy": "Noisy Malvar", "gt": "Exact optical GT", "v120": "V120 Small EMA"}
        labels = LABELS | names
        camera = {
            k: np.broadcast_to(raw[k], (4, *raw[k].shape)).copy()
            for k in ("colors", "wb", "matrix")
        }
        noisy = noisy_malvar(camera | {"packed": raw["packed"]})
        all_ = outputs | {"noisy": noisy, "gt": raw["target"]}
        comparisons = {}
        for mode, idx in (("present", 0), ("flat", 3), ("absent", 2)):

            def stamp(v):
                return image(crop(v[idx], EXACT), raw["wb"], raw["matrix"], 2.0)

            prev = ["v120"] if "v120" in p else []
            all_.update({k: p[k] for k in prev})
            b = {k: stamp(all_[k]) for k in ("noisy", *prev, *ORDER, "gt")}
            tag = row["id"]
            comparisons[mode] = board(
                [(labels[k], v) for k, v in b.items()], root / f"{tag}-{mode}.png"
            )
            if mode == "present":
                comparisons["triplet"] = board(
                    [(labels[k], b[k]) for k in ("noisy", correct, "gt")],
                    root / f"{tag}-triplet.png",
                )
        selected.append(
            {
                "id": row["id"],
                "fixture": row["fixture"],
                "input": source_b,
                "selection": key[row["id"]],
                "noise": row["profile"],
                "camera": row["fixture"]["camera"],
                "ROI": EXACT,
                "display_exposure": 2.0,
                "correction": correct,
                "views": comparisons,
            }
        )
        print(row["id"], key[row["id"]], flush=True)
    assert len(selected) == 2
    return {"source": source, "rows": selected}


def run():
    torch.set_num_threads(2)
    bound, p = binding()
    ref = {
        "first": reference(OUT / "calibration.json"),
        "deficit": reference(OUT / "deficit/calibration.json"),
    }
    strengths = {}
    for x in ref.values():
        strengths |= {
            k: v["locked"]["dose"] for k, v in read_json(checked(x))["policy"]["arms"].items()
        }
    start = monotonic()
    folder = OUT / "native"
    folder.mkdir(exist_ok=True)
    for k, method in (("camera", standing), ("exact", exact)):
        path = folder / k
        path.mkdir(exist_ok=True)
        data = method(p, bound, strengths, path)
        write_json(
            OUT / f"review-{k}.json",
            {
                "driver": reference(Path(__file__)),
                "router": bound,
                "calibrations": ref,
                "strengths": strengths,
                "report": data,
                "elapsed": monotonic() - start,
            },
        )


if __name__ == "__main__":
    run()
