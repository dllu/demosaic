"""Measure exact-target headroom for the frozen proposal space."""

from functools import cache
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch
from torch.nn.functional import interpolate, pad

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from proposal import OUT, base, fields
from measure_proposal import FWD, off_grid
from evaluate_direct import Cases
from review_selector import wire_scorer

ROI = np.s_[..., 64:192, 64:192]


@cache
def windows():
    basis = pad(torch.eye(36).reshape(1, 36, 6, 6), (1, 1, 1, 1))
    return interpolate(basis, size=(256, 256), mode="bilinear", align_corners=False)[0].numpy()[ROI]


def remove(a, Q):
    return a - (a @ Q) @ Q.T


def native_proposal_columns(p, modifiers, metric):
    # Present role 0 and weak-absent role 2, each with independent gains.
    chosen = p[[0, 2]][ROI] * np.array([1, -1])[:, None, None, None]
    local = chosen[:, :, None] * windows()
    A = local[..., metric.intact].reshape(-1, np.count_nonzero(metric.intact))
    cap = modifiers[[0, 2], :, 1:7, 1:7].ravel()
    assert len(cap) == len(A)
    return remove(A, metric.intact_nuisance), cap


def fit_exact(A, cap, target, parent, exact):
    # Use double precision and normalize the objective to DN16 per scored pixel.
    scale = 65535 / np.sqrt(len(target))
    d = (A * scale).T
    e = (target - parent) * scale
    gram = d.T @ d
    w = d.T @ e
    top = max(float(np.linalg.eigvalsh(gram)[-1]), 1e-20)
    time = 1.0
    z = np.zeros(len(gram), dtype=float)
    x = z.copy()
    for _ in range(600):
        update = np.clip(z - (gram @ z - w) / top, 0, cap)
        speed = (1 + np.sqrt(1 + 4 * time * time)) / 2
        z = update + (time - 1) / speed * (update - x)
        x = update
        time = speed
    diff = d @ x - e
    value = float(diff @ diff)
    g = 2 * d.T @ diff
    gap = -float(np.minimum(-g * x, g * (cap - x)).sum())
    assert gap >= -1e-8
    maximum = 100 * (float(parent @ exact) + np.maximum(A @ exact, 0) @ cap) / (exact @ exact)
    done = parent + x @ A
    return {
        "maximum_signed_response_pp": float(maximum),
        "best_error_fit_response_pp": float(100 * (done @ exact) / (exact @ exact)),
        "best_paired_RMS_DN16": float(np.sqrt(value)),
        "RMS_lower_bound_DN16": float(np.sqrt(max(0.0, value - gap))),
        "fit_dual_gap_DN16_squared": gap,
    }


def measure(case, factory):
    r, d, p, ref = case
    geometry = r["fixture"]["geometry"]
    if geometry["family"] in ("smooth-dip", "contrast-step"):
        d = d | {"support": np.ones_like(d["support"])}
    model = factory(d, geometry)
    y = base.old.luma(p["nominal"], d)[ROI]
    parent = remove((y[0] - y[2])[model.intact], model.intact_nuisance)
    raw, signs, cap, waveform, _ = base.local(d, p, r["profile"])
    prior_bound = np.stack((cap, np.ones_like(cap)), axis=1)
    A, G = native_proposal_columns(waveform, prior_bound, model)
    fresh, _ = fields(d, p, r["profile"])
    carry, limit = native_proposal_columns(
        fresh["directional"][:, None], np.ones((len(y), 1, 8, 8)), model
    )
    t = model.truth_weak
    old = fit_exact(A, G, t, parent, t)
    combined = fit_exact(np.concatenate((A, carry)), np.concatenate((G, limit)), t, parent, t)
    return {
        "id": r["id"],
        "source": ref,
        "baseline": model(p["nominal"]),
        "conditioning_space": old,
        "augmented_space": combined,
    }


def run(which):
    torch.set_num_threads(2)
    scorer, factory = wire_scorer()
    if which == "retained":
        c = Cases("wires")
        before = c.source
        cases = iter(c)
    else:
        before = reference(FWD)
        cases = off_grid(before)
    stage = monotonic()
    rows = []
    for case in cases:
        rows.append(measure(case, factory))
        if len(rows) % 8 == 0:
            print(which, len(rows), round(monotonic() - stage, 1), flush=True)
    result = {
        k: {x: mean(r[k][x] for r in rows) for x in rows[0][k]}
        for k in ("conditioning_space", "augmented_space")
    }
    result["base_weak_response_pp"] = mean(r["baseline"]["weak_response_pp"] for r in rows)
    result["base_intact_increment_RMS_DN16"] = mean(
        r["baseline"]["intact_increment_RMS_DN16"] for r in rows
    )
    print(result, flush=True)
    write_json(
        OUT / f"ceiling-{which}.json",
        {
            "driver": reference(Path(__file__)),
            "scorer": scorer,
            "source": before,
            "rows": rows,
            "summary": result,
            "scope": "Uses exact wire targets and separate role gain ceilings. No gap-risk constraint.",
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
