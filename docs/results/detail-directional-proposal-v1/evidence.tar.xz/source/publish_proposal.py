"""Archive the analytic proposals, exact limits, locked metrics and native crops."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from proposal import OUT, HERE
import measure_proposal as measure

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULT = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "calibration",
    "natural",
    "wires",
    "off-grid/completed",
    "off-grid",
    "deficit/calibration",
    "deficit/natural",
    "deficit/wires",
    "deficit/off-grid",
    "ceiling-retained",
    "ceiling-off-grid",
    "ceiling-frontier",
    "audit",
    "review-camera",
    "review-exact",
)
SOURCE = {
    "detail-regime-router-v1": (
        "collect_router.py",
        "review_router.py",
        "confirm_router.py",
        "score_router.py",
        "fit_router.py",
        "regime_router.py",
        "fit_split.py",
        "confirm_capture.py",
    ),
    "detail-redraw-gate-v1": ("redraw_gate.py", "collect_redraw.py"),
    "direct-detail-response-v1": (
        "direct_detail.py",
        "train_direct.py",
        "collect_direct.py",
        "evaluate_direct.py",
    ),
    "scene-detail-selector-v1": (
        "detail_selector.py",
        "review_selector.py",
        "evaluate_selector.py",
        "train_selector.py",
        "benchmark_shared_local_encoding.py",
        "collect_training.py",
    ),
    "scene-local-contrast-2400-v1": ("prepare_eval.py",),
    "context-conditioned-detail-v1": ("context_gate.py", "mild_score.py", "score.py", "capture.py"),
    "scene-mixture-wire-gaps-v1": ("scoring.py",),
}


def bound(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def graph(items):
    fig, ax = plt.subplots(1, 2, figsize=(10.6, 4.35), layout="constrained")
    name = "intact_increment_RMS_DN16"
    resp = "weak_response_pp"
    first = items["calibration"]["policy"]
    latest = items["deficit/calibration"]["policy"]
    anchor = items["off-grid"]["scores"]
    colors = {
        "radial": ("Radial", "#4477aa"),
        "directional": ("Directional", "#ee7733"),
        "residual checked": ("Residual phase check", "#882255"),
        "raw deficit": ("Raw-phase deficit", "#ccbb44"),
        "parent phase": ("Parent-phase deficit", "#228833"),
    }
    for title, (label, color) in colors.items():
        desc = first if title in first["arms"] else latest
        records = items["off-grid" if title in first["arms"] else "deficit/off-grid"]["rows"]
        fixed = desc["arms"][title]["locked"]["dose"]
        stress = max(fixed, desc["arms"][title]["wire-only"]["dose"])
        coeff = []
        for k in (name, resp):
            ach = np.asarray([r["coefficients"][title][k] for r in records])

            def value(dose):
                x = ach @ np.asarray([1.0, dose, dose * dose])
                return (
                    float(np.mean(x if k == resp else np.sqrt(np.maximum(0, x))))
                    - anchor[k]["router"]["value"]
                )

            coeff.append([value(z) for z in (*np.linspace(0, stress, 41), fixed)])
        ax[0].plot(coeff[0][:-1], coeff[1][:-1], color=color, label=label)
        ax[0].scatter(coeff[0][-1], coeff[1][-1], color=color, s=24)
    ax[0].set_title("Actual off-grid transfer")
    ax[0].set_xlabel("Intact paired RMS change from earlier blend (DN16)")
    ax[0].set_ylabel("Added weak contrast (percentage points)")
    ax[0].legend(frameon=False, fontsize=7)
    ax[0].axhline(0, ls=":", color="#888", lw=1)
    ax[0].axvline(0, ls=":", color="#888", lw=1)
    all_ = items["ceiling-frontier"]["summary"]
    xx = [float(k) for k in all_]
    for k, color, label in (
        ("conditioning", "#505050", "Conditioning proposals"),
        ("directional", "#ee7733", "Add directional proposal"),
        ("parent phase", "#228833", "Add parent-phase proposal"),
    ):
        y = [v[k]["mean_RMS_delta_common"] for v in all_.values()]
        ax[1].plot(xx, y, color=color, label=label)
        ax[1].scatter(xx, y, color=color, s=22)
    ax[1].set_title("Exact-target gain selection")
    ax[1].set_xlabel("Required gain (percentage points)")
    ax[1].set_ylabel("Best intact RMS change from Local 50k (DN16)")
    ax[1].set_xticks(xx, labels=["0.5", "1", "2", "4¹"])
    ax[1].legend(frameon=False, fontsize=7, loc="upper left")
    ax[1].text(
        0.99,
        0.02,
        "¹ 20 common sources at 4 points",
        ha="right",
        transform=ax[1].transAxes,
        fontsize=7,
    )
    path = ASSETS / "response-and-headroom.png"
    fig.savefig(path, dpi=160)
    return bound(path)


def copy(frame):
    old = checked(frame["image"])
    to = ASSETS / old.name
    shutil.copyfile(old, to)
    assert reference(to)["sha256"] == frame["image"]["sha256"]
    with Image.open(to) as i:
        for p in frame["panels"]:
            x, y, w, h = p["png_xywh"]
            assert w == h == 160 and x + w <= i.width and y + h <= i.height
    return frame | {"image": bound(to)}


def main():
    refs = {k: reference(OUT / (k + ".json")) for k in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in refs.items()}
    for rec in data.values():
        for key in ("driver", "operator"):
            if key in rec:
                checked(rec[key])
    for prefix in ("", "deficit/"):
        for k in ("natural", "wires", "off-grid"):
            assert data[prefix + k]["calibration"] == refs[prefix + "calibration"]
        assert data[prefix + "off-grid"]["source"] == refs["off-grid/completed"]
    assert data["audit"]["sources"]["off_grid"] == refs["off-grid/completed"]
    assert data["ceiling-frontier"]["source"] == refs["off-grid/completed"]
    assert data["ceiling-off-grid"]["source"] == refs["off-grid/completed"]
    assert data["review-exact"]["report"]["source"] == refs["deficit/off-grid"]
    for k in ("review-camera", "review-exact"):
        assert data[k]["calibrations"] == {
            "first": refs["calibration"],
            "deficit": refs["deficit/calibration"],
        }
    assert all(r["router"] == data["calibration"]["router"] for r in data.values() if "router" in r)
    rows = data["off-grid/completed"]["rows"]
    for k in ("off-grid", "deficit/off-grid"):
        assert [r["source"]["input"] for r in data[k]["rows"]] == [r["input"] for r in rows]
    for r in rows:
        checked(r["input"])
        checked(r["local"])
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULT.mkdir(exist_ok=True, parents=True)
    photo = data["review-exact"]["report"]["rows"]
    camera = data["review-camera"]["report"]["rows"]
    assert len(photo) == 2 and sum(len(r["views"]) for r in camera) == 12
    for r in photo:
        r["views"] = {k: copy(v) for k, v in r["views"].items()}
    for r in camera:
        for v in r["views"]:
            names = {k["label"] for k in v["panels"]}
            assert "ISO100 AHD reference" in names
            if r["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= names
        r["views"] = [copy(v) for v in r["views"]]
    plot = graph(data)
    summary = RESULT / "summary.json"
    write_json(
        summary,
        {
            "calibration": {
                n: {
                    p: {k: v for k, v in a.items() if k != "table"}
                    for p, a in data[n]["policy"]["arms"].items()
                }
                for n in ("calibration", "deficit/calibration")
            },
            "results": {
                k: data[k]["scores"]
                for k in (
                    "natural",
                    "deficit/natural",
                    "wires",
                    "deficit/wires",
                    "off-grid",
                    "deficit/off-grid",
                )
            },
            "wire_only": {
                k: data[k]["wire_only"]
                for k in ("wires", "deficit/wires", "off-grid", "deficit/off-grid")
            },
            "exact_target": {
                k: data[k]["summary"]
                for k in ("ceiling-retained", "ceiling-off-grid", "ceiling-frontier")
            },
            "camera": {r["id"]: r["RGB_change_DN16"] for r in camera},
            "source_scope": data["audit"]["sources"],
            "local_forward_seconds": data["off-grid/completed"]["seconds"],
        },
    )
    native = ASSETS / "manifest.json"
    write_json(
        native,
        {
            "photo": photo,
            "camera": camera,
            "plot": plot,
            "router": data["calibration"]["router"],
            "parent": data["off-grid/completed"]["parent"],
            "scales": data["review-exact"]["strengths"],
            "analytic_operators": data["audit"]["operators"],
        },
    )
    book = {f"receipts/{k}.json": r for k, r in refs.items()}
    for file in sorted(HERE.glob("*.py")):
        book[f"source/{file.name}"] = reference(file)
    for folder, files in SOURCE.items():
        for file in files:
            book[f"source/previous/{folder}/{file}"] = reference(HERE.with_name(folder) / file)
    for k in ("configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json"):
        book[k] = reference(ROOT / k)
    evidence = RESULT / "evidence.tar.xz"
    with tarfile.open(evidence, "x:xz", preset=4) as tar:
        for k, r in book.items():
            tar.add(checked(r), arcname=k, recursive=False)
    with tarfile.open(evidence) as tar:
        assert set(tar.getnames()) == book.keys()
        for k, r in book.items():
            with tar.extractfile(k) as src:
                assert file_digest(src, "sha256").hexdigest() == r["sha256"], k
    write_json(
        RESULT / "publication.json",
        {
            "scope": "Analytic Bayer proposals and target-informed gain headroom",
            "archive": bound(evidence),
            "manifest": bound(native),
            "summary": bound(summary),
            "members": book,
        },
    )
    print(bound(evidence), flush=True)


if __name__ == "__main__":
    main()
