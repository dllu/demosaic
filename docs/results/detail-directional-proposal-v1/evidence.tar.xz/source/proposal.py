"""Build overlapping measured Bayer residual proposals with matched radial and directional support."""

from functools import cache
from pathlib import Path
import sys

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.fft import fft2, ifft2, fftshift, ifftshift
from scipy.ndimage import gaussian_filter

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("detail-regime-router-v1")))

from collect_router import base

NATIVE = 64
PACKED = NATIVE // 2
HOP = PACKED // 2
ARMS = ("radial", "directional", "residual checked")
CAP = 32 / 65535


@cache
def geometry():
    k = np.fft.fftshift(np.fft.fftfreq(PACKED)) / 2
    y, x = np.meshgrid(k, k, indexing="ij")
    width = np.hypot(x, y)
    taper = np.clip((width - 0.026) / 0.028, 0, 1) * np.clip((0.242 - width) / 0.031, 0, 1)
    angle = np.arctan2(y, x)
    lo = np.asarray([0.046, 0.078, 0.116, 0.160, 0.210])
    spacing = np.asarray([0.018, 0.021, 0.025, 0.030, 0.039])
    raw = np.exp(-0.5 * ((width.ravel()[None] - lo[:, None]) / spacing[:, None]) ** 2)
    raw *= taper.ravel()
    dirs = np.arange(8) * np.pi / 8
    angular = np.exp(5.0 * (np.cos(2 * (angle.ravel()[None] - dirs[:, None])) - 1))
    wide = np.sqrt(np.outer(np.hanning(NATIVE + 2)[1:-1], np.hanning(NATIVE + 2)[1:-1]))

    def normalized(a):
        m = a.sum(-1, keepdims=True)
        return a / np.maximum(m, 1e-15)

    sectors = (raw[:, None, :] * angular[None]).reshape(-1, PACKED**2)
    return (
        (y, x),
        wide,
        taper,
        (normalized(raw), normalized(raw.T)),
        (normalized(sectors), normalized(sectors.T)),
    )


@cache
def lattice_operators(oy, ox):
    k, window, *_ = geometry()
    us = window[oy::2, ox::2]
    q = (np.arange(PACKED) * 2 - (NATIVE - 1) / 2) / NATIVE
    v, u = np.meshgrid(q + oy / NATIVE, q + ox / NATIVE, indexing="ij")
    plane = np.stack((np.ones_like(u), u, v), axis=-1).reshape(-1, 3)
    weight = us.ravel() ** 2
    coeff = np.linalg.solve(plane.T @ (weight[:, None] * plane), plane.T * weight)
    offset = np.exp(-2j * np.pi * (k[0] * oy + k[1] * ox))
    return us, plane, coeff, offset


def locals_(pixels):
    result = np.pad(pixels, ((0, 0), (HOP, HOP), (HOP, HOP)), mode="reflect")
    return sliding_window_view(result, (PACKED, PACKED), axis=(-2, -1))[:, ::HOP, ::HOP]


def transforms(obs, anchor, oy, ox):
    window, plane, projection, phase = lattice_operators(oy, ox)
    shape = obs.shape

    def coefficients(v):
        flat = v.reshape(-1, PACKED**2)
        residual = flat - (flat @ projection.T) @ plane.T
        spatial = residual.reshape(shape) * window
        return fftshift(fft2(spatial, axes=(-2, -1)), axes=(-2, -1)) * phase

    return coefficients(obs), coefficients(obs - anchor), float((window**2).sum())


def attenuation(cross, noise, pool, spread, *, floor):
    shape = cross.shape
    statistic = (cross.reshape(-1, PACKED**2) @ pool.T) / noise.reshape(-1, 1)
    positive = np.maximum(statistic - floor, 0)
    confidence = positive / (positive + 0.8)
    return (confidence @ spread.T).reshape(shape)


def native_ola(spectrum, shape, taper, wide):
    shp = spectrum.shape[:-2]
    centered = np.zeros((*shp, NATIVE, NATIVE), dtype=spectrum.dtype)
    i = NATIVE // 2 - PACKED // 2
    centered[..., i : i + PACKED, i : i + PACKED] = spectrum * taper
    batch = 4 * ifft2(ifftshift(centered, axes=(-2, -1)), axes=(-2, -1)).real
    h, w = shape
    answer = np.zeros((batch.shape[0], h + NATIVE, w + NATIVE), dtype=float)
    weight = np.zeros(answer.shape[-2:], dtype=float)
    for y in range(shp[1]):
        for x in range(shp[2]):
            slice_y = slice(y * 2 * HOP, y * 2 * HOP + NATIVE)
            slice_x = slice(x * 2 * HOP, x * 2 * HOP + NATIVE)
            answer[:, slice_y, slice_x] += batch[:, y, x] * wide
            weight[slice_y, slice_x] += wide**2
    pad = 2 * HOP
    result = (answer / np.maximum(1e-10, weight))[..., pad : pad + h, pad : pad + w]
    assert result.shape[-2:] == shape
    return result


def fields(meta, predictions, profile):
    colors = np.asarray(meta["colors"])
    raw = meta["packed"]
    green = predictions["nominal"][:, 1]
    assert raw.ndim == 4 and colors.shape == (4,) and len(green) == len(raw)
    phases = np.flatnonzero(colors == 1)
    assert len(phases) == 2
    measurements, remaining, noise = [], [], []
    for p in phases:
        y, x = divmod(int(p), 2)
        observed, estimate = locals_(raw[:, p]), locals_(green[:, y::2, x::2])
        actual, residual, scale = transforms(observed, estimate, y, x)
        v = np.maximum(2e-10, profile["shot"] * observed.mean((-1, -2)).clip(0) + profile["read"])
        noise.append(v * scale)
        measurements.append(actual)
        remaining.append(residual)
    floor = np.sqrt(noise[0] * noise[1])
    cross = (measurements[0] * measurements[1].conj()).real
    cross_rem = (remaining[0] * remaining[1].conj()).real
    average = (remaining[0] + remaining[1]) * 0.5
    _, window, taper, radial, directional = geometry()
    r = attenuation(cross, floor, *radial, floor=0.19)
    a = attenuation(cross, floor, *directional, floor=0.19)
    v = attenuation(cross_rem, floor, *directional, floor=0.05)
    neutral = np.linalg.solve(meta["matrix"].astype(float), np.ones(3)) / meta["wb"]
    ratio = max(abs(float(neutral[1])), 1e-8)
    result = {}
    for k, support in zip(ARMS, (r, a, a * v), strict=True):
        delta = native_ola(average * support, green.shape[-2:], taper, window) / ratio
        cap = CAP / np.maximum(CAP, np.sqrt(gaussian_filter(delta**2, (0, 12, 12))))
        valid = np.all((raw < 0.995) & (raw > 0.001), axis=1)
        valid = np.repeat(np.repeat(valid, 2, axis=-1), 2, axis=-2)
        result[k] = delta * cap * gaussian_filter(valid.astype(float), (0, 2.0, 2.0))
    return result, neutral
