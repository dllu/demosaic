"""Run the matched Local 50k proposals on the retained off-grid wire mosaics."""

import json
from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from proposal import OUT
from collect_router import OUT as ROUTER, batch, forward, identities, load_model, save

OFF_GRID = Path("/mnt/external/demosaic/scene-coherent-fourier-v1/transfer/parents.json")


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 9 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    source = reference(OFF_GRID)
    info = read_json(checked(source))
    base = reference(ROUTER / "plan.json")
    spec = read_json(checked(base))
    ids = identities(r["source"] for r in info["rows"])
    assert len(ids) == 64
    with checked(spec["training_manifest"]).open() as f:
        assert ids.isdisjoint(identities(map(json.loads, f)))
    local = load_model(spec["parent"])
    folder = OUT / "off-grid"
    folder.mkdir(exist_ok=True)
    stamp = []
    tic = monotonic()
    with ieee_fp32():
        for i, r in enumerate(info["rows"]):
            with np.load(checked(r["input"]), allow_pickle=False) as f:
                d = {k: f[k] for k in ("packed", "variance", "colors", "wb", "matrix")}
            path = folder / f"local-{i:02}.npz"
            if not path.exists():
                got = forward(local, batch(d), r["profile"], reuse=True)
                result = {k: v.cpu().numpy() for k, v in got.items()}
                assert all(
                    v.shape == (4, 3, 256, 256) and np.isfinite(v).all() for v in result.values()
                )
                save(path, result)
            stamp.append(r | {"local": reference(path)})
            if len(stamp) % 8 == 0:
                print(len(stamp), round(monotonic() - tic, 2), flush=True)
    write_json(
        folder / "completed.json",
        {
            "driver": reference(__file__),
            "source": source,
            "parent": spec["parent"],
            "router_inputs": base,
            "source_overlap_local_manifest": 0,
            "rows": stamp,
            "seconds": monotonic() - tic,
        },
    )


if __name__ == "__main__":
    run()
