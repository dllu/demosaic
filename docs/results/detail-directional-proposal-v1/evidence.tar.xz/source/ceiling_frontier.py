"""Constrain the exact-target wire fit to deliver a specified contrast gain."""

from pathlib import Path
from statistics import mean
from time import monotonic

import numpy as np
from scipy.optimize import brentq
import torch

from demosaic.experiments.artifacts import reference, write_json
from proposal import OUT, base, fields
from proposal_ceiling import ROI, native_proposal_columns, remove
from measure_proposal import FWD, off_grid
from review_selector import wire_scorer
import deficit

LEVELS = (0.5, 1.0, 2.0, 4.0)


def curve(A, cap, target, anchor):
    cap = cap.astype(np.float64)
    S = 65535 / np.sqrt(len(target))
    e = (target - anchor) * S
    q = A * S
    g = q @ q.T
    v = q @ e
    multiplier = max(float(np.linalg.eigvalsh(g)[-1]), 1e-20)
    a = 100 * (A @ target) / (target @ target)
    maximum = float(np.maximum(a, 0) @ cap)
    scores = {}
    for gain in LEVELS:
        if maximum <= gain + 1e-9:
            scores[str(gain)] = None
            continue
        speed = 1.0
        x = np.zeros_like(v)
        y = x.copy()
        norm = float(np.linalg.norm(a))

        def project(z):
            cut = np.clip(z, 0, cap)
            if a @ cut >= gain:
                return cut
            h = a / norm

            def decision(t):
                return float(a @ np.clip(z + t * h, 0, cap) - gain)

            hi = 1.0
            while decision(hi) < 0:
                hi *= 2
            t = brentq(decision, 0, hi, xtol=1e-10)
            return np.clip(z + t * h, 0, cap)

        for _ in range(500):
            step = project(y - (g @ y - v) / multiplier)
            rate = (1 + np.sqrt(1 + 4 * speed * speed)) / 2
            y = step + (speed - 1) / rate * (step - x)
            x = step
            speed = rate
        assert a @ x >= gain - 1e-8
        actual = q.T @ x - e
        # A feasible dual multiplier for the one linear inequality gives
        # a bound for the supporting hyperplane on the constrained box.
        gradient = 2 * (g @ x - v)
        z = cap * (gradient < 0)
        missing = gain - a @ z
        mu = 0.0
        if missing > 0:
            beneficial = ((a > 0) & (z == 0)) | ((a < 0) & (z == cap))
            idx = np.flatnonzero(beneficial & (cap > 0))
            prices = np.abs(gradient[idx] / a[idx])
            ranked = np.argsort(prices)
            for rank in ranked:
                i = idx[rank]
                mu = prices[rank]
                missing -= cap[i] * abs(a[i])
                if missing <= 1e-10:
                    break
            assert missing <= 1e-8
        v2 = float(actual @ actual)
        bound = mu * gain + np.minimum(gradient - mu * a, 0) @ cap
        lo = max(0.0, v2 + float(bound - gradient @ x))
        assert lo <= v2 + 1e-7
        scores[str(gain)] = {
            "paired_RMS": float(np.sqrt(v2)),
            "RMS_lower_bound": float(np.sqrt(lo)),
            "achieved_gain": float(a @ x),
        }
    return scores


def run():
    torch.set_num_threads(2)
    before = reference(FWD)
    scorer, factory = wire_scorer()
    start = monotonic()
    output = []
    for r, d, p, proof in off_grid(before):
        geo = r["fixture"]["geometry"]
        if geo["family"] in ("smooth-dip", "contrast-step"):
            d = d | {"support": np.ones_like(d["support"])}
        metric = factory(d, geo)
        parent = base.old.luma(p["nominal"], d)[ROI]
        y = remove((parent[0] - parent[2])[metric.intact], metric.intact_nuisance)
        _, _, cap, first, _ = base.local(d, p, r["profile"])
        A, c = native_proposal_columns(first, np.stack((cap, np.ones_like(cap)), axis=1), metric)
        raw = fields(d, p, r["profile"])[0]["directional"]
        clean = deficit.fields(d, p, r["profile"])[0]["parent phase"]
        menu = {"conditioning": (A, c)}
        bound = np.ones((len(parent), 1, 8, 8))
        for k, basis in (("directional", raw), ("parent phase", clean)):
            u, z = native_proposal_columns(basis[:, None], bound, metric)
            menu[k] = (np.concatenate((A, u)), np.concatenate((c, z)))
        decisions = {k: curve(a, limits, metric.truth_weak, y) for k, (a, limits) in menu.items()}
        origin = float(np.sqrt(np.mean((y - metric.truth_weak) ** 2)) * 65535)
        output.append(
            {"id": r["id"], "source": proof, "paired_RMS_parent": origin, "curves": decisions}
        )
        if len(output) % 8 == 0:
            print(len(output), round(monotonic() - start, 1), flush=True)
    grouped = {}
    for level in map(str, LEVELS):
        methods = output[0]["curves"]
        common = [r for r in output if all(r["curves"][k][level] is not None for k in methods)]
        grouped[level] = {
            k: {
                "viable_sources": sum(r["curves"][k][level] is not None for r in output),
                "mean_RMS_delta_common": mean(
                    r["curves"][k][level]["paired_RMS"] - r["paired_RMS_parent"] for r in common
                )
                if common
                else None,
                "common_count": len(common),
                "largest_RMS_certificate_gap": max(
                    (r["curves"][k][level]["paired_RMS"] - r["curves"][k][level]["RMS_lower_bound"])
                    for r in output
                    if r["curves"][k][level] is not None
                ),
            }
            for k in methods
        }
    print(grouped, flush=True)
    write_json(
        OUT / "ceiling-frontier.json",
        {
            "driver": reference(Path(__file__)),
            "source": before,
            "scorer": scorer,
            "rows": output,
            "summary": grouped,
            "seconds": monotonic() - start,
            "scope": "Clean wire target and separate role gains supplied; intact paired error and response only.",
        },
    )


if __name__ == "__main__":
    run()
