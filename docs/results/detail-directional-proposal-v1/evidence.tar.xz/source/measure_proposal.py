"""Calibrate spectral residual proposals on measured quiet and gap budgets."""

from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from proposal import HERE, OUT, ARMS, fields, base
from collect_router import OUT as ROUTER, REGIMES
from score_router import captures
from confirm_router import networks, locked_points
from review_router import render as make_router
from evaluate_direct import Cases
from evaluate_selector import values
from review_selector import wire_scorer
import mild_score as m
import score

PRIMARY = "directional"
GRID = tuple(float(x) for x in np.linspace(0, 1, 51))
WIRE_LIMITS = {
    "exact_flat_RMS_DN16": 0.10,
    "gap_weak_RMS_DN16": 0.05,
    "exterior_only_weak_RMS_DN16": 0.05,
}
FWD = OUT / "off-grid/completed.json"
SHORT = ROUTER / "confirmation/confirm/completed.json"


def binding():
    ref = reference(ROUTER / "robust-calibration.json")
    prior = reference(ROUTER / "score-calibration.json")
    frozen = read_json(checked(ref))
    original = read_json(checked(prior))
    fit, net = networks()
    assert frozen["fit"] == list(fit)
    k = frozen["policy"]["primary"]
    points = locked_points(frozen["policy"], original["policy"])
    return {
        "calibration": ref,
        "original": prior,
        "checkpoints": fit,
        "name": k,
        "dose": points[k],
    }, net


def alternatives(d, p, r, params, router):
    mode = router["name"]
    original = make_router(d, p, r, params, {mode: router["dose"]})[mode]
    corrections, neutral = fields(d, p, r["profile"])
    values_ = {k: a[:, None] * neutral[None, :, None, None] for k, a in corrections.items()}
    return original, values_


def exact_natural(row, d, p, params, router):
    body, delta = alternatives(d, p, row, params, router)
    source, target, base_coefs = (score.stats(a, d) for a in (p["nominal"], d["target"], body))
    zero = np.zeros_like(source)
    arms = {k: m.terms(target, base_coefs, score.stats(v, d), zero) for k, v in delta.items()}
    arms |= {
        "nominal": m.terms(target, source, zero, zero),
        "router": m.terms(target, base_coefs, zero, zero),
        "v120": m.terms(target, score.stats(p["v120"], d), zero, zero),
    }
    return arms


def replay_photo(file, params, router):
    rows = []
    for row, regimes in captures(file):
        terms = {k: exact_natural(row, d, p, params, router) for k, (d, p) in regimes.items()}
        rows.append(
            {
                "id": row["id"],
                "source": row["source"]["id"],
                "inputs": row["inputs"],
                "regimes": terms,
            }
        )
    return rows


def off_grid(stamp):
    for row in read_json(checked(stamp))["rows"]:
        with np.load(checked(row["input"]), allow_pickle=False) as f:
            d = {k: f[k] for k in f.files}
        with np.load(checked(row["local"]), allow_pickle=False) as f:
            p = {k: f[k] for k in f.files}
        saved = row["rgb"]
        if isinstance(saved, dict) and set(saved) >= {"path", "sha256"}:
            with np.load(checked(saved), allow_pickle=False) as f:
                p.update({k: f[k] for k in f.files if k in ("100k", "V120", "v120", "origin")})
        elif isinstance(saved, dict):
            for k, v in saved.items():
                p[k] = np.load(checked(v), allow_pickle=False)
        yield row, d, p, {"input": row["input"], "predictions": row["local"], "original": saved}


def replay_wire(items, params, router):
    scorer, factory = wire_scorer()
    rows = []
    for row, data, pred, proof in items:
        geo = row["fixture"]["geometry"]
        if geo["family"] in ("smooth-dip", "contrast-step"):
            data = data | {"support": np.ones_like(data["support"])}
        metric = factory(data, geo)
        body, delta = alternatives(data, pred, row, params, router)
        controls = {
            "nominal": metric(pred["nominal"]),
            "router": metric(body),
        }
        controls |= {
            k: metric(v) for k, v in pred.items() if k in ("100k", "V120", "v120", "origin")
        }
        # For each metric the squared RMS is a quadratic in delivery scale.
        coeff = {}
        for name, move in delta.items():
            pairs = [metric(body + u * move) for u in (-1, 0, 1)]
            series = {}
            for k in pairs[0]:
                if k == "weak_response_pp":
                    v = pairs[1][k]
                    series[k] = [v, (pairs[2][k] - pairs[0][k]) * 0.5, 0.0]
                    continue
                a, b, c = (d[k] ** 2 for d in pairs)
                series[k] = [b, (c - a) * 0.5, (c + a) * 0.5 - b]
            coeff[name] = series
        rows.append(
            {
                "id": row["id"],
                "fixture": row["fixture"],
                "source": proof,
                "controls": controls,
                "coefficients": coeff,
            }
        )
    return scorer, rows


def natural(rows, mode, method, scale):
    return values([{"scores": r["regimes"][mode]} for r in rows], method, (scale, 0))


def wires(rows, method, metric, scale):
    if method not in ARMS:
        return np.asarray(
            [r["controls"][method][metric] for r in rows if metric in r["controls"][method]]
        )
    coeff = np.asarray(
        [r["coefficients"][method][metric] for r in rows if metric in r["coefficients"][method]]
    )
    d = coeff @ np.array([1, scale, scale * scale])
    return d if metric == "weak_response_pp" else np.sqrt(np.maximum(0, d))


def wire_means(rows, method, scale):
    present = rows[0]["coefficients"].keys()
    measures = sorted(
        {
            k
            for r in rows
            for k in (r["coefficients"][method] if method in present else r["controls"][method])
        }
    )
    return {k: float(wires(rows, method, k, scale).mean()) for k in measures}


def specs(photo, calibration_wire):
    nominal = {mode: score.evaluate(natural(photo, mode, "nominal", 0)) for mode in REGIMES}
    anchor = wire_means(calibration_wire, "nominal", 0)
    policy = {}
    for arm in ARMS:
        candidates = []
        for t in GRID:
            view = {mode: score.evaluate(natural(photo, mode, arm, t)) for mode in REGIMES}
            actual = wire_means(calibration_wire, arm, t)
            photo_ok = all(
                v[k] - nominal[n][k] <= lim
                for n, v in view.items()
                for k, lim in score.LIMITS.items()
            )
            wires_ok = all(actual[k] - anchor[k] <= lim for k, lim in WIRE_LIMITS.items())
            candidates.append(
                {
                    "dose": t,
                    "photo": view,
                    "wire": actual,
                    "photo_pass": photo_ok,
                    "wire_pass": wires_ok,
                }
            )
        joint = [r for r in candidates if r["photo_pass"] and r["wire_pass"]]
        wire_only = [r for r in candidates if r["wire_pass"]]
        pred = lambda r: r["wire"]["weak_response_pp"]
        policy[arm] = {
            "locked": max(joint, key=pred) if joint else None,
            "wire-only": max(wire_only, key=pred) if wire_only else None,
            "table": candidates,
        }
    return {
        "photo_limits": score.LIMITS,
        "wire_limits": WIRE_LIMITS,
        "anchor": anchor,
        "nominal": nominal,
        "arms": policy,
    }


def draws(n, rng):
    return np.vstack((np.arange(n), rng.integers(n, size=(8000, n))))


def deltas(a, b):
    change = a - b
    return [float(change[0]), *np.quantile(change[1:], (0.025, 0.975)).tolist()]


def stats_wire(rows, policy, wireonly=False):
    label = "wire-only" if wireonly else "locked"
    doses = {k: v[label]["dose"] for k, v in policy["arms"].items() if v[label] is not None}
    rng = np.random.default_rng(202611201012)
    arms = list(rows[0]["controls"]) + list(doses)
    metrics = sorted({k for r in rows for k in r["controls"]["nominal"]})
    stats = {}
    for metric in metrics:
        groups = {k: wires(rows, k, metric, doses.get(k, 0.0)) for k in arms}
        n = len(groups["nominal"])
        ix = draws(n, rng)
        sampled = {k: v[ix].mean(axis=1) for k, v in groups.items()}
        stats[metric] = {
            k: {
                "value": float(v[0]),
                "from nominal": deltas(v, sampled["nominal"]),
                "from router": deltas(v, sampled["router"]),
            }
            for k, v in sampled.items()
        }
        if "directional" in sampled and "radial" in sampled:
            stats[metric]["directional"]["from radial"] = deltas(
                sampled["directional"], sampled["radial"]
            )
    return stats


def stats_photo(rows, policy):
    doses = {k: v["locked"]["dose"] for k, v in policy["arms"].items() if v["locked"] is not None}
    arms = ("nominal", "router", "v120", *doses)
    rng = np.random.default_rng(202611201013)
    stats = {}
    for k in REGIMES:
        iv = draws(len(rows), rng)
        p = {arm: natural(rows, k, arm, doses.get(arm, 0.0)) for arm in arms}
        results = {arm: score.evaluate(v) for arm, v in p.items()}
        resample = {
            arm: {m: np.sqrt((v[m][iv] ** 2).mean(axis=1)) for m in score.LIMITS}
            | {"response_pp": 100 * v["projection"][iv].sum(axis=1) / v["true"][iv].sum(axis=1)}
            for arm, v in p.items()
        }
        contrast = {
            k_: {
                a: {m: deltas(v, e[m]) for m, v in s.items()}
                for a, e in resample.items()
                if a in ("nominal", "router", "radial")
            }
            for k_, s in resample.items()
        }
        order = np.argsort(p["nominal"]["true"])[: len(rows) // 2]
        stats[k] = {
            "scores": results,
            "intervals": contrast,
            "weaker_half": {
                arm: score.evaluate({m: a[order] for m, a in v.items()}) for arm, v in p.items()
            },
        }
    return stats


def run(mode):
    torch.set_num_threads(2)
    router, p = binding()
    tic = monotonic()
    if mode == "calibration":
        source = reference(ROUTER / "calibration/completed.json")
        natural_rows = replay_photo(source, p, router)
        cfg = Cases("wires")
        sh, wire_rows = replay_wire((case for i, case in enumerate(cfg) if i % 2 == 0), p, router)
        policies = specs(natural_rows, wire_rows)
        report = {
            "source": source,
            "wire_receipt": cfg.source,
            "wire_scorer": sh,
            "photos": natural_rows,
            "wires": wire_rows,
            "policy": policies,
        }
        print(
            {
                k: (
                    q["locked"]["dose"] if q["locked"] else None,
                    q["wire-only"]["dose"] if q["wire-only"] else None,
                )
                for k, q in policies["arms"].items()
            },
            flush=True,
        )
    else:
        cal = reference(OUT / "calibration.json")
        policy = read_json(checked(cal))["policy"]
        if mode == "natural":
            source = reference(SHORT)
            rows = replay_photo(source, p, router)
            report = {
                "source": source,
                "calibration": cal,
                "rows": rows,
                "scores": stats_photo(rows, policy),
            }
        elif mode == "wires":
            cfg = Cases("wires")
            source = cfg.source
            proof, rows = replay_wire((case for i, case in enumerate(cfg) if i % 2 == 1), p, router)
            report = {
                "source": source,
                "scorer": proof,
                "calibration": cal,
                "rows": rows,
                "scores": stats_wire(rows, policy),
                "wire_only": stats_wire(rows, policy, True),
            }
        else:
            source = reference(FWD)
            proof, rows = replay_wire(off_grid(source), p, router)
            report = {
                "source": source,
                "scorer": proof,
                "calibration": cal,
                "rows": rows,
                "scores": stats_wire(rows, policy),
                "wire_only": stats_wire(rows, policy, True),
            }
    write_json(
        OUT / (mode + ".json"),
        {
            "driver": reference(Path(__file__)),
            "operator": reference(HERE / "proposal.py"),
            "router": router,
            "seconds": monotonic() - tic,
            **report,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
