"""Estimate a wavelength-dependent amplitude deficit from the two native greens."""

import numpy as np
from scipy.ndimage import gaussian_filter

from proposal import CAP, geometry, locals_, transforms, native_ola

ARMS = ("raw deficit", "parent phase")


def estimate_deficit(cross, residual, noise, pool, spread):
    shape = cross.shape
    s = (cross.reshape(-1, shape[-2] * shape[-1]) @ pool.T) / noise.reshape(-1, 1)
    d = (residual.reshape(-1, shape[-2] * shape[-1]) @ pool.T) / noise.reshape(-1, 1)
    # Phasewise signal and deficit are compared in the same direction/band.
    # The noise-relative denominator regularizes small and negative estimates.
    strength = np.clip((d - 0.08) / (np.maximum(0, s) + 1.5), 0, 0.35)
    return (strength @ spread.T).reshape(shape)


def fields(meta, predictions, profile):
    raw = meta["packed"]
    green = predictions["nominal"][:, 1]
    physical = np.flatnonzero(meta["colors"] == 1)
    assert len(physical) == 2
    q = []
    for p in physical:
        oy, ox = divmod(int(p), 2)
        data = locals_(raw[:, p])
        a, r, window = transforms(data, locals_(green[:, oy::2, ox::2]), oy, ox)
        noise = window * np.maximum(
            2e-10, profile["shot"] * data.mean((-1, -2)).clip(0) + profile["read"]
        )
        q.append((a, r, noise))
    (a0, r0, n0), (a1, r1, n1) = q
    product = (a0 * a1.conj()).real
    wanted = (a0 * r1.conj() + a1 * r0.conj()).real * 0.5
    _, window, taper, _, spectra = geometry()
    fraction = estimate_deficit(product, wanted, np.sqrt(n0 * n1), *spectra)
    mean = (a0 + a1) * 0.5
    denoised = mean - (r0 + r1) * 0.5
    neutral = np.linalg.solve(meta["matrix"].astype(float), np.ones(3)) / meta["wb"]
    scale = max(abs(float(neutral[1])), 1e-8)
    safe = np.all((raw < 0.995) & (raw > 0.001), axis=1)
    safe = np.repeat(np.repeat(safe, 2, axis=-1), 2, axis=-2)
    safe = gaussian_filter(safe.astype(float), (0, 2, 2))
    out = {}
    for mode, s in zip(ARMS, (mean, denoised), strict=True):
        move = native_ola(fraction * s, green.shape[-2:], taper, window) / scale
        bound = CAP / np.maximum(CAP, np.sqrt(gaussian_filter(move**2, (0, 12, 12))))
        out[mode] = move * bound * safe
    return out, neutral
