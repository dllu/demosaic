"""Repeat the locks and transfer for measured amplitude-deficit proposals."""

from pathlib import Path
from time import monotonic
from unittest.mock import patch

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import proposal
import deficit
import measure_proposal as m
from collect_router import OUT as ROUTER

OUT = proposal.OUT / "deficit"


def run():
    torch.set_num_threads(2)
    OUT.mkdir(exist_ok=True)
    router, params = m.binding()
    original = reference(proposal.OUT / "calibration.json")
    plan = read_json(checked(original))
    photo = plan["source"]
    wire = m.Cases("wires")
    with patch.object(m, "fields", deficit.fields), patch.object(m, "ARMS", deficit.ARMS):
        tic = monotonic()
        pn = m.replay_photo(photo, params, router)
        scorer, wn = m.replay_wire(
            (case for i, case in enumerate(wire) if i % 2 == 0), params, router
        )
        choose = m.specs(pn, wn)
        print(
            {k: (v["locked"]["dose"], v["wire-only"]["dose"]) for k, v in choose["arms"].items()},
            flush=True,
        )
        provisional = OUT / "calibration.json"
        scope = {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(deficit.__file__)),
            "router": router,
            "previous_calibration": original,
        }
        write_json(
            provisional,
            scope
            | {
                "photo": photo,
                "wire": wire.source,
                "scorer": scorer,
                "photos": pn,
                "wires": wn,
                "policy": choose,
                "seconds": monotonic() - tic,
            },
        )
        lock = reference(provisional)
        refs = {
            "natural": reference(m.SHORT),
            "wires": wire.source,
            "off-grid": reference(m.FWD),
        }
        for name, source in refs.items():
            t = monotonic()
            if name == "natural":
                rows = m.replay_photo(source, params, router)
                q = m.stats_photo(rows, choose)
                meta = {}
            else:
                sequence = (
                    (case for i, case in enumerate(wire) if i % 2 == 1)
                    if name == "wires"
                    else m.off_grid(source)
                )
                proof, rows = m.replay_wire(sequence, params, router)
                q = m.stats_wire(rows, choose)
                meta = {"scorer": proof, "wire_only": m.stats_wire(rows, choose, True)}
            write_json(
                OUT / (name + ".json"),
                scope
                | {
                    "calibration": lock,
                    "source": source,
                    "rows": rows,
                    "scores": q,
                    "seconds": monotonic() - t,
                    **meta,
                },
            )


if __name__ == "__main__":
    run()
