"""Refit only the weak carrier with the validated exterior geometry."""

from functools import partial
from pathlib import Path
from types import SimpleNamespace
from time import monotonic
import sys

import numpy as np
import torch
from scipy.special import expit

from demosaic._mesh_pooled import _CENTERS, _CORE, _SMOOTH, _CENTER_BACKGROUND, _STRIDE, _footprint, _rgb, _wave, _windows
from demosaic._mesh_presence import _RING, _PACKED_CORE, _ring_prior
from demosaic.mesh_carrier_fit import _positions
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic._mesh_weak_phase import _carrier
import transport_phase as phase
from transport_phase import OUT, basis
from replay_transport import CurvedFundamental
from conditional import replay, combined, conditional_posterior, prior_shape
import replay_exterior_support as template


EXTRA = ('fixed_2.5', 'curvature_2.5', 'same_support', 'refit_support', 'refit_guarded')
ARMS = ('combined', 'weak', *EXTRA)


def regress(design, smooth, measurements, shot, read):
    projection = np.linalg.pinv(smooth, rcond=1e-8) @ design
    residual = design - smooth @ projection
    inverse_noise = 1 / np.maximum(2e-11, shot * np.maximum(0, measurements.mean(axis=1)) + read)
    gram = (residual.swapaxes(1,2) @ residual) * inverse_noise[:,None,None]
    moment = (measurements[:, None] @ residual)[:,0] * inverse_noise[:,None]
    return gram, moment, residual


def weak_patch(parent, local, scene, colors, roi, frequency, direction, beta, shot, read):
    x, y, w, _ = local
    offsets = (np.indices((192,192), dtype='d') - 95.5)/128
    warp = basis(offsets[1], offsets[0]) @ beta
    weak = _carrier(192, -16, -16, frequency)[...,direction,:]
    shifted = (weak[...,0] + 1j*weak[...,1]) * np.exp(1j*warp)
    local_bend = np.stack([_windows(c, 64, _STRIDE) for c in (shifted.real, shifted.imag)], axis=-1)
    nominal = _wave(64, frequency)
    local_waves = np.broadcast_to(nominal, (len(_CENTERS), *nominal.shape)).copy()
    local_waves[...,direction,:] = local_bend
    ring_design = local_waves.reshape(len(_CENTERS),64,64,4)
    core_waves = local_waves[:,_CORE[0],_CORE[1]]
    core = core_waves[...,direction,:]
    nuisance = np.concatenate((_CENTER_BACKGROUND, nominal[_CORE][...,1-direction,:]), axis=-1)
    ring_gram, ring_moment, center_gram, center_moment = [], [], [], []
    for r,c in _positions(colors,*roi[:2]):
        raw = _windows(_footprint(scene,roi[:2],(r,c)),32,_STRIDE//2)
        keep = _RING[r::2,c::2]
        gram, moment, _ = regress(ring_design[:,r::2,c::2][:,keep], _SMOOTH[r::2,c::2][keep], raw[:,keep], shot, read)
        ring_gram.append(gram)
        ring_moment.append(moment)
        center = raw[:,_PACKED_CORE,_PACKED_CORE].reshape(len(raw), -1)
        bg = nuisance[r::2,c::2].reshape(center.shape[1],-1)
        gram, moment, _ = regress(core[:,r::2,c::2].reshape(len(raw),-1,2), bg, center, shot, read)
        center_gram.append(gram)
        center_moment.append(moment)
    prior, deviation = _ring_prior(sum(ring_gram),sum(ring_moment))
    gram = sum(center_gram)
    moment = sum(center_moment)
    precision = prior_shape(prior.reshape(-1,2,2)[:,direction],deviation[:,direction],'free')
    fit, evidence = conditional_posterior(gram, moment, prior.reshape(-1,2,2)[:,direction], precision)
    strength = np.clip((expit(evidence-5) - .2)/.8, 0., 1.)
    parent_data = _windows(parent[1,y:y+w,x:x+w],32,_STRIDE).reshape(len(_CENTERS),-1)
    _, _, residual = regress(core.reshape(len(_CENTERS),-1,2), nuisance.reshape(32**2,-1), parent_data, 0., 1.)
    transposed = residual.swapaxes(1,2)
    inherited = np.linalg.solve(transposed @ residual, transposed @ parent_data[...,None])[...,0]
    cap = np.linalg.norm(np.linalg.solve(gram,moment[...,None])[...,0],axis=1)
    delta = (fit-inherited)*strength[:,None]
    delta *= np.minimum(1,strength*cap/np.linalg.norm(delta,axis=1).clip(min=1e-15))[:,None]
    new_patch = np.einsum('nyxf,nf->nyx',core,delta)
    old_wave, old = combined(parent[:,y-16:y+176,x-16:x+176],scene,colors,roi,frequency,shot,read)
    old_patch = np.einsum('yxf,nf->nyx',old_wave[...,direction,:],old[:,direction])
    return new_patch-old_patch, strength>0


def qualify(parent, local, scene, colors, roi, freq, noise, wb, matrix, *, prepared):
    source, trace = phase.qualify(parent,local,scene,colors,roi,freq,noise,wb,matrix,prepared=prepared)
    result = {k: source[k] for k in ARMS if k in source}
    anchor = result['combined']
    result |= dict.fromkeys(EXTRA[-3:], result['weak'])
    if not trace.get('selected'):
        return result, trace
    direction = trace['weak']
    active = prepared[direction][0]['curvature']
    if active is None:
        return result, trace
    shot, read = noise['shot'],noise['read']
    patch, eligible = weak_patch(parent, local, scene, colors, roi, freq, direction, active[0], shot, read)
    same = np.isin(np.arange(len(_CENTERS)),trace['selected'])
    neutral = np.linalg.solve(matrix,np.ones(3))/wb
    neutral /= neutral[1]
    resolution = _rgb(np.where(eligible[:,None,None],patch,0.),neutral,anchor.dtype)
    result['same_support'] = anchor + _rgb(np.where((eligible&same)[:,None,None],patch,0.),neutral,anchor.dtype)
    result['refit_support'] = anchor + resolution
    scores = phase.fields_from_geometry(scene,roi,freq,direction,shot,read,active)
    result['refit_guarded'] = (anchor + resolution.astype('d')*np.clip(1+(scores-2.5)/2,0,1)).astype(anchor.dtype)
    return result, trace | {'refit_added_windows': int((eligible & ~same).sum()), 'refit_lost_windows': int((same & ~eligible).sum())}


def assess(*args, **kwargs):
    template.model = SimpleNamespace(ARMS=ARMS,qualify=partial(qualify,prepared={}))
    return template.assess(*args, **kwargs)


def main(name):
    torch.set_num_threads(2)
    start = monotonic()
    replay.comparisons = assess
    replay.WireFundamental = CurvedFundamental
    replay.OUT = OUT
    if name == 'curved':
        replay.PREVIOUS = OUT/'fresh'
        source, plan, rows = replay.load_confirmation()
        sense = {'plan': plan, 'previous': reference(OUT/'curved.json')}
    else:
        source, rows = replay.load_calibration()
        sense = {'previous': reference(OUT/'calibration.json')}
    write_json(OUT/f'refit-{name}.json', {'driver':reference(Path(__file__)), 'source':source,
                                        **sense, 'rows':rows, 'seconds':monotonic()-start})


if __name__ == '__main__':
    main(sys.argv[1])
