"""Prepare a source-disjoint curved carrier panel with existing local restorers."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic') / HERE.name / 'fresh'
sys.path.insert(0, str(HERE.with_name('local-phase-extent-v1')))
from capture_extent import prior
import curved_scene

SEED = 202611200455


def choose():
    root = OUT.parent.parent
    manifest_paths = (*prior.EXCLUSIONS, root/'local-weak-support-v1/fresh/plan.json', root/'local-phase-extent-v1/fresh/plan.json')
    refs = [reference(p) for p in manifest_paths]
    earlier = prior.earlier
    capture = earlier.capture_wide
    blocked = set()
    for binding in refs:
        capture.scan(read_json(checked(binding)), blocked)
    lines = capture.lines
    pool = read_json(checked(refs[0]))['source_pool']

    def disjoint(binding):
        for r in lines(binding):
            if binding != pool or {r['id'], r['cache_sha256']}.isdisjoint(blocked):
                yield r

    earlier.COUNT, earlier.GROUP_SIZE, earlier.SEED = 24, 6, SEED
    capture.lines = disjoint
    try:
        plan = earlier.choose()
    finally:
        capture.lines = lines
    for r in plan['sources']:
        rng = np.random.default_rng(scene_seed(SEED, r['index'], 'curvature'))
        r['geometry']['bend_cycles'] = float(rng.choice((-1., 1.)) * rng.uniform(.10, .23))
        r['id'] = r['id'].replace('nested-', 'curved-phase-')
        assert {r['source']['id'], r['source']['cache_sha256']}.isdisjoint(blocked)
    return plan | {'driver': reference(__file__), 'bend_generator': reference(curved_scene.__file__),
                   'extra_excluded_sources': refs, 'native_indices': [1, 9],
                   'primary': 'Source-level added gap luma at similar weak response with a curved weak carrier.'}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    OUT.mkdir(exist_ok=True)
    plan_path = OUT / 'plan.json'
    if not plan_path.is_file():
        write_json(plan_path, choose())
    plan = read_json(plan_path)
    assert plan['driver'] == reference(__file__)
    prior.earlier.SEED = SEED
    case_folder = OUT/'inputs'
    case_folder.mkdir(exist_ok=True)
    receipt = OUT/'inputs.json'
    if not receipt.is_file():
        observations = []
        operator = prior.earlier.capture_wide.wire_math
        fixed = operator.exact
        operator.exact = curved_scene.exact
        try:
            for r in plan['sources']:
                observations.append(prior.earlier.capture(r, plan['noise'], case_folder))
                if len(observations) % 8 == 0:
                    print('Captured curved', len(observations), flush=True)
        finally:
            operator.exact = fixed
        write_json(receipt, {'driver': reference(__file__), 'plan': reference(plan_path),
                             'observations': observations, 'seconds': monotonic()-start})
    prior.parents.OUT = OUT
    if not (OUT/'parent/result.json').is_file():
        prior.parents.main()


if __name__ == '__main__':
    main()
