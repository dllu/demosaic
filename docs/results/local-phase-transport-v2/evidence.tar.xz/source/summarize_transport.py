"""Match recovery, verify replay lineage, and examine donor phase against curved truth."""

from pathlib import Path
from statistics import mean
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from transport_phase import OUT, METHODS, basis
from reduce_support import ADDED, RESPONSE, compare, means, review_panel
from curved_scene import warp


PARITY = {'calibration': 'calibration', 'previous': 'previous', 'second': 'held', 'held': 'fresh'}


def verify(previous, current):
    worst = dict.fromkeys(('combined', 'weak', 'fixed_2.5'), 0.)
    for a,b in zip(previous, current, strict=True):
        assert a['id'] == b['id']
        for x,y in zip(a['draws'], b['draws'], strict=True):
            if 'input' in x:
                assert x['input'] == y['input'] and x['outputs'] == y['outputs']
            for arm in worst:
                old = 'local_+2.5' if arm.startswith('fixed') else arm
                for metric in x['nominal'][old]:
                    delta = abs(x['nominal'][old][metric] - y['nominal'][arm][metric])
                    worst[arm] = max(worst[arm], delta)
    np.testing.assert_equal([worst['combined'], worst['weak']], [0.,0.])
    assert worst['fixed_2.5'] <= .002
    return worst


def availability(rows):
    valid = [i for r in rows for d in r['draws'] for i in d['evidence'] if i.get('selected')]
    return {'crops_selected': len(valid), 'windows_selected': sum(len(i['selected']) for i in valid),
            'qualified_crops': {k: sum(i['phase'][k]['eligible'] for i in valid) for k in METHODS},
            'qualified_windows': {k: sum(len(i['selected']) for i in valid if i['phase'][k]['eligible']) for k in METHODS}}


def response_match_fixed(rows, values, choices):
    result = {}
    default = values['combined'][RESPONSE]
    for name in METHODS:
        if name == 'fixed':
            continue
        target = min(values[name][RESPONSE], values['fixed'][RESPONSE])
        paths = [(choices[k][0], choices[k][1] * (target-default)/(values[k][RESPONSE]-default)) for k in (name, 'fixed')]
        a, b = paths
        result[name] = {'choices': paths, 'response_matched': target, 'paired_vs_deployed_fixed': compare(rows, a, b)}
    return result


def phase_quality(rows):
    py, px = np.indices((128,128), dtype='d') + 16
    x, y = px - 79.5, py - 79.5
    axes = basis(x/128, y/128)
    qualities = []
    for row in rows:
        fixture = row['fixture']
        geometry = fixture['geometry']
        fx, fy = geometry['frequency'][1]
        target = 2*np.pi*(fx*x + fy*y) + geometry['phase'][1] + warp(x, y, geometry)
        sims = []
        for draw in row['draws']:
            role = draw['evidence'][0]
            if not role.get('selected') or role['weak'] != 1:
                continue
            freq = draw['actual_frequency'][1]
            nominal = 2*np.pi*(freq[0]*px + freq[1]*py)
            trial = {}
            for arm, info in role['phase'].items():
                if not info['eligible']:
                    continue
                beta = np.asarray(info.get('phase_correction_cycles_per_128', [0.]*5))
                params = np.asarray(info['phase_coefficients'])
                green = np.asarray({'RGGB': [1,2], 'BGGR':[1,2], 'GRBG':[0,3], 'GBRG':[0,3]}[fixture['camera']['pattern']])
                vector = params[green, 0] + 1j * params[green, 1]
                unit = vector / abs(vector)
                alignment = np.exp(1j*(nominal + axes@beta - target))[...,None] * unit.conj()
                trial[arm] = float(alignment.real.mean())
            sims.append(trial)
        qualities.append({'source': row['id'], 'draws': sims})
    paired = {}
    for method in METHODS[1:]:
        valid = [[(d[method],d['fixed']) for d in r['draws'] if 'fixed' in d and method in d] for r in qualities]
        values = [np.mean(x, axis=0) for x in valid if x]
        if values:
            paired[method] = {'sources': len(values), 'transport_and_fixed_cosines': np.mean(values, axis=0).tolist()}
    return {'details': qualities, 'paired': paired}


def main(names):
    cal = reference(OUT/'calibration.json')
    calibration = read_json(checked(cal))['policy']
    choices = {'combined': ('combined',1), 'weak': ('weak',1), 'uniform': ('weak',.75)}
    choices.update({k:(v['name'],v['weight']) for k,v in calibration['selected'].items()})
    result = {}
    old = OUT.with_name('local-phase-extent-v1')
    for name in names:
        binding = reference(OUT/f'{name}.json')
        receipt = read_json(checked(binding))
        rows = receipt['rows']
        panel = review_panel('fresh' if name == 'curved' else name, binding, rows, choices)
        panel['availability'] = availability(rows)
        panel['equal_response_to_fixed'] = response_match_fixed(rows, panel['means'], choices)
        if name == 'curved':
            assert len(rows) == 24
            panel['phase_templates_against_truth'] = phase_quality(rows)
        else:
            compare_ref = reference(old / f'{PARITY[name]}.json')
            panel['prior_parity'] = {'source': compare_ref, 'maximum_score_difference': verify(read_json(checked(compare_ref))['rows'], rows)}
        result[name] = panel
        print(name, panel['availability'], flush=True)
        for key, score in panel['means'].items():
            match = panel['equal_response_to_fixed'].get(key)
            exact = '' if match is None else match['paired_vs_deployed_fixed'][ADDED]['difference_interval']
            print(key, round(score[RESPONSE],6), round(score[ADDED],6), exact, flush=True)
        if name == 'curved':
            print(panel['phase_templates_against_truth']['paired'], flush=True)
    if 'curved' in names:
        write_json(OUT/'summary.json', {'driver': reference(Path(__file__)), 'calibration': cal, 'choices': choices, 'panels': result})


if __name__ == '__main__':
    main(sys.argv[1:])
