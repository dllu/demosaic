"""Diagnose which donor geometry survives independent RAW prediction on GFX."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from transport_phase import OUT, prepare
from review_presence import FIXED, arrays


def main():
    binding = reference(FIXED)
    records = []
    for row in read_json(checked(binding))['standing']:
        data = arrays(row['input'])
        scene, colors = data['packed'][0], data['colors'][0]
        roi = tuple(row['local_ROI'])
        profile = row['noise']
        frequency = _spacing(scene, colors, *roi[:2], clearance=16)
        result = []
        if frequency is not None:
            for weak in (0, 1):
                _, diagnostic = prepare(scene, colors, roi, frequency, weak, profile['shot'], profile['read'], 16)
                result.append(diagnostic)
                print(row['id'], weak, {k:(v['eligible'], v.get('opposed_validated_donors'), v.get('minimum_query_phase_cosine'))
                                        for k,v in diagnostic.items()}, flush=True)
        records.append({'id': row['id'], 'input': row['input'], 'noise': profile,
                        'frequency': None if frequency is None else frequency.tolist(), 'directions': result})
    write_json(OUT / 'standing-donor-diagnostic.json', {'driver': reference(Path(__file__)), 'source': binding, 'rows': records})


if __name__ == '__main__':
    main()
