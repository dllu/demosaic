"""Calibrate phase transport and score fixed held RAW controls."""

from functools import partial
from pathlib import Path
from types import SimpleNamespace
from time import monotonic
import sys

import torch
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import transport_phase as phase
from transport_phase import OUT
from conditional import replay
import replay_exterior_support as template
from scoring import remove_basis, space
from curved_scene import warp


class CurvedFundamental(replay.WireFundamental):
    """Keep the previous measurements and bind the primary waveform to the curved target."""

    def __init__(self, data, geo):
        super().__init__(data, geo)
        if 'bend_cycles' not in geo:
            return
        y, x = np.indices((128, 128), dtype='d') - 63.5
        fx, fy = geo['frequency'][1]
        angle = 2*np.pi*(fx*x + fy*y) + warp(x, y, geo)
        trig = np.stack((np.cos(angle), np.sin(angle)))
        self.signed_basis = space(remove_basis(trig[:, self.intact], self.intact_nuisance))
        self.clean_coeff = (self.truth[0] - self.truth[2])[self.intact] @ self.signed_basis
        self.clean_norm = self.clean_coeff @ self.clean_coeff
        assert self.clean_norm > 0
        self.gap_basis = (space(remove_basis(trig[:, self.gap], self.gap_nuisance)) if self.gap.any() else None)


def assess(*args, **kwargs):
    template.model = SimpleNamespace(ARMS=phase.ARMS, qualify=partial(phase.qualify, prepared={}))
    return template.assess(*args, **kwargs)


def main(name):
    torch.set_num_threads(2)
    start = monotonic()
    replay.comparisons = assess
    replay.WireFundamental = CurvedFundamental
    replay.OUT = OUT
    binding = {'driver': reference(Path(__file__)), 'operator': reference(phase.__file__)}
    if name == 'calibration':
        source, rows = replay.load_calibration()
        template.model = phase
        policy = template.select(rows)
        write_json(OUT / 'calibration.json', binding | {'source': source, 'rows': rows, 'policy': policy, 'seconds': monotonic()-start})
        return
    source_path = {'previous': 'local-conditional-posterior-v1/fresh', 'second': 'local-weak-support-v1/fresh',
                   'held': 'local-phase-extent-v1/fresh', 'curved': 'local-phase-transport-v2/fresh'}
    replay.PREVIOUS = OUT.parent / source_path[name]
    calibration = reference(OUT / 'calibration.json')
    assert read_json(checked(calibration))['operator'] == binding['operator']
    source, plan, rows = replay.load_confirmation()
    write_json(OUT / f'{name}.json', binding | {'source': source, 'plan': plan, 'rows': rows, 'calibration': calibration, 'seconds': monotonic()-start})


if __name__ == '__main__':
    main(sys.argv[1])
