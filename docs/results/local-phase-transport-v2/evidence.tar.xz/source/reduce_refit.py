"""Quantify the diagnostic that changes synthesis geometry as well as support."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from transport_phase import OUT
from reduce_support import ADDED, FALSE, RESPONSE, compare, means
from summarize_transport import verify


def main():
    binding = reference(OUT/'refit-curved.json')
    receipt = read_json(checked(binding))
    rows = receipt['rows']
    old = read_json(checked(receipt['previous']))['rows']
    previous_keys = ('combined','weak','fixed_2.5','curvature_2.5')
    for a,b in zip(old,rows,strict=True):
        assert a['id'] == b['id']
        for d1,d2 in zip(a['draws'],b['draws'],strict=True):
            assert d1['input'] == d2['input']
            for key in previous_keys:
                np.testing.assert_equal(d1['powers'][key],d2['powers'][key])
    cal = read_json(OUT/'calibration.json')['policy']
    choices = {'combined':('combined',1), 'weak':('weak',1)}
    choices.update({k:(cal['selected'][k]['name'],cal['selected'][k]['weight']) for k in ('fixed','curvature')})
    choices.update({k:(k,1) for k in ('same_support','refit_support','refit_guarded')})
    scores = {k:means(rows,v) for k,v in choices.items()}
    differences = {}
    for name, control in (('same_support','weak'),('refit_support','weak'),('refit_guarded','curvature')):
        a,b = choices[name], choices[control]
        anchor = scores['combined'][RESPONSE]
        target = min(scores[name][RESPONSE],scores[control][RESPONSE])
        weights = [w*(target-anchor)/(scores[k][RESPONSE]-anchor) for (arm,w),k in ((a,name),(b,control))]
        matched = compare(rows,(a[0],weights[0]),(b[0],weights[1]))
        differences[name] = {'control':control,'nominal':compare(rows,a,b),'equal_response':matched,
                             'equal_response_weights':weights,'equal_response_value':target}
    window_changes = {k:sum(x.get(k,0) for r in rows for d in r['draws'] for x in d['evidence'])
                      for k in ('refit_added_windows','refit_lost_windows')}
    write_json(OUT/'refit-summary.json', {'driver':reference(Path(__file__)), 'source':binding,
                                        'scope':'exploratory reuse of the same 24 curved scenes after phase-support replay',
                                        'choices':choices, 'means':scores, 'differences':differences,
                                        'admission_changes_all_roles':window_changes})
    for k,v in scores.items():
        print(k,{m:v[m] for m in (RESPONSE,ADDED,FALSE)})
    for k,v in differences.items():
        print(k,v['nominal'][RESPONSE]['difference_interval'],v['nominal'][ADDED]['difference_interval'],v['equal_response'][ADDED]['difference_interval'])
    print(window_changes)


if __name__ == '__main__':
    main()
