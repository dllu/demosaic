"""Review the curved-basis refit beside its taper-only control."""

from pathlib import Path
import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from transport_phase import OUT
import refit_curvature as refit
import review_extent as review

LABELS = {'parent':'Local 50k', 'nested':'Combined check', 'weak':'Weak posterior',
          'fixed':'Fixed phase guard', 'curved':'Curved taper', 'local':'Curved refit and taper'}


def arms(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    variant, detail = refit.qualify(parent, local, scene, colors, roi, peaks, noise, wb, matrix, prepared={}) if local != roi else refit_real(parent, local, scene, colors, roi, peaks, noise, wb, matrix)
    combined = variant['combined']
    results = {'parent':review.view.section(parent, *local), 'nested':combined, 'weak':variant['weak']}
    for name, key in (('fixed','fixed'),('curved','curvature')):
        item = policy['selected'][key]
        result = variant[item['name']].astype('d')-combined
        results[name] = (combined + item['weight']*result).astype(combined.dtype)
    return results | {'local':variant['refit_guarded']}, detail


def refit_real(parent, local, scene, colors, roi, peaks, noise, wb, matrix):
    guard, trace = refit.phase.qualify(parent, local, scene, colors, roi, peaks, noise, wb, matrix, clearance=16, prepared={})
    combined, weak = guard['combined'], guard['weak']
    if not trace.get('phase',{}).get('curvature',{}).get('eligible'):
        return {'combined':combined, 'weak':weak, 'fixed_2.5':guard['fixed_2.5'],
                'curvature_2.5':guard['curvature_2.5'], 'refit_guarded':weak}, trace
    d = trace['weak']
    geometry = trace['phase']['curvature']
    beta = np.asarray(geometry['phase_correction_cycles_per_128'])
    locked = np.asarray(geometry['phase_coefficients'])
    green = locked[:,0]+1j*locked[:,1]
    # Apply the fitted subset's channel eligibility from the same trainer state.
    observations, _ = refit.phase.prepare(scene, colors, roi, peaks, d, noise['shot'], noise['read'], 16)
    curve = observations['curvature']
    patch, use = refit.weak_patch(parent, local, scene, colors, roi, peaks, d, beta, noise['shot'], noise['read'])
    neutral = np.linalg.solve(matrix,np.ones(3))/wb
    neutral /= neutral[1]
    correction = refit._rgb(np.where(use[:,None,None],patch,0),neutral,combined.dtype)
    field = refit.phase.fields_from_geometry(scene, roi, peaks, d, noise['shot'], noise['read'], curve)
    result = (combined + correction.astype('d') * np.clip(1+(field-2.5)/2,0,1)).astype(combined.dtype)
    return {'combined':combined, 'weak':weak, 'fixed_2.5':guard['fixed_2.5'],
            'curvature_2.5':guard['curvature_2.5'], 'refit_guarded':result}, trace


def main():
    torch.set_num_threads(2)
    calibration = reference(OUT/'calibration.json')
    policy = read_json(checked(calibration))['policy']
    output = OUT/'boards/refit'
    output.mkdir(parents=True,exist_ok=True)
    review.OUT = OUT
    review.arms = arms
    review.DISPLAY = LABELS
    exact = review.exact(policy,output,('curved-phase-01','curved-phase-09'),'refit-curved')
    standing = reference(review.view.FIXED)
    real = []
    for row in read_json(checked(standing))['standing']:
        data = review.view.arrays(row['input'])
        raw, colors, wb, matrix = (data[k][0] for k in ('packed','colors','wb','matrix'))
        roi = tuple(row['local_ROI'])
        parent = np.load(checked(row['predictions']['local50k']),allow_pickle=False)[0]
        peaks = _spacing(raw,colors,*roi[:2],clearance=16)
        values, trace = arms(parent,roi,raw,colors,roi,peaks,row['noise'],wb,matrix,policy)
        real.append({'id':row['id'],'input':row['input'], 'curvature_eligible':trace.get('phase',{}).get('curvature',{}).get('eligible',False),
                     'refit_minus_taper_RMS_DN16':float(np.sqrt(np.mean((values['local'].astype('d')-values['curved'])**2))*65535)})
    write_json(OUT/'board-refit.json', {'driver':reference(Path(__file__)), 'calibration':calibration,
                                       'data':exact, 'standing_source':standing, 'standing_diagnostics':real})


if __name__ == '__main__':
    main()
