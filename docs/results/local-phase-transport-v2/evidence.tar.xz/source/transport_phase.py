"""Predict the weak phase at the query from disjoint Bayer donor subwindows."""

from pathlib import Path
from itertools import product
import sys

import numpy as np
from scipy.optimize import minimize
from scipy.ndimage import map_coordinates

from demosaic._mesh_weak_phase import _carrier, _background, _cells, _PIXEL_COORDS
from demosaic.mesh_carrier_fit import _DONOR, _ROI_SIZE, _donor_boxes, _sites

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic') / HERE.name
sys.path.insert(0, str(HERE.with_name('local-phase-extent-v1')))
import phase_extent as prior

CELL = 32
SIDES = np.asarray(tuple(np.ndindex(2, 2)))
NODES = np.asarray(tuple(np.ndindex(4, 4)))
DONOR_ID = np.repeat(np.arange(4), len(NODES))
VALIDATION_FOLD = np.tile(NODES.sum(axis=1) % 2, 4)
BRACKETS = ((0, 1), (2, 3))
METHODS = ('fixed', 'subbin', 'curvature', 'bracket', 'adjacent')
CUTOFFS = (1.0, 2.5, 3.5)
OPTIONS = tuple((name, 'score', cutoff, f'{name}_{cutoff:g}') for name, cutoff in product(METHODS, CUTOFFS))
ARMS = ('combined', 'weak', *(key for _, _, _, key in OPTIONS))
FIT_BOUNDS = ((-.40, .40), (-.40, .40), (-.26, .26), (-.26, .26), (-.26, .26))


def basis(x, y):
    return 2 * np.pi * np.stack((x, y, x*x/2, x*y, y*y/2), axis=-1)


def donor_observations(scene, colors, roi, freq, weak, shot, read, clearance):
    """Measure per-CFA residual weak coefficients in 64 nonoverlapping stations."""
    x, y = roi[:2]
    origin = (_ROI_SIZE - 1) / 2
    design_rows, signals, precisions = [], [], []
    sub = CELL // 2
    for left, top in _donor_boxes(x, y, clearance):
        centers = NODES * CELL + (CELL - 1) / 2
        yy = (centers[:, 0] + top - y - origin) / _DONOR
        xx = (centers[:, 1] + left - x - origin) / _DONOR
        design_rows.extend(basis(xx, yy))
        wave = _carrier(_DONOR, left - x, top - y, freq).reshape(_DONOR, _DONOR, 4)
        planar = _background(CELL).reshape(CELL, CELL, 6)
        obs, weights = [], []
        for rr, cc in SIDES:
            r, c = (rr + y - top) % 2, (cc + x - left) % 2
            values = _sites(scene, left, top, _DONOR, r, c)
            values = values.reshape(4, sub, 4, sub).swapaxes(1, 2).reshape(16, sub*sub)
            channels = wave[r::2, c::2].reshape(4, sub, 4, sub, 4).swapaxes(1, 2).reshape(16, sub*sub, 4)
            smooth = planar[r::2, c::2].reshape(1, sub*sub, 6)
            design = np.concatenate((np.broadcast_to(smooth, (16, sub*sub, 6)), channels), axis=-1)
            inverse = np.linalg.pinv(design, rcond=1e-8)[:, 6+2*weak:8+2*weak]
            coeff = (inverse @ values[..., None])[..., 0]
            var = np.maximum(2e-11, shot * np.maximum(0, values.mean(axis=1)) + read)
            info = 1 / (var * np.square(inverse).sum(axis=2).mean(axis=1))
            obs.append(coeff[:, 0] + 1j*coeff[:, 1])
            weights.append(info)
        signals.append(np.stack(obs, axis=-1))
        precisions.append(np.stack(weights, axis=-1))
    greens = np.array([colors[2*((y+r)%2)+(x+c)%2] == 1 for r, c in SIDES])
    return np.asarray(design_rows), np.concatenate(signals), np.concatenate(precisions), greens


def estimator(rows, value, inv, greens, subset, dim, *, single=False):
    """Concentrate out per-CFA phase and fit a small smooth spatial correction."""
    matrix = rows[subset, :dim]
    weighted = value[subset][:, greens] * inv[subset][:, greens]
    normal = inv[subset][:, greens].sum(axis=0)
    scale = max(1., float(np.sum(abs(weighted.sum(axis=0))**2 / normal)))
    penalty = np.r_[np.full(2, .12 if single else .002), np.full(3, .014)][:dim]

    def loss(beta):
        rotation = np.exp(1j * (matrix @ beta))
        transformed = rotation[:, None] * weighted
        total = transformed.sum(axis=0)
        slope = matrix.T @ (-transformed.imag + 1j*transformed.real)
        loss = -np.sum(abs(total)**2 / normal) / scale + np.sum(penalty * beta**2)
        jac = -2 * np.real(slope @ (np.conj(total) / normal)) / scale + 2 * penalty * beta
        return float(loss), jac

    # Four donors can admit multiple integer-cycle shifts. Use fixed starts on the same samples.
    shifts = (0., -.23, .23)
    seeds = [np.r_[a, b, np.zeros(dim-2)] for a,b in product(shifts, shifts)]
    bounds = ((-.21, .21), (-.21, .21)) if single else FIT_BOUNDS[:dim]
    results = [minimize(loss, seed, jac=True, method='L-BFGS-B', bounds=bounds,
                        options={'maxiter': 42, 'ftol': 1e-11}) for seed in seeds]
    best = min(results, key=lambda fit: fit.fun)
    beta = np.pad(best.x, (0, 5-dim))
    corrected = np.exp(1j*(rows[subset] @ beta))[:, None] * value[subset]
    phases = (inv[subset] * corrected).sum(axis=0) / inv[subset].sum(axis=0)
    return beta, phases


def evidence(rows, values, inv, beta, phase, hold):
    rotation = np.exp(1j * (rows[hold] @ beta))
    z = rotation[:, None] * values[hold]
    unit = phase / np.maximum(1e-12, abs(phase))
    weighted = inv[hold]
    alignment = np.real(z * unit.conj())
    donors = DONOR_ID[hold]
    numerator = np.asarray([(weighted * alignment)[donors == d].sum(axis=0) for d in range(4)])
    powers = np.asarray([weighted[donors == d].sum(axis=0) for d in range(4)])
    amplitude = np.asarray([(weighted * abs(z))[donors == d].sum(axis=0) for d in range(4)])
    return numerator / np.sqrt(np.maximum(1e-12, powers)), numerator / np.maximum(1e-12, amplitude)


def fit_model(rows, values, inv, greens, method, allowed=(0, 1, 2, 3)):
    dim = 5 if method == 'curvature' else 2
    single = len(allowed) == 1
    region = np.isin(DONOR_ID, allowed)
    predictions = []
    for fold in (0, 1):
        train = region & (VALIDATION_FOLD == fold)
        test = region & (VALIDATION_FOLD != fold)
        beta, phase = estimator(rows, values, inv, greens, train, dim, single=single)
        z, cosine = evidence(rows, values, inv, beta, phase, test)
        predictions.append((beta, phase, z, cosine))
    stats = np.stack([p[2] for p in predictions])
    cosines = np.stack([p[3] for p in predictions])
    # Both green lattices must predict held stations on two sides of the query.
    donor_valid = ((stats[..., greens] >= 2.0) & (cosines[..., greens] >= .32)).all(axis=(0, 2))
    strong_brackets = [b for b in BRACKETS if all(donor_valid[d] for d in b)]
    # Avoid delivering either reciprocal fit if their predicted phases disagree in the query.
    probes = np.array((0., -.43, .43, 0., 0.))
    probe_design = basis(probes, probes[[0, 3, 4, 1, 2]])
    templates = [p[1][None] * np.exp(-1j * (probe_design @ p[0]))[:, None] for p in predictions]
    left, right = templates
    similarity = np.real(left * right.conj()) / np.maximum(1e-12, abs(left * right))
    reciprocal = float(similarity[:, greens].min())
    sufficient_donors = bool(donor_valid[allowed[0]]) if single else bool(strong_brackets)
    trace = {'validation_snr': stats.tolist(), 'validation_alignment': cosines.tolist(),
             'minimum_query_phase_cosine': reciprocal, 'opposed_validated_donors': strong_brackets,
             'allowed': list(allowed), 'eligible': bool(sufficient_donors and reciprocal >= .60)}
    score = float(np.maximum(0, stats[..., greens]).sum())
    trace['score'] = score
    if not trace['eligible']:
        return None, trace
    beta, phase = estimator(rows, values, inv, greens, region, dim, single=single)
    trace['phase_correction_cycles_per_128'] = beta.tolist()
    trace['phase_coefficients'] = np.stack((phase.real, phase.imag), axis=-1).tolist()
    color_good = ((stats >= 1.5) & (cosines >= .25)).all(axis=0).sum(axis=0) >= (1 if single else 2)
    return (beta, np.where(color_good | greens, phase, 0.)), trace


def fields_from_geometry(scene, roi, freq, weak, shot, read, coefficients):
    """Measure the fixed varying wave with the same local nuisance as the prior guard."""
    beta, phase = coefficients
    im = _carrier(_ROI_SIZE, 0, 0, freq)
    y, x = (np.indices((_ROI_SIZE, _ROI_SIZE)) - (_ROI_SIZE - 1) / 2) / _DONOR
    warp = basis(x, y) @ beta
    wave = (im[..., weak, 0] + 1j*im[..., weak, 1]) * np.exp(1j*warp)
    origin = roi[:2]
    stations = _ROI_SIZE // 16
    moment = np.zeros(stations**2)
    precision = np.zeros_like(moment)
    for (r, c), coeff in zip(SIDES, phase, strict=True):
        if not coeff:
            continue
        values = _cells(_sites(scene, *origin, _ROI_SIZE, r, c)).astype('d')
        vn = np.maximum(2e-11, shot * np.maximum(0, values.mean(axis=1)) + read)
        smooth = np.broadcast_to(_background(16)[r::2, c::2].reshape(1, 64, 6), (*values.shape, 6))
        nuisance = np.concatenate((smooth, _cells(im[r::2, c::2, 1-weak])), axis=-1)
        p = _cells(np.real(wave[r::2, c::2] * np.conj(coeff)))
        remove = (np.linalg.pinv(nuisance, rcond=1e-8) @ p[..., None])[..., 0]
        p -= np.einsum('npi,ni->np', nuisance, remove)
        moment += np.einsum('np,np->n', p, values) / vn
        precision += np.einsum('np,np->n', p, p) / vn
    region = (moment / np.sqrt(np.maximum(1e-10, precision))).reshape(stations, stations)
    return map_coordinates(region, _PIXEL_COORDS, order=1, mode='nearest', prefilter=False)


def qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, clearance=48, prepared=None):
    original, info = prior.previous.qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix,
                                             clearance=clearance)
    combined, weak = original['combined'], original['weak']
    result = dict.fromkeys(ARMS, weak) | {'combined': combined}
    if not info.get('selected'):
        return result, {'weak': info['weak'], 'selected': []}
    direction = info['weak']
    shot, read = noise['shot'], noise['read']
    if prepared is None or direction not in prepared:
        values = prepare(scene, colors, roi, frequency, direction, shot, read, clearance)
        if prepared is not None:
            prepared[direction] = values
    else:
        values = prepared[direction]
    arm_sources, audit = values
    change = weak.astype('d') - combined
    delta = {k: fields_from_geometry(scene, roi, frequency, direction, shot, read, locked)
             for k, locked in arm_sources.items() if locked is not None}
    for method, _, cut, name in OPTIONS:
        if method in delta:
            weight = np.clip(1 + (delta[method] - cut) / 2, 0, 1)
            result[name] = (combined + weight * change).astype(weak.dtype)
    return result, {'weak': direction, 'selected': info['selected'], 'phase': audit,
                    'scores': {key: np.quantile(field, (0, .25, .50, .75, 1)).tolist() for key,field in delta.items()}}


def prepare(scene, colors, roi, frequency, direction, shot, read, clearance):
    fixed, coherence, strength = prior.donor_phase(scene, colors, roi, frequency, direction, shot, read, clearance)
    observations = donor_observations(scene, colors, roi, frequency, direction, shot, read, clearance)
    locked = {'fixed': None if fixed is None else (np.zeros(5), fixed[:, 0] + 1j * fixed[:, 1])}
    audit = {'fixed': {'eligible': fixed is not None, 'coherence': coherence.tolist(), 'strength': strength.tolist(),
                       'phase_coefficients': None if fixed is None else fixed.tolist()}}
    for method in ('subbin', 'curvature'):
        locked[method], audit[method] = fit_model(*observations, method)
    brackets = [fit_model(*observations, 'subbin', allowed=b) for b in BRACKETS]
    locked['bracket'], audit['bracket'] = max(brackets, key=lambda pair: (pair[0] is not None, pair[1]['score']))
    audit['bracket']['comparisons'] = [{k:v for k,v in item.items() if k != 'comparisons'} for _,item in brackets]
    adjacent = [fit_model(*observations, 'subbin', allowed=(d,)) for d in range(4)]
    locked['adjacent'], audit['adjacent'] = max(adjacent, key=lambda pair: (pair[0] is not None, pair[1]['score']))
    audit['adjacent']['comparisons'] = [{k:v for k,v in item.items() if k != 'comparisons'} for _,item in adjacent]
    return locked, audit
