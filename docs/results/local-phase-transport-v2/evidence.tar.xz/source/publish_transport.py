"""Publish source-bound curved phase results, native evidence and discovery replays."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from transport_phase import HERE, OUT

ROOT = Path.cwd()
ASSETS = ROOT/'docs/assets'/HERE.name
RESULTS = ROOT/'docs/results'/HERE.name
RECEIPTS = ('calibration.json', 'previous.json', 'second.json', 'held.json', 'curved.json',
            'fresh/plan.json', 'fresh/inputs.json', 'fresh/parent/result.json',
            'summary.json', 'transport-audit.json', 'standing-donor-diagnostic.json',
            'refit-curved.json', 'refit-summary.json', 'plot.json',
            'board-camera.json', 'board-exact.json', 'board-refit.json')


def reference_local(path):
    return reference(path) | {'path': str(path.relative_to(ROOT))}


def copy_image(binding, prefix=''):
    source = checked(binding)
    target = ASSETS/(prefix + source.name)
    shutil.copyfile(source, target)
    new = reference_local(target)
    assert new['sha256'] == binding['sha256']
    return new


def board(record, prefix=''):
    image = copy_image(record['image'], prefix)
    with Image.open(ROOT/image['path']) as png:
        for panel in record['panels']:
            x,y,w,h = panel['png_xywh']
            assert (w,h) == (160,160)
            assert 0 <= x < x+w <= png.width and 0 <= y < y+h <= png.height
    return record | {'image': image}


def main():
    ASSETS.mkdir(exist_ok=True,parents=True)
    RESULTS.mkdir(exist_ok=True,parents=True)
    refs = {k:reference(OUT/k) for k in RECEIPTS}
    r = {k:read_json(checked(v)) for k,v in refs.items()}
    for value in r.values():
        for key in ('driver','operator'):
            if key in value:
                checked(value[key])
    for n in ('previous','second','held','curved','board-camera','board-exact','board-refit'):
        assert r[f'{n}.json']['calibration'] == refs['calibration.json']
    assert r['board-exact.json']['data']['receipt'] == refs['curved.json']
    assert r['board-refit.json']['data']['receipt'] == refs['refit-curved.json']
    assert r['refit-summary.json']['source'] == refs['refit-curved.json']
    assert r['refit-curved.json']['previous'] == refs['curved.json']
    assert r['plot.json']['summary'] == refs['summary.json']
    assert r['curved.json']['source'] == refs['fresh/parent/result.json']
    assert r['curved.json']['plan'] == refs['fresh/plan.json']
    assert r['fresh/parent/result.json']['inputs'] == refs['fresh/inputs.json']
    assert r['fresh/inputs.json']['plan'] == refs['fresh/plan.json']
    for result in r['fresh/parent/result.json']['records']:
        for draw in result['streams']:
            checked(draw['data'])
            for prediction in draw['outputs'].values():
                checked(prediction)

    evidence = {f'receipts/{name}':binding for name,binding in refs.items()}
    evidence.update({f'source/{file.name}':reference(file) for file in sorted(HERE.glob('*.py'))})
    for k in ('src/demosaic/_mesh_weak_phase.py','src/demosaic/_mesh_weak_posterior.py', 'src/demosaic/_mesh_pooled.py'):
        evidence[k] = reference(ROOT/k)
    archive = RESULTS/'evidence.tar.xz'
    with tarfile.open(archive,'x:xz') as package:
        for name,binding in evidence.items():
            package.add(checked(binding),arcname=name,recursive=False)
    with tarfile.open(archive) as package:
        assert set(package.getnames()) == evidence.keys()
        for name,binding in evidence.items():
            with package.extractfile(name) as member:
                assert hashlib.file_digest(member,'sha256').hexdigest() == binding['sha256']

    camera = [x | {'native':[board(b) for b in x['native']]} for x in r['board-camera.json']['data']['rows']]
    exact, refit = ([x | {'board':board(x['board'],prefix),'triplet':board(x['triplet'],prefix)}
                     for x in r[f'board-{which}.json']['data']['boards']]
                    for which,prefix in (('exact',''),('refit','refit-')))
    manifest = ASSETS/'manifest.json'
    write_json(manifest, {'camera':camera,'exact':exact,'refit':refit,
                          'plot':copy_image(r['plot.json']['image']),
                          'standing_refit_diagnostics':r['board-refit.json']['standing_diagnostics']})
    tracked_summaries = {}
    for name in ('summary.json','refit-summary.json'):
        target = RESULTS/name
        shutil.copyfile(checked(refs[name]),target)
        tracked_summaries[name] = reference_local(target)
        assert tracked_summaries[name]['sha256'] == refs[name]['sha256']
    prior = ROOT/'docs/results/local-phase-extent-v1/publication.json'
    write_json(RESULTS/'publication.json', {
        'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'archive':reference_local(archive),'summary':tracked_summaries['summary.json'],
        'refit_summary':tracked_summaries['refit-summary.json'], 'native_manifest':reference_local(manifest),
        'prior_publication':reference_local(prior),'receipt_bindings':refs,'archive_members':evidence,
        'native_triplets_viewed':len(exact)+len(refit),
        'standing_boards_viewed':sum(len(x['native']) for x in camera),'new_weights':None,
    })


if __name__ == '__main__':
    main()
