"""Render the frozen transport choices at native pixel scale."""

from pathlib import Path
from time import monotonic
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import transport_phase as phase
from transport_phase import OUT
import review_extent as review

LABELS = {
    'parent': 'Local 50k', 'nested': 'Combined check', 'weak': 'Weak posterior',
    'uniform': 'Uniform 75%', 'fixed': 'Fixed phase guard', 'subbin': 'Refined planar phase',
    'local': 'Curved phase', 'bracket': 'Opposed phase', 'ring_phase': 'One adjacent donor',
}


def arms(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    values, trace = phase.qualify(parent, local, scene, colors, roi, peaks, noise, wb, matrix,
                                  clearance=16 if local == roi else 48)
    combined = values['combined']
    crops = {'parent': review.view.section(parent, *local), 'nested': combined, 'weak': values['weak']}
    keys = {'uniform': 'uniform', 'fixed': 'fixed', 'subbin': 'subbin', 'curvature': 'local',
            'bracket': 'bracket', 'adjacent': 'ring_phase'}
    options = {'uniform': policy['control']} | policy['selected']
    for label, public in keys.items():
        opt = options[label]
        change = values[opt['name']].astype('d') - combined
        crops[public] = (combined + opt['weight'] * change).astype(combined.dtype)
    return crops, trace


def main(kind):
    torch.set_num_threads(2)
    now = monotonic()
    binding = reference(OUT/'calibration.json')
    policy = read_json(checked(binding))['policy']
    output = OUT/'boards'/kind
    output.mkdir(parents=True, exist_ok=True)
    review.OUT = OUT
    review.arms = arms
    review.DISPLAY = LABELS
    if kind == 'camera':
        review.view.arcs = arms
        review.view.NAMES = LABELS
        data = review.view.standing(policy, output)
    else:
        data = review.exact(policy, output, ('curved-phase-01', 'curved-phase-09'), 'curved')
    write_json(OUT/f'board-{kind}.json', {'driver': reference(Path(__file__)), 'calibration': binding,
                                       'data': data, 'seconds': monotonic()-now})


if __name__ == '__main__':
    main(sys.argv[1])
