"""An optically filtered curved weak carrier with exact absence controls."""

import numpy as np
import torch
from torch.nn import functional as F


def warp(x, y, geometry):
    fx, fy = geometry['frequency'][1]
    tangent = (-fy*x + fx*y) / (128 * (fx**2 + fy**2)**.5)
    return np.pi * geometry['bend_cycles'] * tangent**2


def coefficients(geometry):
    fx, fy = geometry['frequency'][1]
    tx, ty = np.array((-fy, fx)) / np.hypot(fx, fy)
    common = geometry['bend_cycles']
    return [0., 0., tx*tx*common, tx*ty*common, ty*ty*common]


def exact(photo, geometry):
    axis = torch.arange(512) - 255.5
    y, x = torch.meshgrid(axis, axis, indexing='ij')
    field = torch.maximum(x.abs(), y.abs())
    exterior = ((field - 132) / 27).clamp(0, 1)
    fringe = ((field - 108) / 18).clamp(0, 1)
    flat = ((128 - field) / 57).clamp(0, 1)
    smooth = .085 + .52 * F.avg_pool2d(photo[None], 11, stride=1, padding=5, count_include_pad=False)[0]
    angle = geometry['angle']
    z = x * np.cos(angle) + y * np.sin(angle) - geometry['edge']
    step = torch.sigmoid(z / 1.3)
    base = smooth + torch.tensor(geometry['tint'])[:, None, None] * step
    phases = [2*np.pi*(fx*x + fy*y) + phi for (fx, fy), phi in zip(geometry['frequency'], geometry['phase'], strict=True)]
    phases[1] += warp(x, y, geometry)
    p, q = phases

    def wire(theta, width):
        return sum(np.exp(-2*np.pi**2 * width**2 * (m*m - 1)) * (m*theta).cos() for m in range(1, 9))

    lead, weak = geometry['strength']
    front = base + lead * wire(p, geometry['width'][0])
    dx, dy = x - geometry['gap_center'][0], y - geometry['gap_center'][1]
    angle = geometry['gap_orientation']
    u = (dx*np.cos(angle) + dy*np.sin(angle)) / geometry['gap_width']
    v = (-dx*np.sin(angle) + dy*np.cos(angle)) / geometry['gap_length']
    radius = torch.hypot(u, v)
    family = geometry['family']
    if family == 'ellipse':
        footprint = ((radius - 1) * 3.2).clamp(0, 1)
    elif family == 'strip':
        footprint = ((u.abs() - 1) * 3.2).clamp(0, 1)
    elif family == 'smooth-dip':
        footprint = 1 - .57 * torch.exp(-.5 * radius**2)
    else:
        footprint = torch.ones_like(x)
    gain = .53 + .47 * step if family == 'contrast-step' else .78 + .22 * step
    support = torch.maximum(footprint, fringe)
    detail = weak * wire(q, geometry['width'][1]) * gain * (1 - .28*(.5 + .5*p.cos()))
    detail += .19 * weak * p.cos() * q.cos()
    signal = front + detail * support
    no_center = front + detail * fringe
    clean_flat = signal[:, 198:314, 198:314].mean((-2, -1), keepdim=True)
    quiet = torch.where(flat == 1, clean_flat, torch.lerp(signal, clean_flat, flat))
    shell = base + .025*p.cos() + .025*q.cos()
    targets = tuple(torch.lerp(img, shell, exterior) for img in (signal, no_center, front, quiet))
    assert all(0 < float(img.min()) and float(img.max()) < 1 for img in targets)
    return targets, None, support, detail
