"""Verify the transport sign, query isolation and reciprocal donor split."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from transport_phase import OUT, VALIDATION_FOLD, basis, donor_observations, estimator, evidence, prepare

ROI = (176, 176, 160, 160)
NOISE = dict(shot=.00128, read=6.5536e-6)


def unit_quality(coefficients, frequency, angle, greens):
    x, y = ROI[:2]
    py, px = np.indices((160, 160), dtype='d')
    normalized = ((px-79.5)/128, (py-79.5)/128)
    field = basis(*normalized)
    if coefficients is None:
        return None
    beta, phase = coefficients
    cycle = 2*np.pi*(frequency[1,0]*px + frequency[1,1]*py) + field@beta
    unit = phase[greens]/abs(phase[greens])
    return float(np.real(np.exp(1j*(cycle-angle))[..., None] * unit.conj()).mean())


def exact_control():
    x, y = ROI[:2]
    py, px = np.indices((512, 512), dtype='d')
    field = basis((px-x-79.5)/128, (py-y-79.5)/128)
    freq = np.asarray(((.1171875, .072265625), (.091796875, -.072265625)))
    start = 2*np.pi*(freq[1,0]*(px-x) + freq[1,1]*(py-y))
    strong = .015*np.cos(2*np.pi*(freq[0,0]*(px-x) + freq[0,1]*(py-y)))
    controls = {}
    for name, beta in (('subbin', [.24,-.14,0.,0.,0.]), ('curvature', [.08,-.11,.04,-.099,.19])):
        angle = start + field @ np.asarray(beta) + .849
        observed = (.10 + strong + .008*np.cos(angle)).astype('f')
        packed = np.stack([observed[r::2,c::2] for r,c in np.ndindex(2,2)])
        colors = np.array((0,1,1,2))
        values, trace = prepare(packed, colors, ROI, freq, 1, **NOISE, clearance=48)
        exact_angle = angle[y:y+160, x:x+160]
        result = {key: unit_quality(value, freq, exact_angle, np.array((False,True,True,False)))
                  for key,value in values.items()}
        assert result[name] is not None and result[name] > .99, result
        reference_name = 'fixed' if name == 'subbin' else 'subbin'
        assert result[reference_name] is None or result[name] > result[reference_name], result
        controls[name] = {'true_coefficients': beta, 'recovered_template_cosine': result, 'geometry': trace}
    return controls


def main():
    index = reference(OUT/'fresh/inputs.json')
    catalog = read_json(checked(index))
    plan = read_json(checked(catalog['plan']))
    results = {}
    gen = np.random.default_rng(804505)
    for item, fixture in zip(catalog['observations'][:4], plan['sources'], strict=False):
        binding = item['streams'][0]['data']
        with np.load(checked(binding)) as data:
            scene, colors = data['scene_packed'], data['colors']
        f = _spacing(scene, colors, *ROI[:2], clearance=48)
        assert f is not None
        modified = scene.copy()
        modified[:,64:192,64:192] += gen.uniform(-.01,.03, (4,128,128))
        np.testing.assert_array_equal(f, _spacing(modified, colors, *ROI[:2], clearance=48))
        a = donor_observations(scene, colors, ROI, f, 1, **NOISE, clearance=48)
        b = donor_observations(modified, colors, ROI, f, 1, **NOISE, clearance=48)
        for original, after in zip(a,b,strict=True):
            np.testing.assert_array_equal(original, after)
        rows, value, inv, greens = a
        train = VALIDATION_FOLD == 0
        beta, phases = estimator(rows, value, inv, greens, train, 5)
        perturbed = value.copy()
        perturbed[~train] *= -1
        other, p = estimator(rows, perturbed, inv, greens, train, 5)
        np.testing.assert_array_equal(beta, other)
        np.testing.assert_array_equal(phases, p)
        scores, coherence = evidence(rows, value, inv, beta, phases, ~train)
        scores2, coherence2 = evidence(rows, perturbed, inv, beta, phases, ~train)
        np.testing.assert_allclose(scores2, -scores)
        np.testing.assert_allclose(coherence2, -coherence)
        results[fixture['camera']['pattern']] = {'input': binding, 'query_samples_replaced': 65536,
            'donor_sites_in_each_phase': len(value), 'max_held_score_difference': float(abs(scores-scores2).max())}
    assert len(results) == 4
    write_json(OUT/'transport-audit.json', {'driver': reference(Path(__file__)), 'input_index': index,
                                           'isolation_by_layout': results, 'pure_signal_controls': exact_control()})


if __name__ == '__main__':
    main()
