"""Contrast true-phase agreement on curved fixtures and held support on the real cab."""

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _positions
from transport_phase import OUT
from review_presence import arrays, FIXED


def main():
    summary = reference(OUT/'summary.json')
    diagnosis = reference(OUT/'standing-donor-diagnostic.json')
    records = read_json(checked(summary))['panels']['curved']['phase_templates_against_truth']['details']
    ifr = read_json(checked(diagnosis))
    pairs = []
    for r in records:
        common = [[d['fixed'],d['curvature']] for d in r['draws'] if {'fixed','curvature'} <= d.keys()]
        if common:
            pairs.append(np.mean(common,axis=0))
    standalone = read_json(FIXED)['standing']
    fig,axes = plt.subplots(1,2,figsize=(8.9,3.6),layout='constrained')
    left,right = axes
    left.plot([0,1],np.asarray(pairs).T,color='#90a6b8',linewidth=.9,alpha=.65)
    left.scatter((0,1),np.mean(pairs,axis=0),color='#22685d',s=30,zorder=3,label='Source mean')
    left.set_title(f'Curved fixtures, {len(pairs)} common sources',fontweight='bold',loc='left',fontsize=10)
    left.set_ylabel('Cosine agreement with known phase')
    left.set_xticks((0,1),('Fixed phase','Curved phase'))
    left.set_xlim(-.22,1.21)
    left.set_ylim(bottom=min(.38,min(min(v) for v in pairs)-.04),top=1.022)
    offset=[-.09,.09]
    ids=np.arange(4)
    target=zip([r for r in ifr['rows'] if r['id'].endswith('mesh-right')],
               [r for r in standalone if r['id'].endswith('mesh-right')], strict=True)
    for i,(row,view) in enumerate(target):
        assert row['id']==view['id']
        colors=arrays(view['input'])['colors'][0]
        greens=[2*r+c for r,c in _positions(colors,*view['local_ROI'][:2])]
        z=np.asarray(row['directions'][1]['subbin']['validation_snr'])[...,greens].min(axis=(0,2))
        right.scatter(ids+offset[i],z,label=('Nominal','Transferred')[i],color=('#1c6b63','#b65c35')[i],s=36,zorder=3)
    right.axhline(2,color='#7e8287',linewidth=1,linestyle=':')
    right.set_title('Right cab, weak direction',fontweight='bold',loc='left',fontsize=10)
    right.set_ylabel('Lowest held green score per donor')
    right.set_xticks(ids,('Left','Right','Top','Bottom'))
    right.legend(frameon=False,loc='lower left',fontsize=8)
    for ax in axes:
        ax.grid(axis='y',alpha=.2)
        ax.spines[['top','right']].set_visible(False)
    img=OUT/'phase-prediction-and-donors.png'
    fig.savefig(img,dpi=160,facecolor='white')
    write_json(OUT/'plot.json', {'driver':reference(Path(__file__)), 'summary':summary,
                                'standing_diagnosis':diagnosis,'image':reference(img)})


if __name__ == '__main__':
    main()
