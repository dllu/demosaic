"""Plot the response and false-detail tradeoff of the locked fresh-crop fit."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay_presence import ABSOLUTE, FALSE, OUT, metrics_at


def values(rows, arm, weight, m):
    return np.mean([
        np.mean([metrics_at(a["powers"][arm], weight)[m] for a in r["draws"]])
        for r in rows if all(m in a["powers"][arm] for a in r["draws"])
    ])


def main():
    binding = reference(OUT / "fresh-guarded.json")
    data = read_json(checked(binding))
    lock = read_json(checked(data["calibration"]))["weights"]
    mode = lock["best"]["ring_phase"]
    modes = (("nested", "Combined check"), ("broad", "Broad check"), (mode, "Ring phase prior"))
    colors = ("#2563a6", "#757575", "#187451")
    fig, panes = plt.subplots(1, 2, figsize=(8.6, 3.3), layout="constrained", sharey=True)
    doses = np.linspace(0, 1, 21)
    recorded = {}
    axes = (
        (FALSE, "False weak projection in true gaps (DN16)"),
        ("flat_added_DN16", "Change on exact flat cores (DN16)"),
    )
    for (arm, name), color in zip(modes, colors, strict=True):
        response = [float(values(data["cases"], arm, w, ABSOLUTE)) for w in doses]
        curve = {ABSOLUTE: response}
        for axis, (metric, label) in zip(panes, axes, strict=True):
            error = [float(values(data["cases"], arm, w, metric)) for w in doses]
            curve[metric] = error
            axis.plot(error, response, label=name, color=color, linewidth=2)
            axis.scatter(error[-1:], response[-1:], color=color, s=18, zorder=3)
            axis.set_xlabel(label, fontsize=9)
            axis.grid(alpha=0.22)
            axis.tick_params(labelsize=8)
        recorded[arm] = curve
    panes[0].set_ylabel("Recovered weak fundamental (%)", fontsize=9)
    panes[1].legend(loc="lower right", frameon=False, fontsize=8)
    fig.suptitle("ISO6400 • 24 held-out photos • two RAW draws per source", fontsize=11)
    filename = OUT / "native" / "response-tradeoff.png"
    fig.savefig(filename, dpi=170)
    plt.close(fig)
    write_json(OUT / "response-tradeoff.json", {
        "driver": reference(Path(__file__)), "source": binding, "image": reference(filename),
        "fraction_of_nominal_correction": doses.tolist(), "curves": recorded,
    })


if __name__ == "__main__":
    main()
