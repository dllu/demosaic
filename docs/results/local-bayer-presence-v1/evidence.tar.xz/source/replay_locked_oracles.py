"""Supply exact frequencies to the locked models without changing local evidence."""

from pathlib import Path
from time import monotonic
from types import SimpleNamespace

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import presence_guarded as guarded
import replay_presence as replay


def main():
    torch.set_num_threads(2)
    lock = reference(replay.OUT / "guarded-calibration.json")
    policy = read_json(checked(lock))["weights"]
    name = policy["best"]["ring_phase"]

    def apply(*args):
        parent, outputs, info = guarded.fit(*args)
        return parent, {name: outputs[name]}, {name: info[name]} if name in info else {}

    replay.presence = SimpleNamespace(fit=apply)
    replay.ARMS = ("broad", "nested", name)
    collections = {}
    start = monotonic()
    for key, path in (("retained", replay.PREVIOUS), ("fresh", replay.OUT / "fresh")):
        replay.PREVIOUS = path
        source, plan, rows = replay.load_confirmation(oracle=True)
        collections[key] = {"source": source, "plan": plan, "rows": rows}
    write_json(replay.OUT / "locked-oracles.json", {
        "driver": reference(Path(__file__)), "operator": reference(guarded.__file__),
        "calibration": lock, "panels": collections, "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
