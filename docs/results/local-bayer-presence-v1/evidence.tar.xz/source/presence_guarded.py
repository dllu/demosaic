"""Average zero-, one- and two-direction fits with support inferred from Bayer RAW."""

from itertools import product

import numpy as np
from scipy.special import logsumexp

from demosaic._mesh_pooled import _CORE, _STRIDE, _WINDOW, _footprint, _rgb, _wave, _windows
from demosaic.mesh_carrier_fit import _cosine_background, _positions

ODDS = (-8.0, -6.0, -4.0, -2.0)
MODES = ("local", "ring_power", "ring_phase")
CUTOFFS = (0.05, 0.2, 0.5)
ARMS = tuple(
    f"{mode}_{-odds:g}_{cutoff:g}"
    for mode, odds, cutoff in product(MODES, ODDS, CUTOFFS)
)
STATES = ((0,), (1,), (0, 1))
CENTER = _WINDOW // 2
WIDTH = _WINDOW - 2 * _CORE[0].start
WINDOW_SHAPE = np.s_[:, _CORE[0], _CORE[1]]
RING = np.ones((_WINDOW, _WINDOW), dtype=bool)
RING[_CORE] = False


def residualizer(smooth, wave, position, keep):
    y, x = position
    sampled = keep[y::2, x::2]
    bg = smooth[y::2, x::2][sampled]
    measured = wave[y::2, x::2][sampled]
    residual = measured - bg @ (np.linalg.pinv(bg, rcond=1e-8) @ measured)
    return sampled, residual, residual.T @ residual


def statistics(windows, positions, wave, smooth, keep, shot, read):
    """Sum green-lattice likelihoods, with a separate nuisance fit per lattice."""
    matrix, moments = [], []
    for observed, site in zip(windows, positions, strict=True):
        mask, design, gram = residualizer(smooth, wave, site, keep)
        raw = observed[:, mask]
        sigma = np.maximum(2e-11, shot * np.maximum(0, raw.mean(axis=-1)) + read)
        weight = 1 / sigma
        matrix.append(weight[:, None, None] * gram)
        moments.append(weight[:, None] * (raw @ design))
    return np.sum(matrix, axis=0), np.sum(moments, axis=0)


def observations(scene, colors, roi):
    sites = _positions(colors, *roi[:2])
    windows = tuple(
        _windows(_footprint(scene, roi[:2], pos), _WINDOW // 2, _STRIDE // 2) for pos in sites
    )
    centers = tuple(a[:, _CORE[0].start // 2 : -_CORE[0].start // 2,
                      _CORE[1].start // 2 : -_CORE[1].start // 2] for a in windows)
    return sites, windows, centers


def fit_rings(windows, sites, wave, shot, read):
    gram, moment = statistics(windows, sites, wave, _cosine_background(_WINDOW), RING, shot, read)
    inv = np.linalg.pinv(gram, hermitian=True, rcond=1e-8)
    raw = (inv @ moment[..., None])[..., 0].reshape(-1, 2, 2)
    variance = inv.diagonal(axis1=-2, axis2=-1).reshape(-1, 2, 2).sum(axis=-1)
    energy = np.sum(raw**2, axis=-1)
    power = np.maximum(0, energy - variance)
    shrink = np.sqrt(power / energy.clip(min=1e-20))
    return raw * shrink[..., None], np.sqrt(power)


def posterior(gram, moment, mean, deviation):
    """Compare every projected submodel to a nuisance-only fit."""
    n = len(moment)
    evidences = [np.zeros(n)]
    fits = [np.zeros((n, 4))]
    presence = [np.zeros(2)]
    for state in STATES:
        columns = np.array([2 * d + k for d in state for k in range(2)])
        dim = len(columns)
        precision = np.repeat(1 / deviation[:, state] ** 2, 2, axis=-1)
        prior = mean[:, columns]
        system = gram[:, columns][:, :, columns].copy()
        system[:, np.arange(dim), np.arange(dim)] += precision
        location = prior * precision + moment[:, columns]
        update = np.linalg.solve(system, location[..., None])[..., 0]
        _, logdet = np.linalg.slogdet(system)
        evidence = 0.5 * (
            np.sum(np.log(precision) - prior * (prior * precision), axis=-1)
            - logdet + np.einsum("ni,ni->n", location, update)
        )
        padded = np.zeros((n, 4))
        padded[:, columns] = update
        fits.append(padded)
        evidences.append(evidence)
        presence.append(np.isin(np.arange(2), state).astype("d"))
    return np.stack(evidences, axis=1), np.stack(fits, axis=1), np.stack(presence)


def combine(evidence, fits, states, odds, inherited, central_cap, cutoff):
    logit = evidence + odds * states.sum(axis=1)
    probability = np.exp(logit - logsumexp(logit, axis=1, keepdims=True))
    inclusion = probability @ states
    value = np.einsum("ns,nsd->nd", probability, fits).reshape(-1, 2, 2)
    delta = value - inclusion[..., None] * inherited
    cap = inclusion * central_cap
    delta *= np.minimum(1, cap / np.linalg.norm(delta, axis=-1).clip(min=1e-15))[..., None]
    raw_gate = np.maximum(0, (inclusion - cutoff) / (1 - cutoff))
    relative = raw_gate / np.maximum(inclusion, 1e-15)
    delta *= relative[..., None]
    return delta.reshape(-1, 4), inclusion, raw_gate


def statistics_for(scene, colors, roi, peaks, shot, read):
    sites, windows, center = observations(scene, colors, roi)
    outer_wave = _wave(_WINDOW, peaks).reshape(_WINDOW, _WINDOW, 4)
    central_wave = outer_wave[_CORE]
    assert central_wave.shape[:2] == (CENTER, CENTER)
    ring_means, ring_amp = fit_rings(windows, sites, outer_wave, shot, read)
    gram, response = statistics(
        center, sites, central_wave, _cosine_background(CENTER),
        np.ones((CENTER, CENTER), dtype=bool), shot, read,
    )
    return central_wave, gram, response, ring_means, ring_amp


def fit(parent, local, scene, colors, roi, peaks, shot, read, wb, matrix):
    x, y = local[:2]
    prior = parent[:, y:y + 160, x:x + 160]
    if peaks is None:
        return prior, {k: prior for k in ARMS}, {}
    wave, gram, moment, ring, power = statistics_for(scene, colors, roi, peaks, shot, read)
    smooth = _cosine_background(CENTER)
    design = np.concatenate((smooth, wave), axis=-1).reshape(CENTER**2, -1)
    center_green = _windows(prior[1], CENTER, _STRIDE).reshape(-1, CENTER**2)
    inherited = (center_green @ np.linalg.pinv(design, rcond=1e-8)[-4:].T).reshape(-1, 2, 2)
    ls = (np.linalg.pinv(gram, hermitian=True, rcond=1e-8) @ moment[..., None])[..., 0]
    cap = np.linalg.norm(ls.reshape(-1, 2, 2), axis=-1)
    width = 0.00065 + 0.60 * power
    local_width = np.zeros_like(width) + 0.0015
    specifications = {
        "local": (np.zeros_like(moment), local_width),
        "ring_power": (np.zeros_like(moment), width),
        "ring_phase": (ring.reshape(-1, 4), width),
    }
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    results, info = {}, {}
    for label, (m, s) in specifications.items():
        parts = posterior(gram, moment, m, s)
        for logodds, cutoff in product(ODDS, CUTOFFS):
            delta, inclusion, raw_gate = combine(*parts, logodds, inherited, cap, cutoff)
            patch = np.einsum("yxk,nk->nyx", wave, delta)
            key = f"{label}_{-logodds:g}_{cutoff:g}"
            results[key] = prior + _rgb(patch, neutral, prior.dtype)
            info[key] = {
                "probability_over_half": np.count_nonzero(inclusion > 0.5, axis=0).tolist(),
                "nonzero_gate": np.count_nonzero(raw_gate > 0, axis=0).tolist(),
                "median_inclusion": np.median(inclusion, axis=0).tolist(),
                "max_inclusion": inclusion.max(axis=0).tolist(),
            }
    return prior, results, info


def audit():
    rng = np.random.default_rng(452020)
    raw = rng.normal(0.07, 0.013, (4, 256, 256)).astype("f")
    from demosaic.cfa import PATTERNS

    geometry = np.array(((0.109, 0.086), (0.094, -0.077)))
    roi = (176, 176, 160, 160)
    checked_cases = []
    for layout, colors in PATTERNS.items():
        s, ext, center = observations(raw, colors, roi)
        wave = _wave(_WINDOW, geometry).reshape(_WINDOW, _WINDOW, 4)
        base = fit_rings(ext, s, wave, 0.00128, 6.5536e-6)
        masked = tuple(x.copy() for x in ext)
        for x in masked:
            x[:, 8:24, 8:24] += rng.uniform(-0.05, 0.05, x[:, 8:24, 8:24].shape)
        updated = fit_rings(masked, s, wave, 0.00128, 6.5536e-6)
        for a, b in zip(base, updated, strict=True):
            np.testing.assert_array_equal(a, b)
        assert all(x.shape[1:] == (16, 16) for x in center)
        checked_cases.append(layout)
    # Orthogonal unit likelihood factors split into independent one-direction posteriors.
    gram = (np.eye(4) * 3)[None]
    moment = np.array([[4., -3., 0.8, -0.4]])
    mean = np.array([[0.6, 0.1, 0., 0.3]])
    scale = np.array([[0.9, 0.7]])
    l, _, _ = posterior(gram, moment, mean, scale)
    np.testing.assert_allclose(l[0, -1], l[0, 1:3].sum(), rtol=1e-13, atol=1e-13)
    return {"independent_ring_layouts": checked_cases, "factorized_likelihood_error": float(l[0, -1] - l[0, 1:3].sum())}
