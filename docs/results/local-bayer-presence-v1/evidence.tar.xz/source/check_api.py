"""Verify the packaged ring option matches the selected experimental policy."""

from pathlib import Path
from statistics import median
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers
from review_presence import arrays, FIXED, ROI
import presence_guarded as previous
from replay_presence import OUT

API = Path("src/demosaic/mesh_carrier_fit.py")
IMPLEMENTATION = Path("src/demosaic/_mesh_presence.py")
ARM = "ring_phase_6_0.2"


def compare(restored, local, raw, roi, colors, noise, wb, matrix, clearance):
    x, y, w, h = local
    parent = restored[:, y:y + h, x:x + w]
    peak = _spacing(raw, colors, *roi[:2], clearance=clearance)
    _, source, _ = previous.fit(restored, local, raw, colors, roi, peak, noise["shot"], noise["read"], wb, matrix)
    mark = monotonic()
    result = refine_raw_mesh_carriers(
        parent, raw, colors, roi,
        shot=noise["shot"], read=noise["read"], white_balance=wb, camera_to_srgb=matrix,
        method="ring-posterior", donor_clearance=clearance,
    )
    elapsed = monotonic() - mark
    committed = source[ARM]
    np.testing.assert_allclose(result, committed, rtol=1e-7, atol=4e-9)
    return {
        "bit_exact": bool(np.array_equal(result, committed)),
        "max_abs_DN16": float(np.max(abs(result.astype("d") - committed)) * 65535),
        "seconds": elapsed,
    }


def main():
    torch.set_num_threads(2)
    start = monotonic()
    fresh = reference(OUT / "fresh-guarded.json")
    bundle = read_json(checked(fresh))
    plan = read_json(checked(bundle["plan"]))
    lock = read_json(checked(bundle["calibration"]))["weights"]
    assert lock["best"]["ring_phase"] == ARM and lock["choices"][ARM]["weight"] == 1
    x, y, w, h = plan["query"]
    roi = (x + ROI[0], y + ROI[1], *ROI[2:])
    results = []
    for g in bundle["cases"]:
        for d in g["draws"]:
            f = arrays(d["input"])
            scene = f["scene_packed"].copy()
            parents = np.load(checked(d["outputs"]["local50k"]), allow_pickle=False)
            sample = []
            for p, packed in zip(parents, f["packed"], strict=True):
                scene[:, y//2:(y + h)//2, x//2:(x + w)//2] = packed
                sample.append(compare(
                    p, ROI, scene, roi, f["colors"], plan["noise"], f["wb"], f["matrix"], 48,
                ))
            results.append({"id": g["id"], "draw": d["draw"], "scores": sample})
    fixed = reference(FIXED)
    camera = []
    for row in read_json(checked(fixed))["standing"]:
        f = arrays(row["input"])
        parent = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(row["local_ROI"])
        values = compare(
            parent, roi, f["packed"][0], roi, f["colors"][0], row["noise"], f["wb"][0], f["matrix"][0], 16,
        )
        camera.append({"id": row["id"], "scores": values})
    all_scores = [r for x in results for r in x["scores"]]
    write_json(OUT / "api-equivalence.json", {
        "driver": reference(__file__), "api": reference(API), "operator": reference(IMPLEMENTATION),
        "fresh": fresh, "camera_fixture": fixed, "fresh_results": results, "camera": camera,
        "fresh_count": len(all_scores), "fresh_exact": sum(x["bit_exact"] for x in all_scores),
        "camera_exact": sum(x["scores"]["bit_exact"] for x in camera),
        "maximum_absolute_difference_DN16": max(x["max_abs_DN16"] for x in (*all_scores, *(r["scores"] for r in camera))),
        "median_fresh_api_ms": 1000 * median(x["seconds"] for x in all_scores),
        "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
