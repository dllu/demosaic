"""Bind paired optical contrasts at nominal and calibration-matched response."""

from pathlib import Path
from statistics import mean, median

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from replay_presence import OUT, metrics_at
from evaluate_ring import ABS, ABSOLUTE, FALSE, FLAT, GAP, interval, source_bootstrap

METRICS = (
    ABSOLUTE, ABS, FALSE, GAP, FLAT, "flat_added_DN16", "edge_update_RMS_DN16",
    "uniform_update_RMS_DN16",
)


def paired(groups, first, second):
    data = {}
    for key in METRICS:
        subset = []
        for row in groups:
            pairs = []
            for d in row["draws"]:
                values = [metrics_at(d["powers"][arm], scale) for arm, scale in (first, second)]
                if key in values[0]:
                    pairs.append([v[key] for v in values])
            if pairs:
                subset.append({"family": row["family"], "values": np.mean(pairs, axis=0)})
        if subset:
            idx = source_bootstrap(subset, np.random.default_rng(202611200347))
            matrix = np.asarray([r["values"] for r in subset])
            boot = matrix[idx].mean(axis=1)
            data[key] = {
                "sources": len(subset), "means": matrix.mean(axis=0).tolist(),
                "difference_interval": interval(boot[:, 0] - boot[:, 1]),
                "source_differences": (matrix[:, 0] - matrix[:, 1]).tolist(),
            }
    return data


def limits_summary(rows, arms):
    result = {}
    roles = (
        ("flat_core", "flat_added_DN16"), ("edge_only", "edge_update_RMS_DN16"),
        ("uniform", "uniform_update_RMS_DN16"),
    )
    for arm in arms:
        flattened = [e["nominal"][arm] for r in rows for e in r["draws"]]
        result[arm] = {
            role: {
                "mean_added_DN16": mean(x[key] for x in flattened),
                "maximum_added_DN16": max(x[key] for x in flattened),
                "nonzero_crops": sum(x[key] > 0 for x in flattened),
            }
            for role, key in roles
        }
    return result


def oracle_summary(raw, oracle, arms):
    a = [d for r in raw for d in r["draws"]]
    b = [d for r in oracle for d in r["draws"]]
    assert len(a) == len(b)
    e = [x["guide_error_in_128_bins"][1] for x in a if x["guide_error_in_128_bins"] is not None]
    return {
        "captures": len(a), "guides_found": len(e), "weak_guide_median_bins": median(e),
        "weak_guide_maximum_bins": max(e),
        "exact_frequency_added_response": {
            arm: mean(
                after["nominal"][arm][ABSOLUTE] - before["nominal"][arm][ABSOLUTE]
                for before, after in zip(a, b, strict=True)
            )
            for arm in arms
        },
    }


def main():
    cal = reference(OUT / "guarded-calibration.json")
    data = read_json(checked(cal))
    policy = data["weights"]
    arm = policy["best"]["ring_phase"]
    assert policy["choices"][arm]["weight"] == 1
    base = "nested"
    target = policy["baseline"]
    controls = [base, "broad", *policy["best"].values()]
    calibration = [r["draws"][0]["nominal"] for r in data["rows"]]
    original = mean(d["local50k"][ABSOLUTE] for d in calibration)
    scales = {
        label: (target - original) / (mean(d[label][ABSOLUTE] for d in calibration) - original)
        for label in (arm, "broad")
    }
    assert all(0.0 < x <= 1.0 for x in scales.values())
    exact = reference(OUT / "locked-oracles.json")
    oracle = read_json(checked(exact))
    panels = {}
    for panel in ("retained", "fresh"):
        ref = reference(OUT / f"{panel}-guarded.json")
        rows = read_json(checked(ref))["cases"]
        panels[panel] = {
            "observations": ref, "sources": len(rows),
            "nominal_vs_combined": {k: paired(rows, (k, 1), (base, 1)) for k in controls},
            "response_matched_vs_combined": {k: paired(rows, (k, a), (base, 1)) for k, a in scales.items()},
            "nominal_quiet": limits_summary(rows, controls),
            "exact_frequency_diagnostic": oracle_summary(rows, oracle["panels"][panel]["rows"], (arm, base, "broad")),
        }
    write_json(OUT / "summary.json", {
        "driver": reference(Path(__file__)), "calibration": cal, "scope_locked": True,
        "exact_frequencies": exact, "arms": controls, "scale_to_calibration_combined_response": scales,
        "panels": panels,
    })


if __name__ == "__main__":
    main()
