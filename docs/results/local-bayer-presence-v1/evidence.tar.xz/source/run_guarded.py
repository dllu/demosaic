"""Calibrate truncated posterior means and hold their policy fixed on two cohorts."""

from time import monotonic
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import presence_guarded as guarded
import replay_presence as replay


def main():
    torch.set_num_threads(2)
    start = monotonic()
    replay.presence = guarded
    replay.ARMS = ("broad", "nested", *guarded.ARMS)
    if "--fresh" in sys.argv:
        replay.PREVIOUS = replay.OUT / "fresh"
        destination = replay.OUT / "fresh-guarded.json"
    else:
        source, rows = replay.load_calibration()
        write_json(replay.OUT / "guarded-calibration.json", {
            "driver": reference(__file__), "operator": reference(guarded.__file__), "source": source,
            "weights": replay.calibration(rows), "rows": rows, "seconds": monotonic() - start,
        })
        destination = replay.OUT / "retained-guarded.json"
    calibration = reference(replay.OUT / "guarded-calibration.json")
    frozen = read_json(checked(calibration))["weights"]
    # Retained replay captures nominal curves. The fresh cohort tests the locked per-family winners.
    if "--fresh" in sys.argv:
        replay.ARMS = ("broad", "nested", *frozen["best"].values())
    parent, plan, cases = replay.load_confirmation()
    write_json(destination, {
        "driver": reference(__file__), "operator": reference(guarded.__file__),
        "calibration": calibration, "source": parent, "plan": plan,
        "cases": cases, "reported_arms": replay.ARMS, "elapsed": monotonic() - start,
    })


if __name__ == "__main__":
    main()
