"""Render the two selected fresh RAW panels using their frozen frequency arrays."""

from pathlib import Path
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import review_presence as review


def main():
    torch.set_num_threads(2)
    start = monotonic()
    lock = reference(review.replay.OUT / "guarded-calibration.json")
    policy = read_json(checked(lock))["weights"]
    driver = review.arcs

    def arcs(parent, local, scene, colors, roi, peaks, *values):
        frequencies = None if peaks is None else np.asarray(peaks, dtype="d")
        return driver(parent, local, scene, colors, roi, frequencies, *values)

    review.arcs = arcs
    location = review.replay.OUT / "native" / "exact"
    location.mkdir(exist_ok=True, parents=True)
    rows = review.exact(policy, location)
    write_json(
        review.replay.OUT / "native-exact.json",
        {"driver": reference(Path(__file__)), "calibration": lock, "data": rows, "seconds": monotonic() - start},
    )


if __name__ == "__main__":
    main()
