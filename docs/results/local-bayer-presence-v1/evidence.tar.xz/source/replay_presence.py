"""Replay Bayer models and matched gates on fixed calibration and confirmation crops."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PREVIOUS = OUT.with_name("local-nested-support-v1")

sys.path.insert(0, str(HERE.with_name(PREVIOUS.name)))
from nested_gate import apply as nested_apply
from evaluate_ring import ABSOLUTE, ABS, FALSE, FLAT, GAP, LENGTH, ROI, WireFundamental
from evaluate_ring import arrays, frozen_inputs, support_for_scoring
from score_nested_clearance48 import null_measures, profile_with_color, section
from scoring import luma

import presence

ARMS = ("broad", "nested", *presence.ARMS)
LINEAR = (LENGTH, ABSOLUTE)
LEVELS = np.linspace(0, 1, 129)


def datums(case, profile, parent, f, scene, cut, roi, *, oracle=False):
    noise = profile_with_color(f, profile)
    geometry = case["geometry"]
    colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
    measured = _spacing(scene, colors, *roi[:2], clearance=48)
    reference_angle = np.asarray(geometry["frequency"])
    guide = reference_angle if oracle else measured
    output = {name: parent.copy() for name in ARMS}
    activity = []
    saved = scene[cut].copy()
    for i, packed in enumerate(f["packed"]):
        scene[cut] = packed
        if i == 0 or i == len(f["packed"]) - 1:
            same = _spacing(scene, colors, *roi[:2], clearance=48)
            np.testing.assert_array_equal(measured, same)
        direction_gate, accepted = nested_apply(parent[i], ROI, scene, colors, roi, guide, noise)
        _, result, info = presence.fit(parent[i], ROI, scene, colors, roi, guide, profile["shot"], profile["read"], wb, matrix)
        for k in ("broad", "nested"):
            section(output[k][i], *ROI)[:] = direction_gate[k]
        for k, q in result.items():
            section(output[k][i], *ROI)[:] = q
        activity.append({k: {"probability_over_half": v, "legacy": True} for k, v in accepted.items()} | info)
    scene[cut] = saved
    return measured, reference_angle, output, activity


def comparisons(case, profile, parent, f, scene, cut, roi, sharp, *, oracle=False):
    measured, known, corrected, accepted = datums(case, profile, parent, f, scene, cut, roi, oracle=oracle)
    geo, support = case["geometry"], support_for_scoring(f["support"])
    clean = WireFundamental({"target": sharp, "support": support, "wb": f["wb"], "matrix": f["matrix"]}, geo)
    opt = WireFundamental(f | {"target": f["target"][:4], "support": support}, geo)
    origin = parent.astype("d")
    pixel_slice = np.s_[..., 64:192, 64:192]

    def measure(rgb):
        dflat = luma((rgb[3:4] - origin[3:4])[pixel_slice], f["wb"], f["matrix"])
        other = null_measures(rgb, origin, f) if len(rgb) == 6 else {}
        return {
            **opt(rgb[:4]),
            ABSOLUTE: clean(rgb[:4])[LENGTH],
            "flat_added_DN16": float(np.sqrt(np.mean(dflat**2)) * 65535),
            **other,
        }

    base = measure(origin)
    observations = {}
    for k, img in corrected.items():
        dx = img - origin
        positive, negative = measure(origin + dx), measure(origin - dx)
        observations[k] = {}
        for m, z in base.items():
            p, n = positive[m], negative[m]
            if m in LINEAR:
                observations[k][m] = (z, (p - n) / 2)
            else:
                observations[k][m] = (z*z, (p*p - n*n) / 2, (p*p + n*n) / 2 - z*z)
    return {
        "fixed_guide": None if measured is None else measured.tolist(),
        "exact_guide": known.tolist(),
        "guide_error_in_128_bins": None if measured is None else (128 * np.linalg.norm(known - measured, axis=1)).tolist(),
        "nominal": {"local50k": base, **{k: metrics_at(v, 1) for k, v in observations.items()}},
        "powers": observations,
        "activity": accepted,
    }


def metrics_at(moment, a):
    metrics = {}
    for key, vector in moment.items():
        if key in LINEAR:
            metrics[key] = float(vector[0] + vector[1] * a)
        else:
            metrics[key] = float(np.sqrt(max(0, vector[0] + vector[1] * a + vector[2] * a * a)))
    return metrics


def curve(rows, mode, metric):
    groups = [
        [a["powers"][mode][metric] for a in g["draws"] if metric in a["powers"][mode]]
        for g in rows
    ]
    data = np.array([np.mean(x, axis=0) for x in groups if x], dtype="d")
    if not len(data):
        return np.full_like(LEVELS, np.nan)
    components = data[:, 0, None] + data[:, 1, None] * LEVELS
    if metric not in LINEAR:
        components = np.sqrt(np.maximum(0, components + data[:, 2, None] * LEVELS**2))
    return components.mean(axis=0)


def calibration(data):
    limits = (FALSE, FLAT, "flat_added_DN16")
    ceilings = {k: float(curve(data, "nested", k)[-1]) for k in limits}
    baseline = float(curve(data, "nested", ABSOLUTE)[-1])
    choices = {}
    for method in presence.ARMS:
        recall = curve(data, method, ABSOLUTE)
        clean = np.logical_and.reduce([curve(data, method, k) <= ceilings[k] + 1e-10 for k in limits])
        if not clean.any():
            continue
        eligible = np.flatnonzero(clean)
        selected = eligible[np.argmax(recall[eligible])]
        choices[method] = {
            "weight": float(LEVELS[selected]), "weak_response": float(recall[selected]),
            "quiet": {k: float(curve(data, method, k)[selected]) for k in limits},
        }
    groups = {
        name: max(
            (k for k in choices if k.startswith(name + "_")),
            key=lambda k: choices[k]["weak_response"],
        )
        for name in presence.MODES
        if any(k.startswith(name + "_") for k in choices)
    }
    return {"limits": ceilings, "baseline": baseline, "best": groups, "choices": choices}


def load_calibration():
    source = reference(OUT.with_name("local-exterior-phase-transfer-v1") / "parent/result.json")
    panel = read_json(checked(source))["panels"]["previous"]
    rows = []
    for row in panel["rows"]:
        f = frozen_inputs(row)
        fixture = f["case"]["fixture"]
        sharp = arrays(f["case"]["inputs"]["0.0"])["target"]
        result = comparisons(
            fixture, panel["profile"], f["parent"], f["input"], f["scene"], f["cut"], f["phase_correction_roi"], sharp,
        )
        rows.append({"id": f["case"]["id"], "fixture": fixture, "family": fixture["geometry"]["family"], "draws": [result]})
        if len(rows) % 8 == 0:
            print("calibration", len(rows), flush=True)
    return source, rows


def load_confirmation(oracle=False):
    source = reference(PREVIOUS / "parent/result.json")
    previous = read_json(checked(source))
    inputs = read_json(checked(previous["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + ROI[0], y + ROI[1], *ROI[2:])
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    results = []
    for case, series in zip(plan["sources"], previous["records"], strict=True):
        draws = []
        assert case["id"] == series["id"]
        for row in series["streams"]:
            f = arrays(row["data"])
            p = np.load(checked(row["outputs"]["local50k"]), allow_pickle=False)
            z = comparisons(case, plan["noise"], p, f, f["scene_packed"].copy(), cut, roi, f["sharp_target"], oracle=oracle)
            draws.append(z | {"input": row["data"], "outputs": row["outputs"], "draw": row["draw"]})
        results.append({"id": case["id"], "fixture": case, "family": case["geometry"]["family"], "draws": draws})
        if len(results) % 8 == 0:
            print("confirmation", "exact guides" if oracle else "estimated guides", len(results), flush=True)
    return source, inputs["plan"], results


def main():
    torch.set_num_threads(2)
    start = monotonic()
    if "--oracle" not in sys.argv:
        src, training = load_calibration()
        write_json(
            OUT / "calibration.json",
            {"driver": reference(__file__), "model": reference(presence.__file__), "source": src,
             "rows": training, "weights": calibration(training), "seconds": monotonic() - start},
        )
    exact = "--oracle" in sys.argv
    trial, plan, examples = load_confirmation(oracle=exact)
    name = "exact-guides.json" if exact else "estimated-guides.json"
    write_json(
        OUT / name,
        {"driver": reference(__file__), "model": reference(presence.__file__), "source": trial,
         "plan": plan, "rows": examples, "audit": presence.audit(), "seconds": monotonic() - start},
    )


if __name__ == "__main__":
    main()
