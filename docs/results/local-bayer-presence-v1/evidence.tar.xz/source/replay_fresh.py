"""Evaluate the calibrated posterior rules on fresh source-disjoint captures."""

from pathlib import Path
from time import monotonic
from types import SimpleNamespace

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import presence_guarded as guarded
import replay_presence as replay


def main():
    torch.set_num_threads(2)
    start = monotonic()
    calibration = reference(replay.OUT / "guarded-calibration.json")
    frozen = read_json(checked(calibration))["weights"]
    selected = tuple(frozen["best"].values())

    def locked_fit(*values, **kwargs):
        prior, outputs, diagnostics = guarded.fit(*values, **kwargs)
        return prior, {k: outputs[k] for k in selected}, {k: diagnostics[k] for k in selected if k in diagnostics}

    replay.PREVIOUS = replay.OUT / "fresh"
    replay.ARMS = ("broad", "nested", *selected)
    replay.presence = SimpleNamespace(fit=locked_fit)
    source, plan, results = replay.load_confirmation()
    write_json(replay.OUT / "fresh-guarded.json", {
        "driver": reference(Path(__file__)), "operator": reference(guarded.__file__),
        "calibration": calibration, "source": source, "plan": plan,
        "cases": results, "reported_arms": replay.ARMS, "elapsed": monotonic() - start,
    })


if __name__ == "__main__":
    main()
