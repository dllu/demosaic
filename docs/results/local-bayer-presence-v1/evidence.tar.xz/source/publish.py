"""Publish the evaluated crop option, native boards and immutable evidence."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
ID = "local-bayer-presence-v1"
OUT = Path("/mnt/external/demosaic") / ID
SCRATCH = ROOT / ".cache/experiments" / ID
IMAGES = ROOT / "docs/assets" / ID
RESULTS = ROOT / "docs/results" / ID
RECEIPTS = (
    "calibration.json", "estimated-guides.json", "exact-guides.json",
    "guarded-calibration.json", "retained-guarded.json", "fresh-guarded.json",
    "locked-oracles.json", "fresh/plan.json", "fresh/inputs.json", "fresh/parent/result.json",
    "native-exact.json", "native-standing.json", "api-equivalence.json", "api-release-equivalence.json",
    "summary.json", "response-tradeoff.json",
)


def put(source):
    old = checked(source)
    target = IMAGES / old.name
    shutil.copyfile(old, target)
    got = reference(target)
    assert got["sha256"] == source["sha256"]
    return got | {"path": str(target.relative_to(ROOT))}


def board(data):
    published = put(data["image"])
    with Image.open(ROOT / published["path"]) as image:
        for column in data["panels"]:
            x, y, w, h = column["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= image.width and 0 <= y < y + h <= image.height
    return data | {"image": published}


def main():
    IMAGES.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    sources = {path: reference(OUT / path) for path in RECEIPTS}
    evidence = {key: read_json(checked(value)) for key, value in sources.items()}
    release = evidence["api-release-equivalence.json"]
    assert (release["fresh_count"], release["fresh_exact"], release["camera_exact"]) == (288, 288, 8)
    files = {
        f"source/{p.name}": reference(p)
        for p in sorted(SCRATCH.glob("*.py"))
    }
    assert (
        files["source/mesh_presence-before-format.py"]["sha256"]
        == evidence["api-equivalence.json"]["operator"]["sha256"]
    )
    for key in ("api", "operator"):
        rel = Path(release[key]["path"]).relative_to(ROOT)
        files[str(rel)] = reference(checked(release[key]))
    files["tests/test_mesh_carrier_fit.py"] = reference(ROOT / "tests/test_mesh_carrier_fit.py")
    for k, r in sources.items():
        files[f"receipts/{k}"] = r
        for f in ("driver", "model", "operator"):
            if f in evidence[k] and not (k == "api-equivalence.json" and f == "operator"):
                checked(evidence[k][f])
    previous = reference(ROOT / "docs/results/local-nested-support-v1/publication.json")
    fresh = evidence["fresh/parent/result.json"]
    assert fresh["inputs"] == sources["fresh/inputs.json"]
    for group in fresh["records"]:
        for capture in group["streams"]:
            checked(capture["data"])
            for bound in capture["outputs"].values():
                checked(bound)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for name, binding in files.items():
            tar.add(checked(binding), arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == files.keys()
        for name, binding in files.items():
            with tar.extractfile(name) as handle:
                assert hashlib.file_digest(handle, "sha256").hexdigest() == binding["sha256"]

    native = IMAGES / "manifest.json"
    exact = [row | {"board": board(row["board"]), "triplet": board(row["triplet"])}
             for row in evidence["native-exact.json"]["data"]["boards"]]
    camera = [row | {"native": [board(b) for b in row["native"]]}
              for row in evidence["native-standing.json"]["data"]["rows"]]
    chart = put(evidence["response-tradeoff.json"]["image"])
    write_json(native, {
        "exact": exact, "camera": camera, "tradeoff_plot": chart,
    })
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(sources["summary.json"]), summary)
    assert reference(summary)["sha256"] == sources["summary.json"]["sha256"]
    write_json(RESULTS / "publication.json", {
        "base_git_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "archive": reference(archive), "summary": reference(summary), "native_manifest": reference(native),
        "prior_publication": previous, "members": files, "original_receipts": sources,
        "native_comparisons_viewed": sum(len(row["native"]) for row in camera) + len(exact),
        "native_triplets_viewed": len(exact), "new_weights": None,
    })


if __name__ == "__main__":
    main()
