"""Review weak-carrier support changes on both standing GFX families."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.reporting import display_crop
from support import ROOT,CURVE,estimate
from run_restore import ARGS

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

LABELS={"wide":"Curved backup","compact":"Compact support","deficit":"Local deficit check",
        "uniform-compact":"Uniform compact control","uniform-deficit":"Uniform deficit control"}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    stamp = reference(ROOT/"forecasts-standing.json")
    linked = read_json(checked(stamp))
    choices = {r["id"]:r for r in linked["rows"]}
    source = reference(CURVE/"standing/manifest.json")
    board = read_json(checked(source))
    metric = reference(ROOT/"scores.json")
    sheet = read_json(checked(metric))
    scale = sheet["scale"]
    folder = ROOT/"standing"
    folder.mkdir(exist_ok=True)
    cards = []
    with ieee_fp32():
        for previous in board["rows"]:
            key = previous["id"]
            model = choices[key]
            assert model["raw"]==previous["noisy_source"] and model["window"]==previous["fit_box"]
            left,top,_,_ = model["window"]
            query = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            with np.load(checked(model["raw"]),allow_pickle=False)as f:
                args = [torch.from_numpy(f[k][query].copy()if k in ARGS[:2]else f[k])for k in ARGS]
            wb,matrix = args[-2:]
            parent = torch.from_numpy(np.load(checked(previous["parent"]),allow_pickle=False)[...,top:top+256,left:left+256].copy())
            x,y,w,h = previous["ROI"]["ROI_xywh"]
            roi = (x-left,y-top,w,h)
            outputs = estimate(args,parent,model["geometry"],model["weaker"]["index"]if model["weaker"]else None)
            values = {k:parent+scale*outputs[k]for k in ("wide","compact","deficit")}
            values.update({k:parent+scale*(outputs["strong"]+strength*outputs["weak"])
                           for k,strength in sheet["uniform_weak_factors"].items()})
            with Image.open(checked(previous["image"]))as f:
                image = np.asarray(f.convert("RGB"))
            data = {p["name"]:image[b:b+d,a:a+c]for p in previous["panels"]for a,b,c,d in (p["png_xywh"],)}
            base = np.rint(display_crop(parent,wb,matrix,roi,exposure=previous["display_exposure"])*255).astype(np.uint8)
            np.testing.assert_array_equal(base,data["Parent 100k EMA"])
            panes = [(k,data[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA")if k in data]
            change = {}
            x0,y0,w,h = roi
            saved = np.s_[...,y0:y0+h,x0:x0+w]
            for method,value in values.items():
                pixels = np.rint(display_crop(value,wb,matrix,roi,exposure=previous["display_exposure"])*255).astype(np.uint8)
                panes.append((LABELS[method],pixels))
                d = (value-values["wide"])[saved].numpy().astype(float)
                delta = (value-parent)[saved].numpy().astype(float)
                change[method] = {"camera_RGB_RMS_to_wide_DN16":float(65535*np.sqrt(np.mean(d*d))),
                                  "camera_RGB_RMS_to_parent_DN16":float(65535*np.sqrt(np.mean(delta*delta))),
                                  "changed_display_components_vs_parent":int((pixels!=base).sum())}
            panes += [(k,data[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in data]
            result = native_png(folder/(key+".png"),panes)
            saved = folder/(key+".npz")
            with saved.open("wb")as f:
                np.savez(f,parent=parent.numpy(),**{k:v.numpy()for k,v in values.items()})
            cards.append(result|{"id":key,"noise":previous["noise"],"exposure":previous["display_exposure"],
                "references":previous["references"],"ROI":previous["ROI"],"query_box":model["window"],
                "input":model["raw"],"parent":previous["parent"],"prior_board":previous["image"],
                "output":reference(saved),"weak_selector":model["weaker"],"camera_metrics":change})
            print(key,{k:round(v["camera_RGB_RMS_to_wide_DN16"],3)for k,v in change.items()},flush=True)
    assert len(cards)==8
    write_json(folder/"manifest.json",{"driver":reference(__file__),"selectors":stamp,"metrics":metric,
         "source":source,"scale":scale,"checkpoint":board["checkpoint"],"rows":cards})


if __name__=="__main__":
    main()
