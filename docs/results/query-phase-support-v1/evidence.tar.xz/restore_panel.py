"""Keep the strong carrier and parent fixed while changing weak support."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from support import ROOT,CURVE,METHODS,estimate
from run_restore import ARGS,observations,setup_models

OUTPUTS = ("strong","weak",*METHODS)


def restore_groups(args,parent,records):
    groups = defaultdict(list)
    outputs = {k:torch.zeros_like(parent)for k in OUTPUTS}
    for j,r in enumerate(records):
        if not r["geometry"]:
            continue
        template = tuple(tuple(p)for p in r["geometry"])
        groups[(template,r["weaker"]["index"])].append(j)
    for (shape,weak),indexes in groups.items():
        models = estimate([a[indexes]for a in args],parent[indexes],shape,weak)
        for k,v in models.items():
            outputs[k][indexes] = v
    return outputs


@torch.inference_mode()
def run(mode):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    selected = reference(ROOT/f"forecasts-{mode}.json")
    predictions = read_json(checked(selected))
    checked(predictions["support_code"])
    captures = read_json(checked(predictions["observations"]))
    plan = read_json(checked(captures["plan"]))
    older = reference(CURVE/"fallback-delivery-fit.json")if mode=="fit"else None
    inherited = read_json(checked(older))if older else None
    saved = {row["index"]:row for row in inherited["rows"]}if inherited else {}
    device = torch.device("cuda")
    target = ROOT/f"restored-{mode}"
    target.mkdir(exist_ok=True)
    records = []
    start = time.monotonic()
    with ieee_fp32():
        model = None
        if mode=="fresh":
            model = setup_models({"models":{"Corpus 100k":plan["base"]}})["Corpus 100k"]
            model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for row in predictions["rows"]:
            i = row["index"]
            source = captures["rows"][i]
            assert row["capture"]==source["capture"] and source["index"]==i
            path = target/f"{i:03d}.npz"
            if not path.exists():
                array = observations(source)
                args = [torch.from_numpy(array[k].reshape((-1,*array[k].shape[2:]))).to(device)for k in ARGS]
                args[:2] = [a.contiguous(memory_format=torch.channels_last)for a in args[:2]]
                if inherited:
                    with np.load(checked(saved[i]["output"]),allow_pickle=False)as f:
                        original = f["fallback-curved"]
                        parent = torch.from_numpy(f["baseline"].reshape(8,3,256,256)).to(device)
                else:
                    parent = model(*args)
                done = restore_groups(args,parent,row["trials"])
                output = {k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in (done|{"baseline":parent}).items()}
                if inherited:
                    np.testing.assert_allclose(output["wide"],original,rtol=0,atol=4e-8)
                assert all(np.isfinite(v).all()for v in output.values())
                partial = path.with_suffix(".incomplete")
                with partial.open("wb")as f:
                    np.savez(f,**output)
                partial.rename(path)
            records.append({"index":i,"output":reference(path)})
            print(mode,len(records),round(time.monotonic()-start,2),flush=True)
    write_json(ROOT/f"restoration-{mode}.json",{"driver":reference(__file__),"forecasts":selected,
                "previous_fit_outputs":older,"checkpoint":plan["base"],"rows":records,
                "seconds":time.monotonic()-start})


if __name__=="__main__":
    run(sys.argv[1])
