"""Bind the fixed curvature geometry and reserve-only identity of the weaker carrier."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from support import ROOT,CURVE,weaker,curvature
from fallback import select as backup
from consensus import cut

ROLES = ("present","outside-only","strong-only","quiet-query")
finder_spec = importlib.util.spec_from_file_location("source_nomination",CURVE/"select.py")
finder = importlib.util.module_from_spec(finder_spec)
finder_spec.loader.exec_module(finder)


def nominate(job):
    archive,frozen = job
    with np.load(checked(archive["capture"]),allow_pickle=False)as f:
        data = {k:f[k]for k in ("packed","variance","colors")}
    assert {k:fingerprint(v)for k,v in data.items()}=={k:archive["fingerprints"][k]for k in data}
    rows = []
    for repeat in range(2):
        for j,role in enumerate(ROLES):
            native = {k:v[repeat,j:j+1]for k,v in data.items()}
            patch = cut(native,128,128)
            if frozen is None:
                initial = finder.frequencies(native,128,128)
                chosen = curvature.choose(*patch,[q["frequency_xy"]for q in initial["peaks"]])
                curve = chosen["curved"] or backup(*patch)["fallback-curved"]
            else:
                row = frozen["rows"][repeat*4+j]
                assert (row["repeat"],row["role"])==(repeat,role)
                curve = row["methods"]["fallback-curved"]
            rows.append({"repeat":repeat,"role":role,"geometry":curve,"weaker":weaker(*patch,curve)})
    return {"index":archive["index"],"capture":archive["capture"],"trials":rows}


def select(mode):
    old = reference(CURVE/"fallback-fit.json")if mode=="fit"else None
    earlier = read_json(checked(old))if old else None
    frozen = read_json(checked(earlier["seeds"]))["observations"] if earlier else reference(ROOT/"fields.json")
    fields = read_json(checked(frozen))
    plan = read_json(checked(fields["plan"]))
    chosen = plan["fit_indices"]if mode=="fit"else plan["test_indices"]
    choices = {k["index"]:k for k in earlier["decisions"]}if earlier else {}
    pieces = [(fields["rows"][i],choices.get(i))for i in chosen]
    results = []
    with ThreadPoolExecutor(3)as pool:
        for i,v in enumerate(pool.map(nominate,pieces),1):
            results.append(v)
            print(mode,i,len(pieces),flush=True)
    write_json(ROOT/f"forecasts-{mode}.json",{"driver":reference(__file__),"support_code":reference(ROOT/"support.py"),
          "observations":frozen,"earlier_geometry":old,"selection_code":[reference(CURVE/"select.py"),reference(CURVE/"fallback.py")],
          "rows":results})


def standing():
    old = reference(CURVE/"fallback-standing.json")
    decisions = read_json(checked(old))
    source = read_json(checked(decisions["seeds"]))
    lookup = {r["id"]:r for r in source["rows"]}
    rows = []
    for case in decisions["decisions"]:
        fixture = lookup[case["id"]]
        box = fixture["native_box"]
        with np.load(checked(fixture["input"]),allow_pickle=False)as r:
            values = {k:r[k]for k in ("packed","variance","colors")}
        model = case["methods"]["fallback-curved"]
        word = weaker(*cut(values,*box[:2]),model)
        rows.append({"id":case["id"],"window":box,"raw":fixture["input"],"geometry":model,
                     "weaker":word})
        print(case["id"],word,flush=True)
    write_json(ROOT/"forecasts-standing.json",{"driver":reference(__file__),"earlier_geometry":old,
          "support_code":reference(ROOT/"support.py"),"rows":rows})


if __name__=="__main__":
    standing()
    select("fit")
    select("fresh")
