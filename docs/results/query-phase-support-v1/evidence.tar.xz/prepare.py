"""Freeze independent photos with curved carriers and broken or continuous support."""
from pathlib import Path
import hashlib
import importlib.util
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
CURVE = ROOT.parent/"query-phase-curvature-v1"
LAST = ROOT.parent/"query-frequency-consensus-v1"
module_spec = importlib.util.spec_from_file_location("frozen_curved_targets", LAST/"prepare.py")
geometry = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(geometry)

SEED = 627959133561
COUNT = 24


def clean_targets(photo,row):
    captures,gap,carrier = geometry.clean_targets(photo,row)
    if row["support"]=="continuous":
        y,x = torch.meshgrid(torch.arange(512,dtype=photo.dtype)-255.5,torch.arange(512,dtype=photo.dtype)-255.5,indexing="ij")
        if row["contrast_step"]:
            a = row["foreground_angle"]
            signed = x*np.cos(a)+y*np.sin(a)-row["foreground_shift"]
            gain = .48+.52*torch.sigmoid(signed/3)
            carrier = carrier*gain
        intact = captures[2]+carrier
        return (intact,*captures[1:]),torch.ones_like(gap),carrier
    return captures,gap,carrier


def run():
    predecessor = reference(CURVE/"plan.json")
    first = read_json(checked(predecessor))
    last = read_json(checked(first["preceding"]))
    grouped = read_json(checked(last["preceding"]))
    outer = read_json(checked(grouped["comparison"]))
    gap = read_json(checked(outer["prior"]))
    old = read_json(checked(gap["exclusion"]))
    repeat = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    cohort = read_json(checked(last["cohort"]))
    used = {s["source"]["id"]for s in [*first["sources"],*last["sources"],*grouped["sources"],*outer["sources"],*gap["sources"],*old["heldout_rows"],*repeat["rows"]]}
    sources = [s for s in cohort["source_metadata"]if s["split"]=="val" and s["bin_factor"]==4
               and min(s["shape"][:2])>=512 and np.prod(s["shape"][:2])<=4_000_000 and s["id"] not in used]
    ranked = sorted(sources,key=lambda r:hashlib.sha256(f'{SEED}/{r["id"]}'.encode()).hexdigest())
    fields = geometry.fields
    fields.ROOT=ROOT
    fields.SEED=SEED
    fields.clean_targets=clean_targets
    chosen = []
    for i,photo in enumerate(ranked[:COUNT]):
        box, = scene_crop_boxes(photo["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"target"))
        layout = fields.draw(i)
        k = ((-1)**(i//2))*(.000037+i*.00000095) if i%4!=0 else 0.
        shape = "continuous" if i//2%2 else "broken"
        layout.update({"strong_tangential_curvature_cycles_per_px2":-.66*k,
                       "weak_tangential_curvature_cycles_per_px2":k,
                       "support":shape,"contrast_step":bool(shape=="continuous" and i%2),
                       "gap_radius":min(layout["gap_radius"],17) if i%2 else layout["gap_radius"]})
        chosen.append(fields.row_for(photo,i,SEED)|{"box":box,"layout":layout})
    assert len({r["source"]["id"]for r in chosen})==COUNT
    write_json(ROOT/"plan.json",{
        **{k:first[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"curve_reference":predecessor,"geometry_code":reference(LAST/"prepare.py"),
        "sources":chosen,"seed":SEED,"fit_indices":[],"test_indices":list(range(COUNT)),
        "scope":"24 unused photos, 12 continuous and 12 broken weak carriers. Six continuous roles have a real contrast change without a gap. Half of the broken regions are narrow. Strong-only, outside-only and exact-flat controls share the physical capture scheme."
    })
    fields.construct()


if __name__=="__main__":
    run()
