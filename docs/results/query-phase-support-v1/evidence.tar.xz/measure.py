"""Score support changes and strength-matched weaker-carrier controls."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from restore_panel import ROOT,CURVE,observations
from score_panel import luma

CROP = np.s_[...,64:192,64:192]
ARMS = ("baseline","wide","compact","deficit","uniform-compact","uniform-deficit")
MISSING = ("added_gap","absolute_gap","false_gap_projection","gap_pair_RMS")


def load(mode):
    stamp = reference(ROOT/f"restoration-{mode}.json")
    result = read_json(checked(stamp))
    choice = read_json(checked(result["forecasts"]))
    material = read_json(checked(choice["observations"]))
    plan = read_json(checked(material["plan"]))
    rows = []
    for item,decision in zip(result["rows"],choice["rows"],strict=True):
        i = item["index"]
        record = material["rows"][i]
        source = plan["sources"][i]
        assert i==record["index"]==source["index"]==decision["index"]
        camera = observations(record)
        with np.load(checked(item["output"]),allow_pickle=False)as f:
            predictions = {k:luma(f[k],camera)for k in ("baseline","strong","weak","wide","compact","deficit")}
        gold = luma(camera["target"],camera)
        keep = camera["region"][CROP]==1
        gap = camera["region"][CROP]==0
        born = gold[0,0]-gold[0,1]
        assert keep.any()
        if gap.any():
            np.testing.assert_array_equal(gold[0,0][gap],gold[0,1][gap])
        assert np.array_equal(gold[0,3],np.full_like(gold[0,3],gold[0,3,0,0]))
        nominal = camera["weak_linear_nominal"][CROP]
        correction = np.sum(nominal[keep]*born[keep])/np.sum(nominal[keep]**2)
        rows.append({"index":i,"source":source,"decision":decision,"raw":record,"prediction":item,
                     "restored":predictions,"gold":gold,"nominal":nominal*correction,
                     "intact":keep,"gap":gap,"weak":born})
    return stamp,rows


def rms(v):
    return float(np.sqrt(np.mean(v.reshape(v.shape[0],-1)**2,axis=1)).mean()*65535)


def project(image,template):
    return 100*np.sum(image*template[None],axis=1)/np.sum(template*template)


def lift(row,kind,strength,uniform):
    fields = row["restored"]
    if kind=="baseline":
        return np.zeros_like(fields["baseline"])
    if kind.startswith("uniform-"):
        return strength*(fields["strong"]+uniform[kind]*fields["weak"])
    return strength*fields[kind]


def metrics(row,kind,strength,uniform):
    estimate = lift(row,kind,strength,uniform)
    result = row["restored"]["baseline"]+estimate
    target = row["gold"]
    inside,gap,truth = row["intact"],row["gap"],row["weak"]
    pair = result[:,0]-result[:,1]
    saved = {
        "intact_projection":float(project(pair[:,inside],truth[inside]).mean()),
        "intact_error":rms((pair-truth)[:,inside]),
        "added_flat":rms(estimate[:,3]),
        "absolute_flat":rms(result[:,3]-target[:,3]),
        "outside_false":float(np.abs(project((result[:,1]-target[:,1]).reshape(2,-1),row["nominal"].ravel())).mean()),
    }
    if np.any(gap):
        saved.update({
            "added_gap":rms(estimate[:,0][:,gap]),
            "absolute_gap":rms((result[:,0]-target[:,0])[:,gap]),
            "false_gap_projection":float(np.abs(project(pair[:,gap],row["nominal"][gap])).mean()),
            "gap_pair_RMS":rms(pair[:,gap]),
        })
    return saved


def score(rows,strength,uniform):
    return [{"i":r["index"],"id":r["source"]["source"]["id"],"layout":r["source"]["layout"],
             "has_gap":bool(np.any(r["gap"])),
             "metrics":{k:metrics(r,k,strength,uniform)for k in ARMS}}for r in rows]


def reduce(rows):
    random = np.random.default_rng(689124)
    pair = (("compact","wide"),("deficit","wide"),("compact","uniform-compact"),
            ("deficit","uniform-deficit"),("deficit","compact"),("deficit","baseline"))
    table = {}
    for metric in rows[0]["metrics"]["baseline"]:
        vectors = {k:np.array([r["metrics"][k][metric]for r in rows])for k in ARMS}
        support = random.integers(len(rows),size=(10000,len(rows)))
        uncertainty = {}
        for a,b in pair:
            d = vectors[a]-vectors[b]
            lo,hi = np.quantile(d[support].mean(-1),(.025,.975))
            uncertainty[f"{a}_vs_{b}"] = [float(d.mean()),float(lo),float(hi)]
        table[metric] = {"means":{k:float(v.mean())for k,v in vectors.items()},"paired_delta_95pct":uncertainty}
    return table


def analyze():
    prior = reference(CURVE/"fallback-scores.json")
    fixed = read_json(checked(prior))
    strength = fixed["scales"]["fallback-curved"]
    baseline,calib = load("fit")
    evaluation,actual = load("fresh")
    saved = {}
    for method in ("wide","compact","deficit"):
        amps = [
            rms((r["restored"][method]-r["restored"]["strong"])[:,0][:,r["intact"]])
            for r in calib
        ]
        saved[method] = float(np.mean(amps))
    uniform = {f"uniform-{k}":saved[k]/saved["wide"] for k in ("compact","deficit")}
    rows = score(actual,strength,uniform)
    first = [r for r in rows if r["has_gap"]]
    second = [r for r in rows if not r["has_gap"]]
    assert len(first)==len(second)==12
    write_json(ROOT/"scores.json",{"driver":reference(__file__),"previous_strength":prior,"fit":baseline,"fresh":evaluation,
        "scale":strength,"uniform_weak_factors":uniform,"calibration_intact_weak_correction_DN16":saved,
        "fresh_rows":rows,"nominal_bound_outputs":reference(ROOT/"forecasts-fresh.json"),
        "broken":reduce(first),"continuous":reduce(second),
        "contrast_step_continuous":reduce([r for r in second if r["layout"]["contrast_step"]]),
        "uniform_continuous":reduce([r for r in second if not r["layout"]["contrast_step"]])})
    print(strength,uniform,flush=True)


def native():
    torch.set_num_threads(2)
    receipt = reference(ROOT/"scores.json")
    score = read_json(checked(receipt))
    _,records = load("fresh")
    source_type = (
        next(r for r in records if r["gap"].any()and r["decision"]["trials"][0]["geometry"]),
        next(r for r in records if not r["gap"].any()and r["source"]["layout"]["contrast_step"]and r["decision"]["trials"][0]["geometry"]),
    )
    out = ROOT/"native"
    out.mkdir(exist_ok=True)
    items = []
    for row in source_type:
        i = row["index"]
        record = row["raw"]
        data = observations(record)
        with np.load(checked(row["prediction"]["output"]),allow_pickle=False)as f:
            origin = f["baseline"][0]
            stage = {
                n:origin+score["scale"]*f[n][0]for n in ("wide","compact","deficit")
            }|{
                n:origin+score["scale"]*(f["strong"][0]+factor*f["weak"][0])
                for n,factor in score["uniform_weak_factors"].items()
            }
        noisy = malvar(torch.from_numpy(data["packed"][0]),torch.from_numpy(data["colors"][0])).numpy()
        rgb = stage|{"baseline":origin,"noisy":noisy,"GT":data["target"][0]}
        supervision = {k:data[k][0]for k in ("wb","matrix")}
        display_views = {k:np.rint(display(v,supervision,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
                         for k,v in rgb.items()}
        for label,role in (("present",0),("outside-only",1),("quiet-query",3)):
            sets = [("all",(*ARMS,"GT"))]
            if role==0:
                sets.append(("triplet",("noisy","deficit","GT")))
            for scope,columns in sets:
                file = out/f"{i:03d}-{label}-{scope}.png"
                Image.fromarray(np.concatenate([display_views[k][role]for k in columns],axis=1)).save(file,optimize=True)
                items.append({"image":reference(file),"index":i,"native_ROI":[48,48,160,160],"order":columns,
                    "role":label,"capture":record,"prediction":row["prediction"],"photo":row["source"]["source"],
                    "source_box":row["source"]["box"],"layout":row["source"]["layout"],
                    "camera_profile":{"shot":.00128,"read":6.5536e-6,"exposure":.33},
                    "CFA":row["source"]["camera"]["pattern"],"repeat":0,"display_exposure":2})
    write_json(out/"manifest.json",{
        "driver":reference(__file__),"score":receipt,"checkpoint":read_json(checked(score["fresh"]))["checkpoint"],
        "display":"Identical camera WB/matrix, exposure ×2 and clipped sRGB8.",
        "scope":"First broken geometry and first continuous contrast-step geometry with any at-draw-zero pair nomination. Selection examines no scores.",
        "rows":items})


if __name__=="__main__":
    analyze()
    native()
