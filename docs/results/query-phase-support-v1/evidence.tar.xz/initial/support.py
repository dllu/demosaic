"""Check a deficit of phase-aligned amplitude in a small RAW neighborhood."""
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
CURVE = ROOT.parent/"query-phase-curvature-v1"
sys.path.insert(0,str(CURVE))
import curvature
from curvature import anchored,local,subsets,fit,torch_phase

METHODS = ("wide","compact","deficit")


def weaker(packed,variance,colors,shape):
    if not shape:
        return None
    with anchored((0,0)):
        train,_ = subsets(packed,variance,colors)
    beta,_,_ = fit(train,shape)
    power = np.sum(beta.reshape(2,2)**2,axis=-1).tolist()
    return {"index":int(np.argmin(power)),"squared_reserve_coefficients":power}


def small_fits(packed,variance,colors,parent,signal,competitor):
    device = packed.device
    green = torch.where(colors[0]==1)[0]
    row,col = torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    Y = (2*row+green[:,None,None]//2).flatten()
    X = (2*col+green[:,None,None]%2).flatten()
    split = torch.from_numpy(local.partition()).to(device).expand(2,-1,-1).flatten()
    sign = torch.stack((torch.ones_like(row),-torch.ones_like(row))).flatten()
    sensor = torch.cat((packed[:,green].flatten(1),parent[:,1,Y,X])).double()
    variance = variance[:,green].flatten(1).repeat(2,1).double()
    Y,X = Y.double(),X.double()
    y,x = (Y-127.5)/128,(X-127.5)/128
    native = (torch.arange(16,device=device,dtype=torch.float64)*16+7.5).clamp(54,201)
    cy,cx = torch.meshgrid(native,native,indexing="ij")
    sq = (X[None]-cx.reshape(-1,1)).square()+(Y[None]-cy.reshape(-1,1)).square()
    radius = 13**2
    usable = (x.abs()<=.70)&(y.abs()<=.70)
    aperture = {
        "inner":(-sq/(2*5.5**2)).exp()*usable*(sq<radius),
        "ring":(-sq/(2*16**2)).exp()*usable*(sq>=radius)*(sq<30**2),
    }
    d = torch_phase(X,Y,competitor)
    t = torch_phase(X,Y,signal)
    c,s = d.cos(),d.sin()
    basis = torch.stack((torch.ones_like(x),x,y,sign,sign*x,sign*y,c,s,c*x,c*y,s*x,s*y,t.cos(),t.sin()),dim=-1)
    groups = [split==k for k in (2,3)]
    return {name:[local.solve(basis[g],sensor[:,g],variance[:,g],w[:,g])for g in groups]
            for name,w in aperture.items()}


def projected(pair,direction,n):
    beta,variance = pair
    estimate = (beta[:n]*direction).sum(-1)
    projected_variance = torch.einsum("bgi,bgij,bgj->bg",direction,variance[:n],direction).clamp_min(1e-20)
    return estimate,projected_variance


def support_mask(fit,small,rows):
    inside,outside,signals = [],[],[]
    for inner,ring,far in zip(small["inner"],small["ring"],fit["exterior"],strict=True):
        unit,_ = local.unit(far[0][:rows])
        small_value,small_var = projected(inner,unit,rows)
        ring_value,ring_var = projected(ring,unit,rows)
        inside.append(small_value)
        outside.append(ring_value)
        signals.append((ring_value-small_value)/(small_var+ring_var).sqrt())
    present = (outside[0]>0)&(outside[1]>0)
    concordant = (signals[0]>0)&(signals[1]>0)&present
    detect = ((signals[0]+signals[1])*(.5**.5)-.9).div(1.4).clamp(0,1)*concordant
    relationship = ((inside[0]+inside[1]).clamp_min(0)/(outside[0]+outside[1]).clamp_min(1e-12)).clamp(0,1)
    return 1-detect*(1-relationship)


def estimate(args,parent,shape,weak):
    if not shape:
        empty = torch.zeros_like(parent)
        return {n:empty for n in ("strong","weak",*METHODS)}
    assert weak in (0,1)
    packed,variance,colors,wb,matrix = args
    with anchored((0,0)):
        gains = torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
        gains = gains/gains[:,1:2]
        render_gain = gains[:,:,None,None]
        use_curve = any(d[2] for d in shape)
        old_fit = curvature.local_fits if use_curve else local.delivery_fits
        old_lift = curvature.lift if use_curve else local.lift
        bands = []
        for i in (0,1):
            shape_i,shape_j = shape[i],shape[1-i]
            target,neighbor = (shape_i,shape_j)if use_curve else (shape_i[:2],shape_j[:2])
            fixed = old_fit(packed,variance,colors,parent,target,neighbor)
            coeff = local.amplitude("exterior",fixed,packed.shape[0])
            baseline = (old_lift(coeff,target)[:,None]*render_gain).to(parent.dtype)
            bands.append(baseline)
            if i==weak:
                narrow = small_fits(packed,variance,colors,parent,shape_i,shape_j)
                aperture = fixed|{"local":narrow["inner"]}
                compact_coeff = local.amplitude("exterior",aperture,packed.shape[0])
                cap = support_mask(fixed,narrow,packed.shape[0])
                compact = (old_lift(compact_coeff,target)[:,None]*render_gain).to(parent.dtype)
                deficit = (old_lift(coeff*cap[...,None],target)[:,None]*render_gain).to(parent.dtype)
        strong,weak_band = bands[1-weak],bands[weak]
        return {"strong":strong,"weak":weak_band,"wide":strong+weak_band,"compact":strong+compact,"deficit":strong+deficit}
