"""Publish source-bound measurements and all reviewed native crops."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path("docs/results/query-phase-support-v1")
IMAGES = Path("docs/images/query-phase-support-v1")


def keep_image(row,group,note):
    source = checked(row["image"])
    destination = IMAGES/group/source.name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)
    binding = reference(destination)
    assert binding["sha256"]==row["image"]["sha256"]
    boxes = ([p["png_xywh"]for p in row["panels"]]if group=="standing"
             else [[160*j,0,160,160]for j in range(len(row["order"]))])
    with Image.open(destination)as png:
        for x,y,w,h in boxes:
            assert w==h==160 and x+w<=png.width and y+h<=png.height
        png.verify()
    row["image"] = {"path":str(destination),"sha256":binding["sha256"]}
    row["native_viewing"] = note


def main():
    RESULT.mkdir(exist_ok=True)
    scores = reference(ROOT/"scores.json")
    values = read_json(checked(scores))
    audit = read_json(ROOT/"audit.json")
    exact = read_json(ROOT/"native/manifest.json")
    cameras = read_json(ROOT/"standing/manifest.json")
    assert audit["score"]==scores==exact["score"]
    assert values["scale"]==cameras["scale"] and exact["checkpoint"]==cameras["checkpoint"]
    groups = {"exact":exact,"standing":cameras}
    evidence = {
        ("exact",0,"present"):"The leading diagonal is visible after denoising. Fine crossings stay subdued near the edges of the true gap.",
        ("exact",0,"outside-only"):"The stronger diagonal remains visible over the lettering with little new cross-direction texture.",
        ("exact",0,"quiet-query"):"All corrected crops show the same smooth red core.",
        ("exact",7,"present"):"The continuous weak family is clearer in the exact target. All corrections preserve the underlying lettering.",
        ("exact",7,"outside-only"):"The small diagonal structure is similar across corrections.",
        ("exact",7,"quiet-query"):"The quiet crop stays smooth across all corrected views.",
    }
    for row in exact["rows"]:
        keep_image(row,"exact",evidence[("exact",row["index"],row["role"])])
    for row in cameras["rows"]:
        ident = row["id"]
        if ident.endswith("mesh-right"):
            note = "The backup shows both directions. Narrow support gives uneven crossings and a softer weaker family in parts. The deficit check looks like the backup. Reference diamonds remain clearer throughout."
        elif ident.endswith("mesh-left"):
            note = "All added paths return the parent. Fine crossings visible in the ISO100 references remain weak."
        elif "chain-link-fence" in ident:
            note = "The coarse lattice remains visible across all paths. The local deficit check has little visible effect."
        elif "overcast-sky" in ident:
            note = "The smooth sky equals the Corpus 100k parent."
        else:
            note = "The corrections equal the parent, with some fine structure still soft relative to the independent reference."
        keep_image(row,"standing",note)
    assert all(len(v["rows"])==8 for v in groups.values())
    manifest = IMAGES/"manifest.json"
    write_json(manifest,groups|{"actual_native_viewing_complete":True})
    archive = RESULT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        names = (
            "prepare.py","support.py","forecasts.py","restore_panel.py","measure.py","cameras.py","audit.py","publish.py",
            "plan.json","fields.json","forecasts-fit.json","forecasts-fresh.json","forecasts-standing.json",
            "restoration-fit.json","restoration-fresh.json","scores.json","audit.json","prepare.log","forecasts.log",
            "restore-fit.log","restore-fresh.log","measure.log","cameras.log","audit.log","tests.log",
            "native/manifest.json","standing/manifest.json",
        )
        for name in names:
            f.add(ROOT/name,arcname=name)
        for file in sorted((ROOT/"initial").iterdir()):
            f.add(file,arcname=f"initial/{file.name}")
    fields = ("scale","uniform_weak_factors","calibration_intact_weak_correction_DN16","broken",
              "continuous","contrast_step_continuous","uniform_continuous")
    write_json(RESULT/"publication.json",{
        "experiment":"query-phase-support-v1","training_performed":False,"numeric_evaluation_complete":True,
        "actual_native_viewing_complete":True,"parent":exact["checkpoint"],
        "max_rms_difference_to_wide_for_standing_GFX_DN16":{
            key:max(r["camera_metrics"][key]["camera_RGB_RMS_to_wide_DN16"]for r in cameras["rows"])
            for key in cameras["rows"][0]["camera_metrics"]
        },
        "values":{name:values[name]for name in fields},"audit":audit,
        "manifest":reference(manifest),"archive":reference(archive),
        "scope":"24 held-out constructed weak-carrier scenes and both standing GFX families with both cab priors. No comparable full427 or camera-panel score.",
    })


if __name__=="__main__":
    main()
