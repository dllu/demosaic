"""Check source exclusions, carrier identity and split-sample reproducibility."""
from itertools import permutations
import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from restore_panel import ARGS,observations
from support import ROOT,anchored,estimate,local,weaker


def identity(shape,layout):
    targets = [np.asarray(layout[f"{k}_frequency_xy"])for k in ("strong","weak")]
    hints = [np.asarray(p[:2])for p in shape]
    options = []
    for perm in permutations(range(2)):
        distance = [min(np.linalg.norm(hints[perm[j]]+v),np.linalg.norm(hints[perm[j]]-v))
                    for j,v in enumerate(targets)]
        options.append((sum(distance),max(distance),perm[1]))
    _,maximum,weak = min(options)
    return weak if maximum<=3/256 else None


def main():
    torch.set_num_threads(2)
    selected = reference(ROOT/"forecasts-fresh.json")
    solved = reference(ROOT/"restoration-fresh.json")
    draws = read_json(checked(selected))
    runs = read_json(checked(solved))
    assert runs["forecasts"]==selected
    fields = read_json(checked(draws["observations"]))
    plan = read_json(checked(fields["plan"]))
    training = read_json(ROOT.parent/"scene-full-epoch-v1/plan.json")["train_manifest"]
    with checked(training).open()as stream:
        ids = {json.loads(r)["id"]for r in stream}
    assert len(ids)==90692
    assert not ids.intersection(r["source"]["id"]for r in plan["sources"])
    with anchored((0,0)):
        partition = local.partition()
    made = np.isin(partition,(0,1))
    random = np.random.default_rng(106237)
    access,recognition = [],[]
    for chosen,found in zip(draws["rows"],runs["rows"],strict=True):
        i = chosen["index"]
        source = plan["sources"][i]
        for case in (q for q in chosen["trials"]if q["role"]=="present"and q["geometry"]):
            rep = case["repeat"]
            shape,index = case["geometry"],case["weaker"]["index"]
            actual = identity(shape,source["layout"])
            recognition.append({"index":i,"repeat":rep,"geometry_matches_both":actual is not None,
                                "reserve_selected_weak":index,"exact_weak":actual,
                                "layout":source["layout"]["support"]})
            if len(access)>=6 or actual is None:
                continue
            raw = observations(fields["rows"][i])
            arg = [raw[k][rep,0:1].copy()for k in ARGS]
            baseline = [v.copy()for v in arg]
            for value in arg[:2]:
                value[...,~made] = random.uniform(.05,.8,(1,4,int((~made).sum())))
            assert weaker(arg[0][0],arg[1][0],arg[2][0],shape)==case["weaker"]
            with np.load(checked(found["output"]),allow_pickle=False)as arrays:
                parent = torch.from_numpy(arrays["baseline"][rep,0:1].copy())
                cpu = estimate([torch.from_numpy(t)for t in baseline],parent,shape,index)
                altered = [v.copy()for v in baseline]
                for value in altered[:2]:
                    value[...,made] = random.uniform(.05,.8,(1,4,int(made.sum())))
                replacement = estimate([torch.from_numpy(t)for t in altered],parent,shape,index)
                values = {}
                for key,out in cpu.items():
                    np.testing.assert_array_equal(out.numpy(),replacement[key].numpy())
                    np.testing.assert_allclose(out.numpy(),arrays[key][rep,0:1],rtol=0,atol=4e-8)
                    values[key] = float(np.abs(out.numpy()-arrays[key][rep,0:1]).max())
                access.append({"index":i,"repeat":rep,"CPU_GPU_max_abs":values})
    assert len(access)==6
    score = reference(ROOT/"scores.json")
    flat = read_json(checked(score))
    for group in ("continuous","broken"):
        assert all(v==0 for v in flat[group]["added_flat"]["means"].values())
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"training_manifest":training,
              "training_rows":len(ids),"distinct_heldout_photos":len(plan["sources"]),"training_overlap":0,
              "plan":fields["plan"],"forecasts":selected,"predictions":solved,"score":score,
              "reserve_choice_checks":access,"nominal_geometry_identity":recognition,
              "exact_flat_added_RMS_DN16":0.,
              "scope":"Q0 weak identity is invariant to replacing Q2/Q3. Q2/Q3 delivery is invariant to replacing Q0/Q1 at fixed full-input parent and nominated geometry, for all five outputs."})
    print(len(access),len(recognition),sum(q["geometry_matches_both"]for q in recognition),
          sum(q["exact_weak"]==q["reserve_selected_weak"]for q in recognition),flush=True)


if __name__=="__main__":
    main()
