"""Render the repeat where the checked harmonic changes the exact output."""

import numpy as np
from PIL import Image

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from review import ROI,ROOT,get,transform


def main():
    stamp=reference(ROOT/"restoration.json")
    results=read_json(checked(stamp))
    captures=read_json(checked(results["sources"]))
    plan=read_json(checked(captures["plan"]))
    active=[(row,repeat)for row in results["rows"] for repeat in range(2)
            if row["decisions"][repeat*4]["matching"]["state"]=="donor-and-checked-bands"]
    assert len(active)==1
    row,repeat=active[0]
    series,source=get(row)
    series["target"]=source["target"]
    values=("local","donor","composed","rotated","target")
    images=[np.rint(display(series[v][repeat][ROI],transform(source,repeat),exposure=2)[0]*255)
             .astype(np.uint8).transpose(1,2,0)for v in values]
    path=ROOT/"native/010-repeat1-bands.png"
    Image.fromarray(np.concatenate(images,axis=1)).save(path,optimize=True)
    material=plan["sources"][row["index"]]
    write_json(ROOT/"active-native.json",{"image":reference(path),"restoration":stamp,"driver":reference(__file__),
               "order":values,"index":row["index"],"repeat":repeat,
               "source":material["source"],"source_box":material["box"],"camera_pattern":material["camera"]["pattern"],
               "shot_read_exposure":plan["profile"],"query_roi":[48,48,160,160],"display_exposure":2})


if __name__=="__main__":
    main()
