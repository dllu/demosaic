"""Freeze matched and rotated exterior interventions on weak exact fields."""
from dataclasses import replace
import hashlib
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
LAST=ROOT.parent/"query-checked-junctions-v1"
spec=importlib.util.spec_from_file_location("earlier_fields",LAST/"prepare.py")
earlier=importlib.util.module_from_spec(spec)
spec.loader.exec_module(earlier)
build=earlier.previous.before.geometry.fields
SEED=80637412165
TYPES=("continuous","contrast","local-gap")


def targets(photo,g):
    axis=torch.arange(512)-255.5
    y,x=torch.meshgrid(axis,axis,indexing="ij")
    area=torch.maximum(x.abs(),y.abs())
    outer=((area-132)/27).clamp(0,1)
    base=.070+.56*F.avg_pool2d(photo[None],11,stride=1,padding=5,count_include_pad=False)[0]
    edge=x*math.cos(g["foreground_angle"])+y*math.sin(g["foreground_angle"])-g["foreground_shift"]
    if g["step"]:
        base=base+torch.tensor(g["foreground_height"])[:,None,None]*torch.sigmoid(edge/1.14)
    gap_angle=g["gap_angle"]
    u=x*math.cos(gap_angle)+y*math.sin(gap_angle)
    v=-x*math.sin(gap_angle)+y*math.cos(gap_angle)
    if g["condition"]=="local-gap":
        footprint=((torch.hypot((u-17)/25,v/47)-1)*4).clamp(0,1)
    elif g["condition"]=="contrast":
        footprint=.30+.70*torch.sigmoid(edge/2)
    else:
        footprint=torch.ones_like(x)
    mask=torch.maximum(footprint,((area-104)/18).clamp(0,1))
    outside=((area-109)/18).clamp(0,1)
    flat=((128-area)/51).clamp(0,1)

    def carriers(rotation):
        a,b=math.cos(rotation),math.sin(rotation)
        values=[]
        for token in ("strong","weak"):
            fx,fy=g[token+"_frequency_xy"]
            values.append(2*math.pi*((a*fx-b*fy)*x+(b*fx+a*fy)*y)+g[token+"_phase"])
        return [phase.cos() for phase in values]

    a,b=carriers(0)
    c,d=carriers(.59)
    local_front=g["strong_amplitude"]*a
    local_back=g["weak_amplitude"]*b
    interaction=g["junction_amplitude"]*a*b
    clean_present=base+local_front+(local_back+interaction)*mask
    clean_absent=base+local_front+(local_back+interaction)*outside
    quiet=clean_present[:,198:314,198:314].mean((-2,-1),keepdim=True)
    clean_flat=torch.where(flat==1,quiet,torch.lerp(clean_present,quiet,flat))
    rows=(clean_present,clean_absent,base+local_front,clean_flat)
    matching=.025*a+.025*b
    rotated=.025*c+.025*d
    primary=tuple((1-outer)*q+outer*(base+matching) for q in rows)
    contrast=base+(1-outer)*matching+outer*rotated
    assert all(float(q.min())>0 and float(q.max())<1 for q in (*primary,contrast))
    return primary,contrast,mask


def source_plan():
    previous=reference(LAST/"plan.json")
    old=read_json(checked(previous))
    previous_ids={q["source"]["id"] for q in old["sources"]}
    used=set(previous_ids)
    for proof in old["excluded"]:
        material=read_json(checked(proof))
        used.update(q["source"]["id"] for q in material.get("sources",material.get("heldout_rows",[])))
    repeat=reference(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    used.update(q["source"]["id"] for q in read_json(checked(repeat))["rows"])
    eligible=[q for q in read_json(checked(old["cohort"]))["source_metadata"]
              if q["bin_factor"]==4 and q["split"]=="val" and min(q["shape"][:2])>=512 and q["id"] not in used]

    def rank(source):
        return hashlib.sha256(f"{SEED}/{source['id']}".encode()).hexdigest()

    sources=sorted(eligible,key=rank)[:2]+sorted([r["source"]for r in old["sources"]],key=rank)[:10]
    assert len(sources)==12 and len({r["id"]for r in sources})==12
    train=read_json(ROOT.parent/"scene-full-epoch-v1/plan.json")["train_manifest"]
    with checked(train).open() as f:
        assert not set(r["id"] for r in sources) & {json.loads(p)["id"] for p in f}
    build.SEED=SEED
    records=[]
    for i,s in enumerate(sources):
        crop,=scene_crop_boxes(s["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"fresh box"))
        g=build.draw(i)
        generator=np.random.default_rng(scene_seed(SEED,i,"weaker native query"))
        for name,low,high in (("strong",.086,.119),("weak",.103,.148)):
            f=np.array(g[name+"_frequency_xy"])
            g[name+"_frequency_xy"]=(f*generator.uniform(low,high)/np.linalg.norm(f)).tolist()
        g.update({"condition":TYPES[i%3],"strong_amplitude":float(generator.uniform(.0055,.012)),
                  "weak_amplitude":float(generator.uniform(.0028,.0074)),
                  "junction_amplitude":float(generator.uniform(.0046,.0078))*(-1 if i%2 else 1)})
        records.append(build.row_for(s,i,SEED)|{"box":crop,"layout":g,"previous_photo":s["id"] in previous_ids})
    write_json(ROOT/"plan.json",{"previous":previous,"driver":reference(__file__),"train":train,
        "seed":SEED,"base":old["base"],"profile":old["profile"],"roles":old["roles"],
        "query_box":old["query_box"],"sources":records,"previous_photo_replay_count":10,"new_photo_count":2,
        "edits":"Only samples in the donor region, beyond the query and its 32-native-pixel margin, are replaced with the rotated exposure. All native query samples and its local fit inputs are kept byte-identical."})


def collect():
    torch.set_num_threads(2)
    stamp=reference(ROOT/"plan.json")
    plan=read_json(checked(stamp))
    path=ROOT/"fields"
    path.mkdir()
    saved=[]
    for row in plan["sources"]:
        i=row["index"]
        canonical,rotated,footprint=targets(build.decode(row["source"],row["box"]),row["layout"])
        camera=replace(sample_scene_recipe(SEED),**(row["camera"]|plan["profile"]))
        seeds=[[scene_seed(SEED,i,f"physical draw {r}/{role}")for role in plan["roles"]]for r in range(2)]
        draws=[[observe_scene(t,replace(camera,noise_seed=s))for t,s in zip(canonical,group,strict=True)]for group in seeds]
        base={k:torch.stack([torch.stack([getattr(o,k)for o in group])for group in draws]).numpy()
              for k in (*build.ARGS,"target")}
        swap_seed=[scene_seed(SEED,i,f"rotated exterior {r}") for r in range(2)]
        swaps=[observe_scene(rotated,replace(camera,noise_seed=s))for s in swap_seed]
        row_coord=np.arange(256)*2+.5-255.5
        outside=np.maximum(abs(row_coord[:,None]),abs(row_coord[None,:]))>=160
        for k in ("packed","variance"):
            other=base[k].copy()
            for j,q in enumerate(swaps):
                other[j,...,outside]=np.broadcast_to(getattr(q,k).numpy()[:,outside].T[:,None,:],other[j,...,outside].shape)
            base["rotated_"+k]=other
            np.testing.assert_array_equal(base[k][...,48:208,48:208],other[...,48:208,48:208])
        base["region"]=footprint.numpy()[128:384,128:384]
        with (result:=path/f"{i:03d}.npz").open("xb") as f:
            np.savez(f,**base)
        saved.append({"index":i,"capture":reference(result),"seeds":seeds,"rotated_exterior_seeds":swap_seed,
                     "fingerprints":{k:fingerprint(v)for k,v in base.items()}})
        print(i,row["layout"]["condition"],flush=True)
    write_json(ROOT/"fields.json",{"plan":stamp,"rows":saved})


if __name__=="__main__":
    source_plan()
    collect()
