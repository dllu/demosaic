"""Run exact matched-versus-rotated exterior tests with an identical neural query."""
from concurrent.futures import ThreadPoolExecutor
import json
import sys
import time

import numpy as np
import torch

from compose import GAIN,LAST,ROOT,composed,render
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32

sys.path.insert(0,str(ROOT.parent/"query-phase-support-v1"))
from forecasts import nominate
from model_delivery import curvature,select
from run_restore import ARGS,setup_models


def donor_trials(job):
    repeat,role,local,predicted,inputs,box,noise=job
    if local:
        return [predicted,predicted,predicted],{"state":"existing-query-pair"}, {"state":"existing-query-pair"}
    parent=np.zeros((3,512,512),predicted.dtype)
    parent[...,96:416,96:416]=predicted
    wb,mat=inputs["wb"][repeat,role],inputs["matrix"][repeat,role]
    c=inputs["colors"][repeat,role]
    results=[]
    records=[]
    for prefix in ("","rotated_"):
        pair=[inputs[k][repeat,role]for k in (prefix+"packed",prefix+"variance")]
        d,adjusted,state=composed(*pair,c,parent,box,noise,wb,mat,80)
        results.append((d,adjusted))
        records.append(state)
    return [*results[0],results[1][1]],*records


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    cohort=reference(ROOT/"fields.json")
    source=read_json(checked(cohort))
    plan=read_json(checked(source["plan"]))
    out=ROOT/"outputs"
    out.mkdir()
    started=time.monotonic()
    rows=[]
    nt=plan["profile"]
    patch=np.s_[...,64:192,64:192]
    padded=np.s_[...,48:208,48:208]
    with ieee_fp32(),ThreadPoolExecutor(3)as pool:
        net=setup_models({"models":{"Corpus100k":plan["base"]}})["Corpus100k"]
        net.set_noise(nt["shot"],nt["read"])
        for row in source["rows"]:
            i=row["index"]
            with np.load(checked(row["capture"]),allow_pickle=False)as file:
                data={k:file[k]for k in (*ARGS,"rotated_packed","rotated_variance")}
            for k in ("packed","variance"):
                np.testing.assert_array_equal(data[k][padded],data["rotated_"+k][padded])
            args=[torch.from_numpy(v.reshape(-1,*v.shape[2:])).cuda()
                  for k in ARGS for v in (data[k][padded].copy() if k in ("packed","variance")else data[k],)]
            args[:2]=[x.contiguous(memory_format=torch.channels_last)for x in args[:2]]
            full=net(*args)
            parent=full[...,32:288,32:288].contiguous()
            matched=parent.cpu().numpy().reshape(2,4,3,256,256)
            base=matched.copy()
            bank=nominate((row,None))
            tasks=[]
            for j,case in enumerate(bank["trials"]):
                repeat,role=divmod(j,4)
                g=case["geometry"]
                if g:
                    params=[a[j:j+1,...,16:144,16:144] if ii<2 else a[j:j+1] for ii,a in enumerate(args)]
                    wide=parent[j:j+1]+GAIN*curvature.deliver(params,parent[j:j+1],g)
                    camera=data["colors"][repeat,role],data["wb"][repeat,role],data["matrix"][repeat,role]
                    raw=data["packed"][patch][repeat,role]
                    selected=select(raw,camera[0],nt,g)
                    previous=wide[0].cpu().numpy()
                    base[repeat,role]=previous+GAIN*render(raw,camera[0],nt,previous,*camera[1:],selected)["locked"]
                    intended=base[repeat,role]
                else:
                    intended=full[j].cpu().numpy()
                tasks.append((repeat,role,bool(g),intended,data,plan["query_box"],nt))
            results=np.empty((3,*base.shape),dtype=base.dtype)
            decisions=[]
            for j,(outputs,match,rotated)in enumerate(pool.map(donor_trials,tasks)):
                repeat,role=divmod(j,4)
                for idx,predicted in enumerate(outputs):
                    results[idx,repeat,role]=predicted
                decisions.append({"baseline":bank["trials"][j],"matching":match,"rotated":rotated})
            assert np.isfinite(results).all()
            outfile=out/f"{i:03d}.npz"
            np.savez(outfile,parent=matched,local=base,donor=results[0],composed=results[1],rotated=results[2])
            rows.append({"index":i,"input":row["capture"],"output":reference(outfile),"decisions":decisions})
            partial=out/f"{i:03d}.json"
            write_json(partial,rows[-1])
            print(i,round(time.monotonic()-started,1),
                  [(d["matching"]["state"],d["rotated"]["state"])for d in decisions],flush=True)
    write_json(ROOT/"restoration.json",{"checkpoint":plan["base"],"sources":cohort,
                    "driver":reference(__file__),"seconds":time.monotonic()-started,"rows":rows,
                    "common_parent_view_native_xywh":[96,96,320,320]})


if __name__=="__main__":
    run()
