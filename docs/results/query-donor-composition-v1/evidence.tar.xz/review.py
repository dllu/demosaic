"""Score exact native detail and the effects of changing only exterior Bayer sites."""
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
MODES=("parent","local","donor","composed","rotated")
LUMA=np.array([.2126,.7152,.0722])
CENTER=np.s_[...,64:192,64:192]
QUERY=np.s_[...,128:384,128:384]
PACKED_QUERY=np.s_[...,64:192,64:192]
ROI=np.s_[...,48:208,48:208]


def get(row):
    with np.load(checked(row["input"]),allow_pickle=False)as f:
        samples={k:f[k]for k in ("wb","matrix","target","region","packed","colors")}
    samples["target"]=samples["target"][QUERY]
    with np.load(checked(row["output"]),allow_pickle=False)as f:
        models={k:f[k]for k in MODES}
    return models,samples


def transform(samples,repeat):
    return {k:samples[k][repeat]for k in ("wb","matrix")}


def camera_luma(array,samples):
    return np.stack([np.einsum("c,bchw->bhw",LUMA,linear_rgb(x,transform(samples,r)))
                      for r,x in enumerate(array[CENTER])])


def rms(value):
    return float(np.sqrt(np.mean(value.reshape(len(value),-1)**2,axis=1)).mean()*65535)


def measurements(row,source):
    models,raw=get(row)
    data={k:camera_luma(m,raw)for k,m in models.items()}
    gt=camera_luma(raw["target"],raw)
    truth=gt[0,0]-gt[0,1]
    supported=raw["region"][CENTER]==1
    gap=raw["region"][CENTER]==0
    assert supported.any()
    np.testing.assert_array_equal(gt[0,1],gt[0,2])
    np.testing.assert_array_equal(gt[0,3],np.full((128,128),gt[0,3,0,0]))
    if gap.any():
        assert not np.any(truth[gap])
    metrics={}
    for k,p in data.items():
        delivered=p[:,0]-p[:,1]
        added=p-data["local"]
        metrics[k]={"aligned_response_pct":float((100*np.sum(delivered*truth,axis=(1,2))/np.sum(truth**2)).mean()),
                    "increment_DN16":rms(delivered-truth),"intact_increment_DN16":rms((delivered-truth)[:,supported]),
                    "truth_present_DN16":rms((p-gt)[:,0]),"quiet_added_DN16":rms(added[:,3]),
                    "outside_only_added_DN16":rms(added[:,1]),"strong_only_added_DN16":rms(added[:,2])}
        if gap.any():
            metrics[k]["within_gap_added_DN16"]=rms(added[:,0, gap])
    return {"index":row["index"],"condition":source["layout"]["condition"],"values":metrics}


def render(row,source,plan,root):
    cases,raw=get(row)
    repeat=next((i//4 for i,r in enumerate(row["decisions"]) if i%4==0
                 and r["matching"]["state"] in ("donor-only","donor-and-checked-bands")),0)
    cases.update({"noisy":malvar(torch.from_numpy(raw["packed"][repeat][PACKED_QUERY]),
                                 torch.from_numpy(raw["colors"][repeat])).numpy()[None],
                  "target":raw["target"]})
    img={k:np.rint(display(v[0 if k=="noisy"else repeat][ROI],transform(raw,repeat),exposure=2)*255)
         .astype(np.uint8).transpose(0,2,3,1) for k,v in cases.items()}
    options=(
        ("triplet",0,("noisy","composed","target")),
        ("matching",0,("parent","local","donor","composed","rotated","target")),
        ("outside-only",1,("parent","local","donor","composed","rotated","target")),
        ("quiet",3,("parent","local","donor","composed","rotated","target")),
    )
    out=[]
    for name,role,order in options:
        path=root/f"{row['index']:03d}-{name}.png"
        Image.fromarray(np.concatenate([img[k][role]for k in order],axis=1)).save(path,optimize=True)
        out.append({"image":reference(path),"role":name,"index":row["index"],"repeat":repeat,"order":order,
                     "camera_pattern":source["camera"]["pattern"],"source":source["source"],
                     "source_box":source["box"],"query_roi":[48,48,160,160],"shot_read_exposure":plan["profile"],
                     "display_exposure":2,"capture":row["input"],"prediction":row["output"]})
    return out


def main():
    torch.set_num_threads(2)
    bound=reference(ROOT/"restoration.json")
    restored=read_json(checked(bound))
    fields=read_json(checked(restored["sources"]))
    plan=read_json(checked(fields["plan"]))
    scores=[measurements(p,s)for p,s in zip(restored["rows"],plan["sources"],strict=True)]
    bootstrap=np.random.default_rng(732194)
    summary={}
    for category in ("all","continuous","contrast","local-gap"):
        group=[row["values"]for row in scores if category in ("all",row["condition"])]
        inds=bootstrap.integers(len(group),size=(10000,len(group)))
        common_keys=set.intersection(*(set(r["local"])for r in group))
        stats={}
        for key in sorted(common_keys):
            means={k:np.array([r[k][key]for r in group])for k in MODES}
            effects={}
            for first,second in (("donor","local"),("composed","local"),("composed","donor"),("rotated","local"),("composed","rotated")):
                d=means[first]-means[second]
                effects[first+"-minus-"+second]=[float(d.mean()),*np.quantile(d[inds].mean(1),(0.025,0.975)).tolist()]
            stats[key]={"mean":{k:float(m.mean())for k,m in means.items()},"photo_paired_95pct":effects}
        summary[category]=stats
    counts={}
    for n,r in enumerate(plan["roles"]):
        for context in ("matching","rotated"):
            counts[context+"/"+r]=dict(Counter(r["decisions"][j][context]["state"]
                       for r in restored["rows"] for j in (n,n+4)))
    score=ROOT/"scores.json"
    write_json(score,{"driver":reference(__file__),"restoration":bound,"summary":summary,"states":counts,"per_case":scores})
    selections=[]
    for row in restored["rows"]:
        if any(r["matching"]["state"] in ("donor-only","donor-and-checked-bands")for r in row["decisions"][::4]):
            selections.append(row)
    selected=(selections+[r for r in restored["rows"]if r not in selections])[:2]
    native=ROOT/"native"
    native.mkdir()
    boards=[record for row in selected for record in render(row,plan["sources"][row["index"]],plan,native)]
    write_json(native/"manifest.json",{"driver":reference(__file__),"score":reference(score),
               "restoration":bound,"checkpoint":restored["checkpoint"],"rows":boards,
               "selection":"First two present fields with an active exterior route. Fill from source order if fewer than two are active."})


if __name__=="__main__":
    main()
