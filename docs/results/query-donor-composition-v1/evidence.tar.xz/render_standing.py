"""Review the camera fallback with the original native display geometry."""
import sys

import numpy as np
from PIL import Image
import torch

from compose import composed,ROOT,LAST
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    source=reference(LAST/"standing/manifest.json")
    prior=read_json(checked(source))
    out=ROOT/"standing"
    out.mkdir()
    rows=[]
    for row in prior["rows"]:
        name=row["id"]
        bx,by,w,h=row["query_box"]
        roi=row["ROI"]["ROI_xywh"]
        sx,sy,cw,ch=roi
        origin=sx-bx,sy-by,cw,ch
        local_region=np.s_[...,sy-by:sy-by+ch,sx-bx:sx-bx+cw]
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            raw,var,colors,wb,mat=(f[k][0]for k in ("packed","variance","colors","wb","matrix"))
        with np.load(checked(row["prediction"]),allow_pickle=False)as f:
            previous=f["wide"]+prior["gain"]*f["locked"]
        if row["new_geometry"]["observed"]:
            donor=previous
            current=previous
            choice={"state":"existing-query-pair"}
        else:
            full=np.load(checked(row["parent"]),allow_pickle=False)[0]
            np.testing.assert_array_equal(full[...,by:by+h,bx:bx+w],previous)
            donor,current,choice=composed(raw,var,colors,full,row["query_box"],row["shot_read"],wb,mat,
                                          112 if name.startswith("mesh-")else 80)
        with Image.open(checked(row["image"])) as f:
            raster=np.asarray(f.convert("RGB"))
        panels={p["name"]:raster[y:y+h,x:x+w]for p in row["panels"]for x,y,w,h in (p["png_xywh"],)}
        old_name="Phase-locked bands"
        keep=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA",old_name)
        output=[(k,panels[k])for k in keep if k in panels]
        for label,a in (("With exterior fit",donor),("With exterior and checked bands",current)):
            rgb=np.rint(display_crop(torch.from_numpy(a[None]),torch.from_numpy(wb[None]),
                                     torch.from_numpy(mat[None]),origin,exposure=row["display_exposure"])*255).astype(np.uint8)
            output.append((label,rgb))
        output.extend((k,panels[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in panels)
        image=native_png(out/(name+".png"),output)
        cache=out/(name+".npz")
        np.savez(cache,old=previous,donor=donor,composed=current)
        def rms(a,b):
            return float(np.sqrt(np.mean((a[local_region].astype(float)-b[local_region])**2))*65535)
        result={"donor_from_previous_DN16":rms(donor,previous),"harmonics_from_donor_DN16":rms(current,donor),
                "composed_from_previous_DN16":rms(current,previous),
                "display_component_changes":int((output[-3 if "ISO100 camera JPEG" in panels else -2][1]!=panels[old_name]).sum())}
        rows.append({"id":name,"outputs":reference(cache),"image":image["image"],
                    "panels":image["panels"],"base_input":row["input"],"previous_image":row["image"],
                    "ROI":roi,"box":row["query_box"],"noise":row["shot_read"],"display_exposure":row["display_exposure"],
                    "state":choice,"results":result})
        print(name,choice["state"],result,flush=True)
    write_json(out/"manifest.json",{"driver":reference(__file__),"source":source,"checkpoint":prior["checkpoint"],"rows":rows})


if __name__=="__main__":
    run()
