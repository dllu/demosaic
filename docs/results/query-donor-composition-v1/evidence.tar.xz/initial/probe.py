"""Check whether the validated exterior frequencies support junction bands."""
from pathlib import Path
import sys

import numpy as np

from demosaic._mesh_frequency import infer_prior
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import refine_local_raw_mesh
ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "query-checked-junctions-v1"
sys.path.insert(0, str(PREVIOUS))
from model_delivery import curvature, interior, select


def probe(raw, colors, box, noise, span):
    pair = infer_prior(raw, colors, box, noise, span=span)
    if pair is None:
        return None
    left, top, width, height = box
    crop = raw[:, top//2:(top+height)//2, left//2:(left+width)//2]
    (x, y, _, pixels, variance, fold), _, _ = interior(crop, colors, noise)
    core = (np.maximum(abs(x), abs(y)) <= 96) & (fold == 0)
    weights = np.exp(-.5*(x*x+y*y)/75**2) / variance
    samples = x[core], y[core], weights[core], pixels[core]
    seed = [[float(fx), float(fy), 0.] for fx, fy in pair]
    # Estimate geometry only on Q0. Remove phase-plane affine terms there
    # before optimizing the fundamental frequencies.
    basis = np.column_stack((np.ones_like(x), x/128, y/128,
                             np.tile(np.repeat([-1., 1.], len(x)//2), 1)))
    sub = basis[core]
    beta = np.linalg.lstsq(sub * np.sqrt(weights[core,None]), pixels[core]*np.sqrt(weights[core]), rcond=None)[0]
    selection = curvature.refine((*samples[:3], samples[3]-sub@beta), seed, (0,1), False).tolist()
    return {"prior": [list(p) for p in pair], "refined": selection,
            "seed_result": select(crop, colors, noise, seed),
            "refined_result": select(crop, colors, noise, selection)}


def standing():
    source = reference(PREVIOUS / "standing/manifest.json")
    rows=[]
    for r in read_json(checked(source))["rows"]:
        camera=r["id"]
        span=112 if camera.startswith("mesh-") else 80
        with np.load(checked(r["input"]),allow_pickle=False) as f:
            raw,variance,colors=(f[k][0] for k in ("packed","variance","colors"))
        noise=r["shot_read"]
        box=r["query_box"]
        extension=probe(raw,colors,box,noise,span)
        p=np.load(checked(r["parent"]),allow_pickle=False)[0]
        roi=r["ROI"]["ROI_xywh"]
        x,y,w,h=roi
        baseline=p[:,y:y+h,x:x+w]
        added=refine_local_raw_mesh(p,raw,variance,colors,box,roi,donor_span=span,**noise)
        mag=np.sqrt(np.mean((added.astype(float)-baseline)**2))*65535
        print(camera, float(mag), extension["prior"] if extension else None,
              [(round(z["pooled"],2),z["scores"])for z in extension["refined_result"]["fundamentals"]] if extension else None,
              [z["name"]for z in extension["refined_result"]["modes"]["locked"] if z["accepted"]] if extension else None,flush=True)
        rows.append({"id":camera,"probe":extension,"old_donor_RMS_DN16":float(mag)})
    write_json(ROOT/"probe.json",{"driver":reference(__file__),"source":source,"rows":rows})


if __name__=="__main__":
    standing()
