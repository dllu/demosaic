"""Check sealed local inputs, Bayer reserve isolation and the final camera outputs."""
from pathlib import Path

import numpy as np

from compose import ROOT,LAST
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from probe import probe
from review import MODES
from witness import anchored,local
from model_delivery import choose_nuisance,interior,phases,witness_out


def camera_checks(row):
    x,y,w,h=row["box"]
    with np.load(checked(row["base_input"]),allow_pickle=False)as a:
        raw,colors=a["packed"][0],a["colors"][0]
    noise=row["noise"]
    rawbox=np.s_[...,y//2:(y+h)//2,x//2:(x+w)//2]
    original=probe(raw,colors,row["box"],noise,112)
    saved=row["state"]["refined_result"]
    assert original["refined_result"]==saved
    with anchored((0,0)):
        reserve=local.partition()>=2
    rng=np.random.default_rng(264116)
    alternate=raw.copy()
    alternate[rawbox][:,reserve]=rng.uniform(.001,.40,(4,reserve.sum()))
    tested=probe(alternate,colors,row["box"],noise,112)
    assert tested["prior"]==original["prior"] and tested["refined"]==original["refined"]
    a,test=original["refined_result"],tested["refined_result"]
    assert a["Q0_angles"]==test["Q0_angles"]
    for key in ("locked","free"):
        for old,new in zip(a["modes"][key],test["modes"][key],strict=True):
            assert all(old[k]==new[k]for k in ("discovery","local_axis","frequency"))
    samples,_,boundary=interior(raw[rawbox],colors,noise)
    x,y,_,z,var,fold=samples
    null,carrier=choose_nuisance(samples,boundary,a["geometry"])
    angle=phases(x,y,a["geometry"])+np.array(a["Q0_angles"])
    columns=[]
    for item in a["modes"]["locked"]:
        q=angle@item["integer_phase"]
        columns.append(np.column_stack((np.cos(q),np.sin(q))))
    use=np.maximum(abs(x),abs(y))<=96
    controls=[]
    for j,item in enumerate(a["modes"]["locked"]):
        if not item["accepted"]:
            continue
        bg=np.column_stack((null,carrier,*(b for i,b in enumerate(columns) if i!=j)))
        sign,sin=item["local_axis"]
        same=witness_out(x,y,z,var,fold,use,columns[j]@[sign,sin],bg)
        away=witness_out(x,y,z,var,fold,use,columns[j]@[-sin,sign],bg)
        assert same["pooled"]==item["pooled"]
        controls.append({"band":item["name"],"fixed_phase":same,"shifted_90_degrees":away})
    return {"id":row["id"],"exterior_and_query_Q0_choices_unchanged_with_held_mutation":True,"rotations":controls}


def main():
    restoration=reference(ROOT/"restoration.json")
    scores=reference(ROOT/"scores.json")
    records=read_json(checked(restoration))
    fields=read_json(checked(records["sources"]))
    assert read_json(checked(scores))["restoration"]==restoration
    same=np.zeros((256,256),bool)
    same[48:208,48:208]=True
    test=[]
    for row,field in zip(records["rows"],fields["rows"],strict=True):
        assert row["input"]==field["capture"]
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            assert {k:fingerprint(f[k])for k in f.files}==field["fingerprints"]
            for key in ("packed","variance"):
                np.testing.assert_array_equal(f[key][...,same],f["rotated_"+key][...,same])
            differences=int(np.count_nonzero(f["packed"]!=f["rotated_packed"]))
            assert differences>0
        with np.load(checked(row["output"]),allow_pickle=False)as f:
            assert set(f.files)==set(MODES)
            assert np.array_equal(f["local"],f["rotated"])
            for idx in range(1,4):
                np.testing.assert_array_equal(f["local"][:,idx],f["composed"][:,idx])
        test.append({"index":row["index"],"exterior_replaced_packed_components":differences})
    standing=reference(ROOT/"standing/manifest.json")
    previous={r["id"]:r for r in read_json(LAST/"standing/manifest.json")["rows"]}
    cameras=[]
    for r in read_json(checked(standing))["rows"]:
        with np.load(checked(r["outputs"]),allow_pickle=False) as f:
            old=previous[r["id"]]
            with np.load(checked(old["prediction"]),allow_pickle=False) as t:
                np.testing.assert_array_equal(f["old"],t["wide"]+.6318481533720487*t["locked"])
            if r["id"].endswith("mesh-left"):
                cameras.append(camera_checks(r))
            else:
                np.testing.assert_array_equal(f["old"],f["composed"])
    assert len(cameras)==2 and len(test)==12
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"restoration":restoration,"scores":scores,"standing":standing,
               "query_halo_stable_and_control_composition_pixel_identical":test,
               "real_reserved_query_checks":cameras,
               "six_other_standing_outputs_pixel_identical":True})
    for r in cameras:
        print(r["id"],r["rotations"],flush=True)


if __name__=="__main__":
    main()
