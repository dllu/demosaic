"""Publish inspected native evidence and preserve the exact experiment sources."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from review import ROOT

DOC=Path("docs")
RESULT=DOC/"results/query-donor-composition-v1"
IMAGES=DOC/"images/query-donor-composition-v1"
VIEWS={
    "main-overcast-sky-main-overcast-sky":"Sky is smooth and identical across the three final controls.",
    "main-building-detail-main-building-detail":"Main framework is clean. Thin cables stay soft in each variant.",
    "main-foliage-main-foliage":"The soft leaf edges and shadow areas have identical pixels across the final routes.",
    "main-chain-link-fence-main-chain-link-fence":"The preceding checked result retains both visible coarse crossing directions.",
    "mesh-nominal-fine-green-mesh-left":"Both diagonals form faint diamonds below the horizontal wire to the left of the green post. The added difference band is hard to distinguish from the donor fit alone.",
    "mesh-nominal-fine-green-mesh-right":"The earlier local checked output retains both right-cab directions, with uneven crossings and mottling.",
    "mesh-profile3879-fine-green-mesh-left":"The left lattice is visible in more of the lower area. Crossings remain irregular in strength and look overly uniform in spacing. The bands make little visible change over donor delivery.",
    "mesh-profile3879-fine-green-mesh-right":"The earlier right-cab output retains faint crossings above and below the diagonal. Background mottling remains.",
}


def copy_board(row,family,view):
    image=row["image"]
    before=checked(image)
    after=IMAGES/family/before.name
    after.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(before,after)
    assert reference(after)["sha256"]==image["sha256"]
    with Image.open(after)as f:
        if family=="exact":
            assert f.size==(160*len(row["order"]),160)
        else:
            for p in row["panels"]:
                x,y,w,h=p["png_xywh"]
                assert w==h==160 and x+w<=f.width and y+h<=f.height
        f.verify()
    return row|{"image":{"path":str(after),"sha256":image["sha256"]},"actual_viewing":view}


def main():
    numeric=reference(ROOT/"scores.json")
    standing=reference(ROOT/"standing/manifest.json")
    scope=read_json(checked(numeric))
    archive=scope["restoration"]
    exact=read_json(ROOT/"native/manifest.json")
    active=read_json(ROOT/"active-native.json")
    real=read_json(checked(standing))
    audit=read_json(ROOT/"audit.json")
    assert exact["checkpoint"]==real["checkpoint"] and audit["standing"]==standing
    assert exact["score"]==audit["scores"]==numeric
    assert exact["restoration"]==active["restoration"]==audit["restoration"]==archive
    definitions={"triplet":"The primary diagonals are clear. The weak crossing pattern remains much softer than the exact target.",
                 "matching":"Matching donors add subtle fine modulation. The exact target still has stronger crossings.",
                 "outside-only":"The existing single direction and coarse edge are retained across the outputs.",
                 "quiet":"All methods leave the displayed exact-flat region smooth."}
    exact_rows=[copy_board(r,"exact",definitions[r["role"]])for r in exact["rows"]]
    active_board=copy_board(active,"exact","The complementary direction is visible after adding the donor fit. The incremental change from the checked band is extremely faint. The exact target has stronger crossing modulation.")
    camera_rows=[copy_board(r,"standing",VIEWS[r["id"]])for r in real["rows"]]
    assert len(exact_rows)==len(camera_rows)==8
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"exact":exact|{"rows":exact_rows},"active_exact":active_board,
                         "standing":real|{"rows":camera_rows},"actual_native_viewing_complete":True})
    RESULT.mkdir(parents=True,exist_ok=True)
    paths=["*.py","*.json","*.log","initial/*.py","initial/*.json","initial/*.log",
           "standing/manifest.json","native/manifest.json"]
    archive_path=RESULT/"evidence.tar.xz"
    program=[Path("src/demosaic")/n for n in ("mesh_refinement.py","_mesh_frequency.py","_mesh_profiles.py")]
    inherited=[LAST/"model_delivery.py",LAST/"model.py"]
    with tarfile.open(archive_path,"x:xz")as bundle:
        for rule in paths:
            for source in sorted(ROOT.glob(rule)):
                bundle.add(source,arcname=source.relative_to(ROOT))
        for frozen in program:
            bundle.add(frozen,arcname=Path("package")/frozen.name)
        for frozen in inherited:
            bundle.add(frozen,arcname=Path("previous")/frozen.name)
    write_json(RESULT/"publication.json",{"study":"query-donor-composition-v1","checkpoint":real["checkpoint"],
        "trained":False,"parent_weights":"Corpus 100k EMA","scope":"Twelve exact-target photo backgrounds, eight standing GFX crop boards and two shared-capture noise profiles. No comparable 427-photo or measured-camera panels.",
        "numerical_evaluation_complete":True,"actual_native_viewing_complete":True,"states":scope["states"],
        "summary":scope["summary"],"standing":{r["id"]:r["results"]for r in real["rows"]},
        "audit":audit,"predecessors":[reference(p)for p in program+inherited],
        "manifest":reference(manifest),"evidence":reference(archive_path)})


if __name__=="__main__":
    main()
