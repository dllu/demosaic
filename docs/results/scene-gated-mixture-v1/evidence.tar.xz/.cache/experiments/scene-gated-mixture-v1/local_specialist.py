"""Repeat the bounded-detail mixture with the matched local-only specialist."""
import time

import numpy as np

from signed import FAMILIES,POLICIES,ROOT,checked,inputs_for_quadratic,load,metadata,oracle_weight
from signed import quadratic,read_json,reference,scalar,score_case,solve,summary,write_json


def comparison(new, old):
    rng=np.random.default_rng(99299114)
    bench={}
    for iso,draw in ((i,d)for i in ('iso400','iso6400') for d in ('independent','coupled')):
        picked = [r for r in new if (r['profile'],r['draw'],r['sample']) == (iso,draw,'test')]
        assert len(picked)==48
        paired = [old[r['prediction_receipt']['sha256']] for r in picked]
        ids=np.vstack((np.arange(48),rng.integers(48,size=(8000,48))))
        results={}
        for f in ('local','registered','shuffled'):
            name=f+'/preserve_response'
            left = [row['scores'][name]['fine'] for row in picked]
            right = [row['scores'][name]['fine'] for row in paired]
            assert all(a['truth']==b['truth'] for a,b in zip(left,right,strict=True))
            ratio=lambda arr:100*np.asarray([c['signed_projection'] for c in arr])[ids].sum(1)/np.asarray([c['truth'] for c in arr])[ids].sum(1)
            error=lambda arr,key:np.sqrt(np.asarray([c[key] for c in arr])[ids].mean(1))
            delta={'response_pp':ratio(left)-ratio(right)}
            delta.update({m+'_RMS_DN16':error(left,m)-error(right,m)for m in ('increment','present','quiet')})
            results[name]={key:{'point':float(v[0]),'interval':np.quantile(v[1:],(.025,.975)).tolist()}for key,v in delta.items()}
        bench[iso+'/'+draw]=results
    return bench


def run():
    start=time.monotonic()
    main=reference(ROOT/'signed.json')
    prior=read_json(checked(main))
    panel,reviewed,plan,settings=metadata()
    assert panel==prior['panel'] and plan['models']==prior['models']
    original={r['prediction_receipt']['sha256']:r for r in prior['rows']}
    measured=[]
    for record in reviewed['source_metrics']:
        case,data,rgb=load(record)
        p,gt,z=inputs_for_quadratic(case,data,rgb,settings,bed='none')
        row=original[record['prediction_receipt']['sha256']]
        item={k:row[k]for k in ('sample','source','profile','draw','case','input','prediction_receipt')}
        item['terms']={f:quadratic(p,gt,d)for f,d in z.items()}
        assert score_case(item,'registered',scalar(0))==row['scores']['parent']
        measured.append(item)
        if len(measured)%32==0:
            print(len(measured),round(time.monotonic()-start,2),flush=True)
    fits={}
    active={'parent':scalar(0),'spatial':scalar(1),'equal_mix':scalar(.5)}
    families={k:'registered' for k in active}
    calibration=[r for r in measured if r['sample']=='calibration']
    assert len(calibration)==64
    for mode in POLICIES:
        for f in FAMILIES:
            name=f+'/'+mode
            fits[name]=solve(calibration,f,mode)
            active[name]=np.asarray(fits[name]['effective'])
            families[name]=f
    output=[]
    for row in measured:
        scores={name:score_case(row,families[name],w)for name,w in active.items()}
        scores['photo_oracle']=score_case(row,'registered',scalar(oracle_weight(row)))
        output.append({k:v for k,v in row.items()if k!='terms'}|dict(scores=scores))
    scores=summary(output,active,families)
    write_json(ROOT/'local-specialist.json',dict(driver=reference(__file__),matched_input_panel=panel,
         signed_spatial=main,checkpoints=plan['models'],fits=fits,partitions=prior['partitions'],rows=output,
         scores=scores,comparison_to_spatial= comparison(output,original),
         training_seconds=sum(r['seconds']for r in fits.values()),replay_seconds=time.monotonic()-start,
         schema_note='Within scores, the spatial key is the unmixed endpoint, here local-only 40k.'))
    print('finished',time.monotonic()-start,flush=True)


if __name__=='__main__':
    run()
