"""Materialize all held-out responses and audit luma, chroma and directional tails."""
import time

import numpy as np

from demosaic.archive_metrics import linear_rgb, photometry
from native_review import ROOT,ROI,SCORE,checked,composed,load,luma,measure,metadata,read_json,reference,tile_dct,write_json


def metric(p,truth,supervise,truth_dct,noise):
    x,y,w,h=SCORE
    p=p[...,y:y+h,x:x+w]
    t=truth[...,y:y+h,x:x+w]
    camera=linear_rgb(p,supervise)
    goal=linear_rgb(t,supervise)
    d=camera[2]-goal[2]
    chroma=d-d.mean(0,keepdims=True)
    bias=chroma.mean((1,2),keepdims=True)
    q=tile_dct(np.einsum('bcxy,c->bxy',camera,measure.LUMA))
    band=measure.BANDS['fine']
    y,x=np.mgrid[:16,:16]
    diff=(q[0]-q[1])-(truth_dct[0]-truth_dct[1])
    scale=65535./96
    horizontal=band&(x>y)
    vertical=band&(y>x)
    diagonal=band&(x==y)
    target=(truth_dct[0]-truth_dct[1])[...,band]
    present_psnr=photometry(p/noise['exposure'],supervise|{'target':t/noise['exposure']},border=0)['srgb_psnr'][0]
    return {
        'chroma_quiet_RMS_DN16':float(np.sqrt(np.mean((chroma-bias)**2))*65535),
        'quiet_peak_channel_mean_bias_DN16':float(np.abs(d.mean((1,2))).max()*65535),
        'quiet_peak_chroma_bias_DN16':float(abs(bias).max()*65535),
        'present_sRGB_PSNR_dB':float(present_psnr),
        'increment_RMS_DN16':float(np.linalg.norm(diff[...,band])*scale),
        'quiet_fine_RMS_DN16':float(np.linalg.norm(q[2,...,band])*scale),
        'x_increment_RMS_DN16':float(np.linalg.norm(diff[...,horizontal])*scale),
        'y_increment_RMS_DN16':float(np.linalg.norm(diff[...,vertical])*scale),
        'diagonal_increment_RMS_DN16':float(np.linalg.norm(diff[...,diagonal])*scale),
    }


def main():
    start=time.monotonic()
    ref={n:reference(ROOT/f'{n}.json')for n in ('signed','local-specialist')}
    spatial,local=(read_json(checked(b))for b in ref.values())
    _,board,spec,_=metadata()
    keep=set(spatial['partitions']['test'])
    prior={r['prediction_receipt']['sha256']:r for r in spatial['rows']}
    rows=[]
    maximum_error=0.
    for r in board['source_metrics']:
        if r['source'] not in keep:
            continue
        case,data,predictions=load(r)
        master=read_json(checked(r['prediction_receipt']))
        with np.load(checked(master['saved']),allow_pickle=False)as f:
            predictions['V120']=f['V120']
        composed_rows={}
        for i in range(3):
            camera={k:data[k] for k in ('colors','wb','matrix')}|{'packed':data['packed'][i]}
            arms={k:z[i] for k,z in predictions.items()}
            deliver=composed(arms['100k'],arms,camera,case['profile'],ROI,data['scene_packed'],
                            case['box'],spatial,local)
            for k,v in deliver.items():
                composed_rows.setdefault(k,[]).append(v)
        outputs=predictions|{k:np.stack(v)for k,v in composed_rows.items()}
        met={k:np.broadcast_to(data[k][None],(3,*data[k].shape))for k in ('wb','matrix')}
        x,y,w,h=SCORE
        desired=tile_dct(luma(data['target'][...,y:y+h,x:x+w],data['wb'],data['matrix']))
        cases={k:metric(v,data['target'],met,desired,case['profile'])for k,v in outputs.items()}
        archived=prior[r['prediction_receipt']['sha256']]['scores']['registered/preserve_response']['fine']
        error=abs(cases['registered']['increment_RMS_DN16']-np.sqrt(archived['increment']))
        assert error < .002
        maximum_error=max(maximum_error,error)
        rows.append({k:r[k]for k in ('profile','draw','source','prediction_receipt')}|dict(scores=cases))
        if len(rows)%24==0:
            print(len(rows),round(time.monotonic()-start,2),flush=True)
    assert len(rows)==192
    summary={}
    rng=np.random.default_rng(985500)
    for condition in sorted({(r['profile'],r['draw'])for r in rows}):
        chosen=[r['scores']for r in rows if (r['profile'],r['draw'])==condition]
        ids=np.vstack((np.arange(48),rng.integers(48,size=(6000,48))))
        by_metric={}
        for name in chosen[0]['registered']:
            aggregator = name.endswith('_RMS_DN16')
            values={}
            for arm in chosen[0]:
                a=np.asarray([row[arm][name]for row in chosen])[ids]
                values[arm]=np.sqrt((a*a).mean(1)) if aggregator else a.mean(1)
            diff=values['registered']-values['100k']
            by_metric[name]={'mean':{arm:float(v[0])for arm,v in values.items()},
                'registered_vs_parent':{'point':float(diff[0]),'interval':np.quantile(diff[1:],(.025,.975)).tolist()}}
        summary['/'.join(condition)]=by_metric
    write_json(ROOT/'color-audit.json',dict(driver=reference(__file__),inputs=ref,
        endpoint=spatial['models'],seconds=time.monotonic()-start,maximum_DELIVERED_increment_error_DN16=maximum_error,
        per_case=rows,scopes=summary))
    print(maximum_error,flush=True)


if __name__=='__main__':
    main()
