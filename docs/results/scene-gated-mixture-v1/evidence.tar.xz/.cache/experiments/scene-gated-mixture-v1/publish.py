"""Freeze fitted coefficients, error measurements and native camera comparisons."""
from datetime import datetime
from pathlib import Path
import hashlib
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
RESULT=Path('docs/results')/ROOT.name
IMAGE=Path('docs/images')/ROOT.name


def pixels(path,record):
    img=np.asarray(Image.open(path).convert('RGB'))
    cells={p.get('label',p.get('name')):img[y:y+h,x:x+w]for p in record['panels']
           for x,y,w,h in [p['png_xywh']]}
    assert all(z.shape==(160,160,3)for z in cells.values())
    return cells


def keep(record,kind):
    raw=checked(record['image'])
    result=IMAGE/kind/raw.name
    result.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(raw,result)
    assert reference(result)['sha256']==record['image']['sha256']
    record['image']['path']=result.relative_to(IMAGE).as_posix()
    return pixels(result,record)


def publish():
    names=('scores','signed','local-specialist','native','color-audit')
    refs={n:reference(ROOT/f'{n}.json')for n in names}
    original,signed,local,views,color=(read_json(checked(x))for x in refs.values())
    assert signed['positive_only']==refs['scores']
    assert local['signed_spatial']==refs['signed']
    assert views['collection']==color['inputs']=={k:refs[k]for k in ('signed','local-specialist')}
    assert original['models']==signed['models']==local['checkpoints']==views['models']==color['endpoint']
    assert all(len(v['rows'])==256 and v['partitions']==signed['partitions']for v in (original,signed,local))
    assert len(signed['partitions']['calibration'])==16 and len(signed['partitions']['test'])==48
    for abc in zip(original['rows'],signed['rows'],local['rows'],strict=True):
        for key in ('source','profile','draw','sample','prediction_receipt','input'):
            assert abc[0][key]==abc[1][key]==abc[2][key]
        assert all(r['scores']['parent']==abc[0]['scores']['parent']for r in abc)
    assert len(color['per_case'])==192 and color['maximum_DELIVERED_increment_error_DN16']<.002
    for view in views['exact']:
        original=keep(view['board'],'exact')
        triplet=keep(view['triplet'],'exact')
        assert list(triplet)==['Noisy Malvar','Registered detail gate','Exact GT']
        assert all(np.array_equal(original[k],p)for k,p in triplet.items())
    assert len(views['exact'])==2 and len(views['standing']['records'])==8
    for row in views['standing']['records']:
        prior=row['previous']
        before=pixels(checked(prior['image']),prior)
        current=keep(row['board'],'standing')
        named=set(before)&set(current)
        assert {'ISO100 AHD reference','Noisy (Malvar)','Parent 100k EMA',
                'Local-only 40k EMA','Spatial 40k EMA'}<=named
        if row['id'].startswith('mesh-'):
            assert {'ISO6400 camera JPEG','ISO100 camera JPEG'}<=named
        assert all(np.array_equal(before[k],current[k])for k in named)
    image=IMAGE/'manifest.json'
    write_json(image,{**views,'viewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    RESULT.mkdir(exist_ok=True)
    weights=RESULT/'mixture-coefficients.json'
    write_json(weights,{'spatial_fit':signed['fits'],'local_only_fit':local['fits'],'models':signed['models'],
             'calibration_photos':signed['partitions']['calibration'],'registered_context':True,
             'methods':{key:refs[key]for key in ('signed','local-specialist')},'negative_fine_bound':.5})
    inputs=list(refs.values())
    archive=RESULT/'evidence.tar.xz'
    members=[checked(v)for v in inputs]+list(ROOT.glob('*.py'))+list(ROOT.glob('*.log'))
    members+= [ROOT.with_name('scene-raw-covariance-v1')/'evaluate.py',
               ROOT.with_name('scene-local-contrast-2400-v1')/'measure.py',
               ROOT.with_name('paired-luminance-detail-v1')/'render.py',Path('scripts/report_scene_wave_guides.py')]
    with tarfile.open(archive,'w:xz',preset=4) as out:
        for p in sorted(members):
            out.add(p,arcname=str(p.resolve().relative_to(Path.cwd())),recursive=False)
    with tarfile.open(archive) as f:
        for p in members:
            with f.extractfile(str(p.resolve().relative_to(Path.cwd()))) as fd:
                assert hashlib.file_digest(fd,'sha256').hexdigest()==reference(p)['sha256']
    relevant=('iso400/coupled/test','iso400/independent/test','iso6400/coupled/test','iso6400/independent/test')
    write_json(RESULT/'publication.json',{'checkpoint':reference(weights),'sources':refs,'models':signed['models'],
        'archive':reference(archive),'native_manifest':reference(image),
        'fits':{'bounded':{'solves':8,'seconds':read_json(checked(refs['scores']))['fit_time_seconds']},
                'signed_spatial':{'solves':len(signed['fits']),'seconds':signed['optimization_seconds']},
                'signed_local':{'solves':len(local['fits']),'seconds':local['training_seconds']}},
        'results':{k:signed['summary'][k]['fine'] for k in relevant},
        'matched_local_endpoint_comparison':local['comparison_to_spatial'],
        'delivered_color_checks':color['scopes']['iso6400/independent'],
        'scope':'Fitted output composition from frozen EMA predictions. 16 photo fits and 48 evaluation photos. Two exact witnesses and both standing GFX families. No full427 or broad measured-camera score.'})
    print('Verified',len(members),'archive members and twelve native PNGs')


if __name__=='__main__':
    publish()
