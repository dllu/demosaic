"""Apply the fitted mixtures to retained camera RGB and render native witnesses."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from mixture import ROOT, TRIAL, ROI, SCORE, GATES, gate_maps, shape_delta, luma, load, metadata, tile_dct, measure
from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.io import read_raw
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

sys.path.insert(0,str(ROOT.with_name('paired-luminance-detail-v1')))
from render import native_png

RENDER=TRIAL/'review-native-040000/work/render/result.json'
RAW_PROVENANCE=Path('docs/images/scene-raw-covariance-v1/manifest.json')
POLICIES=('constant','local','registered','shuffled','local_endpoint')
LABELS={'constant':'Constant risk mix','local':'Local detail gate','registered':'Registered detail gate',
        'shuffled':'Shuffled context gate','local_endpoint':'Local 40k mixture'}


def composed(p,q,raw,noise,roi,scene,box,model_record,local_record):
    cfa,wb,matrix=(raw[k] for k in ('colors','wb','matrix'))
    x,y,w,h=roi
    span=np.s_[:,y:y+h,x:x+w]
    direction = np.linalg.solve(matrix.astype(float),np.ones(3))/np.asarray(wb,dtype=float)
    output={}
    maps = {}
    cases=[(name, q['spatial--matching'], model_record['fits'][key])
           for name,key in (('constant','static/risk'), ('local','local/preserve_response'),
                            ('registered','registered/preserve_response'), ('shuffled','shuffled/preserve_response'))]
    cases.append(('local_endpoint',q['none'],local_record['fits']['registered/preserve_response']))
    for name,expert,fit in cases:
        diff,lo,hi=shape_delta(p,expert,roi)
        donor_scope=name in ('registered','shuffled','local_endpoint')
        if name in ('constant','local'):
            cache='local'
        else:
            cache=name
        if cache not in maps:
            g=gate_maps(raw['packed'],cfa,noise,roi,diff,scene=scene if donor_scope else None,
                        box=box,shuffled=name=='shuffled')
            if len(g)<len(GATES):
                g=np.pad(g,((0,len(GATES)-len(g)),(0,0),(0,0)))
            maps[cache]=g
        basis=maps[cache]
        assert len(basis)==len(GATES)
        coarse_weights,detail_weights=np.split(np.asarray(fit['positive']),2)
        gain_low,gain_high,gain_boost=(np.einsum('i,ihw->hw',v,basis)
                       for v in (coarse_weights,detail_weights,np.asarray(fit['neutral_boost'])))
        assert gain_boost.min()>=-1e-12 and gain_boost.max()<.5000001
        assert gain_low.min()>=-1e-12 and gain_low.max()<1.00000005
        assert gain_high.min()>=-1e-12 and gain_high.max()<1.00000005
        update=gain_low*lo + gain_high*hi - (gain_boost*luma(hi,wb,matrix))[None]*direction[:,None,None]
        image=p.copy()
        image[span]+=update.astype(np.float32)
        output[name]=image
    return output


def exact(spatial,local):
    _,read,_,settings=metadata()
    ids=spatial['witnesses']['registered/preserve_response']
    assert len(ids)==2 and ids[0]['source']!=ids[1]['source']
    output=ROOT/'exact'
    output.mkdir(exist_ok=True)
    views=[]
    for mark in ids:
        row = next(r for r in read['source_metrics'] if (r['source'],r['profile'],r['draw'])==
                   (mark['source'],'iso6400','independent'))
        case, data, raw_predictions=load(row)
        mix_case=next(r for r in spatial['rows'] if r['prediction_receipt']==row['prediction_receipt'])
        local_case=next(r for r in local['rows'] if r['prediction_receipt']==row['prediction_receipt'])
        arms = {}
        for i in range(3):
            raw={k:data[k] for k in ('colors','wb','matrix')}
            raw['packed']=data['packed'][i]
            arrays={k:v[i] for k,v in raw_predictions.items()}
            for k,v in composed(arrays['100k'],arrays,raw,case['profile'],ROI,data['scene_packed'],
                                case['box'],spatial,local).items():
                arms.setdefault(k,[]).append(v)
        # Verify the polynomial prediction against the actual applied FP32
        # camera RGB, including the achromatic boost transformation.
        x,y,w,h=SCORE
        mask=measure.BANDS['fine']
        truth=luma(data['target'][...,y:y+h,x:x+w],data['wb'],data['matrix'])
        truth_dct=tile_dct(truth)
        for arm,name,record in (('constant','static/risk',mix_case),('local','local/preserve_response',mix_case),
              ('registered','registered/preserve_response',mix_case),
              ('shuffled','shuffled/preserve_response',mix_case),('local_endpoint','registered/preserve_response',local_case)):
            mix = np.stack(arms[arm])[...,y:y+h,x:x+w]
            score=tile_dct(luma(mix,data['wb'],data['matrix']))-truth_dct
            measured=np.sqrt(np.sum(np.square((score[0]-score[1])[...,mask]))*65535**2/(36*16*16))
            assert abs(measured-np.sqrt(record['scores'][name]['fine']['increment']))<.002
        refs={key:data[key][None] for key in ('colors','wb','matrix')}
        refs['packed']=data['packed'][:1]
        variants=('Noisy Malvar','Corpus 100k','Local-only 40k','Spatial 40k',*(LABELS[v]for v in POLICIES),'Exact GT')
        values=(noisy_malvar(refs)[0],raw_predictions['100k'][0],raw_predictions['none'][0],
                raw_predictions['spatial--matching'][0],*(arms[v][0]for v in POLICIES),data['target'][0])
        source=settings['rows'][case['case']]
        views.append(native_board(output,case['id']+'-scene-mixture',values,refs,
            {'source':source['source'],'camera_pattern':source['camera']['pattern'],
             'photo_query_xywh':case['box'],'noise':case['profile'],'input':case['input'],
             'ADC_bits':16,'black_level':source['camera']['black'],
             'selected_increment_change_DN16':mark['fine_increment_delta'],'checkpoints':spatial['models'],
             'method':'paired response calibration for registered mixture'},
             labels=variants,triplet_indices=(0,variants.index(LABELS['registered']),len(variants)-1),
             exposure=1/case['profile']['exposure'],contrast=2,roi=ROI))
    return views


def pixels(board):
    image=np.asarray(Image.open(checked(board['image'])).convert('RGB'))
    return {p['label']:image[y:y+h,x:x+w]for p in board['panels'] for x,y,w,h in [p['png_xywh']]}


def standing(spatial,local):
    torch.set_num_threads(2)
    out=ROOT/'standing'
    out.mkdir(exist_ok=True)
    reports=reference(RENDER)
    receipts=read_json(checked(reports))
    refs={n:read_json(checked(receipts['collections'][n])) for n in ('parent100k','none','spatial')}
    accepted={n:{r['id']:r for r in v['records']}for n,v in refs.items()}
    for key,n in (('100k','parent100k'),('none','none'),('spatial','spatial')):
        assert spatial['models'][key]['sha256']==refs[n]['checkpoint']['sha256']
    bodies={r['id']:r for r in read_json(RAW_PROVENANCE)['native']['standing']['rows']}
    evidence=[]
    for group in ('main','mesh'):
        rows=[r for r in receipts['boards'] if r['id'].startswith(group+'-')]
        bound=bodies[rows[0]['id']]['raw']
        raw,info=read_raw(checked(bound))
        h,w=raw.shape
        scene=np.stack([raw[oy:h//2*2:2,ox:w//2*2:2] for oy in range(2)for ox in range(2)])
        cfa=np.asarray(color_indices(info.pattern))
        del raw
        for record in rows:
            name=record['id']
            assert bodies[name]['raw']==bound
            observation=record['observation']
            recs={n:collection[observation]for n,collection in accepted.items()}
            bx,by,bw,bh=box=recs['spatial']['scene_box_xywh'][0]
            assert bx%2==by%2==0
            with np.load(checked(record['input_arrays']),allow_pickle=False) as f:
                data={k:f[k] for k in ('packed','variance','colors','wb','matrix')}
            for key,value in data.items():
                assert all(fingerprint(value)==r['input_fingerprints'][key] for r in recs.values())
            assert np.array_equal(data['colors'][0],cfa)
            assert np.array_equal(data['packed'][0],scene[:,by//2:(by+bh)//2,bx//2:(bx+bw)//2])
            field={k:np.load(checked(v['prediction']),allow_pickle=False)[0]for k,v in recs.items()}
            roi=record['case']['ROI_xywh']
            nose=record['noise']
            arguments={k:v[0] for k,v in data.items()}
            q={'spatial--matching':field['spatial'],'none':field['none']}
            shaped=composed(field['parent100k'],q,arguments,nose,roi,scene,box,spatial,local)
            exposure=record['display_exposure']
            def display(image):
                value=display_crop(torch.from_numpy(image[None]),torch.from_numpy(data['wb']),
                                   torch.from_numpy(data['matrix']),roi,exposure=exposure)
                return np.rint(value.clip(0,1)*255).astype(np.uint8)
            prior=pixels(record)
            for key,arm in (('Parent 100k EMA','parent100k'),('Local-only 40k EMA','none'),('Spatial 40k EMA','spatial')):
                assert np.array_equal(prior[key],display(field[arm]))
            lead=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Local-only 40k EMA','Spatial 40k EMA')
            panels=[(key,prior[key]) for key in lead if key in prior]
            panels.extend((LABELS[k],display(v))for k,v in shaped.items())
            panels.extend((key,prior[key])for key in ('ISO100 AHD reference','ISO100 camera JPEG')if key in prior)
            x,y,wi,he=roi
            diff={k:float(np.sqrt(np.mean((v[:,y:y+he,x:x+wi].astype(float)-
                                         field['parent100k'][:,y:y+he,x:x+wi])**2))*65535)for k,v in shaped.items()}
            evidence.append({'id':name,'raw':bound,'roi':roi,'native_sensor_box':box,'input':record['input_arrays'],
                'parent_images':{k:r['prediction'] for k,r in recs.items()},'arm_checkpoints':spatial['models'],
                'conditioning':nose,'display_exposure':exposure,'previous':record,
                'board':native_png(out/f'{name}.png',panels),'RGB_RMS_DN16_vs_parent':diff})
            print(name,diff,flush=True)
        del scene
    assert len(evidence)==8
    return {'records':evidence,'reference':reports}


def main():
    binding={k:reference(ROOT/f'{k}.json')for k in ('signed','local-specialist')}
    spatial,local=(read_json(checked(v))for v in binding.values())
    assert local['signed_spatial']==binding['signed']
    views=exact(spatial,local)
    cameras=standing(spatial,local)
    write_json(ROOT/'native.json',{'driver':reference(__file__),'models':spatial['models'],
             'collection':binding,'exact':views,'standing':cameras})


if __name__=='__main__':
    main()
