"""Test a constrained detail boost above spatially mixed frozen endpoints."""
from collections import defaultdict
import time

import numpy as np
from scipy.optimize import minimize

from mixture import (FAMILIES,GATES,POLICIES,ROOT,accumulate,checked,index,inputs_for_quadratic,load,metadata,
                     oracle_weight,quadratic,read_json,reference,scalar,score_case,split,summary,write_json)

SCALE=.50
LENGTH=len(GATES)


def bounds_for(family):
    size=len(FAMILIES[family])
    # Coarse weights only interpolate. Fine weights can put a bounded amount
    # of the opposite endpoint difference back into the parent.
    transform=np.vstack((np.eye(2*size),np.c_[np.zeros((size,size)),-SCALE*np.eye(size)])).T
    split=np.zeros((2,3*size))
    split[0,:size]=1
    split[1,size:]=1
    return transform,split


def solve(cal,family,mode):
    start=time.perf_counter()
    H,v,resp=accumulate(cal,family)
    t,C=bounds_for(family)
    n=len(FAMILIES[family])
    w0=np.zeros(3*n)
    w0[[0,n]]=1
    working=t.T@H@t
    linear=t.T@v
    constraints=[{'type':'eq','fun':lambda w: C@w-1,'jac':lambda w:C}]
    scope={}
    if mode=='preserve_response':
        for spec in sorted({(r['profile'],r['draw']) for r in cal}):
            group=[r for r in cal if (r['profile'],r['draw'])==spec]
            assert len(group)==16
            projected=accumulate(group,family)[-1]@t
            constraints.append({'type':'ineq','fun':lambda w,p=projected:float(p@w),'jac':lambda w,p=projected:p})
            scope['/'.join(spec)]=projected
    reg=.0001
    opt=minimize(lambda w:float(w@working@w+2*linear@w+reg*(w@w)),w0,
                 jac=lambda w:2*(working@w+linear+reg*w),method='SLSQP',constraints=constraints,
                 bounds=[(0.,1.) for _ in w0],options={'ftol':1e-11,'maxiter':300})
    assert opt.success,(family,mode,opt.message)
    assert np.max(abs(C@opt.x-1))<1e-7
    positive=np.zeros(2*LENGTH)
    positive[index(family)]=opt.x[:2*n]
    negative=np.zeros(LENGTH)
    negative[index(family)[:n]]=opt.x[2*n:]*SCALE
    effective=positive-np.r_[np.zeros(LENGTH),negative]
    assert np.max(np.abs(effective[index(family)]-t@opt.x))<1e-7
    limits={p:float(100*(v@opt.x))for p,v in scope.items()}
    assert all(v>-1e-7 for v in limits.values())
    return {'effective':effective.tolist(),'positive':positive.tolist(),'neutral_boost':negative.tolist(),
        'iterations':opt.nit,'seconds':time.perf_counter()-start,'calibrated_min_per_noise_draw_pp':limits,
        'calibrated_pooled_change_pp':float(100*(resp@effective[index(family)]))}


def run():
    start=time.monotonic()
    bound=reference(ROOT/'scores.json')
    previous=read_json(checked(bound))
    panel,reviewed,plan,settings=metadata()
    assert panel==previous['panel'] and plan['models']==previous['models']
    display={r['prediction_receipt']['sha256']:r for r in previous['rows']}
    measured=[]
    for row in reviewed['source_metrics']:
        case,data,rgb=load(row)
        record=display[row['prediction_receipt']['sha256']]
        old=record['scores']
        p,gt,design=inputs_for_quadratic(case,data,rgb,settings)
        terms={k:quadratic(p,gt,v)for k,v in design.items()}
        item={k:record[k]for k in ('sample','source','profile','draw','case','input','prediction_receipt')}
        item['terms']=terms
        before=score_case(item,'registered',scalar(0))
        assert before==old['parent']
        measured.append(item)
        if len(measured)%32==0:
            print(len(measured),round(time.monotonic()-start,2),flush=True)
    eval_modes={'parent':scalar(0),'spatial':scalar(1),'equal_mix':scalar(.5)}
    cal=[row for row in measured if row['sample']=='calibration']
    assert len(measured)==256 and len(cal)==64
    fits={}
    families={k:'registered' for k in eval_modes}
    for mode in POLICIES:
        for family in FAMILIES:
            name=family+'/'+mode
            fits[name]=solve(cal,family,mode)
            eval_modes[name]=np.asarray(fits[name]['effective'])
            families[name]=family
    rows=[]
    for d in measured:
        result={arm:score_case(d,families[arm],weights) for arm,weights in eval_modes.items()}
        old=display[d['prediction_receipt']['sha256']]['scores']
        result['photo_oracle']=old['photo_oracle']
        rows.append({k:v for k,v in d.items() if k!='terms'}|{'scores':result})
    totals=summary(rows,eval_modes,families)
    witnesses={}
    for policy in POLICIES:
        arm='registered/'+policy
        picked=[r for r in rows if (r['profile'],r['draw'],r['sample'])==('iso6400','independent','test')]
        e=lambda r: np.sqrt(r['scores'][arm]['fine']['increment'])-np.sqrt(r['scores']['parent']['fine']['increment'])
        witnesses[arm]=[{k:r[k] for k in ('case','source')}|{'fine_increment_delta':float(e(r))}
                        for r in (min(picked,key=e),max(picked,key=e))]
    write_json(ROOT/'signed.json',dict(driver=reference(__file__),positive_only=bound,panel=panel,models=plan['models'],
        partitions=previous['partitions'],fits=fits,summary=totals,rows=rows,
        witnesses=witnesses,maximum_extrapolation=SCALE,families=families,
        optimization_seconds=sum(v['seconds']for v in fits.values()),replay_seconds=time.monotonic()-start))
    print('finished',round(time.monotonic()-start,2),flush=True)


if __name__=='__main__':
    run()
