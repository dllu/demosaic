"""Test whether a single asynchronous checkpoint upload preserves output."""
import copy
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from screen import ROOT, PRIMARY, MODEL, policy

MODES=('two_traversals','combined_sync','combined_async')


def stage(model,mode):
    if mode=='two_traversals':
        return model.to('cuda').to(memory_format=torch.channels_last)
    return model.to(device='cuda',memory_format=torch.channels_last,non_blocking=mode=='combined_async')


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.init()
    primary=read_json(PRIMARY)
    checkpoint=primary['models'][MODEL]['checkpoint']
    parent,state=load_checkpoint(checkpoint['path'],'cpu')
    assert state['loaded_sha256']==checkpoint['sha256']
    del state
    parent.eval()
    control=read_json(checked(primary['canonical_inputs']))['records'][0]
    noise=control['context']['condition']
    keys=('packed','variance','colors','wb','matrix')
    with np.load(checked(control['arrays']),allow_pickle=False) as image:
        args=[torch.from_numpy(image[k][:1].copy()).cuda()for k in keys]
    args[:2]=[v.contiguous(memory_format=torch.channels_last) for v in args[:2]]
    history={k:[] for k in MODES}
    expected=None
    for i in range(4):
        order=MODES if i%2==0 else MODES[::-1]
        for mode in order:
            test=copy.deepcopy(parent)
            torch.cuda.synchronize()
            begin=time.perf_counter()
            stage(test,mode)
            submitted=time.perf_counter()
            torch.cuda.synchronize()
            done=time.perf_counter()
            test.set_noise(noise['shot'],noise['read'])
            with policy(test,'fp16'):
                out=test(*args).cpu().numpy()
            if expected is None:
                expected=out
            else:
                np.testing.assert_array_equal(out,expected)
            assert all(a.is_contiguous(memory_format=torch.channels_last) for a in test.parameters() if a.ndim==4)
            del test
            history[mode].append({'submit_seconds':submitted-begin,'completed_seconds':done-begin})
            print(i,mode,round(done-begin,4),flush=True)
    write_json(ROOT/'transfer.json',{'driver':reference(__file__),'checkpoint':checkpoint,'inputs':control,
        'measurements':history,'median_complete_seconds':{k:float(np.median([r['completed_seconds']for r in v]))for k,v in history.items()},
        'validation':'All 12 FP16 output arrays match byte-for-byte. Shared GB10. Same process, warmed allocator.'})


if __name__=='__main__':
    main()
