"""Link measured timing, fixed panel comparisons and reviewed native evidence."""
from pathlib import Path
import shutil
import subprocess
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
NAME=ROOT.name
RESULTS=Path('docs/results')/NAME
IMAGES=Path('docs/images')/NAME


def verify_copy(section):
    for name,image in section.items():
        original=checked(image)
        with Image.open(original) as pixels:
            if pixels.height not in (184,192):
                raise ValueError(f'Unexpected native board height: {original}')
        to=Path(shutil.copy2(original,IMAGES/name))
        target=reference(to)
        assert target['sha256']==image['sha256']
        section[name]={'path':str(to),'sha256':target['sha256']}


def target_summary(quality):
    output={}
    for profile in ('iso400','iso6400'):
        group=[r for r in quality['wire_cases'] if r['noise']==profile]
        deltas={}
        for name in group[0]['scores']['fp32']:
            full=np.asarray([r['scores']['fp32'][name]for r in group])
            half=np.asarray([r['scores']['fp16'][name]for r in group])
            d=half-full
            deltas[name]={'fp32_mean':float(full.mean()),'fp16_mean':float(half.mean()),
                          'mean_delta':float(d.mean()),'max_abs_delta':float(abs(d).max())}
        output[profile]={'backgrounds':len(group),'metrics':deltas}
    return output


def main():
    RESULTS.mkdir()
    IMAGES.mkdir()
    files=['screen.py','screen.json','screen.run.log','full_frame.py','full_production.py',
           'first-fp32.json','first-fp16.json','rgb16_diff.py','rgb16-difference.json',
           'quality.py','target-quality.json','main_boards.py','main-boards/manifest.json',
           'canonical.py','canonical.json','canonical-progress.jsonl','tests.log',
           'alternatives.py','alternatives.json','startup.py','startup-online.json','startup-offline.json',
           'startup_profile.py','startup-stages.json','startup_fused.py','startup-fused.json',
           'transfer.py','transfer.json','ramps.py','ramps.json','outlier.py','outlier.json','publish.py']
    evidence=RESULTS/'evidence.tar.xz'
    by_hash={}
    with tarfile.open(evidence,'x:xz') as tar:
        for name in files:
            path=ROOT/name
            by_hash[name]=reference(path)['sha256']
            tar.add(path,arcname=name)
    quality=read_json(ROOT/'target-quality.json')
    main_scene=read_json(ROOT/'main-boards/manifest.json')
    images={}
    for fixed in quality['fixed_cases']:
        board=fixed['board']
        for kind in ('board','triplet'):
            path=board[kind]['image']
            images[Path(path['path']).name]=path
    for row in quality['cab']+main_scene['rows']:
        path=row['board']['image']
        images[Path(path['path']).name]=path
    maximum=read_json(ROOT/'outlier.json')
    images['outlier.png']=maximum['board']['image']
    verify_copy(images)
    write_json(IMAGES/'manifest.json',{'image_files':images,'exact_target_views':quality['fixed_cases'],
                  'cab_views':quality['cab'],'main_views':main_scene['rows'],'maximum_export_difference':maximum,'checkpoint':quality['model'],
                  'actual_views':{'exact_triplets_and_comparisons':2,'GFX_native_boards':8}})
    primary=read_json(ROOT/'canonical.json')
    screen=read_json(ROOT/'screen.json')
    diff=read_json(ROOT/'rgb16-difference.json')
    full={k:read_json(ROOT/f'first-{k}.json')for k in ('fp32','fp16')}
    alt=read_json(ROOT/'alternatives.json')
    write_json(RESULTS/'publication.json',{
        'checkout':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'checkpoint':quality['model'],
        'repository_sources':{name:reference(Path('src/demosaic')/name) for name in
             ('inference.py','precision.py','pretrained_rgb.py','dino_pyramid.py','cli.py','io.py')},
        'seconds':{k:r['median_seconds']for k,r in screen['results'].items()},
        'resident FP16 forward statistics':screen['results']['fp16'],
        'alternative_precisions':alt['results'],'full_frame':full,'full_frame_difference':diff,
        'panel_summary':primary['metrics'],'wire_statistics':target_summary(quality),
        'paired_checkpoint_upload':read_json(ROOT/'transfer.json')['median_complete_seconds'],
        'setup_stages':{label:read_json(ROOT/file)['times_seconds']for label,file in
                        (('two_transfers','startup-stages.json'),('combined_async','startup-fused.json'))},
        'ramps':reference(ROOT/'ramps.json'),
        'native_manifest':reference(IMAGES/'manifest.json'),'archive':reference(evidence),'member_sha256':by_hash,
        'test_receipt':reference(ROOT/'tests.log'),
        'scope':'Fixed checkpoint inference only, with no weight updates.'})

if __name__=='__main__':
    main()
