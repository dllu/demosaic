"""Measure the existing BF16 default and opt-in cuDNN FP32 tuning."""
from contextlib import contextmanager
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.cfa import color_indices, pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.precision import amp_context, cudnn_autotune
from screen import ROOT, READ, SHOT, load, policy, statistics, versions

MODES=('fp32','fp32-tuned','bf16','fp16')


@contextmanager
def apply(model,mode):
    if mode=='bf16':
        with amp_context('cuda',dtype='bfloat16'):
            yield
    elif mode=='fp32-tuned':
        with cudnn_autotune('cuda',enabled=True):
            yield
    else:
        with policy(model,mode):
            yield


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,12*2**30/torch.cuda.get_device_properties(0).total_memory))
    prior=reference(ROOT/'screen.json')
    fixed=read_json(checked(prior))
    raw,meta=read_raw(checked(fixed['camera']))
    tiles=np.stack([raw[y:y+512,x:x+512]for x,y in fixed['crop_geometry']])
    sensor=pack(torch.from_numpy(tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
    camera=[torch.as_tensor(v,device='cuda',dtype=d).unsqueeze(0).expand(4,*np.shape(v)) for v,d in
            ((color_indices(meta.pattern),torch.long),(meta.white_balance,torch.float32),(meta.camera_to_srgb,torch.float32))]
    args=(sensor,sensor.clamp_min(0)*SHOT+READ,*camera)
    model,checkpoint=load()
    assert checkpoint==fixed['checkpoint']
    model.set_noise(SHOT,READ)
    times={mode:[] for mode in MODES}
    first={}
    saved={}
    for mode in MODES:
        torch.cuda.synchronize()
        t0=time.perf_counter()
        with apply(model,mode):
            out=model(*args)
        torch.cuda.synchronize()
        first[mode]=time.perf_counter()-t0
        saved[mode]=out.cpu().numpy()
        with apply(model,mode):
            model(*args)
        torch.cuda.synchronize()
        print('warm',mode,first[mode],flush=True)
    for i in range(8):
        order=MODES[i//2:]+MODES[:i//2]
        for mode in (order if i%2==0 else order[::-1]):
            torch.cuda.synchronize()
            t0=time.perf_counter()
            with apply(model,mode):
                model(*args)
            torch.cuda.synchronize()
            times[mode].append(time.perf_counter()-t0)
    result={mode:{'resident_seconds':times[mode],'median':float(np.median(times[mode])),
                  'first_forward_seconds':first[mode],'difference':statistics(saved[mode],saved['fp32'])}for mode in MODES}
    write_json(ROOT/'alternatives.json',{'driver':reference(__file__),'screen':prior,'results':result,'backend':versions()})
    print({mode:info['median'] for mode,info in result.items()},flush=True)


if __name__=='__main__':
    main()
