"""Attribute inference setup time to exact loader stages."""
import hashlib
from pathlib import Path
import time

import torch

from demosaic.experiments.artifacts import read_json, reference, write_json
from screen import MODEL, PRIMARY, ROOT, versions


def main():
    torch.set_num_threads(3)
    torch.cuda.init()
    torch.cuda.synchronize()
    begin=time.perf_counter()
    from demosaic.model import JointDemosaic, ModelConfig
    from transformers import AutoModel
    from unittest.mock import patch
    imported=time.perf_counter()
    binding=read_json(PRIMARY)['models'][MODEL]['checkpoint']
    with Path(binding['path']).open('rb') as stream:
        weights=torch.load(stream,map_location='cpu',weights_only=True)
        deserialized=time.perf_counter()
        stream.seek(0)
        assert hashlib.file_digest(stream,'sha256').hexdigest()==binding['sha256']
    checked=time.perf_counter()
    dino=[]
    original=AutoModel.from_pretrained
    def timed_dino(*args,**kwargs):
        t0=time.perf_counter()
        model=original(*args,**kwargs)
        dino.append(time.perf_counter()-t0)
        return model
    with patch.object(AutoModel,'from_pretrained',new=timed_dino):
        model=JointDemosaic(ModelConfig.from_checkpoint(weights['model_config']))
    constructed=time.perf_counter()
    missing,unexpected=model.load_state_dict(weights['ema'],strict=False)
    assert not unexpected and all(name.startswith('context.backbone.') for name in missing)
    model.set_refinement_precision('float32')
    assigned=time.perf_counter()
    model.eval().to('cuda').to(memory_format=torch.channels_last)
    torch.cuda.synchronize()
    staged=time.perf_counter()
    measured={'python_imports':imported-begin,'checkpoint_read':deserialized-imported,
              'checkpoint_SHA256':checked-deserialized,'model_construction':constructed-checked,
              'DINO_within_model_construction':dino,'copy_ema':assigned-constructed,
              'stage_cuda':staged-assigned,'total':staged-begin}
    write_json(ROOT/'startup-stages.json',{'checkpoint':binding,'DINO_revision':model.config.dino_revision,
                     'times_seconds':measured,'driver':reference(__file__),'backend':versions()})
    print(measured,flush=True)

if __name__=='__main__':
    main()
