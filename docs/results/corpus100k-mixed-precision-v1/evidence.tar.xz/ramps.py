"""Measure precision differences and banding risk on exact calibrated ramps."""
from dataclasses import replace
from itertools import product

import numpy as np
import torch

from demosaic.archive_metrics import linear_rgb
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
from demosaic.scene_data import observe_scene, sample_scene_recipe
from quality import LUMA, infer, error
from screen import ROOT, load


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,8*2**30/torch.cuda.get_device_properties(0).total_memory))
    model,checkpoint=load()
    axis=torch.linspace(0,1,256)
    rising=axis[None,None,:].expand(3,256,-1)
    lows=torch.tensor((.00025,.0004,.00032))[:,None,None]
    highs=torch.tensor((.007,.014,.010))[:,None,None]
    targets={'shadow':torch.lerp(lows,highs,rising),
             'bright colour':torch.lerp(torch.tensor((.13,.21,.10))[:,None,None],
                                        torch.tensor((.96,.84,.53))[:,None,None],rising)}
    profiles=(('ADC-only',0.,0.),('ISO400',.00008,2.56e-8),('ISO6400',.00128,6.5536e-6))
    rows=[]
    for index,(bayer,scene,noise) in enumerate(product(PATTERNS,targets,profiles)):
        label,shot,read=noise
        settings={'shot':shot,'read':read}
        recipe=replace(sample_scene_recipe(27581+index),pattern=bayer,shot=shot,read=read,
                       exposure=1. if scene=='shadow' else 1.35,black=.03)
        sampled=observe_scene(targets[scene],recipe)
        keys=('packed','variance','colors','wb','matrix','target')
        data={k:getattr(sampled,k)[None].numpy() for k in keys}
        fp32,fp16=[infer(model,data,settings,mode) for mode in ('fp32','fp16')]
        crop=np.s_[...,48:208,48:208]
        y=[np.einsum('c,bchw->bhw',LUMA,linear_rgb(rgb,data))[crop][0]for rgb in (fp32,fp16)]
        signal_delta=y[1]-y[0]
        measured={'CFA':bayer,'scene':scene,'noise':label,'conditioning':settings,'seed':recipe.noise_seed,
                  'exposure':recipe.exposure,'camera_RGB_difference':error(fp16[crop],fp32[crop]),
                  'column_mean_delta_DN16':float(abs(signal_delta.mean(axis=0)).max())*65535,
                  'peak_column_slope_delta_DN16':float(abs(np.diff(signal_delta.mean(axis=0))).max())*65535}
        rows.append(measured)
    write_json(ROOT/'ramps.json',{'driver':reference(__file__),'checkpoint':checkpoint,
                   'cases':rows,'ROI':[48,48,160,160]})
    print(len(rows),max(r['column_mean_delta_DN16'] for r in rows),
          max(r['peak_column_slope_delta_DN16'] for r in rows),flush=True)


if __name__=='__main__':
    main()
