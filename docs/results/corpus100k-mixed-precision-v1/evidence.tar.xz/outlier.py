"""Render the worst exported-code location on identical native crops."""
import sys
from pathlib import Path

import numpy as np
import tifffile

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from screen import ROOT
sys.path.insert(0,str(Path('.cache/experiments/paired-luminance-detail-v1').resolve()))
from render import native_png


def main():
    source=reference(ROOT/'rgb16-difference.json')
    report=read_json(checked(source))
    runs=[read_json(checked(s)) for s in report['input']]
    x,y=report['worst']['x'],report['worst']['y']
    rect=np.s_[y-80:y+80,x-80:x+80]
    arrays=Path('docs/images/full-corpus-long100k-native-v1/manifest.json')
    original=read_json(checked(reference(arrays)))
    control=next(r for r in original['images'] if r['id']=='main-overcast-sky')
    with np.load(checked(control['provenance']['input_arrays']),allow_pickle=False)as f:
        cal={k:f[k] for k in ('wb','matrix')}
    out=ROOT/'outlier.png'
    pages=[tifffile.memmap(checked(run['RGB16'])) for run in runs]
    panels=[]
    for label,page in zip(('FP32 RGB16','FP16 RGB16'),pages,strict=True):
        raw=page[rect].transpose(2,0,1)[None].astype(float)/65535
        rendered=np.rint(display(raw,cal,exposure=1.)[0].transpose(1,2,0)*255).astype(np.uint8)
        panels.append((label,rendered))
    image=native_png(out,panels)
    write_json(ROOT/'outlier.json',{'driver':reference(__file__),'source':source,'ROI':[x-80,y-80,160,160],
               'display_exposure':1,'board':image})

if __name__=='__main__':
    main()
