"""Build the native main-scene boards from the actual full-frame outputs."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from screen import ROOT

ARCHIVE=Path('docs/images/full-corpus-long100k-native-v1/manifest.json')
CONFIG=Path('configs/gfx-qualitative-20231231.json')
sys.path.insert(0,str(Path('.cache/experiments/paired-luminance-detail-v1').resolve()))
from render import native_png


def main():
    out=ROOT/'main-boards'
    out.mkdir()
    sources=[reference(ROOT/f'first-{mode}.json') for mode in ('fp32','fp16')]
    receipts=[read_json(checked(s)) for s in sources]
    archive=reference(ARCHIVE)
    config=reference(CONFIG)
    regions=read_json(checked(config))['regions']
    items=read_json(checked(archive))['images']
    results=[]
    with np.load(checked(receipts[0]['native_float_RGB']),allow_pickle=False) as fp32, np.load(checked(receipts[1]['native_float_RGB']),allow_pickle=False) as fp16:
        for region in regions:
            key=region['name']
            item=next(x for x in items if x['id']=='main-'+key)
            old=item['provenance']
            with np.load(checked(old['input_arrays']),allow_pickle=False) as f:
                cal={k:f[k] for k in ('wb','matrix')}
            exposure=old['display_exposure']
            assert len(cal['wb'])==len(cal['matrix'])==1
            encode=lambda a:np.rint(display(a[None],cal,exposure=exposure)[0].transpose(1,2,0)*255).astype(np.uint8)
            images=[encode(f[key]) for f in (fp32,fp16)]
            raster=np.asarray(Image.open(checked(item['image'])).convert('RGB'))
            views={p['label']:raster[y:y+h,x:x+w] for p in old['panels'] for x,y,w,h in (p['png_xywh'],)}
            board=native_png(out/(key+'.png'), [('Noisy Malvar',views['Noisy Malvar']),
                                  ('Corpus 100k FP32',images[0]),('Corpus 100k FP16',images[1]),
                                  ('ISO100 AHD reference',views['ISO100 ref, not GT'])])
            delta=(fp16[key].astype(float)-fp32[key])*65535
            results.append({'id':key,'position':region,'exposure':exposure,'source':old,
                         'RMS_camera_DN16':float(np.sqrt(np.mean(delta**2))),'max_abs_DN16':float(abs(delta).max()),
                         'changed_display_pixels':int(np.any(images[0]!=images[1],axis=2).sum()),'board':board})
    write_json(out/'manifest.json',{'driver':reference(__file__),'config':config,'source':archive,'restore':sources,
               'rows':results,'checkpoint':receipts[0]['checkpoint']})

if __name__=='__main__':
    main()
