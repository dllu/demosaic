"""Test FP16 on the fixed panels against archived same-checkpoint IEEE FP32."""
from collections import defaultdict
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.color import render
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.real_suite import measured_sensor_psnr
from screen import MODEL, PRIMARY, ROOT, load, policy, versions

KEYS=('packed','variance','colors','wb','matrix')


def psnr(rgb,target,wb,matrix):
    delta=render(rgb,wb,matrix)-render(target,wb,matrix)
    return -10.*(delta.square().flatten(1).mean(1).clamp_min(1e-12)).log10()


def stats(rows):
    def summary(data):
        values=np.array([r['fp16']-r['cpu_fp32'] for r in data])
        control=[r['fp16']-r['gpu_fp32'] for r in data if 'gpu_fp32' in r]
        return {'count':len(data),'mean_delta_dB':float(values.mean()),
                'abs_p95_dB':float(np.quantile(abs(values),.95)),'max_abs_dB':float(abs(values).max()),
                'min_max_dB':[float(values.min()),float(values.max())],
                'checked_GPU_control_cases':len(control),'GPU_control_abs_max_dB':max(map(abs,control),default=None)}
    photo=[r for r in rows if r['panel']=='photo' and not r['id'].startswith('synthetic-')]
    per_photo=defaultdict(list)
    for row in photo:
        per_photo[row['id']].append(row)
    return {
        'photographic_tiles':summary(photo),
        'photo_source_count':len(per_photo),
        'photo_source_balanced_mean_delta_dB':float(np.mean([np.mean([r['fp16']-r['cpu_fp32'] for r in group]) for group in per_photo.values()])),
        'photo_conditions':{kind:summary([r for r in photo if r['condition']==kind]) for kind in sorted({r['condition'] for r in photo})},
        **{panel:summary([r for r in rows if r['panel']==panel]) for panel in ('known','unseen')},
    }


@torch.inference_mode()
def main():
    import json
    torch.set_num_threads(3)
    torch.cuda.set_per_process_memory_fraction(min(1.,11*2**30/torch.cuda.get_device_properties(0).total_memory))
    source=reference(PRIMARY)
    primary=read_json(checked(source))
    canonical=read_json(checked(primary['canonical_inputs']))
    audited=read_json(checked(primary['source_result']))
    receipts={Path(b['path']).parent.name:b for b in audited['case_records']}
    assert len(receipts)==len(canonical['records'])==3162
    model,checkpoint=load()
    rows=[]
    audit=set()
    started=time.monotonic()
    with (ROOT/'canonical-progress.jsonl').open('x') as progress:
        for i,r in enumerate(canonical['records']):
            stage=r['stage']
            sensor=stage!='photo'
            noise=r['context']['noise' if sensor else 'condition']
            key=(stage,noise.get('name',str(noise['shot'])),r['context']['pattern'])
            bound=receipts[f'{stage}-{r["batch"]:05d}']
            archived=read_json(checked(bound))
            reference_arm=next(v for v in archived['variants'] if v['arm']==MODEL)
            assert archived['canonical_arrays']==r['arrays'] and reference_arm['checkpoint']['sha256']==checkpoint['sha256']
            required=(*KEYS,'sensor_reference','sensor_mask') if sensor else (*KEYS,'target')
            with np.load(checked(r['arrays']),allow_pickle=False) as f:
                data={k:torch.from_numpy(f[k]).cuda() for k in required}
            for k in KEYS[:2]:
                data[k]=data[k].contiguous(memory_format=torch.channels_last)
            border=32 if sensor else 8
            cut=np.s_[...,border:-border,border:-border]
            metric='sensor_psnr' if sensor else 'srgb_psnr'
            model.set_noise(noise['shot'],noise['read'])
            scores={}
            for mode in (('fp16','fp32') if key not in audit or (sensor and r['batch']%5==0) else ('fp16',)):
                with policy(model,mode):
                    value=model(*(data[k] for k in KEYS))
                if sensor:
                    score,_=measured_sensor_psnr(value[cut],data['sensor_reference'][cut],data['sensor_mask'][cut])
                else:
                    score=psnr(value[cut],data['target'][cut],data['wb'],data['matrix'])
                scores[mode]=score.cpu().tolist()
            audit.add(key)
            group=[]
            for j,old in enumerate(reference_arm['rows']):
                assert old['id']==r['context']['ids'][j]
                reference_score=old['metrics'][metric]
                new_score=scores['fp16'][j]
                if reference_score is None:
                    assert not np.isfinite(new_score)
                    continue
                assert np.isfinite(new_score)
                row={'id':old['id'],'panel':stage,'batch':r['batch'],'condition':key[1],
                     'pattern':key[2],'cpu_fp32':reference_score,'fp16':new_score}
                if 'fp32' in scores:
                    row['gpu_fp32']=scores['fp32'][j]
                group.append(row)
            rows.extend(group)
            progress.write(json.dumps({'stage':stage,'batch':r['batch'],'source':r['arrays'],'archive':bound,'scores':group},allow_nan=False)+'\n')
            if i%50==0:
                progress.flush()
                print(i,stage,round(time.monotonic()-started,2),flush=True)
    write_json(ROOT/'canonical.json',{'driver':reference(__file__),'primary':source,'checkpoint':checkpoint,'backend':versions(),
         'elapsed_seconds':time.monotonic()-started,'scored_batches':len(canonical['records']),
         'progress':reference(ROOT/'canonical-progress.jsonl'),'metrics':stats(rows),
         'scope':'Same canonical observations across all three panels. Archived CPU IEEE FP32, GPU FP16, and a stratified matched GPU FP32 subset.'})


if __name__=='__main__':
    main()
