"""Time model loading with the same local cache and differing Hub access."""
import os
import time

import torch

from demosaic.experiments.artifacts import reference, write_json
from screen import ROOT, load, versions


def main():
    torch.set_num_threads(3)
    torch.cuda.init()
    torch.cuda.synchronize()
    t0=time.perf_counter()
    model, checkpoint=load()
    torch.cuda.synchronize()
    elapsed=time.perf_counter()-t0
    offline=os.environ.get('HF_HUB_OFFLINE')=='1'
    write_json(ROOT/('startup-offline.json' if offline else 'startup-online.json'),
               {'driver':reference(__file__),'checkpoint':checkpoint,'model_revision':model.config.dino_revision,
                'seconds':elapsed,'HF_HUB_OFFLINE':offline,'backend':versions()})
    print(offline,model.config.dino_revision,elapsed,flush=True)

if __name__=='__main__':
    main()
