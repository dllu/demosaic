"""Compare all exported integer RGB codes and test overlap bands for error."""
from pathlib import Path

import numpy as np
import tifffile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import positions
from screen import ROOT


def summarize(counts):
    values=np.arange(len(counts),dtype=float)
    total=int(counts.sum())
    cdf=np.cumsum(counts)
    return {'samples':total,'identical_fraction':float(counts[0]/total),
            'within_one_fraction':float(counts[:2].sum()/total),
            'mean_absolute_DN16':float(values@counts/total),
            'rms_DN16':float(np.sqrt((values**2)@counts/total)),
            'percentile_95_99_999_DN16':np.searchsorted(cdf,total*np.array([.95,.99,.999])).tolist(),
            'maximum_DN16':int(np.flatnonzero(counts)[-1])}


def main():
    full=[reference(ROOT/f'first-{mode}.json') for mode in ('fp32','fp16')]
    before,after=[read_json(checked(binding)) for binding in full]
    assert all(before[k]==after[k] for k in ('source','checkpoint','noise','flip','RGB16_shape'))
    a,b=[tifffile.memmap(checked(row['RGB16'])) for row in (before,after)]
    assert a.shape==b.shape and a.dtype==b.dtype==np.uint16
    h,w=a.shape[:2]
    assert before['flip']==0
    tile=512
    overlap=64
    def seams(length):
        coords=positions(length,tile,tile-overlap)
        grid=np.arange(length)
        centers=[(l+r+tile)/2 for l,r in zip(coords[:-1],coords[1:],strict=True)]
        return np.logical_or.reduce([abs(grid-center)<=16 for center in centers])
    nearx,neary=seams(w),seams(h)
    counts=np.zeros(65536,dtype=np.int64)
    overlaps=np.zeros_like(counts)
    per_channel=np.zeros(3,dtype=np.int64)
    worst=(-1,None)
    for y in range(0,h,128):
        old=a[y:y+128]
        new=b[y:y+128]
        delta=new.astype(np.int32)-old
        per_channel+=delta.sum(axis=(0,1))
        error=np.abs(delta)
        counts+=np.bincount(error.ravel(),minlength=counts.size)
        chosen=nearx[None,:]|neary[y:y+128,None]
        overlaps+=np.bincount(error[chosen].ravel(),minlength=counts.size)
        largest=int(error.max())
        if largest>worst[0]:
            iy,ix,c=np.unravel_index(error.argmax(),error.shape)
            worst=(largest,{'x':int(ix),'y':int(iy+y),'channel':int(c),'fp32':int(old[iy,ix,c]),'fp16':int(new[iy,ix,c])})
    assert counts.sum()==a.size
    write_json(ROOT/'rgb16-difference.json',{'driver':reference(__file__),'input':full,'all':summarize(counts),
            'seam_band':summarize(overlaps),'tile_interiors':summarize(counts-overlaps),
            'signed_bias_by_channel_DN16':(per_channel/(h*w)).tolist(),'worst':worst[1],
            'restore_speedup':before['timing']['seconds']/after['timing']['seconds'],
            'raw_to_rgb16_speedup':before['raw_to_rgb16_seconds']/after['raw_to_rgb16_seconds'],
            'seams':'Within 16 pixels of the midpoint of each real overlap along either axis.'})
    print(read_json(ROOT/'rgb16-difference.json')['all'],flush=True)


if __name__=='__main__':
    main()
