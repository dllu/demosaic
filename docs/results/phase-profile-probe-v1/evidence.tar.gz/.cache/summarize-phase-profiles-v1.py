"""Pair each arm against the cached parent and visualize the fixed threshold sweep."""
from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(".cache/experiments/phase-profile-probe-v1").resolve()
report_path = root / "review/result.json"
report = read_json(report_path)
output = root/"diagnosis"
output.mkdir()
by_case = defaultdict(dict)
by_stratum = defaultdict(list)
for value in report["metrics"]:
    by_case[value["id"]][value["method"]] = value
    by_stratum[value["profile"],value["placement"],value["source"],value["method"]].append(value)
assert len(by_case) == 128 and all(len(r)==7 for r in by_case.values())
metrics = ("weak_gain","weak_increment_error_RMS_DN16","query_quiet_RMS_DN16",
           "query_weak_absent_RMS_DN16","query_full_RMS_DN16","strong_gain")
means = {}
for (profile, placement, source, method), rows in by_stratum.items():
    assert len(rows)==4
    means[profile,placement,source,method] = {key:float(np.mean([v[key] for v in rows])) for key in metrics}
rng = np.random.default_rng(20261117)
draws = rng.integers(0,8,(12000,8))
arms = ("sinusoid","phase-profile")
fig, axes = plt.subplots(2,2, figsize=(10,8), layout="constrained")
rows = []
for i, profile in enumerate(("iso400","iso6400")):
    for j, place in enumerate(("far","near")):
        ax = axes[i,j]
        base = np.array([[means[profile,place,source,"V143"][key] for key in metrics] for source in range(8)])
        for arm, color, marker in zip(arms,("#5058b5","#087f65"),("o","^"),strict=True):
            curve = []
            for threshold in (0,2,4):
                values = np.array([[means[profile,place,source,f"{arm}-t{threshold}"][key]
                                    for key in metrics] for source in range(8)])
                delta = values-base
                sample = delta[draws].mean(1)
                lower, upper = np.quantile(sample,[.025,.975],axis=0)
                mean = delta.mean(0)
                curve.append((mean[2],100*mean[0]))
                rows.append({
                    "profile":profile,"placement":place,"shape":arm,"threshold":threshold,
                    "metric_order":list(metrics),"value":values.mean(0).tolist(),
                    "delta_from_parent":mean.tolist(),"paired_source_delta":delta.tolist(),
                    "descriptive_source_bootstrap_interval":[lower.tolist(),upper.tolist()],
                })
            x,y = zip(*curve,strict=True)
            ax.plot(x,y,label={"sinusoid":"Sinusoidal guide","phase-profile":"Phase-bin guide"}[arm],
                    color=color,marker=marker,linewidth=1.5,markersize=5)
            ax.annotate("0",(x[0],y[0]),xytext=(4,4),textcoords="offset points",fontsize=8,color=color)
        ax.axline((0,0),(0,1),color="#9ca3af",linewidth=.8,zorder=0)
        ax.axhline(0,color="#9ca3af",linewidth=.8,zorder=0)
        ax.scatter([0],[0],marker="+",s=45,color="black",zorder=3,label="V143 parent")
        ax.set_title(f"{profile.upper()} · {place} from edge",loc="left",fontweight="semibold",fontsize=11)
        ax.set_xlabel("Query quiet RMS change (DN16)")
        ax.set_ylabel("Weak response change (percentage points)")
        ax.grid(alpha=.15)
        ax.spines[["top","right"]].set_visible(False)
        if i==j==0:
            ax.legend(loc="best",fontsize=8,frameon=False)
fig.suptitle("Weak-wire response versus quiet-region error", fontsize=15,fontweight="semibold")
fig.savefig(output/"quiet-tradeoff.png",dpi=160)
plt.close(fig)
write_json(output/"summary.json",{
    "source_report":reference(report_path),"producer":reference(__file__),
    "plot":reference(output/"quiet-tradeoff.png"),"rows":rows,
    "scope":"Equal four-CFA within-source means then equal eight geometries. Fixed thresholds"
             " 0,2,4. Labels mark unattenuated threshold0. Intervals resample paired geometries;"
             " eight reused shapes and two noise priors give descriptive uncertainty.",
})
