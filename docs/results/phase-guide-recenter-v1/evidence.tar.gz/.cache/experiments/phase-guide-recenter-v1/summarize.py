"""Summarize guide stress and plot the observed quiet-error tradeoffs."""

from collections import defaultdict
from pathlib import Path

import matplotlib
import numpy as np
from matplotlib.lines import Line2D

from demosaic.experiments.artifacts import read_json, reference, write_json

matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
source = root / "review/result.json"
result = read_json(source)
audit = read_json(root / "review/independent-audit.json")
assert audit["status"] == "passed"
METRICS = (
    "weak_gain",
    "strong_gain",
    "quiet_RMS_DN16",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "query_RMS_DN16",
    "abs_weak_absent_projection",
)


def row_values(r):
    return [
        r["weak_gain"],
        r["strong_gain"],
        r["quiet_RMS_DN16"],
        r["delta_from_parent"]["quiet_RMS_DN16"],
        r["weak_increment_RMS_DN16"],
        r["query_RMS_DN16"],
        abs(r["weak_absent_projection"]),
    ]


values = defaultdict(list)
for r in result["metrics"]:
    values[r["profile"], r["placement"], r["method"], r["budget_DN16"], r["arm"]].append(r)
summaries = []
rng = np.random.default_rng(21864)
resample = rng.integers(0, 8, (12_000, 8))
means = {}
for (profile, placement, method, budget, arm), matching in values.items():
    actual = np.array([row_values(r) for r in sorted(matching, key=lambda v: v["source"])])
    assert len(actual) == 8
    means[profile, placement, method, budget, arm] = actual.mean(axis=0)
    data = {
        "profile": profile,
        "placement": placement,
        "method": method,
        "budget_DN16": budget,
        "arm": arm,
        "mean": actual.mean(axis=0).tolist(),
    }
    if arm.endswith("recentered"):
        fixed = values[profile, placement, method, budget, arm.split("-")[0] + "-fixed"]
        controls = np.array([row_values(r) for r in sorted(fixed, key=lambda v: v["source"])])
        paired = actual - controls
        data.update(
            {
                "paired_mean_against_same_offset_fixed": paired.mean(axis=0).tolist(),
                "paired_descriptive_interval": np.quantile(
                    paired[resample].mean(axis=1), [0.025, 0.975], axis=0
                ).tolist(),
                "sources_with_more_weak_response": int((paired[:, 0] > 0).sum()),
                "sources_with_lower_increment_error": int((paired[:, 4] < 0).sum()),
            }
        )
    summaries.append(data)
assert len(summaries) == 96

geometry = defaultdict(list)
for r in result["guides"]:
    if r["role"] == 2:
        geometry[r["profile"], r["placement"], r["arm"]].append(r)
guides = []
for (profile, place, arm), rows in geometry.items():
    assert len(rows) == 16
    before = np.array([r["guide_errors_before"] for r in rows])
    after = np.array([r["guide_errors_after"] for r in rows])
    guides.append(
        {
            "profile": profile,
            "placement": place,
            "arm": arm,
            "mean_errors_before_bins": before.mean(axis=0).tolist(),
            "mean_errors_after_bins": after.mean(axis=0).tolist(),
            "fraction_choices_moved": sum(r["number_moved"] for r in rows) / (2 * len(rows)),
            "both_frequencies_within_quarter_bin": int((after.max(axis=1) <= 0.25).sum()),
            "matched_units": sum(r["matched_units"] for r in rows),
        }
    )
background = defaultdict(list)
for r in audit["background_correction_rows"]:
    background[(r["profile"], r["placement"], r["arm"])].append(
        r["no_wire_delivered_correction_RMS_DN16"]
    )
blank = []
for (profile, place, arm), v in background.items():
    assert len(v) == 8
    blank.append(
        {
            "profile": profile,
            "placement": place,
            "arm": arm,
            "mean_DN16": float(np.mean(v)),
            "max_DN16": float(max(v)),
            "number_above_0p1_DN16": sum(x > 0.1 for x in v),
        }
    )

guide_types = {
    "nominal": ("o", "Nominal"),
    "tangential": ("s", "Tangential 0.5 bin"),
    "radial": ("^", "Radial 1 bin"),
}
colors = {"fixed": "#425ab0", "recentered": "#b54e27"}
fig, axes = plt.subplots(2, 2, figsize=(9.6, 7.6), layout="constrained")
for i, profile in enumerate(("iso400", "iso6400")):
    for j, place in enumerate(("far", "near")):
        ax = axes[i, j]
        for kind, (marker, _) in guide_types.items():
            samples = [
                means[profile, place, "weighted-refit", 0.02, f"{kind}-{fit}"] for fit in colors
            ]
            ax.plot(
                [v[3] for v in samples],
                [100 * v[0] for v in samples],
                color="#999999",
                linewidth=0.85,
            )
            for fit, point in zip(colors, samples, strict=True):
                ax.scatter(
                    point[3], 100 * point[0], marker=marker, color=colors[fit], s=47, zorder=4
                )
        subtitle = "far from edge" if place == "far" else "near edge"
        ax.set_title(f"{profile.upper()} · {subtitle}", loc="left", fontweight="bold")
        ax.set_xlabel("Quiet RMS change from V143 (DN16)")
        ax.set_ylabel("Weak response (%)")
        ax.grid(alpha=0.15)
        ax.spines[["top", "right"]].set_visible(False)
        if (i, j) == (0, 0):
            keys = [
                Line2D([], [], marker="o", linestyle="none", color=c, label=k.capitalize())
                for k, c in colors.items()
            ]
            keys.extend(
                Line2D([], [], marker=m, linestyle="none", color="#555555", label=label)
                for m, label in guide_types.values()
            )
            ax.legend(handles=keys, frameon=False, fontsize=8)
fig.suptitle("Fixed and recentered guides at frozen tight-budget settings", fontweight="bold")
plot = root / "review/guide-stress.png"
fig.savefig(plot, dpi=150)
write_json(
    root / "review/summary.json",
    {
        "source": reference(source),
        "driver": reference(__file__),
        "metrics": list(METRICS),
        "strata": summaries,
        "both_wire_geometry": guides,
        "no_wire_delivery": blank,
        "plot": reference(plot),
        "scope": "Paired source comparisons at frozen thresholds/scales."
        " Error units are native query bins; scene pixels remain at native scale.",
    },
)
for v in summaries:
    if v["method"] == "weighted-refit" and v["budget_DN16"] == 0.02:
        print(v["profile"], v["placement"], v["arm"], np.round(v["mean"], 7).tolist())
