"""Verify perturbations, bounded frequency choices, and native delivered scores."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
result_file = root / "review/result.json"
result = read_json(result_file)
plan = read_json(checked(result["plan"]))
closed = read_json(checked(result["collection"]))
fresh = read_json(checked(plan["fresh_collection"]))
old = read_json(checked(plan["fresh_report"]))
assert len(closed["synthetic"]) == len(fresh["cases"]) == 32
assert closed["new_synthetic_calls"] == 480 and closed["new_camera_calls"] == 8
assert [r["case"] for r in (read_json(checked(x)) for x in closed["synthetic"])] == fresh["cases"]
region = np.s_[..., 128:384, 128:384]
metrics = (
    "quiet_RMS_DN16",
    "weak_gain",
    "strong_gain",
    "query_RMS_DN16",
    "weak_increment_RMS_DN16",
    "weak_absent_projection",
)
rows = defaultdict(list)
for v in result["metrics"]:
    rows[v["id"]].append(v)
nominal = [
    {k: v for k, v in row.items() if k != "arm"}
    for row in result["metrics"]
    if row["arm"] == "nominal-fixed"
]
assert nominal == old["frozen_budget_results"]
checks, largest, directions = 0, 0.0, 0
background_stats = []


def rms(x):
    return float(np.sqrt(np.mean(x * x)) * 65535)


for link in closed["synthetic"]:
    observed = read_json(checked(link))
    case = read_json(checked(observed["case"]))
    name = case["id"]
    assert name == observed["id"] and len(rows[name]) == 24
    guide = np.array(fresh["donors"][case["guide_key"]]["frequencies"])
    axis = guide / np.linalg.norm(guide, axis=1, keepdims=True)
    cross = np.stack((-axis[:, 1], axis[:, 0]), axis=1)
    allowed = np.array(
        [[0, 0], [0.5, 0], [-0.5, 0], [1, 0], [-1, 0], [0, 0.5], [0, -0.5], [0, 1], [0, -1]]
    )
    for label, roles in observed["fits"].items():
        offset, mode = label.split("-")
        expected = plan["offsets_native_bins"][offset]
        sign = np.array([1 - 2 * ((case["source"] + i) % 2) for i in range(2)])
        for fit in roles:
            assert fit["parent_used_for_discovery_or_validation"] is False
            seed = np.array(fit["guide_frequencies_xy"])
            delta = 256 * (seed - guide)
            np.testing.assert_allclose(np.linalg.norm(delta, axis=1), expected, atol=4e-14, rtol=0)
            change_radial = np.einsum("ij,ij->i", delta, axis)
            change_tangential = np.einsum("ij,ij->i", delta, cross)
            np.testing.assert_allclose(
                change_radial, sign * expected if offset == "radial" else 0, atol=4e-14, rtol=0
            )
            np.testing.assert_allclose(
                change_tangential,
                sign * expected if offset == "tangential" else 0,
                atol=4e-14,
                rtol=0,
            )
            start = seed / np.linalg.norm(seed, axis=1, keepdims=True)
            tangent = np.stack((-start[:, 1], start[:, 0]), axis=1)
            assert len(fit["records"]) == 1
            assert fit.get("recenter_phase_guides", False) == (mode == "recentered")
            for vector in np.array(fit["records"][0]["frequencies"]):
                step = 256 * (vector - seed)
                if mode == "fixed":
                    np.testing.assert_array_equal(step, 0)
                else:
                    coord = np.stack(
                        (np.sum(step * start, axis=1), np.sum(step * tangent, axis=1)), axis=1
                    )
                    assert (
                        np.max(
                            np.min(np.linalg.norm(coord[:, None] - allowed[None], axis=2), axis=1)
                        )
                        < 4e-14
                    )
                directions += len(vector)
    with np.load(checked(case["target"])) as a:
        truth = a["target"].astype(np.float64)
        quiet = a["quiet"][region]
    parent = np.load(checked(case["parent"])).astype(np.float64)
    w = (truth[2] - truth[1]).ravel()
    s = (truth[1] - truth[0]).ravel()
    t0 = parent[0][region]
    with (
        np.load(checked(case["predictions"])) as base,
        np.load(checked(observed["output"])) as corrected,
    ):
        for v in rows[name]:
            arm = v["arm"]
            key = f"{v['method']}-t{v['threshold']:g}"
            raw = base[key] if arm == "nominal-fixed" else corrected[f"{arm}--{key}"]
            image = parent.copy()
            image[region] = (1 - v["scale"]) * parent[region] + v["scale"] * raw.astype(np.float64)
            err = image - truth
            detail = (image[2] - image[1]).ravel()
            strong = (image[1] - image[0]).ravel()
            observed_score = np.array(
                [
                    rms(err[region][..., quiet]),
                    detail @ w / (w @ w),
                    strong @ s / (s @ s),
                    rms(err[region]),
                    rms(detail - w),
                    err[1].ravel() @ w / (w @ w),
                ]
            )
            expected_score = np.array([v[k] for k in metrics])
            np.testing.assert_allclose(observed_score, expected_score, atol=4e-10, rtol=0)
            largest = max(largest, float(np.max(abs(observed_score - expected_score))))
            checks += len(metrics)
            if v["budget_DN16"] == 0.02 and v["method"] == "weighted-refit":
                background_stats.append(
                    {
                        "id": name,
                        "profile": case["profile"],
                        "placement": case["placement"],
                        "arm": arm,
                        "no_wire_delivered_correction_RMS_DN16": rms(image[0][region] - t0),
                    }
                )


def pixels(image, panel):
    x, y, w, h = panel["png_xywh"]
    assert (w, h) == (160, 160)
    return image[y : y + h, x : x + w]


copied = 0
for v, original in zip(result["camera"], plan["camera"], strict=True):
    board = original["board"]
    assert v["id"] == board["id"] and v["previous_image"] == board["image"]
    a = np.asarray(Image.open(checked(v["image"])))
    b = np.asarray(Image.open(checked(board["image"])))
    keep = [q for q in v["panels"] if q["label"] != "Recentered weighted"]
    for x, y in zip(keep, board["panels"], strict=True):
        assert x["label"] == y["label"]
        np.testing.assert_array_equal(pixels(a, x), pixels(b, y))
        copied += 1
for v in result["boards"]:
    a, b = [np.asarray(Image.open(checked(v[k]["image"]))) for k in ("board", "triplet")]
    for i, j in enumerate((0, 3, 5)):
        np.testing.assert_array_equal(
            pixels(a, v["board"]["panels"][j]), pixels(b, v["triplet"]["panels"][i])
        )
assert checks == 4608 and directions == 1920 and copied == 96 and len(background_stats) == 192
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(result_file),
        "status": "passed",
        "native_reductions": checks,
        "maximum_absolute_difference": largest,
        "direction_vectors_checked": directions,
        "frozen_nominal_metrics_exact": len(nominal),
        "retained_camera_cells_bitexact": copied,
        "exact_triplet_subsets": 4,
        "background_correction_rows": background_stats,
    },
)
print(checks, directions, copied, largest)
