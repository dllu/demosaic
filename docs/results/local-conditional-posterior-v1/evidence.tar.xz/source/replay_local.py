"""Calibrate and confirm locally ranked weak-side posterior fits."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import conditional
from conditional import OUT, replay
import local_rank
from replay_conditional import configure


def datums(case, profile, parent, f, scene, cut, roi, *, oracle=False):
    colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
    measured = _spacing(scene, colors, *roi[:2], clearance=48)
    exact = np.asarray(case["geometry"]["frequency"])
    peak = exact if oracle else measured
    saved = scene[cut].copy()
    output = {k: parent.copy() for k in replay.ARMS}
    activity = []
    for i, raw in enumerate(f["packed"]):
        scene[cut] = raw
        if i == len(f["packed"]) - 1:
            np.testing.assert_array_equal(measured, _spacing(scene, colors, *roi[:2], clearance=48))
        rank = (None, None) if peak is None else local_rank.rank(
            scene, colors, roi, peak, profile["shot"], profile["read"]
        )
        base, results, receipt = conditional.fit(
            parent[i], replay.ROI, scene, colors, roi, peak, profile, wb, matrix, rank=rank,
        )
        replay.section(output["nested"][i], *replay.ROI)[:] = base
        for k in replay.ARMS[1:]:
            replay.section(output[k][i], *replay.ROI)[:] = results[k]
        activity.append(receipt | {"green_lattice_rank": rank[1]})
    scene[cut] = saved
    return measured, exact, output, activity


def main():
    torch.set_num_threads(2)
    start = monotonic()
    configure()
    replay.datums = datums
    sources = {
        "driver": reference(__file__), "model": reference(conditional.__file__),
        "rank": reference(local_rank.__file__),
    }
    if len(sys.argv) == 1:
        source, rows = replay.load_calibration()
        write_json(OUT / "local-calibration.json", sources | {
            "source": source, "weights": replay.calibration(rows),
            "rows": rows, "seconds": monotonic()-start,
        })
    else:
        cohort = sys.argv[1]
        previous = OUT.with_name("local-bayer-presence-v1")
        if cohort == "fresh":
            replay.PREVIOUS = previous / "fresh"
        lock = reference(OUT / "local-calibration.json")
        src, plan, rows = replay.load_confirmation()
        write_json(
            OUT / f"local-{cohort}.json",
            sources | {"source": src, "plan": plan, "calibration": lock,
                       "rows": rows, "seconds": monotonic() - start},
        )


if __name__ == "__main__":
    main()
