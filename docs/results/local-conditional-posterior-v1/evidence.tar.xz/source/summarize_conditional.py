"""Bootstrap source-level effects and verify the frozen comparison lineage."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from conditional import OUT, replay
from summarize_presence import METRICS, paired


def summarized(rows, arms):
    data = {}
    for arm in arms:
        rowscores = [d["nominal"][arm] for row in rows for d in row["draws"]]
        data[arm] = {k: mean(d[k] for d in rowscores if k in d) for k in METRICS if any(k in d for d in rowscores)}
    return data


def matched_rank(rows):
    scores = [d["activity"][0]["weak"] for row in rows for d in row["draws"]]
    return {"present_crops": len(scores), "ambiguous": scores.count(None), "planted_weak_rank": scores.count(1), "other": scores.count(0)}


def main():
    policy = reference(OUT / "weak-dose-calibration.json")
    calibration = read_json(checked(policy))
    choices = calibration["weights"]["best"]
    locked = ("nested", *choices.values())
    assert all(calibration["weights"]["choices"][x]["weight"] == 1 for x in choices.values())
    previous = OUT.with_name("local-bayer-presence-v1")
    sources = {
        "retained": "retained-weak-dose.json", "previous": "previous-weak-dose.json",
        "confirmation": "confirmation-weak-dose.json", "extra_strong_harmonics": "confirmation-weak-dose-harmonics.json",
    }
    panels = {}
    for label, path in sources.items():
        binding = reference(OUT / path)
        source = read_json(checked(binding))
        rows = source["rows"]
        assert source["calibration"] == policy
        panels[label] = {
            "source": binding, "rank": matched_rank(rows),
            "means": summarized(rows, ("local50k", *locked)),
            "paired_vs_combined": {k: paired(rows, (name, 1), ("nested", 1)) for k, name in choices.items()},
            "unwanted_changes": {
                name: {
                    k: {
                        "count": sum(x > 0 for x in scores),
                        "max_DN16": max(scores),
                    }
                    for k in ("flat_added_DN16", "edge_update_RMS_DN16", "uniform_update_RMS_DN16")
                    for scores in [[d["nominal"][name][k] for row in rows for d in row["draws"]]]
                }
                for name in locked
            },
        }
    old = reference(previous / "fresh-guarded.json")
    prior = read_json(checked(old))["cases"]
    current = read_json(checked(panels["previous"]["source"]))["rows"]
    for a, b in zip(prior, current, strict=True):
        assert a["id"] == b["id"]
        for one, two in zip(a["draws"], b["draws"], strict=True):
            assert one["input"] == two["input"]
            for m, v in one["nominal"]["nested"].items():
                np.testing.assert_allclose(v, two["nominal"]["nested"][m], rtol=1e-11, atol=1e-9)
    panels["previous"]["joint_ring_reference"] = summarized(prior, ("ring_phase_6_0.2",))
    first_rank_attempt = reference(OUT / "calibration.json")
    exterior = read_json(checked(first_rank_attempt))["rows"]
    write_json(OUT / "summary.json", {
        "driver": reference(Path(__file__)), "calibration": policy, "selection": choices,
        "exterior_only_calibration": first_rank_attempt,
        "exterior_only_rank": matched_rank(exterior), "local_calibration_rank": matched_rank(calibration["rows"]),
        "joint_reference": old, "panels": panels,
    })


if __name__ == "__main__":
    main()
