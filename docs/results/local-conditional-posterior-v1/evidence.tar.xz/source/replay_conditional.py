"""Calibrate and replay the weak-only posterior on fixed optical recipients."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing

import conditional
from conditional import OUT, replay


def datums(case, profile, parent, f, scene, cut, roi, *, oracle=False):
    colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
    measured = _spacing(scene, colors, *roi[:2], clearance=48)
    exact = np.asarray(case["geometry"]["frequency"])
    peak = exact if oracle else measured
    saved = scene[cut].copy()
    rank = None if peak is None else conditional.donor_rank(
        scene, colors, roi, peak, profile["shot"], profile["read"], 48
    )
    output = {k: parent.copy() for k in replay.ARMS}
    activity = []
    for i, raw in enumerate(f["packed"]):
        scene[cut] = raw
        if i == len(f["packed"]) - 1:
            np.testing.assert_array_equal(measured, _spacing(scene, colors, *roi[:2], clearance=48))
            if peak is not None:
                verify = conditional.donor_rank(
                    scene, colors, roi, peak, profile["shot"], profile["read"], 48,
                )
                np.testing.assert_equal(rank, verify)
        base, results, receipt = conditional.fit(
            parent[i], replay.ROI, scene, colors, roi, peak, profile, wb, matrix, rank=rank,
        )
        replay.section(output["nested"][i], *replay.ROI)[:] = base
        for k in replay.ARMS[1:]:
            replay.section(output[k][i], *replay.ROI)[:] = results[k]
        activity.append(receipt)
    scene[cut] = saved
    return measured, exact, output, activity


def configure():
    replay.OUT = OUT
    replay.datums = datums
    replay.presence = conditional
    conditional.MODES = conditional.METHOD
    replay.ARMS = ("nested", *conditional.ARMS)


def main():
    torch.set_num_threads(2)
    start = monotonic()
    configure()
    if len(sys.argv) == 1:
        source, rows = replay.load_calibration()
        weights = replay.calibration(rows)
        write_json(
            OUT / "calibration.json",
            {"driver": reference(__file__), "source": source, "model": reference(conditional.__file__),
             "weights": weights, "rows": rows, "seconds": monotonic() - start},
        )
    else:
        cohort = sys.argv[1]
        raw = OUT.with_name("local-bayer-presence-v1")
        replay.PREVIOUS = raw / "fresh" if cohort == "fresh" else OUT.with_name("local-nested-support-v1")
        lock = reference(OUT / "calibration.json")
        plan = read_json(checked(lock))["weights"]
        if cohort == "fresh":
            replay.ARMS = ("nested", *plan["best"].values())
        source, observation_plan, rows = replay.load_confirmation()
        write_json(
            OUT / f"{cohort}.json",
            {"driver": reference(Path(__file__)), "source": source, "plan": observation_plan,
             "model": reference(conditional.__file__), "calibration": lock, "rows": rows,
             "seconds": monotonic() - start},
        )


if __name__ == "__main__":
    main()
