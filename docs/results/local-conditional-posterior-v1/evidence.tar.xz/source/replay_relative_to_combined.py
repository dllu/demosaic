"""Measure every dose relative to the fixed combined fit, retaining its strong strand."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from conditional import OUT, replay
import replay_local as driver


def comparisons(case, profile, parent, inputs, scene, cut, roi, sharp, *, oracle=False):
    estimated, exact, output, activities = driver.datums(
        case, profile, parent, inputs, scene, cut, roi, oracle=oracle,
    )
    support = replay.support_for_scoring(inputs["support"])
    geometry = case["geometry"]
    clean = replay.WireFundamental(
        {"target": sharp, "support": support, "wb": inputs["wb"], "matrix": inputs["matrix"]},
        geometry,
    )
    optical = replay.WireFundamental(
        inputs | {"target": inputs["target"][:4], "support": support},
        geometry,
    )
    raw_parent = parent.astype("d")
    matched_base = output["nested"].astype("d")
    region = np.s_[..., 64:192, 64:192]

    def measure(rgb):
        diff = ((rgb[3:4] - raw_parent[3:4]))[region]
        flat = replay.luma(diff, inputs["wb"], inputs["matrix"])
        other = replay.null_measures(rgb, raw_parent, inputs) if len(rgb) == 6 else {}
        return {
            **optical(rgb[:4]),
            replay.ABSOLUTE: clean(rgb[:4])[replay.LENGTH],
            "flat_added_DN16": float(np.sqrt(np.mean(flat**2)) * 65535),
            **other,
        }

    base = measure(matched_base)
    curves = {}
    for key, image in output.items():
        step = image - matched_base
        positive, negative = measure(matched_base + step), measure(matched_base - step)
        curves[key] = {}
        for metric, b in base.items():
            p, n = positive[metric], negative[metric]
            curves[key][metric] = (
                (b, (p - n) / 2) if metric in replay.LINEAR else
                (b*b, (p*p - n*n) / 2, (p*p + n*n) / 2 - b*b)
            )
    return {
        "fixed_guide": None if estimated is None else estimated.tolist(),
        "exact_guide": exact.tolist(),
        "powers": curves,
        "activity": activities,
        "nominal": {"local50k": measure(raw_parent), **{
            key: replay.metrics_at(s, 1) for key, s in curves.items()
        }},
    }


def main():
    torch.set_num_threads(2)
    start = monotonic()
    driver.configure()
    replay.comparisons = comparisons
    cohort = sys.argv[1] if len(sys.argv) > 1 else None
    harmonic = "--harmonics" in sys.argv
    if harmonic:
        import conditional_harmonics
        driver.conditional = conditional_harmonics
    proofs = {
        "driver": reference(Path(__file__)),
        "matched_driver": reference(driver.__file__),
        "model": reference(driver.conditional.__file__),
        "rank": reference(driver.local_rank.__file__),
        "dose_reference": "combined-check output",
    }
    if cohort is None:
        source, rows = replay.load_calibration()
        lock = replay.calibration(rows)
        write_json(OUT / "weak-dose-calibration.json", proofs | {
            "source": source, "weights": lock, "rows": rows, "seconds": monotonic() - start,
        })
        return
    if cohort == "previous":
        replay.PREVIOUS = OUT.with_name("local-bayer-presence-v1") / "fresh"
    elif cohort == "confirmation":
        replay.PREVIOUS = OUT / "fresh"
    elif cohort != "retained":
        raise ValueError(cohort)
    binding = reference(OUT / "weak-dose-calibration.json")
    lock = read_json(checked(binding))["weights"]
    replay.ARMS = ("nested", *lock["best"].values())
    source, plan, rows = replay.load_confirmation()
    dest = f"{cohort}-weak-dose" + ("-harmonics" if harmonic else "")
    write_json(OUT / f"{dest}.json", proofs | {
        "source": source, "plan": plan, "calibration": binding,
        "rows": rows, "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
