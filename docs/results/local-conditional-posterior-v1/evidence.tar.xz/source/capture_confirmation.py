"""Freeze source-disjoint optical recipients and reuse the calibrated RAW capture."""

from pathlib import Path
import sys
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name / "fresh"
DATA = OUT.parent.parent
sys.path.insert(0, str(HERE.with_name("local-nested-support-v1")))
import freeze_nested as earlier
import replay_nested_parents as parents

EXCLUSIONS = (
    DATA / "local-nested-support-v1/plan.json",
    DATA / "local-bayer-presence-v1/fresh/plan.json",
    DATA / "local-carrier-envelope-v1/plan.json",
    DATA / "cfa-relative-phase-v1/master.json",
    DATA / "cfa-predictive-covariance-v1/lightstep/sources.json",
)


def freeze():
    refs = [reference(p) for p in EXCLUSIONS]
    blocked = set()
    capture = earlier.capture_wide
    for binding in refs:
        capture.scan(read_json(checked(binding)), blocked)
    original = capture.lines
    source_pool = read_json(checked(refs[0]))["source_pool"]

    def filtered(binding):
        rows = original(binding)
        if binding != source_pool:
            yield from rows
        else:
            for item in rows:
                if {item["id"], item["cache_sha256"]}.isdisjoint(blocked):
                    yield item

    earlier.COUNT, earlier.GROUP_SIZE, earlier.SEED = 24, 6, 202611200404
    capture.lines = filtered
    try:
        plan = earlier.choose()
    finally:
        capture.lines = original
    plan["driver"] = reference(__file__)
    plan["capture_source"] = reference(earlier.__file__)
    plan["extra_excluded_sources"] = refs
    plan["primary"] = "Source-disjoint confirmation at aid and false-detail levels frozen on the earlier calibration photos."
    plan["hypothesis"] = "Replacing only the weaker fit can recover more faint detail while preserving the continuing strong strand."
    plan["native_indices"] = [1, 9]
    for row in plan["sources"]:
        assert {row["source"]["id"], row["source"]["cache_sha256"]}.isdisjoint(blocked)
        row["id"] = row["id"].replace("nested-", "weak-side-")
    return plan


def main():
    torch.set_num_threads(2)
    OUT.mkdir(exist_ok=True)
    start = monotonic()
    plan_path = OUT / "plan.json"
    if not plan_path.is_file():
        write_json(plan_path, freeze())
    plan = read_json(plan_path)
    assert plan["driver"] == reference(__file__)
    earlier.SEED = plan["seed"]
    destination = OUT / "inputs"
    destination.mkdir(exist_ok=True)
    input_receipt = OUT / "inputs.json"
    if not input_receipt.is_file():
        observed = []
        for case in plan["sources"]:
            observed.append(earlier.capture(case, plan["noise"], destination))
            if len(observed) % 8 == 0:
                print("captured", len(observed), flush=True)
        write_json(input_receipt, {
            "driver": reference(__file__), "plan": reference(plan_path),
            "observations": observed, "seconds": monotonic() - start,
        })
    parents.OUT = OUT
    parents.main()


if __name__ == "__main__":
    main()
