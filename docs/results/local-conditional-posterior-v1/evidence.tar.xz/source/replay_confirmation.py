"""Run locked carrier comparisons on the new validation sources."""

import sys
from pathlib import Path
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from conditional import OUT, replay
import replay_local as driver

def main():
    torch.set_num_threads(2)
    start = monotonic()
    driver.configure()
    replay.datums = driver.datums
    defense = "--harmonics" in sys.argv
    if defense:
        import conditional_harmonics
        driver.conditional = conditional_harmonics
    replay.PREVIOUS = OUT / "fresh"
    lock = reference(OUT / "local-calibration.json")
    policy = read_json(checked(lock))["weights"]
    replay.ARMS = ("nested", *policy["best"].values())
    source, plan, rows = replay.load_confirmation()
    write_json(OUT / ("confirmation-harmonics.json" if defense else "confirmation.json"), {
        "driver": reference(Path(__file__)), "model": reference(driver.conditional.__file__),
        "rank": reference(driver.local_rank.__file__), "calibration": lock,
        "source": source, "plan": plan, "rows": rows, "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
