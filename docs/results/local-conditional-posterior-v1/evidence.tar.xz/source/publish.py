"""Publish source-bound weak-only comparisons and native review boards."""

from pathlib import Path
import hashlib
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
ID = "local-conditional-posterior-v1"
OUT = Path("/mnt/external/demosaic") / ID
SRC = ROOT / ".cache/experiments" / ID
IMAGES = ROOT / "docs/assets" / ID
RESULT = ROOT / "docs/results" / ID
RECEIPTS = (
    "calibration.json", "local-calibration.json", "local-retained.json", "local-fresh.json",
    "confirmation.json", "confirmation-harmonics.json",
    "weak-dose-calibration.json", "previous-weak-dose.json", "retained-weak-dose.json",
    "confirmation-weak-dose.json", "confirmation-weak-dose-harmonics.json",
    "fresh/plan.json", "fresh/inputs.json", "fresh/parent/result.json",
    "native-camera.json", "native-exact.json", "api-proof.json", "summary.json", "tradeoff.json",
)


def copy_image(binding):
    source = checked(binding)
    target = IMAGES / source.name
    shutil.copyfile(source, target)
    new = reference(target)
    assert new["sha256"] == binding["sha256"]
    return new | {"path": str(target.relative_to(ROOT))}


def copy_board(data):
    link = copy_image(data["image"])
    with Image.open(ROOT / link["path"]) as image:
        for panel in data["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= image.width and 0 <= y < y + h <= image.height
    return data | {"image": link}


def main():
    IMAGES.mkdir(exist_ok=True, parents=True)
    RESULT.mkdir(exist_ok=True, parents=True)
    records = {k: reference(OUT / k) for k in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in records.items()}
    for row in data.values():
        for key in ("driver", "model", "rank", "operator", "api", "matched_driver"):
            if key in row:
                checked(row[key])
    assert data["native-exact.json"]["calibration"] == records["weak-dose-calibration.json"]
    assert data["native-camera.json"]["calibration"] == records["weak-dose-calibration.json"]
    assert data["api-proof.json"]["source"] == records["confirmation-weak-dose.json"]
    assert data["api-proof.json"]["maximum_difference_DN16"] < 0.002
    source = data["fresh/parent/result.json"]
    assert source["inputs"] == records["fresh/inputs.json"]
    assert data["fresh/inputs.json"]["plan"] == records["fresh/plan.json"]
    for p in source["records"]:
        for draw in p["streams"]:
            checked(draw["data"])
            for r in draw["outputs"].values():
                checked(r)

    evidence = {f"receipts/{name}": binding for name, binding in records.items()}
    evidence.update({f"source/{file.name}": reference(file) for file in sorted(SRC.glob("*.py"))})
    for f in ("src/demosaic/mesh_carrier_fit.py", "src/demosaic/_mesh_weak_posterior.py", "tests/test_mesh_carrier_fit.py"):
        evidence[f] = reference(ROOT / f)
    prior = reference(ROOT / "docs/results/local-bayer-presence-v1/publication.json")
    archive = RESULT / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for k, v in evidence.items():
            tar.add(checked(v), arcname=k, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == evidence.keys()
        for k, v in evidence.items():
            with tar.extractfile(k) as blob:
                assert hashlib.file_digest(blob, "sha256").hexdigest() == v["sha256"], k

    exact = [
        r | {"board": copy_board(r["board"]), "triplet": copy_board(r["triplet"])}
        for r in data["native-exact.json"]["data"]["boards"]
    ]
    real = [
        r | {"native": [copy_board(b) for b in r["native"]]}
        for r in data["native-camera.json"]["data"]["rows"]
    ]
    crop_manifest = IMAGES / "manifest.json"
    write_json(crop_manifest, {
        "synthetic": exact, "camera": real, "chart": copy_image(data["tradeoff.json"]["image"]),
    })
    summary = RESULT / "summary.json"
    shutil.copyfile(checked(records["summary.json"]), summary)
    assert reference(summary)["sha256"] == records["summary.json"]["sha256"]
    write_json(RESULT / "publication.json", {
        "source_revision_parent": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "archive": reference(archive), "summary": reference(summary), "native_manifest": reference(crop_manifest),
        "prior_publication": prior, "original_receipts": records, "members": evidence,
        "synthetic_native_comparisons_viewed": len(exact), "native_triplets_viewed": len(exact),
        "standing_native_comparisons_viewed": sum(len(r["native"]) for r in real), "new_weights": None,
    })


if __name__ == "__main__":
    main()
