"""Review both standing photo families and two new exact native crops."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
import conditional
from conditional import OUT, replay
import local_rank
import review_presence as prior

NAMES = {
    "parent": "Local 50k",
    "nested": "Combined check",
    "joint": "Joint ring posterior",
    "ring_phase": "Weak-only posterior",
    "phase": "Phase-aligned weak",
}
SELECTED = ("weak-side-01", "weak-side-09")


def arcs(parent, local, scene, colors, roi, frequencies, noise, wb, matrix, policy):
    camera = local == roi
    clearance = 16 if camera else 48
    measured = None if frequencies is None else np.asarray(frequencies)
    rank = (None, None) if measured is None else local_rank.rank(
        scene, colors, roi, measured, noise["shot"], noise["read"],
    )
    base, options, info = conditional.fit(
        parent, local, scene, colors, roi, measured, noise, wb, matrix, clearance=clearance, rank=rank,
    )
    inherited = prior.section(parent, *local)
    joint = refine_raw_mesh_carriers(
        inherited, scene, colors, roi, shot=noise["shot"], read=noise["read"],
        white_balance=wb, camera_to_srgb=matrix, method="ring-posterior", donor_clearance=clearance,
    )
    frozen = {"parent": inherited, "nested": base, "joint": joint}
    for group, actual in policy["best"].items():
        key = "ring_phase" if group == "free" else group
        weight = policy["choices"][actual]["weight"]
        frozen[key] = (base.astype("d") + weight * (options[actual].astype("d") - base)).astype(base.dtype)
    if "arms" in info:
        info["arms"] = {k: info["arms"][v] for k, v in policy["best"].items()}
    return frozen, info


def exact(policy, native):
    binding = reference(OUT / "confirmation-weak-dose.json")
    b = read_json(checked(binding))
    plan = read_json(checked(b["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + replay.ROI[0], y + replay.ROI[1], *replay.ROI[2:])
    rendered = []
    for row in b["rows"]:
        if row["id"] not in SELECTED:
            continue
        record = row["draws"][0]
        fields = replay.arrays(record["input"])
        parent = np.load(checked(record["outputs"]["local50k"]))[0]
        v120 = np.load(checked(record["outputs"]["v120"]))[0]
        scene = fields["scene_packed"].copy()
        scene[:, y//2:(y+h)//2, x//2:(x+w)//2] = fields["packed"][0]
        colors, wb, matrix = (fields[k] for k in ("colors", "wb", "matrix"))
        arms, detail = arcs(parent, replay.ROI, scene, colors, roi, record["fixed_guide"], plan["noise"], wb, matrix, policy)
        inputs = {k: fields[k][None] for k in ("colors", "wb", "matrix")}
        inputs["packed"] = fields["packed"][:1]
        images = [noisy_malvar(inputs)[0], v120]
        for crop in arms.values():
            filled = parent.copy()
            prior.section(filled, *replay.ROI)[:] = crop
            images.append(filled)
        images.append(fields["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(NAMES[k] for k in arms), "Exact GT"]
        rendered.append(prior.native_board(
            native, row["id"], images, inputs,
            {"input": record["input"], "fixture": row["fixture"], "query": plan["query"],
             "noise": plan["noise"], "weights": plan["checkpoints"], "optical_sigma": plan["sigma"],
             "draw": 0, "evidence": detail},
            labels=labels, triplet_indices=(0, labels.index(NAMES["ring_phase"]), len(labels)-1),
        ))
    assert len(rendered) == 2
    return {"source": binding, "boards": rendered}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    camera_only = "--camera" in sys.argv
    policy = reference(OUT / "weak-dose-calibration.json")
    values = read_json(checked(policy))["weights"]
    native = OUT / "native" / ("camera" if camera_only else "exact")
    native.mkdir(parents=True, exist_ok=True)
    prior.arcs, prior.NAMES = arcs, NAMES
    reviewed = (prior.standing if camera_only else exact)(values, native)
    write_json(OUT / ("native-camera.json" if camera_only else "native-exact.json"), {
        "driver": reference(Path(__file__)), "calibration": policy,
        "data": reviewed, "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
