"""Hold the stronger correction fixed while fitting the weaker phase."""

from itertools import product
from pathlib import Path
import sys

import numpy as np
from scipy.special import expit

from demosaic._mesh_presence import (
    _CENTER_BACKGROUND,
    _CENTER_PIXELS,
    _CORE,
    _PACKED_CORE,
    _RING,
    _SMOOTH,
    _evidence,
    _ring_prior,
)
from demosaic._mesh_pooled import _STRIDE, _footprint, _rgb, _wave, _windows
from demosaic.mesh_carrier_fit import _DONOR, _ROI_SIZE, _WINDOW, _positions, _sites

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("local-bayer-presence-v1")))
import replay_presence as replay
from nested_gate import CenterGuard, OFFSET, POLICIES, WIDTH, fields, unpack

OUT = Path("/mnt/external/demosaic") / HERE.name
ODDS = (-7.0, -6.0, -5.0, -4.0, -3.0)
GUARD = (None, 0.5, 1.5)
METHOD = ("free", "phase")
FORMS = tuple(
    (method, odds, threshold, f"{method}_{-odds:g}_{'no_guard' if threshold is None else f'{threshold:g}'}")
    for method, odds, threshold in product(METHOD, ODDS, GUARD)
)
ARMS = tuple(form[-1] for form in FORMS)


def donor_rank(scene, colors, roi, frequencies, shot, read, clearance):
    """Require the exterior patches on both green lattices to rank the pair alike."""
    x, y, _, _ = roi
    boxes = (
        (x - _DONOR - clearance, y + 16),
        (x + _ROI_SIZE + clearance, y + 16),
        (x + 16, y - _DONOR - clearance),
        (x + 16, y + _ROI_SIZE + clearance),
    )
    y, x = np.indices((_DONOR, _DONOR), dtype="d") / _DONOR - 0.5
    nuisance = np.stack((np.ones_like(x), x, y, x*y, x*x, y*y), axis=-1)
    wave = _wave(_DONOR, frequencies).reshape(_DONOR, _DONOR, 4)
    powers = []
    for xo, yo in boxes:
        powers.append([])
        for pos in _positions(colors, xo, yo):
            r, c = pos
            origin = _sites(scene, xo, yo, _DONOR, r, c)
            smooth = nuisance[r::2, c::2].reshape((-1, nuisance.shape[-1]))
            design = wave[r::2, c::2].reshape(-1, 4)
            residual = design - smooth @ (np.linalg.pinv(smooth, rcond=1e-8) @ design)
            gram = residual.T @ residual
            inverse = np.linalg.inv(gram)
            weights = (inverse @ (origin.reshape(-1) @ residual)).reshape(2, 2)
            noise = max(2e-11, read + shot * max(0, float(origin.mean())))
            variance = noise * inverse.diagonal().reshape(2, 2).sum(axis=1)
            powers[-1].append(np.maximum(0, np.sum(weights**2, axis=1) - variance))
    average = np.median(powers, axis=0)
    ranked = average.argmax(axis=1)
    if ranked[0] == ranked[1] and all(average[:, ranked[0]] > 1.25 * average[:, 1-ranked[0]]):
        return 1 - int(ranked[0]), average.tolist()
    return None, average.tolist()


def carrier_terms(wave, nuisance, observed, positions, keep):
    values = []
    for inputs, (y, x) in zip(observed, positions, strict=True):
        mask = keep[y::2, x::2]
        design = wave[y::2, x::2][mask]
        b = nuisance[y::2, x::2][mask]
        inverses = np.linalg.pinv(b, rcond=1e-8)
        residual = design - b @ (inverses @ design)
        data = inputs[:, mask]
        values.append((residual, data, b, inverses, design))
    return tuple(values)


def condition(terms, shot, read):
    grams, moments = [], []
    for design, raw, _, _, _ in terms:
        fit_variance = np.maximum(2e-11, shot * np.maximum(0, raw.mean(axis=1)) + read)
        inverse = 1 / fit_variance
        grams.append(inverse[:, None, None] * (design.T @ design))
        moments.append(inverse[:, None] * (raw @ design))
    return tuple(grams), tuple(moments)


def held_score(terms, first, other, update, shot, read):
    x, raw, b, project, initial = terms[first]
    y, held, c, _, future = terms[other]
    residual = held - (raw @ project.T) @ c.T
    prediction = future - c @ (project @ initial)
    lift = update @ prediction.T
    sigma = np.maximum(2e-11, shot * np.maximum(0, raw.mean(axis=-1)) + read)
    return np.sum((2 * residual - lift) * lift, axis=1) / sigma


def conditional_posterior(gram, moment, prior_mean, precision):
    """Compute the Gaussian slab estimator and its evidence against zero."""
    location = moment + (precision @ prior_mean[..., None])[..., 0]
    system = gram + precision
    fitted = np.linalg.solve(system, location[..., None])[..., 0]
    _, logdet = np.linalg.slogdet(system)
    _, prior_logdet = np.linalg.slogdet(precision)
    return fitted, 0.5 * (
        prior_logdet - logdet + np.sum(location * fitted, axis=1)
        - np.einsum("ni,nij,nj->n", prior_mean, precision, prior_mean)
    )


def prior_shape(mean, sd, method):
    variance = sd**2
    eye = np.eye(2)
    if method == "free":
        return eye / variance[:, None, None]
    norm = np.linalg.norm(mean, axis=1)
    unit = mean / norm.clip(min=1e-12)[:, None]
    confidence = np.clip(norm / sd, 0, 1)
    # When the ring has no measurable phase the slab is isotropic.
    narrow = sd * (1 - 0.60 * confidence)
    outer = np.einsum("ni,nj->nij", unit, unit)
    return eye / narrow[:, None, None] + outer * (1 / variance - 1 / narrow**2)[:, None, None]


def combined(parent, camera, colors, roi, frequencies, shot, read):
    """Recover the old combined check's directional coefficients before tapering."""
    x, y = roi[:2]
    raw = unpack(camera)
    operator = CenterGuard(colors, x, y, frequencies)
    broad = _windows(parent[1], _WINDOW, _STRIDE)
    wave = operator.wave
    estimated = []
    for dy in range(0, _ROI_SIZE - WIDTH + 1, _STRIDE):
        for dx in range(0, _ROI_SIZE - WIDTH + 1, _STRIDE):
            px, py = x + dx - OFFSET, y + dy - OFFSET
            tile = raw[py:py+_WINDOW, px:px+_WINDOW].astype("d")
            a, b = (operator.fold(tile, side, shot, read) for side in (0, 1))
            g = fields(a, b, POLICIES)["nested"]
            f = 0.5 * (a["broad"][0] + b["broad"][0])
            old = (operator.outer_parent_fit @ broad[len(estimated)].ravel()).reshape(2, 2)
            delta = g[:, None] * (f - old)
            limit = np.linalg.norm(f, axis=-1)
            delta *= np.minimum(1, limit / np.linalg.norm(delta, axis=-1).clip(min=1e-12))[:, None]
            estimated.append(delta)
    return wave, np.stack(estimated)


def fit(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, clearance=48, rank=None):
    x, y = local[:2]
    prior = parent[:, y:y+160, x:x+160]
    base, activity = replay.nested_apply(
        parent, local, scene, colors, roi, frequency, noise | {"wb": wb, "matrix": matrix},
    )
    base = base["nested"]
    if frequency is None:
        return base, {k: base for k in ARMS}, {"weak": None}
    shot, read = noise["shot"], noise["read"]
    ranked = donor_rank(scene, colors, roi, frequency, shot, read, clearance) if rank is None else rank
    weak, power = ranked
    if weak is None:
        return base, {k: base for k in ARMS}, {"weak": None, "donor_power": power}

    support = parent[:, y-16:y+176, x-16:x+176]
    # The old and new estimators share the absolute carrier origin.
    design, former = combined(support, scene, colors, roi, frequency, shot, read)
    old = former[:, weak]
    sites = _positions(colors, *roi[:2])
    greens = tuple(_footprint(scene, roi[:2], pos) for pos in sites)
    windows = tuple(_windows(data, _WINDOW//2, _STRIDE//2) for data in greens)
    wave = _wave(_WINDOW, frequency).reshape(_WINDOW, _WINDOW, 4)
    ring_mean, width = _ring_prior(*_evidence(windows, sites, wave, _SMOOTH, _RING, shot, read))
    core = wave[_CORE].reshape(32, 32, 2, 2)
    weak_wave, strong_wave = core[..., weak, :], core[..., 1-weak, :]
    np.testing.assert_allclose(core, design, rtol=1e-13, atol=1e-13)
    bg = np.concatenate((_CENTER_BACKGROUND, strong_wave), axis=-1)
    center = tuple(g[:, _PACKED_CORE, _PACKED_CORE] for g in windows)
    terms = carrier_terms(weak_wave, bg, center, sites, _CENTER_PIXELS)
    gram, moment = condition(terms, shot, read)
    total_gram, total_moment = sum(gram), sum(moment)
    center_coeff = np.linalg.solve(total_gram, total_moment[..., None])[..., 0]
    cap = np.linalg.norm(center_coeff, axis=1)
    template = np.concatenate((bg, weak_wave), axis=-1).reshape(32**2, -1)
    inverse = np.linalg.pinv(template, rcond=1e-8)[-2:]
    original = _windows(prior[1], 32, _STRIDE).reshape(-1, 32**2)
    existing = original @ inverse.T
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    m = ring_mean.reshape(-1, 2, 2)[:, weak]
    estimation, diagnostics = {}, {}
    for method in METHOD:
        precision = prior_shape(m, width[:, weak], method)
        center_beta, center_evidence = conditional_posterior(total_gram, total_moment, m, precision)
        held = np.stack([
            held_score(terms, i, 1-i, conditional_posterior(gram[i], moment[i], m, precision)[0], shot, read)
            for i in (0, 1)
        ])
        evidence = np.min(held, axis=0)
        for kind, odds, threshold, key in FORMS:
            if kind != method:
                continue
            probability = expit(center_evidence + odds)
            strength = np.clip((probability - 0.2) / 0.8, 0, 1)
            delta = (center_beta - existing) * strength[:, None]
            delta *= np.minimum(1, strength * cap / np.linalg.norm(delta, axis=1).clip(min=1e-15))[:, None]
            use = strength > 0
            if threshold is not None:
                use &= evidence > threshold
            # Existing weaker coefficients remain on rejected windows. The stronger
            # correction stays identical for every window and every comparison.
            update = np.where(use[:, None], delta - old, 0)
            patch = np.einsum("yxf,nf->nyx", weak_wave, update)
            estimation[key] = base + _rgb(patch, neutral, base.dtype)
            diagnostics[key] = {"delivered_windows": int(use.sum()), "max_probability": float(probability.max())}
    return base, estimation, {"weak": weak, "donor_power": power, "legacy": activity, "arms": diagnostics}
