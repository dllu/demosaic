"""Verify the deployed crop operation against the frozen research arm."""

from pathlib import Path
from statistics import median
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers, _spacing
import conditional
import local_rank
from conditional import OUT, replay
from review_presence import FIXED, section


def verify(parent, local, scene, colors, roi, noise, wb, matrix, clearance, name):
    x, y, w, h = local
    p = section(parent, *local)
    context = parent[:, y-16:y+h+16, x-16:x+w+16]
    frequency = _spacing(scene, colors, *roi[:2], clearance=clearance)
    order = (None, None) if frequency is None else local_rank.rank(
        scene, colors, roi, frequency, noise["shot"], noise["read"]
    )
    _, baseline, _ = conditional.fit(
        parent, local, scene, colors, roi, frequency, noise, wb, matrix, clearance=clearance, rank=order,
    )
    start = monotonic()
    packaged = refine_raw_mesh_carriers(
        p, scene, colors, roi, shot=noise["shot"], read=noise["read"], white_balance=wb,
        camera_to_srgb=matrix, method="weak-posterior", parent_context=context, donor_clearance=clearance,
    )
    elapsed = monotonic()-start
    difference = packaged.astype("d") - baseline[name]
    error = float(np.max(abs(difference)) * 65535)
    assert error < 0.020, error
    return {
        "exact": bool(np.array_equal(packaged, baseline[name])),
        "peak_difference_DN16": error,
        "rms_difference_DN16": float(np.sqrt(np.mean(difference**2)) * 65535),
        "seconds": elapsed,
    }


def main():
    torch.set_num_threads(2)
    start = monotonic()
    source = reference(OUT / "confirmation-weak-dose.json")
    data = read_json(checked(source))
    policy = read_json(checked(data["calibration"]))["weights"]
    name = policy["best"]["free"]
    assert name == "free_5_no_guard" and policy["choices"][name]["weight"] == 1
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + replay.ROI[0], y + replay.ROI[1], *replay.ROI[2:])
    captures = []
    for row in data["rows"]:
        for r in row["draws"]:
            f = replay.arrays(r["input"])
            parents = np.load(checked(r["outputs"]["local50k"]))
            scene = f["scene_packed"].copy()
            observations = []
            for p, raw in zip(parents, f["packed"], strict=True):
                scene[:, y//2:(y+h)//2, x//2:(x+w)//2] = raw
                observations.append(verify(
                    p, replay.ROI, scene, f["colors"], roi, plan["noise"], f["wb"], f["matrix"], 48, name,
                ))
            captures.append({"id": row["id"], "draw": r["draw"], "results": observations})
    camera = []
    for row in read_json(FIXED)["standing"]:
        a = replay.arrays(row["input"])
        roi = tuple(row["local_ROI"])
        p = np.load(checked(row["predictions"]["local50k"]))[0]
        camera.append({"id": row["id"], "result": verify(
            p, roi, a["packed"][0], a["colors"][0], roi, row["noise"], a["wb"][0], a["matrix"][0], 16, name,
        )})
    flat = [x for row in captures for x in row["results"]]
    measurements = [*flat, *(x["result"] for x in camera)]
    write_json(OUT / "api-proof.json", {
        "driver": reference(Path(__file__)), "source": source, "camera_inputs": reference(FIXED),
        "api": reference("src/demosaic/mesh_carrier_fit.py"),
        "operator": reference("src/demosaic/_mesh_weak_posterior.py"),
        "synthetic": captures, "camera": camera,
        "maximum_difference_DN16": max(x["peak_difference_DN16"] for x in measurements),
        "fresh_median_ms": median(x["seconds"] for x in flat) * 1000,
        "seconds": monotonic() - start,
    })


if __name__ == "__main__":
    main()
