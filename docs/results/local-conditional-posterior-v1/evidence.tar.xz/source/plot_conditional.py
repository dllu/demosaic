"""Plot weak-response recovery against measured gap error."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from conditional import OUT, replay


def main():
    source = reference(OUT / "confirmation-weak-dose.json")
    result = read_json(checked(source))
    policy = read_json(checked(result["calibration"]))["weights"]
    arms = [
        ("free", "Weak-only posterior", "#2563a6"),
        ("phase", "Phase-aligned weak", "#187451"),
    ]
    fig, ax = plt.subplots(figsize=(6.5, 3.6), layout="constrained")
    axis = np.linspace(0, 1, 21)
    data = {}
    for group, label, color in arms:
        method = policy["best"][group]
        values = []
        for a in axis:
            by_crop = [
                replay.metrics_at(d["powers"][method], a)
                for case in result["rows"] for d in case["draws"]
            ]
            values.append([
                np.mean([r[replay.FALSE] for r in by_crop if replay.FALSE in r]),
                np.mean([r[replay.ABSOLUTE] for r in by_crop]),
            ])
        x, y = np.array(values).T
        ax.plot(x, y, linewidth=2.3, label=label, color=color)
        ax.scatter(x[-1], y[-1], color=color, s=30)
        data[group] = {"false_projection_DN16": x.tolist(), "weak_response": y.tolist()}
    ax.scatter(x[0], y[0], color="#4c4c4c", label="Combined check", s=28, zorder=4)
    ax.set_title("ISO6400 • 24 new held-out photos", fontsize=11)
    ax.set_xlabel("False weak projection in true gaps (DN16)", fontsize=9)
    ax.set_ylabel("Recovered weak fundamental (%)", fontsize=9)
    ax.grid(alpha=0.22)
    ax.legend(loc="lower right", frameon=False, fontsize=8)
    destination = OUT / "native" / "weak-only-tradeoff.png"
    fig.savefig(destination, dpi=170)
    plt.close(fig)
    write_json(OUT / "tradeoff.json", {
        "driver": reference(Path(__file__)), "source": source, "image": reference(destination),
        "fractions_of_weak_change": axis.tolist(), "curves": data,
    })


if __name__ == "__main__":
    main()
