"""Rank carrier strength within the RAW crop using both green lattices."""

from demosaic._mesh_pooled import _POOLED_FOOTPRINT, _dominant, _footprint, _measure_nodes, _wave
from demosaic.mesh_carrier_fit import _positions


def rank(scene, colors, roi, frequency, shot, read):
    positions = _positions(colors, *roi[:2])
    lattice = _wave(_POOLED_FOOTPRINT, frequency)
    ranking = []
    for site in positions:
        data = _footprint(scene, roi[:2], site)
        measurements = _measure_nodes(data, lattice, site, shot, read)
        ranking.append(_dominant(*measurements))
    weaker = 1-ranking[0] if ranking[0] is not None and ranking[0] == ranking[1] else None
    return weaker, ranking
