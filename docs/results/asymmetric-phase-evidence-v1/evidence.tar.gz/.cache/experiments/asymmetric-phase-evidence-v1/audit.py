"""Independently reduce saved RGB predictions and check native comparison panels."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.prediction_archive import fingerprint

root = Path(__file__).resolve().parent
path = root / "review/result.json"
report = read_json(path)
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
earlier = read_json(checked(plan["camera_controls"]))
camera_plan = read_json(checked(plan["camera_plan"]))
assert collection["synthetic_fits"] == 240 and collection["camera_fits"] == 16
assert len(report["metrics"]) == 160 and len(report["boards"]) == 4
assert collection["synthetic_observations"] == 60 and len(collection["donors"]) == 16
assert collection["parent_state_unchanged"] and collection["parent_calls"] == {
    "root": 20,
    "DINO": 20,
}
groups = defaultdict(list)
for r in report["metrics"]:
    groups[r["id"]].append(r)
roi = np.s_[..., 128:384, 128:384]


def rms(v):
    return np.sqrt(np.mean(np.square(v))) * 65535


def projection(a, b, *, axes=None):
    return np.sum(a * b, axis=axes) / np.sum(b * b, axis=axes)


def measure_active(packed, colors, run, noise):
    height, width = packed.shape[-2:]
    raw = np.empty((height * 2, width * 2))
    for k, plane in enumerate(packed):
        raw[k // 2 :: 2, k % 2 :: 2] = plane
    labels = np.tile(colors.reshape(2, 2), (height, width))
    x = (np.arange(2 * width) + 0.5) / width - 1
    y = (np.arange(2 * height) + 0.5) / height - 1
    x, y = np.meshgrid(x, y)
    affine = np.stack((np.ones(raw.shape), x, y), axis=-1)
    mask = stratified_split(raw.shape, plan["config"]["split_seed"])
    active = []
    record = run["records"][0]
    for fold, (angle, offset) in zip((mask, ~mask), record["edges"], strict=True):
        side = x * np.cos(angle) + y * np.sin(angle) > offset
        green = (labels == 1) & fold
        nuisance = np.concatenate((affine, side[..., None]), axis=-1)[green]
        coef = np.linalg.pinv(nuisance.T @ nuisance, hermitian=True, rcond=1e-12) @ (
            nuisance.T @ raw[green]
        )
        variance = noise["read"] + noise["shot"] * max(1e-6, np.max(nuisance @ coef))
        count = []
        for color in (0, 1, 2):
            sites = fold & (labels == color)
            n = np.count_nonzero(sites)
            m = np.count_nonzero(sites & side)
            count.append(8 * min(m, n - m) >= n)
        active.append(bool(coef[3] ** 2 > 4 * variance and all(count)))
    return active


def check_folds(independent, constrained, active):
    count = 0
    for a, b in zip(independent["records"], constrained["records"], strict=True):
        for name in ("frequencies", "edges", "guide_search_excluded", "discovery_reliability"):
            assert a[name] == b[name]
            count += len(a[name])
        assert b["phase_edge_side_detected"] == active
        assert b["phase_edge_side_applied"] == all(active)
        assert b["unit_keys"] == [[[0, 0], [1, 0]]] * 2
    return count


def side_measures(target, prediction, source):
    recipe = source["metadata"]["recipe"]
    y, x = np.indices(target.shape[-2:])
    origin = (recipe["size"] - 1) / 2
    theta = recipe["edge_angle"]
    distance = (
        (x - origin) * np.cos(theta) + (y - origin) * np.sin(theta) - recipe["edge_jitter"]
    )[roi]
    a = (prediction[2] - prediction[1])[roi]
    b = (target[2] - target[1])[roi]
    dark, bright = distance < -2, distance > 2
    error = (prediction[0] - target[0])[roi]
    return {
        "dark_weak_gain": projection(a[:, dark], b[:, dark]),
        "bright_weak_gain": projection(a[:, bright], b[:, bright]),
        "no_wire_edge_RMS_DN16": rms(error[:, np.abs(distance) <= 8]),
    }


reductions, delta, fold_checks, exact, sensor_checks = 0, 0.0, 0, 0, 0
background = []
observed_ids = set()
for binding, declaration in zip(collection["synthetic"], plan["groups"], strict=True):
    source = read_json(checked(binding))
    assert all(source[k] == v for k, v in declaration.items())
    assert source["id"] not in observed_ids
    observed_ids.add(source["id"])
    assert source["metadata"]["repeat"] == 7521
    assert source["source"] in range(60, 68) and source["source"] not in range(40, 48)
    donor = collection["donors"][source["guide_key"]]
    checked(donor["arrays"])
    assert donor["metadata"]["repeat"] == 7522
    assert donor["arrays"] != source["sensor"]
    with np.load(checked(source["sensor"])) as data:
        sensor, colors = data["packed"][..., 64:192, 64:192], data["colors"]
        for k, v in source["sensor_fingerprints"].items():
            assert fingerprint(data[k]) == v
            sensor_checks += 1
    base = source["fits"]["independent"]
    detectable = [
        measure_active(sensor[r], colors[r], fit, plan["profiles"][source["profile"]])
        for r, fit in enumerate(base)
    ]
    for arm, fits in source["fits"].items():
        if arm == "independent":
            continue
        for independent, constrained, active in zip(base, fits, detectable, strict=True):
            assert constrained.get("bright_cross_edge_weight", 0.0) == plan["arms"][arm]
            fold_checks += check_folds(independent, constrained, active)
    parent = np.load(checked(source["parent"])).astype(np.float64)
    with np.load(checked(source["target"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][roi]
    weak, strong = np.diff(target, axis=0)[::-1]
    with np.load(checked(source["prediction"])) as candidates:
        for role, active in enumerate(detectable):
            if all(active):
                continue
            for label in candidates.files:
                model, suffix = label.split("--", 1)
                if model != "independent":
                    np.testing.assert_array_equal(
                        candidates[label][role], candidates[f"independent--{suffix}"][role]
                    )
                    exact += 1
        for row in groups[source["id"]]:
            key = f"{row['model']}--t{row['threshold']:g}"
            saved = candidates[key]
            prediction = parent.copy()
            scale = row["scale"]
            prediction[roi] = (1 - scale) * parent[roi] + scale * saved.astype(np.float64)
            error = prediction - target
            inc_weak, inc_strong = np.diff(prediction, axis=0)[::-1]
            weak_error = inc_weak - weak
            chroma = weak_error[roi] - weak_error[roi].mean(axis=0, keepdims=True)
            actual = {
                "weak_gain": projection(inc_weak, weak),
                "strong_gain": projection(inc_strong, strong),
                "weak_absent_projection": projection(error[1], weak),
                "weak_increment_RMS_DN16": rms(weak_error),
                "quiet_RMS_DN16": rms(error[roi][..., quiet]),
                "query_RMS_DN16": rms(error[roi]),
                "quiet_delta_DN16": rms(error[roi][..., quiet])
                - rms((parent - target)[roi][..., quiet]),
                "response_RGB": projection(inc_weak[roi], weak[roi], axes=(1, 2)),
                "centered_chroma_increment_RMS_DN16": rms(chroma),
            }
            if source["placement"] == "near":
                actual.update(side_measures(target, prediction, source))
            for name, value in actual.items():
                np.testing.assert_allclose(value, row[name], rtol=0, atol=4e-10)
                delta = max(delta, float(np.max(np.abs(value - row[name]))))
                reductions += np.size(value)
            if row["method"] == "weighted-refit" and row["budget_DN16"] == 0.02:
                background.append(
                    {
                        "id": row["id"],
                        "profile": row["profile"],
                        "placement": row["placement"],
                        "model": row["model"],
                        "delivered_correction_DN16": float(rms((prediction - parent)[0][roi])),
                    }
                )


def display_cell(path, panel):
    x, y, w, h = panel["png_xywh"]
    assert (w, h) == (160, 160)
    return np.asarray(Image.open(checked(path)))[y : y + h, x : x + w]


assert reductions == 2144 and fold_checks == 1440 and len(background) == 80 and sensor_checks == 100
camera_checks = []
retained = 0
old = read_json(checked(earlier["collection"]))
for row, prev, new, control in zip(
    report["camera"], earlier["camera"], collection["camera"], old["camera"], strict=True
):
    assert row["id"] == prev["id"] == new["id"] == control["id"]
    additions = {"Bright cross-edge 0.5", "Bright cross-edge 1.0"}
    keep = [p for p in row["panels"] if p["label"] not in additions]
    for a, b in zip(keep, prev["panels"], strict=True):
        assert a["label"] == b["label"]
        np.testing.assert_array_equal(display_cell(row["image"], a), display_cell(prev["image"], b))
        retained += 1
    scene = row["source"]
    x, y, w, h = row["ROI_xywh"]
    tx, ty, tw, th = scene["query_box"]
    with np.load(checked(scene["query_arrays"])) as data:
        sample = data["packed"][0, :, ty // 2 : (ty + th) // 2, tx // 2 : (tx + tw) // 2]
        colors = data["colors"][0]
    expected = measure_active(
        sample,
        colors,
        control["fits"]["validation"],
        next(v["noise"] for v in camera_plan["camera"] if v["board"]["id"] == row["id"]),
    )
    ox, oy, *_ = scene["query_box"]
    parent_crop = np.load(checked(scene["parent_prediction"]), mmap_mode="r")[
        0, :, y : y + h, x : x + w
    ]
    crop = np.s_[:, y - oy : y - oy + h, x - ox : x - ox + w]
    with (
        np.load(checked(row["asymmetric_prediction"])) as current,
        np.load(checked(prev["edge_side_predictions"])) as old_arrays,
    ):
        for arm in ("bright-half", "bright-full"):
            constrained = new["fits"][arm]
            fold_checks += check_folds(control["fits"]["validation"], constrained, expected)
            val = current[arm][crop].astype(np.float64)
            if not all(expected):
                np.testing.assert_array_equal(current[arm], old_arrays["validation"])
                exact += 1
            measured = rms(val - old_arrays["validation"][crop])
            assert abs(measured - row["change_from_same_side_RMS_DN16"][arm]) < 1e-12
            camera_checks.append(
                {
                    "id": row["id"],
                    "arm": arm,
                    "minus_V120_RMS_DN16": float(rms(val - parent_crop)),
                    "minus_same_side_RMS_DN16": float(measured),
                }
            )
for b in report["boards"]:
    f, t = b["board"], b["triplet"]
    for j, k in enumerate((0, 4, 6)):
        np.testing.assert_array_equal(
            display_cell(f["image"], f["panels"][k]), display_cell(t["image"], t["panels"][j])
        )
assert retained == 136 and fold_checks == 1568
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "status": "passed",
        "native_reductions": int(reductions),
        "sensor_hash_checks": sensor_checks,
        "maximum_difference": delta,
        "fold_geometry_and_guard_where_matched": fold_checks,
        "camera_checks": camera_checks,
        "bitexact_inactive_saved_fields": exact,
        "retained_camera_cells_bitexact": retained,
        "exact_triplet_subsets": 4,
        "no_wire_role": background,
    },
)
print(reductions, delta, retained, "independent audit passed", flush=True)
