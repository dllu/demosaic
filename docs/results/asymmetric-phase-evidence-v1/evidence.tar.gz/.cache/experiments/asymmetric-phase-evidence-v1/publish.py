"""Publish native asymmetric validation comparisons and their executed analysis."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
review = root / "review"
report = read_json(review / "result.json")
summary = read_json(review / "summary.json")
audit = read_json(review / "independent-audit.json")
seen = read_json(review / "actual-native-viewing.json")
fixed = read_json(root / "fixed-guide/review/result.json")
assert len(report["metrics"]) == 160 and len(summary["groups"]) == 8
assert audit["status"] == "passed" and audit["native_reductions"] == 2144
assert len(seen["boards"]) == 12 and all(v["viewed"] for v in seen["boards"])
assert len(seen["fixed_guide_boards"]) == 2 and all(v["viewed"] for v in seen["fixed_guide_boards"])
assert fixed["status"] == "passed" and fixed["independent_reductions"] == 48
images = repo / "docs/images/asymmetric-phase-evidence-v1"
results = repo / "docs/results/asymmetric-phase-evidence-v1"
images.mkdir()
results.mkdir()
items = []
for kind, row in (
    [(k, v) for v in report["boards"] for k in ("board", "triplet")]
    + [("camera", v) for v in report["camera"]]
    + [(k, v) for v in fixed["native"] for k in ("board", "triplet")]
):
    info = row if kind == "camera" else row[kind]
    source = checked(info["image"])
    dest = images / source.name
    shutil.copyfile(source, dest)
    fingerprint = reference(dest)
    assert fingerprint["sha256"] == info["image"]["sha256"]
    items.append({"id": row["id"], "kind": kind, "published": fingerprint, "native": row})
assert len(items) == 20
write_json(
    images / "manifest.json",
    {
        "images": items,
        "viewing": reference(review / "actual-native-viewing.json"),
        "scope": "Fresh synthetic inputs and both standing GFX families. All crops at native 160×160.",
    },
)
for name in ("summary.json", "independent-audit.json", "actual-native-viewing.json"):
    shutil.copyfile(review / name, results / name)
    assert reference(review / name)["sha256"] == reference(results / name)["sha256"]
shutil.copyfile(root / "fixed-guide/result.json", results / "fixed-guide-metrics.json")
shutil.copyfile(root / "fixed-guide/review/result.json", results / "fixed-guide-audit.json")
bundle = results / "evidence.tar.gz"
members = []
with (
    bundle.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped,
    tarfile.open(fileobj=zipped, mode="w") as tar,
):
    for path in sorted(root.rglob("*")):
        if (
            path.is_file()
            and path.suffix in (".py", ".json", ".log")
            and "__pycache__" not in path.parts
        ):
            member = str(path.relative_to(repo))
            members.append({"member": member, **reference(path)})
            tar.add(path, arcname=member, recursive=False)
with tarfile.open(bundle) as tar:
    for x in members:
        assert hashlib.sha256(tar.extractfile(x["member"]).read()).hexdigest() == x["sha256"]
write_json(
    results / "publication.json",
    {
        "archive": reference(bundle),
        "members": members,
        "all_member_hashes_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "boards_opened": 12,
        "fixed_guide_boards_opened": 2,
        "metric_rows": 160,
        "matched_fold_geometry_checks": 1568,
        "scope": "Two bright-side cross-edge weights, fresh native synthetic observations, and both GFX families.",
    },
)
print(len(members), len(items), "publication verified")
