"""Bind observations to the actual native boards and check the rendered sky."""

import datetime as dt
import json
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent / "review"
path = root / "result.json"
report = read_json(path)
audit = read_json(root / "independent-audit.json")
observations = json.load(sys.stdin)
rows = []
for row in report["boards"] + report["camera"]:
    board = row.get("board", row)
    image = board["image"]
    checked(image)
    rows.append(
        {"id": row["id"], "image": image, "viewed": True, "observation": observations[row["id"]]}
    )
fixed_rows = []
fixed = read_json(root.parent / "fixed-guide/review/result.json")
for row in fixed["native"]:
    info = row["board"]["image"]
    checked(info)
    fixed_rows.append(
        {
            "id": row["id"],
            "image": info,
            "viewed": True,
            "observation": observations[row["id"]],
        }
    )
assert len(rows) == 12 and len(fixed_rows) == 2 and len(observations) == 14
sky = next(c for c in report["camera"] if c["id"] == "main-overcast-sky")
checks = {c["arm"]: c for c in audit["camera_checks"] if c["id"] == "main-overcast-sky"}
assert len(checks) == 2
image = np.asarray(Image.open(checked(sky["image"])))
cells = {}
for p in sky["panels"]:
    x, y, w, h = p["png_xywh"]
    cells[p["label"]] = image[y : y + h, x : x + w]
sky_match = {
    arm: {
        "linear_camera_RGB_bitexact": checks[arm]["minus_V120_RMS_DN16"] == 0,
        "displayed_pixels_bitexact": bool(np.array_equal(cells["V120 EMA"], cells[label])),
    }
    for arm, label in (
        ("bright-half", "Bright cross-edge 0.5"),
        ("bright-full", "Bright cross-edge 1.0"),
    )
}
write_json(
    root / "actual-native-viewing.json",
    {
        "observed_at": dt.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "report": reference(path),
        "boards": rows,
        "fixed_guide_boards": fixed_rows,
        "v120_sky_matches": sky_match,
    },
)
