"""Check the effect of disabling recentering on the closed ISO400 near stratum."""

import time
from pathlib import Path

import numpy as np
from probe_fresh_phase_refit import write_array
from report_fold_support_pooling import ROI, evaluated, measure
from report_phase_edge_side import near_edge_masks, side_metrics

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig, restore_local_waves

here = Path(__file__).resolve().parent
root = here.parent
plan_path = root / "plan.json"
plan = read_json(plan_path)
config = LocalWaveConfig(**plan["config"])
setting = next(
    s
    for s in plan["settings"]
    if s["profile"] == "iso400" and s["placement"] == "near" and s["budget_DN16"] == 0.02
)
groups = sorted((root / "output").glob("iso400*near*.json"))
assert len(groups) == 8
fits = []
started = time.monotonic()
for path in groups:
    case = read_json(path)
    guide = case["fits"]["same-side"][0]["guide_frequencies_xy"]
    parent = np.load(checked(case["parent"]))[ROI]
    with np.load(checked(case["sensor"])) as archive:
        packed = archive["packed"][..., 64:192, 64:192]
        colors = archive["colors"]
    runs, predictions = [], []
    for role in range(3):
        values, record = restore_local_waves(
            parent[role],
            packed[role],
            colors[role],
            shot=plan["profiles"]["iso400"]["shot"],
            read=plan["profiles"]["iso400"]["read"],
            config=config,
            thresholds=(setting["threshold"],),
            guide_frequencies_xy=guide,
            phase_bins=8,
            shrink_phase_fit=True,
            compare_pooled_support=True,
            compare_pooled_refit=True,
            phase_edge_side="validation",
        )
        assert np.array_equal(
            record["records"][0]["edges"], case["fits"]["same-side"][role]["records"][0]["edges"]
        )
        np.testing.assert_array_equal(record["records"][0]["frequencies"], [guide, guide])
        runs.append(record)
        predictions.append(values["weighted-refit", setting["threshold"]])
    prediction = write_array(here / (case["id"] + ".npz"), corrected=predictions)
    fits.append({"case": reference(path), "prediction": prediction, "records": runs})
write_json(
    here / "fits.json",
    {
        "driver": reference(__file__),
        "plan": reference(plan_path),
        "settings": setting,
        "model": "same-side, fixed measured donor frequency",
        "fits": fits,
        "query_fits": 24,
        "seconds": time.monotonic() - started,
    },
)
out = []
for saved in fits:
    case = read_json(checked(saved["case"]))
    parent = np.load(checked(case["parent"])).astype(np.float64)
    with np.load(checked(case["target"])) as f:
        truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
    masks = near_edge_masks(case, truth.shape[-2:])
    with np.load(checked(saved["prediction"])) as f, np.load(checked(case["prediction"])) as before:
        for label, value in (
            ("fixed", f["corrected"]),
            ("recentered", before[f"same-side--t{setting['threshold']:g}"]),
        ):
            moments = measure(parent, truth, quiet, value)
            scale = setting["scale"]
            result = evaluated(moments, scale)
            out.append(
                {
                    "id": case["id"],
                    "arm": label,
                    **result,
                    **side_metrics(parent[ROI], truth[ROI], value, scale, masks),
                    "quiet_delta_DN16": result["quiet_RMS_DN16"]
                    - evaluated(moments, 0)["quiet_RMS_DN16"],
                }
            )
names = (
    "weak_gain",
    "dark_weak_gain",
    "bright_weak_gain",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
)
means = {
    label: {k: float(np.mean([v[k] for v in out if v["arm"] == label])) for k in names}
    for label in ("fixed", "recentered")
}
write_json(
    here / "result.json",
    {
        "fits": reference(here / "fits.json"),
        "rows": out,
        "means": means,
        "scope": "Adaptively added diagnostic on the already observed ISO400 near stratum. No recalibration.",
    },
)
print(means, flush=True)
