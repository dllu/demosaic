"""Check the fixed-guide reduction independently and show native witness crops."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI
from report_scene_wave_guides import native_board
from scipy.optimize import brentq

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
fits = read_json(root / "fits.json")
reported = read_json(root / "result.json")
setting = fits["settings"]
rows = {(r["id"], r["arm"]): r for r in reported["rows"]}
raw = defaultdict(list)
boards = []
review = root / "review"
review.mkdir()
verifications = 0


def reduction(value):
    pred, p, truth, quiet = value
    inc = pred[2] - pred[1]
    reference_inc = truth[2] - truth[1]
    error = pred - truth
    return {
        "weak_gain": float(np.sum(inc * reference_inc) / np.sum(reference_inc**2)),
        "quiet_RMS_DN16": float(np.std(error[ROI][..., quiet], mean=0) * 65535),
        "weak_increment_RMS_DN16": float(np.std(inc - reference_inc, mean=0) * 65535),
    }


def score(row, multiplier):
    parent, truth, quiet, corrected = row
    scaled = parent.copy()
    alpha = multiplier * setting["scale"]
    scaled[ROI] = (1 - alpha) * parent[ROI] + alpha * corrected.astype(np.float64)
    return reduction((scaled, parent, truth, quiet))


for fit in fits["fits"]:
    case = read_json(checked(fit["case"]))
    parent = np.load(checked(case["parent"])).astype(np.float64)
    with np.load(checked(case["target"])) as f:
        truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
    with np.load(checked(fit["prediction"])) as f, np.load(checked(case["prediction"])) as g:
        arrays = {"fixed": f["corrected"], "recentered": g[f"same-side--t{setting['threshold']:g}"]}
    for arm, array in arrays.items():
        item = (parent, truth, quiet, array)
        raw[arm].append(item)
        independent = score(item, 1)
        for metric, value in independent.items():
            np.testing.assert_allclose(value, rows[case["id"], arm][metric], atol=3e-10, rtol=0)
            verifications += 1
    if case["source"] in (60, 62):
        with np.load(checked(case["sensor"])) as f:
            ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
            ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
        p = parent[2][ROI]
        images = [p + setting["scale"] * (arrays[a][2] - p) for a in ("recentered", "fixed")]
        boards.append(
            native_board(
                review,
                case["id"] + "-fixed-guide",
                [noisy_malvar(ctx)[0], p, *images, truth[2][ROI]],
                ctx,
                {"case": case, "fit": fit, "operating_point": setting},
                labels=(
                    "Noisy Malvar",
                    "V143 EMA",
                    "Recentered guide",
                    "Fixed donor guide",
                    "Exact GT",
                ),
                triplet_indices=(0, 3, 4),
            )
        )


def mean(arm, multiplier):
    values = [score(r, multiplier) for r in raw[arm]]
    return {k: float(np.mean([v[k] for v in values])) for k in values[0]}


target = mean("recentered", 1)["quiet_RMS_DN16"]
multiplier = brentq(lambda v: mean("fixed", v)["quiet_RMS_DN16"] - target, 0, 1)
matched = mean("fixed", multiplier)
assert verifications == 48 and len(boards) == 2 and abs(matched["quiet_RMS_DN16"] - target) < 1e-9
write_json(
    review / "result.json",
    {
        "driver": reference(__file__),
        "primary_metrics": reference(root / "result.json"),
        "native": boards,
        "status": "passed",
        "independent_reductions": verifications,
        "matched_quiet_descriptive": {
            "fixed_multiplier": multiplier,
            "fixed": matched,
            "recentered": mean("recentered", 1),
        },
    },
)
print(multiplier, matched, flush=True)
