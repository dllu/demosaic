"""Compare source-paired response and match quiet error on the finished new panel."""

from collections import defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, evaluated, measure
from report_fresh_phase_refit import donor_errors
from report_phase_edge_side import near_edge_masks, side_metrics
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
audit_path = root / "review/independent-audit.json"
report = read_json(report_path)
audit = read_json(audit_path)
assert audit["status"] == "passed"
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
arms = tuple(plan["arms"])
base_columns = (
    "weak_gain",
    "strong_gain",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "weak_absent_projection",
    "centered_chroma_increment_RMS_DN16",
)
side_columns = ("dark_weak_gain", "bright_weak_gain", "no_wire_edge_RMS_DN16")
groups = defaultdict(lambda: defaultdict(dict))
for row in report["metrics"]:
    key = row["profile"], row["placement"], row["budget_DN16"]
    names = base_columns + (side_columns if row["placement"] == "near" else ())
    groups[key][row["model"]][row["source"]] = [
        abs(row[n]) if n == "weak_absent_projection" else row[n] for n in names
    ]
rng = np.random.default_rng(7523)
rows = []
for (profile, placement, budget), models in groups.items():
    order = sorted(models["independent"])
    columns = base_columns + (side_columns if placement == "near" else ())
    assert len(order) == (8 if placement == "near" else 2)
    draw = rng.integers(0, len(order), (12000, len(order))) if placement == "near" else None
    data = {m: np.asarray([models[m][k] for k in order]) for m in arms}
    pairs = {}
    for a, b in combinations(arms, 2):
        delta = data[b] - data[a]
        pairs[f"{b}_vs_{a}"] = {
            "mean": dict(zip(columns, delta.mean(axis=0).tolist(), strict=True)),
            "higher_weak_response": int((delta[:, 0] > 0).sum()),
            "lower_increment_error": int((delta[:, 3] < 0).sum()),
            **(
                {
                    "descriptive_95_percent": np.quantile(
                        delta[draw].mean(1), [0.025, 0.975], axis=0
                    ).tolist()
                }
                if draw is not None
                else {}
            ),
        }
    rows.append(
        {
            "profile": profile,
            "placement": placement,
            "budget_DN16": budget,
            "columns": columns,
            "sources": order,
            "mean": {
                m: dict(zip(columns, values.mean(0).tolist(), strict=True))
                for m, values in data.items()
            },
            "pairs": pairs,
        }
    )

settings = {(s["profile"], s["placement"]): s for s in plan["settings"] if s["budget_DN16"] == 0.02}
saved = defaultdict(lambda: defaultdict(list))
activated = defaultdict(lambda: [0, 0])
query_guide_errors = []
for binding in collection["synthetic"]:
    source = read_json(checked(binding))
    key = source["profile"], source["placement"]
    parent = np.load(checked(source["parent"])).astype(np.float64)
    setting = settings[key]
    with (
        np.load(checked(source["target"])) as target,
        np.load(checked(source["prediction"])) as preds,
    ):
        gt, quiet = target["target"].astype(np.float64), target["quiet"][ROI]
        masks = near_edge_masks(source, gt.shape[-2:]) if key[1] == "near" else ()
        for m in arms:
            value = preds[f"{m}--t{setting['threshold']:g}"]
            moments = measure(parent, gt, quiet, value)
            if masks:
                empty, full = (side_metrics(parent[ROI], gt[ROI], value, u, masks) for u in (0, 1))
                for name in side_columns[:2]:
                    moments[name] = np.array([empty[name], full[name] - empty[name]])
            saved[key][m].append(moments)
    for fit in source["fits"]["same-side"]:
        activated[key][0] += int(fit["records"][0]["phase_edge_side_applied"])
        activated[key][1] += 1
    fit = source["fits"]["same-side"][2]
    query_guide_errors.append(
        {
            "id": source["id"],
            "seed": donor_errors(
                {"metadata": source["metadata"], "frequencies": fit["guide_frequencies_xy"]}
            ),
            "after_recenter": [
                donor_errors({"metadata": source["metadata"], "frequencies": f})
                for f in fit["records"][0]["frequencies"]
            ],
        }
    )


def match(models, scale, near):
    columns = ("quiet_RMS_DN16", "weak_gain", "weak_increment_RMS_DN16")
    if near:
        columns += side_columns[:2]

    def average(model, multiplier):
        results = [evaluated(v, scale * multiplier) for v in models[model]]
        return {n: float(np.mean([r[n] for r in results])) for n in columns}

    target = min(average(m, 1)["quiet_RMS_DN16"] for m in models)

    def fit(model):
        if average(model, 1)["quiet_RMS_DN16"] == target:
            return 1.0
        if average(model, 0)["quiet_RMS_DN16"] > target:
            return None
        return brentq(lambda s: average(model, s)["quiet_RMS_DN16"] - target, 0, 1, xtol=1e-11)

    factors = {m: fit(m) for m in models}
    matched = {m: average(m, f) for m, f in factors.items() if f is not None}
    assert all(abs(v["quiet_RMS_DN16"] - target) < 1e-9 for v in matched.values())
    return {"common_multiplier": factors, "measured": matched}


comparisons = []
for (profile, place), values in saved.items():
    cohort = [("all", arms)]
    if place == "near":
        cohort.extend((f"{b}_vs_{a}", (a, b)) for a, b in combinations(arms, 2))
    for label, models in cohort:
        comparisons.append(
            {
                "profile": profile,
                "placement": place,
                "comparison": label,
                **match(
                    {m: values[m] for m in models},
                    settings[profile, place]["scale"],
                    place == "near",
                ),
            }
        )
write_json(
    root / "review/summary.json",
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "audit": reference(audit_path),
        "groups": rows,
        "matched_quiet_descriptive": comparisons,
        "activated": [
            {"profile": p, "placement": w, "applied": a, "observations": n}
            for (p, w), (a, n) in activated.items()
        ],
        "camera": audit["camera_checks"],
        "donor_frequency_errors_in_native_bins": {
            name: donor_errors(donor) for name, donor in collection["donors"].items()
        },
        "two_wire_query_guide_errors_in_native_bins": query_guide_errors,
    },
)
for r in rows:
    if r["budget_DN16"] == 0.02:
        print(
            r["profile"],
            r["placement"],
            {a: {k: round(v, 8) for k, v in row.items()} for a, row in r["mean"].items()},
            flush=True,
        )
for item in comparisons:
    if item["comparison"] == "all":
        print("matched", item, flush=True)
