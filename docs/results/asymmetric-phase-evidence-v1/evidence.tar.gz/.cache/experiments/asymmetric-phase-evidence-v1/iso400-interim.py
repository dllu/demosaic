"""Read the complete ISO400 near stratum while the second prior is still running."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, evaluated, measure
from report_phase_edge_side import near_edge_masks, side_metrics
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json

root = Path(__file__).resolve().parent
plan = read_json(root / "plan.json")
setting = next(
    s
    for s in plan["settings"]
    if s["profile"] == "iso400" and s["placement"] == "near" and s["budget_DN16"] == 0.02
)
predicted = defaultdict(list)
for path in sorted((root / "output").glob("iso400*near*.json")):
    sample = read_json(path)
    parent = np.load(checked(sample["parent"])).astype(np.float64)
    with np.load(checked(sample["target"])) as archive:
        target, quiet = archive["target"].astype(np.float64), archive["quiet"][ROI]
    nearly = near_edge_masks(sample, target.shape[-2:])
    with np.load(checked(sample["prediction"])) as predictions:
        for model in plan["arms"]:
            prediction = predictions[f"{model}--t{setting['threshold']:g}"]
            moment = measure(parent, target, quiet, prediction)
            a, b = [side_metrics(parent[ROI], target[ROI], prediction, u, nearly) for u in (0, 1)]
            for key in ("dark_weak_gain", "bright_weak_gain"):
                moment[key] = [a[key], b[key] - a[key]]
            predicted[model].append(moment)
assert all(len(x) == 8 for x in predicted.values()) and len(predicted) == 4
names = (
    "weak_gain",
    "dark_weak_gain",
    "bright_weak_gain",
    "quiet_RMS_DN16",
    "weak_increment_RMS_DN16",
)


def average(model, factor):
    rows = [evaluated(v, factor * setting["scale"]) for v in predicted[model]]
    return np.mean([[r[k] for k in names] for r in rows], axis=0)


for model in predicted:
    print(model, average(model, 1), flush=True)
target = min(average(f, 1)[3] for f in predicted)
for model in predicted:
    if average(model, 0)[3] <= target:
        factor = brentq(lambda u, m=model: average(m, u)[3] - target, 0, 1)
        print(model, "match", factor, average(model, factor), flush=True)
