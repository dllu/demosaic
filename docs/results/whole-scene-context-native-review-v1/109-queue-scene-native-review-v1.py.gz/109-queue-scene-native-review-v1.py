"""Collect each remaining CPU endpoint once, after its terminal train receipt."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

plan_path=Path(sys.argv[1]);queue=read_json(plan_path)
root=Path(queue['root']);(root/'native-review-controller.claim').open('x').close()
training_launch=read_json(checked(queue['training_controller']))
native_plan=read_json(checked(queue['native_plan']))
training=read_json(checked(native_plan['training_plan']))
deadline=time.monotonic()+queue['maximum_wait_seconds'];results=[]
for arm in queue['arms']:
    terminal=Path(training['work'])/'artifacts/train'/arm/'completed.json'
    while not terminal.exists() or psutil.virtual_memory().available<32*2**30:
        if time.monotonic()>deadline:raise TimeoutError('Bounded endpoint/RAM wait expired; no retry')
        try:
            owner=psutil.Process(training_launch['pid'])
            live=owner.create_time()==training_launch['create_time'] and owner.status()!=psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:live=False
        if not live and not terminal.exists():raise RuntimeError('Owned training controller ended without required endpoint')
        write_json(root/'native-review-progress.json',{'arm':arm,'status':'waiting-for-terminal-endpoint-or-RAM',
                   'training_controller_verified_live':live,'completed':results},replace=True)
        time.sleep(10)
    assert not (root/arm).exists()
    command=[sys.executable,str(checked(native_plan['script'])),str(checked(queue['native_plan'])),arm]
    with (root/(arm+'.log')).open('x')as log:
        child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,
                  env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2'))
        identity={'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,
                  'queue_plan':reference(plan_path),'training_receipt':reference(terminal)}
        write_json(root/(arm+'-launch.json'),identity)
        write_json(root/'native-review-progress.json',{'arm':arm,'status':'collecting-CPU-native',
                   'child':identity,'completed':results},replace=True)
        try:code=child.wait(timeout=queue['maximum_collector_seconds'])
        except subprocess.TimeoutExpired:
            child.terminate()
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:child.kill();child.wait()
            code=124
    result={'arm':arm,'returncode':code,'launch':reference(root/(arm+'-launch.json'))}
    if not code:result['collection']=reference(root/arm/'collection.json')
    write_json(root/(arm+'-controller-result.json'),result);results.append(result)
    if code:break
write_json(root/'native-review-queue-result.json',{'all_succeeded':len(results)==len(queue['arms'])and all(r['returncode']==0 for r in results),
           'results':results,'plan':reference(plan_path),'scope':'CPU native collection only, each declared endpoint once. No automatic retry, training restart, GPU work, noise regeneration or quality-based checkpoint selection. Rendering/actual native viewing and broad427/camera panels remain separate.'})
