"""Read independent saved bytes/state/metrics; never rerun a neural prediction."""
import gzip
import hashlib
import re
import tarfile
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.metrics import quality_metrics

torch.set_num_threads(2)
repo=Path.cwd();root=repo/'.cache/experiments/scene-context-native-review-v2'
publication_path=repo/'docs/results/whole-scene-context-native-review-v1/publication.json'
pub=read_json(publication_path);checks=[]
for item in pub['archives']:
    data=gzip.decompress(checked(item['published']).read_bytes())
    assert hashlib.sha256(data).hexdigest()==item['original']['sha256']
    assert data==checked(item['original']).read_bytes()
for snapshot in pub['source_snapshots']:
    expected={m['member']:m for m in snapshot['members']}
    with tarfile.open(checked(snapshot['published']),'r:gz')as tar:
        assert set(tar.getnames())==set(expected)
        for name,item in expected.items():
            data=tar.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==item['original']['sha256'];assert data==checked(item['original']).read_bytes()
for item in pub['native_assets']:
    assert checked(item['published']).read_bytes()==checked(item['original']).read_bytes()
checks.append({'exact_archives':len(pub['archives']),'exact_source_members':sum(len(s['members'])for s in pub['source_snapshots']),
               'exact_native_assets':len(pub['native_assets'])})
old=repo/'.cache/experiments/scene-context-native-review-v1'
assert reference(repo/'.cache/scene-native-collector-v1-pinned.py')['sha256']==read_json(old/'plan.json')['script']['sha256']
checks.append({'original_failed_collector_source_retained_exact':True})

train=read_json(checked(read_json(root/'plan.json')['training_plan']));trainroot=Path(train['work'])/'artifacts/train'
bindings=[];states=[]
for arm in ['none','pooled','spatial']:
    terminal=read_json(trainroot/arm/'completed.json');assert terminal['steps']==2000 and terminal['DINO_unchanged']
    endpoint=terminal['checkpoints'][-1];state=torch.load(checked(endpoint),map_location='cpu',weights_only=True)
    assert state['step']==2000 and state['scene_draw_index']==4000 and state['mode']==arm
    assert len(state['model'])==len(state['ema'])==101 and state['python_rng'] and state['cuda_rng']
    for section in ['model','ema']:assert all(torch.isfinite(t).all()for t in state[section].values())
    assert len(state['optimizer']['state'])==(89 if arm=='none'else 99)
    assert all(v['step']==2000 for v in state['optimizer']['state'].values())
    assert all(torch.isfinite(t).all()for value in state['optimizer']['state'].values()for t in value.values()if isinstance(t,torch.Tensor))
    if arm=='none':
        exported=torch.load(checked(read_json(root/'none/legacy-base-export.json')['export']),map_location='cpu',weights_only=True)
        for section in ['model','ema']:
            assert len(exported[section])==91
            assert all(torch.equal(v,state[section]['base.'+k])for k,v in exported[section].items())
        del exported
    bindings.append(terminal['observations']);states.append({'arm':arm,'checkpoint':endpoint,'Adam_states':len(state['optimizer']['state']),'training_seconds':terminal['seconds']});del state
assert len({b['sha256']for b in bindings})==1
observations=[__import__('json').loads(line)for line in checked(bindings[0]).read_text().splitlines()]
assert len(observations)==4000 and len({r['source_id']for r in observations})==3701
assert sum(len(r['boxes_xywh'])for r in observations)==16000
checks.append({'complete_training_endpoints':states,'actual_observations_byte_identical':True,'scene_visits_per_arm':4000,'distinct_sources':3701,'crop_slots':16000,'none_inference_export_exact_raw_EMA_tensors_each':91})

plan=read_json(root/'plan.json');baseline=read_json(checked(plan['baseline_collection']))
assert baseline['seconds'] is None and baseline['post_run_model_hash_receipt_available'] is False
collections={'V120':baseline,**{a:read_json(root/a/'collection.json')for a in ['none','pooled','spatial']}}
tables={a:{v['id']:v for v in d['records']}for a,d in collections.items()}
for arm in ['none','pooled','spatial']:
    collection=collections[arm];assert collection['counts']=={'root':10,'encoder':10 if arm=='none'else 16}
    assert collection['DINO_unchanged'] and collection['weights']=='EMA'
means={}
for obs in plan['observations']:
    ident=obs['id']
    assert all(table[ident]['input_fingerprints']==tables['V120'][ident]['input_fingerprints']for table in tables.values())
    for arm,table in tables.items():
        value=np.load(checked(table[ident]['prediction']),allow_pickle=False);assert np.isfinite(value).all()
        if obs['kind']!='development':continue
        with np.load(checked(obs['arrays']),allow_pickle=False)as arrays:
            metrics=quality_metrics(torch.from_numpy(value)[...,8:-8,8:-8],torch.from_numpy(arrays['crop_target'])[...,8:-8,8:-8],torch.from_numpy(arrays['crop_wb']),torch.from_numpy(arrays['crop_matrix']))
        previous=table[ident]['metrics']
        for name,values in metrics.items():
            for actual,saved in zip(values,previous[name],strict=True):
                if saved is None:assert not torch.isfinite(actual)
                else:assert float(actual)==saved
        condition=ident.split('-',2)[2]
        means.setdefault(arm+'-'+condition,[]).extend(previous['srgb_psnr'])
render=read_json(root/'render-all-v1/result.json')
for name,values in means.items():assert float(np.mean(values))==render['development_condition_means'][name]['srgb_psnr']
checks.append({'native_collections':4,'all10_input_batches_identical':True,'development_metrics_recomputed_from_saved_predictions':True,
               'real_reference_PSNR_computed':False,'baseline_failed_final_duration_hash_receipt_not_invented':True})

board_map={b['id']:b for b in render['boards']};label_map={'none':'Local-only2k','pooled':'Pooled2k','spatial':'Spatial2k'}
for triplet in render['triplets']:
    board=board_map[triplet['id']];image=np.asarray(Image.open(checked(board['image'])));meta=read_json(checked(triplet['metadata']));strip=np.asarray(Image.open(checked(triplet['image'])))
    relevant=[board['panels'][0] if board['panels'][0]['label']=='Noisy (Malvar)'else board['panels'][1],
              next(p for p in board['panels']if p['label']==label_map[triplet['arm']]),
              next(p for p in board['panels']if p['label']in ['Exact GT','ISO100 AHD, not GT'])]
    for source,target in zip(relevant,meta['panels'],strict=True):
        x,y,w,h=source['png_xywh'];tx,ty,tw,th=target['png_xywh'];assert(w,h)==(tw,th)==(160,160)
        np.testing.assert_array_equal(image[y:y+h,x:x+w],strip[ty:ty+th,tx:tx+tw])
view=read_json(root/'render-all-v1/native-viewing.json')
assert view['actual_native_boards_viewed']==16 and view['viewed_boards']==[b['image']for b in render['boards']]
checks.append({'final_boards_actually_viewed':16,'triplets_exact_native160_subsets_of_viewed_boards':48,'independent_real_references_not_GT':True})

inventory=read_json(repo/'.cache/canonical-fullscene-lineage-v1.json')
assert inventory['all427_exact_RGB_crops_found'] and len(inventory['sources'])==427
assert sum(v for k,v in inventory['phase_origin_histogram'].items()if k!='0,0')==315
assert read_json(root/'whole-scene-GFX-lineage.json')['all_passed']
assert '47 passed' in (repo/'.cache/scene-photo-inference-tests-v1.log').read_text()
assert (repo/'.cache/scene-native-lint-v2.log').read_text().strip()=='All checks passed!'
checks.append({'canonical_photo_crop_inventory':427,'source_CFA_frame_offsets_needed':315,'GFX_full_capture_crop_lineage_exact':6,'focused_tests_passed':47})

documents=['docs/whole-scene-context-native-review.md','docs/whole-scene-context-next-test.md','docs/full-corpus-scaling.md',
           'docs/current-model.md','docs/experiments.md','docs/research.md','docs/index.md','docs/gfx-green-mesh.md','docs/gfx-qualitative.md',
           'diary/index.md','diary/2026-11-17-01-45-10-scene-inference-first-control.md']
links=0
for filename in documents:
    path=repo/filename
    for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
        if '://'in target or target.startswith('#'):continue
        target=target.split('#')[0].strip('<>')
        if target=='results/whole-scene-context-native-review-v1/independent-review.json':continue
        assert (path.parent/target).exists(),(filename,target);links+=1
checks.append({'current_local_document_links_exist':links,'README_lines':len((repo/'README.md').read_text().splitlines())})
write_json(repo/'.cache/scene-native-independent-verification-v1.json',{'publication':reference(publication_path),'verifier':reference(__file__),'all_passed':True,'checks':checks,
           'scope':'Independent exact archive/source/native-pixel, CPU checkpoint/Adam/raw/EMA, matched observations and saved-prediction metric audit.0 new root/DINO/optimizer/noise/RAW calls. Actual viewing separately recorded; full427/camera and the running64-scene analysis remain pending. No missing baseline terminal receipt reconstructed.'})
print('all_passed',True,'groups',len(checks),'links',links)
