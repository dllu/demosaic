"""Append the completed independent audit, preserving every original receipt."""
import gzip
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo=Path.cwd();root=repo/'docs/results/whole-scene-context-native-review-v1'
verification=repo/'.cache/scene-native-independent-verification-v1.json'
assert read_json(verification)['all_passed']
names=['publish-scene-native-review-v1.log','verify-scene-native-review-v1.py',
       'verify-scene-native-review-v1.log','scene-native-independent-verification-v1.json','seal-scene-native-review-v1.py']
archives=[]
for index,name in enumerate(names):
    source=repo/'.cache'/name;data=source.read_bytes();path=root/f'verification-{index:02d}-{name}.gz'
    with path.open('xb')as out:out.write(gzip.compress(data,mtime=0))
    assert gzip.decompress(path.read_bytes())==data
    archives.append({'original':reference(source),'published':reference(path),'decompressed_bytes_exact':True})
write_json(root/'independent-review.json',{'publication':reference(root/'publication.json'),'archives':archives,'all_passed':True,
           'scope':'Exact132 archived originals,496 frozen source members and114 native assets.3 complete2000-update CPU raw/EMA/Adam states, byte-identical4000-observation logs, exact91-tensor no-scene inference export. Recomputed saved-prediction metrics;16 final boards actually viewed and48 triplets pixel-identical to their panels.427-source geometry/6 GFX context lineage/47 tests,527 existing local links.0 new neural/noise/RAW/optimizer work. Full427/camera scores and running64-source study remain pending.'})
checked(reference(root/'independent-review.json'))
assert (repo/'docs/whole-scene-context-native-review.md').exists()
print(root/'independent-review.json')
