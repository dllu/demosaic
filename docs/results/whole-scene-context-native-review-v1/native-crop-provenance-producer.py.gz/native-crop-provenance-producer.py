"""Add explicit original-source coordinates without rewriting retained sidecars."""
import gzip
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo=Path.cwd();root=repo/'.cache/experiments/scene-context-native-review-v2';plan=read_json(root/'plan.json')
render=read_json(root/'render-all-v1/result.json');training=read_json(checked(plan['training_plan']))
catalogue={row['id']:row for row in [__import__('json').loads(line)for line in checked(training['development_manifest']).read_text().splitlines()]}
lineage=read_json(root/'whole-scene-GFX-lineage.json');real={v['family']:v for v in lineage['results']};cases=[]
for board in render['boards']:
    obs=next(o for o in plan['observations']if o['id']==board['observation']);index=board['case']['crop_index'];roi=board['case']['ROI_xywh'];rx,ry,rw,rh=roi
    with np.load(checked(obs['arrays']),allow_pickle=False)as arrays:
        prefix='crop_'if obs['kind']=='development'else''
        wb=arrays[prefix+'wb'][index].tolist();matrix=arrays[prefix+'matrix'][index].tolist()
    record={'board_id':board['id'],'ROI_within_model_output_xywh':roi,'input_arrays':obs['arrays'],
            'noise_conditioning':obs['noise'],'display_exposure':obs['display_exposure'],'WB':wb,'camera_to_sRGB':matrix,
            'weights':'EMA','endpoints':{arm:read_json(root/arm/'collection.json')['checkpoint']for arm in ['none','pooled','spatial']},
            'reference_role':obs['reference_role']}
    if obs['kind']=='development':
        x,y,w,h=obs['boxes_xywh'][index];assert rw==rh==160 and rx+rw<=w and ry+rh<=h
        source=catalogue[obs['source_id']]
        record.update({'source_id':obs['source_id'],'linear_uint16_source_cache':obs['source_cache'],'source_native_xywh':[x+rx,y+ry,rw,rh],
                       'native_model_context_xywh':[x,y,w,h],'full_scene_recipe':obs['recipe'],
                       'attribution':{k:source.get(k)for k in ['title','author','license','license_url','page_url','attribution']},
                       'source_transform':'No D4/resize; trim only odd trailing row/column of the complete binned source.'})
    else:
        family='main'if obs['kind']=='gfx'else'mesh';x,y,w,h=obs['metadata']['context_xywh']if family=='main'else[600,6260,768,768]
        record.update({'noisy_cached_RAW':real[family]['local_cached_RAW'],'source_native_xywh':[x+rx,y+ry,rw,rh],'native_model_context_xywh':[x,y,w,h]})
        if family=='main':record['independent_reference_native_xywh']=[*obs['metadata']['region']['reference_xy'],rw,rh]
        else:
            record['independent_reference_native_xywh']=board['case']['reference_raw_xywh'];record['camera_JPEGs']=board['case']['camera_JPEGs']
    cases.append(record)
destination=repo/'docs/results/whole-scene-context-native-review-v1';path=destination/'native-crop-provenance.json'
write_json(path,{'publication':reference(destination/'publication.json'),'producer':reference(__file__),'cases':cases,
           'scope':'All16 final boards: explicit original cached source and source/native-model ROIs, actual camera/display/noise conditioning and every EMA checkpoint. Original triplet JSON/PNG bytes stay unchanged. Independent real references/JPEGs are not exact GT. No new inference/noise/RAW work.'})
source=Path(__file__);target=destination/'native-crop-provenance-producer.py.gz'
with target.open('xb')as out:out.write(gzip.compress(source.read_bytes(),mtime=0))
assert len(cases)==16 and all(c['source_native_xywh'][2:]==[160,160]for c in cases)
write_json(destination/'native-crop-provenance-audit.json',{'provenance':reference(path),'producer_archive':reference(target),'original_producer':reference(source),
           'all16_source_ROIs_resolved':True,'preserved_sidecars_unmodified':True})
print('source_provenance',len(cases))
