"""Shared objectives implementations."""
