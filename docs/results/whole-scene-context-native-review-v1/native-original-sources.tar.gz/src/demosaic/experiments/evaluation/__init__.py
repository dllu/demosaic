"""Shared evaluation implementations."""
