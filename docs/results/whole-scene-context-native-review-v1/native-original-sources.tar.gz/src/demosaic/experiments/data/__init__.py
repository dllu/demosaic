"""Shared data implementations."""
