"""Actual native scene/crop forward checks, independent of the GPU allocation."""
import os
import time
from pathlib import Path

import torch

from demosaic.cfa import unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import SceneInferenceSession, load_scene_checkpoint
from demosaic.scene_training_data import ScenePhotoDataset

os.sched_setaffinity(0, [24, 25])
torch.set_num_threads(2)
root = Path('.cache/experiments/scene-inference-qualification-v1').resolve()
root.mkdir()
plan_path = Path('.cache/experiments/whole-scene-context-ablation-v2/plan.json').resolve()
plan = read_json(plan_path)
preflight = read_json(Path(plan['root']) / 'preflight/result.json')
dataset = ScenePhotoDataset(checked(plan['development_manifest']), seed=plan['data_seed'],
                           patch_size=256, crops_per_scene=2)
sample = dataset[47]
result = []
with ieee_fp32():
    for mode in ['none', 'spatial']:
        endpoint = next(row['roundtrip_checkpoint'] for row in preflight['results'] if row['mode'] == mode)
        model, state = load_scene_checkpoint(checked(endpoint), weights='model', expected_sha256=endpoint['sha256'])
        calls = {'wrapper': 0, 'encoder': 0}
        hooks = [model.register_forward_pre_hook(lambda *_, c=calls: c.__setitem__('wrapper', c['wrapper']+1)),
                 model.base.context.backbone.register_forward_pre_hook(lambda *_, c=calls: c.__setitem__('encoder', c['encoder']+1))]
        obs = sample.observation
        began = time.monotonic()
        session = SceneInferenceSession(model, unpack(obs.packed[None])[0, 0], obs.colors,
                    shot=obs.recipe.shot, read=obs.recipe.read, wb=obs.wb, matrix=obs.matrix,
                    preview_long_side=state['preview_long_side'], preview_exposure=state['preview_exposure'])
        actual = session.predict_boxes(sample.metadata['boxes_xywh'], batch_size=2)
        assert calls == {'wrapper': 1, 'encoder': 1 if mode == 'none' else 2}
        with torch.inference_mode():
            direct_scene = None if mode == 'none' else model.encode_scene(obs.packed, obs.colors, obs.wb, obs.matrix,
                                long_side=state['preview_long_side'], exposure=state['preview_exposure'])
            expected = model(*(sample.crops[k] for k in ['packed','variance','colors','wb','matrix']),
                             scene=direct_scene, boxes_xywh=sample.metadata['boxes_xywh'])
        difference = (actual - expected).abs() * 65535
        assert difference.max() == 0
        for hook in hooks: hook.remove()
        row = {'mode': mode, 'checkpoint': endpoint, 'weights': 'raw-discarded-step2',
               'session_calls': {'wrapper': 1, 'encoder': 1 if mode == 'none' else 2},
               'all_check_calls': calls, 'max_difference_DN16': float(difference.max()),
               'session_prediction': fingerprint(actual), 'direct_prediction': fingerprint(expected),
               'seconds': time.monotonic()-began, 'session': session.metadata}
        result.append(row)
        print(mode, row['max_difference_DN16'], row['seconds'], flush=True)
        del model, state, session, actual, expected, direct_scene
write_json(root/'result.json', {'script': reference(__file__), 'plan': reference(plan_path),
           'sources': {str(p): reference(p)['sha256'] for p in [Path('src/demosaic/scene_inference.py').resolve(),Path('src/demosaic/scene_restoration.py').resolve()]},
           'sample': sample.metadata, 'results': result, 'all_passed': True,
           'scope': 'CPU IEEE FP32 contiguous actual V120/scene-wrapper forwards on one reserved development scene, two native256 crops. No GPU calls or interference with allocated training. Discarded preflight weights; plumbing parity, not a restoration-quality score. Full scene from noisy RAW, never clean/reference context. Timing is check time, not a production inference benchmark.'})
