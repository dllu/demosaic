"""Export the unused-scene control for the existing full-panel model loader."""
from pathlib import Path

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint

torch.set_num_threads(2)
root=Path('.cache/experiments/scene-context-native-review-v2').resolve()
plan=read_json(root/'plan.json');training=read_json(checked(plan['training_plan']))
terminal=read_json(Path(training['work'])/'artifacts/train/none/completed.json')
binding=terminal['checkpoints'][-1]
original=torch.load(checked(binding),map_location='cpu',weights_only=True)
assert original['mode']=='none' and original['step']==2000
parent=torch.load(checked(plan['parent']),map_location='cpu',weights_only=True)
payload={'model':{k.removeprefix('base.'):v for k,v in original['model'].items()if k.startswith('base.')},
         'ema':{k.removeprefix('base.'):v for k,v in original['ema'].items()if k.startswith('base.')},
         'model_config':parent['model_config'],'step':2000,'config':{'initialized_from':plan['parent'],
         'scene_training_plan':plan['training_plan'],'source_scene_checkpoint':binding,
         'scope':'Native-bin4 shared-observation local-only control. Only no-scene mode is exportable; all91 learned base tensors retained. Inference export only, not a resumable optimizer checkpoint. Original complete scene checkpoint remains authoritative.'},
         'source_scene_checkpoint':binding,'inference_export_only':True}
assert len(payload['model'])==len(payload['ema'])==91
path=root/'none/legacy-base-weights.pt';assert not path.exists();torch.save(payload,path)
model,state=load_checkpoint(path,'cpu')
assert len(model.restoration_state_dict())==91
assert all(torch.equal(v,state['ema'][k]) for k,v in model.restoration_state_dict().items())
write_json(root/'none/legacy-base-export.json',{'source_scene_checkpoint':binding,'export':reference(path),
           'script':reference(__file__),'source_plan':reference(root/'plan.json'),
           'model_raw_EMA_base_tensors_each':91,'actual_legacy_loader_EMA_tensors_exact':True,
           'step':2000,'optimizer_not_exported':True,
           'scope':'No-scene mode forwards exactly to base; unused adapter omitted without changing any learned base value or neural operation. Legacy loader constructs and reloads all91 EMA tensors exactly, with0 neural calls. This is ready for the old427/camera evaluation pipeline, not a new score, training continuation or context-conditioned export.'})
print(reference(path))
