"""Fix native development/GFX inputs before collecting endpoint predictions."""
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import SceneRecipe, observe_scene, scene_crop_boxes

torch.set_num_threads(2)
repo = Path.cwd()
root = repo / '.cache/experiments/scene-context-native-review-v1'
root.mkdir()
(root/'inputs').mkdir()
training_plan = repo / '.cache/experiments/whole-scene-context-ablation-v2/plan.json'
training = read_json(training_plan)
manifest = checked(training['development_manifest'])
rows = [__import__('json').loads(line) for line in manifest.read_text().splitlines()]
protocol = yaml.safe_load((repo/'configs/evaluation.yaml').read_text())
matrix = torch.tensor(protocol['camera_to_srgb'], dtype=torch.float32)
inverse = torch.linalg.inv(matrix)
observations = []
for source_index in [0, 1]:
    row = rows[source_index]
    cache = checked({'path': str((manifest.parent/row['cache']).resolve()), 'sha256': row['cache_sha256']})
    array = np.load(cache, allow_pickle=False)
    assert array.dtype == np.uint16 and list(array.shape) == row['shape']
    rgb = torch.from_numpy(array.copy().astype(np.float32)).permute(2,0,1)/65535
    rgb = rgb[:,:rgb.shape[1]//2*2,:rgb.shape[2]//2*2]
    boxes = scene_crop_boxes(rgb.shape[-2:], count=4, patch_size=256, seed=710+source_index)
    for condition_name in ['shadows', 'iso12800-prior']:
        condition = next(c for c in protocol['conditions'] if c['name'] == condition_name)
        identity = f'development-{source_index}-{condition_name}'
        recipe = SceneRecipe('RGGB', tuple(protocol['white_balance']), tuple(tuple(v) for v in inverse.tolist()),
                             condition['exposure'], condition['shot'], condition['read'], .03,
                             71000+100*source_index+len(observations))
        obs = observe_scene(rgb, recipe)
        crops = obs.crops(boxes)
        path = root/'inputs'/(identity+'.npz')
        with path.open('xb') as stream:
            np.savez_compressed(stream, scene_packed=obs.packed.numpy(),
                                **{'crop_'+k:v.numpy() for k,v in crops.items()})
        observations.append({'id':identity,'kind':'development','arrays':reference(path),
                             'source_id':row['id'],'source_cache':reference(cache),'native_hw':list(rgb.shape[-2:]),
                             'boxes_xywh':boxes,'recipe':asdict(recipe),'noise':{'shot':recipe.shot,'read':recipe.read},
                             'ROI_xywh':[48,48,160,160], 'display_exposure':1/recipe.exposure,
                             'reference_role':'Exact synthetic clean target; this source is reserved for the scene-context probe, but belongs to the larger scaling training pool.'})
old = repo/'.cache/experiments/raw-spatial-endpoint-review-v3/queue-plan.json'
previous = read_json(old)
for identity in ['main-overcast-sky','main-building-detail','main-foliage','main-chain-link-fence','mesh-nominal','mesh-profile3879']:
    observation = next(row for row in previous['observations'] if row['id']==identity)
    checked(observation['arrays'])
    observations.append(observation)
script = repo/'scripts/review_scene_context_native.py'
sources = {str(p):reference(p)['sha256'] for p in [script,repo/'src/demosaic/scene_inference.py',repo/'src/demosaic/scene_restoration.py']}
write_json(root/'plan.json',{'root':str(root),'training_plan':reference(training_plan),'parent':training['parent'],
           'DINO_sha256':training['DINO_sha256'],'legacy_inputs_plan':reference(old),
           'sources':sources,'script':reference(script),'observations':observations,
           'main_full_RAW':reference(repo/'configs/gfx-qualitative-20231231.json'),
           'mesh_full_RAW':reference(repo/'configs/gfx-green-mesh-20231231.json'),
           'preview_long_side':training['preview_long_side'],'preview_exposure':training['preview_exposure'],
           'scope':'Four full-scene noisy development observations and six immutable existing GFX contexts, two native160 cab ROIs/both profiles/JPEG references. CPU IEEE FP32 contiguous, EMA endpoint. No427/camera claim. Development sources are context-probe holdouts, not holdouts from the larger scaling corpus. No output-dependent scene/crop/noise selection. Full real noisy scenes decoded only from local cached RAFs for context arms; independent references never enter context or scores. Baseline and each new endpoint collected once; rendering reuses predictions.'})
print(root)
