"""Recover serialization-only metadata from all retained baseline predictions."""
import math
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.metrics import quality_metrics
from demosaic.prediction_archive import fingerprint

torch.set_num_threads(2)
root = Path('.cache/experiments/scene-context-native-review-v1').resolve()
plan = read_json(root/'plan.json')
log = (root/'parent.log').read_text()
assert 'ValueError: Out of range float values are not JSON compliant: nan' in log
assert not (root/'parent/collection.json').exists()
records = []
for observation in plan['observations']:
    path = root/'parent'/(observation['id']+'-RGB-f32.npy')
    pred = torch.from_numpy(np.load(path,allow_pickle=False))
    development = observation['kind']=='development'
    assert tuple(pred.shape)==((4,3,256,256) if development else tuple(observation['output_shape']))
    assert torch.isfinite(pred).all()
    with np.load(checked(observation['arrays']), allow_pickle=False)as data:
        arrays = {k:torch.from_numpy(data[k].copy())for k in data.files}
    args = {k:arrays[('crop_'if development else '')+k]for k in ['packed','variance','colors','wb','matrix']}
    metrics = None
    if development:
        metrics = {k:[float(x)if math.isfinite(float(x))else None for x in v]for k,v in quality_metrics(pred[...,8:-8,8:-8],arrays['crop_target'][...,8:-8,8:-8],args['wb'],args['matrix']).items()}
    prefix = 'parent '+observation['id']+' '
    lines = [line for line in log.splitlines()if line.startswith(prefix)]
    assert len(lines)==1
    seconds = float(lines[0][len(prefix):])
    records.append({'id':observation['id'],'prediction':reference(path),'input_fingerprints':{k:fingerprint(v)for k,v in args.items()},'inference_seconds':seconds,'metrics':metrics,'scene_box_xywh':None})
write_json(root/'parent/collection-recovered.json',{'plan':reference(root/'plan.json'),'arm':'parent','checkpoint':plan['parent'],'weights':'EMA','mode':'none',
           'counts':{'root':10,'encoder':10},'count_evidence':'All10 distinct prediction files/log lines, plus terminal traceback after both exact hook-count assertions. No neural replay.',
           'seconds':None,'measured_prediction_seconds_sum':sum(r['inference_seconds']for r in records),'records':records,
           'recovery_script':reference(__file__),'failed_collector_source':reference(Path('.cache/scene-native-collector-v1-pinned.py')),'failed_log':reference(root/'parent.log'),
           'post_run_model_hash_receipt_available':False,'scope':'All actual baseline predictions completed. Only JSON serialization failed on undefined empty-highlight metrics; recover saved predictions and per-call log timings, encode unavailable metrics as null. Do not invent the missing final model-hash/duration receipt. No new model forward, source/cache decoding or noise draw. Numerical/native/broad review separate.'})
new = Path('.cache/experiments/scene-context-native-review-v2').resolve();new.mkdir()
sources = {str(p):reference(p)['sha256']for p in [Path('scripts/review_scene_context_native.py').resolve(),Path('src/demosaic/scene_inference.py').resolve(),Path('src/demosaic/scene_restoration.py').resolve()]}
write_json(new/'plan.json',{**plan,'root':str(new),'sources':sources,'script':reference(Path('scripts/review_scene_context_native.py')),
           'previous_plan':reference(root/'plan.json'),'baseline_collection':reference(root/'parent/collection-recovered.json'),
           'serialization_correction':'Represent undefined per-image metrics as null. Original baseline predictions/logs and exact pre-fix frozen source remain retained. No baseline neural replay or new synthetic observations. Fresh endpoint collection follows the same fixed inputs.'})
print('Recovered10 baseline predictions; remaining endpoint plan',new/'plan.json')
