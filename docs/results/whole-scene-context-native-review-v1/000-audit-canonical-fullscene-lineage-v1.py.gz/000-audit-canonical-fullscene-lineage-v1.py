"""Locate exact legacy photo crops within complete cached fields, without noise."""
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from demosaic.data import CleanDataset
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

torch.set_num_threads(2)
old = Path('.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-quality-v1/evaluation-plan-v1.json').resolve()
stage = read_json(old)['stages']['photo']
manifest = checked(stage['manifest'])
dataset = CleanDataset(manifest, split='val', patch_size=256, native_crop=True, trace_sources=True)
assert len(dataset) == 427
rows, parity = [], Counter()
for i in range(len(dataset)):
    item = dataset[i]
    provenance = json.loads(item['source'])
    assert provenance['kind'] == 'photographic'
    record = dataset.rows[i]
    path = Path(provenance['cache'])
    assert reference(path)['sha256'] == record['cache_sha256']
    array = np.load(path, mmap_mode='r', allow_pickle=False)
    assert array.dtype == np.uint16 and list(array.shape) == record['shape']
    x, y, w, h = provenance['cache_xywh']
    assert (w, h) == (256, 256)
    ox, oy = x % 2, y % 2
    height = (array.shape[0] - oy) // 2 * 2
    width = (array.shape[1] - ox) // 2 * 2
    box = [x - ox, y - oy, w, h]
    assert box[0] % 2 == box[1] % 2 == 0
    assert box[0] + w <= width and box[1] + h <= height
    exact = torch.from_numpy(array[y:y+h, x:x+w].copy().astype(np.float32)).permute(2,0,1) / 65535
    assert torch.equal(exact, item['rgb'])
    parity[f'{ox},{oy}'] += 1
    rows.append({'id': record['id'], 'index': i, 'cache': reference(path),
                 'source_shape': list(array.shape), 'legacy_cache_xywh': [x,y,w,h],
                 'phase_frame_source_origin_xy': [ox,oy], 'phase_frame_native_hw': [height,width],
                 'legacy_crop_in_frame_xywh': box, 'legacy_RGB': fingerprint(item['rgb'])})
write_json(Path('.cache/canonical-fullscene-lineage-v1.json'), {
    'script': reference(__file__), 'legacy_plan': reference(old), 'manifest': stage['manifest'],
    'all427_exact_RGB_crops_found': True, 'phase_origin_histogram': dict(parity), 'sources': rows,
    'scope': 'Cached full binned source fields, not uncropped camera photographs. Trim at most one source pixel from each side to preserve the selected legacy crop and its actual CFA phase. No crop relocation/resizing, sensor draws, target-based decisions, neural calls or GPU work. Future scoring must retain canonical noisy tile tensors and targets exactly; surrounding noisy context needs a separate declared source/condition-keyed draw and exact native measurement insertion. This inventory does not itself qualify a comparable full427 evaluation.'})
print(json.dumps({'sources': len(rows), 'exact_crops': True, 'source_parity': dict(parity)}))
