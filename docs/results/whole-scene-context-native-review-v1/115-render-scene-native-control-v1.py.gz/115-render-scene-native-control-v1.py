"""Render retained native pixels; no model/noise/reference fitting or resizing."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

from demosaic.cfa import malvar
from demosaic.color import linear_to_srgb, srgb_to_linear
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop, save_triplet

torch.set_num_threads(2)
root = Path('.cache/experiments/scene-context-native-review-v2').resolve()
plan_path = root/'plan.json'; plan=read_json(plan_path)
baseline = read_json(checked(plan['baseline_collection']))
endpoint = read_json(root/'none/collection.json')
assert endpoint['plan']==reference(plan_path) and endpoint['weights']=='EMA'
base_rows = {r['id']:r for r in baseline['records']}
new_rows = {r['id']:r for r in endpoint['records']}
output = root/'render-none-v1';output.mkdir()
figures, triplets = [],[]

def image_bytes(array):
    assert array.shape==(160,160,3) and np.isfinite(array).all()
    return np.rint(array.clip(0,1)*255).astype(np.uint8)

def board(name, panels, metadata):
    path=output/(name+'.png')
    image=Image.new('RGB',(8+168*len(panels),192),'#eeeeee');draw=ImageDraw.Draw(image)
    rectangles=[]
    for i,(label,values)in enumerate(panels):
        x=8+168*i;draw.text((x,5),label,fill='black');image.paste(Image.fromarray(image_bytes(values)),(x,24))
        rectangles.append({'label':label,'png_xywh':[x,24,160,160]})
    image.save(path)
    reread=np.asarray(Image.open(path))
    for rectangle,(_,values)in zip(rectangles,panels,strict=True):
        x,y,w,h=rectangle['png_xywh'];np.testing.assert_array_equal(reread[y:y+h,x:x+w],image_bytes(values))
    figures.append({'id':name,'image':reference(path),'panels':rectangles,**metadata})

for observation in plan['observations']:
    identity=observation['id'];a,b=base_rows[identity],new_rows[identity]
    assert a['input_fingerprints']==b['input_fingerprints']
    parent=torch.from_numpy(np.load(checked(a['prediction']),allow_pickle=False))
    restored=torch.from_numpy(np.load(checked(b['prediction']),allow_pickle=False))
    with np.load(checked(observation['arrays']),allow_pickle=False)as data:
        arrays={k:torch.from_numpy(data[k].copy())for k in data.files}
    development=observation['kind']=='development'
    prefix='crop_'if development else''
    wb,matrix,packed,colors=[arrays[prefix+k]for k in ['wb','matrix','packed','colors']]
    noisy=malvar(packed,colors,wb)
    exposure=observation['display_exposure']
    if development:
        cases=[{'name':f'crop{i}','ROI_xywh':observation['ROI_xywh'],'crop_index':i}for i in [0,1]]
    elif observation['kind']=='gfx':
        cases=[{'name':identity,'ROI_xywh':observation['ROI_xywh'],'crop_index':0}]
    else:
        cases=[{**c,'crop_index':0}for c in observation['cases']]
    for case in cases:
        index=case['crop_index'];roi=case['ROI_xywh'];camera_wb=wb[index:index+1];camera_matrix=matrix[index:index+1]
        def display(value, box=roi):
            return display_crop(value[index:index+1],camera_wb,camera_matrix,box,exposure=exposure)
        panels=[('Noisy (Malvar)',display(noisy)),('V120 EMA',display(parent)),('Local-only2k EMA',display(restored))]
        if development:
            ref=display(arrays['crop_target']);reference_label='Exact GT'
        elif observation['kind']=='gfx':
            reference_rgb=torch.from_numpy(np.load(checked(observation['target']),allow_pickle=False))
            ref=display_crop(reference_rgb,camera_wb,camera_matrix,[0,0,160,160],exposure=exposure);reference_label='ISO100 AHD, not GT'
        else:
            ref=display(arrays['reference_rgb']);reference_label='ISO100 AHD, not GT'
        panels.append((reference_label,ref))
        if observation['kind']=='mesh':
            def jpeg(role):
                pixels=np.load(checked(case['camera_JPEGs'][role]['pixels']),allow_pickle=False)
                return linear_to_srgb((srgb_to_linear(pixels.astype(np.float32)/255)*exposure).clip(0,1))
            panels.insert(0,('ISO6400 camera JPEG',jpeg('noisy_camera_jpeg')))
            panels.append(('ISO100 camera JPEG',jpeg('reference_camera_jpeg')))
        name=identity+'-'+case['name']
        metadata={'observation':identity,'case':case,'checkpoint':endpoint['checkpoint'],'weights':'EMA',
                  'parent_checkpoint':baseline['checkpoint'],'noise':observation['noise'],
                  'input_arrays':observation['arrays'],'display_exposure':exposure,'reference_role':observation['reference_role']}
        board(name,panels,metadata)
        selected=[('Noisy (Malvar)',display(noisy)),('Local-only2k EMA',display(restored)),(reference_label,ref)]
        triplet=save_triplet(output/'triplets',name,selected,caption=name,metadata=metadata)
        triplets.append({'id':name,'image':reference(output/'triplets'/triplet['image']),
                         'metadata':reference((output/'triplets'/triplet['image']).with_suffix('.json'))})
means={}
for arm,collection in [('V120',baseline),('none-2000',endpoint)]:
    for condition in ['shadows','iso12800-prior']:
        group=[r for r in collection['records']if r['id'].startswith('development-')and r['id'].endswith(condition)]
        means[arm+'-'+condition]={key:float(np.mean([v for row in group for v in row['metrics'][key]if v is not None]))
                                 for key in group[0]['metrics']if any(v is not None for row in group for v in row['metrics'][key])}
write_json(output/'result.json',{'plan':reference(plan_path),'baseline':plan['baseline_collection'],
           'endpoint_collection':reference(root/'none/collection.json'),'renderer':reference(__file__),
           'native_crop_size':[160,160],'boards':figures,'triplets':triplets,'development_condition_means':means,
           'actual_native_viewing':'pending','scope':'Retained predictions rendered without resizing; independently reread every PNG panel and verify exact display pixels. Four noisy full development fields,16 scored crops;8 fixed displayed development crops plus4 main GFX regions and4 cab ROI/profile combinations. These narrow development metrics are not full427/camera scores. ISO100/JPEG references are qualitative, not exact GT. No model/noise/RAW calls.'})
print('rendered',len(figures),'boards and',len(triplets),'triplets')
