"""Archive closed native evidence and separately identify a running64-source study."""
import gzip
import hashlib
import io
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo=Path.cwd();root=repo/'.cache/experiments/scene-context-native-review-v2'
old=repo/'.cache/experiments/scene-context-native-review-v1'
large=repo/'.cache/experiments/scene-development64-context-review-v1'
destination=repo/'docs/results/whole-scene-context-native-review-v1';destination.mkdir()
images=repo/'docs/images/whole-scene-context-native-v1';images.mkdir()
render=read_json(root/'render-all-v1/result.json')
assets=[]
for source in (root/'render-all-v1').rglob('*'):
    if not source.is_file() or source.suffix not in {'.png','.json'}:continue
    target=images/source.relative_to(root/'render-all-v1');target.parent.mkdir(exist_ok=True)
    shutil.copyfile(source,target);assert source.read_bytes()==target.read_bytes()
    assets.append({'original':reference(source),'published':reference(target),'bytes_exact':True})
paths=[]
for base in [old,root]:
    paths.extend(p for p in base.iterdir()if p.is_file()and p.suffix=='.json')
paths.extend([old/'parent.log',old/'parent/collection-recovered.json'])
for arm in ['none','pooled','spatial']:
    paths.extend([root/(arm+'.log'),root/arm/'collection.json'])
paths.append(root/'none/legacy-base-export.json')
paths.extend([root/'render-none-v1/result.json',root/'render-none-v1/native-viewing.json'])
paths.extend(p for p in (root/'render-none-v1').rglob('*')if p.is_file()and p.suffix in {'.png','.json'})
train=read_json(checked(read_json(root/'plan.json')['training_plan']));trainroot=Path(train['work'])/'artifacts/train'
for arm in ['none','pooled','spatial']:
    paths.extend(trainroot/arm/name for name in ['completed.json','owner.json','observations.jsonl','train.jsonl'])
qual=repo/'.cache/experiments/scene-inference-qualification-v2'
paths.extend([qual/'result.json',qual/'admission-addendum.json'])
paths.extend(large/name for name in ['plan.json','launch.json','pooled-shuffle-invariance.json'])
# Only already closed initial cases; never seal mutable progress/logs as results.
paths.extend(large/'cases'/name/'result.json'for name in [
    'development-0-shadows','development-0-iso12800-prior','development-1-shadows','development-1-iso12800-prior'])
paths.extend(repo/p for p in [
    'src/demosaic/scene_inference.py','src/demosaic/scene_restoration.py','src/demosaic/photo_scene.py',
    'tests/test_scene_inference.py','tests/test_photo_scene.py','scripts/review_scene_context_native.py',
    '.cache/scene-inference-tests-v1.log','.cache/scene-photo-inference-tests-v1.log','.cache/scene-inference-lint-v1.log','.cache/scene-native-lint-v2.log',
    '.cache/qualify-scene-inference-cpu-v1.py','.cache/qualify-scene-inference-cpu-v2.py',
    '.cache/scene-inference-qualification-cpu-v1.log','.cache/scene-inference-qualification-cpu-v2.log',
    '.cache/audit-canonical-fullscene-lineage-v1.py','.cache/canonical-fullscene-lineage-v1.json','.cache/canonical-fullscene-lineage-v1.log',
    '.cache/prepare-scene-native-review-v1.py','.cache/prepare-scene-native-review-v1.log',
    '.cache/scene-native-collector-v1-pinned.py','.cache/recover-scene-native-parent-v1.py','.cache/recover-scene-native-parent-v1.log',
    '.cache/render-scene-native-control-v1.py','.cache/render-scene-native-control-v1.log','.cache/render-scene-native-control-v2.log',
    '.cache/render-scene-native-all-v1.py','.cache/render-scene-native-all-v1.log',
    '.cache/audit-gfx-whole-scene-lineage-v1.py','.cache/audit-gfx-whole-scene-lineage-v1.log',
    '.cache/export-scene-none-2000-v1.py','.cache/export-scene-none-2000-v1.log',
    '.cache/queue-scene-native-review-v1.py','.cache/run-scene-development64-v1.py','.cache/scene-development64-shuffle-check-v1.json',
    '.cache/publish-scene-native-review-v1.py'])
snapshots=[]
for label,manifest in [('native-original',old/'source-snapshot-addendum.json'),('native-corrected',root/'source-snapshot.json'),('development64',large/'plan.json')]:
    specification=read_json(manifest);work=Path(specification['work']);members=[]
    path=destination/(label+'-sources.tar.gz')
    with tarfile.open(path,'w:gz')as tar:
        for source,digest in sorted(specification['frozen_files'].items()):
            p=checked({'path':source,'sha256':digest});data=p.read_bytes();name=str(p.relative_to(work))
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
            members.append({'member':name,'original':{'path':source,'sha256':digest}})
    snapshots.append({'manifest':reference(manifest),'published':reference(path),'members':members})
archives=[];compressed={}
for index,source in enumerate(sorted(set(paths))):
    data=source.read_bytes();digest=hashlib.sha256(data).hexdigest()
    if digest in compressed:target=compressed[digest]
    else:
        target=destination/f'{index:03d}-{source.name}.gz'
        with target.open('xb')as out:out.write(gzip.compress(data,mtime=0))
        compressed[digest]=target
    assert gzip.decompress(target.read_bytes())==data
    archives.append({'original':{'path':str(source),'sha256':digest},'published':reference(target),'decompressed_bytes_exact':True})
write_json(destination/'publication.json',{'archives':archives,'source_snapshots':snapshots,'native_assets':assets,
           'primary_report':str(repo/'docs/whole-scene-context-native-review.md'),'publisher':reference(__file__),
           'native_viewing':reference(root/'render-all-v1/native-viewing.json'),
           'scope':'All3 fixed2000-update training endpoints and EMA native review complete.16 final matched boards/48 triplets, plus earlier16 interim control boards, original failures/recovery and47 focused tests. Canonical427 full-field/crop inventory is geometry, not a new score. Fixed64/intervention study is running; only its immutable admission/launch/first4 case receipts are sealed here. Full427/camera scores remain missing and PSNR history unchanged.',
           'not_embedded':'Checkpoint/Adam/DINO binaries, full noisy scene arrays/native predictions and image caches remain locally bound. No claim every transitive historical path is packed. Original baseline final duration/hash receipt unavailable after serialization failure; recovered metadata does not invent it. Loose pre-disk-guard shuffle fixture source identity predates the frozen study driver; the actual trained pooled-invariance receipt separately qualifies the executed source.'})
print('archives',len(archives),'unique_compressed',len(compressed),'source_members',sum(len(s['members'])for s in snapshots),'native_assets',len(assets))
