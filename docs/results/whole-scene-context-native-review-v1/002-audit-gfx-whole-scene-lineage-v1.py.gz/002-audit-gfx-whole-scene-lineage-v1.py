"""Check exact existing native crop measurements against complete cached RAWs."""
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

torch.set_num_threads(2)
root=Path('.cache/experiments/scene-context-native-review-v2').resolve()
plan=read_json(root/'plan.json');results=[]
for family in ['main','mesh']:
    config=read_json(checked(plan[family+'_full_RAW']))
    source=Path(config['noisy']) if family=='main' else checked(config['sources']['noisy'])
    raw,meta=read_raw(source)
    assert meta.pattern=='RGGB' and meta.iso==6400 and all(n%2==0 for n in raw.shape)
    matches=[]
    for obs in plan['observations']:
        if obs['kind']!=('gfx'if family=='main'else'mesh'):continue
        box=obs['metadata']['context_xywh'] if family=='main' else [600,6260,768,768]
        x,y,w,h=box
        with np.load(checked(obs['arrays']),allow_pickle=False)as data:
            packed=pack(torch.from_numpy(raw[y:y+h,x:x+w].copy())[None,None])
            torch.testing.assert_close(packed,torch.from_numpy(data['packed']),atol=0,rtol=0)
            torch.testing.assert_close(torch.tensor(meta.white_balance),torch.from_numpy(data['wb'])[0],atol=0,rtol=0)
            torch.testing.assert_close(torch.tensor(meta.camera_to_srgb),torch.from_numpy(data['matrix'])[0],atol=0,rtol=0)
        matches.append({'observation':obs['id'],'context_xywh':box,'packed_WB_matrix_exact':True})
    results.append({'family':family,'local_cached_RAW':reference(source),'native_hw':list(raw.shape),
                    'metadata':asdict(meta),'matches':matches})
    del raw
write_json(root/'whole-scene-GFX-lineage.json',{'plan':reference(root/'plan.json'),'script':reference(__file__),
           'all_passed':True,'results':results,'RAW_decodes':2,
           'scope':'Only two already-cached noisy RAFs read, never original spinning-drive paths or independent ISO100/JPEG references. Exact actual native512/768 crop RAW measurements/WB/matrices match existing inputs. No resizing, new noise, neural/model/optimizer or GPU work.'})
print('Exact full-scene/crop lineage for all6 GFX contexts')
