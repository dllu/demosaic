"""Bind the local 12k training endpoint and original native render bytes."""

import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
REPO=Path.cwd()
OUT=REPO/"docs/images/expanded-scene-local12k-v1"
RESULT=REPO/"docs/results/expanded-scene-local12k-v1"
TRAIN=ROOT.parent/"expanded-scene-12000-v2"
PRIMARY=ROOT.parent/"expanded-scene-12000-primary-v1"


def portable(p):
    return reference(p) | {"path":str(p.relative_to(REPO))}


def copy(bound,name=None):
    path=checked(bound)
    output=OUT/(name or path.name)
    shutil.copyfile(path,output)
    binding=portable(output)
    assert binding["sha256"]==bound["sha256"]
    return binding


def main():
    native=read_json(ROOT/"result.json")
    trained=read_json(ROOT/"training-verified.json")
    assert native["checkpoint"]==trained["EMA_evaluation_checkpoint"]
    rendered=read_json(ROOT/"render/result.json")
    assert rendered["collections"]["none"]==native["native_collection"]
    end=read_json(checked(native["native_collection"]))
    assert end["weights"]=="EMA" and end["checkpoint"]==native["checkpoint"]
    assert end["counts"]=={"root":10,"encoder":10}
    plan=read_json(checked(native["plan"]))
    obs={o["id"]:o for o in plan["observations"]}
    OUT.mkdir(parents=True,exist_ok=True)
    RESULT.mkdir(parents=True,exist_ok=True)
    boards=[]
    for row in rendered["boards"]:
        o=obs[row["observation"]]
        if o["kind"]=="development" and row["case"]["crop_index"]!=0:
            continue
        boards.append(row | {"image":copy(row["image"]),"kind":o["kind"]})
    assert len(boards)==12
    ids=("development-0-shadows-crop0","development-1-iso12800-prior-crop0")
    triplets=[]
    for r in rendered["triplets"]:
        if r["id"] not in ids:
            continue
        triplets.append(r | {"image":copy(r["image"]),
                             "metadata":copy(r["metadata"])})
    assert len(triplets)==2
    files={
      "completed-training.json":checked(trained["training"]),
      "training-verified.json":ROOT/"training-verified.json",
      "training-plan.json":checked(trained["plan"]),
      "training-worker-exit.json":checked(trained["worker_exit"]),
      "matched-spatial-launch.json":TRAIN/"spatial-launch.json",
      "local-native-completed.json":ROOT/"result.json",
      "local-native-collection.json":checked(native["native_collection"]),
      "local-native-plan.json":checked(native["plan"]),
      "local-native-render.json":ROOT/"render/result.json",
      "canonical-queue-owner.json":PRIMARY/"owner.json",
      "src/observe.py":ROOT/"observe.py",
      "src/verify-training.py":ROOT/"verify-training.py",
      "src/render.py":ROOT/"render.py",
      "src/publish.py":Path(__file__),
      "src/train_scene_context.py":checked(read_json(checked(trained["training"]))["script"]),
      "src/review_scene_context_native.py":checked(plan["script"]),
      "src/queue-canonical.py":PRIMARY/"observe.py",
    }
    refs={n:reference(p)["sha256"] for n,p in files.items()}
    bundle=RESULT/"evidence.tar.xz"
    with tarfile.open(bundle,"x:xz",preset=4) as t:
        for n,p in files.items():
            t.add(p,arcname=n)
    with tarfile.open(bundle) as t:
        for n,s in refs.items():
            assert hashlib.file_digest(t.extractfile(n),"sha256").hexdigest()==s
    write_json(RESULT/"publication.json",{
      "training":trained,"native_collection":native,"native_CPU_inference_collection_seconds":end["seconds"],
      "triplets":triplets,"boards":boards,"development_condition_means":rendered["development_condition_means"],
      "archive":portable(bundle),"archive_member_sha256":refs,
      "scope":"Completed local-only endpoint. Fixed scoped native review versus V120 and matched 100k parent. Broad three-panel run is queued on completion of both measured training endpoints.",
    })


if __name__=="__main__":
    main()
