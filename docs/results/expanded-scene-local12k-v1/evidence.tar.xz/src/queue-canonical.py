"""Queue canonical three-panel evaluation for the expanded matched scene endpoints."""

import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

ROOT = Path(__file__).resolve().parent
TRAIN = ROOT.parent / "expanded-scene-12000-v2"
REFERENCE = ROOT.parent / "scene-primary-cpu-v1"
PHASES = ("preflight", "full")


def run_one(driver, plan, action):
    work = driver.parents[1]
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="2",
               PYTHONPATH=f"{work/'src'}:{work/'scripts'}")
    command = [sys.executable, str(driver), str(plan), action]
    with (ROOT / (action+".log")).open("xb") as stream:
        child = subprocess.Popen(command, env=env, stdout=stream, stderr=subprocess.STDOUT)
        write_json(ROOT/(action+"-launch.json"),{
            "pid":child.pid,"created":psutil.Process(child.pid).create_time(),
            "plan":reference(plan),"command":command,
        })
        code = child.wait()
    write_json(ROOT/(action+"-exit.json"),{"returncode":code})
    if code:
        raise RuntimeError(f"Expanded primary {action} exited with {code}")
    result_path = ROOT/action/"result.json"
    result = read_json(result_path)
    assert result["all_complete"] and result["cases"] == (3 if action=="preflight" else 3162)
    return reference(result_path)


def main():
    with exclusive_run(ROOT):
        owner = read_json(TRAIN/"launch.json")
        end = TRAIN/"matched-training.json"
        while not end.is_file():
            if not owner_live(owner):
                raise RuntimeError("Bound matched training ended without both endpoints")
            time.sleep(20)
        endpoints = read_json(end)
        assert endpoints["trained"] and endpoints["actual_distinct_scene_ids_per_arm"] == 24000
        template_path = REFERENCE/"full-plan.json"
        template = read_json(template_path)
        training_path = TRAIN/"plan.json"
        training = read_json(training_path)
        admitted = checked(template["canonical_inputs"])
        assert len(read_json(admitted)["records"])==3162
        models = {"V120":template["models"]["V120"],
                  "parent100k":{"kind":"parent","checkpoint":training["parent"],"step":100000}}
        for arm in ("none","spatial"):
            models[arm] = {"kind":"scene","checkpoint":endpoints["endpoints"][arm]["EMA"],"step":12000}
        for m in models.values():
            checked(m["checkpoint"])
        plan = template | {
            "root":str(ROOT),"models":models,"CPU_affinity":[6,7],"CPU_threads":2,
            "maximum_seconds":604800,
            "inputs":[v for v in template["inputs"] if v != template["preflight"]] +
                     [reference(p) for p in (end,training_path,template_path)] +
                     [m["checkpoint"] for m in models.values()],
            "scope":"Matched expanded 12k local-only/spatial EMA endpoints plus 100k parent and V120 on exactly the three fixed canonical panels. Uses the existing scene-field collector and DINO replay, contiguous CPU IEEE FP32. Earlier stage preflight results are not substitutions.",
        }
        del plan["preflight"]
        driver = checked(plan["driver"])
        prep = ROOT/"preflight-plan.json"
        write_json(prep,plan)
        preflight = run_one(driver,prep,"preflight")
        full = ROOT/"full-plan.json"
        write_json(full,plan | {"preflight":preflight,"inputs":[*plan["inputs"],preflight]})
        completed = run_one(driver,full,"full")
        write_json(ROOT/"result.json",{"training":reference(end),"models":models,
                                      "preflight":preflight,"full_primary":completed,
                                      "quality_review_complete":False})


if __name__=="__main__":
    main()
