"""Bind the completed local arm's realized schedule and EMA checkpoint before review."""

import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
RUN=ROOT.parent/"expanded-scene-12000-v2"
PLAN=RUN/"plan.json"

def main():
    torch.set_num_threads(2)
    plan=read_json(PLAN)
    p=RUN/"none/completed.json"
    end=read_json(p)
    status=RUN/"none-exit.json"
    assert read_json(status)=={"returncode":0}
    assert end["mode"]=="none" and end["steps"]==plan["steps"]==12000
    assert end["DINO_unchanged"] and end["plan"]==reference(PLAN)
    assert plan["crops_per_scene"]==4 and plan["scenes_per_step"]==2
    order_path=checked(plan["photo_epoch_order"])
    order=read_json(order_path)
    indices=np.load(checked(order["order"]|{"path":str(order_path.parent/order["order"]["path"])}))
    with checked(plan["train_manifest"]).open() as f:
        ids=[json.loads(line)["id"] for line in f]
    trace=checked(end["observations"])
    used=set()
    with trace.open() as f:
        for i,(line,index) in enumerate(zip(f,indices,strict=True)):
            record=json.loads(line)
            assert record["index"]==i and record["source_id"]==ids[index]
            assert len(record["boxes_xywh"])==4
            used.add(record["source_id"])
    assert len(indices)==len(used)==24_000
    endpoint=end["checkpoints"][-1]
    state=torch.load(checked(endpoint),map_location="cpu",weights_only=True)
    assert state["step"]==12000
    model,ema=[state[k] for k in ("model","ema")]
    assert model.keys()==ema.keys()
    assert all(torch.isfinite(t).all() for role in (model,ema) for t in role.values())
    assert any(not torch.equal(model[k],ema[k]) for k in model)
    write_json(ROOT/"training-verified.json",{
      "experiment":"expanded-scene-12000-v2","arm":"none","training":reference(p),"worker_exit":reference(status),
      "plan":reference(PLAN),"EMA_evaluation_checkpoint":endpoint,"parent_100k_EMA":plan["parent"],
      "weights_saved":["raw","EMA"],"weights_selected":"EMA","tensor_counts":{"raw":len(model),"EMA":len(ema)},
      "distinct_scenes":len(used),"native_examples":len(used)*plan["crops_per_scene"],"updates":end["steps"],
      "runtime_seconds":end["seconds"],"training_manifest":plan["train_manifest"],"photo_order":plan["photo_epoch_order"],
      "actual_observations":end["observations"],
      "scope":"Closed local-only training arm and audited full source order. Native and canonical evaluations have separate receipts.",
    })

if __name__=="__main__":
    main()
