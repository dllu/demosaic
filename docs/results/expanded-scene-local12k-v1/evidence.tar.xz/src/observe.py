"""Review the first completed scene arm while the paired arm trains."""

import os
import subprocess
import sys
import time
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

ROOT = Path(__file__).resolve().parent
MATCHED = ROOT.parent / "expanded-scene-12000-native-v1"
TRAIN = ROOT.parent / "expanded-scene-12000-v2"


def main():
    with exclusive_run(ROOT):
        parent_plan = MATCHED / "plan.json"
        plan = read_json(parent_plan)
        script = checked(plan["script"])
        expected = read_json(checked(plan["baseline_collection"]))["records"]
        owner = read_json(TRAIN / "launch.json")
        end = TRAIN / "none/completed.json"
        while not end.is_file():
            if not owner_live(owner):
                raise RuntimeError("Bound training controller exited without the local endpoint")
            time.sleep(12)
        completed = read_json(end)
        assert completed["plan"] == plan["training_plan"]
        assert completed["steps"] == 12000 and completed["DINO_unchanged"]
        bound_end = reference(end)
        endpoint = completed["checkpoints"][-1]
        checked(endpoint)
        path = ROOT / "plan.json"
        write_json(path, plan | {
            "root": str(ROOT),
            "sources": plan["sources"] | {str(parent_plan):reference(parent_plan)["sha256"],
                                           str(end):bound_end["sha256"], str(endpoint["path"]):endpoint["sha256"]},
            "scope": "Immediate local-only endpoint review on fixed stand-alone native observations. The separate matched review waits for the spatial endpoint.",
        })
        env = dict(os.environ, CUDA_VISIBLE_DEVICES="", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="2",
                   PYTHONPATH=f"{script.parents[1]}/src:{script.parent}")
        command = [sys.executable, str(script), str(path), "none"]
        subprocess.run(command, env=env, check=True)
        report = ROOT / "none/collection.json"
        collection = read_json(report)
        assert collection["checkpoint"]["sha256"] == endpoint["sha256"]
        for actual, control in zip(collection["records"], expected, strict=True):
            assert actual["input_fingerprints"] == control["input_fingerprints"] and actual["id"] == control["id"]
        write_json(ROOT / "result.json", {
            "source": reference(__file__), "plan":reference(path), "training":bound_end,
            "checkpoint":endpoint, "native_collection":reference(report),
            "matched_100k_control":reference(MATCHED / "parent/collection.json"),
            "V120":plan["baseline_collection"], "viewed":False,
        })


if __name__ == "__main__":
    main()
