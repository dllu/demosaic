"""Compare complex cross-fit corrections with the locked Fourier controls."""

import sys

import numpy as np
from scipy.optimize import brentq

from coherent_fourier import MODES, ROOT, cell_update, corrections, donor_axis, frequency_cells
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_staggered import (
    BAND, DENSE, FLAT, RESPONSE, WireFundamental, encode_banks, offgrid_summary,
    patch, replay, run, summarize_natural, values,
)
from demosaic.cfa import PATTERNS

PREVIOUS = ROOT.with_name("scene-staggered-phase-v1")


def field_updates(case, data, base):
    shot, read = (case["profile"][k] for k in ("shot", "read"))
    scene, colors = (data[k] for k in ("scene_packed", "colors"))
    box = case["box"]
    dense = patch.build_exterior(scene, colors, box, shot, read, band=BAND, dense_radius=DENSE)
    atlas = encode_banks(scene, colors, dense, shot, read)
    fields = {k: [] for k in MODES}
    for raw, parent in zip(data["packed"], base, strict=True):
        changes = corrections(raw, parent[1], colors, shot, read, box, atlas)
        for k, delta in changes.items():
            fields[k].append(
                replay.apply_delta(np.zeros_like(parent), delta, data["wb"], data["matrix"], 1)
            )
    return {k: np.stack(v) for k, v in fields.items()}


def wire(row):
    case = row["case"]
    data, base, _ = replay.read_inputs(case)
    corrections = field_updates(case, data, base)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        truth = {k: source[k] for k in ("target", "support")}
    metric = WireFundamental(data | truth, case["fixture"]["geometry"])
    parent = base.astype(np.float64)
    width = row["width"]["4800"]
    existing = metric(parent)
    assert existing == width["origin"]
    terms = dict(width["terms"])
    for name, field in corrections.items():
        plus, minus = metric(parent + field), metric(parent - field)
        terms[name] = {
            k: (
                [v, (plus[k] - minus[k]) / 2] if k in RESPONSE else
                [v**2, (plus[k]**2 - minus[k]**2) / 2, (plus[k]**2 + minus[k]**2) / 2 - v**2]
            )
            for k, v in existing.items()
        }
    return {"case": case, "width": {"4800": width | {"terms": terms}}}


def natural(row):
    case = row["case"]
    data, base, _ = replay.read_inputs(case)
    corrections = field_updates(case, data, base)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        truth = replay.transform(source["target"], data)
    parent = replay.transform(base, data)
    terms = dict(row["terms"])
    for name, field in corrections.items():
        adjustment = replay.transform(field, data)
        terms[name] = {
            k: replay.terms(v, adjustment[k], truth[k]) for k, v in parent.items()
        }
    return row | {"terms": terms}


def invariants():
    # Dense complex rank-one power is invariant to carrier phase in each donor.
    rng = np.random.default_rng(202611192235)
    frequency = np.array([0.7 + 0.2j, -0.2j, 0.5 - 0.3j])
    mode = frequency / np.linalg.norm(frequency)
    theta = rng.uniform(-np.pi, np.pi, (1, 32, 1, 1))
    donors = np.broadcast_to(4 * np.exp(1j * theta) * mode, (1, 32, 2, 3)).copy()
    weights = np.full((1, 32), 1 / 32)
    power, axis = donor_axis(donors, weights)
    np.testing.assert_allclose(np.abs(axis @ mode.conj()), 1, rtol=0, atol=1e-14)
    np.testing.assert_allclose(power, 8, rtol=0, atol=1e-14)
    for pattern in PATTERNS.values():
        groups, _, maps = frequency_cells(tuple(pattern), BAND)
        assert np.array_equal(np.sort(np.concatenate(groups)), np.arange(len(maps[0])))
        assert all(len(set(g)) == len(g) for g in groups)

    observed = np.broadcast_to(0.04 * mode, (1, 2, 3)).copy()
    parent = 0.25 * observed
    maps = rng.normal(size=(2, 3, 24)) + 1j * rng.normal(size=(2, 3, 24))
    raw, magnitude = cell_update(donors, weights, observed, parent, observed[:, 0],
                                 np.full(1, 1e-4), maps)
    assert np.linalg.norm(raw) > 0 and np.linalg.norm(magnitude) > 0
    for original, swap in zip((raw, magnitude), cell_update(
        donors[:, ::-1], weights[:, ::-1], observed, parent, observed[:, 0],
        np.full(1, 1e-4), maps
    ), strict=True):
        np.testing.assert_allclose(swap, original, rtol=0, atol=1e-14)
    random_phase = np.exp(1j * rng.uniform(-np.pi, np.pi, (1, 32, 1, 1)))
    for original, rotated in zip((raw, magnitude), cell_update(
        donors * random_phase, weights, observed, parent, observed[:, 0], np.full(1, 1e-4), maps
    ), strict=True):
        np.testing.assert_allclose(rotated, original, rtol=0, atol=1e-14)
    opposed = donors.copy()
    # A wholly unrelated selected bank (orthogonal complex direction) gives no update.
    orthogonal = np.array([-mode[1].conj(), mode[0].conj(), 0])
    assert abs(orthogonal @ mode.conj()) < 1e-14
    opposed[:, 1::2, :, :] = np.exp(1j * theta[:, 1::2]) * orthogonal
    no_update = cell_update(opposed, weights, observed, parent, observed[:, 0], np.full(1, 1e-4), maps)
    np.testing.assert_array_equal(no_update, np.zeros((2, 1, 3)))
    return {
        "four_bayer_layouts": True,
        "phase_rotation_invariance": True,
        "disjoint_fold_exchange": True,
        "orthogonal_donor_modes_suppressed": True,
    }


def calibration():
    source = reference(PREVIOUS / "calibration.json")
    original = read_json(checked(source))
    rows, elapsed = run(original["calibration"], wire)
    group = [r["width"]["4800"] for r in rows]
    baseline = values(group, "origin", FLAT, 0)
    strengths = dict(original["strengths"]["4800"])
    for mode in MODES:
        def quiet(gain):
            return float((values(group, mode, FLAT, gain) - baseline).mean())
        cap = 1.5
        gain = brentq(lambda g: quiet(g) - 0.10, 0, cap) if quiet(cap) > 0.10 else cap
        strengths[mode] = {"gain": gain, "flat_DN16": quiet(gain)}
    assert len(rows) == 16
    write_json(ROOT / "calibration.json", {
        "driver": reference(__file__), "operator": reference(ROOT / "coherent_fourier.py"),
        "virgin_controls": source, "calibration": rows, "strengths": strengths,
        "seconds": elapsed, "invariants": invariants(),
    })
    print("locked", strengths, flush=True)


def score(panel):
    calibration = reference(ROOT / "calibration.json")
    strengths = read_json(checked(calibration))["strengths"]
    gains = {k: r["gain"] for k, r in strengths.items()}
    if panel == "natural":
        original = reference(PREVIOUS / "retained.json")
        source = read_json(checked(original))["natural"]
        rows, elapsed = run(source, natural)
        summary = summarize_natural(rows, strengths)
        assert len(rows) == 32
    else:
        assert panel in ("prior", "fresh")
        original = reference(PREVIOUS / f"offgrid-{panel}.json")
        source = read_json(checked(original))["rows"]
        rows, elapsed = run(source, wire)
        summary = offgrid_summary(rows, gains)
        assert len(rows) == 24
    write_json(ROOT / f"{panel}.json", {
        "driver": reference(__file__), "lock": calibration, "source": original,
        "seconds": elapsed, "summary": summary, "rows": rows,
    })


if __name__ == "__main__":
    if sys.argv[1] == "calibration":
        calibration()
    else:
        score(sys.argv[1])
