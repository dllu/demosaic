"""Cross-fit contributions of neighboring quadrature pairs on disjoint donor windows."""

from functools import lru_cache
from pathlib import Path
import sys

import numpy as np

from demosaic import scene_patch_covariance as patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name("scene-staggered-phase-v1")))
from staggered_phase import SHIFTS, amplitudes, blend, encode_banks, staggered_grid

MODES = ("coherent_phase", "coherent_strength")


def complex_to_pairs(values):
    return np.stack((values.real, values.imag), axis=-1)


@lru_cache(maxsize=12)
def frequency_cells(colors, band):
    """Group nearby shifted pairs in a consistent orientation and preserve their sensor maps."""
    grids = [staggered_grid(colors, band, shift) for shift in SHIFTS]
    frequencies = np.concatenate([grid.frequency for grid in grids])
    nearest = np.floor(frequencies * band.size + 0.5).astype(int)
    flipped = (nearest[:, 0] == 0) & (nearest[:, 1] < 0)
    nearest[flipped] *= -1
    signs = np.where(flipped, -1, 1)
    projections = np.concatenate([g.basis.projection for g in grids], axis=1)
    projections = projections.reshape(2, len(frequencies), 2, -1)
    projections = projections[:, :, 0] + 1j * signs[None, :, None] * projections[:, :, 1]
    groups = [
        np.flatnonzero(np.all(nearest == value, axis=1)) for value in np.unique(nearest, axis=0)
    ]
    return groups, signs, projections


def normalized_support(coefficients, reference, sigma, cov):
    """Apply the existing two-green ramp with per-window quadrature covariance."""
    norm = np.abs(reference)
    direction = np.divide(reference, norm, out=np.zeros_like(reference), where=norm > 0)
    vector = complex_to_pairs(direction)
    signed = (coefficients * direction[:, None].conj()).real
    variance = np.einsum("qi,qgij,qj->qg", vector, cov, vector)
    scale = sigma[:, None] * np.sqrt(np.maximum(variance, 1e-12))
    limit = np.clip((np.min(signed / scale, axis=1) - 0.5) / 2, 0, 1)
    return direction, limit


def donor_axis(values, weights):
    """Choose a direction from the discovery half alone using Hermitian cross power."""
    first, second = values.transpose(2, 0, 1, 3)
    cross = np.einsum("qn,qni,qnj->qij", weights, first, second.conj())
    moment = (cross + cross.conj().swapaxes(-1, -2)) / 4
    eig, basis = np.linalg.eigh(moment)
    return eig[:, -1], basis[:, :, -1]


def cell_update(donors, weights, observed, predicted, radial, sigma, mapping):
    """Use the held donor half to measure the discovery mode and cap its query update."""
    phase = np.zeros_like(observed[:, 0])
    strength = np.zeros_like(phase)
    match = np.minimum(weights.sum(axis=1), 1)
    for start in (0, 1):
        choose, held = slice(start, None, 2), slice(1 - start, None, 2)
        p, _, eligible = patch.folded_weights(weights[:, choose])
        estimate, axis = donor_axis(donors[:, choose], p)
        held_coeff = np.einsum("qngi,qi->qng", donors[:, held], axis.conj())
        product = (held_coeff[:, :, 0] * held_coeff[:, :, 1].conj()).real[:, :, None] / 2

        # Multiple shifted fits use the same sensor sites. Keeping the full
        # projection here includes cross-grid error covariance in the noise floor.
        projector = np.einsum("giw,qi->qgw", mapping, axis.conj())
        blocks = np.stack((projector.real, projector.imag), axis=2)
        cov = blocks @ blocks.swapaxes(-1, -2)
        independent_noise = np.sum(cov[:, 0] * cov[:, 1], axis=(-2, -1))[:, None] / 16
        confirmed = patch.confirmed_power(product, weights[:, held], independent_noise)[:, 0]
        power = np.maximum(np.minimum(estimate, confirmed), 0) * match * eligible[:, 0]
        gain = 0.5 * power / (1 + power)

        measurement = np.einsum("qgi,qi->qg", observed, axis.conj())
        parent = np.einsum("qgi,qi->qg", predicted, axis.conj())
        direction, support = normalized_support(measurement, measurement.mean(axis=1), sigma, cov)
        deficit = ((measurement - parent) * direction[:, None].conj()).real.mean(axis=1)
        phase += (gain * support * np.maximum(deficit, 0) * direction)[:, None] * axis

        # Keep each original pair's own measured phase and sign in this arm.
        share = np.abs(axis) ** 2
        strength += (gain * support)[:, None] * (share / share.max(axis=-1, keepdims=True)) * radial
    return phase, strength


def corrections(raw, parent, colors, shot, read, box, encoded):
    output = {mode: np.zeros_like(parent) for mode in MODES}
    if encoded is None:
        return output
    all_grids, bank = encoded
    size = bank.band.size
    if min(parent.shape) < size:
        return output

    grids = all_grids[1:]
    groups, signs, maps = frequency_cells(tuple(colors), bank.band)
    y, x = np.meshgrid(
        *(np.arange(0, n - size + 1, size // 2) for n in parent.shape), indexing="ij"
    )
    coords = np.column_stack((y.ravel(), x.ravel()))
    offset = np.arange(size)
    ys = coords[:, 0, None, None] + offset[:, None]
    xs = coords[:, 1, None, None] + offset[None, :]
    raw_windows = patch.sample_windows(raw, coords, size)
    base_windows = parent[ys, xs]
    feature, _, sigma, valid = patch.encode(raw_windows, grids[0].basis, shot, read)
    saved, weights = patch.choose_exterior(
        feature, coords + np.asarray(box)[[1, 0]], bank, ranked=True
    )
    saved = saved[..., len(all_grids[0].frequency):, :]
    mean_raw, mean_base, local = [], [], []
    for grid in grids:
        basis = grid.basis
        project = basis.projection
        green = raw_windows[:, basis.green].reshape(len(coords), 2, -1)
        sensor_base = np.stack(
            [base_windows[:, g // 2 :: 2, g % 2 :: 2] for g in basis.green], axis=1
        ).reshape(len(coords), 2, -1)
        mean_raw.append(np.einsum("gif,qgf->qgi", project, green).reshape(len(coords), 2, -1, 2))
        mean_base.append(np.einsum("gif,qgf->qgi", project, sensor_base).reshape(len(coords), 2, -1, 2))
        local.append(amplitudes(grid, raw_windows, base_windows, shot, read)[1])

    def canonical(pairs):
        return pairs[..., 0] + 1j * signs * pairs[..., 1]

    donors = canonical(saved)
    observed = canonical(np.concatenate(mean_raw, axis=2))
    predicted = canonical(np.concatenate(mean_base, axis=2))
    radial = canonical(np.concatenate(local, axis=1))
    updates = {mode: np.zeros_like(radial) for mode in MODES}
    for indexes in groups:
        phase, strength = cell_update(
            donors[..., indexes], weights, observed[..., indexes], predicted[..., indexes],
            radial[..., indexes], sigma, maps[:, indexes],
        )
        updates["coherent_phase"][:, indexes] = phase
        updates["coherent_strength"][:, indexes] = strength

    taper = np.sin((offset + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(coords), size, size)))
    images = np.concatenate([grid.basis.image for grid in grids])
    for mode, update in updates.items():
        pairs = np.stack((update.real, update.imag * signs), axis=-1)
        pairs *= valid[:, None, None] / len(grids)
        output[mode] = blend(pairs, images, parent, ys, xs, window) / np.maximum(1, norm)
    return output
