"""Render the matched-increment policies on exact and standing native crops."""

import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_neighbors import BAND, COHERENT, DENSE, MODES, ROOT, corrections, encode_banks
from score_neighbors import fields, patch, replay, values
from atlas_probe import exact_query, load_standing, packed_scene, pixels, render
from render_wide import native_board, native_png, peak_fit

CONTINUING = "gap_continuing_strong_RMS_DN16"
FALSE = "fundamental_false_RMS_DN16"
LABELS = {
    "coherent_strength": "Joint gate",
    "tangent": "Along-wire phase",
    "normal": "Across-wire phase",
    "quadrature": "Wrong phase",
    "phase_blind": "Magnitude only",
}
CANDIDATE = "normal"
OPERATING_POINT = "natural_increment"


def standing(calibration, gains):
    start = time.monotonic()
    binding = reference(COHERENT / "native/standing/result.json")
    before = {r["id"]: r for r in read_json(checked(binding))["rows"]}
    _, baseline, lookup = load_standing()
    dest = ROOT / "native/standing"
    dest.mkdir(parents=True)
    result = []
    for category in ("main", "mesh"):
        group = [r for r in baseline["rows"] if r["id"].startswith(category)]
        source, scene, colors = packed_scene(group)
        for row in group:
            prior = before[row["id"]]
            assert source == prior["raw"] and row["query"] == prior["absolute_query"]
            raw, parent, roi, wb, matrix = exact_query(row, lookup, scene, colors)
            x, y, w, h = roi
            with np.load(checked(prior["parent_arrays"]), allow_pickle=False) as saved:
                np.testing.assert_array_equal(raw, saved["raw"])
                np.testing.assert_array_equal(parent, saved["parent"])
                np.testing.assert_array_equal(colors, saved["colors"])
                np.testing.assert_array_equal(wb, saved["wb"])
                np.testing.assert_array_equal(matrix, saved["matrix"])
            shot, read = (row["noise"][k] for k in ("shot", "read"))
            donors = patch.build_exterior(
                scene, colors, row["query"], shot, read, band=BAND, dense_radius=DENSE
            )
            atlas = encode_banks(scene, colors, donors, shot, read)
            new = corrections(raw, parent[1], colors, shot, read, row["query"], atlas)
            updates = {
                k: replay.apply_delta(np.zeros_like(parent), v, wb, matrix, gains[k])
                for k, v in new.items()
            }
            estimates = {k: parent + updates[k] for k in MODES}
            window = np.s_[..., y:y+h, x:x+w]
            dose = {k: float(np.sqrt(np.mean(v[window].astype(float)**2)) * 65535)
                    for k, v in updates.items()}
            projection = matched_projection = {}
            if category == "mesh":
                anchor = dose["coherent_strength"]
                equal = {k: parent + (anchor / dose[k]) * updates[k] if dose[k] > 0 else parent
                         for k in MODES}
                same_raw = peak_fit(raw, parent, estimates, colors, roi)
                matched = peak_fit(raw, parent, equal, colors, roi)
                base = np.asarray(same_raw["parent"]["percent_of_observed"])
                projection, matched_projection = (
                    {k: (np.asarray(records[k]["percent_of_observed"]) - base).tolist()
                     for k in MODES} for records in (same_raw, matched)
                )
            views = []
            for d in prior["displays"]:
                existing = pixels(d["board"])
                exposure = d["exposure"]
                np.testing.assert_array_equal(
                    render(parent, wb, matrix, roi, exposure), existing["Corpus 100k"]
                )
                np.testing.assert_array_equal(
                    render(estimates["coherent_strength"], wb, matrix, roi, exposure),
                    existing["Joint gate"],
                )
                panels = [(k, existing[k]) for k in (
                    "Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Four-grid mean",
                )]
                panels.extend((label, render(estimates[k], wb, matrix, roi, exposure))
                              for k, label in LABELS.items())
                panels.extend((k, existing[k]) for k in (
                    "ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG"
                ) if k in existing)
                view = native_png(dest / f"{row['id']}-x{exposure:g}.png", panels)
                views.append({"exposure": exposure, "board": view})
            result.append({
                "id": row["id"], "raw": prior["raw"], "global_roi": prior["global_roi"],
                "absolute_query": prior["absolute_query"], "noise": prior["noise"],
                "parent_arrays": prior["parent_arrays"], "reference": prior["reference"],
                "rgb_RMS_DN16": dose, "projection_points": projection,
                "matched_joint_projection_points": matched_projection, "displays": views,
            })
    write_json(dest / "result.json", {
        "driver": reference(__file__), "baseline": binding, "calibration": calibration,
        "policy": OPERATING_POINT, "rows": result, "seconds": time.monotonic() - start,
    })


def exact(calibration, gains):
    binding = reference(ROOT / "transfer.json")
    receipt = read_json(checked(binding))
    family = [v for v in receipt["rows"] if v["width"]["4800"]["gap_pixels"]]

    def change(row, metric):
        group = [row["width"]["4800"]]
        return float(values(group, CANDIDATE, metric, gains[CANDIDATE])[0]
                     - values(group, "coherent_strength", metric, gains["coherent_strength"])[0])

    best = min(family, key=lambda v: change(v, CONTINUING))
    adverse = max((v for v in family if v is not best), key=lambda v: change(v, FALSE))
    dest = ROOT / "native/exact"
    dest.mkdir(parents=True)
    found = []
    for row, label in ((best, "largest continuing-wire improvement"),
                       (adverse, "largest false-gap increase among remaining cases")):
        case = row["case"]
        data, parent, v120 = replay.read_inputs(case)
        updates = fields(case, data, parent)
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            truth = archive["target"]
        camera = {k: data[k][None] for k in ("colors", "wb", "matrix")}
        labels = ["Noisy Malvar", "V120 EMA", "Corpus 100k", *LABELS.values(), "Exact GT"]
        for i, role in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(camera | {"packed": data["packed"][i:i+1]})[0]
            estimates = [noisy, v120[i], parent[i]]
            estimates.extend(parent[i] + gains[k] * updates[k][i] for k in MODES)
            estimates.append(truth[i])
            found.append(native_board(
                dest, f"transfer-{case['fixture']['index']:02}-{role}", estimates, camera,
                {"case": case, "role": role, "selection": label, "gains": gains,
                 "differences_vs_joint_gate": {k: change(row, k) for k in (CONTINUING, FALSE)}},
                labels=labels, triplet_indices=(0, labels.index(LABELS[CANDIDATE]), len(labels)-1),
                exposure=2, roi=(48, 48, 160, 160),
            ))
    write_json(dest / "result.json", {
        "driver": reference(__file__), "comparison": binding, "calibration": calibration,
        "policy": OPERATING_POINT, "rows": found,
    })


if __name__ == "__main__":
    torch.set_num_threads(2)
    calibration = reference(ROOT / "natural-lock.json")
    gains = read_json(checked(calibration))["strengths"][OPERATING_POINT]
    assert sys.argv[1] in ("standing", "exact")
    (standing if sys.argv[1] == "standing" else exact)(calibration, gains)
