"""Set a second operating point on independent natural-photo comparisons."""

import numpy as np
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_neighbors import MODES, ROOT, fields, replay, run, summarize

BASE = "coherent_strength"
CROSSFIT = ROOT.with_name("scene-patch-crossfit-v1")


def measure(row):
    case = row["case"]
    data, parent, _ = replay.read_inputs(case)
    updates = fields(case, data, parent)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        exact = replay.transform(source["target"], data)
    base = replay.transform(parent, data)
    terms = {"parent": row["terms"]["parent"]}
    for name, delta in updates.items():
        lifted = replay.transform(delta, data)
        terms[name] = {band: replay.terms(arr, lifted[band], exact[band]) for band, arr in base.items()}
    for name, arr in terms["parent"].items():
        expected = replay.terms(base[name], np.zeros_like(base[name]), exact[name])
        for k, v in arr.items():
            np.testing.assert_allclose(v, expected[k], atol=1e-10, rtol=0)
    return {"case": case, "terms": terms}


def natural_summary(rows, scales):
    rng = np.random.default_rng(202611192159)
    index = np.vstack((np.arange(len(rows)), rng.integers(0, len(rows), (8000, len(rows)))))
    result = {}
    for band in ("fine", "lower"):
        for metric in ("present", "increment", "flat", "response"):
            estimates = {
                k: replay.estimate(replay.arrays(rows, k, band, metric), metric, g, index)
                for k, g in scales.items()
            }
            summary = {}
            for key, val in estimates.items():
                rec = {"value": float(val[0])}
                for base in (BASE, "parent"):
                    d = val - estimates[base]
                    rec[base] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
                summary[key] = rec
            result.setdefault(band, {})[metric] = summary
    return result


def main():
    orig = reference(ROOT / "calibration.json")
    current = read_json(checked(orig))
    current_gains = {k: v["gain"] for k, v in current["strengths"].items()}
    binding = reference(CROSSFIT / "calibration.json")
    calibration = read_json(checked(binding))["rows"]
    eval_binding = reference(CROSSFIT / "evaluation.json")
    existing = read_json(checked(eval_binding))["cases"]

    def select(rows, subset):
        return [r for r in rows if r["case"]["profile"]["name"] == "iso6400"
                and r["case"]["partition"] == subset and r["case"]["draw"] == "independent"]

    cal = select(calibration, "calibration")
    hold = select(existing, "held_out")
    original = reference(ROOT / "natural.json")
    fresh = read_json(checked(original))["rows"]
    assert len(cal) == len(hold) == len(fresh) == 32
    for key in ("id", "cache_sha256"):
        identities = [{r["case"]["source"][key] for r in group} for group in (cal, hold, fresh)]
        assert all(len(group) == 32 for group in identities)
        assert len(set.union(*identities)) == 96
    cal_rows, cal_time = run(cal, measure)

    def rms(method, field, g):
        ind = np.arange(len(cal_rows))[None, :]
        terms = replay.arrays(cal_rows, method, "fine", field)
        return float(replay.estimate(terms, field, g, ind)[0])

    def match(field):
        target = rms(BASE, field, current_gains[BASE])
        return {"parent": 0, **{
            k: brentq(lambda g: rms(k, field, g) - target, 0, 1.5) for k in MODES
        }}

    scales = {
        "wire_flat": {"parent": 0, **{k: current_gains[k] for k in MODES}},
        "natural_flat": match("flat"),
        "natural_increment": match("increment"),
    }
    # Freeze all gains before reading holdout pixels.
    frozen = ROOT / "natural-lock.json"
    write_json(frozen, {
        "driver": reference(__file__), "calibration_source": binding, "previous_calibration": orig,
        "strengths": scales, "seconds": cal_time, "rows": cal_rows,
    })
    other, held_time = run(hold, measure)
    comparisons = {}
    for label, strength in scales.items():
        wire = {k: reference(ROOT / f"{k}.json") for k in ("prior", "fresh", "transfer")}
        comparisons[label] = {
            "retained_natural": natural_summary(fresh, strength),
            "other_natural": natural_summary(other, strength),
            "wire": {name: summarize(read_json(checked(ref))["rows"], current_gains | strength)
                     for name, ref in wire.items()},
        }
    write_json(ROOT / "natural-doses.json", {
        "driver": reference(__file__), "calibration": reference(frozen),
        "other_natural_source": eval_binding, "retained_natural": original,
        "wire": wire, "rows": other, "seconds": held_time, "comparisons": comparisons,
    })


if __name__ == "__main__":
    main()
