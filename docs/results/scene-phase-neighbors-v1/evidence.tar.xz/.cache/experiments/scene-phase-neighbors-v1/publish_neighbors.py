"""Publish the calibrated neighboring phase replays and native GFX plates."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_neighbors import COHERENT, LABELS, OPERATING_POINT, ROOT, pixels

REPO = ROOT.parents[2]
IMAGES = REPO / "docs/images" / ROOT.name
OUTPUT = REPO / "docs/results" / ROOT.name
EXTERNAL = Path("/mnt/external/demosaic")
STAGES = {
    "wire_lock": "calibration.json", "natural_lock": "natural-lock.json",
    "prior": "prior.json", "fresh": "fresh.json", "transfer": "transfer.json",
    "natural_A": "natural.json", "doses": "natural-doses.json", "views": "views.json",
    "standing": "native/standing/result.json", "exact": "native/exact/result.json",
}


def copy(binding, folder=""):
    path = checked(binding)
    target = IMAGES / folder / path.name
    shutil.copyfile(path, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return binding | {"path": str(target.relative_to(IMAGES))}


def board(record, folder):
    values = pixels(record)
    assert len(values) == len(record["panels"])
    assert all(p.shape == (160, 160, 3) for p in values.values())
    return record | {"image": copy(record["image"], folder)}


def main():
    receipts = {k: reference(ROOT / v) for k, v in STAGES.items()}
    data = {k: read_json(checked(r)) for k, r in receipts.items()}
    wire_lock, natural_lock, prior, fresh, transfer, natural, doses, views, standing, exact = data.values()
    assert natural_lock["previous_calibration"] == receipts["wire_lock"]
    assert all(panel["calibration"] == receipts["wire_lock"]
               for panel in (prior, fresh, transfer, natural))
    assert doses["calibration"] == standing["calibration"] == exact["calibration"] == receipts["natural_lock"]
    assert doses["retained_natural"] == receipts["natural_A"]
    assert exact["comparison"] == receipts["transfer"]
    assert standing["policy"] == exact["policy"] == OPERATING_POINT
    assert views["numerics"] == receipts["doses"]
    assert views["receipts"] == {k: receipts[k] for k in ("standing", "exact")}
    assert len(wire_lock["calibration"]) == 16 and all(wire_lock["invariants"].values())
    assert len(prior["rows"]) == len(fresh["rows"]) == 24 and len(transfer["rows"]) == 32
    groups = [natural_lock["rows"], natural["rows"], doses["rows"]]
    for key in ("id", "cache_sha256"):
        ids = {r["case"]["source"][key] for group in groups for r in group}
        assert all(len(group) == 32 for group in groups) and len(ids) == 96
    for source in views["sheets"].values():
        checked(source)

    (IMAGES / "standing").mkdir(parents=True)
    (IMAGES / "exact").mkdir()
    OUTPUT.mkdir(parents=True)
    review = []
    for row in standing["rows"]:
        mesh = row["id"].startswith("mesh")
        assert {d["exposure"] for d in row["displays"]} == ({4, 16} if mesh else {4})
        displays = []
        for display in row["displays"]:
            expected = {"Noisy (Malvar)", "Corpus 100k", "V120 EMA",
                        *LABELS.values(), "ISO100 AHD reference"}
            if mesh:
                expected |= {"ISO6400 camera JPEG", "ISO100 camera JPEG"}
            assert expected <= pixels(display["board"]).keys()
            displays.append(display | {"board": board(display["board"], "standing")})
        review.append(row | {"displays": displays})
    assert len(review) == 8 and sum(len(r["displays"]) for r in review) == 12

    triplets = []
    for row in exact["rows"]:
        original, triplet = (pixels(row[k]) for k in ("board", "triplet"))
        assert list(triplet) == ["Noisy Malvar", "Across-wire phase", "Exact GT"]
        for key, crop in triplet.items():
            np.testing.assert_array_equal(crop, original[key])
        triplets.append(row | {k: board(row[k], "exact") for k in ("board", "triplet")})
    assert len(triplets) == 4
    prior_transfer = read_json(checked(transfer["previous"]))
    prior_capture = read_json(checked(prior_transfer["parent_replay"]))
    manifest = IMAGES / "manifest.json"
    write_json(manifest, {
        "weights": prior_transfer["weights"], "weight_type": "EMA",
        "native_size": [160, 160], "displayed_policy": OPERATING_POINT,
        "standing": review, "exact": triplets, "plot": copy(views["plot"]),
        "review": {
            "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "sheets": receipts["views"],
            "standing": "Both sets viewed with independent ISO100 AHD and both cab JPEGs. "
                        "Sky stays smooth, coarse links stay coherent and fine cab junctions stay incomplete.",
            "exact": "Two off-grid backgrounds and their exact flat controls viewed at common exposure.",
        },
    })

    archive = OUTPUT / "evidence.tar.xz"
    refs = [*receipts.values(), *(v["driver"] for v in data.values()), wire_lock["operator"],
            wire_lock["previous_calibration"], natural_lock["calibration_source"],
            doses["other_natural_source"], standing["baseline"],
            prior["previous"], fresh["previous"], transfer["previous"], natural["previous"],
            prior_transfer["parent_replay"], prior_capture["plan"], reference(manifest),
            reference(COHERENT / "coherent_fourier.py"), reference(COHERENT / "score_coherence.py"),
            reference(REPO / "configs/gfx-green-mesh-20231231.json"),
            reference(REPO / "configs/gfx-qualitative-20231231.json"), reference(__file__)]
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for ref in {r["path"]: r for r in refs}.values():
            path = checked(ref)
            name = (path.relative_to(REPO) if path.is_relative_to(REPO)
                    else Path("external") / path.relative_to(EXTERNAL)).as_posix()
            tar.add(path, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(p).read()).hexdigest() == h for p, h in members.items())
    write_json(OUTPUT / "publication.json", {
        "scope": "Inference-only phase validation replay across three off-grid and two natural-photo "
                 "panels and both standing GFX captures with the frozen Corpus 100k EMA.",
        "weights": prior_transfer["weights"], "weight_type": "EMA",
        "strengths": natural_lock["strengths"], "comparisons": doses["comparisons"],
        "seconds": {k: data[k]["seconds"] for k in ("wire_lock", "natural_lock", "prior", "fresh",
                                                  "transfer", "natural_A", "doses", "standing")},
        "receipts": receipts, "manifest": reference(manifest), "archive": reference(archive),
        "members": members,
    })


if __name__ == "__main__":
    main()
