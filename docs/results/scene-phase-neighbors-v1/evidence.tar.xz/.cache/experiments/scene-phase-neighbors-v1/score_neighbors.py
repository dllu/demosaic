"""Measure nearby phase confirmation on frozen wire and natural-photo replays."""

import sys

import numpy as np
from scipy.optimize import brentq

from phase_neighbors import COHERENT, MODES, ROOT, corrections, lag_pairs, neighbor_scores
from score_coherence import BAND, DENSE, FLAT, RESPONSE, WireFundamental, encode_banks
from score_coherence import patch, replay, run, summarize_natural, values
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

WIRE_REF = "fundamental_response"
METRICS = (WIRE_REF, "fundamental_intact_RMS_DN16", "gap_continuing_strong_RMS_DN16",
           "fundamental_false_RMS_DN16", FLAT)
VARIANTS = MODES[1:]
COMPARISON = ("origin", "v120", "dense", "staggered_mean", *MODES)


def fields(case, raw, parent):
    shot, read = (case["profile"][k] for k in ("shot", "read"))
    colors, box = raw["colors"], case["box"]
    dense = patch.build_exterior(raw["scene_packed"], colors, box, shot, read,
                                 band=BAND, dense_radius=DENSE)
    atlas = encode_banks(raw["scene_packed"], colors, dense, shot, read)
    updates = {key: [] for key in MODES}
    for packed, rgb in zip(raw["packed"], parent, strict=True):
        every = corrections(packed, rgb[1], colors, shot, read, box, atlas)
        for key, value in every.items():
            updates[key].append(replay.apply_delta(
                np.zeros_like(rgb), value, raw["wb"], raw["matrix"], 1.0
            ))
    return {k: np.stack(v) for k, v in updates.items()}


def wire(row):
    case = row["case"]
    group = row["width"]["4800"]
    data, base, _ = replay.read_inputs(case)
    changes = fields(case, data, base)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        exact = {k: source[k] for k in ("target", "support")}
    metric = WireFundamental(data | exact, case["fixture"]["geometry"])
    parent = base.astype(np.float64)
    initial = metric(parent)
    assert initial == group["origin"]
    terms = dict(group["terms"])
    for name, delta in changes.items():
        plus, minus = metric(parent + delta), metric(parent - delta)
        terms[name] = {
            k: (
                [v, (plus[k] - minus[k]) / 2] if k in RESPONSE else
                [v**2, (plus[k]**2 - minus[k]**2) / 2, (plus[k]**2 + minus[k]**2) / 2 - v**2]
            )
            for k, v in initial.items()
        }
    for k, v in terms["coherent_strength"].items():
        np.testing.assert_allclose(v, group["terms"]["coherent_strength"][k], rtol=0, atol=1e-10)
    return {"case": case, "width": {"4800": group | {"terms": terms}}}


def natural(row):
    case = row["case"]
    data, parent, _ = replay.read_inputs(case)
    changes = fields(case, data, parent)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        truth = replay.transform(source["target"], data)
    transformed = replay.transform(parent, data)
    terms = dict(row["terms"])
    for key, dz in changes.items():
        adj = replay.transform(dz, data)
        terms[key] = {k: replay.terms(v, adj[k], truth[k]) for k, v in transformed.items()}
    for band, vals in terms["coherent_strength"].items():
        for key, vals_ in vals.items():
            np.testing.assert_allclose(vals_, row["terms"]["coherent_strength"][band][key],
                                       rtol=0, atol=1e-10)
    return row | {"terms": terms}


def invariants():
    size = 15
    center_yx = np.indices((size, size)).reshape(2, -1).T
    checks = []
    for colors in PATTERNS.values():
        _, _, mapping, bank = lag_pairs(tuple(colors), BAND, (size, size))
        for neighbors, eligible, transport in bank:
            pos = center_yx[neighbors]
            disjoint = np.max(np.abs(pos - center_yx[None, :, None]), axis=-1) >= 2
            assert disjoint[eligible].all()
            spacing = np.max(np.abs(pos[0] - pos[1]), axis=-1) >= 4
            assert spacing[eligible.all(axis=0)].all()
            count = mapping.shape[1]
            mid = (size**2 - 1) // 2
            phase = np.exp(1j * np.linspace(-2.1, 2.3, count))
            observed = np.zeros((size**2, 2, count), dtype=np.complex128)
            observed[mid] = phase
            # Use a synthetic phase advance to check sign in either quadrature.
            custom = transport * np.exp(1j * 0.48)
            bins = np.arange(count)
            observed[neighbors[:, mid], :, bins] = (phase[None, :, None] * custom.conj()[..., None])
            parallel, across = neighbor_scores(observed, np.ones(len(observed)), mapping,
                                               neighbors, eligible, custom)
            assert (parallel[mid] > 0).all()
            np.testing.assert_allclose(across[mid], 0, atol=1e-14, rtol=0)
            checks.append(float(np.min(parallel[mid])))
    return {
        "all_four_layouts": True, "center_and_adjacent_samples_disjoint": True,
        "positive_rotated_carrier_score": min(checks), "wrong_quadrature_rejected": True,
    }


def lock():
    reference_calibration = reference(COHERENT / "calibration.json")
    prior = read_json(checked(reference_calibration))
    rows, elapsed = run(prior["calibration"], wire)
    groups = [r["width"]["4800"] for r in rows]
    baseline = values(groups, "origin", FLAT, 0)
    gains = dict(prior["strengths"])
    for name in VARIANTS:
        def risk(scale):
            return float((values(groups, name, FLAT, scale) - baseline).mean())
        gain = brentq(lambda s: risk(s) - 0.10, 0, 1.5) if risk(1.5) > 0.1 else 1.5
        gains[name] = {"gain": gain, "flat_DN16": risk(gain)}
    proof = {"driver": reference(__file__), "operator": reference(ROOT / "phase_neighbors.py"),
             "previous_calibration": reference_calibration, "strengths": gains,
             "calibration": rows, "seconds": elapsed, "invariants": invariants()}
    write_json(ROOT / "calibration.json", proof)
    print("locked", gains, flush=True)


def summarize(rows, gains):
    rng = np.random.default_rng(202611192154)
    groups = [r["width"]["4800"] for r in rows]
    result = {}
    for field in METRICS:
        subset = [r for r in groups if field in r["origin"]]
        n = len(subset)
        draws = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
        scores = {k: values(subset, k, field, gains.get(k, 0))[draws].mean(axis=1)
                  for k in COMPARISON}
        detailed = {}
        for name, vals in scores.items():
            def interval(ref):
                delta = vals - scores[ref]
                return [float(delta[0]), *np.quantile(delta[1:], [0.025, 0.975]).tolist()]
            detailed[name] = {
                "value": float(vals[0]), "joint": interval("coherent_strength"),
                "phase_blind": interval("phase_blind"), "parent": interval("origin"),
            }
        result[field] = {"n": n, "values": detailed}
    return result


def evaluate(panel):
    calibration = reference(ROOT / "calibration.json")
    binding = reference(COHERENT / f"{panel}.json")
    choices = read_json(checked(calibration))["strengths"]
    prior = read_json(checked(binding))
    rows, elapsed = run(prior["rows"], natural if panel == "natural" else wire)
    gains = {k: a["gain"] for k, a in choices.items()}
    result = summarize_natural(rows, choices) if panel == "natural" else summarize(rows, gains)
    write_json(ROOT / f"{panel}.json", {
        "driver": reference(__file__), "calibration": calibration, "previous": binding,
        "rows": rows, "summary": result, "seconds": elapsed,
    })


if __name__ == "__main__":
    if sys.argv[1] == "calibration":
        lock()
    else:
        assert sys.argv[1] in ("natural", "prior", "fresh", "transfer")
        evaluate(sys.argv[1])
