"""Prepare native sheets with both camera JPEGs and plot paired transfer deltas."""

import os

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from PIL import Image, ImageDraw
from native_neighbors import CONTINUING, FALSE, LABELS, ROOT, pixels


def sheet(key, rows, labels):
    canvas = Image.new("RGB", (8 + 168*len(labels), 26 + 184*len(rows)), "#eeeeee")
    title = ImageDraw.Draw(canvas)
    for col, label in enumerate(labels):
        title.text((8 + 168*col, 5), label, fill="black")
    for row, (label, board) in enumerate(rows):
        values = pixels(board)
        for col, name in enumerate(labels):
            panel = Image.fromarray(values[name])
            assert panel.size == (160, 160)
            canvas.paste(panel, (8 + 168*col, 26 + 184*row))
        title.text((8, 188 + 184*row), label, fill="black")
    file = ROOT / f"view-{key}.png"
    canvas.save(file)
    return reference(file)


def main():
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    receipts = {k: reference(ROOT / f"native/{k}/result.json") for k in ("standing", "exact")}
    standing, exact = (read_json(checked(r))["rows"] for r in receipts.values())
    source = reference(ROOT / "natural-doses.json")
    payload = read_json(checked(source))["comparisons"]["natural_increment"]
    choice = ("Noisy (Malvar)", "Corpus 100k", "Joint gate", "Along-wire phase",
              "Across-wire phase", "ISO100 AHD reference")
    controls = ("V120 EMA", "Four-grid mean", "Wrong phase", "Magnitude only")
    sheets = {}
    for kind, exp in (("main", 4), ("mesh", 4), ("mesh", 16)):
        group = [(r["id"], d["board"]) for r in standing if r["id"].startswith(kind)
                 for d in r["displays"] if d["exposure"] == exp]
        assert len(group) == 4
        tag = f"{kind}-x{exp}"
        sheets[tag] = sheet(tag, group, choice)
        jpgs = ("ISO6400 camera JPEG", "ISO100 camera JPEG") if kind == "mesh" else ()
        sheets[tag + "-controls"] = sheet(tag + "-controls", group, controls + jpgs)
    sheets["exact"] = sheet(
        "neighbor-exact", [(r["id"], r["board"]) for r in exact],
        ("Noisy Malvar", "Corpus 100k", *LABELS.values(), "Exact GT")
    )

    comparisons = [
        ("fundamental_response", "Intact weak response", "Percentage points"),
        (CONTINUING, "Continuing-wire error", "DN16 RMS"),
        (FALSE, "False weak gap projection", "DN16 RMS"),
        ("increment", "Natural fine-increment error", "DN16 RMS"),
    ]
    panels = ("prior", "fresh", "transfer")
    natural = ("retained_natural", "other_natural")
    fig, grid = plt.subplots(2, 2, figsize=(9.7, 5.0), layout="constrained")
    for ax, (metric, title, units) in zip(grid.flat, comparisons, strict=True):
        ax.axvline(0, color="#818181", linewidth=0.9)
        is_natural = metric == "increment"
        sites = natural if is_natural else panels
        for index, (key, color) in enumerate(zip(
            ("tangent", "normal", "quadrature", "phase_blind"),
            ("#328179", "#a2472e", "#696385", "#606060"), strict=True
        )):
            rows = [
                payload[k]["fine"][metric][key]["coherent_strength"] if is_natural
                else payload["wire"][k][metric]["values"][key]["joint"] for k in sites
            ]
            central, low, high = np.array(rows).T
            y = np.arange(len(sites)) + (index - 1.5) * .17
            ax.errorbar(central, y, xerr=(central - low, high - central), color=color,
                        label=LABELS[key], fmt="o", markersize=3.5, capsize=2.8)
        ax.set_title(title)
        ax.set_xlabel(units)
        labels = ("Natural panel A", "Natural panel B") if is_natural else (
            "First off-grid", "Second off-grid", "32-photo replay"
        )
        ax.set_yticks(range(len(labels)), labels)
        ax.set_ylim(len(labels) - .53, -.47)
        ax.grid(axis="x", alpha=.18)
    handles, labels = grid[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside upper center", ncols=4, frameon=False, fontsize=9)
    graph = ROOT / "neighbor-effects.png"
    fig.savefig(graph, dpi=150, facecolor="white")
    write_json(ROOT / "views.json", {
        "driver": reference(__file__), "receipts": receipts, "numerics": source,
        "sheets": sheets, "plot": reference(graph),
    }, replace=True)


if __name__ == "__main__":
    main()
