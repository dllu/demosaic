"""Confirm native Bayer phase on fixed, disjoint neighboring windows."""

from functools import lru_cache
from pathlib import Path
import sys

import numpy as np

from demosaic import scene_patch_covariance as patch

ROOT = Path(__file__).resolve().parent
COHERENT = ROOT.with_name("scene-coherent-fourier-v1")
sys.path.insert(0, str(COHERENT))
from coherent_fourier import cell_update, frequency_cells
from staggered_phase import SHIFTS, amplitudes, blend, staggered_grid

MODES = ("coherent_strength", "tangent", "normal", "quadrature", "phase_blind")


@lru_cache(maxsize=12)
def lag_pairs(colors, band, shape):
    """Select two disjoint windows per carrier axis using geometry alone."""
    # Offsets are expressed in units of one native window, then mapped to
    # the half-window inference grid. Opposite offsets never overlap.
    compass = np.array([[1, 0], [1, 1], [0, 1], [1, -1]])
    directions = compass / np.linalg.norm(compass, axis=1, keepdims=True)
    groups, signs, maps = frequency_cells(colors, band)
    frequency = np.concatenate([staggered_grid(colors, band, s).frequency for s in SHIFTS])
    frequency = frequency * signs[:, None]
    alignment = np.abs(frequency @ directions.T)
    offsets = (compass[alignment.argmin(axis=1)], compass[alignment.argmax(axis=1)])
    axes = (np.arange(shape[0]), np.arange(shape[1]))
    ys, xs = np.meshgrid(*axes, indexing="ij")
    lattice = np.column_stack((ys.ravel(), xs.ravel()))
    result = []
    for direction in offsets:
        displacement = np.stack((direction, -direction))
        slide = lattice[None, :, None, :] + 2 * displacement[:, None, :, :]
        valid = ((slide >= 0) & (slide < shape)).all(axis=-1)
        slide = slide.clip(0, np.asarray(shape) - 1)
        neighbor = slide[..., 0] * shape[1] + slide[..., 1]
        phase = 2 * np.pi * band.size * np.einsum("sfi,fi->sf", displacement, frequency)
        transport = np.exp(1j * phase)
        # z = cosine + i sine, so translation advances the fitted phase
        # by exp(-i * phase). The inverse rotation returns it to center.
        result.append((neighbor, valid, transport))
    return groups, signs, maps, result


def neighbor_scores(observed, sigma, mapping, neighbor, valid, transport):
    """Score adjacent RAW along the query's phase without feeding it into synthesis."""
    ref = observed.mean(axis=1)
    length = np.abs(ref)
    center = np.divide(ref, length, out=np.ones_like(ref), where=length > 0)
    products = []
    indexes = np.arange(observed.shape[-1])
    blocks = np.stack((mapping.real, mapping.imag), axis=-2)
    cov = np.einsum("gfiw,gfjw->fij", blocks, blocks)
    neighbor_green = observed.transpose(0, 2, 1)[neighbor, indexes]
    for turn in (1, 1j):
        direction = (center * turn)[None] * transport[:, None, :].conj()
        measured = (neighbor_green * direction[..., None].conj()).real
        # The two green coefficients have independent scalar variance in
        # this model. Adjacent windows use their own green means.
        quadrature = np.stack((direction.real, direction.imag), axis=-1)
        var = np.einsum("sqfi,fij,sqfj->sqf", quadrature, cov, quadrature)
        scale = sigma[neighbor] * np.sqrt(np.maximum(var, 1e-12))
        norm = np.sqrt(np.maximum(valid.sum(axis=0), 1))
        products.append(((measured.sum(axis=-1) / scale) * valid).sum(axis=0) / norm)
    return products


def local_gate(score):
    """A broad smooth gate that shrinks negative or weak spatial evidence."""
    return np.clip((score + 0.75) / 2.75, 0, 1)


def corrections(raw, parent, colors, shot, read, box, encoded):
    output = {name: np.zeros_like(parent) for name in MODES}
    if encoded is None:
        return output
    all_grids, bank = encoded
    size = bank.band.size
    if min(parent.shape) < size:
        return output

    grids = all_grids[1:]
    axes = tuple(np.arange(0, n - size + 1, size // 2) for n in parent.shape)
    groups, signs, mapping, neighbors = lag_pairs(tuple(colors), bank.band, tuple(map(len, axes)))
    y, x = np.meshgrid(*axes, indexing="ij")
    coords = np.column_stack((y.ravel(), x.ravel()))
    offset = np.arange(size)
    ys = coords[:, 0, None, None] + offset[:, None]
    xs = coords[:, 1, None, None] + offset[None, :]
    raw_windows = patch.sample_windows(raw, coords, size)
    base_windows = parent[ys, xs]
    feature, _, sigma, valid = patch.encode(raw_windows, grids[0].basis, shot, read)
    saved, weights = patch.choose_exterior(
        feature, coords + np.asarray(box)[[1, 0]], bank, ranked=True
    )
    saved = saved[..., len(all_grids[0].frequency):, :]
    mean_raw, mean_base, local = [], [], []
    for grid in grids:
        basis = grid.basis
        project = basis.projection
        green = raw_windows[:, basis.green].reshape(len(coords), 2, -1)
        sensor_base = np.stack(
            [base_windows[:, g // 2 :: 2, g % 2 :: 2] for g in basis.green], axis=1
        ).reshape(len(coords), 2, -1)
        mean_raw.append(np.einsum("gif,qgf->qgi", project, green).reshape(len(coords), 2, -1, 2))
        mean_base.append(np.einsum("gif,qgf->qgi", project, sensor_base).reshape(len(coords), 2, -1, 2))
        local.append(amplitudes(grid, raw_windows, base_windows, shot, read)[1])

    def canonical(pairs):
        return pairs[..., 0] + 1j * signs * pairs[..., 1]

    donors = canonical(saved)
    observed = canonical(np.concatenate(mean_raw, axis=2))
    predicted = canonical(np.concatenate(mean_base, axis=2))
    radial = canonical(np.concatenate(local, axis=1))
    strength = np.zeros_like(radial)
    for indexes in groups:
        _, strength[:, indexes] = cell_update(
            donors[..., indexes], weights, observed[..., indexes], predicted[..., indexes],
            radial[..., indexes], sigma, mapping[:, indexes],
        )

    gate_scores = []
    for neighbor, eligible, transport in neighbors:
        score = neighbor_scores(observed, sigma, mapping, neighbor, eligible & valid[neighbor], transport)
        gate_scores.append(score)
    tangent, quadrature = gate_scores[0]
    normal = gate_scores[1][0]
    # A magnitude control retains adjacent spectral amplitude while discarding
    # its phase relation to the query. The shift offsets its positive noise mean.
    phase_blind = np.hypot(tangent, quadrature) - 1.25
    policies = {
        "coherent_strength": strength,
        "tangent": strength * local_gate(tangent),
        "normal": strength * local_gate(normal),
        "quadrature": strength * local_gate(quadrature),
        "phase_blind": strength * local_gate(phase_blind),
    }

    taper = np.sin((offset + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(coords), size, size)))
    images = np.concatenate([grid.basis.image for grid in grids])
    for name, field in policies.items():
        pairs = np.stack((field.real, field.imag * signs), axis=-1)
        pairs *= valid[:, None, None] / len(grids)
        output[name] = blend(pairs, images, parent, ys, xs, window) / np.maximum(1, norm)
    return output
