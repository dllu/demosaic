"""Reduce paired exact-target metrics and verify the ordinary 12k path."""
from pathlib import Path
import sys

import numpy as np

from context import POLICIES, ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

SOURCE=ROOT.parent/'scene-local-contrast-2400-v1'
sys.path.insert(0,str(SOURCE))
from measure import parts


def compare(diagnostic):
    data=read_json(checked(diagnostic))
    plan=read_json(checked(data['plan']))
    spec=read_json(checked(plan['fixed_development']))
    ordinary=read_json(checked(plan['twelve_k_monitor']))
    previous=read_json(checked(ordinary['plan']))
    ordinary_points={(r['source'],r['draw']):r for r in ordinary['source_metrics']if r['profile']=='iso6400'}
    control={}
    identities=[]
    for row in data['rows']:
        setting=read_json(checked(row['case']))
        old=reference(SOURCE/'evaluation/predictions'/(setting['id']+'.json'))
        row['archive_controls']=old
        record=read_json(checked(old))
        assert row['case']==record['case']
        assert record['exact_query_inputs']=={k:setting['fingerprints'][k]for k in ('packed','variance','colors','wb','matrix')}
        key=(row['source'],row['draw'])
        with np.load(checked(setting['input']),allow_pickle=False) as f:
            inputs={k:np.broadcast_to(f[k],(3,*f[k].shape))for k in ('wb','matrix')}
            target=f['target']
        inputs['exposure']=setting['profile']['exposure']
        with np.load(checked(record['saved']),allow_pickle=False) as f:
            controls={k:parts(inputs,f[k],target,spec) for k in ('100k','V120')}
        control[key]=controls
        if key not in ordinary_points:
            continue
        frozen=read_json(checked(ordinary_points[key]['prediction_receipt']))
        sensor=read_json(checked(frozen['case']))
        assert sensor['fingerprints']==setting['fingerprints']
        with (np.load(checked(frozen['saved']),allow_pickle=False) as baseline,
              np.load(checked(row['outputs']),allow_pickle=False) as new):
            np.testing.assert_array_equal(baseline['spatial--matching'],new['native-cap'])
        identities.append({'case':row['case'],'previous_prediction':ordinary_points[key]['prediction_receipt'],'new':row['outputs']})
    outputs={}
    names=(*POLICIES,'native-cap','100k','V120')
    indices=np.vstack((np.arange(len(plan['development_selection'])),
                       np.random.default_rng(263189).integers(len(plan['development_selection']),size=(10000,len(plan['development_selection'])))))
    for draw in plan['draws']:
        rows=[r for r in data['rows'] if r['draw']==draw]
        assert [r['index']for r in rows]==plan['development_selection']
        metrics=[r['metrics']|control[r['source'],draw] for r in rows]
        scores={}
        for name in names:
            values={}
            for band in ('lower','fine','upper'):
                parts_=[point[name]['band'][band]for point in metrics]
                sums=np.array([r['aligned_increment_dot']for r in parts_])
                exact=np.array([r['exact_paired_increment_sq']for r in parts_])
                values[band]={k:np.array([q[k]for q in parts_])[indices].mean(1)
                    for k in ('increment_RMS_DN16','quiet_RMS_DN16','present_RMS_DN16')}
                values[band]['response_points']=100*sums[indices].sum(1)/exact[indices].sum(1)
            values['flat_color']={k:np.array([q[name]['uniform_core'][k]for q in metrics])[indices].mean(1)
                for k in ('quiet_RGB_mean_absolute_bias_DN16','quiet_RGB_centered_RMS_DN16')}
            scores[name]=values
        pairs=[(arm,'global')for arm in names if arm!='global']+[
            ('hybrid','hybrid-resampled'),('hybrid','hybrid-flipped'),('hybrid','native-cap'),('hybrid','regional'),('hybrid','100k'),('hybrid','V120')]
        intervals={}
        for arm,base in pairs:
            channels={}
            for band,subset in scores[arm].items():
                effect={k:v-scores[base][band][k]for k,v in subset.items()}
                channels[band]={k:[float(v[0]),*np.quantile(v[1:],[.025,.975]).tolist()]for k,v in effect.items()}
            intervals[arm+' vs '+base]=channels
        outputs[draw]={'means':{name:{band:{k:float(v[0])for k,v in b.items()}for band,b in terms.items()}
                                   for name,terms in scores.items()},'paired':intervals}
    geometry={name:[] for name in ('global','full-dense','regional')}
    for row in data['rows']:
        for role in row['preview_geometry']:
            for name in ('global','full-dense'):
                geometry[name].append(role['whole'][name]['pitch_xy'])
            geometry['regional'].append(role['region']['dense']['pitch_xy'])
    stats={k:{'xy_median_native_pixels_per_preview_pixel':np.median(v,axis=0).tolist(),
              'xy_minmax':np.stack((np.min(v,axis=0),np.max(v,axis=0))).tolist()}for k,v in geometry.items()}
    out={'driver':reference(__file__),'diagnostic':diagnostic,'archive_controls':[r['archive_controls']for r in data['rows']],
         'native_cap_bit_exact_to_12k_monitor':identities,
         'prior_monitor':plan['twelve_k_monitor'],'scope':'Same exact present/absent/flat goals at independent and coupled ISO6400. Replayed 16 development photo IDs, excluded from the continuation. Bootstrap by source.',
         'draws':outputs,'geometry':stats}
    write_json(ROOT/'paired.json',out)


if __name__=='__main__':
    compare(reference(ROOT/'development-results.json'))
