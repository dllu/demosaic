"""Render and measure registered native crops using the retained reference transforms."""
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
import torch

from context import POLICIES, ROOT
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board

LABELS={'global':'Full coarse preview','full-dense':'Full dense preview','regional':'Regional only','hybrid':'Registered hybrid',
        'hybrid-resampled':'Resampled hybrid','hybrid-flipped':'Flipped hybrid','native-cap':'Native-cap baseline'}


def measurements(crop):
    return float(np.sqrt(np.mean(crop.astype(np.float64)**2))*65535)


def standing():
    import sys
    sys.path.insert(0,str(ROOT.parent/'scene-preview-scale-v1'))
    from render_standing import board
    trace=reference(ROOT/'standing-results.json')
    report=read_json(checked(trace))
    plan=read_json(checked(report['plan']))
    later=read_json(checked(plan['camera_render']))
    output=ROOT/'standing-native'
    output.mkdir()
    observed=[]
    for case in later['boards']:
        if case['observation'] not in report['cases']:
            continue
        provenance=report['cases'][case['observation']]
        x,y,w,h=box=case['case']['ROI_xywh']
        src=np.asarray(Image.open(checked(case['image'])).convert('RGB'))
        saved={p['label']:src[b:b+d,a:a+c] for p in case['panels'] for a,b,c,d in (p['png_xywh'],)}
        baseline_names=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Local-only 12k EMA')
        panels=[(k,saved[k])for k in baseline_names if k in saved]
        changes={}
        with np.load(checked(case['input_arrays']),allow_pickle=False)as data:
            wb,matrix=[torch.from_numpy(data[k]) for k in ('wb','matrix')]
        with np.load(checked(provenance['outputs']),allow_pickle=False)as file:
            anchor=file['global'][0,:,y:y+h,x:x+w].astype(np.float64)
            for name in POLICIES:
                value=file[name]
                rgb=display_crop(torch.from_numpy(value),wb,matrix,box,exposure=case['display_exposure'])
                panels.append((LABELS[name],np.rint(rgb.clip(0,1)*255).astype(np.uint8)))
                delta=value[0,:,y:y+h,x:x+w].astype(np.float64)-anchor
                changes[name]={'RGB_delta_RMS_DN16':measurements(delta),'highpassed_delta_RMS_DN16':measurements(delta-gaussian_filter(delta,(0,3,3),mode='reflect'))}
        panels.extend((k,saved[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG') if k in saved)
        photo=board(output/(case['id']+'.png'),panels)
        observed.append({k:case[k]for k in ('id','noise','display_exposure','reference_role','input_arrays')}|photo|
                        {'ROI_xywh':box,'scene_boxes':provenance['boxes'],'predictions':provenance['outputs'],
                         'RGB_to_global':changes,'prior':case['image']})
    assert len(observed)==8
    write_json(ROOT/'standing-native.json',{'driver':reference(__file__),'raw':trace,'checkpoint':report['checkpoint'],'cases':observed})


def natural():
    origin=reference(ROOT/'development-results.json')
    source=read_json(checked(origin))
    plan=read_json(checked(source['plan']))
    panel=read_json(checked(plan['fixed_development']))
    output=ROOT/'development-native'
    output.mkdir()
    rows=[]
    for row in source['rows']:
        if row['index'] not in plan['development_selection'][:2] or row['draw']!='independent':
            continue
        case=read_json(checked(row['case']))
        photo=panel['rows'][row['index']]
        cameras=('packed','variance','wb','matrix','colors')
        with (np.load(checked(case['input']),allow_pickle=False)as data,
              np.load(checked(row['outputs']),allow_pickle=False)as predicted):
            for role in (0,2):
                fixture={k:data[k][role:role+1] if k in ('packed','variance')else data[k][None]for k in cameras}
                fixed=('global','full-dense','regional','hybrid','hybrid-resampled','hybrid-flipped','native-cap')
                images=[noisy_malvar(fixture)[0],*[predicted[k][role]for k in fixed],data['target'][role]]
                item=native_board(output,f"{case['id']}-role{role}",images,fixture,
                       {'source':photo['source'],'role':role,'id':case['id'],'CFA':photo['camera']['pattern'],
                        'profile':case['profile'],'capture':row['case'],'predictions':row['outputs'],'query_box':case['box'],
                        'black_level':photo['camera']['black'],'display_contrast':2,'scale':'100% native crop'},
                       labels=('Noisy Malvar',*(LABELS[k]for k in fixed),'Exact GT'),triplet_indices=(0,4,len(images)-1),
                       contrast=2,exposure=1/case['profile']['exposure'],roi=tuple(panel['native_display_ROI_xywh']))
                rows.append(item)
    assert len(rows)==4
    write_json(ROOT/'development-native.json',{'driver':reference(__file__),'raw':origin,'checkpoint':plan['models']['spatial-12k'],'rows':rows})


if __name__=='__main__':
    torch.set_num_threads(2)
    standing()
    natural()
