"""Check literal sampling of known wire carriers at the fixed adapter scales."""
import numpy as np

from context import ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


if __name__=='__main__':
    previous=reference(ROOT.parent/'scene-preview-scale-v1/frequency-geometry.json')
    current=reference(ROOT/'standing-results.json')
    view=reference(ROOT/'standing-native.json')
    geometry=read_json(checked(previous))
    run=read_json(checked(current))
    boards=read_json(checked(view))
    rows=[]
    for item in geometry['rows']:
        name=item['crop']
        if 'main-' in name:
            fixture='main-chain-link-fence'
            family='main'
        else:
            family='mesh'
            fixture='mesh-profile3879' if 'profile3879' in name else 'mesh-nominal'
        assert any(r['id']==name for r in boards['cases'])
        note=run['cases'][fixture]
        shared=run['full_view_receipts'][family]['previews']
        pitch={k:shared[k]['pitch_xy'] for k in ('global','full-dense')} | {'regional':note['region']['dense']['pitch_xy']}
        harmonics=np.asarray(item['carriers_cyc_per_native_xy'],dtype=float)
        comparisons={}
        for key, grid in pitch.items():
            group={}
            for stride in (1,4,8,16,32):
                fmax=.5/(np.asarray(grid)*stride)
                group[str(stride)]={'rectangular_Nyquist_cyc_per_native_xy':fmax.tolist(),
                    'directions_within_grid':(abs(harmonics)<=fmax).all(axis=1).tolist()}
            comparisons[key]=group
        rows.append({'name':name,'known_frequency_xy':harmonics.tolist(),'sampling':comparisons})
    assert len(rows)==5
    assert all(all(r['sampling'][v]['1']['directions_within_grid']) for r in rows for v in ('regional','full-dense'))
    assert all(not any(r['sampling'][v]['4']['directions_within_grid']) for r in rows for v in ('regional','full-dense'))
    write_json(ROOT/'sampling-bound.json',{'driver':reference(__file__),'carrier_source':previous,'preview_source':current,'boards':view,
        'scope':'Nyquist bound for literal carrier oscillation across feature-grid sites. Multi-channel codes may still carry subcell evidence. This is neither an encoder-transfer measurement nor pairwise camera scoring.',
        'rows':rows})
