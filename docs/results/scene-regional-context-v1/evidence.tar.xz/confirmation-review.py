"""Render the first two reserved fields and score them at the fixed pilot settings."""
import sys

import torch

from context import ROOT
from demosaic.experiments.artifacts import reference
import render
import summarize

WORK=ROOT/'confirmation'

if __name__=='__main__':
    torch.set_num_threads(2)
    if 'score' in sys.argv[1:]:
        summarize.ROOT=WORK
        summarize.compare(reference(WORK/'development-results.json'))
    if 'render' in sys.argv[1:]:
        render.ROOT=WORK
        render.natural()
