"""Evaluate the pre-existing faint-half labels across all 64 fixed sources."""
import numpy as np

from context import ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


if __name__=='__main__':
    source=[reference(p/'development-results.json') for p in (ROOT, ROOT/'confirmation')]
    conditions=[read_json(checked(p))['rows']for p in source]
    label=reference(ROOT.parent/'scene-local-contrast-2400-v1/matched-analysis-plan.json')
    ids={k[2]for k in read_json(checked(label))['fainter_half_by_frozen_clean_increment']}
    ordered=[r for cohort in conditions for r in cohort]
    assert len(ids)==32 and len(ordered)==128 and len({r['source']for r in ordered})==64
    all_groups={}
    for draw in ('independent','coupled'):
        rows=[r for r in ordered if r['draw']==draw]
        assert len(set(r['source']for r in rows))==len(rows)==64
        rng=np.random.default_rng(92723)
        groups={}
        for name,subset in (('fainter',[r for r in rows if r['source'] in ids]),('other',[r for r in rows if r['source'] not in ids])):
            indexes=np.vstack((np.arange(32),rng.integers(32,size=(10000,32))))
            assert len(subset)==32
            variants={}
            for policy in ('global','full-dense','regional','hybrid','hybrid-resampled','hybrid-flipped','native-cap'):
                entries=[r['metrics'][policy]['band']['fine']for r in subset]
                cross=np.array([r['aligned_increment_dot']for r in entries])[indexes].sum(1)
                power=np.array([r['exact_paired_increment_sq']for r in entries])[indexes].sum(1)
                item={k:np.array([r[k]for r in entries])[indexes].mean(1)for k in ('increment_RMS_DN16','quiet_RMS_DN16')}
                item['aligned_response_points']=100*cross/power
                variants[policy]=item
            comparisons={}
            for method in ('full-dense','regional','hybrid','hybrid-resampled','hybrid-flipped','native-cap'):
                diff={k:v-variants['global'][k]for k,v in variants[method].items()}
                comparisons[method]={k:[float(v[0]),*np.quantile(v[1:],(.025,.975)).tolist()]for k,v in diff.items()}
            groups[name]={'values':{arm:{k:float(v[0])for k,v in m.items()}for arm,m in variants.items()},
                          'paired_vs_global':comparisons,'sources':sorted(r['source']for r in subset)}
        all_groups[draw]=groups
    write_json(ROOT/'faint.json',{'pilot_and_confirmation':source,'original_clean_stratification':label,'results':all_groups,
              'driver':reference(__file__),'scope':'Pre-existing fixed label from exact target power. Same frozen methods, paired by photo ID.'})
