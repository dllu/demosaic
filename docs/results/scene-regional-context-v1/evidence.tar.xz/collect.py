"""Collect the fixed native predictions and exact-target scores for the regional replay."""
import os
from pathlib import Path
import sys
import time

import numpy as np
import psutil
import torch

from context import POLICIES, PITCH, ROOT, adapter_offsets, full_views, patch_views, restore
from demosaic.cfa import pack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from probe_scene_context_extent import ARGUMENTS, observation

FIXED=ROOT.parent/'scene-local-contrast-2400-v1'
sys.path.insert(0,str(FIXED))
from evaluate import ARGS, load, setup_models
from measure import parts


def prepare_inputs(data):
    items={k:v.to('cuda') for k,v in data.items()}
    for k in ARGUMENTS[:2]:
        items[k]=items[k].contiguous(memory_format=torch.channels_last)
    return items


def put(path, **items):
    assert all(np.isfinite(v).all() for v in items.values()),path
    with path.open('xb') as stream:
        np.savez(stream,**items)
    return reference(path)


def standing(model, plan):
    old=read_json(checked(plan['camera_collection']))
    native=read_json(checked(plan['native_control_plan']))
    assert old['checkpoint']=={k:plan['models']['spatial-12k'][k]for k in ('path','sha256')}
    records={r['id']:r for r in old['records']}
    destination=ROOT/'standing'
    destination.mkdir()
    entries={}
    full_notes={}
    for family,obs_kind in (('main','gfx'),('mesh','mesh')):
        incoming=checked(old['full_real_noisy_sources'][family])
        reference_raw,native_metadata=read_raw(incoming)
        assert native_metadata.pattern=='RGGB' and incoming.is_relative_to(Path.cwd()/'.cache')
        packed=pack(torch.from_numpy(reference_raw)[None,None])[0]
        residents=[row for row in native['observations'] if row['kind']==obs_kind]
        shared=None
        regional_cache={}
        exposure=native['preview_exposure']
        for fixture in residents:
            now=time.monotonic()
            ident=fixture['id']
            older=records[ident]
            raw,_=observation(fixture['arrays'],False)
            signatures={k:fingerprint(v) for k,v in raw.items()}
            assert signatures==older['input_fingerprints']
            boxes=older['scene_box_xywh']
            box,=boxes
            x,y,w,h=box
            torch.testing.assert_close(packed[:,y//2:(y+h)//2,x//2:(x+w)//2],raw['packed'][0],atol=0,rtol=0)
            camera=[raw[k][0] for k in ('colors','wb','matrix')]
            for attr in ('shot','read'):
                assert fixture['noise'][attr]>=0
            model.base.set_noise(fixture['noise']['shot'],fixture['noise']['read'])
            if shared is None:
                shared,info=full_views(model,packed,camera,exposure,global_limit=1024,dense_limit=3072)
                full_notes[family]={'RAW':old['full_real_noisy_sources'][family],'previews':info,'camera':{k:fingerprint(v) for k,v in zip(('colors','wb','matrix'),camera)}}
                basis=camera
            assert all(torch.equal(a,b) for a,b in zip(camera,basis))
            if tuple(box) not in regional_cache:
                regional_cache[tuple(box)]=patch_views(model,packed,camera,exposure,box,PITCH)
            patches,mapped,stamp=regional_cache[tuple(box)]
            offsets=adapter_offsets(model,shared,patches,box,mapped)
            actual=prepare_inputs(raw)
            inputs=[actual[k] for k in ARGUMENTS]
            outputs={k:restore(model,inputs,v).cpu().numpy() for k,v in offsets.items()}
            ordinary=model(*inputs,scene=shared['global'],boxes_xywh=boxes).cpu().numpy()
            np.testing.assert_array_equal(outputs['global'],ordinary)
            assert all(list(v.shape)==fixture['output_shape'] for v in outputs.values())
            baseline=np.load(checked(older['prediction']),allow_pickle=False)
            diff=float(np.linalg.norm(outputs['global'].astype(float)-baseline)*65535/np.sqrt(baseline.size))
            assert diff<=.01,(ident,diff)
            assert tuple(outputs)==POLICIES
            entries[ident]={'fixture':fixture,'boxes':boxes,'input_fingerprints':signatures,'region':stamp,
                            'outputs':put(destination/(ident+'.npz'),**outputs),
                            'prior_global_1024_CPU':older['prediction'],'global_RMS_vs_prior_DN16':diff,
                            'elapsed_seconds':time.monotonic()-now}
            print('standing',ident,'delta from CPU',round(diff,6),'seconds',round(entries[ident]['elapsed_seconds'],2),flush=True)
        del shared,regional_cache,packed,reference_raw
        torch.cuda.empty_cache()
    assert len(entries)==6
    write_json(ROOT/'standing-results.json',{'plan':reference(ROOT/'plan.json'),'driver':reference(__file__),
                  'checkpoint':old['checkpoint'],'full_view_receipts':full_notes,'cases':entries,
                  'exact_global_adapter_forward_identity':True,'precision':'CUDA IEEE FP32 channels last, EMA'})


def development(model, plan):
    spec=read_json(checked(plan['fixed_development']))
    destination=ROOT/'development'
    destination.mkdir()
    profile=next(p for p in spec['profiles'] if p['name']==plan['profile'])
    model.base.set_noise(profile['shot'],profile['read'])
    entries=[]
    start=time.monotonic()
    for i in plan['development_selection']:
        for draw in plan['draws']:
            binding,case,arrays=load(i,(profile['name'],draw))
            with np.load(checked(case['input']),allow_pickle=False) as f:
                target=f['target']
            data={k:torch.from_numpy(v).to('cuda') for k,v in arrays.items()}
            camera=[data[k] for k in ('colors','wb','matrix')]
            source=data['scene_packed']
            box=case['box']
            x,y,w,h=[v//2 for v in box]
            long_side=2*max(source.shape[-2:])
            cap=round(long_side/PITCH)
            pool={k:[]for k in (*POLICIES,'native-cap')}
            encoders=[]
            evidence=[]
            for branch in data['packed']:
                whole=source.clone()
                whole[:,y:y+h,x:x+w]=branch
                others=whole.clone()
                others[:,y:y+h,x:x+w]=source[:,y:y+h,x:x+w]
                torch.testing.assert_close(others,source,atol=0,rtol=0)
                outer,notes=full_views(model,whole,camera,1.,global_limit=cap,dense_limit=round(long_side*3/PITCH))
                loc,mapped,regional=patch_views(model,whole,camera,1.,box,PITCH)
                values=adapter_offsets(model,outer,loc,box,mapped)
                native=model.encode_scene(whole,*camera,long_side=1024)
                values['native-cap']=model.adapter(native,[box],(box[3]//8,box[2]//8),mode='spatial')
                for name,value in values.items():
                    pool[name].append(value)
                evidence.append({'whole':notes,'region':regional})
                if i==plan['development_selection'][0] and draw==plan['draws'][0]:
                    encoders.append(outer['global'])
                del loc,outer,native
            merged={k:torch.cat(v) for k,v in pool.items()}
            actual=[data[k].contiguous(memory_format=torch.channels_last) if k in ('packed','variance')
                    else data[k][None].expand(3,*data[k].shape) for k in ARGS]
            for j,k in enumerate(ARGS[:2]):
                assert fingerprint(actual[j])==case['fingerprints'][k]
            predictions={k:restore(model,actual,v).cpu().numpy() for k,v in merged.items()}
            if encoders:
                same=model(*actual,scene=encoders,boxes_xywh=[box]*3).cpu().numpy()
                np.testing.assert_array_equal(same,predictions['global'])
            display={k:np.broadcast_to(arrays[k],(3,*arrays[k].shape)) for k in ('wb','matrix')}
            measured={k:parts(display|{'exposure':profile['exposure']},v,target,spec) for k,v in predictions.items()}
            entries.append({'case':binding,'source':case['source'],'index':i,'draw':draw,'observations':case['input'],
                            'metrics':measured,'preview_geometry':evidence,
                            'outputs':put(destination/(case['id']+'.npz'),**predictions)})
            print('development',i,draw,len(entries),round(time.monotonic()-start,1),flush=True)
    assert len(entries)==len(plan['development_selection'])*len(plan['draws'])
    write_json(ROOT/'development-results.json',{'plan':reference(ROOT/'plan.json'),'driver':reference(__file__),
          'precision':'CUDA IEEE FP32 channels last, EMA','fixed_input_identity':True,'rows':entries})


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    assert psutil.virtual_memory().available >= 52 * 2**30
    plan=read_json(ROOT/'plan.json')
    assert reference(Path(__file__).parent/'context.py')==plan['implementation']
    model=setup_models(plan)['spatial-12k']
    with ieee_fp32():
        for part in sys.argv[1:]:
            {'standing':standing,'development':development}[part](model,plan)


if __name__=='__main__':
    main()
