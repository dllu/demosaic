"""Audit crop coordinates, offset arithmetic and fixture membership."""
import json

import torch

from context import ROOT, bounded_window, centered_mix
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_context import SceneGrid, sample_scene_features


def field(g, origin, stride):
    h,w=g.padded_hw
    ch,cw=g.preview_hw
    nh,nw=g.native_hw
    y=(torch.arange(h//stride,dtype=torch.float64)+.5)*stride*nh/ch+origin[1]
    x=(torch.arange(w//stride,dtype=torch.float64)+.5)*stride*nw/cw+origin[0]
    return (x[None,:]*.37+y[:,None]*.63)[None,None]


def registration():
    notes=[]
    h,w=640,896
    whole=SceneGrid((h,w),(320,448),(320,448))
    image=torch.arange(h*w,dtype=torch.int32).reshape(h,w)
    fixed=[(0,0,64,64),(w-112,h-176,112,176),(18,30,240,256),(470,334,256,256),(124,12,512,512)]
    for box in fixed:
        nx,ny,nw,nh=box
        area,native=bounded_window((h,w),box)
        x,y,cw,ch=area
        left,top,bw,bh=native
        pixel=image[y:y+ch,x:x+cw][top:top+bh,left:left+bw]
        assert torch.equal(pixel,image[ny:ny+nh,nx:nx+nw])
        rgb=SceneGrid((ch,cw),(ch//2,cw//2),tuple(((x//2+31)//32)*32 for x in (ch,cw)))
        size=(bh//8,bw//8)
        # Ignore border-extending feature-cell centers. Interior linear coordinates
        # must agree across both grids regardless of cropping or padding.
        for stride in (4,8,16,32):
            primary=sample_scene_features(field(whole,(0,0),stride),whole,stride,[box],size)
            local=sample_scene_features(field(rgb,(x,y),stride),rgb,stride,[native],size)
            torch.testing.assert_close(primary[...,2:-2,2:-2],local[...,2:-2,2:-2],rtol=0,atol=1e-10)
        notes.append({'full_query':box,'region':area,'regional_query':native})
    return notes


def moments():
    rng=torch.Generator().manual_seed(5216)
    anchor=torch.randn(3,16,8,17,dtype=torch.float64,generator=rng)
    nearby=torch.randn(3,16,8,17,dtype=torch.float64,generator=rng)
    together=centered_mix(anchor,nearby)
    torch.testing.assert_close(together.mean((-2,-1)),anchor.mean((-2,-1)),rtol=0,atol=3e-16)
    torch.testing.assert_close(centered_mix(anchor,anchor+5.),anchor,rtol=0,atol=8e-16)
    return float((together- anchor).abs().max())


def run():
    plan=read_json(ROOT/'plan.json')
    declared=read_json(checked(plan['paired']))
    train=read_json(checked(declared['plan']))
    with checked(train['train_manifest']).open()as f:
        legal={json.loads(t)['id']for t in f}
    photo=read_json(checked(plan['fixed_development']))
    test={photo['rows'][i]['source']['id']for i in plan['development_selection']}
    assert len(legal)==90692 and len(test)==16 and not legal&test
    write_json(ROOT/'coordinate-audit.json',{'driver':reference(__file__),'plan':reference(ROOT/'plan.json'),
               'paired_source_count':len(test),'continuation_pool_size':len(legal),'source_overlap':0,
               'phase_aligned_regions':registration(),'hybrid_spatial_mean_preserved':True,
               'pure_constant_offset_cancels':True,'offset_max_difference':moments()})


if __name__=='__main__':
    torch.set_num_threads(2)
    run()
