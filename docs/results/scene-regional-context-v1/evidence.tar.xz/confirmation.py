"""Replay the frozen policies on the 48 development sources outside the pilot."""
import sys

import psutil
import torch

from context import ROOT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
import collect

WORK=ROOT/'confirmation'
PILOT=ROOT/'plan.json'


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,8*2**30/torch.cuda.get_device_properties(0).total_memory))
    assert psutil.virtual_memory().available>=52*2**30
    pilot=read_json(PILOT)
    checked(pilot['implementation'])
    panel=read_json(checked(pilot['fixed_development']))
    focus=set(pilot['development_selection'])
    outside=[row['index']for row in panel['rows'] if row['index'] not in focus]
    assert len(outside)==48 and len(focus)==16
    WORK.mkdir()
    plan=pilot|{'driver':reference(__file__),'pilot':reference(PILOT),'development_selection':outside,
           'scope':'Fixed-policy replay on all 48 existing development photo IDs outside the 16-ID regional preview pilot. No density or blend tuning.'}
    write_json(WORK/'plan.json',plan)
    collect.ROOT=WORK
    model=collect.setup_models(plan)['spatial-12k']
    with ieee_fp32():
        collect.development(model,plan)


if __name__=='__main__':
    main()
