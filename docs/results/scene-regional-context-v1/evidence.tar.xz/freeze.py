"""Declare the matched 12k whole-scene and regional preview policies before scoring."""
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from context import ROOT,POLICIES,PITCH,WEIGHT

FULL=ROOT.parent/'scene-full-epoch-v1'
PREV=FULL/'review-native-012000'
NATURAL=ROOT.parent/'scene-local-contrast-2400-v1'
SOURCES=(0,1,5,9,13,17,21,25,29,33,37,41,45,49,53,57)


def main():
    match=reference(FULL/'matched-012000.json')
    paired=read_json(checked(match))
    step=paired['through_update']
    assert step==12000 and paired['matched_input_traces']
    checkpoint=paired['arms']['spatial']['checkpoint'] | {'type':'scene','mode':'spatial','step':step}
    write_json(ROOT/'plan.json',{
        'driver':reference(__file__),'implementation':reference(ROOT/'context.py'),
        'models':{'spatial-12k':checkpoint}, 'paired':match,
        'camera_collection':reference(PREV/'spatial/collection.json'),
        'camera_render':reference(PREV/'work/render/result.json'),
        'native_control_plan':reference(PREV/'plan.json'),
        'fixed_development':reference(NATURAL/'evaluation-plan.json'),
        'twelve_k_monitor':reference(FULL/'review-012000/pilot/results.json'),
        'development_selection':SOURCES,'draws':['coupled','independent'],'profile':'iso6400',
        'policies':POLICIES,'full_preview_caps':[1024,3072],'simulated_global_pitch':PITCH,
        'region_query_factor':4,'regional_preview_cap':1024,'blend':WEIGHT,
        'scope':'Inference-only registered context replay. Native RAW and weights fixed. Development images reserved from the continuation. Both standing GFX sets.'})


if __name__=='__main__':
    main()
