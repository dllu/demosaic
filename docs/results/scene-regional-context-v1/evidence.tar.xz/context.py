"""Reweight the fixed scene adapter between a full preview and a dense neighborhood."""
from pathlib import Path
import time

import torch
from torch.nn import functional as F

from demosaic.prediction_archive import fingerprint
from demosaic.scene_context import scene_preview
from demosaic.scene_restoration import EncodedScene
from probe_scene_context_extent import encode

ROOT=Path(__file__).resolve().parent
POLICIES=('global','full-dense','regional','hybrid','hybrid-resampled','hybrid-flipped')
PITCH=11662/1024
WEIGHT=.5


def bounded_window(native_hw, box, factor=4):
    h,w=native_hw
    x,y,bw,bh=box
    assert min(h,w,bw,bh)>0 and all(v%2==0 for v in (*native_hw,*box))
    assert x>=0 and y>=0 and x+bw<=w and y+bh<=h
    nw,nh=min(w,bw*factor),min(h,bh*factor)
    left=min(max(0,x-(nw-bw)//2),w-nw)
    top=min(max(0,y-(nh-bh)//2),h-nh)
    left,top=left//2*2,top//2*2
    local=(x-left,y-top,bw,bh)
    assert min(local[:2])>=0 and local[0]+bw<=nw and local[1]+bh<=nh
    return (left,top,nw,nh),local


def norm_spatial(x):
    return x-x.mean(dim=(-2,-1),keepdim=True)


def centered_mix(anchor, alternate, weight=WEIGHT):
    return anchor+weight*norm_spatial(alternate-anchor)


def clip_preview(model, data, calibration, limit, exposure):
    began=time.monotonic()
    rgb,grid=scene_preview(data,*calibration,long_side=limit,exposure=exposure)
    rgb=rgb.to(next(model.parameters()).device)
    return rgb,grid,time.monotonic()-began


def encoded(model, image, grid):
    torch.cuda.synchronize()
    began=time.monotonic()
    state=encode(model,image,grid)
    torch.cuda.synchronize()
    return state, {'preview_HW':grid.preview_hw,'native_HW':grid.native_hw,
                   'pitch_xy':[grid.native_hw[j]/grid.preview_hw[j] for j in (1,0)],
                   'image':fingerprint(image.cpu()),'encode_seconds':time.monotonic()-began}


def full_views(model,packed,calibration,exposure,*,global_limit,dense_limit):
    fields={}
    traces={}
    for name,cap in (('global',global_limit),('full-dense',dense_limit)):
        image,grid,spent=clip_preview(model,packed,calibration,cap,exposure)
        fields[name],traces[name]=encoded(model,image,grid)
        traces[name]['render_seconds']=spent
    return fields,traces


def patch_views(model,packed,calibration,exposure,box,pitch):
    region,query=bounded_window(tuple(2*v for v in packed.shape[-2:]),box)
    left,top,width,height=region
    nearby=packed[:,top//2:(top+height)//2,left//2:(left+width)//2]
    dense_fine=min(1024,max(nearby.shape[-2:]))
    coarse_cap=max(1,round(max(width,height)/pitch))
    rgb,grid,duration=clip_preview(model,nearby,calibration,dense_fine,exposure)
    low,lg,low_duration=clip_preview(model,nearby,calibration,coarse_cap,exposure)
    up=F.interpolate(low,size=grid.preview_hw,mode='bilinear',align_corners=False)
    reg,evidence=encoded(model,rgb,grid)
    control,control_evidence=encoded(model,up,grid)
    reflected=EncodedScene(tuple(v.flip((-1,)) for v in reg.features),reg.grid)
    return {'regional':reg,'resampled':control,'flipped':reflected},query,{
        'region_xywh':region,'local_query_xywh':query,
        'dense':evidence|{'render_seconds':duration},
        'resampled':control_evidence|{'original_raster_HW':lg.preview_hw,'render_seconds':low_duration},
    }


def adapter_offsets(model, full, neighborhood, global_box, local_box):
    shape=(global_box[3]//8,global_box[2]//8)
    def project(state,box):
        return model.adapter(state,[box],shape,mode='spatial')
    outer={k:project(s,global_box) for k,s in full.items()}
    inner={k:project(s,local_box) for k,s in neighborhood.items()}
    anchor=outer['global']
    return outer | {'regional':inner['regional'],
                    'hybrid':centered_mix(anchor,inner['regional']),
                    'hybrid-resampled':centered_mix(anchor,inner['resampled']),
                    'hybrid-flipped':centered_mix(anchor,inner['flipped'])}


def restore(model, actual, offsets):
    """Inject the registered offset at the same native trunk level as the adapter."""
    def context_fn(preview, size):
        local=model.base.context(preview,size)
        assert len(local)==3 and local[2].shape==offsets.shape
        return (*local[:2],local[2]+offsets.to(local[2].dtype))
    return model.base.pretrained_rgb(*actual,context=context_fn)
