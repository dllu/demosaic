"""Publish the reviewed native comparisons and frozen regional-context evidence."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
DOC=Path('docs/results/scene-regional-context-v1')
IMAGES=Path('docs/images/scene-regional-context-v1')


def install(board, folder):
    original=checked(board['image'])
    path=IMAGES/folder/original.name
    path.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(original,path)
    binding=reference(path)
    assert binding['sha256']==board['image']['sha256']
    with Image.open(path)as image:
        for pane in board['panels']:
            x,y,w,h=pane['png_xywh']
            assert w==h==160 and x+w<=image.width and y+h<=image.height
        image.verify()
    return board|{'image':{'path':str(path),'sha256':binding['sha256']}}


def finish():
    notes=read_json(ROOT/'viewing.json')
    camera=read_json(ROOT/'standing-native.json')
    pilot=read_json(ROOT/'development-native.json')
    final=read_json(ROOT/'confirmation/development-native.json')
    pilot_hist=read_json(ROOT/'paired.json')
    confirm=read_json(ROOT/'confirmation/paired.json')
    audit=read_json(ROOT/'coordinate-audit.json')
    assert audit['source_overlap']==0
    assert len(pilot_hist['native_cap_bit_exact_to_12k_monitor'])+len(confirm['native_cap_bit_exact_to_12k_monitor'])==16
    assert camera['checkpoint']=={k:pilot['checkpoint'][k]for k in ('path','sha256')}
    assert final['checkpoint']==pilot['checkpoint']
    groups={}
    for tag,data in (('pilot',pilot),('confirmation',final)):
        points=notes['exact'] if tag=='pilot' else notes['confirmation']
        rows=[]
        for r in data['rows']:
            rows.append(r | {k:install(r[k],tag) for k in ('board','triplet')}|
                        {'actual_viewing':points[r['id']]})
        groups[tag]=data|{'rows':rows}
        assert len(rows)==4
    cases=[install(row,'standing')|{'actual_viewing':notes['standing'][row['id']]} for row in camera['cases']]
    assert len(cases)==8
    manifest=IMAGES/'manifest.json'
    write_json(manifest,groups|{'standing':camera|{'cases':cases},'actual_native_viewing_complete':True})
    DOC.mkdir(exist_ok=True,parents=True)
    archive=DOC/'evidence.tar.xz'
    helpers=(Path('scripts/probe_scene_context_extent.py'),Path('scripts/report_scene_wave_guides.py'),
             Path('src/demosaic/scene_context.py'),Path('src/demosaic/scene_restoration.py'),
             ROOT.parent/'scene-local-contrast-2400-v1/measure.py',ROOT.parent/'scene-preview-scale-v1/render_standing.py')
    with tarfile.open(archive,'x:xz')as bundle:
        for rule in ('*.py','*.log','*.json','initial/*.py','initial/*.log','confirmation/*.json'):
            for path in sorted(ROOT.glob(rule)):
                bundle.add(path,arcname=path.relative_to(ROOT))
        for path in helpers:
            bundle.add(path,arcname=Path('frozen-helpers')/path.name)
    write_json(DOC/'publication.json',{
        'scope':'Frozen EMA context intervention on 16 plus 48 development photo backgrounds and both standing GFX families. No training and no full-photo or camera PSNR panel.',
        'checkpoint':camera['checkpoint'],'plan':reference(ROOT/'plan.json'),'archive':reference(archive),
        'actual_native_viewing_complete':True,'manifest':reference(manifest),'numeric_evaluation_complete':True,
        'sources':{key:reference(ROOT/filename)for key,filename in (
            ('pilot','paired.json'),('confirmation','confirmation/paired.json'),('faint','faint.json'),
            ('coordinate_audit','coordinate-audit.json'),('sampling_bound','sampling-bound.json'),('standing','standing-native.json'))},
        'helpers':[reference(p)for p in helpers],
        'camera_deltas_to_coarse':{r['id']:r['RGB_to_global']for r in camera['cases']},
        'pilot_means':{k:v['means']for k,v in pilot_hist['draws'].items()},
        'confirmation_means':{k:v['means']for k,v in confirm['draws'].items()},
    })


if __name__=='__main__':
    finish()
