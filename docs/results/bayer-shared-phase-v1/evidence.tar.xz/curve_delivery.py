"""Distinguish phase-estimation errors from the effect of correct bend geometry."""
from functools import partial
from unittest.mock import patch
import time

import numpy as np

from diagnose import CURVES, ROOT
import shared_phase as operator
from render_phase import native_board
from demosaic.archive_metrics import linear_rgb, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

VARIANTS = ("fixed", "recenter", "curved", "tangent", "exact-curved")
DOSE = .73
CORE = np.s_[...,64:192,64:192]
LUMA = np.array((.2126,.7152,.0722))
CAPTIONS = {
    "parent":"Corpus 100k EMA", "fixed":"Fixed exact center", "recenter":"Checked shift",
    "curved":"Checked quadratic", "tangent":"Checked tangent", "exact-curved":"Exact curve diagnostic",
}


def luma(values, captured):
    return np.stack([np.einsum("c,bchw->bhw",LUMA,linear_rgb(x,{k:captured[k][i]for k in ("wb","matrix")}))
                     for i,x in enumerate(values)])[CORE]


def score(rgb, parent, target, data):
    prediction = luma(rgb,data)
    view = luma(target,data)
    base = luma(parent,data)
    keep = data["region"][CORE] == 1
    gap = data["region"][CORE] == 0
    nominal = data["weak_linear_nominal"][CORE]
    exact = (view[:,0]-view[:,1])
    assert keep.sum()>300 and gap.sum()>256 and (exact[:,gap]==0).all()
    np.testing.assert_array_equal(view[:,1],view[:,2])
    inc = prediction[:,0]-prediction[:,1]
    glow = (prediction[:,0] - view[:,0])[:,gap]
    def rms(images):
        return float(np.sqrt(np.mean(np.reshape(images,(2,-1))**2,axis=-1)).mean()*65535)
    def project(a,b):
        return (a*b).sum(axis=1)/np.square(b).sum(axis=1)
    return {
        "weak_response_pp":float(100*project(inc[:,keep],exact[:,keep]).mean()),
        "weak_increment_RMS_DN16":rms((inc-exact)[:,keep]),
        "exact_gap_RMS_DN16":rms(glow),
        "gap_coherent_DN16":float(np.abs((glow @ nominal[gap])/np.linalg.norm(nominal[gap])).mean()*65535/np.sqrt(gap.sum())),
        "quiet_RMS_DN16":rms(prediction[:,3]-view[:,3]),
        "quiet_added_RMS_DN16":rms(prediction[:,3]-base[:,3]),
    }


def observe(row, plan, bundles, diagnostic, tangent, render_indices):
    i = row["index"]
    source = plan["sources"][i]
    archived = bundles[i]
    # The synthetic supplied frequency and physical curvature come only from the generator.
    detail,tangential = diagnostic[i],tangent[i]
    assert detail["input"]==tangential["input"]==row["capture"]
    assert detail["source_id"]==tangential["source_id"]==source["source"]["id"]
    with np.load(checked(row["capture"]),allow_pickle=False) as f:
        data={name:f[name] for name in f.files}
    with np.load(checked(archived["output"]),allow_pickle=False) as f:
        parent=f["baseline"]
    x,y,w,h = plan["query_box"]
    assert w==h==256
    capture = data["packed"][..., y//2:(y+h)//2,x//2:(x+w)//2]
    truth = data["target"][...,y:y+h,x:x+w]
    spacing = np.array(detail["exact_centers_xy"])
    known = np.array(detail["exact_terms"])
    noise = plan["profile"]
    predictions = {"parent":parent,**{key:parent.copy()for key in VARIANTS}}
    for d, tang in zip(detail["draws"],tangential["rows"],strict=True):
        rep,role = d["repeat"],plan["roles"].index(d["role"])
        assert tang["repeat"]==rep and tang["role"]==d["role"]
        arms = {k:np.asarray(d["shapes"]["delivered_cycles"][k])for k in ("fixed","recenter","curved")}
        params = tang["receipt"]["tangent"]
        supplied = np.where(np.asarray(params["accepted"])[:,None],np.mean(params["each_fit"],axis=0),arms["recenter"])
        arms.update(tangent=supplied,**{"exact-curved":known})
        with patch.object(operator,"ARMS",VARIANTS),patch.object(operator,"measure_geometry",return_value=(arms,None)):
            adds,_=operator.correction(capture[rep,role],parent[rep,role],data["colors"][rep,role],
                          data["wb"][rep,role],data["matrix"][rep,role],noise,spacing,operator.ROI,DOSE,True)
        for arm,image in adds.items():
            predictions[arm][rep,role]+=image
    scores = {arm:score(rgb,parent,truth,data)for arm,rgb in predictions.items()}
    board=None
    if i in render_indices:
        common={name:data[name][0,:1]for name in ("colors","wb","matrix")}
        common["packed"]=capture[0,:1]
        view=[noisy_malvar(common)[0],*(predictions[k][0,0]for k in predictions),truth[0,0]]
        labels=("Noisy Malvar",*(CAPTIONS[k]for k in predictions),"Exact GT")
        board=native_board(ROOT/"bent-native",f'bent-{i:03d}',view,common,
                {"CFA":source["camera"]["pattern"],"noise":noise,"input":row["capture"],"source":source["source"],
                 "source_box":source["box"],"query":plan["query_box"],"parent":archived["output"],"repeat":0,"role":"present"},
                labels=labels,exposure=2,contrast=1,triplet_indices=(0,labels.index(CAPTIONS["exact-curved"]),len(labels)-1))
    assert detail["geometry"]=="bent" or np.array_equal(predictions["fixed"], predictions["exact-curved"])
    return {"index":i, "id":detail["source_id"], "geometry":detail["geometry"], "case":row["capture"],
            "parent":archived["output"],"scores":scores,"board":board}


def summary(rows):
    rng = np.random.default_rng(1103192026)
    selected = rng.integers(len(rows),size=(10000,len(rows)))
    out = {}
    for metric in rows[0]["scores"]["parent"]:
        arms={key:np.array([v["scores"][key][metric]for v in rows])for key in rows[0]["scores"]}
        diffs={}
        for key in (*VARIANTS[1:],"parent"):
            d=arms[key]-arms["fixed"]
            diffs[key]={"mean":float(d.mean()),"interval_95":np.quantile(d[selected].mean(axis=1),[.025,.975]).tolist()}
        out[metric]={"mean":{key:float(v.mean())for key,v in arms.items()},"delta_from_fixed":diffs}
    return out


def main():
    start=time.monotonic()
    refs={stem:reference(path/stem).copy()for path,stem in
          ((ROOT,"diagnostic.json"),(ROOT,"tangent.json"),(CURVES,"fields.json"),(CURVES,"predictions-fresh.json"))}
    saved={key:read_json(checked(value))for key,value in refs.items()}
    panel=saved["fields.json"]
    plan=read_json(checked(panel["plan"]))
    saved_parent=saved["predictions-fresh.json"]
    selected=read_json(checked(saved_parent["selection"]))
    assert selected["observations"]==refs["fields.json"] and saved_parent["checkpoint"]==plan["base"]
    for i, value in enumerate(selected["rows"]):
        assert value["index"]==i and panel["rows"][i]["index"]==i==saved_parent["rows"][i]["index"]
        assert value["input"]==panel["rows"][i]["capture"]
    diag=saved["diagnostic.json"]
    tang=saved["tangent.json"]
    assert diag["exact_source"]==refs["fields.json"] and tang["diagnostic"]==refs["diagnostic.json"]
    (ROOT/"bent-native").mkdir(exist_ok=True)
    render_indices=[i for i,r in enumerate(diag["exact_geometry"])if r["geometry"]=="bent"][:2]
    rows=operator.review.run(panel["rows"],partial(observe,plan=plan,bundles=saved_parent["rows"],
                    diagnostic=diag["exact_geometry"],tangent=tang["exact"], render_indices=render_indices))
    assert len(rows)==20
    write_json(ROOT/"delivery.json",{"driver":reference(__file__),"dependencies":refs,"checkpoint":plan["base"],
         "plan":panel["plan"],"dose":DOSE,"rows":rows,"summary":{
             geometry:summary([r for r in rows if r["geometry"]==geometry])for geometry in ("bent","straight")},
         "scope":"Known centers for all corrected arms. Exact-curved also receives the generator's curvature. All use 64-pixel fits and the same 0.73 delivery dose above frozen Corpus 100k.",
         "seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
