"""Publish the geometry, delivery and actual native checks."""
from pathlib import Path
import hashlib
import shutil
import tarfile

import numpy as np
from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
OUT=Path("docs/results")/ROOT.name
IMAGES=Path("docs/images")/ROOT.name


def copy_board(item,scope):
    source=checked(item["image"])
    destination=IMAGES/scope/source.name
    destination.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(source,destination)
    assert reference(destination)["sha256"]==item["image"]["sha256"]
    item["image"]["path"]=destination.relative_to(IMAGES).as_posix()
    pieces={}
    with Image.open(destination) as image:
        for cell in item["panels"]:
            x,y,w,h=cell["png_xywh"]
            assert w==h==160 and 0<=x<=image.width-w and 0<=y<=image.height-h
            pieces[cell.get("label") or cell["name"]]=image.crop((x,y,x+w,y+h))
    assert len(pieces)==len(item["panels"])
    return pieces


def writable_row(row,scope):
    panels=copy_board(row["board"],scope)
    if "triplet" in row:
        for inst in (row["triplet"],*row.get("other_triplets",{}).values()):
            cells=copy_board(inst,scope)
            assert len(cells)==3
            assert all(ImageChops.difference(panels[label],view).getbbox() is None for label,view in cells.items())
    return panels


def main():
    OUT.mkdir(exist_ok=True)
    sources={key:reference(ROOT/f"{key}.json")for key in ("diagnostic","tangent","wire","delivery")}
    saved={key:read_json(checked(value))for key,value in sources.items()}
    diagnostic,tangent,wire,delivery=(saved[k]for k in sources)
    assert diagnostic["operator"]==wire["operator"] and tangent["diagnostic"]==sources["diagnostic"]
    assert delivery["dependencies"]["diagnostic.json"]==sources["diagnostic"]
    assert delivery["dependencies"]["tangent.json"]==sources["tangent"]
    assert len(diagnostic["exact_geometry"])==len(delivery["rows"])==20
    assert len(wire["rows"])==48 and len(wire["calibration"])==24
    for row in wire["rows"]+wire["calibration"]:
        checked(row["input"])
        checked(row["parent_output"])
    for row in delivery["rows"]:
        checked(row["case"])
        checked(row["parent"])
    for record in saved.values():
        checked(record["driver"])
    checked(wire["checkpoint"])
    checked(wire["parent"])
    checked(delivery["checkpoint"])
    views={}
    for tag,count in (("exact",3),("standing",8)):
        record=read_json(ROOT/tag/"manifest.json")
        assert record["geometry_benchmark"]==sources["wire"] and record["checkpoint"]==wire["checkpoint"]
        assert len(record["rows"])==count
        checked(record["driver"])
        for row in record["rows"]:
            panels=writable_row(row,tag)
            base=np.asarray(panels["64-pixel carrier fit"])
            names=("Checked frequency shift","Checked quadratic","Unchecked quadratic")
            row["changed_display_channel_codes"]={k:int(np.count_nonzero(np.asarray(panels[k])!=base))for k in names}
        views[tag]=record
    bent=[]
    for row in delivery["rows"]:
        if row["board"] is not None:
            writable_row(row["board"],"bent")
            bent.append(row)
    assert len(bent)==2
    views["bent"]={"checkpoint":delivery["checkpoint"],"rows":bent}
    views["actual_viewing"]={"exact":5,"standing":8,
         "observations":"All eight standing boards were inspected with the designated ISO100 references and both cab JPEGs. The checked fits retain the original crossing pattern and smooth sky. The cab stays mottled and fine intersections remain incomplete. Two planted bent examples and three matched exact-target boards were evaluated at native scale. The supplied shape makes a faint difference without restoring the full exact pattern."}
    manifest=IMAGES/"manifest.json"
    write_json(manifest,views,replace=True)
    members={k:ROOT/k for k in (
          "shared_phase.py","diagnose.py","tangent.py","wire_benchmark.py","curve_delivery.py","render_phase.py","publish.py",
          "diagnostic.log","tangent.log","wire.log","delivery.log","exact.log","standing.log",
          "standing/manifest.json","exact/manifest.json")}
    members.update({f"{k}.json":checked(v)for k,v in sources.items()})
    plan_inputs={"prior/scale-screen.json":checked(wire["prior"]),
                 "prior/field-inputs.json":checked(diagnostic["camera_inputs"]),
                 "prior/bent-plan.json":checked(delivery["plan"])}
    members.update(plan_inputs)
    archive=OUT/"evidence.tar.xz"
    with tarfile.open(archive,"w:xz",preset=4)as collection:
        for label,source in sorted(members.items()):
            collection.add(source,arcname=label,recursive=False)
    with tarfile.open(archive)as collection:
        assert collection.getnames()==sorted(members)
        for label,source in members.items():
            with collection.extractfile(label)as contents:
                assert hashlib.file_digest(contents,"sha256").hexdigest()==reference(source)["sha256"]
    write_json(OUT/"publication.json",{"checkpoint":wire["checkpoint"],"parent":wire["parent"],
            "frozen_wide_checkpoint":wire["frozen_wide_checkpoint"],"frozen_phase":wire["frozen_phase"],
            "curve_delivery_checkpoint":delivery["checkpoint"],"source_receipts":sources,"training":False,
            "wire_contrasts":{k:v["contrasts"]for k,v in wire["reports"].items()},
            "bent_delivery":delivery["summary"],"bent_delivery_seconds":delivery["seconds"],
            "camera_diagnostic":diagnostic["camera"],"tangent_camera":tangent["camera"],
            "native_manifest":{"path":f"../../images/{ROOT.name}/manifest.json","sha256":reference(manifest)["sha256"]},
            "archive":{"path":archive.name,"sha256":reference(archive)["sha256"],"entries":len(members)},
            "scope":"Inference only, one fixed crop composition and a conditional curvature oracle on archived Corpus 100k queries. No fixed427 or measured camera numerical scores."},replace=True)
    print("Published",len(members),"receipt members and 13 inspected native comparisons")


if __name__=="__main__":
    main()
