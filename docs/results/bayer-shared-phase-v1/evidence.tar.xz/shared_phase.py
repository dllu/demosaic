"""Fit geometry across RAW windows while retaining distinct local coefficients."""
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
SCALE = ROOT.parent / "bayer-carrier-scale-v1"
sys.path.insert(0, str(SCALE))

from carrier_scale import planes
from restore import TEMPLATES, BLENDS, ROI, unpack, geometry, compose, review
from apply_scale import setup as prior_setup, select

ARMS = ("fixed", "recenter", "curved", "unchecked")
SIZE = 64
BOUNDS = np.array((.30, .30, .20, .20, .20))
MIN_GAIN = 3.
MAX_DISAGREEMENT = .18
CENTERS = (16, 80)
TONE = TEMPLATES[SIZE]


def coords(tx, ty, frequencies):
    y,x = np.indices((SIZE,SIZE),dtype=np.float64)
    x += tx-79.5
    y += ty-79.5
    nominal = np.stack((x,y),axis=-1)@frequencies.T
    x,y = x/64,y/64
    field = np.stack((x,y,.5*x*x,x*y,.5*y*y),axis=-1)
    return nominal,field


def wave(nominal, field, correction):
    angle = 2*np.pi*(nominal+field@correction.T)
    return np.concatenate((np.cos(angle),np.sin(angle)),axis=-1)


def clip_samples(array, offset):
    y,x=offset
    plane=array[y::2,x::2]
    return plane.reshape((-1,*plane.shape[2:]))


def make_station(raw, pattern, xy, starts, frequencies):
    tx,ty=starts
    nominal,field=coords(tx,ty,frequencies)
    offsets=planes(pattern,(xy[0]+tx,xy[1]+ty,SIZE))
    picture=raw[ty:ty+SIZE,tx:tx+SIZE]
    return tuple((clip_samples(picture,o).astype(np.float64),clip_samples(TONE,o),
                  clip_samples(nominal,o),clip_samples(field,o))for o in offsets)


def estimate(scene, amplitudes):
    raw,tone,center,field=scene
    carrier=wave(center,field,amplitudes)
    matrix=np.concatenate((tone,carrier),axis=-1)
    gram=matrix.T@matrix
    coeff=np.linalg.solve(gram,matrix.T@raw)
    return matrix,gram,coeff,raw-matrix@coeff,carrier


def variance(raw,noise):
    return max(2e-11,noise["shot"]*max(0.,float(raw.mean()))+noise["read"])


def update(stations, current, active, noise):
    points, targets=[],[]
    for item in stations:
        U,rho,v,residual,w=estimate(item,current)
        field=item[3][:,:active]
        slope=2*np.pi*(-w[:,2:]*v[-4:-2]+w[:,:2]*v[-2:])
        basis=(slope[...,None]*field[:,None,:]).reshape(len(w),-1)
        basis -= U@np.linalg.solve(rho,U.T@basis)
        unit=np.sqrt(variance(item[0],noise))
        points.append(basis/unit)
        targets.append(residual/unit)
    columns=np.concatenate(points,axis=0)
    values=np.concatenate(targets)
    form=columns.T@columns
    damp=.10*np.diag(form)+.01
    delta=np.linalg.solve(form+np.diag(damp),columns.T@values)
    return delta.reshape(2,active),float(values@values)


def optimize(stations, initial, active, noise):
    params=initial.copy()
    for _ in range(5):
        step,incumbent=update(stations,params,active,noise)
        limits=BOUNDS[:active]
        step=np.clip(step,-limits/2,limits/2)
        if np.max(abs(step)) < .0005:
            break
        for fraction in (1.,.5,.25):
            trial=params.copy()
            trial[:,:active]=np.clip(params[:,:active]+fraction*step,-limits,limits)
            error=sum(np.sum(estimate(station,trial)[3]**2)/variance(station[0],noise) for station in stations)
            if error < incumbent:
                params=trial
                break
        else:
            break
    return params


def reserve_gain(stations, old, proposed, noise):
    score=np.zeros(2,dtype=np.float64)
    for fit,hold in stations:
        test,tone,nominal,shape=hold
        previous=estimate(fit,old)[2]
        null=test-np.concatenate((tone,wave(nominal,shape,old)),axis=-1)@previous
        baseline=float(null@null)
        for k in range(2):
            candidate=old.copy()
            candidate[k]=proposed[k]
            parameters=estimate(fit,candidate)[2]
            pred=np.concatenate((tone,wave(nominal,shape,candidate)),axis=-1)@parameters
            residual=test-pred
            score[k]+=(baseline-residual@residual)/variance(fit[0],noise)
    return score


def accept(stations, old, next_params, noise, references=None):
    p,q=next_params
    references=(old,old) if references is None else references
    gain=np.stack([reserve_gain(bank,b,c,noise)for bank,b,c in zip(stations,references,next_params,strict=True)])
    difference=[]
    for ty in CENTERS:
        for tx in CENTERS:
            _,field=coords(tx,ty,np.zeros((2,2)))
            disagreement=field@(p-q).T
            difference.append(np.ptp(disagreement,axis=(0,1)))
    worst=np.max(difference,axis=0)
    known=(gain.min(axis=0)>MIN_GAIN)&(worst<MAX_DISAGREEMENT)
    return np.where(known[:,None],(p+q)*.5,old),{
        "reserve_whitened_gains":gain.tolist(),"max_in_tile_phase_disagreement":worst.tolist(),
        "accepted":known.tolist(),"each_fit":[p.tolist(),q.tolist()],
    }


def measure_geometry(raw, cfa, xy, frequencies, noise):
    windows=[make_station(raw,cfa,xy,(tx,ty),frequencies)for ty in CENTERS for tx in CENTERS]
    banks=(windows,[p[::-1]for p in windows])
    training=[[p[0]for p in bank]for bank in banks]
    zero=np.zeros((2,5))
    first=[optimize(bank,zero,2,noise)for bank in training]
    linear,step1=accept(banks,zero,first,noise)
    second=[optimize(bank,anchor,5,noise)for bank,anchor in zip(training,first,strict=True)]
    curved,step2=accept(banks,linear,second,noise,references=first)
    params={"fixed":zero,"recenter":linear,"curved":curved,"unchecked":np.mean(second,axis=0)}
    return params,{"recenter":step1,"curved":step2,"delivered_cycles":{k:v.tolist()for k,v in params.items()}}


def fit_patch(raw, parent, colors, absolute, carrier, profile):
    offsets=planes(colors,absolute)
    design=np.concatenate((TONE,carrier),axis=-1)
    stations=tuple((clip_samples(raw,o).astype(np.float64),clip_samples(design,o))for o in offsets)
    def learn(training,reserve):
        a,M=training
        b,N=reserve
        gram=M.T@M
        pr=M.T@a
        solve=np.linalg.solve(gram,pr)
        residual=b-N@solve
        full=residual@residual
        gain=[]
        for family in range(2):
            active=np.ones(len(pr),dtype=bool)
            active[len(pr)-4+family::2]=False
            e=b-N[:,active]@np.linalg.solve(gram[active][:,active],pr[active])
            gain.append((e@e-full)/variance(a,profile))
        return solve[-4:].reshape(2,2).T,gain
    first,second=learn(*stations),learn(*stations[::-1])
    support=np.maximum(0.,np.minimum(first[1],second[1])-6.)
    if not support.any():
        return np.zeros_like(raw)
    estimate=(first[0]+second[0])*.5
    matrix=design.reshape(-1,design.shape[-1])
    recovered=np.linalg.solve(matrix.T@matrix,matrix.T@parent.ravel())[-4:].reshape(2,2).T
    difference=(estimate-recovered)*(support/(support+6))[:,None]
    cap=np.linalg.norm(estimate,axis=1)
    difference*=np.minimum(1,cap/np.maximum(np.linalg.norm(difference,axis=1),1e-10))[:,None]
    return (carrier@difference.T.ravel()).astype(np.float32)


def correction(raw,parent,cfa,wb,matrix,noise,spacing,roi,dose,admitted, *, diagnostic=False):
    if not admitted:
        return {a:np.zeros_like(parent)for a in ARMS},None
    x,y,width,height=roi
    assert width==height==160
    mosaic=unpack(raw)[y:y+height,x:x+width]
    options,note=measure_geometry(mosaic,cfa,(x,y),spacing,noise)
    if diagnostic:
        return options,note
    mass=np.zeros((height,width),dtype=np.float64)
    sums={a:np.zeros_like(mass)for a in ARMS}
    stage=parent[1,y:y+height,x:x+width]
    blend=BLENDS[SIZE]
    for ty in range(0,height-SIZE+1,SIZE//2):
        for tx in range(0,width-SIZE+1,SIZE//2):
            bounds=np.s_[ty:ty+SIZE,tx:tx+SIZE]
            phases,field=coords(tx,ty,spacing)
            previous={}
            for arm,item in options.items():
                key=item.tobytes()
                if key not in previous:
                    previous[key]=fit_patch(mosaic[bounds],stage[bounds],cfa,(x+tx,y+ty,SIZE),
                                               wave(phases,field,item),noise)
                sums[arm][bounds]+=previous[key]*blend
            mass[bounds]+=blend
    edge=np.minimum(1,np.minimum(np.arange(width)+.5,np.arange(width)[::-1]+.5)/12)
    weights=(edge[:,None]*edge[None,:])/np.maximum(.02,mass)
    ratios=np.linalg.solve(matrix,np.ones(3))/wb
    output={}
    for arm,signal in sums.items():
        rgb = np.zeros_like(parent)
        rgb[:,y:y+height,x:x+width]=(ratios/ratios[1])[:,None,None]*(signal*weights)[None]
        output[arm]=np.float32(dose)*rgb
    return output,note
