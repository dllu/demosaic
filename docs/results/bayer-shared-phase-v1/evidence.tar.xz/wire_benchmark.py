"""Measure rendered shared geometry at the existing Bayer correction dose."""
from functools import partial
import sys
import time

import numpy as np

from shared_phase import ROOT, SCALE, ARMS, ROI, geometry, compose, correction, prior_setup, review
from review_quiet import CORE, LOCAL, numeric, wire_inputs
from quadrature import products, rms_at
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0,str(ROOT.parent/"local-phase-envelope-v1"))
from gap_projection import subspace


def observe(case, plan, lookup, model, dose):
    sampled, parents, proof=wire_inputs(case,lookup,None)
    scene=plan["sources"][case["index"]]
    noise=plan["profiles"][case["noise"]]
    box=plan["query"]
    spacing,admitted,geom=geometry(sampled["full"],sampled["colors"][0],box,ROI)
    donation=review.exterior(sampled["full"],sampled["colors"][0],noise,box)
    parent=[]
    candidate=[]
    by_policy=[]
    for raw,cfa,wb,matrix,output in zip(sampled["packed"],sampled["colors"],sampled["wb"],sampled["matrix"],parents[LOCAL],strict=True):
        base=compose(raw,cfa,wb,matrix,noise,box,donation,output,model,False)
        rendered,notes=correction(raw,base["distant"],cfa,wb,matrix,noise,spacing,ROI,dose,admitted)
        parent.append(base)
        by_policy.append(rendered)
        candidate.append(notes)
    def luma(value):return review.old.luma(value,sampled)[...,CORE[0],CORE[1]]
    base=luma(np.stack([r["distant"]for r in parent]))
    anchor=luma(np.stack([r["ring8"]for r in parent]))
    truth=luma(sampled["target"])
    frac=sampled["support"][CORE]
    gap=frac<=.01
    present=frac>=.97
    values={arm:luma(np.stack([r[arm]for r in by_policy]))for arm in ARMS}
    values["distant"]=np.zeros_like(base)
    values["ring8"]=anchor-base
    error=base-truth
    target=(truth[0]-truth[1])[present]
    prediction=(base[0]-base[1])[present]
    masks=subspace(scene["geometry"],gap)
    result={}
    for arm,img in values.items():
        inc=(img[0]-img[1])[present]
        scores={"aligned":[*review.aligned(target,prediction),*review.aligned(target,inc)],
                "intact_rms":products(prediction-target,inc),
                "intact_change":products(np.zeros_like(inc),inc),
                "gap_exact":products(error[0][gap],img[0][gap]),
                "gap_added":products(np.zeros(gap.sum()),img[0][gap]),
                "flat_rms":products(error[3,8:-8,8:-8],img[3,8:-8,8:-8]),
                "flat_added":products(np.zeros_like(img[3,8:-8,8:-8]),img[3,8:-8,8:-8])}
        if masks is None:
            scores["gap_weak_error"]=[0,0,0,0]
        else:
            basis=masks[-1]
            scores["gap_weak_error"]=products(basis.T@error[0][gap],basis.T@img[0][gap])
            scores["gap_weak_error"][-1]=int(gap.sum())
        result[arm]=scores
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"profile":case["noise"],"input":case["input"],"parent_output":proof,
            "source_id":scene["source"]["id"],"gap_pixels":int(gap.sum()),"geometry":geom,"phase":candidate,"products":result}


def group(row,matched):
    output={}
    choices=[(key,key,1.)for key in (*ARMS,"distant","ring8")]+[(label,"fixed",dose)for label,dose in matched.items()]
    for label,key,dose in choices:
        row_data=row["products"][key]
        point,energy,add,_=row_data["aligned"]
        output[label]={k:rms_at(v,dose)for k,v in row_data.items()if k!="aligned"}
        output[label].update(intact_dot=point+dose*add,intact_power=energy)
    return row|{"metrics":output|{"matched":output["fixed"]}}


def main():
    start=time.monotonic()
    (model,dose),receipt=prior_setup()
    fixed=reference(SCALE/"wire.json")
    earlier=read_json(checked(fixed))
    facts={}
    for key,count in (("wire-tune",24),("wire",48)):
        source=read_json(checked(earlier["inputs"][key]))
        sets=read_json(checked(source["inputs"]))["rows"]
        plan=read_json(checked(source["plan"]))
        facts[key]=review.run(sets,partial(observe,plan=plan,lookup={r["id"]:r for r in source["rows"]},
                                   model=model,dose=dose["scale64"]))
        assert len(facts[key])==count
    calib=facts["wire-tune"]
    rates={key:float(np.mean([rms_at(r["products"][key]["intact_change"],1)for r in calib]))for key in ARMS}
    adjusted={m+"-matched":rates[m]/rates["fixed"]for m in ARMS[1:]}
    results=[group(r,adjusted)for r in facts["wire"]]
    from benchmark import evaluate as previous
    visited={r["id"]:previous(r,earlier["dose"])for r in earlier["rows"]["wire"]}
    for r in results:
        match=visited[r["id"]]
        assert (r["input"],r["parent_output"]) == (match["input"],match["parent_output"])
        for k in ("intact_rms","gap_exact","flat_rms"):
            u,v=r["metrics"]["fixed"][k],match["metrics"]["scale64"][k]
            if u is not None:
                assert abs(u-v)<.002,(r["id"],k,u,v)
    cohorts={n:[r for r in results if r["profile"]==n]for n in ("iso400","iso6400")}
    comparisons=[(k,x)for k in ARMS[1:]for x in ("fixed",k+"-matched","distant")]
    keys=("intact_response","intact_rms","gap_exact","gap_added","gap_weak_error","flat_rms")
    write_json(ROOT/"wire.json",receipt|{"driver":reference(__file__),"operator":reference(ROOT/"shared_phase.py"),
            "prior":fixed,"matched_calibration":adjusted,"calibration":calib,"rows":results,
            "reports":numeric(cohorts,comparisons,keys),"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
