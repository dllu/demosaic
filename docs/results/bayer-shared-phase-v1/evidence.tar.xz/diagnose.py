"""Measure conditional sub-bin and quadratic geometry on sensor reserves."""
from functools import partial
from pathlib import Path
import time

import numpy as np

from shared_phase import ROOT, SCALE, CENTERS, coords, measure_geometry, review, unpack
from carrier_scale import cut
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

CURVES=ROOT.parent/"query-phase-curvature-v1"


def camera():
    file=reference(SCALE/"field.json")
    survey=read_json(checked(file))
    rows=[]
    for group,record in survey["inputs"].items():
        array,metadata=read_raw(checked(record["media"]["noisy"]))
        layout=np.asarray(color_indices(metadata.pattern))
        for name,(box,_) in record["rois"].items():
            prior=survey["results"][name]["candidate_frequencies_xy"]["separate-RAW-spacing"]
            geometry=np.asarray(prior,dtype=np.float64)
            radius=np.linalg.norm(geometry,axis=-1)
            angles=abs(geometry[:,1]/geometry[:,0])
            nominated=np.asarray(survey["results"][name]["donor_modes"])
            agreeing=(np.linalg.norm(nominated-geometry,axis=-1)<=.009).all(axis=1)
            accepted=bool(agreeing.any() and np.all((radius>=.077)&(radius<=.195)&(angles>=.26)&(angles<=3.8)))
            names=("nominal",) if group=="main"else ("nominal","transferred")
            checks={}
            for label in names:
                noise=survey["profiles"][label]
                _,checks[label]=measure_geometry(cut(array,box),layout,box[:2],geometry,noise)
            rows.append({"region":name,"box":box,"raw":record["media"]["noisy"],"frequencies_xy":prior,
                         "original_admission":accepted,"checks":checks})
        del array
    return rows,file


def known_geometry(layout):
    families=[]
    for carrier in ("strong","weak"):
        frequency=np.asarray(layout[f"{carrier}_frequency_xy"],dtype=np.float64)
        tangent=np.array((-frequency[1],frequency[0]))/np.linalg.norm(frequency)
        curvature=layout[f"{carrier}_tangential_curvature_cycles_per_px2"]
        adjusted=np.r_[0,0,curvature*(64**2)*np.asarray([tangent[0]**2,tangent.prod(),tangent[1]**2])]
        if frequency[0]<0:
            frequency,adjusted=-frequency,-adjusted
        families.append((frequency,adjusted))
    return tuple(np.stack(v)for v in zip(*families,strict=True))


def assess(parameters,truth):
    scores=[]
    for ty in CENTERS:
        for tx in CENTERS:
            _,field=coords(tx,ty,np.zeros((2,2)))
            delta=field@(parameters-truth).T
            delta-=delta.mean(axis=(0,1),keepdims=True)
            scores.append(np.square(delta).mean(axis=(0,1)))
    return np.sqrt(np.mean(scores,axis=0)).tolist()


def synthetic(record,plan):
    note=plan["sources"][record["index"]]
    frequencies,truth=known_geometry(note["layout"])
    noise=plan["profile"]
    qx,qy,_,_=plan["query_box"]
    region=(qx+48,qy+48,160)
    with np.load(checked(record["capture"]),allow_pickle=False)as camera:
        inputs=camera["packed"]
        layouts=camera["colors"]
    rows=[]
    for repeat in range(len(inputs)):
        for r,label in enumerate(plan["roles"]):
            mosaic=unpack(inputs[repeat,r])
            params,audit=measure_geometry(cut(mosaic,region),layouts[repeat,r],region[:2],frequencies,noise)
            rows.append({"repeat":repeat,"role":label,"shapes":audit,
                         "local_phase_error_cycles":{k:assess(c,truth)for k,c in params.items()}})
    return {"source_id":note["source"]["id"],"input":record["capture"],"geometry":"bent" if np.any(truth)else "straight",
            "exact_centers_xy":frequencies.tolist(),"exact_terms":truth.tolist(),"draws":rows}


if __name__=="__main__":
    start=time.monotonic()
    rows,survey=camera()
    atomic=reference(CURVES/"fields.json")
    data=read_json(checked(atomic))
    exact=review.run(data["rows"],partial(synthetic,plan=read_json(checked(data["plan"]))))
    assert len(rows)==6 and len(exact)==20
    write_json(ROOT/"diagnostic.json",{"driver":reference(__file__),"operator":reference(ROOT/"shared_phase.py"),
           "camera_inputs":survey,"camera":rows,"exact_source":atomic,"exact_geometry":exact,
           "scope":"Noisy-only standing geometry. The archived synthetic diagnostic supplies only the exact center frequency; shape must be inferred from RAW.",
           "seconds":time.monotonic()-start})
