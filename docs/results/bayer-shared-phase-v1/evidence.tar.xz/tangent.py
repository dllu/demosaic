"""Fit a shared tangential curvature with just one parameter per wire family."""
from functools import partial
import time

import numpy as np

from shared_phase import ROOT, CENTERS, make_station, estimate, variance, accept, optimize
from diagnose import CURVES, known_geometry, assess
from shared_phase import unpack, review
from carrier_scale import cut
from demosaic.cfa import color_indices
from demosaic.io import read_raw
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def fit(stations, fixed, tangent, noise):
    refined=fixed.copy()
    scalar=np.zeros(2)
    for _ in range(5):
        xs,ys=[],[]
        for station in stations:
            matrix,gram,c,residual,w=estimate(station,refined)
            differential=2*np.pi*(-w[:,2:]*c[-4:-2]+w[:,:2]*c[-2:])*(station[3][:,2:]@tangent.T)
            differential-=matrix@np.linalg.solve(gram,matrix.T@differential)
            weight=np.sqrt(variance(station[0],noise))
            xs.append(differential/weight)
            ys.append(residual/weight)
        X,Y=np.concatenate(xs),np.concatenate(ys)
        H=X.T@X
        step=np.linalg.solve(H+np.diag(.1*np.diag(H)+.01),X.T@Y)
        if np.max(abs(step)) < .0005:
            break
        for alpha in (1.,.5,.25):
            z=np.clip(scalar+alpha*np.clip(step,-.15,.15),-.30,.30)
            candidate=fixed.copy()
            candidate[:,2:]=z[:,None]*tangent
            error=sum(np.square(estimate(q,candidate)[3]).sum()/variance(q[0],noise)for q in stations)
            if error < Y@Y:
                scalar,refined=z,candidate
                break
        else:
            break
    return refined


def measure(raw,layout,xy,frequency,noise):
    frames=[make_station(raw,layout,xy,(x,y),frequency)for y in CENTERS for x in CENTERS]
    splits=frames,[a[::-1]for a in frames]
    halves=[[s[0]for s in part]for part in splits]
    zero=np.zeros((2,5),dtype=np.float64)
    linear=[optimize(g,zero,2,noise)for g in halves]
    coherent,first=accept(splits,zero,linear,noise)
    y,x=(frequency/np.linalg.norm(frequency,axis=1,keepdims=True)).T
    tangent=np.stack((x*x,-x*y,y*y),axis=-1)
    result=[fit(s,a,tangent,noise)for s,a in zip(halves,linear,strict=True)]
    accepted,check=accept(splits,coherent,result,noise,references=linear)
    return accepted,{"recenter":first,"tangent":check,"accepted_cycles":accepted.tolist()}


def synthetic(record,plan):
    source=plan["sources"][record["index"]]
    frequency,truth=known_geometry(source["layout"])
    qx,qy,_,_=plan["query_box"]
    box=(qx+48,qy+48,160)
    with np.load(checked(record["capture"]),allow_pickle=False)as data:
        inputs,layouts=data["packed"],data["colors"]
    rows=[]
    for i in range(len(inputs)):
        for k,role in enumerate(plan["roles"]):
            values,receipt=measure(cut(unpack(inputs[i,k]),box),layouts[i,k],box[:2],frequency,plan["profile"])
            rows.append({"repeat":i,"role":role,"receipt":receipt,"phase_error_cycles":assess(values,truth)})
    return {"source_id":source["source"]["id"],"input":record["capture"],"geometry":"bent"if np.any(truth)else "straight","rows":rows}


def main():
    elapsed=time.monotonic()
    audit=reference(ROOT/"diagnostic.json")
    data=read_json(checked(audit))
    surveyed=read_json(checked(data["camera_inputs"]))
    cameras=[]
    for group,fields in surveyed["inputs"].items():
        sensor,meta=read_raw(checked(fields["media"]["noisy"]))
        cfa=np.asarray(color_indices(meta.pattern))
        for prior in data["camera"]:
            name=prior["region"]
            if name not in fields["rois"]:
                continue
            roi=prior["box"]
            noise=surveyed["profiles"]
            checks={key:measure(cut(sensor,roi),cfa,roi[:2],np.asarray(prior["frequencies_xy"]),noise[key])[1]
                    for key in prior["checks"]}
            cameras.append({"region":name,"raw":prior["raw"],"original_admission":prior["original_admission"],"checks":checks})
        del sensor
    bound=read_json(checked(data["exact_source"]))
    cases=review.run(bound["rows"],partial(synthetic,plan=read_json(checked(bound["plan"]))))
    write_json(ROOT/"tangent.json",{"driver":reference(__file__),"diagnostic":audit,"camera":cameras,
               "exact":cases,"seconds":time.monotonic()-elapsed})


if __name__=="__main__":
    main()
