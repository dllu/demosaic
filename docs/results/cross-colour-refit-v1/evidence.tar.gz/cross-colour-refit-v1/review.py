"""Evaluate unchanged refits, fixed gate changes and equal-quiet diagnostics."""

import importlib.util
from itertools import product
from pathlib import Path

import numpy as np
from probe_cross_colour_refit import MODES, PANELS
from probe_surface_aggregation import field
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "local-phase-bounds-v1/review.py"
spec = importlib.util.spec_from_file_location("old_report_reader", PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)


def synth(done, split, plan, output):
    boards, cases = [], []
    for row in done:
        case, p, gt, quiet, images = prior.read_case(row, split)
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        names = ["parent", *(field(g, a, t) for g, a, t in product(guides, MODES, (0, 1)))]
        moments = {k: measure(p, gt, quiet, images[k]) for k in names}
        cases.append({"id": case["id"], "profile": case["profile"], "moments": moments})
        if split != "synthetic" or case["profile"] != "iso400" or case["source"] not in (88, 89):
            continue
        with np.load(checked(case["sensor"])) as raw:
            ctx = {k: raw[k][2:3] for k in ("colors", "wb", "matrix")}
            ctx["packed"] = raw["packed"][2:3, :, 64:192, 64:192]
        parent = p[2][ROI]
        op = plan["settings"][case["profile"]]
        labels = ("Independent", "Joint CFA", "Bounded partners")
        values = [parent + op["scale"] * (images[field("scene", a, 0)][2] - parent) for a in MODES]
        boards.append(
            native_board(
                output,
                case["id"],
                [noisy_malvar(ctx)[0], parent, *values, gt[2][ROI]],
                ctx,
                {
                    "case_receipt": row["case"],
                    "CFA": case["CFA"],
                    "noise": case["metadata"]["noise"],
                    "checkpoint": plan["parent_checkpoint"],
                    "operating": op,
                },
                labels=["Noisy Malvar", "V143 EMA", *labels, "Exact GT"],
                triplet_indices=(0, 4, 5),
                contrast=5,
            )
        )
    results = []
    for profile, setting in plan["settings"].items():
        for guide, offset in product(guides, (0, 1)):
            group = [r["moments"] for r in cases if r["profile"] == profile]
            modes = {"parent": "parent", **{a: field(guide, a, offset) for a in MODES}}
            means = {
                arm: {k: np.mean([r[key][k] for r in group], axis=0) for k in group[0][key]}
                for arm, key in modes.items()
            }
            alpha = setting["scale"]
            fixed = {a: evaluated(m, alpha) for a, m in means.items()}
            limit = fixed["screened"]["quiet_RMS_DN16"]
            budget = max(0, limit - fixed["parent"]["quiet_RMS_DN16"])
            matched = {}
            for arm, moment in means.items():
                scale = min(alpha, scale_at_budget(moment["quiet_mse"], budget))
                matched[arm] = evaluated(moment, scale) | {"scale": scale}
                assert (
                    matched[arm]["quiet_RMS_DN16"]
                    <= max(limit, fixed["parent"]["quiet_RMS_DN16"]) + 1e-9
                )
            results.append(
                {
                    "panel": split,
                    "guide": guide,
                    "profile": profile,
                    "threshold": setting["threshold"] + offset,
                    "case_count": len(group),
                    "fixed_scale": alpha,
                    "quiet_limit_DN16": limit,
                    "fixed": fixed,
                    "matched": matched,
                }
            )
    case_moments = [
        r | {"moments": {a: {k: v.tolist() for k, v in m.items()} for a, m in r["moments"].items()}}
        for r in cases
    ]
    return results, boards, case_moments


def camera(done, plan, output):
    base = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    labels = ("Independent", "Joint", "Bounded")
    names = {
        field(g, a, 0): f"{g.title()} {l}"
        for g, (a, l) in product(("scene", "spectral"), zip(MODES, labels))
    }
    rows = []
    for row, old in zip(done, base, strict=True):
        key, s = old["id"], old["source"]
        assert key == row["id"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = s["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            values = {a: f[a] for a in ("parent", *names)}
        with np.load(checked(s["query_arrays"])) as f:
            ctx = {a: f[a] for a in ("wb", "matrix")}
        exposure = old["display_exposure"]
        pixels = {
            a: np.rint(
                display(img[None], ctx, exposure=exposure)[0][region].transpose(1, 2, 0) * 255
            ).astype(np.uint8)
            for a, img in values.items()
        }
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, positions = insert_camera_panels(
            output,
            key,
            old | {"panels": panels},
            "V120 EMA",
            [(label, pixels[a]) for a, label in names.items()],
        )
        ax, ay, *_ = s["absolute_query_xywh"]
        rows.append(
            {
                "id": key,
                "image": image,
                "panels": positions,
                "noise": noise[key],
                "display_exposure": exposure,
                "ROI_xywh": [x - qx + ax, y - qy + ay, w, h],
                "checkpoint": s["checkpoint"],
                "calibration": s["query_arrays"],
                "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
                "reference": "DSCF3880 ISO100 AHD"
                if key.startswith("main-")
                else "DSCF3835 ISO100 AHD and both camera JPEGs",
                "predictions": row["predictions"],
                "CFA": "RGGB",
                "deltas": {
                    a: {
                        "RMS_DN16": float(
                            np.sqrt(
                                np.mean((img[region].astype(float) - values["parent"][region]) ** 2)
                            )
                            * 65535
                        ),
                        "display_pixels_changed": int(
                            np.any(pixels[a] != pixels["parent"], axis=2).sum()
                        ),
                    }
                    for a, img in values.items()
                    if a != "parent"
                },
            }
        )
    return rows


def null_stats(rows):
    groups = {
        "flat": {"flat"},
        "straight": {"step", "rail"},
        "complex": {"wedge", "bent-rail", "two-rails"},
    }
    results = {}
    for label, styles in groups.items():
        data = [r for r in rows if r["style"] in styles]
        results[label] = {}
        for arm, offset in product(MODES, (0, 1)):
            key = field("null", arm, offset)
            entries = [r["metrics"][key] for r in data]
            results[label][key] = {
                "count": len(entries),
                "changed": sum(v["changed_pixels"] > 0 for v in entries),
                "RMS_DN16": float(np.sqrt(np.mean([v["RMS_DN16"] ** 2 for v in entries]))),
                "peak_DN16": max(v["max_abs_DN16"] for v in entries),
            }
    return results


def sensitivity(rows):
    result = {}
    for profile in {r["profile"] for r in rows}:
        chosen = [r["metrics"] for r in rows if r["profile"] == profile]
        result[profile] = {}
        for arm in chosen[0]:
            result[profile][arm] = {}
            for key in chosen[0][arm]:
                v = np.asarray([r[arm][key] for r in chosen])
                result[profile][arm][key] = float(
                    np.sqrt(np.mean(v**2)) if key.endswith("RMS_DN16") else v.mean()
                )
    return result


def main():
    plan_path = ROOT / "plan.json"
    plan = read_json(plan_path)
    out = ROOT / "review"
    out.mkdir(exist_ok=True)
    stages = {label: reference(ROOT / f"{label}.json") for label in PANELS}
    rows = {label: read_json(checked(p))["rows"] for label, p in stages.items()}
    assert [len(rows[p]) for p in PANELS] == [16, 16, 8, 48, 16]
    synthetic, boards, cases = synth(rows["synthetic"], "synthetic", plan, out)
    disjoint, _, extra = synth(rows["disjoint"], "disjoint", plan, out)
    write_json(out / "case-moments.json", cases + extra)
    write_json(
        out / "result.json",
        {
            "plan": reference(plan_path),
            "stages": stages,
            "prior_render_source": reference(PRIOR),
            "boards": boards,
            "camera": camera(rows["camera"], plan, out),
            "wire_panels": synthetic + disjoint,
            "nulls": null_stats(rows["replication"]),
            "rail_sensitivity": sensitivity(rows["sensitivity"]),
        },
    )


if __name__ == "__main__":
    main()
