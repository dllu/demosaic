"""Publish reviewed native comparisons and bind the immutable executed evidence."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
review_path = root / "review/result.json"
review = read_json(review_path)
assert len(review["boards"]) == 2 and len(review["camera"]) == 8
plan = read_json(checked(review["plan"]))
results = Path.cwd() / "docs/results" / root.name
images = Path.cwd() / "docs/images" / root.name
images.mkdir()
results.mkdir()


def copy(binding):
    source = checked(binding)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return output.name


manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "scope": "Two synthetic boards and native triplets, and all eight GFX crop comparisons. "
        "The GFX crops use independent qualitative reference captures.",
        "synthetic": [
            r | {k: r[k] | {"file": copy(r[k]["image"])} for k in ("board", "triplet")}
            for r in review["boards"]
        ],
        "camera": [r | {"file": copy(r["image"])} for r in review["camera"]],
    },
)
summary = results / "summary.json"
write_json(
    summary,
    {k: v for k, v in review.items() if k not in ("boards", "camera")}
    | {
        "case_moments": reference(root / "review/case-moments.json"),
        "camera": [
            {k: r[k] for k in ("id", "ROI_xywh", "checkpoint", "noise", "deltas")}
            for r in review["camera"]
        ],
    },
)
previous = root.parent / "screened-query-edges-v1"
fallback = previous / "work/scripts/probe_matched_query_evidence.py"
old_plan = read_json(previous / "plan.json")
assert reference(fallback)["sha256"] == old_plan["frozen_files"][str(fallback)]
members = {
    root: [
        "plan.json",
        *(f"{k}.json" for k in review["stages"]),
        *(f"{k}.log" for k in ("camera", "disjoint", "replication", "sensitivity")),
        *(f"{k}-retry.log" for k in ("replication", "sensitivity", "synthetic")),
        "tests-publish.log",
        "review.log",
        "review/case-moments.json",
        "review/result.json",
        "review.py",
        "publish.py",
        "work/scripts/probe_cross_colour_refit.py",
        "work/scripts/probe_flexible_query_edges.py",
        "work/src/demosaic/joint_colour_evidence.py",
        "work/src/demosaic/local_validated_waves.py",
    ],
    previous: ["work/scripts/probe_matched_query_evidence.py"],
    root.parent / "flexible-query-edges-v1": ["sensitivity.py"],
    root.parent / "local-phase-bounds-v1": ["review.py"],
    root.parent / "matched-query-evidence-v1": ["structure_null.py"],
}
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as stream,
    tarfile.open(fileobj=stream, mode="w") as bundle,
):
    for folder, names in members.items():
        for name in names:
            p = folder / name
            entry = bundle.gettarinfo(str(p), arcname=f"{folder.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with p.open("rb") as f:
                bundle.addfile(entry, f)
with tarfile.open(archive) as bundle:
    for folder, names in members.items():
        for name in names:
            assert (
                bundle.extractfile(f"{folder.name}/{name}").read() == (folder / name).read_bytes()
            )
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(manifest),
        "verified_members": sum(map(len, members.values())),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "target_dependency_on_retry": reference(fallback),
        "screened_checkpoint_composition": plan["parent_checkpoint"],
        "new_checkpoint": None,
    },
)
