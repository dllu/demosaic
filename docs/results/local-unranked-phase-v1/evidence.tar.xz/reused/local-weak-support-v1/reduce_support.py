"""Summarize fixed policies and paired equal-response diagnostics."""

from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from weak_support import OUT
from conditional import replay
from evaluate_ring import ABS, FALSE, GAP, interval, source_bootstrap

RESPONSE = replay.ABSOLUTE
ADDED = 'gap_added_DN16'
QUIET = ('flat_added_DN16', 'edge_update_RMS_DN16', 'uniform_update_RMS_DN16')
METRICS = (RESPONSE, ABS, GAP, FALSE, ADDED, *QUIET)
PANELS = {'calibration': 'exterior-calibration', 'retained': 'retained',
          'recent': 'exterior-recent', 'fresh': 'exterior-new', 'target_assisted': 'oracle-new'}


def evaluate(draw, choice):
    arm, weight = choice
    return replay.metrics_at(draw['powers'][arm], weight)


def values(rows, choice):
    result = {key: [] for key in METRICS}
    for row in rows:
        draws = [evaluate(draw, choice) for draw in row['draws']]
        for key in METRICS:
            scores = [d[key] for d in draws if key in d]
            result[key].append(mean(scores) if scores else None)
    return result


def means(rows, choice):
    return {k: mean(v for v in vv if v is not None)
            for k, vv in values(rows, choice).items() if any(v is not None for v in vv)}


def compare(rows, path, reference_path):
    first, second = values(rows, path), values(rows, reference_path)
    result = {}
    for key in METRICS:
        subset, effects = [], []
        for row, a, b in zip(rows, first[key], second[key], strict=True):
            assert (a is None) == (b is None)
            if a is not None:
                subset.append(row)
                effects.append(a - b)
        if subset:
            ids = source_bootstrap(subset, np.random.default_rng(202611200424))
            result[key] = {'sources': len(subset), 'difference_interval': interval(np.array(effects)[ids].mean(axis=1))}
    return result


def support_counts(rows):
    counts = dict.fromkeys(('selected', 'color_available', 'exterior_available'), 0)
    for row in rows:
        for draw in row['draws']:
            for role in draw['evidence']:
                counts['selected'] += len(role.get('selected', []))
                for key in ('color_available', 'exterior_available'):
                    counts[key] += sum(role.get(key, []))
    return counts


def review_panel(name, binding, rows, choices):
    valid = {k: v for k, v in choices.items() if v[0] in rows[0]['draws'][0]['powers']}
    scores = {k: means(rows, v) for k, v in valid.items()}
    baseline = scores['combined'][RESPONSE]
    denominator = scores['weak'][RESPONSE] - baseline
    matched = {}
    for key, choice in valid.items():
        if key in ('combined', 'weak', 'uniform'):
            continue
        weight = (scores[key][RESPONSE] - baseline) / denominator
        assert 0 <= weight <= 1
        control = ('weak', weight)
        matched[key] = {'uniform_weight': weight, 'uniform_means': means(rows, control),
                        'versus_equal_response_uniform': compare(rows, choice, control)}
        np.testing.assert_allclose(matched[key]['uniform_means'][RESPONSE], scores[key][RESPONSE], atol=1e-12)
    out = {'receipt': binding, 'sources': len(rows), 'noise_draws_per_source': [len(r['draws']) for r in rows],
           'means': scores, 'availability': support_counts(rows) if 'color' in valid else None,
           'equal_response_diagnostic': matched,
           'weak_vs_combined': compare(rows, valid['weak'], valid['combined']),
           'vs_fixed_uniform': {k: compare(rows, v, valid['uniform']) for k, v in valid.items() if k != 'uniform'}}
    if name == 'fresh':
        out['quiet_surfaces'] = {k: {q: {'max_DN16': max(samples), 'nonzero_draws': sum(x > 0 for x in samples)}
                                    for q, samples in {q: [evaluate(d, v)[q] for r in rows for d in r['draws']]
                                                       for q in QUIET}.items()} for k, v in valid.items()}
    if name == 'recent':
        case = next(r for r in rows if r['id'] == 'weak-side-07')
        draw = case['draws'][0]
        out['largest_prior_draw'] = {'source_id': case['id'], 'draw': draw['draw'], 'input': draw['input'],
                                     'metrics': {k: evaluate(draw, v) for k, v in valid.items()}}
    return out


def parity(current, previous):
    maxima = dict.fromkeys(('combined', 'weak'), 0.0)
    for a, b in zip(current, previous, strict=True):
        assert a['id'] == b['id']
        for one, two in zip(a['draws'], b['draws'], strict=True):
            assert one['input'] == two['input'] and one['outputs'] == two['outputs']
            for k, old in (('combined', 'nested'), ('weak', 'free_5_no_guard')):
                expected = two['nominal'][old]
                now = one['nominal'][k]
                assert set(expected) <= set(now)
                for metric, score in expected.items():
                    np.testing.assert_allclose(now[metric], score, atol=1e-8, rtol=1e-10)
                    maxima[k] = max(maxima[k], abs(now[metric] - score))
    return maxima


def main():
    receipts = {label: reference(OUT / f'{name}.json') for label, name in PANELS.items()}
    data = {label: read_json(checked(binding)) for label, binding in receipts.items()}
    policy = data['calibration']['policy']
    choices = {'combined': ('combined', 1), 'weak': ('weak', 1),
               'uniform': ('weak', policy['control']['weight'])}
    choices.update({label: (r['name'], r['weight']) for label, r in policy['selected'].items()})
    choices['known_support'] = ('true_stations', 1)
    prior = reference(OUT.with_name('local-conditional-posterior-v1') / 'confirmation-weak-dose.json')
    plan = read_json(checked(data['fresh']['plan']))
    parent = read_json(checked(data['fresh']['source']))
    roles = plan['roles']
    assert len(roles) == 6 and plan['source_count'] == len(data['fresh']['rows']) == 24
    report = {label: review_panel(label, receipts[label], p['rows'], choices) for label, p in data.items()}
    write_json(OUT / 'summary.json', {
        'driver': reference(Path(__file__)), 'locked_calibration': receipts['calibration'],
        'choices': choices, 'target_assisted_using_clean_four_station_means': True,
        'previously_published_replay': prior,
        'maximum_prior_score_differences': parity(data['recent']['rows'], read_json(checked(prior))['rows']),
        'fresh_capture': {'plan': data['fresh']['plan'], 'parents': data['fresh']['source'],
                          'training_photo_visits_audited': plan['training_photo_visits_audited'],
                          'weights': parent['weights'], 'precision': parent['precision'],
                          'roles': roles, 'parent_capture_seconds': parent['seconds']},
        'panels': report,
    })


if __name__ == '__main__':
    main()
