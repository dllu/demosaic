"""Replay ordinary-photo input under authentic and planted incompatible context."""

from pathlib import Path
from statistics import mean
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
import unranked_phase as model

ROI = (176,176,160,160)
LOCAL = (48,48,160,160)
QUERY = np.s_[...,64:192,64:192]
RGB = np.s_[...,48:208,48:208]


def main():
    calibration = reference(model.OUT / "calibration.json")
    policy = read_json(checked(calibration))["policy"]
    alternate = reference(model.OUT.parent / "local-near-phase-v1/contexts-calibration.json")
    natural = reference(model.OUT.parent / "local-weak-contrast-v1/natural-controls.json")
    scenes = read_json(checked(natural))
    pairs = read_json(checked(alternate))
    plan = read_json(checked(pairs["plan"]))
    rows = []
    modes = {"near": "near", "unverified": "unverified", "primary": policy["primary"]["arm"]}
    for row, altered in zip(scenes["rows"], pairs["records"], strict=True):
        assert row["id"] == altered["id"]
        f = model.replay.arrays(row["input"])
        source = altered["streams"][0]["far_phase"]
        other = np.load(checked(source), allow_pickle=False)
        other[QUERY] = f["scene_packed"][QUERY]
        np.testing.assert_array_equal(other[QUERY], f["packed"][0])
        colors, wb, matrix = f["colors"], f["wb"], f["matrix"]
        base = f["parent"][RGB].astype(np.float64)
        target = f["target"][RGB].astype(np.float64)
        results = {}
        for condition, raw in (("authentic", f["scene_packed"]), ("planted_mismatch", other)):
            freq = _spacing(raw, colors, *ROI[:2], clearance=48)
            arms, trace = model.qualify(f["parent"], LOCAL, raw, colors, ROI, freq, plan["noise"], wb, matrix)
            def rgb_rms(a, b):
                return float(np.sqrt(np.mean((a.astype(np.float64) - b)**2))*65535)
            def luma_rms(a):
                return float(np.sqrt(np.mean(model.replay.luma((a-target)[None], wb, matrix)**2))*65535)
            chosen = policy["primary"]
            arms[chosen["arm"]] = (arms["near"].astype(np.float64) + chosen["calibrated"]["weight"]
                                   * (arms[chosen["arm"]].astype(np.float64) - arms["near"])).astype(arms["near"].dtype)
            values = {label: {"added_from_parent_DN16": rgb_rms(arms[key], base),
                              "added_from_near_DN16": rgb_rms(arms[key], arms["near"]),
                              "target_luma_error_DN16": luma_rms(arms[key])} for label, key in modes.items()}
            results[condition] = {"scores": values, "state": trace["state"]}
        rows.append({"id": row["id"], "input": row["input"], "alternate_context": source, "results": results})
    summary = {}
    for condition in ("authentic", "planted_mismatch"):
        subset = [row["results"][condition] for row in rows]
        scores = {label: {key: mean(r["scores"][label][key] for r in subset)
                          for key in subset[0]["scores"][label]} for label in modes}
        summary[condition] = {"means": scores, "with_frequency": sum(r["state"] != "no frequency" for r in subset),
                              "ambiguous": sum(r["state"] == "ambiguous rank" for r in subset),
                              "changed_from_near": sum(r["scores"]["primary"]["added_from_near_DN16"] > 0 for r in subset)}
    write_json(model.OUT / "natural-replay.json", {"driver": reference(Path(__file__)), "calibration": calibration,
              "source": natural, "alternate_donors": alternate, "rows": rows, "summary": summary})


if __name__ == "__main__":
    main()
