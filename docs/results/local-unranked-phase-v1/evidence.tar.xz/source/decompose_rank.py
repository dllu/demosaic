"""Attribute exact-gap changes to the continuing and interrupted direction."""

from pathlib import Path
from statistics import mean
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import unranked_phase as model
from replay_rank import ADDED, ABS, GAP, QUIET, RESPONSE, compare


def additions(parent, data, roi, frequency, noise, policy):
    shot, read = noise["shot"], noise["read"]
    scene = data["scene_packed"].copy()
    scene[:, 64:192, 64:192] = data["packed"][0]
    colors, wb, matrix = (data[k] for k in ("colors", "wb", "matrix"))
    original = model._rgb
    contributions = []

    def report(*args):
        rgb = original(*args)
        contributions.append(rgb)
        return rgb

    with patch.object(model, "_rgb", report):
        result, trace = model.qualify(parent, model.replay.ROI, scene, colors, roi, frequency, noise, wb, matrix)
    base = result["near"].astype(np.float64)
    if trace["state"] != "ambiguous rank":
        assert not contributions
        return base, (np.zeros_like(base), np.zeros_like(base))
    assert len(contributions) == 2 and policy["method"] == "collar"
    origin = roi[:2]
    green = tuple(2*r+c for r,c in model._positions(colors, *origin))
    sites = [model._sites(scene, *origin, 160, *s) for s in model._SITES]
    mixed = []
    for d, estimated in enumerate(contributions):
        closure = model._observations(scene, origin, frequency, d, shot, read)
        phase, eligible = model._pool_phases(*closure, frequency[d], green)
        score = model._signed_evidence(sites, phase, frequency, d, green, shot, read)
        weight = model.field(np.where(eligible, np.clip((score-policy["cut"])/2,0,1),0))
        mixed.append(model._GAIN * weight * estimated)
    np.testing.assert_array_equal((base + sum(mixed)).astype(np.float32), result[policy["arm"]])
    return base, tuple(value*policy["calibrated"]["weight"] for value in mixed)


def main():
    torch.set_num_threads(2)
    confirmation = reference(model.OUT / "fresh.json")
    receipt = read_json(checked(confirmation))
    policy = read_json(checked(receipt["calibration"]))["policy"]["primary"]
    plan = read_json(checked(receipt["plan"]))
    x, y, _, _ = plan["query"]
    local = model.replay.ROI
    roi = (x+local[0], y+local[1], *local[2:])
    output = []
    worst = []
    for row in receipt["rows"]:
        for d in row["draws"]:
            metrics = model.replay.metrics_at(d["powers"][policy["arm"]], policy["calibrated"]["weight"])
            worst.append({"id": row["id"], "draw": d["draw"], "added_gap_DN16": metrics.get(ADDED),
                          "flat_delta_DN16": np.sqrt(max(0, d["powers"][policy["arm"]][QUIET[0]][2]))})
            if ADDED not in d["nominal"]["near"]:
                continue
            input_data = model.replay.arrays(d["input"])
            parent = np.load(checked(d["outputs"]["local50k"]), allow_pickle=False)[0]
            base, (front, rear) = additions(parent, input_data, roi, np.asarray(d["actual_frequency"]), plan["noise"], policy)
            support = model.replay.support_for_scoring(input_data["support"])
            optics = model.replay.WireFundamental(input_data | {"target": input_data["target"][:4],
                                                              "support": support}, row["fixture"]["geometry"])
            wb, matrix = input_data["wb"], input_data["matrix"]
            gt = input_data["target"][0, :, 48:208, 48:208].astype(np.float64)
            def luma(field):
                return model.replay.luma(field[None, ..., 16:144, 16:144], wb, matrix)[0][optics.gap]

            def rms(x):
                return float(np.sqrt(np.mean(x**2)) * 65535)
            lower, upper = luma(front), luma(rear)
            residual = luma(base - gt)
            scores = {"continuing_delta_DN16": rms(lower), "absent_delta_DN16": rms(upper),
                      "total_delta_DN16": rms(lower + upper), "near_target_luma_error_DN16": rms(residual),
                      "with_first_only_luma_error_DN16": rms(residual + lower),
                      "with_second_only_luma_error_DN16": rms(residual + upper),
                      "with_both_luma_error_DN16": rms(residual + lower + upper)}
            assert abs(scores["total_delta_DN16"] - metrics[ADDED]) < .002
            output.append({"id": row["id"], "draw": d["draw"], "input": d["input"], "scores": scores})
    summary = {key: mean(row["scores"][key] for row in output) for key in output[0]["scores"]}
    changed = [row for row in output if row["scores"]["total_delta_DN16"] > 0]
    write_json(model.OUT / "gap-attribution.json", {"driver": reference(Path(__file__)), "source": confirmation,
               "calibration": receipt["calibration"], "means": summary, "draws_changed": len(changed),
               "worst_gap": max(output, key=lambda row: row["scores"]["total_delta_DN16"]),
               "worst_flat":max(worst,key=lambda row: row["flat_delta_DN16"]), "rows": output})


if __name__ == "__main__":
    main()
