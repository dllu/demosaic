"""Audit independent direction checks in the standing camera crops."""
import unranked_phase as model
import review_near as review
from demosaic.experiments.artifacts import reference, write_json


def centers(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    values, trace = model.qualify(parent, local, scene, colors, roi, peaks, noise, wb, matrix, clearance=16)
    return {"parent": review.view.section(parent, *local), "nested": values["near"],
            "ring_phase": values["tangent/1.5"], "lift": values["ring/1.5"],
            "annular": values["bilateral/1.5"], "pooled": values["collar/1.5"]}, trace


review.view.arcs = centers
review.view.NAMES = review.LABELS | {"nested": "Near Phase", "ring_phase": "Tangent 1.5",
                                    "lift": "Ring 1.5", "annular": "Bilateral 1.5", "pooled": "Collar 1.5"}
out = model.OUT / "pilot-standing"
out.mkdir(exist_ok=True)
value = review.view.standing({}, out)
write_json(model.OUT / "pilot-standing.json", {"operator": reference(model.__file__), "data": value})
for r in value["rows"]:
    print(r["id"], r["support"], {k: round(v["from_nested_DN16"], 3) for k, v in r["delta"].items()}, flush=True)
