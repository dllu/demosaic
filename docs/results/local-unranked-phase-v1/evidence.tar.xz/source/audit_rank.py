"""Verify held station isolation and phase origins on all Bayer layouts."""

from pathlib import Path
import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
from demosaic._mesh_near_phase import _signed_evidence
from demosaic._mesh_weak_phase import _SITES, _carrier
from demosaic.mesh_carrier_fit import _positions, _sites
import unranked_phase as model

FREQUENCIES = np.asarray(((.095, .077), (.083, -.080)))
PHASES = np.asarray(((.014, -.011), (.01, .016)))
ORIGIN = (95, 97)
STATION = (3, 4)
INDEX = STATION[0] * 10 + STATION[1]


def pack(raw):
    return np.asarray([raw[r::2, c::2] for r, c in _SITES], dtype=np.float32)


def main():
    x, y = ORIGIN
    raw = .22 + np.einsum("yxdi,di->yx", _carrier(352, -x, -y, FREQUENCIES), PHASES)
    yy, xx = np.indices(raw.shape)
    raw += .00020 * (xx - x) - .00015 * (yy - y)
    bottom, left = y + STATION[0] * 16, x + STATION[1] * 16
    keep = np.s_[bottom:bottom+16, left:left+16]
    modified = raw.copy()
    carrier = _carrier(352, -x, -y, FREQUENCIES)[keep][..., 1, :]
    modified[keep] -= 2 * (carrier @ PHASES[1])
    test = []
    for layout, color in PATTERNS.items():
        green = tuple(2*r+c for r,c in _positions(color, x, y))
        original, edited = pack(raw), pack(modified)
        a, b = (model.center_bands(scene, ORIGIN, FREQUENCIES, 1) for scene in (original, edited))
        maximum = 0.0
        for (m, fits), (n, other) in zip(a, b, strict=True):
            np.testing.assert_array_equal(m[INDEX], n[INDEX])
            for (first, info), (second, expected) in zip(fits, other, strict=True):
                np.testing.assert_array_equal(first[INDEX], second[INDEX])
                assert info == expected
                maximum = max(maximum, float(np.max(abs(first[INDEX] - PHASES[1]))))
        assert maximum < 1e-7
        phase, eligible = model.middle_phases(a, green, .0001, 1e-7)["bilateral"]
        assert eligible[INDEX]
        values = [_signed_evidence([_sites(scene, *ORIGIN, 160, *s) for s in _SITES], phase, FREQUENCIES, 1, green,
                                   .0001, 1e-7)[INDEX] for scene in (original, edited)]
        assert values[0] > 5 and values[1] < -5
        test.append({"pattern": layout, "greens": green, "score_before_after": values,
                     "maximum_coefficient_error": maximum, "station_donors_bit_identical": True})
    write_json(model.OUT / "support-audit.json", {"driver": reference(Path(__file__)),
              "operator": reference(model.__file__), "frequency": FREQUENCIES.tolist(), "origin": ORIGIN,
              "changed_only_one_delivered_station": STATION, "rows": test})


if __name__ == "__main__":
    main()
