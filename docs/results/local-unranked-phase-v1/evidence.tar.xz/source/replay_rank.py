"""Evaluate two direction checks with a fixed calibration budget."""

from collections import Counter
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import unranked_phase as model
from unranked_phase import OUT, replay
from reduce_support import ABS, ADDED, FALSE, GAP, METRICS, QUIET, RESPONSE, compare, means
import replay_exterior_support as scoring

GAP_BUDGET = 0.080
FALSE_BUDGET = 0.025
QUIET_PEAK_BUDGET = 0.6


def load(kind):
    source = reference(OUT / kind / "parent" / "result.json")
    parent = read_json(checked(source))
    read = read_json(checked(parent["inputs"]))
    plan = read_json(checked(read["plan"]))
    x, y, w, h = plan["query"]
    local = replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    rows = []
    for fixture, entity in zip(plan["sources"], parent["records"], strict=True):
        assert fixture["id"] == entity["id"]
        draws = []
        for stream in entity["streams"]:
            data = replay.arrays(stream["data"])
            pred = np.load(checked(stream["outputs"]["local50k"]), allow_pickle=False)
            result = scoring.assess(
                fixture,
                plan["noise"],
                pred,
                data,
                data["scene_packed"].copy(),
                cut,
                roi,
                data["sharp_target"],
            )
            draws.append(
                result
                | {"input": stream["data"], "outputs": stream["outputs"], "draw": stream["draw"]}
            )
        rows.append(
            {
                "id": fixture["id"],
                "fixture": fixture,
                "family": fixture["geometry"]["family"],
                "draws": draws,
            }
        )
        if len(rows) % 8 == 0:
            print("Measured", kind, len(rows), flush=True)
    return rows, source, read["plan"]


def quiet(rows, path):
    name, weight = path
    samples = [replay.metrics_at(d["powers"][name], weight) for row in rows for d in row["draws"]]
    return {
        k: {"peak": max(x[k] for x in samples), "count": sum(x[k] > 0 for x in samples)}
        for k in QUIET
    }


def quiet_delta(rows, arm, weight):
    draws = [d["powers"][arm] for row in rows for d in row["draws"]]
    return {key: weight * max(np.sqrt(max(d[key][2], 0)) for d in draws) for key in QUIET}


def lock(rows):
    base = means(rows, ("near", 1))
    detail = []
    original_absolute_passes = []
    for method, cut, key in model.OPTIONS:
        score = means(rows, (key, 1))
        original_absolute_passes.append(
            score[ADDED] <= GAP_BUDGET
            and score[FALSE] <= base[FALSE] + FALSE_BUDGET
            and max(v["peak"] for v in quiet(rows, (key, 1)).values()) <= QUIET_PEAK_BUDGET
        )
        quiet_peak = quiet_delta(rows, key, 1)
        viable = []
        for weight in np.linspace(0.05, 1, 20).tolist():
            scores = means(rows, (key, weight))
            if (
                scores[ADDED] <= GAP_BUDGET
                and scores[FALSE] <= base[FALSE] + FALSE_BUDGET
                and max(quiet_peak.values()) * weight <= QUIET_PEAK_BUDGET
            ):
                viable.append({"weight": weight, "means": scores})
        choice = (
            max(viable, key=lambda t: (t["means"][RESPONSE], -t["means"][ADDED]))
            if viable
            else None
        )
        detail.append(
            {
                "method": method,
                "cut": cut,
                "arm": key,
                "unscaled": score,
                "peak_added_quiet_DN16_at_full": quiet_peak,
                "calibrated": choice,
            }
        )
    winners = {}
    for method in model.METHODS:
        available = [x for x in detail if x["method"] == method and x["calibrated"] is not None]
        winners[method] = (
            max(
                available,
                key=lambda row: (
                    row["calibrated"]["means"][RESPONSE],
                    -row["calibrated"]["means"][ADDED],
                ),
            )
            if available
            else None
        )
    eligible = [p for p in winners.values() if p is not None]
    return {
        "caps": {
            "added_gap_DN16": GAP_BUDGET,
            "extra_false_projection_DN16": FALSE_BUDGET,
            "quiet_peak_from_near_DN16": QUIET_PEAK_BUDGET,
        },
        "original_absolute_quiet_arms_passing": sum(original_absolute_passes),
        "near_quiet_from_parent": quiet(rows, ("near", 1)),
        "choices": detail,
        "best_each": winners,
        "primary": max(
            eligible,
            key=lambda row: (
                row["calibrated"]["means"][RESPONSE],
                -row["calibrated"]["means"][ADDED],
            ),
        ),
        "anchor": base,
    }


def states(rows):
    return {
        str(i): dict(Counter(d["evidence"][i]["state"] for row in rows for d in row["draws"]))
        for i in range(6)
    }


def summary(rows, policy):
    choices = {
        "near": ("near", 1),
        "no_phase_check": ("unverified", 1),
        "primary": (policy["primary"]["arm"], policy["primary"]["calibrated"]["weight"]),
    }
    choices |= {
        method: (result["arm"], result["calibrated"]["weight"])
        for method, result in policy["best_each"].items()
        if result is not None
    }
    scores = {key: means(rows, name) for key, name in choices.items()}
    status = states(rows)
    ambiguous = sum(d["evidence"][0]["state"] == "ambiguous rank" for r in rows for d in r["draws"])
    denominator = scores["no_phase_check"][RESPONSE] - scores["near"][RESPONSE]
    dose = (
        (scores["primary"][RESPONSE] - scores["near"][RESPONSE]) / denominator
        if denominator
        else None
    )
    matched = None
    if dose is not None and 0 <= dose <= 1:
        scaled = ("unverified", dose)
        matched = {
            "scale": dose,
            "means": means(rows, scaled),
            "paired_primary": compare(rows, choices["primary"], scaled),
        }
    return {
        "means": scores,
        "states": status,
        "ambiguous_intact_draws": ambiguous,
        "quiet": {key: quiet(rows, name) for key, name in choices.items()},
        "peak_added_quiet_from_near": {
            key: quiet_delta(rows, *name) for key, name in choices.items()
        },
        "vs_near": {
            key: compare(rows, name, choices["near"])
            for key, name in choices.items()
            if key != "near"
        },
        "equal_response_no_phase_check": matched,
    }


def main(kind):
    torch.set_num_threads(2)
    start = monotonic()
    scoring.model = model
    bindings = {"driver": reference(Path(__file__)), "operator": reference(model.__file__)}
    data, source, plan = load(kind)
    if kind == "calibration":
        policy = lock(data)
        receipt = bindings | {"policy": policy}
    else:
        calibration = reference(OUT / "calibration.json")
        locked = read_json(checked(calibration))
        assert locked["operator"] == bindings["operator"]
        policy = locked["policy"]
        receipt = bindings | {"calibration": calibration}
    results = summary(data, policy)
    print(
        "locked",
        policy["primary"]["arm"],
        "ambiguous",
        results["ambiguous_intact_draws"],
        flush=True,
    )
    for key, score in results["means"].items():
        print(key, {m: round(score[m], 6) for m in (RESPONSE, ABS, GAP, FALSE, ADDED)}, flush=True)
    write_json(
        OUT / f"{kind}.json",
        receipt
        | {
            "source": source,
            "plan": plan,
            "rows": data,
            "summary": results,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
