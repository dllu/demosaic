"""Report paired uncertainty, the calibration curve, and native review bindings."""

from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import unranked_phase as model
from replay_rank import ADDED, FALSE, RESPONSE, compare, means

OUT = model.OUT


def arm_table(policy):
    result = {"near": ("near", 1), "no_phase_check": ("unverified", 1)}
    for label, option in policy["best_each"].items():
        if option is not None:
            result[label] = (option["arm"], option["calibrated"]["weight"])
    main = policy["primary"]
    return result | {"primary": (main["arm"], main["calibrated"]["weight"])}


def cohort(rows, name):
    if name == "all":
        return rows
    return [
        row | {"draws": subset}
        for row in rows
        if (subset := [d for d in row["draws"] if d["evidence"][0]["state"] == name])
    ]


def chart(rows, policy, data):
    start = means(rows, ("near", 1))[RESPONSE]
    styles = {
        "collar": "#487f99",
        "ring": "#00715b",
        "tangent": "#995588",
        "bilateral": "#a16825",
        "no_phase_check": "#7e8494",
    }
    names = {
        "collar": "Outer crop collar",
        "ring": "64px local ring",
        "tangent": "Direction-weighted ring",
        "bilateral": "Two-sided agreement",
        "no_phase_check": "No phase check",
    }
    fig, axes = plt.subplots(1, 2, figsize=(10.1, 4.1), sharey=True, layout="constrained")
    false_baseline = means(rows, ("near", 1))[FALSE]
    for ax, xkey, baseline in zip(axes, (ADDED, FALSE), (0, false_baseline), strict=True):
        for key, (arm, weight) in arm_table(policy).items():
            if key in ("near", "primary"):
                continue
            curve = [means(rows, (arm, float(scale))) for scale in np.linspace(0, 1, 26)]
            xs = [s[xkey] - baseline for s in curve]
            ys = [s[RESPONSE] - start for s in curve]
            ax.plot(
                xs,
                ys,
                color=styles[key],
                label=names[key],
                linewidth=2,
                linestyle="--" if key == "no_phase_check" else "-",
            )
            if key != "no_phase_check":
                chosen = data["means"][key]
                ax.scatter(
                    chosen[xkey] - baseline,
                    chosen[RESPONSE] - start,
                    color=styles[key],
                    s=42,
                    zorder=3,
                    edgecolor="white",
                )
        main = data["means"]["primary"]
        ax.scatter(
            main[xkey] - baseline,
            main[RESPONSE] - start,
            marker="o",
            s=115,
            facecolor="none",
            edgecolor="#293238",
            linewidth=1.8,
            zorder=4,
            label="Locked choice",
        )
        ax.grid(lw=0.7, alpha=0.3)
    axes[0].set(
        xlabel="All added luma in exact gaps (DN16)",
        ylabel="Added second-direction response (percentage points)",
    )
    axes[1].set(xlabel="Change in false projection along absent wire (DN16)")
    axes[1].legend(frameon=False, loc="best", fontsize=8)
    fig.suptitle("32 new photos with similar wire amplitudes", fontsize=13)
    image = OUT / "rank-independent-tradeoff.png"
    fig.savefig(image, dpi=155)
    plt.close(fig)
    return reference(image)


def main():
    files = {
        key: reference(OUT / f"{key}.json")
        for key in (
            "calibration",
            "fresh",
            "support-audit",
            "natural-replay",
            "board-camera",
            "board-exact",
            "gap-attribution",
        )
    }
    docs = {key: read_json(checked(file)) for key, file in files.items()}
    policy = docs["calibration"]["policy"]
    final = docs["fresh"]
    rows = final["rows"]
    arms = arm_table(policy)
    slices = {}
    for label in ("all", "ambiguous rank", "ranked"):
        panel = cohort(rows, label)
        if not panel:
            continue
        diffs = []
        for r in panel:
            for d in r["draws"]:
                base = d["nominal"]["near"][RESPONSE]
                output = model.replay.metrics_at(
                    d["powers"][arms["primary"][0]], arms["primary"][1]
                )
                diffs.append(output[RESPONSE] - base)
        slices[label] = {
            "source_count": len(panel),
            "draw_count": sum(len(r["draws"]) for r in panel),
            "percentile_draw_response_change": np.quantile(diffs, [0, 0.10, 0.5, 0.9, 1]).tolist(),
            "primary_vs_near": compare(panel, arms["primary"], arms["near"]),
            "geometry_flags": dict(Counter(r["family"] for r in panel)),
        }
    photo_plan = read_json(checked(final["plan"]))
    capture = read_json(checked(final["source"]))
    checksums = {key: value for key, value in capture["weights"].items()}
    summary = {
        "driver": reference(Path(__file__)),
        "sources": files,
        "policy": policy,
        "calibration": docs["calibration"]["summary"],
        "confirmation": final["summary"],
        "cohorts": slices,
        "training_photo_visits_audited": photo_plan["training_photo_visits_audited"],
        "checkpoints": checksums,
        "noise": photo_plan["noise"],
        "optical_sigma": photo_plan["sigma"],
        "natural": docs["natural-replay"]["summary"],
        "gap_attribution": {
            k: docs["gap-attribution"][k]
            for k in ("means", "draws_changed", "worst_gap", "worst_flat")
        },
        "standing": {
            r["id"]: r["delta"]["ring_phase"] | {"rank": r["support"]}
            for r in docs["board-camera"]["data"]["rows"]
        },
        "exact": [
            {k: b[k] for k in ("id", "draw", "response_gain_points", "added_gap_DN16")}
            for b in docs["board-exact"]["data"]["boards"]
        ],
    }
    image = chart(rows, policy, final["summary"])
    summary["chart"] = image
    write_json(OUT / "summary.json", summary)


if __name__ == "__main__":
    main()
