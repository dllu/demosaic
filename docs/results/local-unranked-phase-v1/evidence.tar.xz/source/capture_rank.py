"""Capture close-amplitude wire pairs from separate calibration and confirmation photos."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.parent / "local-weak-contrast-v1"))
import capture_contrast as run

PREVIOUS = OUT.parent / "local-near-phase-v1"
CALIBRATION = OUT.parent / "local-weak-contrast-v1" / "fresh" / "plan.json"
SEEDS = {"calibration": 202611200549, "fresh": 202611200559}


def plan_for(kind):
    seed = SEEDS[kind]
    if kind == "calibration":
        previous = reference(CALIBRATION)
        plan = read_json(checked(previous))
    else:
        previous = reference(PREVIOUS / "fresh" / "plan.json")
        run.OUT = OUT / "fresh"
        run.SEED = seed
        run.COUNT = 32
        run.prior.EXCLUSIONS += (CALIBRATION, Path(previous["path"]))
        plan = run.freeze()
    for case in plan["sources"]:
        i = case["index"]
        rng = np.random.default_rng(scene_seed(seed, i, "close-amplitude"))
        geometry = case["geometry"]
        ratio = float(rng.uniform(.88, 1.32))
        geometry["unscaled_second_to_first"] = ratio
        geometry["strength"][1] = ratio * geometry["strength"][0]
        case["id"] = f"unranked-{kind}-{i:02d}"
    return plan | {
        "driver": reference(__file__), "earlier_experiment": previous, "seed": seed,
        "hypothesis": "An independently measured phase can validate both directions when crop-wide rank is ambiguous.",
        "primary": "Measure second-direction response, the continuing first direction, and gap and quiet-region error.",
    }


def main(kind):
    torch.set_num_threads(2)
    run.prior.earlier.SEED = SEEDS[kind]
    start = monotonic()
    dest = OUT / kind
    (dest / "inputs").mkdir(exist_ok=True, parents=True)
    plan_path = dest / "plan.json"
    if not plan_path.exists():
        write_json(plan_path, plan_for(kind))
    plan = read_json(plan_path)
    assert plan["driver"] == reference(__file__)
    inputs_path = dest / "inputs.json"
    if not inputs_path.exists():
        observations = []
        for case in plan["sources"]:
            observations.append(run.prior.earlier.capture(case, plan["noise"], dest / "inputs"))
            if len(observations) % 8 == 0:
                print("Captured", kind, len(observations), flush=True)
        write_json(inputs_path, {"driver": reference(__file__), "plan": reference(plan_path),
                                 "observations": observations, "seconds": monotonic() - start})
    run.prior.parents.OUT = dest
    if not (dest / "parent" / "result.json").exists():
        run.prior.parents.main()


if __name__ == "__main__":
    main(sys.argv[1])
