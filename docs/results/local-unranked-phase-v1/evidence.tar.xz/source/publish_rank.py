"""Publish native boards and bind the frozen experiment receipts and sources."""

from hashlib import file_digest
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import unranked_phase as model

ROOT = Path.cwd()
OUT = model.OUT
ASSETS = ROOT / "docs" / "assets" / model.HERE.name
RESULTS = ROOT / "docs" / "results" / model.HERE.name
FILES = (
    "calibration.json",
    "fresh.json",
    "support-audit.json",
    "natural-replay.json",
    "board-camera.json",
    "board-exact.json",
    "gap-attribution.json",
    "summary.json",
    "calibration/plan.json",
    "calibration/inputs.json",
    "calibration/parent/result.json",
    "fresh/plan.json",
    "fresh/inputs.json",
    "fresh/parent/result.json",
    "preliminary/absolute-quiet-constraint.log",
)
BASE = (
    "src/demosaic/mesh_carrier_fit.py",
    "src/demosaic/_mesh_weak_posterior.py",
    "src/demosaic/_mesh_weak_phase.py",
    "src/demosaic/_mesh_near_phase.py",
    "src/demosaic/_mesh_presence.py",
    "src/demosaic/_mesh_pooled.py",
    "tests/test_mesh_carrier_fit.py",
)
REUSE = (
    "local-nested-support-v1/freeze_nested.py",
    "local-nested-support-v1/replay_nested_parents.py",
    "local-weak-contrast-v1/capture_contrast.py",
    "local-weak-support-v1/replay_exterior_support.py",
    "local-weak-support-v1/reduce_support.py",
    "local-bayer-presence-v1/review_presence.py",
    "scene-patch-width-v1/evaluate_wide.py",
    "green-covariance-refit-v1/wire_math.py",
)


def local(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def copy_image(binding):
    source = checked(binding)
    path = ASSETS / source.name
    shutil.copyfile(source, path)
    result = local(path)
    assert result["sha256"] == binding["sha256"]
    return result


def render(board):
    result = copy_image(board["image"])
    with Image.open(ROOT / result["path"]) as image:
        for panel in board["panels"]:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160) and min(x, y) >= 0
            assert x + w <= image.width and y + h <= image.height
    return board | {"image": result}


def main():
    refs = {file: reference(OUT / file) for file in FILES}
    records = {key: read_json(checked(ref)) for key, ref in refs.items() if key.endswith(".json")}
    for row in records.values():
        for key in ("driver", "operator"):
            if key in row:
                checked(row[key])
    expected = refs["calibration.json"]
    for item in ("fresh", "natural-replay", "board-camera", "board-exact", "gap-attribution"):
        assert records[f"{item}.json"]["calibration"] == expected
    assert records["board-exact.json"]["data"]["source"] == refs["fresh.json"]
    assert records["gap-attribution.json"]["source"] == refs["fresh.json"]
    for group in ("calibration", "fresh"):
        parent = records[f"{group}/parent/result.json"]
        inputs = records[f"{group}/inputs.json"]
        plan = records[f"{group}/plan.json"]
        assert records[f"{group}.json"]["source"] == refs[f"{group}/parent/result.json"]
        assert parent["inputs"] == refs[f"{group}/inputs.json"]
        assert inputs["plan"] == refs[f"{group}/plan.json"]
        for spec in parent["weights"].values():
            checked(spec)
        for row, predictions in zip(inputs["observations"], parent["records"], strict=True):
            assert row["id"] == predictions["id"]
            for raw, draw in zip(row["streams"], predictions["streams"], strict=True):
                assert raw["data"] == draw["data"] and raw["draw"] == draw["draw"]
                checked(raw["data"])
                for reference_ in draw["outputs"].values():
                    checked(reference_)
        assert len(plan["sources"]) == (48 if group == "calibration" else 32)
    marker_sets = [
        {
            row["source"][key]
            for row in records[f"{group}/plan.json"]["sources"]
            for key in ("id", "cache_sha256")
        }
        for group in ("calibration", "fresh")
    ]
    assert marker_sets[0].isdisjoint(marker_sets[1])

    ASSETS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    evidence = {f"receipts/{key}": ref for key, ref in refs.items()}
    evidence.update({f"source/{p.name}": reference(p) for p in sorted(model.HERE.glob("*.py"))})
    evidence.update({f"reused/{name}": reference(model.HERE.parent / name) for name in REUSE})
    evidence.update({name: reference(ROOT / name) for name in BASE})
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for path, ref in evidence.items():
            tar.add(checked(ref), arcname=path, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == evidence.keys()
        for name, ref in evidence.items():
            with tar.extractfile(name) as handle:
                assert file_digest(handle, "sha256").hexdigest() == ref["sha256"]

    camera = [
        row | {"native": [render(board) for board in row["native"]]}
        for row in records["board-camera.json"]["data"]["rows"]
    ]
    exact = [
        row | {"board": render(row["board"]), "triplet": render(row["triplet"])}
        for row in records["board-exact.json"]["data"]["boards"]
    ]
    assert sum(len(row["native"]) for row in camera) == 12 and len(exact) == 2
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {"camera": camera, "exact": exact, "chart": copy_image(records["summary.json"]["chart"])},
    )
    summary = RESULTS / "summary.json"
    shutil.copyfile(checked(refs["summary.json"]), summary)
    write_json(
        RESULTS / "publication.json",
        {
            "parent_revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip(),
            "manifest": local(manifest),
            "summary": local(summary),
            "archive": local(archive),
            "receipt_bindings": refs,
            "archive_members": evidence,
            "prior_publication": local(ROOT / "docs/results/local-near-phase-v1/publication.json"),
            "native_boards_viewed": 12,
            "native_triplets_viewed": 2,
            "new_weights": None,
            "packaged_mode": None,
        },
    )


if __name__ == "__main__":
    main()
