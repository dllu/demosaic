"""Render locked checks at fixed coordinates without resizing native pixels."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import unranked_phase as model
import review_near as review

view = review.view
LABELS = {
    "parent": "Local 50k",
    "nested": "Nearby phase",
    "ring_phase": "Independent phase",
    "lift": "No phase check",
}


def crop_set(
    parent,
    local,
    scene,
    colors,
    roi,
    peaks,
    profile,
    wb,
    matrix,
    policy,
    *,
    include_unverified=True,
):
    clearance = 16 if local == roi else 48
    values, trace = model.qualify(
        parent, local, scene, colors, roi, peaks, profile, wb, matrix, clearance=clearance
    )
    base = values["near"]
    dose = policy["primary"]["calibrated"]["weight"]
    primary = base + dose * (values[policy["primary"]["arm"]].astype(np.float64) - base)
    selected = {
        "parent": view.section(parent, *local),
        "nested": base,
        "ring_phase": primary.astype(base.dtype),
    }
    if include_unverified:
        selected["lift"] = values["unverified"]
    return selected, trace


def exact(policy, dest):
    source = reference(model.OUT / "fresh.json")
    data = read_json(checked(source))
    plan = read_json(checked(data["plan"]))
    x, y, _, _ = plan["query"]
    local = model.replay.ROI
    roi = (x + local[0], y + local[1], *local[2:])
    selected = []
    key = policy["primary"]["arm"]
    dose = policy["primary"]["calibrated"]["weight"]
    from replay_rank import ADDED, RESPONSE

    for geometry in ("contrast-step", "ellipse"):
        options = []
        for row in data["rows"]:
            if row["family"] != geometry:
                continue
            for d in row["draws"]:
                if d["evidence"][0]["state"] != "ambiguous rank":
                    continue
                baseline = d["nominal"]["near"]
                proposed = model.replay.metrics_at(d["powers"][key], dose)
                options.append(
                    (proposed[RESPONSE] - baseline[RESPONSE], proposed.get(ADDED), row, d)
                )
        selected.append(max(options, key=lambda a: a[0] if geometry == "contrast-step" else a[1]))
    boards = []
    for gain, gap, row, draw in selected:
        samples = model.replay.arrays(draw["input"])
        colors, wb, matrix = (samples[k] for k in ("colors", "wb", "matrix"))
        camera = {k: samples[k][None] for k in ("colors", "wb", "matrix")} | {
            "packed": samples["packed"][:1]
        }
        parent, v120 = (
            np.load(checked(draw["outputs"][k]), allow_pickle=False)[0]
            for k in ("local50k", "v120")
        )
        scene = samples["scene_packed"].copy()
        scene[:, y // 2 : (y + 256) // 2, x // 2 : (x + 256) // 2] = samples["packed"][0]
        directions = np.asarray(draw["actual_frequency"])
        chosen, trace = crop_set(
            parent, local, scene, colors, roi, directions, plan["noise"], wb, matrix, policy
        )
        frames = [noisy_malvar(camera)[0], v120]
        for value in chosen.values():
            frame = parent.copy()
            view.section(frame, *local)[:] = value
            frames.append(frame)
        frames.append(samples["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(LABELS[k] for k in chosen), "Exact GT"]
        boards.append(
            view.native_board(
                dest,
                row["id"],
                frames,
                camera,
                {
                    "input": draw["input"],
                    "fixture": row["fixture"],
                    "query": plan["query"],
                    "noise": plan["noise"],
                    "optical_sigma": plan["sigma"],
                    "draw": draw["draw"],
                    "weights": plan["checkpoints"],
                    "trace": trace,
                    "response_gain_points": gain,
                    "added_gap_DN16": gap,
                    "nomination": directions.tolist(),
                    "locked_delivery": policy["primary"],
                },
                labels=labels,
                triplet_indices=(0, labels.index("Independent phase"), len(labels) - 1),
            )
        )
    return {
        "source": source,
        "selection": "Largest response gain in contrast steps and largest added gap luma in ellipses, among ambiguous ranks",
        "boards": boards,
    }


def main(mode):
    torch.set_num_threads(2)
    source = reference(model.OUT / "calibration.json")
    policy = read_json(checked(source))["policy"]
    dest = model.OUT / "boards" / mode
    dest.mkdir(exist_ok=True, parents=True)
    if mode == "camera":
        view.arcs = lambda *args: crop_set(*args, include_unverified=False)
        view.NAMES = LABELS
        values = view.standing(policy, dest)
    else:
        values = exact(policy, dest)
    write_json(
        model.OUT / f"board-{mode}.json",
        {"driver": reference(Path(__file__)), "calibration": source, "data": values},
    )


if __name__ == "__main__":
    main(sys.argv[1])
