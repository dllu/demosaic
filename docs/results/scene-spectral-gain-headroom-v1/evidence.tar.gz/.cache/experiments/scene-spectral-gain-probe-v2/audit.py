"""Rebuild gains from archived basis fields and verify retained native panels."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-gain-probe-v2")


def cells(board):
    with Image.open(checked(board["image"])) as canvas:
        return {
            p["label"]: canvas.crop((x, y, x + w, y + h)).tobytes()
            for p in board["panels"]
            for x, y, w, h in (p["png_xywh"],)
        }


def kkt(g, gram, product):
    candidate = np.asarray(g)
    assert np.all((candidate >= 0) & (candidate <= 2))
    gradient = gram @ candidate - product
    violation = np.where(candidate == 0, np.minimum(gradient, 0), gradient)
    violation = np.where(candidate == 2, np.maximum(gradient, 0), violation)
    norm = max(np.linalg.norm(gram), np.linalg.norm(product), 1e-30)
    return float(np.max(np.abs(violation)) / norm)


def main():
    file = ROOT / "report/result.json"
    results = read_json(file)
    stage = read_json(checked(results["basis_stage"]))
    plan = read_json(checked(stage["plan"]))
    assert stage["target_reads"] == 0
    totals = defaultdict(list)
    real, max_reproduction = {}, 0.0
    for b in stage["rows"]:
        r = read_json(checked(b))
        base, main, entries = [
            np.load(checked(r[key]), allow_pickle=False) for key in ("parent", "learned", "basis")
        ]
        residual = main.astype(np.float64) - base
        discrepancy = np.abs(entries.astype(np.float64).sum(0) - residual)
        tolerance = 0.51 * np.abs(np.spacing(main)) + 4 * r["decomposition_max_abs"] + 1e-9
        assert np.all(discrepancy <= tolerance)
        maximum = float(discrepancy.max())
        max_reproduction = max(maximum, max_reproduction)
        if r["kind"] == "camera":
            real[r["id"]] = (base, entries)
            continue
        with np.load(checked(r["inputs"]), allow_pickle=False) as data:
            target = data["crop_target"].astype(np.float64) - base
        # List the columns explicitly here rather than invoking the report's
        # batched kernel. The same division uses the full squared parent error.
        columns = [values.ravel().astype(np.float64) for values in entries]
        target = target.ravel()
        scale = max(float(np.dot(target, target)), target.size / 65535**2)
        grams = np.array([[np.dot(a, b) for b in columns] for a in columns]) / scale
        product = np.array([np.dot(a, target) for a in columns]) / scale
        totals[r["source_id"]].append((grams, product))
    assert len(totals) == 64 and len(real) == 6
    assert all(len(v) == 2 for v in totals.values())
    errors = []
    for title, held_out in results["leave_source_out_calibration"].items():
        remaining = [v for source, gs in totals.items() if source != title for v in gs]
        errors.append(kkt(held_out, *[sum(item[k] for item in remaining) for k in range(2)]))
    all_cases = [p for entries in totals.values() for p in entries]
    calib = results["camera_calibration"]
    errors.append(kkt(calib, *[sum(item[k] for item in all_cases) for k in range(2)]))
    assert len(errors) == 65 and max(errors) < 2e-12
    original = {row["id"]: row for row in read_json(checked(plan["native_pilot"]))["boards"]}
    matched, camera_crops, max_delta = 0, 0, 0.0
    for b in results["native"]:
        a, c = cells(original[b["id"]]), cells(b)
        for label in a.keys() & c.keys():
            assert a[label] == c[label]
            matched += 1
        if b["observation"] not in real:
            continue
        assert "GT-aided gains" not in c
        base, entries = real[b["observation"]]
        x, y, w, h = b["case"]["ROI_xywh"]
        i = b["case"]["crop_index"]
        first, second = entries[:, i, :, y : y + h, x : x + w].astype(np.float64)
        deltas = {"long-only": first, "cross-fit": first * calib[0] + second * calib[1]}
        for method, change in deltas.items():
            value = float(np.sqrt((change**2).mean()) * 65535)
            max_delta = max(max_delta, abs(value - b["changes_DN16"][method]))
        camera_crops += 1
    assert len(results["native"]) == 16 and matched == 72 and camera_crops == 8
    assert max_delta < 1e-9
    write_json(
        ROOT / "audit.json",
        {
            "driver": reference(__file__),
            "report": reference(file),
            "status": "passed",
            "independent_gain_fits": 65,
            "maximum_relative_KKT_violation": max(errors),
            "reconstruction_max_error": max_reproduction,
            "retained_native_cells": matched,
            "camera_crops": camera_crops,
            "maximum_camera_RMS_error": max_delta,
        },
    )


if __name__ == "__main__":
    main()
