"""Source-level reductions and checks for the frozen two-band comparison."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-gain-probe-v2")
DN = 65535


def run():
    path = ROOT / "report/result.json"
    result = read_json(path)
    receipt = read_json(checked(result["basis_stage"]))
    assert receipt["replayed_outputs_exact"] == 134 and receipt["target_reads"] == 0
    output = {"report": reference(path), "summary": {}, "audit": {}}
    masks = (("weak", 256), ("quiet", 256), ("long", 1024))
    for prior in ("shadows", "iso12800-prior"):
        sources = [r for r in result["per_case"] if r["id"].split("-", 2)[-1] == prior]
        assert len(sources) == 64 and len({r["source"] for r in sources}) == 64
        methods = sources[0]["by_method"]
        prior_result = {}
        for method in methods:
            items = [r["by_method"][method] for r in sources]
            entry = {"PSNR_dB": float(np.mean([r["crop_PSNR_dB"] for r in items]))}
            for name, pixels in masks:
                counts = np.array([r[f"{name}_blocks"] for r in items])
                sums = np.array([r[f"{name}_error_sq"] for r in items])
                used = counts > 0
                scores = np.sqrt(sums[used] / (counts[used] * pixels)) * DN
                entry[name] = {
                    "sources": int(used.sum()),
                    "blocks": int(counts.sum()),
                    "RMS_DN16": float(scores.mean()),
                }
                if name == "weak":
                    gain = [
                        r["weak_signed_cross"] / r["weak_target_sq"]
                        for r in items
                        if r["weak_blocks"]
                    ]
                    entry[name]["signed_gain"] = float(np.mean(gain))
            prior_result[method] = entry
        local = [
            np.sqrt(
                r["local_weak_oracle_error_sq"] / (256 * r["by_method"]["parent"]["weak_blocks"])
            )
            * DN
            for r in sources
            if r["by_method"]["parent"]["weak_blocks"]
        ]
        gains = np.concatenate([r["weak_band_oracle_gains"] for r in sources], axis=0)
        target = np.array([r["by_method"]["weak-band-oracle"]["weak_error_sq"] for r in sources])
        ref = np.array([r["by_method"]["learned"]["weak_error_sq"] for r in sources])
        block = np.array([r["local_weak_oracle_error_sq"] for r in sources])
        violation = max(float(np.max(target - ref)), float(np.max(block - target)))
        assert violation < 1e-7
        prior_result["local_weak_oracle_RMS_DN16"] = float(np.mean(local))
        prior_result["weak_oracle_gains_percentiles"] = np.percentile(
            gains, (0, 25, 50, 75, 100), axis=0
        ).tolist()
        output["audit"][prior] = {"maximum_higher_objective_violation": max(0.0, violation)}
        output["summary"][prior] = prior_result
        for name in methods:
            z = prior_result[name]
            print(
                prior,
                name,
                z["PSNR_dB"],
                z["weak"]["RMS_DN16"],
                z["long"]["RMS_DN16"],
                z["quiet"]["RMS_DN16"],
                z["weak"]["signed_gain"],
            )
        print(prior, "local weak-band oracle", prior_result["local_weak_oracle_RMS_DN16"])
    output["camera_gains"] = result["camera_calibration"]
    loo = np.asarray(list(result["leave_source_out_calibration"].values()))
    assert loo.shape == (64, 2)
    output["LOO_range"] = np.stack([loo.min(0), loo.max(0)]).tolist()
    output["real"] = [
        {"id": r["id"], **r["changes_DN16"]}
        for r in result["native"]
        if not r["id"].startswith("development-")
    ]
    write_json(ROOT / "summary.json", output)
    print("camera", output["camera_gains"], "range", output["LOO_range"])


if __name__ == "__main__":
    run()
