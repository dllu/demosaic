"""Publish source-bound metrics and fixed native comparisons."""

import tarfile
from pathlib import Path
from shutil import copyfile

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-gain-probe-v2")
DEST = Path("docs/results/scene-spectral-gain-headroom-v1")
IMAGES = Path("docs/images/scene-spectral-gain-headroom-v1")
TRIPLETS = {"development-0-iso12800-prior-crop1", "development-1-shadows-crop0"}


def triplet(board):
    labels = ("Noisy (Malvar)", "Calibrated gains", "Exact GT")
    coords = {p["label"]: p["png_xywh"] for p in board["panels"]}
    new = Image.new("RGB", (512, 192), "#eee")
    draw = ImageDraw.Draw(new)
    original = Image.open(checked(board["image"]))
    entries = []
    for i, name in enumerate(labels):
        x, y, w, h = coords[name]
        assert (w, h) == (160, 160)
        cell = original.crop((x, y, x + w, y + h))
        tx = 8 + i * 168
        new.paste(cell, (tx, 24))
        draw.text((tx, 5), name, fill="black")
        entries.append((tx, cell))
    output = IMAGES / (board["id"] + "-triplet.png")
    new.save(output)
    with Image.open(output) as saved:
        for tx, cell in entries:
            np.testing.assert_array_equal(cell, saved.crop((tx, 24, tx + 160, 184)))
    return reference(output)


def run():
    doc = ROOT / "report/result.json"
    report = read_json(doc)
    basis = read_json(checked(report["basis_stage"]))
    audit = read_json(ROOT / "audit.json")
    assert audit["status"] == "passed" and audit["report"] == reference(doc)
    observation = read_json(ROOT / "viewing.json")
    assert observation["report"] == reference(doc)
    viewed = {n["id"]: n for n in observation["notes"]}
    assert len(report["native"]) == len(viewed) == 16
    DEST.mkdir()
    IMAGES.mkdir()
    published = []
    for b in report["native"]:
        data = {**b, "note": viewed[b["id"]]["note"]}
        assert b["image"] == viewed[b["id"]]["image"]
        original = checked(b["image"])
        target = IMAGES / original.name
        copyfile(original, target)
        data["published"] = reference(target)
        assert data["published"]["sha256"] == b["image"]["sha256"]
        if b["id"] in TRIPLETS:
            data["triplet"] = triplet(b)
        published.append(data)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "viewing": reference(ROOT / "viewing.json"),
            "model": basis["checkpoint"],
            "report": reference(doc),
            "native": published,
        },
    )
    evidence = [
        ROOT / name
        for name in (
            "plan.json",
            "qualification/result.json",
            "qualification.log",
            "basis/result.json",
            "basis.log",
            "report/result.json",
            "report.log",
            "summary.json",
            "summary.log",
            "summarize.py",
            "audit.json",
            "audit.py",
            "relax.py",
            "relaxed.log",
            "relaxed.json",
            "solver_check.py",
            "solver.log",
            "viewing.json",
            "publish.py",
        )
    ]
    evidence += [checked(record) for record in basis["rows"]]
    evidence += sorted((ROOT / "work/scripts").glob("*.py"))
    evidence += [
        ROOT / "work/src/demosaic" / n
        for n in (
            "scene_spectral_detail.py",
            "late_spectral_detail.py",
            "scene_restoration.py",
            "cfa.py",
        )
    ]
    evidence = [p.relative_to(Path.cwd()) if p.is_absolute() else p for p in evidence]
    archive = DEST / "evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for target in evidence:
            tar.add(target, arcname=target)
    for name in ("summary.json", "audit.json", "relaxed.json", "viewing.json"):
        copyfile(ROOT / name, DEST / name)
    write_json(
        DEST / "publication.json",
        {
            "checkpoint": basis["checkpoint"],
            "archive": reference(archive),
            "manifest": reference(manifest),
            "members": [reference(p) for p in evidence],
            "scope": "No new training. Source-disjoint development calibration plus target-assisted diagnostics; both GFX families viewed.",
        },
    )


if __name__ == "__main__":
    run()
