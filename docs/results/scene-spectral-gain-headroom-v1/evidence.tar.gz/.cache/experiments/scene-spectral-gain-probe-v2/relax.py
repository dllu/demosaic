"""Measure the local weak-band cost after removing the gain cap."""

from pathlib import Path

import numpy as np
from report_full_faint_photo_panel import band, original_masks
from report_scene_spectral_gains import arrays, luma, normal

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-spectral-gain-probe-v2")


def oracle(design, desired):
    gram, product = normal(design, desired)
    complete = np.einsum("...ij,...j->...i", np.linalg.pinv(gram, hermitian=True), product)
    diagonal = np.diagonal(gram, axis1=-2, axis2=-1)
    fitted = np.divide(product, diagonal, out=np.zeros_like(product), where=diagonal > 0)
    alternatives = [
        np.where((complete >= 0).all(-1, keepdims=True), complete, 0),
        np.stack((fitted[:, 0].clip(0), np.zeros(len(design))), axis=-1),
        np.stack((np.zeros(len(design)), fitted[:, 1].clip(0)), axis=-1),
    ]
    various = np.stack(alternatives, axis=1)
    numerator = desired[:, None] - np.einsum("...ni,...si->...sn", design, various)
    energy = (numerator**2).sum(-1)
    use = energy.argmin(1)
    positive = various[np.arange(len(design)), use]
    signed = desired - np.einsum("...ni,...i->...n", design, complete)
    return energy[np.arange(len(design)), use].sum(), np.sum(signed**2), positive


def main():
    report_path = ROOT / "report/result.json"
    report = read_json(report_path)
    rows = []
    basis = read_json(checked(report["basis_stage"]))
    old = {r["id"]: r for r in report["per_case"]}
    for item in basis["rows"]:
        saved = read_json(checked(item))
        if saved["kind"] != "development":
            continue
        context, base, _, measured = arrays(saved)
        mask = original_masks(context["target"], context)["0"]
        if not mask.any():
            continue
        desired = (band(luma(context["target"], context)) - band(luma(base, context)))[mask]
        design = np.stack([band(luma(p, context)) for p in measured], -1)[mask]
        pos, signed, gain = oracle(design, desired)
        bounded = old[saved["id"]]["local_weak_oracle_error_sq"]
        assert pos <= bounded + 1e-10 and signed <= pos + 1e-10
        rows.append(
            {
                "id": saved["id"],
                "blocks": int(mask.sum()),
                "gain_gt_2": int((gain > 2).any(-1).sum()),
                "positive_RMS_DN16": float(np.sqrt(pos / mask.sum() / 256) * 65535),
                "signed_RMS_DN16": float(np.sqrt(signed / mask.sum() / 256) * 65535),
            }
        )
    means = {}
    for key in ("shadows", "iso12800-prior"):
        valid = [r for r in rows if r["id"].split("-", 2)[-1] == key]
        means[key] = {
            "sources": len(valid),
            "blocks": sum(v["blocks"] for v in valid),
            "gain_gt_2": sum(v["gain_gt_2"] for v in valid),
            "positive_RMS_DN16": float(np.mean([v["positive_RMS_DN16"] for v in valid])),
            "signed_RMS_DN16": float(np.mean([v["signed_RMS_DN16"] for v in valid])),
        }
    write_json(
        ROOT / "relaxed.json",
        {
            "driver": reference(__file__),
            "source_report": reference(report_path),
            "source_balanced": means,
            "per_source": rows,
            "scope": "Post-analysis sensitivity to the gain bounds on the exact local fine-band targets, with no images rendered.",
        },
    )
    print(means)


if __name__ == "__main__":
    main()
