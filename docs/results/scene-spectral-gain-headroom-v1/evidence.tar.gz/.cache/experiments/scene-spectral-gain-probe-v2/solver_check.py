"""Check the bounded fit against an independent SciPy least-squares solver."""

import numpy as np
from scipy.optimize import lsq_linear

from report_scene_spectral_gains import apply, bounded_pair, normal

rng = np.random.default_rng(20261117)
basis = rng.normal(size=(128, 53, 2)) * 10 ** rng.uniform(-4, 4, size=(128, 1, 1))
basis[::7, :, 1] = basis[::7, :, 0]
basis[::16] = 0
actual = np.einsum("bni,bi->bn", basis, rng.normal(0.9, 2.3, (128, 2)))
actual += rng.normal(0, 0.1, actual.shape)
M, b = normal(basis, actual)
g = bounded_pair(M, b)
diff = []
for i, (matrix, truth) in enumerate(zip(basis, actual, strict=True)):
    answer = lsq_linear(matrix, truth, bounds=(0, 2), tol=1e-11, max_iter=500)
    error = np.linalg.norm(matrix @ g[i] - truth) ** 2
    expected = np.linalg.norm(matrix @ answer.x - truth) ** 2
    diff.append(abs(error - expected) / max(1, np.linalg.norm(truth) ** 2))
assert g.min() >= 0 and g.max() <= 2 and max(diff) < 2e-10
toy = np.zeros((2, 3, 3, 5, 6))
toy[0, ...] = 1
toy[1, ...] = 2
np.testing.assert_array_equal(apply(np.zeros((3, 3, 5, 6)), toy, np.tile([3, 4], (3, 1))), 11)
print(
    "128 bounded/rank-deficient fits and literal band rendering, max relative objective difference",
    max(diff),
)
