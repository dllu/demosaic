"""Freeze activity policies on separate natural and wire calibration scenes."""
from collections import defaultdict
from pathlib import Path
import sys

import numpy as np

from activity import ROOT, PRIOR, PRIOR_NAMES
from score_activity import GATES, GATE_MAP
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

GRID = np.linspace(0., 1.5, 151)


def table(rows, gate, scales):
    scales = np.asarray(scales)
    value = np.array([[1., g, g*g] for g in scales]).T
    scores = [r["results"][gate] for r in rows]
    columns = {}
    for measure in scores[0]:
        signed = measure in ("response","dip")
        group = np.asarray([r[measure] for r in scores if r[measure] is not None])
        if not len(group):
            continue
        if signed:
            a,b,c=group.sum(0)
            if c > 0:
                columns[measure] = 100*(a+b*scales)/c
        else:
            columns[measure] = np.sqrt(np.maximum(group @ value, 0.)).mean(0)
    return columns


def result(values,j):
    return {k:float(v[j]) for k,v in values.items()}


def natural_policies(rows):
    control=table(rows,"100k",[0])
    budget=control["flat"][0]
    targets={"flat_rms":float(budget),"response":float(control["response"][0])}
    summaries={}
    for gate,_,_,_ in GATES:
        t=table(rows,gate,GRID)
        free=(t["flat"] <= budget)
        match_response=(t["response"] >= targets["response"])
        if free.any():
            idx=int(np.argmax(np.where(free,t["response"],-np.inf)))
            best={"gate":gate,"gain":float(GRID[idx]),"scores":result(t,idx)}
        else:
            best=None
        if match_response.any():
            idx=int(np.argmin(np.where(match_response,t["flat"],np.inf)))
            at_response={"gate":gate,"gain":float(GRID[idx]),"scores":result(t,idx)}
        else:
            at_response=None
        summaries[gate]={"within_flat_budget":best,"at_reference_response":at_response,
                         "max_response":float(t["response"].max()),
                         "both_constraints":int(np.count_nonzero(free & match_response))}
    groups = {key: [g for g in summaries if g.startswith(key+"-")] for key in PRIOR_NAMES}
    selected={}
    for name,candidates in {"uniform":["uniform"],"supported-only":["supported-only"],**groups}.items():
        valid=[summaries[gate]["within_flat_budget"] for gate in candidates if summaries[gate]["within_flat_budget"]]
        if valid:
            selected[name]=max(valid,key=lambda x:x["scores"]["response"])
    return targets,summaries,selected


def wire_policies(rows):
    anchor=table(rows,"uniform",[1.])
    caps={measure:float(anchor[measure][0]) for measure in ("gap_added","flat_added")}
    prior={}
    for gate,_,_,_ in GATES:
        t=table(rows,gate,GRID)
        valid=(t["gap_added"]<=caps["gap_added"]) & (t["flat_added"]<=caps["flat_added"])
        idx=int(np.argmax(np.where(valid,t["response"],-np.inf)))
        prior[gate]={"gate":gate,"gain":float(GRID[idx]),"scores":result(t,idx)}
    candidates=[name for name,group,*_ in GATES if group in (0,1,3)]
    return caps,prior,max((prior[name] for name in candidates),key=lambda x:x["scores"]["response"])


def select():
    photo_ref=reference(ROOT/"calibration-photo.json")
    wire_ref=reference(ROOT/"calibration-wire.json")
    photo=read_json(checked(photo_ref))["rows"]
    wire=read_json(checked(wire_ref))["rows"]
    eligible=[row for row in wire if row["iso"]=="iso6400"]
    assert len(eligible)==24 and len(photo)==16
    targets, summary, selected=natural_policies(photo)
    cap, wire_table, wire_best=wire_policies(eligible)
    policies={"local20k":{"gate":"uniform","gain":0.},"Bayer-gated":{"gate":"uniform","gain":1.}}
    for name in ("uniform","supported-only","auto","cross","surround","joint"):
        if name in selected:
            policies["photo-"+name]={k:selected[name][k] for k in ("gate","gain")}
    policies["wire-local"]={k:wire_best[k] for k in ("gate","gain")}
    strong=max((v for name,v in selected.items() if name in ("auto","cross","joint")),
               key=lambda x:x["scores"]["response"])
    policies["photo-local"]=policies["photo-"+strong["gate"].split("-")[0]]
    write_json(ROOT/"selection.json",{"driver":reference(__file__),"calibration_photo":photo_ref,"calibration_wire":wire_ref,
        "scale_grid":{"min":0.,"max":1.5,"step":.01},"natural_calibration_target":targets,
        "natural_selection":selected,"natural_per_gate":summary,"wire_targets":cap,"wire_per_gate":wire_table,
        "policies":policies,
        "selection_rule":"Natural controls choose peak signed response at or below the Corpus 100k flat floor, by gate family. Wire-local chooses peak response under both original gap- and flat-addition caps among gates with local data. The photo-local candidates are the local auto, cross and joint statistics."})
    print("natural target",targets)
    for k,v in selected.items():
        print(k,v)
    print("wire cap",cap,"local best",wire_best)


if __name__=="__main__":
    select()
