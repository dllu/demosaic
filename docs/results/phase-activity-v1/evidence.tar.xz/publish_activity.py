"""Publish native image comparisons and byte-exact method and measurement receipts."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name


def read(name):
    return json.loads((ROOT/name).read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def reference(path):
    return {"path":str(path),"sha256":sha(path)}


def check(record, local=None):
    assert sha(Path(record["path"]) if local is None else local)==record["sha256"], record


def write(path, record):
    path.write_text(json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)+"\n")


def transfer(entry, directory):
    binding=entry["image"]
    original=Path(binding["path"])
    path=IMAGES/directory/original.name
    path.parent.mkdir(parents=True,exist_ok=True)
    check(binding)
    shutil.copyfile(original,path)
    check(binding,path)
    binding["path"]=path.relative_to(IMAGES).as_posix()
    with Image.open(path) as im:
        pieces={}
        for panel in entry["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160)
            assert 0<=x<=im.width-w and 0<=y<=im.height-h
            pieces[panel.get("label") or panel["name"]]=im.crop((x,y,x+w,y+h))
        assert len(pieces)==len(entry["panels"])
    return pieces


def review(checkpoint, policy):
    manifests={}
    for directory,n in (("exact",3),("standing",8)):
        data=read(directory+"/manifest.json")
        assert data["checkpoint"]==checkpoint and data["policy_selection"]==policy and len(data["rows"])==n
        check(data["driver"])
        for row in data["rows"]:
            frames=transfer(row["board"],directory)
            if directory=="standing":
                continue
            for trio in (row["triplet"],*row["other_triplets"].values()):
                pages=transfer(trio,directory)
                assert len(pages)==3
                for name,img in pages.items():
                    assert ImageChops.difference(img,frames[name]).getbbox() is None
        manifests[directory]=data
    manifests["native_image_review"]={
        "completed":True,"standing":8,"exact_comparisons":3,"triplets":9,
        "notes":"The sky stays visually smooth. Coarse fence contrast increases in the moderate local settings and fine building lines and foliage stay soft. The stricter photo gate removes most of the correction in the nominal fine cab. The moderate green cross-power gate keeps some old right diagonals, and the transferred profile still shows incomplete lines. No convincing newly resolved junctions were seen."
    }
    output=IMAGES/"manifest.json"
    write(output,manifests)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":sha(output)}


def archive(name, files):
    path=OUT/name
    names=sorted(files)
    with tarfile.open(path,"w:xz",preset=5)as bundle:
        for key in names:
            bundle.add(files[key],arcname=key,recursive=False)
    with tarfile.open(path)as bundle:
        assert bundle.getnames()==names
        for key in names:
            with bundle.extractfile(key)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==sha(files[key])
    return {"path":name,"sha256":sha(path),"entries":len(files)}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    selection=read("selection.json")
    controls=read("holdout-summary.json")
    check(selection["driver"])
    check(controls["driver"])
    check(controls["selection"])
    for stage,kind,size in (("calibration","photo",16),("calibration","wire",24),
                            ("holdout","photo",192),("holdout","wire",48)):
        receipt=read(f"{stage}-{kind}.json")
        check(receipt["driver"])
        check(receipt["activity"])
        assert len(receipt["rows"])==size
        if stage=="calibration":
            check(selection[f"calibration_{kind}"])
        else:
            check(controls["holdout_bindings"][kind])
    method=read("detector-audit.json")
    check(method["driver"])
    check(method["measurement"])
    native=read("standing/manifest.json")
    for key in ("checkpoint","training","parent","policy_selection"):
        check(native[key])
    upstream={name:ROOT.parent/"quiet-parent-phase-v1"/name for name in
            ("quiet_heads.py","calibrate_components.py","review_quiet.py","native_quiet.py","training/completed.json")}
    records=[
        "activity.py","score_activity.py","select_activity.py","render_activity.py",
        "audit_activity.py","summarize_activity.py","publish_activity.py",
        "calibration-photo.json","calibration-wire.json","selection.json","detector-audit.json",
        "holdout-photo.json","holdout-wire.json","holdout-summary.json",
        "exact/manifest.json","standing/manifest.json","tests.log"
    ]
    result=archive("evidence.tar.xz",{p:ROOT/p for p in records}|{f"upstream/{k}":v for k,v in upstream.items()})
    early={path.relative_to(ROOT).as_posix():path for directory in ("calibration-first","calibration-without-constant")
           for path in (ROOT/directory).iterdir()}
    early|={name:ROOT/name for name in ("initial-calibration.log","initial-score-activity.py","initial-tests.log")}
    first=archive("initial-calibration.tar.xz",early)
    write(OUT/"publication.json",{
        "experiment":ROOT.name,"parent":native["parent"],"frozen_crop_component":native["checkpoint"],
        "component_training_record":native["training"],"weights":"Frozen EMA for parent and correction. New gain policies fitted to calibration observations without changing any neural weights.",
        "scoped_numerical_evaluation_complete":True,"native_image_review_complete":True,
        "fixed_427_photo_and_camera_panels":"Outside this crop policy diagnostic",
        "evidence":result,"initial_calibration":first,
        "presentation":review(native["checkpoint"],native["policy_selection"]),
        "policy_selection_sha256":native["policy_selection"]["sha256"],
        "summary":{cohort:data["iso6400/"+("independent" if cohort=="photo" else "wire")]
                    for cohort,data in controls["summary"].items()}
    })
    print("Verified binders, archives, standing images and native triplet pixels.")


if __name__=="__main__":
    main()
