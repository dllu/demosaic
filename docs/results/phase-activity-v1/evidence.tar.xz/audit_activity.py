"""Check the activity estimators with controlled flats, ramps and waves."""
import time
import numpy as np
from scipy.stats import rankdata

from activity import ROOT, PRIOR_NAMES, fields, reliability
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json

def auc(a,b):
    ranks=rankdata(np.r_[a,b])
    return float((ranks[len(a):].sum()-len(b)*(len(b)+1)/2)/(len(a)*len(b)))

def pack(scene):
    return np.stack([scene[p//2::2,p%2::2] for p in range(4)])

def main():
    t0=time.monotonic()
    random=np.random.default_rng(381902)
    y,x=np.indices((256,256))
    luminance=.20
    ramp=.00048*(x-127.5)-.00026*(y-127.5)
    patterns=list(PATTERNS.values())
    profiles={"iso400":{"shot":8e-5,"read":2.56e-8},"iso6400":{"shot":.00128,"read":6.5536e-6}}
    rows={}
    index=(7*15)+7
    cases=("flat","ramp","wave-.002","wave-.006","wave-.02","edge-only")
    gates=(0,.15,.30)
    for label, noise in profiles.items():
        data={k:[] for k in cases}
        for i in range(160):
            layout=np.asarray(patterns[i%4])
            direction=((.125,.0625),(.03125,.15625),(.15625,-.09375))[(i//4)%3]
            wave=np.sin(2*np.pi*(direction[0]*y+direction[1]*x)+random.uniform(0,2*np.pi))
            clean={"flat":np.full((256,256),luminance),"ramp":luminance+ramp,
                   "edge-only":luminance+.04*(x-127.5 > (y-127.5)*.4)}
            clean|={case:luminance+float(case[5:])*wave for case in cases if case.startswith("wave")}
            for case,scene in clean.items():
                mean=pack(scene)
                sigma=np.sqrt(noise["shot"]*mean+noise["read"])
                raw=(np.rint((mean+sigma*random.normal(size=mean.shape))*65535)/65535).astype(np.float32)
                measured=fields(raw,layout,noise)
                data[case].append([measured[:,index],measured.max(axis=1)])
        a={case:np.asarray(crop) for case,crop in data.items()}
        scores={}
        for k,name in enumerate(PRIOR_NAMES):
            scores[name]={}
            for case in cases:
                values=a[case][:,0,k]
                scores[name][case]={"center_percentiles":np.quantile(values,[.1,.5,.9,.99]).tolist(),
                        "center_vs_flat_auc":auc(a["flat"][:,0,k],values),
                        "center_fraction_active":{str(lo):float(np.mean(reliability(values,lo,.30)>0))for lo in gates},
                        "any_tile_fraction_active":{str(lo):float(np.mean(a[case][:,1,k]>lo))for lo in gates}}
        rows[label]=scores
    write_json(ROOT/"detector-audit.json",{"driver":reference(__file__),"measurement":reference(ROOT/"activity.py"),
        "distribution":"160 Gaussian shot/read realizations per family and noise profile on a 16-bit ADC, all four Bayer layouts. One center window for the AUC. Max across 225 overlapping windows for the any-activation report.",
        "seed":381902,"seconds":time.monotonic()-t0,"cohorts":rows})
    print("Checked flat, ramp, edge and three sinusoid contrasts at both profiles.")
if __name__=="__main__":
    main()
