"""Freeze activity policies on separate natural and wire calibration scenes."""
import sys

import numpy as np

from activity import ROOT, PRIOR_NAMES
from score_activity import GATES
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

X,Y = np.meshgrid(np.linspace(0., 1.5, 151), np.linspace(0., .25, 26), indexing="ij")
GRID = np.column_stack((X.ravel(),Y.ravel()))


def table(rows, gate, scales):
    scales = np.asarray(scales)
    gain, quiet = scales.T
    value = np.stack([np.ones(len(scales)), gain, gain**2, quiet, gain*quiet, quiet**2])
    scores = [r["results"][gate] for r in rows]
    columns = {}
    for measure in scores[0]:
        group = np.asarray([r[measure] for r in scores if r[measure] is not None])
        if not len(group):
            continue
        if measure in ("response","dip"):
            a,b,c,power=group.sum(0)
            if power > 0:
                columns[measure] = 100*(a+b*gain+c*quiet)/power
        else:
            columns[measure] = np.sqrt(np.maximum(group @ value, 0.)).mean(0)
    return columns


def chosen(gate, values, index):
    gain, quiet = GRID[index]
    return {"gate":gate,"gain":float(gain),"quiet":float(quiet),
            "scores":{k:float(v[index]) for k,v in values.items()}}


def natural_policies(rows):
    control=table(rows,"100k",[(0.,0.)])
    budget=control["flat"][0]
    targets={"flat_rms":float(budget),"response":float(control["response"][0])}
    summaries={}
    for gate,_,_,_ in GATES:
        t=table(rows,gate,GRID)
        free=(t["flat"] <= budget)
        match_response=(t["response"] >= targets["response"])
        within=None
        if free.any():
            if (free & match_response).any():
                best=int(np.argmin(np.where(free & match_response,t["increment"],np.inf)))
            else:
                best=int(np.argmax(np.where(free,t["response"],-np.inf)))
            within=chosen(gate,t,best)
        half = table(rows,"uniform",[(0.,0.),(1.,0.)])["flat"].mean()
        below_half=(t["flat"]<=half) & (GRID[:,1]==0)
        best_half=chosen(gate,t,int(np.argmax(np.where(below_half,t["response"],-np.inf))))
        at_response=chosen(gate,t,int(np.argmin(np.where(match_response,t["flat"],np.inf)))) if match_response.any() else None
        summaries[gate]={"within_flat_budget":within,"at_reference_response":at_response,
                         "best_without_parent_attenuation":best_half,
                         "max_response":float(t["response"].max()),
                         "both_constraints":int(np.count_nonzero(free & match_response))}
    groups = {key: [g for g in summaries if g.startswith(key+"-")] for key in PRIOR_NAMES}
    selected={}
    nonatt={}
    for name,candidates in {"uniform":["uniform"],"supported-only":["supported-only"],
                            "constant-damp":["constant-damp"],**groups}.items():
        valid=[summaries[gate]["within_flat_budget"] for gate in candidates if summaries[gate]["within_flat_budget"]]
        if valid:
            selected[name]=max(valid,key=lambda x:x["scores"]["response"])
        nonatt[name]=max((summaries[gate]["best_without_parent_attenuation"] for gate in candidates),
                         key=lambda x:x["scores"]["response"])
    return targets,summaries,selected,nonatt


def wire_policies(rows):
    anchor=table(rows,"uniform",[(1.,0.)])
    caps={measure:float(anchor[measure][0]) for measure in ("gap_added","flat_added")}
    prior={}
    for gate,_,_,_ in GATES:
        t=table(rows,gate,GRID)
        valid=(t["gap_added"]<=caps["gap_added"]) & (t["flat_added"]<=caps["flat_added"])
        i=int(np.argmax(np.where(valid,t["response"],-np.inf)))
        prior[gate]=chosen(gate,t,i)
    candidates=[name for name,group,*_ in GATES if group in (0,1,3)]
    return caps,prior,max((prior[name] for name in candidates),key=lambda x:x["scores"]["response"])


def freeze():
    photo_ref=reference(ROOT/"calibration-photo.json")
    wire_ref=reference(ROOT/"calibration-wire.json")
    p=read_json(checked(photo_ref))
    w=read_json(checked(wire_ref))
    assert p["gate_parameters"]==w["gate_parameters"]==[list(g) for g in GATES]
    photo=p["rows"]
    wire=w["rows"]
    eligible=[row for row in wire if row["iso"]=="iso6400"]
    assert len(eligible)==24 and len(photo)==16
    targets, summary, selected, plus=natural_policies(photo)
    cap, wire_table, wire_best=wire_policies(eligible)
    def key(x):
        return {k:x[k] for k in ("gate","gain","quiet")}
    policies={"local20k":{"gate":"uniform","gain":0.,"quiet":0.},
              "Bayer-gated":{"gate":"uniform","gain":1.,"quiet":0.}}
    policies |= {"photo-"+name:key(value) for name,value in selected.items()}
    policies |= {"half-"+name:key(value) for name,value in plus.items()}
    policies["wire-local"]=key(wire_best)
    strong=max((v for name,v in selected.items() if name in ("auto","cross","joint")),
               key=lambda x:x["scores"]["response"], default=None)
    if strong:
        policies["photo-local"]=key(strong)
    write_json(ROOT/"selection.json",{"driver":reference(__file__),"calibration_photo":photo_ref,"calibration_wire":wire_ref,
        "scale_grid":{"detail_gain":[0.,1.5,.01],"flat_gain":[0.,.25,.01]},"natural_calibration_target":targets,
        "natural_selection":selected,"natural_half_change":plus,"natural_per_gate":summary,
        "wire_targets":cap,"wire_per_gate":wire_table,"policies":policies,
        "selection_rule":"For the Corpus 100k flat floor, choose lowest increment error if response meets Corpus 100k or otherwise the highest constrained response. Match half the flat increase without a new attenuation branch as a separate probe. Wire-local uses the original gap and flat addition caps, maximizing response among locally conditioned gates."})
    print("natural target",targets)
    for k,v in selected.items():
        print(k,v)
    print("wire caps",cap,"local best",wire_best)


if __name__=="__main__":
    freeze()
