"""Compute source-paired intervals for the frozen activity policies."""
import numpy as np

from activity import ROOT
from select_activity import table
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CONTRASTS=[
    ("photo-local","local20k"),("photo-local","100k"),("photo-local","photo-constant-damp"),
    ("wire-local","local20k"),("wire-local","Bayer-gated"),("wire-local","half-uniform"),
    ("half-cross","half-uniform"),("half-surround","half-uniform"),("wire-local","100k")
]


def policy_vectors(rows, selection):
    gate=selection["gate"]
    a,b=selection["gain"],selection["quiet"]
    linear=np.array([1.,a,b])
    quadratic=np.array([1.,a,a*a,b,a*b,b*b])
    cases=[row["results"][gate] for row in rows]
    scores={}
    for key in cases[0]:
        vectors=[r[key] for r in cases]
        mask=np.array([v is not None for v in vectors])
        if not mask.any():
            continue
        vectors=np.asarray([v for v in vectors if v is not None])
        if key in ("response","dip"):
            scores[key]=(100*vectors[:,:3]@linear,vectors[:,3],mask)
        else:
            values=np.sqrt(np.maximum(vectors@quadratic,0.))
            scores[key]=(values,np.ones(len(values)),mask)
    return scores


def paired(original, other, random):
    vector_a, power_a, mask_a=original
    vector_b, power_b, mask_b=other
    np.testing.assert_array_equal(mask_a,mask_b)
    np.testing.assert_array_equal(power_a,power_b)
    mask=power_a>0
    if not mask.any():
        return None
    delta=(vector_a-vector_b)[mask]
    power=power_a[mask]
    indices=random.integers(len(delta),size=(8000,len(delta)))
    observed=float(delta.sum()/power.sum())
    sampled=delta[indices].sum(1)/power[indices].sum(1)
    return {"n":len(delta),"delta":observed,"interval95":np.quantile(sampled,[.025,.975]).tolist()}


def summary(rows, options, random):
    assert len({r["source"] for r in rows})==len(rows)
    metrics={name:policy_vectors(rows,policy) for name,policy in options.items()}
    return {"sources":len(rows),"means":{name:{
                k:float(v.sum()/p.sum()) for k,(v,p,_) in scores.items() if p.sum()>0
            } for name,scores in metrics.items()},
            "contrasts":{a+" vs "+b:{k:paired(pair,metrics[b][k],random)
                for k,pair in metrics[a].items() if k in metrics[b]}
                for a,b in CONTRASTS if a in metrics and b in metrics}}


def main():
    rng=np.random.default_rng(92631)
    selection=reference(ROOT/"selection.json")
    policies=read_json(checked(selection))["policies"]
    refs={k:reference(ROOT/f"holdout-{k}.json")for k in ("photo","wire")}
    output={}
    for kind,binding in refs.items():
        rows=read_json(checked(binding))["rows"]
        entries=policies | ({"100k":{"gate":"100k","gain":0.,"quiet":0.}} if kind=="photo" else {})
        grouped={}
        for noise in ("iso400","iso6400"):
            for draw in (("independent","coupled") if kind=="photo" else ("wire",)):
                sample=[r for r in rows if r["iso"]==noise and r.get("draw","wire")==draw]
                assert len(sample)==(24 if kind=="wire" else 48)
                grouped[noise+"/"+draw]=summary(sample,entries,rng)
        output[kind]=grouped
    write_json(ROOT/"holdout-summary.json",{"driver":reference(__file__),"selection":selection,"holdout_bindings":refs,
                    "interval":"Percentile bootstrap, 8000 resamples of paired source photos within one profile/draw group.",
                    "partial_support":"The diagnostic field dip covers all nonzero support up to 0.65, including transition pixels in gapped geometry. It is different from the preceding report's continuous-dip-only measurement.",
                    "summary":output})


if __name__=="__main__":
    main()
