"""Test signed correction shape at matched natural flat-region error."""

from collections import defaultdict
import math

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_phase import ROOT, replay

SOURCE = reference(ROOT / "review/native.json")
review = read_json(checked(SOURCE))


def mixed(parent, lifted, gain):
    return (parent.astype(np.float64) + gain * (lifted.astype(np.float64) - parent)).astype(
        np.float32
    )


calibration = []
for row in review["exact"]["photo"]["rows"]:
    args = replay.read_arrays(row["input"])
    base = replay.load(row["previous_outputs"]["wire-aligned"])
    control = replay.load(row["outputs"]["support-only"])
    phase = replay.load(row["outputs"]["phase-support"])
    key = "exact_flat_fine_RMS_DN16"
    measurements = {
        "frozen_parent": replay.metrics(row, base, args)[key],
        "support_at_one": replay.metrics(row, control, args)[key],
        "phase_at_one": replay.metrics(row, phase, args)[key],
        "phase_at_minus_one": replay.metrics(row, mixed(base, phase, -1), args)[key],
    }
    calibration.append(
        {"input": row["input"], "source": row["source"]["source"]["id"]} | measurements
    )
squares = {key: float(np.mean([entry[key] ** 2 for entry in calibration])) for key in measurements}
const = squares["frozen_parent"]
cross = (squares["phase_at_one"] - squares["phase_at_minus_one"]) / 2
curvature = (squares["phase_at_one"] + squares["phase_at_minus_one"]) / 2 - const
target = squares["support_at_one"]
assert target > const and curvature > 0
scale = (-cross + math.sqrt(cross**2 + 4 * curvature * (target - const))) / (2 * curvature)
print("Matched phase gain", scale, "target natural flat RMS", math.sqrt(target), flush=True)
rows = []
calibration_ids = {r["source"] for r in calibration}
for row in review["exact"]["wire"]["rows"]:
    identity = row["source"]["source"]["id"]
    assert identity not in calibration_ids
    args = replay.read_arrays(row["input"])
    base = replay.load(row["previous_outputs"]["wire-aligned"])
    control = replay.load(row["outputs"]["support-only"])
    phase = replay.load(row["outputs"]["phase-support"])
    scores = {}
    metric = replay.metric_for_wire(args, row["source"]["geometry"])
    for label, values in (
        ("frozen parent", base),
        ("support at one", control),
        ("phase at one", phase),
        ("phase at matched natural flat", mixed(base, phase, scale)),
    ):
        scores[label] = replay.metrics(row, values, args)
        if metric.gap.any():
            basis = metric.strong_basis
            truth = metric.truth[0][metric.gap] @ basis
            luma = replay.luma(values, args["wb"], args["matrix"])[0, 64:192, 64:192][metric.gap]
            scores[label]["strong_response_pp"] = float(
                100 * ((luma @ basis) @ truth) / (truth @ truth)
            )
    rows.append({"input": row["input"], "source": identity, "scores": scores})
keys = ("weak_response_pp", "gap_RMS_DN16", "strong_response_pp", "exact_flat_RMS_DN16")
summary = defaultdict(dict)
for label in rows[0]["scores"]:
    for metric in keys:
        values = [r["scores"][label].get(metric) for r in rows]
        summary[label][metric] = float(np.mean([value for value in values if value is not None]))
write_json(
    ROOT / "review/matched-lift.json",
    {
        "source": SOURCE,
        "driver": reference(__file__),
        "calibration": calibration,
        "calibration_squared_means": squares,
        "matched_phase_scale": scale,
        "target_natural_flat_RMS_DN16": math.sqrt(target),
        "wire": rows,
        "summary": dict(summary),
        "scope": "A scalar chosen only to match the support-only exact-flat fine RMS on 24 natural images. "
        "Evaluate that fixed scalar on 24 source-disjoint synthetic wire backgrounds. "
        "An amplitude diagnostic on frozen outputs, separate from the composed endpoint.",
    },
)
print(dict(summary))
