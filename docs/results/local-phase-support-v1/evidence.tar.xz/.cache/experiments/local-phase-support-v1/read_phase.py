"""Print paired summaries from the scoped phase supervision review."""

from statistics import median

from demosaic.experiments.artifacts import read_json
from review_phase import ARMS, ROOT


def show(summary, keys):
    for key in keys:
        metric = summary[key]
        print(key, "n", metric["cases"], {k: round(v, 6) for k, v in metric["values"].items()})
        picked = [p for p in metric["differences"] if p.startswith("Signed phase + support")]
        print({p: [round(x, 6) for x in metric["differences"][p]["interval"]] for p in picked})


review_dir = ROOT / "review"
native = read_json(review_dir / "native.json")
for kind, metrics in (
    ("photo", ("fine_response_pp", "fine_increment_RMS_DN16", "exact_flat_fine_RMS_DN16")),
    (
        "wire",
        (
            "strong_response_pp",
            "weak_response_pp",
            "gap_RMS_DN16",
            "strong_error_DN16",
            "intact_increment_RMS_DN16",
            "exact_flat_RMS_DN16",
            "flat_chroma_RMS_DN16",
        ),
    ),
):
    print(kind)
    show(native["exact"][kind]["summary"], metrics)
    for arm in ARMS:
        data = native["exact"][kind]["rows"]
        print(
            arm,
            "RMS",
            median(r["delivered"][arm]["RMS_DN16"] for r in data),
            "open",
            median(r["gate"][arm]["confidence_logits_5_50_95"][1] for r in data),
            "off",
            median(r["gate"][arm]["confidence_below_one_percent"] for r in data),
        )
for case in native["standing"]:
    print(
        case["id"],
        {key: round(value["RMS_DN16"], 5) for key, value in case["delivered"].items()},
        {
            key: round(value["confidence_logits_5_50_95"][1], 5)
            for key, value in case["gate"].items()
        },
    )
for filename, keys in (
    ("double-gap", ("strong_response_pp", "double_gap_strong_DN16", "flat_RMS_DN16")),
    (
        "wire-transfer",
        ("weak_response_pp", "gap_RMS_DN16", "exact_flat_RMS_DN16", "intact_draw_variance_DN16"),
    ),
):
    if (path := review_dir / (filename + ".json")).is_file():
        print(filename)
        show(read_json(path)["summary"], keys)
        if filename == "double-gap":
            from publish_phase import gates_summary

            print(gates_summary(read_json(path)))
if (path := review_dir / "cameras.json").is_file():
    for name, panel in read_json(path)["summary"].items():
        print(name, {k: round(v["sensor_psnr"], 6) for k, v in panel.items()})
