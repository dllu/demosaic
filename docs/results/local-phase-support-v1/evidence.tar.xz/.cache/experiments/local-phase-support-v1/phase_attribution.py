"""Measure the delivered correction's exact continuing-wire component."""

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_phase import ARMS, ROOT, replay

source = reference(ROOT / "review/native.json")
review = read_json(checked(source))
rows = []
for case in review["exact"]["wire"]["rows"]:
    if not case["strong_projections"]:
        continue
    values = replay.read_arrays(case["input"])
    metric = replay.metric_for_wire(values, case["source"]["geometry"])
    basis = metric.strong_basis
    np.testing.assert_allclose(basis.T @ basis, np.eye(basis.shape[1]), rtol=0, atol=1e-10)
    direction = basis @ (metric.truth[0][metric.gap] @ basis)
    direction /= np.linalg.norm(direction)

    def gap(rgb):
        return replay.luma(rgb, values["wb"], values["matrix"])[0, 64:192, 64:192][metric.gap]

    def rms(field):
        return float(65535 * np.sqrt(np.mean(field**2)))

    control = gap(replay.load(case["previous_outputs"]["wire-aligned"]))
    exact = gap(values["target"])
    scores = {}
    for arm, prediction in case["outputs"].items():
        candidate = gap(replay.load(prediction))
        lift = candidate - control
        parallel = direction * (lift @ direction)
        scores[arm] = {
            "total_lift_sum_squares": float(lift @ lift),
            "aligned_lift_sum_squares": float(parallel @ parallel),
            "learned_gap_RMS_DN16": rms(candidate - exact),
            "aligned_proposal_only_gap_RMS_DN16": rms(control + parallel - exact),
            "lift_RMS_DN16": rms(lift),
            "aligned_lift_RMS_DN16": rms(parallel),
        }
    rows.append(
        {
            "source": case["source"],
            "input": case["input"],
            "frozen_parent_gap_RMS_DN16": rms(control - exact),
            "scores": scores,
        }
    )
assert len(rows) == 12
summary = {}
for arm in ARMS:
    fields = [case["scores"][arm] for case in rows]
    report = {key: float(np.mean([row[key] for row in fields])) for key in fields[0]}
    report["pooled_aligned_percent"] = (
        100 * report["aligned_lift_sum_squares"] / report["total_lift_sum_squares"]
    )
    summary[arm] = report
write_json(
    ROOT / "review/phase-attribution.json",
    {
        "native": source,
        "driver": reference(__file__),
        "scope": "Oracle diagnostics on the emitted lift. The target direction does not enter inference.",
        "rows": rows,
        "summary": summary,
    },
)
print(summary)
