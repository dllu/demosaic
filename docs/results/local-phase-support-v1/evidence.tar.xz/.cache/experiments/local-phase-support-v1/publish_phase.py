"""Bind scoped EMA comparisons and pixel-native reports to the completed training run."""

from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from review_phase import ARMS, FACTORED, ROOT, replay
from train_factored_detail import ancestor_plans

RESULTS = Path("docs/results") / ROOT.name
IMAGES = Path("docs/images") / ROOT.name


def training():
    end, preflight = [
        reference(ROOT / phase / "completed.json") for phase in ("training", "qualification")
    ]
    run, qual = [read_json(checked(role)) for role in (end, preflight)]
    plan = read_json(checked(run["plan"]))
    prior = read_json(checked(plan["parent_completion"]))
    first_factored = reference(FACTORED / "plan.json")
    assert first_factored in plan["inputs"]
    verify_plan(plan)
    assert prior["checkpoints"]["wire-aligned"] == plan["parent"] == run["parent"] == qual["parent"]
    assert run["plan"] == qual["plan"] and qual["qualification"] and not run["qualification"]
    assert plan["pair_axis"] == "strong" and set(plan["arms"]) == set(ARMS)
    previous = [p for _, p in ancestor_plans(checked(plan["parent_completion"]))]
    previous.append(read_json(checked(first_factored)))
    excluded = {
        case["source"]["id"]
        for p in previous
        for key in ("schedule", "qualification_schedule")
        for case in read_json(checked(p[key]))
    }
    assert len(excluded) == plan["excluding_distinct_prior_ids"]
    details = {}
    proofs = [end, preflight, run["plan"], plan["driver"]]
    for phase, state, key, expected in (
        ("training", run, "schedule", 480),
        ("qualification", qual, "qualification_schedule", 8),
    ):
        assert state["frozen_parent"] and set(state["checkpoints"]) == set(ARMS)
        assert state["updates_per_arm"] == state["source_photos_per_arm"] == expected
        assert state["native_observations_per_arm"] == 6 * expected
        for b in state["checkpoints"].values():
            checked(b)
        actual = [
            json.loads(line) for line in checked(state["observations"]).read_text().splitlines()
        ]
        learning = [json.loads(line) for line in checked(state["log"]).read_text().splitlines()]
        cases = read_json(checked(plan[key]))
        assert len(actual) == len(learning) == len(cases) == expected
        strata = Counter()
        for item, recorded, log in zip(cases, actual, learning, strict=True):
            row = item["source"]
            assert row["id"] == recorded["source_id"] and row["id"] not in excluded
            assert row["cache_sha256"] == recorded["cache_sha256"] and row["split"] == "train"
            excluded.add(row["id"])
            kind = item["kind"]
            assert (kind == "wire") == ("wire" in recorded["geometry"])
            assert "strong_continues" not in item
            assert (kind == "wire") == ("phase" in log["phase-support"])
            assert "phase" not in log["support-only"]
            for arm in ARMS:
                assert "support" in log[arm] and np.isfinite(list(log[arm].values())).all()
            assert len(set(recorded["seeds"].values())) == 8
            strata[kind, item["law"], item["iso"], item["pattern"]] += 1
        if expected == 480:
            assert len(strata) == 32 and set(strata.values()) == {15}
        details[phase] = {
            "split": state["plan"],
            "wire_pairs_with_a_continuing_and_double_gap_target": sum(
                count for (kind, *_), count in strata.items() if kind == "wire"
            ),
            "valid_paired_cores": state["valid_core_pairs"],
        }
        proofs.extend([state["observations"], state["log"], plan[key]])
    work = Path(plan["driver"]["path"]).parent.parent
    proofs.extend(
        reference(work / name)
        for name in (
            "src/demosaic/factored_detail.py",
            "scripts/train_local_paired_continuation.py",
        )
    )
    return run | {
        "endpoint": end,
        "qualification_receipt": preflight,
        "details": details,
        "fresh_wrt_factored_trial": first_factored,
    }, proofs


def board(source):
    path = checked(source["image"])
    target = IMAGES / path.parent.name / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    assert reference(target)["sha256"] == source["image"]["sha256"]
    with Image.open(target) as img:
        for p in source["panels"]:
            x, y, w, h = p["png_xywh"]
            assert w == h == 160 and x + w <= img.width and y + h <= img.height
    return source | {"image": source["image"] | {"path": str(target.relative_to(IMAGES))}}


def gates_summary(double):
    aggregate = {}
    for arm in ARMS:
        pairs = [
            dict(
                zip(
                    draws[0],
                    np.mean([[d[k] for k in draws[0]] for d in draws], axis=0),
                    strict=True,
                )
            )
            for row in double["rows"]
            if (draws := row["gains"][arm])
        ]
        n = len(pairs)
        assert n == 16
        keys = tuple(pairs[0])
        means = np.asarray([[row[k] for k in keys] for row in pairs])
        differences = means[:, 0] - means[:, 1]
        assert keys == ("continuing", "double_gap", "exact_flat")
        rng = np.random.default_rng(202611191529)
        bootstrap = differences[rng.integers(n, size=(6500, n))].mean(1)
        aggregate[arm] = {name: float(np.mean(means[:, i])) for i, name in enumerate(keys)} | {
            "true_minus_double": float(differences.mean()),
            "true_minus_double_95": np.quantile(bootstrap, (0.025, 0.975)).tolist(),
            "sources_with_higher_true_gain": int(np.sum(differences > 0)),
        }
    return aggregate


def compare_floor(rows, metrics, *, pool_rms=False):
    rng = np.random.default_rng(202611191541)
    result = {}
    for key in metrics:
        values = np.asarray(
            [
                [r["Support only"][key], r["0.25 gain floor"][key]]
                for r in rows
                if r["Support only"].get(key) is not None
            ]
        ).T
        n = values.shape[1]
        index = np.vstack((np.arange(n), rng.integers(n, size=(6500, n))))
        sampled = values[:, index]
        scores = (
            np.sqrt(np.mean(sampled**2, axis=2))
            if pool_rms and key.endswith("RMS_DN16")
            else sampled.mean(2)
        )
        change = scores[0] - scores[1]
        result[key] = {
            "cases": n,
            "delta": float(change[0]),
            "interval": np.quantile(change[1:], (0.025, 0.975)).tolist(),
        }
    return result


def publish(training_audit, proofs):
    native, double, redraw, camera, attribution, settings, views = (
        reference(ROOT / path)
        for path in (
            "review/native.json",
            "review/double-gap.json",
            "review/wire-transfer.json",
            "review/cameras.json",
            "review/phase-attribution.json",
            "configured/result.json",
            "viewing.json",
        )
    )
    n, d, t, c, a, mesh, viewed = [
        read_json(checked(b))
        for b in (native, double, redraw, camera, attribution, settings, views)
    ]
    assert all(x["endpoint"] == training_audit["endpoint"] for x in (n, d, t, c))
    assert a["native"] == mesh["review"] == viewed["native"] == native
    matched = reference(ROOT / "review/matched-lift.json")
    lifted = read_json(checked(matched))
    assert lifted["source"] == native and len(lifted["calibration"]) == len(lifted["wire"]) == 24
    support_triplets = reference(ROOT / "support-triplets/result.json")
    support = read_json(checked(support_triplets))
    assert support["native"] == native and len(support["rows"]) == 4
    support_boards = {row["id"]: row for row in support["rows"]}
    assert (
        viewed["configured"] == settings and mesh["historical_display_reconstructed_pixel_exactly"]
    )
    assert len(d["rows"]) == len(t["rows"]) == 16
    assert {stage: len(rows) for stage, rows in c["rows"].items()} == {"known": 24, "unseen": 30}
    image_rows = {
        "exact": [
            item | {key: board(item[key]) for key in ("board", "triplet")} for item in n["boards"]
        ],
        "standing": [item | {"board": board(item["board"])} for item in n["standing"]],
        "configured_mesh": [item | {"board": board(item["board"])} for item in mesh["boards"]],
    }
    assert {k: len(v) for k, v in image_rows.items()} == {
        "exact": 4,
        "standing": 8,
        "configured_mesh": 4,
    }
    for item in image_rows["exact"]:
        earlier = support_boards[item["id"]]
        assert earlier["source_comparison"]["sha256"] == item["board"]["image"]["sha256"]
        item["support_triplet"] = board(earlier["board"])
    for kind, group in image_rows.items():
        assert set(viewed[kind]) == {r["id"] for r in group}
    RESULTS.mkdir(parents=True, exist_ok=True)
    r = RESULTS / "training.json"
    write_json(r, training_audit)
    m = IMAGES / "manifest.json"
    write_json(
        m,
        image_rows
        | {
            "training": reference(r),
            "native_replay": native,
            "configured_reference": settings,
            "viewing": views,
            "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "checkpoint_policy": "Two correction EMAs composed on the frozen aligned-control EMA.",
            "precision": n["precision"],
            "reference": "Independent ISO100 AHD and camera JPEG references.",
        },
    )
    phase_path = RESULTS / "phase-attribution.json"
    shutil.copyfile(checked(attribution), phase_path)
    assert reference(phase_path)["sha256"] == attribution["sha256"]
    lift_path = RESULTS / "matched-lift.json"
    shutil.copyfile(checked(matched), lift_path)
    assert reference(lift_path)["sha256"] == matched["sha256"]
    archive = RESULTS / "evidence.tar.xz"
    resources = [
        *proofs,
        native,
        double,
        redraw,
        camera,
        attribution,
        settings,
        views,
        matched,
        support_triplets,
        reference(r),
        reference(replay.__file__),
        reference(ROOT / "review.log"),
        *(reference(p) for p in ROOT.glob("*.py")),
    ]
    with tarfile.open(archive, "x:xz", preset=4) as target:
        for binding in {b["path"]: b for b in resources}.values():
            path = checked(binding)
            target.add(path, arcname=str(path.relative_to(Path.cwd())), recursive=False)
    write_json(
        RESULTS / "publication.json",
        {
            "training": reference(r),
            "native_manifest": reference(m),
            "archive": reference(archive),
            "phase_attribution": reference(phase_path),
            "matched_lift": reference(lift_path),
            "scopes": {
                "training_complete": True,
                "scoped_numerical_replay_complete": True,
                "native_viewing_complete": True,
                "fixed_camera_complete": True,
                "fixed_427_complete": False,
                "photo_note": "Scoped frozen-component trial.",
            },
            "exact": {key: v["summary"] for key, v in n["exact"].items()},
            "double_gap": d["summary"],
            "redraws": t["summary"],
            "camera": c["summary"],
            "gate": gates_summary(d),
            "support_only_vs_gain_floor": {
                "wire": compare_floor(
                    [row["scores"] for row in n["exact"]["wire"]["rows"]],
                    ("weak_response_pp", "gap_RMS_DN16", "exact_flat_RMS_DN16"),
                ),
                "photograph": compare_floor(
                    [row["scores"] for row in n["exact"]["photo"]["rows"]],
                    ("fine_response_pp", "fine_increment_RMS_DN16", "exact_flat_fine_RMS_DN16"),
                    pool_rms=True,
                ),
                "double_gap": compare_floor(
                    [row["scores"] for row in d["rows"]],
                    ("strong_response_pp", "double_gap_strong_DN16", "flat_RMS_DN16"),
                ),
                "redraws": compare_floor(
                    [row["scores"] for row in t["rows"]],
                    ("weak_response_pp", "gap_RMS_DN16", "exact_flat_RMS_DN16"),
                ),
            },
            "standing": [{k: row[k] for k in ("id", "delivered", "gate")} for row in n["standing"]],
            "receipts": {
                "native": native,
                "camera": camera,
                "double_gap": double,
                "redraws": redraw,
            },
        },
    )


if __name__ == "__main__":
    audit, receipts = training()
    publish(audit, receipts)
