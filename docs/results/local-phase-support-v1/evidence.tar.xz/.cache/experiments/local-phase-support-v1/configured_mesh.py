"""Render both mesh ROIs under both noise profiles at the configured exposure."""

from pathlib import Path

import numpy as np
import torch

from demosaic.color import linear_to_srgb, srgb_to_linear
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from review_phase import ARMS, FLOOR, ROOT, replay

CONFIG = Path("configs/gfx-green-mesh-20231231.json")
V120 = ROOT.with_name("scene-context-native-review-v1") / "parent/collection-recovered.json"


def pixels(rgb):
    return np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    source = reference(ROOT / "review/native.json")
    review = read_json(checked(source))
    old = {
        r["id"]: r
        for r in read_json(checked(review["gain_floor"]))["standing"]
        if r["id"].startswith("mesh-")
    }
    config = read_json(CONFIG)
    baseline = read_json(V120)
    assert (
        baseline["checkpoint"]["sha256"]
        == "a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb"
    )
    by_id = {r["id"]: r for r in baseline["records"]}
    folder = ROOT / "configured"
    folder.mkdir()
    records = []
    for case in review["standing"]:
        if not case["id"].startswith("mesh-"):
            continue
        other = old[case["id"]]
        assert case["input"] == other["input"] and case["noise"] == other["noise"]
        assert case["raw"] == config["sources"]["noisy"]
        assert case["native_sensor_box"] == config["raw_context_xywh"]
        region = next(r for r in config["regions"] if case["id"].endswith(r["name"]))
        assert case["roi"] == region["ROI_xywh"]
        identifier = case["id"].removesuffix("-" + region["name"])
        archive = replay.read_arrays(case["input"])
        prior = by_id[identifier]
        assert all(fingerprint(archive[k]) == prior["input_fingerprints"][k] for k in replay.KEYS)
        bindings = {
            "V120 EMA": prior["prediction"],
            "Aligned control": case["previous_outputs"]["wire-aligned"],
            "Continuing-wire loss": case["previous_outputs"]["strong-gap"],
            "0.25 gain floor": other["outputs"]["gain-floor"],
        } | {ARMS[k]: v for k, v in case["outputs"].items()}
        arrays = (
            {"Noisy (Malvar)": archive["noisy_rgb"]}
            | {label: replay.load(ref) for label, ref in bindings.items()}
            | {"ISO100 AHD reference": archive["reference_rgb"]}
        )
        wb, matrix = (torch.from_numpy(archive[k]) for k in ("wb", "matrix"))

        def render(exposure):
            displayed = {
                label: pixels(
                    display_crop(torch.from_numpy(rgb), wb, matrix, case["roi"], exposure=exposure)
                )
                for label, rgb in arrays.items()
            }
            for key, label in (
                ("noisy_camera_jpeg", "ISO6400 camera JPEG"),
                ("reference_camera_jpeg", "ISO100 camera JPEG"),
            ):
                jpeg = replay.load(region["camera_JPEGs"][key]["pixels"]).astype(np.float32) / 255
                displayed[label] = pixels(
                    linear_to_srgb(np.clip(srgb_to_linear(jpeg) * exposure, 0, 1))
                )
            return displayed

        old_pixels = replay.old_pixels(other["board"])
        new_pixels = replay.old_pixels(case["board"])
        for label, rgb in render(case["exposure"]).items():
            np.testing.assert_array_equal(
                rgb, (new_pixels if label in new_pixels else old_pixels)[label]
            )
        exposure = config["display_exposure"]
        display = render(exposure)
        ordered = ["ISO6400 camera JPEG", *arrays, "ISO100 camera JPEG"]
        board = replay.native_png(
            folder / (case["id"] + "-configured.png"),
            [(label, display[label]) for label in ordered],
        )
        records.append(
            {
                "id": case["id"],
                "board": board,
                "input": case["input"],
                "noise": case["noise"],
                "capture": case["raw"],
                "region": region,
                "native_box": case["native_sensor_box"],
                "display_exposure": exposure,
                "predictions": bindings,
            }
        )
    assert len(records) == 4
    write_json(
        folder / "result.json",
        {
            "review": source,
            "driver": reference(__file__),
            "V120": reference(V120),
            "config": reference(CONFIG),
            "boards": records,
            "historical_display_reconstructed_pixel_exactly": True,
        },
    )


if __name__ == "__main__":
    main()
