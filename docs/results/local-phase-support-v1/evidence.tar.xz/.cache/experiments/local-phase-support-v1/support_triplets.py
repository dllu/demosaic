"""Select noisy, support-only and exact reference panels with their original pixels."""

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_phase import ROOT, replay

source = reference(ROOT / "review/native.json")
rows = []
folder = ROOT / "support-triplets"
folder.mkdir()
for case in read_json(checked(source))["boards"]:
    pixels = replay.old_pixels(case["board"])
    order = ("Noisy Malvar", "Support only", "Exact GT")
    board = replay.native_png(
        folder / (case["id"] + "-support-triplet.png"),
        [(name, pixels[name]) for name in order],
    )
    cropped = replay.old_pixels(board)
    for name in order:
        np.testing.assert_array_equal(pixels[name], cropped[name])
    rows.append({"id": case["id"], "board": board, "source_comparison": case["board"]["image"]})
write_json(
    folder / "result.json",
    {
        "native": source,
        "driver": reference(__file__),
        "rows": rows,
    },
)
