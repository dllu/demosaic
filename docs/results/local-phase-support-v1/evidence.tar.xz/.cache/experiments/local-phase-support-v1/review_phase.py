"""Replay exact, counterfactual, camera and standing tests for separate phase supervision."""

from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.factored_detail import load_detail_checkpoint
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
FACTORED = ROOT.with_name("local-factored-wire-v1")
FLOOR = ROOT.with_name("local-factored-wire-floor-v1")
sys.path.insert(0, str(FACTORED))
import review_factored as replay

PRIOR = replay.PREVIOUS
ARMS = {"support-only": "Support only", "phase-support": "Signed phase + support"}
OUTPUT = ROOT / "review"
PARENT = replay.PARENT
TEACHER = replay.TEACHER
OLD_FLOOR = "0.25 gain floor"


def exact_key(values, noise):
    return (
        *(fingerprint(values[key])["sha256"] for key in replay.KEYS),
        noise["shot"],
        noise["read"],
    )


class Runner(replay.Runner):
    def __init__(self, run):
        self.parent_binding = run["parent"]
        self.parent = None
        self.cached = None
        self.heads = {}
        self.activations = {}
        for key, binding in run["checkpoints"].items():
            detail, state = load_detail_checkpoint(
                checked(binding), weights="ema", expected_sha256=binding["sha256"]
            )
            assert state["parent"] == self.parent_binding and state["plan"] == run["plan"]
            assert state["band_limited"] and detail.gain_floor == 0.0
            assert state["step"] == run["updates_per_arm"]
            self.heads[key] = _stage_tiled_cuda(detail, "cuda")

            def capture(module, inputs, output, *, label=key):
                self.activations[label] = output.detach()

            detail.output.register_forward_hook(capture)

    def cached_inputs(self, native):
        self.cached = {}
        for row, profile in (
            *(
                (case, replay.PROFILE)
                for field in native["groups"].values()
                for case in field["rows"]
            ),
            *((case, case["noise"]) for case in native["standing"]),
        ):
            key = exact_key(replay.read_arrays(row["input"]), profile)
            binding = row["outputs"]["wire-aligned"]
            assert self.cached.setdefault(key, binding) == binding

    def forward(self, args, profile):
        if self.cached is None:
            if self.parent is None:
                binding = self.parent_binding
                self.parent, _ = load_scene_checkpoint(
                    checked(binding), weights="ema", expected_sha256=binding["sha256"]
                )
                _stage_tiled_cuda(self.parent, "cuda")
            return super().forward(args, profile)

        value = replay.load(self.cached[exact_key(args, profile)])
        packed = (
            torch.as_tensor(args["packed"]).cuda().contiguous(memory_format=torch.channels_last)
        )
        variance = (
            torch.as_tensor(args["variance"]).cuda().contiguous(memory_format=torch.channels_last)
        )
        camera = []
        for key in ("colors", "wb", "matrix"):
            tensor = torch.as_tensor(args[key]).cuda()
            if tensor.ndim == (2 if key == "matrix" else 1):
                tensor = tensor[None].expand(len(packed), *tensor.shape)
            camera.append(tensor)
        base = torch.as_tensor(value).cuda().contiguous(memory_format=torch.channels_last)
        with ieee_fp32():
            frames, scale, direction = next(iter(self.heads.values())).features(
                base, packed, variance, *camera
            )
            deltas = {key: head.correction(frames, scale) for key, head in self.heads.items()}
            outputs = {key: base + direction * delta for key, delta in deltas.items()}
        return base, outputs, deltas


def native_with_old_floor(groups, old):
    for kind, data in groups.items():
        earlier = {case["input"]["sha256"]: case for case in old["exact"][kind]["rows"]}
        for row in data["rows"]:
            prev = earlier[row["input"]["sha256"]]
            assert row["input"] == prev["input"] and row["source"] == prev["source"]
            row["scores"][OLD_FLOOR] = prev["scores"][OLD_FLOOR]
            if row["strong_projections"]:
                row["strong_projections"][OLD_FLOOR] = prev["strong_projections"][OLD_FLOOR]
        data["summary"] = replay.compare(
            [row["scores"] for row in data["rows"]], natural=kind == "photo"
        )
        if kind == "wire":
            data["summary"].update(
                replay.compare(
                    [row["strong_projections"] for row in data["rows"] if row["strong_projections"]]
                )
            )
    return groups


def gate_measurement(activations, data):
    truth = replay.luma(data["target"], data["wb"], data["matrix"])
    support = np.clip(np.abs(truth[0] - truth[1]), 0, None)
    support /= support.sum()
    rows = {}
    for key, logits in activations.items():
        confidence = torch.nn.functional.pixel_shuffle(logits.float(), 2)[:, 1]
        gain = confidence.sigmoid().cpu().numpy()
        rows[key] = {
            "continuing": float(np.sum(gain[0] * support)),
            "double_gap": float(np.sum(gain[1] * support)),
            "exact_flat": float(np.sum(gain[2] * support)),
        }
    return rows


def repeat(runner, previous, floor, ids, *, double):
    panel = read_json(checked(previous["inputs"]))
    assert floor["source"] == previous["inputs"]
    results = []
    for case, old, gain_floor in zip(panel["rows"], previous["rows"], floor["rows"], strict=True):
        assert old["case"] == gain_floor["case"] == case
        source_id = case["source"]["id"] if double else case["source"]["source"]["id"]
        assert source_id not in ids
        rendered, gain_rows = defaultdict(list), defaultdict(list)
        for draw in case["draws"]:
            data = replay.read_arrays(draw["arrays"])
            assert fingerprint(data["packed"]) == draw["packed"]
            if double:
                assert fingerprint(data["target"]) == case["clean"]
            else:
                assert {k: fingerprint(data[k]) for k in case["target_fingerprints"]} == case[
                    "target_fingerprints"
                ]
            _, variants, _ = runner.arrays(data, panel["profile"])
            for key, values in variants.items():
                rendered[key].append(
                    replay.luma(values, data["wb"], data["matrix"]) if double else values
                )
            if double:
                for key, gain in gate_measurement(runner.activations, data).items():
                    gain_rows[key].append(gain)
        scores = {name: old["scores"][name] for name in (PARENT, TEACHER)} | {
            OLD_FLOOR: gain_floor["scores"][OLD_FLOOR]
        }
        for key, outputs in rendered.items():
            if double:
                truth = replay.luma(data["target"], data["wb"], data["matrix"])
                metrics = replay.double_metrics(np.stack(outputs), truth, case["geometry"])
            else:
                metric = replay.metric_for_wire(data, case["source"]["geometry"])
                metrics = replay.decompose(np.stack(outputs), data, metric)
                measures = [replay.metrics(case, array, data) for array in outputs]
                for name in (
                    "exact_flat_RMS_DN16",
                    "gap_RMS_DN16",
                    "gap_weak_RMS_DN16",
                    "flat_chroma_RMS_DN16",
                ):
                    values = [row[name] for row in measures if row.get(name) is not None]
                    if values:
                        metrics[name] = float(np.mean(values))
            scores[ARMS[key]] = metrics
        results.append({"case": case, "scores": scores, "gains": dict(gain_rows)})
    return {
        "source": previous["inputs"],
        "rows": results,
        "summary": replay.compare([row["scores"] for row in results]),
    }


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    endpoint = reference(ROOT / "training/completed.json")
    run = read_json(checked(endpoint))
    plan = read_json(checked(run["plan"]))
    assert run["frozen_parent"] and not run["qualification"] and run["updates_per_arm"] == 480
    assert plan["pair_axis"] == "strong" and set(plan["arms"]) == set(ARMS)
    assert run["parent"] == plan["parent"]
    prior_run = read_json(checked(plan["parent_completion"]))
    assert prior_run["checkpoints"]["wire-aligned"] == run["parent"]
    ids = {
        row["source"]["id"]
        for name in ("schedule", "qualification_schedule")
        for row in read_json(checked(plan[name]))
    }
    assert len(ids) == 488
    source_refs = {
        key: reference(PRIOR / "review" / (name + ".json"))
        for key, name in (
            ("native", "result"),
            ("double-gap", "double-gap"),
            ("wire-transfer", "wire-transfer"),
        )
    }
    floor_refs = {key: reference(FLOOR / "review" / (key + ".json")) for key in source_refs}
    source = {key: read_json(checked(p)) for key, p in source_refs.items()}
    floors = {key: read_json(checked(p)) for key, p in floor_refs.items()}
    assert all(d["endpoint"] == plan["parent_completion"] for d in source.values())
    floor_endpoint = reference(FLOOR / "training/completed.json")
    assert read_json(checked(floor_endpoint))["parent"] == run["parent"]
    assert all(
        d["gain_floor_endpoint"] == floor_endpoint and d["previous"] == source_refs[key]
        for key, d in floors.items()
    )
    for group in source["native"]["groups"].values():
        assert ids.isdisjoint(row["source"]["source"]["id"] for row in group["rows"])
    replay.ARMS = ARMS
    replay.OUTPUT = OUTPUT
    run_bindings = {
        "endpoint": endpoint,
        "driver": reference(__file__),
        "library": reference(replay.__file__),
        "weights": "EMA correction on frozen parent EMA",
        "precision": "CUDA IEEE FP32",
    }
    runner = Runner(run)
    OUTPUT.mkdir()
    start = time.monotonic()
    runner.cached_inputs(source["native"])
    groups, boards = replay.exact(runner, source["native"])
    print("exact complete", time.monotonic() - start, flush=True)
    real = replay.standing(runner, source["native"])
    write_json(
        OUTPUT / "native.json",
        run_bindings
        | {
            "previous": source_refs["native"],
            "gain_floor": floor_refs["native"],
            "exact": native_with_old_floor(groups, floors["native"]),
            "boards": boards,
            "standing": real,
            "seconds": time.monotonic() - start,
            "parent_prediction_policy": "Only digest-verified frozen parent predictions on identical "
            "Bayer arrays, camera calibration and shot/read.",
        },
    )
    runner.cached = None
    print("standing complete", time.monotonic() - start, flush=True)
    for key in ("double-gap", "wire-transfer"):
        section = repeat(runner, source[key], floors[key], ids, double=key == "double-gap")
        write_json(
            OUTPUT / (key + ".json"),
            run_bindings
            | section
            | {
                "previous": source_refs[key],
                "gain_floor": floor_refs[key],
                "seconds": time.monotonic() - start,
            },
        )
        print(key, "complete", time.monotonic() - start, flush=True)
    write_json(
        OUTPUT / "cameras.json",
        run_bindings
        | replay.cameras(runner)
        | {
            "seconds": time.monotonic() - start,
        },
    )
    print("cameras complete", time.monotonic() - start, flush=True)


if __name__ == "__main__":
    main()
