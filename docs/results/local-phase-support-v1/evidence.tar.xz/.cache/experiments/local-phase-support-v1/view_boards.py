"""Arrange the saved native crop pixels for inspection."""

from demosaic.experiments.artifacts import read_json
from review_phase import ARMS, ROOT

from prepare_views import make

native = read_json(ROOT / "review/native.json")
configured = read_json(ROOT / "configured/result.json")["boards"]
make(
    native["boards"],
    ("Noisy Malvar", "Aligned control", *ARMS.values(), "Exact GT"),
    ROOT / "exact.png",
)
for family in ("main", "mesh"):
    rows = [case for case in native["standing"] if case["id"].startswith(family)]
    make(
        rows,
        ("V120 EMA", "Aligned control", "Continuing-wire loss", *ARMS.values()),
        ROOT / (family + ".png"),
    )
    labels = ("Noisy (Malvar)", "ISO100 AHD reference")
    if family == "mesh":
        labels = ("ISO6400 camera JPEG", *labels, "ISO100 camera JPEG")
    make(rows, labels, ROOT / (family + "-references.png"))
make(
    configured,
    ("V120 EMA", "Aligned control", "0.25 gain floor", *ARMS.values()),
    ROOT / "configured.png",
)
make(
    configured,
    ("ISO6400 camera JPEG", "Noisy (Malvar)", "ISO100 AHD reference", "ISO100 camera JPEG"),
    ROOT / "configured-references.png",
)
