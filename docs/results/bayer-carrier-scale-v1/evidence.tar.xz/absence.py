"""Measure added weak-family signal where the weak carrier is absent throughout."""
from functools import partial
import sys

import numpy as np

from apply_scale import setup
from benchmark import GATE
from restore import ROOT, ROI, geometry, proposals, review
from review_gate import PRIOR
from review_quiet import LOCAL, CORE, numeric, wire_inputs
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0,str(ROOT.parent/"local-phase-envelope-v1"))
from gap_projection import subspace


def measure(case, plan, lookup, model):
    data, parents, source = wire_inputs(case,lookup,None)
    scene = plan["sources"][case["index"]]
    noise = plan["profiles"][case["noise"]]
    box = plan["query"]
    cfa = data["colors"][0]
    spacing, ok, _ = geometry(data["full"],cfa,box,ROI)
    donors = review.exterior(data["full"],cfa,noise,box)
    networks,doses = model
    role = 2
    current, change, counts = proposals(data["packed"][role],data["colors"][role],
          data["wb"][role],data["matrix"][role],noise,box,donors,parents[LOCAL][role],
          networks,spacing,ROI,ok,GATE)
    images = current | {"scale64":current["distant"] + np.float32(doses["scale64"])*change["scale64"]}
    ref = review.old.luma(data["target"],data)[role,CORE[0],CORE[1]]
    width = subspace(scene["geometry"],np.ones(ref.shape,dtype=bool))[-1]
    def luma(x):
        # The camera metadata is constant across roles.
        return review.old.luma(x[None],data)[0,CORE[0],CORE[1]]
    prior = luma(current["distant"])
    scale = 65535/np.sqrt(ref.size)
    metrics = {}
    for arm,x in images.items():
        z=luma(x)
        metrics[arm] = {"weak_band_error":float(scale*np.linalg.norm(width.T@(z-ref).ravel())),
                        "weak_band_added":float(scale*np.linalg.norm(width.T@(z-prior).ravel())),
                        "all_error":review.rms(z-ref)}
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"source_id":scene["source"]["id"],"profile":case["noise"],
            "input":case["input"],"parent_output":source,"active_windows":counts["scale64"],
            "metrics":metrics|{"matched":metrics["distant"]}}


if __name__=="__main__":
    model,trust = setup()
    manifest = reference(PRIOR/"wire-parent.json")
    source = read_json(checked(manifest))
    samples = read_json(checked(source["inputs"]))["rows"]
    plan = read_json(checked(source["plan"]))
    assert plan["roles"][2]=="strong-only"
    rows = review.run(samples,partial(measure,plan=plan,lookup={r["id"]:r for r in source["rows"]},model=model))
    assert len(rows)==48
    fields = ("weak_band_error","weak_band_added","all_error")
    summaries = {iso:[r for r in rows if r["profile"]==iso]for iso in ("iso400","iso6400")}
    reporting = numeric(summaries,[("scale64","distant"),("scale64","ring8")],fields)
    write_json(ROOT/"absence.json",trust|{"driver":reference(__file__),"inputs":manifest,"roles":plan["roles"],
                                         "rows":rows,"reports":reporting})
