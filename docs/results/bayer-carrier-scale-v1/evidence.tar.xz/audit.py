"""Check native coordinate, CFA and sample separation on exact signals."""
import numpy as np

from carrier_scale import ROOT, far_geometry, nuisance, planes, regress, wave
from demosaic.experiments.artifacts import reference, write_json


def check():
    seed = 369335
    random = np.random.default_rng(seed)
    pattern = ("RGGB","GRBG","GBRG","BGGR")
    true = np.array([[.119,.075],[.090,-.071]])
    coefficient = np.array([.0020,-.0012,.0018,-.0007])
    profile = {"shot":.00128, "read":6.5536e-6}
    RGB = {"R":0, "G":1, "B":2}
    maximum = 0.
    min_gain = float("inf")
    for cfa in pattern:
        layout=np.array([RGB[k]for k in cfa])
        for origin in ((0,0),(1,0),(0,1),(1,1)):
            n=64
            design=nuisance(n,"smooth")
            carriers=wave(true,n)
            input=(.04+.01*design[...,1]+carriers@coefficient).astype(np.float32)
            a,b=planes(layout,(*origin,n))
            for first, second in ((a,b),(b,a)):
                result = regress(input,first,second,design,carriers,profile)
                got=np.asarray(result["training_coefficients"]).T.ravel()
                maximum=max(maximum,float(abs(got-coefficient).max()))
                min_gain=min(min_gain,*result["conditional_gain"])
                isolated = input.copy()
                isolated[second[0]::2,second[1]::2]+=random.normal(0,.012,size=(n//2,n//2))
                changed=regress(isolated,first,second,design,carriers,profile)
                assert changed["training_coefficients"]==result["training_coefficients"]
    assert maximum<1e-8 and min_gain>4
    bounds=(164,164,160)
    raw=(.07+wave(true,496)@coefficient).astype(np.float32)
    before=far_geometry(raw,layout,bounds)
    after=raw.copy()
    after[164:324,164:324]+=random.uniform(-.03,.03,(160,160)).astype(np.float32)
    assert before==far_geometry(after,layout,bounds)
    stable=np.asarray(before[0])
    err=float(np.max(np.linalg.norm(stable-true,axis=-1)))
    assert err<.003
    write_json(ROOT/"audit.json", {"driver":reference(__file__),"seed":seed,"layouts":list(pattern),
                "origins":[[0,0],[1,0],[0,1],[1,1]],"max_coefficient_replay_error":maximum,
                "min_exact_predictive_gain":min_gain,"max_frequency_error_cycles_per_pixel":err,
                "heldout_green_perturbation_leaves_fit_identical":True,
                "central_raw_perturbation_leaves_donor_nomination_identical":True})


if __name__=="__main__":
    check()
