"""Match crop correction strength and audit leakage into the missing family."""
from functools import partial
import sys
import time

import numpy as np

from apply_scale import setup
from benchmark import GATE, evaluate
from restore import ROOT, ROI, ARMS, geometry, proposals, review
from review_gate import PRIOR
from review_quiet import CORE, LOCAL, numeric, wire_inputs
from quadrature import rms_at
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.insert(0,str(ROOT.parent/"local-phase-envelope-v1"))
from gap_projection import subspace, summarize


def gap(case, plan, lookup, model, base_interval):
    data, parents, proof = wire_inputs(case,lookup,None)
    mask = data["support"][CORE] <= .01
    if not mask.any():
        return None
    networks,doses = model
    noise = plan["profiles"][case["noise"]]
    box = plan["query"]
    src = plan["sources"][case["index"]]
    spacing,ok,_ = geometry(data["full"],data["colors"][0],box,ROI)
    around = review.exterior(data["full"],data["colors"][0],noise,box)
    pred,delta,_ = proposals(data["packed"][0],data["colors"][0],data["wb"][0],data["matrix"][0],
                             noise,box,around,parents[LOCAL][0],networks,spacing,ROI,ok,GATE)
    template = subspace(src["geometry"],mask)
    luma = lambda x:review.old.luma(x[None],data)[0,CORE[0],CORE[1]].astype(np.float64)
    clean = luma(data["target"][0])
    anchor = luma(pred["distant"])
    choices = pred | {k:pred["distant"]+np.float32(doses[k])*delta[k]for k in ARMS}
    choices["scale32-matched"] = pred["distant"]+np.float32(base_interval)*delta["scale32"]
    result = {}
    for arm,img in choices.items():
        rgb = luma(img)
        result[arm] = summarize(rgb-anchor,rgb-clean,mask,template)
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"profile":case["noise"],"source_id":src["source"]["id"],
            "input":case["input"],"parent_output":proof,"gap_pixels":int(mask.sum()),
            "metrics":result|{"matched":result["distant"]}}


def main():
    start = time.monotonic()
    model,receipt = setup()
    path = reference(ROOT/"wire.json")
    artifact = read_json(checked(path))
    tune = [r for r in artifact["rows"]["wire-tune"] if r["gap_pixels"]]
    assert len(tune)==12
    average = {name:float(np.mean([rms_at(row["products"][name]["gap_added"],1.)for row in tune]))
               for name in ARMS}
    chosen = artifact["dose"]["scale64"]["gain"]
    gain = chosen*average["scale64"]/average["scale32"]
    doses = artifact["dose"] | {"scale32-matched":{"gain":gain}}
    # Benchmark rows retain exact linear product tables for the original basis.
    measured = []
    for row in artifact["rows"]["wire"]:
        clone = row | {"products":row["products"] | {"scale32-matched":row["products"]["scale32"]}}
        measured.append(evaluate(clone,doses))
    cohorts = {p:[r for r in measured if r["profile"]==p]for p in ("iso400","iso6400")}
    values = numeric(cohorts,[("scale64","scale32-matched")],
                     ("intact_response","intact_rms","gap_exact","gap_added","flat_rms"))
    base = read_json(checked(artifact["inputs"]["wire"]))
    loaded = read_json(checked(base["inputs"]))["rows"]
    notes = review.run(loaded,partial(gap,plan=read_json(checked(base["plan"])),
                lookup={r["id"]:r for r in base["rows"]},model=model,base_interval=gain))
    exact = [r for r in notes if r is not None]
    cohorts = {p:[r for r in exact if r["profile"]==p]for p in ("iso400","iso6400")}
    assert all(len(z)==12 for z in cohorts.values())
    estimates = numeric(cohorts,[("scale64",old)for old in ("distant","ring8","scale32-matched")],
                        ("gap_weak_band_error","gap_strong_band_added","gap_weak_band_added","gap_other_error"))
    write_json(ROOT/"gap-compare.json",receipt | {"driver":reference(__file__),"original_wire":path,
                "calibration_gain_32":gain,"calibration_gap_rms_per_unit":average,"matched_reports":values,
                "gap_bands":estimates,"rows":exact,"seconds":time.monotonic()-start})


if __name__=="__main__":
    main()
