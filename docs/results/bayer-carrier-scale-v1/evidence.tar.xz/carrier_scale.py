"""Measure how well native Bayer wire candidates predict an unused green lattice."""
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import fft2

from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw

ROOT = Path(__file__).resolve().parent
GFX = ROOT.parent / "bayer-distant-phase-gate-v1"
MAIN = Path("configs/gfx-qualitative-20231231.json")
CAB = Path("configs/gfx-green-mesh-20231231.json")
SIZES = (32, 64, 128, 160)
PAD = 256
FREQ = np.fft.fftfreq(PAD, d=2)
FY, FX = np.meshgrid(FREQ, FREQ, indexing="ij")
RADIAL = np.hypot(FX, FY)
FULL_ANGLES = (FX >= .021) & (abs(FY) >= .012) & (RADIAL >= .041) & (RADIAL <= .22)
SECTORS = (FULL_ANGLES & (FY > 0), FULL_ANGLES & (FY < 0))
STRIDE = {32: 32, 64: 96, 128: 128, 160: 160}


def cut(raw, box):
    x, y, size = box
    view = raw[y : y+size, x : x+size]
    assert view.shape == (size, size)
    return view


def planes(cfa, box):
    x, y, _ = box
    tiled = cfa.reshape(2,2)[(np.arange(2)+y)%2][:,(np.arange(2)+x)%2]
    return tuple(zip(*np.where(tiled == 1), strict=True))


def origins(size):
    if size <= 64:
        return [(x,y,size) for y in range(0,161-size,STRIDE[size])
                for x in range(0,161-size,STRIDE[size])]
    return [((160-size)//2,(160-size)//2,size)]


def spectrum(patch, offsets):
    n = patch.shape[0]//2
    taper = np.sin(np.pi*(np.arange(n)+.5)/n)
    taper = (taper[:,None]*taper).astype(np.float32)
    output = []
    for y,x in offsets:
        sampled = patch[y::2,x::2]
        weighted = (sampled - (taper*sampled).sum()/taper.sum())*taper
        response = fft2(weighted, s=(PAD,PAD))
        response *= np.exp(-2j*np.pi*(FY*y+FX*x)).astype(np.complex64)
        output.append(response / np.sqrt((taper**2).sum()))
    return np.stack(output)


def select(power):
    source = []
    for group in SECTORS:
        pos = np.unravel_index(np.where(group, power, -np.inf).argmax(), power.shape)
        source.append([float(FX[pos]), float(FY[pos])])
    return source


def far_geometry(raw, cfa, box):
    x,y,n = box
    # Four 128 px banks adjacent to the fixed ROI, each strictly disjoint.
    windows = [(x-128,y+16,128),(x+n,y+16,128),(x+16,y-128,128),(x+16,y+n,128)]
    maps = []
    for w in windows:
        values = spectrum(cut(raw, w), planes(cfa, w))
        maps.append(abs(values.mean(axis=0))**2)
    # Per-donor normalization caps the influence of a single bright structure.
    z = np.stack(maps)
    z /= np.maximum(z[:,FULL_ANGLES].mean(axis=1)[:,None,None], 1e-10)
    return select(z.mean(0)), windows, [select(p)for p in maps]


def nuisance(size, kind):
    yy,xx = np.indices((size,size), dtype=np.float64)
    x,y = ((xx+.5)/size), ((yy+.5)/size)
    if kind == "affine":
        return np.stack((np.ones_like(x), x-.5, y-.5),axis=-1)
    order = int(np.ceil(.066*size))
    terms = [np.cos(np.pi*i*x)*np.cos(np.pi*j*y) for i in range(order+1) for j in range(order+1)
             if np.hypot(i,j) <= order]
    return np.stack(terms, axis=-1)


def wave(frequency, size):
    y,x = np.indices((size,size),dtype=np.float64)
    x -= (size-1)/2
    y -= (size-1)/2
    q = np.asarray(frequency)
    angle = 2*np.pi*(x[...,None]*q[:,0] + y[...,None]*q[:,1])
    return np.concatenate((np.cos(angle), np.sin(angle)),axis=-1)


def regress(train, green_a, green_b, design, carriers, profile):
    cols = carriers.shape[-1]
    joined = np.concatenate((design,carriers),axis=-1)
    A, B = (joined[y::2,x::2].reshape(-1,joined.shape[-1]) for y,x in (green_a,green_b))
    u, v = (train[y::2,x::2].astype(np.float64).ravel() for y,x in (green_a,green_b))
    base = A[:,:-cols]
    mu = np.mean(u)
    variance = max(2e-11, float(profile["shot"])*max(0,float(mu))+float(profile["read"]))
    gram, moment = A.T@A, A.T@u
    prior = np.linalg.solve(gram,moment)
    beta = prior[-cols:].reshape(2,2).T
    hold_error = v-B@prior
    full = float(hold_error@hold_error)
    gain = []
    for direction in range(2):
        good = np.ones(joined.shape[-1], dtype=bool)
        good[np.arange(direction,cols,2)+joined.shape[-1]-cols] = False
        cut = np.linalg.solve(gram[good][:,good],moment[good])
        err = v-B[:,good]@cut
        gain.append(float((err@err-full)/variance))
    null = np.linalg.solve(base.T@base,base.T@u)
    err = v-B[:,:-cols]@null
    return {"conditional_gain":gain,"joint_gain":float((err@err-full)/variance), "test_pixels":len(v),
            "training_coefficients":beta.tolist(),"equivalent_sensor_sigma_DN16":float(np.sqrt(variance)*65535)}


def field(raw, cfa, box, fixed, profiles, style):
    outputs = {}
    for size in SIZES:
        tiles = []
        background = nuisance(size,style)
        for dx,dy,n in origins(size):
            q = (box[0]+dx,box[1]+dy,n)
            image = cut(raw,q)
            offsets = planes(cfa,q)
            fit = dict(fixed)
            # Local discovery uses the fitting plane only. Its held-out
            # predictor, nuisance and amplitude have never read the other.
            candidates = [select(abs(s)**2)for s in spectrum(image,offsets)]
            fit["local-search"] = candidates
            vals = {}
            for key,coords in fit.items():
                geometry = coords if key == "local-search" else (coords,coords)
                vals[key] = {p:[regress(image,a,b,background,wave(geometry[i],n),profile)
                       | {"frequency":geometry[i]} for i,(a,b) in enumerate((offsets,offsets[::-1]))]
                       for p,profile in profiles.items()}
            tiles.append({"xywh":[q[0],q[1],n,n], "models":vals})
        outputs[str(size)] = tiles
    return outputs


def sources():
    config = {"main":read_json(MAIN),"cab":read_json(CAB)}
    stamp = {}
    specs = {}
    for name,cfg in config.items():
        if name=="main":
            pair = {k:reference(cfg[k])for k in ("noisy","reference")}
            rows = {r["name"]:(r["noisy_xy"]+[r["size"]],r["reference_xy"]+[r["size"]])for r in cfg["regions"]}
        else:
            pair = {k:cfg["sources"][k]for k in ("noisy","reference")}
            rows = {r["name"]:(r["noisy_raw_xywh"][:3],r["reference_raw_xywh"][:3])for r in cfg["regions"]}
        stamp[name] = {"media":pair,"rois":rows,"config":reference(MAIN if name=="main" else CAB)}
        specs[name] = rows
    return stamp,specs


def main():
    start=time.monotonic()
    profile = {"nominal":{"shot":.00128,"read":6.5536e-6},
               "transferred":{"shot":.0014635775921166604,"read":1.0715704128646712e-6}}
    specs, regions = sources()
    answers = {}
    for group,fields in regions.items():
        entry=specs[group]
        noisy,meta = read_raw(checked(entry["media"]["noisy"]))
        refer,refmeta = read_raw(checked(entry["media"]["reference"]))
        cfa,ref_cfa = (np.asarray(color_indices(v.pattern))for v in (meta,refmeta))
        named = ("chain-link-fence",) if group=="main" else tuple(fields)
        preferred = {}
        for key in named:
            _,box = fields[key]
            candidate=spectrum(cut(refer,box),planes(ref_cfa,box))
            preferred[key]=select(abs(candidate.mean(0))**2)
        entry["reference_frequency_only"] = preferred
        del refer
        for key,(box,_ref) in fields.items():
            basis, donors, donor_modes = far_geometry(noisy,cfa,box)
            candidates = {"reference-spacing":preferred[key if key in preferred else named[0]],
                          "separate-RAW-spacing":basis}
            results={style:field(noisy,cfa,box,candidates,profile,style)for style in ("smooth","affine")}
            answers[key] = {"nearby_noisy_donor_boxes":donors,"donor_modes":donor_modes,
                            "candidate_frequencies_xy":candidates,"rows":results}
            print(key,candidates,round(time.monotonic()-start,2),flush=True)
        del noisy
    write_json(ROOT/"field.json",{"driver":reference(__file__),"inputs":specs,"profiles":profile,"results":answers,
                                  "runtime_s":time.monotonic()-start,
                                  "scope":"ISO6400 Bayer predictive diagnostic. ISO100 geometry only, no amplitude or phase transfer."})


if __name__=="__main__":
    main()
