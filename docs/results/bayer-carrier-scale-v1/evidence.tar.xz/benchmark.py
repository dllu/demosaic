"""Calibrate and compare local sensor fit sizes on paired exact-target wires."""
from functools import partial
import sys
import time

import numpy as np

from restore import ARMS, ROI, ROOT, geometry, proposals, setup, review
from review_gate import PRIOR
from review_quiet import CORE, LOCAL, numeric, wire_inputs
from quadrature import products, rms_at
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

GATE = 6.0


def observe(case, plan, lookup, models):
    data, parents, evidence = wire_inputs(case, lookup, None)
    profile = plan["profiles"][case["noise"]]
    query = plan["query"]
    src = plan["sources"][case["index"]]
    spatial = review.exterior(data["full"], data["colors"][0], profile, query)
    spacing, admitted, geom = geometry(data["full"],data["colors"][0],query,ROI)
    views = [proposals(raw,cfa,wb,mat,profile,query,spatial,prior,models,spacing,ROI,admitted,GATE)
              for raw,cfa,wb,mat,prior in zip(data["packed"],data["colors"],data["wb"],
                                            data["matrix"],parents[LOCAL],strict=True)]
    def luma(frame):
        return review.old.luma(frame,data)[...,CORE[0],CORE[1]]
    def baseline(name):
        return luma(np.stack([v[0][name]for v in views]))
    base = baseline("distant")
    exact = luma(data["target"])
    masked = data["support"][CORE]
    is_gap = masked <= .01
    intact = masked >= .97
    good = np.s_[3,8:-8,8:-8]
    target = (exact[0]-exact[1])[intact]
    estimates = {"ring8":baseline("ring8")-base,"exterior-only":baseline("exterior-only")-base,
                 "distant":np.zeros_like(base)}
    estimates.update({label:luma(np.stack([v[1][label]for v in views]))for label in ARMS})
    scores = {}
    for name,delta in estimates.items():
        d = (delta[0]-delta[1])[intact]
        e = ((base[0]-base[1])[intact]-target)
        scores[name] = {
            "intact": [*review.aligned(target,(base[0]-base[1])[intact]),*review.aligned(target,d)],
            "intact_rms":products(e,d),
            "flat_rms":products((base-exact)[good],delta[good]),
            "flat_added":products(np.zeros_like(delta[good]),delta[good]),
            "gap_exact":products((base[0]-exact[0])[is_gap],delta[0][is_gap]),
            "gap_added":products(np.zeros_like(delta[0][is_gap]),delta[0][is_gap]),
        }
    true = np.asarray(src["geometry"]["frequency"])
    assert tuple(np.sign(true[:,1]))==(1,-1)
    return {"id":f'{case["index"]:03d}-{case["noise"]}',"profile":case["noise"],"source_id":src["source"]["id"],
            "geometry":geom,"counts":[v[2]for v in views],"true_frequency":true.tolist(),
            "distance":np.linalg.norm(spacing-true,axis=-1).tolist(),"input":case["input"],
            "parent_output":evidence,"gap_pixels":int(is_gap.sum()),"products":scores}


def calibrate(rows):
    gains = {}
    for arm in ARMS:
        keys = ("intact_rms","gap_exact","flat_rms")
        groups = [[r["products"][arm][k]for r in rows if r["products"][arm][k][3]] for k in keys]
        results = []
        for d in np.linspace(0,1,101):
            change = [float(np.mean([rms_at(record,d)-rms_at(record,0)for record in g]))for g in groups]
            if change[1] <= .05 and change[2] <= .025:
                results.append((change[0],float(d),change[1],change[2]))
        gains[arm] = dict(zip(("increment_change","gain","gap_change","flat_change"),min(results),strict=True))
    return gains


def evaluate(row, gains):
    metrics = {}
    variants = [(k,k,1.)for k in ("distant","ring8","exterior-only")]
    variants.extend((arm,arm,e["gain"])for arm,e in gains.items())
    variants.extend((arm+"-full",arm,1.)for arm in ARMS)
    for label,mode,dose in variants:
        x = row["products"][mode]
        dot, power, extra, _ = x["intact"]
        metrics[label] = {name:rms_at(record,dose)for name,record in x.items()if name!="intact"}
        metrics[label].update({"intact_dot":dot+dose*extra,"intact_power":power})
    return row | {"metrics":metrics | {"matched":metrics["distant"]}}


def main():
    tick = time.monotonic()
    networks, binding = setup()
    passes = {}
    dataset = {}
    for label in ("wire-tune","wire"):
        dataset[label] = reference(PRIOR / f"{label}-parent.json")
        plan = read_json(checked(dataset[label]))
        items = read_json(checked(plan["inputs"]))["rows"]
        cases = {row["id"]:row for row in plan["rows"]}
        lengths = {"wire":48,"wire-tune":24}
        passes[label] = review.run(items,partial(observe,plan=read_json(checked(plan["plan"])),lookup=cases,models=networks))
        assert len(passes[label])==lengths[label]
    assert {r["source_id"]for r in passes["wire-tune"]}.isdisjoint(r["source_id"]for r in passes["wire"])
    dose = calibrate(passes["wire-tune"])
    scored = {p:[evaluate(row,dose)for row in passes["wire"]if row["profile"]==p]for p in ("iso400","iso6400")}
    earlier = reference(ROOT.parent/"bayer-distant-phase-gate-v1"/"wire-holdout.json")
    prior = {r["id"]:r for r in read_json(checked(earlier))["rows"]}
    for group in scored.values():
        for record in group:
            row = prior[record["id"]]
            assert record["input"]==row["input"] and record["parent_output"]==row["parent_output"]
            for method in ("distant","ring8","exterior-only"):
                for key in ("intact_rms","gap_exact","flat_rms"):
                    sample = record["metrics"][method][key]
                    if sample is not None:
                        assert abs(sample-row["metrics"][method][key]) < .002
    labels = [(name,old)for name in ("scale32","scale64","scale32-full","scale64-full")
              for old in ("distant","ring8")]
    labels += [("scale64","scale32"),("scale64-full","scale32-full")]
    metrics = ("intact_response","intact_rms","gap_exact","gap_added","flat_rms","flat_added")
    write_json(ROOT/"wire.json",binding | {"driver":reference(__file__),"operator":reference(ROOT/"restore.py"),
               "earlier":earlier,"inputs":dataset,"methods":list(ARMS),"gate_per_raw_green_fold":GATE,"dose":dose,
               "rows":passes,"reports":numeric(scored,labels,metrics),"wall_seconds":time.monotonic()-tick})


if __name__=="__main__":
    main()
