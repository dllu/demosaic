"""Preserve the source-bound Bayer scale study and native comparisons."""
import shutil
from pathlib import Path
import sys
import tarfile

import numpy as np
from PIL import Image, ImageChops
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name
OLDER = ROOT.parent/"bayer-distant-phase-gate-v1"
sys.path.insert(0,str(OLDER))
from review_gate import setup
from native_quiet import native_png


def copy_board(record, directory):
    source=checked(record["image"])
    directory.mkdir(exist_ok=True,parents=True)
    result=directory/source.name
    shutil.copyfile(source,result)
    assert reference(result)["sha256"]==record["image"]["sha256"]
    record["image"]["path"]=result.relative_to(IMAGES).as_posix()
    frames={}
    with Image.open(result)as image:
        for key in record["panels"]:
            x,y,w,h=key["png_xywh"]
            assert w==h==160 and image.width>=x+w and image.height>=y+h
            frames[key.get("label")or key["name"]]=image.crop((x,y,x+w,y+h))
    assert len(frames)==len(record["panels"])
    return frames


def native(checkpoint, known):
    pictures={}
    for family,n in (("exact",3),("standing",8)):
        raw=read_json(ROOT/family/"manifest.json")
        assert (raw["checkpoint"],raw["scale_calibration"],len(raw["rows"]))==(checkpoint,known,n)
        checked(raw["driver"])
        for row in raw["rows"]:
            path=IMAGES/family
            frames=copy_board(row["board"],path)
            if family=="exact":
                for trial in (row["triplet"],*row["other_triplets"].values()):
                    pieces=copy_board(trial,path)
                    assert len(pieces)==3
                    assert all(ImageChops.difference(frames[label],p).getbbox() is None for label,p in pieces.items())
            else:
                before,after=(frames[k]for k in ("Distant Bayer gate","64-pixel carrier fit"))
                delta=np.asarray(after,dtype=np.int16)-np.asarray(before,dtype=np.int16)
                row["display8_composed_change_rms"]=float(np.sqrt(np.mean(delta.astype(np.float64)**2)))
                row["display8_composed_codes_changed"]=int(np.count_nonzero(delta))
                if any(k in row["id"]for k in ("overcast-sky","building-detail","foliage")):
                    assert not np.any(delta)
                if row["id"]=="mesh-nominal-fine-green-mesh-right":
                    keep=("Distant Bayer gate","64-pixel carrier fit","ISO100 AHD reference")
                    representative=native_png(IMAGES/"cab-right-native-comparison.png",
                                                [(k,np.asarray(frames[k]))for k in keep])
                    representative["image"]["path"]="cab-right-native-comparison.png"
                    pictures["representative_cab"] = {"board":representative,"source":row["board"],
                                                        "profile":row["noise"],"case":row["id"]}
        pictures[family]=raw
    pictures["actual_viewing"]={"exact":3,"standing":8,
        "notes":"The 64-pixel fit makes both cab directions clearer, especially on the nominal right. Some crossings are visible; contrast looks overly regular in places and background mottling and incomplete intersections persist. Sky, foliage and building reproduce the frozen gate."}
    path=IMAGES/"manifest.json"
    write_json(path,pictures)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":reference(path)["sha256"]}


def main():
    _,parent=setup()
    OUT.mkdir(exist_ok=True)
    binding=reference(ROOT/"wire.json")
    measured=("wire","photo","gap-compare","absence","field","audit")
    records={k:read_json(ROOT/(k+".json"))for k in measured}
    for key,n in (("photo",96),("gap-compare",24),("absence",48)):
        info=records[key]
        assert info["checkpoint"]==parent["checkpoint"] and len(info["rows"])==n
        for row in info["rows"]:
            checked(row["input"])
            checked(row["parent_output"])
    assert records["wire"]["checkpoint"]==parent["checkpoint"]
    for rows in records["wire"]["rows"].values():
        for row in rows:
            checked(row["input"])
            checked(row["parent_output"])
    for proof in records.values():
        checked(proof["driver"])
    for dataset in records["field"]["inputs"].values():
        checked(dataset["config"])
        for bound in dataset["media"].values():
            checked(bound)
    papers=native(parent["checkpoint"],binding)
    files={k:ROOT/k for k in (
        "carrier_scale.py","restore.py","benchmark.py","apply_scale.py","render_scale.py","compare.py",
        "absence.py","audit.py","publish.py","tests.log","field.log","wire.log","photo.log",
        "gap-compare.log","absence.log","audit.log","exact.log","standing.log","exact/manifest.json","standing/manifest.json",
    )}
    files |= {key+".json":ROOT/(key+".json")for key in measured}
    archive=OUT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=4)as data:
        for k,p in sorted(files.items()):
            data.add(p,arcname=k,recursive=False)
    with tarfile.open(archive)as data:
        assert data.getnames()==sorted(files)
        for k,p in files.items():
            with data.extractfile(k)as stream:
                assert stream.read()==p.read_bytes()
    artifacts={k:reference(ROOT/(k+".json"))for k in measured}
    write_json(OUT/"publication.json",parent|{"driver":reference(__file__),"source_receipts":artifacts,
        "native_review":papers,"archive":{"path":archive.name,"sha256":reference(archive)["sha256"],"entries":len(files)},
        "dose":records["wire"]["dose"], "wire":records["wire"]["reports"]["iso6400"],
        "natural":records["photo"]["reports"]["iso6400"], "absence":records["absence"]["reports"]["iso6400"],
        "admitted_natural":sum(r["admission"]["admitted"]for r in records["photo"]["rows"]),
        "no_complete_donor_bank":sum("state"in r["admission"]for r in records["photo"]["rows"]),
        "scope":"Calibrated inference study. Synthetic and natural photo interventions and both standing GFX views. No new weight training or broad PSNR panels.",
    })


if __name__=="__main__":
    main()
