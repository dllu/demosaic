"""Test a larger, reserved-green fit with spacing nominated outside the crop."""
from pathlib import Path
import sys

import numpy as np

from carrier_scale import ROOT, far_geometry, nuisance, planes, regress, wave

sys.path.insert(0, str(ROOT.parent / "bayer-distant-phase-gate-v1"))
from review_gate import compose, setup, review

ARMS = ("scale32", "scale64")
ROI = (48, 48, 160, 160)
TEMPLATES = {size:nuisance(size, "smooth") for size in (32, 64)}
BLENDS = {size:np.outer(np.sin(np.pi*(np.arange(size)+.5)/size)**2,
                        np.sin(np.pi*(np.arange(size)+.5)/size)**2) for size in (32, 64)}


def unpack(packed):
    height, width = packed.shape[-2:]
    mosaic = np.empty((height*2,width*2), dtype=packed.dtype)
    for index, values in enumerate(packed):
        mosaic[index//2::2,index%2::2] = values
    return mosaic


def geometry(surround, layout, query, roi):
    x,y,w,_ = roi
    shape = (query[0]+x, query[1]+y, w)
    result, donors, measured = far_geometry(unpack(surround), layout, shape)
    spacing = np.asarray(result)
    consensus = (np.linalg.norm(np.asarray(measured)-spacing, axis=-1) <= .009).all(axis=1)
    # Both oblique fundamentals must be in the declared native band, and
    # one separate donor must have independently nominated the pair.
    band = np.linalg.norm(spacing,axis=-1)
    angle = abs(spacing[:,1]/spacing[:,0])
    admitted = bool(consensus.any() and np.all((band >= .077)&(band <= .195)&(angle >= .26)&(angle <= 3.8)))
    return spacing, admitted, {"frequencies_xy":spacing.tolist(),"donor_boxes":donors,
                               "pair_nominating_donors":int(consensus.sum()),"admitted":admitted}


def measured_patch(raw, parent, pattern, offset, design, carriers, noise, threshold):
    a,b = planes(pattern, offset)
    first = regress(raw, a, b, design, carriers, noise)
    second = regress(raw, b, a, design, carriers, noise)
    support = np.maximum(0,np.minimum(first["conditional_gain"],second["conditional_gain"])-threshold)
    gate = support / (support+6)
    if not gate.any():
        return np.zeros_like(raw), gate
    coefficients = (np.asarray(first["training_coefficients"]) + np.asarray(second["training_coefficients"]))*.5
    # Use the same nuisance projection to identify signal already present in
    # the restored green. The parent has seen all raw samples.
    joined = np.concatenate((design,carriers),axis=-1)
    estimate = joined.reshape(-1,joined.shape[-1])
    old = np.linalg.solve(estimate.T@estimate,estimate.T@parent.ravel())[-4:].reshape(2,2).T
    deficit = (coefficients-old)*gate[:,None]
    # Cap each delivered correction at the measured carrier power, including
    # cancellation of opposite-phase model artifacts.
    extent = np.linalg.norm(coefficients, axis=-1)
    power = np.linalg.norm(deficit, axis=-1)
    deficit *= np.minimum(1,extent/np.maximum(power,1e-10))[:,None]
    return (carriers@deficit.T.ravel()).astype(np.float32), gate


def correction(raw, parent, layout, wb, matrix, noise, spacing, roi, size, threshold, admitted):
    x,y,w,h = roi
    assert w==h==160
    if not admitted:
        return np.zeros_like(parent), [0,0]
    signal = np.zeros((w,h),dtype=np.float64)
    mass = np.zeros_like(signal)
    axes = np.minimum(np.arange(w)+.5,np.arange(w)[::-1]+.5)
    edge = np.minimum(1, axes/12)
    spatial, bands = BLENDS[size], wave(spacing,size)
    query_green = parent[1,y:y+h,x:x+w]
    mosaic = unpack(raw)[y:y+h,x:x+w]
    count = np.zeros(2,dtype=np.int64)
    for ty in range(0, w-size+1, size//2):
        for tx in range(0, w-size+1, size//2):
            region = np.s_[ty:ty+size,tx:tx+size]
            delta, gate = measured_patch(mosaic[region],query_green[region],layout,
                                        (x+tx,y+ty,size),TEMPLATES[size],bands,noise,threshold)
            signal[region] += delta*spatial
            mass[region] += spatial
            count += gate>0
    neutral = np.linalg.solve(matrix,np.ones(3))/wb
    unscaled = (signal/np.maximum(.02,mass))*edge[:,None]*edge[None,:]
    result = np.zeros_like(parent)
    result[:,y:y+h,x:x+w] = (neutral/neutral[1])[:,None,None] * unscaled
    return result, count.tolist()


def proposals(raw, layout, wb, matrix, noise, query, donors, parent, networks,
              spacing, roi, admitted, threshold, display_controls=False):
    predictions = compose(raw, layout, wb, matrix, noise, query, donors, parent, networks, False)
    base = predictions["distant"]
    pieces, counts = {}, {}
    for size, label in zip((32,64), ARMS, strict=True):
        pieces[label], counts[label] = correction(raw, base, layout, wb, matrix, noise, spacing, roi, size, threshold, admitted)
    if not display_controls:
        predictions = {k:predictions[k]for k in ("ring8","distant","exterior-only")}
    return predictions, pieces, counts
