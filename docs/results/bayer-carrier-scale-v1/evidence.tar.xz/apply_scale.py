"""Render and score the fixed calibrated scale fit using noisy RAW only."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np

from restore import ARMS, ROI, ROOT, geometry, proposals, setup as load_models, review
from benchmark import GATE
from review_gate import PRIOR
from review_quiet import LOCAL, photo_inputs, numeric
from demosaic.archive_metrics import photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CAPTIONS = {
    "Bayer-gated": "Bayer-gated refit", "ring8": "Eight-donor EMA",
    "distant": "Distant Bayer gate", "exterior-only": "Fixed exterior phase",
    "scale32": "32-pixel carrier fit", "scale64": "64-pixel carrier fit",
    "scale64-full": "64-pixel full dose",
}


def setup():
    models, receipt = load_models()
    calibration = reference(ROOT/"wire.json")
    output = read_json(checked(calibration))
    assert output["checkpoint"] == receipt["checkpoint"] and output["parent"] == receipt["parent"]
    doses = {key:v["gain"]for key,v in output["dose"].items()}
    return (models,doses), receipt | {"driver":reference(__file__),"scale_calibration":calibration,"scale_gains":doses}


def select(exterior, layout, box, roi):
    x,y,w,_ = roi
    sx,sy=box[0]+x,box[1]+y
    height,width=(d*2 for d in exterior.shape[-2:])
    if min(sx-128,sy-128,width-(sx+w+128),height-(sy+w+128))<0:
        return None,False,{"admitted":False,"state":"Incomplete four-donor bank at scene border"}
    return geometry(exterior,layout,box,roi)


def render_models(raw, layout, wb, matrix, noise, box, exterior, parent, model, roi=None):
    models,doses=model
    roi=ROI if roi is None else tuple(roi)
    spacing,ok,_=select(exterior,layout,box,roi)
    donors=review.exterior(exterior,layout,noise,box)
    head,adds,_ = proposals(raw,layout,wb,matrix,noise,box,donors,parent,models,spacing,roi,ok,GATE,True)
    results = head | {key:head["distant"]+np.float32(doses[key])*value for key,value in adds.items()}
    results["scale64-full"] = head["distant"]+adds["scale64"]
    return {key:results[key]for key in CAPTIONS}


def measures(pointer, model):
    test, data, parents, bound = photo_inputs(pointer)
    raw = data["scene_packed"]
    models,doses = model
    known = test["profile"]
    box = test["box"]
    spacing,ok,admission = select(raw,data["colors"][0],box,ROI)
    exterior = review.exterior(raw,data["colors"][0],known,box)
    prepared = [proposals(view,layout,wb,mat,known,box,exterior,parent,models,spacing,ROI,ok,GATE)
                for view,layout,wb,mat,parent in zip(data["packed"],data["colors"],data["wb"],
                                                   data["matrix"],parents[LOCAL],strict=True)]
    base = np.stack([v[0]["distant"]for v in prepared])
    predicted = parents | {"distant":base,"ring8":np.stack([v[0]["ring8"]for v in prepared]),
                           "exterior-only":np.stack([v[0]["exterior-only"]for v in prepared])}
    predicted |= {key:base+np.float32(doses[key])*np.stack([v[1][key]for v in prepared])for key in ARMS}
    predicted["scale64-full"] = base+np.stack([v[1]["scale64"]for v in prepared])
    band = lambda x:review.old.target_coeff(x,data,review.old.ROI)
    exact = band(data["target"])
    target = exact[0]-exact[1]
    anchor = band(base)
    exp = known["exposure"]
    fields = {}
    for key,x in predicted.items():
        f = band(x)
        delta = f[0]-f[1]
        d,p = review.aligned(target.ravel(),delta.ravel())
        fields[key] = {"intact_dot":d,"intact_power":p,"increment_rms":review.old.source_rms(delta-target,96**2),
                       "flat_rms":review.old.source_rms(f[2],96**2),
                       "flat_added":review.old.source_rms(f[2]-anchor[2],96**2),
                       "srgb_present_psnr":float(photometry(x/exp,data|{"target":data["target"]/exp})["srgb_psnr"][0])}
    return {"id":test["id"],"source_id":test["source"],"input":test["input"],"parent_output":bound,
            "profile":known["name"],"admission":admission,"counts":[v[2]for v in prepared],
            "metrics":fields|{"matched":fields["distant"]}}


def natural():
    tick=time.monotonic()
    model,binding=setup()
    previous=reference(ROOT.parent/"bayer-distant-phase-gate-v1"/"photo-holdout.json")
    old = {r["id"]:r for r in read_json(checked(previous))["rows"]}
    batch=read_json(checked(read_json(PRIOR/"natural-results.json")["inputs"]))["records"]
    eligible=[p for p in batch if Path(p["path"]).stem in old]
    assert len(eligible)==96
    result=review.run(eligible,partial(measures,model=model))
    for row in result:
        previous_row=old[row["id"]]
        assert row["input"]==previous_row["input"] and row["parent_output"]==previous_row["parent_output"]
        for case in ("distant","ring8","exterior-only"):
            for key in ("flat_rms","increment_rms"):
                assert abs(row["metrics"][case][key]-previous_row["metrics"][case][key])<.001
    groups={p:[r for r in result if r["profile"]==p]for p in ("iso400","iso6400")}
    fields=("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")
    labels=[(a,b)for a in ("scale32","scale64","scale64-full")for b in ("distant","ring8","V120","100k")]
    write_json(ROOT/"photo.json",binding|{"prior":previous,"rows":result,"reports":numeric(groups,labels,fields),
               "wall_seconds":time.monotonic()-tick})


if __name__=="__main__":
    natural()
