"""Publish the closed faint-ADC measurements and actual native comparisons."""

import datetime
import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
source = root.with_name("full427-faint-adc-v1")
report = root / "report/result.json"
r = read_json(report)
audit = root / "report/independent-audit.json"
a = read_json(audit)
assert a["status"] == "passed" and a["rows"] == 13664 and a["protection"] == []
assert read_json(root / "report-return.json")["returncode"] == 0
result = repo / "docs/results/full427-faint-adc-v1"
images = repo / "docs/images/full427-faint-adc-v1"
result.mkdir()
images.mkdir()
photo_notes = {
    "0014aa4e075b1827f91ef8a02069e1e318f040ba": "Fine strands near the brown tip are largely absent in the unprojected restorations. ADC-bin projection makes some of those strands visible again.",
    "002fc6eeadf637e81d5a327f117b79abb86becd9": "The building outline and balcony structure remain close. ADC-bin projection gives somewhat clearer thin lines with no visible new broad pattern.",
}
camera_notes = {
    "main-overcast-sky": "The two trained outputs are smooth. Chromatic grain is visible in the noisy view.",
    "main-building-detail": "Small cables and bracing remain softer than in the independent ISO100 reference.",
    "main-foliage": "Coarse leaves remain visible, with less fine texture than the independent reference.",
    "main-chain-link-fence": "Both outputs preserve the coarse diamonds. Thin wire edges remain softer than in the separate capture.",
    "mesh-nominal-fine-green-mesh-left": "Faint modulation and the green post are visible. Complete fine crossings remain missing; both JPEGs viewed.",
    "mesh-nominal-fine-green-mesh-right": "The cable remains visible, with an incomplete lattice in both outputs; both JPEGs viewed.",
    "mesh-profile3879-fine-green-mesh-left": "The alternate prior retains some diagonal modulation. Fine crossings remain softer than in the low-ISO reference; both JPEGs viewed.",
    "mesh-profile3879-fine-green-mesh-right": "Both outputs preserve faint diagonal modulation near the cable, without clearly resolving the reference crossings; both JPEGs viewed.",
}
entries = []
for b in r["native_images"]:
    assert b["id"] in photo_notes
    row = {}
    for kind in ("board", "triplet"):
        old = checked(b[kind]["image"])
        path = images / old.name
        shutil.copyfile(old, path)
        local = reference(path)
        assert local["sha256"] == b[kind]["image"]["sha256"]
        row[kind] = {"image": local, "panels": b[kind]["panels"]}
    entries.append({**b, **row, "viewed": True, "observation": photo_notes[b["id"]]})
real = []
legacy = read_json(checked(a["real_native_report"]))
for row in legacy["boards"]:
    if row["id"] in camera_notes:
        checked(row["image"])
        real.append(
            {
                **row,
                "viewed": True,
                "observation": camera_notes[row["id"]],
                "projection_identity_checked_for_both_models": True,
            }
        )
assert len(entries) == 2 and len(real) == 8
manifest = images / "manifest.json"
write_json(
    manifest,
    {
        "report": reference(report),
        "native_synthetic": entries,
        "retained_real": real,
        "viewed_at": datetime.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
    },
)
shutil.copyfile(audit, result / "independent-audit.json")
raw = result / "report.json.gz"
with (
    raw.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0, filename="") as out,
):
    out.write(report.read_bytes())
with gzip.open(raw, "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == reference(report)["sha256"]
bundle = result / "evidence.tar.gz"
parts = []
candidates = [p for p in root.glob("*") if p.suffix in (".py", ".json", ".log")]
candidates += list((root / "work").rglob("*.py"))
candidates += [
    source / "plan.json",
    source / "launch.json",
    source / "cohort.json",
    source / "collection.log",
    source / "analysis-protocol-clarification-v1.json",
    Path(r["collection"]["path"]),
]
candidates += sorted((source / "collection").glob("case-*.json"))
paths = sorted(set(p.resolve() for p in candidates))
with (
    bundle.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0, filename="") as gz,
    tarfile.open(fileobj=gz, mode="w") as tf,
):
    for p in paths:
        title = str(p.relative_to(repo))
        tf.add(p, arcname=title, recursive=False)
        parts.append({"member": title, **reference(p)})
with tarfile.open(bundle) as tf:
    for item in parts:
        assert hashlib.sha256(tf.extractfile(item["member"]).read()).hexdigest() == item["sha256"]
write_json(
    result / "publication.json",
    {
        "closed_analysis": reference(root / "numerical-complete.json"),
        "uncompressed_report": reference(report),
        "compressed_report": reference(raw),
        "independent_audit": reference(result / "independent-audit.json"),
        "native_manifest": reference(manifest),
        "native_boards_viewed": 10,
        "evidence": reference(bundle),
        "members": parts,
        "scope": "Faint ADC-only evaluation, separate from the standard 427-photo benchmark.",
    },
)
print(len(parts), len(entries), len(real), flush=True)
