"""Start the frozen faint-ADC analysis after its owned upstream closes."""
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json


queue_path = Path(sys.argv[1])
queue = read_json(queue_path)
verify_plan(queue)
assert reference(__file__) == queue["watcher"]
root = Path(queue["root"])
source = Path(queue["source"])
producer = read_json(checked(queue["producer_launch"]))
deadline = time.monotonic() + 12 * 3600
receipt = source / "collection/result.json"
while not receipt.exists():
    worker = psutil.Process(producer["pid"])
    if worker.create_time() != producer["create_time"] or worker.status() == psutil.STATUS_ZOMBIE:
        raise RuntimeError("Upstream identity changed before full result")
    if time.monotonic() >= deadline:
        raise TimeoutError("Upstream observation deadline expired")
    time.sleep(15)
artifact = reference(receipt)
result = read_json(checked(artifact))
assert result["plan"] == queue["source_plan"]
assert len(result["records"]) == 428
env = {**os.environ, "OPENBLAS_NUM_THREADS": "2", "OMP_NUM_THREADS": "2", "CUDA_VISIBLE_DEVICES": ""}
command = [sys.executable, str(checked(queue["reporter"])), str(source), str(root / "report")]
with (root / "report.log").open("xb") as log:
    child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    write_json(root / "report-launch.json", {"pid": child.pid,
               "create_time": psutil.Process(child.pid).create_time(),
               "source_receipt": artifact, "command": command})
    result = child.wait()
write_json(root / "report-return.json", {"returncode": result, "source_receipt": artifact})
if result:
    raise RuntimeError("Faint analysis failed with code " + str(result))
write_json(root / "numerical-complete.json", {
    "result": reference(root / "report/result.json"), "source_receipt": artifact,
    "scope": "All sources and four CFA observations scored under the fixed protocol."
             " Native viewing and publication are separate."
})
