"""Independently aggregate the closed faint-ADC panel and recheck real-input bypass."""

from collections import Counter, defaultdict
from math import fsum, sqrt
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from demosaic.adc_bins import adc_bin_projection
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
path = root / "report/result.json"
result = read_json(path)
complete = read_json(root / "numerical-complete.json")
assert complete["result"] == reference(path)
collection = read_json(checked(result["collection"]))
plan = read_json(checked(result["input_plan"]))
cohort = read_json(checked(result["source_cohort"]))
assert len(collection["records"]) == len(plan["observations"]) == 428
assert collection["root_calls"] == {"V120": {"root": 428}, "scale-control20k": {"root": 428}}
assert collection["models"] == plan["models"]
assert len(cohort["source_ids"]) == 427
assert len(result["rows"]) == 13664
patterns = {"RGGB", "BGGR", "GRBG", "GBRG"}
models = ("V120", "scale-control20k")
policies = ("raw", "existing-exact-Malvar", "existing-exact-sites", "ADC-bins-Malvar")
by_source = defaultdict(dict)
for row in result["rows"]:
    key = (row["model"], row["policy"], row["source"])
    assert row["CFA"] not in by_source[key]
    by_source[key][row["CFA"]] = row
assert len(by_source) == 427 * 8
assert all(set(v) == patterns for v in by_source.values())
assert set(s for m, p, s in by_source) == set(cohort["source_ids"])
index = {(r["model"], r["policy"], r["band"]): r for r in result["source_balanced_bands"]}
from_rows = defaultdict(dict)
photos = defaultdict(dict)
for (model, policy, source), values in by_source.items():
    photos[model, policy][source] = {
        name: fsum(r["photometry"][name] for r in values.values()) / 4
        for name in next(iter(values.values()))["photometry"]
    }
    for name in next(iter(values.values()))["band_sums"]:
        v = [r["band_sums"][name] for r in values.values()]
        assert all(r["blocks"] == v[0]["blocks"] for r in v)
        total = {k: fsum(r[k] for r in v) for k in v[0]}
        from_rows[model, policy, name][source] = {
            "blocks": v[0]["blocks"],
            "gain": total["cross"] / total["target"]
            if name != "quiet" and total["target"] > 0
            else None,
            "rms": sqrt(total["error"] / (total["blocks"] * 256)) * 65535,
        }
bands = []
for key, value in from_rows.items():
    retained = index[key]
    assert retained["source_count"] == len(value)
    assert retained["unique_blocks"] == sum(r["blocks"] for r in value.values())
    assert {r["source"] for r in retained["source_rows"]} == set(value)
    for row in retained["source_rows"]:
        item = value[row["source"]]
        assert row["unique_blocks"] == item["blocks"] and row["CFA_observations"] == 4
        np.testing.assert_allclose(row["error_RMS_DN16"], item["rms"], rtol=0, atol=2e-12)
        if item["gain"] is None:
            assert row["gain"] is None
        else:
            np.testing.assert_allclose(row["gain"], item["gain"], rtol=0, atol=2e-12)
    rms = fsum(r["rms"] for r in value.values()) / len(value)
    gain = fsum(r["gain"] for r in value.values()) / len(value) if key[2] != "quiet" else None
    np.testing.assert_allclose(rms, retained["equal_source_RMS_DN16"], rtol=0, atol=2e-12)
    bands.append(
        {
            "model": key[0],
            "policy": key[1],
            "band": key[2],
            "sources": len(value),
            "blocks": retained["unique_blocks"],
            "rms_DN16": rms,
            "gain": gain,
        }
    )
photo_means = []
for (model, policy), v in sorted(photos.items()):
    assert len(v) == 427
    baseline = photos[model, "raw"]
    keys = next(iter(v.values()))
    photo_means.append(
        {
            "model": model,
            "policy": policy,
            "source_count": len(v),
            **{k: fsum(row[k] for row in v.values()) / len(v) for k in keys},
            "srgb_sources_better_vs_raw": sum(
                v[s]["srgb_psnr"] > baseline[s]["srgb_psnr"] for s in v
            ),
            "weakest_band_sources_lower_error_vs_raw": sum(
                r["rms"] < from_rows[model, "raw", "0"][s]["rms"]
                for s, r in from_rows[model, policy, "0"].items()
            ),
        }
    )
means_by_policy = []
for p in policies:
    a, b = [photos[m, p] for m in models]
    pa, pb = [from_rows[m, p, "0"] for m in models]
    assert set(pa) == set(pb)
    means_by_policy.append(
        {
            "policy": p,
            "corpus_20k_srgb_psnr_gain": fsum(b[k]["srgb_psnr"] - a[k]["srgb_psnr"] for k in a)
            / len(a),
            "corpus_20k_srgb_sources_better": sum(b[k]["srgb_psnr"] > a[k]["srgb_psnr"] for k in a),
            "corpus_20k_weakest_band_sources_better": sum(pb[k]["rms"] < pa[k]["rms"] for k in pa),
        }
    )


def cell(image, p):
    x, y, w, h = p["png_xywh"]
    assert (w, h) == (160, 160)
    return image.crop((x, y, x + w, y + h)).tobytes()


native_checks = 0
for b in result["native_images"]:
    assert (
        b["ROI_xywh"] == [48, 48, 160, 160]
        and b["display_contrast"] == 20
        and b["display_exposure"] == 1
    )
    full = Image.open(checked(b["board"]["image"]))
    t = Image.open(checked(b["triplet"]["image"]))
    for i, p in zip((0, 3, 4), b["triplet"]["panels"], strict=True):
        assert cell(full, b["board"]["panels"][i]) == cell(t, p)
        native_checks += 1
legacy_path = Path("docs/results/full-corpus-control20k-review-v1/report.json").resolve()
legacy = read_json(legacy_path)
legacy_col = read_json(checked(legacy["collection"]))
legacy_producer = read_json(checked(legacy["plan"]))
legacy_records = {}
keep = {b["observation_id"] for b in legacy["boards"] if b["id"].startswith(("main-", "mesh-"))}
for v, ref in zip(legacy_producer["observations"], legacy_col["records"], strict=True):
    if v["id"] in keep:
        legacy_records[v["id"]] = (v, read_json(checked(ref)))
assert len(legacy_records) == 6
camera = []
for key, (source, record) in legacy_records.items():
    assert record["id"] == key and source["input_fingerprints"] == record["input_fingerprints"]
    with np.load(checked(source["arrays"])) as f:
        packed, cfa, wb = [torch.from_numpy(f[k]) for k in ("packed", "colors", "wb")]
    for v in record["variants"]:
        assert v["checkpoint"] == plan["models"][v["label"]]["checkpoint"]
        raw = torch.from_numpy(np.load(checked(v["prediction"])))
        noise = source["noise"]
        out = adc_bin_projection(
            raw,
            packed,
            cfa,
            wb,
            bit_depth=16,
            black_level=0.03,
            quantizer_precision="float64",
            shot=noise["shot"],
            read=noise["read"],
        )
        assert out is raw
        camera.append(
            {
                "id": key,
                "model": v["label"],
                "prediction": v["prediction"],
                "return_same_object": True,
            }
        )
assert len(camera) == 12 and native_checks == 6
write_json(
    root / "report/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "status": "passed",
        "rows": len(result["rows"]),
        "groups": len(by_source),
        "cohort": result["source_cohort"],
        "protection": cohort["training_overlap"],
        "photo_means": photo_means,
        "between_models": means_by_policy,
        "bands": sorted(bands, key=lambda x: (x["model"], x["policy"], x["band"])),
        "real_inputs_bypass": camera,
        "real_native_report": reference(legacy_path),
        "triplet_cells_rechecked": native_checks,
    },
)
print(len(result["rows"]), len(by_source), len(camera), native_checks, flush=True)
