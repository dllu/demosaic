from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
root=Path.cwd()/'.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
old=root.parent/'neural-nuisance-guided-phase129-pilot-v1'
assert read_json(root/'controller-result.json')['all_stages_succeeded']
current=read_json(root/'collection.json');before=read_json(old/'collection.json')
by_id={r['id']:r for r in before['rows']}
count=0
for row in current['rows']:
 prior=by_id[row['id']]
 for k in ['parent_values','packed_values','colors_values']:assert row[k]==prior[k]
 for method,binding in row['predictions'].items():
  if not method.startswith('H1-'):continue
  np.testing.assert_array_equal(np.load(checked(binding)),np.load(checked(prior['predictions'][method])))
  count+=1
assert count==288
write_json(root/'all-H1-control-parity.json',{'script':reference(__file__),'current':reference(root/'collection.json'),'baseline':reference(old/'collection.json'),'all48_actual_input_parent_fingerprints_exact':True,'H1_arrays_byte_exact_values':count,'new_neural_forwards':0,'scope':'All global/local raw-H1 outputs at fixed0/2/4 thresholds, including ADC; additional fine proposals alter phase arms only.'})
print(count,'H1 outputs exact')
