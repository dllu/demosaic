"""Prepare exact native review helpers; never inspect pending trial outputs."""
from pathlib import Path

repo = Path.cwd()
old = 'neural-nuisance-fine-phase129-pilot-v1'
new = 'neural-nuisance-fine-sinusoidal129-pilot-v1'
tools = []


def make(source, target, changes):
    text = (repo / '.cache' / source).read_text().replace(old, new)
    for a, b in changes:
        assert a in text, (source, a)
        text = text.replace(a, b)
    path = repo / '.cache' / target
    assert not path.exists()
    path.write_text(text)
    compile(text, str(path), 'exec')
    tools.append(path)


labels = [('Broad+fine A t2', 'Broad+fine H1 A t2'),
          ('Broad+fine NN t2', 'Broad+fine H1 NN t2')]
make('extra-neural-fine-phase129-stress-v1.py', 'extra-fine-sinusoidal129-stress-v1.py', labels)
make('analytic-fine-phase-triplets-v1.py', 'analytic-fine-sinusoidal129-triplets-v1.py', labels[:1])
make('fine-1600-triplets-v1.py', 'fine-sinusoidal129-1600-triplets-v1.py', labels[:1])
make('fine-phase-paired-boards-v1.py', 'fine-sinusoidal129-paired-boards-v1.py', [
    ('neural-nuisance-guided-phase129-pilot-v1', old),
    ('iso400', 'iso1600'), ('Broad-only A t2', 'Fine phase A t2'),
    ('Broad+fine A t2', 'Fine H1 A t2'),
    ('Analytic nuisance with the same own-color A-only NN guidance, original broad phase geometry/operator and support. Additional fine pair discovered after broad-design projection, separate A/B matching/support with broad carriers in fine nuisance.',
     'Common analytic nuisance and identical broad guided-phase correction/fine proposals. Fine phase versus local129/stride32 H1 full-fit carrier delivery, conditional full/null support, fixed global broad/background nuisance. Fine H1 has no phase/range/edge-side pooling; RGB coefficients independent. Not an isolated harmonic-only ablation.'),
])
make('fine-cab-before-after-v1.py', 'fine-sinusoidal129-cab-before-after-v1.py', [
    ('neural-nuisance-guided-phase129-pilot-v1', old),
    ("('Broad-only A t2',a,ap,'Guided analytic t2'),('Broad+fine A t2',b,bp,'Broad+fine A t2')",
     "('Fine phase A t2',a,ap,'Broad+fine A t2'),('Fine H1 A t2',b,bp,'Broad+fine H1 A t2')"),
    ('Four primary analytic broad-only/broad+fine comparisons', 'Four primary analytic fine-phase/fine-sinusoidal comparisons'),
])

source = (repo / '.cache/publish-neural-nuisance-fine-phase129-v1.py').read_text()
source = source.replace(old, new).replace('neural-nuisance-fine-phase129-v1', 'neural-nuisance-fine-sinusoidal129-v1')
start = source.index('extras = [')
stop = source.index('assert all(p.is_file()', start)
extras = ['tests/test_fine_carrier_proposals.py', '.cache/fine-sinusoidal-tests-v1.log',
          '.cache/fine-sinusoidal-tests-v2.log', '.cache/fine-sinusoidal-regression-v1.log',
          '.cache/fine-sinusoidal-regression-v2.log', '.cache/fine-sinusoidal-ruff-v1.log',
          '.cache/fine-sinusoidal-ruff-v2.log', '.cache/fine-sinusoidal-initial-conditional-source-v1.tar.gz',
          '.cache/launch-neural-nuisance-fine-sinusoidal129-v1.py',
          '.cache/launch-neural-nuisance-fine-sinusoidal129-v1.log',
          '.cache/prepare-neural-nuisance-fine-sinusoidal129-v1.log',
          '.cache/build-fine-sinusoidal-evidence-tools-v1.py',
          '.cache/prepare-fine-sinusoidal129-publication-v1.py',
          '.cache/publish-neural-nuisance-fine-sinusoidal129-v1.py',
          'scripts/audit_neural_nuisance_inputs.py']
for path in tools:
    extras.extend([str(path.relative_to(repo)), str(path.with_suffix('.log').relative_to(repo))])
source = source[:start] + 'extras = [R / name for name in ' + repr(extras) + ']\n' + source[stop:]
for a, b in labels:
    source = source.replace(a, b)
needle = 'assert len(figures)==38'
assert needle in source
source = source.replace(needle, "for figure in read_json(root/'analytic-1600-triplets/report.json')['figures']:copy_image(figure['image'],'triplets/'+Path(figure['image']['path']).name,figure)\nfor figure in read_json(root/'cab-before-after/report.json')['figures']:copy_image(figure['image'],'cab-before-after/'+Path(figure['image']['path']).name,figure)\nassert len(figures)==44")
source = source.replace('Paired boards compare analytic nuisance broad-only vs broad+fine, both with identical A-only neural guides at identical coordinates and display transforms.',
    'Paired1600 boards compare fine phase versus fine sinusoidal full-fit carrier delivery, with the identical broad guided-phase correction and fine proposals. Fine H1 has local129/stride32 amplitudes/conditional support after global nuisance, no fine phase/range/edge-side pooling. Separate RGB coefficients and identical RAW/parent map. Direct cab before/after includes independent ISO100 reference/JPEG, not GT.')
source = source.replace('Additional fine pair discovered after broad-design projection, separate A/B matching/support with broad carriers in fine nuisance.',
    'Common additional fine pair discovered after broad-design projection, retained above identical broad correction; fine delivery is sinusoidal full-fit carriers with conditional full/null support and identical RAW/parent carrier projection.')
path = repo / '.cache/publish-neural-nuisance-fine-sinusoidal129-v1.py'
assert not path.exists()
path.write_text(source)
compile(source, str(path), 'exec')
print('Prepared', len(tools) + 1, 'native evidence helpers without reading pending outputs')
