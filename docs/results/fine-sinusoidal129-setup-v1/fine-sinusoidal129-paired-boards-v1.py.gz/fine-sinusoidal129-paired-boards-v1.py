"""Two native paired waveform comparisons after all pilot outputs close."""
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from audit_checkpoint_pilot import crop
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
baseline = repo / '.cache/experiments/neural-nuisance-fine-phase129-pilot-v1'
assert read_json(root / 'controller-result.json')['all_stages_succeeded']
plan = read_json(root / 'plan.json')
records = {r['id']: r for r in read_json(root / 'collection.json')['rows']}
old_records = {r['id']: r for r in read_json(baseline / 'collection.json')['rows']}
old_rows = {r['id']: r for r in read_json(baseline / 'plan.json')['rows']}
output = root / 'waveform-paired'
output.mkdir()
figures = []
channels = 0
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 10)
for case in ['iso1600-index0008-role2', 'iso1600-index0024-role2']:
    row = next(r for r in plan['rows'] if r['id'] == case)
    assert row == old_rows[case]
    current, old = records[case], old_records[case]
    assert all(current[k] == old[k] for k in ['parent_values', 'packed_values', 'colors_values'])
    sample, roi = row['sample'], row['ROI_xywh']
    with np.load(checked(row['arrays']), allow_pickle=False) as z:
        data = {k: z[k][sample:sample+1] for k in ['packed','colors','wb','matrix']}
        gt = z['target'][sample:sample+1]
    values = [noisy_malvar(data), np.load(checked(row['parent']))[sample:sample+1],
              np.load(checked(old['predictions']['conditional-local-t2']))[None],
              np.load(checked(current['predictions']['conditional-local-t2']))[None], gt]
    labels = ['Noisy Malvar','V143','Fine phase A t2','Fine H1 A t2','Exact constructed GT']
    canvas = Image.new('RGB',(848,192),'#eee')
    draw = ImageDraw.Draw(canvas)
    panels = []
    for j, (label,value) in enumerate(zip(labels,values,strict=True)):
        cell = crop(value,data,roi,row['display_exposure'])
        x,y = 8+j*168,24
        assert cell.shape == (160,160,3)
        canvas.paste(Image.fromarray(cell),(x,y))
        draw.text((x,5),label,fill='black',font=font)
        panels.append({'label':label,'xywh':[x,y,160,160]})
    path = output / (case+'-paired.png')
    canvas.save(path)
    encoded = np.asarray(Image.open(path))
    for p,value in zip(panels,values,strict=True):
        x,y,w,h = p['xywh']
        np.testing.assert_array_equal(encoded[y:y+h,x:x+w],crop(value,data,roi,row['display_exposure']))
        channels += w*h*3
    figures.append({'image':reference(path),'panels':panels,'source':row,
        'ROI_xywh':roi,'display_exposure':row['display_exposure'],'display_contrast':1,
        'no_resize':True,'previous_prediction':old['predictions']['conditional-local-t2'],
        'current_prediction':current['predictions']['conditional-local-t2']})
write_json(output/'report.json',{'script':reference(__file__),'figures':figures,
    'RGB_channels_exact':channels,'baseline_model':reference(baseline/'analytic-model.json'),
    'current_model':reference(root/'analytic-model.json'),'new_neural_forwards':0,
    'scope':'Common analytic nuisance and identical broad guided-phase correction/fine proposals. Fine phase versus local129/stride32 H1 full-fit carrier delivery, conditional full/null support, fixed global broad/background nuisance. Fine H1 has no phase/range/edge-side pooling; RGB coefficients independent. Not an isolated harmonic-only ablation. Raw inputs/parent/ROI/calibration/exposure identical; no new NN/RAW/noise observations.'})
print('paired boards',len(figures),'exact channels',channels)
