"""Preserve immutable admission/source evidence while the new pilot runs."""
import gzip
import io
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
root = repo / '.cache/experiments/neural-nuisance-fine-sinusoidal129-pilot-v1'
destination = repo / 'docs/results/fine-sinusoidal129-setup-v1'
destination.mkdir(exist_ok=False)
files = [root / n for n in [
    'plan.json', 'analytic-model.json', 'study.json', 'controller.py', 'launch.json',
    'audit_neural_nuisance_inputs.py', 'followup/plan.json', 'followup/controller.py',
    'followup/review_neural_nuisance.py', 'followup/launch.json',
    'evidence-queue.json', 'evidence-queue-launch.json',
    'backgrounds-collection.json', 'background-independent-audit.json',
]]
files += [repo / n for n in [
    'tests/test_fine_carrier_proposals.py',
    '.cache/fine-sinusoidal-tests-v1.log', '.cache/fine-sinusoidal-tests-v2.log',
    '.cache/fine-sinusoidal-regression-v1.log', '.cache/fine-sinusoidal-regression-v2.log',
    '.cache/fine-sinusoidal-ruff-v1.log', '.cache/fine-sinusoidal-ruff-v2.log',
    '.cache/fine-sinusoidal-initial-conditional-source-v1.tar.gz',
    '.cache/prepare-neural-nuisance-fine-sinusoidal129-v1.log',
    '.cache/launch-neural-nuisance-fine-sinusoidal129-v1.py',
    '.cache/launch-neural-nuisance-fine-sinusoidal129-v1.log',
    '.cache/build-fine-sinusoidal-evidence-tools-v1.py',
    '.cache/build-fine-sinusoidal-evidence-tools-v1.log',
    '.cache/prepare-fine-sinusoidal129-publication-v1.py',
    '.cache/fine-sinusoidal129-H1-parity-v1.py',
    '.cache/fine-sinusoidal129-scene-maxima-v1.py',
    '.cache/archive-fine-sinusoidal129-setup-v1.py',
]]
queue = read_json(root / 'evidence-queue.json')
files += [Path(s['script']['path']) for s in queue['stages']]
archives = []
for p in dict.fromkeys(files):
    name = str(p.relative_to(root) if root in p.parents else p.name).replace('/', '--')
    dest = destination / (name + '.gz')
    with dest.open('xb') as stream:
        stream.write(gzip.compress(p.read_bytes(), mtime=0))
    assert gzip.decompress(dest.read_bytes()) == p.read_bytes()
    archives.append({'original': reference(p), 'published': reference(dest), 'decompressed_bytes_exact': True})
members = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for p in sorted((root / 'work').rglob('*.py')):
        name = str(p.relative_to(root / 'work'))
        data = p.read_bytes()
        assert data == (repo / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
        members.append({'member': name, 'original': reference(p)})
path = destination / 'frozen-source.tar.gz'
with path.open('xb') as stream:
    stream.write(gzip.compress(buffer.getvalue(), mtime=0))
with tarfile.open(path, 'r:gz') as tar:
    for m in members:
        assert tar.extractfile(m['member']).read() == Path(m['original']['path']).read_bytes()
write_json(destination / 'publication.json', {
    'plan': reference(root / 'plan.json'), 'model': reference(root / 'analytic-model.json'),
    'archives': archives, 'frozen_source': {'archive': reference(path), 'members': members},
    'status': 'admitted and running; no quality outcome claimed',
    'scope': 'Immutable all48 source/config/input admission,88 adopted fields with0 new NN calls, '
        'initial coloured conditional-delivery failure/source and corrected210-pass regression. '
        'Seven-stage44-figure evidence queue waits exact owners and successful all48 closure; '
        'actual viewing/final publication remain required. Separate full guided run untouched.',
})
print(len(archives), 'exact admission/queue/test archives;', len(members), 'frozen Python sources')
