"""Verify source-disjoint 64-photo monitor and reduce paired metric intervals."""
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import json
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

BASE = Path(__file__).resolve().parent
ROOT = BASE/"review-050000/evaluation"
OUT = Path("docs/results/scene-050000-controlled-v1")
IMAGES = Path("docs/images/scene-050000-controlled-v1")
EXPERIMENTS = (
    ("none","100k"),
    ("none","V120"),
    ("spatial/matching","none"),
    ("spatial/matching","spatial/wrong-distant"),
    ("spatial/matching","spatial/blur-distant"),
    ("spatial/matching","spatial/neutral"),
)
VIEWING = {
    "000-iso6400-independent-role0": "The stone edges and dark niches stay coherent. Fine local grain is softened by both arms, and faint mottling remains.",
    "000-iso6400-independent-role2": "The exact-flat center remains nearly smooth. The boundary retains some low-frequency tone variation.",
    "001-iso6400-independent-role0": "Both arches remain visible. Fine masonry at the sill stays soft, with little visible change from swapping the distant view.",
    "001-iso6400-independent-role2": "The brown center remains smooth and the surroundings keep their masonry and roofline. Neither arm introduces arches inside the flat patch.",
}


def compare(rows, left, right):
    rng = np.random.default_rng(665545)
    size = len(rows)
    assert size >= 20
    draw = np.vstack([np.arange(size), rng.integers(size,size=(7500,size))])
    metrics = defaultdict(dict)
    for band_name in ("lower","fine","upper"):
        for arm in (left,right):
            band = [r["metrics"][arm]["band"][band_name] for r in rows]
            for key in ("increment_RMS_DN16","quiet_RMS_DN16","present_RMS_DN16"):
                array = np.asarray([row[key] for row in band])
                metrics[(band_name,key)][arm] = array[draw].mean(1)
            match = np.asarray([row["aligned_increment_dot"] for row in band])[draw].sum(1)
            energy = np.asarray([row["exact_paired_increment_sq"] for row in band])[draw].sum(1)
            metrics[(band_name,"pooled_response_pp")][arm] = 100 * match / energy
    for arm in (left,right):
        for key in ("quiet_RGB_mean_absolute_bias_DN16","quiet_RGB_centered_RMS_DN16"):
            values = np.asarray([r["metrics"][arm]["uniform_core"][key] for r in rows])
            metrics[("uniform",key)][arm] = values[draw].mean(1)
    result = defaultdict(dict)
    for (band,key), vals in metrics.items():
        gap = vals[left]-vals[right]
        result[band][key] = dict(left=float(vals[left][0]),right=float(vals[right][0]),
            delta=float(gap[0]),interval=np.quantile(gap[1:],[.025,.975]).tolist())
    return result


def stratify_fine_amplitude(rows):
    """Use clean target energy for reporting only. Each stratum is held-out."""
    assert len(rows)==64

    def amplitude(row):
        energy = row["metrics"]["none"]["band"]["fine"]["exact_paired_increment_sq"]
        return np.sqrt(energy) * 65535 / 96

    ordered = sorted(rows, key=lambda row: (amplitude(row), row["source"]))
    subsets = (ordered[:22],ordered[22:43],ordered[43:])
    return {
        group: dict(sources=[row["source"] for row in subset],
            target_fine_RMS_DN16_range=[float(amplitude(subset[0])),float(amplitude(subset[-1]))],
            matching_vs_local=compare(subset,"spatial/matching","none")["fine"],
            matching_vs_wrong=compare(subset,"spatial/matching","spatial/wrong-distant")["fine"])
        for group,subset in zip(("faint","middle","strongest"),subsets,strict=True)
    }


def publish_views(boards, checkpoints, source):
    IMAGES.mkdir()
    viewed = []
    for row in boards:
        proof = dict(row)
        proof["actual_viewing"] = VIEWING[row["id"]]
        for kind in ("board","triplet"):
            image = checked(proof[kind]["image"])
            path = IMAGES/image.name
            shutil.copyfile(image,path)
            assert reference(path)["sha256"]==proof[kind]["image"]["sha256"]
            with Image.open(path) as png:
                for panel in proof[kind]["panels"]:
                    x,y,w,h=panel["png_xywh"]
                    assert w==h==160 and x+w<=png.width and y+h<=png.height
            proof[kind]=proof[kind]|{"image":proof[kind]["image"]|{"path":path.name}}
        viewed.append(proof)
    assert {row["id"] for row in viewed}==set(VIEWING)
    manifestation=IMAGES/"manifest.json"
    write_json(manifestation,dict(viewed_local=datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        checkpoints=checkpoints, source=source, scope="Actual native review of four 160-pixel comparisons.",
        boards=viewed))
    return reference(manifestation)


def main():
    file = reference(ROOT/"results.json")
    product = read_json(checked(file))
    experiment = read_json(checked(product["plan"]))
    catalog = read_json(checked(experiment["panel"]))
    training_ref = reference("docs/results/scene-full-epoch-v1/paired-prefix-050000.json")
    training = read_json(checked(training_ref))
    assert experiment["training_snapshot"]==training["matched_marker"]
    opts = read_json(checked(training["plan"]))
    for mode in ("none","spatial"):
        checkpoint = training["arms"][mode]["checkpoint"]
        assert all(experiment["models"][mode][k]==v for k,v in checkpoint.items())
    training_ids = {json.loads(line)["id"]for line in checked(opts["train_manifest"]).read_text().splitlines()}
    cohort = {row["source"]["id"] for row in catalog["rows"]}
    assert len(cohort)==64 and cohort.isdisjoint(training_ids)
    rows = product["source_metrics"]
    assert len(rows)==len(product["native"])*64==256
    assert Counter(row["source"]for row in rows)==dict.fromkeys(cohort,4)
    panel_keys=defaultdict(list)
    for row in rows:
        source = read_json(checked(row["prediction_receipt"]))
        capture = read_json(checked(source["case"]))
        assert source["plan"]==product["plan"]
        assert capture["plan"]==experiment["panel"] and capture["source"]==row["source"]
        assert (capture["profile"]["name"],capture["draw"])==(row["profile"],row["draw"])
        assert source["exact_query_inputs"]=={k:capture["fingerprints"][k]for k in
            ("packed","variance","colors","wb","matrix")}
        checked(source["saved"])
        panel_keys[row["profile"],row["draw"]].append(row)
    assert set(panel_keys)=={(a,b)for a in ("iso400","iso6400")for b in ("coupled","independent")}
    all_results={f"{profile}-{law}":{
            f"{left} vs {right}":compare(pool,left,right)for left,right in EXPERIMENTS
        }for (profile,law),pool in panel_keys.items()}
    OUT.mkdir()
    views=publish_views(product["native"],experiment["models"],file)
    archive=OUT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=4) as tar:
        for name,binding in {
            "monitor-results.json":file,"monitor-plan.json":product["plan"],
            "collection.json":product["collection"],"panel.json":experiment["panel"],
            "publication.py":reference(__file__),"monitor.py":experiment["monitor"],
            "metric-code.py":experiment["metrics_driver"],"collector.py":experiment["source"],
            "native-manifest.json":views,
        }.items():
            tar.add(checked(binding),arcname=name)
        for row in rows:
            p=checked(row["prediction_receipt"])
            tar.add(p,arcname="predictions/"+p.name)
    write_json(OUT/"publication.json",dict(
        training=training_ref, endpoint_results=file, archive=reference(archive),
        endpoint_models=experiment["models"], scopes={"sources":64,"matched_cases":256,
            "independent_capture_pairs":128,"coupled_capture_pairs":128,"native_queries_each_model":768},
        exact_observations_verified=True, training_source_overlap=[], summary=all_results,
        independent_iso6400_clean_fine_amplitude_tertiles=stratify_fine_amplitude(
            panel_keys["iso6400","independent"]
        ),
        original_means=product["pooled"], native_boards=views,
        actual_viewing_complete=True,
    ))
    print("Paired monitor confirmed",len(rows),len(cohort), flush=True)

if __name__ == "__main__":
    main()
