"""Score fixed-donor occlusion replays and render the standing camera crops."""

import importlib.util
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, insert_camera_panels
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SUMMARY = ROOT.parent / "affinity-first-fresh-v3/review.py"
SCORER = importlib.util.spec_from_file_location("closed_occlusion_scoring", SUMMARY)
SCORING = importlib.util.module_from_spec(SCORER)
SCORER.loader.exec_module(SCORING)
LABELS = {
    "parent": "V143 EMA",
    "whole": "Whole donor",
    "local": "Local donor",
    "unequal": "Unequal local",
    "query": "Query-screened",
}


def distance(fit, known):
    f = np.asarray(fit.get("frequencies_xy", [[0, 0], [0, 0]]))[fit["active"]]
    if not len(f):
        return [None, None]
    return (
        np.minimum(
            np.linalg.norm(f[:, None] - known, axis=-1), np.linalg.norm(f[:, None] + known, axis=-1)
        ).min(axis=0)
        * 256
    ).tolist()


def synth(plan, done, out):
    rows, diagnoses, boards = [], [], []
    for item in done["synthetic"]:
        c = read_json(checked(item["case"]))
        c["prediction"] = item["prediction"]
        recipe = c["metadata"]["recipe"]
        angles = np.asarray(recipe["wire_angles"])
        known = (
            np.stack((np.cos(angles), np.sin(angles)), 1) / np.asarray(recipe["periods"])[:, None]
        )
        role2 = item["role2_fits"] if "role2_fits" in item else item["fits"]
        diagnoses.append(
            {
                "id": item["id"],
                "profile": c["profile"],
                "appearance": c["appearance"],
                "center_error_native_bins": {
                    arm: distance(fit, known) for arm, fit in role2.items()
                },
                "edge_control": {
                    arm: any(fit["active"]) for arm, fit in item["edge_control"]["fits"].items()
                }
                if item["edge_control"]
                else None,
            }
        )
        for split in item["donors"]:
            with (
                np.load(checked(split["raw"])) as x,
                np.load(checked(split["source"])) as a,
                np.load(checked(split["occluder"])) as b,
            ):
                px, py, w, h = split["remaining_surface_xywh"]
                sl = np.s_[..., py // 2 : (py + h) // 2, px // 2 : (px + w) // 2]
                expected = b["packed"].copy()
                expected[sl] = a["packed"][sl]
                np.testing.assert_array_equal(expected, x["packed"])
        rows.append(c)
        if (c["profile"], c["source"]) in (("iso400", 88), ("iso400", 89)):
            p, gt, _, pred = SCORING.load(c)
            s = plan["settings"][c["profile"]]["scale"]
            with np.load(checked(c["sensor"])) as f:
                ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
                ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
            parent = p[2][ROI]
            boards.append(
                native_board(
                    out,
                    c["id"],
                    [
                        noisy_malvar(ctx)[0],
                        *(parent + s * (pred[arm][2] - parent) for arm in plan["arms"]),
                        gt[2][ROI],
                    ],
                    ctx,
                    {
                        "case_receipt": item["case"],
                        "CFA": c["CFA"],
                        "noise": c["metadata"]["noise"],
                        "checkpoint": plan["parent_checkpoint"],
                        "setting": plan["settings"][c["profile"]],
                    },
                    labels=["Noisy Malvar", *(LABELS[arm] for arm in plan["arms"]), "Exact GT"],
                    triplet_indices=(0, len(plan["arms"]), len(plan["arms"]) + 1),
                    contrast=5,
                )
            )
    groups = []
    for profile, settings in plan["settings"].items():
        for paint in ("all", "same-paint", "distinct"):
            subset = [
                c
                for c in rows
                if c["profile"] == profile and (paint == "all" or c["appearance"] == paint)
            ]
            groups.append(
                {"profile": profile, "paint": paint, "count": len(subset)}
                | SCORING.score(subset, plan["arms"], settings["scale"])
            )
    return groups, diagnoses, boards


def camera(plan, done, out):
    baseline = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    rows = []
    for old, new in zip(baseline, done["camera"], strict=True):
        key, source = old["id"], old["source"]
        assert key == new["id"]
        x, y, width, height = old["ROI_xywh"]
        ox, oy, *_ = source["query_box"]
        crop = np.s_[:, y - oy : y - oy + height, x - ox : x - ox + width]
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        with np.load(checked(new["appearance_first"])) as f:
            before = f["corrected"]
        with np.load(checked(new["predictions"])) as f:
            cl = dict(f)
        parent = np.load(checked(source["parent_prediction"]), mmap_mode="r")[
            0, :, y : y + height, x : x + width
        ]
        np.testing.assert_array_equal(cl["parent"][crop], parent)
        added = []
        for label, px in [
            ("Scene affinity", before),
            *((LABELS[arm], cl[arm]) for arm in plan["arms"][1:]),
        ]:
            image = display(px[None], ctx, exposure=old["display_exposure"])[0][crop]
            added.append((label, np.rint(image.transpose(1, 2, 0) * 255).astype(np.uint8)))
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        image, locations = insert_camera_panels(
            out, key, old | {"panels": panels}, "V120 EMA", added
        )
        absolute_x, absolute_y, *_ = source["absolute_query_xywh"]
        distances = {
            arm: {
                "vs_parent_DN16": float(
                    np.sqrt(np.mean((v[crop].astype(np.float64) - parent) ** 2)) * 65535
                ),
                "vs_affinity_DN16": float(
                    np.sqrt(np.mean((v[crop].astype(np.float64) - before[crop]) ** 2)) * 65535
                ),
            }
            for arm, v in cl.items()
        }
        rows.append(
            {
                "id": key,
                "image": image,
                "panels": locations,
                "distance": distances,
                "fits": new["fits"],
                "noise": noise[key],
                "display_exposure": old["display_exposure"],
                "ROI_xywh": [x - ox + absolute_x, y - oy + absolute_y, width, height],
                "checkpoint": source["checkpoint"],
                "arrays": source["query_arrays"],
                "predictions": new["predictions"],
                "old_affinity": new["appearance_first"],
                "camera_inputs": plan["photos"]["main" if key.startswith("main-") else "mesh"],
            }
        )
    return rows


def main():
    receipt = ROOT / "output/collection.json"
    done = read_json(receipt)
    plan = read_json(checked(done["plan"]))
    out = ROOT / "review"
    out.mkdir()
    aggregates, diagnostics, boards = synth(plan, done, out)
    cams = camera(plan, done, out)
    write_json(
        out / "result.json",
        {
            "producer": reference(__file__),
            "collection": reference(receipt),
            "scoring_code": reference(SUMMARY),
            "aggregates": aggregates,
            "diagnostics": diagnostics,
            "boards": boards,
            "camera": cams,
            "edge_only_activations": {
                arm: sum(
                    bool(v["edge_control"] and v["edge_control"].get(arm, False))
                    for v in diagnostics
                )
                for arm in plan["arms"][1:]
            },
            "available_edge_controls": sum(v["edge_control"] is not None for v in diagnostics),
        },
    )


if __name__ == "__main__":
    main()
