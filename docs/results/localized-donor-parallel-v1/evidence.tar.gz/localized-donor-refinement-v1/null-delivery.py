"""Apply retained edge-only donor guides to a held-out no-wire query."""

from pathlib import Path

import numpy as np
from probe_donor_phase_geometry import sensor_box
from probe_localized_donor_support import deliver_options
from probe_screened_scene_donors import offset_box
from report_fold_support_pooling import ROI

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

root = Path(__file__).resolve().parent
source = root / "output/collection.json"
result = read_json(source)
plan = read_json(checked(result["plan"]))
query = offset_box(plan["query_xywh"])
cfg = LocalWaveConfig(**plan["config"])
rows = []
for item in result["synthetic"]:
    if item["edge_control"] is None:
        continue
    case = read_json(checked(item["case"]))
    profile = case["profile"]
    noise = plan["profiles"][profile]
    setting = plan["settings"][profile]
    packed, colors = sensor_box(case["sensor"], plan["query_xywh"])
    with np.load(checked(case["parent"])) as archive:
        parent = archive["parent"][0][ROI]
    with np.load(checked(case["target"])) as archive:
        quiet = archive["quiet"][ROI]
        truth = archive["target"][0][ROI].astype(np.float64)
    outputs = deliver_options(
        parent,
        packed[0],
        colors[0],
        item["edge_control"]["fits"],
        query,
        noise,
        cfg,
        setting["threshold"],
    )
    measured = {}
    for name, pixels in outputs.items():
        added = (pixels.astype(np.float64) - parent) * setting["scale"]
        measured[name] = {
            "correction_rms_DN16": float(np.sqrt(np.mean(added**2)) * 65535),
            "quiet_correction_rms_DN16": float(np.sqrt(np.mean(added[..., quiet] ** 2)) * 65535),
            "quiet_target_RMS_DN16": float(
                np.sqrt(np.mean((parent + added - truth)[..., quiet] ** 2)) * 65535
            ),
        }
    rows.append({"id": item["id"], "case": item["case"], "outputs": measured})
write_json(
    root / "null-delivery.json",
    {
        "producer": reference(__file__),
        "source": reference(source),
        "rows": rows,
        "scope": "Four retained edge-only donor brackets composed with the original independent background role. "
        "Noise thresholds and fixed scaling are unchanged. These are measured final deltas.",
    },
)
