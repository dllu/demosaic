"""Stress the donor gate with independent noise on flats, edges and narrow rails."""

from collections import Counter
from itertools import product
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import reference, write_json
from demosaic.localized_donor_geometry import localize_donor_geometry

ROOT = Path(__file__).resolve().parent
SIZE = 128
BOXES = [(-128, 0, SIZE, SIZE), (128, 0, SIZE, SIZE)]
QUERY = (0, 0, SIZE, SIZE)
COLORS = np.array([0, 1, 1, 2])
ISO = {"iso400": (8e-5, 2.56e-8), "iso6400": (0.00128, 6.5536e-6)}
SEED = 202611172019
TRIALS = 12


def observation(index, a, b, style, kind, noise):
    yy, xx = np.indices((SIZE, SIZE)) - SIZE / 2 + 0.5
    rng = np.random.default_rng(np.random.SeedSequence([SEED, *index]))
    cfa = np.tile(COLORS.reshape(2, 2), (SIZE // 2, SIZE // 2))
    edge = np.zeros((SIZE, SIZE))
    if style != "flat":
        for sx, sy in product(np.linspace(-0.4, 0.4, 5), repeat=2):
            d = a * (xx + sx) + b * (yy + sy) - kind["shift"] + rng_offset(index[-1])
            above = d > 0
            edge += (above if style == "step" else (above & (d < kind["rail_width"]))) / 25
    sensor = (kind["level"] + edge * kind["contrast"]) * np.array([0.84, 1, 0.79])[cfa]
    shot, read = noise
    sampled = rng.poisson(sensor / shot) * shot + rng.normal(0, np.sqrt(read), sensor.shape)
    quantized = np.rint(np.clip(sampled + 0.03, 0, 1) * 65535) / 65535 - 0.03
    return (
        quantized.reshape(SIZE // 2, 2, SIZE // 2, 2)
        .transpose(1, 3, 0, 2)
        .reshape(4, SIZE // 2, SIZE // 2)
    )


def rng_offset(role):
    return [0.0, -3.25, 4.25][role]


def collect():
    rows = []
    tallies = Counter()
    for (iso_i, (label, noise)), (geom_i, style), trial in product(
        enumerate(ISO.items()), enumerate(("flat", "step", "rail")), range(TRIALS)
    ):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 100, geom_i, trial]))
        angle = rng.uniform(0.02, np.pi - 0.02)
        kind = {
            "shift": float(rng.uniform(-30, 30)),
            "rail_width": float(rng.uniform(5, 17)),
            "level": float(rng.uniform(0.028, 0.065)),
            "contrast": float(rng.uniform(0.06, 0.19)),
        }
        samples = [
            observation(
                [iso_i, geom_i, trial, role], np.cos(angle), np.sin(angle), style, kind, noise
            )
            for role in range(3)
        ]
        donors = [(v, COLORS, box) for v, box in zip(samples[1:], BOXES, strict=True)]
        shot, read = noise
        opts = {"shot": shot, "read": read}
        values = {
            "parallel": localize_donor_geometry(
                donors, QUERY, unequal=True, refined_edge=True, parallel_edge=True, **opts
            )
        }
        for arm, fit in values.items():
            tallies[label, style, arm] += any(fit["active"])
        rows.append(
            {
                "iso": label,
                "style": style,
                "trial": trial,
                "angle_rad": float(angle),
                "parameters": kind,
                "fits": values,
            }
        )
        if len(rows) % 12 == 0:
            print(len(rows), label, style, flush=True)
    write_json(
        ROOT / "null-parallel.json",
        {
            "producer": reference(__file__),
            "plan": reference(ROOT / "plan.json"),
            "seed": SEED,
            "trial_count_per_pair": TRIALS,
            "false_guide_counts": {" / ".join(k): v for k, v in tallies.items()},
            "rows": rows,
            "scope": "Independent oblique edge and rail-band nulls, area-averaged on a 5-by-5 pixel grid. "
            "Poisson/read noise and ADC rounding with separately keyed draws for both donors and query. "
            "A recorded activation credits the donor gate only. No output synthesis or quality claim.",
        },
    )


if __name__ == "__main__":
    collect()
