"""Publish the native boards and source-bound results of the donor replay."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
cache = root.parent
images = Path.cwd() / "docs/images" / root.name
results = Path.cwd() / "docs/results" / root.name
images.mkdir(exist_ok=True)
results.mkdir(exist_ok=True)

review = read_json(root / "review/result.json")
collection = read_json(checked(review["collection"]))
plan = read_json(checked(collection["plan"]))
assert len(review["boards"]) == 2 and len(review["camera"]) == 8
assert review["retained_arrays_bit_exact"] == 144 and collection["neural_calls"] == 0


def publish_image(binding):
    source = checked(binding)
    output = images / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return source.name


synthetic = []
for row in review["boards"]:
    synthetic.append({
        **row,
        **{
            key: row[key] | {"file": publish_image(row[key]["image"])}
            for key in ("board", "triplet")
        },
    })
camera = []
for row in review["camera"]:
    main = row["id"].startswith("main-")
    camera.append({
        **{key: value for key, value in row.items() if key not in ("fits", "predictions")},
        "file": publish_image(row["image"]),
        "camera_id": "Fujifilm GFX100S",
        "CFA": "RGGB",
        "full_raw": plan["photos"]["main" if main else "mesh"],
        "reference_capture": "DSCF3880 ISO100 AHD" if main else
        "DSCF3835 ISO100 AHD and both DSCF3842/DSCF3835 camera JPEGs",
    })
manifest = images / "manifest.json"
write_json(manifest, {
    "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
    "native_viewing_layouts": read_json(root / "native-view/items.json"),
    "synthetic": synthetic,
    "camera": camera,
    "scope": "Ten native comparison boards and two separate native triplets were inspected. "
    "The camera AHD and JPEG columns are independent qualitative references.",
})

summary = results / "summary.json"
write_json(summary, {
    "source": reference(root / "review/result.json"),
    "scoring_code": review["scoring_code"],
    "plan": collection["plan"],
    "collection": review["collection"],
    "run_cpu_wall_seconds": collection["seconds"],
    "neural_calls": collection["neural_calls"],
    "retained_arrays_bit_exact": review["retained_arrays_bit_exact"],
    "aggregates": review["aggregates"],
    "original_edge_controls": review["edge_only_activations"],
    "camera": [
        {key: row[key] for key in ("id", "ROI_xywh", "checkpoint", "noise", "distance")}
        for row in review["camera"]
    ],
})
earlier = cache / "localized-donor-refinement-v1"
null_paths = {n: earlier / f"null-{n}.json" for n in ("panel", "parallel", "delivery")}
null = {key: read_json(path) for key, path in null_paths.items()}
identity = ("iso", "style", "trial", "angle_rad", "parameters")
assert [
    tuple(row[key] for key in identity) for row in null["panel"]["rows"]
] == [
    tuple(row[key] for key in identity) for row in null["parallel"]["rows"]
]
assert len(null["panel"]["rows"]) == 72 and len(null["delivery"]["rows"]) == 4
null_summary = results / "null-summary.json"
write_json(null_summary, {
    "sources": {key: reference(path) for key, path in null_paths.items()},
    "earlier_controls": null["panel"]["false_guide_counts"],
    "parallel_controls": null["parallel"]["false_guide_counts"],
    "delivery_controls": null["delivery"]["rows"],
    "rail_scope": "Counts describe the donor acceptance gate before query validation.",
})

members = {
    root: [
        "plan.json", "collect.log", "output/collection.json", "review/result.json",
        "review.py", "native-view/items.json", "publish.py",
        *(
            f"work/src/demosaic/{name}.py" for name in (
                "full_frame_edge", "localized_donor_geometry",
                "search_donor_geometry", "donor_phase_geometry",
            )
        ),
        "work/scripts/probe_localized_donor_support.py",
        "work/scripts/probe_localized_donor_refinement.py",
    ],
    cache / "localized-donor-support-v1": ["plan.json", "collect.log"],
    cache / "localized-donor-support-v2": [
        "plan.json", "collect.log", "output/collection.json", "review/result.json", "review.py",
    ],
    earlier: [
        "plan.json", "collect.log", "output/collection.json", "review/result.json", "review.py",
        "null-panel.py", "null-panel.json", "null-panel.log", "null-parallel.py",
        "null-parallel.json", "null-parallel.log", "null-delivery.py", "null-delivery.json",
    ],
    cache / "affinity-first-fresh-v3": ["review.py"],
}
assert checked(review["scoring_code"]) == cache / "affinity-first-fresh-v3/review.py"
archive = results / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as tar,
):
    for directory, names in members.items():
        for name in names:
            path = directory / name
            entry = tar.gettarinfo(str(path), arcname=f"{directory.name}/{name}")
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            with path.open("rb") as stream:
                tar.addfile(entry, stream)
with tarfile.open(archive) as tar:
    for directory, names in members.items():
        for name in names:
            assert tar.extractfile(f"{directory.name}/{name}").read() == (directory / name).read_bytes()
write_json(results / "publication.json", {
    "archive": reference(archive),
    "native_manifest": reference(manifest),
    "summary": reference(summary),
    "null_summary": reference(null_summary),
    "verified_members": sum(map(len, members.values())),
    "comparison_boards_viewed": 10,
    "triplets_viewed": 2,
    "new_checkpoint": None,
})
