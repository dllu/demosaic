"""Read-only publication, source and documentation integrity checks; no inference."""
import gzip
import re
import subprocess
import tarfile
from pathlib import Path
from urllib.parse import unquote

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path.cwd()
publications = [
    ("neural-nuisance-hann512-v1", ".cache/experiments/neural-nuisance-hann512-pilot-v1/work"),
    ("v132-endpoint-v1", ".cache/experiments/raw-spatial-endpoint-review-v3/V132/work"),
    ("neural-nuisance-context512-v1", ".cache/experiments/neural-nuisance-context512-pilot-v1/work"),
    ("neural-nuisance-full-edge512-v1", ".cache/experiments/neural-nuisance-full-edge512-pilot-v1/work"),
]
rows = []
for name, source in publications:
    file = ROOT / "docs/results" / name / "publication.json"
    document = read_json(file)
    for archive in document["archives"]:
        assert gzip.decompress(checked(archive["published"]).read_bytes()) == checked(archive["original"]).read_bytes()
    for image in document["images"]:
        assert checked(image["published"]).read_bytes() == checked(image["original"]).read_bytes()
    checked(document["viewer"])
    with tarfile.open(checked(document["source_snapshot"]), "r:gz") as tar:
        members = tar.getmembers()
        assert len(members) == document["source_files_exact"]
        for member in members:
            assert tar.extractfile(member).read() == (ROOT / source / member.name).read_bytes()
    if name.startswith("v132"):
        assert document["viewing_complete"]
    else:
        assert document["viewing"]["actually_viewed"]
        assert document["new_neural_forwards"] == 0
    rows.append({"publication": reference(file), "archives_exact": len(document["archives"]),
                 "images_exact": len(document["images"]), "source_files_exact": len(members)})

addendum = ROOT / "docs/results/v132-endpoint-v1/import-test-addendum.json"
for item in read_json(addendum)["archives"]:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()

changed = subprocess.check_output(["git", "diff", "--name-only"], text=True).splitlines()
documents = [ROOT / p for p in changed if p.endswith(".md")]
documents += [ROOT / p for p in ["docs/v132-endpoint-quality.md", "docs/neural-nuisance-context512.md",
              "diary/2026-11-16-17-05-56-tapered-weighted-carriers.md", "docs/neural-nuisance-hann512.md"]]
links = 0
for document in documents:
    for target in re.findall(r"\]\(([^\n)]+)\)", document.read_text()):
        if target.startswith(("https:", "http:", "mailto:", "#")):
            continue
        path = unquote(target.split("#", 1)[0]).strip("<>")
        assert (document.parent / path).exists(), (str(document), target)
        links += 1

destination = ROOT / "docs/results/attention-hann-publication-verification-v2.json"
script_archive = destination.with_suffix(".py.gz")
with script_archive.open("xb") as stream:
    stream.write(gzip.compress(Path(__file__).read_bytes(), mtime=0))
assert gzip.decompress(script_archive.read_bytes()) == Path(__file__).read_bytes()
test_archives = []
for path in [".cache/weighted-discovery-tests-v2.log", ".cache/weighted-discovery-ruff-v2.log"]:
    source = ROOT / path
    target = destination.parent / ("attention-hann-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    test_archives.append({"original": reference(source), "published": reference(target)})
for file in (ROOT / ".cache/experiments/neural-nuisance-hann512-pilot-v1/work/src").rglob("*.py"):
    assert file.read_bytes() == (ROOT / "src" / file.relative_to(ROOT / ".cache/experiments/neural-nuisance-hann512-pilot-v1/work/src")).read_bytes()
write_json(destination, {
    "status": "passed", "publications": rows, "current_package_matches_executed_Hann_snapshot": True, "import_test_addendum": reference(addendum),
    "local_document_links_checked": links, "documents_checked": [reference(p) for p in documents],
    "script": reference(Path(__file__)), "script_archive": reference(script_archive),
    "test_logs": test_archives, "new_neural_forwards": 0,
    "scope": "Exact compressed receipts/source snapshots/native PNG copies; actual viewing already recorded separately; no new quality or inference",
})
print(rows)
print(links, "local document links checked;147 numerical tests passed;20 package tests previously passed")
