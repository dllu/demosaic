"""Preserve complete compact CUDA photo receipts for the PSNR history."""

import argparse
from collections import Counter
from pathlib import Path
import tarfile

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def export(source, output):
    source = reference(source)
    result = read_json(checked(source))
    assert result["complete"] and result["scope"] == "full"
    assert result["counts"] == {"known": 24, "unseen": 30, "photo": 3108}
    plan_binding = result["plan"]
    plan_path = checked(plan_binding)
    plan = read_json(plan_path)
    assert result["models"] == plan["models"] and result["policy"] == plan["policy"]
    assert result["canonical_inputs"] == plan["canonical_inputs"]
    canonical_path = checked(result["canonical_inputs"])
    canonical = read_json(canonical_path)
    assert canonical["all_input_witnesses_exact"]
    records = {(item["stage"], item["batch"]): item for item in canonical["records"]}
    assert len(result["cases"]) == len(records) == len(canonical["records"]) == sum(result["counts"].values())
    qualified = checked(result["qualification"])
    archive = output / "evidence.tar.xz"
    output.mkdir()
    counts = Counter()
    with tarfile.open(archive, "x:xz", preset=3) as bundle:
        bundle.add(checked(source), arcname="collector-result.json")
        bundle.add(plan_path, arcname="plan.json")
        bundle.add(canonical_path, arcname="canonical-inputs.json")
        bundle.add(qualified, arcname="preflight.json")
        bundle.add(checked(plan["driver"]), arcname="sources/collector.py")
        bundle.add(__file__, arcname="sources/export.py")
        for item in result["cases"]:
            local = checked(item)
            row = read_json(local)
            stage, index = row["stage"], row["batch"]
            expected = records.pop((stage, index))
            assert row["plan"] == plan_binding and row["arrays"] == expected["arrays"]
            assert set(row["variants"]) == set(result["models"])
            counts[stage] += 1
            if stage == "photo":
                bundle.add(local, arcname=f"photo/{index:05d}.json")
    assert counts == result["counts"] and not records
    archive_ref = reference(archive)
    archive_ref["path"] = str(archive.relative_to(Path.cwd()))
    write_json(output / "publication.json", {
        "collector": source,
        "plan": plan_binding,
        "qualification": result["qualification"],
        "archive": archive_ref,
        "canonical_inputs": result["canonical_inputs"],
        "models": result["models"],
        "complete": result["complete"],
        "counts": result["counts"],
        "policy": result["policy"],
        "weights": "EMA",
        "photo_sources": 427,
        "observations_per_model": 11956,
        "photo_summary": result["summaries"]["photo"]["overall"],
    })


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    export(args.source, args.output.absolute())
