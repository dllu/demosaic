"""Measure shared phase geometry, strict ROI crops and rail-only fallback."""

import argparse
import importlib.util
from itertools import product
from pathlib import Path

import numpy as np
from probe_shared_projective_phase import MODES
from probe_surface_aggregation import field
from report_fold_support_pooling import (
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.shared_projective_phase import projective_hessians

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent / "shared-projective-phase-v1"
PREDICTIVE = ROOT.parent / "shared-projective-predictive-v1"
PRIOR = ROOT.parent / "local-phase-bounds-v1/review.py"
spec = importlib.util.spec_from_file_location("retained_case_reader", PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)


def math_row(row, weak_mse, scale_factor, key):
    v = row["metrics"][key]
    cross = 2 * weak_mse * v["weak_projection"]
    square = v["increment_RMS_DN16"] ** 2 - weak_mse + cross
    assert square > -1e-8
    return (
        v["weak_projection"] * scale_factor,
        weak_mse - scale_factor * cross + scale_factor**2 * max(0, square),
        (v["quiet_RMS_DN16"] * scale_factor) ** 2,
        v["strong_projection"] * scale_factor,
    )


def reduce_targets(rows, old, moments, offset):
    suffix = "-strict" if offset else ""
    modes = (*MODES, "oracle", "oracle-weak", "standardized-shared", "standardized-anchor")
    current = [
        row
        | {
            "metrics": row["metrics"]
            | {
                "standardized-shared" + suffix: prev["metrics"]["shared" + suffix],
                "standardized-anchor" + suffix: prev["metrics"]["anchor" + suffix],
            }
        }
        for row, prev in zip(rows, old, strict=True)
    ]
    baseline_quiet = np.sqrt(
        np.mean([r["metrics"]["screened" + suffix]["quiet_RMS_DN16"] ** 2 for r in rows])
    )
    result = {}
    for a in modes:
        key = a + suffix
        rms = np.sqrt(np.mean([r["metrics"][key]["quiet_RMS_DN16"] ** 2 for r in current]))
        cap = min(1, baseline_quiet / rms) if rms else 1
        result[a] = {}
        for label, scale in (("fixed", 1), ("quiet_capped", cap)):
            p, error, quiet, strong = np.mean(
                [math_row(r, w, scale, key) for r, w in zip(current, moments, strict=True)], axis=0
            )
            result[a][label] = {
                "weak_projection": p,
                "increment_RMS_DN16": float(np.sqrt(error)),
                "quiet_RMS_DN16": float(np.sqrt(quiet)),
                "strong_projection": strong,
                "scale_multiplier": float(scale),
            }
    return result


def geom_errors(row, quiet, mode):
    heights, widths = quiet.shape
    y, x = np.indices(quiet.shape).astype(float)
    v = np.column_stack((x[~quiet] - (widths - 1) / 2, y[~quiet] - (heights - 1) / 2))
    guessed = np.zeros((2, 2, 2))
    if mode in ("shared", "transfer"):
        chosen = row["selection"][1]["directions"][0]
        if chosen["accepted"]:
            guessed = projective_hessians(
                row["guide"]["frequencies_xy"], np.asarray(chosen["proposed"]) / min(quiet.shape)
            )
            if mode == "transfer":
                guessed[0] = 0
    err = 0.5 * np.einsum("pi,kij,pj->kp", v, guessed - row["true_hessians_xy"], v)
    return np.std(err, axis=1)


def render_synth(out, row, f, profile, plan):
    parent = f["parent"].astype(float)
    names = ("screened", "anchor", "shared", "independent", "transfer", "oracle")
    settings = plan["settings"][profile]
    ctx = {
        "packed": f["packed"][None],
        "colors": f["cfa"][None],
        "wb": np.ones((1, 3)),
        "matrix": np.eye(3)[None],
    }
    imgs = [parent + settings["scale"] * (f[a] - parent) for a in names]
    roi = (48, 48, 160, 160)
    labels = (
        "Noisy Malvar",
        "Analytic rail",
        "Planar",
        "Anchor only",
        "Shared",
        "Separate",
        "Companion only",
        "Exact perspective",
        "Exact GT",
    )
    return native_board(
        out,
        f"{profile}-case{row['case']}",
        [noisy_malvar(ctx)[0], parent, *imgs, f["target"]],
        ctx,
        {
            "ROI_xywh": list(roi),
            "noise": plan["profiles"][profile],
            "operating": settings,
            "CFA": row["CFA"],
            "case_receipt": row["prediction"],
            "case": row["case"],
            "kind": row["kind"],
            "parent": "Exact analytic rail",
            "checkpoint_sha256": None,
            "color_transform": "Identity WB and camera matrix, fixed clipped sRGB",
        },
        labels=labels,
        triplet_indices=(0, 6, 8),
        roi=roi,
        exposure=4,
    )


def fresh(out, plan):
    boards, table = [], {}
    for p, profile in (("projective400", "iso400"), ("projective6400", "iso6400")):
        done = read_json(ROOT / f"{p}.json")["rows"]
        rank0 = read_json(ORIGINAL / f"{p}.json")["rows"]
        rank1 = read_json(PREDICTIVE / f"{p}.json")["rows"]
        assert len(done) == len(rank0) == len(rank1) == 12
        moments, phases = [], []
        for r, a, b in zip(done, rank0, rank1, strict=True):
            assert r["case"] == a["case"] == b["case"]
            assert r["selection"] == b["selection"]
            for label, v in b["metrics"].items():
                assert v == r["metrics"][label]
            with np.load(checked(r["prediction"])) as f, np.load(checked(a["prediction"])) as old:
                for key in ("packed", "target", "strong", "parent", "screened", "oracle"):
                    np.testing.assert_array_equal(f[key], old[key])
                weak = f["target"].astype(float) - f["strong"]
                moments.append(float(np.mean((weak * 65535) ** 2)))
                phases.append(
                    {
                        name: geom_errors(r, f["quiet"], name)
                        for name in ("screened", "shared", "transfer")
                    }
                )
                if profile == "iso400" and r["case"] in (2, 7):
                    boards.append(render_synth(out, r, f, profile, plan))
        table[profile] = {}
        for kind in ("shared", "different", "planar"):
            indices = [i for i, r in enumerate(done) if r["kind"] == kind]
            rows, old, variances = ([seq[i] for i in indices] for seq in (done, rank0, moments))
            table[profile][kind] = {
                "count": len(indices),
                "scores": {str(o): reduce_targets(rows, old, variances, o) for o in (0, 1)},
                "phase_RMS_cycles": {
                    k: np.mean([phases[i][k] for i in indices], axis=0).tolist() for k in phases[0]
                },
                "accepted_two_direction_roles": [
                    sum(r["selection"][1]["directions"][j]["accepted"] for r in rows)
                    for j in (0, 1)
                ],
            }
    return table, boards


def archive(plan):
    result = {}
    for split in ("synthetic", "disjoint"):
        moments = {}
        done = read_json(ROOT / f"{split}.json")["rows"]
        old = read_json(PREDICTIVE / f"{split}.json")["rows"]
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        for row, b in zip(done, old, strict=True):
            assert row["id"] == b["id"] and row["witnesses_flexible"] == b["witnesses_flexible"]
            case, p, truth, quiet, images = prior.read_case(row, split)
            for guide, offset in product(guides, (0, 1)):
                names = ["parent", *(field(guide, a, offset) for a in MODES)]
                moments.setdefault((case["profile"], guide, offset), []).append(
                    {a: measure(p, truth, quiet, images[a]) for a in names}
                )
        result[split] = {}
        for (profile, guide, offset), group in moments.items():
            assert len(group) == 8
            means = {
                a: {k: np.mean([v[a][k] for v in group], axis=0) for k in m}
                for a, m in group[0].items()
            }
            fixed_scale = plan["settings"][profile]["scale"]
            fixed = {a: evaluated(m, fixed_scale) for a, m in means.items()}
            limit = fixed[field(guide, "screened", offset)]["quiet_RMS_DN16"]
            budget = max(0, limit - fixed["parent"]["quiet_RMS_DN16"])
            capped = {
                a: evaluated(m, min(fixed_scale, scale_at_budget(m["quiet_mse"], budget)))
                for a, m in means.items()
            }
            result[split].setdefault(profile, {})[field(guide, "comparison", offset)] = {
                "fixed": fixed,
                "quiet_capped": capped,
                "count": len(group),
            }
    return result


def camera(out, plan):
    references = read_json(checked(plan["camera_baseline"]))["camera"]
    observations = read_json(ROOT / "camera.json")["rows"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    review = []
    for source, row in zip(references, observations, strict=True):
        key, old = source["id"], source["source"]
        assert key == row["id"]
        x, y, w, h = source["ROI_xywh"]
        qx, qy, *_ = old["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(old["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        cells, metrics = [], {}
        labels = {"screened": "planar", "shared": "shared", "transfer": "companion"}
        with np.load(checked(row["predictions"])) as f:
            parent = f["parent"][region].astype(float)
            for g, (mode, label) in product(("scene", "spectral"), labels.items()):
                prediction = f[field(g, mode, 0)][region]
                render = display(prediction[None], ctx, exposure=source["display_exposure"])[
                    0
                ].transpose(1, 2, 0)
                cells.append((f"{g.title()} {label}", np.rint(render * 255).astype(np.uint8)))
                metrics[field(g, mode, 0)] = float(
                    np.sqrt(np.mean((prediction - parent) ** 2)) * 65535
                )
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [x for x in source["panels"] if x["label"] in keep or "JPEG" in x["label"]]
        img, cells = insert_camera_panels(out, key, source | {"panels": panels}, "V120 EMA", cells)
        ax, ay, *_ = old["absolute_query_xywh"]
        review.append(
            {
                "id": key,
                "image": img,
                "panels": cells,
                "checkpoint": old["checkpoint"],
                "ROI_xywh": [ax + x - qx, ay + y - qy, w, h],
                "CFA": "RGGB",
                "noise": noise[key],
                "display_exposure": source["display_exposure"],
                "predictions": row["predictions"],
                "calibration": old["query_arrays"],
                "selection": row["flexible_edges"],
                "RMS_from_V120_DN16": metrics,
                "reference": "DSCF3880 ISO100 AHD"
                if key.startswith("main-")
                else "DSCF3835 ISO100 AHD and both camera JPEGs",
            }
        )
    return review


def nulls():
    data = [r for p in ("null400", "null6400") for r in read_json(ROOT / f"{p}.json")["rows"]]
    assert len(data) == 48
    groups = {
        "flat": {"flat"},
        "straight": {"step", "rail"},
        "complex": {"wedge", "bent-rail", "two-rails"},
    }
    answer = {}
    for group, styles in groups.items():
        rows = [r for r in data if r["style"] in styles]
        answer[group] = {
            "count": len(rows),
            "accepted": [
                sum(r["selection"]["directions"][i]["accepted"] for r in rows) for i in (0, 1)
            ],
            "metrics": {},
        }
        for a in rows[0]["metrics"]:
            v = [r["metrics"][a] for r in rows]
            answer[group]["metrics"][a] = {
                "RMS_DN16": float(np.sqrt(np.mean([r["RMS_DN16"] ** 2 for r in v]))),
                "peak_DN16": max(r["max_abs_DN16"] for r in v),
                "changed": sum(r["changed_pixels"] > 0 for r in v),
            }
    return answer


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("task", choices=("fresh", "archive", "camera", "nulls"))
    task = cli.parse_args().task
    plan = read_json(ROOT / "plan.json")
    out = ROOT / "review"
    out.mkdir(exist_ok=True)
    if task == "fresh":
        results, boards = fresh(out, plan)
        data = {"scores": results, "boards": boards}
    elif task == "archive":
        data = archive(plan)
    elif task == "camera":
        data = {"rows": camera(out, plan)}
    else:
        data = nulls()
    write_json(out / f"{task}.json", {"producer": reference(__file__), **data})
