"""Bundle the inspected fixed native boards and replay evidence."""

import shutil
import tarfile
from pathlib import Path

import numpy as np
from probe_localized_guide_frequency import PANELS

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
review = root / "review"
transport = root.parent / "anchor-frequency-transport-v1"
images = Path("docs/images") / root.name
results = Path("docs/results") / root.name
constructed = read_json(review / "constructed.json")
camera = read_json(review / "camera.json")["rows"]
assert len(constructed["boards"]) == 2 and len(camera) == 8
assert "119 passed" in (root / "tests.log").read_text()
images.mkdir()
results.mkdir()


def adopt(binding):
    p = checked(binding)
    out = images / p.name
    shutil.copyfile(p, out)
    assert reference(out)["sha256"] == binding["sha256"]
    return out.name


native = images / "manifest.json"
write_json(
    native,
    {
        "scope": "Two native synthetic GT triplets and their comparison boards, plus eight GFX crops. "
        "The GFX references are independent qualitative images.",
        "synthetic": [
            b | {k: b[k] | {"file": adopt(b[k]["image"])} for k in ("board", "triplet")}
            for b in constructed["boards"]
        ],
        "camera": [c | {"file": adopt(c["image"])} for c in camera],
    },
)

exact_candidate = []
for panel in ("projective400", "projective6400"):
    for r in read_json(root / f"{panel}.json")["rows"]:
        s = r["trace"][1]["selection"]
        c = np.asarray(s["candidates"])
        distance = np.linalg.norm(c - np.asarray(r["known_frequency"])[1], axis=1)
        idx = int(distance.argmin())
        assert distance[idx] < 1e-8
        values = {k: np.array(v["margins"])[:, :, idx].tolist() for k, v in s["screening"].items()}
        assert all(min(fold[0] for fold in value) < 0 for value in values.values())
        exact_candidate.append({"id": r["id"], "margins_vs_absent_and_original": values})
assert len(exact_candidate) == 24

summary = results / "summary.json"
write_json(
    summary,
    {
        "plan": reference(root / "plan.json"),
        "panels": {p: reference(root / f"{p}.json") for p in PANELS},
        "constructed": {k: constructed[k] for k in ("scores", "guides")},
        "constructed_exact_candidate_check": exact_candidate,
        "archived": read_json(review / "archived.json"),
        "forced_guide_nulls": read_json(review / "nulls.json"),
        "anchor_transport_headroom": read_json(transport / "headroom-v2.json"),
        "camera": [
            {k: c[k] for k in ("id", "checkpoint", "noise", "ROI_xywh", "RMS_from_V120_DN16")}
            for c in camera
        ],
        "new_checkpoint": None,
    },
)

files = [
    "plan.json",
    "review.py",
    "review-camera.py",
    "publish.py",
    "tests.log",
    *(f"{p}.{e}" for p in PANELS for e in ("json", "log")),
    *(f"review/{m}.json" for m in ("archived", "camera", "constructed", "nulls")),
    "work/src/demosaic/localized_guide_frequency.py",
    "work/src/demosaic/finite_wire_profiles.py",
    "work/scripts/probe_localized_guide_frequency.py",
]
members = {f"{root.name}/{f}": root / f for f in files}
members.update(
    {
        f"{transport.name}/{f}": transport / f
        for f in ("headroom.py", "headroom-v2.json", "headroom-v2.log")
    }
)
for name in ("shared-projective-transfer-v1", "local-phase-bounds-v1"):
    members[f"{name}/review.py"] = root.parent / name / "review.py"
archive = results / "evidence.tar.xz"
with tarfile.open(archive, "x:xz", preset=8) as writer:
    for name, path in sorted(members.items()):
        metadata = writer.gettarinfo(str(path), arcname=name)
        metadata.mtime = metadata.uid = metadata.gid = 0
        metadata.uname = metadata.gname = ""
        with path.open("rb") as stream:
            writer.addfile(metadata, stream)
with tarfile.open(archive) as writer:
    for member in writer:
        assert writer.extractfile(member).read() == members[member.name].read_bytes()
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "summary": reference(summary),
        "native_manifest": reference(native),
        "verified_members": len(members),
        "comparisons_viewed": 10,
        "triplets_viewed": 2,
    },
)
