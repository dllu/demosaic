"""Measure candidate admission, quiet-limited response and fixed native crops."""

import argparse
import importlib.util
from collections import defaultdict
from itertools import product
from pathlib import Path

import numpy as np
from probe_localized_guide_frequency import ARMS
from probe_surface_aggregation import field
from report_fold_support_pooling import evaluated, insert_camera_panels, measure, scale_at_budget
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PLAN = read_json(ROOT / "plan.json")
OUT = ROOT / "review"
PRIOR = ROOT.parent / "shared-projective-transfer-v1/review.py"
spec = importlib.util.spec_from_file_location("projective_review", PRIOR)
proj = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proj)
read_case = proj.prior.read_case

LABELS = ("Eight knots", "Fixed focused", "Uniform search", "Localized search")


def camera():
    original = read_json(checked(PLAN["camera_baseline"]))["camera"]
    done = read_json(ROOT / "camera.json")["rows"]
    prior = {r["id"]: r for r in read_json(proj.ROOT / "review/camera.json")["rows"]}
    result = []
    for r, source in zip(done, original, strict=True):
        name = r["id"]
        assert source["id"] == name
        x, y, w, h = source["ROI_xywh"]
        qx, qy, *_ = source["source"]["query_box"]
        region = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(source["source"]["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        cols, rms = [], {}
        with np.load(checked(r["predictions"])) as f:
            p = f["parent"][region].astype(float)
            for guide, (arm, label) in product(
                ("scene", "spectral"), zip(ARMS, LABELS, strict=True)
            ):
                key = field(guide, arm, 0)
                predicted = f[key][region]
                pixels = display(predicted[None], ctx, exposure=source["display_exposure"])[0]
                cols.append(
                    (
                        f"{guide.title()} {label}",
                        np.rint(pixels.transpose(1, 2, 0) * 255).astype(np.uint8),
                    )
                )
                rms[key] = float(np.sqrt(np.mean((predicted - p) ** 2)) * 65535)
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in source["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        img, cells = insert_camera_panels(OUT, name, source | {"panels": panels}, "V120 EMA", cols)
        result.append(
            prior[name]
            | {
                "image": img,
                "panels": cells,
                "predictions": r["predictions"],
                "selection": r["flexible_edges"],
                "RMS_from_V120_DN16": rms,
            }
        )
    return {"rows": result}


def summary_guide(trace, weak):
    selected = trace.get("delivered_guides", {})
    result = {}
    for k in ARMS[1:]:
        f = selected.get(k)
        error = None
        if f is not None and any(f["active"]):
            actual = np.asarray(f["frequencies_xy"])[f["active"]]
            error = float(
                256
                * np.minimum(
                    np.linalg.norm(actual - weak, axis=1), np.linalg.norm(actual + weak, axis=1)
                ).min()
            )
        result[k] = error
    main = trace.get("selection", {}).get("screening", {})
    return {
        "support": bool(trace.get("footprint_used", False)),
        "accepted": {k: v["accepted"] for k, v in main.items()},
        "error": result,
    }


def archived():
    table, traces = {}, {}
    for split in ("synthetic", "disjoint"):
        moments = defaultdict(list)
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        traces[split] = []
        for r in read_json(ROOT / f"{split}.json")["rows"]:
            case, p, truth, quiet, images = read_case(r, split)
            recipe = case["metadata"]["recipe"]
            a = recipe["wire_angles"][1]
            weak = np.array([np.cos(a), np.sin(a)]) / recipe["periods"][1]
            traces[split].append(
                {
                    "id": r["id"],
                    "profile": case["profile"],
                    "roles": [{g: summary_guide(h[g], weak) for g in guides} for h in r["traces"]],
                }
            )
            for guide, offset in product(guides, (0, 1)):
                names = ("parent", *(field(guide, key, offset) for key in ARMS))
                moments[case["profile"], guide, offset].append(
                    {k: measure(p, truth, quiet, images[k]) for k in names}
                )
        table[split] = {}
        for (profile, guide, offset), group in moments.items():
            assert len(group) == 8
            means = {
                k: {m: np.mean([g[k][m] for g in group], axis=0) for m in v}
                for k, v in group[0].items()
            }
            alpha = PLAN["settings"][profile]["scale"]
            fixed = {k: evaluated(v, alpha) for k, v in means.items()}
            limit = fixed[field(guide, "fixed-focused", offset)]["quiet_RMS_DN16"]
            floor = fixed["parent"]["quiet_RMS_DN16"]
            budget = max(0, limit - floor)
            capped = {
                k: evaluated(v, min(alpha, scale_at_budget(v["quiet_mse"], budget)))
                for k, v in means.items()
            }
            key = field(guide, "comparison", offset)
            table[split].setdefault(profile, {})[key] = {
                "quiet_capped": capped,
                "fixed": fixed,
                "count": len(group),
            }
    return {"results": table, "guides": traces}


def constructed():
    boards, summaries, witness = [], {}, {}
    for panel, profile in (("projective400", "iso400"), ("projective6400", "iso6400")):
        stage = read_json(ROOT / f"{panel}.json")["rows"]
        powers = {}

        def gain(r):
            m = r["metrics"]
            return (
                m["localized-frequency"]["weak_projection"] - m["fixed-focused"]["weak_projection"]
            )

        # Pair a gain example with the case where localization loses the most against uniform selection.
        idx = {
            max(stage, key=gain)["case"],
            min(
                stage,
                key=lambda r: (
                    r["metrics"]["localized-frequency"]["weak_projection"]
                    - r["metrics"]["uniform-frequency"]["weak_projection"]
                ),
            )["case"],
        }
        if len(idx) == 1:
            idx.add(5 if 5 not in idx else 4)
        witness[profile] = []
        for r in stage:
            weak_f = np.asarray(r["known_frequency"])[1]
            witness[profile].append(
                {
                    "case": r["case"],
                    "kind": r["kind"],
                    "roles": [summary_guide(t, weak_f) for t in r["trace"]],
                }
            )
            with np.load(checked(r["old_prediction"])) as src:
                rgb = src["parent"].astype(float)
                weak = src["target"].astype(float) - src["strong"]
                powers[r["case"]] = float(np.mean((weak * 65535) ** 2))
                if profile != "iso400" or r["case"] not in idx:
                    continue
                with np.load(checked(r["prediction"])) as f:
                    images = [rgb + PLAN["settings"][profile]["scale"] * (f[a] - rgb) for a in ARMS]
                ctx = {
                    "packed": src["packed"][None],
                    "colors": src["cfa"][None],
                    "wb": np.ones((1, 3)),
                    "matrix": np.eye(3)[None],
                }
                boards.append(
                    native_board(
                        OUT,
                        r["id"],
                        [noisy_malvar(ctx)[0], *images, src["target"]],
                        ctx,
                        {
                            "ROI_xywh": [48, 48, 160, 160],
                            "noise": PLAN["profiles"][profile],
                            "operating": PLAN["settings"][profile],
                            "CFA": r["CFA"],
                            "case": r["case"],
                            "kind": r["kind"],
                            "observations": r["old_prediction"],
                            "predictions": r["prediction"],
                            "parent": "Exact analytic rail",
                            "checkpoint_sha256": None,
                            "color_transform": "Identity WB and camera matrix, fixed clipped sRGB",
                        },
                        labels=("Noisy Malvar", *LABELS, "Exact GT"),
                        triplet_indices=(0, 4, 5),
                        roi=(48, 48, 160, 160),
                        exposure=4,
                    )
                )
        summaries[profile] = {}
        for kind in ("shared", "different", "planar"):
            rows = [r for r in stage if r["kind"] == kind]
            stats = {}
            for off, suffix in enumerate(("", "-strict")):
                baseline = np.sqrt(
                    np.mean(
                        [
                            r["metrics"]["fixed-focused" + suffix]["quiet_RMS_DN16"] ** 2
                            for r in rows
                        ]
                    )
                )
                entry = {}
                for a in ARMS:
                    rms = np.sqrt(
                        np.mean([r["metrics"][a + suffix]["quiet_RMS_DN16"] ** 2 for r in rows])
                    )
                    alpha = min(1, baseline / rms) if rms else 1
                    v = {}
                    for setting, scale in (("fixed", 1), ("quiet_capped", alpha)):
                        p, e, q, s = np.mean(
                            [proj.math_row(r, powers[r["case"]], scale, a + suffix) for r in rows],
                            axis=0,
                        )
                        v[setting] = {
                            "weak_projection": p,
                            "increment_RMS_DN16": np.sqrt(e),
                            "quiet_RMS_DN16": np.sqrt(q),
                            "strong_projection": s,
                            "multiplier": scale,
                        }
                    entry[a] = v
                stats[str(off)] = entry
            summaries[profile][kind] = stats
    return {"scores": summaries, "guides": witness, "boards": boards}


def nulls():
    classes = defaultdict(list)
    for panel in ("null400", "null6400"):
        for r in read_json(ROOT / f"{panel}.json")["rows"]:
            k = (
                "flat"
                if r["style"].endswith("flat")
                else "straight"
                if r["style"] in ("step", "rail")
                else "complex"
            )
            classes[k].append(r)
    table = {}
    for k, rows in classes.items():
        metrics = {}
        for arm in rows[0]["metrics"]:
            values = [r["metrics"][arm] for r in rows]
            metrics[arm] = {
                "RMS_DN16": float(np.sqrt(np.mean([v["RMS_DN16"] ** 2 for v in values]))),
                "peak_DN16": max(v["max_abs_DN16"] for v in values),
            }
        table[k] = {
            "count": len(rows),
            "metrics": metrics,
            "guides": [{f: r[f] for f in ("style", "trial", "profile", "witness")} for r in rows],
        }
    return table


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("stage", choices=("camera", "archived", "constructed", "nulls"))
    mode = cli.parse_args().stage
    OUT.mkdir(exist_ok=True)
    data = {"camera": camera, "archived": archived, "constructed": constructed, "nulls": nulls}[
        mode
    ]()
    write_json(OUT / f"{mode}.json", {"producer": reference(__file__), **data})
