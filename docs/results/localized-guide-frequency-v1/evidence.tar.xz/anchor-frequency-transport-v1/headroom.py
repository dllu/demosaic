"""Check whether the nominal guide errors are compatible with anchor transport."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BOUND = 2.0
BIN = 256


def dist(a, b):
    return BIN * min(np.linalg.norm(a - b), np.linalg.norm(a + b))


def transport(before, after, companion):
    old, new, weak = [complex(*x) for x in (before, after, companion)]
    value = weak * new / old
    return np.asarray([value.real, value.imag])


def diagnostic(anchor, companion, strong, weak):
    if anchor @ strong < 0:
        strong = -strong
    moved = transport(anchor, strong, companion)
    return {
        "anchor_error_bins": dist(anchor, strong),
        "original_error_bins": dist(companion, weak),
        "transported_error_bins": dist(moved, weak),
        "transport_bins": dist(companion, moved),
        "transported_xy": moved.tolist(),
        "eligible": bool(dist(anchor, strong) <= BOUND and dist(companion, moved) <= BOUND),
    }


records, sources = [], {}
plan = read_json(ROOT.parent / "focused-wire-conditional-v1" / "plan.json")
guide_sources = {
    panel: plan["source"][key]
    for panel, key in (("synthetic", "original_guides"), ("disjoint", "disjoint_guides"))
}
original_guides = {
    panel: {row["id"]: row for row in read_json(checked(binding))["synthetic"]}
    for panel, binding in guide_sources.items()
}
for panel in ("synthetic", "disjoint"):
    for iso in ("iso400", "iso6400"):
        tag = f"{panel}-{iso}"
        f = ROOT.parent / "donor-frequency-bank-v1" / f"{tag}.json"
        sources[tag] = reference(f)
        for r in read_json(f)["rows"]:
            recipe = read_json(checked(r["case"]))["metadata"]["recipe"]
            angles = recipe["wire_angles"]
            strong, weak = (
                np.column_stack((np.cos(angles), np.sin(angles)))
                / np.asarray(recipe["periods"])[:, None]
            )
            observation = r["bank_records"][2]
            orig = original_guides[panel][r["id"]]
            g = orig["roles" if panel == "synthetic" else "rankings"][2]["fits"]["scene"]
            anchor_index = next((i for i, v in enumerate(g["active"]) if v), None)
            assert anchor_index == observation["anchor_index"]
            record = {"id": r["id"], "panel": tag, "bank": [], "original": None}
            if anchor_index is not None:
                anchor, companion = [
                    np.asarray(g["frequencies_xy"][i]) for i in (anchor_index, 1 - anchor_index)
                ]
                record["original"] = diagnostic(anchor, companion, strong, weak) | {
                    "companion_active": g["active"][1 - anchor_index],
                }
            for entry in observation["bank"]["shortlist"]:
                witness = entry["witness"]
                f_weak, f_strong = np.asarray(witness["frequencies_xy"])
                if all(witness["active"]) and len(witness["screened_frequencies_xy"]) == 2:
                    record["bank"].append(diagnostic(f_strong, f_weak, strong, weak))
            records.append(record)
write_json(
    ROOT / "headroom-v2.json",
    {
        "sources": sources,
        "guide_sources": guide_sources,
        "producer": reference(__file__),
        "scope": "Exact nominal constructed anchor frequencies for an upper bound. Distances are sign invariant in native DFT bins. No RAW or model evaluation.",
        "norm_bound_bins": BOUND,
        "rows": records,
    },
)
for name in sources:
    rr = [r for r in records if r["panel"] == name]
    original = [r["original"] for r in rr if r["original"] and r["original"]["companion_active"]]
    bank = [b for r in rr for b in r["bank"]]
    print(
        name,
        "active pairs",
        len(original),
        "anchor-near",
        sum(o["eligible"] for o in original),
        "weak hit",
        sum(o["original_error_bins"] <= 1 for o in original),
        "transport hit",
        sum(
            (o["transported_error_bins"] if o["eligible"] else o["original_error_bins"]) <= 1
            for o in original
        ),
        "bank pairs",
        len(bank),
        "bank anchor-near",
        sum(o["eligible"] for o in bank),
        flush=True,
    )
