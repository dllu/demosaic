"""Score native exact targets, real crops and both forced-guide control panels."""

import importlib.util
from itertools import product
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from probe_local_phase_bounds import MODES, compare, structure_module
from probe_surface_aggregation import deliver, field
from report_fold_support_pooling import (
    ROI,
    evaluated,
    insert_camera_panels,
    measure,
    scale_at_budget,
)
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
DIRECT = ROOT.parent / "affinity-first-fresh-v3/review.py"
spec = importlib.util.spec_from_file_location("closed_evaluation", DIRECT)
direct = importlib.util.module_from_spec(spec)
spec.loader.exec_module(direct)


def read_case(item, split):
    case = read_json(checked(item["case"]))
    block = case | {"prediction": item["prediction"]}
    if split == "synthetic":
        p, truth, quiet, values = direct.load(block)
    else:
        p = np.load(checked(case["parent"])).astype(float)
        with np.load(checked(case["target"])) as f:
            truth, quiet = f["target"].astype(float), f["quiet"][ROI]
        with np.load(checked(item["prediction"])) as f:
            values = dict(f)
    return case, p, truth, quiet, values


def verify_old(item, values, guides, offsets):
    checked_pairs = 0
    with np.load(checked(item["prior_prediction"])) as old:
        np.testing.assert_array_equal(values["parent"], old["parent"])
        checked_pairs += 1
        for g, m, t in product(guides, ("weighted-refit", "tangent-predictive-gate"), offsets):
            key = field(g, m, t)
            np.testing.assert_array_equal(values[key], old[key])
            checked_pairs += 1
        if "scene-bounded-tangent" in old:
            np.testing.assert_array_equal(
                values["scene-global-energy"], old["scene-bounded-tangent"]
            )
            checked_pairs += 1
    return checked_pairs


def capped(moments, fixed, ceiling, limit):
    baseline = fixed["parent"]["quiet_RMS_DN16"]
    values = {}
    for name, moment in moments.items():
        scale = min(limit, scale_at_budget(moment["quiet_mse"], max(0, ceiling - baseline)))
        values[name] = evaluated(moment, scale) | {"scale": scale}
    assert all(m["quiet_RMS_DN16"] <= max(ceiling, baseline) + 2e-9 for m in values.values())
    return values


def render_synthetic(case, p, gt, v, row, plan, out):
    with np.load(checked(case["sensor"])) as f:
        ctx = {k: f[k][2:3] for k in ("colors", "wb", "matrix")}
        ctx["packed"] = f["packed"][2:3, :, 64:192, 64:192]
    nominal = plan["settings"][case["profile"]]
    alpha = nominal["scale"]
    parent = p[2][ROI]
    columns = {
        "scene-weighted-refit": "Wave refit",
        "scene-tangent-predictive-gate": "Tangent / wave gate",
        "scene-global-energy": "Whole-query cap",
        "scene-local-peak": "Local signed peaks",
        "scene-local-energy": "Local energy",
        "exact-center-weighted-refit": "Exact guide wave",
        "exact-center-local-peak": "Exact guide local peaks",
    }
    pixels = [
        noisy_malvar(ctx)[0],
        parent,
        *(parent + alpha * (v[k][2] - parent) for k in columns),
        gt[2][ROI],
    ]
    return native_board(
        out,
        case["id"],
        pixels,
        ctx,
        {
            "case_receipt": row["case"],
            "CFA": case["CFA"],
            "noise": case["metadata"]["noise"],
            "checkpoint": plan["parent_checkpoint"],
            "operating": nominal,
        },
        labels=["Noisy Malvar", "V143 EMA", *columns.values(), "Exact GT"],
        triplet_indices=(0, 5, 9),
        contrast=5,
    )


def synthetic(done, plan, out):
    totals, boards, verified, variants = [], [], 0, []
    for split in ("synthetic", "disjoint"):
        guides = ("scene", "exact-center") if split == "synthetic" else ("scene",)
        gates = (0, 1) if split == "synthetic" else (0,)
        groups = []
        for row in done[split]:
            case, p, gt, quiet, v = read_case(row, split)
            verified += verify_old(row, v, guides, gates)
            moments = {name: measure(p, gt, quiet, values) for name, values in v.items()}
            fields = plan["settings"][case["profile"]]
            alpha = fields["scale"]
            for key in ["parent", "scene-weighted-refit", "scene-local-energy", "scene-local-peak"]:
                standard = direct.direct(p, gt, quiet, v[key], alpha)
                polynomial = evaluated(moments[key], alpha)
                for metric, value in standard.items():
                    if metric == "background_quiet_mse":
                        continue
                    observed = np.sqrt(value) if metric.endswith("_mse") else value
                    np.testing.assert_allclose(
                        polynomial[metric.replace("_mse", "_RMS_DN16")],
                        observed,
                        atol=2e-9,
                        rtol=2e-9,
                    )
            groups.append({"id": row["id"], "profile": case["profile"], "moments": moments})
            variants.append(
                {
                    "panel": split,
                    "id": row["id"],
                    "profile": case["profile"],
                    "metrics_at_fixed_scale": {a: evaluated(c, alpha) for a, c in moments.items()},
                }
            )
            if split == "synthetic" and case["profile"] == "iso400" and case["source"] in (88, 89):
                boards.append(render_synthetic(case, p, gt, v, row, plan, out))
        for profile, setting in plan["settings"].items():
            data = [r for r in groups if r["profile"] == profile]
            alpha = setting["scale"]
            for guide in guides:
                labels = ["parent", *(field(guide, m, t) for m, t in product(MODES, gates))]
                moments = {
                    name: {
                        k: np.mean([r["moments"][name][k] for r in data], axis=0)
                        for k in data[0]["moments"][name]
                    }
                    for name in labels
                }
                fixed = {name: evaluated(m, alpha) for name, m in moments.items()}
                ceiling = fixed[field(guide, "weighted-refit", 0)]["quiet_RMS_DN16"]
                totals.append(
                    {
                        "panel": split,
                        "profile": profile,
                        "guide": guide,
                        "count": len(data),
                        "quiet_ceiling_DN16": ceiling,
                        "fixed": fixed,
                        "matched": capped(moments, fixed, ceiling, alpha),
                    }
                )
    return totals, boards, verified, variants


def camera(done, plan, out):
    baseline = read_json(checked(plan["camera_baseline"]))["camera"]
    noise = {
        r["board"]["id"]: r["noise"]
        for r in read_json(checked(plan["camera_conditions"]))["camera"]
    }
    names = {
        "scene-weighted-refit": "Scene wave refit",
        "scene-global-energy": "Scene whole-query cap",
        "scene-local-peak": "Scene local peaks",
        "scene-local-energy": "Scene local energy",
        "spectral-weighted-refit": "Spectra wave refit",
        "spectral-global-energy": "Spectra whole-query",
        "spectral-local-peak": "Spectra local peaks",
        "spectral-local-energy": "Spectra local energy",
    }
    camera_rows, verified = [], 0
    for old, row in zip(baseline, done, strict=True):
        key, source = old["id"], old["source"]
        assert key == row["id"]
        x, y, w, h = old["ROI_xywh"]
        qx, qy, *_ = source["query_box"]
        crop = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(row["predictions"])) as f:
            output = dict(f)
        verified += verify_old(row, output, ("scene", "spectral"), (0, 1))
        with np.load(checked(source["query_arrays"])) as f:
            ctx = {k: f[k] for k in ("wb", "matrix")}
        exposure = old["display_exposure"]
        extra = [
            (
                label,
                np.rint(
                    display(output[name][None], ctx, exposure=exposure)[0][crop].transpose(1, 2, 0)
                    * 255
                ).astype(np.uint8),
            )
            for name, label in names.items()
        ]
        keep = {"Noisy Malvar", "V120 EMA", "ISO100 AHD ref"}
        panels = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        png, indices = insert_camera_panels(out, key, old | {"panels": panels}, "V120 EMA", extra)
        parent = output["parent"][crop]
        ax, ay, *_ = source["absolute_query_xywh"]
        camera_rows.append(
            {
                "id": key,
                "image": png,
                "panels": indices,
                "display_exposure": exposure,
                "ROI_xywh": [x - qx + ax, y - qy + ay, w, h],
                "predictions": row["predictions"],
                "checkpoint": source["checkpoint"],
                "noise": noise[key],
                "camera_RAW": plan["photos"]["main" if key.startswith("main-") else "mesh"],
                "calibration": source["query_arrays"],
                "delta_RMS_DN16": {
                    name: float(np.sqrt(np.mean((img[crop].astype(float) - parent) ** 2)) * 65535)
                    for name, img in output.items()
                },
            }
        )
    return camera_rows, verified


def summarize_null(label):
    path = ROOT / f"null-{label}.json"
    rows = read_json(path)["rows"]
    groups = {}
    for style in sorted({r["style"] for r in rows}):
        values = [r for r in rows if r["style"] == style]
        names = list(values[0]["metrics"])
        groups[style] = {}
        for name in names:
            metrics = [r["metrics"][name] for r in values]
            groups[style][name] = {
                "cases": len(metrics),
                "changed": sum(m["changed_pixels"] > 0 for m in metrics),
                "pooled_RMS_DN16": float(np.sqrt(np.mean([m["RMS_DN16"] ** 2 for m in metrics]))),
                "peak_DN16": max(m["max_abs_DN16"] for m in metrics),
            }
    return {"source": reference(path), "by_structure": groups}


def worst_rail(plan, out):
    path = ROOT / "null-retained.json"
    rails = [r for r in read_json(path)["rows"] if r["style"] == "rail"]
    row = max(rails, key=lambda r: r["metrics"]["null-global-energy"]["max_abs_DN16"])
    p = structure_module(plan["structure"])
    truth = p.construct(row["style"], row["angle_radians"], *row["width_shift_level_height"])
    cfa = np.asarray(PATTERNS[row["CFA"]])
    cfg = LocalWaveConfig(**plan["config"])
    noise = plan["profiles"][row["profile"]]
    raw = p.corrupt(
        truth, cfa, np.random.default_rng(np.random.SeedSequence(row["noise_seed"])), noise
    )
    guide = {"active": [True, True], "frequencies_xy": row["guide_frequencies_xy"]}
    variants, _ = deliver(
        truth,
        raw,
        cfa,
        {"null": guide},
        noise,
        p.QUERY,
        cfg,
        plan["settings"][row["profile"]]["threshold"],
    )
    plate = compare(
        truth, variants["null-weighted-refit"], variants["null-tangent-predictive-gate"]
    )
    columns = {
        "weighted-refit": "Wave refit",
        "global-energy": "Whole-query cap",
        "local-peak": "Local signed peaks",
        "local-energy": "Local energy",
    }
    board = Image.new("RGB", (176 * len(columns) + 8, 198), "#eeeeee")
    draw = ImageDraw.Draw(board)
    measure_area = p.MEASURE
    for j, (name, title) in enumerate(columns.items()):
        values = np.max(
            np.abs(plate[name][measure_area].astype(float) - truth[measure_area]) * 65535, axis=0
        )
        np.testing.assert_allclose(values.max(), row["metrics"][f"null-{name}"]["max_abs_DN16"])
        gray = np.rint(np.clip(values / 36, 0, 1) * 255).astype(np.uint8)
        x = 8 + 176 * j
        draw.text((x, 4), title, fill="black")
        draw.text((x, 184), f"Peak {values.max():.2f} DN16", fill="black")
        board.paste(Image.fromarray(gray).convert("RGB"), (x, 22))
    file = out / "max-rail-correction.png"
    board.save(file)
    return {
        "image": reference(file),
        "control_source": reference(path),
        "style": row["style"],
        "profile": row["profile"],
        "trial": row["trial"],
        "scale": "black=0 DN16, white=36 DN16",
        "ROI_xywh": [48, 48, 160, 160],
    }


def main():
    source = ROOT / "output/collection.json"
    done = read_json(source)
    plan = read_json(checked(done["plan"]))
    out = ROOT / "review"
    out.mkdir()
    rows, boards, synth_verified, per_case = synthetic(done, plan, out)
    cameras, camera_verified = camera(done["camera"], plan, out)
    panel = {label: summarize_null(label) for label in ("retained", "fresh")}
    write_json(
        out / "result.json",
        {
            "collection": reference(source),
            "producer": reference(__file__),
            "direct_scorer": reference(DIRECT),
            "results": rows,
            "per_case": per_case,
            "camera": cameras,
            "boards": boards,
            "nulls": panel,
            "rail_peak": worst_rail(plan, out),
            "verified_arrays": synth_verified + camera_verified,
        },
    )


if __name__ == "__main__":
    main()
