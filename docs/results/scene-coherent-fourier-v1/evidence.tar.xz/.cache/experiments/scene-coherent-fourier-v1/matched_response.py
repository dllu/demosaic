"""Describe the tradeoff at equal observed response using the archived gain terms."""

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from transfer_coherence import CONTINUING, FALSE, ROOT, values

RESPONSE = "fundamental_response"
METRICS = (RESPONSE, CONTINUING, FALSE, "exact_flat_RMS_DN16", "fundamental_intact_RMS_DN16")
METHODS = ("staggered_mean", "staggered_selected", "coherent_phase", "coherent_strength", "dense")


def table(group, gains):
    widths = [row["width"]["4800"] for row in group]
    target = values(widths, "coherent_strength", RESPONSE, gains["coherent_strength"]).mean()
    report = {}
    for name in METHODS:
        origin = values(widths, name, RESPONSE, 0).mean()
        slope = values(widths, name, RESPONSE, 1).mean() - origin
        scale = float((target - origin) / slope)
        assert slope > 0 and 0 <= scale <= 0.4
        results = {}
        for metric in METRICS:
            subset = [w for w in widths if metric in w["origin"]]
            results[metric] = float(values(subset, name, metric, scale).mean())
        report[name] = {"gain": scale, "results": results}
    return report


def main():
    binding = reference(ROOT / "calibration.json")
    gains = {k: v["gain"] for k, v in read_json(checked(binding))["strengths"].items()}
    references = {k: reference(ROOT / f"{k}.json") for k in ("prior", "fresh", "transfer")}
    results = {k: table(read_json(checked(v))["rows"], gains) for k, v in references.items()}
    write_json(ROOT / "matched-response.json", {
        "driver": reference(__file__), "calibration": binding, "panels": references,
        "purpose": "Descriptive gain interpolation to the test-set joint gate's response.",
        "matched": results,
    })


if __name__ == "__main__":
    main()
