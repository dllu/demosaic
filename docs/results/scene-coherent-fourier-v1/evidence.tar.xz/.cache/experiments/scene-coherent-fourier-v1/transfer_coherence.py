"""Score frozen gains on the independent transfer panel and render exact native crops."""

import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_coherence import CONTINUING, FALSE, LABELS, native_board
from score_coherence import ROOT, field_updates, replay, run, values, wire
from score_staggered import fields as previous_fields, measurements

DATA = "/mnt/external/demosaic/scene-coherent-fourier-v1/transfer"
CANDIDATE = "coherent_strength"
CONTROLS = ("origin", "v120", "dense", "radial", "staggered_mean", "staggered_selected",
            "coherent_phase", CANDIDATE)
REFERENCES = ("dense", "radial", "staggered_mean", "staggered_selected", "origin")


def summarize(rows, gains):
    rng = np.random.default_rng(202611192141)
    widths = [r["width"]["4800"] for r in rows]
    stats = {}
    for metric in sorted({name for row in widths for name in row["origin"]}):
        eligible = [row for row in widths if metric in row["origin"]]
        n = len(eligible)
        draws = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
        means = {k: values(eligible, k, metric, gains.get(k, 0))[draws].mean(axis=1)
                 for k in CONTROLS}
        records = {}
        for k, sample in means.items():
            record = {"value": float(sample[0])}
            for ref in REFERENCES:
                delta = sample - means[ref]
                record[ref] = [float(delta[0]), *np.quantile(delta[1:], [0.025, 0.975]).tolist()]
            records[k] = record
        stats[metric] = {"n": n, "values": records}
    return stats


def exact(receipt, gains):
    source = read_json(checked(receipt))
    gaps = [r for r in source["rows"] if r["width"]["4800"]["gap_pixels"]]

    def change(row, metric):
        data = [row["width"]["4800"]]
        return float(values(data, CANDIDATE, metric, gains[CANDIDATE])[0]
                     - values(data, "staggered_mean", metric, gains["staggered_mean"])[0])

    best = min(gaps, key=lambda r: change(r, CONTINUING))
    adverse = max((r for r in gaps if r is not best), key=lambda r: change(r, FALSE))
    chosen = [(best, "largest reduction in continuing-wire error"),
              (adverse, "largest increase in false projection among remaining cases")]
    root = ROOT / "native/transfer"
    root.mkdir()
    rows = []
    for row, selection in chosen:
        case = row["case"]
        data, parent, v120 = replay.read_inputs(case)
        prior, _ = previous_fields(case, data, parent, 4800, cosine=True)
        newer = field_updates(case, data, parent)
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            target = archive["target"]
        camera = {k: data[k][None] for k in ("colors", "wb", "matrix")}
        frames = prior | newer
        names = {
            "dense": "Dense cosine prior", "radial": "Earlier radial",
            "staggered_mean": "Four-grid mean", "staggered_selected": "Four-grid selected",
            **LABELS,
        }
        labels = ("Noisy Malvar", "V120 EMA", "Corpus 100k", *names.values(), "Exact GT")
        for i, role in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(camera | {"packed": data["packed"][i:i+1]})[0]
            images = [noisy, v120[i], parent[i]]
            images.extend(parent[i] + gains[k] * frames[k][i] for k in names)
            images.append(target[i])
            rows.append(native_board(
                root, f"transfer-{case['fixture']['index']:02}-{role}", images, camera,
                {"case": case, "role": role, "gains": gains, "selection": selection,
                 "difference_vs_four_grid_mean": {k: change(row, k) for k in (CONTINUING, FALSE)}},
                labels=labels, triplet_indices=(0, labels.index(names[CANDIDATE]), len(labels)-1),
                exposure=2, roi=(48, 48, 160, 160),
            ))
    write_json(root / "result.json", {"driver": reference(__file__), "transfer": receipt, "rows": rows})


def main():
    torch.set_num_threads(2)
    calibration = reference(ROOT / "calibration.json")
    gains = {k: v["gain"] for k, v in read_json(checked(calibration))["strengths"].items()}
    binding = reference(DATA + "/parents.json")
    predictions = read_json(checked(binding))
    plan = read_json(checked(predictions["plan"]))
    assert plan["calibration"] == calibration and plan["parent_visits_checked"] == 559808
    assert len(predictions["rows"]) == 32
    rows, elapsed = run(predictions["rows"], lambda case: wire(
        measurements(case, budgets=(4800,), cosine=True)
    ))
    assert sum(r["width"]["4800"]["gap_pixels"] > 0 for r in rows) == 16
    old_replays = {name: reference(ROOT / f"{name}.json") for name in ("prior", "fresh")}
    comparisons = {k: summarize(read_json(checked(ref))["rows"], gains)
                   for k, ref in old_replays.items()}
    output = ROOT / "transfer.json"
    write_json(output, {
        "driver": reference(__file__), "calibration": calibration, "parent_replay": binding,
        "prior_replays": old_replays, "precision": predictions["precision"],
        "weights": predictions["weights"], "rows": rows, "seconds": elapsed,
        "summary": comparisons | {"transfer": summarize(rows, gains)},
    })
    exact(reference(output), gains)


if __name__ == "__main__":
    main()
