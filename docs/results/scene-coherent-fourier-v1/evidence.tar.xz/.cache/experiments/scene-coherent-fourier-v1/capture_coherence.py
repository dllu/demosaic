"""Freeze an unused 32-photo transfer panel and capture the existing FP32 EMAs."""

from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / ROOT.name / "transfer"
SEED = 202611192141
FAMILIES = ("strip", "ellipse", "smooth-dip", "contrast-step")
COUNT = 32
STAGGERED = Path("/mnt/external/demosaic/scene-staggered-phase-v1/fresh/plan.json")
sys.path.insert(0, str(ROOT.with_name("scene-staggered-phase-v1")))
from capture_confirmation import carrier, old


def freeze(calibration):
    previous = reference(STAGGERED)
    settings = read_json(checked(previous))
    exclude = [
        previous, *settings["source_exclusions"],
        reference("/mnt/external/demosaic/wire-regional-amplitude-v1/fresh/plan.json"),
    ]
    seen = set()
    for source in exclude:
        old.scan(read_json(checked(source)), seen)
    for row in old.lines(settings["training_manifest"]):
        old.scan(row, seen)

    eligible = [
        r for r in old.lines(settings["source_pool"])
        if r["split"] == "val" and r["bin_factor"] == 4 and min(r["shape"][:2]) >= 512
        and r["id"] not in seen and r["cache_sha256"] not in seen
    ]
    eligible.sort(key=lambda r: sha256(f"{SEED}/{r['id']}".encode()).digest())
    chosen = []
    old.SEED = SEED
    for row in eligible:
        if row["id"] in seen or row["cache_sha256"] in seen:
            continue
        seen.update((row["id"], row["cache_sha256"]))
        i = len(chosen)
        (box,) = scene_crop_boxes(
            row["shape"][:2], patch_size=512, count=1, seed=scene_seed(SEED, i, "crop")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        camera.update(pattern=tuple(PATTERNS)[i % 4], black=0.03, **{
            k: settings["noise"][k] for k in ("shot", "read", "exposure")
        })
        rng = np.random.default_rng(scene_seed(SEED, i, "geometry-independent"))
        geometry = old.geometry(i)
        geometry.update(
            family=FAMILIES[i // 8],
            frequency=[carrier(rng, 1, (7.25, 8.90)), carrier(rng, -1, (7.20, 9.25))],
            strength=rng.uniform([0.011, 0.0045], [0.016, 0.009]).tolist(),
        )
        chosen.append({
            "source": row, "box": box, "index": i, "camera": camera,
            "geometry": geometry, "partition": "independent_transfer",
        })
        if len(chosen) == COUNT:
            break
    assert len(chosen) == COUNT
    ids = {r["source"]["id"] for r in chosen}
    hashes = {r["source"]["cache_sha256"] for r in chosen}
    visits = 0
    for trace in read_json(checked(settings["parent_traces"]))["source_traces"]:
        for update in old.lines(trace):
            for entry in update["sources"]:
                if entry["kind"] == "photographic":
                    assert entry["source_id"] not in ids and entry["cache_sha256"] not in hashes
                    visits += 1
    assert visits == settings["parent_visits_checked"] == 559808
    OUT.mkdir(parents=True)
    plan = settings | {
        "freeze_driver": reference(__file__), "calibration": calibration,
        "parent_visits_checked": visits, "seed": SEED, "count": COUNT,
        "sources": chosen, "source_exclusions": exclude,
        "primary_comparison": "coherent_strength versus staggered_mean at locked gain",
    }
    target = OUT / "plan.json"
    write_json(target, plan)
    return target, plan


def main():
    settings = reference(ROOT / "calibration.json")
    path, plan = freeze(settings)
    old.N = COUNT
    old.OUT = OUT
    old.ROLES = tuple(plan["roles"])
    torch.cuda.set_per_process_memory_fraction(
        min(1, 10 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    old.run(path)


if __name__ == "__main__":
    main()
