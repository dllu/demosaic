"""Replay both standing scenes and fixed crops at the calibrated gains."""

import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_coherence import BAND, DENSE, MODES, PREVIOUS, ROOT, corrections, encode_banks
from score_coherence import field_updates, patch, replay, values
from atlas_probe import exact_query, load_standing, packed_scene, pixels, render
from render_wide import native_board, native_png, peak_fit
from score_staggered import fields as earlier_fields

CONTINUING = "gap_continuing_strong_RMS_DN16"
FALSE = "fundamental_false_RMS_DN16"
LABELS = {"coherent_phase": "Joint update", "coherent_strength": "Joint gate"}


def standing(calibration, gains):
    start = time.monotonic()
    binding = reference(PREVIOUS / "native/standing/result.json")
    before = {r["id"]: r for r in read_json(checked(binding))["rows"]}
    _, baseline, lookup = load_standing()
    dest = ROOT / "native/standing"
    dest.mkdir(parents=True, exist_ok=True)
    result = []
    for category in ("main", "mesh"):
        group = [r for r in baseline["rows"] if r["id"].startswith(category)]
        source, scene, colors = packed_scene(group)
        for row in group:
            prior = before[row["id"]]
            assert source == prior["raw"] and row["query"] == prior["absolute_query"]
            raw, parent, roi, wb, matrix = exact_query(row, lookup, scene, colors)
            x, y, w, h = roi
            with np.load(checked(prior["paths"]), allow_pickle=False) as saved:
                np.testing.assert_array_equal(raw, saved["raw"])
                np.testing.assert_array_equal(parent, saved["parent"])
                np.testing.assert_array_equal(colors, saved["colors"])
                np.testing.assert_array_equal(wb, saved["wb"])
                np.testing.assert_array_equal(matrix, saved["matrix"])
            shot, read = (row["noise"][k] for k in ("shot", "read"))
            donor = patch.build_exterior(
                scene, colors, row["query"], shot, read, band=BAND, dense_radius=DENSE
            )
            atlas = encode_banks(scene, colors, donor, shot, read)
            new = corrections(raw, parent[1], colors, shot, read, row["query"], atlas)
            updates = {
                k: replay.apply_delta(np.zeros_like(parent), v, wb, matrix, gains[k])
                for k, v in new.items()
            }
            predictions = {k: parent + updates[k] for k in MODES}
            window = np.s_[..., y:y+h, x:x+w]
            dose = {k: float(np.sqrt(np.mean(v[window].astype(float)**2)) * 65535)
                    for k, v in updates.items()}
            projection = matched_projection = {}
            if category == "mesh":
                anchor = prior["rgb_RMS_DN16"]["staggered_mean"]
                equal = {k: parent + (anchor / dose[k]) * updates[k] if dose[k] > 0 else parent
                         for k in MODES}
                same_raw = peak_fit(raw, parent, predictions, colors, roi)
                matched = peak_fit(raw, parent, equal, colors, roi)
                base = np.asarray(same_raw["parent"]["percent_of_observed"])
                projection, matched_projection = (
                    {k: (np.asarray(records[k]["percent_of_observed"]) - base).tolist()
                     for k in MODES} for records in (same_raw, matched)
                )
            views = []
            for d in prior["displays"]:
                existing = pixels(d["board"])
                exposure = d["exposure"]
                np.testing.assert_array_equal(
                    render(parent, wb, matrix, roi, exposure), existing["Corpus 100k"]
                )
                panels = [(k, existing[k]) for k in (
                    "Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Dense cosine prior",
                    "Earlier radial", "Four-grid mean", "Four-grid selected",
                )]
                panels.extend((label, render(predictions[k], wb, matrix, roi, exposure))
                              for k, label in LABELS.items())
                panels.extend((k, existing[k]) for k in (
                    "ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG"
                ) if k in existing)
                view = native_png(dest / f"{row['id']}-x{exposure:g}.png", panels)
                views.append({"exposure": exposure, "board": view})
            result.append({
                "id": row["id"], "raw": prior["raw"], "global_roi": prior["global_roi"],
                "absolute_query": prior["absolute_query"], "noise": prior["noise"],
                "parent_arrays": prior["paths"], "reference": prior["native_reference"],
                "rgb_RMS_DN16": dose, "projection_points": projection,
                "matched_four_grid_projection_points": matched_projection, "displays": views,
            })
    write_json(dest / "result.json", {
        "driver": reference(__file__), "baseline": binding, "calibration": calibration,
        "rows": result, "seconds": time.monotonic() - start,
    })


def crop_views(calibration, gains):
    binding = reference(ROOT / "fresh.json")
    receipt = read_json(checked(binding))
    assert receipt["lock"] == calibration
    family = [v for v in receipt["rows"] if v["width"]["4800"]["gap_pixels"]]
    candidate = "coherent_phase"

    def delta(row, metric):
        group = [row["width"]["4800"]]
        return float(
            values(group, candidate, metric, gains[candidate])[0]
            - values(group, "staggered_mean", metric, gains["staggered_mean"])[0]
        )

    best = min(family, key=lambda v: delta(v, CONTINUING))
    adverse = max((v for v in family if v is not best), key=lambda v: delta(v, FALSE))
    dest = ROOT / "native/exact"
    dest.mkdir(parents=True, exist_ok=True)
    found = []
    for row, label in ((best, "largest continuing-wire improvement"),
                       (adverse, "largest false-gap increase among the remaining cases")):
        case = row["case"]
        data, parent, v120 = replay.read_inputs(case)
        new = field_updates(case, data, parent)
        original, _ = earlier_fields(case, data, parent, 4800, cosine=True)
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            truth = archive["target"]
        camera = {k: data[k][None] for k in ("colors", "wb", "matrix")}
        for i, role in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(camera | {"packed": data["packed"][i:i+1]})[0]
            selected = [
                ("Dense cosine prior", "dense"), ("Earlier radial", "radial"),
                ("Four-grid mean", "staggered_mean"), ("Four-grid selected", "staggered_selected"),
            ]
            estimates = [noisy, v120[i], parent[i]]
            estimates.extend(parent[i] + gains[k] * original[k][i] for _, k in selected)
            estimates.extend(parent[i] + gains[k] * new[k][i] for k in MODES)
            estimates.append(truth[i])
            labels = ["Noisy Malvar", "V120 EMA", "Corpus 100k", *(n for n, _ in selected),
                      *LABELS.values(), "Exact GT"]
            found.append(native_board(
                dest, f"offgrid-{case['fixture']['index']:02}-{role}", estimates, camera,
                {"case": case, "role": role, "selection": label, "gains": gains,
                 "differences_vs_four_grid_mean": {k: delta(row, k) for k in (CONTINUING, FALSE)}},
                labels=labels, triplet_indices=(0, labels.index(LABELS[candidate]), len(labels)-1),
                exposure=2, roi=(48, 48, 160, 160),
            ))
    write_json(dest / "result.json", {
        "driver": reference(__file__), "comparison": binding, "calibration": calibration,
        "rows": found,
    })


if __name__ == "__main__":
    torch.set_num_threads(2)
    calibration = reference(ROOT / "calibration.json")
    strengths = read_json(checked(calibration))["strengths"]
    gains = {k: v["gain"] for k, v in strengths.items()}
    assert sys.argv[1] in ("standing", "exact")
    (standing if sys.argv[1] == "standing" else crop_views)(calibration, gains)
