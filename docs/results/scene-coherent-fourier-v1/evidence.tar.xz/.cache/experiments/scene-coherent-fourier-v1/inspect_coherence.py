"""Lay out individual native cells and summarize the paired differences."""

import os
import sys

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_coherence import CONTINUING, FALSE, ROOT, pixels


def sheet(key, rows, labels):
    canvas = Image.new("RGB", (8 + 168*len(labels), 26 + 184*len(rows)), "#eeeeee")
    title = ImageDraw.Draw(canvas)
    for col, label in enumerate(labels):
        title.text((8 + 168*col, 5), label, fill="black")
    for row, (label, board) in enumerate(rows):
        values = pixels(board)
        for col, name in enumerate(labels):
            panel = Image.fromarray(values[name])
            assert panel.size == (160, 160)
            canvas.paste(panel, (8 + 168*col, 26 + 184*row))
        title.text((8, 188 + 184*row), label, fill="black")
    file = ROOT / f"view-{key}.png"
    canvas.save(file)
    return reference(file)


def standing():
    source = reference(ROOT / "native/standing/result.json")
    boards = read_json(checked(source))["rows"]
    primary = ("Noisy (Malvar)", "Corpus 100k", "Four-grid mean", "Joint update",
               "Joint gate", "ISO100 AHD reference")
    controls = ("V120 EMA", "Dense cosine prior", "Earlier radial", "Four-grid selected")
    output = {}
    for group, exposure in (("main", 4), ("mesh", 4), ("mesh", 16)):
        key = f"{group}-x{exposure}"
        rows = [(r["id"], d["board"]) for r in boards if r["id"].startswith(group)
                for d in r["displays"] if d["exposure"] == exposure]
        assert len(rows) == 4
        output[key] = sheet(key, rows, primary)
        extra = ("ISO6400 camera JPEG", "ISO100 camera JPEG") if group == "mesh" else ()
        output[key + "-controls"] = sheet(key + "-controls", rows, controls + extra)
    write_json(ROOT / "standing-views.json", {
        "driver": reference(__file__), "source": source, "sheets": output,
    })


def results():
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    exact = reference(ROOT / "native/transfer/result.json")
    samples = read_json(checked(exact))["rows"]
    labels = ("Noisy Malvar", "Corpus 100k", "Four-grid mean", "Joint update", "Joint gate", "Exact GT")
    views = sheet("transfer", [(r["id"], r["board"]) for r in samples], labels)
    comparison = reference(ROOT / "transfer.json")
    summary = read_json(checked(comparison))["summary"]
    titles = ("Intact weak response", "Continuing-wire error", "False weak projection", "Exact-flat RMS")
    metrics = ("fundamental_response", CONTINUING, FALSE, "exact_flat_RMS_DN16")
    methods = ("coherent_phase", "coherent_strength", "dense")
    groups = ("prior", "fresh", "transfer")
    fig, axes = plt.subplots(2, 2, figsize=(9.8, 5.1), layout="constrained")
    for axis, metric, title, units in zip(
        axes.flat, metrics, titles, ("Percentage points", "DN16", "DN16", "DN16"), strict=True
    ):
        axis.axvline(0, color="#666666", linewidth=1)
        for method, name, color, shift in zip(
            methods, ("Joint update", "Joint gate", "Dense cosine"),
            ("#187b85", "#b34d37", "#555555"), (-0.19, 0, 0.19), strict=True
        ):
            points = np.array([
                summary[group][metric]["values"][method]["staggered_mean"] for group in groups
            ])
            mid, low, high = points.T
            axis.errorbar(mid, np.arange(3) + shift, xerr=(mid-low, high-mid), color=color,
                          label=name, fmt="o", markersize=4, capsize=3)
        axis.set_title(title)
        axis.set_xlabel(units)
        axis.set_yticks(range(3), ("First replay", "Second replay", "New transfer"))
        axis.set_ylim(2.42, -0.42)
        axis.grid(axis="x", alpha=0.15)
    axes[0, 0].legend(loc="upper left", bbox_to_anchor=(0, 1.43), fontsize=8, ncols=3)
    dst = ROOT / "paired-effects.png"
    fig.savefig(dst, dpi=155)
    write_json(ROOT / "transfer-views.json", {
        "driver": reference(__file__), "source": exact, "comparison": comparison,
        "sheets": {"exact": views}, "plot": reference(dst),
    })


if __name__ == "__main__":
    assert sys.argv[1] in ("standing", "transfer")
    (standing if sys.argv[1] == "standing" else results)()
