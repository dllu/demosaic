"""Bind the pilot, unused-source transfer, and reviewed native PNGs."""

from datetime import datetime
from hashlib import file_digest, sha256
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_coherence import LABELS, PREVIOUS, ROOT, pixels

REPO = ROOT.parents[2]
EXTERNAL = Path("/mnt/external/demosaic")
IMAGES = REPO / "docs/images" / ROOT.name
OUTPUT = REPO / "docs/results" / ROOT.name
STAGES = {
    "calibration": "calibration.json",
    "first_replay": "prior.json",
    "second_replay": "fresh.json",
    "natural": "natural.json",
    "transfer": "transfer.json",
    "standing": "native/standing/result.json",
    "exact": "native/transfer/result.json",
    "standing_views": "standing-views.json",
    "transfer_views": "transfer-views.json",
    "matched_response": "matched-response.json",
}


def save(binding, subdir=""):
    path = checked(binding)
    target = IMAGES / subdir / path.name
    shutil.copyfile(path, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return binding | {"path": str(target.relative_to(IMAGES))}


def verify_board(board, subdir):
    crops = pixels(board)
    assert len(crops) == len(board["panels"])
    assert all(p.shape == (160, 160, 3) for p in crops.values())
    return board | {"image": save(board["image"], subdir)}


def main():
    receipts = {k: reference(ROOT / v) for k, v in STAGES.items()}
    data = {k: read_json(checked(ref)) for k, ref in receipts.items()}
    cal, prior, second, natural, new, standing, exact, stood, viewed, matched = data.values()
    assert new["calibration"] == standing["calibration"] == matched["calibration"] == receipts["calibration"]
    assert prior["lock"] == second["lock"] == natural["lock"] == receipts["calibration"]
    assert exact["transfer"] == viewed["comparison"] == receipts["transfer"]
    assert stood["source"] == receipts["standing"] and viewed["source"] == receipts["exact"]
    assert len(cal["calibration"]) == 16 and all(cal["invariants"].values())
    assert len(natural["rows"]) == 32 and len(prior["rows"]) == len(second["rows"]) == 24

    replay = read_json(checked(new["parent_replay"]))
    plan = read_json(checked(replay["plan"]))
    assert replay["weights"] == plan["weights"] == new["weights"]
    assert plan["calibration"] == receipts["calibration"] and plan["parent_visits_checked"] == 559808
    assert len(new["rows"]) == len(replay["rows"]) == len(plan["sources"]) == 32
    for attr in ("id", "cache_sha256"):
        testing = {r["case"]["source"][attr] for r in new["rows"]}
        old = {r["case"]["source"][attr] for panel in (prior["rows"], second["rows"],
               natural["rows"], cal["calibration"]) for r in panel}
        assert len(testing) == 32 and testing.isdisjoint(old)
    for bound, row in zip(replay["rows"], new["rows"], strict=True):
        assert row["case"] == bound
        checked(bound["input"])
        checked(bound["rgb"])
    for ref in (*stood["sheets"].values(), *viewed["sheets"].values()):
        checked(ref)

    (IMAGES / "standing").mkdir(parents=True)
    (IMAGES / "exact").mkdir()
    OUTPUT.mkdir(parents=True)
    gallery = []
    for row in standing["rows"]:
        mesh = row["id"].startswith("mesh")
        assert {d["exposure"] for d in row["displays"]} == ({4, 16} if mesh else {4})
        displays = []
        for d in row["displays"]:
            required = {"Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Four-grid mean",
                        "ISO100 AHD reference", *LABELS.values()}
            if mesh:
                required |= {"ISO6400 camera JPEG", "ISO100 camera JPEG"}
            assert required <= pixels(d["board"]).keys()
            displays.append(d | {"board": verify_board(d["board"], "standing")})
        gallery.append(row | {"displays": displays})
    assert len(gallery) == 8 and sum(len(row["displays"]) for row in gallery) == 12
    crops = []
    for row in exact["rows"]:
        all_cells, triplet = (pixels(row[k]) for k in ("board", "triplet"))
        assert list(triplet) == ["Noisy Malvar", "Joint gate", "Exact GT"]
        for key, cell in triplet.items():
            np.testing.assert_array_equal(cell, all_cells[key])
        crops.append(row | {k: verify_board(row[k], "exact") for k in ("board", "triplet")})
    assert len(crops) == 4
    manifest = IMAGES / "manifest.json"
    write_json(manifest, {
        "weights": new["weights"], "weight_type": "EMA", "plan": replay["plan"],
        "crop_size": [160, 160], "exact": crops, "standing": gallery, "plot": save(viewed["plot"]),
        "review": {
            "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "sheets": {k: receipts[k] for k in ("standing_views", "transfer_views")},
            "standing": "Smooth main sky, connected coarse links, and soft building cables and fine foliage. "
                        "The transferred right cab retains the clearest diagonal traces. Fine crossings remain "
                        "incomplete. Both ROIs and profiles reviewed at both displays with both JPEGs and AHD.",
            "exact": "Two independent transfer photos and their flat controls viewed at matched coordinates "
                     "and display exposure. Native photos show a predominantly stronger direction.",
        },
    })

    payload = [
        *receipts.values(), *(r["driver"] for r in data.values()), cal["operator"],
        cal["virgin_controls"], prior["source"], second["source"], natural["source"],
        new["parent_replay"], replay["plan"], plan["driver"], plan["freeze_driver"], plan["fixture"],
        standing["baseline"], reference(manifest), reference(__file__),
        reference(PREVIOUS / "staggered_phase.py"),
        reference(PREVIOUS / "score_staggered.py"),
        reference(PREVIOUS / "capture_confirmation.py"),
        reference(REPO / "src/demosaic/scene_patch_covariance.py"),
        reference(REPO / "configs/gfx-qualitative-20231231.json"),
        reference(REPO / "configs/gfx-green-mesh-20231231.json"),
    ]
    archive = OUTPUT / "evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for ref in {r["path"]: r for r in payload}.values():
            file = checked(ref)
            name = (file.relative_to(REPO) if file.is_relative_to(REPO)
                    else Path("external") / file.relative_to(EXTERNAL)).as_posix()
            tar.add(file, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(archive) as tar:
        assert all(file_digest(tar.extractfile(k), sha256).hexdigest() == v for k, v in members.items())
    write_json(OUTPUT / "publication.json", {
        "scope": "Inference-only 32-photo independent transfer, two earlier off-grid replays, "
                 "32 natural pairs and both standing GFX scenes on the frozen Corpus 100k EMA.",
        "weights": new["weights"], "weight_type": "EMA", "precision": new["precision"],
        "gains": cal["strengths"], "metrics": new["summary"], "natural": natural["summary"],
        "matched_response": matched["matched"],
        "seconds": {k: data[k]["seconds"] for k in ("calibration", "natural", "standing",
                    "first_replay", "second_replay", "transfer")} | {"parent_capture": replay["seconds"]},
        "receipts": receipts, "manifest": reference(manifest), "archive": reference(archive),
        "members": members,
    })


if __name__ == "__main__":
    main()
