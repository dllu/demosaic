"""Lock staggered-grid gains on retained calibration and score independent fields."""

import sys
from pathlib import Path

import numpy as np
from scipy.optimize import brentq
from staggered_phase import MODES, ROOT, corrections, encode_banks, patch
from consensus_measure import BAND, BUDGETS, DENSE, replay, run, summary, summarize_natural
from evaluate_wide import FLAT, RESPONSE, WireFundamental, values

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

PRIOR = ROOT.with_name("scene-query-consensus-v1")
OUT = Path("/mnt/external/demosaic") / ROOT.name / "fresh"
QUIET = 0.10


def fields(case, f, base, budget, *, cosine=False):
    shot, read = (case["profile"][k] for k in ("shot", "read"))
    scene, colors = (f[k] for k in ("scene_packed", "colors"))
    query = case["box"]
    limit = budget
    if budget < 4800:
        uniform = patch.build_exterior(
            scene, colors, query, shot, read, band=BAND, max_windows=budget
        )
        if uniform is not None:
            limit = max(1, len(uniform.coords))
    dense = patch.build_exterior(
        scene, colors, query, shot, read, band=BAND, max_windows=limit, dense_radius=DENSE
    )
    bank = encode_banks(scene, colors, dense, shot, read)
    output = {}
    for raw, parent in zip(f["packed"], base, strict=True):
        updates = corrections(raw, parent[1], shot, read, query, bank)
        if cosine:
            updates["dense"] = patch.corrections(
                raw, parent[1], colors, shot, read, query, dense, validate_donors=True
            )["donor_and_query"]
        for k, d in updates.items():
            item = replay.apply_delta(np.zeros_like(parent), d, f["wb"], f["matrix"], 1)
            output.setdefault(k, []).append(item)
    return {k: np.stack(v) for k, v in output.items()}, 0 if dense is None else len(dense.coords)


def measurements(case, *, budgets, cosine=False):
    data, base, v120 = replay.read_inputs(case)
    additions = {i: fields(case, data, base, i, cosine=cosine) for i in budgets}
    with np.load(checked(case["input"]), allow_pickle=False) as src:
        truth = {k: src[k] for k in ("target", "support")}
    metric = WireFundamental(data | truth, case["fixture"]["geometry"])
    parent = base.astype(np.float64)
    score = metric(parent)
    result = {}
    for budget, (fields_, count) in additions.items():
        terms = {}
        for name, delta in fields_.items():
            plus, minus = metric(parent + delta), metric(parent - delta)
            terms[name] = {}
            for k, v in score.items():
                terms[name][k] = (
                    [v, (plus[k] - minus[k]) / 2]
                    if k in RESPONSE
                    else [
                        v**2,
                        (plus[k] ** 2 - minus[k] ** 2) / 2,
                        (plus[k] ** 2 + minus[k] ** 2) / 2 - v**2,
                    ]
                )
        result[str(budget)] = {
            "origin": score,
            "v120": metric(v120),
            "gap_pixels": int(metric.gap.sum()),
            "terms": terms,
            "windows": {"dense": count},
        }
    return {"case": case, "width": result}


def retained_wire(old):
    replayed = measurements(old["case"], budgets=BUDGETS)
    for b, group in replayed["width"].items():
        old_group = old["width"][b]
        assert group["windows"]["dense"] == old_group["windows"]["dense"]
        for k, actual in group["terms"]["radial"].items():
            np.testing.assert_allclose(actual, old_group["terms"]["radial"][k], atol=1e-10, rtol=0)
        group["terms"] = old_group["terms"] | group["terms"]
    return replayed


def calibrate(rows, prior):
    output = {}
    for budget in BUDGETS:
        key = str(budget)
        subset = [r["width"][key] for r in rows]
        baseline = values(subset, "origin", FLAT, 0)
        constrained = {
            k: d for k, d in prior[key].items() if k in ("dense", "phase_pair", "separate")
        }
        for method in MODES:

            def increase(gain):
                return float(np.mean(values(subset, method, FLAT, gain) - baseline))

            g = brentq(lambda s: increase(s) - QUIET, 0, 0.8) if increase(0.8) > QUIET else 0.8
            constrained[method] = {"gain": g, "flat_DN16": increase(g)}
        np.testing.assert_allclose(
            constrained["radial"]["gain"], prior[key]["radial"]["gain"], atol=1e-12, rtol=0
        )
        output[key] = constrained
    return output


def natural(old):
    data, base, _ = replay.read_inputs(old["case"])
    change, count = fields(old["case"], data, base, 4800)
    assert count == old["windows"]["dense"]
    with np.load(checked(old["case"]["input"]), allow_pickle=False) as src:
        gt = replay.transform(src["target"], data)
    parent = replay.transform(base, data)
    comparisons = {
        k: old["terms"][k] for k in ("parent", "v120", "dense", "phase_pair", "separate")
    }
    for k, delta in change.items():
        adjusted = replay.transform(delta, data)
        comparisons[k] = {
            band: replay.terms(v, adjusted[band], gt[band]) for band, v in parent.items()
        }
    for band, modes in comparisons["radial"].items():
        for val, exact in zip(modes.values(), old["terms"]["radial"][band].values(), strict=True):
            np.testing.assert_allclose(val, exact, atol=1e-10, rtol=0)
    return {**old, "terms": comparisons}


def offgrid_summary(rows, gains):
    output = {}
    rng = np.random.default_rng(202611192150)
    keys = tuple(rows[0]["width"]["4800"]["terms"])
    compared = ("origin", "v120", *keys)
    for name in sorted({m for r in rows for m in r["width"]["4800"]["origin"]}):
        eligible = [r["width"]["4800"] for r in rows if name in r["width"]["4800"]["origin"]]
        indices = np.vstack(
            (np.arange(len(eligible)), rng.integers(0, len(eligible), (8000, len(eligible))))
        )
        ms = {k: values(eligible, k, name, gains.get(k, 0))[indices].mean(axis=1) for k in compared}
        records = {}
        for mode, v in ms.items():
            rec = {"value": float(v[0])}
            for ref in ("origin", "radial", "pruned_integer", "dense"):
                d = v - ms[ref]
                rec[ref] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
            records[mode] = rec
        output[name] = {"count": len(eligible), "values": records}
    return output


def run_retained():
    ancestor = reference(PRIOR / "results.json")
    numeric = read_json(checked(ancestor))
    old = read_json(checked(numeric["calibration"]))
    calibration, cseconds = run(old["calibration"], retained_wire)
    fit = calibrate(calibration, old["strengths"])
    lock = ROOT / "calibration.json"
    write_json(
        lock,
        {
            "driver": reference(__file__),
            "operator": reference(ROOT / "staggered_phase.py"),
            "retained_source": ancestor,
            "previous_calibration": numeric["calibration"],
            "strengths": fit,
            "calibration": calibration,
            "seconds": cseconds,
        },
    )
    print("FROZEN", fit, flush=True)
    long, lsec = run(numeric["long"], retained_wire)
    short, ssec = run(numeric["short"], retained_wire)
    photos, nsec = run(numeric["natural"], natural)
    write_json(
        ROOT / "retained.json",
        {
            "driver": reference(__file__),
            "calibration": reference(lock),
            "long": long,
            "short": short,
            "natural": photos,
            "time_seconds": {"long": lsec, "short": ssec, "natural": nsec},
            "scores": {
                "long": summary(long, fit),
                "short": summary(short, fit),
                "natural": summarize_natural(photos, fit["4800"]),
            },
        },
    )


def run_offgrid(name):
    if name == "prior":
        binding = reference(PRIOR / "fresh-score.json")
        original = read_json(checked(binding))
        cases = [r["case"] for r in original["rows"]]
    else:
        assert name == "fresh"
        binding = reference(OUT / "parents.json")
        original = read_json(checked(binding))
        cases = original["rows"]
    f = reference(ROOT / "calibration.json")
    lock = read_json(checked(f))
    gains = {k: v["gain"] for k, v in lock["strengths"]["4800"].items()}
    rows, elapsed = run(cases, lambda r: measurements(r, budgets=(4800,), cosine=True))
    assert len(rows) == 24 and sum(r["width"]["4800"]["gap_pixels"] > 0 for r in rows) == 16
    if name == "prior":
        for row, before in zip(rows, original["rows"], strict=True):
            assert row["case"]["id"] == before["case"]["id"]
            for mode in ("dense", "radial"):
                for metric, exact in before["scores"][mode].items():
                    got = values([row["width"]["4800"]], mode, metric, gains[mode])[0]
                    np.testing.assert_allclose(got, exact, atol=1e-9, rtol=0)
    write_json(
        ROOT / f"offgrid-{name}.json",
        {
            "driver": reference(__file__),
            "calibration": f,
            "input": binding,
            "gains": gains,
            "rows": rows,
            "summary": offgrid_summary(rows, gains),
            "seconds": elapsed,
        },
    )


if __name__ == "__main__":
    if sys.argv[1] == "retained":
        run_retained()
    else:
        run_offgrid(sys.argv[1])
