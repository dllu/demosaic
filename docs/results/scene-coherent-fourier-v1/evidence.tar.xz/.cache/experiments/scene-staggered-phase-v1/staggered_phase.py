"""Validate shifted sine/cosine pairs with disjoint RAW donor windows."""

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from pathlib import Path
import sys

import numpy as np

from demosaic import scene_patch_covariance as patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.with_name("scene-query-consensus-v1")))
from query_consensus import paired_query_support, phase_basis, unit_direction
from phase_pairs import limit_pair_amplitude

SHIFTS = ((0, 0), (0, 0.5), (0.5, 0), (0.5, 0.5))
MODES = ("radial", "pruned_integer", "staggered_mean", "staggered_selected")
NUISANCE_LOW = 0.04


@dataclass(frozen=True)
class SpectralGrid:
    basis: patch.PatchBasis
    frequency: np.ndarray
    covariance: np.ndarray
    noise_power: np.ndarray
    condition: float | None


def grid_info(basis, freq, condition):
    gram = basis.projection @ basis.projection.swapaxes(-1, -2)
    slots = np.arange(len(basis.image)).reshape(-1, 2)
    cov = gram[:, slots[:, :, None], slots[:, None, :]]
    noise = np.sum(cov[0] * cov[1], axis=(-1, -2)) / 16
    return SpectralGrid(basis, freq, cov, noise, condition)


@lru_cache(maxsize=24)
def staggered_grid(colors, band, shift):
    """Fit separately well-conditioned lattices rather than one redundant matrix."""
    n = band.size
    green = np.flatnonzero(np.asarray(colors) == 1)
    if len(colors) != 4 or len(green) != 2:
        raise ValueError("Expected two physical greens in a Bayer layout")
    radius = int(np.ceil(n * 0.224))
    off_y, off_x = shift
    candidates = np.array(
        [
            (y + off_y, x + off_x)
            for y, x in product(range(radius + 1), range(-radius, radius + 1))
            if (y + off_y > 0 or x + off_x > 0)
            and NUISANCE_LOW * n <= np.hypot(y + off_y, x + off_x) <= 0.224 * n
        ]
    )
    length = np.linalg.norm(candidates, axis=1) / n
    usable = (length >= band.low) & (length <= band.high)
    if not np.any(usable):
        raise ValueError("The detail band does not intersect the shifted grid")
    axis = (np.arange(n) - (n - 1) / 2) / n
    yy, xx = np.meshgrid(axis, axis, indexing="ij")
    theta = 2 * np.pi * np.einsum("ki,iyx->kyx", candidates, np.stack((yy, xx)))
    waves = np.sqrt(2) / n * np.stack((np.cos(theta), np.sin(theta)), axis=1)
    plane = np.stack((np.full_like(xx, 1 / n), xx / np.linalg.norm(xx), yy / np.linalg.norm(yy)))
    nuisance = np.concatenate((plane, waves[~usable].reshape(-1, n, n)))
    delivered = waves[usable].reshape(-1, n, n)
    design = np.concatenate((nuisance, delivered)).reshape(-1, n, n)
    gather = np.stack([design[:, g // 2 :: 2, g % 2 :: 2] for g in green])
    matrix = gather.reshape(2, len(design), -1).transpose(0, 2, 1)
    cond = float(np.linalg.cond(matrix).max())
    if not np.isfinite(cond) or cond > 128:
        raise ValueError("Ill-conditioned shifted basis")
    projection = np.linalg.pinv(matrix)[:, len(nuisance) :]
    basis = patch.PatchBasis(green, projection, delivered, np.arange(len(delivered)))
    return grid_info(basis, candidates[usable] / n, cond)


def encode_banks(raw, colors, bank, shot, read):
    if bank is None or len(bank.coords) < 8:
        return None
    previous, frequency = phase_basis(tuple(colors), bank.band)
    grids = [grid_info(previous, frequency, None)]
    grids.extend(staggered_grid(tuple(colors), bank.band, shift) for shift in SHIFTS)
    windows = patch.sample_windows(raw, bank.coords, bank.band.size)
    coefficients = []
    for grid in grids:
        descriptor, values, noise, valid = patch.encode(windows, grid.basis, shot, read)
        np.testing.assert_array_equal(descriptor, bank.features)
        assert valid.all()
        normalized = limit_pair_amplitude(values / (np.sqrt(2) * noise[:, None, None]))
        coefficients.append(normalized.reshape(len(windows), 2, -1, 2))
    # The exterior matcher ranks identical observations across grids.
    joined = patch.ExteriorPatches(
        bank.coords, bank.features, np.concatenate(coefficients, axis=2), bank.band
    )
    return grids, joined


def amplitudes(grid, window, parent, shot, read):
    basis = grid.basis
    feature, fitted, noise, valid = patch.encode(window, basis, shot, read)
    sampled = np.stack([parent[:, g // 2 :: 2, g % 2 :: 2] for g in basis.green], axis=1)
    model = np.einsum("gkp,bgp->bgk", basis.projection, sampled.reshape(len(sampled), 2, -1))
    fitted = fitted.reshape(len(window), 2, -1, 2)
    model = model.reshape(fitted.shape)
    direction = unit_direction(fitted.mean(axis=1))
    gate = paired_query_support(direction, fitted, noise, grid.covariance)
    deficit = np.sum((fitted - model).mean(axis=1) * direction, axis=-1)
    return feature, (gate * np.maximum(deficit, 0) * valid[:, None])[..., None] * direction


def exchange_gain(products, weights, noise_power, cells):
    """Winner selection sees the discovery half only, then checks the held half."""
    broad = np.zeros((len(weights), products.shape[-1]))
    selected = broad.copy()
    confidence = np.minimum(weights.sum(axis=1, keepdims=True), 1)
    query = np.arange(len(weights))
    for source in (0, 1):
        choose, hold = slice(source, None, 2), slice(1 - source, None, 2)
        p, _, eligible = patch.folded_weights(weights[:, choose])
        estimate = np.maximum(np.einsum("bn,bnk->bk", p, products[:, choose]), 0)
        measured = patch.confirmed_power(products[:, hold], weights[:, hold], noise_power)
        signal = np.minimum(estimate, measured) * confidence * eligible
        gain = 0.5 * signal / (1 + signal)
        broad += gain
        scores = estimate / np.sqrt(np.maximum(noise_power, 1e-12))
        for index in cells:
            winners = index[np.argmax(scores[:, index], axis=1)]
            selected[query, winners] += gain[query, winners]
    return broad, selected


def coarse_cells(grids, size):
    frequency = np.concatenate([grid.frequency for grid in grids[1:]]) * size
    nearest = np.floor(frequency + 0.5).astype(int)
    flip = (nearest[:, 0] == 0) & (nearest[:, 1] < 0)
    nearest[flip] *= -1
    return [
        np.flatnonzero(np.all(nearest == value, axis=1)) for value in np.unique(nearest, axis=0)
    ]


def blend(values, images, base, ys, xs, window):
    rendered = np.einsum("nk,kyx->nyx", values.reshape(len(values), -1), images)
    field = np.zeros_like(base)
    np.add.at(field, (ys, xs), rendered * window)
    return field


def corrections(raw, parent, shot, read, box, donor_bank):
    result = {k: np.zeros_like(parent) for k in MODES}
    if donor_bank is None:
        return result
    grids, bank = donor_bank
    size = bank.band.size
    if min(parent.shape) < size:
        return result
    y, x = np.meshgrid(
        *(np.arange(0, n - size + 1, size // 2) for n in parent.shape), indexing="ij"
    )
    coords = np.column_stack((y.ravel(), x.ravel()))
    offset = np.arange(size)
    ys = coords[:, 0, None, None] + offset[:, None]
    xs = coords[:, 1, None, None] + offset[None, :]
    windows = patch.sample_windows(raw, coords, size)
    pairs = [amplitudes(grid, windows, parent[ys, xs], shot, read) for grid in grids]
    feature = pairs[0][0]
    for desc, _ in pairs[1:]:
        np.testing.assert_array_equal(feature, desc)
    donor, weight = patch.choose_exterior(
        feature, coords + np.asarray(box)[[1, 0]], bank, ranked=True
    )
    # Donor tensors are [query, neighbor, green, pair, quadrature].
    products = (donor[:, :, 0] * donor[:, :, 1]).mean(axis=-1)
    bounds = np.insert(np.cumsum([len(g.frequency) for g in grids]), 0, 0)
    noise = np.concatenate([grid.noise_power for grid in grids])
    legacy, _ = exchange_gain(products[..., : bounds[1]], weight, noise[: bounds[1]], ())
    combined = np.concatenate([p[1] for p in pairs[1:]], axis=1)
    entered, selected = exchange_gain(
        products[..., bounds[1] :], weight, noise[bounds[1] :], coarse_cells(grids, size)
    )
    taper = np.sin((offset + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(coords), size, size)))
    extra = bounds[2] - bounds[1]
    common = np.concatenate([grid.basis.image for grid in grids[1:]])
    result["radial"] = blend(
        pairs[0][1] * legacy[..., None], grids[0].basis.image, parent, ys, xs, window
    )
    result["pruned_integer"] = blend(
        combined[:, :extra] * entered[:, :extra, None], grids[1].basis.image, parent, ys, xs, window
    )
    result["staggered_mean"] = blend(
        combined * entered[..., None] / len(SHIFTS), common, parent, ys, xs, window
    )
    result["staggered_selected"] = blend(
        combined * selected[..., None], common, parent, ys, xs, window
    )
    return {k: field / np.maximum(1, norm) for k, field in result.items()}
