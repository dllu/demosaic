"""Compare frozen EMA models across faint natural textures and repeated RAW draws."""

import argparse
import hashlib
import os
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.inference import load_checkpoint
from demosaic.noise import add_noise,variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

ROOT=Path(__file__).resolve().parent
EXPERIMENTS=ROOT.parent
REPO=ROOT.parents[2]
ARGS=("packed","variance","colors","wb","matrix")
CONDITIONS=(
    {"name":"adc","shot":0.,"read":0.,"draws":1,"target":"target","gain":1.,"exposure":1.},
    {"name":"tiny","shot":1e-8,"read":1e-10,"draws":1,"target":"target","gain":1.,"exposure":1.},
    {"name":"iso100","shot":2e-5,"read":1.6e-9,"draws":1,"target":"target","gain":1.,"exposure":1.},
    {"name":"iso6400","shot":.00128,"read":6.5536e-6,"draws":4,"target":"target","gain":1.,"exposure":1.},
    {"name":"natural-shadow","shot":.00128,"read":6.5536e-6,"draws":1,
     "target":"original_target","gain":.125,"exposure":8.},
)


def seed(source,pattern,condition,draw):
    digest=hashlib.sha256(f"faint-noise-v1|{source}|{pattern}|{condition}|{draw}".encode()).digest()
    return int.from_bytes(digest[:8],"little")%(2**63)


def plan():
    faint=EXPERIMENTS/"full427-faint-adc-v1"
    incomplete=EXPERIMENTS/"full-corpus-long86k-adc-panels-v1"
    subset_sources=[reference(incomplete/f"faint-{i}"/"plan.json") for i in (0,1)]
    full_faint=read_json(faint/"plan.json")
    subset=[o for source in subset_sources for o in read_json(checked(source))["observations"]]
    assert len(subset)==64
    ids={item for row in subset for item in row["source_ids"]}
    assert len(ids)==64 and all(len(row["source_ids"])==4 for row in subset)
    all_inputs={row["id"]:row for row in full_faint["observations"]}
    for row in subset:
        previous=all_inputs[row["id"]]
        for key in ("source_ids","input_fingerprints","target","arrays"):
            assert row[key]==previous[key]
    cohort=read_json(faint/"cohort.json")
    assert cohort["training_overlap"]==[] and ids<=set(cohort["source_ids"])
    paths={label:reference(file) for label,file in {
        "faint_source":faint/"plan.json",
        "validation_cohort":faint/"cohort.json",
        "older_86k_review":REPO/"docs/results/full-corpus-long86k-adc-panels-v1/publication.json",
        "100k_checkpoint":EXPERIMENTS/"full-corpus-long100k-review-v1/native/candidate/plan.json",
        "bridge_checkpoint":REPO/"docs/results/near-adc-bridge-training-v1/completed-training.json",
    }.items()}
    before=read_json(checked(subset_sources[0]))["models"]["scale-long86k"]
    parent=read_json(checked(paths["100k_checkpoint"]))["models"]["scale-long100k"]
    bridge=read_json(checked(paths["bridge_checkpoint"]))["models"]
    models={"V120":full_faint["models"]["V120"],"86k":before,"100k":parent,
        "bridge-control":dict(checkpoint=bridge["control"]["checkpoint"],step=800,weights="EMA"),
        "bridge-near":dict(checkpoint=bridge["bridge"]["checkpoint"],step=800,weights="EMA")}
    assert all(r["weights"]=="EMA" for r in models.values())
    chosen=sorted(ids)[:2]
    result={"driver":reference(__file__),"sources":paths,"earlier_subset":subset_sources,
            "observations":sorted(subset,key=lambda r:r["id"]),"conditions":CONDITIONS,
            "models":models,"native_sources":chosen,"source_ids":sorted(ids),"expected_records":len(subset)*8,
            "seeds":"SHA256 of source ID, CFA, profile and draw; positive RAW generated on CPU with FP32 Poisson/read/ADC.",
            "scope":"64 fixed photographed sources, four CFA orders, 512 batches across historical faint-ADC, new tiny/ISO100/four ISO6400 draws and natural shadow observation. Matched CUDA IEEE FP32 EMA. A scoped quality study separate from the primary 427-photo benchmark."}
    write_json(ROOT/"plan.json",result)


def observation(spec,condition,draw):
    with np.load(checked(spec["target"]),allow_pickle=False) as target_file:
        target=target_file[condition["target"]]*condition["gain"]
    with np.load(checked(spec["arrays"]),allow_pickle=False) as f:
        source={key:f[key] for key in ARGS}
    assert {key:fingerprint(value) for key,value in source.items()}==spec["input_fingerprints"]
    if condition["name"]=="adc":
        return source,target,[]
    chosen=[seed(i,spec["pattern"],condition["name"],draw) for i in spec["source_ids"]]
    clean=mosaic(torch.from_numpy(target),torch.from_numpy(source["colors"]))
    shot,read=condition["shot"],condition["read"]
    sensor=torch.cat([add_noise(obj[None],shot,read,black_level=.03,
        generator=torch.Generator().manual_seed(key)) for obj,key in zip(clean,chosen,strict=True)])
    source["packed"]=sensor.numpy()
    source["variance"]=variance_map(sensor,shot,read).numpy()
    return source,target,chosen


def write_arrays(path,values):
    with path.open("xb") as stream:
        np.savez(stream,**values)


@torch.inference_mode()
def collect():
    os.sched_setaffinity(0,[12,13])
    os.nice(9)
    torch.set_num_threads(2)
    cap=9*2**30
    torch.cuda.set_per_process_memory_fraction(min(1,cap/torch.cuda.get_device_properties(0).total_memory))
    declared=reference(ROOT/"plan.json")
    spec=read_json(checked(declared))
    assert reference(__file__)==spec["driver"]
    models={}
    for label,model_spec in spec["models"].items():
        model,state=load_checkpoint(checked(model_spec["checkpoint"]),"cuda")
        assert (state["step"],state["loaded_sha256"])==(model_spec["step"],model_spec["checkpoint"]["sha256"])
        assert "ema" in state
        models[label]=model.eval().to(memory_format=torch.channels_last)
        del state
        print("loaded",label,flush=True)
    destination=ROOT/"collection"
    destination.mkdir()
    count=0
    begin=time.monotonic()
    records=[]
    with ieee_fp32():
        for item in spec["observations"]:
            for condition in spec["conditions"]:
                for draw in range(condition["draws"]):
                    arrays,target,seeds=observation(item,condition,draw)
                    tensors={k:torch.from_numpy(v).cuda() for k,v in arrays.items()}
                    for key in ("packed","variance"):
                        tensors[key]=tensors[key].contiguous(memory_format=torch.channels_last)
                    outputs={}
                    for name,model in models.items():
                        model.set_noise(condition["shot"],condition["read"])
                        value=model(*(tensors[k] for k in ARGS)).detach().cpu().contiguous().numpy()
                        assert value.shape==target.shape and value.dtype==np.float32 and np.isfinite(value).all()
                        outputs[name]=value
                    key=f"{item['id']}-{condition['name']}-{draw}"
                    native=destination/f"{key}.npz"
                    write_arrays(native,arrays|outputs)
                    path=destination/f"{key}.json"
                    write_json(path,{"plan":declared,"case":item["id"],"profile":condition,"draw":draw,
                        "seeds":seeds,"input_fingerprints":{k:fingerprint(v) for k,v in arrays.items()},
                        "target_fingerprint":fingerprint(target),"arrays":reference(native)})
                    records.append(reference(path))
                    count+=1
            if count%32==0:
                print(count,"of",spec["expected_records"],"batches",round(time.monotonic()-begin,1),flush=True)
    assert count==spec["expected_records"]
    write_json(ROOT/"collected.json",{"plan":declared,"records":records,"seconds":time.monotonic()-begin,
           "models":spec["models"],"peak_cuda_GiB":torch.cuda.max_memory_allocated()/2**30,"count":count})
    print("completed",count,flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    plan() if parser.parse_args().plan else collect()
