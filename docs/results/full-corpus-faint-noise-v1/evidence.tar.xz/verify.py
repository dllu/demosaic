"""Reproduce the faint ADC and repeated positive-noise statistics independently."""

import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.adc_bins import adc_bin_projection
from demosaic.archive_metrics import linear_rgb, photometry
from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from diagnose_local_material_detail import fft_dct
from report_full_faint_photo_panel import BAND,LUMA,blocks,original_masks
from measure import ARGS,wait_record

ROOT=Path(__file__).resolve().parent


def archive_predictions(plan,witness):
    prev=plan["sources"]["faint_source"]
    baseline=read_json(checked(prev))["observations"]
    old_root=Path(prev["path"]).parent
    number=next(i for i,b in enumerate(baseline)if b["id"]==witness["id"])
    row=read_json(old_root/"collection"/f"case-{number:03d}.json")
    assert row["id"]==witness["id"]
    assert row["input_fingerprints"]==witness["input_fingerprints"]
    found={"V120":next(v["prediction"] for v in row["variants"]if v["label"]=="V120")}
    for source in plan["earlier_subset"]:
        job=checked(source)
        entries=read_json(job)["observations"]
        for j,other in enumerate(entries):
            if other["id"]==witness["id"]:
                row=read_json(job.parent/"collection"/f"case-{j:03d}.json")
                assert row["input_fingerprints"]==witness["input_fingerprints"]
                found["86k"]=row["variants"][0]["prediction"]
                break
    assert set(found)=={"V120","86k"}
    return found


def render_band(rgb,args):
    luma=np.einsum("c,bchw->bhw",LUMA,linear_rgb(rgb,args))
    tile=blocks(luma)
    transform=fft_dct(fft_dct(tile,-1),-2)
    return transform[...,BAND]


def adc(spec,plan,result):
    with np.load(checked(spec["target"]),allow_pickle=False) as f:
        t=f["target"]
    file=checked(result["arrays"])
    with np.load(file,allow_pickle=False) as f:
        data=dict(f)
    stored=archive_predictions(plan,spec)
    comparison={}
    for model,binding in stored.items():
        earlier=np.load(checked(binding),allow_pickle=False)
        change=photometry(data[model],data|{"target":t})["srgb_psnr"]-photometry(earlier,data|{"target":t})["srgb_psnr"]
        d=data[model].astype(float)-earlier.astype(float)
        comparison[model]={"cpu_reference":binding,"sRGB_PSNR_delta":change.tolist(),
                    "maximum_RGB_absolute_delta_DN16":65535*float(abs(d).max()),"RGB_RMS_delta_DN16":65535*float(np.sqrt(np.mean(d*d)))}
    sensor=torch.from_numpy(data["packed"])
    cfa=torch.from_numpy(data["colors"])
    wb=torch.from_numpy(data["wb"])
    target=mosaic(torch.from_numpy(t),cfa).numpy().astype(float)
    encoded=np.rint(np.clip(sensor.numpy().astype(float)*.97+.03,0,1)*65535).astype(np.uint16)
    for k in ("V120","86k","100k"):
        current=torch.from_numpy(data[k])
        reduced=adc_bin_projection(current,sensor,cfa,wb,bit_depth=16,black_level=.03,quantizer_precision="float64",shot=0.,read=0.)
        predicted=mosaic(reduced,cfa).numpy().astype(float)
        np.testing.assert_array_equal(encoded,np.rint(np.clip(predicted*.97+.03,0,1)*65535).astype(np.uint16))
        old=mosaic(current,cfa).numpy().astype(float)
        assert np.mean((predicted-target)**2)<=np.mean((old-target)**2)+1e-20
    return comparison


def repeated(plan,entry,records):
    with np.load(checked(entry["target"]),allow_pickle=False) as f:
        target=f["target"]
        original=f["original_target"]
    with np.load(checked(entry["arrays"]),allow_pickle=False) as f:
        calibration={k:f[k]for k in ("wb","matrix")}
    selected=original_masks(original,calibration)["0"]
    if not selected.any():
        return None
    true=render_band(target,calibration)[selected]
    outputs={}
    for row in records:
        with np.load(checked(row["arrays"]),allow_pickle=False) as f:
            for name in plan["models"]:
                outputs.setdefault(name,[]).append(render_band(f[name],calibration)[selected]-true)
    verified=[]
    for model,parts in outputs.items():
        estimate=np.asarray(parts)
        pairs=[estimate[i]-estimate[j]for i in range(4)for j in range(i)]
        sample_var=sum(np.sum(v*v)for v in pairs)/(4*3)
        baseline=np.sum(np.var(estimate,axis=0,ddof=1))
        np.testing.assert_allclose(sample_var,baseline,rtol=1e-12,atol=1e-17)
        est_bias=sum(np.sum(estimate[i]*estimate[j])for i in range(4)for j in range(i))/6
        mse=np.mean(np.sum(estimate*estimate,axis=(1,2)))
        np.testing.assert_allclose(est_bias+baseline,mse,rtol=1e-12,atol=1e-17)
        verified.append({"model":model,"pair_product_bias_squared":float(est_bias),
                         "pair_difference_variance":float(baseline),"per_draw_mse":float(mse)})
    return {"verified_blocks":int(selected.sum()),"model_audit":verified}


def main():
    os.sched_setaffinity(0,[19]);os.nice(10);torch.set_num_threads(1)
    launch=read_json(ROOT/"launch.json")
    binding=launch["plan"]
    plan=read_json(checked(binding))
    started=time.monotonic()
    a=[]
    cases=plan["observations"][:5]
    for x in cases:
        front=ROOT/"collection"/f"{x['id']}-adc-0.json"
        meta=wait_record(front,launch["pid"],started)
        refs=[ROOT/"collection"/f"{x['id']}-iso6400-{draw}.json" for draw in range(4)]
        raw=[wait_record(ref,launch["pid"],started)for ref in refs]
        a.append({"case":x["id"],"adcbins_code_exact_and_no_CFA_MSE_increase":True,
                  "matched_CPU_ADC_backend_delta":adc(x,plan,meta),
                  "independent_repeated_check":repeated(plan,x,raw)})
        print(x["id"],flush=True)
    assert sum(w["independent_repeated_check"] is not None for w in a)>=4
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"plan":binding,"results":a})

if __name__=="__main__":
    main()
