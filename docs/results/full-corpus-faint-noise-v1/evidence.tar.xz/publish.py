"""Archive the bound 64-photo study, per-source scores and viewed native outputs."""

import hashlib
import math
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
RESULTS=REPO/"docs/results/full-corpus-faint-noise-v1"
IMAGES=REPO/"docs/images/full-corpus-faint-noise-v1"


def relative(path):
    return {"path":path.relative_to(REPO).as_posix(),"sha256":reference(path)["sha256"]}


def export(source,panels=()):
    old=checked(source)
    new=IMAGES/old.name
    shutil.copyfile(old,new)
    with Image.open(new) as image:
        for p in panels:
            x,y,w,h=p["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
    assert reference(new)["sha256"]==source["sha256"]
    return relative(new)


def inspect_existing_camera():
    source=REPO/"docs/images/near-adc-bridge-native-v1"
    keys=("main-overcast-sky","main-building-detail","main-foliage","main-chain-link-fence",
          "mesh-nominal-fine-green-mesh-left","mesh-nominal-fine-green-mesh-right",
          "mesh-profile3879-fine-green-mesh-left","mesh-profile3879-fine-green-mesh-right")
    return {"scope":"Earlier matched boards, newly re-viewed for context. No new GFX predictions or scoring.",
            "references":"Independent ISO100 RAW comparisons and the camera JPEGs are qualitative references.",
            "boards":[relative(source/(key+".png"))for key in keys]}


def main():
    summary=read_json(ROOT/"summary.json")
    collection=read_json(checked(summary["collection"]))
    assert collection["count"]==512 and len(collection["records"])==512
    assert len(summary["sources"])==64 and len(summary["verified_input_regenerations"])>=16
    checked(summary["score_source"])
    assert len(read_json(ROOT/"verification.json")["results"])==5
    lift=read_json(ROOT/"tiny-lift.json")
    assert len(lift["records"])==64 and len(lift["native_boards"])==2
    assert lift["plan"]==summary["plan"]
    for m,stats in lift["statistics"].items():
        assert math.isclose(stats["raw_psnr"],summary["photometry"]["tiny"][m]["srgb_psnr"],abs_tol=2e-12)
        assert math.isclose(stats["raw_fine_RMS_DN16"],summary["spectra"]["tiny"][m]["fine"]["0"]["rms_DN16"],abs_tol=2e-12)
    notes=read_json(ROOT/"native-notes.json")
    native=[]
    selected=[("base",v)for v in summary["native_boards"] if v["condition"]["name"] in ("adc","iso6400","natural-shadow")]
    selected+=[("tiny",v)for v in lift["native_boards"]]
    assert len(selected)==8 and set(notes)=={v["id"]for _,v in selected}
    RESULTS.mkdir()
    IMAGES.mkdir()
    for scope,item in selected:
        row={k:v for k,v in item.items()if k not in ("board","triplet")}
        for mode in ("board","triplet"):
            v=item[mode]
            row[mode]={**v,"image":export(v["image"],v["panels"])}
        native.append(row|{"observation":notes[row["id"]],"source_scope":scope})
    plot=read_json(ROOT/"plot.json")
    viewing=RESULTS/"viewing.json"
    write_json(viewing,{"native":native,"plot":export(plot["image"]),"actual_native_viewing":True,
         "existing_GFX_review":inspect_existing_camera(),
         "scope":"Viewed all eight published photo comparisons, their eight triplets and the summary plot, plus eight earlier GFX boards."})
    reports=("summary.json","verification.json","paired-model-comparison.json","tiny-lift.json","source-statistics.json.gz")
    for name in reports:
        shutil.copyfile(ROOT/name,RESULTS/name)
    archive=RESULTS/"evidence.tar.xz"
    files={f.name:f for f in ROOT.iterdir() if f.is_file() and f.suffix in (".json",".py",".log",".gz")}
    for path in collection["records"]:
        original=checked(path)
        files["collection/"+original.name]=original
    with tarfile.open(archive,"x:xz",preset=4) as stream:
        for name,path in sorted(files.items()):
            stream.add(path,arcname=name)
    members={name:reference(path)["sha256"] for name,path in files.items()}
    with tarfile.open(archive) as stream:
        assert set(stream.getnames())==set(members)
        for member,digest in members.items():
            assert hashlib.sha256(stream.extractfile(member).read()).hexdigest()==digest
    write_json(RESULTS/"publication.json",{"archive":relative(archive),"members":members,
         "reports":[relative(RESULTS/name)for name in reports],
         "viewed_crops":relative(viewing),"fixed_input_observations":collection["count"]*4,
         "contributing_sources":64,"checkpoint_bindings":collection["models"],
         "scope":"Exact previous 64-source faint ADC subset expanded with positive noise and naturally contrasted shadows."
                 " No optimizer updates or new general benchmark measurements."})


if __name__=="__main__":
    main()
