"""Replay the existing bounded near-ADC lift on all matched tiny-noise photos."""

from collections import defaultdict
import os
from pathlib import Path
from statistics import mean
import time

import numpy as np
import torch

from demosaic.adc_bins import near_adc_residual_projection
from demosaic.archive_metrics import noisy_malvar,photometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_full_faint_photo_panel import BAND,band_sums,original_masks
from report_scene_wave_guides import native_board

from collect import ARGS
from measure import bootstrap,coefficients,wait_record

ROOT=Path(__file__).resolve().parent


def forward(model,values,profile):
    pred,packed,colors,wb=(torch.from_numpy(values[k])for k in (model,"packed","colors","wb"))
    out=near_adc_residual_projection(pred,packed,colors,wb,shot=profile["shot"],read=profile["read"],black_level=.03)
    return out.numpy(),out is pred


def main():
    os.sched_setaffinity(0,[19]);os.nice(11);torch.set_num_threads(1)
    started=time.monotonic()
    inputs=read_json(ROOT/"launch.json")
    plan=read_json(checked(inputs["plan"]))
    output=ROOT/"tiny-native"
    output.mkdir()
    performance=defaultdict(lambda:defaultdict(list))
    spectra=defaultdict(lambda:defaultdict(dict))
    records=[]
    boards=[]
    bypass=[]
    for i,row in enumerate(plan["observations"]):
        key=f"{row['id']}-tiny-0"
        source=ROOT/"collection"/f"{key}.json"
        case=wait_record(source,inputs["pid"],started)
        with np.load(checked(case["arrays"]),allow_pickle=False) as f:
            values=dict(f)
        with np.load(checked(row["target"]),allow_pickle=False)as f:
            target,original=f["target"],f["original_target"]
        masks=original_masks(original,values)
        truth=coefficients(target,values)[...,BAND]
        fixed={}
        for model in plan["models"]:
            fixed[model],returned=forward(model,values,case["profile"])
            assert not returned
            for policy,pred in (("raw",values[model]),("bounded",fixed[model])):
                photo=photometry(pred,values|{"target":target})["srgb_psnr"]
                spectral=band_sums(coefficients(pred,values)[...,BAND],truth,masks)
                for n,identity in enumerate(row["source_ids"]):
                    group=performance[model,policy][identity]
                    group.append(float(photo[n]))
                    parts=spectra[model,policy].setdefault(identity,[])
                    if "0" in spectral[n]:
                        parts.append(spectral[n]["0"])
        if row["pattern"]=="RGGB":
            for n,identity in enumerate(row["source_ids"]):
                if identity not in plan["native_sources"]:
                    continue
                item={k:values[k][n:n+1]for k in ARGS}
                raw=noisy_malvar(item)[0]
                images=(raw,values["V120"][n],fixed["V120"][n],values["100k"][n],
                        fixed["100k"][n],values["bridge-control"][n],fixed["bridge-control"][n],
                        values["bridge-near"][n],fixed["bridge-near"][n],target[n])
                labels=("Noisy Malvar","V120","V120 bounded","100k","100k bounded",
                        "Control","Control bounded","Near-ADC","Near-ADC bounded","Exact GT")
                boards.append(native_board(output,identity+"-tiny-lift",images,item,
                    {"CFA":"RGGB","draw":0,"source_id":identity,"profiles":case["profile"],
                     "fixed_input_slice":n,"treatment":"100k with bounded near-ADC lift",
                     "models":plan["models"],"observation":reference(source),"target":row["target"]},
                    labels=labels,triplet_indices=(0,4,len(labels)-1),exposure=1,contrast=20))
        if i==0:
            for other in ("adc","iso100","iso6400","natural-shadow"):
                r=ROOT/"collection"/f"{row['id']}-{other}-0.json"
                old=wait_record(r,inputs["pid"],started)
                with np.load(checked(old["arrays"]),allow_pickle=False)as f:
                    other_values=dict(f)
                for model in plan["models"]:
                    assert forward(model,other_values,old["profile"])[1]
                bypass.append(reference(r))
        records.append(reference(source))
    assert len(records)==64 and len(boards)==2
    details={}
    for m in plan["models"]:
        reference_psnr,corrected_psnr=({src:mean(samples)for src,samples in performance[m,k].items()}
                                      for k in ("raw","bounded"))
        image_diff=[corrected_psnr[key]-reference_psnr[key]for key in sorted(reference_psnr)]
        fine=[{src:65535*np.sqrt(sum(x["error"]for x in rows)/(sum(x["blocks"]for x in rows)*256))
               for src,rows in spectra[m,k].items() if rows}for k in ("raw","bounded")]
        assert len(fine[0])==48 and fine[0].keys()==fine[1].keys()
        difference=[fine[1][src]-fine[0][src]for src in sorted(fine[0])]
        details[m]={"raw_psnr":mean(reference_psnr.values()),"bounded_psnr":mean(corrected_psnr.values()),
                    "photo_psnr_change_CI":bootstrap(image_diff),"photo_psnr_wins":sum(x>0 for x in image_diff),
                    "raw_fine_RMS_DN16":mean(fine[0].values()),"bounded_fine_RMS_DN16":mean(fine[1].values()),
                    "fine_change_CI_DN16":bootstrap(difference),"fine_error_wins":sum(y<0 for y in difference),
                    "raw_fine_by_source":fine[0],"bounded_fine_by_source":fine[1]}
    write_json(ROOT/"tiny-lift.json",{"source":reference(__file__),"plan":inputs["plan"],"records":records,
       "high_and_ADC_bypass_representative_batches":bypass,"native_boards":boards,"statistics":details,
       "scope":"Supplemental fixed existing physical correction at tiny positive noise. All64 sources/four CFAs; no tuning, additional neural inference or use of targets in the correction."})
    print({m:(v["bounded_psnr"],v["bounded_fine_RMS_DN16"],v["fine_error_wins"])for m,v in details.items()},flush=True)


if __name__=="__main__":
    main()
