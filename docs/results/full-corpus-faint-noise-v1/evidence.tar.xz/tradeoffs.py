"""Compare the five checkpoints using paired source means and exact original bands."""

import gzip
import json
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from measure import bootstrap

ROOT=Path(__file__).resolve().parent
COMPARISONS=(("86k","V120"),("100k","V120"),("100k","86k"),
             ("bridge-near","bridge-control"),("100k-bins","V120-bins"))


def paired(values,base,prefer_high=True):
    assert values.keys()==base.keys()
    differences=[values[k]-base[k] for k in sorted(values)]
    wins=sum(d>0 if prefer_high else d<0 for d in differences)
    return {"mean_difference":mean(differences),"interval_95pct":bootstrap(differences) if len(differences)>1 else None,
            "improved":wins,"sources":len(differences)}


def metrics(statistics):
    photo=statistics["photometry"]
    sp=statistics["spectra"]
    roots={}
    for key,values in sp.items():
        condition,model,source=key.split("|")
        part=values.get("fine|0")
        if part:
            roots.setdefault((condition,model),{})[source]=65535*np.sqrt(part["error"]/(part["blocks"]*256))
    totals={}
    for condition in ("adc","tiny","iso100","iso6400","natural-shadow"):
        for candidate,reference_model in COMPARISONS:
            lhs,rhs=f"{condition}|{candidate}",f"{condition}|{reference_model}"
            if lhs not in photo or rhs not in photo:
                continue
            first,second=({source:mean(row["srgb_psnr"] for row in samples) for source,samples in photo[k].items()}
                          for k in (lhs,rhs))
            totals.setdefault(condition,{})[f"{candidate} minus {reference_model}"]={
                "srgb_psnr_dB":paired(first,second),
                "fine_RMS_DN16":paired(roots[condition,candidate],roots[condition,reference_model],prefer_high=False)}
    return totals


if __name__=="__main__":
    summary=reference(ROOT/"summary.json")
    source=reference(ROOT/"source-statistics.json.gz")
    with gzip.open(checked(source),"rt") as f:
        values=json.load(f)
    data=metrics(values)
    assert len(read_json(checked(summary))["sources"])==64 and len(data)==5
    write_json(ROOT/"paired-model-comparison.json",{"summary":summary,"sufficient_stats":source,
        "source":reference(__file__),"comparisons":data,
        "bootstrap_scope":"Paired descriptive confidence intervals resample photographs, with CFA and noise draws kept together within each source."})
