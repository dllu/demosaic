"""Plot matched natural-image detail retention and repeated-error decomposition."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
summary_ref=reference(ROOT/"summary.json")
data=read_json(checked(summary_ref))
names={"V120":"V120","86k":"86k","100k":"100k","bridge-control":"Bridge control","bridge-near":"Near-ADC"}
colors=("#3A6A9B","#837CAA","#2A886B","#B98635","#A8516C")
conditions=("adc","tiny","iso100","iso6400")
bands=("low","fine","high")
fig,axes=plt.subplots(1,3,figsize=(12.1,4.4),layout="constrained")
for label,color in zip(names,colors,strict=True):
    value=[data["spectra"][condition][label]["fine"]["0"]["signed_response"] for condition in conditions]
    axes[0].plot(range(4),value,"o-",color=color,label=names[label],linewidth=1.6)
axes[0].set_xticks(range(4),("ADC","Tiny","ISO100","ISO6400"),rotation=15)
axes[0].set_ylabel("Signed detail response")
axes[0].set_title("Faint fine detail across noise")
axes[0].legend(frameon=False,fontsize=8)

x=np.arange(len(names))
p=[data["conditional"][model]["fine"]["0"]for model in names]
bias=[t["bias_squared"] for t in p]
var=[t["sampling_variance"]for t in p]
axes[1].bar(x,bias,color="#435F7B",label="Persistent error")
axes[1].bar(x,var,bottom=bias,color="#A1B8C7",label="Noise-to-noise variance")
axes[1].set_xticks(x,names.values(),rotation=19)
axes[1].set_ylabel("Fine-band mean-squared error (DN16²)")
axes[1].set_title("Four fixed ISO6400 draws per CFA")
axes[1].legend(frameon=False,fontsize=8)

for label,color in zip(names,colors,strict=True):
    values=[data["spectra"]["natural-shadow"][label][band]["0"]["signed_response"]for band in bands]
    axes[2].plot(range(3),values,"o-",color=color,label=names[label],linewidth=1.6)
axes[2].set_xticks(range(3),("Lower","Fine","Above fine"))
axes[2].set_ylabel("Signed detail response")
axes[2].set_title("Native contrast in ISO6400 shadows")
for ax in axes:
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y",color="#ddd",linewidth=.5)
    ax.set_axisbelow(True)
fig.suptitle("Weak texture in the 64-photo matched evaluation",fontsize=13,weight="bold")
output=ROOT/"faint-noise-bands.png"
fig.savefig(output,dpi=155)
write_json(ROOT/"plot.json",{"data":summary_ref,"source":reference(__file__),"image":reference(output),
    "scope":"Fixed lowest original-contrast fine stratum. Raw EMA inference policies shown. Natural-shadow targets retain their original contrast."})
