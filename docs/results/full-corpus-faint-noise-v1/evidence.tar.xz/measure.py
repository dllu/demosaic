"""Score the fixed faint-photo panel and separate high-noise response from variance."""

import argparse
from collections import defaultdict
import gzip
import json
import os
from pathlib import Path
from statistics import mean
import time

import numpy as np
import torch

from demosaic.adc_bins import adc_bin_projection
from demosaic.archive_metrics import linear_rgb,noisy_malvar,photometry
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from report_full_faint_photo_panel import BAND, COEFFICIENTS, LUMA, RADIUS, blocks, original_masks
from report_scene_wave_guides import native_board
from collect import ARGS, observation

ROOT=Path(__file__).resolve().parent
BANDS={"low":(RADIUS>=1/32)&(RADIUS<1/8),"fine":BAND,"high":RADIUS>=1/3}
ROI=(48,48,160,160)
LABELS={"V120":"V120 EMA","86k":"86k EMA","100k":"100k EMA",
        "bridge-control":"Bridge control EMA","bridge-near":"Near-ADC EMA"}


def coefficients(image,values):
    weights=np.einsum("c,bcj->bj",LUMA,values["matrix"].astype(float))*values["wb"]
    y=np.einsum("bc,bchw->bhw",weights,image.astype(float))
    samples=blocks(y)
    return COEFFICIENTS @ samples @ COEFFICIENTS.T


def score_components(accumulator,predicted,truth,masks):
    for band_key,band in BANDS.items():
        p,t=predicted[...,band],truth[...,band]
        error=np.sum((p-t)**2,axis=-1)
        cross=np.sum(p*t,axis=-1)
        energy=np.sum(t*t,axis=-1)
        for stratum,selected in masks.items():
            if not selected.any():
                continue
            sub=accumulator[band_key,stratum]
            sub["error"]+=float(error[selected].sum())
            sub["cross"]+=float(cross[selected].sum())
            sub["target"]+=float(energy[selected].sum())
            sub["blocks"]+=int(selected.sum())


def conditional_components(accumulator,predictions,truth,masks):
    count=len(predictions)
    assert count==4
    sample=np.asarray(predictions)
    center=sample.mean(0)
    for band_key,band in BANDS.items():
        target=truth[...,band]
        apparent=np.sum((center[...,band]-target)**2,axis=-1)
        variance=np.sum(np.var(sample[...,band],axis=0,ddof=1),axis=-1)
        mse=np.sum(np.mean((sample[...,band]-target)**2,axis=0),axis=-1)
        np.testing.assert_allclose(apparent+variance*(count-1)/count,mse,atol=1e-15,rtol=1e-11)
        unbiased_bias=apparent-variance/count
        for stratum,select in masks.items():
            if not select.any():
                continue
            item=accumulator[band_key,stratum]
            item["bias_squared"]+=float(unbiased_bias[select].sum())
            item["sampling_variance"]+=float(variance[select].sum())
            item["repeated_mse"]+=float(mse[select].sum())
            item["blocks"]+=int(select.sum())


def verify_regenerated_inputs(metadata,spec,condition,values,target):
    generated,truth,seeds=observation(spec,condition,metadata["draw"])
    assert fingerprint(truth)==metadata["target_fingerprint"] and seeds==metadata["seeds"]
    np.testing.assert_array_equal(truth,target)
    rendered=np.einsum("c,bchw->bhw",LUMA,linear_rgb(target,values))
    native=blocks(rendered)
    np.testing.assert_allclose(coefficients(target,values),COEFFICIENTS@native@COEFFICIENTS.T,atol=4e-14,rtol=0)
    for key in ARGS:
        np.testing.assert_array_equal(generated[key],values[key])


def wait_record(path,producer,started):
    while not path.is_file():
        status=Path(f"/proc/{producer}/stat")
        if not status.is_file() or status.read_text().split(") ",1)[1][0]=="Z":
            raise RuntimeError(f"Collection exited before {path.name}")
        if time.monotonic()-started>1800:
            raise TimeoutError(path)
        time.sleep(2)
    return read_json(path)


def compare_native(root,meta,spec,plan,values,target,corrected):
    cases=[]
    for i,source in enumerate(spec["source_ids"]):
        if source not in plan["native_sources"] or meta["draw"]!=0 or spec["pattern"]!="RGGB":
            continue
        names=("V120","86k","100k","bridge-control","bridge-near")
        settings={k:values[k][i:i+1] for k in ARGS}
        variant=[noisy_malvar(settings)[0],*(values[k][i]for k in names)]
        labels=["Noisy Malvar",*(LABELS[k]for k in names)]
        chosen=3
        if corrected:
            variant.extend([corrected["V120"][i],corrected["100k"][i]])
            labels.extend(["V120 ADC Malvar","100k ADC Malvar"])
            chosen=7
        variant.append(target[i]);labels.append("Exact GT")
        contrast=1 if meta["profile"]["target"]=="original_target" else (20 if corrected else 4)
        case=native_board(root,f"{source}-{meta['profile']['name']}",variant,settings,
               {"source_id":source,"all_checkpoints":plan["models"],"condition":meta["profile"],
                "treatment":"ADC-bin Malvar above 100k" if corrected else "100k EMA",
                "CFA":spec["pattern"],"draw":0,"output_record":meta["arrays"],
                "target":spec["target"],"seed":None if not meta["seeds"] else meta["seeds"][i]},
               labels=tuple(labels),triplet_indices=(0,chosen,len(labels)-1),
               exposure=meta["profile"]["exposure"],roi=ROI,contrast=contrast)
        cases.append(case)
    return cases


def grouped(values):
    return defaultdict(lambda: defaultdict(float),values)


def bootstrap(sample,seed=442028):
    arr=np.asarray(sample)
    rng=np.random.default_rng(seed)
    resamples=rng.integers(0,len(arr),size=(3000,len(arr)))
    return np.quantile(arr[resamples].mean(axis=1),[.025,.975]).tolist()


def aggregate(photometric,spectra,conditional):
    photo_summary={}
    for (condition,model),rows in sorted(photometric.items()):
        assert len(rows)==64
        balanced={k:float(mean(mean(q[k]for q in values)for values in rows.values()))
            for k in next(iter(rows.values()))[0]}
        photo_summary.setdefault(condition,{})[model]=balanced
    summaries={}
    per_source={}
    for (profile,model,source),row in spectra.items():
        for (band,stratum),sums in sorted(row.items()):
            blocks=sums["blocks"]
            key=(profile,model,band,stratum)
            per_source.setdefault(key,{})[source]={"rms_DN16":float(65535*np.sqrt(sums["error"]/(blocks*256))),
                "signed_response":sums["cross"]/sums["target"] if sums["target"]>1e-20 and stratum!="quiet" else None,
                "observed_blocks":int(blocks)}
    for (profile,model,band,stratum),sources in sorted(per_source.items()):
        gains=[j["signed_response"] for j in sources.values() if j["signed_response"] is not None]
        stats={"rms_DN16":float(mean(d["rms_DN16"]for d in sources.values())),
               "signed_response":float(mean(gains)) if gains else None,
               "source_count":len(sources),
               "observed_blocks":sum(s["observed_blocks"] for s in sources.values())}
        if model!="V120" and (profile,"V120",band,stratum) in per_source:
            first=per_source[profile,"V120",band,stratum]
            assert first.keys()==sources.keys()
            diff=[r["rms_DN16"]-first[k]["rms_DN16"]for k,r in sorted(sources.items())]
            stats["paired_RMS_difference_95pct_interval_DN16"]=bootstrap(diff) if len(diff)>1 else None
            stats["smaller_RMS_count_vs_V120"]=sum(z<0 for z in diff)
        summaries.setdefault(profile,{}).setdefault(model,{}).setdefault(band,{})[stratum]=stats
    repeat=defaultdict(lambda:defaultdict(list))
    for (model,source),row in conditional.items():
        for (band,stratum),val in row.items():
            assert val["blocks"]>0
            repeat[model][band,stratum].append({"source":source,"observed_blocks":int(val["blocks"]),
                  **{k:val[k]/(val["blocks"]*256)*65535**2 for k in
                                     ("bias_squared","sampling_variance","repeated_mse")}})
    repeats={}
    for model,items in repeat.items():
        for (band,stratum),values in items.items():
            avg={k:float(mean(row[k]for row in values)) for k in ("bias_squared","sampling_variance","repeated_mse")}
            assert abs(avg["bias_squared"]+avg["sampling_variance"]-avg["repeated_mse"])<1e-7
            repeats.setdefault(model,{}).setdefault(band,{})[stratum]=avg|{"source_count":len(values)}
    return photo_summary,summaries,repeats


def main(producer):
    os.sched_setaffinity(0,[14,15])
    os.nice(10)
    torch.set_num_threads(2)
    begin=time.monotonic()
    declared=reference(ROOT/"plan.json")
    plan=read_json(checked(declared))
    results=ROOT/"native"
    results.mkdir()
    photos=defaultdict(lambda:defaultdict(list))
    spectra=defaultdict(lambda:grouped({}))
    repeats=defaultdict(lambda:grouped({}))
    boards=[]
    qual=[]
    source_table={name:defaultdict(dict) for name in ("photometry","spectra","conditional")}
    inputs=ROOT/"collection"
    seen=set()
    for spec in plan["observations"]:
        with np.load(checked(spec["target"]),allow_pickle=False) as f:
            base={k:f[k]for k in ("target","original_target")}
        with np.load(checked(spec["arrays"]),allow_pickle=False) as f:
            calibration={k:f[k] for k in ("wb","matrix")}
        masks=original_masks(base["original_target"],calibration)
        for condition in plan["conditions"]:
            target=base[condition["target"]]*condition["gain"]
            target_coeff=coefficients(target,calibration)
            by_model=defaultdict(list)
            for draw in range(condition["draws"]):
                key=f"{spec['id']}-{condition['name']}-{draw}"
                receipt=inputs/f"{key}.json"
                meta=wait_record(receipt,producer,begin)
                assert meta["plan"]==declared and meta["case"]==spec["id"]
                assert meta["profile"]==condition and meta["draw"]==draw
                assert fingerprint(target)==meta["target_fingerprint"]
                for seed in meta["seeds"]:
                    assert seed not in seen
                    seen.add(seed)
                with np.load(checked(meta["arrays"]),allow_pickle=False) as f:
                    values=dict(f)
                assert {k:fingerprint(values[k])for k in ARGS}==meta["input_fingerprints"]
                if spec["id"]==plan["observations"][0]["id"] or (condition["name"]=="iso6400" and "RGGB" in spec["id"] and draw==3):
                    verify_regenerated_inputs(meta,spec,condition,values,target)
                    qual.append(reference(receipt))
                if condition["name"]=="adc":
                    corrected={}
                    for name in ("V120","86k","100k"):
                        packed,colors,wb=(torch.from_numpy(values[k]) for k in ("packed","colors","wb"))
                        corrected[name]=adc_bin_projection(torch.from_numpy(values[name]),packed,colors,wb,
                            bit_depth=16,black_level=.03,quantizer_precision="float64",shot=0.,read=0.).numpy()
                else:
                    corrected=None
                boards.extend(compare_native(results,meta,spec,plan,values,target,corrected))
                for name in plan["models"]:
                    predicted=values[name]
                    assert predicted.dtype==np.float32 and predicted.shape==target.shape and np.isfinite(predicted).all()
                measures={name:values[name] for name in plan["models"]}
                if corrected:
                    measures.update({name+"-bins":v for name,v in corrected.items()})
                for model,predicted in measures.items():
                    bigger=condition["exposure"]
                    photo=photometry(predicted*bigger,values|{"target":target*bigger})
                    pred=coefficients(predicted,values)
                    if condition["draws"]>1:
                        by_model[model].append(pred)
                    for i,source in enumerate(spec["source_ids"]):
                        adder=spectra[condition["name"],model,source]
                        photos[condition["name"],model][source].append({k:float(v[i]) for k,v in photo.items()})
                        individual={k:v[i]for k,v in masks.items()}
                        score_components(adder,pred[i],target_coeff[i],individual)
            if condition["draws"]>1:
                for model,draws in by_model.items():
                    for i,source in enumerate(spec["source_ids"]):
                        individual={k:v[i]for k,v in masks.items()}
                        conditional_components(repeats[model,source],[d[i]for d in draws],target_coeff[i],individual)
        if spec["pattern"]=="RGGB":
            print(spec["id"],"scored",round(time.monotonic()-begin,1),flush=True)
    assert len(boards)==10 and len(seen)==64*4*7
    for (condition,model),rows in photos.items():
        count=4*next(entry["draws"]for entry in plan["conditions"]if entry["name"]==condition)
        assert all(len(v)==count for v in rows.values())
    summary=aggregate(photos,spectra,repeats)
    collection=reference(ROOT/"collected.json")
    assert read_json(checked(collection))["count"]==512
    manifest={"plan":declared,"collection":collection,"score_source":reference(__file__),
         "native_boards":boards,"verified_input_regenerations":qual,
         "photometry":summary[0],"spectra":summary[1],"conditional":summary[2],
         "conditions":plan["conditions"],"sources":plan["source_ids"],
         "seconds":time.monotonic()-begin}
    write_json(ROOT/"summary.json",manifest)
    raw_path=ROOT/"source-statistics.json.gz"
    for (profile,model),rows in photos.items():
        source_table["photometry"][profile+"|"+model]=dict(rows)
    for (profile,model,source),row in spectra.items():
        source_table["spectra"][profile+"|"+model+"|"+source]={"|".join(key):v for key,v in row.items()}
    for (model,source),row in repeats.items():
        source_table["conditional"][model+"|"+source]={"|".join(key):v for key,v in row.items()}
    with gzip.open(raw_path,"xt") as stream:
        json.dump(source_table,stream,allow_nan=False)
    print("complete",round(time.monotonic()-begin,1),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("collector_pid",type=int)
    main(parser.parse_args().collector_pid)
