"""Fit constant and conditional mixtures using identical frozen inputs."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import sys
import time

import numpy as np
import torch

from mixture import ROOT, PRIOR, EDGE, ARMS, EXPERTS, DESCRIPTORS, Mixture, inputs, complex_parts
from demosaic.experiments.artifacts import checked, reference, read_json, write_json
from demosaic.phase_witness import XI, YI
from review_quiet import load
from head_corrected_broad import EXACT_FLAT, NATIVE_I, NATIVE_J, SYNTH, exterior
from train_gap_head import SEED, EPOCHS, PHOTOS, TILE, choose_tiles, batch, objective, focal_energy
import evaluate_gap_head as review


def calculate(case, pointer, component):
    proof=read_json(checked(pointer["measurement"]))
    assert case["index"]==proof["index"]==pointer["index"]
    parents=np.load(checked(pointer["parent"]),allow_pickle=False)
    with np.load(checked(proof["input"]),allow_pickle=False) as dataset:
        raw={k:dataset[k]for k in dataset.files}
    around=exterior(raw["scene_packed"],raw["colors"][0],case["noise"],case["box"])
    assert around is not None
    records=[inputs(mosaic,layout,case["noise"],case["box"],around,parent,wb,matrix,component,target)
        for mosaic,layout,parent,wb,matrix,target in zip(raw["packed"],raw["colors"],parents,raw["wb"],raw["matrix"],raw["target"],strict=True)]
    norm=np.maximum(np.mean([row[1] for row in records[:2]],axis=0),.002)
    void=np.lib.stride_tricks.sliding_window_view(raw["support"]==0,(TILE,TILE))[2*YI,2*XI]
    weight=(void*SYNTH**2).sum(axis=(-1,-2))/(SYNTH**2).sum()
    result={
        "descriptor":np.stack([row[-1]for row in records]),
        "experts":np.stack([row[-2]for row in records]),
        "correction":np.stack([complex_parts(row[2]/norm)for row in records]),
        "target":np.stack([complex_parts(row[0].desired/norm)for row in records]),
        "baseline":np.stack([complex_parts(row[0].basis[...,0]/norm)for row in records]),
        "void":void,"void_weight":weight,
    }
    return result


def features():
    torch.set_num_threads(1)
    old,head,checkpoint=load(raw_weights=False)
    binding=reference(PRIOR/"training-parent.json")
    capture=read_json(checked(binding))
    assert capture["checkpoint"]==checkpoint["parent"]
    plan=read_json(checked(capture["plan"]))
    overlap=review.panel_membership()
    assert isinstance(overlap,set)
    pats={case["source"]["id"] for case in plan["batches"]}
    assert len(pats)==len(plan["batches"])==448
    protected=read_json(checked(reference("configs/gfx-green-mesh-20231231.json")))
    assert not any("DSCF38" in str(case["source"]) for case in plan["batches"])
    directory=ROOT/"features"
    directory.mkdir()
    shapes={}
    records=zip(plan["batches"],capture["rows"],strict=True)
    started=time.monotonic()
    with ThreadPoolExecutor(3) as threads:
        def one(pair):
            return calculate(*pair,old["witness-gated"])
        for k,result in enumerate(threads.map(one, records)):
            for name,data in result.items():
                assert np.isfinite(data).all()
                if name not in shapes:
                    shapes[name]=np.lib.format.open_memmap(directory/(name+".npy"),mode="w+",
                        shape=(448,*data.shape),dtype=np.bool_ if name=="void" else np.float16)
                shapes[name][k]=data
            if (k+1)%28==0:
                print(k+1,round(time.monotonic()-started,2),flush=True)
    for values in shapes.values():
        values.flush()
    write_json(ROOT/"features.json",{
        "driver":reference(__file__),"mixture":reference(ROOT/"mixture.py"),"prior_training_parents":binding,
        "frozen_phase_training":head,"frozen_phase_checkpoint":checkpoint["checkpoint"],"parent":capture["checkpoint"],
        "sources":448,"source_styles":dict(Counter(row["style"]for row in plan["batches"])),
        "feature_storage":"FP16 arrays, exact bool gap masks, phase inputs from one frozen parent, shared first-two-role per-tile noise scale with .002 floor.",
        "tensors":{k:reference(directory/(k+".npy"))for k in shapes},
        "seconds":time.monotonic()-started,
    })


def train():
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    device="cuda"
    mem=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/mem))
    descriptor=reference(ROOT/"features.json")
    manifest=read_json(checked(descriptor))
    arrays={k:np.load(checked(v),mmap_mode="r",allow_pickle=False)for k,v in manifest["tensors"].items()}
    adaptive=Mixture(adaptive=True).to(device)
    nets={"constant":Mixture(adaptive=False).to(device),"conditional":adaptive,
          "gap-supervised":deepcopy(adaptive)}
    average={k:deepcopy(n).requires_grad_(False).eval()for k,n in nets.items()}
    params=[p for n in nets.values()for p in n.parameters()]
    optimizer=torch.optim.AdamW(params,lr=.001,weight_decay=.001)
    coords=tuple(torch.as_tensor(k,device=device) for k in (NATIVE_I,NATIVE_J))
    window=torch.as_tensor(SYNTH**2,device=device,dtype=torch.float32)
    rng=np.random.default_rng(SEED)
    count=manifest["sources"]
    step,schedule=0,count*EPOCHS//PHOTOS
    start=time.monotonic()
    history=[]
    for epoch in range(EPOCHS):
        sequence=rng.permutation(count)
        for offset in range(0,count,PHOTOS):
            subset=sequence[offset:offset+PHOTOS]
            chosen=choose_tiles(rng,arrays["void_weight"],subset)
            data=batch(arrays,subset,chosen,device)
            flat=torch.as_tensor(EXACT_FLAT[chosen],device=device)
            gap=data["void"]*window
            step+=1
            lr=.001*step/24 if step<=24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(schedule-24)))
            optimizer.param_groups[0]["lr"]=float(lr)
            optimizer.zero_grad(set_to_none=True)
            logged={}
            for mode,net in nets.items():
                out=net(data["descriptor"],data["correction"],data["experts"])
                loss,err,projected=objective(out,data["target"],data["baseline"],flat)
                if mode=="gap-supervised":
                    pair=focal_energy(err[:,0]-err[:,1],gap,coords)
                    absolute=focal_energy(err[:,0],gap,coords)
                    loss=loss+2*pair+absolute
                loss.backward()
                magnitude=torch.nn.utils.clip_grad_norm_(tuple(net.parameters()),2.0)
                if not torch.isfinite(magnitude):
                    raise FloatingPointError(step)
                logged[mode]=torch.stack((loss,projected)).detach()
            optimizer.step()
            with torch.no_grad():
                for mode in ARMS:
                    torch._foreach_lerp_(tuple(average[mode].parameters()),tuple(nets[mode].parameters()),.01)
            if step==1 or step%schedule==0 or step%48==0:
                stats={k:v.cpu().tolist()for k,v in logged.items()}
                history.append(dict(step=step,epoch=epoch+1,arms=stats))
                print(step,round(time.monotonic()-start,3),stats,flush=True)
    torch.cuda.synchronize()
    elapsed=time.monotonic()-start
    assert step==schedule
    directory=ROOT/"training"
    directory.mkdir()
    path=directory/f"step{step:06d}.pt"
    with path.open("xb")as checkpoint:
        torch.save({"raw":{k:n.state_dict()for k,n in nets.items()},"EMA":{k:n.state_dict()for k,n in average.items()},
                    "optimizer":optimizer.state_dict(),"updates":step,"seed":SEED},checkpoint)
    write_json(directory/"completed.json",{
        "driver":reference(__file__),"mixture":manifest["mixture"],"features":descriptor,
        "frozen_phase_checkpoint":manifest["frozen_phase_checkpoint"],"parent":manifest["parent"],
        "checkpoint":reference(path),"seconds":elapsed,"photos":count,"updates_per_head":step,
        "visits_per_head":count*EPOCHS,"queries_per_head":count*EPOCHS*3,"epochs":EPOCHS,
        "seed":SEED,"EMA":.99,"optimizer":"AdamW, .001 to .0001 cosine, 24-update warmup, weight decay .001, per-head gradient cap 2.",
        "experts":EXPERTS,"descriptors":DESCRIPTORS,"weight_dtype":"FP32 raw and EMA.",
        "arms":{"constant":"Fitted global expert weights with frozen expert corrections",
                "conditional":"Input-conditioned mixture with the original absolute, paired and flat objective",
                "gap-supervised":"Same conditional head, plus twice the paired spatial gap error and once the absolute gap error"},
        "constant_weights":average["constant"].logits.softmax(0).detach().cpu().tolist(),
        "progress":history,
    })


if __name__=="__main__":
    {"features":features,"train":train}[sys.argv[1]]()
