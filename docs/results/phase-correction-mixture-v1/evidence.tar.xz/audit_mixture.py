"""Verify convex gain bounds and inspect the selected expert contributions."""
import time

import numpy as np
import torch

from mixture import ROOT, PRIOR, ARMS, EXPERTS, DESCRIPTORS, inputs
from evaluate_mixture import load
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_quiet import raw_full
import evaluate_gap_head as review


@torch.inference_mode()
def sanity(nets):
    rng=torch.Generator().manual_seed(18342)
    descriptor=torch.randn((4096,len(DESCRIPTORS)),generator=rng).clamp(-6,6)
    experts=torch.rand((4096,len(EXPERTS)),generator=rng)*1.5
    experts[:,0]=0
    frozen=torch.randn((4096,2),generator=rng)
    checks={}
    for name,net in nets.items():
        w=net.weights(descriptor)
        assert torch.all(w>=0)
        np.testing.assert_allclose(w.sum(-1),1.,atol=2e-7,rtol=0)
        strength=(experts*w).sum(-1)
        assert torch.all(strength>=0) and torch.all(strength-unpack(experts)<=3e-7)
        result=net(descriptor,frozen,experts)
        assert torch.all(torch.abs(result-frozen*strength[:,None])<=8e-7)
        checks[name]={"count":len(experts),"row_sum_error_max":float(abs(w.sum(-1)-1.).max()),
                      "minimum_weight":float(w.min())}
    return checks


def unpack(values):
    return values.max(dim=-1).values


@torch.inference_mode()
def gate_map(capture, component, nets):
    previous=read_json(checked(capture))
    target={row["id"]:row for row in previous["rows"]}
    reference_scene=read_json(checked(previous["earlier_standing"]))
    rows=[]
    for key in ("main","mesh"):
        panel=[row for row in reference_scene["boards"]if row["id"].startswith(key+"-")]
        distance=target[panel[0]["id"]]["raw"]
        exterior, CFA=raw_full(distance)
        for row in panel:
            old=target[row["id"]]
            assert old["raw"]==distance
            x,y,_,_=row["case"]["ROI_xywh"]
            ox,oy=x-old["roi"][0],y-old["roi"][1]
            box=old["native_box"]
            with np.load(checked(old["input"]),allow_pickle=False)as source:
                raw=np.ascontiguousarray(source["packed"][0,:,oy//2:oy//2+128,ox//2:ox//2+128])
                layout,wb,matrix=(source[name][0]for name in ("colors","wb","matrix"))
            np.testing.assert_array_equal(layout,CFA)
            bx,by=box[:2]
            np.testing.assert_array_equal(raw,exterior[:,by//2:by//2+128,bx//2:bx//2+128])
            with np.load(checked(old["predictions"]),allow_pickle=False)as prediction:
                parent=prediction["parent"][0]
            donors=review.exterior(exterior,CFA,old["noise"],box)
            _,_,frozen,experts,descriptor=inputs(raw,CFA,old["noise"],box,donors,parent,wb,matrix,component)
            evidence=np.abs(frozen.astype(np.complex128))**2
            total=evidence.sum()
            weights={}
            for name,net in nets.items():
                mass=net.weights(torch.from_numpy(descriptor)).numpy()
                pooled=np.sum(evidence[...,None]*mass,axis=(0,1))/total
                gain=np.sum(evidence[...,None]*mass*experts,axis=(0,1))/total
                weights[name]={"base_correction_energy_weighted_expert_weights":pooled.tolist(),
                               "base_correction_energy_weighted_active_gains":gain.tolist()}
            rows.append({"id":row["id"],"input":old["input"],"checkpoint":old["checkpoint"],"weights":weights})
        del exterior
    assert len(rows)==8
    return rows


def main():
    torch.set_num_threads(1)
    (component,nets),training,endpoint=load(raw_weights=False)
    start=time.monotonic()
    native=reference(PRIOR/"standing/manifest.json")
    numbers=sanity(nets)
    routed=gate_map(native,component,nets)
    write_json(ROOT/"mixture-audit.json",{"driver":reference(__file__),"training":training,
        "checkpoint":endpoint["checkpoint"],"standing_input":native,"experts":EXPERTS,
        "bound_check":numbers,"rows":routed,"seconds":time.monotonic()-start,
        "scope":"Convexity on seeded descriptor and coefficient samples. Sensor-coordinate matches and expert assignment on the eight fixed standing queries, weighted by the pre-existing correction's spectral energy."})
    print(numbers,flush=True)
if __name__=="__main__":
    main()
