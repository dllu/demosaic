"""Evaluate learned and fixed phase mixtures on unchanged held-out Bayer observations."""
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from mixture import ROOT, PRIOR, EDGE, ARMS, EXPERTS, Mixture, inputs, combine
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_quiet import LOCAL, SCENE, CORE, photo_inputs, wire_inputs, numeric, load as old_models
from demosaic.archive_metrics import photometry
import evaluate_gap_head as review


def load(*, raw_weights=True):
    receipt=reference(ROOT/"training/completed.json")
    saved=read_json(checked(receipt))
    old,source,component=old_models(raw_weights=False)
    assert saved["parent"]==component["parent"] and saved["frozen_phase_checkpoint"]==component["checkpoint"]
    checkpoint=torch.load(checked(saved["checkpoint"]),weights_only=True,map_location="cpu")
    nets={}
    for kind in ("EMA","raw") if raw_weights else ("EMA",):
        for mode in ARMS:
            net=Mixture(adaptive=mode!="constant")
            net.load_state_dict(checkpoint[kind][mode],strict=True)
            nets[mode if kind=="EMA" else mode+"-raw"]=net.eval().requires_grad_(False)
    return (old["witness-gated"],nets),receipt,saved


def predict(native, surround, noise, box, parents, models, _include=True):
    old,nets=models
    donors=review.exterior(surround,native["colors"][0],noise,box)
    output={}
    for raw,cfa,matrix,wb,parent in zip(native["packed"],native["colors"],native["matrix"],
                                      native["wb"],parents[LOCAL],strict=True):
        field,_,frozen,spec,features=inputs(raw,cfa,noise,box,donors,parent,wb,matrix,old)
        predictions=combine(nets,field,frozen,spec,features)
        for mode,increment in predictions.items():
            image=parent+increment
            assert image.dtype==np.float32 and np.isfinite(image).all()
            output.setdefault(mode,[]).append(image)
    return {key:np.stack(v)for key,v in output.items()}


def scaled_models(composed, local, scales):
    return composed | {f"{expert}-scaled-to-{name}":local+np.float32(gain)*(composed[expert]-local)
                       for name,settings in scales.items()for expert,gain in settings.items()}


def photo_row(pointer, models, scales):
    test, data, parents, proof = photo_inputs(pointer)
    variants = predict(data, data["scene_packed"], test["profile"], test["box"], parents, models)
    outputs = parents | scaled_models(variants, parents[LOCAL], scales)
    exact = review.old.target_coeff(data["target"], data, review.old.ROI)
    increment = exact[0] - exact[1]
    anchor = review.old.target_coeff(parents[LOCAL], data, review.old.ROI)
    exposure = test["profile"]["exposure"]
    results = {}
    for name, restored in outputs.items():
        bands = review.old.target_coeff(restored, data, review.old.ROI)
        response = bands[0] - bands[1]
        dot, energy = review.aligned(increment.ravel(), response.ravel())
        results[name] = {
            "increment_rms": review.old.source_rms(response-increment, 96**2),
            "present_rms": review.old.source_rms(bands[0]-exact[0], 96**2),
            "flat_rms": review.old.source_rms(bands[2], 96**2),
            "flat_added": review.old.source_rms(bands[2]-anchor[2], 96**2),
            "attenuated_added": review.old.source_rms(bands[1]-anchor[1], 96**2),
            "intact_dot": dot, "intact_power": energy,
            "srgb_present_psnr": float(photometry(restored/exposure,
                data | {"target":data["target"]/exposure})["srgb_psnr"][0]),
        }
    return {"id":test["id"], "source_id":test["source"], "profile":test["profile"]["name"], "draw":test["draw"],
            "input":test["input"],"local20k_outputs":proof,"metrics":results | {"matched":results[LOCAL]}}


def wire_row(task, models, plan, scales, lookup, v120):
    data, parents, proof = wire_inputs(task, lookup, v120)
    scene = plan["sources"][task["index"]]
    noise = plan["profiles"][task["noise"]]
    names = predict(data, data["full"], noise, plan["query"], parents, models)
    results = parents | scaled_models(names, parents[LOCAL], scales)
    clean = review.old.luma(data["target"], data)[..., CORE[0], CORE[1]]
    local = review.old.luma(parents[LOCAL], data)[..., CORE[0], CORE[1]]
    support = data["support"][CORE]
    intact = support >= .97
    gap = support <= .01
    family = scene["geometry"]["family"]
    dip = (support>.01) & (support<=.65) if family in ("smooth-dip","contrast-step") else np.zeros_like(gap)
    target = clean[0]-clean[1]
    measures = {}
    for arm, rgb in results.items():
        restored = review.old.luma(rgb,data)[..., CORE[0], CORE[1]]
        pair = restored[0]-restored[1]
        delta = restored-local
        dot, power = review.aligned(target[intact],pair[intact])
        d_dot,d_power = review.aligned(target[dip],pair[dip])
        measures[arm] = {
            "intact_rms": review.rms((pair-target)[intact]),
            "intact_dot":dot,"intact_power":power,"dip_dot":d_dot,"dip_power":d_power,
            "present_rms":review.rms(restored[0]-clean[0]),
            "gap_added":review.rms(delta[0][gap]) if gap.any() else None,
            "gap_exact":review.rms((restored[0]-clean[0])[gap]) if gap.any() else None,
            "gap_pair":review.rms((pair-target)[gap]) if gap.any() else None,
            "dip_exact":review.rms((pair-target)[dip]) if dip.any() else None,
            "weak_free_added":review.rms(delta[2]),"flat_added":review.rms(delta[3,8:-8,8:-8]),
        }
    return {"id":f'{task["index"]:03d}-{task["noise"]}',"source_id":scene["source"]["id"],"profile":task["noise"],
            "family":family,"input":task["input"],"local20k_output":proof,
            "gap_pixels":int(gap.sum()),"metrics":measures | {"matched":measures[LOCAL]}}


def scale_to_targets(earlier, measure):
    groups=review.score_group(earlier)
    return {arm:{expert:groups[arm][measure]["mean"]/max(groups[expert][measure]["mean"],1e-12)
                 for expert in ("local_power","edge_contrast","Bayer-gated")}for arm in ARMS[1:]}


def main(mode):
    torch.set_num_threads(1)
    models,pointer,training=load()
    main_control=reference(PRIOR/"natural-results.json")
    natural=read_json(checked(main_control))
    previous=reference(EDGE/f"holdout-{mode}.json")
    stamp={"driver":reference(__file__),"training":pointer,"checkpoint":training["checkpoint"],
           "parent":training["parent"],"frozen_phase":training["frozen_phase_checkpoint"],
           "previous_matched_inputs":previous}
    start=time.monotonic()
    training_only=(models[0],{k:v for k,v in models[1].items()if k in ARMS})
    labels=[(name,ctrl)for name in ARMS for ctrl in (LOCAL,"100k","constant","local_power","edge_contrast",
            "edge_prediction","Bayer-gated") if name!=ctrl]
    labels.extend((name,expert+"-scaled-to-"+name)for name in ARMS[1:]
                  for expert in ("local_power","edge_contrast","Bayer-gated"))
    if mode=="photo":
        records=read_json(checked(natural["inputs"]))["records"]
        membership=review.panel_membership()
        links=[]
        for record in records:
            metadata=read_json(checked(read_json(checked(record))["case"]))
            if metadata["source"]in membership and metadata["profile"]["name"]=="iso6400" and metadata["draw"]=="independent":
                links.append(record)
        assert len(links)==16
        tune=review.run(links,partial(photo_row,models=training_only,scales={}))
        scales=scale_to_targets(tune,"flat_added")
        calibration=ROOT/"photo-calibration.json"
        write_json(calibration,stamp|{"rows":tune,"scales":scales})
        results=review.run(records,partial(photo_row,models=models,scales=scales))
        retained=[row for row in results if row["source_id"]not in membership]
        assert len(retained)==192 and len(results)==256
        cohorts={iso+"/"+draw:[row for row in retained if (row["profile"],row["draw"])==(iso,draw)]
                 for iso in ("iso400","iso6400")for draw in ("coupled","independent")}
        scores=("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")
    else:
        control=read_json(checked(reference(ROOT.parent/"learned-spectral-detail-v1/v120-wire.json")))
        def run(prefix,networks,scales,v120):
            binding=reference(PRIOR/f"{prefix}-parent.json")
            incoming=read_json(checked(binding))
            lookup={row["id"]:row for row in incoming["rows"]}
            sources=read_json(checked(incoming["inputs"]))["rows"]
            plan=read_json(checked(incoming["plan"]))
            return review.run(sources,partial(wire_row,models=networks,plan=plan,scales=scales,lookup=lookup,v120=v120))
        tune=run("wire-tune",training_only,{},None)
        gaps=[row for row in tune if row["gap_pixels"]]
        assert len(gaps)==12
        scales=scale_to_targets(gaps,"gap_added")
        calibration=ROOT/"wire-calibration.json"
        write_json(calibration,stamp|{"rows":tune,"scales":scales})
        v120={row["input"]["sha256"]:row for row in control["rows"]}
        results=run("wire",models,scales,v120)
        assert len(results)==48
        cohorts={iso:[row for row in results if row["profile"]==iso]for iso in ("iso400","iso6400")}
        scores=("intact_response","intact_rms","gap_exact","gap_added","gap_pair","flat_added","dip_response")
    prior=read_json(checked(previous))
    existing={row["id"]:row for row in prior["rows"]}
    for row in results:
        old=existing.get(row["id"])
        if old is None:
            continue
        assert old["input"]==row["input"] and old["source"]==row["source_id"]
        from_key="local20k_outputs" if mode=="photo" else "local20k_output"
        assert old["local"]==row[from_key]
        # Experts retain the earlier analytical signs, scales and camera arrays.
        specs=(("Bayer-gated","uniform",1.),("local_power","activity",1.),
               ("edge_contrast","edge-0.55",1.31),("edge_prediction","predictive-edge-0.00",1.5))
        for name,key,gain in specs:
            actual=row["metrics"][name]
            control=old["results"][key]
            names=(("increment_rms","increment"),("flat_rms","flat"))if mode=="photo" else (
                ("intact_rms","increment"),("gap_exact","gap"),("flat_added","flat_added"))
            for m,k in names:
                if control[k] is not None:
                    value=float(np.sqrt(max(0.,np.asarray(control[k])@[1,gain,gain**2,0,0,0])))
                    assert abs(value-actual[m])<.009,(row["id"],name,m,value,actual[m])
    write_json(ROOT/(mode+"-holdout.json"),stamp|{"calibration":reference(calibration),"scales":scales,
       "rows":results,"reports":numeric(cohorts,labels,scores),"seconds":time.monotonic()-start})


if __name__=="__main__":
    main(sys.argv[1])
