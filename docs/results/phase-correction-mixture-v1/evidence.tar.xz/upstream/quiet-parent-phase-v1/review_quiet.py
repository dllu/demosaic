"""Score transferred, refitted and evidence-gated phase heads on exact targets."""
from dataclasses import replace
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import measure_witnesses

from quiet_heads import ARMS, REFERENCE, ROOT, GatedTransport, TransportHead
from models import extend
from collect_parent import SCENE, WIRE_GROUPS
from derive_contrasts import contrast
import evaluate_gap_head as base
import review_subbin

NATURAL_RECORDS = SCENE / "review-020000/evaluation/collected.json"
CAPTIONS = {"transfer": "Frozen phase head", "fit": "Local phase refit",
            "quiet-fit": "Flat-weighted refit", "witness-gated": "Bayer-gated refit"}
BASELINE_CAPTIONS = {"V120": "V120 EMA", "100k": "Corpus 100k EMA", "100k-phase": "Corpus 100k + phase",
                     "local20k": "Local 20k EMA", "spatial20k": "Spatial 20k EMA"}
CORE = np.s_[64:192, 64:192]
OLD_CHECKPOINT = REFERENCE / "training/completed.json"
LOCAL = "local20k"


def load(*, raw_weights=True):
    head = reference(ROOT / "training/completed.json")
    definition = read_json(checked(head))
    prior, prior_receipt, _ = review_subbin.load()
    assert prior_receipt == definition["old_phase"]
    result = {"transfer": prior["transport"]}
    state = torch.load(checked(definition["checkpoint"]), weights_only=True, map_location="cpu")
    for marker in ("EMA", "raw") if raw_weights else ("EMA",):
        for mode in ARMS:
            model = GatedTransport() if mode == "witness-gated" else TransportHead()
            model.load_state_dict(state[marker][mode])
            result[mode if marker=="EMA" else mode+"-raw"] = model.eval().requires_grad_(False)
    return result, head, definition


def ready_field(raw, layout, noise, box, exterior, parent, wb, matrix, phase):
    field = base.features(raw, layout, noise, box, exterior, parent, wb, matrix)
    return replace(field, inputs=np.concatenate((field.inputs, phase.features), axis=-1),
                   basis=extend(field.basis, phase))


def predict(native, surround, noise, box, comparators, models, include_100k=True):
    donations = base.exterior(surround, native["colors"][0], noise, box)
    answers = {key: [] for key in models}
    if include_100k:
        answers["100k-phase"] = []
    for i, (raw, layout, wb, matrix) in enumerate(zip(
        native["packed"], native["colors"], native["wb"], native["matrix"], strict=True,
    )):
        phase = measure_witnesses(raw, layout, noise)
        local = comparators[LOCAL][i]
        field = ready_field(raw, layout, noise, box, donations, local, wb, matrix, phase)
        for name, model in models.items():
            expected = base.apply(model, field, local, "shape")
            assert expected.dtype == np.float32 and np.isfinite(expected).all()
            answers[name].append(expected)
        if include_100k:
            initial = comparators["100k"][i]
            previous = ready_field(raw, layout, noise, box, donations, initial, wb, matrix, phase)
            answers["100k-phase"].append(base.apply(models["transfer"], previous, initial, "shape"))
    return {k: np.stack(v) for k, v in answers.items()}


def photo_inputs(pointer):
    stored = read_json(checked(pointer))
    test, inputs, reference_models = base.old.natural_values(pointer)
    matched = reference(NATURAL_RECORDS.parent / "predictions" / Path(pointer["path"]).name)
    record = read_json(checked(matched))
    assert stored["case"]["sha256"] == record["case"]["sha256"]
    assert checked(stored["case"]).resolve() == checked(record["case"]).resolve()
    assert stored["exact_query_inputs"] == record["exact_query_inputs"]
    with np.load(checked(record["saved"]), allow_pickle=False) as output:
        for name in ("V120", "100k"):
            np.testing.assert_array_equal(reference_models[name], output[name])
        reference_models |= {LOCAL: output["none"], "spatial20k": output["spatial--matching"]}
    return test, inputs, reference_models, record["saved"]


def wire_inputs(task, lookup, v120):
    standard = None if v120 is None else v120[task["input"]["sha256"]]
    r, baselines = base.wire_inputs(task, standard)
    name = f'{task["index"]:03d}-{task["noise"]}'
    newer = lookup[name]
    assert newer["input"] == task["input"]
    return r, baselines | {LOCAL: np.load(checked(newer["parent"]), allow_pickle=False)}, newer["parent"]


def scaled_models(composed, local, scales):
    return composed | {f"fit-scaled-to-{target}": local + np.float32(factor)*(composed["fit"]-local)
                       for target, factor in scales.items()}


def photo_row(pointer, models, scales):
    test, data, parents, proof = photo_inputs(pointer)
    variants = predict(data, data["scene_packed"], test["profile"], test["box"], parents, models)
    outputs = parents | scaled_models(variants, parents[LOCAL], scales)
    exact = base.old.target_coeff(data["target"], data, base.old.ROI)
    increment = exact[0] - exact[1]
    anchor = base.old.target_coeff(parents[LOCAL], data, base.old.ROI)
    exposure = test["profile"]["exposure"]
    results = {}
    for name, restored in outputs.items():
        bands = base.old.target_coeff(restored, data, base.old.ROI)
        response = bands[0] - bands[1]
        dot, energy = base.aligned(increment.ravel(), response.ravel())
        results[name] = {
            "increment_rms": base.old.source_rms(response-increment, 96**2),
            "present_rms": base.old.source_rms(bands[0]-exact[0], 96**2),
            "flat_rms": base.old.source_rms(bands[2], 96**2),
            "flat_added": base.old.source_rms(bands[2]-anchor[2], 96**2),
            "attenuated_added": base.old.source_rms(bands[1]-anchor[1], 96**2),
            "intact_dot": dot, "intact_power": energy,
            "srgb_present_psnr": float(photometry(restored/exposure,
                data | {"target":data["target"]/exposure})["srgb_psnr"][0]),
        }
    return {"id":test["id"], "source_id":test["source"], "profile":test["profile"]["name"], "draw":test["draw"],
            "input":test["input"],"local20k_outputs":proof,"metrics":results | {"matched":results[LOCAL]}}


def wire_row(task, models, plan, scales, lookup, v120):
    data, parents, proof = wire_inputs(task, lookup, v120)
    scene = plan["sources"][task["index"]]
    noise = plan["profiles"][task["noise"]]
    names = predict(data, data["full"], noise, plan["query"], parents, models)
    results = parents | scaled_models(names, parents[LOCAL], scales)
    clean = base.old.luma(data["target"], data)[..., CORE[0], CORE[1]]
    local = base.old.luma(parents[LOCAL], data)[..., CORE[0], CORE[1]]
    support = data["support"][CORE]
    intact = support >= .97
    gap = support <= .01
    family = scene["geometry"]["family"]
    dip = (support>.01) & (support<=.65) if family in ("smooth-dip","contrast-step") else np.zeros_like(gap)
    target = clean[0]-clean[1]
    measures = {}
    for arm, rgb in results.items():
        restored = base.old.luma(rgb,data)[..., CORE[0], CORE[1]]
        pair = restored[0]-restored[1]
        delta = restored-local
        dot, power = base.aligned(target[intact],pair[intact])
        d_dot,d_power = base.aligned(target[dip],pair[dip])
        measures[arm] = {
            "intact_rms": base.rms((pair-target)[intact]),
            "intact_dot":dot,"intact_power":power,"dip_dot":d_dot,"dip_power":d_power,
            "present_rms":base.rms(restored[0]-clean[0]),
            "gap_added":base.rms(delta[0][gap]) if gap.any() else None,
            "gap_exact":base.rms((restored[0]-clean[0])[gap]) if gap.any() else None,
            "gap_pair":base.rms((pair-target)[gap]) if gap.any() else None,
            "dip_exact":base.rms((pair-target)[dip]) if dip.any() else None,
            "weak_free_added":base.rms(delta[2]),"flat_added":base.rms(delta[3,8:-8,8:-8]),
        }
    return {"id":f'{task["index"]:03d}-{task["noise"]}',"source_id":scene["source"]["id"],"profile":task["noise"],
            "family":family,"input":task["input"],"local20k_output":proof,
            "gap_pixels":int(gap.sum()),"metrics":measures | {"matched":measures[LOCAL]}}


def numeric(groups, labels, keys):
    rng = np.random.default_rng(78239)
    return {name: {"overview":base.score_group(rows), "contrasts": {
        arm+"-"+who: {stat:contrast(rows,arm,who,stat,rng) for stat in keys}
        for arm,who in labels if arm in rows[0]["metrics"] and who in rows[0]["metrics"]},
    } for name,rows in groups.items()}


def run_natural(models, stamp):
    overlapping = base.panel_membership()
    collection = reference(base.NATURAL / "evaluation/collected.json")
    photos = read_json(checked(collection))["records"]
    archive = reference(NATURAL_RECORDS)
    assert len(photos) == len(read_json(checked(archive))["records"]) == 256
    calibrate = []
    products = []
    for pointer in photos:
        data = read_json(checked(pointer))
        source = read_json(checked(data["case"]))
        if source["source"] in overlapping and source["profile"]["name"]=="iso6400" and source["draw"]=="independent":
            calibrate.append(pointer)
        if source["source"] not in overlapping:
            products.append(pointer)
    assert len(calibrate)==16 and len(products)==192
    ema = {k:v for k,v in models.items() if not k.endswith("-raw")}
    prior = base.run(calibrate, partial(photo_row, models=ema, scales={}))
    summaries = base.score_group(prior)
    scales = {arm:summaries[arm]["flat_added"]["mean"]/summaries["fit"]["flat_added"]["mean"]
              for arm in ("quiet-fit","witness-gated")}
    phase_tune = ROOT/"natural-calibration.json"
    write_json(phase_tune,stamp | {"rows":prior,"scales":scales})
    results = base.run(photos,partial(photo_row,models=models,scales=scales))
    sparse = [r for r in results if r["source_id"] not in overlapping]
    labels = [(name,ctrl) for name in ("transfer",*ARMS) for ctrl in (LOCAL,"100k","transfer") if name!=ctrl]
    labels += [(name,"fit-scaled-to-"+name)for name in ("quiet-fit","witness-gated")]
    keys = ("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")
    def stage(rows):
        return {iso+"/"+kind:[x for x in rows if (x["profile"],x["draw"])==(iso,kind)]
                for iso in ("iso400","iso6400") for kind in ("coupled","independent")}
    write_json(ROOT/"natural-results.json",stamp | {"inputs":collection,"local_outputs":archive,
       "calibration":reference(phase_tune),"scales":scales,"rows":results,
       "held_48":numeric(stage(sparse),labels,keys),"full_64":numeric(stage(results),labels,keys)})


def run_wires(models, stamp):
    old = read_json(checked(reference(REFERENCE.parent/"learned-spectral-detail-v1/v120-wire.json")))
    fresh = reference(ROOT/"wire-parent.json")
    old_map = {r["input"]["sha256"]:r for r in old["rows"]}
    assert old["source"] == read_json(checked(fresh))["inputs"]

    def one(name, selected, scales, baseline):
        panel = read_json(checked(reference(ROOT/f"{name}-parent.json")))
        inputs = read_json(checked(panel["inputs"]))["rows"]
        plan = read_json(checked(panel["plan"]))
        lookup = {r["id"]:r for r in panel["rows"]}
        return base.run(inputs, partial(wire_row, models=selected, plan=plan,
                                      scales=scales, lookup=lookup, v120=baseline))

    tune = one("wire-tune",{k:v for k,v in models.items() if not k.endswith("-raw")},{},None)
    gapped = [row for row in tune if row["gap_pixels"]]
    assert len(gapped)==12
    overview = base.score_group(gapped)
    scales = {arm:overview[arm]["gap_added"]["mean"]/overview["fit"]["gap_added"]["mean"]
              for arm in ("quiet-fit","witness-gated")}
    calibration = ROOT/"wire-calibration.json"
    write_json(calibration,stamp | {"rows":tune,"scales":scales})
    results = one("wire",models,scales,old_map)
    labels = [(name,ctrl) for name in ("transfer",*ARMS)for ctrl in (LOCAL,"100k","transfer")if name!=ctrl]
    labels += [(name,"fit-scaled-to-"+name)for name in ("quiet-fit","witness-gated")]
    keys = ("intact_response","intact_rms","gap_added","gap_exact","gap_pair","flat_added","dip_response")
    groups = {iso:[row for row in results if row["profile"]==iso]for iso in ("iso400","iso6400")}
    write_json(ROOT/"wire-results.json",stamp | {"local_outputs":fresh,"calibration":reference(calibration),
         "scales":scales,"rows":results,"holdout":numeric(groups,labels,keys)})


if __name__=="__main__":
    torch.set_num_threads(1)
    models, fit, end = load()
    stamp = {"driver":reference(__file__),"training":fit,"checkpoint":end["checkpoint"],
             "parent":end["parent"],"transfer":end["old_phase"],
             "witness":reference("src/demosaic/phase_witness.py")}
    {"natural":run_natural,"wire":run_wires}[sys.argv[1]](models,stamp)
