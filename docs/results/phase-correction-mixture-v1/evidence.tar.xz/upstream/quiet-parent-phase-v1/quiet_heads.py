"""Learn a transported complex correction with optional signed evidence for added energy."""
from pathlib import Path
import sys

import torch

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent / "subbin-spectral-witness-v1"
sys.path.insert(0, str(ROOT.parent / "learned-spectral-gaps-v1"))
sys.path.insert(0, str(REFERENCE))
from models import TransportHead

ARMS = ("fit", "quiet-fit", "witness-gated")


def evidenced_delta(delta, base, witness):
    """Permit attenuation along the existing phase and gate the remaining delta."""
    power = torch.linalg.vector_norm(base, dim=-1, keepdim=True)
    direction = base / power.clamp_min(1e-10)
    radial = (delta * direction).sum(-1, keepdim=True)
    attenuation = torch.maximum(radial.clamp(max=0), -power) * direction

    rgb = torch.sinh(witness[..., 2:4]).mean(-1, keepdim=True)
    greens = torch.sinh(witness[..., 4:6]).mean(-1, keepdim=True)
    verified = ((torch.minimum(rgb, greens) - .15) / .85).clamp(0, 1)
    neighbor = ((torch.expm1(witness[..., 6:7]) - .75) / 1.5).clamp(0, 1)
    return attenuation + verified * neighbor * (delta - attenuation)


class GatedTransport(TransportHead):
    def forward(self, features, context, basis):
        proposed = super().forward(features, context, basis)
        return evidenced_delta(proposed, basis[..., 0, :], features[..., -8:])
