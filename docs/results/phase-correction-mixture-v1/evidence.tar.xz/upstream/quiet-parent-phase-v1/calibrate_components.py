"""Test independent gains for parent-phase attenuation and measured expansion."""
from functools import partial
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import measure_witnesses
from review_quiet import ROOT, LOCAL, load, photo_inputs, ready_field
from quiet_heads import GatedTransport, TransportHead, evidenced_delta
from head_corrected_broad import synthesis
import evaluate_gap_head as review


def attenuation(delta, base):
    magnitude = torch.linalg.vector_norm(base, dim=-1, keepdim=True)
    unit = base / magnitude.clamp_min(1e-10)
    inward = torch.maximum((delta*unit).sum(-1,keepdim=True).clamp(max=0),-magnitude)
    return inward * unit


class CalibratedTransport(GatedTransport):
    def __init__(self, gains):
        super().__init__()
        self.gains=tuple(map(float,gains))

    def forward(self, features, context, basis):
        full = TransportHead.forward(self,features,context,basis)
        shrink = attenuation(full,basis[...,0,:])
        supported = evidenced_delta(full,basis[...,0,:],features[...,-8:]) - shrink
        return self.gains[0]*shrink + self.gains[1]*supported


@torch.inference_mode()
def pieces(model, field):
    features = torch.from_numpy(np.ascontiguousarray(field.inputs))
    context = torch.from_numpy(np.ascontiguousarray(field.contexts[...,1]))
    waves = torch.from_numpy(np.stack((field.basis.real,field.basis.imag),axis=-1))
    original = TransportHead.forward(model,features,context,waves)
    shrink = attenuation(original,waves[...,0,:])
    guarded = evidenced_delta(original,waves[...,0,:],features[...,-8:])
    parts = []
    for values in (shrink,guarded-shrink):
        values=values.numpy()
        surface=synthesis(values[...,0]+1j*values[...,1])
        delta=field.neutral[:,None,None]*surface[None]/field.neutral[1]
        parts.append(delta.astype(np.float32))
    return parts


def gram(arrays, divisor):
    matrix = np.stack([a.ravel() for a in arrays]).astype(np.float64)
    return (matrix @ matrix.T / divisor * 65535**2).tolist()


def photo(pointer, model):
    row, raw, parents, local = photo_inputs(pointer)
    around = review.exterior(raw["scene_packed"],raw["colors"][0],row["profile"],row["box"])
    frames=[]
    for mosaic,cfa,wb,matrix,parent in zip(
        raw["packed"],raw["colors"],raw["wb"],raw["matrix"],parents[LOCAL],strict=True):
        phase=measure_witnesses(mosaic,cfa,row["profile"])
        field=ready_field(mosaic,cfa,row["profile"],row["box"],around,parent,wb,matrix,phase)
        frames.append(pieces(model,field))
    components=[np.stack([frame[j]for frame in frames])for j in range(2)]
    original,predicted,old,shrink,verified=[review.old.target_coeff(a,raw,review.old.ROI)
        for a in (raw["target"],parents[LOCAL],parents["100k"],*components)]
    inc=lambda t:t[0]-t[1]
    truth=inc(original)
    built=[inc(a)for a in (predicted,shrink,verified)]
    dot=[float(np.sum(a*truth))for a in built]
    floor=float(np.sum(inc(old)*truth))
    power=float(np.sum(truth**2))
    return {"case":row["id"],"source":row["source"],"profile":row["profile"]["name"],"draw":row["draw"],
        "inputs":row["input"],"parent":local,"dot":dot,"power":power,"reference_dot":floor,
        "increment":gram([built[0]-truth,*built[1:]],96**2),
        "flat":gram([predicted[2]-original[2],shrink[2],verified[2]],96**2),
        "present":gram([predicted[0]-original[0],shrink[0],verified[0]],96**2),
        "ref_increment":review.old.source_rms(inc(old)-truth,96**2),
        "ref_flat":review.old.source_rms(old[2]-original[2],96**2)}


def evaluate(rows, gains):
    gains=np.asarray(gains)
    weights=np.column_stack((np.ones(len(gains)),gains))
    d=np.asarray([r["dot"]for r in rows])
    den=sum(r["power"]for r in rows)
    scores={"response":100*(weights@d.sum(0))/den}
    for metric in ("increment","flat","present"):
        mats=np.asarray([r[metric]for r in rows])
        raw=np.einsum("gi,fij,gj->gf",weights,mats,weights)
        scores[metric]=np.sqrt(raw.clip(min=0)).mean(1)
    return scores


def reference_level(rows):
    return {"response":100*sum(r["reference_dot"]for r in rows)/sum(r["power"]for r in rows),
            "increment":float(np.mean([r["ref_increment"]for r in rows])),
            "flat":float(np.mean([r["ref_flat"]for r in rows]))}


def main():
    torch.set_num_threads(1)
    models,binding,trial=load(raw_weights=False)
    fitting=reference(ROOT/"natural-results.json")
    control=read_json(checked(fitting))
    calibration=read_json(checked(control["calibration"]))
    eligible={r["source_id"]for r in calibration["rows"]}
    source=control["inputs"]
    requests=read_json(checked(source))["records"]
    start=time.monotonic()
    rows=review.run(requests,partial(photo,model=models["witness-gated"]))
    intended=[r for r in rows if r["profile"]=="iso6400" and r["draw"]=="independent"]
    train=[r for r in intended if r["source"]in eligible]
    test=[r for r in intended if r["source"]not in eligible]
    assert len(train)==16 and len(test)==48
    frozen=reference_level(train)
    grid=np.stack(np.meshgrid(np.linspace(0,1,33),np.linspace(0,1,33),indexing="ij"),axis=-1).reshape(-1,2)
    report=evaluate(train,grid)
    response_ok=report["response"]>=frozen["response"]
    flat_ok=report["flat"]<=frozen["flat"]
    fits=(response_ok & flat_ok)
    if np.any(fits):
        pick=int(np.argmin(np.where(fits,report["increment"],np.inf)))
        policy="Lowest increment error within reference response and flat RMS"
    elif np.any(response_ok):
        pick=int(np.argmin(np.where(response_ok,report["flat"],np.inf)))
        policy="Lowest flat RMS at the reference response"
    else:
        pick=int(np.argmax(report["response"]))
        policy="Highest response after the reference response proved infeasible"
    chosen=grid[pick]
    selected=np.stack(([0,0],[1,1],chosen))
    outputs={}
    for iso in ("iso400","iso6400"):
        for noise in ("coupled","independent"):
            cohort=[r for r in rows if r["source"]not in eligible and (r["profile"],r["draw"])==(iso,noise)]
            table=evaluate(cohort,selected)
            outputs[iso+"/"+noise]={"Corpus 100k":reference_level(cohort)}|{
                arm:{k:float(v[i])for k,v in table.items()}
                for i,arm in enumerate(("Local 20k","Bayer-gated","Calibrated"))}
    write_json(ROOT/"calibrated-components.json",{
        "driver":reference(__file__),"head":binding,"checkpoint":trial["checkpoint"],
        "original_results":fitting,"calibration_sources":sorted(eligible),
        "model_policy":policy,"settings":chosen.tolist(),"tested_scales":len(grid),
        "compliant_on_calibration":int(fits.sum()),"reference_on_calibration":frozen,
        "selected_on_calibration":{k:float(v[pick])for k,v in report.items()},
        "held_out":outputs,"seconds":time.monotonic()-start,"rows":rows})
    print(policy,chosen,outputs["iso6400/independent"],flush=True)


if __name__=="__main__":
    main()
