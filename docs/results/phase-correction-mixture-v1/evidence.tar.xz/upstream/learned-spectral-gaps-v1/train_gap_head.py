"""Train matched spectral heads with focal supervision inside known wire gaps."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "learned-spectral-detail-v1"
sys.path.insert(0, str(PREVIOUS))
from head_corrected_broad import EXACT_FLAT, FREQ_I, GainHead, NATIVE_I, NATIVE_J, SYNTH, XI, YI
from head_corrected_broad import exterior, features

SEED = 764211
EPOCHS = 6
PHOTOS = 4
REGIMES = ("matched", "localized", "zero-add")
INPUTS = ("features", "context", "basis", "target", "void", "void_weight")
TILE = len(SYNTH)
TILE_COUNT = len(YI)


def real_complex(x):
    return np.stack((x.real, x.imag), axis=-1)


def design(work):
    row, proof = work
    obs = read_json(checked(proof["measurement"]))
    assert row["index"] == proof["index"] == obs["index"]
    parents = np.load(checked(proof["parent"]), allow_pickle=False)
    with np.load(checked(obs["input"]), allow_pickle=False) as stream:
        r = {k: stream[k] for k in stream.files}
    pattern, wb, matrix = (r[k][0] for k in ("colors", "wb", "matrix"))
    donors = exterior(r["scene_packed"], pattern, row["noise"], row["box"])
    fields = [features(raw, pattern, row["noise"], row["box"], donors, pred, wb, matrix, target)
              for raw, pred, target in zip(r["packed"], parents, r["target"], strict=True)]
    assert donors is not None
    scale = np.maximum(np.mean([f.noise for f in fields[:2]], axis=0), 0.002)
    void = np.lib.stride_tricks.sliding_window_view(r["support"] == 0, (TILE, TILE))[2 * YI, 2 * XI]
    pixel_weight = (void * SYNTH**2).sum(axis=(-1, -2)) / (SYNTH**2).sum()
    if row["style"] in ("ellipse", "strip"):
        assert np.any(pixel_weight >= 0.25)
    else:
        assert not void.any()
    return {
        "features": np.stack([f.inputs for f in fields]),
        "context": np.stack([f.contexts[..., 1] for f in fields]),
        "basis": np.stack([real_complex(f.basis / scale[..., None]) for f in fields]),
        "target": np.stack([real_complex(f.desired / scale) for f in fields]),
        "void": void,
        "void_weight": pixel_weight,
    }


def collect():
    torch.set_num_threads(2)
    parents = reference(ROOT / "parents.json")
    bank = read_json(checked(parents))
    plan = read_json(checked(bank["plan"]))
    count = len(plan["batches"])
    cache = ROOT / "features"
    cache.mkdir()
    arrays = {}
    started = time.monotonic()
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i, ready in enumerate(pool.map(design, zip(plan["batches"], bank["rows"], strict=True))):
            for key, value in ready.items():
                dtype = np.bool_ if key == "void" else np.float16
                assert np.isfinite(value).all()
                if key not in arrays:
                    arrays[key] = np.lib.format.open_memmap(
                        cache / (key + ".npy"), mode="w+", dtype=dtype,
                        shape=(count, *value.shape),
                    )
                arrays[key][i] = value.astype(dtype)
                assert np.isfinite(arrays[key][i]).all()
            if (i + 1) % 40 == 0:
                print(i + 1, round(time.monotonic() - started, 2), flush=True)
    for array in arrays.values():
        array.flush()
    write_json(ROOT / "feature-cache.json", {
        "driver": reference(__file__), "head": reference(PREVIOUS / "head_corrected_broad.py"),
        "parents": parents, "inputs": {k: reference(cache / (k + ".npy")) for k in arrays},
        "counts": {"photos": count, "roles": 3, "tiles": TILE_COUNT, "spectral_modes": len(FREQ_I)},
        "precompute_seconds": time.monotonic() - started,
        "normalization": "Two-view per-tile shared noise scale with .002 floor, FP16 feature cache and FP32 training.",
    })


def objective(prediction, target, baseline, flat):
    errors = prediction - target
    difference = errors[:, 0] - errors[:, 1]
    truth = target[:, 0] - target[:, 1] + baseline[:, 0] - baseline[:, 1]
    direction = truth.flatten(1)
    projection = (direction * difference.flatten(1)).sum(1)
    power = direction.square().sum(1).clamp_min(1e-6)
    aligned = (projection.square() / power).mean() / direction.shape[1]
    flat_penalty = (prediction[:, 2].square() * flat[..., None, None]).sum() / (
        flat.sum().clamp_min(1) * prediction.shape[-2] * prediction.shape[-1]
    )
    loss = (errors[:, :2].square().mean() + 0.65 * difference.square().mean()
            + 0.50 * errors[:, 2].square().mean() + 0.70 * flat_penalty + 9.0 * aligned)
    return loss, errors, aligned


def focal_energy(values, weights, coordinates):
    coeff = torch.view_as_complex(values.contiguous())
    dense = coeff.new_zeros((*coeff.shape[:-1], TILE, TILE))
    ys, xs = coordinates
    dense[..., ys, xs] = coeff
    dense[..., -ys, -xs] = coeff.conj()
    spatial = 2 * torch.fft.ifft2(dense, norm="ortho").real
    return (spatial.square() * weights).sum() / weights.sum().clamp_min(1)


def choose_tiles(rng, source, indices):
    common = rng.choice(TILE_COUNT, 64, replace=False)
    flat = rng.choice(np.flatnonzero(EXACT_FLAT), 14, replace=False)
    selected = []
    for index in indices:
        mask = source[index]
        weights = np.square(mask.astype(np.float64))
        n = min(np.count_nonzero(weights), 12)
        chosen = rng.choice(TILE_COUNT, n, replace=False, p=weights / weights.sum()) if n else []
        background = rng.choice(TILE_COUNT, 12 - n, replace=False)
        selected.append(np.concatenate((common, flat, np.asarray(chosen, dtype=np.int64), background)))
    return np.asarray(selected)


def batch(data, indices, selected, device):
    result = {}
    for key, array in data.items():
        if key == "void_weight":
            continue
        if key == "void":
            values = [array[p, tiles] for p, tiles in zip(indices, selected, strict=True)]
        else:
            values = [array[p][:, tiles] for p, tiles in zip(indices, selected, strict=True)]
        result[key] = torch.from_numpy(np.asarray(values, dtype=np.float32)).to(device)
    return result


def train():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    device = "cuda"
    limit = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, 5 * 2**30 / limit))
    cache = reference(ROOT / "feature-cache.json")
    source = read_json(checked(cache))
    rows = source["counts"]["photos"]
    data = {k: np.load(checked(source["inputs"][k]), allow_pickle=False, mmap_mode="r") for k in INPUTS}
    initial = GainHead().to(device)
    models = {name: deepcopy(initial) for name in REGIMES}
    averages = {name: deepcopy(initial).eval().requires_grad_(False) for name in REGIMES}
    params = [p for model in models.values() for p in model.parameters()]
    optimizer = torch.optim.AdamW(params, lr=0.001, weight_decay=0.001)
    coords = tuple(torch.as_tensor(k, device=device) for k in (NATIVE_I, NATIVE_J))
    taper = torch.as_tensor(SYNTH**2, device=device, dtype=torch.float32)
    updates = rows // PHOTOS * EPOCHS
    rng = np.random.default_rng(SEED)
    output = ROOT / "training"
    output.mkdir()
    started = time.monotonic()
    progress = []
    step = 0
    for epoch in range(EPOCHS):
        order = rng.permutation(rows)
        for offset in range(0, len(order), PHOTOS):
            indices = order[offset:offset + PHOTOS]
            selected = choose_tiles(rng, data["void_weight"], indices)
            values = batch(data, indices, selected, device)
            flat = torch.as_tensor(EXACT_FLAT[selected], device=device)
            weights = values["void"] * taper
            step += 1
            rate = (0.001 * step / 24 if step <= 24 else
                    0.0001 + 0.0009 * (0.5 + 0.5 * np.cos(np.pi * (step - 24) / (updates - 24))))
            optimizer.param_groups[0]["lr"] = float(rate)
            optimizer.zero_grad(set_to_none=True)
            report = {}
            for name, net in models.items():
                pred = net(values["features"], values["context"], values["basis"])
                if step == 1:
                    assert not torch.any(pred)
                base, errors, projected = objective(pred, values["target"], values["basis"][..., 0, :], flat)
                include_grad = name != "matched"
                with torch.set_grad_enabled(include_grad):
                    paired = focal_energy(errors[:, 0] - errors[:, 1], weights, coords)
                    exact = focal_energy(errors[:, 0], weights, coords)
                    addition = focal_energy(pred[:, 0], weights, coords)
                loss = base
                if name == "localized":
                    loss = base + 3.0 * paired + 1.5 * exact
                elif name == "zero-add":
                    loss = base + 3.0 * paired + 1.5 * addition
                loss.backward()
                report[name] = torch.stack([loss, base, projected, paired, exact, addition]).detach()
            # Independent parameter sets and gradient caps keep the three matched
            # updates independent even though they share data and clock.
            for net in models.values():
                norm = torch.nn.utils.clip_grad_norm_(tuple(net.parameters()), 2.0)
                if not torch.isfinite(norm):
                    raise FloatingPointError(f"Nonfinite gradient at update {step}")
            optimizer.step()
            with torch.no_grad():
                for name, net in models.items():
                    torch._foreach_lerp_(tuple(averages[name].parameters()), tuple(net.parameters()), 0.01)
            if step % 40 == 0 or step in (1, updates):
                note = {"step": step, "epoch": epoch + 1, "lr": float(rate),
                        "values": {k: v.cpu().tolist() for k, v in report.items()}}
                progress.append(note)
                print(step, round(time.monotonic() - started, 2), note["values"], flush=True)
    torch.cuda.synchronize()
    elapsed = time.monotonic() - started
    assert step == updates
    end = output / f"step{step:06}.pt"
    with end.open("xb") as stream:
        torch.save({"raw": {k: m.state_dict() for k, m in models.items()},
                    "EMA": {k: m.state_dict() for k, m in averages.items()},
                    "cache": cache, "optimizer": optimizer.state_dict(), "seed": SEED,
                    "updates": updates}, stream)
    write_json(output / "completed.json", {
        "driver": reference(__file__), "checkpoint": reference(end), "cache": cache,
        "modes": REGIMES, "seconds": elapsed, "updates_per_head": step, "photos": rows,
        "photo_visits_per_head": rows * EPOCHS, "native_queries_per_head": rows * EPOCHS * 3,
        "parent": read_json(checked(source["parents"]))["parent"],
        "seed": SEED, "epochs": EPOCHS, "photos_per_update": PHOTOS,
        "optimizer": "AdamW .001 to .0001 cosine, 24-update warmup, .001 decay, per-head gradient cap 2, EMA .99.",
        "recipe": {"matched": "Original broad projection objective on the new photo and wire data",
                   "localized": "Matched + 3 paired gap error + 1.5 absolute gap error",
                   "zero-add": "Matched + 3 paired gap error + 1.5 gap correction energy"},
        "sampling": "64 uniform, 14 flat-centered, 12 gap-weighted or uniform fallback tiles per photo. Same schedule for all heads.",
        "scope": "The ground-truth gap map supplies a loss weight in training only. FP32 optimization, no trainable parent weights.",
        "metric_order": ("loss", "base", "projection", "focal_paired", "focal_absolute", "focal_added"),
        "progress": progress,
    })


if __name__ == "__main__":
    {"features": collect, "train": train}[sys.argv[1]]()
