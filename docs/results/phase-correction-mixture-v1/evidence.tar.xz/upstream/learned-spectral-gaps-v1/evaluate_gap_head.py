"""Score weak wire breaks, continuous controls, and natural photo details."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.archive_metrics import photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_gap_head import ROOT, PREVIOUS, REGIMES, GainHead, exterior, features

sys.path.insert(0, str(PREVIOUS))
from head_corrected_broad import apply
import review_corrected_broad as old

WIRE_TUNE = ROOT.parent / "query-gap-shoulders-v1"
WIRE_TEST = ROOT.parent / "query-exterior-colour-v1"
NATURAL = ROOT.parent / "scene-local-contrast-2400-v1"
CORE = np.s_[64:192, 64:192]
CAPTIONS = {
    "prior": "Earlier spectral head",
    "matched": "Matched training",
    "localized": "Exact gap supervision",
    "zero-add": "Gap correction penalty",
}


def load():
    training = reference(ROOT / "training/completed.json")
    end = read_json(checked(training))
    state = torch.load(checked(end["checkpoint"]), weights_only=True, map_location="cpu")
    archive = old.load()[0]
    models = {"prior": archive["shape"]}
    for checkpoint in ("EMA", "raw"):
        for name in REGIMES:
            model = GainHead()
            model.load_state_dict(state[checkpoint][name])
            models[name if checkpoint == "EMA" else name + "-raw"] = model.eval().requires_grad_(False)
    return models, training, end


def predictions(native, exterior_raw, parents, noise, box, models):
    cfa = native["colors"]
    donors = exterior(exterior_raw, cfa[0], noise, box)
    all_rows = {name: [] for name in models}
    for raw, pred, layout, wb, matrix in zip(native["packed"], parents, cfa,
                                             native["wb"], native["matrix"], strict=True):
        field = features(raw, layout, noise, box, donors, pred, wb, matrix)
        for name, model in models.items():
            value = apply(model, field, pred, "shape")
            assert value.dtype == np.float32 and np.all(np.isfinite(value))
            all_rows[name].append(value)
    return {name: np.stack(values) for name, values in all_rows.items()}


def with_scaling(models, parent, scales):
    for target, factor in scales.items():
        models["matched-at-" + target] = parent + np.float32(factor) * (models["matched"] - parent)
    return models


def wire_inputs(row, control):
    with np.load(checked(row["input"]), allow_pickle=False) as stream:
        r = {k: stream[k] for k in ("packed", "colors", "wb", "matrix", "target", "support")}
    r["full"] = r["packed"][0]
    r["packed"] = r["packed"][..., 64:192, 64:192]
    r["target"] = r["target"][..., 128:384, 128:384]
    with np.load(checked(row["output"]), allow_pickle=False) as file:
        models = {"100k": file["parent"], "shared-gap": file["shared"]}
    if control is not None:
        assert row["input"] == control["input"]
        models["V120"] = np.load(checked(control["output"]), allow_pickle=False)
    return r, models


def rms(x):
    return float(np.sqrt(np.mean(x**2)) * 65535)


def aligned(target, output):
    return float(np.dot(target, output)), float(np.dot(target, target))


def wire_row(item, models, plan, scales, v120, predictor=predictions):
    line = plan["sources"][item["index"]]
    r, baselines = wire_inputs(item, None if v120 is None else v120[item["input"]["sha256"]])
    noise = plan["profiles"][item["noise"]]
    current = predictor(r, r["full"], baselines["100k"], noise, plan["query"], models)
    composed = baselines | with_scaling(current, baselines["100k"], scales)
    truth = old.luma(r["target"], r)[..., CORE[0], CORE[1]]
    parent = old.luma(baselines["100k"], r)[..., CORE[0], CORE[1]]
    support = r["support"][CORE]
    intact, gap = (support >= 0.97), (support <= 0.01)
    family = line["geometry"]["family"]
    dip = (support > 0.01) & (support <= 0.65) if family in ("smooth-dip", "contrast-step") else np.zeros_like(gap)
    true = truth[0] - truth[1]
    measured = {}
    for name, value in composed.items():
        pred = old.luma(value, r)[..., CORE[0], CORE[1]]
        edit = pred - parent
        paired = pred[0] - pred[1]
        dot, power = aligned(true[intact], paired[intact])
        dip_dot, dip_power = aligned(true[dip], paired[dip])
        measured[name] = {
            "intact_rms": rms(paired[intact] - true[intact]),
            "present_rms": rms(pred[0] - truth[0]),
            "intact_dot": dot, "intact_power": power,
            "gap_added": rms(edit[0][gap]) if gap.any() else None,
            "gap_exact": rms((pred[0] - truth[0])[gap]) if gap.any() else None,
            "gap_pair": rms((paired - true)[gap]) if gap.any() else None,
            "dip_exact": rms((paired - true)[dip]) if dip.any() else None,
            "dip_dot": dip_dot, "dip_power": dip_power,
            "weak_free_added": rms(edit[2]),
            "flat_added": rms(edit[3, 8:-8, 8:-8]),
        }
    frequency = float(np.linalg.norm(line["geometry"]["frequency"][1]))
    return {"id": f'{item["index"]:03d}-{item["noise"]}', "profile": item["noise"],
            "source_id": line["source"]["id"], "family": family, "weak_frequency": frequency,
            "input": item["input"], "baseline": item["output"],
            "region_pixels": {"intact": int(intact.sum()), "gap": int(gap.sum()), "dip": int(dip.sum())},
            "metrics": measured}


def natural_row(record, models, predictor=predictions):
    test, r, baselines = old.natural_values(record)
    composed = baselines | predictor(r, r["scene_packed"], baselines["100k"],
                                       test["profile"], test["box"], models)
    exact = old.target_coeff(r["target"], r, old.ROI)
    assert np.max(abs(exact[2])) < 1e-13
    increment = exact[0] - exact[1]
    parent = old.target_coeff(baselines["100k"], r, old.ROI)
    exposure = test["profile"]["exposure"]
    rows = {}
    for name, result in composed.items():
        pred = old.target_coeff(result, r, old.ROI)
        restored = pred[0] - pred[1]
        dot, power = aligned(increment.ravel(), restored.ravel())
        rows[name] = {
            "increment_rms": old.source_rms(restored - increment, 96**2),
            "present_rms": old.source_rms(pred[0] - exact[0], 96**2),
            "flat_rms": old.source_rms(pred[2], 96**2),
            "flat_added": old.source_rms(pred[2] - parent[2], 96**2),
            "attenuated_added": old.source_rms(pred[1] - parent[1], 96**2),
            "intact_dot": dot, "intact_power": power,
            "srgb_present_psnr": float(photometry(result / exposure, r | {
                "target": r["target"] / exposure,
            })["srgb_psnr"][0]),
        }
    return {"id": test["id"], "source_id": test["source"], "profile": test["profile"]["name"],
            "draw": test["draw"], "input": test["input"], "baseline": record, "metrics": rows}


def score_group(rows):
    rng = np.random.default_rng(22717776)
    keys = rows[0]["metrics"]
    result = {}
    for name in keys:
        metrics = {}
        base = [r["metrics"]["matched"] for r in rows]
        values = [r["metrics"][name] for r in rows]
        for key in values[0]:
            if key.endswith(("_dot", "_power")):
                continue
            indices = [i for i, row in enumerate(values) if row[key] is not None]
            if not indices:
                continue
            mean = np.array([values[i][key] for i in indices])
            compared = np.array([base[i][key] for i in indices])
            sample = rng.integers(len(indices), size=(5000, len(indices)))
            delta = mean - compared
            metrics[key] = {"n": len(indices), "mean": float(mean.mean()),
                            "minus_matched": [float(delta.mean()),
                                              *np.quantile(delta[sample].mean(1), [0.025, 0.975]).tolist()]}
        for tag in ("intact", "dip"):
            if tag + "_dot" not in values[0]:
                continue
            power = np.array([v[tag + "_power"] for v in values])
            kept = power > 1e-18
            if not np.any(kept):
                continue
            numer = np.array([v[tag + "_dot"] for v in values])[kept]
            retained = power[kept]
            other = np.array([v[tag + "_dot"] for v in base])[kept]
            sample = rng.integers(len(retained), size=(5000, len(retained)))
            delta = numer - other
            summary = 100 * delta[sample].sum(axis=-1) / retained[sample].sum(axis=-1)
            metrics[tag + "_response"] = {"n": len(retained), "mean": float(100 * numer.sum() / retained.sum()),
                                         "minus_matched": [float(100 * delta.sum() / retained.sum()),
                                                           *np.quantile(summary, [0.025, 0.975]).tolist()]}
        result[name] = metrics
    return result


def run(rows, func):
    out = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(func, rows):
            out.append(result)
            if len(out) % 24 == 0:
                print(len(out), flush=True)
    return out


def wire_panel(directory, models, scales, primary, predictor=predictions):
    inputs = reference(directory / "fresh-gap.json")
    plan_path = reference(directory / "plan.json")
    plan = read_json(checked(plan_path))
    bank = read_json(checked(inputs))
    v120 = None
    if primary:
        comparator = read_json(checked(reference(PREVIOUS / "v120-wire.json")))
        assert comparator["source"] == inputs
        v120 = {x["input"]["sha256"]: x for x in comparator["rows"]}
    started = time.monotonic()
    rows = run(bank["rows"], partial(wire_row, models=models, plan=plan, scales=scales, v120=v120, predictor=predictor))
    groups = {}
    for profile in sorted({x["profile"] for x in rows}):
        chosen = [x for x in rows if x["profile"] == profile]
        groups[profile] = {}
        conditions = {"all": lambda x: True,
                      "gapped": lambda x: x["region_pixels"]["gap"] > 0,
                      "continuous": lambda x: x["family"] in ("smooth-dip", "contrast-step"),
                      "below-0.112": lambda x: x["weak_frequency"] < 0.112}
        for tag, select in conditions.items():
            subgroup = [r for r in chosen if select(r)]
            if subgroup:
                groups[profile][tag] = score_group(subgroup)
    return {"inputs": inputs, "plan": plan_path, "scales": scales, "seconds": time.monotonic() - started,
            "rows": rows, "summary": groups}


def panel_membership():
    plan = read_json(ROOT / "plan.json")
    train = {x["source"]["id"] for x in plan["batches"]}
    membership = {}
    for directory in (WIRE_TUNE, WIRE_TEST, NATURAL):
        path = directory / ("evaluation-plan.json" if directory == NATURAL else "plan.json")
        contents = read_json(path)
        ids = {x["source"]["id"] for x in contents.get("sources", contents.get("rows", []))}
        assert ids and ids.isdisjoint(train)
        membership[directory] = ids
    assert membership[WIRE_TEST].isdisjoint(membership[WIRE_TUNE] | membership[NATURAL])
    return membership[NATURAL] & membership[WIRE_TUNE]


def main(panel):
    torch.set_num_threads(1)
    overlap = panel_membership()
    models, training, end = load()
    note = {"driver": reference(__file__), "training": training, "checkpoint": end["checkpoint"],
            "prior_training": reference(PREVIOUS / "training-corrected-broad/completed.json")}
    if panel == "wire":
        ema = {k: v for k, v in models.items() if not k.endswith("-raw")}
        tune = wire_panel(WIRE_TUNE, ema, {}, False)
        controls = tune["summary"]["iso6400"]["gapped"]
        scales = {k: controls[k]["gap_added"]["mean"] / controls["matched"]["gap_added"]["mean"]
                  for k in ("localized", "zero-add")}
        write_json(ROOT / "wire-calibration-canonical.json", note | tune | {"selected_scales": scales})
        test = wire_panel(WIRE_TEST, models, scales, True)
        write_json(ROOT / "wire-scores.json", note | test | {
            "calibration": reference(ROOT / "wire-calibration-canonical.json")})
    else:
        inputs = reference(NATURAL / "evaluation/collected.json")
        started = time.monotonic()
        rows = run(read_json(checked(inputs))["records"], partial(natural_row, models=models))
        def summarize(group):
            return {profile: {draw: score_group(
                [r for r in group if (r["profile"], r["draw"]) == (profile, draw)])
                for draw in ("coupled", "independent")} for profile in ("iso400", "iso6400")}
        natural_only = [r for r in rows if r["source_id"] not in overlap]
        assert len(natural_only) == 4 * (len(rows) // 4 - len(overlap))
        write_json(ROOT / "natural-scores-canonical.json", note | {
            "inputs": inputs, "rows": rows, "summary": summarize(natural_only),
            "full_replay": summarize(rows), "natural_only": len(natural_only) // 4,
            "shared_with_wire_calibration": sorted(overlap), "seconds": time.monotonic() - started,
        })


if __name__ == "__main__":
    main(sys.argv[1])
