"""Test exterior phase candidates on reserved native green pixels."""
from pathlib import Path
import sys

import numpy as np
from scipy.fft import rfft2
from scipy.special import expit

ROOT = Path(__file__).resolve().parent
ACTIVITY = ROOT.parent / "phase-activity-v1"
sys.path.insert(0, str(ACTIVITY))

from demosaic.phase_witness import (
    BASE, BAYER_OFFSETS, COORDINATES, INDEX, MIRROR, PACKED, PAD, SHIFT, UNIQUE, XI, YI,
)

N = PACKED**2
ANGLES = np.arange(12, dtype=np.float32)*np.pi/12
POSITIONS = np.arange(-11., 12., 2., dtype=np.float32)
NORMALS = np.stack((np.sin(ANGLES),np.cos(ANGLES)), axis=1)
EDGES = len(ANGLES)*len(POSITIONS)
SUPPORT = 24.
HALF = N//2
random = np.random.default_rng(691381)
MASK = np.zeros(N, dtype=bool)
MASK[random.permutation(N)[:HALF]] = True
# The two folds keep both green Bayer offsets and never share a RAW sample.
FOLDS = (np.flatnonzero(MASK), np.flatnonzero(~MASK))
NATIVE = np.stack(np.indices((PACKED, PACKED)),axis=-1).reshape(N,2).astype(np.float32)*2
PHASES = np.arange(len(BASE))[None,:]


def fft_columns(samples, fold, plane):
    field = np.zeros((*samples.shape[:-1],N),dtype=np.float32)
    field[...,FOLDS[fold]] = samples
    s = rfft2(field.reshape(*field.shape[:-1],PACKED,PACKED),s=(PAD,PAD),workers=1)
    s = s.reshape(*field.shape[:-1],-1)[...,COORDINATES]
    s[...,MIRROR] = s[...,MIRROR].conj()
    return s*SHIFT[plane]


def kernel(fold, plane):
    coords = NATIVE + BAYER_OFFSETS[plane] - 15.5
    xy = coords[FOLDS[fold]]
    x = xy @ NORMALS.T
    ribbon = expit((x[:,:,None]-POSITIONS)/.75).reshape(HALF,EDGES).T
    aff = np.column_stack((np.ones(HALF),xy/16.))
    q = np.linalg.qr(aff)[0].T.astype(np.float32)
    ribbon -= (ribbon @ q.T) @ q
    e = ribbon / np.linalg.norm(ribbon,axis=1,keepdims=True).clip(min=1e-7)
    base = fft_columns(q,fold,plane)
    edge = fft_columns(e,fold,plane)
    doubled = np.exp(-4j*np.pi/PAD*(NATIVE[FOLDS[fold]]+BAYER_OFFSETS[plane]) @ (UNIQUE.T/2))
    squared = doubled.sum(axis=0).astype(np.complex64)
    return {"affine":q,"edge":e,"affine_fft":base,"edge_fft":edge,"twice_fft":squared}


CACHE = [[kernel(f,p) for p in range(4)] for f in range(2)]


def discovery(data, plane, fold, noise):
    proxy_variance = (noise["shot"] * data.mean(axis=1).clip(min=0) + noise["read"]).clip(min=2e-11)
    kernels=CACHE[fold][plane]
    affine = data @ kernels["affine"].T
    edges = data @ kernels["edge"].T
    discovery_power = edges**2 / proxy_variance[:,None]
    return (data, affine, edges, proxy_variance, discovery_power)


def projected(data, fold, plane, edge, selected, phase):
    values, affine, poles, _, _ = data
    kernels=CACHE[fold][plane]
    observed=(np.take_along_axis(fft_columns(values,fold,plane),selected,axis=1)*phase).real
    q=(kernels["affine_fft"][:,selected]*phase[None]).real
    amplitude=observed-np.einsum("wq,qwf->wf",affine,q)
    full_power=HALF*.5 + (.5*kernels["twice_fft"][selected]*phase**2).real
    power=full_power-np.sum(q**2,axis=0)
    edge_idx=edge.clip(min=0)
    addition=(kernels["edge_fft"][edge_idx[:,None],selected]*phase).real
    addition *= (edge>=0)[:,None]
    chosen=poles[np.arange(len(poles)),edge_idx,None]
    signaled=amplitude-chosen*addition
    explained=power-addition**2
    return np.stack((amplitude,signaled)),np.stack((power,explained)).clip(min=1e-5)


def scores(raw, layout, noise, phase, *, geometry=False):
    """Evaluate fixed exterior waveforms under affine and competing edge nulls.

    One fold nominates an edge and estimates an amplitude and per-plane noise.
    The other uses the fixed edge and waveform, projecting out the design on
    its own sampling coordinates. Near-zero projected norms are suppressed.
    """
    shape=np.lib.stride_tricks.sliding_window_view(raw,(PACKED,PACKED),axis=(-2,-1))
    windows=np.ascontiguousarray(shape[:,YI,XI].reshape(4,len(XI),N))
    green=tuple(np.flatnonzero(layout==1))
    measured=[[discovery(windows[p][:,FOLDS[j]],p,j,noise) for p in green] for j in range(2)]
    selected=INDEX[PHASES,phase.offsets]
    conjugate=phase.phase.conj()
    modes, found = [], []
    for discover in range(2):
        hold=1-discover
        strength=measured[discover][0][-1]+measured[discover][1][-1]
        edge=np.where(strength.max(1)>=SUPPORT,strength.argmax(1),-1)
        found.append(edge)
        redrawn, predictive = [], []
        for i, plane in enumerate(green):
            train=measured[discover][i]
            test=measured[hold][i]
            fitted, scale_a=projected(train,discover,plane,edge,selected,conjugate)
            residual, scale_b=projected(test,hold,plane,edge,selected,conjugate)
            sigma=np.sqrt(train[3][:,None])
            c=residual/(sigma*np.sqrt(scale_b))
            a=np.maximum(fitted,0.)/scale_a
            valid=(scale_a>=.10*HALF)&(scale_b>=.10*HALF)
            redrawn.append(np.where(valid,c,0.))
            predictive.append(np.where(valid & (a>0),c-.5*a*np.sqrt(scale_b)/sigma,0.))
        pooled=[np.stack(z).sum(axis=0)*np.float32(2**-.5) for z in (redrawn,predictive)]
        modes.append(np.concatenate(pooled))
    support=np.minimum(modes[0],modes[1]).astype(np.float32)
    return (support,np.stack(found)) if geometry else support
