"""Apply supported exterior evidence to frozen Bayer phase correction coefficients."""
import numpy as np
import torch

from phase_edge import ACTIVITY, ROOT, scores
from activity import fields, reliability, rgb_residual
from calibrate_components import attenuation
from quiet_heads import TransportHead, evidenced_delta
from review_quiet import ready_field
from demosaic.phase_witness import measure_witnesses

PHASE_NAMES = ("affine", "edge", "predictive-affine", "predictive-edge")
GATES = [("uniform",None,0.,False),("activity",None,0.,False)]
GATES += [(f"{name}-{threshold:.2f}",j,threshold,False)
          for j,name in enumerate(PHASE_NAMES) for threshold in (0.,.25,.55)]
GATES += [(f"replace-{PHASE_NAMES[j]}-{threshold:.2f}",j,threshold,True)
          for j in (2,3) for threshold in (0.,.25,.55)]
GATE_MAP = {r[0]:r for r in GATES}


@torch.inference_mode()
def correction_parts(model, field):
    x=torch.from_numpy(np.ascontiguousarray(field.inputs))
    d=torch.from_numpy(np.ascontiguousarray(field.contexts[...,1]))
    wave=torch.from_numpy(np.stack((field.basis.real,field.basis.imag),axis=-1))
    initial=TransportHead.forward(model,x,d,wave)
    shrink=attenuation(initial,wave[...,0,:])
    frozen=evidenced_delta(initial,wave[...,0,:],x[...,-8:])
    result=[]
    for value in (frozen,shrink,initial-shrink):
        v=value.numpy()
        result.append(v[...,0]+1j*v[...,1])
    return result


def choices(raw, pattern, noise, box, donors, parent, wb, matrix, model, policies=GATES):
    phase=measure_witnesses(raw,pattern,noise)
    values,edges=scores(raw,pattern,noise,phase,geometry=True)
    field=ready_field(raw,pattern,noise,box,donors,parent,wb,matrix,phase)
    frozen,shrink,remainder=correction_parts(model,field)
    generic=(fields(raw,pattern,noise)[0] if any(name=="activity" for name,*_ in policies) else None)
    neighbor=((phase.exterior_z-.75)/1.5).clip(0,1)
    predictions={}
    for name,mode,lo,replace in policies:
        if name=="uniform":
            full=frozen
        elif name=="activity":
            full=1.5*reliability(generic,0.,.30)[:,None]*frozen
        else:
            support=reliability(values[mode],lo,.75)
            full=shrink+support*neighbor*remainder if replace else support*frozen
        predictions[name]=rgb_residual(full,field)
    return predictions,(values,edges)
