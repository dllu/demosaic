"""Noise-debiased local activity from same-site energy and separate green cross-power."""
from pathlib import Path
import sys

import numpy as np
from scipy.fft import rfft2
import torch

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "quiet-parent-phase-v1"
sys.path.insert(0, str(PRIOR))

from demosaic.phase_witness import PACKED, SIDE, WEIGHT, XI, YI
from quiet_heads import TransportHead, evidenced_delta
from calibrate_components import attenuation
from head_corrected_broad import NATIVE_I, NATIVE_J, synthesis

P = np.arange(PACKED, dtype=np.float32) - (PACKED - 1) / 2
AXES = np.stack(np.broadcast_arrays(np.float32(1), P[:, None], P[None, :]))
DECISION = (AXES * WEIGHT).reshape(3, -1).T
SOLVE = np.linalg.solve(DECISION.T @ AXES.reshape(3, -1).T, DECISION.T)
FREQUENCY = np.fft.fftfreq(PACKED, d=2)
X = np.fft.rfftfreq(PACKED, d=2)[None, :]
Y = FREQUENCY[:, None]
RADIAL = np.hypot(X, Y)
# The radial bound avoids component axes near the packed-plane Nyquist limit.
BAND = (RADIAL >= .125) & (RADIAL <= .221) & ((X > 0) | (Y > 0))
YF, XF = np.broadcast_arrays(Y, X)
WAVE = 2j * np.pi * np.stack((YF[BAND], XF[BAND]), axis=-1)
PIXEL_OFFSETS = np.stack((np.arange(4) // 2, np.arange(4) % 2), axis=-1)
WEIGHT_VARIANCE = (WEIGHT**2).mean()
PRIOR_NAMES = ("auto", "cross", "surround", "joint")
FINE_PARENT = np.hypot(NATIVE_I, NATIVE_J) / (2 * PACKED) >= .125


def fields(raw, layout, noise):
    """Compare two noise-normalized local power estimates at identical bins.

    Weighted affine fitting suppresses tone ramps. The same per-window
    normalizer is used for both summary statistics. Native green offsets
    are accounted for before multiplying complex coefficients.
    """
    green = np.flatnonzero(layout == 1)
    window = np.lib.stride_tricks.sliding_window_view(raw[green], (PACKED, PACKED), axis=(-2, -1))
    pixels = window[:, YI, XI]
    coefficients = pixels.reshape(2, len(XI), -1) @ SOLVE.T
    residual = pixels - np.einsum("gwi,iyx->gwyx", coefficients, AXES)
    transformed = rfft2(residual * WEIGHT, workers=1)[..., BAND] / PACKED
    adjusted = transformed * np.exp(-PIXEL_OFFSETS[green] @ WAVE.T)[:, None, :]
    mean = coefficients[..., 0].clip(min=0)
    variance = (noise['shot'] * mean + noise['read']).clip(min=2e-11) * WEIGHT_VARIANCE
    z = adjusted / np.sqrt(variance)[..., None]
    auto = (np.abs(z)**2).mean(axis=(0, 2)) - 1.
    cross = (z[0] * z[1].conj()).real.mean(axis=1)
    square = cross.reshape(SIDE, SIDE)
    outside = np.zeros_like(square)
    counts = np.zeros_like(square)
    for axis in (0, 1):
        field = square.swapaxes(0, axis)
        total = outside.swapaxes(0, axis)
        count = counts.swapaxes(0, axis)
        # The offset uses one full window width, so the four donors
        # share no pixels with the center window.
        total[2:] += field[:-2]
        total[:-2] += field[2:]
        count[2:] += 1
        count[:-2] += 1
    surround = (outside / counts).ravel()
    joint = np.sqrt(np.maximum(cross, 0.) * np.maximum(surround, 0.))
    return np.stack((auto, cross, surround, joint)).astype(np.float32)


@torch.inference_mode()
def components(model, field):
    inputs = torch.from_numpy(np.ascontiguousarray(field.inputs))
    context = torch.from_numpy(np.ascontiguousarray(field.contexts[..., 1]))
    basis = torch.from_numpy(np.stack((field.basis.real, field.basis.imag), axis=-1))
    original = TransportHead.forward(model, inputs, context, basis)
    shrink = attenuation(original, basis[..., 0, :])
    accepted = evidenced_delta(original, basis[..., 0, :], inputs[..., -8:])
    outputs = []
    for tensor in (shrink, accepted-shrink):
        values = tensor.numpy()
        outputs.append(values[..., 0]+1j*values[..., 1])
    return np.stack(outputs)


def rgb_residual(coeff, field):
    return (field.neutral[:, None, None] / field.neutral[1] * synthesis(coeff)[None]).astype(np.float32)


def reliability(activity, lo, width):
    weight = ((activity-lo)/width).clip(0, 1)
    return weight**2 * (3 - 2*weight)
