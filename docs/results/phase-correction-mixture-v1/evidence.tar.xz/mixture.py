"""Learn a bounded mixture of local power and reserved Bayer phase gates."""
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
EDGE = ROOT.parent / "phase-edge-validation-v1"
sys.path.insert(0,str(EDGE))

from phase_edge import scores
from edge_choices import correction_parts
from activity import fields, reliability, rgb_residual, PRIOR
from demosaic.phase_witness import measure_witnesses
from models import extend
from head_corrected_broad import features

ARMS = ("constant", "conditional", "gap-supervised")
DESCRIPTORS = (
    "local_self_power", "local_green_cross_power", "nearby_green_cross_power",
    "selected_edge_share", "affine_contrast", "edge_contrast",
    "edge_predictive_gain", "exterior_strength", "directional_change_snr",
    "local_signed_green", "local_signed_red_blue",
)
EXPERTS = ("zero", "local_power", "edge_contrast", "edge_prediction")


class Mixture(nn.Module):
    def __init__(self, *, adaptive):
        super().__init__()
        self.logits=nn.Parameter(torch.zeros(len(EXPERTS)))
        self.router = None
        if adaptive:
            self.router = nn.Sequential(nn.Linear(len(DESCRIPTORS), 24),nn.SiLU(),
                                        nn.Linear(24,24),nn.SiLU(),nn.Linear(24,len(EXPERTS)))
            nn.init.zeros_(self.router[-1].weight)
            nn.init.zeros_(self.router[-1].bias)

    def weights(self, descriptor):
        logits=self.logits + (self.router(descriptor) if self.router is not None else 0.)
        return logits.softmax(dim=-1)

    def forward(self, descriptor, correction, experts):
        return correction * (experts*self.weights(descriptor)).sum(-1, keepdim=True)


def inputs(raw, layout, noise, box, donors, parent, wb, matrix, model, target=None):
    phase = measure_witnesses(raw, layout, noise)
    v, edge = scores(raw,layout,noise,phase,geometry=True)
    power=fields(raw,layout,noise)
    field=features(raw,layout,noise,box,donors,parent,wb,matrix,target)
    field=replace(field, inputs=np.concatenate((field.inputs,phase.features),axis=-1),
                  basis=extend(field.basis,phase))
    frozen=correction_parts(model,field)[0]
    experts=np.stack((
        np.zeros_like(v[0]),
        np.broadcast_to(1.5*reliability(power[0],0.,.30)[:,None],v[0].shape),
        1.31*reliability(v[1],.55,.75),
        1.5*reliability(v[3],0.,.75),
    ),axis=-1)
    series=(*[np.arcsinh(s)[:,None] for s in power[:3]],np.mean(edge>=0,axis=0)[:,None],
            np.arcsinh(v[0]),np.arcsinh(v[1]),np.arcsinh(v[3]),np.log1p(phase.exterior_z),
            np.log1p(abs(frozen)/phase.noise.clip(min=.002)),
            phase.features[...,4:6].mean(-1),phase.features[...,2:4].mean(-1))
    descriptor=np.stack(np.broadcast_arrays(*series),axis=-1).clip(-6,6).astype(np.float32)
    return field,phase.noise,frozen,experts,descriptor


def complex_parts(array):
    return np.stack((array.real,array.imag),axis=-1).astype(np.float32)


@torch.inference_mode()
def combine(nets, field, frozen, experts, descriptor):
    desc=torch.from_numpy(descriptor)
    b=torch.from_numpy(complex_parts(frozen))
    masks=torch.from_numpy(experts)
    result={}
    for name,net in nets.items():
        wave=net(desc,b,masks).numpy()
        result[name]=rgb_residual(wave[...,0]+1j*wave[...,1],field)
    for n,name in enumerate(EXPERTS[1:],start=1):
        result[name]=rgb_residual(frozen*experts[...,n],field)
    result["Bayer-gated"]=rgb_residual(frozen,field)
    return result
