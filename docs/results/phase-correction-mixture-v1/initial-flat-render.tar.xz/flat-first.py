"""Render exact-flat controls on native held-out queries."""
from pathlib import Path

import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from review_quiet import BASELINE_CAPTIONS, photo_inputs
from evaluate_mixture import ROOT, load, predict
from render_mixture import CAPTIONS
import evaluate_gap_head as review

if __name__=="__main__":
    torch.set_num_threads(1)
    models,weights,endpoint=load(raw_weights=False)
    source=reference(review.NATURAL/"evaluation/collected.json")
    lookup={Path(a["path"]).stem:a for a in read_json(checked(source))["records"]}
    output=ROOT/"flat"
    output.mkdir()
    rows=[]
    for key in ("000-iso6400-independent","001-iso6400-independent"):
        item,r,parents,parent_receipt=photo_inputs(lookup[key])
        part={k:r[k][2:3]for k in ("packed","wb","matrix","colors")}
        controls={k:v[2:3]for k,v in parents.items()}
        candidates=predict(part,r["scene_packed"],item["profile"],item["box"],controls,models)
        choices=controls|candidates
        names=list(BASELINE_CAPTIONS)+list(CAPTIONS)
        panels=[noisy_malvar(part)[0],*[choices[n][0]for n in names],r["target"][2]]
        labels=("Noisy Malvar",*[(CAPTIONS|BASELINE_CAPTIONS)[n]for n in names],"Exact GT")
        settings=read_json(checked(item["plan"]))["rows"][item["case"]]
        meta={"source":settings["source"],"CFA":settings["camera"]["pattern"],"input":item["input"],
              "local_parent":parent_receipt,"query":item["box"],"noise":item["profile"],"role":"exact-flat"}
        rows.append(native_board(output,key+"-flat",panels,part,meta,labels=labels,
                     exposure=1/item["profile"]["exposure"],contrast=2.,
                     triplet_indices=(0,labels.index(CAPTIONS["conditional"]),len(labels)-1)))
    write_json(output/"manifest.json",{"driver":reference(__file__),"source":source,"weights":weights,
        "checkpoint":endpoint["checkpoint"],"parent":endpoint["parent"],"frozen_phase":endpoint["frozen_phase_checkpoint"],"rows":rows})
