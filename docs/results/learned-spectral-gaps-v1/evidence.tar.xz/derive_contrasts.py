"""Calculate paired intervals for the held-out head comparisons."""
from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
KEYS = ("intact_response", "intact_rms", "gap_added", "gap_exact", "gap_pair", "dip_response")
COMPARISONS = (
    ("localized", "100k"), ("localized", "matched"), ("localized", "matched-at-localized"),
    ("zero-add", "matched"), ("witness-matched", "matched"),
    ("witness-matched", "matched-at-witness-matched"), ("witness-localized", "localized"),
)


def contrast(rows, candidate, baseline, metric, rng):
    kind = metric.removesuffix("_response")
    if kind != metric:
        pairs = [r["metrics"] for r in rows if r["metrics"][candidate][kind + "_power"] > 0]
        change = np.array([r[candidate][kind + "_dot"] - r[baseline][kind + "_dot"] for r in pairs])
        weights = np.array([r[candidate][kind + "_power"] for r in pairs])
        scale = 100
    else:
        pairs = [r["metrics"] for r in rows if r["metrics"][candidate][metric] is not None]
        change = np.array([r[candidate][metric] - r[baseline][metric] for r in pairs])
        weights = np.ones_like(change)
        scale = 1
    sample = rng.integers(len(change), size=(5000, len(change)))
    values = scale * change[sample].sum(1) / weights[sample].sum(1)
    return {"sources": len(change), "mean": float(scale * change.sum() / weights.sum()),
            "interval_95": np.quantile(values, [.025, .975]).tolist()}


def main():
    original = reference(ROOT / "wire-scores.json")
    witness = reference(ROOT / "witness-wire-scores.json")
    data = read_json(checked(original))
    followup = read_json(checked(witness))
    for x, y in zip(data["rows"], followup["rows"], strict=True):
        assert x["input"] == y["input"] and x["id"] == y["id"]
        assert x["metrics"]["matched"] == y["metrics"]["matched"]
        assert x["metrics"]["localized"] == y["metrics"]["localized"]
    rng = np.random.default_rng(931)
    contrasts = {}
    for noise in ("iso400", "iso6400"):
        rows = [x | {"metrics": x["metrics"] | y["metrics"]}
                for x, y in zip(data["rows"], followup["rows"], strict=True) if x["profile"] == noise]
        contrasts[noise] = {candidate + "_vs_" + baseline: {
            key: contrast(rows, candidate, baseline, key, rng) for key in KEYS}
            for candidate, baseline in COMPARISONS}
    write_json(ROOT / "contrasts.json", {"driver": reference(__file__), "original": original,
                                       "witness": witness, "resampling": "5,000 source-paired resamples",
                                       "contrasts": contrasts})


if __name__ == "__main__":
    main()
