"""Review the native images from the matched Bayer witness endpoints."""
import sys

from native_gap_head import standing, exact
from review_witness import CAPTIONS, LABELS, load, predict

LABELS_AND_CONTROLS = {k: CAPTIONS[k] for k in ("prior", "matched", "localized")} | LABELS

if __name__ == "__main__":
    if sys.argv[1] == "standing":
        standing(provider=load, predictor=predict, captions=LABELS_AND_CONTROLS,
                 methods=("matched", "localized", *LABELS), output_dir="witness-standing")
    else:
        exact(provider=load, predictor=predict, captions=LABELS_AND_CONTROLS, main_arm="witness-localized",
              extra_arms=("witness-matched",), output_dir="witness-exact")
