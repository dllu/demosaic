"""Evaluate whether the Bayer witnesses improve results at the same loss."""
from dataclasses import replace
from functools import partial
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import evaluate_gap_head as base
from evaluate_gap_head import ROOT, CAPTIONS, NATURAL, WIRE_TEST, WIRE_TUNE
from train_witness import TREATMENTS
from witness_features import WitnessHead, measured

LABELS = {"witness-matched": "Bayer witnesses",
          "witness-localized": "Bayer witnesses + gap loss"}


def load():
    controls, receipt, original = base.load()
    training = reference(ROOT / "training-witness/completed.json")
    end = read_json(checked(training))
    assert end["matched_control"] == receipt and end["parent"] == original["parent"]
    checkpoint = torch.load(checked(end["checkpoint"]), weights_only=True, map_location="cpu")
    models = {k: v for k, v in controls.items() if k in ("prior", "matched", "localized")}
    for policy in ("EMA", "raw"):
        for name in TREATMENTS:
            model = WitnessHead()
            model.load_state_dict(checkpoint[policy][name])
            models[name if policy == "EMA" else name + "-raw"] = model.eval().requires_grad_(False)
    return models, training, end


def predict(native, exterior_raw, parents, noise, box, models):
    new_names = {name for name, model in models.items() if isinstance(model, WitnessHead)}
    cfa = native["colors"]
    donors = base.exterior(exterior_raw, cfa[0], noise, box)
    decisions = {name: [] for name in models}
    for raw, pred, layout, wb, matrix in zip(native["packed"], parents, cfa,
                                             native["wb"], native["matrix"], strict=True):
        field = base.features(raw, layout, noise, box, donors, pred, wb, matrix)
        extra = replace(field, inputs=np.concatenate((field.inputs, measured(raw, layout, noise)), axis=-1))
        for name, model in models.items():
            used = extra if name in new_names else field
            output = base.apply(model, used, pred, "shape")
            assert output.dtype == np.float32 and np.isfinite(output).all()
            decisions[name].append(output)
    return {name: np.stack(values) for name, values in decisions.items()}


def main(panel):
    torch.set_num_threads(1)
    overlap = base.panel_membership()
    models, receipt, end = load()
    note = {"driver": reference(__file__), "training": receipt, "checkpoint": end["checkpoint"],
            "matched_base_training": end["matched_control"],
            "preceding_checkpoint": reference(base.PREVIOUS / "training-corrected-broad/completed.json")}
    if panel == "wire":
        options = {k: v for k, v in models.items() if not k.endswith("-raw")}
        calibration = base.wire_panel(WIRE_TUNE, options, {}, False, predictor=predict)
        gapped = calibration["summary"]["iso6400"]["gapped"]
        scales = {name: gapped[name]["gap_added"]["mean"] / gapped["matched"]["gap_added"]["mean"]
                  for name in TREATMENTS}
        cal = ROOT / "witness-wire-calibration.json"
        write_json(cal, note | calibration | {"selected_scales": scales})
        scores = base.wire_panel(WIRE_TEST, models, scales, True, predictor=predict)
        write_json(ROOT / "witness-wire-scores.json", note | scores | {"calibration": reference(cal)})
    else:
        inputs = reference(NATURAL / "evaluation/collected.json")
        started = time.monotonic()
        rows = base.run(read_json(checked(inputs))["records"],
                        partial(base.natural_row, models=models, predictor=predict))

        def summarize(group):
            return {profile: {draw: base.score_group(
                [r for r in group if (r["profile"], r["draw"]) == (profile, draw)])
                for draw in ("coupled", "independent")} for profile in ("iso400", "iso6400")}

        natural_only = [r for r in rows if r["source_id"] not in overlap]
        assert len(natural_only) == 4 * (len(rows) // 4 - len(overlap))
        write_json(ROOT / "witness-natural-scores.json", note | {
            "inputs": inputs, "rows": rows, "summary": summarize(natural_only),
            "full_replay": summarize(rows), "natural_only": len(natural_only) // 4,
            "shared_with_wire_calibration": sorted(overlap), "seconds": time.monotonic() - started,
        })


if __name__ == "__main__":
    main(sys.argv[1])
