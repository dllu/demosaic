"""Render exact targets and both standing GFX comparisons in native coordinates."""
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, linear_rgb, noisy_malvar
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from evaluate_gap_head import CAPTIONS, REGIMES, ROOT, PREVIOUS, WIRE_TEST, load, predictions, wire_inputs
from report_scene_wave_guides import native_board

sys.path.insert(0, str(ROOT.parent / "paired-luminance-detail-v1"))
from render import native_png

PRIOR = PREVIOUS / "native-corrected/manifest.json"
NEURAL = ROOT.parent / "query-signed-colour-v1/standing/manifest.json"


def panels(board):
    with Image.open(checked(board["image"])) as image:
        return {item["name"]: np.array(image.crop((x, y, x + w, y + h)).convert("RGB"))
                for item in board["panels"] for x, y, w, h in (item["png_xywh"],)}


def standing():
    torch.set_num_threads(1)
    models, receipt, completed = load()
    models = {k: models[k] for k in REGIMES}
    archive = reference(PRIOR)
    prior = read_json(checked(archive))
    neural = reference(NEURAL)
    parent = read_json(checked(neural))
    assert {k: parent["checkpoint"][k] for k in ("path", "sha256")} == completed["parent"]
    baseline = {x["id"]: x for x in parent["rows"]}
    configs = {kind: reference(f"configs/{name}.json") for kind, name in (
        ("main", "gfx-qualitative-20231231"), ("mesh", "gfx-green-mesh-20231231"),
    )}
    cfg = {k: read_json(checked(v)) for k, v in configs.items()}
    out = ROOT / "standing-canonical"
    out.mkdir()
    rows = []
    for kind in ("main", "mesh"):
        samples = [row for row in prior["standing"]["rows"] if row["id"].startswith(kind + "-")]
        raw_receipt = samples[0]["raw"]
        expected_path = (cfg["main"]["noisy"] if kind == "main" else cfg["mesh"]["sources"]["noisy"]["path"])
        assert Path(raw_receipt["path"]).resolve() == Path(expected_path).resolve()
        image, meta = read_raw(checked(raw_receipt))
        pattern = np.array(color_indices(meta.pattern))
        height, width = [n // 2 * 2 for n in image.shape]
        packed = np.stack([image[p // 2:height:2, p % 2:width:2] for p in range(4)])
        del image
        for record in samples:
            name = record["id"]
            base = baseline[name]
            assert record["raw"] == raw_receipt and record["input"] == base["base_input"]
            assert record["noise"] == base["noise"]
            bx, by, query_width, query_height = record["box"]
            native_raw = packed[:, by // 2:(by + query_height) // 2, bx // 2:(bx + query_width) // 2]
            with np.load(checked(record["input"]), allow_pickle=False) as capture:
                calib = {k: capture[k][:1] for k in ("colors", "matrix", "wb")}
                x, y, w, h = base["box"]
                assert (w, h) == (query_width, query_height)
                np.testing.assert_array_equal(capture["packed"][0, :, y // 2:(y + h) // 2, x // 2:(x + w) // 2],
                                              native_raw)
                np.testing.assert_array_equal(calib["colors"][0], pattern)
            with np.load(checked(base["output"]), allow_pickle=False) as stash:
                prev = stash["parent"][None]
            existing = panels(record["board"])
            composition = [(label, existing[label]) for label in (
                "ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Parent 100k EMA", "Expanded band",
            ) if label in existing]
            composition[-1] = (CAPTIONS["prior"], composition[-1][1])
            begin = time.monotonic()
            restored = predictions(calib | {"packed": native_raw[None]}, packed, prev,
                                   record["noise"], record["box"], models)
            elapsed = time.monotonic() - begin
            rx, ry, rw, rh = record["ROI_xywh"]
            crop = np.s_[..., ry - by:ry - by + rh, rx - bx:rx - bx + rw]
            changes = {}
            for model, value in restored.items():
                rendered = display(value[crop], calib, exposure=record["exposure"])[0]
                composition.append((CAPTIONS[model], np.rint(rendered.transpose(1, 2, 0) * 255).astype(np.uint8)))
                delta = (value[crop].astype(np.float64) - prev[crop]) * 65535
                scene = linear_rgb(delta, calib)[0]
                chroma = scene - np.einsum("c,chw->hw", [.2126, .7152, .0722], scene)[None]
                changes[model] = {"camera_RMS_DN16": float(np.sqrt(np.mean(delta**2))),
                                  "max_camera_DN16": float(abs(delta).max()),
                                  "max_scene_linear_chroma_change_DN16": float(abs(chroma).max())}
            composition.extend((label, existing[label]) for label in (
                "ISO100 AHD reference", "ISO100 camera JPEG",
            ) if label in existing)
            picture = native_png(out / (name + ".png"), composition)
            output = out / (name + ".npz")
            np.savez_compressed(output, parent=prev, **restored)
            rows.append({k: record[k] for k in ("id", "raw", "input", "box", "ROI_xywh", "noise", "exposure")} | {
                "board": picture, "predictions": reference(output), "parent_pixels": base["output"],
                "measurements": changes, "head_seconds": elapsed,
            })
            print(name, {k: round(v["camera_RMS_DN16"], 3) for k, v in changes.items()}, flush=True)
    assert len(rows) == 8
    write_json(out / "manifest.json", {"driver": reference(__file__), "configs": configs,
                                      "training": receipt, "checkpoint": completed["checkpoint"],
                                      "parent": completed["parent"],
                                      "previous_native_review": archive, "neural_inputs": neural, "rows": rows})


def exact():
    torch.set_num_threads(1)
    models, training, completed = load()
    models = {k: models[k] for k in CAPTIONS}
    score = reference(ROOT / "wire-scores.json")
    rows = [r for r in read_json(checked(score))["rows"] if r["profile"] == "iso6400"]
    gaps = [r for r in rows if r["region_pixels"]["gap"] > 0]
    dips = [r for r in rows if r["region_pixels"]["dip"] > 0]
    assert len(gaps) == 12 and len(dips) == 6
    best_gap = min(gaps, key=lambda r: r["metrics"]["localized"]["gap_exact"] - r["metrics"]["matched"]["gap_exact"])
    weakest = min(dips, key=lambda r: (r["metrics"]["localized"]["dip_dot"] - r["metrics"]["matched"]["dip_dot"])
                  / max(r["metrics"]["matched"]["dip_power"], 1e-12))
    plan = read_json(WIRE_TEST / "plan.json")
    cases = read_json(WIRE_TEST / "fresh-gap.json")["rows"]
    sources = read_json(PREVIOUS / "v120-wire.json")["rows"]
    out = ROOT / "exact"
    out.mkdir()
    reviewed = []
    for index, reason in ((best_gap, "Largest reduction of absolute gap error versus matched training"),
                          (weakest, "Largest decrease of aligned response in a continuous low-amplitude region")):
        picked = next((x, y) for x, y in zip(cases, sources, strict=True)
                      if f'{x["index"]:03d}-{x["noise"]}' == index["id"])
        item, control = picked
        capture, baseline = wire_inputs(item, control)
        case = plan["sources"][item["index"]]
        camera = case["camera"]["pattern"]
        noise = plan["profiles"][item["noise"]]
        neural = baseline["100k"]
        composed = predictions({k: v[:1] for k, v in capture.items() if k not in ("full", "support")},
                               capture["full"], neural[:1], noise, plan["query"], models)
        calib = {k: capture[k][:1] for k in ("packed", "colors", "matrix", "wb")}
        noise_rgb = noisy_malvar(calib)[0]
        truth = capture["target"][0]
        options = [noise_rgb, baseline["V120"][0], neural[0], *[composed[k][0] for k in CAPTIONS], truth]
        labels = ["Noisy Malvar", "V120 EMA", "Corpus 100k", *CAPTIONS.values(), "Exact GT"]
        tags = {"source": case["source"], "CFA": camera, "input": item["input"], "query": plan["query"],
                "source_box": case["box"], "noise": noise, "family": index["family"], "selection": reason}
        direct = native_board(out, index["id"], options, calib, tags, labels=labels, exposure=2.0, contrast=1.0,
                              triplet_indices=(0, labels.index(CAPTIONS["localized"]), len(options) - 1))
        extra = {}
        for head in ("matched", "zero-add"):
            info = native_board(out, index["id"] + "-" + head, [noise_rgb, composed[head][0], truth], calib,
                                tags, labels=("Noisy Malvar", CAPTIONS[head], "Exact GT"), exposure=2.0,
                                contrast=1.0, triplet_indices=(0, 1, 2))
            extra[head] = info["triplet"]
        reviewed.append(direct | {"variant_triplets": extra, "metrics": index["metrics"]})
    write_json(out / "manifest.json", {"driver": reference(__file__), "training": training,
                                     "checkpoint": completed["checkpoint"], "scores": score, "rows": reviewed})


if __name__ == "__main__":
    {"standing": standing, "exact": exact}[sys.argv[1]]()
