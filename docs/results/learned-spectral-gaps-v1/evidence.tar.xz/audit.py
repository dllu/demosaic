"""Audit spatial loss localization, known wave phase, and training data binding."""
import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from train_gap_head import ROOT, NATIVE_I, NATIVE_J, SYNTH, focal_energy
from witness_features import FX, FY, SUPPORTED, SIDE, measured, neighborhood

NOISE = {"shot": 0.00128, "read": 6.5536e-6}
PATTERNS = ([0, 1, 1, 2], [2, 1, 1, 0], [1, 0, 2, 1], [1, 2, 0, 1])
CENTER = SIDE * 7 + 7


def phase():
    rng = np.random.default_rng(12811)
    packs = []
    p, q = np.meshgrid(np.arange(128) * 2, np.arange(128) * 2)
    for mode in ((3, 5), (-3, 5), (0, 3), (4, 0)):
        my, mx = mode
        frequency = (FY[SUPPORTED] == my / 32) & (FX[SUPPORTED] == mx / 32)
        indexes = np.flatnonzero(frequency)
        assert len(indexes) == 1
        freq = indexes[0]
        x = rng.uniform(-2.5, 2.5)
        mosaic = np.stack([.22 + .06 * np.cos(2 * np.pi * (
            mx * (p + pl % 2) + my * (q + pl // 2)) / 32 + x) for pl in range(4)])
        for bayer in PATTERNS:
            colors = np.asarray(bayer)
            before = measured(mosaic, colors, NOISE)
            known = before[CENTER, freq]
            assert np.all(known[:7] > .25) and known[7] > .995
            edited = mosaic.copy()
            edited[:, 56:72, 56:72] = .22
            after = measured(edited, colors, NOISE)
            # Only the center's projection onto the neighbor phase disappears.
            # The neighbor template amplitude is unchanged.
            assert np.isclose(known[6], after[CENTER, freq, 6])
            assert np.max(abs(after[CENTER, freq, :6])) < 1e-6
            packs.append({"mode_yx": mode, "CFA": bayer, "center": known.tolist()})
    return packs


def test_window_isolation():
    values = np.zeros((SIDE * SIDE, 2), dtype=complex)
    values[CENTER] = [1, 2]
    shaped, variance = neighborhood(values, np.ones(len(values)))
    assert not shaped[CENTER].any() and variance[CENTER] == 4
    assert sum(np.any(shaped, axis=1)) == 4
    assert np.all(shaped[CENTER + 2] == values[CENTER])
    flat = np.full((4, 128, 128), .3)
    assert np.max(abs(measured(flat, np.array(PATTERNS[0]), NOISE))) < 1e-7


def test_spatial_supervision():
    p, q = torch.meshgrid(torch.arange(32), torch.arange(32), indexing="ij")
    y = torch.cos(2 * torch.pi * (3 * p + 5 * q) / 32 + .27)
    values = torch.fft.fft2(y, norm="ortho")[NATIVE_I, NATIVE_J] / 2
    dense = torch.view_as_real(values).requires_grad_()
    weights = torch.zeros(32, 32)
    weights[7:17, 12:21] = torch.as_tensor(SYNTH[7:17, 12:21]**2)
    coordinates = tuple(torch.from_numpy(k) for k in (NATIVE_I, NATIVE_J))
    result = focal_energy(dense, weights, coordinates)
    truth = (y.square() * weights).sum() / weights.sum()
    assert abs(result - truth) < 1e-6
    result.backward()
    assert torch.isfinite(dense.grad).all() and dense.grad.abs().sum() > .25
    assert focal_energy(dense, weights * 0, coordinates) == 0
    return float(result.detach())


def check_support():
    receipt = reference(ROOT / "observations.json")
    collected = read_json(checked(receipt))
    plan = read_json(checked(collected["plan"]))
    shapes = {}
    for proof, row in zip(collected["rows"], plan["batches"], strict=True):
        sample = read_json(checked(proof))
        assert sample["index"] == row["index"]
        with np.load(checked(sample["input"]), allow_pickle=False) as record:
            void = record["support"] == 0
            if row["style"] in ("ellipse", "strip"):
                assert void.sum() > 300
                np.testing.assert_array_equal(record["target"][0][:, void], record["target"][1][:, void])
            else:
                assert not void.any()
            counts = shapes.setdefault(row["style"], [])
            counts.append(int(void.sum()))
    return {tag: {"count": len(n), "min_void_pixels": min(n), "max_void_pixels": max(n)}
            for tag, n in shapes.items()}


if __name__ == "__main__":
    torch.set_num_threads(2)
    test_window_isolation()
    write_json(ROOT / "audit.json", {
        "driver": reference(__file__), "known_modes": phase(),
        "focal_window_reference": test_spatial_supervision(),
        "support": check_support(),
        "scope": "Known-mode signed Bayer checks, disjoint neighborhood and noiseless flat tests, differentiable spatial loss and every frozen training support mask.",
    })
