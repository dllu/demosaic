"""Freeze matched training inputs for supervised interruptions of weak wires."""
from collections import Counter
from dataclasses import asdict, replace
from pathlib import Path
import json
import math
import random
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "learned-spectral-detail-v1"
sys.path.insert(0, str(PREVIOUS))
from prepare import KEYS, PATTERNS, PROFILES, ROLES, extract, flat_patch, paired_observation, patch

SEED = 693847120638
COUNT = 448
STYLES = ("photo", "ellipse", "photo", "strip", "photo", "smooth-dip", "photo", "contrast-step")
WIRES = tuple(style for style in STYLES if style != "photo")
ALIGNMENT = ROOT.parent / "scene-spectrum-detail-v1" / "spectrum.py"


def freeze():
    past = reference(PREVIOUS / "plan.json")
    preceding = read_json(checked(past))
    blocked = {row["source"]["id"] for row in preceding["batches"]}
    protected = [reference(ROOT.parent / "query-gap-shoulders-v1" / "plan.json"),
                 *preceding["protected_evaluation"]]
    for note in protected:
        fixture = read_json(checked(note))
        blocked.update(x["source"]["id"] for x in fixture.get("sources", fixture.get("rows", [])))
        blocked.update(fixture.get("source_averages", ()))
    manifest = preceding["training_manifest"]
    rows = [json.loads(row) for row in checked(manifest).read_text().splitlines() if row.strip()]
    assert len(rows) == 90692 and all(r["split"] == "train" for r in rows)
    eligible = [r for r in rows if r["id"] not in blocked
                and min(r["shape"][:2]) >= 512 and np.prod(r["shape"][:2]) <= 7_000_000]
    sources = random.Random(SEED).sample(eligible, COUNT)
    cases = []
    tags = [dict(style=STYLES[(i // 8) % 8], noise=i % 2, layout=(i // 2) % 4,
                 paired=(i // 64) % 2 == 0) for i in range(COUNT)]
    random.Random(SEED + 1).shuffle(tags)
    for i, (source, tag) in enumerate(zip(sources, tags, strict=True)):
        profile = PROFILES[tag["noise"]]
        rng = np.random.default_rng(scene_seed(SEED, i, "geometry"))
        exposure = 0.33 * np.exp(rng.uniform(-0.35, 0.35))
        camera = replace(sample_scene_recipe(scene_seed(SEED, i, "camera")),
                         pattern=tuple(PATTERNS)[tag["layout"]], shot=profile["shot"],
                         read=profile["read"], exposure=float(exposure), black=0.03)
        scene_box, = scene_crop_boxes(source["shape"][:2], patch_size=512, count=1,
                                      seed=scene_seed(SEED, i, "scene-box"))
        query = [128 + 2 * int(pos) for pos in rng.integers(-18, 19, 2)] + [256, 256]
        geometry = None
        if tag["style"] in WIRES:
            angle = rng.uniform(0, math.pi)
            geometry = {
                "wave_angle": [float(angle), float(angle + rng.uniform(0.84, 1.78))],
                "freq": [float(rng.uniform(0.095, 0.194)), float(rng.uniform(0.071, 0.201))],
                "phase": rng.uniform(-math.pi, math.pi, 2).tolist(),
                "center": (128 + rng.uniform(-43, 43, 2)).tolist(),
                "radii": rng.uniform([23, 15], [54, 43]).tolist(),
                "angle": float(rng.uniform(0, math.pi)),
                "amplitude": float(rng.uniform(0.0035, 0.014)),
                "dip_floor": float(rng.uniform(0.23, 0.51)),
            }
        cases.append({"index": i, "source": source, "scene_box": scene_box, "box": query,
                      "camera": asdict(camera), "noise": profile | {"exposure": float(exposure)},
                      "style": tag["style"], "geometry": geometry,
                      "draw": "coupled" if tag["paired"] else "independent",
                      "seeds": {s: scene_seed(SEED, i, s) for s in ("scene", *ROLES, "coupled")}})
    assert len({row["source"]["id"] for row in cases}) == COUNT
    assert {row["source"]["id"] for row in cases}.isdisjoint(blocked)
    write_json(ROOT / "plan.json", {
        "driver": reference(__file__), "seed": SEED, "parent": preceding["parent"],
        "previous_training": past, "training_manifest": manifest, "excluded_evaluations": protected,
        "phase_implementation": reference(ALIGNMENT), "source_count": COUNT, "roles": ROLES,
        "batches": cases, "strata": {"/".join(k): count for k, count in Counter(
            (c["style"], c["noise"]["name"], c["draw"]) for c in cases).items()},
    })


Y, X = torch.meshgrid(torch.arange(512, dtype=torch.float32),
                      torch.arange(512, dtype=torch.float32), indexing="ij")


def smoothstep(value):
    bounded = value.clamp(0, 1)
    return bounded.square() * (3 - 2 * bounded)


def targets(photo, row):
    x, y, width, height = row["box"]
    box = np.s_[y:y + height, x:x + width]
    style = row["style"]
    if style == "photo":
        rng = np.random.default_rng(scene_seed(SEED, row["index"], "detail-strength"))
        return photo, [patch(photo, row["box"], rng.uniform(0.18, 0.62)),
                       patch(photo, row["box"], 0.0)], torch.ones(256, 256)

    geometry = row["geometry"]
    p, q = (X - x - geometry["center"][0], Y - y - geometry["center"][1])
    c, s = math.cos(geometry["angle"]), math.sin(geometry["angle"])
    major, minor = c * p + s * q, -s * p + c * q
    major_radius, minor_radius = geometry["radii"]
    ellipse = ((major / major_radius).square() + (minor / minor_radius).square()).sqrt()
    if style == "ellipse":
        support = smoothstep((ellipse - 1) / 0.35)
    elif style == "strip":
        support = smoothstep((minor.abs() - minor_radius) / 8)
    elif style == "smooth-dip":
        support = 1 - (1 - geometry["dip_floor"]) * (-0.64 * ellipse.square()).exp()
    else:
        support = geometry["dip_floor"] + (1 - geometry["dip_floor"]) * smoothstep((minor + 8) / 16)
    # Outside this band, both interrupted and continuous scenes share a strong
    # continuation. Keep that evidence even when the query has a true break.
    context_dist = torch.minimum(torch.minimum(X - x, x + width - X),
                                 torch.minimum(Y - y, y + height - Y))
    support = 1 - (1 - support) * smoothstep((context_dist + 16) / 20)
    waves = []
    for frequency, angle, origin in zip(geometry["freq"], geometry["wave_angle"],
                                         geometry["phase"], strict=True):
        phase = 2 * math.pi * frequency * (X * math.cos(angle) + Y * math.sin(angle)) + origin
        waves.append(phase.cos() + 0.23 * (2 * phase + 0.31).cos())
    strong, weak = waves
    base = 0.04 + 0.86 * photo + 0.015 * strong
    weak_signal = geometry["amplitude"] * weak * (0.90 - 0.14 * strong)
    intact = (base + support * weak_signal).clamp(0.001, 0.995)
    exterior = (base + 2.2 * weak_signal).clamp(0.001, 0.995)
    absent = base.clamp(0.001, 0.995)
    void = (support[box] == 0)
    assert torch.equal(intact[:, box[0], box[1]][:, void], absent[:, box[0], box[1]][:, void])
    if style in ("ellipse", "strip"):
        assert void.count_nonzero() > 300
    else:
        assert not torch.any(void)
    return exterior, [intact[:, box[0], box[1]].contiguous(),
                      absent[:, box[0], box[1]].contiguous()], support[box].contiguous()


def observations(row):
    photo = extract(row)
    camera = replace(sample_scene_recipe(SEED), **row["camera"])
    exterior, clean, support = targets(photo, row)
    clean.append(flat_patch(clean[1]))
    large = observe_scene(exterior, replace(camera, noise_seed=row["seeds"]["scene"]))
    if row["draw"] == "coupled":
        pair, _ = paired_observation(clean[0][None], clean[1][None], row["noise"], [camera.pattern],
                                     torch.tensor(camera.wb)[None], torch.tensor(camera.camera_inverse)[None],
                                     row["seeds"]["coupled"])
        native = {k: list(pair[k]) for k in (*KEYS, "target")}
        flat = observe_scene(clean[-1], replace(camera, noise_seed=row["seeds"]["flat"]))
        for k in native:
            native[k].append(getattr(flat, k).numpy())
    else:
        rows = [observe_scene(im, replace(camera, noise_seed=row["seeds"][role]))
                for role, im in zip(ROLES, clean, strict=True)]
        native = {k: [getattr(sample, k).numpy() for sample in rows] for k in (*KEYS, "target")}
    for k in ("colors", "wb", "matrix"):
        for value in native[k]:
            np.testing.assert_array_equal(getattr(large, k).numpy(), value)
    return {k: np.stack(v) for k, v in native.items()} | {
        "scene_packed": large.packed.numpy(), "support": support.numpy(),
    }


def collect():
    torch.set_num_threads(2)
    directory = ROOT / "observations"
    directory.mkdir(exist_ok=True)
    plan = reference(ROOT / "plan.json")
    rows = []
    for row in read_json(checked(plan))["batches"]:
        i = row["index"]
        fields = observations(row)
        npz = directory / f"{i:03d}.npz"
        with npz.open("xb") as file:
            np.savez(file, **fields)
        record = npz.with_suffix(".json")
        write_json(record, {"plan": plan, "index": i, "input": reference(npz),
                            "fingerprints": {k: fingerprint(v) for k, v in fields.items()}})
        rows.append(reference(record))
        if i % 40 == 0:
            print(i, row["style"], row["noise"]["name"], flush=True)
    write_json(ROOT / "observations.json", {"driver": reference(__file__), "plan": plan, "rows": rows})


if __name__ == "__main__":
    freeze()
    collect()
