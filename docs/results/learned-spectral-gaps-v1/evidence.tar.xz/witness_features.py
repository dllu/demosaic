"""Measure local Bayer support at a neighboring-green phase."""
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "learned-spectral-detail-v1"
sys.path.insert(0, str(PREVIOUS))
from head_corrected_broad import FX, FY, SUPPORTED, GainHead, XI, YI, squares
from spectrum import WINDOW

FEATURE_COUNT = 8
SIDE = len(np.unique(YI))
SHIFTED = np.exp(-2j * np.pi * (
    (np.arange(4) % 2)[:, None] * FX[SUPPORTED] +
    (np.arange(4) // 2)[:, None] * FY[SUPPORTED]
))


def neighborhood(vector, variance):
    """Average the four cardinal windows that share no sites with the center."""
    shape = (SIDE, SIDE, vector.shape[-1])
    grid = vector.reshape(shape)
    noise = variance.reshape(shape[:2])
    total = np.zeros_like(grid)
    sigma = np.zeros_like(noise)
    for k in (0, 1):
        g = np.swapaxes(grid, 0, k)
        n = np.swapaxes(noise, 0, k)
        out = np.swapaxes(total, 0, k)
        ns = np.swapaxes(sigma, 0, k)
        # Two tile steps are 32 native pixels, a whole period at every FFT bin.
        out[2:] += g[:-2]
        ns[2:] += n[:-2]
        out[:-2] += g[2:]
        ns[:-2] += n[2:]
    return total.reshape(vector.shape), sigma.ravel()


def unit(value):
    return value / np.maximum(abs(value), 1e-12)


def measured(raw, layout, noise):
    pixels = squares(raw, YI, XI).astype(np.float64)
    average = (pixels * WINDOW).sum(axis=(-1, -2)) / WINDOW.sum()
    weighted = (pixels - average[..., None, None]) * WINDOW
    coeff = np.fft.fft2(weighted, norm="ortho")[..., SUPPORTED] * SHIFTED
    variance = (noise["shot"] * average.clip(min=0) + noise["read"]).clip(min=2e-11)
    variance *= np.mean(WINDOW**2)
    sigma = np.sqrt(variance)
    green = np.flatnonzero(layout == 1)
    red, blue = (np.flatnonzero(layout == color)[0] for color in (0, 2))
    direct = coeff[:, green].mean(1)
    fused_variance = variance[:, green].sum(1) * 0.25
    external, external_variance = neighborhood(direct, fused_variance)
    local_direction = unit(direct)
    held_direction = unit(external)
    external_z = abs(external) / np.sqrt(external_variance[:, None]).clip(min=2e-5)
    normalized = coeff / sigma[..., None]
    local_color = (normalized[:, [red, blue]] * local_direction[:, None].conj()).real
    external_color = (normalized[:, [red, blue]] * held_direction[:, None].conj()).real
    external_green = (normalized[:, green] * held_direction[:, None].conj()).real
    agreement = (local_direction * held_direction.conj()).real
    return np.concatenate((
        np.arcsinh(local_color).transpose(0, 2, 1),
        np.arcsinh(external_color).transpose(0, 2, 1),
        np.arcsinh(external_green).transpose(0, 2, 1),
        np.log1p(external_z)[..., None], agreement[..., None],
    ), axis=-1).clip(-6, 6).astype(np.float32)


class WitnessHead(GainHead):
    def __init__(self):
        super().__init__()
        old = self.layers[0]
        replacement = nn.Linear(old.in_features + FEATURE_COUNT, old.out_features)
        with torch.no_grad():
            replacement.weight.zero_()
            replacement.weight[:, :old.in_features].copy_(old.weight)
            replacement.bias.copy_(old.bias)
        self.layers[0] = replacement

    def forward(self, features, contexts, basis):
        standard, measurement = torch.split(features, (17, FEATURE_COUNT), dim=-1)
        features = torch.cat((standard, contexts[..., None], measurement), dim=-1)
        logits = self.layers(features)
        weights = logits.tanh() * self.cap
        return (basis * weights[..., None]).sum(dim=-2)
