"""Repeat the held camera check with a horizontal rather than vertical bracket."""

from pathlib import Path

import numpy as np
from probe_donor_phase_geometry import restore, sensor_box
from probe_fresh_phase_refit import write_array
from report_phase_drift import make_camera_board

from demosaic.bracket_phase_geometry import bracket_donor_geometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
plan = read_json(ROOT / "plan.json")
old = read_json(checked(plan["camera_baseline"]))
conditions = read_json(checked(plan["camera_conditions"]))
cfg = LocalWaveConfig(**plan["config"])
output = ROOT / "horizontal"
output.mkdir()
rows = []
for row, condition in zip(old["camera"], conditions["camera"], strict=True):
    key, scene = row["id"], row["source"]
    assert key == condition["board"]["id"]
    x, y, w, h = scene["query_box"]
    ax, ay, *_ = scene["absolute_query_xywh"]
    with np.load(checked(scene["query_arrays"])) as f:
        full_width = f["packed"].shape[-1] * 2
    # Round to a multiple of four to preserve the crop-centering Bayer parity.
    side = 4 * (min(128, x, full_width - x - w) // 4)
    boxes = [(xx, y + (h - side) // 2, side, side) for xx in (x - side, x + w)]
    native_boxes = [(a + ax - x, b + ay - y, c, d) for a, b, c, d in boxes]
    donors = []
    for box, native in zip(boxes, native_boxes, strict=True):
        packed, colors = sensor_box(scene["query_arrays"], box)
        donors.append((packed[0], colors[0], native))
    noise = condition["noise"]
    fit = bracket_donor_geometry(
        donors, scene["absolute_query_xywh"], scene["guide"], shot=noise["shot"], read=noise["read"]
    )
    prediction = row["crosscheck_prediction"]
    if any(fit["accepted"]):
        parent = np.load(checked(scene["parent_prediction"]), mmap_mode="r")[
            0, :, y : y + h, x : x + w
        ]
        packed, colors = sensor_box(scene["query_arrays"], scene["query_box"])
        corrected, _ = restore(parent, packed[0], colors[0], fit, noise, cfg, (2.0,), True, True)
        prediction = write_array(output / f"{key}-prediction.npz", corrected=corrected[2])
    rec = make_camera_board(
        output, row, {"id": key, "prediction": prediction, "fit": fit}, label="Horizontal bracket"
    )
    rows.append(
        {
            "id": key,
            "fit": fit,
            "donor_boxes": native_boxes,
            "query_arrays": scene["query_arrays"],
            "image": rec["image"],
            "panels": rec["panels"],
            "change_DN16": rec["change_DN16"],
        }
    )
    print(key, fit["accepted"], rec["change_DN16"], flush=True)
write_json(
    output / "result.json",
    {"script": reference(__file__), "plan": reference(ROOT / "plan.json"), "rows": rows},
)
