"""Show the three source neighborhoods underlying the real RAW bracket checks."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
plan = read_json(root / "plan.json")
previous = read_json(checked(plan["camera_baseline"]))
keys = ("main-chain-link-fence", "mesh-profile3879-left", "mesh-profile3879-right")
sheet = Image.new("RGB", (418, 3 * 168), "#eeeeee")
draw = ImageDraw.Draw(sheet)
records = []
for i, key in enumerate(keys):
    row = next(x for x in previous["camera"] if x["id"] == key)
    scene = row["source"]
    x, y, w, h = scene["query_box"]
    ax, ay, *_ = scene["absolute_query_xywh"]
    boxes = [(x + w // 2 - 64, yy, 128, 128) for yy in (y - 128, y + h // 2 - 64, y + h)]
    parent = np.load(checked(scene["parent_prediction"]), mmap_mode="r")
    with np.load(checked(scene["query_arrays"])) as f:
        ctx = {k: f[k] for k in ("wb", "matrix")}
    draw.text((6, i * 168 + 4), key, fill="black")
    for j, ((a, b, c, d), label) in enumerate(
        zip(boxes, ("Upper donor", "Query center", "Lower donor"), strict=True)
    ):
        tile = display(parent[..., b : b + d, a : a + c], ctx, exposure=row["display_exposure"])[0]
        pixels = np.rint(tile.transpose(1, 2, 0) * 255).astype(np.uint8)
        assert pixels.shape == (128, 128, 3)
        left, top = 6 + 138 * j, i * 168 + 34
        draw.text((left, i * 168 + 18), label, fill="black")
        sheet.paste(Image.fromarray(pixels), (left, top))
        records.append(
            {
                "id": key,
                "kind": label,
                "source_xywh": [a + ax - x, b + ay - y, c, d],
                "parent": scene["checkpoint"],
                "parent_prediction": scene["parent_prediction"],
                "display_exposure": row["display_exposure"],
                "figure_xywh": [left, top, c, d],
            }
        )
path = root / "nearby-regions.png"
sheet.save(path)
write_json(
    root / "nearby-regions.json",
    {
        "source": reference(__file__),
        "image": reference(path),
        "cells": records,
        "scope": "Unresized V120 display crops annotate the donor geometry. Geometry estimation receives only the original noisy RAW samples from the labeled donors.",
    },
)
