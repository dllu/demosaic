"""Test whether discordant planar donors produce an apparent curvature."""

from pathlib import Path

import numpy as np
import torch
from probe_donor_phase_geometry import restore, sample_donor_raw, sensor_box
from report_fold_support_pooling import ROI, evaluated, measure

from demosaic.bracket_phase_geometry import bracket_donor_geometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig

ROOT = Path(__file__).resolve().parent
SCALES = (0.94, 1.06)


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    plan = read_json(ROOT / "plan.json")
    cfg = LocalWaveConfig(**plan["config"])
    old = read_json(checked(plan["single_collection"]))
    rows = []
    for item in old["synthetic"]:
        case = read_json(checked(item["case"]))
        if case["source"] not in (86, 87) or case["placement"] != "far":
            continue
        key = case["id"]
        noise = plan["profiles"][case["profile"]]
        donor = old["donors"][item["guide_key"]]
        recipe = case["metadata"]["recipe"]
        changed = recipe | {
            "periods": [v * s for v, s in zip(recipe["periods"], SCALES, strict=True)]
        }
        case_left = case | {"metadata": case["metadata"] | {"recipe": changed}}
        left, colors, declaration = sample_donor_raw(case_left, noise, plan["left_xywh"], 7954)
        with np.load(checked(donor["sensor"])) as f:
            right = f["packed"], f["colors"], plan["right_xywh"]
        geometry = bracket_donor_geometry(
            [(left, colors, plan["left_xywh"]), right],
            plan["query_xywh"],
            donor["initial_guide"],
            shot=noise["shot"],
            read=noise["read"],
        )
        setting = next(
            s
            for s in plan["settings"]
            if (s["profile"], s["placement"], s["budget_DN16"]) == (case["profile"], "far", 0.02)
        )
        threshold = setting["threshold"]
        p = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as data:
            truth = data["target"].astype(np.float64)
            quiet = data["quiet"][ROI]
        packed, cfa = sensor_box(case["sensor"], plan["query_xywh"])
        scores = {}
        for label in ("planar", "curved"):
            frames = []
            for role in range(3):
                images, _ = restore(
                    p[role][ROI].astype(np.float32),
                    packed[role],
                    cfa[role],
                    geometry,
                    noise,
                    cfg,
                    (threshold,),
                    False,
                    label == "curved",
                )
                frames.append(images[threshold])
            scores[label] = evaluated(measure(p, truth, quiet, np.stack(frames)), setting["scale"])
        rows.append(
            {
                "id": key,
                "case": item["case"],
                "left_declaration": declaration,
                "fit": geometry,
                "scores": scores,
            }
        )
        print(key, geometry["accepted"], flush=True)
    assert len(rows) == 4
    write_json(
        ROOT / "stress.json",
        {
            "source": reference(__file__),
            "rows": rows,
            "scope": "Both donors are planar; the left donor periods are 0.94 and 1.06 times the original. "
            "Query is the original straight fixture with independent noise. Tests adjacent surfaces "
            "whose phase normal directions agree but whose local periods differ discontinuously.",
        },
    )


if __name__ == "__main__":
    run()
