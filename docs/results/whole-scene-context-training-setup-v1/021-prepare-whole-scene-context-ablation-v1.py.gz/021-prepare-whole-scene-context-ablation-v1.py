"""Freeze the matched native-bin4 whole-scene quality experiment prospectively."""
import hashlib
import json
import sys
from pathlib import Path

from demosaic.experiments.artifacts import freeze_sources, reference, verify_plan, write_json

repo = Path.cwd()
root = repo/'.cache/experiments/whole-scene-context-ablation-v1'
assert not root.exists()
source = repo/'.cache/current-quality-20261023-v1/V123-complete-source-loss-review-v1/future-cohort-v1/manifest4.jsonl'
rows = [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
eligible = []
for r in rows:
    if r['split'] != 'train' or min(r['shape'][:2]) < 768 or r['shape'][0]*r['shape'][1] > 4_000_000:
        continue
    assert r['bin_factor'] == 4 and r['color_space'] == 'linear-sRGB' and r['dtype'] == 'uint16'
    assert str(r['cache']).startswith('/mnt/external/demosaic/commons-')
    assert not any(name in str(r['cache']).upper() for name in ['DSCF3879','DSCF3880','DSCF3842','DSCF3835'])
    eligible.append(r)
assert len(eligible) > 20000
ordered = sorted(eligible,key=lambda r:hashlib.sha256(('scene-context-development64-v1:'+r['id']).encode()).hexdigest())
development,train = ordered[:64],ordered[64:]
assert not {r['id']for r in development} & {r['id']for r in train}
root.mkdir()
for name,data in [('train',train),('development',development)]:
    with (root/f'manifest-{name}.jsonl').open('x') as f:
        for r in data:f.write(json.dumps(r,sort_keys=True)+'\n')
work,files = freeze_sources(repo,root,entries=('train_scene_context.py','profile_raw_kernel_inference.py',
                            'report_checkpoint_pilot.py','audit_checkpoint_pilot.py'))
parent = reference('/mnt/external/demosaic/models/v120-final20000.pt')
assert parent['sha256'] == 'a9d9b6b4f974e24a6b11e5e740aab32314233a7f53c056cf37c7d2aac1c589fb'
plan = {'root':str(root),'work':str(work),'python':sys.executable,'frozen_files':files,
        'training_script':reference(work/'scripts/train_scene_context.py'),
        'parent':parent,'DINO_sha256':'691963f0f796aac860d818d59d9d14287a4675612829fbe9467c7f5df8ce5b14',
        'source_manifest':reference(source),'train_manifest':reference(root/'manifest-train.jsonl'),
        'development_manifest':reference(root/'manifest-development.jsonl'),
        'eligible_sources':len(eligible),'training_sources':len(train),'development_sources':64,
        'modes':['none','pooled','spatial'],'model_seed':202611170020,'data_seed':202611170021,
        'steps':2000,'scenes_per_step':2,'crops_per_scene':4,'patch_size':256,'adapter_width':32,
        'preview_long_side':1024,'preview_exposure':1.,'precision':'bfloat16',
        'base_lr':1e-5,'adapter_lr':1e-4,'weight_decay':1e-4,'warmup_steps':100,'ema_decay':.999,
        'checkpoint_every':500,'log_every':25,'minimum_start_RAM_GiB':48,'minimum_runtime_RAM_GiB':32,
        'maximum_GPU_GiB':16,'minimum_disk_GiB':96,'maximum_arm_seconds':21600,
        'scientific_primary':'Spatial whole-scene context versus local-only none; pooled secondary. Identical frozen DINO parent and base restoration architecture, matched native-bin4 photo cohort, exact full noisy observations/crops/targets, identical2000-update horizons and loss. Retain source-level adverse tails and correct/shuffled/masked/spatially shuffled context interventions.',
        'data_contract':'Native bin4 full binned source fields, minimum native short axis768/max4MP; no additional2x reduction. One camera/exposure/noise observation followed by4 exact native256 crops per scene. Global D4 only, no independent crop resize/homography or optical PSF. This changes data relative to mature V120; all three continuation arms share this change.64 sources withheld from these continuations, but possibly seen by mature parent; development holdout, not untouched camera evidence.',
        'safety_contract':'Existing cleaned Commons training records only; original personal photos/protected GFX families/JPEGs/siblings excluded by source provenance. No new source-media reads. Ordinary supervised conditioning from full noisy scene, not a withheld-evidence confidence score. Scene features modulate bottleneck; local DINO/RAW path retained.',
        'review_contract':'No quality-based early stopping, threshold selection or automatic restart. Complete all three declared horizons before new final GT/reference quality analysis. Compare full native known-GT sources plus weak/quiet counterexamples and both standing GFX families using cached media. At least two primary native noisy/restored/exactGT triplets, same coordinates/transforms; independent real ISO100/AHD/JPEG refs are not GT. No quality/speed/SOTA claim from preflight.',
        'inputs':[reference(source),reference(root/'manifest-train.jsonl'),reference(root/'manifest-development.jsonl'),parent]}
write_json(root/'plan.json',plan);verify_plan(plan)
write_json(root/'admission.json',{'plan':reference(root/'plan.json'),'script':reference(__file__),
            'training_sources':len(train),'development_sources':64,
            'scope':'Prospective matched scene-context architecture admission. No training/GT evaluation/encoder calls yet. Every selected cache actual hash checked on first load and every observation/target/crop fingerprint logged across arms. Parent and DINO weights separately pinned.'})
print(len(train),'train scenes,64 development sources;3 matched2000-update arms admitted')
