"""Capture an observation without treating a mutable log as a terminal receipt."""
import datetime
import hashlib
import json
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path('.cache/experiments/full-corpus-scaling-v3').resolve()
allocation = root / 'production-handoff-v2'
progress = read_json(allocation / 'production-progress.json')
child = progress.get('child', {})
try:
    process = psutil.Process(child['pid'])
    same_live = process.create_time() == child['create_time'] and process.status() != psutil.STATUS_ZOMBIE
except (psutil.NoSuchProcess, KeyError):
    same_live = False
scene = Path('.cache/experiments/whole-scene-context-ablation-v2').resolve()
observations = {}
for mode in ['none', 'pooled', 'spatial']:
    path = scene / 'work/artifacts/train' / mode / 'progress.json'
    if path.exists():
        data = path.read_bytes()
        observations[mode] = {'path': str(path), 'observed_bytes_sha256': hashlib.sha256(data).hexdigest(),
                              'observed_contents': json.loads(data)}
    terminal = path.parent / 'completed.json'
    if terminal.exists():
        observations.setdefault(mode, {})['terminal_receipt'] = reference(terminal)
write_json(root / 'publication-progress-capture-v2.json', {
    'observed_at_UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'plan': reference(root / 'production-handoff-plan-v2.json'),
    'launch': reference(root / 'production-handoff-v2-launch.json'),
    'observed_allocation_contents': progress,
    'same_child_verified_live': same_live,
    'scene_observations': observations,
    'first1000_completed': reference(root / 'work/artifacts/train/long100k/phase-000001-001000/completed.json'),
    'scope': 'Point-in-time observation, not proof a whole allocation completed. Live log paths are descriptive, their observed contents are embedded, and terminal receipts are separately identified. No prefix replay or new model evaluation.'})
print(json.dumps({'same_live': same_live, 'stage': progress['stage'],
                  'scene_steps': {k: v.get('observed_contents', {}).get('step') for k, v in observations.items()}}))
