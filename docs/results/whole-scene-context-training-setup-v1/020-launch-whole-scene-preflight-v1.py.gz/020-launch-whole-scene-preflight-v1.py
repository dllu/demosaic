"""Start actual three-mode optimizer qualification against the frozen admission."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

repo=Path.cwd();root=repo/'.cache/experiments/whole-scene-context-ablation-v1'
plan=read_json(root/'plan.json');verify_plan(plan)
assert '19 passed' in (repo/'.cache/scene-training-data-tests-v1.log').read_text()
assert not (root/'preflight-launch.json').exists() and not (root/'preflight').exists()
assert psutil.virtual_memory().available > plan['minimum_start_RAM_GiB']*2**30
assert shutil.disk_usage(root).free > plan['minimum_disk_GiB']*2**30
os.sched_setaffinity(0,[14,15])
work=Path(plan['work'])
command=[sys.executable,str(checked(plan['training_script'])),'preflight',str(root/'plan.json'),str(root/'preflight')]
env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONUNBUFFERED='1')
with (root/'preflight.log').open('x') as log:
    child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
identity={'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'command':command,
          'plan':reference(root/'plan.json'),'launcher':reference(__file__),
          'scope':'Discarded actual256/B4 all3-mode optimizer qualification; no production admitted by this launcher, no automatic restart.'}
write_json(root/'preflight-launch.json',identity)
print(identity)
