"""Fix the zero-update output handoff and retain canonical mosaic/optimizer state."""
from pathlib import Path
from demosaic.experiments.artifacts import freeze_sources,read_json,reference,verify_plan,write_json

repo=Path.cwd();old=repo/'.cache/experiments/whole-scene-context-ablation-v1'
scale=repo/'.cache/experiments/full-corpus-scaling-v3'
root=repo/'.cache/experiments/whole-scene-context-ablation-v2';assert not root.exists()
assert read_json(scale/'01-context-none-result.json')['returncode']==1
assert 'FileNotFoundError' in (scale/'01-context-none.log').read_text()
assert not (old/'work/artifacts/train/none').exists()
base=read_json(old/'plan.json');root.mkdir()
work,files=freeze_sources(repo,root,entries=('train_scene_context.py','profile_raw_kernel_inference.py',
                                          'report_checkpoint_pilot.py','audit_checkpoint_pilot.py'))
plan={**base,'root':str(root),'work':str(work),'frozen_files':files,
      'training_script':reference(work/'scripts/train_scene_context.py'),
      'train_manifest':base['train_manifest'],'development_manifest':base['development_manifest'],
      'canonical_auxiliary_mosaic_loss':True,'complete_optimizer_RNG_checkpoints':True,
      'previous_plan':reference(old/'plan.json'),
      'source_admission_correction':'First context production stopped at output.mkdir before model construction/data draws. Create parent paths. Also retain the canonical auxiliary mosaic term, shared by all3 arms, and serialize complete Adam/RNG/draw-index state. Old RGB-only preflight/export sources and receipts preserved; no production context updates to reinterpret.'}
plan['inputs']=[*base['inputs'],reference(old/'plan.json'),reference(scale/'01-context-none-result.json'),reference(scale/'01-context-none.log')]
write_json(root/'plan.json',plan);verify_plan(plan)
write_json(root/'admission-addendum.json',{'plan':reference(root/'plan.json'),'previous_plan':reference(old/'plan.json'),
           'script':reference(__file__),'before_any_context_production_updates':True,
           'scope':plan['source_admission_correction']})
print(root)
