"""Independently read saved bytes, CPU checkpoint state and observation lineage."""
import gzip
import hashlib
import json
import re
import tarfile
from collections import Counter
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
scale = repo / '.cache/experiments/full-corpus-scaling-v3'
scene = repo / '.cache/experiments/whole-scene-context-ablation-v2'
checks = []
publication_refs = []
for family in ['whole-scene-context-training-setup-v1', 'full-corpus-training-setup-v1']:
    publication_path = repo / 'docs/results' / family / 'publication.json'
    publication_refs.append(reference(publication_path))
    publication = read_json(publication_path)
    for item in publication['archives']:
        data = gzip.decompress(checked(item['published']).read_bytes())
        assert hashlib.sha256(data).hexdigest() == item['original']['sha256']
        assert data == checked(item['original']).read_bytes()
    for snapshot in publication['source_snapshots']:
        expected = {item['member']: item for item in snapshot['members']}
        with tarfile.open(checked(snapshot['published']), 'r:gz') as tar:
            assert set(tar.getnames()) == set(expected)
            for name, item in expected.items():
                data = tar.extractfile(name).read()
                assert hashlib.sha256(data).hexdigest() == item['original']['sha256']
                assert data == checked(item['original']).read_bytes()
    checks.append({'publication': family, 'exact_archives': len(publication['archives']),
                   'exact_source_members': sum(len(s['members']) for s in publication['source_snapshots'])})

orders = []
for name in ['order20k', 'order100k']:
    root = repo / '.cache/experiments/full-corpus-scaling-v1' / name
    header = read_json(root / 'photo-epoch-order.json')
    order = np.load(checked({'path': str(root / header['order']['path']), 'sha256': header['order']['sha256']}))
    ordinary = order[order >= 0]
    assert len(ordinary) == header['summary']['Commons_families']['ordinary']
    assert len(np.unique(ordinary)) == 90778
    orders.append(order)
assert np.array_equal(orders[0], orders[1][:len(orders[0])])
checks.append({'epoch_payload_prefix_exact': int(len(orders[0])), 'planned_full100k_unique_ordinary': 90778,
               'scope': 'Prepared ordering only, not completed coverage.'})

profiles = [read_json(scale / 'profiles' / name / 'result.json') for name in ['strict0', 'fast0', 'fast2']]
assert all(r['sampled_input_witnesses_outside_measurement'] == profiles[0]['sampled_input_witnesses_outside_measurement'] for r in profiles)
assert all(r['actual_calls'] == {'root': 77, 'DINO': 77} and r['DINO_unchanged'] for r in profiles)
checks.append({'actual_profile_updates': 231, 'sampled_full_input_witnesses_exact': 5})

for version in [1, 2]:
    root = repo / f'.cache/experiments/whole-scene-context-ablation-v{version}'
    receipt = read_json(root / 'preflight/result.json')
    assert receipt['all_modes_passed'] and len(receipt['results']) == 3
    for row in receipt['results']:
        state = torch.load(checked(row['roundtrip_checkpoint']), map_location='cpu', weights_only=True)
        assert state['step'] == 2 and len(state['model']) == len(state['ema']) == 101
        if version == 2:
            assert all(s['step'] == 2 for s in state['optimizer']['state'].values())
            assert state['scene_draw_index'] == 4 and state['python_rng'] and state['cuda_rng']
        assert row['initial_max_DN16'] == 0 and row['DINO_unchanged']
        del state
    checks.append({'scene_version': version, 'actual_discarded_updates': 6,
                   'canonical_mosaic_and_optimizer_state': version == 2})

phase = scale / 'work/artifacts/train/long100k/phase-000001-001000'
completed = read_json(phase / 'completed.json')
state = torch.load(checked(completed['last']), map_location='cpu', weights_only=True)
assert state['step'] == 1000 and len(state['model']) == len(state['ema']) == 91
assert len(state['optimizer']['state']) == 89
assert all(s['step'] == 1000 for s in state['optimizer']['state'].values())
for section in ['model', 'ema']:
    assert all(torch.isfinite(t).all() for t in state[section].values())
for item in state['optimizer']['state'].values():
    assert all(torch.isfinite(t).all() for t in item.values() if isinstance(t, torch.Tensor))
checkpoint_keys = list(state)
assert any('rng' in k.lower() for k in state)
del state
observations = [json.loads(line) for line in checked(completed['source_crop_observations']).read_text().splitlines()]
assert [r['step'] for r in observations] == list(range(1, 1001))
assert dict(Counter(r['domain'] for r in observations)) == completed['domains']
visits, boxes = Counter(), set()
for row in observations:
    seed = int.from_bytes(hashlib.sha256(f'data:70:{row["step"]}'.encode()).digest()[:8], 'little') % 2**63
    assert row['data_RNG_seed'] == seed and row['global_draw_start'] == (row['step'] - 1) * 16
    for item in row['sources']:
        if isinstance(item, dict) and item.get('source_id'):
            visits[item['source_id']] += 1
            if item.get('cache_xywh'):
                boxes.add((item['source_id'], tuple(item['cache_xywh'])))
assert dict(visits) == completed['source_visit_counts']
assert len(visits) == completed['distinct_photo_sources'] == 5045
assert sum(visits.values()) == completed['photo_draws'] == 5294
assert len(boxes) == completed['unique_source_crop_boxes'] == 5047
steps = []
for binding in completed['corruption_condition_files']:
    with np.load(checked(binding)) as data:
        assert data['values'].shape == (250, 16, 14)
        assert np.isfinite(data['values']).all()
        assert all(domain == observations[int(step) - 1]['domain'] for step, domain in zip(data['steps'], data['domains'], strict=True))
        steps.extend(data['steps'].tolist())
assert steps == list(range(1, 1001))
checks.append({'completed_production_updates': 1000, 'target_examples': 16000,
               'photo_sources': len(visits), 'photo_visits': sum(visits.values()), 'source_crop_pairs': len(boxes),
               'conditioning_shape': [1000, 16, 14], 'model_EMA_tensors': 91, 'Adam_states': 89,
               'checkpoint_keys': checkpoint_keys, 'checkpoint': completed['last'],
               'scope': 'Saved1000-update milestone only. No427/camera quality result.'})

retention = read_json(scale / 'operator-retention-addendum.json')
assert retention['retained_step8']
handoff = read_json(scale / 'production-handoff-plan-v2.json')
assert handoff['compute_schedule'][-1] == {'kind': 'scale', 'arm': 'long100k', 'updates': 99000, 'maximum_seconds': 259200}
assert checked(handoff['adopted_first1000']) == phase / 'completed.json'
assert read_json(checked(handoff['context_preflight']))['all_modes_passed']
checks.append({'remaining_updates_adopt_saved1000': True, 'original_failed_admission_receipts_preserved': True,
               'discarded_step6_bytes_missing': True, 'discarded_step6_not_recreated': True})

documents = ['docs/full-corpus-scaling.md', 'docs/whole-scene-context-next-test.md',
             'docs/current-model.md', 'docs/experiments.md', 'docs/research.md', 'docs/index.md',
             'diary/index.md', 'diary/2026-11-17-00-58-45-scene-context-full-corpus-training.md']
link_count = 0
for filename in documents:
    path = repo / filename
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        target = target.split('#')[0].strip('<>')
        assert (path.parent / target).exists(), (filename, target)
        link_count += 1
checks.append({'current_document_links_exist': link_count})
write_json(repo / '.cache/scene-scale-independent-setup-verification-v1.json', {
    'all_passed': True, 'publications': publication_refs, 'verifier': reference(__file__),
    'checks': checks, 'scope': 'Independent CPU read/audit of exact existing bytes; no new observations, model forward, GPU update or quality metric. Training completion, broad numerical evaluation and actual native viewing remain separate. No unavailable step6 checkpoint reconstruction.'})
print(json.dumps({'all_passed': True, 'check_groups': len(checks), 'links': link_count}))
