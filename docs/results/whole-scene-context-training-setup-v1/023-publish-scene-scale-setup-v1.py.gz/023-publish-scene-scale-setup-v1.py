"""Preserve exact setup, failures and completed phases; never package live logs."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
experiments = repo / '.cache/experiments'
scale = experiments / 'full-corpus-scaling-v3'
scene = experiments / 'whole-scene-context-ablation-v2'


def publish(name, roots, extras, *, scope):
    destination = repo / 'docs/results' / name
    destination.mkdir()
    paths = set(Path(p).resolve() for p in extras)
    snapshots = []
    for root in roots:
        plan_path = root / 'plan.json'
        plan = read_json(plan_path)
        work = Path(plan['work'])
        members = []
        archive = destination / (root.name + '-frozen-sources.tar.gz')
        with tarfile.open(archive, 'w:gz') as tar:
            for filename, digest in sorted(plan['frozen_files'].items()):
                path = checked({'path': filename, 'sha256': digest})
                data = path.read_bytes()
                member_name = str(path.relative_to(work))
                info = tarfile.TarInfo(member_name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
                members.append({'member': member_name, 'original': {'path': filename, 'sha256': digest}})
        snapshots.append({'plan': reference(plan_path), 'published': reference(archive), 'members': members})
        paths.update(p for p in root.iterdir() if p.is_file()
                     and p.suffix in {'.json', '.yaml', '.log'}
                     and p.name != 'production-handoff-v2-controller.log')
    archives = []
    for index, path in enumerate(sorted(paths)):
        assert path.is_file() and path.suffix != '.pt', path
        data = path.read_bytes()
        original = {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest()}
        target = destination / f'{index:03d}-{path.name}.gz'
        with target.open('xb') as stream:
            stream.write(gzip.compress(data, mtime=0))
        assert gzip.decompress(target.read_bytes()) == data
        archives.append({'original': original, 'published': reference(target),
                         'decompressed_bytes_exact': True})
    receipt = {'archives': archives, 'source_snapshots': snapshots,
               'publisher': reference(__file__), 'scope': scope,
               'not_embedded': 'Model/optimizer/DINO binaries, original media, training image caches and unselected upstream large manifests remain in their bound local locations. No claim all transitive paths are packed. The discarded logger step6 checkpoint was replaced and is explicitly unavailable; its receipts are preserved without reconstruction.'}
    write_json(destination / 'publication.json', receipt)
    print(json.dumps({'publication': str(destination / 'publication.json'), 'archives': len(archives),
                      'source_trees': len(snapshots),
                      'bytes': sum(p.stat().st_size for p in destination.iterdir())}))


scene_roots = [experiments / f'whole-scene-context-ablation-v{i}' for i in [1, 2]]
scene_extras = [repo / p for p in [
    'src/demosaic/scene_data.py', 'src/demosaic/scene_training_data.py',
    'src/demosaic/scene_restoration.py', 'scripts/train_scene_context.py',
    'tests/test_scene_data.py', 'tests/test_scene_training_data.py', 'tests/test_scene_restoration.py',
    '.cache/prepare-whole-scene-context-ablation-v1.py', '.cache/launch-whole-scene-preflight-v1.py',
    '.cache/prepare-whole-scene-context-ablation-v2.py', '.cache/scene-data-tests-v1.log',
    '.cache/scene-restoration-tests-v1.log', '.cache/scene-training-data-tests-v1.log',
    '.cache/scene-final-tests-v1.log', '.cache/scene-scale-final-lint-v1.log',
    '.cache/scene-canonical-trainer-lint-v2.log', '.cache/scene-scale-final-lint-v2.log',
    '.cache/capture-scene-scale-progress-v2.py', '.cache/publish-scene-scale-setup-v1.py']]
for root in scene_roots:
    scene_extras.append(root / 'preflight/result.json')
scene_extras.extend([scene_roots[0] / 'manifest-train.jsonl', scene_roots[0] / 'manifest-development.jsonl',
                     scale / '01-context-none.log', scale / '01-context-none-result.json',
                     scale / 'production-handoff-plan-v2.json', scale / 'production-handoff-v2-launch.json',
                     scale / 'publication-progress-capture-v2.json'])
publish('whole-scene-context-training-setup-v1', scene_roots, scene_extras,
        scope='Integrated scene data/model engineering qualification. Original RGB-only and corrected canonical-mosaic preflights are separate; no production context update preceded the correction. Three actual two-update optimizer/roundtrip checks passed in each version. Production starts untouched parent; no trained quality score. Snapshot of the running allocation, not completion.19 focused tests; fixed native scene/crop lineage, noisy-input context only. Protected families excluded.')

scale_roots = [experiments / f'full-corpus-scaling-v{i}' for i in [1, 2, 3]]
scale_extras = [repo / p for p in [
    'scripts/profile_full_corpus_training.py', 'scripts/run_full_corpus_continuation.py',
    '.cache/prepare-large-corpus-recipes-v1.py', '.cache/prepare-full-corpus-profile-plan-v1.py',
    '.cache/prepare-full-corpus-profile-plan-v2.py', '.cache/prepare-full-corpus-profile-plan-v3.py',
    '.cache/full-corpus-profile-controller-v1.py', '.cache/launch-full-corpus-profiles-v1.py',
    '.cache/prepare-full-corpus-production-v1.py', '.cache/full-corpus-and-context-controller-v1.py',
    '.cache/full-corpus-and-context-controller-v2.py', '.cache/capture-scene-scale-progress-v2.py',
    '.cache/publish-scene-scale-setup-v1.py', '.cache/scene-scale-final-lint-v2.log']]
for family in ['order20k', 'order100k']:
    scale_extras.extend(p for p in (scale_roots[0] / family).iterdir() if p.is_file())
for mode in ['strict0', 'fast0', 'fast2']:
    scale_extras.append(scale / 'profiles' / mode / 'result.json')
for script in ['run_full_corpus_continuation.py', 'run_full_corpus_continuation_v2.py']:
    scale_extras.append(scale / 'work/scripts' / script)
for rel in ['work/artifacts/train/operator-check/phase-000001-000006',
            'work/artifacts/train/operator-check/phase-000007-000008',
            'work/artifacts/train/long100k/phase-000001-001000']:
    scale_extras.extend(p for p in (scale / rel).iterdir() if p.is_file() and p.suffix != '.pt')
# Bind the actual cleaned source list, reviewed quota configuration and domains.
config = yaml.safe_load((scale / 'long100k-production.yaml').read_text())
for key in ['manifest', 'photo_sampling_reference_manifest', 'low_contrast_rois',
            'raw_clean_manifest', 'paired_manifest']:
    value = config.get(key)
    if value:
        path = Path(value)
        if path.is_file():
            scale_extras.append(path)
publish('full-corpus-training-setup-v1', scale_roots, scale_extras,
        scope='First1000 of the declared100k trajectory complete, not a completed100k endpoint. Exact failed setup admissions, three actual75+2 profiles, discarded6+2 logger receipts, immutable first1000 phase records, precomputed20k/100k source-order payloads and remaining allocation. Original controller stopped before context construction; corrected remaining allocation does not replay1000 or reset its schedule. No comparable427/camera score or actual new native image review yet. No promoted recommendation or inference-speed claim.')
