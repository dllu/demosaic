"""Compare wide Bayer frequency nominations under the same held-center gate."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import wide_phase as operator
import evaluate_routing as previous
import score_wire_gate as scoring
import review_wire_gate as review

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
NARROW = previous.OUT
METHODS = ("wide", "directional", "wide exterior")
LABELS = previous.LABELS | {
    "wide": "Wide frequency",
    "directional": "Wide harmonic-aware",
    "wide exterior": "Wide without local check",
    "narrow": "Earlier 64px phase",
}
ORDER = ("nominal", "router", "parent phase", "shared", "direct", "narrow", *METHODS)


def models():
    _, nets = previous.models()
    locked = reference(NARROW / "score-calibration.json")
    nets["narrow"] = read_json(checked(locked))["policy"]["arms"]["directional"]["locked"]["dose"]
    return reference(OUT / "plan.json"), nets


def prepare(row, d, p, nets):
    known, old = previous.prepare(row, d, p, nets)
    nominal = known["nominal"]
    known["narrow"] = (nominal + nets["narrow"] * old["directional"]).astype(nominal.dtype)
    waves, neutral, _ = operator.fields(d, p, row["profile"])
    waves["directional"] = waves.pop("harmonic")
    return known, {k: v[:, None] * neutral[None, :, None, None] for k, v in waves.items()}


def stage():
    limits = scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": previous.prior.CONTINUING_LIMIT}
    paths = {
        "calibration": NARROW / "calibration",
        "prior-held": NARROW / "held",
        "held": OUT / "confirmation/held",
    }
    for k, src in paths.items():
        alias = OUT / k
        if not alias.exists() and not alias.is_symlink():
            alias.symlink_to(src, target_is_directory=True)
        assert alias.resolve() == src.resolve()
    plan = OUT / "plan.json"
    if not plan.exists():
        write_json(plan, {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(operator.__file__)),
            "local_operator": reference(Path(operator.local.__file__)),
            "capture_selection": reference(OUT / "confirmation/plan.json"),
            "narrow_calibration": reference(NARROW / "score-calibration.json"),
            "narrow_plan": reference(NARROW / "plan.json"),
            "calibration": reference(paths["calibration"] / "completed.json"),
            "replay": reference(paths["prior-held"] / "completed.json"),
            "inherited_scorer": reference(Path(scoring.__file__)),
            "inherited_reviewer": reference(Path(review.__file__)),
            "limits": limits,
            "methods": METHODS,
            "scope": "Fit strengths on the frozen 44-source calibration. Score once on the new 56-source confirmation. Keep the prior confirmation as a development replay.",
        })
    return limits


def run(mode):
    limits = stage()
    with ExitStack() as context:
        for mod, attr, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepare),
            (scoring, "WIRE_LIMITS", limits),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepare),
            (review, "ORDER", ORDER),
            (review, "DISPLAY", review.DISPLAY | LABELS),
        ):
            context.enter_context(patch.object(mod, attr, value))
        if mode == "review":
            review.run()
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
