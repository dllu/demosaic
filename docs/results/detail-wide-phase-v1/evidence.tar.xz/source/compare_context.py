"""Measure the wide nomination's contribution with the recipient RAW held fixed."""

from pathlib import Path
from time import monotonic
from unittest.mock import patch

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_wide import OUT, METHODS, scoring, operator

METRICS = (
    "weak_response_pp", "intact_increment_RMS_DN16", "gap_weak_RMS_DN16",
    "gap_continuing_strong_RMS_DN16", "exterior_only_weak_RMS_DN16",
    "exact_flat_RMS_DN16",
)
SHIFT = 11


def held_terms(source):
    _, factory = scoring.wire_scorer()
    votes = []
    for case, d, p, binding in scoring.loads(source):
        if case["kind"] == "wire":
            selected = operator.nominate(d, case["profile"])["harmonic"]
            votes.append((case["id"], selected))
    rows = []
    for case, d, p, binding in scoring.loads(source):
        if case["kind"] != "wire":
            continue
        i = len(rows)
        actual, proposal = votes[(i + SHIFT) % len(votes)]
        with patch.object(operator.local, "discover", operator.inject(proposal)):
            m, neutral, _ = operator.local.fields(d, p, case["profile"])
        geom = case["fixture"]["geometry"]
        if geom["family"] not in ("strip", "ellipse"):
            d = d | {"support": np.ones_like(d["support"])}
        scorer = factory(d, geom)
        delta = m["directional"][:, None] * neutral[None, :, None, None]
        rows.append({
            "id": case["id"], "different_donor_id": actual, "proof": binding,
            "terms": scoring.polynomial(scorer, p["nominal"], {"directional": delta}),
        })
    return rows


def evaluate():
    start = monotonic()
    result = reference(OUT / "score-held.json")
    data = read_json(checked(result))
    source = reference(OUT / "confirmation/held/completed.json")
    actual = [r for r in data["rows"] if r["kind"] == "wire"]
    different = held_terms(source)
    assert [r["id"] for r in actual] == [r["id"] for r in different]
    doses = {k: v["locked"]["dose"] for k, v in data["policy"]["arms"].items()}
    rng = np.random.default_rng(202611201519)
    stats = {}
    with patch.object(scoring, "METHODS", METHODS):
        score = lambda rows, method, metric, dose: scoring.wire_values(rows, method, metric, dose)
        for m in METRICS:
            nominal = score(actual, "nominal", m, 0)
            shared = score(actual, "shared", m, 0)
            narrow = score(actual, "narrow", m, 0)
            wide = score(actual, "wide", m, doses["wide"])
            harmonic = score(actual, "directional", m, doses["directional"])
            wrong = score(different, "directional", m, doses["directional"])
            rolled = score(actual, "rolled directional", m, doses["directional"])
            output = {
                "borrowed minus nominal": wrong - nominal,
                "matched minus borrowed": harmonic - wrong,
                "matched minus shifted witness": harmonic - rolled,
                "matched minus narrow": harmonic - narrow,
                "matched minus shared": harmonic - shared,
                "matched minus plain wide": harmonic - wide,
            }
            stats[m] = {}
            for name, diff in output.items():
                ix = rng.integers(len(diff), size=(12000, len(diff)))
                stats[m][name] = [float(diff.mean()), *np.quantile(diff[ix].mean(1), (0.025, 0.975)).tolist()]
    print(stats, flush=True)
    write_json(OUT / "context-control.json", {
        "driver": reference(Path(__file__)), "collection": source, "score": result, "doses": doses,
        "rows": different, "summary": stats, "seconds": monotonic() - start,
        "scope": "Post-score hypothesis intervention. Each wire draws the four quadrant hypotheses from a different wire with role held fixed. The original RAW still fits all local amplitudes, phases and checks.",
        "shift": SHIFT,
    })


if __name__ == "__main__":
    evaluate()
