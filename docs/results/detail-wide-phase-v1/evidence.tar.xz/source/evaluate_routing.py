"""Replay phase-gated weak correction against the existing locked gain heads."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import numpy as np

from phase_route import fields

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR_OUT = OUT.with_name("detail-shared-oracle-v1")
sys.path = [s for s in sys.path if Path(s).resolve() != HERE]
sys.path.insert(0, str(HERE.with_name("detail-shared-oracle-v1")))
import evaluate_shared as prior
import score_wire_gate as scoring
import review_wire_gate as review

METHODS = ("exterior", "directional")
LABELS = {
    "exterior": "Exterior phase alone",
    "directional": "Held local phase",
    "shared": "Calibrated shared head",
    "direct": "Calibrated direct head",
}
ORDER = ("nominal", "router", "parent phase", "shared", "direct", *METHODS)


def models():
    _, nets = prior.models()
    bound = reference(PRIOR_OUT / "score-calibration.json")
    data = read_json(checked(bound))
    nets["previous_dose"] = {k: d["locked"]["dose"] for k, d in data["policy"]["arms"].items()}
    return reference(OUT / "plan.json"), nets


def prepare(row, data, p, nets):
    known, old = prior.ORIGINAL_PREPARE(row, data, p, nets)
    nominal = known["nominal"]
    known.update({
        target: (nominal + nets["previous_dose"][key] * old[key]).astype(nominal.dtype)
        for key, target in (("continuation", "direct"), ("directional", "shared"))
    })
    moves, neutral, _ = fields(data, p, row["profile"])
    return known, {k: v[:, None] * neutral[None, :, None, None] for k, v in moves.items()}


def stage():
    arms = scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": prior.CONTINUING_LIMIT}
    sources = {
        "calibration": PRIOR_OUT / "calibration",
        "prior-held": PRIOR_OUT / "held",
        "held": OUT / "confirmation/held",
    }
    for name, source in sources.items():
        alias = OUT / name
        if not alias.exists():
            alias.symlink_to(source, target_is_directory=True)
        assert alias.resolve() == source.resolve()
    path = OUT / "plan.json"
    if not path.exists():
        write_json(path, {
            "driver": reference(Path(__file__)),
            "operator": reference(HERE / "phase_route.py"),
            "capture_selection": reference(OUT / "confirmation/plan.json"),
            "parent_locks": reference(PRIOR_OUT / "score-calibration.json"),
            "parent_fit": reference(PRIOR_OUT / "fit-training/result.json"),
            "inherited_scorer": reference(Path(scoring.__file__)),
            "inherited_reviewer": reference(Path(review.__file__)),
            "methods": METHODS,
            "limits": arms,
            "diagnostic_control": "Roll the bounded held-witness map by two stations along both axes.",
            "scope": "Calibrate on the same 24 wire and 20 natural sources, compare once on new confirmation sources.",
        })
    return arms


def run(mode):
    arms = stage()
    with ExitStack() as scope:
        for obj, attr, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepare),
            (scoring, "WIRE_LIMITS", arms),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepare),
            (review, "ORDER", ORDER),
            (review, "DISPLAY", review.DISPLAY | LABELS),
        ):
            scope.enter_context(patch.object(obj, attr, value))
        if mode == "review":
            review.run()
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
