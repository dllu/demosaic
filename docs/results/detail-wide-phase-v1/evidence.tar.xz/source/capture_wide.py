"""Capture fresh independent sources for the broad versus local phase test."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PROTECTED = ("detail-shared-oracle-v1", "detail-phase-routing-v1")
SEED = 202611201516
spec = spec_from_file_location("prior_capture_design", HERE.with_name(PROTECTED[0]) / "confirm_capture.py")
prior = module_from_spec(spec)
spec.loader.exec_module(prior)


def select():
    seen = set()
    refs = {}
    identities = prior.c.identities
    for folder in PROTECTED:
        file = OUT.with_name(folder) / "confirmation/plan.json"
        refs[folder] = reference(file)
        for group in read_json(checked(refs[folder]))["groups"].values():
            seen |= identities(r["source"] for r in group)
    with (
        patch.object(prior, "SEED", SEED),
        patch.object(prior.c, "identities", lambda sources: identities(sources) | seen),
    ):
        plan = prior.select()
    chosen = identities(r["source"] for r in plan["groups"]["held"])
    assert len(chosen) == 112 and chosen.isdisjoint(seen)
    return plan | {"followup_driver": reference(Path(__file__)), "prior_confirmations": refs}


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    if not (plan := folder / "plan.json").exists():
        write_json(plan, select())
    with patch.object(prior.c, "OUT", folder), patch.object(prior.c, "SEED", SEED):
        prior.c.collect("held")
