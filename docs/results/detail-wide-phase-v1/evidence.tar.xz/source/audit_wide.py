"""Verify source separation and measure narrow and wide frequency nomination."""

import json
from pathlib import Path
import sys
from time import monotonic

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_wide import HERE, OUT, scoring, operator
from collect_wire_gate import identities

sys.path.insert(0, str(HERE.with_name("direct-detail-response-v1")))
from audit_sources import CORPUS, LOCAL, matches

TOLERANCE = 0.0234375
INTERIOR = np.s_[..., 2:6, 2:6]


def source_audit():
    selection = reference(OUT / "confirmation/plan.json")
    plan = read_json(checked(selection))
    ids = identities(r["source"] for r in plan["groups"]["held"])
    assert len(ids) == 112
    used = plan["prior_confirmations"] | {"original": plan["previous_plan"]}
    for prev in used.values():
        data = read_json(checked(prev))["groups"]
        assert all(ids.isdisjoint(identities(r["source"] for r in z)) for z in data.values())
    assert ids.isdisjoint(identities(read_json(checked(plan["fixed427"]))["source_metadata"]))
    with checked(plan["training_manifest"]).open() as f:
        assert ids.isdisjoint(identities(map(json.loads, f)))
    corpus, local = reference(CORPUS), reference(LOCAL)
    history, terminal = read_json(checked(corpus)), read_json(checked(local))
    assert history["checkpoint"] == terminal["parent"] and terminal["checkpoint"] == plan["parent"]
    count = 0
    for s in history["source_traces"]:
        with checked(s).open() as f:
            for row in map(json.loads, f):
                for x in row["sources"]:
                    if x["kind"] == "photographic":
                        assert not matches(x, ids)
                        count += 1
    last = 0
    for s in terminal["segments"]:
        with checked(s["observations"]).open() as f:
            for row in map(json.loads, f):
                assert not matches(row, ids)
                last += 1
    assert (count, last) == (559808, 5000)
    return {"selection": selection, "corpus": corpus, "local": local,
            "blocked_prior_confirmation": used, "sources": len(ids)//2,
            "corpus_visits": count, "local_visits": last}


def tally(result, geometry, support):
    strong, weak = np.asarray(geometry["frequency"])[:, ::-1]
    active = result["active"][INTERIOR]
    check = (result["local"] > 0)[INTERIOR]
    f = result["phase"][:, 2:6, 2:6]
    angle_error = lambda v: np.minimum(np.linalg.norm(f - v, axis=-1), np.linalg.norm(f + v, axis=-1))
    weak_peak = angle_error(weak) <= TOLERANCE
    strong_peak = np.logical_or.reduce([angle_error(k * strong) <= TOLERANCE for k in (1, 2, 3)])
    exact_gap = (support == 0).reshape(8, 32, 8, 32).mean((1, 3))[INTERIOR] >= 0.25
    intact = (support >= 0.97).reshape(8, 32, 8, 32).mean((1, 3))[INTERIOR] >= 0.85
    if geometry["family"] not in ("strip", "ellipse"):
        exact_gap[:] = False
        intact[:] = True
    all_ = np.ones_like(intact)
    totals = {}
    for label, role, domain in (
        ("intact", 0, intact), ("gap", 0, exact_gap), ("exterior only", 1, exact_gap),
        ("strong only", 2, all_), ("flat", 3, all_),
    ):
        admitted = domain & active[role]
        accepted = admitted & check[role]
        totals[label] = {
            "stations": int(domain.sum()),
            "nominated": int(admitted.sum()),
            "accepted": int(accepted.sum()),
            "weak nominated": int((admitted & weak_peak[role]).sum()),
            "weak accepted": int((accepted & weak_peak[role]).sum()),
            "strong or harmonic nominated": int((admitted & strong_peak[role]).sum()),
        }
    return totals


if __name__ == "__main__":
    now = monotonic()
    proof = reference(OUT / "confirmation/held/completed.json")
    seen = source_audit()
    rows = []
    for case, d, p, binding in scoring.loads(proof):
        if case["kind"] != "wire":
            continue
        _, _, local = operator.local.fields(d, p, case["profile"])
        _, _, wide = operator.fields(d, p, case["profile"])
        tallies = {k: tally(value, case["fixture"]["geometry"], d["support"])
                   for k, value in ({"local": local} | wide).items()}
        rows.append({"id": case["id"], "input": binding, "tallies": tallies})
    summary = {arm: {group: {metric: sum(r["tallies"][arm][group][metric] for r in rows)
                              for metric in vals}
                        for group, vals in groups.items()}
               for arm, groups in rows[0]["tallies"].items()}
    print(summary, flush=True)
    write_json(OUT / "audit.json", {
        "driver": reference(Path(__file__)), "operator": reference(Path(operator.__file__)),
        "collection": proof, "source_audit": seen, "rows": rows, "summary": summary,
        "seconds": monotonic() - now, "frequency_tolerance_cycles_per_px": TOLERANCE,
    })
