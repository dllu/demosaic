"""Close the native quality review and compare outputs with the matched joint support."""
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


ROOT = Path(".cache/experiments")
PILOT = ROOT / "neural-nuisance-parent-innovation129-pilot-v1"
COLOUR = ROOT / "coloured-parent-innovation129-v1"
OUT = ROOT / "parent-innovation-native-review-v1"
METHODS = ("conditional-local-t2", "local-t2")


def collection(path):
    receipt = read_json(path)
    assert len(receipt["rows"]) == 48
    return {v["id"]: v for v in receipt["rows"]}


def pair_inputs(new, old):
    for key in ("parent_values", "packed_values", "colors_values", "effective_geometry_config"):
        assert new[key] == old[key], (new["id"], key)


def values(case, method):
    return np.load(checked(case["predictions"][method]), mmap_mode="r")


def compare_images(new, old):
    delta = (new.astype(np.float64) - old) * 65535
    return {
        "change_rms_DN16": float(np.sqrt(np.mean(delta**2))),
        "change_max_DN16": float(np.max(np.abs(delta))),
        "changed_channels": int(np.count_nonzero(delta)),
        "channels": delta.size,
    }


def render_panel(board, panel):
    x, y, w, h = panel["xywh"]
    assert (w, h) == (160, 160)
    with Image.open(checked(board["image"])) as rendered:
        return np.asarray(rendered.crop((x, y, x + w, y + h)))


def main():
    old_pilot = Path(checked(read_json(PILOT / "study.json")["baseline"])).parent
    old_colour = Path(checked(read_json(COLOUR / "study.json")["baseline"])).parent
    new_receipts = [p / "collection.json" for p in (PILOT, COLOUR)]
    old_receipts = [p / "collection.json" for p in (old_pilot, old_colour)]
    compare = {}
    for arm, newer, older in zip(("pilot", "coloured"), new_receipts, old_receipts, strict=True):
        new, old = collection(newer), collection(older)
        assert new.keys() == old.keys()
        result = []
        for key in new:
            pair_inputs(new[key], old[key])
            for method in METHODS:
                after, before = [values(x[key], method) for x in (new, old)]
                result.append(
                    {"case": key, "method": method, **compare_images(after, before)}
                )
        compare[arm] = result

    new_native = read_json(PILOT / "native/report.json")
    old_native = read_json(old_pilot / "native/report.json")
    established = {Path(r["image"]["path"]).name: r for r in old_native["figures"]}
    plan = read_json(PILOT / "plan.json")
    declared = {v["id"]: v for v in plan["rows"]}
    real = []
    for board in new_native["figures"]:
        key = board["case_id"]
        if not key.startswith(("main-", "mesh-")):
            continue
        earlier = established[Path(board["image"]["path"]).name]
        for field in ("ROI_xywh", "reference_ROI_xywh", "display_exposure", "display_contrast", "wb", "matrix", "noise_conditioning"):
            assert board[field] == earlier[field], (key, field)
        roi = board["ROI_xywh"]
        x, y, w, h = roi
        assert (w, h) == (160, 160)
        new_panels, prior_panels = board["panels"], earlier["panels"]
        retained = set(range(len(new_panels))) - {2, 3}
        for i in retained:
            np.testing.assert_array_equal(render_panel(board, new_panels[i]), render_panel(earlier, prior_panels[i]))

        a, b = collection(new_receipts[0])[key], collection(old_receipts[0])[key]
        with Image.open(checked(board["image"])) as im:
            assert im.height == 192
        ref = declared[key]["parent"]
        base = np.load(checked(ref), mmap_mode="r")[..., y:y+h, x:x+w]
        observation = {
            "board": board["image"], "previous_board": earlier["image"], "case": key,
            "roi": roi, "retained_panels_checked": len(retained), "methods": {},
        }
        for m, i in zip(METHODS, (2, 3), strict=True):
            after, before = [values(c, m)[..., y:y+h, x:x+w] for c in (a, b)]
            assert base.shape == after.shape == before.shape
            raster_after, raster_before = [
                render_panel(item, item["panels"][i]) for item in (board, earlier)
            ]
            observation["methods"][m] = {
                "against_prior": compare_images(after, before),
                "against_parent": compare_images(after, base),
                "changed_display_channels_from_prior": int(np.count_nonzero(raster_after != raster_before)),
            }
        real.append(observation)
    assert len(real) == 8

    colour = read_json(COLOUR / "scores-v1.json")
    changes = {}
    for r in colour["means"]:
        changes.setdefault((r["profile"], r["source"]), {})[r["method"]] = r
    metrics = []
    for (profile, source), group in changes.items():
        for method in METHODS:
            keys = ("weak_gain", "strong_gain", "weak_increment_error_RMS_DN16",
                    "weak_colour_orthogonal_RMS_DN16", "quiet_error_RMS_DN16",
                    "full_error_RMS_DN16", "edge_error_RMS_DN16")
            metrics.append({
                "profile": profile, "source": source, "method": method,
                "values": {
                    arm: {k: group[variant][k] for k in keys}
                    for arm, variant in (
                       ("V120", "V120"), ("joint", f"prior-joint::{method}"),
                       ("innovation", f"innovation::{method}"),
                    )
                },
            })
    write_json(
        OUT / "comparison.json",
        {
            "driver": reference(__file__),
            "new_collection": [reference(x) for x in new_receipts],
            "old_collection": [reference(x) for x in old_receipts],
            "native": [reference(PILOT / "native/report.json"), reference(old_pilot / "native/report.json")],
            "paired_fields": compare, "real": real, "coloured_metrics": metrics,
            "real_meaning": "Delivered method versus matched method/parent. Neither comparison is a reference error.",
        },
    )
    for cohort, records in compare.items():
        print(cohort, len(records), sum(r["changed_channels"] == 0 for r in records),
              max(r["change_rms_DN16"] for r in records))
    for r in real:
        print(Path(r["board"]["path"]).name, [
            (m, round(v["against_prior"]["change_rms_DN16"], 5),
             round(v["against_parent"]["change_rms_DN16"], 5),
             v["changed_display_channels_from_prior"])
            for m,v in r["methods"].items()
        ])


if __name__ == "__main__":
    main()
