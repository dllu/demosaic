"""Show both validation choices on the exact standing camera coordinates."""
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/parent-innovation-native-review-v1")


def create():
    report = read_json(ROOT / "comparison.json")
    output = ROOT / "paired-real"
    output.mkdir()
    result = []
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
    for entry in report["real"]:
        a, b = [Image.open(checked(entry[k])).convert("RGB")
                for k in ("previous_board", "board")]
        labels = ("V120 EMA", "Prior joint analytic", "Innovation analytic",
                  "Prior joint neural", "Innovation neural", "ISO100 AHD ref")
        sources = ((b, 1), (a, 2), (b, 2), (a, 3), (b, 3), (b, 4))
        board = Image.new("RGB", (len(labels) * 168 + 8, 192), "#eeeeee")
        draw = ImageDraw.Draw(board)
        panels = []
        for j, ((origin, i), label) in enumerate(zip(sources, labels, strict=True)):
            x, tx = 8 + i * 168, 8 + j * 168
            crop = origin.crop((x, 24, x + 160, 184))
            board.paste(crop, (tx, 24))
            draw.text((tx, 5), label, font=font, fill="black")
            panels.append((label, (tx, 24, 160, 160), crop))
        file = output / Path(entry["board"]["path"]).name.replace("-comparison.png", "-paired.png")
        board.save(file)
        with Image.open(file) as pixels:
            for _, (x, y, w, h), crop in panels:
                np.testing.assert_array_equal(pixels.crop((x,y,x+w,y+h)), crop)
        result.append({
            "image": reference(file), "source_boards": [entry["board"], entry["previous_board"]],
            "ROI_xywh": entry["roi"],
            "panels": [{"label": label, "xywh": xywh} for label,xywh,_ in panels],
        })
    write_json(ROOT / "paired-real.json", {"driver": reference(__file__), "figures": result})
    for k, bundle in enumerate((result[:4], result[4:])):
        sheet = Image.new("RGB", (1016, 768))
        for i, entry in enumerate(bundle):
            with Image.open(checked(entry["image"])) as photo:
                sheet.paste(photo, (0, 192*i))
        sheet.save(ROOT / f"paired-real-{k}.png")


if __name__ == "__main__":
    create()
