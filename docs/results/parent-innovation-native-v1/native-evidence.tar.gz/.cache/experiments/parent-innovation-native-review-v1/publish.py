"""Publish immutable native boards and the matched saved-output comparison."""
from datetime import datetime
from pathlib import Path
from shutil import copyfile
import tarfile
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

CACHE = Path(".cache/experiments")
ROOT = CACHE / "parent-innovation-native-review-v1"
PILOT = CACHE / "neural-nuisance-parent-innovation129-pilot-v1"
COLOUR = CACHE / "coloured-parent-innovation129-v1"
IMAGES = Path("docs/images/parent-innovation-native-v1")
RESULTS = Path("docs/results/parent-innovation-native-v1")

NOTES = {
    "pilot-0": "ISO6400 retains smooth edge/background with weaker strands missing.",
    "pilot-1": "ISO1600 panels vary primarily in broad diagonals and still miss the thin crossings.",
    "pilot-2": "ISO400 far recovers some diagonal shading already present with the prior gate; edges and weak crossings remain incomplete.",
    "pilot-3": "Bark and fur are close to V120, sky smooth, subtle foliage shifts, coarse fence retains diamonds. Main building has less analytic color fringing than prior joint.",
    "pilot-4": "Left favors one diagonal family, right displays a soft periodic lattice. Neither noise profile gives reliably sharp fine crossings. Both JPEG references visible.",
    "pilot-5": "Exhaustive correction stress crops show residual building color and broad cab modulation. Sky is smooth.",
    "colour-0": "ISO1600 neutral shows thicker diagonal traces than V120. Thin crossings remain blurred with both gates.",
    "colour-1": "ISO6400 mostly retains broad features; ISO1600 BGGR shows modest directional recovery close to prior joint.",
    "colour-2": "ISO6400 changes are soft and sometimes irregular; ISO1600 faint diagonals do not reach the exact target.",
    "colour-3": "GRBG/GBRG outputs keep the broad structure, with softer finer crossing traces at ISO1600.",
    "colour-4": "Signed-color RGGB shows new diagonal modulation over V120, with differences between gates small and exact signed structure still missing.",
    "colour-5": "Signed ISO6400 retains coarse patterns. More directional modulation at ISO1600, much softer than exact GT.",
    "colour-6": "BGGR/GRBG ISO6400 remains broad; GRBG ISO1600 has stronger streaks and incomplete crossings.",
    "colour-7": "GBRG ISO1600 shows a stronger diagonal but incomplete fine recovery; ISO6400 is mostly broad texture.",
    "paired-real-0": "Sky exactly smooth. Analytic building fringe near the lines drops markedly; neural changes are smaller. Foliage soft, coarse lattice retained.",
    "paired-real-1": "Matched gates both show softened repetitive patterns, with only small amplitude changes on both sides and profiles.",
}


def main():
    IMAGES.mkdir()
    RESULTS.mkdir()
    contact = read_json(ROOT / "inspection-sheets.json")
    paired = read_json(ROOT / "paired-real.json")["figures"]
    contact["paired-real-0"] = [v["image"] for v in paired[:4]]
    contact["paired-real-1"] = [v["image"] for v in paired[4:]]
    ordered = []
    for key, children in contact.items():
        items = []
        for child in children:
            source = checked(child)
            dest = IMAGES / source.name
            assert not dest.exists()
            copyfile(source, dest)
            pub = reference(dest)
            assert child["sha256"] == pub["sha256"]
            items.append({"archived": child, "published": pub})
        ordered.append({"sheet": key, "observation": NOTES[key], "boards": items})
    assert len(ordered) == len(NOTES) and sum(len(v["boards"]) for v in ordered) == 76
    write_json(
        IMAGES / "manifest.json",
        {"viewed_at": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(), "groups": ordered,
         "scope": "68 previously rendered and eight additional matched native boards. Sheets stack boards without resizing any pixel."},
    )
    artifacts = [
        ROOT / name for name in (
            "compare.py", "compare-v2.py", "comparison.json", "paired-real.json", "publish.py",
            "real_boards.py", "inspection-sheets.json",
        )
    ]
    artifacts.extend(
        [PILOT / n for n in ("native/report.json", "report/report.json", "summary-review/summary.json",
                              "independent-audit.json", "quality-review-result.json")]
        + [COLOUR / n for n in ("native/report.json", "independent-audit-v1.json", "scores-v1.json")]
    )
    archive = RESULTS / "native-evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as bundle:
        for item in artifacts:
            bundle.add(item, arcname=item)
    for name in ("comparison.json", "paired-real.json"):
        copyfile(ROOT / name, RESULTS / name)
    write_json(
        RESULTS / "publication.json",
        {
            "archive": reference(archive), "members": [reference(p) for p in artifacts],
            "manifest": reference(IMAGES / "manifest.json"),
            "prior_preserved": reference("docs/results/parent-innovation-completed-pre-review-v1/publication.json"),
            "reviewed_native_boards": 76,
            "scope": "Training unchanged. Both matched numerical pilots and the complete intended native viewing are now closed.",
        },
    )


if __name__ == "__main__":
    main()
