"""Inspect luma-only versus full-color lifts on the same selected native crops."""

from pathlib import Path

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from probe import PRIOR, ROOT
from report_scene_wave_guides import native_board


def render():
    target=ROOT/"chroma-native"
    target.mkdir()
    selected=read_json(ROOT/"composition-native/viewing.json")["boards"]
    receipt=reference(ROOT/"chroma-results.json")
    results=read_json(checked(receipt))
    matches={row["original"]["path"].split("/")[-1].removesuffix(".json"):row for row in results["rows"]}
    spec=read_json(PRIOR/"evaluation-plan.json")
    boards=[]
    for sample in selected:
        identifier, suffix=sample["id"].rsplit("-role",1)
        row=matches[identifier]
        role=int(suffix)
        original=read_json(checked(row["original"]))
        with np.load(checked(original["input"]),allow_pickle=False)as data:
            inputs={k:data[k][role:role+1]if k in ("packed","variance")else data[k][None]
                    for k in ("packed","variance","colors","wb","matrix")}
            truth=data["target"][role]
        with np.load(checked(row["prediction"]),allow_pickle=False)as data:
            parent=data["100k"][role]
        if row["chroma_render"] is None:
            repaired=[parent]*3
        else:
            with np.load(checked(row["chroma_render"]),allow_pickle=False)as data:
                repaired=[data[k][role]for k in ("1.0","0.25","0.0")]
        metadata={k:sample[k]for k in ("parent","source","profile","CFA","query_box","draw","role","selection")}
        boards.append(native_board(target,sample["id"],[noisy_malvar(inputs)[0],parent,*repaired,truth],
                    inputs,metadata|{"chroma_result":receipt},
                    labels=("Noisy Malvar","Corpus 100k","Full RGB lift","25% chroma","Luma-only lift","Exact GT"),
                    triplet_indices=(0,4,5),contrast=2,exposure=1/original["profile"]["exposure"],
                    roi=tuple(spec["native_display_ROI_xywh"])))
    write_json(target/"viewing.json",{"source":receipt,"driver":reference(__file__),"boards":boards})


if __name__=="__main__":
    render()
