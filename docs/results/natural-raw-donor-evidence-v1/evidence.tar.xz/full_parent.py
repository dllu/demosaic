"""Collect exact Corpus 100k EMA predictions across the complete donor panel."""

import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from probe import PLAN, PRIOR, ROOT

sys.path.insert(0,str(PRIOR))
from evaluate import ARGS, setup_models

PARENT_PLAN=ROOT/"full-parent-plan.json"
PREDICTIONS=ROOT/"full-parent-predictions"


def freeze():
    pilot=PRIOR/"pilot/plan.json"
    model=read_json(pilot)["models"]["100k"]
    write_json(PARENT_PLAN,{
        "driver":reference(__file__),"experiment":reference(PLAN),
        "completed_sensor_summary":reference(ROOT/"summary.json"),
        "model":model,"previous_plan":reference(pilot),
        "reuse":reference(PRIOR/"pilot/collected.json"),
        "precision":"CUDA IEEE FP32 channels last, B3 matched to prior natural panel",
    })


@torch.inference_mode()
def collect():
    os.sched_setaffinity(0,[17,18])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,4.5*2**30/torch.cuda.get_device_properties(0).total_memory))
    parent=read_json(PARENT_PLAN)
    assert checked(parent["driver"])==Path(__file__)
    test=read_json(checked(parent["experiment"]))
    previous=read_json(checked(parent["reuse"]))
    assert previous["plan"]==parent["previous_plan"]
    inherited={}
    for record in previous["records"]:
        old=read_json(checked(record))
        inherited[old["case"]["sha256"]]=old
    model=setup_models({"models":{"100k":parent["model"]}})["100k"]
    PREDICTIONS.mkdir()
    results=[]
    began=time.monotonic()
    with ieee_fp32():
        for source in test["photo_receipts"]:
            spec=read_json(checked(source))
            sensor=spec["profile"]
            if source["sha256"] in inherited:
                known=inherited[source["sha256"]]
                assert known["case"]==source
                assert all(known["exact_query_inputs"][k]==spec["fingerprints"][k] for k in ARGS)
                prediction=known["saved"]
                field="100k"
            else:
                with np.load(checked(spec["input"]),allow_pickle=False)as store:
                    values={key:store[key]for key in ARGS}
                assert all(fingerprint(values[k])==spec["fingerprints"][k]for k in ARGS)
                raw={k:torch.from_numpy(v).cuda()for k,v in values.items()}
                query=[raw[k] if k in ("packed","variance") else raw[k][None].expand(3,*raw[k].shape)
                       for k in ARGS]
                for k in range(2):
                    query[k]=query[k].contiguous(memory_format=torch.channels_last)
                model.set_noise(sensor["shot"],sensor["read"])
                rgb=model(*query).cpu().numpy()
                assert rgb.shape==(3,3,256,256) and rgb.dtype==np.float32 and np.isfinite(rgb).all()
                path=PREDICTIONS/(spec["id"]+".npy")
                with path.open("xb")as output:
                    np.save(output,rgb,allow_pickle=False)
                prediction=reference(path)
                field=None
            results.append({"id":spec["id"],"source":source,"rgb":prediction,
                            "npz_field":field,"exact_query":{k:spec["fingerprints"][k] for k in ARGS}})
            if len(results)%16==0:
                print(len(results),round(time.monotonic()-began,2),flush=True)
    assert len(results)==256 and sum(v["npz_field"] is not None for v in results)==32
    write_json(ROOT/"full-parent.json",{"plan":reference(PARENT_PLAN),"records":results,
                    "seconds_wall":time.monotonic()-began,"recorded_inherited":32,"new_forwards":224})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else collect()
