"""Audit the fitting split and both per-block nuisance projections."""

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from probe import BLOCK, DESIGN, NUISANCES, PLAN, REGION, ROOT, SIZE, SPLIT, donor_candidates, filtered, measurements, scores, unpack


def verify():
    plan=read_json(PLAN)
    scopes={}
    layout_cases={}
    for entry in plan["photo_receipts"]:
        case=read_json(checked(entry))
        if case["draw"]!="coupled" or case["profile"]["name"]!="iso6400":
            continue
        with np.load(checked(case["input"]),allow_pickle=False) as store:
            colors=store["colors"]
            key=tuple(int(c)for c in colors)
            if key in layout_cases:
                continue
            query=unpack(store["packed"][0])
            donor,_=donor_candidates(store["scene_packed"],case["box"])["registered"]
            levels=filtered(donor)
        layout_cases[key]=case["id"]
        for kind in NUISANCES:
            original=measurements(query,levels,colors,case["profile"],kind=="donor-coarse")
            ref=scores(original)
            new=query.copy()
            pattern=np.tile(SPLIT,(SIZE//BLOCK,SIZE//BLOCK))
            new[REGION] += .45*(levels[0]-levels[1])[REGION]*(~pattern)
            after=measurements(new,levels,colors,case["profile"],kind=="donor-coarse")
            got=scores(after)
            assert ref["fits"][0]["discovery_coeff"]==got["fits"][0]["discovery_coeff"]
            assert ref["fits"][0]["held_z"]!=got["fits"][0]["held_z"]
            for old,newest in zip(original[0],after[0],strict=True):
                np.testing.assert_array_equal(newest["shape"],old["shape"])
                np.testing.assert_array_equal(newest["discover_noise"],old["discover_noise"])
                np.testing.assert_array_equal(newest["obs"],old["obs"])
                component=np.einsum("nkd,nk->nd",old["basis"],old["shape"])
                assert np.max(abs(component))<2e-13
            # A linearly mixed nuisance and exact template recovers its planted
            # amplitude in both partitions independently. The query nuisance
            # itself is neither known to the fit nor taken from the target.
            expected=.23
            linear=levels[2]*.78 + .015
            if kind=="affine":
                yy,xx=np.indices(query.shape)
                linear=.05+.00007*xx-.00003*yy
            exact=linear+expected*(levels[0]-levels[1])
            result=scores(measurements(exact,levels,colors,case["profile"],kind=="donor-coarse"))
            np.testing.assert_allclose([a["discovery_coeff"]for a in result["fits"]],
                                       [expected,expected],rtol=0.,atol=2e-11)
            assert result["both_gains_positive"]
            scopes[str(key),kind]=abs(result["amplitude"]-expected)
        if len(layout_cases)==4:
            break
    assert len(layout_cases)==4
    write_json(ROOT/"verification.json",{
        "driver":reference(__file__),"plan":reference(PLAN),
        "bayer_cases":{str(k):v for k,v in layout_cases.items()},
        "held_out_pixels_leave_directional_discovery_identical":True,
        "held_out_intervention_changes_validation":True,
        "orthogonality_bound":2e-13,
        "maximum_planted_amplitude_error":max(scopes.values()),
    })


if __name__=="__main__":
    verify()
