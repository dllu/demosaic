"""Audit and remove donor-induced chroma while retaining the measured luma lift."""

import argparse
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from compose import PRIOR, ROOT
from measure import BANDS, LUMA, coeffs, parts

SOURCE=ROOT/"full-composition-results.json"
PLAN=ROOT/"chroma-plan.json"
COEFFICIENTS=(0.,.25,1.)


def freeze():
    write_json(PLAN,{
        "driver":reference(__file__),"full_composition":reference(SOURCE),
        "chroma_gains":COEFFICIENTS,"luma_weights":LUMA.tolist(),
        "scope":"Follow-up selected after seeing colored grain in the registered donor RGB crop. RGB lift and neutral alternatives share the exact registered donor, coefficients and taper. Adjustment operates only on the lift in linear sRGB. The luma component remains fixed before float32 rounding.",
    })


def reports(rgb, target, fields, panel):
    receipt=parts(fields,rgb,target,panel)
    ref=linear_rgb(target,fields)
    restored=linear_rgb(rgb,fields)
    def chromatic(values):
        y=np.einsum("c,bchw->bhw",LUMA,values)
        return values-y[:,None]
    data=coeffs(chromatic(restored-ref),panel["score_ROI_xywh"])
    fine=data[...,BANDS["fine"]]
    rms=65535*np.sqrt(np.sum(fine**2,axis=(-1,-2,-3))/(3*96**2))
    assert rms.shape==(3,)
    return receipt|{"fine_chromatic_error_DN16_per_role":rms.tolist()}


def project(desired, base, matrix, balance, chroma_gain):
    if chroma_gain==1. or np.array_equal(desired,base):
        return desired
    transfer=matrix.astype(np.float64)*balance[None,:]
    inv=np.linalg.inv(transfer)
    delta=desired.astype(np.float64)-base
    srgb=np.einsum("ij,bjhw->bihw",transfer,delta)
    y=np.einsum("c,bchw->bhw",LUMA,srgb)
    adjusted = y[:,None] + chroma_gain*(srgb-y[:,None])
    restored=np.einsum("ij,bjhw->bihw",inv,adjusted)+base
    effective=np.einsum("ij,bjhw->bihw",transfer,restored-base)
    np.testing.assert_allclose(np.einsum("c,bchw->bhw",LUMA,effective),y,atol=5e-15,rtol=0)
    result=restored.astype(np.float32)
    if chroma_gain==0:
        effective_rounded=np.einsum("ij,bjhw->bihw",transfer,result.astype(np.float64)-base)
        assert np.max(abs(effective_rounded-effective))<2.4e-7
    return result


def measure():
    settings=read_json(PLAN)
    assert checked(settings["driver"])==Path(__file__)
    results=read_json(checked(settings["full_composition"]))
    panel=read_json(PRIOR/"evaluation-plan.json")
    folder=ROOT/"chroma-predictions"
    folder.mkdir()
    all_rows=[]
    for group,row in enumerate(results["cases"]):
        original=read_json(checked(row["original"]))
        with np.load(checked(original["input"]),allow_pickle=False)as data:
            balance,matrix,target=(data[k]for k in ("wb","matrix","target"))
        with np.load(checked(row["prediction"]),allow_pickle=False)as data:
            base,desired=(data[k]for k in ("100k","registered--donor-coarse"))
        fields={"exposure":original["profile"]["exposure"],"wb":np.broadcast_to(balance,(3,3)),
                "matrix":np.broadcast_to(matrix,(3,3,3))}
        metrics={"100k":reports(base,target,fields,panel)}
        pred={}
        for ratio in COEFFICIENTS:
            key=str(ratio)
            outcome=project(desired,base,matrix,balance,ratio)
            for j,lift in enumerate(row["response"]["registered/donor-coarse"]["lifted_coefficients"]):
                if not lift:
                    np.testing.assert_array_equal(outcome[j],base[j])
            pred[key]=outcome
            metrics[key]=reports(outcome,target,fields,panel)
        if np.array_equal(base,desired):
            binding=None
        else:
            path=folder/(original["id"]+".npz")
            with path.open("xb")as save:
                np.savez(save,**pred)
            binding=reference(path)
        all_rows.append({**{k:row[k]for k in ("case","source","profile","draw","original","prediction")},
                         "chroma_render":binding,"metrics":metrics})
        if (group+1)%64==0:
            print(group+1,flush=True)
    assert len(all_rows)==256
    summary={}
    for profile in ("iso400","iso6400"):
        summary[profile]={}
        for draw in ("coupled","independent"):
            scenes=[r for r in all_rows if (r["profile"],r["draw"])==(profile,draw)]
            assert len(scenes)==64
            data={}
            for key in ("100k",*map(str,COEFFICIENTS)):
                variants=[r["metrics"][key]for r in scenes]
                raw=[v["band"]["fine"]for v in variants]
                data[key]={
                    "mean_fine_chromatic_RMS_per_role":np.mean([v["fine_chromatic_error_DN16_per_role"]for v in variants],axis=0).tolist(),
                    "mean_paired_increment_fine_RMS":float(np.mean([v["increment_RMS_DN16"]for v in raw])),
                    "mean_present_srgb_PSNR":float(np.mean([v["srgb_PSNR_per_role"][0] for v in variants])),
                }
            summary[profile][draw]=data
    write_json(ROOT/"chroma-results.json",{"plan":reference(PLAN),"rows":all_rows,"summary":summary})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else measure()
