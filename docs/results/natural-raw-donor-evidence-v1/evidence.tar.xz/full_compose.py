"""Reduce the complete natural-photo benchmark with the frozen donor lift."""

import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from demosaic.prediction_archive import fingerprint
from compose import PARENT, PLAN, PRIOR, ROOT, band, lift
from full_parent import PARENT_PLAN
from probe import donor_candidates, REGION
from registration import REG_PLAN
from measure import parts, reduce

FULL=ROOT/"full-composition-plan.json"
CASES=("registered/affine","registered/donor-coarse","registered-by-search","disjoint-by-search")


def freeze():
    write_json(FULL,{
        "driver":reference(__file__),"probe":reference(PLAN),"parent_plan":reference(PARENT_PLAN),
        "parent_launch":reference(ROOT/"full-parent-launch.json"),
        "composition_driver":reference(ROOT/"compose.py"),
        "raw_results":reference(ROOT/"summary.json"),"registration_plan":reference(REG_PLAN),
        "registration_records":[reference(ROOT/f"registration-{i}.json")for i in (0,1)],
        "policies":CASES,
        "scope":"Full 64-source exact natural panel with one bound neural parent. Correct registration is a separately measured same-source simulator control. Small-translation replay and disjoint same-photo search use identical signal delivery.",
    })


def load_parent(entry):
    path=checked(entry["rgb"])
    if entry["npz_field"] is None:
        return np.load(path,allow_pickle=False)
    with np.load(path,allow_pickle=False) as values:
        return values[entry["npz_field"]]


def compute(row, base_receipt, reg_receipt, panel):
    spec=read_json(checked(row["receipt"]))
    assert base_receipt["source"]==row["receipt"]==reg_receipt["observation"]
    parent=load_parent(base_receipt)
    with np.load(checked(spec["input"]),allow_pickle=False)as store:
        arrays={k:store[k]for k in ("packed","variance","colors","wb","matrix","scene_packed","target")}
    assert all(fingerprint(v)==spec["fingerprints"][k]for k,v in arrays.items())
    display_fields={k:np.broadcast_to(arrays[k][None],(3,*arrays[k].shape))for k in ("wb","matrix")}
    display_fields["exposure"]=spec["profile"]["exposure"]
    common={key:arrays[key][None]for key in ("wb","matrix","colors")}
    donors=donor_candidates(arrays["scene_packed"],spec["box"])
    metrics={PARENT:parts(display_fields,parent,arrays["target"],panel)}
    generated={PARENT:parent}
    traces={}
    for name in CASES:
        shapes=[]
        if name.startswith("registered/"):
            donor=donors["registered"][0]
            key=name.split("/")[1]
            coefficients=row["donors"]["registered"]["metrics"][key]["2.5"]["coefficients"]
            native=band(noisy_malvar(common|{"packed":donor[None]})[0])
            shapes=[native]*3
        else:
            label="shifted" if name=="registered-by-search" else "disjoint-neighbor"
            witnesses=reg_receipt["donors"].get(label,[{}, {}, {}])
            coefficients=[v["fine"]["amplitude"] if v.get("accepted") else 0. for v in witnesses]
            for decision in witnesses:
                donor_band=None
                if decision.get("accepted"):
                    dy,dx=decision["offset"]
                    assert x_even(dx,dy)
                    reported=np.roll(donors[label][0],(dy//2,dx//2),axis=(-2,-1))
                    donor_band=band(noisy_malvar(common|{"packed":reported[None]})[0])
                shapes.append(donor_band)
        out=[lift(a,b,c)for a,b,c in zip(shapes,parent,coefficients,strict=True)]
        composed, gains, parent_coeffs=zip(*out,strict=True)
        result=np.stack(composed)
        assert result.shape==parent.shape and np.isfinite(result).all()
        for j,delta in enumerate(gains):
            if delta==0:
                np.testing.assert_array_equal(result[j],parent[j])
            else:
                difference=result[j]-parent[j]
                assert not difference[:,:80].any() and not difference[:,176:].any()
                assert not difference[:,:,:80].any() and not difference[:,:,176:].any()
        metrics[name]=parts(display_fields,result,arrays["target"],panel)
        generated[name]=result
        traces[name]={"lifted_coefficients":gains,"parent_projections":parent_coeffs,"approved":coefficients}
    return generated,metrics,traces


def x_even(x,y):
    return x%2==y%2==0


def collect():
    os.sched_setaffinity(0,[14,19])
    frozen=read_json(FULL)
    assert checked(frozen["driver"])==Path(__file__)
    start_ref=read_json(checked(frozen["parent_launch"]))
    awaiting=ROOT/"full-parent.json"
    while not awaiting.exists():
        if not owner_live(start_ref) and not awaiting.exists():
            raise RuntimeError("Bound 100k worker ended without the expected receipt")
        time.sleep(5)
    parent=read_json(awaiting)
    assert parent["plan"]==frozen["parent_plan"] and len(parent["records"])==256
    summary=read_json(checked(frozen["raw_results"]))
    panel=read_json(checked(read_json(checked(frozen["probe"]))["source_panel"]))
    registration=[read_json(checked(file))for file in frozen["registration_records"]]
    assert all(row["plan"]==frozen["registration_plan"] for row in registration)
    ready={row["observation"]["sha256"]:row for part in registration for row in part["rows"]}
    parent_rows={r["source"]["sha256"]:r for r in parent["records"]}
    report=[]
    output=ROOT/"full-composition"
    output.mkdir()
    for bind in summary["shards"]:
        for photo in read_json(checked(bind))["rows"]:
            key=photo["receipt"]["sha256"]
            generated,metrics,traces=compute(photo,parent_rows[key],ready[key],panel)
            file=output/(parent_rows[key]["id"]+".npz")
            with file.open("xb")as stream:
                np.savez(stream,**{n.replace("/","--"):v for n,v in generated.items()})
            report.append({**{k:photo[k]for k in ("case","source","profile","draw")},
                           "original":photo["receipt"],"prediction":reference(file),
                           "response":traces,"metrics":metrics,"parent_receipt":parent_rows[key]})
            if len(report)%16==0:
                print("composition",len(report),flush=True)
    assert len(report)==256
    write_json(ROOT/"full-composition-results.json",{
        "plan":reference(FULL),"parent":read_json(checked(frozen["parent_plan"]))["model"],
        "parent_collection":reference(awaiting),"cases":report,"pooled":reduce(report),
    })


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else collect()
