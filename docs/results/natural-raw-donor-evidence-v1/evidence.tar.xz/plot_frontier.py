"""Plot true paired response against unwanted transfer to masked-detail crops."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import read_json, reference, write_json
from probe import ROOT


def plot():
    data=read_json(ROOT/"summary.json")
    figure, panels=plt.subplots(1,2,figsize=(8.7,3.8),sharex=True,sharey=True,layout="constrained")
    for axis,draw in zip(panels,("coupled","independent"),strict=True):
        series=data["summary"]["iso6400"][draw]["registered"]
        for method,label,color in (("affine","Affine nuisance","#a95b3e"),
                                   ("donor-coarse","Affine + coarse donor","#1a6580")):
            thresholds=("0","1","2.5","4","6")
            pts=[series[method][direct] for direct in thresholds]
            x=[u["mean_masked_injected_RMS_DN16"] for u in pts]
            y=[100*u["pooled_signed_response"] for u in pts]
            axis.plot(x,y,"-o",label=label,color=color,markersize=3.5)
            ix=thresholds.index("2.5")
            axis.scatter(x[ix],y[ix],color=color,s=45)
        axis.set_title(draw.title()+" observation")
        axis.set_xlabel("Added variation on masked-detail controls (DN16)")
        axis.grid(alpha=.25)
        axis.set_xlim(-8,255)
    panels[0].set_ylabel("Signed response to the exact weak increment (%)")
    panels[0].legend(loc="best",frameon=False,fontsize=8)
    figure.suptitle("Registered RAW donor on 64 ISO6400 photographs\nLarger points show the fixed validation cutoff of 2.5",fontsize=11)
    image=ROOT/"donor-frontier.png"
    figure.savefig(image,dpi=180)
    write_json(ROOT/"donor-frontier.json",{"driver":reference(__file__),"input":reference(ROOT/"summary.json"),
                                          "figure":reference(image)})


if __name__=="__main__":
    plot()
