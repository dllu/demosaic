"""Cross-fit weak natural texture using an independently measured RAW donor."""

from collections import defaultdict
from pathlib import Path
import argparse

import numpy as np
from scipy.ndimage import gaussian_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "scene-local-contrast-2400-v1"
PLAN = ROOT / "plan.json"
REGION = np.s_[80:176,80:176]
SIZE = 96
BLOCK = 16
SHIFT_YX = (4, 6)
AUDIT = 2.5
DONORS = ("registered", "shifted", "disjoint-neighbor")
NUISANCES = ("affine", "donor-coarse")
BY, BX = np.indices((BLOCK,BLOCK))
X, Y = (BX-7.5)/8, (BY-7.5)/8
DESIGN = np.stack((np.ones_like(X),X,Y),axis=-1)
SPLIT = (BX//2+BY//2)%2 == 0


def freeze():
    source = PRIOR/"evaluation-plan.json"
    described=read_json(source)
    shards=[PRIOR/f"observation-shard-{k}.json" for k in (0,1)]
    receipts=[row for shard in shards for row in read_json(shard)["records"]]
    assert len(receipts)==256
    write_json(PLAN,{
        "driver":reference(__file__),"source_panel":reference(source),
        "photo_receipts":receipts, "expect_sources":64,
        "verification":reference(PRIOR/"observation-verification.json"),
        "original_shards":[reference(path) for path in shards],
        "roi_xywh":[80,80,SIZE,SIZE],"fit_block_native_pixels":BLOCK,
        "reservation":"Alternating native 2x2 Bayer cells with each phase balanced in every 16x16 block.",
        "donors":DONORS,"nuisances":NUISANCES,"offset_native_yx":SHIFT_YX,
        "score_cutoffs":[0,1,2.5,4,6],
        "delivery_cutoff":AUDIT,
        "donor_raw_prefilter_sigmas_in_packed_pixels":[.50,2.,4.],
        "max_output_coefficient":.5,
        "scope":"Registered donor is a separate noisy measurement of the unattenuated source at the query location in the simulator. It supplies an upper-limit correspondence test. It is not the whole-image preview or a transferable real-camera claim. Shifted donor is from the same observation with the fixed integer displacement; disjoint natural donor is a different patch in the same noisy exterior. No clean targets enter the fitting path.",
    })


def unpack(packed):
    arr = np.empty((packed.shape[1]*2,packed.shape[2]*2), dtype=packed.dtype)
    for p in range(4):
        y, x=divmod(p,2)
        arr[y::2,x::2]=packed[p]
    return arr


def filtered(packed):
    return [unpack(gaussian_filter(packed.astype(np.float64), (0,sigma,sigma), mode="reflect"))
            for sigma in (.50,2.,4.)]


def donor_candidates(scene, box):
    x,y,w,h = box
    assert (w,h)==(256,256) and x%2==y%2==0
    i,j=x//2,y//2
    sized=128
    height,width=scene.shape[-2:]
    exact=scene[:,j:j+sized,i:i+sized]
    shifted=np.roll(exact,(SHIFT_YX[0]//2,SHIFT_YX[1]//2),axis=(-2,-1))
    result={"registered":(exact,[x,y,w,h]),"shifted":(shifted,None)}
    other=[]
    for yy, xx in ((0,0),(0,width-sized),(height-sized,0),(height-sized,width-sized)):
        if xx+sized<=i or i+sized<=xx or yy+sized<=j or j+sized<=yy:
            other.append((abs(yy-j)+abs(xx-i),yy,xx))
    if other:
        _,yy,xx=max(other)
        result["disjoint-neighbor"] = (scene[:,yy:yy+sized,xx:xx+sized],[xx*2,yy*2,w,h])
    assert all(v.shape==(4,128,128) for v,_ in result.values())
    return result


def tile(values):
    arrays=np.asarray(values)
    assert arrays.shape[:2] == (SIZE, SIZE)
    z=SIZE//BLOCK
    reshaped=arrays.reshape(z,BLOCK,z,BLOCK,*arrays.shape[2:])
    return reshaped.swapaxes(1,2).reshape(z*z,BLOCK,BLOCK,*arrays.shape[2:])


def nuisance_qr(design):
    u,s,_=np.linalg.svd(design,full_matrices=False)
    keep=s>s[:,:1]*1e-9
    return u*keep[:,None,:]


def remove(basis, values):
    return values - np.einsum("nkd,nd->nk",basis,np.einsum("nkd,nk->nd",basis,values))


def measurements(noisy, levels, colors, prior, detail_basis):
    raw=tile(noisy[REGION])
    donor_half,donor_two,donor_four=(tile(v[REGION]) for v in levels)
    template=donor_half-donor_two
    cfa=np.asarray(colors).reshape(2,2)[BY%2,BX%2]
    measurements=[]
    for select in (SPLIT,~SPLIT):
        color_records=[]
        for channel in range(3):
            sites=(cfa==channel)
            picked=sites&select
            selected=raw[:,picked]
            affine=np.broadcast_to(DESIGN[picked],(*selected.shape,3))
            if detail_basis:
                guide=(donor_two[:,picked],donor_four[:,picked])
                affine=np.concatenate((affine,*[g[...,None] for g in guide]),axis=-1)
            space=nuisance_qr(affine)
            shape=remove(space,template[:,picked])
            whiten=prior["shot"]*np.maximum(1.e-4,selected.mean(axis=1))+prior["read"]
            color_records.append({"color":channel, "basis":space, "shape":shape,
                                  "discover_noise":whiten, "obs":selected})
        measurements.append(color_records)
    return measurements


def scores(data):
    terms=[]
    for records,other in ((data[0],data[1]),(data[1],data[0])):
        cross=norm=held_cross=held_norm=0.
        for fit,test in zip(records,other,strict=True):
            assert fit["color"]==test["color"]
            weight=(1./fit["discover_noise"])[:,None]
            a,b=fit["shape"],test["shape"]
            cross+=float(np.sum(a*fit["obs"]*weight))
            norm+=float(np.sum(a*a*weight))
            held_cross+=float(np.sum(b*test["obs"]*weight))
            held_norm+=float(np.sum(b*b*weight))
        beta=float(np.clip(cross/max(norm,1.e-16),0.,.5))
        score=float(held_cross/np.sqrt(max(held_norm,1.e-16)))
        gain=2*beta*held_cross-beta**2*held_norm
        terms.append({"discovery_coeff":beta,"held_z":score,"held_gain":gain})
    return {
        "fits":terms, "min_z":min(t["held_z"] for t in terms),
        "both_gains_positive":all(t["held_gain"]>0 for t in terms),
        "amplitude":float(np.mean([t["discovery_coeff"] for t in terms])),
    }


def footprint(role_rgb,colors):
    result=np.empty(role_rgb.shape[-2:],np.float64)
    for p,c in enumerate(colors):
        y,x=divmod(p,2)
        result[y::2,x::2]=role_rgb[c,y::2,x::2]
    return result


def observe(spec, arrays):
    cfa=arrays["colors"]
    weights=spec["profile"]
    donors=donor_candidates(arrays["scene_packed"],spec["box"])
    methods={}
    for label,(packed,box) in donors.items():
        levels=filtered(packed)
        template=(levels[0]-levels[1])[REGION]
        by_policy={}
        for name in NUISANCES:
            rows=[]
            for raw in arrays["packed"]:
                data=measurements(unpack(raw),levels,cfa,weights,name=="donor-coarse")
                rows.append(scores(data))
            by_policy[name]=rows
        methods[label]={"donor":fingerprint(packed),"source_box":box,"policies":by_policy}

    truth=np.stack([footprint(rgb, cfa)[REGION] for rgb in arrays["target"]])
    original=truth[0]-truth[1]
    assert np.isfinite(truth).all()
    reference_rms=float(np.sqrt(np.mean(original**2))*65535)
    for label,results in methods.items():
        packed,_=donors[label]
        levels=filtered(packed)
        template=(levels[0]-levels[1])[REGION]
        power=float(np.sum(original**2))
        cross=float(np.sum(template*original))
        results["increment_cfa_power"] = power
        results["donor_to_target_cosine"] = cross/np.sqrt(power*np.sum(template**2)) if power>1e-18 else None
        by_policy={}
        for name,values in results["policies"].items():
            metrics={}
            for t in (0,1,2.5,4,6):
                accepted=[row["both_gains_positive"] and row["min_z"]>t for row in values]
                amplitudes=[row["amplitude"]*on for row,on in zip(values,accepted,strict=True)]
                delivered=(amplitudes[0]-amplitudes[1])*template
                score=float(np.sum(delivered*original))
                metrics[str(t)]={"accepted":accepted,"coefficients":amplitudes,
                    "paired_increment_dot":score,
                    "increment_error_DN16":float(np.sqrt(np.mean((delivered-original)**2))*65535),
                    "masked_injected_RMS_DN16":float(abs(amplitudes[1])*np.sqrt(np.mean(template**2))*65535),
                    "flat_injected_RMS_DN16":float(abs(amplitudes[2])*np.sqrt(np.mean(template**2))*65535)}
            by_policy[name]=metrics
        results["metrics"]=by_policy
    return methods,reference_rms


def collect(shard):
    plan=read_json(PLAN)
    assert checked(plan["driver"])==Path(__file__)
    raw=[]
    for record in plan["photo_receipts"]:
        spec=read_json(checked(record))
        if spec["case"]%2!=shard:
            continue
        with np.load(checked(spec["input"]),allow_pickle=False) as stored:
            arrays={k:stored[k] for k in ("packed","scene_packed","colors","target")}
        assert all(fingerprint(data)==spec["fingerprints"][k] for k,data in arrays.items())
        results,rms=observe(spec,arrays)
        raw.append({"case":spec["case"],"profile":spec["profile"]["name"],"draw":spec["draw"],
                    "receipt":record,"source":spec["source"],"input_rms":rms,"donors":results})
        if len(raw)%16==0:
            print(shard,len(raw),flush=True)
    assert len(raw)==128
    write_json(ROOT/f"shard-{shard}.json",{"plan":reference(PLAN),"rows":raw})


def reduce():
    paths=[ROOT/f"shard-{k}.json" for k in (0,1)]
    shards=[read_json(p) for p in paths]
    assert all(r["plan"]==reference(PLAN) for r in shards)
    rows=[r for shard in shards for r in shard["rows"]]
    assert len({(r["case"],r["profile"],r["draw"])for r in rows})==len(rows)==256
    grouped=defaultdict(list)
    for row in rows:
        for label, donor in row["donors"].items():
            for policy, spec in donor["metrics"].items():
                for threshold,v in spec.items():
                    key=row["profile"],row["draw"],label,policy,threshold
                    grouped[key].append((row["case"],donor["increment_cfa_power"],v))
    summary={}
    for (prior,draw,label,policy,threshold),data in grouped.items():
        power=[power for _,power,v in data]
        numbers=[v for _,p,v in data]
        accepted=np.array([v["accepted"] for v in numbers])
        before=np.array([(p/SIZE**2)**.5*65535 for p in power])
        table={"sources":len(data),"counts_present_masked_flat":accepted.sum(0).tolist(),
               "pooled_signed_response":sum(v["paired_increment_dot"] for v in numbers)/max(1e-18,sum(power)),
               "mean_paired_increment_error_DN16":float(np.mean([v["increment_error_DN16"] for v in numbers])),
               "mean_reference_RMS_DN16":float(before.mean()),
               "mean_masked_injected_RMS_DN16":float(np.mean([v["masked_injected_RMS_DN16"] for v in numbers])),
               "mean_flat_injected_RMS_DN16":float(np.mean([v["flat_injected_RMS_DN16"] for v in numbers]))}
        summary.setdefault(prior,{}).setdefault(draw,{}).setdefault(label,{}).setdefault(policy,{})[threshold]=table
    write_json(ROOT/"summary.json",{"plan":reference(PLAN),"cases":len(rows),
                   "shards":list(map(reference,paths)),"summary":summary})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("plan","collect","reduce"))
    parser.add_argument("--shard",type=int,choices=(0,1))
    args=parser.parse_args()
    {"plan":freeze,"collect":lambda:collect(args.shard),"reduce":reduce}[args.action]()
