"""Render fixed-choice native crops from the real-noise-model donor experiment."""

import sys

import numpy as np

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from probe import PLAN, PRIOR, ROOT

sys.path.insert(0,str(PRIOR))
from report_scene_wave_guides import native_board


def render():
    record=ROOT/"full-composition-results.json"
    panel=read_json(checked(read_json(PLAN)["source_panel"]))
    summary=read_json(record)
    examples=[r for r in summary["cases"] if (r["profile"],r["draw"])==("iso6400","coupled")]
    def gain(row):
        metric=lambda name: row["metrics"][name]["band"]["fine"]["increment_RMS_DN16"]
        return metric("100k")-metric("registered/donor-coarse")
    selected=sorted(examples,key=lambda row:(-gain(row),row["case"]))[:2]
    assert len(selected)==2 and all(gain(r)>0 for r in selected)
    choices=[(row,0,"largest paired fine-band increment RMS decrease")for row in selected]
    choices.append((next(r for r in examples if r["case"]==0),2,"predeclared exact flat core"))
    worst=min(examples,key=lambda row:(gain(row),row["case"]))
    if gain(worst)<0:
        choices.append((worst,0,"largest paired fine-band increment regression"))
    version=ROOT/"composition-native"
    version.mkdir()
    boards=[]
    for row,role,witness in choices:
        settings=read_json(checked(row["original"]))
        with np.load(checked(settings["input"]),allow_pickle=False)as f:
            inputs={k:f[k][role:role+1]if k in ("packed","variance")else f[k][None]
                    for k in ("packed","variance","colors","wb","matrix")}
            gt=f["target"][role]
        with np.load(checked(row["prediction"]),allow_pickle=False)as outputs:
            bind=["100k","registered--affine","registered--donor-coarse","registered-by-search",
                  "disjoint-by-search"]
            r=[outputs[key][role]for key in bind]
        options=panel["rows"][row["case"]]
        values=[noisy_malvar(inputs)[0],*r,gt]
        boards.append(native_board(version,f"{settings['id']}-role{role}",values,inputs,
            {"selection":witness,"role":panel["roles"][role],"delta_RMS_DN16":gain(row)if role==0 else None,
             "parent":summary["parent"],"source":options["source"],"profile":settings["profile"],
             "CFA":options["camera"]["pattern"],"draw":settings["draw"],"query_box":settings["box"],
             "composed_output":row["prediction"]},
            labels=("Noisy Malvar","Corpus 100k","Affine RAW lift","Coarse-aware RAW lift",
                    "Registered by search","Disjoint by search","Exact GT"),
            triplet_indices=(0,3,6),contrast=2,exposure=1/settings["profile"]["exposure"],
            roi=tuple(panel["native_display_ROI_xywh"])))
    write_json(version/"viewing.json",{"driver":reference(__file__),"composition":reference(record),"boards":boards})


if __name__=="__main__":
    render()
