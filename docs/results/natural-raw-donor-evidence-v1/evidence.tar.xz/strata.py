"""Apply the predeclared faint-source split to the measured donor tests."""

import argparse
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from probe import ROOT,PRIOR

COHORT=PRIOR/"matched-analysis-plan.json"
SEED=39487
N_BOOT=5000


def split():
    return {v[2]for v in read_json(COHORT)["fainter_half_by_frozen_clean_increment"]}


def paired(values,rng):
    choices=rng.integers(0,len(values),(N_BOOT,len(values)))
    distribution=values[choices].mean(axis=1)
    return {"mean":float(values.mean()),"median":float(np.median(values)),
            "wins":int((values<0).sum()),"strict_losses":int((values>0).sum()),
            "paired_CI95":np.percentile(distribution,[2.5,97.5]).tolist()}


def raw():
    summary=read_json(ROOT/"summary.json")
    source=[row for h in summary["shards"]for row in read_json(checked(h))["rows"]]
    rng=np.random.default_rng(SEED)
    strata=split()
    result={}
    for profile in ("iso400","iso6400"):
        result[profile]={}
        for draw in ("coupled","independent"):
            rows=[v for v in source if (v["profile"],v["draw"])==(profile,draw)]
            palette={}
            for label in ("full","fainter-half"):
                selected=[x for x in rows if label=="full" or x["source"] in strata]
                assert len(selected)==(64 if label=="full" else 32)
                report={}
                controls={
                    "registered-affine":("registered","affine"),
                    "registered-coarse-aware":("registered","donor-coarse"),
                    "shifted-coarse-aware":("shifted","donor-coarse"),
                    "disjoint-coarse-aware":("disjoint-neighbor","donor-coarse"),
                }
                for method,(name,nuisance) in controls.items():
                    data=[(row,row["donors"][name])for row in selected if name in row["donors"]]
                    measurements=[x["metrics"][nuisance]["2.5"]for _,x in data]
                    result_rows=np.array([v["accepted"]for v in measurements])
                    cfa_energy=np.array([d["increment_cfa_power"]for _,d in data])
                    products=np.array([v["paired_increment_dot"]for v in measurements])
                    assert len(cfa_energy)==len(measurements)
                    error=np.array([v["increment_error_DN16"] for v in measurements])
                    base=np.array([o["input_rms"]for o,_ in data])
                    report[method]={
                        "number_of_sources":len(data),
                        "accepted_present_masked_flat":result_rows.sum(0).tolist(),
                        "signed_increment_response":float(products.sum()/max(cfa_energy.sum(),1e-18)),
                        "mean_CFA_increment_RMS_DN16":float(error.mean()),
                        "difference_vs_zero_increment_DN16":paired(error-base,rng),
                    }
                palette[label]=report
            result[profile][draw]=palette
    write_json(ROOT/"raw-strata.json",{"driver":reference(__file__),"cohort":reference(COHORT),
                                      "summary":reference(ROOT/"summary.json"),"strata":result})


def composition():
    published=ROOT/"full-composition-results.json"
    report=read_json(published)
    rng=np.random.default_rng(SEED)
    strata=split()
    out={}
    for prior in ("iso400","iso6400"):
        out[prior]={}
        for draw in ("coupled","independent"):
            data=[row for row in report["cases"] if (row["profile"],row["draw"])==(prior,draw)]
            assert len(data)==64
            result={}
            for label in ("full","fainter-half"):
                v=[x for x in data if label=="full" or x["source"] in strata]
                assert len(v)==(64 if label=="full" else 32)
                result[label]={}
                for name in v[0]["response"]:
                    pair=[(row["metrics"][name]["band"]["fine"],row["metrics"]["100k"]["band"]["fine"])for row in v]
                    errors={}
                    for metric in ("increment_RMS_DN16","quiet_RMS_DN16","present_RMS_DN16"):
                        difference=np.array([candidate[metric]-base[metric] for candidate,base in pair])
                        errors[metric]=paired(difference,rng)
                    response=[(j["aligned_increment_dot"],b["aligned_increment_dot"],b["exact_paired_increment_sq"])
                                for (j,b) in pair]
                    d, c, e=np.array(response).sum(axis=0)
                    applied=np.array([row["response"][name]["lifted_coefficients"]for row in v])
                    result[label][name]={"error_change":errors,"lifted_present_masked_flat":np.count_nonzero(applied>0,axis=0).tolist(),
                       "base_response":float(c/e),"new_response":float(d/e)}
            out[prior][draw]=result
    write_json(ROOT/"composition-strata.json",{"driver":reference(__file__),"cohort":reference(COHORT),
                        "composition":reference(published),"strata":out})


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("raw","composition"))
    {"raw":raw,"composition":composition}[p.parse_args().action]()
