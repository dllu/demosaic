"""Apply a supported donor increment above the archived Corpus 100k EMA."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from probe import DONORS, NUISANCES, PLAN, PRIOR, REGION, ROOT, SIZE, donor_candidates

sys.path.insert(0,str(PRIOR))
from measure import parts, reduce
from report_scene_wave_guides import native_board

PARENT = "100k"
CUT = "2.5"


def support():
    edge=np.minimum(np.arange(SIZE)+.5,np.arange(SIZE)[::-1]+.5)
    phase=np.clip(edge/12,0,1)
    taper=phase**2*(3-2*phase)
    return taper[:,None]*taper[None,:]


WINDOW=support()


def band(rgb):
    values=rgb.astype(np.float64)
    narrow,wide=(gaussian_filter(values,(0,sigma,sigma),mode="reflect")for sigma in (1.,4.))
    return narrow-wide


def weighted_center(value):
    return value-np.sum(value*WINDOW,axis=(-2,-1),keepdims=True)/WINDOW.sum()


def lift(donor_band, base, approved_coefficient):
    if approved_coefficient == 0.:
        return base, 0., None
    template=weighted_center(donor_band[(slice(None),*REGION)].copy())
    parent=weighted_center(band(base)[(slice(None),*REGION)])
    energy=float(np.sum(template**2*WINDOW))
    recovered=float(np.sum(parent*template*WINDOW)/max(1.e-15,energy))
    delta=float(np.clip(approved_coefficient - recovered,0.,.5))
    correction=delta*template*WINDOW
    assert np.max(abs(correction.sum(axis=(1,2))))<1e-12
    out=base.copy()
    out[(slice(None),*REGION)] += correction.astype(out.dtype)
    return out,delta,recovered


def compare():
    collected=read_json(ROOT/"summary.json")
    assert collected["plan"]==reference(PLAN)
    original=read_json(checked(collected["plan"]))
    panel=read_json(checked(original["source_panel"]))
    tests=[row for shard in collected["shards"] for row in read_json(checked(shard))["rows"]]
    plan_path=PRIOR/"pilot/plan.json"
    pilot=read_json(plan_path)
    previous=read_json(PRIOR/"pilot/results.json")
    assert previous["plan"]==reference(plan_path)
    parent=pilot["models"][PARENT]
    assert parent["step"]==100000
    selected=set(pilot["selected_indices"])
    active=ROOT/"composition"
    active.mkdir()
    rows=[]
    for row in tests:
        if row["case"] not in selected:
            continue
        scene=read_json(checked(row["receipt"]))
        earlier=next(v for v in previous["source_metrics"] if
                     (v["source"],v["profile"],v["draw"])==(row["source"],row["profile"],row["draw"]))
        prediction=read_json(checked(earlier["prediction_receipt"]))
        assert prediction["case"]==row["receipt"]
        with np.load(checked(scene["input"]),allow_pickle=False) as contents:
            original={k:contents[k]for k in ("packed","variance","colors","wb","matrix","target","scene_packed")}
        with np.load(checked(prediction["saved"]),allow_pickle=False) as contents:
            rgb=contents[PARENT]
        donor_data=donor_candidates(original["scene_packed"],scene["box"])
        display_fields={k:np.broadcast_to(original[k][None],(3,*original[k].shape))for k in ("wb","matrix")}
        display_fields["exposure"]=scene["profile"]["exposure"]
        metrics={PARENT:parts(display_fields,rgb,original["target"],panel)}
        np.testing.assert_allclose(metrics[PARENT]["band"]["fine"]["increment_RMS_DN16"],
                     earlier["metrics"][PARENT]["band"]["fine"]["increment_RMS_DN16"],atol=1e-10,rtol=0)
        values={PARENT:rgb}
        response={}
        for name in DONORS:
            if name not in donor_data:
                continue
            donor,_=donor_data[name]
            assert row["donors"][name]["donor"]==fingerprint(donor)
            params={key:original[key][None]for key in ("colors","wb","matrix")}
            donor_rgb=noisy_malvar(params|{"packed":donor[None]})[0]
            narrow=band(donor_rgb)
            for method in NUISANCES:
                key=f"{name}/{method}"
                coefficient=row["donors"][name]["metrics"][method][CUT]["coefficients"]
                applied=[lift(narrow,base,c)for base,c in zip(rgb,coefficient,strict=True)]
                approx, scale, existed=zip(*applied,strict=True)
                for i,was_changed in enumerate(scale):
                    if was_changed==0:
                        np.testing.assert_array_equal(approx[i],rgb[i])
                values[key]=np.stack(approx)
                metrics[key]=parts(display_fields,values[key],original["target"],panel)
                response[key]={"lift_coefficients":scale,"parent_coefficients":existed,
                               "accepted_sensor_coefficients":coefficient}
        archive=active/(scene["id"]+".npz")
        with archive.open("xb") as stream:
            np.savez(stream,**{k.replace("/","--"):v for k,v in values.items()})
        rows.append({"case":row["case"],"source":row["source"],"profile":row["profile"],"draw":row["draw"],
        "metrics":metrics,"response":response,"original":row["receipt"],"parent_receipt":earlier["prediction_receipt"],
        "prediction":reference(archive)})
    assert len(rows)==32
    write_json(ROOT/"composition.json",{
        "driver":reference(__file__),"raw_audit":reference(ROOT/"summary.json"),
        "parent":parent, "parent_scope":"Existing Corpus 100k EMA, CUDA IEEE FP32 archives.",
        "frozen_combination":"Lift only the positive difference between the supported CFA coefficient and the measured template projection in parent RGB. Camera RGB band from Malvar of noisy donor, separable Gaussian difference at sigmas 1 and 4 native px, weighted zero mean, 12-pixel inward taper. No lift exceeds 0.5.",
        "cases":rows, "pooled":reduce(rows)
    })


if __name__=="__main__":
    compare()
