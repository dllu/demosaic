"""Review disjoint, row-separated RAW donors on the two standing GFX scenes."""

import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.cfa import malvar
from demosaic.color import linear_to_srgb, srgb_to_linear
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from compose import band, lift
from probe import REGION, ROOT, unpack
from registration import REG_PLAN, prepare_bank, register

EARLIER=ROOT.parent/"scene-local-contrast-2400-v1"/"reviews"
STANDING=ROOT/"standing-plan.json"
DONOR_NATIVE=192
STRIDE=96
QUERY_NATIVE=256


def freeze():
    prior=EARLIER/"first-endpoint/collection.json"
    controls=read_json(prior)
    write_json(STANDING,{
        "driver":reference(__file__),"composition_driver":reference(ROOT/"compose.py"),
        "registration":reference(REG_PLAN),"standing_protocol":reference(EARLIER/"standing/localized/plan.json"),
        "previous_protocol":reference(prior),
        "models":{"Corpus 100k EMA":controls["parent"],"V120 EMA":controls["V120"],
                  "Localized spatial EMA":controls["epochs"]["localized-spatial"]},
        "donor_candidate_native_width":DONOR_NATIVE,
        "donor_candidate_grid_stride":STRIDE,
        "donor_source_contract":"Fixed 192px square grid contained in archived local context. Every donor shares zero native readout rows with the entire 96px query fit region. Reflect-pad donor edges for common inference shapes before the same fine fit. Each fold ranks the complete donor/translation list from its own crop sample band.",
        "scope":"Eight native standing regions, no fresh RAW decode or neural forward. Independent ISO100 AHD/JPEG qualitative references are rendered after the correction is fixed.",
    })


def extract(raw, x, y, size):
    return raw[:,y//2:(y+size)//2,x//2:(x+size)//2]


def donor_candidates(raw, query):
    x,y=query
    height,width=(2*n for n in raw.shape[-2:])
    allowed={}
    for iy in range(0,height-DONOR_NATIVE+1,STRIDE):
        for ix in range(0,width-DONOR_NATIVE+1,STRIDE):
            if iy+DONOR_NATIVE > y+80 and iy < y+176:
                continue
            native=extract(raw,ix,iy,DONOR_NATIVE)
            pad=(QUERY_NATIVE-DONOR_NATIVE)//4
            padded=np.pad(native,((0,0),(pad,pad),(pad,pad)),mode="reflect")
            allowed[f"x{ix}-y{iy}"]=(padded,[ix,iy,DONOR_NATIVE,DONOR_NATIVE])
    assert allowed
    return allowed


def compare():
    torch.set_num_threads(1)
    spec=read_json(STANDING)
    assert checked(spec["driver"])==Path(__file__)
    checked(spec["composition_driver"])
    checked(spec["registration"])
    source=read_json(checked(spec["standing_protocol"]))
    models={k:read_json(checked(v))for k,v in spec["models"].items()}
    records={k:{v["id"]:v for v in r["records"]}for k,r in models.items()}
    output=ROOT/"standing-native"
    output.mkdir()
    rows=[]
    for item in source["observations"]:
        if item["kind"]=="development":
            continue
        name=item["id"]
        inputs=fingerprint
        reference_input=records["Corpus 100k EMA"][name]["input_fingerprints"]
        assert all(table[name]["input_fingerprints"]==reference_input for table in records.values())
        with np.load(checked(item["arrays"]),allow_pickle=False)as pack:
            args={k:pack[k]for k in ("packed","colors","wb","matrix")}
            target=pack["reference_rgb"] if item["kind"]=="mesh" else None
        assert all(inputs(v)==reference_input[k] for k,v in args.items())
        arrays={k:np.load(checked(table[name]["prediction"]),allow_pickle=False)for k,table in records.items()}
        exposure=item["display_exposure"]
        parent=arrays["Corpus 100k EMA"][0]
        noisy=malvar(torch.from_numpy(args["packed"]),torch.from_numpy(args["colors"]),
                     torch.from_numpy(args["wb"]))
        balance,matrix=[torch.from_numpy(args[k])for k in ("wb","matrix")]
        regions=item["cases"] if item["kind"]=="mesh" else [{"name":name,"ROI_xywh":item["ROI_xywh"]}]
        for r in regions:
            rx,ry,rw,rh=r["ROI_xywh"]
            assert rw==rh==160
            x,y=(int((v-48)//2)*2 for v in (rx,ry))
            packed=args["packed"][0]
            query=extract(packed,x,y,QUERY_NATIVE)
            candidates=donor_candidates(packed,(x,y))
            raw_query=unpack(query)
            prepared=prepare_bank({k:v[0]for k,v in candidates.items()},args["colors"][0])
            trace,admitted=register(raw_query,args["colors"][0],item["noise"],prepared)
            result=parent.copy()
            alpha=0.
            existing=None
            if admitted is not None:
                donor,shift,_=admitted
                tile=np.roll(candidates[donor][0],tuple(v//2 for v in shift),axis=(-2,-1))
                donor_rgb=malvar(torch.from_numpy(tile[None]),torch.from_numpy(args["colors"]),balance)[0].numpy()
                crop=result[:,y:y+QUERY_NATIVE,x:x+QUERY_NATIVE]
                composed,alpha,existing=lift(band(donor_rgb),crop,trace["fine"]["amplitude"])
                result[:,y:y+QUERY_NATIVE,x:x+QUERY_NATIVE]=composed
            delta=result[:,ry:ry+rh,rx:rx+rw]-parent[:,ry:ry+rh,rx:rx+rw]
            if alpha==0:
                np.testing.assert_array_equal(result,parent)
            scope={
                "id":name+"-"+r["name"],"case":r,"query_context_xywh":[x,y,QUERY_NATIVE,QUERY_NATIVE],
                "approved_candidate":admitted is not None,"lift":alpha,"parent_amplitude":existing,
                "delta_RMS_DN16":float(65535*np.sqrt(np.mean(delta.astype(np.float64)**2))),
                "fit":trace,"conditioning":item["noise"],"exposure":exposure,
                "capture_input":item["arrays"],"query":inputs(query),
                "donor_boxes":{k:v[1] for k,v in candidates.items()},
                "noisy_observations_source_role":item["reference_role"],
            }
            panel=render(output,scope,noisy,arrays,result,balance,matrix,r,item,target)
            rows.append(scope|panel)
            print(scope["id"],[len(candidates),trace["coarse_pass"],admitted is not None,alpha,scope["delta_RMS_DN16"]],flush=True)
    assert len(rows)==8
    write_json(ROOT/"standing.json",{"plan":reference(STANDING),"boards":rows,"parent_models":{
                        k:v["checkpoint"]for k,v in models.items()},"native_viewing":"pending"})


def render(output,case,noisy,models,result,wb,matrix,roi,original,target):
    box=roi["ROI_xywh"]
    exp=case["exposure"]
    pixels=[("Noisy Malvar",display_crop(noisy,wb,matrix,box,exposure=exp))]
    for name in ("V120 EMA","Corpus 100k EMA","Localized spatial EMA"):
        values = torch.from_numpy(models[name])
        pixels.append((name,display_crop(values,wb,matrix,box,exposure=exp)))
    pixels.append(("RAW donor lift",display_crop(torch.from_numpy(result[None]),wb,matrix,box,exposure=exp)))
    if target is None:
        target=np.load(checked(original["target"]),allow_pickle=False)
        ref_box=[0,0,160,160]
    else:
        ref_box=box
    pixels.append(("ISO100 AHD reference",display_crop(torch.from_numpy(target),wb,matrix,ref_box,exposure=exp)))
    if original["kind"]=="mesh":
        for role,title,pos in (("noisy_camera_jpeg","ISO6400 camera JPEG",0),
                               ("reference_camera_jpeg","ISO100 camera JPEG",len(pixels))):
            data=np.load(checked(roi["camera_JPEGs"][role]["pixels"]),allow_pickle=False)
            image=linear_to_srgb(np.clip(srgb_to_linear(data.astype(np.float32)/255)*exp,0,1))
            pixels.insert(pos if pos==0 else len(pixels),(title,image))
    board=Image.new("RGB",(8+168*len(pixels),192),"#eeeeee")
    draw=ImageDraw.Draw(board)
    rectangles=[]
    prepared=[]
    for index,(label,data) in enumerate(pixels):
        x=8+168*index
        value=np.rint(np.clip(data,0,1)*255).astype(np.uint8)
        assert value.shape==(160,160,3)
        board.paste(Image.fromarray(value),(x,24))
        draw.text((x,5),label,fill="black")
        rectangles.append({"label":label,"png_xywh":[x,24,160,160]})
        prepared.append(value)
    path=output/(case["id"]+".png")
    board.save(path)
    readback=np.asarray(Image.open(path))
    for r,value in zip(rectangles,prepared,strict=True):
        x,y,w,h=r["png_xywh"]
        np.testing.assert_array_equal(readback[y:y+h,x:x+w],value)
    return {"image":reference(path),"panels":rectangles}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan",action="store_true")
    freeze() if parser.parse_args().plan else compare()
