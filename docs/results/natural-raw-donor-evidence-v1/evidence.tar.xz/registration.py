"""Try short-range registration before auditing copied fine RAW structure."""

from pathlib import Path
import argparse

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from probe import AUDIT, BLOCK, BX, BY, DESIGN, NUISANCES, PLAN, PRIOR, REGION, ROOT, SIZE, SPLIT
from probe import donor_candidates, filtered, measurements, nuisance_qr, scores, tile, unpack

REG_PLAN=ROOT/"registration-plan.json"
OFFSETS=[(y,x)for y in range(-4,5,2)for x in range(-6,7,2)]


def freeze():
    write_json(REG_PLAN,{
        "driver":reference(__file__),"probe_plan":reference(PLAN),
        "probe_source":reference(ROOT/"probe.py"),"fixed_registration_summary":reference(ROOT/"summary.json"),
        "native_offsets_yx":OFFSETS,"match_cutoff":4.,"fine_cutoff":AUDIT,
        "bank":["shifted","disjoint-neighbor"],
        "support_contract":"Each half chooses a coarse band template from the fixed bank of even native translations. Both halves must select the same candidate and have coarse z>4. The existing fine donor-coarse fit and two held-out gain checks then approve or withhold transfer. No alignment fitted from clean targets, the parent, or a combined query.",
    })


def shifted_view(a, offset):
    dy,dx=offset
    return np.roll(a,(dy,dx),axis=(-2,-1))


def prepare_bank(donors, colors):
    cfa=np.asarray(colors).reshape(2,2)[BY%2,BX%2]
    layouts=[[(cfa==color)&mask for color in range(3)]for mask in (SPLIT,~SPLIT)]
    variants=[]
    terms=[]
    for name, packed in donors.items():
        levels=filtered(packed)
        coarse=levels[1]-levels[2]
        for offset in OFFSETS:
            shift=shifted_view(coarse,offset)
            variants.append((name,offset,levels))
            terms.append(tile(shift[REGION]))
    matrix=np.stack(terms)
    banks=[]
    for mask_set in layouts:
        order=[]
        for mask in mask_set:
            basis=np.linalg.qr(DESIGN[mask],mode="reduced")[0]
            elements=matrix[:,:,mask]
            orth=elements-np.einsum("id,mbd->mbi",basis,np.einsum("id,mbi->mbd",basis,elements))
            order.append((mask,orth,orth*orth))
        banks.append(order)
    return variants,banks


def register(raw, colors, sensor, prepared):
    variants,banks=prepared
    query=tile(raw[REGION])
    results=[]
    for channel_banks in banks:
        prediction=np.zeros(len(variants))
        norm=np.zeros_like(prediction)
        for mask, shape, shape_sq in channel_banks:
            probe=query[:,mask]
            weight=1/(sensor["shot"]*np.maximum(1.e-4,probe.mean(axis=1))+sensor["read"])
            prediction+=np.einsum("mbi,bi,b->m",shape,probe,weight)
            norm+=np.einsum("mbi,b->m",shape_sq,weight)
        score=prediction/np.sqrt(np.maximum(norm,1e-16))
        winner=int(np.argmax(score))
        results.append((winner,float(score[winner])))
    agrees = results[0][0]==results[1][0]
    trace={"reserved_winners":[[variants[i][0],list(variants[i][1]),z]for i,z in results],
           "consensus":agrees,"coarse_pass":agrees and min(z for _,z in results)>4.}
    if not trace["coarse_pass"]:
        return trace,None
    name,offset,levels=variants[results[0][0]]
    aligned=[shifted_view(level,offset)for level in levels]
    outcome=scores(measurements(raw,aligned,colors,sensor,True))
    accepted=outcome["both_gains_positive"] and outcome["min_z"]>AUDIT
    trace|={"accepted":accepted,"fine":outcome,"donor":name,"offset":list(offset)}
    return trace, (name,offset,aligned) if accepted else None


def evaluate(shard):
    frozen=read_json(REG_PLAN)
    assert checked(frozen["driver"])==Path(__file__)
    plan=read_json(checked(frozen["probe_plan"]))
    scores_out=[]
    for binding in plan["photo_receipts"]:
        scene=read_json(checked(binding))
        if scene["case"]%2!=shard:
            continue
        with np.load(checked(scene["input"]),allow_pickle=False)as store:
            packed, colors, full = (store[k]for k in ("packed","colors","scene_packed"))
        assert fingerprint(packed)==scene["fingerprints"]["packed"]
        donors=donor_candidates(full,scene["box"])
        chosen={}
        for role in frozen["bank"]:
            if role not in donors:
                continue
            ready=prepare_bank({role:donors[role][0]},colors)
            outputs=[]
            for raw in packed:
                trace,result=register(unpack(raw),colors,scene["profile"],ready)
                outputs.append(trace)
            chosen[role]=outputs
        scores_out.append({"case":scene["case"],"profile":scene["profile"]["name"],"draw":scene["draw"],
                           "source":scene["source"],"observation":binding,"donors":chosen})
        if len(scores_out)%16==0:
            print(shard,len(scores_out),flush=True)
    assert len(scores_out)==128
    write_json(ROOT/f"registration-{shard}.json",{"plan":reference(REG_PLAN),"rows":scores_out})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("plan","collect"))
    parser.add_argument("--shard",type=int,choices=(0,1))
    args=parser.parse_args()
    freeze() if args.action=="plan" else evaluate(args.shard)
