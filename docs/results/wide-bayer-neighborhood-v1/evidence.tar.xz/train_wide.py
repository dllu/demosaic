"""Train the directional control and two wider, disjoint Bayer variants."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import sys
import time

import numpy as np
import torch

from wide_mixture import ROOT,DIRECTIONAL,PRIOR,Mixture,EXPERTS,DESCRIPTORS,inputs
from direction import FABRIC
from mixture import complex_parts
from train_directions import losses,samples
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from head_corrected_broad import EXACT_FLAT,NATIVE_I,NATIVE_J,SYNTH,exterior
from train_gap_head import SEED,EPOCHS,PHOTOS,choose_tiles,objective
from review_quiet import load


ARMS=("directional-replay","ring8","split-axis")
TILES=("descriptor","experts","correction")


def extract(case,binding,networks):
    pointer=read_json(checked(binding["measurement"]))
    assert pointer["index"]==binding["index"]==case["index"]
    base=np.load(checked(binding["parent"]),allow_pickle=False)
    with np.load(checked(pointer["input"]),allow_pickle=False)as stored:
        data={k:stored[k]for k in ("packed","scene_packed","colors","wb","matrix")}
    cfa=data["colors"][0]
    env=exterior(data["scene_packed"],cfa,case["noise"],case["box"])
    assert env is not None
    results={}
    for mode in ARMS[1:]:
        stack=[inputs(raw,layout,case["noise"],case["box"],env,starting,wb,matrix,networks,mode=mode)
               for raw,layout,starting,wb,matrix in zip(data["packed"],data["colors"],base,data["wb"],data["matrix"],strict=True)]
        norm=np.maximum(np.mean([r[1]for r in stack[:2]],axis=0),.002)
        results[mode]={"descriptor":np.stack([row[-1]for row in stack]),
                       "experts":np.stack([row[-2]for row in stack]),
                       "correction":np.stack([complex_parts(row[2]/norm)for row in stack]),
                       "normalized_parent":np.stack([complex_parts(row[0].basis[...,0]/norm)for row in stack])}
    return results


def prepare():
    torch.set_num_threads(1)
    sources=reference(FABRIC/"features.json")
    old=read_json(checked(sources))
    parents=read_json(checked(old["prior_training_parents"]))
    recipe=read_json(checked(parents["plan"]))
    component,receipt,head=load(raw_weights=False)
    assert old["frozen_phase_checkpoint"]==head["checkpoint"] and old["parent"]==head["parent"]
    checks=np.load(checked(old["tensors"]["baseline"]),allow_pickle=False,mmap_mode='r')
    arms={}
    start=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        panels=pool.map(lambda case:extract(*case,component["witness-gated"]),zip(recipe["batches"],parents["rows"],strict=True))
        for i,all_arms in enumerate(panels):
            for name,row in all_arms.items():
                np.testing.assert_array_equal(row["normalized_parent"].astype(np.float16),checks[i])
                fields=arms.setdefault(name,{})
                directory=ROOT/name
                directory.mkdir(exist_ok=True)
                for key in TILES:
                    values=row[key]
                    assert np.isfinite(values).all()
                    if key not in fields:
                        fields[key]=np.lib.format.open_memmap(directory/(key+".npy"),mode="w+",dtype=np.float16,
                                                           shape=(len(parents["rows"]),*values.shape))
                    fields[key][i]=values
            if (i+1)%28==0:
                print(i+1,round(time.monotonic()-start,1),flush=True)
    for fields in arms.values():
        for values in fields.values():
            values.flush()
    write_json(ROOT/"features.json",{"driver":reference(__file__),"operator":reference(ROOT/"wide_witness.py"),
        "mixture":reference(ROOT/"wide_mixture.py"),"parent":parents["checkpoint"],"sources":len(parents["rows"]),
        "prior_features":sources,"frozen_phase":head["checkpoint"],"frozen_phase_receipt":receipt,
        "tensors":{mode:{k:reference(ROOT/mode/(k+".npy"))for k in values}for mode,values in arms.items()},
        "seconds":time.monotonic()-start,"matched_basis_target":True,
        "scope":"Reuse the identical target,parent,void and noise basis. Exterior donor geometry replaces every nomination-dependent input."})


def train():
    torch.set_num_threads(1)
    torch.manual_seed(SEED)
    device="cuda"
    total=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/total))
    features=reference(ROOT/"features.json")
    wide=read_json(checked(features))
    old_dir=reference(DIRECTIONAL/"training/completed.json")
    earlier=read_json(checked(old_dir))
    prev=read_json(checked(earlier["features"]))
    assert earlier["features"]==wide["prior_features"]
    weight=earlier["gradient_match"]["weights"]["directional"]
    arrays={name:np.load(checked(v),allow_pickle=False,mmap_mode="r")for name,v in prev["tensors"].items()}
    projections={k:np.load(checked(v),allow_pickle=False,mmap_mode="r")
                 for k,v in read_json(checked(earlier["directions"]))["tensors"].items()}
    later={name:{key:np.load(checked(path),allow_pickle=False,mmap_mode="r")for key,path in sources.items()}
           for name,sources in wide["tensors"].items()}
    base=Mixture(adaptive=True).to(device)
    networks={name:deepcopy(base)for name in ARMS}
    ema={name:deepcopy(model).requires_grad_(False)for name,model in networks.items()}
    optimizer=torch.optim.AdamW([p for model in networks.values()for p in model.parameters()],lr=.001,weight_decay=.001)
    taper=torch.tensor(SYNTH**2,device=device,dtype=torch.float32)
    coordinates=tuple(torch.tensor(v,device=device)for v in (NATIVE_I,NATIVE_J))
    rng=np.random.default_rng(SEED)
    progress=[]
    count=wide["sources"]
    step=0
    updates=count//PHOTOS*EPOCHS
    start=time.monotonic()
    for epoch in range(EPOCHS):
        groups=rng.permutation(count)
        for offset in range(0,count,PHOTOS):
            ids=groups[offset:offset+PHOTOS]
            tile=choose_tiles(rng,arrays["void_weight"],ids)
            data=samples(arrays,projections,ids,tile,device)
            flat=torch.as_tensor(EXACT_FLAT[tile],device=device)
            step+=1
            optimizer.param_groups[0]["lr"]=float(.001*step/24 if step<=24 else
                 .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(updates-24))))
            optimizer.zero_grad(set_to_none=True)
            stats={}
            for name in ARMS:
                model=networks[name]
                bit=data
                if name in later:
                    bit={key:torch.from_numpy(np.asarray([a[p][:,cell]
                         for p,cell in zip(ids,tile,strict=True)],dtype=np.float32)).to(device)for key,a in later[name].items()}
                prediction=model(bit["descriptor"],bit["correction"],bit["experts"])
                prior,error,pair=objective(prediction,data["target"],data["baseline"],flat)
                detail=losses(error,data,taper,coordinates)[2]
                loss=prior+float(weight)*detail
                loss.backward()
                magnitude=torch.nn.utils.clip_grad_norm_(tuple(model.parameters()),2.)
                assert torch.isfinite(magnitude)
                stats[name]=torch.stack((loss,prior,detail,pair,magnitude)).detach()
            optimizer.step()
            with torch.no_grad():
                for name in ARMS:
                    torch._foreach_lerp_(tuple(ema[name].parameters()),tuple(networks[name].parameters()),.01)
            if step==1 or step%48==0 or step==updates:
                sample={k:v.cpu().tolist()for k,v in stats.items()}
                progress.append({"step":step,"losses":sample})
                print(step,round(time.monotonic()-start,2),sample,flush=True)
    torch.cuda.synchronize()
    seconds=time.monotonic()-start
    checkpoint=torch.load(checked(earlier["checkpoint"]),weights_only=True,map_location="cpu")
    for kind,models in (("EMA",ema),("raw",networks)):
        assert all(torch.equal(v.cpu(),checkpoint[kind]["directional"][k])
                   for k,v in models["directional-replay"].state_dict().items())
    out=ROOT/"training"
    out.mkdir()
    target=out/f"step{step:06d}.pt"
    with target.open("xb")as stream:
        torch.save({"EMA":{k:m.state_dict()for k,m in ema.items()},"raw":{k:m.state_dict()for k,m in networks.items()},
                    "optimizer":optimizer.state_dict(),"updates":step,"seed":SEED},stream)
    write_json(out/"completed.json",{"driver":reference(__file__),"features":features,"prior_training":old_dir,
       "checkpoint":reference(target),"parent":earlier["parent"],"frozen_phase_checkpoint":earlier["frozen_phase_checkpoint"],
       "updates_per_head":step,"photos":count,"visits_per_head":count*EPOCHS,"queries_per_head":count*EPOCHS*3,
       "seconds":seconds,"EMA":.99,"seed":SEED,"epochs":EPOCHS,"optimizer":earlier["optimizer"],
       "control_reproduced_bit_for_bit":True,"experts":EXPERTS,"directional_weight":weight,
       "arms":{"directional-replay":"Nearest four donor control, exact replay",
       "ring8":"Nearest four plus four diagonal donors",
       "split-axis":"Diagonal group retained only for frequencies with positive coherent dot product"},
       "progress":progress})


if __name__=="__main__":
    {"prepare":prepare,"train":train}[sys.argv[1]]()
