"""Bind stricter all-bin flat thresholds to calibration and score held-out data."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import reference,read_json,checked,write_json

ROOT=Path(__file__).resolve().parent
target=.1
record=reference(ROOT/'detector-curves.json')
proof=read_json(checked(record))
level=np.asarray(proof['thresholds'])
modes=('nearest','ring8','split-axis')
threshold={}
for mode in modes:
    samples=[r['rates'][mode]['flat_any_bin'] for r in proof['calibration_rows']
             if r['rates'][mode]['flat_any_bin'] is not None]
    assert len(samples)==24
    rate=np.mean(samples,axis=0)
    assert rate.min() < target < rate.max()
    i=int(abs(rate-target).argmin())
    threshold[mode]={"index":i,"value":float(level[i]),"calibration_FPR":float(rate[i])}
rng=np.random.default_rng(199178)
results={}
for noise in ('iso400','iso6400'):
    cohort=[r for r in proof['holdout_rows']if r['profile']==noise]
    results[noise]={}
    for mode in modes:
        summary={}
        i=threshold[mode]['index']
        j=threshold['nearest']['index']
        for k in ('flat_any_bin','intact_match','gap_match','weak_free_any_in_bin'):
            rows=[r['rates']for r in cohort if r['rates'][mode][k] is not None]
            pair=np.asarray([[r[mode][k][i],r['nearest'][k][j]]for r in rows])
            diff=pair[:,0]-pair[:,1]
            interval=np.percentile(diff[rng.integers(0,len(rows),(4096,len(rows)))].mean(1),[2.5,97.5])
            summary[k]={"sources":len(rows),"mean":float(pair[:,0].mean()),"nearest":float(pair[:,1].mean()),
                          "difference":float(diff.mean()),"interval_95":interval.tolist()}
        results[noise][mode]=summary
write_json(ROOT/'strict-flat.json',{"driver":reference(__file__),"source":record,"target_all_bin_FPR":target,
           "thresholds":threshold,"reports":results})
