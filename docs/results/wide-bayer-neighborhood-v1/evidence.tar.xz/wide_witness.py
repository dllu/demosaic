"""Extend phase discovery to a wider disjoint Bayer neighborhood."""
from collections.abc import Mapping
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
from demosaic.cfa import PATTERNS
from demosaic.phase_witness import (
    ALLOWED, BASE, BAYER_OFFSETS, FREQ, GRID, INDEX, MEAN_RESPONSE, PENALTY, SIDE,
    STEP, UNIQUE, XI, YI, PhaseWitness, _choose_by_power, _consistency, _gather,
    _neighboring_pair, _neighborhood, _transform, _unit,
)

NEAR = ((-2,0),(2,0),(0,-2),(0,2))
CORNERS = ((-2,-2),(-2,2),(2,-2),(2,2))
AXIAL = ((-4,0),(4,0),(0,-4),(0,4))
MODES = ("nearest", "ring8", "ring12", "tangent", "tangent-rotated", "split-axis")
ROUTES = {key:(NEAR+CORNERS+AXIAL if key=="ring12" else NEAR+CORNERS) for key in MODES[1:]}

def slices(n,shift):
    if shift<0:
        return slice(-shift,n),slice(0,n+shift)
    return slice(0,n-shift),slice(shift,n)

def references(dy,dx):
    y,ys=slices(SIDE,dy)
    x,xs=slices(SIDE,dx)
    return (y,x),(ys,xs)

UNIT = UNIQUE.astype(np.float64)/np.linalg.norm(UNIQUE,axis=1,keepdims=True)
TRANSPORT = {key:np.exp(-2j*np.pi * 16 * STEP * (UNIQUE @ key)).astype(np.complex64)
             for key in NEAR+CORNERS+AXIAL}


def contributions(values, variance, offsets, orientation="uniform"):
    data=values.reshape(SIDE,SIDE,-1)
    sigma=variance.reshape(SIDE,SIDE)
    total=np.zeros_like(data)
    power=np.zeros_like(data.real)
    for d in offsets:
        query,donor=references(*d)
        if orientation=="uniform":
            weight=1.
        else:
            along=(UNIT@d)/np.linalg.norm(d)
            direction=1-along**2 if orientation=="tangent" else along**2
            weight=(.22+.78*direction).astype(np.float32)
        total[query]+=data[donor]*TRANSPORT[d]*weight
        power[query]+=sigma[donor][...,None] * weight**2
    return total.reshape(values.shape),power.reshape(values.shape)


def longer_sum(values, variance, mode):
    if mode not in ROUTES:
        raise ValueError(f"Unknown Bayer neighborhood {mode!r}")
    weights=mode if mode=="tangent" else "normal" if mode=="tangent-rotated" else "uniform"
    if mode=="split-axis":
        straight,v1=contributions(values,variance,NEAR)
        diagonal,v2=contributions(values,variance,CORNERS)
        # The diagonal donors influence the phase through corroborating support.
        # If both donor groups agree, retain the wider estimate.
        prod=(straight*diagonal.conj()).real
        agree=prod>0
        outer=straight+diagonal*agree
        outvar=v1+v2*agree
        return outer,outvar
    return contributions(values,variance,ROUTES[mode],weights)


def choose(source,variance, refine):
    selection=INDEX if refine else INDEX[:,:1]
    n=selection.shape[-1]
    power=abs(source)**2/variance.clip(min=4e-10)
    offset=np.where(ALLOWED[None,:,:n],power[:,selection]-PENALTY[...,:n],-np.inf).argmax(axis=-1)
    return offset,INDEX[np.arange(len(BASE))[None],offset]


def measure(
    raw: np.ndarray,
    layout: np.ndarray,
    noise: Mapping[str, float],
    *,
    refine: bool = True,
    pair_features: bool = False,
    mode: str = "nearest",
) -> PhaseWitness:
    """Measure signed evidence for sub-bin phase on one native 256-pixel query."""
    raw = np.asarray(raw, dtype=np.float32)
    layout = np.asarray(layout)
    if raw.shape != (4, 128, 128) or not np.isfinite(raw).all():
        raise ValueError("Expected a finite 4 × 128 × 128 packed Bayer query")
    if layout.shape != (4,) or tuple(layout) not in PATTERNS.values():
        raise ValueError("Expected four color indices in Bayer spatial phase order")
    shot, read = float(noise["shot"]), float(noise["read"])
    if min(shot, read) < 0 or not np.isfinite([shot, read]).all():
        raise ValueError("Expected finite nonnegative shot and read coefficients")
    transform, variance = _transform(raw, shot, read)
    green = np.flatnonzero(layout == 1)
    red, blue = (np.flatnonzero(layout == shade)[0] for shade in (0, 2))
    g0, g1 = (_gather(transform, plane) for plane in green)
    direct = (g0 + g1) * 0.5
    green_variance = variance[:, green].sum(1) * 0.25
    if mode == "nearest":
        source, exterior_var = _neighborhood(direct, green_variance, GRID)
        offsets, selected = _choose_by_power(source, exterior_var, refine)
        exterior_var = exterior_var[:, None]
    else:
        source, external_variance = longer_sum(direct,green_variance,mode)
        offsets, selected = choose(source,external_variance,refine)
        exterior_var = np.take_along_axis(external_variance,selected,axis=-1)

    external = np.take_along_axis(source, selected, axis=-1)
    external_phase = _unit(external)
    direct_phase = _unit(direct[:, BASE])
    refined_unit = _unit(np.take_along_axis(direct, selected, axis=-1))
    per_site = np.sqrt(variance)
    base = np.broadcast_to(BASE, selected.shape)
    local_color = np.stack(
        [
            ((_gather(transform, p, base) / per_site[:, p, None]) * direct_phase.conj()).real
            for p in (red, blue)
        ],
        axis=-1,
    )
    exterior_color = np.stack(
        [
            ((_gather(transform, p, selected) / per_site[:, p, None]) * external_phase.conj()).real
            for p in (red, blue)
        ],
        axis=-1,
    )
    exterior_green = np.stack(
        [
            (
                (np.take_along_axis(g, selected, axis=-1) / per_site[:, p, None])
                * external_phase.conj()
            ).real
            for p, g in zip(green, (g0, g1), strict=True)
        ],
        axis=-1,
    )
    strength = abs(external) / np.sqrt(exterior_var).clip(min=2e-5)
    agreement = (refined_unit * external_phase.conj()).real
    features = (
        np.concatenate(
            (
                np.arcsinh(local_color),
                np.arcsinh(exterior_color),
                np.arcsinh(exterior_green),
                np.log1p(strength)[..., None],
                agreement[..., None],
            ),
            axis=-1,
        )
        .clip(-6, 6)
        .astype(np.float32)
    )
    carrier = _unit(external_phase * MEAN_RESPONSE[offsets])
    amplitude = (np.take_along_axis(direct, selected, axis=-1) * external_phase.conj()).real
    amplitude = amplitude.clip(min=0) * abs(MEAN_RESPONSE[offsets])
    evidence = (exterior_color.mean(-1) - 0.4).clip(min=0)
    confidence = np.sqrt(evidence / (1 + evidence))
    local_noise = np.sqrt(variance[:, green].mean(1))[:, None]
    pairs = None
    if pair_features:
        vertical, vv = _neighboring_pair(direct, green_variance, 0)
        horizontal, hv = _neighboring_pair(direct, green_variance, 1)
        pairs = _consistency(vertical, horizontal, vv, hv, selected, refine)
    return PhaseWitness(
        features,
        FREQ[np.arange(len(BASE))[None], offsets],
        external_phase,
        strength,
        offsets,
        carrier,
        amplitude,
        confidence,
        local_noise,
        pairs,
    )
