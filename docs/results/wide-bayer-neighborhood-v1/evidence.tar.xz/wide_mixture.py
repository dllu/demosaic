"""Assemble the fixed mixture inputs from any registered Bayer donor geometry."""
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

from wide_witness import ROOT, measure
DIRECTIONAL=ROOT.parent/"directional-gap-training-v1"
sys.path.insert(0,str(DIRECTIONAL))
import direction
from mixture import Mixture, PRIOR, EXPERTS, DESCRIPTORS

from phase_edge import scores
from edge_choices import correction_parts
from activity import fields, reliability, rgb_residual, PRIOR
from demosaic.phase_witness import measure_witnesses
from models import extend
from head_corrected_broad import features

def inputs(raw, layout, noise, box, donors, parent, wb, matrix, model, target=None, *, mode="nearest"):
    phase = measure(raw,layout,noise,mode=mode)
    v, edge = scores(raw,layout,noise,phase,geometry=True)
    power=fields(raw,layout,noise)
    field=features(raw,layout,noise,box,donors,parent,wb,matrix,target)
    field=replace(field, inputs=np.concatenate((field.inputs,phase.features),axis=-1),
                  basis=extend(field.basis,phase))
    frozen=correction_parts(model,field)[0]
    experts=np.stack((
        np.zeros_like(v[0]),
        np.broadcast_to(1.5*reliability(power[0],0.,.30)[:,None],v[0].shape),
        1.31*reliability(v[1],.55,.75),
        1.5*reliability(v[3],0.,.75),
    ),axis=-1)
    series=(*[np.arcsinh(s)[:,None] for s in power[:3]],np.mean(edge>=0,axis=0)[:,None],
            np.arcsinh(v[0]),np.arcsinh(v[1]),np.arcsinh(v[3]),np.log1p(phase.exterior_z),
            np.log1p(abs(frozen)/phase.noise.clip(min=.002)),
            phase.features[...,4:6].mean(-1),phase.features[...,2:4].mean(-1))
    descriptor=np.stack(np.broadcast_arrays(*series),axis=-1).clip(-6,6).astype(np.float32)
    return field,phase.noise,frozen,experts,descriptor


