"""Check registered Bayer context against reserved raw samples on exact wire panels."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np
from scipy.stats import rankdata

from wide_witness import ROOT,MODES,NEAR,CORNERS,AXIAL,contributions,measure
from demosaic.phase_witness import (
    FREQ,GRID,SIDE,XI,YI,_neighborhood,_unit,measure_witnesses,taper,
)
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
sys.path.insert(0,str(ROOT.parent/"directional-gap-training-v1"))
import direction
from mixture import PRIOR
from phase_edge import scores


NATIVE=32
NY,NX=np.indices((NATIVE,NATIVE),dtype=np.float32)
CENTER=(SIDE//2)*SIDE+SIDE//2
CORE=(2*YI+16>=64)&(2*YI+16<192)&(2*XI+16>=64)&(2*XI+16<192)
PROFILES={"iso400":{"shot":8e-5,"read":2.56e-8},"iso6400":{"shot":.00128,"read":6.5536e-6}}


def dist(a,b):
    return np.minimum(np.linalg.norm(a-b,axis=-1),np.linalg.norm(a+b,axis=-1))


def auc(null, present):
    ranked=rankdata(np.r_[null,present])
    return float((ranked[len(null):].sum()-len(present)*(len(present)+1)/2)/(len(null)*len(present)))


def independence():
    random=np.random.default_rng(202611192)
    signal=(random.normal(size=(SIDE**2,len(GRID)))+1j*random.normal(size=(SIDE**2,len(GRID)))).astype(np.complex64)
    variance=random.uniform(1e-6,1e-4,SIDE**2).astype(np.float32)
    new=contributions(signal,variance,NEAR)
    left,right=_neighborhood(signal,variance,GRID)
    np.testing.assert_array_equal(left,new[0])
    np.testing.assert_array_equal(np.broadcast_to(right[:,None],new[1].shape),new[1])
    sub={d:np.zeros((SIDE,SIDE),bool)for d in ((0,0),*NEAR,*CORNERS,*AXIAL)}
    acquired=np.zeros((128,128),int)
    for n,(dy,dx) in enumerate(sub):
        by,bx=YI[CENTER]+dy*8,XI[CENTER]+dx*8
        acquired[by:by+16,bx:bx+16]+=1
    assert acquired.max()==1
    from demosaic.cfa import PATTERNS
    raw=random.normal(.14,.039,(4,128,128)).astype(np.float32)
    noise=PROFILES["iso6400"]
    for layout in PATTERNS.values():
        cfa=np.asarray(layout)
        for mode in MODES:
            base=measure(raw,cfa,noise,mode=mode)
            changed=raw.copy()
            y,x=YI[CENTER],XI[CENTER]
            changed[:,y:y+16,x:x+16]+=random.normal(0,.05,(4,16,16)).astype("float32")
            after=measure(changed,cfa,noise,mode=mode)
            np.testing.assert_array_equal(base.phase[CENTER],after.phase[CENTER])
            np.testing.assert_array_equal(base.offsets[CENTER],after.offsets[CENTER])
            np.testing.assert_array_equal(base.exterior_z[CENTER],after.exterior_z[CENTER])
        expected=measure_witnesses(raw,cfa,noise)
        for key in vars(expected):
            if key!="pair_features":
                np.testing.assert_array_equal(getattr(base if mode=="nearest" else measure(raw,cfa,noise),key),
                                              getattr(expected,key))
    return {"nearest_reproduces_bit_for_bit":True,"disjoint_center_and_donor_windows":13,
            "center_nomination_invariant_all_cfas":True}


def record(task,plan):
    scene=plan["sources"][task["index"]]
    noise=plan["profiles"][task["noise"]]
    weak=np.asarray(scene["geometry"]["frequency"][1])[::-1]
    near=int(np.argmin(dist(FREQ[:,0],weak)))
    x,y,w,h=plan["query"]
    assert w==h==256
    with np.load(checked(task["input"]),allow_pickle=False)as f:
        packed=f["packed"][:2,:,y//2:y//2+128,x//2:x//2+128]
        cfa=f["colors"][:2]
        support=f["support"]
        greentruth=f["target"][:2,1,y:y+256,x:x+256].astype(np.float64)
    core8=np.lib.stride_tricks.sliding_window_view(support,(8,8))[2*YI+12,2*XI+12].mean((1,2))
    intact=CORE&(core8>=.97)
    gap=CORE&(core8<=.01)
    dip=CORE&(core8>.01)&(core8<=.65)
    weak_win=np.lib.stride_tricks.sliding_window_view(greentruth[0]-greentruth[1],(32,32))[2*YI,2*XI]
    results={}
    for mode in MODES:
        ordinary=measure(packed[0],cfa[0],noise,mode=mode)
        absent=measure(packed[1],cfa[1],noise,mode=mode)
        metric=scores(packed[0],cfa[0],noise,ordinary)[1,:,near]
        quiet=scores(packed[1],cfa[1],noise,absent)[1,:,near]
        lookup=ordinary.frequency[:,near]
        delta=dist(lookup,weak)
        cosine=2*np.pi*(lookup[:,0,None,None]*NY+lookup[:,1,None,None]*NX)
        native_coefficient=(weak_win*taper*np.exp(-1j*cosine)).sum((1,2))
        angle=(_unit(native_coefficient)*ordinary.phase[:,near].conj()).real
        close=delta<=.015625
        threshold=metric>.55
        result={
            "mean_frequency_error":float(delta[intact].mean()),
            "mean_phase_cosine":float(angle[intact].mean()),
            "matched_intact":float(close[intact].mean()),
            "validated_intact":float((close&threshold)[intact].mean()),
            "positive_any_gap":float(threshold[gap].mean())if gap.any()else None,
            "validated_gap":float((close&threshold)[gap].mean())if gap.any()else None,
            "validated_weak_free":float((quiet[intact]>.55).mean()),
            "AUC_true_gap":auc(metric[gap],metric[intact])if gap.any()else None,
            "AUC_weak_free":auc(quiet[intact],metric[intact]),
            "intact_z":float(metric[intact].mean()),
            "dip_z":float(metric[dip].mean())if dip.any()else None,
        }
        assert all(np.isfinite(v) for v in result.values()if v is not None)
        results[mode]=result
    return {"profile":task["noise"],"source":scene["source"]["id"],"index":task["index"],
            "input":task["input"],"counts":[int(intact.sum()),int(gap.sum()),int(dip.sum())],"metrics":results}


def main(segment):
    b=reference(PRIOR/("wire-parent.json"if segment=="holdout"else "wire-tune-parent.json"))
    src=read_json(checked(b))
    plan=read_json(checked(src["plan"]))
    tasks=read_json(checked(src["inputs"]))["rows"]
    started=time.monotonic()
    checks=independence()
    with ThreadPoolExecutor(3)as pool:
        rows=[]
        for entry in pool.map(lambda row:record(row,plan),tasks):
            rows.append(entry)
            if len(rows)%12==0:
                print(segment,len(rows),round(time.monotonic()-started,2),flush=True)
    rng=np.random.default_rng(7577)
    out={}
    for iso in PROFILES:
        batch=[row["metrics"]for row in rows if row["profile"]==iso]
        if not batch:
            continue
        out[iso]={}
        for name in MODES:
            out[iso][name]={}
            for key in batch[0][name]:
                vals=np.array([[r["nearest"][key],r[name][key]]for r in batch if r[name][key]is not None])
                if len(vals):
                    dif=vals[:,1]-vals[:,0]
                    ci=np.percentile(dif[rng.integers(0,len(dif),(4096,len(dif)))].mean(1),[2.5,97.5])
                    out[iso][name][key]={"n":len(vals),"mean":float(vals[:,1].mean()),"delta":float(dif.mean()),"interval_95":ci.tolist()}
    write_json(ROOT/f'audit-{segment}.json',{"driver":reference(__file__),"operator":reference(ROOT/"wide_witness.py"),
               "plan":src["plan"],"input_source":src["inputs"],"parent_pointer":b,
               "checks":checks,"rows":rows,"reports":out,"seconds":time.monotonic()-started,
               "scope":"Known weaker wire selects a scoring bin and supplies exact projected phase only to measurement. "
                       "Nomination uses RAW from disjoint windows. Score uses the original reserved edge-background model."})

if __name__=="__main__":
    main(sys.argv[1])
