"""Compare reserved weak-wave detection at matched false activation."""
from concurrent.futures import ThreadPoolExecutor
import time

import numpy as np

from audit_wide import ROOT,CORE,measure,scores,dist
from mixture import PRIOR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.phase_witness import FREQ,XI,YI

MODES=("nearest","ring8","split-axis")
LEVELS=np.unique(np.r_[np.arange(-.50,2.51,.025), .55])
PRIMARY=int(np.flatnonzero(LEVELS==.55)[0])
SAME=.015625


def rates(score,mask):
    if not mask.any():
        return None
    return (score[mask,None]>LEVELS[None]).mean(axis=0).tolist()


def source(task,plan):
    scene=plan["sources"][task["index"]]
    noise=plan["profiles"][task["noise"]]
    f=np.asarray(scene["geometry"]["frequency"][1])[::-1]
    k=int(np.argmin(dist(FREQ[:,0],f)))
    x,y,w,h=plan["query"]
    assert w==h==256
    with np.load(checked(task["input"]),allow_pickle=False) as file:
        packed=file["packed"][[0,1,3],:,y//2:y//2+128,x//2:x//2+128]
        cfa=file["colors"][[0,1,3]]
        support=file["support"]
        # Restrict the flat check to genuinely constant exact RGB rectangles.
        flat=file["target"][3,:,y:y+256,x:x+256]
    weak_center=np.lib.stride_tricks.sliding_window_view(support,(8,8))[2*YI+12,2*XI+12].mean((1,2))
    flat_windows=np.lib.stride_tricks.sliding_window_view(flat,(32,32),axis=(-2,-1))[:,2*YI,2*XI]
    flat_region=CORE&(np.ptp(flat_windows,axis=(-2,-1)).max(0)<=1e-6)
    intact=CORE&(weak_center>=.97)
    gap=CORE&(weak_center<=.01)
    results={}
    for mode in MODES:
        phases=[measure(a,b,noise,mode=mode)for a,b in zip(packed,cfa,strict=True)]
        evidence=[scores(a,b,noise,phase)[1]for a,b,phase in zip(packed,cfa,phases,strict=True)]
        matched=[dist(phase.frequency[:,k],f)<=SAME for phase in phases[:2]]
        present=np.where(matched[0],evidence[0][:,k],-np.inf)
        wholly_absent=np.where(matched[1],evidence[1][:,k],-np.inf)
        results[mode]={"intact_match":rates(present,intact),"gap_match":rates(present,gap),
           "weak_free_match":rates(wholly_absent,intact),"weak_free_any_in_bin":rates(evidence[1][:,k],intact),
           "flat_any_bin":rates(evidence[2].max(1),flat_region)}
    return {"index":task["index"],"source_id":scene["source"]["id"],"input":task["input"],"profile":task["noise"],
            "exact_flat_windows":int(flat_region.sum()),"rates":results}


def collect(panel):
    tag="wire-tune-parent.json"if panel=="calibration"else "wire-parent.json"
    anchor=reference(PRIOR/tag)
    data=read_json(checked(anchor))
    plan=read_json(checked(data["plan"]))
    tasks=read_json(checked(data["inputs"]))["rows"]
    with ThreadPoolExecutor(3)as pool:
        rows=list(pool.map(lambda row:source(row,plan),tasks))
    return anchor,rows


def main():
    started=time.monotonic()
    cal,train=collect("calibration")
    holdout,test=collect("holdout")
    assert len(train)==24 and len(test)==48
    assert not {r['source_id']for r in train} & {r['source_id']for r in test}
    accept=[]
    for metric in ("weak_free_any_in_bin","gap_match","flat_any_bin"):
        choices={}
        matrix={}
        for mode in MODES:
            matrix[mode]=np.array([r["rates"][mode][metric]for r in train if r["rates"][mode][metric]is not None])
        desired=float(matrix["nearest"][:,PRIMARY].mean()) if len(matrix["nearest"]) else None
        if desired is None:
            continue
        for mode in MODES:
            vals=matrix[mode].mean(axis=0)
            candidates=np.flatnonzero(abs(vals-desired)<=abs(vals-desired).min()+1e-12)
            k=int(candidates[np.argmin(abs(LEVELS[candidates]-.55))])
            choices[mode]={"index":k,"threshold":float(LEVELS[k]),"calibration_rate":float(vals[k])}
        accept.append({"calibrated_to":metric,"target":desired,"choices":choices})
    rng=np.random.default_rng(349810)
    out={}
    for row in accept:
        target=row["calibrated_to"]
        out[target]={}
        for profile in ("iso6400","iso400"):
            out[target][profile]={}
            for method in MODES:
                index=row["choices"][method]["index"]
                stats={}
                for kind in ("intact_match","gap_match","weak_free_any_in_bin","flat_any_bin"):
                    pair=[(r["rates"][method][kind][index],r["rates"]["nearest"][kind][PRIMARY])for r in test
                          if r["profile"]==profile and r["rates"][method][kind]is not None]
                    if len(pair)==0:
                        continue
                    pair=np.asarray(pair)
                    dif=pair[:,0]-pair[:,1]
                    ci=np.percentile(dif[rng.integers(0,len(dif),(4000,len(dif)))].mean(1),[2.5,97.5])
                    stats[kind]={"sources":len(pair),"mean":float(pair[:,0].mean()),"nearest":float(pair[:,1].mean()),
                                 "delta":float(dif.mean()),"interval_95":ci.tolist()}
                out[target][profile][method]=stats
    write_json(ROOT/"detector-curves.json",{"driver":reference(__file__),"calibration":cal,"holdout":holdout,
      "thresholds":LEVELS.tolist(),"policies":accept,"reports":out,"calibration_rows":train,"holdout_rows":test,
      "seconds":time.monotonic()-started,"scope":"Source-level thresholds fitted at ISO6400 on 24 disjoint calibration sources. "
           "Intact and true-gap weak matches use the planted scored bin; flat uses max across every candidate within the exact constant footprint."})


if __name__=="__main__":
    main()
