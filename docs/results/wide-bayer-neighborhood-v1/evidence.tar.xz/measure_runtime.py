"""Measure the cost of changing donor support on a fixed native cab query."""
import os
from pathlib import Path
import time

import numpy as np

from wide_witness import ROOT,measure
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    path=Path('docs/images/directional-gap-training-v1/manifest.json')
    case=next(r for r in read_json(path)['standing']['rows'] if r['id']=='mesh-profile3879-fine-green-mesh-right')
    old=read_json('configs/gfx-green-mesh-20231231.json')
    x,y=case['native_box'][:2]
    cx,cy=old['raw_context_xywh'][:2]
    x,y=(x-cx)//2,(y-cy)//2
    assert min(x,y)>=0
    with np.load(checked(case['input']),allow_pickle=False) as data:
        raw=data['packed'][0,:,y:y+128,x:x+128].copy()
        colors=data['colors'][0]
    assert raw.shape==(4,128,128)
    pins=os.sched_getaffinity(0)
    pin=max(pins)
    os.sched_setaffinity(0,[pin])
    rows={mode:[]for mode in ('nearest','ring8','split-axis')}
    for mode in rows:
        measure(raw,colors,case['noise'],mode=mode)
    for i in range(18):
        ordered=list(rows)
        ordered=ordered[i%3:]+ordered[:i%3]
        for mode in ordered:
            start=time.perf_counter()
            measure(raw,colors,case['noise'],mode=mode)
            rows[mode].append(time.perf_counter()-start)
    write_json(ROOT/'runtime.json',{'driver':reference(__file__),'source':case['input'],'noise':case['noise'],
                'native_box':case['native_box'],'CPU_affinity':[pin],'recorded':rows,
                'median_ms':{k:float(np.median(v)*1000)for k,v in rows.items()},
                'scope':'18 interleaved warm calls per method. Bayer witness extraction only; excludes reserved edge score and restoration.'})


if __name__=='__main__':
    main()
