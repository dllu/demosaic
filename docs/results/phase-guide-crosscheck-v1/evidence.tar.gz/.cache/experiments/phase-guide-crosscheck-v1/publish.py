"""Publish native phase guide cross-check comparisons and their executed analysis."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
review = root / "review"
report = read_json(review / "result.json")
summary = read_json(review / "summary.json")
audit = read_json(review / "independent-audit.json")
seen = read_json(review / "actual-native-viewing.json")
assert len(report["metrics"]) == 128 and len(summary["means"]) == 16
assert audit["status"] == "passed" and audit["independent_reductions"] == 960
assert len(seen["boards"]) == 12 and all(v["viewed"] for v in seen["boards"])
images = repo / "docs/images/phase-guide-crosscheck-v1"
results = repo / "docs/results/phase-guide-crosscheck-v1"
images.mkdir()
results.mkdir()
items = []
for kind, row in [(k, v) for v in report["boards"] for k in ("board", "triplet")] + [
    ("camera", v) for v in report["camera"]
]:
    info = row if kind == "camera" else row[kind]
    source = checked(info["image"])
    dest = images / source.name
    shutil.copyfile(source, dest)
    fingerprint = reference(dest)
    assert fingerprint["sha256"] == info["image"]["sha256"]
    items.append({"id": row["id"], "kind": kind, "published": fingerprint, "native": row})
assert len(items) == 16
write_json(
    images / "manifest.json",
    {
        "images": items,
        "viewing": reference(review / "actual-native-viewing.json"),
        "scope": "Fresh synthetic inputs and both standing GFX families. All crops at native 160×160.",
    },
)
for name in ("summary.json", "independent-audit.json", "actual-native-viewing.json"):
    shutil.copyfile(review / name, results / name)
    assert reference(review / name)["sha256"] == reference(results / name)["sha256"]
bundle = results / "evidence.tar.gz"
members = []
with (
    bundle.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped,
    tarfile.open(fileobj=zipped, mode="w") as tar,
):
    for path in sorted(root.rglob("*")):
        if (
            path.is_file()
            and path.suffix in (".py", ".json", ".log")
            and "__pycache__" not in path.parts
        ):
            member = str(path.relative_to(repo))
            members.append({"member": member, **reference(path)})
            tar.add(path, arcname=member, recursive=False)
with tarfile.open(bundle) as tar:
    for x in members:
        assert hashlib.sha256(tar.extractfile(x["member"]).read()).hexdigest() == x["sha256"]
write_json(
    results / "publication.json",
    {
        "archive": reference(bundle),
        "members": members,
        "all_member_hashes_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "boards_opened": 12,
        "metric_rows": 128,
        "nested_reductions_recomputed": 370,
        "scope": "Nested green-site guide validation replay and both standing GFX families.",
    },
)
print(len(members), len(items), "publication verified")
