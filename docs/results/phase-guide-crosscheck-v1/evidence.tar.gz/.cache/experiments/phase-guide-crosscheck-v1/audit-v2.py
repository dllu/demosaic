"""Independently check the nested prediction comparisons, metrics and native cells."""

from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image
from report_fold_support_pooling import evaluated
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split

root = Path(__file__).resolve().parent
report_path = root / "review/result.json"
report = read_json(report_path)
plan = read_json(checked(report["plan"]))
closed = read_json(checked(report["collection"]))
assert closed["synthetic_fits"] == 96 and closed["camera_fits"] == 8
roi = np.s_[..., 128:384, 128:384]
yy, xx = np.indices((256, 256))
x, y = (xx + 0.5) / 128 - 1, (yy + 0.5) / 128 - 1
base = np.stack((np.ones(x.shape), x, y), axis=-1)
inner = stratified_split(x.shape, 202611170713)
outer = stratified_split(x.shape, plan["config"]["split_seed"])
counts = Counter()
differences = []


def project(weighted, target):
    return np.linalg.pinv(weighted, rcond=1e-10) @ target


def replay(sensor, cfa, fit, noise, cohort):
    raw = np.empty((256, 256))
    for i, plane in enumerate(sensor):
        raw[i // 2 :: 2, i % 2 :: 2] = plane
    green = np.tile(cfa.reshape(2, 2), (128, 128)) == 1
    row = fit["records"][0]
    for fold, (angle, offset) in enumerate(row["edges"]):
        signed = x * np.cos(angle) + y * np.sin(angle) - offset
        h = outer if fold == 0 else ~outer
        use = green & h
        design = np.concatenate((base, (signed > 0)[..., None]), axis=-1)
        nuisance = design[use]
        b = project(nuisance, raw[use])
        peak = max(float((nuisance @ b).max()), 1e-6)
        if abs(b[3]) > 2 * np.sqrt(noise["read"] + noise["shot"] * peak):
            distance = abs(signed) / np.hypot(np.cos(angle) / 128, np.sin(angle) / 128)
            use &= distance >= 8
        assert (green & h).sum() - use.sum() == row["guide_search_excluded"][fold]
        nuisance = design[use]
        gx, gy = xx[use], yy[use]
        sig = raw[use]
        choice = list(fit["guide_frequencies_xy"])
        path = row["guide_crosschecks"][fold]
        for step in path:
            j = step["direction"]
            assert step["origin_xy"] == choice[j] and step["full_discovery_gain"] > 4
            other = choice[1 - j]
            phase = np.mod(other[0] * gx + other[1] * gy, 1.0) * 8
            i = np.floor(phase).astype(int)
            t = phase - i
            knots = (1 - t[:, None]) * (i[:, None] % 8 == np.arange(8)) + t[:, None] * (
                (i[:, None] + 1) % 8 == np.arange(8)
            )
            base_shape = np.column_stack((nuisance, knots[:, :7] - knots[:, 7:]))
            candidates = []
            for fx, fy in (step["origin_xy"], step["proposed_xy"]):
                phi = 2 * np.pi * (fx * gx + fy * gy)
                candidates.append(np.column_stack((base_shape, np.cos(phi), np.sin(phi))))
            gains = []
            for learn in (inner[use], ~inner[use]):
                test = ~learn
                proxy = nuisance @ project(nuisance[learn], sig[learn])
                weight = np.sqrt(1 / (noise["read"] + noise["shot"] * np.maximum(proxy, 1e-6)))
                errors = []
                for a in candidates:
                    trained = project(a[learn] * weight[learn, None], sig[learn] * weight[learn])
                    errors.append(
                        float(np.sum(((sig[test] - a[test] @ trained) * weight[test]) ** 2))
                    )
                gains.append(errors[0] - errors[1])
            np.testing.assert_allclose(gains, step["nested_error_reductions"], atol=3e-9, rtol=0)
            assert (min(gains) > 0) == step["accepted"]
            if step["accepted"]:
                choice[j] = step["proposed_xy"]
            counts[cohort, "proposed"] += 1
            counts[cohort, "accepted"] += step["accepted"]
            differences.extend(abs(np.array(gains) - step["nested_error_reductions"]))
        assert choice == row["frequencies"][fold]


def rms(value):
    return np.sqrt(np.mean(value**2)) * 65535


def proj(a, b):
    return float(np.sum(a * b) / np.sum(b * b))


scored = defaultdict(list)
for r in report["metrics"]:
    scored[r["id"]].append(r)
reductions = 0
for link in closed["synthetic"]:
    item = read_json(checked(link))
    c = read_json(checked(item["case"]))
    parent = np.load(checked(c["parent"])).astype(np.float64)
    with np.load(checked(c["sensor"])) as raw:
        for i, fit in enumerate(item["fits"]):
            replay(
                raw["packed"][i, :, 64:192, 64:192],
                raw["colors"][i],
                fit,
                plan["profiles"][c["profile"]],
                c["profile"] + "-" + c["placement"],
            )
    with np.load(checked(c["target"])) as gt:
        truth, quiet = gt["target"].astype(np.float64), gt["quiet"][roi]
    weak, strong = np.diff(truth, axis=0)[::-1]
    with (
        np.load(checked(item["prediction"])) as new,
        np.load(checked(item["control_prediction"])) as old,
    ):
        for r in scored[c["id"]]:
            t = r["threshold"]
            stem = item["control_prefix"] + (
                "--" if c["placement"] == "near" else "--weighted-refit-"
            )
            f = new[f"t{t:g}"] if r["arm"] == "crosschecked" else old[f"{stem}t{t:g}"]
            out = parent.copy()
            scale = r["scale"]
            out[roi] = (1 - scale) * parent[roi] + scale * f.astype(np.float64)
            err = out - truth
            a, b = np.diff(out, axis=0)[::-1]
            values = {
                "weak_gain": proj(a, weak),
                "strong_gain": proj(b, strong),
                "quiet_RMS_DN16": rms(err[roi][..., quiet]),
                "weak_increment_RMS_DN16": rms(a - weak),
                "query_RMS_DN16": rms(err[roi]),
                "weak_absent_projection": proj(err[1], weak),
            }
            if c["placement"] == "near":
                recipe = c["metadata"]["recipe"]
                bx, by = xx + 128.5 - recipe["size"] / 2, yy + 128.5 - recipe["size"] / 2
                d = (
                    bx * np.cos(recipe["edge_angle"])
                    + by * np.sin(recipe["edge_angle"])
                    - recipe["edge_jitter"]
                )
                dark, bright = d < -2, d > 2
                values.update(
                    dark_weak_gain=proj(a[roi][:, dark], weak[roi][:, dark]),
                    bright_weak_gain=proj(a[roi][:, bright], weak[roi][:, bright]),
                    no_wire_edge_RMS_DN16=rms(err[0][roi][:, abs(d) <= 8]),
                )
            for k, v in values.items():
                np.testing.assert_allclose(v, r[k], atol=4e-10, rtol=0)
                reductions += 1


def crop(img, panel):
    a, b, w, h = panel["png_xywh"]
    assert (w, h) == (160, 160)
    return img.crop((a, b, a + w, b + h)).tobytes()


previous = read_json(checked(plan["camera_report"]))
camera_plan = read_json(checked(plan["camera_conditions"]))
camera = []
kept = 0
for prior, new, binding, near in zip(
    previous["camera"], report["camera"], closed["camera"], camera_plan["camera"], strict=True
):
    assert prior["id"] == new["id"] == binding["id"] == near["board"]["id"]
    old_image, new_image = [Image.open(checked(v["image"])) for v in (prior, new)]
    for a, b in zip(
        prior["panels"],
        [v for v in new["panels"] if v["label"] != "Cross-checked guide"],
        strict=True,
    ):
        assert a["label"] == b["label"] and crop(old_image, a) == crop(new_image, b)
        kept += 1
    s = new["source"]
    a, b, w, h = new["ROI_xywh"]
    x0, y0, xw, yh = s["query_box"]
    with np.load(checked(s["query_arrays"])) as data:
        replay(
            data["packed"][0, :, y0 // 2 : (y0 + yh) // 2, x0 // 2 : (x0 + xw) // 2],
            data["colors"][0],
            binding["fit"],
            near["noise"],
            new["id"],
        )
    with np.load(checked(binding["prediction"])) as z:
        actual = z["corrected"][:, b - y0 : b - y0 + h, a - x0 : a - x0 + w].astype(np.float64)
    parent = np.load(checked(s["parent_prediction"]), mmap_mode="r")[0, :, b : b + h, a : a + w]
    v120 = next(p for p in new["panels"] if p["label"] == "V120 EMA")
    cross = next(p for p in new["panels"] if p["label"] == "Cross-checked guide")
    camera.append(
        {
            "id": new["id"],
            "minus_control_rms_DN16": new["change_DN16"],
            "minus_V120_RMS_DN16": float(rms(actual - parent)),
            "display_equals_V120": crop(new_image, v120) == crop(new_image, cross),
        }
    )
for b in report["boards"]:
    full, trip = [Image.open(checked(b[k]["image"])) for k in ("board", "triplet")]
    for i, p in zip((0, 3, 4), b["triplet"]["panels"], strict=True):
        assert crop(full, b["board"]["panels"][i]) == crop(trip, p)
assert kept == 152 and reductions == 960
audit = root / "review/independent-audit.json"
write_json(
    audit,
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "status": "passed",
        "independent_reductions": reductions,
        "retained_camera_cells": kept,
        "selection_counts": {
            name: {k: n for (a, k), n in counts.items() if a == name} for name, _ in counts
        },
        "nested_reductions_recomputed": len(differences),
        "max_nested_difference": float(max(differences, default=0)),
        "camera": camera,
    },
)
groups = defaultdict(list)
for row in report["metrics"]:
    groups[row["profile"], row["placement"], row["budget_DN16"], row["arm"]].append(row)
means = []
keys = ("weak_gain", "quiet_delta_DN16", "weak_increment_RMS_DN16", "weak_absent_projection")
for (p, placement, budget, arm), rows in groups.items():
    assert len(rows) == 8
    names = keys + (("dark_weak_gain", "bright_weak_gain") if placement == "near" else ())
    means.append(
        {
            "profile": p,
            "placement": placement,
            "budget_DN16": budget,
            "arm": arm,
            **{
                k: float(
                    np.mean([abs(r[k]) if k == "weak_absent_projection" else r[k] for r in rows])
                )
                for k in names
            },
        }
    )
geometry = defaultdict(list)
for row in report["geometry"]:
    if row["role"] == 2:
        geometry[row["profile"], row["query"]].append(row)
matched = []
for (p, placement, budget, arm), rows in groups.items():
    if arm != "guarded" or budget != 0.02:
        continue
    paired = {arm: rows, "crosschecked": groups[p, placement, budget, "crosschecked"]}

    def mean(label, multiplier, paired=paired):
        values = [evaluated(r["moments"], r["scale"] * multiplier) for r in paired[label]]
        return {
            k: float(np.mean([r[k] for r in values]))
            for k in ("weak_gain", "quiet_RMS_DN16", "weak_increment_RMS_DN16")
        }

    target = min(mean(v, 1)["quiet_RMS_DN16"] for v in paired)
    scales = {}
    for label in paired:
        alt = lambda u, m=label, q=target, mean=mean: mean(m, u)["quiet_RMS_DN16"] - q
        scales[label] = 1.0 if abs(alt(1)) < 1e-13 else brentq(alt, 0, 1) if alt(0) <= 0 else None
    matched.append(
        {
            "profile": p,
            "placement": placement,
            "factor": scales,
            "matched": {k: mean(k, v) for k, v in scales.items() if v is not None},
        }
    )
write_json(
    root / "review/summary.json",
    {
        "audit": reference(audit),
        "means": means,
        "matched_quiet_descriptive": matched,
        "guide_error": [
            {
                "profile": p,
                "placement": a,
                "before": np.mean([r["prior_error"] for r in v], 0).tolist(),
                "after": np.mean([r["new_error"] for r in v], 0).tolist(),
            }
            for (p, a), v in geometry.items()
        ],
    },
)
print(reductions, len(differences), kept, flush=True)
