"""Bind actual inspection notes to the 12 native guide boards."""

import datetime
import json
import sys
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

review = Path(__file__).resolve().parent / "review"
r = read_json(review / "result.json")
a = read_json(review / "independent-audit.json")
obs = json.load(sys.stdin)
records = []
for board in r["boards"] + r["camera"]:
    b = board.get("board", board)["image"]
    checked(b)
    records.append({"id": board["id"], "image": b, "viewed": True, "observation": obs[board["id"]]})
assert len(records) == len(obs) == 12
sky = next(x for x in a["camera"] if x["id"] == "main-overcast-sky")
assert sky["display_equals_V120"] and sky["minus_V120_RMS_DN16"] == 0
write_json(
    review / "actual-native-viewing.json",
    {
        "observed_at": datetime.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "report": reference(review / "result.json"),
        "boards": records,
        "v120_sky_matches": sky,
    },
)
