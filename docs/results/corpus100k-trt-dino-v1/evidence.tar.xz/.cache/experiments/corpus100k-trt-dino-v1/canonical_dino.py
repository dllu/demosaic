"""Compare compiled DINO against prior arithmetic on all frozen panel batches."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import json
from statistics import mean
import time

import numpy as np
import torch

from dino_engine import DinoEngine, ROOT
from dino_review import PREVIOUS, Engine, combined, checked, read_json, reference, write_json
from full_quality import bound_model, gpu_jobs, prepare as prepare_model, trt, versions
import trt_canonical as base
from demosaic.precision import amp_context

PROGRESS = ROOT/'canonical-progress.jsonl'
PRIOR = base.ROOT/'trt-canonical.json'


def compare(rows, control):
    diff = np.asarray([r['dino_trt']-r[control] for r in rows])
    groups = defaultdict(list)
    for row, delta in zip(rows,diff,strict=True):
        groups[row['id']].append(float(delta))
    return dict(cases=len(rows), sources=len(groups), mean_delta_dB=float(diff.mean()),
                source_balanced_delta_dB=mean(mean(x) for x in groups.values()),
                absolute_delta_p95_dB=float(np.quantile(abs(diff),.95)),
                worst=rows[int(diff.argmin())], maximum=rows[int(diff.argmax())],
                min_max_delta_dB=[float(diff.min()),float(diff.max())])


@torch.inference_mode()
def main():
    prepare_model()
    prior=read_json(PRIOR)
    source=prior['canonical_arrays']
    expected=read_json(checked(source))['records']
    old=dict(base.rows_by_key(checked(prior['progress'])))
    assert len(old)==len(expected)==3162
    model,checkpoint=bound_model()
    assert prior['checkpoint']==checkpoint
    builds={size:reference(ROOT/f'dino-t{size}-l3.json') for size in (256,512)}
    dino={}
    for size,path in builds.items():
        info=read_json(checked(path))
        assert info['checkpoint']==checkpoint and info['tile']==size
        dino[size]=info['plan']
    engines={int(size):(Engine(checked(ref)),DinoEngine(checked(dino[int(size)]),int(size)))
             for size,ref in prior['engines'].items()}
    jobs=gpu_jobs()
    start=time.monotonic()
    done=dict(base.rows_by_key(PROGRESS)) if PROGRESS.exists() else {}
    for key,row in done.items():
        assert old[key]['source']==row['source'] and old[key]['archive']==row['archive']
        assert all(new['trt_fp16']==ref['trt_fp16'] for new,ref in zip(row['scores'],old[key]['scores'],strict=True))
    expected=sorted(expected,key=lambda row:row['stage']=='photo')
    records=[row for row in expected if (row['stage'],row['batch']) not in done]
    torch.cuda.synchronize()
    stream=torch.cuda.Stream()
    with (PROGRESS.open('a') as out, ThreadPoolExecutor(1) as pool, torch.cuda.stream(stream)):
        loaded=pool.submit(base.prepare,records[0]) if records else None
        for index,row in enumerate(records):
            stage,batch=row['stage'],row['batch']
            sensor=stage!='photo'
            archived=old[(stage,batch)]
            assert archived['source']==row['arrays']
            batch_cpu=loaded.result()
            loaded=pool.submit(base.prepare,records[index+1]) if index+1<len(records) else None
            data={k:v.cuda(non_blocking=True) for k,v in batch_cpu.items()}
            for key in base.KEYS[:2]:
                data[key]=data[key].contiguous(memory_format=torch.channels_last)
            noise=row['context']['noise' if sensor else 'condition']
            model.set_noise(noise['shot'],noise['read'])
            shape=data['packed'].shape[-1]*2
            with combined(model,engines[shape]),amp_context('cuda',dtype='float16'):
                output=model(*(data[k] for k in base.KEYS))
            border=32 if sensor else 8
            view=np.s_[...,border:-border,border:-border]
            if sensor:
                score,_=base.measured_sensor_psnr(output[view],data['sensor_reference'][view],data['sensor_mask'][view])
            else:
                score=base.psnr(output[view],data['target'][view],data['wb'],data['matrix'])
            numbers=score.cpu().tolist()
            valid=[i for i,value in enumerate(numbers) if np.isfinite(value)]
            series=[]
            for case,i in zip(archived['scores'],valid,strict=True):
                assert case['id']==row['context']['ids'][i]
                series.append(dict(case,dino_trt=numbers[i]))
            result={**archived,'scores':series}
            done[(stage,batch)]=result
            out.write(json.dumps(result,allow_nan=False)+'\n')
            if index%50==0 or index+1==len(records):
                out.flush()
                print(len(done),stage,round(time.monotonic()-start,2),flush=True)
    assert len(done)==3162
    measured=[case for row in done.values() for case in row['scores']]
    controls=('trt_fp16','fp16','cpu_fp32')
    photos=[row for row in measured if row['panel']=='photo' and not row['id'].startswith('synthetic-')]
    panels={
        'photo':photos,
        'known':[r for r in measured if r['panel']=='known'],
        'unseen':[r for r in measured if r['panel']=='unseen'],
        **{condition:[r for r in photos if r['condition']==condition] for condition in sorted({r['condition'] for r in photos})},
    }
    summary={name:{control:compare(rows,control) for control in controls} for name,rows in panels.items()}
    for name in ('photo','known','unseen'):
        print(name,{control:summary[name][control]['source_balanced_delta_dB'] for control in controls},flush=True)
    write_json(ROOT/'canonical.json',dict(driver=reference(__file__),prior_driver=reference(base.__file__),
        checkpoint=checkpoint,builds=builds,old_control=reference(PRIOR),original_scores=prior['progress'],
        canonical_arrays=source,plans={'trunk':prior['engines'],'dino':dino},batches=len(done),summary=summary,
        invocation_seconds=time.monotonic()-start,progress=reference(PROGRESS),
        backend={**versions(),'TensorRT':trt.__version__},job_pids_before=jobs,job_pids_after=gpu_jobs()))


if __name__=='__main__':
    main()
