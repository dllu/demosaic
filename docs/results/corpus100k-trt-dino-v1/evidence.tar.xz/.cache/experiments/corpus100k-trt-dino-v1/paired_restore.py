"""Pair both TensorRT paths through equivalent tile transfer and FP32 blend work."""
import time

import numpy as np
import torch

from dino_engine import ROOT
from dino_review import combined, quality, engine_set, build_refs
from full_quality import prepare, bound_model, gpu_jobs, read_json, checked, reference, write_json, SHOT, READ
from demosaic.cfa import pack
from demosaic.inference import positions
from demosaic.precision import amp_context


@torch.inference_mode()
def main():
    prepare()
    full=read_json(ROOT/'full.json')
    start=time.perf_counter()
    raw,meta=quality.read_raw(checked(full['source']))
    raw=torch.from_numpy(raw)
    assert raw.numel() == 101995852 and all(length % 2 == 0 for length in raw.shape)
    model,checkpoint=bound_model()
    assert checkpoint==full['checkpoint'] and build_refs(3)==full['plans']
    engines=engine_set(full['plans'])
    model.set_noise(SHOT,READ)
    h,w=raw.shape
    tile,stride=512,448
    coords=[(y,x) for y in positions(h,tile,stride) for x in positions(w,tile,stride)]
    assert len(coords)==520
    edge=torch.hann_window(tile,periodic=False).clamp_min(0.02)
    weight=edge[:,None]*edge[None,:]
    modes=('dynamic','static')
    accum={mode:torch.zeros(3,h,w,dtype=torch.float32) for mode in modes}
    norm={mode:torch.zeros(h,w,dtype=torch.float32) for mode in modes}
    rows=[]
    jobs=gpu_jobs()
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for index in range(-4,len(coords)//4):
            current=coords[max(0,index)*4:max(0,index)*4+4]
            order=modes if index%2==0 else modes[::-1]
            stats={}
            for arm in order:
                t0=time.perf_counter()
                tiles=pack(torch.stack([raw[y:y+tile,x:x+tile] for y,x in current])[:,None].cuda())
                tiles=tiles.contiguous(memory_format=torch.channels_last)
                variance=tiles.clamp_min(0)*SHOT+READ
                colors=torch.as_tensor(quality.color_indices(meta.pattern),device='cuda')[None].expand(4,-1)
                wb=torch.as_tensor(meta.white_balance,dtype=torch.float32,device='cuda')[None].expand(4,-1)
                matrix=torch.as_tensor(meta.camera_to_srgb,dtype=torch.float32,device='cuda')[None].expand(4,-1,-1)
                with combined(model,engines[arm]),amp_context('cuda',dtype='float16'):
                    colors_out=model(tiles,variance,colors,wb,matrix)
                output=colors_out.float().cpu()
                t1=time.perf_counter()
                if index>=0:
                    for crop,(y,x) in zip(output,current,strict=True):
                        accum[arm][:,y:y+tile,x:x+tile].add_(crop*weight)
                        norm[arm][y:y+tile,x:x+tile].add_(weight)
                t2=time.perf_counter()
                stats[arm]={'pack_forward_copy':t1-t0,'blend':t2-t1,'total':t2-t0}
            if index>=0:
                rows.append(dict(batch=index,origin_yx=current,order=order,stats=stats))
            if index%26==25:
                print(index+1,{mode:round(sum(row['stats'][mode]['total'] for row in rows),4) for mode in modes},flush=True)
    assert torch.equal(norm['dynamic'],norm['static'])
    final={}
    for arm in modes:
        before=time.perf_counter()
        accum[arm].div_(norm[arm].clamp_min_(1e-12))
        normalize_seconds=time.perf_counter()-before
        path=ROOT/f'paired-restore-{arm}.tiff'
        before=time.perf_counter()
        quality.write_rgb16(path,accum[arm].permute(1,2,0).numpy(),metadata=meta,flip=meta.flip)
        export_seconds=time.perf_counter()-before
        binding=reference(path)
        assert binding['sha256']==full['exports'][arm]['sha256']
        final[arm]=dict(normalize_seconds=normalize_seconds,export_seconds=export_seconds,export=binding)
        path.unlink()
    summary={}
    blocks=np.arange(130).reshape(26,5)
    rng=np.random.default_rng(2026111911)
    draw=blocks[rng.integers(0,len(blocks),(4000,len(blocks)))].reshape(4000,130)
    for metric in ('pack_forward_copy','blend','total'):
        control,candidate=[np.asarray([r['stats'][arm][metric] for r in rows]) for arm in modes]
        deltas=100*(candidate[draw].mean(1)/control[draw].mean(1)-1)
        summary[metric]={'seconds':dict(zip(modes,(float(control.sum()),float(candidate.sum())),strict=True)),
            'percent_delta':float(100*(candidate.mean()/control.mean()-1)),
            'boot95_percent':np.quantile(deltas,[.025,.975]).tolist(),
            'candidate_faster_fraction':float(np.mean(candidate<control))}
    write_json(ROOT/'paired-restore.json',dict(driver=reference(__file__),full=reference(ROOT/'full.json'),
             plans=full['plans'],checkpoint=checkpoint,source=full['source'],rows=rows,summary=summary,final=final,
             elapsed_seconds=time.perf_counter()-start,job_pids_before=jobs,job_pids_after=gpu_jobs()))
    print(summary,flush=True)


if __name__=='__main__':
    main()
