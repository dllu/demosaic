"""Publish bound numerical receipts and unchanged native pixels."""
from copy import deepcopy
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
IMAGES=Path('docs/images')/ROOT.name
RESULTS=Path('docs/results')/ROOT.name
CANDIDATE='TensorRT FP16 trunk and DINO'
TRUNK='TensorRT FP16 trunk'


def retain_board(board):
    src=checked(board['image'])
    dst=IMAGES/src.name
    shutil.copyfile(src,dst)
    assert reference(dst)['sha256']==board['image']['sha256']
    with Image.open(dst) as image:
        pixel=np.asarray(image.convert('RGB'))
    panels={}
    for panel in board['panels']:
        x,y,w,h=panel['png_xywh']
        tile=pixel[y:y+h,x:x+w]
        assert tile.shape==(160,160,3)
        panels[panel.get('label',panel.get('name'))]=tile
    board['image']['path']=dst.name
    return panels


def retain_triplet(row):
    comparison=retain_board(row['board'])
    triplet=retain_board(row['triplet'])
    assert list(triplet)==['Noisy Malvar',CANDIDATE,'Exact GT']
    assert all(np.array_equal(tile,comparison[label]) for label,tile in triplet.items())


def main():
    IMAGES.mkdir(parents=True,exist_ok=True)
    RESULTS.mkdir(parents=True,exist_ok=True)
    names=('screen','full','paired-tiles','paired-restore','quality','wires','true-gaps','canonical','outliers','panel-outliers')
    receipts={name:reference(ROOT/f'{name}.json') for name in names}
    results={name:read_json(checked(ref)) for name,ref in receipts.items()}
    screen=results['screen']
    full=results['full']
    interleave=results['paired-tiles']
    paired=results['paired-restore']
    quality=results['quality']
    wires=results['wires']
    gaps=results['true-gaps']
    canonical=results['canonical']
    outliers=results['outliers']
    photo_views=results['panel-outliers']
    assert all(results[name]['checkpoint']==full['checkpoint'] for name in names if name!='outliers')
    assert all(results[name]['plans']==full['plans'] for name in names if name not in ('canonical','outliers','panel-outliers'))
    assert all(row['full']==receipts['full'] for row in (interleave,paired,outliers)) and quality['full_receipt']==receipts['full']
    assert photo_views['canonical']==receipts['canonical']
    assert canonical['plans']['trunk']['512']==full['plans']['dynamic'] and canonical['plans']['dino']['512']==full['plans']['dino']
    assert len(interleave['rows'])==len(paired['rows'])==130
    assert all(sorted(tuple(reversed(xy)) for xy in a['origins_xy'])==sorted(map(tuple,b['origin_yx']))
               for a,b in zip(interleave['rows'],paired['rows'],strict=True))
    assert len(wires['rows'])==48 and len(gaps['rows'])==24 and canonical['batches']==3162
    for key, expected in (('photo',(427,11956)),('known',(72,72)),('unseen',(90,90))):
        panel=canonical['summary'][key]['trt_fp16']
        assert panel['cases']==expected[1]
        if key=='photo':
            assert panel['sources']==expected[0]
    for i,row in enumerate(full['events']):
        assert row['index']==i and row['restore']['tiles']==520
        assert row['export']['sha256']==full['exports'][row['arm']]['sha256']
    for mode in ('dynamic','static'):
        assert paired['final'][mode]['export']['sha256']==full['exports'][mode]['sha256']
    for ref in (full['FP32_anchor'],full['source'],*full['exports'].values()):
        checked(ref)
    fp32=read_json(ROOT.with_name('corpus100k-mixed-precision-v1')/'first-fp32.json')
    assert fp32['RGB16']==full['FP32_anchor'] and fp32['checkpoint']==full['checkpoint']
    assert fp32['source']==full['source'] and fp32['policy']=='fp32'
    assert all(fp32['noise'][key]==full['settings'][key] for key in ('shot','read'))
    assert all(fp32['timing'][key]==full['settings'][key] for key in ('tile','overlap','batch_size'))
    builds=[read_json(checked(canonical['builds'][str(size)])) for size in (256,512)]
    for build in builds:
        assert build['checkpoint']==full['checkpoint'] and build['dino_revision']==builds[0]['dino_revision']
        checked(build['plan'])
        checked(build['inspection'])
    views=deepcopy(quality)
    assert len(views['main'])==len(views['cab'])==4 and len(views['exact'])==6
    for row in views['main']+views['cab']:
        panels=retain_board(row['board'])
        assert all(label in panels for label in ('IEEE FP32',TRUNK,CANDIDATE))
        cab=row in views['cab']
        assert sum('ISO100' in label for label in panels)==(2 if cab else 1)
        if cab:
            assert 'SOOC ISO6400 JPEG' in panels
    for row in views['exact'][:2]:
        retain_triplet(row['board'])
    extremes=deepcopy(outliers['rows'])
    for row in extremes.values():
        assert len(retain_board(row['board']))==4
    photo_outliers=deepcopy(photo_views['rows'])
    for row in photo_outliers:
        retain_triplet(row['board'])
    manifest=IMAGES/'manifest.json'
    write_json(manifest,{**views,'source':receipts['quality'],'full_export_outliers':extremes,
         'fixed_photo_outliers':photo_outliers,'reviewed_local':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})
    old_dino=ROOT.with_name('corpus100k-faster-inference-v1')
    comp=ROOT.with_name('corpus100k-trt-tactics-v1')
    tile=ROOT.with_name('corpus100k-fp16-throughput-v1')
    mixed=ROOT.with_name('corpus100k-mixed-precision-v1')
    paths=list(ROOT.glob('*.py'))+[checked(ref) for ref in receipts.values()]
    paths.extend(p for p in ROOT.glob('*.log') if '-preflight.' not in p.name)
    paths.extend([checked(canonical['progress']),checked(wires['plan']),checked(wires['captures']),checked(quality['sources']['exact']),
                  checked(canonical['old_control']),checked(canonical['prior_driver']),*(checked(b['inspection']) for b in builds),
                  *(checked(x) for x in canonical['builds'].values()),old_dino/'trt_hidden.py',comp/'tactics.py',
                  comp/'full_quality.py',comp/'interleave.py',comp/'wires.py',tile/'full_throughput.py',
                  tile/'screen_throughput.py',tile/'review_throughput.py',tile/'trt_panel_outlier.py',
                  mixed/'screen.py',mixed/'full_production.py',mixed/'canonical.py',mixed/'first-fp32.json',
                  Path('src/demosaic/inference.py'),Path('src/demosaic/dino_pyramid.py'),
                  Path('scripts/report_scene_wave_guides.py'),ROOT.with_name('paired-luminance-detail-v1')/'render.py',
                  Path('configs/gfx-qualitative-20231231.json'),Path('configs/gfx-green-mesh-20231231.json')])
    workdir=Path.cwd()
    members={str(p.absolute().relative_to(workdir)):p for p in paths}
    archive=RESULTS/'evidence.tar.xz'
    with tarfile.open(archive,'x:xz',dereference=True,preset=4) as out:
        for name,file_path in sorted(members.items()):
            out.add(file_path,arcname=name,recursive=False)
    with tarfile.open(archive) as inp:
        for name,file_path in members.items():
            with inp.extractfile(name) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==reference(file_path)['sha256']
    summary=dict(checkpoint=full['checkpoint'],settings=full['settings'],builds=builds,sources=receipts,
         archive=reference(archive),native_review=reference(manifest),versions=full['versions'],
         resident=screen['medians'],runs=full['events'],full_export_deltas=full['paired'],
         paired_forward=interleave['summary'],paired_restore=paired['summary'],wire_deltas=wires['deltas_vs_eager'],
         gap_deltas=gaps['summary'],fixed_panels=canonical['summary'],scope='One checkpoint and a new inference policy.')
    write_json(RESULTS/'publication.json',summary)
    print(len(members),'source-bound archive members and',len(list(IMAGES.glob('*.png'))),'native images')


if __name__=='__main__':
    main()
