"""Replay and publish the largest fixed-photo losses after DINO compilation."""
import json

import numpy as np
import torch

from canonical_dino import base
from dino_engine import DinoEngine, ROOT
from full_quality import prepare, bound_model
from dino_review import Engine, combined, read_json, reference, checked, write_json, quality
from trt_panel_outlier import MANIFEST
from demosaic.precision import amp_context


@torch.inference_mode()
def main():
    prepare()
    proof=reference(ROOT/'canonical.json')
    result=read_json(checked(proof))
    records=read_json(checked(result['canonical_arrays']))['records']
    model,checkpoint=bound_model()
    assert result['checkpoint']==checkpoint
    engines={size:(Engine(checked(result['plans']['trunk'][str(size)])),
                   DinoEngine(checked(result['plans']['dino'][str(size)]),size))
             for size in (256,512)}
    manifest=reference(MANIFEST)
    with checked(manifest).open() as data:
        sources={photo['id']:photo for photo in map(json.loads,data)}
    done=set()
    views=[]
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for control in ('trt_fp16','fp16','cpu_fp32'):
            outlier=result['summary']['photo'][control]['worst']
            key=outlier['batch'],outlier['id']
            if key in done:
                continue
            done.add(key)
            row=next(r for r in records if r['stage']=='photo' and r['batch']==key[0])
            slot=row['context']['ids'].index(key[1])
            with np.load(checked(row['arrays']),allow_pickle=False) as f:
                data={k:torch.from_numpy(f[k]).cuda() for k in (*base.KEYS,'target')}
            for k in base.KEYS[:2]:
                data[k]=data[k].contiguous(memory_format=torch.channels_last)
            shape=data['packed'].shape[-1]*2
            noise=row['context']['condition']
            model.set_noise(noise['shot'],noise['read'])
            trunk,dino=engines[shape]
            policies={'ieee-fp32':((None,None),'float32'),'eager':((None,None),'float16'),
                      'dynamic':((trunk,None),'float16'),'static':((trunk,dino),'float16')}
            predictions,scores={},{}
            cut=np.s_[...,8:-8,8:-8]
            for arm,(runtime,precision) in policies.items():
                with combined(model,runtime),amp_context('cuda',dtype=precision):
                    rgb=model(*(data[k] for k in base.KEYS))
                scores[arm]=float(base.psnr(rgb[cut],data['target'][cut],data['wb'],data['matrix'])[slot])
                predictions[arm]=rgb[slot].cpu().numpy()
            assert abs(outlier['dino_trt']-scores['static']) < 2e-5
            assert abs(outlier['trt_fp16']-scores['dynamic']) < 2e-5
            arrays={k:v[slot:slot+1].cpu().numpy() for k,v in data.items()}
            source=sources[key[1]]
            attribution={k:source[k] for k in ('id','title','author','license','page_url')}
            tag=f'worst-vs-{control}'
            labels={'ieee-fp32':'IEEE FP32','eager':'Eager FP16',
                    'dynamic':'TensorRT FP16 trunk','static':'TensorRT FP16 trunk and DINO'}
            board=quality.native_board(ROOT,tag,[quality.noisy_malvar(arrays)[0],*predictions.values(),arrays['target'][0]],
                  arrays,{'photo':attribution,'context':row['context'],'case':outlier,
                          'checkpoint':checkpoint,'arrays':row['arrays']},
                  labels=('Noisy Malvar',*[labels[arm] for arm in policies],'Exact GT'),
                  triplet_indices=(0,4,5),exposure=1,roi=(48,48,160,160))
            views.append(dict(id=tag,control=control,board=board,attribution=attribution,scores=scores,
                              delta=quality.difference(predictions['static'],predictions['dynamic'])))
            print(tag,attribution,scores,flush=True)
    write_json(ROOT/'panel-outliers.json',dict(driver=reference(__file__),checkpoint=checkpoint,
        canonical=proof,photo_manifest=manifest,rows=views))


if __name__=='__main__':
    main()
