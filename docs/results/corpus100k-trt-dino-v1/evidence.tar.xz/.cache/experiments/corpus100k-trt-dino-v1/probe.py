from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.with_name('corpus100k-trt-tactics-v1')))
from full_quality import prepare, bound_model, torch, trt

prepare()
model, checkpoint = bound_model()
net=model.context.backbone
print(net.config.hidden_act, net.config.hidden_sizes, net.config.depths, model.config.dino_revision)
for name, mod in net.named_modules():
    if name.count('.') <= 2 or name.startswith('stages.0.layers.0.'):
        mod.register_forward_hook(lambda _m, args, y, name=name: print(name, args[0].dtype, y.dtype, y.stride()) if isinstance(y,torch.Tensor) else None)
with torch.inference_mode(), torch.autocast('cuda',dtype=torch.float16):
    net(pixel_values=torch.rand(1,3,512,512,device='cuda').contiguous(memory_format=torch.channels_last),output_hidden_states=True)
