"""Test whether DINO compilation changes wire responses in exact empty gaps."""
from statistics import mean

import numpy as np
import torch

from dino_engine import ROOT
from dino_review import build_refs, combined, engine_set, read_json, reference, checked, write_json
from full_quality import prepare, bound_model
from wires import SOURCE, KEYS, LUMA
from demosaic.archive_metrics import linear_rgb
from demosaic.precision import amp_context


@torch.inference_mode()
def main():
    prepare()
    model, checkpoint=bound_model()
    refs=build_refs(3)
    engines=engine_set(refs)
    plan=read_json(SOURCE/'plan.json')
    captures=read_json(SOURCE/'captures.json')
    assert plan['roles'][:3] == ['present','outside-only','strong-only']
    x,y=np.meshgrid(np.arange(128)-63.5,np.arange(128)-63.5)
    roi=np.s_[...,192:320,192:320]
    rows=[]
    torch.cuda.synchronize()
    with torch.cuda.stream(torch.cuda.Stream()):
        for case in captures['rows']:
            geometry=plan['sources'][case['index']]['geometry']
            if geometry['family'] not in ('ellipse','strip'):
                continue
            capture=case['input']
            with np.load(checked(capture),allow_pickle=False) as src:
                gap=(src['support'][64:192,64:192]==0)
                data={key:src[key] for key in (*KEYS,'target')}
            assert int(gap.sum())>=64
            truth=np.einsum('c,bchw->bhw',LUMA,linear_rgb(data['target'],data)[roi])
            np.testing.assert_array_equal(truth[0][gap],truth[2][gap])
            xg,yg=x[gap],y[gap]
            phases=2*np.pi*np.asarray(geometry['frequency'])@np.stack((xg,yg))
            terms=np.column_stack((np.ones(len(xg)),xg,yg,xg*xg,xg*yg,yg*yg,
                                   np.cos(phases[0]),np.sin(phases[0]),np.cos(phases[1]),np.sin(phases[1])))
            fit=np.linalg.pinv(terms)[-2:]
            args=[torch.from_numpy(data[key]).cuda() for key in KEYS]
            args[0]=args[0].contiguous(memory_format=torch.channels_last)
            noise=plan['profiles'][case['noise']]
            model.set_noise(noise['shot'],noise['read'])
            scores={}
            for key in ('eager','dynamic','static'):
                with combined(model,engines[key]), amp_context('cuda', dtype='float16'):
                    rgb=model(*args).cpu().numpy()
                image=np.einsum('c,bchw->bhw',LUMA,linear_rgb(rgb,data)[roi])
                error=image[0][gap]-truth[0][gap]
                gap_difference=image[0][gap]-image[2][gap]
                scores[key]=dict(gap_luma_error_RMS_DN16=float(np.sqrt(np.mean(error**2))*65535),
                     weak_direction_error_DN16=float(np.linalg.norm(fit@error)*65535),
                     paired_weak_direction_DN16=float(np.linalg.norm(fit@gap_difference)*65535))
            rows.append(dict(source=case['index'],profile=case['noise'],gap_pixels=int(gap.sum()),
                             family=geometry['family'],input=capture,scores=scores))
    assert len(rows)==24
    summary={}
    for profile in ('iso400','iso6400'):
        selected=[r['scores'] for r in rows if r['profile']==profile]
        assert len(selected)==12
        summary[profile]={}
        for metric in selected[0]['static']:
            delta=[r['static'][metric]-r['dynamic'][metric] for r in selected]
            summary[profile][metric]=dict(control_mean=mean(r['dynamic'][metric] for r in selected),
                                           candidate_mean=mean(r['static'][metric] for r in selected),
                                           mean_delta=mean(delta),min_delta=min(delta),max_delta=max(delta))
    write_json(ROOT/'true-gaps.json',dict(driver=reference(__file__),checkpoint=checkpoint,plans=refs,
                captures=reference(SOURCE/'captures.json'),rows=rows,summary=summary))
    print(summary,flush=True)


if __name__=='__main__':
    main()
