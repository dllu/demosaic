"""Render the largest full-frame RGB16 changes at native scale."""
import numpy as np
import tifffile
import torch

from dino_engine import ROOT
from dino_review import quality, configure, checked, read_json, reference, write_json


def main():
    torch.set_num_threads(2)
    configure()
    row=read_json(ROOT/'full.json')
    _,meta=quality.read_raw(checked(row['source']))
    assert meta.flip==0
    wb,mat=torch.tensor(meta.white_balance)[None],torch.tensor(meta.camera_to_srgb)[None]
    images={key:tifffile.memmap(checked(src)) for key,src in
            {**row['exports'],'ieee-fp32':row['FP32_anchor']}.items()}
    results={}
    for key in ('static_vs_dynamic','static_vs_ieee-fp32'):
        baseline=key.rsplit('_',1)[-1]
        magnitude,(x,y,c)=row['paired'][key]['max_DN16_and_sensor_xy_channel']
        assert abs(int(images['static'][y,x,c])-int(images[baseline][y,x,c]))==magnitude
        x0=min(max(0,x-80),images['static'].shape[1]-160)
        y0=min(max(0,y-80),images['static'].shape[0]-160)
        panels=[]
        for arm in ('ieee-fp32','eager','dynamic','static'):
            crop=torch.from_numpy(images[arm][y0:y0+160,x0:x0+160].astype(np.float32)).permute(2,0,1)/65535
            panels.append((quality.LABELS[arm],quality.display_sensor(crop,wb,mat,(0,0,160,160),1)))
        results[key]=dict(difference_DN16=magnitude,xyc=[x,y,c],xywh=[x0,y0,160,160],display_exposure=1,
                          board=quality.native_png(ROOT/f'{key}-outlier.png',panels))
    write_json(ROOT/'outliers.json',dict(driver=reference(__file__),full=reference(ROOT/'full.json'),rows=results))


if __name__=='__main__':
    main()
