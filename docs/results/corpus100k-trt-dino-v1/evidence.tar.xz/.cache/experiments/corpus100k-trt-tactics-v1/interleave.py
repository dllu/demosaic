"""Time all three engines on each identical batch of the 102 MP RAW."""
from collections import defaultdict
from itertools import permutations
from statistics import mean, median
import time

import numpy as np
import torch

from full_quality import (FIXTURE, ROOT, SHOT, READ, bound_model, build_refs, color_indices,
    engine_set, gpu_jobs, prepare, read_json, read_raw, reference, selected, trt, versions, write_json)
from demosaic.cfa import pack
from demosaic.inference import positions
from demosaic.precision import amp_context


@torch.inference_mode()
def main():
    started = time.perf_counter()
    prepare()
    record = read_json(ROOT/'full.json')
    fixture = read_json(FIXTURE)
    source = reference(fixture['noisy'])
    raw, meta = read_raw(source['path'])
    assert all(length % 2 == 0 for length in raw.shape)
    model, checkpoint = bound_model()
    assert checkpoint == record['checkpoint'] and source == record['source']
    engines = engine_set(build_refs(record['level']))
    model.set_noise(SHOT, READ)
    xs, ys = positions(raw.shape[1],512,448), positions(raw.shape[0],512,448)
    coords = [(x,y) for y in ys for x in xs]
    assert len(coords) == 520
    colors = torch.as_tensor(color_indices(meta.pattern), device='cuda')[None].expand(4,-1)
    wb = torch.as_tensor(meta.white_balance,dtype=torch.float32,device='cuda')[None].expand(4,-1)
    matrix = torch.as_tensor(meta.camera_to_srgb,dtype=torch.float32,device='cuda')[None].expand(4,-1,-1)
    keys = ('eager', 'dynamic', 'static')
    # Each engine appears twice at every order position in each six-batch block.
    orders = tuple(permutations(keys))
    rows = []
    pre_jobs = gpu_jobs()
    torch.cuda.synchronize()
    stream = torch.cuda.Stream()
    with torch.cuda.stream(stream):
        start, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
        for index in range(-3, 130):
            batch_start = max(0,index) * 4
            rc = coords[batch_start:batch_start+4]
            tiles = np.stack([raw[y:y+512,x:x+512] for x,y in rc])
            packed = pack(torch.from_numpy(tiles[:,None]).cuda()).contiguous(memory_format=torch.channels_last)
            args = packed,packed.clamp_min(0)*SHOT+READ,colors,wb,matrix
            stream.synchronize()
            stats = {}
            order = orders[index % len(orders)]
            for arm in order:
                t0 = time.perf_counter()
                start.record(stream)
                with selected(model,engines[arm]), amp_context('cuda',dtype='float16'):
                    output = model(*args)
                end.record(stream)
                end.synchronize()
                stats[arm] = {'wall_seconds':time.perf_counter()-t0,'CUDA_seconds':start.elapsed_time(end)/1000}
                assert output.dtype == torch.float32 and output.shape == (4,3,512,512)
            if index >= 0:
                rows.append(dict(batch=index, origins_xy=rc, order=order, timings=stats))
            if index >= 0 and (index+1) % 26 == 0:
                print(index+1, {k:round(mean(r['timings'][k]['wall_seconds'] for r in rows),4) for k in keys},flush=True)
    result = defaultdict(dict)
    for metric in ('wall_seconds','CUDA_seconds'):
        a = {mode:np.array([r['timings'][mode][metric] for r in rows]) for mode in keys}
        for arm,v in a.items():
            result[metric][arm] = dict(total=float(v.sum()), median=float(np.median(v)))
        # Resample aligned runs of nearby batches to keep some temporal correlation.
        rng = np.random.default_rng(1961)
        blocks = np.arange(130).reshape(26,5)
        draw = blocks[rng.integers(0,len(blocks),(4000,len(blocks)))].reshape(4000,130)
        for candidate,control in (('dynamic','eager'), ('static','eager'), ('static','dynamic')):
            ratio = 100*(a[candidate][draw].mean(1)/a[control][draw].mean(1) - 1)
            result[metric][f'{candidate}_vs_{control}'] = {
                'mean_relative_percent':float(100*(a[candidate].mean()/a[control].mean()-1)),
                'bootstrap_interval_percent':np.quantile(ratio,[.025,.975]).tolist(),
                'fraction_batches_faster':float((a[candidate]<a[control]).mean())}
    write_json(ROOT/'paired-tiles.json',dict(driver=reference(__file__), raw=source, checkpoint=checkpoint,
        plans=record['plans'], full=reference(ROOT/'full.json'), rows=rows,
        summary=result, backend={**versions(),'TensorRT':trt.__version__}, gpu_before=pre_jobs,
        gpu_after=gpu_jobs(), process_seconds=time.perf_counter()-started))
    print(dict(result),flush=True)


if __name__ == '__main__':
    main()
