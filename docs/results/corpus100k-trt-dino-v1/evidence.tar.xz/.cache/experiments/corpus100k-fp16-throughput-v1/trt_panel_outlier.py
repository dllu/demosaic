"""Replay the worst fixed-photo TensorRT scores and retain native comparisons."""
import json
from pathlib import Path

import numpy as np
import torch

from trt_canonical import Engine, KEYS, ROOT, bound_model, selected, read_json, write_json, reference, checked, psnr
from review_throughput import native_board, noisy_malvar, difference
from demosaic.precision import amp_context

MANIFEST=Path('.cache/current-quality-20261023-v1/raw-global-attention-pilot-v1/run/work/artifacts/CPU/V136/source/6f0ad10f63b46ae7b5a357e1d9e842de59ca331bb94694469986d58dfca645db/validation-manifest.jsonl')


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    proof_ref=reference(ROOT/'trt-canonical.json')
    result=read_json(checked(proof_ref))
    records=read_json(checked(result['canonical_arrays']))['records']
    model,checkpoint=bound_model()
    assert checkpoint==result['checkpoint']
    engine=Engine(checked(result['engines']['256']))
    manifest_ref=reference(MANIFEST)
    with checked(manifest_ref).open() as handle:
        sources={photo['id']:photo for line in handle for photo in (json.loads(line),)}
    stream=torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    metrics=[]
    with torch.cuda.stream(stream):
        for tag, name in [('trt-worst-photo','worst_loss_case'),('trt-best-photo','largest_gain_case')]:
            before=result['summaries']['photo'][name]
            row=next(r for r in records if r['stage']=='photo' and r['batch']==before['batch'])
            idx=row['context']['ids'].index(before['id'])
            with np.load(checked(row['arrays']),allow_pickle=False) as f:
                data={k:torch.from_numpy(f[k]).cuda() for k in (*KEYS,'target')}
            for k in KEYS[:2]:
                data[k]=data[k].contiguous(memory_format=torch.channels_last)
            noise=row['context']['condition']
            model.set_noise(noise['shot'],noise['read'])
            cases=((None,'float32','gpu_ieee_fp32'),(None,'float16','fp16'),(engine,'float16','trt_fp16'))
            predictions={}
            scores={}
            cut=np.s_[...,8:-8,8:-8]
            for runtime,precision,arm in cases:
                with selected(model,runtime),amp_context('cuda',dtype=precision):
                    rgb=model(*(data[k] for k in KEYS))
                scores[arm]=float(psnr(rgb[cut],data['target'][cut],data['wb'],data['matrix'])[idx])
                predictions[arm]=rgb[idx].cpu().numpy()
            assert all(abs(before[k]-scores[k])<2e-5 for k in ('fp16','trt_fp16'))
            arrays={k:v[idx:idx+1].cpu().numpy() for k,v in data.items()}
            source=sources[before['id']]
            attribution={k:source[k] for k in ('id','title','author','license','page_url')}
            board=native_board(ROOT,tag,[noisy_malvar(arrays)[0],*predictions.values(),arrays['target'][0]],arrays,
                  {'photo':attribution,'context':row['context'],'case':before,
                   'checkpoint':checkpoint,'arrays':row['arrays']},
                  labels=('Noisy Malvar','IEEE FP32','Eager FP16','TensorRT FP16','Exact GT'),
                  triplet_indices=(0,3,4),exposure=1,roi=(48,48,160,160))
            metrics.append({'id':tag,'board':board,'scores':scores,
                           'TensorRT_vs_eager':difference(predictions['trt_fp16'],predictions['fp16'])})
    write_json(ROOT/'trt-panel-outliers.json',{'driver':reference(__file__),'checkpoint':checkpoint,
      'canonical':proof_ref,'photo_manifest':manifest_ref,'rows':metrics})
    print([(r['id'],r['scores'],r['TensorRT_vs_eager']) for r in metrics],flush=True)


if __name__=='__main__':
    main()
