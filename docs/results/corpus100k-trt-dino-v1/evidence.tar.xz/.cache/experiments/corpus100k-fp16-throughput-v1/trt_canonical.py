"""Score the previously reviewed TensorRT FP16 engines on the frozen broad panels."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from statistics import mean
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.with_name('corpus100k-faster-inference-v1')))
from trt_hidden import Engine, selected, trt
from full_production import gpu_jobs
from canonical import KEYS, psnr
from screen_throughput import bound_model, versions
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import amp_context
from demosaic.real_suite import measured_sensor_psnr

PRIMARY = Path('docs/results/full-corpus-long100k-primary-v1/primary.json')
FAST = Path('docs/results/corpus100k-faster-inference-v1/publication.json')
EAGER = ROOT.with_name('corpus100k-mixed-precision-v1')/'canonical.json'
PROGRESS = ROOT/'trt-canonical-progress.jsonl'


def prepare(row):
    sensor = row['stage']!='photo'
    required = (*KEYS,'sensor_reference','sensor_mask') if sensor else (*KEYS,'target')
    with np.load(checked(row['arrays']),allow_pickle=False) as f:
        return {k:torch.from_numpy(f[k]).pin_memory() for k in required}


def rows_by_key(path):
    with path.open() as stream:
        for line in stream:
            entry = json.loads(line)
            yield (entry['stage'],entry['batch']),entry


def paired_summary(rows, selector):
    picked = [row for row in rows if selector(row)]
    values = np.array([row['trt_fp16']-row['fp16'] for row in picked])
    fp32 = np.array([row['trt_fp16']-row['cpu_fp32'] for row in picked])
    eager = np.array([row['fp16'] for row in picked])
    buckets = defaultdict(list)
    for row in picked:
        buckets[row['id']].append(row['trt_fp16']-row['fp16'])
    return {'cases':len(picked),'sources':len(buckets),'mean_difference_vs_eager_dB':float(values.mean()),
            'source_balanced_difference_vs_eager_dB':mean(mean(v) for v in buckets.values()),
            'mean_difference_vs_archived_IEEE_FP32_dB':float(fp32.mean()),
            'source_balanced_difference_vs_archived_IEEE_FP32_dB':mean(
                mean(r['trt_fp16']-r['cpu_fp32'] for r in group)
                for group in grouped(picked).values()),
            'abs_p95_difference_vs_eager_dB':float(np.quantile(abs(values),.95)),
            'min_max_difference_vs_eager_dB':[float(values.min()),float(values.max())],
            'worst_loss_case':picked[int(values.argmin())],'largest_gain_case':picked[int(values.argmax())],
            'eager_mean_dB':float(eager.mean()),'trt_mean_dB':float((eager+values).mean())}


def grouped(rows):
    items = defaultdict(list)
    for r in rows:
        items[r['id']].append(r)
    return items


@torch.inference_mode()
def main():
    torch.set_num_threads(3)
    total = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1,12*2**30/total))
    primary, fast, eager = [read_json(path) for path in (PRIMARY,FAST,EAGER)]
    source = primary['canonical_inputs']
    expected = read_json(checked(source))['records']
    old = dict(rows_by_key(checked(eager['progress'])))
    assert len(old)==len(expected)==3162
    model,checkpoint = bound_model()
    assert fast['checkpoint']==eager['checkpoint']==checkpoint
    archived = fast['TensorRT']['trunk_screen']['artifacts']['trt-fp16']['engine']
    previous_review = read_json(ROOT.with_name('corpus100k-faster-inference-v1')/'trt-review.json')
    refs = {256:previous_review['small_engines']['trt-fp16']['engine'],
            512:previous_review['engines']['trt-fp16']['engine']}
    assert refs[512]==archived
    engines = {size:Engine(checked(path)) for size,path in refs.items()}
    jobs_start=gpu_jobs()
    metric_start=time.monotonic()
    done = dict(rows_by_key(PROGRESS)) if PROGRESS.exists() else {}
    for key,row in done.items():
        assert old[key]['source']==row['source'] and old[key]['archive']==row['archive']
    expected=sorted(expected,key=lambda row:row['stage']=='photo')
    records=[row for row in expected if (row['stage'],row['batch']) not in done]
    torch.cuda.synchronize()
    stream=torch.cuda.Stream()
    with (PROGRESS.open('a') as out, ThreadPoolExecutor(1) as pool, torch.cuda.stream(stream)):
        loaded = pool.submit(prepare,records[0]) if records else None
        for index,row in enumerate(records):
            stage,batch = row['stage'],row['batch']
            sensor = stage!='photo'
            archived = old[(stage,batch)]
            assert archived['source']==row['arrays']
            batch_cpu = loaded.result()
            loaded = pool.submit(prepare,records[index+1]) if index+1<len(records) else None
            data = {k:v.cuda(non_blocking=True) for k,v in batch_cpu.items()}
            for k in KEYS[:2]:
                data[k]=data[k].contiguous(memory_format=torch.channels_last)
            noise = row['context']['noise' if sensor else 'condition']
            model.set_noise(noise['shot'],noise['read'])
            shape = data['packed'].shape[-1]*2
            with selected(model,engines[shape]),amp_context('cuda',dtype='float16'):
                output=model(*(data[k] for k in KEYS))
            border=32 if sensor else 8
            cut=np.s_[...,border:-border,border:-border]
            if sensor:
                score,_=measured_sensor_psnr(output[cut],data['sensor_reference'][cut],data['sensor_mask'][cut])
            else:
                score=psnr(output[cut],data['target'][cut],data['wb'],data['matrix'])
            numbers=score.cpu().tolist()
            valid=[i for i,value in enumerate(numbers) if np.isfinite(value)]
            assert len(valid)==len(archived['scores'])
            rows=[]
            for case,i in zip(archived['scores'],valid,strict=True):
                assert case['id']==row['context']['ids'][i]
                rows.append(dict(case,trt_fp16=numbers[i]))
            result = {**archived,'scores':rows}
            done[(stage,batch)]=result
            out.write(json.dumps(result,allow_nan=False)+'\n')
            if index%50==0 or index+1==len(records):
                out.flush()
                print(len(done),stage,'seconds',round(time.monotonic()-metric_start,2),flush=True)
    assert len(done)==3162
    rows = [r for group in done.values() for r in group['scores']]
    photographic = lambda row: row['panel']=='photo' and not row['id'].startswith('synthetic-')
    scopes={'photo':paired_summary(rows,photographic)}
    for key in ('known','unseen'):
        scopes[key]=paired_summary(rows,lambda row: row['panel']==key)
    scopes['photo_conditions']={condition:paired_summary(rows,lambda row:photographic(row) and row['condition']==condition)
                                for condition in sorted({row['condition'] for row in rows if photographic(row)})}
    write_json(ROOT/'trt-canonical.json',{'driver':reference(__file__),'checkpoint':checkpoint,
      'engines':{str(size):ref for size,ref in refs.items()},'TRT':trt.__version__,'backend':versions(),
      'previous_engine_review':reference(FAST),'canonical_arrays':source,'paired_eager_source':reference(EAGER),
      'previous_progress':eager['progress'],'progress':reference(PROGRESS),'batches':len(done),
      'summaries':scopes,'current_invocation_seconds':time.monotonic()-metric_start,
      'jobs_before':jobs_start,'jobs_after':gpu_jobs()})
    print({key:scopes[key] for key in ('photo','known','unseen')},flush=True)


if __name__=='__main__':
    main()
