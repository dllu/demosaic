"""Verify exact full/local publications and current standalone API evidence."""
import gzip
import hashlib
import re
import subprocess
import tarfile
from pathlib import Path
from urllib.parse import unquote
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
publications = []
members_checked = 0
for name, source in [("neural-nuisance-spatial129-v1", ".cache/experiments/neural-nuisance-spatial129-pilot-v1/work"),
                     ("neural-nuisance-full-panel-v1", None)]:
    file = repo / "docs/results" / name / "publication.json"
    data = read_json(file)
    assert data["viewing"]["actually_viewed"]
    for item in data["archives"]:
        assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
    for item in data["images"]:
        assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
    checked(data["viewer"])
    if source:
        with tarfile.open(checked(data["source_snapshot"]), "r:gz") as tar:
            members = tar.getmembers()
            assert len(members) == data["source_files_exact"]
            for member in members:
                assert tar.extractfile(member).read() == (repo / source / member.name).read_bytes()
                members_checked += 1
    else:
        for bundle in [*data["source_snapshots"], data["per_case_receipts"]]:
            with tarfile.open(checked(bundle["archive"]), "r:gz") as tar:
                for item in bundle["members"]:
                    assert tar.extractfile(item["member"]).read() == checked(item["original"]).read_bytes()
                    members_checked += 1
    publications.append({"publication": reference(file), "exact_receipt_archives": len(data["archives"]),
                         "exact_native_figures_actually_viewed": len(data["images"])})

api = repo / "docs/results/neural-nuisance-spatial129-v1/public-api-addendum.json"
for item in read_json(api)["archives"]:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
root = repo / ".cache/experiments/neural-nuisance-spatial129-pilot-v1"
preserved = read_json(root / "publication-failure-v1.json")["preserved_files"]
hashes = {reference(file)["sha256"] for kind in ["images", "results"]
          for file in (repo / "docs" / kind / "neural-nuisance-spatial129-v1").rglob("*") if file.is_file()}
for item in preserved:
    assert reference(item["preserved_path"])["sha256"] == item["original"]["sha256"]
    assert item["original"]["sha256"] in hashes

names = subprocess.check_output(["git", "diff", "--name-only"], text=True).splitlines()
documents = {repo / name for name in names if name.endswith(".md")}
documents.update(repo / name for name in ["docs/spatial-carrier-amplitudes.md",
    "diary/2026-11-16-17-32-53-local-amplitude-reconstruction.md"])
links = 0
for file in sorted(documents):
    for target in re.findall(r"\]\(([^\n)]+)\)", file.read_text()):
        if target.startswith(("https:", "http:", "mailto:", "#")):
            continue
        assert (file.parent / unquote(target.split("#", 1)[0]).strip("<>")).exists(), (str(file), target)
        links += 1
destination = repo / "docs/results/neural-followups-publication-verification-v1.json"
script = destination.with_suffix(".py.gz")
with script.open("xb") as stream:
    stream.write(gzip.compress(Path(__file__).read_bytes(), mtime=0))
assert hashlib.sha256(gzip.decompress(script.read_bytes())).hexdigest() == reference(__file__)["sha256"]
write_json(destination, {"status": "passed", "publications": publications,
    "tar_members_checked_exactly": members_checked, "public_conditional_API": reference(api),
    "partial_publication_files_preserved_and_published_by_exact_contents": len(preserved),
    "local_document_links_checked": links, "documents_checked": [reference(p) for p in sorted(documents)],
    "script": reference(__file__), "script_archive": reference(script), "new_neural_forwards": 0,
    "scope": "Exact compressed archives, executed source/bundled receipt tar members, native PNG copies and completed actual-viewing receipts; standalone API matches72 closed outputs and157 numerical tests pass. No quality inference or model execution in this verification."})
print(publications)
print(members_checked, "exact tar members;", links, "local document links;207 partial contents preserved")
