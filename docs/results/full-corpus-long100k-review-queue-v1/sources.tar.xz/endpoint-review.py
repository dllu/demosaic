"""Wait for the declared 100k endpoint, then run native and canonical reviews."""

import argparse
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import psutil
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

ROOT = Path(__file__).resolve().parent
MODEL = "scale-long100k"
CONTROL = ("V120", "scale-long86k")
STEP = 100_000


def alive(owner):
    try:
        proc = psutil.Process(owner["pid"])
        return proc.create_time() == owner["create_time"] and proc.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False


def verify_controls(plan):
    path = checked(plan["native_plan"])
    old = read_json(path)
    result = read_json(checked(plan["native_collection"]))
    assert result["plan"] == reference(path) and result["models"] == old["models"]
    fresh = read_json(checked(result["fresh_collection"]))
    assert fresh["CPU_rng_unchanged"] and fresh["full_model_before"] == fresh["full_model_after"]
    assert fresh["root_calls"] == {CONTROL[1]: {"root": 110}}
    assert len(old["observations"]) == len(result["records"]) == 110
    output = []
    for obs, binding in zip(old["observations"], result["records"], strict=True):
        record = read_json(checked(binding))
        assert record["id"] == obs["id"] and record["input_fingerprints"] == obs["input_fingerprints"]
        variants = {v["label"]: v for v in record["variants"]}
        saved = [variants[k] for k in CONTROL]
        for variant in saved:
            spec = old["models"][variant["label"]]
            assert variant["checkpoint"] == spec["checkpoint"] and spec["weights"] == "EMA"
            checked(variant["prediction"])
        output.append(saved)
    return old, output


def bind_endpoint(plan):
    run = Path(plan["training_run"])
    stage_path = Path(plan["training_stage_result"])
    missed = 0
    while not stage_path.is_file():
        missed = 0 if any(alive(v) for v in plan["owners"]) else missed + 1
        if missed >= 3:
            raise RuntimeError("Training owners exited without a stage receipt")
        time.sleep(10)
    stage = read_json(stage_path)
    assert stage["production_plan"] == plan["training_plan"]
    assert stage["stage"] == "01-scale-long100k" and stage["returncode"] == 0
    run_result = run / "completed.json"
    terminal = read_json(run_result)
    last_phase = read_json(checked(terminal["phase"]))
    first_phase = read_json(checked(plan["first_phase"]))
    assert first_phase["from_step"] == 0 and first_phase["to_step"] == last_phase["from_step"] == 1_000
    assert last_phase["production_plan"] == plan["training_plan"]
    assert terminal["steps"] == last_phase["to_step"] == last_phase["LR_horizon"] == STEP
    assert last_phase["optimizer_EMA_RNG_preserved_on_resume"] and last_phase["DINO_unchanged"]
    assert terminal["checkpoint"] == last_phase["last"]
    retained = run / "step100000-receipt.json"
    step = read_json(retained)
    assert step["global_step"] == STEP and step["LR_horizon"] == STEP
    assert step["checkpoint"]["sha256"] == terminal["checkpoint"]["sha256"]
    checked(terminal["checkpoint"])
    state = torch.load(checked(step["checkpoint"]), map_location="cpu", weights_only=True)
    assert state["step"] == state["config"]["steps"] == STEP
    assert len(state["model"]) == len(state["ema"]) == 91
    assert len(state["optimizer"]["state"]) == 89
    assert all(v["step"] == STEP for v in state["optimizer"]["state"].values())
    assert all(torch.isfinite(t).all() for role in ("model", "ema") for t in state[role].values())
    assert all(torch.isfinite(t).all() for d in state["optimizer"]["state"].values()
               for t in d.values() if isinstance(t, torch.Tensor))
    assert state["python_rng"] and state["cuda_rng"] and state["torch_rng"].numel()

    endpoint = {
        "checkpoint": step["checkpoint"], "step": STEP, "training_horizon": STEP,
        "retained_progress": True, "weights": "EMA", "display_label": "Long schedule 100k EMA",
    }
    assert first_phase["examples"] + last_phase["examples"] == 1_600_000
    write_json(ROOT / "endpoint-admission.json", {
        "source": reference(__file__), "stage": reference(stage_path),
        "run": reference(run_result), "first_phase": plan["first_phase"], "final_phase": terminal["phase"],
        "retained_step": reference(retained), "model": endpoint, "training_slots": 1_600_000,
        "train_phase_seconds": [first_phase["seconds"], last_phase["seconds"]],
        "trained": True, "numerical_quality_review_complete": False, "native_viewing_complete": False,
    })
    return endpoint


def run_script(label, script, argument, work, threads):
    env = {
        **os.environ, "CUDA_VISIBLE_DEVICES": "", "PYTHONPATH": f"{work}/scripts:{work}/src",
        "OPENBLAS_NUM_THREADS": str(threads), "OMP_NUM_THREADS": str(threads), "PYTHONUNBUFFERED": "1",
    }
    cmd = [sys.executable, str(script), str(argument)]
    with (ROOT / f"{label}.log").open("xb") as log:
        proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        write_json(ROOT / f"{label}-launch.json",
                   {"pid": proc.pid, "create_time": psutil.Process(proc.pid).create_time(),
                    "command": cmd, "source": reference(script)})
        rc = proc.wait()
    write_json(ROOT / f"{label}-exit.json", {"returncode": rc})
    if rc:
        raise RuntimeError(f"{label} finished with {rc}; consult its own log")


def native(plan, spec, old, controls):
    dst = ROOT / "native"
    candidate = dst / "candidate"
    candidate.mkdir(parents=True)
    work = Path(old["work"])
    collector = checked(old["collector"])
    deps = [reference(ROOT / "endpoint-admission.json"), plan["native_plan"], plan["native_collection"]]
    initial = old | {
        "root": str(candidate), "models": {MODEL: spec}, "triplet_model": MODEL,
        "CPU_affinity": plan["native_affinity"], "CPU_threads": len(plan["native_affinity"]),
        "inputs": [*old["inputs"], *deps, spec["checkpoint"]],
        "retained_checkpoint_receipt": reference(Path(plan["training_run"]) / "step100000-receipt.json"),
        "scope": "Fixed 110 native inputs, fresh original-horizon 100k EMA CPU IEEE FP32. B1.",
    }
    path = candidate / "plan.json"
    write_json(path, initial)
    run_script("native-model", collector, path, work, initial["CPU_threads"])
    fetched = reference(candidate / "collection/result.json")
    collection = read_json(checked(fetched))
    assert collection["plan"] == reference(path) and collection["models"] == {MODEL: spec}
    assert collection["local_DINO"] == {"requests": 110, "executions": 110, "replays": 0}
    assert collection["root_calls"] == {MODEL: {"root": 110}}
    assert collection["full_model_before"] == collection["full_model_after"]
    assert collection["CPU_rng_unchanged"]
    paths = []
    complete = dst / "collection"
    complete.mkdir()
    for i, (obs, saved, binding) in enumerate(zip(initial["observations"], controls, collection["records"], strict=True)):
        r = read_json(checked(binding))
        assert r["id"] == obs["id"] and r["input_fingerprints"] == obs["input_fingerprints"]
        assert len(r["variants"]) == 1 and r["variants"][0]["checkpoint"] == spec["checkpoint"]
        assert r["variants"][0]["label"] == MODEL
        output = complete / f"case-{i:03d}.json"
        write_json(output, r | {"variants": [*saved, *r["variants"]]})
        paths.append(reference(output))
    combined = initial | {
        "root": str(dst), "models": {**{k: old["models"][k] for k in CONTROL}, MODEL: spec},
        "scope": "100k EMA and verified V120/86k EMA controls, identical conditioning and native inputs.",
    }
    write_json(dst / "plan.json", combined)
    write_json(complete / "result.json", {
        "plan": reference(dst / "plan.json"), "models": combined["models"], "records": paths,
        "fresh_collection": fetched, "saved_controls": plan["native_collection"],
        "fresh_root_calls": collection["root_calls"], "fresh_local_DINO": collection["local_DINO"],
        "fresh_collection_seconds": collection["seconds"], "saved_predictions_reused": 220,
    })
    run_script("native-render", work / "scripts/report_full_corpus_checkpoint_review.py", dst, work, 2)
    write_json(ROOT / "native-complete.json", {
        "report": reference(dst / "report/result.json"), "review_stage": "rendered; actual image viewing pending",
    })


def primary(plan, spec):
    template = read_json(checked(plan["primary_template"]))
    work = Path(template["work"])
    driver = checked(template["driver"])
    dst = ROOT / "primary-preflight"
    dst.mkdir()
    body = template | {
        "root": str(dst), "models": {MODEL: spec}, "parent_label": MODEL,
        "parent_reference_checks": [], "CPU_affinity": plan["primary_affinity"],
        "inputs": [template["canonical_inputs"], reference(ROOT / "endpoint-admission.json"), spec["checkpoint"]],
        "scope": "Three canonical CPU cases for 100k EMA. The complete V120 CPU reference is collected separately.",
    }
    write_json(dst / "plan.json", body)
    run_script("primary-preflight", driver, dst / "plan.json", work, body["CPU_threads"])
    receipt = reference(dst / "collection/result.json")
    closed = read_json(checked(receipt))
    assert closed["all_complete"] and closed["cases"] == 3 and closed["models"] == body["models"]
    full = ROOT / "primary"
    full.mkdir()
    final = body | {
        "root": str(full), "kind": "full", "maximum_seconds": 172800,
        "preflight": receipt, "inputs": [*body["inputs"], receipt],
        "scope": "All 3162 fixed canonical inputs in original order, candidate 100k EMA. "
        "CPU contiguous IEEE FP32 matching the qualified reference. V120 adopted separately from verified closed controls.",
    }
    write_json(full / "plan.json", final)
    run_script("primary", driver, full / "plan.json", work, final["CPU_threads"])


def main(path, *, preflight=False):
    torch.set_num_threads(2)
    os.nice(9)
    plan = read_json(path)
    assert plan["driver"] == reference(__file__) and not torch.cuda.is_initialized()
    verify_plan(plan)
    old, controls = verify_controls(plan)
    assert len(controls) == 110
    assert any(alive(o) for o in plan["owners"]) or Path(plan["training_stage_result"]).is_file()
    print("Verified 110 fixed cases and both EMA controls", flush=True)
    if preflight:
        return
    spec = bind_endpoint(plan)
    print("Admitted completed 100k", spec["checkpoint"], flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(f, *args) for f, args in (
            (native, (plan, spec, old, controls)), (primary, (plan, spec)),
        )]
        for done in futures:
            done.result()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    main(args.plan, preflight=args.preflight)
