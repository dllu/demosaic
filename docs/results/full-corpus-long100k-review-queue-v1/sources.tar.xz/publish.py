"""Record the live endpoint observer and its completed admission preflights."""

import tarfile
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
DEST = Path("docs/results/full-corpus-long100k-review-queue-v1")


def main():
    DEST.mkdir()
    launch = read_json(ROOT/"launch.json")
    assert launch["plan"] == reference(ROOT/"plan.json")
    assert launch["driver"] == reference(ROOT/"endpoint-review.py")
    p = psutil.Process(launch["pid"])
    assert p.create_time() == launch["create_time"] and p.status()!=psutil.STATUS_ZOMBIE
    assert p.cmdline() == launch["command"]
    assert "Verified 110 fixed cases and both EMA controls" in (ROOT/"watcher.log").read_text()
    assert "Verified 110 fixed cases and both EMA controls" in (ROOT/"preflight.log").read_text()
    adoption = read_json(ROOT/"adoption-preflight.json")
    dry = read_json(checked(adoption["camera_adoption_dry_run"]))
    assert dry["cases"] == 54
    values = {
        stage: {m["model"]:m["metrics"]["sensor_psnr"]["mean"] for m in table["overall"]}
        for stage,table in dry["summaries"].items()
    }
    assert abs(values["known"]["V120"] - 54.31271764967177) < 1e-10
    assert abs(values["unseen"]["V120"] - 54.00872213575575) < 1e-10
    assert all(len(v) == 2 for v in values.values())
    archive = DEST/"sources.tar.xz"
    members = [
        "endpoint-review.py","prepare.py","plan.json","launch.json","adopt-primary.py","preflight.log",
        "watcher.log","adoption-preflight.json","real-control-camera-dry-run/collection/result.json",
        "publish.py",
    ]
    payloads = {name:(ROOT/name).read_bytes() for name in members}
    with tarfile.open(archive,"x:xz") as f:
        for name in members:
            info=f.gettarinfo(ROOT/name,arcname=name)
            info.uid=info.gid=info.mtime=0
            info.uname=info.gname=""
            with (ROOT/name).open("rb") as stream:
                f.addfile(info,stream)
    with tarfile.open(archive,"r:xz") as f:
        assert all(f.extractfile(name).read()==content for name,content in payloads.items())
    write_json(DEST/"publication.json",{
        "sources":reference(archive),"plan":launch["plan"],"dispatch":reference(ROOT/"launch.json"),
        "alive":True,"native_inputs_verified":110,"native_control_predictions_verified":220,
        "prior_camera_case_adoption_dry_run":adoption,"prior_camera_dry_run_scores":values,
        "pending":"100k endpoint, actual 100k numerical scores and native inspection.",
    })
    print("Published bound endpoint watcher and 110-case/54-case qualifications.")


if __name__=="__main__":
    main()
