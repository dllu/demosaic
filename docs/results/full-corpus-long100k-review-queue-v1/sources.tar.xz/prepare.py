"""Bind the owned long-run process and the prior native/canonical benchmark inputs."""

from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
SCALE = ROOT.parent / "full-corpus-scaling-v3"
OLD = ROOT.parent / "full-corpus-long86k-native-v1"
PRIMARY = ROOT.parent / "local-primary-preflight-v1"


def main():
    controller = SCALE / "production-handoff-v7-launch.json"
    worker = SCALE / "production-handoff-v7/01-scale-long100k-launch.json"
    training = SCALE / "production-handoff-plan-v7.json"
    ctx, phase = read_json(controller), read_json(worker)
    assert ctx["plan"] == phase["production_plan"] == reference(training)
    assert 100000 in read_json(training)["retained_steps"]
    first = SCALE / "work/artifacts/train/long100k/phase-000001-001000/completed.json"
    result = SCALE / "production-handoff-v7/01-scale-long100k-result.json"
    destination = SCALE / "checkpoint-recovery-v7/work/artifacts/train/long100k"
    source_files = [controller, worker, training, first, OLD / "plan.json", OLD / "collection/result.json",
                    PRIMARY / "plan.json", Path(__file__)]
    write_json(ROOT / "plan.json", {
        "driver": reference(ROOT / "endpoint-review.py"), "inputs": list(map(reference, source_files)),
        "frozen_files": {},
        "training_plan": reference(training), "training_stage_result": str(result),
        "training_run": str(destination), "first_phase": reference(first),
        "native_plan": reference(OLD / "plan.json"), "native_collection": reference(OLD / "collection/result.json"),
        "primary_template": reference(PRIMARY / "plan.json"),
        "native_affinity": [6,7], "primary_affinity": [2,3,16,17],
        "owners": [{k: v[k] for k in ("pid","create_time")} for v in (ctx,phase)],
        "scope": "Wait for successful explicit 100k completion independent of other jobs. Verify raw/EMA/Adam/RNG, "
        "run 110 matched native cases and the full canonical primary candidate review, both CPU IEEE FP32. "
        "Native saved V120 and 86k controls checked before adoption. Broad V120 will be adopted from its separate exact CPU collection.",
    })


if __name__ == "__main__":
    main()
