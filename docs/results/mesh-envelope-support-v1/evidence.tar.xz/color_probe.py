"""Check whether a signed exterior color improves the known-gap RAW forecast."""

from importlib.util import module_from_spec, spec_from_file_location
import math
import os
import time

import numpy as np
import torch
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

from oracle import ROOT, sampled
from deliver import CENTRE, Carrier,window
from mesh import ribbon
from envelope_nuisance import observation,partition
from qualified import KNOTS,forecast

spec=spec_from_file_location("fresh_mesh_observations",ROOT/"observations.py")
generator=module_from_spec(spec)
spec.loader.exec_module(generator)


def color_direction(scene,colors,trace,pair):
    span=trace["donor_span"]
    w=np.outer(np.hanning(span//2),np.hanning(span//2))
    xn,yn=native_sites((span//2,span//2),(-(span-1)/2,)*2)
    cfa=np.broadcast_to(colors[:,None,None],xn.shape)
    tint=[]
    for cx,cy in trace["supporting_centers"]:
        raw=window(scene,(int(cx-span/2),int(cy-span/2),span,span),phase=2)
        p,q=(ribbon(xn+cx-384,yn+cy-384,c)for c in pair)
        a=np.stack((np.ones_like(xn),xn/span,yn/span,p,q),axis=-1)
        v=[]
        for col in range(3):
            select=cfa==col
            weight=np.broadcast_to(w,xn.shape)[select]
            fit=np.linalg.lstsq(a[select]*weight[:,None],raw[select]*weight,rcond=None)[0]
            v.append(float(fit[-1]))
        tint.append(v)
    v=np.median(tint,axis=0)
    return v/np.linalg.norm(v),tint


def shared_forecast(data,train,test,cut,tint):
    changes=[]
    for common_wave in (data.wave,data.wave*(1-cut)):
        blocks=[]
        for col in range(3):
            a,b=train&(data.colors==col),test&(data.colors==col)
            design=data.nuisance[a]
            values=data.raw[a]
            variance=data.shot*max(1e-4,float(np.median(values)))+data.read
            prototype=common_wave*tint[col]
            beta,predict=np.linalg.lstsq(design,np.column_stack((values,prototype[a])),rcond=None)[0].T
            r=values-design@beta
            d=prototype[a]-design@predict
            x=data.nuisance[b]
            blocks.append((float(d@r)/variance,float(d@d)/variance,data.raw[b]-x@beta,prototype[b]-x@predict,variance))
        best=sum(b[0]for b in blocks)/max(1e-12,sum(b[1]for b in blocks))
        changes.append([(res-bias*best,variance)for _,_,res,bias,variance in blocks])
    overlap=power=0.
    for (res,var),(cut_res,_) in zip(*changes,strict=True):
        diff=res-cut_res
        overlap+=float(res@diff)/var
        power+=float(diff@diff)/var
    gain=2*overlap-power
    return {"gain":gain,"z":gain/(2*math.sqrt(max(power,1e-12))),"power":power}


def run():
    plan=read_json(ROOT/"fresh-plan.json")
    records=[]
    begin=time.monotonic()
    for entry in plan["cases"]:
        if entry["kind"]!="gaps":
            continue
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-begin>1800:
                raise TimeoutError(path)
            time.sleep(2)
        case=read_json(path)
        prior=plan["noise"][entry["profile"]]
        kin=case["details"]["matching"]
        evidence=kin["roles"][1]
        if "central_pair" not in evidence:
            continue
        values,ext,_,_,_=generator.observe(entry["g"],entry["layout"],prior,entry["seed"])
        with np.load(checked(case["array"]),allow_pickle=False)as f:
            np.testing.assert_array_equal(values["packed"],f["packed"])
            local=window(f["packed"][1],CENTRE,phase=2)
            flags=f["colors"][1]; present=window(f["support"],CENTRE)
        pair=tuple(Carrier(**v)for v in evidence["central_pair"])
        # Recenter on the exterior model when it is available and keep
        # direction alignment with the rear profile in the local query.
        from transport import ordered_like
        if kin["donors"] and kin["donors"].get("carriers"):
            learned=tuple(Carrier(**p["carrier"])for p in kin["donors"]["carriers"])
            transported=ordered_like(learned,pair)
        else:
            transported=pair
        tint,individual=color_direction(ext["matching"],flags,kin["geometry"],transported)
        nx,ny=native_sites(local.shape[-2:],(-127.5,-127.5))
        front,rear=(ribbon(nx,ny,g)for g in pair)
        data=observation(local,flags,front,rear,prior,KNOTS,flexible=True)
        mask=sampled(np.broadcast_to(1-present,(3,*present.shape)),flags).ravel()
        scores={}
        for sampling in ("columns","distributed"):
            slot=partition(local.shape,sampling)
            a,b,d=(slot==i for i in (1,2,3))
            for name in ("separate","donor-color"):
                method=(lambda u,v:forecast(data,u,v,mask))if name=="separate"else(lambda u,v:shared_forecast(data,u,v,mask,tint))
                values=[method(u,v)for u,v in ((a,b),(b,a),(a|b,d))]
                scores[sampling+"/"+name]={
                    "scores":values,"passed":min(v["z"]for v in values[:2])>.75 and values[-1]["z"]>1.5}
        records.append({"id":case["id"],"case":reference(path),"color":tint.tolist(),
                        "donor_tile_colors":individual,"scores":scores})
        print(case["id"],tint.tolist(),[(k,[round(s["z"],2)for s in v["scores"]],v["passed"])
                                      for k,v in scores.items()],flush=True)
    write_json(ROOT/"color-probe.json",{"driver":reference(__file__),"plan":reference(ROOT/"fresh-plan.json"),"rows":records,
                                        "scope":"Later exact-mask diagnostic. Nominate the physical signed RGB direction using the disjoint matching donor tiles. Hold the measured local phase and true cut fixed. Scores compare independent color fitting and the same one-scalar conditional fit."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12);torch.set_num_threads(2)
    run()
