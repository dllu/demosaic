"""Replay the archived 13-shift fit with a frozen exterior carrier override."""

import numpy as np
from demosaic.isolated_line import coordinates
from deliver import geometry, window, evidence
from mesh import restore

def correction(field,packed,var,colors,query,roi,freq,g,noise,*,packed_offset=0, replace_pair=None):
    raw=window(packed,query,phase=2)
    old=window(field,query)
    shade=lambda a: window(a,(roi[0]-query[0],roi[1]-query[1],roi[2],roi[3]))
    pair,z=geometry.reserve_candidates(raw,colors,freq,g,noise,packed_offset=packed_offset)
    if replace_pair is not None:
        pair = replace_pair(pair)
    if max(z)<3:
        return np.zeros_like(shade(old)), {'status':'no reserve proposal'}
    scores=evidence(raw,colors,pair,noise,packed_offset)
    if not scores['passes']:
        return np.zeros_like(shade(old)), {'status':'RAW prediction rejected','checks':scores}
    reserve=(np.indices(raw.shape[-2:])[1]+packed_offset)%4==0
    shot,read=noise['shot'],noise['read']
    variance=window(var,query,phase=2)
    fits=[];supports=[]
    for lines,method in ((pair[::-1],'add'),(pair,'adaptive')):
        new,r=restore(old,raw,variance,colors,lines,(shot,read),method=method,reserved=reserve)
        if r[0]['basis'] is None:
            return np.zeros_like(shade(old)), {'status':'fit rejected','checks':scores}
        _,local=restore(old,raw,variance,colors,lines,(shot,read),method=method,local=True,reserved=reserve,dense=True)
        fits.append(new);supports.append(local)
    x,y=coordinates(*old.shape[-2:],origin=(-127.5,-127.5))
    mask=np.zeros_like(x);denom=np.zeros_like(x)
    for l,r in zip(*supports,strict=True):
        cx,cy=l['center']
        taper=np.maximum(0,1-abs(x-cx)/64)*np.maximum(0,1-abs(y-cy)/64)
        denom+=taper
        mask+=taper*min(l['blend'],r['blend'])
    addition=(fits[0].astype(float)-old)+(fits[1].astype(float)-old)
    weight = mask[None] / np.maximum(denom,1e-8)
    value = (old + addition * weight).astype(old.dtype)
    front = ((fits[0].astype(float)-old)*weight).astype(old.dtype)
    return shade(value-old),{'front_delta':shade(front),'status':'supported','checks':scores,'support_fraction':float(np.count_nonzero(mask)/mask.size),'phase_candidates':[dict(frequency=q.frequency,offset=q.offset,width=q.width,perspective=q.perspective) for q in pair]}

