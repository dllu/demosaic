"""Replay smooth spatial support on previously bound projected-wire queries."""

import os
from pathlib import Path
from statistics import mean

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from deliver import CENTRE, DISPLAY, Carrier, score, window
from mesh import ribbon
from demosaic.isolated_line import native_sites

from qualified import audit_masks

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "donor-phase-transport-v1"
POLICIES = {
    f"{sampling}/{profile}/{agreement}": (sampling, profile, 1.5, agreement)
    for sampling in ("columns", "distributed")
    for profile in ("soft", "firm")
    for agreement in (True, False)
}


def run():
    source = read_json(PREVIOUS / "attenuation.json")
    plan = read_json(checked(source["plan"]))
    rows = []
    for archived in source["rows"]:
        row = read_json(checked(archived["case"]))
        entry = row["entry"]
        noise = plan["noise"][entry["profile"]]
        with np.load(checked(row["array"]), allow_pickle=False) as data:
            parent, target, packed, colors, delta = (data[k] for k in
                ("parent", "target", "packed", "colors", "matching/transported"))
            regions = {k: data[k] for k in ("strong_phase", "weak_phase", "support")}
        selected = {key: delta.copy() for key in POLICIES}
        notices = {}
        for evidence in archived["fixed_pair_evidence"]:
            role = evidence["role"]
            pair = [Carrier(**d) for d in evidence["pair"]]
            raw = window(packed[role], CENTRE, phase=2)
            p, q = (ribbon(*native_sites(raw.shape[-2:], (-127.5, -127.5)), carrier) for carrier in pair)
            assessed = audit_masks(raw, colors[role], p, q, noise, CENTRE, DISPLAY, POLICIES.values())
            for label, spec in POLICIES.items():
                mask, summary = assessed[spec]
                selected[label][role] = delta[role] * (1 - mask[None])
                notices.setdefault(label, []).append(summary)
        scored = {key: score(parent, value, target, regions) for key, value in selected.items()}
        rows.append({
            "entry": entry, "id": row["id"], "original": archived["case"],
            "metrics": scored, "checks": notices,
            "wide": row["metrics"]["matching/transported"], "previous": archived["modes"],
        })
        print(row["id"], [(k,round(v[0]["forecast"][-1]["z"],2),round(v[0]["mask_mean"],3))
                          for k, v in notices.items() if k.endswith("True")], flush=True)
    for profile in ("iso400", "iso6400"):
        for kind in ("continuous", "gaps"):
            cases = [r for r in rows if r["entry"]["profile"] == profile
                     and (r["entry"]["layout"] == "continuous") == (kind == "continuous")]
            for method in ("wide", "column", "short", *POLICIES):
                v = [r["wide"] if method == "wide" else r["previous"][method] if method in ("column", "short")
                     else r["metrics"][method] for r in cases]
                print(profile, kind, method, round(mean(x["response"][0] for x in v)*100,2),
                      round(mean(x["increment_RMS_DN16"][0] for x in v),2),
                      round(mean(x["gap_added_RMS_DN16"] or 0 for x in v),2),
                      sum(a["response"] != b["wide"]["response"] for a,b in zip(v,cases,strict=True)), flush=True)
    write_json(ROOT / "qualified-dev.json", {"rows": rows, "configs": POLICIES, "source": reference(PREVIOUS / "attenuation.json"),
                                      "driver": reference(__file__), "fit": reference(ROOT / "qualified.py")})


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    run()
