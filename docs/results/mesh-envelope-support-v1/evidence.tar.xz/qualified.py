"""Audit the actual attenuation mask nominated by a spatial RAW fit."""

import math

import numpy as np
from demosaic.isolated_line import coordinates

from envelope_nuisance import basis, observation, partition, prepare, solve

KNOTS = (-72, -36, 0, 36, 72)


def forecast(data, train, test, cut):
    nuisance = data.nuisance
    whole_wave = data.wave
    supported_wave = whole_wave * (1 - cut)
    overlap = power = 0.0
    for color in range(3):
        a, b = train & (data.colors == color), test & (data.colors == color)
        segment = data.raw[a]
        variance = data.shot * max(1e-4, float(np.median(segment))) + data.read
        whole = np.column_stack((nuisance, whole_wave))
        finite = np.column_stack((nuisance, supported_wave))
        fits = [x[b] @ np.linalg.solve(x[a].T @ x[a], x[a].T @ segment) for x in (whole, finite)]
        change = fits[1] - fits[0]
        overlap += float((data.raw[b] - fits[0]) @ change) / variance
        power += float(change @ change) / variance
    gain = 2 * overlap - power
    return {"z": gain / (2 * math.sqrt(max(power, 1e-12))), "gain": gain, "change_power": power}


def field_cut(b, ref, coeff, profile):
    peak = max(.4, float(np.quantile(1 + ref @ coeff, .8)))
    relative = (1 + b @ coeff) / peak
    if profile == "soft":
        return np.clip(.90 - relative, 0, 1)
    return np.clip((.78 - relative) / .50, 0, 1)


def audit_masks(raw, colors, front, rear, noise, query, roi, specs):
    data = observation(raw, colors, front, rear, noise, KNOTS, flexible=True)
    nx, ny = coordinates(256, 256, origin=(-127.5, -127.5))
    lo_x, lo_y = roi[0] - query[0], roi[1] - query[1]
    w, h = roi[2:]
    y, x = np.s_[lo_y:lo_y+h, lo_x:lo_x+w]
    display = basis(nx[y,x], ny[y,x], KNOTS)
    reference = basis(nx[::5,::5], ny[::5,::5], KNOTS)
    cache = {}
    result = {}
    for sampling, profile, threshold, agreement in specs:
        if sampling not in cache:
            slot = partition(raw.shape, sampling)
            a,b,d = [slot == k for k in (1,2,3)]
            folds = ((a,b),(b,a),(a | b,d))
            models = [solve(prepare(data, t, v), 1.2) for t,v in folds]
            cache[sampling] = folds, models
        folds, models = cache[sampling]
        crops = [field_cut(display, reference, coeff, profile) for coeff, _ in models]
        cuts = [field_cut(data.spline, reference, coeff, profile) for coeff, _ in models]
        if agreement:
            cuts[2] = np.minimum.reduce(cuts)
            crops[2] = np.minimum.reduce(crops)
        scores = [forecast(data, t, v, cut) for (t,v),cut in zip(folds,cuts,strict=True)]
        passed = min(x["z"] for x in scores[:2]) > 0.75 and scores[2]["z"] > threshold
        crop = crops[2].reshape(h,w) if passed else np.zeros((h,w))
        result[(sampling, profile, threshold, agreement)] = crop, {
            "forecast": scores, "spatial_forecast": [m for _, m in models], "passed": bool(passed),
            "mask_max": float(crop.max()), "mask_mean": float(crop.mean()),
        }
    return result
