"""Evaluate spatial masks on all eight composed, packaged RAW outputs."""

import os
from pathlib import Path
import sys

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import coordinates, native_sites
from demosaic._mesh_frequency import adjacent_prior, infer_prior, query_phases, ADJACENT_SEARCH
from demosaic._mesh_profiles import extra_query_check,fit_direction,ribbon
from demosaic.mesh_refinement import TRANSLATIONS, _overlap_correction

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/"donor-phase-transport-v1"
sys.path.insert(1,str(PRIOR))
from deliver import window
from standing import legacy
from qualified import audit_masks

SPECS=[("columns","firm",1.5,False),("distributed","firm",1.5,False)]


def front_field(parent, packed, variance, colors, box, roi, noise, prior, **opts):
    x, y = coordinates(256,256,origin=(-127.5,-127.5))
    strips=[]
    terms=[]
    for dx,dy in TRANSLATIONS:
        query=box[0]+dx,box[1]+dy,*box[2:]
        source=window(parent,query)
        raw=window(packed,query,phase=2)
        var=window(variance,query,phase=2)
        offset=dx//2
        pair,reserve,levels=query_phases(raw,colors,prior,noise,packed_offset=offset,**opts)
        front_delta=np.zeros_like(source)
        full_delta=front_delta
        shot,read=noise["shot"],noise["read"]
        if max(levels)>=3 and extra_query_check(raw,colors,pair,shot,read,offset):
            front,left=fit_direction(source,raw,var,colors,pair[::-1],reserve,shot,read,occlusion=False)
            back,right=fit_direction(source,raw,var,colors,pair,reserve,shot,read,occlusion=True)
            if left is not None and right is not None:
                mask,denominator=np.zeros_like(x),np.zeros_like(x)
                for (cx,cy,a),(_,_,b) in zip(left,right,strict=True):
                    t=np.maximum(0,1-abs(x-cx)/64)*np.maximum(0,1-abs(y-cy)/64)
                    denominator+=t
                    mask+=t*min(a,b)
                mask/=np.maximum(denominator,1e-8)
                combined=front.astype(float)+back.astype(float)-source
                full_delta=(source+mask[None]*(combined-source)).astype(source.dtype)-source
                front_delta=((front.astype(float)-source)*mask[None]).astype(source.dtype)
        cut=(roi[0]-query[0],roi[1]-query[1],*roi[2:])
        strips.append(window(full_delta,cut))
        terms.append(window(front_delta,cut))
    values=np.stack(strips)
    chosen=np.argpartition(values,len(values)//2,axis=0)[len(values)//2][None]
    median=np.take_along_axis(values,chosen,axis=0)[0]
    retained=np.take_along_axis(np.stack(terms),chosen,axis=0)[0]
    return median,np.where(median!=0,median.astype(float)-retained,0)


def rms(value):
    return float(np.sqrt(np.mean(value.astype(float)**2))*65535)


def run():
    old=read_json(PRIOR/"port.json")
    measurements={v["id"]:v for v in old["cases"]}
    visual={v["id"]:v for v in read_json(PRIOR/"adjacent-ranked.json")["views"]}
    source=read_json(ROOT.parent/"local-mesh-phase-evidence-v1"/"camera.json")
    dest=ROOT/"camera";dest.mkdir()
    records=[]
    for row in source["views"]:
        name=row["id"]; previous=measurements[name]; view=visual[name]
        box,roi,noise=row["query"],row["ROI"],row["noise"]
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            raw,var,colors=(f[k][0]for k in ("packed","variance","colors"))
            render={k:f[k]for k in ("wb","matrix")}
        parent=np.load(checked(row["parent"]),allow_pickle=False)[0]
        base=window(parent,roi)
        with np.load(checked(previous["native_array"]),allow_pickle=False)as f:
            package=f["adjacent"]
            old_gap=f["adjacent_gap"]
        package_delta=package-base
        cert={}
        whole=rear=distributed=package
        if package_delta.any():
            cfg={}; spacing=previous["noise"]["donor_span"]
            prior=infer_prior(raw,colors,box,noise,span=spacing)
            median, pair=_overlap_correction(parent,raw,var,colors,box,roi,noise,prior)
            if median is None or not median.any():
                prior=adjacent_prior(raw,colors,box,noise)
                cfg={"search": ADJACENT_SEARCH}
                median,pair=_overlap_correction(parent,raw,var,colors,box,roi,noise,prior,**cfg)
            np.testing.assert_array_equal(base+median,package)
            combined,rear_delta=front_field(parent,raw,var,colors,box,roi,noise,prior,**cfg)
            np.testing.assert_array_equal(combined,median)
            local=window(raw,box,phase=2)
            p,q=(ribbon(*native_sites(local.shape[-2:],(-127.5,-127.5)), wave)for wave in pair)
            cut=audit_masks(local,colors,p,q,noise,box,roi,SPECS)
            mask,cert["columns"]=cut[SPECS[0]]
            distributed_mask,cert["distributed"]=cut[SPECS[1]]
            whole=base+(median*(1-mask[None])).astype(median.dtype)
            distributed=base+(median*(1-distributed_mask[None])).astype(median.dtype)
            rear=base+(median-rear_delta*mask[None]).astype(median.dtype)
        w,h=roi[2:]
        panels=[(label,legacy.pixel(v,render,(0,0,w,h),row["exposure"]))for label,v in (
            ("Crop helper + adjacent",package),("Smooth RAW support",whole),("Rear only",rear),
            ("Distributed smooth",distributed))]
        board={"image":view["image"],"panels":[p for p in view["panels"] if p["label"]
                                              not in ("Short support","Donor projective","Median, anchored split","Adjacent donor fallback")]}
        image,positions=legacy.insert_camera_panels(dest,name,board,"Wider donors",panels)
        out=dest/(name+".npz")
        np.savez_compressed(out,before=package,whole=whole,rear=rear,distributed=distributed)
        differences={k:rms(v-package)for k,v in (("whole",whole),("rear",rear),("distributed",distributed),("old_gap",old_gap))}
        records.append({"id":name,"source":row["input"],"RAW":view["RAW"],"parent":row["parent"],"prior_view":view["image"],
                        "camera_delta":reference(out),"image":image,"panels":positions,"ROI":roi,"query":box,"noise":noise,
                        "exposure":row["exposure"],"checks":cert,"changes_DN16":differences})
        print(name,differences,{k:tuple(round(x["z"],2)for x in v["forecast"])for k,v in cert.items()},flush=True)
    assert len(records)==8
    write_json(ROOT/"camera.json",{"source":reference(PRIOR/"port.json"),"driver":reference(__file__),"checkpoint":old["checkpoints"][0],
                                   "views":records,"scope":"Matched package outputs based on bound 2k parent and adjacent option. Real references remain qualitative. The independent RAW mask only scales the existing crop correction or its rear contribution."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
