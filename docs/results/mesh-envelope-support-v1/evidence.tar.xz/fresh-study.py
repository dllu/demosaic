"""Validate smooth masks on fresh exact RAW observations and the same 13 placements."""

import importlib.util
import os
from pathlib import Path
import sys
from itertools import product
import time

import numpy as np
import torch
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "donor-phase-transport-v1"
sys.path.insert(1,str(PREVIOUS))
diagnostic = importlib.util.spec_from_file_location("diagnose", PREVIOUS / "diagnose.py")
sys.modules["diagnose"] = importlib.util.module_from_spec(diagnostic)
diagnostic.loader.exec_module(sys.modules["diagnose"])
from delivery import prepare
from deliver import CENTRE,DISPLAY,proposals,window,score,geometry
from mesh import ribbon
from transport import ordered_like

from directional import reconstruct
from qualified import audit_masks
sampler = importlib.util.spec_from_file_location("new_wire_observations", ROOT / "observations.py")
generator = importlib.util.module_from_spec(sampler)
sampler.loader.exec_module(generator)
observe = generator.observe

spec=importlib.util.spec_from_file_location("prior_gap_assessment",PREVIOUS/"attenuate.py")
old=importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)

POLICIES = {
    "spline-columns": ("columns","firm",1.5,False),
    "spline-distributed": ("distributed","firm",1.5,False),
}
MODES = ("query", "wide", "column", "distributed", "short", *POLICIES, "spline-rear", "spline-column-union")


def apply(all_data, parent, masks, surroundings, noise, entry):
    raw,var,colors,clean=(all_data[k].numpy()for k in ("packed","variance","colors","target"))
    metrics={"parent":score(parent,None,clean,masks)}
    details={}; outcome={}
    for outside, scene in surroundings.items():
        if outside=="phase-shifted" or (outside=="unrelated" and entry["g"] not in (161,164)):
            continue
        _,trace=proposals(scene,colors[0],(256,256,256,256),noise,80)
        config,moved,donors=prepare(lambda x,y,s:window(scene,(x,y,s,s),phase=2),trace,colors[0],noise,(383.5,383.5))
        current={k:[] for k in MODES}; proofs=[]
        for role in range(3):
            cfa=colors[role]
            args=parent[role],raw[role],var[role],cfa,CENTRE,DISPLAY,noise,config
            baseline,rear,checks=reconstruct(*args,None)
            broad,phase=baseline,None
            if moved is not None:
                changed,other,extra=reconstruct(*args,moved)
                if changed.any():
                    broad,rear,checks,phase=changed,other,extra,moved
            local=window(raw[role],CENTRE,phase=2)
            choices={"query":baseline,"wide":broad}
            note={"role":role,"carried":bool(phase),"wide_placements":sum(r["status"]=="supported"for r in checks)}
            if broad.any():
                pair,_=geometry.reserve_candidates(local,cfa,*config,noise)
                if phase:
                    pair=pair[0],ordered_like(phase,pair)[1]
                sites=native_sites(local.shape[-2:],(-127.5,-127.5))
                p,q=(ribbon(*sites,g)for g in pair)
                cut=audit_masks(local,cfa,p,q,noise,CENTRE,DISPLAY,POLICIES.values())
                for k,s in POLICIES.items():
                    mask,witness=cut[s]
                    note[k]=witness
                    choices[k]=(broad*(1-mask[None])).astype(broad.dtype)
                mask=cut[POLICIES["spline-columns"]][0]
                choices["spline-rear"]=(broad-rear*mask[None]).astype(broad.dtype)
                for k,scheme in (("column","columns-proxy"),("distributed","balanced-proxy")):
                    choices[k],note[k]=old.previous_gap.apply(broad,raw[role],cfa,pair,noise,CENTRE,DISPLAY,scheme)
                choices["short"]=old.short.shorten(broad,local,cfa,[vars(c)for c in pair],noise,CENTRE,DISPLAY,0)
                # Both methods are attenuation. Retain the larger verified cut.
                choices["spline-column-union"]=np.where(abs(choices["column"])<abs(choices["spline-columns"]),
                                                       choices["column"],choices["spline-columns"])
                note["central_pair"]=[vars(c)for c in pair]
            for k in MODES:
                current[k].append(choices.get(k,broad))
            current.setdefault("broad-rear",[]).append(rear)
            proofs.append(note)
        for k, result in current.items():
            delta=np.stack(result)
            outcome[outside+"/"+k]=delta
            if k!="broad-rear":
                metrics[outside+"/"+k]=score(parent,delta,clean,masks)
        details[outside]={"donors":donors,"geometry":trace,"roles":proofs}
    return metrics,outcome,details


@torch.inference_mode()
def main():
    inherited=ROOT.parent/"donor-phase-transport-v1"/"fresh-plan.json"
    plan=read_json(inherited)
    out=ROOT/"fresh";out.mkdir()
    entries=[]
    for i,(prior,kind,g) in enumerate(product(("iso6400","iso400"),("continuous","gaps"),range(160,166))):
        layout=("disk"if g%2==0 else"band")if kind=="gaps"else("step"if g%2 else"continuous")
        entries.append({"id":f"{prior}-{layout}-g{g}","profile":prior,"kind":kind,
                        "layout":layout,"g":g,"seed":651387645+i*34877+g*223})
    spec={"runner":reference(__file__),"cases":entries,"reference":reference(inherited),
          "checkpoint":plan["checkpoint"],"noise":plan["noise"],"policies":POLICIES,
          "files":[reference(ROOT/k)for k in ("observations.py","directional.py","split_fit.py","qualified.py","envelope_nuisance.py")],
          "query":CENTRE,"ROI":DISPLAY,
          "scope":"Exact-target prospectively assigned 24-case panel. Six continuous (three over steps) and six gaps at each prior. Same rotated donor control on two distinct geometries per cell. Existing local predictions and phase proposals are shared across attenuation choices."}
    write_json(ROOT/"fresh-plan.json",spec)
    key=plan["checkpoint"]
    model,model_spec=load_scene_checkpoint(checked(key),device="cuda",weights="ema",expected_sha256=key["sha256"])
    assert model_spec["step"]==2000
    model.mode="none";del model_spec
    results=[];start=time.monotonic()
    with ieee_fp32():
        for entry in entries:
            noise=plan["noise"][entry["profile"]]
            values,surrounds,masks,sensor,identity=observe(entry["g"],entry["layout"],noise,entry["seed"])
            model.base.set_noise(noise["shot"],noise["read"])
            parent=model(*(values[k].cuda()for k in ("packed","variance","colors","wb","matrix"))).cpu().numpy()
            metrics,arrays,details=apply(values,parent,masks,surrounds,noise,entry)
            path=out/(entry["id"]+".npz")
            np.savez_compressed(path,parent=parent,**{k:v.numpy()for k,v in values.items()},**masks,**arrays)
            summary=out/(entry["id"]+".json")
            write_json(summary,{"id":entry["id"],"entry":entry,"metrics":metrics,"sensor":sensor,"identity":identity,
                                 "details":details,"array":reference(path),"input":{k:fingerprint(v)for k,v in values.items()}})
            results.append(reference(summary))
            print(entry["id"],[(k,round(v["response"][0]*100,2),round(v["gap_added_RMS_DN16"] or 0,2))
                               for k,v in metrics.items()if k.startswith("matching/")],
                  round(time.monotonic()-start,1),flush=True)
    assert len(results)==24
    write_json(ROOT/"fresh.json",{"driver":reference(__file__),"plan":reference(ROOT/"fresh-plan.json"),
                                   "cases":results,"seconds":time.monotonic()-start})


if __name__=="__main__":
    os.sched_setaffinity(0,[12,13]);os.nice(12);torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    main()
