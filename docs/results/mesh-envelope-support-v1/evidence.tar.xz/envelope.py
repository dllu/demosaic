"""Compare constant and smoothly varying rear profiles on disjoint Bayer sites."""

from dataclasses import dataclass
import math

import numpy as np
from scipy.interpolate import BSpline
from demosaic.isolated_line import coordinates, native_sites


def basis(x, y, knots):
    """Tensor product of compact, quadratic B-splines in native pixels."""
    bounds = np.r_[[-128.0] * 3, knots, [128.0] * 3]
    bx = BSpline.design_matrix(x.ravel(), bounds, 2).toarray()
    by = BSpline.design_matrix(y.ravel(), bounds, 2).toarray()
    return (by[:, :, None] * bx[:, None, :]).reshape(len(bx), -1)


def partition(raw_shape, scheme):
    yy, xx = np.indices(raw_shape[-2:])
    reserve = xx % 4 == 0
    group = 1 + (xx % 4 - 1 + yy) % 3 if scheme == "distributed" else xx % 4
    return np.broadcast_to(np.where(reserve, 0, group), raw_shape).ravel()


@dataclass
class Observation:
    raw: np.ndarray
    colors: np.ndarray
    wave: np.ndarray
    nuisance: np.ndarray
    spline: np.ndarray
    positions: tuple
    shot: float
    read: float


def observation(raw, colors, front, rear, noise, knots, *, step=None):
    native_x, native_y = native_sites(raw.shape[-2:], (-127.5, -127.5))
    x, y = native_x.ravel(), native_y.ravel()
    u, v = x / 128, y / 128
    p = front.ravel()
    background = [np.ones_like(u), u, v, u*u, u*v, v*v, p, p*u, p*v]
    if step is not None:
        background.append(step)
    return Observation(
        raw.ravel().astype(float), np.broadcast_to(np.asarray(colors)[:, None, None], raw.shape).ravel(),
        (rear * (1 - front)).ravel(), np.column_stack(background), basis(x, y, knots), (x, y),
        noise["shot"], noise["read"],
    )


def prepare(data, train, test):
    """Use only the learning samples for the nuisance fit and variance scale."""
    augmented = np.column_stack((data.nuisance, data.wave))
    folds = []
    for color in range(3):
        learn = train & (data.colors == color)
        check = test & (data.colors == color)
        y = data.raw[learn]
        x = augmented[learn]
        z = augmented[check]
        variance = data.shot * max(1e-4, np.median(y)) + data.read
        raw_spline = data.spline[learn] * data.wave[learn, None]
        design = np.column_stack((y, raw_spline))
        solution = np.linalg.solve(x.T @ x, x.T @ design)
        residual = design - x @ solution
        gain = solution[-1, 0]
        projected = raw_spline * gain - x @ (solution[:, 1:] * gain)
        rhs = residual[:, 0]
        test_wave = data.spline[check] * (data.wave[check, None] * gain)
        test_change = test_wave - z @ (solution[:, 1:] * gain)
        # The coefficients can be positive or negative on each camera color.
        # Only spatial modulation is shared.
        folds.append({
            "design": projected, "residual": rhs, "variance": variance,
            "test_residual": data.raw[check] - z @ solution[:, 0],
            "test_design": test_change, "linear_gain": float(gain),
        })
    lhs = sum(row["design"].T @ row["design"] / row["variance"] for row in folds)
    rhs = sum(row["design"].T @ row["residual"] / row["variance"] for row in folds)
    return lhs, rhs, folds


def solve(parts, penalty):
    lhs, rhs, folds = parts
    # Feature units model a fractional change in the already fitted wave.
    scale = np.median(np.diag(lhs))
    fit = np.linalg.solve(lhs + np.eye(len(rhs)) * (penalty * scale + 2), rhs)
    overlap = power = 0.0
    for row in folds:
        change = row["test_design"] @ fit
        overlap += float(row["test_residual"] @ change) / row["variance"]
        power += float(change @ change) / row["variance"]
    delta = 2 * overlap - power
    return fit, {"delta": float(delta), "z": float(delta / (2 * math.sqrt(max(power, 1e-12)))),
                 "power": float(power), "color_gains": [row["linear_gain"] for row in folds]}


def deficit(grid, ref_grid, coefficients, slack):
    # Shift the relative map by the fitted broader amplitude. The global
    # regression set its zero point using the same waveform across the query.
    field = 1 + grid @ coefficients
    ref = max(0.4, float(np.quantile(1 + ref_grid @ coefficients, 0.8)))
    return np.clip(1 - field / ref - slack, 0.0, 1.0)


def fit_masks(raw, colors, front, rear, noise, query, roi, specs):
    """Return only crops of masks with reproducible held-out amplitude evidence."""
    height, width = 2 * raw.shape[-2], 2 * raw.shape[-1]
    width_out, height_out = roi[2:]
    lo_x, lo_y = roi[0] - query[0], roi[1] - query[1]
    x, y = coordinates(height, width, origin=(-127.5, -127.5))
    partitions = {spec[0]: partition(raw.shape, spec[0]) for spec in specs}
    held = {}
    result = {}
    zero = np.zeros((height_out, width_out), dtype=float)
    for scheme, knots, penalty, threshold, consensus in specs:
        cache = scheme, knots
        if cache not in held:
            data = observation(raw, colors, front, rear, noise, knots)
            slot = partitions[scheme]
            a, b, d = (slot == i for i in (1, 2, 3))
            folds = [prepare(data, train, test) for train, test in ((a, b), (b, a), (a | b, d))]
            ry, rx = np.s_[lo_y:lo_y + height_out, lo_x:lo_x + width_out]
            grid = basis(x[ry, rx], y[ry, rx], knots)
            ref = basis(x[::5, ::5], y[::5, ::5], knots)
            held[cache] = folds, grid, ref
        folds, grid, ref = held[cache]
        fits = [solve(part, penalty) for part in folds]
        scores = [metrics for _, metrics in fits]
        passed = min(s["z"] for s in scores[:2]) > 0 and scores[-1]["z"] > threshold
        mask = zero
        if passed:
            cuts = [deficit(grid, ref, values, slack=0.10) for values, _ in fits]
            mask = (np.minimum.reduce(cuts) if consensus else cuts[-1]).reshape(height_out, width_out)
        result[(scheme, knots, penalty, threshold, consensus)] = mask, {
            "forecast": scores, "passed": bool(passed), "mask_mean": float(mask.mean()), "mask_max": float(mask.max()),
        }
    return result
