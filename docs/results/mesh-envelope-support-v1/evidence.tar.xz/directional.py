"""Keep the front correction belonging to the same placement as the delivered median."""

import numpy as np

from replay import ROOT
from split_fit import correction
from deliver import shift_prior
from run import SHIFTS,window
from stabilize import median_correction
from transport import ordered_like, translate


def reconstruct(field, packed, variance, colors, query, roi, noise, config, phase):
    arrays, fronts, history = [], [], []
    if config is None:
        empty = np.zeros_like(window(field, roi))
        return empty, empty, history
    for dx,dy in SHIFTS:
        f, g = shift_prior(*config,dx,dy)
        box = query[0]+dx, query[1]+dy, *query[2:]
        override = None
        if phase:
            moved = tuple(translate(c,dx,dy) for c in phase)

            def override(local):
                return local[0],ordered_like(moved,local)[1]

        combined, state = correction(field,packed,variance,colors,box,roi,f,g,noise,
                                     packed_offset=dx//2,replace_pair=override)
        arrays.append(combined)
        fronts.append(state.pop("front_delta") if "front_delta" in state else np.zeros_like(combined))
        history.append(state)
    median = median_correction(arrays)
    if not median.any():
        return median, np.zeros_like(median), history
    combined = np.stack(arrays)
    choices = np.argpartition(combined, len(arrays)//2, axis=0)[len(arrays)//2]
    idx = choices[None]
    np.testing.assert_array_equal(np.take_along_axis(combined,idx,axis=0)[0], median)
    front = np.take_along_axis(np.stack(fronts),idx,axis=0)[0]
    # A zero in the delivered correction remains a zero after attenuation.
    rear = np.where(median != 0, median.astype(float)-front, 0)
    return median, rear, history
