"""Check shifted median parity and independent sensor predictions."""

import os
import sys

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

from replay import ROOT, PREVIOUS
sys.path.insert(1,str(PREVIOUS))
from directional import reconstruct
from deliver import CENTRE,DISPLAY,Carrier,geometry,window
from mesh import ribbon
from transport import ordered_like
from envelope_nuisance import observation,partition,prepare,solve
from qualified import KNOTS,field_cut,forecast


def objective(data, training, hold, cut):
    scores=[]
    for region in (1,np.subtract(1,cut)):
        rows=[]
        design=np.column_stack((data.nuisance,data.wave*region))
        for c in range(3):
            train=training & (data.colors==c)
            test=hold & (data.colors==c)
            sensor=data.raw[train]
            amp=np.linalg.lstsq(design[train],sensor,rcond=None)[0]
            variance=data.shot*max(1e-4,float(np.median(sensor)))+data.read
            residual=data.raw[test]-design[test]@amp
            rows.append(float(residual@residual)/variance)
        scores.append(sum(rows))
    return scores[0]-scores[1]


def run():
    spec=read_json(PREVIOUS/"fresh-plan.json")
    probes=[]
    for label in ("iso6400-continuous-g153","iso6400-disk-g154","iso400-band-g151"):
        case=read_json(PREVIOUS/"fresh"/(label+".json"))
        noise=spec["noise"][case["entry"]["profile"]]
        kin=case["details"]["matching"]
        with np.load(checked(case["array"]),allow_pickle=False)as f:
            p,c,v,field,saved=(f[k][1]for k in ("packed","colors","variance","parent","matching/transported"))
        trace=kin["donor_trace"]
        cfg=geometry.fit_geometry(*geometry.donor_arrays(trace,(383.5,383.5))[:3])[:2]
        transported=tuple(Carrier(**e["carrier"])for e in kin["transport"]["carriers"])
        moved=transported if kin["roles"][1]["transport_changes"] else None
        base,rear,_=reconstruct(field,p,v,c,CENTRE,DISPLAY,noise,cfg,moved)
        np.testing.assert_array_equal(base,saved)
        assert not np.any(rear[base==0])
        raw=window(p,CENTRE,phase=2)
        chosen,_=geometry.reserve_candidates(raw,c,*cfg,noise)
        if moved:
            chosen=chosen[0],ordered_like(moved,chosen)[1]
        x,y=native_sites(raw.shape[-2:],(-127.5,-127.5))
        first,second=(ribbon(x,y,w)for w in chosen)
        data=observation(raw,c,first,second,noise,KNOTS,flexible=True)
        errors=[]
        for scheme in ("columns","distributed"):
            groups=partition(raw.shape,scheme)
            a,b,d=(groups==i for i in (1,2,3))
            np.testing.assert_array_equal(groups==0,np.broadcast_to(np.indices(raw.shape[-2:])[1]%4==0,raw.shape).ravel())
            assert all((groups==i).sum()==raw.size//4 or scheme=="distributed" for i in range(4))
            for tr,te in ((a,b),(b,a),(a|b,d)):
                assert not np.any(tr&te) and not np.any((tr|te)&(groups==0))
                coeff,_=solve(prepare(data,tr,te),1.2)
                shape=field_cut(data.spline,data.spline[::39],coeff,"firm")
                calculated=forecast(data,tr,te,shape)["gain"]
                replica=objective(data,tr,te,shape)
                difference=abs(calculated-replica)
                assert difference<2e-8,(label,difference)
                errors.append(difference)
        probes.append({"id":label,"median_bit_exact":True,"independent_forecast_delta_max":max(errors),
                       "profiles_compared":len(errors)})
        print(probes[-1],flush=True)
    write_json(ROOT/"verification.json",{"driver":reference(__file__),"prior_panel":reference(PREVIOUS/"fresh.json"),
                                         "cases":probes,"scope":"Six independent direct least-squares forecasts per case compare whitened held-out energy differences against the optimized score. All three recreated median arrays match the previous output bit for bit."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
