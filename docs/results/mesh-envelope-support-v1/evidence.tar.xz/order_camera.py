"""Check whether the two recovered directions switch strength order across placements."""

import os

import numpy as np
from demosaic._mesh_frequency import ADJACENT_SEARCH, adjacent_prior, infer_prior, query_phases
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_refinement import TRANSLATIONS

from camera import ROOT, PRIOR, window


def run():
    proof=read_json(PRIOR/"port.json")
    items={v["id"]:v for v in proof["cases"]}
    archive=read_json(ROOT.parent/"local-mesh-phase-evidence-v1"/"camera.json")
    results=[]
    for row in archive["views"]:
        old=items[row["id"]]
        with np.load(checked(old["native_array"]),allow_pickle=False)as f:
            active=bool(old["adjacent_RMS_DN16"] or np.any(f["adjacent"]!=f["default"]))
        if not active and all(word not in row["id"]for word in ("chain-link-fence","fine-green-mesh-left")):
            continue
        with np.load(checked(row["input"]),allow_pickle=False)as f:
            cfa=f["colors"][0]
            scene=f["packed"][0]
        box=row["query"]
        adj="fine-green-mesh-right"in row["id"]
        pairs=(adjacent_prior(scene,cfa,box,row["noise"])if adj
               else infer_prior(scene,cfa,box,row["noise"],span=old["noise"]["donor_span"]))
        opts={"search":ADJACENT_SEARCH}if adj else {}
        measured=[]
        for dx,dy in TRANSLATIONS:
            query=(box[0]+dx,box[1]+dy,*box[2:])
            local=window(scene,query,phase=2)
            car,_,z=query_phases(local,cfa,pairs,row["noise"],packed_offset=dx//2,**opts)
            f=np.array([v.frequency for v in car])
            measured.append((f/np.linalg.norm(f,axis=1)[:,None],z))
        first=measured[0][0]
        reverse=[]
        for i,(f,z)in enumerate(measured):
            sim=np.abs(first@f.T)
            if sim.trace()<np.fliplr(sim).trace():
                reverse.append({"placement":TRANSLATIONS[i],"reserve_scores":z})
        result={"id":row["id"],"orientation_order_flips":reverse,"total_placements":len(measured)}
        results.append(result)
        print(result,flush=True)
    write_json(ROOT/"camera-order.json",{"camera":reference(ROOT/"camera.json"),"driver":reference(__file__),
                                         "results":results,"scope":"Checks physical identification by the sign-invariant dot products of the two central directions and each individual placement. Includes all placements regardless of amplitude admission."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
