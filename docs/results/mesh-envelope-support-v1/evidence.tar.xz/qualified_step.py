"""Audit the actual attenuation mask nominated by a spatial RAW fit."""

import math
from itertools import product

import numpy as np
from demosaic.isolated_line import coordinates

from envelope_nuisance import basis, observation, partition, prepare, solve

KNOTS = (-72, -36, 0, 36, 72)


def column(x, y, angle, offset, width):
    return np.tanh((np.cos(angle) * x + np.sin(angle) * y - offset) / width)


def select_step(data):
    x, y, colors, slots, wave, nuisance, raw, noise = data
    reserve = slots == 0
    positions = x[reserve], y[reserve]
    basis = np.column_stack((nuisance, wave))[reserve]
    groups = []
    for color in range(3):
        take = colors[reserve] == color
        q, _ = np.linalg.qr(basis[take], mode="reduced")
        values = raw[reserve][take]
        residual = values - q @ (q.T @ values)
        variance = noise["shot"] * max(1e-4, np.median(values)) + noise["read"]
        groups.append((take, q, residual, variance))

    def best(search):
        choice = None
        for start in range(0, len(search), 24):
            options = search[start:start + 24]
            predictors = np.column_stack([column(*positions, *candidate) for candidate in options])
            gains = np.zeros(len(options))
            for take, q, residual, variance in groups:
                design = predictors[take]
                design -= q @ (q.T @ design)
                gains += (residual @ design)**2 / (
                    np.maximum(np.sum(design**2, axis=0), 1e-12) * variance)
            idx = int(gains.argmax())
            if choice is None or gains[idx] > choice[0]:
                choice = float(gains[idx]), tuple(map(float, options[idx]))
        return choice

    rough = list(product(np.arange(12) * np.pi / 12, range(-72, 73, 24), (2.5, 8)))
    strength, shape = best(rough)
    if strength < 48:
        return data, {"screen_gain": strength}
    angle, offset, _ = shape
    refined = list(product(
        angle + np.deg2rad([-6, -3, 0, 3, 6]),
        offset + np.arange(-12, 13, 3), (2.5, 5, 8),
    ))
    refined_strength, refined_shape = best(refined)
    if refined_strength > strength:
        strength, shape = refined_strength, refined_shape
    new_basis = np.column_stack((nuisance, column(x, y, *shape)))
    return (*data[:5], new_basis, *data[6:]), {"screen_gain": strength, "shape": shape}


def forecast(data, train, test, cut):
    nuisance = data.nuisance
    whole_wave = data.wave
    supported_wave = whole_wave * (1 - cut)
    overlap = power = 0.0
    for color in range(3):
        a, b = train & (data.colors == color), test & (data.colors == color)
        segment = data.raw[a]
        variance = data.shot * max(1e-4, float(np.median(segment))) + data.read
        whole = np.column_stack((nuisance, whole_wave))
        finite = np.column_stack((nuisance, supported_wave))
        fits = [x[b] @ np.linalg.solve(x[a].T @ x[a], x[a].T @ segment) for x in (whole, finite)]
        change = fits[1] - fits[0]
        overlap += float((data.raw[b] - fits[0]) @ change) / variance
        power += float(change @ change) / variance
    gain = 2 * overlap - power
    return {"z": gain / (2 * math.sqrt(max(power, 1e-12))), "gain": gain, "change_power": power}


def field_cut(b, ref, coeff, profile):
    peak = max(.4, float(np.quantile(1 + ref @ coeff, .8)))
    relative = (1 + b @ coeff) / peak
    if profile == "soft":
        return np.clip(.90 - relative, 0, 1)
    return np.clip((.78 - relative) / .50, 0, 1)


def audit_masks(raw, colors, front, rear, noise, query, roi, specs):
    data = observation(raw, colors, front, rear, noise, KNOTS, flexible=True)
    x, y = data.positions
    assignment = partition(raw.shape, "columns")
    adjusted, step = select_step((x, y, data.colors, assignment, data.wave, data.nuisance, data.raw, noise))
    data.nuisance = adjusted[5]
    nx, ny = coordinates(256, 256, origin=(-127.5, -127.5))
    lo_x, lo_y = roi[0] - query[0], roi[1] - query[1]
    w, h = roi[2:]
    y, x = np.s_[lo_y:lo_y+h, lo_x:lo_x+w]
    display = basis(nx[y,x], ny[y,x], KNOTS)
    reference = basis(nx[::5,::5], ny[::5,::5], KNOTS)
    cache = {}
    result = {}
    for sampling, profile, threshold, agreement in specs:
        if sampling not in cache:
            slot = partition(raw.shape, sampling)
            a,b,d = [slot == k for k in (1,2,3)]
            folds = ((a,b),(b,a),(a | b,d))
            models = [solve(prepare(data, t, v), 1.2) for t,v in folds]
            cache[sampling] = folds, models
        folds, models = cache[sampling]
        crops = [field_cut(display, reference, coeff, profile) for coeff, _ in models]
        cuts = [field_cut(data.spline, reference, coeff, profile) for coeff, _ in models]
        if agreement:
            cuts[2] = np.minimum.reduce(cuts)
            crops[2] = np.minimum.reduce(crops)
        scores = [forecast(data, t, v, cut) for (t,v),cut in zip(folds,cuts,strict=True)]
        passed = min(x["z"] for x in scores[:2]) > 0.75 and scores[2]["z"] > threshold
        crop = crops[2].reshape(h,w) if passed else np.zeros((h,w))
        result[(sampling, profile, threshold, agreement)] = crop, {
            "step": step, "forecast": scores, "spatial_forecast": [m for _, m in models], "passed": bool(passed),
            "mask_max": float(crop.max()), "mask_mean": float(crop.mean()),
        }
    return result
