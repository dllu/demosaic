"""Independent projected-mesh panel with matching and shifted exterior phases."""

import dataclasses
import math
import numpy as np
import torch
from demosaic.cfa import PATTERNS, mosaic
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise, variance_map
from mesh import ribbon
from run import prior

def smooth(t):
    s=np.clip(t,0,1)
    return s*s*(3-2*s)


def observe(index,layout,noise,seed):
    guides=prior.guides(index)
    cfa=tuple(PATTERNS)[index%4]
    x,y=coordinates(320,320,origin=(-159.5,-159.5))
    first,second=(ribbon(x,y,k)for k in guides)
    base=np.array([.24,.28,.35])[:,None,None]+.015*x/320-.021*y/320
    base=base+.0036*np.sin(.017*x-.029*y)+.0022*np.cos(.026*x+.019*y)
    i=index-160
    angle=math.radians((8,39,71,112,136,163)[i]); normal=(math.cos(angle),math.sin(angle))
    offset=(15,-23,31,-23,27,-22)[i]
    radius=(22,31,26,27,21,30)[i]
    dx=(27,-22,19,-28,24,-18)[i];dy=(-22,18,-28,21,29,-18)[i]
    extent=np.ones_like(x)
    if layout=='band':
        extent=smooth((abs(normal[0]*x+normal[1]*y-offset)-radius)/14)
    if layout=='disk':
        extent=smooth((np.hypot(x-dx,y-dy)-(radius+8))/14)
    strong=.039*prior.STRONG*first
    if layout!='continuous':
        beta=angle+(.61 if i%2 else -.63)
        across=math.cos(beta)*x+math.sin(beta)*y+(-17 if i%2 else 19)
        jump=.5+.5*np.tanh(across/2.3)
        strong=strong+np.array([.017,.024,.010])[:,None,None]*jump
    clean=base+strong
    amplitude=(.0040,.0052,.0060,.0078,.0096,.0089)[i]
    detailed=clean+amplitude*prior.FAINT*(1-first)*second*extent
    p,q,flat=(torch.from_numpy(v.astype(np.float32))for v in (clean,detailed,base))
    raw,meta=paired_observation(p[None],q[None],noise,[cfa],torch.ones(1,3),torch.eye(3)[None],seed)
    batch={k:torch.from_numpy(raw[k])for k in ('target','packed','variance','colors','wb','matrix')}
    colors=batch['colors'][0]
    quiet=add_noise(mosaic(flat[None],colors),noise['shot'],noise['read'],black_level=.03,
                    generator=torch.Generator().manual_seed(seed+1225))
    parts={'target':flat[None],'packed':quiet,'variance':variance_map(quiet,noise['shot'],noise['read']),
           **{k:batch[k][:1]for k in ('wb','matrix','colors')}}
    batch={k:torch.cat((v,parts[k]))for k,v in batch.items()}
    xx,yy=coordinates(768,768,origin=(-383.5,-383.5))
    context=np.array([.255,.285,.343])[:,None,None]+.015*xx/768-.02*yy/768
    patch=np.zeros_like(xx)
    for cx,cy in ((-230,55),(233,(i%3-1)*38),((i%3-1)*61,223)):
        w=smooth((113-np.maximum(abs(xx-cx),abs(yy-cy)))/21)
        patch=np.maximum(patch,w)
    theta=.45
    rotate=np.array([[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]])
    off_axis=[dataclasses.replace(c,frequency=tuple(rotate@c.frequency))for c in guides]
    exterior={}
    shifted = [dataclasses.replace(c, offset=(c.offset + d) % 1)
               for c, d in zip(guides, (.31, .37), strict=True)]
    for tag,geom in (('matching',guides),('phase-shifted',shifted),('unrelated',off_axis)):
        dr,ds=(ribbon(xx,yy,c)for c in geom)
        a=context+patch*(.10*prior.STRONG*dr+.066*prior.FAINT*ds)
        mosaic_raw=mosaic(torch.from_numpy(a.astype(np.float32))[None],colors)
        exterior[tag]=add_noise(mosaic_raw,noise['shot'],noise['read'],black_level=.03,
            generator=torch.Generator().manual_seed(seed+1709))[0].numpy()
    return batch,exterior,{'strong_phase':first,'weak_phase':second,'support':extent},meta,{
        'case_geometry':[vars(q)for q in guides],'cut_normal':normal,'cut_radius':radius,'cut_offset':offset,
        'disk_center':[dx,dy],'amplitude':amplitude,'CFA':cfa,
    }

