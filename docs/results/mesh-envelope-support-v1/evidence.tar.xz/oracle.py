"""Measure the remaining support evidence with an externally supplied gap shape."""

import os
import time
from pathlib import Path

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

from deliver import CENTRE,Carrier,window
from mesh import ribbon
from envelope_nuisance import observation,partition
from qualified import KNOTS,forecast

ROOT=Path(__file__).resolve().parent


def sampled(rgb,colors):
    return np.stack([rgb[int(c),i//2::2,i%2::2]for i,c in enumerate(colors)])


def execute():
    plan=read_json(ROOT/"fresh-plan.json")
    records=[]
    begin=time.monotonic()
    for entry in plan["cases"]:
        if entry["kind"]!="gaps":
            continue
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-begin>1800:
                raise TimeoutError(path)
            time.sleep(2)
        case=read_json(path)
        prior=plan["noise"][entry["profile"]]
        with np.load(checked(case["array"]),allow_pickle=False)as f:
            local=window(f["packed"][1],CENTRE,phase=2)
            flags=f["colors"][1]
            clean=window(f["target"][0],CENTRE)
            present=window(f["support"],CENTRE)
        role=case["details"]["matching"]["roles"][1]
        exact=tuple(Carrier(**v)for v in case["identity"]["case_geometry"])
        measured=tuple(Carrier(**v)for v in role["central_pair"])if "central_pair"in role else None
        mask=sampled(np.broadcast_to(1-present,clean.shape),flags).ravel()
        nx,ny=native_sites(local.shape[-2:],(-127.5,-127.5))
        background=sampled(clean,flags)
        raw_control=local-background+np.median(background,axis=(-1,-2))[:,None,None]
        variants={}
        for name,raw,pair in (
            ("measured",local,measured),("geometry",local,exact),("geometry-and-background",raw_control,exact)):
            if pair is None:
                continue
            p,q=(ribbon(nx,ny,g)for g in pair)
            data=observation(raw,flags,p,q,prior,KNOTS,flexible=True)
            for sampling in ("columns","distributed"):
                folds=partition(local.shape,sampling)
                a,b,d=[folds==i for i in (1,2,3)]
                metrics=[forecast(data,u,v,mask)for u,v in ((a,b),(b,a),(a|b,d))]
                variants[name+"/"+sampling]={
                    "z":[v["z"]for v in metrics],
                    "pass":min(v["z"]for v in metrics[:2])>.75 and metrics[-1]["z"]>1.5,
                    "energy": [v["change_power"]for v in metrics],
                }
        records.append({"id":case["id"],"entry":entry,"case":reference(path),
                        "broad_active":bool(measured is not None),"fixed_mask_tests":variants})
        print(entry["id"],[(k,[round(z,2)for z in v["z"]],v["pass"])for k,v in variants.items()],flush=True)
    assert len(records)==12
    write_json(ROOT/"oracle.json",{"driver":reference(__file__),"plan":reference(ROOT/"fresh-plan.json"),
                                    "cases":records,"scope":"The mask is taken from the exact support. Additional oracle arms fix the carrier parameters and subtract clean no-rear RGB at measured Bayer sites. These arms diagnose limitations and produce no image."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    execute()
