"""Publish source-bound measurements and native photos actually viewed."""

from datetime import UTC,datetime
import hashlib
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
repo=ROOT.parents[2]
images=repo/"docs/images/mesh-envelope-support-v1"
results=repo/"docs/results/mesh-envelope-support-v1"
images.mkdir()
results.mkdir()


def portable(path):
    return {"path":path.relative_to(repo).as_posix(),"sha256":reference(path)["sha256"]}


def photo(item, panels, prefix=""):
    src=checked(item)
    out=images/(prefix+src.name)
    shutil.copyfile(src,out)
    with Image.open(out)as image:
        for row in panels:
            x,y,w,h=row["png_xywh"]
            assert (w,h)==(160,160)and x+w<=image.width and y+h<=image.height
    key=portable(out)
    assert key["sha256"]==item["sha256"]
    return key


notes={
    "main-overcast-sky-main-overcast-sky":"All mask results keep the uniform gray sky.",
    "main-building-detail-main-building-detail":"Matched pixels preserve the previous soft thin braces and lines.",
    "main-foliage-main-foliage":"The same soft foliage edges and dark regions persist in all variants.",
    "main-chain-link-fence-main-chain-link-fence":"Slightly less contrast in parts of the coarse lattice. The main crossings remain legible.",
    "mesh-nominal-fine-green-mesh-left":"The smooth masks fade part of the faint lattice. Fitting the step leaves the left reference output exact.",
    "mesh-profile3879-fine-green-mesh-left":"The faint posts and diagonal structure remain slightly softer with distributed smoothing. The column step fit keeps the prior pixels.",
    "mesh-nominal-fine-green-mesh-right":"Both directions remain visible. Whole-mask versions reduce contrast in parts of the lattice. The rear-only version retains more of the adjacent-donor appearance.",
    "mesh-profile3879-fine-green-mesh-right":"The diagonals persist with a small drop in local contrast. The horizontal wire and uneven background remain present.",
    "iso400-band-g163":"Smooth support fades the narrow added secondary repeats through much of the strip while the strong near-horizontal wires remain. Some weak crossings outside the gap soften.",
    "iso400-band-g165":"The smooth mask substantially reduces the added crossing texture in the strip. The stronger diagonal remains visible.",
    "iso400-step-g161":"Smooth support fades parts of the continuous faint direction near the step. The distributed step replay restores the earlier crossings there.",
    "iso6400-disk-g162":"Audited smooth variants keep the incorrect wide continuation. Short support largely removes it and also fades outside the gap.",
    "iso6400-band-g161":"The distributed smooth mode reduces a small amount of texture near the known gap. The weak crossing response remains quite low.",
}
camera=read_json(ROOT/"camera.json")
added=read_json(ROOT/"camera-step.json")
synthesis=read_json(ROOT/"summary.json")
step_views={r["id"]:r for r in added["views"]}
camera_views=[]
for row in camera["views"]:
    name=row["id"]
    alt=step_views[name]
    for key in ("source","parent","RAW","prior_view","camera_delta"):
        checked(row[key])
        if key!="camera_delta":
            assert alt[key]==row[key]
    with np.load(checked(row["camera_delta"]),allow_pickle=False)as a:
        with np.load(checked(alt["camera_delta"]),allow_pickle=False)as b:
            np.testing.assert_array_equal(a["before"],b["before"])
    entry={k:row[k]for k in ("id","source","parent","RAW","query","ROI","noise","exposure","changes_DN16","panels")}
    entry["image"]=photo(row["image"],row["panels"])
    entry["step_changes_DN16"]=alt["changes_DN16"]
    if name.startswith("mesh-"):
        entry["step_image"]=photo(alt["image"],alt["panels"],"step-")
        entry["step_panels"]=alt["panels"]
    else:
        checked(alt["image"])
        entry["step_viewed_archive"]=alt["image"]
    entry["observation"]=notes[name]
    camera_views.append(entry)
assert len(camera_views)==8
synthetic=[]
both=synthesis["two_example_triplets"]
for row in synthesis["rendered"]:
    entry={k:v for k,v in row.items()if k not in ("board","triplet")}
    for k in ("case","arrays","checkpoint","step_replay"):
        checked(row[k])
    choices=("board","triplet")if row["id"]in both else ("board",)
    for k in choices:
        entry[k]={"panels":row[k]["panels"],"image":photo(row[k]["image"],row[k]["panels"])}
    entry["observation"]=notes[row["id"]]
    synthetic.append(entry)
assert len(synthetic)==5 and sum("triplet"in item for item in synthetic)==2
view=results/"viewing.json"
write_json(view,{"recorded_utc":datetime.now(UTC).isoformat(),"actual_native_viewing":True,
                 "scope":"All eight open native camera boards for both smooth and step policies, five native synthetic comparison boards and the two published triplets were actually viewed.",
                 "camera_checkpoint":camera["checkpoint"],"camera":camera_views,"synthetic":synthetic})
for copied in ("summary.json","step-followup.json","oracle.json","color-probe.json","verification.json"):
    shutil.copyfile(ROOT/copied,results/copied)
files={p.name:p for p in ROOT.iterdir()if p.is_file()and p.suffix in (".json",".py",".log")}
files.update({p.relative_to(ROOT).as_posix():p for p in (ROOT/"fresh").glob("*.json")})
bundle=results/"evidence.tar.xz"
with tarfile.open(bundle,"x:xz",preset=4)as archive:
    for k,p in files.items():
        archive.add(p,arcname=k)
contents={k:reference(p)for k,p in files.items()}
with tarfile.open(bundle,"r:xz")as archive:
    assert set(archive.getnames())==set(files)
    for k,b in contents.items():
        assert hashlib.sha256(archive.extractfile(k).read()).hexdigest()==b["sha256"]
prior=("donor-phase-transport-v1","local-mesh-distributed-audit-v1","local-mesh-gap-support-v1")
write_json(results/"publication.json",{"scope":"Scoped RAW attenuation studies on fixed parents. No training and no comparable primary panel scores.",
                                       "actual_viewing":portable(view),"source_archive":portable(bundle),
                                       "archive_contents":contents,"metrics":portable(results/"summary.json"),
                                       "replays":[portable(results/p)for p in ("step-followup.json","oracle.json","color-probe.json","verification.json")],
                                       "prior_source_archives":[portable(repo/"docs/results"/p/"evidence.tar.xz")for p in prior]})
