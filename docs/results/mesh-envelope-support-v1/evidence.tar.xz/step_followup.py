"""Replay a shared step nuisance after observing a false continuous-wire cut."""

import os
from pathlib import Path
import time

import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.isolated_line import native_sites

from deliver import CENTRE,DISPLAY,Carrier,score,window
from mesh import ribbon
from qualified_step import audit_masks

ROOT=Path(__file__).resolve().parent
POLICIES={"columns":("columns","firm",1.5,False),"distributed":("distributed","firm",1.5,False)}


def run():
    plan=read_json(ROOT/"fresh-plan.json")
    records=[]
    dest=ROOT/"step-followup";dest.mkdir()
    begin=time.monotonic()
    for entry in plan["cases"]:
        path=ROOT/"fresh"/(entry["id"]+".json")
        while not path.exists():
            if time.monotonic()-begin>1800:
                raise TimeoutError(path)
            time.sleep(2)
        case=read_json(path)
        prior=plan["noise"][entry["profile"]]
        kin=case["details"]["matching"]["roles"]
        with np.load(checked(case["array"]),allow_pickle=False)as f:
            parent,clean,packed,colors,broad=(f[k]for k in("parent","target","packed","colors","matching/wide"))
            masks={k:f[k]for k in ("strong_phase","weak_phase","support")}
        corrections={k:broad.copy()for k in POLICIES}
        checks=[]
        for i,role in enumerate(kin):
            if "central_pair"not in role:
                continue
            local=window(packed[i],CENTRE,phase=2)
            points=native_sites(local.shape[-2:],(-127.5,-127.5))
            p,q=(ribbon(*points,Carrier(**args))for args in role["central_pair"])
            localized=audit_masks(local,colors[i],p,q,prior,CENTRE,DISPLAY,POLICIES.values())
            entry_checks={}
            for k,spec in POLICIES.items():
                field,entry_checks[k]=localized[spec]
                corrections[k][i]=(broad[i]*(1-field[None])).astype(broad.dtype)
            checks.append({"role":i,"checks":entry_checks})
        measured={k:score(parent,q,clean,masks)for k,q in corrections.items()}
        f=dest/(entry["id"]+".npz");np.savez_compressed(f,**corrections)
        records.append({"id":case["id"],"entry":entry,"case":reference(path),"observed":measured,
                        "previous_spline":{k:case["metrics"]["matching/spline-"+k]for k in POLICIES},
                        "wide":case["metrics"]["matching/wide"],"arrays":reference(f),"checks":checks})
        print(case["id"],[(k,round(v["response"][0]*100,2),round(v["gap_added_RMS_DN16"]or 0,2))
                          for k,v in measured.items()],flush=True)
    write_json(ROOT/"step-followup.json",{"driver":reference(__file__),"fresh_plan":reference(ROOT/"fresh-plan.json"),
                                          "code":reference(ROOT/"qualified_step.py"),"results":records,
                                          "scope":"Fresh observations replayed after inspecting step false cuts. A step selected from the reserved Bayer columns is used in both constant and variable rear-profile forecasts. Reuses the frozen delivered correction."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
