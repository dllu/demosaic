"""Recompute every reported score and produce matched native exact-target boards."""

import os
from pathlib import Path
from statistics import mean

import numpy as np
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from report_scene_wave_guides import native_board
from deliver import DISPLAY,score

ROOT=Path(__file__).resolve().parent


def summary(data):
    return {
        "n":len(data),
        "recovery_pct":100*mean(v["response"][0]for v in data),
        "wire_RMS_DN16":mean(v["increment_RMS_DN16"][0]for v in data),
        "gap_added_RMS_DN16":None if data[0]["gap_added_RMS_DN16"]is None else mean(v["gap_added_RMS_DN16"]for v in data),
        "gap_error_RMS_DN16":None if data[0]["gap_error_RMS_DN16"]is None else mean(v["gap_error_RMS_DN16"]for v in data),
        "edits_from_wide_by_role":[sum(v["changed_from_wide"][i]for v in data)for i in range(3)],
        "edits_from_parent_by_role":[sum(v["changed"][i]for v in data)for i in range(3)],
    }


def run():
    source=read_json(ROOT/"fresh.json")
    plan=read_json(checked(source["plan"]))
    step_followup=read_json(ROOT/"step-followup.json")
    steps={v["id"]:v for v in step_followup["results"]}
    cases={}
    for ref in source["cases"]:
        case=read_json(checked(ref)); key=case["id"]
        cases[key]=(case,ref)
    lower = [(k,row["metrics"]) for k,(row,_) in cases.items() if row["entry"]["profile"]=="iso400"
             and row["entry"]["kind"]=="gaps"]
    improved=sorted(lower,key=lambda t:t[1]["matching/wide"]["gap_error_RMS_DN16"]-
                    t[1]["matching/spline-columns"]["gap_error_RMS_DN16"],reverse=True)
    chosen = {k: "spline-columns" for k, _ in improved[:2]}
    for k in chosen:
        stats=cases[k][0]["metrics"]
        assert stats["matching/spline-columns"]["gap_error_RMS_DN16"]<stats["matching/wide"]["gap_error_RMS_DN16"]
    example_cases=chosen|{"iso6400-disk-g162":"spline-columns","iso400-step-g161":"step-distributed",
                           "iso6400-band-g161":"spline-distributed"}
    rows=[]; images=[]
    dest=ROOT/"native";dest.mkdir(exist_ok=True)
    for k,(case,ref) in cases.items():
        archive=read_json(checked(steps[k]["case"]))
        assert archive==case
        with np.load(checked(case["array"]),allow_pickle=False)as a:
            arrays=dict(a)
        with np.load(checked(steps[k]["arrays"]),allow_pickle=False)as b:
            stepped=dict(b)
        parent,target=arrays["parent"],arrays["target"]
        masks={k:arrays[k]for k in ("strong_phase","weak_phase","support")}
        results={}
        for key,prediction in case["metrics"].items():
            delta=None if key=="parent"else arrays[key]
            value=score(parent,delta,target,masks)
            assert value==prediction,(key,case["id"])
            base=arrays["matching/wide"]if key=="parent"else arrays[key.split("/")[0]+"/wide"]
            value["changed_from_wide"]=[bool(np.any(a!=b))for a,b in zip(delta if delta is not None else np.zeros_like(base),base,strict=True)]
            results[key]=value
        for key,delta in stepped.items():
            value=score(parent,delta,target,masks)
            assert value==steps[k]["observed"][key]
            value["changed_from_wide"]=[bool(np.any(a!=b))for a,b in zip(delta,arrays["matching/wide"],strict=True)]
            results["matching/step-"+key]=value
        rows.append({"id":k,"entry":case["entry"],"measurements":results,"case":ref})
        if k not in example_cases:
            continue
        x,y,w,h=DISPLAY
        role=1

        def restored(name):
            delta=stepped[name[5:]] if name.startswith("step-") else arrays["matching/"+name]
            result=parent[role].copy()
            result[:,y:y+h,x:x+w]+=delta[role]
            return result

        policies=("wide","column","short","spline-columns","spline-distributed","spline-rear","step-distributed")
        shots=[noisy_malvar(arrays)[role],parent[role]]+[restored(name)for name in policies]+[target[role]]
        tags=("Noisy Malvar","Local trunk","Wide support","Column gap","Short support","Smooth support",
              "Distributed smooth","Rear only","Smooth with step","Exact GT")
        meta={"case":ref,"arrays":case["array"],"checkpoint":plan["checkpoint"],"CFA":case["identity"]["CFA"],
              "noise":plan["noise"][case["entry"]["profile"]],"seed":case["entry"]["seed"],
              "step_replay":steps[k]["arrays"],"triplet_policy":example_cases[k]}
        indices=(0,2+policies.index(example_cases[k]),len(tags)-1)
        board=native_board(dest,k,shots,{name:arrays[name][role:role+1]for name in ("wb","matrix")},
                           meta,labels=tags,triplet_indices=indices,roi=DISPLAY,exposure=1,contrast=8)
        images.append(board)
    aggregated={}
    for profile in ("iso400","iso6400"):
        for kind in ("continuous","gaps"):
            subset=[r for r in rows if r["entry"]["profile"]==profile and r["entry"]["kind"]==kind]
            assert len(subset)==6
            modes={m for v in subset for m in v["measurements"]}
            totals={}
            for mode in sorted(modes):
                records=[v["measurements"][mode]for v in subset if mode in v["measurements"]]
                totals[mode]=summary(records)
                if mode.startswith("matching"):
                    print(profile,kind,mode,totals[mode])
            aggregated[profile+"/"+kind]=totals
    assert len(rows)==24 and len(images)==5
    write_json(ROOT/"summary.json",{"driver":reference(__file__),"primary":reference(ROOT/"fresh.json"),
                                     "after_viewing_step":reference(ROOT/"step-followup.json"),"rows":rows,
                                     "aggregated":aggregated,"rendered":images,"two_example_triplets":list(chosen),
                                     "bit_exact_score_reconstruction":True})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
