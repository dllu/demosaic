"""Locate smooth-envelope false cuts under phase and background controls."""

import os
from dataclasses import replace

import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from deliver import CENTRE, DISPLAY, Carrier, score, window
from mesh import ribbon
from demosaic.isolated_line import native_sites

from replay import ROOT, PREVIOUS
from envelope_nuisance import fit_masks

PRESET = ("columns", (-72, -36, 0, 36, 72), 1.2, 1.0, True)


def geometry_nuisance(x, y, pair, front):
    u,v = x / 128, y / 128
    polynomial = np.column_stack([t.ravel() for t in (np.ones_like(u),u,v,u*u,u*v,v*v)])
    features = []
    for i, wave in enumerate(pair):
        left = ribbon(x,y,replace(wave,offset=wave.offset-.015))
        middle = ribbon(x,y,wave)
        right = ribbon(x,y,replace(wave,offset=wave.offset+.015))
        support = (1-front) if i else 1
        gradient = (right-left)/(2*.015)*support
        bending = (right+left-2*middle)/(.015**2)*support
        features.extend((gradient.ravel()[:,None]*polynomial, bending.ravel()[:,None]*polynomial))
    return features


def run():
    source = read_json(PREVIOUS / "attenuation.json")
    plan = read_json(checked(source["plan"]))
    records = []
    for item in source["rows"]:
        if not item["fixed_pair_evidence"]:
            continue
        case = read_json(checked(item["case"]))
        entry = case["entry"]
        noise = plan["noise"][entry["profile"]]
        role = item["fixed_pair_evidence"][0]["role"]
        measured = tuple(Carrier(**v) for v in item["fixed_pair_evidence"][0]["pair"])
        true = tuple(Carrier(**v) for v in case["geometry"]["case_geometry"])
        with np.load(checked(case["array"]), allow_pickle=False) as f:
            packed, colors, parent, target, delta = (
                f[k] for k in ("packed", "colors", "parent", "target", "matching/transported"))
            regions = {k:f[k] for k in ("strong_phase", "weak_phase", "support")}
        raw = window(packed[role], CENTRE, phase=2)
        x, y = native_sites(raw.shape[-2:], (-127.5,-127.5))
        p, q = (ribbon(x,y,g) for g in measured)
        p0,q0 = (ribbon(x,y,g) for g in true)
        background = window(target[0], CENTRE)
        bayer = np.stack([background[int(c), i//2::2, i%2::2] for i,c in enumerate(colors[role])])
        # The exact-background arms remove the clean no-rear role. They
        # never enter the RAW-only next test.
        no_background = raw-bayer+np.median(bayer,axis=(1,2))[:,None,None]
        flex = geometry_nuisance(x,y,measured,p)
        fits = {}
        for k, used, front, rear, extra, flexible in (
            ("measured",raw,p,q,(),False),
            ("exact-geometry",raw,p0,q0,(),False),
            ("exact-background",no_background,p,q,(),False),
            ("exact-both",no_background,p0,q0,(),False),
            ("smooth-background",raw,p,q,(),True),
            ("phase-jets",raw,p,q,flex,False),
            ("smooth-and-phase",raw,p,q,flex,True),
        ):
            mask, witness = fit_masks(used, colors[role], front,rear,noise,CENTRE,DISPLAY,
                                      [PRESET],extra=extra,flexible=flexible)[PRESET]
            result = delta.copy()
            result[role] = result[role]*(1-mask[None])
            fits[k] = {"check":witness, "metrics":score(parent,result,target,regions)}
        records.append({"id":case["id"],"entry":entry,"fits":fits,"case":item["case"]})
        print(case["id"],[(k,round(v["check"]["forecast"][-1]["z"],2),
                           round(v["check"]["mask_mean"],3)) for k,v in fits.items()],flush=True)
    write_json(ROOT/"nuisance.json",{"rows":records,"driver":reference(__file__),
                                    "code":reference(ROOT/"envelope_nuisance.py"),
                                    "scope":"Retrospective development. Exact-geometry and exact-background arms are target-assisted diagnostics. All other compared nuisances share the same fit and audit sites."})


if __name__=="__main__":
    os.sched_setaffinity(0,[12,13]); os.nice(12)
    run()
