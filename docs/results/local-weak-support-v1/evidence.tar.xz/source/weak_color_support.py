"""Use reciprocal Bayer evidence to taper only the new weak correction."""

from itertools import product
from pathlib import Path
import sys

import numpy as np
from scipy.special import expit

from demosaic._mesh_pooled import _STRIDE, _footprint, _rgb, _wave, _windows
from demosaic._mesh_presence import (
    _CENTER_BACKGROUND, _CENTER_PIXELS, _CORE, _PACKED_CORE, _RING, _SMOOTH,
    _evidence, _ring_prior,
)
from demosaic.mesh_carrier_fit import _WINDOW, _cosine_background, _positions

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("local-conditional-posterior-v1")))
import conditional as base
import local_rank
import color_witness

GREEN = ("center", "flat", "spatial")
METHODS = (*GREEN, "color")
CUTS = (-0.75, -0.25, 0.25)
FOLDS = ("minimum", "average")
OPTIONS = tuple((m, f, c, f"{m}_{f}_{c:+g}") for m, f, c in product(GREEN, FOLDS, CUTS)) + tuple(
    ("color", "paired", c, f"color_paired_{c:+g}") for c in CUTS
)
ARMS = ("combined", "weak", *(x[-1] for x in OPTIONS))
WEIGHTS = np.clip((np.arange(32) - 7.5)/16, 0, 1)
BILINEAR = np.stack([
    np.outer(y, x)
    for y, x in product((1-WEIGHTS, WEIGHTS), (1-WEIGHTS, WEIGHTS))
])


def cross_score(terms, source, coeff, shot, read):
    """Evaluate a fixed candidate with nuisance prediction from the fitting lattice."""
    _, fit, _, inverse, design = terms[source]
    _, held, held_bg, _, held_design = terms[1-source]
    projection = inverse @ design
    difference = held - (fit @ inverse.T) @ held_bg.T
    model = coeff @ (held_design - held_bg @ projection).T
    noise_a = np.maximum(2e-11, shot * np.maximum(0, fit.mean(axis=1)) + read)
    # The mean is estimated on the fitting lattice and predicts both variances.
    transfer = (model @ held_bg) @ inverse
    uncertainty = np.sqrt(
        noise_a * (np.sum(model**2, axis=1) + np.sum(transfer**2, axis=1))
    )
    gain = np.sum((difference - model / 2) * model, axis=1)
    return gain / np.maximum(1e-10, uncertainty)


def station_scores(center, positions, weak, strong, coefficients, shot, read):
    nuisance = _cosine_background(16)
    columns = []
    for dy, dx in product((0, 16), repeat=2):
        region = np.s_[dy:dy+16, dx:dx+16]
        packed = np.s_[:, dy//2:dy//2+8, dx//2:dx//2+8]
        bg = np.concatenate((nuisance, strong[region]), axis=-1)
        terms = base.carrier_terms(
            weak[region], bg, tuple(a[packed] for a in center), positions, np.ones((16,16), dtype=bool),
        )
        columns.append(np.stack([cross_score(terms, f, c, shot, read) for f, c in enumerate(coefficients)]))
    return np.stack(columns, axis=-1)


def ramp(z, center):
    return np.clip(1 + z - center, 0, 1)


def qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, rank_override=None):
    x, y = local[:2]
    baseline = base.replay.nested_apply(
        parent, local, scene, colors, roi, frequency, noise | {"wb": wb, "matrix": matrix},
    )[0]["nested"]
    options = {key: baseline for key in ARMS}
    if frequency is None:
        return options, {"weak": None}
    shot, read = noise["shot"], noise["read"]
    direction, rank = (
        local_rank.rank(scene, colors, roi, frequency, shot, read) if rank_override is None else rank_override
    )
    if direction is None:
        return options, {"weak": None, "rank": rank}

    _, former = base.combined(
        parent[:, y-16:y+176, x-16:x+176], scene, colors, roi, frequency, shot, read,
    )
    old = former[:, direction]
    positions = _positions(colors, *roi[:2])
    observed = tuple(_windows(_footprint(scene, roi[:2], p), _WINDOW//2, _STRIDE//2) for p in positions)
    wave = _wave(_WINDOW, frequency).reshape(_WINDOW, _WINDOW, 4)
    mean, dev = _ring_prior(*_evidence(observed, positions, wave, _SMOOTH, _RING, shot, read))
    center = tuple(o[:, _PACKED_CORE, _PACKED_CORE] for o in observed)
    shape = wave[_CORE].reshape(32,32,2,2)
    weak = shape[..., direction, :]
    strong = shape[..., 1-direction, :]
    background = np.concatenate((_CENTER_BACKGROUND, strong), axis=-1)
    terms = base.carrier_terms(weak, background, center, positions, _CENTER_PIXELS)
    gram, moment = base.condition(terms, shot, read)
    joined_gram, joined_moment = sum(gram), sum(moment)
    m = mean.reshape(-1,2,2)[:, direction]
    precision = base.prior_shape(m, dev[:, direction], "free")
    beta, evidence = base.conditional_posterior(joined_gram, joined_moment, m, precision)
    p = expit(evidence - 5)
    one = np.maximum(0, (p - 0.20)/0.80)
    selected = one > 0
    if not selected.any():
        return options, {"weak": direction, "rank": rank, "selected": []}
    central = np.linalg.solve(joined_gram, joined_moment[..., None])[..., 0]
    cap = np.linalg.norm(central, axis=1)
    design = np.concatenate((background, weak), axis=-1).reshape(32**2, -1)
    inherited = _windows(parent[1,y:y+160,x:x+160], 32, _STRIDE).reshape(-1,32**2)
    existing = inherited @ np.linalg.pinv(design, rcond=1e-8)[-2:].T
    delta = (beta - existing) * one[:, None]
    delta *= np.minimum(1, one * cap / np.linalg.norm(delta, axis=1).clip(min=1e-15))[:, None]
    change = np.einsum("yxf,nf->nyx", weak, np.where(selected[:, None], delta-old, 0))
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral /= neutral[1]
    options["weak"] = baseline + _rgb(change, neutral, baseline.dtype)

    coeff = tuple(base.conditional_posterior(h, g, m, precision)[0] for h,g in zip(gram,moment,strict=True))
    center_evidence = np.stack([cross_score(terms, f, v, shot, read) for f,v in enumerate(coeff)])
    corner_evidence = station_scores(center, positions, weak, strong, coeff, shot, read)
    reducers = {"minimum": np.min, "average": np.mean}
    color_evidence, supported_color = color_witness.predict(
        scene, colors, roi, wave, weak, background, direction, m, beta, shot, read,
    )
    for mode, name, cut, key in OPTIONS:
        if mode == "color":
            scale = np.where(supported_color, ramp(color_evidence,cut), 1)[:,None,None]
            options[key] = baseline + _rgb(change * scale, neutral, baseline.dtype)
            continue
        f = reducers[name]
        if mode == "center":
            scale = ramp(f(center_evidence, axis=0), cut)[:,None,None]
        else:
            corners = ramp(f(corner_evidence, axis=0), cut)
            scale = corners.mean(axis=-1)[:,None,None] if mode == "flat" else np.einsum("nc,cyx->nyx",corners,BILINEAR)
        options[key] = baseline + _rgb(change * scale, neutral, baseline.dtype)
    return options, {
        "weak": direction, "rank": rank, "selected": np.flatnonzero(selected).tolist(),
        "selected_probability": p[selected].tolist(),
        "whole_center_evidence": center_evidence[:,selected].tolist(),
        "station_evidence": corner_evidence[:,selected].tolist(),
        "color_available": supported_color[selected].tolist(),
        "color_evidence": color_evidence[selected].tolist(),
    }
