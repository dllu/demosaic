"""Publish byte-verified inputs, native boards and analysis for the scope study."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from weak_support import HERE, OUT

ROOT = Path.cwd()
ASSETS = ROOT / 'docs/assets' / HERE.name
RESULTS = ROOT / 'docs/results' / HERE.name
RECEIPTS = (
    'calibration.json', 'color-calibration.json', 'exterior-calibration.json',
    'retained.json', 'recent.json', 'new.json', 'color-recent.json', 'color-new.json',
    'exterior-recent.json', 'exterior-new.json', 'oracle-new.json',
    'evidence-audit.json', 'donor-audit.json', 'fresh/plan.json', 'fresh/inputs.json',
    'fresh/parent/result.json', 'native-camera.json', 'board-camera.json',
    'board-exact.json', 'board-outlier.json', 'summary.json', 'chart.json',
)
PRIOR = ('local-conditional-posterior-v1', 'local-bayer-presence-v1', 'local-exterior-phase-transfer-v1')


def published(path):
    return reference(path) | {'path': str(path.relative_to(ROOT))}


def copy_image(binding):
    source = checked(binding)
    target = ASSETS / source.name
    shutil.copyfile(source, target)
    result = published(target)
    assert result['sha256'] == binding['sha256']
    return result


def copy_board(data):
    binding = copy_image(data['image'])
    with Image.open(ROOT / binding['path']) as im:
        for panel in data['panels']:
            x, y, w, h = panel['png_xywh']
            assert (w, h) == (160, 160)
            assert 0 <= x < x + w <= im.width and 0 <= y < y + h <= im.height
    return data | {'image': binding}


def main():
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    records = {key: reference(OUT / key) for key in RECEIPTS}
    data = {key: read_json(checked(value)) for key, value in records.items()}
    for r in data.values():
        for key in ('driver', 'model', 'operator'):
            if key in r:
                checked(r[key])
    for name in ('board-camera.json', 'board-exact.json', 'board-outlier.json'):
        assert data[name]['calibration'] == records['exterior-calibration.json']
    assert data['board-exact.json']['data']['receipt'] == records['exterior-new.json']
    assert data['board-outlier.json']['data']['receipt'] == records['exterior-recent.json']
    assert data['chart.json']['source'] == records['summary.json']
    assert data['exterior-new.json']['plan'] == records['fresh/plan.json']
    assert data['exterior-new.json']['source'] == records['fresh/parent/result.json']
    assert data['fresh/parent/result.json']['inputs'] == records['fresh/inputs.json']
    assert data['fresh/inputs.json']['plan'] == records['fresh/plan.json']
    for record in data['fresh/parent/result.json']['records']:
        for stream in record['streams']:
            checked(stream['data'])
            for output in stream['outputs'].values():
                checked(output)

    evidence = {f'receipts/{name}': binding for name, binding in records.items()}
    evidence.update({f'source/{file.name}': reference(file) for file in sorted(HERE.glob('*.py'))})
    archive = RESULTS / 'evidence.tar.xz'
    with tarfile.open(archive, 'x:xz') as tar:
        for key, value in evidence.items():
            tar.add(checked(value), arcname=key, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == evidence.keys()
        for key, value in evidence.items():
            with tar.extractfile(key) as blob:
                assert hashlib.file_digest(blob, 'sha256').hexdigest() == value['sha256'], key

    synthetic = {}
    for group in ('exact', 'outlier'):
        synthetic[group] = [r | {'board': copy_board(r['board']), 'triplet': copy_board(r['triplet'])}
                            for r in data[f'board-{group}.json']['data']['boards']]
    camera = [r | {'native': [copy_board(b) for b in r['native']]}
              for r in data['board-camera.json']['data']['rows']]
    chart = copy_image(data['chart.json']['image'])
    native = ASSETS / 'manifest.json'
    write_json(native, {'synthetic': synthetic, 'camera': camera, 'chart': chart})
    summary = RESULTS / 'summary.json'
    shutil.copyfile(checked(records['summary.json']), summary)
    assert published(summary)['sha256'] == records['summary.json']['sha256']
    write_json(RESULTS / 'publication.json', {
        'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'summary': published(summary), 'archive': published(archive), 'native_manifest': published(native),
        'previous_publications': [published(ROOT / 'docs/results' / name / 'publication.json') for name in PRIOR],
        'original_receipts': records, 'archive_members': evidence,
        'synthetic_native_triplets_viewed': sum(map(len, synthetic.values())),
        'standing_native_boards_viewed': sum(len(r['native']) for r in camera),
        'new_weights': None,
    })


if __name__ == '__main__':
    main()
