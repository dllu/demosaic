"""Audit center and color checks under held-lattice interventions."""

from pathlib import Path
import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
from demosaic._mesh_pooled import _footprint, _wave, _windows
from demosaic.mesh_carrier_fit import _positions
import weak_support as w
import color_witness


def check():
    rng = np.random.default_rng(202611200418)
    frequency = np.array([[0.107, 0.061], [0.092, -0.083]])
    wave = _wave(64, frequency).reshape(64,64,4)
    middle = wave[w._CORE]
    weak, strong = middle[...,2:], middle[...,:2]
    background = np.concatenate((w._CENTER_BACKGROUND, strong),axis=-1)
    roi = (176,176,160,160)
    sample = 40
    fingerprint = []
    for name, colors in PATTERNS.items():
        g = _positions(colors, *roi[:2])
        trace = [0,1]
        center = [rng.normal(0.1,0.011,(2,16,16)) for k in trace]
        design = w.base.carrier_terms(weak, background, center, g, w._CENTER_PIXELS)
        grams, moments = w.base.condition(design, .00128, 6.5536e-6)
        for f in trace:
            altered = [v.copy() for v in center]
            altered[1-f] += rng.normal(0,0.03,altered[1-f].shape)
            next_design = w.base.carrier_terms(weak,background,altered,g,w._CENTER_PIXELS)
            n,h = w.base.condition(next_design,.00128,6.5536e-6)
            np.testing.assert_array_equal(n[f],grams[f])
            np.testing.assert_array_equal(h[f],moments[f])
            prior = np.zeros((2,2))
            precision = np.broadcast_to(np.eye(2)*1e6,(2,2,2))
            z, _ = w.base.conditional_posterior(grams[f],moments[f],prior,precision)
            first = w.cross_score(design,f,z,.00128,6.5536e-6)
            after = w.cross_score(next_design,f,z,.00128,6.5536e-6)
            assert np.any(first != after)
        y,x = np.indices((512,512))
        linear = (
            0.13 + .009*np.cos(2*np.pi*(frequency[0,0]*x+frequency[0,1]*y)+.2)
            + .008*np.cos(2*np.pi*(frequency[1,0]*x+frequency[1,1]*y)+.4)
        )
        scene = np.stack([linear[r::2,c::2] for r,c in np.ndindex(2,2)])
        sample_wb = np.array([[0.005,0.005]]*81)
        template = np.array([[0.003,0.002]]*81)
        old, eligible = color_witness.predict(scene,colors,roi,wave,weak,background,1,sample_wb,template,.00128,6.5536e-6)
        change = scene.copy()
        for k,c in enumerate(colors):
            if c != 1:
                yy,xx = roi[1]//2 + 32, roi[0]//2 +32
                change[k,yy:yy+16,xx:xx+16] += rng.normal(0,0.03,(16,16))
        for site in g:
            np.testing.assert_array_equal(_footprint(change,roi[:2],site),_footprint(scene,roi[:2],site))
        new, still = color_witness.predict(change,colors,roi,wave,weak,background,1,sample_wb,template,.00128,6.5536e-6)
        assert eligible[sample] and still[sample] and old[sample] != new[sample]
        fingerprint.append({"CFA":name, "green_folds":2, "held_color_score_changed":True})
    return fingerprint


if __name__ == "__main__":
    write_json(w.OUT/"evidence-audit.json",{
        "driver":reference(Path(__file__)), "operator":reference(w.__file__),
        "color_operator":reference(color_witness.__file__), "layouts":check(),
    })
