"""Render native crops for the matched weak-support comparison."""

from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from weak_exterior_support import OUT, qualify
from conditional import replay
import review_presence as view

NAMES = {
    "parent": "Local 50k", "nested": "Combined check", "weak": "Weak posterior",
    "uniform": "Reduced weak", "center": "Center evidence",
    "flat": "Station mean", "ring_phase": "Spatial support",
    "color": "Local color check", "exterior": "Donor color check",
}
BOARD_EXACT = ("weak-support-01", "weak-support-09")
OUTLIER = ("weak-side-07",)


def arcs(parent, local, scene, colors, roi, peaks, noise, wb, matrix, policy):
    frequencies = None if peaks is None else np.asarray(peaks)
    values, flags = qualify(parent, local, scene, colors, roi, frequencies, noise, wb, matrix, clearance=16 if local == roi else 48)
    old = view.section(parent, *local)
    base = values["combined"]
    listed = {"parent": old, "nested": base, "weak": values["weak"]}
    for key, info in [("uniform", policy["control"]), *policy["selected"].items()]:
        new = values[info["name"]]
        delta = new.astype("d") - base
        display_key = "ring_phase" if key == "spatial" else key
        listed[display_key] = (base.astype("d") + info["weight"] * delta).astype(base.dtype)
    return listed, flags


def exact(policy, destination, *, outlier=False):
    binding = reference(OUT / ("exterior-recent.json" if outlier else "exterior-new.json"))
    ensemble = read_json(checked(binding))
    plan = read_json(checked(ensemble["plan"]))
    x, y, w, h = plan["query"]
    roi = (x + replay.ROI[0], y + replay.ROI[1], *replay.ROI[2:])
    boards = []
    cases = OUTLIER if outlier else BOARD_EXACT
    for row in ensemble["rows"]:
        if row["id"] not in cases:
            continue
        draw = row["draws"][0]
        f = replay.arrays(draw["input"])
        p = np.load(checked(draw["outputs"]["local50k"]))[0]
        v120 = np.load(checked(draw["outputs"]["v120"]))[0]
        scene = f["scene_packed"].copy()
        scene[:, y//2:(y+h)//2, x//2:(x+w)//2] = f["packed"][0]
        colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
        observed = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        observed["packed"] = f["packed"][:1]
        variants, detail = arcs(p, replay.ROI, scene, colors, roi, draw["actual_frequency"], plan["noise"], wb, matrix, policy)
        outputs = [noisy_malvar(observed)[0], v120]
        for crop in variants.values():
            frame = p.copy()
            view.section(frame, *replay.ROI)[:] = crop
            outputs.append(frame)
        outputs.append(f["target"][0])
        labels = ["Noisy Malvar", "V120 EMA", *(NAMES[k] for k in variants), "Exact GT"]
        arm = "Donor color check" if "Donor color check" in labels else "Spatial support"
        boards.append(view.native_board(
            destination, row["id"], outputs, observed,
            {"input": draw["input"], "fixture": row["fixture"], "query": plan["query"],
             "noise": plan["noise"], "optical_sigma": plan["sigma"], "weights": plan["checkpoints"],
             "draw": 0, "diagnostics": detail},
            labels=labels, triplet_indices=(0, labels.index(arm), len(labels)-1),
        ))
    assert len(boards) == len(cases)
    return {"receipt": binding, "boards": boards}


def main():
    torch.set_num_threads(2)
    start = monotonic()
    calibration = reference(OUT / "exterior-calibration.json")
    policy = read_json(checked(calibration))["policy"]
    kind = sys.argv[1]
    destination = OUT / "boards" / kind
    destination.mkdir(parents=True, exist_ok=True)
    view.arcs = arcs
    view.NAMES = NAMES
    data = view.standing(policy, destination) if kind == "camera" else exact(policy, destination, outlier=kind=="outlier")
    write_json(OUT / f"board-{kind}.json", {
        "driver": reference(Path(__file__)), "calibration": calibration, "data": data,
        "seconds": monotonic()-start,
    })


if __name__ == "__main__":
    main()
