"""Verify that replacing the whole recipient leaves donor color ratios fixed."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from exterior_witness import ratios
from weak_support import OUT
from conditional import replay


def main():
    bound = reference(OUT / "exterior-new.json")
    data = read_json(checked(bound))
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    roi = (x+48,y+48,160,160)
    tested = {}
    rng = np.random.default_rng(202611200417)
    for row in data["rows"]:
        pattern = row["fixture"]["camera"]["pattern"]
        if pattern in tested:
            continue
        raw = replay.arrays(row["draws"][0]["input"])
        first = raw["scene_packed"].copy()
        color = raw["colors"]
        peak = _spacing(first,color,*roi[:2],clearance=48)
        if peak is None:
            continue
        before = ratios(first,color,roi,peak,1,48)
        if not before:
            continue
        other = first.copy()
        area = other[:,y//2:(y+h)//2,x//2:(x+w)//2]
        area[:] = rng.uniform(0.02,0.35,area.shape)
        np.testing.assert_array_equal(peak,_spacing(other,color,*roi[:2],clearance=48))
        after = ratios(other,color,roi,peak,1,48)
        assert before == after
        tested[pattern] = {
            "input":row["draws"][0]["input"],
            "query_changes":int(np.count_nonzero(other != first)),
            "external_ratios":[(c,float(q.real),float(q.imag)) for c,q in before.items()],
        }
    assert len(tested)==4
    write_json(OUT/"donor-audit.json",{
        "driver":reference(Path(__file__)), "source":bound, "layouts":tested,
    })


if __name__ == "__main__":
    main()
