"""Check the green candidate on its held-out sensor colors."""

import numpy as np

from demosaic._mesh_pooled import _STRIDE, _footprint, _variance, _windows
from demosaic._mesh_presence import _CENTER_PIXELS, _CORE, _PACKED_CORE, _RING, _SMOOTH, _evidence
from demosaic.mesh_carrier_fit import _WINDOW


def predict(scene, colors, roi, wave, weak, background, direction, green_ring, candidate, shot, read):
    x, y = roi[:2]
    variance_weight = []
    improvements = []
    available = []
    for r,c in np.ndindex(2,2):
        color = colors[2*((y+r)%2)+(x+c)%2]
        if color == 1:
            continue
        p = (r,c)
        plane = _footprint(scene, roi[:2], p)
        obs = _windows(plane, _WINDOW//2, _STRIDE//2)
        raw_ring = obs[:, _RING[r::2,c::2]]
        g, q = _evidence((obs,), (p,), wave, _SMOOTH, _RING, shot, read)
        fit = np.linalg.solve(g, q[..., None])[..., 0]
        span = slice(2*direction,2*direction+2)
        champion = fit[:, span]
        power = np.einsum("ni,nij,nj->n", champion, g[:, span, span], champion)
        green_complex = green_ring[:,0] + 1j * green_ring[:,1]
        color_complex = champion[:,0] + 1j * champion[:,1]
        transfer = color_complex * np.conj(green_complex) / (abs(green_complex)**2 + 0.0005**2)
        transfer *= np.minimum(1, 2/abs(transfer).clip(min=1e-12))
        use = (power > 9) & (abs(green_complex) > 0.0005)
        weak_phase = transfer * (candidate[:,0] + 1j*candidate[:,1])
        coefficients = np.stack((weak_phase.real,weak_phase.imag), axis=1)
        observed = obs[:,_PACKED_CORE,_PACKED_CORE].reshape(len(obs),-1)
        design = background[r::2,c::2].reshape(observed.shape[1],-1)
        shape = weak[r::2,c::2].reshape(observed.shape[1],2)
        residual = shape - design @ (np.linalg.pinv(design,rcond=1e-8) @ shape)
        # Residualized templates make fitting the common linear nuisance
        # equivalent under both candidate and null.
        values = coefficients @ residual.T
        predicted_power = np.sum(values**2, axis=1)
        predictor_variance = _variance(raw_ring,shot,read)
        improvements.append(use * np.sum((observed - values/2) * values, axis=1) / predictor_variance)
        variance_weight.append(use * predicted_power / predictor_variance)
        available.append(use)
    power = np.sum(variance_weight,axis=0)
    score = np.sum(improvements,axis=0)/np.sqrt(power.clip(min=1e-10))
    return score, np.any(available,axis=0)
