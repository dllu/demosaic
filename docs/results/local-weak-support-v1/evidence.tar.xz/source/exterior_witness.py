"""Transfer a color phase ratio from the existing disjoint RAW donors."""

import numpy as np

from demosaic._mesh_pooled import _wave, _footprint, _windows, _variance
from demosaic._mesh_presence import _PACKED_CORE, _RING
from demosaic.mesh_carrier_fit import _DONOR, _ROI_SIZE, _WINDOW, _sites


def ratios(scene, colors, roi, frequencies, direction, clearance):
    x, y = roi[:2]
    boxes = (
        (x - _DONOR - clearance, y + 16),
        (x + _ROI_SIZE + clearance, y + 16),
        (x + 16, y - _DONOR - clearance),
        (x + 16, y + _ROI_SIZE + clearance),
    )
    y0, x0 = np.indices((_DONOR,_DONOR))/_DONOR - .5
    nuisance = np.stack((np.ones_like(x0),x0,y0,x0*x0,x0*y0,y0*y0),axis=-1)
    wave = _wave(_DONOR,frequencies)
    fitted = []
    for x,y in boxes:
        phases = [[], [], []]
        for r,c in np.ndindex(2,2):
            p = 2*((r+y)%2)+(c+x)%2
            raw = _sites(scene,x,y,_DONOR,r,c)
            b = nuisance[r::2,c::2].reshape(-1,6)
            v = wave[r::2,c::2].reshape(-1,4)
            residual = v - b @ (np.linalg.pinv(b,rcond=1e-8) @ v)
            fit = np.linalg.lstsq(residual, raw.ravel(), rcond=1e-8)[0].reshape(2,2)
            q = fit[direction]
            phases[colors[p]].append(q[0]+1j*q[1])
        fitted.append([np.mean(a) for a in phases])
    stack = np.array(fitted)
    green = stack[:,1]
    estimates = {}
    for color in (0,2):
        match = np.conj(green)*stack[:,color]
        power = np.sum(abs(green)**2)
        coherence = abs(match.sum())/max(1e-12,abs(match).sum())
        transfer = match.sum()/max(1e-12,power)
        if coherence>=0.80 and np.sqrt(power/4)>0.001 and 0.15<=abs(transfer)<=2.0:
            estimates[color] = transfer
    return estimates


def predict(scene, colors, roi, frequencies, direction, weak, background, candidate, shot, read, clearance):
    relative = ratios(scene, colors, roi, frequencies, direction, clearance)
    if not relative:
        return np.zeros(len(candidate)), np.zeros(len(candidate),dtype=bool)
    x,y = roi[:2]
    improvements, powers = [],[]
    for r,c in np.ndindex(2,2):
        color = colors[2*((y+r)%2)+(x+c)%2]
        if color not in relative:
            continue
        plane = _footprint(scene,roi[:2],(r,c))
        windows = _windows(plane,_WINDOW//2,16//2)
        s = windows[:,_PACKED_CORE,_PACKED_CORE].reshape(len(windows),-1)
        b = background[r::2,c::2].reshape(s.shape[1],-1)
        w = weak[r::2,c::2].reshape(s.shape[1],-1)
        w = w - b @ (np.linalg.pinv(b,rcond=1e-8) @ w)
        z = relative[color]*(candidate[:,0]+1j*candidate[:,1])
        template = np.stack((z.real,z.imag),axis=1) @ w.T
        variance = _variance(windows[:,_RING[r::2,c::2]],shot,read)
        improvements.append(np.sum((s-template/2)*template,axis=1)/variance)
        powers.append(np.sum(template**2,axis=1)/variance)
    score = np.sum(improvements,axis=0)/np.sqrt(np.sum(powers,axis=0).clip(min=1e-10))
    return score,np.ones(len(candidate),dtype=bool)
