"""Plot actual gap edits against recovered weak contrast."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from weak_support import OUT
from reduce_support import ADDED, RESPONSE

COLORS = {'combined': '#49515b', 'uniform': '#24518b', 'weak': '#24518b', 'center': '#bb5a27',
          'flat': '#439191', 'spatial': '#237146', 'color': '#9a5a80', 'exterior': '#d29526',
          'known_support': '#352870'}
MARKERS = {'combined': 's', 'uniform': 'h', 'weak': 'o', 'center': 'D', 'flat': '^',
           'spatial': 'v', 'color': 'P', 'exterior': 'X', 'known_support': '*'}
LABELS = {'combined': 'Combined check', 'uniform': 'Uniform 75%', 'weak': 'Weak posterior',
          'center': 'Center green', 'flat': 'Station mean', 'spatial': 'Spatial green',
          'color': 'Local color', 'exterior': 'Donor color', 'known_support': 'Known support'}


def main():
    summary = reference(OUT / 'summary.json')
    panels = read_json(checked(summary))['panels']
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.9), layout='constrained')
    for ax, panel, title in zip(axes, ('calibration', 'fresh'), ('32 calibration photos', '24 new photos'), strict=True):
        scores = panels[panel]['means'].copy()
        if panel == 'fresh':
            scores['known_support'] = panels['target_assisted']['means']['known_support']
        x = [scores[arm][RESPONSE] for arm in ('combined', 'weak')]
        y = [scores[arm][ADDED] for arm in ('combined', 'weak')]
        if panel == 'calibration':
            # The policies were locked at one response. Jitter the coincident symbols for display.
            offsets = dict(zip(('uniform', 'center', 'flat', 'spatial', 'color', 'exterior'),
                               (-.065, -.035, -.015, .015, .035, .065), strict=True))
            ax.axvline(scores['uniform'][RESPONSE], color='#9c9c9c', linestyle=':', linewidth=1, zorder=0)
        else:
            offsets = {}
        ax.plot(x, y, color='#8aa6c5', linewidth=1.5, zorder=1)
        for key, metric in scores.items():
            ax.scatter(metric[RESPONSE] + offsets.get(key, 0), metric[ADDED], label=LABELS[key],
                       color=COLORS[key], marker=MARKERS[key], s=60 if key != 'known_support' else 105,
                       zorder=3, linewidth=.55, edgecolor='white')
        ax.set_title(title, loc='left', fontweight='bold')
        ax.set_xlabel('Recovered weak contrast (% of sharp target)')
        ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        ax.grid(axis='y', alpha=.18)
        ax.set_axisbelow(True)
        ax.spines[['top', 'right']].set_visible(False)
        ax.set_ylim(bottom=-.003 if panel == 'calibration' else -.016)
    axes[0].set_ylabel('Added luma RMS in true gaps (DN16)')
    handles, labels = axes[1].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncols=5, frameon=False, fontsize=8)
    file = OUT / 'recovery-vs-gap.png'
    fig.savefig(file, dpi=160, facecolor='white')
    write_json(OUT / 'chart.json', {'driver': reference(Path(__file__)), 'source': summary,
                                   'image': reference(file), 'calibration_display_jitter_maximum_points': .065})


if __name__ == '__main__':
    main()
