"""Verify shifted grids, selection/confirmation and clean carrier coverage."""

import numpy as np
from staggered_phase import ROOT, SHIFTS, exchange_gain, phase_basis, staggered_grid
from score_staggered import BAND, OUT, PRIOR
from render_wide import CAMERA_PEAKS

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def condition_and_projection():
    details = {}
    offsets = np.arange(BAND.size) - (BAND.size - 1) / 2
    yy, xx = np.meshgrid(offsets, offsets, indexing="ij")
    shape = BAND.size, BAND.size
    affine = 0.15 + 0.003 * xx - 0.0025 * yy
    for name, pattern in PATTERNS.items():
        items = []
        for shift in SHIFTS:
            result = staggered_grid(tuple(pattern), BAND, shift)
            b = result.basis
            design = b.image.reshape(len(b.image), -1)
            np.testing.assert_allclose(design @ design.T, np.eye(len(design)), rtol=0, atol=1e-14)
            theta = np.array([0.312, -0.227])
            pair = 2 * (len(result.frequency) // 2)
            field = (theta @ design[pair : pair + 2]).reshape(shape)
            frames = np.stack([(field + affine)[g // 2 :: 2, g % 2 :: 2].ravel() for g in b.green])
            predictions = np.einsum("gkp,gp->gk", b.projection, frames)
            expected = np.zeros(len(design))
            expected[pair : pair + 2] = theta
            np.testing.assert_allclose(
                predictions, np.broadcast_to(expected, predictions.shape), atol=1e-13, rtol=0
            )
            items.append(
                {
                    "shift_yx_in_bins": shift,
                    "pairs": len(design) // 2,
                    "condition": result.condition,
                    "max_affine_fit_error": float(np.max(np.abs(predictions - expected))),
                }
            )
        details[name] = items
    return details


def check_held_split():
    weights = np.full((1, 32), 1 / 32)
    products = np.empty((1, 32, 2))
    products[:, ::2] = [12, 3]
    products[:, 1::2] = [0, 50]
    broad, chosen = exchange_gain(products, weights, np.ones(2), [np.array([0, 1])])
    # Even rows nominate pair zero, which has zero held power. Odd rows
    # nominate pair one, which the even rows independently confirm.
    expected = 0.5 * (3 - 0.5) / (1 + 3 - 0.5)
    assert broad[0, 0] == chosen[0, 0] == 0
    np.testing.assert_allclose(chosen[0, 1], expected, atol=1e-14)
    assert broad[0, 1] > chosen[0, 1]
    p, w = products[:, ::-1], weights[:, ::-1]
    np.testing.assert_allclose(
        exchange_gain(p, w, np.ones(2), [np.array([0, 1])])[1], chosen, atol=1e-14, rtol=0
    )
    return {"individually_confirmed": broad.tolist(), "chosen_and_confirmed": chosen.tolist()}


def best_pairs(records):
    colors = tuple(PATTERNS["RGGB"])
    canonical, _ = phase_basis(colors, BAND)
    candidates = [
        canonical.image,
        *(staggered_grid(colors, BAND, shift).basis.image for shift in SHIFTS[1:]),
    ]
    images = [p.reshape(len(p), -1) for p in candidates]
    axis = np.arange(BAND.size) - (BAND.size - 1) / 2
    yy, xx = np.meshgrid(axis, axis, indexing="ij")
    rows = []
    for fx, fy in records:
        theta = 2 * np.pi * (fx * xx + fy * yy)
        exact, _ = np.linalg.qr(np.column_stack((np.cos(theta).ravel(), np.sin(theta).ravel())))
        p = [((basis @ exact) ** 2).reshape(-1, 2, 2).sum(axis=(1, 2)) / 2 for basis in images]
        rows.append(
            {
                "frequency_xy": [fx, fy],
                "integer_best": float(p[0].max()),
                "best_any_shift": float(max(m.max() for m in p)),
                "integer_total": float(p[0].sum()),
                "per_grid_totals": [float(m.sum()) for m in p],
            }
        )
    return rows


def main():
    fresh = reference(OUT / "plan.json")
    old = reference("/mnt/external/demosaic/scene-query-consensus-v1/fresh/plan.json")
    read = {name: read_json(checked(item)) for name, item in {"prior": old, "fresh": fresh}.items()}
    rows = {
        key: best_pairs([p["geometry"]["frequency"][1] for p in data["sources"]])
        for key, data in read.items()
    }
    rows["cab"] = best_pairs(CAMERA_PEAKS)
    summary = {
        k: {
            name: float(np.median([z[name] for z in p]))
            for name in ("integer_best", "best_any_shift")
        }
        for k, p in rows.items()
    }
    write_json(
        ROOT / "math-audit.json",
        {
            "driver": reference(__file__),
            "fresh_plan": fresh,
            "prior_plan": old,
            "grids": condition_and_projection(),
            "split": check_held_split(),
            "coverage": rows,
            "median": summary,
        },
    )
    print(summary, flush=True)


if __name__ == "__main__":
    main()
