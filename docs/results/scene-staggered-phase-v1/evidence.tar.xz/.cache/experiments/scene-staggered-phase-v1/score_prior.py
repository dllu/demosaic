"""Re-score locked controls on the original off-grid panel."""

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_staggered import (
    PRIOR, ROOT, WireFundamental, fields, measurements, offgrid_summary, replay, run, values
)


def verify(case, gains, expected):
    data, base, _ = replay.read_inputs(case)
    deltas, _ = fields(case, data, base, 4800, cosine=True)
    with np.load(checked(case["input"]), allow_pickle=False) as source:
        truth = {key: source[key] for key in ("target", "support")}
    metric = WireFundamental(data | truth, case["fixture"]["geometry"])
    direct = {
        method: metric(base.astype(np.float64) + gains[method] * deltas[method])
        for method in ("dense", "radial")
    }
    return max(
        abs(score - expected[method][name])
        for method, scores in direct.items() for name, score in scores.items()
    )


def main():
    input_ref = reference(PRIOR / "fresh-score.json")
    original = read_json(checked(input_ref))
    calibration = reference(ROOT / "calibration.json")
    lock = read_json(checked(calibration))
    gains = {key: val["gain"] for key, val in lock["strengths"]["4800"].items()}
    rows, score_time = run(
        original["rows"], lambda row: measurements(row["case"], budgets=(4800,), cosine=True)
    )
    direct, direct_time = run(
        original["rows"], lambda row: verify(row["case"], gains, row["scores"])
    )
    assert len(rows) == 24
    assert sum(row["width"]["4800"]["gap_pixels"] > 0 for row in rows) == 16
    assert max(direct) <= 1e-10, max(direct)
    roundoff = 0
    for row, old in zip(rows, original["rows"], strict=True):
        assert row["case"]["id"] == old["case"]["id"]
        for method in ("dense", "radial"):
            for name, score in old["scores"][method].items():
                estimated = values([row["width"]["4800"]], method, name, gains[method])[0]
                roundoff = max(roundoff, abs(estimated - score))
    assert roundoff <= 1e-4, roundoff
    write_json(ROOT / "offgrid-prior.json", {
        "driver": reference(__file__),
        "calibration": calibration,
        "input": input_ref,
        "gains": gains,
        "rows": rows,
        "summary": offgrid_summary(rows, gains),
        "seconds": {"score": score_time, "direct": direct_time},
        "prior_direct_parity_max": max(direct),
        "polynomial_roundoff_max": roundoff,
    })


if __name__ == "__main__":
    main()
