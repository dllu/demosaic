"""Render the standing GFX scenes and paired exact targets at native resolution."""

import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_staggered import PRIOR, ROOT, fields, replay, values
from atlas_probe import pixels, render
from render_wide import native_board, native_png, peak_fit

LABELS = {
    "dense": "Dense cosine prior",
    "radial": "Earlier radial",
    "pruned_integer": "Pruned integer",
    "staggered_mean": "Four-grid mean",
    "staggered_selected": "Four-grid selected",
}
CONTINUING = "gap_continuing_strong_RMS_DN16"
FALSE = "fundamental_false_RMS_DN16"


def camera(calibration, gains):
    binding = reference(ROOT / "camera-fields.json")
    before = reference(PRIOR / "native/standing-extended/result.json")
    originals = {r["id"]: r for r in read_json(checked(before))["rows"]}
    dest = ROOT / "native/standing"
    dest.mkdir(parents=True, exist_ok=True)
    result = []
    for item in read_json(checked(binding))["rows"]:
        row = item["case"]
        with np.load(checked(row["paths"]), allow_pickle=False) as old:
            parent, raw, wb, matrix, colors = (old[k] for k in ("parent", "raw", "wb", "matrix", "colors"))
            updates = {k: old[k] for k in ("dense", "radial")}
        with np.load(checked(item["alternatives"]), allow_pickle=False) as new:
            updates.update({k: new[k] for k in new.files})
        estimates = {k: parent + gains[k] * updates[k] for k in LABELS}
        unit_rms = {"dense": row["unit_crop_DN16"]["dense"], **item["unit_rgb_RMS_DN16"]}
        rms = {k: gains[k] * unit_rms[k] for k in LABELS}
        shifts = equal_shifts = {}
        if row["id"].startswith("mesh"):
            matched = {
                k: parent + (rms["radial"] / unit_rms[k]) * updates[k]
                for k in LABELS
            }

            def compare(images):
                fit = peak_fit(raw, parent, images, colors, row["roi"])
                base = np.asarray(fit["parent"]["percent_of_observed"])
                return {
                    k: (np.asarray(fit[k]["percent_of_observed"]) - base).tolist()
                    for k in LABELS
                }

            shifts, equal_shifts = compare(estimates), compare(matched)
        displays = []
        for d in originals[row["id"]]["displays"]:
            images = pixels(d["board"])
            exposure = d["exposure"]
            np.testing.assert_array_equal(
                render(parent, wb, matrix, row["roi"], exposure), images["Corpus 100k"]
            )
            np.testing.assert_array_equal(
                render(estimates["radial"], wb, matrix, row["roi"], exposure),
                images["Radial consensus"],
            )
            panels = [(k, images[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Corpus 100k")]
            panels.extend(
                (label, render(estimates[k], wb, matrix, row["roi"], exposure))
                for k, label in LABELS.items()
            )
            panels.extend(
                (k, images[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in images
            )
            board = native_png(dest / f"{row['id']}-x{exposure:g}.png", panels)
            displays.append({"exposure": exposure, "board": board})
        result.append(row | {
            "fields": item["alternatives"],
            "rgb_RMS_DN16": rms,
            "projection_points": shifts,
            "equal_rgb_projection_points": equal_shifts,
            "displays": displays,
        })
    write_json(dest / "result.json", {
        "driver": reference(__file__),
        "fields": binding,
        "baseline": before,
        "calibration": calibration,
        "rows": result,
    })


def exact(calibration, gains):
    proof = reference(ROOT / "offgrid-fresh.json")
    receipt = read_json(checked(proof))
    assert receipt["calibration"] == calibration
    pool = [r for r in receipt["rows"] if r["width"]["4800"]["gap_pixels"]]

    def difference(row, metric):
        group = [row["width"]["4800"]]
        return float(
            values(group, "staggered_selected", metric, gains["staggered_selected"])[0]
            - values(group, "radial", metric, gains["radial"])[0]
        )

    best = min(pool, key=lambda r: difference(r, CONTINUING))
    adverse = max((r for r in pool if r is not best), key=lambda r: difference(r, FALSE))
    dest = ROOT / "native/exact"
    dest.mkdir(parents=True, exist_ok=True)
    result = []
    for row, note in ((best, "largest continuing-wire error reduction"),
                      (adverse, "largest increase in false weak projection among remaining gaps")):
        case = row["case"]
        data, parent, general = replay.read_inputs(case)
        delta, _ = fields(case, data, parent, 4800, cosine=True)
        with np.load(checked(case["input"]), allow_pickle=False) as arrays:
            target = arrays["target"]
        camera = {k: data[k][None] for k in ("colors", "wb", "matrix")}
        labels = ("Noisy Malvar", "V120 EMA", "Corpus 100k", *LABELS.values(), "Exact GT")
        for i, role in ((0, "present"), (3, "flat")):
            noisy = noisy_malvar(camera | {"packed": data["packed"][i:i + 1]})[0]
            prediction = [noisy, general[i], parent[i]]
            prediction.extend(parent[i] + gains[k] * delta[k][i] for k in LABELS)
            prediction.append(target[i])
            result.append(native_board(
                dest, f"offgrid-{case['fixture']['index']:02}-{role}", prediction, camera,
                {
                    "source": case, "role": role, "selection": note, "gain": gains,
                    "difference_vs_radial": {k: difference(row, k) for k in (CONTINUING, FALSE)},
                },
                labels=labels,
                triplet_indices=(0, labels.index(LABELS["staggered_selected"]), len(labels) - 1),
                exposure=2,
                roi=(48, 48, 160, 160),
            ))
    write_json(dest / "result.json", {
        "driver": reference(__file__),
        "calibration": calibration,
        "fresh": proof,
        "rows": result,
    })


if __name__ == "__main__":
    torch.set_num_threads(2)
    calibration = reference(ROOT / "calibration.json")
    strengths = read_json(checked(calibration))["strengths"]["4800"]
    gains = {k: strengths[k]["gain"] for k in LABELS}
    (camera if sys.argv[1] == "camera" else exact)(calibration, gains)
