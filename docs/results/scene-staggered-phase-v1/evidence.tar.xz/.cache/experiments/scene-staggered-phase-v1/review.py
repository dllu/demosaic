"""Arrange unresized review cells and plot paired changes in both off-grid cohorts."""

import os

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_staggered import CONTINUING, FALSE, LABELS, ROOT, pixels


def sheet(tag, rows, labels):
    canvas = Image.new("RGB", (8 + 168 * len(labels), 26 + 184 * len(rows)), "#eeeeee")
    title = ImageDraw.Draw(canvas)
    for j, col in enumerate(labels):
        title.text((8 + 168 * j, 5), col, fill="black")
    for i, (label, board) in enumerate(rows):
        crops = pixels(board)
        for j, col in enumerate(labels):
            crop = Image.fromarray(crops[col])
            assert crop.size == (160, 160)
            canvas.paste(crop, (8 + 168 * j, 26 + 184 * i))
        title.text((8, 188 + 184 * i), label, fill="black")
    output = ROOT / f"view-{tag}.png"
    canvas.save(output)
    return reference(output)


def figure(receipts):
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    metrics = ("fundamental_response", CONTINUING, FALSE, "exact_flat_RMS_DN16")
    headings = ("Intact weak response", "Continuing-wire error",
                "False weak projection", "Exact-flat error")
    labels = ("Percentage points", "DN16 RMS", "DN16 RMS", "DN16 RMS")
    order = ("pruned_integer", "staggered_mean", "staggered_selected", "dense")
    positions = np.arange(len(order))
    fig, axes = plt.subplots(2, 2, figsize=(9.6, 5.2), layout="constrained")
    for ax, key, heading, label in zip(axes.flat, metrics, headings, labels, strict=True):
        ax.axvline(0, color="#888888", linewidth=1)
        for offset, cohort, c in [(-0.13, "prior", "#366393"), (0.13, "fresh", "#aa522d")]:
            data = receipts[cohort]["summary"][key]["values"]
            delta, low, high = np.array([data[k]["radial"] for k in order]).T
            ax.errorbar(delta, positions + offset, xerr=[delta - low, high - delta],
                        fmt="o", ms=3.8, capsize=2.7, color=c, label=cohort.title())
        ax.set_title(heading)
        ax.set_xlabel(label)
        ax.set_yticks(positions, [LABELS[k] for k in order])
        ax.invert_yaxis()
        ax.grid(axis="x", alpha=0.2)
    axes[0, 0].legend(loc="upper right", fontsize=8)
    fig.suptitle("Off-grid detail vs the earlier radial filter (95% paired intervals)")
    output = ROOT / "off-grid-effects.png"
    fig.savefig(output, dpi=155, facecolor="white")
    return reference(output)


def main():
    native = {k: reference(ROOT / f"native/{k}/result.json") for k in ("standing", "exact")}
    stand, exact = (read_json(checked(r))["rows"] for r in native.values())
    views = {}
    primary = ("Noisy (Malvar)", "Corpus 100k", "Earlier radial", "Four-grid mean",
               "Four-grid selected", "ISO100 AHD reference")
    controls = ("V120 EMA", "Dense cosine prior", "Pruned integer")
    for family, exposure in (("main", 4), ("mesh", 4), ("mesh", 16)):
        items = [
            (r["id"], d["board"])
            for r in stand if r["id"].startswith(family)
            for d in r["displays"] if d["exposure"] == exposure
        ]
        tag = f"{family}-x{exposure}"
        views[tag] = sheet(tag, items, primary)
        references = () if family == "main" else ("ISO6400 camera JPEG", "ISO100 camera JPEG")
        views[tag + "-controls"] = sheet(tag + "-controls", items, controls + references)
    views["exact"] = sheet(
        "exact", [(a["id"], a["board"]) for a in exact],
        ("Noisy Malvar", "Corpus 100k", *LABELS.values(), "Exact GT")
    )
    numeric = {k: reference(ROOT / f"offgrid-{k}.json") for k in ("prior", "fresh")}
    chart = figure({k: read_json(checked(v)) for k, v in numeric.items()})
    write_json(ROOT / "views.json", {
        "driver": reference(__file__), "native": native, "numeric": numeric,
        "views": views, "figure": chart,
    }, replace=True)


if __name__ == "__main__":
    main()
