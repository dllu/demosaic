"""Replay the fixed sensor windows on the two standing GFX captures."""

import time
from pathlib import Path

import numpy as np
import torch
from staggered_phase import ROOT, corrections, encode_banks, patch
from score_staggered import BAND, DENSE, PRIOR, replay
from atlas_probe import exact_query, load_standing, packed_scene

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

DEST = Path("/mnt/external/demosaic") / ROOT.name / "camera"


def main():
    torch.set_num_threads(2)
    ancestor = reference(PRIOR / "camera-fields.json")
    records = {r["id"]: r for r in read_json(checked(ancestor))["rows"]}
    _, baseline, lookup = load_standing()
    DEST.mkdir()
    rows = []
    start = time.monotonic()
    for family in ("main", "mesh"):
        group = [r for r in baseline["rows"] if r["id"].startswith(family)]
        ref, scene, colors = packed_scene(group)
        for r in group:
            saved = records[r["id"]]
            assert ref == saved["raw"] and r["query"] == saved["absolute_query"]
            packed, parent, roi, wb, matrix = exact_query(r, lookup, scene, colors)
            shot, read = (r["noise"][k] for k in ("shot", "read"))
            dense = patch.build_exterior(
                scene, colors, r["query"], shot, read, band=BAND, dense_radius=DENSE
            )
            bank = encode_banks(scene, colors, dense, shot, read)
            lifts = corrections(packed, parent[1], shot, read, r["query"], bank)
            units = {
                k: replay.apply_delta(np.zeros_like(parent), v, wb, matrix, 1)
                for k, v in lifts.items()
            }
            with np.load(checked(saved["paths"]), allow_pickle=False) as f:
                for k, arr in (("raw", packed), ("parent", parent), ("radial", units["radial"])):
                    np.testing.assert_array_equal(arr, f[k])
            result = DEST / f"{r['id']}.npz"
            with result.open("xb") as data:
                np.savez_compressed(data, **{k: v for k, v in units.items() if k != "radial"})
            x, y, w, h = roi
            window = np.s_[..., y : y + h, x : x + w]
            rms = {
                k: float(np.sqrt(np.mean(delta[window].astype(float) ** 2)) * 65535)
                for k, delta in units.items()
            }
            rows.append(
                {"case": saved, "alternatives": reference(result), "unit_rgb_RMS_DN16": rms}
            )
            print(r["id"], rms, flush=True)
    write_json(
        ROOT / "camera-fields.json",
        {
            "driver": reference(__file__),
            "baseline": ancestor,
            "rows": rows,
            "seconds": time.monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
