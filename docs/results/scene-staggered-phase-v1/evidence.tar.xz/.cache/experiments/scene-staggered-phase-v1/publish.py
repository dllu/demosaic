"""Bind the staggered-grid measurement receipts and verified native views."""

import shutil
import tarfile
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_staggered import LABELS, PRIOR, ROOT, pixels

REPO = ROOT.parents[2]
EXTERNAL = Path("/mnt/external/demosaic")
ART = REPO / "docs/images" / ROOT.name
RES = REPO / "docs/results" / ROOT.name
FILES = {
    "calibration": "calibration.json",
    "retained": "retained.json",
    "prior": "offgrid-prior.json",
    "fresh": "offgrid-fresh.json",
    "coverage": "math-audit.json",
    "camera_fields": "camera-fields.json",
    "standing": "native/standing/result.json",
    "exact": "native/exact/result.json",
    "viewing": "views.json",
}


def copy(binding, group=""):
    path = checked(binding)
    target = ART / group / path.name
    shutil.copyfile(path, target)
    assert reference(target)["sha256"] == binding["sha256"]
    return binding | {"path": str(target.relative_to(ART))}


def board(record, group):
    verified = pixels(record)
    assert all(im.shape == (160, 160, 3) for im in verified.values())
    assert len(record["panels"]) == len(verified)
    return record | {"image": copy(record["image"], group)}


def main():
    receipts = {k: reference(ROOT / v) for k, v in FILES.items()}
    data = {k: read_json(checked(ref)) for k, ref in receipts.items()}
    cal, retained, prior, fresh, audit, camera, standing, exact, viewing = data.values()
    for stage in (retained, prior, fresh, standing, exact):
        assert stage["calibration"] == receipts["calibration"]
    assert standing["fields"] == receipts["camera_fields"]
    assert exact["fresh"] == receipts["fresh"]
    assert viewing["numeric"] == {k: receipts[k] for k in ("prior", "fresh")}
    assert viewing["native"] == {k: receipts[k] for k in ("standing", "exact")}
    assert len(viewing["views"]) == 7
    for binding in viewing["views"].values():
        checked(binding)
    assert len(cal["calibration"]) == 16
    assert len(retained["long"]) == len(retained["natural"]) == 32
    assert len(retained["short"]) == 24
    for entry in (prior, fresh):
        assert len(entry["rows"]) == 24
        assert sum(r["width"]["4800"]["gap_pixels"] > 0 for r in entry["rows"]) == 16

    parents = read_json(checked(fresh["input"]))
    plan = read_json(checked(parents["plan"]))
    assert parents["weights"] == plan["weights"] and parents["plan"] == audit["fresh_plan"]
    assert plan["parent_visits_checked"] == 559808

    def identities(cohort, key):
        return {r["case"]["source"][key] for r in cohort}

    for key in ("id", "cache_sha256"):
        new = identities(fresh["rows"], key)
        old = set.union(*(identities(retained[k], key) for k in ("long", "short", "natural")),
                        identities(prior["rows"], key))
        assert len(new) == 24 and new.isdisjoint(old)
    for row in parents["rows"]:
        checked(row["input"])
        checked(row["rgb"])
    for item in camera["rows"]:
        checked(item["case"]["paths"])
        checked(item["alternatives"])

    (ART / "standing").mkdir(parents=True)
    (ART / "exact").mkdir()
    RES.mkdir(parents=True)
    standing_views = []
    for row in standing["rows"]:
        displays = []
        is_mesh = row["id"].startswith("mesh")
        assert {d["exposure"] for d in row["displays"]} == ({4, 16} if is_mesh else {4})
        for display in row["displays"]:
            expected = {"Noisy (Malvar)", "V120 EMA", "Corpus 100k",
                        *LABELS.values(), "ISO100 AHD reference"}
            if is_mesh:
                expected.update(("ISO6400 camera JPEG", "ISO100 camera JPEG"))
            assert set(pixels(display["board"])) == expected
            displays.append(display | {"board": board(display["board"], "standing")})
        standing_views.append(row | {"displays": displays})
    assert len(standing_views) == 8 and sum(len(r["displays"]) for r in standing_views) == 12

    exact_views = []
    for row in exact["rows"]:
        panel, triplet = (pixels(row[k]) for k in ("board", "triplet"))
        assert list(triplet) == ["Noisy Malvar", "Four-grid selected", "Exact GT"]
        for k in triplet:
            np.testing.assert_array_equal(triplet[k], panel[k])
        exact_views.append(row | {k: board(row[k], "exact") for k in ("board", "triplet")})
    assert len(exact_views) == 4
    manifest = ART / "manifest.json"
    write_json(manifest, {
        "weight_type": "EMA",
        "weights": parents["weights"],
        "fresh_plan": parents["plan"],
        "standing": standing_views,
        "exact": exact_views,
        "figure": copy(viewing["figure"]),
        "review": {
            "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "sheets": receipts["viewing"],
            "main": "Smooth sky, connected coarse crossings and soft fine wires and foliage.",
            "mesh": "Both ROIs, priors and displays checked with the two JPEGs and AHD reference. "
                    "No newly connected fine crossings or conspicuous chroma artifacts.",
            "exact": "The strong diagonals persist and weaker directions stay soft. "
                     "Both exact flat controls look smooth at the common exposure.",
        },
    })
    payload = [
        *receipts.values(), *(r["driver"] for r in data.values()), cal["operator"],
        cal["retained_source"], cal["previous_calibration"], prior["input"], fresh["input"],
        parents["plan"], plan["driver"], plan["freeze_driver"], plan["fixture"],
        audit["prior_plan"], standing["baseline"], camera["baseline"],
        reference(manifest), reference(__file__),
        reference(PRIOR / "consensus_measure.py"),
        reference(PRIOR / "query_consensus.py"),
        reference(ROOT.with_name("scene-phase-power-v1") / "phase_pairs.py"),
        reference(ROOT.with_name("scene-phase-power-v1") / "evaluate_phase.py"),
        reference(ROOT.with_name("scene-dense-atlas-v1") / "atlas_probe.py"),
        reference(ROOT.with_name("scene-patch-width-v1") / "evaluate_wide.py"),
        reference(ROOT.with_name("scene-patch-width-v1") / "render_wide.py"),
        reference(ROOT.with_name("scene-patch-crossfit-v1") / "capture.py"),
        reference(REPO / "src/demosaic/scene_patch_covariance.py"),
        reference(REPO / "scripts/report_scene_wave_guides.py"),
        reference(REPO / "configs/gfx-green-mesh-20231231.json"),
        reference(REPO / "configs/gfx-qualitative-20231231.json"),
    ]
    archive = RES / "evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for binding in {v["path"]: v for v in payload}.values():
            path = checked(binding)
            name = (path.relative_to(REPO) if path.is_relative_to(REPO)
                    else Path("external") / path.relative_to(EXTERNAL)).as_posix()
            tar.add(path, arcname=name)
            members[name] = binding["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(k).read()).hexdigest() == v for k, v in members.items())
    write_json(RES / "publication.json", {
        "scope": "Inference-only correction on frozen Corpus 100k EMA. Two 24-photo off-grid "
                 "panels, retained targets and both standing GFX captures.",
        "weight_type": "EMA",
        "weights": parents["weights"],
        "strengths": cal["strengths"],
        "off_grid": {k: data[k]["summary"] for k in ("prior", "fresh")},
        "retained": retained["scores"],
        "spectral_coverage": audit["median"],
        "seconds": {
            "calibration": cal["seconds"],
            "retained_scoring": retained["time_seconds"],
            "fresh_capture_wall_including_pause": parents["seconds"],
            "fresh_scoring": fresh["seconds"],
            "prior_scoring_and_parity": prior["seconds"],
            "standing_fields": camera["seconds"],
        },
        "receipts": receipts,
        "native": reference(manifest),
        "archive": reference(archive),
        "members": members,
    })


if __name__ == "__main__":
    main()
