"""Archive the input intervention, execution and native viewing evidence."""

import tarfile
from datetime import datetime
from pathlib import Path
from shutil import copyfile
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-context-extent-v1")
IMAGES = Path("docs/images/scene-context-extent-v1")
RESULTS = Path("docs/results/scene-context-extent-v1")


def main():
    result_file = ROOT / "review/result.json"
    result = read_json(result_file)
    audit = read_json(ROOT / "audit.json")
    assert audit["status"] == "passed" and audit["result"] == reference(result_file)
    viewing = checked(reference(ROOT / "native-viewing.json"))
    viewed = read_json(viewing)
    by_id = {r["id"]: r for r in viewed["boards"]}
    assert len(result["boards"]) == len(by_id) == 16
    IMAGES.mkdir()
    RESULTS.mkdir()
    boards = []
    for board in result["boards"]:
        p = checked(board["image"])
        assert by_id[board["id"]]["original_image"] == board["image"]
        to = IMAGES / p.name
        copyfile(p, to)
        record = reference(to)
        assert record["sha256"] == board["image"]["sha256"]
        boards.append(
            {**board, "published": record, "observation_note": by_id[board["id"]]["note"]}
        )
    write_json(
        IMAGES / "manifest.json",
        {
            "viewed_at": viewed["viewed_at"],
            "publication_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "model": read_json(ROOT / "collection.json")["checkpoint"],
            "boards": boards,
            "scope": "All 16 native boards viewed without altering crop pixels. All sensor tile inputs are unchanged.",
        },
    )
    evidence = [
        ROOT / n
        for n in (
            "plan.json",
            "collection.json",
            "collection.log",
            "focused-tests.log",
            "review/result.json",
            "audit.py",
            "audit.json",
            "native-viewing.json",
            "publish.py",
        )
    ]
    evidence += sorted((ROOT / "predictions").glob("*.json"))
    evidence += sorted((ROOT / "work/scripts").glob("*.py"))
    evidence += [
        ROOT / "work/src/demosaic" / p
        for p in ("scene_restoration.py", "scene_context.py", "scene_inference.py")
    ]
    evidence.append(checked(result["reporter"]))
    archive = RESULTS / "evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for p in evidence:
            tar.add(p.relative_to(Path.cwd()) if p.is_absolute() else p)
    for name in ("audit.json", "native-viewing.json"):
        copyfile(ROOT / name, RESULTS / name)
    write_json(
        RESULTS / "publication.json",
        {
            "archive": reference(archive),
            "members": [reference(p) for p in evidence],
            "manifest": reference(IMAGES / "manifest.json"),
            "board_count": len(boards),
            "scope": "Context interventions on a completed spatial 2k EMA checkpoint. Separate native inputs and outputs; zero new training updates.",
        },
    )


if __name__ == "__main__":
    main()
