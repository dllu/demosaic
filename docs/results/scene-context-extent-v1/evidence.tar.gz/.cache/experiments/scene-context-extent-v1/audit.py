"""Independent crop, Fourier-band and camera-change checks of the context blur comparison."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.fft import dctn

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(".cache/experiments/scene-context-extent-v1")
METHODS = ("full", "blur-distant", "blur-near")
LUMA = np.array([0.2126, 0.7152, 0.0722])


def image_bands(values, wb, matrix):
    _, _, height, width = values.shape
    assert (height, width) == (256, 256)
    srgb = np.einsum("bij,bjhw->bihw", matrix, values.astype(np.float64) * wb[:, :, None, None])
    luma = np.einsum("c,bchw->bhw", LUMA, srgb)
    windowed = np.array(
        [luma[:, y : y + 16, x : x + 16] for y in range(8, 248, 16) for x in range(8, 248, 16)]
    ).transpose(1, 0, 2, 3)
    grid = np.arange(16) / 32
    radius = np.sqrt(grid[:, None] ** 2 + grid[None, :] ** 2)
    take = (radius >= 1 / 8) & (radius < 1 / 3)
    return dctn(windowed, norm="ortho", axes=(-2, -1))[:, :, take], windowed, srgb


def masks(bands, windows, rgb):
    targets = np.clip(rgb, 0, 1)
    clipped = np.array(
        [
            (rgb[:, :, y : y + 16, x : x + 16] != targets[:, :, y : y + 16, x : x + 16]).any(
                (1, 2, 3)
            )
            for y in range(8, 248, 16)
            for x in range(8, 248, 16)
        ]
    ).T
    coarse = windows.mean((2, 3))
    energy = np.sqrt((bands**2).sum(-1)) / 16
    use = (~clipped) & (0.02 <= coarse) & (coarse <= 0.9)
    return {
        "weak": use & (energy >= 1e-5) & (energy < 0.02 * coarse),
        "quiet": use & (energy < 1e-5),
    }


def rendered(rgb):
    clipped = np.minimum(np.maximum(rgb, 0), 1)
    return np.where(clipped <= 0.0031308, clipped * 12.92, 1.055 * clipped ** (1 / 2.4) - 0.055)


def native_cells(path, board):
    with Image.open(checked(path)) as raw:
        return {
            p["label"]: np.asarray(raw.crop((x, y, x + w, y + h)))
            for p in board["panels"]
            for x, y, w, h in (p["png_xywh"],)
        }


def run():
    result_path = ROOT / "review/result.json"
    result = read_json(result_path)
    collection = read_json(checked(result["collection"]))
    plan = read_json(checked(collection["plan"]))
    original = read_json(checked(plan["original"]))
    retained = read_json(checked(result["source_native"]))
    original_boards = {r["id"]: r for r in retained["boards"]}
    score = {(r["case"], r["method"], r["crop"]): r for r in result["metrics"]}
    assert len(score) == 48 and len(collection["rows"]) == 10
    max_error = 0.0
    cells_count = 0
    reductions = 0
    totals = defaultdict(dict)
    for declaration, record in zip(original["observations"], collection["rows"], strict=True):
        name = record["case"]
        assert name == declaration["id"]
        value = {
            k: np.load(checked(v), allow_pickle=False) for k, v in record["prediction"].items()
        }
        camera = declaration["kind"] != "development"
        if not camera:
            with np.load(checked(declaration["arrays"]), allow_pickle=False) as arrays:
                target = arrays["crop_target"]
                wb, matrix = [arrays[k] for k in ("crop_wb", "crop_matrix")]
            true_band, local, rgb = image_bands(target, wb, matrix)
            by_level = masks(true_band, local, rgb)
            for method, prediction in value.items():
                predicted, _, predicted_rgb = image_bands(prediction, wb, matrix)
                for i, _ in enumerate(prediction):
                    row = score[name, method, i]
                    delta = prediction[i].astype(np.float64) - value["full"][i]
                    expected = np.sqrt((delta**2).mean()) * 65535
                    max_error = max(max_error, abs(expected - row["output_change_DN16"]))
                    area = np.s_[i, :, 8:248, 8:248]
                    difference = rendered(rgb[area]) - rendered(predicted_rgb[area])
                    psnr = float(-10 * np.log10(np.mean(difference**2)))
                    max_error = max(max_error, abs(psnr - row["srgb_psnr"]))
                    reductions += 2
                    for level, eligible in by_level.items():
                        s = eligible[i]
                        observed = row[f"{level}_band_sums"]
                        if not s.any():
                            assert observed is None
                            continue
                        assert observed["blocks"] == int(s.sum())
                        actual, truth = predicted[i, s], true_band[i, s]
                        expected = {
                            "target": np.vdot(truth, truth),
                            "cross": np.vdot(truth, actual),
                            "prediction": np.vdot(actual, actual),
                            "error": np.vdot(truth - actual, truth - actual),
                        }
                        for k, v in expected.items():
                            max_error = max(max_error, abs(v - observed[k]))
                            reductions += 1
        for board in result["boards"]:
            if board["observation"] != name:
                continue
            previous = original_boards[board["id"]]
            before = native_cells(previous["image"], previous)
            current = native_cells(board["image"], board)
            for label in current.keys() & before.keys():
                np.testing.assert_array_equal(current[label], before[label])
                cells_count += 1
            x, y, w, h = board["case"]["ROI_xywh"]
            i = board["case"]["crop_index"]
            for method in METHODS:
                first = value[method][i, :, y : y + h, x : x + w].astype(np.float64)
                full = value["full"][i, :, y : y + h, x : x + w]
                expected = np.sqrt(((first - full) ** 2).mean()) * 65535
                assert abs(expected - board["output_change_DN16"][method]) < 2e-12
                reductions += 1
    assert max_error < 1e-4
    for row in result["metrics"]:
        _, _, prior = row["case"].split("-", 2)
        totals[prior].setdefault(row["method"], []).append(row)
    summary = {}
    for prior, arms in totals.items():
        summary[prior] = {}
        for method, rows in arms.items():
            s = [r["weak_band_sums"] for r in rows if r["weak_band_sums"] is not None]
            q = [r["quiet_band_sums"] for r in rows if r["quiet_band_sums"] is not None]
            summary[prior][method] = {
                "crops": len(rows),
                "psnr": float(np.mean([r["srgb_psnr"] for r in rows])),
                "change_DN16": float(np.mean([r["output_change_DN16"] for r in rows])),
                "weak_blocks": sum(r["blocks"] for r in s),
                "weak_band_error_DN16": float(
                    np.sqrt(sum(r["error"] for r in s) / (256 * sum(r["blocks"] for r in s)))
                    * 65535
                )
                if s
                else None,
                "weak_band_response": float(
                    sum(r["cross"] for r in s) / sum(r["target"] for r in s)
                )
                if s
                else None,
                "quiet_blocks": sum(r["blocks"] for r in q),
            }
    write_json(
        ROOT / "audit.json",
        {
            "driver": reference(__file__),
            "result": reference(result_path),
            "status": "passed",
            "retained_display_cells": cells_count,
            "direct_reductions": reductions,
            "max_absolute_metric_difference": max_error,
            "conditions": summary,
            "camera_roi_changes": {
                r["id"]: r["output_change_DN16"]
                for r in result["boards"]
                if not r["id"].startswith("development-")
            },
        },
    )
    print(summary)


if __name__ == "__main__":
    run()
