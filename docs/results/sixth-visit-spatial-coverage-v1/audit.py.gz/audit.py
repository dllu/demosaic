"""At fixed crop size, measure added cache area available on an ordinary sixth visit."""

import hashlib
import json
import os
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
PUBLISHED = Path("docs/results/full-corpus-long100k-training-v1")
GROUPS = ("all", "short512-639", "short640-767", "short768+")


def tiles(boxes):
    """Partition a small rectangle union into disjoint vertical-strip rectangles."""
    xs = sorted({x for left, _, w, _ in boxes for x in (left, left + w)})
    for x1, x2 in zip(xs[:-1], xs[1:], strict=True):
        yranges = sorted((y, y + h) for x, y, w, h in boxes if x <= x1 < x + w)
        if not yranges:
            continue
        begin, end = yranges[0]
        for low, high in yranges[1:]:
            if end < low:
                yield x1, begin, x2, end
                begin, end = low, high
            else:
                end = max(end, high)
        yield x1, begin, x2, end


def overlap(start, widths, minima, maxima):
    start = np.asarray(start, dtype=np.int64)[..., None]
    return (np.minimum(start + widths, maxima) - np.maximum(start, minima)).clip(min=0)


def positions(edges, extent, width):
    return np.unique(np.r_[0, extent - width, edges, edges - width].clip(0, extent - width))


def areas(rects, shape, rng):
    five, last = rects[:5], rects[5]
    height, width = shape
    x, y, w, h = last
    x1, y1, x2, y2 = np.asarray(list(tiles(five)), dtype=np.int64).T

    # For fixed crop size the covered area is bilinear between these
    # alignments, so a global minimum occurs at a breakpoint pair.
    xs = positions(np.r_[x1, x2], width, w)
    ys = positions(np.r_[y1, y2], height, h)
    all_overlap = overlap(xs, w, x1, x2) @ overlap(ys, h, y1, y2).T
    base = int(np.sum(overlap([x], w, x1, x2) * overlap([y], h, y1, y2)))
    trial_x = rng.integers(width - w + 1, size=3)
    trial_y = rng.integers(height - h + 1, size=3)
    random_overlaps = (overlap(trial_x, w, x1, x2) * overlap(trial_y, h, y1, y2)).sum(axis=-1)
    actual = w * h - base
    best4 = w * h - min(base, int(random_overlaps.min()))
    optimum = w * h - int(all_overlap.min())
    already_seen = int(((x2 - x1) * (y2 - y1)).sum())
    assert 0 <= actual <= best4 <= optimum <= width * height - already_seen
    return actual, best4, optimum, already_seen


def verify():
    rng = np.random.default_rng(5003)
    for iteration in range(64):
        height, width = map(int, rng.integers(4, 21, size=2))
        crops = []
        for _ in range(6):
            w, h = (int(rng.integers(1, d + 1)) for d in (width, height))
            x, y = (int(rng.integers(d - k + 1)) for d, k in ((width, w), (height, h)))
            crops.append((x, y, w, h))
        occupied = np.zeros((height, width), bool)
        for x, y, w, h in crops[:5]:
            occupied[y:y+h, x:x+w] = True
        x, y, w, h = crops[5]
        expected = (w*h-int(occupied[y:y+h,x:x+w].sum()),
                    max(w*h-int(occupied[j:j+h,i:i+w].sum())
                        for i in range(width-w+1) for j in range(height-h+1)))
        actual, _, upper, covered = areas(crops, (height, width), rng)
        assert (actual, upper, covered) == (*expected, int(occupied.sum())), iteration


def extract(audit):
    rows = defaultdict(list)
    for binding in audit["source_traces"]:
        source = checked(binding)
        with source.open() as stream:
            for line in stream:
                for item in json.loads(line)["sources"]:
                    if item["kind"] == "photographic" and item["reviewed_roi_xywh"] is None:
                        rows[item["source_id"]].append(item["cache_xywh"])
    assert len(rows) == audit["ordinary_distinct"] == 90778
    assert sum(map(len, rows.values())) == audit["observed_source_counts"]["ordinary"]
    return {key: value for key, value in rows.items() if len(value) == 6}


def summarize(records):
    x = np.asarray(records)
    report = {"sources": len(x)}
    for col,name in enumerate(("as_trained","best_of_four","exact_maximum","first_five_union")):
        d = x[:,col]
        report[name] = {
            "mean_frame_fraction":float(d.mean()),
            "p10_p50_p90":np.quantile(d,[.10,.50,.90]).tolist(),
            "zero_area_count":int((d==0).sum()),
        }
    for col,name in enumerate(("best_of_four","exact_maximum"),1):
        d = x[:,col]-x[:,0]
        report[f"{name}_improvement"] = {
            "p10_p50_p90":np.quantile(d,[.10,.50,.90]).tolist(),
            "greater_than_one_percent":int((d>.01).sum()),
            "greater_than_five_percent":int((d>.05).sum()),
        }
    return report


def main():
    os.sched_setaffinity(0,[18])
    os.nice(10)
    began=time.monotonic()
    verify()
    print("64 exact brute-force occupancy checks passed",flush=True)
    bound=reference(PUBLISHED/"source-audit.json")
    audit=read_json(checked(bound))
    prior=read_json(checked(audit["prefix_from_86k"]))
    order=read_json(checked(prior["order"]))
    manifest=order["source_manifest"]
    shapes={}
    with checked(manifest).open() as stream:
        for line in stream:
            row=json.loads(line)
            if row["split"]=="train":
                shapes[row["id"]]=tuple(row["shape"][:2])
    rows=extract(audit)
    assert len(rows)==audit["sixth_ordinary_partial"]==78013
    results=defaultdict(list)
    for source, rects in rows.items():
        shape=shapes[source]
        seed=int.from_bytes(hashlib.sha256(f"sixth-extra-position-v1:{source}".encode()).digest()[:8],"little")
        area=areas(rects,shape,np.random.default_rng(seed))
        fractions=np.asarray(area)/(shape[0]*shape[1])
        results["all"].append(fractions)
        short=min(shape)
        results["short512-639" if short<640 else "short640-767" if short<768 else "short768+"].append(fractions)
    summary={k:summarize(results[k]) for k in GROUPS}
    actual=summary["all"]["as_trained"]
    assert actual["p10_p50_p90"]==audit["sixth_added_area_ratio_p10_p50_p90"]
    assert actual["zero_area_count"]==audit["sixth_unchanged_area_count"]
    write_json(ROOT/"result.json",{
        "producer":reference(__file__),"source_audit":bound,"manifest":manifest,"brute_force_fixtures":64,
        "scope":"Fixed actual sixth crop size over actual first-five ordinary bounding-box union. Best of four includes the actual position plus three seeded legal placements. No cache pixels, geometry, noise, holdout or model tensors were read or changed.",
        "by_short_axis":summary,"wall_seconds":time.monotonic()-began,
    })
    print(summary["all"],flush=True)


if __name__=="__main__":
    main()
