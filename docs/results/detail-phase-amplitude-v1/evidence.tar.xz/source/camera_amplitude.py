"""Measure how the cap and measured allowance affect two real cab directions."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_amplitude import OUT, operator, review

MEASURED = {
    "left": np.array([(0.1152, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
    "right": np.array([(0.1172, 0.0742), (0.0898, -0.0723)])[:, ::-1].copy(),
}
TOLERANCE = 0.009
D65 = np.array([0.2126, 0.7152, 0.0722])
MODES = ("fixed", "raised", "directional")


def coverage(pair, mask, detail):
    results = []
    for f in pair:
        flags, amps = [], []
        for r in detail:
            candidate = r["phase"]
            distance = np.minimum(np.linalg.norm(candidate - f, axis=-1),
                                  np.linalg.norm(candidate + f, axis=-1))
            assigned = (distance <= TOLERANCE) & mask
            fixed, raised, measured = r["amplitude"][:3] * 65535
            results_for_fold = np.stack((fixed > 0.05, raised-fixed > 0.05, measured-fixed > 0.05))
            flags.append((assigned[None] & results_for_fold).any(axis=(1, 2)))
            values = (assigned[None] * r["amplitude"][:3] * 65535).sum(axis=1)[:, 0]
            amps.append(values[:, mask])
        count = np.logical_or(*flags).sum(axis=(1, 2))
        results.append({"stations": count.tolist(),
                        "mean_station_peak_DN16": np.stack(amps).mean((0, 2)).tolist()})
    return results


def project(baseline, deltas, origin, dimensions, pair):
    x, y = origin
    w, h = dimensions
    py, px = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    nuisance = np.stack((np.ones_like(px), px/w, py/h, px**2/w**2, px*py/(w*h), py**2/h**2), -1)
    phase = 2 * np.pi * np.einsum("xyc,kc->xyk", np.stack((py, px), -1), pair)
    basis = np.stack((np.cos(phase), np.sin(phase)), -1).reshape(h, w, 4)
    window = np.sqrt(np.outer(np.hanning(h), np.hanning(w)))
    X = (np.concatenate((nuisance, basis), -1) * window[..., None]).reshape(-1, 10)
    control = baseline[y:y+h, x:x+w]
    frames = [control, *(control + v[0, y:y+h, x:x+w] for v in deltas.values())]
    solved = np.linalg.lstsq(X, (np.stack(frames, -1) * window[..., None]).reshape(-1, len(frames)),
                             rcond=None)[0][-4:]
    values = np.linalg.norm(solved.reshape(2, 2, -1), axis=1) * 65535
    return dict(zip(("nominal", *deltas), values.T.tolist(), strict=True))


if __name__ == "__main__":
    adapter = reference(OUT / "native-adapter.json")
    bindings = read_json(checked(adapter))["rows"]
    lock = reference(OUT / "score-calibration.json")
    doses = {k: c["locked"]["dose"] for k, c in read_json(checked(lock))["policy"]["arms"].items()}
    doses["fixed"] = 0.30
    output = {}
    for row, d, p, _ in review.Cases("camera"):
        key = row["id"]
        if not key.startswith("mesh-"):
            continue
        mark = bindings[key]
        assert mark["input"] == row["input"]
        ox, oy, w, h = mark["operator_roi"]
        dx, dy, dw, dh = mark["display_roi"]
        plane = np.s_[..., oy//2:(oy+h)//2, ox//2:(ox+w)//2]
        area = np.s_[..., oy:oy+h, ox:ox+w]
        pos = np.arange(16, 256, 32)
        inside = ((pos+oy >= dy) & (pos+oy < dy+dh))[:, None] & ((pos+ox >= dx) & (pos+ox < dx+dw))[None, :]
        pair = MEASURED[key.rsplit("-", 1)[-1]]
        nominal = p | {"nominal": p["nominal"][area]}
        delta, _, details = operator.fields(d | {"packed": d["packed"][plane]}, nominal, row["profile"])
        detect = coverage(pair, inside, details)
        base = np.einsum("chw,c->hw", nominal["nominal"][0], (D65 @ d["matrix"]) * d["wb"])
        area = (dx-ox, dy-oy), (dw, dh)
        locked = project(base, {k: delta[k] * doses[k] for k in MODES}, *area, pair)
        full = project(base, {k: delta[k] for k in MODES}, *area, pair)
        output[key] = {"input": row["input"], "peak_fy_fx": pair.tolist(), "native_stations": int(inside.sum()),
                       "coverage": detect, "locked_projection_DN16": locked, "full_projection_DN16": full}
    write_json(OUT / "camera-amplitude.json", {
        "driver": reference(Path(__file__)), "review": adapter, "calibration": lock,
        "source": reference(Path.cwd() / "docs/bayer-carrier-scale.md"),
        "columns": ["fixed station exists", "extension under higher cap", "extension under measured allowance"],
        "tolerance_cycles_per_pixel": TOLERANCE, "rows": output,
        "scope": "Actual RAW-supported candidates and two-component luma fits to a single restoration; independent ISO100 is qualitative only.",
    })
