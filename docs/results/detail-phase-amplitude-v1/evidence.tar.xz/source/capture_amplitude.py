"""Capture fresh subjects using the frozen optical and natural-photo protocols."""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest.mock import patch

from demosaic.experiments.artifacts import reference, write_json

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PREVIOUS = ("detail-wide-phase-v1", "detail-crossfit-phase-v1", "detail-phase-shortlist-v1")
SEED = 202611201150
spec = spec_from_file_location("wide_capture_design", HERE.with_name(PREVIOUS[0]) / "capture_wide.py")
design = module_from_spec(spec)
spec.loader.exec_module(design)


if __name__ == "__main__":
    folder = OUT / "confirmation"
    folder.mkdir(exist_ok=True)
    plan = folder / "plan.json"
    if not plan.exists():
        with patch.object(design, "SEED", SEED), patch.object(
            design, "PROTECTED", (*design.PROTECTED, *PREVIOUS)
        ):
            selected = design.select()
        write_json(plan, selected | {"followup_driver": reference(Path(__file__)),
                                     "selection_operator": reference(Path(design.__file__))})
    with patch.object(design.prior.c, "OUT", folder), patch.object(design.prior.c, "SEED", SEED):
        design.prior.c.collect("held")
