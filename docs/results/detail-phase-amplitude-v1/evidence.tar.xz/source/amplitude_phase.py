"""Compare higher delivery amplitude with a local, noise-aware allowance."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.with_name("detail-phase-shortlist-v1")))
import shortlist_phase as previous

wide = previous.wide
local = previous.local
old = previous.old
COUNT = previous.COUNT
SIZE = previous.SIZE
CAP = 192 / 65535
LOWER_MARGIN = 0.75


def fit_station(sensors, nomination, evidence):
    primary, secondary = nomination
    lookup = wide.inject(nomination)
    strong, score = lookup(sensors, None, np.empty((0, 0)))
    weak, vote = lookup(sensors, None, np.empty((0, 1)))
    both = np.stack((strong, weak), axis=1)
    outer = np.stack([local.regress(s, both, "exterior")[0][..., -2:] for s in sensors])
    common = outer.mean(axis=0)
    amplitude = np.linalg.norm(common, axis=-1)
    direction = common / np.maximum(amplitude[:, None], 1e-10)
    valid = (score >= 4) & (vote >= 3.5) & ((outer * direction).sum(-1).min(axis=0) > 0)
    fitted = [local.regress(s, both, "central", inspect=True) for s in sensors]
    center = np.stack([(r[..., -2:, 0] * direction).sum(-1) for r, _ in fitted])
    nominal = np.stack([(r[..., -2:, 1] * direction).sum(-1) for r, _ in fitted]).mean(0)
    noise = np.stack([np.sqrt(np.maximum(1e-12, np.einsum("si,sij,sj->s", direction, v, direction)))
                      for _, v in fitted])
    signal = center / noise
    margin = np.maximum(signal.min(axis=0) - 0.35, 0)
    check = margin / (1 + margin)
    expect = np.minimum(0.75 * amplitude[None] / noise, 6)
    odds = (expect * (signal - 0.5 * expect)).sum(axis=0)
    guard = np.clip(0.5 + 0.25 * odds, 0, 1)
    supported = evidence * valid
    outer_deficit = np.maximum(amplitude - nominal, 0) * supported
    lower = np.minimum(amplitude, (center - LOWER_MARGIN * noise).min(axis=0))
    measured_deficit = np.maximum(lower - nominal, 0) * supported
    return {
        "frequency": weak, "direction": direction, "outer": outer_deficit, "measured": measured_deficit,
        "nominal": nominal, "center": check, "guard": guard, "validated": valid & (evidence > 0),
    }


def share(values, limit):
    return values * limit / np.maximum(np.maximum(values.sum(axis=0), limit), 1e-10)


def budgets(fits, scale, shape):
    anchor = np.stack([p["outer"] for p in fits]) / scale
    confirmed = np.stack([p["measured"] for p in fits]) / scale
    check = np.stack([p["center"] for p in fits])
    baseline = share(np.minimum(anchor, local.CAP) * check, local.CAP)
    expanded = share(np.minimum(anchor, CAP) * check, CAP)
    extra = np.maximum(expanded - baseline, 0)
    allowance = np.minimum(confirmed, CAP) * check
    improvement = np.minimum(extra, np.maximum(allowance - baseline, 0))
    measured = baseline + improvement
    fraction = improvement / np.maximum(extra, 1e-12)
    shifted = np.roll(fraction.reshape(COUNT, *shape), (2, 2), axis=(-2, -1)).reshape(extra.shape)
    aligned = baseline + share(extra * shifted, CAP - baseline.sum(axis=0))
    return np.stack((baseline, expanded, measured, aligned))


def blend(fits, raw, neutral, shape):
    n, h, w = shape
    y, x, taper = local.delivery()
    scale = max(abs(float(neutral[1])), 1e-10)
    amount = budgets(fits, scale, shape)
    freq = np.stack([p["frequency"] for p in fits])
    wave = 2 * np.pi * (freq[..., 0, None, None] * y + freq[..., 1, None, None] * x)
    phase = np.stack([p["direction"] for p in fits])
    carrier = phase[..., 0, None, None] * np.cos(wave) + phase[..., 1, None, None] * np.sin(wave)
    pieces = carrier.reshape(COUNT, n, h, w, local.NATIVE, local.NATIVE)
    stations = amount.reshape(len(amount), COUNT, n, h, w)
    phases = freq.reshape(COUNT, n, h, w, 2)
    guard = np.stack([p["guard"].reshape(shape) for p in fits])
    allowed = np.stack([p["validated"].reshape(shape) for p in fits])
    pad = local.STRIDE
    dims = (2 * raw.shape[-2] + 2 * pad, 2 * raw.shape[-1] + 2 * pad)
    weight = np.zeros(dims)
    out = np.zeros((len(amount), n, *dims))
    for i in range(h):
        for j in range(w):
            roi = np.s_[i*2*pad:i*2*pad+local.NATIVE, j*2*pad:j*2*pad+local.NATIVE]
            weight[roi] += taper
            q = previous.receiving_gate(phases, allowed, guard[None], i, j)[0]
            piece = pieces[:, :, i, j] * q
            out[..., roi[0], roi[1]] += (stations[..., i, j, None, None] * piece).sum(axis=1) * taper
    valid = np.all((raw > 0.001) & (raw < 0.995), axis=1).repeat(2, -2).repeat(2, -1)
    safe = gaussian_filter(valid.astype(float), (0, 2, 2))
    thumb = (out / np.maximum(1e-10, weight))[..., pad:-pad, pad:-pad] * safe
    return thumb, stations


def fields(d, p, profile):
    raw = d["packed"]
    sensors = [local.observations(raw, p["nominal"][:, 1], profile, k)
               for k in np.flatnonzero(d["colors"] == 1)]
    shape = sensors[0]["shape"]
    neutral = np.linalg.solve(d["matrix"].astype(float), np.ones(3)) / d["wb"]
    folds = [old.data_in_fold(d, profile, i) for i in (0, 1)]
    output, notes = 0.0, []
    for j, fold in enumerate(folds):
        main, prior, weak, power = previous.ranked(fold)
        witness, z = previous.verify(fold, folds[1-j], main, weak)
        fits = [
            fit_station(sensors, ((main, prior), (weak[..., i, :], power[..., i])),
                        old.expand(witness[..., i], shape))
            for i in range(COUNT)
        ]
        move, amplitude = blend(fits, raw, neutral, shape)
        output = output + 0.5 * move
        notes.append({
            "phase": np.stack([v["frequency"].reshape(*shape, 2) for v in fits]),
            "guard": np.stack([v["guard"].reshape(shape) for v in fits]),
            "amplitude": amplitude,
        })
    names = ("fixed", "raised", "directional", "rolled directional")
    return dict(zip(names, output, strict=True)), neutral, notes
