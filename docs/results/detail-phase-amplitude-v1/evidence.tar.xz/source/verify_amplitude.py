"""Verify exact prior rendering and the signed-extra amplitude bounds."""

import numpy as np

from amplitude_phase import fields, previous, local, CAP, HERE

from verify_shortlist import image, PROFILE


if __name__ == "__main__":
    for gap in (False, True):
        d, p = image(gap)
        old, expected_neutral, _ = previous.fields(d, p, PROFILE)
        arms, neutral, details = fields(d, p, PROFILE)
        np.testing.assert_array_equal(neutral, expected_neutral)
        np.testing.assert_allclose(arms["fixed"], old["directional"], atol=1e-16, rtol=0)
        for j in details:
            fixed, raised, measured, shifted = j["amplitude"]
            assert np.all(fixed <= raised + 1e-12)
            assert np.all(fixed <= measured + 1e-12)
            assert np.all(measured <= raised + 1e-12)
            assert np.max(fixed.sum(0)) <= local.CAP + 1e-12
            assert max(np.max(k.sum(0)) for k in (raised, measured, shifted)) <= CAP + 1e-12
        r = np.s_[:, 71:89, 71:89]
        luma = {k: float(np.sqrt(np.mean(v[r]**2))*65535) for k,v in arms.items()}
        print("gap", gap, luma, flush=True)
        if not gap:
            assert luma["directional"] > 2 * luma["fixed"]
            assert luma["directional"] <= luma["raised"] + 1e-9
