"""Bind the amplitude allowance implementation, replay, source audit and rendered crops."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile
from unittest.mock import patch

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_amplitude import HERE, OUT, METHODS, scoring, previous

ROOT = Path.cwd()
ASSET = ROOT / "docs/assets" / HERE.name
RESULT = ROOT / "docs/results" / HERE.name
GROUPS = ("calibration", "prior-held", "held")
RECEIPTS = (
    "plan", "confirmation/plan", "confirmation/held/completed", "audit", "comparisons", "null-controls", "native-adapter", "camera-amplitude",
    *(f"score-{g}" for g in GROUPS), "review-camera", "review-exact", "review-full",
)


def bound(f):
    return reference(f) | {"path": str(f.relative_to(ROOT))}


def same(a, b):
    assert a["sha256"] == b["sha256"]
    assert checked(a).resolve() == checked(b).resolve()


def crop(view, directory):
    src = checked(view["image"])
    target = directory / src.name
    shutil.copyfile(src, target)
    with Image.open(target) as image:
        for entry in view["panels"]:
            x, y, w, h = entry["png_xywh"]
            assert w == h == 160 and x + w <= image.width and y + h <= image.height
    tag = bound(target)
    assert tag["sha256"] == view["image"]["sha256"]
    return view | {"image": tag}


def plot(held):
    rows = [x for x in held["rows"] if x["kind"] == "wire"]
    data = lambda arm, metric, dose: scoring.wire_values(rows, arm, metric, dose).mean()
    contrast = "weak_response_pp"
    treatment = (
        ("raised", "Higher cap", "#0072b2", "-"),
        ("directional", "Measured amplitude allowance", "#d55e00", "-"),
        ("rolled directional", "Shifted allowance", "#7651a3", "--"),
    )
    fig, axes = plt.subplots(1, 2, figsize=(10.7, 4.5), layout="constrained")
    for ax, metric, label in zip(axes,
        ("exact_flat_RMS_DN16", "gap_weak_RMS_DN16"),
        ("Exact-flat error", "Weak-direction error in true gaps"), strict=True):
        ref = [data("nominal", k, 0) for k in (metric, contrast)]
        def point(arm, dose):
            return [data(arm, k, dose) - r for k, r in zip((metric, contrast), ref, strict=True)]
        for key, tag, color, line in treatment:
            x, y = zip(*(point(key, d) for d in np.linspace(0, 1, 41)), strict=True)
            ax.plot(x, y, line, color=color, label=tag)
            if key in METHODS:
                lock = held["policy"]["arms"][key]["locked"]["dose"]
                ax.scatter(*point(key, lock), c=color, edgecolor="white", s=60, zorder=4)
        ax.scatter(*point("fixed", 0), marker="x", color="#222222", label="Earlier fixed cap")
        ax.scatter(*point("rank one", 0), marker="+", color="#426b39", label="Earlier single nomination")
        ax.axvline(0, c="#888888", lw=0.8)
        ax.axhline(0, c="#888888", lw=0.8)
        ax.set_title(label)
        ax.set_xlabel("Change in RMS vs. Local 50k (DN16)")
        ax.set_ylabel("Weak contrast change (percentage points)")
        ax.grid(alpha=0.18)
    axes[0].legend(loc="best", fontsize=9)
    fig.suptitle("New optical fixtures · dots mark strengths fixed on calibration")
    target = ASSET / "phase-response.png"
    fig.savefig(target, dpi=150, facecolor="white")
    plt.close(fig)
    return bound(target)


def run():
    refs = {k: reference(OUT / f"{k}.json") for k in RECEIPTS}
    d = {k: read_json(checked(v)) for k, v in refs.items()}
    plan = d["plan"]
    assert plan["capture_selection"] == refs["confirmation/plan"]
    book = {f"receipts/{k}.json": v for k, v in refs.items()}
    for v in d.values():
        if "driver" in v:
            checked(v["driver"])
    checked(plan["operator"])
    same(d["audit"]["operator"], plan["operator"])
    assert d["comparisons"]["inputs"] == {g: refs[f"score-{g}"] for g in GROUPS}
    assert d["null-controls"]["calibration"] == refs["score-calibration"]
    assert d["null-controls"]["prior_calibration"] == plan["previous_calibration"]
    assert d["audit"]["source_audit"]["source_plan"] == plan["capture_selection"]
    old = read_json(checked(plan["previous_plan"]))
    crossfit = read_json(checked(old["previous_plan"]))
    donor = read_json(checked(crossfit["previous_plan"]))
    narrow = read_json(checked(donor["narrow_plan"]))
    book["receipts/previous-plan.json"] = plan["previous_plan"]
    book["receipts/previous-calibration.json"] = plan["previous_calibration"]
    book["receipts/crossfit-plan.json"] = old["previous_plan"]
    book["receipts/wide-plan.json"] = crossfit["previous_plan"]
    book["receipts/narrow-plan.json"] = donor["narrow_plan"]
    book["receipts/parent-fit.json"] = narrow["parent_fit"]
    book["receipts/parent-locks.json"] = narrow["parent_locks"]
    old_weight = read_json(checked(narrow["parent_fit"]))["checkpoints"]
    reference_score = reference(Path(plan["previous_plan"]["path"]).parent / "score-held.json")
    matching = read_json(checked(reference_score))["summary"]["wire"]
    current = d["score-prior-held"]["summary"]["wire"]
    for metric in matching:
        assert abs(matching[metric]["directional"]["mean"] - current[metric]["fixed"]["mean"]) < 2e-5
    book["receipts/matched-fixed-score.json"] = reference_score
    for k, ref in old_weight.items():
        book[f"controls/{k}.pt"] = ref
    captured = d["confirmation/held/completed"]
    assert captured["plan"] == refs["confirmation/plan"] and captured["count"] == 56
    assert d["audit"]["collection"] == refs["confirmation/held/completed"]
    cases = []
    for i, ref in enumerate(captured["chunks"]):
        part = read_json(checked(ref))
        assert part["plan"] == refs["confirmation/plan"]
        cases.extend(part["rows"])
        book[f"capture/{i:02}.json"] = ref
    for a, b in zip(cases, d["score-held"]["rows"], strict=True):
        assert a["id"] == b["id"]
        same(a["file"], b["proof"]["input"])
    controls = (plan["calibration"], plan["replay"])
    for g, expected in zip(GROUPS, (*controls, refs["confirmation/held/completed"]), strict=True):
        scores = d[f"score-{g}"]
        same(scores["source"], expected)
        assert scores["weights"] == refs["plan"]
        if g != "calibration":
            assert scores["calibration"] == refs["score-calibration"]
        if g != "held":
            book[f"receipts/{g}-source.json"] = expected
    for k in ("camera", "exact", "full"):
        view = d[f"review-{k}"]
        assert view["fit"] == refs["plan"] and view["lock"] == refs["score-calibration"]
    camera_amplitude = d["camera-amplitude"]
    assert camera_amplitude["review"] == refs["native-adapter"]
    assert all(key.startswith("mesh-") for key in camera_amplitude["rows"])
    book["receipts/measured-frequency-source.md"] = camera_amplitude["source"]
    adapter = d["native-adapter"]
    assert adapter["plan"] == refs["plan"] and adapter["operator"] == plan["operator"]
    for k in ("camera", "exact", "full"):
        assert adapter[k] == refs[f"review-{k}"]
    for row in d["review-camera"]["report"]["rows"]:
        key = adapter["rows"][row["id"]]
        assert row["input"] == key["input"] and row["ROI"] == key["global_display_roi"]
    full = d["review-full"]
    assert d["review-exact"]["report"]["reference"] == full["held"] == refs["score-held"]
    assert full["views"]["exact"]["reference"] == refs["score-held"]
    doses = d["review-camera"]["doses"]
    assert doses == d["review-exact"]["doses"] == {
        k: v["locked"]["dose"] for k, v in d["score-calibration"]["policy"]["arms"].items()
    }
    assert full["doses"] == dict.fromkeys(METHODS, 1.0)
    for directory in (RESULT, ASSET, ASSET / "full"):
        directory.mkdir(parents=True, exist_ok=True)
    locked = {k: d[f"review-{k}"]["report"] for k in ("camera", "exact")}
    manifest = {}
    for label, views, dose, directory in (("locked", locked, doses, ASSET),
        ("full", full["views"], full["doses"], ASSET / "full")):
        exact = views["exact"]["rows"]
        cameras = views["camera"]["rows"]
        assert len(exact) == 3 and len(cameras) == 8
        assert sum(len(row["views"]) for row in cameras) == 12
        for row in exact:
            row["views"] = {k: crop(v, directory) for k, v in row["views"].items()}
        for row in cameras:
            row["views"] = [crop(v, directory) for v in row["views"]]
            for v in row["views"]:
                names = {panel["label"] for panel in v["panels"]}
                assert {"ISO100 AHD reference", "Measured amplitude allowance", "Fixed amplitude cap"} <= names
                if row["id"].startswith("mesh-"):
                    assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= names
        manifest[label] = {"doses": dose, "camera": cameras, "exact": exact}
    with patch.object(scoring, "METHODS", METHODS):
        figure = plot(d["score-held"])
    parent = d["confirmation/plan"]
    manifest_file = ASSET / "manifest.json"
    write_json(manifest_file, {
        "parent": parent["parent"], "v120": parent["v120"], "learned_controls": old_weight,
        "operator": plan["operator"], "local_operator": plan["local_operator"], "figure": figure, "views": manifest,
        "camera_windows": adapter["rows"],
    })
    summary = RESULT / "summary.json"
    write_json(summary, {
        "parent": parent["parent"], "locks": doses,
        "scores": {g: d[f"score-{g}"]["summary"] for g in GROUPS},
        "nomination": d["audit"]["summary"],
        "source_audit": d["audit"]["source_audit"],
        "comparisons": d["comparisons"]["results"],
        "null_controls": d["null-controls"]["summary"],
        "camera_amplitude": camera_amplitude["rows"],
        "capture_seconds": captured["seconds"],
        "camera": {key: {r["id"]: r["RGB_RMS_DN16"] for r in data["camera"]}
                   for key, data in manifest.items()},
    })
    for f in HERE.glob("*.py"):
        book[f"source/{f.name}"] = reference(f)
    for k in ("inherited_scorer", "inherited_reviewer", "local_operator", "previous_operator", "wide_operator", "crossfit_operator"):
        book[f"source/{k}.py"] = plan[k]
    book["source/evaluate_shortlist.py"] = reference(Path(previous.__file__))
    book["source/verify_wide.py"] = reference(HERE.with_name("detail-wide-phase-v1") / "verify_wide.py")
    book["source/verify_shortlist.py"] = reference(HERE.with_name("detail-phase-shortlist-v1") / "verify_shortlist.py")
    book["verification/independent-donor.txt"] = reference(OUT / "verification.log")
    for name in ("gfx-qualitative-20231231.json", "gfx-green-mesh-20231231.json"):
        book[f"configs/{name}"] = reference(ROOT / "configs" / name)
    tar = RESULT / "evidence.tar.xz"
    with tarfile.open(tar, "x:xz", preset=4) as archive:
        for k, ref in sorted(book.items()):
            archive.add(checked(ref), arcname=k, recursive=False)
    with tarfile.open(tar) as archive:
        assert set(archive.getnames()) == book.keys()
        for k, ref in book.items():
            with archive.extractfile(k) as h:
                assert file_digest(h, "sha256").hexdigest() == ref["sha256"], k
    write_json(RESULT / "publication.json", {
        "archive": bound(tar), "summary": bound(summary), "manifest": bound(manifest_file),
        "members": book,
        "previous_evidence": bound(ROOT / "docs/results/detail-phase-shortlist-v1/evidence.tar.xz"),
    })
    print(bound(tar), flush=True)


if __name__ == "__main__":
    run()
