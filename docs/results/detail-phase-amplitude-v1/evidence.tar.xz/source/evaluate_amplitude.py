"""Compare fixed and measured amplitude above the same validated shortlist."""

from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

import amplitude_phase as operator
import evaluate_shortlist as previous
import score_wire_gate as scoring
import review_wire_gate as review

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
OLDER = previous.OUT
ROUTING = previous.previous.previous.previous
METHODS = ("raised", "directional")
LABELS = {
    "rank one": "Validated single nomination",
    "fixed": "Fixed amplitude cap",
    "raised": "Higher amplitude cap",
    "directional": "Measured amplitude allowance",
}
ORDER = ("nominal", "rank one", "fixed", *METHODS)


def models():
    _, nets = previous.models()
    stamp = read_json(checked(reference(OLDER / "score-calibration.json")))
    nets["fixed_strength"] = stamp["policy"]["arms"]["directional"]["locked"]["dose"]
    return reference(OUT / "plan.json"), nets


def prepare(row, d, p, nets):
    nominal = p["nominal"]
    controls = {"nominal": nominal}
    if "v120" in p:
        controls["v120"] = p["v120"]
    if "local_ROI" in row:
        known, _ = ROUTING.prepare(row, d, p, nets)
        controls.update({k: known[k] for k in ("router", "parent phase")})
    before, neutral, _ = operator.old.fields(d, p, row["profile"])
    controls["rank one"] = (nominal + nets["rank_one_strength"] * before["directional"][:, None] *
                            neutral[None, :, None, None]).astype(nominal.dtype)
    fields, direction, _ = operator.fields(d, p, row["profile"])
    multiplier = direction[None, :, None, None]
    controls["fixed"] = (nominal + nets["fixed_strength"] *
                         fields.pop("fixed")[:, None] * multiplier).astype(nominal.dtype)
    return controls, {k: v[:, None] * multiplier for k, v in fields.items()}


def stage():
    limits = scoring.WIRE_LIMITS | {"gap_continuing_strong_RMS_DN16": ROUTING.prior.CONTINUING_LIMIT}
    official = {
        "calibration": OLDER / "calibration",
        "prior-held": OLDER / "held",
        "held": OUT / "confirmation/held",
    }
    for k, target in official.items():
        alias = OUT / k
        if not alias.exists() and not alias.is_symlink():
            alias.symlink_to(target, target_is_directory=True)
        assert alias.resolve() == target.resolve()
    stamp = OUT / "plan.json"
    if not stamp.exists():
        write_json(stamp, {
            "driver": reference(Path(__file__)), "operator": reference(Path(operator.__file__)),
            "previous_operator": reference(Path(operator.previous.__file__)),
            "crossfit_operator": reference(Path(operator.old.__file__)),
            "wide_operator": reference(Path(operator.wide.__file__)),
            "local_operator": reference(Path(operator.local.__file__)),
            "capture_selection": reference(OUT / "confirmation/plan.json"),
            "previous_plan": reference(OLDER / "plan.json"),
            "previous_calibration": reference(OLDER / "score-calibration.json"),
            "calibration": reference(official["calibration"] / "completed.json"),
            "replay": reference(official["prior-held"] / "completed.json"),
            "inherited_scorer": reference(Path(scoring.__file__)),
            "inherited_reviewer": reference(Path(review.__file__)),
            "cap_dn16": operator.CAP * 65535, "lower_margin_sd": operator.LOWER_MARGIN,
            "methods": METHODS, "limits": limits,
            "scope": "Actual unchanged nomination and spatial guards. Fix global strengths on the earlier calibration before confirmation.",
        })
    return limits


def run(mode):
    limits = stage()
    with ExitStack() as stack:
        for mod, key, value in (
            (scoring, "OUT", OUT),
            (scoring, "METHODS", METHODS),
            (scoring, "load_models", models),
            (scoring, "prepare", prepare),
            (scoring, "WIRE_LIMITS", limits),
            (review, "OUT", OUT),
            (review, "load_models", models),
            (review, "prepare", prepare),
            (review, "ORDER", ORDER),
            (review, "DISPLAY", review.DISPLAY | LABELS),
        ):
            stack.enter_context(patch.object(mod, key, value))
        if mode == "review":
            review.run()
        else:
            scoring.run(mode)


if __name__ == "__main__":
    run(sys.argv[1])
