"""Exercise the real reconstruction loss/gradients for extreme admitted bridge profiles."""

import hashlib
from pathlib import Path

import torch
import yaml
from prepare_photo_epoch_order import READER_KEYS
from torch.utils.data import default_collate

from demosaic import train as training
from demosaic.data import CleanDataset
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.losses import reconstruction_loss
from demosaic.precision import ieee_fp32
from demosaic.raw_clean import RawCleanDataset

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"full-corpus-long86k-native-v1"


def main():
    torch.set_num_threads(2)
    plan=read_json(ROOT/"plan.json")
    cfg=yaml.safe_load(checked(plan["configs"]["bridge"]).read_text())
    preflight=read_json(ROOT/"preflight-data.json")
    father=read_json(OLD/"plan.json")["models"]["scale-long86k"]["checkpoint"]
    model,state=load_checkpoint(checked(father),"cpu")
    assert state["step"] == 86000 and state["loaded_sha256"]==father["sha256"]
    del state
    model.train()
    ds={
        "commons":CleanDataset(
            cfg["manifest"],**{k:cfg[k] for k in READER_KEYS if k in cfg},
            photo_epoch_order=cfg["photo_epoch_order"],photo_epoch_order_sha256=cfg["photo_epoch_order_sha256"],
            trace_sources=True,
        ),
        "native":RawCleanDataset(
            cfg["raw_clean_manifest"],patch_size=cfg["patch_size"],seed=cfg["seed"],
            optical_blur_probability=cfg["raw_clean_optical_blur_probability"],
            augmentation_downsample=cfg["raw_clean_augmentation_downsample"],
        ),
    }
    extremes=[]
    for rec in preflight["per_step"]:
        if not rec["changed_indices"]:
            continue
        step,domain=rec["step"],rec["domain"]
        msg=f"near-adc-training-v1:{cfg['seed']}:{step}:{domain}:profile".encode()
        seed=int.from_bytes(hashlib.sha256(msg).digest()[:8],"little")%2**63
        samples=torch.rand(16,3,dtype=torch.float64,generator=torch.Generator().manual_seed(seed))
        extremes.extend((float(samples[i,1]),float(samples[i,2]),rec,i) for i in rec["changed_indices"])
    selected=[min(extremes,key=lambda k:k[0]),max(extremes,key=lambda k:k[1])]
    results=[]
    for _,_,rec,index in selected:
        step,domain=rec["step"],rec["domain"]
        clean=default_collate([ds[domain][j] for j in range((step-1)*16,step*16)])
        batch=training.prepare_training_batch(step,domain,clean,model=model,device="cpu",config=cfg,seed=cfg["seed"])
        assert training.batch_fingerprint(batch)==rec["bridge_batch"]
        item={k:v[index:index+1] for k,v in batch.items()}
        model.zero_grad(set_to_none=True)
        model.set_noise(item["shot"],item["read"])
        with ieee_fp32():
            rgb,aux=model(*(item[k] for k in ("packed","variance","colors","wb","matrix")),auxiliary=True)
            loss,terms=reconstruction_loss(
                rgb,item,aux,physical_fp32=model.config.physical_fp32,
                normalized_sensor_weight=cfg["normalized_sensor_weight"],
                multiscale_sensor_weight=cfg["multiscale_sensor_weight"],
                objective=cfg["reconstruction_objective"],camera_supervision=cfg["camera_supervision"],
                reference_interval_weight=cfg["reference_interval_weight"],
                reconstruction_charbonnier_epsilon=cfg["reconstruction_charbonnier_epsilon"],
                gradient_charbonnier_epsilon=cfg["gradient_charbonnier_epsilon"],
                normalized_band_weight=cfg["normalized_band_weight"],
            )
            assert torch.isfinite(rgb).all() and torch.isfinite(loss)
            loss.backward()
        names=[(n,p.grad) for n,p in model.named_parameters() if p.grad is not None]
        assert names and all(torch.isfinite(g).all() for _,g in names)
        assert all(p.grad is None for p in model.context.backbone.parameters())
        shot,read=item["shot"].item(),item["read"].item()
        results.append({"step":step,"index":index,"domain":domain,"loss":float(loss.detach()),
                        "shot":shot,"read":read,"read_electrons":read**.5/shot,
                        "nonzero_gradients":sum(bool(g.count_nonzero()) for _,g in names),
                        "finite_gradient_tensors":len(names),
                        "actual_training_batch_sha256":rec["bridge_batch"]})
        print(results[-1],flush=True)
    write_json(ROOT/"gradient-smoke.json",{
        "source":reference(__file__),"weights":father,"plan":reference(ROOT/"plan.json"),
        "records":results,"optimizer_updates":0,"inference_only":False,
        "scope":"Full reconstruction loss/backward on two single simulated training samples "
                "with recorded 86k EMA. CPU diagnostic, separate from the 100k scheduled runs.",
    })


if __name__=="__main__":
    main()
