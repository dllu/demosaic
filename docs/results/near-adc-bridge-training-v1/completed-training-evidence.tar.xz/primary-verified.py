"""Schedule both trained near-ADC branches on the fixed primary panel."""

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import exclusive_run, owner_live

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "full-corpus-long100k-review-v1/primary/plan.json"
CONTROL = ROOT.parent / "full-corpus-control20k-review-queue-v1/primary20k"
OUT = ROOT / "primary-verified"
AFFINITY = [8, 9, 10, 11]
ARMS = {"bridge-control": "control", "bridge-trained": "bridge"}


def run_driver(driver, plan, work, name):
    env = dict(os.environ, PYTHONPATH=f"{work}/src:{work}/scripts", CUDA_VISIBLE_DEVICES="",
               OMP_NUM_THREADS="4", OPENBLAS_NUM_THREADS="1", PYTHONUNBUFFERED="1")
    command = [sys.executable, str(driver), str(plan)]
    with (OUT/f"{name}.log").open("xb") as stream:
        process = subprocess.Popen(command, env=env, stdout=stream, stderr=subprocess.STDOUT)
        write_json(OUT/f"{name}-launch.json", {
            "pid": process.pid, "created": psutil.Process(process.pid).create_time(),
            "command": command, "plan": reference(plan),
        })
        status = process.wait()
    write_json(OUT/f"{name}-exit.json", {"returncode": status})
    if status:
        raise RuntimeError(f"Primary {name} failed with {status}")


def main():
    OUT.mkdir()
    with exclusive_run(OUT):
        control_owner = read_json(CONTROL/"collection/owner.json")
        source = read_json(SOURCE)
        verify_plan(source)
        assert source["CPU_threads"] == len(AFFINITY) and set(AFFINITY) <= os.sched_getaffinity(0)
        unlock = reference(ROOT/"training-audit-recovery.json")
        recovery = read_json(checked(unlock))
        audit = checked(recovery["completion"])
        training = read_json(audit)
        assert training["trained"] and training["source_and_crop_trace_bitexact"]
        assert training["parent"]["checkpoint"] == source["models"]["scale-long100k"]["checkpoint"]
        out = {}
        for label, arm in ARMS.items():
            binding = training["arms"][arm]
            completion = read_json(checked(binding))
            retained = read_json(Path(binding["path"]).parent/"step000800-receipt.json")
            assert completion["steps"] == retained["global_step"] == retained["LR_horizon"] == 800
            assert completion["checkpoint"]["sha256"] == retained["checkpoint"]["sha256"]
            out[label] = {"checkpoint": retained["checkpoint"], "step": 800, "weights": "EMA"}
        write_json(OUT/"admission.json", {
            "models":out, "source":reference(__file__), "training":reference(audit),
            "source_plan":reference(SOURCE), "preheat_after":control_owner,
            "scope":"Same CPU IEEE FP32 canonical 3162 batches, both branches, shared frozen local DINO."
        })
        drive = checked(source["driver"])
        work = Path(source["work"])
        body = {k: v for k, v in source.items() if k != "preflight"}
        body.update(models=out, parent_label="bridge-control", CPU_affinity=AFFINITY,
                    inputs=[source["canonical_inputs"], reference(SOURCE), reference(audit),
                            reference(OUT/"admission.json"), *[r["checkpoint"] for r in out.values()]],
                    scope="Canonical known, unseen and full427 photo comparison of matched training branches."
                          " CPU IEEE FP32 with four threads, fixed observations and shared frozen DINO.")
        owner = {k: control_owner[k] for k in ("pid",)}
        owner["created"] = control_owner["create_time"]
        while owner_live(owner):
            time.sleep(30)
        previous = read_json(CONTROL/"collection/result.json")
        assert previous["all_complete"] and previous["cases"]==3162
        while (psutil.virtual_memory().available < source["minimum_start_RAM_GiB"] * 2**30
               or shutil.disk_usage(OUT).free < source["minimum_disk_GiB"] * 2**30):
            time.sleep(30)
        trial = OUT/"preflight"
        trial.mkdir()
        write_json(trial/"plan.json", body | {"root":str(trial),"kind":"preflight","maximum_seconds":1800})
        run_driver(drive, trial/"plan.json", work, "preflight")
        receipt = reference(trial/"collection/result.json")
        checked_trial = read_json(checked(receipt))
        assert checked_trial["all_complete"] and checked_trial["cases"] == 3 and checked_trial["models"] == out
        full = OUT/"full"
        full.mkdir()
        write_json(full/"plan.json", body | {"root":str(full), "kind":"full", "maximum_seconds":345600,
                                           "inputs":[*body["inputs"],receipt], "preflight":receipt})
        run_driver(drive, full/"plan.json", work, "full")
        completion = read_json(full/"collection/result.json")
        assert completion["all_complete"] and completion["cases"] == 3162
        write_json(OUT/"completed.json", {"collection":reference(full/"collection/result.json"),
                   "plan":reference(full/"plan.json"),"V120_and_parent_join_pending":True})


if __name__ == "__main__":
    main()
