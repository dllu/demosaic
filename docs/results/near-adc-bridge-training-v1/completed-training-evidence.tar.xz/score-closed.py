"""Score the existing faint-photo and null protocols on the matched 800-update arms."""

import argparse
import os
import sys
import time
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np

from demosaic.archive_metrics import linear_rgb, noisy_malvar, photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live
from report_full_faint_photo_panel import DN16, LUMA, band, band_sums, blocks, original_masks, source_balance
from report_scene_wave_guides import native_board

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "noisy-cfa-residual-v1"
sys.path.insert(0,str(BASE))
from probe import inputs_and_variants

EVAL = ROOT / "evaluation-adopted"
PHOTOS = ("weak-photo-0", "weak-photo-1")
NULLS = ("flat-and-edge", "reserved-flats")
METHODS = ("scale-long100k", "bridge-control", "bridge-trained")
DISPLAYS = ("100k parent EMA", "800 control EMA", "800 near-ADC EMA")
BORDER = np.s_[..., 48:208, 48:208]
y, x = np.mgrid[48:208, 48:208]
DISTANCE = np.abs(x - 121.7 - 0.21 * (y - 128))


def score_photo(observation, inputs, predictions):
    with np.load(checked(observation["target"])) as saved:
        target, original = (saved[k] for k in ("target", "original_target"))
    masks = original_masks(original, inputs)
    reference_rgb = linear_rgb(target, inputs)
    target_band = band(np.einsum("c,bchw->bhw", LUMA, reference_rgb))
    for model, value in predictions.items():
        rgb = linear_rgb(value, inputs)
        estimate = band(np.einsum("c,bchw->bhw", LUMA, rgb))
        photometric = photometry(value, inputs | {"target": target})
        error_blocks = blocks(rgb - reference_rgb)
        mottle = np.sqrt(np.mean(error_blocks.mean((-2, -1)) ** 2, axis=(1, 2)))
        for i, fields in enumerate(band_sums(estimate, target_band, masks)):
            yield {
                "source": observation["source_ids"][i], "CFA": observation["pattern"],
                "profile": observation["noise"]["name"], "model": model, "policy": "raw",
                "band_sums": fields, "PSNR_sRGB": float(photometric["srgb_psnr"][i]),
                "block_mean_error_DN16": float(DN16 * mottle[i]),
            }


def score_null(observation, target, predictions, panel):
    for model, value in predictions.items():
        error = DN16 * (value.astype(float) - target)[BORDER]
        for name, cell in zip(observation["source_ids"], error, strict=True):
            mean_color = cell.mean((-2, -1), keepdims=True)
            centered = cell - mean_color
            is_edge = name == "slanted-edge"
            yield {
                "panel": panel, "profile": observation["noise"]["name"],
                "source": name, "CFA": observation["pattern"], "model": model,
                "worst_channel_abs_bias_DN16": float(np.abs(mean_color).max()),
                "spatial_centered_RMS_DN16": float(np.sqrt(np.mean(centered ** 2))),
                "quiet_RMS_DN16": float(np.sqrt(np.mean(cell[:, DISTANCE >= 24] ** 2))) if is_edge else None,
                "boundary_RMS_DN16": float(np.sqrt(np.mean(cell[:, DISTANCE <= 6] ** 2))) if is_edge else None,
            }


def render(out, observation, inputs, predictions, models, target, source, contrast=1):
    i = observation["source_ids"].index(source)
    local = {k: inputs[k][i:i + 1] for k in ("packed", "colors", "wb", "matrix")}
    return native_board(
        out, f"{observation['noise']['name']}-{source}-contrast{contrast}",
        [noisy_malvar(local)[0], *(predictions[m][i] for m in METHODS), target[i]],
        local, {"source": source, "models": models, "observation": observation},
        labels=("Noisy Malvar", *DISPLAYS, "Exact constructed GT"), triplet_indices=(0, 3, 4),
        exposure=1, contrast=contrast,
    )


def photo_summary(rows):
    profiles = defaultdict(list)
    for row in rows:
        profiles[row["profile"]].append(row)
    summary=[]
    for profile, selected in sorted(profiles.items()):
        assert len(selected) == 16 * 4 * 3
        assert len({r["source"] for r in selected}) == 16
        bands = source_balance(selected)
        for model in METHODS:
            subset = [r for r in selected if r["model"] == model]
            summary.append({
                "profile": profile, "model": model,
                **{field: mean(r[field] for r in subset) for field in ("PSNR_sRGB", "block_mean_error_DN16")},
                "bands": [r for r in bands if r["model"] == model],
            })
    return summary


def null_summary(rows):
    groups=defaultdict(list)
    for row in rows:
        groups[row["panel"], row["profile"], row["model"]].append(row)
    summary=[]
    for (panel, profile, model), group in sorted(groups.items()):
        assert len(group)==16
        flats=[r for r in group if r["source"]!="slanted-edge"]
        edge=[r for r in group if r["source"]=="slanted-edge"]
        fields=("worst_channel_abs_bias_DN16","spatial_centered_RMS_DN16")
        summary.append({
            "panel":panel,"profile":profile,"model":model,
            **{field: max(flats,key=lambda r:r[field]) for field in fields},
            "edge_means": {f:mean(r[f] for r in edge) for f in ("quiet_RMS_DN16","boundary_RMS_DN16")} if edge else {},
        })
    return summary


def qualify():
    prior = read_json(BASE / "review/photos.json")
    expected = {(r["profile"], r["source"], r["CFA"], r["model"]): r
                for batch in prior["observations"].values() for r in batch if r["policy"]=="raw"}
    actual = {}
    for label in ("heldout-0", "heldout-1"):
        for observation, inputs, predictions, _ in inputs_and_variants(BASE / label):
            for row in score_photo(observation, inputs, predictions):
                actual[row["profile"],row["source"],row["CFA"],row["model"]]=row
    assert actual == expected and len(actual) == 512
    prior = read_json(BASE / "nulls-review/result.json")
    expected = {(r["profile"], r["source"], r["CFA"], r["model"]): r
                for r in prior["rows"] if r["policy"]=="raw"}
    null_rows=[]
    for observation, inputs, predictions, _ in inputs_and_variants(BASE / "nulls"):
        with np.load(checked(observation["target"])) as f:
            target=f["target"]
        null_rows.extend(score_null(observation,target,predictions,"flat-and-edge"))
    assert len(null_rows)==len(expected)==128
    for r in null_rows:
        e=expected[r["profile"],r["source"],r["CFA"],r["model"]]
        assert all(r[k]==e[k] for k in ("worst_channel_abs_bias_DN16",
                    "spatial_centered_RMS_DN16","quiet_RMS_DN16","boundary_RMS_DN16"))
    print("Exact replay of 512 saved photo rows and 128 saved flat and edge rows.")


def run():
    config=ROOT/"review-declaration-adopted.json"
    declaration=read_json(config)
    watcher=read_json(ROOT/"evaluation-waiter-adopted-launch.json")
    bindings={}
    for panel in declaration["near_panels"]:
        name=panel["label"]
        path=EVAL/name/"collection/result.json"
        while not path.is_file():
            if not owner_live(watcher):
                raise RuntimeError(f"Evaluation worker exited before {name} was written")
            time.sleep(8)
        bindings[name]=reference(path)
    out=EVAL/"targeted-scores"
    out.mkdir()
    photo_rows, null_rows, boards=[], [], []
    sources=sorted({s for p in declaration["near_panels"][:2] for r in p["plans"]
                    for o in read_json(checked(r))["observations"] for s in o["source_ids"]})
    assert len(sources)==16
    for panel in PHOTOS + NULLS:
        for observation, inputs, predictions, models in inputs_and_variants(EVAL/panel):
            assert set(predictions)==set(METHODS)
            with np.load(checked(observation["target"])) as f:
                target=f["target"]
            profile=observation["noise"]["name"]
            is_rggb=observation["pattern"]=="RGGB"
            if panel in PHOTOS:
                photo_rows.extend(score_photo(observation,inputs,predictions))
                if is_rggb and profile in ("small-positive","iso6400-prior"):
                    for source in observation["source_ids"]:
                        if source not in sources[:2]:
                            continue
                        contrast=20 if profile=="small-positive" else 4
                        boards.append(render(out,observation,inputs,predictions,models,target,source,contrast))
                        if profile=="small-positive":
                            boards.append(render(out,observation,inputs,predictions,models,target,source))
            else:
                null_rows.extend(score_null(observation,target,predictions,panel))
                choices={("flat-and-edge","intermediate"):("slanted-edge",),
                         ("reserved-flats","small-positive"):("cyan","magenta"),
                         ("reserved-flats","intermediate"):("magenta",)}
                if is_rggb:
                    for source in choices.get((panel,profile),()):
                        boards.append(render(out,observation,inputs,predictions,models,target,source))
    assert len(photo_rows)==768 and len(null_rows)==288 and len(boards)==10
    summary=photo_summary(photo_rows)
    write_json(out/"report.json",{
        "source":reference(__file__),"plan":reference(config),"collections":bindings,
        "photo_rows":photo_rows,"null_rows":null_rows,"photos":summary,
        "nulls":null_summary(null_rows),"native_boards":boards,"actual_native_viewing":False,
        "scope":"Raw EMA only. Same archived physical draws across all three checkpoints. Source-balanced fine-band statistics and separate low-frequency block-mean error. No GFX pixelwise score.",
    })
    for row in summary:
        weak=next((b for b in row["bands"] if b["band"]=="0"),{})
        print(row["profile"],row["model"],row["PSNR_sRGB"],weak.get("equal_source_RMS_DN16"))


if __name__=="__main__":
    os.sched_setaffinity(0,[18])
    p=argparse.ArgumentParser()
    p.add_argument("--qualify",action="store_true")
    if p.parse_args().qualify:
        qualify()
    else:
        run()
