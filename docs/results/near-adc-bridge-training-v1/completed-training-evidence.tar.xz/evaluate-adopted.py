"""Evaluate both trained branches on fixed native and noise-gap panels."""

import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
EXPERIMENTS=ROOT.parent
ORIGINAL=EXPERIMENTS/"noisy-cfa-residual-v1"
PRIOR=EXPERIMENTS/"full-corpus-long86k-native-v1"
EVAL=ROOT/"evaluation-adopted"
BRANCHES=("bridge-control","bridge-trained")


def wait(path, owner):
    deadline=time.monotonic()+6*3600
    while not path.is_file():
        assert owner_live(owner)
        if time.monotonic()>deadline:
            raise TimeoutError(f"Evaluation input still pending: {path}")
        time.sleep(10)
    return reference(path)


def run_script(name, path, argument, work):
    env=dict(
        os.environ, CUDA_VISIBLE_DEVICES="",PYTHONPATH=f"{work}/src:{work}/scripts",
        OMP_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",PYTHONUNBUFFERED="1",
    )
    with (EVAL/f"{name}.log").open("xb") as f:
        cmd=[sys.executable,str(path),str(argument)]
        p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
        write_json(
            EVAL/f"{name}-launch.json", {"pid":p.pid,"created":psutil.Process(p.pid).create_time(),
                                        "command":cmd, "source":reference(path)},
        )
        code=p.wait()
    write_json(EVAL/f"{name}-exit.json",{"returncode":code})
    if code:
        raise RuntimeError(f"{name} exited with {code}; see its log")


def models(training):
    output={}
    for branch,arm in zip(BRANCHES,("control","bridge"),strict=True):
        final=read_json(checked(training["arms"][arm]))
        state=read_json(Path(training["arms"][arm]["path"]).parent/"step000800-receipt.json")
        assert final["steps"]==state["global_step"]==state["LR_horizon"]==800
        assert final["checkpoint"]["sha256"]==state["checkpoint"]["sha256"]
        output[branch]={"checkpoint":state["checkpoint"],"step":800,"weights":"EMA",
                        "display_label":branch,"retained_progress":True,"training_horizon":800}
    output["scale-long100k"]={
        "checkpoint":training["parent"]["checkpoint"],"step":100000,"weights":"EMA",
        "display_label":"Long schedule 100k EMA","retained_progress":True,"training_horizon":100000,
    }
    return output


def collect(name, parents, specs, cpus, audit, prep):
    first=read_json(checked(parents[0]))
    collector=checked(first["collector"])
    work=Path(first["work"])
    cases=[]
    for path in parents:
        records=read_json(checked(path))
        assert records["DINO_sha256"]==first["DINO_sha256"]
        assert records["collector"]["sha256"]==first["collector"]["sha256"]
        cases.extend(records["observations"])
    output=EVAL/name
    output.mkdir()
    plan=first | {
        "root":str(output),"models":specs,"observations":cases,
        "CPU_affinity":cpus,"CPU_threads":len(cpus),"maximum_seconds":14400,
        "planned_root_calls":len(cases)*len(specs),"planned_DINO_executions":len(cases),
        "inputs":[*parents,audit,prep,*[r["checkpoint"] for r in specs.values()]],
        "scope":"Prospective bridge-vs-control EMA comparison on fixed physical observations. "
                "Identical CPU/FP32 model execution and shared frozen DINO feature checks.",
    }
    assert len(cases)==len({o["id"] for o in cases})
    path=output/"plan.json"
    write_json(path,plan)
    run_script(name,collector,path,work)
    closure=read_json(output/"collection/result.json")
    assert closure["plan"]==reference(path)
    assert len(closure["records"])==len(cases)
    return output,closure


def adopted_native(prep, audit, specs):
    src=reference(PRIOR/"plan.json")
    branch_specs={k:specs[k] for k in BRANCHES}
    root,new=collect("native-new",[src],branch_specs,[6,7],audit,prep)
    ep=EXPERIMENTS/"full-corpus-long100k-review-v1"
    saved=wait(ep/"native/collection/result.json",read_json(ep/"launch.json")|{"created":read_json(ep/"launch.json")["create_time"]})
    baseline=read_json(checked(saved))
    plan=read_json(checked(new["plan"]))
    previous_plan=read_json(checked(baseline["plan"]))
    assert plan["observations"]==previous_plan["observations"] and len(plan["observations"])==110
    assert baseline["models"]["scale-long100k"]["checkpoint"]==specs["scale-long100k"]["checkpoint"]
    out=EVAL/"native"
    out.mkdir()
    collection=out/"collection"
    collection.mkdir()
    products=[]
    for i,(fresh,old,o) in enumerate(zip(new["records"],baseline["records"],plan["observations"],strict=True)):
        r=read_json(checked(fresh))
        q=read_json(checked(old))
        assert r["id"]==q["id"]==o["id"] and r["input_fingerprints"]==q["input_fingerprints"]==o["input_fingerprints"]
        controls=[v for v in q["variants"] if v["label"] in ("V120","scale-long100k")]
        assert len(controls)==2
        for v in controls:
            checked(v["prediction"])
            assert v["checkpoint"]==baseline["models"][v["label"]]["checkpoint"]
        item=collection/f"case-{i:03d}.json"
        write_json(item,r|{"variants":[*controls,*r["variants"]]})
        products.append(reference(item))
    combined=plan|{
        "root":str(out),"models":{
            **{k:baseline["models"][k] for k in ("V120","scale-long100k")},**branch_specs,
        },
        "parent_label":"V120","triplet_model":"bridge-trained",
        "inputs":[*plan["inputs"],saved,new["plan"]],
    }
    cfg=out/"plan.json"
    write_json(cfg,combined)
    write_json(collection/"result.json",{
        "plan":reference(cfg),"models":combined["models"],"records":products,
        "new":reference(root/"collection/result.json"),"adopted":saved,"confirmed_controls":220,
    })
    work=Path(plan["work"])
    run_script("native-boards",work/"scripts/report_full_corpus_checkpoint_review.py",out,work)
    write_json(EVAL/"native-boards.json",{"report":reference(out/"report/result.json"),"viewed":False})


def main():
    declared=read_json(ROOT/"review-declaration-adopted.json")
    assert declared["source"]==reference(__file__)
    EVAL.mkdir()
    launch=read_json(checked(declared["training_launch"]))
    audit=wait(ROOT/"training-audit.json",launch)
    result=read_json(checked(audit))
    assert result["trained"] and result["source_and_crop_trace_bitexact"]
    specs=models(result)
    prep=reference(ROOT/"review-declaration-adopted.json")
    with ThreadPoolExecutor(max_workers=2) as pool:
        a=pool.submit(adopted_native,prep,audit,specs)
        for item in declared["near_panels"]:
            collect(item["label"],item["plans"],specs,[18,19],audit,prep)
        a.result()
    write_json(EVAL/"completed.json",{
        "audit":audit,"plan":prep,"native":reference(EVAL/"native-boards.json"),
        "near":{p["label"]:reference(EVAL/p["label"]/"collection/result.json") for p in declared["near_panels"]},
        "native_viewing_complete":False,"full_primary_pending":True,
    })


if __name__=="__main__":
    main()
