"""Validate and publish the actual matched 800-update training endpoints."""

import shutil
import tarfile
from pathlib import Path

import torch
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results/near-adc-bridge-training-v1")
STEPS = 800


def verify_arm(plan, completion_path, arm):
    terminal = read_json(completion_path)
    phase_path = checked(terminal["phase"])
    phase = read_json(phase_path)
    run = completion_path.parent
    receipt = run/"step000800-receipt.json"
    retained = read_json(receipt)
    assert retained["checkpoint"]["sha256"] == terminal["checkpoint"]["sha256"]
    checkpoint = checked(retained["checkpoint"])
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    assert state["step"] == state["config"]["steps"] == STEPS
    assert len(state["model"]) == len(state["ema"]) == 91
    assert len(state["optimizer"]["state"]) == 89
    assert all(p["step"] == STEPS for p in state["optimizer"]["state"].values())
    assert all(torch.isfinite(t).all() for part in ("model","ema") for t in state[part].values())
    assert all(torch.isfinite(t).all() for p in state["optimizer"]["state"].values()
               for t in p.values() if isinstance(t, torch.Tensor))
    assert state["python_rng"] and state["cuda_rng"] and state["torch_rng"].numel()
    assert state["config"]["initialized_from"]["sha256"] == plan["parent"]["sha256"]
    assert state["config"]["near_adc_bridge_fraction"] == (0 if arm=="control" else 0.5)
    observed = yaml.safe_load((run/"config.yaml").read_text())
    assert observed["near_adc_bridge_fraction"] == state["config"]["near_adc_bridge_fraction"]
    assert phase["examples"] == 12800 and not phase["optimizer_EMA_RNG_preserved_on_resume"]
    assert phase["source_crop_observations"]["sha256"]
    support = {"completed.json":completion_path, "phase.json":phase_path, "retained.json":receipt,
               "config.yaml":run/"config.yaml", "training-metrics.jsonl":run/"metrics.jsonl",
               "source-crop-observations.jsonl":checked(phase["source_crop_observations"])}
    for binding in phase["corruption_condition_files"]:
        path = checked(binding)
        support[path.name] = path
    return {
        "checkpoint":retained["checkpoint"], "step":STEPS, "weights_for_review":"EMA",
        "raw_tensors":91, "EMA_tensors":91, "optimizer_states":89, "CUDA_CPU_Python_rng":True,
        "distinct_photographic_sources":phase["distinct_photo_sources"], "examples":12800,
        "training_loop_seconds":phase["seconds"], "domain_updates":phase["domains"],
        "production_plan":phase["production_plan"], "completion":reference(completion_path),
    }, {f"{arm}/{name}":path for name,path in support.items()}


def main():
    torch.set_num_threads(2)
    audit_path=ROOT/"training-audit.json"
    dataset=read_json(audit_path)
    assert dataset["trained"] and dataset["source_and_crop_trace_bitexact"] and dataset["camera_metadata_bitexact"]
    plan=read_json(checked(dataset["execution_plan"]))
    assets={}
    rows={}
    for arm in ("control","bridge"):
        rows[arm], data=verify_arm(plan,checked(dataset["arms"][arm]),arm)
        assets.update(data)
    assert rows["control"]["distinct_photographic_sources"] == rows["bridge"]["distinct_photographic_sources"]
    assets.update({name:ROOT/name for name in (
        "training-audit.json","retry-execution-plan.json","control-adoption.json","adopted-control-completion.json",
        "train-control-retry.log","train-bridge-retry.log","train-bridge-adoption-launch.json","train-bridge-adoption-exit.json",
        "dispatch-adopt.py","score-closed.py","score-qualification.log","score-closed-launch.json",
        "evaluate-adopted.py","review-declaration-adopted.json","evaluation-waiter-adopted-launch.json",
        "primary-when-ready.py","primary-when-ready-launch.json","publish-trained.py",
        "training-audit-recovery.json","bind-completed-training.py","dispatch-adopt.log",
        "evaluation-waiter-adopted.log","primary-when-ready.log","score-closed.log",
        "audit-native-when-ready.log","evaluate-verified.py","review-declaration-verified.json",
        "evaluation-waiter-verified-launch.json","score-verified.py","score-verified-launch.json",
        "audit-native-verified.py","audit-native-verified-launch.json",
        "independent-native-audit-verified.py","primary-verified.py","primary-verified-launch.json",
    )})
    path=OUT/"completed-training-evidence.tar.xz"
    with tarfile.open(path,"x:xz",preset=6) as arch:
        for name, source in sorted(assets.items()):
            info=arch.gettarinfo(source,arcname=name)
            info.mtime=info.uid=info.gid=0
            info.uname=info.gname=""
            with source.open("rb") as stream:
                arch.addfile(info,stream)
    with tarfile.open(path) as arch:
        assert all(arch.extractfile(name).read()==source.read_bytes() for name,source in assets.items())
    shutil.copyfile(audit_path,OUT/"training-audit.json")
    write_json(OUT/"completed-training.json",{
        "driver":reference(__file__),"audit":reference(OUT/"training-audit.json"),"models":rows,
        "parent":dataset["parent"],"evidence":reference(path),
        "members":[{"member":name,"sha256":reference(source)["sha256"]} for name,source in sorted(assets.items())],
        "trained":True,"numerical_quality_review_complete":False,"native_viewing_complete":False,
    })
    print(rows)
    print({k:dataset[k] for k in ("changed_ADC_slots","changed_by_domain","read_e_min_max","full_signal_sigma_DN16_min_max")})


if __name__=="__main__":
    main()
