"""Verify the full native board and score archive before viewing."""

import os
import subprocess
import sys
import time
from pathlib import Path

from demosaic.experiments.artifacts import read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
EVAL=ROOT/"evaluation-verified"
owner=read_json(ROOT/"evaluation-waiter-verified-launch.json")
finish=EVAL/"native-boards.json"
while not finish.is_file():
    if not owner_live(owner):
        raise RuntimeError("Native evaluator stopped before reporting")
    time.sleep(8)
driver=ROOT/"independent-native-audit-verified.py"
subprocess.run([sys.executable,str(driver)],env=dict(os.environ,CUDA_VISIBLE_DEVICES=""),check=True)
result=EVAL/"native/independent-audit-v1/result.json"
assert read_json(result)["status"]=="passed"
write_json(EVAL/"native-audit-ready.json",{
    "driver":reference(driver),"result":reference(result),"native_collection":reference(finish),
    "native_viewing_complete":False,
})
