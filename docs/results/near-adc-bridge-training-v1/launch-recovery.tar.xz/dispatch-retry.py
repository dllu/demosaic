"""Dispatch the two fixed continuations after the original 100k run succeeds."""

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import psutil
import yaml

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.experiments.runtime import exclusive_run, owner_identity, owner_live

ROOT = Path(__file__).resolve().parent
ARMS = ("control", "bridge")
OUTPUT = ROOT / "work" / "artifacts" / "near-adc-bridge"


def status(value, **fields):
    write_json(ROOT / "retry-status.json", {"status": value, "owner": owner_identity(), **fields}, replace=True)


def parent_binding(plan):
    stage_result = Path(plan["training_stage_result"])
    owners = [{"pid": o["pid"], "created": o["create_time"]} for o in plan["training_owners"]]
    deadline = time.monotonic() + 6 * 3600
    while not stage_result.is_file():
        if not any(owner_live(o) for o in owners):
            # A controller can publish after its wrapped child exits.
            time.sleep(10)
            if not stage_result.is_file() and not any(owner_live(o) for o in owners):
                raise RuntimeError("The original trainer and controller exited without a stage receipt")
        if time.monotonic() > deadline:
            raise TimeoutError("Original endpoint observer exceeded six hours")
        time.sleep(10)
    stage = read_json(stage_result)
    end_plan = read_json(checked(plan["endpoint_queue"]))
    assert stage["production_plan"] == end_plan["training_plan"]
    assert stage["stage"] == "01-scale-long100k" and stage["returncode"] == 0
    run = Path(end_plan["training_run"])
    state = read_json(run / "completed.json")
    phase = read_json(checked(state["phase"]))
    retained = read_json(run / "step100000-receipt.json")
    assert phase["production_plan"] == end_plan["training_plan"]
    assert state["steps"] == phase["to_step"] == phase["LR_horizon"] == retained["global_step"] == 100000
    assert state["checkpoint"] == phase["last"]
    checkpoint = retained["checkpoint"]
    assert checkpoint["sha256"] == state["checkpoint"]["sha256"]
    checked(checkpoint)
    return {"checkpoint": checkpoint, "step":100000, "weights":"EMA",
            "completion":reference(run/"completed.json"), "stage":reference(stage_result)}


def child(name, cmd, env):
    with (ROOT/f"{name}-retry.log").open("xb") as log:
        proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        launch = {"pid":proc.pid,"created":psutil.Process(proc.pid).create_time(),"command":cmd}
        write_json(ROOT/f"{name}-launch.json",launch)
        status(name, child=launch)
        code=proc.wait()
    write_json(ROOT/f"{name}-exit.json",{"returncode":code})
    if code:
        raise RuntimeError(f"{name} exited with {code}")


def training_inputs(result, steps):
    records=[]
    for t in result["corruption_condition_files"]:
        with np.load(checked(t)) as f:
            records.extend(zip(f["steps"].tolist(), f["domains"].tolist(), f["values"].copy(), strict=True))
    assert [r[0] for r in records] == list(range(1,steps+1))
    return [r[1] for r in records], np.stack([r[2] for r in records])


def audit(plan, parent):
    results=[]
    for arm in ARMS:
        closure=read_json(OUTPUT/arm/"completed.json")
        result=read_json(checked(closure["phase"]))
        assert closure["steps"]==result["to_step"]==result["LR_horizon"]==plan["steps"]
        assert not result["optimizer_EMA_RNG_preserved_on_resume"] and result["from_step"]==0
        assert result["examples"]==plan["examples_per_arm"] and result["domains"]==plan["domains"]
        assert result["initial_checks"]==[{
            "before_first_neural_forward":True,"all91_tensors_exact":True,"from_step":0,"fresh_optimizer":True,
        }]
        assert result["DINO_unchanged"]
        config=yaml.safe_load((OUTPUT/arm/"config.yaml").read_text())
        assert config["initialized_from"]["sha256"]==parent["checkpoint"]["sha256"]
        assert config["initialized_from"]["step"]==100000
        results.append(result)
    c,b=results
    assert c["source_crop_observations"]["sha256"]==b["source_crop_observations"]["sha256"]
    c_domains, control=training_inputs(c,plan["steps"])
    b_domains, bridge=training_inputs(b,plan["steps"])
    assert c_domains==b_domains
    np.testing.assert_array_equal(control[...,2:],bridge[...,2:])
    selected=np.any(control[...,:2]!=bridge[...,:2],axis=-1)
    assert selected.any() and (control[...,:2][selected]==0).all()
    assert (bridge[...,:2][selected]>0).all()
    assert not selected[np.array(c_domains)=="paired"].any()
    inserted={}
    for domain in set(c_domains):
        which=np.array(c_domains)==domain
        inserted[domain]=int(selected[which].sum())
    coefficients=bridge[...,:2][selected].astype(float)
    read_e=np.sqrt(coefficients[:,1])/coefficients[:,0]
    sigma=np.sqrt(coefficients.sum(axis=1))*65535
    out = {"execution_plan":reference(ROOT/"retry-execution-plan.json"),"parent":parent,
           "arms":{name:reference(ROOT/name/"completed.json") for name in ARMS},
           "source_and_crop_trace_bitexact":True,"camera_metadata_bitexact":True,
           "slots_per_arm":plan["examples_per_arm"],"changed_ADC_slots":int(selected.sum()),
           "changed_by_domain":inserted,"read_e_min_max":[float(read_e.min()),float(read_e.max())],
           "full_signal_sigma_DN16_min_max":[float(sigma.min()),float(sigma.max())],
           "measured_training_loop_seconds":{name:r["seconds"] for name,r in zip(ARMS,results,strict=True)},
           "trained":True,"numerically_evaluated":False,"native_inspected":False}
    path=ROOT/"training-audit.json"
    write_json(path,out)
    status("trained-awaiting-quality-review", audit=reference(path))


def main():
    with exclusive_run(ROOT):
        path=ROOT/"plan.json"
        plan=read_json(path)
        verify_plan(plan)
        trial=read_json(ROOT/"preflight-data.json")
        assert trial["plan"] == reference(path) and trial["changed_slots"] and trial["steps"]==32
        status("waiting-for-original-100k")
        parent=parent_binding(plan)
        execution=ROOT/"retry-execution-plan.json"
        work=Path(plan["work"]).resolve()
        assert OUTPUT.resolve().is_relative_to(work)
        configs=[]
        for arm in ARMS:
            original=checked(plan["configs"][arm])
            recipe=yaml.safe_load(original.read_text())
            assert Path(recipe["run"]) == ROOT / arm
            bound=ROOT/f"{arm}-retry.yaml"
            with bound.open("x") as stream:
                yaml.safe_dump(recipe | {"run":str(OUTPUT/arm)},stream,sort_keys=False)
            configs.append(reference(bound))
        assert len(configs)==len(ARMS)
        failed_attempt=[reference(ROOT/name) for name in (
            "execution-plan.json","train-control-exit.json","train-control.log","dispatch.log",
            "evaluation-waiter.log",
        )]
        assert read_json(checked(failed_attempt[1]))["returncode"] != 0
        assert "Output must be inside" in checked(failed_attempt[2]).read_text()
        write_json(execution,plan | {
            "parent":parent["checkpoint"],"parent_stage":parent,
            "configs":dict(zip(ARMS,configs,strict=True)),
            "retry_changes":"Write both runs inside the frozen source workspace. All training fields are identical.",
            "preserved_failed_attempt":failed_attempt,
            "inputs":[*plan["inputs"],reference(path),parent["checkpoint"],parent["completion"],
                      reference(ROOT/"preflight-data.json"),reference(__file__),*configs,*failed_attempt],
        })
        env=dict(os.environ,PYTHONPATH=f"{work}/scripts:{work}/src",
                 OMP_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",MKL_NUM_THREADS="2",
                 CUBLAS_WORKSPACE_CONFIG=":4096:8",PYTHONUNBUFFERED="1")
        env.pop("CUDA_VISIBLE_DEVICES", None)
        for arm in ARMS:
            while psutil.virtual_memory().available < 32*2**30 or shutil.disk_usage(ROOT).free < 192*2**30:
                status("waiting-for-training-resources", next_arm=arm)
                time.sleep(20)
            worker=checked(plan["worker_script"])
            child(f"train-{arm}",[sys.executable,str(worker),str(execution),arm,"--updates",str(plan["steps"])],env)
        audit(plan,parent)


if __name__=="__main__":
    main()
