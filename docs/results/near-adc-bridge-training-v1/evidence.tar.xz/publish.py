"""Publish the matched training admission and intermediate-noise color review."""

import shutil
import tarfile
from pathlib import Path

import psutil
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.runtime import owner_live

ROOT=Path(__file__).resolve().parent
COLOR=ROOT.parent/"intermediate-noise-color-v1"
TRIAL=Path("docs/results/near-adc-bridge-training-v1")
REVIEW=Path("docs/results/coarse-adc-color-v1")
IMAGES=Path("docs/images/coarse-adc-color-v1")


def archive(path, files):
    with tarfile.open(path,"x:xz",preset=6) as stream:
        for label,file in sorted(files.items()):
            info=stream.gettarinfo(file,arcname=label)
            info.uid=info.gid=info.mtime=0
            info.uname=info.gname=""
            with file.open("rb") as f:
                stream.addfile(info,f)
    with tarfile.open(path) as stream:
        for item in stream:
            assert stream.extractfile(item).read()==files[item.name].read_bytes()


def copy(binding):
    source=checked(binding)
    target=IMAGES/source.name
    shutil.copyfile(source,target)
    assert reference(target)["sha256"]==binding["sha256"]
    return target


def panels(path,marks):
    with Image.open(path) as image:
        result={}
        for mark in marks:
            x,y,w,h=mark["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            result[mark["label"]]=image.crop((x,y,x+w,y+h)).tobytes()
    return result


def trial():
    TRIAL.mkdir()
    plan=read_json(ROOT/"plan.json")
    sources={}
    for name in ("dispatch","evaluation-waiter"):
        path=ROOT/("launch.json" if name=="dispatch" else "evaluation-waiter-launch.json")
        launch=read_json(path)
        assert owner_live(launch)
        assert psutil.Process(launch["pid"]).cmdline()==launch["command"]
        sources[name]=reference(path)
    core=(Path("src/demosaic/train.py"),Path("src/demosaic/near_adc_training.py"))
    for path in core:
        assert plan["frozen_files"][str(Path(plan["work"])/path)]==reference(path)["sha256"]
    test=Path("tests/test_near_adc_training.py")
    shutil.copyfile(ROOT/"preflight-data.json",TRIAL/"data-preflight.json")
    proof=read_json(TRIAL/"data-preflight.json")
    assert proof["steps"]==32 and proof["changed_slots"]==23
    assert "118 passed" in (ROOT/"tests.log").read_text()
    assets={key:ROOT/key for key in ("prepare.py","preflight-data.py","dispatch.py","evaluate-when-ready.py",
                    "publish.py","plan.json","control.yaml","bridge.yaml","photo-order/photo-epoch-order.json",
                    "photo-order/ordinary-photo-order.npy","coverage-recipe.yaml","launch.json",
                    "review-declaration.json","evaluation-waiter-launch.json","tests.log","tests-saturated-fixture.log")}
    assets.update({str(path):path for path in (*core,test)})
    assets["original/worker-v7.py"]=checked(plan["worker_script"])
    payload=TRIAL/"evidence.tar.xz"
    archive(payload, assets)
    write_json(TRIAL/"publication.json",{
        "scope":"Actual locked trial setup with completed CPU data validation; training and model quality pending.",
        "raw_plan":reference(ROOT/"plan.json"),"evidence":reference(payload),
        "preflight":reference(TRIAL/"data-preflight.json"),"live_processes":sources,
        "plan_examples_per_arm":plan["examples_per_arm"],"checks_passed":118,
    })


def color():
    REVIEW.mkdir()
    IMAGES.mkdir()
    report=read_json(COLOR/"review/result.json")
    audit=read_json(COLOR/"library-replay.json")
    assert audit["implementation"]==reference("src/demosaic/adc_bins.py")
    notes={
        "034fe53d538446fdc93f2e4d926aae0eb32afc3b":"Roof/branches are unchanged. Thin branches remain softer than the clean target.",
        "03768ece408913d3c727b3e29b8ece77a57e5d9c":"Steeple and sky are unchanged. Some internal detail is still soft.",
        "noisy-residual-reserved-palette-v1-magenta":"Coarse correction brings the pinker raw result close to the exact magenta.",
        "nulls-bright-yellow":"The coarse correction removes most of the hue shift. Corrected interior remains visually smooth.",
    }
    rows=[]
    for b in report["boards"]:
        info={k:v for k,v in b.items() if k not in ("board","triplet")}
        board=copy(b["board"]["image"])
        pictures=panels(board,b["board"]["panels"])
        info["comparison"]=b["board"] | {"file":board.name}
        if "palette" in b["id"] or b["id"].startswith("nulls-"):
            subset=copy(b["triplet"]["image"])
            assert all(t==pictures[k] for k,t in panels(subset,b["triplet"]["panels"]).items())
            info["triplet"]=b["triplet"] | {"file":subset.name}
        else:
            assert pictures["86k raw EMA"]==pictures["86k coarse measured color"]
        rows.append(info | {"viewing":notes[b["id"]]})
    assert len(rows)==4
    index=IMAGES/"manifest.json"
    write_json(index,{"images":rows,"reference_role":"Exact synthetic target; identical native160 cells."})
    shutil.copyfile(COLOR/"library-replay.json",REVIEW/"library-replay.json")
    targets={name:COLOR/name for name in ("review.py","audit.py","tests.log","review/result.json",
                                          "review.log","library-replay.json")}
    targets.update({"src/demosaic/adc_bins.py":Path("src/demosaic/adc_bins.py"),
                    "tests/test_adc_bins.py":Path("tests/test_adc_bins.py")})
    payload=REVIEW/"evidence.tar.xz"
    archive(payload,targets)
    assert "182 passed" in (COLOR/"tests.log").read_text()
    write_json(REVIEW/"publication.json",{
        "manifest":reference(index),"evidence":reference(payload),
        "library_replay":reference(REVIEW/"library-replay.json"),
        "viewed_comparisons":4,"viewed_triplets":2,"tests_passed":182,
        "scope":"86k and V120 on existing synthetic panels and verified unchanged standing "
                 "GFX predictions; calibration-specific interim color repair.",
    })


if __name__=="__main__":
    trial()
    color()
