"""Check both recipes on the first 32 real training batches without using the GPU."""

from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
import yaml
from prepare_photo_epoch_order import READER_KEYS
from torch.utils.data import DataLoader

from demosaic import train as training
from demosaic.cfa import mosaic
from demosaic.data import CleanDataset
from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json
from demosaic.noise import add_noise
from demosaic.paired_training import PairedDataset
from demosaic.raw_clean import RawCleanDataset

ROOT = Path(__file__).resolve().parent
LIMIT = 32
CHANGES = {"packed", "variance", "shot", "read"}


def show_loader(config, kind, data, offset):
    seed = config["seed"]
    sampler = training.domain_indices(
        kind, 0, LIMIT, config["batch_size"], seed,
        config["paired_fraction"], config["raw_clean_fraction"],
    )
    return DataLoader(data, batch_size=config["batch_size"], sampler=sampler, num_workers=0,
                      generator=torch.Generator().manual_seed(seed + offset), pin_memory=False)


def main():
    torch.set_num_threads(2)
    plan = read_json(ROOT / "plan.json")
    verify_plan(plan)
    baseline, candidate = [yaml.safe_load(checked(plan["configs"][k]).read_text()) for k in ("control", "bridge")]
    assert {k for k in baseline if baseline[k] != candidate[k]} == {"run", "near_adc_bridge_fraction"}
    data = CleanDataset(
        baseline["manifest"], **{k:baseline[k] for k in READER_KEYS if k in baseline},
        photo_epoch_order=baseline["photo_epoch_order"],
        photo_epoch_order_sha256=baseline["photo_epoch_order_sha256"],
        trace_sources=True,
    )
    paired = PairedDataset(
        baseline["paired_manifest"], patch_size=baseline["patch_size"], seed=baseline["seed"],
        camera_sampling_weights=baseline["paired_camera_sampling_weights"],
    )
    native = RawCleanDataset(
        baseline["raw_clean_manifest"], patch_size=baseline["patch_size"], seed=baseline["seed"],
        optical_blur_probability=baseline["raw_clean_optical_blur_probability"],
        augmentation_downsample=baseline["raw_clean_augmentation_downsample"],
    )
    loaders = {k:show_loader(baseline, k, ds, shift)
               for k, ds, shift in (("commons",data,0),("paired",paired,17),("native",native,31))}
    model = SimpleNamespace(config=SimpleNamespace(physical_fp32=True))
    prepare = training.bridge_noise_batch
    proofs, noise_coverage, audit, domains = [], [], [], Counter()

    def verify(actual, fraction, *, seed, step, domain):
        before = torch.random.get_rng_state()
        updated = prepare(actual, fraction, seed=seed, step=step, domain=domain)
        assert torch.equal(before, torch.random.get_rng_state())
        if updated is actual:
            return updated
        changed = (actual["shot"] != updated["shot"]).flatten()
        assert (actual["shot"][changed] == 0).all() and (actual["read"][changed] == 0).all()
        assert all(torch.equal(v[~changed], updated[k][~changed]) for k,v in actual.items())
        for key in actual.keys() - CHANGES:
            assert updated[key] is actual[key]
        black = actual["adc_black_level"][changed].double()
        shot, read = (updated[k][changed].double() for k in ("shot","read"))
        sigma = (shot + read).sqrt() * 65535 * (1 - black)
        read_e = read.sqrt() / shot
        assert ((4 <= sigma) & (sigma <= 160)).all()
        assert ((0.7 <= read_e) & (read_e <= 1500)).all()
        noise_coverage.extend(zip(sigma.flatten().tolist(),read_e.flatten().tolist(),strict=True))
        # Reconstruct fresh RAW from the retained, pre-clipping camera signal.
        # Hash the independent selection and seed namespace before comparing exact values.
        import hashlib
        digest = hashlib.sha256(f"near-adc-training-v1:{seed}:{step}:{domain}:sensor".encode()).digest()
        generator = torch.Generator().manual_seed(int.from_bytes(digest[:8],"little") % 2**63)
        clean = mosaic(actual["sensor_target"][changed], actual["colors"][changed])
        rebuilt = add_noise(clean, shot.float(), read.float(), black_level=black.float(), generator=generator)
        torch.testing.assert_close(rebuilt, updated["packed"][changed], rtol=0, atol=0)
        audit.append({"step":step,"domain":domain,"cases_regenerated":int(changed.sum())})
        return updated

    training.bridge_noise_batch = verify
    seed = baseline["seed"]
    try:
        for step, domain, clean in training.selected_batches(loaders, 0, LIMIT, seed, 0.25, 0.25):
            options = dict(model=model, device="cpu", seed=seed)
            control = training.prepare_training_batch(step, domain, clean, config=baseline, **options)
            candidate_batch = training.prepare_training_batch(step, domain, clean, config=candidate, **options)
            assert set(control) == set(candidate_batch)
            selected = (control["shot"] != candidate_batch["shot"]).flatten()
            for key, value in control.items():
                old, new = (value[~selected],candidate_batch[key][~selected]) if key in CHANGES else (value,candidate_batch[key])
                assert torch.equal(old,new)
            assert int(selected.sum()) == 0 or domain != "paired"
            assert torch.isfinite(candidate_batch["packed"]).all()
            domains[domain] += 1
            proofs.append({"step":step,"domain":domain,"changed_indices":selected.nonzero().flatten().tolist(),
                           "actual_source_metadata":clean.get("source",[]),
                           "control_batch":training.batch_fingerprint(control),
                           "bridge_batch":training.batch_fingerprint(candidate_batch)})
    finally:
        training.bridge_noise_batch = prepare
    assert len(proofs) == LIMIT and set(domains) == {"commons","native","paired"}
    assert noise_coverage
    assert not torch.cuda.is_initialized()
    a = np.asarray(noise_coverage)
    write_json(ROOT / "preflight-data.json", {
        "source":reference(__file__),"plan":reference(ROOT/"plan.json"),
        "steps":LIMIT,"B16_slots":LIMIT*16,"domains":dict(domains),
        "changed_slots":len(noise_coverage),"exact_resimulation":audit,
        "sigma_codes_min_max":[float(a[:,0].min()),float(a[:,0].max())],
        "read_e_min_max":[float(a[:,1].min()),float(a[:,1].max())],"per_step":proofs,
        "scope":"Actual CPU training loaders and physical augmentation on the locked sample indices. "
        "No DINO, restoration, optimizer, validation or accelerator work.",
    })
    print("Passed all",LIMIT,"B16 data batches",dict(domains),"changed",len(noise_coverage))


if __name__ == "__main__":
    main()
