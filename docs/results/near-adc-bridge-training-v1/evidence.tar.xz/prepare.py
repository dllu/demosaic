"""Freeze a matched continuation into the low-noise conditioning gap."""

import shutil
from pathlib import Path

import yaml
from prepare_photo_epoch_order import prepare as prepare_order

from demosaic.experiments.artifacts import checked, freeze_sources, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = Path.cwd().resolve()
SCALE = ROOT.parent / "full-corpus-scaling-v3"
ENDPOINT = ROOT.parent / "full-corpus-long100k-review-v1"
SOURCE = SCALE / "production-handoff-plan-v7.json"
STEPS = 800
ARMS = ("control", "bridge")
DATA_KEYS = (
    "manifest", "validation_manifest", "photo_sampling_reference_manifest",
    "paired_manifest", "raw_clean_manifest", "reviewed_roi_catalogue", "validation_protocol",
)


def main():
    production = read_json(SOURCE)
    original = checked(production["configs"]["long100k"])
    cfg = yaml.safe_load(original.read_text())
    assert cfg["batch_size"] == 16 and cfg["steps"] == 100000
    assert cfg["noise_free_fraction"] == 0.1 and cfg["paired_fraction"] == 0.25
    assert cfg["data_seed_per_step"] and cfg.get("noise_pair_draws", 1) == 1
    for key in (
        "initialize_parent", "parent_dino_sha256", "initialized_from",
        "source_sha256", "source_snapshot", "training_execution_runtime",
        "photo_epoch_order", "photo_epoch_order_sha256",
    ):
        cfg.pop(key, None)
    cfg.update(
        steps=STEPS, seed=171, lr=3e-6, warmup_steps=40, checkpoint_every=200,
        experiment_notes="Matched fresh AdamW from completed 100k EMA. Only the candidate resimulates "
        "half of original simulated ADC-only samples with continuous near-ADC noise.",
    )
    recipe = ROOT / "coverage-recipe.yaml"
    recipe.write_text(yaml.safe_dump(cfg, sort_keys=False))
    epoch = prepare_order(recipe, ROOT / "photo-order")
    cfg["photo_epoch_order"] = str(epoch)
    cfg["photo_epoch_order_sha256"] = reference(epoch)["sha256"]
    header = read_json(epoch)
    assert header["summary"]["available_train_photos"] == 90778

    frozen, files = freeze_sources(REPO, ROOT, ("profile_raw_kernel_inference.py",))
    worker = frozen / "scripts/run_full_corpus_continuation_v7.py"
    shutil.copyfile(checked(production["worker_script"]), worker)
    for rel in ("pyproject.toml", "uv.lock", "third_party/gaussian/KAIR-LICENSE",
                "third_party/gaussian/Noise2VST-LICENSE", "third_party/dinov3/LICENSE.md"):
        path = frozen / rel
        path.parent.mkdir(exist_ok=True, parents=True)
        shutil.copyfile(REPO / rel, path)
        files[str(path)] = reference(path)["sha256"]
    files[str(worker)] = reference(worker)["sha256"]

    configs = {}
    for arm, fraction in zip(ARMS, (0., .5), strict=True):
        branch = ROOT / f"{arm}.yaml"
        body = {**cfg, "run": str(ROOT / arm), "near_adc_bridge_fraction": fraction}
        branch.write_text(yaml.safe_dump(body, sort_keys=False))
        configs[arm] = reference(branch)
    original_bridge = REPO / "src/demosaic/near_adc_training.py"
    assert files[str(frozen/"src/demosaic/near_adc_training.py")] == reference(original_bridge)["sha256"]
    learned_source = read_json(ENDPOINT/"plan.json")
    write_json(ROOT / "plan.json", {
        "root": str(ROOT), "work": str(frozen), "configs": configs,
        "DINO_sha256": production["DINO_sha256"], "worker_script": reference(worker),
        "profile_plan": production["profile_plan"], "frozen_files": files, "retained_steps": [STEPS],
        "inputs": [reference(original), reference(__file__), reference(SOURCE), reference(epoch),
                   reference(epoch.parent / header["order"]["path"]), *configs.values(),
                   *[reference(cfg[k]) for k in DATA_KEYS]],
        "endpoint_queue": reference(ENDPOINT/"plan.json"),
        "endpoint_admission": str(ENDPOINT/"endpoint-admission.json"),
        "training_stage_result": learned_source["training_stage_result"],
        "training_owners": learned_source["owners"],
        "steps": STEPS, "examples_per_arm": STEPS * cfg["batch_size"],
        "domains": header["summary"]["domains"], "camera_and_targets_locked": True,
        "scope": "Same fixed native256 shapes, seed, data selection, optimizer and losses. "
        "Only the shot/read distribution of the selected simulated ADC-only slots changes. "
        "No change to source crops, CFA, WB, scene context or measured paired observations.",
    })
    print("Prepared", configs, header["summary"]["domains"])


if __name__ == "__main__":
    main()
