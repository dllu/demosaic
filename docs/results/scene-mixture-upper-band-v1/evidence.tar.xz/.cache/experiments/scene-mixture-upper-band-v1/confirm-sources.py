"""Check confirmation IDs and decoded-cache identities against the actual Corpus 100k visits."""
import json
from pathlib import Path

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

root=Path(__file__).resolve().parent
confirmation=reference(root/'fresh.json')
published=read_json(checked(confirmation))
selected={r['source']for r in published['rows']}
record=read_json(checked(published['protocol']['source_plan']))
sources={r['source']['id']:r['source']['cache_sha256']
         for r in record['rows']if r['source']['id'] in selected}
assert len(sources)==32
target=set(sources.values())
train=reference('docs/results/full-corpus-long100k-training-v1/source-audit.json')
replay=read_json(checked(train))
assert replay['checkpoint']['sha256']==published['checkpoints']['100k']['sha256']
files=replay['source_traces']
visited=0
overlap=[]
for binding in files:
    with checked(binding).open()as stream:
        for line in stream:
            for source in json.loads(line)['sources']:
                if source['kind']!='photographic':
                    continue
                visited+=1
                if source['source_id'] in sources or source['cache_sha256'] in target:
                    overlap.append((source['source_id'],source['cache_sha256']))
assert not overlap
write_json(root/'source-verification.json',{'driver':reference(__file__),'confirmation':confirmation,
    'Corpus_100k_visit_audit':train,'photo_visits_checked':visited,'source_ids_and_cache_hashes':sources,
    'overlap':overlap,'scope':'Actual recorded Corpus 100k continuation visits; no claim about every ancestor.'})
print(visited,len(sources),len(overlap))
