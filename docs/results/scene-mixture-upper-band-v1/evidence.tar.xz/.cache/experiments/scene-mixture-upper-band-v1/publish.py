"""Verify the upper-band experiment, freeze weights and publish native images."""
from datetime import datetime
import hashlib
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.with_name('scene-gated-mixture-v1')
IMAGE=Path('docs/images')/ROOT.name
OUT=Path('docs/results')/ROOT.name


def slices(p,spec):
    image=np.asarray(Image.open(p).convert('RGB'))
    areas={r.get('label',r.get('name')):image[y:y+h,x:x+w]
           for r in spec['panels'] for x,y,w,h in [r['png_xywh']]}
    assert all(v.shape==(160,160,3)for v in areas.values())
    return areas


def retain(spec,directory):
    source=checked(spec['image'])
    path=IMAGE/directory/source.name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,path)
    assert reference(path)['sha256']==spec['image']['sha256']
    spec['image']['path']=path.relative_to(IMAGE).as_posix()
    return slices(path,spec)


def publish():
    files=('upper','fresh','native','fresh-native','delivery','source-verification')
    refs={n:reference(ROOT/f'{n}.json')for n in files}
    fit,fresh,native,extra,delivery,locus=(read_json(checked(v))for v in refs.values())
    assert fresh['protocol']['fit']==native['study']==delivery['source']==refs['upper']
    assert extra['source']==locus['confirmation']==refs['fresh']
    assert fit['checkpoints']==fresh['checkpoints']==native['checkpoints']
    assert len(fit['rows'])==256 and len(fresh['rows'])==128 and len(delivery['rows'])==192
    fixed={r['source']for r in fit['rows']}
    separate={r['source']for r in fresh['rows']}
    assert len(fixed)==64 and len(separate)==32 and fixed.isdisjoint(separate)
    assert set(locus['source_ids_and_cache_hashes'])==separate and not locus['overlap']
    assert len(fit['split']['calibration'])==16 and len(fit['split']['test'])==48
    assert delivery['projected_vs_delivered_max_DN16']<.002 and delivery['single_filter_max_camera_unit_change']<5e-8
    assert len(native['exact'])==len(extra['boards'])==2
    for collection,name in ((native['exact'],'exact'),(extra['boards'],'confirmation')):
        for row in collection:
            both=retain(row['board'],name)
            triple=retain(row['triplet'],name)
            assert list(triple)==['Noisy Malvar','Band-limited guarded mix','Exact GT']
            assert all(np.array_equal(both[k],v)for k,v in triple.items())
    assert len(native['standing']['rows'])==8
    for row in native['standing']['rows']:
        expected=slices(checked(row['reference']['image']),row['reference'])
        new=retain(row['output'],'standing')
        common=set(expected)&set(new)
        assert {'ISO100 AHD reference','Parent 100k EMA','Spatial 40k EMA','Noisy (Malvar)'}<=common
        assert all(np.array_equal(expected[k],new[k])for k in common)
        assert np.array_equal(expected['Registered detail gate'],new['Previous signed mix'])
        if row['id'].startswith('mesh-'):
            assert {'ISO100 camera JPEG','ISO6400 camera JPEG'}<=common
    manifest=IMAGE/'manifest.json'
    write_json(manifest,dict(models=fit['checkpoints'],exact=native['exact'],confirmation=extra['boards'],
        standing=native['standing'],sources={k:refs[k]for k in ('native','fresh-native')},
        viewed_local=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()))
    OUT.mkdir(exist_ok=True)
    checkpoint=OUT/'coefficients.json'
    write_json(checkpoint,dict(checkpoints=fit['checkpoints'],source=refs['upper'],
        coefficient_fit=fit['fits'],transition_cycles_per_native_pixel=fit['transition'],
        reflection_margin=fit['reflection_margin'],calibration_sources=fit['split']['calibration'],
        maximum_neutral_boost=.5,weights_used='direct CPU fit composed above two frozen EMAs'))
    archive=OUT/'evidence.tar.xz'
    members=[checked(src)for src in refs.values()]+list(ROOT.glob('*.py'))+list(ROOT.glob('*.log'))
    members.extend((PREVIOUS/'mixture.py',PREVIOUS/'native_review.py',PREVIOUS/'color_audit.py',
                    ROOT.with_name('scene-raw-covariance-v1')/'evaluate.py',
                    ROOT.with_name('scene-local-contrast-2400-v1')/'prepare_eval.py',
                    ROOT.with_name('scene-local-contrast-2400-v1')/'measure.py',
                    ROOT.with_name('paired-luminance-detail-v1')/'render.py',
                    Path('scripts/probe_scene_context_extent.py'),Path('scripts/report_scene_wave_guides.py')))
    with tarfile.open(archive,'w:xz',preset=4)as tar:
        for path in sorted(members):
            tar.add(path,arcname=path.resolve().relative_to(Path.cwd()).as_posix(),recursive=False)
    with tarfile.open(archive)as tar:
        for path in members:
            with tar.extractfile(path.resolve().relative_to(Path.cwd()).as_posix())as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==reference(path)['sha256']
    key='iso6400/independent'
    primary=fit['scopes'][key+'/test']
    confirmation=fresh['scopes'][key+'/confirmation']
    other_conditions={}
    for name,study,suffix in (('fixed',fit,'test'),('confirmation',fresh,'confirmation')):
        other_conditions[name]={scope:{k:v['delta']['limited_guard vs parent'] for k,v in bands.items()}
            for scope,bands in study['scopes'].items() if scope.endswith('/'+suffix)}
    write_json(OUT/'publication.json',dict(checkpoint=reference(checkpoint),archive=reference(archive),
        manifest=reference(manifest),sources=refs,model_roles=fit['checkpoints'],
        calibration={'photos':16,'groups':64,'solves':len(fit['fits']),'fit_seconds':fit['fit_seconds']},
        matched_photo_review={'test_photos':48,'confirmation_photos':32,'confirmation_source_audit':locus,
             'confirmation_GPU_inference_seconds':fresh['inference_seconds'],'primary':primary,'confirmation':confirmation},
        fit_changes=other_conditions,delivered_color=delivery['scopes'][key],
        scope='Fixed-model output component. Two exact photographic cohorts and standing GFX. No fixed427 or measured camera panel for the composition.'))
    print('Verified',len(members),'archive entries, 4 triplets and 8 standing boards')


if __name__=='__main__':
    publish()
