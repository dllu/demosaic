"""Render the best and worst incremental fine-error witnesses on the confirmation set."""
import numpy as np
import torch

from fresh import config,networks,numpy_input,predictions,prepare_eval
from native import ROOT,ROI,apply,native_board,noisy_malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,9*2**30/torch.cuda.get_device_properties(0).total_memory))
    confirmation=reference(ROOT/'fresh.json')
    fitted,cohort,profiles,_,setup=config()
    archive=read_json(checked(confirmation))
    assert archive['protocol']==setup
    models=networks(fitted['checkpoints'])
    rows=[r for r in archive['rows']if (r['profile'],r['draw'])==('iso6400','independent')]
    high=next(r for r in profiles if r['name']=='iso6400')
    def difference(r):
        return float(np.sqrt(r['scores']['limited_guard']['fine']['increment'])-
                     np.sqrt(r['scores']['parent']['fine']['increment']))
    out=ROOT/'confirmation-native'
    out.mkdir(exist_ok=True)
    boards=[]
    for item in (min(rows,key=difference),max(rows,key=difference)):
        spec=next(r for r in cohort if r['source']['id']==item['source'])
        photo=prepare_eval.load_photo(spec)
        arrays=numpy_input(spec,photo,high,'independent')
        assert {k:fingerprint(v)for k,v in arrays.items()}==item['raw']
        p,enc=predictions(models,arrays,{'box':spec['box'],'profile':high})
        assert enc==item['preview_fingerprints']
        assert {k:fingerprint(v)for k,v in p.items()}==item['predictions']
        props={k:arrays[k]for k in ('colors','wb','matrix')}|{'packed':arrays['packed'][0]}
        fields=apply(p['100k'][0],p['spatial--matching'][0],props,high,ROI,arrays['scene_packed'],spec['box'],fitted)
        labels=('Noisy Malvar','Corpus 100k EMA','Spatial 40k EMA','Previous signed mix','Band-limited guarded mix','Exact GT')
        references={k:v[None]for k,v in props.items()}
        images=(noisy_malvar(references)[0],p['100k'][0],p['spatial--matching'][0],fields['previous'],
                fields['limited_guard'],arrays['target'][0])
        boards.append(native_board(out,f"{spec['index']:03d}-iso6400-confirmation-upper",images,references,
                {'source':spec['source'],'query':spec['box'],'CFA':spec['camera']['pattern'],'noise':high,
                 'ADC_bits':16,'black_level':spec['camera']['black'],'checkpoints':fitted['checkpoints'],
                 'fine_increment_change_DN16':difference(item)},
                labels=labels,triplet_indices=(0,4,5),roi=ROI,exposure=1/high['exposure'],contrast=2))
        print(spec['index'],spec['source']['title'],difference(item),flush=True)
    write_json(ROOT/'fresh-native.json',{'driver':reference(__file__),'source':confirmation,'boards':boards})


if __name__=='__main__':
    main()
