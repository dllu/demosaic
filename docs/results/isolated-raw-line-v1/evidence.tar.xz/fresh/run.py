"""Fresh geometry and noise for direct RAW use of disjoint line guides."""

import math
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
from recover import external_guide, keep_local_support, supported_correction

from demosaic.cfa import mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.noise import add_noise, variance_map
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "scene-wire-gap-v1"
sys.path.insert(0, str(PRIOR))
import probe

PLANS = ("whole", "segments-64", "local-veto")
CASES = range(20, 32)
PRIORS = probe.PRIORS


def target(geometry, partial):
    absent, present, aligned, orthogonal, quiet = probe.pattern(geometry)
    axis = torch.arange(probe.SIDE, dtype=torch.float32) - (probe.SIDE - 1) / 2
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    angle = (geometry * 13 + 17) * math.pi / 180
    t = math.sin(angle) * y + math.cos(angle) * x
    half_gap = (14, 22, 29)[geometry % 3]
    gap_center = (-26, 0, 23, 34)[(geometry // 3) % 4]
    gap = (t - gap_center).abs() <= half_gap
    full = present
    if partial:
        present = absent + (present - absent) * probe.smoothstep(
            ((t - gap_center).abs() - half_gap) / 8
        )
        assert torch.equal(present[:, gap], absent[:, gap])
    return absent, present, aligned, orthogonal, quiet, gap, full


def sample(geometry, profile, seed, partial):
    a, b, aligned, orthogonal, quiet, gap, full = target(geometry, partial)
    bayer = tuple(probe.PATTERNS)[geometry % 4]
    arrays, metadata = paired_observation(
        a[None], b[None], profile, [bayer], torch.ones(1, 3), torch.eye(3)[None], seed
    )
    keys = ("packed", "variance", "target", "colors", "wb", "matrix")
    local = {k: torch.from_numpy(arrays[k]) for k in keys}
    for k in ("packed", "variance", "target"):
        local[k] = probe.query(local[k], packed=k != "target")
    raw = {}
    for i, (name, value) in enumerate(
        (("matching", aligned), ("mismatched", orthogonal), ("no-guide", a))
    ):
        # The guide is independently corrupted and the fitter never reads its
        # local region. All local roles use the one coupled query observation.
        y = mosaic(value[None], local["colors"][0])
        raw[name] = add_noise(
            y,
            profile["shot"],
            profile["read"],
            black_level=0.03,
            generator=torch.Generator().manual_seed(seed + 21 + 11 * i),
        )[0]
    return (
        local,
        raw,
        probe.query(quiet, packed=False),
        probe.query(gap, packed=False),
        probe.query(full - a, packed=False),
        metadata,
    )


def evaluate(local, quiet, gap, full, parent, out, partial):
    row = probe.render_data(local, quiet, out)
    x, y, w, h = probe.ROI
    crop = np.s_[..., y : y + h, x : x + w]
    p = parent.numpy().astype(float)[crop]
    r = out.numpy().astype(float)[crop]
    t = local["target"].numpy().astype(float)[crop]
    q = quiet.numpy()[crop]
    correction = r - p
    row["gap_role_added_RMS_DN16"] = float(65535 * np.sqrt(np.mean(correction[0, :, q] ** 2)))
    row["modified_roles"] = [bool(v.any()) for v in correction]
    if partial:
        full = full.numpy().astype(float)[crop]
        missing = q & gap.numpy()[crop] & (np.abs(full).max(0) > 1e-8)
        expected = full[:, missing]
        wanted = t[1, :, missing].T
        error = r[1, :, missing].T - wanted
        old = p[1, :, missing].T - wanted
        row["abs_partial_gap_projection_percent"] = float(
            100 * abs((error * expected).sum()) / (expected**2).sum()
        )
        row["abs_partial_gap_projection_baseline_percent"] = float(
            100 * abs((old * expected).sum()) / (expected**2).sum()
        )
        row["partial_gap_error_RMS_DN16"] = float(65535 * np.sqrt((error**2).mean()))
        row["partial_gap_added_RMS_DN16"] = float(
            65535 * np.sqrt(np.mean(correction[1, :, missing] ** 2))
        )
    return row


@torch.inference_mode()
def main():
    os.sched_setaffinity(0, [6, 7])
    os.nice(11)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(
        min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    state = read_json(PRIOR / "plan.json")
    binding = state["checkpoint"]
    plan = {
        "driver": reference(__file__),
        "recovery": reference(ROOT / "recover.py"),
        "original_generator": reference(PRIOR / "probe.py"),
        "original_results": reference(PRIOR / "result.json"),
        "checkpoint": binding,
        "priors": PRIORS,
        "geometries": list(CASES),
        "repeats": [0, 1],
        "query_box": probe.BOX,
        "ROI_xywh": probe.ROI,
        "black": 0.03,
        "width_native": 1.2,
        "gap_full_lengths_px": [28, 44, 58],
        "gap_centers_px": [-26, 0, 23, 34],
        "previous_experiment": reference(ROOT.parent / "disjoint-line-recovery-v1/result.json"),
        "local_veto": {
            "support_span": 24,
            "soft_score_interval": [2, 3],
            "amplitude_source": "segments-64",
        },
        "segment_span_native": 64,
        "score_threshold": 2.5,
        "scope": "Fresh geometry and seeds. Fit a single noisy outer line and signed color with an exterior-only proposal. Two disjoint local CFA subsets support it independently. Compare whole-query, 64px and 64px with a 24px local veto on new geometry, varying gap sizes and random draws. No evidence from the truth or neural RGB enters the gate.",
    }
    write_json(ROOT / "plan.json", plan)
    model, payload = load_scene_checkpoint(
        checked(binding), device="cuda", weights="ema", expected_sha256=binding["sha256"]
    )
    assert model.mode == "spatial" and payload["step"] == 2000
    del payload
    model.mode = "none"
    out = ROOT / "cases"
    out.mkdir()
    records = []
    began = time.monotonic()
    with ieee_fp32():
        for noise, profile in PRIORS.items():
            model.base.set_noise(profile["shot"], profile["read"])
            for geometry in CASES:
                for repeat in (0, 1):
                    for partial in (False, True):
                        key = f"{noise}-g{geometry}-r{repeat}-{'partial' if partial else 'full'}"
                        seed = (
                            145608550000
                            + list(PRIORS).index(noise) * 100000
                            + geometry * 250
                            + repeat * 29
                            + int(partial)
                        )
                        local, outer, quiet, gap, full, physics = sample(
                            geometry, profile, seed, partial
                        )
                        args = [
                            local[k].cuda()
                            for k in ("packed", "variance", "colors", "wb", "matrix")
                        ]
                        parent = model(*args).cpu()
                        results = {
                            "parent": evaluate(local, quiet, gap, full, parent, parent, partial)
                        }
                        rendered = {}
                        proposals = {}
                        for guide_name, o in outer.items():
                            g = external_guide(
                                o.numpy(),
                                variance_map(o, profile["shot"], profile["read"]).numpy(),
                                local["colors"][0].numpy(),
                                probe.BOX,
                            )
                            proposals[guide_name] = asdict(g) if g is not None else None
                            medium = []
                            for policy in PLANS:
                                y = []
                                spectra = []
                                for j in (0, 1):
                                    base = parent[j].numpy()
                                    physical = [
                                        local[key][j].numpy()
                                        for key in ("packed", "variance", "colors")
                                    ]
                                    if policy == "local-veto":
                                        corrected, witness = keep_local_support(
                                            base, medium[j], *physical, probe.BOX[:2], g
                                        )
                                    else:
                                        corrected, witness = supported_correction(
                                            base,
                                            *physical,
                                            probe.BOX[:2],
                                            g,
                                            segment=64 if policy == "segments-64" else None,
                                        )
                                        if policy == "segments-64":
                                            medium.append(corrected)
                                    y.append(torch.from_numpy(corrected))
                                    spectra.append(witness)
                                p = torch.stack(y)
                                name = guide_name + "-" + policy
                                results[name] = evaluate(
                                    local, quiet, gap, full, parent, p, partial
                                ) | {"heldout_half_scores": spectra}
                                if guide_name == "matching":
                                    rendered[policy] = p.numpy()
                        retained = None
                        if geometry in (20, 24, 29) and repeat == 0:
                            image = out / (key + ".npz")
                            with image.open("xb") as f:
                                np.savez_compressed(
                                    f,
                                    **{k: t.numpy() for k, t in local.items()},
                                    **rendered,
                                    parent=parent.numpy(),
                                    quiet=quiet.numpy(),
                                    gap=gap.numpy(),
                                    full=full.numpy(),
                                )
                            retained = reference(image)
                        row = {
                            "profile": noise,
                            "geometry": geometry,
                            "repeat": repeat,
                            "seed": seed,
                            "partial": partial,
                            "id": key,
                            "set": ("partial" if partial else "full"),
                            "measurements": results,
                            "outer_proposals": proposals,
                            "noise_physics": physics,
                            "retained": retained,
                            "fingerprints": {k: fingerprint(t) for k, t in local.items()},
                        }
                        path = out / (key + ".json")
                        write_json(path, row)
                        records.append(reference(path))
                    print(noise, geometry, repeat, float(time.monotonic() - began), flush=True)
    assert len(records) == 96
    write_json(
        ROOT / "result.json",
        {
            "plan": reference(ROOT / "plan.json"),
            "records": records,
            "seconds": time.monotonic() - began,
        },
    )


if __name__ == "__main__":
    main()
