"""Compare the packaged experimental API with the retained prototype outputs."""

import os
from pathlib import Path

import numpy as np
import torch
from run import PRIORS, probe, sample

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import external_guide, refine_isolated_raw_line
from demosaic.noise import variance_map

ROOT = Path(__file__).resolve().parent
INITIAL = ROOT.parent / "disjoint-line-recovery-v1"


def main():
    os.sched_setaffinity(0, [12, 13])
    torch.set_num_threads(2)
    result = read_json(ROOT / "result.json")
    compared = []
    for item in result["records"]:
        row = read_json(checked(item))
        if row["retained"] is None:
            continue
        profile = PRIORS[row["profile"]]
        local, outside, _, _, _, _ = sample(row["geometry"], profile, row["seed"], row["partial"])
        with np.load(checked(row["retained"]), allow_pickle=False) as f:
            arrays = {k: f[k] for k in f.files}
        x, y, w, h = (v // 2 for v in probe.BOX)
        packed_box = np.s_[:, y : y + h, x : x + w]
        scene = outside["matching"]
        variance = variance_map(scene, profile["shot"], profile["read"])
        colors = local["colors"][0].numpy()
        original = external_guide(scene.numpy(), variance.numpy(), colors, probe.BOX)
        for role in (0, 1):
            full = scene.clone()
            full[packed_box] = local["packed"][role]
            noise = variance.clone()
            noise[packed_box] = local["variance"][role]
            assert external_guide(full.numpy(), noise.numpy(), colors, probe.BOX) == original
            actual = refine_isolated_raw_line(
                arrays["parent"][role], full.numpy(), noise.numpy(), colors, probe.BOX
            )
            np.testing.assert_array_equal(actual, arrays["local-veto"][role])
        compared.append(item)

    neutral = read_json(INITIAL / "standing/result.json")
    prior = read_json(checked(neutral["native_input_plan"]))
    arrays = {value["id"]: value for value in prior["observations"]}
    for row in neutral["results"]:
        observation = arrays[row["source_board"]["observation"]]
        with np.load(checked(observation["arrays"]), allow_pickle=False) as case:
            scene, noise, colors = map(lambda k: case[k][0], ("packed", "variance", "colors"))
        x, y, w, h = row["native_query"]
        parent = np.load(checked(row["parent"]), allow_pickle=False)[0, :, y : y + h, x : x + w]
        assert refine_isolated_raw_line(parent, scene, noise, colors, row["native_query"]) is parent
    assert len(compared) == 12 and len(neutral["results"]) == 8
    write_json(
        ROOT / "api-check.json",
        {
            "source": reference(__file__),
            "implementation": reference("src/demosaic/isolated_line.py"),
            "known_archive_cases": compared,
            "exact_composed_prototype_predictions": 2 * len(compared),
            "standing_api_parent_identity": len(neutral["results"]),
            "scope": "Replay native crops from the bound 2k EMA arrays. Whole-scene local RAW replacement preserves every fitted guide exactly.",
        },
    )
    print("Prototype binary equivalence on 24 retained role predictions and all 8 standing views.")


if __name__ == "__main__":
    main()
