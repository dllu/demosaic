"""Independent summary and native display for the two isolated line trials."""

import argparse
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint


def retained_check(record, arrays):
    roi = np.s_[..., 48:208, 48:208]
    q = arrays["quiet"][roi]
    gap = arrays["gap"][roi]
    target = arrays["target"].astype(float)[roi]
    full = arrays["full"].astype(float)[roi]
    parent = arrays["parent"].astype(float)[roi]
    delta = target[1] - target[0]
    visible = (np.abs(delta).max(0) > 1e-8) & q
    missing = (np.abs(full).max(0) > 1e-8) & q & gap
    norm = np.linalg.norm
    for method in [
        "parent",
        "whole",
        "segments-64",
        *(["local-veto"] if "local-veto" in arrays else []),
    ]:
        x = arrays[method].astype(float)[roi]
        score = record["measurements"][method if method == "parent" else "matching-" + method]
        increment = x[1] - x[0]
        role = x[0] - target[0]
        measured = {
            "increment_projection": np.dot(increment[:, q].flatten(), delta[:, q].flatten())
            / norm(delta[:, q]) ** 2,
            "false_projection": np.dot(role[:, q].flatten(), delta[:, q].flatten())
            / norm(delta[:, q]) ** 2,
            "quiet_RMS_DN16": 65535 * norm(role[:, q]) / np.sqrt(role[:, q].size),
            "wire_support_increment_RMS_DN16": 65535
            * norm((increment - delta)[:, visible])
            / np.sqrt(delta[:, visible].size),
        }
        if record["partial"]:
            added = (x[1] - parent[1])[:, missing]
            measured["partial_gap_added_RMS_DN16"] = 65535 * norm(added) / np.sqrt(added.size)
        for key, v in measured.items():
            np.testing.assert_allclose(v, score[key], rtol=4e-13, atol=2e-14)
    assert {k: fingerprint(arrays[k]) for k in record["fingerprints"]} == record["fingerprints"]


def report(root):
    raw = read_json(root / "result.json")
    plan = read_json(checked(raw["plan"]))
    records = [read_json(checked(p)) for p in raw["records"]]
    assert len(records) == 96
    assert len({(r["profile"], r["geometry"], r["repeat"], r["set"]) for r in records}) == 96
    out = root / "report"
    out.mkdir()
    buckets = defaultdict(list)
    boards = []
    audits = []
    for r in records:
        buckets[r["profile"], r["set"]].append(r)
        if r["retained"] is None:
            continue
        with np.load(checked(r["retained"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        retained_check(r, data)
        audits.append(r["id"])
        # Review the present wire or partially missing wire for every retained case.
        record = {
            "case": r["id"],
            "ROI_xywh": plan["ROI_xywh"],
            "sensor_seed": r["seed"],
            "noise": plan["priors"][r["profile"]],
            "checkpoint": plan["checkpoint"],
        }
        preview = ["parent", "whole", "segments-64"]
        labels = ["Local trunk", "Whole guide fit", "64px fits"]
        if "local-veto" in data:
            preview.append("local-veto")
            labels.append("Short support veto")
        # Bayer layout is serialized directly on the measured color index array.
        record["color_indices"] = data["colors"][0].tolist()
        local = {k: data[k][1:2] for k in ("packed", "colors", "wb", "matrix")}
        values = [noisy_malvar(local)[0], *[data[k][1] for k in preview], data["target"][1]]
        boards.append(
            native_board(
                out,
                r["id"],
                values,
                local,
                record,
                labels=("Noisy Malvar", *labels, "Exact GT"),
                triplet_indices=(0, len(values) - 2, len(values) - 1),
                exposure=1,
                contrast=8,
            )
        )
    summary = []
    for (profile, subset), cases in sorted(buckets.items()):
        assert len(cases) == 24
        names = list(cases[0]["measurements"])
        for name in names:
            d = [r["measurements"][name] for r in cases]
            row = {
                "noise": profile,
                "set": subset,
                "method": name,
                "weak_response_percent": 100 * mean(v["increment_projection"] for v in d),
                "weak_increment_RMS_DN16": mean(v["wire_support_increment_RMS_DN16"] for v in d),
                "quiet_RMS_DN16": mean(v["quiet_RMS_DN16"] for v in d),
                "mean_abs_whole_gap_projection_percent": 100
                * mean(abs(v["false_projection"]) for v in d),
                "whole_gap_modified": sum(v["modified_roles"][0] for v in d),
                "present_or_partial_modified": sum(v["modified_roles"][1] for v in d),
                "source_geometries_with_lower_increment_error": sum(
                    mean(
                        r["measurements"][name]["wire_support_increment_RMS_DN16"]
                        - r["measurements"]["parent"]["wire_support_increment_RMS_DN16"]
                        for r in cases
                        if r["geometry"] == g
                    )
                    < 0
                    for g in plan["geometries"]
                ),
            }
            if subset == "partial":
                row["mean_added_gap_RMS_DN16"] = mean(x["partial_gap_added_RMS_DN16"] for x in d)
                row["worst_added_gap_RMS_DN16"] = max(x["partial_gap_added_RMS_DN16"] for x in d)
                row["mean_abs_partial_gap_projection_percent"] = mean(
                    x["abs_partial_gap_projection_percent"] for x in d
                )
            summary.append(row)
    write_json(
        out / "result.json",
        {
            "reporter": reference(__file__),
            "source": reference(root / "result.json"),
            "summary": summary,
            "verified_retained_case_reductions": audits,
            "boards": boards,
            "native_viewing_complete": False,
        },
    )
    for row in summary:
        if row["method"] in (
            "parent",
            "matching-whole",
            "matching-segments-64",
            "matching-local-veto",
        ):
            print(row)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("root", type=Path)
    raw = p.parse_args()
    report(raw.root.resolve())
