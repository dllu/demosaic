"""Freeze a physical-only analysis before the complete palette is available."""
from pathlib import Path
import os,subprocess,sys
import psutil
from demosaic.experiments.artifacts import freeze_sources,reference,write_json
repo=Path.cwd();root=repo/'.cache/experiments/control20k-adc-palette-analysis-v1';root.mkdir();work,frozen=freeze_sources(repo,root,['analyze_adc_palette.py'])
source=repo/'.cache/experiments/control20k-full-adc-palette-v1';native=repo/'.cache/experiments/full-corpus-control20k-review-queue-v1/native20k'
watcher=root/'watcher.py';watcher.write_text((repo/'.cache/watch-adc-palette-analysis-v1.py').read_text());frozen[str(watcher)]=reference(watcher)['sha256']
plan={'root':str(root),'work':str(work),'frozen_files':frozen,'palette_plan':reference(source/'plan.json'),'palette_launch':reference(source/'launch.json'),'future_collection':str(source/'collection/result.json'),'legacy_native_plan':reference(native/'plan.json'),'legacy_native_collection':reference(native/'collection/result.json'),'worker':reference(work/'scripts/analyze_adc_palette.py'),'maximum_wait_seconds':21600,'producer':reference(__file__),'scope':'Wait for existing588-case neural collection,then all8 fixed raw/exact-MHC/sites/ADC-bin policies and retained physical arrays. No new neural/RAW/noise/GPU/training or automatic promotion; independent audit/native viewing separate.'};write_json(root/'queue-plan.json',plan)
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=str(work/'scripts')+':'+str(work/'src'))
with(root/'watcher.log').open('xb')as log:child=subprocess.Popen([sys.executable,str(watcher),str(root/'queue-plan.json')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'launch.json',{'producer':reference(__file__),'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'queue_plan':reference(root/'queue-plan.json')});print('Launched physical palette watcher',child.pid)
