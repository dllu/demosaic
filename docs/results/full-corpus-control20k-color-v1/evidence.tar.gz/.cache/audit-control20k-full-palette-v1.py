"""NumPy-only audit of every full-palette metric,ADC code and native pixel."""
import os,sys
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
assert 'torch'not in sys.modules and os.environ['CUDA_VISIBLE_DEVICES']=='';os.sched_setaffinity(0,[6,7]);os.nice(10)
r=Path('.cache/experiments/control20k-adc-palette-analysis-v1');result=read_json(r/'result.json');plan=read_json(checked(read_json(r/'analysis-plan.json')['palette_plan']));col=read_json(checked(read_json(r/'analysis-plan.json')['palette_collection']));cases={read_json(checked(v))['id']:read_json(checked(v))for v in col['records']};physical={(v['id'],v['model']):v for v in result['arrays']};rows={(v['id'],v['model'],v['policy']):v for v in result['metrics']};native=read_json(r/'native-v1/result.json');boards={v['id']:v for v in native['boards']};maxdelta=defaultdict(float);numeric=0;codechecks=0;pixels=0;counts=defaultdict(list)
def close(a,b,key):
 delta=float(np.max(np.abs(np.asarray(a)-np.asarray(b))));maxdelta[key]=max(maxdelta[key],delta);np.testing.assert_allclose(a,b,rtol=2e-12,atol=2e-10 if 'DN16'in key else 2e-15)
def encode(v):return np.rint(np.clip(v.astype(np.float32)*np.float32(.97)+np.float32(.03),0,1)*np.float32(65535)).astype(np.int64)
def linear(v,a):return np.einsum('bij,bjhw->bihw',a['matrix'].astype(np.float64),v.astype(np.float64)*a['wb'].astype(np.float64)[...,None,None])
for o in plan['observations']:
 with np.load(checked(o['arrays']))as f:a=dict(f)
 t=a['target'].astype(np.float64);assert np.array_equal(t,np.broadcast_to(t[...,:1,:1],t.shape))
 for variant in cases[o['id']]['variants']:
  model=variant['label'];values={'raw':np.load(checked(variant['prediction']))}
  with np.load(checked(physical[o['id'],model]['physical_arrays']))as f:values.update({k:f[k]for k in f.files})
  for phase,c in enumerate(a['colors'][0]):
   y,x=divmod(phase,2);measured=values['ADC-bins'][:,c,y::2,x::2];gt=t[:,c,y::2,x::2];before=values['raw'][:,c,y::2,x::2];codes=encode(a['packed'][:,phase])
   np.testing.assert_array_equal(encode(measured),codes);np.testing.assert_array_equal(encode(gt),codes);assert np.all((measured.astype(np.float64)-gt)**2<=(before.astype(np.float64)-gt)**2)
  codechecks+=1
  for policy,p in values.items():
   row=rows[o['id'],model,policy];error=p[...,48:208,48:208].astype(np.float64)-t[...,48:208,48:208];mean=error.sum((0,2,3))/(160*160);mse=float(np.sum(error*error)/error.size);centered=np.sqrt(np.sum((error-mean[None,:,None,None])**2)/error.size)
   close(mean,row['camera_RGB_mean_error'],'mean');close(mse,row['camera_RGB_MSE'],'MSE');close(centered,row['spatially_centered_camera_RGB_RMS'],'RMS');close(max(abs(mean))*65535,row['mean_bias_DN16'],'bias_DN16');close(centered*65535,row['centered_RMS_DN16'],'centered_DN16');counts[model,policy].append(row);numeric+=1
  for view in ['standard','error']:
   key=o['id']+'-'+model+'-'+view
   if key not in boards:continue
   b=boards[key];image=np.asarray(Image.open(checked(b['image'])));assert image.shape==(192,1016,3)
   vs=[noisy_malvar(a),values['raw'],values['exact-Malvar'],values['exact-sites'],values['ADC-bins'],t]
   for v,panel,clip in zip(vs,b['panels'],b['clipping'],strict=True):
    rgb=linear(v,a)[...,48:208,48:208]
    if view=='error':rgb=.18+b['error_gain']*(rgb-linear(t,a)[...,48:208,48:208])
    close(np.mean((rgb<0)|(rgb>1)),clip['fraction'],'clipping');rgb=np.clip(rgb,0,1);rgb=np.where(rgb<=.0031308,12.92*rgb,1.055*rgb**(1/2.4)-.055);pixel=np.rint(rgb[0].transpose(1,2,0)*255).astype(np.uint8);x,y,w,h=panel['png_xywh'];assert(w,h)==(160,160);np.testing.assert_array_equal(image[y:y+h,x:x+w],pixel);pixels+=pixel.size
for v in result['summary']:
 values=counts[v['model'],v['policy']];assert len(values)==588
 bias=max(values,key=lambda v:v['mean_bias_DN16']);spatial=max(values,key=lambda v:v['centered_RMS_DN16']);assert bias['id']==v['max_bias_case']and spatial['id']==v['max_centered_RMS_case'];close(bias['mean_bias_DN16'],v['max_bias_DN16'],'maxbias_DN16');close(spatial['centered_RMS_DN16'],v['max_centered_RMS_DN16'],'maxcenter_DN16');close(np.mean([v['camera_RGB_MSE']for v in values]),v['mean_camera_RGB_MSE'],'meanMSE')
for t in native['triplets']:
 b=boards[t['board']];image=np.asarray(Image.open(checked(t['image'])));base=np.asarray(Image.open(checked(b['image'])))
 for panel,i in zip(t['panels'],t['parent_indices'],strict=True):
  x,y,w,h=panel['png_xywh'];xx,yy,ww,hh=b['panels'][i]['png_xywh'];np.testing.assert_array_equal(image[y:y+h,x:x+w],base[yy:yy+hh,xx:xx+ww])
assert numeric==4704 and codechecks==1176 and pixels==8*6*160*160*3
out=r/'independent-audit-v1';out.mkdir();write_json(out/'result.json',{'producer':reference(__file__),'analysis':reference(r/'result.json'),'native':reference(r/'native-v1/result.json'),'metric_rows':numeric,'actual_ADC_bin_outputs_reencoded_and_measured_error_nonincreasing':codechecks,'native_boards':8,'native_channels':pixels,'triplets_exact_subsets':4,'maximum_discrepancies':dict(maxdelta),'status':'passed','scope':'Independent NumPy64 whole588-case/8policy color sums and worst-case identities;CPU-FP32 encoding of all corrected/GT measured samples,actual site-error nonincrease;all8 native boards/4triplet subsets. No Torch/neural/GPU/RAW/noise/training calls. Independent full RGB/MSE guarantee is not implied by measured-site feasibility.'});print('Audit passed',numeric,'rows',codechecks,'physical outputs',dict(maxdelta))
