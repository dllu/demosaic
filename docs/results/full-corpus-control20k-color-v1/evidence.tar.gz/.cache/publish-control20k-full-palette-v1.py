"""Publish exact full-palette evidence without model/large array duplication."""
import gzip,io,tarfile,shutil
from pathlib import Path
from datetime import datetime,timezone
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
repo=Path.cwd();r=repo/'.cache/experiments/control20k-adc-palette-analysis-v1';source=repo/'.cache/experiments/control20k-full-adc-palette-v1';result=read_json(r/'result.json');assert read_json(r/'independent-audit-v1/result.json')['status']=='passed'and read_json(r/'actual-native-viewing-v1.json')['actual_native_boards']==8
out=repo/'docs/results/full-corpus-control20k-color-v1';out.mkdir();images=repo/'docs/images/full-corpus-control20k-color-v1';images.mkdir();assets=[];native=read_json(r/'native-v1/result.json')
for row in native['boards']+native['triplets']:
 original=checked(row['image']);dest=images/original.name;shutil.copyfile(original,dest);assert reference(dest)['sha256']==row['image']['sha256'];assets.append({**row,'image':reference(dest),'original_image':row['image']})
write_json(images/'manifest.json',{'images':assets,'models':read_json(source/'plan.json')['models'],'actual_viewing':reference(r/'actual-native-viewing-v1.json'),'scope':'Exact original8 actually viewed native boards plus4 subset triplets. Source/ROI/ADCbit/black/CPU arithmetic/WB/matrix/EMA/source selection/display retained. Adverse cases selected after full-grid scoring;all8 policies measured over all588 cases. Error views share gains32(red)/8(purple) aroundlinear.18,not independent method normalization.'})
files=[p for p in r.iterdir()if p.is_file()and p.name not in ['status.json','progress.json','watcher.log']]
files +=[r/'native-v1/result.json',r/'independent-audit-v1/result.json']
files +=[p for p in(r/'work').rglob('*.py')if'__pycache__'not in p.parts]
files +=[source/'plan.json',source/'launch.json',source/'collection.log',source/'collection/result.json']
files +=[checked(v)for v in read_json(source/'collection/result.json')['records']]
files +=[p for p in(source/'work').rglob('*.py')if'__pycache__'not in p.parts]
for stem in ['prepare-control20k-full-color-v1','prepare-adc-palette-analysis-v1','watch-adc-palette-analysis-v1','report-control20k-full-palette-v1','audit-control20k-full-palette-v1']:
 files +=[p for p in(repo/'.cache').glob(stem+'.*')if p.suffix in ['.py','.log']]
files +=[Path(__file__).resolve()];paths=sorted(set(p.resolve()for p in files));archive=out/'evidence.tar.gz';members=[]
with archive.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
 for p in paths:
  data=p.read_bytes();name=str(p.relative_to(repo));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'source':reference(p),'member':name})
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(members)
 for v in members:assert tar.extractfile(v['member']).read()==Path(v['source']['path']).read_bytes()
for src,name in [(r/'result.json','report.json'),(r/'independent-audit-v1/result.json','independent-audit.json'),(r/'actual-native-viewing-v1.json','actual-native-viewing.json'),(source/'collection/result.json','neural-collection.json')]:shutil.copyfile(src,out/name)
write_json(out/'summary.json',{'models':read_json(source/'plan.json')['models'],'summary':result['summary'],'neural_collection_seconds':read_json(source/'collection/result.json')['seconds'],'scope':'All588 ADC-only inputs/147 colors/four CFAs,all8 fixed model/physical policies.4704 color rows,1176 actual ADC-bin feasibility/error checks. Neural1176 roots/588DINOexec/588replays;no new learning/GPU/RAW/noise. Physical3528 corrections retained locally with hashes; no general fine/photo score.'})
write_json(out/'publication.json',{'recorded_UTC':datetime.now(timezone.utc).isoformat(),'producer':reference(__file__),'archive':reference(archive),'all_archive_bytes_verified':True,'members':members,'native_manifest':reference(images/'manifest.json'),'numerical_complete':True,'independent_audit_complete':True,'actual_native_viewing_complete':True,'scope':'Complete588-case/8policy color validation. Raw20k worst mean bias765.656DN16 versusV12055.525;exact-MHC17.325/ADC-bins17.767 for20k. V120 bins improves measured aggregate bias/spatial/MSE versusexact-MHC;not everycase/metric dominance. All1176 bin outputs/targets reencode and siteerror nonincreases;missing colors have no bound.16 raw outputs bitexact old native controls.8 native boards actually viewed/4 exact-subset triplets. No default/history change;expanded427-photo faint test still running. Weights/largearrays remain local,originalsources/receipts preserved.'});print('Published',len(paths),'exactfiles/12nativePNGs;archive MiB',archive.stat().st_size/2**20)
