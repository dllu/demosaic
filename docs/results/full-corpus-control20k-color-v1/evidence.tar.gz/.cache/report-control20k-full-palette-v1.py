"""Native adverse-tail views; same transform for every method within a case."""
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from demosaic.archive_metrics import linear_rgb,noisy_malvar
from demosaic.experiments.artifacts import read_json,checked,reference,write_json
r=Path('.cache/experiments/control20k-adc-palette-analysis-v1').resolve();result=read_json(r/'result.json');plan=read_json(checked(read_json(r/'analysis-plan.json')['palette_plan']));collection=read_json(checked(read_json(r/'analysis-plan.json')['palette_collection']));raw={read_json(checked(v))['id']:read_json(checked(v))for v in collection['records']};physical={(v['id'],v['model']):v for v in result['arrays']}
out=r/'native-v1';out.mkdir();boards=[];triplets=[]
# These are post-hoc adverse-tail selections,not new favorable validation cases.
for identity,gain in [('h000-s0.50-l0.90-RGGB',32),('h285-s0.50-l0.90-GRBG',8)]:
 o=next(o for o in plan['observations']if o['id']==identity)
 with np.load(checked(o['arrays']))as f:a=dict(f)
 target=a['target'];roi=[48,48,160,160]
 for model in plan['models']:
  variant=next(v for v in raw[identity]['variants']if v['label']==model);values={'raw':np.load(checked(variant['prediction']))}
  with np.load(checked(physical[identity,model]['physical_arrays']))as f:values.update({k:f[k]for k in f.files})
  order=[('Noisy Malvar',noisy_malvar(a)),('Raw EMA',values['raw']),('Exact Malvar',values['exact-Malvar']),('Exact sites',values['exact-sites']),('ADC bins',values['ADC-bins']),('Exact constant GT',target)]
  for view in ['standard','error']:
   image=Image.new('RGB',(1016,192),'#eeeeee');draw=ImageDraw.Draw(image);panels=[];clipping=[];cells=[]
   for i,(label,value)in enumerate(order):
    v=linear_rgb(value,a)[...,48:208,48:208]
    if view=='error':v=.18+gain*(v-linear_rgb(target,a)[...,48:208,48:208])
    clipping.append({'label':label,'fraction':float(np.mean((v<0)|(v>1)))})
    v=v.clip(0,1);v=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055);pixel=np.rint(v[0].transpose(1,2,0)*255).astype(np.uint8);assert pixel.shape==(160,160,3);cells.append(pixel)
    x=8+168*i;draw.text((x,5),label,fill='black');image.paste(Image.fromarray(pixel),(x,24));panels.append({'label':label,'png_xywh':[x,24,160,160]})
   dest=out/(identity+'-'+model+'-'+view+'.png');image.save(dest);boards.append({'id':identity+'-'+model+'-'+view,'image':reference(dest),'panels':panels,'source':o,'model':plan['models'][model],'ROI_xywh':roi,'view':view,'error_gain':gain if view=='error'else None,'display_exposure':1,'clipping':clipping,'selection':'Post-hoc maximum raw mean-bias case for V120 or20k across the complete588-case grid;both models shown at each.','reference_role':'Exact constructed constant target;no real-scene GT claim.'})
   if view=='standard':
    t=Image.new('RGB',(512,192),'#eeeeee');d=ImageDraw.Draw(t);tp=[]
    for j,k in enumerate([0,4,5]):x=8+168*j;t.paste(Image.fromarray(cells[k]),(x,24));d.text((x,5),order[k][0],fill='black');tp.append({'label':order[k][0],'png_xywh':[x,24,160,160]})
    dest=out/(identity+'-'+model+'-triplet.png');t.save(dest);triplets.append({'id':identity+'-'+model+'-triplet','image':reference(dest),'board':boards[-1]['id'],'panels':tp,'parent_indices':[0,4,5]})
assert len(boards)==8 and len(triplets)==4
write_json(out/'result.json',{'producer':reference(__file__),'analysis':reference(r/'result.json'),'boards':boards,'triplets':triplets,'actual_viewing':'pending','scope':'Two post-hoc adverse raw-color tails,all4 policies under both EMA models,standard and shared per-case error views.160native pixels,no resizing,exposure1,same color transform. Error gains32(red)/8(purple) aroundlinear.18 use target for display only;record clipping.4 exact-subset ADC-bin triplets.0 neural/GPU/RAW/noise/training work.'});print('Rendered8 native boards/4triplets')
