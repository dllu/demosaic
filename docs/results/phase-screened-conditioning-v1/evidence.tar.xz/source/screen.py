"""Screen sharper Local 50k proposals against fixed held-Bayer junction shape."""

from pathlib import Path

import numpy as np
from scipy.ndimage import map_coordinates

from demosaic import _mesh_junction as mesh
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers, _sites, _spacing

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ARMS = (
    "baseline",
    "raw",
    "strong",
    "mild",
    "raw-local-band",
    "strong-local-band",
    "mild-local-band",
)
PAIRS = ((0, 1), (0, 2), (1, 2))
CORE = np.s_[..., 48:208, 48:208]
NODES = mesh._NODES
CENTRAL = np.s_[..., 48:208, 48:208]


def crop(image, roi):
    x, y, w, h = roi
    return image[..., y : y + h, x : x + w]


def fit_nodes(obs, design, index, sign, maximum, current, alternate):
    """Estimate RAW and neural amplitudes in the same native green coordinates."""
    px = (obs.x + mesh._CENTER).astype(int)
    py = (obs.y + mesh._CENTER).astype(int)
    names = ("raw", *alternate)
    data = np.column_stack((obs.raw, current[py, px], *[v[py, px] for v in alternate.values()]))
    inputs = np.maximum(abs(obs.x), abs(obs.y)) <= 101
    panels = []
    nodes = []
    for y, x in NODES:
        distance = (obs.x - x) ** 2 + (obs.y - y) ** 2
        window = np.exp(-0.5 * distance / 30**2) / obs.variance
        rows, variances = [], []
        for fold in (1, 2, 3):
            selected = inputs & (obs.fold == fold) & (distance <= 72**2)
            a = design[selected]
            weight = a.T * window[selected]
            cov = np.linalg.pinv(weight @ a, hermitian=True, rcond=1e-9)
            rows.append((sign * cov[index] @ weight) @ data[selected])
            variances.append(float(cov[index, index]))
        rows = np.asarray(rows)
        variances = np.asarray(variances)
        votes = np.maximum(0, rows[:, 0])
        positive = np.mean([votes[a] * votes[b] for a, b in PAIRS])
        floor = np.mean([np.sqrt(variances[a] * variances[b]) for a, b in PAIRS])
        avg = np.average(rows, axis=0, weights=1 / variances)
        # Preserve sign and give lower-confidence independent folds no amplitude bonus.
        leave = float(np.maximum(0, 1 - floor / max(1e-20, positive)))
        if np.count_nonzero(rows[:, 0] > 0) < 2:
            leave = 0
        ceiling = np.clip(leave * avg[0] - max(0, avg[1]), 0, 1.5 * maximum)
        estimate = np.clip(np.r_[ceiling, avg[2:] - avg[1]], 0, ceiling)
        nodes.append(estimate)
        panels.append([float(v * 65535) for v in avg] + [float(ceiling * 65535), leave])
    gy, gx = (mesh._GRID_Y + 72) / 48, (mesh._GRID_X + 72) / 48
    fields = [
        map_coordinates(row.reshape(4, 4), [gy, gx], order=1, mode="nearest", prefilter=False)
        for row in np.asarray(nodes).T
    ]
    return dict(zip(names, fields, strict=True)), panels


def local_difference(obs, design, target, sign):
    """Require the signed difference itself after fitting the rival bands."""
    held = mesh._held_stations()
    # Each support estimate uses the same 16 pixels per axis in both physical lattices.
    x, y = obs.x[held], obs.y[held]
    u = (x - x.mean(axis=-1, keepdims=True)) / 16
    v = (y - y.mean(axis=-1, keepdims=True)) / 16
    polynomial = np.stack((np.ones_like(u), u, v, u * u, v * v, u * v), axis=-1)
    other = np.delete(design, target, axis=-1)
    w = 1 / np.sqrt(obs.variance[held])
    possible = np.concatenate((polynomial, other[held]), axis=-1) * w[..., None]
    signal = sign * design[held, target] * w
    # SVD excludes dependent nuisance columns, including a degenerate aliased harmonic.
    q, s, _ = np.linalg.svd(possible, full_matrices=False)
    z = (q.swapaxes(-1, -2) @ signal[..., None])[..., 0]
    z = np.where(s > 1e-8 * s[..., :1], z, 0)
    residue = signal - (q @ z[..., None])[..., 0]
    moment = np.sum(residue * w * obs.raw[held], axis=-1)
    norm = np.sum(residue**2, axis=-1)
    site = moment / np.sqrt(np.maximum(1e-12, norm))
    pooled = moment.sum(axis=0) / np.sqrt(np.maximum(1e-12, norm.sum(axis=0)))
    support = np.clip(np.minimum(pooled, site.min(0) + 1.5) / 1.5, 0, 1)
    own = support.reshape(10, 10).repeat(16, axis=0).repeat(16, axis=1)
    return np.minimum(mesh._pixel_map(support), own)


def prepare(scene, colors, origin, shot, read, clearance):
    x, y = origin[:2]
    f = _spacing(scene, colors, x, y, clearance=clearance)
    if f is None:
        return None
    accepted = mesh._distinct_bands(f)
    if mesh._DIFFERENCE not in accepted:
        return None
    x -= 48
    y -= 48
    packed = np.stack([_sites(scene, x, y, 256, r, c) for r, c in np.ndindex(2, 2)])
    greens = [
        2 * r + c for r, c in np.ndindex(2, 2) if colors[2 * ((y + r) % 2) + (x + c) % 2] == 1
    ]
    obs = mesh._Observation.make(packed, greens, f, shot, read)
    guide = mesh._discovery(obs, accepted)
    return (f, obs, guide) if guide is not None else None


def apply(parent, local, scene, colors, origin, noise, wb, matrix, alternate, *, clearance=48):
    """Keep the packaged fit and add only a RAW-aligned, RAW-capped sideband."""
    x, y, w, h = local
    context = crop(parent, (x - 48, y - 48, 256, 256))
    shot, read = noise["shot"], noise["read"]
    anchor = refine_raw_mesh_carriers(
        crop(parent, local),
        scene,
        colors,
        origin,
        shot=shot,
        read=read,
        white_balance=wb,
        camera_to_srgb=matrix,
        method="weak-junction-phase",
        parent_context=context,
        donor_clearance=clearance,
    )
    nomination = prepare(scene, colors, origin, shot, read, clearance)
    if nomination is None:
        return dict.fromkeys(ARMS, anchor), {"admitted": False}
    f, obs, g = nomination
    phase, base, harmonics, index, sign, maximum = g
    known = obs.angles + phase
    wire = mesh._local_wire_support(obs, known)
    r = harmonics.reshape(len(base), -1)
    target = 2 * index
    local_gate = local_difference(
        obs,
        np.column_stack((mesh._quadratures(obs.angles).reshape(len(base), 4), r)),
        4 + target,
        sign,
    )
    current = context[1].copy()
    current[CORE] = anchor[1]
    patch = {k: crop(a, (x - 48, y - 48, w + 96, h + 96)) for k, a in alternate.items()}
    fields, panels = fit_nodes(
        obs, np.column_stack((base, r)), base.shape[1] + target, sign, maximum, current, patch
    )
    angles = mesh._wave_angles(mesh._GRID_X, mesh._GRID_Y, f) + phase
    wave = sign * np.cos(angles[..., 0] - angles[..., 1])
    wave *= mesh._FIELD_EDGE[:, None] * mesh._FIELD_EDGE
    c = np.linalg.solve(matrix.astype(float), np.ones(3)) / wb
    c /= c[1]
    options = {"baseline": anchor}
    for name, v in fields.items():
        update = mesh._GAINS * wire * (v * wave)[CORE]
        for suffix, m in (("", 1), ("-local-band", local_gate)):
            options[f"{name}{suffix}"] = (anchor + c[:, None, None] * (update * m)).astype(
                anchor.dtype
            )
    return options, {
        "admitted": True,
        "phase": phase.tolist(),
        "frequency": f.tolist(),
        "sign": sign,
        "candidate_DN16": maximum * 65535,
        "calibrated_nodes_DN16": panels,
        "wire_fraction": float(wire.mean()),
        "difference_fraction": float(local_gate.mean()),
    }
