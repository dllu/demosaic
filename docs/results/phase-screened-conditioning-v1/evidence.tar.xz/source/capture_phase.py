"""Capture independent signed-junction fixtures with varying contrast."""

from pathlib import Path
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
CALIBRATION = OUT.with_name("local-junction-support-v1") / "independent"
sys.path.append(str(HERE.parent / "local-junction-support-v1"))
import capture_junction as source

SEED = 202611200733
COUNT = 24
CLEAN = source.clean_scenes
ENGINE = source.source.last.run


def select(root):
    ENGINE.OUT = root
    ENGINE.SEED = SEED
    ENGINE.COUNT = COUNT
    ENGINE.prior.EXCLUSIONS += (
        source.ORIGINAL,
        CALIBRATION / "plan.json",
        CALIBRATION.with_name("calibration") / "plan.json",
        OUT.with_name("cfa-junction-phase-v1") / "held/plan.json",
        *(
            OUT.with_name("local-replicated-phase-v1") / g / "plan.json"
            for g in ("fresh", "verification", "station-confirm")
        ),
        OUT.with_name("local-unranked-phase-v1") / "fresh/plan.json",
        OUT.with_name("local-near-phase-v1") / "fresh/plan.json",
    )
    plan = ENGINE.freeze()
    for record in plan["sources"]:
        i = record["index"]
        g = record["geometry"]
        rng = np.random.default_rng(scene_seed(SEED, i, "uneven-junction"))
        g["interaction_ratio"] = float(rng.uniform(0.5, 1.05))
        g["relative_interaction_polarity"] = 1 if (i + i // 6) % 2 else -1
        g["strength"][1] = float(g["strength"][0] * rng.uniform(0.65, 1.22))
        g["interaction_contrast_floor"] = float(rng.uniform(0.3, 0.6))
        g["contrast_offset_xy"] = rng.uniform(-52, 52, 2).tolist()
        record["id"] = f"screened-{i:02d}"
    return plan | {
        "driver": reference(__file__),
        "roles": source.ROLES,
        "seed": SEED,
        "earlier_source": reference(CALIBRATION / "plan.json"),
        "scope": "Source-disjoint ISO6400 junctions with a smooth polarized contrast variation and the original matched additive controls.",
    }


def clean(case):
    scenes, support, attachment = CLEAN(case)
    geometry = case["geometry"]
    dx, dy = geometry["contrast_offset_xy"]
    axis = torch.arange(512) - 255.5
    v, u = torch.meshgrid(axis - dy, axis - dx, indexing="ij")
    low = geometry["interaction_contrast_floor"]
    strength = 1.05 - (1.05 - low) * torch.exp(-0.5 * ((u / 50) ** 2 + (v / 35) ** 2))
    exact = scenes[1] + strength * (scenes[0] - scenes[1])
    return (exact, *scenes[1:]), support, attachment


def main():
    torch.set_num_threads(2)
    root = OUT / "independent"
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    plan_file = root / "plan.json"
    if not plan_file.exists():
        write_json(plan_file, select(root))
    plan = read_json(plan_file)
    assert plan["driver"] == reference(__file__)
    observations = root / "inputs.json"
    if not observations.exists():
        start = monotonic()
        rows = []
        with patch.object(source, "clean_scenes", clean):
            for record in plan["sources"]:
                rows.append(
                    {
                        "id": record["id"],
                        "streams": list(
                            source.save_case(
                                record, SEED, plan["noise"], plan["sigma"], root / "inputs"
                            )
                        ),
                    }
                )
                if len(rows) % 8 == 0:
                    print("Photographic captures", len(rows), flush=True)
        write_json(
            observations,
            {
                "driver": reference(__file__),
                "plan": reference(plan_file),
                "observations": rows,
                "seconds": monotonic() - start,
            },
        )
    ENGINE.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        ENGINE.prior.parents.main()


if __name__ == "__main__":
    main()
