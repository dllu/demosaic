"""Native exact-target and GFX review of the locked refit and neural alternatives."""

from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import screen as op
from replay_screen import metrics

sys.path.append(str(op.HERE.parent / "local-junction-support-v1"))
from review_junction import image, board

OUT = op.OUT
DISPLAY_KEYS = ("baseline", "raw", "strong", "comparable")
LABELS = ("Checked sideband", "Regional RAW refit", "Screened low-noise", "RAW at aligned strength")


def apply(outputs, dose):
    base = outputs["baseline"]
    return outputs | {
        "comparable": (base + dose * (outputs["raw"].astype(np.float64) - base)).astype(base.dtype)
    }


def exact(data, dose, room):
    replay = read_json(checked(data))
    plan = read_json(checked(replay["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    local = 48, 48, 160, 160
    roi = x + 48, y + 48, 160, 160
    picked = {}
    for row in replay["rows"]:
        for d in row["draws"]:
            baseline = metrics.values(d, ("baseline", 1))
            updated = metrics.values(d, ("raw", 1))
            j = baseline[metrics.JUNCTION] - updated[metrics.JUNCTION]
            kind = (
                "largest gap leakage"
                if metrics.GAP in updated
                else "largest intact junction reduction"
            )
            merit = updated[metrics.GAP] if metrics.GAP in updated else j
            if kind not in picked or merit > picked[kind][0]:
                picked[kind] = (merit, row, d)
    assert len(picked) == 2
    records = []
    for kind, (value, row, draw) in picked.items():
        with np.load(checked(draw["input"]), allow_pickle=False) as f:
            inputs = {k: f[k] for k in f.files}
        with np.load(checked(draw["alternate"]), allow_pickle=False) as f:
            variants = {k: f[k][0] for k in f.files}
        model = np.load(checked(draw["nominal"]), allow_pickle=False)[0]
        colors, wb, matrix = (inputs[k] for k in ("colors", "wb", "matrix"))
        scene = inputs["scene_packed"].copy()
        scene[cut] = inputs["packed"][0]
        outputs, trace = op.apply(
            model, local, scene, colors, roi, plan["noise"], wb, matrix, variants
        )
        predictions = apply(outputs, dose)
        noisy = noisy_malvar(
            {
                "packed": inputs["packed"][:1],
                **{k: inputs[k][None] for k in ("colors", "wb", "matrix")},
            }
        )[0]
        rgb = [
            ("Noisy Malvar", op.crop(noisy, local)),
            ("Local 50k nominal", op.crop(model, local)),
        ]
        rgb.extend((label, predictions[k]) for label, k in zip(LABELS, DISPLAY_KEYS, strict=True))
        rgb.append(("Exact GT", op.crop(inputs["target"][0], local)))
        cells = [(label, image(im, wb, matrix, 2.0)) for label, im in rgb]
        triplet = board(
            [cells[i] for i in (0, 3, len(cells) - 1)], room / f"{row['id']}-triplet.png"
        )
        compare = board(cells, room / f"{row['id']}-comparison.png")
        records.append(
            {
                "id": row["id"],
                "input": draw["input"],
                "draw": draw["draw"],
                "nominal": draw["nominal"],
                "alternate": draw["alternate"],
                "source": row["fixture"],
                "policy": kind,
                "criterion_DN16": value,
                "exposure": 2.0,
                "noise": plan["noise"],
                "sigma": plan["sigma"],
                "ROI": local,
                "query": plan["query"],
                "triplet": triplet,
                "board": compare,
                "trace": trace,
            }
        )
        print(row["id"], kind, value, flush=True)
    return {"source": data, "rows": records}


def camera(room, dose):
    alternate = reference(OUT / "alternate-camera.json")
    alt = read_json(checked(alternate))
    data = read_json(checked(alt["source"]))
    records = []
    for r, v in zip(data["standing"], alt["rows"], strict=True):
        assert r["id"] == v["id"] and r["input"] == v["input"]
        with np.load(checked(r["input"]), allow_pickle=False) as f:
            raw, colors, wb, matrix = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        with np.load(checked(v["green"]), allow_pickle=False) as f:
            options = {k: f[k][0] for k in f.files}
        nominal = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = r["local_ROI"]
        outputs, trace = op.apply(
            nominal, roi, raw, colors, roi, r["noise"], wb, matrix, options, clearance=16
        )
        predictions = apply(outputs, dose)
        change = {
            k: float(np.sqrt(np.mean((v.astype(float) - predictions["baseline"]) ** 2)) * 65535)
            for k, v in predictions.items()
        }
        views = []
        for former in r["displays"]:
            with Image.open(checked(former["board"]["image"])) as o:
                pixels = np.asarray(o)
            cells = {}
            for item in former["board"]["panels"]:
                x, y, w, h = item["png_xywh"]
                cells[item["name"]] = pixels[y : y + h, x : x + w]
            exp = former["exposure"]
            np.testing.assert_array_equal(
                image(op.crop(nominal, roi), wb, matrix, exp), cells["Local 50k"]
            )
            tiles = [(name, cells[name]) for name in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            tiles.extend(
                (label, image(predictions[k], wb, matrix, exp))
                for label, k in zip(LABELS, DISPLAY_KEYS, strict=True)
            )
            tiles.extend(
                (key, cells[key])
                for key in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if key in cells
            )
            views.append(
                board(tiles, room / f"{r['id']}-x{exp:g}.png")
                | {"exposure": exp, "previous": former["board"]}
            )
        records.append(
            {
                "id": r["id"],
                "input": r["input"],
                "RAW": r["raw"],
                "nominal": r["predictions"]["local50k"],
                "alternate": v["green"],
                "noise": r["noise"],
                "sensor_ROI": r["global_ROI"],
                "local_ROI": roi,
                "native": views,
                "changed_DN16": change,
                "trace": trace,
            }
        )
        print(r["id"], [round(change[k], 4) for k in ("raw", "strong")], flush=True)
    return {"source": alternate, "rows": records}


if __name__ == "__main__":
    torch.set_num_threads(2)
    kind = sys.argv[1]
    base = reference(OUT / "replay-independent.json")
    data = read_json(checked(base))
    policy = data["summary"]["policies"]
    assert policy["neural"] == ["strong", 1.0] and policy["raw"] == ["raw", 1.0]
    dose = policy["raw_matched"][1]
    folder = OUT / "native" / kind
    folder.mkdir(exist_ok=True, parents=True)
    result = exact(base, dose, folder) if kind == "exact" else camera(folder, dose)
    write_json(
        OUT / f"review-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "calibration": data["calibration"],
            "scored_source": base,
            "comparable_dose": dose,
            "review": result,
        },
    )
