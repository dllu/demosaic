"""Compare neural amplitude proposals and a matched RAW-only correction."""

from pathlib import Path
import sys
from time import monotonic
from unittest.mock import patch

import numpy as np

import screen as method
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

sys.path.append(str(method.HERE.parent / "local-junction-support-v1"))
import replay_junction as metrics

OUT = method.OUT
ARMS = method.ARMS
PRIMARY = ("baseline", 1.0)
LIMITS = {"mean_gap": 0.15, "mean_additive": 0.075, "peak_quiet": 0.50}


def paths(group):
    alternate = reference(OUT / f"alternate-{group}.json")
    binding = read_json(checked(alternate))
    original = binding["source"]
    receipt = read_json(checked(original))
    inputs = read_json(checked(receipt["inputs"]))
    return alternate, receipt, binding, inputs["plan"]


def collect(group):
    start = monotonic()
    alternative, frozen, alt, planref = paths(group)
    plan = read_json(checked(planref))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    local = 48, 48, 160, 160
    roi = x + 48, y + 48, 160, 160
    rows = []
    alternate = iter(alt["rows"])
    for case, record in zip(plan["sources"], frozen["records"], strict=True):
        assert case["id"] == record["id"]
        output = []
        for stream in record["streams"]:
            alternative_stream = next(alternate)
            assert (
                alternative_stream["id"],
                alternative_stream["draw"],
                alternative_stream["input"],
            ) == (case["id"], stream["draw"], stream["data"])
            with np.load(checked(stream["data"]), allow_pickle=False) as f:
                data = {key: f[key] for key in f.files}
            with np.load(checked(alternative_stream["green"]), allow_pickle=False) as f:
                greens = {key: f[key] for key in f.files}
            parent = np.load(checked(stream["outputs"]["local50k"]), allow_pickle=False)
            streams = iter(range(len(parent)))

            class Adapter:
                ARMS = method.ARMS

                @staticmethod
                def apply(*args, **kwargs):
                    role = next(streams)
                    k = {name: rgb[role] for name, rgb in greens.items()}
                    return method.apply(*args, **kwargs, alternate=k)

            with patch.object(metrics, "model", Adapter):
                scores = metrics.assess(
                    case, plan["noise"], parent, data, data["scene_packed"].copy(), cut, local, roi
                )
            output.append(
                scores
                | {
                    "draw": stream["draw"],
                    "input": stream["data"],
                    "nominal": stream["outputs"]["local50k"],
                    "alternate": alternative_stream["green"],
                }
            )
        rows.append(
            {
                "id": case["id"],
                "fixture": case,
                "family": case["geometry"]["family"],
                "draws": output,
            }
        )
        if len(rows) % 8 == 0:
            print(group, len(rows), flush=True)
    assert next(alternate, None) is None
    return {"alternate": alternative, "plan": planref, "rows": rows, "seconds": monotonic() - start}


def within(summary):
    avg = summary["means"]
    return (
        avg[metrics.GAP] <= LIMITS["mean_gap"]
        and max(avg[metrics.ADD], avg[metrics.CONTINUOUS_ADD]) <= LIMITS["mean_additive"]
        and max(summary["peak"][k] for k in metrics.QUIET) <= LIMITS["peak_quiet"]
    )


def freeze(rows):
    def options(k):
        candidates = []
        for a in np.linspace(0, 1, 21):
            stats = metrics.score(rows, (k, float(a)))
            candidates.append({"key": (k, float(a)), "fits": within(stats), "scores": stats})
        chosen = max(
            (r for r in candidates if r["fits"]),
            key=lambda r: (
                r["scores"]["means"][metrics.RESPONSE],
                -r["scores"]["means"][metrics.JUNCTION],
            ),
        )
        return {"trials": candidates, "locked": chosen}

    methods = {k: options(k) for k in ARMS[1:]}
    best = lambda keys: max(
        (methods[k]["locked"] for k in keys),
        key=lambda r: (
            r["scores"]["means"][metrics.RESPONSE],
            -r["scores"]["means"][metrics.JUNCTION],
        ),
    )
    return {
        "limits": LIMITS,
        "methods": methods,
        "raw": best(k for k in methods if k.startswith("raw")),
        "neural": best(k for k in methods if not k.startswith("raw")),
    }


def summarize(rows, lock):
    forecast = {"baseline": PRIMARY, **{k: lock[k]["key"] for k in ("raw", "neural")}}
    completed = {k: metrics.score(rows, v) for k, v in forecast.items()}
    reference = completed["baseline"]["means"][metrics.RESPONSE]
    best = completed["neural"]["means"][metrics.RESPONSE]
    raw = metrics.score(rows, (forecast["raw"][0], 1.0))["means"][metrics.RESPONSE]
    if 0 < best - reference <= raw - reference:
        forecast["raw_matched"] = (forecast["raw"][0], (best - reference) / (raw - reference))
        completed["raw_matched"] = metrics.score(rows, forecast["raw_matched"])
    else:
        forecast["raw_full"] = (forecast["raw"][0], 1.0)
        completed["raw_full"] = metrics.score(rows, forecast["raw_full"])
    for key in ARMS[1:]:
        forecast[f"full-{key}"] = (key, 1)
        completed[f"full-{key}"] = metrics.score(rows, forecast[f"full-{key}"])
    pairs = {
        key: metrics.paired(rows, code, PRIMARY)
        for key, code in forecast.items()
        if key != "baseline"
    }
    same = next(k for k in ("raw_matched", "raw_full") if k in forecast)
    return {
        "policies": forecast,
        "metrics": completed,
        "vs_baseline": pairs,
        "neural_vs_raw_at_matched_recovery": metrics.paired(
            rows, forecast["neural"], forecast[same]
        )
        if same == "raw_matched"
        else None,
    }


if __name__ == "__main__":
    group = sys.argv[1]
    result = collect(group)
    source = None if group == "calibration" else reference(OUT / "replay-calibration.json")
    policy = freeze(result["rows"]) if source is None else read_json(checked(source))["policy"]
    report = summarize(result["rows"], policy)
    for name, x in report["metrics"].items():
        print(
            name,
            {
                key: round(x["means"][key], 4)
                for key in (
                    metrics.RESPONSE,
                    metrics.JUNCTION,
                    metrics.GAP,
                    metrics.ADD,
                    metrics.CONTINUOUS_ADD,
                )
            },
            flush=True,
        )
    print("Primary", report["policies"], flush=True)
    write_json(
        OUT / f"replay-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(Path(method.__file__)),
            "calibration": source,
            "policy": policy,
            "summary": report,
            **result,
        },
    )
