"""Replay low-conditioning alternatives on the exact same native Bayer arrays."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

from capture_phase import OUT, HERE, CALIBRATION

from importlib.util import module_from_spec, spec_from_file_location

SOURCE = HERE.parent / "context-conditioned-detail-v1/capture.py"
spec = spec_from_file_location("conditioning_sweep_driver", SOURCE)
driver = module_from_spec(spec)
spec.loader.exec_module(driver)
batch, run, KEYS, FIXED = driver.batch, driver.run, driver.KEYS, driver.FIXED

FACTORS = {"strong": 0.65, "mild": 0.90}


def pair(source, group):
    receipt = read_json(checked(source))
    if group == "camera":
        for row in receipt["standing"]:
            yield row["id"], 0, row["input"], row["noise"]
        return
    root = read_json(checked(receipt["inputs"]))
    plan = read_json(checked(root["plan"]))
    for row in receipt["records"]:
        for stream in row["streams"]:
            yield row["id"], stream["draw"], stream["data"], plan["noise"]


@torch.inference_mode()
def main(group):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    weights = read_json(Path("docs/results/scene-full-epoch-v1/local-050000-training.json"))[
        "checkpoint"
    ]
    path = checked(weights)
    model, state = load_scene_checkpoint(path, expected_sha256=weights["sha256"], weights="ema")
    assert state["mode"] == "none" and state["step"] == 50000
    model = (
        _stage_tiled_cuda(model, torch.device("cuda")).eval().to(memory_format=torch.channels_last)
    )
    reference_path = (
        FIXED
        if group == "camera"
        else ((CALIBRATION if group == "calibration" else OUT / group) / "parent/result.json")
    )
    source = reference(reference_path)
    records = []
    start = monotonic()
    dest = OUT / f"alternate-{group}"
    dest.mkdir(exist_ok=True, parents=True)
    with ieee_fp32():
        for order, (ident, index, binding, noise) in enumerate(pair(source, group), 1):
            file = dest / f"{ident}-draw{index}.npz"
            if not file.exists():
                with np.load(checked(binding), allow_pickle=False) as f:
                    args = {k: f[k] for k in KEYS}
                values = []
                for i in range(0, len(args["packed"]), 3):
                    raw = batch(args | {k: args[k][i : i + 3] for k in ("packed", "variance")})
                    # Only green is needed for phase-constrained synthesis.
                    downstream = np.stack(
                        [
                            run(model, raw, raw["packed"], raw["variance"], noise, f)[:, 1]
                            .cpu()
                            .numpy()
                            for f in FACTORS.values()
                        ]
                    )
                    assert np.isfinite(downstream).all()
                    values.append(downstream)
                payload = np.concatenate(values, axis=1)
                tmp = file.with_suffix(".partial")
                with tmp.open("wb") as h:
                    np.savez(h, **dict(zip(FACTORS, payload, strict=True)))
                tmp.replace(file)
            records.append({"id": ident, "draw": index, "input": binding, "green": reference(file)})
            if order % 8 == 0:
                print(group, order, flush=True)
    write_json(
        OUT / f"alternate-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "weights": weights,
            "precision": "CUDA IEEE FP32 EMA",
            "factors": FACTORS,
            "seconds": monotonic() - start,
            "rows": records,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
