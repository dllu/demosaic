"""Check crop API parity, existing-mode stability and a repeated wider refit."""

import importlib.util
from pathlib import Path
from statistics import median
import sys
from time import perf_counter
from unittest.mock import patch

import numpy as np

from screen import OUT, HERE, apply, crop
from replay_screen import metrics, paths
from demosaic import _mesh_junction as current
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers

MODES = ("weak-junction-phase", "weak-junction-refit")
OLD = OUT / "mesh_junction_pre_refit.py"
_spec = importlib.util.spec_from_file_location("demosaic._mesh_junction_pre_refit", OLD)
previous = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = previous
_spec.loader.exec_module(previous)


def check(parent, local, scene, cfa, roi, noise, wb, matrix, alt, index, clearance=48):
    x, y, w, h = local
    base = crop(parent, local)
    context = crop(parent, (x - 48, y - 48, w + 96, h + 96))

    def api(mode):
        return refine_raw_mesh_carriers(
            base,
            scene,
            cfa,
            roi,
            shot=noise["shot"],
            read=noise["read"],
            white_balance=wb,
            camera_to_srgb=matrix,
            method=mode,
            parent_context=context,
            donor_clearance=clearance,
        )

    expect, trace = apply(
        parent, local, scene, cfa, roi, noise, wb, matrix, alt, clearance=clearance
    )
    results = {}
    run = MODES if index % 2 == 0 else MODES[::-1]
    for name in run:
        start = perf_counter()
        out = api(name)
        results[name] = out, perf_counter() - start
    plate, new = (results[name][0] for name in MODES)
    deltas = {
        key: float(np.max(abs(actual.astype(float) - expect[arm])) * 65535)
        for key, actual, arm in ((MODES[0], plate, "baseline"), (MODES[1], new, "raw"))
    }
    assert max(deltas.values()) <= 0.002, deltas
    with patch.object(current, "_refine", previous._refine):

        def original(*args, **kwargs):
            kwargs.pop("regional_refit", None)
            return previous._refine(*args, **kwargs)

        with patch.object(current, "_refine", original):
            fixed = api(MODES[0])
    np.testing.assert_array_equal(fixed, plate)
    amplitudes = current._amplitudes

    def wide(*args, **kwargs):
        return amplitudes(*args)

    if trace["admitted"]:
        with patch.object(current, "_amplitudes", wide):
            repeated = api(MODES[1])
    else:
        repeated = plate
    return {"baseline": plate, "repeat-wide": repeated, "refit": new}, {
        "seconds": {k: v[1] for k, v in results.items()},
        "parity_error_DN16": deltas,
        "changed": not np.array_equal(plate, new),
        "admitted": trace["admitted"],
    }


def independent():
    binding, parents, alt, source = paths("independent")
    plan = read_json(checked(source))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    roi = x + 48, y + 48, 160, 160
    local = 48, 48, 160, 160
    rows = []
    index = 0
    streams = iter(alt["rows"])
    for case, receipt in zip(plan["sources"], parents["records"], strict=True):
        draws = []
        for row in receipt["streams"]:
            alternative = next(streams)
            assert alternative["input"] == row["data"]
            with np.load(checked(row["data"]), allow_pickle=False) as f:
                payload = {k: f[k] for k in f.files}
            with np.load(checked(alternative["green"]), allow_pickle=False) as f:
                candidate = {k: f[k] for k in f.files}
            ancestor = np.load(checked(row["outputs"]["local50k"]), allow_pickle=False)
            diagnostics = []
            roles = iter(range(len(ancestor)))

            class Adapter:
                ARMS = ("baseline", "repeat-wide", "refit")

                @staticmethod
                def apply(*args, **kwargs):
                    role = next(roles)
                    outputs, measure = check(
                        *args, {k: v[role] for k, v in candidate.items()}, index + role, **kwargs
                    )
                    diagnostics.append(measure)
                    return outputs, measure

            with patch.object(metrics, "model", Adapter):
                score = metrics.assess(
                    case,
                    plan["noise"],
                    ancestor,
                    payload,
                    payload["scene_packed"].copy(),
                    cut,
                    local,
                    roi,
                )
            index += len(ancestor)
            draws.append(score | {"draw": row["draw"], "input": row["data"], "checks": diagnostics})
        rows.append({"id": case["id"], "family": case["geometry"]["family"], "draws": draws})
        if len(rows) % 8 == 0:
            print("Verified", len(rows), flush=True)
    assert index == 336
    statistical = {k: metrics.score(rows, (k, 1)) for k in ("baseline", "repeat-wide", "refit")}
    statistical["narrow_minus_repeat_wide"] = metrics.paired(rows, ("refit", 1), ("repeat-wide", 1))
    print({name: v.get("means") for name, v in statistical.items()}, flush=True)
    return binding, rows, statistical


def camera():
    source = reference(OUT / "alternate-camera.json")
    alt = read_json(checked(source))
    fixed = read_json(checked(alt["source"]))
    rows = []
    for i, (row, variant) in enumerate(zip(fixed["standing"], alt["rows"], strict=True)):
        assert row["id"] == variant["id"] and row["input"] == variant["input"]
        with np.load(checked(row["input"]), allow_pickle=False) as f:
            raw, cfa, wb, mat = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        with np.load(checked(variant["green"]), allow_pickle=False) as f:
            candidate = {k: f[k][0] for k in f.files}
        ancestor = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = row["local_ROI"]
        _, score = check(ancestor, roi, raw, cfa, roi, row["noise"], wb, mat, candidate, i, 16)
        rows.append({"id": row["id"], "checks": score})
    return source, rows


def timing(a, b):
    checks = [j for r in a for d in r["draws"] for j in d["checks"]] + [r["checks"] for r in b]
    return {
        kind: {
            "count": len(filtered),
            "median_ms": {k: 1000 * median(x["seconds"][k] for x in filtered) for k in MODES},
            "max_error_DN16": {k: max(x["parity_error_DN16"][k] for x in filtered) for k in MODES},
        }
        for kind, filtered in (("all", checks), ("changed", [r for r in checks if r["changed"]]))
    }


if __name__ == "__main__":
    a, rows, control = independent()
    b, cameras = camera()
    result = timing(rows, cameras)
    print(result, flush=True)
    write_json(
        OUT / "verification.json",
        {
            "driver": reference(Path(__file__)),
            "original": reference(OLD),
            "source": reference(Path(current.__file__)),
            "inputs": {"independent": a, "camera": b},
            "timing": result,
            "controls": control,
            "rows": rows,
            "camera": cameras,
        },
    )
