"""Compare the public modes on retained ordinary photos and conflicting exteriors."""

from pathlib import Path

import numpy as np

from screen import OUT, crop
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers

CORE = (48, 48, 160, 160)
ORIGIN = (176, 176, 160, 160)
CUT = np.s_[..., 64:192, 64:192]
MODES = ("weak-junction-phase", "weak-junction-refit")


def main():
    refs = {
        name: reference(OUT.with_name(group) / filename)
        for name, group, filename in (
            ("natural", "local-weak-contrast-v1", "natural-controls.json"),
            ("exterior", "local-near-phase-v1", "contexts-calibration.json"),
        )
    }
    a, b = [read_json(checked(refs[k])) for k in ("natural", "exterior")]
    n = read_json(checked(b["plan"]))["noise"]
    rows = []
    for original, extra in zip(a["rows"], b["records"], strict=True):
        assert original["id"] == extra["id"]
        with np.load(checked(original["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        alt = extra["streams"][0]["far_phase"]
        raw = np.load(checked(alt), allow_pickle=False)
        raw[CUT] = data["scene_packed"][CUT]
        np.testing.assert_array_equal(raw[CUT], data["packed"][0])
        outputs = {}
        parent = data["parent"]
        for kind, scene in (("authentic", data["scene_packed"]), ("mismatch", raw)):
            stages = [
                refine_raw_mesh_carriers(
                    crop(parent, CORE),
                    scene,
                    data["colors"],
                    ORIGIN,
                    shot=n["shot"],
                    read=n["read"],
                    white_balance=data["wb"],
                    camera_to_srgb=data["matrix"],
                    method=k,
                    parent_context=parent,
                    donor_clearance=48,
                )
                for k in MODES
            ]
            outputs[kind] = float(
                np.sqrt(np.mean((stages[1].astype(float) - stages[0]) ** 2)) * 65535
            )
        rows.append(
            {
                "id": original["id"],
                "inputs": {"ordinary": original["input"], "altered_exterior": alt},
                "RGB_RMS_DN16": outputs,
            }
        )
    changed = {k: sum(r["RGB_RMS_DN16"][k] > 0 for r in rows) for k in ("authentic", "mismatch")}
    print("Changed natural crops", changed, flush=True)
    write_json(
        OUT / "natural.json",
        {"driver": reference(Path(__file__)), "sources": refs, "changed": changed, "rows": rows},
    )


if __name__ == "__main__":
    main()
