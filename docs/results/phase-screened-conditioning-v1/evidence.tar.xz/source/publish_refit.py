"""Archive the locked evaluation, source proof and native crops."""

from copy import deepcopy
from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from screen import HERE, OUT
from replay_screen import metrics

ROOT = Path.cwd()
RESULTS = ROOT / "docs/results" / HERE.name
ASSETS = ROOT / "docs/assets" / HERE.name
RECEIPTS = (
    "independent/plan.json",
    "independent/inputs.json",
    "independent/parent/result.json",
    *(f"alternate-{g}.json" for g in ("calibration", "independent", "camera")),
    "replay-calibration.json",
    "replay-independent.json",
    "review-exact.json",
    "review-camera.json",
    "verification.json",
    "natural.json",
)
REUSED = (
    "local-junction-support-v1/capture_junction.py",
    "local-junction-support-v1/replay_junction.py",
    "local-junction-support-v1/review_junction.py",
    "local-nested-support-v1/replay_nested_parents.py",
    "context-conditioned-detail-v1/capture.py",
)


def repo_relative(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def image(item):
    source = checked(item["image"])
    file = ASSETS / source.name
    shutil.copyfile(source, file)
    binding = repo_relative(file)
    assert binding["sha256"] == item["image"]["sha256"]
    with Image.open(file) as png:
        for tile in item["panels"]:
            x, y, w, h = tile["png_xywh"]
            assert (
                (w, h) == (160, 160)
                and 0 <= x < x + w <= png.width
                and 0 <= y < y + h <= png.height
            )
    return item | {"image": binding}


def main():
    refs = {k: reference(OUT / k) for k in RECEIPTS}
    data = {k: read_json(checked(v)) for k, v in refs.items()}
    for record in data.values():
        for key in ("driver", "operator", "original"):
            if key in record:
                checked(record[key])
    hold = data["replay-independent.json"]
    cal = data["replay-calibration.json"]
    assert hold["calibration"] == refs["replay-calibration.json"]
    assert cal["alternate"] == refs["alternate-calibration.json"]
    assert hold["alternate"] == refs["alternate-independent.json"]
    assert hold["plan"] == refs["independent/plan.json"]
    assert data["alternate-independent.json"]["source"] == refs["independent/parent/result.json"]
    assert data["independent/parent/result.json"]["inputs"] == refs["independent/inputs.json"]
    assert data["independent/inputs.json"]["plan"] == refs["independent/plan.json"]
    assert hold["summary"]["policies"]["raw"] == ["raw", 1.0]
    for kind in ("exact", "camera"):
        stage = data[f"review-{kind}.json"]
        assert (
            stage["scored_source"] == refs["replay-independent.json"]
            and stage["calibration"] == hold["calibration"]
        )
    ids = []
    for binding in (cal["plan"], hold["plan"]):
        plan = read_json(checked(binding))
        sources = plan["sources"]
        assert len(sources) == 24
        ids.append({item["source"][k] for item in sources for k in ("id", "cache_sha256")})
    assert ids[0].isdisjoint(ids[1])
    input_rows = data["independent/inputs.json"]["observations"]
    parent_rows = data["independent/parent/result.json"]["records"]
    for obs, parent in zip(input_rows, parent_rows, strict=True):
        assert obs["id"] == parent["id"]
        for p, q in zip(obs["streams"], parent["streams"], strict=True):
            assert p["data"] == q["data"]
            checked(p["data"])
            for output in q["outputs"].values():
                checked(output)
    for group in ("calibration", "independent", "camera"):
        r = data[f"alternate-{group}.json"]
        checked(r["source"])
        checked(r["weights"])
        for item in r["rows"]:
            checked(item["input"])
            checked(item["green"])
    verify = data["verification.json"]
    assert verify["timing"]["all"]["count"] == 344
    assert max(verify["timing"]["all"]["max_error_DN16"].values()) == 0
    assert data["natural.json"]["changed"] == {"authentic": 0, "mismatch": 0}
    assert "97 passed" in (OUT / "focused-tests.log").read_text()
    checked(verify["source"])
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    camera = deepcopy(data["review-camera.json"]["review"]["rows"])
    exact = deepcopy(data["review-exact.json"]["review"]["rows"])
    assert len(camera) == 8 and len(exact) == 2
    for row in camera:
        row["native"] = [image(p) for p in row["native"]]
    for row in exact:
        for name in ("triplet", "board"):
            row[name] = image(row[name])
    views = ASSETS / "manifest.json"
    weights = data["alternate-independent.json"]["weights"]
    write_json(
        views,
        {
            "ancestor": weights,
            "weight_policy": "CUDA IEEE FP32 EMA, CPU crop refit",
            "exact": exact,
            "camera": camera,
            "calibration": hold["calibration"],
        },
    )
    files = {f"receipts/{k}": v for k, v in refs.items()}
    files.update({f"source/{f.name}": reference(f) for f in HERE.glob("*.py")})
    files.update({f"reused/{k}": reference(HERE.parent / k) for k in REUSED})
    files.update({f"logs/{f.name}": reference(f) for f in OUT.glob("*.log")})
    files.update(
        {
            f"implementation/{p}": reference(ROOT / p)
            for p in (
                "src/demosaic/_mesh_junction.py",
                "src/demosaic/mesh_carrier_fit.py",
                "tests/test_mesh_carrier_fit.py",
            )
        }
    )
    files["source/mesh_junction_pre_refit.py"] = verify["original"]
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for key, v in files.items():
            tar.add(checked(v), arcname=key, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == files.keys()
        for key, v in files.items():
            with tar.extractfile(key) as f:
                assert file_digest(f, "sha256").hexdigest() == v["sha256"]
    summary = RESULTS / "summary.json"
    e = {
        n: verify["controls"][n]["means"][metrics.RESPONSE]
        for n in ("baseline", "refit", "repeat-wide")
    }
    matched = (e["refit"] - e["baseline"]) / (e["repeat-wide"] - e["baseline"])
    compare = metrics.paired(verify["rows"], ("refit", 1), ("repeat-wide", matched))
    write_json(
        summary,
        {
            "calibration": cal["summary"],
            "held": hold["summary"],
            "timing": verify["timing"],
            "controls": verify["controls"],
            "compared_with_repeat_wide_at_matched_response": {
                "wide_dose": matched,
                "delta": compare,
            },
            "natural_crops": data["natural.json"]["changed"],
            "camera": {r["id"]: r["changed_DN16"] for r in camera},
        },
    )
    write_json(
        RESULTS / "publication.json",
        {
            "archive": repo_relative(archive),
            "images": repo_relative(views),
            "summary": repo_relative(summary),
            "members": files,
            "ancestor": weights,
            "weights": "EMA",
            "scope": "Exact junctions, quiet and ordinary controls, both native GFX families. Frozen weights.",
        },
    )
    print(repo_relative(archive))
    print("Equal response repeat-wide", matched, compare[metrics.GAP])


if __name__ == "__main__":
    main()
