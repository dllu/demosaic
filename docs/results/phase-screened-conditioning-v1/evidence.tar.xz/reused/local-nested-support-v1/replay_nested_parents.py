"""Bind single-capture IEEE FP32 predictions to the two independent RAW draws."""

import sys
import time

import numpy as np
import torch

from freeze_nested import OUT
from review_optical import arrays, bind_models, run_model
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    source = reference(OUT / "inputs.json")
    inputs = read_json(checked(source))
    plan = read_json(checked(inputs["plan"]))
    specs = {k: plan["checkpoints"][k] for k in ("local50k", "v120")}
    models = bind_models(specs)
    output = OUT / "parent"
    output.mkdir(exist_ok=True)
    records = []
    started = time.monotonic()
    with ieee_fp32():
        for obs in inputs["observations"]:
            streams = []
            for row in obs["streams"]:
                payload = arrays(row["data"])
                count = len(payload["packed"])
                results = {}
                for name, model in models.items():
                    fp = output / f"{obs['id']}-{row['draw']}-{name}.npy"
                    if not fp.is_file():
                        data = []
                        for i in range(0, count, 3):
                            sample = payload | {k: payload[k][i:i+3] for k in ("packed", "variance")}
                            data.append(run_model(model, name, sample, plan["noise"]))
                        value = np.concatenate(data, axis=0)
                        assert value.shape == (count, 3, 256, 256) and np.isfinite(value).all()
                        temp = fp.with_suffix(".partial")
                        with temp.open("wb") as f:
                            np.save(f, value, allow_pickle=False)
                        temp.replace(fp)
                    results[name] = reference(fp)
                streams.append(row | {"outputs": results})
            records.append({"id": obs["id"], "streams": streams})
            if len(records) % 8 == 0:
                print("Restored both RAW draws", len(records), flush=True)
    write_json(output / "result.json", {
        "driver": reference(__file__), "inputs": source, "weights": specs,
        "precision": "CUDA IEEE FP32 EMA", "scope": "established 256-pixel model paths",
        "records": records, "seconds": time.monotonic() - started,
    })


if __name__ == "__main__":
    main()
