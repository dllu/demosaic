"""Lock correction strength using actual additive controls and exact missing regions."""

from collections import defaultdict
from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch
from scipy.ndimage import maximum_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import junction_gate as model


OUT = model.OUT
LIMITS = {"mean_additive_DN16": 0.10, "mean_gap_DN16": 0.35, "peak_quiet_DN16": 0.65}
RESPONSE = "interaction_response_points"
JUNCTION = "junction_increment_RMS_DN16"
ERROR = "interaction_increment_RMS_DN16"
ABS = "present_luma_RMS_DN16"
ADD = "additive_extra_DN16"
CONTINUOUS_ADD = "continuous_additive_extra_DN16"
GAP = "gap_extra_DN16"
QUIET = ("strong_extra_DN16", "flat_extra_DN16", "edge_extra_DN16", "uniform_extra_DN16")
METRICS = (RESPONSE, JUNCTION, ERROR, ABS, ADD, CONTINUOUS_ADD, GAP, *QUIET)
REG = np.s_[..., 16:144, 16:144]
SCORE = np.s_[..., 64:192, 64:192]


def terms(anchor, change):
    return [
        float(np.mean(anchor**2) * 65535**2),
        float(2 * np.mean(anchor * change) * 65535**2),
        float(np.mean(change**2) * 65535**2),
    ]


def assess(case, noise, parent, data, scene, cut, local, roi):
    colors, wb, matrix = (data[k] for k in ("colors", "wb", "matrix"))
    affected = {k: [] for k in model.ARMS}
    diagnostics = []
    for raw, reference_ in zip(data["packed"], parent, strict=True):
        scene[cut] = raw
        outputs, trace = model.apply(reference_, local, scene, colors, roi, noise, wb, matrix)
        for key, value in outputs.items():
            affected[key].append(value)
        diagnostics.append(trace)

    def luma(frames):
        return np.einsum(
            "...chw,c->...hw", frames, (np.array((0.2126, 0.7152, 0.0722)) @ matrix) * wb
        )

    base = luma(np.stack(affected["baseline"])[REG])
    target = luma(data["target"][SCORE])
    contrast = target[0] - target[1]
    support = data["support"].copy()
    nearby = maximum_filter(support, 7, mode="nearest") > 0
    support[(support == 0) & nearby] = 1e-4
    support = support[SCORE]
    intact = support >= 0.95
    absent = support == 0
    crossings = data["crossings"][SCORE] & intact
    bw = base[0] - base[1]
    denom = float(contrast[intact] @ contrast[intact])
    assert denom > 0 and crossings.any()
    scores = {}
    for name, images in affected.items():
        change = luma(np.stack(images)[REG]) - base
        addition = change[0] - change[1]
        m = {
            RESPONSE: [
                100 * float(bw[intact] @ contrast[intact]) / denom,
                100 * float(addition[intact] @ contrast[intact]) / denom,
            ],
            JUNCTION: terms((bw - contrast)[crossings], addition[crossings]),
            ERROR: terms((bw - contrast)[intact], addition[intact]),
            ABS: terms(base[0] - target[0], change[0]),
            ADD: terms(np.zeros_like(change[1]), change[1]),
            CONTINUOUS_ADD: terms(np.zeros_like(change[2]), change[2]),
        }
        if absent.any():
            m[GAP] = terms(np.zeros_like(change[0][absent]), change[0][absent])
        for j, key in enumerate(QUIET, start=3):
            m[key] = terms(np.zeros_like(change[j]), change[j])
        scores[name] = m
    return {
        "power": scores,
        "trace": diagnostics,
        "junction_pixels": int(crossings.sum()),
        "gap_pixels": int(absent.sum()),
        "ground_truth_crossing_RMS_DN16": float(np.sqrt(np.mean(contrast[crossings] ** 2)) * 65535),
    }


def collect(group):
    parent = reference(OUT / group / "parent/result.json")
    frozen = read_json(checked(parent))
    inputs = read_json(checked(frozen["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    x, y, w, h = plan["query"]
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    rows = []
    for fixture, record in zip(plan["sources"], frozen["records"], strict=True):
        assert fixture["id"] == record["id"]
        draws = []
        for stream in record["streams"]:
            with np.load(checked(stream["data"]), allow_pickle=False) as payload:
                samples = {k: payload[k] for k in payload.files}
            pred = np.load(checked(stream["outputs"]["local50k"]), allow_pickle=False)
            fitting = assess(
                fixture,
                plan["noise"],
                pred,
                samples,
                samples["scene_packed"].copy(),
                cut,
                local,
                roi,
            )
            draws.append(
                fitting
                | {"draw": stream["draw"], "input": stream["data"], "outputs": stream["outputs"]}
            )
        rows.append(
            {
                "id": fixture["id"],
                "fixture": fixture,
                "family": fixture["geometry"]["family"],
                "draws": draws,
            }
        )
        if len(rows) % 8 == 0:
            print("Replayed", group, len(rows), flush=True)
    return rows, parent, inputs["plan"]


def values(q, path):
    method, dose = path
    measurements = q["power"][method]
    return {
        key: float(x[0] + x[1] * dose)
        if key == RESPONSE
        else float(np.sqrt(max(0.0, x[0] + x[1] * dose + x[2] * dose * dose)))
        for key, x in measurements.items()
    }


def score(rows, path):
    all_values = [values(d, path) for r in rows for d in r["draws"]]
    means = {key: mean(x[key] for x in all_values if key in x) for key in METRICS}
    peaks = {key: max(x[key] for x in all_values if key in x) for key in METRICS[4:]}
    return {"means": means, "peak": peaks}


def within(stats):
    avg = stats["means"]
    return (
        max(avg[ADD], avg[CONTINUOUS_ADD]) <= LIMITS["mean_additive_DN16"]
        and avg[GAP] <= LIMITS["mean_gap_DN16"]
        and max(stats["peak"][key] for key in QUIET) <= LIMITS["peak_quiet_DN16"]
    )


def lock(rows):
    trials = {}
    for arm in model.ARMS[1:]:
        samples = []
        for dose in np.linspace(0.0, 1.0, 21).tolist():
            stats = score(rows, (arm, dose))
            samples.append({"choice": [arm, dose], "stats": stats, "within": within(stats)})
        trials[arm] = samples

    def best(names):
        return max(
            (x for n in names for x in trials[n] if x["within"]),
            key=lambda v: (v["stats"]["means"][RESPONSE], -v["stats"]["means"][GAP]),
        )

    families = {
        family: best([a for f, _, a in model.OPTIONS if f == family]) for family in model.FAMILIES
    }
    return {
        "limits": LIMITS,
        "uniform": best(["uniform"]),
        "variants": families,
        "primary": max(families.values(), key=lambda v: v["stats"]["means"][RESPONSE]),
        "candidates": trials,
    }


def paired(rows, a, b):
    report = {}
    for metric in METRICS:
        subset = []
        delta = []
        for row in rows:
            vals = [
                (values(q, a), values(q, b)) for q in row["draws"] if metric in q["power"][a[0]]
            ]
            if vals:
                subset.append(row)
                delta.append(mean(x[metric] - y[metric] for x, y in vals))
        rng = np.random.default_rng(202611200638)
        strata = defaultdict(list)
        for i, r in enumerate(subset):
            strata[r["family"]].append(i)
        sampled = np.hstack(
            [rng.choice(ids, (12000, len(ids)), replace=True) for ids in strata.values()]
        )
        distribution = np.asarray(delta)[sampled].mean(axis=1)
        estimate = [mean(delta), *np.quantile(distribution, (0.025, 0.975)).tolist()]
        report[metric] = {
            "sources": len(subset),
            "interval": estimate,
        }
    return report


def summary(rows, locked):
    methods = {
        "baseline": ("baseline", 1),
        "uniform_full": ("uniform", 1),
        "uniform_locked": locked["uniform"]["choice"],
        "primary": locked["primary"]["choice"],
    } | {family: data["choice"] for family, data in locked["variants"].items()}
    metrics = {name: score(rows, choice) for name, choice in methods.items()}
    base = metrics["baseline"]["means"][RESPONSE]
    increase = metrics["primary"]["means"][RESPONSE] - base
    uniform = metrics["uniform_full"]["means"][RESPONSE] - base
    matched = None
    if uniform > 0 and 0 <= increase / uniform <= 1:
        scale = increase / uniform
        reference_ = score(rows, ("uniform", scale))
        matched = {
            "dose": scale,
            "scores": reference_,
            "primary_vs_equal_response_uniform": paired(
                rows, methods["primary"], ("uniform", scale)
            ),
        }
    return {
        "methods": methods,
        "metrics": metrics,
        "within": {k: within(v) for k, v in metrics.items()},
        "vs_baseline": {
            name: paired(rows, path, methods["baseline"])
            for name, path in methods.items()
            if name != "baseline"
        },
        "primary_vs_uniform_locked": paired(rows, methods["primary"], methods["uniform_locked"]),
        "matched": matched,
        "admission": {
            str(i): sum(r["trace"][i]["admitted"] for row in rows for r in row["draws"])
            for i in range(7)
        },
        "delivery": {
            str(i): sum(r["trace"][i]["state"] == "delivered" for row in rows for r in row["draws"])
            for i in range(7)
        },
    }


def main(group):
    torch.set_num_threads(2)
    started = monotonic()
    rows, parent, plan = collect(group)
    binding = {
        "driver": reference(Path(__file__)),
        "operator": reference(model.__file__),
        "old_operator": reference(model.old.__file__),
        "source": parent,
        "plan": plan,
    }
    if group == "calibration":
        locked = lock(rows)
        binding["policy"] = locked
    else:
        receipt = reference(OUT / "calibration.json")
        source = read_json(checked(receipt))
        assert source["operator"] == binding["operator"]
        locked = source["policy"]
        binding["calibration"] = receipt
    result = summary(rows, locked)
    print(
        "choices",
        result["methods"],
        "admitted",
        result["admission"],
        "active",
        result["delivery"],
        flush=True,
    )
    for name, line in result["metrics"].items():
        print(
            name,
            {k: round(v, 6) for k, v in line["means"].items()},
            "within",
            result["within"][name],
            flush=True,
        )
    write_json(
        OUT / f"{group}.json",
        binding | {"rows": rows, "summary": result, "seconds": monotonic() - started},
    )


if __name__ == "__main__":
    main(sys.argv[1])
