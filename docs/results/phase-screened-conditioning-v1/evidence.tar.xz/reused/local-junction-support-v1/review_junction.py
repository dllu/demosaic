"""Render the locked sideband study on native synthetic and camera crops."""

from pathlib import Path
import sys

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
import junction_gate as model
import replay_junction as score

FIXED = Path("/mnt/external/demosaic/local-optical-mixture-v1/fixed-review/result.json")
KEYS = ("baseline", "uniform", "uniform_locked", "primary")
LABELS = ("Masked internal phase", "Full sideband", "Reduced sideband", "Local wire support")


def image(data, wb, matrix, exposure):
    rgb = display_crop(
        torch.from_numpy(data[None]),
        torch.from_numpy(wb[None]),
        torch.from_numpy(matrix[None]),
        (0, 0, 160, 160),
        exposure=exposure,
    )
    return np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)


def board(tiles, path):
    frame = Image.new("RGB", (8 + len(tiles) * 168, 192), "#eee")
    draw = ImageDraw.Draw(frame)
    metadata = []
    for i, (label, cell) in enumerate(tiles):
        x = 8 + i * 168
        assert cell.shape == (160, 160, 3)
        frame.paste(Image.fromarray(cell), (x, 24))
        draw.text((x, 5), label, fill="black")
        metadata.append({"label": label, "png_xywh": [x, 24, 160, 160]})
    frame.save(path)
    return {"image": reference(path), "panels": metadata}


def sampled(methods, policy):
    baseline = methods["baseline"]
    assert policy["primary"]["choice"] == ["wire/0", 1.0]
    amount = policy["uniform"]["choice"][1]
    return {
        "baseline": baseline,
        "uniform": methods["uniform"],
        "uniform_locked": (
            baseline + amount * (methods["uniform"].astype(np.float64) - baseline)
        ).astype(baseline.dtype),
        "primary": methods["wire/0"],
    }


def camera(policy, dest):
    fixed = reference(FIXED)
    source = read_json(checked(fixed))
    rows = []
    for r in source["standing"]:
        with np.load(checked(r["input"]), allow_pickle=False) as file:
            packed, colors, wb, matrix = (file[k][0] for k in ("packed", "colors", "wb", "matrix"))
        parent = np.load(checked(r["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(r["local_ROI"])
        layers, trace = model.apply(
            parent, roi, packed, colors, roi, r["noise"], wb, matrix, clearance=16
        )
        restored = sampled(layers, policy)
        views = []
        for former in r["displays"]:
            with Image.open(checked(former["board"]["image"])) as old:
                p = np.asarray(old)
            old_tiles = {}
            for tile in former["board"]["panels"]:
                x, y, w, h = tile["png_xywh"]
                old_tiles[tile["name"]] = p[y : y + h, x : x + w]
            exp = former["exposure"]
            np.testing.assert_array_equal(
                image(model.crop(parent, roi), wb, matrix, exp), old_tiles["Local 50k"]
            )
            cells = [
                (name, old_tiles[name]) for name in ("Noisy (Malvar)", "V120 EMA", "Local 50k")
            ]
            cells += [
                (label, image(restored[key], wb, matrix, exp))
                for key, label in zip(KEYS, LABELS, strict=True)
            ]
            cells += [
                (name, old_tiles[name])
                for name in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if name in old_tiles
            ]
            views.append(
                board(cells, dest / f"{r['id']}-x{exp:g}.png")
                | {"exposure": exp, "previous": former["board"]}
            )
        deltas = {
            k: float(np.sqrt(np.mean((v.astype(np.float64) - restored["baseline"]) ** 2)) * 65535)
            for k, v in restored.items()
        }
        rows.append(
            {
                "id": r["id"],
                "input": r["input"],
                "noise": r["noise"],
                "raw": r["raw"],
                "primary_parent": r["predictions"]["local50k"],
                "ROI_xywh": r["global_ROI"],
                "local_ROI": roi,
                "trace": trace,
                "native": views,
                "change_DN16": deltas,
            }
        )
        print(r["id"], deltas, flush=True)
    return {"source": fixed, "checkpoints": source["checkpoints"], "rows": rows}


def exact(source, policy, dest):
    samples = read_json(checked(source))
    plan = read_json(checked(samples["plan"]))
    local = (48, 48, 160, 160)
    x, y, w, h = plan["query"]
    roi = (x + 48, y + 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    possibilities = {}
    dose = policy["primary"]["choice"]
    for r in samples["rows"]:
        for d in r["draws"]:
            if d["trace"][0]["state"] != "delivered":
                continue
            measured = score.values(d, dose)
            baseline = score.values(d, ("baseline", 1))
            uniform = score.values(d, ("uniform", samples["summary"]["matched"]["dose"]))
            gain = measured[score.RESPONSE] - baseline[score.RESPONSE]
            category = (
                "largest gap reduction"
                if score.GAP in measured
                else "largest junction error reduction"
            )
            merit = (
                (uniform[score.GAP] - measured[score.GAP])
                if score.GAP in measured
                else (baseline[score.JUNCTION] - measured[score.JUNCTION])
            )
            if category not in possibilities or merit > possibilities[category][0]:
                possibilities[category] = (merit, r, d, gain, measured)
    assert len(possibilities) == 2
    rows = []
    for kind, (merit, r, d, gain, native) in possibilities.items():
        with np.load(checked(d["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        colors, wb, matrix = (data[k] for k in ("colors", "wb", "matrix"))
        raw = data["scene_packed"].copy()
        raw[cut] = data["packed"][0]
        args = {k: data[k][None] for k in ("colors", "wb", "matrix")} | {
            "packed": data["packed"][:1]
        }
        parent, v120 = (
            np.load(checked(d["outputs"][k]), allow_pickle=False)[0] for k in ("local50k", "v120")
        )
        products, trace = model.apply(parent, local, raw, colors, roi, plan["noise"], wb, matrix)
        output = sampled(products, policy)
        native_views = [
            ("Noisy Malvar", model.crop(noisy_malvar(args)[0], local)),
            ("V120 EMA", model.crop(v120, local)),
            ("Local 50k", model.crop(parent, local)),
        ]
        native_views += [(label, output[key]) for key, label in zip(KEYS, LABELS, strict=True)]
        native_views.append(("Exact GT", model.crop(data["target"][0], local)))
        cells = [(label, image(rgb, wb, matrix, 2.0)) for label, rgb in native_views]
        indices = (0, len(cells) - 2, len(cells) - 1)
        triplet = board([cells[i] for i in indices], dest / f"{r['id']}-triplet.png")
        all_methods = board(cells, dest / f"{r['id']}-comparison.png")
        rows.append(
            {
                "id": r["id"],
                "input": d["input"],
                "draw": d["draw"],
                "fixture": r["fixture"],
                "noise": plan["noise"],
                "sigma": plan["sigma"],
                "weights": plan["checkpoints"],
                "ROI": local,
                "query": plan["query"],
                "exposure": 2.0,
                "selection": kind,
                "criterion": merit,
                "response_change": gain,
                "scores": native,
                "trace": trace,
                "board": all_methods,
                "triplet": triplet,
            }
        )
    return {"source": source, "boards": rows}


def main(kind):
    torch.set_num_threads(2)
    frozen = reference(model.OUT / "calibration.json")
    confirmed = reference(model.OUT / "independent.json")
    policy = read_json(checked(frozen))["policy"]
    dest = model.OUT / "boards" / kind
    dest.mkdir(exist_ok=True, parents=True)
    out = camera(policy, dest) if kind == "camera" else exact(confirmed, policy, dest)
    write_json(
        model.OUT / f"board-{kind}.json",
        {
            "driver": reference(Path(__file__)),
            "calibration": frozen,
            "source": confirmed,
            "data": out,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
