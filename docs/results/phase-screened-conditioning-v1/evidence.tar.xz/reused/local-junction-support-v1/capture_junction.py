"""Capture matched Bayer scenes with and without measurable wire interaction."""

from dataclasses import replace
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
import torch
from torch.nn import functional as F

from demosaic import scene_data
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import variance_map
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
ORIGINAL = OUT.with_name("cab-local-frequency-v1") / "independent/plan.json"
sys.path.insert(0, str(HERE.parent / "local-replicated-phase-v1"))
import capture_balanced as source
from capture_optical import filtered_observation
from capture_coupled import adc

SEEDS = {"calibration": 202611200638, "independent": 202611200639}
COUNT = 24
ROLES = (
    "junction",
    "matched additive pair",
    "additive with both wires throughout",
    "one direction",
    "flat core",
    "edge only",
    "uniform",
)
BAYER = np.s_[..., 64:192, 64:192]
RGB = np.s_[..., 128:384, 128:384]


def freeze(group, root):
    prior = reference(ORIGINAL)
    if group == "calibration":
        plan = read_json(checked(prior))
    else:
        engine = source.last.run
        engine.OUT = root
        engine.SEED = SEEDS[group]
        engine.COUNT = COUNT
        old = source.PREVIOUS
        parent = OUT.with_name("local-replicated-phase-v1")
        engine.prior.EXCLUSIONS += (
            ORIGINAL,
            *(
                parent / n / "plan.json"
                for n in ("calibration", "fresh", "verification", "station-confirm")
            ),
            old / "fresh/plan.json",
            source.last.PREVIOUS / "fresh/plan.json",
            source.last.CALIBRATION,
        )
        plan = engine.freeze()
    for c in plan["sources"]:
        i = c["index"]
        g = c["geometry"]
        rng = np.random.default_rng(scene_seed(SEEDS[group], i, "junction"))
        g["interaction_ratio"] = float(rng.uniform(0.45, 0.95))
        g["relative_interaction_polarity"] = 1 if i % 3 == 0 else -1
        # Include weaker and near-balanced lattices without letting one sign select the cohort.
        g["strength"][1] = float(g["strength"][0] * rng.uniform(0.60, 1.2))
        c["id"] = f"junction-{group}-{i:02d}"
    return plan | {
        "driver": reference(__file__),
        "earlier_source": prior,
        "roles": ROLES,
        "seed": SEEDS[group],
        "scope": "A signed difference sideband and physically matched additive controls with exact gaps.",
    }


def clean_scenes(case):
    load = source.last.run.prior.earlier.capture_wide.wire_math
    photo = load.decode(case["source"], case["box"])
    g = case["geometry"]
    axis = torch.arange(512) - 255.5
    y, x = torch.meshgrid(axis, axis, indexing="ij")
    extent = torch.maximum(x.abs(), y.abs())
    shell = ((extent - 132) / 27).clamp(0, 1)
    background = (
        0.085
        + 0.52 * F.avg_pool2d(photo[None], 11, stride=1, padding=5, count_include_pad=False)[0]
    )
    distance = x * np.cos(g["angle"]) + y * np.sin(g["angle"]) - g["edge"]
    step = torch.sigmoid(distance / 1.3)
    base = background + torch.as_tensor(g["tint"])[:, None, None] * step
    phase = [
        2 * np.pi * (fx * x + fy * y) + p
        for (fx, fy), p in zip(g["frequency"], g["phase"], strict=True)
    ]

    def waveform(phase, width):
        return sum(
            np.exp(-2 * np.pi**2 * width**2 * (h * h - 1)) * (h * phase).cos() for h in range(1, 6)
        )

    # Unlike the prior optical fixtures, additive receivers contain no interaction term.
    front, rear = (
        a * waveform(p, w) for a, p, w in zip(g["strength"], phase, g["width"], strict=True)
    )
    _, _, support, _ = load.exact(photo, g)
    second = rear * (0.70 + 0.30 * step)
    added = g["relative_interaction_polarity"] * g["interaction_ratio"] * g["strength"][1] / 2
    overlap = (phase[0] - phase[1]).cos() * support * added * (0.65 + 0.35 * step)
    exterior = base + 0.025 * phase[0].cos() + 0.025 * phase[1].cos()
    bare = base + front
    both = bare + second * support
    fade = ((128 - extent) / 57).clamp(0, 1)
    flat = both[:, 198:314, 198:314].mean((-2, -1), keepdim=True)
    uniform = flat.expand_as(base).clone()
    sources = (
        both + overlap,
        both,
        bare + second,
        bare,
        torch.lerp(both, uniform, fade),
        base,
        uniform,
    )
    # Same nominated surroundings for every role.
    scenes = tuple(torch.lerp(frame, exterior, shell) for frame in sources)
    assert all(0 < float(frame.min()) and float(frame.max()) < 1 for frame in scenes)
    attachment = (phase[0].cos() > 0.55) & (phase[1].cos() > 0.55) & (support > 0.95)
    return scenes, support, attachment


def generator(seed):
    return torch.Generator(device="cpu").manual_seed(seed)


def save_case(case, seed, noise, sigma, dest):
    scenes, support, crossings = clean_scenes(case)
    camera = replace(scene_data.sample_scene_recipe(seed), **case["camera"])
    with patch.object(scene_data, "add_noise", lambda clean, *a, **k: clean):
        targets = [filtered_observation(frame, camera, sigma) for frame in scenes]
    role_count = len(ROLES)
    for draw in (0, 1):
        offsets = [
            scene_seed(seed, case["index"] * role_count + i, f"noise-{draw}")
            for i in range(role_count)
        ]
        rates = torch.stack([q.packed for q in targets]).clamp_min(0) / camera.shot
        lower = torch.minimum(rates[0], rates[1])
        common = torch.poisson(
            lower, generator=generator(scene_seed(seed, case["index"], f"shared-charge-{draw}"))
        )
        shared_read = (
            torch.randn(
                common.shape,
                generator=generator(scene_seed(seed, case["index"], f"shared-read-{draw}")),
            )
            * camera.read**0.5
        )
        noise_samples = []
        for i, rate in enumerate(rates):
            rng = generator(offsets[i])
            if i < 2:
                signal = (
                    common + torch.poisson(rate - lower, generator=rng)
                ) * camera.shot + shared_read
            else:
                signal = torch.poisson(rate, generator=rng) * camera.shot
                signal += torch.randn(signal.shape, generator=rng) * camera.read**0.5
            noise_samples.append(adc(signal, camera.black))
        # When the paired targets are identical, sharing photons and read jitter reproduces the RAW exactly.
        np.testing.assert_array_equal(
            noise_samples[0][rates[0] == rates[1]], noise_samples[1][rates[0] == rates[1]]
        )
        data = {key: getattr(targets[0], key).numpy() for key in ("colors", "wb", "matrix")}
        data["packed"] = np.stack([v[BAYER].numpy() for v in noise_samples])
        data["variance"] = np.stack(
            [
                variance_map(value, camera.shot, camera.read)[BAYER].numpy()
                for value in noise_samples
            ]
        )
        data["target"] = np.stack([sample.target[RGB].numpy() for sample in targets])
        data["scene_packed"] = noise_samples[1].numpy()
        data["support"] = support[RGB].numpy()
        data["crossings"] = crossings[RGB].numpy()
        f = dest / f"{case['id']}-draw{draw}.npz"
        with f.open("xb") as handle:
            np.savez(handle, **data)
        yield {"draw": draw, "data": reference(f), "noise_seeds": offsets}


def main(group):
    torch.set_num_threads(2)
    root = OUT / group
    (root / "inputs").mkdir(exist_ok=True, parents=True)
    plan_path = root / "plan.json"
    if not plan_path.exists():
        write_json(plan_path, freeze(group, root))
    plan = read_json(plan_path)
    assert plan["driver"] == reference(__file__)
    raw = root / "inputs.json"
    if not raw.exists():
        acquired = []
        for case in plan["sources"]:
            acquired.append(
                {
                    "id": case["id"],
                    "streams": list(
                        save_case(case, SEEDS[group], plan["noise"], plan["sigma"], root / "inputs")
                    ),
                }
            )
            if len(acquired) % 8 == 0:
                print("Captured", group, len(acquired), flush=True)
        write_json(
            raw,
            {"driver": reference(__file__), "plan": reference(plan_path), "observations": acquired},
        )
    source.last.run.prior.parents.OUT = root
    if not (root / "parent/result.json").exists():
        source.last.run.prior.parents.main()


if __name__ == "__main__":
    main(sys.argv[1])
