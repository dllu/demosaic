"""Frozen Local 50k forwards at three conditioning strengths with unchanged RAW."""

from hashlib import sha256
from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.noise import variance_map
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
MONITOR = HERE.parent / "scene-full-epoch-v1/review-full-040000/evaluation/results.json"
TRANSFER = OUT.with_name("scene-patch-crossfit-v1") / "parents.json"
WIRE = HERE.parent / "local-band-mixture-v1/confirmation.json"
FIXED = OUT.with_name("local-optical-mixture-v1") / "fixed-review/result.json"
CHECKPOINT = "docs/results/scene-full-epoch-v1/local-050000-training.json"
FACTORS = {"crisp": 0.65, "nominal": 1.0, "smooth": 1.45}
EPS = 0.125
PROBES = 2
KEYS = ("packed", "variance", "colors", "wb", "matrix")


def freeze():
    sources = {
        k: reference(f)
        for k, f in (
            ("calibration", MONITOR),
            ("transfer", TRANSFER),
            ("wires", WIRE),
            ("camera", FIXED),
        )
    }
    monitor = read_json(checked(sources["calibration"]))
    settings = read_json(checked(read_json(checked(monitor["plan"]))["panel"]))
    cmp = [
        row
        for row in monitor["source_metrics"]
        if (row["profile"], row["draw"]) == ("iso6400", "independent")
    ]
    cmp.sort(key=lambda v: sha256(("temperature-risk/" + v["source"]).encode()).hexdigest())
    by_set = {"calibration": [], "transfer": [], "wires": [], "camera": []}
    for row in cmp[:32]:
        r = read_json(checked(read_json(checked(row["prediction_receipt"]))["case"]))
        by_set["calibration"].append(
            {k: r[k] for k in ("id", "source", "input", "box", "profile", "draw")}
            | {"fixture": settings["rows"][r["case"]]}
        )
    for r in read_json(checked(sources["transfer"]))["rows"]:
        by_set["transfer"].append(
            {k: r[k] for k in ("id", "source", "input", "box", "profile", "draw")}
        )
    wire = read_json(checked(sources["wires"]))
    wire_plan = read_json(checked(wire["plan"]))
    for r in wire["rows"]:
        fixture = r["source"]
        if fixture["kind"] != "wire":
            continue
        by_set["wires"].append(
            {
                "id": f"wire-{fixture['index']:02d}",
                "fixture": fixture,
                "input": r["input"],
                "source": fixture["source"],
                "box": r["box"],
                "profile": wire_plan["profile"],
            }
        )
    for r in read_json(checked(sources["camera"]))["standing"]:
        by_set["camera"].append(r | {"profile": r["noise"]})
    checkpoint = read_json(CHECKPOINT)["checkpoint"]
    assert len(by_set["calibration"]) == len(by_set["transfer"]) == 32
    assert len(by_set["wires"]) == 24
    return {
        "driver": reference(__file__),
        "sources": sources,
        "checkpoint": checkpoint,
        "factors": FACTORS,
        "epsilon": EPS,
        "probe_count": PROBES,
        "precision": "CUDA IEEE FP32 EMA",
        "groups": by_set,
    }


def batch(args):
    d = {k: torch.from_numpy(args[k]).cuda() for k in KEYS}
    count = len(d["packed"])
    for k in ("colors", "wb", "matrix"):
        if d[k].ndim == (2 if k == "matrix" else 1):
            d[k] = d[k][None].expand(count, *d[k].shape)
    return d


def run(model, d, raw, variance, prior, f):
    model.base.set_noise(prior["shot"] * f, prior["read"] * f)
    return model(
        raw.contiguous(memory_format=torch.channels_last),
        (variance * f).contiguous(memory_format=torch.channels_last),
        d["colors"],
        d["wb"],
        d["matrix"],
    )


def mosaic(rhs, cfa):
    b = torch.arange(len(rhs), device=rhs.device)
    return torch.stack([rhs[b, cfa[:, 2 * y + x], y::2, x::2] for y, x in np.ndindex(2, 2)], dim=1)


def estimate(model, d, profile, probes, seed):
    raw, var = d["packed"], d["variance"]
    result = {k: run(model, d, raw, var, profile, f).cpu().numpy() for k, f in FACTORS.items()}
    if not probes:
        return result
    # Finite derivatives of decoded RAW, using fixed physical plug-in variance for the probe.
    rng = np.random.default_rng(seed)
    for i in range(PROBES):
        sign = torch.from_numpy(
            (2 * rng.integers(0, 2, size=raw.shape, dtype=np.int8) - 1).astype(np.float32)
        ).cuda()
        scale = var.sqrt()
        # Exclude sites near saturation or black clipping from the risk probe and estimator.
        keep = (raw > 6 * scale + 0.001) & (raw < 1 - 6 * scale)
        perturbation = scale * sign * keep
        direction = []
        for a in (1, -1):
            observed = raw + a * EPS * perturbation
            cov = variance_map(observed, profile["shot"], profile["read"])
            term = [
                mosaic(run(model, d, observed, cov, profile, f), d["colors"])
                for f in FACTORS.values()
            ]
            direction.append((term[0] - term[1], term[2] - term[1]))
        result[f"eps{i}"] = perturbation.cpu().numpy()
        for k, u, v in zip(("crisp", "smooth"), *direction, strict=True):
            result[f"df{i}-{k}"] = ((u - v) / (2 * EPS)).cpu().numpy()
    return result


@torch.inference_mode()
def main(group):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 8 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    plan_file = OUT / "plan.json"
    if not plan_file.exists():
        write_json(plan_file, freeze())
    plan = read_json(plan_file)
    assert plan["driver"] == reference(__file__)
    weight = plan["checkpoint"]
    model, state = load_scene_checkpoint(
        checked(weight), expected_sha256=weight["sha256"], weights="ema"
    )
    assert state["mode"] == "none" and state["step"] == 50000
    model = (
        _stage_tiled_cuda(model, torch.device("cuda")).eval().to(memory_format=torch.channels_last)
    )
    records = []
    start = monotonic()
    dest = OUT / group
    dest.mkdir(exist_ok=True)
    with ieee_fp32():
        for i, r in enumerate(plan["groups"][group]):
            f = dest / f"{r['id']}.npz"
            if not f.is_file():
                with np.load(checked(r["input"]), allow_pickle=False) as stream:
                    args = {key: stream[key] for key in KEYS}
                record = estimate(
                    model,
                    batch(args),
                    r["profile"],
                    group in ("calibration", "transfer"),
                    202611200716 + i + 100 * (group == "transfer"),
                )
                p = f.with_suffix(".partial")
                with p.open("wb") as stream:
                    np.savez(stream, **record)
                p.replace(f)
            records.append({"id": r["id"], "input": r["input"], "output": reference(f)})
            if (i + 1) % 8 == 0:
                print(group, i + 1, "of", len(plan["groups"][group]), flush=True)
    write_json(
        OUT / f"capture-{group}.json",
        {
            "driver": reference(__file__),
            "plan": reference(plan_file),
            "group": group,
            "rows": records,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
