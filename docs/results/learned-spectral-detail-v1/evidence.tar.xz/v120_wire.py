"""Evaluate the recommended V120 EMA on the same native wire inputs."""
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import amp_context

ROOT=Path(__file__).resolve().parent
WIRE=ROOT.parent/'query-exterior-colour-v1'
KEYS=('packed','variance','colors','wb','matrix')

@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    baseline=read_json('docs/results/full-corpus-long100k-primary-v1/primary.json')['models']['V120']['checkpoint']
    bound=reference(WIRE/'fresh-gap.json')
    cases=read_json(checked(bound))
    prepared=read_json(WIRE/'plan.json')
    model,state=load_checkpoint(baseline['path'],'cuda')
    assert state['loaded_sha256']==baseline['sha256'] and state['step']==20000
    model.eval().to(memory_format=torch.channels_last)
    del state
    output=ROOT/'v120-wire'
    output.mkdir()
    rows=[]
    start=time.monotonic()
    for item in cases['rows']:
        p=prepared['profiles'][item['noise']]
        model.set_noise(p['shot'],p['read'])
        with np.load(checked(item['input']),allow_pickle=False)as f:
            args=[torch.from_numpy(f[k][...,48:208,48:208] if k in KEYS[:2] else f[k]).cuda()for k in KEYS]
        args[:2]=[v.contiguous(memory_format=torch.channels_last)for v in args[:2]]
        with amp_context('cuda',dtype='float32'):
            restored=model(*args)
        result=restored[...,32:288,32:288].cpu().contiguous().numpy()
        path=output/f'{item["index"]:03d}-{item["noise"]}.npy'
        np.save(path,result,allow_pickle=False)
        rows.append({'input':item['input'],'output':reference(path)})
        if len(rows)%12==0:
            print(len(rows),time.monotonic()-start,flush=True)
    write_json(ROOT/'v120-wire.json',{'driver':reference(__file__),'checkpoint':baseline,
               'source':bound,'policy':'GPU IEEE FP32, native 256 query with 32-pixel halo on each edge',
               'rows':rows,'seconds':time.monotonic()-start})

if __name__=='__main__':
    main()
