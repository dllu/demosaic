"""Verify transfer for positive and negative native-frequency wave vectors."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import reference, write_json
import head_corrected, head_corrected_broad

ROOT=Path(__file__).resolve().parent


def main():
    y,x=np.indices((256,256),dtype=float)
    core=np.s_[64:192,64:192]
    rows=[]
    for k,mode in (('narrow',head_corrected),('broad',head_corrected_broad)):
        for fx,fy in ((5,3),(5,-3),(3,5),(3,-5),(3,-2)):
            if fx==3 and abs(fy)==2 and k=='narrow':
                continue
            original=np.cos(2*np.pi*(fx*x+fy*y)/32.+.47)
            data=mode.direct_fft(original)
            restored=mode.synthesis(data)
            a,b=original[core].ravel(),restored[core].ravel()
            response=float(a@b/(a@a))
            residual=float(np.sqrt(np.mean((a-b)**2)))
            assert response>.66 and residual<.28,(k,fx,fy,response,residual)
            rows.append({'band':k,'signed_mode':[fx,fy],'response':response,'RMS':residual})
    write_json(ROOT/'phase-audit.json',{'driver':reference(__file__),'rows':rows,
         'scope':'Round-trip coherent sinusoids at both signs of the vertical native frequency, with no learning.'})
    print(rows)

if __name__=='__main__':
    main()
