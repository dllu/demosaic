"""Publish native photo and wire triplets plus both standing GFX comparisons."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import review_corrected_paired as review
import review_corrected_aligned as review_aligned
import review_corrected_broad as review_broad
from head import ROOT
from report_scene_wave_guides import native_board
sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png

ENGINES={'paired':review,'aligned':review_aligned,'expanded':review_broad}
CAPTIONS={'paired':'Paired spectral head','aligned':'Projection loss','expanded':'Expanded band'}
WIRE=ROOT.parent/'query-exterior-colour-v1'


def native_examples(loaded,out):
    receipts=[]
    case_id='001-iso6400-independent'
    group=reference(review.NATIVE/'evaluation/collected.json')
    mappings=read_json(checked(group))['records']
    proof=next(r for r in mappings if Path(r['path']).stem==case_id)
    test,args,bases=review.natural_values(proof)
    plan=read_json(checked(test['plan']))
    p=plan['rows'][test['case']]
    receipts.append(exact(out,case_id,args,bases,args['scene_packed'],test['box'],test['profile'],
                 p['source'],p['camera']['pattern'],test['input'],loaded,contrast=2.,exposure=1/test['profile']['exposure']))
    wire_path=reference(WIRE/'fresh-gap.json')
    benchmarks=read_json(checked(wire_path))
    wire_plan=read_json(WIRE/'plan.json')
    v120=read_json(checked(reference(ROOT/'v120-wire.json')))
    a,b=next((a,b)for a,b in zip(benchmarks['rows'],v120['rows'],strict=True)
             if a['noise']=='iso6400'and a['index']==10)
    args,bases,p=review.wire_values(a,b,wire_plan)
    receipts.append(exact(out,'010-iso6400-wire',args,bases,args['full'][0],wire_plan['query'],
              wire_plan['profiles']['iso6400'],p['source'],p['camera']['pattern'],a['input'],loaded,
              contrast=1.,exposure=2.,source_box=p['box']))
    return receipts


def exact(out,id,args,parents,surround,box,noise,source,cfa,input,loaded,*,exposure,contrast,source_box=None):
    results={}
    for name,engine in ENGINES.items():
        options=engine.groups(args['packed'][:1],surround,parents['100k'][:1],args['colors'][:1],args['wb'][:1],
                            args['matrix'][:1],noise,box,{'shape':loaded[name]})
        results[name]=options['shape'][0]
    cal={k:args[k][:1]for k in ('colors','wb','matrix','packed')}
    noisy=noisy_malvar(cal)[0]
    comparison=[noisy,parents['V120'][0],parents['100k'][0],*results.values(),args['target'][0]]
    labels=('Noisy Malvar','V120 EMA','Corpus 100k',*CAPTIONS.values(),'Exact GT')
    props={'source':source,'CFA':cfa,'input':input,'query':box,'source_box':source_box,'noise':noise}
    result=native_board(out,id,comparison,cal,props,labels=labels,exposure=exposure,
                        contrast=contrast,triplet_indices=(0,5,6))
    variant={}
    for name in ('paired','aligned'):
        r=native_board(out,f'{id}-{name}',[noisy,results[name],args['target'][0]],cal,props,
                         labels=('Noisy Malvar',CAPTIONS[name],'Exact GT'),exposure=exposure,
                         contrast=contrast,triplet_indices=(0,1,2))
        variant[name]=r['triplet']
    return result | {'variant_triplets':variant}


def standing(out):
    manifests={name:reference(ROOT/d/'manifest.json')for name,d in
              (('paired','standing-corrected-paired'),('aligned','standing-corrected-aligned'),('expanded','standing-corrected-broad'))}
    reports={name:read_json(checked(b))for name,b in manifests.items()}
    stored={name:{r['id']:r for r in report['rows']}for name,report in reports.items()}
    pictures=[]
    for main in reports['paired']['rows']:
        id=main['id']
        with Image.open(checked(main['board']['image']))as old:
            existing={p['name']:np.asarray(old.crop((x,y,x+w,y+h)).convert('RGB'))
                      for p in main['board']['panels'] for x,y,w,h in (p['png_xywh'],)}
        labels=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Exterior-frequency colour')
        panels=[(k,existing[k])for k in labels if k in existing]
        changes={}
        for name,k in CAPTIONS.items():
            row=stored[name][id]
            assert all(row[z]==main[z]for z in ('input','raw','box','ROI_xywh','noise','exposure'))
            with Image.open(checked(row['board']['image']))as img:
                x,y,w,h=next(p['png_xywh']for p in row['board']['panels']if p['name']=='Learned spectral shape')
                panels.append((k,np.asarray(img.crop((x,y,x+w,y+h)).convert('RGB'))))
            changes[name]=row['measurements']['shape']
        panels.extend((k,existing[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG')if k in existing)
        board=native_png(out/(id+'.png'),panels)
        pictures.append({k:main[k] for k in ('id','raw','input','box','ROI_xywh','noise','exposure')}|{
            'board':board,'measurements':changes})
    assert len(pictures)==8
    return {'sources':manifests,'rows':pictures}


def main():
    torch.set_num_threads(1)
    loaded={}; receipts={}
    for k,engine in ENGINES.items():
        options,receipt,report=engine.load()
        loaded[k]=options['shape']
        receipts[k]=report['checkpoint']
    out=ROOT/'native-corrected'
    out.mkdir()
    write_json(out/'manifest.json',{'driver':reference(__file__),'checkpoints':receipts,
          'exact':native_examples(loaded,out),'standing':standing(out)})

if __name__=='__main__':
    main()
