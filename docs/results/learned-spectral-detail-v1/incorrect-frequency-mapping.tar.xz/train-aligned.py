"""Test a fixed exact-increment projection loss with the same data and head."""
from copy import deepcopy
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from head import EXACT_FLAT, FREQ_I, ROOT, GainHead, exterior, features

SEED=6183204
MODES=('scalar','shape')
EPOCHS=6
PHOTOS=4
COMPONENTS=('feedback','context','basis','target')


def real_complex(a):
    return np.stack((a.real,a.imag),axis=-1)


def group(parent, raw, record):
    layout,wb,matrix=[raw[k][0]for k in ('colors','wb','matrix')]
    outside=exterior(raw['scene_packed'],layout,record['noise'],record['box'])
    linear=[features(bayer,layout,record['noise'],record['box'],outside,pred,wb,matrix,target)
            for bayer,pred,target in zip(raw['packed'],parent,raw['target'],strict=True)]
    assert outside is not None
    dev=np.maximum(np.mean([r.noise for r in linear[:2]],axis=0),.002)
    return {'feedback':np.stack([r.inputs for r in linear]),
            'context':np.stack([r.contexts[...,:2]for r in linear]),
            'basis':np.stack([real_complex(r.basis/dev[...,None]) for r in linear]),
            'target':np.stack([real_complex(r.desired/dev) for r in linear])}


def collect():
    torch.set_num_threads(2)
    parent_binding=reference(ROOT/'parents.json')
    receipt=read_json(checked(parent_binding))
    spec=read_json(checked(receipt['plan']))
    count=len(spec['batches'])
    path=ROOT/'features'
    path.mkdir()
    design={}
    rows=[]
    started=time.monotonic()
    for photo,proof in zip(spec['batches'],receipt['rows'],strict=True):
        i=photo['index']
        observation=read_json(checked(proof['measurement']))
        assert (i,observation['index'])==(proof['index'],i)
        parent=np.load(checked(proof['parent']),allow_pickle=False)
        with np.load(checked(observation['input']),allow_pickle=False)as f:
            raw={k:f[k]for k in f.files}
        tensors=group(parent,raw,photo)
        for name,v in tensors.items():
            if name not in design:
                design[name]=np.lib.format.open_memmap(path/(name+'.npy'),mode='w+',dtype=np.float16,shape=(count,*v.shape))
            assert np.isfinite(v).all()
            design[name][i]=v.astype(np.float16)
            assert np.isfinite(design[name][i]).all()
        rows.append({'index':i,'parent':proof['parent'],'measurement':proof['measurement']})
        if (i+1)%40==0:
            print('prepared',i+1,round(time.monotonic()-started,2),flush=True)
    for array in design.values():
        array.flush()
    write_json(ROOT/'feature-cache.json',{'driver':reference(__file__),'head':reference(ROOT/'head.py'),
                'parents':parent_binding,'records':rows,'inputs':{k:reference(path/(k+'.npy'))for k in design},
                'counts':{'photos':count,'rows_per_photo':3,'tiles_per_row':len(EXACT_FLAT),'modes_per_tile':len(FREQ_I)},
                'normalization':'Matched shared scale from the two physical observations, floored at .002. Float16 cache with FP32 optimization.',
                'precompute_seconds':time.monotonic()-started})


def objective(prediction, target, baseline, selected):
    errors=prediction-target
    absolute=errors[:,:2].square().mean()
    paired=(errors[:,0]-errors[:,1]).square().mean()
    square=errors[:,2].square().mean()
    flat=prediction[:,2,selected].square().mean()
    true=target[:,0]-target[:,1]+baseline[:,0]-baseline[:,1]
    residual=errors[:,0]-errors[:,1]
    direction=true.flatten(1)
    power=direction.square().sum(1).clamp_min(1e-6)
    projection=(direction*residual.flatten(1)).sum(1)
    aligned=(projection.square()/power).mean()/direction.shape[1]
    return absolute+.65*paired+.50*square+.70*flat+9.*aligned,(absolute,paired,square,flat,aligned)


def train():
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    train_cache=reference(ROOT/'feature-cache.json')
    source=read_json(checked(train_cache))
    rows=source['counts']['photos']
    path=ROOT/'training-aligned'
    path.mkdir()
    data={k:np.load(checked(source['inputs'][k]),allow_pickle=False,mmap_mode='r')for k in COMPONENTS}
    initial=GainHead().cuda()
    models={name:deepcopy(initial)for name in MODES}
    averages={name:deepcopy(initial).eval().requires_grad_(False) for name in MODES}
    optimizer=torch.optim.AdamW([p for obj in models.values() for p in obj.parameters()],lr=.001,weight_decay=.001)
    updates=rows//PHOTOS*EPOCHS
    rng=np.random.default_rng(SEED)
    started=time.monotonic()
    logged=[]
    step=0
    for epoch in range(EPOCHS):
        order=rng.permutation(rows)
        assert len(np.unique(order))==rows
        for i in range(0,rows,PHOTOS):
            photos=order[i:i+PHOTOS]
            selected=np.concatenate((rng.choice(len(EXACT_FLAT),64,replace=False),
                                     rng.choice(np.flatnonzero(EXACT_FLAT),14,replace=False)))
            mask=torch.as_tensor(EXACT_FLAT[selected],device='cuda')
            tensor={k:torch.from_numpy(v[photos][:,:,selected].astype(np.float32)).cuda()for k,v in data.items()}
            args=[tensor[k]for k in COMPONENTS]
            settings={}; loss=0.
            for j,name in enumerate(MODES):
                amount=models[name](args[0],args[1][...,j],args[2])
                current,parts=objective(amount,args[3],args[2][...,0,:],mask)
                if step==0:
                    assert not torch.any(amount)
                loss=loss+current
                settings[name]=[current,*parts]
            step+=1
            lr=.001*(step/24) if step<=24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(updates-24)))
            optimizer.param_groups[0]['lr']=float(lr)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            norm=torch.nn.utils.clip_grad_norm_(list(p for model in models.values() for p in model.parameters()),2.0)
            if not torch.isfinite(norm):
                raise FloatingPointError(f'Nonfinite gradient at step {step}')
            optimizer.step()
            with torch.no_grad():
                for name in MODES:
                    torch._foreach_lerp_(tuple(averages[name].parameters()),tuple(models[name].parameters()),.01)
            if step%20==0 or step in (1,updates):
                report={key:torch.stack(items).detach().cpu().tolist() for key,items in settings.items()}
                logged.append({'step':step,'epoch':epoch+1,'gradient_norm':float(norm),'LR':lr,'losses':report})
                print(step,round(time.monotonic()-started,1),report,flush=True)
    torch.cuda.synchronize()
    elapsed=time.monotonic()-started
    assert step==updates
    model_file=path/'step480.pt'
    checkpoint={'updates':updates,'model':{k:r.state_dict()for k,r in models.items()},
         'EMA':{k:r.state_dict()for k,r in averages.items()},'AdamW':optimizer.state_dict(),
         'cache':train_cache,'torch_RNG':torch.get_rng_state(),'training_seed':SEED}
    with model_file.open('xb')as handle:
        torch.save(checkpoint,handle)
    write_json(path/'completed.json',{'driver':reference(__file__),'head':reference(ROOT/'head.py'),'updates':updates,
        'checkpoint':reference(model_file),'cache':train_cache,'seconds':elapsed,
        'photos':rows,'photo_visits':rows*EPOCHS,'native_queries_per_head':rows*EPOCHS*3,
        'epoch_count':EPOCHS,'seed':SEED,'photos_per_update':PHOTOS,
        'optimizer':'AdamW, 24 update warmup, .001→.0001 cosine, decay .001, gradient cap 2, EMA .99',
        'loss':'Absolute true complex residual for present/attenuated + .65 paired difference + .50 absolute flat residual + .70 flat-core correction energy, plus weight 9 on squared error aligned with the exact paired increment. Both heads have exactly the same samples and initialization.',
        'policy':'FP32 component. Two outputs train jointly with no parameter sharing, same geometry and seeds.',
        'progress':logged})


if __name__=='__main__':
    import sys
    {'features':collect,'train':train}[sys.argv[1]]()
