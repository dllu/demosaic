"""Evaluate the learned heads on archived, held-out natural and weak-wire targets."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.archive_metrics import linear_rgb, photometry
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from head import LUMA, ROOT, GainHead, apply, exterior, features
from evaluate import target_coeff

NATIVE=ROOT.parent/'scene-local-contrast-2400-v1'
WIRE=ROOT.parent/'query-exterior-colour-v1'
CHECKPOINTED=ROOT/'training-aligned/completed.json'
ROI=(80,80,96,96)
CORE=np.s_[64:192,64:192]
MODELS={'shape':('EMA','shape','shape'),'scalar':('EMA','scalar','scalar'),
        'shape-transposed':('EMA','shape','transposed'),'shape-local':('EMA','shape','local'),
        'shape-raw':('model','shape','shape'),'scalar-raw':('model','scalar','scalar')}


def load():
    point=reference(CHECKPOINTED)
    receipt=read_json(checked(point))
    # AdamW stored the cosine learning rate as a NumPy float scalar.
    with torch.serialization.safe_globals([np._core.multiarray.scalar,np.dtype,np.dtypes.Float64DType]):
        state=torch.load(checked(receipt['checkpoint']),weights_only=True,map_location='cpu')
    result={}
    for name,(weight,source,_) in MODELS.items():
        current=GainHead()
        current.load_state_dict(state[weight][source],strict=True)
        result[name]=current.eval().requires_grad_(False)
    return result,point,receipt


def luma(value, cal):
    return np.einsum('c,bchw->bhw',LUMA,linear_rgb(value,cal))


def groups(raw, full, parent, cfa, wb, matrix, settings, box, models):
    donors=exterior(full,cfa[0],settings,box)
    answer={name:[] for name in models}
    for mosaic,p,layout,balance,conversion in zip(raw,parent,cfa,wb,matrix,strict=True):
        block=features(mosaic,layout,settings,box,donors,p,balance,conversion)
        for mode,m in models.items():
            out=apply(m,block,p,MODELS[mode][2])
            assert out.dtype==np.float32 and np.isfinite(out).all()
            answer[mode].append(out)
    return {name:np.stack(r) for name,r in answer.items()}


def source_rms(full, divisor=1):
    return float(np.sqrt(np.sum(full**2)/divisor)*65535)


def natural_values(record):
    item=read_json(checked(record))
    test=read_json(checked(item['case']))
    with np.load(checked(test['input']),allow_pickle=False)as f:
        args={k:(np.broadcast_to(f[k][None],(3,*f[k].shape))if k in ('colors','wb','matrix') else f[k])for k in f.files}
    with np.load(checked(item['saved']),allow_pickle=False)as f:
        models={k:f[k] for k in ('100k','V120')}
    assert test['fingerprints']['packed']==item['exact_query_inputs']['packed']
    return test,args,models


def native_case(record, heads):
    test,data,inherited=natural_values(record)
    composed=groups(data['packed'],data['scene_packed'],inherited['100k'],data['colors'],data['wb'],data['matrix'],
                    test['profile'],test['box'],heads)
    exact=target_coeff(data['target'],data,ROI)
    assert np.max(abs(exact[2]))<1e-13
    ref=exact[0]-exact[1]
    reference=target_coeff(inherited['100k'],data,ROI)
    stats={}
    for key,y in (inherited|composed).items():
        pred=target_coeff(y,data,ROI)
        recovered=pred[0]-pred[1]
        stats[key]={'increment_DN16':source_rms(recovered-ref,96**2),
                    'present_DN16':source_rms(pred[0]-exact[0],96**2),
                    'flat_DN16':source_rms(pred[2],96**2),
                    'flat_added_DN16':source_rms(pred[2]-reference[2],96**2),
                    'attenuated_added_DN16':source_rms(pred[1]-reference[1],96**2),
                    'dot':float(np.sum(ref*recovered)),
                    'power':float(np.sum(ref**2)),
                    'srgb_present_dB':float(photometry(y/test['profile']['exposure'],data|{'target':data['target']/test['profile']['exposure']})['srgb_psnr'][0])}
    return {'id':test['id'],'source':test['source'],'profile':test['profile']['name'],'draw':test['draw'],
            'input':test['input'],'baseline':record,'measures':stats}


def wire_values(item, control, plan):
    assert item['input']==control['input']
    with np.load(checked(item['input']),allow_pickle=False) as f:
        args={k:f[k] for k in ('packed','variance','colors','matrix','wb','target','support')}
    with np.load(checked(item['output']),allow_pickle=False)as f:
        parents={'100k':f['parent'],'shared-gap':f['shared']}
    parents['V120']=np.load(checked(control['output']),allow_pickle=False)
    crops={k:args[k]for k in ('colors','wb','matrix','support')} | {
        'full':args['packed'],'packed':args['packed'][...,64:192,64:192],
        'target':args['target'][...,128:384,128:384]}
    details=plan['sources'][item['index']]
    return crops,parents,details


def wire_case(record, heads, plan):
    item,control=record
    args,parents,details=wire_values(item,control,plan)
    measurements=groups(args['packed'],args['full'][0],parents['100k'],args['colors'],args['wb'],args['matrix'],
                        plan['profiles'][item['noise']],plan['query'],heads)
    label=details['geometry']['color_role']
    truth=luma(args['target'],args)[...,CORE[0],CORE[1]]
    bases=luma(parents['100k'],args)[...,CORE[0],CORE[1]]
    true=truth[0]-truth[1]
    mask=args['support'][CORE]>=.97
    gap=args['support'][CORE]<=.01
    exact=true[mask]
    assert len(exact)>100
    stats={}
    for k,out in (parents|measurements).items():
        pred=luma(out,args)[...,CORE[0],CORE[1]]
        recovered=(pred[0]-pred[1])[mask]
        addition=pred[0]-bases[0]
        flat=(pred[3]-bases[3])[8:-8,8:-8]
        stats[k]={'intact_increment_DN16':source_rms(recovered-exact,len(exact)),
                  'present_DN16':source_rms(pred[0]-truth[0],128**2),
                  'flat_added_DN16':source_rms(flat,flat.size),
                  'no_weak_added_DN16':source_rms(pred[2]-bases[2],128**2),
                  'gap_added_DN16':source_rms(addition[gap],int(gap.sum())) if gap.any() else None,
                  'dot':float(exact@recovered),'power':float(exact@exact)}
    return {'id':f'{item["index"]:03d}-{item["noise"]}','profile':item['noise'],'source':details['source']['id'],'colour':label,
            'family':details['geometry']['family'],'input':item['input'],'baseline':item,'measures':stats}


def summarize(rows,wire):
    signal=np.random.default_rng(561227)
    result={}
    for profile in ('iso400','iso6400'):
        groups={'all':[r for r in rows if r['profile']==profile]} if wire else {
            name:[r for r in rows if r['profile']==profile and r['draw']==name]for name in ('coupled','independent')}
        result[profile]={}
        for key,group in groups.items():
            sample=signal.integers(len(group),size=(5000,len(group)))
            result[profile][key]={}
            for side in group[0]['measures']:
                matches=[r['measures'][side]for r in group]
                base=[r['measures']['100k']for r in group]
                scalar=[r['measures']['scalar']for r in group]
                outcomes={}
                for metric in matches[0]:
                    if metric in ('dot','power'):
                        continue
                    good=np.asarray([m[metric]is not None for m in matches])
                    values=np.array([m[metric] or 0. for m in matches])[good]
                    start=np.array([m[metric] or 0. for m in base])[good]
                    compare=np.array([m[metric] or 0. for m in scalar])[good]
                    n=len(values)
                    if not n:
                        continue
                    permute=sample if n==len(group) else signal.integers(n,size=(5000,n))
                    delta=values-start
                    control=values-compare
                    outcomes[metric]={'mean':float(values.mean()),'minus_parent':[float(delta.mean()),*np.quantile(delta[permute].mean(1),[.025,.975]).tolist()],
                                      'minus_scalar':[float(control.mean()),*np.quantile(control[permute].mean(1),[.025,.975]).tolist()]}
                numerator=np.array([r['dot']for r in matches])
                energy=np.array([r['power']for r in matches])
                added=numerator-np.array([r['dot']for r in base])
                scalar_effect=numerator-np.array([r['dot']for r in scalar])
                intervals=lambda v: [float(100*v.sum()/energy.sum()), *np.quantile(100*v[sample].sum(1)/energy[sample].sum(1),[.025,.975]).tolist()]
                outcomes['response_percent']={'mean':float(100*numerator.sum()/energy.sum()),'minus_parent':intervals(added),
                                              'minus_scalar':intervals(scalar_effect)}
                result[profile][key][side]=outcomes
    return result


def main(name):
    torch.set_num_threads(1)
    models,binding,end=load()
    if name=='natural':
        source=reference(NATIVE/'evaluation/collected.json')
        pairs=read_json(checked(source))['records']
        run=partial(native_case,heads=models)
    else:
        source=reference(WIRE/'fresh-gap.json')
        candidate=read_json(checked(source))
        control=read_json(checked(reference(ROOT/'v120-wire.json')))
        assert control['source']==source
        pairs=list(zip(candidate['rows'],control['rows'],strict=True))
        run=partial(wire_case,heads=models,plan=read_json(WIRE/'plan.json'))
    rows=[]
    started=time.monotonic()
    with ThreadPoolExecutor(3)as pool:
        for row in pool.map(run,pairs):
            rows.append(row)
            if len(rows)%16==0:
                print(len(rows),round(time.monotonic()-started,1),flush=True)
    write_json(ROOT/f'{name}-aligned-scores.json',{'driver':reference(__file__),'checkpoint':end['checkpoint'],'training':binding,
         'source':source,'seconds':time.monotonic()-started,'weights':MODELS,'rows':rows,'summary':summarize(rows,name=='wire')})

if __name__=='__main__':
    import sys
    main(sys.argv[1])
