"""Learn a bounded achromatic residual in native Fourier coordinates."""
from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np
import torch
from torch import nn

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'scene-spectrum-detail-v1'
sys.path.append(str(PRIOR))
from spectrum import BAND, FX, FY, HALF, N, STRIDE, SYNTH, analyze, exterior, green_fft, priors, squares

LUMA=np.array([.2126,.7152,.0722])
SUPPORTED=BAND&HALF
FREQ_I,FREQ_J=np.where(SUPPORTED)
FREQUENCIES=len(FREQ_I)
CAP=np.array([.45,.30,.22],np.float32)
ROUTES=('scalar','shape','transposed','local')
YI,XI=np.indices((15,15))
YI,XI=YI.ravel()*STRIDE,XI.ravel()*STRIDE
EXACT_FLAT=((2*YI>=80)&(2*YI+32<=176)&(2*XI>=80)&(2*XI+32<=176))


@dataclass
class Field:
    inputs: np.ndarray
    contexts: np.ndarray
    basis: np.ndarray
    noise: np.ndarray
    desired: np.ndarray | None
    neutral: np.ndarray


def green_units(rgb,wb,matrix,neutral):
    k=(LUMA@matrix)*wb
    return np.einsum('c,chw->hw',k,rgb)*neutral[1]


def direct_fft(rgb):
    windows=np.lib.stride_tricks.sliding_window_view(rgb,(2*N,2*N))[YI*2,XI*2]
    mean=(windows*SYNTH).sum(axis=(-2,-1),keepdims=True)/SYNTH.sum()
    # The native unitary FFT of a continuous mode has twice the amplitude of
    # its 2x-decimated unitary FFT. Keep both in packed-analysis units.
    full=np.fft.fft2((windows-mean)*SYNTH,norm='ortho') * .5
    return full[:,FREQ_I,FREQ_J]


def features(raw,layout,noise,box,surroundings,parent,wb,matrix,target=None):
    if raw.shape!=(4,128,128) or parent.shape!=(3,256,256):
        raise ValueError('Expected 256 native Bayer pixels and matched RGB')
    station=analyze(raw,layout,noise,YI,XI)
    neutral=np.linalg.solve(matrix,np.ones(3))/wb
    sensor=green_units(parent,wb,matrix,neutral)
    base=direct_fft(sensor)
    p_green=green_fft(squares(np.stack([parent[1,p//2::2,p%2::2]for p in range(4)]),YI,XI),
                      np.flatnonzero(layout==1)).mean(axis=1)[:,SUPPORTED]
    noise_std=np.sqrt(station.noise[:,None]).clip(min=2e-5)
    cross=station.cross[:,SUPPORTED]
    a,b=(station.green[:,k][:,SUPPORTED] for k in range(2))
    observation=(a+b)*.5
    measured_axes=observation/np.maximum(abs(observation),1e-12)
    phase=base/np.maximum(abs(base),1e-12)
    agreement=np.sqrt(np.maximum(cross,0)/(1+np.maximum(cross,0)))
    innovation=(observation-p_green)*agreement
    coherent=(np.sqrt(np.maximum(cross-.6,0))*noise_std*measured_axes - base)*agreement
    values=np.stack((base,innovation,coherent),axis=-1)
    local=np.maximum(station.cross[:,BAND].mean(axis=1),0)[:,None,None]
    result=priors(station,surroundings,box,local)
    ctx=np.stack([np.log1p(np.broadcast_to(result[src],station.cross.shape)[:,SUPPORTED])
                         for src in ('exterior-scalar','exterior-shaped','exterior-transposed','local')],axis=-1)
    power=np.maximum(abs(a)*abs(b),1e-10)
    noise_level=np.broadcast_to(np.log(noise_std/.012),base.shape)
    coarse=np.broadcast_to(station.features[:,3,None],base.shape)
    chroma_change=np.log1p(abs(p_green-base)/noise_std)
    max_raw=squares(raw,YI,XI).max(axis=(1,2,3))
    saturation=np.broadcast_to(max_raw[:,None].clip(0,1),base.shape)
    directional=(FX[SUPPORTED]*FY[SUPPORTED]) / .06
    features=np.stack((
        np.log1p(abs(a)/noise_std), np.log1p(abs(b)/noise_std),
        np.log1p(abs(base)/noise_std), np.log1p(abs(p_green)/noise_std),
        np.log1p(abs(observation-p_green)/noise_std), np.arcsinh(cross),
        (a*b.conj()).real/power, (measured_axes*phase.conj()).real,
        abs((measured_axes*phase.conj()).imag), chroma_change, noise_level, coarse,
        np.broadcast_to(abs(FX[SUPPORTED])/.25,base.shape),
        np.broadcast_to(abs(FY[SUPPORTED])/.25,base.shape),
        np.broadcast_to(directional,base.shape), saturation,
        np.broadcast_to(np.log1p(local[:,0,0,None]),base.shape),
    ),axis=-1).clip(-8,8)
    expected=None if target is None else direct_fft(green_units(target,wb,matrix,neutral))-base
    return Field(features.astype(np.float32),ctx.astype(np.float32),values.astype(np.complex64),
                 noise_std.astype(np.float32),None if expected is None else expected.astype(np.complex64),neutral)


class GainHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers=nn.Sequential(nn.Linear(18,32),nn.SiLU(),nn.Linear(32,32),nn.SiLU(),nn.Linear(32,3))
        nn.init.zeros_(self.layers[-1].weight)
        nn.init.zeros_(self.layers[-1].bias)
        self.register_buffer('cap',torch.from_numpy(CAP.copy()))

    def forward(self, features, contexts, basis):
        logits=self.layers(torch.cat((features,contexts[...,None]),dim=-1))
        weights=logits.tanh()*self.cap
        return (basis*weights[...,None]).sum(dim=-2)


def synthesis(spectrum):
    n=len(spectrum)
    full=np.zeros((n,2*N,2*N),dtype=complex)
    full[:,FREQ_I,FREQ_J]=spectrum
    full[:,-FREQ_I,-FREQ_J]=spectrum.conj()
    images=2*np.fft.ifft2(full,norm='ortho').real
    canvas=np.zeros((256,256),dtype=float)
    total=np.zeros_like(canvas)
    for y,x,sample in zip(YI*2,XI*2,images,strict=True):
        core=np.s_[y:y+2*N,x:x+2*N]
        canvas[core]+=sample*SYNTH
        total[core]+=SYNTH**2
    side=np.minimum(np.arange(256)+.5,np.arange(256)[::-1]+.5)
    boundary=np.clip((side-8)/24,0,1)
    return (canvas/np.maximum(total,.05)) * boundary[:,None]*boundary[None,:]


@torch.inference_mode()
def apply(model, field, parent, mode):
    band=int(ROUTES.index(mode))
    dtype=next(model.parameters()).dtype
    location=next(model.parameters()).device
    values=lambda a:torch.from_numpy(np.ascontiguousarray(a)).to(device=location,dtype=dtype)
    vectors=np.stack((field.basis.real,field.basis.imag),axis=-1)
    coeff=model(values(field.inputs),values(field.contexts[...,band]),values(vectors)).cpu().numpy()
    delta=synthesis(coeff[...,0]+1j*coeff[...,1])
    return parent+((field.neutral/field.neutral[1])[:,None,None]*delta[None]).astype(parent.dtype)


def camera_field(raw, layout, noise, box, donors, parent, wb, matrix, truth=None):
    outer=exterior(donors, layout, noise, box)
    return features(raw,layout,noise,box,outer,parent,wb,matrix,truth)
