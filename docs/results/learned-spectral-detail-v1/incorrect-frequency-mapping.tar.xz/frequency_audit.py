"""Measure which exact wire frequencies each residual bandwidth can express."""
from pathlib import Path

import numpy as np

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import head,head_broad

ROOT=Path(__file__).resolve().parent
WIRE=ROOT.parent/'query-exterior-colour-v1'
CORE=np.s_[64:192,64:192]


def main():
    mark=reference(WIRE/'plan.json')
    conditions=read_json(checked(mark))
    cases=reference(WIRE/'fresh-gap.json')
    base=read_json(checked(cases))
    rows=[]
    for item in base['rows']:
        if item['noise']!='iso6400':
            continue
        layout=conditions['sources'][item['index']]['geometry']
        frequency=float(np.linalg.norm(layout['frequency'][1]))
        with np.load(checked(item['input']),allow_pickle=False)as f:
            cal={k:f[k] for k in ('wb','matrix')}
            target=f['target'][...,128:384,128:384]
            intact=f['support'][CORE]>=.97
        with np.load(checked(item['output']),allow_pickle=False)as f:
            parent=f['parent']
        yy=lambda z:np.einsum('c,bchw->bhw',head.LUMA,linear_rgb(z,cal))
        actual=yy(target)
        inherited=yy(parent)
        ideal=actual[0]-actual[1]
        before=inherited[0]-inherited[1]
        keep=ideal[CORE][intact]
        denom=float(keep@keep)
        receipts={}
        for k,engine in (('narrow',head),('broad',head_broad)):
            signal=engine.synthesis(engine.direct_fft(ideal))[CORE][intact]
            limit=engine.synthesis(engine.direct_fft(ideal-before))[CORE][intact]
            p=before[CORE][intact]+limit
            receipts[k]={'projection_of_synthesis_of_exact_increment':float(100*signal@keep/denom),
                 'projection_with_spectral_exact_residual':float(100*p@keep/denom),
                 'increment_RMS_with_spectral_exact_residual_DN16':float(np.sqrt(np.mean((p-keep)**2))*65535)}
        rows.append({'source':item['index'],'planted_weak_frequency_cycles_per_native_pixel':frequency,
            'exact_input':item['input'],'diagnostic':receipts,
            'preceding_projection':float(100*before[CORE][intact]@keep/denom)})
    totals={k:{metric:float(np.mean([r['diagnostic'][k][metric] for r in rows])) for metric in rows[0]['diagnostic'][k]}
            for k in ('narrow','broad')}
    count=sum(r['planted_weak_frequency_cycles_per_native_pixel']<.112 for r in rows)
    write_json(ROOT/'frequency-audit.json',{'driver':reference(__file__),'plan':mark,'target_archive':cases,
          'weak_fundamental_below_narrow_band':count,'summary':totals,'rows':rows,
          'scope':'Truth-assisted diagnostic. Apply each architecture’s fixed Fourier analysis and overlap-add to the exact increment or exact residual. No delivered result uses these coefficients.'})
    print(count,totals,flush=True)

if __name__=='__main__':
    main()
