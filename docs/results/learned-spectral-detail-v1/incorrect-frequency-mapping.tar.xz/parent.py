"""Save the same frozen Corpus 100k forward for the two matched heads."""
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import load_checkpoint
from demosaic.precision import amp_context

ROOT=Path(__file__).resolve().parent
KEYS=('packed','variance','colors','wb','matrix')


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,7*2**30/torch.cuda.get_device_properties(0).total_memory))
    inputs=reference(ROOT/'observations.json')
    capture=read_json(checked(inputs))
    plan=read_json(checked(capture['plan']))
    model,state=load_checkpoint(plan['parent']['path'],'cuda')
    assert (state['loaded_sha256'],state['step'])==(plan['parent']['sha256'],100000) and 'ema' in state
    model.eval().to(memory_format=torch.channels_last)
    del state
    print('frozen parent ready',flush=True)
    output=ROOT/'parents'
    output.mkdir()
    started=time.monotonic()
    rows=[]
    for note,source in zip(capture['rows'],plan['batches'],strict=True):
        record=read_json(checked(note))
        assert record['index']==source['index']
        noise=source['noise']
        model.set_noise(noise['shot'],noise['read'])
        with np.load(checked(record['input']),allow_pickle=False)as file:
            args=[torch.from_numpy(file[k]).cuda()for k in KEYS]
        args[:2]=[v.contiguous(memory_format=torch.channels_last)for v in args[:2]]
        with amp_context('cuda',dtype='float16'):
            img=model(*args)
        assert img.dtype==torch.float32
        result=img.cpu().numpy()
        assert result.shape==(3,3,256,256) and np.isfinite(result).all()
        path=output/f'{source["index"]:03d}.npy'
        np.save(path,result,allow_pickle=False)
        proof={'index':source['index'],'measurement':note,'parent':reference(path)}
        write_json(path.with_suffix('.json'),proof)
        rows.append(proof)
        if len(rows)%20==0:
            print(len(rows),round(time.monotonic()-started,2),flush=True)
    write_json(ROOT/'parents.json',{'driver':reference(__file__),'observations':inputs,'plan':capture['plan'],
              'parent':plan['parent'],'precision':'standard GPU FP16 autocast, FP32 output',
              'forward_seconds_wall':time.monotonic()-started,'rows':rows})

if __name__=='__main__':
    main()
