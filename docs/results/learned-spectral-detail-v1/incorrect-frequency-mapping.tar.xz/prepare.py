"""Freeze ordinary training photos and paired native Bayer observations."""
from collections import Counter
from dataclasses import asdict, replace
import json
import math
from pathlib import Path
import random
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.data.paired import paired_observation
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_data import observe_scene, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT=Path(__file__).resolve().parent
DATA=ROOT.parent/'scene-local-contrast-2400-v1'
SPECTRAL=ROOT.parent/'scene-spectrum-detail-v1'
PARENT_HISTORY=Path('docs/results/full-corpus-long100k-primary-v1/primary.json')
sys.path.insert(0,str(DATA))
from prepare_eval import flat_patch, patch

SEED=145660225549
COUNT=320
PROFILES=({'name':'iso400','shot':.00008,'read':2.56e-8,'exposure':.33},
          {'name':'iso6400','shot':.00128,'read':6.5536e-6,'exposure':.33})
KEYS=('packed','variance','colors','wb','matrix')
ROLES=('present','attenuated','flat')


def freeze():
    controller=read_json(ROOT.parent/'scene-full-epoch-v1/plan.json')
    train=controller['train_manifest']
    held=reference(DATA/'evaluation-plan.json')
    wired=reference(ROOT.parent/'query-exterior-colour-v1/plan.json')
    forbidden={r['source']['id'] for mark,key in ((held,'rows'),(wired,'sources')) for r in read_json(checked(mark))[key]}
    primary=reference(PARENT_HISTORY)
    predecessor=read_json(checked(primary))
    forbidden.update(predecessor['source_averages'])
    with checked(train).open() as stream:
        rows=[json.loads(line)for line in stream if line.strip()]
    assert len(rows)==90692 and all(r['split']=='train' for r in rows)
    assert {r['id']for r in rows}.isdisjoint(forbidden)
    candidates=[r for r in rows if min(r['shape'][:2])>=512 and np.prod(r['shape'][:2])<=7000000]
    selected=random.Random(SEED).sample(candidates,COUNT)
    plan=[]
    for i,src in enumerate(selected):
        profile=PROFILES[(i//4)%2]
        conf=sample_scene_recipe(scene_seed(SEED,i,'camera'))
        shot=profile['shot']; read=profile['read']
        rng=np.random.default_rng(scene_seed(SEED,i,'geometry'))
        exposure=.33*float(np.exp(rng.uniform(-.35,.35)))
        camera=replace(conf,pattern=tuple(PATTERNS)[i%4],shot=shot,read=read,exposure=exposure,black=.03)
        larger,=scene_crop_boxes(src['shape'][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,'scene-box'))
        x,y=(128+2*int(t) for t in rng.integers(-20,21,2))
        style='wire' if (i//32)%4==0 else 'photo'
        law='coupled' if (i//8)%4==0 else 'independent'
        seeds={name:scene_seed(SEED,i,name)for name in ('scene','present','attenuated','flat','coupled')}
        plan.append({'index':i,'source':src,'scene_box':larger,'box':[x,y,256,256],
                     'camera':asdict(camera),'noise':profile|{'exposure':exposure},
                     'style':style,'draw':law,'seeds':seeds})
    assert len(set(r['source']['id']for r in plan))==COUNT
    write_json(ROOT/'plan.json',{'driver':reference(__file__),'seed':SEED,'parent':predecessor['models']['scale-long100k']['checkpoint'],
              'training_manifest':train,'eligible':len(candidates),'protected_evaluation':[held,wired,primary],
              'phase_implementation':reference(SPECTRAL/'spectrum.py'),'roles':ROLES,
              'batches':plan,'strata':{f'{a}/{b}/{c}':n for (a,b,c),n in Counter(
                  (r['noise']['name'],r['style'],r['draw']) for r in plan).items()},
              'scope':'All sources come from the protected-scene-excluding ordinary training manifest. Whole native 512-pixel Bayer contexts exclude the query and halo. A random jitter moves each 256-pixel query.'})


def extract(row):
    source=row['source']
    link={'path':source['cache'],'sha256':source['cache_sha256']}
    pixels=np.load(checked(link),mmap_mode='r',allow_pickle=False)
    assert pixels.dtype==np.uint16 and list(pixels.shape)==source['shape']
    x,y,w,h=row['scene_box']
    values=pixels[y:y+h,x:x+w].astype(np.float32)
    return torch.from_numpy(values).permute(2,0,1).contiguous()/65535


def wire_targets(photo,row):
    rng=np.random.default_rng(scene_seed(SEED,row['index'],'finite-wires'))
    yy,xx=torch.meshgrid(torch.arange(512,dtype=torch.float32),torch.arange(512,dtype=torch.float32),indexing='ij')
    center=(rng.uniform(200,310),rng.uniform(200,310))
    turn=rng.uniform(0,math.pi/2)
    angles=(turn,turn+rng.uniform(.8,1.6))
    structure=[]
    for phi in angles:
        phase=2*math.pi*rng.uniform(.113,.206)*(xx*math.cos(phi)+yy*math.sin(phi))+rng.uniform(-math.pi,math.pi)
        structure.append(phase.cos()+.26*(2*phase).cos())
    a,b=structure
    dx,dy=xx-center[0],yy-center[1]
    footprint=1.-.95*torch.exp(-.5*((dx/rng.uniform(13,32))**2+(dy/rng.uniform(15,40))**2))
    base=.04+.86*photo+.013*a
    weak=rng.uniform(.0035,.012)*b*footprint*(.88-.18*a)
    absent=base
    present=base+weak
    strong_surround=base+2.2*weak
    x,y,w,h=row['box']
    roi=np.s_[:,y:y+h,x:x+w]
    return strong_surround.clamp(.001,.995),[present.clamp(.001,.995)[roi].contiguous(),absent.clamp(.001,.995)[roi].contiguous()]


def observations(row):
    photo=extract(row)
    camera=replace(sample_scene_recipe(SEED),**row['camera'])
    if row['style']=='photo':
        ratio=.18+.44*np.random.default_rng(scene_seed(SEED,row['index'],'detail-strength')).random()
        scene=photo
        clean=[patch(photo,row['box'],ratio),patch(photo,row['box'],0.)]
    else:
        scene,clean=wire_targets(photo,row)
    clean.append(flat_patch(clean[1]))
    large=observe_scene(scene,replace(camera,noise_seed=row['seeds']['scene']))
    if row['draw']=='coupled':
        pair,_=paired_observation(clean[0][None],clean[1][None],row['noise'],[camera.pattern],
                   torch.tensor(camera.wb)[None],torch.tensor(camera.camera_inverse)[None],row['seeds']['coupled'])
        native={k:list(pair[k])for k in (*KEYS,'target')}
        v=observe_scene(clean[-1],replace(camera,noise_seed=row['seeds']['flat']))
        for k in native:
            native[k].append(getattr(v,k).numpy())
    else:
        locals_=[observe_scene(v,replace(camera,noise_seed=row['seeds'][role])) for role,v in zip(ROLES,clean,strict=True)]
        native={k:[getattr(v,k).numpy()for v in locals_] for k in (*KEYS,'target')}
    for k in ('colors','wb','matrix'):
        for v in native[k]:
            np.testing.assert_array_equal(getattr(large,k).numpy(),v)
    return {k:np.stack(v)for k,v in native.items()} | {'scene_packed':large.packed.numpy()}


def collect():
    torch.set_num_threads(2)
    directory=ROOT/'observations'
    directory.mkdir(exist_ok=True)
    plan=reference(ROOT/'plan.json')
    schedule=read_json(checked(plan))
    observed=[]
    for row in schedule['batches']:
        i=row['index']
        fields=observations(row)
        npz=directory/f'{i:03d}.npz'
        with npz.open('xb')as file:
            np.savez(file,**fields)
        record=directory/f'{i:03d}.json'
        write_json(record,{'plan':plan,'index':i,'input':reference(npz),
              'fingerprints':{k:fingerprint(v)for k,v in fields.items()}})
        observed.append(reference(record))
        if i%20==0:
            print(i,row['style'],row['noise']['name'],flush=True)
    write_json(ROOT/'observations.json',{'driver':reference(__file__),'plan':plan,'rows':observed})


if __name__=='__main__':
    freeze()
    collect()
