"""Compare both trained luminance heads on the two standing cached RAW scenes."""
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display, linear_rgb
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from head import LUMA, ROOT, exterior, features, apply
from review import load

LAST=ROOT.parent/'query-exterior-colour-v1/standing/manifest.json'
NEURAL=ROOT.parent/'query-signed-colour-v1/standing/manifest.json'
sys.path.insert(0,str(ROOT.parent/'paired-luminance-detail-v1'))
from render import native_png


def main():
    torch.set_num_threads(1)
    loaded,train,entry=load()
    reference_base,reference_prior=reference(NEURAL),reference(LAST)
    neural,prior=(read_json(checked(r))for r in (reference_base,reference_prior))
    assert neural['checkpoint']==prior['checkpoint']
    progress=read_json(checked(entry['cache']))
    front=read_json(checked(progress['parents']))
    assert front['parent']['sha256']==neural['checkpoint']['sha256']
    base={r['id']:r for r in neural['rows']}
    configs={k:reference(f'configs/{p}.json')for k,p in (
        ('main','gfx-qualitative-20231231'),('mesh','gfx-green-mesh-20231231'))}
    main_cfg,mesh_cfg=(read_json(checked(configs[k]))for k in ('main','mesh'))
    saved=ROOT/'standing'
    saved.mkdir()
    receipts=[]
    for kind,source in (('main',reference(main_cfg['noisy'])),('mesh',mesh_cfg['sources']['noisy'])):
        raw,meta=read_raw(checked(source))
        layout=np.array(color_indices(meta.pattern))
        h,w=[v//2*2 for v in raw.shape]
        large=np.stack([raw[p//2:h:2,p%2:w:2]for p in range(4)])
        del raw
        for item in prior['rows']:
            id=item['id']
            if not id.startswith(kind+'-'):
                continue
            old=base[id]
            assert old['base_input']==item['base_input'] and old['noise']==item['noise'] and old['ROI']==item['ROI']
            bx,by,_,_=item['box']
            rx,ry,rw,rh=item['ROI']
            if kind=='main':
                chosen=next(r for r in main_cfg['regions'] if id.endswith('-'+r['name']))
                x,y=(a-b for a,b in zip(chosen['noisy_xy'],(rx,ry),strict=True))
            else:
                x,y=mesh_cfg['raw_context_xywh'][:2]
            left,top=x+bx,y+by
            window=(left,top,256,256)
            values=large[:,top//2:top//2+128,left//2:left//2+128]
            with np.load(checked(item['base_input']),allow_pickle=False)as f:
                cfa,wb,matrix=(f[k][0]for k in ('colors','wb','matrix'))
                np.testing.assert_array_equal(values,f['packed'][0,:,by//2:by//2+128,bx//2:bx//2+128])
                np.testing.assert_array_equal(layout,cfa)
            with np.load(checked(old['output']),allow_pickle=False)as f:
                parent=f['parent']
            t0=time.monotonic()
            donors=exterior(large,cfa,item['noise'],window)
            current=features(values,cfa,item['noise'],window,donors,parent,wb,matrix)
            predictions={name:apply(loaded[name],current,parent,name)for name in ('scalar','shape')}
            elapsed=time.monotonic()-t0
            crop=np.s_[...,ry-by:ry-by+rh,rx-bx:rx-bx+rw]
            calibration={'wb':wb[None],'matrix':matrix[None]}
            image=np.asarray(Image.open(checked(item['image'])).convert('RGB'))
            existing={p['name']:image[y:y+h,x:x+w] for p in item['panels'] for x,y,w,h in (p['png_xywh'],)}
            labels=('ISO6400 camera JPEG','Noisy (Malvar)','V120 EMA','Parent 100k EMA','Exterior-frequency colour')
            panels=[(k,existing[k])for k in labels if k in existing]
            d={}
            for name,value in predictions.items():
                out=value[crop]
                a=display(out[None],calibration,exposure=item['display_exposure'])[0]
                panels.append((('Learned total power' if name=='scalar'else 'Learned spectral shape'),np.rint(a.transpose(1,2,0)*255).astype(np.uint8)))
                delta=(out.astype(float)-parent[crop])*65535
                light=linear_rgb(delta[None],calibration)[0]
                chroma=light-np.einsum('c,chw->hw',LUMA,light)[None]
                d[name]={'camera_RMS_DN16':float(np.sqrt(np.mean(delta**2))),
                         'max_camera_DN16':float(abs(delta).max()),
                         'max_scene_linear_chroma_change_DN16':float(abs(chroma).max())}
            panels.extend((k,existing[k])for k in ('ISO100 AHD reference','ISO100 camera JPEG') if k in existing)
            board=native_png(saved/(id+'.png'),panels)
            arrays=saved/(id+'.npz')
            np.savez_compressed(arrays,parent=parent,**predictions)
            receipts.append({'id':id,'raw':source,'input':item['base_input'],'parent':old['output'],'box':window,
                'ROI_xywh':[x+rx,y+ry,rw,rh],'noise':item['noise'],'exposure':item['display_exposure'],
                'board':board,'output':reference(arrays),'measurements':d,'elapsed_seconds':elapsed})
            print(id,{k:round(z['camera_RMS_DN16'],4)for k,z in d.items()},flush=True)
    assert len(receipts)==8
    write_json(saved/'manifest.json',{'driver':reference(__file__),'configs':configs,'parent':front['parent'],
               'trained':entry['checkpoint'],'training':train,'preceding':reference_prior,'rows':receipts})

if __name__=='__main__':
    main()
