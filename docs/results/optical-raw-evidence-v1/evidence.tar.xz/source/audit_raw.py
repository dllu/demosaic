"""Measure weak-template evidence on the 32 existing optical development photos."""

from hashlib import sha256
from pathlib import Path
import sys
import time

import numpy as np
from scipy.special import expit
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent
OUT = Path("/mnt/external/demosaic") / HERE.name
OPTICAL = OUT.with_name("sensor-optical-transfer-v1")
sys.path.insert(0, str(CACHE / "sensor-optical-transfer-v1"))
from capture_optical import arrays, support_for_scoring

DRAWS = 48
WIDTHS = (32, 64, 128)
MODES = ("known_background", "split_plane", "split_edge_strong")
ALPHA = .05
SEED = 202611200019
WINDOW = slice(64, 192)


def packed_query(target, cfa):
    window = target[..., WINDOW, WINDOW]
    return np.stack([window[..., channel, p // 2::2, p % 2::2] for p, channel in enumerate(cfa)], axis=-3)


def geometry(fixture, support):
    y, x = np.meshgrid(np.arange(128) - 63.5, np.arange(128) - 63.5, indexing="ij")
    scaled_x, scaled_y = x / 64, y / 64
    base = [np.ones_like(x), scaled_x, scaled_y]
    edge = x * np.cos(fixture["angle"]) + y * np.sin(fixture["angle"]) - fixture["edge"]
    edge = expit(edge / 1.3)
    strong, weak = fixture["frequency"]
    strong_phase = 2 * np.pi * (strong[0] * x + strong[1] * y) + fixture["phase"][0]
    weak_phase = 2 * np.pi * (weak[0] * x + weak[1] * y) + fixture["phase"][1]
    expanded = base + [scaled_x**2, scaled_x * scaled_y, scaled_y**2, edge, scaled_x * edge, scaled_y * edge]
    for harmonic in (1, 2, 3):
        expanded.extend((np.cos(harmonic * strong_phase), np.sin(harmonic * strong_phase)))
    intact = np.ones((128, 128), dtype=bool) if fixture["family"] == "smooth-dip" else support >= .97
    assert np.count_nonzero(intact) >= 1024
    return np.stack(base), np.stack(expanded), np.cos(weak_phase), intact


def windows(intact):
    positions = [(y, x) for y in range(0, 97, 16) for x in range(0, 97, 16)]
    positions.sort(key=lambda p: ((p[0] - 48)**2 + (p[1] - 48)**2, *p))
    y, x = max(positions, key=lambda p: np.count_nonzero(intact[p[0]:p[0]+32, p[1]:p[1]+32]))
    for width in WIDTHS:
        a = int(np.clip(y + 16 - width // 2, 0, 128 - width))
        b = int(np.clip(x + 16 - width // 2, 0, 128 - width))
        selected = np.zeros_like(intact)
        selected[a:a+width, b:b+width] = True
        yield (b, a, width, width), selected & intact


def phase_stack(mat):
    block = [mat[..., p // 2::2, p % 2::2] for p in range(4)]
    return np.stack(block, axis=0)


def split_filter(proposal, var, nuisance):
    """Predict the nuisance from A, test the fixed template on B, then reverse."""
    parity = (np.indices((64, 64)).sum(0) % 2).ravel().astype(bool)
    result = np.zeros_like(proposal)
    for p, phase in enumerate(nuisance):
        n = phase.reshape(len(phase), -1).T
        d = proposal[p].ravel()
        v = var[p].ravel()
        accum = np.zeros_like(d)
        active = np.any(n != 0, axis=1)
        for left in (parity, ~parity):
            a, b = left & active, ~left & active
            assert a.sum() >= 12 and b.sum() >= 12
            projected = d[b] / v[b]
            weights = np.reciprocal(np.sqrt(v[a]))
            design = n[a] * weights[:, None]
            u, s, vt = np.linalg.svd(design, full_matrices=False)
            keep = s > s[0] * 1e-5
            leverage = n[b].T @ projected
            correction = u[:, keep] @ ((vt[keep] @ leverage) / s[keep])
            accum[b] += projected
            accum[a] -= correction * weights
        result[p] = accum.reshape(64, 64)
    return result


def make_filter(proposal, background, profile, mode, design, support):
    var = background * profile["shot"] + profile["read"]
    select = phase_stack(support)
    d = proposal * select
    if mode == "known_background":
        w = d / var
        subtract = float(np.sum(w * background))
    else:
        w = split_filter(d, var, phase_stack(design) * select[:, None])
        subtract = 0.
    scale = float(np.sqrt(np.sum(w**2 * var)))
    assert scale > 0 and np.isfinite(scale)
    return w.ravel() / scale, subtract / scale, scale


def draws(clean, profile, rng):
    shot, read, black = (profile[k] for k in ("shot", "read", "black"))
    noise = rng.poisson(clean / shot, size=(DRAWS, *clean.shape)) * shot
    noise += rng.normal(0, np.sqrt(read), noise.shape)
    adc = (noise * (1 - black) + black).clip(0, 1)
    return ((np.rint(adc * 65535) / 65535 - black) / (1 - black)).reshape(DRAWS, -1)


def evaluate(case, ref, cv):
    data = arrays(ref)
    clean = packed_query(data["target"].astype(np.float64), data["colors"])
    observed = data["packed"][..., 32:96, 32:96].astype(np.float64).reshape(4, -1)
    assert clean.shape == (4, 4, 64, 64) and clean.min() > 0 and clean.max() < .5
    present, _, absent, flat = clean
    increment = present - absent
    profile = case["fixture"]["camera"]
    fixture = case["fixture"]["geometry"]
    support = support_for_scoring(data["support"])[WINDOW, WINDOW]
    plane, edge, hypothetical, intact = geometry(fixture, support)
    null_gap = support == 0
    np.testing.assert_array_equal(increment[:, :, :][phase_stack(null_gap)], np.zeros(np.sum(null_gap)))
    earliest = case["fixture"]["index"]
    # Fresh role draws within each dose. Identical RNG seeds across doses do not
    # enforce common photons when the Poisson means differ.
    sim = {k: draws(clean[k], profile, np.random.default_rng(np.random.SeedSequence((SEED, earliest, k, cv))))
           for k in (0, 2, 3)}

    output = {}
    for box, area in windows(intact):
        width = box[-1]
        result = {}
        for index, mode in enumerate(MODES):
            design = plane if index == 1 else edge
            coef, offset, _ = make_filter(increment, absent, profile, mode, design, area)
            flat_offset = float(coef @ flat.ravel()) if index == 0 else 0.
            result[mode] = {
                "oracle_d_prime": float(coef @ increment.ravel()),
                "actual_present": float(observed[0] @ coef - offset),
                "actual_absent": float(observed[2] @ coef - offset),
                "present": (sim[0] @ coef - offset).tolist(),
                "absent": (sim[2] @ coef - offset).tolist(),
                "flat": (sim[3] @ coef - flat_offset).tolist(),
            }
            if width == 128 and null_gap.any():
                proposed = phase_stack(hypothetical) / data["wb"][data["colors"], None, None]
                w, offset, _ = make_filter(proposed, absent, profile, mode, design, null_gap)
                result[mode]["true_gap"] = (sim[0] @ w - offset).tolist()
        output[str(width)] = {"selected_xywh": box, "pixel_count": int(area.sum()), "scores": result}
    return output


def split(photos):
    result = {"calibration": [], "confirmation": []}
    for group in sorted({r["family"] for r in photos}):
        subset = sorted((r for r in photos if r["family"] == group),
                        key=lambda r: sha256(f"{SEED}:{r['id']}".encode()).hexdigest())
        assert len(subset) == 8
        result["calibration"].extend(subset[:4])
        result["confirmation"].extend(subset[4:])
    return result


def summary(rows):
    comparison = split(rows)
    rng = np.random.default_rng(SEED + 9)
    stats = {}
    for dose in ("0.0", "0.55", "0.85"):
        stats[dose] = {}
        for width in WIDTHS:
            stats[dose][str(width)] = {}
            for method in MODES:
                data = lambda r: r["doses"][dose][str(width)]["scores"][method]
                threshold = float(np.quantile(np.concatenate([data(r)["absent"] for r in comparison["calibration"]]), 1 - ALPHA))
                report = {"threshold": threshold}
                chosen = comparison["confirmation"]
                for tag in ("present", "absent", "flat", "true_gap", "oracle_d_prime"):
                    eligible = [r for r in chosen if tag in data(r)]
                    if not eligible:
                        continue
                    vals = [data(r)[tag] for r in eligible]
                    means = np.asarray(vals) if tag == "oracle_d_prime" else (np.asarray(vals) > threshold).mean(1)
                    groups = [[i for i, r in enumerate(eligible) if r["family"] == group]
                              for group in sorted({r["family"] for r in eligible})]
                    sample = np.hstack([rng.choice(ids, size=(12000, len(ids)), replace=True) for ids in groups])
                    report[tag] = {
                        "n": len(vals), "mean": float(means.mean()),
                        "paired_sources_95": np.quantile(means[sample].mean(1), (.025, .975)).tolist(),
                        "median": float(np.median(means)),
                    }
                report["actual_present_fraction"] = float(np.mean([data(r)["actual_present"] > threshold for r in chosen]))
                report["actual_absent_fraction"] = float(np.mean([data(r)["actual_absent"] > threshold for r in chosen]))
                stats[dose][str(width)][method] = report
    return {k: [r["id"] for r in v] for k, v in comparison.items()}, stats


def main():
    torch.set_num_threads(2)
    OUT.mkdir(parents=True, exist_ok=True)
    inputs_ref = reference(OPTICAL / "inputs.json")
    inputs = read_json(checked(inputs_ref))
    coupled_ref = reference(OPTICAL / "coupled/samples.json")
    readout = read_json(checked(coupled_ref))
    assert readout["standard_input_plan"] == inputs_ref
    historical = read_json(checked(inputs["parents"]))
    rows = []
    started = time.monotonic()
    for case, base, coupled in zip(historical["rows"], inputs["inputs"], readout["inputs"], strict=True):
        assert case["id"] == coupled["id"] == base["case"] and case["input"] == base["inputs"]["0.0"]
        source_doses = {"0.0": case["input"]} | coupled["observations"]
        dose_scores = {dose: evaluate(case, record, cv) for cv, (dose, record) in enumerate(source_doses.items())}
        rows.append({"id": case["id"], "family": case["fixture"]["geometry"]["family"], "doses": dose_scores})
        if len(rows) % 4 == 0:
            print(f"RAW evidence {len(rows)}/32", flush=True)
    assert len(rows) == 32
    selection, stats = summary(rows)
    write_json(OUT / "result.json", {
        "driver": reference(__file__), "input_plan": inputs_ref, "coupled_inputs": coupled_ref,
        "doses": list(source_doses), "requested_false_admission": ALPHA,
        "noise_replicates_per_source_dose_role": DRAWS,
        "scope": "existing development scenes, fixed supplied optical weak template, oracle variance; no model inputs or fresh confirmation",
        "source_split": selection, "summary": stats, "rows": rows, "seconds": time.monotonic() - started,
    })


if __name__ == "__main__":
    main()
