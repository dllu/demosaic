"""Verify the Bayer evidence diagnostic and bind the published summaries."""

from dataclasses import replace
from pathlib import Path
import sys
import tarfile
from unittest.mock import patch

import numpy as np
import torch

from demosaic import scene_data
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from audit_raw import HERE, OUT, SEED, arrays, packed_query, split_filter

from capture_optical import capture_wide, filtered_observation
from summarize_optical import interval, source_bootstrap

REPO = HERE.parents[2]
DEST = REPO / "docs/results" / OUT.name


def verify_split():
    rng = np.random.default_rng(SEED)
    plane = np.stack([np.ones((64, 64)), *np.indices((64, 64)) / 64])
    n = np.repeat(plane[None], 4, axis=0)
    d = rng.uniform(-1, 1, size=(4, 64, 64))
    v = rng.uniform(.5, 1, size=d.shape)
    raw = (np.einsum("ptxy,pt->pxy", n, rng.random((4, 3))) + .3 * d
           + rng.normal(size=d.shape) * np.sqrt(v))
    w = split_filter(d, v, n)
    a = np.indices((64, 64)).sum(0) % 2 == 0
    expected = 0.
    for mask in (a, ~a):
        for channel in range(4):
            design = n[channel][:, mask].T
            inverse = 1 / np.sqrt(v[channel, mask])
            beta = np.linalg.lstsq(design * inverse[:, None], raw[channel, mask] * inverse, rcond=1e-5)[0]
            validation = raw[channel, ~mask] - n[channel][:, ~mask].T @ beta
            expected += float(validation @ (d[channel, ~mask] / v[channel, ~mask]))
    np.testing.assert_allclose(np.sum(w * raw), expected, rtol=1e-10, atol=1e-10)
    assert np.max(np.abs(np.sum(w[:, None] * n, axis=(-2, -1)))) < 1e-9


def verify_sensor_means(known):
    inputs = read_json(checked(known["input_plan"]))
    coupled = read_json(checked(known["coupled_inputs"]))
    original = read_json(checked(inputs["parents"]))
    count = 0
    for row, variant in zip(original["rows"], coupled["inputs"], strict=True):
        assert row["id"] == variant["id"]
        fixture = row["fixture"]
        photo = capture_wide.wire_math.decode(fixture["source"], fixture["box"])
        images, _, _, _ = capture_wide.wire_math.exact(photo, fixture["geometry"])
        recipe = replace(capture_wide.sample_scene_recipe(SEED), **fixture["camera"])
        for sigma, raw in ({"0.0": row["input"]} | variant["observations"]).items():
            observed = arrays(raw)
            with patch.object(scene_data, "add_noise", lambda clean, *args, **kwargs: clean):
                fields = [filtered_observation(rgb, recipe, float(sigma)).packed.numpy() for rgb in images]
            np.testing.assert_array_equal(packed_query(observed["target"], observed["colors"]),
                                          np.stack(fields)[..., 96:160, 96:160])
            count += 1
    return count


def benefits(known, context):
    ids = context["source_split"]["confirmation"]
    assert context["source_split"] == known["source_split"]
    order = {x["id"]: x for x in known["rows"]}
    selected = [row for row in context["rows"] if row["id"] in ids]
    ranked = sorted(selected, key=lambda r: order[r["id"]]["doses"]["0.0"]["128"]["scores"]["known_background"]["oracle_d_prime"])
    rng = np.random.default_rng(SEED + 7)
    effects = {}
    sigma = "0.85"
    for key, rows in (("all", selected), ("lowest_template_SNR_half", ranked[:8])):
        ix = source_bootstrap(rows, rng)
        measurements = {}
        for mode, width in (("exterior_phase", "32"), ("exterior_phase", "64"),
                            ("exterior_phase", "128"), ("quarter_cycle_control", "64")):
            hist = context["heldout_readout"][sigma][width][mode]
            values = [
                np.mean(np.asarray(r["doses"][sigma][width]["tests"][mode]["present"]) > hist["threshold"])
                for r in rows
            ]
            measurements[(mode, width)] = np.asarray(values)[ix].mean(1)
        a, b, c, placebo = measurements.values()
        effects[key] = {
            "source_count": len(rows), "exterior_detection_by_width": {
                label: interval(x) for label, x in zip(("32", "64", "128"), (a, b, c), strict=True)
            },
            "64_minus_32": interval(b - a), "128_minus_64": interval(c - b),
            "64_correct_minus_quarter_cycle": interval(b - placebo),
        }
    edge128 = known["summary"][sigma]["128"]
    scores = {}
    for method in ("split_plane", "split_edge_strong"):
        threshold = edge128[method]["threshold"]
        scores[method] = np.array([
            np.mean(np.asarray(order[row["id"]]["doses"][sigma]["128"]["scores"][method]["absent"]) > threshold)
            for row in selected
        ])
    effects["128_absent_edge_minus_plane"] = interval(
        (scores["split_edge_strong"] - scores["split_plane"])[source_bootstrap(selected, rng)].mean(1)
    )
    return effects


def main():
    torch.set_num_threads(2)
    a = reference(OUT / "result.json")
    known = read_json(checked(a))
    b = reference(OUT / "exterior.json")
    context = read_json(checked(b))
    assert context["known_template_reference"] == a
    assert context["input_plan"] == known["input_plan"] and context["coupled_inputs"] == known["coupled_inputs"]
    assert len(known["rows"]) == len(context["rows"]) == 32
    verify_split()
    verified = verify_sensor_means(known)
    assert verified == 96
    effects = benefits(known, context)
    DEST.mkdir(exist_ok=True)
    archive = DEST / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for item in (reference(__file__), known["driver"], context["driver"]):
            file = checked(item)
            tar.add(file, arcname=f"source/{file.name}", recursive=False)
        for item in (a, b):
            file = checked(item)
            tar.add(file, arcname=f"receipts/{file.name}", recursive=False)
    write_json(DEST / "publication.json", {
        "scope": "Fixed-template and exterior-phase RAW diagnostic on the 32 existing optical development photos",
        "archive": {"repo_path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "score_source": a, "exterior_source": b, "fixed_template": known["summary"],
        "exterior": context["heldout_readout"], "paired_effects_at_sigma_0_85": effects,
        "inputs": known["input_plan"], "shared_dose_input_capture": known["coupled_inputs"],
        "source_split": known["source_split"], "sensor_mean_arrays_exactly_reproduced": verified,
        "checks": "Split filter reproduced explicit A nuisance fit, held-out B score, and reverse; checked orthogonality.",
    })
    print("Verified", verified, "sensor mean groups and the disjoint split algebra.", flush=True)


if __name__ == "__main__":
    main()
