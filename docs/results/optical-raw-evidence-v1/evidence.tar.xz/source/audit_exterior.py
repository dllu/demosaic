"""Use a disjoint exterior phase with a fixed-frequency held-out Bayer test."""

from pathlib import Path
import time

import numpy as np
from scipy.special import expit
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from audit_raw import (
    ALPHA, DRAWS, OPTICAL, OUT, SEED, WIDTHS, WINDOW, arrays, draws, geometry,
    make_filter, packed_query, phase_stack, support_for_scoring, windows,
)

METHODS = ("exterior_phase", "quarter_cycle_control")


def exterior(data, fixture):
    raw = data["scene_packed"].astype(np.float64)
    assert raw.shape == (4, 256, 256)
    sx, sy = fixture["frequency"][0]
    fx, fy = fixture["frequency"][1]
    y, x = np.meshgrid(np.arange(512) - 255.5, np.arange(512) - 255.5, indexing="ij")
    rad = np.maximum(abs(x), abs(y))
    use = (rad >= 166) & (rad <= 230)
    space = 2 * np.pi * (sx * x + sy * y)
    direction = 2 * np.pi * (fx * x + fy * y)
    edge = expit((x * np.cos(fixture["angle"]) + y * np.sin(fixture["angle"]) - fixture["edge"]) / 1.3)
    ux, uy = x / 256, y / 256
    columns = [np.ones_like(x), ux, uy, ux**2, uy**2, ux * uy, edge, edge * ux, edge * uy]
    for harmonic in (1, 2, 3):
        columns.extend((np.cos(harmonic * space), np.sin(harmonic * space)))
    design = np.stack([*columns, np.cos(direction), np.sin(direction)], axis=-1)
    coeff = []
    levels = []
    for phase, k in enumerate(data["colors"]):
        i, j = divmod(phase, 2)
        mask = use[i::2, j::2]
        matrix = design[i::2, j::2][mask]
        source = raw[phase][mask]
        fit = np.linalg.lstsq(matrix, source, rcond=1e-6)[0]
        coeff.append(fit[-2:] * data["wb"][k])
        levels.append(max(0.0005, float(np.median(source))))
    cosine, sine = np.mean(coeff, axis=0)
    phase = float(np.arctan2(-sine, cosine))
    return phase, np.array(levels)


def readout(case, ref, dose_index):
    data = arrays(ref)
    fixture = case["fixture"]["geometry"]
    profile = case["fixture"]["camera"]
    clean = packed_query(data["target"].astype(np.float64), data["colors"])
    support = support_for_scoring(data["support"])[WINDOW, WINDOW]
    _, basis, _, intact = geometry(fixture, support)
    gap = support == 0
    zero = np.zeros(gap.sum(), dtype=np.float64)
    np.testing.assert_array_equal((clean[0] - clean[2])[phase_stack(gap)], zero)
    phase, levels = exterior(data, fixture)
    delta = np.angle(np.exp(1j * (phase - fixture["phase"][1])))
    y, x = np.meshgrid(np.arange(128) - 63.5, np.arange(128) - 63.5, indexing="ij")
    fx, fy = fixture["frequency"][1]
    angle = 2 * np.pi * (fx * x + fy * y)
    mean_field = np.broadcast_to(levels[:, None, None], (4, 64, 64))
    simulated = {
        k: draws(clean[k], profile, np.random.default_rng(np.random.SeedSequence(
            (SEED, case["fixture"]["index"], k, dose_index)
        ))) for k in (0, 2, 3)
    }
    real = data["packed"][..., 32:96, 32:96].astype(np.float64).reshape(4, -1)
    output = {}
    for box, pixels in windows(intact):
        width = box[-1]
        results = {}
        for index, method in enumerate(METHODS):
            proposal = phase_stack(np.cos(angle + phase + index * np.pi / 2))
            proposal = proposal / data["wb"][data["colors"], None, None]
            w, offset, _ = make_filter(proposal, mean_field, profile, "split_edge_strong", basis, pixels)
            assert offset == 0
            entry = {
                "present": (simulated[0] @ w).tolist(), "absent": (simulated[2] @ w).tolist(),
                "flat": (simulated[3] @ w).tolist(), "actual_present": float(real[0] @ w),
                "actual_absent": float(real[2] @ w),
            }
            if width == 128 and gap.any():
                g, offset, _ = make_filter(proposal, mean_field, profile, "split_edge_strong", basis, gap)
                assert offset == 0
                entry["true_gap"] = (simulated[0] @ g).tolist()
            results[method] = entry
        output[str(width)] = {"tests": results, "selected_xywh": box,
                              "phase_error_degrees": float(np.degrees(delta))}
    return output


def summarize(rows, sectors):
    out = {}
    for dose in ("0.0", "0.55", "0.85"):
        out[dose] = {}
        for width in WIDTHS:
            outcome = {}
            for method in METHODS:
                def score(row):
                    return row["doses"][dose][str(width)]["tests"][method]

                train = [r for r in rows if r["id"] in sectors["calibration"]]
                confirm = [r for r in rows if r["id"] in sectors["confirmation"]]
                threshold = float(np.quantile(np.concatenate([score(r)["absent"] for r in train]), 1 - ALPHA))
                rng = np.random.default_rng(SEED + 15)
                result = {"threshold": threshold}
                for group in ("present", "absent", "flat", "true_gap"):
                    eligible = [r for r in confirm if group in score(r)]
                    if not eligible:
                        continue
                    prop = np.asarray([np.mean(np.asarray(score(r)[group]) > threshold) for r in eligible])
                    sub = [[i for i, r in enumerate(eligible) if r["family"] == family]
                           for family in sorted({r["family"] for r in eligible})]
                    sample = np.hstack([rng.choice(indices, (12000, len(indices)), replace=True) for indices in sub])
                    result[group] = {
                        "n": len(eligible), "mean": float(prop.mean()),
                        "ci": np.quantile(prop[sample].mean(1), (.025, .975)).tolist(),
                    }
                for group in ("actual_present", "actual_absent"):
                    result[group] = sum(score(r)[group] > threshold for r in confirm)
                outcome[method] = result
            phases = [abs(r["doses"][dose][str(width)]["phase_error_degrees"]) for r in confirm]
            out[dose][str(width)] = outcome | {"phase_error_median_degrees": float(np.median(phases))}
    return out


def main():
    torch.set_num_threads(2)
    oracle_ref = reference(OUT / "result.json")
    oracle = read_json(checked(oracle_ref))
    inputs = read_json(checked(oracle["input_plan"]))
    coupled = read_json(checked(oracle["coupled_inputs"]))
    historical = read_json(checked(inputs["parents"]))
    began = time.monotonic()
    records = []
    for case, item in zip(historical["rows"], coupled["inputs"], strict=True):
        assert case["id"] == item["id"]
        binding = {"0.0": case["input"]} | item["observations"]
        results = {dose: readout(case, ref, i) for i, (dose, ref) in enumerate(binding.items())}
        records.append({"id": case["id"], "family": case["fixture"]["geometry"]["family"], "doses": results})
        if len(records) % 4 == 0:
            print(f"Exterior evidence {len(records)}/32", flush=True)
    assert len(records) == 32
    write_json(OUT / "exterior.json", {
        "driver": reference(__file__), "known_template_reference": oracle_ref,
        "input_plan": oracle["input_plan"], "coupled_inputs": oracle["coupled_inputs"],
        "source_split": oracle["source_split"], "noise_replicates_per_role": DRAWS,
        "scope": "Supplied candidate frequencies, supplied masks and nuisance geometry; phase and variance scale use exterior exposed Bayer only",
        "heldout_readout": summarize(records, oracle["source_split"]),
        "rows": records, "time_seconds": time.monotonic() - began,
    })


if __name__ == "__main__":
    main()
