"""Inventory existing binned scene/crop lineage without original-photo access."""
from collections import Counter
from pathlib import Path
import json
import numpy as np

from demosaic.experiments.artifacts import reference, write_json

repo = Path.cwd()
manifest = repo/'.cache/current-quality-20261023-v1/V123-complete-source-loss-review-v1/future-cohort-v1/manifest4.jsonl'
rows = [json.loads(line) for line in manifest.read_text().splitlines() if line.strip()]
train = [r for r in rows if r['split'] == 'train']
counts = {str(n): sum(min(r['shape'][:2]) >= n for r in train) for n in [512, 768, 1024, 1536, 2048]}
prefixes = Counter()
protected = []
for r in train:
    path = Path(r['cache'])
    assert path.is_absolute() and str(path).startswith('/mnt/external/demosaic/')
    prefixes[str(path.parents[2])] += 1
    if any(name in str(path).upper() for name in ['DSCF3879', 'DSCF3880', 'DSCF3842', 'DSCF3835']):
        protected.append(r['id'])
assert not protected
eligible = [r for r in train if min(r['shape'][:2]) >= 1024]
indices = np.linspace(0, len(eligible)-1, 32, dtype=int)
samples = []
for i in indices:
    r = eligible[int(i)]
    path = Path(r['cache'])
    array = np.load(path, mmap_mode='r', allow_pickle=False)
    assert list(array.shape) == r['shape'] and array.dtype == np.uint16
    assert r['color_space'] == 'linear-sRGB' and r['bin_factor'] == 4
    samples.append({'id': r['id'], 'cache': str(path), 'declared_cache_sha256': r['cache_sha256'],
                    'shape': list(array.shape), 'dtype': str(array.dtype), 'license': r['license'],
                    'source_page': r['page_url'], 'header_only': True})
write_json(repo/'.cache/whole-scene-training-lineage-v1.json', {
    'script': reference(__file__), 'manifest': reference(manifest), 'rows': len(rows), 'training_rows': len(train),
    'minimum_cached_axis_counts': counts, 'cache_prefix_counts': dict(prefixes),
    'header_checked_samples': samples, 'protected_exact_capture_names_in_cache_paths': protected,
    'existing_data_path': {
        'source': reference(repo/'src/demosaic/data.py'),
        'crop_provenance': 'source_id/cache/cache_sha256/cache_xywh available with trace_sources',
        'missing': 'Existing augmentation/noise follows source cropping. It does not supply a full-scene noisy observation or a scene/crop coordinate transform after projective augmentation. Existing batch is not already a valid whole-scene/crop training pair.'},
    'scope': 'Read existing cleaned Commons manifest and32 evenly spaced eligible NPY headers only. No pixel decoding, original-photo/source-drive access, sensor noise, model forward, target analysis or training. Cached field is the full binned source image, not necessarily the uncropped camera photograph. Exact-name path screen is supplementary, not a substitute for existing protected-family exclusion policy or content hashes.'})
print('training rows',len(train),'minimum cached axes',counts,'32 headers checked;0 source photos/NN calls')
