"""Seal completed full-guided and coloured-wire reviews without changing receipts."""
import gzip
import html
import shutil
from datetime import datetime, timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
full = repo/'.cache/experiments/neural-nuisance-guided-phase129-full-review-v1'
colour = repo/'.cache/experiments/coloured-fine-wire-neural-v1'

def views(root, figures, sheets):
    manifest = read_json(root/'contact-sheets/manifest.json')
    batches = sorted(root.glob('viewing-batch-*.json'))
    indices = []
    for path in batches:
        b = read_json(path)
        assert b['actually_viewed'] and b['notes'] and b['manifest'] == reference(root/'contact-sheets/manifest.json')
        indices.extend(b['sheets'])
    assert sorted(indices) == list(range(sheets))
    assert manifest['source_images'] == figures and len(manifest['sheets']) == sheets
    return {'actually_viewed': True, 'figures': figures, 'contact_sheets': sheets,
            'manifest': reference(root/'contact-sheets/manifest.json'), 'batches': [reference(x) for x in batches]}

def archive(dest, initial, sources):
    result = list(initial)
    existing = {a['original']['path'] for a in result}
    for index, source in enumerate(sources):
        source = source.resolve()
        ref = reference(source)
        if ref['path'] in existing:
            continue
        target = dest/f'addendum-{index:03d}-{source.name}.gz'
        with target.open('xb') as stream:
            stream.write(gzip.compress(source.read_bytes(), mtime=0))
        result.append({'original': ref, 'published': reference(target), 'decompressed_bytes_exact': True})
        existing.add(ref['path'])
    for item in result:
        assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
    return result

assert read_json(repo/'.cache/experiments/neural-nuisance-guided-phase129-full-v1/controller-result.json')['producer_stages_succeeded']
assert read_json(full/'controller-result.json')['returncode'] == 0
assert read_json(colour/'comparison-result.json')['all_corrections_closed']
common = [Path(__file__), repo/'.cache/close-detail-native-reviews-v1.py', repo/'.cache/close-detail-native-reviews-v1.log']
p = read_json(full/'publication-prepared.json')
dest = repo/'docs/results/neural-nuisance-guided-phase129-full-v1'
assert not (dest/'publication.json').exists()
extras = [full/'publication-prepared.json', full/'contact-sheets/manifest.json', *sorted(full.glob('viewing-batch-*.json')),
          repo/'.cache/native-contact-sheets-v1.py', repo/'.cache/publish-neural-nuisance-guided-phase129-full-v1.py',
          repo/'.cache/guided-phase129-full-publication-prep-result-v1.json',
          repo/'.cache/summarize-guided-phase129-full-v1.py', repo/'.cache/summarize-guided-phase129-full-v1.log',
          repo/'.cache/guided-phase129-full-documentation-summary-v1.json', *common]
p.update(archives=archive(dest, p['archives'], extras), viewing=views(full, 70, 18),
         original_preparation=reference(full/'publication-prepared.json'),
         documentation_summary=reference(repo/'.cache/guided-phase129-full-documentation-summary-v1.json'),
         status='complete full producer, independent audits, source statistics and70 actual native views',
         quality_decision='Analytic400/far weak2.299% to9.300% and strong37.032% to68.274%, all8 sources improve response/full RGB error versus256 NN; all8 quiet errors and7 increment errors rise. Mean increment cost+0.606% versus256/+0.661% versus parent reverses the two-source pilot gain. Fine cab crossings/high-noise weak detail remain missing; building bands persist. Useful stronger-response/full RGB tradeoff, no broad weak-fidelity promotion.',
         scope_clarification='Original broad-only guided package/configuration retained. Both phase arms require A-only neural guide fields. Conditional H1 t2 label means analytic guided phase; Fixed proposal NN means neural guided phase; Prior256 NN t2 means saved baseline. All6 fixed threshold2 controls and both primary/secondary arms retained. ISO100/AHD/JPEG references independent and qualitative, not exact GT; no real-reference scoring. No new inference, training or noise in this full follow-up.',
         published_UTC=datetime.now(timezone.utc).isoformat())
for item in p['images']:
    assert checked(item['published']).read_bytes() == checked(item['original']).read_bytes()
write_json(dest/'publication.json', p)
print('Full:', len(p['archives']), 'archives,70 figures,18 actually viewed sheets')

dest = repo/'docs/results/coloured-fine-wire-v1'
images = repo/'docs/images/coloured-fine-wire-v1'
dest.mkdir(); images.mkdir()
admission = read_json(repo/'docs/results/coloured-fine-wire-admission-v1/publication.json')
completion = read_json(repo/'docs/results/coloured-fine-wire-completed-pre-review-v1/publication.json')
report = read_json(colour/'native/report.json')
items = []
for item in report['figures']:
    source = checked(item['image'])
    target = images/source.name
    assert not target.exists()
    shutil.copyfile(source, target)
    assert target.read_bytes() == source.read_bytes()
    items.append({'original': reference(source), 'published': reference(target), 'relative': target.name, 'metadata': item})
viewer = images/'native-viewer.html'
viewer.write_text('<!doctype html><meta charset="utf-8"><title>Coloured fine wires: native100%</title>'
                  '<style>body{font:14px sans-serif;background:#ddd}img{display:block;max-width:none;width:auto;height:auto}section{margin:24px 0;overflow:auto}</style>'
                  '<h1>Coloured fine wires: native100%</h1><p>160px crops, no resizing. Browser zoom100%. Synthetic exact GT; both priors, allCFAs and both nuisance arms.</p>'
                  + ''.join('<section><p>'+html.escape(i['relative'])+'</p><img src="'+html.escape(i['relative'])+'"></section>' for i in items))
review = colour/'actual-review'
extras = [colour/'independent-audit-v1.json', colour/'paired-source-summary-v1.json',
          review/'publication-prepared.json', review/'contact-sheets/manifest.json', *sorted(review.glob('viewing-batch-*.json')),
          repo/'scripts/audit_colored_fine_wires.py', repo/'.cache/audit-coloured-fine-comparison-v1.log',
          repo/'.cache/coloured-fine-audit-ruff-v1.log', repo/'.cache/native-coloured-fine-contact-sheets-v1.log',
          repo/'.cache/native-contact-sheets-v1.py', *common]
archives = archive(dest, admission['archives']+completion['archives'], extras)
write_json(dest/'publication.json', {
    'archives': archives, 'images': items, 'viewer': reference(viewer), 'viewing': views(review, 40, 10),
    'frozen_source': admission['frozen_source'], 'admission': reference(repo/'docs/results/coloured-fine-wire-admission-v1/publication.json'),
    'completion_pre_review': reference(repo/'docs/results/coloured-fine-wire-completed-pre-review-v1/publication.json'),
    'independent_audit': reference(colour/'independent-audit-v1.json'), 'paired_source_summary': reference(colour/'paired-source-summary-v1.json'),
    'scores': reference(colour/'scores-v1.json'), 'native_report': reference(colour/'native/report.json'),
    'comparison': reference(colour/'comparison-plan.json'), 'terminal': reference(colour/'comparison-result.json'),
    'status': 'complete192 corrections,400 metric rows,8400 independent fields and40 actual native figures',
    'quality_decision': 'No general coloured weak-detail gain.1600 joint analytic weak23.217% to24.088% versus independent fineH1 is almost entirely neutral source0; signed source1 weak25.362225% to25.362461%, with increment/colour errors slightly worse. All-stage increment/colour errors remain above V120;6400 no useful weak gain. Real cab tint improvement remains a separate qualitative result, not exact colour recovery.',
    'neural_forwards': {'preparation_root': 144, 'preparation_DINO': 144, 'correction_scoring_audit_view_publication': 0},
    'source_scope': 'Two new adaptive constructed geometries, all4CFAs, independent role noise, V120 parents. Source1 weak contrast[1,-.3,.7]. Not a camera generalization benchmark. No protected captures/JPEGs/siblings or source-drive media in training. Original admission/completion/failure receipts and executed source bytes preserved.',
    'published_UTC': datetime.now(timezone.utc).isoformat(),
})
print('Colour:', len(archives), 'archives,40 figures,10 actually viewed sheets')
