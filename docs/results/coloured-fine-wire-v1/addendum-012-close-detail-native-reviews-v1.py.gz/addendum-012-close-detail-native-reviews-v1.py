"""Record completed actual tool viewing and descriptive paired colour summaries."""
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import read_json, reference, write_json

repo = Path.cwd()
full = repo / '.cache/experiments/neural-nuisance-guided-phase129-full-review-v1'
colour = repo / '.cache/experiments/coloured-fine-wire-neural-v1'
full_batches = [
    ([12, 13, 14, 15], 'Materials bark/fur remain soft. Sky unchanged; coarse fence has modest modulation. Both cab profiles/ROIs/JPEGs inspected: fine crossings absent, some old256 ripples reduced. Building residual bands persist; independent references are not GT.'),
    ([8, 9, 10, 11], 'All400 near/far sources: stronger first-direction modulation than saved256 in many views, substantial source/placement variation. Weaker crossings largely missing; some views almost unchanged.'),
    ([16, 17], 'Both analytic maximum-correction and unchanged historical building ROI inspected: residual bands remain, less than unguided phase. Both NN and declared-primary analytic400 source1/source7 native triplets inspected: weak direction remains faint/missing.'),
    ([0, 1, 2, 3], 'All6400 near/far sources: weak and often strong lines largely absent. Some parent-visible source2 modulation retained; no general high-noise recovery.'),
    ([4, 5, 6, 7], 'All1600 near/far sources: some first-direction modulation, weak crossings mostly missing. Large source/placement variation; the stronger response does not establish faithful reconstruction.'),
]
colour_batches = [
    ([0, 1, 2, 3, 4], 'All source0 neutral boards across four CFAs/both priors and RGGB triplets actually viewed individually through tools.view_image.1600 fine phase strengthens one diagonal; fine H1 and joint are softer, with only subtle differences. Thin exact-GT crossings remain absent.6400 is mostly broad parent structure; phase occasionally adds a weak diagonal, H1/joint remain nearly parent-like.'),
    ([5, 6, 7, 8, 9], 'All source1 signed-colour boards across four CFAs/both priors and RGGB triplets actually viewed individually through tools.view_image.1600 phase gives a clearer dominant diagonal but does not reproduce thin coloured crossings. Fine H1/joint differences subtle; both remain soft and lack the exact-GT colour/detail.6400 joint/H1 retain broad structure and miss fine families. No broad colour-fidelity success inferred.'),
]
for root, batches in [(full, full_batches), (colour/'actual-review', colour_batches)]:
    manifest = read_json(root/'contact-sheets/manifest.json')
    assert sorted(i for ids, _ in batches for i in ids) == list(range(len(manifest['sheets'])))
    for index, (ids, notes) in enumerate(batches):
        dest = root/f'viewing-batch-{index}.json'
        assert not dest.exists()
        write_json(dest, {'sheets': ids, 'actually_viewed': True,
                         'method': 'Exact unresized contact sheets through tools.view_image',
                         'notes': notes, 'manifest': reference(root/'contact-sheets/manifest.json')})

scores = read_json(colour/'scores-v1.json')
keys = ['weak_gain', 'strong_gain', 'quiet_error_RMS_DN16',
        'weak_increment_error_RMS_DN16', 'weak_colour_orthogonal_RMS_DN16',
        'weak_R_gain', 'weak_G_gain', 'weak_B_gain', 'full_error_RMS_DN16']
means = []
contrasts = []
for profile in ['iso1600', 'iso6400']:
    for source in [0, 1]:
        rows = [r for r in scores['rows'] if (r['profile'], r['source']) == (profile, source)]
        for method in sorted({r['method'] for r in rows}):
            selected = [r for r in rows if r['method'] == method]
            assert len(selected) == 4
            means.append({'profile': profile, 'source': source, 'method': method,
                          **{k: float(np.mean([r[k] for r in selected])) for k in keys}})
        for arm in ['conditional-local-t2', 'local-t2']:
            paired = []
            for pattern in ['RGGB', 'BGGR', 'GRBG', 'GBRG']:
                lookup = {r['method']: r for r in rows if r['pattern'] == pattern}
                a, b, p = [lookup[m] for m in ['joint-fine::'+arm, 'fine-sinusoidal::'+arm, 'V120']]
                paired.append({'pattern': pattern,
                               'delta_vs_independent': {k: a[k]-b[k] for k in keys},
                               'delta_vs_parent': {k: a[k]-p[k] for k in keys}})
            contrasts.append({'profile': profile, 'source': source, 'arm': arm, 'CFA_pairs': paired,
                              'fields': {k: {'mean_delta': float(np.mean([r['delta_vs_independent'][k] for r in paired])),
                                             'minimum_delta': min(r['delta_vs_independent'][k] for r in paired),
                                             'maximum_delta': max(r['delta_vs_independent'][k] for r in paired)} for k in keys}})
write_json(colour/'paired-source-summary-v1.json', {'script': reference(__file__), 'scores': reference(colour/'scores-v1.json'),
            'source_means': means, 'contrasts': contrasts,
            'scope': 'Descriptive two-source/four-CFA paired summaries after all192 corrections closed; no population uncertainty or independent-camera claim. Original score bytes preserved. No inference or new noise.'})
for r in means:
    if r['method'] in ['V120', 'fine-sinusoidal::conditional-local-t2', 'joint-fine::conditional-local-t2']:
        print(r['profile'], r['source'], r['method'], {k: r[k] for k in keys[:5]})
print('18 full and10 coloured contact sheets,110 figures actually viewed; receipts written')
