"""Plot matched intact weak-wire response against false detail in known absences."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from demosaic.experiments.artifacts import read_json

ROOT = Path(__file__).resolve().parent
FIGURE = ROOT / "response-tradeoff.png"
LABELS = ("Repeat control", "Full wire band", "Aligned wire")


def main():
    curves = read_json(ROOT / "prior-wire-curve.json")["curves"]
    observed = read_json(ROOT / "review/result.json")["groups"]["wire"]["summary"]
    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.55), layout="constrained", sharex=True)
    methods = ("Repeat to prior mean control", "Repeat to Local 50k")
    score = "weak_response_pp"
    for a, (field, title) in zip(
        axes,
        (
            ("exact_flat_RMS_DN16", "Exact-flat error"),
            ("gap_weak_RMS_DN16", "Weak-direction error in true gaps"),
        ),
        strict=True,
    ):
        for (name, rows), label, color in zip(
            curves.items(), methods, ("#406fa0", "#65835d"), strict=True
        ):
            a.plot(
                [r["scores"][score] for r in rows],
                [r["scores"][field] for r in rows],
                ".-",
                label=label,
                color=color,
                alpha=0.8,
            )
        for name, color, marker in zip(
            LABELS, ("#525252", "#b87522", "#9c406b"), ("s", "^", "D"), strict=True
        ):
            a.scatter(
                [observed[score]["values"][name]],
                [observed[field]["values"][name]],
                color=color,
                marker=marker,
                label=name,
                zorder=4,
                edgecolor="white",
                linewidth=0.4,
                s=58,
            )
        a.set(title=title, xlabel="Recovered weak-wire response (%)", ylabel="RMS (DN16)")
        a.grid(alpha=0.23)
        for sp in ("top", "right"):
            a.spines[sp].set_visible(False)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncols=3, frameon=False, fontsize=8)
    fig.savefig(FIGURE, dpi=170)


if __name__ == "__main__":
    main()
