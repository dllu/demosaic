"""Calibrate comparison mixtures by response on one half and test on the other."""

from collections import Counter

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_response import LABELS, ROOT
from fit_local import metric_for_wire


def main():
    scored = reference(ROOT / "review/result.json")
    outcome = read_json(checked(scored))
    archive_ref = outcome["previous"]
    older = read_json(checked(archive_ref))
    old = {r["source"]["index"]: r for r in older["groups"]["wire"]["rows"]}
    rows = outcome["groups"]["wire"]["rows"]
    cal, held = [], []
    for row in rows:
        index = row["source"]["index"]
        paired = old[index]
        assert (
            row["input"] == paired["input"] and row["parent_output"] == paired["outputs"]["repeat"]
        )
        part = cal if (index // 4) % 2 == 0 else held
        part.append((row, paired))
    for part in (cal, held):
        assert len(part) == 12 and set(
            Counter(r["source"]["geometry"]["family"] for r, _ in part).values()
        ) == {3}
        assert len({r["source"]["source"]["id"] for r, _ in part}) == 12
    response = "weak_response_pp"
    fields = (
        response,
        "intact_increment_RMS_DN16",
        "exact_flat_RMS_DN16",
        "gap_weak_RMS_DN16",
        "gap_RMS_DN16",
    )
    base = float(np.mean([p["scores"]["Repeat loss"][response] for _, p in cal]))
    contrasts = {}
    for label in LABELS.values():
        candidate = float(np.mean([r["scores"][label][response] for r, _ in cal]))
        for exemplar, key in (("Mean control", "mean"), ("Local 50k EMA", None)):
            high = float(np.mean([p["scores"][exemplar][response] for _, p in cal]))
            alpha = (candidate - base) / (high - base)
            result = dict(
                evaluated=bool(0 <= alpha <= 1),
                control_calibration_range=[base, high],
                desired_calibration_response=candidate,
            )
            contrasts[f"{label} vs Repeat/ {exemplar}"] = result
            if not result["evaluated"]:
                continue
            result["control_share"] = alpha
            pairs = []
            for row, previous in held:
                with np.load(checked(row["input"]), allow_pickle=False) as f:
                    data = {k: f[k] for k in f.files}
                p = np.load(checked(row["parent_output"]), allow_pickle=False)
                q = np.load(
                    checked(previous["outputs"][key] if key else previous["endpoint_output"]),
                    allow_pickle=False,
                )
                measured = metric_for_wire(data, row["source"]["geometry"])(
                    p * (1 - alpha) + q * alpha
                )
                pairs.append(
                    dict(
                        source=row["source"]["source"]["id"],
                        measurements={
                            k: [row["scores"][label].get(k), measured.get(k)] for k in fields
                        },
                    )
                )
            rng = np.random.default_rng(202611191309)
            summary = {}
            for k in fields:
                choices = np.array(
                    [r["measurements"][k] for r in pairs if r["measurements"][k][0] is not None]
                )
                bootstrap = rng.integers(len(choices), size=(6500, len(choices)))
                delta = choices[:, 0] - choices[:, 1]
                summary[k] = dict(
                    cases=len(delta),
                    delta=float(delta.mean()),
                    candidate=float(choices[:, 0].mean()),
                    mixture=float(choices[:, 1].mean()),
                    interval=np.quantile(delta[bootstrap].mean(1), [0.025, 0.975]).tolist(),
                )
            result.update(scores=summary, cases=pairs)
    write_json(
        ROOT / "matched-wire-response.json",
        dict(
            evaluation=scored,
            control_sources=archive_ref,
            driver=reference(__file__),
            calibration=[r["source"]["index"] for r, _ in cal],
            check=[r["source"]["index"] for r, _ in held],
            contrasts=contrasts,
        ),
    )
    print({name: row.get("control_share") for name, row in contrasts.items()})


if __name__ == "__main__":
    main()
