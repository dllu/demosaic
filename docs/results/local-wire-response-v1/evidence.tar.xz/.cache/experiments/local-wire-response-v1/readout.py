"""Read exact and repeat measurements from the source-bound review."""

from pathlib import Path

from demosaic.experiments.artifacts import read_json

ROOT = Path(__file__).resolve().parent
PHOTO = (
    "fine_response_pp",
    "fine_increment_RMS_DN16",
    "exact_flat_fine_RMS_DN16",
    "flat_chroma_RMS_DN16",
)
WIRE = (
    "weak_response_pp",
    "intact_increment_RMS_DN16",
    "exact_flat_RMS_DN16",
    "gap_RMS_DN16",
    "gap_weak_RMS_DN16",
)
NATURAL_REPEAT = (
    "pooled_response_pp",
    "mean_increment_RMS_DN16",
    "swapped_draw_variance_DN16_squared",
    "shared_error_product_DN16_squared",
    "mean_present_RMS_DN16",
    "mean_quiet_RMS_DN16",
)
WIRE_REPEAT = WIRE + (
    "intact_draw_variance_DN16_squared",
    "aligned_variance_DN16_squared",
    "other_variance_DN16_squared",
    "shared_DN16_squared",
    "aligned_bias_DN16",
)


def show(name, summary, metrics):
    print(name)
    for k in metrics:
        row = summary[k]
        print(k, str({name: round(x, 5) for name, x in row["values"].items()}))
        for label in (
            "Full wire band vs Repeat control",
            "Aligned wire vs Repeat control",
            "Aligned wire vs Full wire band",
            "Aligned wire vs Repeat parent",
        ):
            if label in row["differences"]:
                x = row["differences"][label]
                print(" ", label, round(x["delta"], 5), [round(t, 5) for t in x["interval"]])


if __name__ == "__main__":
    native = ROOT / "review/result.json"
    redraw = ROOT / "review/redraw.json"
    wires = ROOT / "review/wire-redraw.json"
    if native.is_file():
        r = read_json(native)
        for key, fields in (("photo", PHOTO), ("wire", WIRE)):
            show(key, r["groups"][key]["summary"], fields)
        print("Boards", [v["id"] for v in r["exact"]])
        for row in r["standing"]:
            print(row["id"], row["rms_vs_parent_DN16"])
    if redraw.is_file():
        for law, g in read_json(redraw)["groups"].items():
            show(law, g["summary"], NATURAL_REPEAT)
    if wires.is_file():
        show("wire redraw", read_json(wires)["summary"], WIRE_REPEAT)
