"""Use the original natural redraw plan after checking the latest score receipt."""

import time

import torch

from review_response import PRIOR, ROOT, independent
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.scene_inference import load_scene_checkpoint


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    endpoint = reference(ROOT / "training/completed.json")
    run = read_json(checked(endpoint))
    native = read_json(ROOT / "review/result.json")
    assert native["endpoint"] == endpoint
    parent = reference(PRIOR / "review/redraw.json")
    replay = read_json(checked(parent))
    original_ref = replay["previous"]
    original = read_json(checked(original_ref))
    plan = read_json(checked(original["plan"]))
    assert sorted(plan["sources"]) == sorted(
        r["case"]["index"] for r in replay["groups"]["independent"]["rows"]
    )
    previous = read_json(checked(replay["endpoint"]))
    assert previous["checkpoints"]["repeat"] == run["parent"]
    train = read_json(checked(run["plan"]))
    ids = {r["source"]["id"] for r in read_json(checked(train["schedule"]))}
    models = {}
    for arm, binding in run["checkpoints"].items():
        model, state = load_scene_checkpoint(
            checked(binding), weights="ema", expected_sha256=binding["sha256"]
        )
        assert state["training_arm"] == arm and state["continued_from"] == run["parent"]
        models[arm] = _stage_tiled_cuda(model, "cuda")
    started = time.monotonic()
    summary = independent(models, replay | {"plan": original["plan"]}, ids)
    write_json(
        ROOT / "review/redraw.json",
        dict(
            previous=parent,
            frozen_panel=original_ref,
            endpoint=endpoint,
            groups=summary,
            driver=reference(__file__),
            shared_reducer=reference(ROOT / "review_response.py"),
            seconds=time.monotonic() - started,
            weights="EMA",
            precision="CUDA IEEE FP32",
        ),
    )


if __name__ == "__main__":
    main()
