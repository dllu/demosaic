"""Bind and score three fresh ISO6400 draws of held-out wire fields."""

import argparse
from collections import Counter, defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.prediction_archive import fingerprint
from demosaic.scene_inference import load_scene_checkpoint
from demosaic.scene_training_data import scene_seed
from review_response import LABELS, PARENT, PROFILE, ROOT, compare, metrics, restore

BASE = ROOT.with_name("green-covariance-refit-v1")
sys.path.insert(0, str(BASE))
import fresh_fields
from fit_local import metric_for_wire
from scoring import remove_basis
from upper import luma

SEED = 202611191433


def capture():
    origin = reference(BASE / "plan.json")
    source_plan = read_json(checked(origin))
    assert source_plan["profile"] == PROFILE
    approved = reference(ROOT / "plan.json")
    trial = read_json(checked(approved))
    forbidden = {
        r["source"]["id"]
        for k in ("schedule", "qualification_schedule")
        for r in read_json(checked(trial[k]))
    }
    main_set = read_json(ROOT.with_name("local-redraw-stability-v1") / "review/result.json")
    separate = {r["source"]["source"]["id"] for g in main_set["groups"].values() for r in g["rows"]}
    photos = [r for r in source_plan["sources"] if r["kind"] == "wire"][:16]
    assert len(photos) == 16 and set(Counter(r["geometry"]["family"] for r in photos).values()) == {
        4
    }
    assert set(Counter(r["camera"]["pattern"] for r in photos).values()) == {4}
    assert {r["source"]["id"] for r in photos}.isdisjoint(forbidden | separate)
    assert all(r["source"]["split"] == "val" for r in photos)
    cohort = ROOT / "wire-redraw-inputs"
    cohort.mkdir()
    rows = []
    for row in photos:
        marks, clean = [], None
        for draw in range(3):
            fresh_fields.SEED = scene_seed(SEED, draw, "wire-confirmation")
            data, roi = fresh_fields.capture(row, PROFILE)
            data.pop("scene_packed")
            fields = {
                k: fingerprint(data[k])
                for k in ("target", "support", "weak_linear", "colors", "wb", "matrix")
            }
            assert clean is None or clean == fields
            clean = fields
            key = f"{row['index']:02d}-draw-{draw}"
            outfile = cohort / f"{key}.npz"
            with outfile.open("xb") as stream:
                np.savez_compressed(stream, **data)
            seeds = {
                role: scene_seed(fresh_fields.SEED, row["index"], role)
                for role in fresh_fields.ROLES
            }
            marks.append(
                dict(
                    role_seeds=seeds, arrays=reference(outfile), packed=fingerprint(data["packed"])
                )
            )
        assert len({seed for mark in marks for seed in mark["role_seeds"].values()}) == 12
        assert len({str(mark["packed"]) for mark in marks}) == 3
        rows.append(dict(source=row, draws=marks, target_fingerprints=clean, query=roi))
        print("compiled observations for", row["index"], flush=True)
    write_json(
        cohort / "panel.json",
        dict(
            scope="Sixteen held-out sources, four geometry families, three independent draws per target",
            root_seed=SEED,
            profile=PROFILE,
            camera_roles=fresh_fields.ROLES,
            origin=origin,
            trial=approved,
            rows=rows,
            code=reference(fresh_fields.__file__),
            geometry=reference(fresh_fields.wire_math.__file__),
            driver=reference(__file__),
        ),
    )


def decompose(estimate, data, metric):
    rgb = estimate[..., 64:192, 64:192]
    y = luma(rgb, data["wb"], data["matrix"])
    intact = remove_basis((y[:, 0] - y[:, 2])[:, metric.intact], metric.intact_nuisance)
    error = intact - metric.truth_weak
    shape = metric.truth_weak / np.sqrt(metric.strength)
    along = error @ shape
    norm = 65535**2 / error.shape[1]
    variance = float(np.sum(error.var(axis=0, ddof=1)) * norm)
    along_variance = float(along.var(ddof=1) * norm)
    shared = float(np.mean([error[a] @ error[b] for a, b in ((0, 1), (0, 2), (1, 2))]) * norm)
    np.testing.assert_allclose(np.mean(error**2) * 65535**2, shared + variance, rtol=1e-11)
    return dict(
        weak_response_pp=float(100 * np.mean(intact @ metric.truth_weak) / metric.strength),
        intact_draw_variance_DN16_squared=variance,
        aligned_variance_DN16_squared=along_variance,
        other_variance_DN16_squared=variance - along_variance,
        shared_DN16_squared=shared,
        aligned_bias_DN16=float(along.mean() * np.sqrt(norm)),
        true_amplitude_DN16=float(np.sqrt(metric.strength * norm)),
        intact_increment_RMS_DN16=float(np.mean(np.sqrt(np.sum(error**2, axis=1) * norm))),
    )


@torch.inference_mode()
def score(*, baseline=False):
    torch.set_num_threads(2)
    proof = reference(ROOT / "wire-redraw-inputs/panel.json")
    panel = read_json(checked(proof))
    prior_binding, prior_cases = None, None
    if baseline:
        endpoint = panel["trial"]
        plan = read_json(checked(endpoint))
        configs = {PARENT: plan["parent"]}
    else:
        endpoint = reference(ROOT / "training/completed.json")
        run = read_json(checked(endpoint))
        assert panel["trial"] == run["plan"]
        prior_binding = reference(ROOT / "parent-wire-redraw.json")
        old = read_json(checked(prior_binding))
        assert old["inputs"] == proof and old["models"] == {PARENT: run["parent"]}
        prior_cases = {r["case"]["source"]["index"]: r for r in old["rows"]}
        configs = {LABELS[arm]: r for arm, r in run["checkpoints"].items()}
    models: dict = {}
    for name, binding in configs.items():
        poly, state = load_scene_checkpoint(
            checked(binding), weights="ema", expected_sha256=binding["sha256"]
        )
        assert state["loaded_weights"] == "ema"
        models[name] = _stage_tiled_cuda(poly, "cuda")
    results = []
    start = time.monotonic()
    for case in panel["rows"]:
        values, fields = defaultdict(list), defaultdict(list)
        for draw in case["draws"]:
            with np.load(checked(draw["arrays"]), allow_pickle=False) as stream:
                data = {k: stream[k] for k in stream.files}
            assert {k: fingerprint(data[k]) for k in case["target_fingerprints"]} == case[
                "target_fingerprints"
            ]
            assert fingerprint(data["packed"]) == draw["packed"]
            for name, model in models.items():
                result, _ = restore(model, data, panel["profile"])
                values[name].append(result)
                fields[name].append(metrics(case, result, data))
        metric = metric_for_wire(data, case["source"]["geometry"])
        choices = {}
        for name, renders in values.items():
            result = decompose(np.stack(renders), data, metric)
            for field in (
                "exact_flat_RMS_DN16",
                "gap_RMS_DN16",
                "gap_weak_RMS_DN16",
                "flat_chroma_RMS_DN16",
            ):
                measurements = [r[field] for r in fields[name] if r.get(field) is not None]
                if measurements:
                    result[field] = float(np.mean(measurements))
            np.testing.assert_allclose(
                result["weak_response_pp"],
                np.mean([r["weak_response_pp"] for r in fields[name]]),
                rtol=1e-8,
            )
            choices[name] = result
        if prior_cases is not None:
            prior = prior_cases[case["source"]["index"]]
            assert prior["case"] == case
            choices[PARENT] = prior["scores"][PARENT]
        results.append(dict(case=case, scores=choices))
        print("redraw wires scored", len(results), flush=True)
    summary = {}
    if not baseline:
        keys = sorted({k for row in results for k in row["scores"][PARENT]})
        summary = compare([r["scores"] for r in results], keys)
        for family in sorted({r["case"]["source"]["geometry"]["family"] for r in results}):
            cohort = [
                r["scores"] for r in results if r["case"]["source"]["geometry"]["family"] == family
            ]
            family_keys = sorted({k for row in cohort for k in row[PARENT]})
            summary[family] = compare(cohort, family_keys)
    write_json(
        ROOT / ("parent-wire-redraw.json" if baseline else "review/wire-redraw.json"),
        dict(
            inputs=proof,
            endpoint=endpoint,
            models=configs,
            parent_replay=prior_binding,
            weights="EMA",
            precision="CUDA IEEE FP32",
            driver=reference(__file__),
            rows=results,
            summary=summary,
            seconds=time.monotonic() - start,
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("capture", "baseline", "score"))
    args = parser.parse_args()
    if args.mode == "capture":
        torch.set_num_threads(2)
        capture()
    else:
        score(baseline=args.mode == "baseline")
