"""Verify fresh wire inputs are exact and reserved across all matched schedules."""

import json
from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent


def main():
    case_ref = reference(ROOT / "wire-redraw-inputs/panel.json")
    panel = read_json(checked(case_ref))
    for key in ("origin", "trial", "driver", "geometry", "code"):
        checked(panel[key])
    trial = read_json(checked(panel["trial"]))
    prior = read_json(checked(trial["parent_completion"]))
    scopes = [trial, read_json(checked(prior["plan"]))]
    older = read_json(checked(scopes[-1]["parent_completion"]))
    scopes.append(read_json(checked(older["plan"])))
    correct = {
        arm: {row["source"]["id"] for row in read_json(checked(p[arm]))}
        for p in scopes[:1]
        for arm in ("schedule", "qualification_schedule")
    }
    assert len(correct["schedule"]) == 320 and len(correct["qualification_schedule"]) == 8
    assert correct["schedule"].isdisjoint(correct["qualification_schedule"])
    any_seen = set.union(*correct.values())
    older_ids = {
        row["source"]["id"]
        for p in scopes[1:]
        for arm in ("schedule", "qualification_schedule")
        for row in read_json(checked(p[arm]))
    }
    assert any_seen.isdisjoint(older_ids)
    source_ids = {r["source"]["source"]["id"] for r in panel["rows"]}
    cache_ids = {r["source"]["source"]["cache_sha256"] for r in panel["rows"]}
    assert len(source_ids) == len(cache_ids) == 16
    recipes, seeds = Counter(), []
    gap_sources = []
    for row in panel["rows"]:
        source = row["source"]
        assert len(row["draws"]) == 3 and source["source"]["split"] == "val"
        recipes[(source["geometry"]["family"], source["camera"]["pattern"])] += 1
        distinct = set()
        for draw in row["draws"]:
            seeds.extend(draw["role_seeds"].values())
            with np.load(checked(draw["arrays"]), allow_pickle=False) as f:
                assert {k: fingerprint(f[k]) for k in row["target_fingerprints"]} == row[
                    "target_fingerprints"
                ]
                packed = fingerprint(f["packed"])
                assert packed == draw["packed"]
                distinct.add(packed["sha256"])
                assert f["packed"].shape == (4, 4, 128, 128) and f["target"].shape == (
                    4,
                    3,
                    256,
                    256,
                )
                gap = f["support"][64:192, 64:192] == 0
                yes = source["geometry"]["family"] in ("ellipse", "strip")
                assert yes == bool(np.any(gap))
                if yes:
                    assert np.array_equal(
                        f["target"][0, :, 64:192, 64:192][:, gap],
                        f["target"][2, :, 64:192, 64:192][:, gap],
                    )
                    gap_sources.append(source["index"])
        assert len(distinct) == 3
    assert len(seeds) == len(set(seeds)) == 192
    assert len(recipes) == 16 and set(recipes.values()) == {1}
    assert len(set(gap_sources)) == 8
    exposures = [p["inputs"] for p in scopes]
    known = {
        ref["sha256"]: ref
        for refs in exposures
        for ref in refs
        if ref["path"].endswith("manifest-train.jsonl")
    }
    visited = []
    for ref in known.values():
        path = checked(ref)
        count = 0
        with path.open() as stream:
            for line in stream:
                train = json.loads(line)
                assert train["id"] not in source_ids and train["cache_sha256"] not in cache_ids
                count += 1
        visited.append(dict(manifest=ref, records=count))
    assert visited and (any_seen | older_ids).isdisjoint(source_ids)
    write_json(
        ROOT / "wire-capture-audit.json",
        dict(
            inputs=case_ref,
            driver=reference(__file__),
            scoped_sources=16,
            physical_draws=192,
            independent_seeds=192,
            exact_gap_sources=8,
            balanced_geometry_by_CFA=True,
            training_manifests=visited,
            training_schedule_sources=len(any_seen),
            older_schedule_sources=len(older_ids),
            same_clean_targets=True,
            independently_drawn_raw=True,
        ),
    )
    print("Verified 192 physical captures, exact gaps and source exclusions")


if __name__ == "__main__":
    main()
