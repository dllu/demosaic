"""Review aligned wire supervision with unchanged exact, redraw and standing GFX inputs."""

from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.inference import _stage_tiled_cuda
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from demosaic.scene_inference import load_scene_checkpoint
from report_scene_wave_guides import native_board

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.with_name("local-redraw-stability-v1")
sys.path.insert(0, str(ROOT.with_name("local-redraw-average-v1")))
from review_redraw_average import (
    CORPUS,
    KEYS,
    LOCAL,
    ROI,
    V120,
    metrics,
    native_png,
    old_pixels,
    predict,
    restore,
)
from continuation_redraw_math import BANDS, channel_coefficients, contributions
from demosaic.archive_metrics import noisy_malvar

LABELS = {"repeat": "Repeat control", "wire-mean": "Full wire band", "wire-aligned": "Aligned wire"}
PARENT = "Repeat parent"
PAIRS = (("wire-mean", "repeat"), ("wire-aligned", "repeat"), ("wire-aligned", "wire-mean"))


def compare(rows, metrics_names, *, exact=False, natural=False):
    rng = np.random.default_rng(202611191231)
    pairs = [(LABELS[a], LABELS[b]) for a, b in PAIRS]
    comparators = (PARENT, LOCAL, CORPUS, V120) if exact else (PARENT, LOCAL)
    pairs.extend(
        (name, comp) for name in LABELS.values() for comp in comparators if comp in rows[0]
    )
    summary = {}
    for metric in metrics_names:
        selected = [
            r
            for r in rows
            if r[LABELS["repeat"]].get(metric) is not None or metric == "pooled_response_pp"
        ]
        n = len(selected)
        indexes = np.vstack([np.arange(n), rng.integers(n, size=(6500, n))])
        measurements = {}
        for name in selected[0]:
            if metric == "pooled_response_pp" and not exact:
                dot = np.array([row[name]["aligned_dot"] for row in selected])[indexes].sum(1)
                power = np.array([row[name]["clean_power"] for row in selected])[indexes].sum(1)
                measure = 100 * dot / power
            else:
                values = np.array([row[name][metric] for row in selected])[indexes]
                measure = (
                    np.sqrt(np.mean(values**2, axis=1))
                    if natural and metric.endswith("RMS_DN16")
                    else values.mean(1)
                )
            measurements[name] = measure
        differences = {}
        for a, b in pairs:
            d = measurements[a] - measurements[b]
            differences[f"{a} vs {b}"] = {
                "delta": float(d[0]),
                "interval": np.quantile(d[1:], [0.025, 0.975]).tolist(),
            }
        summary[metric] = dict(
            cases=n,
            values={name: float(a[0]) for name, a in measurements.items()},
            differences=differences,
        )
    return summary


def exact(models, prior, folder):
    rows = []
    arm = LABELS["wire-aligned"]
    control = LABELS["repeat"]
    groups = {}
    for kind in ("photo", "wire"):
        records = []
        for case in prior[kind]:
            with np.load(checked(case["input"]), allow_pickle=False) as archive:
                args = {key: archive[key] for key in archive.files}
            native = case["source"]["index"]
            outputs, duration = predict(models, args, PROFILE, folder, f"{native:02d}")
            previous = case["scores"]
            values = {PARENT: previous["Repeat loss"]} | {
                key: previous[key] for key in (V120, CORPUS, LOCAL)
            }
            for key, label in LABELS.items():
                values[label] = metrics(
                    case, np.load(checked(outputs[key]), allow_pickle=False), args
                )
            records.append(
                dict(
                    case,
                    scores=values,
                    outputs=outputs,
                    forward_seconds=duration,
                    parent_output=case["outputs"]["repeat"],
                )
            )
        assert len(records) == 24
        records.sort(key=lambda r: r["source"]["index"])
        keys = sorted(set().union(*(r["scores"][arm].keys() for r in records)))
        groups[kind] = dict(
            rows=records,
            summary=compare(
                [r["scores"] for r in records], keys, exact=True, natural=kind == "photo"
            ),
        )
        metric = "gap_weak_RMS_DN16" if kind == "wire" else "fine_increment_RMS_DN16"
        selection = [r for r in records if r["scores"][arm].get(metric) is not None]
        if not selection:
            metric = "gap_RMS_DN16"
            selection = [r for r in records if r["scores"][arm].get(metric) is not None]
        ranked = sorted(
            selection, key=lambda r: r["scores"][arm][metric] - r["scores"][control][metric]
        )
        rows.extend([ranked[0], ranked[-1]])
    output = folder.parent / "exact"
    output.mkdir()
    boards = []
    for row in rows:
        with np.load(checked(row["input"]), allow_pickle=False) as args:
            camera = {key: args[key][None] for key in ("wb", "matrix", "colors")} | {
                "packed": args["packed"][:1]
            }
            noisy, target = noisy_malvar(camera)[0], args["target"][0]
        with np.load(checked(row["model_outputs"]), allow_pickle=False) as prior_archive:
            baseline = prior_archive["v120"][0], prior_archive["parent"][0]
        parent = np.load(checked(row["parent_output"]), allow_pickle=False)[0]
        variants = [np.load(checked(row["outputs"][key]), allow_pickle=False)[0] for key in LABELS]
        wire = row["source"]["kind"] == "wire"
        boards.append(
            native_board(
                output,
                f"{row['source']['index']:02d}-{row['source']['kind']}-iso6400",
                (noisy, *baseline, parent, *variants, target),
                camera,
                dict(
                    source=row["source"],
                    query=row["box"],
                    input=row["input"],
                    outputs=row["outputs"],
                    parent_output=row["parent_output"],
                    iso_profile=PROFILE,
                ),
                labels=("Noisy Malvar", V120, CORPUS, PARENT, *LABELS.values(), "Exact GT"),
                triplet_indices=(0, 6, 7),
                exposure=2 if wire else 1 / 0.33,
                contrast=1 if wire else 2,
                roi=ROI,
            )
        )
    return groups, boards


def standing(models, previous, folder):
    output = folder.parent / "standing"
    output.mkdir()
    records, cache = [], {}
    before = ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA", "Parent 100k EMA", LOCAL)
    after = ("ISO100 AHD reference", "ISO100 camera JPEG")
    for case in previous:
        with np.load(checked(case["input"]), allow_pickle=False) as archive:
            data = {k: archive[k] for k in KEYS}
        wb, matrix = (torch.from_numpy(data[k]) for k in ("wb", "matrix"))
        data.update({k: data[k][0] for k in ("colors", "wb", "matrix")})
        key = case["input"]["sha256"], str(case["noise"])
        if key not in cache:
            cache[key] = predict(models, data, case["noise"], folder, case["id"])
        outputs, duration = cache[key]
        pixels = old_pixels(case["board"])
        v = np.load(checked(case["outputs"]["repeat"]), allow_pickle=False)
        arrays = {name: np.load(checked(outputs[name]), allow_pickle=False) for name in LABELS}
        x, y, w, h = case["roi"]
        cut = np.s_[..., y : y + h, x : x + w]

        def render(array):
            rgb = display_crop(
                torch.from_numpy(array), wb, matrix, case["roi"], exposure=case["exposure"]
            )
            return np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)

        np.testing.assert_array_equal(render(v), pixels["Repeat loss"])
        columns = [(key, pixels[key]) for key in before if key in pixels]
        columns.append((PARENT, pixels["Repeat loss"]))
        columns.extend((LABELS[k], render(array)) for k, array in arrays.items())
        columns.extend((key, pixels[key]) for key in after if key in pixels)
        changes = {
            name: float(np.sqrt(np.mean((a[cut].astype(np.float64) - v[cut]) ** 2)) * 65535)
            for name, a in arrays.items()
        }
        records.append(
            case
            | dict(
                board=native_png(output / f"{case['id']}.png", columns),
                outputs=outputs,
                parent_output=case["outputs"]["repeat"],
                rms_vs_parent_DN16=changes,
            )
        )
    assert len(records) == 8
    return records, {name: sum(t[name] for _, t in cache.values()) for name in LABELS}


def independent(models, previous, source_ids):
    plan = read_json(checked(previous["plan"]))
    roi = plan["native_ROI"]
    grouped = defaultdict(list)
    for law, group in previous["groups"].items():
        rows = group["rows"]
        for i, entry in enumerate(rows, 1):
            case = entry["case"]
            assert case["source"] not in source_ids
            band_output = defaultdict(list)
            target = None
            for draw in case["draws"]:
                with np.load(checked(draw["file"]), allow_pickle=False) as archive:
                    args = {key: archive[key] for key in draw["fingerprints"]}
                assert {k: fingerprint(v) for k, v in args.items()} == draw["fingerprints"]
                wanted = channel_coefficients(args["target"], args, roi)[1]
                if target is None:
                    target = wanted
                else:
                    np.testing.assert_array_equal(target, wanted)
                data = dict(args)
                data.update({k: args[k][0] for k in ("colors", "wb", "matrix")})
                for arm, model in models.items():
                    restored, _ = restore(model, data, case["profile"])
                    band_output[LABELS[arm]].append(channel_coefficients(restored, args, roi)[1])
            scores = {
                name: contributions(np.stack(z), target, BANDS["fine"])
                for name, z in band_output.items()
            }
            scores.update({PARENT: entry["scores"]["Repeat loss"], LOCAL: entry["scores"][LOCAL]})
            grouped[law].append(dict(case=case, scores=scores))
            if i % 4 == 0:
                print("redraw", law, i, flush=True)
    keys = (
        "mean_increment_RMS_DN16",
        "shared_error_product_DN16_squared",
        "swapped_draw_variance_DN16_squared",
        "mean_present_RMS_DN16",
        "mean_quiet_RMS_DN16",
        "pooled_response_pp",
    )
    return {
        law: dict(rows=rows, summary=compare([r["scores"] for r in rows], keys))
        for law, rows in grouped.items()
    }


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    run_ref = reference(ROOT / "training/completed.json")
    run = read_json(checked(run_ref))
    native_ref = reference(PRIOR / "review/result.json")
    native = read_json(checked(native_ref))
    redraw_ref = reference(PRIOR / "review/redraw.json")
    redraw = read_json(checked(redraw_ref))
    parent = read_json(checked(native["endpoint"]))
    assert run["parent"] == parent["checkpoints"]["repeat"]
    assert redraw["endpoint"] == native["endpoint"]
    assert run["updates_per_arm"] == 320 and run["native_observations_per_arm"] == 1920
    train = read_json(checked(run["plan"]))
    source_ids = {row["source"]["id"] for row in read_json(checked(train["schedule"]))}
    assert len(source_ids) == 320
    native.update({kind: data["rows"] for kind, data in native["groups"].items()})
    assert source_ids.isdisjoint(
        r["source"]["source"]["id"] for key in ("photo", "wire") for r in native[key]
    )
    models = {}
    for arm, ref in run["checkpoints"].items():
        model, loaded = load_scene_checkpoint(
            checked(ref), weights="ema", expected_sha256=ref["sha256"]
        )
        assert loaded["training_arm"] == arm and loaded["continued_from"] == run["parent"]
        models[arm] = _stage_tiled_cuda(model, "cuda")
    start = time.monotonic()
    folder = ROOT / "review" / "predictions"
    folder.mkdir(parents=True)
    groups, boards = exact(models, native, folder)
    real, timings = standing(models, native["standing"], folder)
    write_json(
        folder.parent / "result.json",
        dict(
            endpoint=run_ref,
            previous=native_ref,
            groups=groups,
            exact=boards,
            standing=real,
            standing_forward_seconds=timings,
            seconds=time.monotonic() - start,
            driver=reference(__file__),
            weights="EMA",
            precision="CUDA IEEE FP32",
        ),
    )
    print("native boards complete", time.monotonic() - start, flush=True)
    start = time.monotonic()
    repeat = independent(models, redraw, source_ids)
    write_json(
        folder.parent / "redraw.json",
        dict(
            previous=redraw_ref,
            endpoint=run_ref,
            groups=repeat,
            driver=reference(__file__),
            seconds=time.monotonic() - start,
            weights="EMA",
            precision="CUDA IEEE FP32",
        ),
    )


PROFILE = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": 0.33}
if __name__ == "__main__":
    main()
