"""Measure the recovery and false-detail curve of fixed earlier wire predictions."""

from collections import defaultdict
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_response import PRIOR, ROOT
from fit_local import metric_for_wire

DOSES = (0.0, 0.25, 0.5, 0.75, 1.0)
TARGETS = ("Mean control", "Local 50k EMA")


def main():
    binding = reference(PRIOR / "review/result.json")
    archive = read_json(checked(binding))
    rows = archive["groups"]["wire"]["rows"]
    paths = defaultdict(list)
    for row in rows:
        with np.load(checked(row["input"]), allow_pickle=False) as data:
            args = {key: data[key] for key in data.files}
        metric = metric_for_wire(args, row["source"]["geometry"])
        repeat = np.load(checked(row["outputs"]["repeat"]), allow_pickle=False)
        alternatives = (
            np.load(checked(row["outputs"]["mean"]), allow_pickle=False),
            np.load(checked(row["endpoint_output"]), allow_pickle=False),
        )
        for comparison, alternate in zip(TARGETS, alternatives, strict=True):
            for fraction in DOSES:
                result = metric(repeat * (1 - fraction) + alternate * fraction)
                if fraction in (0, 1):
                    source = "Repeat loss" if fraction == 0 else comparison
                    assert all(
                        np.isclose(value, row["scores"][source][k], rtol=1e-7)
                        for k, value in result.items()
                    )
                paths[(comparison, fraction)].append(
                    dict(source=row["source"]["source"]["id"], scores=result)
                )
    curves = {}
    for comp in TARGETS:
        entries = []
        for fraction in DOSES:
            chosen = paths[comp, fraction]
            scores = {
                key: float(np.mean([r["scores"][key] for r in chosen if key in r["scores"]]))
                for key in sorted({k for r in chosen for k in r["scores"]})
            }
            entries.append(dict(fraction=fraction, scores=scores, rows=chosen))
        curves[comp] = entries
        print(
            comp,
            [
                (
                    round(x["scores"]["weak_response_pp"], 3),
                    round(x["scores"]["exact_flat_RMS_DN16"], 3),
                    round(x["scores"]["gap_weak_RMS_DN16"], 3),
                )
                for x in entries
            ],
            flush=True,
        )
    write_json(
        ROOT / "prior-wire-curve.json",
        dict(
            fixed_pairs=24,
            true_gaps=12,
            precision="Existing CUDA IEEE FP32 EMA predictions",
            parent="Repeat loss",
            inputs=binding,
            driver=reference(__file__),
            scope="Fixed camera-RGB mixtures in unit fractions, descriptively scored on the previous exact held-out wire panel.",
            curves=curves,
        ),
    )


if __name__ == "__main__":
    main()
