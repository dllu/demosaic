"""Summarize the parent variance split and fixed open-loop controls."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def paired(reference_rows, alternative):
    assert [r["source"] for r in reference_rows] == [r["source"] for r in alternative]
    rng = np.random.default_rng(202611191309)
    out = {}
    for k in sorted({key for row in alternative for key in row["scores"]}):
        diff = np.asarray(
            [
                b["scores"][k] - a["scores"][k]
                for a, b in zip(reference_rows, alternative, strict=True)
                if k in b["scores"] and k in a["scores"]
            ]
        )
        take = rng.integers(len(diff), size=(8000, len(diff)))
        out[k] = dict(
            mean=float(diff.mean()),
            interval=np.quantile(diff[take].mean(1), [0.025, 0.975]).tolist(),
        )
    return out


def main():
    bound = reference(ROOT / "parent-wire-redraw.json")
    parent = read_json(checked(bound))
    assert len(parent["rows"]) == 16
    rows = [r["scores"]["Repeat parent"] for r in parent["rows"]]
    strength = np.array([r["true_amplitude_DN16"] for r in rows])
    bias = np.array([r["aligned_bias_DN16"] for r in rows])
    np.testing.assert_allclose(100 * (1 + bias / strength), [r["weak_response_pp"] for r in rows])
    variance = np.array([r["intact_draw_variance_DN16_squared"] for r in rows])
    aligned = np.array([r["aligned_variance_DN16_squared"] for r in rows])
    shared = np.array([r["shared_DN16_squared"] for r in rows])
    aligned_shared = bias**2 - aligned / 3
    averaged = {
        k: float(np.mean([r[k] for r in rows if k in r]))
        for k in sorted({k for row in rows for k in row})
    }
    rng = np.random.default_rng(202611191309)
    indexes = np.vstack([np.arange(16), rng.integers(16, size=(8000, 16))])
    fractions = {}
    for name, num, den in (
        ("draw_sensitive", aligned, variance),
        ("shared", aligned_shared, shared),
    ):
        ratio = 100 * num[indexes].sum(1) / den[indexes].sum(1)
        fractions[name] = dict(
            share_along_clean_percent=float(ratio[0]),
            interval=np.quantile(ratio[1:], [0.025, 0.975]).tolist(),
        )
    readout = reference(ROOT / "prior-wire-curve.json")
    curve = read_json(checked(readout))["curves"]
    comparisons = {
        name: dict(
            points={str(b["fraction"]): paired(arms[0]["rows"], b["rows"]) for b in arms[1:]}
        )
        for name, arms in curve.items()
    }
    write_json(
        ROOT / "parent-variance.json",
        dict(
            parent=bound,
            comparisons=readout,
            driver=reference(__file__),
            samples=16,
            means=averaged,
            along_template_percent=fractions,
            source_bootstrap_intervals_on_previous_wire_panel=comparisons,
        ),
    )
    print(fractions)
    for name, point in comparisons.items():
        measured = point["points"]["0.25"]
        print(
            name,
            {
                k: measured[k]
                for k in ("weak_response_pp", "exact_flat_RMS_DN16", "gap_weak_RMS_DN16")
            },
        )


if __name__ == "__main__":
    main()
