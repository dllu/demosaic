"""Decompose strong-band gap error into attenuation and other shapes."""

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_response import LABELS, PARENT, ROOT, compare
from fit_local import metric_for_wire
from upper import luma


def main():
    bound = reference(ROOT / "gap-attribution.json")
    audited = read_json(checked(bound))
    native = read_json(checked(audited["review"]))
    cases = {r["source"]["source"]["id"]: r for r in native["groups"]["wire"]["rows"]}
    rows = []
    for record in audited["rows"]:
        case = cases[record["source"]]
        assert record["input"] == case["input"]
        with np.load(checked(case["input"]), allow_pickle=False) as src:
            args = {k: src[k] for k in src.files}
        metric = metric_for_wire(args, case["source"]["geometry"])
        basis = metric.strong_basis
        exact = metric.truth[0][metric.gap] @ basis
        power = exact @ exact
        assert power > 0
        score = {}
        for model, binding in record["files"].items():
            data = np.load(checked(binding), allow_pickle=False)
            tone = luma(data, args["wb"], args["matrix"])[0, 64:192, 64:192][metric.gap]
            prediction = tone @ basis
            difference = prediction - exact
            response = prediction @ exact / power
            scale = 65535**2 / len(tone)
            along = (response - 1) ** 2 * power * scale
            total = (difference @ difference) * scale
            np.testing.assert_allclose(total, record["scores"][model]["strong_wire"], rtol=1e-8)
            score[model] = {
                "target_aligned_response_pp": float(response * 100),
                "along_target_MSE_DN16_squared": float(along),
                "off_target_MSE_DN16_squared": float(total - along),
            }
        rows.append(dict(source=record["source"], scores=score))
    keys = sorted(set(rows[0]["scores"][PARENT]))
    summary = compare([r["scores"] for r in rows], keys)
    write_json(
        ROOT / "gap-signed.json",
        dict(source=bound, driver=reference(__file__), summary=summary, rows=rows),
    )
    for key, values in summary.items():
        print(key, values["values"], values["differences"]["Aligned wire vs Repeat parent"])


if __name__ == "__main__":
    main()
