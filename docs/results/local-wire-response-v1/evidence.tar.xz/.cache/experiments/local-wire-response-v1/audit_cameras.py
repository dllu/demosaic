"""Bind the three supervised wire continuations to their completed canonical camera cases."""

from collections import Counter, defaultdict
from pathlib import Path
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent / "primary"
OUT = Path("docs/results/local-wire-response-camera-v1")
STAGES = {"known": (24, 4), "unseen": (30, 5)}


def main():
    proof = reference(ROOT / "plan.json")
    plan = read_json(checked(proof))
    witness = reference(ROOT / "preflight/result.json")
    qualification = read_json(checked(witness))
    assert qualification["plan"] == proof and qualification["models"] == plan["models"]
    assert len(qualification["V120_CPU_comparisons"]) == 8
    assert (
        max(
            abs(diff) for demo in qualification["V120_CPU_comparisons"] for diff in demo["delta_dB"]
        )
        < 1e-4
    )
    bundle = read_json(checked(plan["canonical_inputs"]))
    assert bundle["all_input_witnesses_exact"]
    models = plan["models"]
    earlier = reference("docs/results/scene-050000-camera-v1/publication.json")
    earlier_cameras = read_json(checked(earlier))
    assert earlier_cameras["canonical_inputs"] == plan["canonical_inputs"]
    local = reference(ROOT.parent / "training/completed.json")
    expected = read_json(checked(local))
    for label, ref in expected["checkpoints"].items():
        assert models[label]["checkpoint"] == ref and models[label]["step"] == 320
    assert models["prior-repeat"]["checkpoint"] == expected["parent"]
    replay = reference(ROOT / "full/camera-result.json")
    done = read_json(checked(replay))
    assert done["plan"] == proof and done["models"] == models and done["scope"] == "cameras"
    assert done["complete"] and done["counts"] == {
        stage: batches for stage, (batches, _) in STAGES.items()
    }
    before = reference("docs/results/local-redraw-stability-camera-v1/publication.json")
    reference_parent = read_json(checked(before))
    assert reference_parent["canonical_inputs"] == plan["canonical_inputs"]
    assert reference_parent["models"]["repeat"]["checkpoint"] == expected["parent"]
    references = plan["reference_replay"]
    assert references["plan"] == reference_parent["plan"]
    assert references["models"] == {"V120": "V120", "prior-repeat": "repeat"}
    book = {}
    copies = []
    for stage, (batches, scenes) in STAGES.items():
        records = {r["batch"]: r for r in bundle["records"] if r["stage"] == stage}
        assert len(records) == batches
        source_keys, all_scores = {}, defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        cases = []
        for batch, record in sorted(records.items()):
            link = reference(ROOT / "full" / f"{stage}-{batch:05d}.json")
            receipt = read_json(checked(link))
            assert (
                receipt["plan"] == proof and receipt["stage"] == stage and receipt["batch"] == batch
            )
            assert receipt["arrays"] == record["arrays"] and set(receipt["variants"]) == set(models)
            checked(receipt["arrays"])
            original_binding = receipt["reference_replay_batch"]
            old = read_json(checked(original_binding))
            assert old["plan"] == reference_parent["plan"] and old["arrays"] == record["arrays"]
            assert original_binding in reference_parent["panels"][stage]["cases"]
            for name, earlier in references["models"].items():
                actual = receipt["variants"][name]
                witness = old["variants"][earlier]
                assert actual["reused_from"] == {"batch": original_binding, "model": earlier}
                assert actual["output_fingerprint"] == witness["output_fingerprint"]
                assert actual["rows"] == [item | {"model": name} for item in witness["rows"]]
            expect = list(record["context"]["ids"])
            original = None
            for arm, variant in receipt["variants"].items():
                rows = variant["rows"]
                assert variant["output_fingerprint"]["dtype"].endswith("f4")
                assert [r["id"] for r in rows] == expect and len(rows) == variant[
                    "output_fingerprint"
                ]["shape"][0]
                assert all(
                    r["model"] == arm and r["metrics"]["reference_samples"] >= 1024 for r in rows
                )
                identity = [
                    (
                        r["id"],
                        r["scene"],
                        r["pair"],
                        r["pattern"],
                        r["metrics"]["reference_samples"],
                    )
                    for r in rows
                ]
                if original is not None:
                    assert identity == original
                original = identity
                pair = record["context"]["raw_source"]["sha256"]
                scene = record["context"]["scene"]
                assert all((r["scene"], r["pair"]) == (scene, pair) for r in rows)
                for row in rows:
                    all_scores[arm][scene][pair].append(row["metrics"]["sensor_psnr"])
                source_keys.setdefault(arm, Counter()).update(r["id"] for r in rows)
            cases.append(link)
            copies.append((f"{stage}/cases/{batch:05d}.json", link))
        assert all(v == next(iter(source_keys.values())) for v in source_keys.values())
        arm_means = {}
        for arm, fields in all_scores.items():
            assert len(fields) == scenes and all(len(pairs) == 2 for pairs in fields.values())
            assert all(len(q) == 9 for pairs in fields.values() for q in pairs.values())
            balanced = {
                s: float(np.mean([np.mean(v) for v in pairs.values()]))
                for s, pairs in sorted(fields.items())
            }
            arm_means[arm] = dict(
                sensor_psnr=float(np.mean(list(balanced.values()))), per_scene=balanced
            )
        book[stage] = dict(
            batches=batches,
            scenes=scenes,
            crops_per_model=scenes * 18,
            cases=cases,
            overall=arm_means,
            matching_canonical_arrays=True,
        )
    # The V120 camera means must also match its completed archived panel numerically.
    historical = read_json("docs/results/version-PSNR-history-corpus-v6.json")
    baseline = next(x for x in historical["points"] if x["version"] == 120)
    baseline_deltas = {
        s: book[s]["overall"]["V120"]["sensor_psnr"] - baseline[f"{s}_CFA_PSNR"] for s in STAGES
    }
    assert max(map(abs, baseline_deltas.values())) < 1e-4
    parent_deltas = {
        s: book[s]["overall"]["prior-repeat"]["sensor_psnr"]
        - reference_parent["panels"][s]["overall"]["repeat"]["sensor_psnr"]
        for s in STAGES
    }
    assert max(map(abs, parent_deltas.values())) < 1e-4
    assert len(done["cases"]) == len(copies) and sorted(
        p["sha256"] for p in done["cases"]
    ) == sorted(p["sha256"] for _, p in copies)
    OUT.mkdir()
    about = dict(
        plan=proof,
        preflight=witness,
        models=models,
        canonical_inputs=plan["canonical_inputs"],
        weights="EMA",
        prior_camera_study=earlier,
        training=local,
        parent_camera_study=before,
        parent_minus_archived_dB=parent_deltas,
        replay=replay,
        precision="CUDA IEEE FP32, channels-last, measured-CFA reference",
        complete_camera_panels=True,
        photo_panel_complete=False,
        V120_minus_archived_dB=baseline_deltas,
        panels=book,
    )
    for stage, r in book.items():
        key = OUT / f"{stage}.json"
        write_json(key, r)
        copies.append((f"{stage}/analysis.json", reference(key)))
    archive = OUT / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as out:
        for name, link in [
            ("plan.json", proof),
            ("preflight.json", witness),
            ("replay.json", replay),
            ("audit.py", reference(__file__)),
            ("training-audit.json", local),
            *copies,
        ]:
            out.add(checked(link), arcname=name)
    analysis = {s: reference(OUT / f"{s}.json") for s in STAGES}
    write_json(
        OUT / "publication.json",
        about
        | dict(
            archive=reference(archive) | {"path": str(archive)},
            analysis=analysis,
            reused_canonical_references=references,
        ),
    )
    print(baseline_deltas)
    for stage, panel in book.items():
        print(stage, {k: v["sensor_psnr"] for k, v in panel["overall"].items()})


if __name__ == "__main__":
    main()
