"""Compose inspection views at 100% with the original crop pixels."""

from pathlib import Path

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json

ROOT = Path(__file__).resolve().parent
CANDIDATES = ("Repeat parent", "Repeat control", "Full wire band", "Aligned wire")


def make(boards, columns, path):
    width = 12 + 174 * len(columns)
    height = 12 + 185 * len(boards)
    result = Image.new("RGB", (width, height), "#eeeeee")
    text = ImageDraw.Draw(result)
    for row, case in enumerate(boards):
        board = case["board"]
        with Image.open(checked(board["image"])) as img:
            cells = {}
            for item in board["panels"]:
                x, y, w, h = item["png_xywh"]
                assert w == h == 160
                cells[item.get("label", item.get("name"))] = img.crop((x, y, x + w, y + h)).convert(
                    "RGB"
                )
        for col, label in enumerate(columns):
            x, y = 10 + 174 * col, 10 + 185 * row
            text.text(
                (x, y), label if col else case["id"].replace("-fine-green-mesh", ""), fill="black"
            )
            result.paste(cells[label], (x, y + 17))
    result.save(path)


if __name__ == "__main__":
    review = read_json(ROOT / "review/result.json")
    make(review["exact"], ("Noisy Malvar", *CANDIDATES, "Exact GT"), ROOT / "view-exact.png")
    for family in ("main", "mesh"):
        boards = [case for case in review["standing"] if case["id"].startswith(family)]
        other = "ISO100 camera JPEG" if family == "mesh" else "ISO100 AHD reference"
        make(boards, ("Noisy (Malvar)", *CANDIDATES, other), ROOT / f"view-{family}.png")
