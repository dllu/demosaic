"""Measure which orthogonal components contribute to absolute error in true gaps."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from review_response import LABELS, PARENT, ROOT, compare
from fit_local import metric_for_wire
from upper import luma


def evaluate(prediction, metric, data):
    tone = luma(prediction, data["wb"], data["matrix"])[0, 64:192, 64:192]
    err = (tone - metric.truth[0])[metric.gap]
    contrast_rank = metric.strong_basis.shape[1]
    nuisance = metric.gap_nuisance[:, : metric.gap_nuisance.shape[1] - contrast_rank]
    components = {
        "background_and_edge": nuisance,
        "strong_wire": metric.strong_basis,
        "weak_direction": metric.weak_basis,
    }
    scale = 65535.0**2 / len(err)
    whole = float(err @ err) * scale
    result = {name: float(np.sum((err @ basis) ** 2)) * scale for name, basis in components.items()}
    rest = err - sum((err @ basis) @ basis.T for basis in components.values())
    result["remaining"] = float(rest @ rest) * scale
    np.testing.assert_allclose(sum(result.values()), whole, rtol=1e-8, atol=1e-8)
    result["total"] = whole
    return result


def main():
    proof = reference(ROOT / "review/result.json")
    native = read_json(checked(proof))
    rows = []
    for case in native["groups"]["wire"]["rows"]:
        with np.load(checked(case["input"]), allow_pickle=False) as stream:
            args = {k: stream[k] for k in stream.files}
        metric = metric_for_wire(args, case["source"]["geometry"])
        if not metric.gap.any():
            continue
        files = {PARENT: case["parent_output"]} | {LABELS[k]: v for k, v in case["outputs"].items()}
        result = {
            name: evaluate(np.load(checked(bind), allow_pickle=False), metric, args)
            for name, bind in files.items()
        }
        for name in result:
            np.testing.assert_allclose(
                result[name]["total"] ** 0.5, case["scores"][name]["gap_RMS_DN16"], rtol=1e-10
            )
            np.testing.assert_allclose(
                result[name]["weak_direction"] ** 0.5,
                case["scores"][name]["gap_weak_RMS_DN16"],
                rtol=1e-10,
            )
        rows.append(
            dict(
                source=case["source"]["source"]["id"],
                input=case["input"],
                files=files,
                scores=result,
                geometry=case["source"]["geometry"]["family"],
                pixels=int(metric.gap.sum()),
            )
        )
    assert len(rows) == 12
    scopes = sorted({k for row in rows for k in row["scores"][PARENT]})
    summary = compare([r["scores"] for r in rows], scopes)
    write_json(
        ROOT / "gap-attribution.json",
        dict(
            review=proof,
            driver=reference(__file__),
            summary=summary,
            rows=rows,
            units="DN16 squared",
            scope="Fixed held-out exact weak-direction gaps, known geometry, absolute channel-weighted luminance residual.",
        ),
    )
    for label in ("Aligned wire vs Repeat parent", "Aligned wire vs Repeat control"):
        print(label, {k: round(summary[k]["differences"][label]["delta"], 2) for k in scopes})


if __name__ == "__main__":
    main()
