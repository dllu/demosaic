"""Publish the completed endpoint and its reviewed native evidence."""

from collections import Counter
from datetime import datetime
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
RESULTS, IMAGES = (Path("docs") / part / ROOT.name for part in ("results", "images"))


def read_lines(binding):
    import json

    return [json.loads(line) for line in checked(binding).read_text().splitlines()]


def audit_training():
    qual_ref, training_ref = (
        reference(ROOT / phase / "completed.json") for phase in ("qualification", "training")
    )
    qual, run = (read_json(checked(binding)) for binding in (qual_ref, training_ref))
    assert qual["qualification"] and not run["qualification"] and qual["plan"] == run["plan"]
    assert run["parent"] == qual["parent"] and qual["DINO_unchanged"] and run["DINO_unchanged"]
    plan = read_json(checked(run["plan"]))
    parent = read_json(checked(plan["parent_completion"]))
    assert parent["checkpoints"]["repeat"] == run["parent"] == plan["parent"]
    assert plan["initial_step"] == parent["updates_per_arm"] == 320
    checked(run["parent"])
    arms = set(plan["mode_weights"])
    assert arms == {"repeat", "wire-mean", "wire-aligned"}
    for phase in (qual, run):
        for binding in phase["checkpoints"].values():
            checked(binding)
    observation = {}
    for name, phase, count, schedule_key in (
        ("qualification", qual, 8, "qualification_schedule"),
        ("training", run, 320, "schedule"),
    ):
        order = read_json(checked(plan[schedule_key]))
        inputs, losses = (read_lines(phase[key]) for key in ("observations", "log"))
        assert (
            phase["updates_per_arm"]
            == phase["source_photos_per_arm"]
            == len(inputs)
            == len(losses)
            == len(order)
            == count
        )
        assert phase["native_observations_per_arm"] == 6 * count
        groups = Counter()
        for case, data, logged in zip(order, inputs, losses, strict=True):
            assert (
                data["source_id"] == case["source"]["id"]
                and data["cache_sha256"] == case["source"]["cache_sha256"]
            )
            assert (data["iso"], data["kind"], data["law"], data["camera"]["pattern"]) == (
                case["iso"],
                case["kind"],
                case["law"],
                case["pattern"],
            )
            assert len(set(data["seeds"].values())) == 8 and arms <= set(logged)
            for arm in arms:
                assert np.isfinite(list(logged[arm].values())).all()
                assert ("aligned_loss" in logged[arm]) == (case["kind"] == "wire")
                assert logged[arm]["paired"] == logged[arm]["mean_loss"]
            groups[(case["kind"], case["iso"], case["pattern"], case["law"])] += 1
        if name == "training":
            assert len(groups) == 32 and set(groups.values()) == {10}
        ids = {x["source_id"] for x in inputs}
        assert len(ids) == count
        observation[name] = ids
    assert observation["training"].isdisjoint(observation["qualification"])
    old_plan = read_json(checked(parent["plan"]))
    old_ids = {
        row["source"]["id"]
        for key in ("schedule", "qualification_schedule")
        for row in read_json(checked(old_plan[key]))
    }
    assert all(s.isdisjoint(old_ids) for s in observation.values())
    return dict(
        run,
        receipt=training_ref,
        qualification_receipt=qual_ref,
        parent_completion=plan["parent_completion"],
        initial_step=plan["initial_step"],
        train_manifest=next(
            x for x in plan["inputs"] if x["path"].endswith("manifest-train.jsonl")
        ),
        qualification_observations_and_losses_checked=True,
        previous_redraw_sources_excluded=True,
        matched_training_observations_checked=True,
    )


def publish_board(board):
    source = checked(board["image"])
    dest = IMAGES / source.parent.name / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    assert reference(dest)["sha256"] == board["image"]["sha256"]
    board["image"]["path"] = str(dest.relative_to(IMAGES))
    with Image.open(dest) as img:
        pixels = np.asarray(img.convert("RGB"))
    crops = {}
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert w == h == 160
        crops[panel.get("label", panel.get("name"))] = pixels[y : y + h, x : x + w]
    return crops


def main():
    training = audit_training()
    native_binding = reference(ROOT / "review/result.json")
    redraw_binding = reference(ROOT / "review/redraw.json")
    native, redraw = (read_json(checked(x)) for x in (native_binding, redraw_binding))
    assert native["endpoint"] == redraw["endpoint"] == training["receipt"]
    assert len(native["groups"]["photo"]["rows"]) == len(native["groups"]["wire"]["rows"]) == 24
    assert all(len(panel["rows"]) == 16 for panel in redraw["groups"].values())
    viewed_ref = reference(ROOT / "viewing-notes.json")
    viewed = read_json(checked(viewed_ref))
    assert set(viewed["exact"]) == {board["id"] for board in native["exact"]}
    assert set(viewed["standing"]) == {board["id"] for board in native["standing"]}
    for item in native["exact"]:
        full = publish_board(item["board"])
        triplet = publish_board(item["triplet"])
        assert list(triplet) == ["Noisy Malvar", "Aligned wire", "Exact GT"]
        assert all(np.array_equal(value, full[k]) for k, value in triplet.items())
    for item in native["standing"]:
        full = publish_board(item["board"])
        assert {
            "Repeat parent",
            "Repeat control",
            "Full wire band",
            "Aligned wire",
            "ISO100 AHD reference",
        } <= set(full)
        if item["id"].startswith("mesh-"):
            assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= set(full)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        dict(
            exact=native["exact"],
            standing=native["standing"],
            review=native_binding,
            ISO100_reference="Independent capture and independent demosaicing, qualitative reference.",
            models=training["checkpoints"],
            parent=training["parent"],
            viewing_notes=viewed_ref,
            viewed_local=datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            weights="EMA",
            precision=native["precision"],
        ),
    )
    RESULTS.mkdir(exist_ok=True, parents=True)
    out = RESULTS / "training.json"
    write_json(out, training)
    wire_binding = reference(ROOT / "review/wire-redraw.json")
    wire = read_json(checked(wire_binding))
    assert wire["endpoint"] == native["endpoint"] and len(wire["rows"]) == 16
    parent_binding = wire["parent_replay"]
    parent = read_json(checked(parent_binding))
    assert (
        parent["inputs"] == wire["inputs"]
        and parent["models"]["Repeat parent"] == training["parent"]
    )
    capture = reference(ROOT / "wire-capture-audit.json")
    assert read_json(checked(capture))["inputs"] == wire["inputs"]
    curve = reference(ROOT / "prior-wire-curve.json")
    baseline = reference(ROOT / "parent-variance.json")
    matched_wire = reference(ROOT / "matched-wire-response.json")
    assert read_json(checked(matched_wire))["evaluation"] == native_binding
    matched_repeat = reference(ROOT / "matched-repeat-parent.json")
    assert read_json(checked(matched_repeat))["evaluation"] == native_binding
    chart = reference(ROOT / "response-tradeoff.png")
    chart_path = IMAGES / "response-tradeoff.png"
    shutil.copyfile(checked(chart), chart_path)
    assert reference(chart_path)["sha256"] == chart["sha256"]
    gap_analysis = reference(ROOT / "gap-attribution.json")
    gap_direction = reference(ROOT / "gap-signed.json")
    assert read_json(checked(gap_analysis))["review"] == native_binding
    assert read_json(checked(gap_direction))["source"] == gap_analysis
    for piece in (curve, baseline, matched_wire, matched_repeat, gap_analysis, gap_direction):
        dest = RESULTS / Path(piece["path"]).name
        shutil.copyfile(checked(piece), dest)
        assert reference(dest)["sha256"] == piece["sha256"]
    plan = read_json(checked(training["plan"]))
    qual = read_json(checked(training["qualification_receipt"]))
    archive = RESULTS / "evidence.tar.xz"
    pieces = [
        native_binding,
        redraw_binding,
        wire_binding,
        wire["inputs"],
        parent_binding,
        capture,
        curve,
        baseline,
        matched_wire,
        matched_repeat,
        gap_analysis,
        gap_direction,
        chart,
        viewed_ref,
        training["receipt"],
        training["plan"],
        plan["schedule"],
        plan["qualification_schedule"],
        plan["driver"],
        training["observations"],
        training["log"],
        training["qualification_receipt"],
        qual["observations"],
        qual["log"],
        *(
            reference(ROOT / f)
            for f in (
                "qualification.log",
                "training.log",
                "review.log",
                "natural-redraw.log",
                "wire-redraw.log",
            )
        ),
        *(reference(f) for f in sorted(ROOT.glob("*.py"))),
        reference(out),
    ]
    with tarfile.open(archive, "x:xz", preset=4) as bundle:
        for binding in pieces:
            source = checked(binding)
            bundle.add(source, arcname=source.relative_to(Path.cwd()), recursive=False)
    write_json(
        RESULTS / "publication.json",
        dict(
            training=reference(out),
            archive=reference(archive),
            manifest=reference(manifest),
            curves=reference(RESULTS / "prior-wire-curve.json"),
            parent_variance=reference(RESULTS / "parent-variance.json"),
            matched_wire=reference(RESULTS / "matched-wire-response.json"),
            matched_repeat=reference(RESULTS / "matched-repeat-parent.json"),
            gap_attribution=reference(RESULTS / "gap-attribution.json"),
            gap_signed=reference(RESULTS / "gap-signed.json"),
            response_tradeoff=reference(chart_path),
            wire_redraw_metrics=wire["summary"],
            models=training["checkpoints"],
            parent=training["parent"],
            reviews=dict(
                native_metrics_complete=True,
                independent_redraw_metrics_complete=True,
                independent_wire_redraws_complete=True,
                native_image_view_complete=True,
                fixed_427_complete=False,
            ),
            training_seconds=training["training_seconds"],
            native_evaluation_seconds=native["seconds"],
            redraw_evaluation_seconds=redraw["seconds"],
            wire_redraw_evaluation_seconds=wire["seconds"],
            exact_metrics={k: g["summary"] for k, g in native["groups"].items()},
            redraw_metrics={k: g["summary"] for k, g in redraw["groups"].items()},
            standing={case["id"]: case["rms_vs_parent_DN16"] for case in native["standing"]},
        ),
    )


if __name__ == "__main__":
    main()
