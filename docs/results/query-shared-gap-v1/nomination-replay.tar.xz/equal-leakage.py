"""Compare exploratory nominations to a uniform strength reduction at equal gap RMS."""
import numpy as np

from nominate import BASE, ROOT, CORE, fields, luma, score
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

source = reference(ROOT / 'nomination.json')
selected = read_json(checked(source))
prior = read_json(checked(selected['base_scores']))
outcomes = {}
for cohort, ledger in prior['cohorts'].items():
    observed = read_json(checked(ledger['raw']))
    sets = {}
    for row, candidate in zip(observed['rows'], selected['evaluations'][cohort]['cases'], strict=True):
        assert (row['index'], row['noise']) == (candidate['index'], candidate['noise'])
        if candidate['gap']:
            obs, img = fields(row)
            images = {k:luma(img[k], obs) for k in ('parent','directional','shared')}
            images['target'] = luma(obs['target'], obs)
            sets.setdefault(row['noise'], []).append((images, obs['support'], candidate))
    outcomes[cohort] = {}
    for noise, dataset in sets.items():
        ranking = selected['evaluations'][cohort]['by_noise'][noise]
        def quality(scale):
            scores = []
            for values, support, _ in dataset:
                ref = values['directional'] + scale*(values['shared']-values['directional'])
                scores.append(score(values['target'],support,values | {'scaled':ref})['scaled'])
            return {m:float(np.mean([c[m] for c in scores]))for m in scores[0]}
        for arm in ('nuisance','agreement'):
            target = ranking[arm]['added_gap_RMS']
            best, worst = quality(1)['added_gap_RMS'], quality(0)['added_gap_RMS']
            if not best <= target <= worst:
                continue
            lo, hi = 0., 1.
            for _ in range(28):
                mid = (lo+hi)*.5
                if quality(mid)['added_gap_RMS'] > target:
                    lo = mid
                else:
                    hi = mid
            calibrated = quality((lo+hi)*.5)
            assert abs(calibrated['added_gap_RMS']-target) < 1e-5
            outcomes[cohort].setdefault(noise,{})[arm] = {'ranking': ranking[arm], 'scaled_shared':calibrated,
                'scale': (lo+hi)*.5, 'cut_continuous_count': ranking[arm]['cut_continuous']}
write_json(ROOT/'equal-leakage.json', {'source':source, 'driver':reference(__file__), 'results':outcomes,
           'scope':'Retrospective calibration to the exact mean added gap RMS. Exact labels set only the diagnostic comparison scale.'})
