"""Replay shared weak-wire gap nominations with footprint-aware nuisance fits."""
from copy import deepcopy
from pathlib import Path
import sys

import numpy as np

BASE = Path(__file__).resolve().parents[1] / 'query-shared-gap-v1'
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from review import CORE, fields, luma, rms
from check import DEFICIT_THRESHOLD, apply, area, held, interior, latent, regress, shapes
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def candidates(data, model):
    x, y, _, raw, var, fold = data
    use = model['domain'] & (fold < 2)
    phase = model['g_shared'][use]
    base = model['nuisance'][use]
    d = raw[use]
    v = var[use]
    weight = model['taper'][use] / v
    cross = base.T * weight
    precision = regress(base, weight, d)[1]
    d = d - base @ (precision @ (cross @ d))
    variance = weight**2 * v
    winners = {}
    for start in range(0, len(shapes()), 32):
        bank = shapes()[start:start + 32]
        hard, soft = area(x[use], y[use], bank)
        blocks = np.column_stack((-hard * phase[:, None], hard, soft))
        blocks -= base @ (precision @ (cross @ blocks))
        pulse, a, b = np.split(blocks, 3, axis=1)
        aa = (weight @ (a*a)).clip(1e-20)
        ab = weight @ (a*b)
        bb = (weight @ (b*b)).clip(1e-20)
        da = weight @ (pulse*a)
        db = weight @ (pulse*b)
        determinant = (aa*bb-ab*ab).clip(1e-20)
        pulse -= a * ((da*bb-db*ab)/determinant) + b * ((db*aa-da*ab)/determinant)
        power = weight @ (pulse*pulse)
        signal = (weight*d) @ pulse
        fold_z = []
        for side in (0, 1):
            study = fold[use] == side
            fold_z.append(((weight[study]*d[study]) @ pulse[study]) / np.sqrt((variance[study] @ (pulse[study]**2)).clip(1e-20)))
        pooled = signal / np.sqrt((variance @ (pulse*pulse)).clip(1e-20))
        rejected = ((hard > .92).sum(axis=0) < 150) | ((hard < .05).sum(axis=0) < 600) | (power < 3)
        scores = {'nuisance': pooled.copy(), 'agreement': np.minimum(*fold_z)}
        for name, rank in scores.items():
            rank[rejected] = -np.inf
            winner = int(np.argmax(rank))
            if np.isfinite(rank[winner]) and (name not in winners or rank[winner] > winners[name]['rank']):
                winners[name] = {'index': start+winner, 'shape': bank[winner].tolist(),
                                 'z': float(pooled[winner]), 'rank': float(rank[winner]),
                                 'fraction': float(signal[winner]/power[winner]),
                                 'discovery_fold_scores': [float(s[winner]) for s in fold_z]}
    return {name: c if c['z'] >= 2 else None for name, c in winners.items()}


def score(target, support, vals):
    true_gap = support[CORE] == 0
    intact = support[CORE] >= .97
    baseline = vals['directional'][0][CORE]
    desired = (target[0]-target[1])[CORE][intact]
    return {method:{'added_gap_RMS': rms((v[0]-vals['parent'][0])[CORE][true_gap]) if true_gap.any() else None,
                    'total_gap_error_RMS': rms((v[0]-target[0])[CORE][true_gap]) if true_gap.any() else None,
                    'intact_response': float(100*(v[0][CORE][intact]-v[1][CORE][intact])@desired/(desired@desired)) if (desired@desired)>0 else None,
                    'intact_edit_RMS': rms((v[0][CORE]-baseline)[intact]) if intact.any() else None}
            for method,v in vals.items() if method != 'parent'}


def main():
    receipt = reference(BASE / 'scores.json')
    scorebook = read_json(checked(receipt))
    summary = {}
    for cohort, names in scorebook['cohorts'].items():
        source = read_json(checked(names['raw']))
        plan = read_json(checked(names['hub']))
        results = []
        for old in source['rows']:
            proof = old['checks']['matching'][0]
            obs, pictures = fields(old)
            variants = {k: pictures['directional'].copy() for k in ('nuisance','agreement')}
            picked = {}
            if 'geometry' in proof:
                noise = plan['profiles'][old['noise']]
                native, _, boundary = interior(obs['packed'][0], obs['colors'][0], noise)
                model = latent(native, boundary, proof['geometry'])
                picked = candidates(native, model)
                assert set(picked) == set(variants)
                for arm, nominate in picked.items():
                    witness = held(native, model, 'shared', nominate)
                    if witness and witness['pooled'] >= DEFICIT_THRESHOLD and min(witness['scores']) >= .85:
                        strength = float(np.clip(.85*min(witness['fraction'],nominate['fraction']),0,.85))
                        gate = deepcopy(proof)
                        gate['chosen']['shared'] = nominate
                        gate['cut']['shared'] = strength
                        variants[arm][0] = apply(pictures['parent'][0],pictures['directional'][0],gate,'shared')
                    else:
                        strength = 0
                    picked[arm] = {'nomination': nominate, 'held': witness, 'cut': strength}
            values = {name:luma(v,obs) for name,v in pictures.items() if name in ('parent','directional','shared')}
            values.update({name:luma(v,obs) for name,v in variants.items()})
            calculated = score(luma(obs['target'],obs),obs['support'],values)
            results.append({'index':old['index'],'noise':old['noise'],'edits':picked,'measures':calculated,
                            'gap':bool((obs['support'][CORE]==0).any())})
        by_noise = {}
        for label in sorted({row['noise'] for row in results}):
            group = [r for r in results if r['noise']==label]
            scores = {}
            for arm in ('directional','shared','nuisance','agreement'):
                gap = [r['measures'][arm] for r in group if r['gap']]
                scores[arm] = {m: float(np.mean([r[m] for r in gap])) for m in gap[0]}
                scores[arm]['cut_true'] = sum(r['edits'].get(arm,{}).get('cut',0)>0 for r in group if r['gap']) if arm in variants else None
                scores[arm]['cut_continuous'] = sum(r['edits'].get(arm,{}).get('cut',0)>0 for r in group if not r['gap']) if arm in variants else None
            by_noise[label] = scores
        summary[cohort] = {'by_noise':by_noise,'cases':results}
    write_json(ROOT / 'nomination.json',{'base_scores':receipt,'driver':reference(__file__),'evaluations':summary,
              'scope':'Exploratory replay. Uses identical reserved fold check and edit. Primary and prior cohorts reused. No image re-render in this diagnostic.'})
    print({k:v['by_noise'] for k,v in summary.items()},flush=True)


if __name__ == '__main__':
    main()
