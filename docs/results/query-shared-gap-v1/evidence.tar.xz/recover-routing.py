"""Bind all complete routing shards after the final receipt used a stale source path."""
import numpy as np

from check import ROOT,SHAPE
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def main():
    parents=reference(ROOT/"parents.json")
    final=read_json(checked(parents))
    stashed=reference(ROOT/"routing-run.py")
    error=reference(ROOT/"routing.log")
    assert b"FileNotFoundError" in checked(error).read_bytes()
    order=[]
    for source in final["rows"]:
        row=read_json(ROOT/"predictions"/f'{source["index"]:03d}-{source["noise"]}.json')
        assert all(row[k]==source[k]for k in ("index","noise","input","parent"))
        with np.load(checked(row["prediction"]),allow_pickle=False)as f:
            assert len(f.files)==9 and all(f[k].shape==(4,3,256,256)for k in f.files)
        order.append(row)
    assert len(order)==24
    write_json(ROOT/"results.json",{"driver":stashed,"assembly":reference(__file__),"initial_receipt_error":error,
          "parent_receipts":parents,"shape_policy":reference(SHAPE/"routing.py"),
          "checkpoint":final["checkpoint"],"rows":order})


if __name__=="__main__":
    main()
