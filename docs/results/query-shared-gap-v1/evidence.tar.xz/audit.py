"""Verify sample isolation, control images and raw information at fixed footprints."""
import json
import math

import numpy as np

from check import ROOT,METHODS,analyze,apply,area,held,interior,latent
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from witness import anchored,local

RAW=np.s_[...,64:192,64:192]


def mathematical():
    f=[[.106,.061,0.],[.084,-.079,0.]]
    colors=np.array([0,1,1,2])
    coord=np.arange(256)-127.5
    y,x=np.meshgrid(coord,coord,indexing="ij")
    a=2*np.pi*(f[0][0]*x+f[0][1]*y)-.28
    b=2*np.pi*(f[1][0]*x+f[1][1]*y)+.71
    pattern=(0,16.,-16.,21.,36.,0.)
    gap=area(x.ravel(),y.ravel(),pattern)[0][:,0].reshape(x.shape)
    front=.018*np.cos(a)
    weak=.009*(np.cos(b)+.55*np.cos(2*b))
    data=.31+.022*x/128+.009*y/128+front+weak*(1-gap)
    packed=np.stack([data[dy::2,dx::2]for dy,dx in ((0,0),(0,1),(1,0),(1,1))])
    profile={"shot":0.,"read":1.5e-7}
    original=analyze(packed,colors,profile,f)
    assert "shared" in original["cut"] and len(original["active_orders"])>=2
    assert original["target"]==1
    parent=np.full((3,256,256),.31)
    rendered=parent+front+weak
    after=apply(parent,rendered,original,"shared")
    chosen=area(x.ravel(),y.ravel(),original["chosen"]["shared"]["shape"])[0][:,0].reshape(x.shape)
    np.testing.assert_array_equal(after[:,chosen==0],rendered[:,chosen==0])
    true_gap=gap==1
    assert np.linalg.norm((after-rendered+weak)[1,true_gap])<np.linalg.norm(weak[true_gap])
    with anchored((0,0)):
        hold=local.partition()>=2
    mutate=packed.copy()
    mutate[:,hold]=np.random.default_rng(181837).uniform(.19,.46,(4,int(hold.sum())))
    disputed=analyze(mutate,colors,profile,f)
    assert original["geometry"]==disputed["geometry"] and original["boundary"]==disputed["boundary"]
    assert original["chosen"]==disputed["chosen"] and original["active_orders"]==disputed["active_orders"]
    assert original["discovery_bands"]==disputed["discovery_bands"] and original["held"]!=disputed["held"]
    dominant=np.cos(a)[true_gap]
    exposed=after[1,true_gap]-rendered[1,true_gap]
    return {"shape":original["chosen"]["shared"],"weaker_orders":original["active_orders"],
            "selected_zone_exterior_pixel_exact":True,"fixed_nomination_under_held_intervention":True,
            "raw_scores_changed_under_held_intervention":True,
            "relative_edit_projection_on_strong_direction":float((dominant@exposed)/(dominant@dominant)/.018)}


def inspect_oracle(row,source,profile):
    decision=row["source_geometry"][0]["matching"]
    if not decision["state"].startswith("donor-"):
        return {"index":row["index"],"route":"rejected"}
    raw=row["checks"]["matching"][0]
    wave=source["geometry"]
    with np.load(checked(row["input"]),allow_pickle=False)as arrays:
        packed=arrays["packed"][0][RAW]
        cfa=arrays["colors"][0]
        gold=arrays["support"].astype(float)==0
    data,_,boundary=interior(packed,cfa,profile)
    model=latent(data,boundary,decision["geometry"])
    cx,cy=wave["gap_center"]
    w,l,theta=(wave[k]for k in ("gap_width","gap_length","gap_orientation"))
    if wave["family"]=="strip":
        shape=(1,cx*math.cos(theta)+cy*math.sin(theta),0.,w,1.,theta)
    else:
        shape=(0,cx,cy,w,l,theta)
    fixed={"shape":shape}
    results={}
    coord=np.arange(256)-127.5
    y,x=np.meshgrid(coord,coord,indexing="ij")
    for k in ("fundamental","shared"):
        own=raw["chosen"][k]
        cross=raw["chosen"]["shared" if k=="fundamental"else "fundamental"]
        observed=None
        if own:
            fit=(area(x.ravel(),y.ravel(),own["shape"])[0][:,0].reshape(x.shape)>.5)
            region=np.sum(fit&gold)/max(1,np.sum(fit|gold))
            observed={"footprint_IoU":float(region),"score":raw["held"][k]}
        results[k]={"true_shape_evidence":held(data,model,k,fixed),"automatic":observed,
                    "other_arms_nominated_shape":held(data,model,k,cross)}
    return {"index":row["index"],"family":wave["family"],"route":"admitted","fixed":results}


def main():
    score=reference(ROOT/"scores.json")
    checked_outputs=read_json(checked(score))
    camera=reference(ROOT/"standing/manifest.json")
    real=read_json(checked(camera))
    for row in real["rows"]:
        with np.load(checked(row["arrays"]),allow_pickle=False)as f:
            for k in METHODS:
                np.testing.assert_array_equal(f[k],f["before"])
    stats={}
    bound={}
    all_ids={}
    for tag,ledger in checked_outputs["cohorts"].items():
        spot=read_json(checked(ledger["raw"]))
        capture=read_json(checked(spot["observations"]))
        plan=read_json(checked(capture["source"]))
        all_ids[tag]={k["source"]["id"]for k in plan["sources"]}
        if tag=="fresh":
            with checked(plan["training_manifest"]).open()as f:
                training={json.loads(r)["id"]for r in f}
            assert not all_ids[tag]&training
        proof=[]
        for row in spot["rows"]:
            a,b=row["index"],row["noise"]
            with np.load(checked(row["output"]),allow_pickle=False)as f:
                for kind in METHODS:
                    np.testing.assert_array_equal(f[kind][1:],f["directional"][1:])
                    np.testing.assert_array_equal(f["rotated_"+kind],f["rotated_base"])
            if tag=="fresh"and plan["sources"][a]["geometry"]["family"]in ("ellipse","strip"):
                proof.append(inspect_oracle(row,plan["sources"][a],plan["profiles"][b]))
        stats[tag]=len(spot["rows"])
        bound[tag]=proof
    assert len(all_ids["fresh"])==len(all_ids["replay"])==24 and not all_ids["fresh"]&all_ids["replay"]
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"results":score,"standing":camera,
              "exact_math":mathematical(),"native_camera_pixel_identity":True,
              "outside_strong_flat_and_rotated_bitwise_controls":stats,"photo_cohort_overlap":0,
              "training_overlap_fresh":0,"known_footprint_diagnostic_only":bound["fresh"]})
    print(stats,flush=True)


if __name__=="__main__":
    main()
