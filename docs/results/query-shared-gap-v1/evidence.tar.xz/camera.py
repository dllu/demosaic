"""Review the shared-waveform gap check on the standing GFX boards."""
import sys
import numpy as np
from PIL import Image
import torch

from check import ROOT,SHAPE,METHODS,analyze,apply
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

COMPOSITION=ROOT.parent/"query-donor-composition-v1"


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    origin=reference(SHAPE/"standing/manifest.json")
    reference_shapes=reference(COMPOSITION/"standing/manifest.json")
    prior=read_json(checked(origin))
    notes={r["id"]:r for r in read_json(checked(reference_shapes))["rows"]}
    output=ROOT/"standing"
    output.mkdir()
    gathered=[]
    for row in prior["rows"]:
        name=row["id"]
        left,top,w,h=row["box"]
        sx,sy,cw,ch=row["ROI"]
        box=sx-left,sy-top,cw,ch
        pix=np.s_[...,box[1]:box[1]+ch,box[0]:box[0]+cw]
        with np.load(checked(row["base_input"]),allow_pickle=False)as f:
            raw=f["packed"][0,:,top//2:(top+h)//2,left//2:(left+w)//2]
            colors,wb,mat=(f[k][0]for k in ("colors","wb","matrix"))
        with np.load(checked(row["prediction"]),allow_pickle=False)as f:
            parent,before=f["parent"],f["directional"]
        state=notes[name]["state"]
        evidence=analyze(raw,colors,row["noise"],state["refined"]) if state["state"].startswith("donor-") else {"cut":{}}
        methods={k:apply(parent,before,evidence,k)for k in METHODS}
        with Image.open(checked(row["image"]))as f:
            raster=np.asarray(f.convert("RGB"))
        previous={p["name"]:raster[y:y+h,x:x+w]for p in row["panels"]for x,y,w,h in (p["png_xywh"],)}
        take=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Per-direction gate")
        panels=[(k,previous[k])for k in take if k in previous]
        for key,label in (("fundamental","Fundamental deficit"),("shared","Shared-wave deficit"),("sharp","Shared, smooth-dip check")):
            cropped=display_crop(torch.from_numpy(methods[key][None]),torch.from_numpy(wb[None]),
                 torch.from_numpy(mat[None]),box,exposure=row["display_exposure"])
            panels.append((label,np.rint(cropped*255).astype(np.uint8)))
        panels.extend((k,previous[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in previous)
        art=native_png(output/(name+".png"),panels)
        data=output/(name+".npz")
        np.savez(data,parent=parent,before=before,**methods)
        metrics={k:float(np.sqrt(np.mean((pred[pix].astype(float)-before[pix])**2))*65535)for k,pred in methods.items()}
        gathered.append({k:row[k]for k in ("id","box","ROI","noise","display_exposure","base_input")}|
                        art|{"predecessor":row["image"],"arrays":reference(data),"fit":evidence,"RMS_change_DN16":metrics})
        print(name,evidence["cut"],metrics,flush=True)
    write_json(output/"manifest.json",{"driver":reference(__file__),"prior":origin,
                 "prior_geometry":reference_shapes,"checkpoint":prior["checkpoint"],"rows":gathered})


if __name__=="__main__":
    main()
