"""Infer the same neural query and 32-native-pixel halo for both exteriors."""
from pathlib import Path
import sys
import time

import numpy as np
import torch

from check import ROOT
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32

sys.path.insert(0,str(ROOT.parent/"donor-peak-prominence-v1"))
from run_restore import ARGS,setup_models

PAD=np.s_[...,48:208,48:208]


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/torch.cuda.get_device_properties(0).total_memory))
    captured=reference(ROOT/"captures.json")
    list_of_files=read_json(checked(captured))
    plan=read_json(checked(list_of_files["source"]))
    root=ROOT/"parents"
    root.mkdir()
    reached=[]
    elapsed=time.monotonic()
    with ieee_fp32():
        mdl=setup_models({"models":{"100k":plan["base"]}})["100k"]
        for row in list_of_files["rows"]:
            noise=plan["profiles"][row["noise"]]
            mdl.set_noise(noise["shot"],noise["read"])
            with np.load(checked(row["input"]),allow_pickle=False)as f:
                for name in ("packed","variance"):
                    np.testing.assert_array_equal(f[name][PAD],f["rotated_"+name][PAD])
                parts={k:(f[k][PAD].copy()if k in ("packed","variance")else f[k])for k in ARGS}
            params=[torch.from_numpy(parts[k]).to("cuda")for k in ARGS]
            params[:2]=[x.contiguous(memory_format=torch.channels_last)for x in params[:2]]
            result=mdl(*params).cpu().numpy()
            assert result.shape==(4,3,320,320)
            path=root/Path(row["input"]["path"]).name
            np.save(path.with_suffix(".npy"),result,allow_pickle=False)
            reached.append({"index":row["index"],"noise":row["noise"],"input":row["input"],
                           "parent":reference(path.with_suffix(".npy"))})
            print(row["index"],row["noise"],round(time.monotonic()-elapsed,2),flush=True)
    write_json(ROOT/"parents.json",{"driver":reference(__file__),"captures":captured,
                                    "checkpoint":plan["base"],"rows":reached,"seconds":time.monotonic()-elapsed})


if __name__=="__main__":
    main()
