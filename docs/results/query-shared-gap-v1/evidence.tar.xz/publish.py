"""Publish the scoped Bayer gap study with its viewed native boards."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
IMAGES = Path('docs/images/query-shared-gap-v1')
RESULTS = Path('docs/results/query-shared-gap-v1')


def copy_board(board, collection, note):
    source = checked(board['image'])
    target = IMAGES / collection / source.name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert reference(target)['sha256'] == board['image']['sha256']
    with Image.open(target) as image:
        if 'order' in board:
            assert image.size == (160 * len(board['order']), 160)
        else:
            for panel in board['panels']:
                x, y, width, height = panel['png_xywh']
                assert width == height == 160 and x + width <= image.width and y + height <= image.height
        image.verify()
    return board | {'image': {'path': str(target), 'sha256': board['image']['sha256']}, 'actual_viewing': note}


def exact_note(cohort, role):
    if role == 'quiet':
        return 'The quiet crop stays visually close to the parent with no conspicuous added pattern.'
    if cohort == 'fresh':
        return 'Fine repeated diagonal contrast softens around the center and the gap becomes slightly clearer. Some fine background structure and residual pattern remain.'
    return 'The edit is small. A faint diagonal remains visible around the interrupted section.'


def camera_note(name):
    if 'sky' in name:
        return 'The overcast sky looks smooth and equals the predecessor pixel for pixel.'
    if 'mesh-left' in name:
        return 'Both prior-profile outputs retain the soft restricted crossings. The new gap test does not alter any pixels.'
    if 'mesh-right' in name or 'chain-link' in name:
        return 'The preceding crossings remain visible at the same strength. Fine crossings stay incomplete and uneven.'
    return 'Fine detail and shading reproduce the preceding result pixel for pixel.'


def main():
    scores = read_json(ROOT / 'scores.json')
    audit = read_json(ROOT / 'audit.json')
    exact = read_json(ROOT / 'native/manifest.json')
    standing = read_json(checked(audit['standing']))
    assert exact['checkpoint'] == standing['checkpoint']
    assert exact['scores'] == reference(ROOT / 'scores.json')
    exact_rows = []
    for row in exact['rows']:
        boards = [copy_board(b, 'exact', exact_note(row['cohort'], b['role'])) for b in row['boards']]
        exact_rows.append(row | {'boards': boards})
    camera_rows = [copy_board(r, 'standing', camera_note(r['id'])) for r in standing['rows']]
    assert len(exact_rows) == 2 and sum(len(r['boards']) for r in exact_rows) == 6
    assert len(camera_rows) == 8
    manifest = IMAGES / 'manifest.json'
    write_json(manifest, {'exact': exact | {'rows': exact_rows}, 'standing': standing | {'rows': camera_rows},
                          'actual_native_viewing_complete': True})

    RESULTS.mkdir(parents=True, exist_ok=True)
    bundle = RESULTS / 'evidence.tar.xz'
    predecessor = ROOT.parent
    frozen = (predecessor / 'query-shape-routing-v1/routing.py',
              predecessor / 'query-checked-junctions-v1/model_delivery.py',
              predecessor / 'query-donor-bandlimit-v1/bandlimit.py',
              predecessor / 'query-donor-composition-v1/compose.py',
              predecessor / 'query-donor-composition-v1/probe.py')
    assert all(path.is_file() for path in frozen)
    patterns = ('*.py', '*.json', '*.log', 'initial/*.py', 'initial/*.log', 'native/manifest.json', 'standing/manifest.json')
    with tarfile.open(bundle, 'x:xz') as archive:
        for pattern in patterns:
            for path in sorted(ROOT.glob(pattern)):
                archive.add(path, arcname=path.relative_to(ROOT))
        for path in frozen:
            archive.add(path, arcname=Path('preceding') / path.parent.name / path.name)
    write_json(RESULTS / 'publication.json', {
        'study': 'query-shared-gap-v1', 'checkpoint': exact['checkpoint'], 'training_performed': False,
        'numeric_evaluation_complete': True, 'actual_native_viewing_complete': True,
        'cohorts': {name: cohort['summary'] for name, cohort in scores['cohorts'].items()},
        'controls': audit['outside_strong_flat_and_rotated_bitwise_controls'],
        'standing_pixel_identity': audit['native_camera_pixel_identity'],
        'numeric_source': reference(ROOT / 'scores.json'), 'audit': reference(ROOT / 'audit.json'),
        'exploratory_boundary': reference(ROOT / 'boundary.json'), 'frozen_sources': [reference(p) for p in frozen],
        'manifest': reference(manifest), 'archive': reference(bundle),
        'scope': 'Scoped automatic exterior-frequency inference with 24 additional gap-study photos and 48 replays. Both standing GFX families viewed. No full-photo or camera PSNR coverage.',
    })


if __name__ == '__main__':
    main()
