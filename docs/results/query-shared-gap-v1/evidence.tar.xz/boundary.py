"""Test a tighter edit when reserved Bayer sites support only the gap center."""
from copy import deepcopy

import numpy as np

from review import CORE,fields,luma,rms
from check import ROOT,apply,area,interior,latent,residual
from demosaic.experiments.artifacts import checked,read_json,reference,write_json


def split_evidence(raw,cfa,profile,old):
    native,_,boundary=interior(raw,cfa,profile)
    mdl=latent(native,boundary,old["geometry"])
    x,y,_,value,var,fold=native
    full=np.array(old["chosen"]["shared"]["shape"],dtype=float)
    central=full.copy()
    central[3]*=.78
    if central[0]==0:
        central[4]*=.78
    votes={"core":[],"rim":[]}
    for part in (2,3):
        valid=mdl["domain"]&(fold==part)
        narrow,_=area(x[valid],y[valid],central)
        wide,fade=area(x[valid],y[valid],full)
        taper=mdl["taper"][valid]
        v=var[valid]
        w=taper/v
        signal=mdl["g_shared"][valid,None]
        expressions={"core":-narrow*signal,"rim":-(wide-narrow)*signal}
        baseline=np.column_stack((mdl["nuisance"][valid],wide,narrow,fade))
        for key,axis in expressions.items():
            competitor=next(p for label,p in expressions.items()if label!=key)
            target=residual(axis,np.column_stack((baseline,competitor)),v,taper).ravel()
            dot=float((w*target*value[valid]).sum())
            power=float(((w*target)**2*v).sum())
            votes[key].append((dot,power))
    z={}
    for key,pairs in votes.items():
        z[key]={"both":[d/max(v,1e-20)**.5 for d,v in pairs],
                "pooled":sum(d for d,_ in pairs)/max(1e-20,sum(v for _,v in pairs))**.5}
    def allowed(p):
        return p["pooled"]>=2 and min(p["both"])>0
    if allowed(z["rim"]):
        result="full"
        gate=old
    elif allowed(z["core"]):
        result="confined"
        gate=deepcopy(old)
        gate["chosen"]["shared"]["shape"]=central.tolist()
    else:
        result="abstain"
        gate={"cut":{}}
    return gate,{"route":result,"core":z["core"],"rim":z["rim"],"footprint":central.tolist()}


def main():
    source=reference(ROOT/"scores.json")
    info=read_json(checked(source))
    experiment={}
    for cohort,ledger in info["cohorts"].items():
        observed=read_json(checked(ledger["raw"]))
        plan=read_json(checked(ledger["hub"]))
        provenance=[]
        pairs_by_noise={}
        for row in observed["rows"]:
            old=row["checks"]["matching"][0]
            data,before=fields(row)
            pred=before["directional"]
            choice=old["cut"].get("shared",0)
            if choice>0:
                a,n=split_evidence(data["packed"][0],data["colors"][0],plan["profiles"][row["noise"]],old)
                trimmed=apply(before["parent"][0],pred[0],a,"shared")
            else:
                n={"route":"upstream abstention"}
                trimmed=pred[0]
            after=pred.copy()
            after[0]=trimmed
            values={k:luma(v,data)for k,v in (before|{"localized":after,"target":data["target"]}).items()
                    if k in ("parent","directional","shared","localized","target")}
            gap=data["support"][CORE]==0
            alive=data["support"][CORE]>=.97
            if not alive.any():
                alive=np.ones_like(gap)
            pair=(row,n,values,gap,alive)
            pairs_by_noise.setdefault(row["noise"],[]).append(pair)
            provenance.append({"index":row["index"],"noise":row["noise"],"fit":n,
                               "significant_gap":bool(gap.any()),"present_edit_RMS":rms((values["localized"][0]-values["directional"][0])[CORE])})
        by_noise={}
        for label,rows in pairs_by_noise.items():
            choices=[item for item in rows if item[3].any()]
            def gap_added(v,g):
                return rms((v[0]-v[1])[CORE][g])
            want=float(np.mean([gap_added((t["localized"][0],t["parent"][0]),g)for _,_,t,g,_ in choices]))
            def test(scale):
                return float(np.mean([gap_added((t["directional"][0]+scale*(t["shared"][0]-t["directional"][0]),t["parent"][0]),g)
                                      for _,_,t,g,_ in choices]))
            lower,upper=0.,1.
            target_bound=want<=test(0)+1e-9 and want>=test(1)-1e-9
            if target_bound:
                for _ in range(40):
                    mid=.5*(lower+upper)
                    if test(mid)<want:
                        upper=mid
                    else:
                        lower=mid
                gain=.5*(lower+upper)
            else:
                gain=None
            measures={key:{"gap_added":[],"gap_error":[],"intact_change":[],"intact_increment_error":[],"response":[]} 
                      for key in ("directional","shared","localized","matched_uniform")if key!="matched_uniform"or gain is not None}
            for row,notes,t,g,a in choices:
                expected=(t["target"][0]-t["target"][1])[CORE]
                for key in measures:
                    score=t[key]if key!="matched_uniform"else t["directional"]+gain*(t["shared"]-t["directional"])
                    inc=(score[0]-score[1])[CORE]
                    fields_={"gap_added":gap_added((score[0],t["parent"][0]),g),
                            "gap_error":rms((score[0]-t["target"][0])[CORE][g]),
                            "intact_change":rms((score[0]-t["directional"][0])[CORE][a]),
                            "intact_increment_error":rms((inc-expected)[a]),
                            "response":float(100*inc[a]@expected[a]/(expected[a]@expected[a]))}
                    for name,val in fields_.items():
                        measures[key][name].append(val)
            by_noise[label]={"matched_uniform_scale":gain,"metrics":{k:{q:float(np.mean(v))for q,v in m.items()}
                                                                  for k,m in measures.items()}}
        experiment[cohort]={"rows":provenance,"by_noise":by_noise}
    write_json(ROOT/"boundary.json",{"driver":reference(__file__),"comparison_source":source,"controls":experiment,
        "scope":"Exploratory replay after the primary evaluation. Requires positive fixed confirmation for a core or a rim. Uniform attenuation control matches the mean true-gap addition on the same cohort using exact support."})


if __name__=="__main__":
    main()
