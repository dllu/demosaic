"""Test a follow-up that changes the weak correction at a fixed stronger correction."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from pool_phase import OUT
from capture_envelope import RAW
from weak_only_pool import METHODS, WeakOnly, apply, nominal_peaks
from score_envelope import FIXED, ROI, Measure, arrays, display, native_board
from review_pool import PRIMARY, GAP, FALSE, INTACT, FLAT, METRICS, interval, source_bootstrap, section
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LABELS={"parent":"Local 50k","planar":"Fixed combined","weak_pool":"Pool weaker direction","v120":"V120 EMA"}


def evaluate(fixture, captures, source, selected, plan, folder, weights=None):
    geo=fixture["geometry"]|{"warp":fixture["warp"]}
    rows=[]
    for read,old,outer in zip(captures["warped"],source["states"]["warped"],captures["straight"],strict=True):
        f=arrays(read["input"])
        scene=arrays(outer["input"])["scene_packed"]
        p=f["local50k"]
        roi=(176,176,160,160)
        freq=nominal_peaks(scene,f["colors"],roi,48)
        geometry_guard=None if freq is None else WeakOnly(*roi[:2],f["colors"],freq)
        common=p.copy()
        parts={k:np.zeros_like(p) for k in METHODS}
        rank=[]
        for i,value in enumerate(f["packed"]):
            scene[RAW]=value
            base,broad,plain,pool,info=apply(
                p[i],ROI,scene,roi,geometry_guard,plan["noise"],f["wb"],f["matrix"],
            )
            section(common[i],*ROI)[:]=base+broad
            for method,wave in zip(METHODS,(plain,pool),strict=True):
                section(parts[method][i],*ROI)[:]=wave
            rank.append(info)
        test=Measure(f,geo)
        nominal={k:common+v for k,v in parts.items()}
        metrics={k:test(v,p) for k,v in nominal.items()}
        metrics["parent"]=test(p,p)
        metrics["shared"]=test(common,p)
        np.testing.assert_allclose([metrics["planar"][k] for k in metrics["planar"]],
                                   [old["scores"]["planar"][k] for k in metrics["planar"]],
                                   atol=.0002,rtol=0)
        if weights is None:
            matched={}
        else:
            matched={k:test(common+parts[k]*weights[k],p) for k in METHODS}
            metrics["v120"]=test(f["v120"],p)
        view=None
        if fixture["index"] in selected and read["draw"]==0:
            attrs={k:f[k][None] for k in ("colors","wb","matrix")}
            attrs["packed"]=f["packed"][:1]
            native=(p,nominal["planar"],nominal["weak_pool"],f["v120"])
            frames=[noisy_malvar(attrs)[0],*(v[0] for v in native),f["target"][0]]
            view=native_board(folder,fixture["id"]+"-weak",frames,attrs,{
                "input":read["input"],"source":fixture,"query":plan["query"],"weights":plan["weights"],
                "optical_sigma":plan["sigma"],"noise":plan["noise"],
            },labels=["Noisy Malvar",*LABELS.values(),"Exact GT"],triplet_indices=(0,3,5))
        rows.append({"id":fixture["id"],"input":read["input"],"draw":read["draw"],
                     "nominal":metrics,"matched":matched,"candidate":rank,"native":view})
    return {"id":fixture["id"],"family":geo["family"],"fixture":fixture,"draws":rows}


def standing(plan, folder):
    source=reference(FIXED)
    bind=read_json(checked(source))
    assert bind["checkpoints"]["local50k"]==plan["weights"]["local50k"]
    results=[]
    for r in bind["standing"]:
        f=arrays(r["input"])
        p=np.load(checked(r["predictions"]["local50k"]),allow_pickle=False)[0]
        raw,colors,wb,matrix=(f[k][0] for k in ("packed","colors","wb","matrix"))
        roi=tuple(r["local_ROI"])
        freq=nominal_peaks(raw,colors,roi,16)
        guard=None if freq is None else WeakOnly(*roi[:2],colors,freq)
        target,high,lo,pool,info=apply(p,roi,raw,roi,guard,r["noise"],wb,matrix)
        results.append({
            "id":r["id"],"raw":r["raw"],"noise":r["noise"],"ROI":r["global_ROI"],"candidate":info,
            "RMS_change_from_planar":float(np.sqrt(np.mean((pool.astype(float)-lo)**2))*65535),
            "native":[],
        })
        for v in r["displays"]:
            prior=v["board"]
            exposure=v["exposure"]
            with Image.open(checked(prior["image"])) as im:
                base=np.asarray(im)
            frames={}
            for item in prior["panels"]:
                x,y,w,h=item["png_xywh"]
                frames[item["name"]]=base[y:y+h,x:x+w]
            np.testing.assert_array_equal(display(target,wb,matrix,exposure),frames["Local 50k"])
            views=[(k,frames[k]) for k in ("Noisy (Malvar)","V120 EMA","Corpus 100k","Local 50k")]
            views += [(LABELS["planar"],display(target+high+lo,wb,matrix,exposure)),
                      (LABELS["weak_pool"],display(target+high+pool,wb,matrix,exposure))]
            views.extend((k,frames[k]) for k in ("ISO100 AHD reference","ISO6400 camera JPEG","ISO100 camera JPEG")
                         if k in frames)
            pic=Image.new("RGB",(8+168*len(views),192),"#eeeeee")
            painter=ImageDraw.Draw(pic)
            for i,(key,px) in enumerate(views):
                x=8+168*i
                pic.paste(Image.fromarray(px),(x,24))
                painter.text((x,5),key,fill="black")
            out=folder/f'{r["id"]}-x{exposure:g}-weak.png'
            pic.save(out)
            results[-1]["native"].append({"image":reference(out),"columns":len(views),"exposure":exposure,
                                          "reference":prior})
    return {"standing":source,"rows":results}


def summarize(rows):
    sums={}
    for variant in ("nominal","matched"):
        stats={}
        rng=np.random.default_rng(202611200154)
        for key in METRICS:
            values=[]
            for row in rows:
                groups=[r[variant] for r in row["draws"]]
                if not all(key in g["planar"] for g in groups):
                    continue
                d=np.mean([g["weak_pool"][key]-g["planar"][key] for g in groups])
                values.append({"family":row["family"],"delta":d})
            ix=source_bootstrap(values,rng)
            stats[key]={"n":len(values),"difference":interval(np.asarray([r["delta"] for r in values])[ix].mean(1))}
        sums[variant]=stats
    return sums


def main():
    torch.set_num_threads(2)
    start=time.monotonic()
    prior_ref=reference(OUT/"review.json")
    prior=read_json(checked(prior_ref))
    input_binding=prior["captures"]
    inputs=read_json(checked(input_binding))
    plan=read_json(checked(inputs["plan"]))
    folder=OUT/"weak-only"
    folder.mkdir(exist_ok=True)
    exact=folder/"exact"
    real=folder/"standing"
    exact.mkdir(exist_ok=True)
    real.mkdir(exist_ok=True)
    old={r["id"]:r for r in prior["confirmation"]}
    lock=read_json(checked(prior["gain_lock"]))
    old|={r["id"]:r for r in lock["calibration"]}
    calibration=[]
    for photo,data in zip(plan["cases"],inputs["rows"],strict=True):
        if photo["split"]=="calibration":
            calibration.append(evaluate(photo,data["observations"],old[photo["id"]],(),plan,exact))
    change={k:float(np.mean([d["nominal"][k][PRIMARY]-d["nominal"]["shared"][PRIMARY]
                            for p in calibration for d in p["draws"]])) for k in METHODS}
    middle=min(change.values())/2
    assert middle>0
    gains={k:middle/v for k,v in change.items()}
    frozen=folder/"fit.json"
    write_json(frozen,{"driver":reference(__file__),"inputs":input_binding,"gains":gains,
                        "calibration":calibration,"increments":change,"after_initial_review":prior_ref})
    confirmed=[]
    for photo,data in zip(plan["cases"],inputs["rows"],strict=True):
        if photo["split"]=="confirmation":
            confirmed.append(evaluate(photo,data["observations"],old[photo["id"]],plan["native_indices"],plan,exact,gains))
    output={"driver":reference(__file__),"operation":reference(__import__("weak_only_pool").__file__),"prior":prior_ref,
            "fit":reference(frozen),"confirmation":confirmed,"summary":summarize(confirmed),
            "standing":standing(plan,real),"seconds":time.monotonic()-start,
            "scope":"Exploratory follow-up on the same held-out warped photo backgrounds."}
    write_json(folder/"result.json",output)
    print(output["summary"],flush=True)


if __name__=="__main__":
    main()
