"""Compare blind templates directly with the isolated clean weak fundamental."""

import time

import numpy as np
import torch

from pool_phase import CORE, GRID, OUT, OFFSET, SIZE, SPACING, WIDTH, provider, unpack
from capture_envelope import OUT as ENVELOPE, RAW
from warped_wire import phase_shift
from score_envelope import arrays, interval, source_bootstrap, support_for_scoring
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

AXIS=np.arange(SIZE,dtype=np.float32)+32-127.5
Y,X=np.meshgrid(AXIS,AXIS,indexing="ij")
LABELS=("planar","isotropic","oriented","quarter_cycle")


def truth_phase(geometry):
    shift=phase_shift(torch.from_numpy(X),torch.from_numpy(Y),geometry).numpy()
    x,y=geometry["frequency"][1]
    p=2*np.pi*(x*X+y*Y)+geometry["phase"][1]+shift
    return np.cos(p).astype(np.float64)


def correlation(a,b):
    x=a-a.mean()
    y=b-b.mean()
    return float(x@y/max(1e-12,np.linalg.norm(x)*np.linalg.norm(y)))


def panel(fixture, raw, seen, noise, state):
    geometry=fixture["geometry"]
    if state=="warped":
        geometry = geometry|{"warp":fixture["warp"]}
    guide=truth_phase(geometry)
    context=seen.copy()
    box=(176,176,160,160)
    operator=provider(context,raw["colors"],box,48)
    if operator is None:
        return None
    context[RAW]=raw["packed"][0]
    data=unpack(context)[160:352,160:352].astype(np.float64)
    m=support_for_scoring(raw["support"])[32:224,32:224]
    eligible=[(y,x) for y,x in GRID
              if y>=16 and y<=112 and x>=16 and x<=112 and
              (m[y+OFFSET:y+OFFSET+WIDTH,x+OFFSET:x+OFFSET+WIDTH]>=.97).mean()>=.75]
    if not eligible:
        return None
    rows=[]
    for l,r in (operator.planar.positions,operator.planar.positions[::-1]):
        template=operator.guides(data,l,noise)
        for y,x in eligible:
            sl=np.s_[y+OFFSET:y+OFFSET+WIDTH,x+OFFSET:x+OFFSET+WIDTH]
            chosen=m[sl]>=.97
            target=guide[sl][chosen]
            measured=operator.fold(data,template,l,r,noise["shot"],noise["read"],y,x)
            params,alternatives=measured[1]
            z=params[2]/max(1e-12,np.linalg.norm(params[2]))
            baseline=(operator.planar.waves[CORE][...,1,:]@z)[chosen]
            actual={k:correlation(a[3][CORE][chosen],target) for k,a in alternatives.items()}
            actual["planar"]=correlation(baseline,target)
            rows.append(actual)
    return {"n_windows":len(rows),"mean":{k:float(np.mean([r[k] for r in rows])) for k in LABELS}}


def main():
    torch.set_num_threads(2)
    start=time.monotonic()
    capture_ref=reference(ENVELOPE/"inputs.json")
    capture=read_json(checked(capture_ref))
    plan=read_json(checked(capture["plan"]))
    results=[]
    for fixture,r in zip(plan["cases"],capture["rows"],strict=True):
        if fixture["split"]!="confirmation":
            continue
        rows={}
        for name,draws in r["observations"].items():
            values=[]
            for i,p in enumerate(draws):
                original=arrays(r["observations"]["straight"][i]["input"])["scene_packed"]
                f=arrays(p["input"])
                values.append(panel(fixture,f,original,plan["noise"],name))
            rows[name]=values
        results.append({"id":fixture["id"],"family":fixture["geometry"]["family"],"states":rows})
    summary={}
    rng=np.random.default_rng(202611200152)
    for state in ("straight","warped"):
        ordered=[]
        for r in results:
            valid=[p for p in r["states"][state] if p is not None]
            if valid:
                ordered.append({"family":r["family"],"avg":np.mean([
                    [d["mean"][k] for k in LABELS] for d in valid
                ],axis=0)})
        ix=source_bootstrap(ordered,rng)
        values=np.array([r["avg"] for r in ordered])[ix].mean(1)
        summary[state]={"sources":len(ordered),"mean":{k:interval(values[:,i]) for i,k in enumerate(LABELS)},
                        "versus_planar":{k:interval(values[:,i]-values[:,0])
                                         for i,k in enumerate(LABELS) if i}}
    write_json(OUT/"phase-audit.json",{"inputs":capture_ref,"driver":reference(__file__),
                                      "summary":summary,"rows":results,"seconds":time.monotonic()-start})
    print(summary,flush=True)


if __name__=="__main__":
    main()
