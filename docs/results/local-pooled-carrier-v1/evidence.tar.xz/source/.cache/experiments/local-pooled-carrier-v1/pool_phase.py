"""Fit a spatial phase guide on a single green lattice and verify its local use."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import map_coordinates

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("local-carrier-envelope-v1")))
from carrier_envelope import Envelope, GRID, CORE, LIMITS, nominal_peaks, sample, strength, unpack
from center_guard import improvement, variance
from review_raw import box_wave, nuisance, planes
from ring_refit import EDGE, GAIN, OFFSET, OUTER, TAPER, WIDTH

DELIVERY = 160
SIZE = DELIVERY + 2 * OFFSET
SPACING = 24
NODES = SIZE // SPACING
REG = .50
EDGE_POW = 4
METHODS = ("planar", "isotropic", "oriented", "quarter_cycle")
FIELD_METHODS = METHODS[1:]

GRID_XY = tuple((y,x) for y in range(NODES) for x in range(NODES))
QY,QX=np.meshgrid(np.arange(SIZE),np.arange(SIZE),indexing="ij")
INTERP = (np.stack((QY,QX)) - (SPACING-1)/2)/SPACING


def laplacian(frequency, oriented):
    slopes=[]
    for direction in frequency:
        f=np.asarray(direction)
        tangent=np.array([-f[1],f[0]])/np.linalg.norm(f)
        degree=np.zeros((len(GRID_XY),len(GRID_XY)))
        for y,x in GRID_XY:
            a=y*NODES+x
            for dy,dx in ((0,1),(1,-1),(1,0),(1,1)):
                yy,xx=y+dy,x+dx
                if not (0<=yy<NODES and 0<=xx<NODES):
                    continue
                b=yy*NODES+xx
                e=np.asarray([dx,dy])/np.hypot(dx,dy)
                d=.24+1.76*float(tangent@e)**EDGE_POW if oriented else 1.
                w=d/np.hypot(dx,dy)
                degree[a,a]+=w
                degree[b,b]+=w
                degree[a,b]-=w
                degree[b,a]-=w
        slopes.append(degree)
    return slopes


class Proposals:
    def __init__(self, x, y, colors, frequency):
        self.origin=(x-OFFSET,y-OFFSET)
        self.frequency=frequency
        pairs=planes(np.asarray(colors),(x,y,WIDTH))
        self.planar=Envelope(colors,x,y,frequency)
        self.wave=box_wave((0,0,SIZE),((SIZE-1)/2,)*2,frequency)
        self.L={"isotropic":laplacian(frequency,False),"oriented":laplacian(frequency,True)}
        self.local={}
        shape=nuisance(SPACING,"cosine")
        self.parent_bases={}
        self.parent_held={}
        cosine=nuisance(OUTER,"cosine")
        planar_wave=self.planar.waves
        for d in range(2):
            base=np.concatenate((cosine,planar_wave[...,1-d,:]),axis=-1).reshape(OUTER**2,-1)
            self.parent_bases[d]=base
            self.parent_held[d]=np.linalg.pinv(base,rcond=1e-8)
        for axis in pairs:
            spaces=[]
            for yy,xx in GRID_XY:
                sy,sx=yy*SPACING,xx*SPACING
                fields=self.wave[sy:sy+SPACING,sx:sx+SPACING]
                joined=np.concatenate((shape,fields.reshape(SPACING,SPACING,4)),axis=-1)
                design=sample(joined,axis).reshape(-1,joined.shape[-1])
                gram=design.T@design
                inv=np.linalg.pinv(gram,rcond=1e-9)
                result=(inv@design.T)[-4:].reshape(2,2,-1)
                # Marginal carrier variance, including the competing wave and smooth nuisance.
                information=np.reciprocal(np.diag(inv)[-4:]).reshape(2,2).mean(-1)
                spaces.append((result,information))
            self.local[axis]=spaces

    def guides(self, raw, axis, noise):
        nodes,info=[],[]
        for (yy,xx),(op,cov) in zip(GRID_XY,self.local[axis],strict=True):
            y,x=yy*SPACING,xx*SPACING
            values=sample(raw[y:y+SPACING,x:x+SPACING],axis).ravel()
            nodes.append(op@values)
            info.append(cov/variance(values,noise["shot"],noise["read"]))
        nodes=np.asarray(nodes)
        info=np.asarray(info)
        templates={}
        for name, mat in self.L.items():
            fits=[]
            for d,L in enumerate(mat):
                p=info[:,d]
                regularizer=REG*np.median(p)
                z=np.linalg.solve(np.diag(p)+regularizer*L,p[:,None]*nodes[:,d])
                interp=np.stack([map_coordinates(z[:,i].reshape(NODES,NODES),INTERP,order=1,mode="nearest")
                                 for i in (0,1)],axis=-1)
                norm=np.linalg.norm(interp,axis=-1,keepdims=True).clip(min=1e-12)
                fits.append(interp/norm)
            templates[name]=np.stack(fits,axis=2)
        field=templates["oriented"]
        rotated=np.stack((-field[...,1],field[...,0]),axis=-1)
        templates["quarter_cycle"]=rotated
        return {k:np.sum(v*self.wave,axis=-1) for k,v in templates.items()}

    @staticmethod
    def project(split, field, lattice, held):
        a,b=(sample(field,p).ravel() for p in (lattice,held))
        nuisance_coef=split.inverse@a
        da=a-split.train_background@nuisance_coef
        db=b-split.held_background@nuisance_coef
        return da,db

    def fold(self, raw, guide, lattice, held, shot, read, dy, dx):
        region=np.s_[dy:dy+OUTER,dx:dx+OUTER]
        tile=raw[region]
        a,b=(sample(tile,t).ravel() for t in (lattice,held))
        c,d=(sample(tile[CORE],t).ravel() for t in (lattice,held))
        broad_var,center_var=variance(a,shot,read),variance(c,shot,read)
        pack=[]
        for idx,(broad, narrow, plain, _, _) in enumerate(self.planar.fitting[lattice]):
            e, hold=broad.errors(a,b)
            _, middle=narrow.errors(c,d)
            coeff=plain@(broad.train_wave[:,:2].T@e)
            base_r=improvement(hold,broad.held_wave[:,:2]@coeff,broad_var)
            base_c=improvement(middle,narrow.held_wave[:,:2]@coeff,center_var)
            options={}
            for k,v in guide.items():
                tmpl=v[region][...,idx]
                ta,tb=self.project(broad,tmpl,lattice,held)
                _,tc=self.project(narrow,tmpl[CORE],lattice,held)
                amp=max(0.,float(ta@e/max(1e-12,ta@ta)))
                r=improvement(hold,tb*amp,broad_var)
                q=improvement(middle,tc*amp,center_var)
                options[k]=(r,q,amp,tmpl)
            pack.append(((base_r,base_c,coeff),options))
        return pack

    def candidate_delta(self, direction, parent, choices, gain):
        refined=[]
        for _,_,amp,f in choices:
            t=f.ravel()
            dc=t-self.parent_bases[direction]@(self.parent_held[direction]@t)
            old=dc@parent.ravel()/max(1e-12,dc@dc)
            delta=float(np.clip(gain*(amp-old),-amp,amp))
            refined.append(f[CORE]*delta)
        return np.mean(refined,axis=0)

    def patch(self, raw, pool, parent, shot, read, y, x):
        first,second=(self.fold(raw,pool[l],l,r,shot,read,y,x)
                      for l,r in (self.planar.positions,self.planar.positions[::-1]))
        parent_pairs=(self.planar.own_planar@parent.ravel()).reshape(2,2)
        wave=self.planar.waves[CORE]
        out={k:np.zeros((WIDTH,WIDTH)) for k in METHODS}
        stats={k:[0,0] for k in METHODS}
        admits={k:[0,0] for k in METHODS}
        for i,((f,op),(g,rival)) in enumerate(zip(first,second,strict=True)):
            broad=min(f[0],g[0])
            narrow=min(f[1],g[1])
            base_gain=min(strength(broad,LIMITS["broad"]),strength(narrow,LIMITS["center"]))
            est=(f[2]+g[2])/2
            correction=base_gain*(est-parent_pairs[i])
            correction*=min(1.,np.linalg.norm(est)/max(1e-12,np.linalg.norm(correction)))
            baseline=wave[...,i,:]@correction
            out["planar"]+=baseline
            admits["planar"][i]=int(base_gain>0)
            for k in FIELD_METHODS:
                a,b=op[k],rival[k]
                gain=min(strength(min(a[0],b[0]),LIMITS["broad"]),
                         strength(min(a[1],b[1]),LIMITS["center"]))
                eligible=gain>0 and (
                    a[0]>f[0]+1.0 and b[0]>g[0]+1.0
                    and a[1]>f[1]+.2 and b[1]>g[1]+.2
                )
                if eligible:
                    out[k]+=self.candidate_delta(i,parent,(a,b),gain)
                else:
                    out[k]+=baseline
                admits[k][i]=int(eligible or base_gain>0)
                stats[k][i]=int(eligible)
        return out,stats,admits

    def apply(self,parent,local,raw,noise,wb,matrix):
        x,y,w,h=local
        target=parent[...,y:y+h,x:x+w]
        assert (w,h)==(DELIVERY,DELIVERY)
        in_frame=parent[1,y-OFFSET:y+h+OFFSET,x-OFFSET:x+w+OFFSET]
        assert raw.shape==in_frame.shape==(SIZE,SIZE)
        pool={l:self.guides(raw,l,noise) for l in self.planar.positions}
        frame={k:np.zeros((h,w)) for k in METHODS}
        mass=np.zeros((h,w))
        count={k:np.zeros(2,dtype=np.int32) for k in METHODS}
        allowed={k:np.zeros(2,dtype=np.int32) for k in METHODS}
        for dy,dx in GRID:
            parent_tile=in_frame[dy:dy+OUTER,dx:dx+OUTER]
            values,stats,admits=self.patch(raw,pool,parent_tile,noise["shot"],noise["read"],dy,dx)
            sl=np.s_[dy:dy+WIDTH,dx:dx+WIDTH]
            for k,part in values.items():
                frame[k][sl]+=TAPER*part
                count[k]+=stats[k]
                allowed[k]+=admits[k]
            mass[sl]+=TAPER
        neutral=np.linalg.solve(matrix,np.ones(3))/wb
        neutral/=neutral[1]
        for k,part in frame.items():
            wave=part/np.maximum(.02,mass)*EDGE[:,None]*EDGE[None,:]
            frame[k]=target+(GAIN*neutral[:,None,None]*wave).astype(target.dtype)
        return frame,{k:v.tolist() for k,v in count.items()},{k:v.tolist() for k,v in allowed.items()}


def provider(scene, colors, roi, clearance):
    peak=nominal_peaks(scene,colors,roi,clearance)
    return Proposals(*roi[:2],colors,peak) if peak is not None else None


def apply(p, local, scene, roi, fitted, noise, wb, matrix):
    x,y,w,h=local
    if fitted is None:
        zeros={k:[0,0] for k in METHODS}
        return {k:p[...,y:y+h,x:x+w] for k in METHODS},zeros,zeros
    xx,yy=fitted.origin
    assert (xx,yy)==(roi[0]-OFFSET,roi[1]-OFFSET)
    raw=unpack(scene)[yy:yy+SIZE,xx:xx+SIZE].astype(np.float64)
    return fitted.apply(p,local,raw,noise,wb,matrix)


def independence():
    rng=np.random.default_rng(202611200147)
    for colors in ((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0)):
        op=Proposals(151,149,colors,((.114,.074),(.089,-.071)))
        data=rng.uniform(.06,.1,(SIZE,SIZE))
        profile={"shot":.00128,"read":6.5536e-6}
        for a,b in (op.planar.positions,op.planar.positions[::-1]):
            prior=op.guides(data,a,profile)
            modified=data.copy()
            modified[b[0]::2,b[1]::2]=rng.uniform(.04,.15,(SIZE//2,SIZE//2))
            check=op.guides(modified,a,profile)
            for k in prior:
                np.testing.assert_array_equal(prior[k],check[k])
            before=op.fold(data,prior,a,b,profile["shot"],profile["read"],32,48)
            after=op.fold(modified,check,a,b,profile["shot"],profile["read"],32,48)
            changed = False
            for f,g in zip(before,after,strict=True):
                for k in prior:
                    assert f[1][k][2]==g[1][k][2]
                    changed |= f[1][k][:2]!=g[1][k][:2]
            assert changed
