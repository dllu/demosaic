"""Keep the stronger planar correction while testing a pooled weaker phase."""

import numpy as np

from pool_phase import (GRID, GRID_XY, LIMITS, CORE, EDGE, GAIN, OFFSET, OUTER,
                        SPACING, SIZE, TAPER, WIDTH, Proposals, nominal_peaks, sample, strength, unpack, variance)

METHODS = ("planar", "weak_pool")


def weak_lattice(operator, raw, lattice, noise):
    powers=[]
    for (yy,xx),(fit,information) in zip(GRID_XY,operator.local[lattice],strict=True):
        y,x=yy*SPACING,xx*SPACING
        values=sample(raw[y:y+SPACING,x:x+SPACING],lattice).ravel()
        coeff=fit@values
        var=variance(values,noise["shot"],noise["read"])
        energies=np.sum(coeff*coeff,axis=-1)-2*var/information
        powers.append(energies)
    power=np.maximum(0.,np.median(powers,axis=0))
    strongest=int(np.argmax(power))
    passed=power[strongest]>max(1e-12,1.25*power[1-strongest])
    return 1-strongest if passed else None, power.tolist()


class WeakOnly(Proposals):
    def fit(self, raw, noise):
        a,b=self.planar.positions
        first,left=weak_lattice(self,raw,a,noise)
        second,right=weak_lattice(self,raw,b,noise)
        choice=first if first==second else None
        return choice, (left,right)

    def dispatch(self, raw, pool, parent, shot, read, y, x, weak):
        first,second=(self.fold(raw,pool[l],l,r,shot,read,y,x)
                      for l,r in (self.planar.positions,self.planar.positions[::-1]))
        parent_pairs=(self.planar.own_planar@parent.ravel()).reshape(2,2)
        waves=self.planar.waves[CORE]
        full=np.zeros((2,WIDTH,WIDTH))
        replace=np.zeros((WIDTH,WIDTH))
        passes=0
        for idx,((f,opts),(g,rivals)) in enumerate(zip(first,second,strict=True)):
            broad=min(f[0],g[0])
            narrow=min(f[1],g[1])
            base_gain=min(strength(broad,LIMITS["broad"]),strength(narrow,LIMITS["center"]))
            est=(f[2]+g[2])/2
            correction=base_gain*(est-parent_pairs[idx])
            correction*=min(1.,np.linalg.norm(est)/max(1e-12,np.linalg.norm(correction)))
            baseline=waves[...,idx,:]@correction
            full[idx]=baseline
            if idx!=weak:
                continue
            a,b=opts["isotropic"],rivals["isotropic"]
            gain=min(strength(min(a[0],b[0]),LIMITS["broad"]),
                     strength(min(a[1],b[1]),LIMITS["center"]))
            passes=int(gain>0 and
                       a[0]>f[0]+1. and b[0]>g[0]+1. and a[1]>f[1]+.2 and b[1]>g[1]+.2)
            replace=self.candidate_delta(idx,parent,(a,b),gain) if passes else baseline
        if weak is None:
            return full.sum(0), np.zeros_like(replace), np.zeros_like(replace), 0
        return full[1-weak], full[weak], replace, passes

    def capture(self,parent,roi,raw,noise,wb,matrix):
        x,y,w,h=roi
        parent_view=parent[...,y:y+h,x:x+w]
        extra=parent[1,y-OFFSET:y+h+OFFSET,x-OFFSET:x+w+OFFSET]
        assert extra.shape==raw.shape==(SIZE,SIZE)
        weak,terms=self.fit(raw,noise)
        pool={l:{"isotropic":self.guides(raw,l,noise)["isotropic"]} for l in self.planar.positions}
        strong,original,new,blend=(np.zeros((160,160)) for _ in range(4))
        hits=0
        for dy,dx in GRID:
            parent_tile=extra[dy:dy+OUTER,dx:dx+OUTER]
            a,b,c,n=self.dispatch(raw,pool,parent_tile,noise["shot"],noise["read"],dy,dx,weak)
            area=np.s_[dy:dy+WIDTH,dx:dx+WIDTH]
            hits+=n
            for frame,v in zip((strong,original,new), (a,b,c), strict=True):
                frame[area]+=TAPER*v
            blend[area]+=TAPER
        neutral=np.linalg.solve(matrix,np.ones(3))/wb
        neutral/=neutral[1]
        factor=GAIN*EDGE[:,None]*EDGE[None,:]/np.maximum(.02,blend)
        neutral=neutral[:,None,None]*factor
        return (parent_view, (neutral*strong).astype(parent_view.dtype),
                (neutral*original).astype(parent_view.dtype), (neutral*new).astype(parent_view.dtype),
                {"weak_direction":weak,"chosen":hits,"median_noise_subtracted_power":terms})


def apply(p,roi,scene,sample_box,op,noise,wb,matrix):
    x,y,w,h=roi
    if op is None:
        piece=p[...,y:y+h,x:x+w]
        blank=np.zeros_like(piece)
        return piece,blank,blank,blank,{"weak_direction":None,"chosen":0,"median_noise_subtracted_power":None}
    xx,yy=op.origin
    assert (xx,yy)==(sample_box[0]-OFFSET,sample_box[1]-OFFSET)
    raw=unpack(scene)[yy:yy+SIZE,xx:xx+SIZE].astype(np.float64)
    return op.capture(p,roi,raw,noise,wb,matrix)
