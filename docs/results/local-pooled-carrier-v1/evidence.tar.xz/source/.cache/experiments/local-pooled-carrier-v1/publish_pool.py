"""Preserve paired phase-pooling measurements and their native image figures."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from pool_phase import HERE, OUT
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

REPO=HERE.parents[2]


def main():
    keys=("review","phase-audit","analysis","analysis-v2","gain-lock")
    refs={k:reference(OUT/f"{k}.json") for k in keys}
    run, audit, initial, updated, locked=(read_json(checked(refs[k])) for k in keys)
    folder=OUT/"weak-only"
    weak={k:reference(folder/f"{k}.json") for k in ("result","fit","secondary")}
    changed, fit, confirmed=(read_json(checked(weak[k])) for k in ("result","fit","secondary"))
    assert changed["prior"]==confirmed["replay"]==fit["after_initial_review"]==refs["review"]
    assert changed["fit"]==weak["fit"] and confirmed["followup"]==weak["result"]
    assert len(changed["confirmation"])==20 and len(confirmed["rows"])==32
    assert confirmed["summary"]["present_direction_rank"]=={"1":64}
    assert run["policy"]==refs["analysis-v2"] and updated["initial"]==refs["analysis"]
    assert run["gain_lock"]==refs["gain-lock"] and run["captures"]==locked["inputs"]==audit["inputs"]
    assert updated["preexisting_inputs"]==initial["preexisting_inputs"]==run["captures"]
    assert len(run["confirmation"])==len(audit["rows"])==20
    assert len(locked["calibration"])==12 and len(run["secondary"]["rows"])==32
    assert len(run["standing"]["rows"])==8
    selected=[d["native"] for r in run["confirmation"] for d in r["states"]["warped"] if d["native"]]
    captured=[d for row in run["standing"]["rows"] for d in row["native"]]
    assert len(selected)==2 and len(captured)==12
    natives=[(r[k]["image"],n) for r in selected for k,n in (("triplet",3),("board",8))]
    natives.extend((v["image"],v["columns"]) for v in captured)
    new_exact=[d["native"] for r in changed["confirmation"] for d in r["draws"] if d["native"]]
    new_real=[d for r in changed["standing"]["rows"] for d in r["native"]]
    assert len(new_exact)==2 and len(new_real)==12
    natives.extend((r[k]["image"],n) for r in new_exact for k,n in (("triplet",3),("board",6)))
    natives.extend((d["image"],d["columns"]) for d in new_real)
    dest=REPO/"docs/results"/HERE.name
    assets=REPO/"docs/assets"/HERE.name
    dest.mkdir()
    assets.mkdir()
    images=[]
    for ref,n in natives:
        original=checked(ref)
        with Image.open(original) as f:
            assert f.size==(8+168*n,192)
        fp=assets/original.name
        shutil.copyfile(original,fp)
        assert reference(fp)["sha256"]==ref["sha256"]
        images.append({"path":str(fp.relative_to(REPO)),"sha256":ref["sha256"]})
    archive=dest/"evidence.tar.xz"
    initial_driver=HERE/"review_pool_initial.py"
    assert reference(initial_driver)["sha256"]==initial["source"]["sha256"]
    bind=[run["driver"],audit["driver"],updated["implementation"],reference(initial_driver),reference(__file__)]
    bind += [reference(HERE.with_name("local-carrier-envelope-v1")/n) for n in ("carrier_envelope.py","score_envelope.py")]
    bind.extend((changed["driver"], changed["operation"], confirmed["driver"]))
    with tarfile.open(archive,"x:xz",preset=3) as tar:
        for ident,ref in refs.items():
            tar.add(checked(ref),arcname=f"receipts/{ident}.json",recursive=False)
        for ident,ref in weak.items():
            tar.add(checked(ref),arcname=f"receipts/weak-only/{ident}.json",recursive=False)
        for ref in bind:
            fp=checked(ref)
            tar.add(fp,arcname="source/"+str(fp.relative_to(REPO)),recursive=False)
    write_json(dest/"publication.json",{
        "review":refs["review"],"phase_audit":refs["phase-audit"],"calibration":refs["gain-lock"],
        "archive":{"path":str(archive.relative_to(REPO)),"sha256":reference(archive)["sha256"]},
        "weights":run["weights"],"prior_replay_groups":{"calibration":12,"straight_warped":20,"secondary":32},
        "score_wall_seconds":run["seconds"],"phase_audit_wall_seconds":audit["seconds"],"matches":locked["amounts"],
        "paired":run["paired"],"activity":run["activity"],"secondary":{
            k:run["secondary"][k] for k in ("summary","activity")},
        "weak_only":{"bindings":weak,"fit":fit["gains"],"warped":changed["summary"],
                     "secondary":confirmed["summary"],"standing":[{"id":r["id"],
                     "rank":r["candidate"],"RMS_from_planar":r["RMS_change_from_planar"]} for r in changed["standing"]["rows"]]},
        "template_fit":audit["summary"],"native_figures_viewed":len(images),"images":images,
        "standing":{r["id"]:{k:r[k] for k in ("rms_RGB_DN16","passed","chosen")} for r in run["standing"]["rows"]},
    })


if __name__=="__main__":
    main()
