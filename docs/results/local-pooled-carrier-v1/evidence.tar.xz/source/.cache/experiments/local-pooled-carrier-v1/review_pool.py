"""Replay phase pooling on bound optical inputs, secondary photos and GFX crops."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from pool_phase import METHODS, FIELD_METHODS, apply, independence, provider, OUT
from capture_envelope import OUT as ENVELOPE, NESTED, RAW, STATES
from score_envelope import Measure
from warped_wire import phase_shift
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_ring import FIXED, ROI, arrays, display, interval, native_board, source_bootstrap, support_for_scoring
from scoring import luma, remove_basis, space, wire_bases
from score_center_guard import section
from nested_gate import apply as nested_control

PRIMARY = "weak_response"
GAP = "continuing_RMS_DN16"
FALSE = "weak_gap_band_RMS_DN16"
INTACT = "intact_fundamental_RMS_DN16"
FLAT = "flat_core_RMS_DN16"
METRICS = (PRIMARY,GAP,FALSE,INTACT,FLAT,"weak_quadrature_RMS_DN16","edge_added_RMS_DN16","uniform_added_RMS_DN16")
LABELS = {
    "parent":"Local 50k","planar":"Fixed combined","isotropic":"Pool evenly","oriented":"Pool along wire",
    "quarter_cycle":"Quarter-cycle control","v120":"V120 EMA",
}
GRID=(np.arange(128)-63.5).astype(np.float32)
Y,X=np.meshgrid(GRID,GRID,indexing="ij")
EVAL=np.s_[...,64:192,64:192]


def measured(data, parent, scene, noise, g, audit):
    bayer=data["colors"]
    box=(176,176,160,160)
    p=scene.copy()
    fitted=provider(p,bayer,box,48)
    corrections={k:parent.copy() for k in METHODS}
    act,flex=[],[]
    for i,crop in enumerate(data["packed"]):
        p[RAW]=crop
        out,c,a=apply(parent[i],ROI,p,box,fitted,noise,data["wb"],data["matrix"])
        if audit:
            peaks=None if fitted is None else fitted.frequency
            hand, _ = nested_control(parent[i],ROI,p,bayer,box,peaks,noise | {
                "wb":data["wb"],"matrix":data["matrix"],
            })
            np.testing.assert_allclose(out["planar"],hand["nested"],rtol=3e-7,atol=2e-8)
        for k,row in out.items():
            section(corrections[k][i],*ROI)[:]=row
        act.append(a)
        flex.append(c)
    return corrections,act,flex,Measure(data,g)


def evaluate(fixture, captures, selected, plan, gain, folder):
    result={}
    base_scene=[arrays(r["input"])["scene_packed"] for r in captures["straight"]]
    for state in STATES:
        r=[]
        geo=fixture["geometry"] if state=="straight" else fixture["geometry"]|{"warp":fixture["warp"]}
        for read in captures[state]:
            f=arrays(read["input"])
            draw=read["draw"]
            parent=f["local50k"]
            outputs,active,selected_windows,metric=measured(f,parent,base_scene[draw],plan["noise"],geo,
                                                          audit=not draw and fixture["index"] in (0,13))
            all_={"parent": parent}|outputs
            if "v120" in f:
                all_["v120"]=f["v120"]
            metrics={k:metric(v,parent) for k,v in all_.items()}
            match={}
            for key, weights in gain.get(state,{}).items():
                if weights:
                    match[key]={k:metric(parent+(outputs[k]-parent)*value,parent) for k,value in weights.items()}
            native=None
            if state=="warped" and draw==0 and fixture["index"] in selected:
                camera={k:f[k][None] for k in ("colors","wb","matrix")}
                camera["packed"]=f["packed"][:1]
                frames=[noisy_malvar(camera)[0],*(all_[k][0] for k in LABELS),f["target"][0]]
                native=native_board(folder,fixture["id"],frames,camera,{
                    "source":fixture,"input":read["input"],"geometry":geo,"noise":plan["noise"],
                    "weights":plan["weights"],"query":plan["query"],"optical_sigma":plan["sigma"],
                },labels=["Noisy Malvar",*LABELS.values(),"Exact GT"],triplet_indices=(0,4,7))
            r.append({"draw":draw,"input":read["input"],"scores":metrics,"held_donors":captures["straight"][draw]["input"],
                      "passed":active,"chosen":selected_windows,"matched":match,"native":native})
        result[state]=r
    return {"id":fixture["id"],"fixture":fixture,"family":fixture["geometry"]["family"],"states":result}


def fit_match(calibration):
    output={}
    for state in STATES:
        n=["parent",*METHODS]
        means={k:float(np.mean([d["scores"][k][PRIMARY] for r in calibration for d in r["states"][state]])) for k in n}
        response={k:v-means["parent"] for k,v in means.items() if k!="parent"}
        matched={}
        for first,second in (("planar","oriented"),("isotropic","oriented"),("planar","isotropic")):
            point=min(response[first],response[second])/2
            matched[first+"+"+second]={k:point/response[k] for k in (first,second)} if point>0 else None
        output[state]=matched
    return output


def summary(rows, states=STATES):
    out={}
    for state in states:
        by={}
        rng=np.random.default_rng(202611200139)
        pairs=[("parent",a) for a in (*METHODS,"v120")]+[("planar",k) for k in METHODS if k!="planar"]
        pairs.append(("isotropic","oriented"))
        for first,second in pairs:
            label=first+"+"+second
            report={}
            for version in ("nominal","matched"):
                change={}
                for k in METRICS:
                    chosen=[]
                    for r in rows:
                        groups=[d["scores"] if version=="nominal" else d["matched"].get(label)
                                for d in r["states"][state]]
                        if not all(g is not None and k in g[second] for g in groups):
                            continue
                        delta=np.mean([g[second][k]-g[first][k] for g in groups])
                        chosen.append({"family":r["family"],"delta":delta})
                    if chosen:
                        ix=source_bootstrap(chosen,rng)
                        vals=np.asarray([r["delta"] for r in chosen])[ix].mean(1)
                        change[k]={"n":len(chosen),"difference":interval(vals)}
                if change:
                    report[version]=change
            by[label]=report
        out[state]=by
    return out


def nulls(rows, states=STATES):
    output={}
    for state in states:
        flat={}
        for label,i in (("strong_only",1),("flat_core",2),("edge_only",3),("uniform",4)):
            group=[d for r in rows for d in r["states"][state]]
            flat[label]={
                "n":len(group),"any_pass":{k:sum(any(d["passed"][i][k]) for d in group) for k in METHODS},
                "admissions":{k: np.asarray([d["passed"][i][k] for d in group]).sum(0).tolist() for k in METHODS},
                "chosen_expansion":{k:np.asarray([d["chosen"][i][k] for d in group]).sum(0).tolist() for k in METHODS},
            }
        group=[d for r in rows for d in r["states"][state]]
        flat["present_chosen_expansion"]={k:np.asarray([d["chosen"][0][k] for d in group]).sum(0).tolist()
                                           for k in METHODS}
        output[state]=flat
    return output


def gfx(weight, folder):
    binding=reference(FIXED)
    original=read_json(checked(binding))
    assert original["checkpoints"]["local50k"]==weight
    report=[]
    for row in original["standing"]:
        f=arrays(row["input"])
        p=np.load(checked(row["predictions"]["local50k"]),allow_pickle=False)[0]
        scene, colors, wb, matrix=(f[k][0] for k in ("packed","colors","wb","matrix"))
        box=tuple(row["local_ROI"])
        fit=provider(scene,colors,box,16)
        out, flexible, count=apply(p,box,scene,box,fit,row["noise"],wb,matrix)
        crop=section(p,*box)
        rms={k:float(np.sqrt(np.mean((a.astype(float)-crop)**2))*65535) for k,a in out.items()}
        views=[]
        for display_ in row["displays"]:
            exposure, prior=display_["exposure"],display_["board"]
            with Image.open(checked(prior["image"])) as im:
                board=np.asarray(im)
            frames={}
            for descriptor in prior["panels"]:
                x,y,w,h=descriptor["png_xywh"]
                frames[descriptor["name"]]=board[y:y+h,x:x+w]
            np.testing.assert_array_equal(display(crop,wb,matrix,exposure),frames["Local 50k"])
            columns=[(k,frames[k]) for k in ("Noisy (Malvar)","V120 EMA","Corpus 100k","Local 50k")]
            columns.extend((LABELS[k],display(out[k],wb,matrix,exposure)) for k in METHODS)
            columns.extend((k,frames[k]) for k in ("ISO100 AHD reference","ISO6400 camera JPEG","ISO100 camera JPEG") if k in frames)
            native=Image.new("RGB",(8+168*len(columns),192),"#eeeeee")
            draw=ImageDraw.Draw(native)
            for i,(name,values) in enumerate(columns):
                x=8+168*i
                assert values.shape==(160,160,3)
                native.paste(Image.fromarray(values),(x,24))
                draw.text((x,5),name,fill="black")
            path=folder/f'{row["id"]}-x{exposure:g}.png'
            native.save(path)
            views.append({"image":reference(path),"columns":len(columns),"exposure":exposure,"prior":prior})
        report.append({"id":row["id"],"roi":row["global_ROI"],"noise":row["noise"],"raw":row["raw"],
                       "parent":row["predictions"]["local50k"],"input":row["input"],"native":views,
                       "rms_RGB_DN16":rms,"passed":count,"chosen":flexible})
    return {"standing_receipt":binding,"rows":report}


def secondary(amounts):
    plan_ref=reference(NESTED/"plan.json")
    data=read_json(checked(plan_ref))
    parent_ref=reference(NESTED/"parent/result.json")
    source=read_json(checked(parent_ref))
    assert source["weights"] == {k:data["checkpoints"][k] for k in ("local50k","v120")}
    rows=[]
    chosen=np.array([0,2,3,4,5])
    for fixture,inputs in zip(data["sources"],source["records"],strict=True):
        assert fixture["id"]==inputs["id"]
        geo=fixture["geometry"]
        draws=[]
        for r in inputs["streams"]:
            f=arrays(r["data"])
            for key in ("packed","variance","target"):
                f[key]=f[key][chosen]
            if geo["family"] == "smooth-dip":
                assert np.all(f["support"] > 0)
                f["support"] = np.ones_like(f["support"])
            parent=np.load(checked(r["outputs"]["local50k"]),allow_pickle=False)[chosen]
            v120=np.load(checked(r["outputs"]["v120"]),allow_pickle=False)[chosen]
            output,act,flex,measure=measured(f,parent,f["scene_packed"],data["noise"],geo,audit=False)
            pools={"parent":parent,**output,"v120":v120}
            metrics={k:measure(v,parent) for k,v in pools.items()}
            matches={
                name:{k:measure(parent+(output[k]-parent)*scale,parent) for k,scale in weights.items()}
                for name,weights in amounts["straight"].items() if weights
            }
            draws.append({"input":r["data"],"weights":r["outputs"],"scores":metrics,
                          "matched":matches,"chosen":flex,"passed":act})
        rows.append({"id":fixture["id"],"family":geo["family"],"states":{"secondary":draws}})
        if len(rows)%8==0:
            print("Completed prior independent sources",len(rows),flush=True)
    return {"parents":parent_ref,"plan":plan_ref,"rows":rows,
            "summary":summary(rows,("secondary",))["secondary"],"activity":nulls(rows,("secondary",))["secondary"]}

def main():
    torch.set_num_threads(2)
    independence()
    start=time.monotonic()
    frozen=reference(ENVELOPE/"inputs.json")
    inputs=read_json(checked(frozen))
    plan=read_json(checked(inputs["plan"]))
    folder=OUT/"native-v2"
    protocol={"source":reference(__file__),"implementation":reference(__import__("pool_phase").__file__),
              "preexisting_inputs":frozen,"primary":"on warped fixtures, oriented pooling minus fixed combined",
              "methods":METHODS,"support_relative":{"broad":1.0,"center":.2},"regularization":.5}
    prior_protocol = reference(OUT/"analysis.json")
    protocol["initial"] = prior_protocol
    protocol["secondary_measure"] = "The prior smooth-dip cohort scores the complete continuously supported carrier."
    write_json(OUT/"analysis-v2.json",protocol)
    exact=folder/"exact"
    standing=folder/"GFX"
    exact.mkdir(parents=True,exist_ok=True)
    standing.mkdir(parents=True,exist_ok=True)
    confirmation=[]
    original_fit = read_json(OUT/"gain-lock.json")
    assert original_fit["driver"] == read_json(checked(prior_protocol))["source"]
    assert original_fit["inputs"] == frozen
    calibrated = original_fit["calibration"]
    amounts = original_fit["amounts"]
    for fixture,row in zip(plan["cases"],inputs["rows"],strict=True):
        if fixture["split"]=="confirmation":
            confirmation.append(evaluate(fixture,row["observations"],plan["native_indices"],plan,amounts,exact))
            if len(confirmation)%5==0:
                print("Scored frozen confirmation",len(confirmation),flush=True)
    assert len(calibrated)==12 and len(confirmation)==20
    extra=secondary(amounts)
    report={
        "driver":reference(__file__),"policy":reference(OUT/"analysis-v2.json"),"captures":frozen,
        "secondary":extra,
        "gain_lock":reference(OUT/"gain-lock.json"),"confirmation":confirmation,"paired":summary(confirmation),
        "activity":nulls(confirmation),"weights":plan["weights"],
        "standing":gfx(plan["weights"]["local50k"],standing),"seconds":time.monotonic()-start,
    }
    write_json(OUT/"review.json",report)


if __name__=="__main__":
    main()
