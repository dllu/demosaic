"""Check the weak-only intervention on a separate 32-photo straight panel."""

import collections
import time

import numpy as np
import torch

from pool_phase import OUT
from weak_only_pool import apply, WeakOnly, nominal_peaks
from capture_envelope import NESTED, RAW
from score_envelope import ROI, Measure, arrays
from review_pool import METRICS, interval, section, source_bootstrap
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    torch.set_num_threads(2)
    start=time.monotonic()
    earlier_ref=reference(OUT/"review.json")
    earlier=read_json(checked(earlier_ref))
    plan=read_json(checked(earlier["secondary"]["plan"]))
    parents=read_json(checked(earlier["secondary"]["parents"]))
    compare=reference(OUT/"weak-only/result.json")
    rows=[]
    selected=np.array([0,2,3,4,5])
    for fixture,r,record in zip(plan["sources"],parents["records"],earlier["secondary"]["rows"],strict=True):
        assert fixture["id"]==r["id"]==record["id"]
        geo=fixture["geometry"]
        scores=[]
        for d,expected in zip(r["streams"],record["states"]["secondary"],strict=True):
            values=arrays(d["data"])
            parent=np.load(checked(d["outputs"]["local50k"]),allow_pickle=False)[selected]
            scene=values["scene_packed"].copy()
            for key in ("packed","variance","target"):
                values[key]=values[key][selected]
            if geo["family"]=="smooth-dip":
                assert np.all(values["support"]>0)
                values["support"]=np.ones_like(values["support"])
            src=(176,176,160,160)
            peak=nominal_peaks(scene,values["colors"],src,48)
            operator=None if peak is None else WeakOnly(*src[:2],values["colors"],peak)
            base,guided=parent.copy(),parent.copy()
            guesses=[]
            for i,raw in enumerate(values["packed"]):
                scene[RAW]=raw
                p,strong,local,weak,report=apply(parent[i],ROI,scene,src,operator,plan["noise"],
                                                 values["wb"],values["matrix"])
                section(base[i],*ROI)[:]=p+strong+local
                section(guided[i],*ROI)[:]=p+strong+weak
                guesses.append(report)
            measure=Measure(values,geo)
            default=measure(base,parent)
            np.testing.assert_allclose([default[k] for k in default],
                                       [expected["scores"]["planar"][k]for k in default],atol=.0002,rtol=0)
            scores.append({"input":d["data"],"rank":guesses,
                          "planar":default,"weak_pool":measure(guided,parent)})
        rows.append({"id":fixture["id"],"family":geo["family"],"draws":scores})
    rng=np.random.default_rng(202611200156)
    summary={}
    for key in METRICS:
        subset=[{"family":r["family"],"delta":np.mean([a["weak_pool"][key]-a["planar"][key]for a in r["draws"]])}
                for r in rows if key in r["draws"][0]["planar"]]
        idx=source_bootstrap(subset,rng)
        summary[key]={"n":len(subset),"difference":interval(np.array([r["delta"]for r in subset])[idx].mean(1))}
    count=collections.Counter(guess["weak_direction"] for r in rows for d in r["draws"] for guess in d["rank"][:1])
    summary["present_direction_rank"]={str(k):v for k,v in count.items()}
    write_json(OUT/"weak-only/secondary.json",{"driver":reference(__file__),"replay":earlier_ref,"followup":compare,
                                               "summary":summary,"rows":rows,"seconds":time.monotonic()-start})
    print(summary,flush=True)


if __name__=="__main__":
    main()
