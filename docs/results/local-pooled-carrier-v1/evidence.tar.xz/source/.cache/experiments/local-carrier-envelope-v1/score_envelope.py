"""Review verified affine carriers on the locked planar/warped and GFX crops."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from carrier_envelope import METHODS, apply, held_audit, nominal_peaks
from capture_envelope import OUT, NESTED, RAW, STATES
from warped_wire import phase_shift
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from evaluate_ring import FIXED, ROI, arrays, display, interval, native_board, source_bootstrap, support_for_scoring
from scoring import luma, remove_basis, space, wire_bases
from score_center_guard import section
from nested_gate import apply as nested_control

PRIMARY = "weak_response"
GAP = "continuing_RMS_DN16"
FALSE = "weak_gap_band_RMS_DN16"
INTACT = "intact_fundamental_RMS_DN16"
FLAT = "flat_core_RMS_DN16"
METRICS = (PRIMARY,GAP,FALSE,INTACT,FLAT,"weak_quadrature_RMS_DN16","edge_added_RMS_DN16","uniform_added_RMS_DN16")
LABELS = {
    "parent":"Local 50k","planar":"Fixed combined","amplitude":"Vary amplitude","complex":"Vary complex",
    "unrestricted":"Always complex","v120":"V120 EMA",
}
GRID=(np.arange(128)-63.5).astype(np.float32)
Y,X=np.meshgrid(GRID,GRID,indexing="ij")
EVAL=np.s_[...,64:192,64:192]


class Measure:
    def __init__(self,data,geometry):
        self.wb,self.matrix=(data[k] for k in ("wb","matrix"))
        self.clean=luma(data["target"], self.wb, self.matrix)[EVAL]
        support=support_for_scoring(data["support"])[EVAL]
        self.intact,self.gap=support>=.97,support==0
        wx,wy=geometry["frequency"][1]
        phi=2*np.pi*(wx*X+wy*Y)+phase_shift(torch.from_numpy(X),torch.from_numpy(Y),geometry).numpy()
        wave=np.stack((np.cos(phi),np.sin(phi)))
        nuisance,_,_=wire_bases(geometry,self.intact)
        self.band=space(remove_basis(wave[:,self.intact],nuisance))
        self.target=(self.clean[0]-self.clean[1])[self.intact]@self.band
        self.norm=self.target@self.target
        assert self.norm>0
        if self.gap.any():
            assert np.count_nonzero(self.gap)>64
            np.testing.assert_array_equal(self.clean[0][self.gap],self.clean[1][self.gap])
            background,self.strong,_=wire_bases(geometry,self.gap)
            lens=np.stack((np.ones_like(X), X/64,Y/64))
            combo=(wave[:,None]*lens[None]).reshape(6,128,128)
            self.above=space(remove_basis(combo[:,self.gap],background))

    def __call__(self,pred,parent):
        tone=luma(pred,self.wb,self.matrix)[EVAL]
        weak=(tone[0]-tone[1])[self.intact]@self.band
        signed=float(weak@self.target/self.norm)
        scale=65535/np.sqrt(self.intact.sum())
        prior=luma(parent,self.wb,self.matrix)[EVAL]
        result={
            PRIMARY:100*signed,
            INTACT:float(np.linalg.norm(weak-self.target)*scale),
            "weak_quadrature_RMS_DN16":float(np.linalg.norm(weak-signed*self.target)*scale),
            FLAT:float(np.std(tone[2])*65535),
        }
        for i,name in ((3,"edge"),(4,"uniform")):
            result[name+"_added_RMS_DN16"]=float(np.sqrt(np.mean((tone[i]-prior[i])**2))*65535)
        if self.gap.any():
            r=(tone[0]-self.clean[0])[self.gap]
            scale=65535/np.sqrt(self.gap.sum())
            result[GAP]=float(np.linalg.norm(r@self.strong)*scale)
            result[FALSE]=float(np.linalg.norm(r@self.above)*scale)
        return result


def measured(data, parent, scene, noise, g, audit):
    bayer=data["colors"]
    box=(176,176,160,160)
    p=scene.copy()
    peaks=nominal_peaks(p,bayer,box,48)
    corrections={k:parent.copy() for k in METHODS}
    act,flex=[],[]
    for i,crop in enumerate(data["packed"]):
        p[RAW]=crop
        if audit:
            np.testing.assert_array_equal(nominal_peaks(p,bayer,box,48),peaks)
        out,a,c=apply(parent[i],ROI,p,bayer,box,peaks,noise,data["wb"],data["matrix"])
        if audit:
            hand, _ = nested_control(parent[i],ROI,p,bayer,box,peaks,noise | {
                "wb":data["wb"],"matrix":data["matrix"],
            })
            np.testing.assert_allclose(out["planar"],hand["nested"],rtol=3e-7,atol=2e-8)
        for k,row in out.items():
            section(corrections[k][i],*ROI)[:]=row
        act.append(a)
        flex.append(c)
    return corrections,act,flex,Measure(data,g)


def evaluate(fixture, captures, selected, plan, gain, folder):
    result={}
    base_scene=[arrays(r["input"])["scene_packed"] for r in captures["straight"]]
    for state in STATES:
        r=[]
        geo=fixture["geometry"] if state=="straight" else fixture["geometry"]|{"warp":fixture["warp"]}
        for read in captures[state]:
            f=arrays(read["input"])
            draw=read["draw"]
            parent=f["local50k"]
            outputs,active,selected_windows,metric=measured(f,parent,base_scene[draw],plan["noise"],geo,
                                                          audit=not draw and fixture["index"] in (0,13))
            all_={"parent": parent}|outputs
            if "v120" in f:
                all_["v120"]=f["v120"]
            metrics={k:metric(v,parent) for k,v in all_.items()}
            match={}
            for key, weights in gain.get(state,{}).items():
                if weights:
                    match[key]={k:metric(parent+(outputs[k]-parent)*value,parent) for k,value in weights.items()}
            native=None
            if state=="warped" and draw==0 and fixture["index"] in selected:
                camera={k:f[k][None] for k in ("colors","wb","matrix")}
                camera["packed"]=f["packed"][:1]
                frames=[noisy_malvar(camera)[0],*(all_[k][0] for k in LABELS),f["target"][0]]
                native=native_board(folder,fixture["id"],frames,camera,{
                    "source":fixture,"input":read["input"],"geometry":geo,"noise":plan["noise"],
                    "weights":plan["weights"],"query":plan["query"],"optical_sigma":plan["sigma"],
                },labels=["Noisy Malvar",*LABELS.values(),"Exact GT"],triplet_indices=(0,4,7))
            r.append({"draw":draw,"input":read["input"],"scores":metrics,"held_donors":captures["straight"][draw]["input"],
                      "passed":active,"chosen":selected_windows,"matched":match,"native":native})
        result[state]=r
    return {"id":fixture["id"],"fixture":fixture,"family":fixture["geometry"]["family"],"states":result}


def fit_match(calibration):
    output={}
    for state in STATES:
        n=["parent",*METHODS]
        means={k:float(np.mean([d["scores"][k][PRIMARY] for r in calibration for d in r["states"][state]])) for k in n}
        response={k:v-means["parent"] for k,v in means.items() if k!="parent"}
        matched={}
        for first,second in (("planar","complex"),("amplitude","complex"),("planar","unrestricted")):
            point=min(response[first],response[second])/2
            matched[first+"+"+second]={k:point/response[k] for k in (first,second)} if point>0 else None
        output[state]=matched
    return output


def summary(rows):
    out={}
    for state in STATES:
        by={}
        rng=np.random.default_rng(202611200139)
        pairs=[("parent",a) for a in (*METHODS,"v120")]+[("planar",k) for k in METHODS if k!="planar"]
        pairs.append(("amplitude","complex"))
        for first,second in pairs:
            label=first+"+"+second
            report={}
            for version in ("nominal","matched"):
                change={}
                for k in METRICS:
                    chosen=[]
                    for r in rows:
                        groups=[d["scores"] if version=="nominal" else d["matched"].get(label)
                                for d in r["states"][state]]
                        if not all(g is not None and k in g[second] for g in groups):
                            continue
                        delta=np.mean([g[second][k]-g[first][k] for g in groups])
                        chosen.append({"family":r["family"],"delta":delta})
                    if chosen:
                        ix=source_bootstrap(chosen,rng)
                        vals=np.asarray([r["delta"] for r in chosen])[ix].mean(1)
                        change[k]={"n":len(chosen),"difference":interval(vals)}
                if change:
                    report[version]=change
            by[label]=report
        out[state]=by
    return out


def nulls(rows):
    output={}
    for state in STATES:
        flat={}
        for label,i in (("strong_only",1),("flat_core",2),("edge_only",3),("uniform",4)):
            group=[d for r in rows for d in r["states"][state]]
            flat[label]={
                "n":len(group),"any_pass":{k:sum(any(d["passed"][i][k]) for d in group) for k in METHODS},
                "admissions":{k: np.asarray([d["passed"][i][k] for d in group]).sum(0).tolist() for k in METHODS},
                "chosen_expansion":{k:np.asarray([d["chosen"][i][k] for d in group]).sum(0).tolist() for k in METHODS},
            }
        group=[d for r in rows for d in r["states"][state]]
        flat["present_chosen_expansion"]={k:np.asarray([d["chosen"][0][k] for d in group]).sum(0).tolist()
                                           for k in METHODS}
        output[state]=flat
    return output


def gfx(weight, folder):
    binding=reference(FIXED)
    original=read_json(checked(binding))
    assert original["checkpoints"]["local50k"]==weight
    report=[]
    for row in original["standing"]:
        f=arrays(row["input"])
        p=np.load(checked(row["predictions"]["local50k"]),allow_pickle=False)[0]
        scene, colors, wb, matrix=(f[k][0] for k in ("packed","colors","wb","matrix"))
        box=tuple(row["local_ROI"])
        peaks=nominal_peaks(scene,colors,box,16)
        out, count, flexible=apply(p,box,scene,colors,box,peaks,row["noise"],wb,matrix)
        crop=section(p,*box)
        rms={k:float(np.sqrt(np.mean((a.astype(float)-crop)**2))*65535) for k,a in out.items()}
        views=[]
        for display_ in row["displays"]:
            exposure, prior=display_["exposure"],display_["board"]
            with Image.open(checked(prior["image"])) as im:
                board=np.asarray(im)
            frames={}
            for descriptor in prior["panels"]:
                x,y,w,h=descriptor["png_xywh"]
                frames[descriptor["name"]]=board[y:y+h,x:x+w]
            np.testing.assert_array_equal(display(crop,wb,matrix,exposure),frames["Local 50k"])
            columns=[(k,frames[k]) for k in ("Noisy (Malvar)","V120 EMA","Corpus 100k","Local 50k")]
            columns.extend((LABELS[k],display(out[k],wb,matrix,exposure)) for k in METHODS)
            columns.extend((k,frames[k]) for k in ("ISO100 AHD reference","ISO6400 camera JPEG","ISO100 camera JPEG") if k in frames)
            native=Image.new("RGB",(8+168*len(columns),192),"#eeeeee")
            draw=ImageDraw.Draw(native)
            for i,(name,values) in enumerate(columns):
                x=8+168*i
                assert values.shape==(160,160,3)
                native.paste(Image.fromarray(values),(x,24))
                draw.text((x,5),name,fill="black")
            path=folder/f'{row["id"]}-x{exposure:g}.png'
            native.save(path)
            views.append({"image":reference(path),"columns":len(columns),"exposure":exposure,"prior":prior})
        report.append({"id":row["id"],"roi":row["global_ROI"],"noise":row["noise"],"raw":row["raw"],
                       "parent":row["predictions"]["local50k"],"input":row["input"],"native":views,
                       "rms_RGB_DN16":rms,"passed":count,"chosen":flexible})
    return {"standing_receipt":binding,"rows":report}


def main():
    torch.set_num_threads(2)
    held_audit()
    start=time.monotonic()
    frozen=reference(OUT/"inputs.json")
    inputs=read_json(checked(frozen))
    plan=read_json(checked(inputs["plan"]))
    folder=OUT/"native"
    exact=folder/"exact"
    standing=folder/"GFX"
    exact.mkdir(parents=True,exist_ok=True)
    standing.mkdir(parents=True,exist_ok=True)
    calibrated=[]
    confirmation=[]
    for fixture,row in zip(plan["cases"],inputs["rows"],strict=True):
        assert fixture["id"]==row["id"]
        if fixture["split"]=="calibration":
            calibrated.append(evaluate(fixture,row["observations"],(),plan,{},exact))
    amounts=fit_match(calibrated)
    write_json(OUT/"gain-lock.json",{"driver":reference(__file__),"inputs":frozen,
                                     "amounts":amounts,"calibration":calibrated})
    for fixture,row in zip(plan["cases"],inputs["rows"],strict=True):
        if fixture["split"]=="confirmation":
            confirmation.append(evaluate(fixture,row["observations"],plan["native_indices"],plan,amounts,exact))
            if len(confirmation)%5==0:
                print("Scored frozen confirmation",len(confirmation),flush=True)
    assert len(calibrated)==12 and len(confirmation)==20
    report={
        "driver":reference(__file__),"policy":plan["policy"],"captures":frozen,
        "gain_lock":reference(OUT/"gain-lock.json"),"confirmation":confirmation,"paired":summary(confirmation),
        "activity":nulls(confirmation),"weights":plan["weights"],
        "standing":gfx(plan["weights"]["local50k"],standing),"seconds":time.monotonic()-start,
    }
    write_json(OUT/"review.json",report)


if __name__=="__main__":
    main()
