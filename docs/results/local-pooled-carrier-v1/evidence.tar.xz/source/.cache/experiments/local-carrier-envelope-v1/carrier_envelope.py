"""Validate a spatially varying carrier on held-out broad and center green sites."""

from dataclasses import dataclass
import sys

import numpy as np

from capture_envelope import CACHE, LIMITS
sys.path[:0] = [str(CACHE/name) for name in ("local-nested-support-v1", "local-center-guard-v1", "local-exterior-phase-transfer-v1")]
from center_guard import improvement, variance
from nested_gate import nominal_peaks, strength
from ring_refit import EDGE, GAIN, OFFSET, OUTER, TAPER, WIDTH, sample, unpack
from review_raw import box_wave, nuisance, planes

SIZE = 160
METHODS = ("planar", "amplitude", "complex", "unrestricted")
CORE = np.s_[OFFSET:OFFSET+WIDTH, OFFSET:OFFSET+WIDTH]
GRID = tuple((y,x) for y in range(0, SIZE-WIDTH+1, WIDTH//2)
             for x in range(0, SIZE-WIDTH+1, WIDTH//2))
X, Y = np.meshgrid((np.arange(OUTER)-(OUTER-1)/2) / ((OUTER-1)/2),
                   (np.arange(OUTER)-(OUTER-1)/2) / ((OUTER-1)/2))
MOD = np.stack((np.ones_like(X), X, Y),axis=-1)


def get_design(array, parity):
    return sample(array,parity).reshape(-1,array.shape[-1])


@dataclass
class Split:
    train_background: np.ndarray
    held_background: np.ndarray
    inverse: np.ndarray
    train_wave: np.ndarray
    held_wave: np.ndarray

    @classmethod
    def build(cls, nuisance_terms, test_wave, train, held):
        a,b=(get_design(nuisance_terms,point) for point in (train,held))
        x,y=(get_design(test_wave,point) for point in (train,held))
        fit=np.linalg.pinv(a,rcond=1e-8)
        moment=fit@x
        return cls(a,b,fit,x-a@moment,y-b@moment)

    def errors(self, a, b):
        coeff=self.inverse@a
        return a-self.train_background@coeff,b-self.held_background@coeff


def geom_bank(waves, mod):
    n=waves.shape[0]
    return (mod[...,None,:,None]*waves[..., :,None,:]).reshape(n,n,2,6)


class Envelope:
    def __init__(self, colors, x, y, frequency):
        self.positions=planes(np.asarray(colors),(x,y,WIDTH))
        self.waves=box_wave((0,0,OUTER),((OUTER-1)/2,)*2,frequency)
        expanded=geom_bank(self.waves,MOD)
        base=nuisance(OUTER,"cosine")
        core_background=nuisance(WIDTH,"cosine")
        self.fitting={}
        for primary, hold in (self.positions,self.positions[::-1]):
            options=[]
            for d in range(2):
                rival=self.waves[...,1-d,:]
                before=np.concatenate((base,rival),axis=-1)
                inside=np.concatenate((core_background,rival[CORE]),axis=-1)
                broad=Split.build(before,expanded[...,d,:],primary,hold)
                narrow=Split.build(inside,expanded[CORE][...,d,:],primary,hold)
                gram=broad.train_wave.T@broad.train_wave
                plain=np.linalg.inv(gram[:2,:2])
                regularized=gram + np.diag([0.,0.,1.,1.,1.,1.])*LIMITS["ridge"]*np.diag(gram)[2:].mean()
                mix=np.linalg.inv(regularized)
                options.append((broad,narrow,plain,regularized,mix))
            self.fitting[primary]=options
        self.own_planar=self.parent_fit(base,self.waves)
        self.own_complex=self.parent_fit(base,expanded)

    @staticmethod
    def parent_fit(nuisance_terms,wave):
        n=wave.shape[-1]*2
        design=np.concatenate((nuisance_terms,wave.reshape(OUTER,OUTER,n)),axis=-1).reshape(OUTER**2,-1)
        return np.linalg.pinv(design,rcond=1e-8)[-n:]

    def fold(self, tile, source, held, shot, read):
        a,b=(sample(tile,t).ravel() for t in (source,held))
        c,d=(sample(tile[CORE],t).ravel() for t in (source,held))
        record=[]
        for broad, narrow, plane, regularized, mixed in self.fitting[source]:
            raw,error=broad.errors(a,b)
            _,center=narrow.errors(c,d)
            moment=broad.train_wave.T@raw
            coef=plane@moment[:2]
            unit=coef/np.linalg.norm(coef).clip(min=1e-12)
            parallel=np.zeros((6,4))
            parallel[:2,:2]=np.eye(2)
            parallel[2:4,2]=unit
            parallel[4:6,3]=unit
            slope=parallel@np.linalg.lstsq(parallel.T@regularized@parallel,parallel.T@moment,rcond=1e-8)[0]
            variants=np.stack((np.r_[coef,np.zeros(4)],slope,mixed@moment))
            wide=improvement
            broad_score=[wide(error,broad.held_wave@v,variance(a,shot,read)) for v in variants]
            center_score=[wide(center,narrow.held_wave@v,variance(c,shot,read)) for v in variants]
            record.append({"coef":variants,"broad":broad_score,"center":center_score})
        return record

    def patch(self, tile, parent, shot, read):
        first,second=(self.fold(tile,a,b,shot,read)
                      for a,b in (self.positions,self.positions[::-1]))
        parent_planar=(self.own_planar@parent.ravel()).reshape(2,2)
        parent_complex=(self.own_complex@parent.ravel()).reshape(2,6)
        active={k:np.zeros(2,dtype=int) for k in METHODS}
        changed={k:np.zeros(2,dtype=int) for k in METHODS}
        predictions={k:np.zeros((WIDTH,WIDTH)) for k in METHODS}
        for i,(a,b) in enumerate(zip(first,second,strict=True)):
            broad, center=(np.stack((a[key],b[key])) for key in ("broad","center"))
            cap=np.minimum(strength(broad.min(0),LIMITS["broad"]),
                           strength(center.min(0),LIMITS["center"]))
            preferred={}
            for label,j in (("amplitude",1),("complex",2)):
                support=np.all(broad[:,j]-broad[:,0]>LIMITS["broad_relative"]) and                         np.all(center[:,j]-center[:,0]>LIMITS["center_relative"])
                preferred[label]=j if support and cap[j]>0 else 0
            preferred|={"planar":0,"unrestricted":2}
            pooled=(a["coef"]+b["coef"])/2
            mod=MOD[CORE]
            for label,j in preferred.items():
                if cap[j]<=0:
                    continue
                coeff=pooled[j]
                if j==0:
                    before=np.r_[parent_planar[i],np.zeros(4)]
                elif j==1:
                    unit=coeff[:2]/np.linalg.norm(coeff[:2]).clip(min=1e-12)
                    before=parent_complex[i].copy().reshape(3,2)
                    before[1:]=(before[1:]@unit)[:,None]*unit
                    before=before.ravel()
                else:
                    before=parent_complex[i]
                measured=mod@coeff.reshape(3,2)
                correction=cap[j]*(mod@(coeff-before).reshape(3,2))
                limit=np.linalg.norm(measured,axis=-1)
                step=np.linalg.norm(correction,axis=-1).clip(min=1e-12)
                correction*=np.minimum(1,limit/step)[...,None]
                predictions[label]+=np.sum(self.waves[CORE][...,i,:]*correction,axis=-1)
                active[label][i]+=1
                changed[label][i]+=int(j!=0)
        return predictions,active,changed


def apply(parent, region, scene, colors, samples, peaks, noise, wb, matrix):
    x,y,w,h=region
    p=parent[...,y:y+h,x:x+w]
    assert p.shape==(3,SIZE,SIZE)
    zeros={k:[0,0] for k in METHODS}
    if peaks is None:
        return {k:p for k in METHODS}, zeros, zeros
    xx,yy=samples[:2]
    operator=Envelope(colors,xx,yy,peaks)
    raw=unpack(scene)
    source=parent[1,y-OFFSET:y+h+OFFSET,x-OFFSET:x+w+OFFSET]
    assert source.shape==(192,192)
    frame={k:np.zeros((SIZE,SIZE)) for k in METHODS}
    admits={k:np.zeros(2,dtype=np.int32) for k in METHODS}
    changes={k:np.zeros(2,dtype=np.int32) for k in METHODS}
    weights=np.zeros((SIZE,SIZE))
    for dy,dx in GRID:
        a,b=xx+dx-OFFSET,yy+dy-OFFSET
        tile=raw[b:b+OUTER,a:a+OUTER].astype(np.float64)
        p64=source[dy:dy+OUTER,dx:dx+OUTER]
        rendered,used,selected=operator.patch(tile,p64,noise["shot"],noise["read"])
        sl=np.s_[dy:dy+WIDTH,dx:dx+WIDTH]
        for k,v in rendered.items():
            admits[k]+=used[k]
            changes[k]+=selected[k]
            frame[k][sl]+=v*TAPER
        weights[sl]+=TAPER
    neutral=np.linalg.solve(matrix,np.ones(3))/wb
    neutral/=neutral[1]
    for k in METHODS:
        wave=frame[k]/np.maximum(.02,weights)*EDGE[:,None]*EDGE[None,:]
        frame[k]=p+(GAIN*neutral[:,None,None]*wave).astype(p.dtype)
    return frame,{k:v.tolist() for k,v in admits.items()},{k:v.tolist() for k,v in changes.items()}


def held_audit():
    rng=np.random.default_rng(202611200136)
    for colors in ((0,1,1,2),(1,0,2,1),(1,2,0,1),(2,1,1,0)):
        box=rng.uniform(.05,.12,(64,64))
        for xy in ((0,0),(5,7)):
            fit=Envelope(colors,*xy,((.12,.075),(.09,-.072)))
            for source,held in (fit.positions,fit.positions[::-1]):
                a=fit.fold(box,source,held,.00128,6.5536e-6)
                altered=box.copy()
                altered[held[0]::2,held[1]::2]=rng.uniform(.02,.17,(32,32))
                b=fit.fold(altered,source,held,.00128,6.5536e-6)
                for f,g in zip(a,b,strict=True):
                    np.testing.assert_array_equal(f["coef"],g["coef"])
                    assert f["broad"]!=g["broad"] and f["center"]!=g["center"]
