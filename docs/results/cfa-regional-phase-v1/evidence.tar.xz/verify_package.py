"""Verify the experimental API against the frozen crop replay and time standing inputs."""

import os
from pathlib import Path
from random import Random
from statistics import median
from time import perf_counter_ns

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing, refine_raw_mesh_carriers
from demosaic.prediction_archive import fingerprint
from regional_phase import apply_sharing
from replay_regional import FIXED, OUT, RAW, ROI, SENSOR_ROI, arrays

METHODS = {"pooled": "weak_only", "pooled-color": "regional_phase"}


def apply(rgb, scene, local, roi, colors, wb, matrix, noise, method, clearance):
    x, y, w, h = local
    crop = rgb[:, y : y + h, x : x + w]
    extra = rgb[:, y - 16 : y + h + 16, x - 16 : x + w + 16]
    return refine_raw_mesh_carriers(
        crop,
        scene,
        colors,
        roi,
        shot=noise["shot"],
        read=noise["read"],
        white_balance=wb,
        camera_to_srgb=matrix,
        method=method,
        parent_context=extra,
        donor_clearance=clearance,
    )


def photo_replay(review, plan):
    done = 0
    for row in review["rows"]:
        for cases in row["states"].values():
            for d in cases:
                data = arrays(d["input"])
                rgb = data["local50k"]
                colors, wb, matrix = (data[k] for k in ("colors", "wb", "matrix"))
                scene = arrays(d["exterior"])["scene_packed"].copy()
                for i, sensor in enumerate(data["packed"]):
                    scene[RAW] = sensor
                    gold = d["fits"][i]["fingerprint"]
                    for method, old in METHODS.items():
                        v = apply(
                            rgb[i],
                            scene,
                            ROI,
                            SENSOR_ROI,
                            colors,
                            wb,
                            matrix,
                            plan["noise"],
                            method,
                            48,
                        )
                        assert fingerprint(v) == gold[old], (
                            row["case"]["id"],
                            d["draw"],
                            i,
                            method,
                        )
                    done += 1
        if (row["case"]["index"] + 1) % 8 == 0:
            print("matched", row["case"]["index"] + 1, flush=True)
    return done


def standing():
    fixed = reference(FIXED)
    old = read_json(checked(fixed))
    rng = Random(1383)
    timings = []
    for d in old["standing"]:
        f = arrays(d["input"])
        scene, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        p = np.load(checked(d["predictions"]["local50k"]), allow_pickle=False)[0]
        roi = tuple(d["local_ROI"])
        peaks = _spacing(scene, colors, *roi[:2], clearance=16)
        archived, _ = apply_sharing(p, roi, scene, roi, colors, peaks, d["noise"], wb, matrix)

        def run(m):
            return apply(p, scene, roi, roi, colors, wb, matrix, d["noise"], m, 16)

        for m, key in METHODS.items():
            np.testing.assert_array_equal(run(m), archived[key])
            for _ in range(2):
                run(m)
        values = {m: [] for m in METHODS}
        order = list(METHODS)
        for _ in range(15):
            rng.shuffle(order)
            for m in order:
                start = perf_counter_ns()
                run(m)
                values[m].append((perf_counter_ns() - start) / 1e6)
        row = {
            "id": d["id"],
            "input": d["input"],
            "parent": d["predictions"]["local50k"],
            "roi": d["global_ROI"],
            "noise": d["noise"],
            "samples_ms": values,
            "median_ms": {m: median(v) for m, v in values.items()},
        }
        timings.append(row)
        print(d["id"], row["median_ms"], flush=True)
    return fixed, timings


def main():
    bind = reference(OUT / "review.json")
    review = read_json(checked(bind))
    plan = read_json(checked(review["plan"]))
    source, times = standing()
    cases = photo_replay(review, plan)
    assert cases == 480 and len(times) == 8
    root = Path(__file__).resolve().parents[3]
    write_json(
        OUT / "package.json",
        {
            "driver": reference(__file__),
            "review": bind,
            "sources": [
                reference(root / "src/demosaic" / f"{key}.py")
                for key in ("mesh_carrier_fit", "_mesh_pooled")
            ],
            "photo_crops": cases,
            "standing_file": source,
            "standing_crops": len(times),
            "methods": METHODS,
            "exact_rgb_values_per_method": (cases + len(times)) * 160 * 160 * 3,
            "median_warm_crop_CPU_ms": times,
            "timing_threads": {
                k: os.environ.get(k) for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS")
            },
        },
    )


if __name__ == "__main__":
    main()
