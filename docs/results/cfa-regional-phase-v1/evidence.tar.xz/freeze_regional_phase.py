"""Reserve an unused photographic panel before testing regional color agreement."""

from collections import Counter
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
COUNT = 24
SEED = 202611200225
sys.path.insert(0, str(HERE.with_name("local-carrier-envelope-v1")))
import capture_envelope as envelope

from capture_envelope import NESTED, FAMILIES, capture_wide, carrier

PREVIOUS = OUT.with_name("local-carrier-envelope-v1") / "plan.json"


def freeze():
    prior_bind = reference(PREVIOUS)
    before = read_json(checked(prior_bind))
    nested_bind = reference(NESTED / "plan.json")
    nested = read_json(checked(nested_bind))
    exclusions = [prior_bind, *before["evaluation_exclusions"], nested["earlier_photos_excluded"]]
    seen = set()
    for binding in exclusions:
        if checked(binding).suffix == ".jsonl":
            for row in capture_wide.lines(binding):
                capture_wide.scan(row, seen)
        else:
            capture_wide.scan(read_json(checked(binding)), seen)

    bank = [
        r
        for r in capture_wide.lines(before["source_pool"])
        if r["split"] == "val"
        and r["bin_factor"] == 4
        and min(r["shape"][:2]) >= 512
        and {r["id"], r["cache_sha256"]}.isdisjoint(seen)
    ]
    bank.sort(key=lambda r: sha256(f"regional-phase/{SEED}/{r['id']}".encode()).digest())
    rows = []
    capture_wide.SEED = SEED
    for j, photo in enumerate(bank):
        if not {photo["id"], photo["cache_sha256"]}.isdisjoint(seen):
            continue
        i = len(rows)
        (box,) = scene_crop_boxes(
            photo["shape"][:2], patch_size=512, count=1, seed=scene_seed(SEED, i, "crop")
        )
        camera = asdict(sample_scene_recipe(scene_seed(SEED, i, "camera")))
        camera.update(
            pattern=tuple(PATTERNS)[(i + i // 4) % 4],
            black=0.03,
            **{k: before["noise"][k] for k in ("shot", "read", "exposure")},
        )
        rng = np.random.default_rng(scene_seed(SEED, i, "phase"))
        warp = dict(
            zip(
                ("tilt_t", "tilt_n", "bend"),
                (rng.choice((-1, 1), 3) * rng.uniform((1.8, 0.45, 1.35), (4.0, 1.2, 3.2))).tolist(),
                strict=True,
            )
        )
        g = capture_wide.geometry(i)
        # The competitive half includes comparable directional amplitudes.
        group = "clear" if i % 8 < 4 else "competitive"
        primary = float(rng.uniform(0.0095, 0.017))
        secondary = (
            primary * rng.uniform(0.82, 1.08)
            if group == "competitive"
            else float(rng.uniform(0.0028, 0.0072))
        )
        g.update(
            family=FAMILIES[i % 4],
            frequency=[carrier(rng, 1, (6.85, 9.4)), carrier(rng, -1, (6.9, 9.5))],
            strength=[primary, secondary],
            gap_width=float(rng.uniform(22, 33)),
            gap_length=float(rng.uniform(32, 57)),
            tint=rng.uniform(0.04, 0.13, 3).tolist(),
        )
        seen.update((photo["id"], photo["cache_sha256"]))
        rows.append(
            {
                "source": photo,
                "box": box,
                "index": i,
                "geometry": g,
                "warp": warp,
                "id": f"regional-phase-{i:02d}",
                "camera": camera,
                "split": "confirmation",
                "contrast_group": group,
            }
        )
        if len(rows) == COUNT:
            break
    assert len(rows) == COUNT
    picks = {r["source"][k] for r in rows for k in ("id", "cache_sha256")}
    trace = read_json(checked(before["train_trace"]))
    visits = 0
    for binding in trace["source_traces"]:
        for r in capture_wide.lines(binding):
            for source in r["sources"]:
                if source["kind"] == "photographic":
                    assert picks.isdisjoint((source["source_id"], source["cache_sha256"]))
                    visits += 1
    assert visits == before["photo_visits_checked"]
    return {
        "driver": reference(__file__),
        "capture_driver": reference(envelope.__file__),
        "warp_source": before["warp_source"],
        "generator_source": before["generator_source"],
        "exclusion_manifests": exclusions,
        "source_pool": before["source_pool"],
        "train_trace": before["train_trace"],
        "photo_visits_checked": visits,
        "weights": before["weights"],
        "cases": rows,
        "states": ("straight", "warped"),
        "sources": dict(Counter(r["contrast_group"] for r in rows)),
        "noise": before["noise"],
        "sigma": before["sigma"],
        "roles": before["roles"],
        "query": before["query"],
        "native_indices": (0, 6),
        "seed": SEED,
        "primary": "Fresh warped and straight photo targets. Compare fixed green, crop-wide and regional phase.",
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    plan_path = OUT / "plan.json"
    if not plan_path.exists():
        write_json(plan_path, freeze())
    binding = reference(plan_path)
    plan = read_json(checked(binding))
    assert plan["driver"] == reference(__file__)
    envelope.OUT, envelope.SALT = OUT, SEED
    envelope.capture(plan, binding)
