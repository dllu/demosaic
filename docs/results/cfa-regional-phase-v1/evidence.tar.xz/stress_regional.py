"""Probe regional color coherence before and after the held-green check."""

from pathlib import Path
import time

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json

from regional_phase import _measure_nodes, _wave, apply_sharing, fields, independence, template

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
NOISE = {"shot": 0.00128, "read": 6.5536e-6}
NOISES = (1.0, 2.0)
COUNT = 48
SALT = 202611200218
CENTER = np.s_[32:-32, 32:-32]
CROP = np.s_[16:-16, 16:-16]
ORIGIN = (33, 31, 160, 160)


def correlation(values, target):
    return float(np.sum(values * target) / np.sqrt(np.sum(values**2) * np.sum(target**2)))


def local_profile(weak, x, y, w, h):
    ellipse = (x / w) ** 2 + (y / h) ** 2
    reversal = np.clip((1.2 - ellipse) / 0.4, 0, 1)
    return weak * (1 - 2 * reversal), ellipse <= 0.8


def store(packed, position, values):
    pr, pc = position
    xx, yy = ORIGIN[:2]
    top, left = yy - 16 + pr, xx - 16 + pc
    index = 2 * (top % 2) + left % 2
    packed[index, top // 2 : top // 2 + 96, left // 2 : left // 2 + 96] = values


def run_case(seed, scale):
    rng = np.random.default_rng(seed)
    noise = {k: scale * v for k, v in NOISE.items()}
    peaks = np.array(
        [
            [rng.uniform(0.09, 0.125), rng.uniform(0.058, 0.09)],
            [rng.uniform(0.082, 0.111), -rng.uniform(0.06, 0.088)],
        ]
    )
    y, x = np.indices((192, 192), dtype=np.float64) - 95.5
    wave = _wave(192, peaks)
    phase = rng.uniform(-np.pi, np.pi) + (
        rng.uniform(0.7, 2.5) * x / 96 + rng.uniform(-1.6, 1.6) * (y**2 - x * y) / 96**2
    ) * rng.choice([-1, 1])
    weak = wave[..., 1, 0] * np.cos(phase) - wave[..., 1, 1] * np.sin(phase)
    strong = 0.009 * (wave[..., 0, 0] + 0.25 * wave[..., 0, 1])
    amp = rng.uniform(0.002, 0.0045)
    field = 0.06 + 0.005 * (x + y) / 160 + 0.01 * np.tanh((x - 1.4 * y + 32) / 10)
    background = field + strong
    offband = np.cos(2 * np.pi * ((peaks[1, 0] + 0.014) * x + (peaks[1, 1] - 0.016) * y) + phase)
    medium, patch = local_profile(weak, x, y, 32, 43)
    small, small_patch = local_profile(weak, x, y, 16, 22)
    wide, wide_patch = local_profile(weak, x, y, 48, 58)
    profiles = {
        "aligned": (weak, weak, patch),
        "absent": (0.0, 0.0, patch),
        "opposite": (-weak, -weak, patch),
        "unrelated": (offband, -offband, patch),
        "medium": (medium, medium, patch),
        "small": (small, small, small_patch),
        "wide": (wide, wide, wide_patch),
    }
    colors = tuple(PATTERNS.values())[(seed - SALT) % 4]
    packed = np.full((4, 128, 128), 0.08, dtype=np.float64)
    green, chroma, _ = fields(packed, colors, ORIGIN[:2])
    positions = (*green, *chroma)
    eps = {p: rng.standard_normal((96, 96)) for p in positions}
    core = {p: (slice(p[0], None, 2), slice(p[1], None, 2)) for p in positions}
    terms = {}

    def observe(clean, position):
        values = clean[core[position]]
        noisy = values + eps[position] * np.sqrt(noise["read"] + noise["shot"] * values)
        store(packed, position, noisy)
        return _measure_nodes(noisy, wave, position, **noise)

    for p in green:
        terms[p] = observe(background + amp * weak, p)
    results = {}
    for name, (red, blue, mask) in profiles.items():
        for p, gain, profile in zip(chroma, (0.9, 1.1), (red, blue), strict=True):
            terms[p] = observe(gain * (background + amp * profile), p)
        scores = []
        for p in green:
            base, _ = template(wave, terms, p, (), 1)
            shared, global_ratio = template(wave, terms, p, chroma, 1)
            local, regional_ratio = template(wave, terms, p, chroma, 1, regional=True)
            scores.append(
                {
                    **{
                        key: {
                            "phase_full": correlation(v[CENTER], weak[CENTER]),
                            "phase_patch": correlation(v[mask], weak[mask]),
                        }
                        for key, v in zip(
                            ("green", "shared", "regional"), (base, shared, local), strict=True
                        )
                    },
                    "global_ratio": global_ratio,
                    "regional_ratio": regional_ratio,
                }
            )
        delivered = None
        if name in ("aligned", "medium"):
            levels = np.array((0.9, 1, 1.1))[:, None, None]
            carrier = np.stack((red, weak, blue))
            exact = levels * (background + amp * carrier)
            parent = levels * (background + 0.3 * amp * carrier)
            arms, _ = apply_sharing(
                parent,
                (16, 16, 160, 160),
                packed,
                ORIGIN,
                colors,
                peaks,
                noise,
                np.ones(3),
                np.eye(3),
            )
            delta = {}
            for key, rgb in {"parent": parent[:, CROP[0], CROP[1]], **arms}.items():
                error = rgb[:, mask[CROP]] - exact[:, CROP[0], CROP[1]][:, mask[CROP]]
                delta[key] = {
                    "green_RMS_DN16": float(np.sqrt(np.mean(error[1] ** 2)) * 65535),
                    "rgb_RMS_DN16": float(np.sqrt(np.mean(error**2)) * 65535),
                }
            delivered = delta
        results[name] = {"folds": scores, "delivered": delivered}

    packed.fill(0.08)
    for p in chroma:
        store(packed, p, (0.08 + 3 * (strong + amp * weak))[core[p]])
    parent = np.full((3, 192, 192), 0.08, dtype=np.float64)
    outs, _ = apply_sharing(
        parent, (16, 16, 160, 160), packed, ORIGIN, colors, peaks, noise, np.ones(3), np.eye(3)
    )
    for rgb in outs.values():
        np.testing.assert_array_equal(rgb, parent[:, CROP[0], CROP[1]])
    return {"seed": seed, "pure_chroma_flat_green_exact": True, "conditions": results}


def stats(fold_major, methods, metric, draw):
    out = {}
    value = np.array(
        [[np.mean([f[m][metric] for f in pair]) for m in methods] for pair in fold_major]
    )
    for i, name in enumerate(methods):
        difference = value[:, i] - value[:, 0]
        out[name] = {
            "mean": float(value[:, i].mean()),
            "difference": float(difference.mean()),
            "paired_95": np.quantile(difference[draw].mean(1), (0.025, 0.975)).tolist(),
        }
    return out


def summarize(rows):
    draw = np.random.default_rng(SALT).integers(0, COUNT, (6000, COUNT))
    out = {}
    for condition in rows[0]["conditions"]:
        groups = [x["conditions"][condition] for x in rows]
        fold_major = [g["folds"] for g in groups]
        details = {
            key: stats(fold_major, ("green", "shared", "regional"), key, draw)
            for key in ("phase_full", "phase_patch")
        }
        if groups[0]["delivered"] is not None:
            samples = [[g["delivered"]] for g in groups]
            arms = ("weak_only", "shared_phase", "regional_phase", "parent")
            details["delivered"] = {
                key: stats(samples, arms, key, draw) for key in ("green_RMS_DN16", "rgb_RMS_DN16")
            }
        out[condition] = details
    return out


def main():
    start = time.monotonic()
    panels = {}
    audit = independence()
    for variance in NOISES:
        rows = [run_case(SALT + i, variance) for i in range(COUNT)]
        key = f"{variance:g}x"
        panels[key] = {"rows": rows, "summary": summarize(rows)}
        print(
            key,
            {
                role: {k: v["mean"] for k, v in r["phase_patch"].items()}
                for role, r in panels[key]["summary"].items()
            },
            flush=True,
        )
    write_json(
        OUT / "Stress.json",
        {
            "driver": reference(__file__),
            "operation": reference(HERE / "regional_phase.py"),
            "base_noise": NOISE,
            "noise_factors": NOISES,
            "held_green": audit,
            "seconds": time.monotonic() - start,
            "panels": panels,
        },
    )


if __name__ == "__main__":
    main()
