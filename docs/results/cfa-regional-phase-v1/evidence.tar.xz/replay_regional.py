"""Score regional phase on the frozen fresh photo panel and both standing scenes."""

from pathlib import Path
import sys
from time import monotonic

import numpy as np
from PIL import Image, ImageDraw
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from demosaic.prediction_archive import fingerprint

from regional_phase import ARMS, apply_sharing

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("cfa-phase-sharing-v1")
sys.path.insert(0, str(HERE.with_name(PRIOR.name)))
import replay_sharing as earlier
from replay_sharing import FIXED, PARITY, Measure, RAW, ROI, arrays, display, native_board, section
from review_pool import METRICS, interval, source_bootstrap

SENSOR_ROI = (176, 176, 160, 160)
LABELS = {
    "weak_only": "Green weak-only",
    "open_rank": "Green rank open",
    "shared_phase": "Crop-wide color",
    "regional_phase": "Regional color",
}
PAIRS = (
    ("regional_phase", "weak_only"),
    ("regional_phase", "open_rank"),
    ("regional_phase", "shared_phase"),
    ("shared_phase", "weak_only"),
    ("open_rank", "weak_only"),
    ("regional_phase", "parent"),
    ("regional_phase", "v120"),
)


def score(plan, inputs):
    assert len(plan["cases"]) == len(inputs["rows"]) == 24
    sources = []
    for case, row in zip(plan["cases"], inputs["rows"], strict=True):
        assert case["id"] == row["id"]
        states = {}
        for state in plan["states"]:
            g = case["geometry"] | ({"warp": case["warp"]} if state == "warped" else {})
            draws = []
            for inside, outer in zip(
                row["observations"][state], row["observations"]["straight"], strict=True
            ):
                f = arrays(inside["input"])
                scene = arrays(outer["input"])["scene_packed"].copy()
                p = f["local50k"]
                colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
                peaks = _spacing(scene, colors, *SENSOR_ROI[:2], clearance=48)
                predictions = {k: p.copy() for k in ARMS}
                details = []
                for i, patch in enumerate(f["packed"]):
                    scene[RAW] = patch
                    arms, info = apply_sharing(
                        p[i], ROI, scene, SENSOR_ROI, colors, peaks, plan["noise"], wb, matrix
                    )
                    old, _ = earlier.apply_sharing(
                        p[i], ROI, scene, SENSOR_ROI, colors, peaks, plan["noise"], wb, matrix
                    )
                    for key, value in old.items():
                        np.testing.assert_array_equal(value, arms[key])
                    for k in ARMS:
                        section(predictions[k][i], *ROI)[:] = arms[k]
                    info["fingerprint"] = {k: fingerprint(v) for k, v in arms.items()}
                    details.append(info)
                measure = Measure(f, g)
                pred = {"parent": p, "v120": f["v120"], **predictions}
                metrics = {key: measure(v, p) for key, v in pred.items()}
                board = None
                if (
                    inside["draw"] == 0
                    and case["index"] in plan["native_indices"]
                    and state == "warped"
                ):
                    attrs = {key: f[key][None] for key in ("colors", "wb", "matrix")}
                    attrs["packed"] = f["packed"][:1]
                    frames = [
                        noisy_malvar(attrs)[0],
                        f["v120"][0],
                        p[0],
                        *(predictions[k][0] for k in ARMS),
                        f["target"][0],
                    ]
                    board = native_board(
                        OUT / "exact",
                        case["id"],
                        frames,
                        attrs,
                        {
                            "source": case,
                            "source_input": inside["input"],
                            "weights": plan["weights"],
                            "geometry": g,
                            "query": plan["query"],
                            "optical_sigma": plan["sigma"],
                            "noise": plan["noise"],
                        },
                        labels=[
                            "Noisy Malvar",
                            "V120 EMA",
                            "Local 50k",
                            *LABELS.values(),
                            "Exact GT",
                        ],
                        triplet_indices=(0, 6, 7),
                    )
                draws.append(
                    {
                        "draw": inside["draw"],
                        "input": inside["input"],
                        "exterior": outer["input"],
                        "scores": metrics,
                        "fits": details,
                        "native": board,
                    }
                )
            states[state] = draws
        sources.append(
            {
                "case": case,
                "states": states,
                "family": g["family"],
                "contrast": case["contrast_group"],
            }
        )
        if len(sources) % 6 == 0:
            print("Scored", len(sources), flush=True)
    return sources


def summarize(rows):
    result = {}
    for state in ("straight", "warped"):
        result[state] = {}
        for selection, subset in (
            ("all", rows),
            *((k, [r for r in rows if r["contrast"] == k]) for k in ("clear", "competitive")),
        ):
            result[state][selection] = {}
            for method, base in PAIRS:
                table = {}
                rng = np.random.default_rng(202611200228)
                for metric in METRICS:
                    cohort = [
                        {
                            "family": r["family"],
                            "delta": np.mean(
                                [
                                    d["scores"][method][metric] - d["scores"][base][metric]
                                    for d in r["states"][state]
                                ]
                            ),
                        }
                        for r in subset
                        if metric in r["states"][state][0]["scores"][base]
                    ]
                    ix = source_bootstrap(cohort, rng)
                    table[metric] = {
                        "n": len(cohort),
                        "difference": interval(
                            np.asarray([d["delta"] for d in cohort])[ix].mean(1)
                        ),
                    }
                result[state][selection][f"{method}_minus_{base}"] = table
    return result


def standing(parity):
    bind = reference(FIXED)
    previous = read_json(checked(bind))
    expectations = {r["id"]: r["expected"] for r in parity["standing"]["rows"]}
    out = []
    for row in previous["standing"]:
        f = arrays(row["input"])
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        raw, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(row["local_ROI"])
        peaks = _spacing(raw, colors, *roi[:2], clearance=16)
        arms, detail = apply_sharing(p, roi, raw, roi, colors, peaks, row["noise"], wb, matrix)
        old, _ = earlier.apply_sharing(p, roi, raw, roi, colors, peaks, row["noise"], wb, matrix)
        assert fingerprint(arms["weak_only"]) == expectations[row["id"]]
        for k, v in old.items():
            np.testing.assert_array_equal(v, arms[k])
        difference = {
            key: float(np.sqrt(np.mean((arms["regional_phase"].astype("d") - v) ** 2)) * 65535)
            for key, v in old.items()
        }
        paths = []
        for v in row["displays"]:
            source = v["board"]
            exposure = v["exposure"]
            with Image.open(checked(source["image"])) as saved:
                original = np.asarray(saved)
            frames = {}
            for part in source["panels"]:
                x, y, w, h = part["png_xywh"]
                frames[part["name"]] = original[y : y + h, x : x + w]
            columns = [(k, frames[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            columns += [
                (LABELS[k], display(arms[k], wb, matrix, exposure))
                for k in ARMS
                if k != "open_rank"
            ]
            columns += [
                (k, frames[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in frames
            ]
            sheet = Image.new("RGB", (168 * len(columns) + 8, 192), "#eee")
            text = ImageDraw.Draw(sheet)
            panels = []
            for i, (label, a) in enumerate(columns):
                x = 8 + 168 * i
                sheet.paste(Image.fromarray(a), (x, 24))
                text.text((x, 5), label, fill="black")
                panels.append({"name": label, "xywh": [x, 24, 160, 160]})
            path = OUT / "standing" / f"{row['id']}-x{exposure:g}.png"
            sheet.save(path)
            paths.append(
                {
                    "image": reference(path),
                    "panels": panels,
                    "exposure": exposure,
                    "reference": source,
                }
            )
        out.append(
            {
                "id": row["id"],
                "input": row["input"],
                "raw": row["raw"],
                "roi": row["global_ROI"],
                "noise": row["noise"],
                "parent": row["predictions"]["local50k"],
                "changes": difference,
                "details": detail,
                "native": paths,
            }
        )
        print(row["id"], difference, flush=True)
    return {"source": bind, "weights": previous["checkpoints"], "rows": out}


def main():
    start = monotonic()
    torch.set_num_threads(2)
    for folder in ("exact", "standing"):
        (OUT / folder).mkdir(exist_ok=True)
    inputs_bind = reference(OUT / "inputs.json")
    inputs = read_json(checked(inputs_bind))
    plan = read_json(checked(inputs["plan"]))
    parity_bind = reference(PARITY)
    real = standing(read_json(checked(parity_bind)))
    rows = score(plan, inputs)
    write_json(
        OUT / "review.json",
        {
            "driver": reference(__file__),
            "operation": reference(HERE / "regional_phase.py"),
            "src": [
                reference(Path(__import__(m, fromlist=["_"]).__file__))
                for m in ("demosaic._mesh_pooled", "demosaic.mesh_carrier_fit")
            ],
            "previous_operation": reference(Path(earlier.apply_sharing.__code__.co_filename)),
            "prior_parity": parity_bind,
            "capture": inputs_bind,
            "plan": inputs["plan"],
            "rows": rows,
            "summary": summarize(rows),
            "standing": real,
            "seconds": monotonic() - start,
            "prior_arm_checked_rgb_crops": 24 * 2 * 2 * 5 + 8,
        },
    )


if __name__ == "__main__":
    main()
