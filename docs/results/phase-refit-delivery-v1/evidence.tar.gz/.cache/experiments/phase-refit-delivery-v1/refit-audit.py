"""Verify fixed held-out scores and replay post-validation fits through normal equations."""

import argparse
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.local_validated_waves import (
    LocalWaveConfig,
    conditional_scores,
    fit_local_candidate,
    phase_fit_reliability,
)

MODES = ("all-site-refit", "weighted-refit")
ROOT = Path(__file__).resolve().parent


def unpack(packed, colors):
    h, w = packed.shape[-2:]
    raw = packed.reshape(2, 2, h, w).transpose(2, 0, 3, 1).reshape(2 * h, 2 * w)
    layout = np.tile(colors.reshape(2, 2), (h, w))
    return raw.astype(np.float64), layout


def taper(score, threshold):
    gain = np.zeros_like(score)
    selected = score > threshold
    gain[selected] = 1 - (threshold / score[selected]) ** 2
    return gain


def score_case(config, packed, colors, parent, frequency, noise, receipt):
    raw, cfa = unpack(packed, colors)
    fold = stratified_split(raw.shape, config.split_seed)
    options = {
        "shot": noise["shot"],
        "read": noise["read"],
        "config": config,
        "guide_frequencies_xy": frequency,
        "phase_bins": 8,
    }
    models = [fit_local_candidate(raw, cfa, mask, **options) for mask in (fold, ~fold)]
    reliability = [phase_fit_reliability(model, cfa) for model in models]
    first, second = [
        conditional_scores(
            fit,
            raw,
            cfa,
            ~fit.discovery_mask,
            window=config.validation_window,
            stride=config.validation_stride,
            reliability=r,
        )[0]
        for fit, r in zip(models, reliability, strict=True)
    ]
    score = np.where((first > 0) & (second > 0), (first + second) / 2, np.minimum(first, second))
    influence = 0.25 + 0.75 * taper(score, 1)
    assert influence.min() >= 0.25 and influence.max() <= 1
    native = np.zeros((2, 2, 3, *raw.shape), dtype=np.float64)
    for model, r in zip(models, reliability, strict=True):
        for k, (left, right) in enumerate(model.unit_slices):
            for color in range(3):
                m = cfa == color
                design = model.design[m.ravel()]
                for mode, weight in enumerate((1, influence[k, color, m])):
                    precision = weight / model.variance_cfa[m]
                    gram = design.T @ (precision[:, None] * design)
                    projector = np.linalg.pinv(gram, rcond=1e-12, hermitian=True)
                    moments = design.T @ (
                        precision[:, None] * np.column_stack((raw[m], parent[color][m]))
                    )
                    fitted = projector @ moments
                    delta = fitted[left:right, 0] - fitted[left:right, 1]
                    native[mode, k, color] += (r[k, color] / 2) * (model.unit_fields[k] @ delta)
    error = 0.0
    with np.load(checked(receipt)) as actual:
        for threshold in (0, 2, 4):
            gain = taper(score, threshold)
            active = (gain > 0).any(axis=0)
            for i, mode in enumerate(MODES):
                correct = (parent + (native[i] * gain).sum(axis=0)).astype(parent.dtype)
                observed = actual[f"{mode}-t{threshold}"]
                np.testing.assert_allclose(observed, correct, rtol=0, atol=6e-8)
                np.testing.assert_array_equal(observed[~active], parent[~active])
                error = max(error, np.max(abs(correct.astype(np.float64) - observed)))
    return {
        "prediction": receipt,
        "max_sample_error": float(error),
        "fraction_sites_with_refit_weight_above_floor": float(np.mean(influence > 0.25)),
    }


def main(smoke):
    plan_path = ROOT / "plan.json"
    plan = read_json(plan_path)
    cfg = LocalWaveConfig(**plan["config"])
    assert cfg.window == cfg.stride == 256
    source = ROOT.parent / "donor-phase-support-v1/output/collection.json"
    previous = read_json(source)
    old_plan = read_json(checked(previous["plan"]))
    assert old_plan["groups"] == plan["groups"] and old_plan["camera_cases"] == plan["camera_cases"]
    originals = {r["id"]: r for r in previous["synthetic"]}
    rows = []
    if smoke:
        groups = [next(g for g in plan["groups"] if g["id"] == "iso6400-index0001")]
        closed_groups = [read_json(ROOT / "output/iso6400-index0001.json")]
    else:
        closed_file = ROOT / "output/collection.json"
        closed = read_json(closed_file)
        assert closed["plan"] == reference(plan_path)
        assert closed["references_read"] == closed["learned_calls"] == closed["noise_draws"] == 0
        groups, closed_groups = plan["groups"], closed["synthetic"]
    score_checks = 0
    for group, output in zip(groups, closed_groups, strict=True):
        assert output["id"] == group["id"]
        old = originals[group["id"]]
        for v, n in zip(old["rows"], output["rows"], strict=True):
            assert n["role"] == v["role"]
            assert n["fits"]["records"] == v["fits"]["square"]["records"]
            assert (
                n["fits"]["refit_weight_floor"] == 0.25 and n["fits"]["refit_weight_threshold"] == 1
            )
            score_checks += 1
        select = (group["source"], group["CFA"]) in {(0, "RGGB"), (3, "GBRG")}
        if not (smoke or select):
            continue
        parent = np.load(checked(group["parent"]))[..., 128:384, 128:384]
        with np.load(checked(group["arrays"])) as f:
            raw, colors = f["packed"][..., 64:192, 64:192], f["colors"]
        for view in output["rows"]:
            i = view["role"]
            result = score_case(
                cfg,
                raw[i],
                colors[i],
                parent[i],
                group["frequencies"],
                group["noise"],
                view["prediction"],
            )
            rows.append({"id": group["id"], "role": i, **result})
    if smoke:
        print("Smoke", score_checks, len(rows), max(r["max_sample_error"] for r in rows))
        return
    reference_case = read_json(checked(plan["camera_guide_source"]))
    old_camera_plan = read_json(checked(reference_case["plan"]))
    native = read_json(checked(old_camera_plan["native_plan"]))
    noise_cases = {v["id"]: v["noise"] for v in native["observations"]}
    for case, v, prior in zip(
        plan["camera_cases"], closed["camera"], previous["camera"], strict=True
    ):
        assert case["id"] == v["id"] == prior["id"]
        assert v["fits"]["records"] == prior["fits"]["square"]["records"]
        score_checks += 1
        x, y, w, h = case["query_box"]
        parent = np.load(checked(case["parent_prediction"]))[0, :, y : y + h, x : x + w]
        with np.load(checked(case["query_arrays"])) as f:
            packed = f["packed"][0, :, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
            colors = f["colors"][0]
        result = score_case(
            cfg, packed, colors, parent, case["guide"], noise_cases[case["query"]], v["prediction"]
        )
        rows.append({"id": case["id"], **result})
    assert score_checks == 392 and len(rows) == 32
    write_json(
        ROOT / "refit-audit.json",
        {
            "driver": reference(__file__),
            "collection": reference(closed_file),
            "baseline_collection": reference(source),
            "saved_fold_diagnostics_bitexact": score_checks,
            "direct_refit_views": len(rows),
            "direct_refit_images": len(rows) * 2 * 3,
            "thresholds": [0, 2, 4],
            "max_sample_error": max(r["max_sample_error"] for r in rows),
            "closed_gate_pixels_bitexact_to_parent": True,
            "rows": rows,
        },
    )
    print(score_checks, len(rows), max(r["max_sample_error"] for r in rows))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--smoke", action="store_true")
    main(p.parse_args().smoke)
