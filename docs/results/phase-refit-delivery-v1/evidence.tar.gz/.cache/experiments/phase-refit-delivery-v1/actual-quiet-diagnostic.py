"""Match measured mean quiet RMS using a descriptive post-hoc uniform scale."""

from pathlib import Path

import numpy as np
from scipy.optimize import brentq

from demosaic.experiments.artifacts import read_json, reference, write_json

root = Path(__file__).resolve().parent
report = root / "review/result.json"
rows = read_json(report)
subset = {"profile": "iso400", "placement": "far"}
budget = 0.02
selected = [
    v
    for v in rows["leave_one_geometry_out"]
    if all(v[k] == value for k, value in subset.items()) and v["budget_DN16"] == budget
]
control = [v for v in selected if v["method"] == "square"]
treatment = [v for v in selected if v["method"] == "weighted-refit"]
assert [v["source"] for v in control] == [v["source"] for v in treatment] == list(range(8))
names = ("quiet_RMS_DN16", "weak_gain", "weak_increment_RMS_DN16", "weak_absent_projection")
moments = [
    [
        v["moments"]
        for v in rows["fixed_threshold_metrics"]
        if all(v[k] == value for k, value in subset.items())
        and v["source"] == row["source"]
        and v["method"] == f"weighted-refit-t{row['threshold']:g}"
    ]
    for row in treatment
]
assert all(len(v) == 4 for v in moments)
model = [{k: np.mean([m[k] for m in v], axis=0) for k in v[0]} for v in moments]


def evaluated(scale):
    result = []
    for row, moments in zip(treatment, model, strict=True):
        amt = scale * row["scale"]
        p = {k: np.polynomial.polynomial.polyval(amt, value) for k, value in moments.items()}
        result.append(
            [
                np.sqrt(p["quiet_mse"]),
                p["weak_gain"],
                np.sqrt(p["weak_increment_mse"]),
                abs(p["weak_absent_projection"]),
            ]
        )
    return np.array(result)


baseline = np.array([[v[k] if k != names[-1] else abs(v[k]) for k in names] for v in control])
calibrated = np.array([[v[k] if k != names[-1] else abs(v[k]) for k in names] for v in treatment])
np.testing.assert_allclose(evaluated(1), calibrated, rtol=0, atol=1e-12)
target = baseline[:, 0].mean()
alpha = brentq(lambda scale: evaluated(scale)[:, 0].mean() - target, 0, 1)
equal = evaluated(alpha)
assert abs(equal[:, 0].mean() - target) < 1e-12
summary = {
    "means": {
        "fold_averaged": dict(zip(names, baseline.mean(0).tolist(), strict=True)),
        "weighted_cross_validated": dict(zip(names, calibrated.mean(0).tolist(), strict=True)),
        "weighted_equal_measured_quiet": dict(zip(names, equal.mean(0).tolist(), strict=True)),
    },
    "source_equal_measured_quiet_differences": [
        dict(zip(names, v.tolist(), strict=True)) for v in equal - baseline
    ],
    "equal_quiet_shared_multiplier": alpha,
    "scope": "One additional common multiplier chosen using exact held-out quiet targets. Retains"
    " each geometry's selected threshold and relative scale. This post-hoc tradeoff is"
    " descriptive and cannot choose an inference operating point.",
    "test": subset,
    "calibration_budget_DN16": budget,
    "report": reference(report),
    "driver": reference(__file__),
}
write_json(root / "actual-quiet-diagnostic.json", summary)
print(summary["means"], alpha)
