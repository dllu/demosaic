"""Preserve the post-validation RAW refit results, native images, and frozen source evidence."""

import gzip
import hashlib
import shutil
import tarfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = Path(__file__).resolve().parent
review = root / "review"
report = read_json(review / "result.json")
audit = read_json(review / "independent-audit.json")
summary = read_json(review / "summary.json")
view = read_json(review / "actual-native-viewing.json")
assert audit["status"] == "passed" and audit["held_out_rows"] == 288
assert (
    len(report["fixed_threshold_metrics"]) == 3072 and report["square_t2_controls_bitexact"] == 392
)
assert len(view["boards"]) == 12 and all(v["viewed"] for v in view["boards"])
images = repo / "docs/images/phase-refit-delivery-v1"
results = repo / "docs/results/phase-refit-delivery-v1"
images.mkdir()
results.mkdir()
rows = []
for label, source in [
    (f"synthetic_{key}", v) for v in report["synthetic_boards"] for key in ("board", "triplet")
] + [("GFX", v) for v in report["camera_boards"]]:
    render = source[label.removeprefix("synthetic_")] if label.startswith("synthetic_") else source
    pixels = checked(render["image"])
    target = images / pixels.name
    shutil.copyfile(pixels, target)
    assert reference(target)["sha256"] == render["image"]["sha256"]
    rows.append(
        {"id": source["id"], "kind": label, "published_image": reference(target), "origin": source}
    )
for source in report["synthetic_boards"]:
    if not source["id"].startswith("iso400"):
        continue
    board = source["board"]
    image = np.asarray(Image.open(checked(board["image"])))
    labels = ("Noisy Malvar", "Weighted refit", "Exact GT")
    lookup = {p["label"]: p for p in board["panels"]}
    canvas = Image.new("RGB", (512, 192), "#eeeeee")
    drawer = ImageDraw.Draw(canvas)
    new_panels = []
    for i, label in enumerate(labels):
        x, y, w, h = lookup[label]["png_xywh"]
        assert w == h == 160
        dx = 8 + 168 * i
        drawer.text((dx, 5), label, fill="black")
        canvas.paste(Image.fromarray(image[y : y + h, x : x + w]), (dx, 24))
        new_panels.append({"label": label, "png_xywh": [dx, 24, w, h]})
    dest = images / f"{source['id']}-weighted-triplet.png"
    canvas.save(dest)
    reread = np.asarray(Image.open(dest))
    for p in new_panels:
        x, y, w, h = lookup[p["label"]]["png_xywh"]
        dx, dy, _, _ = p["png_xywh"]
        np.testing.assert_array_equal(reread[dy : dy + h, dx : dx + w], image[y : y + h, x : x + w])
    record = {
        **board,
        "image": reference(dest),
        "panels": new_panels,
        "source_board": board["image"],
    }
    rows.append(
        {
            "id": source["id"],
            "kind": "synthetic_weighted_triplet",
            "published_image": reference(dest),
            "origin": {**source, "weighted_triplet": record},
        }
    )
figure = images / "quiet-tradeoff.png"
shutil.copyfile(checked(summary["plot"]), figure)
assert reference(figure)["sha256"] == summary["plot"]["sha256"]
write_json(
    images / "manifest.json",
    {
        "images": rows,
        "plot": reference(figure),
        "actual_viewing": reference(review / "actual-native-viewing.json"),
        "scope": "Four native synthetic comparisons and all-site triplets, two additional weighted refit triplets, and eight native GFX boards.",
    },
)
assert len(rows) == 18
for name in ("independent-audit.json", "summary.json", "actual-native-viewing.json"):
    shutil.copyfile(review / name, results / name)
    assert reference(review / name)["sha256"] == reference(results / name)["sha256"]
files = [
    p
    for p in root.rglob("*")
    if p.is_file() and p.suffix in (".py", ".json", ".log") and "__pycache__" not in p.parts
]
for name in ("refit-audit.json", "actual-quiet-diagnostic.json"):
    shutil.copyfile(root / name, results / name)
    assert reference(root / name)["sha256"] == reference(results / name)["sha256"]
assert read_json(root / "refit-audit.json")["direct_refit_images"] == 192
archive = results / "evidence.tar.gz"
members = []
with (
    archive.open("xb") as stream,
    gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as gz,
    tarfile.open(fileobj=gz, mode="w") as tar,
):
    for p in sorted(files):
        name = str(p.relative_to(repo))
        members.append({"member": name, **reference(p)})
        tar.add(p, arcname=name, recursive=False)
with tarfile.open(archive) as tar:
    for v in members:
        assert hashlib.sha256(tar.extractfile(v["member"]).read()).hexdigest() == v["sha256"]
write_json(
    results / "publication.json",
    {
        "archive": reference(archive),
        "members": members,
        "all_member_hashes_verified": True,
        "native_manifest": reference(images / "manifest.json"),
        "native_viewing_count": 12,
        "fixed_threshold_rows": len(report["fixed_threshold_metrics"]),
        "held_out_rows": audit["held_out_rows"],
        "scope": "Complete post-validation RAW refits and standing GFX comparison using retained inputs.",
    },
)
print("Verified", len(members), "archive files and", len(rows), "unresized native images")
