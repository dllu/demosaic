"""Render the prespecified color-gap policy and both standing camera scenes."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import cfa_gap_field as model
from evaluate_cfa_gaps import metric
from view_camera_references import panels
from view_adaptive import board, image

OUT = model.OUT
CROP = model.s.crop
PRIMARY = "Bounded color"


def fields(images, choices, *, camera=False):
    anchor = images["baseline"]
    labels = {
        "baseline": "Regional RAW refit",
        "local_curve": "Earlier local curve",
        "pool": "Whole-region pool",
        "green": "Green connected refit",
        "propose": "Color proposes, green checks",
        "bounded": PRIMARY,
        "unchecked": "Unbounded color",
    }
    displayed = []
    for key, name in labels.items():
        arm, scale = choices[key]
        item = images[arm]
        if scale != 1:
            item = (anchor + scale * (item.astype(float) - anchor)).astype(anchor.dtype)
        displayed.append((name, item))
    if camera:
        displayed.extend(
            (name, images[arm])
            for name, arm in (
                ("Affine green, full", "affine-green"),
                ("Affine bounded, full", "affine-bounded"),
                ("Affine unbounded, full", "affine-unchecked"),
            )
        )
    return displayed


def exact(folder, data, choices):
    plan = read_json(checked(data["plan"]))
    x, y, w, h = plan["query"]
    local = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    selected = {}
    for row in data["rows"]:
        g = row["fixture"]
        if g["geometry"]["stationary_junction"]:
            continue
        group = "red-only" if g["color_case"] == "red-only-gap" else "shared or other conflict"
        for draw in row["draws"]:
            b = metric.values(draw, choices["green"])
            q = metric.values(draw, choices["bounded"])
            change = b[metric.JUNCTION] - q[metric.JUNCTION]
            order = -change if group == "red-only" else change
            if group not in selected or order > selected[group][0]:
                selected[group] = order, row, draw, change
    out = []
    for kind, (_, row, draw, change) in selected.items():
        parent = np.load(checked(draw["outputs"]["local50k"]), allow_pickle=False)[0]
        with np.load(checked(draw["input"]), allow_pickle=False) as f:
            pack = {k: f[k] for k in f.files}
        raw = pack["scene_packed"].copy()
        raw[cut] = pack["packed"][0]
        wb, mx, cfa = (pack[k] for k in ("wb", "matrix", "colors"))
        arms, trace = model.replay(parent, local, raw, cfa, roi, plan["noise"], wb, mx)
        test = fields(arms, choices)
        noisy = noisy_malvar(
            {"packed": pack["packed"][:1], **{k: pack[k][None] for k in ("colors", "wb", "matrix")}}
        )[0]
        values = [
            ("Noisy Malvar", CROP(noisy, local)),
            ("Local 50k", CROP(parent, local)),
            *test,
            ("Exact optical GT", CROP(pack["target"][0], local)),
        ]
        render = {name: image(v, wb, mx, 2) for name, v in values}
        identity = row["id"]
        triplet = board(
            [(k, render[k]) for k in ("Noisy Malvar", PRIMARY, "Exact optical GT")],
            folder / f"{identity}-triplet.png",
        )
        everything = board(list(render.items()), folder / f"{identity}-comparison.png")
        out.append(
            {
                "id": identity,
                "source": row["fixture"],
                "draw": draw["draw"],
                "selection": kind,
                "junction_gain_over_locked_green": change,
                "input": draw["input"],
                "outputs": draw["outputs"],
                "ROI": local,
                "scene_ROI": roi,
                "noise": plan["noise"],
                "exposure": 2,
                "trace": trace,
                "triplet": triplet,
                "all": everything,
            }
        )
        print(identity, kind, change, flush=True)
    return {"rows": out}


def camera(folder, choices):
    ancestor = reference(
        OUT.with_name("adaptive-junction-phase-v1") / "views-camera-all-references.json"
    )
    old = read_json(checked(ancestor))["report"]
    items = []
    for prior in old["rows"]:
        raw = prior["input"]
        with np.load(checked(raw), allow_pickle=False) as f:
            packed, colors, wb, mx = [f[k][0] for k in ("packed", "colors", "wb", "matrix")]
        result = prior["compared"]
        photo = np.load(checked(result), allow_pickle=False)[0]
        roi = prior["local_ROI"]
        arms, trace = model.replay(
            photo, roi, packed, colors, roi, prior["noise"], wb, mx, clearance=16
        )
        trials = fields(arms, choices, camera=True)
        draws = []
        for old_board in prior["native"]:
            ex = old_board["exposure"]
            originals = dict(panels(old_board))
            np.testing.assert_array_equal(
                image(CROP(photo, roi), wb, mx, ex), originals["Local 50k"]
            )
            values = [(k, originals[k]) for k in ("Noisy (Malvar)", "V120 EMA", "Local 50k")]
            values.extend((k, image(v, wb, mx, ex)) for k, v in trials)
            values.extend(
                (k, originals[k])
                for k in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                if k in originals
            )
            drawings = board(values, folder / f"{prior['id']}-x{ex:g}.png")
            draws.append(drawings | {"exposure": ex, "source": old_board})
        distances = {
            label: float(np.sqrt(np.mean((v.astype(float) - arms["baseline"]) ** 2)) * 65535)
            for label, v in trials
        }
        print(prior["id"], {k: round(v, 5) for k, v in distances.items()}, flush=True)
        items.append(
            {
                "id": prior["id"],
                "input": raw,
                "RAW": prior["RAW"],
                "compared": result,
                "ROI": prior["ROI"],
                "local_ROI": roi,
                "noise": prior["noise"],
                "difference_DN16": distances,
                "trace": trace,
                "native": draws,
            }
        )
    return {"source": ancestor, "rows": items}


if __name__ == "__main__":
    role = sys.argv[1]
    folder = OUT / "native" / role
    folder.mkdir(exist_ok=True, parents=True)
    torch.set_num_threads(2)
    cal = reference(OUT / "evaluated-calibration.json")
    choices = read_json(checked(cal))["summary"]["choices"]
    source = None if role == "camera" else reference(OUT / "evaluated-independent.json")
    results = (
        camera(folder, choices)
        if source is None
        else exact(folder, read_json(checked(source)), choices)
    )
    write_json(
        OUT / f"viewed-{role}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "lock": cal,
            "holdout": source,
            "report": results,
        },
    )
