"""Re-render the held color conflicts with a coherent red strand."""

from copy import deepcopy
from pathlib import Path
from time import monotonic
from unittest.mock import patch

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from capture_cfa_gaps import OUT, prior, seed, original_renderer


if __name__ == "__main__":
    torch.set_num_threads(2)
    holdout = reference(OUT / "evaluated-independent.json")
    result = read_json(checked(holdout))
    plan = read_json(checked(result["plan"]))
    cases = [
        p
        for p in result["rows"]
        if p["fixture"]["color_case"] in ("red-continuing", "red-only-gap")
        and p["family"] in ("strip", "ellipse")
    ]
    assert len(cases) == 8
    folder = OUT / "counterfactual"
    folder.mkdir(exist_ok=True)
    start = monotonic()
    records = []
    with patch.object(prior.base, "clean_scenes", original_renderer):
        for row in cases:
            clone = deepcopy(row["fixture"])
            if clone["color_case"] == "red-only-gap":
                clone["geometry"]["family"] = "contrast-step"
            streams = list(prior.base.save_case(clone, seed, plan["noise"], plan["sigma"], folder))
            records.append({"id": row["id"], "inputs": streams, "rendered_fixture": clone})
    write_json(
        OUT / "red-replicas.json",
        {
            "driver": reference(Path(__file__)),
            "holdout": holdout,
            "original_plan": result["plan"],
            "rows": records,
            "seconds": monotonic() - start,
        },
    )
