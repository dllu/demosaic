"""Test the same connected-gap fit with separately measured Bayer colors."""

from dataclasses import dataclass
from pathlib import Path
from unittest.mock import patch
import sys

import numpy as np
from scipy.ndimage import gaussian_filter

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("junction-occlusion-v1")))
import junction_occlusion as previous

phase, s, j = previous.phase, previous.s, previous.j
METHODS = ("green", "propose", "bounded", "unchecked")
ARMS = (
    "baseline",
    "curved",
    "affine",
    "curved-pool",
    "affine-pool",
    *(f"{family}-{mode}" for family in ("curved", "affine") for mode in METHODS),
)
Q0_GREEN_FLOOR = 1.0
Q1_GREEN_FLOOR = 0.65


def coordinates(packed, colors, roi, noise):
    x, y = roi[0] - 48, roi[1] - 48
    planes = [s._sites(packed, x, y, 256, r, c) for r, c in np.ndindex(2, 2)]
    cfa = [colors[2 * ((y + r) % 2) + (x + c) % 2] for r, c in np.ndindex(2, 2)]
    step = j._step_from_discovery(
        np.stack(planes), j._folds() == 0, [k for k, c in enumerate(cfa) if c == 1]
    )
    sites = {}
    row, col = np.indices(j._folds().shape)
    q0 = j._folds() == 0
    density = gaussian_filter(q0.astype(float), 3)
    for name, color in (("red", 0), ("blue", 2)):
        site = cfa.index(color)
        raw = planes[site].astype(float)
        if not np.isfinite(raw).all():
            continue
        floor = gaussian_filter(np.where(q0, raw, 0), 3) / density
        variance = np.maximum(2e-11, noise["shot"] * floor.clip(min=0) + noise["read"])
        u = 2 * col.ravel() + site % 2 - j._CENTER
        v = 2 * row.ravel() + site // 2 - j._CENTER
        a, b = u / 128, v / 128
        design = np.column_stack((np.ones_like(u), a, b, a * a, a * b, b * b))
        if step is not None:
            angle, offset = step
            transition = np.clip(0.5 + (u * np.cos(angle) + v * np.sin(angle) - offset) / 5, 0, 1)
            design = np.c_[design, transition[:, None] * design[:, :3]]
        sites[name] = j._Observation(
            u,
            v,
            np.full_like(u, site),
            raw.ravel(),
            variance.ravel(),
            j._folds().ravel(),
            design,
            np.empty(0),
        )
    return sites


@dataclass
class SiteFit:
    discovery: list
    validation: list
    weights: np.ndarray
    detail: dict


def measure_color(obs, green_template, f, bands, center):
    obs.angles = j._wave_angles(obs.x, obs.y, f)
    angles = s.phases(obs.x, obs.y, green_template.coefficients, f, green_template.curved)
    inner = np.maximum(abs(obs.x), abs(obs.y)) <= 96
    learn = inner & (obs.fold == 0)
    design, _ = s.shape_baseline(obs, f, bands, center, angles)
    features = design[learn]
    weight = 1 / obs.variance[learn]
    basis = features.T * weight
    inverse = np.linalg.pinv(basis @ features, hermitian=True, rcond=1e-9)
    estimate = inverse @ (basis @ obs.raw[learn])
    offset = obs.nuisance.shape[1]
    amplitude = estimate[offset : offset + 4].reshape(2, 2)
    angle = np.arctan2(-amplitude[:, 1], amplitude[:, 0])
    size = np.linalg.norm(amplitude, axis=1)
    sd = np.sqrt(np.diag(inverse)[offset : offset + 4].reshape(2, 2).max(axis=1))
    snr = size / np.maximum(sd, 1e-10)
    qualified = (abs(angle) < np.pi / 3) & (snr >= 2.25)
    if not qualified.any():
        return None
    shifted = angles + angle
    nuisance, _ = s.shape_baseline(obs, f, bands, center + angle, shifted)
    if obs.nuisance.shape[1] == 9:
        nuisance = np.c_[nuisance, np.cos(shifted) * obs.nuisance[:, 6, None]]
    # Only the fields below are needed by the inherited station projection.
    product = np.cos(shifted[:, 0] - shifted[:, 1])
    guide = ColouredTemplate(shifted, nuisance, product)
    picks = previous.grid_scores(obs, guide, inner, 0)
    checks = previous.grid_scores(obs, guide, inner, 1)
    return SiteFit(
        picks,
        checks,
        size * qualified,
        {
            "amplitude_DN16": (size * 65535).tolist(),
            "phase_offset_rad": angle.tolist(),
            "SNR": snr.tolist(),
            "admitted": qualified.tolist(),
        },
    )


@dataclass
class ColouredTemplate:
    angles: np.ndarray
    nuisance: np.ndarray
    signal: np.ndarray


def joint(moment, power, strength, *, bounded):
    raw_power = power * strength**2
    alpha = strength
    if bounded:
        # At each location the two chromatic planes combined have at most the
        # green information. Preserve their relative estimated information.
        chroma = raw_power[1:].sum(axis=0)
        factor = np.sqrt(np.minimum(1.0, raw_power[0] / np.maximum(1e-18, chroma)))
        alpha = np.broadcast_to(strength, power.shape).copy()
        alpha[1:] *= factor
    votes = (moment * alpha).sum(axis=0)
    information = (power * alpha**2).sum(axis=0)
    return votes / np.sqrt(np.maximum(1e-18, information)), votes / np.maximum(1e-18, information)


def attenuation(obs, a, inner, colors, f, bands, center):
    templates, design, energy = previous.bank()
    q0 = previous.grid_scores(obs, a, inner, 0)
    q1 = previous.grid_scores(obs, a, inner, 1)
    green_level = np.maximum(1e-8, [u.beta[u.index] for u in q0])
    choices = {
        name: fit
        for name, data in colors.items()
        if (fit := measure_color(data, a, f, bands, center)) is not None
    }
    lookup = [q0, *(v.discovery for v in choices.values())]
    replication = [q1, *(v.validation for v in choices.values())]
    powers = np.stack([green_level, *(v.weights for v in choices.values())])[:, :, None]
    moments, energy_ = np.moveaxis(
        np.asarray([[u.templates(design, energy) for u in v] for v in lookup]), -2, 0
    )
    base_z = moments[0] / np.sqrt(energy_[0])
    baseline = np.unravel_index(base_z.argmax(), base_z.shape)
    optimized = {}
    diag = {}
    for mode in METHODS:
        if mode == "green" or not choices:
            d, el = baseline
            criterion = float(base_z[d, el])
            signed = None
        else:
            bounded = mode != "unchecked"
            z, _ = joint(moments, energy_, powers, bounded=bounded)
            if bounded:
                z = np.where(base_z >= Q0_GREEN_FLOOR, z, -1e8)
            d, el = np.unravel_index(z.argmax(), z.shape)
            criterion = float(z[d, el])
            signed = bounded
        z0, depth0 = q0[d].fit(design[el], energy[el])
        z1, depth1 = q1[d].fit(design[el], energy[el])
        combined0, combined1 = z0, z1
        if signed is not None:

            def repeat(fits):
                vec = [v[d].templates(design[el : el + 1], energy[el : el + 1]) for v in fits]
                m, p = np.moveaxis(np.asarray(vec), -2, 0)
                z, depth = joint(m, p, powers[:, d], bounded=signed)
                return float(z[0]), float(np.clip(depth[0], 0, 1))

            combined0, d0 = repeat(lookup)
            combined1, d1 = repeat(replication)
            if mode == "bounded":
                depth0, depth1 = min(depth0, d0), min(depth1, d1)
            elif mode == "unchecked":
                depth0, depth1 = d0, d1
        check = z1 if mode in ("green", "propose") else combined1
        delivered = 0.0
        if criterion >= previous.Q0_MIN and check >= previous.REPEATS[0]:
            if mode != "bounded" or z1 >= Q1_GREEN_FLOOR:
                delivered = float(min(depth0, depth1) * np.clip((check - 0.5) / 2, 0, 1))
        region = templates[el]
        optimized[mode] = 1 - delivered * region.deficit(j._GRID_X, j._GRID_Y)
        diag[mode] = {
            "site_count": 1 + sum(int(v.weights[d] > 0) for v in choices.values()),
            "direction": int(d),
            "bank_index": int(el),
            "region": vars(region),
            "green_z": [z0, z1],
            "combined_z": [combined0, combined1],
            "strength": delivered,
        }
    return optimized, diag, {k: v.detail for k, v in choices.items()}


def render(anchor, context, obs, f, bands, center, a, wb, matrix, inner, colors):
    rgb = context[1].copy()
    rgb[s.CROP] = anchor[1]
    yi = (obs.y + j._CENTER).astype(int)
    xi = (obs.x + j._CENTER).astype(int)
    query_rgb = rgb[yi, xi]
    raw_lift = np.linalg.solve(matrix.astype(float), np.ones(3)) / wb
    raw_lift /= raw_lift[1]

    full = s.FULL_X, s.FULL_Y
    angles = s.phases(*full, a.coefficients, f, a.curved)
    stationary = s.stationary_side(*full, j._wave_angles(*full, f), center)
    sign, cap = np.sign(a.amplitude), abs(a.amplitude)
    harmonic = sign * (np.cos(angles[:, 0] - angles[:, 1]) - stationary @ a.station).reshape(
        256, 256
    )
    edge = j._FIELD_EDGE[:, None] * j._FIELD_EDGE
    field = j._GAINS * j._local_wire_support(obs, a.angles) * (harmonic * edge)[s.CROP]
    columns = np.c_[a.nuisance, a.signal]
    index = a.nuisance.shape[1]
    local = j._amplitudes(obs, columns, index, sign, cap, query_rgb, sigma=35, radius=80)
    pool = phase.pool(obs, columns, index, sign, cap, query_rgb)

    def image(amplitude):
        return (anchor + (field * amplitude) * raw_lift[:, None, None]).astype(anchor.dtype)

    images = {"local": image(local[s.CROP]), "pool": image(pool)}
    info, valid = {}, {}
    if pool > 0:
        support, info, valid = attenuation(obs, a, inner, colors, f, bands, center)
        for name, taper in support.items():
            where = taper[s.CROP]
            refit = pool
            if info[name]["strength"] > 0:
                inputs = np.c_[a.nuisance, a.signal * taper[yi, xi]]
                refit = phase.pool(obs, inputs, index, sign, cap, query_rgb)
            images[name] = image(refit * where)
            info[name]["refit_DN16"] = refit * 65535
            info[name]["min_keep"] = float(where.min())
    else:
        images.update(dict.fromkeys(METHODS, images["pool"]))
    return images, info, valid


def replay(nominal, local, packed, colors, roi, noise, wb, matrix, *, clearance=48, geometry=None):
    # The color data is built only for a recipient passing the same green phase check.
    rgb = None

    def deliver(anchor, context, green, f, bands, wb, matrix, *, geometry=None):
        nonlocal rgb
        inner = np.maximum(abs(green.x), abs(green.y)) <= 96
        taper = np.exp(-0.5 * (green.x**2 + green.y**2) / 75**2)
        center = s.stationary(green, inner, taper)
        templates, _ = phase.discover(green, f, bands, inner, taper, center)
        out = dict.fromkeys(ARMS, anchor)
        trace = {}
        for family, a in templates.items():
            ok, parent_note = phase.validate(green, a, inner)
            fits, info, valid = {}, {}, {}
            if ok:
                if rgb is None:
                    rgb = coordinates(packed, colors, roi, noise)
                fits, info, valid = render(
                    anchor, context, green, f, bands, center, a, wb, matrix, inner, rgb
                )
            for arm in ARMS[1:]:
                if arm == family or arm.startswith(family + "-"):
                    key = "local" if arm == family else arm.removeprefix(family + "-")
                    out[arm] = fits.get(key, anchor)
                    trace[arm] = parent_note | {
                        "mode": info.get(key),
                        "admitted": ok,
                        "planes": valid,
                        "change": not np.array_equal(anchor, out[arm]),
                    }
        return out, {"status": "measured", "arms": trace}

    with patch.object(s, "ARMS", ARMS), patch.object(s, "deliver", deliver):
        return s.replay(nominal, local, packed, colors, roi, noise, wb, matrix, clearance=clearance)
