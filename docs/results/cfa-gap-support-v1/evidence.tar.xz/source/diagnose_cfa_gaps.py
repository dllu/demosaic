"""Compare equal-strength color cases and draw the largest red intervention."""

from pathlib import Path
from statistics import mean

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_cfa_gaps import OUT, metric
from cfa_gap_field import j, s, previous

ARMS = ("curved-green", "curved-propose", "curved-bounded", "curved-unchecked")


def same_dose(result):
    rows = result["rows"]
    summary = {}
    for key in sorted({r["fixture"]["color_case"] for r in rows}):
        relevant = [r for r in rows if r["fixture"]["color_case"] == key]
        active = [
            d
            for r in relevant
            for d in r["draws"]
            if not r["fixture"]["geometry"]["stationary_junction"]
        ]
        data = {}
        for arm in ARMS:
            values = [metric.values(d, (arm, 0.4)) for d in active]
            base = [metric.values(d, ("baseline", 1)) for d in active]
            data[arm] = {
                "response_gain": mean(
                    a[metric.RESPONSE] - b[metric.RESPONSE]
                    for a, b in zip(values, base, strict=True)
                ),
                "mean_gap": mean(x[metric.GAP] for x in values if metric.GAP in x)
                if any(metric.GAP in x for x in values)
                else None,
            }
        summary[key] = data
    return summary


def extreme(scan):
    change = []
    for case in scan["rows"]:
        for draw in case["diagnostic"]:
            a, b = (draw["regions"][k] for k in ("observed", "coherent_red"))
            if a["statistics"] is not None:
                delta = a["statistics"]["curved-bounded"] - b["statistics"]["curved-bounded"]
                change.append((delta, case["source"], draw))
    return max(change, key=lambda x: x[0])


def visual(held, intervention):
    delta, identity, draw = extreme(intervention)
    with np.load(checked(draw["observed_input"]), allow_pickle=False) as f:
        truth = f["support"][48:208, 48:208]
    row = next(r for r in held["rows"] if r["id"] == identity)
    original = next(r for r in row["draws"] if r["draw"] == draw["draw"])
    guide = original["trace"][0]["arms"]["curved-green"]["mode"]

    def keep(note):
        shape = previous.Region(**note["region"])
        return (1 - note["strength"] * shape.deficit(j._GRID_X, j._GRID_Y))[s.CROP]

    obs, clean = (draw["regions"][k] for k in ("observed", "coherent_red"))
    frames = (
        ("Exact green support", truth),
        ("Green estimate", keep(guide)),
        ("Observed red", keep(obs["vote"])),
        ("Coherent red", keep(clean["vote"])),
    )
    fig, axes = plt.subplots(1, 4, figsize=(9.1, 2.4), layout="constrained")
    for ax, (title, field) in zip(axes, frames, strict=True):
        im = ax.imshow(field, cmap="viridis", vmin=0, vmax=1, interpolation="nearest")
        ax.set_title(title, fontsize=11)
        ax.set_xticks([])
        ax.set_yticks([])
    cb = fig.colorbar(im, ax=axes, shrink=0.83)
    cb.set_label("Fraction of contrast kept")
    dest = OUT / "red-gap-masks.png"
    fig.savefig(dest, dpi=170)
    return {
        "fixture": identity,
        "draw": draw["draw"],
        "decrease_DN16": delta,
        "before": obs["statistics"],
        "after": clean["statistics"],
        "image": reference(dest),
    }


if __name__ == "__main__":
    source = reference(OUT / "evaluated-independent.json")
    observation = reference(OUT / "red-intervention.json")
    held = read_json(checked(source))
    replica = read_json(checked(observation))
    assert replica["holdout"] == source
    summary = same_dose(held)
    picture = visual(held, replica)
    print(summary, flush=True)
    print(picture, flush=True)
    write_json(
        OUT / "diagnostics.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "intervention": observation,
            "equal_dose": summary,
            "visualization": picture,
        },
    )
