"""Replace only red samples with the coherent counterfactual in paired crops."""

from pathlib import Path
from time import monotonic
from contextlib import nullcontext
from unittest.mock import patch

import numpy as np
import torch
from scipy.ndimage import maximum_filter

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import cfa_gap_field as model

OUT = model.OUT
CHOICES = ("curved-green", "curved-propose", "curved-bounded", "curved-unchecked")
TILE = np.s_[..., 16:144, 16:144]


def summary(result, wb, matrix, mask, doses):
    base = result["baseline"]
    color = (np.array([0.2126, 0.7152, 0.0722]) @ matrix) * wb
    return {
        arm: float(
            np.sqrt(np.mean((color @ (result[arm] - base)[TILE][:, mask]) ** 2))
            * 65535
            * doses[arm]
        )
        for arm in CHOICES
    }


def run(z, current, plan, clear, kind):
    rows = []
    x, y, w, h = plan["query"]
    offset = (48, 48, 160, 160)
    roi = (x + 48, y + 48, 160, 160)
    cut = np.s_[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    valid = current["fixture"]["color_case"]
    for replay, original in zip(z, current["draws"], strict=True):
        assert replay["draw"] == original["draw"]
        with np.load(checked(original["input"]), allow_pickle=False) as f:
            data = {k: f[k] for k in f.files}
        with np.load(checked(replay["data"]), allow_pickle=False) as f:
            copy = {k: f[k] for k in f.files}
        for k in ("colors", "wb", "matrix"):
            np.testing.assert_array_equal(data[k], copy[k])
        # For a red-only gap the new reference has red continuing. Green
        # remains the observed same plane even where the replacement differs.
        source = data["scene_packed"].copy()
        source[cut] = data["packed"][0]
        replaced = source.copy()
        site = int(np.flatnonzero(data["colors"] == 0)[0])
        adjusted = data["packed"][0].copy()
        adjusted[site] = copy["packed"][0, site]
        replaced[cut] = adjusted
        assert np.any(replaced[site] != source[site])
        for r in set(range(4)) - {site}:
            np.testing.assert_array_equal(source[r], replaced[r])
        config = [data[k] for k in ("colors", "wb", "matrix")]
        wb, matrix = config[1:]
        noise = plan["noise"]
        parent = np.load(checked(original["outputs"]["local50k"]), allow_pickle=False)[0]
        variants = {}
        for label, bayer in (("observed", source), ("coherent_red", replaced)):
            lock = (
                nullcontext()
                if label == "observed"
                else patch.object(model.s, "refine_raw_mesh_carriers", return_value=fixed_anchor)
            )
            with lock:
                estimates, trace = model.replay(
                    parent, offset, bayer, config[0], roi, noise, wb, matrix
                )
            if label == "observed":
                fixed = estimates["curved-green"]
                fixed_anchor = estimates["baseline"]
            else:
                np.testing.assert_array_equal(fixed, estimates["curved-green"])
            guide = trace["arms"].get("curved-bounded", {})
            footprint = data["support"]
            mask = ((footprint == 0) & (maximum_filter(footprint, 7, mode="nearest") == 0))[
                64:192, 64:192
            ]
            variants[label] = {
                "vote": guide.get("mode"),
                "planes": guide.get("planes"),
                "changed": guide.get("change"),
                "statistics": (summary(estimates, wb, matrix, mask, clear) if mask.any() else None),
                "difference_from_green_RGB_DN16": {
                    key: float(
                        np.sqrt(
                            np.mean((estimates[key].astype(float) - estimates["curved-green"]) ** 2)
                        )
                        * 65535
                    )
                    for key in CHOICES[1:]
                },
            }
        rows.append(
            {
                "draw": original["draw"],
                "observed_input": original["input"],
                "counterfactual_input": replay["data"],
                "model": original["outputs"]["local50k"],
                "red_plane": site,
                "color_case": valid,
                "geometry": kind,
                "regions": variants,
            }
        )
    return rows


def main():
    torch.set_num_threads(2)
    bound = reference(OUT / "evaluated-independent.json")
    result = read_json(checked(bound))
    plan = read_json(checked(result["plan"]))
    replica = reference(OUT / "red-replicas.json")
    seen = read_json(checked(replica))
    assert seen["holdout"] == bound and seen["original_plan"] == result["plan"]
    cases = {row["id"]: row for row in result["rows"]}
    scales = {
        "curved-" + k: result["summary"]["choices"][k][1]
        for k in ("green", "propose", "bounded", "unchecked")
    }
    start = monotonic()
    output = []
    for row in seen["rows"]:
        current = cases[row["id"]]
        side = row["inputs"]
        rows = run(side, current, plan, scales, current["family"])
        output.append({"source": current["id"], "inputs": side, "diagnostic": rows})
        for r in rows:
            variants = r["regions"]
            print(
                current["id"],
                r["draw"],
                r["color_case"],
                [
                    (k, v["statistics"], v["vote"]["bank_index"] if v["vote"] else None)
                    for k, v in variants.items()
                ],
                flush=True,
            )
    write_json(
        OUT / "red-intervention.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "holdout": bound,
            "replica": replica,
            "rows": output,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
