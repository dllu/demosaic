"""Freeze the color variants on earlier images and replay controlled color conflicts."""

from collections import Counter
from itertools import product
from pathlib import Path
from statistics import mean
from unittest.mock import patch
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import cfa_gap_field as model
import evaluate_occlusion as earlier

metric = earlier.metric
OUT = model.OUT
BASE = earlier.BASE
LOCKS = {
    k: tuple(f"{f}-{k}" for f in ("affine", "curved"))
    for k in ("green", "propose", "bounded", "unchecked", "pool")
}
FIXED = {
    "baseline": BASE,
    "local_curve": ("curved", 1),
    "full_green": ("curved-green", 1),
    "prior_green": ("curved-green", 0.55),
    "full_pool": ("curved-pool", 1),
}


def collect(src):
    replay = earlier.earlier.spatial_eval
    with patch.object(replay, "model", model):
        return replay.collect(src, oracle=False)


def lock(rows):
    subsets = earlier.earlier.panel_rows(rows)
    max_stat = metric.score(subsets["stationary"], BASE)["means"][metric.JUNCTION]
    result = {}
    for key, arms in LOCKS.items():
        trials = []
        for arm, dose in product(arms, np.linspace(0, 1, 21)):
            selection = (arm, float(dose))
            panels = {
                k: metric.score(subsets[k], selection) for k in ("all", "varying", "stationary")
            }
            ok = earlier.earlier.spatial_eval.within(panels["all"], panels["stationary"], max_stat)
            trials.append({"choice": selection, "panels": panels, "allowed": ok})
        choice = max(
            (x for x in trials if x["allowed"]),
            key=lambda x: (
                x["panels"]["varying"]["means"][metric.RESPONSE],
                -x["panels"]["varying"]["means"][metric.JUNCTION],
            ),
        )
        result[key] = {"locked": choice["choice"], "trials": trials}
    return {"limits": earlier.LIMITS, "groups": result}


def summarize(rows, policy):
    panels = earlier.earlier.panel_rows(rows)
    choices = FIXED | {k: v["locked"] for k, v in policy["groups"].items()}
    data = {}
    for key, subset in panels.items():
        data[key] = {n: metric.score(subset, v) for n, v in choices.items()}
        for n, v in choices.items():
            if v != BASE:
                data[key][n]["versus_anchor"] = metric.paired(subset, v, BASE)
    matched = {}
    for name in ("propose", "bounded", "unchecked"):
        arm, dose = choices[name]
        targets = (arm.split("-")[0] + "-green", arm.split("-")[0] + "-pool")
        current = data["all"][name]["means"][metric.GAP]
        matched[name] = {
            "held_gap": current,
        }
        for reference_ in targets:
            base = metric.score(panels["all"], (reference_, 1))["means"][metric.GAP]
            alpha = min(1.0, current / base) if base > 0 else 0.0
            label = reference_.split("-")[1]
            matched[name][label] = {
                "reference": (reference_, alpha),
                "actual_reference_gap": alpha * base,
                "paired": metric.paired(panels["varying"], (arm, dose), (reference_, alpha)),
            }

    details = {}
    for color in sorted({r["fixture"].get("color_case", "neutral") for r in rows}):
        subset = [r for r in rows if r["fixture"].get("color_case", "neutral") == color]
        varying = [r for r in subset if not r["fixture"]["geometry"]["stationary_junction"]]
        examples = [v for r in varying for v in r["draws"]]
        numbers = {}
        for name, choice in choices.items():
            scores = [metric.values(v, choice) for v in examples]
            means = {
                k: mean(s[k] for s in scores if k in s)
                for k in metric.METRICS
                if any(k in s for s in scores)
            }
            events = [d["trace"][0]["arms"].get(choice[0], {}) for d in examples]
            stats = [v["mode"] for v in events if v.get("mode")]
            numbers[name] = {
                "means": means,
                "tapers": sum(v["strength"] > 0 for v in stats),
                "sites": dict(Counter(str(v["site_count"]) for v in stats)),
                "admitted": sum(v.get("admitted", False) for v in events),
            }
        details[color] = {
            "sources": len(subset),
            "variable_sources": len(varying),
            "results": numbers,
        }
    return {"panels": data, "choices": choices, "equal_gap": matched, "color_cases": details}


def reproduce(rows, expected):
    assert len(rows) == len(expected["rows"])
    total = 0
    for new, before in zip(rows, expected["rows"], strict=True):
        assert new["id"] == before["id"]
        for a, b in zip(new["draws"], before["draws"], strict=True):
            assert a["input"] == b["input"]
            for family in ("curved", "affine"):
                for k, v in a["power"][family + "-green"].items():
                    np.testing.assert_array_equal(v, b["power"][family + "-refit"][k])
                    total += 1
    return total


def main(group):
    data = model.previous.OUT if group == "calibration" else OUT
    source = reference(data / "independent/parent/result.json")
    rows, plan, seconds = collect(source)
    config = None if group == "calibration" else reference(OUT / "evaluated-calibration.json")
    policy = lock(rows) if config is None else read_json(checked(config))["policy"]
    result = summarize(rows, policy)
    parity = None
    if group == "calibration":
        prior = reference(data / "evaluated-independent.json")
        parity = {
            "source": prior,
            "exact_metric_values": reproduce(rows, read_json(checked(prior))),
        }
    print("Locked", result["choices"], flush=True)
    for name, row in result["panels"]["varying"].items():
        print(
            name,
            [round(row["means"][k], 6) for k in (metric.RESPONSE, metric.JUNCTION)],
            round(result["panels"]["all"][name]["means"][metric.GAP], 6),
            flush=True,
        )
    for arm, items in result["equal_gap"].items():
        print(
            arm,
            items["held_gap"],
            {
                g: v["paired"][metric.RESPONSE]["interval"]
                for g, v in items.items()
                if g != "held_gap"
            },
            flush=True,
        )
    write_json(
        OUT / f"evaluated-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "operator": reference(model.__file__),
            "source": source,
            "plan": plan,
            "calibration": config,
            "policy": policy,
            "summary": result,
            "rows": rows,
            "seconds": seconds,
            "parity": parity,
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
