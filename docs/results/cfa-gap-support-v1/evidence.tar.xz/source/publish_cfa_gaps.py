"""Publish control replays, native crops and the matched red intervention."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from cfa_gap_field import OUT, HERE

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "evaluated-calibration",
    "evaluated-independent",
    "audit",
    "ordinary",
    "viewed-exact",
    "viewed-camera",
    "red-replicas",
    "red-intervention",
    "diagnostics",
    "independent/plan",
    "independent/inputs",
    "independent/parent/result",
)


def bind(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def preserved(item):
    src = checked(item["image"])
    dest = ASSETS / src.name
    shutil.copyfile(src, dest)
    with Image.open(dest) as im:
        for panel in item.get("panels", []):
            x, y, w, h = panel["png_xywh"]
            assert w == h == 160 and x + w <= im.width and y + h <= im.height
    ref = bind(dest)
    assert ref["sha256"] == item["image"]["sha256"]
    return item | {"image": ref}


def check_panel(receipt):
    source = read_json(checked(receipt["source"]))
    inputs = read_json(checked(source["inputs"]))
    assert receipt["plan"] == inputs["plan"]
    plan = read_json(checked(receipt["plan"]))
    names = set()
    for g, a, b, r in zip(
        plan["sources"], inputs["observations"], source["records"], receipt["rows"], strict=True
    ):
        assert g["id"] == a["id"] == b["id"] == r["id"] and r["fixture"] == g
        f = g["source"]
        ids = {f["id"], f["cache_sha256"]}
        assert names.isdisjoint(ids) and f["split"] == "val"
        names.update(ids)
        checked({"path": f["cache"], "sha256": f["cache_sha256"]})
        for raw, pred, scored in zip(a["streams"], b["streams"], r["draws"], strict=True):
            assert (
                raw["data"] == pred["data"] == scored["input"]
                and pred["outputs"] == scored["outputs"]
            )
            checked(raw["data"])
            for key in pred["outputs"].values():
                checked(key)
    for ck in source["weights"].values():
        checked(ck)
    return names, source["weights"]


def main():
    refs = {k: reference(OUT / f"{k}.json") for k in RECEIPTS}
    payload = {k: read_json(checked(v)) for k, v in refs.items()}
    for data in payload.values():
        for k in ("driver", "operator"):
            if k in data:
                checked(data[k])
    cal, held = (payload[f"evaluated-{k}"] for k in ("calibration", "independent"))
    assert (
        held["calibration"] == refs["evaluated-calibration"]
        and held["plan"] == refs["independent/plan"]
    )
    assert (
        held["source"] == refs["independent/parent/result"]
        and cal["parity"]["exact_metric_values"] > 1000
    )
    assert cal["plan"] == payload["independent/plan"]["previous_gap_sources"]
    a, weights = check_panel(cal)
    b, other = check_panel(held)
    assert len(a) == len(b) == 64 and a.isdisjoint(b) and weights == other
    both = payload["independent/plan"]["excluded_spatial_panels"] + [
        payload["independent/plan"]["additional_exclusion"]
    ]
    for r in both:
        assert all(
            {x["source"]["id"], x["source"]["cache_sha256"]}.isdisjoint(b)
            for x in read_json(checked(r))["sources"]
        )
    assert payload["viewed-exact"]["holdout"] == refs["evaluated-independent"]
    for k in ("viewed-exact", "viewed-camera"):
        assert payload[k]["lock"] == refs["evaluated-calibration"]
    intervention = payload["red-intervention"]
    assert (
        payload["red-replicas"]["holdout"]
        == intervention["holdout"]
        == refs["evaluated-independent"]
    )
    assert (
        intervention["replica"] == refs["red-replicas"]
        and payload["diagnostics"]["intervention"] == refs["red-intervention"]
    )
    assert len(intervention["rows"]) == 8
    for r in intervention["rows"]:
        for d in r["diagnostic"]:
            for k in ("observed_input", "counterfactual_input", "model"):
                checked(d[k])
    assert not any(any(m.values()) for m in payload["ordinary"]["changes"].values())
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    camera = payload["viewed-camera"]["report"]["rows"]
    exact = payload["viewed-exact"]["report"]["rows"]
    assert len(camera) == 8 and len(exact) == 2
    for row in exact:
        for k in ("triplet", "all"):
            row[k] = preserved(row[k])
    for row in camera:
        for out in row["native"]:
            labels = {k["label"] for k in out["panels"]}
            assert "ISO100 AHD reference" in labels
            if row["id"].startswith("mesh-"):
                assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= labels
        row["native"] = [preserved(m) for m in row["native"]]
    art = preserved(payload["diagnostics"]["visualization"])
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest, {"camera": camera, "exact": exact, "weights": weights, "red_intervention": art}
    )
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            "calibration": cal["summary"],
            "holdout": held["summary"],
            "parity": cal["parity"],
            "audit": payload["audit"]["patterns"],
            "ordinary": payload["ordinary"]["changes"],
            "equal_dose": payload["diagnostics"]["equal_dose"],
            "red_intervention": art,
            "camera_difference_DN16": {r["id"]: r["difference_DN16"] for r in camera},
        },
    )
    members = {f"receipts/{k}.json": v for k, v in refs.items()}
    members.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    for p in (
        "junction-occlusion-v1/junction_occlusion.py",
        "junction-occlusion-v1/capture_occlusion.py",
        "junction-occlusion-v1/evaluate_occlusion.py",
        "adaptive-junction-phase-v1/adaptive_phase_field.py",
        "adaptive-junction-phase-v1/capture_adaptive.py",
        "adaptive-junction-phase-v1/evaluate_adaptive.py",
        "adaptive-junction-phase-v1/view_adaptive.py",
        "adaptive-junction-phase-v1/view_camera_references.py",
        "spatial-junction-phase-v1/junction_phase_field.py",
        "spatial-junction-phase-v1/capture_warped.py",
        "spatial-junction-phase-v1/pool_probe.py",
        "spatial-junction-phase-v1/audit_spatial.py",
        "spatial-junction-phase-v1/ordinary_phase.py",
        "spatial-junction-phase-v1/replay.py",
        "local-junction-support-v1/capture_junction.py",
        "local-junction-support-v1/replay_junction.py",
        "local-junction-support-v1/review_junction.py",
    ):
        members[f"reused/{p}"] = reference(HERE.parent / p)
    for p in (
        "src/demosaic/_mesh_junction.py",
        "src/demosaic/mesh_carrier_fit.py",
        "configs/gfx-qualitative-20231231.json",
        "configs/gfx-green-mesh-20231231.json",
    ):
        members[f"repo/{p}"] = reference(ROOT / p)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as stream:
        for name, ref in members.items():
            stream.add(checked(ref), arcname=name, recursive=False)
    with tarfile.open(archive) as stream:
        assert set(stream.getnames()) == members.keys()
        for name, v in members.items():
            with stream.extractfile(name) as f:
                assert file_digest(f, "sha256").hexdigest() == v["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "archive": bind(archive),
            "native": bind(manifest),
            "summary": bind(summary),
            "members": members,
            "scope": "Frozen connected Bayer support with controlled spectral disagreement",
        },
    )
    print(bind(archive), flush=True)


if __name__ == "__main__":
    main()
