"""Audit phase origins, independently held color evidence and color-only gaps."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
import cfa_gap_field as model
from audit_spatial import F, GEOMETRY, ROI, observation, pack, PRIOR
import ordinary_phase


def run_audit():
    j, s = model.j, model.s
    rng = np.random.default_rng(67850)
    scene_h = scene_w = 544
    x0, y0 = ROI[0] - 48, ROI[1] - 48
    yy, xx = np.indices((scene_h, scene_w))
    x, y = xx - x0 - j._CENTER, yy - y0 - j._CENTER
    setup = s.supplied_phase(GEOMETRY)
    a, b = setup(x.ravel(), y.ravel()).T.reshape(2, scene_h, scene_w)
    region = model.previous.Region("oval", (25, -26), (24, 32), 0.2)
    actual = 1 - region.deficit(x, y)
    raw_voter = rng.normal(0, 0.00025, (scene_h, scene_w))
    findings = {}

    for name, cfa in PATTERNS.items():
        channel = np.asarray(cfa)[(yy % 2) * 2 + xx % 2]
        strength = np.asarray([0.062, 0.024, 0.042])[channel]
        levels = np.asarray([0.23, 0.19, 0.16])[channel]
        start = levels + 0.036 * np.cos(a) + raw_voter
        scenarios = {}
        for behavior in ("shared", "red-only"):
            mask = actual if behavior == "shared" else np.where(channel == 0, actual, 1)
            side = start + mask * (strength * np.cos(b) - 0.009 * np.cos(a - b))

            def inspect(values):
                raw = pack(values)
                green = observation(raw, cfa)
                sites = model.coordinates(raw, cfa, ROI, PRIOR)
                inner = np.maximum(abs(green.x), abs(green.y)) <= 96
                taper = np.exp(-0.5 * (green.x**2 + green.y**2) / 75**2)
                center = s.stationary(green, inner, taper)
                bands = j._distinct_bands(F)
                guide = model.phase.discover(green, F, bands, inner, taper, center)[0]["curved"]
                _, record, eligibility = model.attenuation(
                    green, guide, inner, sites, F, bands, center
                )
                for color, location in (("red", 0), ("blue", 2)):
                    q = sites[color]
                    iy = (q.y + j._CENTER).astype(int) + y0
                    ix = (q.x + j._CENTER).astype(int) + x0
                    np.testing.assert_array_equal(q.raw, values[iy, ix])
                    assert (channel[iy, ix] == location).all()
                return record, eligibility

            traces, eligible = inspect(side)
            if behavior == "shared":
                assert traces["bounded"]["strength"] > 0.6
                assert traces["bounded"]["direction"] == 1
                np.testing.assert_allclose(
                    traces["bounded"]["region"]["center"], region.center, atol=15
                )
            else:

                def depth_at_red_gap(name):
                    t = traces[name]
                    mark = model.previous.Region(**t["region"])
                    return float(mark.deficit(*region.center) * t["strength"])

                at_red_gap = {mode: depth_at_red_gap(mode) for mode in model.METHODS}
                assert at_red_gap["unchecked"] > 0.35, traces
                assert at_red_gap["bounded"] == at_red_gap["propose"] == 0, traces

            for first in (1, 2):
                replaced = side.copy()
                cells = j._folds() >= first
                selected = np.repeat(np.repeat(cells, 2, axis=0), 2, axis=1)
                replaced[y0 : y0 + 256, x0 : x0 + 256][selected] = rng.uniform(
                    0.06, 0.38, size=selected.sum()
                )
                after, after_eligible = inspect(replaced)
                assert after_eligible == eligible
                for arm in model.METHODS:
                    for k in ("direction", "bank_index", "region", "site_count"):
                        assert after[arm][k] == traces[arm][k]
                    for k in ("green_z", "combined_z"):
                        assert after[arm][k][0] == traces[arm][k][0]
                    if first == 2:
                        assert after[arm] == traces[arm]
            scenarios[behavior] = {"votes": traces, "eligibility": eligible, "fold_isolation": True}
            if behavior == "red-only":
                scenarios[behavior]["depth_at_red_gap"] = at_red_gap
        findings[name] = scenarios
    return findings


if __name__ == "__main__":
    if sys.argv[1] == "ordinary":
        with (
            patch.object(ordinary_phase, "model", model),
            patch.object(ordinary_phase, "OUT", model.OUT),
        ):
            ordinary_phase.main()
    else:
        receipt = run_audit()
        write_json(
            model.OUT / "audit.json",
            {
                "driver": reference(Path(__file__)),
                "operator": reference(model.__file__),
                "ROI": ROI,
                "patterns": receipt,
            },
        )
        print("All odd-origin color and isolation constraints passed")
