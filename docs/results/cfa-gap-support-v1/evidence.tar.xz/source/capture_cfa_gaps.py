"""Capture offset shared and conflicting color gaps on separate backgrounds."""

from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / HERE.name
sys.path.insert(0, str(HERE.with_name("junction-occlusion-v1")))
import capture_occlusion as previous

prior = previous.prior
seed = 202611200825
prior_gap = previous.OUT / "independent" / "plan.json"
prior_adaptive = previous.excluded
COLORS = ("shared", "red-continuing", "red-only-gap", "blue-reversed")
original_renderer = prior.warped


def choose(kind, root):
    old = previous.choose(kind, root)
    source = reference(prior_gap)
    protected = {
        a
        for r in read_json(checked(source))["sources"]
        for a in (r["source"]["id"], r["source"]["cache_sha256"])
    }
    # Every geometry group gets each color intervention twice. Across the groups
    # the colored cases avoid an association with the Bayer layout or phase class.
    for row in old["sources"]:
        i = row["index"]
        group, index = divmod(i, 8)
        row["id"] = f"cfa-gap-{i:02d}"
        # Balance each color exactly within the fixture family.
        row["color_case"] = COLORS[((index % 4) * (1 if group % 2 == 0 else 3) + group) % 4]
        r = row["source"]
        assert {r["id"], r["cache_sha256"]}.isdisjoint(protected)
    return old | {
        "driver": reference(__file__),
        "previous_gap_sources": source,
        "connected_capture": reference(previous.__file__),
        "channel_cases": COLORS,
        "scope": "Source-disjoint displaced gaps including red-only loss, retained red and reversed blue.",
    }


def capture(case):
    scenes, green, junctions = original_renderer(case)
    behavior = case["color_case"]
    if behavior == "shared":
        return scenes, green, junctions
    inv = torch.as_tensor(case["camera"]["camera_inverse"], dtype=torch.float32)
    camera_to_source = torch.linalg.inv(inv)
    original = np.array(
        [
            behavior == "red-continuing",
            behavior == "red-only-gap",
            behavior in ("red-only-gap", "blue-reversed"),
        ]
    )
    convert = camera_to_source[:, original] @ inv[original]
    convert = lambda img, mat=convert: torch.einsum("ij,jhw->ihw", mat, img)
    if behavior == "blue-reversed":
        across = -2 * convert(scenes[1] - scenes[3])
        delta = [across, across]
    else:
        added_wire = convert(scenes[2] - scenes[1])
        g = case["geometry"]
        axis = torch.arange(512) - 255.5
        y, x = torch.meshgrid(axis, axis, indexing="ij")
        extent = torch.maximum(x.abs(), y.abs())
        shell = ((159 - extent) / 27).clamp(0, 1)
        distance = x * np.cos(g["angle"]) + y * np.sin(g["angle"]) - g["edge"]
        step = torch.sigmoid(distance / 1.3)
        a, b = prior.fields(x, y, g)
        d0 = a[0] - b[0]
        difference = d0 if g["stationary_junction"] else d0 + a[1] - b[1]
        amplitude = (
            g["relative_interaction_polarity"] * g["interaction_ratio"] * g["strength"][1] / 2
        )
        missing = amplitude * difference.cos() * (0.75 + 0.25 * step) * (1 - green) * shell
        delta = [added_wire + convert(missing.expand(3, -1, -1)), added_wire]
        if behavior == "red-only-gap":
            green = torch.ones_like(green)
            junctions = ((a[0] + a[1]).cos() > 0.55) & ((b[0] + b[1]).cos() > 0.55)
    scenes = tuple(a + delta[i] if i < 2 else a for i, a in enumerate(scenes))
    assert all(float(f.min()) > 0 and float(f.max()) < 1 for f in scenes)
    return scenes, green, junctions


if __name__ == "__main__":
    e = prior.ENGINE.prior
    with (
        patch.object(e, "EXCLUSIONS", (*e.EXCLUSIONS, prior_gap, prior_adaptive)),
        patch.object(prior, "__file__", __file__),
        patch.object(prior, "OUT", OUT),
        patch.object(prior, "choose", choose),
        patch.object(prior, "warped", capture),
        patch.object(previous, "seed", seed),
        patch.object(previous.adaptive, "SEED", seed),
        patch.dict(prior.SEED, {"independent": seed}),
    ):
        prior.main("independent")
