"""Compute source-paired summaries with family-stratified bootstrap intervals."""

from collections import defaultdict
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path("/mnt/external/demosaic/sensor-optical-transfer-v1")
SHARP, *BLUR = ("0.0", "0.55", "0.85")
ALL = (SHARP, *BLUR)
METHODS = ("v120", "parent", "local50k", "global-aligned", "regional-aligned")
PAIRS = tuple((m, "parent") for m in METHODS if m != "parent") + (
    ("regional-aligned", "global-aligned"),
)
METRICS = (
    "fundamental_response", "sharp_normalized_fundamental_response",
    "fundamental_intact_RMS_DN16", "fundamental_false_RMS_DN16",
    "gap_continuing_strong_RMS_DN16", "exact_flat_RMS_DN16",
)


def source_bootstrap(rows, rng):
    strata = defaultdict(list)
    for index, row in enumerate(rows):
        strata[row["family"]].append(index)
    return np.vstack(
        (np.arange(len(rows)), np.hstack([
            rng.choice(ids, (12000, len(ids)), replace=True) for ids in strata.values()
        ]))
    )


def interval(draws):
    return [float(draws[0]), *np.quantile(draws[1:], (.025, .975)).tolist()]


def paired_comparisons(rows, rng):
    summary = {}
    for key in (*METRICS, "target_transfer"):
        eligible = [
            row for row in rows
            if key == "target_transfer" or key in row["scores"][SHARP]["methods"]["parent"]
        ]
        if not eligible:
            continue
        sampled = source_bootstrap(eligible, rng)

        def sample(x):
            return np.asarray(x)[sampled].mean(1)

        def measure(row, sigma, model):
            score = row["scores"][sigma]
            return score[key] if model == "target" else score["methods"][model][key]

        models = ("target",) if key == "target_transfer" else METHODS
        curves = {
            k: {s: sample([measure(r, s, k) for r in eligible]) for s in ALL}
            for k in models
        }
        summary[key] = {
            "count": len(eligible),
            "dose_means": {k: {s: interval(v) for s, v in scores.items()} for k, scores in curves.items()},
            "within_model_change": {
                k: {s: interval(scores[s] - scores[SHARP]) for s in BLUR}
                for k, scores in curves.items()
            },
            "paired_model_effect": {
                f"{k} vs {base}": {
                    s: interval(curves[k][s] - curves[base][s]) for s in ALL
                }
                for k, base in PAIRS if k in curves
            },
            "paired_model_interaction": {
                f"{k} vs {base}": {
                    s: interval(
                        (curves[k][s] - curves[base][s]) -
                        (curves[k][SHARP] - curves[base][SHARP])
                    )
                    for s in BLUR
                }
                for k, base in PAIRS if k in curves
            },
        }
    return summary


def coupled_comparisons(rows, standard, rng):
    assert {r["id"] for r in rows} == set(standard)
    scores = {}
    for key in METRICS:
        eligible = [row for row in rows if key in row["scores"][SHARP]]
        if not eligible:
            continue
        resample = source_bootstrap(eligible, rng)

        def summary(values):
            return interval(np.asarray(values)[resample].mean(1))

        baseline = np.asarray([r["scores"][SHARP][key] for r in eligible])
        assert all(
            row["scores"][SHARP][key] == standard[row["id"]]["scores"][SHARP]["methods"]["local50k"][key]
            for row in eligible
        )
        doses = {}
        for sigma in ALL:
            coupled = np.asarray([r["scores"][sigma][key] for r in eligible])
            original = np.asarray([
                standard[r["id"]]["scores"][sigma]["methods"]["local50k"][key] for r in eligible
            ])
            doses[sigma] = {
                "mean": summary(coupled), "from_sharp": summary(coupled - baseline),
                "from_same_seed": summary(coupled - original),
            }
        scores[key] = {"count": len(eligible), "doses": doses}
    return scores


def main():
    root = reference(ROOT / "result.json")
    result = read_json(checked(root))
    rows = [read_json(checked(r)) for r in result["rows"]]
    assert len(rows) == len({row["id"] for row in rows}) == 32
    assert all(row["input_plan"] == result["input_plan"] for row in rows)
    assert sum(row["scores"][SHARP]["gap_pixels"] > 0 for row in rows) == 16
    ranked = sorted(rows, key=lambda row: row["scores"][SHARP]["sharp_strength"])
    rng = np.random.default_rng(202611192340)
    coupled_ref = reference(ROOT / "coupled/result.json")
    coupled = read_json(checked(coupled_ref))
    coupled_rows = {row["id"]: row for row in coupled["rows"]}
    assert len(coupled_rows) == 32
    weak_ids = {r["id"] for r in ranked[:16]}
    write_json(Path(sys.argv[1]), {
        "result": root, "aggregation": reference(__file__),
        "capture_and_checkpoints": read_json(checked(result["input_plan"])),
        "defined_panel": {
            "count": 32, "gap_sources": 16,
            "bootstrap": "12000 source resamples within each footprint family",
            "reported_interval": "point estimate, percentile 2.5, percentile 97.5",
            "rank": "original clean weak fundamental RMS after nuisance projection, DN16",
            "weakest_half": [row["id"] for row in ranked[:16]],
        },
        "scores": {g: paired_comparisons(cohort, rng)
                   for g, cohort in (("all", rows), ("weakest_half", ranked[:16]))},
        "common_noise": {
            "result": coupled_ref, "observations": read_json(checked(coupled["samples"])),
            "scores": {
                g: coupled_comparisons(cohort, {r["id"]: r for r in selected}, rng)
                for g, cohort, selected in (
                    ("all", list(coupled_rows.values()), rows),
                    ("weakest_half", [coupled_rows[k] for k in sorted(weak_ids)], ranked[:16]),
                )
            },
        },
        "native_crops": [crop for row in rows for crop in row["native"]],
        "run_seconds": result["run_seconds"],
    })


if __name__ == "__main__":
    main()
