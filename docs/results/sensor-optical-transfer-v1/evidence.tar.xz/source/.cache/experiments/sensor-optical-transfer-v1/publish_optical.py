"""Package reproducibility receipts, inputs by hash, and the executed study scripts."""

from pathlib import Path
import subprocess
import sys
import tarfile

import numpy as np

import capture_coupled
import summarize_optical
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = capture_coupled.ROOT
REPORT = Path("docs/results/sensor-optical-transfer-v1")
STUDY = Path(__file__).resolve().parent


def verify_flat_cores(standard, common):
    checked_count = 0
    for original, shared in zip(standard["inputs"], common["inputs"], strict=True):
        assert original["case"] == shared["id"]
        with np.load(checked(original["inputs"]["0.0"]), allow_pickle=False) as sharp:
            for binding in shared["observations"].values():
                with np.load(checked(binding), allow_pickle=False) as blurred:
                    for key in ("packed", "variance"):
                        np.testing.assert_array_equal(
                            sharp[key][3, :, 32:96, 32:96], blurred[key][3, :, 32:96, 32:96]
                        )
                    np.testing.assert_array_equal(
                        sharp["target"][3, :, 64:192, 64:192], blurred["target"][3, :, 64:192, 64:192]
                    )
                    checked_count += 1
    assert checked_count == 64
    return checked_count


def main():
    summary_ref = reference(ROOT / "summary.json")
    summary = read_json(checked(summary_ref))
    collection = read_json(checked(summary["result"]))
    mounted = Path.cwd() / ".cache" / "experiments"
    code = {Path(mod.__file__).resolve() for mod in list(sys.modules.values())
            if getattr(mod, "__file__", None) and Path(mod.__file__).resolve().is_relative_to(mounted)}
    code.add(Path(__file__).resolve())
    flat_checks = verify_flat_cores(summary["capture_and_checkpoints"], summary["common_noise"]["observations"])
    source_checkpoints = summary["capture_and_checkpoints"]["checkpoints"]
    for name, file in source_checkpoints.items():
        assert checked(file).is_file(), name

    native = []
    for board in summary["native_crops"]:
        for kind in ("board", "triplet"):
            archived = board[kind]["image"]
            name = "docs/assets/sensor-optical-transfer/" + Path(archived["path"]).name
            if not Path(name).is_file():
                continue
            local = reference(name)
            assert local["sha256"] == archived["sha256"]
            native.append({"repo_path": name, "sha256": local["sha256"]})
    assert len(native) == 8

    raw = [
        *collection["rows"], summary["result"], summary_ref, collection["input_plan"],
        summary["common_noise"]["result"],
        read_json(checked(summary["common_noise"]["result"]))["samples"],
    ]
    archive = REPORT / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz") as tar:
        for path in sorted(code):
            assert path.is_file(), path
            tar.add(path, arcname="source/" + str(path.relative_to(Path.cwd())), recursive=False)
        for item in raw:
            path = checked(item)
            tar.add(path, arcname="receipts/" + str(path.relative_to(ROOT)), recursive=False)

    write_json(REPORT / "publication.json", {
        "scope": "existing checkpoint replay on 32 off-grid scenes with blur; no training",
        "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "report": "docs/sensor-optical-transfer.md",
        "archive": {"repo_path": str(archive), "sha256": reference(archive)["sha256"]},
        "checkpoints": source_checkpoints, "native_crops": native,
        "capture": {
            "input_plan": collection["input_plan"], "sigma_pixels": (0, .55, .85),
            "gap_erosion_pixels": 3, "sharp_reproduced_fixtures": 32,
            "sharp_predictions_spot_checked": list(source_checkpoints),
            "weights": "EMA", "precision": "CUDA IEEE FP32",
            "sampling": (
                "32 exposures with archived role seeds per dose and a Local 50k supplement"
                " sharing photon counts and read noise across doses"
            ),
        },
        "defined_panel": summary["defined_panel"], "scores": summary["scores"],
        "common_noise": {
            "exact_flat_input_and_target_checks": flat_checks,
            "scores": summary["common_noise"]["scores"],
        },
        "numeric_review": "complete", "native_review": "complete, two fixtures at three blur widths",
    })


if __name__ == "__main__":
    main()
