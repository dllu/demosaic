"""Check dense donor selection on exact wires, absent texture, and natural photos."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time

import numpy as np
from scipy.optimize import brentq

from atlas_probe import BAND, DENSE, POLICIES, ROOT, WIDTH, atlases, fields, patch, replay
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_wide import COMP, FLAT, HOLE, LENGTH, RESPONSE, WireFundamental, values

TIGHT = 64
QUIET = 0.10
KEEP = tuple(POLICIES)


def fields_for_observation(row, data, parent, budget):
    p = row["profile"]
    raw_scene, colors, box = data["scene_packed"], data["colors"], row["box"]
    bank = atlases(raw_scene, colors, box, p, budget=budget)
    if budget == TIGHT and bank["uniform"] is not None:
        # Align the count available to read at tight budget before matching.
        s, r = (p[k] for k in ("shot", "read"))
        n = len(bank["uniform"].coords)
        bank["dense"] = patch.build_exterior(
            raw_scene, colors, box, s, r, band=BAND, max_windows=max(1, n), dense_radius=DENSE
        )
    add = {k: [] for k in KEEP}
    for raw, base in zip(data["packed"], parent, strict=True):
        for k, v in fields(raw, base, colors, box, p, bank).items():
            add[k].append(replay.apply_delta(np.zeros_like(base), v, data["wb"], data["matrix"], 1))
    return {k: np.stack(v) for k, v in add.items()}, {
        k: len(a.coords) if a is not None else 0 for k, a in bank.items()
    }


def score_wire(row):
    d, b, v120 = replay.read_inputs(row)
    with np.load(checked(row["input"]), allow_pickle=False) as f:
        exact = {k: f[k] for k in ("target", "support")}
    metric = WireFundamental(d | exact, row["fixture"]["geometry"])
    anchor = b.astype(np.float64)
    origin = metric(anchor)
    reference_v120 = metric(v120)
    groups = {}
    for budget in (TIGHT, 4800):
        predictions, n = fields_for_observation(row, d, b, budget)
        scores = {}
        for k, delta in predictions.items():
            plus, minus = metric(anchor + delta), metric(anchor - delta)
            resp = {}
            for m, g in origin.items():
                p, z = plus[m], minus[m]
                resp[m] = (
                    [g, (p - z) / 2]
                    if m in RESPONSE
                    else [g * g, (p * p - z * z) / 2, (p * p + z * z) / 2 - g * g]
                )
            scores[k] = resp
        groups[str(budget)] = {
            "terms": scores,
            "origin": origin,
            "v120": reference_v120,
            "windows": n,
            "gap_pixels": int(metric.gap.sum()),
        }
    return {"case": row, "width": groups}


def run(rows, callback):
    result = []
    start = time.monotonic()
    with ThreadPoolExecutor(4) as pool:
        for v in pool.map(callback, rows):
            result.append(v)
            if len(result) % 8 == 0:
                print(len(result), round(time.monotonic() - start, 2), flush=True)
    return result, time.monotonic() - start


def cohort():
    long = reference("/mnt/external/demosaic/scene-patch-width-v1/parents.json")
    short = reference(ROOT.with_name("green-covariance-refit-v1") / "fresh.json")
    a, b = [read_json(checked(x)) for x in (long, short)]
    plan = read_json(checked(b["plan"]))
    assert (
        a["weights"]["parent"]["sha256"] == plan["checkpoints"]["100k"]["sha256"] == replay.BASE_SHA
    )
    exact = []
    for r in b["rows"]:
        if r["source"]["kind"] != "wire":
            continue
        s = r["source"]
        exact.append(
            {
                "id": f"retained-{s['index']:02}",
                "fixture": s,
                "source": s["source"],
                "box": r["box"],
                "profile": plan["profile"],
                "input": r["input"],
                "rgb": r["predictions"],
                "rgb_key": "parent",
                "partition": "retained_short",
            }
        )
    for k in ("id", "cache_sha256"):
        assert not {r["source"][k] for r in exact} & {r["source"][k] for r in a["rows"]}
    assert len(exact) == 24 and len(a["rows"]) == 48
    return {"long": long, "short": short}, a["rows"][:16], a["rows"][16:], exact


def calibrate(rows):
    out = {}
    for budget in (TIGHT, 4800):
        k = str(budget)
        sub = [r["width"][k] for r in rows]
        out[k] = {}
        for mode in KEEP:
            base = values(sub, "origin", FLAT, 0)

            def loss(g):
                return float(np.mean(values(sub, mode, FLAT, g) - base))

            gain = brentq(lambda g: loss(g) - QUIET, 0, 0.8) if loss(0.8) > QUIET else 0.8
            out[k][mode] = {"gain": gain, "flat_DN16": loss(gain)}
    return out


def summarize(rows, settings):
    out = {}
    rng = np.random.default_rng(202611191851)
    for budget in (TIGHT, 4800):
        key = str(budget)
        group = [r["width"][key] for r in rows]
        scores = {}
        for metric in sorted({m for r in group for m in r["origin"]}):
            used = [r for r in group if metric in r["origin"]]
            n = len(used)
            idx = np.vstack((np.arange(n), rng.integers(0, n, size=(8000, n))))
            scale = {"origin": 0, "v120": 0, **{m: o["gain"] for m, o in settings[key].items()}}
            means = {
                mode: values(used, mode, metric, gain)[idx].mean(axis=1)
                for mode, gain in scale.items()
            }
            scores[metric] = {}
            for k, x in means.items():
                p = {"value": float(x[0])}
                for reference_ in ("origin", "uniform", "uniform_near", "dense", "near"):
                    d = x - means[reference_]
                    p[reference_] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
                scores[metric][k] = p
        out[key] = {
            "scores": scores,
            "count": len(group),
            "median_windows": {
                k: float(np.median([r["windows"][k] for r in group])) for k in ("uniform", "dense")
            },
        }
    return out


def natural(case):
    data, parent, v120 = replay.read_inputs(case)
    d, window = fields_for_observation(case, data, parent, 4800)
    with np.load(checked(case["input"]), allow_pickle=False) as z:
        gt = replay.transform(z["target"], data)
    old = replay.transform(parent, data)
    by_mode = {
        k: {f: replay.terms(v, replay.transform(change, data)[f], gt[f]) for f, v in old.items()}
        for k, change in d.items()
    }
    assert v120 is not None
    by_mode["parent"] = {f: replay.terms(v, np.zeros_like(v), gt[f]) for f, v in old.items()}
    by_mode["v120"] = {
        f: replay.terms(v, np.zeros_like(v), gt[f]) for f, v in replay.transform(v120, data).items()
    }
    return {"case": case, "terms": by_mode, "windows": window}


def summarize_natural(rows, selected):
    rng = np.random.default_rng(202611191853)
    idx = np.vstack((np.arange(len(rows)), rng.integers(0, len(rows), (8000, len(rows)))))
    chosen = {"parent": 0, "v120": 0, **{k: v["gain"] for k, v in selected.items()}}
    result = {}
    for band in ("fine", "lower"):
        result[band] = {}
        for metric in ("present", "increment", "flat", "response"):
            v = {
                k: replay.estimate(replay.arrays(rows, k, band, metric), metric, g, idx)
                for k, g in chosen.items()
            }
            result[band][metric] = {}
            for k, q in v.items():
                p = {"value": float(q[0])}
                for base in ("parent", "uniform", "dense"):
                    d = q - v[base]
                    p[base] = [float(d[0]), *np.quantile(d[1:], [0.025, 0.975]).tolist()]
                result[band][metric][k] = p
    return result


def main():
    link, building, testing, short = cohort()
    calibration, seconds = run(building, score_wire)
    locked = ROOT / "calibration.json"
    strengths = calibrate(calibration)
    write_json(
        locked,
        {
            "driver": reference(__file__),
            "model": reference(patch.__file__),
            "inputs": link,
            "quiet_budget_DN16": QUIET,
            "strengths": strengths,
            "calibration": calibration,
            "seconds": seconds,
        },
    )
    development, first = run(testing, score_wire)
    control, second = run(short, score_wire)
    p = reference("/mnt/external/demosaic/scene-patch-crossfit-v1/parents.json")
    photos, third = run(read_json(checked(p))["rows"], natural)
    old = reference(WIDTH / "wire-study.json")
    previous = read_json(checked(old))
    for new, before in zip(development, previous["test"], strict=True):
        assert new["case"]["id"] == before["case"]["id"]
        for name, q in new["width"]["4800"]["terms"]["uniform"].items():
            np.testing.assert_allclose(q, before["terms"]["mid32"][name], rtol=0, atol=1e-9)
    write_json(
        ROOT / "results.json",
        {
            "driver": reference(__file__),
            "lock": reference(locked),
            "legacy_exact_parity": old,
            "natural_parent_rows": p,
            "seconds": {"long": first, "short": second, "natural": third},
            "long": development,
            "short": control,
            "natural": photos,
            "summary": {
                "long": summarize(development, strengths),
                "short": summarize(control, strengths),
                "natural": summarize_natural(photos, strengths["4800"]),
            },
        },
    )


if __name__ == "__main__":
    main()
