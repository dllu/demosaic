"""Compare scene sampling density, proximity and query-sign confirmation."""

from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic import scene_patch_covariance as patch
from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.reporting import display_crop

ROOT = Path(__file__).resolve().parent
OUT = Path("/mnt/external/demosaic") / ROOT.name
WIDTH = ROOT.with_name("scene-patch-width-v1")
BAND = patch.PatchBand(32, 0.08, 0.16)
DENSE = 240
POLICIES = {
    "uniform": ("uniform", False, "donor_and_query"),
    "dense": ("dense", False, "donor_and_query"),
    "uniform_near": ("uniform", True, "donor_and_query"),
    "near": ("dense", True, "donor_and_query"),
    "uniform_donor": ("uniform", False, "donor_validated"),
    "dense_donor": ("dense", False, "donor_validated"),
    "near_donor": ("dense", True, "donor_validated"),
}

sys.path.insert(0, str(WIDTH))
from render_wide import peak_fit, pixels, replay


def atlases(scene, colors, box, profile, budget=4800):
    s, r = (profile[k] for k in ("shot", "read"))
    return {
        k: patch.build_exterior(
            scene, colors, box, s, r, band=BAND, max_windows=budget, dense_radius=rad
        )
        for k, rad in (("uniform", 0), ("dense", DENSE))
    }


def fields(raw, parent, colors, box, profile, bank):
    s, r = (profile[k] for k in ("shot", "read"))
    options = {
        (k, near): patch.corrections(
            raw, parent[1], colors, s, r, box, bank[k], validate_donors=True, prefer_nearby=near
        )
        for k in bank
        for near in (False, True)
    }
    return {k: options[(atlas, nearby)][kind] for k, (atlas, nearby, kind) in POLICIES.items()}


def load_standing():
    binding = reference(WIDTH / "native/standing/result.json")
    first = read_json(checked(binding))
    cross = read_json(checked(first["prior"]))
    lower = read_json(checked(cross["old_camera_review"]))
    coords = read_json(checked(lower["links"]["references"]))
    lookup = {r["id"]: r["native_box"] for r in coords["rows"]}
    return binding, first, lookup


def packed_scene(group):
    ref = group[0]["raw"]
    path = checked(ref)
    assert path.is_relative_to(ROOT.parents[1])
    raw, camera = read_raw(path)
    h, w = (n // 2 * 2 for n in raw.shape)
    return (
        ref,
        np.stack([raw[g // 2 : h : 2, g % 2 : w : 2] for g in range(4)]),
        color_indices(camera.pattern).numpy(),
    )


def exact_query(r, lookup, scene, color):
    x, y, w, h = r["query"]
    bx, by, _, _ = lookup[r["id"]]
    u, v = x - bx, y - by
    xx, yy, ww, hh = r["native_ROI"]
    roi = (xx - x, yy - y, ww, hh)
    raw = scene[:, y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
    with np.load(checked(r["parent_input"]), allow_pickle=False) as f:
        np.testing.assert_array_equal(f["colors"][0], color)
        np.testing.assert_array_equal(
            f["packed"][0, :, v // 2 : (v + h) // 2, u // 2 : (u + w) // 2], raw
        )
        wb, matrix = (f[k][0] for k in ("wb", "matrix"))
    parent = np.load(checked(r["parent_prediction"]), allow_pickle=False)[
        0, :, v : v + h, u : u + w
    ].copy()
    return raw, parent, roi, wb, matrix


def render(img, wb, matrix, roi, exposure):
    v = display_crop(
        torch.from_numpy(img[None]),
        torch.from_numpy(wb[None]),
        torch.from_numpy(matrix[None]),
        roi,
        exposure=exposure,
    )
    return np.rint(np.clip(v, 0, 1) * 255).astype(np.uint8)


def main():
    torch.set_num_threads(2)
    current, saved, lookup = load_standing()
    lock = read_json(checked(saved["strengths"]))
    gain = lock["settings"]["mid32"]["quiet"]
    dest = OUT / "camera"
    dest.mkdir()
    results = []
    start = time.monotonic()
    for family in ("main", "mesh"):
        entries = [r for r in saved["rows"] if r["id"].startswith(family)]
        ref, scene, colors = packed_scene(entries)
        for r in entries:
            assert r["raw"] == ref
            raw, parent, roi, wb, matrix = exact_query(r, lookup, scene, colors)
            banks = atlases(scene, colors, r["query"], r["noise"])
            corrections = fields(raw, parent, colors, r["query"], r["noise"], banks)
            # The nominal matched-flat gain from the width experiment is fixed.
            opt = {
                k: replay.apply_delta(parent, f, wb, matrix, gain) for k, f in corrections.items()
            }
            x, y, w, h = roi
            area = np.s_[..., y : y + h, x : x + w]
            rms = {
                k: float(65535 * np.sqrt(np.mean((p[area].astype(float) - parent[area]) ** 2)))
                for k, p in opt.items()
            }
            np.testing.assert_allclose(rms["uniform"], r["DN16"]["mid32"], rtol=0, atol=1e-10)
            for old in r["displays"]:
                p = pixels(old["board"])
                np.testing.assert_array_equal(
                    p["32 px same band"], render(opt["uniform"], wb, matrix, roi, old["exposure"])
                )
            obs = peak_fit(raw, parent, opt, colors, roi) if family == "mesh" else {}
            ext_count = {}
            x, y, w, h = r["query"]
            for key, atlas in banks.items():
                pos = atlas.coords
                near = (pos[:, 0] >= y - DENSE) & (pos[:, 0] + BAND.size <= y + h + DENSE)
                near &= (pos[:, 1] >= x - DENSE) & (pos[:, 1] + BAND.size <= x + w + DENSE)
                ext_count[key] = {"total": len(pos), "within_240": int(near.sum())}
            archive = dest / f"{r['id']}.npz"
            with archive.open("xb") as of:
                np.savez_compressed(of, parent=parent, raw=raw, wb=wb, matrix=matrix, **corrections)
            results.append(
                {
                    "id": r["id"],
                    "ROI": roi,
                    "absolute_query": r["query"],
                    "input": r["parent_input"],
                    "raw": ref,
                    "parent": r["parent_prediction"],
                    "noise": r["noise"],
                    "patch_counts": ext_count,
                    "strength": gain,
                    "rgb_change_DN16": rms,
                    "projection": obs,
                    "arrays": reference(archive),
                }
            )
            print(r["id"], ext_count, {k: round(v, 3) for k, v in rms.items()}, flush=True)
        del scene
    write_json(
        ROOT / "camera-audit.json",
        {
            "driver": reference(__file__),
            "model": reference(patch.__file__),
            "prior": current,
            "rows": results,
            "duration_seconds": time.monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
