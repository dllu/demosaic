"""View two exact contrasts and both standing RAW scenes at native scale."""

from pathlib import Path
from time import monotonic
import sys

import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from weak_contrast import OUT,qualify
import review_extent as review

LABELS = {'parent':'Local 50k','nested':'Combined check','weak':'Weak posterior','phase_guard':'Fixed phase guard',
          'hard':'Guarded full amplitude','root':'Guarded softer ramp','ring_phase':'Guarded off-band noise',
          'local':'Guarded off-band noise','strict':'Low-gap guarded amplitude'}


def arms(parent,local,scene,colors,roi,peaks,noise,wb,matrix,policy):
    options, trace = qualify(parent,local,scene,colors,roi,peaks,noise,wb,matrix,clearance=16 if local==roi else 48)
    anchor = options['combined']
    result = {'parent':review.view.section(parent,*local),'nested':anchor,'weak':options['weak'],'phase_guard':options['phase_guard']}
    moderate = policy['weak']['selected']
    strict = policy['phase_guard']['selected']
    key = 'ring_phase' if local==roi else 'local'
    entries = {'hard':moderate['guarded_hard'],'root':moderate['guarded_root'],
               key:moderate['guarded_offband'],'strict':strict['guarded_hard']}
    for label, row in entries.items():
        delta = options[row['name']].astype('d')-anchor
        result[label] = (anchor+row['weight']*delta).astype(anchor.dtype)
    return result,trace


def main(kind):
    torch.set_num_threads(2)
    start = monotonic()
    source = reference(OUT/'calibration.json')
    policy = read_json(checked(source))['policy']['equal_added_gap']
    dest = OUT/'boards'/kind
    dest.mkdir(parents=True,exist_ok=True)
    review.OUT=OUT
    review.arms=arms
    review.DISPLAY=LABELS
    if kind=='camera':
        review.view.arcs=arms
        review.view.NAMES=LABELS
        data = review.view.standing(policy,dest)
    else:
        data = review.exact(policy,dest,('weak-contrast-01','weak-contrast-13'),'fresh')
    write_json(OUT/f'board-{kind}.json',{'driver':reference(Path(__file__)),'calibration':source,
                                'data':data,'seconds':monotonic()-start})


if __name__=='__main__':
    main(sys.argv[1])
