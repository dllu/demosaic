"""Check unplanted recipients with authentic and deliberately mismatched RAW context."""

from dataclasses import replace
from pathlib import Path
import sys
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import _spacing
from demosaic.precision import ieee_fp32
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_training_data import scene_seed
from weak_contrast import OUT, qualify, replay
from capture_contrast import prior
from capture_optical import bind_models, filtered_observation, run_model

LOCAL = (48,48,160,160)
ROI = (176,176,160,160)
Q = np.s_[...,64:192,64:192]
R = np.s_[...,128:384,128:384]
CORE = np.s_[...,48:208,48:208]
SEED = 202611200514


def controls():
    binding = reference(OUT/'calibration.json')
    locks = read_json(checked(binding))['policy']['equal_added_gap']
    policy = {'combined':('combined',1),'weak':('weak',1),'phase_guard':('phase_guard',1)}
    for k,v in locks.items():
        used = ('guarded_root','guarded_hard','guarded_offband','offband_noise')
        policy |= {f'{k}/{name}': (r['name'],r['weight']) for name,r in v['selected'].items() if name in used}
    return binding, policy


def scores(input_,parent,scene,profile,policy):
    colors,wb,matrix = [input_[k] for k in ('colors','wb','matrix')]
    candidates, activity = qualify(parent,LOCAL,scene,colors,ROI,
                                   _spacing(scene,colors,*ROI[:2],clearance=48), profile,wb,matrix)
    base = candidates['combined'].astype('d')
    target = input_['target'][CORE].astype('d')
    origin = parent[CORE].astype('d')

    def measure(image):
        rgb = image-origin
        delta = replay.luma(rgb[None],wb,matrix)[0]
        error = replay.luma((image-target)[None],wb,matrix)[0]
        return {'added_RGB_RMS_DN16': float(np.sqrt(np.mean(rgb**2))*65535),
                'added_luma_RMS_DN16': float(np.sqrt(np.mean(delta**2))*65535),
                'restored_luma_RMS_DN16': float(np.sqrt(np.mean(error**2))*65535)}

    return {'parent':measure(origin)} | {k:measure(base+a*(candidates[name].astype('d')-base)) for k,(name,a) in policy.items()},activity


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(min(1,8*2**30/torch.cuda.get_device_properties(0).total_memory))
    start = monotonic()
    calibration, policy = controls()
    plan_ref = reference(OUT/'fresh/plan.json')
    plan = read_json(checked(plan_ref))
    captures = reference(OUT/'fresh/inputs.json')
    roles = read_json(checked(captures))['observations']
    spec = {'local50k':plan['checkpoints']['local50k']}
    model = bind_models(spec)['local50k']
    dest = OUT/'natural'
    dest.mkdir(exist_ok=True)
    results = []
    with ieee_fp32():
        for fixture,row in zip(plan['sources'],roles,strict=True):
            assert fixture['id'] == row['id']
            seed = scene_seed(SEED,fixture['index'],'natural-noise')
            photo = prior.earlier.capture_wide.wire_math.decode(fixture['source'],fixture['box'])
            values = .085+.52*photo
            recipe = replace(sample_scene_recipe(SEED),**(fixture['camera'] | {'noise_seed':seed}))
            observation = filtered_observation(values,recipe,plan['sigma'])
            input_ = {k:getattr(observation,k).numpy() for k in ('colors','wb','matrix')}
            input_.update({k:getattr(observation,k).numpy()[Q][None] for k in ('packed','variance')})
            input_['target'] = observation.target.numpy()[R]
            parent = run_model(model,'local50k',input_,plan['noise'])[0]
            natural = observation.packed.numpy()
            artificial = row['streams'][0]['data']
            with np.load(checked(artificial)) as stream:
                mismatched = stream['scene_packed']
                assert np.array_equal(stream['colors'],input_['colors'])
            mismatched[Q] = input_['packed'][0]
            np.testing.assert_array_equal(natural[Q], mismatched[Q])
            scores_natural, natural_trace = scores(input_,parent,natural,plan['noise'],policy)
            scores_transfer, transfer_trace = scores(input_,parent,mismatched,plan['noise'],policy)
            capture_path = dest/(fixture['id']+'.npz')
            with capture_path.open('xb') as file:
                np.savez(file,**input_,scene_packed=natural,parent=parent)
            results.append({'id':row['id'],'seed':seed,'input':reference(capture_path),'transferred_exterior':artificial,
                            'native':scores_natural,'mismatched':scores_transfer,
                            'native_trace':natural_trace,'mismatched_trace':transfer_trace})
            if len(results)%8 == 0:
                print('Natural and mismatched',len(results),flush=True)
    write_json(OUT/'natural-controls.json',{'driver':reference(Path(__file__)), 'plan':plan_ref,
               'paired_exterior_captures':captures,'calibration':calibration,'weights':spec,'policy':policy,
               'precision':'CUDA IEEE FP32 local50k EMA', 'rows':results,'seconds':monotonic()-start})


if __name__ == '__main__':
    main()
