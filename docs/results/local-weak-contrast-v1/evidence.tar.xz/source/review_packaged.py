"""Render the new public crop method at the frozen exact-target coordinates."""

from pathlib import Path
import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers
from weak_contrast import OUT
from review_contrast import arms as research
import review_extent as review

LABELS = {'parent':'Local 50k','nested':'Combined check','weak':'Weak posterior','phase_guard':'Fixed phase guard',
          'local':'Weak phase contrast','root':'Guarded softer ramp','offband':'Guarded off-band noise'}


def arms(parent,local,scene,colors,roi,peaks,noise,wb,matrix,policy):
    outputs, trace = research(parent,local,scene,colors,roi,peaks,noise,wb,matrix,policy)
    x,y,w,h = local
    context = parent[:,y-16:y+h+16,x-16:x+w+16]
    values = refine_raw_mesh_carriers(outputs['parent'],scene,colors,roi,shot=noise['shot'],read=noise['read'],
             white_balance=wb,camera_to_srgb=matrix,parent_context=context,donor_clearance=48,method='weak-phase-contrast')
    np.testing.assert_allclose(values,outputs['hard'],atol=3e-8,rtol=1e-9)
    return ({k:outputs[k] for k in ('parent','nested','weak','phase_guard')} |
            {'local':values,'root':outputs['root'],'offband':outputs['local']}), trace


def main():
    torch.set_num_threads(2)
    policy = reference(OUT/'calibration.json')
    choices = read_json(checked(policy))['policy']['equal_added_gap']
    directory = OUT/'boards/packaged'
    directory.mkdir(parents=True,exist_ok=True)
    review.OUT = OUT
    review.arms = arms
    review.DISPLAY = LABELS
    data = review.exact(choices,directory,('weak-contrast-01','weak-contrast-13'),'fresh')
    write_json(OUT/'board-packaged.json',{'driver':reference(Path(__file__)), 'calibration':policy,'data':data})


if __name__ == '__main__':
    main()
