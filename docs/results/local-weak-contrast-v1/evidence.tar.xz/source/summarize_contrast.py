"""Reduce matched corpus experiments over independent photo sources."""

from pathlib import Path
from statistics import mean, median
import sys

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from weak_contrast import OUT
from reduce_support import ADDED, FALSE, RESPONSE, compare, evaluate, means, METRICS, QUIET

ABS = 'fundamental_intact_RMS_DN16'
DIAG = {'uncapped':('uncapped',1),'principal':('weak',1),'unguarded_hard':('hard_strength_-5',1),'root_at_existing_odds':('root_strength_-5',1)}


def parity(rows, prior_name):
    archive, name = prior_name
    binding = reference(OUT.parent/archive/f'{name}.json')
    earlier = read_json(checked(binding))['rows']
    maximal = dict.fromkeys(('combined','weak'),0.)
    for a,b in zip(earlier,rows,strict=True):
        assert a['id'] == b['id']
        for one,two in zip(a['draws'],b['draws'],strict=True):
            if 'input' in one:
                assert one['input'] == two['input'] and one['outputs'] == two['outputs']
            for name in maximal:
                for metric, value in one['nominal'][name].items():
                    maximal[name] = max(maximal[name],abs(value-two['nominal'][name][metric]))
    assert max(maximal.values()) < 1e-10, maximal
    return {'receipt':binding,'max_previous_score_difference':maximal}


def lower(a,b,rows,metric):
    first, second = (means(rows,x)[metric] for x in (a,b))
    amount = min(first,second)
    assert min(first,second) >= 0
    return [(name,weight*amount/value) if value > 0 else (name,weight) for (name,weight),value in zip((a,b),(first,second),strict=True)]


def pipeline(rows):
    active = [i for r in rows for d in r['draws'] for i in d['evidence'] if i.get('selected')]
    return {'selected_crops':len(active),'selected_windows':sum(len(i['selected']) for i in active),
        'cap_engaged':sum(i['cap_hits'] for i in active),
        'median_inclusion_strength':median(i['strength'][k] for i in active for k in i['selected']),
        'median_offband_factor':median(i['offband_factor'][k] for i in active for k in i['selected']),
        'phase_eligible_windows':sum(len(i['selected']) for i in active if i['guard_phase_eligible'])}


def quiet(rows,key):
    measures = [evaluate(d,key) for r in rows for d in r['draws']]
    answer = {}
    for metric in QUIET:
        values = [x[metric] for x in measures if metric in x]
        if values:
            answer[metric] = {'max_DN16':max(values),'nonzero_crops':sum(v>0 for v in values)}
    return answer


def audit_natural():
    binding = reference(OUT/'natural-controls.json')
    data = read_json(checked(binding))
    answer = {}
    for kind, tag in (('native','native_trace'),('mismatched','mismatched_trace')):
        r = data['rows']
        score = {}
        for arm in r[0][kind]:
            values = [v[kind][arm] for v in r]
            score[arm] = {k:mean(x[k] for x in values) for k in values[0]}
            score[arm]['maximum_added_RGB_RMS_DN16'] = max(x['added_RGB_RMS_DN16'] for x in values)
            score[arm]['changed_crops'] = sum(x['added_RGB_RMS_DN16']>0 for x in values)
        answer[kind] = {'scores':score,'nominated_pairs':sum(x[tag]['status']!='no frequency' for x in r),
                        'admitted_weak_crops':sum(bool(x[tag].get('selected')) for x in r)}
    return {'source':binding,'panels':answer}


def summarize(rows, selected):
    results = {k:means(rows,v) for k,v in DIAG.items()}
    controls = {k:(k,1) for k in ('combined','weak','phase_guard')}
    results |= {k:means(rows,v) for k,v in controls.items()}
    diagnostics = {k:compare(rows,v,controls['weak']) for k,v in DIAG.items() if k!='principal'}
    policy = {}
    for control, options in selected.items():
        reference_path = controls[control]
        values = {}
        for family, spec in options['selected'].items():
            choice = (spec['name'],spec['weight'])
            score = means(rows,choice)
            match_a, match_b = lower(choice,reference_path,rows,ADDED)
            values[family] = {'choice':choice, 'means':score,
                'frozen_vs_control':compare(rows,choice,reference_path),
                'equal_realized_gap':{'choices':(match_a,match_b),'paired':compare(rows,match_a,match_b)},
                'quiet':quiet(rows,choice)}
        policy[control] = values
    return {'means':results,'diagnostics_vs_weak':diagnostics,'pipeline':pipeline(rows),
            'proposed':policy,'controls_quiet':{k:quiet(rows,v) for k,v in controls.items()}}


def main(names):
    binding = reference(OUT/'calibration.json')
    policy = read_json(checked(binding))['policy']
    previous = {'calibration':('local-phase-extent-v1','calibration'),
                'previous':('local-phase-extent-v1','previous'),'straight':('local-phase-extent-v1','fresh'),
                'curved':('local-phase-transport-v2','curved')}
    result = {}
    for name in names:
        receipt = reference(OUT/f'{name}.json')
        rows = read_json(checked(receipt))['rows']
        data = summarize(rows,policy['equal_added_gap'])
        if name in previous:
            data['baseline_parity'] = parity(rows,previous[name])
        else:
            assert len(rows)==48
            weights = sorted(rows,key=lambda row:row['fixture']['geometry']['strength'][1])
            data['lowest_amplitude_half'] = summarize(weights[:24],policy['equal_added_gap'])
        result[name] = {'source':receipt,'photos':len(rows)} | data
        print(name,data['pipeline'],flush=True)
        for k in ('combined','weak','phase_guard','uncapped','unguarded_hard'):
            v=data['means'][k]; print(k,*[round(v[m],6) for m in (RESPONSE,ABS,ADDED,FALSE)],flush=True)
        for control, scores in data['proposed'].items():
            for k,s in scores.items():
                v=s['means']; print(control,k,*[round(v[m],6) for m in (RESPONSE,ABS,ADDED,FALSE)],
                    s['frozen_vs_control'][RESPONSE]['difference_interval'], flush=True)
    if 'fresh' in names:
        write_json(OUT/'summary.json',{'driver':reference(Path(__file__)),'calibration':binding,
                    'panels':result,'natural_controls':audit_natural()})


if __name__ == '__main__':
    main(sys.argv[1:])
