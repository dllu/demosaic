"""Freeze equal-gap operating points and replay independent observations."""

from pathlib import Path
from statistics import mean
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import weak_contrast as model
from weak_contrast import OUT, replay
import replay_exterior_support as template
from reduce_support import RESPONSE, ADDED, FALSE

PANEL = {'straight': 'local-phase-extent-v1/fresh', 'previous': 'local-conditional-posterior-v1/fresh',
         'curved': 'local-phase-transport-v2/fresh', 'fresh': 'local-weak-contrast-v1/fresh'}


def averages(rows, arm, weight):
    samples = [replay.metrics_at(d['powers'][arm],weight) for r in rows for d in r['draws']]
    return {k:mean(d[k] for d in samples if k in d) for k in (RESPONSE,ADDED,FALSE,'flat_added_DN16')}


def lock(rows):
    controls = {key:averages(rows,key,1) for key in ('combined','weak','phase_guard')}
    options = {}
    for control in ('weak','phase_guard'):
        budget = controls[control][ADDED]
        families = {k:[] for k in model.METHODS}
        for method,_,_,name in model.OPTIONS:
            full = averages(rows,name,1)
            weight = min(1.,budget / max(1e-20,full[ADDED]))
            score = averages(rows,name,weight)
            assert score[ADDED] <= budget + 1e-9
            families[method].append({'name':name,'weight':weight,'score':score})
        options[control] = {'budget':budget,'trial':families,'selected':{
            method:max(candidates,key=lambda row:(row['score'][RESPONSE],-row['score'][FALSE]))
            for method,candidates in families.items()}}
    return {'controls':controls,'equal_added_gap':options}


def main(name):
    torch.set_num_threads(2)
    start = monotonic()
    template.model = model
    replay.comparisons = template.assess
    replay.OUT = OUT
    if name == 'curved':
        sys.path.insert(0,str(Path(__file__).resolve().parent.with_name('local-phase-transport-v2')))
        from replay_transport import CurvedFundamental
        replay.WireFundamental = CurvedFundamental
    bindings = {'driver':reference(Path(__file__)), 'operator':reference(model.__file__)}
    if name == 'calibration':
        source, rows = replay.load_calibration()
        write_json(OUT/'calibration.json',bindings | {'source':source, 'rows':rows, 'policy':lock(rows),'seconds':monotonic()-start})
        return
    path = OUT.parent/PANEL[name]
    replay.PREVIOUS = path
    calibration = reference(OUT/'calibration.json')
    assert read_json(checked(calibration))['operator'] == bindings['operator']
    source,plan,rows = replay.load_confirmation()
    write_json(OUT/f'{name}.json',bindings | {'source':source, 'plan':plan, 'rows':rows, 'calibration':calibration, 'seconds':monotonic()-start})


if __name__ == '__main__':
    main(sys.argv[1])
