"""Compare the packaged contrast option with the locked research arm."""

from pathlib import Path
from statistics import median
from time import monotonic

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.mesh_carrier_fit import _spacing,refine_raw_mesh_carriers
from weak_contrast import OUT,replay,qualify
from review_presence import FIXED,arrays,section

METHODS = ('weak-phase-contrast','weak-phase-guard')


def check(full,local,raw,colors,roi,noise,wb,matrix,*,research_choice):
    x,y,w,h = local
    parent = section(full,*local)
    context = full[:,y-16:y+h+16,x-16:x+w+16]
    halo = 16 if local==roi else 48
    freq = _spacing(raw,colors,*roi[:2],clearance=halo)
    controls, trace = qualify(full,local,raw,colors,roi,freq,noise,wb,matrix,clearance=halo)
    kwargs = {'shot':noise['shot'],'read':noise['read'],'white_balance':wb,'camera_to_srgb':matrix,
              'parent_context':context,'donor_clearance':halo}
    results, elapsed = {}, {}
    for method in METHODS:
        start = monotonic()
        results[method] = refine_raw_mesh_carriers(parent,raw,colors,roi,method=method,**kwargs)
        elapsed[method] = monotonic()-start
    eligible = trace.get('guard_phase_eligible',False)
    if not eligible:
        np.testing.assert_array_equal(results[METHODS[0]],results[METHODS[1]])
    variations = {method:float(np.max(abs(results[method].astype('d')-controls[target]))*65535)
                  for method,target in zip(METHODS,(research_choice,'phase_guard'),strict=True)}
    assert max(variations.values()) < .003, variations
    return {'separate_phase_available':eligible,'differences_DN16':variations,'seconds':elapsed,
            'different_from_guard':not np.array_equal(results[METHODS[0]],results[METHODS[1]])}


def main():
    torch.set_num_threads(2)
    source = reference(OUT/'fresh.json')
    data = read_json(checked(source))
    plan = read_json(checked(data['plan']))
    cal = read_json(checked(data['calibration']))['policy']['equal_added_gap']['weak']['selected']['guarded_hard']
    assert cal['name']=='guarded_hard_-5' and cal['weight']==1
    sample_region = np.s_[...,64:192,64:192]
    x,y,*_ = plan['query']
    local = replay.ROI
    roi = (x+local[0],y+local[1],*local[2:])
    fresh = []
    options = {'research_choice':cal['name']}
    for row in data['rows']:
        for d in row['draws']:
            files = replay.arrays(d['input'])
            copies = np.load(checked(d['outputs']['local50k']))
            raw = files['scene_packed'].copy()
            group = []
            for output, values in zip(copies,files['packed'],strict=True):
                raw[sample_region] = values
                group.append(check(output,local,raw,files['colors'],roi,plan['noise'],files['wb'],files['matrix'],**options))
            fresh.append({'source':row['id'],'draw':d['draw'],'crops':group})
        if len(fresh)%16==0:
            print('Paired source draws compared',len(fresh),flush=True)
    standing = reference(FIXED)
    camera = []
    for row in read_json(checked(standing))['standing']:
        sample = arrays(row['input'])
        raw,colors,wb,matrix = (sample[k][0] for k in ('packed','colors','wb','matrix'))
        parent = np.load(checked(row['predictions']['local50k']))[0]
        roi = tuple(row['local_ROI'])
        camera.append({'id':row['id'],'results':check(parent,roi,raw,colors,roi,row['noise'],wb,matrix,**options)})
    fresh_cases = [case for x in fresh for case in x['crops']]
    all_cases = fresh_cases + [case['results'] for case in camera]
    grouped = {'all_crops':fresh_cases, 'eligible_crops':[r for r in fresh_cases if r['separate_phase_available']]}
    timing = {k:{m:1000*median(c['seconds'][m] for c in v) for m in METHODS} for k,v in grouped.items()}
    write_json(OUT/'api-proof.json',{'driver':reference(Path(__file__)),'source':source,'camera_source':standing,
        'production_sources':{p:reference(p) for p in ('src/demosaic/mesh_carrier_fit.py','src/demosaic/_mesh_weak_posterior.py',
            'src/demosaic/_mesh_weak_phase.py')},'case_results':fresh,'camera_results':camera,
        'maximum_difference_DN16':max(x['differences_DN16'][METHODS[0]] for x in all_cases),
        'active_crop_count':sum(x['separate_phase_available'] for x in fresh_cases),'median_cpu_ms':timing})


if __name__=='__main__':
    main()
