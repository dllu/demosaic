"""Publish the verified contrast method, exact targets and native review."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from weak_contrast import HERE,OUT

ROOT = Path.cwd()
ASSETS = ROOT/'docs/assets'/HERE.name
RESULTS = ROOT/'docs/results'/HERE.name
RECEIPTS = ('calibration.json','previous.json','straight.json','curved.json','fresh.json',
            'fresh/plan.json','fresh/inputs.json','fresh/parent/result.json','noise-audit.json',
            'natural-controls.json','summary.json','chart.json','board-camera.json','board-exact.json',
            'board-packaged.json','api-proof.json')


def published(path):
    return reference(path) | {'path':str(path.relative_to(ROOT))}


def image(binding):
    src = checked(binding)
    target = ASSETS/src.name
    shutil.copyfile(src,target)
    result = published(target)
    assert result['sha256'] == binding['sha256']
    return result


def board(data):
    binding = image(data['image'])
    with Image.open(ROOT/binding['path']) as png:
        for cell in data['panels']:
            x,y,w,h = cell['png_xywh']
            assert (w,h)==(160,160)
            assert 0 <= x < x+w <= png.width and 0 <= y < y+h <= png.height
    return data | {'image':binding}


def main():
    ASSETS.mkdir(exist_ok=True,parents=True)
    RESULTS.mkdir(exist_ok=True,parents=True)
    refs = {key:reference(OUT/key) for key in RECEIPTS}
    data = {key:read_json(checked(value)) for key,value in refs.items()}
    for row in data.values():
        for key in ('driver','operator'):
            if key in row:
                checked(row[key])
    for name in ('previous','straight','curved','fresh','natural-controls','board-camera','board-exact','board-packaged'):
        assert data[f'{name}.json']['calibration'] == refs['calibration.json']
    assert data['board-packaged.json']['data']['receipt'] == refs['fresh.json']
    assert data['board-exact.json']['data']['receipt'] == refs['fresh.json']
    assert data['fresh.json']['plan'] == refs['fresh/plan.json']
    assert data['fresh.json']['source'] == refs['fresh/parent/result.json']
    assert data['fresh/parent/result.json']['inputs'] == refs['fresh/inputs.json']
    assert data['fresh/inputs.json']['plan'] == refs['fresh/plan.json']
    assert data['chart.json']['summary'] == refs['summary.json']
    assert data['natural-controls.json']['paired_exterior_captures'] == refs['fresh/inputs.json']
    proof = data['api-proof.json']
    assert proof['source'] == refs['fresh.json'] and proof['maximum_difference_DN16'] < .002
    assert sum(len(row['crops']) for row in proof['case_results']) == 576 and len(proof['camera_results']) == 8
    for row in data['fresh/parent/result.json']['records']:
        for draw in row['streams']:
            checked(draw['data'])
            for prediction in draw['outputs'].values():
                checked(prediction)
    for row in data['natural-controls.json']['rows']:
        checked(row['input'])
    evidence = {f'receipts/{name}':v for name,v in refs.items()}
    evidence.update({f'source/{p.name}':reference(p) for p in sorted(HERE.glob('*.py'))})
    evidence.update(proof['production_sources'])
    evidence['tests/test_mesh_carrier_fit.py'] = reference(ROOT/'tests/test_mesh_carrier_fit.py')
    archive = RESULTS/'evidence.tar.xz'
    with tarfile.open(archive,'x:xz') as tar:
        for key,binding in evidence.items():
            tar.add(checked(binding),arcname=key,recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == evidence.keys()
        for name,value in evidence.items():
            with tar.extractfile(name) as blob:
                assert hashlib.file_digest(blob,'sha256').hexdigest() == value['sha256']
    camera = [x | {'native':[board(a) for a in x['native']]} for x in data['board-camera.json']['data']['rows']]
    exact = [x | {'board':board(x['board']),'triplet':board(x['triplet'])}
             for x in data['board-packaged.json']['data']['boards']]
    manifest = ASSETS/'manifest.json'
    write_json(manifest,{'camera':camera,'exact':exact,'chart':image(data['chart.json']['image'])})
    summary = RESULTS/'summary.json'
    shutil.copyfile(checked(refs['summary.json']),summary)
    assert published(summary)['sha256'] == refs['summary.json']['sha256']
    before = ('local-weak-support-v1','local-phase-extent-v1','local-phase-transport-v2')
    write_json(RESULTS/'publication.json',{
        'parent_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'summary':published(summary),'native_manifest':published(manifest),'archive':published(archive),
        'receipt_bindings':refs,'archive_members':evidence,
        'prior_publications':[published(ROOT/'docs/results'/v/'publication.json') for v in before],
        'standing_boards_viewed':sum(len(x['native']) for x in camera), 'native_triplets_viewed':len(exact),
        'new_weights':None,
    })


if __name__=='__main__':
    main()
