"""Check nuisance rejection and the thermal variance interpretation of nearby bands."""

from itertools import product
from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import reference,write_json
from demosaic._mesh_pooled import _CENTER_BACKGROUND,_wave
from weak_contrast import OUT, apparent_noise, energy_test


def main():
    freq = np.asarray(((.1171875,.07421875),(.08984375,-.072265625)))
    waveform = _wave(32,freq)
    weak, strong = waveform[...,1,:],waveform[...,0,:]
    nuisance = np.concatenate((_CENTER_BACKGROUND,strong),axis=-1)
    positions = ((0,1),(1,0))
    rng = np.random.default_rng(1105)
    noise = .008
    roles = tuple(rng.normal(.12,noise,(8192,16,16)) for _ in positions)
    typical = apparent_noise(freq,1,weak,nuisance,roles,positions,0.,noise**2)
    clean_weak = .009*weak[...,0] - .003*weak[...,1] + .012*strong[...,0]
    added = tuple(a+clean_weak[r::2,c::2] for a,(r,c) in zip(roles,positions,strict=True))
    observed = apparent_noise(freq,1,weak,nuisance,added,positions,0.,noise**2)
    np.testing.assert_allclose(observed,typical,atol=1e-11,rtol=1e-11)
    offsets = np.asarray([(a,b) for a,b in product((-1,0,1),repeat=2) if a or b])
    orientation = freq[1]/np.linalg.norm(freq[1]); orthogonal = orientation[::-1]*[-1,1]
    more = freq[1] + offsets@np.stack((orientation,orthogonal))/32
    nearby = _wave(32,more)
    null_scores = energy_test(nearby,np.concatenate((nuisance,weak),axis=-1),roles,positions,0.,noise**2)
    mean_energy = null_scores.mean(axis=0)
    assert abs(mean_energy-2).max() < .12
    frame = np.sum(nearby[...,0],axis=2)*.009
    background = tuple(a+frame[r::2,c::2] for a,(r,c) in zip(roles,positions,strict=True))
    textured = apparent_noise(freq,1,weak,nuisance,background,positions,0.,noise**2)
    assert np.quantile(typical,.5) < 1.3 and np.quantile(textured,.5)>3
    write_json(OUT/'noise-audit.json',{'driver':reference(Path(__file__)),'samples':8192,'predictors':freq.tolist(),
        'maximum_signal_projection_leakage':float(abs(typical-observed).max()),
        'thermal_mean_chi2':mean_energy.tolist(),
        'thermal_inflation_quantiles':np.quantile(typical,(.05,.5,.95)).tolist(),
        'textured_inflation_quantiles':np.quantile(textured,(.05,.5,.95)).tolist()})


if __name__ == '__main__':
    main()
