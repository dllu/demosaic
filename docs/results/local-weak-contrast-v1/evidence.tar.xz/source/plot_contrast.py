"""Show the response gain and gap change at the frozen operating point."""

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from weak_contrast import OUT
from reduce_support import ADDED,RESPONSE


def main():
    source = reference(OUT/'summary.json')
    panels = read_json(checked(source))['panels']
    names = ('Earlier straight, 24','Earlier straight, 32','Earlier curved, 24','New straight, 48')
    choices = ('previous','straight','curved','fresh')
    rows = [panels[k]['proposed']['weak']['guarded_hard'] for k in choices]
    fig,(a,b) = plt.subplots(1,2,figsize=(10.2,3.0),sharey=True,layout='constrained')
    ys = np.arange(len(names))

    def interval(ax,values,y,label,color,fmt):
        data = np.asarray(values)
        ax.errorbar(data[:,0], y, xerr=(data[:,0]-data[:,1],data[:,2]-data[:,0]),
                    fmt=fmt,color=color,label=label,capsize=2.6,markersize=4.5)

    interval(a,[r['frozen_vs_control'][RESPONSE]['difference_interval'] for r in rows],ys-.12,
             'Frozen strength','#25675a','o')
    interval(a,[r['equal_realized_gap']['paired'][RESPONSE]['difference_interval'] for r in rows],ys+.12,
             'Matched gap change','#83653e','s')
    interval(b,[r['frozen_vs_control'][ADDED]['difference_interval'] for r in rows],ys,
             'Frozen strength','#25675a','o')
    a.invert_yaxis()
    a.set_yticks(ys,names)
    a.set_xlabel('Recovered weak contrast (percentage points)')
    b.set_xlabel('Added luma RMS in true gaps (DN16)')
    a.set_title('Higher recovers more faint detail',fontweight='bold',loc='left',fontsize=10)
    b.set_title('Lower adds less texture in gaps',fontweight='bold',loc='left',fontsize=10)
    a.legend(frameon=False,loc='upper right',fontsize=9)
    for ax in (a,b):
        ax.axvline(0,linewidth=1,color='#969b9e')
        ax.grid(axis='x',alpha=.16)
        ax.spines[['top','right']].set_visible(False)
    chart = OUT/'guarded-contrast-tradeoff.png'
    fig.savefig(chart,dpi=160,facecolor='white')
    write_json(OUT/'chart.json',{'driver':reference(Path(__file__)),'summary':source,'image':reference(chart)})


if __name__=='__main__':
    main()
