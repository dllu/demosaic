"""Measure how inclusion, amplitude caps and local RAW ambiguity affect weak recovery."""

from pathlib import Path
from itertools import product
import sys

import numpy as np
from scipy.special import expit

from demosaic._mesh_pooled import _CENTER_BACKGROUND, _CORE, _SMOOTH, _STRIDE, _footprint, _rgb, _wave, _windows
from demosaic._mesh_presence import _CENTER_PIXELS, _PACKED_CORE, _RING, _evidence, _ring_prior
from demosaic.mesh_carrier_fit import _WINDOW, _positions

HERE = Path(__file__).resolve().parent
OUT = Path('/mnt/external/demosaic') / HERE.name
sys.path.insert(0, str(HERE.with_name('local-phase-extent-v1')))
import phase_extent as extent
from conditional import combined, carrier_terms, condition, conditional_posterior, prior_shape, replay
import local_rank

METHODS = ('odds', 'root_strength', 'hard_strength', 'noise_corrected_cap', 'paired_cap', 'offband_noise',
           'guarded_root', 'guarded_hard', 'guarded_offband')
ODDS = (-6., -5., -4., -3., -2., -1.)
OPTIONS = tuple((name, 'odds', odds, f'{name}_{odds:g}') for name,odds in product(METHODS,ODDS))
ARMS = ('combined','weak','phase_guard','uncapped',*(name for _,_,_,name in OPTIONS))
GUARD_GAIN = .9731861532279491


def energy_test(wave, smooth, samples, positions, shot, read):
    grams, moments = [], []
    count = wave.shape[-2]
    for raw, (r,c) in zip(samples,positions,strict=True):
        shape = wave[r::2,c::2].reshape(-1,count*2)
        background = smooth[r::2,c::2].reshape(shape.shape[0],-1)
        residual = shape - background @ (np.linalg.pinv(background,rcond=1e-8) @ shape)
        waves = residual.reshape(len(shape),count,2)
        matrix = np.einsum('nfi,nfj->fij',waves,waves)
        values = raw.reshape(len(raw),-1)
        precision = 1/np.maximum(2e-11,shot*np.maximum(0,values.mean(axis=1))+read)
        grams.append(matrix[None]*precision[:,None,None,None])
        moments.append((values@residual).reshape(len(values),count,2)*precision[:,None,None])
    grams = sum(grams)
    moments = sum(moments)
    fitted = (np.linalg.pinv(grams,hermitian=True,rcond=1e-8)@moments[...,None])[...,0]
    return np.einsum('nfi,nfi->nf',fitted,moments)


def apparent_noise(frequency, weakest, weak, nuisance, center, positions, shot, read):
    """Estimate extra carrier-band variance with orthogonalized nearby sinusoids."""
    f = frequency[weakest]
    along = f / np.linalg.norm(f)
    across = along[::-1] * np.asarray((-1,1))
    offsets = [(a,b) for a,b in product((-1,0,1),repeat=2) if a or b]
    offsets.extend(((2,0),(-2,0),(0,2),(0,-2)))
    nearby = f[None] + np.asarray(offsets) @ np.stack((along,across)) / 32
    competitors = _wave(32,nearby)
    design = np.concatenate((nuisance,weak),axis=-1)
    scores = energy_test(competitors,design,center,positions,shot,read)
    # The median of a two-degree chi-square variable equals twice ln(2).
    return np.clip(np.median(scores,axis=1)/(2*np.log(2)), 1., 6.)


def qualify(parent, local, scene, colors, roi, frequency, noise, wb, matrix, *, clearance=48):
    x,y = local[:2]
    anchor = replay.nested_apply(parent,local,scene,colors,roi,frequency,noise|{'wb':wb,'matrix':matrix})[0]['nested']
    outputs = dict.fromkeys(ARMS,anchor)
    if frequency is None:
        return outputs, {'weak':None,'status':'no frequency'}
    shot,read = noise['shot'],noise['read']
    direction, rank = local_rank.rank(scene,colors,roi,frequency,shot,read)
    if direction is None:
        return outputs, {'weak':None,'status':'ambiguous rank','rank':rank}

    _, former = combined(parent[:,y-16:y+176,x-16:x+176],scene,colors,roi,frequency,shot,read)
    old = former[:,direction]
    positions = _positions(colors,*roi[:2])
    observed = tuple(_windows(_footprint(scene,roi[:2],p),_WINDOW//2,_STRIDE//2) for p in positions)
    wave = _wave(_WINDOW,frequency).reshape(_WINDOW,_WINDOW,4)
    mean, deviation = _ring_prior(*_evidence(observed,positions,wave,_SMOOTH,_RING,shot,read))
    center = tuple(o[:,_PACKED_CORE,_PACKED_CORE] for o in observed)
    carrier = wave[_CORE].reshape(32,32,2,2)
    weak, strong = carrier[...,direction,:], carrier[...,1-direction,:]
    nuisance = np.concatenate((_CENTER_BACKGROUND,strong),axis=-1)
    terms = carrier_terms(weak,nuisance,center,positions,_CENTER_PIXELS)
    grams, moments = condition(terms,shot,read)
    gram, moment = sum(grams), sum(moments)
    prior_mean = mean.reshape(-1,2,2)[:,direction]
    precision = prior_shape(prior_mean,deviation[:,direction],'free')
    fitted, evidence = conditional_posterior(gram,moment,prior_mean,precision)
    model = np.concatenate((nuisance,weak),axis=-1).reshape(32**2,-1)
    raw_green = _windows(parent[1,y:y+160,x:x+160],32,_STRIDE).reshape(-1,32**2)
    inherited = raw_green @ np.linalg.pinv(model,rcond=1e-8)[-2:].T
    central_fit = np.linalg.solve(gram,moment[...,None])[...,0]
    fitted_power = np.sum(central_fit**2,axis=1)
    caps = {'fixed':np.sqrt(fitted_power)}
    uncertainty = np.linalg.inv(gram).diagonal(axis1=-2,axis2=-1).sum(axis=1)
    caps['noise_corrected_cap'] = np.sqrt(np.maximum(0, fitted_power - uncertainty))
    folds = [np.linalg.solve(g,m[...,None])[...,0] for g,m in zip(grams,moments,strict=True)]
    caps['paired_cap'] = np.sqrt(np.maximum(0,np.einsum('ni,ni->n',*folds)))
    extra = apparent_noise(frequency,direction,weak,nuisance,center,positions,shot,read)
    alternative_fit, alternative_evidence = conditional_posterior(gram/extra[:,None,None],moment/extra[:,None],prior_mean,precision)
    neutral = np.linalg.solve(matrix,np.ones(3))/wb
    neutral /= neutral[1]

    def deliver(strength, estimate, cap):
        difference = estimate-inherited
        strength = strength[:,None]
        # Preserve the baseline operation ordering in the ordinary weak arm.
        adjusted = difference*strength
        allowed = np.asarray(cap)*strength[:,0]
        adjusted *= np.minimum(1,allowed / np.linalg.norm(adjusted,axis=1).clip(min=1e-15))[:,None]
        update = np.where(strength>0,adjusted-old,0.)
        return anchor + _rgb(np.einsum('yxf,nf->nyx',weak,update),neutral,anchor.dtype)

    def probability(e, odds):
        return np.maximum(0,(expit(e+odds)-.2)/.8)

    strength = probability(evidence,-5)
    outputs['weak'] = deliver(strength,fitted,caps['fixed'])
    outputs['uncapped'] = deliver(strength,fitted,np.full(len(gram),1e6))
    delta = outputs['weak'].astype('d') - anchor
    pos = tuple(positions)
    priors, guide_coherence, _ = extent.donor_phase(scene,colors,roi,frequency,direction,shot,read,clearance) if strength.any() else (None,None,None)
    if priors is not None:
        moment2,energy,means,side = extent.measurements(scene,roi,frequency,direction,shot,read,priors,0)
        z = extent.field(moment2,energy,means,side,0,'local')
        taper = np.clip(1+(z-2.5)/2,0,1)
    else:
        taper = 1.
    outputs['phase_guard'] = (anchor + (GUARD_GAIN*taper)*delta).astype(anchor.dtype)
    for method,_,odds,name in OPTIONS:
        guarded = method.startswith('guarded_')
        if guarded and priors is None:
            outputs[name] = outputs['phase_guard']
            continue
        alternate = method in ('offband_noise','guarded_offband')
        p = probability(alternative_evidence if alternate else evidence,odds)
        if guarded:
            p *= strength > 0
        if method in ('root_strength','guarded_root'):
            p = np.sqrt(p)
        elif method in ('hard_strength','guarded_hard'):
            p = (p>0).astype('d')
        candidate = deliver(p,alternative_fit if alternate else fitted,caps.get(method,caps['fixed']))
        if guarded:
            candidate = (anchor+(GUARD_GAIN*taper)*(candidate.astype('d')-anchor)).astype(anchor.dtype)
        outputs[name] = candidate
    selected = strength>0
    cap_hit = (np.linalg.norm(fitted-inherited,axis=1) > caps['fixed']) & selected
    audit = {'weak':direction,'status':'evidence','selected':np.flatnonzero(selected).tolist(),'cap_hits':int(cap_hit.sum()),
             'strength':strength.tolist(),'raw_caps':caps['fixed'].tolist(),'offband_factor':extra.tolist(),
             'posterior_amplitude':np.linalg.norm(fitted,axis=1).tolist(),
             'paired_caps':caps['paired_cap'].tolist(),'noise_corrected_caps':caps['noise_corrected_cap'].tolist(),
             'center_power_over_noise':(fitted_power/uncertainty).tolist(),'guard_phase_eligible':priors is not None}
    if guide_coherence is not None:
        audit['exterior_coherence'] = guide_coherence.tolist()
    return outputs,audit
