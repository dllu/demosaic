"""Collect the next immutable EMA milestone and reuse verified native controls."""

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

CONTROL = ("V120", "scale-long20k")
MODEL = "scale-long50k"
STEP = 50_000
HORIZON = 100_000


def verified_controls(queue):
    old_path = checked(queue["native_source_plan"])
    old = read_json(old_path)
    closure = read_json(checked(queue["native_source_collection"]))
    assert closure["plan"] == reference(old_path)
    assert closure["models"] == old["models"] and closure["CPU_rng_unchanged"]
    assert closure["full_model_before"] == closure["full_model_after"]
    assert len(old["observations"]) == len(closure["records"]) == 110
    controls = []
    for label in CONTROL:
        assert (
            old["models"][label]["weights"] == "EMA" and closure["root_calls"][label]["root"] == 110
        )
        checked(old["models"][label]["checkpoint"])
    for case, binding in zip(old["observations"], closure["records"], strict=True):
        row = read_json(checked(binding))
        assert case["id"] == row["id"] and case["input_fingerprints"] == row["input_fingerprints"]
        by_label = {v["label"]: v for v in row["variants"]}
        selected = [by_label[label] for label in CONTROL]
        for v in selected:
            assert v["checkpoint"] == old["models"][v["label"]]["checkpoint"]
            checked(v["prediction"])
        controls.append(selected)
    return old, controls


def run_phase(root, phase, script, path, env):
    cmd = [sys.executable, str(script), str(path)]
    with (root / f"{phase}.log").open("xb") as log:
        proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        write_json(
            root / f"{phase}-launch.json",
            {
                "pid": proc.pid,
                "create_time": psutil.Process(proc.pid).create_time(),
                "command": cmd,
                "script": reference(script),
            },
        )
        rc = proc.wait()
    write_json(root / f"{phase}-return.json", {"returncode": rc})
    if rc:
        raise RuntimeError(f"{phase} failed with status {rc}")


def run(queue_path, *, preflight=False):
    queue = read_json(queue_path)
    assert reference(__file__) == queue["watcher"]
    os.sched_setaffinity(0, [6, 7])
    os.nice(6)
    verify_plan(queue)
    old, controls = verified_controls(queue)
    launch = read_json(checked(queue["training_launch"]))
    plan = read_json(checked(launch["production_plan"]))
    assert STEP in plan["retained_steps"]
    owner = psutil.Process(launch["pid"])
    assert owner.create_time() == launch["create_time"] and owner.status() != psutil.STATUS_ZOMBIE
    print("110 shared inputs and 220 saved controls verified", flush=True)
    if preflight:
        return
    root, work = (Path(queue[k]) for k in ("root", "work"))
    path = Path(queue["expected_state_receipt"])
    deadline = time.monotonic() + 86_400
    while not path.is_file():
        assert (
            owner.create_time() == launch["create_time"] and owner.status() != psutil.STATUS_ZOMBIE
        )
        if time.monotonic() > deadline:
            raise TimeoutError("50k observation deadline. Trainer left running independently.")
        time.sleep(15)
    binding = reference(path)
    state = read_json(checked(binding))
    assert state["global_step"] == STEP and state["LR_horizon"] == HORIZON
    checked(state["checkpoint"])
    fresh_dir = root / "new-model"
    fresh_dir.mkdir()
    spec = {
        "checkpoint": state["checkpoint"],
        "step": STEP,
        "weights": "EMA",
        "display_label": "Long schedule 50k EMA",
        "retained_progress": True,
        "training_horizon": HORIZON,
    }
    fresh = {
        **old,
        "root": str(fresh_dir),
        "work": str(work),
        "frozen_files": queue["frozen_files"],
        "models": {MODEL: spec},
        "triplet_model": MODEL,
        "inputs": [reference(queue_path), binding, state["checkpoint"], *old["inputs"]],
        "collector": reference(work / "scripts/collect_full_corpus_checkpoint_review.py"),
        "retained_checkpoint_receipt": binding,
        "planned_root_calls": 110,
        "scope": "Fresh 50k EMA on the 110 retained native inputs. CUDA hidden.",
    }
    fresh_path = fresh_dir / "plan.json"
    write_json(fresh_path, fresh)
    env = {
        **os.environ,
        "CUDA_VISIBLE_DEVICES": "",
        "PYTHONPATH": f"{work}/scripts:{work}/src",
        "OPENBLAS_NUM_THREADS": "2",
        "OMP_NUM_THREADS": "2",
    }
    run_phase(
        root,
        "collection",
        work / "scripts/collect_full_corpus_checkpoint_review.py",
        fresh_path,
        env,
    )
    new_result = reference(fresh_dir / "collection/result.json")
    new = read_json(checked(new_result))
    assert new["plan"] == reference(fresh_path) and new["models"] == {MODEL: spec}
    assert new["root_calls"] == {MODEL: {"root": 110}} and len(new["records"]) == 110
    assert new["local_DINO"] == {"requests": 110, "executions": 110, "replays": 0}
    combined = {
        **fresh,
        "root": str(root),
        "models": {**{k: old["models"][k] for k in CONTROL}, MODEL: spec},
        "inputs": [*fresh["inputs"], new_result, queue["native_source_collection"]],
        "scope": "Fresh original-schedule 50k EMA with saved V120 and long 20k EMA controls. Shared retained inputs.",
    }
    combined_path = root / "plan.json"
    write_json(combined_path, combined)
    output = root / "collection"
    output.mkdir()
    records = []
    for i, (case, saved, fresh_binding) in enumerate(
        zip(old["observations"], controls, new["records"], strict=True)
    ):
        record = read_json(checked(fresh_binding))
        assert (
            record["id"] == case["id"]
            and record["input_fingerprints"] == case["input_fingerprints"]
        )
        assert len(record["variants"]) == 1 and record["variants"][0]["label"] == MODEL
        assert record["variants"][0]["checkpoint"] == spec["checkpoint"]
        out = output / f"case-{i:03d}.json"
        write_json(out, {**record, "variants": [*saved, *record["variants"]]})
        records.append(reference(out))
    target = output / "result.json"
    write_json(
        target,
        {
            "plan": reference(combined_path),
            "records": records,
            "models": combined["models"],
            "fresh_collection": new_result,
            "saved_controls": queue["native_source_collection"],
            "fresh_root_calls": new["root_calls"],
            "fresh_local_DINO": new["local_DINO"],
            "fresh_inference_seconds": new["seconds"],
            "saved_predictions_reused": 220,
        },
    )
    run_phase(root, "report", work / "scripts/report_full_corpus_checkpoint_review.py", root, env)
    write_json(
        root / "complete.json",
        {
            "collection": reference(target),
            "report": reference(root / "report/result.json"),
            "quality_status": "Numerical report complete. Independent numerical audit and actual native viewing pending.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    run(args.path, preflight=args.preflight)
