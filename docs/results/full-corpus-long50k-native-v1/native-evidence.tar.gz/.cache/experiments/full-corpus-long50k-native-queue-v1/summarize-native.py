"""Summarize the 50k checkpoint and the matched controls from the audited retained panel."""

from collections import defaultdict
from pathlib import Path
from statistics import mean

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
report_path = root / "report/result.json"
report = read_json(report_path)
audit = read_json(root / "independent-audit-v1/result.json")
assert checked(audit["report"]) == report_path and audit["counts"]["metric_rows"] == 288
labels = ("V120", "scale-long20k", "scale-long50k")
by_case = defaultdict(list)
for row in report["metrics"]:
    by_case[row["group"], row["source_id"], row["method"]].append(row)
faint = []
for (group, key, method), values in sorted(by_case.items()):
    if group != "faint-ADC":
        continue
    assert len(values) == 4
    assert {v["pattern"] for v in values} == {"RGGB", "BGGR", "GRBG", "GBRG"}
    bands = [next(b for b in r["bands"] if b["bin"] == 0) for r in values]
    faint.append(
        {
            "source_id": key,
            "source_case": values[0]["case"],
            "method": method,
            "sRGB_PSNR": mean(v["sRGB_PSNR"] for v in values),
            "camera_RGB_PSNR": mean(v["camera_RGB_PSNR"] for v in values),
            "low_contrast_fine_band_gain": mean(b["gain"] for b in bands),
            "low_contrast_fine_band_error_DN16": 65535 * mean(b["band_error_RMS"] for b in bands),
        }
    )
assert len(faint) == 12
color = {}
for label in labels:
    rows = [r for r in report["ADC_color_spot_checks"] if r["method"] == label]
    assert len(rows) == 8
    color[label] = {
        name: max(v[name] for v in rows)
        for name in ("maximum_absolute_mean_error_DN16", "centered_RGB_RMS_DN16")
    }
collection = read_json(checked(report["collection"]))
write_json(
    root / "report/native-summary.json",
    {
        "driver": reference(__file__),
        "report": reference(report_path),
        "independent_audit": reference(root / "independent-audit-v1/result.json"),
        "epoch_execution_audit": reference(
            "docs/results/full-corpus-long50k-prefix-v1/source-and-crop-audit.json"
        ),
        "training_timing": reference(
            "docs/results/full-corpus-long50k-prefix-v1/checkpoint-verified.json"
        ),
        "condition_means": report["condition_means"],
        "faint_materials": faint,
        "flat_spot_checks": color,
        "CPU_inference_seconds_excluding_load": collection["fresh_collection_seconds"],
        "root_calls": collection["fresh_root_calls"],
        "DINO": collection["fresh_local_DINO"],
        "scope": "Same 110 retained observations at V120 and the long-schedule 20k and 50k EMA states. Full fixed 427-photo, known/unseen camera and full color-palette measurements are separate.",
    },
)
print(report["condition_means"])
print(faint)
print(color)
