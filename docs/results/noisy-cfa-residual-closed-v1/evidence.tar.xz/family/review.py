"""Audit exact scores and render the measured-noise-coordinate interventions."""

from collections import defaultdict
from math import log1p, sqrt
from pathlib import Path

import numpy as np
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "noisy-cfa-residual-v1"
MODE = "scale-long86k"
ARMS = ("original", "clip-read-electrons-5", "ADC-family-only")
LABELS = ("86k original", "86k read feature capped", "86k ADC feature only")
DN16 = 65535


def training_read_e():
    profile = read_json(BASE/"training-noise-audit.json")
    values, counts = defaultdict(list), defaultdict(int)
    for binding in profile["condition_records"]:
        with np.load(checked(binding)) as data:
            d, v = data["domains"], data["values"]
        for label in set(d):
            pairs = v[d==label, :, :2].reshape(-1,2).astype(float)
            counts[str(label)] += len(pairs)
            pairs = pairs[pairs[:,0]>0]
            values[str(label)].append(np.sqrt(pairs[:,1])/pairs[:,0])
    assert sum(counts.values()) == 1376000
    return {
        k: {"positive_shot":len(a), "minimum":float(a.min()), "maximum":float(a.max()),
            "median":float(np.median(a)), "above_31e":int((a>=31).sum())}
        for k,v in values.items() if (a:=np.concatenate(v)).size
    }


def main():
    out = ROOT/"review"
    out.mkdir()
    shards = [reference(ROOT/f"shard-{i}/result.json") for i in range(2)]
    closed = [read_json(checked(p)) for p in shards]
    assert sum(r["original_outputs_bit_exact"] for r in closed) == 8
    base = reference(BASE/"nulls-review/result.json")
    old = {
        (r["model"],r["source"],r["profile"],r["CFA"]):r["worst_channel_abs_bias_DN16"]
        for r in read_json(checked(base))["rows"] if r["policy"]=="raw"
    }
    rows, boards = [], []
    for cohort in closed:
        for binding in cohort["cases"]:
            r = read_json(checked(binding))
            o = r["observation"]
            with np.load(checked(o["arrays"])) as f:
                aux = dict(f)
            with np.load(checked(o["target"])) as f:
                target = f["target"]
            shot, read = (o["noise"][k] for k in ("shot","read"))
            value = sqrt(read)/shot
            store = {}
            for arm in r["variants"]:
                p = np.load(checked(arm["output"]),allow_pickle=False)
                store[(arm["model"],arm["arm"])] = p
                record = arm["features"]
                before, after = (np.asarray(record[q]) for q in ("before","after"))
                np.testing.assert_array_equal(before[:,:2],after[:,:2])
                np.testing.assert_allclose(before[:,2],log1p(value)/3,rtol=0,atol=2e-7)
                if arm["arm"]=="clip-read-electrons-5":
                    np.testing.assert_allclose(after[:,2],log1p(5)/3,rtol=0,atol=4e-8)
                err = (p.astype(float)-target)[...,48:208,48:208]*DN16
                bias = err.mean((-2,-1),keepdims=True)
                centered = np.sqrt(np.mean((err-bias)**2,axis=(-3,-2,-1)))
                for i, case in enumerate(o["source_ids"]):
                    b = float(np.abs(bias[i]).max())
                    if arm["arm"]=="original":
                        assert b == old[arm["model"],case,o["noise"]["name"],o["pattern"]]
                    rows.append({
                        "id":o["id"], "profile":o["noise"]["name"],"CFA":o["pattern"], "material":case,
                        "model":arm["model"],"arm":arm["arm"], "read_e":value, "bias_DN16":b,
                        "centered_RMS_DN16":float(centered[i]),
                    })
            subjects = ["bright-yellow"]
            if o["pattern"]=="RGGB":
                subjects.append("slanted-edge")
            for case in subjects:
                i = o["source_ids"].index(case)
                inpt = {k:aux[k][i:i+1] for k in ("packed","variance","colors","wb","matrix")}
                key = f"{o['id']}-{case}"
                boards.append(native_board(
                    out,key,[noisy_malvar(inpt)[0],*[store[(MODE,a)][i] for a in ARMS],target[i]],
                    inpt,{"source":case,"models":cohort["models"],"observation":o,
                          "source_case":binding,"illumination":o["noise"],"display_transform":"shared clipped sRGB"},
                    exposure=1, labels=("Noisy Malvar",*LABELS,"Exact GT"),
                    triplet_indices=(0,3,4),
                ))
    assert len(rows)==96 and len(boards)==6
    read_e = training_read_e()
    for r in rows:
        if r["material"]=="bright-yellow" and r["model"]==MODE:
            print(r["id"],r["arm"],round(r["bias_DN16"],3),round(r["centered_RMS_DN16"],3))
    write_json(out/"result.json",{
        "source":reference(__file__),"shards":shards,"matched_previous_metrics":32,"rows":rows,
        "boards":boards,"prior_null_metrics":base,"training_read_e":read_e,
        "training_ledger":reference(BASE/"training-noise-audit.json"),
        "scope":"Same noisy Bayer tensors, deterministic physical noise transform, inverse, black/white coordinates "
        "and DINO input. Only third photometry channel changes. Exact fixed synthetic null cases.",
    })
    print("Actual training read electrons",read_e)


if __name__ == "__main__":
    main()
