"""Isolate the stabilized noise-family coordinate on unchanged low-noise sensor tensors."""

import argparse
import math
from pathlib import Path

import numpy as np
import torch
from profile_raw_kernel_inference import model_hash

import demosaic.pretrained_rgb as restored
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.frozen_encoder_replay import FrozenDinoReplay
from demosaic.inference import load_checkpoint
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "noisy-cfa-residual-v1" / "nulls"
POLICIES = ("original", "clip-read-electrons-5", "ADC-family-only")
FIELDS = ("packed", "variance", "colors", "wb", "matrix")
CFA = ("RGGB", "GBRG")
NOISE = ("small-positive", "intermediate")


@torch.inference_mode()
def run(index):
    torch.set_num_threads(2)
    dst = ROOT / f"shard-{index}"
    dst.mkdir()
    plan, result = (read_json(BASE / p) for p in ("plan.json", "collection/result.json"))
    assert result["plan"] == reference(BASE / "plan.json") and result["models"] == plan["models"]
    specs = plan["models"]
    models = {}
    for label, spec in specs.items():
        model, state = load_checkpoint(checked(spec["checkpoint"]), "cpu")
        assert state["step"] == spec["step"] and state["loaded_sha256"] == spec["checkpoint"]["sha256"]
        current = model.restoration_state_dict()
        assert current.keys() == state["ema"].keys() and len(current) == 91
        assert all(torch.equal(t, state["ema"][k]) for k, t in current.items())
        models[label] = model.eval().to(memory_format=torch.contiguous_format)
    assert all(model_hash(m.context.backbone) == plan["DINO_sha256"] for m in models.values())
    before = {label: model_hash(model) for label, model in models.items()}
    rng = torch.get_rng_state().clone()
    replay = FrozenDinoReplay([m.context.backbone for m in models.values()])
    original_features = restored.stabilized_photometry
    cases = []
    for o, binding in zip(plan["observations"], result["records"], strict=True):
        if o["noise"]["name"] != NOISE[index] or o["pattern"] not in CFA:
            continue
        old = read_json(checked(binding))
        assert o["id"] == old["id"] and o["input_fingerprints"] == old["input_fingerprints"]
        prior = {p["label"]: p for p in old["variants"]}
        with np.load(checked(o["arrays"])) as f:
            args = {k: torch.from_numpy(f[k]) for k in FIELDS}
        assert {k: fingerprint(v) for k,v in args.items()} == o["input_fingerprints"]
        shot, read = (o["noise"][k] for k in ("shot","read"))
        outputs = []
        for model in models.values():
            model.set_noise(shot, read)
        with replay.group() as stats, ieee_fp32():
            for arm in POLICIES:
                for label, model in models.items():
                    features = []

                    def replace_family(profiles, offset, span):
                        original = original_features(profiles, offset, span)
                        assert original.shape == (4, 3, 1, 1)
                        attrs = original.clone()
                        if arm == "clip-read-electrons-5":
                            attrs[:, 2].clamp_max_(math.log1p(5) / 3)
                        elif arm == "ADC-family-only":
                            attrs[:, 2].fill_(-2)
                        assert torch.equal(attrs[:, :2], original[:, :2])
                        features.append({"before": original[:, :, 0, 0].tolist(),
                                         "after": attrs[:, :, 0, 0].tolist()})
                        return attrs

                    restored.stabilized_photometry = replace_family
                    try:
                        ans = model(*(args[name] for name in FIELDS)).numpy()
                    finally:
                        restored.stabilized_photometry = original_features
                    assert len(features) == 1 and np.isfinite(ans).all()
                    assert fingerprint(ans)["dtype"] == "<f4"
                    if arm == "original":
                        exact = np.load(checked(prior[label]["prediction"]))
                        np.testing.assert_array_equal(ans, exact)
                    path = dst / f"{o['id']}-{label}-{arm}.npy"
                    with path.open("xb") as f:
                        np.save(f, ans, allow_pickle=False)
                    outputs.append({"model": label, "arm": arm, "output": reference(path),
                                    "checkpoint": specs[label]["checkpoint"], "features": features[0]})
        assert stats == {"requests": 6, "executions": 1, "replays": 5}
        assert {k: fingerprint(v) for k,v in args.items()} == o["input_fingerprints"]
        row = {"observation": o, "original_prediction_record": binding, "variants": outputs,
               "encoder": stats, "same_physical_inputs": True}
        out = dst / f"{o['id']}.json"
        write_json(out,row)
        cases.append(reference(out))
        print(o["id"], stats, flush=True)
    assert len(cases) == 2
    assert before == {label: model_hash(m) for label,m in models.items()}
    assert torch.equal(rng, torch.get_rng_state()) and not torch.cuda.is_initialized()
    write_json(dst / "result.json", {"source": reference(__file__), "index": index, "cases": cases,
        "base": reference(BASE/"plan.json"), "base_collection": reference(BASE/"collection/result.json"),
        "models": specs, "full_model_state_unchanged": True, "original_outputs_bit_exact": 4})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("index", type=int, choices=(0,1))
    run(parser.parse_args().index)
