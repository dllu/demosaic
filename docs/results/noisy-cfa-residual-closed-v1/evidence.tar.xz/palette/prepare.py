"""Create a reserved hue check for the frozen four-sigma correction."""

import hashlib
from pathlib import Path

import numpy as np
import torch

from demosaic.cfa import color_indices, mosaic
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.noise import add_noise, variance_map
from demosaic.prediction_archive import fingerprint

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent/"noisy-cfa-residual-v1"
TARGETS = {
    "orange": (.90, .459, .018),
    "cyan": (.018, .90, .90),
    "magenta": (.90, .018, .90),
    "light-neutral": (.55, .55, .55),
}
CFA = ("RGGB", "BGGR", "GRBG", "GBRG")
NOISE = ("small-positive", "intermediate")


def main():
    torch.set_num_threads(1)
    old = read_json(BASE/"nulls/plan.json")
    calibration = reference(BASE/"calibration.json")
    function = reference(BASE/"large-disagreement.py")
    inputs = ROOT/"inputs"
    inputs.mkdir()
    targets = torch.tensor(list(TARGETS.values()), dtype=torch.float32)
    targets = targets[:,:,None,None].expand(4,3,256,256).contiguous()
    truth = inputs/"target.npz"
    with truth.open("xb") as f:
        np.savez(f,target=targets.numpy())
    observations = []
    for profile in NOISE:
        recipe = next(o["noise"] for o in old["observations"] if o["noise"]["name"] == profile)
        shot, read = recipe["shot"], recipe["read"]
        for cfa in CFA:
            name = f"{profile}-{cfa}"
            rgb = color_indices(cfa)[None].expand(4,-1).clone()
            seed = int.from_bytes(hashlib.sha256(f"reserved-positive-colors-v1:{name}".encode()).digest()[:8],"little") % 2**63
            clean = mosaic(targets, rgb)
            raw = add_noise(clean,shot,read,bit_depth=16,black_level=.03,
                            generator=torch.Generator().manual_seed(seed))
            arrays = {"packed":raw.numpy(),"variance":variance_map(raw,shot,read).numpy(),
                      "colors":rgb.numpy(),"wb":np.ones((4,3),np.float32),
                      "matrix":np.repeat(np.eye(3,dtype=np.float32)[None],4,axis=0)}
            path = inputs/f"{name}.npz"
            with path.open("xb") as f:
                np.savez(f,**arrays)
            observations.append({"id":name,"kind":"reserved-color","source_ids":list(TARGETS),"pattern":cfa,
                                 "arrays":reference(path),"target":reference(truth),"seed":seed,
                                 "output_shape":[4,3,256,256],"ROI_xywh":[48,48,160,160],
                                 "input_fingerprints":{k:fingerprint(v) for k,v in arrays.items()},"noise":recipe})
    assert len(observations)==8
    write_json(ROOT/"plan.json",old | {
        "root":str(ROOT),"observations":observations,
        "inputs":[*old["inputs"],reference(__file__),reference(BASE/"nulls/plan.json"),
                  calibration,function,reference(truth)],
        "CPU_affinity":[16,17], "maximum_seconds":1800, "planned_root_calls":16,"planned_DINO_executions":8,
        "scope":"Reserved colors and statistically independent RAW perturbations. Evaluate the already frozen residual "
        "on the smallest profile; the intermediate profile intentionally probes the guard bypass.",
    })


if __name__ == "__main__":
    main()
