"""Review the frozen low-noise policies on four reserved constant colors."""

import sys
import time
from importlib.machinery import SourceFileLoader
from pathlib import Path

import numpy as np
import psutil
import torch
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent/"noisy-cfa-residual-v1"
sys.path.insert(0,str(BASE))
from guarded import apply, in_scope
from probe import DN16, inputs_and_variants

bounded = SourceFileLoader("bounded_palette",str(BASE/"large-disagreement.py")).load_module()


def wait():
    root = ROOT/"collection"
    result = root/"result.json"
    owner = read_json(root/"owner.json")
    assert owner["plan"] == reference(ROOT/"plan.json")
    while not result.is_file():
        p = psutil.Process(owner["pid"])
        assert p.create_time() == owner["create_time"] and p.status()!=psutil.STATUS_ZOMBIE
        time.sleep(10)
    closure = read_json(result)
    assert closure["plan"] == owner["plan"] and len(closure["records"]) == 8
    assert closure["CPU_rng_unchanged"] and closure["full_model_before"] == closure["full_model_after"]


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    wait()
    dst = ROOT/"review"
    dst.mkdir()
    fit = read_json(BASE/"calibration.json")["parameters"]
    rows, boards = [], []
    for o, a, pred, models in inputs_and_variants(ROOT):
        with np.load(checked(o["target"])) as s:
            target = s["target"]
        for label,p in pred.items():
            variants = {
                "raw":p, "single":apply(p,a,o["noise"],fit),
                "bounded":bounded.correction(p,a,o,fit["single"]["width"]),
            }
            if not in_scope(o["noise"]):
                assert all(t is p for t in variants.values())
            for arm,t in variants.items():
                error = (t.astype(float)-target)[...,48:208,48:208]*DN16
                bias = error.mean((-2,-1),keepdims=True)
                centered = np.sqrt(np.mean((error-bias)**2,axis=(1,2,3)))
                for i,subject in enumerate(o["source_ids"]):
                    rows.append({"color":subject,"CFA":o["pattern"],"profile":o["noise"]["name"],
                                 "model":label,"arm":arm,"max_abs_bias_DN16":float(np.abs(bias[i]).max()),
                                 "centered_RMS_DN16":float(centered[i])})
            if label == "scale-long86k" and o["pattern"]=="RGGB" and in_scope(o["noise"]):
                for subject in ("cyan","magenta"):
                    i = o["source_ids"].index(subject)
                    metadata = {k: a[k][i:i+1] for k in ("packed","colors","wb","matrix")}
                    boards.append(native_board(
                        dst,subject,[noisy_malvar(metadata)[0],*[t[i] for t in variants.values()],target[i]],
                        metadata,{"source":subject,"models":models,"observation":o},
                        exposure=1,labels=("Noisy Malvar","86k raw","86k single","86k bounded","Exact GT"),
                        triplet_indices=(0,3,4),
                    ))
    assert len(rows)==32*2*3 and len(boards)==2
    summaries = []
    for model in ("V120","scale-long86k"):
        for profile in ("small-positive","intermediate"):
            for arm in ("raw","single","bounded"):
                reduced=[r for r in rows if (r["model"],r["profile"],r["arm"])==(model,profile,arm)]
                d={"model":model,"profile":profile,"arm":arm,
                   "worst_bias":max(reduced,key=lambda r:r["max_abs_bias_DN16"]),
                   "worst_centered":max(reduced,key=lambda r:r["centered_RMS_DN16"])}
                summaries.append(d)
                if profile=="small-positive":
                    print(model,arm,d["worst_bias"]["color"],d["worst_bias"]["max_abs_bias_DN16"],
                          d["worst_centered"]["centered_RMS_DN16"],flush=True)
    write_json(dst/"result.json",{"source":reference(__file__),"plan":reference(ROOT/"plan.json"),
                                  "collection":reference(ROOT/"collection/result.json"),
                                  "rows":rows,"summaries":summaries,"boards":boards})


if __name__=="__main__":
    main()
