"""Verify the reusable projection against the exact scored prototype tensors."""

from importlib.machinery import SourceFileLoader
from pathlib import Path

import numpy as np
import torch
from guarded import GFX, ROOT, in_scope
from probe import inputs_and_variants

from demosaic.adc_bins import near_adc_residual_projection
from demosaic.experiments.artifacts import read_json, reference, write_json

prototype=SourceFileLoader("bounded_probe",str(ROOT/"large-disagreement.py")).load_module()


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    fit=read_json(ROOT/"calibration.json")["parameters"]["single"]["width"]
    assert fit==4
    records, counts={}, {}
    paths=[ROOT/f"heldout-{i}" for i in range(2)] + [
        ROOT/"nulls", ROOT.parent/"noisy-residual-reserved-palette-v1", GFX,
    ]
    for directory in paths:
        key=directory.name
        keep=(lambda o:o["kind"] in ("gfx","mesh")) if directory==GFX else (lambda o:True)
        active,bypassed=0,0
        for obs,arr,pred,_ in inputs_and_variants(directory,keep):
            for checkpoint, p in pred.items():
                previous=prototype.correction(p,arr,obs,fit)
                tensor=torch.from_numpy(p)
                packed,colors,wb=(torch.from_numpy(arr[k]) for k in ("packed","colors","wb"))
                shot,read=(obs["noise"][k] for k in ("shot","read"))
                revised=near_adc_residual_projection(tensor,packed,colors,wb,shot=shot,read=read,black_level=.03)
                np.testing.assert_array_equal(previous,revised.numpy())
                if in_scope(obs["noise"]):
                    assert revised is not tensor
                    active+=1
                else:
                    assert revised is tensor
                    bypassed+=1
        counts[key]={"active_bit_exact":active,"bypass_by_identity":bypassed}
        records[key]=reference(directory/"collection/result.json")
    assert sum(r["active_bit_exact"] for r in counts.values())==48
    assert counts[GFX.name]["bypass_by_identity"]==18
    write_json(ROOT/"implementation-check.json",{
        "implementation":reference("src/demosaic/adc_bins.py"),"prototype":reference(ROOT/"large-disagreement.py"),
        "source":reference(__file__),"sources":records,"counts":counts,
    })
    print(counts)


if __name__=="__main__":
    main()
