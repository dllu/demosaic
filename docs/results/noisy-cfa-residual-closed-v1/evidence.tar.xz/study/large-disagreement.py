"""Evaluate a soft four-sigma sensor interval as a low-noise color repair."""

from pathlib import Path

import numpy as np
import torch
from guarded import in_scope
from probe import DN16, ROOT, inputs_and_variants, residuals
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def correction(p, a, obs, width):
    n = obs["noise"]
    if not in_scope(n):
        return p
    colors, wb, sigma, innovation, _ = residuals(p, a, n["shot"], n["read"])
    weight = width / (width + sigma)
    excess = innovation.sign() * (innovation.abs() - 4 * sigma / DN16).clamp_min(0)
    update = weight * innovation + (1 - weight) * excess
    return p + malvar(update, colors, wb).numpy()


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    out = ROOT / "large-disagreement"
    out.mkdir()
    fit = read_json(ROOT / "calibration.json")["parameters"]
    width = fit["single"]["width"]
    rows, boards = [], []
    for o, a, predictions, models in inputs_and_variants(ROOT / "nulls"):
        with np.load(checked(o["target"])) as f:
            t = f["target"]
        for model, p in predictions.items():
            corrected = correction(p, a, o, width)
            if in_scope(o["noise"]):
                assert corrected is not p
            else:
                assert corrected is p
            for label, output in (("raw", p), ("bounded-residual", corrected)):
                e = (output.astype(float) - t)[..., 48:208, 48:208] * DN16
                bias = e.mean((-2,-1), keepdims=True)
                for j, kind in enumerate(o["source_ids"]):
                    rows.append({
                        "profile": o["noise"]["name"], "CFA": o["pattern"], "source": kind, "model": model,
                        "policy": label, "bias_DN16": float(np.max(np.abs(bias[j]))),
                        "centered_DN16": float(np.mean((e[j]-bias[j])**2)**.5),
                    })
            if o["pattern"] == "RGGB" and in_scope(o["noise"]) and model == "scale-long86k":
                i = o["source_ids"].index("bright-yellow")
                camera = {k: a[k][i:i+1] for k in ("packed", "colors", "wb", "matrix")}
                boards.append(native_board(
                    out, "yellow-large-disagreement", [noisy_malvar(camera)[0], p[i], corrected[i], t[i]],
                    camera, {"observation": o, "models": models, "source": "bright-yellow"},
                    exposure=1, labels=("Noisy Malvar", "86k raw EMA", "86k bounded residual", "Exact GT"),
                    triplet_indices=(0, 2, 3),
                ))
    assert len(boards) == 1 and len(rows) == 256
    write_json(out / "result.json", {
        "producer": reference(__file__), "fit": reference(ROOT / "calibration.json"),
        "guard": reference(ROOT / "guarded.py"), "null_input": reference(ROOT / "nulls/plan.json"),
        "scope": "Exploratory replay of the previously viewed exact controls after seeing their color failure.",
        "rows": rows, "boards": boards,
    })


if __name__ == "__main__":
    main()
