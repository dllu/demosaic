"""Recompute source-balanced summaries and verify the shared low-noise controls."""

from collections import defaultdict
from math import fsum, sqrt
from pathlib import Path
from statistics import mean

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
CFA={"RGGB","BGGR","GRBG","GBRG"}
DN16=65535


def grouped(rows):
    by=defaultdict(list)
    for row in rows:
        by[row["model"],row["policy"],row["source"]].append(row)
    result=defaultdict(dict)
    for (model,arm,source), samples in by.items():
        assert len(samples)==4 and {r["CFA"] for r in samples}==CFA
        assert len({tuple(r["band_sums"]) for r in samples})==1
        if "0" not in samples[0]["band_sums"]:
            continue
        fields=[r["band_sums"]["0"] for r in samples]
        coeffs=fsum(v["blocks"] for v in fields)*256
        energy=fsum(v["error"] for v in fields)
        result[model,arm][source]=sqrt(energy/coeffs)*DN16
    return result


def check(summary, rows):
    by=grouped(rows)
    for data in summary:
        key=data["model"],data["policy"]
        legacy={r["source"]:r["error_RMS_DN16"] for r in data["source_rows"]}
        assert legacy.keys()==by[key].keys()
        assert all(abs(true-by[key][s])<2e-13 for s,true in legacy.items())
        assert abs(mean(by[key].values())-data["equal_source_RMS_DN16"])<2e-13
    return by


def compare(data,label,base,arm):
    a,b=data[label,base],data[label,arm]
    assert a.keys()==b.keys()
    return {
        "model":label,"reference":base,"method":arm,"sources":len(a),
        "lower_error_sources":sum(b[k]<a[k] for k in a),
        "equal_source_base_RMS_DN16":mean(a.values()),"equal_source_method_RMS_DN16":mean(b.values()),
        "paired_DN16":{k:b[k]-a[k] for k in a},
    }


def main():
    sources=[reference(ROOT/k) for k in ("review/photos.json","guarded-result.json","photo-conditioning-review/result.json")]
    full,guarded,crossed=(read_json(checked(x)) for x in sources)
    arms=("V120","scale-long86k")
    output={}
    for profile,rows in full["observations"].items():
        chosen=[s["band_0"] for s in full["summary"] if s["profile"]==profile]
        data=check(chosen,rows)
        output[profile]=[compare(data,m,"raw",p) for m in arms for p in ("single","split")]
        for row in full["summary"]:
            if row["profile"]!=profile:
                continue
            relevant=[r for r in rows if (r["model"],r["policy"])==(row["model"],row["policy"])]
            assert len(relevant)==64 and abs(mean(r["PSNR_sRGB"] for r in relevant)-row["PSNR_sRGB"])<2e-13
    all_guarded=guarded["rows"]["small-positive"]
    assert len({r["source"] for r in all_guarded})==12
    assert guarded["coverage"]=={
        "small-positive":"single","intermediate":"raw","iso100-prior":"raw","iso6400-prior":"raw",
    }
    assert len(guarded["GFX"])==18 and all(r["bypass"] for r in guarded["GFX"])
    kept=check([r for r in guarded["results"]["small-positive"] if r["band"]=="0"],all_guarded)
    inter=check([r for r in crossed["bands"] if r["band"]=="0"],crossed["rows"])
    a={(r["model"],r["policy"],r["CFA"],r["source"]):r for r in all_guarded}
    b={(r["model"],r["policy"],r["CFA"],r["source"]):r for r in crossed["rows"] if r["policy"] in ("raw","single")}
    assert a == b
    assert len(crossed["paired_inputs"])==12
    in_scope=set(r["source"] for r in crossed["rows"])
    pre=read_json(ROOT/"photo-conditioning-plan.json")
    assert in_scope.isdisjoint(pre["excluded_source_ids"])
    payload={
        "sources":sources,"full":output,"exact_shared_raw_and_single_rows":len(a),
        "prospective":[compare(inter,m,"raw",p) for m in arms for p in ("single","bounded","zero")],
        "guarded": [compare(kept,m,"raw","single") for m in arms],
        "GFX_bypasses":len(guarded["GFX"]), "source":reference(__file__),
    }
    write_json(ROOT/"independent-closed-audit.json",payload)
    print("Passed independent weighted summaries, 192 exact cross-controls and all 18 GFX bypasses")
    for row in payload["prospective"]:
        print(row["model"],row["method"],round(row["equal_source_base_RMS_DN16"],5),
              round(row["equal_source_method_RMS_DN16"],5),row["lower_error_sources"],row["sources"])


if __name__=="__main__":
    main()
