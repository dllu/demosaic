"""Compare the exact same 12 low-noise photo observations under both conditioning paths."""

from collections import defaultdict
from importlib.machinery import SourceFileLoader
from pathlib import Path
from statistics import mean

import numpy as np
import torch
from probe import ROOT, inputs_and_variants, score
from report_full_faint_photo_panel import source_balance
from report_scene_wave_guides import native_board

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

bounded = SourceFileLoader("noisy_residual_bounded", str(ROOT/"large-disagreement.py")).load_module()
runner = SourceFileLoader("noisy_conditioning_queue", str(ROOT/"review-when-ready.py")).load_module()


@torch.inference_mode()
def analyze():
    torch.set_num_threads(2)
    base = read_json(ROOT/"plan.json")
    replay = read_json(ROOT/"photo-conditioning-plan.json")
    fit = read_json(ROOT/"calibration.json")["parameters"]
    original = {}
    out = ROOT/"photo-conditioning-review"
    out.mkdir()
    for p in base["heldout"]:
        for o, a, ps, ms in inputs_and_variants(
            checked(p).parent,
            lambda row: row["noise"]["name"] == "small-positive"
            and not set(row["source_ids"]).intersection(replay["excluded_source_ids"]),
        ):
            original[o["id"]] = (o, a, ps, ms)
    assert len(original) == 12
    picked = sorted({s for o, *_ in original.values() for s in o["source_ids"]})[:2]
    rows, boards, paired = [], [], []
    for binding in replay["shards"]:
        for o, a, replays, models in inputs_and_variants(checked(binding).parent):
            raw, before, ps, ms = original.pop(o["positive_input"])
            assert all(np.array_equal(a[k], before[k]) for k in a)
            assert o["input_fingerprints"] == raw["input_fingerprints"]
            assert o["measurement_noise"] == raw["noise"] and models == ms
            assert o["noise"]["shot"] == o["noise"]["read"] == 0
            extensions = {model + "#zero": p for model, p in replays.items()}
            bounded_values = {
                model: bounded.correction(p, a, raw, fit["single"]["width"]) for model, p in ps.items()
            }
            extensions |= {model + "#bounded": p for model, p in bounded_values.items()}
            all_rows, rendered, tgt = score(raw, a, ps | extensions, fit)
            for r in all_rows:
                model, _, marker = r["model"].partition("#")
                if marker and r["policy"] == "raw":
                    rows.append(r | {"model": model, "policy": marker})
                if not marker and r["policy"] in ("raw","single"):
                    rows.append(r)
            if o["pattern"] == "RGGB":
                for i, source in enumerate(o["source_ids"]):
                    if source not in picked:
                        continue
                    camera = {k: a[k][i:i+1] for k in ("packed", "colors","wb","matrix")}
                    label = "scale-long86k"
                    boards.append(native_board(
                        out, source, [noisy_malvar(camera)[0], ps[label][i], rendered[label]["single"][i],
                                      bounded_values[label][i], replays[label][i], tgt[i]], camera,
                        {"source": source, "original": raw, "replay": o, "models": models}, exposure=1, contrast=20,
                        labels=("Noisy Malvar","86k positive cond.","86k single lift","86k bounded","86k zero cond.","Exact GT"),
                        triplet_indices=(0,4,5),
                    ))
            paired.append({"raw": raw["id"], "crossed": o["id"], "fingerprints": raw["input_fingerprints"]})
    assert not original and len(boards) == 2 and len(rows) == 12*4*2*4
    summary = source_balance(rows)
    psnr = defaultdict(list)
    for r in rows:
        psnr[r["model"],r["policy"]].append(r["PSNR_sRGB"])
    means = [{"model": k[0],"policy": k[1],"mean_sRGB_PSNR": mean(v)} for k,v in psnr.items()]
    for r in means:
        level = next(g for g in summary if (g["model"],g["policy"],g["band"]) == (r["model"],r["policy"],"0"))
        print(r, level["equal_source_RMS_DN16"], flush=True)
    write_json(out/"result.json", {
        "source": reference(__file__), "conditions": reference(ROOT/"photo-conditioning-plan.json"),
        "bounded_source": reference(ROOT/"large-disagreement.py"), "rows": rows,
        "means": means, "bands": summary, "boards": boards, "paired_inputs": paired,
    })


def main():
    if __import__("sys").argv[1:] == ["analyze"]:
        analyze()
        return
    roots = [ROOT/f"{family}-{i}" for family in ("heldout","photo-conditioning") for i in range(2)]
    runner.review("photo-conditioning-review", roots, (Path(__file__).name,"analyze"))


if __name__ == "__main__":
    main()
