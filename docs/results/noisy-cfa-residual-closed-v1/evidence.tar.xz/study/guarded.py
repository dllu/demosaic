"""Replay the single lift only below eight ADC codes of full-signal noise."""

from pathlib import Path

import numpy as np
import torch
from probe import DN16, GFX, ROOT, delivery, inputs_and_variants, residuals, score
from report_full_faint_photo_panel import source_balance

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

MAX_FULL_SIGNAL_SIGMA_CODES = 8
FIRST = ROOT / "first-heldout-group/result.json"


def in_scope(noise):
    shot, read = noise["shot"], noise["read"]
    step = 1 / (DN16 * 0.97)
    return shot + read > 0 and (shot + read)**0.5 <= MAX_FULL_SIGNAL_SIGMA_CODES * step


def apply(p, a, noise, fit):
    if not in_scope(noise):
        return p
    parts = residuals(p, a, noise["shot"], noise["read"])
    return p + delivery(parts, "single", fit["single"]["width"])


@torch.inference_mode()
def verify(path):
    torch.set_num_threads(2)
    declaration = read_json(path)
    fit = read_json(checked(declaration["calibration"]))["parameters"]
    plan = read_json(checked(declaration["plan"]))
    preflight = read_json(checked(declaration["development_holdout"]))
    excluded = {
        r["source"] for cases in preflight["rows"].values() for r in cases
    }
    assert len(excluded) == 4
    rows, coverage, camera = {}, {}, []
    for binding in plan["heldout"]:
        for o, arrays, predictions, _ in inputs_and_variants(checked(binding).parent):
            if excluded.intersection(o["source_ids"]):
                assert set(o["source_ids"]) == excluded
                continue
            condition = o["noise"]["name"]
            reduced, outputs, _ = score(o, arrays, predictions, fit)
            runs = rows.setdefault(condition, [])
            selected = "single" if in_scope(o["noise"]) else "raw"
            assert coverage.setdefault(condition, selected) == selected
            for model, p in predictions.items():
                candidate = apply(p, arrays, o["noise"], fit)
                np.testing.assert_array_equal(candidate, outputs[model][selected])
                if selected == "raw":
                    assert candidate is p
            runs.extend(r for r in reduced if r["policy"] in ("raw", selected))
    assert set(coverage) == set(plan["profiles"])
    for condition, values in rows.items():
        assert len(values) == 48*2*(2 if condition == "small-positive" else 1)
        assert len({r["source"] for r in values}) == 12
    summary = {p: source_balance(rows[p]) for p in rows}
    for o, a, predictions, _ in inputs_and_variants(GFX, lambda x: x["kind"] in ("gfx", "mesh")):
        for label, p in predictions.items():
            assert not in_scope(o["noise"])
            assert apply(p, a, o["noise"], fit) is p
            camera.append({"observation": o["id"], "model": label, "bypass": True})
    assert len(camera) == 18
    result = ROOT / "guarded-result.json"
    write_json(result, {
        "producer": reference(__file__), "declaration": reference(path), "coverage": coverage,
        "results": summary, "rows": rows, "GFX": camera,
        "scope": "The four first inspected photos suggested the cutoff. Twelve other holdout "
        "sources test it. Both profile and positive-noise guard use only shot/read.",
    })


if __name__ == "__main__":
    import sys
    verify(Path(sys.argv[1]))
