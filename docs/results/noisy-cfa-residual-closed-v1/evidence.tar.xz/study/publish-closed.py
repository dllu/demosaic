"""Publish the complete near-ADC evidence after native viewing and audits."""

import shutil
import tarfile
from pathlib import Path

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT=Path(__file__).resolve().parent
ATTRIB=ROOT.parent/"full427-faint-adc-v1/cohort.json"
FAMILY=ROOT.parent/"low-noise-family-probe-v1"
PALETTE=ROOT.parent/"noisy-residual-reserved-palette-v1"
SCOPE="noisy-cfa-residual-closed-v1"
IMAGES=Path("docs/images")/SCOPE
DATA=Path("docs/results")/SCOPE
FILES={
    "full-photo":ROOT/"review/photos.json",
    "crossed-photo":ROOT/"photo-conditioning-review/result.json",
    "family":FAMILY/"review/result.json",
    "reserved-flats":PALETTE/"review/result.json",
    "adverse-flats":ROOT/"native-display-closed/result.json",
}
AUDIT=ROOT/"independent-closed-audit.json"
NOTES=ROOT/"closed-viewing.json"


def copy(binding, path):
    source=checked(binding)
    shutil.copyfile(source,path)
    current=reference(path)
    assert current["sha256"]==binding["sha256"]
    return {"file":path.relative_to(IMAGES).as_posix(),"sha256":current["sha256"]}


def panels(path,rects):
    values={}
    with Image.open(path) as image:
        for r in rects:
            x,y,w,h=r["png_xywh"]
            assert (w,h)==(160,160) and x+w<=image.width and y+h<=image.height
            values[r["label"]]=image.crop((x,y,x+w,y+h)).tobytes()
    return values


def main():
    IMAGES.mkdir()
    DATA.mkdir()
    data={k:read_json(v) for k,v in FILES.items()}
    notes=read_json(NOTES)
    triplets=data["adverse-flats"]["bounded_triplets"]
    assert set(notes) == set(FILES)
    subjects=read_json(ATTRIB)["source_metadata"]
    credit={r["sha1"]:r for r in subjects}
    manifest={}
    for group, record in data.items():
        folder=IMAGES/group
        folder.mkdir()
        rows=[]
        lessons=notes[group]
        for a in record["boards"]:
            key=a["id"]
            assert key in lessons and a["ROI_xywh"][2:]==[160,160]
            item={k:v for k,v in a.items() if k not in ("board","triplet")}
            b=a["board"]
            item["comparison"]=b | copy(b["image"],folder / Path(b["image"]["path"]).name)
            before=panels(IMAGES/item["comparison"]["file"],b["panels"])
            if group=="crossed-photo":
                t=triplets[key]
                item["triplet"]=t | copy(t["image"],folder / Path(t["image"]["path"]).name)
                subset=panels(IMAGES/item["triplet"]["file"],t["panels"])
                assert len(subset)==3 and all(before[k]==v for k,v in subset.items())
            if "photo" in group:
                item["credit"]=credit[item["source"]]
            rows.append(item | {"actual_viewing":lessons[key]})
        assert len(rows)==len(lessons)
        manifest[group]=rows
    m=IMAGES/"manifest.json"
    write_json(m,manifest)
    shutil.copyfile(AUDIT, DATA/"independent-audit.json")
    shutil.copyfile(FILES["family"], DATA/"family-review.json")
    bindings={}
    for name,folder,files in (
        ("study",ROOT,[
            "plan.json","calibration.json","guarded-declaration.json","photo-conditioning-plan.json",
            "probe.py","guarded.py","guarded-result.json","review-photo-conditioning.py",
            "large-disagreement.py","audit-closed.py","independent-closed-audit.json","closed-viewing.json",
            "publish-closed.py","review/photos.json","photo-conditioning-review/result.json",
            "finish-native-display.py","native-display-closed/result.json","check-implementation.py",
            "photo-review-queued-result.json","guarded-review-queued-result.json","photo-conditioning-review-queued-result.json",
        ]),
        ("family",FAMILY,["replay.py","review.py","review.log","review/result.json","shard-0/result.json","shard-1/result.json"]),
        ("palette",PALETTE,["prepare.py","review.py","review/result.json","plan.json","collection/result.json"]),
    ):
        bindings.update({f"{name}/{f}":folder/f for f in files})
    for stage in ("heldout","photo-conditioning"):
        for i in range(2):
            name=f"{stage}-{i}"
            base=ROOT/name
            for rel in ("plan.json","collection/result.json"):
                bindings[f"study/{name}/{rel}"]=base/rel
            for v in read_json(base/"collection/result.json")["records"]:
                p=checked(v)
                bindings[f"study/{p.relative_to(ROOT)}"]=p
    for i in range(2):
        for v in read_json(FAMILY/f"shard-{i}/result.json")["cases"]:
            p=checked(v)
            bindings[f"family/{p.relative_to(FAMILY)}"]=p
    for v in read_json(PALETTE/"collection/result.json")["records"]:
        p=checked(v)
        bindings[f"palette/{p.relative_to(PALETTE)}"]=p
    optional=ROOT/"implementation-check.json"
    if optional.is_file():
        bindings["study/implementation-check.json"]=optional
        bindings["study/suite.log"]=ROOT/"suite.log"
        code=Path("src/demosaic/adc_bins.py")
        assert reference(code)==read_json(optional)["implementation"]
        bindings["source/adc_bins.py"]=code
        bindings["source/test_adc_bins.py"]=Path("tests/test_adc_bins.py")
    archive=DATA/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz",preset=6) as tar:
        for key,path in sorted(bindings.items()):
            info=tar.gettarinfo(path,arcname=key)
            info.uid=info.gid=info.mtime=0
            info.uname=info.gname=""
            with path.open("rb") as stream:
                tar.addfile(info,stream)
    with tarfile.open(archive) as tar:
        for v in tar:
            assert tar.extractfile(v).read()==bindings[v.name].read_bytes()
    write_json(DATA/"publication.json", {
        "source":reference(__file__),"manifest":reference(m),"archive":reference(archive),
        "independent_audit":reference(DATA/"independent-audit.json"),
        "family_probe":reference(DATA/"family-review.json"),
        "earlier_GFX_native_inspection":reference("docs/images/noisy-cfa-residual-preflight-v1/manifest.json"),
        "tested_GFX_bypasses":read_json(AUDIT)["GFX_bypasses"],
        "source_photos_full":16,"source_photos_prospective":12,
        "viewed_native_comparisons":sum(map(len,manifest.values())),
        "viewed_native_triplets":2,"archive_members":len(bindings),
        "checkpoint":data["crossed-photo"]["boards"][0]["models"]["scale-long86k"]["checkpoint"],
    })
    print("Verified",len(bindings),"archive items")


if __name__=="__main__":
    main()
