"""Prepare exact triplet subsets and render the independently observed worst palette case."""

from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from report_scene_wave_guides import native_board

from demosaic.adc_bins import near_adc_residual_projection
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

from guarded import apply
from probe import ROOT, inputs_and_variants

PALETTE=ROOT.parent/"noisy-residual-reserved-palette-v1"
WANTED=("Noisy Malvar","86k bounded","Exact GT")


def triplet(out,row):
    src=row["board"]
    matched={k:next(r for r in src["panels"] if r["label"]==k) for k in WANTED}
    path=out/f"{row['id']}-bounded-triplet.png"
    canvas=Image.new("RGB",(512,192),"#eeeeee")
    marks=[]
    with Image.open(checked(src["image"])) as board:
        for i,(label,panel) in enumerate(matched.items()):
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160)
            pos=(8+i*168,24)
            canvas.paste(board.crop((x,y,x+w,y+h)),pos)
            ImageDraw.Draw(canvas).text((pos[0],5),label,fill="black")
            marks.append({"label":label,"png_xywh":[*pos,w,h]})
    canvas.save(path)
    return {"image":reference(path),"panels":marks,"source_board":src["image"]}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root=ROOT/"native-display-closed"
    root.mkdir()
    source=ROOT/"photo-conditioning-review/result.json"
    rows=read_json(source)["boards"]
    crops={row["id"]:triplet(root,row) for row in rows}
    fit=read_json(ROOT/"calibration.json")["parameters"]
    selection=lambda o:o["pattern"]=="GBRG" and o["noise"]["name"]=="small-positive"
    case, = list(inputs_and_variants(PALETTE,selection))
    o, data, pred, models=case
    with np.load(checked(o["target"])) as f:
        target=f["target"]
    color=o["source_ids"].index("magenta")
    p=pred["scale-long86k"]
    packed,colors,wb=(torch.from_numpy(data[k]) for k in ("packed","colors","wb"))
    n=o["noise"]
    fixed=near_adc_residual_projection(torch.from_numpy(p),packed,colors,wb,shot=n["shot"],read=n["read"],black_level=.03).numpy()
    a={k:data[k][color:color+1] for k in ("packed","colors","wb","matrix")}
    image=native_board(
        root,"worst-magenta-GBRG",[noisy_malvar(a)[0],p[color],apply(p,data,n,fit)[color],fixed[color],target[color]],
        a,{"source":"magenta","models":models,"observation":o,"selection":"Largest raw bias in the reserved palette."},
        exposure=1,labels=("Noisy Malvar","86k raw","86k single","86k bounded","Exact GT"),
        triplet_indices=(0,3,4),
    )
    write_json(root/"result.json",{"source":reference(__file__),"original_photo_boards":reference(source),
                                   "bounded_triplets":crops,"boards":[image]})
    print("Two exact bounded triplet subsets and one worst-case comparison.")


if __name__=="__main__":
    main()
