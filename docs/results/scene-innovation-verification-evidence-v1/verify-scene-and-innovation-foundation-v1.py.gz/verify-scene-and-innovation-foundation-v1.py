"""Check frozen evidence, source bytes, crop lineage and current doc links."""
import gzip
import re
import tarfile
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, verify_plan, write_json

repo = Path.cwd()
output = repo/'docs/results/scene-innovation-foundation-verification-v1.json'
assert not output.exists()
records = []
for name in ['parent-innovation-completed-pre-review-v1', 'whole-scene-context-foundation-v1']:
    path = repo/'docs/results'/name/'publication.json'
    p = read_json(path)
    for item in p['archives']:
        assert gzip.decompress(checked(item['published']).read_bytes()) == checked(item['original']).read_bytes()
    members = 0
    for snapshot in p.get('source_snapshots', []):
        with tarfile.open(checked(snapshot['archive']), 'r:gz') as tar:
            assert len(tar.getmembers()) == len(snapshot['members'])
            for item in snapshot['members']:
                assert tar.extractfile(item['member']).read() == checked(item['original']).read_bytes()
                members += 1
    records.append({'publication': reference(path), 'archives_exact': len(p['archives']), 'executed_source_members_exact': members})
root = repo/'.cache/experiments/neural-nuisance-parent-innovation129-pilot-v1'
colour = repo/'.cache/experiments/coloured-parent-innovation129-v1'
for folder in [root, colour]:
    plan = read_json(folder/'plan.json')
    verify_plan(plan)
    assert plan['fine_validation'] == 'neural-parent' and plan['fine_support'] == 'joint'
    assert plan['prediction_cache'] is None
    collection = read_json(folder/'collection.json')
    assert len(collection['rows']) == 48 and collection['new_neural_forwards'] == 0
    assert collection['target_or_reference_arrays_loaded'] == 0
assert read_json(root/'quality-review-result.json')['all_stages_succeeded']
assert read_json(colour/'independent-audit-v1.json')['fields_checked'] == 4368
lineage = read_json(repo/'.cache/whole-scene-training-lineage-v1.json')
assert lineage['training_rows'] == 90781 and len(lineage['header_checked_samples']) == 32
assert lineage['minimum_cached_axis_counts'] == {'512':90781,'768':24746,'1024':1759,'1536':47,'2048':3}
links = 0
names = ['README.md','docs/index.md','docs/research.md','docs/experiments.md',
         'docs/weak-detail-literature-2026-11.md','docs/weak-detail-global-context-production-review-2026-11-16.md',
         'docs/whole-scene-context-next-test.md','docs/parent-innovation-validation.md',
         'diary/index.md','diary/2026-11-16-23-37-51-whole-scene-context-innovation.md']
for name in names:
    path = repo/name
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        target = target.split('#')[0]
        if not target or '://' in target:
            continue
        resolved = (path.parent/target).resolve()
        assert resolved == output or resolved.exists(), (name,target)
        links += 1
result = {'script':reference(__file__),'publications':records,'local_MD_links_checked':links,
          'wave_innovation_regression_tests':114,'scene_context_tests':8,
          'all96_new_corrections_closed_before_analysis':True,'new_neural_forwards':0,
          'scope':'Both source snapshots/plans/archive bytes and source/header inventory checked.8 scene preview/query tests and114 innovation regressions passed. No new scene branch training or restoration-quality claim; innovation native actual viewing still pending. Whole-scene/crop noise alignment remains the next data implementation.'}
write_json(output,result)
print(result)
