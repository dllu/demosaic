"""Bind both curvature comparisons and the reviewed native evidence."""
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT = Path(__file__).resolve().parent
RESULT = Path("docs/results/query-phase-curvature-v1")
VIEWS = Path("docs/images/query-phase-curvature-v1")


def preserve(binding,slot,boxes):
    original = checked(binding)
    dest = VIEWS/slot/original.name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original,dest)
    assert binding["sha256"]==reference(dest)["sha256"]
    with Image.open(dest)as img:
        for x,y,w,h in boxes:
            assert w==h==160 and x+w<=img.width and y+h<=img.height
        img.verify()
    return {"path":str(dest),"sha256":binding["sha256"]}


def main():
    RESULT.mkdir(exist_ok=True)
    sr = reference(ROOT/"scores.json")
    measured = read_json(checked(sr))
    backup = reference(ROOT/"fallback-scores.json")
    check = reference(ROOT/"audit.json")
    follow = reference(ROOT/"fallback-audit.json")
    primary = read_json(checked(check))
    supplemental = read_json(checked(follow))
    numbers = read_json(checked(backup))
    assert numbers["original"]==sr==read_json(ROOT/"native/manifest.json")["score"]
    assert supplemental["exact"]["score"]==backup
    assert supplemental["cameras"]["earlier_boards"]==reference(ROOT/"standing/manifest.json")
    assert primary["predictions"]==measured["fresh"]
    arrays = [
        ("exact",read_json(ROOT/"native/manifest.json")),
        ("fallback",read_json(ROOT/"fallback-native/manifest.json")),
        ("standing",read_json(ROOT/"standing/manifest.json")),
    ]
    assert len({m["checkpoint"]["sha256"]for _,m in arrays})==1
    notes = {
        (1,"present"):"Both broad structures are visible. The fitted curved component adds only a faint change and the exact crossing pattern is sharper.",
        (3,"present"):"No curvature was admitted in the first comparison. The weaker curved crossing family in the exact view stays faint.",
        (1,"outside-only"):"Weak periodicity stays visually subdued on top of the complex upper background.",
        (3,"outside-only"):"The stronger diagonal remains visible in the absence of the weaker family. The real edge is preserved.",
        (1,"quiet-query"):"The checked correction arms reproduce the 100k parent in the exact-flat role.",
        (3,"quiet-query"):"The center is visually smooth across the checked arms.",
    }
    for kind,data in arrays:
        for row in data["rows"]:
            if kind=="standing":
                boxes = [r["png_xywh"]for r in row["panels"]]
                ident = row["id"]
                if ident.endswith("mesh-right"):
                    why = "Both diagonal families remain visible, with incomplete crossings. The refined center and checked curvature give the same pixels."
                elif "mesh-left" in ident:
                    why = "The soft cab crop equals the 100k parent."
                elif "sky" in ident:
                    why = "The smooth sky matches the 100k parent exactly."
                elif "fence" in ident:
                    why = "Both coarse crossing directions remain visible and the refined output is close to the planar fit."
                else:
                    why = "Parent appearance is preserved, with soft fine structures."
            else:
                labels = row["order"]if kind=="exact"else row["panes"]
                boxes = [(160*i,0,160,160)for i,_ in enumerate(labels)]
                if kind=="exact":
                    why = notes[row["index"],row["role"]]
                else:
                    why = "The backup adds a faint second direction, with the curved pattern and its context still clearer in the exact target."
            row["image"] = preserve(row["image"],kind,boxes)
            row["viewing"] = why
    assert [len(m["rows"])for _,m in arrays]==[8,4,8]
    manifest = VIEWS/"manifest.json"
    write_json(manifest,dict(arrays)|{"actual_native_viewing_complete":True})
    archive = RESULT/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        names = (
            "prepare.py","curvature.py","select.py","restore_panel.py","measure.py","audit.py","cameras.py",
            "fallback.py","fallback_eval.py","fallback_audit.py","publish.py","plan.json","fields.json",
            "selections-fit.json","selections-fresh.json","selections-standing.json","predictions-fit.json",
            "predictions-fresh.json","scores.json","audit.json","fallback-fit.json","fallback-fresh.json",
            "fallback-standing.json","fallback-delivery-fit.json","fallback-delivery-fresh.json","fallback-scores.json",
            "fallback-audit.json","prepare.log","select-standing.log","select-fit.log","select-fresh.log",
            "restore-fit.log","restore-fresh.log","measure.log","audit.log","cameras.log","fallback.log",
            "fallback-v2.log","fallback-eval.log","fallback-eval-v2.log","fallback-audit.log",
            "native/manifest.json","fallback-native/manifest.json","standing/manifest.json",
        )
        for name in names:
            f.add(ROOT/name,arcname=name)
    write_json(RESULT/"publication.json",{
        "experiment":"query-phase-curvature-v1","training_performed":False,"numeric_evaluation_complete":True,
        "actual_native_viewing_complete":True,"parent":arrays[-1][1]["checkpoint"],
        "scales":measured["scales"],"calibration_caps":measured["limits"],"main_overall":measured["overall"],
        "main_by_geometry":measured["by_geometry"],"main_audit":primary,
        "backup_scales":numbers["scales"],"backup_bent":numbers["bent"],"backup_straight":numbers["straight"],
        "backup_gap_and_camera_parity":supplemental,
        "manifest":reference(manifest),"archive":reference(archive),
        "scope":"One fixed-scene synthetic comparison and one same-capture backup replay; both standing GFX families viewed. No comparable full427 or measured-camera-panel score for this inference-only component.",
    })


if __name__=="__main__":
    main()
