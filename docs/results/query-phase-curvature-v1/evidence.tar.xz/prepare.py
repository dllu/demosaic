"""Freeze new camera-linear targets and noise for the reserved curvature comparison."""
import hashlib
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.scene_data import scene_crop_boxes
from demosaic.scene_training_data import scene_seed

ROOT = Path(__file__).resolve().parent
LAST = ROOT.parent/"query-frequency-consensus-v1"
sys.path.insert(0,str(LAST))
import prepare as generator

SEED = 721691005083
COUNT = 20


def run():
    archive = reference(LAST/"plan.json")
    last = read_json(checked(archive))
    previous = read_json(checked(last["preceding"]))
    broad = read_json(checked(previous["comparison"]))
    local = read_json(checked(broad["prior"]))
    weak = read_json(checked(local["exclusion"]))
    repeat = read_json(ROOT.parent/"paired-repeat-stability-v2/evaluation-plan.json")
    cohort = read_json(checked(last["cohort"]))
    excluded = {r["source"]["id"]for r in [*last["sources"],*previous["sources"],*broad["sources"],
                 *local["sources"],*weak["heldout_rows"],*repeat["rows"]]}
    eligible = [r for r in cohort["source_metadata"]if r["split"]=="val" and r["bin_factor"]==4
                and min(r["shape"][:2])>=512 and np.prod(r["shape"][:2])<=4_000_000 and r["id"]not in excluded]
    ranked = sorted(eligible,key=lambda r:hashlib.sha256(f'{SEED}/{r["id"]}'.encode()).hexdigest())
    fields = generator.fields
    fields.ROOT = ROOT
    fields.SEED = SEED
    fields.clean_targets = generator.clean_targets
    rows = []
    for i,photo in enumerate(ranked[:COUNT]):
        box, = scene_crop_boxes(photo["shape"][:2],patch_size=512,count=1,seed=scene_seed(SEED,i,"selection"))
        layout = fields.draw(i)
        bend = (0 if i%2==0 else (1 if i%4==1 else -1)*(.000035+i*.00000145))
        layout.update({"weak_tangential_curvature_cycles_per_px2":bend,
                       "strong_tangential_curvature_cycles_per_px2":-.70*bend})
        rows.append(fields.row_for(photo,i,SEED)|{"box":box,"layout":layout})
    assert len({r["source"]["id"]for r in rows})==COUNT
    write_json(ROOT/"plan.json",{
        **{k:last[k]for k in ("cohort","base","roles","profile","repeat_count","query_box")},
        "driver":reference(__file__),"target_generator":reference(LAST/"prepare.py"),"preceding":archive,
        "sources":rows,"seed":SEED,"fit_indices":[],"test_indices":list(range(COUNT)),
        "scope":"20 new held-out photo sources, two physical redraws of four roles. Half have opposite-signed gentle bends in the two carrier families, and half are straight. No configuration or strength is fitted on these fields."
    })
    fields.construct()


if __name__=="__main__":
    run()
