"""Verify sample isolation and evaluate the fitted geometry against exact controls."""
from itertools import permutations
import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from curvature import ROOT,choose,deliver,local,anchored
from consensus import cut
from run_restore import ARGS,observations


def phase_compat(estimate,truth,region):
    y,x = np.indices(region.shape,dtype=float)-127.5
    p = lambda f,k: x*f[0]+y*f[1]+.5*k*((f[0]*y-f[1]*x)/np.linalg.norm(f))**2
    a = p(estimate[:2],estimate[2])
    b = p(truth[:2],truth[2])
    return float(abs(np.exp(2j*np.pi*(a-b)[region]).mean()))


def aligned(pair,truth):
    if len(pair)!=2:
        return None
    reference = np.array(truth)
    variants = []
    for feature in permutations(np.asarray(pair)):
        f = np.asarray(feature).copy()
        f *= np.where((f[:,:2]*reference[:,:2]).sum(axis=-1)<0,-1,1)[:,None]
        screen = np.linalg.norm(f[:,:2]-reference[:,:2],axis=1)
        variants.append((float(screen.sum()),screen,f))
    _,delta,solution = min(variants,key=lambda v:v[0])
    return solution if delta.max()<=3/256 else None


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    selected = reference(ROOT/"selections-fresh.json")
    cases = read_json(checked(selected))
    data = read_json(checked(cases["observations"]))
    plan = read_json(checked(data["plan"]))
    seed = np.random.default_rng(924171065)
    training = read_json(ROOT.parent.joinpath("scene-full-epoch-v1","plan.json"))["train_manifest"]
    with checked(training).open()as f:
        ids = {json.loads(v)["id"]for v in f}
    assert len(ids)==90692 and not ids.intersection(r["source"]["id"]for r in plan["sources"])
    solved = reference(ROOT/"predictions-fresh.json")
    outputs = read_json(checked(solved))
    assert outputs["selection"]==selected
    traces = []
    sample_tests = []
    with anchored((0,0)),ieee_fp32():
        held = local.partition()>=2
        for record,source,pred in zip(cases["rows"],plan["sources"],outputs["rows"],strict=True):
            i = record["index"]
            spec = source["layout"]
            targets = [(*spec[k+"_frequency_xy"],spec[k+"_tangential_curvature_cycles_per_px2"])for k in ("strong","weak")]
            raw = observations(data["rows"][i])
            intact = raw["region"]==1
            frames = []
            for draw in record["trials"]:
                if draw["role"]!="present":
                    continue
                seeds = [p["frequency_xy"]for p in draw["frequency_selection"]["peaks"]]
                if not seeds:
                    frames.append({"observed":False,"repeat":draw["repeat"]})
                    continue
                guesses = {name:aligned(draw["methods"][name],targets)for name in ("planar","recentered","curved")}
                compatible = all(g is not None for g in guesses.values())
                h = {
                    name:{"curvature_error_cycles_per_native_pixel²":[float(p[2]-t[2])for p,t in zip(value,targets)],
                          "phase_coherence_on_intact_roi":[phase_compat(p,t,intact)for p,t in zip(value,targets)]}
                    for name,value in guesses.items()if value is not None
                }
                frames.append({"observed":True,"repeat":draw["repeat"],"aligned_to_both":compatible,"geometry":h})
                if len(sample_tests)>=6 or not draw["methods"]["curvature_evidence"]:
                    continue
                rep,j = draw["repeat"],0
                packed,variance,colors = (raw[k][rep,j].copy()for k in ARGS[:3])
                chosen = choose(packed,variance,colors,seeds)
                assert chosen==draw["methods"]
                scrambled = [arr.copy()for arr in (packed,variance)]
                for v in scrambled:
                    v[:,held] = seed.uniform(.05,.80,(4,int(held.sum()))).astype(np.float32)
                assert choose(*scrambled,colors,seeds)==chosen
                method = draw["methods"]["curved"]
                with np.load(checked(pred["output"]),allow_pickle=False)as archive:
                    parent = torch.from_numpy(archive["baseline"][rep,j:j+1].copy())
                    expected = archive["curved"][rep,j].copy()
                args = [raw[name][rep,j:j+1].copy()for name in ARGS]
                lift = deliver([torch.from_numpy(t)for t in args],parent,method).numpy()[0]
                for arr in args[:2]:
                    arr[...,~held] = seed.uniform(.05,.8,(1,4,int((~held).sum()))).astype(np.float32)
                replaced = deliver([torch.from_numpy(t)for t in args],parent,method).numpy()[0]
                np.testing.assert_array_equal(lift,replaced)
                np.testing.assert_allclose(lift,expected,rtol=0,atol=3e-8)
                sample_tests.append({"index":i,"repeat":rep,"replaced_packed_cells":int(held.sum()),
                                     "q0_q1_geometry_unchanged":True,"q2_q3_delivery_unchanged_with_fixed_parent":True,
                                     "independent_CPU_GPU_max_error":float(np.abs(lift-expected).max())})
            traces.append({"index":i,"true_curvature":targets[1][2],"frames":frames})
    assert len(sample_tests)>=4
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"selections":selected,"predictions":solved,
        "phase_checks":traces,"isolation_checks":sample_tests,"training_manifest":training,"training_overlap":0,
        "scope":"Compare the proposal phase against the exact isolated chirps only for analysis. Geometry excludes Q2 and Q3; delivery excludes Q0 and Q1 at fixed parent and predictions."})
    print(len(sample_tests),max(x["independent_CPU_GPU_max_error"]for x in sample_tests),flush=True)


if __name__=="__main__":
    main()
