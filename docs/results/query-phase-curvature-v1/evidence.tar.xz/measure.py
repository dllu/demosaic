"""Match false-detail calibration and score straight and bent held-out photos."""
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from restore_panel import ROOT,OLD,METHODS,observations
import score_panel as metrics

ALL = ("baseline",*METHODS)
metrics.METHODS = METHODS
CONTRAST = (("recentered","planar"),("curved","recentered"),("curved","planar"),
            ("exact-curved","exact-planar"),("exact-curved","curved"),("curved","baseline"))


def bind(mode):
    ref = reference(ROOT/f"predictions-{mode}.json")
    predicted = read_json(checked(ref))
    selected = read_json(checked(predicted["selection"]))
    inputs = read_json(checked(selected["observations"]))
    plan = read_json(checked(inputs["plan"]))
    return ref,predicted,selected,inputs,plan


def samples(mode):
    ref,predicted,selected,inputs,plan = bind(mode)
    stored = []
    for index,item in enumerate(predicted["rows"]):
        i = item["index"]
        archive = inputs["rows"][i]
        source = plan["sources"][i]
        nominate = selected["rows"][index]
        assert nominate["index"]==archive["index"]==i==source["index"] and nominate["input"]==archive["capture"]
        saved = metrics.analyze(archive,item)
        stored.append({"index":i,"id":source["source"]["id"],"curvature":source["layout"].get("weak_tangential_curvature_cycles_per_px2",0),
                       "choices":nominate["trials"],"saved":saved})
    return ref,stored


def evaluate(source,scale):
    return [{"index":r["index"],"id":r["id"],"curvature":r["curvature"],
             "metrics":{name:metrics.values(r["saved"],name,scale.get(name,1))for name in ALL}}
            for r in source]


def summarize(rows):
    generator = np.random.default_rng(878134201)
    indexes = generator.integers(len(rows),size=(10000,len(rows)))
    table = {}
    for name in metrics.METRICS:
        values = {method:np.array([r["metrics"][method][name]for r in rows])for method in ALL}
        summary = {}
        for revised,original in CONTRAST:
            deltas = values[revised]-values[original]
            lo,hi = np.quantile(deltas[indexes].mean(axis=1),(.025,.975))
            summary[f"{revised}_vs_{original}"] = [float(deltas.mean()),float(lo),float(hi)]
        table[name] = {"means":{k:float(v.mean())for k,v in values.items()},
                       "paired_difference_and_95pct":summary}
    return table


def triggers(rows):
    counts = {}
    for name in ("present","outside-only","strong-only","quiet-query"):
        shots = [choice["methods"]for r in rows for choice in r["choices"]if choice["role"]==name]
        counts[name] = {"observed":len(shots),"initial_pair":sum(bool(s["planar"])for s in shots),
                        "recentered":sum(bool(s["recenter_evidence"])for s in shots),
                        "curved":sum(bool(s["curvature_evidence"])for s in shots)}
    return counts


def main():
    a,old_cases = samples("fit")
    b,new_cases = samples("fresh")
    baseline = reference(OLD/"scores.json")
    earlier = read_json(checked(baseline))
    fitting = evaluate(old_cases,{})
    limits = earlier["limits"]
    nominal = {key:{name:float(np.mean([k["metrics"][name][key]for k in fitting]))for name in METHODS}
               for key in limits}
    scales = {name:min([1.,*(limit/nominal[key][name]for key,limit in limits.items()if nominal[key][name]>0)])
              for name in METHODS}
    assert abs(scales["planar"]-earlier["calibration_scales"]["consensus"]) < 1e-9
    trials = evaluate(new_cases,scales)
    raw = evaluate(new_cases,{})
    details = {}
    for key,which in (("straight",False),("bent",True)):
        subgroup = [r for r in trials if bool(r["curvature"])==which]
        assert len(subgroup)==10
        details[key] = {"metrics":summarize(subgroup),
                        "selections":triggers([r for r in new_cases if bool(r["curvature"])==which])}
    write_json(ROOT/"scores.json",{
        "driver":reference(__file__),"fit":a,"fresh":b,"parent_calibration":baseline,
        "limits":limits,"scales":scales,"calibration_nominal":nominal,
        "calibration_rows":fitting,"test_rows":trials,"nominal_test_rows":raw,
        "overall":summarize(trials),"nominal":summarize(raw),"by_geometry":details,
        "calibration_triggers":triggers(old_cases)})
    print("scales",scales,flush=True)


def native():
    torch.set_num_threads(2)
    source = reference(ROOT/"scores.json")
    numbers = read_json(checked(source))
    bound,predictions,choices,inputs,plan = bind("fresh")
    assert bound==numbers["fresh"]
    curved = [r for r in choices["rows"]if plan["sources"][r["index"]]["layout"]["weak_tangential_curvature_cycles_per_px2"]]
    show = [(next(r for r in curved if r["trials"][0]["methods"]["curvature_evidence"])["index"],"accepted curvature"),
            (next(r for r in curved if not r["trials"][0]["methods"]["curvature_evidence"])["index"],"no accepted curvature")]
    directory = ROOT/"native"
    directory.mkdir(exist_ok=True)
    cards = []
    for index,reason in show:
        meta = plan["sources"][index]
        capture = inputs["rows"][index]
        predicted = predictions["rows"][index]
        view = observations(capture)
        with np.load(checked(predicted["output"]),allow_pickle=False)as data:
            base = data["baseline"][0]
            arguments = {"baseline":base,**{name:base+numbers["scales"][name]*data[name][0]for name in METHODS}}
        noisy = malvar(torch.from_numpy(view["packed"][0]),torch.from_numpy(view["colors"][0])).numpy()
        rgb = arguments|{"noisy":noisy,"exact":view["target"][0]}
        cam = {k:view[k][0] for k in ("wb","matrix")}
        photos = {k:np.rint(display(v,cam,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)
                  for k,v in rgb.items()}
        for label,role in (("present",0),("outside-only",1),("quiet-query",3)):
            together = [("all",(*ALL,"exact"))]
            if role==0:
                together += [("triplet",("noisy","curved","exact"))]
            for style,select in together:
                p = directory/f"{index:03d}-{label}-{style}.png"
                Image.fromarray(np.concatenate([photos[name][role]for name in select],axis=1)).save(p,optimize=True)
                cards.append({"image":reference(p),"order":select,"index":index,"selection":reason,"role":label,
                              "photo":meta["source"],"source_box_xywh":meta["box"],"query_box":plan["query_box"],
                              "display_ROI_xywh":[48,48,160,160],"capture":capture,
                              "prediction":predicted,"CFA":meta["camera"]["pattern"],"noise":plan["profile"],
                              "display_exposure":2,"repeat":0})
    write_json(directory/"manifest.json",{"driver":reference(__file__),"score":source,
        "checkpoint":plan["base"],"rows":cards,"display":"Same WB/matrix, exposure ×2, clipped sRGB8."})


if __name__=="__main__":
    main()
    native()
