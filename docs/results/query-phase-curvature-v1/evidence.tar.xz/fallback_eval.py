"""Evaluate a curvature-first backup against the same parent and exact observations."""
from pathlib import Path
import importlib.util
import time

import numpy as np
from PIL import Image
import torch

from demosaic.archive_metrics import display
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from restore_panel import ARGS,grouped,observations
from curvature import ROOT
spec = importlib.util.spec_from_file_location("query_curvature_measure", ROOT/"measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
bind,evaluate,metrics,summarize = (measure.bind,measure.evaluate,measure.metrics,measure.summarize)

EXTRA = ("fallback-planar","fallback-curved")
NORMAL = ("planar","recentered","curved")
METHODS = (*NORMAL,"exact-planar","exact-curved",*EXTRA)


@torch.inference_mode()
def deliver_fallback(mode):
    before,prior,_,captures,plan = bind(mode)
    decision_ref = reference(ROOT/f"fallback-{mode}.json")
    decisions = read_json(checked(decision_ref))
    assert decisions["seeds"]==prior["selection"]
    root = ROOT/f"fallback-output-{mode}"
    root.mkdir(exist_ok=True)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    output = []
    t0 = time.monotonic()
    with ieee_fp32():
        for old,setup in zip(prior["rows"],decisions["decisions"],strict=True):
            i = old["index"]
            assert i==setup["index"]
            path = root/f"{i:03d}.npz"
            if not path.exists():
                with np.load(checked(old["output"]),allow_pickle=False)as f:
                    arrays = {n:f[n]for n in f.files}
                captured = observations(captures["rows"][i])
                args = [torch.from_numpy(captured[k].reshape(-1,*captured[k].shape[2:])).cuda()for k in ARGS]
                base = torch.from_numpy(arrays["baseline"].reshape(8,3,256,256)).cuda()
                for name,label in zip(EXTRA,("recentered","curved"),strict=True):
                    values = arrays[label].copy().reshape(8,3,256,256)
                    selected = [j for j,r in enumerate(setup["rows"])if
                                r["activated_when_consensus_missing"] and r["methods"][name]]
                    if selected:
                        proposal = [setup["rows"][j]["methods"][name]for j in selected]
                        updates = grouped([q[selected]for q in args],base[selected],proposal).cpu().numpy()
                        values[selected] = updates
                    arrays[name] = values.reshape(2,4,3,256,256)
                partial = path.with_suffix(".incomplete")
                with partial.open("wb")as f:
                    np.savez(f,**arrays)
                partial.rename(path)
            output.append({"index":i,"output":reference(path)})
    write_json(ROOT/f"fallback-delivery-{mode}.json",{"driver":reference(__file__),"original":before,
               "fallback_selection":decision_ref,"checkpoint":plan["base"],"seconds":time.monotonic()-t0,"rows":output})


def panel(mode):
    ref = reference(ROOT/f"fallback-delivery-{mode}.json")
    grant = read_json(checked(ref))
    stamp,_,_,captures,plan = bind(mode)
    assert stamp==grant["original"]
    data = []
    for row in grant["rows"]:
        i = row["index"]
        source = plan["sources"][i]
        product = metrics.analyze(captures["rows"][i],row)
        data.append({"index":i,"id":source["source"]["id"],"curvature":source["layout"].get("weak_tangential_curvature_cycles_per_px2",0),
                     "saved":product})
    return ref,data


def score():
    metrics.METHODS = METHODS
    measure.ALL = ("baseline",*METHODS)
    measure.CONTRAST = (("fallback-planar","recentered"),("fallback-curved","curved"),
                        ("fallback-curved","fallback-planar"),("fallback-curved","exact-curved"))
    original = reference(ROOT/"scores.json")
    start = read_json(checked(original))
    left,fitted = panel("fit")
    right,fresh = panel("fresh")
    caps = start["limits"]
    train = evaluate(fitted,{})
    raw = {k:{method:float(np.mean([r["metrics"][method][k]for r in train]))for method in EXTRA}for k in caps}
    scale = start["scales"]|{k:min([1.,*(v/raw[metric][k]for metric,v in caps.items()if raw[metric][k]>0)])for k in EXTRA}
    target = evaluate(fresh,scale)
    write_json(ROOT/"fallback-scores.json",{
        "driver":reference(__file__),"original":original,"fit":left,"fresh":right,"limits":caps,
        "scales":scale,"nominal_added_calibration":raw,"test_rows":target,
        "overall":summarize(target),"bent":summarize([r for r in target if r["curvature"]]),
        "straight":summarize([r for r in target if not r["curvature"]]),
        "scope":"A follow-up replay on the same fresh captures, after the initial results were seen. Raw nomination rules were fixed before the backup was run. Strength calibration stays on the 12 prior fields."})
    print(scale,flush=True)


def native():
    torch.set_num_threads(2)
    evaluated = reference(ROOT/"fallback-scores.json")
    numbers = read_json(checked(evaluated))
    predictions = read_json(checked(numbers["fresh"]))
    fallback = read_json(checked(predictions["fallback_selection"]))
    _,_,_,captures,plan = bind("fresh")
    known = {r["index"]:r for r in numbers["test_rows"]}
    candidates = [r for r in fallback["decisions"]if
                  plan["sources"][r["index"]]["layout"]["weak_tangential_curvature_cycles_per_px2"] and
                  r["rows"][0]["methods"]["adopted_curvature"]]
    # Illustrate the first two adopted examples by source order, independently of test metrics.
    chosen = sorted(candidates,key=lambda x:x["index"])[:2]
    folder = ROOT/"fallback-native"
    folder.mkdir(exist_ok=True)
    table = []
    for region in chosen:
        i = region["index"]
        capture = captures["rows"][i]
        forecast = predictions["rows"][i]
        assert forecast["index"]==i
        material = observations(capture)
        source = plan["sources"][i]
        with np.load(checked(forecast["output"]),allow_pickle=False)as f:
            base = f["baseline"][0]
            values = {"baseline":base,**{n:base+numbers["scales"][n]*f[n][0]for n in ("recentered","curved",*EXTRA,"exact-curved")}}
        noisy = malvar(torch.from_numpy(material["packed"][0]),torch.from_numpy(material["colors"][0])).numpy()
        values |= {"noisy":noisy,"gt":material["target"][0]}
        camera = {k:material[k][0]for k in ("wb","matrix")}
        rendered = {k:np.rint(display(v,camera,exposure=2)[...,48:208,48:208].transpose(0,2,3,1)*255).astype(np.uint8)for k,v in values.items()}
        for style,names in (("triplet",("noisy","fallback-curved","gt")),
                             ("all",("baseline","recentered","curved",*EXTRA,"exact-curved","gt"))):
            image = folder/f"{i:03d}-present-{style}.png"
            Image.fromarray(np.concatenate([rendered[k][0]for k in names],axis=1)).save(image,optimize=True)
            table.append({"image":reference(image),"index":i,"photo":source["source"],"source_box":source["box"],
                           "capture":capture,"prediction":forecast,"ROI":[48,48,160,160],"native_query":plan["query_box"],
                           "panes":names,"repeat":0,"display_exposure":2,"CFA":source["camera"]["pattern"],
                           "noise":plan["profile"],"metrics":known[i]})
    assert len(table)==4
    write_json(folder/"manifest.json",{"driver":reference(__file__),"source":evaluated,"checkpoint":plan["base"],"rows":table})


if __name__=="__main__":
    deliver_fallback("fit")
    deliver_fallback("fresh")
    score()
    native()
