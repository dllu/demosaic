"""Continuously refine two carrier phases, then require reserved predictive gain."""
from pathlib import Path
import math
import sys

import numpy as np
import torch
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/"query-frequency-consensus-v1"
sys.path.insert(0,str(OLD))
from consensus import anchored,local

N = 256
GRID = 16
METHODS = ("planar","recentered","curved","exact-planar","exact-curved")


def wave_columns(x,y,geometry):
    bank = []
    for fx,fy,bend in geometry:
        t = (-fy*x+fx*y)/math.hypot(fx,fy)
        phase = 2*np.pi*(fx*x+fy*y+.5*bend*t*t)
        bank.extend((np.cos(phase),np.sin(phase)))
    return np.column_stack(bank)


def subsets(packed,variance,colors):
    folds = local.partition()
    rows,cols = np.indices(folds.shape)
    records = local.green_records(packed,variance,colors)
    samples = []
    for fold in (0,1):
        valid = folds==fold
        parts = []
        for ch,signal,noise in records:
            x = 2*cols[valid]+ch%2-127.5
            y = 2*rows[valid]+ch//2-127.5
            # Cap the leverage of samples far from the query center.
            weight = np.exp(-.5*(x*x+y*y)/78**2)/noise[valid]
            raw = signal[valid]
            parts.append((x,y,weight,raw))
        samples.append(tuple(np.concatenate(t)for t in zip(*parts,strict=True)))
    return samples


def fit(data,geometry):
    x,y,w,raw = data
    design = wave_columns(x,y,geometry)
    gram = design.T@(w[:,None]*design)
    coef = np.linalg.solve(gram,design.T@(w*raw))
    return coef,design,raw-design@coef


def refine(data,seed,indices,bend):
    x,y,w,raw = data
    base = np.array(seed,dtype=float)
    values = base.copy()
    denom = 128.
    # Express a geometry change as cycles rather than per-pixel quantities.
    max_offset = .0055
    max_bend = .000085
    for _ in range(4):
        coeff,design,residual = fit(data,values)
        derived = []
        for i in indices:
            fx,fy,_ = values[i]
            t = (-fy*x+fx*y)/math.hypot(fx,fy)
            phase_jac = 2*np.pi*(coeff[2*i+1]*design[:,2*i]-coeff[2*i]*design[:,2*i+1])
            slopes = [x/denom,y/denom]
            if bend:
                slopes.append(.5*(t/denom)**2)
            derived.extend(phase_jac*a for a in slopes)
        derivative = np.column_stack(derived)
        both = np.column_stack((design,derivative))
        gram = both.T@(w[:,None]*both)
        ridge = .012*np.mean(gram.diagonal()[4:]).clip(min=1)
        gram.flat[4*(len(gram)+1)::len(gram)+1] += ridge
        delta = np.linalg.solve(gram,both.T@(w*residual))[4:]
        if not np.isfinite(delta).all():
            break
        width = 3 if bend else 2
        for j,i in enumerate(indices):
            requested = .65*np.clip(delta[j*width:(j+1)*width],-.48,.48)
            values[i,:2] += requested[:2]/denom
            values[i,:2] = np.clip(values[i,:2],base[i,:2]-max_offset,base[i,:2]+max_offset)
            if bend:
                values[i,2] = np.clip(values[i,2]+requested[2]/denom**2,-max_bend,max_bend)
    return values


def prediction(fit_data,test_data,shape):
    coef,_,_ = fit(fit_data,shape)
    x,y,_,_ = test_data
    return wave_columns(x,y,shape)@coef


def standardized(test_data,older,newer):
    _,_,w,target = test_data
    delta = newer-older
    sigma = max(1e-20,np.sum(w*delta**2))**.5
    return float(np.sum(w*delta*(target-(older+newer)*.5))/sigma)


def directional_support(train,test,model):
    whole = prediction(train,test,model)
    return [
        standardized(test,prediction(train,test,model[[1-i]]),whole)
        for i in (0,1)
    ]


def adopt(train,test,base,candidates):
    """Apply each deformation separately, then test the combined pair."""
    still = prediction(train,test,base)
    options = []
    for i in (0,1):
        alter = base.copy()
        alter[i] = candidates[i]
        new = prediction(train,test,alter)
        decision = standardized(test,still,new)
        if decision>=1.5 and min(directional_support(train,test,alter))>=2.75:
            options.append((decision,i,alter[i]))
    result = base.copy()
    for score,i,row in options:
        result[i] = row
    if len(options)==2 and (
        standardized(test,still,prediction(train,test,result))<1.5
        or min(directional_support(train,test,result))<2.75
    ):
        result = base.copy()
        score,i,row = max(options,key=lambda p:p[0])
        result[i] = row
        options = [(score,i,row)]
    return result,[{"direction":i,"standardized_gain":score}for score,i,_ in options]


def choose(packed,variance,colors,nominees):
    if len(nominees)!=2:
        return {"planar":[],"recentered":[],"curved":[],"recenter_evidence":[],"curvature_evidence":[]}
    seeds = np.array([(*z,0.)for z in nominees])
    with anchored((0,0)):
        train,test = subsets(packed,variance,colors)
    located = refine(train,seeds,(0,1),bend=False)
    planar,nudged = adopt(train,test,seeds,located)
    candidate = refine(train,planar,(0,1),bend=True)
    final,proof = adopt(train,test,planar,candidate)
    return {"planar":seeds.tolist(),"recentered":planar.tolist(),"curved":final.tolist(),
            "recenter_evidence":nudged,"curvature_evidence":proof,
            "candidate_steps":candidate.tolist(),"confirmed_support":directional_support(train,test,final)}


def torch_phase(x,y,geometry):
    fx,fy,bend = geometry
    t = (-fy*(x-127.5)+fx*(y-127.5))/math.hypot(fx,fy)
    return (x*fx+y*fy+.5*bend*t.square())*(2*torch.pi)


def local_fits(packed,variance,colors,parent,signal,other):
    device = packed.device
    green = torch.where(colors[0]==1)[0]
    row,col = torch.meshgrid(torch.arange(128,device=device),torch.arange(128,device=device),indexing="ij")
    yy = (2*row+green[:,None,None]//2).flatten()
    xx = (2*col+green[:,None,None]%2).flatten()
    split = torch.from_numpy(local.partition()).to(device).expand(2,-1,-1).flatten()
    sign = torch.stack((torch.ones_like(row),-torch.ones_like(row))).flatten()
    values = torch.cat((packed[:,green].flatten(1),parent[:,1,yy,xx])).double()
    noise = variance[:,green].flatten(1).repeat(2,1).double()
    yy,xx = yy.double(),xx.double()
    y,x = (yy-127.5)/128,(xx-127.5)/128
    native = (torch.arange(GRID,device=device,dtype=torch.float64)*16+7.5).clamp(32,223)
    cy,cx = torch.meshgrid(native,native,indexing="ij")
    radius = (xx[None]-cx.reshape(-1,1)).square()+(yy[None]-cy.reshape(-1,1)).square()
    inside = (x.abs()<=.70)&(y.abs()<=.70)
    weights = {"local":(-radius/(2*9**2)).exp()*inside*(radius<30**2),
               "exterior":(-radius/(2*42**2)).exp()*inside*(radius>=30**2)}
    competing = torch_phase(xx,yy,other)
    weak = torch_phase(xx,yy,signal)
    c,s = competing.cos(),competing.sin()
    basis = torch.stack((torch.ones_like(x),x,y,sign,sign*x,sign*y,c,s,c*x,c*y,s*x,s*y,weak.cos(),weak.sin()),dim=-1)
    groups = [split==k for k in (2,3)]
    return {name:[local.solve(basis[g],values[:,g],noise[:,g],weight[:,g])for g in groups]
            for name,weight in weights.items()}


def lift(coefficient,shape):
    p = torch.arange(N,device=coefficient.device,dtype=torch.float64)
    phase = torch_phase(p[None,:],p[:,None],shape)
    plane = coefficient.reshape(-1,GRID,GRID,2).permute(0,3,1,2)
    plane = F.interpolate(plane,(N,N),mode="bilinear",align_corners=False)
    taper = ((112-(p-127.5).abs())/24).clamp(0,1)
    return (plane[:,0]*phase.cos()+plane[:,1]*phase.sin())*taper[:,None]*taper[None,:]


def deliver(args,parent,geometry):
    if len(geometry)!=2:
        return torch.zeros_like(parent)
    with anchored((0,0)):
        if not any(g[2] for g in geometry):
            return local.restore(args,parent,[g[:2]for g in geometry])
        packed,variance,colors,wb,matrix = args
        gains = torch.linalg.solve(matrix,torch.ones_like(wb)[...,None]).squeeze(-1)/wb
        gains = gains/gains[:,1:2]
        total = torch.zeros_like(parent)
        for i in (0,1):
            shape = geometry[i]
            fits = local_fits(packed,variance,colors,parent,shape,geometry[1-i])
            add = lift(local.amplitude("exterior",fits,packed.shape[0]),shape)
            total += (add[:,None]*gains[:,:,None,None]).to(total.dtype)
        return total
