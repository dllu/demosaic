"""Bind the same stable frequency seeds for all curvature arms."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from curvature import ROOT,OLD,choose
from consensus import OFFSETS,anchored,cut,grouped,local,proposal

ROLES = ("present","outside-only","strong-only","quiet-query")


def frequencies(data,x,y):
    votes = [proposal(data,x,y,d,[])["local"]for d in OFFSETS]
    hint = grouped(votes)
    with anchored((0,0)):
        reserved = local.green_records(*cut(data,x,y))
        checked_pair = local.conditional_pair(reserved,hint["peaks"])
    return checked_pair|{"votes":hint["votes"]}


def rows(job):
    rec,geometry,prior = job
    with np.load(checked(rec["capture"]),allow_pickle=False)as f:
        sources = {k:f[k]for k in ("packed","variance","colors")}
    assert {k:fingerprint(v)for k,v in sources.items()}=={k:rec["fingerprints"][k]for k in sources}
    result = []
    for r in range(2):
        for i,name in enumerate(ROLES):
            fields = {k:v[r,i:i+1]for k,v in sources.items()}
            selected = frequencies(fields,128,128)if prior is None else prior["trials"][r*4+i]["methods"]["consensus"]
            seeds = [p["frequency_xy"]for p in selected["peaks"]]
            params = choose(*cut(fields,128,128),seeds)
            result.append({"repeat":r,"role":name,"frequency_selection":selected,"methods":params})
    return {"index":rec["index"],"input":rec["capture"],"trials":result}


def scene(mode):
    record = reference(OLD/"nominations-fit.json") if mode=="fit" else None
    old = read_json(checked(record))if record else None
    pointer = old["upstream"]if old else reference(ROOT/"fields.json")
    source = read_json(checked(pointer))
    plan = read_json(checked(source["plan"]))
    indices = plan["fit_indices"]if mode=="fit" else plan["test_indices"]
    inherited = {r["index"]:r for r in old["rows"]}if old else {}
    jobs = [(source["rows"][i],plan["sources"][i],inherited.get(i))for i in indices]
    result = []
    with ThreadPoolExecutor(3)as pool:
        for q,row in enumerate(pool.map(rows,jobs),1):
            result.append(row)
            print(mode,q,len(jobs),flush=True)
    write_json(ROOT/f"selections-{mode}.json",{"driver":reference(__file__),"method":reference(ROOT/"curvature.py"),
                                             "observations":pointer,"inherited_frequencies":record,"rows":result})


def cameras():
    saved = reference(OLD/"nominations-standing.json")
    upstream = read_json(checked(saved))
    out = []
    for region in upstream["rows"]:
        x,y,_,_ = region["fit_xywh"]
        with np.load(checked(region["raw"]),allow_pickle=False)as f:
            data = {k:f[k]for k in ("packed","variance","colors")}
        peaks = [p["frequency_xy"]for p in region["methods"]["consensus"]["peaks"]]
        fitted = choose(*cut(data,x,y),peaks)
        print(region["id"],len(peaks),fitted,flush=True)
        out.append({"id":region["id"],"native_box":region["fit_xywh"],"input":region["raw"],
                    "methods":fitted,"proposal":region["methods"]["consensus"]})
    write_json(ROOT/"selections-standing.json",{"driver":reference(__file__),"method":reference(ROOT/"curvature.py"),
                                               "inherited":saved,"rows":out})


if __name__=="__main__":
    action = sys.argv[1]
    cameras() if action=="standing" else scene(action)
