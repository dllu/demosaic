"""Test third-party-free reserve nomination when a curved pair misses planar consensus."""
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from curvature import ROOT,anchored,local,subsets,fit,refine,prediction,standardized,directional_support
from consensus import cut


def select(packed,variance,colors):
    with anchored((0,0)):
        bank = local.local_bank(local.green_records(packed,variance,colors))
        train,test = subsets(packed,variance,colors)
    possible = []
    for i,j in combinations(range(len(bank)),2):
        a,b = (np.asarray(bank[k]["frequency_xy"])for k in (i,j))
        if abs(a[0]*b[1]-a[1]*b[0])<.35*np.linalg.norm(a)*np.linalg.norm(b):
            continue
        pair = np.array([(*a,0.),(*b,0.)])
        _,_,residual = fit(train,pair)
        possible.append((float(np.sum(train[2]*residual**2)),i,j,pair))
    if not possible:
        return {"fallback-planar":[],"fallback-curved":[],"tested_pairs":0,"adopted_curvature":False}
    proposals = []
    for _,i,j,pair in sorted(possible,key=lambda p:p[:3])[:4]:
        plane = refine(train,pair,(0,1),False)
        curved = refine(train,plane,(0,1),True)
        _,_,p1 = fit(train,plane)
        _,_,p2 = fit(train,curved)
        proposals.append((float(np.sum(train[2]*p1**2)),float(np.sum(train[2]*p2**2)),i,j,plane,curved))
    top = min(proposals,key=lambda q:(q[0],q[2],q[3]))
    best = min(proposals,key=lambda q:(q[1],q[2],q[3]))
    flat_support = directional_support(train,test,top[4])
    curved_support = directional_support(train,test,best[5])
    against = standardized(test,prediction(train,test,best[4]),prediction(train,test,best[5]))
    plain = top[4].tolist()if min(flat_support)>=2.75 else []
    accepted = min(curved_support)>=2.75 and against>=2
    return {"fallback-planar":plain,"fallback-curved":best[5].tolist()if accepted else plain,
            "tested_pairs":len(proposals),"adopted_curvature":accepted,"gain_against_own_plane":against,
            "planar_support":flat_support,"curved_support":curved_support}


def research(job):
    receipt,source = job
    with np.load(checked(source["capture"]),allow_pickle=False)as f:
        arrays = {k:f[k]for k in ("packed","variance","colors")}
    rows = []
    for trial in receipt["trials"]:
        rep = trial["repeat"]
        role = ("present","outside-only","strong-only","quiet-query").index(trial["role"])
        raw = {k:v[rep,role:role+1]for k,v in arrays.items()}
        base = trial["methods"]
        selected = (
            {"fallback-planar":base["recentered"],"fallback-curved":base["curved"],"tested_pairs":0,
             "adopted_curvature":False}
            if base["planar"] else select(*cut(raw,128,128))
        )
        rows.append({"repeat":rep,"role":trial["role"],"activated_when_consensus_missing":not bool(base["planar"]),
                     "methods":selected})
    return {"index":receipt["index"],"rows":rows}


def record_synthetic(mode):
    seeds = reference(ROOT/f"selections-{mode}.json")
    selection = read_json(checked(seeds))
    shots = read_json(checked(selection["observations"]))
    pieces = [(row,shots["rows"][row["index"]])for row in selection["rows"]]
    with ThreadPoolExecutor(3)as pool:
        decisions = list(pool.map(research,pieces))
    write_json(ROOT/f"fallback-{mode}.json",{"selector":reference(__file__),"seeds":seeds,"decisions":decisions})


def record_cameras():
    seeds = reference(ROOT/"selections-standing.json")
    records = read_json(checked(seeds))
    rows = []
    for info in records["rows"]:
        x,y,_,_ = info["native_box"]
        with np.load(checked(info["input"]),allow_pickle=False)as f:
            arguments = {k:f[k]for k in ("packed","variance","colors")}
        base = info["methods"]
        shape = {"fallback-planar":base["recentered"],"fallback-curved":base["curved"],"tested_pairs":0,
                 "adopted_curvature":False}if base["planar"]else select(*cut(arguments,x,y))
        rows.append({"id":info["id"],"activated_when_consensus_missing":not bool(base["planar"]),"methods":shape})
        print(info["id"],shape,flush=True)
    write_json(ROOT/"fallback-standing.json",{"selector":reference(__file__),"seeds":seeds,"decisions":rows})


if __name__=="__main__":
    record_cameras()
    for mode in ("fit","fresh"):
        record_synthetic(mode)
