"""Deliver gated geometry changes above unchanged query predictions."""
from collections import defaultdict
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from curvature import ROOT,OLD,METHODS,deliver
from run_restore import ARGS,observations,setup_models


def grouped(args,parent,proposals):
    bins = defaultdict(list)
    output = torch.zeros_like(parent)
    for n,pair in enumerate(proposals):
        if len(pair)==2:
            bins[tuple(tuple(a)for a in pair)].append(n)
    for geometry,indices in bins.items():
        output[indices] = deliver([a[indices]for a in args],parent[indices],geometry)
    return output


@torch.inference_mode()
def run(mode):
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1.,6*2**30/torch.cuda.get_device_properties(0).total_memory))
    selected = reference(ROOT/f"selections-{mode}.json")
    all_choices = read_json(checked(selected))
    checked(all_choices["method"])
    fields = read_json(checked(all_choices["observations"]))
    plan = read_json(checked(fields["plan"]))
    previous = reference(OLD/"predictions-fit.json")if mode=="fit"else None
    retained = read_json(checked(previous))if previous else None
    if retained:
        assert retained["checkpoint"]==plan["base"]
    out = ROOT/f"predictions-{mode}"
    out.mkdir(exist_ok=True)
    dev = torch.device("cuda")
    ran = []
    t0 = time.monotonic()
    with ieee_fp32():
        model = None
        if mode=="fresh":
            model = setup_models({"models":{"Corpus 100k":plan["base"]}})["Corpus 100k"]
            model.set_noise(plan["profile"]["shot"],plan["profile"]["read"])
        for subset in all_choices["rows"]:
            index = subset["index"]
            current = fields["rows"][index]
            assert current["index"]==index and current["capture"]==subset["input"]
            path = out/f"{index:03d}.npz"
            if not path.exists():
                target = observations(current)
                args = [torch.from_numpy(target[n].reshape((-1,*target[n].shape[2:]))).to(dev)for n in ARGS]
                args[:2] = [a.contiguous(memory_format=torch.channels_last)for a in args[:2]]
                if retained:
                    with np.load(checked(retained["rows"][index]["output"]),allow_pickle=False)as f:
                        baseline = torch.from_numpy(f["baseline"].reshape(8,3,256,256)).to(dev)
                else:
                    baseline = model(*args)
                geometry = plan["sources"][index]["layout"]
                decoded = {"baseline":baseline}
                cache = {}
                for label in METHODS:
                    if label.startswith("exact"):
                        givens = tuple((*geometry[k+"_frequency_xy"],
                            geometry.get(k+"_tangential_curvature_cycles_per_px2",0.)if label=="exact-curved"else 0.)
                            for k in ("strong","weak"))
                        bank = [givens]*8
                    else:
                        bank = [v["methods"][label]for v in subset["trials"]]
                    key = tuple(tuple(tuple(p)for p in pair)for pair in bank)
                    if key not in cache:
                        cache[key] = grouped(args,baseline,bank)
                    decoded[label] = cache[key]
                arrays = {k:v.cpu().numpy().reshape(2,4,3,256,256)for k,v in decoded.items()}
                partial = path.with_suffix(".incomplete")
                with partial.open("wb")as f:
                    np.savez(f,**arrays)
                partial.rename(path)
            ran.append({"index":index,"output":reference(path)})
            print(mode,len(ran),round(time.monotonic()-t0,2),flush=True)
    write_json(ROOT/f"predictions-{mode}.json",{"driver":reference(__file__),"selection":selected,"checkpoint":plan["base"],
              "inherited_parent":previous,"rows":ran,"seconds":time.monotonic()-t0})


if __name__=="__main__":
    run(sys.argv[1])
