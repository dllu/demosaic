"""Verify backup camera parity and measure absolute error in exact gap cores."""
from pathlib import Path
import importlib.util

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from curvature import ROOT,anchored,local,deliver
from fallback import select
from run_restore import ARGS,observations
from score_panel import luma

EXTRA = ("fallback-planar","fallback-curved")
ARMS = ("baseline","planar","recentered","curved",*EXTRA)
CORE = np.s_[...,64:192,64:192]


@torch.inference_mode()
def cameras():
    old_ref = reference(ROOT/"standing/manifest.json")
    frozen = read_json(checked(old_ref))
    raw_ref = reference(ROOT/"fallback-standing.json")
    lookup = {r["id"]:r for r in read_json(checked(raw_ref))["decisions"]}
    proof = []
    with ieee_fp32():
        for a in frozen["rows"]:
            supported = lookup[a["id"]]["methods"]
            left,top,_,_ = a["fit_box"]
            view = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            with np.load(checked(a["noisy_source"]),allow_pickle=False)as f:
                args = [torch.from_numpy(f[k][view].copy()if k in ARGS[:2]else f[k])for k in ARGS]
            with np.load(checked(a["linear_output"]),allow_pickle=False)as f:
                parent = torch.from_numpy(f["parent"].copy())
                outcome = {}
                for method,compare in zip(EXTRA,("recentered","curved"),strict=True):
                    shape = supported[method]
                    assert shape==a["phase_evidence"][compare]
                    restored = (parent+frozen["render_scale"]*deliver(args,parent,shape)).numpy()
                    np.testing.assert_array_equal(restored,f[compare])
                    outcome[method] = compare
            proof.append({"id":a["id"],"prior_output":a["linear_output"],"exact_output_matches":outcome})
    return {"earlier_boards":old_ref,"decisions":raw_ref,"checked_native_cameras":proof}


def samples():
    binding = reference(ROOT/"fallback-scores.json")
    score = read_json(checked(binding))
    forecast = read_json(checked(score["fresh"]))
    nominated = read_json(checked(forecast["fallback_selection"]))
    seeds = read_json(checked(nominated["seeds"]))
    photos = read_json(checked(seeds["observations"]))
    plan = read_json(checked(photos["plan"]))
    rows = []
    held_check = []
    rng = np.random.default_rng(85015)
    with anchored((0,0)):
        hold = local.partition()>=2
        for source,predicted,case,selection in zip(plan["sources"],forecast["rows"],photos["rows"],nominated["decisions"],strict=True):
            i = source["index"]
            assert i==predicted["index"]==case["index"]==selection["index"]
            material = observations(case)
            mask = material["region"][CORE]==0
            with np.load(checked(predicted["output"]),allow_pickle=False)as f:
                base = luma(f["baseline"],material)
                target = luma(material["target"],material)
                row = {}
                for method in ARMS:
                    output = base+(0 if method=="baseline"else score["scales"][method]*luma(f[method],material))
                    gap = (output[:,0]-target[:,0])[:,mask]
                    increment = (output[:,0]-output[:,1])[:,mask]
                    row[method] = {"absolute_gap_DN16":float(np.sqrt(np.mean(gap**2,axis=1)).mean()*65535),
                                   "paired_gap_DN16":float(np.sqrt(np.mean(increment**2,axis=1)).mean()*65535)}
            if len(held_check)<4:
                for j,r in enumerate(selection["rows"]):
                    if r["role"]!="present" or not r["methods"]["adopted_curvature"]:
                        continue
                    rep = j//4
                    p,v,c = (material[n][rep,0].copy()for n in ARGS[:3])
                    found = select(p,v,c)
                    assert found==r["methods"]
                    for w in (p,v):
                        w[:,hold] = rng.uniform(.02,.95,(4,int(hold.sum()))).astype(np.float32)
                    assert select(p,v,c)==found
                    held_check.append({"index":i,"repeat":rep,"reserved_geometry_predictions_unchanged":True})
                    break
            rows.append({"index":i,"curvature":source["layout"]["weak_tangential_curvature_cycles_per_px2"],
                         "metrics":row})
    assert len(held_check)>=3
    bent = [r["metrics"]for r in rows if r["curvature"]]
    result = {}
    draws = rng.integers(len(bent),size=(10000,len(bent)))
    for key in ("absolute_gap_DN16","paired_gap_DN16"):
        series = {method:np.array([r[method][key]for r in bent])for method in ARMS}
        d = series["fallback-curved"]-series["curved"]
        result[key] = {"means":{k:float(v.mean())for k,v in series.items()},
                       "fallback_curved_minus_curved_and_95pct":[float(d.mean()),*np.quantile(d[draws].mean(-1),(.025,.975)).tolist()]}
    return {"score":binding,"rows":rows,"bent_total_gap_errors":result,"sample_replacement_audit":held_check}


if __name__=="__main__":
    torch.set_num_threads(2)
    write_json(ROOT/"fallback-audit.json",{"driver":reference(__file__),"cameras":cameras(),"exact":samples()})
