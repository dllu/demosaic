"""Render nominal and transferred standing crops with identical delivery scales."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.reporting import display_crop
from curvature import ROOT,OLD,anchored,local,fit,prediction,standardized,deliver
from run_restore import ARGS

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png

METHODS = {"planar":"Consensus planar","recentered":"Refined center","curved":"Checked curvature"}


def select_fold(args,fold):
    partition = local.partition()
    yy,xx = np.indices(partition.shape)
    mask = partition==fold
    pieces = []
    for index,signal,noise in local.green_records(*[v[0].numpy()for v in args[:3]]):
        x,y = 2*xx[mask]+index%2-127.5,2*yy[mask]+index//2-127.5
        w = np.exp(-.5*(x*x+y*y)/78**2)/noise[mask]
        pieces.append((x,y,w,signal[mask]))
    return tuple(np.concatenate(p)for p in zip(*pieces,strict=True))


def audit_prediction(args,templates):
    if not templates["planar"]:
        return None
    with anchored((0,0)):
        train = select_fold(args,0)
        result = {}
        for sample in (1,2,3):
            test = select_fold(args,sample)
            values = {k:prediction(train,test,templates[k])for k in METHODS}
            result[str(sample)] = {
                "recentered_vs_planar":standardized(test,values["planar"],values["recentered"]),
                "curved_vs_recentered":standardized(test,values["recentered"],values["curved"])}
    return result


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    new = reference(ROOT/"selections-standing.json")
    candidates = read_json(checked(new))
    saw = reference(OLD/"standing/manifest.json")
    before = read_json(checked(saw))
    selection = {r["id"]:r for r in candidates["rows"]}
    scores = reference(ROOT/"scores.json")
    scale = read_json(checked(scores))["scales"]["planar"]
    output = ROOT/"standing"
    output.mkdir(exist_ok=True)
    rows = []
    with ieee_fp32():
        for old in before["rows"]:
            key = old["id"]
            a = selection[key]
            ref = a["input"]
            assert ref==old["raw"]
            left,top,_,_ = a["native_box"]
            data = np.s_[...,top//2:top//2+128,left//2:left//2+128]
            with np.load(checked(ref),allow_pickle=False)as station:
                args = [torch.from_numpy(station[k][data].copy()if k in ARGS[:2]else station[k])for k in ARGS]
            wb,matrix = args[-2:]
            x,y,w,h = old["case"]["ROI_xywh"]
            roi = (x-left,y-top,w,h)
            parent = torch.from_numpy(np.load(checked(old["parent_pixels"]),allow_pickle=False)[...,top:top+256,left:left+256].copy())
            with Image.open(checked(old["image"]))as f:
                pixels = np.asarray(f.convert("RGB"))
            inherited = {p["name"]:pixels[b:b+d,c:c+e]for p in old["panels"]for c,b,e,d in (p["png_xywh"],)}
            base = display_crop(parent,wb,matrix,roi,exposure=old["exposure"])
            display_base = np.rint(base*255).astype(np.uint8)
            np.testing.assert_array_equal(display_base,inherited["Parent 100k EMA"])
            panels = [(k,inherited[k])for k in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","Single query")
                      if k in inherited]
            camera_linear = {"parent":parent.numpy()}
            change = {}
            local_roi = np.s_[...,roi[1]:roi[1]+h,roi[0]:roi[0]+w]
            for name,label in METHODS.items():
                forecast = parent+scale*deliver(args,parent,a["methods"][name])
                camera_linear[name] = forecast.numpy()
                shown = display_crop(forecast,wb,matrix,roi,exposure=old["exposure"])
                panels.append((label,np.rint(shown*255).astype(np.uint8)))
                add = (forecast-parent)[local_roi].numpy().astype(float)
                change[name] = float(65535*np.sqrt(np.mean(add**2)))
            if a["methods"]["curved"]==a["methods"]["recentered"]:
                np.testing.assert_array_equal(camera_linear["curved"],camera_linear["recentered"])
            panels += [(k,inherited[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in inherited]
            binding = native_png(output/(key+".png"),panels)
            path = output/(key+".npz")
            with path.open("wb")as f:
                np.savez(f,**camera_linear)
            independently = audit_prediction(args,a["methods"])
            rows.append(binding|{"id":key,"ROI":old["case"],"fit_box":a["native_box"],"linear_output":reference(path),
                                 "noisy_source":ref,"parent":old["parent_pixels"],"inherited_board":old["image"],
                                 "noise":old["noise"],"display_exposure":old["exposure"],"references":old["reference_role"],
                                 "added_RGB_DN16_RMS":change,"phase_evidence":a["methods"],
                                 "fixed_prediction_changes_by_fold":independently})
            print(key,change,independently,flush=True)
    assert len(rows)==8
    write_json(output/"manifest.json",{"driver":reference(__file__),"nominees":new,"resolved":scores,
      "reference":saw,"render_scale":scale,"checkpoint":before["checkpoint"],"rows":rows,
      "scope":"All new camera columns hold delivery amplitude scale fixed at the synthetic planar value. Fold 0 coefficients supply the fixed plane or quadratic prediction. Folds 2 and 3 are excluded from geometry selection."})


if __name__=="__main__":
    run()
