"""Reuse each distinct Fourier coordinate and gather only the selected CFA coefficients."""
from dataclasses import dataclass
from pathlib import Path
import sys

import numpy as np
from scipy.fft import fft2, rfft2

ROOT = Path(__file__).resolve().parent
BASELINE = ROOT.parent / "subbin-spectral-witness-v1"
sys.path.insert(0, str(BASELINE))
from phase import (ALLOWED, BAYER_OFFSETS, BINS, FREQ, MEAN_RESPONSE, NATIVE, PACKED,
                   PAD, PENALTY, SIDE, STEP, WINDOW, XI, YI, Measurements, neighborhood, squares, unit)

WEIGHT = WINDOW.astype(np.float32)
NORM = WEIGHT.sum()
VARIANCE_SCALE = (WEIGHT**2).mean()
UNIQUE, MAP = np.unique(BINS.reshape(-1, 2), axis=0, return_inverse=True)
INDEX = MAP.reshape(ALLOWED.shape)
BASE = INDEX[:, 0]
GRID = np.exp(2j * np.pi * NATIVE * UNIQUE * STEP).astype(np.complex64)
SHIFT = np.exp(-2j * np.pi * np.einsum("ck,fk->cf", BAYER_OFFSETS, UNIQUE * STEP)).astype(np.complex64)
MIRROR = UNIQUE[:, 1] < 0
DIMS = {
    "complex": (UNIQUE[:, 0] % PAD) * PAD + (UNIQUE[:, 1] % PAD),
    "real": ((UNIQUE[:, 0] * np.where(MIRROR, -1, 1)) % PAD) * (PAD // 2 + 1)
    + abs(UNIQUE[:, 1]),
}
CHOICES = ("complex", "real")


@dataclass(frozen=True)
class Spectrum:
    fft: np.ndarray
    coordinates: np.ndarray
    mirrored: bool
    variance: np.ndarray


def spectrum(raw, layout, noise, mode):
    pixels = squares(raw, YI, XI).astype(np.float32)
    average = (pixels * WEIGHT).sum(axis=(-1, -2)) / NORM
    tapered = (pixels - average[..., None, None]) * WEIGHT
    if mode == "real":
        transform = rfft2(tapered, s=(PAD, PAD), workers=1)
    elif mode == "complex":
        transform = fft2(tapered, s=(PAD, PAD), workers=1)
    else:
        raise ValueError(f"Unexpected Fourier policy: {mode}")
    transform /= PACKED
    variance = (noise["shot"] * average.clip(min=0) + noise["read"]).clip(min=2e-11)
    variance *= VARIANCE_SCALE
    return Spectrum(transform.reshape(len(XI), 4, -1), DIMS[mode], mode == "real", variance)


def gather(bank, plane, frequency=None):
    values = bank.fft[:, plane]
    if frequency is None:
        sampled = values[:, bank.coordinates]
        if bank.mirrored:
            sampled[:, MIRROR] = sampled[:, MIRROR].conj()
        return sampled * SHIFT[plane]
    sampled = np.take_along_axis(values, bank.coordinates[frequency], axis=-1)
    if bank.mirrored:
        reflected = MIRROR[frequency]
        sampled[reflected] = sampled[reflected].conj()
    return sampled * SHIFT[plane, frequency]


def neighboring_pair(values, variance, axis):
    grid = values.reshape(SIDE, SIDE, -1).swapaxes(0, axis)
    sigma = variance.reshape(SIDE, SIDE).swapaxes(0, axis)
    total = np.zeros((SIDE, SIDE, grid.shape[-1]), dtype=values.dtype).swapaxes(0, axis)
    combined = np.zeros((SIDE, SIDE), dtype=variance.dtype).swapaxes(0, axis)
    phase = GRID[:, axis]
    total[2:] += grid[:-2] * phase
    total[:-2] += grid[2:] * phase.conj()
    combined[2:] += sigma[:-2]
    combined[:-2] += sigma[2:]
    return total.swapaxes(0, axis).reshape(values.shape), combined.swapaxes(0, axis).ravel()


def choose_by_power(values, variance, refine):
    selection = INDEX if refine else INDEX[:, :1]
    # The penalties are float64 in the source policy.
    power = abs(values)**2 / variance[:, None].clip(min=4e-10)
    options = selection.shape[-1]
    where = np.where(ALLOWED[None, :, :options],
                     power[:, selection] - PENALTY[..., :options], -np.inf).argmax(axis=-1)
    chosen = INDEX[np.arange(len(BASE))[None], where]
    return where, chosen


def consistency(vertical, horizontal, vv, hv, selected, refine):
    """Nominate with each pair separately and evaluate the other pair."""
    _, vertical_best = choose_by_power(vertical, vv, refine)
    _, horizontal_best = choose_by_power(horizontal, hv, refine)
    v_donor = np.take_along_axis(vertical, vertical_best, axis=-1)
    h_donor = np.take_along_axis(horizontal, horizontal_best, axis=-1)
    v_target = np.take_along_axis(vertical, horizontal_best, axis=-1)
    h_target = np.take_along_axis(horizontal, vertical_best, axis=-1)
    v_sigma = np.sqrt(vv[:, None]).clip(min=2e-5)
    h_sigma = np.sqrt(hv[:, None]).clip(min=2e-5)
    v_support = (v_target * unit(h_donor).conj()).real / v_sigma
    h_support = (h_target * unit(v_donor).conj()).real / h_sigma
    v_field = np.take_along_axis(vertical, selected, axis=-1)
    h_field = np.take_along_axis(horizontal, selected, axis=-1)
    match = (unit(v_field) * unit(h_field).conj()).real
    tune = (UNIQUE[vertical_best] - UNIQUE[horizontal_best]) / 4
    features = np.stack((
        np.arcsinh(v_support), np.arcsinh(h_support),
        np.log1p(abs(v_field) / v_sigma), np.log1p(abs(h_field) / h_sigma),
        match, tune[..., 0], tune[..., 1],
        np.arcsinh(abs(v_field - h_field) / np.hypot(v_sigma, h_sigma)),
    ), axis=-1)
    return np.ascontiguousarray(features.clip(-6, 6), dtype=np.float32)


def measured(raw, layout, noise, *, refine=True, mode="real", pair_features=False):
    bank = spectrum(raw, layout, noise, mode)
    green = np.flatnonzero(layout == 1)
    red, blue = (np.flatnonzero(layout == shade)[0] for shade in (0, 2))
    g0, g1 = (gather(bank, plane) for plane in green)
    direct = (g0 + g1) * .5
    green_variance = bank.variance[:, green].sum(1) * .25
    source, exterior_var = neighborhood(direct, green_variance, GRID)
    offsets, selected = choose_by_power(source, exterior_var, refine)
    external = np.take_along_axis(source, selected, axis=-1)
    external_phase = unit(external)
    direct_phase = unit(direct[:, BASE])
    refined_unit = unit(np.take_along_axis(direct, selected, axis=-1))
    per_site = np.sqrt(bank.variance)
    base = np.broadcast_to(BASE, selected.shape)
    local_color = np.stack([
        ((gather(bank, p, base) / per_site[:, p, None]) * direct_phase.conj()).real
        for p in (red, blue)
    ], axis=-1)
    exterior_color = np.stack([
        ((gather(bank, p, selected) / per_site[:, p, None]) * external_phase.conj()).real
        for p in (red, blue)
    ], axis=-1)
    exterior_green = np.stack([
        ((np.take_along_axis(g, selected, axis=-1) / per_site[:, p, None]) * external_phase.conj()).real
        for p, g in zip(green, (g0, g1), strict=True)
    ], axis=-1)
    strength = abs(external) / np.sqrt(exterior_var[:, None]).clip(min=2e-5)
    agreement = (refined_unit * external_phase.conj()).real
    features = np.concatenate((np.arcsinh(local_color), np.arcsinh(exterior_color),
                              np.arcsinh(exterior_green), np.log1p(strength)[..., None],
                              agreement[..., None]), axis=-1).clip(-6, 6).astype(np.float32)
    carrier = unit(external_phase * MEAN_RESPONSE[offsets])
    amplitude = (np.take_along_axis(direct, selected, axis=-1) * external_phase.conj()).real
    amplitude = amplitude.clip(min=0) * abs(MEAN_RESPONSE[offsets])
    evidence = (exterior_color.mean(-1) - .4).clip(min=0)
    confidence = np.sqrt(evidence / (1 + evidence))
    local_noise = np.sqrt(bank.variance[:, green].mean(1))[:, None]
    found = Measurements(features, FREQ[np.arange(len(BASE))[None], offsets], external_phase,
                         strength, offsets, carrier, amplitude, confidence, local_noise)
    if pair_features:
        vertical, vv = neighboring_pair(direct, green_variance, 0)
        horizontal, hv = neighboring_pair(direct, green_variance, 1)
        return found, consistency(vertical, horizontal, vv, hv, selected, refine)
    return found
