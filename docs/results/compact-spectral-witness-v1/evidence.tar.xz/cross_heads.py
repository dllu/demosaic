"""Heads with independent evidence from vertical and horizontal donor pairs."""
import torch
from torch import nn

from phase_indexed import BASELINE, ROOT
from models import TransportHead
from witness_features import WitnessHead

TREATMENTS = ("paired-refined", "paired-gap", "paired-transport")


def extend_inputs(owner):
    start = owner.layers[0]
    added = nn.Linear(start.in_features + 8, start.out_features)
    with torch.no_grad():
        added.weight.zero_()
        added.weight[:, :start.in_features].copy_(start.weight)
        added.bias.copy_(start.bias)
    owner.layers[0] = added


def predict(owner, features, context, basis):
    standard, witnesses = torch.split(features, (17, 16), dim=-1)
    inputs = torch.cat((standard, context[..., None], witnesses), dim=-1)
    coeff = owner.layers(inputs).tanh() * owner.cap
    return (basis * coeff[..., None]).sum(dim=-2)


class CrossHead(WitnessHead):
    def __init__(self):
        super().__init__()
        extend_inputs(self)

    def forward(self, features, contexts, basis):
        return predict(self, features, contexts, basis)


class CrossTransportHead(TransportHead):
    def __init__(self):
        super().__init__()
        extend_inputs(self)

    def forward(self, features, contexts, basis):
        return predict(self, features, contexts, basis)
