"""Check that pair evidence never reads the center or reciprocal donor during nomination."""
import numpy as np

from phase_indexed import INDEX, DIMS, BASE, SIDE, neighboring_pair, choose_by_power, consistency

rng = np.random.default_rng(961)
reference = (rng.normal(size=(SIDE**2,len(DIMS["real"]))) + 1j * rng.normal(size=(SIDE**2,len(DIMS["real"])))).astype(np.complex64)
variance = rng.uniform(.01,.02,SIDE**2).astype(np.float32)
k = 7
center = SIDE*k+k


def calc(values):
    vertical, vv = neighboring_pair(values, variance, 0)
    horizontal, hv = neighboring_pair(values, variance, 1)
    chosen = choose_by_power(vertical + horizontal, vv + hv, True)[1]
    hold = consistency(vertical, horizontal, vv, hv, chosen, True)
    return hold, vertical, vv, horizontal, hv


base, v, vv, h, hv = calc(reference)
changed = reference.copy()
changed[center] += 10
new, *_ = calc(changed)
np.testing.assert_array_equal(base[center], new[center])
not_horizontal = reference.copy()
not_horizontal[[center-2,center+2]] += 13.0 + 27.0j
new_pair, v_changed, var, _, _ = calc(not_horizontal)
np.testing.assert_array_equal(v[center],v_changed[center])
np.testing.assert_array_equal(choose_by_power(v, vv, True)[0][center],
                              choose_by_power(v_changed, var, True)[0][center])
assert np.max(abs(new_pair[center]-base[center]))>.01
print("Center exclusion and vertical nomination isolation verified.")
