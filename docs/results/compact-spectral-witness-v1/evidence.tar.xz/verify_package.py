"""Check the reusable extractor against the timed implementation at all retained sites."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.phase_witness import measure_witnesses
from phase_compact import ROOT, measured
import evaluate_gap_head as base

FIELDS = ("features", "frequency", "phase", "exterior_z", "offsets",
          "carrier", "amplitude", "confidence", "noise")


def check(raw, layout, noise):
    old, extra = measured(raw, layout, noise, pair_features=True)
    actual = measure_witnesses(raw, layout, noise, pair_features=True)
    for name in FIELDS:
        np.testing.assert_array_equal(getattr(actual, name), getattr(old, name))
    np.testing.assert_array_equal(actual.pair_features, extra)


def wire(item, plan):
    with np.load(checked(item["input"]), allow_pickle=False) as arrays:
        for raw, cfa in zip(arrays["packed"][..., 64:192, 64:192], arrays["colors"], strict=True):
            check(raw, cfa, plan["profiles"][item["noise"]])
    return 4


def natural(pointer):
    row, args, _ = base.old.natural_values(pointer)
    for raw, cfa in zip(args["packed"], args["colors"], strict=True):
        check(raw, cfa, row["profile"])
    return 3


def main():
    graphs = reference(ROOT / "extraction-replay-final.json")
    previous = read_json(checked(graphs))
    wire_bank = read_json(checked(previous["wire_cases"]))["rows"]
    wire_plan = read_json(checked(previous["wire_plan"]))
    photos = read_json(checked(previous["natural_cases"]))["records"]
    chosen = [p for p in photos if int(Path(p["path"]).stem.split("-")[0]) % 4 == 0]
    with ThreadPoolExecutor(3) as workers:
        n_wire = sum(workers.map(lambda x: wire(x, wire_plan), wire_bank))
        n_photos = sum(workers.map(natural, chosen))
    boards = read_json(checked(previous["gfx_compact"]))
    geometry = {x["id"]: x["box"] for x in read_json(
        ROOT.parent/"query-exterior-colour-v1/standing/manifest.json")["rows"]}
    for row in boards["rows"]:
        x, y, w, h = geometry[row["id"]]
        assert w == h == 256
        with np.load(checked(row["input"]), allow_pickle=False) as data:
            check(data["packed"][0,:,y//2:y//2+128,x//2:x//2+128],data["colors"][0],row["noise"])
    write_json(ROOT/"package-replay.json",{
        "driver":reference(__file__),"package":reference("src/demosaic/phase_witness.py"),
        "reference":reference(ROOT/"phase_compact.py"),"panel_replay":graphs,"wire_queries":n_wire,
        "natural_queries":n_photos,"GFX_queries":len(boards["rows"]),
        "arrays_equal":list(FIELDS)+["pair_features"]})
    print(n_wire, n_photos, len(boards["rows"]), "package replay identical", flush=True)


if __name__=="__main__":
    main()
