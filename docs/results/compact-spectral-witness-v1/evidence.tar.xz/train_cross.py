"""Train donor-pair evidence on the same examples, proposals and optimizer schedule."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_indexed import ROOT, BASELINE, measured
from phase import PARENT
from cross_heads import CrossHead, CrossTransportHead, TREATMENTS
from train_gap_head import INPUTS, SEED, EPOCHS, PHOTOS, EXACT_FLAT, NATIVE_I, NATIVE_J, SYNTH
from train_gap_head import batch, choose_tiles, focal_energy, objective


def features_one(entry):
    row, pointer = entry
    real = read_json(checked(pointer))
    assert row["index"] == real["index"]
    with np.load(checked(real["input"]), allow_pickle=False) as bank:
        values = [measured(raw, cfa, row["noise"], pair_features=True)[1]
                  for raw, cfa in zip(bank["packed"], bank["colors"], strict=True)]
    return np.stack(values)


def collect():
    history = reference(PARENT / "observations.json")
    seen = read_json(checked(history))
    cases = read_json(checked(seen["plan"]))["batches"]
    start = time.monotonic()
    notes = None
    output = ROOT / "pair-features.npy"
    with ThreadPoolExecutor(3) as pool:
        for i, value in enumerate(pool.map(features_one, zip(cases, seen["rows"], strict=True))):
            assert np.isfinite(value).all()
            if notes is None:
                notes = np.lib.format.open_memmap(
                    output, mode="w+", dtype=np.float16, shape=(len(cases), *value.shape))
            notes[i] = value
            if (i + 1) % 50 == 0:
                print(i + 1, round(time.monotonic() - start, 2), flush=True)
    notes.flush()
    write_json(ROOT / "pair-features.json", {"driver": reference(__file__), "observations": history,
               "implementation":reference(ROOT / "phase_indexed.py"), "tensor":reference(output),
               "shape": list(notes.shape), "collection_seconds":time.monotonic() - start})


def train():
    torch.set_num_threads(2)
    device = "cuda"
    memory = torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1., 5 * 2**30 / memory))
    previous = reference(BASELINE / "training/completed.json")
    inherited = read_json(checked(previous))
    frozen = read_json(checked(inherited["standard_cache"]))
    subbins = read_json(checked(inherited["witness_cache"]))
    cross = reference(ROOT / "pair-features.json")
    pair = read_json(checked(cross))
    assert pair["observations"] == subbins["observations"]
    buffers = {k: frozen["inputs"][k] for k in INPUTS} | subbins["tensors"] | {"pairs":pair["tensor"]}
    data = {k:np.load(checked(ref), allow_pickle=False, mmap_mode="r") for k,ref in buffers.items()}
    rows = frozen["counts"]["photos"]
    torch.manual_seed(SEED)
    first = CrossHead().to(device)
    torch.manual_seed(SEED)
    transporter = CrossTransportHead().to(device)
    models = {"paired-refined":first, "paired-gap":deepcopy(first), "paired-transport":transporter}
    ema = {k:deepcopy(m).requires_grad_(False) for k,m in models.items()}
    optim = torch.optim.AdamW([p for m in models.values() for p in m.parameters()],
                             lr=.001, weight_decay=.001)
    coordinates = tuple(torch.as_tensor(p,device=device) for p in (NATIVE_I,NATIVE_J))
    taper = torch.as_tensor(SYNTH**2,device=device,dtype=torch.float32)
    rng = np.random.default_rng(SEED)
    output = ROOT / "training"
    output.mkdir()
    total_steps = rows // PHOTOS * EPOCHS
    started = time.monotonic()
    step = 0
    history = []
    for epoch in range(EPOCHS):
        permutation = rng.permutation(rows)
        for off in range(0,rows,PHOTOS):
            subset = permutation[off:off+PHOTOS]
            selected = choose_tiles(rng,data["void_weight"],subset)
            arrays = batch(data,subset,selected,device)
            flat = torch.as_tensor(EXACT_FLAT[selected],device=device)
            weight = arrays["void"] * taper
            inputs = torch.cat((arrays["features"],arrays["witness"],arrays["pairs"]),dim=-1)
            step += 1
            rate = .001 * step/24 if step <= 24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(total_steps-24)))
            optim.param_groups[0]["lr"] = float(rate)
            optim.zero_grad(set_to_none=True)
            metrics = {}
            for name, net in models.items():
                basis = arrays["basis"]
                if name == "paired-transport":
                    basis = torch.cat((basis,arrays["proposal"][...,None,:]),dim=-2)
                prediction = net(inputs,arrays["context"],basis)
                original, err, proj = objective(prediction,arrays["target"],arrays["basis"][...,0,:],flat)
                loss = original
                if name == "paired-gap":
                    loss = loss + 3*focal_energy(err[:,0]-err[:,1],weight,coordinates)
                    loss = loss + 1.5*focal_energy(err[:,0],weight,coordinates)
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(tuple(net.parameters()),2.)
                if not torch.isfinite(norm):
                    raise FloatingPointError(step)
                metrics[name] = torch.stack((loss,original,proj)).detach()
            optim.step()
            with torch.no_grad():
                for name,net in models.items():
                    torch._foreach_lerp_(tuple(ema[name].parameters()),tuple(net.parameters()),.01)
            if step in (1,total_steps) or step % 48 == 0:
                scores = {k:v.cpu().tolist() for k,v in metrics.items()}
                history.append({"step":step,"losses":scores})
                print(step,round(time.monotonic()-started,2),scores,flush=True)
    torch.cuda.synchronize()
    elapsed = time.monotonic()-started
    assert step == total_steps
    checkpoint = output / f"step{step:06d}.pt"
    with checkpoint.open("xb") as stream:
        torch.save({"raw":{k:n.state_dict()for k,n in models.items()},
                    "EMA":{k:n.state_dict()for k,n in ema.items()},"optimizer":optim.state_dict(),
                    "seed":SEED,"updates":step},stream)
    write_json(output / "completed.json", {
        "driver":reference(__file__), "parent":inherited["parent"],"compared_to":previous,
        "checkpoint":reference(checkpoint),"policies":TREATMENTS,
        "head_source":reference(ROOT/"cross_heads.py"),"pair_features":cross,
        "standard_cache":inherited["standard_cache"],"subbin_cache":inherited["witness_cache"],
        "seconds":elapsed,"photos":rows,"photo_visits_per_head":rows*EPOCHS,
        "native_queries_per_head":rows*EPOCHS*3,"updates_per_head":step,
        "losses":"Matched previous refined, refined-gap, and transport losses, respectively",
        "epochs":EPOCHS,"optimizer":inherited["optimizer"],"weights":"EMA .99 and raw","progress":history,
    })


if __name__ == "__main__":
    {"features":collect,"train":train}[sys.argv[1]]()
