"""Review exact and standing crops for the new Bayer evidence heads."""
import sys

from phase_compact import ROOT
from review_cross_final import CAPTIONS, load, predict
from native_gap_head import standing, exact

if __name__ == "__main__":
    if sys.argv[1] == "standing":
        standing(provider=load, predictor=predict, captions=CAPTIONS,
                 methods=("transport", "paired-refined", "paired-gap", "paired-transport"),
                 output_dir=ROOT/"standing-final")
    else:
        exact(provider=load, predictor=predict, captions=CAPTIONS, main_arm="paired-transport",
              extra_arms=("paired-refined","paired-gap"), output_dir=ROOT/"exact-final")
