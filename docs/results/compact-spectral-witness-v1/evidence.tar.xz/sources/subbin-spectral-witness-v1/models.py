"""Compare refined Bayer measurements with and without a transported waveform."""
import numpy as np
import torch
from torch import nn

from witness_features import WitnessHead


class TransportHead(WitnessHead):
    def __init__(self):
        super().__init__()
        original = self.layers[-1]
        output = nn.Linear(original.in_features, original.out_features + 1)
        with torch.no_grad():
            output.weight.zero_()
            output.bias.zero_()
        self.layers[-1] = output
        self.register_buffer("cap", torch.cat((self.cap, torch.tensor([.22]))))


def extend(basis, measurements, scale=1.0):
    """Express the candidate in the same signed native FFT coordinates."""
    addition = measurements.proposal(basis[..., 0], scale)
    return np.concatenate((basis, addition[..., None]), axis=-1).astype(np.complex64)
