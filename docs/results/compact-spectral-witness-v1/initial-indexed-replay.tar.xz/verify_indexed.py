"""Time and verify the same transported checkpoint with indexed Fourier extraction."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from functools import partial
from pathlib import Path
from time import perf_counter
import os
import sys

import numpy as np
import torch
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_indexed import BASELINE, ROOT, UNIQUE, measured
from phase import measured as original
from models import extend
import evaluate_gap_head as base
import review_subbin as prior

POLICIES = {"dense": original,
            "indexed-complex": partial(measured, mode="complex"),
            "indexed-real": measured,
            "indexed-real-with-pairs": partial(measured, pair_features=True)}
PRIOR_GFX = BASELINE / "standing" / "manifest.json"


def fourier_capsule(item, r, parents, settings, crop, transport):
    donors = base.exterior(r.get("full", r.get("scene_packed")), r["colors"][0], settings, crop)
    outcomes = {}
    for focus in range(len(parents)):
        raw, cfa, matrix, wb = (r[k][focus] for k in ("packed", "colors", "matrix", "wb"))
        field = base.features(raw, cfa, settings, crop, donors, parents[focus], wb, matrix)
        dense = original(raw, cfa, settings)
        compact = measured(raw, cfa, settings)
        rows = []
        for method, active in (("dense", dense), ("compact", compact)):
            options = replace(field, inputs=np.concatenate((field.inputs, active.features),axis=-1),
                              basis=extend(field.basis, active))
            rows.append(base.apply(transport,options,parents[focus],"shape"))
        delta = (rows[1].astype(np.float64) - rows[0]) * 65535
        export = [np.rint(img.clip(0,1)*65535).astype(np.uint16) for img in rows]
        code_delta = abs(export[0].astype(np.int32) - export[1])
        outcomes[str(focus)] = {"offset_changes": int(np.count_nonzero(dense.offsets != compact.offsets)),
             "offset_candidates": int(np.size(dense.offsets)),
             "feature_linf": float(abs(dense.features-compact.features).max()),
             "output_RMS_DN16": float(np.sqrt(np.mean(delta**2))),
             "output_linf_DN16": float(abs(delta).max()),
             "different_rounded_codes":int(np.count_nonzero(code_delta)),
             "max_rounded_code_difference":int(code_delta.max())}
    return {"input":item,"roles":outcomes}


def wire(task, plan, transport):
    r, parents = base.wire_inputs(task,None)
    return fourier_capsule(task["input"],r,parents["100k"],plan["profiles"][task["noise"]],
                           plan["query"],transport)


def natural(pointer, transport):
    record,args,parents = base.old.natural_values(pointer)
    return fourier_capsule(pointer,args,parents["100k"],record["profile"],record["box"],transport)


def field_for_gfx(row):
    board = read_json(checked(reference(ROOT / "standing/manifest.json")))
    new = next(entry for entry in board["rows"] if entry["id"] == row["id"])
    assert all(row[k] == new[k] for k in ("raw","input","box","ROI_xywh","noise","exposure"))
    with np.load(checked(row["predictions"]),allow_pickle=False) as original, np.load(
        checked(new["predictions"]),allow_pickle=False) as indexed:
        a,b=(img["transport"][0] for img in (original,indexed))
        diff=(a.astype(np.float64)-b)*65535

    def crop(board, label):
        chip = next(p["png_xywh"] for p in board["panels"] if p["name"]==label)
        with Image.open(checked(board["image"])) as img:
            x,y,w,h=chip
            return np.asarray(img.crop((x,y,x+w,y+h)).convert("RGB"))

    u = crop(row["board"],"Transported phase")
    v = crop(new["board"],"Sub-bin transport")
    return {"id":row["id"],"input":row["input"], "display_pixels_changed":int(np.any(u!=v,axis=-1).sum()),
            "output_linf_DN16":float(abs(diff).max()),
            "output_RMS_DN16":float(np.sqrt(np.mean(diff**2)))}


def verify():
    torch.set_num_threads(1)
    models, receipt, endpoint = prior.load()
    transport=models["transport"]
    directory = base.WIRE_TEST
    wire_plan, wire_cases = (reference(directory/x) for x in ("plan.json","fresh-gap.json"))
    natural_cases = reference(base.NATURAL / "evaluation/collected.json")
    plan=read_json(checked(wire_plan))
    with ThreadPoolExecutor(3) as workers:
        wire_results=list(workers.map(partial(wire,plan=plan,transport=transport),
                                      read_json(checked(wire_cases))["rows"]))
        subset=read_json(checked(natural_cases))["records"]
        # Sixteen photo sources across all four capture settings. Select
        # before comparisons by ID and retain their original model predictions.
        subset = [p for p in subset if int(Path(p["path"]).stem.split("-")[0]) % 4 == 0]
        assert len(subset)==64
        natural_results=list(workers.map(partial(natural,transport=transport),subset))
    gfx = [field_for_gfx(row) for row in read_json(checked(reference(PRIOR_GFX)))["rows"]]
    all_fields=[row for sample in wire_results + natural_results for row in sample["roles"].values()]
    commit = {"source":reference(ROOT/"phase_indexed.py"),"parent_trial":receipt,
              "parent_checkpoint":endpoint["checkpoint"],"driver":reference(__file__),
              "wire_plan":wire_plan,"wire_cases":wire_cases,"natural_cases":natural_cases,
              "gfx_baseline":reference(PRIOR_GFX),"gfx_compact":reference(ROOT/"standing/manifest.json"),
              "roles":len(all_fields),"offset_changes":sum(f["offset_changes"] for f in all_fields),
              "offset_candidates":sum(f["offset_candidates"] for f in all_fields),
              "max_feature_delta":max(f["feature_linf"] for f in all_fields),
              "max_output_code_delta":max(f["max_rounded_code_difference"] for f in all_fields),
              "changed_rounded_codes":sum(f["different_rounded_codes"] for f in all_fields),
              "max_output_linf_DN16":max(f["output_linf_DN16"] for f in all_fields),
              "unique_frequencies":len(UNIQUE),"wire_results":wire_results,"natural_results":natural_results,
              "gfx_results":gfx}
    write_json(ROOT/"extraction-replay.json",commit)
    print({k:v for k,v in commit.items() if not isinstance(v,(dict,list))},flush=True)


def timing():
    plan=read_json(base.WIRE_TEST/"plan.json")
    collection=reference(base.WIRE_TEST/"fresh-gap.json")
    wire_bank=read_json(checked(collection))["rows"]
    timing_fields=[]
    for profile, case in (("iso400",3),("iso6400",12),("iso6400",14)):
        selected=next(q for q in wire_bank if (q["noise"],q["index"])==(profile,case))
        with np.load(checked(selected["input"]),allow_pickle=False) as bank:
            args=(np.ascontiguousarray(bank["packed"][0,:,64:192,64:192]),bank["colors"][0],
                  plan["profiles"][profile])
        timing_fields.append((f"{case:03d}-{profile}",selected["input"],args))
    mesh_manifest=reference(PRIOR_GFX)
    row=next(r for r in read_json(checked(mesh_manifest))["rows"]
             if r["id"]=="mesh-profile3879-fine-green-mesh-right")
    with np.load(checked(row["input"]),allow_pickle=False) as bank:
        rw,rh,_,_=next(g["box"] for g in read_json(ROOT.parent/"query-exterior-colour-v1/standing/manifest.json")["rows"]
                          if g["id"]==row["id"])
        raw=bank["packed"][0,:,rh//2:rh//2+128,rw//2:rw//2+128]
        assert raw.shape==(4,128,128)
        timing_fields.append((row["id"],row["input"],
                             (np.ascontiguousarray(raw),bank["colors"][0],row["noise"])))
    outcomes=[]
    for name, input_mark, arrays in timing_fields:
        receipt={"id":name,"input":input_mark,"measurements":{mode:[] for mode in POLICIES}}
        for i in range(24):
            options=list(POLICIES.items())
            options=options[i%len(options):]+options[:i%len(options)]
            for method, action in options:
                started=perf_counter()
                action(*arrays)
                elapsed=perf_counter()-started
                if i>=4:
                    receipt["measurements"][method].append(elapsed)
        receipt["medians"]={key:float(np.median(times))for key,times in receipt["measurements"].items()}
        outcomes.append(receipt)
    write_json(ROOT/"timing.json",{"source":reference(ROOT/"phase_indexed.py"),"driver":reference(__file__),
        "CPU_affinity":sorted(os.sched_getaffinity(0)),"wire_collection":collection,
        "prior_standing":mesh_manifest,"rows":outcomes,"scope":"CPU Bayer feature stage on one 256px query, 20 interleaved post-warmup calls per policy."})


if __name__ == "__main__":
    {"verify":verify,"timing":timing}[sys.argv[1]]()
