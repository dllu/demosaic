"""Compare compact inference and split donor evidence on fixed held-out crops."""
from dataclasses import replace
from functools import partial
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from phase_indexed import BASELINE, ROOT, measured, SIDE
from cross_heads import CrossHead, CrossTransportHead, TREATMENTS
from witness_features import WitnessHead, measured as integer_witness
from models import TransportHead, extend
from derive_contrasts import contrast
import evaluate_gap_head as base
import review_subbin as previous

PARENTS = dict(zip(TREATMENTS, ("refined", "refined-gap", "transport"), strict=True))
CAPTIONS = {
    "prior": "Earlier spectral head",
    "transport": "Sub-bin transport",
    "paired-refined": "Donor pairs",
    "paired-gap": "Donor pairs + gap loss",
    "paired-transport": "Donor pairs + transport",
}
METRICS = ("intact_response", "intact_rms", "gap_added", "gap_exact",
           "gap_pair", "dip_response", "flat_added")


def load(*, ablations=False):
    frozen, prior, parent = previous.load()
    frozen = {k: v for k, v in frozen.items() if not k.endswith("-raw")}
    binding = reference(ROOT / "training/completed.json")
    trial = read_json(checked(binding))
    assert trial["compared_to"] == prior and trial["parent"] == parent["parent"]
    state = torch.load(checked(trial["checkpoint"]), weights_only=True, map_location="cpu")
    for weight in ("EMA", "raw"):
        for arm in TREATMENTS:
            net = CrossTransportHead() if arm == "paired-transport" else CrossHead()
            net.load_state_dict(state[weight][arm])
            frozen[arm if weight == "EMA" else arm + "-raw"] = net.eval().requires_grad_(False)
    if ablations:
        for arm in TREATMENTS:
            frozen[arm + "-rolled"] = frozen[arm]
    return frozen, binding, trial


def predict(native, exterior_raw, parents, noise, box, models):
    cfa = native["colors"]
    donors = base.exterior(exterior_raw, cfa[0], noise, box)
    decisions = {k: [] for k in models}
    wants_pair = any(k.startswith(TREATMENTS) for k in models)
    wants_integer = any(k.startswith("witness-") for k in models)
    for raw, parent, layout, wb, matrix in zip(native["packed"], parents, cfa,
                                                native["wb"], native["matrix"], strict=True):
        frame = base.features(raw, layout, noise, box, donors, parent, wb, matrix)
        if wants_pair:
            phases, pair = measured(raw, layout, noise, pair_features=True)
        else:
            phases = measured(raw, layout, noise)
        compact = replace(frame, inputs=np.concatenate((frame.inputs, phases.features), axis=-1))
        proposal = extend(frame.basis, phases)
        if wants_integer:
            integer = replace(frame, inputs=np.concatenate(
                (frame.inputs, integer_witness(raw, layout, noise)), axis=-1))
        if wants_pair:
            rotated = np.roll(pair.reshape(SIDE, SIDE, *pair.shape[1:]), 5, axis=0).reshape(pair.shape)
            mutual = {
                False: np.concatenate((compact.inputs, pair), axis=-1),
                True: np.concatenate((compact.inputs, rotated), axis=-1),
            }
        for name, model in models.items():
            if name.startswith(TREATMENTS):
                selected = replace(compact, inputs=mutual[name.endswith("-rolled")])
            elif name.startswith(("refined", "transport")):
                selected = compact
            elif isinstance(model, WitnessHead):
                selected = integer
            else:
                selected = frame
            if isinstance(model, TransportHead):
                selected = replace(selected, basis=proposal)
            view = base.apply(model, selected, parent, "shape")
            assert np.isfinite(view).all()
            decisions[name].append(view)
    return {k: np.stack(rows) for k, rows in decisions.items()}


def wire(models, binding):
    ema = {k: v for k, v in models.items() if not k.endswith(("-raw", "-rolled"))}
    tune = base.wire_panel(base.WIRE_TUNE, ema, {}, False, predictor=predict)
    group = tune["summary"]["iso6400"]["gapped"]
    scales = {k: group[k]["gap_added"]["mean"] / group[v]["gap_added"]["mean"] for k, v in PARENTS.items()}
    cal = ROOT / "wire-calibration.json"
    write_json(cal, binding | tune | {"matched_scales": scales})

    def matched(native, around, parent, noise, box, nets):
        predictions = predict(native, around, parent, noise, box, nets)
        return predictions | {"scaled-" + arm: parent + np.float32(scales[arm]) * (predictions[prev] - parent)
                              for arm, prev in PARENTS.items()}

    scores = base.wire_panel(base.WIRE_TEST, models, {}, True, predictor=matched)
    rng = np.random.default_rng(732518)
    selected = {}
    for iso in ("iso400", "iso6400"):
        rows = [r for r in scores["rows"] if r["profile"] == iso]
        selected[iso] = {k: {side: {metric: contrast(rows, k, other, metric, rng)
                                    for metric in METRICS}
                            for side, other in (("original", PARENTS[k]), ("scaled", "scaled-" + k),
                                                ("rolled", k + "-rolled"))}
                         for k in TREATMENTS}
    write_json(ROOT / "wire-scores.json", binding | scores | {"calibration": reference(cal),
                                                             "intervals": selected})


def natural(models, binding):
    overlap = base.panel_membership()
    sample = reference(base.NATURAL / "evaluation/collected.json")
    started = time.monotonic()
    rows = base.run(read_json(checked(sample))["records"], partial(base.natural_row, models=models, predictor=predict))

    def by_condition(scope):
        return {iso: {draw: base.score_group([r for r in scope if r["profile"] == iso and r["draw"] == draw])
                      for draw in ("coupled", "independent")}
                for iso in ("iso400", "iso6400")}

    isolated = [r for r in rows if r["source_id"] not in overlap]
    assert len(rows) == 256 and len(isolated) == 192
    write_json(ROOT / "natural-scores.json", binding | {"inputs": sample, "rows": rows,
        "summary": by_condition(isolated), "full_replay": by_condition(rows),
        "overlap": sorted(overlap), "seconds": time.monotonic() - started})


if __name__ == "__main__":
    torch.set_num_threads(1)
    base.panel_membership()
    options, receipt, outcome = load(ablations=True)
    stamp = {"driver": reference(__file__), "training": receipt, "checkpoint": outcome["checkpoint"],
             "previous": outcome["compared_to"], "extractor": reference(ROOT / "phase_indexed.py")}
    {"wire": wire, "natural": natural}[sys.argv[1]](options, stamp)
