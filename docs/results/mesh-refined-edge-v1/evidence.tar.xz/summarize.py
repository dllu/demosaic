"""Audit all saved comparisons and render the two new foreground-only interventions."""

from pathlib import Path
from statistics import mean
import os

import numpy as np
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import coordinates
from report_scene_wave_guides import native_board

from deliver import DISPLAY, score

ROOT = Path(__file__).resolve().parent
MODES = ("broad", "earlier-rear", "refined-rear", "refined-all")
LABELS = ("Wide delivery", "Coarse edge check", "Refined rear check", "Refined full veto")


def rms(x):
    return float(np.sqrt(np.mean(np.asarray(x, dtype=float)**2)) * 65535)


def projected_error(arrays, geometry, final):
    """Measure visible false rear structure using the known waveform only for scoring."""
    x, y, w, h = DISPLAY
    roi = np.s_[..., y:y+h, x:x+w]
    xn, yn = coordinates(h, w, origin=(x-159.5, y-159.5))
    p, q = (arrays[k][roi] for k in ("strong_phase", "weak_phase"))
    angle = geometry["edge_angle"]
    cn, sn = np.cos(angle), np.sin(angle)
    perpendicular = (-sn*xn+cn*yn)/128
    normal = cn*xn + sn*yn - geometry["edge_offset"] - geometry["curvature"]*perpendicular**2
    width = 2.5 + 1.2*((geometry["g"]-180) % 3)
    wave = q * (1-p)
    if geometry["layout"] == "continuous":
        background = np.stack((np.ones_like(xn), xn/128, yn/128, p), axis=-1).reshape(-1, 4)
        waves = wave.reshape(-1, 1)
    else:
        step = np.tanh(normal/width)
        background = np.stack((np.ones_like(xn), xn/128, yn/128, p, step, p*step), axis=-1).reshape(-1, 6)
        waves = np.stack((wave, wave*step), axis=-1).reshape(-1, 2)
    waves -= background @ np.linalg.lstsq(background, waves, rcond=None)[0]
    basis = np.linalg.qr(waves, mode="reduced")[0]
    delta = (final[0] - arrays["target"][0][roi]).reshape(3, -1)
    projection = basis.T @ delta.T
    return float(65535 * np.linalg.norm(projection) / np.sqrt(delta.size))


def audits():
    plan = read_json(ROOT / "plan.json")
    cases = {}
    references = (reference(ROOT / "part-0.json"), reference(ROOT / "part-1.json"))
    for receipt in references:
        part = read_json(checked(receipt))
        assert part["plan"] == reference(ROOT / "plan.json")
        for key in part["measurements"]:
            row = read_json(checked(key))
            assert row["entry"]["id"] not in cases
            cases[row["entry"]["id"]] = key
    camera = read_json(ROOT / "camera.json")
    assert len(cases) == len(plan["cases"]) == 24
    comparisons = []
    boards = []
    checks = 0
    dest = ROOT / "native"
    dest.mkdir(exist_ok=True)
    for entry in plan["cases"]:
        name = entry["id"]
        key = cases[name]
        row = read_json(checked(key))
        with np.load(checked(row["arrays"]), allow_pickle=False) as source:
            arrays = dict(source)
        assert entry == row["entry"]
        parent, truth = arrays["parent"], arrays["target"]
        shapes = {k: arrays[k] for k in ("strong_phase", "weak_phase", "support")}
        box = np.s_[..., 80:240, 80:240]
        blank = np.zeros_like(arrays["matching/broad"])
        states = {}
        for method, expected in row["metrics"].items():
            delta = None if method == "parent" else arrays[method]
            evidence = score(parent, delta, truth, shapes)
            assert evidence == expected, (name, method)
            checks += 1
            field = parent[box]+(blank if delta is None else delta)
            reference_delta = arrays[(method.split("/")[0] if "/" in method else "matching")+"/broad"]
            report = {
                "edited": [bool(np.any(d != b)) for d,b in zip(blank if delta is None else delta, reference_delta, strict=True)],
                "actual_role_RMS_DN16": [rms(a - b) for a,b in zip(field, truth[box], strict=True)],
                "false_rear_projection_DN16": projected_error(arrays, row["traits"]|entry, field),
            }
            states[method] = evidence | report
        comparisons.append({"id": name, "entry": entry, "traits": row["traits"], "record": key, "metrics": states,
                            "roles": row["proof"]["matching"]["roles"]})
        if name not in ("iso400-step-g180", "iso400-band-g180", "iso6400-step-g183", "iso6400-band-g183",
                        "iso400-step-g184", "iso6400-ellipse-g184"):
            continue
        roles = (0,1) if name == "iso400-step-g180" else (0,) if name == "iso400-band-g180" else (1,)
        for i in roles:
            local = parent[i]
            frames = [noisy_malvar(arrays)[i], local]
            for method in MODES:
                newly = local.copy()
                newly[box] += arrays["matching/"+method][i]
                frames.append(newly)
            frames.append(truth[i])
            render = {k: arrays[k][i:i+1] for k in ("wb", "matrix")}
            meta = {"role": i, "checkpoint": plan["checkpoint"], "source": key, "arrays": row["arrays"],
                    "CFA": row["traits"]["CFA"], "noise": plan["noise"][entry["profile"]], "seed": entry["seed"]}
            boards.append(native_board(dest, f"{name}-role{i}", frames, render, meta, labels=(
                "Noisy Malvar", "Local trunk", *LABELS, "Exact GT"), triplet_indices=(0,4,6),
                roi=DISPLAY, exposure=1, contrast=8))
    summaries = {}
    groups = [("overall", comparisons)]
    for profile in ("iso400", "iso6400"):
        for kind in ("continuity", "gaps"):
            for coupling in (False, True, None):
                name = f"{profile}/{kind}/" + ("all" if coupling is None else "independent" if coupling else "coupled")
                groups.append((name, [r for r in comparisons
                if r["entry"]["profile"] == profile and r["entry"]["kind"] == kind
                and (coupling is None or r["entry"]["independent"] == coupling)]))
    for name, group in groups:
        tails = ("matching/"+k for k in MODES)
        summaries[name] = {}
        for method in ("parent", *tails):
            rows = [r["metrics"][method] for r in group]
            gap = [r["gap_error_RMS_DN16"] for r in rows if r["gap_error_RMS_DN16"] is not None]
            summaries[name][method] = {
                "n":len(rows),
                "edited_roles": [sum(r["edited"][i] for r in rows) for i in range(3)],
                "active_roles": [sum(r["changed"][i] for r in rows) for i in range(3)],
                "response_pct": 100*mean(r["response"][0] for r in rows),
                "increment_RMS_DN16": mean(r["increment_RMS_DN16"][0] for r in rows),
                "gap_error_RMS_DN16": mean(gap) if gap else None,
                "added_gap_RMS_DN16": mean(r["gap_added_RMS_DN16"] for r in rows if r["gap_added_RMS_DN16"] is not None) if gap else None,
                "direct_present_RMS_DN16": mean(r["actual_role_RMS_DN16"][1] for r in rows),
                "direct_front_only_RMS_DN16": mean(r["negative_RMS_DN16"][0] for r in rows),
                "false_rear_projection_DN16": mean(r["false_rear_projection_DN16"] for r in rows),
            }
    camera_check = []
    for row in camera["views"]:
        with np.load(checked(row["arrays"]), allow_pickle=False) as source:
            np.testing.assert_array_equal(source["packaged"], source["refined"])
        camera_check.append(row["id"])
    write_json(ROOT / "summary.json", {"script": reference(__file__), "parts": references, "cases": comparisons,
                                      "groups": summaries, "boards": boards, "exactly_recomputed_metrics": checks,
                                      "camera_checked": camera_check, "camera": reference(ROOT / "camera.json")})


if __name__ == "__main__":
    os.sched_setaffinity(0, [14, 15])
    os.nice(12)
    audits()
