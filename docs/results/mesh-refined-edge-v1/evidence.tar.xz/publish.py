"""Publish the inspected native boards and verify their content bindings."""

from datetime import datetime, UTC
import hashlib
from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
IMAGES = REPO / "docs/images/mesh-refined-edge-v1"
RESULTS = REPO / "docs/results/mesh-refined-edge-v1"


def relative(path):
    return {"path": path.relative_to(REPO).as_posix(), "sha256": reference(path)["sha256"]}


def export(item, panels):
    origin = checked(item)
    destination = IMAGES / origin.name
    shutil.copyfile(origin, destination)
    with Image.open(destination) as image:
        for panel in panels:
            x, y, w, h = panel["png_xywh"]
            assert (w, h) == (160, 160)
            assert x+w <= image.width and y+h <= image.height
    digest = relative(destination)
    assert item["sha256"] == digest["sha256"]
    return digest


def publish():
    study = read_json(ROOT / "summary.json")
    assert study["exactly_recomputed_metrics"] == 152
    assert len(study["cases"]) == 24
    camera = read_json(checked(study["camera"]))
    verified = read_json(ROOT / "verification.json")
    assert len(verified["checks"]) == 7
    IMAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    synthetic_notes = {
        "iso400-step-g180-role0": "The foreground wires dominate and stay sharp enough to follow. The refined and broad outputs look very close.",
        "iso400-band-g180-role0": "The contrast transition and main strands remain, with only subtle change along the absent direction.",
        "iso400-step-g180-role1": "Both directions remain visible, including the fainter wire across the step.",
        "iso400-step-g184-role1": "The rear direction strengthens towards the brighter side. The two checks preserve it.",
        "iso6400-step-g183-role1": "A real second wire weakens under the checks, and the full veto fades both directions towards the trunk.",
        "iso6400-band-g183-role1": "The rear remains faint. Several soft repeats persist through the true break.",
        "iso6400-ellipse-g184-role1": "Periodic detail continues into some of the elliptical gap. The GT has clean missing segments.",
    }
    camera_notes = {
        "main-overcast-sky-main-overcast-sky": "Flat gray region, with no additional pattern.",
        "main-building-detail-main-building-detail": "Soft structural brace and fine rails.",
        "main-foliage-main-foliage": "Soft leaves with the same dark background.",
        "main-chain-link-fence-main-chain-link-fence": "Coarse crossings and the bright spot retain their contrast.",
        "mesh-nominal-fine-green-mesh-left": "Faint regular lattice beside the post remains visible.",
        "mesh-nominal-fine-green-mesh-right": "Recovered lattice crosses the bright rail and stays soft relative to the ISO100 reference.",
        "mesh-profile3879-fine-green-mesh-left": "Oblique repeats remain faint against the uneven background.",
        "mesh-profile3879-fine-green-mesh-right": "Both directions and background mottle remain apparent, with less contrast than the independent reference.",
    }
    native = []
    for board in study["boards"]:
        assert board["id"] in synthetic_notes
        for k in ("checkpoint", "source", "arrays"):
            checked(board[k])
        new = {k:v for k,v in board.items() if k not in ("board", "triplet")}
        new["viewing_note"] = synthetic_notes[board["id"]]
        views = ("board", "triplet") if board["role"] == 0 else ("board",)
        for mode in views:
            image = board[mode]
            new[mode] = {"image": export(image["image"], image["panels"]), "panels": image["panels"]}
        native.append(new)
    assert len(native) == 7 and sum("triplet" in item for item in native) == 2
    standing = []
    for panel in camera["views"]:
        assert panel["id"] in study["camera_checked"]
        assert panel["changes_DN16"]["refined_vs_packaged"] == 0
        for k in ("RAW", "source", "arrays", "parent"):
            checked(panel[k])
        standing.append(panel | {"image": export(panel["image"], panel["panels"]),
                                 "viewing_note": camera_notes[panel["id"]]})
    assert len(standing) == 8
    viewed = RESULTS / "viewing.json"
    write_json(viewed, {"viewed_utc": datetime.now(UTC).isoformat(), "camera": standing, "synthetic": native,
                        "camera_checkpoint": camera["checkpoint"], "actual_native_viewing": True,
                        "scope": "All native comparison boards (eight camera and seven synthetic) and two synthetic triplets were opened."})
    exports = ("summary.json", "verification.json", "shrinkage.json")
    for name in exports:
        shutil.copyfile(ROOT / name, RESULTS / name)

    archive = RESULTS / "evidence.tar.xz"
    inputs = sorted([p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py", ".json", ".log")]
                    + list((ROOT/"fresh").glob("*.json")))
    sources = {p.relative_to(ROOT).as_posix(): reference(p) for p in inputs}
    with tarfile.open(archive, "w:xz", preset=4) as bundle:
        for path in inputs:
            bundle.add(path, arcname=path.relative_to(ROOT).as_posix())
    with tarfile.open(archive, "r:xz") as bundle:
        assert set(bundle.getnames()) == set(sources)
        for name, item in sources.items():
            assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == item["sha256"]

    dependencies = ("local-mesh-distributed-audit-v1", "donor-phase-transport-v1",
                    "mesh-envelope-support-v1", "mesh-step-continuity-v1")
    write_json(RESULTS / "publication.json", {
        "scope": "Crop splices on existing EMA networks. Fresh exact-target panel and both standing GFX families completed. No training or comparable PSNR point.",
        "viewing": relative(viewed),
        "receipts": [relative(RESULTS / name) for name in exports],
        "source_archive": relative(archive),
        "contents": sources,
        "earlier_archives": [relative(REPO / "docs/results" / name / "evidence.tar.xz") for name in dependencies],
    })


if __name__ == "__main__":
    publish()
