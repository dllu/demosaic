"""Check the physical forecast with direct rectangular least squares and untouched reserve data."""

from pathlib import Path
import os
import sys

import numpy as np
from scipy.linalg import lstsq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.isolated_line import native_sites

ROOT = Path(__file__).resolve().parent
CONTINUITY = ROOT.parent / "mesh-step-continuity-v1"
sys.path.insert(1, str(ROOT.parent / "mesh-envelope-support-v1"))
from deliver import CENTRE, Carrier, window
from edge import evidence, nuisance, step_profile
from envelope_nuisance import observation, partition
from mesh import ribbon
from qualified_step import KNOTS


def independent_forecast(observed, null, wave, groups):
    candidate = np.column_stack((null, wave))
    result = []
    a, b, d = (groups == i for i in (1, 2, 3))
    for learn, hold in ((a, b), (b, a), (a|b, d)):
        overlap = power = 0.
        for color in (0, 1, 2):
            color_mask = observed.colors == color
            train, test = learn & color_mask, hold & color_mask
            values = observed.raw[train]
            scale = observed.shot * max(np.median(values), 1e-4) + observed.read
            without = null[test] @ lstsq(null[train], values, lapack_driver="gelsy", check_finite=False)[0]
            with_wire = candidate[test] @ lstsq(candidate[train], values, lapack_driver="gelsy", check_finite=False)[0]
            shift = with_wire - without
            overlap += np.sum(shift * (observed.raw[test] - without)) / scale
            power += np.sum(shift**2) / scale
        result.append((float(2*overlap - power), float(overlap/np.sqrt(power)), float(power)))
    return result


def run():
    earlier = read_json(CONTINUITY / "fresh.json")
    plan = read_json(checked(earlier["plan"]))
    names = {"iso400-step-g174", "iso400-disk-g174", "iso400-step-g175", "iso6400-step-g174"}
    records = []
    for key in earlier["measurements"]:
        row = read_json(checked(key))
        if row["id"] not in names:
            continue
        noise = plan["noise"][row["entry"]["profile"]]
        with np.load(checked(row["saved"]), allow_pickle=False) as f:
            raw, colors = f["packed"], f["colors"]
        for state in row["broad"]["matching"]["roles"]:
            if "central_pair" not in state:
                continue
            i = state["role"]
            sample = window(raw[i], CENTRE, phase=2)
            positions = native_sites(sample.shape[-2:], (-127.5, -127.5))
            p, q = (ribbon(*positions, Carrier(**g)) for g in state["central_pair"])
            proof = evidence(sample, colors[i], p, q, noise)["refined"]
            shape = proof["edge"]["shape"]
            obs = observation(sample, colors[i], p, q, noise, KNOTS, flexible=True)
            groups = partition(sample.shape, "distributed")
            assert set(np.unique(groups)) == {0, 1, 2, 3}
            theta, offset, width = shape
            details = []
            for version in (shape, (theta+np.pi, -offset, width)):
                direction = step_profile(*positions, version)[0].ravel()
                wave = np.column_stack((obs.wave, obs.wave * direction))
                terms = nuisance(obs, p, version, "refined")
                independent = independent_forecast(obs, terms, wave, groups)
                np.testing.assert_allclose(
                    independent,
                    [[v[k] for k in ("gain", "z", "power")] for v in proof["prediction"]],
                    rtol=2e-8, atol=1e-7,
                )
                details.append(independent)
            modified = sample.copy()
            modified[groups.reshape(sample.shape) == 3] += .004
            with_different_audit = evidence(modified, colors[i], p, q, noise)["refined"]
            assert proof["edge"] == with_different_audit["edge"]
            assert proof["prediction"][:2] == with_different_audit["prediction"][:2]
            assert proof["prediction"][2] != with_different_audit["prediction"][2]
            print(row["id"], i, flush=True)
            records.append({"id": row["id"], "role": i, "input": key,
                            "unchanged_with_audit_perturbed": ["reserve edge", "A to B", "B to A"],
                            "shape": shape, "recorded": proof, "rectangular_and_reversed": details})
    assert len(records) == 7
    write_json(ROOT / "verification-qr.json", {"driver": reference(__file__), "checks": records})


if __name__ == "__main__":
    os.sched_setaffinity(0, [14])
    os.nice(12)
    run()
