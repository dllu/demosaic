"""Verify the refined-step forecast on the previously observed false approvals."""

import os
from pathlib import Path
import sys

import numpy as np
from demosaic.isolated_line import native_sites
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"mesh-step-continuity-v1"
sys.path.insert(1,str(ROOT.parent/"mesh-envelope-support-v1"))
from deliver import CENTRE,Carrier,window
from edge import evidence
from mesh import ribbon


def run():
    plan=read_json(OLD/"plan.json")
    dataset=read_json(OLD/"fresh.json")
    cases=[]
    for key in dataset["measurements"]:
        row=read_json(checked(key))
        if row["entry"]["independent"]:
            continue
        prior=plan["noise"][row["entry"]["profile"]]
        with np.load(checked(row["saved"]),allow_pickle=False)as f:
            packed,colors=(f[k]for k in ("packed","colors"))
        roles=[]
        for item in row["broad"]["matching"]["roles"]:
            if "central_pair"not in item:
                continue
            i=item["role"]
            raw=window(packed[i],CENTRE,phase=2)
            pos=native_sites(raw.shape[-2:],(-127.5,-127.5))
            p,q=(ribbon(*pos,Carrier(**v))for v in item["central_pair"])
            options=evidence(raw,colors[i],p,q,prior,("earlier","refined","profile"))
            roles.append({"role":i,"variants":options})
        rec={"case":key,"id":row["id"],"entry":row["entry"],"roles":roles}
        cases.append(rec)
        print(row["id"], [(r["role"], [(k,y["positive"],y["strong"],round(y["edge"].get("gain",0)))for k,y in r["variants"].items()])
                          for r in roles],flush=True)
    write_json(ROOT/"development.json",{"driver":reference(__file__),"source":reference(OLD/"fresh.json"),
                                         "rows":cases,"scope":"Retrospective fixed candidate probe on the old exact-target panel. Only already-active corrections are analyzed."})


if __name__=="__main__":
    os.sched_setaffinity(0,[14,15]);os.nice(12)
    run()
