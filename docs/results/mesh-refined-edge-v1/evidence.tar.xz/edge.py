"""Find a RAW-only foreground edge and use it in a disjoint weak-wire test."""

import itertools
import math

import numpy as np
from scipy.optimize import minimize

from envelope_nuisance import observation, partition
from qualified_step import KNOTS, select_step


def step_profile(x, y, shape):
    angle, offset, width = shape
    normal = np.cos(angle)*x+np.sin(angle)*y-offset
    return np.tanh(normal/width), normal


def fit_edge(data, reserve):
    """Optimize a few distinct foreground steps using the phase reserve alone."""
    x,y=(v[reserve]for v in data.positions)
    colors=data.colors[reserve]
    base=np.column_stack((data.nuisance,data.wave))[reserve]
    samples=data.raw[reserve]
    sub=[]
    for c in range(3):
        take=colors==c
        q=np.linalg.qr(base[take],mode="reduced")[0]
        values=samples[take]
        residual=values-q@(q.T@values)
        variance=data.shot*max(float(np.median(values)),1e-4)+data.read
        sub.append((take,q,residual,variance))
    coarse=list(itertools.product(np.deg2rad(np.arange(0,180,10)),range(-72,73,8),(3.5,)))

    def gains(shapes):
        array=np.column_stack([step_profile(x,y,shape)[0]for shape in shapes])
        totals=np.zeros(len(shapes))
        for take,basis,r,variance in sub:
            design=array[take]
            projection=basis.T@design
            energy=(design*design).sum(0)-(projection*projection).sum(0)
            totals+=(r@design)**2/(np.maximum(energy,1e-11)*variance)
        return totals

    rank=np.concatenate([gains(coarse[i:i+24])for i in range(0,len(coarse),24)])
    if rank.max()<48:
        return None,{"best_coarse_gain":float(rank.max())}
    groups=[]
    for i in np.argsort(-rank):
        theta,distance,w=coarse[i]
        if all(abs(theta-old[0])>np.deg2rad(9) or abs(distance-old[1])>14 for old in groups):
            groups.append((theta,distance,w))
        if len(groups)==3:
            break

    def optimize(seed):
        theta,distance,w=seed
        degree=np.pi/180

        def direction(guess):
            return (theta+guess[0]*degree, distance+guess[1],guess[2])

        def objective(guess):
            return -float(gains([direction(guess)])[0])

        result=minimize(objective,[0.,0.,w],method="Nelder-Mead",
                        bounds=((-13,13),(-18,18),(1.4,12.)),
                        options={"initial_simplex":((0,0,w),(2,0,w),(0,3,w),(0,0,5.)),
                                 "maxiter":55,"xatol":.02,"fatol":.15})
        return -float(result.fun),direction(result.x)

    best=max(map(optimize,groups),key=lambda row:row[0])
    return best[1],{"gain":best[0],"shape":[float(v)for v in best[1]],
                    "best_coarse_gain":float(rank.max())}


def nuisance(data,front,shape,variant):
    if shape is None:
        return data.nuisance
    step,normal=step_profile(*data.positions,shape)
    base=[data.nuisance,step,front.ravel()*step]
    if variant=="profile":
        # Allow the measured edge ramp to deviate from a tanh, with
        # compact, smooth features. Both hypotheses use the same terms.
        bands=[np.exp(-.5*((normal-k)/scale)**2)
               for k,scale in ((-6.,4.),(0.,2.5),(6.,4.),(0.,9.))]
        base.extend(bands)
        base.extend(front.ravel()*b for b in bands[:3])
    return np.column_stack(base)


def forecasts(data,background,template,selection):
    design=np.column_stack((background,template))
    values=[]
    for learn,hold in selection:
        gain=overlap=power=0.
        for color in range(3):
            tr=learn&(data.colors==color);te=hold&(data.colors==color)
            y=data.raw[tr]
            variance=data.shot*max(float(np.median(y)),1e-4)+data.read
            without,with_wire=(x[te]@np.linalg.solve(x[tr].T@x[tr],x[tr].T@y)for x in (background,design))
            d=with_wire-without
            overlap+=float((data.raw[te]-without)@d)/variance
            power+=float(d@d)/variance
        gain=2*overlap-power
        values.append({"gain":gain,"z":overlap/math.sqrt(max(power,1e-20)),"power":power})
    return values


def evidence(raw,colors,front,rear,noise,variants=("refined",)):
    data=observation(raw,colors,front,rear,noise,KNOTS,flexible=True)
    slot=partition(raw.shape,"distributed")
    a,b,d=(slot==k for k in (1,2,3))
    selection=((a,b),(b,a),(a|b,d))
    refined,edge=fit_edge(data,slot==0)
    if "earlier"in variants:
        _,fallback=select_step((*data.positions,data.colors,slot,data.wave,data.nuisance,data.raw,noise))
    result={}
    for variant in variants:
        shape=fallback.get("shape") if variant=="earlier" else refined
        background=nuisance(data,front,shape,variant)
        wave=data.wave
        if shape is not None:
            step=step_profile(*data.positions,shape)[0]
            wave=np.column_stack((wave,wave*step))
        forecasts_for_wave=forecasts(data,background,wave,selection)
        result[variant]={"prediction":forecasts_for_wave,
                          "positive":all(v["gain"]>0 for v in forecasts_for_wave),
                          "strong":all(v["gain"]>0 and v["z"]>1.75 for v in forecasts_for_wave),
                          "edge":fallback if variant=="earlier"else edge}
    return result
