"""Exploratory amplitude-only diagnostic on held-out differences already recorded."""

from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent


def compare(proof):
    # Replacing the candidate displacement d by s*d multiplies its overlap
    # by s and its squared power by s*s. Standardized overlap stays fixed.
    s = .5
    revised = [s * r["gain"] + s * (1-s) * r["power"] for r in proof["prediction"]]
    return {"before": proof["strong"], "half_forecast": all(t > 0 and r["z"] > 1.75
             for t,r in zip(revised, proof["prediction"], strict=True)),
            "shrunken_gains": revised, "original_forecasts": proof["prediction"], "edge": proof["edge"]}


def run():
    development = read_json(ROOT / "development.json")
    earlier = [{"id": x["id"], "role": row["role"], "forecast": compare(row["variants"]["refined"])}
               for x in development["rows"] for row in x["roles"]]
    fresh = []
    for part in ("part-0.json", "part-1.json"):
        for key in read_json(ROOT / part)["measurements"]:
            row = read_json(checked(key))
            for context, option in row["proof"].items():
                for branch in option["roles"]:
                    if "evidence" in branch:
                        fresh.append({"id": row["entry"]["id"], "context": context, "role": branch["role"],
                                      "forecast": compare(branch["evidence"]["refined"])})
    for records in (earlier, fresh):
        for row in records:
            data = row["forecast"]
            if data["edge"].get("shape") is not None and data["before"] != data["half_forecast"]:
                print(row["id"], row["role"], data)
    write_json(ROOT / "shrinkage.json", {"source": reference(__file__),
               "panels": [reference(ROOT/p) for p in ("development.json","part-0.json","part-1.json")],
               "scope": "Factor chosen after examining the fresh panel. Scales forecasts only; does not change delivered amplitudes.",
               "development": earlier, "fresh": fresh})


if __name__ == "__main__":
    run()
