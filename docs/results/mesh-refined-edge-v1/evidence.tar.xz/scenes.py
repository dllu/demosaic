"""Generate native test scenes with genuine contrast changes and true breaks."""

import dataclasses
import math

import numpy as np
import torch

from demosaic.cfa import PATTERNS,mosaic
from demosaic.experiments.data.paired import paired_observation
from demosaic.isolated_line import coordinates
from demosaic.noise import add_noise,variance_map
from mesh import ribbon
from run import prior


def smooth(t):
    s=np.clip(t,0,1)
    return s*s*(3-2*s)


def pack(rgb,pattern,key,noise):
    raw=add_noise(mosaic(rgb[None],pattern),noise["shot"],noise["read"],black_level=.03,
                  generator=torch.Generator().manual_seed(key))
    return raw,variance_map(raw,noise["shot"],noise["read"])


def observe(entry,noise):
    g,seed=entry["g"],entry["seed"]
    i=g-180
    cfa=tuple(PATTERNS)[g%4]
    guides=prior.guides(g)
    x,y=coordinates(320,320,origin=(-159.5,-159.5))
    p,q=(ribbon(x,y,c)for c in guides)
    background=np.array([.235,.283,.338])[:,None,None]+.018*x/320-.016*y/320
    background=background+.0034*np.sin(.019*x-.022*y)+.0025*np.cos(.023*x+.026*y)
    angle=(np.arctan2(guides[1].frequency[1],guides[1].frequency[0])+
           np.deg2rad((3,8,17,32,65,85)[i]))%np.pi
    u,v=np.cos(angle),np.sin(angle)
    offset=(11,-26,19,-13,24,-7)[i]
    curvature=(0,0,0,11,0,-15)[i]
    across=u*x+v*y-offset-curvature*((-v*x+u*y)/128)**2
    step=.5+.5*np.tanh(across/(2.5+1.2*(i%3)))
    has_edge=entry["layout"]!="continuous"
    if has_edge:
        background=background+np.array([.025,.029,.019])[:,None,None]*step
    shade=(.58,.43,.5,.38,.62,.49)[i]
    shade_rgb=np.array([shade*.94,shade,shade*1.1])[:,None,None]
    weak_shading=shade_rgb+(1-shade_rgb)*step if has_edge else 1.
    strong_shading=.76+.24*step if has_edge else 1.
    strength=(.0063,.0078,.0088,.0108,.0117,.0123)[i]
    footprint=np.ones_like(p)
    mode=entry["layout"]
    if mode=="band":
        a=angle+(-.47 if i%2 else .61)
        gap_dir=np.cos(a)*x+np.sin(a)*y-(18 if i%2 else -22)
        footprint=smooth((abs(gap_dir)-29)/13)
    elif mode in ("ellipse","disk"):
        dx,dy=(24,-30,31,-24,22,-26)[i],(-26,25,-25,28,-19,22)[i]
        a=x-dx;b=y-dy
        if mode=="ellipse":
            radial=np.hypot((u*a+v*b)/.64,(-v*a+u*b)/1.35)
        else:
            radial=np.hypot(a,b)
        footprint=smooth((radial-39)/13)
    first=background+(.036*prior.STRONG*p*strong_shading)
    present=first+strength*prior.FAINT*weak_shading*q*(1-p)*footprint
    absent,truth,edge=(torch.from_numpy(v.astype(np.float32))for v in(first,present,background))
    packed,details=paired_observation(absent[None],truth[None],noise,[cfa],torch.ones(1,3),torch.eye(3)[None],seed)
    items={k:torch.from_numpy(packed[k])for k in("target","packed","variance","colors","wb","matrix")}
    pattern=items["colors"][0]
    if entry["independent"]:
        values,variance=zip(*(pack(t,pattern,seed+71+i*601,noise)for i,t in enumerate((absent,truth))),strict=True)
        items["packed"]=torch.cat(values)
        items["variance"]=torch.cat(variance)
    edge_raw,edge_var=pack(edge,pattern,seed+2357,noise)
    tails={"target":edge[None],"packed":edge_raw,"variance":edge_var,
           **{k:items[k][:1]for k in ("colors","wb","matrix")}}
    items={k:torch.cat((v,tails[k]))for k,v in items.items()}
    xx,yy=coordinates(768,768,origin=(-383.5,-383.5))
    donors={}
    extent=np.zeros_like(xx)
    for cx,cy in ((-238,-33),(227,40),(-25,234)):
        extent=np.maximum(extent,smooth((111-np.maximum(abs(xx-cx),abs(yy-cy)))/20))
    rotate=np.array([[np.cos(.49),-np.sin(.49)],[np.sin(.49),np.cos(.49)]])
    for name,geometry in (("matching",guides),("unrelated",tuple(dataclasses.replace(c,frequency=tuple(rotate@c.frequency))for c in guides))):
        if name=="unrelated"and not entry["rotated"]:
            continue
        p1,q1=(ribbon(xx,yy,c)for c in geometry)
        bg=np.array([.23,.281,.34])[:,None,None]+.023*xx/768-.013*yy/768
        image=bg+extent*(.097*prior.STRONG*p1+.069*prior.FAINT*q1)
        exterior=pack(torch.from_numpy(image.astype(np.float32)),pattern,seed+7409,noise)[0]
        donors[name]=exterior[0].numpy()
    return items,donors,{"strong_phase":p,"weak_phase":q,"support":footprint},details,{
        "case_geometry":[vars(c)for c in guides],"CFA":cfa,"weak_amplitude":strength,
        "edge_angle":float(angle),"edge_offset":offset,"curvature":curvature,"weak_side_fraction":shade,
        "continuous_across_step":bool(has_edge and mode=="step"),"independent_noise":entry["independent"],
    }
