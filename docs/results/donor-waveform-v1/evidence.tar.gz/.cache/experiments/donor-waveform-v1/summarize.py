"""Summarize paired source effects and match measured quiet error descriptively."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from report_fold_support_pooling import ROI, evaluated, measure
from scipy.optimize import brentq

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent / "review"
path = root / "result.json"
report = read_json(path)
audit_path = root / "independent-audit.json"
audit = read_json(audit_path)
assert audit["status"] == "passed"
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
columns = (
    "weak_gain",
    "strong_gain",
    "quiet_delta_DN16",
    "weak_increment_RMS_DN16",
    "abs_weak_absent_projection",
    "centered_chroma_increment_RMS_DN16",
    "R",
    "G",
    "B",
)
arms = ("independent", *plan["arms"])
groups = defaultdict(lambda: defaultdict(dict))
for r in report["metrics"]:
    key = r["profile"], r["placement"], r["method"], r["budget_DN16"]
    groups[key][r["model"]][r["source"]] = [
        r["weak_gain"],
        r["strong_gain"],
        r["quiet_delta_DN16"],
        r["weak_increment_RMS_DN16"],
        abs(r["weak_absent_projection"]),
        r["centered_chroma_increment_RMS_DN16"],
        *r["response_RGB"],
    ]
assert len(groups) == 16 and all(len(v[m]) == 8 for v in groups.values() for m in arms)
draws = np.random.default_rng(11670).integers(0, 8, (12000, 8))
rows = []
for (profile, placement, method, budget), models in groups.items():
    order = sorted(models["independent"])
    data = {m: np.asarray([models[m][k] for k in order]) for m in arms}
    means = {m: v.mean(axis=0).tolist() for m, v in data.items()}
    differences = {}
    for a, b in (("donor", "independent"), ("scrambled", "independent"), ("donor", "scrambled")):
        delta = data[a] - data[b]
        differences[f"{a}_vs_{b}"] = {
            "mean": delta.mean(axis=0).tolist(),
            "descriptive_95_percent": np.quantile(
                delta[draws].mean(axis=1), [0.025, 0.975], axis=0
            ).tolist(),
            "higher_weak_response": int((delta[:, 0] > 0).sum()),
            "lower_increment_error": int((delta[:, 3] < 0).sum()),
        }
    rows.append(
        {
            "profile": profile,
            "placement": placement,
            "method": method,
            "budget_DN16": budget,
            "means": means,
            "paired_differences": differences,
        }
    )

settings = {
    (r["profile"], r["placement"]): r
    for r in plan["settings"]
    if r["method"] == "weighted-refit" and r["budget_DN16"] == 0.02
}
saved = defaultdict(lambda: defaultdict(list))
for binding in collection["synthetic"]:
    record = read_json(checked(binding))
    case = read_json(checked(record["case"]))
    prior = read_json(checked(record["control"]))
    key = case["profile"], case["placement"]
    setting = settings[key]
    suffix = f"weighted-refit-t{setting['threshold']:g}"
    parent = np.load(checked(case["parent"])).astype(np.float64)
    with (
        np.load(checked(case["target"])) as targets,
        np.load(checked(record["predictions"])) as new,
        np.load(checked(prior["output"])) as old,
    ):
        reference_rgb = targets["target"].astype(np.float64)
        quiet = targets["quiet"][ROI]
        for m, prediction in [
            ("independent", old[f"{plan['reference_arm']}--{suffix}"]),
            *((m, new[f"{m}--{suffix}"]) for m in plan["arms"]),
        ]:
            saved[key][m].append(measure(parent, reference_rgb, quiet, prediction))


def quiet_match(models, scale):
    names = ("quiet_RMS_DN16", "weak_gain", "weak_increment_RMS_DN16")

    def mean(m, multiplier):
        points = [evaluated(v, scale * multiplier) for v in models[m]]
        return np.array([np.mean([r[n] for r in points]) for n in names])

    target = min(mean(m, 1)[0] for m in models)

    def fit(m):
        if mean(m, 1)[0] == target:
            return 1.0
        if mean(m, 0)[0] > target:
            return None
        return brentq(lambda u: mean(m, u)[0] - target, 0, 1, xtol=1e-11)

    scales = {m: fit(m) for m in models}
    measured = {m: mean(m, s).tolist() for m, s in scales.items() if s is not None}
    assert all(abs(row[0] - target) < 1e-9 for row in measured.values())
    return {"columns": names, "common_multiplier_per_model": scales, "matched": measured}


matched = [
    {"profile": profile, "placement": place, **quiet_match(saved[profile, place], s["scale"])}
    for (profile, place), s in settings.items()
]
paired_quiet = [
    {
        "profile": profile,
        "placement": place,
        **quiet_match(
            {model: saved[profile, place][model] for model in ("independent", "donor")},
            s["scale"],
        ),
    }
    for (profile, place), s in settings.items()
]
write_json(
    root / "summary.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "audit": reference(audit_path),
        "columns": columns,
        "groups": rows,
        "matched_quiet_descriptive": matched,
        "matched_quiet_donor_vs_independent": paired_quiet,
        "camera": audit["camera_checks"],
    },
)
for r in rows:
    if r["method"] == "weighted-refit" and r["budget_DN16"] == 0.02:
        print(
            r["profile"],
            r["placement"],
            {a: np.round(v[:6], 7).tolist() for a, v in r["means"].items()},
            flush=True,
        )
print(matched, flush=True)
print(paired_quiet, flush=True)
