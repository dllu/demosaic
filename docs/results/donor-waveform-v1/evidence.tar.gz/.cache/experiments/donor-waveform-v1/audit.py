"""Independently reduce saved RGB predictions and check native comparison panels."""

from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
path = root / "review/result.json"
report = read_json(path)
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
earlier = read_json(checked(plan["guard_report"]))
assert collection["synthetic_calls"] == 192 and collection["camera_calls"] == 16
assert len(report["metrics"]) == 384 and len(report["boards"]) == 4
groups = defaultdict(list)
for r in report["metrics"]:
    groups[r["id"]].append(r)
roi = np.s_[..., 128:384, 128:384]


def rms(v):
    return np.sqrt(np.mean(np.square(v))) * 65535


def projection(a, b, *, axes=None):
    return np.sum(a * b, axis=axes) / np.sum(b * b, axis=axes)


def check_spectrum(donor):
    original = np.asarray(donor["templates"]["donor"])
    control = np.asarray(donor["templates"]["scrambled"])
    np.testing.assert_allclose(
        abs(np.fft.rfft(control, axis=-1)),
        abs(np.fft.rfft(original, axis=-1)),
        atol=1e-14,
        rtol=0,
    )
    np.testing.assert_allclose(original.sum(axis=1), 0, atol=1e-14, rtol=0)
    assert np.all(np.linalg.norm(original - control, axis=1) > 1e-8)


def check_folds(independent, constrained):
    count = 0
    for a, b in zip(independent["records"], constrained["records"], strict=True):
        for name in ("frequencies", "edges", "guide_search_excluded"):
            assert a[name] == b[name]
            count += len(a[name])
        shifts = np.asarray(b["donor_phase_shifts"])
        assert shifts.shape == (2, 2) and np.isin(shifts, np.arange(24) / 24).all()
    return count


reductions, delta, fold_checks = 0, 0.0, 0
background = []
for binding in collection["synthetic"]:
    item = read_json(checked(binding))
    old = read_json(checked(item["control"]))
    source = read_json(checked(item["case"]))
    assert item["id"] == source["id"] == old["id"]
    donor = collection["synthetic_donors"][item["guide_key"]]
    assert donor["arrays"] != source["sensor"]
    check_spectrum(donor)
    for arm, fits in item["fits"].items():
        for independent, constrained in zip(old["fits"][plan["reference_arm"]], fits, strict=True):
            assert constrained["donor_phase_templates"] == donor["templates"][arm]
            fold_checks += check_folds(independent, constrained)
    parent = np.load(checked(source["parent"])).astype(np.float64)
    with np.load(checked(source["target"])) as data:
        target = data["target"].astype(np.float64)
        quiet = data["quiet"][roi]
    weak, strong = np.diff(target, axis=0)[::-1]
    with (
        np.load(checked(item["predictions"])) as candidate,
        np.load(checked(old["output"])) as independent,
    ):
        for row in groups[item["id"]]:
            key = f"{row['method']}-t{row['threshold']:g}"
            arm = row["model"]
            saved = (
                independent[f"{plan['reference_arm']}--{key}"]
                if arm == "independent"
                else candidate[f"{arm}--{key}"]
            )
            prediction = parent.copy()
            scale = row["scale"]
            prediction[roi] = (1 - scale) * parent[roi] + scale * saved.astype(np.float64)
            error = prediction - target
            inc_weak, inc_strong = np.diff(prediction, axis=0)[::-1]
            weak_error = inc_weak - weak
            chroma = weak_error[roi] - weak_error[roi].mean(axis=0, keepdims=True)
            actual = {
                "weak_gain": projection(inc_weak, weak),
                "strong_gain": projection(inc_strong, strong),
                "weak_absent_projection": projection(error[1], weak),
                "weak_increment_RMS_DN16": rms(weak_error),
                "quiet_RMS_DN16": rms(error[roi][..., quiet]),
                "query_RMS_DN16": rms(error[roi]),
                "quiet_delta_DN16": rms(error[roi][..., quiet])
                - rms((parent - target)[roi][..., quiet]),
                "response_RGB": projection(inc_weak[roi], weak[roi], axes=(1, 2)),
                "centered_chroma_increment_RMS_DN16": rms(chroma),
            }
            for name, value in actual.items():
                np.testing.assert_allclose(value, row[name], rtol=0, atol=4e-10)
                delta = max(delta, float(np.max(np.abs(value - row[name]))))
                reductions += np.size(value)
            if row["method"] == "weighted-refit" and row["budget_DN16"] == 0.02:
                background.append(
                    {
                        "id": row["id"],
                        "profile": row["profile"],
                        "placement": row["placement"],
                        "model": row["model"],
                        "delivered_correction_DN16": float(rms((prediction - parent)[0][roi])),
                    }
                )


def display_cell(path, panel):
    x, y, w, h = panel["png_xywh"]
    assert (w, h) == (160, 160)
    return np.asarray(Image.open(checked(path)))[y : y + h, x : x + w]


assert reductions == 4224 and fold_checks == 1152 and len(background) == 96
camera_checks = []
retained = 0
old = read_json(checked(plan["guard_collection"]))
for row, prev, new, control in zip(
    report["camera"], earlier["camera"], collection["camera"], old["camera"], strict=True
):
    assert row["id"] == prev["id"] == new["id"] == control["id"]
    additions = {"Donor waveform", "Scrambled waveform"}
    keep = [p for p in row["panels"] if p["label"] not in additions]
    for a, b in zip(keep, prev["panels"], strict=True):
        assert a["label"] == b["label"]
        np.testing.assert_array_equal(display_cell(row["image"], a), display_cell(prev["image"], b))
        retained += 1
    scene = row["source"]
    x, y, w, h = row["ROI_xywh"]
    qx, qy, qw, qh = scene["absolute_query_xywh"]
    dx, dy, dw, dh = scene["absolute_donor_xywh"]
    assert max(qx, dx) >= min(qx + qw, dx + dw) or max(qy, dy) >= min(qy + qh, dy + dh)
    donor = collection["camera_donors"][row["id"]]
    check_spectrum(donor)
    assert donor["box"] == scene["donor_box"] and donor["arrays"] == scene["donor_arrays"]
    ox, oy, *_ = scene["query_box"]
    parent_crop = np.load(checked(scene["parent_prediction"]), mmap_mode="r")[
        0, :, y : y + h, x : x + w
    ]
    crop = np.s_[:, y - oy : y - oy + h, x - ox : x - ox + w]
    with (
        np.load(checked(row["template_predictions"])) as current,
        np.load(checked(prev["guarded_prediction"])) as old_arrays,
    ):
        for arm in donor["templates"]:
            constrained = new["fits"][arm]
            assert constrained["donor_phase_templates"] == donor["templates"][arm]
            fold_checks += check_folds(control["fits"]["guard8"], constrained)
            val = current[arm][crop].astype(np.float64)
            measured = rms(val - old_arrays["guard8"][crop])
            assert abs(measured - row["change_from_independent_RMS_DN16"][arm]) < 1e-12
            camera_checks.append(
                {
                    "id": row["id"],
                    "arm": arm,
                    "minus_V120_RMS_DN16": float(rms(val - parent_crop)),
                    "minus_independent_RMS_DN16": float(measured),
                }
            )
for b in report["boards"]:
    f, t = b["board"], b["triplet"]
    for j, k in enumerate((0, 3, 5)):
        np.testing.assert_array_equal(
            display_cell(f["image"], f["panels"][k]), display_cell(t["image"], t["panels"][j])
        )
assert retained == 120 and fold_checks == 1248
write_json(
    root / "review/independent-audit.json",
    {
        "driver": reference(__file__),
        "report": reference(path),
        "status": "passed",
        "native_reductions": int(reductions),
        "maximum_difference": delta,
        "fold_geometry_and_guard_where_matched": fold_checks,
        "camera_checks": camera_checks,
        "retained_camera_cells_bitexact": retained,
        "exact_triplet_subsets": 4,
        "no_wire_role": background,
    },
)
print(reductions, delta, retained, "independent audit passed", flush=True)
