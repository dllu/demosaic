"""Retain exact double gaps with the largest beneficial and adverse changes."""

import numpy as np
import torch

from restore_evaluate import (
    FRESH, NAMES, PARENT, ROOT, bands, checked, native_board, noisy_malvar,
    read_json, reference, scores, write_json,
)

METRIC = "false_strong_RMS_DN16"


def render(source):
    torch.set_num_threads(2)
    delivery_ref = reference(ROOT / "delivery/result.json")
    delivery = read_json(checked(delivery_ref))
    panel = read_json(FRESH)
    parent = read_json(PARENT)
    directory = ROOT / "tails"
    directory.mkdir()
    boards = []
    for guide, selected, direction in (("exact", min, "largest-reduction"), ("radial", max, "largest-increase")):
        sample = [r for r in delivery["rows"][guide] if r["ISO"] == "ISO6400"]
        case = panel["rows"][selected(
            sample, key=lambda r: r["scores"]["innovation"][METRIC]-r["scores"]["fixed"][METRIC]
        )["index"]]
        ref = delivery["refinement"][guide]
        comparisons = read_json(checked(ref))
        records = []
        for n in (0,1):
            arrays, predictions, _ = bands(panel, case, n, parent["cases"][case["index"]], comparisons, guide)
            frame = {k:scores([v],arrays["target"],case,arrays) for k,v in predictions.items()}
            records.append((frame["innovation"][METRIC]-frame["fixed"][METRIC], n, arrays, predictions, frame))
        change, n, arrays, predictions, frame = selected(records,key=lambda r:r[0])
        camera = {k: arrays[k][None] for k in ("wb","matrix","colors")} | {"packed":arrays["packed"][1:2]}
        board = native_board(directory, f"{guide}-ISO6400-{direction}-{case['index']:02d}-draw{n}",
            [noisy_malvar(camera)[0], *(predictions[k][1] for k in NAMES), arrays["target"][1]],
            camera, {"source":case["source"],"crop":case["crop"],"input":case["draws"][n]["arrays"],
                     "scores":frame, "change_in_false_strong_RMS_DN16":change,
                     "noise":case["profile"],"checkpoint":parent["checkpoints"],"role":"double-gap"},
            labels=("Noisy Malvar",*NAMES.values(),"Exact GT"),triplet_indices=(0,5,6),exposure=2)
        boards.append(board)
        print(board["id"],case["source"]["title"],round(change,5),flush=True)
    write_json(directory/"result.json",{"delivery":delivery_ref,"driver":reference(source),
         "selection":"ISO6400 source-ranked double-gap projection reduction (exact starting guide) and increase (half-bin error), with the highest-magnitude redraw per source.","boards":boards})


if __name__=="__main__":
    render(__file__)
