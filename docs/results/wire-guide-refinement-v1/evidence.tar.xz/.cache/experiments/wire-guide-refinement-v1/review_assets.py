"""Combine already rendered native cells and plot empirical RAW admission."""

import os
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
STRATEGIES = {"fixed": "Fixed guide", "affine": "Affine refinement", "innovation": "Innovation refinement"}


def sheet(name, cases, names):
    board = Image.new("RGB", (len(names)*168+8, len(cases)*192), "#161b20")
    draw = ImageDraw.Draw(board)
    for n,(label,src) in enumerate(cases):
        y = 192*n
        draw.text((8,y+2), label, fill="#eef4f5")
        panels = {c.get("name",c.get("label")):c["png_xywh"] for c in src["panels"]}
        with Image.open(checked(src["image"])) as image:
            for i,key in enumerate(names):
                sx,sy,w,h = panels[key]
                assert (w,h)==(160,160)
                crop=image.crop((sx,sy,sx+w,sy+h))
                x=i*168+8
                board.paste(crop,(x,y+29))
                draw.text((x,y+15),key,fill="#d0d6dd")
    board.save(ROOT/f"view-{name}.png")


def native_views():
    restored = read_json(ROOT/"delivery/result.json")
    camera = read_json(ROOT/"camera-v2/result.json")
    donors = read_json(ROOT/"camera-donors/result.json")
    for iso in ("ISO400","ISO6400"):
        crops = [(r["id"],r["board"]) for r in restored["views"] if iso in r["id"]]
        sheet(f"exact-{iso}",crops,("Noisy Malvar","Aligned control",*STRATEGIES.values(),"Exact GT"))
    for exp in (4,16):
        for prefix in ("main","mesh"):
            crops = [
                (r["id"],d["board"])
                for r in camera["rows"] if r["id"].startswith(prefix)
                for d in r["displays"] if d["exposure"]==exp
            ]
            if not crops:
                continue
            sheet(f"{prefix}-x{exp}",crops,("V120 EMA","Aligned control","Fixed guide lift",
                                             "Affine refined lift","Innovation refined lift","ISO100 AHD reference"))
            if prefix=="mesh":
                sheet(f"{prefix}-refs-x{exp}",crops,("Noisy (Malvar)","ISO6400 camera JPEG",
                                                     "ISO100 AHD reference","ISO100 camera JPEG"))
        crops = [(r["id"],d["board"]) for r in donors["rows"] for d in r["displays"] if d["exposure"]==exp]
        sheet(f"donors-x{exp}",crops,("Aligned control","Corpus 100k + earlier donor","Fixed donor guide",
                                     "Affine refined donor","Innovation refined donor","ISO100 AHD reference"))


def admission_plot():
    os.environ.setdefault("MPLCONFIGDIR", str(ROOT/"matplotlib"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    iso_levels = ("ISO400","ISO6400")
    guide_labels = {"exact":"Exact starting guide","rounded":"Rounded x/y bins","radial":"Half-bin radial error"}
    colors = ("#53748d","#9a5c30","#157665")
    source = {k:reference(ROOT/f"{k}.json") for k in guide_labels}
    fig,axes = plt.subplots(2,3,figsize=(12.4,6.7),sharey=True,constrained_layout=True)
    for j,(guide,title) in enumerate(guide_labels.items()):
        raw = read_json(checked(source[guide]))
        for i,iso in enumerate(iso_levels):
            ax = axes[i,j]
            ax.set_title(f"{title}, {iso}")
            ax.grid(color="#e8eaec",linewidth=.75)
            for (method,label),color in zip(STRATEGIES.items(), colors, strict=True):
                receipt = raw["results"][iso]["decisions"][method]["placebo_shrinkage"]
                counts = receipt["counts_exterior"]
                mids = np.array([counts[k] for k in sorted(counts,key=float)])
                true,false,_ = counts["0.5"]
                ax.plot(mids[:,1],mids[:,0],label=label,color=color,lw=1.7)
                ax.scatter(false,true,color=color,edgecolor="white",linewidth=.7,s=39,zorder=5)
            ax.set_ylim(6,64.5)
            if i==1:
                ax.set_xlabel("False calls among 64 double gaps")
            if j==0:
                ax.set_ylabel("True calls among 64 continuations")
    axes[0,0].legend(frameon=False,loc="lower right")
    path=ROOT/"guide-admission.png"
    fig.savefig(path,dpi=165,facecolor="white")
    plt.close(fig)
    write_json(ROOT/"plot.json",{"inputs":source,"driver":reference(__file__),"image":reference(path),
                                "markers":"Continuation exceeds half of measured exterior amplitude",
                                "scope":"Paired raw decision counts on the same 64 sources across guides and methods. Plots use the stored threshold grid and fixed exterior z >= 3 on both folds."})


if __name__=="__main__":
    native_views()
    admission_plot()
