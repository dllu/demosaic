"""Bind native inspection notes to the reviewed images and chart."""

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
NOTES = {
    "rounded-ISO400-best-45-draw0": "The inclined lines extend a little more evenly across the inclined background transition. Crossings are weaker than the exact image.",
    "rounded-ISO400-worst-03-draw1": "Refinement slightly strengthens some of the central vertical stripes. The difference between guides is subtle.",
    "radial-ISO400-best-10-draw1": "A few nearly horizontal lines are clearer in the center. The fine family stays faint.",
    "radial-ISO400-worst-03-draw1": "Central vertical line amplitudes differ slightly. The blurred foreground edges persist.",
    "rounded-ISO6400-best-56-draw0": "A faint diagonal appears over cloud reflections near the center. Many target crossings remain unresolved.",
    "rounded-ISO6400-worst-09-draw1": "Wide horizontal lines gain too much contrast in the middle. The faint diagonal family in the target is missing.",
    "radial-ISO6400-best-30-draw0": "A small change in the crossing over the fabric folds. The fine surface texture stays softer than the target.",
    "radial-ISO6400-worst-09-draw1": "The central horizontal lines strengthen, with the diagonal family still mostly absent.",
    "exact-ISO6400-largest-reduction-08-draw1": "The numeral edges are similar. The refinement removes part of the weak central line crossing the blank field.",
    "radial-ISO6400-largest-increase-33-draw1": "A faint oblique line shifts over the dark area near the curved bright rim. The larger measured false projection is subtle in the full native view.",
    "main-overcast-sky-main-overcast-sky": "The overcast sky stays smooth. No proposal and no delivered change.",
    "main-building-detail-main-building-detail": "Thin poles and bracing remain soft. The innovation mix reduces the existing local horizontal correction.",
    "main-foliage-main-foliage": "Leaf silhouettes and the smooth dark leaf undersides match the aligned control.",
    "main-chain-link-fence-main-chain-link-fence": "The coarse diamond crossings stay coherent. Local modulation shifts subtly.",
    "mesh-nominal-fine-green-mesh-left": "No bank and no change. The crop remains mottled and mostly unresolved beside the post.",
    "mesh-nominal-fine-green-mesh-right": "Both directions appear in the tested circle. Refinement leaves a regular patch and missing crossings farther out.",
    "mesh-profile3879-fine-green-mesh-left": "No query bank. The aligned parent already shows parts of the lower diagonals. Intersection gaps persist.",
    "mesh-profile3879-fine-green-mesh-right": "Transferred conditioning is clearer. Refined lift strengthens the local patch slightly and the fine crossings remain incomplete.",
}
DONORS = {
    "mesh-nominal-fine-green-mesh-left": "Affine adds one diagonal family locally. The verified results do not restore a connected lattice. The earlier wider donor fit shows a much more regular grid.",
    "mesh-profile3879-fine-green-mesh-left": "The fixed and affine guides accent different diagonals. Innovation returns the aligned parent. The earlier donor result has clearer but overly even diamonds.",
}


def main():
    receipts = {
        k: reference(ROOT / p)
        for k, p in {
            "restoration": "delivery/result.json",
            "tails": "tails/result.json",
            "main": "camera-v2/result.json",
            "donors": "camera-donors/result.json",
            "plot": "plot.json",
        }.items()
    }
    states = {k: read_json(checked(v)) for k, v in receipts.items()}
    reviews = []
    for key, rows in (
        ("restoration", states["restoration"]["views"]),
        ("tails", states["tails"]["boards"]),
        ("main", states["main"]["rows"]),
        ("donors", states["donors"]["rows"]),
    ):
        for row in rows:
            if "displays" in row:
                images = [d["board"]["image"] for d in row["displays"]]
            else:
                images = [row[k]["image"] for k in ("board", "triplet")]
            for binding in images:
                checked(binding)
            reviews.append(
                {
                    "scope": key,
                    "id": row["id"],
                    "images": images,
                    "observations": (DONORS if key == "donors" else NOTES)[row["id"]],
                }
            )
    assert len(reviews) == 20
    plot = states["plot"]["image"]
    checked(plot)
    write_json(
        ROOT / "viewing.json",
        {
            "source": receipts,
            "visual_reviews": reviews,
            "viewed_plot": plot,
            "native_pixels_per_side": 160,
            "viewed_Bayer_profiles": ["nominal", "transferred"],
            "both_cab_JPEGs_viewed": True,
            "local_viewed_at": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(
                timespec="seconds"
            ),
        },
    )


if __name__ == "__main__":
    main()
