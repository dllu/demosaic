"""Freeze source-disjoint continuation/double-gap observations on external scratch."""

import argparse
from collections import Counter
from dataclasses import replace
import json
from pathlib import Path
import random

import numpy as np
import torch
from train_local_paired_continuation import BOX, FORWARD_ARGS, PROFILES, clean_crop, wire_pair

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene, sample_scene_recipe
from demosaic.scene_training_data import scene_seed

EXPERIMENTS = Path(".cache/experiments").absolute()
PREVIOUS = EXPERIMENTS / "green-covariance-refit-v1/plan.json"
SEED = 202611191624
ROLES = ("continuing", "double-gap", "exact-flat")


def source_ids(obj, values):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if (
                key in ("id", "source_id", "commons_id")
                and isinstance(value, str)
                and len(value) == 40
            ):
                values.add(value)
            elif (
                key in ("cache_sha256", "image_sha256")
                and isinstance(value, str)
                and len(value) == 64
            ):
                values.add(value)
            elif isinstance(value, (dict, list)):
                source_ids(value, values)
    elif isinstance(obj, list):
        for value in obj:
            source_ids(value, values)


def choose():
    controls = reference(PREVIOUS)
    earlier = read_json(checked(controls))
    references = [
        controls,
        earlier["rejected_full427"],
        earlier["excluded_prior_wires"],
        reference(EXPERIMENTS / "local-continuing-wire-v1/double-gap-inputs/panel.json"),
        reference(EXPERIMENTS / "local-wire-response-v1/wire-redraw-inputs/panel.json"),
        reference(EXPERIMENTS / "local-band-mixture-v1/plan.json"),
        reference("/mnt/external/demosaic/wire-blind-spot-v1/fresh/plan.json"),
    ]
    excluded = set()
    for ref in references:
        source_ids(read_json(checked(ref)), excluded)
    with checked(earlier["training_manifest"]).open() as stream:
        for line in stream:
            source_ids(json.loads(line), excluded)
    with checked(earlier["source_pool"]).open() as stream:
        candidates = [
            row
            for line in stream
            if (row := json.loads(line))["split"] == "val"
            and min(row["shape"][:2]) >= 256
            and row["id"] not in excluded
            and row["cache_sha256"] not in excluded
            and row["bin_factor"] == 4
        ]
    candidates.sort(key=lambda row: row["id"])
    assert len(candidates) > 64
    selection = random.Random(SEED).sample(candidates, 64)
    assert len({r["id"] for r in selection}) == len({r["cache_sha256"] for r in selection}) == 64
    return selection, references + [earlier["training_manifest"], earlier["source_pool"]]


def capture(root):
    torch.set_num_threads(2)
    chosen, source_refs = choose()
    root.mkdir(parents=True)
    sequence = [
        (iso, pattern) for iso in ("ISO400", "ISO6400") for pattern in PATTERNS for _ in range(8)
    ]
    random.Random(SEED + 1).shuffle(sequence)
    plan = root / "plan.json"
    write_json(
        plan,
        {
            "id": root.name,
            "seed": SEED,
            "source_exclusions": source_refs,
            "roles": ROLES,
            "source_schedule": [
                {"source": photo, "iso": iso, "pattern": cfa}
                for photo, (iso, cfa) in zip(chosen, sequence, strict=True)
            ],
            "driver": reference(__file__),
        },
    )
    rows = []
    for index, (source, (iso, pattern)) in enumerate(zip(chosen, sequence, strict=True)):
        rng = random.Random(scene_seed(SEED, index, "background"))
        patch, crop = clean_crop(source, rng)
        present, gap, geometry = wire_pair(patch, rng, pair_axis="strong")
        flat = patch[:, 128:129, 128:129].expand_as(patch).contiguous()
        shot, read = PROFILES[iso]
        profile = {"shot": shot, "read": read, "exposure": 0.33, "iso": iso}
        camera = replace(
            sample_scene_recipe(scene_seed(SEED, index, "camera")),
            pattern=pattern,
            black=0.03,
            shot=shot,
            read=read,
            exposure=profile["exposure"],
        )
        saved = []
        clean = None
        for redraw in range(2):
            seeds = {role: scene_seed(SEED, index, f"{redraw}:{role}") for role in ROLES}
            captures = [
                observe_scene(image, replace(camera, noise_seed=seeds[role])).crops([BOX])
                for image, role in zip((present, gap, flat), ROLES, strict=True)
            ]
            arrays = {
                key: torch.cat([r[key] for r in captures]).numpy()
                for key in (*FORWARD_ARGS, "target")
            }
            for key in ("colors", "wb", "matrix"):
                assert np.all(arrays[key] == arrays[key][0])
                arrays[key] = arrays[key][0]
            identity = fingerprint(arrays["target"])
            assert clean in (None, identity)
            clean = identity
            path = root / f"{index:02d}-{redraw}.npz"
            with path.open("xb") as handle:
                np.savez(handle, **arrays)
            saved.append(
                {
                    "arrays": reference(path),
                    "packed": fingerprint(arrays["packed"]),
                    "role_seeds": seeds,
                }
            )
        rows.append(
            {
                "source": source,
                "index": index,
                "crop": crop,
                "CFA": pattern,
                "geometry": geometry,
                "profile": profile,
                "camera": vars(camera),
                "draws": saved,
                "clean": clean,
            }
        )
        if index % 8 == 7:
            print(index + 1, flush=True)
    assert set(Counter((r["CFA"], r["profile"]["iso"]) for r in rows).values()) == {8}
    seeds = [seed for r in rows for d in r["draws"] for seed in d["role_seeds"].values()]
    assert len(set(seeds)) == len(seeds) == 384
    write_json(
        root / "panel.json",
        {
            "plan": reference(plan),
            "driver": reference(__file__),
            "rows": rows,
            "roles": ROLES,
            "scope": "Untuned 64 source reproducible held-out backgrounds.",
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    capture(parser.parse_args().root.absolute())
