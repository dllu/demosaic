"""Check the archived exterior nominations in the same fixed left-cab aperture."""

import math

import numpy as np
import torch

from camera_review import ROOT, compose, native_display, native_png, old_pixels, read_arrays, score_fixed

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

LABELS = {
    "fixed": "Fixed donor guide",
    "affine": "Affine refined donor",
    "innovation": "Innovation refined donor",
}


def nominated_study():
    torch.set_num_threads(2)
    main_ref = reference(ROOT / "camera-v2/result.json")
    main = read_json(checked(main_ref))
    old_root = ROOT.with_name("query-donor-composition-v1")
    probe_ref = reference(old_root / "probe.json")
    probe = read_json(checked(probe_ref))
    prior_ref = reference(old_root / "standing/manifest.json")
    prior = read_json(checked(prior_ref))
    assert prior["source"] == probe["source"]
    old_probes = {r["id"]: r for r in probe["rows"]}
    old_boards = {r["id"]: r for r in prior["rows"]}
    folder = ROOT / "camera-donors"
    folder.mkdir()
    rows = []
    for case in main["rows"]:
        ident = case["id"]
        if not ident.startswith("mesh-") or not ident.endswith("-left"):
            continue
        assert case["candidate_counts"] == 0
        previous = old_boards[ident]
        nominal = old_probes[ident]["probe"]["prior"]
        r = case["ROI_xywh"]
        assert case["input"] == previous["base_input"]
        assert case["fit_in_context"] == previous["box"] and r == previous["ROI"]
        assert all(previous["noise"][key] == case["noise"][key] for key in ("shot", "read"))
        source = read_arrays(case["input"])
        parent = np.load(checked(case["predictions_parent"]), allow_pickle=False)
        x, y, w, h = case["fit_in_context"]
        cut = np.s_[..., y:y+h, x:x+w]
        ps = np.s_[..., y//2:(y+h)//2, x//2:(x+w)//2]
        data = {k:source[k][0] for k in ("colors","wb","matrix")} | {"packed":source["packed"][ps]}
        base = parent[cut]
        deposits = {mode: np.zeros_like(base) for mode in LABELS}
        evidence = []
        for i in range(2):
            pair = (nominal[i], nominal[1-i])
            geometry = {
                "angles": [math.atan2(fy,fx) for fx,fy in pair],
                "periods": [1/math.hypot(fx,fy) for fx,fy in pair],
                "gap_center": (0.0,0.0), "gap_axes": (28.0,28.0), "gap_angle": 0.0,
            }
            decisions = {}
            for mode in LABELS:
                prediction = score_fixed(data,geometry,case["noise"],mode)
                renders,delivery = compose(data,base,{"geometry":geometry,"profile":case["noise"]},prediction)
                deposits[mode] += renders["placebo_shrinkage"] - base
                decisions[mode] = {"verification":prediction,"delivery":delivery["placebo_shrinkage"]}
            evidence.append({"frequency_xy": pair[0], "results":decisions, "geometry":geometry})
        rx,ry,rw,rh = r
        roi_tile = (rx-x,ry-y,rw,rh)
        sx,sy,sw,sh = roi_tile
        local = np.s_[..., sy:sy+sh, sx:sx+sw]
        changes = {k:float(np.sqrt(np.mean(v[local].astype(float)**2))*65535) for k,v in deposits.items()}
        with np.load(checked(previous["outputs"]),allow_pickle=False) as f:
            historical_parent = f["old"][None]
            historical_composed = f["composed"][None]
        displays = []
        for display in case["displays"]:
            exposure = display["exposure"]
            historical = old_pixels(display["board"])
            def rendered(value):
                return native_display(value,source,roi_tile,exposure)
            np.testing.assert_array_equal(rendered(base),historical["Aligned control"])
            if exposure == previous["display_exposure"]:
                old_panels = old_pixels(previous)
                np.testing.assert_array_equal(rendered(historical_composed),old_panels["With exterior and checked bands"])
            panels = [(label,historical[label]) for label in ("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Aligned control")]
            panels += [("Corpus 100k",rendered(historical_parent)),("Corpus 100k + earlier donor",rendered(historical_composed))]
            panels += [(label,rendered(base+deposits[k])) for k,label in LABELS.items()]
            panels += [(label,historical[label]) for label in ("ISO100 AHD reference","ISO100 camera JPEG")]
            board = native_png(folder / f"{ident}-donor-x{exposure:g}.png",panels)
            displays.append({"exposure":exposure,"board":board})
        rows.append({"id":ident,"input":case["input"],"raw":case["source"],"noise":case["noise"],
                     "native_box":case["native_box"],"ROI_xywh":r,"fit_in_context":case["fit_in_context"],
                     "rgb_RMS_DN16_vs_aligned":changes,"evidence":evidence,"displays":displays,
                     "historical_outputs":previous["outputs"]})
        print(ident,changes,flush=True)
    assert len(rows)==2
    write_json(folder / "result.json",{"driver":reference(__file__),"main":main_ref,"donor_probe":probe_ref,
        "historical_donor_delivery":prior_ref,"parent_checkpoints":{"aligned":main["matched_parent"],"older":prior["checkpoint"]},
        "scope":"Only the two empty left banks are supplemented. Use the archived RAW-only exterior pair, same exact aperture and existing gates. Independent camera references are visual.",
        "rows":rows})


if __name__ == "__main__":
    nominated_study()
