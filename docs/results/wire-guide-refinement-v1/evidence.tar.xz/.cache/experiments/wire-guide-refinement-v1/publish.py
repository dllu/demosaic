"""Publish bytes, crop provenance and reproducible receipts for the guide experiment."""

from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parents[2]
RESULT = BASE / "docs" / "results" / ROOT.name
IMAGES = BASE / "docs" / "images" / ROOT.name
EXTERNAL = Path("/mnt/external/demosaic") / ROOT.name
KEYS = {
    "fixed_guide": "exact.json",
    "rounded": "rounded.json",
    "radial": "radial.json",
    "isolation": "isolation.json",
    "delivery": "delivery/result.json",
    "tails": "tails/result.json",
    "camera": "camera-v2/result.json",
    "donors": "camera-donors/result.json",
    "plot": "plot.json",
    "viewing": "viewing.json",
}


def pixels(board):
    result = {}
    with Image.open(checked(board["image"])) as f:
        image = np.asarray(f.convert("RGB"))
    for panel in board["panels"]:
        x, y, w, h = panel["png_xywh"]
        assert (
            (w, h) == (160, 160)
            and 0 <= x
            and 0 <= y
            and x + w <= image.shape[1]
            and y + h <= image.shape[0]
        )
        result[panel.get("name", panel.get("label"))] = image[y : y + h, x : x + w]
    return result


def copy_board(board, group):
    path = checked(board["image"])
    dest = IMAGES / group / path.name
    dest.parent.mkdir(exist_ok=True)
    shutil.copyfile(path, dest)
    assert reference(dest)["sha256"] == board["image"]["sha256"]
    return board | {"image": board["image"] | {"path": str(dest.relative_to(IMAGES))}}


def exact_boards(rows, reviewed):
    result = []
    for row in rows:
        first, second = (pixels(row[k]) for k in ("board", "triplet"))
        assert list(second) == ["Noisy Malvar", "Innovation refinement", "Exact GT"]
        assert all(np.array_equal(first[k], v) for k, v in second.items())
        notes = reviewed[row["id"]]
        assert notes["images"] == [row[k]["image"] for k in ("board", "triplet")]
        result.append(
            row
            | {k: copy_board(row[k], "exact") for k in ("board", "triplet")}
            | {"viewing": notes["observations"]}
        )
    return result


def real_boards(rows, reviewed, group):
    updated = []
    for row in rows:
        notes = reviewed[row["id"]]
        assert notes["images"] == [d["board"]["image"] for d in row["displays"]]
        for d in row["displays"]:
            cells = pixels(d["board"])
            assert {"ISO100 AHD reference", "V120 EMA", "Aligned control"} <= cells.keys()
            if row["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= cells.keys()
        updated.append(
            row
            | {
                "viewing": notes["observations"],
                "displays": [d | {"board": copy_board(d["board"], group)} for d in row["displays"]],
            }
        )
    return updated


def main():
    bindings = {k: reference(ROOT / rel) for k, rel in KEYS.items()}
    docs = {k: read_json(checked(v)) for k, v in bindings.items()}
    packed = docs["delivery"]
    fresh = packed["panel"]
    assert all(docs[k]["panel"] == fresh for k in ("fixed_guide", "rounded", "radial"))
    assert packed["refinement"] == {
        "exact": bindings["fixed_guide"],
        "rounded": bindings["rounded"],
        "radial": bindings["radial"],
    }
    assert docs["plot"]["inputs"] == packed["refinement"]
    assert (
        docs["donors"]["main"] == bindings["camera"]
        and docs["tails"]["delivery"] == bindings["delivery"]
    )
    assert (
        docs["isolation"]["fresh"] == fresh
        and len(docs["isolation"]["evaluated_fold_interventions"]) == 16
    )
    panel = read_json(checked(fresh))
    parent = read_json(checked(packed["parent"]))
    assert parent["panel"] == fresh and len(parent["cases"]) == len(panel["rows"]) == 64
    assert packed["checkpoints"] == parent["checkpoints"]
    assert parent["checkpoints"]["aligned"] == docs["camera"]["matched_parent"]
    assert docs["donors"]["parent_checkpoints"]["aligned"] == docs["camera"]["matched_parent"]
    for role in parent["checkpoints"].values():
        checked(role)
    for source in ("fixed_guide", "rounded", "radial"):
        assert docs[source]["kernel"] == reference(BASE / "src/demosaic/heldout_wire_frequency.py")
    view = docs["viewing"]
    assert view["source"] == {
        name: bindings[key]
        for name, key in (
            ("restoration", "delivery"),
            ("tails", "tails"),
            ("main", "camera"),
            ("donors", "donors"),
            ("plot", "plot"),
        )
    }
    notes = {k: {} for k in ("restoration", "tails", "main", "donors")}
    for row in view["visual_reviews"]:
        notes[row["scope"]][row["id"]] = row

    IMAGES.mkdir()
    RESULT.mkdir()
    delivery = exact_boards(packed["views"], notes["restoration"])
    tails = exact_boards(docs["tails"]["boards"], notes["tails"])
    camera = real_boards(docs["camera"]["rows"], notes["main"], "standing")
    donors = real_boards(docs["donors"]["rows"], notes["donors"], "donors")
    assert (len(delivery), len(tails), len(camera), len(donors)) == (8, 2, 8, 2)
    assert sum(len(r["displays"]) for r in camera) == 12
    assert sum(len(r["displays"]) for r in donors) == 4
    plot = checked(view["viewed_plot"])
    shutil.copyfile(plot, IMAGES / plot.name)
    manifest = IMAGES / "manifest.json"
    write_json(
        manifest,
        {
            "source_bindings": bindings,
            "exact": delivery,
            "adverse_gaps": tails,
            "standing": camera,
            "left_exterior_donors": donors,
            "decision_chart": view["viewed_plot"] | {"path": plot.name},
            "viewing": bindings["viewing"],
            "weights": parent["checkpoints"],
        },
    )

    previous = ROOT.with_name("wire-blind-spot-v1")
    dependencies = [
        *[
            previous / name
            for name in ("diagnose.py", "verifier.py", "estimated_phase.py", "deliver.py")
        ],
        ROOT.with_name("paired-luminance-detail-v1") / "render.py",
        *[
            BASE / "scripts" / name
            for name in ("report_scene_wave_guides.py", "train_local_paired_continuation.py")
        ],
        BASE / "src/demosaic/heldout_wire_frequency.py",
        BASE / "tests/test_heldout_wire_frequency.py",
        BASE / "configs/gfx-qualitative-20231231.json",
        BASE / "configs/gfx-green-mesh-20231231.json",
    ]
    scripts = [
        ROOT / name
        for name in (
            "capture.py",
            "parents.py",
            "evaluate.py",
            "restore_evaluate.py",
            "audit.py",
            "camera_review.py",
            "camera_donors.py",
            "tails.py",
            "review_assets.py",
            "review_record.py",
            "publish.py",
        )
    ]
    supplemental = [
        fresh,
        panel["plan"],
        packed["parent"],
        reference(manifest),
        docs["camera"]["proposal_source"],
        docs["camera"]["prior_native"],
        docs["camera"]["configured_refs"],
        docs["camera"]["fixed_replay"],
        docs["donors"]["donor_probe"],
        docs["donors"]["historical_donor_delivery"],
    ]
    bundle = RESULT / "evidence.tar.xz"
    with tarfile.open(bundle, "x:xz", preset=4) as tar:
        inputs = [
            *bindings.values(),
            *supplemental,
            *(reference(p) for p in (*scripts, *dependencies)),
        ]
        for binding in {p["path"]: p for p in inputs}.values():
            p = checked(binding)
            arc = (
                p.relative_to(BASE)
                if p.is_relative_to(BASE)
                else Path("external") / p.relative_to(EXTERNAL)
            )
            tar.add(p, arcname=arc)
    scopes = {
        "observations": len(panel["rows"]),
        "noise_draws_per_role": 2,
        "held_out_by_source": True,
        "training": "Frozen EMA weights",
        "numerical_replay": "Complete",
        "native_review": "Complete",
        "full427_known_unseen": "Outside this scoped inference experiment",
        "camera": "Reused RAW-only nominations and prior externally nominated pair in the two left views",
    }
    write_json(
        RESULT / "publication.json",
        {
            "study": ROOT.name,
            "scope": scopes,
            "weights": parent["checkpoints"],
            "aligned_foundation": parent["base_corpus_100k"],
            "policy": parent["policy"],
            "inputs": bindings,
            "synthetic_panel": fresh,
            "parent_receipt": packed["parent"],
            "elapsed_seconds": {
                "raw_scores": {
                    docs[k]["guide"]: docs[k]["seconds"]
                    for k in ("fixed_guide", "rounded", "radial")
                },
                "parent_FP32_replay": parent["seconds"],
                "bounded_delivery": packed["seconds"],
            },
            "raw_summaries": {
                docs[k]["guide"]: docs[k]["results"] for k in ("fixed_guide", "rounded", "radial")
            },
            "output_scores": packed["summary"],
            "camera_correction_DN16": {r["id"]: r["rgb_RMS_DN16"] for r in docs["camera"]["rows"]},
            "left_exterior_donors_RMS_DN16": {
                r["id"]: r["rgb_RMS_DN16_vs_aligned"] for r in docs["donors"]["rows"]
            },
            "manifest": reference(manifest),
            "evidence": reference(bundle),
        },
    )
    print(
        "Published 8 true-continuation boards, 2 exact gaps and 16 native camera boards", flush=True
    )


if __name__ == "__main__":
    main()
