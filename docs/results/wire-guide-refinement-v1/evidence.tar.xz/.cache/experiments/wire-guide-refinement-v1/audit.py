"""Check the old exact-guide control and perturb the held-out sensor values."""

import numpy as np
import torch

import estimated_phase
from evaluate import FRESH, ROOT, guide_for, inspect, templates

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

INVARIANT = (
    "outside_amplitude",
    "outside_z",
    "blend",
    "learned",
    "waveform",
    "refinement",
    "scored_pixels",
    "prediction_fingerprint",
    "influence_fingerprint",
)


def maximum_score_difference(old, new):
    error = 0.0
    for old_role, new_role in zip(old["roles"], new["roles"], strict=True):
        for a, b in zip(old_role, new_role, strict=True):
            for k in a["amplitude"]:
                error = max(error, abs(a["amplitude"][k] - b["amplitude"][k]))
            for k in ("outside_amplitude", "outside_z"):
                error = max(error, abs(a[k] - b[k]))
    return error


def main():
    torch.set_num_threads(1)
    fresh = reference(FRESH)
    panel = read_json(checked(fresh))
    samples = [r for iso in ("ISO400", "ISO6400") for r in
               [row for row in panel["rows"] if row["profile"]["iso"]==iso][:2]]
    checks = []
    for case in samples:
        capture = case["draws"][0]["arrays"]
        with np.load(checked(capture), allow_pickle=False) as data:
            arrays = dict(data)
        profile = case["profile"]
        old = estimated_phase.inspect(arrays, case, profile)
        fixed = inspect(arrays, case, profile, guide_for(case, "exact"), "fixed")
        control_difference = maximum_score_difference(old, fixed)
        assert control_difference <= 1e-9, control_difference
        guide = guide_for(case, "rounded")
        y, x = np.indices(arrays["packed"].shape[-2:])
        _, _, radii = templates(case["geometry"], tuple(2 * n for n in y.shape))
        for mode in ("affine", "innovation"):
            original = inspect(arrays, case, profile, guide, mode)
            altered_target = inspect(
                arrays | {"target": arrays["target"] * 0.8 + 0.001}, case, profile, guide, mode
            )
            for lhs, rhs in zip(original["roles"], altered_target["roles"], strict=True):
                for same, different in zip(lhs, rhs, strict=True):
                    assert all(same[key] == different[key] for key in INVARIANT)
                    assert all(value == different["amplitude"][k]
                               for k, value in same["amplitude"].items() if k != "exact_background")

            for fold in (0, 1):
                mask = ((radii < 1) & (((x + y) % 2)[..., None] == fold)).transpose(2, 0, 1)
                perturbed = arrays["packed"].copy()
                perturbed[:, mask] = 0.75 - 0.5 * perturbed[:, mask]
                replay = inspect(arrays | {"packed": perturbed}, case, profile, guide, mode)
                for lhs, rhs in zip(original["roles"], replay["roles"], strict=True):
                    same, different = lhs[fold], rhs[fold]
                    assert all(same[key] == different[key] for key in INVARIANT)
                    assert same["amplitude"] != different["amplitude"]
                checks.append({
                    "input": capture, "source": case["source"]["id"], "mode": mode,
                    "fold": fold, "modified_sites_per_role": int(mask.sum()),
                    "old_fixed_control_max_abs_score_difference": control_difference,
                })
    write_json(ROOT / "isolation.json", {
        "fresh": fresh, "driver": reference(__file__), "checked_prediction_fields": INVARIANT,
        "evaluated_fold_interventions": checks, "operational_invariance_to_target": True,
        "scope": "Same-fold observations replaced only inside the aperture. Both tones, frequencies, amplitude predictions, and contrasts remain fixed. Exterior same-parity placebos and training at other sites, then the opposite fold, still use the raw frame.",
    })
    print(len(checks), "fold interventions with the raw score changing", flush=True)


if __name__ == "__main__":
    main()
