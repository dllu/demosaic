"""Score bounded delivery after each matched exterior-frequency comparison."""

from collections import defaultdict
from pathlib import Path
import time

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from report_scene_wave_guides import native_board
from evaluate import FRESH, METHODS, ROOT
from deliver import compose, read_arrays, scores

PARENT = FRESH.parents[1] / "parent-v2/completed.json"
GUIDES = ("exact", "rounded", "radial")
NAMES = {
    "v120": "V120 EMA",
    "aligned": "Aligned control",
    "fixed": "Fixed guide",
    "affine": "Affine refinement",
    "innovation": "Innovation refinement",
}


def bands(panel, case, draw, parents, conditions, guide):
    record = parents["draws"][draw]
    source = case["draws"][draw]["arrays"]
    assert record["input"] == source
    data = read_arrays(source)
    parent = read_arrays(record["outputs"])
    outputs = {}
    deltas = {}
    for method in METHODS:
        nominal = conditions["rows"][case["index"]]
        det = nominal["methods"][method][draw]
        variations, decision = compose(data, parent["aligned"], case, det)
        outputs[method] = variations["placebo_shrinkage"]
        deltas[method] = decision["placebo_shrinkage"]
    return data, parent | outputs, deltas


def summary(rows):
    keys = tuple(rows[0]["scores"]["aligned"])
    labels = tuple(rows[0]["scores"])
    a = np.asarray([[[r["scores"][m][k] for k in keys] for m in labels] for r in rows])
    generator = np.random.default_rng(202611191634)
    ix = np.vstack((np.arange(len(rows)), generator.integers(len(rows), size=(6500, len(rows)))))
    field = a[ix].mean(1)
    table = {
        m: dict(zip(keys, row.tolist(), strict=True))
        for m, row in zip(labels, field[0], strict=True)
    }
    comparisons = {}
    for variant in ("affine", "innovation"):
        for control in ("aligned", "fixed"):
            column = field[:, labels.index(variant)] - field[:, labels.index(control)]
            comparisons[variant + " vs " + control] = {
                k: {
                    "delta": float(x[0]),
                    "source_bootstrap_95": np.quantile(x, (0.025, 0.975)).tolist(),
                }
                for k, x in zip(keys, column.T, strict=True)
            }
    return {"sources": len(rows), "values": table, "comparisons": comparisons}


def render(panel, conditions, parent, rows, folder):
    boards = []
    for guide in ("rounded", "radial"):
        for iso in ("ISO400", "ISO6400"):
            candidates = [r for r in rows[guide] if r["ISO"] == iso]
            key = "continuing_gap_RMS_DN16"
            ranked = sorted(
                candidates, key=lambda r: r["scores"]["innovation"][key] - r["scores"]["fixed"][key]
            )
            for direction, row in (("best", ranked[0]), ("worst", ranked[-1])):
                case = panel["rows"][row["index"]]
                restored = parent["cases"][case["index"]]
                assert restored["source"] == case["source"]["id"]
                draws = []
                for i in (0, 1):
                    arrays, predictions, _ = bands(
                        panel, case, i, restored, conditions[guide], guide
                    )
                    frame = {
                        m: scores([values], arrays["target"], case, arrays)
                        for m, values in predictions.items()
                    }
                    change = frame["innovation"][key] - frame["fixed"][key]
                    draws.append((change, i, arrays, predictions, frame))
                selected = (
                    min(draws, key=lambda d: d[0])
                    if direction == "best"
                    else max(draws, key=lambda d: d[0])
                )
                change, i, arrays, predictions, frame = selected
                camera = {k: arrays[k][None] for k in ("wb", "matrix", "colors")} | {
                    "packed": arrays["packed"][:1]
                }
                v = (
                    noisy_malvar(camera)[0],
                    *(predictions[label][0] for label in NAMES),
                    arrays["target"][0],
                )
                board = native_board(
                    folder,
                    f"{guide}-{iso}-{direction}-{case['index']:02d}-draw{i}",
                    v,
                    camera,
                    dict(
                        source=case["source"],
                        roi=case["crop"],
                        input=case["draws"][i]["arrays"],
                        recipe=case["profile"],
                        checkpoints=parent["checkpoints"],
                        output_error_change=change,
                        scores=frame,
                        guide=conditions[guide]["rows"][case["index"]]["provided"],
                    ),
                    labels=("Noisy Malvar", *NAMES.values(), "Exact GT"),
                    triplet_indices=(0, 5, 6),
                    exposure=2,
                    roi=(48, 48, 160, 160),
                )
                boards.append(board)
    return boards


def main():
    torch.set_num_threads(2)
    parent_ref = reference(PARENT)
    parent = read_json(checked(parent_ref))
    panel_ref = reference(FRESH)
    assert parent["panel"] == panel_ref
    panel = read_json(checked(panel_ref))
    verification = {name: reference(ROOT / (name + ".json")) for name in GUIDES}
    states = {name: read_json(checked(p)) for name, p in verification.items()}
    assert all(d["panel"] == panel_ref for d in states.values())
    folder = ROOT / "delivery"
    folder.mkdir()
    evaluated = {}
    summaries = {}
    start = time.monotonic()
    for guide in GUIDES:
        rows = []
        for case, restored in zip(panel["rows"], parent["cases"], strict=True):
            assert (
                restored["source"]
                == case["source"]["id"]
                == states[guide]["rows"][case["index"]]["source"]
            )
            all_predictions = defaultdict(list)
            delivery = []
            for draw in (0, 1):
                data, predictions, deltas = bands(panel, case, draw, restored, states[guide], guide)
                for label, p in predictions.items():
                    all_predictions[label].append(p)
                delivery.append(deltas)
            rows.append(
                {
                    "source": restored["source"],
                    "index": case["index"],
                    "ISO": case["profile"]["iso"],
                    "scores": {
                        k: scores(v, data["target"], case, data) for k, v in all_predictions.items()
                    },
                    "delivery": delivery,
                }
            )
            if len(rows) % 16 == 0:
                print(guide, len(rows), round(time.monotonic() - start, 2), flush=True)
        evaluated[guide] = rows
        summaries[guide] = {
            iso: summary([r for r in rows if r["ISO"] == iso]) for iso in ("ISO400", "ISO6400")
        }
    crops = render(panel, states, parent, evaluated, folder)
    write_json(
        folder / "result.json",
        {
            "parent": parent_ref,
            "panel": panel_ref,
            "refinement": verification,
            "driver": reference(__file__),
            "views": crops,
            "summary": summaries,
            "rows": evaluated,
            "checkpoints": parent["checkpoints"],
            "seconds": time.monotonic() - start,
            "scope": "Single-frame bounded inference using supplied apertures and the same "
            "native-domain RAW verifier for all guide conditions.",
        },
    )


if __name__ == "__main__":
    main()
