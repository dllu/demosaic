"""Publish trained heads, matched native crops, and source-bound redraw receipts."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import HERE, OUT

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "plan",
    "audit",
    "audit-evaluation",
    "preflight/completed",
    "fit-preflight/result",
    "training/completed",
    "fit-training/result",
    "calibration/completed",
    "held/completed",
    "score-calibration",
    "score-held",
    "review-natural",
    "review-camera",
    "review-wire",
    "stress-stronger",
    "matched-held",
)
OTHER_SOURCES = {
    "direct-detail-response-v1": (
        "direct_detail.py",
        "train_direct.py",
        "collect_direct.py",
        "evaluate_direct.py",
        "audit_sources.py",
    ),
    "scene-detail-selector-v1": (
        "detail_selector.py",
        "collect_training.py",
        "benchmark_shared_local_encoding.py",
        "evaluate_selector.py",
        "review_selector.py",
        "train_selector.py",
    ),
    "context-conditioned-detail-v1": ("context_gate.py", "mild_score.py", "score.py", "capture.py"),
    "scene-local-contrast-2400-v1": ("prepare_eval.py",),
}


def bind(file):
    return reference(file) | {"path": str(file.relative_to(ROOT))}


def title_plot(held):
    labels = {
        "plain": ("Direct loss control", "#4477aa"),
        "shared": ("Shared-error loss", "#ee7733"),
        "stable": ("Redraw-stability loss", "#228833"),
        "prior-signed": ("Previous response (recalibrated)", "#aa3377"),
        "heuristic": ("Earlier whole-photo gate", "#555555"),
    }
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), layout="constrained")
    result, curves = held["scores"], held["scaled_curves_diagnostic_only"]
    parent = result["nominal"]
    for axis, metric, label in zip(
        axes, ("increment", "flat"), ("Paired-increment error", "Exact-flat error"), strict=True
    ):
        for name, (method, color) in labels.items():
            x = [g["scores"][metric] - parent[metric] for g in curves[name]]
            y = [g["scores"]["response_pp"] - parent["response_pp"] for g in curves[name]]
            axis.plot(x, y, color=color, linewidth=1.4, label=method)
            axis.scatter(
                result[name][metric] - parent[metric],
                result[name]["response_pp"] - parent["response_pp"],
                color=color,
                s=24,
                zorder=4,
            )
        axis.axvline(0, color="#999", linestyle=":")
        axis.axvline(0.1 if metric == "increment" else 0.05, color="#303030", linestyle="--")
        axis.axhline(0, color="#999", linestyle=":")
        axis.set_title(label)
        axis.set_xlabel("RMS difference from Local 50k (DN16)")
    axes[0].set_ylabel("Fine-contrast response gain (percentage points)")
    axes[1].legend(fontsize=7.5, frameon=False)
    path = ASSETS / "response-error.png"
    fig.savefig(path, dpi=160)
    return bind(path)


def copy_native(data):
    src = checked(data["image"])
    destination = ASSETS / src.name
    shutil.copyfile(src, destination)
    ref = bind(destination)
    assert ref["sha256"] == data["image"]["sha256"]
    with Image.open(destination) as p:
        for r in data["panels"]:
            x, y, w, h = r["png_xywh"]
            assert w == h == 160 and x + w <= p.width and y + h <= p.height
    return data | {"image": ref}


def collect_receipts(items, refs, book):
    plan = items["plan"]
    assert items["audit"]["plan"] == refs["plan"]
    assert items["audit"]["coefficients"]["source"] == refs["preflight/completed"]
    assert items["audit-evaluation"]["scorer"] == items["score-held"]["driver"]
    assert items["score-held"]["calibration"] == refs["score-calibration"]
    assert items["matched-held"]["source"] == refs["score-held"]
    for mode in ("preflight", "training", "calibration", "held"):
        completed = items[f"{mode}/completed"]
        assert completed["plan"] == refs["plan"]
        count = len(plan["cases"][mode])
        assert count == completed["source_count"]
        src = []
        for idx, item in enumerate(completed["stats"]):
            d = read_json(checked(item))
            assert d["plan"] == refs["plan"]
            src.extend(d["samples"])
            book[f"chunks/{mode}/{idx:03}.json"] = item
            if "data" in d:
                checked(d["data"])
            for x in d["samples"]:
                assert len(set(x["role_seeds"])) == 6
                for f in x.get("draws", []):
                    checked(f)
        assert len(src) == count
        for x, expected in zip(src, plan["cases"][mode], strict=True):
            assert x["source"]["id"] == expected["id"]
            assert x["cache"]["sha256"] == expected["cache_sha256"]
        if mode in ("calibration", "held"):
            scored = items[f"score-{mode}"]
            assert scored["source"] == refs[f"{mode}/completed"] and len(scored["rows"]) == count
            for x, expected in zip(src, scored["rows"], strict=True):
                assert x["id"] == expected["id"] and x["draws"] == expected["draws"]
    for name in ("calibration", "held"):
        assert items[f"score-{name}"]["fit"] == refs["fit-training/result"]
    for name in ("wire", "natural", "camera"):
        r = items[f"review-{name}"]
        assert (
            r["fit"] == refs["fit-training/result"]
            and r["calibration"] == refs["score-calibration"]
        )
    assert items["stress-stronger"]["calibration"] == refs["score-calibration"]
    assert items["stress-stronger"]["fit"] == refs["fit-training/result"]
    assert items["review-natural"]["report"]["evidence"] == refs["score-held"]
    for mode in ("preflight", "training"):
        train = items[f"fit-{mode}/result"]
        assert (
            train["collection"] == refs[f"{mode}/completed"] and train["prior_head"] == plan["init"]
        )
        for k, w in train["checkpoints"].items():
            book[f"checkpoints/{mode}/{k}.pt"] = w


def main():
    refs = {k: reference(OUT / (k + ".json")) for k in RECEIPTS}
    items = {k: read_json(checked(ref)) for k, ref in refs.items()}
    for data in items.values():
        checked(data["driver"]) if "driver" in data else None
    book = {f"receipts/{k}.json": v for k, v in refs.items()}
    collect_receipts(items, refs, book)
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    natural = items["review-natural"]["report"]["rows"]
    camera = items["review-camera"]["report"]["rows"]
    assert len(natural) == 2 and sum(len(r["native"]) for r in camera) == 12
    for r in natural:
        r["frames"] = {k: copy_native(d) for k, d in r["frames"].items()}
    for r in camera:
        for view in r["native"]:
            tags = {s["label"] for s in view["panels"]}
            assert "ISO100 AHD reference" in tags
            if r["id"].startswith("mesh-"):
                assert {"ISO100 camera JPEG", "ISO6400 camera JPEG"} <= tags
        r["native"] = [copy_native(d) for d in r["native"]]
    fit = items["fit-training/result"]
    final = items["score-held"]["results"]
    plot = title_plot(final)
    summary = RESULTS / "summary.json"
    write_json(
        summary,
        {
            "scope": "Fine-detail calibration, held-out redraw and crop component study",
            "training": {k: v for k, v in fit.items() if k != "logs"},
            "collection_seconds": items["training/completed"]["seconds"],
            "coverage": items["audit"]["coverage"],
            "calibration": items["score-calibration"]["results"]["scores"],
            "evaluation": {k: v for k, v in final.items() if k != "scaled_curves_diagnostic_only"},
            "camera": {r["id"]: r["RGB_RMS_change_DN16"] for r in camera},
            "wire": items["review-wire"]["report"]["summary"],
            "stress_stronger": items["stress-stronger"]["scores"],
            "matched": items["matched-held"]["results"],
        },
    )
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {
            "weights": fit["checkpoints"],
            "parent": items["plan"]["parent"],
            "v120": items["plan"]["v120"],
            "prior_head": items["plan"]["init"],
            "natural": natural,
            "camera": camera,
            "plot": plot,
            "doses": final["doses"],
        },
    )
    for name in sorted(HERE.glob("*.py")):
        book[f"source/{name.name}"] = reference(name)
    for folder, files in OTHER_SOURCES.items():
        for name in files:
            book[f"source/previous/{folder}/{name}"] = reference(HERE.with_name(folder) / name)
    for name in ("configs/gfx-qualitative-20231231.json", "configs/gfx-green-mesh-20231231.json"):
        book[name] = reference(ROOT / name)
    bundle = RESULTS / "evidence.tar.xz"
    with tarfile.open(bundle, "x:xz", preset=4) as tar:
        for name, ref in book.items():
            tar.add(checked(ref), arcname=name, recursive=False)
    with tarfile.open(bundle) as tar:
        assert set(tar.getnames()) == book.keys()
        for name, ref in book.items():
            with tar.extractfile(name) as stream:
                assert file_digest(stream, "sha256").hexdigest() == ref["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "scope": "Source-bound paired redraw crop component evidence",
            "archive": bind(bundle),
            "members": book,
            "summary": bind(summary),
            "native": bind(manifest),
            "weights": fit["checkpoints"],
        },
    )
    print(bind(bundle), flush=True)


if __name__ == "__main__":
    main()
