"""Verify two-redraw evaluation against the established one-draw scorer."""

from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import OUT, base
from score_redraw import components, fine_luma, pack, values, RMS
from evaluate_direct import weights
from evaluate_selector import deltas, values as prior_values
from train_direct import gain
import mild_score as fixed
import score


def main():
    torch.set_num_threads(2)
    receipt = reference(base.OUT / "faint-recapture/completed.json")
    row = read_json(checked(receipt))["rows"][0]
    binding, nets, _ = weights()
    net, norm = nets["signed-response"]
    with np.load(checked(row["panel"]), allow_pickle=False) as raw:
        d = {k: raw[k] for k in raw.files}
    x, s, c, fields, _ = base.local(d, d, row["profile"])
    with torch.no_grad():
        g = gain(net, *(torch.from_numpy(v) for v in (x, s, c)), norm)
        shift = deltas(fields, g)
    anchor, target = (base.old.luma(v, d) for v in (d["nominal"], d["target"]))
    made = [fine_luma(value) for value in (anchor, target, shift)]
    repeated = [np.stack([x, x]) for x in made]
    pair = components(*repeated)
    t, a = (score.stats(d[k], d) for k in ("target", "nominal"))
    old = fixed.terms(t, a, fixed.coefficients(shift[:, 0]), fixed.coefficients(shift[:, 1]))
    absolute = {}
    dose = (0.7, 0.2)
    first = values(pack([{"scores": {"only": pair}}], "only"), dose)
    old_score = prior_values([{"scores": {"only": old}}], "only", dose)
    for k in score.LIMITS:
        actual, expected = np.sqrt(first[k]), old_score[k]
        np.testing.assert_allclose(actual, expected, rtol=4e-7, atol=2e-6)
        absolute[k] = float(np.max(np.abs(actual - expected)))
    np.testing.assert_allclose(
        first["response"] / first["truth"], old_score["projection"] / old_score["true"], rtol=4e-7
    )
    assert first["flat_redraw"] == first["redraw"] == 0
    draws = np.random.default_rng(22222).uniform(0, 1, size=(2, 3, 2, 36))
    nominal = np.random.default_rng(22223).uniform(0, 1, size=(2, 3, 36))
    target = np.broadcast_to(nominal[0], nominal.shape)
    inc = components(nominal, target, draws)
    swapped = components(nominal[::-1], target, draws[::-1])
    for k in (*RMS, "truth", "response"):
        np.testing.assert_allclose(inc[k], swapped[k], rtol=0, atol=3e-14)
    write_json(
        OUT / "audit-evaluation.json",
        {
            "driver": reference(Path(__file__)),
            "scorer": reference(Path(components.__code__.co_filename)),
            "source": receipt,
            "panel": row["panel"],
            "previous_fit": binding,
            "absolute_difference_DN16": absolute,
            "duplicate_redraw_has_zero_variance": True,
            "swapping_redraws_preserves_metrics": True,
        },
    )
    print(absolute, flush=True)


if __name__ == "__main__":
    main()
