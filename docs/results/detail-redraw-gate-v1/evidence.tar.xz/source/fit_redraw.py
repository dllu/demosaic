"""Train matched signed-response gates from the same frozen checkpoint and redraws."""

from time import monotonic
import sys

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import HERE, OUT, STUDY, EXTRA_WEIGHT, base, loss
from train_direct import gain, observations

UPDATES = 1400
BATCH = 48
LR = 5e-4
EMA = 0.993
SEED = 202611200936


def fit(mode):
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    collection = reference(OUT / mode / "completed.json")
    plan = read_json(checked(read_json(checked(collection))["plan"]))
    init = torch.load(checked(plan["init"]), map_location="cpu", weights_only=True)
    data = observations(collection)
    normal = {k: {m: s.cuda() for m, s in v.items()} for k, v in init["normal"].items()}
    nets = {name: base.Head(True).cuda() for name in STUDY}
    averages = {name: base.Head(True).cuda().requires_grad_(False) for name in STUDY}
    for net in (*nets.values(), *averages.values()):
        net.load_state_dict(init["ema"])
    optimizers = {
        name: torch.optim.AdamW(net.parameters(), lr=LR, weight_decay=1e-4)
        for name, net in nets.items()
    }
    count = len(data["base"])
    batch = min(BATCH, count)
    steps = 5 if mode == "preflight" else UPDATES
    root = OUT / f"fit-{mode}"
    root.mkdir(exist_ok=True)
    log = {}
    rng = torch.Generator().manual_seed(SEED)
    started = monotonic()
    for i in range(1, steps + 1):
        selected = torch.randint(count, (batch,), generator=rng).cuda()
        sample = {k: v[selected] for k, v in data.items()}
        for name, net in nets.items():
            optimizer = optimizers[name]
            optimizer.zero_grad(set_to_none=True)
            g = gain(net, sample["base"], sample["signed"], sample["support"], normal)
            value = loss(g, sample, name)
            assert torch.isfinite(value)
            value.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1)
            optimizer.step()
            with torch.no_grad():
                torch._foreach_lerp_(
                    list(averages[name].parameters()), list(net.parameters()), 1 - EMA
                )
        if i in (1, steps) or i % 100 == 0:
            row = {}
            with torch.no_grad():
                for name, net in nets.items():
                    g = gain(net, sample["base"], sample["signed"], sample["support"], normal)
                    row[name] = {k: loss(g, sample, k).item() for k in STUDY}
            log[i] = row
            print(i, round(monotonic() - started, 2), row, flush=True)
    checkpoints = {}
    for name, net in nets.items():
        target = root / f"{name}.pt"
        draft = target.with_suffix(".partial")
        weights = {
            "raw": {k: v.cpu() for k, v in net.state_dict().items()},
            "ema": {k: v.cpu() for k, v in averages[name].state_dict().items()},
            "normal": init["normal"],
            "optimizer": optimizers[name].state_dict(),
            "source": collection,
            "prior_head": plan["init"],
            "seed": SEED,
            "rng": rng.get_state(),
            "mode": name,
            "with_signed": True,
            "updates": steps,
        }
        torch.save(weights, draft)
        draft.replace(target)
        ref = reference(target)
        saved = torch.load(checked(ref), weights_only=True, map_location="cpu")
        assert saved["source"] == collection and saved["updates"] == steps
        for key in saved["ema"]:
            assert torch.equal(saved["ema"][key], weights["ema"][key])
        checkpoints[name] = ref
    write_json(
        root / "result.json",
        {
            "driver": reference(__file__),
            "operator": reference(HERE / "redraw_gate.py"),
            "prior_head": plan["init"],
            "collection": collection,
            "checkpoints": checkpoints,
            "logs": log,
            "seconds": monotonic() - started,
            "source_count": count,
            "updates": steps,
            "batch": batch,
            "unique_role_examples": count * 6,
            "role_visits_per_arm": steps * batch * 6,
            "response_weight": base.RESP_PULL,
            "extra_weight": EXTRA_WEIGHT,
            "learning_rate": LR,
            "ema_decay": EMA,
        },
    )


if __name__ == "__main__":
    fit(sys.argv[1])
