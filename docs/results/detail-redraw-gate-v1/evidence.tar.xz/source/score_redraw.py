"""Evaluate repeated natural exposures with a calibration-only error budget."""

from itertools import product
from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import HERE, OUT, STUDY, base
from evaluate_direct import fixed_heuristic
from evaluate_selector import deltas
from train_direct import gain
import mild_score as fixed
import score

PRIOR = "prior-signed"
ARMS = (*STUDY, PRIOR)
DISPLAY = {
    "nominal": "Local 50k EMA",
    "v120": "V120 EMA",
    "heuristic": "Earlier whole-photo gate",
    "prior-signed": "Previous signed response",
    "plain": "Direct loss control",
    "shared": "Shared-error loss",
    "stable": "Redraw-stability loss",
}
RMS = ("increment", "present", "flat", "shared", "redraw", "flat_redraw", "flat_shared")
GRID = tuple(round(v, 3) for v in np.linspace(0, 1, 21))
OVERVIEW = fixed.OUT / "mild-calibration.json"


def models():
    trained = reference(OUT / "fit-training/result.json")
    fit = read_json(checked(trained))
    stored = {}
    for name, stamp in (fit["checkpoints"] | {PRIOR: fit["prior_head"]}).items():
        net = base.Head(True)
        src = torch.load(checked(stamp), map_location="cpu", weights_only=True)
        net.load_state_dict(src["ema"])
        stored[name] = (net.eval(), src["normal"])
    return trained, stored


def inputs(stamp):
    done = read_json(checked(stamp))
    for step in done["stats"]:
        chunk = read_json(checked(step))
        assert chunk["plan"] == done["plan"]
        for row in chunk["samples"]:
            samples = []
            for file in row["draws"]:
                with np.load(checked(file), allow_pickle=False) as d:
                    preds = {k: d[k] for k in ("crisp", "nominal", "smooth", "v120")}
                    inputs = {k: d[k] for k in d.files if k not in preds}
                samples.append((inputs, preds))
            samples[1][0]["scene_packed"] = samples[0][0]["scene_packed"]
            yield row, samples


@torch.no_grad()
def fields(meta, pred, profile, nets):
    ordinary, signed, cap, basis, neutral = base.local(meta, pred, profile)
    x, s, c = (torch.from_numpy(v) for v in (ordinary, signed, cap))
    moves = {name: deltas(basis, gain(net, x, s, c, z)) for name, (net, z) in nets.items()}
    return moves, neutral


def render(meta, pred, row, nets, doses, earlier):
    corrections, neutral = fields(meta, pred, row["profile"], nets)
    actual = {
        k: (pred["nominal"] + np.einsum("nchw,c,k->nkhw", d, doses[k], neutral)).astype(
            pred["nominal"].dtype
        )
        for k, d in corrections.items()
    }
    if earlier is not None:
        actual["heuristic"] = fixed_heuristic(meta, pred, row, earlier)
    return dict(pred, **actual)


def expansions(terms):
    # Linear and quadratic coefficients for the two fixed proposal strengths.
    # The leading dimension is (nominal, sharper contribution, smoother contribution).
    a, b, c = terms.reshape(3, -1)
    return [float(x) for x in (a @ a, 2 * (a @ b), 2 * (a @ c), b @ b, 2 * (b @ c), c @ c)]


def fine_luma(v):
    return base.fine(v[base.CENTER]).astype(np.float64) * (65535 / 96)


def components(anchor, target, branch):
    # Draw, role, branch, frequency. The weak target and score mask match across draws.
    exact = target[0, 0] - target[0, 1]
    norm = np.linalg.norm(exact)
    unit = exact / max(norm, 1e-12)
    raw = np.concatenate((anchor[:, :, None, :], branch), axis=2)
    error = raw.copy()
    error[:, :, 0] -= target
    pair = error[:, 0] - error[:, 1]
    restored = raw[:, 0] - raw[:, 1]
    off = pair - (pair @ unit)[..., None] * unit
    average = lambda states: states.mean(0)
    halfdiff = lambda states: (states[0] - states[1]) / 2
    fold = lambda states: states.transpose(1, 0, 2) / np.sqrt(2)
    return {
        "increment": expansions(fold(pair)),
        "present": expansions(fold(error[:, 0])),
        "flat": expansions(fold(error[:, 2])),
        "shared": expansions(average(off)),
        "redraw": expansions(halfdiff(off)),
        "flat_redraw": expansions(halfdiff(error[:, 2])),
        "flat_shared": expansions(average(error[:, 2])),
        "truth": norm**2,
        "response": (average(restored) @ exact).tolist(),
    }


def result_row(row, samples, nets, older):
    corrections, anchors, targets = [], [], []
    for d, pred in samples:
        fields_, _ = fields(d, pred, row["profile"], nets)
        anchor, target = (base.old.luma(rgb, d) for rgb in (pred["nominal"], d["target"]))
        restored = fixed_heuristic(d, pred, row, older)
        zeroes = np.zeros_like(anchor)
        fields_ |= {
            "nominal": np.stack((zeroes, zeroes), axis=1),
            "heuristic": np.stack((base.old.luma(restored, d) - anchor, zeroes), axis=1),
            "v120": np.stack((base.old.luma(pred["v120"], d) - anchor, zeroes), axis=1),
        }
        corrections.append({n: fine_luma(v) for n, v in fields_.items()})
        anchors.append(fine_luma(anchor))
        targets.append(fine_luma(target))
    truth, ref = np.stack(targets), np.stack(anchors)
    np.testing.assert_array_equal(truth[0], truth[1])
    scores = {
        name: components(ref, truth, np.stack([d[name] for d in corrections]))
        for name in corrections[0]
    }
    return {
        "id": row["id"],
        "scores": scores,
        "draws": row["draws"],
        "source": row["source"]["id"],
        "pattern": row["camera"]["pattern"],
    }


def pack(rows, arm):
    records = [r["scores"][arm] for r in rows]
    return {k: np.asarray([r[k] for r in records]) for k in (*RMS, "truth", "response")}


def values(data, dose):
    a, b = dose
    powers = np.array([1, a, b, a * a, a * b, b * b])
    return {m: np.maximum(0, data[m] @ powers) for m in RMS} | {
        "response": data["response"] @ powers[:3],
        "truth": data["truth"],
    }


def means(data):
    return {m: float(np.sqrt(np.mean(data[m]))) for m in RMS} | {
        "response_pp": float(100 * np.sum(data["response"]) / np.sum(data["truth"]))
    }


def options(data, sizes, anchor):
    for dose in sizes:
        q = means(values(data, dose))
        valid = all(q[k] <= anchor[k] + d for k, d in score.LIMITS.items())
        yield {"dose": dose, "scores": q, "valid": valid}


def policy(rows):
    anchor = means(values(pack(rows, "nominal"), (0, 0)))
    choices = {}
    grid = list(product(GRID, (0, 0.125, 0.25, 0.5, 0.75, 1)))
    for name in ARMS:
        tested = list(options(pack(rows, name), grid, anchor))
        best = max(
            (x for x in tested if x["valid"]),
            key=lambda x: (x["scores"]["response_pp"], -x["scores"]["increment"]),
        )
        choices[name] = {
            "locked": best,
            "options": tested,
        }
    return {"nominal": anchor, "limits": score.LIMITS, "arms": choices}


def doses_for(selection):
    return {k: r["locked"]["dose"] for k, r in selection["arms"].items()} | {
        "nominal": (0, 0),
        "heuristic": (1, 1),
        "v120": (1, 1),
        "prior-signed-original": (0.75, 0),
    }


def report(rows, selection):
    doses = doses_for(selection)
    data = {k: pack(rows, k) for k in doses if k != "prior-signed-original"}
    data["prior-signed-original"] = data[PRIOR]
    v = {k: values(u, doses[k]) for k, u in data.items()}
    grouped = {k: means(q) for k, q in v.items()}
    n = len(rows)
    rng = np.random.default_rng(202611200937)
    draws = np.vstack((np.arange(n), rng.integers(0, n, (12000, n))))
    h = {
        k: {m: np.sqrt(q[m][draws].mean(axis=1)) for m in RMS}
        | {"response_pp": 100 * q["response"][draws].sum(axis=1) / q["truth"][draws].sum(axis=1)}
        for k, q in v.items()
    }
    contrast = {}
    for k in h:
        contrast[k] = {}
        for baseline in ("nominal", "plain", PRIOR):
            effect = {m: y - h[baseline][m] for m, y in h[k].items()}
            contrast[k][baseline] = {
                m: [float(x[0]), *np.quantile(x[1:], (0.025, 0.975)).tolist()]
                for m, x in effect.items()
            }
    anchor = grouped["nominal"]
    curves = {}
    for k in (*ARMS, "heuristic"):
        directions = tuple(doses[k])
        if max(directions) <= 0:
            directions = (1, 0)
        scales = [(i * directions[0], i * directions[1]) for i in np.linspace(0, 1, 41)]
        curves[k] = list(options(data[k], scales, anchor))
    e = np.sqrt(v["nominal"]["truth"])
    idx = np.argsort(e)
    strata = {
        "weaker-half": idx[: n // 2],
        "stronger-half": idx[n // 2 :],
    }
    stratum = {}
    for key, idx in strata.items():
        stratum[key] = {
            "count": len(idx),
            "target_increment_rms_range_DN16": [float(e[idx].min()), float(e[idx].max())],
            "scores": {k: means({m: a[idx] for m, a in q.items()}) for k, q in v.items()},
        }
    tails = {}
    for k, q in v.items():
        tails[k] = {
            m: np.quantile(
                np.sqrt(q[m]) - np.sqrt(v["nominal"][m]), [0, 0.25, 0.50, 0.75, 0.90, 1]
            ).tolist()
            for m in ("increment", "flat", "shared", "redraw")
        }
    return {
        "doses": doses,
        "scores": grouped,
        "contrasts": contrast,
        "scaled_curves_diagnostic_only": curves,
        "signal_strata": stratum,
        "tail_delta_percentiles_0_25_50_75_90_100": tails,
    }


def run(group):
    torch.set_num_threads(2)
    source = reference(OUT / group / "completed.json")
    fit, nets = models()
    earlier = reference(OVERVIEW)
    rules = read_json(checked(earlier))["policy"]["specs"]["whole"]["chosen"]
    t = monotonic()
    rows = []
    for row, data in inputs(source):
        rows.append(result_row(row, data, nets, rules))
        if len(rows) % 8 == 0:
            print(group, len(rows), round(monotonic() - t, 2), flush=True)
    calibration = reference(OUT / "score-calibration.json") if group != "calibration" else None
    used = read_json(checked(calibration))["policy"] if calibration else policy(rows)
    results = report(rows, used)
    for k, v in results["scores"].items():
        print(k, results["doses"][k], v, flush=True)
    write_json(
        OUT / f"score-{group}.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "source": source,
            "previous_whole": earlier,
            "calibration": calibration,
            "policy": used,
            "rows": rows,
            "results": results,
            "seconds": monotonic() - t,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
