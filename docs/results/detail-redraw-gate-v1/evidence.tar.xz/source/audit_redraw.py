"""Check frozen source coverage and audit repeated coefficients against delivered pixels."""

import json
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import OUT, base, energy_delta
from audit_sources import CORPUS, LOCAL, matches
from collect_redraw import identities
from evaluate_selector import deltas


def coefficients_audit(lock):
    done = reference(OUT / "preflight/completed.json")
    p = read_json(checked(done))
    receipt = read_json(checked(p["stats"][0]))
    assert receipt["plan"] == lock
    with np.load(checked(receipt["data"]), allow_pickle=False) as source:
        recorded = {k: torch.from_numpy(source[k]) for k in source.files}
    rng = torch.Generator().manual_seed(22217)
    interior = torch.rand((p["source_count"], 2, 3, 4, 4, 2), generator=rng)
    fields = torch.nn.functional.pad(interior.permute(0, 1, 2, 5, 3, 4), (2, 2, 2, 2))
    scores = {}
    for idx, (row, gate) in enumerate(zip(receipt["samples"], fields, strict=True)):
        anchor, target, changes = [], [], []
        for ref, single in zip(row["draws"], gate, strict=True):
            with np.load(checked(ref), allow_pickle=False) as data:
                b, f, _ = base.old.ingredients(data, data)
                anchor.append(b)
                target.append(base.old.luma(data["target"], data))
                changes.append(deltas(f, single.permute(0, 2, 3, 1)).sum(1))
        anchor, target, changes = map(np.stack, (anchor, target, changes))
        out = anchor + changes
        terms = base.fine((out - target)[base.CENTER]) * (65535 / 96)
        nominal = base.fine((anchor - target)[base.CENTER]) * (65535 / 96)
        exact = base.fine((target[0, 0] - target[0, 1])[base.CENTER]) * (65535 / 96)
        unit = exact / max(np.linalg.norm(exact), 1e-12)

        def energy(c, direction):
            pair = c[:, 0] - c[:, 1]
            vec = (pair[0] + direction * pair[1]) / 2
            return np.sum((vec - (vec @ unit) * unit) ** 2)

        raw = {}
        for name, direction in (("shared", 1), ("stable", -1)):
            actual = energy(terms, direction) - energy(nominal, direction)
            c = energy_delta(
                base.flatten(interior[idx : idx + 1]),
                {k: v[idx : idx + 1] for k, v in recorded.items()},
                name,
            ).item()
            np.testing.assert_allclose(c, actual, rtol=3e-5, atol=2e-5)
            raw[name] = {"direct_DN16_squared": actual, "quadratic_DN16_squared": c}
        scores[row["id"]] = raw
    return {"source": done, "cases": scores}


def source_audit(plan):
    spec = read_json(checked(plan))
    groups = spec["cases"]
    groups_by_id = {k: identities(v) for k, v in groups.items()}
    assert len(set.union(*groups_by_id.values())) == sum(map(len, groups_by_id.values()))
    reserved = groups_by_id["calibration"] | groups_by_id["held"]
    with checked(spec["training_manifest"]).open() as f:
        assert identities(map(json.loads, f)).isdisjoint(reserved)
    fixed_data = read_json(checked(spec["full427"]))["source_metadata"]
    assert len(fixed_data) == 427 and identities(fixed_data).isdisjoint(reserved)
    prior_eval = read_json(checked(spec["previous_held"]))["samples"]
    assert identities(prior_eval).isdisjoint(reserved)
    direct_train = read_json(checked(spec["previous_dataset"]))
    earlier_train = read_json(checked(direct_train["previous"]))
    all_new = set.union(*groups_by_id.values())
    assert len(all_new) == 2 * sum(map(len, groups.values()))
    assert identities(direct_train["samples"] + earlier_train["samples"]).isdisjoint(all_new)
    current = reference(CORPUS)
    local = reference(LOCAL)
    parent = read_json(checked(local))
    corpus = read_json(checked(current))
    assert spec["parent"] == parent["checkpoint"] and corpus["checkpoint"] == parent["parent"]
    photo_visits = 0
    for p in corpus["source_traces"]:
        with checked(p).open() as f:
            for row in map(json.loads, f):
                for sample in row["sources"]:
                    if sample["kind"] == "photographic":
                        assert not matches(sample, reserved), sample
                        photo_visits += 1
    local_observations = 0
    for p in parent["segments"]:
        with checked(p["observations"]).open() as f:
            for row in map(json.loads, f):
                assert not matches(row, reserved)
                local_observations += 1
    assert photo_visits == 559808 and local_observations == 5000
    return {
        "groups": {k: len(v) for k, v in groups.items()},
        "corpus": current,
        "corpus_photo_visits": photo_visits,
        "local": local,
        "local_terminal_observations": local_observations,
        "fixed427_overlap": 0,
        "direct_prior_overlap": 0,
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    binding = reference(OUT / "plan.json")
    audit = coefficients_audit(binding)
    coverage = source_audit(binding)
    print(audit, coverage, flush=True)
    write_json(
        OUT / "audit.json",
        {
            "driver": reference(Path(__file__)),
            "plan": binding,
            "coverage": coverage,
            "coefficients": audit,
        },
    )
