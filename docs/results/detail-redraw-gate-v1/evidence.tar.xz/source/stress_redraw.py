"""Replay the locked heads on the earlier, higher-contrast crop cohort."""

from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import OUT, base
from score_redraw import doses_for, models, fields
from evaluate_direct import Cases
from evaluate_selector import values
import mild_score as fixed
import score


def run():
    torch.set_num_threads(2)
    source = Cases("held")
    fit, nets = models()
    cal = reference(OUT / "score-calibration.json")
    dose = doses_for(read_json(checked(cal))["policy"])
    rows = []
    for r, d, p, bind in source:
        moves, _ = fields(d, p, r["profile"], nets)
        t, b = (score.stats(x, d) for x in (d["target"], p["nominal"]))
        v = np.zeros_like(moves["plain"])
        moves["nominal"] = v
        luma_delta = base.old.luma(p["v120"], d) - base.old.luma(p["nominal"], d)
        moves["v120"] = np.stack((luma_delta, v[:, 1]), axis=1)
        table = {
            k: fixed.terms(t, b, fixed.coefficients(x[:, 0]), fixed.coefficients(x[:, 1]))
            for k, x in moves.items()
        }
        table["prior-signed-original"] = table["prior-signed"]
        rows.append({"id": r["id"], "bindings": bind, "scores": table})
    result = {k: score.evaluate(values(rows, k, dose[k])) for k in rows[0]["scores"]}
    print(result, flush=True)
    write_json(
        OUT / "stress-stronger.json",
        {
            "driver": reference(Path(__file__)),
            "source": source.source,
            "v120": source.v120,
            "fit": fit,
            "calibration": cal,
            "rows": rows,
            "scores": result,
            "scope": "Earlier 48 higher-contrast photos, one pair per photo and eight IDs shared with full427.",
        },
    )


if __name__ == "__main__":
    run()
