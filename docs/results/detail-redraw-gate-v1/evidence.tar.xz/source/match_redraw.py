"""Compare measured off-target errors at a common natural faint response."""

from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_redraw import OUT, ARMS, RMS, means, pack, values
import score


def main():
    evidence = reference(OUT / "score-held.json")
    d = read_json(checked(evidence))
    candidates = (*ARMS, "heuristic")
    rows = d["rows"]
    strength = d["results"]["doses"]
    packed = {name: pack(rows, name) for name in (*candidates, "nominal")}
    base = means(values(packed["nominal"], (0, 0)))
    n = len(rows)
    rnd = np.random.default_rng(202611200943)
    observations = np.vstack((np.arange(n), rnd.integers(0, n, (12000, n))))

    def at_equal_contrast(a, b):
        r = [
            means(values(packed[k], strength[k]))["response_pp"] - base["response_pp"]
            for k in (a, b)
        ]
        matched = min(r)
        if matched <= 0:
            return {"status": "no positive common response along the locked scaling rays"}
        evaluated = {
            k: values(packed[k], [t * matched / gain for t in strength[k]])
            for k, gain in zip((a, b), r, strict=True)
        }
        table = {k: means(q) for k, q in evaluated.items()}
        metric = {}
        for m in RMS:
            h = [np.sqrt(evaluated[k][m][observations].mean(axis=1)) for k in (a, b)]
            delta = h[0] - h[1]
            metric[m] = [float(delta[0]), *np.quantile(delta[1:], (0.025, 0.975)).tolist()]
        return {"response_gain": matched, "scores": table, "difference": metric}

    def curve_maximum(name):
        record = d["results"]["scaled_curves_diagnostic_only"][name]
        return max((r for r in record if r["valid"]), key=lambda p: p["scores"]["response_pp"])

    result = {
        "comparisons": {
            name: {
                control: at_equal_contrast(name, control)
                for control in ("plain", "prior-signed", "heuristic")
            }
            for name in ("shared", "stable")
        },
        "limits": score.LIMITS,
        "retrospective_budget_curve": {k: curve_maximum(k) for k in candidates},
    }
    print(result["retrospective_budget_curve"], flush=True)
    write_json(
        OUT / "matched-held.json",
        {
            "driver": reference(Path(__file__)),
            "source": evidence,
            "scope": "Diagnostic common-response scaling and same-budget choices using held results.",
            "results": result,
        },
    )


if __name__ == "__main__":
    main()
