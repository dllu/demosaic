"""Render matched native natural and GFX references and score exact wire controls."""

from pathlib import Path
from statistics import mean
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from redraw_gate import OUT, base
from score_redraw import (
    DISPLAY,
    PRIOR,
    doses_for,
    inputs,
    models,
    pack,
    render,
    values,
)
from evaluate_direct import Cases
from review_selector import board, crop, image, named_pixels, wire_scorer

ROI = (48, 48, 160, 160)
CORE_METHODS = ("nominal", PRIOR, "plain", "shared", "stable")
REFTAGS = ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
LABELS = DISPLAY | {
    "plain": "Direct loss control",
    "shared": "Shared error loss",
    "stable": "Redraw stability",
    PRIOR: "Prior response, relocked",
    "prior-original": "Prior response, original",
    "target": "Exact GT",
}


def natural(nets, doses, heur, folder):
    signal = reference(OUT / "score-held.json")
    data = read_json(checked(signal))
    rows = data["rows"]
    nominal = values(pack(rows, "nominal"), (0, 0))["increment"]
    chosen = values(pack(rows, "stable"), doses["stable"])["increment"]
    changes = np.sqrt(chosen) - np.sqrt(nominal)
    if np.ptp(changes) == 0:
        chosen = values(pack(rows, "stable"), (1, 0))["increment"]
        reasons = (
            "largest reduction at full sharper gain",
            "largest increase at full sharper gain",
        )
        indices = np.argsort(np.sqrt(chosen) - np.sqrt(nominal))
    else:
        reasons = ("lowest paired error change", "highest paired error change")
        indices = np.argsort(changes)
    picks = {
        rows[i]["id"]: (label, float(changes[i]))
        for i, label in zip((indices[0], indices[-1]), reasons, strict=True)
    }
    receipts = []
    for row, samples in inputs(data["source"]):
        if row["id"] not in picks:
            continue
        d, pred = samples[0]
        expo = 1 / row["profile"]["exposure"]
        noisy = noisy_malvar(
            {
                "packed": d["packed"],
                **{
                    k: np.broadcast_to(d[k], (len(d["packed"]), *d[k].shape)).copy()
                    for k in ("colors", "wb", "matrix")
                },
            }
        )
        groups = render(d, pred, row, nets, doses, heur)
        frames = {}
        order = ("v120", "nominal", "heuristic", PRIOR, "plain", "shared", "stable", "target")
        for role, idx in (("present", 0), ("flat", 2)):

            def show(x):
                return image(crop(x[idx], ROI), d["wb"], d["matrix"], expo)

            all_ = dict(groups, target=d["target"])
            pics = [("Noisy Malvar", show(noisy))] + [(LABELS[k], show(all_[k])) for k in order]
            frames[role] = board(pics, folder / (row["id"] + "-" + role + ".png"))
            if role == "present":
                frames["triplet"] = board(
                    [pics[0], (LABELS["stable"], show(groups["stable"])), pics[-1]],
                    folder / (row["id"] + "-triplet.png"),
                )
        receipts.append(
            {
                "fixture": row,
                "display_exposure": expo,
                "ROI": ROI,
                "result": picks[row["id"]],
                "redraw_shown": 0,
                "frames": frames,
            }
        )
        print(row["id"], picks[row["id"]], flush=True)
    assert len(receipts) == 2
    return {"evidence": signal, "rows": receipts}


def standing(nets, doses, folder):
    prev = reference(base.OUT / "review-camera.json")
    refs = {r["id"]: r for r in read_json(checked(prev))["report"]["rows"]}
    rows = []
    people = Cases("camera")
    extra = nets | {"prior-original": nets[PRIOR]}
    scales = doses | {"prior-original": doses["prior-signed-original"]}
    for raw, d, p, b in people:
        current = refs[raw["id"]]
        assert current["input"] == raw["input"] and current["ROI"] == raw["global_ROI"]
        arr = render(d, p, raw, extra, scales, None)
        panels = []
        box = raw["local_ROI"]
        for fmt in current["native"]:
            lit = fmt["exposure"]
            old = named_pixels(fmt)

            def show(x):
                return image(crop(x[0], box), d["wb"], d["matrix"], lit)

            np.testing.assert_array_equal(show(arr["nominal"]), old[DISPLAY["nominal"]])
            np.testing.assert_array_equal(show(arr["prior-original"]), old["Signed response"])
            pre = ("Noisy (Malvar)", "V120 EMA", DISPLAY["heuristic"])
            views = [(k, old[k]) for k in pre]
            views += [
                (LABELS[k], show(arr[k])) for k in ("nominal", "prior-original", *CORE_METHODS[1:])
            ]
            views += [(k, old[k]) for k in REFTAGS if k in old]
            product = board(views, folder / f"{raw['id']}-x{lit:g}.png")
            panels.append(product | {"exposure": lit, "reference_board": fmt})
        anchor = crop(arr["nominal"].astype(np.float64), box)
        changes = {
            k: float(np.sqrt(np.mean((crop(arr[k], box) - anchor) ** 2)) * 65535)
            for k in (*CORE_METHODS, "prior-original")
        }
        rows.append(
            {
                "id": raw["id"],
                "raw": raw["raw"],
                "input": raw["input"],
                "bindings": b,
                "ROI": raw["global_ROI"],
                "local_ROI": box,
                "noise": raw["noise"],
                "native": panels,
                "RGB_RMS_change_DN16": changes,
            }
        )
        print(raw["id"], changes, flush=True)
    assert len(rows) == 8 and sum(len(r["native"]) for r in rows) == 12
    return {"previous": prev, "rows": rows}


def wire(nets, doses):
    file, measure = wire_scorer()
    rows = []
    for row, d, p, proof in Cases("wires"):
        geometry = row["fixture"]["geometry"]
        if geometry["family"] == "smooth-dip":
            d = d | {"support": np.ones_like(d["support"])}
        models_ = nets | {"prior-original": nets[PRIOR]}
        scales = doses | {"prior-original": doses["prior-signed-original"]}
        for_eval = render(d, p, row, models_, scales, None)
        scorer = measure(d, geometry)
        rows.append(
            {
                "id": row["id"],
                "provenance": proof,
                "scores": {k: scorer(for_eval[k]) for k in (*CORE_METHODS, "prior-original")},
            }
        )
    summary = {
        k: {
            m: mean(r["scores"][k][m] for r in rows if m in r["scores"][k])
            for m in sorted({v for r in rows for v in r["scores"][k]})
        }
        for k in rows[0]["scores"]
    }
    print(summary, flush=True)
    return {"scorer": file, "rows": rows, "summary": summary}


def run(job):
    torch.set_num_threads(2)
    fit, nets = models()
    calibration = reference(OUT / "score-calibration.json")
    lock = read_json(checked(calibration))
    doses = doses_for(lock["policy"])
    bound = lock["previous_whole"]
    heur = read_json(checked(bound))["policy"]["specs"]["whole"]["chosen"]
    folder = OUT / "native" / job
    folder.mkdir(exist_ok=True, parents=True)
    if job == "natural":
        report = natural(nets, doses, heur, folder)
    elif job == "camera":
        report = standing(nets, doses, folder)
    elif job == "wire":
        report = wire(nets, doses)
    else:
        raise ValueError(job)
    write_json(
        OUT / f"review-{job}.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "calibration": calibration,
            "policy": doses,
            "report": report,
        },
    )


if __name__ == "__main__":
    run(sys.argv[1])
