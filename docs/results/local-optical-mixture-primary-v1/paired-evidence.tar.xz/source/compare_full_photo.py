"""Compare mixed optics and the matched sharp regional arm on the fixed canonical photo panel."""

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import tarfile

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def compare(publication_path, output):
    publication = reference(publication_path)
    b = read_json(checked(publication))
    ref = b["archive"]
    archive = checked({"path": str(Path(ref["path"]).resolve()), "sha256": ref["sha256"]})
    columns = ("V120", "parent100k", "local50k", "regional-aligned", "regional-optical-mix")
    values = defaultdict(dict)
    with tarfile.open(archive) as tar:
        for index in range(b["counts"]["photo"]):
            row = json.load(tar.extractfile(f"photo/{index:05d}.json"))
            assert row["stage"] == "photo" and row["plan"] == b["plan"]
            assert row["batch"] == index and set(columns) == set(row["variants"])
            samples = [row["variants"][arm]["rows"] for arm in columns]
            for whole in zip(*samples, strict=True):
                first = whole[0]
                fields = ("id", "kind", "condition", "pattern")
                assert all(all(v[k] == first[k] for k in fields) for v in whole)
                if first["kind"] == "photo":
                    key = (first["condition"], first["pattern"])
                    per_source = values[first["id"]]
                    assert key not in per_source
                    scores = tuple(v["metrics"]["srgb_psnr"] for v in whole)
                    assert all(math.isfinite(v) for v in scores)
                    per_source[key] = scores
    assert len(values) == 427
    axes = set.union(*(set(v) for v in values.values()))
    assert len(axes) == 28 and all(set(v) == axes for v in values.values())
    ordered = sorted(axes)
    labels = sorted({a[0] for a in axes})
    table = np.array([[scores[a] for a in ordered] for scores in values.values()])

    def summarize(group):
        single = group.mean(1)
        rng = np.random.default_rng(202611200105)
        draws = rng.integers(0, len(single), (10000, len(single)))
        pairs = [
            ("regional-optical-mix", arm) for arm in columns if arm != "regional-optical-mix"
        ] + [("regional-aligned", arm) for arm in columns[:3]]
        effects = {}
        for first, second in pairs:
            delta = single[:, columns.index(first)] - single[:, columns.index(second)]
            lower, upper = np.quantile(delta[draws].mean(1), [.025, .975])
            effects[f"{first}_minus_{second}"] = [float(delta.mean()), float(lower), float(upper)]
        return {"means": dict(zip(columns, single.mean(0).tolist(), strict=True)), "paired_95": effects}

    all_conditions = summarize(table)
    overall = {r["model"]: r["metrics"]["srgb_psnr"]["mean"] for r in b["photo_summary"]
               if r["kind"] == "photo"}
    published_sharp = read_json(Path("docs/results/local-regional-wire-primary-v1/publication.json"))
    assert b["canonical_inputs"] == published_sharp["canonical_inputs"]
    assert b["models"]["regional-aligned"] == published_sharp["models"]["regional-aligned"]
    sharp = next(r["metrics"]["srgb_psnr"]["mean"] for r in published_sharp["photo_summary"]
                 if r["kind"] == "photo" and r["model"] == "regional-aligned")
    assert abs(sharp - overall["regional-aligned"]) < 1e-4
    assert all(math.isclose(mean, overall[k], abs_tol=1e-10, rel_tol=0)
               for k, mean in all_conditions["means"].items())
    write_json(output, {"driver": reference(__file__), "primary": publication,
                        "sharp_publication": reference(Path("docs/results/local-regional-wire-primary-v1/publication.json")),
                        "sharp_minus_prior_dB": overall["regional-aligned"] - sharp,
                        "sources": len(values), "photo_observations_per_model": table.shape[0]*table.shape[1],
                        "all": all_conditions, "by_condition": {
                            condition: summarize(table[:, [i for i, (a, _) in enumerate(ordered) if a == condition]])
                            for condition in labels
                        }})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("publication", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    compare(args.publication, args.output)
