"""Verify actual whole-cohort visits and every ordinary source index through17250."""
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

base=Path('.cache/experiments/full-corpus-scaling-v3').resolve()
header_path=Path('.cache/experiments/full-corpus-scaling-v1/order20k/photo-epoch-order.json').resolve();header=read_json(header_path)
manifest=checked(header['source_manifest']);rows=[json.loads(l)for l in manifest.read_text().splitlines()if json.loads(l)['split']=='train'];ids=[r['id']for r in rows]
assert len(ids)==len(set(ids))==90778
assert hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest()==header['ordered_train_ids_sha256']
order_path=header_path.parent/header['order']['path'];assert reference(order_path)['sha256']==header['order']['sha256']
order=np.load(order_path,allow_pickle=False)
old=base/'checkpoint-stall-step6000-v1/failed-source-crop-observations.jsonl'
resumed=base/'checkpoint-stall-step14000-v1/failed-source-crop-observations.jsonl'
current=base/'checkpoint-recovery-v7/work/artifacts/train/control20k/phase-013001-020000/source-crop-observations.jsonl'
with current.open()as stream:prefix=''.join(itertools.islice(stream,4250))
current_rows=[json.loads(l)for l in prefix.splitlines()]
assert len(current_rows)==4250 and current_rows[-1]['step']==17250,'Wait for complete source prefix; no training action'
events=[json.loads(l)for l in old.read_text().splitlines()]+[v for l in resumed.read_text().splitlines()if(v:=json.loads(l))['step']<=13000]+current_rows
assert len(events)==17250 and [v['step']for v in events]==list(range(1,17251))
assert [v['global_draw_start']for v in events]==list(range(0,276000,16))
ordinary,reviewed,visits,kinds,domains=Counter(),Counter(),Counter(),Counter(),Counter();crops=set();first_complete=None;first_complete_global_draw=None
for event in events:
    domains[event['domain']]+=1
    expected=order[event['global_draw_start']:event['global_draw_start']+16]
    if event['domain']!='commons':
        assert not event['sources']and np.all(expected==-1)
        continue
    assert len(event['sources'])==16
    for slot,(source,index)in enumerate(zip(event['sources'],expected,strict=True)):
        kinds[source['kind']]+=1
        if source['kind']!='photographic':assert index==-1;continue
        identity=source['source_id'];visits[identity]+=1;crops.add((identity,tuple(source['cache_xywh'])))
        if source['reviewed_roi_xywh']is not None:reviewed[identity]+=1;assert index==-1
        else:
            assert index>=0 and ids[int(index)]==identity
            ordinary[identity]+=1
            if first_complete is None and len(ordinary)==90778:
                first_complete=event['step'];first_complete_global_draw=event['global_draw_start']+slot
assert set(ordinary)==set(ids)and set(visits)==set(ids)
assert first_complete==header['summary']['first_complete_ordinary_epoch_step']==17039
conditions=[];steps=[]
for folder,low,high in [(base/'work/artifacts/train/control20k/phase-000001-020000',1,6000),
 (base/'checkpoint-recovery-v6/work/artifacts/train/control20k/phase-006001-020000',6001,13000),(current.parent,13001,17250)]:
    for path in sorted(folder.glob('conditions-*.npz')):
        with np.load(path,allow_pickle=False)as data:
            a=data['steps']
            if a[0]<low or a[-1]>high:continue
            assert data['values'].shape==(250,16,14)and np.isfinite(data['values']).all()
            assert data['domains'].tolist()==[events[int(s)-1]['domain']for s in a]
            steps.extend(a.tolist());conditions.append(reference(path))
assert steps==list(range(1,17251))and len(conditions)==69
log=base/'production-handoff-v7/00-scale-control20k.log';raw=log.read_text();logs=[json.loads(l)for l in raw.splitlines()if l.startswith('{')]
latest=max(v['step']for v in logs if v['event']=='train');assert latest>=17250
out=base/'first-full-epoch-actual-v1';out.mkdir();snapshot=out/'source-crop-13001-17250.jsonl';snapshot.open('x').write(prefix)
log_snapshot=out/'training-log-observation.log';log_snapshot.open('x').write(raw)
write_json(out/'result.json',{'producer':reference(__file__),'order_header':reference(header_path),'manifest':header['source_manifest'],'order_payload':reference(order_path),
 'first6000':reference(old),'resumed6001-13000_source':reference(resumed),'resumed_source_filter':'Keep only6001..13000; aborted13001..14000 is excluded.',
 'replayed13001-17250':reference(snapshot),'source_steps':17250,'target_slots':276000,'domains':dict(domains),'Commons_kinds':dict(kinds),
 'photo_visits':sum(visits.values()),'distinct_photo_sources':len(visits),'ordinary_photo_draws':sum(ordinary.values()),'ordinary_photo_sources':len(ordinary),
 'ordinary_visit_histogram':dict(Counter(ordinary.values())),'reviewed_photo_draws':sum(reviewed.values()),'reviewed_photo_sources':len(reviewed),
 'reviewed_fraction_of_photo_draws':sum(reviewed.values())/sum(visits.values()),'unique_source_cache_crop_boxes':len(crops),
 'actual_first_complete_ordinary_epoch_step':first_complete,'actual_first_complete_epoch_global_draw_index':first_complete_global_draw,
 'actual_photo_ID_set_equals_all90778_declared_train_IDs':True,'every_actual_ordinary_slot_matches_bound_epoch_payload':True,
 'conditioning':conditions,'conditioning_steps':[1,17250],'latest_observed_optimizer_step':latest,'training_log_snapshot':reference(log_snapshot),
 'native_paired_actual_distinct_IDs':None,
 'scope':'Actual complete0→17250 execution prefix after exact13k resume; all90778 ordinary photo IDs visited, all276000 global target slots/69 conditioning chunks checked, every ordinary source identity matches original order payload. Lost13k→14k rows are excluded before new replay is counted. First epoch confirmed at17039, not inferred from planned counts. Native/paired IDs unavailable; domain/conditioning counts recorded. This is training exposure, not lifetime/backbone novelty, independent-pixel coverage, saved17250 checkpoint or quality/20k-horizon completion.'})
print('Actual all90778-source epoch confirmed at step',first_complete,'through17250 photo visits',sum(visits.values()),'ordinary',sum(ordinary.values()))
