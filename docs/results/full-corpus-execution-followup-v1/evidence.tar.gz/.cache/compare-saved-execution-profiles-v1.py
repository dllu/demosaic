"""Bind existing77-step states and the actual execution/input-witness differences."""
from pathlib import Path
import torch
import yaml
from demosaic.experiments.artifacts import read_json,checked,reference,write_json

torch.set_num_threads(2)
r=Path('.cache/experiments/full-corpus-scaling-v3').resolve();out=Path('.cache/experiments/training-execution-quality-v2/source-comparison-v1').resolve();out.mkdir()
receipts={n:read_json(r/'profiles'/n/'result.json')for n in ['strict0','fast0','fast2']}
configs={n:yaml.safe_load(checked(s['config']).read_text())for n,s in receipts.items()}
states={n:torch.load(checked(s['resumed_step77']),map_location='cpu',weights_only=True)for n,s in receipts.items()}
assert all(states[n]['model_config']==states['strict0']['model_config']for n in states)
assert all(s['sampled_input_witnesses_outside_measurement']==receipts['strict0']['sampled_input_witnesses_outside_measurement']for s in receipts.values())
assert all(s['step']==77 and len(s['model'])==len(s['ema'])==91 and len(s['optimizer']['state'])==89 for s in states.values())
assert all(v['step']==77 for s in states.values()for v in s['optimizer']['state'].values())
differences={key:{n:cfg[key]for n,cfg in configs.items()}for key in configs['strict0']if len({str(cfg[key])for cfg in configs.values()})>1}
assert set(differences)=={'run','workers','paired_workers','raw_clean_workers','training_execution'}
values=[]
for n in ['fast0','fast2']:
 for group in ['model','ema']:
  fields=[]
  for key,a in states['strict0'][group].items():
   b=states[n][group][key];assert torch.isfinite(a).all()and torch.isfinite(b).all()
   fields.append({'tensor':key,'exact':torch.equal(a,b),'maxabs_difference':float((a-b).abs().max())})
  values.append({'profile':n,'state':group,'exact_tensors':sum(v['exact']for v in fields),'total_tensors':len(fields),
                 'maximum_absolute_difference':max(v['maxabs_difference']for v in fields),'tensors':fields})
write_json(out/'result.json',{'producer':reference(__file__),'profiles':{n:{'receipt':reference(r/'profiles'/n/'result.json'),'checkpoint':receipts[n]['resumed_step77']}for n in receipts},
 'actual_config_differences':differences,'model_config':states['strict0']['model_config'],'five_sampled_full_input_witnesses_exact':True,
 'sampled_steps':[1,2,6,76,77],'state_differences':values,'updates_per_profile':77,'target_examples_per_profile':1232,
 'horizon':100000,'precision_all_profiles':'bfloat16','hidden_autocast_all_profiles':False,'native_head_tail_skip_FP32':True,
 'training_timing':{n:{k:s[k]for k in ['measured_updates','native_patches_measured','measured_seconds','patches_per_second','checkpoint_seconds_outside_measurement']}for n,s in receipts.items()},
 'scope':'Actual saved-state/config/witness comparison, no new training or neural call. Model/config precision is identical; strict/throughput backend and loader bundle differ. Five historical complete physical-input witnesses match, not a claim every77 batch was measured equal.50 timed updates exclude warmup/init/checkpoints/resume; full77 duration was not recorded by this profile receipt. Early77 quality cannot isolate or rule out long-run10k effects.'})
print('Saved77-step configs/states and five witnesses checked; no precision change')
