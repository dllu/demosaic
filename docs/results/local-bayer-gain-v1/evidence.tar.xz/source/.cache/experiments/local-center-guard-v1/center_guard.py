"""Separate broad coefficient fitting from the support required at delivery."""

import numpy as np

from ring_refit import EDGE, GAIN, OFFSET, OUTER, ROI_WIDTH, TAPER, THRESHOLD, WIDTH, Patch, sample
from review_raw import box_wave, nuisance, unpack

VENTURES = ("broad", "guarded", "phase_only")


def fit_operators(smooth, wave, positions):
    result = []
    for train, hold in (positions, positions[::-1]):
        side = []
        for direction in range(2):
            base = np.concatenate((smooth, wave[..., 1-direction, :]), axis=-1)
            a, b = (sample(base, point).reshape(-1, base.shape[-1]) for point in (train, hold))
            x, y = (sample(wave[..., direction, :], point).reshape(-1, 2) for point in (train, hold))
            fit = np.linalg.pinv(a, rcond=1e-8)
            projection = fit @ x
            ra, rb = x - a @ projection, y - b @ projection
            side.append((a, b, fit, ra, rb, np.linalg.pinv(ra, rcond=1e-8)))
        result.append(side)
    return result


def views(tile, positions):
    return [sample(tile, point).ravel() for point in positions]


def residuals(fold, train, hold):
    a, b, fit, ra, rb, free = fold
    baseline = fit @ train
    return train - a @ baseline, hold - b @ baseline, ra, rb, free


def improvement(hold, pred, variance):
    return (2 * hold @ pred - pred @ pred) / variance


def variance(values, shot, read):
    return max(2e-11, shot * max(0., float(values.mean())) + read)


class CenterGuard:
    def __init__(self, colors, x, y, frequency):
        local = Patch(colors, x, y, frequency)
        self.positions = local.positions
        self.inner = local.folds
        self.wave = local.wave
        self.core = np.s_[OFFSET:OUTER-OFFSET, OFFSET:OUTER-OFFSET]
        self.old = local.parent_fit
        wave = box_wave((0, 0, OUTER), ((OUTER - 1) / 2,) * 2, frequency)
        self.outer = fit_operators(nuisance(OUTER, "cosine"), wave, self.positions)
        self.outer_parent_fit = np.linalg.pinv(
            np.concatenate((nuisance(OUTER, "cosine"), wave.reshape(OUTER, OUTER, 4)), axis=-1)
            .reshape(OUTER**2, -1), rcond=1e-8
        )[-4:]

    def fold(self, tile, fold, shot, read):
        v = views(tile, self.positions)
        inner = views(tile[self.core], self.positions)
        train, hold = fold, 1-fold
        result = {k: [[], []] for k in VENTURES}
        for outer, center in zip(self.outer[fold], self.inner[fold], strict=True):
            source, target, _, design, inverse = residuals(outer, v[train], v[hold])
            broad_coef = inverse @ source
            s, t, a, b, _ = residuals(center, inner[train], inner[hold])
            unit = broad_coef / max(1e-12, np.linalg.norm(broad_coef))
            w = a @ unit
            amp = max(0., float(w @ s) / max(1e-12, float(w @ w)))
            coef = unit * amp
            outer_var = variance(v[train], shot, read)
            center_var = variance(inner[train], shot, read)
            outcomes = (
                (broad_coef, improvement(target, design @ broad_coef, outer_var)),
                (broad_coef, improvement(t, b @ broad_coef, center_var)),
                (coef, improvement(t, b @ coef, center_var)),
            )
            for name, (weights, score) in zip(VENTURES, outcomes, strict=True):
                result[name][0].append(weights)
                result[name][1].append(score)
        return {k: tuple(map(np.asarray, v)) for k, v in result.items()}

    def predict(self, tile, parent, broad_parent, shot, read):
        first, second = (self.fold(tile, f, shot, read) for f in (0, 1))
        old_center = (self.old @ parent.ravel()).reshape(2, 2)
        old_broad = (self.outer_parent_fit @ broad_parent.ravel()).reshape(2, 2)
        estimates, active = {}, {}
        for name in VENTURES:
            weight, score = first[name]
            other, confirm = second[name]
            strength = np.maximum(0., np.minimum(score, confirm) - THRESHOLD)
            gate = strength / (strength + THRESHOLD)
            measured = (weight + other) / 2
            old = old_center if name == "phase_only" else old_broad
            correction = (measured - old) * gate[:, None]
            limit = np.linalg.norm(measured, axis=1)
            size = np.linalg.norm(correction, axis=1).clip(min=1e-12)
            correction *= np.minimum(1., limit / size)[:, None]
            estimates[name] = np.sum(self.wave * correction[None, None], axis=(2, 3))
            active[name] = gate > 0
        return estimates, active


def correct(parent, parent_context, scene, colors, rectangle, frequency, profile, wb, matrix):
    out = {name: parent for name in VENTURES}
    counts = {name: [0, 0] for name in VENTURES}
    if frequency is None:
        return out, counts
    x, y, w, h = rectangle
    assert w == h == ROI_WIDTH and parent.shape == (3, h, w)
    assert parent_context.shape == (3, h+2*OFFSET, w+2*OFFSET)
    np.testing.assert_array_equal(parent, parent_context[..., OFFSET:-OFFSET, OFFSET:-OFFSET])
    operator = CenterGuard(colors, x, y, frequency)
    raw = unpack(scene)
    fields = {name: np.zeros((h, w)) for name in VENTURES}
    mass = np.zeros((h, w))
    for dy in range(0, h - WIDTH + 1, WIDTH // 2):
        for dx in range(0, w - WIDTH + 1, WIDTH // 2):
            region = np.s_[dy:dy+WIDTH, dx:dx+WIDTH]
            xx, yy = x + dx - OFFSET, y + dy - OFFSET
            tile = raw[yy:yy+OUTER, xx:xx+OUTER].astype(np.float64)
            parent_tile = parent_context[1, dy:dy+OUTER, dx:dx+OUTER]
            estimates, active = operator.predict(tile, parent[1][region], parent_tile,
                                                 profile["shot"], profile["read"])
            for name, estimate in estimates.items():
                fields[name][region] += TAPER * estimate
                counts[name] = (np.asarray(counts[name]) + active[name]).tolist()
            mass[region] += TAPER
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    for name, full in fields.items():
        delta = full / np.maximum(.02, mass) * EDGE[:, None] * EDGE[None, :]
        out[name] = parent + (GAIN * (neutral / neutral[1])[:, None, None] * delta).astype(parent.dtype)
    return out, counts


def verify_folds():
    rng = np.random.default_rng(20261120)
    for layout in ((0, 1, 1, 2), (1, 0, 2, 1), (1, 2, 0, 1), (2, 1, 1, 0)):
        fixture = rng.uniform(.07, .085, (OUTER, OUTER))
        operator = CenterGuard(np.asarray(layout), 0, 0, ((.11, .08), (.09, -.07)))
        for fold in (0, 1):
            y, x = operator.positions[1-fold]
            mutated = fixture.copy()
            mutated[operator.core][y::2, x::2] += .2 * rng.normal(size=(WIDTH//2, WIDTH//2))
            base = operator.fold(fixture, fold, .00128, 6.5536e-6)
            alter = operator.fold(mutated, fold, .00128, 6.5536e-6)
            for name in VENTURES:
                np.testing.assert_array_equal(base[name][0], alter[name][0])
                assert np.any(base[name][1] != alter[name][1])
            np.testing.assert_array_equal(base["broad"][0], base["guarded"][0])
