"""Review the two EMA gain heads against fixed Bayer and neural controls."""

import time

import numpy as np
from PIL import Image, ImageDraw
import torch

from prepare_gain import OUT, TRIAL
from bayer_gain_features import FEATURES, nominal_peaks, support
from train_bayer_gain import ARMS, HIDDEN, Gain
from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_ring import (
    ABSOLUTE, FIXED, LENGTH, ROI, WireFundamental, arrays, coefficients, display, frozen_inputs,
    native_board, support_for_scoring,
)
from optical_response_balance import calibration
from qualify_nesting import PANEL
from score_center_guard import section
from score_nested import null_measures
from score_nested import effects
from nested_gate import apply as reference_gate

LABELS = {"local50k": "Local 50k", "fixed": "Fixed combined check",
          "center_features": "Learned center stats", "broad_features": "Learned broad stats",
          "v120": "V120 EMA"}


def models(training):
    nets = {}
    for arm in ARMS:
        state = torch.load(checked(training["checkpoints"][arm]), weights_only=True, map_location="cpu")
        for key in ("parent", "plan", "evidence"):
            assert state[key] == training[key]
        assert state["features"] == FEATURES and state["steps"] == training["update_count_each"]
        assert state["hidden"] == HIDDEN and state["broad"] == (arm == ARMS[1])
        full = Gain(state["ema"]["center"], state["ema"]["spread"], state["broad"]).eval()
        full.load_state_dict(state["ema"])
        nets[arm] = full
    return nets


def corrected(parent, local, scene, colors, roi, peaks, profile, wb, matrix, models, verify=False):
    fitted = support(parent, local, scene, colors, roi, peaks, profile, wb, matrix)
    p = section(parent, *local)
    chosen = {"fixed": fitted.render(fitted.fixed, p)}
    if verify:
        hand, _ = reference_gate(parent, local, scene, colors, roi, peaks, profile | {"wb": wb, "matrix": matrix})
        np.testing.assert_allclose(chosen["fixed"], hand["nested"], rtol=3e-7, atol=2e-8)
    if len(fitted.fixed):
        terms = torch.from_numpy(fitted.features), torch.from_numpy(fitted.fixed)
        for arm, model in models.items():
            chosen[arm] = fitted.render(model(*terms).numpy(), p)
    else:
        chosen |= {k: p for k in models}
    metrics = {k: float(np.sqrt(np.mean((v.astype(np.float64)-p)**2))*65535) for k,v in chosen.items()}
    return chosen, len(fitted.fixed), metrics


def overlays(parent, f, scene, roi, cut, noise, models, audit=False):
    scene = scene.copy()
    colors, wb, matrix = (f[k] for k in ("colors", "wb", "matrix"))
    peaks = nominal_peaks(scene, colors, roi, 48)
    output = {k: parent.copy() for k in ("fixed", *ARMS)}
    counts, changes = [], []
    for i, packed in enumerate(f["packed"]):
        scene[cut] = packed
        actual, active, rms = corrected(parent[i], ROI, scene, colors, roi, peaks, noise, wb, matrix, models,
                                        verify=audit)
        for k, value in actual.items():
            section(output[k][i], *ROI)[:] = value
        counts.append(active)
        changes.append(rms)
    return output, counts, changes


def scorer(f, sharp, geom, parent):
    mask = support_for_scoring(f["support"])
    clean = WireFundamental(f | {"support": mask, "target": sharp}, geom)
    optical = WireFundamental(f | {"support": mask, "target": f["target"][:4]}, geom)

    def measure(pred):
        result = optical(pred[:4]) | {ABSOLUTE: clean(pred[:4])[LENGTH]}
        if pred.shape[0] == 6:
            result |= null_measures(pred, parent, f)
        return result
    return measure


def fit_response(models):
    source = reference(PANEL)
    r = read_json(checked(source))
    group = r["panels"]["previous"]
    scores = []
    for row in group["rows"]:
        f = frozen_inputs(row)
        truth = arrays(f["case"]["inputs"]["0.0"])["target"]
        data, parent, scene, rect, cut = (f[k] for k in ("input", "parent", "scene", "phase_correction_roi", "cut"))
        chosen, _, _ = overlays(parent, data, scene, rect, cut, group["profile"], models, audit=len(scores)==0)
        measure = scorer(data, truth, f["case"]["fixture"]["geometry"], parent)
        scores.append({"id": row["case"]["id"], "response_balance": coefficients(parent, chosen, measure)})
    pairs = (("fixed", ARMS[0]), ("fixed", ARMS[1]), ARMS)
    fits = {"+".join(pair): calibration(scores, pair) for pair in pairs}
    return {"calibration_parent": source, "scores": scores, "fits": fits}


def observe(fixture, row, plan, models, matches, folder):
    f = arrays(row["data"])
    parent = np.load(checked(row["outputs"]["local50k"]), allow_pickle=False)
    v120 = np.load(checked(row["outputs"]["v120"]), allow_pickle=False)
    cut = np.s_[..., 64:192, 64:192]
    rect = (176, 176, 160, 160)
    chosen, counts, changes = overlays(
        parent, f, f["scene_packed"], rect, cut, plan["noise"], models, audit=fixture["index"] in plan["native_indices"],
    )
    measure = scorer(f, f["sharp_target"], fixture["geometry"], parent)
    mix = {
        k: {arm: measure(parent + (chosen[arm]-parent)*g) for arm,g in recipe["gains"].items()}
        for k, recipe in matches.items() if recipe["calibrated"]
    }
    all_preds = {"local50k": parent, **chosen, "v120": v120}
    if fixture["index"] in plan["native_indices"] and row["draw"] == 0:
        camera = {k: f[k][None] for k in ("colors", "wb", "matrix")}
        camera["packed"] = f["packed"][:1]
        frames = [noisy_malvar(camera)[0], *(all_preds[key][0] for key in LABELS), f["target"][0]]
        native = native_board(
            folder, fixture["id"], frames, camera, {
                "source": fixture, "query": plan["query"], "input": row["data"], "noise": plan["noise"],
                "draw": row["draw"], "sigma": plan["sigma"],
            }, labels=["Noisy Malvar", *LABELS.values(), "Exact GT"], triplet_indices=(0, 4, 6),
        )
    else:
        native = None
    return {"draw": row["draw"], "input": row["data"], "parent": row["outputs"], "active_directions": counts,
            "change_RGB_RMS_DN16": changes, "nominal": {k: measure(v) for k,v in all_preds.items()},
            "matched": mix, "native": native}


def standing(weight, models, dest):
    source = reference(FIXED)
    original = read_json(checked(source))
    assert original["checkpoints"]["local50k"] == weight
    result = []
    for row in original["standing"]:
        data = arrays(row["input"])
        parent = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        scene, colors, wb, matrix = (data[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(row["local_ROI"])
        peaks = nominal_peaks(scene, colors, roi, 16)
        output, active, rms = corrected(parent, roi, scene, colors, roi, peaks, row["noise"], wb, matrix, models, True)
        images = []
        for view in row["displays"]:
            exp, previous = view["exposure"], view["board"]
            with Image.open(checked(previous["image"])) as im:
                image = np.asarray(im)
            frames = {}
            for line in previous["panels"]:
                x, y, w, h = line["png_xywh"]
                frames[line["name"]] = image[y:y+h, x:x+w]
            np.testing.assert_array_equal(display(section(parent, *roi), wb, matrix, exp), frames["Local 50k"])
            names = ("Noisy (Malvar)", "V120 EMA", "Corpus 100k", "Local 50k")
            panels = [(n, frames[n]) for n in names]
            panels.extend((LABELS[arm], display(output[arm], wb, matrix, exp)) for arm in ("fixed", *ARMS))
            panels.extend((n, frames[n]) for n in ("ISO100 AHD reference", "ISO6400 camera JPEG", "ISO100 camera JPEG")
                          if n in frames)
            board = Image.new("RGB", (8+168*len(panels), 192), "#eeeeee")
            draw = ImageDraw.Draw(board)
            for i, (name, pixels) in enumerate(panels):
                x = 8+168*i
                assert pixels.shape==(160,160,3)
                board.paste(Image.fromarray(pixels), (x,24))
                draw.text((x,5), name, fill="black")
            name = dest / f'{row["id"]}-x{exp:g}.png'
            board.save(name)
            images.append({"image": reference(name), "exposure": exp, "columns": len(panels), "prior": previous})
        result.append({"id": row["id"], "ROI": row["global_ROI"], "parent": row["predictions"]["local50k"],
                       "input": row["input"], "raw": row["raw"], "noise": row["noise"], "native": images,
                       "RMS_from_parent": rms, "active": active})
    return {"source": source, "rows": result}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    root = OUT / "review"
    root.mkdir(exist_ok=True)
    exact = root / "exact"
    real = root / "standing"
    exact.mkdir(exist_ok=True)
    real.mkdir(exist_ok=True)
    source = reference(OUT / "train/completed.json")
    training = read_json(checked(source))
    nets = models(training)
    plan_ref = reference(TRIAL / "plan.json")
    plan = read_json(checked(plan_ref))
    parents_ref = reference(TRIAL / "parent/result.json")
    parents = read_json(checked(parents_ref))
    assert training["parent"] == parents["weights"]["local50k"] == plan["checkpoints"]["local50k"]
    start = time.monotonic()
    calibration_pack = fit_response(nets)
    entries = []
    for entry, fixture in zip(parents["records"], plan["sources"], strict=True):
        assert entry["id"] == fixture["id"]
        result = [observe(fixture, draw, plan, nets, calibration_pack["fits"], exact)
                  for draw in entry["streams"]]
        entries.append({"id": fixture["id"], "fixture": fixture, "family": fixture["geometry"]["family"], "draws": result})

    compare = (*ARMS, "fixed", "v120")
    matched = {}
    for key, recipe in calibration_pack["fits"].items():
        first, second = key.split("+")
        if recipe["calibrated"]:
            matched[key] = effects(entries, second, first, "matched", key)
    results = {
        "versus_parent": {k: effects(entries, k, "local50k", "nominal") for k in compare},
        "versus_fixed": {k: effects(entries, k, "fixed", "nominal") for k in ARMS},
        "broad_minus_center": effects(entries, ARMS[1], ARMS[0], "nominal"),
        "matched": matched,
    }
    gfx = standing(training["parent"], nets, real)
    write_json(root / "result.json", {
        "driver": reference(__file__), "training": source, "source_plan": plan_ref, "parent_predictions": parents_ref,
        "calibration": calibration_pack, "results": results, "exact": entries, "standing": gfx,
        "seconds": time.monotonic()-start,
    })


if __name__ == "__main__":
    main()
