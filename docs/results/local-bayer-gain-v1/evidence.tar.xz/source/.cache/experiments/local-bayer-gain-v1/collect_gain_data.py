"""Reduce training queries to exact overlapping-correction loss terms."""

from dataclasses import replace
import sys
import time

import numpy as np
import torch

from prepare_gain import HERE, OUT, ROLES, SALT, capture_wide
from bayer_gain_features import FEATURES, nominal_peaks, support
from freeze_nested import filtered_observation
from review_optical import bind_models, run_model
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe

QUERY = (128, 128, 256, 256)
ROI = (48, 48, 160, 160)
ROI_SL = np.s_[..., 48:208, 48:208]
WINDOW = (176, 176, 160, 160)
CROP = np.s_[..., 128:384, 128:384]
PACKED = np.s_[..., 64:192, 64:192]


def capture(fixture):
    photo = capture_wide.wire_math.decode(fixture["source"], fixture["box"])
    geo = fixture["geometry"]
    targets, _, _, _ = capture_wide.wire_math.exact(photo, geo)
    edge = capture_wide.wire_math.exact(photo, geo | {"strength": [0., 0.]})[0][2]
    constant = torch.ones_like(edge) * edge[..., 176:336, 176:336].mean((-2, -1), keepdim=True)
    natural = .075 + .67 * photo
    sources = (targets[0], targets[2], targets[3], edge, constant, natural)
    recipe = replace(sample_scene_recipe(SALT), **fixture["camera"])
    snaps = [filtered_observation(s, replace(recipe, noise_seed=seed), fixture["sigma"])
             for s, seed in zip(sources, fixture["noise_seeds"], strict=True)]
    args = {k: getattr(snaps[0], k).numpy() for k in ("colors", "wb", "matrix")}
    args |= {k: np.stack([getattr(snap, k).numpy()[PACKED] for snap in snaps])
             for k in ("packed", "variance")}
    exact = np.stack([snap.target.numpy()[CROP] for snap in snaps])
    return args, exact, snaps[0].packed.numpy()


def loss_terms(data, parent, target, scene, photo):
    peaks = nominal_peaks(scene, data["colors"], WINDOW, 48)
    wb, matrix = data["wb"], data["matrix"]
    measurements = {}
    counts = []
    for j, (packed, p, truth) in enumerate(zip(data["packed"], parent, target, strict=True)):
        scene[PACKED] = packed
        selection = support(p, ROI, scene, data["colors"], WINDOW, peaks, photo["camera"], wb, matrix)
        stat = selection.moments(p[ROI_SL], truth[ROI_SL], wb, matrix)
        counts.append(len(selection.fixed))
        if j == 0 and len(selection.fixed) and int(photo["index"]) % 16 == 0:
            # The cached quadratic must equal actual delivered luma error.
            a = np.linalg.norm(stat["gram"], axis=1)
            assert a.max() > 0
            rendered = selection.render(selection.fixed, p[ROI_SL])
            weight = (np.array([.2126,.7152,.0722]) @ matrix) * wb
            actual = (weight @ (truth[ROI_SL]-rendered).reshape(3,-1)) * 65535
            g, m, f = (stat[k] for k in ("gram","moment","fixed"))
            np.testing.assert_allclose(np.mean(actual**2)-stat["parent_mse"],
                                       f @ g @ f - 2*m @ f, rtol=.0035, atol=.024)
        assert all(np.isfinite(a).all() for a in stat.values())
        measurements |= {f"{j}_{k}": v for k, v in stat.items()}
    return measurements, counts, None if peaks is None else peaks.tolist()


@torch.inference_mode()
def main(limit=None):
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 7 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    frozen = reference(OUT / "plan.json")
    plan = read_json(checked(frozen))
    model = bind_models({"local50k": plan["checkpoint"]})["local50k"]
    store = OUT / "moments"
    store.mkdir(exist_ok=True)
    rows = []
    start = time.monotonic()
    with ieee_fp32():
        for photo in plan["cases"][:limit]:
            destination = store / f"{photo['id']}.json"
            if destination.is_file():
                row = read_json(destination)
                assert row["plan"] == frozen and row["driver"] == reference(__file__)
                checked(row["moments"])
                rows.append(row)
                continue
            args, clean, scene = capture(photo)
            out = []
            for i in range(0, len(ROLES), 3):
                batch = args | {k: args[k][i:i+3] for k in ("packed", "variance")}
                out.append(run_model(model, "local50k", batch, photo["camera"]))
            parent = np.concatenate(out, axis=0)
            values, counts, peak = loss_terms(args, parent, clean, scene.copy(), photo)
            group = store / f"{photo['id']}.npz"
            temp = group.with_suffix(".partial")
            with temp.open("wb") as stream:
                np.savez(stream, **values)
            temp.replace(group)
            row = {"id": photo["id"], "plan": frozen, "driver": reference(__file__),
                   "key": photo["source"]["id"], "pixel_hash": photo["source"]["cache_sha256"],
                   "split": photo["split"], "counts": counts, "peak": peak,
                   "input_fingerprints": {k: fingerprint(np.ascontiguousarray(v))
                                          for k,v in (args | {"scene": scene, "truth": clean}).items()},
                   "parent_fingerprint": fingerprint(parent), "moments": reference(group)}
            write_json(destination, row)
            rows.append(row)
            if len(rows) % 12 == 0:
                print("Prepared", len(rows), "sources", round(time.monotonic()-start, 1), flush=True)
    assert len(rows) == (min(limit, len(plan["cases"])) if limit is not None else len(plan["cases"]))
    name = "smoke" if limit is not None else "full"
    write_json(OUT / f"{name}-data.json", {
        "plan": frozen, "features": FEATURES, "driver": reference(__file__),
        "operator": reference(HERE / "bayer_gain_features.py"),
        "sources": rows, "seconds": time.monotonic()-start,
    })


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv)>1 else None)
