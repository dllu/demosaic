"""Fit matched small gain heads to the delivered reconstruction error."""

from copy import deepcopy
import time

import numpy as np
import torch
from torch import nn

from prepare_gain import OUT, ROLES, SALT
from bayer_gain_features import FEATURES, LOCAL_DIM
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ARMS = ("center_features", "broad_features")
HIDDEN = 24


class Gain(nn.Module):
    def __init__(self, center, spread, broad):
        super().__init__()
        self.broad = broad
        self.register_buffer("center", center)
        self.register_buffer("spread", spread)
        self.proposal = nn.Sequential(nn.Linear(len(FEATURES), HIDDEN), nn.SiLU(), nn.Linear(HIDDEN, 1))
        nn.init.zeros_(self.proposal[-1].weight)
        nn.init.zeros_(self.proposal[-1].bias)

    def forward(self, features, fixed):
        z = ((features-self.center)/self.spread).clamp(-8, 8)
        if not self.broad:
            z = torch.cat((z[..., :LOCAL_DIM], torch.zeros_like(z[..., LOCAL_DIM:])), dim=-1)
        lift = self.proposal(z).squeeze(-1)
        return (fixed + .75 * lift.tanh()).clamp(0, 1)


def read_packets(group):
    with np.load(checked(group["moments"]), allow_pickle=False) as f:
        return [{k: torch.from_numpy(f[f"{i}_{k}"]) for k in ("features", "fixed", "moment", "gram")}
                for i in range(len(ROLES)) if len(f[f"{i}_fixed"])]


def batch(packets, group_size):
    n = max(len(t["fixed"]) for t in packets)
    count = len(packets)
    features = torch.zeros(count, n, len(FEATURES))
    fixed, moment = torch.zeros(count, n), torch.zeros(count, n)
    gram = torch.zeros(count, n, n)
    for i, row in enumerate(packets):
        j = len(row["fixed"])
        features[i, :j] = row["features"]
        fixed[i, :j] = row["fixed"]
        gram[i, :j, :j] = row["gram"]
        moment[i, :j] = row["moment"]
    return features, fixed, gram, moment, group_size * len(ROLES)


def objective(fit, values, anchor):
    features, fixed, gram, moment, observations = values
    g = fit(features, fixed)
    v = g - fixed
    old = torch.bmm(gram, fixed.unsqueeze(-1)).squeeze(-1)
    now = torch.bmm(gram, v.unsqueeze(-1)).squeeze(-1)
    improvement = (v * (now + 2*(old-moment))).sum()/observations
    penalty = (v * now).sum()/observations
    return improvement + anchor * penalty, improvement.detach(), penalty.detach()


def main():
    torch.set_num_threads(2)
    source = reference(OUT / "full-data.json")
    evidence = read_json(checked(source))
    plan = read_json(checked(evidence["plan"]))
    assert tuple(evidence["features"]) == FEATURES
    for row, original in zip(evidence["sources"], plan["cases"], strict=True):
        assert row["key"] == original["source"]["id"] and row["split"] == original["split"]
    cfg = plan["optimizer"]
    train = [read_packets(r) for r in evidence["sources"] if r["split"] == "fit"]
    qualify = [read_packets(r) for r in evidence["sources"] if r["split"] != "fit"]
    assert len(train) == plan["fit_sources"] and len(qualify) == plan["qualification_sources"]
    features = torch.cat([r["features"] for g in train for r in g])
    assert torch.isfinite(features).all()
    mean = features.mean(0)
    sd = features.std(0).clamp_min(.03)

    torch.manual_seed(SALT)
    fit = {arm: Gain(mean, sd, arm == "broad_features") for arm in ARMS}
    fit[ARMS[1]].load_state_dict(fit[ARMS[0]].state_dict())
    ema = {arm: deepcopy(fit[arm]).eval().requires_grad_(False) for arm in ARMS}
    opts = {arm: torch.optim.AdamW(fit[arm].parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
            for arm in ARMS}
    qualification_batch = batch([p for source_rows in qualify for p in source_rows], len(qualify))
    rng = torch.Generator().manual_seed(SALT+1)
    target = OUT / "train"
    target.mkdir(exist_ok=True)
    history = []
    swaps = 0
    start = time.monotonic()
    for epoch in range(1, cfg["max_epochs"]+1):
        ids = torch.randperm(len(train), generator=rng).tolist()
        deltas = {arm: [] for arm in ARMS}
        for i in range(0, len(ids), cfg["batch"]):
            picked = ids[i:i+cfg["batch"]]
            rows = [p for j in picked for p in train[j]]
            if not rows:
                continue
            examples = batch(rows, len(picked))
            for arm in ARMS:
                with torch.no_grad():
                    if swaps == 0:
                        expected = examples[1]
                        torch.testing.assert_close(ema[arm](*examples[:2]), expected, rtol=0., atol=0.)
                model = fit[arm]
                optimizer = opts[arm]
                optimizer.zero_grad(set_to_none=True)
                loss, delta, anchor = objective(model, examples, cfg["l2_distance_to_fixed"])
                assert loss.isfinite()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 100, error_if_nonfinite=True)
                optimizer.step()
                with torch.no_grad():
                    for old, new in zip(ema[arm].parameters(), model.parameters(), strict=True):
                        old.lerp_(new, 1-cfg["ema"])
                deltas[arm].append([float(delta), float(anchor)])
            swaps += 1
        with torch.no_grad():
            validation = {k: [float(v) for v in objective(m, qualification_batch, cfg["l2_distance_to_fixed"])[1:]]
                          for k,m in ema.items()}
        history.append({"epoch": epoch, "updates": swaps, "fit": {
            arm: np.mean(values, axis=0).tolist() for arm, values in deltas.items()
        }, "internal_qualification": validation})
        if epoch % 4 == 0:
            print(history[-1], flush=True)

    outputs = {}
    for arm in ARMS:
        model = fit[arm]
        dest = target / f"{arm}.pt"
        state = {
            "weights": model.state_dict(), "ema": ema[arm].state_dict(), "optimizer": opts[arm].state_dict(),
            "arm": arm, "parent": plan["checkpoint"], "plan": evidence["plan"],
            "evidence": source, "features": FEATURES, "broad": model.broad, "hidden": HIDDEN,
            "steps": swaps, "epochs": cfg["max_epochs"],
        }
        with dest.open("xb") as f:
            torch.save(state, f)
        outputs[arm] = reference(dest)
    record = {"driver": reference(__file__), "evidence": source, "plan": evidence["plan"],
              "parent": plan["checkpoint"], "checkpoints": outputs, "training_seconds": time.monotonic()-start,
              "update_count_each": swaps, "total_unique_fit_native_crops": len(train)*len(ROLES),
              "crops_presented_each": len(train)*len(ROLES)*cfg["max_epochs"],
              "trainable_parameters_each": sum(p.numel() for p in fit[ARMS[0]].parameters()),
              "precision": "CPU FP32 fits, immutable CUDA IEEE FP32 EMA parent",
              "epochs": history, "complete": True}
    write_json(target / "completed.json", record)
    print("Completed", outputs, flush=True)


if __name__ == "__main__":
    main()
