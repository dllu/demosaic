"""Expose the bounded waveform and input statistics from the existing two-scale fit."""

from dataclasses import dataclass

import numpy as np

from prepare_gain import CACHE
import sys

sys.path.insert(0, str(CACHE / "local-nested-support-v1"))
from nested_gate import CenterGuard, EDGE, GAIN, OFFSET, OUTER, TAPER, WIDTH, nominal_peaks, strength, unpack

LUMA = np.array([.2126, .7152, .0722])
SIZE = 160
STRIDE = WIDTH // 2
FEATURES = (
    "held_center_min", "held_center_max", "log_raw_amplitude_in_noise",
    "log_parent_amplitude_in_noise", "parent_phase_cosine", "log_noise",
    "relative_center_activity", "frequency_radius", "frequency_ratio",
    "held_broad_min", "held_broad_max", "broad_greens_phase_cosine",
    "broad_greens_amplitude_ratio", "surround_activity", "center_surround_level_delta",
)
LOCAL_DIM = FEATURES.index("held_broad_min")
GRID = tuple((dy, dx) for dy in range(0, SIZE - WIDTH + 1, STRIDE)
             for dx in range(0, SIZE - WIDTH + 1, STRIDE))
MASS = np.zeros((SIZE, SIZE))
for gy, gx in GRID:
    MASS[gy:gy+WIDTH, gx:gx+WIDTH] += TAPER
EDGE_WEIGHT = EDGE[:, None] * EDGE[None, :] / np.maximum(.02, MASS)


def cosine(a, b):
    return float(a @ b) / max(1e-14, float(np.linalg.norm(a)*np.linalg.norm(b)))


def basis_values(tile, parent, frequency, shot, read, operator):
    data = [operator.fold(tile, j, shot, read) for j in (0, 1)]
    score_broad, score_center = (
        np.stack([a[k][1] for a in data]) for k in ("broad", "guarded")
    )
    gate = np.minimum(strength(score_broad.min(0), 6.), strength(score_center.min(0), 1.5))
    if not gate.any():
        return []
    coefficients = np.stack([a["broad"][0] for a in data])
    mixed = coefficients.mean(0)
    old = (operator.outer_parent_fit @ parent.ravel()).reshape(2, 2)
    support = tile[operator.core]
    noise = np.sqrt(max(2e-11, shot * max(0., float(support.mean())) + read))
    contrast = float(support.std()) / noise
    surrounding = float(tile.std()) / noise
    signed_gain = (float(support.mean()) - float(tile.mean())) / noise
    entries = []
    for d in np.flatnonzero(gate):
        coef, p = mixed[d], old[d]
        difference = coef - p
        raw_amplitude = float(np.linalg.norm(coef))
        size = float(np.linalg.norm(difference))
        if size < 1e-12 or raw_amplitude < 1e-12:
            continue
        cap = min(1., raw_amplitude/size)
        left, right = coefficients[:, d]
        amps = np.linalg.norm(coefficients[:, d], axis=-1)
        measures = (
            np.arcsinh(score_center[:, d].min()/3),
            np.arcsinh(score_center[:, d].max()/3),
            np.log1p(raw_amplitude/noise),
            np.log1p(np.linalg.norm(p)/noise), cosine(p, coef), np.log(noise),
            np.log1p(contrast), np.linalg.norm(frequency[d]), abs(frequency[d, 1]/frequency[d, 0]),
            np.arcsinh(score_broad[:, d].min()/6),
            np.arcsinh(score_broad[:, d].max()/6),
            cosine(left, right), np.log((amps.min()+1e-10)/(amps.max()+1e-10)),
            np.log1p(surrounding), np.arcsinh(signed_gain),
        )
        wave = operator.wave[..., d, :] @ (difference*cap)
        entries.append((measures, min(gate[d]/cap, 1.0), wave))
    return entries


@dataclass
class Support:
    features: np.ndarray
    fixed: np.ndarray
    native_lift: np.ndarray
    offsets: list
    neutral: np.ndarray

    def render(self, strength, center):
        if len(strength) == 0:
            return center
        f = np.zeros((SIZE, SIZE))
        for gain, (y, x), lift in zip(strength, self.offsets, self.native_lift, strict=True):
            f[y:y+WIDTH, x:x+WIDTH] += gain * lift
        return center + (self.neutral[:, None, None] * f).astype(center.dtype)

    def moments(self, original, exact, wb, matrix):
        weights = (LUMA @ matrix) * wb
        error = (weights @ (exact-original).reshape(3, -1)) * 65535
        n = len(self.fixed)
        if n:
            z = np.zeros((n, SIZE, SIZE), dtype=np.float32)
            neutral_luma = float(weights @ self.neutral)
            for i, ((y, x), tile) in enumerate(zip(self.offsets, self.native_lift, strict=True)):
                z[i, y:y+WIDTH, x:x+WIDTH] = tile * neutral_luma * 65535
            rows = z.reshape(n, -1)
            gram = (rows @ rows.T) / error.size
            moment = (rows @ error.astype(np.float32)) / error.size
        else:
            gram, moment = np.zeros((0, 0), "f"), np.zeros(0, "f")
        return {"features": self.features, "fixed": self.fixed, "gram": gram, "moment": moment,
                "parent_mse": np.float32(np.mean(error**2))}


def support(parent, local, scene, colors, query, peaks, noise, wb, matrix):
    x, y, w, h = local
    start_x, start_y = query[:2]
    extra = parent[1, y-OFFSET:y+h+OFFSET, x-OFFSET:x+w+OFFSET]
    assert (w, h) == (SIZE, SIZE) and extra.shape == (SIZE+2*OFFSET, SIZE+2*OFFSET)
    neutral = np.linalg.solve(matrix, np.ones(3)) / wb
    neutral = neutral / neutral[1]
    coords, feature, fixed, basis = [], [], [], []
    if peaks is not None:
        operator = CenterGuard(np.asarray(colors), start_x, start_y, peaks)
        src = unpack(scene)
        shot, read = noise["shot"], noise["read"]
        for dy, dx in GRID:
            xx, yy = start_x + dx - OFFSET, start_y + dy - OFFSET
            tile = src[yy:yy+OUTER, xx:xx+OUTER].astype(np.float64)
            guide = extra[dy:dy+OUTER, dx:dx+OUTER]
            for measures, f, wave in basis_values(tile, guide, peaks, shot, read, operator):
                coords.append((dy, dx))
                feature.append(measures)
                fixed.append(f)
                sl = np.s_[dy:dy+WIDTH, dx:dx+WIDTH]
                basis.append(GAIN * wave * TAPER * EDGE_WEIGHT[sl])
    return Support(np.asarray(feature, "f").reshape(-1, len(FEATURES)), np.asarray(fixed, "f"),
                   np.asarray(basis, "f").reshape(-1, WIDTH, WIDTH), coords, neutral)
