"""Verify ordinary whole-scene RAW donors and a paired outer-context stress."""

from dataclasses import replace
import time

import numpy as np
from scipy.ndimage import gaussian_filter
import torch

from prepare_gain import OUT, TRIAL, SALT, capture_wide
from bayer_gain_features import LUMA, nominal_peaks
from collect_gain_data import ROI, WINDOW, CROP, PACKED, ROI_SL
from freeze_nested import filtered_observation
from review_bayer_gain import ARMS, corrected, models
from review_optical import bind_models, run_model
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_training_data import scene_seed
from evaluate_ring import arrays


def errors(rgb, clean, args):
    weights = (LUMA @ args["matrix"]) * args["wb"]
    residual = (weights @ (rgb-clean).reshape(3, -1)).reshape(160,160) * 65535
    remainder = residual - gaussian_filter(residual, sigma=1.0, mode="reflect")
    return {"luma_rms": float(np.sqrt(np.mean(residual**2))), "fine_luma_rms": float(np.sqrt(np.mean(remainder**2))),
            "mean_luma_bias": float(residual.mean())}


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.cuda.set_per_process_memory_fraction(
        min(1, 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    training_ref = reference(OUT / "train/completed.json")
    trained = read_json(checked(training_ref))
    nets = models(trained)
    plan_ref = reference(TRIAL / "plan.json")
    plan = read_json(checked(plan_ref))
    sample_ref = reference(TRIAL / "inputs.json")
    ins = read_json(checked(sample_ref))
    assert ins["plan"] == plan_ref and trained["parent"] == plan["checkpoints"]["local50k"]
    base = bind_models({"local50k": trained["parent"]})["local50k"]
    start = time.monotonic()
    rows = []
    with ieee_fp32():
        for case, selection in zip(plan["sources"], ins["observations"], strict=True):
            assert case["id"] == selection["id"]
            photo = capture_wide.wire_math.decode(case["source"], case["box"])
            sensor = replace(sample_scene_recipe(SALT), **(case["camera"] | {
                "noise_seed": scene_seed(SALT, case["index"], "natural-holdout"),
            }))
            captured = filtered_observation(.075+.67*photo, sensor, plan["sigma"])
            args = {k: getattr(captured, k).numpy() for k in ("colors", "wb", "matrix")}
            scene = captured.packed.numpy()
            args |= {"packed": scene[None][PACKED], "variance": captured.variance.numpy()[None][PACKED]}
            p = run_model(base, "local50k", args, plan["noise"])[0]
            clean = captured.target.numpy()[CROP][ROI_SL]
            parent = p[ROI_SL]
            photo_outer = selection["streams"][0]["data"]
            swap = arrays(photo_outer)["scene_packed"]
            swap[PACKED] = scene[PACKED]
            values = {}
            for name, context in (("aligned", scene), ("mesh_exterior", swap)):
                freq = nominal_peaks(context, args["colors"], WINDOW, 48)
                restored, count, lift = corrected(
                    p, ROI, context, args["colors"], WINDOW, freq, plan["noise"],
                    args["wb"], args["matrix"], nets,
                )
                values[name] = {"nominated": freq is not None, "eligible_direction_windows": count,
                                "change_RGB_RMS_DN16": lift, "context_fingerprint": fingerprint(context),
                                "scores": {k: errors(v, clean, args) for k,v in ({"local50k": parent} | restored).items()}}
            rows.append({
                "id": case["id"], "fixture": case, "read_shot_seed": sensor.noise_seed,
                "noise": plan["noise"], "sigma": plan["sigma"], "mesh_exterior": photo_outer,
                "clean_fingerprint": fingerprint(clean.copy()), "parent_fingerprint": fingerprint(p),
                "query_fingerprint": fingerprint(args["packed"].copy()), "values": values,
            })
    summary = {}
    for condition in ("aligned", "mesh_exterior"):
        group = [row["values"][condition] for row in rows]
        arms = ("fixed", *ARMS)
        summary[condition] = {
            "nominated": sum(row["nominated"] for row in group),
            "active_sources": sum(row["eligible_direction_windows"] > 0 for row in group),
            "sources_with_delivery": {k: sum(row["change_RGB_RMS_DN16"][k] > 0. for row in group) for k in arms},
            "mean_RMS_difference_DN16": {k: {f: float(np.mean([
                row["scores"][k][f]-row["scores"]["local50k"][f] for row in group
            ])) for f in ("luma_rms", "fine_luma_rms")} for k in arms},
            "maximum_update_DN16": {k: max(row["change_RGB_RMS_DN16"][k] for row in group) for k in arms},
        }
    write_json(OUT / "review/natural.json", {
        "driver": reference(__file__), "training": training_ref, "inputs": sample_ref,
        "rows": rows, "summary": summary, "seconds": time.monotonic()-start, "scope": "one fresh ordinary draw/source",
    })
    print(summary, flush=True)


if __name__ == "__main__":
    main()
