"""Freeze training photographs and a fixed physical-feature gain experiment."""

from collections import Counter
from dataclasses import asdict
import hashlib
from pathlib import Path
import sys

import numpy as np

from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.scene_data import sample_scene_recipe, scene_crop_boxes
from demosaic.scene_training_data import scene_seed

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent
REPO = CACHE.parents[1]
OUT = Path("/mnt/external/demosaic") / HERE.name
TRIAL = OUT.with_name("local-nested-support-v1")
sys.path.insert(0, str(CACHE / TRIAL.name))
from freeze_nested import FAMILIES, capture_wide, carrier

SALT = 202611200125
COUNT = 192
CHECK_COUNT = 24
ROLES = ("both wires", "strong only", "flat core", "edge only", "uniform", "photograph")
PROFILES = ((.00032, 4.096e-7, .44), (.00128, 6.5536e-6, .33))
DOSES = (0., .55, .85)
OPTIMIZER = {"name": "AdamW", "lr": .004, "weight_decay": .002,
             "batch": 24, "max_epochs": 24, "ema": .98, "l2_distance_to_fixed": .025}


def identifiers(sources):
    return {row[key] for row in sources for key in ("id", "cache_sha256")}


def freeze():
    previous_ref = reference(TRIAL / "plan.json")
    prior = read_json(checked(previous_ref))
    excluded = identifiers([r["source"] for r in prior["sources"]])
    blocked = [previous_ref, *prior["excluded_manifests"]]
    manifest = reference(CACHE / "expanded-scene-epoch-corpus-v1/manifest-train.jsonl")
    # This is the already-approved training inventory, so scanning it as
    # an exclusion would remove every eligible photograph.
    for binding in blocked:
        if binding == manifest:
            continue
        path = checked(binding)
        if path.suffix == ".jsonl":
            for row in capture_wide.lines(binding):
                capture_wide.scan(row, excluded)
        else:
            capture_wide.scan(read_json(path), excluded)
    reference_replay = read_json(checked(prior["earlier_photos_excluded"]))
    for panel in reference_replay["panels"].values():
        excluded.update(identifiers(r["case"]["fixture"]["source"] for r in panel["rows"]))
    manifest_rows = [
        row for row in capture_wide.lines(manifest)
        if row["split"] == "train" and row["bin_factor"] == 4 and min(row["shape"][:2]) >= 512
        and "commons-" in row["cache"] and not {row["id"], row["cache_sha256"]} & excluded
    ]
    manifest_rows.sort(key=lambda r: hashlib.sha256(f"gain/{SALT}/{r['id']}".encode()).digest())
    cases = []
    capture_wide.SEED = SALT
    for row in manifest_rows:
        i = len(cases)
        markers = identifiers((row,))
        if not markers.isdisjoint(excluded):
            continue
        excluded.update(markers)
        (box,) = scene_crop_boxes(row["shape"][:2], patch_size=512, count=1,
                                   seed=scene_seed(SALT, i, "crop"))
        camera = asdict(sample_scene_recipe(scene_seed(SALT, i, "camera")))
        dose = DOSES[(i // 2) % 3]
        pattern = tuple(PATTERNS)[(i // 24 + i % 4) % 4]
        shot, read, exposure = PROFILES[i % 2]
        camera.update(shot=shot, read=read, exposure=exposure, black=.03, pattern=pattern)
        g = capture_wide.geometry(i)
        rng = np.random.default_rng(scene_seed(SALT, i, "geometry"))
        g.update(family=FAMILIES[(i // 6) % 4],
                 frequency=[carrier(rng, 1, (6.8, 10.3)), carrier(rng, -1, (6.8, 10.3))],
                 strength=rng.uniform([.008, .0025], [.019, .012]).tolist(),
                 gap_width=float(rng.uniform(20, 38)), gap_length=float(rng.uniform(29, 57)),
                 tint=rng.uniform(.035, .155, 3).tolist())
        cases.append({
            "id": f"gain-{i:03d}", "source": row, "box": box, "camera": camera,
            "sigma": dose, "geometry": g, "index": i, "split": "fit" if i < COUNT else "qualification",
            "noise_seeds": [scene_seed(SALT, i*len(ROLES)+j, "read-and-shot") for j in range(len(ROLES))],
        })
        if len(cases) == COUNT + CHECK_COUNT:
            break
    assert len(cases) == COUNT + CHECK_COUNT and len(identifiers(r["source"] for r in cases)) == 2*len(cases)
    for group in (cases[:COUNT], cases[COUNT:]):
        assert len({(r["geometry"]["family"], r["sigma"], r["camera"]["shot"]) for r in group}) == 24
    seeds = [seed for r in cases for seed in r["noise_seeds"]]
    assert len(set(seeds)) == len(seeds)
    return {
        "study": HERE.name, "driver": reference(__file__), "train_manifest": manifest,
        "evaluation": previous_ref, "exclusion_manifests": [r for r in blocked if r != manifest],
        "extra_optical_holdouts": prior["earlier_photos_excluded"], "seed": SALT,
        "checkpoint": prior["checkpoints"]["local50k"],
        "fixed_review": reference(TRIAL / "result-v2.json"),
        "fit_sources": COUNT, "qualification_sources": CHECK_COUNT, "roles": ROLES,
        "profiles": PROFILES, "doses_px": DOSES, "cases": cases, "optimizer": OPTIMIZER,
        "features": "per-direction Bayer and parent statistics, with or without surrounding statistics",
        "primary": "Held-out change in error of the strong strand through gaps at similar signed weak recovery.",
        "support": {"outer_cutoff": 6., "inner_cutoff": 1.5, "verification_px": 64,
                    "center_px": 32, "query_clearance": 48, "GFX_clearance": 16},
        "source_counts": dict(Counter(r["source"]["split"] for r in cases)),
    }


if __name__ == "__main__":
    result = freeze()
    write_json(OUT / "plan.json", result)
    print("Frozen", result["fit_sources"], "fit and", result["qualification_sources"], "qualification photos", flush=True)
