"""Preserve both completed component checkpoints and all evaluated evidence."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from prepare_gain import CACHE, HERE, OUT, REPO
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def main():
    refs = {k: reference(OUT / fp) for k, fp in (
        ("training", "train/completed.json"), ("review", "review/result.json"),
        ("natural", "review/natural.json"), ("cap", "review/cap.json"),
        ("smoke", "smoke-data.json"), ("train_log", "train.log"),
    )}
    train, score, natural, cap = (read_json(checked(refs[k])) for k in ("training", "review", "natural", "cap"))
    assert train["complete"] and train["update_count_each"] == 192
    assert score["training"] == natural["training"] == cap["bindings"]["training"] == refs["training"]
    assert len(score["exact"]) == len(natural["rows"]) == len(cap["rows"]) == 32
    data = read_json(checked(train["evidence"]))
    plan = read_json(checked(train["plan"]))
    assert data["plan"] == train["plan"] and len(data["sources"]) == len(plan["cases"]) == 216
    assert plan["checkpoint"] == train["parent"]
    for item in data["sources"]:
        checked(item["moments"])
    assert all(len(r["draws"])==2 for r in score["exact"])
    assert sum(d["solver_converged"] for r in cap["rows"] for d in r["draws"]) == 194
    exact = [v["native"] for row in score["exact"] for v in row["draws"] if v["native"] is not None]
    stand = [v for row in score["standing"]["rows"] for v in row["native"]]
    assert len(exact) == 2 and len(stand) == 12
    assets = REPO/"docs/assets"/HERE.name
    result = REPO/"docs/results"/HERE.name
    assets.mkdir()
    result.mkdir()
    images = []
    src = [(x[k]["image"], n) for x in exact for k,n in (("triplet",3),("board",7))]
    src.extend((x["image"], x["columns"]) for x in stand)
    for binding, n in src:
        p = checked(binding)
        with Image.open(p) as f:
            assert f.size == (8+n*168,192)
        q = assets / p.name
        shutil.copyfile(p,q)
        assert reference(q)["sha256"] == binding["sha256"]
        images.append({"path": str(q.relative_to(REPO)), "sha256": binding["sha256"]})

    archive = result/"evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=3) as tar:
        for name, binding in refs.items():
            p = checked(binding)
            tar.add(p, arcname=f"receipts/{name}{p.suffix}", recursive=False)
        for name, binding in (("plan", train["plan"]), ("loss-terms", train["evidence"])):
            tar.add(checked(binding), arcname=f"receipts/{name}.json", recursive=False)
        for arm, binding in train["checkpoints"].items():
            tar.add(checked(binding), arcname=f"weights/{arm}.pt", recursive=False)
        for item in (train, score, natural, cap, data, plan, {"driver":data["operator"]}):
            p = checked(item["driver"])
            tar.add(p, arcname="source/"+str(p.relative_to(REPO)), recursive=False)
        for p in (Path(__file__), CACHE/"local-nested-support-v1/nested_gate.py",
                  CACHE/"local-center-guard-v1/center_guard.py", REPO/"src/demosaic/mesh_carrier_fit.py"):
            tar.add(p, arcname="source/"+str(p.relative_to(REPO)), recursive=False)
    write_json(result/"publication.json", {
        "study": HERE.name, "scope": "Two completed scoped gain heads attached to Local 50k EMA",
        "training": refs["training"], "review": refs["review"], "natural": refs["natural"], "cap": refs["cap"],
        "parent": train["parent"], "checkpoints": train["checkpoints"], "weights": "EMA",
        "archive": {"path": str(archive.relative_to(REPO)), "sha256": reference(archive)["sha256"]},
        "train_seconds": train["training_seconds"], "capture_and_moments_seconds": data["seconds"],
        "unique_sources": plan["fit_sources"], "qualification_sources": plan["qualification_sources"],
        "updates_each": train["update_count_each"], "native_crop_presentations_each": train["crops_presented_each"],
        "results": score["results"], "gain_cap": cap["saturation"], "cap_results": cap["results"],
        "natural_results": natural["summary"], "matching": score["calibration"]["fits"],
        "native_figures_viewed": len(images), "images": images,
        "both_standing_cases": [r["id"] for r in score["standing"]["rows"]],
        "fixed_general_panels": "Outside this targeted component experiment; no new full427 or camera evaluations.",
    })


if __name__ == "__main__":
    main()
