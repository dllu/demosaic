"""Separate learned gain selection from amplitude saturation and basis capacity."""

import time

import numpy as np
from scipy.optimize import minimize
import torch

from prepare_gain import OUT, TRIAL
from bayer_gain_features import support, nominal_peaks
from collect_gain_data import ROI, WINDOW, PACKED, ROI_SL
from review_bayer_gain import ARMS, models, effects, scorer
from evaluate_ring import arrays
from demosaic.experiments.artifacts import checked, read_json, reference, write_json


def solve(fitted, parent, clean, wb, matrix, start):
    terms = fitted.moments(parent, clean, wb, matrix)
    gram = terms["gram"].astype("d")
    moment = terms["moment"].astype("d")

    def evaluate(weights):
        projected = gram @ weights
        return float(weights @ (projected-2*moment)), 2*(projected-moment)

    result = minimize(evaluate, start.astype("d"), jac=True, method="L-BFGS-B",
                      bounds=[(0.,1.)]*len(start), options={"ftol": 1e-10, "maxiter": 600, "gtol":1e-6})
    assert np.isfinite(result.x).all()
    assert result.fun <= evaluate(start)[0] + .002
    return result.x, bool(result.success)


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    refs = {k: reference(p) for k,p in (
        ("training", OUT / "train/completed.json"), ("review", OUT / "review/result.json"),
        ("source", TRIAL / "plan.json"), ("parents", TRIAL / "parent/result.json"),
    )}
    plan = read_json(checked(refs["source"]))
    training = read_json(checked(refs["training"]))
    parents = read_json(checked(refs["parents"]))
    review = read_json(checked(refs["review"]))
    nets = models(training)
    start = time.monotonic()
    rows = []
    sat = {k: [[] for _ in plan["roles"]] for k in ARMS}
    for p,f,baseline in zip(parents["records"], plan["sources"], review["exact"], strict=True):
        assert p["id"] == f["id"] == baseline["id"]
        values = []
        for row, old in zip(p["streams"], baseline["draws"], strict=True):
            parent = np.load(checked(row["outputs"]["local50k"]), allow_pickle=False)
            data = arrays(row["data"])
            scene = data["scene_packed"].copy()
            wb, mat, colors = (data[k] for k in ("wb","matrix","colors"))
            peaks = nominal_peaks(scene, colors, WINDOW, 48)
            cap, oracle = parent.copy(), parent.copy()
            status = []
            delivered = []
            for i, packed in enumerate(data["packed"]):
                scene[PACKED] = packed
                a = support(parent[i], ROI, scene, colors, WINDOW, peaks, plan["noise"], wb, mat)
                if not len(a.fixed):
                    continue
                assert len(a.fixed) == old["active_directions"][i]
                args = torch.from_numpy(a.features), torch.from_numpy(a.fixed)
                by_head = [nets[k](*args).numpy() for k in ARMS]
                for k,x in zip(ARMS,by_head,strict=True):
                    sat[k][i].append(x)
                local = parent[i][ROI_SL]
                top = np.ones_like(a.fixed)
                cap[i][ROI_SL] = a.render(top, local)
                choice, ok = solve(a, local, data["target"][i][ROI_SL], wb, mat, by_head[-1])
                status.append(ok)
                oracle[i][ROI_SL] = a.render(choice, local)
                delivered.append(len(a.fixed))
            measure = scorer(data, data["sharp_target"], f["geometry"], parent)
            values.append({
                "draw": row["draw"], "solver_converged": sum(status), "solver_problems": len(status),
                "eligible_windows": delivered,
                "nominal": old["nominal"] | {"full_cap": measure(cap), "oracle": measure(oracle)},
            })
        rows.append({"id": p["id"], "family": f["geometry"]["family"], "draws": values})
    summary = {}
    for k, accounts in sat.items():
        values = {}
        for role, chunks in zip(plan["roles"], accounts, strict=True):
            if not chunks:
                values[role] = {"accepted": 0}
                continue
            p = np.concatenate(chunks)
            values[role] = {"accepted": len(p), "at_cap": int(np.count_nonzero(p == 1.)),
                            "percentiles": np.quantile(p,[.05,.5,.95]).tolist()}
        summary[k] = values
    effects_ = {
        "learned_broad_minus_cap": effects(rows, "broad_features", "full_cap", "nominal"),
        "oracle_minus_learned_broad": effects(rows, "oracle", "broad_features", "nominal"),
        "cap_minus_fixed": effects(rows, "full_cap", "fixed", "nominal"),
    }
    write_json(OUT / "review/cap.json", {
        "driver": reference(__file__), "bindings": refs, "saturation": summary, "results": effects_,
        "rows": rows, "seconds": time.monotonic()-start,
        "oracle": "Exact clean luma errors, fit each held receipt, bounded coordinate gains, diagnostic only.",
    })
    print(summary, flush=True)


if __name__ == "__main__":
    main()
