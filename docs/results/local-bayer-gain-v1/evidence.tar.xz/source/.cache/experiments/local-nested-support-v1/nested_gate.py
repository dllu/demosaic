"""Compare broad, central and intersected Bayer support for the same fit."""

import sys

import numpy as np

from freeze_nested import CACHE, POLICIES
from demosaic.mesh_carrier_fit import _spacing

sys.path[:0] = [str(CACHE / name) for name in ("local-center-guard-v1", "local-exterior-phase-transfer-v1")]
from center_guard import CenterGuard
from ring_refit import EDGE, GAIN, OFFSET, OUTER, TAPER, WIDTH, unpack

BASE_CLEARANCE = 16
FRESH_CLEARANCE = 48
METHODS = tuple(POLICIES)


def strength(score, cutoff):
    excess = np.maximum(0., score - cutoff)
    return excess / (excess + cutoff)


def fields(a, b, policies):
    broad = np.minimum(a["broad"][1], b["broad"][1])
    central = np.minimum(a["guarded"][1], b["guarded"][1])
    gates = {}
    for name, policy in policies.items():
        parts = []
        if "outer_cutoff" in policy:
            parts.append(strength(broad, policy["outer_cutoff"]))
        if "center_cutoff" in policy:
            parts.append(strength(central, policy["center_cutoff"]))
        gates[name] = np.min(parts, axis=0)
    return gates


def apply(parent, local, scene, colors, roi, peaks, profile):
    x, y, w, h = local
    parent_roi = parent[..., y:y+h, x:x+w]
    extra = parent[1, y-OFFSET:y+h+OFFSET, x-OFFSET:x+w+OFFSET]
    wx, wy = roi[:2]
    assert roi[2:] == (w, h) == (160, 160) and extra.shape == (192, 192)
    changed = {k: parent_roi for k in METHODS}
    count = {k: np.zeros(2, dtype=np.int32) for k in METHODS}
    if peaks is None:
        return changed, {k: r.tolist() for k, r in count.items()}
    operator = CenterGuard(colors, wx, wy, peaks)
    raw = unpack(scene)
    total = {k: np.zeros((h, w)) for k in METHODS}
    mass = np.zeros((h, w))
    for dy in range(0, h - WIDTH + 1, WIDTH//2):
        for dx in range(0, w - WIDTH + 1, WIDTH//2):
            px, py = wx + dx - OFFSET, wy + dy - OFFSET
            tile = raw[py:py+OUTER, px:px+OUTER].astype(np.float64)
            both = [operator.fold(tile, fold, profile["shot"], profile["read"]) for fold in (0, 1)]
            for r in both:
                np.testing.assert_array_equal(r["broad"][0], r["guarded"][0])
            gains = fields(*both, POLICIES)
            coef = (both[0]["broad"][0] + both[1]["broad"][0]) / 2
            old = (operator.outer_parent_fit @ extra[dy:dy+OUTER, dx:dx+OUTER].ravel()).reshape(2, 2)
            target = coef - old
            extent = np.linalg.norm(coef, axis=1)
            sl = np.s_[dy:dy+WIDTH, dx:dx+WIDTH]
            for k, factors in gains.items():
                correction = target * factors[:, None]
                size = np.linalg.norm(correction, axis=1).clip(min=1e-12)
                correction *= np.minimum(1., extent / size)[:, None]
                total[k][sl] += np.sum(operator.wave * correction[None, None], axis=(2, 3)) * TAPER
                count[k] += factors > 0
            mass[sl] += TAPER
    neutral = np.linalg.solve(profile["matrix"], np.ones(3)) / profile["wb"]
    neutral /= neutral[1]
    for k, items in total.items():
        wave = items / np.maximum(.02, mass) * EDGE[:, None] * EDGE[None, :]
        changed[k] = parent_roi + (GAIN * neutral[:, None, None] * wave).astype(parent.dtype)
    return changed, {k: r.tolist() for k, r in count.items()}


def nominal_peaks(scene, colors, roi, clearance):
    return _spacing(scene, colors, *roi[:2], clearance=clearance)
