"""Recompute responses, audit role-specific selections and render all camera arms."""

from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image
from report_fold_support_pooling import insert_camera_panels

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
ROI = np.s_[..., 128:384, 128:384]
METRICS = (
    "quiet_RMS_DN16",
    "query_RMS_DN16",
    "weak_increment_RMS_DN16",
    "weak_gain",
    "strong_gain",
    "weak_absent_projection",
)
CAMERA_LABELS = {"planar": "Spectral rank", "near": "Near rank", "scene": "Scene rank"}


def direct(parent, truth, quiet, cropped, alpha):
    out = parent.copy()
    out[ROI] += (cropped.astype(np.float64) - parent[ROI]) * alpha
    error = out - truth
    weak, strong = truth[2] - truth[1], truth[1] - truth[0]
    return (
        np.mean((error[ROI][..., quiet] * 65535) ** 2),
        np.mean((error[ROI] * 65535) ** 2),
        np.mean(((error[2] - error[1]) * 65535) ** 2),
        np.vdot(out[2] - out[1], weak) / np.vdot(weak, weak),
        np.vdot(out[1] - out[0], strong) / np.vdot(strong, strong),
        np.vdot(error[1], weak) / np.vdot(weak, weak),
    )


def synthetic(plan, report, collection):
    archived = read_json(checked(plan["base_collection"]))
    prior = {row["id"]: row for row in archived["synthetic"]}
    old = read_json(checked(plan["previous_plan"]))
    ox, oy = plan["synthetic_appearance_stress"]["xy_offset"]
    correct = {(x + ox, y + oy, w, h) for x, y, w, h in (old["left_xywh"], old["right_xywh"])}
    wrong = {
        (x + ox, y + oy, w, h) for x, y, w, h in plan["synthetic_appearance_stress"]["decoy_boxes"]
    }
    counts = defaultdict(Counter)
    choices = []
    numeric = defaultdict(list)
    witnessed = 0
    for row in collection["synthetic"]:
        case = read_json(checked(row["case"]))
        assert row["case"] == prior[row["id"]]["case"]
        checked(case["sensor"])
        assert len({value["preview"]["sha256"] for value in row["rankings"]}) == 3
        identities = case["metadata"]["identities"] + [m["identity"] for m in row["decoys"]]
        assert len(set(identities)) == len(identities)
        for declaration in row["decoys"]:
            checked(declaration["raw"])
        item = {"id": row["id"], "kind": case["kind"], "selection": []}
        for role, ranking in enumerate(row["rankings"]):
            item["selection"].append({})
            for arm, fit in ranking["fits"].items():
                boxes = {tuple(box) for box in fit.get("donor_boxes", [])}
                label = (
                    "correct"
                    if boxes == correct
                    else "decoy"
                    if boxes == wrong
                    else "other"
                    if boxes
                    else "fallback"
                )
                counts[arm, role, case["profile"], case["placement"]][label] += 1
                item["selection"][-1][arm] = {"pair": label, "validated": any(fit["active"])}
        choices.append(item)
        parent = np.load(checked(case["parent"])).astype(np.float64)
        with np.load(checked(case["target"])) as f:
            truth, quiet = f["target"].astype(np.float64), f["quiet"][ROI]
        with (
            np.load(checked(row["prediction"])) as restored,
            np.load(checked(prior[row["id"]]["prediction"])) as baseline,
        ):
            for key in restored.files:
                if key.startswith("guarded--"):
                    np.testing.assert_array_equal(restored[key], baseline[key])
                    witnessed += 1
            for j, agg in enumerate(report["aggregates"]):
                s = agg["setting"]
                if (case["profile"], case["placement"]) != (s["profile"], s["placement"]):
                    continue
                if agg["kind"] not in ("all", case["kind"]):
                    continue
                for arm in plan["arms"]:
                    px = restored[f"{arm}--t{s['threshold']:g}"]
                    for mode, scale in (
                        ("fixed", s["scale"]),
                        ("matched", agg["matched"][arm]["scale"]),
                    ):
                        numeric[j, arm, mode].append(direct(parent, truth, quiet, px, scale))
    for (j, arm, mode), rows in numeric.items():
        mean = np.mean(rows, axis=0)
        mean[:3] **= 0.5
        expected = report["aggregates"][j][mode][arm]
        np.testing.assert_allclose(mean, [expected[m] for m in METRICS], atol=1e-10, rtol=1e-10)
    for row in report["boards"]:
        with (
            Image.open(checked(row["board"]["image"])) as a,
            Image.open(checked(row["triplet"]["image"])) as b,
        ):
            for label in ("Noisy Malvar", "Scene context", "Exact GT"):
                crops = []
                for im, kind in ((a, "board"), (b, "triplet")):
                    (field,) = [p for p in row[kind]["panels"] if p["label"] == label]
                    x, y, w, h = field["png_xywh"]
                    assert (w, h) == (160, 160)
                    crops.append(im.crop((x, y, x + w, y + h)))
                np.testing.assert_array_equal(*crops)
    return {
        "baseline_arrays_exact": witnessed,
        "independent_metrics": len(numeric) * len(METRICS),
        "choices": choices,
        "counts": {"-".join(map(str, k)): v for k, v in counts.items()},
    }


def camera(plan, report, collection):
    source = read_json(checked(plan["camera_baseline"]))
    out = ROOT / "review/all-arms"
    out.mkdir()
    cells = []
    for row, record, old in zip(
        report["camera"], collection["camera"], source["camera"], strict=True
    ):
        assert row["id"] == record["id"] == old["id"]
        x, y, w, h = row["ROI_xywh"]
        sc = row["source"]
        qx, qy, *_ = sc["query_box"]
        window = np.s_[:, y - qy : y - qy + h, x - qx : x - qx + w]
        with np.load(checked(sc["query_arrays"])) as sensor:
            ctx = {k: sensor[k] for k in ("wb", "matrix")}
        raw_parent = np.load(checked(sc["parent_prediction"]), mmap_mode="r")[
            0, :, y : y + h, x : x + w
        ]
        with np.load(checked(row["crosscheck_prediction"])) as control:
            guided = control["corrected"][window].astype(np.float64)
        actual, distance, rendered = {}, {}, []
        for arm, info in record["predictions"].items():
            with np.load(checked(info)) as f:
                predicted = f["corrected"]
            actual[arm] = predicted[window].astype(np.float64)
            distance[arm] = {
                "vs_parent_DN16": float(np.sqrt(np.mean((actual[arm] - raw_parent) ** 2)) * 65535),
                "vs_guarded_DN16": float(np.sqrt(np.mean((actual[arm] - guided) ** 2)) * 65535),
            }
            image = display(predicted[None], ctx, exposure=row["display_exposure"])[0][window]
            rendered.append(
                (CAMERA_LABELS[arm], np.rint(image.transpose(1, 2, 0) * 255).astype(np.uint8))
            )
        np.testing.assert_allclose(
            distance["scene"]["vs_guarded_DN16"], row["change_DN16"], atol=1e-12, rtol=0
        )
        for arm in ("near", "scene"):
            distance[arm]["vs_spectral_DN16"] = float(
                np.sqrt(np.mean((actual[arm] - actual["planar"]) ** 2)) * 65535
            )
        distance["scene"]["vs_near_DN16"] = float(
            np.sqrt(np.mean((actual["scene"] - actual["near"]) ** 2)) * 65535
        )
        keep = {"Noisy Malvar", "V120 EMA", "Cross-checked guide", "ISO100 AHD ref"}
        selected = [p for p in old["panels"] if p["label"] in keep or "JPEG" in p["label"]]
        img, panels = insert_camera_panels(
            out, row["id"], old | {"panels": selected}, "Cross-checked guide", rendered
        )
        cells.append(
            {
                "id": row["id"],
                "image": img,
                "panels": panels,
                "distance": distance,
                "boxes": {arm: v.get("donor_boxes") for arm, v in record["fits"].items()},
                "active": {arm: v["active"] for arm, v in record["fits"].items()},
                "period_pixels": {
                    arm: [
                        float(1 / np.linalg.norm(f))
                        for f, a in zip(v.get("frequencies_xy", []), v["active"])
                        if a
                    ]
                    for arm, v in record["fits"].items()
                },
            }
        )
    return cells


def main():
    result = ROOT / "review/result.json"
    report = read_json(result)
    plan = read_json(checked(report["plan"]))
    collection = read_json(checked(report["collection"]))
    metrics = synthetic(plan, report, collection)
    cameras = camera(plan, report, collection)
    write_json(
        ROOT / "review/audit.json",
        {
            "producer": reference(__file__),
            "report": reference(result),
            "synthetic": metrics,
            "camera": cameras,
        },
    )
    write_json(ROOT / "review/view-input.json", {"boards": report["boards"], "camera": cameras})


if __name__ == "__main__":
    main()
