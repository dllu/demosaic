"""Check ranking sensitivity to the affinity weight on the declared synthetic donors."""

from collections import Counter
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.search_donor_geometry import _matching_peaks, _native, _screen_peaks, screening_mask

root = Path(__file__).resolve().parent
done_path = root / "output/collection.json"
done = read_json(done_path)
plan = read_json(checked(done["plan"]))
prior = read_json(checked(plan["previous_plan"]))
offset = plan["synthetic_appearance_stress"]["xy_offset"]
boxes = [
    (x + offset[0], y + offset[1], w, h)
    for x, y, w, h in [
        prior["left_xywh"],
        prior["right_xywh"],
        *plan["synthetic_appearance_stress"]["decoy_boxes"],
    ]
]
counts = {
    role: {
        name: Counter()
        for name in ("spectral", "near_rank", "scene_rank", "scene_double", "scene_affinity_only")
    }
    for role in ("all", "two-family")
}
records = []
for row in done["synthetic"]:
    case = read_json(checked(row["case"]))
    noise = plan["profiles"][case["profile"]]
    spectra = []
    for item, box in zip(row["decoys"], boxes, strict=True):
        with np.load(checked(item["raw"])) as f:
            raw, layout = _native(f["packed"], f["colors"], box)
        spectra.append(
            _screen_peaks(raw, layout, screening_mask(box), noise["shot"], noise["read"])
        )
    energies = np.array(
        [
            sum(entry[0] for entry in _matching_peaks(spectra[i], spectra[i + 1], 0.5))
            for i in (0, 2)
        ]
    )
    trials = []
    for role, f in enumerate(row["rankings"]):
        near, scene = (
            np.asarray(f["affinities"][key]).reshape(2, 2).min(1) for key in ("near", "scene")
        )
        options = (
            ("spectral", energies),
            ("near_rank", energies * near),
            ("scene_rank", energies * scene),
            ("scene_double", energies * scene**2),
            ("scene_affinity_only", (energies > 0) * scene),
        )
        for key, value in options:
            choice = (
                "unavailable"
                if not np.any(value)
                else "correct"
                if value.argmax() == 0
                else "decoy"
            )
            counts["all"][key][choice] += 1
            if role == 2:
                counts["two-family"][key][choice] += 1
            if key in ("spectral", "near_rank", "scene_rank"):
                arm = {"spectral": "planar", "near_rank": "near", "scene_rank": "scene"}[key]
                expected = set(map(tuple, f["fits"][arm].get("donor_boxes", [])))
                selected = (
                    set()
                    if choice == "unavailable"
                    else set(boxes[:2] if choice == "correct" else boxes[2:])
                )
                assert expected == selected
        trials.append({"near_affinity": near.tolist(), "scene_affinity": scene.tolist()})
    records.append({"id": row["id"], "energies": energies.tolist(), "roles": trials})
write_json(
    root / "review/weight-sensitivity.json",
    {
        "source": reference(done_path),
        "producer": reference(__file__),
        "counts": counts,
        "rows": records,
        "scope": "Post-run ranking diagnostics only. Double weight squares the saved full-scene affinity. The affinity-only check still requires a spectral match. These variants produce no new denoised images.",
    },
)
