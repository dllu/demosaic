"""Show selected camera field geometry using unresized V120 preview pixels."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from demosaic.archive_metrics import display
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

root = Path(__file__).resolve().parent
plan = read_json(root / "plan.json")
old = {r["id"]: r for r in read_json(checked(plan["camera_baseline"]))["camera"]}
result = read_json(root / "output/camera-collection.json")
rows = [
    q
    for q in result["camera"]
    if q["fits"]["planar"].get("donor_boxes") != q["fits"]["scene"].get("donor_boxes")
]
if not rows:
    raise SystemExit("Selected boxes are identical")
sheet = Image.new("RGB", (698, len(rows) * 162), "#eeeeee")
draw = ImageDraw.Draw(sheet)
cells = []
for i, record in enumerate(rows):
    row = old[record["id"]]
    source = row["source"]
    name = record["id"]
    qx, qy, qw, qh = source["absolute_query_xywh"]
    ox, oy, *_ = record["frame"]
    with np.load(checked(source["query_arrays"])) as f:
        ctx = {k: f[k] for k in ("wb", "matrix")}
    parent = np.load(checked(source["parent_prediction"]), mmap_mode="r")
    a = record["fits"]["planar"].get("donor_boxes", [None, None])
    b = record["fits"]["scene"].get("donor_boxes", [None, None])
    q = [qx + qw // 2 - 64, qy + qh // 2 - 64, 128, 128]
    draw.text((8, i * 162 + 2), name, fill="black")
    labels = (
        "Spectral donor 1",
        "Spectral donor 2",
        "Query center",
        "Scene donor 1",
        "Scene donor 2",
    )
    for j, (label, box) in enumerate(zip(labels, [*a, q, *b], strict=True)):
        x, y = 8 + 138 * j, i * 162 + 29
        draw.text((x, y - 13), label, fill="black")
        if box is None:
            continue
        lx, ly, w, h = box
        cam = parent[..., ly - oy : ly - oy + h, lx - ox : lx - ox + w]
        patch = display(cam, ctx, exposure=row["display_exposure"])[0]
        pixels = np.rint(patch.transpose(1, 2, 0) * 255).astype(np.uint8)
        assert pixels.shape == (128, 128, 3)
        sheet.paste(Image.fromarray(pixels), (x, y))
        cells.append(
            {
                "id": name,
                "label": label,
                "source_xywh": box,
                "png_xywh": [x, y, w, h],
                "parent": source["parent_prediction"],
                "exposure": row["display_exposure"],
            }
        )
png = root / "diagnostic/selected-neighborhoods.png"
sheet.save(png)
write_json(
    root / "diagnostic/neighborhoods.json",
    {"image": reference(png), "cells": cells, "generator": reference(__file__)},
)
