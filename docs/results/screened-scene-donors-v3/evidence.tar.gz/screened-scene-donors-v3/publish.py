"""Publish inspected native comparisons and immutable source receipts."""

import gzip
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
REPO = Path.cwd()
IMAGES = REPO / "docs/images" / ROOT.name
RESULTS = REPO / "docs/results" / ROOT.name
IMAGES.mkdir()
RESULTS.mkdir()

report = read_json(ROOT / "review/result.json")
plan = read_json(checked(report["plan"]))
collection = read_json(checked(report["collection"]))
audit = read_json(ROOT / "review/audit.json")
assert len(report["boards"]) == 2 and len(report["camera"]) == 8

noise = {
    r["board"]["id"]: r["noise"] for r in read_json(checked(plan["camera_conditions"]))["camera"]
}


def copy(binding):
    source = checked(binding)
    output = IMAGES / source.name
    shutil.copyfile(source, output)
    assert reference(output)["sha256"] == binding["sha256"]
    return source.name


synthetic = []
for row in report["boards"]:
    case = read_json(checked(row["case_receipt"]))
    synthetic.append(
        {
            **{k: v for k, v in row.items() if k not in ("board", "triplet")},
            "checkpoint": plan["parent_checkpoint"],
            "noise": case["metadata"]["noise"],
            "CFA": case["CFA"],
            "renderings": {
                k: row[k] | {"file": copy(row[k]["image"])} for k in ("board", "triplet")
            },
        }
    )

camera = []
for row, stats, source in zip(report["camera"], audit["camera"], collection["camera"], strict=True):
    assert row["id"] == stats["id"] == source["id"]
    kind = "main" if row["id"].startswith("main-") else "mesh"
    x, y, w, h = row["ROI_xywh"]
    qx, qy, *_ = row["source"]["query_box"]
    ax, ay, *_ = row["source"]["absolute_query_xywh"]
    camera.append(
        {
            **stats,
            "file": copy(stats["image"]),
            "source": plan["photos"][kind],
            "calibration_and_inputs": row["source"]["query_arrays"],
            "checkpoint": row["source"]["checkpoint"],
            "prediction_receipts": source["predictions"],
            "x_y_width_height": [x + ax - qx, y + ay - qy, w, h],
            "display_exposure": row["display_exposure"],
            "noise": noise[row["id"]],
            "context_native_hw": source["native_hw"],
            "preview_hw": source["preview_hw"],
            "screening_preview_fingerprint": source["preview_fingerprint"],
            "reference_capture": "DSCF3880 ISO100 AHD"
            if kind == "main"
            else "DSCF3835 ISO100 AHD and camera JPEG",
        }
    )
neighborhoods = read_json(ROOT / "diagnostic/neighborhoods.json")
manifest = IMAGES / "manifest.json"
write_json(
    manifest,
    {
        "viewed_local": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(timespec="seconds"),
        "native_viewing_layouts": read_json(ROOT / "native-view/items.json"),
        "source_scene_encoder_revision": plan["encoder_revision"],
        "source_scene_encoder_weights": [
            p for p in plan["inputs"] if p["path"].endswith("model.safetensors")
        ],
        "synthetic": synthetic,
        "camera": camera,
        "selected_donor_geometry": neighborhoods | {"file": copy(neighborhoods["image"])},
        "scope": "Ten native full comparison boards, two separate native triplets and sampled neighborhood cells were inspected. ISO100 AHD and JPEG columns are independent references.",
    },
)
shutil.copyfile(ROOT / "review/audit.json", RESULTS / "independent-audit.json")
shutil.copyfile(ROOT / "review/weight-sensitivity.json", RESULTS / "weight-sensitivity.json")
members = [
    (ROOT, p)
    for p in (
        "plan.json",
        "collect.log",
        "output/collection.json",
        "output/camera-collection.json",
        "review/result.json",
        "review/audit.json",
        "diagnostic/neighborhoods.json",
        "review/weight-sensitivity.json",
        "rank-diagnostic.py",
        "native-view/items.json",
        "audit.py",
        "neighborhoods.py",
        "publish.py",
        "work/src/demosaic/screened_scene_donors.py",
        "work/src/demosaic/search_donor_geometry.py",
        "work/src/demosaic/local_validated_waves.py",
        "work/scripts/probe_screened_scene_donors.py",
        "work/scripts/probe_search_donor_geometry.py",
    )
]
members += [
    (ROOT.parent / f"screened-scene-donors-{version}", p)
    for version in ("v1", "v2")
    for p in ("plan.json", "collect.log")
]
archive = RESULTS / "evidence.tar.gz"
with (
    archive.open("xb") as handle,
    gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as encoded,
    tarfile.open(fileobj=encoded, mode="w") as tf,
):
    for directory, item in members:
        path = directory / item
        t = tf.gettarinfo(str(path), arcname=f"{directory.name}/{item}")
        t.mtime = t.uid = t.gid = 0
        t.uname = t.gname = ""
        with path.open("rb") as stream:
            tf.addfile(t, stream)
with tarfile.open(archive) as tf:
    for directory, item in members:
        assert tf.extractfile(f"{directory.name}/{item}").read() == (directory / item).read_bytes()
write_json(
    RESULTS / "publication.json",
    {
        "archive": reference(archive),
        "verified_members": len(members),
        "native_manifest": reference(manifest),
        "independent_audit": reference(RESULTS / "independent-audit.json"),
        "weight_sensitivity": reference(RESULTS / "weight-sensitivity.json"),
        "comparison_boards_viewed": 10,
        "triplets_viewed": 2,
        "neighborhoods_viewed": 1,
        "partial_runs": {
            "v1": "Stopped to reserve screening pixels from query scoring.",
            "v2": "A synthetic decoy's overlapping modulation exceeded the dark background. Re-declared its brightness before resuming from the original saved inputs.",
        },
    },
)
