"""Render measured green candidates on native exact-target and camera crops."""

from pathlib import Path
import sys

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from evaluate_green import ROOT, ARGS, as_cuda, bind_models, inputs, restore
from alias_panel import read_observation
from report_scene_wave_guides import native_board
import render_repeat

WITHHELD = ROOT.parent / "quincunx-withheld-v2"
sys.path.insert(0, str(WITHHELD))
from compare_folds import restore as restore_withheld
from collect import value

LABEL = {
    "100k": "Corpus 100k EMA",
    "quiet": "Quiet path",
    "uniform": "Fixed fine lift",
    "principal": "Principal class",
    "split": "Both classes",
    "withheld-split": "Disjoint fold support",
    "full": "Both classes, original strength",
}


def all_versions(model, args, parent, thresholds, strengths, held):
    prediction = restore(model, args, parent, thresholds)
    q = prediction["quiet"]
    variant = restore_withheld(model, args, parent, thresholds)["withheld-split"]
    return {
        "100k": parent.cpu().numpy(),
        "quiet": q.cpu().numpy(),
        "full": prediction["split"].cpu().numpy(),
        **{
            k: (q + strengths[k] * (prediction[k] - q)).cpu().numpy()
            for k in ("uniform", "principal", "split")
        },
        "withheld-split": (q + held["withheld-split"] * (variant - q)).cpu().numpy(),
    }


def make_board(output, id, raw, results, row, role, roi, source_noise, via, names=tuple(LABEL)):
    fields = {
        k: raw[k][role : role + 1]
        if k in ("packed", "variance")
        or raw[k].ndim == len({"colors": (4,), "wb": (3,), "matrix": (3, 3)}.get(k, ())) + 1
        else raw[k][None]
        for k in ARGS
    }
    rendered = [noisy_malvar(fields)[0], *[results[k][role] for k in names], raw["target"][role]]
    return native_board(
        output,
        id,
        rendered,
        fields,
        row,
        labels=("Noisy Malvar", *[LABEL[k] for k in names], "Exact GT"),
        triplet_indices=(0, names.index(via) + 1, len(rendered) - 1),
        exposure=1 / source_noise["exposure"],
        contrast=2,
        roi=tuple(roi),
    )


def natural(model, limits, strength, held, report, config, out):
    parents = read_json(checked(config["parents"]))
    stored = {row["id"]: row for row in parents["records"]}
    panel = read_json(checked(config["panel"]))
    selected = [
        r
        for r in report["rows"]
        if r["profile"] == "iso6400" and r["draw"] == "independent" and r["index"] >= 32
    ]
    assert len(selected) == 32

    def delta(row, kind):
        return (
            value(row["scores"]["split"], strength["split"])[kind]
            - value(row["scores"]["uniform"], strength["uniform"])[kind]
        )

    rank = sorted(selected, key=lambda r: delta(r, "increment"))
    examples = [
        (rank[0], 0, "Smallest true increment error change against the fixed lift."),
        (rank[-1], 0, "Largest true increment error change against the fixed lift."),
        (max(selected, key=lambda r: delta(r, "flat")), 2, "Largest increase of exact-flat RMS."),
    ]
    boards = []
    for row, role, why in examples:
        i = row["id"]
        case, raw, baseline = inputs(stored[i])
        spec = panel["rows"][case["case"]]
        args = as_cuda(
            {
                k: raw[k]
                if k in ("packed", "variance")
                else np.broadcast_to(raw[k], (3, *raw[k].shape))
                for k in ARGS
            }
        )
        restored = all_versions(
            model,
            args,
            torch.from_numpy(baseline).cuda().contiguous(memory_format=torch.channels_last),
            limits,
            strength,
            held,
        )
        boards.append(
            make_board(
                out,
                f"{i}-role{role}",
                raw,
                restored,
                {
                    "source": spec["source"],
                    "CFA": spec["camera"]["pattern"],
                    "query": case["box"],
                    "profile": case["profile"],
                    "why": why,
                    "role": role,
                },
                role,
                panel["native_display_ROI_xywh"],
                case["profile"],
                "split",
            )
        )
    return boards


def alias(report, output):
    inputs = read_json(checked(report["inputs"]))
    plan = read_json(checked(inputs["plan"]))
    rows = [r for r in report["rows"] if r["family"] == "shared-alias"]

    def response(row):
        a, b = (row["metrics"][k] for k in ("split", "principal"))
        return (a["dot"] - b["dot"]) / a["target_energy"]

    def leakage(row):
        a, b = (row["metrics"][k] for k in ("split", "principal"))
        return a["absent_carrier_ratio"] - b["absent_carrier_ratio"]

    rank = sorted(rows, key=response)
    examples = [
        (
            rank[-1],
            0,
            "Largest target-aligned split-class response increase versus principal-only.",
        ),
        (rank[0], 0, "Largest target-aligned split-class response decrease versus principal-only."),
        (max(rows, key=leakage), 1, "Largest absent-carrier error increase versus principal-only."),
    ]
    boards = []
    labels = ("100k", "uniform", "principal", "split")
    for row, role, why in examples:
        case = plan["selected"][row["index"]]
        raw = {k: arr[0] for k, arr in read_observation(row).items()}
        with np.load(checked(row["output"]), allow_pickle=False) as ac:
            result = {k: ac["parent" if k == "100k" else k][0] for k in labels}
        boards.append(
            make_board(
                output,
                f"{row['id']}-repeat0-role{role}",
                raw,
                result,
                {
                    "source": case["source"],
                    "CFA": case["camera"]["pattern"],
                    "query": case["box"],
                    "profile": plan["profile"],
                    "why": why,
                    "role": role,
                    "geometry": case["alias"],
                    "input": row["sample"],
                },
                role,
                [48, 48, 160, 160],
                plan["profile"],
                "split",
                labels,
            )
        )
    return boards


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    results = reference(ROOT / "result.json")
    report = read_json(checked(results))
    plan = read_json(checked(report["plan"]))
    config = read_json(checked(plan["parent_panel"]))
    recipe = read_json(checked(config["frozen_composition"]))
    withheld = reference(WITHHELD / "result.json")
    fresh = reference(ROOT / "alias-result.json")
    strengths = report["metrics"]["iso6400"]["scales"]
    held = read_json(checked(withheld))["metrics"]["iso6400"]["scales"]
    model, limits = bind_models(recipe)
    folder = ROOT / "native"
    folder.mkdir()

    def camera(m, args, parents, limits):
        parent = (
            torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
        )
        return all_versions(m, args, parent, limits, strengths, held)

    render_repeat.SHOW = ("uniform", "principal", "split", "withheld-split", "full")
    render_repeat.predictions = camera
    render_repeat.DISPLAY = LABEL
    with ieee_fp32():
        gallery = natural(model, limits, strengths, held, report, config, folder)
        planted = alias(read_json(checked(fresh)), folder)
        standing = render_repeat.show_camera(model, limits, folder)
    write_json(
        folder / "render.json",
        {
            "numeric": results,
            "alias": fresh,
            "withheld": withheld,
            "driver": reference(__file__),
            "parent": recipe["models"]["Corpus 100k"],
            "correction": recipe["initial_head"],
            "photo": gallery,
            "planted": planted,
            "standing": standing,
            "actual_native_viewing_complete": False,
        },
    )


if __name__ == "__main__":
    run()
