"""Verify native alias transport, window reconstruction and the exact-flat case."""

from pathlib import Path

import torch

from demosaic.cfa import PATTERNS, pack
from demosaic.experiments.artifacts import reference, write_json
from quincunx_green import corrections, fold_green, geometry, to_native, _patches, _retile

torch.set_num_threads(2)
layouts = torch.tensor(list(PATTERNS.values()))
green = torch.argsort((layouts != 1).to(torch.int32), dim=1, stable=True)[:, :2]
y, x = torch.meshgrid(
    torch.arange(64, dtype=torch.float64), torch.arange(64, dtype=torch.float64), indexing="ij"
)
bands = []
for fx, fy, p in ((12, 4, 0.27), (-20, 4, 0.81), (3, 21, 0.31)):
    bands.append(torch.cos(2 * torch.pi * (fx * x + fy * y) / 64 + p))
first, second, third = bands
# The first and second terms collide in each individual packed FFT after opposite alias wrapping.
paired = torch.stack((first + second, first + second, third, third))[:, None]
layout = geometry(green, 32, dtype=torch.float64)
phase = pack(paired).gather(1, green[:, :, None, None].expand(-1, -1, 32, 32))
parts = fold_green(torch.fft.fft2(phase[:, None], norm="ortho"), layout)
low, high = parts.unbind(dim=2)
native = to_native(parts, layout.destinations, 32)[:, 0, None]
error = float((native - paired).abs().max())
assert error < 1e-12
principal = to_native(torch.stack((low, torch.zeros_like(high)), 2), layout.destinations, 32)
assert (principal[:2, 0] - first).abs().max() < 1e-12
assert principal[2:].abs().max() < 1e-12

signal = torch.randn(
    3, 1, 112, 96, dtype=torch.float64, generator=torch.Generator().manual_seed(991)
)
padded = torch.nn.functional.pad(signal, (32, 32, 32, 48), mode="reflect")
coord = torch.arange(64, dtype=torch.float64)
sine = torch.sin(torch.pi * (coord + 0.5) / 64)
weights = sine[:, None] * sine[None, :]
windowed = torch.nn.functional.unfold(padded, 64, stride=32).transpose(1, 2).reshape(3, -1, 64, 64)
replay = _retile(windowed * weights, padded.shape[-2:], signal.shape[-2:])
lapped_error = float((signal - replay).abs().max())
assert lapped_error < 1e-12
constant = torch.full((4, 4, 128, 128), 0.18, dtype=torch.float64)
restored = torch.full((4, 3, 256, 256), 0.18, dtype=torch.float64)
valid = corrections(constant, torch.zeros_like(constant), layouts, restored)
zero = max(float(v.abs().max()) for v in valid.values())
assert zero < 1e-12
root = Path(__file__).resolve().parent
write_json(
    root / "geometry-check.json",
    {
        "driver": reference(__file__),
        "paired_native_alias_max_error": error,
        "exact_flat_max_correction": zero,
        "lapped_window_max_replay_error": lapped_error,
        "CFA_checks": list(PATTERNS),
        "spectra": "A principal and odd branch term overlap in the same packed bin, plus an odd-y carrier. The chosen green-diamond bands reproduce all at exact phase.",
    },
)
print(error, lapped_error, zero)
