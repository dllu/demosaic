"""Match the false-texture budget of a green Fourier restoration component."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from quincunx_green import corrections

ROOT = Path(__file__).resolve().parent
CONTEXT = ROOT.parent / "context-strength-v1"
sys.path.insert(0, str(CONTEXT))
from collect import ARGS, as_cuda, bind_models, channel_coefficients, contrast, inputs, moments
from edge_delivery import detail, paired_gates, quiet
from edge_guard import edge_weight

METHODS = ("uniform", "principal", "split", "blend")


def freeze():
    inputs = reference(CONTEXT / "plan.json")
    write_json(
        ROOT / "plan.json",
        {
            "driver": reference(__file__),
            "module": reference(ROOT / "quincunx_green.py"),
            "parent_panel": inputs,
            "check": reference(ROOT / "geometry-check.json"),
            "sources_fit": list(range(32)),
            "sources_test": list(range(32, 64)),
            "scope": "Same fixed Corpus 100k trunk, retained correction, and common quiet route. Compare principal and alternate green alias classes with lapped locally shrunk direct reconstructions and a same-flat-addition budget. The two-green evidence uses one observation. Fixed exact targets are reserved for scoring and strength calibration across distinct source halves.",
        },
    )


def restore(model, args, parent, limits):
    outer, inner = paired_gates(*args[:3], *limits)
    calm, neutral = quiet(model, parent, args, outer)
    anchor = parent + calm
    edge = edge_weight(model.scene_luma(parent, *args[-2:]), args[1])
    # Match upstream CFA support and cap all RAW bands by the measured sigma.
    cap = F.interpolate(
        2 * args[1].mean(1, keepdim=True).clamp_min(1e-10).sqrt(), scale_factor=2, mode="nearest"
    )
    options = corrections(args[0], args[1], args[2], anchor)
    out = {
        "parent": parent,
        "quiet": anchor,
        "uniform": anchor + neutral[:, :, None, None] * detail(model, parent, args, inner),
    }
    for name, proposal in options.items():
        protected = proposal.clamp(min=-cap, max=cap) * edge * inner
        out[name] = anchor + neutral[:, :, None, None] * protected
    return out


def budgets(rows, plan):
    rng = np.random.default_rng(527213)
    out = {}
    for profile in ("iso400", "iso6400"):
        own = [r for r in rows if r["profile"] == profile]
        fit = [r for r in own if r["index"] in plan["sources_fit"] and r["draw"] == "coupled"]
        assert len(fit) == 32
        added = {
            k: float(np.mean([np.sqrt(max(0, r["scores"][k]["flat"][2])) for r in fit]))
            for k in METHODS
        }
        # Fixed flat calibration uses no present-detail target.
        limit = min(added.values())
        scales = {k: limit / v if v > 0 else 0 for k, v in added.items()}
        # Also report full strength. The nonamplifying matched comparison preserves quiet exactly.
        result = {"calibration_exact_flat_addition_DN16": added, "scales": scales, "draw": {}}
        for draw in ("coupled", "independent"):
            test = [r for r in own if r["index"] in plan["sources_test"] and r["draw"] == draw]
            assert len(test) == 32
            comparisons = (
                ("split", "principal"),
                ("blend", "principal"),
                ("split", "blend"),
                ("split", "uniform"),
                ("principal", "uniform"),
                ("blend", "uniform"),
                ("split", "parent"),
                ("uniform", "parent"),
                ("quiet", "parent"),
            )
            result["draw"][draw] = {
                "heldout_added_flat_DN16": {
                    k: float(
                        np.mean(
                            [scales[k] * np.sqrt(max(0, r["scores"][k]["flat"][2])) for r in test]
                        )
                    )
                    for k in METHODS
                },
                "matched": {
                    f"{a}_vs_{b}": contrast(test, a, b, scales, rng) for a, b in comparisons
                },
                "nominal": {f"{a}_vs_{b}": contrast(test, a, b, {}, rng) for a, b in comparisons},
            }
        out[profile] = result
    return out


@torch.inference_mode()
def run(smoke):
    torch.set_num_threads(2)
    limit = 6 * 2**30 / torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.0, limit))
    plan_ref = reference(ROOT / "plan.json")
    plan = read_json(checked(plan_ref))
    for key in ("driver", "module", "check"):
        checked(plan[key])
    source = read_json(checked(plan["parent_panel"]))
    parents = read_json(checked(source["parents"]))
    panel = read_json(checked(source["panel"]))
    model, limits = bind_models(read_json(checked(source["frozen_composition"])))
    started = time.monotonic()
    rows = []
    with ieee_fp32():
        for record in parents["records"][: 4 if smoke else None]:
            case, arrays, base = inputs(record)
            args = as_cuda(
                {
                    k: arrays[k]
                    if k in ("packed", "variance")
                    else np.broadcast_to(arrays[k], (3, *arrays[k].shape))
                    for k in ARGS
                }
            )
            parent = torch.from_numpy(base).cuda().contiguous(memory_format=torch.channels_last)
            output = restore(model, args, parent, limits)
            camera = {
                k: np.broadcast_to(arrays[k], (3, *arrays[k].shape)) for k in ("wb", "matrix")
            }
            coef = {
                k: channel_coefficients(value.cpu().numpy(), camera, panel["score_ROI_xywh"])[1]
                for k, value in output.items()
            }
            goal = channel_coefficients(arrays["target"], camera, panel["score_ROI_xywh"])[1]
            assert all(torch.isfinite(v).all() for v in output.values())
            rows.append(
                {
                    "id": case["id"],
                    "index": case["case"],
                    "profile": case["profile"]["name"],
                    "draw": case["draw"],
                    "scores": {
                        key: moments(coef["quiet"], value, goal) for key, value in coef.items()
                    },
                }
            )
            if len(rows) % 32 == 0 or smoke:
                print(len(rows), round(time.monotonic() - started, 2), flush=True)
    assert len(rows) == (4 if smoke else 256)
    write_json(
        ROOT / ("smoke.json" if smoke else "result.json"),
        {
            "plan": plan_ref,
            "rows": rows,
            "metrics": None if smoke else budgets(rows, plan),
            "seconds": time.monotonic() - started,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("freeze", "smoke", "run"))
    mode = parser.parse_args().mode
    freeze() if mode == "freeze" else run(mode == "smoke")
