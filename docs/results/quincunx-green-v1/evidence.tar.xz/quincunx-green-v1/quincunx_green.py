"""Lapped green reconstruction using both phase classes on the Bayer quincunx."""

from dataclasses import dataclass

import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic

WINDOW = 64
STRIDE = WINDOW // 2


@dataclass(frozen=True)
class Geometry:
    weights: torch.Tensor
    transform: torch.Tensor
    destinations: torch.Tensor
    bands: torch.Tensor


def smoothstep(x):
    x = x.clamp(0, 1)
    return x.square() * (3 - 2 * x)


def geometry(greens, width, *, dtype=torch.float32):
    """Map two phase-compensated Fourier sums to the green Nyquist diamond.

    The even alias class uses the principal packed square. For the odd
    class we choose the shorter of the two one-axis half-cycle shifts.
    Equal-axis ties and single-plane Nyquist boundaries are tapered out.
    """
    axis = torch.arange(width, device=greens.device, dtype=dtype)
    oy, ox = greens.div(2, rounding_mode="floor"), greens % 2
    kx = ox[:, None, :, None, None]
    ky = oy[:, None, :, None, None]
    wy = torch.sin(torch.pi * (2 * axis[None, None, None, :, None] + ky + 0.5) / (2 * width))
    wx = torch.sin(torch.pi * (2 * axis[None, None, None, None, :] + kx + 0.5) / (2 * width))
    weights = wy * wx
    freq = torch.fft.fftfreq(width, d=2, dtype=dtype, device=greens.device)
    fy, fx = torch.meshgrid(freq, freq, indexing="ij")
    no_alias = torch.stack((fy, fx), dim=0)
    y_shift = fy.abs() > fx.abs()
    longer_y = fy - 0.5 * fy.sign() * y_shift
    longer_x = fx - 0.5 * fx.sign() * ~y_shift
    native = torch.stack((no_alias, torch.stack((longer_y, longer_x))), dim=0)
    y, x = native.unbind(dim=1)
    phase = (
        -2
        * torch.pi
        * (y[None, None, :, None] * ky[:, :, None] + x[None, None, :, None] * kx[:, :, None])
    )
    transform = torch.polar(torch.ones_like(phase), phase)
    pixels = (native * (width * 2)).round().to(torch.int64).remainder(width * 2)
    destination = pixels[:, 0] * (2 * width) + pixels[:, 1]
    radius = torch.hypot(y, x)
    band = smoothstep((radius - 0.085) / 0.055) * smoothstep((0.36 - radius) / 0.07)
    # Taper packed-grid boundaries for both classes and odd-class directional ties.
    away = smoothstep((0.25 - torch.maximum(fx.abs(), fy.abs())) / 0.018)
    unique_odd = smoothstep((fy.abs() - fx.abs()).abs() / 0.045)
    band = band * torch.stack((away, away * unique_odd))
    return Geometry(weights, transform, destination.flatten(1), band)


def fold_green(planes, geometry):
    """Return the principal and alternate terms at their actual native phases."""
    return (planes[:, :, None] * geometry.transform).mean(dim=3)


def spectral_sample(plane, window):
    center = (plane * window.square()).sum((-2, -1), keepdim=True) / window.square().sum(
        (-2, -1), keepdim=True
    )
    return torch.fft.fft2((plane - center) * window, norm="ortho")


def smooth_power(powers):
    return sum(powers.roll((dy, dx), (-2, -1)) for dy in (-1, 0, 1) for dx in (-1, 0, 1)) / 9


def to_native(coefficients, mapping, width):
    batch, patches = coefficients.shape[:2]
    spectrum = coefficients.new_zeros((batch, patches, (2 * width) ** 2))
    index = mapping.flatten()[None, None].expand(batch, patches, -1)
    spectrum.scatter_add_(2, index, 2 * coefficients.flatten(2))
    return torch.fft.ifft2(
        spectrum.reshape(batch, patches, 2 * width, 2 * width), norm="ortho"
    ).real


def _patches(field, width):
    b, colors, height, span = field.shape
    # The surrounding padding is in packed cells, preserving Bayer phase.
    native_stride = width // 2
    extra_h, extra_w = (-height) % native_stride, (-span) % native_stride
    padded = F.pad(
        field,
        (native_stride, native_stride + extra_w, native_stride, native_stride + extra_h),
        mode="reflect",
    )
    linear = F.unfold(padded, kernel_size=width, stride=native_stride)
    windows = linear.transpose(1, 2).reshape(b, -1, colors, width, width)
    return windows, (padded.shape[-2] * 2, padded.shape[-1] * 2)


def _unfold_measurements(packed, variance, restored, greens):
    def read(field):
        return field.gather(1, greens[:, :, None, None].expand(-1, -1, *field.shape[-2:]))

    p, grid = _patches(read(packed), WINDOW // 2)
    v, _ = _patches(read(variance), WINDOW // 2)
    q, _ = _patches(read(restored), WINDOW // 2)
    return p, v, q, grid


def _retile(frames, grid, shape):
    coord = torch.arange(WINDOW, device=frames.device, dtype=frames.dtype)
    window = torch.sin(torch.pi * (coord + 0.5) / WINDOW)
    weights = window[:, None] * window[None, :]
    stack = (frames * weights).flatten(2).transpose(1, 2)
    out = F.fold(stack, grid, kernel_size=WINDOW, stride=STRIDE)
    # In the retained interior, the squared sine windows sum to one.
    return out[..., STRIDE : STRIDE + shape[0], STRIDE : STRIDE + shape[1]]


def corrections(packed, variance, colors, parent):
    """Green-constrained candidates for a camera-neutral luma correction.

    Both branches share the same observation. The local power estimates
    are heuristic shrinkage weights with no independent validation claim.
    """
    greens = torch.argsort((colors != 1).to(torch.int32), dim=1, stable=True)[:, :2]
    native_shape = parent.shape[-2:]
    photo, noise, base, grid = _unfold_measurements(
        packed, variance, mosaic(parent, colors), greens
    )
    layout = geometry(greens, WINDOW // 2, dtype=packed.dtype)
    measured = fold_green(spectral_sample(photo, layout.weights), layout)
    fixed = fold_green(spectral_sample(base, layout.weights), layout)
    noise_power = (noise * layout.weights.square()).mean((-2, -1)).mean(2) * 0.5
    power = smooth_power(measured.abs().square())
    floor = 1.35 * noise_power[:, :, None, None, None]
    shrink = (1 - floor / power.clamp_min(1e-12)).clamp(0, 1)
    # A conservative contrast floor suppresses an ambiguous second phase class.
    partner = power.flip((2,))
    coherent = (1 - 0.12 * partner / power.clamp_min(1e-12)).clamp(0, 1)
    scale = shrink * coherent * layout.bands
    from_raw = measured * shrink
    cross = (fixed * measured.conj()).real
    denominator = (measured.abs().square() * shrink).clamp_min(1e-12)
    missing = 1 - (cross / denominator).clamp(0, 1)
    gain = scale * missing * from_raw
    zero = torch.zeros_like(gain[:, :, 0])

    def decode(components):
        return _retile(to_native(components, layout.destinations, WINDOW // 2), grid, native_shape)

    return {
        "principal": decode(torch.stack((gain[:, :, 0], zero), dim=2)),
        "split": decode(gain),
        "blend": decode((from_raw - fixed) * scale),
    }
