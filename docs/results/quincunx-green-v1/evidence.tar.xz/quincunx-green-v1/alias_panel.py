"""Check the green alias separation on weak carriers over separate photographs."""

import argparse
from dataclasses import replace
from pathlib import Path
import random
import time

import numpy as np
import torch

from demosaic.archive_metrics import linear_rgb
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import sample_scene_recipe
from demosaic.scene_training_data import scene_seed
from evaluate_green import ROOT, ARGS, as_cuda, bind_models, restore
from edge_data import decode, pair_targets
from evaluate import setup_models
from train_repeat import observe

SCHEDULE = 424208011898
PROFILE = {"name": "iso6400", "shot": 0.00128, "read": 6.5536e-6, "exposure": 0.33}
CONDITIONS = ("weak-only", "shared-alias")
LUMA = np.array([0.2126, 0.7152, 0.0722])


def wave_spec(row):
    rng = random.Random(scene_seed(SCHEDULE, row["index"], "geometry"))
    major = rng.uniform(0.18, 0.218)
    minor = rng.uniform(0.033, 0.089) * rng.choice((-1, 1))
    principal = (major, minor)
    alternate = (major - 0.5, minor)
    if row["index"] // 4 % 2:
        principal = principal[::-1]
        alternate = alternate[::-1]
    return {
        "principal": principal,
        "alternate": alternate,
        "strong_phase": rng.uniform(-np.pi, np.pi),
        "weak_phase": rng.uniform(-np.pi, np.pi),
        "weak_amp": (0.003, 0.005)[row["index"] // 8 % 2],
        "strong_amp": 0.012,
        "common_step": bool(row["index"] // 4 % 2),
    }


def plan():
    parent = reference(ROOT.parent / "weak-edge-distill-v1/evaluation.json")
    old = read_json(checked(parent))
    learned = read_json(ROOT / "plan.json")
    photo = read_json(checked(learned["parent_panel"]))
    sources = read_json(checked(photo["panel"]))
    existing = {r["source"]["id"] for r in sources["rows"]}
    selected = [r | {"alias": wave_spec(r)} for r in old["heldout_rows"][:32]]
    assert not existing.intersection(r["source"]["id"] for r in selected)
    write_json(
        ROOT / "alias-plan.json",
        {
            "driver": reference(__file__),
            "origins": parent,
            "natural_controls": reference(ROOT / "plan.json"),
            "selected": selected,
            "roles": CONDITIONS,
            "profile": PROFILE,
            "scope": "32 photographic fields absent from the primary photo-panel calibration. Two frequencies differ by half a cycle per native pixel on one axis. Both conditions retain the same weak ground truth. The shared stronger carrier is on the corresponding principal alias. A subpixel common step is present in half the backgrounds. Two independent physical draws for every role.",
        },
    )


def prepare():
    stamped = reference(ROOT / "alias-plan.json")
    config = read_json(checked(stamped))
    torch.set_num_threads(2)
    output = ROOT / "alias-observations"
    output.mkdir()
    rows = []
    y, x = torch.meshgrid(torch.arange(256), torch.arange(256), indexing="ij")

    def wave(nu, phase):
        return torch.cos(2 * torch.pi * (nu[0] * x + nu[1] * y) + phase)

    mask = ((114 - (x - 127.5).abs()) / 25).clamp(0, 1) * ((114 - (y - 127.5).abs()) / 25).clamp(
        0, 1
    )
    for row in config["selected"]:
        geometry = row["alias"]
        crop = decode(row["source"], row["box"])
        _, base, flat = pair_targets(
            crop, row["geometry"], "same-edge" if geometry["common_step"] else "natural"
        )
        amplitude = geometry["weak_amp"]
        signal = amplitude * wave(geometry["alternate"], geometry["weak_phase"]) * mask
        strong = (
            geometry["strong_amp"] * wave(geometry["principal"], geometry["strong_phase"]) * mask
        )
        assert np.isclose(
            abs(geometry["principal"][0] - geometry["alternate"][0])
            + abs(geometry["principal"][1] - geometry["alternate"][1]),
            0.5,
        )
        for family in CONDITIONS:
            canvas = base if family == "weak-only" else base + strong
            present = canvas + signal
            assert present.min() > 0 and present.max() < 1
            camera = replace(
                sample_scene_recipe(SCHEDULE),
                **(row["camera"] | {k: PROFILE[k] for k in ("exposure", "shot", "read")}),
            )
            fields = []
            for repeat in range(2):
                keys = [
                    scene_seed(SCHEDULE, row["index"], f"{family}/{repeat}/{role}")
                    for role in ("pair", "present", "absent", "flat")
                ]
                fields.append(
                    observe((present, canvas, flat), camera, PROFILE, "independent", keys)
                )
            assert torch.equal(fields[0]["target"], fields[1]["target"])
            arr = {key: torch.stack([r[key] for r in fields]).numpy() for key in (*ARGS, "target")}
            name = f"{row['index']:03d}-{family}"
            with (output / f"{name}.npz").open("xb") as stream:
                np.savez(stream, **arr)
            rows.append(
                {
                    "id": name,
                    "family": family,
                    "index": row["index"],
                    "sample": reference(output / f"{name}.npz"),
                    "fingerprints": {k: fingerprint(v) for k, v in arr.items()},
                }
            )
    assert len(rows) == 64
    write_json(ROOT / "alias-inputs.json", {"plan": stamped, "rows": rows})


def read_observation(row):
    with np.load(checked(row["sample"]), allow_pickle=False) as arrays:
        out = {k: arrays[k] for k in (*ARGS, "target")}
    assert {k: fingerprint(v) for k, v in out.items()} == row["fingerprints"]
    return out


def examine(arrays, forecasts):
    crop = np.s_[..., 80:176, 80:176]

    def convert(rgb):
        bands = [linear_rgb(rgb[i], {k: arrays[k][i] for k in ("wb", "matrix")}) for i in range(2)]
        return np.einsum("c,dbchw->dbhw", LUMA, np.stack(bands))[crop]

    gt = convert(arrays["target"])
    np.testing.assert_array_equal(gt[0], gt[1])
    true = gt[0, 0] - gt[0, 1]
    energy = float(np.sum(true**2))
    assert energy > 0
    results = {}
    for mode, value in forecasts.items():
        rgb = convert(value)
        addition = rgb[:, 0] - rgb[:, 1]
        error = addition - true
        projected = addition.mean(axis=0)
        alignment = float(np.sum(projected * true))
        off = projected - (alignment / energy) * true
        false = np.einsum("dyx,yx->d", (rgb[:, 1] - gt[:, 1]), true) / energy
        results[mode] = {
            "target_energy": energy,
            "dot": alignment,
            "off_axis_DN16": float(np.sqrt(np.mean(off**2)) * 65535),
            "increment_RMS_DN16": float(np.sqrt(np.mean(error**2, axis=(-2, -1))).mean() * 65535),
            "absent_carrier_ratio": float(abs(false).mean()),
        }
    return results


def summarize(rows):
    rng = np.random.default_rng(2740)
    metrics = {}
    for cond in CONDITIONS:
        selected = [r for r in rows if r["family"] == cond]
        assert len(selected) == 32
        indices = rng.integers(32, size=(4000, 32))
        metrics[cond] = {}
        for name, base in (
            ("principal", "parent"),
            ("split", "parent"),
            ("blend", "parent"),
            ("split", "principal"),
            ("split", "uniform"),
            ("blend", "split"),
            ("uniform", "parent"),
        ):
            measurements = [(r["metrics"][name], r["metrics"][base]) for r in selected]
            r = {}
            for key in ("off_axis_DN16", "increment_RMS_DN16", "absent_carrier_ratio"):
                change = np.array([a[key] - b[key] for a, b in measurements])
                r[key] = [
                    float(change.mean()),
                    *np.quantile(change[indices].mean(1), [0.025, 0.975]).tolist(),
                ]
            d = np.array([a["dot"] - b["dot"] for a, b in measurements])
            power = np.array([b["target_energy"] for a, b in measurements])
            r["response_pp"] = [
                float(100 * d.sum() / power.sum()),
                *np.quantile(
                    100 * d[indices].sum(1) / power[indices].sum(1), [0.025, 0.975]
                ).tolist(),
            ]
            metrics[cond][f"{name}_vs_{base}"] = r
    return metrics


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(
        min(1.0, 7 * 2**30 / torch.cuda.get_device_properties(0).total_memory)
    )
    inputs = reference(ROOT / "alias-inputs.json")
    observation = read_json(checked(inputs))
    calibration = reference(ROOT / "result.json")
    numbers = read_json(checked(calibration))
    scale = numbers["metrics"]["iso6400"]["scales"]
    plan = read_json(checked(observation["plan"]))
    assert plan["driver"] == reference(__file__)
    config = read_json(checked(plan["natural_controls"]))
    parent = read_json(checked(config["parent_panel"]))
    recipe = read_json(checked(parent["frozen_composition"]))
    model, limits = bind_models(recipe)
    restorer = setup_models({"models": {"100k": recipe["models"]["Corpus 100k"]}})["100k"]
    restorer.set_noise(PROFILE["shot"], PROFILE["read"])
    folder = ROOT / "alias-outputs"
    folder.mkdir()
    rows = []
    start = time.monotonic()
    with ieee_fp32():
        for case in observation["rows"]:
            native = read_observation(case)
            args = as_cuda({k: native[k].reshape((-1, *native[k].shape[2:])) for k in ARGS})
            base = restorer(*args)
            predictions = restore(model, args, base, limits)
            q = predictions["quiet"]
            values = {
                k: (q + scale[k] * (p - q) if k in scale else p)
                .cpu()
                .numpy()
                .reshape(2, 3, 3, 256, 256)
                for k, p in predictions.items()
            }
            path = folder / (case["id"] + ".npz")
            with path.open("xb") as stream:
                np.savez(stream, **values)
            rows.append(case | {"output": reference(path), "metrics": examine(native, values)})
            if len(rows) % 8 == 0:
                print(len(rows), round(time.monotonic() - start, 2), flush=True)
    write_json(
        ROOT / "alias-result.json",
        {
            "inputs": inputs,
            "natural_flat_calibration": calibration,
            "scales": scale,
            "rows": rows,
            "metrics": summarize(rows),
            "seconds": time.monotonic() - start,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("plan", "prepare", "run"))
    {"plan": plan, "prepare": prepare, "run": run}[parser.parse_args().stage]()
