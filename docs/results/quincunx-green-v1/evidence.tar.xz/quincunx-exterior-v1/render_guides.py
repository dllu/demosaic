"""Review the exterior guide at matched flat addition on native crops."""

import numpy as np
import torch

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from score_exterior import ROOT, ARGS, as_cuda, bind_models, inputs, restore
from collect import value
from report_scene_wave_guides import native_board
import render_repeat

LABEL = {
    "100k": "Corpus 100k EMA",
    "uniform": "Fixed fine lift",
    "local": "Local green spectrum",
    "exterior": "Exterior guide",
    "other-orientation": "Rotated frequency guide",
    "full": "Exterior, original strength",
}


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    result = reference(ROOT / "result.json")
    report = read_json(checked(result))
    scope = read_json(checked(report["plan"]))
    older = read_json(checked(scope["input_plan"]))
    config = read_json(checked(older["parent_panel"]))
    parents = read_json(checked(config["parents"]))
    panel = read_json(checked(config["panel"]))
    recipe = read_json(checked(config["frozen_composition"]))
    head, limits = bind_models(recipe)
    fields = {r["id"]: r for r in parents["records"]}
    scales = report["metrics"]["iso6400"]["scales"]
    selected = [
        r
        for r in report["rows"]
        if r["index"] >= 32 and r["profile"] == "iso6400" and r["draw"] == "independent"
    ]

    def shift(row, score):
        return (
            value(row["scores"]["exterior"], scales["exterior"])[score]
            - value(row["scores"]["local"], scales["local"])[score]
        )

    rank = sorted(selected, key=lambda r: shift(r, "increment"))

    def predict(model, args, prior, limits):
        base = torch.from_numpy(prior["100k"]).cuda().contiguous(memory_format=torch.channels_last)
        candidates = restore(model, args, base, limits)
        anchor = candidates["quiet"]
        produced = {
            k: (anchor + scales[k] * (candidates[k] - anchor)).cpu().numpy()
            for k in ("uniform", "local", "exterior", "other-orientation")
        }
        return prior | produced | {"full": candidates["exterior"].cpu().numpy()}

    output = ROOT / "native"
    output.mkdir()
    render_repeat.SHOW = ("uniform", "local", "exterior", "other-orientation", "full")
    render_repeat.DISPLAY = LABEL
    render_repeat.predictions = predict
    records = []
    with ieee_fp32():
        for row, role, why in (
            (rank[0], 0, "Largest fine-increment error reduction versus local spectrum."),
            (rank[-1], 0, "Largest fine-increment error increase versus local spectrum."),
            (
                max(selected, key=lambda r: shift(r, "flat")),
                2,
                "Largest exact-flat error increase versus local spectrum.",
            ),
        ):
            case, arrays, original = inputs(fields[row["id"]])
            source = panel["rows"][case["case"]]
            args = as_cuda(
                {
                    k: arrays[k]
                    if k in ("packed", "variance")
                    else np.broadcast_to(arrays[k], (3, *arrays[k].shape))
                    for k in ARGS
                }
            )
            predictions = predict(head, args, {"100k": original}, limits)
            render_args = {
                k: arrays[k][role : role + 1] if k in ("packed", "variance") else arrays[k][None]
                for k in ARGS
            }
            images = [
                noisy_malvar(render_args)[0],
                *[predictions[k][role] for k in LABEL],
                arrays["target"][role],
            ]
            records.append(
                native_board(
                    output,
                    f"{case['id']}-role{role}",
                    images,
                    render_args,
                    {
                        "why": why,
                        "source": source["source"],
                        "CFA": source["camera"]["pattern"],
                        "box": case["box"],
                        "profile": case["profile"],
                        "role": role,
                        "sensor_input": fields[row["id"]]["source"],
                    },
                    labels=("Noisy Malvar", *LABEL.values(), "Exact GT"),
                    triplet_indices=(0, list(LABEL).index("exterior") + 1, len(images) - 1),
                    exposure=1 / case["profile"]["exposure"],
                    contrast=2,
                    roi=tuple(panel["native_display_ROI_xywh"]),
                )
            )
        standing = render_repeat.show_camera(head, limits, output)
    write_json(
        output / "render.json",
        {
            "driver": reference(__file__),
            "numeric": result,
            "scales": scales,
            "tested_frozen_parent": recipe["models"]["Corpus 100k"],
            "quiet_component": recipe["initial_head"],
            "photo": records,
            "standing": standing,
            "actual_native_viewing_complete": False,
        },
    )


if __name__ == "__main__":
    run()
