"""Use surrounding RAW as evidence for local green Fourier components."""

import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic
from quincunx_green import (
    WINDOW,
    _unfold_measurements,
    _retile,
    geometry,
    fold_green,
    smooth_power,
    smoothstep,
    spectral_sample,
    to_native,
)
from withheld_green import fold_mask

GUIDE = WINDOW * 2


def guide_patches(field):
    """Return 128-native windows on the same centers as the 64-native windows."""
    batch, channels, h, w = field.shape
    radius, stride, size = GUIDE // 4, WINDOW // 4, GUIDE // 2
    before = (radius, radius + (-w) % stride, radius, radius + (-h) % stride)
    padded = F.pad(field, before)
    pieces = F.unfold(padded, kernel_size=size, stride=stride)
    return pieces.transpose(1, 2).reshape(batch, -1, channels, size, size)


def exteriors(packed, variance, greens):
    def choose(field):
        return field.gather(1, greens[:, :, None, None].expand(-1, -1, *field.shape[-2:]))

    photo = guide_patches(choose(packed))
    noise = guide_patches(choose(variance))
    is_a = fold_mask(*packed.shape[-2:], packed.device)
    masks = guide_patches(torch.stack((is_a, ~is_a))[None].to(dtype=packed.dtype))
    layout = geometry(greens, GUIDE // 2, dtype=packed.dtype)
    coord = (
        torch.arange(GUIDE // 2, device=packed.device, dtype=packed.dtype) - (GUIDE // 2 - 1) / 2
    )
    distance = torch.maximum(coord[:, None].abs(), coord[None, :].abs())
    outside = smoothstep((distance - 20) / 8)
    reference = layout.weights * outside
    references = reference.square().sum((-2, -1), keepdim=True)
    observations = []
    noise_by_fold = []
    for mask in masks.unbind(dim=2):
        window = reference * mask[:, :, None]
        norm = references / window.square().sum((-2, -1), keepdim=True).clamp_min(1e-9)
        observations.append(fold_green(spectral_sample(photo, window) * norm, layout))
        prediction = (noise * window.square() * norm.square()).mean((-2, -1))
        noise_by_fold.append(prediction.mean(2) * 0.5)
    a, b = observations
    positive = smooth_power((a * b.conj()).real)
    noise_level = (noise_by_fold[0] * noise_by_fold[1]).clamp_min(1e-20).sqrt()
    ratio = positive / noise_level[:, :, None, None, None]
    # Same physical frequencies are every second bin of the doubled window.
    return (smoothstep((ratio - 2.5) / 5))[..., ::2, ::2]


def corrections(packed, variance, colors, parent):
    green = torch.argsort((colors != 1).to(torch.int32), dim=1, stable=True)[:, :2]
    photo, noise, base, grid = _unfold_measurements(packed, variance, mosaic(parent, colors), green)
    layout = geometry(green, WINDOW // 2, dtype=packed.dtype)
    measured = fold_green(spectral_sample(photo, layout.weights), layout)
    estimate = fold_green(spectral_sample(base, layout.weights), layout)
    power = smooth_power(measured.abs().square())
    variance_power = (noise * layout.weights.square()).mean((-2, -1)).mean(2) * 0.5
    shrink = (1 - 1.35 * variance_power[:, :, None, None, None] / power.clamp_min(1e-12)).clamp(
        0, 1
    )
    coherence = (1 - 0.12 * power.flip(2) / power.clamp_min(1e-12)).clamp(0, 1)
    missing = (
        1 - (estimate * measured.conj()).real / (measured.abs().square() * shrink).clamp_min(1e-12)
    ).clamp(0, 1)
    correction = measured * missing * shrink.square() * coherence * layout.bands
    evidence = exteriors(packed, variance, green)
    assert evidence.shape == correction.shape
    # Flip frequency axes to change its orientation without drawing other noise.
    contrast = evidence.transpose(-1, -2)

    def decode(v):
        return _retile(to_native(v, layout.destinations, WINDOW // 2), grid, parent.shape[-2:])

    return {
        "local": decode(correction),
        "exterior": decode(correction * evidence),
        "other-orientation": decode(correction * contrast),
    }
