"""Replay local and exterior gates on the independent planted-carrier panel."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from score_exterior import ROOT, GREEN, ARGS, as_cuda, bind_models, restore
from alias_panel import examine, read_observation

ROUTES = ("uniform", "local", "exterior", "other-orientation")
PAIRS = (
    ("exterior", "local"),
    ("exterior", "other-orientation"),
    ("exterior", "uniform"),
    ("exterior", "parent"),
    ("local", "parent"),
    ("other-orientation", "local"),
)


def summaries(rows):
    rng = np.random.default_rng(521879)
    output = {}
    for style in ("weak-only", "shared-alias"):
        data = [r for r in rows if r["family"] == style]
        assert len(data) == 32
        output[style] = {}
        picks = rng.integers(32, size=(4000, 32))
        for comparator in ("matched", "nominal"):
            summary = {}
            for a, b in PAIRS:
                src = [(r["metrics"][comparator][a], r["metrics"][comparator][b]) for r in data]
                signal = np.array([x["dot"] - y["dot"] for x, y in src])
                actual = np.array([y["target_energy"] for x, y in src])
                result = {
                    "response_pp": [
                        float(signal.sum() / actual.sum() * 100),
                        *np.quantile(
                            100 * signal[picks].sum(1) / actual[picks].sum(1), [0.025, 0.975]
                        ).tolist(),
                    ]
                }
                for term in ("off_axis_DN16", "increment_RMS_DN16", "absent_carrier_ratio"):
                    v = np.array([x[term] - y[term] for x, y in src])
                    result[term] = [
                        float(v.mean()),
                        *np.quantile(v[picks].mean(1), [0.025, 0.975]).tolist(),
                    ]
                summary[f"{a}_vs_{b}"] = result
            output[style][comparator] = summary
    return output


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    plan = read_json(ROOT / "plan.json")
    sources = read_json(checked(plan["input_plan"]))
    photo = read_json(checked(sources["parent_panel"]))
    recipe = read_json(checked(photo["frozen_composition"]))
    head, limit = bind_models(recipe)
    calibration = reference(ROOT / "result.json")
    tuning = read_json(checked(calibration))["metrics"]["iso6400"]["scales"]
    template = reference(GREEN / "alias-result.json")
    first = read_json(checked(template))
    rows = []
    began = time.monotonic()
    with ieee_fp32():
        for row in first["rows"]:
            case = read_observation(row)
            with np.load(checked(row["output"]), allow_pickle=False) as z:
                parent = z["parent"]
            args = as_cuda({k: case[k].reshape((-1, *case[k].shape[2:])) for k in ARGS})
            predictions = restore(
                head,
                args,
                torch.from_numpy(parent.reshape(6, 3, 256, 256))
                .cuda()
                .contiguous(memory_format=torch.channels_last),
                limit,
            )
            original = predictions["quiet"]
            out = {k: v.cpu().numpy().reshape(parent.shape) for k, v in predictions.items()}
            matched = {
                k: (original + tuning[k] * (p - original)).cpu().numpy().reshape(parent.shape)
                if k in tuning
                else out[k]
                for k, p in predictions.items()
            }
            rows.append(
                {
                    "id": row["id"],
                    "family": row["family"],
                    "index": row["index"],
                    "metrics": {"nominal": examine(case, out), "matched": examine(case, matched)},
                }
            )
    assert len(rows) == 64
    write_json(
        ROOT / "planted.json",
        {
            "driver": reference(__file__),
            "flat_calibration": calibration,
            "source": template,
            "metrics": summaries(rows),
            "rows": rows,
            "seconds": time.monotonic() - began,
        },
    )


if __name__ == "__main__":
    run()
