"""Compare local and exterior-supported lapped Bayer restoration."""

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
GREEN = ROOT.parent / "quincunx-green-v1"
sys.path[:0] = [str(GREEN), str(ROOT.parent / "quincunx-withheld-v2")]
from evaluate_green import (
    ARGS,
    as_cuda,
    bind_models,
    channel_coefficients,
    contrast,
    inputs,
    moments,
)
from edge_delivery import detail, quiet, paired_gates
from edge_guard import edge_weight
from exterior_green import corrections

METHODS = ("uniform", "local", "exterior", "other-orientation")


def restore(model, args, parent, limits):
    wide, tight = paired_gates(*args[:3], *limits)
    calm, grey = quiet(model, parent, args, wide)
    baseline = parent + calm
    direct = corrections(args[0], args[1], args[2], baseline)
    edge = edge_weight(model.scene_luma(parent, *args[-2:]), args[1])
    cap = F.interpolate(
        2 * args[1].mean(1, keepdim=True).clamp_min(1e-10).sqrt(), scale_factor=2, mode="nearest"
    )
    weights = grey[:, :, None, None]
    return {
        "parent": parent,
        "quiet": baseline,
        "uniform": baseline + weights * detail(model, parent, args, tight),
    } | {
        name: baseline + weights * delta.clamp(min=-cap, max=cap) * edge * tight
        for name, delta in direct.items()
    }


def summaries(rows):
    out = {}
    rng = np.random.default_rng(11771)
    for prior in ("iso400", "iso6400"):
        chosen = [r for r in rows if r["profile"] == prior]
        cal = [r for r in chosen if r["draw"] == "coupled" and r["index"] < 32]
        assert len(cal) == 32
        power = {
            k: float(np.mean([np.sqrt(max(0, r["scores"][k]["flat"][2])) for r in cal]))
            for k in METHODS
        }
        scales = {k: min(power.values()) / v if v > 0 else 0 for k, v in power.items()}
        a, b, wrong = METHODS[1:]
        out[prior] = {"added_flat_fit_DN16": power, "scales": scales, "draw": {}}
        for draw in ("coupled", "independent"):
            test = [r for r in chosen if r["draw"] == draw and r["index"] >= 32]
            pairs = (
                (a, "uniform"),
                (b, "uniform"),
                (b, a),
                (b, wrong),
                (b, "parent"),
                ("uniform", "parent"),
            )
            out[prior]["draw"][draw] = {
                "matched": {f"{x}_vs_{y}": contrast(test, x, y, scales, rng) for x, y in pairs},
                "nominal": {f"{x}_vs_{y}": contrast(test, x, y, {}, rng) for x, y in pairs},
            }
    return out


@torch.inference_mode()
def run(smoke):
    torch.set_num_threads(2)
    native = reference(ROOT / "plan.json")
    plan = read_json(checked(native))
    assert plan["driver"] == reference(__file__)
    actual = read_json(checked(plan["input_plan"]))
    config = read_json(checked(actual["parent_panel"]))
    model, limits = bind_models(read_json(checked(config["frozen_composition"])))
    parent = read_json(checked(config["parents"]))
    panel = read_json(checked(config["panel"]))
    rows = []
    start = time.monotonic()
    with ieee_fp32():
        for item in parent["records"][: 4 if smoke else None]:
            case, fields, base = inputs(item)
            args = as_cuda(
                {
                    k: fields[k]
                    if k in ("packed", "variance")
                    else np.broadcast_to(fields[k], (3, *fields[k].shape))
                    for k in ARGS
                }
            )
            old = torch.from_numpy(base).cuda().contiguous(memory_format=torch.channels_last)
            axes = {k: np.broadcast_to(fields[k], (3, *fields[k].shape)) for k in ("wb", "matrix")}
            restored = restore(model, args, old, limits)
            obs = {
                k: channel_coefficients(v.cpu().numpy(), axes, panel["score_ROI_xywh"])[1]
                for k, v in restored.items()
            }
            gt = channel_coefficients(fields["target"], axes, panel["score_ROI_xywh"])[1]
            rows.append(
                {
                    "id": case["id"],
                    "profile": case["profile"]["name"],
                    "index": case["case"],
                    "draw": case["draw"],
                    "scores": {k: moments(obs["quiet"], v, gt) for k, v in obs.items()},
                }
            )
            if len(rows) % 32 == 0 or smoke:
                print(len(rows), round(time.monotonic() - start, 2), flush=True)
    assert len(rows) == (4 if smoke else 256)
    write_json(
        ROOT / ("smoke.json" if smoke else "result.json"),
        {
            "plan": native,
            "rows": rows,
            "minutes": (time.monotonic() - start) / 60,
            "metrics": None if smoke else summaries(rows),
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "smoke", "run"))
    mode = parser.parse_args().mode
    if mode == "freeze":
        write_json(
            ROOT / "plan.json",
            {
                "driver": reference(__file__),
                "input_plan": reference(GREEN / "plan.json"),
                "exterior_module": reference(ROOT / "exterior_green.py"),
                "holdout_check": reference(ROOT / "local-exclusion.json"),
                "scope": "Guide from a 128-native window with its 80-pixel center excluded. Local recovery from the native 64 pixels at the same center. Test matching orientation versus swapped axes and local-only spectrum. Flat addition matched on the calibration source half. No global threshold tuned on the real photographs.",
            },
        )
    else:
        run(mode == "smoke")
