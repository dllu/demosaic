"""Qualify spatial isolation and exact replay of the original local lapped lift."""

from pathlib import Path

import torch

from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import reference, write_json
from exterior_green import corrections, exteriors
from quincunx_green import corrections as original

torch.set_num_threads(2)
torch.manual_seed(91432)
packed = torch.rand(1, 4, 128, 128) * 0.3
noise = 0.00128 * packed + 6.5536e-6
colors = color_indices("RGGB")[None]
greens = torch.tensor([[1, 2]])
height = packed.shape[-2] // 16 + 1
x = (height // 2) * 16
i = ((height // 2) * height) + (height // 2)
original_guide = exteriors(packed, noise, greens)
changed = packed.clone()
changed[..., x - 20 : x + 20, x - 20 : x + 20] += 0.4
new_noise = noise.clone()
new_noise[..., x - 20 : x + 20, x - 20 : x + 20] *= 2
changed_guide = exteriors(changed, new_noise, greens)
assert torch.equal(original_guide[:, i], changed_guide[:, i])
assert not torch.equal(original_guide, changed_guide)
parent = torch.zeros(1, 3, 256, 256)
end = corrections(packed, noise, colors, parent)["local"]
baseline = original(packed, noise, colors, parent)["split"]
error = float((end - baseline).abs().max())
assert error < 1e-7
root = Path(__file__).resolve().parent
write_json(
    root / "local-exclusion.json",
    {
        "driver": reference(__file__),
        "scope": "The central guide window was byte-identical after changing both the central input and its variance. Other guide windows changed.",
        "local_replay_max_difference": error,
    },
)
