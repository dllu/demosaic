"""Estimate lapped green branch agreement from disjoint Bayer cell folds."""

import torch
from torch.nn import functional as F

from demosaic.cfa import mosaic
from quincunx_green import WINDOW, _unfold_measurements, _retile, geometry, fold_green
from quincunx_green import spectral_sample, smooth_power, to_native


def fold_mask(height, width, device):
    y = torch.arange(height, device=device) // 2
    x = torch.arange(width, device=device) // 2
    return (y[:, None] + x[None, :]) % 2 == 0


def mask_patches(shape, device, width):
    height, span = shape
    step = width // 2
    extra_h, extra_w = (-height) % step, (-span) % step
    a = fold_mask(height, span, device)
    masks = torch.stack((a, ~a)).to(torch.float32)
    padded = F.pad(masks[None], (step, step + extra_w, step, step + extra_h))
    return (
        F.unfold(padded, kernel_size=width, stride=step)
        .transpose(1, 2)
        .reshape(1, -1, 2, width, width)
    )


def heldout_spectra(photo, layout, masks):
    words = []
    for mask in masks.unbind(dim=2):
        fit_window = layout.weights * mask[:, :, None]
        scale = layout.weights.square().sum((-2, -1), keepdim=True) / fit_window.square().sum(
            (-2, -1), keepdim=True
        ).clamp_min(1e-12)
        estimate = spectral_sample(photo, fit_window) * scale
        words.append(fold_green(estimate, layout))
    return words


def corrections(packed, variance, colors, parent):
    greens = torch.argsort((colors != 1).to(torch.int32), dim=1, stable=True)[:, :2]
    photo, noise, base, grid = _unfold_measurements(
        packed, variance, mosaic(parent, colors), greens
    )
    layout = geometry(greens, WINDOW // 2, dtype=packed.dtype)
    masks = mask_patches(packed.shape[-2:], packed.device, WINDOW // 2)
    a, b = heldout_spectra(photo, layout, masks)
    common = 0.5 * (a + b)
    evidence = smooth_power((a * b.conj()).real)
    nuisance = fold_green(spectral_sample(base, layout.weights), layout)
    sigma = (noise * layout.weights.square()).mean((-2, -1)).mean(2)[:, :, None, None, None] * 0.5
    attenuation = (1 - (1.2 * sigma / evidence.clamp_min(1e-12))).clamp(0, 1)
    slope = (nuisance * common.conj()).real / (common.abs().square() * attenuation).clamp_min(1e-12)
    lifts = common * (1 - slope.clamp(0, 1)) * attenuation.square() * layout.bands

    def decode(coeff):
        return _retile(to_native(coeff, layout.destinations, WINDOW // 2), grid, parent.shape[-2:])

    main = torch.stack((lifts[:, :, 0], torch.zeros_like(lifts[:, :, 0])), dim=2)
    return {"withheld-principal": decode(main), "withheld-split": decode(lifts)}
