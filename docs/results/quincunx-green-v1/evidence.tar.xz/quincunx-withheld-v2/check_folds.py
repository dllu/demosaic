"""Verify that neither spectral estimate reads its withheld native sites."""

from pathlib import Path
import torch
from demosaic.cfa import PATTERNS
from demosaic.experiments.artifacts import reference, write_json
from quincunx_green import WINDOW, _patches, geometry
from withheld_green import fold_mask, heldout_spectra, mask_patches

torch.set_num_threads(2)
roots = Path(__file__).resolve().parent
layouts = torch.tensor(list(PATTERNS.values()))
interior = torch.randn(
    4, 2, 120, 112, dtype=torch.float64, generator=torch.Generator().manual_seed(3544)
)
mask = fold_mask(120, 112, interior.device)
geom = geometry(
    torch.argsort((layouts != 1).to(torch.int32), dim=1, stable=True)[:, :2],
    WINDOW // 2,
    dtype=interior.dtype,
)
shape = mask_patches(interior.shape[-2:], interior.device, WINDOW // 2)
assert torch.max(shape.sum(2)) == 1
old = heldout_spectra(_patches(interior, WINDOW // 2)[0], geom, shape)
for i in range(2):
    modified = interior + 50 * (mask if i else ~mask)
    changed = heldout_spectra(_patches(modified, WINDOW // 2)[0], geom, shape)
    assert torch.equal(old[i], changed[i])
    assert not torch.equal(old[1 - i], changed[1 - i])
write_json(
    roots / "fold-audit.json",
    {
        "driver": reference(__file__),
        "module": reference(roots / "withheld_green.py"),
        "all_four_CFA": True,
        "padded_samples_excluded": True,
        "each_fold_prediction_bit_exact_when_only_other_sites_change": True,
        "validated_patches_per_layout": old[0].shape[1],
    },
)
