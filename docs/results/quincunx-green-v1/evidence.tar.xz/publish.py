"""Publish frozen quincunx evidence and the viewed native crops."""

from pathlib import Path
import shutil
import tarfile

from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

ROOT = Path(__file__).resolve().parent
FOLDS = ROOT.parent / "quincunx-withheld-v2"
GUIDES = ROOT.parent / "quincunx-exterior-v1"
OUTPUT = Path("docs/results/quincunx-green-v1")
IMAGES = Path("docs/images/quincunx-green-v1")


def resize_free(row, destination):
    src = checked(row["image"])
    target = destination / src.name
    shutil.copyfile(src, target)
    assert reference(target)["sha256"] == row["image"]["sha256"]
    with Image.open(target) as picture:
        assert all(
            w == h == 160 and x + w <= picture.width and y + h <= picture.height
            for pane in row["panels"]
            for x, y, w, h in (pane["png_xywh"],)
        )
        picture.verify()
    row["image"]["path"] = str(target)


def select_gallery(report, stage, source, notes):
    folder = IMAGES / stage
    folder.mkdir(parents=True)
    all_photo = [*report["photo"], *report.get("planted", [])]
    assert {row["id"] for row in all_photo + report["standing"]} == set(notes)
    for row in all_photo:
        resize_free(row["board"], folder)
        resize_free(row["triplet"], folder)
        row["viewing"] = notes[row["id"]]
    for row in report["standing"]:
        resize_free(row, folder)
        row["viewing"] = notes[row["id"]]
    report["actual_native_viewing_complete"] = True
    return report


def archive(name, tables):
    path = OUTPUT / name
    with tarfile.open(path, "x:xz") as f:
        for directory, entries in tables:
            for entry in entries:
                f.add(directory / entry, arcname=f"{directory.name}/{entry}")
        f.add(Path(__file__), arcname="publish.py")
    return reference(path)


def publish():
    OUTPUT.mkdir()
    first = read_json(ROOT / "native/render.json")
    second = read_json(GUIDES / "native/render.json")
    natural = read_json(checked(first["numeric"]))
    fresh = read_json(checked(first["alias"]))
    folded = read_json(checked(first["withheld"]))
    context = read_json(checked(second["numeric"]))
    from_around = read_json(GUIDES / "planted.json")
    assert len(natural["rows"]) == len(folded["rows"]) == len(context["rows"]) == 256
    assert len(fresh["rows"]) == len(from_around["rows"]) == 64
    assert from_around["source"] == first["alias"]
    assert from_around["flat_calibration"] == second["numeric"]
    assert len(first["planted"]) == len(first["photo"]) == len(second["photo"]) == 3
    assert len(first["standing"]) == len(second["standing"]) == 8
    first = select_gallery(first, "local", ROOT, read_json(ROOT / "viewed.json"))
    second = select_gallery(second, "exterior", GUIDES, read_json(GUIDES / "viewed.json"))
    evidence = archive(
        "evidence.tar.xz",
        (
            (
                ROOT,
                (
                    "quincunx_green.py",
                    "check_geometry.py",
                    "geometry-check.json",
                    "evaluate_green.py",
                    "plan.json",
                    "smoke.json",
                    "review.log",
                    "result.json",
                    "alias_panel.py",
                    "alias-plan.json",
                    "alias-inputs.json",
                    "alias-result.json",
                    "alias-eval.log",
                    "render_review.py",
                    "native/render.json",
                    "viewed.json",
                ),
            ),
            (
                FOLDS,
                (
                    "withheld_green.py",
                    "check_folds.py",
                    "fold-audit.json",
                    "compare_folds.py",
                    "plan.json",
                    "run.log",
                    "result.json",
                    "smoke.json",
                ),
            ),
            (
                GUIDES,
                (
                    "exterior_green.py",
                    "check_exterior.py",
                    "local-exclusion.json",
                    "score_exterior.py",
                    "plan.json",
                    "result.json",
                    "run.log",
                    "check_planted.py",
                    "planted.json",
                    "render_guides.py",
                    "native/render.json",
                    "viewed.json",
                ),
            ),
        ),
    )
    write_json(
        OUTPUT / "publication.json",
        {
            "archive": evidence,
            "parent": first["parent"],
            "frozen_learned_correction": first["correction"],
            "calibration": {
                "local": natural["metrics"],
                "disjoint_folds": folded["metrics"],
                "exterior": context["metrics"],
            },
            "planted": {"local": fresh["metrics"], "exterior": from_around["metrics"]},
            "native": {"local": first, "exterior": second},
            "timing_seconds": {
                "natural": natural["seconds"],
                "two_fold": 60 * folded["minutes"],
                "planted_including_parent": fresh["seconds"],
                "exterior": 60 * context["minutes"],
            },
            "scope": "Experimental inference components. Comparison at a fixed calibrated level of exact-flat fine-band additions. Separate planted panel and two reviewed standing GFX families. No full-model scores or newly trained weights.",
        },
    )


if __name__ == "__main__":
    publish()
