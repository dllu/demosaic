"""Audit waveform projection, fold separation and known carrier interference."""
import time

import numpy as np
from scipy.stats import rankdata

from competing import ROOT, WAVE, FOLDS, CACHE, N, MIN_SEPARATION, THRESHOLD, evidence, fixed_projection
from phase_edge import discovery, scores as previous_score
from demosaic.experiments.artifacts import reference, write_json
from demosaic.phase_witness import measure_witnesses, INDEX, UNIQUE, XI, YI, STEP, FREQ, SIDE


PROFILES={"iso400":{"shot":8e-5,"read":2.56e-8},"iso6400":{"shot":.00128,"read":6.5536e-6}}
LAYOUT=np.array([0,1,1,2])
CENTER=(SIDE//2)*SIDE+SIDE//2


def split_check():
    random=np.random.default_rng(85314)
    raw=random.normal(.19,.04,(4,128,128)).astype(np.float32)
    noise=PROFILES["iso6400"]
    original=measure_witnesses(raw,LAYOUT,noise)
    _,geom,pieces=evidence(raw,LAYOUT,noise,original,audit=True)
    perturbed=raw.copy()
    y,x=FOLDS[1]//16+YI[CENTER],FOLDS[1]%16+XI[CENTER]
    for p in range(4):
        perturbed[p,y,x]+=random.normal(0,.055,len(y))
    new=measure_witnesses(perturbed,LAYOUT,noise)
    _,other,_=evidence(perturbed,LAYOUT,noise,new,audit=True)
    for a,b in zip(geom[0],other[0],strict=True):
        np.testing.assert_array_equal(a[CENTER],b[CENTER])
    np.testing.assert_array_equal(original.phase[CENTER],new.phase[CENTER])
    np.testing.assert_array_equal(original.offsets[CENTER],new.offsets[CENTER])
    prior=previous_score(raw,LAYOUT,noise,original)
    inplace=np.minimum(pieces[0][2],pieces[1][2])
    delta=float(np.max(abs(prior[1]-inplace)))
    assert delta < 2e-5,delta

    plane=2
    f=1
    ids=np.arange(0,len(UNIQUE),13)[None]
    vals=random.normal(.18,.04,(1,len(FOLDS[f]))).astype(np.float32)
    phase=np.exp(1j*random.uniform(0,6,ids.shape)).astype(np.complex64)
    edge_pick=37
    bin_id=int(INDEX[18,0])
    active=(np.linalg.norm(UNIQUE[ids]-UNIQUE[bin_id],axis=-1)*STEP>=MIN_SEPARATION)
    current=fixed_projection(discovery(vals,plane,f,noise),f,plane,np.array([edge_pick]),
                             ids,phase,np.array([bin_id]),active)
    vector=WAVE[f][plane][:,bin_id]
    dictionary=CACHE[f][plane]
    prefix=np.vstack((dictionary["affine"],dictionary["edge"][edge_pick]))
    expected=[[],[]]
    for j,key in enumerate(ids[0]):
        sig=(WAVE[f][plane][:,key]*phase[0,j]).real
        basis=prefix if not active[0,j] else np.vstack((prefix,vector.real,vector.imag))
        Q=np.linalg.qr(basis.astype(np.float64).T)[0]
        left=sig-Q@(Q.T@sig)
        expected[0].append(float(vals[0]@left))
        expected[1].append(float(left@left))
    errors=[]
    for a,b in zip(current[2:4],expected,strict=True):
        errors.append(float(np.max(abs(a-b))))
    assert errors[0] < 2e-5 and errors[1] < 2e-4,errors
    return {"independent_discovery_invariant":True,"old_edge_z_max_abs_error":delta,
            "direct_amplitude_and_energy_max_abs_errors":errors,"direct_bin_count":len(ids[0])}


def auc(null, signal):
    ranks=rankdata([*null,*signal])
    return float((ranks[len(null):].sum()-len(signal)*(len(signal)+1)/2)/(len(signal)*len(null)))


def main():
    rng=np.random.default_rng(78459)
    start=time.monotonic()
    checks=split_check()
    yy,xx=np.indices((256,256))
    coords=np.stack((yy,xx),axis=-1).astype(np.float32)
    truth=np.array([[.008,.117],[.042,.168]],dtype=np.float32)
    nuisance,target=truth
    bins=FREQ[:,0]
    control_idx=int(np.argmin(np.linalg.norm(bins-target,axis=1)))
    control_idx2=int(np.argmin(np.linalg.norm(bins-nuisance,axis=1)))
    out=[]
    for iso,noise in PROFILES.items():
        for i in range(40):
            phase=rng.uniform(-np.pi,np.pi,6)
            carrier=np.cos(2*np.pi * np.einsum("yxd,d->yx",coords, nuisance)+phase[1]).astype("float32")
            faint=np.cos(2*np.pi * np.einsum("yxd,d->yx",coords, target)+phase[0]).astype("float32")
            scalar=.13 + .00014*(xx-127.5) - .00011*(yy-127.5)
            clean=scalar + .035*carrier
            values={k:clean+amplitude*faint for k,amplitude in (("strong-only",0.),("weak-.002",.002),("weak-.006",.006))}
            for j,(name,rgb) in enumerate(values.items()):
                cfa=np.roll(LAYOUT,i%4)
                # Keep each valid spatial Bayer layout.
                cfa=np.array(((0,1,1,2),(2,1,1,0),(1,0,2,1),(1,2,0,1))[i%4])
                quant=np.rint((rgb+np.sqrt(rgb*noise["shot"]+noise["read"])*rng.standard_normal(rgb.shape))*65535)/65535
                packed=np.stack([quant[p//2::2,p%2::2]for p in range(4)]).astype("float32")
                apparent=measure_witnesses(packed,cfa,noise)
                _,geometry,scores=evidence(packed,cfa,noise,apparent,audit=True,edges=False)
                score0=min(v[2,CENTER,control_idx]for v in scores)
                score1=min(v[0,CENTER,control_idx]for v in scores)
                a,b=[v[3][CENTER,control_idx]for v in geometry]
                found=[(UNIQUE[v[1][CENTER]]*STEP).tolist()for v in geometry]
                own=[bool(v[3][CENTER,control_idx2])for v in geometry]
                out.append(dict(noise=iso,role=name,draw=i,previous=float(score0),conditional=float(score1),
                                projection_applied=[bool(a),bool(b)],discovered=found,own_family_removed=own))
    report={}
    for iso in PROFILES:
        rows=[row for row in out if row["noise"]==iso]
        null=[row for row in rows if row["role"]=="strong-only"]
        report[iso]={"gap":{score:float(np.asarray([row[score]for row in null]).mean())
                            for score in ("previous","conditional")},
                     "gap_per_fold_competitor_coverage":np.mean([row["projection_applied"]for row in null],axis=0).tolist(),
                     "AUC":{role:{method:auc([r[method]for r in null],[r[method]for r in rows if r["role"]==role])
                                  for method in ("previous","conditional")}for role in ("weak-.002","weak-.006")}}
        print(iso,report[iso],flush=True)
    write_json(ROOT/"audit.json",{"driver":reference(__file__),"operator":reference(ROOT/"competing.py"),
                       "known_separation_cycles_px":float(np.linalg.norm(nuisance-target)),
                       "discovery_threshold":THRESHOLD,"checks":checks,"results":report,"rows":out,
                       "seconds":time.monotonic()-start,
                       "scope":"Independently corrupted exact two-carrier scenes. Carrier identification for scoring "
                               "uses the closest original frequency bin. Neither truth nor geometry enters the fit."})


if __name__=="__main__":
    main()
