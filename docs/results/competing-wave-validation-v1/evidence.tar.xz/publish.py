"""Publish native image comparisons and byte-exact method and measurement receipts."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent
OUT = Path("docs/results")/ROOT.name
IMAGES = Path("docs/images")/ROOT.name


def read(name):
    return json.loads((ROOT/name).read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def reference(path):
    return {"path":str(path),"sha256":sha(path)}


def check(record, local=None):
    assert sha(Path(record["path"]) if local is None else local)==record["sha256"], record


def write(path, record):
    path.write_text(json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)+"\n")


def transfer(entry, directory):
    binding=entry["image"]
    original=Path(binding["path"])
    path=IMAGES/directory/original.name
    path.parent.mkdir(parents=True,exist_ok=True)
    check(binding)
    shutil.copyfile(original,path)
    check(binding,path)
    binding["path"]=path.relative_to(IMAGES).as_posix()
    with Image.open(path) as im:
        pieces={}
        for panel in entry["panels"]:
            x,y,w,h=panel["png_xywh"]
            assert (w,h)==(160,160)
            assert 0<=x<=im.width-w and 0<=y<=im.height-h
            pieces[panel.get("label") or panel["name"]]=im.crop((x,y,x+w,y+h))
        assert len(pieces)==len(entry["panels"])
    return pieces


def review(training, pointer):
    manifests={}
    for directory,n in (("exact",3),("standing",8),("flat",2)):
        data=read(directory+"/manifest.json")
        assert data["checkpoint"]==training["checkpoint"] and data["parent"]==training["parent"] and len(data["rows"])==n
        assert data.get("training",data.get("weights"))==pointer
        check(data["driver"])
        for row in data["rows"]:
            frames=transfer(row["board"],directory)
            if directory=="standing":
                continue
            for trio in (row["triplet"],*row.get("other_triplets",{}).values()):
                pages=transfer(trio,directory)
                assert len(pages)==3
                for name,img in pages.items():
                    assert ImageChops.difference(img,frames[name]).getbbox() is None
        manifests[directory]=data
    manifests["native_image_review"]={
        "completed":True,"standing":8,"exact_comparisons":3,"exact_triplets":9,"flat_comparisons":2,"flat_triplets":2,
        "notes":"The sky and exact-flat cores stay smooth. The coarse fence remains coherent, with soft foliage and building details. The nominal right cab is slightly softer than directional training. The left and both transferred crops have incomplete crossings and mottled patches. No visibly new false color."
    }
    output=IMAGES/"manifest.json"
    write(output,manifests)
    return {"path":f"../../images/{ROOT.name}/manifest.json","sha256":sha(output)}


def archive(name, files):
    path=OUT/name
    names=sorted(files)
    with tarfile.open(path,"w:xz",preset=5)as bundle:
        for key in names:
            bundle.add(files[key],arcname=key,recursive=False)
    with tarfile.open(path)as bundle:
        assert bundle.getnames()==names
        for key in names:
            with bundle.extractfile(key)as stream:
                assert hashlib.file_digest(stream,"sha256").hexdigest()==sha(files[key])
    return {"path":name,"sha256":sha(path),"entries":len(files)}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    bound=ROOT/"training/completed.json"
    completed=read("training/completed.json")
    pointer=reference(bound)
    for name in ("driver","checkpoint","additional","frozen_phase_checkpoint","parent","prior_training"):
        check(completed[name])
    assert completed["control_reproduced_bit_for_bit"]
    endpoint=completed["checkpoint"]
    upstream={}
    for label,files in {
        "directional-gap-training-v1": ("direction.py","train_directions.py","evaluate_directions.py","training/completed.json"),
        "phase-correction-mixture-v1": ("mixture.py","evaluate_mixture.py","training/completed.json"),
        "phase-activity-v1":("activity.py",),
        "phase-edge-validation-v1":("phase_edge.py","edge_choices.py","audit_edge.py"),
        "quiet-parent-phase-v1":("quiet_heads.py","review_quiet.py","native_quiet.py"),
        "local-phase-envelope-v1":("gap_projection.py",),
        "learned-spectral-gaps-v1":("train_gap_head.py","evaluate_gap_head.py"),
    }.items():
        upstream |= {f"upstream/{label}/{name}":ROOT.parent/label/name for name in files}
    upstream["upstream/phase_witness.py"]=Path("src/demosaic/phase_witness.py")
    records=[
        "competing.py","train_competing.py","evaluate_competing.py","render_competing.py",
        "flat_competing.py","audit.py","audit_aligned.py","audit_donors.py","donor_nomination.py",
        "wire_nomination_audit.py","strength_contrasts.py","publish.py","native_for_view.py",
        "additional.json","training/completed.json",f"training/{Path(endpoint['path']).name}",
        "exact/manifest.json","standing/manifest.json","flat/manifest.json","tests.log",
        "audit.json","audit-aligned.json","donor-audit.json","wire-nomination.json",
        "strength-contrasts.json","prepare.log","train.log"
    ]
    summaries={}
    verified=read("strength-contrasts.json")
    for panel,size,tune in (("photo",256,16),("wire",48,24)):
        for scope,count in (("holdout",size),("calibration",tune)):
            name=f"{panel}-{scope}.json"
            receipt=read(name)
            assert len(receipt["rows"])==count and receipt["training"]==pointer
            assert receipt["checkpoint"]==endpoint and receipt["parent"]==completed["parent"]
            check(receipt["driver"])
            records.append(name)
        check(verified["source"][panel])
        summaries[panel]=verified["reports"][panel]["iso6400/independent"if panel=="photo"else "iso6400"]
    detector={}
    for record in ("audit.json","audit-aligned.json","donor-audit.json"):
        measured=read(record)
        check(measured["operator"])
        check(measured["driver"])
        assert measured["checks"]["independent_discovery_invariant"]
        detector[record]=measured["results"]
    bands=read("wire-nomination.json")
    assert len(bands["rows"])==48
    check(bands["driver"])
    prepared=review(completed,pointer)
    result=archive("evidence.tar.xz",{p:ROOT/p for p in records}|upstream)
    write(OUT/"publication.json",{
        "experiment":ROOT.name,"parent":completed["parent"],"frozen_crop_component":completed["frozen_phase_checkpoint"],
        "prior_training":completed["prior_training"],
        "checkpoint":{"member":f"training/{Path(endpoint['path']).name}","sha256":endpoint["sha256"]},
        "training":{k:completed[k]for k in ("seconds","photos","updates_per_head","visits_per_head",
                           "queries_per_head","epochs","seed","EMA","optimizer","arms","experts","directional_weight",
                           "control_reproduced_bit_for_bit")},
        "weights":"EMA for reported primary comparisons; raw weights and their numerical results are archived.",
        "training_complete":True,"scoped_numerical_evaluation_complete":True,"native_image_review_complete":True,
        "fixed_427_photo_and_camera_panels":"Outside this crop component study",
        "evidence":result,"presentation":prepared,"summary":summaries,
        "automatic_nomination_audit":bands["overview"],"controlled_detector_checks":detector,
    })
    print("Verified model, matched numeric replays, archives and native pixels.")


if __name__=="__main__":
    main()
