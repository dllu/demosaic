from pathlib import Path
import json
from PIL import Image
root=Path(__file__).resolve().parent
for family in ('standing','exact','flat'):
    folder=root/family
    result=json.loads((folder/'manifest.json').read_text())
    out=folder/'view'
    out.mkdir(exist_ok=True)
    for row in result['rows']:
        board=row['board']
        source=Image.open(board['image']['path']).convert('RGB')
        panels=board['panels']
        width=8+4*168
        canvas=Image.new('RGB',(width,(len(panels)+3)//4*192),'#eeeeee')
        for i,item in enumerate(panels):
            x,y,w,h=item['png_xywh']
            cut=source.crop((x,0,x+w,y+h))
            canvas.paste(cut,(8+i%4*168,i//4*192))
        canvas.save(out/Path(board['image']['path']).name)
