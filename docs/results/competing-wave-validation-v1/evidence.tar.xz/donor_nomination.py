"""Test whether removing a dominant donor wave improves exterior phase nomination."""
from dataclasses import replace

import numpy as np
from scipy.fft import rfft2

from demosaic.phase_witness import (ALLOWED, BASE, BAYER_OFFSETS, COORDINATES, FREQ, GRID, INDEX,
        MIRROR, NORM, PACKED, PAD, PENALTY, SHIFT, STEP, UNIQUE, WEIGHT, XI, YI,
        _gather, _neighborhood, _transform, _unit, measure_witnesses)
from competing import MIN_SEPARATION, THRESHOLD


YX=np.stack(np.indices((PACKED,PACKED)),axis=-1).astype(np.float32)*2


def frequency_distance(a,b):
    return np.minimum(np.linalg.norm(a-b,axis=-1),np.linalg.norm(a+b,axis=-1))


def wave_spectrum(packed,greens,weights,lead):
    """Fit a shared sinusoid to both green offsets, with separate plane means."""
    frequencies=UNIQUE[lead].astype('float32') * np.float32(2*np.pi*STEP)
    coordinates=YX[None]+BAYER_OFFSETS[greens,None,None].astype('float32')
    angles=np.einsum("wk,gyxk->wgyx",frequencies,coordinates)
    wave=np.stack((np.cos(angles),np.sin(angles)),axis=-1)
    window=WEIGHT[None,None,:,:,None]
    wave-=(wave*window).sum(axis=(2,3),keepdims=True)/NORM
    pixels=packed[:,greens]
    values=pixels-(pixels*WEIGHT).sum(axis=(2,3),keepdims=True)/NORM
    weights=weights[:,:,None,None]*WEIGHT
    left=np.einsum("wgyxa,wgyxb,wgyx->wab",wave,wave,weights)
    right=np.einsum("wgyxa,wgyx,wgyx->wa",wave,values,weights)
    beta=np.linalg.solve(left+np.eye(2,dtype=np.float32)[None]*1e-7,right[...,None])[...,0]
    fit=np.einsum("wgyxa,wa->wgyx",wave,beta)*WEIGHT
    f=rfft2(fit,s=(PAD,PAD),workers=1).reshape(len(lead),len(greens),-1)[...,COORDINATES]/PACKED
    f[...,MIRROR]=f[...,MIRROR].conj()
    f*=SHIFT[greens][None]
    return f.mean(axis=1)


def cleaned_nomination(raw,layout,noise,ordinary=None):
    """Nominate using disjoint donors after single-wave projection in each donor."""
    if ordinary is None:
        ordinary=measure_witnesses(raw,layout,noise)
    transform,variance=_transform(raw,noise["shot"],noise["read"])
    greens=np.flatnonzero(layout==1)
    direct=sum(_gather(transform,p)for p in greens)*.5
    green_variance=variance[:,greens].sum(axis=1)*.25
    base,base_variance=_neighborhood(direct,green_variance,GRID)
    signal=abs(direct)**2/green_variance[:,None].clip(min=4e-10)
    lead=signal.argmax(axis=-1)
    strength=np.take_along_axis(signal,lead[:,None],axis=-1)[:,0]
    windows=np.lib.stride_tricks.sliding_window_view(raw,(PACKED,PACKED),axis=(-2,-1))
    packed=np.moveaxis(windows[:,YI,XI],0,1)
    removed=wave_spectrum(packed,greens,1./variance[:,greens].clip(min=4e-10),lead)
    active=strength>=THRESHOLD
    clean,_=_neighborhood(direct-removed*active[:,None],green_variance,GRID)
    count,_=_neighborhood(active.astype(np.complex64)[:,None],green_variance,np.ones((1,2),np.complex64))
    outer_strength=abs(base)**2/base_variance[:,None].clip(min=4e-10)
    outer_lead=outer_strength.argmax(axis=-1)
    away=frequency_distance(FREQ[None,:,0],UNIQUE[outer_lead,None]*STEP)>=MIN_SEPARATION
    selected=away&(count.real>=2)
    both=np.where(selected[...,None],clean[:,INDEX],base[:,INDEX])
    power=abs(both)**2/base_variance[:,None,None].clip(min=4e-10)
    offsets=np.where(ALLOWED[None],power-PENALTY,-np.inf).argmax(axis=-1)
    np.testing.assert_array_equal(offsets[~selected],ordinary.offsets[~selected])
    winning=np.take_along_axis(both,offsets[...,None],axis=-1)[...,0]
    return replace(ordinary,frequency=FREQ[np.arange(len(BASE))[None],offsets],
                   offsets=offsets,phase=_unit(winning)),selected
