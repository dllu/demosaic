"""Project training errors onto known strong and weak wave families."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np
from scipy.fft import fft2
import torch

ROOT=Path(__file__).resolve().parent
FABRIC=ROOT.parent/"phase-correction-mixture-v1"
sys.path.insert(0,str(FABRIC))

from mixture import PRIOR
from head_corrected_broad import NATIVE_I, NATIVE_J, SYNTH, XI, YI
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

SIZE=SYNTH.shape[0]
Y,X=(a.ravel().astype(np.float64)for a in np.indices((SIZE,SIZE)))
COORD=np.stack((X,Y),axis=-1)
AFFINE=np.column_stack((np.ones(X.size),(COORD-15.5)/16))
WINDOW=SYNTH.astype(np.float64).ravel()
COMPONENTS=2*len(NATIVE_I)
FIELDS={"gap_weak":8,"gap_strong":4,"intact_weak":8}
ARMS=("whole-gap","weak-gap","directional")


def axes(parts):
    p=2*np.pi*COORD@parts.T
    return np.concatenate((np.cos(p),np.sin(p)),axis=1)


def bands(geometry):
    a=np.asarray(geometry["wave_angle"])
    first,second=np.asarray(geometry["freq"])[:,None]*np.stack((np.cos(a),np.sin(a)),axis=1)
    def within(grid):
        return grid[(abs(grid)<.5).all(axis=1)]
    strong=within(np.stack((first,2*first)))
    weak=within(np.stack((second,2*second,second+first,second-first)))
    return axes(strong),axes(weak)


def orth(design, earlier=None):
    if earlier is not None:
        design=design-earlier@(earlier.T@design)
    u,s,_=np.linalg.svd(design,full_matrices=False)
    return u[:,s>max(.02*s[0],1e-9)]


def projectors(mask, strong, weak):
    weight=WINDOW[mask]
    z=weight[:,None]
    affine=orth(AFFINE[mask]*z)
    lead=orth(strong[mask]*z,affine)
    faint=orth(weak[mask]*z,np.column_stack((affine,lead)))
    return lead,faint


def map_basis(q, mask, capacity):
    native=np.zeros((capacity,SIZE*SIZE),dtype=np.float64)
    native[:q.shape[1],mask]=(q*WINDOW[mask,None]).T
    cells=fft2(native.reshape(capacity,SIZE,SIZE),norm="ortho",workers=1)
    sub=4*cells[:,NATIVE_I,NATIVE_J]
    return np.stack((sub.real,sub.imag),axis=-1).reshape(capacity,COMPONENTS)


def geometry(case, pointer):
    out={k:np.zeros((len(XI),width,COMPONENTS),dtype=np.float16)for k,width in FIELDS.items()}
    masses=np.zeros((len(XI),2),dtype=np.float32)
    if case["style"]=="photo":
        return out|{"direction_mass":masses}
    evidence=read_json(checked(pointer["measurement"]))
    assert evidence["index"]==case["index"]==pointer["index"]
    with np.load(checked(evidence["input"]),allow_pickle=False)as stored:
        support=stored["support"]
    around=np.lib.stride_tricks.sliding_window_view(support,(SIZE,SIZE))[2*YI,2*XI]
    around=around.reshape(len(XI),-1)
    strong,weak=bands(case["geometry"])
    num=(around==0).sum(1)
    has_gap=(case["style"] in ("ellipse","strip"))
    assert bool(num.any())==has_gap
    for group in (0,1):
        if group==0 and not has_gap:
            continue
        region=around==0 if group==0 else around>=.97
        for i in np.flatnonzero(region.sum(1)>=64):
            chosen=region[i]
            strong_q,weak_q=projectors(chosen,strong,weak)
            masses[i,group]=np.sum(WINDOW[chosen]**2)
            if group==0:
                out["gap_weak"][i]=map_basis(weak_q,chosen,FIELDS["gap_weak"])
                out["gap_strong"][i]=map_basis(strong_q,chosen,FIELDS["gap_strong"])
            else:
                out["intact_weak"][i]=map_basis(weak_q,chosen,FIELDS["intact_weak"])
    return out|{"direction_mass":masses}


def precompute():
    source=reference(FABRIC/"features.json")
    binding=read_json(checked(source))
    parents=read_json(checked(binding["prior_training_parents"]))
    plan=read_json(checked(parents["plan"]))
    assert len(plan["batches"])==len(parents["rows"])==448
    output=ROOT/"directions"
    output.mkdir()
    start=time.monotonic()
    data={}
    active=[]
    with ThreadPoolExecutor(3) as workers:
        pair=zip(plan["batches"],parents["rows"],strict=True)
        for i,row in enumerate(workers.map(lambda args:geometry(*args),pair)):
            for key,field in row.items():
                assert np.isfinite(field).all()
                if key not in data:
                    data[key]=np.lib.format.open_memmap(output/f"{key}.npy",mode="w+",
                                      dtype=field.dtype,shape=(448,*field.shape))
                data[key][i]=field
            active.append((row["direction_mass"]>0).sum(0).tolist())
            if (i+1)%56==0:
                print(i+1,round(time.monotonic()-start,2),flush=True)
    for value in data.values():
        value.flush()
    write_json(ROOT/"directions.json",{"driver":reference(__file__),"mixture_features":source,
        "training_cases":parents["plan"],"tensors":{key:reference(output/f"{key}.npy")for key in data},
        "tiles":np.asarray(active).sum(0).tolist(),"sources":448,"seconds":time.monotonic()-start,
        "scope":"Project onto planted wave quadratures orthogonal to tone and, for weak losses, the continuing strong carrier. Labels appear in training loss only."})


def energy(coeff, transform, mass):
    values=torch.einsum("btrf,btf->btr",transform,coeff.flatten(-2))
    return values.square().sum()/mass.sum().clamp_min(1.)


if __name__=="__main__":
    precompute()
