"""Train matched routers with spatial and direction-separated losses."""
from copy import deepcopy
import time

import numpy as np
import torch

from direction import ROOT,FABRIC,ARMS,energy
from mixture import Mixture,EXPERTS
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from head_corrected_broad import EXACT_FLAT,NATIVE_I,NATIVE_J,SYNTH
from train_gap_head import SEED,EPOCHS,PHOTOS,batch,choose_tiles,focal_energy,objective


def samples(arrays, projections, selected, choices, device):
    result=batch(arrays,selected,choices,device)
    for name,value in projections.items():
        part=np.asarray(value[selected[:,None],choices],dtype=np.float32)
        result[name]=torch.from_numpy(part).to(device)
    return result


def losses(error, data, taper, coordinates):
    absolute=error[:,0]
    paired=absolute-error[:,1]
    weight=data["void"]*taper
    raw=2*focal_energy(paired,weight,coordinates)+focal_energy(absolute,weight,coordinates)
    gap,intact=data["direction_mass"].unbind(-1)
    weak=2*energy(paired,data["gap_weak"],gap)+energy(absolute,data["gap_weak"],gap)
    strong=energy(absolute,data["gap_strong"],gap)
    present=energy(paired,data["intact_weak"],intact)
    return raw,weak,weak+strong+present


def calibrate(network, arrays, projections, taper, coordinates, device):
    rng=np.random.default_rng(SEED+313)
    candidate=np.flatnonzero(np.any(projections["direction_mass"][...,0]>0,axis=1))
    assert len(candidate)==112
    norms=[]
    count=arrays["descriptor"].shape[0]
    for _ in range(48):
        peers=rng.choice(candidate,2,replace=False)
        others=rng.choice(np.setdiff1d(np.arange(count),peers),2,replace=False)
        selected=np.r_[peers,others]
        choices=choose_tiles(rng,arrays["void_weight"],selected)
        data=samples(arrays,projections,selected,choices,device)
        out=network(data["descriptor"],data["correction"],data["experts"])
        values=losses(out-data["target"],data,taper,coordinates)
        per=[]
        for value in values:
            grad=torch.autograd.grad(value,tuple(network.parameters()),retain_graph=True)
            per.append(torch.linalg.vector_norm(torch.cat([g.flatten()for g in grad])).item())
        norms.append(per)
    observed=np.asarray(norms)
    ratio=np.median(observed[:,:1]/observed[:,1:].clip(min=1e-12),axis=0)
    chosen=np.r_[1.,ratio.clip(.25,32.)]
    return dict(zip(ARMS,chosen,strict=True)),observed.tolist(),ratio.tolist()


def main():
    torch.manual_seed(SEED)
    torch.set_num_threads(1)
    device="cuda"
    total=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/total))
    direction=reference(ROOT/"directions.json")
    layout=read_json(checked(direction))
    features=read_json(checked(layout["mixture_features"]))
    earlier=reference(FABRIC/"training/completed.json")
    previous=read_json(checked(earlier))
    assert previous["features"]==layout["mixture_features"]
    arrays={name:np.load(checked(v),allow_pickle=False,mmap_mode="r")for name,v in features["tensors"].items()}
    proj={name:np.load(checked(v),allow_pickle=False,mmap_mode="r")for name,v in layout["tensors"].items()}
    adaptive=Mixture(adaptive=True).to(device)
    nets={k:deepcopy(adaptive)for k in ARMS}
    ema={k:deepcopy(m).requires_grad_(False)for k,m in nets.items()}
    taper=torch.tensor(SYNTH**2,device=device,dtype=torch.float32)
    coordinates=tuple(torch.tensor(a,device=device)for a in (NATIVE_I,NATIVE_J))
    start=time.monotonic()
    calibration,gradient_samples,uncapped=calibrate(adaptive,arrays,proj,taper,coordinates,device)
    elapsed_calibration=time.monotonic()-start
    print("Training-only gradient calibration",calibration,round(elapsed_calibration,2),flush=True)
    optimizer=torch.optim.AdamW([p for net in nets.values()for p in net.parameters()],lr=.001,weight_decay=.001)
    count=features["sources"]
    updates=count//PHOTOS*EPOCHS
    rng=np.random.default_rng(SEED)
    start=time.monotonic()
    progress=[]
    step=0
    for epoch in range(EPOCHS):
        ids=rng.permutation(count)
        for offset in range(0,count,PHOTOS):
            selected=ids[offset:offset+PHOTOS]
            choices=choose_tiles(rng,arrays["void_weight"],selected)
            data=samples(arrays,proj,selected,choices,device)
            flat=torch.as_tensor(EXACT_FLAT[choices],device=device)
            step+=1
            lr=(.001*step/24 if step<=24 else .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(updates-24))))
            optimizer.param_groups[0]["lr"]=float(lr)
            optimizer.zero_grad(set_to_none=True)
            results={}
            for i,route in enumerate(ARMS):
                net=nets[route]
                output=net(data["descriptor"],data["correction"],data["experts"])
                loss,error,pair=objective(output,data["target"],data["baseline"],flat)
                extra=losses(error,data,taper,coordinates)[i]
                total=loss+float(calibration[route])*extra
                total.backward()
                norm=torch.nn.utils.clip_grad_norm_(tuple(net.parameters()),2.)
                assert torch.isfinite(norm)
                results[route]=torch.stack((total,loss,extra,pair,norm)).detach()
            optimizer.step()
            with torch.no_grad():
                for k in ARMS:
                    torch._foreach_lerp_(tuple(ema[k].parameters()),tuple(nets[k].parameters()),.01)
            if step==1 or step%48==0 or step==updates:
                row={k:v.cpu().tolist() for k,v in results.items()}
                progress.append({"step":step,"epoch":epoch+1,"losses":row})
                print(step,round(time.monotonic()-start,3),row,flush=True)
    torch.cuda.synchronize()
    seconds=time.monotonic()-start
    folder=ROOT/"training"
    folder.mkdir()
    path=folder/f"step{step:06d}.pt"
    with path.open("xb")as out:
        torch.save({"raw":{k:n.state_dict()for k,n in nets.items()},"EMA":{k:m.state_dict()for k,m in ema.items()},
                    "optimizer":optimizer.state_dict(),"updates":step,"seed":SEED},out)
    write_json(folder/"completed.json",{
        "driver":reference(__file__),"directions":direction,"features":layout["mixture_features"],
        "prior_training":earlier,"parent":previous["parent"],"frozen_phase_checkpoint":previous["frozen_phase_checkpoint"],
        "checkpoint":reference(path),"seconds":seconds,"calibration_seconds":elapsed_calibration,
        "updates_per_head":step,"photos":count,"visits_per_head":count*EPOCHS,"queries_per_head":count*EPOCHS*3,
        "epochs":EPOCHS,"seed":SEED,"EMA":.99,"optimizer":previous["optimizer"],"experts":EXPERTS,
        "gradient_match":{"weights":calibration,"unclipped_ratios":uncapped,"initial_norms":gradient_samples,
            "scope":"48 batches drawn exclusively from the original training set, two known-gap sources per batch, before any update."},
        "arms":{"whole-gap":"Prior twofold paired and onefold absolute spatial gap loss",
                "weak-gap":"Same paired/absolute emphasis projected onto the weak band in known gaps",
                "directional":"Weak-gap projections plus absolute strong-band gap error and paired intact weak-band error"},
        "progress":progress
    })


if __name__=="__main__":
    main()
