"""Decompose error in the annotated zero-wire footprint by known structure."""
import numpy as np
from scipy.special import expit

from review_quiet import CORE

Z=np.arange(256,dtype=np.float64)-127.5
Y,X=(a[CORE] for a in np.meshgrid(Z,Z,indexing="ij"))


def orthogonal(design, earlier):
    if earlier.shape[1]:
        design=design-earlier@(earlier.T@design)
    u,s,_=np.linalg.svd(design,full_matrices=False)
    return u[:,s>max(1e-10,1e-8*s[0])]


def quadratures(native,freq):
    x,y=native.T
    angle=2*np.pi*(x[:,None]*freq[:,0]+y[:,None]*freq[:,1])
    return np.concatenate((np.cos(angle),np.sin(angle)),axis=1)


def subspace(geometry, mask):
    if not mask.any():
        return None
    x,y=X[mask],Y[mask]
    vector=np.stack((x,y),axis=-1)
    a=geometry["angle"]
    d=np.cos(a)*x+np.sin(a)*y-geometry["edge"]
    trend=np.column_stack((np.ones(len(x)),x/64,y/64,expit(d/1.3)))
    quiet=orthogonal(trend,np.empty((len(x),0)))
    strong,weak=np.asarray(geometry["frequency"])
    strong_bands=np.arange(1,5)[:,None]*strong
    weak_bands=np.vstack((np.arange(1,5)[:,None]*weak,weak+strong,weak-strong))
    def valid(freq):
        return freq[(abs(freq)<.5).all(axis=1)]
    first=orthogonal(quadratures(vector,valid(strong_bands)),quiet)
    second=orthogonal(quadratures(vector,valid(weak_bands)),np.column_stack((quiet,first)))
    return quiet,first,second


def project(q,error):
    return q.T@error


def summarize(change,error,gap,space):
    keys=("gap_tone_added","gap_strong_band_added","gap_weak_band_added","gap_other_added",
          "gap_weak_band_error","gap_other_error","gap_weak_energy_fraction")
    if space is None:
        return dict.fromkeys(keys,None)
    scale=65535./np.sqrt(gap.sum())
    difference=change[gap]
    true_error=error[gap]
    levels=[project(q,difference)for q in space]
    squares=np.asarray([np.sum(q*q)for q in levels])
    err_weak=project(space[-1],true_error)
    overall=float(np.sum(difference*difference))
    remaining=max(0.,overall-squares.sum())
    assert squares.sum()<=overall+1e-9
    span=np.column_stack(space)
    err_other=true_error-span@(span.T@true_error)
    numbers=(*[float(scale*np.sqrt(a))for a in squares],float(scale*np.sqrt(remaining)),
             float(scale*np.linalg.norm(err_weak)), float(scale*np.linalg.norm(err_other)),
             float(squares[-1]/max(1e-20,overall)))
    return dict(zip(keys,numbers,strict=True))
