"""Measure exterior nomination and reserved scores on the fixed wire panel."""
from concurrent.futures import ThreadPoolExecutor
import time

import numpy as np

from competing import ROOT,evidence
from donor_nomination import cleaned_nomination,frequency_distance
from mixture import PRIOR
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.phase_witness import FREQ,XI,YI,measure_witnesses

WINDOWS=(2*YI,2*XI)
CENTERS=(2*YI+16,2*XI+16)
CORE=(CENTERS[0]>=64)&(CENTERS[0]<192)&(CENTERS[1]>=64)&(CENTERS[1]<192)
MATCH=.015625


def measure(task,plan):
    case=plan["sources"][task["index"]]
    noise=plan["profiles"][task["noise"]]
    weak=np.asarray(case["geometry"]["frequency"][1])[::-1]
    index=int(np.argmin(frequency_distance(FREQ[:,0],weak)))
    x,y,w,h=plan["query"]
    assert w==h==256
    with np.load(checked(task["input"]),allow_pickle=False)as source:
        raw=source["packed"][:2,:,y//2:y//2+128,x//2:x//2+128]
        colors=source["colors"][:2]
        support=source["support"]
    sampled=np.lib.stride_tricks.sliding_window_view(support,(8,8))[CENTERS[0]-4,CENTERS[1]-4].mean((1,2))
    masks={"intact":CORE&(sampled>=.97),"gap":CORE&(sampled<=.01)}
    result={}
    for role,(packed,cfa) in zip(("weak-present","weak-free"),zip(raw,colors,strict=True),strict=True):
        ordinary=measure_witnesses(packed,cfa,noise)
        cleaned,active=cleaned_nomination(packed,cfa,noise,ordinary)
        details={}
        for name,phase in (("ordinary",ordinary),("cleaned",cleaned)):
            _,geometry,score=evidence(packed,cfa,noise,phase,audit=True)
            z0=np.minimum(score[0][2],score[1][2])[:,index]
            z1=np.minimum(score[0][0],score[1][0])[:,index]
            dist=frequency_distance(phase.frequency[:,index],weak)
            aimed=dist<=MATCH
            details[name]={}
            for region,mask in masks.items():
                if not mask.any():
                    continue
                details[name][region]={"windows":int(mask.sum()),
                  "frequency_match_fraction":float(aimed[mask].mean()),
                  "conditional_z_mean":float(z1[mask].mean()),"earlier_z_mean":float(z0[mask].mean()),
                  "positive_match_fraction":float((aimed&(z1>.55))[mask].mean()),
                  "coverage_fraction":float(active[:,index][mask].mean()),
                  "local_projection_both_fraction":float((geometry[0][3][:,index]&geometry[1][3][:,index])[mask].mean())}
        result[role]=details
    return {"noise":task["noise"],"input":task["input"],"source":case["source"]["id"],
            "exact_weak_frequency_yx":weak.tolist(),"family":case["geometry"]["family"],"roles":result}


def main():
    started=time.monotonic()
    baseline=reference(PRIOR/"wire-parent.json")
    old=read_json(checked(baseline))
    plan=read_json(checked(old["plan"]))
    cases=read_json(checked(old["inputs"]))["rows"]
    with ThreadPoolExecutor(3)as pool:
        rows=list(pool.map(lambda r:measure(r,plan),cases))
    assert len(rows)==48
    out={}
    rng=np.random.default_rng(20261119)
    for profile in ("iso400","iso6400"):
        chosen=[row for row in rows if row["noise"]==profile]
        assert len({r["source"] for r in chosen})==24
        out[profile]={}
        for role in ("weak-present","weak-free"):
            out[profile][role]={}
            for region in ("intact","gap"):
                built=[row["roles"][role]for row in chosen if region in row["roles"][role]["ordinary"]]
                record={"sources":len(built)}
                for key in ("frequency_match_fraction","conditional_z_mean","earlier_z_mean",
                            "positive_match_fraction","local_projection_both_fraction"):
                    pair=np.array([[arm["ordinary"][region][key],arm["cleaned"][region][key]]for arm in built])
                    delta=pair[:,1]-pair[:,0]
                    bounds=np.percentile(delta[rng.integers(0,len(built),(4096,len(built)))].mean(1),(2.5,97.5))
                    record[key]={"mean_each":pair.mean(0).tolist(),"difference":float(delta.mean()),"interval_95":bounds.tolist()}
                out[profile][role][region]=record
    write_json(ROOT/"wire-nomination.json",{"driver":reference(__file__),"nomination":reference(ROOT/"donor_nomination.py"),
      "source":baseline,"fixed_inputs":old["inputs"],"plan":old["plan"],"rows":rows,"overview":out,
      "seconds":time.monotonic()-started,"scope":"Exact coordinates define evaluation only. Source-level paired intervals. An automatic candidate matches when it is within .015625 cycles per pixel, allowing sign reversal."})


if __name__=="__main__":
    main()
