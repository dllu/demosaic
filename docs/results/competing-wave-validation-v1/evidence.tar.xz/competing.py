"""Test each nominated Bayer waveform after removing another locally supported wave."""
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
DIRECTIONAL = ROOT.parent / "directional-gap-training-v1"
sys.path.insert(0, str(DIRECTIONAL))
import direction  # loads the original mixture study and its pinned module paths
from mixture import inputs as old_inputs, DESCRIPTORS
from phase_edge import (CACHE, FOLDS, NATIVE, BAYER_OFFSETS, HALF, N, SUPPORT,
                        PHASES, discovery, fft_columns)
from demosaic.phase_witness import measure_witnesses, INDEX, UNIQUE, XI, YI, STEP

NEW = ("reserved_competing_wave", "predictive_competing_wave",
       "reserved_removed_leakage", "interfering_wave_snr", "competing_wave_overlap")
THRESHOLD = 18.
MIN_SEPARATION = .052
COORDS = [[(NATIVE[FOLDS[fold]] + BAYER_OFFSETS[p]).astype(np.float32) for p in range(4)]
          for fold in range(2)]
VECTORS = (UNIQUE * (2 * np.pi * STEP)).astype(np.float32)
WAVE = [[np.exp(-1j * (COORDS[fold][p] @ VECTORS.T)).astype(np.complex64)
         for p in range(4)] for fold in range(2)]
SQRT2 = np.float32(2**-.5)


def fit_terms(work, fold, plane, edge, selected):
    """Return inner products after removing affine tone and the discovery edge."""
    data, affine, measured_edges, variance, _ = work
    stock = CACHE[fold][plane]
    shade = edge.clip(min=0)
    use = (edge >= 0)[:, None]
    edge_wave = stock["edge_fft"][shade[:, None], selected] * use
    affine_wave = stock["affine_fft"][:, selected]
    dot = np.take_along_axis(fft_columns(data, fold, plane), selected, axis=1)
    dot -= np.einsum("wq,qwf->wf", affine, affine_wave)
    dot -= measured_edges[np.arange(len(edge)), shade, None] * edge_wave
    double = stock["twice_fft"][selected]
    power_cos = .5 * (HALF + double.real)
    power_sin = .5 * (HALF - double.real)
    cross = .5 * double.imag
    power_cos -= np.sum(affine_wave.real**2, axis=0) + edge_wave.real**2
    power_sin -= np.sum(affine_wave.imag**2, axis=0) + edge_wave.imag**2
    cross -= np.sum(affine_wave.real * affine_wave.imag, axis=0) + edge_wave.real * edge_wave.imag
    return dot, power_cos, power_sin, cross


def leading(work, fold, greens, edge, selected):
    """Choose the strongest same-signal two-quadrature fit in discovery samples."""
    weights = [1. / row[3][:, None] for row in work]
    terms = [fit_terms(row, fold, p, edge, selected) for row, p in zip(work, greens, strict=True)]
    dot, cos, sine, cross = [
        a * weights[0] + b * weights[1] for a, b in zip(*terms, strict=True)
    ]
    determinant = cos * sine - cross**2
    valid = (determinant >= .10 * cos * sine) & (cos > 0) & (sine > 0)
    explained = (sine*dot.real**2 + cos*dot.imag**2 - 2*cross*dot.real*dot.imag)
    score = np.where(valid, explained / determinant.clip(min=1.), 0.)
    best = np.argmax(score, axis=1)
    indices = np.arange(len(best))
    power = score[indices, best]
    bins = selected[indices, best]
    return bins, power


def residual_quadratures(fold, plane, edge, bins):
    """Orthonormal competitor columns on a fold's own sampling coordinates."""
    stock = CACHE[fold][plane]
    shade = stock["edge"][edge.clip(min=0)] * (edge >= 0)[:, None]
    aff = stock["affine"]
    waves = WAVE[fold][plane][:, bins].T
    columns = np.stack((waves.real, waves.imag), axis=1)
    columns -= (columns @ aff.T) @ aff
    columns -= np.sum(columns * shade[:, None], axis=-1, keepdims=True) * shade[:, None]
    first, second = columns[:, 0], columns[:, 1]
    norm = np.linalg.norm(first, axis=1, keepdims=True)
    first /= norm.clip(min=1e-5)
    second -= (first * second).sum(axis=1, keepdims=True) * first
    norm2 = np.linalg.norm(second, axis=1, keepdims=True)
    second /= norm2.clip(min=1e-5)
    valid = (norm >= 1.) & (norm2 >= 1.)
    return columns * valid[:, None]


def fixed_projection(work, fold, plane, edge, selected, phase, bins, usable):
    dot, cos, sine, cross = fit_terms(work, fold, plane, edge, selected)
    base = (dot*phase).real
    energy = phase.real**2 * cos + phase.imag**2 * sine - 2 * phase.real * phase.imag * cross
    q = residual_quadratures(fold,plane,edge,bins)
    spectra = fft_columns(q,fold,plane)
    coupling = (np.take_along_axis(spectra,selected[:,None],axis=-1)*phase[:,None]).real
    coupling *= usable[:,None]
    beta = np.einsum("wqn,wn->wq",q,work[0])
    norm = np.sum(coupling**2,axis=1)
    filtered = base-np.einsum("wq,wqf->wf",beta,coupling)
    return base, energy, filtered, np.maximum(energy-norm, 1e-5), norm


def evidence(raw, layout, noise, phase=None, *, audit=False, edges=True):
    if phase is None:
        phase = measure_witnesses(raw, layout, noise)
    windows = np.lib.stride_tricks.sliding_window_view(raw, (16,16), axis=(-2,-1))
    windows = np.ascontiguousarray(windows[:, YI, XI].reshape(4, len(XI), N))
    greens = np.flatnonzero(layout==1)
    measured = [[discovery(windows[p][:,FOLDS[f]], p, f, noise) for p in greens] for f in range(2)]
    selected = INDEX[PHASES,phase.offsets]
    conjugate = phase.phase.conj()
    tested = UNIQUE[selected] * STEP
    records=[]
    results=[]
    for f in range(2):
        h=1-f
        support=measured[f][0][-1]+measured[f][1][-1]
        edge=np.where((support.max(axis=1)>=SUPPORT)&edges,support.argmax(axis=1),-1)
        bins, power=leading(measured[f],f,greens,edge,selected)
        leader=UNIQUE[bins,None]*STEP
        distance=np.minimum(np.linalg.norm(tested-leader,axis=-1),np.linalg.norm(tested+leader,axis=-1))
        usable=(power[:,None]>=THRESHOLD)&(distance>=MIN_SEPARATION)
        groups=[]
        for i, plane in enumerate(greens):
            fit = fixed_projection(measured[f][i],f,plane,edge,selected,conjugate,bins,usable)
            test = fixed_projection(measured[h][i],h,plane,edge,selected,conjugate,bins,usable)
            base, oldnorm, a,b,overlap=test
            sigma=np.sqrt(measured[f][i][3][:,None])
            z = a/(sigma*np.sqrt(b))
            gain=np.maximum(fit[2],0.) / fit[3]
            valid=(b>=.10*HALF)&(fit[3]>=.10*HALF)
            original=np.where(oldnorm>=.10*HALF,base/(sigma*np.sqrt(oldnorm.clip(min=1e-5))),0.)
            groups.append(np.stack((np.where(valid,z,0.),
                          np.where(valid&(gain>0),z-.5*gain*np.sqrt(b)/sigma,0.),
                          original, overlap/oldnorm.clip(min=1e-5))))
        both = groups[0]+groups[1]
        results.append(np.concatenate((both[:3]*SQRT2, both[3:]*.5, np.sqrt(power)[:,None][None]*usable[None]),axis=0))
        records.append((edge,bins,power,usable))
    a,b=results
    reserved=np.minimum(a[0],b[0])
    prior=np.minimum(a[2],b[2])
    values=np.stack((np.arcsinh(reserved),np.arcsinh(np.minimum(a[1],b[1])),np.arcsinh(prior-reserved),
                     np.log1p(np.minimum(a[4],b[4])),np.maximum(a[3],b[3])),axis=-1)
    values=values.clip(-6,6).astype(np.float32)
    return (values, records, results) if audit else values


def inputs(raw, layout, noise, box, donors, parent, wb, matrix, component, target=None):
    field, noise_scale, frozen, spec, base = old_inputs(raw,layout,noise,box,donors,parent,wb,matrix,component,target)
    extra = evidence(raw,layout,noise)
    return field, noise_scale, frozen, spec, np.concatenate((base,extra),axis=-1)
