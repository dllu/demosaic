"""Train matched directional routers with and without the competing-wave evidence."""
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch import nn

from competing import ROOT,DIRECTIONAL,NEW,DESCRIPTORS,evidence
from direction import FABRIC
from mixture import Mixture,EXPERTS
from train_directions import losses,samples
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from head_corrected_broad import EXACT_FLAT, NATIVE_I, NATIVE_J, SYNTH
from train_gap_head import SEED, EPOCHS, PHOTOS, choose_tiles, objective

ARMS=("directional-replay","competing")


class CompetingMixture(Mixture):
    def __init__(self, base=None):
        super().__init__(adaptive=True)
        if base is not None:
            self.load_state_dict(base.state_dict(),strict=True)
        self.additional = nn.Linear(len(NEW),self.router[0].out_features,bias=False)
        nn.init.zeros_(self.additional.weight)

    def weights(self, descriptor):
        split = len(DESCRIPTORS)
        hidden = self.router[0](descriptor[...,:split]) + self.additional(descriptor[...,split:])
        for layer in self.router[1:]:
            hidden = layer(hidden)
        return (self.logits + hidden).softmax(dim=-1)


def prepare():
    feature_source=reference(FABRIC/"features.json")
    parents=read_json(checked(read_json(checked(feature_source))["prior_training_parents"]))
    plan=read_json(checked(parents["plan"]))
    assert len(plan["batches"])==len(parents["rows"])==448
    def sample(pair):
        case,row=pair
        pointer=read_json(checked(row["measurement"]))
        assert pointer["index"]==row["index"]==case["index"]
        with np.load(checked(pointer["input"]),allow_pickle=False) as source:
            args=zip(source["packed"],source["colors"],strict=True)
            return np.stack([evidence(raw,cfa,case["noise"])for raw,cfa in args])
    started=time.monotonic()
    path=ROOT/"additional.npy"
    with ThreadPoolExecutor(3) as pool:
        ready=pool.map(sample,zip(plan["batches"],parents["rows"],strict=True))
        array=None
        for i,value in enumerate(ready):
            assert np.isfinite(value).all()
            if array is None:
                array=np.lib.format.open_memmap(path,mode="w+",dtype=np.float16,shape=(448,*value.shape))
            array[i]=value
            if (i+1)%28==0:
                print(i+1,round(time.monotonic()-started,2),flush=True)
    array.flush()
    write_json(ROOT/"additional.json",{
        "driver":reference(__file__),"operator":reference(ROOT/"competing.py"),
        "source":feature_source,"training_cases":parents["plan"],"additional":reference(path),
        "sources":448,"roles":3,"shape":list(array.shape),"descriptors":NEW,
        "seconds":time.monotonic()-started,
        "scope":"Only noisy Bayer input. Candidate phase comes from four disjoint neighbors. "
                "The competing wave is nominated on discovery green samples and projected separately "
                "on the reserved coordinates. FP16 feature storage; training calculations in FP32."})


def train():
    torch.set_num_threads(1)
    torch.manual_seed(SEED)
    device="cuda"
    total=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(1.,5*2**30/total))
    more=reference(ROOT/"additional.json")
    extra=read_json(checked(more))
    direction=reference(DIRECTIONAL/"training/completed.json")
    prior=read_json(checked(direction))
    assert prior["features"]==extra["source"]
    weight=prior["gradient_match"]["weights"]["directional"]
    arrays={k:np.load(checked(p),allow_pickle=False,mmap_mode="r")
            for k,p in read_json(checked(prior["features"]))["tensors"].items()}
    projections={k:np.load(checked(p),allow_pickle=False,mmap_mode="r")
            for k,p in read_json(checked(prior["directions"]))["tensors"].items()}
    extra_array=np.load(checked(extra["additional"]),allow_pickle=False,mmap_mode="r")
    networks={"directional-replay":Mixture(adaptive=True).to(device)}
    networks["competing"]=CompetingMixture(networks["directional-replay"]).to(device)
    average={k:deepcopy(v).requires_grad_(False)for k,v in networks.items()}
    optimizer=torch.optim.AdamW([p for model in networks.values()for p in model.parameters()],lr=.001,weight_decay=.001)
    taper=torch.tensor(SYNTH**2,device=device,dtype=torch.float32)
    coordinates=tuple(torch.tensor(v,device=device)for v in (NATIVE_I,NATIVE_J))
    count=extra["sources"]
    rng=np.random.default_rng(SEED)
    progress=[]
    steps=count//PHOTOS*EPOCHS
    start=time.monotonic()
    step=0
    for epoch in range(EPOCHS):
        sources=rng.permutation(count)
        for offset in range(0,count,PHOTOS):
            ids=sources[offset:offset+PHOTOS]
            tiles=choose_tiles(rng,arrays["void_weight"],ids)
            data=samples(arrays,projections,ids,tiles,device)
            feature=np.asarray([extra_array[p][:,tile]for p,tile in zip(ids,tiles,strict=True)],dtype=np.float32)
            extended=torch.cat((data["descriptor"],torch.from_numpy(feature).to(device)),dim=-1)
            flat=torch.as_tensor(EXACT_FLAT[tiles],device=device)
            step+=1
            optimizer.param_groups[0]["lr"]=float(.001*step/24 if step<=24 else
                 .0001+.0009*(.5+.5*np.cos(np.pi*(step-24)/(steps-24))))
            optimizer.zero_grad(set_to_none=True)
            results={}
            for name,desc in zip(ARMS,(data["descriptor"],extended),strict=True):
                model=networks[name]
                output=model(desc,data["correction"],data["experts"])
                base,error,pair=objective(output,data["target"],data["baseline"],flat)
                direction_loss=losses(error,data,taper,coordinates)[2]
                total=base+float(weight)*direction_loss
                total.backward()
                norm=torch.nn.utils.clip_grad_norm_(tuple(model.parameters()),2.)
                assert torch.isfinite(norm)
                results[name]=torch.stack((total,base,direction_loss,pair,norm)).detach()
            optimizer.step()
            with torch.no_grad():
                for name in ARMS:
                    torch._foreach_lerp_(tuple(average[name].parameters()),tuple(networks[name].parameters()),.01)
            if step==1 or step%48==0 or step==steps:
                stats={k:v.cpu().tolist()for k,v in results.items()}
                progress.append({"step":step,"stats":stats})
                print(step,round(time.monotonic()-start,2),stats,flush=True)
    torch.cuda.synchronize()
    seconds=time.monotonic()-start
    old=torch.load(checked(prior["checkpoint"]),weights_only=True,map_location="cpu")
    for label,value in (("EMA",average),("raw",networks)):
        assert all(torch.equal(t.detach().cpu(),old[label]["directional"][k])
                   for k,t in value["directional-replay"].state_dict().items()),label
    folder=ROOT/"training"
    folder.mkdir()
    endpoint=folder/f"step{step:06d}.pt"
    with endpoint.open("xb")as stream:
        torch.save({"EMA":{k:v.state_dict()for k,v in average.items()},
                    "raw":{k:v.state_dict()for k,v in networks.items()},"optimizer":optimizer.state_dict(),
                    "updates":step,"seed":SEED},stream)
    write_json(folder/"completed.json",{"driver":reference(__file__),"additional":more,
        "prior_training":direction,"parent":prior["parent"],"frozen_phase_checkpoint":prior["frozen_phase_checkpoint"],
        "checkpoint":reference(endpoint),"seconds":seconds,"updates_per_head":step,"photos":count,
        "visits_per_head":count*EPOCHS,"queries_per_head":count*EPOCHS*3,"epochs":EPOCHS,
        "seed":SEED,"EMA":.99,"optimizer":prior["optimizer"],"experts":EXPERTS,
        "directional_weight":weight,"arms":{"directional-replay":"Bit-exact previous directional router",
        "competing":"Same objective with five per-frequency features from the competing-wave fit"},
        "control_reproduced_bit_for_bit":True,"progress":progress})


if __name__=="__main__":
    {"prepare":prepare,"train":train}[sys.argv[1]]()
