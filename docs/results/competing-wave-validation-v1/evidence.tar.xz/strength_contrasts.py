"""Compute matched correction strength and causal evidence contrasts on stored rows."""
from pathlib import Path
from competing import ROOT
from review_quiet import numeric
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
import evaluate_gap_head as review

def main():
    all_pairs=[]
    for base in ("conditional","directional","local_power","edge_contrast"):
        all_pairs.append(("competing",f"{base}-scaled-to-competing"))
    all_pairs.extend(("competing",name)for name in ("local20k","100k","V120","directional","competing-neutral","competing-shifted"))
    bindings={kind:reference(ROOT/f"{kind}-holdout.json")for kind in ("wire","photo")}
    data={kind:read_json(checked(binding))for kind,binding in bindings.items()}
    membership=review.panel_membership()
    profiles={iso:[row for row in data['wire']['rows']if row["profile"]==iso]for iso in ("iso400","iso6400")}
    kinds={iso+"/"+draw:[row for row in data['photo']['rows'] if row["source_id"]not in membership
                        and (row["profile"],row["draw"])==(iso,draw)]
           for iso in ("iso400","iso6400")for draw in ("coupled","independent")}
    assert [len(v) for v in profiles.values()]==[24,24] and all(len(v)==48 for v in kinds.values())
    reports={
        "wire":numeric(profiles,all_pairs,("intact_response","gap_added","gap_exact","gap_weak_band_error",
                                          "intact_weak_band_error","gap_strong_band_error","flat_added","dip_response")),
        "photo":numeric(kinds,all_pairs,("intact_response","increment_rms","flat_rms","flat_added","srgb_present_psnr")),
    }
    write_json(ROOT/"strength-contrasts.json",{"driver":reference(__file__),"source":bindings,"reports":reports})

if __name__=="__main__":
    main()
