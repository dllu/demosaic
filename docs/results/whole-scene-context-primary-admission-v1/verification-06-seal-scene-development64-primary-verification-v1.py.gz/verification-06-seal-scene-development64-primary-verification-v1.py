"""Retain successful verification and its original metadata-key failure verbatim."""
import gzip
import re
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
receipt = repo / '.cache/scene-development64-primary-independent-v2.json'
assert read_json(receipt)['all_passed']
paths = [repo / '.cache' / p for p in [
    'verify-scene-development64-and-primary-v1.py', 'verify-scene-development64-and-primary-v1.log',
    'verify-scene-development64-and-primary-v2.py', 'verify-scene-development64-and-primary-v2.log',
    'scene-development64-primary-independent-v2.json', 'publish-scene-development64-and-primary-v1.log',
    'seal-scene-development64-primary-verification-v1.py']]
documents = ['docs/whole-scene-context-development64.md', 'docs/whole-scene-context-primary-admission.md',
             'docs/whole-scene-context-native-review.md', 'docs/whole-scene-context-next-test.md',
             'docs/current-model.md', 'docs/experiments.md', 'docs/research.md', 'docs/architecture.md',
             'docs/full-corpus-scaling.md', 'docs/index.md', 'docs/gfx-qualitative.md', 'docs/gfx-green-mesh.md',
             'diary/index.md', 'diary/2026-11-17-04-17-00-scene-development64-primary-admission.md']
links = 0
for document in documents:
    path = repo / document
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        assert (path.parent / target.split('#')[0].strip('<>')).exists(), (document, target)
        links += 1
for name in ['whole-scene-context-development64-v1', 'whole-scene-context-primary-admission-v1']:
    directory = repo / 'docs/results' / name
    archives = []
    for i, path in enumerate(paths):
        target = directory / f'verification-{i:02d}-{path.name}.gz'
        with target.open('xb') as stream:
            stream.write(gzip.compress(path.read_bytes(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == path.read_bytes()
        archives.append({'original': reference(path), 'published': reference(target)})
    assert read_json(directory / 'independent-review.json') == read_json(receipt)
    write_json(directory / 'verification-addendum.json', {
        'original_publication': reference(directory / 'publication.json'),
        'independent_review': reference(directory / 'independent-review.json'),
        'verification_sources_and_original_failure': archives, 'final_current_doc_links_checked': links,
        'README_lines': len((repo / 'README.md').read_text().splitlines()),
        'scope': 'Post-publication independent audit closure. Original verifier v1 used the wrong triplet metadata rectangle key and stopped; v2 uses the actual png_xywh field and passes. Original scripts/logs/receipts remain verbatim. No neural, GPU, RAW, optimizer or noise work. Both core publication manifests remain unchanged; primary quality panels still running.',
    })
print('Sealed independent sources/failure/success; current links', links)
