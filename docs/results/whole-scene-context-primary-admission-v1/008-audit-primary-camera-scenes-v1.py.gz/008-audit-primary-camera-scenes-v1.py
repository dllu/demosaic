"""Bind complete public noisy captures to every fixed known/unseen native crop."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
from demosaic.prediction_archive import fingerprint

os.sched_setaffinity(0,[4,5]);torch.set_num_threads(2)
repo=Path.cwd();old_path=repo/'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-quality-v1/evaluation-plan-v1.json';old=read_json(old_path)
root=repo/'.cache/experiments/scene-primary-camera-lineage-v1';root.mkdir();records=[]
for stage in ['known','unseen']:
    manifest=checked(old['stages'][stage]['manifest']);data=read_json(manifest)
    for case_index,case in enumerate(data['cases']):
        source=checked({'path':case['noisy']['path'],'sha256':case['noisy']['sha256']})
        assert source.is_relative_to(Path('/mnt/external'))
        raw,meta=read_raw(source)
        assert meta.pattern==case['metadata']['pattern']
        torch.testing.assert_close(torch.tensor(meta.white_balance),torch.tensor(case['metadata']['white_balance']),atol=0,rtol=0)
        torch.testing.assert_close(torch.tensor(meta.camera_to_srgb),torch.tensor(case['metadata']['camera_to_srgb']),atol=0,rtol=0)
        for crop in case['crops']:
            x,y,w,h=crop['xywh'];assert x%2==y%2==0
            with np.load(checked({'path':str(manifest.parent/crop['path']),'sha256':crop['sha256']}),allow_pickle=False)as arrays:
                np.testing.assert_array_equal(raw[y:y+h,x:x+w],arrays['raw'])
        records.append({'stage':stage,'case_index':case_index,'source':reference(source),'native_hw':list(raw.shape),
                        'pattern':meta.pattern,'metadata':case['metadata'],'all_native_crops_exact':len(case['crops']),
                        'full_noisy_RAW':fingerprint(raw),'reference_used_as_context':False})
        print(stage,case_index,len(case['crops']),'exact',flush=True)
        del raw
write_json(root/'result.json',{'script':reference(__file__),'primary_plan':reference(old_path),'all_passed':True,'records':records,
           'RAW_decodes':len(records),'total_crops':sum(r['all_native_crops_exact']for r in records),
           'scope':'All18 cached public noisy RAWs read from SSD only; all162 known/unseen crop RAW samples,WB,matrix,CFA/native coordinates match exactly. Independent lowISO/reference images never enter context.0 neural/GPU/optimizer/noise draws; no primary score.'})
