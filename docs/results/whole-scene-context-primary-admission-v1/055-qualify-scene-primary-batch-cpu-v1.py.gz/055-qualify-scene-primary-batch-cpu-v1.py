"""Actual learned heterogeneous B4 scene conditioning versus separate B2 scenes."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.prediction_archive import fingerprint
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint

os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2)
root=Path('.cache/experiments/scene-primary-batch-qualification-v1').resolve();root.mkdir()
native=Path('.cache/experiments/scene-context-native-review-v2').resolve();plan=read_json(native/'plan.json')
samples=[]
for index in [0,1]:
    record=next(r for r in plan['observations']if r['id']==f'development-{index}-shadows')
    with np.load(checked(record['arrays']),allow_pickle=False)as a:samples.append(({k:torch.from_numpy(a[k].copy())for k in a.files},record))
args={k:torch.cat([a['crop_'+k][:2]for a,_ in samples])for k in ['packed','variance','colors','wb','matrix']}
boxes=[b for _,r in samples for b in r['boxes_xywh'][:2]]
results=[]
with torch.inference_mode(),ieee_fp32():
    for mode in ['pooled','spatial']:
        endpoint=read_json(native/mode/'collection.json')['checkpoint']
        model,_=load_scene_checkpoint(checked(endpoint),weights='ema',expected_sha256=endpoint['sha256'])
        model.base.set_noise(samples[0][1]['noise']['shot'],samples[0][1]['noise']['read'])
        scenes=[model.encode_scene(a['scene_packed'],a['crop_colors'][0],a['crop_wb'][0],a['crop_matrix'][0])for a,_ in samples]
        counts={'root':0,'encoder':0}
        hooks=[model.register_forward_pre_hook(lambda *_,c=counts:c.__setitem__('root',c['root']+1)),model.base.context.backbone.register_forward_pre_hook(lambda *_,c=counts:c.__setitem__('encoder',c['encoder']+1))]
        actual=model(*(args[k]for k in ['packed','variance','colors','wb','matrix']),scene=[scenes[0],scenes[0],scenes[1],scenes[1]],boxes_xywh=boxes)
        expected=torch.cat([model(*(args[k][2*i:2*i+2]for k in ['packed','variance','colors','wb','matrix']),scene=scenes[i],boxes_xywh=boxes[2*i:2*i+2])for i in range(2)])
        delta=(actual-expected)*65535;maximum=float(delta.abs().max());rms=float(delta.square().mean().sqrt())
        assert counts=={'root':3,'encoder':3}
        assert maximum<=.25 and rms<=.025
        for hook in hooks:hook.remove()
        results.append({'mode':mode,'checkpoint':endpoint,'weights':'EMA','counts_after_scene_encoding':counts,'new_scene_encoder_calls':2,
                        'maximum_DN16_difference':maximum,'RMS_DN16_difference':rms,'B4':fingerprint(actual),'separate_B2':fingerprint(expected)})
        del model,actual,expected,scenes
write_json(root/'result.json',{'script':reference(__file__),'source':reference(Path('src/demosaic/scene_restoration.py')),'native_plan':reference(native/'plan.json'),
           'results':results,'all_passed':True,'scope':'Actual EMA pooled/spatial models on2 distinct full development fields,4 native256 crops. Heterogeneous B4 retains original local batch; compares separate B2 single-field outputs under quarter-DN max/0.025DN RMS bounds.6 root+10 total encoder calls,CPU IEEE FP32,0 GPU/noise/optimizer. Numerical composition check, not a quality metric.'})
print('actual_B4_scene_checks',results)
