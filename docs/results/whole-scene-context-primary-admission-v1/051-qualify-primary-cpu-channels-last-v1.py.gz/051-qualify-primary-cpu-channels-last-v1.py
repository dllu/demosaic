"""Check the original GPU memory layout on the failed CPU highlight probe."""
import os
import time
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.models import load_model
from demosaic.precision import ieee_fp32

os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2)
root=Path('.cache/experiments/scene-primary-cpu-compatibility-v1').resolve();previous=read_json(root/'result.json')
probe=next(r for r in previous['records']if r['stage']=='photo'and r['batch']==20)
with np.load(checked(probe['canonical_arrays']),allow_pickle=False)as data:batch={k:torch.from_numpy(data[k].copy())for k in data.files}
for key in ['packed','variance']:batch[key]=batch[key].contiguous(memory_format=torch.channels_last)
model,_=load_model('v120',checkpoint=checked(previous['checkpoint']),device='cpu');model.eval().to(memory_format=torch.channels_last);model.set_noise(.00008,2.56e-8)
with torch.inference_mode(),ieee_fp32():
    began=time.monotonic();prediction=model(*(batch[k]for k in ['packed','variance','colors','wb','matrix']));seconds=time.monotonic()-began
expected=torch.from_numpy(np.load(checked(probe['historic_GPU_prediction']),allow_pickle=False));delta=(prediction-expected)*65535
maximum=float(delta.abs().max());rms=float(delta.square().mean().sqrt())
path=root/'photo-00020-CPU-channels-last.npy'
with path.open('xb')as out:np.save(out,prediction.numpy(),allow_pickle=False)
write_json(root/'channels-last-highlight-check.json',{'script':reference(__file__),'original_failed_probe':probe,'prediction':reference(path),
           'maximum_DN16':maximum,'RMS_DN16':rms,'within_original_bounds':maximum<=.25 and rms<=.025,'seconds':seconds,
           'scope':'One new actual CPU FP32 channels-last forward/encoder, matching original GPU layout, on the failed highlight probe. Original contiguous outputs/failure unchanged.0 GPU/noise/optimizer; layout/numerical diagnosis, not a quality selection.'})
print(maximum,rms,seconds)
