"""Compare actual CPU V120 outputs with retained canonical GPU V120 predictions."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.models import load_model
from demosaic.precision import ieee_fp32

os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2)
repo=Path.cwd();root=repo/'.cache/experiments/scene-primary-cpu-compatibility-v1';root.mkdir()
canonical_path=repo/'.cache/experiments/scene-primary-canonical-inputs-v1/full/result.json';canonical=read_json(canonical_path)
assert canonical['all_input_witnesses_exact'] and canonical['module_forwards']==0
old=repo/'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-quality-v1/work/artifacts'
checkpoint=read_json(repo/'.cache/experiments/whole-scene-context-ablation-v2/plan.json')['parent']
model,state=load_model('v120',checkpoint=checked(checkpoint),device='cpu');model.eval().to(memory_format=torch.contiguous_format)
assert len(model.restoration_state_dict())==91 and all(torch.equal(v,state['ema'][k])for k,v in model.restoration_state_dict().items())
records=[]
with torch.inference_mode(),ieee_fp32():
    for stage,indices in [('photo',[0,12,16,20]),('known',[0,23]),('unseen',[0,29])]:
        old_result=read_json(old/stage/'result.json');archive=[__import__('json').loads(line)for line in checked(old_result['archive']).read_text().splitlines()]
        previous=[r for r in archive if r['model']['sha256']==checkpoint['sha256']and r['model']['self_ensemble']=='none']
        for index in indices:
            item=next(r for r in canonical['records']if r['stage']==stage and r['batch']==index)
            with np.load(checked(item['arrays']),allow_pickle=False)as data:batch={k:torch.from_numpy(data[k].copy())for k in data.files}
            historic=previous[index]
            for key in ['packed','variance','colors','wb','matrix']:assert item['fingerprints'][key]==historic['context']['input_fingerprints'][key]
            noise=item['context']['condition']if stage=='photo'else item['context']['noise'];model.set_noise(noise['shot'],noise['read'])
            predicted=model(*(batch[k]for k in ['packed','variance','colors','wb','matrix']))
            expected=torch.from_numpy(np.load(checked(historic['prediction']),allow_pickle=False))
            delta=(predicted-expected)*65535;maximum=float(delta.abs().max());rms=float(delta.square().mean().sqrt())
            path=root/f'{stage}-{index:05d}-CPU-f32.npy'
            with path.open('xb')as stream:np.save(stream,predicted.numpy(),allow_pickle=False)
            record={'stage':stage,'batch':index,'canonical_arrays':item['arrays'],'CPU_prediction':reference(path),'historic_GPU_prediction':historic['prediction'],
                    'maximum_DN16':maximum,'RMS_DN16':rms,'within_bounds':maximum<=.25 and rms<=.025}
            records.append(record);write_json(root/f'{stage}-{index:05d}.json',record);print(stage,index,maximum,rms,flush=True)
all_passed=all(r['within_bounds']for r in records)
write_json(root/'result.json',{'script':reference(__file__),'canonical_inputs':reference(canonical_path),'checkpoint':checkpoint,
           'records':records,'all_passed':all_passed,'maximum_DN16_bound':.25,'RMS_DN16_bound':.025,
           'scope':'8 actual CPU IEEE FP32 contiguous V120 forwards, same canonical five arguments as original GPU primary; ADC,positive-noise,shadows,highlights and B4/B1 camera cases.0 new GPU/noise/optimizer. Compatibility bounds are numerical, not a quality gate; report actual errors and preserve failed probes. CPU primary collection admitted only if all pass.'})
