"""Publish closed study evidence and an explicitly incomplete primary admission."""
import gzip
import hashlib
import io
import shutil
import tarfile
from datetime import datetime, timezone
from pathlib import Path

from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
study = repo / '.cache/experiments/scene-development64-context-review-v1'
primary = repo / '.cache/experiments/scene-primary-cpu-v1'
export = repo / '.cache/experiments/scene-primary-canonical-inputs-v1'


def publish(name, paths, snapshots, assets, scope):
    destination = repo / 'docs/results' / name
    destination.mkdir()
    archives = []
    for index, path in enumerate(sorted(set(paths))):
        data = path.read_bytes()
        target = destination / f'{index:03d}-{path.name}.gz'
        target.write_bytes(gzip.compress(data, mtime=0))
        assert gzip.decompress(target.read_bytes()) == data
        archives.append({'original': reference(path), 'published': reference(target), 'decompressed_bytes_exact': True})
    packages = []
    for label, plan_path in snapshots:
        plan = read_json(plan_path)
        target = destination / f'{label}-sources.tar.gz'
        members = []
        with tarfile.open(target, 'w:gz') as tar:
            for path, digest in sorted(plan['frozen_files'].items()):
                source = checked({'path': path, 'sha256': digest})
                data = source.read_bytes()
                member = str(source.relative_to(plan['work']))
                info = tarfile.TarInfo(member)
                info.size, info.mode = len(data), 0o644
                tar.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original': reference(source)})
        packages.append({'plan': reference(plan_path), 'published': reference(target), 'members': members})
    write_json(destination / 'publication.json', {
        'publisher': reference(__file__), 'recorded_UTC': datetime.now(timezone.utc).isoformat(),
        'archives': archives, 'source_snapshots': packages, 'native_assets': assets, 'scope': scope,
        'not_embedded': 'Large checkpoint/DINO/Adam binaries, canonical tensor/RAW/features/predictions and image caches stay bound in local storage. No claim every transitive historical source is packed. Existing historical publications remain authoritative and unchanged.',
    })
    print(name, 'archives', len(archives), 'source members', sum(len(s['members']) for s in packages), 'native assets', len(assets))


images = repo / 'docs/images/whole-scene-context-development64-v1'
images.mkdir()
assets = []
for source in (study / 'native-review-v1').rglob('*'):
    if source.is_file() and source.suffix in {'.png', '.json'}:
        target = images / source.relative_to(study / 'native-review-v1')
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(source, target)
        assert source.read_bytes() == target.read_bytes()
        assets.append({'original': reference(source), 'published': reference(target)})
paths = [study / p for p in ['plan.json', 'launch.json', 'result.json', 'pooled-shuffle-invariance.json',
         'analysis-v1/result.json', 'analysis-v1/per-crop.csv', 'analysis-v1/quiet-detail-supplement-v2.json',
         'analysis-v1/source-robustness.json', 'native-review-v1/result.json', 'native-review-v1/native-viewing.json']]
paths += [checked(binding) for binding in read_json(study / 'result.json')['cases']]
paths += [repo / '.cache' / p for p in ['run-scene-development64-v1.py', 'analyze-scene-development64-v1.py',
         'analyze-scene-development64-v1.log', 'analyze-scene-quiet-detail-v1.py', 'analyze-scene-quiet-detail-v1.log',
         'analyze-scene-quiet-detail-v2.py', 'analyze-scene-quiet-detail-v2.log', 'render-scene-development64-v1.py',
         'render-scene-development64-v1.log', 'close-scene-development64-v1.py', 'close-scene-development64-v1.log',
         'publish-scene-development64-and-primary-v1.py']]
publish('whole-scene-context-development64-v1', paths, [('development64', study / 'plan.json')], assets,
        'Complete64-source,128-case,512-crop/variant context-development study;6 variants/3072 rows. All8 final native boards actually viewed,8 exact-GT triplets. Source-balanced diagnostics/bootstrap, quiet fine-error and source-tail sensitivity included. All3 EMA endpoints trained2k; original training/GFX receipts in prior native publication. Not full427/camera scores or a parent-lifetime/scaling-independent holdout. Original failed analytic boundary fixture preserved with its corrected v2 successor.')

# Freeze the live progress as a timestamped observation, without sealing a mutable
# log or confusing the observation with a terminal evaluation result.
snapshot = primary / 'publication-progress-observation-v1.json'
data = (primary / 'full/progress.json').read_bytes()
value = __import__('json').loads(data)
write_json(snapshot, {'observed_UTC': datetime.now(timezone.utc).isoformat(), 'progress': value,
                     'read_progress_bytes_sha256': hashlib.sha256(data).hexdigest(),
                     'scope': 'One live progress observation; full evaluation remains incomplete. The worker progress file may advance.'})
paths = [primary / p for p in ['preflight-plan.json', 'preflight-launch.json', 'preflight/result.json',
         'preflight.log', 'full-plan.json', 'full-launch.json', 'CPU-control-adoption-addendum.json',
         'publication-progress-observation-v1.json']]
paths += [checked(p) for p in read_json(primary / 'preflight/result.json')['case_records']]
paths += [export / p for p in ['preflight-plan.json', 'preflight-launch.json', 'preflight/result.json',
          'preflight.log', 'full-plan.json', 'full-launch.json', 'full/result.json', 'full.log']]
for name in ['scene-primary-batch-qualification-v1', 'scene-primary-frozen-replay-v1',
             'scene-primary-thread-qualification-v1', 'scene-primary-camera-lineage-v1', 'scene-primary-cpu-compatibility-v1']:
    directory = repo / '.cache/experiments' / name
    paths += list(directory.glob('*.json'))
prefixes = ['qualify-scene-primary-batch-', 'qualify-primary-frozen-', 'qualify-parent-CPU-',
            'qualify-primary-cpu-', 'analyze-primary-cpu-', 'audit-primary-camera-', 'prepare-scene-primary-',
            'scene-primary-batch-', 'scene-primary-replay-', 'frozen-encoder-replay-',
            'scene-primary-cpu-compatibility-', 'primary-camera-scene-lineage-']
paths += [p for p in (repo / '.cache').iterdir() if p.is_file() and p.suffix in {'.py', '.log', '.json'}
          and any(p.name.startswith(prefix) for prefix in prefixes)]
paths += [repo / p for p in ['src/demosaic/scene_restoration.py', 'src/demosaic/frozen_encoder_replay.py',
          'scripts/collect_scene_primary.py', 'scripts/export_canonical_primary_inputs.py',
          'tests/test_scene_restoration.py', 'tests/test_frozen_encoder_replay.py',
          '.cache/publish-scene-development64-and-primary-v1.py']]
publish('whole-scene-context-primary-admission-v1', paths,
        [('primary', primary / 'full-plan.json'), ('canonical-export', export / 'full-plan.json')], [],
        'All3162 canonical historical five-argument input batches exact;0 learned exporter forwards. All18 public noisy RAWs/162 native crops exact. Heterogeneous native B4 and checked frozen-feature sharing qualified on actual models;50+5 focused tests. Original cross-device quarter-DN test remains failed, channels-last does not fix it. Matched CPU V120 evaluated alongside candidates;8 existing CPU parents admitted after byte-exact four-thread verification. Three-case learned preflight complete; full427/known/unseen collection running on CPU with36h runtime guard. This is admission/evidence, not a completed quality panel. Original oneDNN SSIM and JSON fixture failures preserved. Physical-only bounded CUDA export ran concurrently with unchanged training; no claim exclusive training timing or bit-identical resulting weights.')
