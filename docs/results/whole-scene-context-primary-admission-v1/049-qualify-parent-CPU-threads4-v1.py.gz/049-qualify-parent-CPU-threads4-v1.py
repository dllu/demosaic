"""Check the eight adopted CPU control predictions under the primary thread count."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.models import load_model
from demosaic.precision import ieee_fp32

os.sched_setaffinity(0,[6,7,10,11]);torch.set_num_threads(4)
repo=Path.cwd();root=repo/'.cache/experiments/scene-primary-thread-qualification-v1';root.mkdir()
old=read_json(repo/'.cache/experiments/scene-primary-cpu-compatibility-v1/result.json')
canonical=read_json(repo/'.cache/experiments/scene-primary-canonical-inputs-v1/full/result.json')
model,_=load_model('v120',checkpoint=checked(old['checkpoint']),device='cpu');model.eval().to(memory_format=torch.contiguous_format)
rows=[]
with torch.inference_mode(),ieee_fp32():
    for item in old['records']:
        case=next(c for c in canonical['records']if (c['stage'],c['batch'])==(item['stage'],item['batch']))
        with np.load(checked(case['arrays']),allow_pickle=False)as values:batch={k:torch.from_numpy(values[k].copy())for k in values.files}
        noise=case['context']['condition']if case['stage']=='photo'else case['context']['noise'];model.set_noise(noise['shot'],noise['read'])
        actual=model(*(batch[k]for k in ['packed','variance','colors','wb','matrix']))
        previous=torch.from_numpy(np.load(checked(item['CPU_prediction']),allow_pickle=False));delta=(actual-previous)*65535
        path=root/f"{case['stage']}-{case['batch']:05d}-four-thread.npy"
        with path.open('xb')as out:np.save(out,actual.numpy(),allow_pickle=False)
        row={'stage':case['stage'],'batch':case['batch'],'two_thread_prediction':item['CPU_prediction'],'four_thread_prediction':reference(path),
             'bit_exact':bool(torch.equal(actual,previous)),'maximum_DN16':float(delta.abs().max()),'RMS_DN16':float(delta.square().mean().sqrt())}
        rows.append(row);print(case['stage'],case['batch'],row['bit_exact'],row['maximum_DN16'],flush=True)
write_json(root/'result.json',{'script':reference(__file__),'parent':old['checkpoint'],'records':rows,'all_bit_exact':all(r['bit_exact']for r in rows),
           'scope':'8 actual CPU parent forwards,primary4 threads vs prior2-thread CPU outputs,identical canonical inputs.0 GPU/noise/optimizer. Does not waive failed cross-device quarter-DN bounds. Each new output preserved; adoption policy follows measured thread equivalence.'})
