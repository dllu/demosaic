"""Actual four-checkpoint B4 equivalence for guarded frozen DINO replay."""
import os
from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.frozen_encoder_replay import FrozenDinoReplay
from demosaic.models import load_model
from demosaic.precision import ieee_fp32
from demosaic.scene_inference import load_scene_checkpoint
from demosaic.scene_restoration import WholeSceneRestorer

os.sched_setaffinity(0,[2,3]);torch.set_num_threads(2)
repo=Path.cwd();root=repo/'.cache/experiments/scene-primary-frozen-replay-v1';root.mkdir()
native=read_json(repo/'.cache/experiments/scene-context-native-review-v2/plan.json')
training=read_json(checked(native['training_plan']))
canonical=read_json(repo/'.cache/experiments/scene-primary-canonical-inputs-v1/full/result.json')
record=next(r for r in canonical['records']if r['stage']=='photo'and r['batch']==16)
with np.load(checked(record['arrays']),allow_pickle=False)as data:batch={k:torch.from_numpy(data[k].copy())for k in data.files}
models={};base,_=load_model('v120',checkpoint=checked(native['parent']),device='cpu');models['V120']=WholeSceneRestorer(base,mode='none',adapter_width=training['adapter_width'])
for arm in ['none','pooled','spatial']:
    endpoint=read_json(repo/'.cache/experiments/scene-context-native-review-v2'/arm/'collection.json')['checkpoint']
    models[arm],_=load_scene_checkpoint(checked(endpoint),weights='ema',expected_sha256=endpoint['sha256'])
for model in models.values():model.eval().to(memory_format=torch.contiguous_format);model.base.set_noise(.00064,1.6384e-6)
replay=FrozenDinoReplay([m.base.context.backbone for m in models.values()])
predictions={}
with torch.inference_mode(),ieee_fp32():
    for mode in ['independent','replayed']:
        def calls():
            for arm,model in models.items():
                # This checks the shared local frozen path; heterogeneous scene
                # composition has its separate actual2-scene B4 qualification.
                scene=None
                if arm in ['pooled','spatial']:
                    h,w=batch['packed'].shape[-2:]
                    # One explicit per-sample noisy observation suffices here;
                    # no target enters context, and all4 inputs remain identical.
                    scene=[model.encode_scene(batch['packed'][i],batch['colors'][i],batch['wb'][i],batch['matrix'][i])for i in range(4)]
                result=model(*(batch[k]for k in ['packed','variance','colors','wb','matrix']),scene=scene,boxes_xywh=[[0,0,256,256]]*4)
                path=root/(mode+'-'+arm+'.npy')
                with path.open('xb')as stream:np.save(stream,result.numpy(),allow_pickle=False)
                predictions[mode,arm]=reference(path)
        if mode=='independent':calls()
        else:
            # Encode before replay to keep the call group strictly the common
            # local B4 pixel input, not the different B1 whole-scene inputs.
            # The function below supplies already computed scene features.
            scenes={arm:[m.encode_scene(batch['packed'][i],batch['colors'][i],batch['wb'][i],batch['matrix'][i])for i in range(4)]for arm,m in models.items()if arm in ['pooled','spatial']}
            with replay.group()as counts:
                for arm,model in models.items():
                    result=model(*(batch[k]for k in ['packed','variance','colors','wb','matrix']),scene=scenes.get(arm),boxes_xywh=[[0,0,256,256]]*4)
                    path=root/('replayed-'+arm+'.npy')
                    with path.open('xb')as stream:np.save(stream,result.numpy(),allow_pickle=False)
                    predictions[mode,arm]=reference(path)
results=[]
for arm in models:
    a=np.load(checked(predictions['independent',arm]),allow_pickle=False);b=np.load(checked(predictions['replayed',arm]),allow_pickle=False)
    assert np.array_equal(a,b)
    results.append({'arm':arm,'independent':predictions['independent',arm],'replayed':predictions['replayed',arm],'bit_exact':True})
assert counts=={'requests':4,'executions':1,'replays':3}
write_json(root/'result.json',{'script':reference(__file__),'cache_source':reference(repo/'src/demosaic/frozen_encoder_replay.py'),'canonical_arrays':record['arrays'],'results':results,
           'replayed_group':counts,'all_passed':True,'scope':'All4 actual checkpoints,8 root forwards. Independent/replayed native B4 local paths are byte-identical. Scene controls here encode the noisy canonical crop itself, only to exercise the code path; no whole-image quality claim. Each conditioned model builds4 B1 scene features in both passes (16 extra scene encoder calls); localDINO4 independent+1 executed replay=5, total21 actual encoder computations,24 forward requests.0 new GPU/noise/optimizer work.'})
print('all4 predictions bit-exact;3 of4 localDINO executions eliminated')
