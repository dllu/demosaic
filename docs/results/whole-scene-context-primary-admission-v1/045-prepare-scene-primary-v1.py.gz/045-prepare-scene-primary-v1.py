"""Admit a matching CPU baseline and candidate primary evaluation, preserving inputs."""
import ast
import os
import subprocess
import sys
from pathlib import Path

import psutil

from demosaic.experiments.artifacts import checked,freeze_sources,read_json,reference,write_json

repo=Path.cwd();root=repo/'.cache/experiments/scene-primary-cpu-v1';root.mkdir()
canonical=repo/'.cache/experiments/scene-primary-canonical-inputs-v1/full/result.json'
assert read_json(canonical)['all_input_witnesses_exact'] and len(read_json(canonical)['records'])==3162
assert read_json(repo/'.cache/experiments/scene-primary-camera-lineage-v1/result.json')['all_passed']
batch=read_json(repo/'.cache/experiments/scene-primary-batch-qualification-v1/result.json');assert batch['all_passed']
checked(batch['source'])
replay=read_json(repo/'.cache/experiments/scene-primary-frozen-replay-v1/result.json');assert replay['all_passed'];checked(replay['cache_source'])
native_root=repo/'.cache/experiments/scene-context-native-review-v2';native=read_json(native_root/'plan.json')
training=read_json(checked(native['training_plan']))
old_path=repo/'.cache/current-quality-20261023-v1/V120-V121-paired32-weak-detail-quality-v1/evaluation-plan-v1.json';old=read_json(old_path)
for name in ['color.py','metrics.py']:
    assert reference(repo/'src/demosaic'/name)['sha256']==reference(Path(old['work'])/'src/demosaic'/name)['sha256']
for name,function in [('suite.py','summarize'),('real_suite.py','measured_sensor_psnr')]:
    def declaration(path):return next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)and n.name==function)
    assert ast.dump(declaration(repo/'src/demosaic'/name),include_attributes=False)==ast.dump(declaration(Path(old['work'])/'src/demosaic'/name),include_attributes=False)
work,files=freeze_sources(repo,root,entries=('collect_scene_primary.py',))
models={'V120':{'kind':'parent','checkpoint':native['parent'],'step':20000}}
for arm in ['none','pooled','spatial']:
    endpoint=read_json(native_root/arm/'collection.json')['checkpoint'];models[arm]={'kind':'scene','checkpoint':endpoint,'step':2000}
inputs=[reference(canonical),reference(old_path),reference(native_root/'plan.json'),native['parent'],
        reference(repo/'.cache/canonical-fullscene-lineage-v1.json'),reference(repo/'.cache/experiments/scene-primary-camera-lineage-v1/result.json'),
        reference(repo/'.cache/experiments/scene-primary-cpu-compatibility-v1/result.json'),
        reference(repo/'.cache/experiments/scene-primary-cpu-compatibility-v1/scoring-domain-analysis-v4.json'),
        reference(repo/'.cache/experiments/scene-primary-frozen-replay-v1/result.json'),reference(repo/'.cache/experiments/scene-primary-batch-qualification-v1/result.json')]
inputs.extend(v['checkpoint']for v in models.values())
plan={'root':str(root),'work':str(work),'frozen_files':files,'driver':reference(work/'scripts/collect_scene_primary.py'),'inputs':inputs,
      'canonical_inputs':reference(canonical),'photo_inventory':reference(repo/'.cache/canonical-fullscene-lineage-v1.json'),
      'stages':{s:old['stages'][s]for s in ['photo','known','unseen']},'models':models,'DINO_sha256':training['DINO_sha256'],
      'parent_CPU_probes':reference(repo/'.cache/experiments/scene-primary-cpu-compatibility-v1/result.json'),
      'CPU_affinity':[0,1,4,5],'CPU_threads':4,'maximum_seconds':129600,'preview_long_side':1024,'preview_exposure':1.,
      'legacy_GPU_control_reuse_admitted':False,
      'control_policy':'Evaluate parent and every candidate on the same CPU IEEE FP32 contiguous path. The initial cross-device quarter-DN bound failed only on one unclipped highlight value1.836 (0.343745DN16); original failed receipt retained. Observed scoring-domain deviations are <=0.00000763dB in8 probes, but no bound is relaxed to reuse GPU controls. Adopt8 existing CPU parent predictions with exact canonical inputs. Recompute remaining parent predictions alongside candidates.',
      'encoder_policy':'One common full noisy scene encoding, shared by pooled/spatial after identical frozen state and mean/std checks. Local frozen encoder calls are reused only after actual input fingerprints match; consumers checked read-only. Actual4-model B4 cache qualification is byte-exact. Keep original local B4 execution and all learned projections/trunks.',
      'metric_policy':'Original color/metric source bytes and aggregation formulas verified unchanged. CPU Gaussian SSIM reference convolution disables oneDNN only while computing metrics, due reproducible grouped-convolution JIT label-too-far failures. Neural model oneDNN policy unchanged. Undefined metrics serialize null.',
      'scope':'Full fixed427 photos+16 synthetic,7 conditions/4 CFAs; known4scenes72crops and unseen5scenes90crops. Preflight3 actual batches (photo16,known0,unseen0), not a primary score. Full only after preflight, adopts all preflight predictions/contexts without replay. All cases fixed before outcomes;0 new GPU/optimizer calls, no quality-based stopping or checkpoint/horizon reset. Retain complete actual noisy whole fields/features and native predictions. Actual native viewing/report/PSNR registry update require completed comparable panels.'}
path=root/'preflight-plan.json';write_json(path,plan)
env=dict(os.environ,PYTHONPATH=str(work/'src')+':'+str(work/'scripts'),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONUNBUFFERED='1')
with (root/'preflight.log').open('x')as log:child=subprocess.Popen([sys.executable,plan['driver']['path'],str(path),'preflight'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write_json(root/'preflight-launch.json',{'pid':child.pid,'create_time':psutil.Process(child.pid).create_time(),'plan':reference(path),'driver':plan['driver']})
print('primary_preflight_pid',child.pid)
