"""Measure scoring-domain effects of existing CPU/GPU differences, no replay."""
from pathlib import Path

import numpy as np
import torch

from demosaic.color import render
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.metrics import quality_metrics
from demosaic.precision import ieee_fp32
from demosaic.real_suite import measured_sensor_psnr

torch.set_num_threads(2)
root=Path('.cache/experiments/scene-primary-cpu-compatibility-v1').resolve();result=read_json(root/'result.json');records=[]
with torch.inference_mode(), ieee_fp32(), torch.backends.mkldnn.flags(enabled=False):
    for record in result['records']:
        a=torch.from_numpy(np.load(checked(record['CPU_prediction']),allow_pickle=False))
        b=torch.from_numpy(np.load(checked(record['historic_GPU_prediction']),allow_pickle=False))
        with np.load(checked(record['canonical_arrays']),allow_pickle=False)as values:batch={k:torch.from_numpy(values[k].copy())for k in values.files}
        border=8 if record['stage']=='photo'else 32
        ref=batch['target']if record['stage']=='photo'else batch['reference_rgb']
        ma=quality_metrics(a[...,border:-border,border:-border],ref[...,border:-border,border:-border],batch['wb'],batch['matrix'])
        mb=quality_metrics(b[...,border:-border,border:-border],ref[...,border:-border,border:-border],batch['wb'],batch['matrix'])
        delta=(a-b).abs();location=np.unravel_index(int(delta.flatten().argmax()),delta.shape)
        display=(render(a,batch['wb'],batch['matrix'])-render(b,batch['wb'],batch['matrix'])).abs()*65535
        maximum_srgb=float((ma['srgb_psnr']-mb['srgb_psnr']).abs().max())
        row={**record,'maximum_difference_location':list(location),'CPU_value_at_max':float(a[location]),'GPU_value_at_max':float(b[location]),
             'maximum_rendered_sRGB_DN16':float(display.max()),'maximum_per_source_sRGB_PSNR_difference_dB':maximum_srgb,
             'per_source_sRGB_PSNR_differences_dB':(ma['srgb_psnr']-mb['srgb_psnr']).tolist()}
        if record['stage']!='photo':
            scorea,_=measured_sensor_psnr(a[...,32:-32,32:-32],batch['sensor_reference'][...,32:-32,32:-32],batch['sensor_mask'][...,32:-32,32:-32])
            scoreb,_=measured_sensor_psnr(b[...,32:-32,32:-32],batch['sensor_reference'][...,32:-32,32:-32],batch['sensor_mask'][...,32:-32,32:-32])
            row['maximum_per_crop_measured_CFA_PSNR_difference_dB']=float((scorea-scoreb).abs().max())
        records.append(row)
write_json(root/'scoring-domain-analysis-v3.json',{'source_result':reference(root/'result.json'),'script':reference(__file__),'records':records,
           'scope':'Existing immutable predictions and exact targets only. Quantifies actual FP32 CPU/GPU differences in output/scoring domains; does not change or retroactively pass the original quarter-DN bound.0 new learned forward, noise,GPU or optimizer.'})
print([(r['stage'],r['batch'],r['maximum_DN16'],r['maximum_per_source_sRGB_PSNR_difference_dB'])for r in records])
