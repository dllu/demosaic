"""Test whether exact Bayer coordinate symmetry stabilizes the paired head."""
import os
from pathlib import Path
import sys
import time

import numpy as np
import psutil
import torch

from demosaic.cfa import pack, unpack
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.paired_detail import PairedLuminanceDetail
from demosaic.precision import ieee_fp32
from demosaic.prediction_archive import fingerprint
from demosaic.self_ensemble import _transform

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / "paired-luminance-detail-v1"
SCENE = ROOT.parent / "scene-local-contrast-2400-v1"
sys.path[:0] = [str(PRIOR), str(SCENE)]
from local_guard import paired_gates
from measure import parts, reduce
from evaluate import ARGS

METHODS = ("single", "D4", "single-matched", "D4-matched")


def head_views(head, parent, packed, variance, colors, wb, matrix, gate):
    raw, noise = unpack(packed), unpack(variance)
    color_tile = colors.reshape(-1, 1, 2, 2)
    correction = []
    for mirror in (False, True):
        for turns in range(4):
            changed = _transform(parent, turns, mirror)
            sensor = pack(_transform(raw, turns, mirror)).contiguous(memory_format=torch.channels_last)
            error = pack(_transform(noise, turns, mirror)).contiguous(memory_format=torch.channels_last)
            codes = _transform(color_tile, turns, mirror).reshape(-1, 4)
            fine = head.luminance_delta(changed, sensor, error, codes, wb, matrix)
            if mirror:
                fine = fine.flip(-1)
            correction.append(torch.rot90(fine, -turns, (-2, -1)))
    views = torch.stack(correction).to(torch.float64) * gate
    single = views[0]
    repeated = views.mean(0)
    norms = [v.square().mean((1, 2, 3), keepdim=True).sqrt() for v in (single, repeated)]
    matched = torch.minimum(*norms)
    single_matched = single * (matched / norms[0].clamp_min(1e-20))
    repeated_matched = repeated * (matched / norms[1].clamp_min(1e-20))
    for candidate in (single_matched, repeated_matched):
        torch.testing.assert_close(matched, candidate.square().mean((1, 2, 3), keepdim=True).sqrt(),
                                   rtol=1e-12, atol=1e-15)
    return dict(zip(METHODS, (single, repeated, single_matched, repeated_matched), strict=True)), {
        "single_RMS": norms[0].flatten().tolist(), "averaged_RMS": norms[1].flatten().tolist(),
        "orientation_disagreement_RMS": views.var(0, unbiased=False).mean((1, 2, 3)).sqrt().tolist(),
    }


def apply(parent, fields, net, thresholds):
    _, gate = paired_gates(*(fields[k] for k in ARGS[:3]), *thresholds)
    correction, trace = head_views(net, parent, *(fields[k] for k in ARGS), gate)
    wb, matrix = (fields[k] for k in ("wb", "matrix"))
    neutral = torch.linalg.solve(matrix, torch.ones_like(wb).unsqueeze(-1)).squeeze(-1) / wb
    return {k: (parent + neutral[:, :, None, None]*v.float()).cpu().numpy()
            for k, v in correction.items()}, trace


def make_review():
    cached = read_json(PRIOR / "endpoint/short-guard/results.json")
    parent_panel = read_json(SCENE / "evaluation/plan.json")
    spec = read_json(checked(parent_panel["panel"]))
    previous = read_json(PRIOR / "training/complete.json")
    cutoff = read_json(PRIOR / "local-support-calibration.json")
    guidance = read_json(checked(cutoff["existing"]))
    return cached, spec, previous, (cutoff["threshold"], guidance["threshold_0_to_1"][0])


def input_fields(values):
    fields = {key: torch.from_numpy(np.ascontiguousarray(values[key]).copy()).cuda() for key in ARGS}
    for key in ARGS[:2]:
        fields[key] = fields[key].contiguous(memory_format=torch.channels_last)
    return fields


@torch.inference_mode()
def run():
    os.sched_setaffinity(0, [16, 18])
    os.nice(14)
    torch.set_num_threads(2)
    torch.cuda.set_per_process_memory_fraction(min(1., 5 * 2**30 / torch.cuda.get_device_properties(0).total_memory))
    write_json(ROOT / "launch.json", {"pid": os.getpid(), "created": psutil.Process().create_time()})
    cached, spec, previous, thresholds = make_review()
    parent_point = previous["parent"]
    component_point = previous["head_checkpoint"]
    state = torch.load(checked(component_point), weights_only=True, map_location="cpu")
    model = PairedLuminanceDetail().cuda().to(memory_format=torch.channels_last).eval()
    model.load_state_dict(state["weights"]["paired"]["ema"])
    out = ROOT / "predictions"
    out.mkdir()
    frozen = ROOT / "plan.json"
    write_json(frozen, {
        "driver": reference(__file__), "inherited": reference(PRIOR/"endpoint/short-guard/results.json"),
        "parent": parent_point, "component": component_point, "guard": reference(PRIOR/"local-support-calibration.json"),
        "dihedral_implementation": reference(Path("src/demosaic/self_ensemble.py")),
        "scope": "Reuse each frozen parent prediction. Average only the eight oriented single-query luminance corrections after exact inverse placement and apply a single fixed RAW guard. For the matched control, attenuate both methods to the lower full-query correction RMS.",
    })
    began = time.monotonic()
    rows = []
    with ieee_fp32():
        for old in cached["rows"]:
            if old["profile"] != "iso6400":
                continue
            record = read_json(checked(old["original"]))
            case = read_json(checked(record["case"]))
            with np.load(checked(case["input"]), allow_pickle=False) as data:
                raw = {key: data[key] for key in (*ARGS, "target")}
            assert {k: fingerprint(raw[k]) for k in ARGS} == record["exact_query_inputs"]
            for key in ARGS[2:]:
                arr = raw[key]
                raw[key] = np.broadcast_to(arr[None], (3, *arr.shape))
            fields = input_fields(raw)
            with np.load(checked(record["saved"]), allow_pickle=False) as base:
                parents = {k: base[k] for k in ("100k", "V120")}
            parent = torch.from_numpy(parents["100k"]).cuda().contiguous(memory_format=torch.channels_last)
            methods, traces = apply(parent, fields, model, thresholds)
            with np.load(checked(old["guarded_output"]), allow_pickle=False) as ref:
                previous_array = ref["intersection-paired"]
                difference = (previous_array.astype(float) - methods["single"]) * 65535
                assert np.max(np.abs(difference)) < .020
            fit = {"wb": raw["wb"], "matrix": raw["matrix"], "exposure": case["profile"]["exposure"]}
            score = {label: parts(fit, x, raw["target"], spec) for label, x in (parents | methods).items()}
            term = out/(case["id"]+".npz")
            with term.open("xb") as stream:
                np.savez(stream, **methods)
            rows.append({"source": case["source"],"draw": case["draw"], "profile": "iso6400", "metrics": score,
                         "input": record["case"], "parent_receipt": old["original"],"saved": reference(term),
                         "guarded_single_replay_max_difference_DN16": float(np.max(np.abs(difference))), "trace": traces})
            if len(rows) % 8 == 0:
                print(len(rows), round(time.monotonic()-began, 2), flush=True)
        assert len(rows) == 128
        cameras = read_json(PRIOR / "endpoint/standing-results.json")
        standing = []
        for row in cameras["rows"]:
            with np.load(checked(row["raw"]["arrays"]), allow_pickle=False) as arrived:
                raw = {k: arrived[k] for k in ARGS}
            assert {k: fingerprint(v) for k,v in raw.items()} == row["inputs"]
            fields = input_fields(raw)
            parent = torch.from_numpy(np.load(checked(row["parent"]), allow_pickle=False)).cuda()
            methods, traces = apply(parent, fields, model, thresholds)
            term = out/(row["id"]+".npz")
            with term.open("xb") as stream:
                np.savez(stream, **methods)
            standing.append({"id": row["id"], "saved": reference(term), "input": row, "trace": traces})
            print(row["id"], flush=True)
    assert len(standing) == 6
    write_json(ROOT / "results.json",{
        "plan": reference(frozen), "metrics": reduce(rows), "rows": rows, "standing": standing,
        "duration_seconds": time.monotonic()-began, "actual_native_viewing": False,
    })


if __name__ == "__main__":
    run()
