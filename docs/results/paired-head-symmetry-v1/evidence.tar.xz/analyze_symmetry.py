"""Compare paired-head orientation averaging and render its native evidence."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from demosaic.archive_metrics import noisy_malvar
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.reporting import display_crop
from report_scene_wave_guides import native_board
from run_symmetry import ARGS, METHODS, PRIOR, ROOT, SCENE
from analyze_matched import compare
from render import native_png

NAMES = ("Canonical correction", "Eight orientations", "Canonical matched RMS", "Eight matched RMS")
CONTRASTS = {
    "mean_vs_single": {"D4": 1, "single": -1},
    "same_RMS": {"D4-matched": 1, "single-matched": -1},
    "mean_vs_100k": {"D4": 1, "100k": -1},
    "matched_mean_vs_100k": {"D4-matched": 1, "100k": -1},
}


def synthetic(results, native):
    fresh = [row for row in results["rows"] if row["draw"] == "independent"]
    assert len(fresh) == 64
    change = lambda row, key: (row["metrics"]["D4-matched"]["band"]["fine"][key] -
                               row["metrics"]["single-matched"]["band"]["fine"][key])
    ranked = sorted(fresh, key=lambda r:change(r, "increment_RMS_DN16"))
    quiet = max(fresh, key=lambda r:change(r, "quiet_RMS_DN16"))
    spec = read_json(SCENE / "evaluation-plan.json")
    output = []
    for row, role, chosen in (
        (ranked[0], 0, "Largest fine-increment error reduction at matched correction RMS"),
        (ranked[-1], 0, "Largest fine-increment error increase at matched correction RMS"),
        (quiet, 2, "Largest rise in flat fine-band RMS at matched correction strength"),
    ):
        case = read_json(checked(row["input"]))
        profile = spec["rows"][case["case"]]
        assert case["source"] == profile["source"]["id"] == row["source"]
        record = read_json(checked(row["parent_receipt"]))
        assert record["case"] == row["input"]
        with np.load(checked(case["input"]), allow_pickle=False) as saved:
            mosaic = {k: saved[k][role:role+1] if k in ARGS[:2] else saved[k][None] for k in ARGS}
            gt = saved["target"][role]
        with np.load(checked(record["saved"]), allow_pickle=False) as saved:
            older = [saved[k][role] for k in ("V120", "100k")]
        with np.load(checked(row["saved"]), allow_pickle=False) as saved:
            compared = [saved[k][role] for k in METHODS]
        frames = [noisy_malvar(mosaic)[0], *older, *compared, gt]
        output.append(native_board(
            native, f"{case['id']}-role{role}", frames, mosaic,
            {"selection": chosen, "source_photo": profile["source"], "bbox_native": case["box"],
             "profile": case["profile"], "CFA": profile["camera"]["pattern"], "draw": case["draw"],
             "bound_original": row["input"], "composed_inference_plan": results["plan"],
             "role": spec["roles"][role]},
            labels=("Noisy Malvar", "V120 EMA", "Parent 100k EMA", *NAMES, "Exact GT"),
            triplet_indices=(0, 3 + METHODS.index("D4-matched"), len(frames) - 1),
            exposure=1/case["profile"]["exposure"], contrast=2,
            roi=tuple(spec["native_display_ROI_xywh"]),
        ))
    return output


def standing(results, native):
    record = read_json(PRIOR / "endpoint/standing-results.json")
    previous = read_json(checked(record["display_parent_boards"]))
    by_id = {r["id"]: r for r in results["standing"]}
    rendered = []
    for region in previous["boards"]:
        if region["observation"] not in by_id:
            continue
        row = by_id[region["observation"]]
        assert row["input"]["raw"]["arrays"] == region["input_arrays"]
        with Image.open(checked(region["image"])) as img:
            pixels = np.asarray(img.convert("RGB"))
        old = {p["label"]: pixels[y:y+h, x:x+w] for p in region["panels"]
               for x,y,w,h in [p["png_xywh"]]}
        panels = [(k, old[k]) for k in ("ISO6400 camera JPEG", "Noisy (Malvar)", "V120 EMA",
                  "Parent 100k EMA") if k in old]
        roi = region["case"]["ROI_xywh"]
        x, y, w, h = roi
        with np.load(checked(region["input_arrays"]), allow_pickle=False) as data:
            wb, matrix = (torch.from_numpy(data[k]) for k in ("wb", "matrix"))
        base = np.load(checked(row["input"]["parent"]), allow_pickle=False)[..., y:y+h, x:x+w].astype(float)
        info = {}
        with np.load(checked(row["saved"]), allow_pickle=False) as data:
            for key, label in zip(METHODS, NAMES, strict=True):
                output = data[key]
                sub = output[..., y:y+h, x:x+w].astype(float)
                display = display_crop(torch.from_numpy(output), wb, matrix, roi, exposure=region["display_exposure"])
                panels.append((label, np.rint(display.clip(0, 1)*255).astype(np.uint8)))
                info[key] = {
                    "vs_parent_camera_RGB_RMS_DN16": float(65535 * np.sqrt(np.mean((sub-base)**2))),
                    "changed_camera_RGB_values": int(np.count_nonzero(sub-base)),
                }
        panels.extend((k, old[k]) for k in ("ISO100 AHD reference", "ISO100 camera JPEG") if k in old)
        rendered.append(native_png(native / (region["id"]+".png"), panels) | {
            "id": region["id"], "input": region["input_arrays"], "ROI_xywh": roi, "review": row["saved"],
            "parent": row["input"]["parent"], "noise": region["noise"], "display_exposure": region["display_exposure"],
            "reference_role": region["reference_role"], "measured_camera_changes": info,
        })
    assert len(rendered) == 8
    return rendered


def analyze():
    torch.set_num_threads(2)
    result = ROOT / "results.json"
    data = read_json(result)
    pool = {}
    rng = np.random.default_rng(120811007)
    panel = read_json(SCENE / "matched-analysis-plan.json")
    faint = {row[2] for row in panel["fainter_half_by_frozen_clean_increment"]}
    for draw in ("coupled", "independent"):
        cases = [r for r in data["rows"] if r["draw"] == draw]
        assert len(cases) == 64
        bands = {}
        for subgroup, group in (("all", cases), ("fainter", [r for r in cases if r["source"] in faint])):
            bands[subgroup] = {
                label: compare(group, coefs, rng, True) for label, coefs in CONTRASTS.items()
            }
            bands[subgroup]["strength_DN16"] = {
                metric: (65535 * np.tile(
                    np.asarray([row["trace"][metric] for row in group]).mean(axis=0), 1
                )).tolist()
                for metric in ("single_RMS", "averaged_RMS", "orientation_disagreement_RMS")
            }
        pool[draw] = bands
    native = ROOT/"native"
    native.mkdir()
    photos = synthetic(data, native)
    cameras = standing(data, native)
    write_json(ROOT/"analysis.json", {
        "source": reference(result), "driver": reference(__file__), "pooled_64": data["metrics"],
        "contrasts": pool, "synthetic_native": photos, "GFX_standing_native": cameras,
        "max_guarded_single_replay_difference_DN16": max(r["guarded_single_replay_max_difference_DN16"] for r in data["rows"]),
        "actual_viewing_complete": False,
    })


if __name__ == "__main__":
    analyze()
