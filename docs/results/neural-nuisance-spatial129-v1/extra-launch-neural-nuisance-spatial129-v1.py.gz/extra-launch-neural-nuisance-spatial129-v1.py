"""Launch the fixed129 local-amplitude pilot and closed-output review."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import psutil
from demosaic.experiments.artifacts import checked, read_json, reference, write_json, verify_plan

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-spatial129-pilot-v1"
plan = read_json(root / "plan.json")
verify_plan(plan)
assert not (root / "launch.json").exists()
assert len(plan["rows"]) == 48 and plan["prediction_cache"] is None
cache = read_json(checked(plan["background_cache"]))
assert {r["id"] for r in cache["rows"]} == {r["id"] for r in plan["rows"]}
assert cache["new_root_forwards"] == cache["new_encoder_forwards"] == 0
assert plan["geometry_config"]["frequency_weighting"] == "hann-inverse-variance"
assert plan["geometry_config"]["amplitude_window"] == 129
audit_script = root / "audit_neural_nuisance_inputs.py"
shutil.copyfile(repo / "scripts/audit_neural_nuisance_inputs.py", audit_script)
old = repo / ".cache/experiments/neural-nuisance-full-edge512-pilot-v1"
controller = (old / "controller.py").read_text().replace(
    "sorted(os.sched_getaffinity(0))[-4:-2]", "[16,17]"
).replace("Full edge NN t2", "Spatial NN t2").replace("Full edge H1 t2", "Spatial H1 t2")
needle = "for name,args,gpu in stages:"
replacement = "stages.insert(1,('background-audit',[py,str(root/'audit_neural_nuisance_inputs.py'),str(root),str(root/'background-independent-audit.json')],False))\n" + needle
assert controller.count(needle) == 1
(root / "controller.py").write_text(controller.replace(needle, replacement))
follow = root / "followup"
follow.mkdir()
shutil.copyfile(repo / "scripts/review_neural_nuisance.py", follow / "review_neural_nuisance.py")
shutil.copyfile(old / "followup/controller.py", follow / "controller.py")
env = dict(os.environ, PYTHONPATH=str(repo / "src"), OMP_NUM_THREADS="2",
           OPENBLAS_NUM_THREADS="2", MKL_NUM_THREADS="2")
with (root / "controller.log").open("x") as log:
    producer = subprocess.Popen([sys.executable, str(root / "controller.py"), str(root)],
                               stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
identity = {"pid": producer.pid, "create_time": psutil.Process(producer.pid).create_time(),
            "plan": reference(root / "plan.json"), "controller": reference(root / "controller.py")}
write_json(root / "launch.json", identity)
write_json(follow / "plan.json", {"producer": identity, "root": str(root),
    "script": reference(follow / "review_neural_nuisance.py"), "output": str(root / "summary-review"),
    "work": plan["work"]})
with (follow / "controller.log").open("x") as log:
    reviewer = subprocess.Popen([sys.executable, str(follow / "controller.py"), str(follow)],
                               stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
psutil.Process(reviewer.pid).cpu_affinity([16, 17])
write_json(follow / "launch.json", {"pid": reviewer.pid,
    "create_time": psutil.Process(reviewer.pid).create_time(), "plan": reference(follow / "plan.json")})
write_json(root / "study.json", {"plan": reference(root / "plan.json"),
    "baseline": reference(repo / ".cache/experiments/neural-nuisance-hann512-pilot-v1/plan.json"), "launcher": reference(__file__),
    "diagnostics": [reference(repo / ".cache/diagnose-hann-transfer-v1.json"), reference(repo / ".cache/diagnose-weighted-discovery-v1.json"),
                    reference(repo / ".cache/diagnose-weighted-hann-discovery-v1.json"),
                    reference(repo / ".cache/weighted-discovery-reproduction-v2.json")],
    "intervention": "Same completed Hann512/full-frame edge/carrier/variance; native129/stride32 A-only local full/null WLS amplitudes, normalized Gram cutoff1e-8; physical validation/gates and conditional full-minus-null delivery retained; parent projected through identical local operator after scoring",
    "new_neural_forwards_expected": 0, "cached_fields": 88,
    "primary_comparison": "conditional-local-t2 vs local-t2; retain native256 preferred operating point and full-frame512 prior separately",
    "scope": "Same adaptive two-source48-case development cohort/all3 priors/6 controls/thresholds0,2,4; all corrections close before new quality analysis; both standing GFX families/ROIs/profiles/JPEGs retained; no GT/reference in fitting",
})
print("producer", identity)
print("reviewer", read_json(follow / "launch.json"))
