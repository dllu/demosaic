"""A-only weighted sinusoid discovery; recipes used only after selection."""
import os
from pathlib import Path

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import fit_candidate, geometry, stratified_split
from demosaic.local_validated_waves import _wave_columns
from pilot_neural_nuisance import input_arrays, raw_frame


def spectrum(raw, selected, basis, weights):
    scale = weights / weights.mean()
    sigma = np.sqrt(scale)
    q, _ = np.linalg.qr(basis[selected] * sigma[:, None], mode="reduced")
    values = raw.ravel()[selected] * sigma
    residual = values - q @ (q.T @ values)
    field = np.zeros(raw.shape)
    field.ravel()[selected] = residual * sigma
    cross = np.fft.fft2(field)
    field.ravel()[selected] = scale
    mass = np.fft.fft2(field)
    iy, ix = np.indices(raw.shape)
    double = mass[(2 * iy) % raw.shape[0], (2 * ix) % raw.shape[1]]
    cc, ss, cs = (scale.sum() + double.real) / 2, (scale.sum() - double.real) / 2, -double.imag / 2
    for column in q.T:
        field.ravel()[selected] = column * sigma
        transform = np.fft.fft2(field)
        a, b = transform.real, -transform.imag
        cc -= a * a
        ss -= b * b
        cs -= a * b
    a, b = cross.real, -cross.imag
    det = cc * ss - cs * cs
    valid = det > 1e-10 * scale.sum() ** 2
    power = np.zeros(raw.shape)
    power[valid] = (ss * a * a - 2 * cs * a * b + cc * b * b)[valid] / det[valid]
    return power


def select(raw, selected, basis, weights, avoid=None):
    power = spectrum(raw, selected, basis, weights)
    fy, fx = np.meshgrid(np.fft.fftfreq(raw.shape[0]), np.fft.fftfreq(raw.shape[1]), indexing="ij")
    radius = np.hypot(fx, fy)
    allowed = (radius >= 1 / 64) & (radius <= .24) & ((fy > 0) | ((fy == 0) & (fx > 0)))
    if avoid is not None:
        allowed &= abs(fx * avoid[0] + fy * avoid[1]) <= np.cos(np.deg2rad(20)) * radius * np.linalg.norm(avoid)
    index = np.unravel_index(np.argmax(np.where(allowed, power, -np.inf)), raw.shape)
    return np.array([fx[index], fy[index]])


def refine(raw, selected, basis, weights, frequency, xx, yy, avoid=None):
    sigma = np.sqrt(weights / weights.mean())
    q, _ = np.linalg.qr(basis[selected] * sigma[:, None], mode="reduced")
    values = raw.ravel()[selected] * sigma
    residual = values - q @ (q.T @ values)
    candidates = []
    for dy in np.linspace(-.5, .5, 9) / min(raw.shape):
        for dx in np.linspace(-.5, .5, 9) / min(raw.shape):
            f = frequency + [dx, dy]
            if not 1 / 64 <= np.linalg.norm(f) <= .24:
                continue
            if avoid is not None and abs(f @ avoid) > np.cos(np.deg2rad(20)) * np.linalg.norm(f) * np.linalg.norm(avoid):
                continue
            wave = _wave_columns(xx, yy, f)[selected] * sigma[:, None]
            wave -= q @ (q.T @ wave)
            coefficient = np.linalg.lstsq(wave, residual, rcond=1e-10)[0]
            candidates.append((float(np.sum((wave @ coefficient) ** 2)), f))
    return max(candidates, key=lambda item: item[0])[1]


root = Path.cwd()
os.nice(10)
os.sched_setaffinity(0, [16, 17])
plan_path = root / ".cache/experiments/neural-nuisance-full-edge512-pilot-v1/plan.json"
plan = read_json(plan_path)
rows = []
for group in plan["finite_groups"]:
    if group["profile"] != "iso400" or group["metadata"]["placement"] != "far":
        continue
    row = next(r for r in plan["rows"] if r["id"] == group["cases"][2])
    data = input_arrays(row)
    raw = raw_frame(data)
    colors = np.tile(data["colors"].reshape(2, 2), (raw.shape[0] // 2, raw.shape[1] // 2))
    mask = stratified_split(raw.shape, plan["geometry_config"]["split_seed"])
    xx, yy, basis, _ = geometry(raw.shape)
    for fold, selected_mask in enumerate([mask, ~mask]):
        initial = fit_candidate(raw, colors, selected_mask, shot=row["noise"]["shot"], read=row["noise"]["read"], nuisance="step", peaks=1, edge_refinements=3, edge_search="full-frame")
        angle, offset = initial.edge_geometry
        x, y = basis[:, 1], basis[:, 2]
        nuisance = np.column_stack((basis, x * np.cos(angle) + y * np.sin(angle) > offset))
        selected = ((colors == 1) & selected_mask).ravel()
        proxy = nuisance[selected] @ np.linalg.lstsq(nuisance[selected], raw.ravel()[selected], rcond=1e-10)[0]
        weights = 1 / (row["noise"]["read"] + row["noise"]["shot"] * np.maximum(proxy, 1e-6))
        first = refine(raw, selected, nuisance, weights, select(raw, selected, nuisance, weights), xx, yy)
        one = np.column_stack((nuisance, _wave_columns(xx, yy, first)))
        second = refine(raw, selected, one, weights, select(raw, selected, one, weights, first), xx, yy, first)
        # Independent explicit weighted least squares checks all FFT benefits at
        # fixed grid frequencies; this truth-free check precedes recipe access.
        power = spectrum(raw, selected, nuisance, weights)
        sigma = np.sqrt(weights / weights.mean())
        design = nuisance[selected] * sigma[:, None]
        values = raw.ravel()[selected] * sigma
        base = np.sum((values - design @ np.linalg.lstsq(design, values, rcond=1e-10)[0]) ** 2)
        discrepancies = []
        for iy, ix in [(7, 2), (31, 49), (39, 8), (4, 13), (70, 25)]:
            f = [np.fft.fftfreq(raw.shape[1])[ix], np.fft.fftfreq(raw.shape[0])[iy]]
            full = np.column_stack((design, _wave_columns(xx, yy, f)[selected] * sigma[:, None]))
            gain = base - np.sum((values - full @ np.linalg.lstsq(full, values, rcond=1e-10)[0]) ** 2)
            discrepancies.append(abs(gain - power[iy, ix]))
        assert max(discrepancies) < 1e-10
        recipe = group["metadata"]["recipe"]
        truth = np.column_stack([np.cos(recipe["wire_angles"]), np.sin(recipe["wire_angles"])]) / np.asarray(recipe["periods"])[:, None]
        f = np.array([first, second])
        distance = np.minimum(np.linalg.norm(f[:, None] - truth, axis=-1), np.linalg.norm(f[:, None] + truth, axis=-1)) * raw.shape[0]
        rows.append({"source": recipe["source"], "fold": fold, "frequencies": f.tolist(), "closest_truth_frequency_distance_native_bins": distance.min(axis=0).tolist(), "weighted_FFT_explicit_LS_max_error": max(discrepancies), "weight_ratio_max_min": float(weights.max() / weights.min())})
        print(rows[-1], flush=True)
write_json(root / ".cache/diagnose-weighted-discovery-v1.json", {"plan": reference(plan_path), "script": reference(__file__), "rows": rows, "new_neural_forwards": 0, "Torch_imported": False, "GT_reference_RGB_arrays_loaded": 0, "scope": "Post-closure A-only weighted-periodogram feasibility diagnostic; full-frame nuisance fixed. Recipe frequencies used only after selection, no new noise/RAW/learned weights."})
