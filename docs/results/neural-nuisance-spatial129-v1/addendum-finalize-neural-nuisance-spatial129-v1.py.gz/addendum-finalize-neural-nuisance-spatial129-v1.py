import gzip
from datetime import datetime, timezone
from pathlib import Path
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-spatial129-pilot-v1"
destination = repo / "docs/results/neural-nuisance-spatial129-v1"
notes = [
    ([0,1,2,3], "All twelve procedural comparisons and material/sky/building primary crops viewed. Low-prior strong modulation increases; most weak crossings remain absent. High-noise outputs largely parent-like. Bark/fur soft; sky quiet. Analytic building now has clear green/magenta bands at lower left; neural reduces but does not establish real fidelity."),
    ([4,5,6,7], "Foliage/coarse fence and both cab profiles/ROIs/JPEGs inspected. Fine cab crossings remain missing. All stress views and two NN triplets viewed. Analytic building maximum/prior failure show severe green/magenta broad bands and altered rail contrast; neural much smaller but nonzero changes. New local amplitude is not a real-photo quality upgrade."),
    ([8,9,10], "Both analytic native160 noisy/restored/exact-GT triplets viewed, with improved strong slants but still muted weak crossings. Both fixed0/2/4 charts inspected with intact labels. Threshold0 buys more400/far response with large quiet cost;1600/far weak response declines. No posthoc threshold retuning."),
]
for i, (sheets, note) in enumerate(notes):
    write_json(root / f"viewing-batch-{i}.json", {"sheets": sheets, "actually_viewed": True,
        "method": "Exact unresized contact sheets through tools.view_image", "notes": note})
prepared = read_json(root / "publication-prepared.json")
manifest = read_json(root / "contact-sheets/manifest.json")
assert manifest["source_images"] == len(prepared["images"]) == 36
assert sorted(s for group, _ in notes for s in group) == list(range(len(manifest["sheets"])))
archives = list(prepared["archives"])
for source in [root / "publication-prepared.json", root / "contact-sheets/manifest.json",
               *sorted(root.glob("viewing-batch-*.json")), repo / ".cache/native-contact-sheets-v1.py", Path(__file__)]:
    target = destination / ("addendum-" + source.name + ".gz")
    with target.open("xb") as stream:
        stream.write(gzip.compress(source.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    archives.append({"original": reference(source), "published": reference(target), "decompressed_bytes_exact": True})
for item in archives:
    assert gzip.decompress(checked(item["published"]).read_bytes()) == checked(item["original"]).read_bytes()
for item in prepared["images"]:
    assert checked(item["published"]).read_bytes() == checked(item["original"]).read_bytes()
prepared.update(archives=archives,
    viewing={"actually_viewed": True, "figures": 36, "contact_sheets": 11,
             "manifest": reference(root / "contact-sheets/manifest.json"),
             "batches": [reference(p) for p in sorted(root.glob("viewing-batch-*.json"))]},
    status="complete; low-prior synthetic gains with severe real building artifacts",
    quality_decision="Keep local129 as an explicit ablation with synthetic strengths/costs. Preserve global-amplitude alternatives; new green/magenta building bands prevent a real-photo/default quality recommendation.",
    comparison_baselines=[reference(repo / "docs/results" / name / "publication.json") for name in [
        "neural-nuisance-hann512-v1", "neural-nuisance-fixed-v1", "neural-nuisance-full-edge512-v1"]],
    scope_clarification="Declared amplitude_window129 overrides inherited global-amplitude statement; local full/null WLS and identical parent projection are explicit in plan scope and study.json. A standalone conditional API was added after freezing; current-source/36-output-per-study equivalence evidence archived separately. Executed sources/receipts unchanged.",
    published_UTC=datetime.now(timezone.utc).isoformat())
write_json(destination / "publication.json", prepared)
print(len(archives), "exact archives;36 source figures actually viewed")
