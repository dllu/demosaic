"""Match the public standalone analytic API to closed six-control predictions."""
import os
import sys
from dataclasses import replace
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.local_validated_waves import LocalWaveConfig, restore_conditional_waves
from pilot_neural_nuisance import input_arrays, raw_frame

os.nice(10)
os.sched_setaffinity(0, [16, 17])
root, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
assert read_json(root / "controller-result.json")["all_stages_succeeded"]
plan = read_json(root / "plan.json")
records = {r["id"]: r for r in read_json(root / "collection.json")["rows"]}
backgrounds = {r["id"]: r for r in read_json(root / "backgrounds-collection.json")["rows"]}
config = LocalWaveConfig(**plan["geometry_config"])
names = ["iso400-index0008-role2", "iso400-index0024-role2", "main-building-detail",
         "mesh-nominal", "mesh-profile3879"]
zero = next(r["id"] for r in plan["rows"] if r["noise"]["shot"] + r["noise"]["read"] == 0)
names.append(zero)
results = []
for name in names:
    row = next(r for r in plan["rows"] if r["id"] == name)
    data = input_arrays(row)
    raw = raw_frame(data)
    actual_config = config if min(raw.shape) >= config.window else replace(config, window=min(raw.shape), stride=min(raw.shape)//2)
    parent = np.load(checked(row["parent"]))[row["sample"]]
    mask = np.load(checked(backgrounds[name]["mask_A"])) if backgrounds[name].get("mask_A") else None
    values, _ = restore_conditional_waves(parent, data["packed"], data["colors"],
        shot=row["noise"]["shot"], read=row["noise"]["read"], thresholds=tuple(plan["thresholds"]),
        config=actual_config, discovery_mask=mask)
    for (mode, threshold), value in values.items():
        expected = records[name]["predictions"][f"conditional-{mode}-t{threshold:g}"]
        np.testing.assert_array_equal(value, np.load(checked(expected)))
        results.append({"id": name, "mode": mode, "threshold": threshold, "prediction": expected, "exact": True})
write_json(output, {"plan": reference(root / "plan.json"), "script": reference(__file__),
    "rows": results, "current_sources": [reference(Path("src/demosaic") / name) for name in [
        "local_validated_waves.py", "spatial_carrier_amplitudes.py", "neural_nuisance.py"]],
    "new_neural_forwards": 0, "GT_reference_RGB_arrays_loaded": 0, "Torch_imported": False,
    "scope": "Public standalone conditional API matches every six-control analytic output at all0/2/4 thresholds for both finite400/far cases, building, both cab profiles, and one zero-noise case. No neural nuisance fields loaded or GT/reference arrays used."})
print(len(results), "analytic predictions exact; no neural fields/inference/GT RGB")
