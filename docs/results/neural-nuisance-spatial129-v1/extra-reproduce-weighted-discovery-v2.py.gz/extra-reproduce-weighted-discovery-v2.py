from pathlib import Path
import os
import numpy as np
from demosaic.experiments.artifacts import read_json, write_json, reference
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.local_validated_waves import LocalWaveConfig, fit_local_candidate
from pilot_neural_nuisance import input_arrays, raw_frame

os.sched_setaffinity(0, [16, 17])
root = Path.cwd()
rows = []
for tag, mode in [
    ("neural-nuisance-fixed-proposals-pilot-v1", "uniform"),
    ("neural-nuisance-full-edge512-pilot-v1", "uniform"),
    ("neural-nuisance-full-edge512-pilot-v1", "hann-inverse-variance"),
]:
    path = root / ".cache/experiments" / tag
    plan = read_json(path / "plan.json")
    records = {r["id"]: r for r in read_json(path / "collection.json")["rows"]}
    diagnostic = read_json(root / ".cache/diagnose-weighted-hann-discovery-v1.json")
    config = LocalWaveConfig(**dict(plan["geometry_config"], frequency_weighting=mode))
    for group in plan["finite_groups"]:
        if group["profile"] != "iso400" or group["metadata"]["placement"] != "far":
            continue
        row = next(r for r in plan["rows"] if r["id"] == group["cases"][2])
        data = input_arrays(row)
        raw = raw_frame(data)
        colors = np.tile(data["colors"].reshape(2, 2), (raw.shape[0] // 2, raw.shape[1] // 2))
        mask = stratified_split(raw.shape, config.split_seed)
        record = records[row["id"]]["aux"]["records"][0]
        x, y = record["xy"]
        region = np.s_[y:y + config.window, x:x + config.window]
        for fold, selected in enumerate([mask, ~mask]):
            candidate = fit_local_candidate(raw[region], colors[region], selected[region],
                shot=row["noise"]["shot"], read=row["noise"]["read"], config=config)
            if mode == "uniform":
                expected = record["arms"]["H1-"]["frequencies"][fold]
            else:
                expected = next(r["frequencies"] for r in diagnostic["rows"]
                    if r["source"] == group["metadata"]["recipe"]["source"] and r["fold"] == fold)
            np.testing.assert_array_equal(candidate.frequencies_xy, expected)
            rows.append({"tag": tag, "mode": mode, "case": row["id"], "fold": fold,
                         "tile_xy": [x, y], "window": config.window, "frequencies_exact": True})
write_json(root / ".cache/weighted-discovery-reproduction-v2.json", {
    "script": reference(__file__), "rows": rows,
    "legacy_source256_and512_reproduced_exactly": True,
    "Hann_diagnostic_reproduced_exactly": True, "new_neural_forwards": 0,
    "GT_reference_RGB_arrays_loaded": 0, "Torch_imported": False,
    "initial_reproduction_failure": "v1 compared a whole512 fit against the saved first256 tile; original failed log retained; v2 uses executed tile coordinates and global partition",
})
print("12 exact two-fold discovery checks passed; no GT RGB or neural calls")
