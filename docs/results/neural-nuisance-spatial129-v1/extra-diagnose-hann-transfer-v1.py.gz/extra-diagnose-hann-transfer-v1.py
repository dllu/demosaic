"""Post-closure frozen-operator signal transfer, not an inference quality result."""
import os
from dataclasses import replace
from pathlib import Path
import numpy as np
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.experiments.evaluation.withheld import stratified_split
from demosaic.local_validated_waves import LocalWaveConfig, fit_local_candidate, conditional_scores, match_directions, support_weight
from demosaic.neural_nuisance import WithheldBackground, fit_neural_candidate, conditional_components
from pilot_neural_nuisance import input_arrays, raw_frame

os.nice(10)
os.sched_setaffinity(0, [16, 17])
repo = Path.cwd()
root = repo / ".cache/experiments/neural-nuisance-hann512-pilot-v1"
plan = read_json(root / "plan.json")
collection = read_json(root / "collection.json")
assert read_json(root / "controller-result.json")["all_stages_succeeded"]
records = {r["id"]: r for r in collection["rows"]}
fields = {r["id"]: r for r in read_json(root / "backgrounds-collection.json")["rows"]}
config = LocalWaveConfig(**plan["geometry_config"])
rows = []
for group in plan["finite_groups"]:
    if group["profile"] != "iso400" or group["metadata"]["placement"] != "far":
        continue
    row = next(r for r in plan["rows"] if r["id"] == group["cases"][2])
    data = input_arrays(row)
    raw = raw_frame(data)
    colors = np.tile(data["colors"].reshape(2, 2), (raw.shape[0] // 2, raw.shape[1] // 2))
    mask = stratified_split(raw.shape, config.split_seed)
    backgrounds = [WithheldBackground(np.load(checked(f)), m) for f, m in zip(fields[row["id"]]["fields"], [mask, ~mask], strict=True)]
    references = [fit_local_candidate(raw, colors, m, shot=row["noise"]["shot"], read=row["noise"]["read"], config=config) for m in [mask, ~mask]]
    neural = [fit_neural_candidate(raw, colors, c, b, config=config, reselect_frequencies=False) for c, b in zip(references, backgrounds, strict=True)]
    parent = np.load(checked(row["parent"]))[row["sample"]]
    with np.load(checked(group["arrays"]), allow_pickle=False) as archive:
        # Target arrays enter only the closed diagnostic's fixed linear maps.
        target = archive["target"].astype(np.float64)
    weak = target[2] - target[1]
    yy, xx = np.indices(raw.shape)
    raw_delta = weak[colors, yy, xx]
    scale = np.vdot(weak, weak)
    taper = np.sin(np.pi * (np.arange(config.window) + .5) / config.window) ** 2
    blend = taper[:, None] * taper[None]
    for arm, candidates, nuisance_fields, prefix in [("analytic", references, [None, None], "conditional-"), ("neural", neural, backgrounds, "")]:
        scores = [conditional_scores(c, raw, colors, ~c.discovery_mask, window=config.validation_window, stride=config.validation_stride) for c in candidates]
        matches = match_directions(candidates[0].frequencies_xy, candidates[1].frequencies_xy, raw.shape, config.match_native_bins, matching=config.matching)
        real = [conditional_components(c, parent, raw, colors, b)[0] for c, b in zip(candidates, nuisance_fields, strict=True)]
        signal = []
        for c, b in zip(candidates, nuisance_fields, strict=True):
            coefficient = np.stack([operator @ raw_delta.ravel()[selected] for operator, selected in zip(c.operators, c.selected_indices, strict=True)])
            signal.append(conditional_components(replace(c, coefficients=coefficient), np.zeros_like(parent), raw_delta, colors, b)[0])
        responses = {"ungated": np.zeros_like(weak), **{f"local-t{t}": np.zeros_like(weak) for t in [0, 2, 4]}}
        real_total = np.zeros_like(weak)
        for a, b, _ in matches:
            local = np.minimum(scores[0][0][a], scores[1][0][b])
            component = (signal[0][a] + signal[1][b]) / 2
            responses["ungated"] += component
            for threshold in [0, 2, 4]:
                responses[f"local-t{threshold}"] += component * support_weight(local, threshold)
            real_total += (real[0][a] + real[1][b]) / 2 * support_weight(local, 2) * blend
        reproduced = (parent.astype(np.float64) + real_total / blend).astype(parent.dtype)
        np.testing.assert_array_equal(reproduced, np.load(checked(records[row["id"]]["predictions"][prefix + "local-t2"])))
        rows.append({"id": row["id"], "arm": arm, "matches": matches, "actual_executed_output_exact": True,
            "frozen_operator_weak_signal_transfer": {key: float(np.vdot(value, weak) / scale) for key, value in responses.items()},
            "frozen_operator_weak_signal_RMS_error_DN16": {key: float(np.sqrt(np.mean((value - weak) ** 2)) * 65535) for key, value in responses.items()}})
        print(rows[-1], flush=True)
write_json(repo / ".cache/diagnose-hann-transfer-v1.json", {"plan": reference(root / "plan.json"), "collection": reference(root / "collection.json"),
    "script": reference(__file__), "rows": rows, "new_neural_forwards": 0, "Torch_imported": False,
    "scope": "Post-closure oracle mechanistic diagnostic: all geometry, weights, operators, nuisance and support scores frozen from actual role2 noisy input; exact GT weak increment passed through that fixed linear map, without parent. Real parent/output reproduced exactly. Not a deployable correction, quality result or real-photo reference score."})
