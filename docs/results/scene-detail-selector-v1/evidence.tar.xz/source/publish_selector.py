"""Publish matched head checkpoints, feature lineage and native comparisons."""

from hashlib import file_digest
from pathlib import Path
import shutil
import tarfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from detail_selector import OUT, HERE

ROOT = Path.cwd()
ASSETS = ROOT / "docs/assets" / HERE.name
RESULTS = ROOT / "docs/results" / HERE.name
RECEIPTS = (
    "preflight/plan",
    "preflight/completed",
    "fit-preflight/result",
    "training/plan",
    "training/completed",
    "training/resume-encoding",
    "training/shared-collection",
    "fit-training/result",
    "audit",
    "shared-local-preview",
    "review-features",
    "evaluate-calibration",
    "evaluate-transfer",
    "review-exact",
    "review-camera",
    "review-wires",
    "basis-headroom",
    "response-frontier",
    "delivery-audit",
    "strata",
    "equal-response",
)


def bind(path):
    return reference(path) | {"path": str(path.relative_to(ROOT))}


def image(item):
    src = checked(item["image"])
    dest = ASSETS / src.name
    shutil.copyfile(src, dest)
    ref = bind(dest)
    assert ref["sha256"] == item["image"]["sha256"]
    with Image.open(dest) as img:
        for t in item["panels"]:
            x, y, w, h = t["png_xywh"]
            assert w == h == 160 and x + w <= img.width and y + h <= img.height
    return item | {"image": ref}


def plot(scores, frontier):
    colors = {
        "nominal": "#333333",
        "heuristic": "#666666",
        "local locked": "#4477aa",
        "pooled locked": "#aa3377",
        "spatial locked": "#228833",
        "shuffled locked": "#cc6677",
        "swapped locked": "#aa4499",
    }
    names = {
        "nominal": "Parent",
        "heuristic": "Earlier gate",
        "local locked": "Local",
        "pooled locked": "Pooled",
        "spatial locked": "Aligned",
        "shuffled locked": "Rolled",
        "swapped locked": "Other photo",
    }
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.3), layout="constrained")
    parent = scores["nominal"]
    for i, (ax, axis, title) in enumerate(
        zip(axes, ("increment", "flat"), ("Weak increment", "Exact-flat core"), strict=True)
    ):
        ax.axvline(0, color="#aaa", linewidth=1, linestyle=":")
        ax.axhline(0, color="#aaa", linewidth=1, linestyle=":")
        for k, c in colors.items():
            d = scores[k]
            mark = {"shuffled locked": "x", "swapped locked": "+", "nominal": "s"}.get(k, "o")
            ax.scatter(
                d[axis] - parent[axis],
                d["response_pp"] - parent["response_pp"],
                color=c,
                marker=mark,
                s=42,
                label=names[k],
            )
        att = frontier["summary"][frontier["example_at_transfer_limits"]]
        ax.scatter(
            att[f"{axis}_energy"] - parent[axis],
            att["response_pp"] - parent["response_pp"],
            marker="*",
            s=75,
            color="#785723",
            label="Exact targets",
        )
        ax.set_title(title)
        ax.set_xlabel("RMS change from parent (DN16)")
        ax.grid(axis="y", alpha=0.2)
    axes[0].set_ylabel("Fine contrast change (percentage points)")
    axes[1].legend(fontsize=8, frameon=False, loc="best")
    out = ASSETS / "detail-versus-error.png"
    fig.savefig(out, dpi=160)
    return bind(out)


def verify_training(data, refs):
    plan = data["training/plan"]
    base = plan["parent"]
    plan_rows = plan["samples"]
    completed = data["training/completed"]
    assert completed["plan"] == refs["training/plan"]
    handoff = data["training/resume-encoding"]
    resume = data["training/shared-collection"]
    count = resume["counts"]
    assert (
        resume["handoff"] == refs["training/resume-encoding"]
        and resume["completed"] == refs["training/completed"]
    )
    assert (
        handoff["plan"] == refs["training/plan"]
        and handoff["preview_parity"] == refs["shared-local-preview"]
    )
    assert completed["chunks"][: len(handoff["before"])] == handoff["before"]
    rows = []
    secs = 0
    members = {}
    for k, source in enumerate(completed["chunks"]):
        row = read_json(checked(source))
        checked(row["data"])
        rows.extend(row["samples"])
        secs += row["seconds"]
        members[f"training/feature-chunk-{k:02}.json"] = source
    assert len(rows) == 1600 and len({r["source"] for r in rows}) == 1600
    assert count["series"] + 32 * len(handoff["before"]) == len(rows)
    assert (
        count["series"] == count["reused_encoder_calls"]
        and count["old_encoder_calls"] == 3 * count["series"]
    )
    for seen, source in zip(rows, plan_rows, strict=True):
        assert seen["source"] == source["id"] and seen["sha256"] == source["cache_sha256"]
        assert seen["observed"]["shape"] == [3, 4, 128, 128]
        assert seen["target"]["shape"] == [3, 3, 256, 256] and source["split"] == "train"
    train = {r["source"] for r in rows} | {r["sha256"] for r in rows}
    earlier = read_json(checked(plan["observations_for_evaluation"]))
    for role in ("calibration", "transfer", "wires"):
        for r in earlier["groups"][role]:
            f = r["source"]
            if isinstance(f, str):
                matching = r["fixture"]["source"]
                assert f == matching["id"]
                ids = {f, matching["cache_sha256"]}
            else:
                ids = {f["id"], f["cache_sha256"]}
            assert ids.isdisjoint(train)
    fit = data["fit-training/result"]
    assert fit["source"] == refs["training/completed"] and fit["sources"] == 1600
    assert base == data["review-features"]["parent"]
    assert fit["native_role_examples"] == 4800
    for k, v in fit["checkpoints"].items():
        checked(v)
        members[f"checkpoints/{k}.pt"] = v
    for k, v in data["fit-preflight/result"]["checkpoints"].items():
        members[f"preflight-checkpoints/{k}.pt"] = v
    return members, secs


def main():
    entries = RECEIPTS + (("profile-idle",) if (OUT / "profile-idle.json").is_file() else ())
    refs = {k: reference(OUT / f"{k}.json") for k in entries}
    data = {k: read_json(checked(v)) for k, v in refs.items()}
    for item in data.values():
        for field in ("driver", "head"):
            if field in item:
                checked(item[field])
    members, sec = verify_training(data, refs)
    assert data["evaluate-transfer"]["prior"] == refs["evaluate-calibration"]
    assert data["delivery-audit"]["evaluation"] == refs["evaluate-transfer"]
    assert data["strata"]["source"] == data["equal-response"]["source"] == refs["evaluate-transfer"]
    assert data["delivery-audit"]["maximum_error_DN16"] < 0.002
    for k in (
        "evaluate-calibration",
        "evaluate-transfer",
        "review-camera",
        "review-exact",
        "review-wires",
    ):
        assert data[k]["fit"] == refs["fit-training/result"]
    for k in ("review-camera", "review-exact", "review-wires"):
        assert data[k]["calibration"] == refs["evaluate-calibration"]
    assert data["review-exact"]["report"]["holdout"] == refs["evaluate-transfer"]
    scene_data = data["review-features"]
    for pack in scene_data["groups"].values():
        checked(pack["mild_capture"])
        for v in pack["cases"].values():
            checked(v["features"])
    bench = data["shared-local-preview"]
    assert all(r["max_rgb_DN16"] == 0 for r in bench["cases"])
    ASSETS.mkdir(exist_ok=True, parents=True)
    RESULTS.mkdir(exist_ok=True, parents=True)
    camera = data["review-camera"]["report"]["rows"]
    exact = data["review-exact"]["report"]["rows"]
    assert len(exact) == 2 and sum(len(r["native"]) for r in camera) == 12
    for r in camera:
        for board in r["native"]:
            labels = {p["label"] for p in board["panels"]}
            assert "ISO100 AHD reference" in labels
            if r["id"].startswith("mesh-"):
                assert {"ISO6400 camera JPEG", "ISO100 camera JPEG"} <= labels
        r["native"] = [image(a) for a in r["native"]]
    for r in exact:
        r["comparison"] = {k: image(v) for k, v in r["comparison"].items()}
    result = data["evaluate-transfer"]["summary"]
    visual = plot(result["scores"], data["response-frontier"])
    manifest = ASSETS / "manifest.json"
    write_json(
        manifest,
        {
            "camera": camera,
            "natural": exact,
            "tradeoff": visual,
            "parent": data["training/plan"]["parent"],
            "weights": data["fit-training/result"]["checkpoints"],
        },
    )
    report = RESULTS / "summary.json"
    write_json(
        report,
        {
            "training": data["fit-training/result"],
            "collection_seconds_excluding_warmup": sec,
            "local_encoder_reuse": data["training/shared-collection"],
            "training_audit": data["audit"],
            "calibration": data["evaluate-calibration"]["summary"],
            "transfer": result,
            "policy": data["evaluate-calibration"]["policy"],
            "wires": data["review-wires"]["report"]["means"],
            "wider_headroom": data["basis-headroom"]["summary"],
            "frontier": {k: v for k, v in data["response-frontier"].items() if k != "rows"},
            "camera_DN16": {r["id"]: r["changes_DN16"] for r in camera},
            "forward_preview": bench,
            "idle_forward_preview": data.get("profile-idle"),
            "delivery_audit": data["delivery-audit"],
            "strata": data["strata"],
            "equal_response": data["equal-response"],
        },
    )
    members.update({f"receipts/{k}.json": v for k, v in refs.items()})
    members.update({f"source/{p.name}": reference(p) for p in HERE.glob("*.py")})
    members["source/close_run.sh"] = reference(HERE / "close_run.sh")
    for p in ("capture.py", "context_gate.py", "score.py", "mild_score.py"):
        members[f"reused/{p}"] = reference(HERE.with_name("context-conditioned-detail-v1") / p)
    for p in (
        "src/demosaic/scene_context.py",
        "src/demosaic/scene_restoration.py",
        "src/demosaic/pretrained_rgb.py",
        "src/demosaic/scene_data.py",
        "src/demosaic/scene_training_data.py",
        "configs/gfx-qualitative-20231231.json",
        "configs/gfx-green-mesh-20231231.json",
    ):
        members[f"repo/{p}"] = reference(ROOT / p)
    archive = RESULTS / "evidence.tar.xz"
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for k, v in members.items():
            tar.add(checked(v), arcname=k, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == members.keys()
        for k, v in members.items():
            with tar.extractfile(k) as f:
                assert file_digest(f, "sha256").hexdigest() == v["sha256"]
    write_json(
        RESULTS / "publication.json",
        {
            "weights": data["fit-training/result"]["checkpoints"],
            "archive": bind(archive),
            "native": bind(manifest),
            "summary": bind(report),
            "members": members,
            "scope": "Trained crop-scale quality selector, controlled scene-context comparison",
        },
    )
    print(bind(archive), flush=True)


if __name__ == "__main__":
    main()
