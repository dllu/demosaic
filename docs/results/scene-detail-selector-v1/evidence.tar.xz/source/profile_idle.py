"""Measure checked local encoder reuse without the collector sharing the GPU."""

from pathlib import Path
from statistics import median
from time import monotonic

import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.precision import ieee_fp32
from benchmark_shared_local_encoding import forward
from collect_training import batch, capture, load_model
from detail_selector import OUT


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    source = reference(OUT / "shared-local-preview.json")
    input = read_json(checked(source))
    plan = read_json(checked(input["plan"]))
    model = load_model(input["parent"])
    results = []
    with ieee_fp32():
        for i, info in enumerate(plan["samples"]):
            obs, _, prior, _, trace = capture(info, i)
            ops = batch(obs)
            standard = forward(model, ops, prior)
            reused = forward(model, ops, prior, reuse=True)
            assert all(torch.equal(a, reused[k]) for k, a in standard.items())
            times = {"ordinary": [], "shared": []}
            for j in range(3):
                order = (("ordinary", False), ("shared", True))
                if (i + j) % 2:
                    order = tuple(reversed(order))
                for k, use in order:
                    torch.cuda.synchronize()
                    t = monotonic()
                    forward(model, ops, prior, reuse=use)
                    torch.cuda.synchronize()
                    times[k].append(monotonic() - t)
            results.append(
                {
                    "source": trace["source"],
                    "pattern": trace["recipe"]["pattern"],
                    "seconds": times,
                    "max_RGB_DN16": 0,
                }
            )
    summary = {
        k: median([v for r in results for v in r["seconds"][k]]) for k in ("ordinary", "shared")
    }
    logged = {
        "driver": reference(Path(__file__)),
        "prior": source,
        "checkpoint": input["parent"],
        "count": len(results),
        "rows": results,
        "summary": summary,
        "scope": "Local 50k IEEE FP32. Three noise settings per batch of three crops. Encoder equality checked on every shared forward. Restore forward time excludes source decode, previews and setup.",
    }
    write_json(OUT / "profile-idle.json", logged)
    print(summary, flush=True)


if __name__ == "__main__":
    run()
