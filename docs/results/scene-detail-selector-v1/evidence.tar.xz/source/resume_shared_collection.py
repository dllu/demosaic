"""Resume the frozen source order using the checked, shared local encoder output."""

from contextlib import ExitStack
from pathlib import Path
from time import monotonic
from unittest.mock import patch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import collect_training as collector
from benchmark_shared_local_encoding import shared_encoding

OUT = collector.OUT
ROOT = OUT / "training"


def resume():
    verification = reference(OUT / "shared-local-preview.json")
    evidence = read_json(checked(verification))
    assert len(evidence["cases"]) == 8 and all(
        row["max_rgb_DN16"] == 0 for row in evidence["cases"]
    )
    done = list(sorted(ROOT.glob("selection-*.json")))
    before = []
    for row in done:
        receipt = reference(row)
        checked(read_json(checked(receipt))["data"])
        before.append(receipt)
    handoff = ROOT / "resume-encoding.json"
    plan = reference(ROOT / "plan.json")
    write_json(
        handoff,
        {
            "driver": reference(Path(__file__)),
            "plan": plan,
            "before": before,
            "preview_parity": verification,
            "policy": "Exact equality of encoder input on every repeated call",
        },
    )
    raw_run = collector.run
    counts = {"series": 0, "old_encoder_calls": 0, "reused_encoder_calls": 0}
    band = ExitStack()
    stats = None

    def forward(model, desc, packed, variance, profile, strength):
        nonlocal stats
        if strength == collector.CHOICES["crisp"]:
            assert stats is None
            stats = band.enter_context(shared_encoding(model.base.context, compare=True))
        prediction = raw_run(model, desc, packed, variance, profile, strength)
        if strength == collector.CHOICES["smooth"]:
            assert stats == {"used": 3, "executed": 1}
            counts["series"] += 1
            counts["old_encoder_calls"] += stats["used"]
            counts["reused_encoder_calls"] += stats["executed"]
            band.close()
            stats = None
        return prediction

    start = monotonic()
    with band, patch.object(collector, "run", forward):
        collector.main("training")
    write_json(
        ROOT / "shared-collection.json",
        {
            "driver": reference(Path(__file__)),
            "handoff": reference(handoff),
            "completed": reference(ROOT / "completed.json"),
            "counts": counts,
            "wall_time_seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    resume()
