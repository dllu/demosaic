"""Train three matched heads on identical window-level quadratic supervision."""

from copy import deepcopy
from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch
from torch import nn

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import detail_selector as head

SEED = 202611200844
UPDATES = 1200
BATCH = 32
LR = 6e-4
EMA = 0.994
OUT = head.OUT
CORE = np.s_[..., 3:5, 3:5]


def load_source(capture):
    info = read_json(checked(capture))
    data = []
    for binding in info["chunks"]:
        chunk = read_json(checked(binding))
        with np.load(checked(chunk["data"]), allow_pickle=False) as f:
            data.append({k: f[k] for k in f.files})
    return {key: torch.from_numpy(np.concatenate([b[key] for b in data])).cuda() for key in data[0]}


def normalizers(data):
    scene = data["scene"]
    local = data["features"]

    def normal(a):
        dims = tuple(range(a.ndim - 1))
        return {"mean": a.mean(dims), "sd": a.std(dims, unbiased=False).clamp_min(0.05)}

    return {k: normal(v) for k, v in (("local", local), ("scene", scene))}


def normalize(v, norm):
    return ((v - norm["mean"]) / norm["sd"]).clamp(-6, 6)


def normalized_gain(net, data, mode, normal):
    x = normalize(data["features"], normal["local"])
    aligned = normalize(data["scene"], normal["scene"])
    flat = normalize(data["pooled"], normal["scene"])
    slots = head.context_slots(x, aligned, flat, mode)
    return net(x, data["support"], slots.contiguous())


def delta(q, linear, gram):
    return 2 * (q * linear).sum(-1) + torch.einsum("...i,...ij,...j->...", q, gram, q)


def loss(out, data):
    obj = delta(out, data["linear"], data["quad"])
    normalized = obj / (data["level"] + 30**2)
    natural = normalized[:, :2].mean()
    quiet = normalized[:, 2, 3:5, 3:5].mean()
    pa = torch.cat((out[:, 0], out[:, 1]), dim=-1)
    increment = delta(pa, data["p_linear"], data["p_quad"]) / (data["p_level"] + 45**2)
    # The small paired linear incentive is already in the 1.10x weak-increment target.
    regularization = (out[..., 0] ** 2).mean() * 0.0002
    return 0.55 * natural + 1.4 * quiet + 1.35 * increment[:, 3:5, 3:5].mean() + regularization


def save_net(dst, arm, raw, average, opt, norm, stats, source, updates):
    file = dst / f"{arm}.pt"
    temp = file.with_suffix(".partial")
    torch.save(
        {
            "raw": {k: v.cpu() for k, v in raw.state_dict().items()},
            "ema": {k: v.cpu() for k, v in average.state_dict().items()},
            "optimizer": opt.state_dict(),
            "normalization": {k: {a: t.cpu() for a, t in x.items()} for k, x in norm.items()},
            "mode": arm,
            "stats": stats,
            "collector": source,
            "step": updates,
            "seed": SEED,
            "rng": torch.cuda.get_rng_state(),
        },
        temp,
    )
    temp.rename(file)
    return reference(file)


def main(what):
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    root = OUT / f"fit-{what}"
    root.mkdir(exist_ok=True)
    source = reference(OUT / what / "completed.json")
    data = load_source(source)
    norm = normalizers(data)
    total = len(data["features"])
    init = head.Selector()
    nets = {m: deepcopy(init).cuda() for m in head.ARMS}
    averages = {m: deepcopy(net).requires_grad_(False) for m, net in nets.items()}
    optim = {
        m: torch.optim.AdamW(net.parameters(), lr=LR, weight_decay=1e-4) for m, net in nets.items()
    }
    updates = 4 if what == "preflight" else UPDATES
    lottery = torch.Generator(device="cpu").manual_seed(SEED + 1)
    log = {m: [] for m in nets}
    t = monotonic()
    for step in range(1, updates + 1):
        ids = torch.randint(total, (min(total, BATCH),), generator=lottery).cuda()
        rows = {key: arr[ids] for key, arr in data.items()}
        for name, net in nets.items():
            optimizer = optim[name]
            optimizer.zero_grad(set_to_none=True)
            gain = normalized_gain(net, rows, name, norm)
            value = loss(gain, rows)
            assert torch.isfinite(value)
            value.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 1)
            optimizer.step()
            with torch.no_grad():
                torch._foreach_lerp_(
                    list(averages[name].parameters()), list(net.parameters()), 1 - EMA
                )
            if step == 1 or step % 100 == 0 or step == updates:
                log[name].append(
                    {
                        "step": step,
                        "loss": value.item(),
                        "gain": gain.detach().mean((0, 1, 2, 3)).tolist(),
                    }
                )
        if step == updates or step % 100 == 0:
            print(
                what,
                step,
                round(monotonic() - t, 3),
                {k: v[-1] for k, v in log.items()},
                flush=True,
            )
    results = {}
    for name, net in nets.items():
        bind = save_net(
            root, name, net, averages[name], optim[name], norm, log[name], source, updates
        )
        snapshot = torch.load(checked(bind), map_location="cpu", weights_only=True)
        clone = head.Selector()
        clone.load_state_dict(snapshot["ema"])
        assert snapshot["step"] == updates and snapshot["mode"] == name
        for k, v in averages[name].state_dict().items():
            torch.testing.assert_close(v.cpu(), clone.state_dict()[k], rtol=0, atol=0)
        results[name] = bind
    write_json(
        root / "result.json",
        {
            "driver": reference(Path(__file__)),
            "head": reference(head.__file__),
            "source": source,
            "updates": updates,
            "batch": min(total, BATCH),
            "sources": total,
            "native_role_examples": 3 * total,
            "optimizer_source_visits": min(total, BATCH) * updates,
            "checkpoints": results,
            "seconds": monotonic() - t,
            "ema_decay": EMA,
            "learning_rate": LR,
            "seed": SEED,
            "logs": log,
            "weights_used_in_evaluation": "EMA",
        },
    )


if __name__ == "__main__":
    main(sys.argv[1])
