"""Compare delivery policies at the same measured fine response."""

from pathlib import Path
import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_selector import OUT, values, score


if __name__ == "__main__":
    source = reference(OUT / "evaluate-transfer.json")
    d = read_json(checked(source))
    rows = d["rows"]
    result = d["summary"]["scores"]
    target = result["spatial locked"]["response_pp"] - result["nominal"]["response_pp"]
    response = {"spatial": ("spatial", tuple(d["policy"]["arms"]["spatial"]["locked"]["dose"]))}
    for variant, label in (
        ("heuristic", "heuristic"),
        ("shuffled", "shuffled locked"),
        ("swapped", "swapped locked"),
    ):
        other = result[label]["response_pp"] - result["nominal"]["response_pp"]
        q = target / other
        scale = (1.0, 1.0) if label == "heuristic" else response["spatial"][1]
        response[variant] = (variant, tuple(q * v for v in scale))
    cells = {k: values(rows, *t) for k, t in response.items()}
    out = {k: score.evaluate(v) for k, v in cells.items()}
    rng = np.random.default_rng(202611200902)
    n = len(rows)
    index = rng.integers(n, size=(12000, n))
    readings = {
        k: {m: np.sqrt(np.mean(x[m][index] ** 2, axis=1)) for m in score.LIMITS}
        for k, x in cells.items()
    }
    aligned = {
        k: {
            m: [
                out["spatial"][m] - out[k][m],
                *np.quantile(readings["spatial"][m] - x[m], (0.025, 0.975)).tolist(),
            ]
            for m in x
        }
        for k, x in readings.items()
    }
    print(out, aligned, flush=True)
    write_json(
        OUT / "equal-response.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "choices": response,
            "scores": out,
            "aligned_minus_other_DN16": aligned,
        },
    )
