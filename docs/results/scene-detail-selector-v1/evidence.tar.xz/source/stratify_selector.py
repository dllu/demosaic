"""Score the fainter half by exact target energy and verify the context interventions."""

from pathlib import Path
from statistics import median

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_selector import OUT, summary


def rms(x):
    return float(np.sqrt(np.mean(x * x, dtype=float)))


if __name__ == "__main__":
    source = reference(OUT / "evaluate-transfer.json")
    final = read_json(checked(source))
    features = reference(OUT / "review-features.json")
    case = read_json(checked(features))["groups"]["transfer"]["cases"]
    sampled = sorted(final["rows"], key=lambda r: r["scores"]["nominal"]["truth"])
    middle = len(sampled) // 2
    results = {
        k: summary(v, final["policy"])
        for k, v in zip(("fainter", "stronger"), (sampled[:middle], sampled[middle:]), strict=True)
    }
    ctx = []
    for row in final["rows"]:
        src = case[row["id"]]["features"]
        with np.load(checked(src), allow_pickle=False) as f:
            ctx.append((row["id"], f["scene"], f["pooled"]))
    observed = []
    for i, (name, scene, pooled) in enumerate(ctx):
        foreign = ctx[(i + len(ctx) // 2) % len(ctx)][1]
        roll = np.roll(scene, (scene.shape[0] // 2, scene.shape[1] // 2), axis=(0, 1))
        observed.append(
            {
                "id": name,
                "from_pool": rms(scene - pooled[None, None, :]),
                "rolled_change": rms(scene - roll),
                "other_photo_change": rms(scene - foreign),
            }
        )
    stats = {
        k: median(x[k] for x in observed)
        for k in ("from_pool", "rolled_change", "other_photo_change")
    }
    write_json(
        OUT / "strata.json",
        {
            "driver": reference(Path(__file__)),
            "source": source,
            "features": features,
            "exact_signal_order": [r["id"] for r in sampled],
            "scores": results,
            "context_rows": observed,
            "context_median_RMS": stats,
        },
    )
    print(
        {
            k: {
                m: v["scores"][m]
                for m in (
                    "nominal",
                    "heuristic",
                    "local locked",
                    "spatial locked",
                    "shuffled locked",
                    "swapped locked",
                )
            }
            for k, v in results.items()
        },
        flush=True,
    )
