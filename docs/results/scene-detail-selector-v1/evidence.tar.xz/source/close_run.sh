#!/bin/bash
set -euo pipefail

collection_pid=$1
study=/mnt/external/demosaic/scene-detail-selector-v1
driver=.cache/experiments/scene-detail-selector-v1
export PYTHONPATH=scripts OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
test "$(tr '\0' ' ' < /proc/"$collection_pid"/cmdline)" = ".venv/bin/python $driver/resume_shared_collection.py "
while kill -0 "$collection_pid" 2>/dev/null; do sleep 4; done
test -s "$study/training/shared-collection.json"
test -s "$study/training/completed.json"
.venv/bin/python "$driver/train_selector.py" training > "$study/fit-training.log" 2>&1
.venv/bin/python "$driver/evaluate_selector.py" calibration > "$study/evaluate-calibration.log" 2>&1
.venv/bin/python "$driver/evaluate_selector.py" transfer > "$study/evaluate-transfer.log" 2>&1
for group in exact camera wires; do
  .venv/bin/python "$driver/review_selector.py" "$group" > "$study/review-$group.log" 2>&1
done
