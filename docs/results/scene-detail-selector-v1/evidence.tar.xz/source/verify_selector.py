"""Check the exterior mask, bounded synthesis and exact metric plumbing."""

from pathlib import Path
import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from collect_training import capture
from detail_selector import OUT, scene_without_query, block_pixels, gram
from evaluate_selector import Cases, load_heads, evaluate_case
from review_selector import correction, wire_scorer
from train_selector import delta


def check():
    rng = np.random.default_rng(171)
    plan = reference(OUT / "preflight/plan.json")
    cases = read_json(checked(plan))["samples"]
    ob, raw, noise, box, note = capture(cases[0], 0)
    x, y, w, h = (v // 2 for v in box)
    rw = raw.clone()
    a, b = max(0, x - 8), min(x + w + 8, rw.shape[-1])
    c, d = max(0, y - 8), min(y + h + 8, rw.shape[-2])
    rw[:, c:d, a:b] = torch.from_numpy(rng.uniform(0, 1, size=(4, d - c, b - a)).astype(np.float32))
    np.testing.assert_array_equal(scene_without_query(raw, box), scene_without_query(rw, box))
    far_y = raw.shape[-2] - 1 if c <= raw.shape[-2] // 2 else 0
    far_x = raw.shape[-1] - 1 if a <= raw.shape[-1] // 2 else 0
    rw[:, far_y, far_x] += 0.12
    assert not torch.equal(scene_without_query(raw, box), scene_without_query(rw, box))
    flat = ob["target"][2, :, 90:166, 90:166]
    assert np.ptp(flat, axis=(-2, -1)).max() < 1e-7

    signal = rng.normal(size=(2, 3, 64, 96)).astype(np.float32) / 65535
    base = rng.normal(size=(2, 64, 96)).astype(np.float32) / 65535
    linear, cov, _ = gram(base, signal)
    g = rng.uniform(0, 1, size=linear.shape).astype(np.float32)
    predicted = delta(torch.from_numpy(g), torch.from_numpy(linear), torch.from_numpy(cov)).numpy()
    change = (np.moveaxis(g, -1, 1)[..., None, None] * block_pixels(signal * 65535)).sum(axis=1)
    observed = block_pixels(base * 65535)
    exact = np.mean((observed + change) ** 2 - observed**2, axis=(-2, -1))
    np.testing.assert_allclose(exact, predicted, rtol=1e-5, atol=1e-6)

    fit, nets = load_heads("preflight")
    prep = Cases("calibration")
    example = next(iter(prep))
    record = evaluate_case(example, nets, example[3]["scene"], prep.heuristic)
    assert all(np.isfinite(x["flat"]).all() for x in record["scores"].values())
    wires = Cases("wires")
    example_wire = next(iter(wires))
    policy = {"arms": {k: {"locked": {"dose": [0.4, 0.5]}} for k in ("local", "pooled", "spatial")}}
    images, _ = correction(example_wire, nets, policy, wires.heuristic)
    bound, metric = wire_scorer()
    actual = metric(example_wire[1], example_wire[0]["fixture"]["geometry"])(images["spatial"])
    assert all(np.isfinite(v) for v in actual.values())
    return {
        "mask_and_halo_bit_exact": True,
        "exterior_change_visible": True,
        "flat_core_verified": True,
        "station_energy_max_delta": float(np.max(abs(exact - predicted))),
        "feature_binding": prep.binding,
        "preflight": fit,
        "photo_smoke": record["id"],
        "wire_smoke": example_wire[0]["id"],
        "wire_metric": bound,
        "wire_stats": actual,
        "fixture_plan": plan,
    }


if __name__ == "__main__":
    torch.set_num_threads(2)
    report = check()
    print(report, flush=True)
    write_json(OUT / "audit.json", {"driver": reference(Path(__file__)), **report})
