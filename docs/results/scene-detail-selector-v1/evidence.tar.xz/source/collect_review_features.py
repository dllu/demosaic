"""Encode the registered exterior once per held photo or camera query."""

from itertools import groupby
from pathlib import Path
from time import monotonic
import sys

import numpy as np
import torch

from demosaic.cfa import color_indices
from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.io import read_raw
import detail_selector as model
from collect_training import load_model
from capture import OUT as EARLIER
from mild_score import paired_items

OUT = model.OUT


def source_groups(group):
    return EARLIER / f"mild-capture-{group}.json"


@torch.inference_mode()
def main():
    torch.set_num_threads(2)
    plan = reference(EARLIER / "plan.json")
    p = read_json(checked(plan))
    model_ = load_model(p["checkpoint"])
    root = OUT / "review-features"
    root.mkdir(exist_ok=True)
    start = monotonic()
    all_ = {}
    for role in ("calibration", "transfer", "wires", "camera"):
        output = {}
        group = list(paired_items(role))
        for frame, subset in groupby(group, key=lambda r: r[0].get("raw", {}).get("path")):
            entire = None
            if frame:
                raw, profile = read_raw(frame)
                h, w = (2 * (v // 2) for v in raw.shape)
                entire = np.stack([raw[i // 2 : h : 2, i % 2 : w : 2] for i in range(4)])
                cfa = color_indices(profile.pattern).numpy()
                del raw
            for row, data, pred, _ in subset:
                fp = root / f"{role}-{row['id']}.npz"
                if role == "camera":
                    data = {
                        k: (v[0] if k in ("colors", "wb", "matrix") else v) for k, v in data.items()
                    }
                    x, y, w, h = row["sensor_box"]
                    assert entire is not None
                    np.testing.assert_array_equal(cfa, data["colors"])
                    np.testing.assert_array_equal(
                        data["packed"][0], entire[..., y // 2 : (y + h) // 2, x // 2 : (x + w) // 2]
                    )
                    box = tuple(row["sensor_box"])
                    scene = entire
                else:
                    scene = data["scene_packed"]
                    box = tuple(row["box"])
                if not fp.is_file():
                    spatial, pooled = model.scene_features(
                        model_, scene, *(data[k] for k in ("colors", "wb", "matrix")), box
                    )
                    nominal, items, _ = model.ingredients(pred, data)
                    features, support = model.local_features(
                        data["packed"], nominal, items, data["colors"], row["profile"]
                    )
                    with fp.open("xb") as stream:
                        np.savez(
                            stream, features=features, support=support, scene=spatial, pooled=pooled
                        )
                output[row["id"]] = {"features": reference(fp), "input": row["input"], "query": box}
                if len(output) % 8 == 0:
                    print(role, len(output), round(monotonic() - start, 2), flush=True)
            del entire
        all_[role] = {"mild_capture": reference(source_groups(role)), "cases": output}
    write_json(
        OUT / "review-features.json",
        {
            "driver": reference(Path(__file__)),
            "head": reference(model.__file__),
            "parent": p["checkpoint"],
            "scope": plan,
            "groups": all_,
            "seconds": monotonic() - start,
        },
    )


if __name__ == "__main__":
    main()
