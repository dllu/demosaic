"""Measure target-assisted headroom of the mild and wider correction fields."""

from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import detail_selector as head
from evaluate_selector import Cases, OUT, ideal, values, deltas
import mild_score as fixed
import score


def run():
    torch.set_num_threads(2)
    cases = Cases("transfer")
    table = []
    for item, d, p, features, record in cases:
        row = {"id": item["id"], "targets": item["input"], "source": record, "scores": {}}
        b, t = [score.stats(v, d) for v in (p["nominal"], d["target"])]
        z = np.zeros((len(d["packed"]), 256, 256), dtype=float)
        row["scores"]["nominal"] = fixed.terms(t, b, fixed.coefficients(z), fixed.coefficients(z))
        with np.load(checked(record["initial"]), allow_pickle=False) as f:
            wide = {k: f[k] for k in ("crisp", "nominal", "smooth")}
        for scope, panels in (("mild", p), ("wide", wide)):
            a = ideal(d, panels, features, item["profile"])
            _, things, _ = head.ingredients(panels, d)
            s = deltas(things, a)
            row["scores"][scope] = fixed.terms(
                t, b, fixed.coefficients(s[:, 0]), fixed.coefficients(s[:, 1])
            )
        table.append(row)
    raw = {name: values(table, name, (1, 1)) for name in ("nominal", "mild", "wide")}
    results = {k: score.evaluate(r) for k, r in raw.items()}
    print(results, flush=True)
    write_json(
        OUT / "basis-headroom.json",
        {
            "driver": reference(Path(__file__)),
            "features": cases.binding,
            "rows": table,
            "summary": results,
            "scope": "Exact-target diagnostic. Identical positive cross-green guard plus 24 DN16 local cap.",
        },
    )


if __name__ == "__main__":
    run()
