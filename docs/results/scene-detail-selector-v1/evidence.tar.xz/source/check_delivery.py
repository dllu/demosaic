"""Recompute locked RGB metric values after explicit pixel delivery."""

from pathlib import Path

import numpy as np
import torch

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from evaluate_selector import Cases, OUT, load_heads, values
from review_selector import correction
import score


def direct(result, target, data):
    pred, truth = [score.stats(v, data)[..., score.BANDS["fine"]] for v in (result, target)]
    a = (pred[0] - pred[1]) - (truth[0] - truth[1])
    squares = lambda u: float(np.sqrt(np.sum(u * u) * score.SCALE))
    return {
        "flat": squares(pred[2] - truth[2]),
        "increment": squares(a),
        "present": squares(pred[0] - truth[0]),
    }


def main():
    fit, nets = load_heads()
    eval_ = reference(OUT / "evaluate-transfer.json")
    receipt = read_json(checked(eval_))
    assert receipt["fit"] == fit
    score_rows = {r["id"]: r for r in receipt["rows"]}
    data = Cases("transfer")
    largest = 0.0
    done = []
    for i, case in enumerate(data):
        if i % 4:
            continue
        item, m, p, f, _ = case
        touched, _ = correction(case, nets, receipt["policy"], data.heuristic)
        outputs = {}
        for k in ("nominal", "local", "pooled", "spatial", "shuffled", "heuristic"):
            dose = (1, 1)
            if k in nets or k == "shuffled":
                dose = receipt["policy"]["arms"][k if k != "shuffled" else "spatial"]["locked"][
                    "dose"
                ]
            actual = direct(touched[k], m["target"], m)
            summary = values([score_rows[item["id"]]], k, dose)
            error = max(abs(actual[key] - summary[key][0]) for key in actual)
            assert error < 0.002, (k, item["id"], error)
            largest = max(largest, float(error))
            outputs[k] = float(error)
        done.append({"id": item["id"], "absolute_RMS_error_DN16": outputs})
    write_json(
        OUT / "delivery-audit.json",
        {
            "driver": reference(Path(__file__)),
            "fit": fit,
            "evaluation": eval_,
            "rows": done,
            "maximum_error_DN16": largest,
        },
    )
    print(len(done), "duplicated delivery views", largest, flush=True)


if __name__ == "__main__":
    torch.set_num_threads(2)
    main()
