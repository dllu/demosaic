"""Measure an exact-target response frontier after the actual delivery interpolation."""

from pathlib import Path
from itertools import product
from time import monotonic

import numpy as np
from scipy.optimize import minimize
import torch
from torch.nn.functional import interpolate

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
import detail_selector as head
from evaluate_selector import Cases, OUT, score, fixed

TARGET_PULL = (0.0, 0.05, 0.1, 0.2, 0.4, 0.8, 1.5, 3.0, 6.0)
PRESENT_WEIGHT = (0.15, 0.6, 1.8)


def basis():
    tiles = torch.eye(16).reshape(1, 16, 4, 4)
    tiles = torch.nn.functional.pad(tiles, (2, 2, 2, 2))
    return interpolate(tiles, size=(256, 256), mode="bilinear", align_corners=False)[0].numpy()


def prep(meta, pred, card):
    cursor = basis()
    _, terms, _ = head.ingredients(pred, meta)
    matrix = []
    lim = []
    raw_support = card["support"][:, 2:6, 2:6].numpy()
    for t, u in zip(terms, raw_support, strict=True):
        design = (t[:, None] * cursor).reshape(32, 256, 256)
        bands = (
            fixed.coefficients(design)[..., score.BANDS["fine"]].reshape(32, -1).astype(float)
            * 65535
        )
        matrix.append(bands)
        lim.append(np.r_[u.ravel(), np.ones(16)])
    signal, truth = [
        score.stats(x, meta)[..., score.BANDS["fine"]].reshape(3, -1) * 65535
        for x in (pred["nominal"], meta["target"])
    ]
    return matrix, lim, signal - truth, truth[0] - truth[1]


def pull(error, gram, linear, bounds):
    def differentiable(v):
        energy = gram @ v
        return float(v @ linear * 2 + v @ energy), 2 * (energy + linear)

    x = np.zeros(len(bounds))
    solved = minimize(
        differentiable,
        x,
        jac=True,
        bounds=list(zip(x, bounds, strict=True)),
        method="L-BFGS-B",
        options={"maxiter": 140, "ftol": 2e-13, "gtol": 1e-8},
    )
    assert solved.x.shape == x.shape and np.isfinite(solved.x).all()
    return solved.x


def diagnostics(pre):
    matrix, limits, error, delta = pre
    g0, g1, g2 = matrix
    pair = np.concatenate((g0, -g1), axis=0)
    pvector = pair @ delta / (96**2)
    rawe = error[0] - error[1]
    X = (pair @ pair.T) / (96**2)
    Y = np.zeros_like(X)
    Y[:32, :32] = (g0 @ g0.T) / (96**2)
    bb = pair @ rawe / (96**2)
    yy = np.r_[g0 @ error[0] / (96**2), np.zeros(32)]
    u = pull(error[2], g2 @ g2.T / (96**2), g2 @ error[2] / (96**2), limits[2])
    f = float(np.mean((error[2] + u @ g2) ** 2) * (error.shape[-1] / 96**2))
    bounds = np.concatenate(limits[:2])
    absolute = np.sum(delta**2)

    def score(v):
        actual = rawe + v @ pair
        n = e = 96**2
        return {
            "increment_energy": float(actual @ actual / n),
            "present_energy": float(np.sum((error[0] + v[:32] @ g0) ** 2) / e),
            "projection": float((delta + actual) @ delta),
            "true": float(absolute),
            "flat_energy": f,
        }

    base = score(np.zeros(64)) | {"flat_energy": float(np.sum(error[2] ** 2) / 96**2)}
    all_ = {}
    for w, k in product(PRESENT_WEIGHT, TARGET_PULL):
        gains = pull(rawe, X + Y * w, bb + yy * w - k * pvector, np.asarray(bounds))
        all_[f"{w:g}/{k:g}"] = score(gains)
    return base, all_


def aggregate(items):
    return {
        **{
            k: float(np.sqrt(np.mean([v[k] for v in items])))
            for k in ("flat_energy", "increment_energy", "present_energy")
        },
        "response_pp": 100 * sum(v["projection"] for v in items) / sum(v["true"] for v in items),
    }


def run():
    torch.set_num_threads(2)
    data = Cases("transfer")
    start = monotonic()
    rows = []
    for item, meta, pred, feat, where in data:
        baseline, table = diagnostics(prep(meta, pred, feat))
        rows.append({"id": item["id"], "base": baseline, "options": table, "input": where})
    before = aggregate([r["base"] for r in rows])
    report = {k: aggregate([r["options"][k] for r in rows]) for k in rows[0]["options"]}
    limits = {f"{k}_energy": v for k, v in score.LIMITS.items()}
    chosen = max(
        (r for r in report if all(report[r][k] <= before[k] + v for k, v in limits.items())),
        key=lambda r: report[r]["response_pp"],
    )
    print(before, chosen, report[chosen], flush=True)
    write_json(
        OUT / "response-frontier.json",
        {
            "driver": reference(Path(__file__)),
            "features": data.binding,
            "rows": rows,
            "baseline": before,
            "summary": report,
            "example_at_transfer_limits": chosen,
            "seconds": monotonic() - start,
            "scope": "Target-assisted response frontier for measured 0.90x/1.15x candidates and their actual bilinear delivery. Diagnostic, selects a point retrospectively.",
        },
    )


if __name__ == "__main__":
    run()
