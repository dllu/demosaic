"""Check if held samples distinguish narrow profiles from soft and crossed waves."""
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

from bandlimit import ROOT,COMPOSE,CHECKED
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.prediction_archive import fingerprint
from demosaic.scene_data import observe_scene,sample_scene_recipe,scene_crop_boxes
from demosaic.scene_training_data import scene_seed
from model_delivery import select

sys.path.insert(0,str(ROOT.parent/"weak-edge-distill-v1"))
from edge_data import decode

SEED=179960140213
KINDS=("smooth","crossing","narrow","flat")
NOISE={"iso400":{"shot":8e-5,"read":2.56e-8,"exposure":.33},
       "iso6400":{"shot":.00128,"read":6.5536e-6,"exposure":.33}}


def experiment():
    source=reference(CHECKED/"plan.json")
    exclude=reference(COMPOSE/"plan.json")
    p=read_json(checked(source))
    q=read_json(checked(exclude))
    excluded={x["source"]["id"]for x in q["sources"]}
    avail=[row for row in p["sources"]if row["source"]["id"]not in excluded]
    avail.sort(key=lambda r:hashlib.sha256(f"{SEED}/{r['source']['id']}".encode()).hexdigest())
    assert len(avail)>=16
    rows=[]
    for i,s in enumerate(avail[:16]):
        src=s["source"]
        box,=scene_crop_boxes(src["shape"][:2],patch_size=256,count=1,seed=scene_seed(SEED,i,"width region"))
        rng=np.random.default_rng(scene_seed(SEED,i,"physical width"))
        slope=rng.uniform(.48,.83)
        t=rng.uniform(.55,.84)
        a,b=rng.uniform(.078,.123,2)
        geometry=[[a*math.cos(slope),a*math.sin(slope),0.],[b*math.cos(t),-b*math.sin(t),0.]]
        rows.append({"index":i,"source":src,"camera":s["camera"],"geometry":geometry,
                     "phase":rng.uniform(-math.pi,math.pi,2).tolist(),"wave_strength":[.012,rng.uniform(.004,.009)],
                     "wire_width_px_fraction":rng.uniform(.087,.139),"box":box,
                     "contrast_step":i%2==1,"seeds":{a:{k:scene_seed(SEED,i,f"{a}/{k}")for k in KINDS}for a in NOISE}})
    write_json(ROOT/"width-plan.json",{"driver":reference(__file__),"source":source,"excluded_prior_replay":exclude,
               "scope":"16 disjoint photo backgrounds from the 24-draw replay and new camera draws. Candidate direction is supplied by the generator for a conditional waveform test.",
               "rows":rows,"noise":NOISE,"kinds":KINDS})


def targets(photo,row):
    axis=torch.arange(256)-127.5
    y,x=torch.meshgrid(axis,axis,indexing="ij")
    base=.068+.49*F.avg_pool2d(photo[None],11,stride=1,padding=5,count_include_pad=False)[0]
    if row["contrast_step"]:
        base=base+torch.tensor([.064,.088,.118])[:,None,None]*torch.sigmoid((.43*x+y-16)/1.6)
    phases=[2*math.pi*(x*freq[0]+y*freq[1])+phase for freq,phase in zip(row["geometry"],row["phase"],strict=True)]
    a,b=phases
    a0,b0=row["wave_strength"]
    texture=a0*a.cos()+b0*b.cos()
    curved=torch.zeros_like(x)
    # The Gaussian periodic line profile and sinusoid have identical
    # signed fundamental amplitude. There is no DC term in either.
    sig=row["wire_width_px_fraction"]
    for n in range(2,9):
        gain=math.exp(-2*math.pi**2*sig**2*(n*n-1))
        curved+=gain*(a0*(n*a).cos()+b0*(n*b).cos())
    return base+texture,base+texture+.62*a0*a.cos()*b.cos(),base+texture+curved,torch.full_like(base,0.16)


def run():
    torch.set_num_threads(2)
    bind=reference(ROOT/"width-plan.json")
    plan=read_json(checked(bind))
    collected=[]
    for row in plan["rows"]:
        exact=targets(decode(row["source"],row["box"]),row)
        results={}
        for name,profile in NOISE.items():
            camera=replace(sample_scene_recipe(SEED),**(row["camera"]|profile))
            for kind,target in zip(KINDS,exact,strict=True):
                assert 0<float(target.min())<float(target.max())<1 or kind=="flat"
                value=observe_scene(target,replace(camera,noise_seed=row["seeds"][name][kind]))
                outcome=select(value.packed.numpy(),value.colors.numpy(),profile,row["geometry"])
                records=outcome["modes"]["locked"]
                fundamental=all(v["pooled"]>=2.75 and min(v["scores"])>0 for v in outcome["fundamentals"])
                results[name+"/"+kind]={"input":fingerprint(value.packed.numpy()),"target":fingerprint(value.target.numpy()),
                    "choice":outcome,"fundamentals_pass":fundamental,
                    "narrow_allowed":any(v["accepted"] and v["name"].startswith("second-") for v in records)}
        collected.append({"index":row["index"],"width":row["wire_width_px_fraction"],"results":results})
        print(row["index"],flush=True)
    summary={}
    for profile in NOISE:
        for kind in KINDS:
            r=[x["results"][profile+"/"+kind]for x in collected]
            summary[profile+"/"+kind]={"count":len(r),"fundamentals":sum(p["fundamentals_pass"]for p in r),
                                      "narrow_allowed":sum(p["narrow_allowed"]for p in r)}
    write_json(ROOT/"width-probe.json",{"driver":reference(__file__),"plan":bind,"rows":collected,"summary":summary})


if __name__=="__main__":
    experiment()
    run()
