"""Publish the checked-native replay and retain its waveform evidence."""
from pathlib import Path
import shutil
import tarfile

import numpy as np
from PIL import Image

from bandlimit import ROOT
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

IMAGES=Path("docs/images/query-donor-bandlimit-v1")
RESULTS=Path("docs/results/query-donor-bandlimit-v1")


def picture(row,label,comment):
    image=row["image"]
    source=checked(image)
    path=IMAGES/label/source.name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,path)
    assert reference(path)["sha256"]==image["sha256"]
    with Image.open(path)as png:
        if "columns" in row:
            assert png.size==(len(row["columns"])*160,160)
        else:
            for p in row["panels"]:
                x,y,w,h=p["png_xywh"]
                assert w==h==160 and x+w<=png.width and y+h<=png.height
        png.verify()
    return row|{"image":{"path":str(path),"sha256":image["sha256"]},"actual_viewing":comment}


def reductions(results):
    records={}
    for key,cohort in results.items():
        index="scores" if key=="photo" else "metrics"
        summary={}
        for name,rows in (("all",cohort["rows"]),("active",[r for r in cohort["rows"]if r["active"]])):
            totals={}
            for model in ("parent","legacy","fundamental","checked"):
                fields=set.intersection(*(set(r[index][model]) for r in rows))
                totals[model]={k:float(np.mean([r[index][model][k]for r in rows]))for k in sorted(fields)}
            summary[name]={"count":len(rows),"means":totals}
        records[key]=summary
    return records


def main():
    real=reference(ROOT/"standing/manifest.json")
    scope=read_json(checked(real))
    audit=read_json(ROOT/"verification.json")
    replay=read_json(checked(audit["replay"]))
    shape=read_json(checked(audit["width_probe"]))
    local=scope["rows"]
    assert all((row["metrics"]["checked"]["RGB_RMS_to_previous_DN16"]>0)==row["id"].endswith("mesh-left")for row in local)
    assert scope["checkpoint"]==replay["photo"]["checkpoint"]
    models={}
    for cohort in ("photo","legacy_wire"):
        data=replay[cohort]
        output=[]
        for group in data["native"]:
            category=str(group.get("case",group.get("index")))
            if cohort=="photo":
                note="The second direction is visible and appears softer than the earlier donor profile. The exact target has stronger crossing modulation."
            elif category.startswith("iso400"):
                note="Restricting the restoration softens the weak profile. Some of the sharper wire response is visible in the old fit."
            else:
                note="The original donor guard abstains. Both reconstructions match the parent. The faint crossing direction remains weak."
            output.append(group|{"boards":[picture(b,"exact",note)for b in group["boards"]]})
        models[cohort]=data|{"native":output}
    boards=[]
    for row in local:
        name=row["id"]
        if name.endswith("mesh-left"):
            note="Both directions remain faintly visible. Crossings are softer than in the previous donor result. The difference with equal-RMS attenuation is subtle."
        elif "sky" in name:
            note="Sky remains smooth and pixel-identical."
        elif "fence" in name or name.endswith("mesh-right"):
            note="The preceding checked lattice is reproduced. Fine cab crossings remain uneven."
        else:
            note="The previous crop is reproduced. Finer scene details remain soft."
        boards.append(picture(row,"standing",note))
    controls=[picture(r,"equal-strength","At comparable correction RMS, the band-limited grid is less sharp. The two reference crops show substantially clearer crossings.")for r in audit["strength_matched_camera"]]
    assert sum(len(r["boards"])for v in models.values()for r in v["native"])==8
    assert len(boards)==8 and len(controls)==2
    manifest=IMAGES/"manifest.json"
    write_json(manifest,{"exact":models,"standing":scope|{"rows":boards},"standing_equal_strength":controls,
                         "actual_native_viewing_complete":True})
    RESULTS.mkdir(parents=True,exist_ok=True)
    archive=RESULTS/"evidence.tar.xz"
    with tarfile.open(archive,"x:xz")as f:
        for rule in ("*.py","*.json","*.log","standing/manifest.json"):
            for path in sorted(ROOT.glob(rule)):
                f.add(path,arcname=path.relative_to(ROOT))
    write_json(RESULTS/"publication.json",{"study":"query-donor-bandlimit-v1","inference_component_only":True,
       "broad_quality_complete":False,"numerical_evaluation_complete":True,"actual_native_viewing_complete":True,
       "parent_checkpoints":{"photographic":replay["photo"]["checkpoint"],"wire_replay":replay["legacy_wire"]["checkpoint"]},
       "manifest":reference(manifest),"standing":real,"shape_counts":shape["summary"],
       "audit":audit,"replays":reductions({k:replay[k]for k in ("photo","legacy_wire")}),"archive":reference(archive)})


if __name__=="__main__":
    main()
