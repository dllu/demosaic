"""Replay the same donor outputs and exact targets under spectral restriction."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from bandlimit import ROOT,COMPOSE,limit,isolate
from demosaic.archive_metrics import display,linear_rgb
from demosaic.cfa import malvar
from demosaic.experiments.artifacts import checked,read_json,reference,write_json

PANEL=ROOT.parent/"local-mesh-stable-v1"
MODES=("parent","legacy","fundamental","checked")
ROI=np.s_[...,48:208,48:208]
CORE=np.s_[...,64:192,64:192]
PACK=np.s_[...,64:192,64:192]
NATIVE=ROOT/"native"


def rms(x):
    return float(np.sqrt(np.mean(x*x))*65535)


def score_linear(models,target,transform,center,mask=None,present=0,absent=1):
    def luminance(value):
        return np.einsum("c,bchw->bhw",[.2126,.7152,.0722],linear_rgb(value,transform))[center]
    gt=luminance(target)
    truth=gt[present]-gt[absent]
    old=luminance(models["parent"])
    table={}
    for tag,array in models.items():
        p=luminance(array)
        delta=p[present]-p[absent]
        errors={
            "present_RMS":rms((p[present]-gt[present])),
            "increment_RMS":rms(delta-truth),
            "aligned_response":float(100*np.sum(delta*truth)/np.sum(truth**2)),
            "quiet_added_RMS":rms(p[-1]-old[-1]),
            "absent_added_RMS":rms(p[absent]-old[absent]),
        }
        if mask is not None and mask.any():
            errors["known_gap_RMS"]=rms((p[present]-old[present])[mask])
        table[tag]=errors
    return table


def native(name,models,noisy,target,wb,matrix,role,roi,exposure,contrast=1):
    transform={k:v[role:role+1]for k,v in {"wb":wb,"matrix":matrix}.items()}
    rgb={k:display(v[role:role+1][roi],transform,exposure=exposure)[0].transpose(1,2,0)
          for k,v in (models|{"noisy":noisy,"target":target}).items()}
    if contrast!=1:
        level=rgb["target"].mean((0,1))
        rgb={k:np.clip(level+contrast*(v-level),0,1)for k,v in rgb.items()}
    saved=[]
    for kind,items in (("triplet",("noisy","checked","target")),("comparison",("noisy",*MODES,"target"))):
        path=NATIVE/f"{name}-{kind}.png"
        png=np.concatenate([np.rint(rgb[k]*255).astype(np.uint8)for k in items],axis=1)
        Image.fromarray(png).save(path,optimize=True)
        saved.append({"image":reference(path),"columns":items})
    return saved


def recovered_photo_panel():
    source=reference(COMPOSE/"restoration.json")
    restore=read_json(checked(source))
    material=read_json(checked(restore["sources"]))
    plan=read_json(checked(material["plan"]))
    rows=[]
    renders=[]
    target_codes=set()
    for r,echo in zip(restore["rows"],plan["sources"],strict=True):
        with np.load(checked(r["input"]),allow_pickle=False)as f:
            packed=f["packed"][PACK]
            cfa,wb,mat=(f[k]for k in ("colors","wb","matrix"))
            truth=f["target"][...,128:384,128:384]
            gap=f["region"][CORE]==0
        with np.load(checked(r["output"]),allow_pickle=False)as f:
            bases,donors,orig=(f[k]for k in ("local","donor","composed"))
        for repeat in range(2):
            fields={k:np.empty_like(bases[repeat])for k in ("fundamental","checked")}
            notes=[]
            for role in range(4):
                state=r["decisions"][repeat*4+role]["matching"]
                one,two,info=limit(bases[repeat,role],donors[repeat,role],packed[repeat,role],cfa[repeat,role],
                                   wb[repeat,role],mat[repeat,role],plan["profile"],state)
                fields["fundamental"][role]=one
                fields["checked"][role]=two
                notes.append(info)
            models={"parent":bases[repeat],"legacy":orig[repeat]}|fields
            results=score_linear(models,truth[repeat],{"wb":wb[repeat],"matrix":mat[repeat]},CORE,gap)
            rows.append({"index":r["index"],"repeat":repeat,"active":bool(notes[0]),"caption":echo["layout"]["condition"],
                         "scores":results,"energies":notes})
            if notes[0] and r["index"] not in target_codes:
                target_codes.add(r["index"])
                noisy=malvar(torch.from_numpy(packed[repeat]),torch.from_numpy(cfa[repeat])).numpy()
                renders.append({"source":echo["source"],"source_box":echo["box"],"repeat":repeat,"index":r["index"],
                      "input":r["input"],"ROI":[48,48,160,160],"checkpoint":restore["checkpoint"],
                      "CFA":echo["camera"]["pattern"],"noise":plan["profile"],"exposure":2,
                      "boards":native(f"photo-{r['index']:03d}-{repeat}",models,noisy,truth[repeat],wb[repeat],mat[repeat],
                                      0,ROI,2)})
    assert len(rows)==24 and len(renders)==2
    return {"source":source,"checkpoint":restore["checkpoint"],"rows":rows,"native":renders}


def narrow_wire_panel():
    source=reference(PANEL/"result.json")
    original=read_json(checked(source))
    plan=read_json(checked(original["plan"]))
    rows=[]
    renders=[]
    for record in original["cases"]:
        card=read_json(checked(record))
        if not card["retained"]:
            continue
        info=card["retained"]
        profile=plan["noise"][card["profile"]]
        with np.load(checked(info),allow_pickle=False)as f:
            packed=f["packed"][...,16:144,16:144]
            cfa,wb,mat=(f[k]for k in ("colors","wb","matrix"))
            truth=f["target"]
            parent=f["parent"]
            exact_crop=np.s_[...,80:240,80:240]
            ripple=f["matching-anchored-median"]
            gap=f["support"][exact_crop]==0
        models={k:parent.copy()for k in MODES}
        geometry=[[*p,0.]for p in card["frequency_priors"]["matching"]]
        for role in range(3):
            local=parent[role,:,32:288,32:288]
            lifted=local.copy()
            lifted[ROI]+=ripple[role]
            models["legacy"][role][exact_crop]+=ripple[role]
            if not ripple[role].any():
                continue
            # Use the previously frozen exterior geometry for this replay and refit only
            # the signed phases and raw bands upstream of the same conservative filter.
            from model_delivery import select

            picked=select(packed[role],cfa[role],profile,geometry)
            state={"state":"donor-only","refined_result":picked}
            first,second,_=limit(local,lifted,packed[role],cfa[role],wb[role],mat[role],profile,state)
            models["fundamental"][role][exact_crop]=first[ROI]
            models["checked"][role][exact_crop]=second[ROI]
        stats=score_linear(models,truth,{"wb":wb,"matrix":mat},exact_crop,gap,present=1,absent=0)
        rows.append({"case":card["id"],"profile":card["profile"],"layout":card["layout"],"metrics":stats,
                     "active":bool(ripple[1].any()),"input":info})
        if card["g"]==110 and card["layout"]=="occluded":
            with np.load(checked(info),allow_pickle=False)as f:
                previews=malvar(torch.from_numpy(f["packed"]),torch.from_numpy(cfa)).numpy()
            renders.append({"case":card["id"],"checkpoint":plan["checkpoint"],"input":info,
                            "CFA":cfa[1].tolist(),"ROI":plan["ROI"],"noise":profile,"exposure":1,"contrast":8,
                            "boards":native(card["id"],models,previews,truth,wb,mat,1,exact_crop,1,8)})
    assert len(rows)==12 and len(renders)==2
    return {"source":source,"checkpoint":plan["checkpoint"],"rows":rows,"native":renders}


def main():
    torch.set_num_threads(2)
    NATIVE.mkdir()
    phot=recovered_photo_panel()
    wire=narrow_wire_panel()
    write_json(ROOT/"replay.json",{"driver":reference(__file__),"photo":phot,"legacy_wire":wire})
    print("photo",[(p["index"],p["repeat"])for p in phot["rows"]if p["active"]])
    print("wire",[p["case"]for p in wire["rows"]if p["active"]])


if __name__=="__main__":
    main()
