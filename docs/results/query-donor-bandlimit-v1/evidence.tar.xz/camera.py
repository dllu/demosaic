"""Inspect band-limited donor corrections on both standing GFX families."""
import sys
import numpy as np
from PIL import Image
import torch

from bandlimit import ROOT,COMPOSE,limit,SIGMA
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


@torch.inference_mode()
def run():
    torch.set_num_threads(2)
    previous=reference(COMPOSE/"standing/manifest.json")
    book=read_json(checked(previous))
    output=ROOT/"standing"
    output.mkdir()
    rows=[]
    for row in book["rows"]:
        x,y,w,h=row["box"]
        top=y//2
        left=x//2
        with np.load(checked(row["base_input"]),allow_pickle=False)as f:
            raw=f["packed"][0,:,top:top+h//2,left:left+w//2]
            cfa,wb,mat=(f[k][0]for k in ("colors","wb","matrix"))
        with np.load(checked(row["outputs"]),allow_pickle=False)as f:
            parent,donor,published=(f[k]for k in ("old","donor","composed"))
        only,new,facts=limit(parent,donor,raw,cfa,wb,mat,row["noise"],row["state"])
        if facts is None:
            np.testing.assert_array_equal(published,new)
        rx,ry,rw,rh=row["ROI"]
        roi=rx-x,ry-y,rw,rh
        with Image.open(checked(row["image"]))as f:
            previous_image=np.asarray(f.convert("RGB"))
        boards={p["name"]:previous_image[yy:yy+hh,xx:xx+ww]for p in row["panels"]
                for xx,yy,ww,hh in (p["png_xywh"],)}
        keys=("ISO6400 camera JPEG","Noisy (Malvar)","V120 EMA","Parent 100k EMA","With exterior and checked bands")
        panels=[(k,boards[k])for k in keys if k in boards]
        for name,model in (("Only supported fundamentals",only),("Fundamentals + checked bands",new)):
            clipped=np.rint(display_crop(torch.from_numpy(model[None]),torch.from_numpy(wb[None]),
                torch.from_numpy(mat[None]),roi,exposure=row["display_exposure"])*255).astype(np.uint8)
            panels.append((name,clipped))
        panels.extend((k,boards[k])for k in ("ISO100 AHD reference","ISO100 camera JPEG")if k in boards)
        image=native_png(output/(row["id"]+".png"),panels)
        bounds=np.s_[...,roi[1]:roi[1]+rh,roi[0]:roi[0]+rw]
        metrics={}
        for key,a in (("old",published),("fundamental",only),("checked",new)):
            metrics[key]={"RGB_RMS_to_input_DN16":float(np.sqrt(np.mean((a-parent)[bounds].astype(float)**2))*65535),
                          "RGB_RMS_to_previous_DN16":float(np.sqrt(np.mean((a-published)[bounds].astype(float)**2))*65535)}
        arrays=output/(row["id"]+".npz")
        np.savez(arrays,parent=parent,donor=donor,previous=published,fundamental=only,checked=new)
        rows.append({k:row[k]for k in ("id","base_input","ROI","box","noise","display_exposure")}|image|
          {"previous":row["image"],"linear":reference(arrays),"band_model":facts,"metrics":metrics})
        print(row["id"],metrics,flush=True)
    write_json(output/"manifest.json",{"driver":reference(__file__),"inputs":previous,"checkpoint":book["checkpoint"],
                                        "bandwidth_sigma":SIGMA,"rows":rows})


if __name__=="__main__":
    run()
