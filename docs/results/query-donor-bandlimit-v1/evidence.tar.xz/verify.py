"""Verify the spectral isolation and replay a conservative shape gate."""
import sys

import numpy as np
from PIL import Image
import torch

from bandlimit import ROOT,COMPOSE,SIGMA,isolate,limit
from demosaic.experiments.artifacts import checked,read_json,reference,write_json
from demosaic.reporting import display_crop
from replay import CORE,PACK,PANEL,ROI,score_linear,rms
from model_delivery import phases,select

sys.path.insert(0,str(ROOT.parent/"paired-luminance-detail-v1"))
from render import native_png


def analytic():
    v=np.arange(256)-127.5
    y,x=np.meshgrid(v,v,indexing="ij")
    geom=[[.117,.071,0.],[.088,-.072,0.]]
    a,b=phases(x.ravel(),y.ravel(),geom).T.reshape(2,256,256)
    amplitude=.7+.2*np.sin(2*np.pi*x/150)*np.cos(2*np.pi*y/140)
    truth=amplitude*(np.cos(a+.33)+.58*np.cos(b-.61))
    contaminant=(.43*np.cos(2*a+.12)+.29*np.cos(a-b-.42)+.38)
    filmed=np.stack((truth+contaminant,2*(truth+contaminant),.5*(truth+contaminant)))
    result=isolate(filmed,geom)
    center=np.s_[64:192,64:192]
    reference=np.stack((truth,2*truth,.5*truth))
    original=np.sqrt(np.mean((filmed-reference)[(slice(None),)+center]**2))
    final=np.sqrt(np.mean((result-reference)[(slice(None),)+center]**2))
    assert final < .10*original, (original,final)
    hard=np.stack((contaminant,contaminant,contaminant))
    leakage=np.sqrt(np.mean(isolate(hard,geom)[:,64:192,64:192]**2))
    assert leakage<1e-4, leakage
    return {"pre_filter_RMS":float(original),"post_filter_RMS":float(final),"isolated_nuisance_leakage":float(leakage)}


def shape(state):
    accepted=[t["name"]for t in state["modes"]["locked"]if t["accepted"]]
    return any(t.startswith("second-")for t in accepted),accepted


def exact_strength_and_route(replay):
    marks=read_json(checked(replay["photo"]["source"]))
    capture=read_json(checked(marks["sources"]))
    setup=read_json(checked(capture["plan"]))
    active=[r for r in replay["photo"]["rows"]if r["active"]]
    average=lambda kind: np.mean([q["scores"][kind]["aligned_response"]for q in active])
    parent,old,new=(average(k)for k in ("parent","legacy","checked"))
    multiplier=float((new-parent)/(old-parent))
    assert .80 < multiplier < 1
    comparison=[]
    for row in active:
        i,j=row["index"],row["repeat"]
        info=marks["rows"][i]
        state=info["decisions"][4*j]["matching"]
        choose,accepted=shape(state["refined_result"])
        with np.load(checked(info["input"]),allow_pickle=False)as inputs:
            true=inputs["target"][j,...,128:384,128:384]
            wb,mat=inputs["wb"][j],inputs["matrix"][j]
        with np.load(checked(info["output"]),allow_pickle=False)as f:
            parent=np.array(f["local"][j])
            old=np.array(f["composed"][j])
        control=parent+multiplier*(old-parent)
        scores=score_linear({"parent":parent,"equal_response_legacy":control},true,{"matrix":mat,"wb":wb},CORE)
        comparison.append({"index":i,"repeat":j,"old_retained":choose,"admitted":accepted,
                           "equal_response_legacy":scores["equal_response_legacy"],
                           "restricted":row["scores"]["checked"],"historical":row["scores"]["legacy"]})
    assert all(not o["old_retained"]for o in comparison)
    wire=[]
    original=read_json(checked(replay["legacy_wire"]["source"]))
    by_name={read_json(checked(k))["id"]:read_json(checked(k))for k in original["cases"]}
    noise=read_json(checked(original["plan"]))["noise"]
    for row in replay["legacy_wire"]["rows"]:
        if not row["active"]:
            continue
        actual=by_name[row["case"]]
        with np.load(checked(actual["retained"]),allow_pickle=False)as f:
            pixels=f["packed"][1,:,16:144,16:144]
            colors=f["colors"][1]
        geometry=[[*p,0.]for p in actual["frequency_priors"]["matching"]]
        state=select(pixels,colors,noise[row["profile"]],geometry)
        retain,labels=shape(state)
        wire.append({"case":row["case"],"retains_old_narrow":retain,"admitted":labels,
                     "before":row["metrics"]["legacy"],"restricted":row["metrics"]["checked"]})
    assert all(t["retains_old_narrow"]for t in wire)
    return {"diagnostic_strength_multiplier":multiplier,"matched_response_photo":comparison,"narrow_control":wire,
            "scope":"Development replays. The strength control matches the active photo draws' mean target projection, using exact targets only in this diagnostic."}


def render_strength_camera():
    previous=read_json(COMPOSE/"standing/manifest.json")
    incoming=read_json(ROOT/"standing/manifest.json")
    old={r["id"]:r for r in previous["rows"]}
    output=ROOT/"standing-matched"
    output.mkdir()
    values=[]
    for row in incoming["rows"]:
        if not row["band_model"]:
            continue
        done=old[row["id"]]
        with np.load(checked(row["linear"]),allow_pickle=False) as f:
            base,prior,new=(f[k]for k in ("parent","previous","checked"))
        lx,ly,_,_=row["box"]
        rx,ry,w,h=row["ROI"]
        roi=(rx-lx,ry-ly,w,h)
        p=np.s_[...,roi[1]:roi[1]+h,roi[0]:roi[0]+w]
        strength=rms((new-base)[p].astype(float))/rms((prior-base)[p].astype(float))
        scaled=base+strength*(prior-base)
        with np.load(checked(row["base_input"]),allow_pickle=False)as f:
            wb,mat=(torch.from_numpy(f[k])for k in ("wb","matrix"))
        panels=[]
        for tag,n in (("Earlier checked donor",prior),("Earlier donor, equal RGB RMS",scaled),("Supported bands",new)):
            pix=display_crop(torch.from_numpy(n[None]),wb,mat,roi,exposure=row["display_exposure"])
            panels.append((tag,np.rint(pix*255).astype(np.uint8)))
        with Image.open(checked(done["image"]))as f:
            same=np.asarray(f.convert("RGB"))
        for panel in done["panels"]:
            if panel["name"] in ("ISO100 AHD reference","ISO100 camera JPEG"):
                x,y,pw,ph=panel["png_xywh"]
                panels.append((panel["name"],same[y:y+ph,x:x+pw]))
        picture=native_png(output/(row["id"]+".png"),panels)
        values.append({"id":row["id"],"image":picture["image"],"panels":picture["panels"],"view_source":row["image"],
                       "strength_multiplier":strength,"ROIs":row["ROI"],"noise":row["noise"],
                       "display_exposure":row["display_exposure"],"checkpoint":incoming["checkpoint"]})
    assert len(values)==2
    return values


def main():
    torch.set_num_threads(2)
    stamp=reference(ROOT/"replay.json")
    widths=reference(ROOT/"width-probe.json")
    replay=read_json(checked(stamp))
    audit=analytic()
    routes=exact_strength_and_route(replay)
    cameras=render_strength_camera()
    write_json(ROOT/"verification.json",{
        "driver":reference(__file__),"replay":stamp,"width_probe":widths,
        "analytic_filter":audit,"shape_routing":routes,"strength_matched_camera":cameras})
    print(audit,routes["diagnostic_strength_multiplier"],[r["strength_multiplier"]for r in cameras])


if __name__=="__main__":
    main()
