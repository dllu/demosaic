"""Lay out unresized native cells for manual inspection."""

from PIL import Image, ImageDraw

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_pooled import LABELS, ROOT, pixels


def sheet(key, rows, labels):
    canvas = Image.new("RGB", (8 + 168*len(labels), 26 + 184*len(rows)), "#eeeeee")
    title = ImageDraw.Draw(canvas)
    for col, label in enumerate(labels):
        title.text((8 + 168*col, 5), label, fill="black")
    for row, (label, board) in enumerate(rows):
        values = pixels(board)
        for col, name in enumerate(labels):
            panel = Image.fromarray(values[name])
            assert panel.size == (160, 160)
            canvas.paste(panel, (8 + 168*col, 26 + 184*row))
        title.text((8, 188 + 184*row), label, fill="black")
    file = ROOT / f"view-{key}.png"
    canvas.save(file)
    return reference(file)


def main():
    receipts = {key: reference(ROOT / f"native/{key}/result.json")
                for key in ("standing", "exact")}
    stand, exact = (read_json(checked(k))["rows"] for k in receipts.values())
    primary = ("Noisy (Malvar)", "Corpus 100k", "Across-wire phase",
               "Pooled support", "Threshold supplement", "ISO100 AHD reference")
    controls = ("V120 EMA", "Four-grid mean", "Joint gate", "Per-green supplement",
                "Wrong-phase supplement")
    views = {}
    for group, exposure in (("main", 4), ("mesh", 4), ("mesh", 16)):
        rows = [(r["id"], d["board"]) for r in stand if r["id"].startswith(group)
                for d in r["displays"] if d["exposure"] == exposure]
        assert len(rows) == 4
        tag = f"{group}-x{exposure}"
        views[tag] = sheet(tag, rows, primary)
        jpeg = ("ISO6400 camera JPEG", "ISO100 camera JPEG") if group == "mesh" else ()
        views[tag + "-controls"] = sheet(tag + "-controls", rows, controls + jpeg)
    views["exact"] = sheet(
        "exact", [(r["id"], r["board"]) for r in exact],
        ("Noisy Malvar", "Corpus 100k", *LABELS.values(), "Exact GT"),
    )
    write_json(ROOT / "views.json", {
        "driver": reference(__file__), "receipts": receipts, "sheets": views,
    })


if __name__ == "__main__":
    main()
