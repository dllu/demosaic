"""Use adjacent phase only when a positive center measurement is marginal."""

import numpy as np

from pooled_phase import (
    blend, cell_update, lag_pairs, local_gate, neighbor_by_green,
    neighbor_scores, patch, pooled_gates, ramp, standardized_center,
)

MODES = ("normal", "rescue", "rescue_per_green", "rescue_wrong")


def rescue_gates(original, center, support):
    weak = center.min(axis=1)
    # Full access below the original 0.5-sigma threshold. Fade by 1 sigma
    # so the stronger correction remains the original across-wire gate.
    priority = np.clip((1 - weak) / 0.5, 0, 1)

    def supplement(name):
        return original + priority * np.maximum(support[name] - original, 0)

    return {
        "normal": original,
        "rescue": supplement("pooled"),
        "rescue_per_green": supplement("per_green"),
        "rescue_wrong": supplement("wrong_phase"),
    }


def corrections(raw, parent, colors, shot, read, box, encoded):
    output = {name: np.zeros_like(parent) for name in MODES}
    if encoded is None:
        return output
    all_grids, bank = encoded
    size = bank.band.size
    if min(parent.shape) < size:
        return output

    grids = all_grids[1:]
    axes = tuple(np.arange(0, n - size + 1, size // 2) for n in parent.shape)
    groups, signs, mapping, neighbors = lag_pairs(tuple(colors), bank.band, tuple(map(len, axes)))
    y, x = np.meshgrid(*axes, indexing="ij")
    coords = np.column_stack((y.ravel(), x.ravel()))
    offsets = np.arange(size)
    ys = coords[:, 0, None, None] + offsets[:, None]
    xs = coords[:, 1, None, None] + offsets[None, :]
    raw_windows = patch.sample_windows(raw, coords, size)
    base_windows = parent[ys, xs]
    feature, _, sigma, valid = patch.encode(raw_windows, grids[0].basis, shot, read)
    saved, weights = patch.choose_exterior(
        feature, coords + np.asarray(box)[[1, 0]], bank, ranked=True
    )
    saved = saved[..., len(all_grids[0].frequency):, :]
    green = grids[0].basis.green
    observed_sites = raw_windows[:, green].reshape(len(coords), 2, -1)
    parent_sites = np.stack(
        [base_windows[:, g // 2 :: 2, g % 2 :: 2] for g in green], axis=1
    ).reshape(len(coords), 2, -1)

    # Match the original per-grid contraction. Fold in the conjugation
    # convention after projecting each physical green lattice.
    def project(sites):
        result = np.concatenate([
            np.einsum("gif,qgf->qgi", g.basis.projection, sites).reshape(len(coords), 2, -1, 2)
            for g in grids
        ], axis=2)
        return result[..., 0] + 1j * signs * result[..., 1]

    donors = saved[..., 0] + 1j * signs * saved[..., 1]
    observed, predicted = project(observed_sites), project(parent_sites)
    phase, center, radial = standardized_center(observed, predicted, sigma, mapping)
    potential = np.zeros_like(radial)
    for indexes in groups:
        _, potential[:, indexes] = cell_update(
            donors[..., indexes], weights, observed[..., indexes], predicted[..., indexes],
            radial[..., indexes], sigma, mapping[:, indexes],
        )
    # Preserve the old grouped support and exterior weighting. Replace only
    # the hard local dominance that previously operated before neighbor support.
    neighbor, eligible, rotation = neighbors[1]
    eligible = eligible & valid[neighbor]
    along, wrong = neighbor_by_green(observed, sigma, mapping, phase, (neighbor, eligible, rotation))
    admitted = ramp(center.min(axis=1))
    same, _ = neighbor_scores(observed, sigma, mapping, neighbor, eligible, rotation)
    original = admitted * local_gate(same)
    support = pooled_gates(center, along, wrong, eligible.any(axis=0))
    gates = rescue_gates(original, center, support)

    taper = np.sin((offsets + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(coords), size, size)))
    images = np.concatenate([grid.basis.image for grid in grids])
    for name, gate in gates.items():
        field = potential * gate
        pairs = np.stack((field.real, field.imag * signs), axis=-1)
        pairs *= valid[:, None, None] / len(grids)
        output[name] = blend(pairs, images, parent, ys, xs, window) / np.maximum(1, norm)
    return output
