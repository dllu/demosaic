"""Bind the gain sweeps, both center-support policies and native reviews."""

from datetime import datetime
from hashlib import sha256
from pathlib import Path
import shutil
import tarfile
from zoneinfo import ZoneInfo

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from native_pooled import LABELS, NEIGHBORS, OPERATING_POINT, ROOT, pixels

REPO = ROOT.parents[2]
IMAGES = REPO / "docs/images" / ROOT.name
RESULTS = REPO / "docs/results" / ROOT.name
EXTERNAL = Path("/mnt/external/demosaic")
FILES = {
    "pooled_calibration": "calibration.json", "supplement_calibration": "rescue-calibration.json",
    "curves": "curves.json", "views": "views.json", "standing": "native/standing/result.json",
    "exact": "native/exact/result.json",
}
PANELS = {"prior": 24, "fresh": 24, "transfer": 32, "natural": 32, "natural-B": 32}
for name in PANELS:
    FILES[f"pooled_{name}"] = f"{name}.json"
    FILES[f"supplement_{name}"] = f"rescue-{name}.json"


def copy(ref, family=""):
    path = checked(ref)
    target = IMAGES / family / path.name
    shutil.copyfile(path, target)
    assert reference(target)["sha256"] == ref["sha256"]
    return ref | {"path": str(target.relative_to(IMAGES))}


def verify(board, family):
    panel = pixels(board)
    assert len(panel) == len(board["panels"])
    assert all(p.shape == (160, 160, 3) for p in panel.values())
    return board | {"image": copy(board["image"], family)}


def main():
    receipts = {k: reference(ROOT / p) for k, p in FILES.items()}
    data = {k: read_json(checked(v)) for k, v in receipts.items()}
    first, second = (data[f"{k}_calibration"] for k in ("pooled", "supplement"))
    assert first["original"] == second["original"]
    assert len(first["rows"]) == len(second["rows"]) == 32
    assert all(first["invariants"].values()) and all(second["invariants"].values())
    for key, count in PANELS.items():
        a, b = (data[f"{s}_{key}"] for s in ("pooled", "supplement"))
        assert a["original"] == b["original"]
        assert len(a["rows"]) == len(b["rows"]) == count
        assert all(x["case"] == y["case"] for x, y in zip(a["rows"], b["rows"], strict=True))
        for tag, item in (("pooled", a), ("supplement", b)):
            assert item["calibration"] == receipts[f"{tag}_calibration"]
    standing, exact, shown, graph = (data[k] for k in ("standing", "exact", "views", "curves"))
    assert exact["comparison"] == receipts["supplement_transfer"]
    assert shown["receipts"] == {k: receipts[k] for k in ("standing", "exact")}
    for p in shown["sheets"].values():
        checked(p)
    for item in (standing, exact):
        assert item["calibration"] == receipts["supplement_calibration"]
        assert item["policy"] == OPERATING_POINT
    prior_pub = reference(REPO / "docs/results" / NEIGHBORS.name / "publication.json")
    parent = read_json(checked(prior_pub))["weights"]

    (IMAGES / "standing").mkdir(parents=True)
    (IMAGES / "exact").mkdir()
    RESULTS.mkdir(parents=True)
    review = []
    for item in standing["rows"]:
        mesh = item["id"].startswith("mesh")
        renders = []
        assert {x["exposure"] for x in item["displays"]} == ({4, 16} if mesh else {4})
        for d in item["displays"]:
            expected = {"Noisy (Malvar)", "Corpus 100k", "V120 EMA", *LABELS.values(),
                        "ISO100 AHD reference"}
            if mesh:
                expected |= {"ISO6400 camera JPEG", "ISO100 camera JPEG"}
            assert expected <= pixels(d["board"]).keys()
            renders.append(d | {"board": verify(d["board"], "standing")})
        review.append(item | {"displays": renders})
    assert len(review) == 8 and sum(len(x["displays"]) for x in review) == 12
    examples = []
    for r in exact["rows"]:
        all_cells, triplet = (pixels(r[k]) for k in ("board", "triplet"))
        assert list(triplet) == ["Noisy Malvar", "Threshold supplement", "Exact GT"]
        for label, image in triplet.items():
            np.testing.assert_array_equal(image, all_cells[label])
        examples.append(r | {k: verify(r[k], "exact") for k in ("board", "triplet")})
    assert len(examples) == 4
    manifest = IMAGES / "manifest.json"
    write_json(manifest, {
        "weights": parent, "weight_type": "EMA", "displayed_policy": OPERATING_POINT,
        "plot": copy(graph["figure"]), "exact": examples, "standing": review,
        "review": {
            "local_time": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "sheets": receipts["views"],
            "standing": "Both displays and priors viewed with AHD and both cab JPEGs. "
                        "The sky stays smooth, coarse links remain connected and fine crossings "
                        "stay incomplete. The building cables and fine foliage remain soft.",
            "exact": "Two exact-target backgrounds and their flat controls viewed with matched native cells.",
        },
    })
    sources = [*receipts.values(), *(r["driver"] for r in data.values()), first["operator"],
               second["operator"], first["original"], standing["baseline"], prior_pub,
               *[data[f"pooled_{k}"]["original"] for k in PANELS],
               reference(NEIGHBORS / "phase_neighbors.py"), reference(manifest), reference(__file__),
               reference(REPO / "configs/gfx-qualitative-20231231.json"),
               reference(REPO / "configs/gfx-green-mesh-20231231.json")]
    archive = RESULTS / "evidence.tar.xz"
    members = {}
    with tarfile.open(archive, "x:xz", preset=4) as tar:
        for ref in {r["path"]: r for r in sources}.values():
            path = checked(ref)
            name = (path.relative_to(REPO) if path.is_relative_to(REPO)
                    else Path("external") / path.relative_to(EXTERNAL)).as_posix()
            tar.add(path, arcname=name)
            members[name] = ref["sha256"]
    with tarfile.open(archive) as tar:
        assert all(sha256(tar.extractfile(path).read()).hexdigest() == value
                   for path, value in members.items())
    write_json(RESULTS / "publication.json", {
        "scope": "Inference replay of pooled and below-threshold phase support over Corpus 100k EMA.",
        "weights": parent, "weight_type": "EMA", "receipts": receipts,
        "natural_constraints": first["constraints"],
        "gains": {k: data[f"{k}_calibration"]["gains"] for k in ("pooled", "supplement")},
        "summary": {k: v["summary"] for k, v in data.items() if "summary" in v},
        "seconds": {k: v["seconds"] for k, v in data.items() if "seconds" in v},
        "manifest": reference(manifest), "archive": reference(archive), "members": members,
    })


if __name__ == "__main__":
    main()
