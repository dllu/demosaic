"""Measure recovery versus false detail over a range of fixed correction gains."""

import os

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from score_pooled import ROOT, replay, values

METHODS = {
    "normal": ("Across-wire gate", "#15776e"),
    "pooled": ("Pooled support", "#ae4e32"),
    "rescue": ("Below-threshold supplement", "#326baa"),
    "rescue_wrong": ("Quarter-cycle supplement", "#956891"),
    "dense": ("Dense cosine", "#666666"),
}
RESPONSE = "fundamental_response"
FALSE = "fundamental_false_RMS_DN16"
CONTINUING = "gap_continuing_strong_RMS_DN16"
SCALE = np.linspace(0, 2, 101)


def main():
    original = reference(ROOT / "calibration.json")
    supplement = reference(ROOT / "rescue-calibration.json")
    old = reference(ROOT / "transfer.json")
    new = reference(ROOT / "rescue-transfer.json")
    natural_old = reference(ROOT / "natural.json")
    natural_new = reference(ROOT / "rescue-natural.json")
    base = read_json(checked(original))["gains"]["natural_limits"]
    more = read_json(checked(supplement))["gains"]["natural_limits"]
    controls = read_json(checked(read_json(checked(old))["older_control_gains"]))
    scales = base | more | {"dense": controls["strengths"]["dense"]["gain"]}
    old_rows = read_json(checked(old))["rows"]
    new_rows = read_json(checked(new))["rows"]
    wire = []
    for a, b in zip(old_rows, new_rows, strict=True):
        assert a["case"] == b["case"]
        x, y = (r["width"]["4800"] for r in (a, b))
        wire.append(x | {"terms": x["terms"] | y["terms"]})
    photos = []
    for a, b in zip(read_json(checked(natural_old))["rows"],
                    read_json(checked(natural_new))["rows"], strict=True):
        assert a["case"] == b["case"]
        photos.append(a | {"terms": a["terms"] | b["terms"]})
    idx = np.arange(len(photos))[None, :]
    results = {}
    for method in METHODS:
        output = {"scale": SCALE.tolist()}
        for metric in (RESPONSE, FALSE, CONTINUING):
            subset = [r for r in wire if metric in r["origin"]]
            output[metric] = [float(values(subset, method, metric, g).mean()) for g in SCALE * scales[method]]
        for metric in ("flat", "increment"):
            terms = replay.arrays(photos, method, "fine", metric)
            output[metric] = [float(replay.estimate(terms, metric, g, idx)[0])
                              for g in SCALE * scales[method]]
        results[method] = output
    os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 3, figsize=(11.8, 3.65), layout="constrained")
    for name, (label, color) in METHODS.items():
        result = results[name]
        for ax, x, y in (
            (axes[0], FALSE, RESPONSE),
            (axes[1], CONTINUING, RESPONSE),
            (axes[2], "flat", "increment"),
        ):
            ax.plot(result[x], result[y], label=label, color=color, lw=1.5)
            ax.scatter(result[x][50], result[y][50], color=color, s=19, zorder=4)
    for ax, x, y in (
        (axes[0], "False weak projection, DN16", "Intact weak response (%)"),
        (axes[1], "Continuing-wire error, DN16", "Intact weak response (%)"),
        (axes[2], "Natural fine-flat error, DN16", "Natural fine-increment error, DN16"),
    ):
        ax.set_xlabel(x)
        ax.set_ylabel(y)
        ax.grid(alpha=0.2)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside upper center", ncols=3, frameon=False, fontsize=8)
    destination = ROOT / "gain-curves.png"
    fig.savefig(destination, dpi=155, facecolor="white")
    write_json(ROOT / "curves.json", {
        "driver": reference(__file__), "inputs": [original, supplement, old, new, natural_old, natural_new],
        "scales": scales, "results": results, "figure": reference(destination),
    })


if __name__ == "__main__":
    main()
