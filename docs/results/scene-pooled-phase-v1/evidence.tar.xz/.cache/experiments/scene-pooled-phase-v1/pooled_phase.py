"""Pool disjoint neighboring phase evidence in the query's Bayer support test."""

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
NEIGHBORS = ROOT.with_name("scene-phase-neighbors-v1")
sys.path.insert(0, str(NEIGHBORS))
from phase_neighbors import cell_update, lag_pairs, local_gate, neighbor_scores, patch
from staggered_phase import blend

MODES = ("normal", "pooled", "per_green", "wrong_phase", "potential")
NEAR_WEIGHT = 0.5


def standardized_center(observed, parent, sigma, mapping):
    """Measure the signed deficit and center evidence in each pair's own phase."""
    center = observed.mean(axis=1)
    magnitude = np.abs(center)
    phase = np.divide(center, magnitude, out=np.zeros_like(center), where=magnitude > 0)
    signed = (observed * phase[:, None].conj()).real
    design = np.stack((mapping.real, mapping.imag), axis=-2)
    covariance = design @ design.swapaxes(-1, -2)
    axis = np.stack((phase.real, phase.imag), axis=-1)
    variance = np.einsum("qfi,gfij,qfj->qgf", axis, covariance, axis)
    noise = sigma[:, None, None] * np.sqrt(np.maximum(variance, 1e-12))
    deficit = ((observed - parent) * phase[:, None].conj()).real.mean(axis=1)
    radial = np.maximum(deficit, 0) * phase
    return phase, signed / noise, radial


def neighbor_by_green(observed, sigma, mapping, phase, choice):
    """Predict the center phase on untouched windows, one green at a time."""
    neighbor, valid, transport = choice
    idx = np.arange(observed.shape[-1])
    seen = observed.transpose(0, 2, 1)[neighbor, idx].transpose(0, 1, 3, 2)
    blocks = np.stack((mapping.real, mapping.imag), axis=-2)
    covariance = blocks @ blocks.swapaxes(-1, -2)
    support = []
    for test in (1, 1j):
        direction = phase[None] * test * transport[:, None, :].conj()
        q = np.stack((direction.real, direction.imag), axis=-1)
        variance = np.einsum("sqfi,gfij,sqfj->sqgf", q, covariance, q)
        scale = sigma[neighbor][:, :, None] * np.sqrt(np.maximum(variance, 1e-12))
        signed = (seen * direction[:, :, None].conj()).real
        result = ((signed / scale) * valid[:, :, None]).sum(axis=0)
        support.append(result / np.sqrt(np.maximum(valid.sum(axis=0), 1))[:, None])
    return support


def ramp(score):
    return np.clip((score - 0.5) / 2, 0, 1)


def pooled_gates(center, adjacent, wrong, has_neighbors):
    """Use nearby RAW to support amplitude while preserving local sign."""
    weakest = center.min(axis=1)
    # Requiring both signs in the center prevents a distant pattern from
    # producing an update by itself. Neighbor precision vanishes at boundaries.
    positive = np.clip(weakest / 0.5, 0, 1)
    weight = NEAR_WEIGHT * has_neighbors
    denom = np.sqrt(1 + weight**2)
    common = np.sqrt(2) * adjacent.mean(axis=1)
    perpendicular = np.sqrt(2) * wrong.mean(axis=1)
    return {
        "pooled": positive * ramp((weakest + weight * common) / denom),
        "per_green": positive * ramp(((center + weight[:, None] * adjacent) / denom[:, None]).min(axis=1)),
        "wrong_phase": positive * ramp((weakest + weight * perpendicular) / denom),
    }


def corrections(raw, parent, colors, shot, read, box, encoded):
    output = {name: np.zeros_like(parent) for name in MODES}
    if encoded is None:
        return output
    all_grids, bank = encoded
    size = bank.band.size
    if min(parent.shape) < size:
        return output

    grids = all_grids[1:]
    axes = tuple(np.arange(0, n - size + 1, size // 2) for n in parent.shape)
    groups, signs, mapping, neighbors = lag_pairs(tuple(colors), bank.band, tuple(map(len, axes)))
    y, x = np.meshgrid(*axes, indexing="ij")
    coords = np.column_stack((y.ravel(), x.ravel()))
    offsets = np.arange(size)
    ys = coords[:, 0, None, None] + offsets[:, None]
    xs = coords[:, 1, None, None] + offsets[None, :]
    raw_windows = patch.sample_windows(raw, coords, size)
    base_windows = parent[ys, xs]
    feature, _, sigma, valid = patch.encode(raw_windows, grids[0].basis, shot, read)
    saved, weights = patch.choose_exterior(
        feature, coords + np.asarray(box)[[1, 0]], bank, ranked=True
    )
    saved = saved[..., len(all_grids[0].frequency):, :]
    green = grids[0].basis.green
    observed_sites = raw_windows[:, green].reshape(len(coords), 2, -1)
    parent_sites = np.stack(
        [base_windows[:, g // 2 :: 2, g % 2 :: 2] for g in green], axis=1
    ).reshape(len(coords), 2, -1)

    # Match the original per-grid contraction. Fold in the conjugation
    # convention after projecting each physical green lattice.
    def project(sites):
        result = np.concatenate([
            np.einsum("gif,qgf->qgi", g.basis.projection, sites).reshape(len(coords), 2, -1, 2)
            for g in grids
        ], axis=2)
        return result[..., 0] + 1j * signs * result[..., 1]

    donors = saved[..., 0] + 1j * signs * saved[..., 1]
    observed, predicted = project(observed_sites), project(parent_sites)
    phase, center, radial = standardized_center(observed, predicted, sigma, mapping)
    potential = np.zeros_like(radial)
    for indexes in groups:
        _, potential[:, indexes] = cell_update(
            donors[..., indexes], weights, observed[..., indexes], predicted[..., indexes],
            radial[..., indexes], sigma, mapping[:, indexes],
        )
    # Preserve the old grouped support and exterior weighting. Replace only
    # the hard local dominance that previously operated before neighbor support.
    neighbor, eligible, rotation = neighbors[1]
    eligible = eligible & valid[neighbor]
    along, wrong = neighbor_by_green(observed, sigma, mapping, phase, (neighbor, eligible, rotation))
    gates = pooled_gates(center, along, wrong, eligible.any(axis=0))
    same, _ = neighbor_scores(observed, sigma, mapping, neighbor, eligible, rotation)
    gates["normal"] = ramp(center.min(axis=1)) * local_gate(same)
    gates["potential"] = np.ones_like(same)

    taper = np.sin((offsets + 0.5) * np.pi / size) ** 2
    window = taper[:, None] * taper[None, :]
    norm = np.zeros_like(parent)
    np.add.at(norm, (ys, xs), np.broadcast_to(window, (len(coords), size, size)))
    images = np.concatenate([grid.basis.image for grid in grids])
    for name, gate in gates.items():
        field = potential * gate
        pairs = np.stack((field.real, field.imag * signs), axis=-1)
        pairs *= valid[:, None, None] / len(grids)
        output[name] = blend(pairs, images, parent, ys, xs, window) / np.maximum(1, norm)
    return output
