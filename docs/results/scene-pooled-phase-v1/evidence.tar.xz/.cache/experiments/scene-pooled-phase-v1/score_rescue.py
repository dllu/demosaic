"""Lock pooled-phase doses and compare with the established across-wire gate."""

import sys

import numpy as np
from scipy.optimize import brentq

from pooled_phase import NEIGHBORS, ROOT, pooled_gates, ramp
from rescue_phase import MODES, corrections, rescue_gates
from score_neighbors import BAND, DENSE, FLAT, RESPONSE, WireFundamental, encode_banks
from score_neighbors import METRICS, patch, replay, run, values
from demosaic.experiments.artifacts import checked, read_json, reference, write_json

TESTS = MODES[1:]
CONTEXT = "normal"


def fields(case, data, parent):
    shot, read = (case["profile"][k] for k in ("shot", "read"))
    scene, color, box = (data["scene_packed"], data["colors"], case["box"])
    dense = patch.build_exterior(scene, color, box, shot, read, band=BAND, dense_radius=DENSE)
    atlas = encode_banks(scene, color, dense, shot, read)
    fields = {k: [] for k in MODES}
    for raw, base in zip(data["packed"], parent, strict=True):
        for name, update in corrections(raw, base[1], color, shot, read, box, atlas).items():
            fields[name].append(replay.apply_delta(np.zeros_like(base), update, data["wb"], data["matrix"], 1))
    return {k: np.stack(v) for k, v in fields.items()}


def wire(row):
    case = row["case"]
    prior = row["width"]["4800"]
    data, base, _ = replay.read_inputs(case)
    change = fields(case, data, base)
    with np.load(checked(case["input"]), allow_pickle=False) as raw:
        exact = {k: raw[k] for k in ("target", "support")}
    evaluate = WireFundamental(data | exact, case["fixture"]["geometry"])
    parent = base.astype(np.float64)
    origin = evaluate(parent)
    assert origin == prior["origin"]
    terms = dict(prior["terms"])
    for name, update in change.items():
        plus, minus = evaluate(parent + update), evaluate(parent - update)
        measured = {}
        for key, value in origin.items():
            p, m = plus[key], minus[key]
            if key in RESPONSE:
                measured[key] = [value, (p - m) / 2]
            else:
                measured[key] = [value**2, (p**2 - m**2) / 2, (p**2 + m**2) / 2 - value**2]
        if name == CONTEXT:
            for key, value in measured.items():
                np.testing.assert_allclose(value, terms[CONTEXT][key], atol=2e-5, rtol=2e-7)
        else:
            terms[name] = measured
    return {"case": case, "width": {"4800": prior | {"terms": terms}}}


def natural(row):
    case = row["case"]
    data, base, _ = replay.read_inputs(case)
    change = fields(case, data, base)
    with np.load(checked(case["input"]), allow_pickle=False) as raw:
        gt = replay.transform(raw["target"], data)
    parent = replay.transform(base, data)
    terms = dict(row["terms"])
    for name, dz in change.items():
        z = replay.transform(dz, data)
        measured = {k: replay.terms(v, z[k], gt[k]) for k, v in parent.items()}
        if name == CONTEXT:
            for band, modes in measured.items():
                for key, score in modes.items():
                    np.testing.assert_allclose(score, terms[name][band][key], atol=2e-5, rtol=2e-7)
        else:
            terms[name] = measured
    return row | {"terms": terms}


def invariants():
    signed = np.array([[[0.3, -0.1, 1.9], [0.31, 0.5, 2.0]]])
    witness = np.full_like(signed, 2.5)
    support = pooled_gates(signed, witness, np.zeros_like(witness), np.ones((1, 3), dtype=bool))
    for arm in ("pooled", "per_green"):
        assert support[arm][0, 0] > 0 and ramp(signed.min(axis=1))[0, 0] == 0
        assert support[arm][0, 1] == 0
        assert support[arm].max() <= 1
    fallback = pooled_gates(signed, witness, witness, np.zeros((1, 3), dtype=bool))
    for confirmed in fallback.values():
        np.testing.assert_array_equal(confirmed, ramp(signed.min(axis=1)))
    original = np.array([[0, 0, 0.31]])
    updated = rescue_gates(original, signed, support)
    for key in MODES[1:3]:
        assert updated[key][0, 0] > 0
        assert updated[key][0, 1] == 0
        assert updated[key][0, 2] == original[0, 2]
        assert np.all(updated[key] >= original) and updated[key].max() <= 1
    return {"requires_two_positive_center_signs": True, "no_neighbor_fallback": True,
            "rescue_preserves_strong_support": True, "opens_below_old_local_threshold": True}


def choose_gains(records, doses):
    x = np.arange(len(records))[None, :]

    def estimate(name, field, gain):
        terms = replay.arrays(records, name, "fine", field)
        return float(replay.estimate(terms, field, gain, x)[0])

    targets = {k: estimate(CONTEXT, k, doses[CONTEXT]) for k in ("flat", "increment")}
    arms = {}
    for name in TESTS:
        arms[name] = dict()
        for k, target in targets.items():
            f = lambda g: estimate(name, k, g) - target
            arms[name][k] = float(brentq(f, 0, 1.5)) if f(1.5) > 0 else 1.5
    return {
        "natural_increment": doses | {k: v["increment"] for k, v in arms.items()},
        "natural_limits": doses | {k: min(v.values()) for k, v in arms.items()},
    }, targets


def lock():
    reference_old = reference(NEIGHBORS / "natural-lock.json")
    record = read_json(checked(reference_old))
    rows, elapsed = run(record["rows"], natural)
    assert len(rows) == 32
    doses = record["strengths"]["natural_increment"]
    candidate, constraints = choose_gains(rows, doses)
    write_json(ROOT / "rescue-calibration.json", {
        "driver": reference(__file__), "operator": reference(ROOT / "rescue_phase.py"),
        "original": reference_old, "constraints": constraints, "gains": candidate,
        "rows": rows, "seconds": elapsed, "invariants": invariants(),
    })
    print(candidate, flush=True)


def wire_summary(rows, gains):
    rng = np.random.default_rng(202611192200)
    groups = [r["width"]["4800"] for r in rows]
    result = {}
    methods = ("origin", "v120", "dense", "staggered_mean", "coherent_strength", *MODES)
    for metric in METRICS:
        eligible = [r for r in groups if metric in r["origin"]]
        n = len(eligible)
        index = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
        estimates = {k: values(eligible, k, metric, gains.get(k, 0))[index].mean(axis=1) for k in methods}
        result[metric] = {"count": n, "modes": indicators(estimates, ("normal", "coherent_strength", "origin"))}
    return result


def indicators(estimates, anchors):
    result = {}
    for name, sample in estimates.items():
        effects = {"value": float(sample[0])}
        for key in anchors:
            delta = sample - estimates[key]
            effects[key] = [float(delta[0]), *np.quantile(delta[1:], [0.025, 0.975]).tolist()]
        result[name] = effects
    return result


def natural_summary(rows, gains):
    rng = np.random.default_rng(202611192200)
    n = len(rows)
    index = np.vstack((np.arange(n), rng.integers(0, n, (8000, n))))
    result = {}
    for field in ("flat", "increment", "response", "present"):
        estimates = {k: replay.estimate(replay.arrays(rows, k, "fine", field), field, g, index)
                     for k, g in gains.items() if all(k in r["terms"] for r in rows)}
        result[field] = indicators(estimates, ("normal", "coherent_strength", "parent"))
    return result


def evaluate(name):
    original = reference(NEIGHBORS / ("natural-doses.json" if name == "natural-B" else name + ".json"))
    source = read_json(checked(original))["rows"]
    settings = reference(ROOT / "rescue-calibration.json")
    gains = read_json(checked(settings))["gains"]
    previous_wire = reference(NEIGHBORS / "calibration.json")
    older_gains = {k: v["gain"] for k, v in read_json(checked(previous_wire))["strengths"].items()}
    select = natural if name.startswith("natural") else wire
    calc = natural_summary if name.startswith("natural") else wire_summary
    rows, elapsed = run(source, select)
    write_json(ROOT / f"rescue-{name}.json", {
        "driver": reference(__file__), "original": original, "calibration": settings,
        "older_control_gains": previous_wire, "rows": rows, "seconds": elapsed,
        "summary": {k: calc(rows, doses if name.startswith("natural") else older_gains | doses)
                    for k, doses in gains.items()},
    })


if __name__ == "__main__":
    assert sys.argv[1] in ("calibration", "natural", "natural-B", "prior", "fresh", "transfer")
    lock() if sys.argv[1] == "calibration" else evaluate(sys.argv[1])
