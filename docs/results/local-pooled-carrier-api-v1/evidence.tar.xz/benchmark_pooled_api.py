"""Time cached GFX inputs on the CPU, including donor nomination each call."""

import os
import platform
import sys
from pathlib import Path
from random import Random
from statistics import median
from time import perf_counter_ns

import scipy

from verify_pooled_api import (
    FIXED, OUT, ROOT, WeakOnly, _spacing, apply, arrays, bounds, checked, np,
    read_json, reference, refine_raw_mesh_carriers, write_json,
)

ROUNDS = 21
WARMUPS = 3


def make_calls(parent, packed, roi, colors, noise, wb, matrix):
    crop = bounds(parent, roi)
    context = bounds(parent, roi, 16)
    args = dict(shot=noise["shot"], read=noise["read"], white_balance=wb, camera_to_srgb=matrix)

    def archived():
        frequencies = _spacing(packed, colors, *roi[:2], clearance=16)
        operator = None if frequencies is None else WeakOnly(*roi[:2], colors, frequencies)
        original, strong, _, pooled, _ = apply(parent, roi, packed, roi, operator, noise, wb, matrix)
        return original + strong + pooled

    def packaged():
        return refine_raw_mesh_carriers(
            crop, packed, colors, roi, method="pooled", parent_context=context, **args,
        )

    def local64():
        return refine_raw_mesh_carriers(crop, packed, colors, roi, **args)

    return {"archived": archived, "pooled": packaged, "local64": local64}


def benchmark():
    fixed = reference(FIXED)
    source = read_json(checked(fixed))
    bound = {name: [] for name in ("archived", "pooled", "local64")}
    cases = []
    for row in source["standing"]:
        data = arrays(row["input"])
        parent_source = row["predictions"]["local50k"]
        parent = np.load(checked(parent_source), allow_pickle=False)[0]
        packed, colors, wb, matrix = (data[key][0] for key in ("packed", "colors", "wb", "matrix"))
        roi = tuple(row["local_ROI"])
        calls = make_calls(parent, packed, roi, colors, row["noise"], wb, matrix)
        np.testing.assert_allclose(calls["archived"](), calls["pooled"](), atol=3e-8, rtol=0)
        for name, run in calls.items():
            for _ in range(WARMUPS):
                run()
        cases.append((row, parent_source, calls, {name: [] for name in bound}))
    order = [(i, m) for i in range(len(cases)) for m in bound]
    shuffle = Random(1671)
    for _ in range(ROUNDS):
        shuffle.shuffle(order)
        for i, name in order:
            _, _, methods, times = cases[i]
            start = perf_counter_ns()
            methods[name]()
            elapsed = (perf_counter_ns() - start) / 1e6
            times[name].append(elapsed)
            bound[name].append(elapsed)
    rows = [
        {
            "id": r["id"], "roi": r["global_ROI"], "noise": r["noise"],
            "input": r["input"], "parent": parent, "ms": times,
            "median_ms": {name: median(values) for name, values in times.items()},
        }
        for r, parent, _, times in cases
    ]
    for row in rows:
        print(row["id"], row["median_ms"], flush=True)
    write_json(OUT / "timing.json", {
        "driver": reference(__file__), "standing": fixed,
        "packaged_sources": [
            reference(ROOT / "src/demosaic" / name)
            for name in ("mesh_carrier_fit.py", "_mesh_pooled.py")
        ],
        "sources": read_json(OUT / "parity-final.json")["reference_source"],
        "parent_checkpoint": source["checkpoints"]["local50k"],
        "rows": rows, "warmups": WARMUPS, "rounds": ROUNDS, "rng": 1671,
        "ms": {name: median(times) for name, times in bound.items()},
        "python": sys.version.split()[0], "numpy": np.__version__, "scipy": scipy.__version__,
        "host": platform.node(), "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "threads": {key: os.environ.get(key) for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS")},
        "hardware": Path("/proc/cpuinfo").read_text().split("\n\n")[0],
        "scope": "Warm CPU crop refinement on preloaded input and parent; no GPU or demosaicing.",
    })


if __name__ == "__main__":
    benchmark()
