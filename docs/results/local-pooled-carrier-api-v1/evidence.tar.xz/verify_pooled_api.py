"""Compare the packaged weak-only path with the archived experiment."""

import os
from pathlib import Path
import sys
import time

import numpy as np

from demosaic.experiments.artifacts import checked, read_json, reference, write_json
from demosaic.mesh_carrier_fit import refine_raw_mesh_carriers, _spacing
from demosaic.prediction_archive import fingerprint

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = Path("/mnt/external/demosaic") / HERE.name
PRIOR = OUT.with_name("local-pooled-carrier-v1")
sys.path.insert(0, str(HERE.with_name(PRIOR.name)))
from weak_only_pool import WeakOnly, apply
from capture_envelope import RAW, NESTED
from score_envelope import arrays, FIXED

QUERY = (176, 176, 160, 160)
LOCAL = (48, 48, 160, 160)
EPSILON = 3e-8


def bounds(value, local, margin=0):
    x, y, w, h = local
    return value[..., y-margin:y+h+margin, x-margin:x+w+margin]


def compare(rgb, packed, rgb_roi, sensor_roi, colors, wb, matrix, noise, clearance, reference_fit):
    current = bounds(rgb, rgb_roi)
    context = bounds(rgb, rgb_roi, 16)
    original, high, low, pooled, evidence = apply(
        rgb, rgb_roi, packed, sensor_roi, reference_fit, noise, wb, matrix,
    )
    np.testing.assert_array_equal(current, original)
    recovered = refine_raw_mesh_carriers(
        current, packed, colors, sensor_roi, shot=noise["shot"], read=noise["read"],
        white_balance=wb, camera_to_srgb=matrix, method="pooled", parent_context=context,
        donor_clearance=clearance,
    )
    expected = original + high + pooled
    np.testing.assert_allclose(expected, recovered, rtol=0, atol=EPSILON)
    truth = (expected.astype("d")-recovered.astype("d"))
    return {
        "input_crop": fingerprint(np.ascontiguousarray(current)),
        "expected": fingerprint(expected), "packaged": fingerprint(recovered),
        "exact_values": int(np.count_nonzero(expected==recovered)), "elements": expected.size,
        "maximum_abs_DN16": float(np.max(np.abs(truth))*65535),
        "rms_DN16": float(np.sqrt(np.mean(truth**2))*65535),
        "chosen": evidence["chosen"], "weak_direction": evidence["weak_direction"],
    }


def evaluate(cases, noise, group):
    rows = []
    for name, observations in cases:
        sample = []
        for obs in observations:
            f = arrays(obs["input"])
            scene = arrays(obs["donor"])["scene_packed"].copy()
            parent = f["local50k"] if "local50k" in f else np.load(checked(obs["parent"]), allow_pickle=False)
            freq = _spacing(scene, f["colors"], *QUERY[:2], clearance=48)
            operator = None if freq is None else WeakOnly(*QUERY[:2], f["colors"], freq)
            roles = []
            for i in obs["roles"]:
                scene[RAW] = f["packed"][i]
                roles.append(compare(parent[i], scene, LOCAL, QUERY, f["colors"], f["wb"],
                                     f["matrix"], noise, 48, operator))
            sample.append({"input": obs["input"], "donor": obs["donor"], "roles": roles})
        rows.append({"id": name, "draws": sample})
        if len(rows) % 8 == 0:
            print(group, len(rows), flush=True)
    return rows


def warped_rows(receipt):
    plan = read_json(checked(receipt["captures"]))
    validated = {r["id"] for r in receipt["confirmation"]}
    source = read_json(checked(plan["plan"]))
    cases = []
    for row in plan["rows"]:
        if row["id"] in validated:
            cases.append((row["id"], [{
                "input": w["input"], "donor": s["input"], "roles": range(5),
            } for w, s in zip(row["observations"]["warped"], row["observations"]["straight"], strict=True)]))
    return evaluate(cases, source["noise"], "warped")


def secondary_rows(receipt):
    data = read_json(checked(receipt["secondary"]["plan"]))
    source = read_json(checked(receipt["secondary"]["parents"]))
    cases = []
    for row in source["records"]:
        cases.append((row["id"], [{
            "input": r["data"], "donor": r["data"], "parent": r["outputs"]["local50k"],
            "roles": (0, 2, 3, 4, 5),
        } for r in row["streams"]]))
    return evaluate(cases, data["noise"], "straight")


def standing(weight):
    source = reference(FIXED)
    review = read_json(checked(source))
    assert review["checkpoints"]["local50k"] == weight
    results = []
    for row in review["standing"]:
        f = arrays(row["input"])
        p = np.load(checked(row["predictions"]["local50k"]), allow_pickle=False)[0]
        packed, colors, wb, matrix = (f[k][0] for k in ("packed", "colors", "wb", "matrix"))
        roi = tuple(row["local_ROI"])
        freq = _spacing(packed, colors, *roi[:2], clearance=16)
        fit = None if freq is None else WeakOnly(*roi[:2], colors, freq)
        probe = compare(p, packed, roi, roi, colors, wb, matrix, row["noise"], None, fit)
        results.append({"id": row["id"], "input": row["input"], "parent": row["predictions"]["local50k"],
                        "noise": row["noise"], "roi": row["global_ROI"], **probe})
    return {"source": source, "rows": results}


def main():
    mark = time.monotonic()
    archived = reference(PRIOR / "review.json")
    x = read_json(checked(archived))
    previous = reference(PRIOR / "weak-only/result.json")
    assert read_json(checked(previous))["prior"] == archived
    panels = {"warped": warped_rows(x), "secondary": secondary_rows(x)}
    gfx = standing(x["weights"]["local50k"])
    values = [row for panel in panels.values() for r in panel for d in r["draws"] for row in d["roles"]]
    values.extend(gfx["rows"])
    assert len(values) == 528
    write_json(OUT/"parity-final.json", {
        "driver": reference(__file__), "reference": archived, "previous": previous,
        "packaged": [reference(ROOT/f"src/demosaic/{name}.py") for name in ("mesh_carrier_fit","_mesh_pooled")],
        "reference_source": reference(HERE.with_name(PRIOR.name)/"weak_only_pool.py"),
        "panels": panels, "standing": gfx, "maximum_DN16": max(r["maximum_abs_DN16"] for r in values),
        "pixel_values": sum(r["elements"] for r in values),
        "pixel_values_exact": sum(r["exact_values"] for r in values),
        "case_count": len(values), "seconds": time.monotonic()-mark,
        "threads": os.environ.get("OPENBLAS_NUM_THREADS"),
    })
    print("Replayed", len(values), "crop outputs.", flush=True)


if __name__ == "__main__":
    main()
